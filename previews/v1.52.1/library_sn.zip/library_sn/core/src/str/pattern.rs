//! Iyo tambo Pattern API.
//!
//! Iyo Pattern API inopa yakajairika mashandisiro ekushandisa akasiyana mapateni mhando kana uchitsvaga kuburikidza netambo.
//!
//! Kuti uwane rumwe ruzivo, ona iyo traits [`Pattern`], [`Searcher`], [`ReverseSearcher`], uye [`DoubleEndedSearcher`].
//!
//! Kunyangwe iyi API isina kugadzikana, inoburitswa kuburikidza nemaAPIs akasimba pane [`str`] mhando.
//!
//! # Examples
//!
//! [`Pattern`] iri [implemented][pattern-impls] mune yakagadzikana API ye [`&str`][`str`], [`char`], zvidimbu zve [`char`], uye mashandiro uye kuvhara kuita `FnMut(char) -> bool`.
//!
//!
//! ```
//! let s = "Can you find a needle in a haystack?";
//!
//! // &str pattern
//! assert_eq!(s.find("you"), Some(4));
//! // char pateni
//! assert_eq!(s.find('n'), Some(2));
//! // chidimbu chematani maitiro
//! assert_eq!(s.find(&['a', 'e', 'i', 'o', 'u'][..]), Some(1));
//! // maitiro ekuvhara
//! assert_eq!(s.find(|c: char| c.is_ascii_punctuation()), Some(35));
//! ```
//!
//! [pattern-impls]: Pattern#implementors
//!
//!
//!
//!

#![unstable(
    feature = "pattern",
    reason = "API not fully fleshed out and ready to be stabilized",
    issue = "27721"
)]

use crate::cmp;
use crate::fmt;
use crate::slice::memchr;

// Pattern

/// Tambo patani.
///
/// `Pattern<'a>` inoratidza kuti mhando yekushandisa inogona kushandiswa senge tambo pateni yekutsvaga mu [`&'a str`][str].
///
/// Semuenzaniso, ese ari maviri `'a'` uye `"aa"` mapatani angaenderana pane index `1` mune tambo `"baaaab"`.
///
/// trait pachayo inoshanda semuvaki weiyo inosanganisirwa [`Searcher`] mhando, iyo inoita basa chairo rekutsvaga zvinoitika zveiyo pateni mune tambo.
///
///
/// Zvichienderana nerudzi rweiyo pateni, maitiro enzira senge [`str::find`] uye [`str::contains`] anogona kuchinja.
/// Tafura iri pazasi inotsanangura mamwe eaya maitiro.
///
/// | Pattern type             | Match condition                           |
/// |--------------------------|-------------------------------------------|
/// | `&str`                   | is substring                              |
/// | `char`                   | is contained in string                    |
/// | `&[char]`                | any char in slice is contained in string  |
/// | `F: FnMut(char) -> bool` | `F` returns `true` for a char in string   |
/// | `&&str`                  | is substring                              |
/// | `&String`                | is substring                              |
///
/// # Examples
///
/// ```
/// // &str
/// assert_eq!("abaaa".find("ba"), Some(1));
/// assert_eq!("abaaa".find("bac"), None);
///
/// // char
/// assert_eq!("abaaa".find('a'), Some(0));
/// assert_eq!("abaaa".find('b'), Some(1));
/// assert_eq!("abaaa".find('c'), None);
///
/// // &[char]
/// assert_eq!("ab".find(&['b', 'a'][..]), Some(0));
/// assert_eq!("abaaa".find(&['a', 'z'][..]), Some(0));
/// assert_eq!("abaaa".find(&['c', 'd'][..]), None);
///
/// // FnMut(char) -> bool
/// assert_eq!("abcdef_z".find(|ch| ch > 'd' && ch < 'y'), Some(4));
/// assert_eq!("abcddd_z".find(|ch| ch > 'd' && ch < 'y'), None);
/// ```
///
///
///
///
pub trait Pattern<'a>: Sized {
    /// Yakabatanidzwa yekutsvaga iyi pateni
    type Searcher: Searcher<'a>;

    /// Inogadzira inotsvaga yakatsvaga kubva ku `self` uye iyo `haystack` yekutsvaga mukati.
    ///
    fn into_searcher(self, haystack: &'a str) -> Self::Searcher;

    /// Inotarisa kana iyo pateni inowirirana chero kupi mune iyo haystack
    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        self.into_searcher(haystack).next_match().is_some()
    }

    /// Inotarisa kana iyo pateni inowirirana kumberi kwehuswa
    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        matches!(self.into_searcher(haystack).next(), SearchStep::Match(0, _))
    }

    /// Inotarisa kana iyo pateni inowirirana kuseri kwehuswa
    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        matches!(self.into_searcher(haystack).next_back(), SearchStep::Match(_, j) if haystack.len() == j)
    }

    /// Inobvisa iyo pateni kubva kumberi kwehuswa, kana ichienderana.
    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        if let SearchStep::Match(start, len) = self.into_searcher(haystack).next() {
            debug_assert_eq!(
                start, 0,
                "The first search step from Searcher \
                 must include the first character"
            );
            // KUCHENGETEKA: `Searcher` inozivikanwa kuti idzore indices inoshanda.
            unsafe { Some(haystack.get_unchecked(len..)) }
        } else {
            None
        }
    }

    /// Inobvisa iyo pateni kubva kumashure kwehuswa, kana ichienderana.
    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        if let SearchStep::Match(start, end) = self.into_searcher(haystack).next_back() {
            debug_assert_eq!(
                end,
                haystack.len(),
                "The first search step from ReverseSearcher \
                 must include the last character"
            );
            // KUCHENGETEKA: `Searcher` inozivikanwa kuti idzore indices inoshanda.
            unsafe { Some(haystack.get_unchecked(..start)) }
        } else {
            None
        }
    }
}

// Searcher

/// Mhedzisiro yekufona [`Searcher::next()`] kana [`ReverseSearcher::next_back()`].
#[derive(Copy, Clone, Eq, PartialEq, Debug)]
pub enum SearchStep {
    /// Inotaura kuti mechi yemhando yacho yawanikwa pa `haystack[a..b]`.
    ///
    Match(usize, usize),
    /// Inotaura kuti `haystack[a..b]` yakarambwa senge inogona kuita mutambo.
    ///
    /// Ziva kuti panogona kuve neanopfuura imwe `Reject` pakati pemaviri`Match`es, hapana chikonzero chekuti ivo vasanganiswe kuita imwechete.
    ///
    ///
    Reject(usize, usize),
    /// Inotaura kuti yega yega ye haystack yashanyirwa, ichigumisa iteration.
    ///
    Done,
}

/// Mutsvaguru weiyo tambo pateni.
///
/// Iyi trait inopa nzira dzekutsvaga dzisina kupindirana machisi epateni kutanga kubva kumberi (left) yetambo.
///
/// Ichaitiswa nemhando dzakabatana dze `Searcher` dze [`Pattern`] trait.
///
/// trait inoratidzirwa isina kuchengeteka nekuti indices dzinodzoserwa nenzira dze [`next()`][Searcher::next] dzinodiwa kuti dzirare pamiganhu ye utf8 inoshanda mune haystack.
/// Izvi zvinogonesa vatengi veiyi trait kutsemura haystack pasina kuwedzerwa nguva yekumhanya.
///
///
///
///
pub unsafe trait Searcher<'a> {
    /// Getter yeiyo tambo yepazasi inotsvaga mukati
    ///
    /// Ndichagara ndichidzosa iyo imwechete [`&str`][str].
    fn haystack(&self) -> &'a str;

    /// Inoita inotevera yekutsvaga nhanho kutanga kubva kumberi.
    ///
    /// - Inodzorera [`Match(a, b)`][SearchStep::Match] kana `haystack[a..b]` yakafanana neiyi pateni.
    /// - Inodzorera [`Reject(a, b)`][SearchStep::Reject] kana `haystack[a..b]` isingakwanise kufanana nepateni, kunyangwe zvishoma.
    /// - Inodzorera [`Done`][SearchStep::Done] kana yega yega yehuswa yakashanyirwa.
    ///
    /// Rukova rwe [`Match`][SearchStep::Match] uye [`Reject`][SearchStep::Reject] kukosha kusvika pa [`Done`][SearchStep::Done] richava nematanho ematanho ari padhuze, asingapindirane, achifukidza huswa hwese, nekuisa pamiganhu ye utf8.
    ///
    ///
    /// Mhedzisiro ye [`Match`][SearchStep::Match] inoda kuve neyakaenzana pateni, zvisinei [`Reject`][SearchStep::Reject] mhedzisiro inogona kupatsanurwa kuita zvimupindirana zvidimbu zvakawanda zviri pedyo.Mavara ese ari maviri anogona kunge aine zero zero.
    ///
    /// Semuenzaniso, iyo pateni `"aaa"` uye haystack `"cbaaaaab"` inogona kuburitsa rwizi
    /// `[Reject(0, 1), Reject(1, 2), Match(2, 5), Reject(5, 8)]`
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn next(&mut self) -> SearchStep;

    /// Inotsvaga inotevera [`Match`][SearchStep::Match] mhedzisiro.Ona [`next()`][Searcher::next].
    ///
    /// Kusiyana ne [`next()`][Searcher::next], hapana vimbiso yekuti mitsara yakadzoserwa yeiyi uye [`next_reject`][Searcher::next_reject] ichapfuura.
    /// Izvi zvinodzosera `(start_match, end_match)`, uko start_match iri indekisi yekuti mutambo wacho unotangira kupi, uye end_match ndiyo indekisi mushure mekuguma kwemutambo.
    ///
    ///
    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next() {
                SearchStep::Match(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }

    /// Inotsvaga inotevera [`Reject`][SearchStep::Reject] mhedzisiro.Ona [`next()`][Searcher::next] uye [`next_match()`][Searcher::next_match].
    ///
    /// Kusiyana ne [`next()`][Searcher::next], hapana vimbiso yekuti mitsara yakadzoserwa yeiyi uye [`next_match`][Searcher::next_match] ichapfuura.
    ///
    ///
    #[inline]
    fn next_reject(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next() {
                SearchStep::Reject(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }
}

/// Yekutsvaga inotsvaga patambo pateni.
///
/// Iyi trait inopa nzira dzekutsvaga dzisina-kupindirana machisi epateni kutanga kubva kumashure (right) yetambo.
///
/// Ichaitiswa nemhando dzakabatana dze [`Searcher`] dze [`Pattern`] trait kana iyo pateni inotsigira kuitsvaga kubva kumashure.
///
///
/// Idzo renji dzakadzoserwa neiyi trait hazvidiwe kuti zvifanane chaizvo neizvo zvekutsvaga kwekumberi mukudzoka.
///
/// Nechikonzero nei iyi trait ichinzi haina kuchengeteka, vaone ivo mubereki trait [`Searcher`].
///
///
///
///
pub unsafe trait ReverseSearcher<'a>: Searcher<'a> {
    /// Inoita inotevera yekutsvaga nhanho kutanga kubva kumashure.
    ///
    /// - Inodzorera [`Match(a, b)`][SearchStep::Match] kana `haystack[a..b]` yakafanana neiyi pateni.
    /// - Inodzorera [`Reject(a, b)`][SearchStep::Reject] kana `haystack[a..b]` isingakwanise kufanana nepateni, kunyangwe zvishoma.
    /// - Inodzorera [`Done`][SearchStep::Done] kana yega yega yehuswa yakashanyirwa
    ///
    /// Rukova rwe [`Match`][SearchStep::Match] uye [`Reject`][SearchStep::Reject] kukosha kusvika pa [`Done`][SearchStep::Done] richava nematanho ematanho ari padhuze, asingapindirane, achifukidza huswa hwese, nekuisa pamiganhu ye utf8.
    ///
    ///
    /// Mhedzisiro ye [`Match`][SearchStep::Match] inoda kuve neyakaenzana pateni, zvisinei [`Reject`][SearchStep::Reject] mhedzisiro inogona kupatsanurwa kuita zvimupindirana zvidimbu zvakawanda zviri pedyo.Mavara ese ari maviri anogona kunge aine zero zero.
    ///
    /// Semuenzaniso, pateni `"aaa"` uye haystack `"cbaaaaab"` inogona kuburitsa rwizi `[Reject(7, 8), Match(4, 7), Reject(1, 4), Reject(0, 1)]`.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn next_back(&mut self) -> SearchStep;

    /// Inotsvaga inotevera [`Match`][SearchStep::Match] mhedzisiro.
    /// Ona [`next_back()`][ReverseSearcher::next_back].
    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next_back() {
                SearchStep::Match(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }

    /// Inotsvaga inotevera [`Reject`][SearchStep::Reject] mhedzisiro.
    /// Ona [`next_back()`][ReverseSearcher::next_back].
    #[inline]
    fn next_reject_back(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next_back() {
                SearchStep::Reject(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }
}

/// Mucherechedzo trait kuratidza kuti [`ReverseSearcher`] inogona kushandiswa kuitisa [`DoubleEndedIterator`].
///
/// Kune izvi, kuiswa kwe [`Searcher`] uye [`ReverseSearcher`] inoda kuteedzera aya mamiriro:
///
/// - Mhedzisiro yese ye `next()` inoda kufanana nemhedzisiro ye `next_back()` mukudzosera kumashure.
/// - `next()` uye `next_back()` inoda kuzvibata semagumo maviri ehurefu hwemitengo, ndiko kuti havakwanise "walk past each other".
///
/// # Examples
///
/// `char::Searcher` i `DoubleEndedSearcher` nekuti kutsvaga [`char`] kunongoda kutarisa kune imwe panguva, inoita zvakafanana kubva kumagumo maviri.
///
/// `(&str)::Searcher` haisi `DoubleEndedSearcher` nekuti pateni `"aa"` mune haystack `"aaa"` inowirirana senge `"[aa]a"` kana `"a[aa]"`, zvinoenderana nerutivi rwuri kutsvaga.
///
///
///
///
///
///
///
///
///
pub trait DoubleEndedSearcher<'a>: ReverseSearcher<'a> {}

/////////////////////////////////////////////////////////////////////////////
// Impl ye char
/////////////////////////////////////////////////////////////////////////////

/// Yakabatana mhando ye `<char as Pattern<'a>>::Searcher`.
#[derive(Clone, Debug)]
pub struct CharSearcher<'a> {
    haystack: &'a str,
    // chengetedzo inogara ichingoitika: `finger`/`finger_back` inofanirwa kunge iri yechokwadi utf8 byte index ye `haystack` Iyi inowirirana inogona kutyorwa *mukati me* next_match uye next_match_back, zvisinei ivo vanofanirwa kubuda nezvigunwe pamiganhu inoshanda yekodhi kodhi.
    //
    //
    /// `finger` ndiyo indekisi yazvino yetete yekutsvaga kwekumberi.
    /// Fungidzira kuti iripo pamberi peyete paindekisi yayo, kureva
    /// `haystack[finger]` ndiyo yekutanga byte yechidimbu chatinofanira kuongorora panguva yekutsvaga kumberi
    ///
    finger: usize,
    /// `finger_back` ndiyo indekisi yazvino yetete yekutsvaga kwekutsvaga.
    /// Fungidzira kuti iripo mushure meyakafa indekisi yayo, kureva
    /// haystack [munwe_musana, 1] ndiyo yekupedzisira chidimbu chechidimbu chatinofanira kuongorora panguva yekutsvaga kumberi (uye nekudaro yekutanga byte yekuongororwa kana ichisheedza next_back()).
    ///
    finger_back: usize,
    /// Hunhu huri kutsvagwa
    needle: char,

    // chengetedzo isinga pindirani: `utf8_size` inofanira kunge iri pasi pe5
    /// Huwandu hwemabheti `needle` hunotora kana hwakamisikidzwa mu utf8.
    utf8_size: usize,
    /// A utf8 kopi yakanyorwa ye `needle`
    utf8_encoded: [u8; 4],
}

unsafe impl<'a> Searcher<'a> for CharSearcher<'a> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }
    #[inline]
    fn next(&mut self) -> SearchStep {
        let old_finger = self.finger;
        // Kachengeteka: 1-4 vimbiso chengetedzo ye `get_unchecked`
        // 1. `self.finger` uye `self.finger_back` inochengetwa pamatanho eunicode (izvi zvinogara zvichishanduka)
        // 2. `self.finger >= 0` sezvo ichitanga pa0 uye inongowedzera chete
        // 3. `self.finger < self.finger_back` nekuti zvikasadaro char `iter` yaizodzosa `SearchStep::Done`
        // 4.
        // `self.finger` inouya pamberi pokupera kwehuswa nekuti `self.finger_back` inotangira kumagumo uye inongodzikira
        //
        //
        let slice = unsafe { self.haystack.get_unchecked(old_finger..self.finger_back) };
        let mut iter = slice.chars();
        let old_len = iter.iter.len();
        if let Some(ch) = iter.next() {
            // wedzera byte offset yeazvino hunhu pasina kuisazve encoding se utf-8
            //
            self.finger += old_len - iter.iter.len();
            if ch == self.needle {
                SearchStep::Match(old_finger, self.finger)
            } else {
                SearchStep::Reject(old_finger, self.finger)
            }
        } else {
            SearchStep::Done
        }
    }
    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        loop {
            // tora haystack mushure mekupedzisira hunhu hwawanikwa
            let bytes = self.haystack.as_bytes().get(self.finger..self.finger_back)?;
            // yekupedzisira byte ye utf8 yakavharidzirwa tsono KUSVIKIRA: isu tine inosiana iyo `utf8_size < 5`
            //
            let last_byte = unsafe { *self.utf8_encoded.get_unchecked(self.utf8_size - 1) };
            if let Some(index) = memchr::memchr(last_byte, bytes) {
                // Munwe mutsva ndiyo indekisi yetete yatakawana, uyezve imwe, sezvo isu takakumbira yekupedzisira byte yemunhu.
                //
                // Ziva kuti izvi hazviwanzo kutipa munwe pamuganhu we UTF8.
                // Dai isu * tisina kuwana hunhu hwedu tingave takanongedzera kune isiri yekupedzisira byte ye3-byte kana 4-byte hunhu.
                // Hatigone kungosvetukira kune inotevera inoshanda yekutanga byte nekuti hunhu senge ꁁ (U + A041 YI SYLLABLE PA), utf-8 `EA 81 81` ichaita kuti tigare tichiwana yechipiri byte pakutsvaga chechitatu.
                //
                //
                // Nekudaro, izvi zvakanyatsonaka.
                // Kunyange isu tiine inogara ichishanduka iyo self.finger iri pamuganhu we UTF8, ino inogara isinga tsanangurike mukati meiyi nzira (inovimbwa nayo mu CharSearcher::next()).
                //
                // Isu tinongobuda nenzira iyi kana tasvika kumagumo kwetambo, kana kana tikawana chimwe chinhu.Kana tawana chimwe chinhu iyo `finger` ichaiswa kumuganhu we UTF8.
                //
                //
                //
                //
                //
                //
                self.finger += index + 1;
                if self.finger >= self.utf8_size {
                    let found_char = self.finger - self.utf8_size;
                    if let Some(slice) = self.haystack.as_bytes().get(found_char..self.finger) {
                        if slice == &self.utf8_encoded[0..self.utf8_size] {
                            return Some((found_char, self.finger));
                        }
                    }
                }
            } else {
                // hapana chavakawana, buda
                self.finger = self.finger_back;
                return None;
            }
        }
    }

    // rega next_reject shandisa iyo yekumisikidza kuitisa kubva kuSearcher trait
}

unsafe impl<'a> ReverseSearcher<'a> for CharSearcher<'a> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        let old_finger = self.finger_back;
        // Kachengeteka: ona chirevo che next() pamusoro
        let slice = unsafe { self.haystack.get_unchecked(self.finger..old_finger) };
        let mut iter = slice.chars();
        let old_len = iter.iter.len();
        if let Some(ch) = iter.next_back() {
            // bvisa byte kukanganiswa kwehunhu hwazvino pasina kuisazve encoding se utf-8
            //
            self.finger_back -= old_len - iter.iter.len();
            if ch == self.needle {
                SearchStep::Match(self.finger_back, old_finger)
            } else {
                SearchStep::Reject(self.finger_back, old_finger)
            }
        } else {
            SearchStep::Done
        }
    }
    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        let haystack = self.haystack.as_bytes();
        loop {
            // tora haystack kusvika asi kwete kusanganisira wekupedzisira munhu akatsvaga
            let bytes = haystack.get(self.finger..self.finger_back)?;
            // yekupedzisira byte ye utf8 yakavharidzirwa tsono KUSVIKIRA: isu tine inosiana iyo `utf8_size < 5`
            //
            let last_byte = unsafe { *self.utf8_encoded.get_unchecked(self.utf8_size - 1) };
            if let Some(index) = memchr::memrchr(last_byte, bytes) {
                // isu takatsvaga chidimbu chakakanganiswa ne self.finger, wedzera self.finger kuti utore index yekutanga
                //
                let index = self.finger + index;
                // memrchr inodzosa indekisi yetete yatinoshuvira kuwana.
                // Kana paine ASCII hunhu, izvi ndizvo chaizvo zvataishuvira kuti munwe wedu mutsva uve ("after" iyo yakawanikwa char mune paradigm yekudzosera iteration).
                //
                // Kune multibyte chars isu tinofanirwa kusvetuka pasi nenhamba yemamwe mabheti avanayo kupfuura ASCII
                //
                //
                let shift = self.utf8_size - 1;
                if index >= shift {
                    let found_char = index - shift;
                    if let Some(slice) = haystack.get(found_char..(found_char + self.utf8_size)) {
                        if slice == &self.utf8_encoded[0..self.utf8_size] {
                            // fambisa chigunwe pamberi pechimiro chisati chawanikwa (kureva., pakutanga kwadzo index)
                            self.finger_back = found_char;
                            return Some((self.finger_back, self.finger_back + self.utf8_size));
                        }
                    }
                }
                // Hatigone kushandisa finger_back=index, size + 1 apa.
                // Kana isu tikawana yekupedzisira char yeakasiyana-saizi hunhu (kana yepakati byte yeumwe hunhu) isu tinofanirwa kurovera chigunwe_dzokera pasi ku `index`.
                // Izvi zvakafanana zvinoita kuti `finger_back` ive nekwaniso yekusave pamuganho, asi izvi zvakanaka sezvo isu tichingobuda basa iri pamuganho kana kana haystack yatsvaga zvachose.
                //
                //
                // Kusiyana ne next_match izvi hazvina dambudziko rekudzokororwa mabheti mu utf-8 nekuti isu tiri kutsvaga yekupedzisira byte, uye isu tinogona kungowana yekupedzisira byte patinotsvaga in reverse.
                //
                //
                //
                //
                //
                self.finger_back = index;
            } else {
                self.finger_back = self.finger;
                // hapana chavakawana, buda
                return None;
            }
        }
    }

    // rega next_reject_back ishandise iyo yekumisikidza kuitisa kubva kuSearcher trait
}

impl<'a> DoubleEndedSearcher<'a> for CharSearcher<'a> {}

/// Kutsvaga kwema chars akaenzana neakapihwa [`char`].
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find('o'), Some(4));
/// ```
impl<'a> Pattern<'a> for char {
    type Searcher = CharSearcher<'a>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> Self::Searcher {
        let mut utf8_encoded = [0; 4];
        let utf8_size = self.encode_utf8(&mut utf8_encoded).len();
        CharSearcher {
            haystack,
            finger: 0,
            finger_back: haystack.len(),
            needle: self,
            utf8_size,
            utf8_encoded,
        }
    }

    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        if (self as u32) < 128 {
            haystack.as_bytes().contains(&(self as u8))
        } else {
            let mut buffer = [0u8; 4];
            self.encode_utf8(&mut buffer).is_contained_in(haystack)
        }
    }

    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        self.encode_utf8(&mut [0u8; 4]).is_prefix_of(haystack)
    }

    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        self.encode_utf8(&mut [0u8; 4]).strip_prefix_of(haystack)
    }

    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        self.encode_utf8(&mut [0u8; 4]).is_suffix_of(haystack)
    }

    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        self.encode_utf8(&mut [0u8; 4]).strip_suffix_of(haystack)
    }
}

/////////////////////////////////////////////////////////////////////////////
// Impl ye MultiCharEq inoputira
/////////////////////////////////////////////////////////////////////////////

#[doc(hidden)]
trait MultiCharEq {
    fn matches(&mut self, c: char) -> bool;
}

impl<F> MultiCharEq for F
where
    F: FnMut(char) -> bool,
{
    #[inline]
    fn matches(&mut self, c: char) -> bool {
        (*self)(c)
    }
}

impl MultiCharEq for &[char] {
    #[inline]
    fn matches(&mut self, c: char) -> bool {
        self.iter().any(|&m| m == c)
    }
}

struct MultiCharEqPattern<C: MultiCharEq>(C);

#[derive(Clone, Debug)]
struct MultiCharEqSearcher<'a, C: MultiCharEq> {
    char_eq: C,
    haystack: &'a str,
    char_indices: super::CharIndices<'a>,
}

impl<'a, C: MultiCharEq> Pattern<'a> for MultiCharEqPattern<C> {
    type Searcher = MultiCharEqSearcher<'a, C>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> MultiCharEqSearcher<'a, C> {
        MultiCharEqSearcher { haystack, char_eq: self.0, char_indices: haystack.char_indices() }
    }
}

unsafe impl<'a, C: MultiCharEq> Searcher<'a> for MultiCharEqSearcher<'a, C> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }

    #[inline]
    fn next(&mut self) -> SearchStep {
        let s = &mut self.char_indices;
        // Enzanisa kureba kwemukati byte slice iterator kuti uwane kureba kwazvino char
        //
        let pre_len = s.iter.iter.len();
        if let Some((i, c)) = s.next() {
            let len = s.iter.iter.len();
            let char_len = pre_len - len;
            if self.char_eq.matches(c) {
                return SearchStep::Match(i, i + char_len);
            } else {
                return SearchStep::Reject(i, i + char_len);
            }
        }
        SearchStep::Done
    }
}

unsafe impl<'a, C: MultiCharEq> ReverseSearcher<'a> for MultiCharEqSearcher<'a, C> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        let s = &mut self.char_indices;
        // Enzanisa kureba kwemukati byte slice iterator kuti uwane kureba kwazvino char
        //
        let pre_len = s.iter.iter.len();
        if let Some((i, c)) = s.next_back() {
            let len = s.iter.iter.len();
            let char_len = pre_len - len;
            if self.char_eq.matches(c) {
                return SearchStep::Match(i, i + char_len);
            } else {
                return SearchStep::Reject(i, i + char_len);
            }
        }
        SearchStep::Done
    }
}

impl<'a, C: MultiCharEq> DoubleEndedSearcher<'a> for MultiCharEqSearcher<'a, C> {}

/////////////////////////////////////////////////////////////////////////////

macro_rules! pattern_methods {
    ($t:ty, $pmap:expr, $smap:expr) => {
        type Searcher = $t;

        #[inline]
        fn into_searcher(self, haystack: &'a str) -> $t {
            ($smap)(($pmap)(self).into_searcher(haystack))
        }

        #[inline]
        fn is_contained_in(self, haystack: &'a str) -> bool {
            ($pmap)(self).is_contained_in(haystack)
        }

        #[inline]
        fn is_prefix_of(self, haystack: &'a str) -> bool {
            ($pmap)(self).is_prefix_of(haystack)
        }

        #[inline]
        fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
            ($pmap)(self).strip_prefix_of(haystack)
        }

        #[inline]
        fn is_suffix_of(self, haystack: &'a str) -> bool
        where
            $t: ReverseSearcher<'a>,
        {
            ($pmap)(self).is_suffix_of(haystack)
        }

        #[inline]
        fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
        where
            $t: ReverseSearcher<'a>,
        {
            ($pmap)(self).strip_suffix_of(haystack)
        }
    };
}

macro_rules! searcher_methods {
    (forward) => {
        #[inline]
        fn haystack(&self) -> &'a str {
            self.0.haystack()
        }
        #[inline]
        fn next(&mut self) -> SearchStep {
            self.0.next()
        }
        #[inline]
        fn next_match(&mut self) -> Option<(usize, usize)> {
            self.0.next_match()
        }
        #[inline]
        fn next_reject(&mut self) -> Option<(usize, usize)> {
            self.0.next_reject()
        }
    };
    (reverse) => {
        #[inline]
        fn next_back(&mut self) -> SearchStep {
            self.0.next_back()
        }
        #[inline]
        fn next_match_back(&mut self) -> Option<(usize, usize)> {
            self.0.next_match_back()
        }
        #[inline]
        fn next_reject_back(&mut self) -> Option<(usize, usize)> {
            self.0.next_reject_back()
        }
    };
}

/////////////////////////////////////////////////////////////////////////////
// Impl ye&[char]
/////////////////////////////////////////////////////////////////////////////

// Todo: Chinja/Bvisa nekuda kwekusanzwisisika mune zvinoreva.

/// Yakabatana mhando ye `<&[char] as Pattern<'a>>::Searcher`.
#[derive(Clone, Debug)]
pub struct CharSliceSearcher<'a, 'b>(<MultiCharEqPattern<&'b [char]> as Pattern<'a>>::Searcher);

unsafe impl<'a, 'b> Searcher<'a> for CharSliceSearcher<'a, 'b> {
    searcher_methods!(forward);
}

unsafe impl<'a, 'b> ReverseSearcher<'a> for CharSliceSearcher<'a, 'b> {
    searcher_methods!(reverse);
}

impl<'a, 'b> DoubleEndedSearcher<'a> for CharSliceSearcher<'a, 'b> {}

/// Kutsvaga kwemashini akaenzana nechero ipi ye (`char`] s mune chidimbu.
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find(&['l', 'l'] as &[_]), Some(2));
/// assert_eq!("Hello world".find(&['l', 'l'][..]), Some(2));
/// ```
impl<'a, 'b> Pattern<'a> for &'b [char] {
    pattern_methods!(CharSliceSearcher<'a, 'b>, MultiCharEqPattern, CharSliceSearcher);
}

/////////////////////////////////////////////////////////////////////////////
// Impl yeF: FnMut(char)-> bool
/////////////////////////////////////////////////////////////////////////////

/// Yakabatana mhando ye `<F as Pattern<'a>>::Searcher`.
#[derive(Clone)]
pub struct CharPredicateSearcher<'a, F>(<MultiCharEqPattern<F> as Pattern<'a>>::Searcher)
where
    F: FnMut(char) -> bool;

impl<F> fmt::Debug for CharPredicateSearcher<'_, F>
where
    F: FnMut(char) -> bool,
{
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("CharPredicateSearcher")
            .field("haystack", &self.0.haystack)
            .field("char_indices", &self.0.char_indices)
            .finish()
    }
}
unsafe impl<'a, F> Searcher<'a> for CharPredicateSearcher<'a, F>
where
    F: FnMut(char) -> bool,
{
    searcher_methods!(forward);
}

unsafe impl<'a, F> ReverseSearcher<'a> for CharPredicateSearcher<'a, F>
where
    F: FnMut(char) -> bool,
{
    searcher_methods!(reverse);
}

impl<'a, F> DoubleEndedSearcher<'a> for CharPredicateSearcher<'a, F> where F: FnMut(char) -> bool {}

/// Kutsvaga kwe [`char`] s kunoenderana nedanho rakapihwa.
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find(char::is_uppercase), Some(0));
/// assert_eq!("Hello world".find(|c| "aeiou".contains(c)), Some(1));
/// ```
impl<'a, F> Pattern<'a> for F
where
    F: FnMut(char) -> bool,
{
    pattern_methods!(CharPredicateSearcher<'a, F>, MultiCharEqPattern, CharPredicateSearcher);
}

/////////////////////////////////////////////////////////////////////////////
// Impl ye&&str
/////////////////////////////////////////////////////////////////////////////

/// Vamiriri kune `&str` impl.
impl<'a, 'b, 'c> Pattern<'a> for &'c &'b str {
    pattern_methods!(StrSearcher<'a, 'b>, |&s| s, |s| s);
}

/////////////////////////////////////////////////////////////////////////////
// Impl ye &str
/////////////////////////////////////////////////////////////////////////////

/// Isiri-kugovera substring yekutsvaga.
///
/// Tichabata iyo pateni `""` sekudzosa isina machisi pamuganhu wega wega.
///
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find("world"), Some(6));
/// ```
impl<'a, 'b> Pattern<'a> for &'b str {
    type Searcher = StrSearcher<'a, 'b>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> StrSearcher<'a, 'b> {
        StrSearcher::new(haystack, self)
    }

    /// Inotarisa kana iyo pateni inowirirana kumberi kwehuswa.
    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        haystack.as_bytes().starts_with(self.as_bytes())
    }

    /// Inobvisa iyo pateni kubva kumberi kwehuswa, kana ichienderana.
    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        if self.is_prefix_of(haystack) {
            // Kachengeteka: chivakashure chakangosimbiswa kuti chiripo.
            unsafe { Some(haystack.get_unchecked(self.as_bytes().len()..)) }
        } else {
            None
        }
    }

    /// Inotarisa kana iyo pateni inowirirana kuseri kwehuswa.
    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool {
        haystack.as_bytes().ends_with(self.as_bytes())
    }

    /// Inobvisa iyo pateni kubva kumashure kwehuswa, kana ichienderana.
    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str> {
        if self.is_suffix_of(haystack) {
            let i = haystack.len() - self.as_bytes().len();
            // Kachengeteka: chinongedzo chakangosimbiswa kuti chiripo.
            unsafe { Some(haystack.get_unchecked(..i)) }
        } else {
            None
        }
    }
}

/////////////////////////////////////////////////////////////////////////////
// Nzira mbiri nzira yekutsvagisa
/////////////////////////////////////////////////////////////////////////////

#[derive(Clone, Debug)]
/// Yakabatana mhando ye `<&str as Pattern<'a>>::Searcher`.
pub struct StrSearcher<'a, 'b> {
    haystack: &'a str,
    needle: &'b str,

    searcher: StrSearcherImpl,
}

#[derive(Clone, Debug)]
enum StrSearcherImpl {
    Empty(EmptyNeedle),
    TwoWay(TwoWaySearcher),
}

#[derive(Clone, Debug)]
struct EmptyNeedle {
    position: usize,
    end: usize,
    is_match_fw: bool,
    is_match_bw: bool,
}

impl<'a, 'b> StrSearcher<'a, 'b> {
    fn new(haystack: &'a str, needle: &'b str) -> StrSearcher<'a, 'b> {
        if needle.is_empty() {
            StrSearcher {
                haystack,
                needle,
                searcher: StrSearcherImpl::Empty(EmptyNeedle {
                    position: 0,
                    end: haystack.len(),
                    is_match_fw: true,
                    is_match_bw: true,
                }),
            }
        } else {
            StrSearcher {
                haystack,
                needle,
                searcher: StrSearcherImpl::TwoWay(TwoWaySearcher::new(
                    needle.as_bytes(),
                    haystack.len(),
                )),
            }
        }
    }
}

unsafe impl<'a, 'b> Searcher<'a> for StrSearcher<'a, 'b> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }

    #[inline]
    fn next(&mut self) -> SearchStep {
        match self.searcher {
            StrSearcherImpl::Empty(ref mut searcher) => {
                // tsono isina chinhu inoramba char imwe uye inowirirana tambo yega isina chinhu pakati pavo
                let is_match = searcher.is_match_fw;
                searcher.is_match_fw = !searcher.is_match_fw;
                let pos = searcher.position;
                match self.haystack[pos..].chars().next() {
                    _ if is_match => SearchStep::Match(pos, pos),
                    None => SearchStep::Done,
                    Some(ch) => {
                        searcher.position += ch.len_utf8();
                        SearchStep::Reject(pos, searcher.position)
                    }
                }
            }
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                // TwoWaySearcher inogadzira inoshanda *Match* indices iyo inopatsanurwa pamiganhu yechadhi sekureba kwazvinoita kuenderana uye kuti haystack uye tsono zviri pamutemo UTF-8 *Inoramba* kubva kualgorithm inogona kuwira pane chero maindices, asi isu tichavafamba nemaoko kuenda kunotevera hunhu muganho. , kuitira kuti vave utf-8 yakachengeteka.
                //
                //
                //
                //
                if searcher.position == self.haystack.len() {
                    return SearchStep::Done;
                }
                let is_long = searcher.memory == usize::MAX;
                match searcher.next::<RejectAndMatch>(
                    self.haystack.as_bytes(),
                    self.needle.as_bytes(),
                    is_long,
                ) {
                    SearchStep::Reject(a, mut b) => {
                        // skip kune inotevera char muganho
                        while !self.haystack.is_char_boundary(b) {
                            b += 1;
                        }
                        searcher.position = cmp::max(b, searcher.position);
                        SearchStep::Reject(a, b)
                    }
                    otherwise => otherwise,
                }
            }
        }
    }

    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        match self.searcher {
            StrSearcherImpl::Empty(..) => loop {
                match self.next() {
                    SearchStep::Match(a, b) => return Some((a, b)),
                    SearchStep::Done => return None,
                    SearchStep::Reject(..) => {}
                }
            },
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                let is_long = searcher.memory == usize::MAX;
                // nyora kunze `true` uye `false` kesi kukurudzira murongedzeri kuti anyatsogadzirisa iwo maviri kesi zvakasiyana.
                //
                if is_long {
                    searcher.next::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        true,
                    )
                } else {
                    searcher.next::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        false,
                    )
                }
            }
        }
    }
}

unsafe impl<'a, 'b> ReverseSearcher<'a> for StrSearcher<'a, 'b> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        match self.searcher {
            StrSearcherImpl::Empty(ref mut searcher) => {
                let is_match = searcher.is_match_bw;
                searcher.is_match_bw = !searcher.is_match_bw;
                let end = searcher.end;
                match self.haystack[..end].chars().next_back() {
                    _ if is_match => SearchStep::Match(end, end),
                    None => SearchStep::Done,
                    Some(ch) => {
                        searcher.end -= ch.len_utf8();
                        SearchStep::Reject(searcher.end, end)
                    }
                }
            }
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                if searcher.end == 0 {
                    return SearchStep::Done;
                }
                let is_long = searcher.memory == usize::MAX;
                match searcher.next_back::<RejectAndMatch>(
                    self.haystack.as_bytes(),
                    self.needle.as_bytes(),
                    is_long,
                ) {
                    SearchStep::Reject(mut a, b) => {
                        // skip kune inotevera char muganho
                        while !self.haystack.is_char_boundary(a) {
                            a -= 1;
                        }
                        searcher.end = cmp::min(a, searcher.end);
                        SearchStep::Reject(a, b)
                    }
                    otherwise => otherwise,
                }
            }
        }
    }

    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        match self.searcher {
            StrSearcherImpl::Empty(..) => loop {
                match self.next_back() {
                    SearchStep::Match(a, b) => return Some((a, b)),
                    SearchStep::Done => return None,
                    SearchStep::Reject(..) => {}
                }
            },
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                let is_long = searcher.memory == usize::MAX;
                // nyora `true` uye `false`, sa `next_match`
                if is_long {
                    searcher.next_back::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        true,
                    )
                } else {
                    searcher.next_back::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        false,
                    )
                }
            }
        }
    }
}

/// Iyo yemukati mamiriro enzira mbiri-nzira substring yekutsvaga algorithm.
#[derive(Clone, Debug)]
struct TwoWaySearcher {
    // constants
    /// yakakosha factorization index
    crit_pos: usize,
    /// yakakosha factorization index yeiyo yakadzoserwa tsono
    crit_pos_back: usize,
    period: usize,
    /// `byteset` kuwedzera (kwete chikamu chenzira mbiri algorithm);
    /// iri 64-bit "fingerprint" apo yega yega seti `j` inoenderana ne (byte&63)==j iripo mune tsono.
    ///
    byteset: u64,

    // variables
    position: usize,
    end: usize,
    /// index mune tsono yatakatarisana nayo
    memory: usize,
    /// index kupinda mune tsono mushure meizvozvo isu tanga tatarisana
    memory_back: usize,
}

/*
    This is the Two-Way search algorithm, which was introduced in the paper:
    Crochemore, M., Perrin, D., 1991, Two-way string-matching, Journal of the ACM 38(3):651-675.

    Here's some background information.

    A *word* is a string of symbols. The *length* of a word should be a familiar
    notion, and here we denote it for any word x by |x|.
    (We also allow for the possibility of the *empty word*, a word of length zero).

    If x is any non-empty word, then an integer p with 0 < p <= |x| is said to be a
    *period* for x iff for all i with 0 <= i <= |x| - p - 1, we have x[i] == x[i+p].
    For example, both 1 and 2 are periods for the string "aa". As another example,
    the only period of the string "abcd" is 4.

    We denote by period(x) the *smallest* period of x (provided that x is non-empty).
    This is always well-defined since every non-empty word x has at least one period,
    |x|. We sometimes call this *the period* of x.

    If u, v and x are words such that x = uv, where uv is the concatenation of u and
    v, then we say that (u, v) is a *factorization* of x.

    Let (u, v) be a factorization for a word x. Then if w is a non-empty word such
    that both of the following hold

      - either w is a suffix of u or u is a suffix of w
      - either w is a prefix of v or v is a prefix of w

    then w is said to be a *repetition* for the factorization (u, v).

    Just to unpack this, there are four possibilities here. Let w = "abc". Then we
    might have:

      - w is a suffix of u and w is a prefix of v. ex: ("lolabc", "abcde")
      - w is a suffix of u and v is a prefix of w. ex: ("lolabc", "ab")
      - u is a suffix of w and w is a prefix of v. ex: ("bc", "abchi")
      - u is a suffix of w and v is a prefix of w. ex: ("bc", "a")

    Note that the word vu is a repetition for any factorization (u,v) of x = uv,
    so every factorization has at least one repetition.

    If x is a string and (u, v) is a factorization for x, then a *local period* for
    (u, v) is an integer r such that there is some word w such that |w| = r and w is
    a repetition for (u, v).

    We denote by local_period(u, v) the smallest local period of (u, v). We sometimes
    call this *the local period* of (u, v). Provided that x = uv is non-empty, this
    is well-defined (because each non-empty word has at least one factorization, as
    noted above).

    It can be proven that the following is an equivalent definition of a local period
    for a factorization (u, v): any positive integer r such that x[i] == x[i+r] for
    all i such that |u| - r <= i <= |u| - 1 and such that both x[i] and x[i+r] are
    defined. (i.e., i > 0 and i + r < |x|).

    Using the above reformulation, it is easy to prove that

        1 <= local_period(u, v) <= period(uv)

    A factorization (u, v) of x such that local_period(u,v) = period(x) is called a
    *critical factorization*.

    The algorithm hinges on the following theorem, which is stated without proof:

    **Critical Factorization Theorem** Any word x has at least one critical
    factorization (u, v) such that |u| < period(x).

    The purpose of maximal_suffix is to find such a critical factorization.

    If the period is short, compute another factorization x = u' v' to use
    for reverse search, chosen instead so that |v'| < period(x).

*/
impl TwoWaySearcher {
    fn new(needle: &[u8], end: usize) -> TwoWaySearcher {
        let (crit_pos_false, period_false) = TwoWaySearcher::maximal_suffix(needle, false);
        let (crit_pos_true, period_true) = TwoWaySearcher::maximal_suffix(needle, true);

        let (crit_pos, period) = if crit_pos_false > crit_pos_true {
            (crit_pos_false, period_false)
        } else {
            (crit_pos_true, period_true)
        };

        // Tsananguro inoverengwa chaizvo yezviri kuitika pano inogona kuwanikwa muCrocochemore uye bhuku raRytter "Text Algorithms", ch 13.
        // Kunyanya ona kodhi ye "Algorithm CP" pane p.
        // 323.
        //
        // Chii chirikuitika isu tine chakakomba factorization (u, v) chetsono, uye isu tinoda kuona kuti iwe uri chirevo che&v [.. nguva].
        // Kana zvirizvo, tinoshandisa "Algorithm CP1".
        // Zvikasadaro isu tinoshandisa "Algorithm CP2", iyo yakagadzirisirwa iyo iyo nguva yetsono yakakura.
        //
        //
        if needle[..crit_pos] == needle[period..period + crit_pos] {
            // ipfupi nguva kesi-iyo nguva yakanyatso kuenzanisa yakasarudzika yakakosha factorization yeiyo yakadzoserwa tsono x=u 'v' kupi | v '|<period(x).
            //
            // Izvi zvinomhanyiswa nenguva iri kuzivikanwa kare.
            // Ziva kuti kesi senge x= "acba" inogona kuburitsirwa kumberi (crit_pos=1, period=3) ichiri kuumbiridzwa neinofungidzirwa nguva yekumashure (crit_pos=2, period=2).
            // Isu tinoshandisa yakapihwa yakadzoserwa factorization asi chengeta iyo chaiyo nguva.
            //
            //
            //
            //
            let crit_pos_back = needle.len()
                - cmp::max(
                    TwoWaySearcher::reverse_maximal_suffix(needle, period, false),
                    TwoWaySearcher::reverse_maximal_suffix(needle, period, true),
                );

            TwoWaySearcher {
                crit_pos,
                crit_pos_back,
                period,
                byteset: Self::byteset_create(&needle[..period]),

                position: 0,
                end,
                memory: 0,
                memory_back: needle.len(),
            }
        } else {
            // yakareba nguva kesi-isu tine fungidziro kune iyo chaiyo nguva, uye usashandise kuyeuka.
            //
            //
            // Inofungidzirwa iyo nguva neakaderera akasungwa max(|u|, |v|) + 1.
            // Iyo yakakosha factorization inoshanda kushandisa kune ese ari kumberi uye ekudzosera kumashure kutsvaga.
            //

            TwoWaySearcher {
                crit_pos,
                crit_pos_back: crit_pos,
                period: cmp::max(crit_pos, needle.len() - crit_pos) + 1,
                byteset: Self::byteset_create(needle),

                position: 0,
                end,
                memory: usize::MAX, // Dummy kukosha kuratidza kuti nguva yacho yareba
                memory_back: usize::MAX,
            }
        }
    }

    #[inline]
    fn byteset_create(bytes: &[u8]) -> u64 {
        bytes.iter().fold(0, |a, &b| (1 << (b & 0x3f)) | a)
    }

    #[inline]
    fn byteset_contains(&self, byte: u8) -> bool {
        (self.byteset >> ((byte & 0x3f) as usize)) & 1 != 0
    }

    // Imwe yemafungiro makuru eTwo-Nzira ndeyekuti isu tinokonzeresa tsono muzvikamu zviviri, (u, v), uye totanga kuyedza kutsvaga v mune iyo haystack nekutarisa kuruboshwe kurudyi.
    // Kana v vachienderana, tinoedza kukufananidza nekutarisa kurudyi kuruboshwe.
    // Kusvika papi patinogona kusvetuka kana tikasangana nemisikanzwa zvese zvinoenderana nenyaya yekuti (u, v) chinhu chakakosha chinokonzeresa tsono.
    //
    //
    #[inline]
    fn next<S>(&mut self, haystack: &[u8], needle: &[u8], long_period: bool) -> S::Output
    where
        S: TwoWayStrategy,
    {
        // `next()` inoshandisa `self.position` seyakakumbira
        let old_pos = self.position;
        let needle_last = needle.len() - 1;
        'search: loop {
            // Tarisa uone kuti isu tine nzvimbo yekutsvaga munzvimbo + tsono_last haigone kufashukira kana tichifungidzira zvidimbu zvakasungwa neisize renji.
            //
            //
            let tail_byte = match haystack.get(self.position + needle_last) {
                Some(&b) => b,
                None => {
                    self.position = haystack.len();
                    return S::rejecting(old_pos, self.position);
                }
            };

            if S::use_early_reject() && old_pos != self.position {
                return S::rejecting(old_pos, self.position);
            }

            // Kurumidza kusvetuka nezvikamu zvikuru zvisina hukama neyedu substring
            if !self.byteset_contains(tail_byte) {
                self.position += needle.len();
                if !long_period {
                    self.memory = 0;
                }
                continue 'search;
            }

            // Tarisa uone kana chikamu chakakodzera chetsono chichienderana
            let start =
                if long_period { self.crit_pos } else { cmp::max(self.crit_pos, self.memory) };
            for i in start..needle.len() {
                if needle[i] != haystack[self.position + i] {
                    self.position += i - self.crit_pos + 1;
                    if !long_period {
                        self.memory = 0;
                    }
                    continue 'search;
                }
            }

            // Ona kana chikamu chekuruboshwe chetsono chichienderana
            let start = if long_period { 0 } else { self.memory };
            for i in (start..self.crit_pos).rev() {
                if needle[i] != haystack[self.position + i] {
                    self.position += self.period;
                    if !long_period {
                        self.memory = needle.len() - self.period;
                    }
                    continue 'search;
                }
            }

            // Tawana mutambo!
            let match_pos = self.position;

            // Note: wedzera self.period pachinzvimbo che needle.len() kuti uve nemitambo inopindirana
            self.position += needle.len();
            if !long_period {
                self.memory = 0; // seta ku needle.len(), self.period yemitambo inopindirana
            }

            return S::matching(match_pos, match_pos + needle.len());
        }
    }

    // Inotevera mazano mu `next()`.
    //
    // Idzo tsananguro dzakaenzana, iine period(x) = period(reverse(x)) uye local_period(u, v) = local_period(reverse(v), reverse(u)), saka kana (u, v) yakakosha kuisa pfungwa, ndizvo zvakaitawo (reverse(v), reverse(u)).
    //
    //
    // Yenyaya iri kumashure isu takanyora yakakosha factorization x=u 'v' (munda `crit_pos_back`).Tinoda | u |<period(x) yeiyo kesi yekumberi uye nekudaro | v '|<period(x) yekudzosera kumashure.
    //
    // Kuti titsvage tichidzoka neshure kwehuswa, isu tinotsvaga kumberi kuburikidza neiyo yakadzoserwa haystack ine inodzoserwa tsono, inofanidza kutanga u 'uye v'.
    //
    //
    //
    //
    #[inline]
    fn next_back<S>(&mut self, haystack: &[u8], needle: &[u8], long_period: bool) -> S::Output
    where
        S: TwoWayStrategy,
    {
        // `next_back()` inoshandisa `self.end` seyakakara-kuitira kuti `next()` ne `next_back()` vazvimiririre.
        //
        let old_end = self.end;
        'search: loop {
            // Tarisa kuti tine nzvimbo yekutsvaga pakupedzisira, needle.len() ichaputira kana pasisina imwe nzvimbo, asi nekuda kwehuremu hwehurefu haigone kuputira iyo yese kudzoka muhurefu hwehuswa.
            //
            //
            //
            let front_byte = match haystack.get(self.end.wrapping_sub(needle.len())) {
                Some(&b) => b,
                None => {
                    self.end = 0;
                    return S::rejecting(0, old_end);
                }
            };

            if S::use_early_reject() && old_end != self.end {
                return S::rejecting(self.end, old_end);
            }

            // Kurumidza kusvetuka nezvikamu zvikuru zvisina hukama neyedu substring
            if !self.byteset_contains(front_byte) {
                self.end -= needle.len();
                if !long_period {
                    self.memory_back = needle.len();
                }
                continue 'search;
            }

            // Ona kana chikamu chekuruboshwe chetsono chichienderana
            let crit = if long_period {
                self.crit_pos_back
            } else {
                cmp::min(self.crit_pos_back, self.memory_back)
            };
            for i in (0..crit).rev() {
                if needle[i] != haystack[self.end - needle.len() + i] {
                    self.end -= self.crit_pos_back - i;
                    if !long_period {
                        self.memory_back = needle.len();
                    }
                    continue 'search;
                }
            }

            // Tarisa uone kana chikamu chakakodzera chetsono chichienderana
            let needle_end = if long_period { needle.len() } else { self.memory_back };
            for i in self.crit_pos_back..needle_end {
                if needle[i] != haystack[self.end - needle.len() + i] {
                    self.end -= self.period;
                    if !long_period {
                        self.memory_back = self.period;
                    }
                    continue 'search;
                }
            }

            // Tawana mutambo!
            let match_pos = self.end - needle.len();
            // Note: sub self.period pachinzvimbo che needle.len() kuve nemitambo inopindirana
            self.end -= needle.len();
            if !long_period {
                self.memory_back = needle.len();
            }

            return S::matching(match_pos, match_pos + needle.len());
        }
    }

    // Komputa yakanyanya kukwana suffix ye `arr`.
    //
    // Iyo yakakwenenzverwa nechimbichimbi inogona kuitika yakakosha factorization (u, v) ye `arr`.
    //
    // Returns (`i`, `p`) uko `i` iri yekutanga index ye v uye `p` inguva ye v.
    //
    // `order_greater` inosarudza kana rexical odhiyo iri `<` kana `>`.
    // Ose maodha anofanirwa kuverengerwa-kuodha neiyo hombe `i` inopa yakakosha factorization.
    //
    //
    // Kwenguva refu kesi, iyo inoguma nguva haina kunyatsoita (ipfupi).
    //
    #[inline]
    fn maximal_suffix(arr: &[u8], order_greater: bool) -> (usize, usize) {
        let mut left = 0; // Inoenderana nei ini mupepa
        let mut right = 1; // Inoenderana na j mupepa
        let mut offset = 0; // Inoenderana na k mupepa, asi kutanga na0
        // kuenzanisa 0-based indexing.
        let mut period = 1; // Inoenderana nep mupepa

        while let Some(&a) = arr.get(right + offset) {
            // `left` ichave inbound kana `right` iri.
            let b = arr[left + offset];
            if (a < b && !order_greater) || (a > b && order_greater) {
                // Suffix idiki, nguva izere chivakashure kusvika zvino.
                right += offset + 1;
                offset = 0;
                period = right - left;
            } else if a == b {
                // Kufambira mberi kuburikidza nekudzokorora kwenguva iriko.
                if offset + 1 == period {
                    right += offset + 1;
                    offset = 0;
                } else {
                    offset += 1;
                }
            } else {
                // Suffix yakakura, tanga pamusoro kubva kwazvino nzvimbo.
                left = right;
                right += 1;
                offset = 0;
                period = 1;
            }
        }
        (left, period)
    }

    // Komputa iyo yakakwenenzverwa chirevo chekuseri kwe `arr`.
    //
    // Iyo yakakwenenzverwa chinokwanisika inogona kuitika yakakosha factorization (u ', v') ye `arr`.
    //
    // Inodzorera `i` uko `i` iri yekutanga index ye v ', kubva kumashure;
    // inodzoka nekukasira kana nguva ye `known_period` yasvika.
    //
    // `order_greater` inosarudza kana rexical odhiyo iri `<` kana `>`.
    // Ose maodha anofanirwa kuverengerwa-kuodha neiyo hombe `i` inopa yakakosha factorization.
    //
    //
    // Kwenguva refu kesi, iyo inoguma nguva haina kunyatsoita (ipfupi).
    fn reverse_maximal_suffix(arr: &[u8], known_period: usize, order_greater: bool) -> usize {
        let mut left = 0; // Inoenderana nei ini mupepa
        let mut right = 1; // Inoenderana na j mupepa
        let mut offset = 0; // Inoenderana na k mupepa, asi kutanga na0
        // kuenzanisa 0-based indexing.
        let mut period = 1; // Inoenderana nep mupepa
        let n = arr.len();

        while right + offset < n {
            let a = arr[n - (1 + right + offset)];
            let b = arr[n - (1 + left + offset)];
            if (a < b && !order_greater) || (a > b && order_greater) {
                // Suffix idiki, nguva izere chivakashure kusvika zvino.
                right += offset + 1;
                offset = 0;
                period = right - left;
            } else if a == b {
                // Kufambira mberi kuburikidza nekudzokorora kwenguva iriko.
                if offset + 1 == period {
                    right += offset + 1;
                    offset = 0;
                } else {
                    offset += 1;
                }
            } else {
                // Suffix yakakura, tanga pamusoro kubva kwazvino nzvimbo.
                left = right;
                right += 1;
                offset = 0;
                period = 1;
            }
            if period == known_period {
                break;
            }
        }
        debug_assert!(period <= known_period);
        left
    }
}

// TwoWayStr Strategy inobvumira iyo algorithm kuti isvetuke isiri-machisi nekukurumidza sezvazvinogona, kana kuti ishande mumodi iyo painoburitsa Zvinorambwa nekukurumidza.
//
trait TwoWayStrategy {
    type Output;
    fn use_early_reject() -> bool;
    fn rejecting(a: usize, b: usize) -> Self::Output;
    fn matching(a: usize, b: usize) -> Self::Output;
}

/// Darika kuti uenzanise zvikamu nekukurumidza sezvazvinogona
enum MatchOnly {}

impl TwoWayStrategy for MatchOnly {
    type Output = Option<(usize, usize)>;

    #[inline]
    fn use_early_reject() -> bool {
        false
    }
    #[inline]
    fn rejecting(_a: usize, _b: usize) -> Self::Output {
        None
    }
    #[inline]
    fn matching(a: usize, b: usize) -> Self::Output {
        Some((a, b))
    }
}

/// Emit Inoramba nguva dzose
enum RejectAndMatch {}

impl TwoWayStrategy for RejectAndMatch {
    type Output = SearchStep;

    #[inline]
    fn use_early_reject() -> bool {
        true
    }
    #[inline]
    fn rejecting(a: usize, b: usize) -> Self::Output {
        SearchStep::Reject(a, b)
    }
    #[inline]
    fn matching(a: usize, b: usize) -> Self::Output {
        SearchStep::Match(a, b)
    }
}