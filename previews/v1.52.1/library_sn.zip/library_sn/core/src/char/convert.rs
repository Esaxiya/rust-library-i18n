//! Hunhu kutendeuka.

use crate::convert::TryFrom;
use crate::fmt;
use crate::mem::transmute;
use crate::str::FromStr;

use super::MAX;

/// Inoshandura `u32` kuita `char`.
///
/// Ziva kuti ese [`char`] s anoshanda [`u32`] s, uye anogona kukandwa kune imwechete ne
/// `as`:
///
/// ```
/// let c = '💯';
/// let i = c as u32;
///
/// assert_eq!(128175, i);
/// ```
///
/// Zvisinei, zvinopesana hazvisi zvechokwadi: hazvisi zvese zvinoshanda [`u32`] s zvinoshanda [`char`] s.
/// `from_u32()` inodzosera `None` kana iko kuiswa kusiri iko kukosha kwe [`char`].
///
/// Kune isina kuchengetedzeka vhezheni yeiri basa iro rinofuratira macheki aya, ona [`from_u32_unchecked`].
///
///
/// # Examples
///
/// Kushandiswa kwekutanga:
///
/// ```
/// use std::char;
///
/// let c = char::from_u32(0x2764);
///
/// assert_eq!(Some('❤'), c);
/// ```
///
/// Kudzosera `None` kana iko kuiswa kusiri kwechokwadi [`char`]:
///
/// ```
/// use std::char;
///
/// let c = char::from_u32(0x110000);
///
/// assert_eq!(None, c);
/// ```
///
#[doc(alias = "chr")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_u32(i: u32) -> Option<char> {
    char::try_from(i).ok()
}

/// Inoshandura `u32` kuita `char`, ichiregeredza huchokwadi.
///
/// Ziva kuti ese [`char`] s anoshanda [`u32`] s, uye anogona kukandwa kune imwechete ne
/// `as`:
///
/// ```
/// let c = '💯';
/// let i = c as u32;
///
/// assert_eq!(128175, i);
/// ```
///
/// Zvisinei, zvinopesana hazvisi zvechokwadi: hazvisi zvese zvinoshanda [`u32`] s zvinoshanda [`char`] s.
/// `from_u32_unchecked()` vanofuratira izvi, vokanda bofu ku [`char`], pamwe vachigadzira isiriyo.
///
///
/// # Safety
///
/// Iri basa harina kuchengeteka, nekuti rinogona kuvaka zvisirizvo `char` kukosha.
///
/// Kuti uwane yakachengeteka vhezheni yeiri basa, ona iyo [`from_u32`] basa.
///
/// # Examples
///
/// Kushandiswa kwekutanga:
///
/// ```
/// use std::char;
///
/// let c = unsafe { char::from_u32_unchecked(0x2764) };
///
/// assert_eq!('❤', c);
/// ```
#[inline]
#[stable(feature = "char_from_unchecked", since = "1.5.0")]
pub unsafe fn from_u32_unchecked(i: u32) -> char {
    // KUCHENGETEKA: iye anofona anofanira kuvimbisa kuti `i` ndeyechokwadi char kukosha.
    if cfg!(debug_assertions) { char::from_u32(i).unwrap() } else { unsafe { transmute(i) } }
}

#[stable(feature = "char_convert", since = "1.13.0")]
impl From<char> for u32 {
    /// Inoshandura [`char`] kuita [`u32`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = 'c';
    /// let u = u32::from(c);
    /// assert!(4 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        c as u32
    }
}

#[stable(feature = "more_char_conversions", since = "1.51.0")]
impl From<char> for u64 {
    /// Inoshandura [`char`] kuita [`u64`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = '👤';
    /// let u = u64::from(c);
    /// assert!(8 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        // Iyo char inokandirwa kune kukosha kweiyo kodhi kodhi, uye zero-yakawedzeredzwa kusvika makumi matanhatu neshanu.
        // Ona [https://doc.rust-lang.org/reference/expressions/operator-expr.html#semantics]
        c as u64
    }
}

#[stable(feature = "more_char_conversions", since = "1.51.0")]
impl From<char> for u128 {
    /// Inoshandura [`char`] kuita [`u128`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = '⚙';
    /// let u = u128::from(c);
    /// assert!(16 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        // Iyo char inokandirwa kune kukosha kweiyo kodhi kodhi, uye zero-yakawedzeredzwa kusvika 128 bit.
        // Ona [https://doc.rust-lang.org/reference/expressions/operator-expr.html#semantics]
        c as u128
    }
}

/// Mepu byte mu0x00 ..=0xFF kusvika ku `char` ine kodhi kodhi ine kukosha kwakafanana, muU + 0000 ..=U + 00FF.
///
/// Unicode yakagadzirirwa zvekuti izvi zvinobudirira kusarudza mabheti nehunhu encoding iyo IANA inodaidza ISO-8859-1.
/// Iyi encoding inoenderana neASIIII.
///
/// Ziva kuti izvi zvakasiyana ne ISO/IEC 8859-1 aka
/// ISO 8859-1 (ine imwechete hyphen), iyo inosiya imwe "blanks", byte tsika dzisina kupihwa chero hunhu.
/// ISO-8859-1 (iyo IANA imwe) inovapa iwo ma C0 uye C1 makodhi ekudzora.
///
/// Ziva kuti izvi *zvakare* zvakasiyana neWindows-1252 aka
/// kodhi peji 1252, inova superset ISO/IEC 8859-1 iyo inopa mamwe (kwete ese!) mabhii ekunyorwa uye mavara akasiyana echiLatin.
///
/// Kuvhiringidza zvinhu kumberi, [on the Web](https://encoding.spec.whatwg.org/) `ascii`, `iso-8859-1`, uye `windows-1252` zvese zvinongedzo zve superset yeWindows-1252 iyo inozadza mabara akasara neakaenzana e C0 uye C1 macode ekudzora.
///
///
///
///
///
#[stable(feature = "char_convert", since = "1.13.0")]
impl From<u8> for char {
    /// Inoshandura [`u8`] kuita [`char`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let u = 32 as u8;
    /// let c = char::from(u);
    /// assert!(4 == mem::size_of_val(&c))
    /// ```
    #[inline]
    fn from(i: u8) -> Self {
        i as char
    }
}

/// Iko kukanganisa uko kunogona kudzoreredzwa kana uchigadzirisa char.
#[stable(feature = "char_from_str", since = "1.20.0")]
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct ParseCharError {
    kind: CharErrorKind,
}

impl ParseCharError {
    #[unstable(
        feature = "char_error_internals",
        reason = "this method should not be available publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            CharErrorKind::EmptyString => "cannot parse char from empty string",
            CharErrorKind::TooManyChars => "too many characters in string",
        }
    }
}

#[derive(Copy, Clone, Debug, PartialEq, Eq)]
enum CharErrorKind {
    EmptyString,
    TooManyChars,
}

#[stable(feature = "char_from_str", since = "1.20.0")]
impl fmt::Display for ParseCharError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}

#[stable(feature = "char_from_str", since = "1.20.0")]
impl FromStr for char {
    type Err = ParseCharError;

    #[inline]
    fn from_str(s: &str) -> Result<Self, Self::Err> {
        let mut chars = s.chars();
        match (chars.next(), chars.next()) {
            (None, _) => Err(ParseCharError { kind: CharErrorKind::EmptyString }),
            (Some(c), None) => Ok(c),
            _ => Err(ParseCharError { kind: CharErrorKind::TooManyChars }),
        }
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl TryFrom<u32> for char {
    type Error = CharTryFromError;

    #[inline]
    fn try_from(i: u32) -> Result<Self, Self::Error> {
        if (i > MAX as u32) || (i >= 0xD800 && i <= 0xDFFF) {
            Err(CharTryFromError(()))
        } else {
            // KUCHENGETEKA: kuongororwa kuti iri pamutemo unicode kukosha
            Ok(unsafe { transmute(i) })
        }
    }
}

/// Rudzi rwekukanganisa rwakadzoka kana shanduko kubva ku u32 kuenda kuchar ikakundikana.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct CharTryFromError(());

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for CharTryFromError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        "converted integer out of range for `char`".fmt(f)
    }
}

/// Inoshandura digit mune yakapihwa radix kuita `char`.
///
/// A 'radix' pano dzimwe nguva inonziwo 'base'.
/// Radix yezviviri inoratidza nhamba yebhinari, radix yegumi, decimal, uye radix yegumi nenhanhatu, hexadecimal, kupa mamwe maitiro akafanana.
///
/// Zvekupokana radices zvinotsigirwa.
///
/// `from_digit()` inodzosa `None` kana iko kuiswa isiri digit mune yakapihwa radix.
///
/// # Panics
///
/// Panics kana ikapihwa radix yakakura kupfuura makumi matatu.
///
/// # Examples
///
/// Kushandiswa kwekutanga:
///
/// ```
/// use std::char;
///
/// let c = char::from_digit(4, 10);
///
/// assert_eq!(Some('4'), c);
///
/// // Decimal 11 idhijiti imwe mune base 16
/// let c = char::from_digit(11, 16);
///
/// assert_eq!(Some('b'), c);
/// ```
///
/// Kudzosera `None` kana iko kuiswa isiri digit:
///
/// ```
/// use std::char;
///
/// let c = char::from_digit(20, 10);
///
/// assert_eq!(None, c);
/// ```
///
/// Kupfuura radix yakakura, ichikonzera panic:
///
/// ```should_panic
/// use std::char;
///
/// // this panics
/// let c = char::from_digit(1, 37);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_digit(num: u32, radix: u32) -> Option<char> {
    if radix > 36 {
        panic!("from_digit: radix is too high (maximum 36)");
    }
    if num < radix {
        let num = num as u8;
        if num < 10 { Some((b'0' + num) as char) } else { Some((b'a' + num - 10) as char) }
    } else {
        None
    }
}