//! impl char char {}

use crate::intrinsics::likely;
use crate::slice;
use crate::str::from_utf8_unchecked_mut;
use crate::unicode::printable::is_printable;
use crate::unicode::{self, conversions};

use super::*;

#[lang = "char"]
impl char {
    /// Iyo yepamusoro inoshanda kodhi poindi iyo `char` inogona kuve nayo.
    ///
    /// `char` i [Unicode Scalar Value], zvinoreva kuti i [Code Point], asi chete mune imwe nhanho.
    /// `MAX` ndiyo yepamusoro kodhi kodhi ndeyechokwadi [Unicode Scalar Value].
    ///
    /// [Unicode Scalar Value]: http://www.unicode.org/glossary/#unicode_scalar_value
    /// [Code Point]: http://www.unicode.org/glossary/#code_point
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const MAX: char = '\u{10ffff}';

    /// `U+FFFD REPLACEMENT CHARACTER` () inoshandiswa mu Unicode kumiririra kukanganisa kwekugadzirisa.
    ///
    /// Izvo zvinogona kuitika, semuenzaniso, kana uchipa yakaipa-yakaumbwa UTF-8 mabheti ku [`String::from_utf8_lossy`](string/struct.String.html#method.from_utf8_lossy).
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const REPLACEMENT_CHARACTER: char = '\u{FFFD}';

    /// Iyo vhezheni ye [Unicode](http://www.unicode.org/) iyo iyo Unicode zvikamu zve `char` uye `str` nzira zvinovakirwa pairi.
    ///
    /// Shanduro nyowani dze Unicode dzinoburitswa nguva dzose uye zvichizoteera nzira dzese mune raibhurari yakajairwa zvichienderana ne Unicode inogadziridzwa.
    /// Naizvozvo hunhu hwedzimwe nzira dze `char` uye `str` uye kukosha kweiyi inogara ichichinja nekufamba kwenguva.
    /// Izvi * hazvifungidzirwe sekuchinja kuri kutyora.
    ///
    /// Iyo vhezheni yekuverenga scheme yakatsanangurwa mu [Unicode 11.0 or later, Section 3.1 Versions of the Unicode Standard](https://www.unicode.org/versions/Unicode11.0.0/ch03.pdf#page=4).
    ///
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const UNICODE_VERSION: (u8, u8, u8) = crate::unicode::UNICODE_VERSION;

    /// Inogadzira iterator pamusoro peiyo UTF-16 encoded kodhi kodhi mu `iter`, ichidzosera vasina kubhadharwa ma surrogates se`Err`s.
    ///
    ///
    /// # Examples
    ///
    /// Kushandiswa kwekutanga:
    ///
    /// ```
    /// use std::char::decode_utf16;
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///         .map(|r| r.map_err(|e| e.unpaired_surrogate()))
    ///         .collect::<Vec<_>>(),
    ///     vec![
    ///         Ok('𝄞'),
    ///         Ok('m'), Ok('u'), Ok('s'),
    ///         Err(0xDD1E),
    ///         Ok('i'), Ok('c'),
    ///         Err(0xD834)
    ///     ]
    /// );
    /// ```
    ///
    /// Yakarasika dhodhi inogona kuwanikwa nekutsiva `Err` mhedzisiro neinotsiva hunhu:
    ///
    /// ```
    /// use std::char::{decode_utf16, REPLACEMENT_CHARACTER};
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///        .map(|r| r.unwrap_or(REPLACEMENT_CHARACTER))
    ///        .collect::<String>(),
    ///     "𝄞mus�ic�"
    /// );
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn decode_utf16<I: IntoIterator<Item = u16>>(iter: I) -> DecodeUtf16<I::IntoIter> {
        super::decode::decode_utf16(iter)
    }

    /// Inoshandura `u32` kuita `char`.
    ///
    /// Ziva kuti ese `char`s anoshanda [`u32`] s, uye anogona kukandwa kune imwe ne
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// Zvisinei, zvinopesana hazvisi zvechokwadi: hazvisi zvese zvinoshanda [`u32`] s zvinoshanda`char`s.
    /// `from_u32()` inodzosera `None` kana iko kuiswa kusiri iko kukosha kwe `char`.
    ///
    /// Kune isina kuchengetedzeka vhezheni yeiri basa iro rinofuratira macheki aya, ona [`from_u32_unchecked`].
    ///
    ///
    /// [`from_u32_unchecked`]: #method.from_u32_unchecked
    ///
    /// # Examples
    ///
    /// Kushandiswa kwekutanga:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x2764);
    ///
    /// assert_eq!(Some('❤'), c);
    /// ```
    ///
    /// Kudzosera `None` kana iko kuiswa kusiri kwechokwadi `char`:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x110000);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_u32(i: u32) -> Option<char> {
        super::convert::from_u32(i)
    }

    /// Inoshandura `u32` kuita `char`, ichiregeredza huchokwadi.
    ///
    /// Ziva kuti ese `char`s anoshanda [`u32`] s, uye anogona kukandwa kune imwe ne
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// Zvisinei, zvinopesana hazvisi zvechokwadi: hazvisi zvese zvinoshanda [`u32`] s zvinoshanda`char`s.
    /// `from_u32_unchecked()` vanofuratira izvi, vokanda bofu ku `char`, pamwe vachigadzira isiriyo.
    ///
    ///
    /// # Safety
    ///
    /// Iri basa harina kuchengeteka, nekuti rinogona kuvaka zvisirizvo `char` kukosha.
    ///
    /// Kuti uwane yakachengeteka vhezheni yeiri basa, ona iyo [`from_u32`] basa.
    ///
    /// [`from_u32`]: #method.from_u32
    ///
    /// # Examples
    ///
    /// Kushandiswa kwekutanga:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = unsafe { char::from_u32_unchecked(0x2764) };
    ///
    /// assert_eq!('❤', c);
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub unsafe fn from_u32_unchecked(i: u32) -> char {
        // Kachengeteka: chibvumirano chekuchengetedza chinofanira kuchengetedzwa neanodana.
        unsafe { super::convert::from_u32_unchecked(i) }
    }

    /// Inoshandura digit mune yakapihwa radix kuita `char`.
    ///
    /// A 'radix' pano dzimwe nguva inonziwo 'base'.
    /// Radix yezviviri inoratidza nhamba yebhinari, radix yegumi, decimal, uye radix yegumi nenhanhatu, hexadecimal, kupa mamwe maitiro akafanana.
    ///
    /// Zvekupokana radices zvinotsigirwa.
    ///
    /// `from_digit()` inodzosa `None` kana iko kuiswa isiri digit mune yakapihwa radix.
    ///
    /// # Panics
    ///
    /// Panics kana ikapihwa radix yakakura kupfuura makumi matatu.
    ///
    /// # Examples
    ///
    /// Kushandiswa kwekutanga:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(4, 10);
    ///
    /// assert_eq!(Some('4'), c);
    ///
    /// // Decimal 11 idhijiti imwe mune base 16
    /// let c = char::from_digit(11, 16);
    ///
    /// assert_eq!(Some('b'), c);
    /// ```
    ///
    /// Kudzosera `None` kana iko kuiswa isiri digit:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(20, 10);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    /// Kupfuura radix yakakura, ichikonzera panic:
    ///
    /// ```should_panic
    /// use std::char;
    ///
    /// // this panics
    /// char::from_digit(1, 37);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_digit(num: u32, radix: u32) -> Option<char> {
        super::convert::from_digit(num, radix)
    }

    /// Inotarisa kana `char` iri digit mune yakapihwa radix.
    ///
    /// A 'radix' pano dzimwe nguva inonziwo 'base'.
    /// Radix yezviviri inoratidza nhamba yebhinari, radix yegumi, decimal, uye radix yegumi nenhanhatu, hexadecimal, kupa mamwe maitiro akafanana.
    ///
    /// Zvekupokana radices zvinotsigirwa.
    ///
    /// Kuenzaniswa ne [`is_numeric()`], iri basa rinongoziva mavara `0-9`, `a-z` uye `A-Z`.
    ///
    /// 'Digit' inotsanangurwa kuve chete anotevera mavara:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// Kuti uwane nzwisiso yakazara ye 'digit', ona [`is_numeric()`].
    ///
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Panics
    ///
    /// Panics kana ikapihwa radix yakakura kupfuura makumi matatu.
    ///
    /// # Examples
    ///
    /// Kushandiswa kwekutanga:
    ///
    /// ```
    /// assert!('1'.is_digit(10));
    /// assert!('f'.is_digit(16));
    /// assert!(!'f'.is_digit(10));
    /// ```
    ///
    /// Kupfuura radix yakakura, ichikonzera panic:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.is_digit(37);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_digit(self, radix: u32) -> bool {
        self.to_digit(radix).is_some()
    }

    /// Inoshandura `char` kuve digit mune yakapihwa radix.
    ///
    /// A 'radix' pano dzimwe nguva inonziwo 'base'.
    /// Radix yezviviri inoratidza nhamba yebhinari, radix yegumi, decimal, uye radix yegumi nenhanhatu, hexadecimal, kupa mamwe maitiro akafanana.
    ///
    /// Zvekupokana radices zvinotsigirwa.
    ///
    /// 'Digit' inotsanangurwa kuve chete anotevera mavara:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// # Errors
    ///
    /// Inodzorera `None` kana `char` isingarevi kune digit mune yakapihwa radix.
    ///
    /// # Panics
    ///
    /// Panics kana ikapihwa radix yakakura kupfuura makumi matatu.
    ///
    /// # Examples
    ///
    /// Kushandiswa kwekutanga:
    ///
    /// ```
    /// assert_eq!('1'.to_digit(10), Some(1));
    /// assert_eq!('f'.to_digit(16), Some(15));
    /// ```
    ///
    /// Kupasa isina-manhamba kunoguma nekutadza:
    ///
    /// ```
    /// assert_eq!('f'.to_digit(10), None);
    /// assert_eq!('z'.to_digit(16), None);
    /// ```
    ///
    /// Kupfuura radix yakakura, ichikonzera panic:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.to_digit(37);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_digit(self, radix: u32) -> Option<u32> {
        assert!(radix <= 36, "to_digit: radix is too high (maximum 36)");
        // kodhi yacho yakakamurwa pano kuti ivandudze kumhanyisa mhanyisa kwezviitiko uko iyo `radix` iri yenguva dzose uye gumi kana diki
        //
        let val = if likely(radix <= 10) {
            // Kana isiri digit, nhamba yakakura kupfuura radix ichagadzirwa.
            (self as u32).wrapping_sub('0' as u32)
        } else {
            match self {
                '0'..='9' => self as u32 - '0' as u32,
                'a'..='z' => self as u32 - 'a' as u32 + 10,
                'A'..='Z' => self as u32 - 'A' as u32 + 10,
                _ => return None,
            }
        };

        if val < radix { Some(val) } else { None }
    }

    /// Inodzorera iterator iyo inoburitsa iyo hexadecimal Unicode kutiza kwehunhu se`char`s.
    ///
    /// Izvi zvichapunyuka mavara ane Rust syntax yefomu `\u{NNNNNN}` apo `NNNNNN` inomiririra hexadecimal.
    ///
    ///
    /// # Examples
    ///
    /// Se iterator:
    ///
    /// ```
    /// for c in '❤'.escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Uchishandisa `println!` zvakananga:
    ///
    /// ```
    /// println!("{}", '❤'.escape_unicode());
    /// ```
    ///
    /// Ose ari maviri akaenzana ne:
    ///
    /// ```
    /// println!("\\u{{2764}}");
    /// ```
    ///
    /// Uchishandisa `to_string`:
    ///
    /// ```
    /// assert_eq!('❤'.escape_unicode().to_string(), "\\u{2764}");
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_unicode(self) -> EscapeUnicode {
        let c = self as u32;

        // kana-ing 1 inovimbisa kuti ye c==0 kodhi yacho inokomberedza kuti chidimbu chimwe chete chidhindwe uye (zvinova zvakafanana) zvinodzivirira (31, 32) kufashukira
        //
        //
        let msb = 31 - (c | 1).leading_zeros();

        // indekisi yeiyo inonyanya kukosha hex manhamba
        let ms_hex_digit = msb / 4;
        EscapeUnicode {
            c: self,
            state: EscapeUnicodeState::Backslash,
            hex_digit_idx: ms_hex_digit as usize,
        }
    }

    /// Iyo yakawedzerwa vhezheni ye `escape_debug` iyo inosarudzika inobvumidza kupukunyuka Yakawedzerwa Grapheme macodepoints.
    /// Izvi zvinotibvumidza isu kumisikidza mavara senge nonspacing mamaki zvirinani pavanenge vari pakutanga kwetambo.
    ///
    #[inline]
    pub(crate) fn escape_debug_ext(self, escape_grapheme_extended: bool) -> EscapeDebug {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            _ if escape_grapheme_extended && self.is_grapheme_extended() => {
                EscapeDefaultState::Unicode(self.escape_unicode())
            }
            _ if is_printable(self) => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDebug(EscapeDefault { state: init_state })
    }

    /// Inodzorera iterator iyo inoburitsa chaiyo chaiyo yekutiza kodhi yehunhu se`char`s.
    ///
    /// Izvi zvichapunyuka mavara akafanana ne `Debug` kuitiswa kwe `str` kana `char`.
    ///
    ///
    /// # Examples
    ///
    /// Se iterator:
    ///
    /// ```
    /// for c in '\n'.escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Uchishandisa `println!` zvakananga:
    ///
    /// ```
    /// println!("{}", '\n'.escape_debug());
    /// ```
    ///
    /// Ose ari maviri akaenzana ne:
    ///
    /// ```
    /// println!("\\n");
    /// ```
    ///
    /// Uchishandisa `to_string`:
    ///
    /// ```
    /// assert_eq!('\n'.escape_debug().to_string(), "\\n");
    /// ```
    ///
    #[stable(feature = "char_escape_debug", since = "1.20.0")]
    #[inline]
    pub fn escape_debug(self) -> EscapeDebug {
        self.escape_debug_ext(true)
    }

    /// Inodzorera iterator iyo inoburitsa chaiyo chaiyo yekutiza kodhi yehunhu se`char`s.
    ///
    /// Iko kusarudzika kunosarudzwa nechisaruro pakugadzira zvinyorwa zviri pamutemo mumitauro yakasiyana siyana, kusanganisira C++ 11 nemitauro yakafanana yeC-yemhuri.
    /// Mitemo chaiyo ndeiyi:
    ///
    /// * Tab yapunyuka se `\t`.
    /// * Kudzoka kwengoro kunopukunyuka se `\r`.
    /// * Mutsetse wekudya unopukunyuka se `\n`.
    /// * Imwe chete quote yakapunyuka se `\'`.
    /// * Kaviri quote yakapunyuka se `\"`.
    /// * Kudzoka kwakapunyuka se `\\`.
    /// * Chero hunhu mu 'anodhinda ASCII' renji `0x20` .. `0x7e` inosanganisirwa haina kupunyuka.
    /// * Vamwe vese mavara vanopihwa hexadecimal Unicode kutiza;ona [`escape_unicode`].
    ///
    /// [`escape_unicode`]: #method.escape_unicode
    ///
    /// # Examples
    ///
    /// Se iterator:
    ///
    /// ```
    /// for c in '"'.escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Uchishandisa `println!` zvakananga:
    ///
    /// ```
    /// println!("{}", '"'.escape_default());
    /// ```
    ///
    /// Ose ari maviri akaenzana ne:
    ///
    /// ```
    /// println!("\\\"");
    /// ```
    ///
    /// Uchishandisa `to_string`:
    ///
    /// ```
    /// assert_eq!('"'.escape_default().to_string(), "\\\"");
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_default(self) -> EscapeDefault {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            '\x20'..='\x7e' => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDefault { state: init_state }
    }

    /// Inodzorera huwandu hwemabheti iyi `char` ingangoda kana yakanyorwa mu UTF-8.
    ///
    /// Iyo nhamba yemabheti inogara iri pakati pe1 ne4, inosanganisira.
    ///
    /// # Examples
    ///
    /// Kushandiswa kwekutanga:
    ///
    /// ```
    /// let len = 'A'.len_utf8();
    /// assert_eq!(len, 1);
    ///
    /// let len = 'ß'.len_utf8();
    /// assert_eq!(len, 2);
    ///
    /// let len = 'ℝ'.len_utf8();
    /// assert_eq!(len, 3);
    ///
    /// let len = '💣'.len_utf8();
    /// assert_eq!(len, 4);
    /// ```
    ///
    /// Rudzi rwe `&str` runovimbisa kuti zvirimo zviri UTF-8, uye saka tinogona kuenzanisa kureba kwazvaizotora kana poindi imwe neimwe yekodhi yakamiririrwa se `char` vs mu `&str` pachayo:
    ///
    ///
    /// ```
    /// // semitambo
    /// let eastern = '東';
    /// let capital = '京';
    ///
    /// // ese ari maviri anogona kumiririrwa semabheti matatu
    /// assert_eq!(3, eastern.len_utf8());
    /// assert_eq!(3, capital.len_utf8());
    ///
    /// // se &str, maviri aya akanyorwa mu UTF-8
    /// let tokyo = "東京";
    ///
    /// let len = eastern.len_utf8() + capital.len_utf8();
    ///
    /// // tinogona kuona kuti vanotora mabheti matanhatu ...
    /// assert_eq!(6, tokyo.len());
    ///
    /// // ... kungofanana ne &str
    /// assert_eq!(len, tokyo.len());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf8(self) -> usize {
        len_utf8(self as u32)
    }

    /// Inodzorera iyo nhamba ye16-bit kodhi mayuniti iyi `char` ingangoda kana yakanyorwa mu UTF-16.
    ///
    ///
    /// Ona zvinyorwa zve [`len_utf8()`] kuti uwane imwe tsananguro yeiyi pfungwa.
    /// Iri basa igirazi, asi re UTF-16 pachinzvimbo che UTF-8.
    ///
    /// [`len_utf8()`]: #method.len_utf8
    ///
    /// # Examples
    ///
    /// Kushandiswa kwekutanga:
    ///
    /// ```
    /// let n = 'ß'.len_utf16();
    /// assert_eq!(n, 1);
    ///
    /// let len = '💣'.len_utf16();
    /// assert_eq!(len, 2);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf16(self) -> usize {
        let ch = self as u32;
        if (ch & 0xFFFF) == ch { 1 } else { 2 }
    }

    /// Encode uyu hunhu se UTF-8 mune yakapihwa byte buffer, uyezve ndokudzorera subslice yeye buffer iyo iine iyo encoded hunhu.
    ///
    ///
    /// # Panics
    ///
    /// Panics kana iyo buffer isina kukwana zvakakwana.
    /// Iyo buffer yehurefu ina yakakura zvakakwana kuti encode chero `char`.
    ///
    /// # Examples
    ///
    /// Mune ese ari maviri mienzaniso, 'ß' inotora mabheti maviri kukodhi.
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = 'ß'.encode_utf8(&mut b);
    ///
    /// assert_eq!(result, "ß");
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// Iyo buffer idiki kwazvo:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// 'ß'.encode_utf8(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf8(self, dst: &mut [u8]) -> &mut str {
        // KUCHENGETEKA: `char` haisi surrogate, saka ichi chinoshanda UTF-8.
        unsafe { from_utf8_unchecked_mut(encode_utf8_raw(self as u32, dst)) }
    }

    /// Encode uyu hunhu se UTF-16 mune yakapihwa `u16` buffer, uyezve ndokudzorera subslice yeye buffer iyo ine encoded hunhu.
    ///
    ///
    /// # Panics
    ///
    /// Panics kana iyo buffer isina kukwana zvakakwana.
    /// Iyo buffer yehurefu 2 yakakura zvakakwana kuti encode chero `char`.
    ///
    /// # Examples
    ///
    /// Mune ese ari maviri mienzaniso, '𝕊' inotora maviri `u16`s kukodhi.
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = '𝕊'.encode_utf16(&mut b);
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// Iyo buffer idiki kwazvo:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// '𝕊'.encode_utf16(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf16(self, dst: &mut [u16]) -> &mut [u16] {
        encode_utf16_raw(self as u32, dst)
    }

    /// Inodzorera `true` kana iyi `char` iine `Alphabetic` chivakwa.
    ///
    /// `Alphabetic` inotsanangurwa muChitsauko 4 (Hunhu Hunhu) ye [Unicode Standard] uye yakatsanangurwa mu [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Kushandiswa kwekutanga:
    ///
    /// ```
    /// assert!('a'.is_alphabetic());
    /// assert!('京'.is_alphabetic());
    ///
    /// let c = '💝';
    /// // rudo zvinhu zvakawanda, asi haruitirwe alufabheti
    /// assert!(!c.is_alphabetic());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphabetic(self) -> bool {
        match self {
            'a'..='z' | 'A'..='Z' => true,
            c => c > '\x7f' && unicode::Alphabetic(c),
        }
    }

    /// Inodzorera `true` kana iyi `char` iine `Lowercase` chivakwa.
    ///
    /// `Lowercase` inotsanangurwa muChitsauko 4 (Hunhu Hunhu) ye [Unicode Standard] uye yakatsanangurwa mu [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Kushandiswa kwekutanga:
    ///
    /// ```
    /// assert!('a'.is_lowercase());
    /// assert!('δ'.is_lowercase());
    /// assert!(!'A'.is_lowercase());
    /// assert!(!'Δ'.is_lowercase());
    ///
    /// // Iwo akasiyana maChinese zvinyorwa uye mapumburo haana kesi, uye saka:
    /// assert!(!'中'.is_lowercase());
    /// assert!(!' '.is_lowercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_lowercase(self) -> bool {
        match self {
            'a'..='z' => true,
            c => c > '\x7f' && unicode::Lowercase(c),
        }
    }

    /// Inodzorera `true` kana iyi `char` iine `Uppercase` chivakwa.
    ///
    /// `Uppercase` inotsanangurwa muChitsauko 4 (Hunhu Hunhu) ye [Unicode Standard] uye yakatsanangurwa mu [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Kushandiswa kwekutanga:
    ///
    /// ```
    /// assert!(!'a'.is_uppercase());
    /// assert!(!'δ'.is_uppercase());
    /// assert!('A'.is_uppercase());
    /// assert!('Δ'.is_uppercase());
    ///
    /// // Iwo akasiyana maChinese zvinyorwa uye mapumburo haana kesi, uye saka:
    /// assert!(!'中'.is_uppercase());
    /// assert!(!' '.is_uppercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_uppercase(self) -> bool {
        match self {
            'A'..='Z' => true,
            c => c > '\x7f' && unicode::Uppercase(c),
        }
    }

    /// Inodzorera `true` kana iyi `char` iine `White_Space` chivakwa.
    ///
    /// `White_Space` inotsanangurwa mu [Unicode Character Database][ucd] [`PropList.txt`].
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`PropList.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/PropList.txt
    ///
    /// # Examples
    ///
    /// Kushandiswa kwekutanga:
    ///
    /// ```
    /// assert!(' '.is_whitespace());
    ///
    /// // nzvimbo isiri kutyora
    /// assert!('\u{A0}'.is_whitespace());
    ///
    /// assert!(!'越'.is_whitespace());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_whitespace(self) -> bool {
        match self {
            ' ' | '\x09'..='\x0d' => true,
            c => c > '\x7f' && unicode::White_Space(c),
        }
    }

    /// Inodzorera `true` kana iyi `char` inogutsa chero [`is_alphabetic()`] kana [`is_numeric()`].
    ///
    /// [`is_alphabetic()`]: #method.is_alphabetic
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Examples
    ///
    /// Kushandiswa kwekutanga:
    ///
    /// ```
    /// assert!('٣'.is_alphanumeric());
    /// assert!('7'.is_alphanumeric());
    /// assert!('৬'.is_alphanumeric());
    /// assert!('¾'.is_alphanumeric());
    /// assert!('①'.is_alphanumeric());
    /// assert!('K'.is_alphanumeric());
    /// assert!('و'.is_alphanumeric());
    /// assert!('藏'.is_alphanumeric());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphanumeric(self) -> bool {
        self.is_alphabetic() || self.is_numeric()
    }

    /// Inodzorera `true` kana iyi `char` iine chikamu chakazara chemakodhi ekudzivirira.
    ///
    /// Kudzora makodhi (kodhi kodhi ine yakajairwa chikamu che `Cc`) zvinotsanangurwa muChitsauko 4 (Hunhu Hunhu) ye [Unicode Standard] uye yakatsanangurwa mu [Unicode Character Database][ucd] [`UnicodeData.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// Kushandiswa kwekutanga:
    ///
    /// ```
    /// // U + 009C, STRING TERMINATOR
    /// assert!(''.is_control());
    /// assert!(!'q'.is_control());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_control(self) -> bool {
        unicode::Cc(self)
    }

    /// Inodzorera `true` kana iyi `char` iine `Grapheme_Extend` chivakwa.
    ///
    /// `Grapheme_Extend` inotsanangurwa mu [Unicode Standard Annex #29 (Unicode Text Segmentation)][uax29] uye yakatsanangurwa mu [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [uax29]: https://www.unicode.org/reports/tr29/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    #[inline]
    pub(crate) fn is_grapheme_extended(self) -> bool {
        unicode::Grapheme_Extend(self)
    }

    /// Inodzorera `true` kana iyi `char` iine imwe yemapoka akaenzana enhamba.
    ///
    /// Iwo mapato akajairwa enhamba (`Nd` yemadhijiti manhamba, `Nl` yemavara-akafanana manhamba mavara, uye `No` yemamwe mavara manhamba) zvinotsanangurwa mu [Unicode Character Database][ucd] [`UnicodeData.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// Kushandiswa kwekutanga:
    ///
    /// ```
    /// assert!('٣'.is_numeric());
    /// assert!('7'.is_numeric());
    /// assert!('৬'.is_numeric());
    /// assert!('¾'.is_numeric());
    /// assert!('①'.is_numeric());
    /// assert!(!'K'.is_numeric());
    /// assert!(!'و'.is_numeric());
    /// assert!(!'藏'.is_numeric());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_numeric(self) -> bool {
        match self {
            '0'..='9' => true,
            c => c > '\x7f' && unicode::N(c),
        }
    }

    /// Inodzorera iterator iyo inoburitsa mepasi yepasi mepu yeiyi `char` seimwe kana yakawanda
    /// `char`s.
    ///
    /// Kana iyi `char` isina mepu yepasi, iyo iterator inoburitsa yakafanana `char`.
    ///
    /// Kana iyi `char` iine mepu imwe-kune-imwe yakaderera yakapihwa ne [Unicode Character Database][ucd] [`UnicodeData.txt`], iyo iterator inoburitsa iyo `char`.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// Kana iyi `char` ichida kutariswa kwakasarudzika (semuenzaniso akawanda`char`s) iyo iterator inoburitsa iyo `char` (s) yakapihwa ne [`SpecialCasing.txt`].
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// Uku kuvhiya kunoita mepu isina zvimisikidzo isina kusona.Ndokunge, iko kushandurwa kwakazvimiririra mamiriro uye mutauro.
    ///
    /// Mu [Unicode Standard], Chitsauko 4 (Character Properties) inokurukura mamepu akajairwa uye Chitsauko 3 (Conformance) inokurukura default algorithm yekutendeuka kwenyaya.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// Se iterator:
    ///
    /// ```
    /// for c in 'İ'.to_lowercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Uchishandisa `println!` zvakananga:
    ///
    /// ```
    /// println!("{}", 'İ'.to_lowercase());
    /// ```
    ///
    /// Ose ari maviri akaenzana ne:
    ///
    /// ```
    /// println!("i\u{307}");
    /// ```
    ///
    /// Uchishandisa `to_string`:
    ///
    /// ```
    /// assert_eq!('C'.to_lowercase().to_string(), "c");
    ///
    /// // Dzimwe nguva mhedzisiro inopfuura hunhu humwe:
    /// assert_eq!('İ'.to_lowercase().to_string(), "i\u{307}");
    ///
    /// // Hunhu husina mabhii maviri epasi uye epasi anochinja kuita mavari.
    /////
    /// assert_eq!('山'.to_lowercase().to_string(), "山");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_lowercase(self) -> ToLowercase {
        ToLowercase(CaseMappingIter::new(conversions::to_lower(self)))
    }

    /// Inodzorera iyo iterator iyo inoburitsa iyo yepamusoro mepu yeiyi `char` seimwe kana yakawanda
    /// `char`s.
    ///
    /// Kana iyi `char` isina mepu yepamusoro, iyo iterator inoburitsa yakafanana `char`.
    ///
    /// Kana iyi `char` iine one-to-one yepamusoro mepu yakapihwa ne [Unicode Character Database][ucd] [`UnicodeData.txt`], iyo iterator inoburitsa iyo `char`.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// Kana iyi `char` ichida kutariswa kwakasarudzika (semuenzaniso akawanda`char`s) iyo iterator inoburitsa iyo `char` (s) yakapihwa ne [`SpecialCasing.txt`].
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// Uku kuvhiya kunoita mepu isina zvimisikidzo isina kusona.Ndokunge, iko kushandurwa kwakazvimiririra mamiriro uye mutauro.
    ///
    /// Mu [Unicode Standard], Chitsauko 4 (Character Properties) inokurukura mamepu akajairwa uye Chitsauko 3 (Conformance) inokurukura default algorithm yekutendeuka kwenyaya.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// Se iterator:
    ///
    /// ```
    /// for c in 'ß'.to_uppercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Uchishandisa `println!` zvakananga:
    ///
    /// ```
    /// println!("{}", 'ß'.to_uppercase());
    /// ```
    ///
    /// Ose ari maviri akaenzana ne:
    ///
    /// ```
    /// println!("SS");
    /// ```
    ///
    /// Uchishandisa `to_string`:
    ///
    /// ```
    /// assert_eq!('c'.to_uppercase().to_string(), "C");
    ///
    /// // Dzimwe nguva mhedzisiro inopfuura hunhu humwe:
    /// assert_eq!('ß'.to_uppercase().to_string(), "SS");
    ///
    /// // Hunhu husina mabhii maviri epasi uye epasi anochinja kuita mavari.
    /////
    /// assert_eq!('山'.to_uppercase().to_string(), "山");
    /// ```
    ///
    /// # Cherekedza pane locale
    ///
    /// MuTurkey, iyo yakaenzana ne 'i' muchiLatin ine mafomu mashanu pane maviri:
    ///
    /// * 'Dotless': I/ı, dzimwe nguva zvakanyorwa ï
    /// * 'Dotted': İ/i
    ///
    /// Ziva kuti iro repazasi rakadonhedzwa 'i' rakafanana neLatin.Naizvozvo:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    /// ```
    ///
    /// Iko kukosha kwe `upper_i` pano kunotsamira pamutauro wechinyorwa: kana tiri mu `en-US`, inofanira kunge iri `"I"`, asi kana tiri mu `tr_TR`, inofanira kunge iri `"İ"`.
    /// `to_uppercase()` haina hanya izvi, uye saka:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    ///
    /// assert_eq!(upper_i, "I");
    /// ```
    ///
    /// inobata mhiri mitauro.
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_uppercase(self) -> ToUppercase {
        ToUppercase(CaseMappingIter::new(conversions::to_upper(self)))
    }

    /// Cheki kana kukosha kuri mukati meiyo ASCII renji.
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.32.0")]
    #[inline]
    pub const fn is_ascii(&self) -> bool {
        *self as u32 <= 0x7F
    }

    /// Inoita kopi yeiyo kukosha mune yayo ASCII yepamusoro kesi yakaenzana.
    ///
    /// ASCII mavara 'a' kusvika 'z' akaiswa kumepu ku 'A' kusvika 'Z', asi mavara asiri eASCII haana kuchinja.
    ///
    /// Kuti uwedzere kukosha mu-nzvimbo, shandisa [`make_ascii_uppercase()`].
    ///
    /// Kuwedzera mavara eASCII kuwedzera kune asiri-ASCII mavara, shandisa [`to_uppercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('A', ascii.to_ascii_uppercase());
    /// assert_eq!('❤', non_ascii.to_ascii_uppercase());
    /// ```
    ///
    /// [`make_ascii_uppercase()`]: #method.make_ascii_uppercase
    /// [`to_uppercase()`]: #method.to_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_uppercase(&self) -> char {
        if self.is_ascii_lowercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// Inoita kopi yeiyo kukosha mune yayo ASCII yakaderera kesi yakaenzana.
    ///
    /// ASCII mavara 'A' kusvika 'Z' akaiswa kumepu ku 'a' kusvika 'z', asi mavara asiri eASCII haana kuchinja.
    ///
    /// Kudzikisa kukosha mu-nzvimbo, shandisa [`make_ascii_lowercase()`].
    ///
    /// Kudzikisa mavara eASCII kuwedzera kune asiri-ASCII mavara, shandisa [`to_lowercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'A';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('a', ascii.to_ascii_lowercase());
    /// assert_eq!('❤', non_ascii.to_ascii_lowercase());
    /// ```
    ///
    /// [`make_ascii_lowercase()`]: #method.make_ascii_lowercase
    /// [`to_lowercase()`]: #method.to_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_lowercase(&self) -> char {
        if self.is_ascii_uppercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// Inotarisa kuti mbiri mbiri ndeye ASCII kesi-isina hanya mutambo.
    ///
    /// Zvakaenzana ne `to_ascii_lowercase(a) == to_ascii_lowercase(b)`.
    ///
    /// # Examples
    ///
    /// ```
    /// let upper_a = 'A';
    /// let lower_a = 'a';
    /// let lower_z = 'z';
    ///
    /// assert!(upper_a.eq_ignore_ascii_case(&lower_a));
    /// assert!(upper_a.eq_ignore_ascii_case(&upper_a));
    /// assert!(!upper_a.eq_ignore_ascii_case(&lower_z));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn eq_ignore_ascii_case(&self, other: &char) -> bool {
        self.to_ascii_lowercase() == other.to_ascii_lowercase()
    }

    /// Inoshandura iyi mhando kune yayo ASCII yepamusoro kesi yakaenzana mu-nzvimbo.
    ///
    /// ASCII mavara 'a' kusvika 'z' akaiswa kumepu ku 'A' kusvika 'Z', asi mavara asiri eASCII haana kuchinja.
    ///
    /// Kuti udzore iyo nyowani yepamusoro yepamusoro usingachinje iyo iripo, shandisa [`to_ascii_uppercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'a';
    ///
    /// ascii.make_ascii_uppercase();
    ///
    /// assert_eq!('A', ascii);
    /// ```
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        *self = self.to_ascii_uppercase();
    }

    /// Inoshandura iyi mhando kune yayo ASCII yakaderera kesi yakaenzana mu-nzvimbo.
    ///
    /// ASCII mavara 'A' kusvika 'Z' akaiswa kumepu ku 'a' kusvika 'z', asi mavara asiri eASCII haana kuchinja.
    ///
    /// Kudzosera iyo nyowani yakadzikira kukosha pasina kugadzirisa iyo iripo, shandisa [`to_ascii_lowercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'A';
    ///
    /// ascii.make_ascii_lowercase();
    ///
    /// assert_eq!('a', ascii);
    /// ```
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        *self = self.to_ascii_lowercase();
    }

    /// Inotarisa kana iko kukosha kuri ASCII alphabetic hunhu:
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z', kana
    /// - U + 0061 'a' ..=U + 007A 'z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphabetic());
    /// assert!(uppercase_g.is_ascii_alphabetic());
    /// assert!(a.is_ascii_alphabetic());
    /// assert!(g.is_ascii_alphabetic());
    /// assert!(!zero.is_ascii_alphabetic());
    /// assert!(!percent.is_ascii_alphabetic());
    /// assert!(!space.is_ascii_alphabetic());
    /// assert!(!lf.is_ascii_alphabetic());
    /// assert!(!esc.is_ascii_alphabetic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphabetic(&self) -> bool {
        matches!(*self, 'A'..='Z' | 'a'..='z')
    }

    /// Inotarisa kana kukosha kuri kweASCII yepamusoro mavara:
    /// U + 0041 'A' ..=U + 005A 'Z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_uppercase());
    /// assert!(uppercase_g.is_ascii_uppercase());
    /// assert!(!a.is_ascii_uppercase());
    /// assert!(!g.is_ascii_uppercase());
    /// assert!(!zero.is_ascii_uppercase());
    /// assert!(!percent.is_ascii_uppercase());
    /// assert!(!space.is_ascii_uppercase());
    /// assert!(!lf.is_ascii_uppercase());
    /// assert!(!esc.is_ascii_uppercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_uppercase(&self) -> bool {
        matches!(*self, 'A'..='Z')
    }

    /// Inotarisa kana iko kukosha kuri ASCII yakaderera mavara:
    /// U + 0061 'a' ..=U + 007A 'z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_lowercase());
    /// assert!(!uppercase_g.is_ascii_lowercase());
    /// assert!(a.is_ascii_lowercase());
    /// assert!(g.is_ascii_lowercase());
    /// assert!(!zero.is_ascii_lowercase());
    /// assert!(!percent.is_ascii_lowercase());
    /// assert!(!space.is_ascii_lowercase());
    /// assert!(!lf.is_ascii_lowercase());
    /// assert!(!esc.is_ascii_lowercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_lowercase(&self) -> bool {
        matches!(*self, 'a'..='z')
    }

    /// Inotarisa kana kukosha kuri ASCII alphanumeric hunhu:
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z', kana
    /// - U + 0061 'a' ..=U + 007A 'z', kana
    /// - U + 0030 '0' ..=U + 0039 '9'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphanumeric());
    /// assert!(uppercase_g.is_ascii_alphanumeric());
    /// assert!(a.is_ascii_alphanumeric());
    /// assert!(g.is_ascii_alphanumeric());
    /// assert!(zero.is_ascii_alphanumeric());
    /// assert!(!percent.is_ascii_alphanumeric());
    /// assert!(!space.is_ascii_alphanumeric());
    /// assert!(!lf.is_ascii_alphanumeric());
    /// assert!(!esc.is_ascii_alphanumeric());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphanumeric(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='Z' | 'a'..='z')
    }

    /// Inotarisa kana kukosha kuri ASCII digit digit.
    /// U + 0030 '0' ..=U + 0039 '9'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_digit());
    /// assert!(!uppercase_g.is_ascii_digit());
    /// assert!(!a.is_ascii_digit());
    /// assert!(!g.is_ascii_digit());
    /// assert!(zero.is_ascii_digit());
    /// assert!(!percent.is_ascii_digit());
    /// assert!(!space.is_ascii_digit());
    /// assert!(!lf.is_ascii_digit());
    /// assert!(!esc.is_ascii_digit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_digit(&self) -> bool {
        matches!(*self, '0'..='9')
    }

    /// Inotarisa kana kukosha kuri ASCII hexadecimal digit:
    ///
    /// - U + 0030 '0' ..=U + 0039 '9', kana
    /// - U + 0041 'A' ..=U + 0046 'F', kana
    /// - U + 0061 'a' ..=U + 0066 'f'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_hexdigit());
    /// assert!(!uppercase_g.is_ascii_hexdigit());
    /// assert!(a.is_ascii_hexdigit());
    /// assert!(!g.is_ascii_hexdigit());
    /// assert!(zero.is_ascii_hexdigit());
    /// assert!(!percent.is_ascii_hexdigit());
    /// assert!(!space.is_ascii_hexdigit());
    /// assert!(!lf.is_ascii_hexdigit());
    /// assert!(!esc.is_ascii_hexdigit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_hexdigit(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='F' | 'a'..='f')
    }

    /// Inotarisa kana kukosha kwacho kuri kweASCII punctuation hunhu:
    ///
    /// - U + 0021 ..=U + 002F `! " # $ % & ' ( ) * + , - . /`, kana
    /// - U + 003A ..=U + 0040 `: ; < = > ? @`, kana
    /// - U + 005B ..=U + 0060 ``[\] ^ _``, kana
    /// - U + 007B ..=U + 007E `{ | } ~`
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_punctuation());
    /// assert!(!uppercase_g.is_ascii_punctuation());
    /// assert!(!a.is_ascii_punctuation());
    /// assert!(!g.is_ascii_punctuation());
    /// assert!(!zero.is_ascii_punctuation());
    /// assert!(percent.is_ascii_punctuation());
    /// assert!(!space.is_ascii_punctuation());
    /// assert!(!lf.is_ascii_punctuation());
    /// assert!(!esc.is_ascii_punctuation());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_punctuation(&self) -> bool {
        matches!(*self, '!'..='/' | ':'..='@' | '['..='`' | '{'..='~')
    }

    /// Inotarisa kana kukosha kuri ASCII graphic hunhu:
    /// U + 0021 '!' ..=U + 007E '~'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_graphic());
    /// assert!(uppercase_g.is_ascii_graphic());
    /// assert!(a.is_ascii_graphic());
    /// assert!(g.is_ascii_graphic());
    /// assert!(zero.is_ascii_graphic());
    /// assert!(percent.is_ascii_graphic());
    /// assert!(!space.is_ascii_graphic());
    /// assert!(!lf.is_ascii_graphic());
    /// assert!(!esc.is_ascii_graphic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_graphic(&self) -> bool {
        matches!(*self, '!'..='~')
    }

    /// Inoongorora kana kukosha kuri ASCII whitespace hunhu:
    /// U + 0020 SPACE, U + 0009 HORIZONTAL TAB, U + 000A LINE FEED, U + 000C FOMU FEED, kana U + 000D KUKUDZWA KWECHIKWATA.
    ///
    /// Rust inoshandisa iyo WhatWG Infra Standard's [definition of ASCII whitespace][infra-aw].Kune dzimwe tsanangudzo dzinoverengeka mukushandiswa kukuru.
    /// Semuenzaniso, [the POSIX locale][pct] inosanganisira U + 000B VERTICAL TAB pamwe neese ari pamusoro mavara, asi-kubva kune iwo chaiwo iwo marongero-[mutemo wakasarudzika we "field splitting" muBourne shell][bfs] inofunga *chete* SPACE, HORIZONTAL TAB, uye ZVINOKOSHA FEED seyechena nzvimbo.
    ///
    ///
    /// Kana iwe uri kunyora chirongwa icho chichagadzirisa iripo faira fomati, tarisa kuti iyo fomati tsananguro yeiyo whitespace iri usati washandisa iri basa.
    ///
    /// [infra-aw]: https://infra.spec.whatwg.org/#ascii-whitespace
    /// [pct]: http://pubs.opengroup.org/onlinepubs/9699919799/basedefs/V1_chap07.html#tag_07_03_01
    /// [bfs]: http://pubs.opengroup.org/onlinepubs/9699919799/utilities/V3_chap02.html#tag_18_06_05
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_whitespace());
    /// assert!(!uppercase_g.is_ascii_whitespace());
    /// assert!(!a.is_ascii_whitespace());
    /// assert!(!g.is_ascii_whitespace());
    /// assert!(!zero.is_ascii_whitespace());
    /// assert!(!percent.is_ascii_whitespace());
    /// assert!(space.is_ascii_whitespace());
    /// assert!(lf.is_ascii_whitespace());
    /// assert!(!esc.is_ascii_whitespace());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_whitespace(&self) -> bool {
        matches!(*self, '\t' | '\n' | '\x0C' | '\r' | ' ')
    }

    /// Inoongorora kana kukosha kuri ASCII yekudzora hunhu:
    /// U + 0000 NUL ..=U + 001F UNIT SEPARATOR, kana U + 007F DELETE.
    /// Ziva kuti mazhinji ASCII machena mavara mavara anodzora, asi SPACE haisi.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_control());
    /// assert!(!uppercase_g.is_ascii_control());
    /// assert!(!a.is_ascii_control());
    /// assert!(!g.is_ascii_control());
    /// assert!(!zero.is_ascii_control());
    /// assert!(!percent.is_ascii_control());
    /// assert!(!space.is_ascii_control());
    /// assert!(lf.is_ascii_control());
    /// assert!(esc.is_ascii_control());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_control(&self) -> bool {
        matches!(*self, '\0'..='\x1F' | '\x7F')
    }
}

#[inline]
const fn len_utf8(code: u32) -> usize {
    if code < MAX_ONE_B {
        1
    } else if code < MAX_TWO_B {
        2
    } else if code < MAX_THREE_B {
        3
    } else {
        4
    }
}

/// Encode yakasvibirira u32 kukosha se UTF-8 mune yakapihwa byte buffer, uyezve ndokudzorera subslice yeye buffer iyo ine iyo encoded hunhu.
///
///
/// Kusiyana ne `char::encode_utf8`, iyi nzira inobatawo macodepoints mune imwe surrogate renji.
/// (Kugadzira `char` mune yekuberekera renji ndeye UB.) Mhedzisiro yacho ndeyechokwadi [generalized UTF-8] asi isiri UTF-8.
///
/// [generalized UTF-8]: https://simonsapin.github.io/wtf-8/#generalized-utf8
///
/// # Panics
///
/// Panics kana iyo buffer isina kukwana zvakakwana.
/// Iyo buffer yehurefu ina yakakura zvakakwana kuti encode chero `char`.
///
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf8_raw(code: u32, dst: &mut [u8]) -> &mut [u8] {
    let len = len_utf8(code);
    match (len, &mut dst[..]) {
        (1, [a, ..]) => {
            *a = code as u8;
        }
        (2, [a, b, ..]) => {
            *a = (code >> 6 & 0x1F) as u8 | TAG_TWO_B;
            *b = (code & 0x3F) as u8 | TAG_CONT;
        }
        (3, [a, b, c, ..]) => {
            *a = (code >> 12 & 0x0F) as u8 | TAG_THREE_B;
            *b = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *c = (code & 0x3F) as u8 | TAG_CONT;
        }
        (4, [a, b, c, d, ..]) => {
            *a = (code >> 18 & 0x07) as u8 | TAG_FOUR_B;
            *b = (code >> 12 & 0x3F) as u8 | TAG_CONT;
            *c = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *d = (code & 0x3F) as u8 | TAG_CONT;
        }
        _ => panic!(
            "encode_utf8: need {} bytes to encode U+{:X}, but the buffer has {}",
            len,
            code,
            dst.len(),
        ),
    };
    &mut dst[..len]
}

/// Encode yakasvibirira u32 kukosha se UTF-16 mune yakapihwa `u16` buffer, uyezve ndokudzorera subslice yeye buffer iyo ine iyo encoded hunhu.
///
///
/// Kusiyana ne `char::encode_utf16`, iyi nzira inobatawo macodepoints mune imwe surrogate renji.
/// (Kugadzira `char` mune yekutsiva renji ndeye UB.)
///
/// # Panics
///
/// Panics kana iyo buffer isina kukwana zvakakwana.
/// Iyo buffer yehurefu 2 yakakura zvakakwana kuti encode chero `char`.
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf16_raw(mut code: u32, dst: &mut [u16]) -> &mut [u16] {
    // Kachengeteka: ruoko rwese runotarisa kana paine mabiti akakwana ekunyorera
    unsafe {
        if (code & 0xFFFF) == code && !dst.is_empty() {
            // Iyo BMP inodonha kuburikidza
            *dst.get_unchecked_mut(0) = code as u16;
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 1)
        } else if dst.len() >= 2 {
            // Ndege dzekuwedzera dzinopaza kuita mamwe masurugri.
            code -= 0x1_0000;
            *dst.get_unchecked_mut(0) = 0xD800 | ((code >> 10) as u16);
            *dst.get_unchecked_mut(1) = 0xDC00 | ((code as u16) & 0x3FF);
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 2)
        } else {
            panic!(
                "encode_utf16: need {} units to encode U+{:X}, but the buffer has {}",
                from_u32_unchecked(code).len_utf16(),
                code,
                dst.len(),
            )
        }
    }
}