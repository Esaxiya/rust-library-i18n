//! Iyi module inoshandisa iyo `Any` trait, iyo inogonesa inesimba typing yechero `'static` mhando kuburikidza neiyo nguva yekumhanya.
//!
//! `Any` pachayo inogona kushandiswa kutora `TypeId`, uye ine zvimwe zvinhu painoshandiswa sechinhu che trait.
//! Sezvo `&dyn Any` (chinhu chakakweretwa trait chinhu), ine nzira dze `is` uye `downcast_ref`, kuyedza kana iri kukosha iri yerudzi rwakapihwa, uye kuti uwane revo kune kukosha kwemukati serudzi.
//! Sa `&mut dyn Any`, kune zvekare nzira ye `downcast_mut`, yekuwana chirevo chinoshanduka kune kukosha kwemukati.
//! `Box<dyn Any>` inowedzera iyo `downcast` nzira, iyo inoedza kushandura kuita `Box<T>`.
//! Ona iyo [`Box`] zvinyorwa zvemashoko azere.
//!
//! Ziva kuti `&dyn Any` inogumira pakuyedza kana kukosha kuri kwerudzi rwekongiri yakatarwa, uye hakugone kushandiswa kuyedza kana iri mhando inoshandisa trait.
//!
//! [`Box`]: ../../std/boxed/struct.Box.html
//!
//! # Anonongedzera smart uye `dyn Any`
//!
//! Chimwe chidimbu chehunhu chekuchengeta mundangariro kana uchishandisa `Any` sechinhu che trait, kunyanya nemhando senge `Box<dyn Any>` kana `Arc<dyn Any>`, ndeyekuti kungodaidza `.type_id()` pamutengo kuchaburitsa `TypeId` ye *mudziyo*, kwete icho chiri pasi pe trait chinhu.
//!
//! Izvi zvinogona kudzivirirwa nekushandura smart pointer kuita `&dyn Any` pachinzvimbo, icho chinodzosera `TypeId` yechinhu.
//! Semuyenzaniso:
//!
//! ```
//! use std::any::{Any, TypeId};
//!
//! let boxed: Box<dyn Any> = Box::new(3_i32);
//!
//! // Iwe ungangoda izvi.
//! let actual_id = (&*boxed).type_id();
//! // ... pane izvi:
//! let boxed_id = boxed.type_id();
//!
//! assert_eq!(actual_id, TypeId::of::<i32>());
//! assert_eq!(boxed_id, TypeId::of::<Box<dyn Any>>());
//! ```
//!
//! # Examples
//!
//! Funga mamiriro ezvinhu apo isu tinoda kuti tione kunze kukosha kwakapfuudzwa kune basa.
//! Isu tinoziva kukosha kwatiri kushanda pazvishandiso Debug, asi isu hatizive mhando yayo yekongiri.Isu tinoda kupa kwakakosha kurapwa kune mamwe marudzi: mune ino kesi kudhinda kunze kwehurefu hweString tsika pamberi pekukosha kwayo.
//! Hatizive iyo kongiri mhando yekukosha kwedu panguva yekubatanidza, saka tinofanirwa kushandisa nguva yekumhanya kuratidza.
//!
//! ```rust
//! use std::fmt::Debug;
//! use std::any::Any;
//!
//! // Logger inoshanda kune chero mhando inoshandisa Debug.
//! fn log<T: Any + Debug>(value: &T) {
//!     let value_any = value as &dyn Any;
//!
//!     // Edza kushandura kukosha kwedu kuve `String`.
//!     // Kana tikabudirira, isu tinoda kuburitsa iyo String`hurefu pamwe nekukosha kwayo.
//!     // Kana zvisiri, iri imwe mhando: ingoipurinda kunze usina kushongedzwa.
//!     match value_any.downcast_ref::<String>() {
//!         Some(as_string) => {
//!             println!("String ({}): {}", as_string.len(), as_string);
//!         }
//!         None => {
//!             println!("{:?}", value);
//!         }
//!     }
//! }
//!
//! // Iri basa rinoda kubaya paramende kunze risati raita basa naro.
//! fn do_work<T: Any + Debug>(value: &T) {
//!     log(value);
//!     // ... ita rimwe basa
//! }
//!
//! fn main() {
//!     let my_string = "Hello World".to_string();
//!     do_work(&my_string);
//!
//!     let my_i8: i8 = 100;
//!     do_work(&my_i8);
//! }
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::intrinsics;

///////////////////////////////////////////////////////////////////////////////
// Chero trait
///////////////////////////////////////////////////////////////////////////////

/// trait kutevedzera typing ine simba.
///
/// Mhando zhinji dzinoshandisa `Any`.Nekudaro, chero mhando ine iyo isiri-`` static 'rejisheni haina.
/// Ona iyo [module-level documentation][mod] kuti uwane rumwe ruzivo.
///
/// [mod]: crate::any
// Iyi trait haina kuchengetedzeka, asi isu tichivimba nezvinotsanangurwa zveiyo yega impl's `type_id` inoshanda mune isina kuchengetedzeka kodhi (semuenzaniso, `downcast`).Kazhinji, icho chingave chinetso, asi nekuti iyo chete implx ye `Any` ndeye gumbeze kuitisa, hapana imwe kodhi inogona kuita `Any`.
//
// Tinogona kunyatsoita kuti iyi trait ive isina kuchengetedzeka-zvaisazokonzeresa kuparara, nekuti isu tinodzora zvese zvinoitwa-asi isu tinosarudza kusaita sezvo izvo zvese zvisina kunyanya kukosha uye zvinogona kukanganisa vashandisi nezve mutsauko we traits isina kuchengetedzeka uye nzira dzisina kuchengetedzeka (kureva. `type_id` inenge ichiri yakachengeteka kufona, asi isu tingangoda kuratidza saizvozvi muzvinyorwa).
//
//
//
//
//
//
//
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Any: 'static {
    /// Inowana iyo `TypeId` ye `self`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string(s: &dyn Any) -> bool {
    ///     TypeId::of::<String>() == s.type_id()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "get_type_id", since = "1.34.0")]
    fn type_id(&self) -> TypeId;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: 'static + ?Sized> Any for T {
    fn type_id(&self) -> TypeId {
        TypeId::of::<T>()
    }
}

///////////////////////////////////////////////////////////////////////////////
// Nzira dzekuwedzera dzeZvipi trait zvinhu.
///////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

// Ita shuwa kuti mhedzisiro ye eg, kujoina tambo inogona kudhindwa uye nekudaro inoshandiswa ne `unwrap`.
// Panogona kuzopedzisira pasingadiwe kana kutumira kuchishanda nekusimudzira.
//
#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any + Send {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

#[stable(feature = "any_send_sync_methods", since = "1.28.0")]
impl fmt::Debug for dyn Any + Send + Sync {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

impl dyn Any {
    /// Inodzorera `true` kana iyo mhando yebhokisi yakafanana ne `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &dyn Any) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        // Tora `TypeId` yerudzi urwu basa iri inosimbiswa ne.
        let t = TypeId::of::<T>();

        // Tora `TypeId` yerudzi mu trait chinhu (`self`).
        let concrete = self.type_id();

        // Enzanisa zvese `TypeId`s pane kuenzana.
        t == concrete
    }

    /// Inodzorera kumwe kutaurwa kune kukosha kwebhokisi kana iri yerudzi `T`, kana `None` kana isiri.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &dyn Any) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        if self.is::<T>() {
            // Kachengeteka: tangotarisa kuti tiri kunongedzera mhando chaiyo, uye isu tinogona kuvimba nazvo
            // iyo inotarisa kuchengetedzwa kwendangariro nekuti isu takaita Chero zvemarudzi ese;hapana mamwe ma impls anogona kuvapo sezvaanogona kupokana neyedu impl.
            //
            unsafe { Some(&*(self as *const dyn Any as *const T)) }
        } else {
            None
        }
    }

    /// Inodzorera imwe inogona kuchinjika kune iro bhokisi rakakosheswa kana iri yerudzi `T`, kana `None` kana isiri iyo.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut dyn Any) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        if self.is::<T>() {
            // Kachengeteka: tangotarisa kuti tiri kunongedzera mhando chaiyo, uye isu tinogona kuvimba nazvo
            // iyo inotarisa kuchengetedzwa kwendangariro nekuti isu takaita Chero zvemarudzi ese;hapana mamwe ma impls anogona kuvapo sezvaanogona kupokana neyedu impl.
            //
            unsafe { Some(&mut *(self as *mut dyn Any as *mut T)) }
        } else {
            None
        }
    }
}

impl dyn Any + Send {
    /// Tungamira kumberi kunzira yakatsanangurwa pane mhando `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// Tungamira kumberi kunzira yakatsanangurwa pane mhando `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// Tungamira kumberi kunzira yakatsanangurwa pane mhando `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

impl dyn Any + Send + Sync {
    /// Tungamira kumberi kunzira yakatsanangurwa pane mhando `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send + Sync)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// Tungamira kumberi kunzira yakatsanangurwa pane mhando `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send + Sync)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// Tungamira kumberi kunzira yakatsanangurwa pane mhando `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send + Sync)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

///////////////////////////////////////////////////////////////////////////////
// TypeID uye nzira dzayo
///////////////////////////////////////////////////////////////////////////////

/// `TypeId` inomiririra yakasarudzika yepasirese chitupa cherudzi.
///
/// Imwe neimwe `TypeId` chinhu che opaque chisingatenderi kuongorora zviri mukati asi chinotendera mashandiro ekutanga senge kuumbana, kuenzanisa, kudhinda, uye kuratidza.
///
///
/// `TypeId` parizvino inongowanikwa chete pamhando dzinopa `'static`, asi uyu muganho unogona kubviswa mu future.
///
/// Ipo `TypeId` ichishandisa `Hash`, `PartialOrd`, uye `Ord`, zvakakosha kuti uzive kuti hashes uye odha zvichasiyana pakati pe Rust kuburitswa.
/// Ngwarira kuvimba navo mukati mekodhi yako!
///
///
///
#[derive(Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Debug, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct TypeId {
    t: u64,
}

impl TypeId {
    /// Inodzorera `TypeId` yemhando iyi generic basa rakasimbiswa nayo.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string<T: ?Sized + Any>(_s: &T) -> bool {
    ///     TypeId::of::<String>() == TypeId::of::<T>()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub const fn of<T: ?Sized + 'static>() -> TypeId {
        TypeId { t: intrinsics::type_id::<T>() }
    }
}

/// Inodzorera zita rerudzi setambo tambo.
///
/// # Note
///
/// Izvi zvinoitirwa kushandiswa kwekuongorora.
/// Izvo zvirimo zvirimo uye fomati yetambo yakadzoserwa haina kutaurwa, kunze kwekunge iri yekuedza-yekuedza tsananguro yerudzi.
/// Semuenzaniso, pakati petambo idzo `type_name::<Option<String>>()` inogona kudzoka i `"Option<String>"` uye `"std::option::Option<std::string::String>"`.
///
///
/// Iyo tambo yakadzoserwa haifanire kutariswa seakasarudzika erudzi sezvo akawanda marudzi anogona mepu kune yakafanana mhando zita.
/// Saizvozvo, hapana vimbiso yekuti zvese zvikamu zvechimiro zvichaonekwa mune tambo yakadzoserwa: semuenzaniso, vatauri veupenyu hwese parizvino havana kuiswa.
/// Uye zvakare, izvo zvinoburitswa zvinogona kuchinja pakati peshanduro dzemusanganisi.
///
/// Kuitwa kwazvino kunoshandisa iyo imwecheteyo masekisheni senge compiler diagnostics uye debuginfo, asi izvi hazvivimbiswe.
///
/// # Examples
///
/// ```rust
/// assert_eq!(
///     std::any::type_name::<Option<String>>(),
///     "core::option::Option<alloc::string::String>",
/// );
/// ```
///
///
///
///
#[stable(feature = "type_name", since = "1.38.0")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name<T: ?Sized>() -> &'static str {
    intrinsics::type_name::<T>()
}

/// Inodzorera zita rerudzi rweiyo yakanongedzwa-kukosha senge tambo chidimbu.
/// Izvi zvakafanana ne `type_name::<T>()`, asi inogona kushandiswa uko mhando yemusiyano isingawanikwe nyore.
///
/// # Note
///
/// Izvi zvinoitirwa kushandiswa kwekuongorora.Izvo zvirimo zvirimo uye fomati yeiyo tambo haina kutaurwa, kunze kwekunge iri yekuedza-yekuedza tsananguro yerudzi.
/// Semuenzaniso, `type_name_of_val::<Option<String>>(None)` inogona kudzosa `"Option<String>"` kana `"std::option::Option<std::string::String>"`, asi kwete `"foobar"`.
///
/// Uye zvakare, izvo zvinoburitswa zvinogona kuchinja pakati peshanduro dzemusanganisi.
///
/// Iri basa harigadzirise zvinhu trait, zvichireva kuti `type_name_of_val(&7u32 as &dyn Debug)` inogona kudzosa `"dyn Debug"`, asi kwete `"u32"`.
///
/// Rudzi rwezita harufanire kutariswa seakasarudzika chiratidzo cherudzi;
/// mhando dzakawanda dzinogona kugovana zvakafanana zita zita.
///
/// Kuitwa kwazvino kunoshandisa iyo imwecheteyo masekisheni senge compiler diagnostics uye debuginfo, asi izvi hazvivimbiswe.
///
/// # Examples
///
/// Tinoprinta default manhamba uye mhando dzekuyangarara.
///
/// ```rust
/// #![feature(type_name_of_val)]
/// use std::any::type_name_of_val;
///
/// let x = 1;
/// println!("{}", type_name_of_val(&x));
/// let y = 1.0;
/// println!("{}", type_name_of_val(&y));
/// ```
///
///
///
///
///
///
#[unstable(feature = "type_name_of_val", issue = "66359")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name_of_val<T: ?Sized>(_val: &T) -> &'static str {
    type_name::<T>()
}