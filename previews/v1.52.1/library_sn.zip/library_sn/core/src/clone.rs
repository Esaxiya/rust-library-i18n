//! Iyo `Clone` trait yemhando dzisingakwanise 'kunyatsoteedzerwa'.
//!
//! Mu Rust, mamwe marudzi akapusa ari "implicitly copyable" uye kana iwe ukaaisa kana kuapfuudza sekupokana, iye anogamuchira anowana kopi, achisiya kukosha kwepakutanga munzvimbo.
//! Aya marudzi haadi kugoverwa kuteedzera uye haana ekupedzisa (kureva kuti, haana mabhokisi ane avo kana kuita [`Drop`]), saka muunganidzi anozviona zvakachipa uye zvakachengeteka kuteedzera.
//!
//! Kune mamwe marudzi emakopi anofanirwa kuitwa zvakajeka, nekonisheni ichiita iyo [`Clone`] trait uye inodaidza iyo [`clone`] nzira.
//!
//! [`clone`]: Clone::clone
//!
//! Yekutanga muenzaniso wekushandisa:
//!
//! ```
//! let s = String::new(); // String mhando inoshandisa Clone
//! let copy = s.clone(); // saka tinogona kuzvienzanisa
//! ```
//!
//! Kuti uite nyore Clone trait, unogona zvakare kushandisa `#[derive(Clone)]`.Muenzaniso:
//!
//! ```
//! #[derive(Clone)] // isu tinowedzera iyo Clone trait kuMorpheus struct
//! struct Morpheus {
//!    blue_pill: f32,
//!    red_pill: i64,
//! }
//!
//! fn main() {
//!    let f = Morpheus { blue_pill: 0.0, red_pill: 0 };
//!    let copy = f.clone(); // uye ikozvino tinogona kuzvienzanisa!
//! }
//! ```
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

/// trait yakajairika yekukwanisa kujekesa chinhu.
///
/// Zvinosiyana kubva ku [`Copy`] mune iyo [`Copy`] iri pachena uye inodhura zvakanyanya, nepo `Clone` inogara iri pachena uye inogona kana isingadhuri.
/// Kuti usimbise hunhu uhwu, Rust haibvumidze iwe kuti umise zvakare [`Copy`], asi unogona kumisikidza `Clone` uye unomhanyisa kodhi kodhi.
///
/// Sezvo `Clone` yakajairika kupfuura [`Copy`], unogona kungoita chero chinhu [`Copy`] ive `Clone` futi.
///
/// ## Derivable
///
/// Iyi trait inogona kushandiswa ne `#[derive]` kana minda yese iri `Clone`.Iyo `derive`d kuitiswa kwe [`Clone`] inodaidza [`clone`] pane yega ndima.
///
/// [`clone`]: Clone::clone
///
/// Yechimiro chakajairika, `#[derive]` inoshandisa `Clone` mamiriro nekuwedzera yakasungwa `Clone` pamatanho akajairika.
///
/// ```
/// // `derive` zvishandiso Clone yekuverenga<T>apo T ari Clone.
/// #[derive(Clone)]
/// struct Reading<T> {
///     frequency: T,
/// }
/// ```
///
/// ## Ndingaite sei kuti ndiite `Clone`?
///
/// Mhando dziri [`Copy`] dzinofanirwa kuve nekuita kushoma kwe `Clone`.Zvimwe zvakarongeka:
/// kana `T: Copy`, `x: T`, uye `y: &T`, ipapo `let x = y.clone();` yakaenzana ne `let x = *y;`.
/// Maitirwo emanyorerwo anofanirwa kuve nehanya kusimudzira ino isinga pindike;zvisinei, kodhi isina kuchengetedzeka haifanire kuvimba nayo kuti ive nechokwadi chekuchengetedza ndangariro.
///
/// Muenzaniso chimiro chakajairika chakabata chinongedzo chebasa.Mune ino kesi, kuiswa kwe `Clone` hakugone `derive`d, asi kunogona kuitwa se:
///
/// ```
/// struct Generate<T>(fn() -> T);
///
/// impl<T> Copy for Generate<T> {}
///
/// impl<T> Clone for Generate<T> {
///     fn clone(&self) -> Self {
///         *self
///     }
/// }
/// ```
///
/// ## Kuwedzera vanoshanda
///
/// Pamusoro peiyo [implementors listed below][impls], anotevera marudzi anoshandisawo `Clone`:
///
/// * Yekuita chinhu mhando (kureva, iwo akasarudzika mhando akatsanangurwa pabasa rega rega)
/// * Anoshanda pointer mhando (semuenzaniso, `fn() -> i32`)
/// * Mhando dzearray, dzese saizi, kana chinhu chechinhu chichiisawo `Clone` (semuenzaniso, `[i32; 123456]`)
/// * Mhando dzeTuple, kana chinhu chimwe nechimwe chichiisawo `Clone` (semuenzaniso, `()`, `(i32, bool)`)
/// * Mhando dzekuvhara, kana dzikatora hapana kukosha kubva kunharaunda kana kana ese akadaro akabatwa maitiro anoshandisa `Clone` pachavo.
///   Ziva kuti misiyano yakatorwa neyakagovaniswa mareferensi inogara ichiita `Clone` (kunyangwe kana iyo yakasarudzika isingaiti), nepo misiyano yakatorwa nerevo isingachinjiki isingamboite `Clone`.
///
///
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "clone"]
#[rustc_diagnostic_item = "Clone"]
pub trait Clone: Sized {
    /// Anodzorera kopi yemutengo.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(noop_method_call)]
    /// let hello = "Hello"; // &str zvishandiso Clone
    ///
    /// assert_eq!("Hello", hello.clone());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "cloning is often expensive and is not expected to have side effects"]
    fn clone(&self) -> Self;

    /// Inoita kopi-kupihwa kubva ku `source`.
    ///
    /// `a.clone_from(&b)` yakaenzana ne `a = b.clone()` mukushanda, asi inogona kuwedzerwa kushandisa zvakare zviwanikwa zve `a` kudzivirira migove isiri madikanwa.
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn clone_from(&mut self, source: &Self) {
        *self = source.clone()
    }
}

/// Derive macro inogadzira impl yeiyo trait `Clone`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Clone($item:item) {
    /* compiler built-in */
}

// FIXME(aburka): aya maStructs anoshandiswa chete ne#[derive] kusimbisa kuti chikamu chimwe nechimwe cherudzi chinoshandisa Clone kana Copy.
//
//
// Aya maumbirwo haafanire kuoneka mune mushandisi kodhi.
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsClone<T: Clone + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsCopy<T: Copy + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// Maitiro e `Clone` emhando dzechinyakare.
///
/// Maitiro asingakwanise kutsanangurwa mu Rust anoitwa mu `traits::SelectionContext::copy_clone_conditions()` mu `rustc_trait_selection`.
///
///
mod impls {

    use super::Clone;

    macro_rules! impl_clone {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Clone for $t {
                    #[inline]
                    fn clone(&self) -> Self {
                        *self
                    }
                }
            )*
        }
    }

    impl_clone! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Clone for ! {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *const T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *mut T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// Shared mareferenzi anogona kuumbika, asi zvinoshandurwa zvinongedzo *hazvigone*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for &T {
        #[inline]
        #[rustc_diagnostic_item = "noop_method_clone"]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// Shared mareferenzi anogona kuumbika, asi zvinoshandurwa zvinongedzo *hazvigone*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> !Clone for &mut T {}
}