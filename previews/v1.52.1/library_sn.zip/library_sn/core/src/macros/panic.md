Panics tambo iripo.

Izvi zvinobvumidza chirongwa kumisa ipapo nekupa mhinduro kune anodana chirongwa.
`panic!` inofanirwa kushandiswa kana chirongwa chasvika pasingadzoreke nyika.

Iyi macro ndiyo nzira kwayo yekusimbisa mamiriro mune muenzaniso kodhi uye mumiyedzo.
`panic!` yakasungwa kwazvo neiyo `unwrap` nzira yeese ma [`Option`][ounwrap] uye [`Result`][runwrap] enum.
Maitirwo ese ari maviri anodana `panic!` kana akaiswa ku [`None`] kana [`Err`] akasiyana.

Paunenge uchishandisa `panic!()` unogona kudoma tambo yekubhadhara, iyo inovakwa uchishandisa [`format!`] syntax.
Mubhadharo iwoyo unoshandiswa kana jekiseni panic mukudaidzira Rust tambo, zvichikonzera tambo ku panic zvachose.

Hunhu hwekusarudzika `std` hook, kureva
iyo kodhi inomhanya yakananga mushure me panic yakadanwa, ndeyekudhinda meseji yekubhadharira ku `stderr` pamwe neiyo file/line/column ruzivo rwe `panic!()` kufona.

Unogona kudarika panic hook uchishandisa [`std::panic::set_hook()`].
Mukati me hook a panic inogona kuwanikwa se `&dyn Any + Send`, iyo iine `&str` kana `String` yekugara ichikumbira `panic!()`.
Ku panic ine kukosha kweimwe mhando, [`panic_any`] inogona kushandiswa.

[`Result`] enum inowanzo iri mhinduro iri nani yekuwanazve kubva mukukanganisa pane kushandisa `panic!` macro.
Iyi macro inofanirwa kushandiswa kudzivirira kuenderera uchishandisa zvisizvo zvisirizvo, senge kubva kunowanikwa kunze.
Ruzivo rwakadzama nezvekukanganisa kubata runowanikwa mu [book].

Onawo iyo macro [`compile_error!`], yekusimudza zvikanganiso panguva yekusanganiswa.

[ounwrap]: Option::unwrap
[runwrap]: Result::unwrap
[`std::panic::set_hook()`]: ../std/panic/fn.set_hook.html
[`panic_any`]: ../std/panic/fn.panic_any.html
[`Box`]: ../std/boxed/struct.Box.html
[`Any`]: crate::any::Any
[`format!`]: ../std/macro.format.html
[book]: ../book/ch09-00-error-handling.html

# Kuitwa kwazvino

Kana iyo yakakosha tambo panics inogumisa tambo dzako dzese uye kupedza chirongwa chako nekodhi `101`.

# Examples

```should_panic
# #![allow(unreachable_code)]
panic!();
panic!("this is a terrible mistake!");
panic!("this is a {} {message}", "fancy", message = "message");
std::panic::panic_any(4); // panic with the value of 4 to be collected elsewhere
```





