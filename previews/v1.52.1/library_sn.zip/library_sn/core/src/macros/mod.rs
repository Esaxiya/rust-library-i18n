#[doc = include_str!("panic.md")]
#[macro_export]
#[rustc_builtin_macro = "core_panic"]
#[allow_internal_unstable(edition_panic)]
#[stable(feature = "core", since = "1.6.0")]
#[rustc_diagnostic_item = "core_panic_macro"]
macro_rules! panic {
    // Inowedzera kune chero `$crate::panic::panic_2015` kana `$crate::panic::panic_2021` zvinoenderana neshanduro yeanodana.
    //
    ($($arg:tt)*) => {
        /* compiler built-in */
    };
}

/// Inoisa kuti zvirevo zviviri zvakaenzana kune imwe (uchishandisa [`PartialEq`]).
///
/// Pa panic, iyi macro ichapurinda hunhu hwezvirevo nemamiriri avo ekugadzirisa.
///
///
/// Sa [`assert!`], iyi macro ine yechipiri fomu, panowanikwa tsika ye panic.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// assert_eq!(a, b);
///
/// assert_eq!(a, b, "we are testing addition with {} and {}", a, b);
/// ```
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_eq {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // Izvo zvinotora pazasi zvine chinangwa.
                    // Pasina ivo, stack slot yekukwereta inotangwa kunyangwe kukosha kwacho kusati kwaenzaniswa, zvichitungamira kudzikira kunoonekwa.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // Izvo zvinotora pazasi zvine chinangwa.
                    // Pasina ivo, stack slot yekukwereta inotangwa kunyangwe kukosha kwacho kusati kwaenzaniswa, zvichitungamira kudzikira kunoonekwa.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// Inoisa kuti zvirevo zviviri hazvina kuenzana (kushandisa [`PartialEq`]).
///
/// Pa panic, iyi macro ichapurinda hunhu hwezvirevo nemamiriri avo ekugadzirisa.
///
///
/// Sa [`assert!`], iyi macro ine yechipiri fomu, panowanikwa tsika ye panic.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// assert_ne!(a, b);
///
/// assert_ne!(a, b, "we are testing that the values are not equal");
/// ```
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_ne {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // Izvo zvinotora pazasi zvine chinangwa.
                    // Pasina ivo, stack slot yekukwereta inotangwa kunyangwe kukosha kwacho kusati kwaenzaniswa, zvichitungamira kudzikira kunoonekwa.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&($left), &($right)) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // Izvo zvinotora pazasi zvine chinangwa.
                    // Pasina ivo, stack slot yekukwereta inotangwa kunyangwe kukosha kwacho kusati kwaenzaniswa, zvichitungamira kudzikira kunoonekwa.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// Inotsigira kuti boolean expression ndeye `true` panguva yekumhanya.
///
/// Izvi zvinokumbira iyo [`panic!`] macro kana chirevo chakapihwa chisingakwanise kuongororwa kusvika `true` panguva yekumhanya.
///
/// Sa [`assert!`], iyi macro zvakare ine yechipiri vhezheni, panowanikwa tsika panic meseji.
///
/// # Uses
///
/// Kusiyana ne [`assert!`], zvirevo zve `debug_assert!` zvinongogoneswa mune zvisina kugadziriswa zvinovaka nekutadza.
/// Chivakwa chakakwenenzverwa hachiite zvirevo zve `debug_assert!` kunze kwekunge `-C debug-assertions` yapfuudzwa kumusanganisi.
/// Izvi zvinoita kuti `debug_assert!` ibatsire macheki ayo anodhura zvakanyanya kuvepo mukuburitsa kuvaka asi inogona kubatsira panguva yekuvandudza.
/// Mhedzisiro yekuwedzera `debug_assert!` inogara iri mhando yakaongororwa.
///
/// Chirevo chisina kuongororwa chinotendera chirongwa munzvimbo isingawirirane kuti chirambe chichimhanya, icho chinogona kuve nemhedzisiro isingatarisirwe asi hachiunze kusagadzikana chero bedzi izvi zvichingoitika mukodhi yakachengeteka.
///
/// Mari yekuita yekusimbisa, zvisinei, haina kuyerwa nezvakawanda.
/// Kutsiva [`assert!`] ne `debug_assert!` saka zvinongokurudzirwa mushure mekunyatso profiling, uye zvakanyanya kukosha, chete mune yakachengeteka kodhi!
///
/// # Examples
///
/// ```
/// // iyo panic meseji yezvezvirevo kukosha kwakatemerwa kwechirevo chakapihwa.
/////
/// debug_assert!(true);
///
/// fn some_expensive_computation() -> bool { true } // basa rakareruka
/// debug_assert!(some_expensive_computation());
///
/// // simbisa neyakajairwa meseji
/// let x = true;
/// debug_assert!(x, "x wasn't true!");
///
/// let a = 3; let b = 27;
/// debug_assert!(a + b == 30, "a = {}, b = {}", a, b);
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "debug_assert_macro"]
macro_rules! debug_assert {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert!($($arg)*); })
}

/// Inoisa kuti matauriro maviri akaenzana kune mumwe nemumwe.
///
/// Pa panic, iyi macro ichapurinda hunhu hwezvirevo nemamiriri avo ekugadzirisa.
///
/// Kusiyana ne [`assert_eq!`], zvirevo zve `debug_assert_eq!` zvinongogoneswa mune zvisina kugadziriswa zvinovaka nekutadza.
/// Chivakwa chakakwenenzverwa hachiite zvirevo zve `debug_assert_eq!` kunze kwekunge `-C debug-assertions` yapfuudzwa kumusanganisi.
/// Izvi zvinoita kuti `debug_assert_eq!` ibatsire macheki ayo anodhura zvakanyanya kuvepo mukuburitsa kuvaka asi inogona kubatsira panguva yekuvandudza.
///
/// Mhedzisiro yekuwedzera `debug_assert_eq!` inogara iri mhando yakaongororwa.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// debug_assert_eq!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! debug_assert_eq {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_eq!($($arg)*); })
}

/// Inoisa kuti matauriro maviri haana kuenzana.
///
/// Pa panic, iyi macro ichapurinda hunhu hwezvirevo nemamiriri avo ekugadzirisa.
///
/// Kusiyana ne [`assert_ne!`], zvirevo zve `debug_assert_ne!` zvinongogoneswa mune zvisina kugadziriswa zvinovaka nekutadza.
/// Chivakwa chakakwenenzverwa hachiite zvirevo zve `debug_assert_ne!` kunze kwekunge `-C debug-assertions` yapfuudzwa kumusanganisi.
/// Izvi zvinoita kuti `debug_assert_ne!` ibatsire macheki ayo anodhura zvakanyanya kuvepo mukuburitsa kuvaka asi inogona kubatsira panguva yekuvandudza.
///
/// Mhedzisiro yekuwedzera `debug_assert_ne!` inogara iri mhando yakaongororwa.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// debug_assert_ne!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
macro_rules! debug_assert_ne {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_ne!($($arg)*); })
}

/// Inodzosera kana chirevo chakapihwa chichienderana nechero ipi yemhando dzakapihwa.
///
/// Senge mukutaura kwe `match`, iyo pateni inogona kuteverwa nesarudzo ne `if` uye chirevo chevarindi chine mukana wezita rakasungwa nepateni.
///
///
/// # Examples
///
/// ```
/// let foo = 'f';
/// assert!(matches!(foo, 'A'..='Z' | 'a'..='z'));
///
/// let bar = Some(4);
/// assert!(matches!(bar, Some(x) if x > 2));
/// ```
#[macro_export]
#[stable(feature = "matches_macro", since = "1.42.0")]
macro_rules! matches {
    ($expression:expr, $( $pattern:pat )|+ $( if $guard: expr )? $(,)?) => {
        match $expression {
            $( $pattern )|+ $( if $guard )? => true,
            _ => false
        }
    }
}

/// Inoputira mhedzisiro kana kuparadzira kukanganisa kwayo.
///
/// Anoshanda we `?` akawedzerwa kutsiva `try!` uye inofanira kushandiswa pachinzvimbo.
/// Uyezve, `try` ishoko rakachengetedzwa mu Rust 2018, saka kana uchifanira kurishandisa, uchafanira kushandisa [raw-identifier syntax][ris]: `r#try`.
///
///
/// [ris]: https://doc.rust-lang.org/nightly/rust-by-example/compatibility/raw_identifiers.html
///
/// `try!` inowirirana yakapihwa [`Result`].Muchiitiko cheiyo `Ok` musiyano, chirevo chine kukosha kweiyo yakaputirwa kukosha.
///
/// Mukana wekusiyana kwe `Err`, inowana iko kukanganisa kwemukati.`try!` inozoita shanduko ichishandisa `From`.
/// Izvi zvinopa otomatiki kutendeuka pakati pehunyanzvi zvikanganiso uye zvimwe zvakajairika iwo.
/// Iko kukanganisa kunoguma kunobva kwadzoserwa ipapo.
///
/// Nekuda kwekutanga kudzoka, `try!` inogona chete kushandiswa mumabasa anodzosa [`Result`].
///
/// # Examples
///
/// ```
/// use std::io;
/// use std::fs::File;
/// use std::io::prelude::*;
///
/// enum MyError {
///     FileWriteError
/// }
///
/// impl From<io::Error> for MyError {
///     fn from(e: io::Error) -> MyError {
///         MyError::FileWriteError
///     }
/// }
///
/// // Nzira yakasarudzika yekukurumidza kudzosa Zvikanganiso
/// fn write_to_file_question() -> Result<(), MyError> {
///     let mut file = File::create("my_best_friends.txt")?;
///     file.write_all(b"This is a list of my best friends.")?;
///     Ok(())
/// }
///
/// // Iyo yapfuura nzira yekukurumidza kudzosa Zvikanganiso
/// fn write_to_file_using_try() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     r#try!(file.write_all(b"This is a list of my best friends."));
///     Ok(())
/// }
///
/// // Izvi zvakaenzana ne:
/// fn write_to_file_using_match() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     match file.write_all(b"This is a list of my best friends.") {
///         Ok(v) => v,
///         Err(e) => return Err(From::from(e)),
///     }
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "1.39.0", reason = "use the `?` operator instead")]
#[doc(alias = "?")]
macro_rules! r#try {
    ($expr:expr $(,)?) => {
        match $expr {
            $crate::result::Result::Ok(val) => val,
            $crate::result::Result::Err(err) => {
                return $crate::result::Result::Err($crate::convert::From::from(err));
            }
        }
    };
}

/// Anonyora data rakamisikidzwa kuita buffer.
///
/// Iyi macro inogamuchira 'writer', fomati tambo, uye runyorwa rwekupokana.
/// Nharo dzinozo fomatwa zvinoenderana neyakatemwa fomati tambo uye mhedzisiro yacho inopfuudzwa kumunyori.
/// Iye munyori anogona kuve chero kukosha ne `write_fmt` nzira;kazhinji izvi zvinobva mukuitwa kweiyo [`fmt::Write`] kana iyo [`io::Write`] trait.
/// Iyo macro inodzosera chero iyo `write_fmt` nzira inodzoka;kazhinji [`fmt::Result`], kana [`io::Result`].
///
/// Ona [`std::fmt`] kuti uwane rumwe ruzivo nezve fomati tambo syntax.
///
/// [`std::fmt`]: ../std/fmt/index.html
/// [`fmt::Write`]: crate::fmt::Write
/// [`io::Write`]: ../std/io/trait.Write.html
/// [`fmt::Result`]: crate::fmt::Result
/// [`io::Result`]: ../std/io/type.Result.html
///
/// # Examples
///
/// ```
/// use std::io::Write;
///
/// fn main() -> std::io::Result<()> {
///     let mut w = Vec::new();
///     write!(&mut w, "test")?;
///     write!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(w, b"testformatted arguments");
///     Ok(())
/// }
/// ```
///
/// Module inogona kuendesa ese ari maviri `std::fmt::Write` uye `std::io::Write` uye inodaidza `write!` pazvinhu zvinoshandisa chero, sezvo zvinhu zvisingawanzo kuita zvese zviri zviviri.
///
/// Nekudaro, module rinofanirwa kuendesa iyo traits inokodzera saka mazita avo haapikisane:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     write!(&mut s, "{} {}", "abc", 123)?; // inoshandisa fmt::Write::write_fmt
///     write!(&mut v, "s = {:?}", s)?; // inoshandisa io::Write::write_fmt
///     assert_eq!(v, b"s = \"abc 123\"");
///     Ok(())
/// }
/// ```
///
/// Note: Iyi macro inogona kushandiswa mu `no_std` setups futi.
/// Mune setup ye `no_std` mune basa rekuita ruzivo rwezvinhu zvacho.
///
/// ```no_run
/// # extern crate core;
/// use core::fmt::Write;
///
/// struct Example;
///
/// impl Write for Example {
///     fn write_str(&mut self, _s: &str) -> core::fmt::Result {
///          unimplemented!();
///     }
/// }
///
/// let mut m = Example{};
/// write!(&mut m, "Hello World").expect("Not written");
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! write {
    ($dst:expr, $($arg:tt)*) => ($dst.write_fmt($crate::format_args!($($arg)*)))
}

/// Nyora yakarongedzwa dhata mune buffer, ine newline yakawedzerwa.
///
/// Pane mapuratifomu ese, iyo newline ndeye LINE FEED hunhu (`\n`/`U+000A`) chete (hapana imwe CARRIAGE RETURN (`\r`/`U+000D`).
///
/// Kuti uwane rumwe ruzivo, ona [`write!`].Kuti uwane ruzivo nezve fomati tambo syntax, ona [`std::fmt`].
///
/// [`std::fmt`]: ../std/fmt/index.html
///
/// # Examples
///
/// ```
/// use std::io::{Write, Result};
///
/// fn main() -> Result<()> {
///     let mut w = Vec::new();
///     writeln!(&mut w)?;
///     writeln!(&mut w, "test")?;
///     writeln!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(&w[..], "\ntest\nformatted arguments\n".as_bytes());
///     Ok(())
/// }
/// ```
///
/// Module inogona kuendesa ese ari maviri `std::fmt::Write` uye `std::io::Write` uye inodaidza `write!` pazvinhu zvinoshandisa chero, sezvo zvinhu zvisingawanzo kuita zvese zviri zviviri.
/// Nekudaro, module rinofanirwa kuendesa iyo traits inokodzera saka mazita avo haapikisane:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     writeln!(&mut s, "{} {}", "abc", 123)?; // inoshandisa fmt::Write::write_fmt
///     writeln!(&mut v, "s = {:?}", s)?; // inoshandisa io::Write::write_fmt
///     assert_eq!(v, b"s = \"abc 123\\n\"\n");
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(format_args_nl)]
macro_rules! writeln {
    ($dst:expr $(,)?) => (
        $crate::write!($dst, "\n")
    );
    ($dst:expr, $($arg:tt)*) => (
        $dst.write_fmt($crate::format_args_nl!($($arg)*))
    );
}

/// Inoratidza isingasvikike kodhi.
///
/// Izvi zvinobatsira chero nguva iyo compiler isingakwanise kuona kuti imwe kodhi haigoneke.Semuyenzaniso:
///
/// * Sanganisa maoko nemamiriro ekuchengetedza.
/// * Zvishwe zvinomisa zvine simba.
/// * MaIterator anogumisa zvine simba.
///
/// Kana iko kutsunga kwekuti kodhi isingasvikike kunoratidza kusiri iko, chirongwa chinobva chapera ne [`panic!`].
///
/// Iye asina kuchengeteka mumwe weiyi macro ibasa re [`unreachable_unchecked`], rinozokonzeresa kusanzwisisika maitiro kana kodhi yasvika.
///
///
/// [`unreachable_unchecked`]: crate::hint::unreachable_unchecked
///
/// # Panics
///
/// Izvi zvinogara zviri [`panic!`].
///
/// # Examples
///
/// Match maoko:
///
/// ```
/// # #[allow(dead_code)]
/// fn foo(x: Option<i32>) {
///     match x {
///         Some(n) if n >= 0 => println!("Some(Non-negative)"),
///         Some(n) if n <  0 => println!("Some(Negative)"),
///         Some(_)           => unreachable!(), // compile kukanganisa kana zvataurwa kunze
///         None              => println!("None")
///     }
/// }
/// ```
///
/// Iterators:
///
/// ```
/// # #[allow(dead_code)]
/// fn divide_by_three(x: u32) -> u32 { // kumwe kwehurombo hwekushandisa kwe x/3
///     for i in 0.. {
///         if 3*i < i { panic!("u32 overflow"); }
///         if x < 3*i { return i-1; }
///     }
///     unreachable!();
/// }
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unreachable {
    () => ({
        $crate::panic!("internal error: entered unreachable code")
    });
    ($msg:expr $(,)?) => ({
        $crate::unreachable!("{}", $msg)
    });
    ($fmt:expr, $($arg:tt)*) => ({
        $crate::panic!($crate::concat!("internal error: entered unreachable code: ", $fmt), $($arg)*)
    });
}

/// Inoratidza isina kumisikidzwa kodhi nekuvhunduka ine meseji ye "not implemented".
///
/// Izvi zvinobvumidza kodhi yako kunyora-kutarisa, iyo inobatsira kana uri prototyping kana kushandisa trait inoda nzira dzakawanda dzausina kuronga kushandisa dzese.
///
/// Musiyano uripo pakati pe `unimplemented!` ne [`todo!`] ndewekuti kunyange `todo!` ichiratidza chinangwa chekushandisa mashandiro gare gare uye meseji iri "not yet implemented", `unimplemented!` haitaure zvakadaro.
/// Meseji yacho i "not implemented".
/// Zvakare mamwe maIDE anoisa mucherechedzo `todo!` S.
///
/// # Panics
///
/// Izvi zvinogara zviri [`panic!`] nekuti `unimplemented!` ingori shorthand ye `panic!` ine yakatarwa, yakatarwa meseji.
///
/// Sa `panic!`, iyi macro ine yechipiri fomu yekuratidza tsika tsika.
///
/// # Examples
///
/// Iti tine trait `Foo`:
///
/// ```
/// trait Foo {
///     fn bar(&self) -> u8;
///     fn baz(&self);
///     fn qux(&self) -> Result<u64, ()>;
/// }
/// ```
///
/// Tinoda kushandisa `Foo` ye 'MyStruct', asi nekuda kwechimwe chikonzero zvinongonzwisisika kuita basa re `bar()`.
/// `baz()` uye `qux()` icharamba ichida kutsanangurwa mukuitwa kwedu kwe `Foo`, asi isu tinogona kushandisa `unimplemented!` mumadudziro avo kubvumira kodhi yedu kuumbika.
///
/// Isu tichiri kuda kuti chirongwa chedu chimire kumhanya kana nzira dzisina kumisikidzwa dzikasvika.
///
/// ```
/// # trait Foo {
/// #     fn bar(&self) -> u8;
/// #     fn baz(&self);
/// #     fn qux(&self) -> Result<u64, ()>;
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) -> u8 {
///         1 + 1
///     }
///
///     fn baz(&self) {
///         // Hazvina musoro ku `baz` `MyStruct`, saka hatina pfungwa pano zvachose.
/////
///         // Izvi zvicharatidza "thread 'main' panicked at 'not implemented'".
///         unimplemented!();
///     }
///
///     fn qux(&self) -> Result<u64, ()> {
///         // Tine imwe pfungwa pano, Tinogona kuwedzera meseji kune isina kuzadzikiswa!kuratidza kusiiwa kwedu.
///         // Izvi zvicharatidza: "thread 'main' panicked at 'not implemented: MyStruct isn't quxable'".
/////
/////
///         unimplemented!("MyStruct isn't quxable");
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
/// }
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unimplemented {
    () => ($crate::panic!("not implemented"));
    ($($arg:tt)+) => ($crate::panic!("not implemented: {}", $crate::format_args!($($arg)+)));
}

/// Inoratidza kodhi isina kupera.
///
/// Izvi zvinogona kubatsira kana iwe uri prototyping uye uri kungotarisa kuve neyako kodhi typecheck.
///
/// Musiyano uripo pakati pe [`unimplemented!`] ne `todo!` ndewekuti kunyange `todo!` ichiratidza chinangwa chekushandisa mashandiro gare gare uye meseji iri "not yet implemented", `unimplemented!` haitaure zvakadaro.
/// Meseji yacho i "not implemented".
/// Zvakare mamwe maIDE anoisa mucherechedzo `todo!` S.
///
/// # Panics
///
/// Izvi zvinogara zviri [`panic!`].
///
/// # Examples
///
/// Heino muenzaniso weimwe-yekufambira mberi kodhi.Tine trait `Foo`:
///
/// ```
/// trait Foo {
///     fn bar(&self);
///     fn baz(&self);
/// }
/// ```
///
/// Tinoda kushandisa `Foo` pane imwe yemhando dzedu, asi tinodawo kushanda pa `bar()` chete kutanga.Kuti kodhi yedu inyorwe, tinofanirwa kushandisa `baz()`, kuti tikwanise kushandisa `todo!`:
///
/// ```
/// # trait Foo {
/// #     fn bar(&self);
/// #     fn baz(&self);
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) {
///         // kuitiswa kunoenda pano
///     }
///
///     fn baz(&self) {
///         // ngatirege kunetseka nezvekushandisa baz() ikozvino
///         todo!();
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
///
///     // isu hatisi kunyangwe kushandisa baz(), saka izvi zvakanaka.
/// }
/// ```
///
///
///
///
#[macro_export]
#[stable(feature = "todo_macro", since = "1.40.0")]
macro_rules! todo {
    () => ($crate::panic!("not yet implemented"));
    ($($arg:tt)+) => ($crate::panic!("not yet implemented: {}", $crate::format_args!($($arg)+)));
}

/// Tsanangudzo dzeakavakirwa-mukati macro.
///
/// Mazhinji macro zvivakwa (kugadzikana, kuoneka, nezvimwewo) zvinotorwa kubva kune sosi kodhi pano, kunze kwekuwedzera mabasa ekushandura macro kupinda mune zvinobuda, iwo mabasa anopihwa neyekugadzira.
///
///
pub(crate) mod builtin {

    /// Zvinokonzera kusangana kutadza neakapihwa meseji yekukanganisa kana wasangana.
    ///
    /// Iyi macro inofanirwa kushandiswa kana crate ikashandisa nzira yekuunganidza yakasarudzika kupa zvirinani mameseji ekukanganisa emamiriro asina kunaka.
    ///
    /// Ndiyo compiler-level fomu ye [`panic!`], asi inoburitsa chikanganiso panguva ye *kuunganidzwa* kwete pane *nguva yekumhanya*.
    ///
    /// # Examples
    ///
    /// Mienzaniso miviri yakadaro macros uye `#[cfg]` nharaunda.
    ///
    /// Emit zvirinani compiler kukanganisa kana macro ikapasiswa zvisingaite kukosha.
    /// Pasina yekupedzisira branch, muunganidzi aigona kuramba achiburitsa chikanganiso, asi meseji yekanganiso yaisazotaura nezvemaitiro maviri anoshanda.
    ///
    /// ```compile_fail
    /// macro_rules! give_me_foo_or_bar {
    ///     (foo) => {};
    ///     (bar) => {};
    ///     ($x:ident) => {
    ///         compile_error!("This macro only accepts `foo` or `bar`");
    ///     }
    /// }
    ///
    /// give_me_foo_or_bar!(neither);
    /// // ^ will fail at compile time with message "This macro only accepts `foo` or `bar`"
    /// ```
    ///
    /// Emit compiler kukanganisa kana chimwe chezvinhu zvinoverengeka chisipo.
    ///
    /// ```compile_fail
    /// #[cfg(not(any(feature = "foo", feature = "bar")))]
    /// compile_error!("Either feature \"foo\" or \"bar\" must be enabled for this crate.");
    /// ```
    ///
    #[stable(feature = "compile_error_macro", since = "1.20.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! compile_error {
        ($msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Inogadzira parameter yeimwe tambo-fomati macros.
    ///
    /// Aya macro anoshanda nekutora fomati tambo chaiyo ine `{}` yenharo yega yega yekuwedzera yakapfuudzwa.
    /// `format_args!` inogadzirira mamwe maparamende kuona kuti chinobuda chinogona kududzirwa senge tambo uye canonicalize nharo dzacho kuva mhando imwe.
    /// Chero ipi kukosha iyo inoshandisa iyo [`Display`] trait inogona kupfuudzwa kuenda ku `format_args!`, sekugona chero [`Debug`] kuitiswa kungapfuudzwa kune `{:?}` mukati meiyo tambo yekumisikidza.
    ///
    ///
    /// Iyi macro inogadzira kukosha kwerudzi [`fmt::Arguments`].Iko kukosha kunogona kupfuudzwa kune macro mukati me [`std::fmt`] yekuita kunobatsira redirection.
    /// Mamwe ese mafomati macros ([`fomati!`], [`write!`], [`println!`], nezvimwewo) akafanirwa kuburikidza neiyi.
    /// `format_args!`, kusiyana nemacros ayo akatorwa, inodzivirira kugoverwa kwemirwi.
    ///
    /// Unogona kushandisa iyo [`fmt::Arguments`] kukosha iyo `format_args!` inodzoka mu `Debug` uye `Display` mamiriro sezvinoonekwa pazasi.
    /// Muenzaniso unoratidza zvakare kuti `Debug` uye `Display` fomati kuchinhu chimwe chete: tambo yakadomwa fomati mu `format_args!`.
    ///
    /// ```rust
    /// let debug = format!("{:?}", format_args!("{} foo {:?}", 1, 2));
    /// let display = format!("{}", format_args!("{} foo {:?}", 1, 2));
    /// assert_eq!("1 foo 2", display);
    /// assert_eq!(display, debug);
    /// ```
    ///
    /// Kuti uwane rumwe ruzivo, ona zvinyorwa mu [`std::fmt`].
    ///
    /// [`Display`]: crate::fmt::Display
    /// [`Debug`]: crate::fmt::Debug
    /// [`fmt::Arguments`]: crate::fmt::Arguments
    /// [`std::fmt`]: ../std/fmt/index.html
    /// [`format!`]: ../std/macro.format.html
    /// [`println!`]: ../std/macro.println.html
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// let s = fmt::format(format_args!("hello {}", "world"));
    /// assert_eq!(s, format!("hello {}", "world"));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// Zvakafanana ne `format_args`, asi inowedzera mutsara mutsva pakupedzisira.
    #[unstable(
        feature = "format_args_nl",
        issue = "none",
        reason = "`format_args_nl` is only for internal \
                  language use and is subject to change"
    )]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args_nl {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// Inoongorora nharaunda inoshanduka panguva yekubatanidza.
    ///
    /// Iyi macro ichawedzera kusvika pakukosha kwenzvimbo inonzi nharaunda kusiana panguva yekubatanidza, ichiburitsa chirevo cherudzi `&'static str`.
    ///
    ///
    /// Kana iyo nharaunda inoshanduka isingatsanangurwe, ipapo kukanganisa kwekuunganidzwa kuchaburitswa.
    /// Kuti usaburitse kukanganisa kwekuunganidza, shandisa [`option_env!`] macro pachinzvimbo.
    ///
    /// # Examples
    ///
    /// ```
    /// let path: &'static str = env!("PATH");
    /// println!("the $PATH variable at the time of compiling was: {}", path);
    /// ```
    ///
    /// Unogona kugadzirisa mameseji ekukanganisa nekupfuura tambo separamende yechipiri:
    ///
    /// ```compile_fail
    /// let doc: &'static str = env!("documentation", "what's that?!");
    /// ```
    ///
    /// Kana iyo `documentation` yemamiriro ekunze isina kutsanangurwa, iwe unowana inotevera kukanganisa:
    ///
    /// ```text
    /// error: what's that?!
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
        ($name:expr, $error_msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Nesarudzo inoongorora nharaunda inoshanduka panguva yekubatanidza.
    ///
    /// Kana iyo yakasarudzika yemamiriro ekunze iripo panguva yekubatanidza, izvi zvichawedzera kuita chirevo cherudzi `Option<&'static str>` iyo kukosha kwayo kuri `Some` yemutengo wekusiyana kwezvakatipoteredza.
    /// Kana iyo nharaunda nharaunda isipo, saka izvi zvichawedzera kusvika `None`.
    /// Ona [`Option<T>`][Option] kuti uwane rumwe ruzivo nezverudzi urwu.
    ///
    /// Kokorodzano yenguva yekukanganisa haina kumbobuditswa kana uchishandisa iyi macro zvisinei nekuti iyo nharaunda inoshanduka iripo kana kwete
    ///
    /// # Examples
    ///
    /// ```
    /// let key: Option<&'static str> = option_env!("SECRET_KEY");
    /// println!("the secret key might be: {:?}", key);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! option_env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Inobatanidza zvitupa muchidimbu chimwe.
    ///
    /// Iyi macro inotora chero nhamba yemakomendi akapatsanurwa nekoma, uye inoabatanidza ese kuita rimwe, ichipa chirevo chinova chitsva chitsva.
    /// Ziva kuti hutsanana hunoita kuti zvive zvakadai kuti iyi macro haigone kutora akasiyana emuno.
    /// Zvakare, sekutonga kwese, macro anotenderwa chete muchinhu, chirevo kana chinongedzo chinzvimbo.
    /// Izvi zvinoreva kuti nepo iwe uchizoshandisa iyi macro yekureva kune aripo akasiyana, mashandiro kana ma module nezvimwe, haugone kutsanangura imwe nyowani nayo.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(concat_idents)]
    ///
    /// # fn main() {
    /// fn foobar() -> u32 { 23 }
    ///
    /// let f = concat_idents!(foo, bar);
    /// println!("{}", f());
    ///
    /// // fn concat_idents! (nyowani, mafaro, zita) { }//isingashandiswe nenzira iyi!
    /// # }
    /// ```
    ///
    ///
    ///
    #[unstable(
        feature = "concat_idents",
        issue = "29599",
        reason = "`concat_idents` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat_idents {
        ($($e:ident),+ $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Inobatanidza zvinyorwa mune yakamira tambo chidimbu.
    ///
    /// Iyi macro inotora chero huwandu hwemakoma akaparadzaniswa nemakoma, ichiburitsa chirevo cherudzi `&'static str` iyo inomiririra ese ezvinyorwa zvakabvumidzwa kuruboshwe-kurudyi.
    ///
    ///
    /// Dzakakura uye dzinoyangarara poindi zvinyorwa zvakasunganidzwa kuitira kuti zvibatanidzwe.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = concat!("test", 10, 'b', true);
    /// assert_eq!(s, "test10btrue");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat {
        ($($e:expr),* $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Inowedzera kune iyo nhamba yemutsetse payakadhonzwa.
    ///
    /// Iine [`column!`] uye [`file!`], aya macros anopa ruzivo rwekugadzirisa ruzivo kune vanogadzira nezvenzvimbo iri mukati maro.
    ///
    /// Chirevo chakakudziridzwa chine mhando `u32` uye iri 1-based, saka mutsetse wekutanga mune yega yega faira unoongorora kusvika 1, wechipiri kusvika 2, nezvimwe
    /// Izvi zvinoenderana nekanganiso mameseji neakajairwa macomputer kana akakurumbira edhita.
    /// Mutsara wakadzoserwa hausi iwo * mutsetse weiyo `line!` kukumbira pachayo, asi panzvimbo yekutanga macro kukumbira kunotungamira mukukumbira kwe `line!` macro.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_line = line!();
    /// println!("defined on line: {}", current_line);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! line {
        () => {
            /* compiler built-in */
        };
    }

    /// Inowedzera kune iyo nhamba yekoramu payakange yakumbirwa.
    ///
    /// Iine [`line!`] uye [`file!`], aya macros anopa ruzivo rwekugadzirisa ruzivo kune vanogadzira nezvenzvimbo iri mukati maro.
    ///
    /// Chirevo chakawedzerwa chine mhando `u32` uye chiri 1-based, saka yekutanga ikholamu mumutsara wega wega inoongorora kusvika pa1, yechipiri kusvika pa2, nezvimwe.
    /// Izvi zvinoenderana nekanganiso mameseji neakajairwa macomputer kana akakurumbira edhita.
    /// Iyo yakadzoserwa ikholamu *haidi* mutsetse weiyo `column!` kukumbira pachayo, asi panzvimbo pekutanga macro kukumbira kunotungamira mukukumbira kwe `column!` macro.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_col = column!();
    /// println!("defined on column: {}", current_col);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! column {
        () => {
            /* compiler built-in */
        };
    }

    /// Inowedzera kune iro zita refaira mairi raakakumbira.
    ///
    /// Iine [`line!`] uye [`column!`], aya macros anopa ruzivo rwekugadzirisa ruzivo kune vanogadzira nezvenzvimbo iri mukati maro.
    ///
    /// Chirevo chakawedzerwa chine mhando `&'static str`, uye iyo faira rakadzoserwa haisi iyo kukumbira kwe `file!` macro pachayo, asi panzvimbo yekutanga macro kukumbira kunotungamira mukukumbira kwe `file!` macro.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let this_file = file!();
    /// println!("defined in file: {}", this_file);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! file {
        () => {
            /* compiler built-in */
        };
    }

    /// Inoomesa nharo dzayo.
    ///
    /// Iyi macro ichaburitsa chirevo cherudzi `&'static str` inova kurongedzwa kwe tokens dzese dzakapfuudzwa kumacro.
    /// Hapana zvirambidzo zvinoiswa pane syntax yeiyo macro kukumbira pachayo.
    ///
    /// Ziva kuti mhedzisiro yakawedzerwa yekuisa tokens inogona kuchinja mu future.Iwe unofanirwa kuve wakangwarira kana iwe uchivimba nezvinobuda.
    ///
    /// # Examples
    ///
    /// ```
    /// let one_plus_one = stringify!(1 + 1);
    /// assert_eq!(one_plus_one, "1 + 1");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! stringify {
        ($($t:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Inosanganisira iyo UTF-8 yakavharirwa faira setambo.
    ///
    /// Iyo faira inowanikwa maererano neiyo yazvino faira (zvakafanana nema module anowanikwa).
    /// Iyo nzira yakapihwa inodudzirwa nenzira yeplatform-yakatarwa panguva yekubatanidza.
    /// Nekudaro, semuenzaniso, kukumbira ine nzira ye Windows ine backslashes `\` yaisazoungana nemazvo pa Unix.
    ///
    ///
    /// Iyi macro ichaburitsa kutaura kwerudzi `&'static str` zvinova zviri mukati mefaira.
    ///
    /// # Examples
    ///
    /// Fungidzira kuti pane mafaera maviri mune dhairekitori imwechete ine zvinotevera zvirimo:
    ///
    /// Faira 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// Faira 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_str = include_str!("spanish.in");
    ///     assert_eq!(my_str, "adiós\n");
    ///     print!("{}", my_str);
    /// }
    /// ```
    ///
    /// Kunyora 'main.rs' uye kumhanyisa kunoguma binary kunopurinda "adiós".
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_str {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Inosanganisira iyo faira sereferenzi kune byte rondedzero.
    ///
    /// Iyo faira inowanikwa maererano neiyo yazvino faira (zvakafanana nema module anowanikwa).
    /// Iyo nzira yakapihwa inodudzirwa nenzira yeplatform-yakatarwa panguva yekubatanidza.
    /// Nekudaro, semuenzaniso, kukumbira ine nzira ye Windows ine backslashes `\` yaisazoungana nemazvo pa Unix.
    ///
    ///
    /// Iyi macro ichaburitsa kutaura kwerudzi `&'static [u8; N]` zvinova zviri mukati mefaira.
    ///
    /// # Examples
    ///
    /// Fungidzira kuti pane mafaera maviri mune dhairekitori imwechete ine zvinotevera zvirimo:
    ///
    /// Faira 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// Faira 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let bytes = include_bytes!("spanish.in");
    ///     assert_eq!(bytes, b"adi\xc3\xb3s\n");
    ///     print!("{}", String::from_utf8_lossy(bytes));
    /// }
    /// ```
    ///
    /// Kunyora 'main.rs' uye kumhanyisa kunoguma binary kunopurinda "adiós".
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_bytes {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Inowedzera kune tambo inomiririra yazvino module nzira.
    ///
    /// Iyo yazvino module nzira inogona kufungidzirwa sehukuru hwema module anotungamira kumashure kusvika ku crate root.
    /// Chinhu chekutanga chemugwagwa wakadzorerwa izita re crate parizvino iri kunyorwa.
    ///
    /// # Examples
    ///
    /// ```
    /// mod test {
    ///     pub fn foo() {
    ///         assert!(module_path!().ends_with("test"));
    ///     }
    /// }
    ///
    /// test::foo();
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! module_path {
        () => {
            /* compiler built-in */
        };
    }

    /// Inoongorora maboolean musanganiswa wekugadzirisa mireza panguva yekubatanidza-nguva.
    ///
    /// Pamusoro peiyo `#[cfg]` hunhu, iyi macro inopihwa kubvumidza boolean expression expression yekugadzirisa mireza.
    /// Izvi zvinowanzo tungamira kune yakaderera kopi kodhi.
    ///
    /// Iyo syntax yakapihwa iyi macro yakafanana syntax seye [`cfg`] hunhu.
    ///
    /// `cfg!`, kusiyana ne `#[cfg]`, haibvise chero kodhi uye inongotarisa kune yechokwadi kana kwenhema.
    /// Semuenzaniso, mabhuroko ese muchirevo che if/else anoda kuve anoshanda kana `cfg!` ichishandiswa pamamiriro acho, zvisinei nekuti `cfg!` iri kuongorora chii.
    ///
    ///
    /// [`cfg`]: ../reference/conditional-compilation.html#the-cfg-attribute
    ///
    /// # Examples
    ///
    /// ```
    /// let my_directory = if cfg!(windows) {
    ///     "windows-specific-directory"
    /// } else {
    ///     "unix-directory"
    /// };
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! cfg {
        ($($cfg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Anocherekedza faira sekutaura kana chinhu zvinoenderana nemamiriro ezvinhu.
    ///
    /// Iyo faira inowanikwa maererano neiyo yazvino faira (zvakafanana nema module anowanikwa).Iyo nzira yakapihwa inodudzirwa nenzira yeplatform-yakatarwa panguva yekubatanidza.
    /// Nekudaro, semuenzaniso, kukumbira ine nzira ye Windows ine backslashes `\` yaisazoungana nemazvo pa Unix.
    ///
    /// Kushandisa iyi macro kazhinji iri zano rakaipa, nekuti kana iyo faira ikapatsanurwa sechirevo, ichaiswa mukodhi yakakomberedza zvisina hunhu.
    /// Izvi zvinogona kukonzeresa misiyano kana mashandiro kuve akasiyana neizvo faira raitarisira kana paine misiyano kana mabasa ane zita rimwe chete mufaira razvino.
    ///
    ///
    /// # Examples
    ///
    /// Fungidzira kuti pane mafaera maviri mune dhairekitori imwechete ine zvinotevera zvirimo:
    ///
    /// Faira 'monkeys.in':
    ///
    /// ```ignore (only-for-syntax-highlight)
    /// ['🙈', '🙊', '🙉']
    ///     .iter()
    ///     .cycle()
    ///     .take(6)
    ///     .collect::<String>()
    /// ```
    ///
    /// Faira 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_string = include!("monkeys.in");
    ///     assert_eq!("🙈🙊🙉🙈🙊🙉", my_string);
    ///     println!("{}", my_string);
    /// }
    /// ```
    ///
    /// Kunyora 'main.rs' uye kumhanyisa kunoguma binary kunopurinda "🙈🙊🙉🙈🙊🙉".
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Inotsigira kuti boolean expression ndeye `true` panguva yekumhanya.
    ///
    /// Izvi zvinokumbira iyo [`panic!`] macro kana chirevo chakapihwa chisingakwanise kuongororwa kusvika `true` panguva yekumhanya.
    ///
    /// # Uses
    ///
    /// Assertions anogara achitariswa mune zvese debug uye kuburitsa inovaka, uye haigone kuremadzwa.
    /// Ona [`debug_assert!`] yezvirevo zvisingabvumirwe mukuburitsa inovaka nekutadza.
    ///
    /// Kodhi isina kuchengetedzeka inogona kuvimba ne `assert!` kuti isimbise zvinomhanyisa-nguva zvinopinda izvo, kana zvikatyorwa zvinogona kutungamira mukusagadzikana.
    ///
    /// Zvimwe zvekushandisa-zviitiko zve `assert!` zvinosanganisira kuyedza uye kumisikidza vanomhanya-nguva vanopinda mune yakachengeteka kodhi (iyo kutyora hakugone kukonzeresa kusagadzikana).
    ///
    ///
    /// # Tsika Meseji
    ///
    /// Iyi macro ine fomu yechipiri, uko yetsika panic meseji inogona kupihwa pamwe kana pasina nharo dzekuomesa.
    /// Ona [`std::fmt`] ye syntax yefomu iyi.
    /// Mashoko anoshandiswa semafomati mafomati anozoongororwa chete kana chirevo chikatadza.
    ///
    /// [`std::fmt`]: ../std/fmt/index.html
    ///
    /// # Examples
    ///
    /// ```
    /// // iyo panic meseji yezvezvirevo kukosha kwakatemerwa kwechirevo chakapihwa.
    /////
    /// assert!(true);
    ///
    /// fn some_computation() -> bool { true } // basa rakareruka
    ///
    /// assert!(some_computation());
    ///
    /// // simbisa neyakajairwa meseji
    /// let x = true;
    /// assert!(x, "x wasn't true!");
    ///
    /// let a = 3; let b = 27;
    /// assert!(a + b == 30, "a = {}, b = {}", a, b);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    #[rustc_diagnostic_item = "assert_macro"]
    #[allow_internal_unstable(core_panic, edition_panic)]
    macro_rules! assert {
        ($cond:expr $(,)?) => {{ /* compiler built-in */ }};
        ($cond:expr, $($arg:tt)+) => {{ /* compiler built-in */ }};
    }

    /// Inline gungano.
    ///
    /// Verenga iyo [unstable book] yekushandisa.
    ///
    /// [unstable book]: ../unstable-book/library-features/asm.html
    #[unstable(
        feature = "asm",
        issue = "72016",
        reason = "inline assembly is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! asm {
        ("assembly template",
            $(operands,)*
            $(options($(option),*))?
        ) => {
            /* compiler built-in */
        };
    }

    /// LLVM-style inline musangano.
    ///
    /// Verenga iyo [unstable book] yekushandisa.
    ///
    /// [unstable book]: ../unstable-book/library-features/llvm-asm.html
    #[unstable(
        feature = "llvm_asm",
        issue = "70173",
        reason = "prefer using the new asm! syntax instead"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! llvm_asm {
        ("assembly template"
                        : $("output"(operand),)*
                        : $("input"(operand),)*
                        : $("clobbers",)*
                        : $("options",)*) => {
            /* compiler built-in */
        };
    }

    /// Module-nhanho inline musangano.
    #[unstable(
        feature = "global_asm",
        issue = "35119",
        reason = "`global_asm!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! global_asm {
        ("assembly") => {
            /* compiler built-in */
        };
    }

    /// Prints dzakapasa tokens mune yakajairwa kuburitsa.
    #[unstable(
        feature = "log_syntax",
        issue = "29598",
        reason = "`log_syntax!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! log_syntax {
        ($($arg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Inoita kana kuremadza kutsvaga mashandiro anoshandiswa kugadzirisa mamwe macro.
    #[unstable(
        feature = "trace_macros",
        issue = "29598",
        reason = "`trace_macros` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! trace_macros {
        (true) => {{ /* compiler built-in */ }};
        (false) => {{ /* compiler built-in */ }};
    }

    /// Ipa macro anoshandiswa kuisa zvinowana macros.
    #[cfg(not(bootstrap))]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    pub macro derive($item:item) {
        /* compiler built-in */
    }

    /// Ipa macro anoshandiswa kune basa kuti riishandure kuita yuniti bvunzo.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test($item:item) {
        /* compiler built-in */
    }

    /// Ipa macro anoshandiswa kune basa kuti riishandure muyedzo yekuyera.
    #[unstable(
        feature = "test",
        issue = "50297",
        soft,
        reason = "`bench` is a part of custom test frameworks which are unstable"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro bench($item:item) {
        /* compiler built-in */
    }

    /// Tsananguro yekumisikidza ye `#[test]` uye `#[bench]` macros.
    #[unstable(
        feature = "custom_test_frameworks",
        issue = "50297",
        reason = "custom test frameworks are an unstable feature"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test_case($item:item) {
        /* compiler built-in */
    }

    /// Ipa macro anoshandiswa kune yakamira kuti uinyore seyakagoverwa yepasirese.
    ///
    /// Onawo [`std::alloc::GlobalAlloc`](../std/alloc/trait.GlobalAlloc.html).
    #[stable(feature = "global_allocator", since = "1.28.0")]
    #[allow_internal_unstable(rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro global_allocator($item:item) {
        /* compiler built-in */
    }

    /// Inochengeta chinhu chayakashandisirwa kana iyo nzira yakapfuura ichiwanika, uye yoibvisa neimwe nzira.
    #[unstable(
        feature = "cfg_accessible",
        issue = "64797",
        reason = "`cfg_accessible` is not fully implemented"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_accessible($item:item) {
        /* compiler built-in */
    }

    /// Inowedzera ese `#[cfg]` uye `#[cfg_attr]` hunhu mune kodhi chidimbu icho chayashandiswa.
    #[cfg(not(bootstrap))]
    #[unstable(
        feature = "cfg_eval",
        issue = "82679",
        reason = "`cfg_eval` is a recently implemented feature"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_eval($($tt:tt)*) {
        /* compiler built-in */
    }

    /// Isina kugadzikana yekuita tsananguro yeiyo `rustc` compiler, usashandise.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics, libstd_sys_internals)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcDecodable($item:item) {
        /* compiler built-in */
    }

    /// Isina kugadzikana yekuita tsananguro yeiyo `rustc` compiler, usashandise.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcEncodable($item:item) {
        /* compiler built-in */
    }
}