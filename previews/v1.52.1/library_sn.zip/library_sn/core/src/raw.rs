#![allow(missing_docs)]
#![unstable(feature = "raw", issue = "27751")]

//! Iine tsananguro dzekumisikidzwa kwemakomputa akavakirwa-mukati mhando.
//!
//! Dzinogona kushandiswa sezvinangwa zvekupfuudza mukodhi isina kuchengetedzeka yekumiririra zvakamiririrwa zvisizvo.
//!
//!
//! Tsananguro yavo inofanirwa kugara ichienderana neABI inotsanangurwa mu `rustc_middle::ty::layout`.
//!

/// Mumiriri we trait chinhu senge `&dyn SomeTrait`.
///
/// Ichi chimiro chine marongerwo akafanana nemhando senge `&dyn SomeTrait` uye `Box<dyn AnotherTrait>`.
///
/// `TraitObject` inovimbiswa kuenzanisa marongero, asi haisi iyo mhando ye trait zvinhu (semuenzaniso, minda yacho haisvikike zvakananga pa `&dyn SomeTrait`) uye haina kudzora marongero iwayo (kuchinja dudziro hakuchinje maratidziro e `&dyn SomeTrait`).
///
/// Iyo inongogadzirirwa kuti ishandiswe nekodhi isina kuchengetedzeka iyo inoda kumanikidza iwo ezasi-epamusoro ruzivo.
///
/// Iko hakuna nzira yekureva kune zvese trait zvinhu zvine hunyanzvi, saka nzira chete yekugadzira hunhu hwerudzi urwu ine mabasa senge [`std::mem::transmute`][transmute].
/// Saizvozvo, iyo chete nzira yekugadzira yechokwadi trait chinhu kubva ku `TraitObject` kukosha iri ne `transmute`.
///
/// [transmute]: crate::intrinsics::transmute
///
/// Kugadzira chinhu che trait chine mhando dzisingaenzanisike-imwe iyo vtable isingaenderane nerudzi rwekukosha kunongedzwa nedatha-ingangotungamira kune isina kujekeswa maitiro.
///
/// # Examples
///
/// ```
/// #![feature(raw)]
///
/// use std::{mem, raw};
///
/// // muenzaniso trait
/// trait Foo {
///     fn bar(&self) -> i32;
/// }
///
/// impl Foo for i32 {
///     fn bar(&self) -> i32 {
///          *self + 1
///     }
/// }
///
/// let value: i32 = 123;
///
/// // rega mugadziri aite trait chinhu
/// let object: &dyn Foo = &value;
///
/// // tarisa kumiriri kwakasvibirira
/// let raw_object: raw::TraitObject = unsafe { mem::transmute(object) };
///
/// // iyo data pointer ndiyo kero ye `value`
/// assert_eq!(raw_object.data as *const i32, &value as *const _);
///
/// let other_value: i32 = 456;
///
/// // gadzira chinhu chitsva, uchinongedzera kune yakasarudzika `i32`, uchichenjerera kushandisa iyo `i32` vtable kubva ku `object`
/////
/// let synthesized: &dyn Foo = unsafe {
///      mem::transmute(raw::TraitObject {
///          data: &other_value as *const _ as *mut (),
///          vtable: raw_object.vtable,
///      })
/// };
///
/// // inofanira kushanda sekunge isu tanga tagadzira chinhu trait kunze kwe `other_value` zvakananga
/////
/// assert_eq!(synthesized.bar(), 457);
/// ```
///
///
///
///
///
///
///
///
///
#[repr(C)]
#[derive(Copy, Clone)]
#[allow(missing_debug_implementations)]
pub struct TraitObject {
    pub data: *mut (),
    pub vtable: *mut (),
}