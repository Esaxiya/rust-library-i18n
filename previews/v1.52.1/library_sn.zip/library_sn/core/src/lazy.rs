//! Unhu hwehusimbe uye kutanga-kamwe-nguva kwedata.

use crate::cell::{Cell, UnsafeCell};
use crate::fmt;
use crate::mem;
use crate::ops::Deref;

/// Sero rinogona kunyorwa kamwe chete.
///
/// Kusiyana ne `RefCell`, `OnceCell` inopa chete zvakagovaniswa `&T` mareferenzi kune kukosha kwayo.
/// Kusiyana ne `Cell`, `OnceCell` haidi kutevedzera kana kutsiva kukosha kwekuiwana.
///
/// # Examples
///
/// ```
/// #![feature(once_cell)]
///
/// use std::lazy::OnceCell;
///
/// let cell = OnceCell::new();
/// assert!(cell.get().is_none());
///
/// let value: &String = cell.get_or_init(|| {
///     "Hello, World!".to_string()
/// });
/// assert_eq!(value, "Hello, World!");
/// assert!(cell.get().is_some());
/// ```
#[unstable(feature = "once_cell", issue = "74465")]
pub struct OnceCell<T> {
    // Invariant: yakanyorerwa kune kamwe chete.
    inner: UnsafeCell<Option<T>>,
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T> Default for OnceCell<T> {
    fn default() -> Self {
        Self::new()
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: fmt::Debug> fmt::Debug for OnceCell<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self.get() {
            Some(v) => f.debug_tuple("OnceCell").field(v).finish(),
            None => f.write_str("OnceCell(Uninit)"),
        }
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: Clone> Clone for OnceCell<T> {
    fn clone(&self) -> OnceCell<T> {
        let res = OnceCell::new();
        if let Some(value) = self.get() {
            match res.set(value.clone()) {
                Ok(()) => (),
                Err(_) => unreachable!(),
            }
        }
        res
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: PartialEq> PartialEq for OnceCell<T> {
    fn eq(&self, other: &Self) -> bool {
        self.get() == other.get()
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: Eq> Eq for OnceCell<T> {}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T> From<T> for OnceCell<T> {
    fn from(value: T) -> Self {
        OnceCell { inner: UnsafeCell::new(Some(value)) }
    }
}

impl<T> OnceCell<T> {
    /// Inogadzira sero idzva risina chinhu.
    #[unstable(feature = "once_cell", issue = "74465")]
    pub const fn new() -> OnceCell<T> {
        OnceCell { inner: UnsafeCell::new(None) }
    }

    /// Inowana chirevo kune icho chakakosha kukosha.
    ///
    /// Inodzorera `None` kana sero risina chinhu.
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get(&self) -> Option<&T> {
        // Kachengeteka: Kwakachengeteka nekuda kwe `zvemukati 'zvisingawanzo
        unsafe { &*self.inner.get() }.as_ref()
    }

    /// Inowana iyo inogona kuchinjika kune iyo yepasi kukosha.
    ///
    /// Inodzorera `None` kana sero risina chinhu.
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get_mut(&mut self) -> Option<&mut T> {
        // Kachengeteka: Kwakachengeteka nekuti isu tine yakasarudzika kuwana
        unsafe { &mut *self.inner.get() }.as_mut()
    }

    /// Inoisa zvirimo muchitokisi ku `value`.
    ///
    /// # Errors
    ///
    /// Iyi nzira inodzosera `Ok(())` dai sero rakanga risina chinhu uye `Err(value)` kana yakazara.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell = OnceCell::new();
    /// assert!(cell.get().is_none());
    ///
    /// assert_eq!(cell.set(92), Ok(()));
    /// assert_eq!(cell.set(62), Err(62));
    ///
    /// assert!(cell.get().is_some());
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn set(&self, value: T) -> Result<(), T> {
        // Kachengeteka: Kuchengeteka nekuti isu hatigone kuverengera zvakapatsanuka zvikwereti
        let slot = unsafe { &*self.inner.get() };
        if slot.is_some() {
            return Err(value);
        }

        // Kachengeteka: Iyi ndiyo chete nzvimbo yatinogadzika slot, hapana nhangemutange
        // nekuda kwe reentrancy/concurrency zvinogoneka, uye takaongorora kuti slot parizvino i `None`, saka izvi zvinyorwa zvinochengeta izvo zvemukati zvinogara zvichichinja.
        //
        //
        let slot = unsafe { &mut *self.inner.get() };
        *slot = Some(value);
        Ok(())
    }

    /// Inowana zvirimo muchitokisi, ichizvitangisa ne `f` kana sero rakanga risina chinhu.
    ///
    /// # Panics
    ///
    /// Kana `f` panics, iyo panic inoparidzirwa kune ari kufona, uye sero rinoramba risina kuvhurwa.
    ///
    ///
    /// Iko kukanganisa kutangazve kuisa sero kubva ku `f`.Kuita izvi kunoguma mu panic.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell = OnceCell::new();
    /// let value = cell.get_or_init(|| 92);
    /// assert_eq!(value, &92);
    /// let value = cell.get_or_init(|| unreachable!());
    /// assert_eq!(value, &92);
    /// ```
    ///
    ///
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get_or_init<F>(&self, f: F) -> &T
    where
        F: FnOnce() -> T,
    {
        match self.get_or_try_init(|| Ok::<T, !>(f())) {
            Ok(val) => val,
        }
    }

    /// Inowana zvirimo muchitokisi, ichizvitangisa ne `f` kana sero rakanga risina chinhu.
    /// Kana sero rakanga risina chinhu uye `f` ikakundikana, kukanganisa kunodzorerwa.
    ///
    /// # Panics
    ///
    /// Kana `f` panics, iyo panic inoparidzirwa kune ari kufona, uye sero rinoramba risina kuvhurwa.
    ///
    ///
    /// Iko kukanganisa kutangazve kuisa sero kubva ku `f`.Kuita izvi kunoguma mu panic.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell = OnceCell::new();
    /// assert_eq!(cell.get_or_try_init(|| Err(())), Err(()));
    /// assert!(cell.get().is_none());
    /// let value = cell.get_or_try_init(|| -> Result<i32, ()> {
    ///     Ok(92)
    /// });
    /// assert_eq!(value, Ok(&92));
    /// assert_eq!(cell.get(), Some(&92))
    /// ```
    ///
    ///
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get_or_try_init<F, E>(&self, f: F) -> Result<&T, E>
    where
        F: FnOnce() -> Result<T, E>,
    {
        if let Some(val) = self.get() {
            return Ok(val);
        }
        let val = f()?;
        // Ziva kuti *mamwe* mafomu ereentrant kutanga anogona kutungamira kuUB (ona `reentrant_init` bvunzo).
        // Ini ndinotenda kuti kungobvisa iyi `assert`, uku uchichengeta `set/get` kungave kune mutsindo, asi zvinoita kunge kuri nani ku panic, pane kushandisa chinyararire kukosha kwekare.
        //
        //
        assert!(self.set(val).is_ok(), "reentrant init");
        Ok(self.get().unwrap())
    }

    /// Inoshandisa sero, ichidzosera kukosha kwakaputirwa.
    ///
    /// Inodzorera `None` dai sero rakanga risina chinhu.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell: OnceCell<String> = OnceCell::new();
    /// assert_eq!(cell.into_inner(), None);
    ///
    /// let cell = OnceCell::new();
    /// cell.set("hello".to_string()).unwrap();
    /// assert_eq!(cell.into_inner(), Some("hello".to_string()));
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn into_inner(self) -> Option<T> {
        // Nekuti `into_inner` inotora `self` nemutengo, iyo compiler inosimbisa kuti haina kukweretwa parizvino.
        // Saka zvakachengeteka kubuda `Option<T>`.
        self.inner.into_inner()
    }

    /// Inotora kukosha kunze kweiyi `OnceCell`, ichichidzosera kune isina kuvhurika nyika.
    ///
    /// Haina zvainoita uye inodzosera `None` kana iyo `OnceCell` isati yatangwa.
    ///
    /// Kudzivirirwa kunovimbiswa nekutora chinongedzo chinoshanduka.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let mut cell: OnceCell<String> = OnceCell::new();
    /// assert_eq!(cell.take(), None);
    ///
    /// let mut cell = OnceCell::new();
    /// cell.set("hello".to_string()).unwrap();
    /// assert_eq!(cell.take(), Some("hello".to_string()));
    /// assert_eq!(cell.get(), None);
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn take(&mut self) -> Option<T> {
        mem::take(self).into_inner()
    }
}

/// Iko kukosha kunotangwa pane yekutanga kuwana.
///
/// # Examples
///
/// ```
/// #![feature(once_cell)]
///
/// use std::lazy::Lazy;
///
/// let lazy: Lazy<i32> = Lazy::new(|| {
///     println!("initializing");
///     92
/// });
/// println!("ready");
/// println!("{}", *lazy);
/// println!("{}", *lazy);
///
/// // Prints:
/// //   kugadzirira kutanga
/////
/// //   92
/// //   92
/// ```
#[unstable(feature = "once_cell", issue = "74465")]
pub struct Lazy<T, F = fn() -> T> {
    cell: OnceCell<T>,
    init: Cell<Option<F>>,
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: fmt::Debug, F> fmt::Debug for Lazy<T, F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Lazy").field("cell", &self.cell).field("init", &"..").finish()
    }
}

impl<T, F> Lazy<T, F> {
    /// Inogadzira iyo nyowani kukosha neiyo yakapihwa yekutanga basa.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// # fn main() {
    /// use std::lazy::Lazy;
    ///
    /// let hello = "Hello, World!".to_string();
    ///
    /// let lazy = Lazy::new(|| hello.to_uppercase());
    ///
    /// assert_eq!(&*lazy, "HELLO, WORLD!");
    /// # }
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub const fn new(init: F) -> Lazy<T, F> {
        Lazy { cell: OnceCell::new(), init: Cell::new(Some(init)) }
    }
}

impl<T, F: FnOnce() -> T> Lazy<T, F> {
    /// Inomanikidza kuongororwa kweiyi husimbe kukosha uye inodzosera chirevo kumhedzisiro.
    ///
    ///
    /// Izvi zvakaenzana neiyo `Deref` impl, asi yakajeka.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::Lazy;
    ///
    /// let lazy = Lazy::new(|| 92);
    ///
    /// assert_eq!(Lazy::force(&lazy), &92);
    /// assert_eq!(&*lazy, &92);
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn force(this: &Lazy<T, F>) -> &T {
        this.cell.get_or_init(|| match this.init.take() {
            Some(f) => f(),
            None => panic!("`Lazy` instance has previously been poisoned"),
        })
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T, F: FnOnce() -> T> Deref for Lazy<T, F> {
    type Target = T;
    fn deref(&self) -> &T {
        Lazy::force(self)
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: Default> Default for Lazy<T> {
    /// Inogadzira iyo nyowani kukosha ichishandisa `Default` sebasa rekutanga.
    fn default() -> Lazy<T> {
        Lazy::new(T::default)
    }
}