//! Vanowandisa vanoshanda.
//!
//! Kuteedzera izvi traits inokutendera kuti uremedze vamwe vanoshanda.
//!
//! Zvimwe zve traits zvinotumirwa kunze ne prelude, saka zvinowanikwa mune yega Rust chirongwa.Vashandisi chete vanotsigirwa ne traits vanogona kuzadzikiswa.
//! Semuenzaniso, wekuwedzera opareta (`+`) anogona kuzadzikiswa kuburikidza ne [`Add`] trait, asi sezvo mupi wekupa basa (`=`) asina rutsigiro trait, hapana nzira yekuwandisa masemantiki ayo.
//! Pamusoro pezvo, iyi module haina kupa chero mashandiro ekugadzira vashandisi vatsva.
//! Kana zvisina hunhu hwekuremedza kana vashandisi vetsika vachidikanwa, iwe unofanirwa kutarisa kumacro kana compiler plugins kuti uwedzere syntax ye Rust.
//!
//! Maitikiro eanoshanda traits anofanirwa kunge asingashamise mune yavo mamiriro, vachirangarira zvavangareva zvinoreva uye [operator precedence].
//! Semuenzaniso, kana uchiita [`Mul`], iko kuvhiyiwa kunofanirwa kuve nekwakafanana nekuwanda (uye kugovana zvinotarisirwa zvivakwa senge kushamwaridzana).
//!
//! Ziva kuti `&&` uye `||` vanoshanda vashoma-dunhu, kureva, ivo vanongotarisa yavo yechipiri operand kana ichipa kumhedzisiro.Sezvo hunhu uhwu husingamanikidzwe ne traits, `&&` uye `||` hazvitsigirwe sevashandisi vanowandisa.
//!
//! Vazhinji vevanoshanda vanotora oparesheni yavo nemutengo.Mune zvisirizvo zvakajairika zvinosanganisira zvakavakirwa-mukati mhando, izvi kazhinji hazvisi dambudziko.
//! Nekudaro, kushandisa ava vanoshanda mune generic kodhi, zvinoda kutariswa kana kukosha kuchizoshandiswazve zvichipesana nekurega vanoita vachizvidya.Imwe sarudzo ndeyekuti dzimwe nguva ushandise [`clone`].
//! Imwe sarudzo ndeyekuvimba nemhando dzakabatanidzwa kupa mamwe maitirwo eanoshanda kune mareferenzi.
//! Semuenzaniso, kune yemushandisi-yakatsanangurwa mhando `T` iyo inofanirwa kutsigira kuwedzera, ingangove zano rakanaka kuva nezvose `T` uye `&T` kuita traits [`Add<T>`][`Add`] uye [`Add<&T>`][`Add`] kuitira kuti generic kodhi inogona kunyorwa pasina kudikanwa kwekunamatira.
//!
//!
//! # Examples
//!
//! Uyu muenzaniso unogadzira `Point` struct inoshandisa [`Add`] uye [`Sub`], uyezve inoratidza kuwedzera nekubvisa ma`Point`s maviri.
//!
//! ```rust
//! use std::ops::{Add, Sub};
//!
//! #[derive(Debug, Copy, Clone, PartialEq)]
//! struct Point {
//!     x: i32,
//!     y: i32,
//! }
//!
//! impl Add for Point {
//!     type Output = Self;
//!
//!     fn add(self, other: Self) -> Self {
//!         Self {x: self.x + other.x, y: self.y + other.y}
//!     }
//! }
//!
//! impl Sub for Point {
//!     type Output = Self;
//!
//!     fn sub(self, other: Self) -> Self {
//!         Self {x: self.x - other.x, y: self.y - other.y}
//!     }
//! }
//!
//! assert_eq!(Point {x: 3, y: 3}, Point {x: 1, y: 0} + Point {x: 2, y: 3});
//! assert_eq!(Point {x: -1, y: -3}, Point {x: 1, y: 0} - Point {x: 2, y: 3});
//! ```
//!
//! Ona zvinyorwa zve trait yega yega semuenzaniso kuitisa.
//!
//! [`Fn`], [`FnMut`], uye [`FnOnce`] traits inoitwa nemhando dzinogona kukumbirwa semabasa.Ziva kuti [`Fn`] inotora `&self`, [`FnMut`] inotora `&mut self` uye [`FnOnce`] inotora `self`.
//! Izvi zvinoenderana nemhando nhatu dzenzira dzinogona kukumbirwa pane imwe nhambo: kufona-nereferenzi, kufona-ne-kuchinjika-chirevo, uye kufona-ne-kukosha.
//! Iko kushandiswa kwakanyanya kweiyi traits ndeyekuita semuganho kune epamusoro-chikamu mabasa anotora mabasa kana kuvhara sekupokana.
//!
//! Kutora [`Fn`] separamende:
//!
//! ```rust
//! fn call_with_one<F>(func: F) -> usize
//!     where F: Fn(usize) -> usize
//! {
//!     func(1)
//! }
//!
//! let double = |x| x * 2;
//! assert_eq!(call_with_one(double), 2);
//! ```
//!
//! Kutora [`FnMut`] separamende:
//!
//! ```rust
//! fn do_twice<F>(mut func: F)
//!     where F: FnMut()
//! {
//!     func();
//!     func();
//! }
//!
//! let mut x: usize = 1;
//! {
//!     let add_two_to_x = || x += 2;
//!     do_twice(add_two_to_x);
//! }
//!
//! assert_eq!(x, 5);
//! ```
//!
//! Kutora [`FnOnce`] separamende:
//!
//! ```rust
//! fn consume_with_relish<F>(func: F)
//!     where F: FnOnce() -> String
//! {
//!     // `func` inoshandisa ayo akatorwa akasiyana, saka haigone kumhanyisa kanopfuura kamwe
//!     //
//!     println!("Consumed: {}", func());
//!
//!     println!("Delicious!");
//!
//!     // Kuedza kukumbira `func()` zvakare kunokanda `use of moved value` kukanganisa kwe `func`
//!     //
//! }
//!
//! let x = String::from("x");
//! let consume_and_return_x = move || x;
//! consume_with_relish(consume_and_return_x);
//!
//! // `consume_and_return_x` haichagone kukumbirwa panguva ino
//! ```
//!
//! [`clone`]: Clone::clone
//! [operator precedence]: ../../reference/expressions.html#expression-precedence
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

mod arith;
mod bit;
mod control_flow;
mod deref;
mod drop;
mod function;
mod generator;
mod index;
mod range;
mod r#try;
mod unsize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::arith::{Add, Div, Mul, Neg, Rem, Sub};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::arith::{AddAssign, DivAssign, MulAssign, RemAssign, SubAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::bit::{BitAnd, BitOr, BitXor, Not, Shl, Shr};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::bit::{BitAndAssign, BitOrAssign, BitXorAssign, ShlAssign, ShrAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::deref::{Deref, DerefMut};

#[unstable(feature = "receiver_trait", issue = "none")]
pub use self::deref::Receiver;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::drop::Drop;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::function::{Fn, FnMut, FnOnce};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::index::{Index, IndexMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::range::{Range, RangeFrom, RangeFull, RangeTo};

#[stable(feature = "inclusive_range", since = "1.26.0")]
pub use self::range::{Bound, RangeBounds, RangeInclusive, RangeToInclusive};

#[unstable(feature = "try_trait", issue = "42327")]
pub use self::r#try::Try;

#[unstable(feature = "generator_trait", issue = "43122")]
pub use self::generator::{Generator, GeneratorState};

#[unstable(feature = "coerce_unsized", issue = "27732")]
pub use self::unsize::CoerceUnsized;

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
pub use self::unsize::DispatchFromDyn;

#[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
pub use self::control_flow::ControlFlow;