/// trait yekugadzirisa maitiro eiyo `?` opareta.
///
/// Rudzi rwekushandisa `Try` ndeimwe ine canonical nzira yekuiona maererano ne success/failure dichotomy.
/// Iyi trait inobvumidza zvese kuburitsa iwo ekubudirira kana kukosha kwekutadza kubva pane iripo chiitiko uye kugadzira chiitiko chitsva kubva pakubudirira kana kukosha kwekutadza.
///
///
#[unstable(feature = "try_trait", issue = "42327")]
#[rustc_on_unimplemented(
    on(
        all(
            any(from_method = "from_error", from_method = "from_ok"),
            from_desugaring = "QuestionMark"
        ),
        message = "the `?` operator can only be used in {ItemContext} \
                    that returns `Result` or `Option` \
                    (or another type that implements `{Try}`)",
        label = "cannot use the `?` operator in {ItemContext} that returns `{Self}`",
        enclosing_scope = "this function should return `Result` or `Option` to accept `?`"
    ),
    on(
        all(from_method = "into_result", from_desugaring = "QuestionMark"),
        message = "the `?` operator can only be applied to values \
                    that implement `{Try}`",
        label = "the `?` operator cannot be applied to type `{Self}`"
    )
)]
#[doc(alias = "?")]
#[lang = "try"]
pub trait Try {
    /// Rudzi rweiyi kukosha kana ichionekwa seyakabudirira.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Ok;
    /// Rudzi rweiyi kukosha kana ichionekwa seyakatadza.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Error;

    /// Inoshandisa iyo "?" opareta.Kudzoka kwe `Ok(t)` kunoreva kuti kuuraya kunofanira kuenderera zvakajairika, uye mhedzisiro ye `?` ndiyo kukosha `t`.
    /// Kudzoka kwe `Err(e)` kunoreva kuti kuurayiwa kunofanirwa kuve branch kune iyo yemukati yakavharira `catch`, kana kudzoka kubva kubasa.
    ///
    /// Kana `Err(e)` mhedzisiro ikadzoserwa, kukosha kwe `e` kuchave "wrapped" murudzi rwekudzoka kwenzvimbo yakavharika (iyo inofanirwa pachayo kuita `Try`).
    ///
    /// Kunyanya, kukosha `X::from_error(From::from(e))` kunodzoserwa, uko `X` iri mhando yekudzosa yeiyo yakavharika basa.
    ///
    ///
    ///
    #[lang = "into_result"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn into_result(self) -> Result<Self::Ok, Self::Error>;

    /// Putira kukosha kwekukanganisa kuvaka iyo inosanganiswa mhedzisiro.
    /// Semuenzaniso, `Result::Err(x)` ne `Result::from_error(x)` zvakaenzana.
    #[lang = "from_error"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_error(v: Self::Error) -> Self;

    /// Putira OK kukosha kuti ugadzire iyo yakasanganiswa mhedzisiro.
    /// Semuenzaniso, `Result::Ok(x)` ne `Result::from_ok(x)` zvakaenzana.
    #[lang = "from_ok"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_ok(v: Self::Ok) -> Self;
}