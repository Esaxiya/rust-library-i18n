/// Iyo vhezheni yeanodana opareta iyo inotora isingachinjiki inogamuchira.
///
/// Zviitiko zve `Fn` zvinogona kudaidzwa zvakapetwa pasina kuchinja nyika.
///
/// *Iyi trait (`Fn`) haifanirwe kuvhiringidzwa ne [function pointers] (`fn`).*
///
/// `Fn` inoitwa otomatiki nekuvharwa uko kunongotora mareferenzi asingachinjiki kune akasiyana akabatwa kana kusatora chero chinhu, pamwe ne (safe) [function pointers] (ine mamwe mapako, ona zvinyorwa zvavo kuti uwane rumwe ruzivo).
///
/// Kuwedzera, kune chero mhando `F` inoshandisa `Fn`, `&F` inoshandisa `Fn`, futi.
///
/// Sezvo ese [`FnMut`] uye [`FnOnce`] ari masitoreti e `Fn`, chero chiitiko che `Fn` chinogona kushandiswa separamende panotarisirwa [`FnMut`] kana [`FnOnce`].
///
/// Shandisa `Fn` sekusunga kana iwe uchida kugamuchira paramende yemhando-senge mhando uye unoda kuidana kasingaperi uye pasina kushandura nyika (semuenzaniso, kana uchizvidaidza panguva imwe chete).
/// Kana iwe usingade zvinodiwa zvakanyanya, shandisa [`FnMut`] kana [`FnOnce`] semuganhu.
///
/// Ona iyo [chapter on closures in *The Rust Programming Language*][book] kune rumwe ruzivo pane iyi nyaya.
///
/// Zvakare zvechinyorwa ndeye yakakosha syntax ye `Fn` traits (semuenzaniso
/// `Fn(usize, bool) -> usize`).Ivo vanofarira ruzivo rwehunyanzvi rweizvi vanogona kureva [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Kushevedza kuvhara
///
/// ```
/// let square = |x| x * x;
/// assert_eq!(square(5), 25);
/// ```
///
/// ## Uchishandisa `Fn` paramende
///
/// ```
/// fn call_with_one<F>(func: F) -> usize
///     where F: Fn(usize) -> usize {
///     func(1)
/// }
///
/// let double = |x| x * 2;
/// assert_eq!(call_with_one(double), 2);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{Fn}<{Args}>` closure, found `{Self}`",
    label = "expected an `Fn<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // kuitira kuti regex igone kuvimba ne `&str: !FnMut` iyoyo
#[must_use = "closures are lazy and do nothing unless called"]
pub trait Fn<Args>: FnMut<Args> {
    /// Inoita iko kufona kushanda.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call(&self, args: Args) -> Self::Output;
}

/// Iyo vhezheni yeanodana opareta iyo inotora inogadziriswa inogamuchira.
///
/// Zviitiko zve `FnMut` zvinogona kudaidzwa zvakapetwa uye zvinogona kuchinja nyika.
///
/// `FnMut` inoitwa otomatiki nekuvharwa uko kunotora zvinongedzo zvinoshanduka kune akasiyana akabatwa, pamwe nemhando dzese dzinoshandisa [`Fn`], semuenzaniso, (safe) [function pointers] (sezvo `FnMut` iri supertrait ye [`Fn`]).
/// Kuwedzera, kune chero mhando `F` inoshandisa `FnMut`, `&mut F` inoshandisa `FnMut`, futi.
///
/// Sezvo [`FnOnce`] iri supertrait ye `FnMut`, chero chiitiko che `FnMut` chinogona kushandiswa panotarisirwa [`FnOnce`], uye sezvo [`Fn`] iri chikamu che `FnMut`, chero chiitiko che [`Fn`] chinogona kushandiswa panotarisirwa `FnMut`.
///
/// Shandisa `FnMut` sekusunga kana iwe uchida kugamuchira paramende yemhando-senge mhando uye unoda kuidana ichidzokororwa, uchiibvumira kuti ichinje nyika.
/// Kana iwe usiri kuda kuti paramende ishandure nyika, shandisa [`Fn`] sekusungwa;kana iwe usinga fane kuidaidza kakawanda, shandisa [`FnOnce`].
///
/// Ona iyo [chapter on closures in *The Rust Programming Language*][book] kune rumwe ruzivo pane iyi nyaya.
///
/// Zvakare zvechinyorwa ndeye yakakosha syntax ye `Fn` traits (semuenzaniso
/// `Fn(usize, bool) -> usize`).Ivo vanofarira ruzivo rwehunyanzvi rweizvi vanogona kureva [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Kushevedza mutably Capture kuvhara
///
/// ```
/// let mut x = 5;
/// {
///     let mut square_x = || x *= x;
///     square_x();
/// }
/// assert_eq!(x, 25);
/// ```
///
/// ## Uchishandisa `FnMut` paramende
///
/// ```
/// fn do_twice<F>(mut func: F)
///     where F: FnMut()
/// {
///     func();
///     func();
/// }
///
/// let mut x: usize = 1;
/// {
///     let add_two_to_x = || x += 2;
///     do_twice(add_two_to_x);
/// }
///
/// assert_eq!(x, 5);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn_mut"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnMut}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnMut<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // kuitira kuti regex igone kuvimba ne `&str: !FnMut` iyoyo
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnMut<Args>: FnOnce<Args> {
    /// Inoita iko kufona kushanda.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_mut(&mut self, args: Args) -> Self::Output;
}

/// Iyo vhezheni yeanodana opareta iyo inotora ne-kukosha mugamuchiri.
///
/// Zviitiko zve `FnOnce` zvinogona kudaidzwa, asi zvingangodaro zvisingaite kakawanda.Nekuda kweizvi, kana icho chete chinhu chinozivikanwa nezve mhando ndechekuti inoshandisa `FnOnce`, inogona kungodaidzwa kamwe chete.
///
/// `FnOnce` inoitwa otomatiki nekuvharwa kunogona kutora akasiyana akabatwa, pamwe nemhando dzese dzinoshandisa [`FnMut`], semuenzaniso, (safe) [function pointers] (sezvo `FnOnce` iri supertrait ye [`FnMut`]).
///
///
/// Sezvo zvese zviri zviviri [`Fn`] uye [`FnMut`] zvidhoma zve `FnOnce`, chero chiitiko che [`Fn`] kana [`FnMut`] chinogona kushandiswa panotarisirwa `FnOnce`.
///
/// Shandisa `FnOnce` sekusunga kana iwe uchida kugamuchira paramende yemhando-senge mhando uye unongoda kuidana kamwe chete.
/// Kana iwe uchida kufonera paramende kakawanda, shandisa [`FnMut`] senge yakasungwa;kana iwe uchidawo kuti usachinje nyika, shandisa [`Fn`].
///
/// Ona iyo [chapter on closures in *The Rust Programming Language*][book] kune rumwe ruzivo pane iyi nyaya.
///
/// Zvakare zvechinyorwa ndeye yakakosha syntax ye `Fn` traits (semuenzaniso
/// `Fn(usize, bool) -> usize`).Ivo vanofarira ruzivo rwehunyanzvi rweizvi vanogona kureva [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Uchishandisa `FnOnce` paramende
///
/// ```
/// fn consume_with_relish<F>(func: F)
///     where F: FnOnce() -> String
/// {
///     // `func` inoshandisa ayo akatorwa akasiyana, saka haigone kumhanyisa kanopfuura kamwe.
/////
///     println!("Consumed: {}", func());
///
///     println!("Delicious!");
///
///     // Kuedza kukumbira `func()` zvakare kunokanda `use of moved value` kukanganisa kwe `func`.
/////
/// }
///
/// let x = String::from("x");
/// let consume_and_return_x = move || x;
/// consume_with_relish(consume_and_return_x);
///
/// // `consume_and_return_x` haichagone kukumbirwa panguva ino
/// ```
///
///
///
///
///
///
///
///
#[lang = "fn_once"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnOnce}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnOnce<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // kuitira kuti regex igone kuvimba ne `&str: !FnMut` iyoyo
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnOnce<Args> {
    /// Rudzi rwakadzoserwa mushure mekufona unoshandiswa.
    #[lang = "fn_once_output"]
    #[stable(feature = "fn_once_output", since = "1.12.0")]
    type Output;

    /// Inoita iko kufona kushanda.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_once(self, args: Args) -> Self::Output;
}

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> Fn<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call(&self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &F
    where
        F: Fn<A>,
    {
        type Output = F::Output;

        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &mut F
    where
        F: FnMut<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &mut F
    where
        F: FnMut<A>,
    {
        type Output = F::Output;
        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }
}