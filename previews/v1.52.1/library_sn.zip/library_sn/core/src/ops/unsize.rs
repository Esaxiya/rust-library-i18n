use crate::marker::Unsize;

/// Trait iyo inoratidza kuti ichi pointer kana kuputira imwe, uko kusinganisa kunogona kuitiswa pane iyo pooko.
///
/// Ona iyo [DST coercion RFC][dst-coerce] uye [the nomicon entry on coercion][nomicon-coerce] kuti uwane rumwe ruzivo.
///
/// Zvemhando dzakavakirwa zvekunongedzera, anonongedza ku `T` anozomanikidza kunongedzera ku `U` kana `T: Unsize<U>` nekushandura kubva kunongedzo yakatetepa kuenda kunongedzera mafuta.
///
/// Pamhando dzetsika, iko kumanikidza pano kunoshanda nekumanikidza `Foo<T>` kusvika `Foo<U>` yakapa kuiswa kwe `CoerceUnsized<Foo<U>> for Foo<T>` kuriko.
/// Iyo impl inogona kungonyorwa chete kana `Foo<T>` iine chete imwechete isiri-phantomdata munda inosanganisira `T`.
/// Kana mhando yemunda iwoyo iri `Bar<T>`, kumisikidzwa kwe `CoerceUnsized<Bar<U>> for Bar<T>` kunofanirwa kuvapo.
/// Kumanikidza kuchashanda nekumanikidza munda we `Bar<T>` kuita `Bar<U>` uye kuzadza mimwe minda kubva ku `Foo<T>` kugadzira `Foo<U>`.
/// Izvi zvinobudirira kudonhera pasi kune pointer munda uye kumanikidza izvo.
///
/// Kazhinji, kune akachenjera anongedzera iwe unozoisa `CoerceUnsized<Ptr<U>> for Ptr<T> where T: Unsize<U>, U: ?Sized`, uine sarudzo `?Sized` yakasungwa pa `T` pachayo.
/// Yemhando dzekuputira dzakanyatso pinza `T` se `Cell<T>` uye `RefCell<T>`, unogona kuita zvakananga `CoerceUnsized<Wrap<U>> for Wrap<T> where T: CoerceUnsized<U>`.
///
/// Izvi zvinorega kumanikidza kwemhando senge `Cell<Box<T>>` inoshanda.
///
/// [`Unsize`][unsize] inoshandiswa kumaka mhando dzinogona kumanikidzwa kuDSTs kana kumashure kwezvinongedzo.Inoitwa otomatiki nemugadziri.
///
/// [dst-coerce]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [unsize]: crate::marker::Unsize
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
///
///
///
///
///
///
#[unstable(feature = "coerce_unsized", issue = "27732")]
#[lang = "coerce_unsized"]
pub trait CoerceUnsized<T: ?Sized> {
    // Empty.
}

// &mut T-> &mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a mut U> for &'a mut T {}
// &mut T-> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b mut T {}
// &mut T-> * mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for &'a mut T {}
// &mut T-> * const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a mut T {}

// &T -> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b T {}
// &T -> * const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a T {}

// *mut T->* mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for *mut T {}
// *mut T->* const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *mut T {}

// *const T->* const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *const T {}

/// Izvi zvinoshandiswa chengetedzo yechinhu, kutarisa kuti nzira yeanogamuchira inogona kutumirwa pairi.
///
/// Muenzaniso kumisikidzwa kwe trait:
///
/// ```
/// # #![feature(dispatch_from_dyn, unsize)]
/// # use std::{ops::DispatchFromDyn, marker::Unsize};
/// # struct Rc<T: ?Sized>(std::rc::Rc<T>);
/// impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T>
/// where
///     T: Unsize<U>,
/// {}
/// ```
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
#[lang = "dispatch_from_dyn"]
pub trait DispatchFromDyn<T> {
    // Empty.
}

// &T -> &U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a U> for &'a T {}
// &mut T-> &mut U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a mut U> for &'a mut T {}
// *const T->* const U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*const U> for *const T {}
// *mut T->* mut U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*mut U> for *mut T {}