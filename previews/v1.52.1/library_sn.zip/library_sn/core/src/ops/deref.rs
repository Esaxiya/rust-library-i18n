/// Inoshandiswa pamabasa asingachinjiki ekuregeresa, se `*v`.
///
/// Pamusoro pekushandisirwa mabasa akajeka ekudzora kureketa neiyo (unary) `*` mushandisi mune zvisingachinjiki mamiriro, `Deref` inoshandiswawo zvisirizvo nemusanganisi mumamiriro mazhinji.
/// Iyi nzira inonzi ['`Deref` coercion'][more].
/// Mune zvinoshanduka mamiriro, [`DerefMut`] inoshandiswa.
///
/// Kuteedzera `Deref` yezvinongedzo zvine hungwaru kunoita kuti uwane iyo data iri kuseri kwavo ive nyore, ndosaka vachishandisa `Deref`.
/// Kune rimwe divi, iyo mitemo ine chekuita ne `Deref` ne [`DerefMut`] yakagadzirirwa zvakanyanya kugadzirisa zvinongedzo zvine hungwaru.
/// Nekuda kweizvi,**`Deref` inofanira kungoitwa chete kune anonongedzera smart** kudzivirira nyonganiso.
///
/// Nezvikonzero zvakafanana,**iyi trait haifanire kukundikana**.Kukundikana panguva yekureferencera kunogona kuvhiringidza zvakanyanya kana `Deref` ikakumbirwa zvisina tsarukano.
///
/// # Zvizhinji pane `Deref` kumanikidza
///
/// Kana `T` ichishandisa `Deref<Target = U>`, uye `x` iri kukosha kwerudzi `T`, saka:
///
/// * Mune zvisingachinjiki mamiriro, `*x` (uko `T` isiri referenzi kana poindi mbishi) yakaenzana ne `* Deref::deref(&x)`.
/// * Maitiro erudzi `&T` anomanikidzwa kuhunhu hwerudzi `&U`
/// * `T` inoshandisa zvakakwana nzira dzese dze (immutable) dzerudzi `U`.
///
/// Kuti uwane rumwe ruzivo, shanyira [the chapter in *The Rust Programming Language*][book] pamwe nezvikamu zvinongedzera pa [the dereference operator][ref-deref-op], [method resolution] uye [type coercions].
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// Chiumbwa chine munda mumwechete unowanikwa nekureferesa iyo fekitori.
///
/// ```
/// use std::ops::Deref;
///
/// struct DerefExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// let x = DerefExample { value: 'a' };
/// assert_eq!('a', *x);
/// ```
///
///
///
///
///
///
///
#[lang = "deref"]
#[doc(alias = "*")]
#[doc(alias = "&*")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Deref"]
pub trait Deref {
    /// Rudzi runoguma mushure mekuregererwa.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_target"]
    #[cfg_attr(not(bootstrap), lang = "deref_target")]
    type Target: ?Sized;

    /// Inoratidzira kukosha.
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_method"]
    fn deref(&self) -> &Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &T {
    type Target = T;

    #[rustc_diagnostic_item = "noop_method_deref"]
    fn deref(&self) -> &T {
        *self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !DerefMut for &T {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &mut T {
    type Target = T;

    fn deref(&self) -> &T {
        *self
    }
}

/// Inoshandiswa pamabasa ekudzoreredza ekuchinja, senge mu `*v = 1;`.
///
/// Pamusoro pekushandisirwa mabasa akajeka ekuti dereferencing iitwe (unary) `*` mushanduki mune zvinoshanduka mamiriro, `DerefMut` inoshandiswawo zvisizvo nemusanganisi mumamiriro mazhinji.
/// Iyi nzira inonzi ['`Deref` coercion'][more].
/// Mumamiriro asingachinjiki, [`Deref`] inoshandiswa.
///
/// Kuteedzera `DerefMut` yezvinongedzo zvine hungwaru kunoita kuti kuchinjika data riri kuseri kwavo kuve nyore, ndosaka vachishandisa `DerefMut`.
/// Kune rimwe divi, iyo mitemo ine chekuita ne [`Deref`] ne `DerefMut` yakagadzirirwa zvakanyanya kugadzirisa zvinongedzo zvine hungwaru.
/// Nekuda kweizvi,**`DerefMut` inofanirwa kungoitwa chete kune akanakisa mapoinzi** kudzivirira kuvhiringidzika.
///
/// Nezvikonzero zvakafanana,**iyi trait haifanire kukundikana**.Kukundikana panguva yekureferencera kunogona kuvhiringidza zvakanyanya kana `DerefMut` ikakumbirwa zvisina tsarukano.
///
/// # Zvizhinji pane `Deref` kumanikidza
///
/// Kana `T` ichishandisa `DerefMut<Target = U>`, uye `x` iri kukosha kwerudzi `T`, saka:
///
/// * Mune zvinoshanduka mamiriro, `*x` (uko `T` isiri mareferenzi kana poindi mbishi) yakaenzana ne `* DerefMut::deref_mut(&mut x)`.
/// * Maitiro erudzi `&mut T` anomanikidzwa kuhunhu hwerudzi `&mut U`
/// * `T` inoshandisa zvakakwana nzira dzese dze (mutable) dzerudzi `U`.
///
/// Kuti uwane rumwe ruzivo, shanyira [the chapter in *The Rust Programming Language*][book] pamwe nezvikamu zvinongedzera pa [the dereference operator][ref-deref-op], [method resolution] uye [type coercions].
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// Chiumbwa chine munda mumwe chete unoshanduka nekuregedza iyo fekitori.
///
/// ```
/// use std::ops::{Deref, DerefMut};
///
/// struct DerefMutExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefMutExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// impl<T> DerefMut for DerefMutExample<T> {
///     fn deref_mut(&mut self) -> &mut Self::Target {
///         &mut self.value
///     }
/// }
///
/// let mut x = DerefMutExample { value: 'a' };
/// *x = 'b';
/// assert_eq!('b', *x);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "deref_mut"]
#[doc(alias = "*")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DerefMut: Deref {
    /// Zvinonzwisisika zvinoratidzira kukosha.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn deref_mut(&mut self) -> &mut Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for &mut T {
    fn deref_mut(&mut self) -> &mut T {
        *self
    }
}

/// Inoratidza kuti fomati inogona kushandiswa senzira yekugashira, isina `arbitrary_self_types` chimiro.
///
/// Izvi zvinoitwa ne stdlib pointer mhando senge `Box<T>`, `Rc<T>`, `&T`, uye `Pin<P>`.
#[lang = "receiver"]
#[unstable(feature = "receiver_trait", issue = "none")]
#[doc(hidden)]
pub trait Receiver {
    // Empty.
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &T {}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &mut T {}