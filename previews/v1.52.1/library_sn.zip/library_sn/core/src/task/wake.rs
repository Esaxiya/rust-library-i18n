#![stable(feature = "futures_api", since = "1.36.0")]

use crate::fmt;
use crate::marker::{PhantomData, Unpin};

/// A `RawWaker` inobvumidza iye anoita weanobata basa kugadzira [`Waker`] iyo inopa yakasarudzika maitiro ekumuka.
///
/// [vtable]: https://en.wikipedia.org/wiki/Virtual_method_table
///
/// Inosanganisira data pointer uye [virtual function pointer table (vtable)][vtable] iyo inogadzirisa maitiro e `RawWaker`.
///
///
#[derive(PartialEq, Debug)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct RawWaker {
    /// Chinongedzo chedata, icho chinogona kushandiswa kuchengetera zvinhu zvisina tsarukano sezvinodiwa nemuiti.
    /// Izvi zvinogona kunge eg
    /// mhando-yakadzimirwa pointer kune `Arc` iyo inosangana nebasa racho.
    /// Iko kukosha kwemunda uyu kunoendeswa kune ese mashandiro ari chikamu chevtable seyekutanga paramende.
    ///
    data: *const (),
    /// Virtual basa pointer tafura iyo inogadzirisa maitiro eiyi waker.
    vtable: &'static RawWakerVTable,
}

impl RawWaker {
    /// Inogadzira `RawWaker` nyowani kubva kune yakapihwa `data` pointer uye `vtable`.
    ///
    /// Iyo `data` pointer inogona kushandiswa kuchengetedza data risingapindike sezvinodiwa nemuiti.Izvi zvinogona kunge eg
    /// mhando-yakadzimirwa pointer kune `Arc` iyo inosangana nebasa racho.
    /// Iko kukosha kweichi pointer kuchapfuudzwa kune ese mashandiro ayo ari chikamu che `vtable` sepakutanga paramende.
    ///
    /// Iyo `vtable` inogadzirisa hunhu hwe `Waker` iyo inogadzirwa kubva ku `RawWaker`.
    /// Pabasa rega rega pa `Waker`, rakabatana basa mu `vtable` yeiyo iri pasi pe `RawWaker` ichadaidzwa.
    ///
    ///
    ///
    #[inline]
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    pub const fn new(data: *const (), vtable: &'static RawWakerVTable) -> RawWaker {
        RawWaker { data, vtable }
    }
}

/// Iyo chaiyo yekuita pointer tafura (vtable) iyo inotsanangura maitiro e [`RawWaker`].
///
/// Iyo pointer yakapfuudzwa kune ese mashandiro mukati meiyo vtable ndiyo `data` pointer kubva kune yakavharidzirwa [`RawWaker`] chinhu.
///
/// Mabasa mukati meichi chimiro anongotarisirwa kushevedzwa pane iyo `data` pointer yechinhu chakavakwa zvakanaka [`RawWaker`] chinhu kubva mukati meiyo [`RawWaker`] kuitiswa.
/// Kudana chimwe chezviitwa zvirimo uchishandisa chero imwe `data` pointer kunokonzera undefined maitiro.
///
///
///
///
#[stable(feature = "futures_api", since = "1.36.0")]
#[derive(PartialEq, Copy, Clone, Debug)]
pub struct RawWakerVTable {
    /// Iri basa rinodaidzwa kana [`RawWaker`] ikaunganidzwa, semuenzaniso kana iyo [`Waker`] inochengeterwa iyo [`RawWaker`] ikaunganidzwa.
    ///
    /// Kuitwa kweiri basa kunofanirwa kuchengetedza zviwanikwa zvese zvinodiwa kune ino yekuwedzera chiitiko che [`RawWaker`] uye basa rakabatana.
    /// Kufonera `wake` pane [`RawWaker`] inoguma kunofanirwa kumutsa basa rakafanana iro ringadai rakamutswa neiyo [`RawWaker`] yekutanga.
    ///
    ///
    ///
    clone: unsafe fn(*const ()) -> RawWaker,

    /// Iri basa richadaidzwa panonzi `wake` pa [`Waker`].
    /// Inofanirwa kumutsa basa rakabatana neiyi [`RawWaker`].
    ///
    /// Kuitwa kweiri basa kunofanirwa kuve nechokwadi chekuburitsa chero zviwanikwa zvinoenderana neichi chiitiko che [`RawWaker`] uye basa rakabatana.
    ///
    ///
    wake: unsafe fn(*const ()),

    /// Iri basa richadaidzwa panonzi `wake_by_ref` pa [`Waker`].
    /// Inofanirwa kumutsa basa rakabatana neiyi [`RawWaker`].
    ///
    /// Iri basa rakafanana ne `wake`, asi haifanire kushandisa yakapihwa data pointer.
    ///
    wake_by_ref: unsafe fn(*const ()),

    /// Iri basa rinodaidzwa panodonhedzwa [`RawWaker`].
    ///
    /// Kuitwa kweiri basa kunofanirwa kuve nechokwadi chekuburitsa chero zviwanikwa zvinoenderana neichi chiitiko che [`RawWaker`] uye basa rakabatana.
    ///
    ///
    drop: unsafe fn(*const ()),
}

impl RawWakerVTable {
    /// Inogadzira `RawWakerVTable` nyowani kubva kune yakapihwa `clone`, `wake`, `wake_by_ref`, uye `drop` mabasa.
    ///
    /// # `clone`
    ///
    /// Iri basa rinodaidzwa kana [`RawWaker`] ikaunganidzwa, semuenzaniso kana iyo [`Waker`] inochengeterwa iyo [`RawWaker`] ikaunganidzwa.
    ///
    /// Kuitwa kweiri basa kunofanirwa kuchengetedza zviwanikwa zvese zvinodiwa kune ino yekuwedzera chiitiko che [`RawWaker`] uye basa rakabatana.
    /// Kufonera `wake` pane [`RawWaker`] inoguma kunofanirwa kumutsa basa rakafanana iro ringadai rakamutswa neiyo [`RawWaker`] yekutanga.
    ///
    /// # `wake`
    ///
    /// Iri basa richadaidzwa panonzi `wake` pa [`Waker`].
    /// Inofanirwa kumutsa basa rakabatana neiyi [`RawWaker`].
    ///
    /// Kuitwa kweiri basa kunofanirwa kuve nechokwadi chekuburitsa chero zviwanikwa zvinoenderana neichi chiitiko che [`RawWaker`] uye basa rakabatana.
    ///
    ///
    /// # `wake_by_ref`
    ///
    /// Iri basa richadaidzwa panonzi `wake_by_ref` pa [`Waker`].
    /// Inofanirwa kumutsa basa rakabatana neiyi [`RawWaker`].
    ///
    /// Iri basa rakafanana ne `wake`, asi haifanire kushandisa yakapihwa data pointer.
    ///
    /// # `drop`
    ///
    /// Iri basa rinodaidzwa panodonhedzwa [`RawWaker`].
    ///
    /// Kuitwa kweiri basa kunofanirwa kuve nechokwadi chekuburitsa chero zviwanikwa zvinoenderana neichi chiitiko che [`RawWaker`] uye basa rakabatana.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_allow_const_fn_unstable(const_fn_fn_ptr_basics)]
    pub const fn new(
        clone: unsafe fn(*const ()) -> RawWaker,
        wake: unsafe fn(*const ()),
        wake_by_ref: unsafe fn(*const ()),
        drop: unsafe fn(*const ()),
    ) -> Self {
        Self { clone, wake, wake_by_ref, drop }
    }
}

/// Iyo `Context` yeasynchronous basa.
///
/// Parizvino, `Context` inoshanda chete kupa mukana kune `&Waker` iyo inogona kushandiswa kumutsa iro razvino basa.
///
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Context<'a> {
    waker: &'a Waker,
    // Ita shuwa isu future-humbowo kupesana nekusiyana kwekuchinja nekumanikidza iyo yehupenyu kuve isingachinjiki (nharo-chinzvimbo nguva yeupenyu inopesana nepo kudzoka-chinzvimbo nguva yeupenyu iri covariant).
    //
    //
    //
    _marker: PhantomData<fn(&'a ()) -> &'a ()>,
}

impl<'a> Context<'a> {
    /// Gadzira `Context` nyowani kubva ku `&Waker`.
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn from_waker(waker: &'a Waker) -> Self {
        Context { waker, _marker: PhantomData }
    }

    /// Inodzorera chirevo ku `Waker` yebasa razvino.
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn waker(&self) -> &'a Waker {
        &self.waker
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Context<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Context").field("waker", &self.waker).finish()
    }
}

/// `Waker` mubato wekumutsa basa nekuzivisa muiti wayo kuti yakagadzirira kumhanyisa.
///
/// Ichi chibato chinoputira [`RawWaker`] semuenzaniso, iyo inotsanangura iyo inomiririra-yakatarwa yekumuka maitiro.
///
///
/// Zvishandiso [`Clone`], [`Send`], uye [`Sync`].
///
#[repr(transparent)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Waker {
    waker: RawWaker,
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Unpin for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Send for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Sync for Waker {}

impl Waker {
    /// Mutsa basa rakabatana neiyi `Waker`.
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake(self) {
        // Iyo chaiyo yekumutsa kufona inopihwa kuburikidza neicho chaicho basa kufona kune iyo kuitiswa iyo inotsanangurwa nemuiti.
        //
        let wake = self.waker.vtable.wake;
        let data = self.waker.data;

        // Usashevedze `drop`-iyo inomutsa ichapedzwa ne `wake`.
        crate::mem::forget(self);

        // Kachengeteka: Izvi zvakachengeteka nekuti `Waker::from_raw` ndiyo chete nzira
        // kutanga `wake` uye `data` inoda kuti mushandisi azive kuti kontrakiti ye `RawWaker` yakachengetedzwa.
        //
        unsafe { (wake)(data) };
    }

    /// Mutsa basa rakabatana neiyi `Waker` pasina kushandisa iyo `Waker`.
    ///
    /// Izvi zvakafanana ne `wake`, asi inogona kunge isinganyanyo shanda mune kesi panowanikwa `Waker`.
    /// Iyi nzira inofanirwa kusarudzwa kusheedza `waker.clone().wake()`.
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake_by_ref(&self) {
        // Iyo chaiyo yekumutsa kufona inopihwa kuburikidza neicho chaicho basa kufona kune iyo kuitiswa iyo inotsanangurwa nemuiti.
        //

        // Kachengeteka: ona `wake`
        unsafe { (self.waker.vtable.wake_by_ref)(self.waker.data) }
    }

    /// Inodzorera `true` kana iyi `Waker` neimwe `Waker` yamutsa basa rakafanana.
    ///
    /// Iri basa rinoshanda pane yakanyanya-kuyedza, uye rinogona kudzoka manyepo kunyangwe ma`Waker paanomutsa basa rimwe chete.
    /// Nekudaro, kana basa iri rikadzosa `true`, zvinovimbiswa kuti `Waker`s inomutsa iro basa rimwe chete.
    ///
    /// Iri basa rinonyanya kushandiswa mukugadzirisa zvinangwa.
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn will_wake(&self, other: &Waker) -> bool {
        self.waker == other.waker
    }

    /// Inogadzira `Waker` nyowani kubva ku [`RawWaker`].
    ///
    /// Hunhu hwe `Waker` yakadzoserwa haina kujekeswa kana kondirakiti yakatsanangurwa mu ["RawWaker`] 's uye [' RawWakerVTable`] 'zvinyorwa haina kuchengetedzwa.
    ///
    /// Naizvozvo nzira iyi haina kuchengetedzeka.
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub unsafe fn from_raw(waker: RawWaker) -> Waker {
        Waker { waker }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Clone for Waker {
    #[inline]
    fn clone(&self) -> Self {
        Waker {
            // Kachengeteka: Izvi zvakachengeteka nekuti `Waker::from_raw` ndiyo chete nzira
            // kutanga `clone` uye `data` inoda kuti mushandisi azive kuti kontrakiti ye [`RawWaker`] yakachengetedzwa.
            //
            waker: unsafe { (self.waker.vtable.clone)(self.waker.data) },
        }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Drop for Waker {
    #[inline]
    fn drop(&mut self) {
        // Kachengeteka: Izvi zvakachengeteka nekuti `Waker::from_raw` ndiyo chete nzira
        // kutanga `drop` uye `data` inoda kuti mushandisi azive kuti kontrakiti ye `RawWaker` yakachengetedzwa.
        //
        unsafe { (self.waker.vtable.drop)(self.waker.data) }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Waker {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let vtable_ptr = self.waker.vtable as *const RawWakerVTable;
        f.debug_struct("Waker")
            .field("data", &self.waker.data)
            .field("vtable", &vtable_ptr)
            .finish()
    }
}