//! Midziyo inogovaniswa inogona kuchinjika.
//!
//! Rust ndangariro chengetedzo yakavakirwa pamutemo uyu: Kupihwa chinhu `T`, zvinongogoneka kuve nechimwe cheanotevera:
//!
//! - Kuve nezvakawanda zvisingachinjiki mareferenzi (`&T`) kuchinhu (chinonziwo **aliasing**).
//! - Kuve neinogona kuchinjika chirevo (`&mut T`) kuchinhu (chinonziwo **mutability**).
//!
//! Izvi zvinomanikidzwa ne Rust compiler.Zvisinei, kune mamiriro ezvinhu apo mutemo uyu hauna kuchinja zvakakwana.Dzimwe nguva zvinofanirwa kuve nezvakawanda mareferenzi kuchinhu uye wochichinja.
//!
//! Midziyo inogovaniswa inogona kuchinjika kubvumidza kuchinjika nenzira inodzorwa, kunyangwe paine kusarudzika.Ose ari maviri [`Cell<T>`] uye [`RefCell<T>`] anotendera kuita izvi mune imwechete-tambo nzira.
//! Nekudaro, kana `Cell<T>` kana `RefCell<T>` haina tambo yakachengeteka (havaite [`Sync`]).
//! Kana iwe uchida kuita aliasing uye shanduko pakati pakawanda tambo zvinokwanisika kushandisa [`Mutex<T>`], [`RwLock<T>`] kana [`atomic`] mhando.
//!
//! Maitiro eiyo `Cell<T>` uye `RefCell<T>` mhando anogona kuchinjika kuburikidza akagovaniswa mareferensi (kureva
//! iyo yakajairika `&T` mhando), nepo mazhinji Rust mhando dzinogona kungochinjika kuburikidza neyeakasarudzika (`&mut T`) mareferensi.
//! Isu tinoti `Cell<T>` uye `RefCell<T>` zvinopa 'zvemukati kuchinjika', kusiyana neyakajairika Rust mhando dzinoratidza 'nhaka yekuchinja'.
//!
//! Mhando dzemasero anouya mune maviri akanakisa: `Cell<T>` uye `RefCell<T>`.`Cell<T>` inoshandura mukati kugadzikana nekufambisa hunhu mukati nekunze kwe `Cell<T>`.
//! Kuti ushandise mareferenzi pachinzvimbo chemitengo, munhu anofanirwa kushandisa iyo `RefCell<T>` mhando, kutora rekodhi yekunyora usati wachinja.`Cell<T>` inopa nzira dzekudzosa uye nekuchinja iko iko iko kukosha kwemukati:
//!
//!  - Kune mhando dzinoshandisa [`Copy`], iyo [`get`](Cell::get) nzira inowana iyo yazvino kukosha kwemukati.
//!  - Yemhando dzinoshandisa [`Default`], iyo [`take`](Cell::take) nzira inotsiva iyo yazvino kukosha kwemukati ne [`Default::default()`] uye inodzosera iyo yakatsiviwa kukosha.
//!  - Kune ese marudzi, iyo [`replace`](Cell::replace) nzira inotsiva yazvino kukosha kwemukati uye inodzosera iyo yakatsiviwa kukosha uye iyo [`into_inner`](Cell::into_inner) nzira inoshandisa iyo `Cell<T>` uye inodzosera iyo yemukati kukosha.
//!  Pamusoro pezvo, iyo [`set`](Cell::set) nzira inotsiva kukosha kwemukati, ichidonhedza kukosha kwakatsiviwa.
//!
//! `RefCell<T>` inoshandisa nguva yeupenyu ye Rust kuita 'inesimba kukwereta', maitiro ekuti munhu anogona kutora chenguva pfupi, yakasarudzika, inogona kuchinjika kuwana kune yemukati kukosha.
//! Inokwereta ye`RefCell<T>`s anoteerwa 'panguva yekumhanya', kusiyana ne Rust yemhando mareferenzi emhando ayo anoteedzerwa zvakazara, panguva yekubatanidza.
//! Nekuti `RefCell<T>` inokwereta ine simba zvinokwanisika kuyedza kukwereta kukosha iyo yatobhadhariswa zvikaita;kana izvi zvikaitika zvinoguma neshinda panic.
//!
//! # Nguva yekusarudza kuchinjika kwemukati
//!
//! Kuchinja kwakajairika kunowanikwa nhaka, uko munhu anofanirwa kuve neakasarudzika mukana wekuchinja kukosha, ndechimwe chezvinhu zvakakosha zvemitauro zvinoita kuti Rust ifunge zvine simba nezve pointer aliasing, inodzivirira kuparara kwetsikidzi.
//! Nekuda kweizvozvo, chinjo inogarwa nhaka inosarudzwa, uye kugadzikana kwemukati ndechimwe chinhu chekupedzisira.
//! Sezvo mhando dzemasero dzinoita kuti kuchinjika uko kwaisazobvumidzwa zvakadaro, pane nguva apo kugadzikana kwemukati kungave kwakakodzera, kana kunyangwe * kunofanirwa kushandiswa, semuenzaniso
//!
//! * Kuunza kuchinjika 'inside' yechimwe chinhu chisingachinjiki
//! * Maitiro ekumisikidza enzira-zvisingachinjiki nzira.
//! * Kuchinja mashandiro e [`Clone`].
//!
//! ## Kuunza kuchinjika 'inside' yechimwe chinhu chisingachinjiki
//!
//! Vazhinji vakagovana smart pointer mhando, kusanganisira [`Rc<T>`] uye [`Arc<T>`], inopa midziyo inogona kuumbiwa uye kugovaniswa pakati pemapato mazhinji.
//! Nekuti izvo zvirimo zvimiro zvinogona kuwanda-kusheedzwa, ivo vanogona kungokweretwa chete ne `&`, kwete `&mut`.
//! Pasina masero hazvingagone kuchinjisa dhata mukati meaya akanakisa mapoinzi zvachose.
//!
//! Zvakajairika kwazvo ipapo kuisa `RefCell<T>` mukati yakagovaniswa mhando dzemapoint kuti udzorezve kugona.
//!
//! ```
//! use std::cell::{RefCell, RefMut};
//! use std::collections::HashMap;
//! use std::rc::Rc;
//!
//! fn main() {
//!     let shared_map: Rc<RefCell<_>> = Rc::new(RefCell::new(HashMap::new()));
//!     // Gadzira bhuroka nyowani kudzikisira chiyero chesimba rekukwereta
//!     {
//!         let mut map: RefMut<_> = shared_map.borrow_mut();
//!         map.insert("africa", 92388);
//!         map.insert("kyoto", 11837);
//!         map.insert("piccadilly", 11826);
//!         map.insert("marbles", 38);
//!     }
//!
//!     // Ziva kuti dai isu tisina kurega iyo yapfuura kukweretwa kwecache kudonha kubva pachiyero saka iyo inotevera yekukwereta ingakonzera ine simba tambo panic
//!     //
//!     // Iyi ndiyo njodzi huru yekushandisa `RefCell`.
//!     let total: i32 = shared_map.borrow().values().sum();
//!     println!("{}", total);
//! }
//! ```
//!
//! Ziva kuti uyu muenzaniso unoshandisa `Rc<T>` uye kwete `Arc<T>`.RefCell<T>'ndezvezviitiko zvine tambo imwechete.Funga kushandisa [`RwLock<T>`] kana [`Mutex<T>`] kana iwe uchida kugovana kuchinjika mune yakawanda-tambo mamiriro.
//!
//! ## Maitiro ekumisikidza enzira-zvisingachinjiki nzira
//!
//! Dzimwe nguva zvinogona kuve zvinodikanwa kuti usafumure muAPI kuti pane shanduko iri kuitika "under the hood".
//! Izvi zvinogona kunge zviri nekuti zvine musoro kuti mashandiro haachinjike, asi semuenzaniso, caching inomanikidza kuitisa kuita shanduko;kana nekuti unofanirwa kushandisa mutation kuita trait nzira iyo pakutanga yakatsanangurwa kutora `&self`.
//!
//!
//! ```
//! # #![allow(dead_code)]
//! use std::cell::RefCell;
//!
//! struct Graph {
//!     edges: Vec<(i32, i32)>,
//!     span_tree_cache: RefCell<Option<Vec<(i32, i32)>>>
//! }
//!
//! impl Graph {
//!     fn minimum_spanning_tree(&self) -> Vec<(i32, i32)> {
//!         self.span_tree_cache.borrow_mut()
//!             .get_or_insert_with(|| self.calc_span_tree())
//!             .clone()
//!     }
//!
//!     fn calc_span_tree(&self) -> Vec<(i32, i32)> {
//!         // Kuverenga kwakachipa kunoenda pano
//!         vec![]
//!     }
//! }
//! ```
//!
//! ## Kuchinja mashandiro e `Clone`
//!
//! Iyi ingori yakasarudzika, asi yakajairika, kesi yeakare: kuvanza kuchinjika kwemabasa anoita kunge asingachinjiki.
//! Iyo [`clone`](Clone::clone) nzira inotarisirwa kuti isachinje iyo sosi kukosha, uye inonzi yatora `&self`, kwete `&mut self`.
//! Naizvozvo, chero shanduko inoitika mune `clone` nzira inofanira kushandisa maseru mhando.
//! Semuenzaniso, [`Rc<T>`] inochengetedza ayo mareferenzi kuverenga mukati me `Cell<T>`.
//!
//! ```
//! use std::cell::Cell;
//! use std::ptr::NonNull;
//! use std::process::abort;
//! use std::marker::PhantomData;
//!
//! struct Rc<T: ?Sized> {
//!     ptr: NonNull<RcBox<T>>,
//!     phantom: PhantomData<RcBox<T>>,
//! }
//!
//! struct RcBox<T: ?Sized> {
//!     strong: Cell<usize>,
//!     refcount: Cell<usize>,
//!     value: T,
//! }
//!
//! impl<T: ?Sized> Clone for Rc<T> {
//!     fn clone(&self) -> Rc<T> {
//!         self.inc_strong();
//!         Rc {
//!             ptr: self.ptr,
//!             phantom: PhantomData,
//!         }
//!     }
//! }
//!
//! trait RcBoxPtr<T: ?Sized> {
//!
//!     fn inner(&self) -> &RcBox<T>;
//!
//!     fn strong(&self) -> usize {
//!         self.inner().strong.get()
//!     }
//!
//!     fn inc_strong(&self) {
//!         self.inner()
//!             .strong
//!             .set(self.strong()
//!                      .checked_add(1)
//!                      .unwrap_or_else(|| abort() ));
//!     }
//! }
//!
//! impl<T: ?Sized> RcBoxPtr<T> for Rc<T> {
//!    fn inner(&self) -> &RcBox<T> {
//!        unsafe {
//!            self.ptr.as_ref()
//!        }
//!    }
//! }
//! ```
//!
//! [`Arc<T>`]: ../../std/sync/struct.Arc.html
//! [`Rc<T>`]: ../../std/rc/struct.Rc.html
//! [`RwLock<T>`]: ../../std/sync/struct.RwLock.html
//! [`Mutex<T>`]: ../../std/sync/struct.Mutex.html
//! [`atomic`]: ../../core/sync/atomic/index.html
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering;
use crate::fmt::{self, Debug, Display};
use crate::marker::Unsize;
use crate::mem;
use crate::ops::{CoerceUnsized, Deref, DerefMut};
use crate::ptr;

/// Nzvimbo inogona kuyeukwa.
///
/// # Examples
///
/// Mumuenzaniso uyu, unogona kuona kuti `Cell<T>` inogonesa shanduko mukati mechinhu chisingachinjiki.
/// Mune mamwe mazwi, inogonesa "interior mutability".
///
/// ```
/// use std::cell::Cell;
///
/// struct SomeStruct {
///     regular_field: u8,
///     special_field: Cell<u8>,
/// }
///
/// let my_struct = SomeStruct {
///     regular_field: 0,
///     special_field: Cell::new(1),
/// };
///
/// let new_value = 100;
///
/// // Kanganiso: `my_struct` haichinjiki
/// // my_struct.regular_field =nyowani_kukosha;
///
/// // BASA: kunyangwe `my_struct` isingachinjiki, `special_field` iri `Cell`,
/// // iyo inogona kugara ichichinjika
/// my_struct.special_field.set(new_value);
/// assert_eq!(my_struct.special_field.get(), new_value);
/// ```
///
/// Ona [module-level documentation](self) zvimwe.
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
pub struct Cell<T: ?Sized> {
    value: UnsafeCell<T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for Cell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for Cell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Copy> Clone for Cell<T> {
    #[inline]
    fn clone(&self) -> Cell<T> {
        Cell::new(self.get())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Cell<T> {
    /// Inogadzira `Cell<T>`, iine `Default` kukosha kweT.
    #[inline]
    fn default() -> Cell<T> {
        Cell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialEq + Copy> PartialEq for Cell<T> {
    #[inline]
    fn eq(&self, other: &Cell<T>) -> bool {
        self.get() == other.get()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: Eq + Copy> Eq for Cell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: PartialOrd + Copy> PartialOrd for Cell<T> {
    #[inline]
    fn partial_cmp(&self, other: &Cell<T>) -> Option<Ordering> {
        self.get().partial_cmp(&other.get())
    }

    #[inline]
    fn lt(&self, other: &Cell<T>) -> bool {
        self.get() < other.get()
    }

    #[inline]
    fn le(&self, other: &Cell<T>) -> bool {
        self.get() <= other.get()
    }

    #[inline]
    fn gt(&self, other: &Cell<T>) -> bool {
        self.get() > other.get()
    }

    #[inline]
    fn ge(&self, other: &Cell<T>) -> bool {
        self.get() >= other.get()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: Ord + Copy> Ord for Cell<T> {
    #[inline]
    fn cmp(&self, other: &Cell<T>) -> Ordering {
        self.get().cmp(&other.get())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for Cell<T> {
    fn from(t: T) -> Cell<T> {
        Cell::new(t)
    }
}

impl<T> Cell<T> {
    /// Inogadzira `Cell` nyowani iine iyo yakapihwa kukosha.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> Cell<T> {
        Cell { value: UnsafeCell::new(value) }
    }

    /// Inoisa kukosha kuri mukati.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// c.set(10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn set(&self, val: T) {
        let old = self.replace(val);
        drop(old);
    }

    /// Chinja hunhu hweMasero maviri.
    /// Musiyano ne `std::mem::swap` ndewekuti basa iri haridi `&mut` chirevo.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c1 = Cell::new(5i32);
    /// let c2 = Cell::new(10i32);
    /// c1.swap(&c2);
    /// assert_eq!(10, c1.get());
    /// assert_eq!(5, c2.get());
    /// ```
    #[inline]
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn swap(&self, other: &Self) {
        if ptr::eq(self, other) {
            return;
        }
        // Kachengeteka: Izvi zvinogona kuve nenjodzi kana ikadaidzwa kubva kune dzakasiyana tambo, asi `Cell`
        // iri `!Sync` saka izvi hazviitike.
        // Izvi zvakare hazvizoshandise chero anonongedza sezvo `Cell` ichive nechokwadi kuti hapana chimwe chinhu chinganongedze mune chero eaya ma`Cell`s.
        //
        unsafe {
            ptr::swap(self.value.get(), other.value.get());
        }
    }

    /// Inotsiva iyo yaivepo kukosha ne `val`, uye inodzosera iyo yekare yaivepo kukosha.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let cell = Cell::new(5);
    /// assert_eq!(cell.get(), 5);
    /// assert_eq!(cell.replace(10), 5);
    /// assert_eq!(cell.get(), 10);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn replace(&self, val: T) -> T {
        // Kachengeteka: Izvi zvinogona kukonzeresa kumhanyisa dhata kana ikadaidzwa kubva kune yakasarudzika tambo
        // asi `Cell` iri `!Sync` saka izvi hazviitike.
        mem::replace(unsafe { &mut *self.value.get() }, val)
    }

    /// Unwraps kukosha.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.into_inner();
    ///
    /// assert_eq!(five, 5);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value.into_inner()
    }
}

impl<T: Copy> Cell<T> {
    /// Inodzorera kopi yeiyo yaive nemutengo.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let five = c.get();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get(&self) -> T {
        // Kachengeteka: Izvi zvinogona kukonzeresa kumhanyisa dhata kana ikadaidzwa kubva kune yakasarudzika tambo
        // asi `Cell` iri `!Sync` saka izvi hazviitike.
        unsafe { *self.value.get() }
    }

    /// Inovandudza iyo yaivepo kukosha uchishandisa basa uye inodzosera iyo nyowani kukosha.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_update)]
    ///
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let new = c.update(|x| x + 1);
    ///
    /// assert_eq!(new, 6);
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[unstable(feature = "cell_update", issue = "50186")]
    pub fn update<F>(&self, f: F) -> T
    where
        F: FnOnce(T) -> T,
    {
        let old = self.get();
        let new = f(old);
        self.set(new);
        new
    }
}

impl<T: ?Sized> Cell<T> {
    /// Inodzorera pointer mbishi kune iri pasi data iri muchitokisi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    #[rustc_const_stable(feature = "const_cell_as_ptr", since = "1.32.0")]
    pub const fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// Inodzorera chinongedzo chinoshandurwa kune iri pasi data.
    ///
    /// Kufona uku kunokwereta `Cell` zvinonzwisisika (panguva yekubatanidza-nguva) iyo inovimbisa kuti isu tine chete chirevo.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let mut c = Cell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// Inodzorera `&Cell<T>` kubva ku `&mut T`
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[inline]
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn from_mut(t: &mut T) -> &Cell<T> {
        // Kachengeteka: `&mut` inovimbisa yakasarudzika kuwana.
        unsafe { &*(t as *mut T as *const Cell<T>) }
    }
}

impl<T: Default> Cell<T> {
    /// Inotora kukosha kwesero, ichisiya `Default::default()` munzvimbo yayo.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<Cell<U>> for Cell<T> {}

impl<T> Cell<[T]> {
    /// Inodzorera `&[Cell<T>]` kubva ku `&Cell<[T]>`
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn as_slice_of_cells(&self) -> &[Cell<T>] {
        // KUCHENGETEKA: `Cell<T>` ine yakafanana ndangariro marongero se `T`.
        unsafe { &*(self as *const Cell<[T]> as *const [Cell<T>]) }
    }
}

/// Iyo inogona kuchinjika ndangariro nzvimbo ine simba rakatariswa rekukwereta mitemo
///
/// Ona [module-level documentation](self) zvimwe.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefCell<T: ?Sized> {
    borrow: Cell<BorrowFlag>,
    value: UnsafeCell<T>,
}

/// Iko kukanganisa kwakadzoserwa ne [`RefCell::try_borrow`].
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already mutably borrowed", f)
    }
}

/// Iko kukanganisa kwakadzoserwa ne [`RefCell::try_borrow_mut`].
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowMutError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowMutError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already borrowed", f)
    }
}

// Hwakanaka hunhu hunomiririra huwandu hwe `Ref` inoshanda.Hunhu hwakashata hunomiririra huwandu hwe `RefMut` inoshanda.
// Akawanda `RefMut`s anogona kungove anoshanda pane imwe nguva kana achinongedzera kune akasiyana, asina kuvharira zvinhu zve `RefCell` (semuenzaniso, akasiyana masiyiti echidimbu).
//
// `Ref` uye `RefMut` ese ari maviri mazwi muhukuru, uye saka pangangove pasina kuzombove akakwana `Ref`s kana`RefMut`s aripo kufashukira hafu ye `usize` renji.
// Nekudaro, `BorrowFlag` ingangodaro isingazofashukira kana kufashukira.
// Nekudaro, ichi hachisi chivimbiso, sehurongwa hwehutachiona hunogona kudzokorora uyezve mem::forget `Ref`s kana`RefMut`s.
// Nekudaro, kodhi yese inofanira kutarisa zvakajeka kufashukira uye kufashukira kuitira kudzivirira kusagadzikana, kana kuzvibata nenzira kwayo muchiitiko chekufashukira kana kufashukira kunoitika (semuenzaniso, ona BorrowRef::new).
//
//
//
//
//
//
type BorrowFlag = isize;
const UNUSED: BorrowFlag = 0;

#[inline(always)]
fn is_writing(x: BorrowFlag) -> bool {
    x < UNUSED
}

#[inline(always)]
fn is_reading(x: BorrowFlag) -> bool {
    x > UNUSED
}

impl<T> RefCell<T> {
    /// Inogadzira `RefCell` nyowani ine `value`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_refcell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> RefCell<T> {
        RefCell { value: UnsafeCell::new(value), borrow: Cell::new(UNUSED) }
    }

    /// Inoshandisa iyo `RefCell`, ichidzosera iyo yakaputirwa kukosha.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let five = c.into_inner();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    #[inline]
    pub const fn into_inner(self) -> T {
        // Sezvo basa iri richitora `self` (iyo `RefCell`) nemutengo, iyo compiler inosimbisa kuti haina kukweretwa parizvino.
        //
        self.value.into_inner()
    }

    /// Inotsiva kukosha kwakaputirwa neimwe nyowani, ichidzosa iyo yekare kukosha, pasina kubvisa rimwe chete.
    ///
    ///
    /// Iri basa rinoenderana ne [`std::mem::replace`](../mem/fn.replace.html).
    ///
    /// # Panics
    ///
    /// Panics kana kukosha kuchikweretwa parizvino.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace(6);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace", since = "1.24.0")]
    #[track_caller]
    pub fn replace(&self, t: T) -> T {
        mem::replace(&mut *self.borrow_mut(), t)
    }

    /// Inotsiva kukosha kwakaputirwa neimwe nyowani yakanyorwa kubva ku `f`, ichidzosa iyo yekare kukosha, pasina kubvisa rimwe chete.
    ///
    ///
    /// # Panics
    ///
    /// Panics kana kukosha kuchikweretwa parizvino.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace_with(|&mut old| old + 1);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace_swap", since = "1.35.0")]
    #[track_caller]
    pub fn replace_with<F: FnOnce(&mut T) -> T>(&self, f: F) -> T {
        let mut_borrow = &mut *self.borrow_mut();
        let replacement = f(mut_borrow);
        mem::replace(mut_borrow, replacement)
    }

    /// Inochinjisa kukosha kwakaputirwa kwe `self` nemutengo wakaputirwa we `other`, pasina kubvisa rimwe chete.
    ///
    ///
    /// Iri basa rinoenderana ne [`std::mem::swap`](../mem/fn.swap.html).
    ///
    /// # Panics
    ///
    /// Panics kana kukosha mune chero `RefCell` kuchikweretwa pari zvino.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let c = RefCell::new(5);
    /// let d = RefCell::new(6);
    /// c.swap(&d);
    /// assert_eq!(c, RefCell::new(6));
    /// assert_eq!(d, RefCell::new(5));
    /// ```
    #[inline]
    #[stable(feature = "refcell_swap", since = "1.24.0")]
    pub fn swap(&self, other: &Self) {
        mem::swap(&mut *self.borrow_mut(), &mut *other.borrow_mut())
    }
}

impl<T: ?Sized> RefCell<T> {
    /// Chaizvoizvo inokwereta iyo yakaputirwa kukosha.
    ///
    /// Iyo inokwereta inogara kusvikira iyo yakadzoserwa `Ref` yabuda chiyero.
    /// Zvikwereti zvakawanda zvisingachinjiki zvinogona kutorwa panguva imwe chete.
    ///
    /// # Panics
    ///
    /// Panics kana kukosha kwacho kuchikweretwa zvino.
    /// Kune isina-kuvhunduka musiyano, shandisa [`try_borrow`](#method.try_borrow).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let borrowed_five = c.borrow();
    /// let borrowed_five2 = c.borrow();
    /// ```
    ///
    /// Muenzaniso we panic:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let m = c.borrow_mut();
    /// let b = c.borrow(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow(&self) -> Ref<'_, T> {
        self.try_borrow().expect("already mutably borrowed")
    }

    /// Asingaoneki anokwereta iro rakaputirwa kukosha, achidzosera kukanganisa kana kukosha kwacho parizvino kuchikweretwa.
    ///
    ///
    /// Iyo inokwereta inogara kusvikira iyo yakadzoserwa `Ref` yabuda chiyero.
    /// Zvikwereti zvakawanda zvisingachinjiki zvinogona kutorwa panguva imwe chete.
    ///
    /// Iyi ndiyo misiyano isiri yekuvhunduka ye [`borrow`](#method.borrow).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(c.try_borrow().is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow().is_ok());
    /// }
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow(&self) -> Result<Ref<'_, T>, BorrowError> {
        match BorrowRef::new(&self.borrow) {
            // Kachengeteka: `BorrowRef` inova nechokwadi chekuti kune chete kusingachinjiki kuwana
            // kune iyo kukosha ichikweretwa.
            Some(b) => Ok(Ref { value: unsafe { &*self.value.get() }, borrow: b }),
            None => Err(BorrowError { _private: () }),
        }
    }

    /// Inobvumirana inokwereta iyo yakaputirwa kukosha.
    ///
    /// Iyo inokwereta inogara kusvikira iyo yakadzoserwa `RefMut` kana ese `RefMut`s akatorwa kubva mairi kubuda chiyero.
    ///
    /// Iko kukosha hakugone kukweretwa uku kukwereta kuri kushanda.
    ///
    /// # Panics
    ///
    /// Panics kana kukosha kuchikweretwa parizvino.
    /// Kune isina-kuvhunduka musiyano, shandisa [`try_borrow_mut`](#method.try_borrow_mut).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new("hello".to_owned());
    ///
    /// *c.borrow_mut() = "bonjour".to_owned();
    ///
    /// assert_eq!(&*c.borrow(), "bonjour");
    /// ```
    ///
    /// Muenzaniso we panic:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let m = c.borrow();
    ///
    /// let b = c.borrow_mut(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow_mut(&self) -> RefMut<'_, T> {
        self.try_borrow_mut().expect("already borrowed")
    }

    /// Inobvumirana inokweretesa iyo yakaputirwa kukosha, ichidzosera kukanganisa kana iyo kukosha kwazvino yakweretwa.
    ///
    ///
    /// Iyo inokwereta inogara kusvikira iyo yakadzoserwa `RefMut` kana ese `RefMut`s akatorwa kubva mairi kubuda chiyero.
    /// Iko kukosha hakugone kukweretwa uku kukwereta kuri kushanda.
    ///
    /// Iyi ndiyo misiyano isiri yekuvhunduka ye [`borrow_mut`](#method.borrow_mut).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow_mut().is_err());
    /// }
    ///
    /// assert!(c.try_borrow_mut().is_ok());
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow_mut(&self) -> Result<RefMut<'_, T>, BorrowMutError> {
        match BorrowRefMut::new(&self.borrow) {
            // Kachengeteka: `BorrowRef` inovimbisa yakasarudzika kuwana.
            Some(b) => Ok(RefMut { value: unsafe { &mut *self.value.get() }, borrow: b }),
            None => Err(BorrowMutError { _private: () }),
        }
    }

    /// Inodzorera pointer mbishi kune iri pasi data iri muchitokisi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    pub fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// Inodzorera chinongedzo chinoshandurwa kune iri pasi data.
    ///
    /// Kufona uku kunokwereta `RefCell` zvine mutsindo (panguva yekubatanidza-nguva) saka hapana chikonzero chemasimba macheki.
    ///
    /// Nekudaro chenjera: iyi nzira inotarisira kuti `self` inogona kuchinjika, izvo zvisingawanzo kuitika kana uchishandisa `RefCell`.
    ///
    /// Tarisa uone iyo [`borrow_mut`] nzira pachinzvimbo kana `self` isingachinjiki.
    ///
    /// Zvakare, ndapota ziva kuti iyi nzira ndeyemamiriro ezvinhu akasarudzika uye kazhinji haisi izvo zvaunoda.
    /// Kana paine kusahadzika, shandisa [`borrow_mut`] pachinzvimbo.
    ///
    /// [`borrow_mut`]: RefCell::borrow_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c, RefCell::new(6));
    /// ```
    ///
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// Shandura mhedzisiro yevarindi vakadonhedza pamamiriro ekukwereta e `RefCell`.
    ///
    /// Kufona uku kwakafanana ne [`get_mut`] asi kwakanyanya kuzivikanwa.
    /// Iyo inokwereta `RefCell` zvinonzwisisika kuti ive nechokwadi chekuti hapana zvikwereti zviripo uye wozogadzirisazve nyika yekutevera yakagovaniswa zvikwereti.
    /// Izvi zvinokodzera kana imwe `Ref` kana `RefMut` zvikwereti zvaburitswa.
    ///
    /// [`get_mut`]: RefCell::get_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(0);
    /// std::mem::forget(c.borrow_mut());
    ///
    /// assert!(c.try_borrow().is_err());
    /// c.undo_leak();
    /// assert!(c.try_borrow().is_ok());
    /// ```
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn undo_leak(&mut self) -> &mut T {
        *self.borrow.get_mut() = UNUSED;
        self.get_mut()
    }

    /// Asingaoneki anokwereta iro rakaputirwa kukosha, achidzosera kukanganisa kana kukosha kwacho parizvino kuchikweretwa.
    ///
    /// # Safety
    ///
    /// Kusiyana ne `RefCell::borrow`, iyi nzira haina kuchengeteka nekuti haina kudzosa `Ref`, nekudaro ichisiya mureza wekukwereta usina kubatika.
    /// Kukwereta zvine mutsindo iyo `RefCell` nepo chirevo chakadzoserwa nenzira iyi chiri chipenyu chisina kujekeswa maitiro.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_ok());
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "borrow_state", since = "1.37.0")]
    #[inline]
    pub unsafe fn try_borrow_unguarded(&self) -> Result<&T, BorrowError> {
        if !is_writing(self.borrow.get()) {
            // Kachengeteka: Isu tinoongorora kuti hapana munhu ari kushingaira kunyora izvozvi, asi ndizvo
            // basa remunhu arifonera rekuona kuti hapana munhu anonyora kudzamara mareferenzi adzoserwa asisiri kushandiswa.
            // Zvakare, `self.value.get()` inoreva kukosha kwakabatwa ne `self` uye zvinobva zvavimbiswa kuve zvinoshanda kwehupenyu hwese hwe `self`.
            //
            //
            Ok(unsafe { &*self.value.get() })
        } else {
            Err(BorrowError { _private: () })
        }
    }
}

impl<T: Default> RefCell<T> {
    /// Inotora kukosha kwakaputirwa, ichisiya `Default::default()` munzvimbo yayo.
    ///
    /// # Panics
    ///
    /// Panics kana kukosha kuchikweretwa parizvino.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "refcell_take", since = "1.50.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for RefCell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for RefCell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for RefCell<T> {
    /// # Panics
    ///
    /// Panics kana kukosha kwacho kuchikweretwa zvino.
    #[inline]
    #[track_caller]
    fn clone(&self) -> RefCell<T> {
        RefCell::new(self.borrow().clone())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for RefCell<T> {
    /// Inogadzira `RefCell<T>`, iine `Default` kukosha kweT.
    #[inline]
    fn default() -> RefCell<T> {
        RefCell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for RefCell<T> {
    /// # Panics
    ///
    /// Panics kana kukosha mune chero `RefCell` kuchikweretwa pari zvino.
    #[inline]
    fn eq(&self, other: &RefCell<T>) -> bool {
        *self.borrow() == *other.borrow()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: ?Sized + Eq> Eq for RefCell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for RefCell<T> {
    /// # Panics
    ///
    /// Panics kana kukosha mune chero `RefCell` kuchikweretwa pari zvino.
    #[inline]
    fn partial_cmp(&self, other: &RefCell<T>) -> Option<Ordering> {
        self.borrow().partial_cmp(&*other.borrow())
    }

    /// # Panics
    ///
    /// Panics kana kukosha mune chero `RefCell` kuchikweretwa pari zvino.
    #[inline]
    fn lt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() < *other.borrow()
    }

    /// # Panics
    ///
    /// Panics kana kukosha mune chero `RefCell` kuchikweretwa pari zvino.
    #[inline]
    fn le(&self, other: &RefCell<T>) -> bool {
        *self.borrow() <= *other.borrow()
    }

    /// # Panics
    ///
    /// Panics kana kukosha mune chero `RefCell` kuchikweretwa pari zvino.
    #[inline]
    fn gt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() > *other.borrow()
    }

    /// # Panics
    ///
    /// Panics kana kukosha mune chero `RefCell` kuchikweretwa pari zvino.
    #[inline]
    fn ge(&self, other: &RefCell<T>) -> bool {
        *self.borrow() >= *other.borrow()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + Ord> Ord for RefCell<T> {
    /// # Panics
    ///
    /// Panics kana kukosha mune chero `RefCell` kuchikweretwa pari zvino.
    #[inline]
    fn cmp(&self, other: &RefCell<T>) -> Ordering {
        self.borrow().cmp(&*other.borrow())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for RefCell<T> {
    fn from(t: T) -> RefCell<T> {
        RefCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<RefCell<U>> for RefCell<T> {}

struct BorrowRef<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl<'b> BorrowRef<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRef<'b>> {
        let b = borrow.get().wrapping_add(1);
        if !is_reading(b) {
            // Kuwedzera chikwereti kunogona kukonzera kukosha kusiri kuverenga (<=0) mune izvi zviitiko:
            // 1. Yaive <0, kureva kuti pane kunyora zvikwereti, saka isu hatigone kubvumidza kuverenga kukweretwa nekuda kwe Rust's reference aliasing mitemo
            // 2.
            // Yakanga iri isize::MAX (iyo yakawanda huwandu hwekuverenga inokwereta) uye yakafashukira mu isize::MIN (iyo yakawanda huwandu hwekunyora inokwereta) saka isu hatigone kubvumira yekuwedzera kuverenga kukwereta nekuti isize haigone kumiririra yakawanda kuverenga zvikwereti (izvi zvinogona chete kuitika kana iwe mem::forget inopfuura diki diki inogara ye`Ref`s, inova isiri tsika yakanaka)
            //
            //
            //
            //
            None
        } else {
            // Kuwedzera chikwereti kunogona kukonzera kukosha kwekuverenga (> 0) mune idzi kesi:
            // 1. Yaive=0, kureva kuti yakanga isina kukweretwa, uye tiri kutora yekutanga kuverenga yakweretwa
            // 2. Yaive> 0 uye <isize::MAX, kureva
            // pakaverengerwa zvikwereti, uye isize yakakura zvakakwana kuti inomiririra kuve nekumwe kuverenga kuverenga kukwereta
            borrow.set(b);
            Some(BorrowRef { borrow })
        }
    }
}

impl Drop for BorrowRef<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        self.borrow.set(borrow - 1);
    }
}

impl Clone for BorrowRef<'_> {
    #[inline]
    fn clone(&self) -> Self {
        // Sezvo Ref iyi iriko, tinoziva mureza wekukwereta kuverenga kuverenga.
        //
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        // Kudzivirira iyo yekukwereta pakaunda kubva kufashukira kuita yekunyora chikwereti.
        //
        assert!(borrow != isize::MAX);
        self.borrow.set(borrow + 1);
        BorrowRef { borrow: self.borrow }
    }
}

/// Inoputira yakweretwa kukweretwa kune kukosha mubhokisi re `RefCell`.
/// Rudzi rwekuputira yemutengo usingachinjiki wakakweretwa kubva ku `RefCell<T>`.
///
/// Ona [module-level documentation](self) zvimwe.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Ref<'b, T: ?Sized + 'b> {
    value: &'b T,
    borrow: BorrowRef<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Ref<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

impl<'b, T: ?Sized> Ref<'b, T> {
    /// Kopa `Ref`.
    ///
    /// Iyo `RefCell` yatobhadharwa zvisingachinjiki, saka izvi hazvigone kutadza.
    ///
    /// Iri ibasa rakabatana rinoda kushandiswa se `Ref::clone(...)`.
    /// Kuitwa kwe `Clone` kana nzira ingavhiringidze kushandiswa kwakapararira kwe `r.borrow().clone()` kuumbiridza zviri mukati me `RefCell`.
    ///
    ///
    #[stable(feature = "cell_extras", since = "1.15.0")]
    #[inline]
    pub fn clone(orig: &Ref<'b, T>) -> Ref<'b, T> {
        Ref { value: orig.value, borrow: orig.borrow.clone() }
    }

    /// Inoita nyowani `Ref` yechinhu cheiyo yakakweretwa dhata.
    ///
    /// Iyo `RefCell` yatobhadharwa zvisingachinjiki, saka izvi hazvigone kutadza.
    ///
    /// Iri ibasa rakabatana rinoda kushandiswa se `Ref::map(...)`.
    /// Maitiro aigona kukanganisa nzira dzezita rimwe chete pane zviri mukati me `RefCell` inoshandiswa kuburikidza ne `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// let b1: Ref<(u32, char)> = c.borrow();
    /// let b2: Ref<u32> = Ref::map(b1, |t| &t.0);
    /// assert_eq!(*b2, 5)
    /// ```
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Ref<'b, U>
    where
        F: FnOnce(&T) -> &U,
    {
        Ref { value: f(orig.value), borrow: orig.borrow }
    }

    /// Inoita nyowani `Ref` yechimwe chinhu chinosarudzika cheiyo yakakweretwa data.
    /// Muchengeti wepakutanga anodzoserwa se `Err(..)` kana kuvhara kuchidzorera `None`.
    ///
    /// Iyo `RefCell` yatobhadharwa zvisingachinjiki, saka izvi hazvigone kutadza.
    ///
    /// Iri ibasa rakabatana rinoda kushandiswa se `Ref::filter_map(...)`.
    /// Maitiro aigona kukanganisa nzira dzezita rimwe chete pane zviri mukati me `RefCell` inoshandiswa kuburikidza ne `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    /// let b1: Ref<Vec<u32>> = c.borrow();
    /// let b2: Result<Ref<u32>, _> = Ref::filter_map(b1, |v| v.get(1));
    /// assert_eq!(*b2.unwrap(), 2);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Result<Ref<'b, U>, Self>
    where
        F: FnOnce(&T) -> Option<&U>,
    {
        match f(orig.value) {
            Some(value) => Ok(Ref { value, borrow: orig.borrow }),
            None => Err(orig),
        }
    }

    /// Inoparadzanisa `Ref` kuita akawanda `Ref`s ezvikamu zvakasiyana zveakakwereta dhata.
    ///
    /// Iyo `RefCell` yatobhadharwa zvisingachinjiki, saka izvi hazvigone kutadza.
    ///
    /// Iri ibasa rakabatana rinoda kushandiswa se `Ref::map_split(...)`.
    /// Maitiro aigona kukanganisa nzira dzezita rimwe chete pane zviri mukati me `RefCell` inoshandiswa kuburikidza ne `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{Ref, RefCell};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow();
    /// let (begin, end) = Ref::map_split(borrow, |slice| slice.split_at(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// ```
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(orig: Ref<'b, T>, f: F) -> (Ref<'b, U>, Ref<'b, V>)
    where
        F: FnOnce(&T) -> (&U, &V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (Ref { value: a, borrow }, Ref { value: b, borrow: orig.borrow })
    }

    /// Chinja kuva chirevo kune iri pasi data.
    ///
    /// `RefCell` iri pasi haigone kukweretwa zvinonzwisisika kubva zvekare uye ichagara ichitoonekwa seisingakweretesi.
    ///
    /// Haisi zano rakanaka kudonhedza kupfuura huwandu hwenongedzo.
    /// Iyo `RefCell` inogona kukweretwa isingachinjiki zvekare kana paingova nenhamba shoma yekudonha kwazara.
    ///
    /// Iri ibasa rakabatana rinoda kushandiswa se `Ref::leak(...)`.
    /// Maitiro aigona kukanganisa nzira dzezita rimwe chete pane zviri mukati me `RefCell` inoshandiswa kuburikidza ne `Deref`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, Ref};
    /// let cell = RefCell::new(0);
    ///
    /// let value = Ref::leak(cell.borrow());
    /// assert_eq!(*value, 0);
    ///
    /// assert!(cell.try_borrow().is_ok());
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: Ref<'b, T>) -> &'b T {
        // Nekukanganwa iyi Ref isu tinoona kuti iyo inokweretesa mu RefCell haigone kudzokera kuUNUSED mukati menguva yehupenyu `'b`.
        // Kugadzirisazve mamiriro ekuteedzera mamiriro kunoda chirevo chakasarudzika kune yakakweretwa RefCell.
        // Hapana zvimwe zvinongedzo zvinoshanduka zvinogona kugadzirwa kubva kuchitokisi chepakutanga.
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Ref<'b, U>> for Ref<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Ref<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

impl<'b, T: ?Sized> RefMut<'b, T> {
    /// Inoita nyowani `RefMut` yechinhu cheiyo yakakweretwa dhata, semuenzaniso, enum musiyano.
    ///
    /// Iyo `RefCell` yatobhadharwa zvine mutsindo, saka izvi hazvigone kutadza.
    ///
    /// Iri ibasa rakabatana rinoda kushandiswa se `RefMut::map(...)`.
    /// Maitiro aigona kukanganisa nzira dzezita rimwe chete pane zviri mukati me `RefCell` inoshandiswa kuburikidza ne `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// {
    ///     let b1: RefMut<(u32, char)> = c.borrow_mut();
    ///     let mut b2: RefMut<u32> = RefMut::map(b1, |t| &mut t.0);
    ///     assert_eq!(*b2, 5);
    ///     *b2 = 42;
    /// }
    /// assert_eq!(*c.borrow(), (42, 'b'));
    /// ```
    ///
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> RefMut<'b, U>
    where
        F: FnOnce(&mut T) -> &mut U,
    {
        // FIXME(nll-rfc#40): gadzirisa kukwereta-cheki
        let RefMut { value, borrow } = orig;
        RefMut { value: f(value), borrow }
    }

    /// Inoita nyowani `RefMut` yechimwe chinhu chinosarudzika cheiyo yakakweretwa data.
    /// Muchengeti wepakutanga anodzoserwa se `Err(..)` kana kuvhara kuchidzorera `None`.
    ///
    /// Iyo `RefCell` yatobhadharwa zvine mutsindo, saka izvi hazvigone kutadza.
    ///
    /// Iri ibasa rakabatana rinoda kushandiswa se `RefMut::filter_map(...)`.
    /// Maitiro aigona kukanganisa nzira dzezita rimwe chete pane zviri mukati me `RefCell` inoshandiswa kuburikidza ne `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    ///
    /// {
    ///     let b1: RefMut<Vec<u32>> = c.borrow_mut();
    ///     let mut b2: Result<RefMut<u32>, _> = RefMut::filter_map(b1, |v| v.get_mut(1));
    ///
    ///     if let Ok(mut b2) = b2 {
    ///         *b2 += 2;
    ///     }
    /// }
    ///
    /// assert_eq!(*c.borrow(), vec![1, 4, 3]);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> Result<RefMut<'b, U>, Self>
    where
        F: FnOnce(&mut T) -> Option<&mut U>,
    {
        // FIXME(nll-rfc#40): gadzirisa kukwereta-cheki
        let RefMut { value, borrow } = orig;
        let value = value as *mut T;
        // Kachengeteka: basa rinobatirira pane yakasarudzika mareferenzi kwenguva yacho
        // yekufona kwayo kuburikidza ne `orig`, uye iyo yekunongedzera inongobviswa-mukati meiyo yekufona basa isingatombo bvumidza yakasarudzika mareferenzi kutiza.
        //
        //
        match f(unsafe { &mut *value }) {
            Some(value) => Ok(RefMut { value, borrow }),
            None => {
                // KUCHENGETEKA: zvakafanana nepamusoro.
                Err(RefMut { value: unsafe { &mut *value }, borrow })
            }
        }
    }

    /// Inoparadzanisa `RefMut` kuita akawanda `RefMut`s ezvikamu zvakasiyana zveakakwereta dhata.
    ///
    /// `RefCell` iri pasi icharamba yakweretwa zvine mutsindo kudzamara vaviri vadzoka `RefMut`s vabuda pachiyero.
    ///
    /// Iyo `RefCell` yatobhadharwa zvine mutsindo, saka izvi hazvigone kutadza.
    ///
    /// Iri ibasa rakabatana rinoda kushandiswa se `RefMut::map_split(...)`.
    /// Maitiro aigona kukanganisa nzira dzezita rimwe chete pane zviri mukati me `RefCell` inoshandiswa kuburikidza ne `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow_mut();
    /// let (mut begin, mut end) = RefMut::map_split(borrow, |slice| slice.split_at_mut(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// begin.copy_from_slice(&[4, 3]);
    /// end.copy_from_slice(&[2, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(
        orig: RefMut<'b, T>,
        f: F,
    ) -> (RefMut<'b, U>, RefMut<'b, V>)
    where
        F: FnOnce(&mut T) -> (&mut U, &mut V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (RefMut { value: a, borrow }, RefMut { value: b, borrow: orig.borrow })
    }

    /// Chinja kuva chinoshanduka chinongedzo kune iri pasi data.
    ///
    /// `RefCell` yepasi haigone kukweretwa kubva zvekare uye ichagara ichitaridzika kunge yakweretwa zvine mutsindo, zvichiita kuti rejisheni yakadzoserwa ive yega yemukati.
    ///
    ///
    /// Iri ibasa rakabatana rinoda kushandiswa se `RefMut::leak(...)`.
    /// Maitiro aigona kukanganisa nzira dzezita rimwe chete pane zviri mukati me `RefCell` inoshandiswa kuburikidza ne `Deref`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, RefMut};
    /// let cell = RefCell::new(0);
    ///
    /// let value = RefMut::leak(cell.borrow_mut());
    /// assert_eq!(*value, 0);
    /// *value = 1;
    ///
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: RefMut<'b, T>) -> &'b mut T {
        // Nekukanganwa iyi BorrowRefMut isu tinoona kuti iyo inokwereta muRefCell haigone kudzokera kuUNUSED mukati menguva yehupenyu `'b`.
        // Kugadzirisazve mamiriro ekuteedzera mamiriro kunoda chirevo chakasarudzika kune yakakweretwa RefCell.
        // Hapana zvimwe zvinongedzo zvinogona kugadzirwa kubva kuchitokisi chepakutanga mukati menguva iyoyo yehupenyu, zvichiita kuti ikozvino ikweretese chirevo chega cheupenyu hwasara.
        //
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

struct BorrowRefMut<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl Drop for BorrowRefMut<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        self.borrow.set(borrow + 1);
    }
}

impl<'b> BorrowRefMut<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRefMut<'b>> {
        // NOTE: Kusiyana ne BorrowRefMut::clone, nyowani inodaidzwa kuti igadzire iyo yekutanga
        // chinoshandurwa chinongedzo, uye saka panofanirwa kuve parizvino pasina mareferenzi aripo.
        // Nekudaro, nepo Clone ichiwedzera iyo inogona kuchinjika kuverenga, pano isu tinongobvumidza chete kubvumira kuenda kubva UNUSED kuenda UNUSED, 1.
        //
        match borrow.get() {
            UNUSED => {
                borrow.set(UNUSED - 1);
                Some(BorrowRefMut { borrow })
            }
            _ => None,
        }
    }

    // Inosanganisa `BorrowRefMut`.
    //
    // Izvi zvinongoshanda chete kana `BorrowRefMut` imwe neimwe ikashandiswa kuteedzera chinongedzo chinoshandurwa kune yakasarudzika, isina nonoverlapping renji rechinhu chepakutanga.
    //
    // Izvi hazvisi muClone impl kuitira kuti kodhi isashevedze izvi zvachose.
    #[inline]
    fn clone(&self) -> BorrowRefMut<'b> {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        // Dzivirira iyo yekukwereta pakaunda kubva pakuzadza.
        assert!(borrow != isize::MIN);
        self.borrow.set(borrow - 1);
        BorrowRefMut { borrow: self.borrow }
    }
}

/// Rudzi rwekuputira yemutengo wakakweretwa unokweretwa kubva ku `RefCell<T>`.
///
/// Ona [module-level documentation](self) zvimwe.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefMut<'b, T: ?Sized + 'b> {
    value: &'b mut T,
    borrow: BorrowRefMut<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for RefMut<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for RefMut<'_, T> {
    #[inline]
    fn deref_mut(&mut self) -> &mut T {
        self.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<RefMut<'b, U>> for RefMut<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for RefMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

/// Iyo yepakutanga yechinyakare yekuchinja mukati me Rust.
///
/// Kana iwe uine revo `&T`, saka kazhinji mu Rust iyo compiler inoita optimizations zvinoenderana neruzivo rwekuti `&T` inonongedza kune isingachinjiki data.Kuchinja iro data, semuenzaniso kuburikidza nema alias kana nekufambisa `&T` kuita `&mut T`, inoonekwa seisina kujekeswa maitiro.
/// `UnsafeCell<T>` opts-kunze kweiyo isingachinjiki vimbiso ye `&T`: akagovaniswa mareferenzi `&UnsafeCell<T>` inogona kunongedzera kudatha iri kuchinjika.Izvi zvinonzi "interior mutability".
///
/// Dzimwe dzese mhando dzinobvumidza kuchinjika kwemukati, senge `Cell<T>` uye `RefCell<T>`, mukati shandisa `UnsafeCell` kuputira data ravo.
///
/// Ziva kuti chete iyo isingachinjiki vimbiso yezvakagovaniswa mareferenzi inokanganiswa ne `UnsafeCell`.Iyo yakasarudzika garandi yeinogona kuchinjika mareferenzi haina kukanganiswa.Iko hakuna * yepamutemo nzira yekuwana aliasing `&mut`, kunyangwe ne `UnsafeCell<T>`.
///
/// Iyo `UnsafeCell` API pachayo iri nyore kwazvo: [`.get()`] inokupa iyo yakasviba pointer `*mut T` kune zvirimo.Zviri kusvika ku _you_ seye dhizaini dhizaini yekushandisa iyo mbichana mbichana nenzira kwayo.
///
/// [`.get()`]: `UnsafeCell::get`
///
/// Iyo chaiyo Rust yekumisikidza mitemo ingangoita mukubuda, asi iwo akakosha mapoinzi haana kukakavara:
///
/// - Kana iwe ukagadzira chirevo chakachengeteka neupenyu `'a` (ingave `&T` kana `&mut T` rejista) iyo inowanikwa nekodhi yakachengeteka (semuenzaniso, nekuti wakadzorera iyo), saka haufanire kuwana iyo data munzira ipi neipi inopokana nereferensi yezasara ye `'a`.
/// Semuenzaniso, izvi zvinoreva kuti kana iwe ukatora iyo `*mut T` kubva ku `UnsafeCell<T>` ukaikanda ku `&T`, ipapo iyo data iri mu `T` inofanira kuramba isingachinjiki (modulo chero data re `UnsafeCell` rinowanikwa mukati me `T`, hongu) kusvikira hupenyu hwereferenzi hwapera.
/// Saizvozvo, kana iwe ukagadzira `&mut T` rejisheni iyo inosunungurwa kune yakachengeteka kodhi, saka haufanire kuwana iyo data mukati me `UnsafeCell` kudzamara chirevo icho chapera.
///
/// - Nguva dzese, unofanirwa kudzivirira nhangemutange yedata.Kana tambo dzakawanda dzichikwanisa kuwana iyo imwechete `UnsafeCell`, saka chero zvinonyorwa zvinofanirwa kuve nechaitika chinoitika-pamberi pehukama kune zvimwe zvese zvinowana (kana kushandisa maatomu).
///
/// Kubatsira neyakakodzera dhizaini, zvinotevera zviitiko zvinotaurwa zvakajeka zviri pamutemo kune imwechete-tambo kodhi:
///
/// 1. Chirevo che `&T` chinogona kuburitswa kukodhi yakachengeteka uye ipapo inogona kubatana pamwe nezvimwe zvinongedzo zve `&T`, asi kwete ne `&mut T`
///
/// 2. Chirevo che `&mut T` chinogona kusunungurwa kukodhi yakachengeteka chero imwe `&mut T` kana `&T` isipo nayo.`&mut T` inofanira kugara yakasarudzika.
///
/// Ziva kuti uku uchichinja zvirimo mu `&UnsafeCell<T>` (kunyangwe dzimwe `&UnsafeCell<T>` mareferensi ari kune imwe sero) zvakanaka (chero iwe uchimanikidza zvinokuvadza pamusoro apa neimwe nzira), ichiri chisina kujekeswa maitiro ekuti uwane akawanda ma `&mut UnsafeCell<T>`.
/// Ndokunge, `UnsafeCell` inoputira yakagadzirirwa kuve nehukama hwakakosha ne _shared_ accesses (_i.e._, kuburikidza neiyo `&UnsafeCell<_>` rejista);hapana mashiripiti chero api zvawo paunenge uchibata ne _exclusive_ accesses (_e.g._, kuburikidza ne `&mut UnsafeCell<_>`): kana sero kana kukosha kwakaputirwa kunogona kupihwa mukana kwenguva iyo iyo `&mut` inokwereta.
///
/// Izvi zvinoratidzwa ne [`.get_mut()`] accessor, inova _safe_ getter inoburitsa `&mut T`.
///
/// [`.get_mut()`]: `UnsafeCell::get_mut`
///
/// # Examples
///
/// Heino muenzaniso uratidzira maitiro ekuchinja zvine mutsindo zviri mukati me `UnsafeCell<_>` kunyangwe paine akawanda mareferenzi anomisa sero:
///
/// ```
/// use std::cell::UnsafeCell;
///
/// let x: UnsafeCell<i32> = 42.into();
/// // Tora akawanda/akagovaniswa mareferenzi kune imwecheteyo `x`.
/// let (p1, p2): (&UnsafeCell<i32>, &UnsafeCell<i32>) = (&x, &x);
///
/// unsafe {
///     // KUCHENGETEKA: mukati meichi chiyero hapana zvimwe zvinongedzo kune zviri mukati `x,
///     // saka yedu yakasarudzika yakasarudzika.
///     let p1_exclusive: &mut i32 = &mut *p1.get(); // -- kukwereta-+
///     *p1_exclusive += 27; // |
/// } // <---------- haigone kupfuura iyi poindi -------------------+
///
/// unsafe {
///     // KUCHENGETEKA: mukati meichi chiyero hapana munhu anotarisira kuve nekwaniso yekuwana kune zviri mukati ma` x,
///     // saka tinogona kuwana akawanda akagovaniswa mawaniro panguva imwe chete.
///     let p2_shared: &i32 = &*p2.get();
///     assert_eq!(*p2_shared, 42 + 27);
///     let p1_shared: &i32 = &*p1.get();
///     assert_eq!(*p1_shared, *p2_shared);
/// }
/// ```
///
/// Muenzaniso unotevera unoratidza chokwadi chekuti mukana wekupinda mu `UnsafeCell<T>` unoreva kuwanikwa kwakazara kune `T` yayo:
///
/// ```rust
/// #![forbid(unsafe_code)] // pamwe chete nevanopinda,
///                         // `UnsafeCell` iri pachena isina-op inoputira, saka hapana kudiwa kwe `unsafe` pano.
/////
/// use std::cell::UnsafeCell;
///
/// let mut x: UnsafeCell<i32> = 42.into();
///
/// // Tora rondedzero-yenguva-yakatariswa yakasarudzika rezita kune `x`.
/// let p_unique: &mut UnsafeCell<i32> = &mut x;
/// // Nechirevo chega, tinogona kuchinjisa zvirimo mahara.
/// *p_unique.get_mut() = 0;
/// // Kana, zvakafanana:
/// x = UnsafeCell::new(0);
///
/// // Kana isu tichinge tine hukoshi, tinogona kubvisa zvirimo mahara.
/// let contents: i32 = x.into_inner();
/// assert_eq!(contents, 0);
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "unsafe_cell"]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
#[repr(no_niche)] // rust-lang/rust#68303.
pub struct UnsafeCell<T: ?Sized> {
    value: T,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for UnsafeCell<T> {}

impl<T> UnsafeCell<T> {
    /// Inovaka chiitiko chitsva che `UnsafeCell` icho chinoputira kukosha kwakataurwa.
    ///
    ///
    /// Kwese kuwana kune yemukati kukosha kuburikidza nenzira ndeye `unsafe`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafe_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> UnsafeCell<T> {
        UnsafeCell { value }
    }

    /// Unwraps kukosha.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.into_inner();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value
    }
}

impl<T: ?Sized> UnsafeCell<T> {
    /// Inowana chinoshandisika chinongedzera kune chakaputirwa kukosha.
    ///
    /// Izvi zvinogona kukandwa kunongedzera chero mhando.
    /// Ita shuwa kuti iko kuwana kwakasarudzika (hapana zvinongedzo zvinoshanda, zvinoshanduka kana kwete) kana uchikanda ku `&mut T`, uye uone kuti hapana shanduko kana zvinoshanduka zvinomiririra zviri kuitika kana uchikanda ku `&T`
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.get();
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafecell_get", since = "1.32.0")]
    pub const fn get(&self) -> *mut T {
        // Tinogona kungokanda pointer kubva ku `UnsafeCell<T>` kusvika ku `T` nekuda kwe #[repr(transparent)].
        // Izvi zvinoshandisa chinzvimbo chakasununguka che libstd, hapana vimbiso yekodhi yemushandisi kuti izvi zvinoshanda mu future shanduro dzemugadziri!
        //
        self as *const UnsafeCell<T> as *const T as *mut T
    }

    /// Inodzorera chinongedzo chinoshandurwa kune iri pasi data.
    ///
    /// Kufona uku kunokwereta iyo `UnsafeCell` zvine mutsindo (panguva yekubatanidza-nguva) iyo inovimbisa kuti isu tine chete chirevo.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let mut c = UnsafeCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(*c.get_mut(), 6);
    /// ```
    #[inline]
    #[stable(feature = "unsafe_cell_get_mut", since = "1.50.0")]
    pub fn get_mut(&mut self) -> &mut T {
        &mut self.value
    }

    /// Inowana chinoshandisika chinongedzera kune chakaputirwa kukosha.
    /// Musiyano we [`get`] ndewekuti basa iri rinogamuchira pointer mbishi, iyo inobatsira kudzivirira kugadzirwa kwemareferenzi enguva pfupi.
    ///
    /// Mhedzisiro yacho inogona kukandirwa kunongedzera chero ipi mhando.
    /// Ita shuwa kuti iko kuwana kwakasarudzika (hapana zvinoshanda zvinongedzo, zvinoshandisika kana kwete) kana uchikanda ku `&mut T`, uye uone kuti hapana shanduko kana zvinoshanduka zvinomiririra zviri kuitika kana uchikanda ku `&T`.
    ///
    ///
    /// [`get`]: UnsafeCell::get()
    ///
    /// # Examples
    ///
    /// Kutanga zvishoma nezvishoma kwe `UnsafeCell` kunoda `raw_get`, sekufonera `get` kungangoda kugadzira referensi kune isina kuvhurwa dhata:
    ///
    /// ```
    /// #![feature(unsafe_cell_raw_get)]
    /// use std::cell::UnsafeCell;
    /// use std::mem::MaybeUninit;
    ///
    /// let m = MaybeUninit::<UnsafeCell<i32>>::uninit();
    /// unsafe { UnsafeCell::raw_get(m.as_ptr()).write(5); }
    /// let uc = unsafe { m.assume_init() };
    ///
    /// assert_eq!(uc.into_inner(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "unsafe_cell_raw_get", issue = "66358")]
    pub const fn raw_get(this: *const Self) -> *mut T {
        // Tinogona kungokanda pointer kubva ku `UnsafeCell<T>` kusvika ku `T` nekuda kwe #[repr(transparent)].
        // Izvi zvinoshandisa chinzvimbo chakasununguka che libstd, hapana vimbiso yekodhi yemushandisi kuti izvi zvinoshanda mu future shanduro dzemugadziri!
        //
        this as *const T as *mut T
    }
}

#[stable(feature = "unsafe_cell_default", since = "1.10.0")]
impl<T: Default> Default for UnsafeCell<T> {
    /// Inogadzira `UnsafeCell`, iine `Default` kukosha kweT.
    fn default() -> UnsafeCell<T> {
        UnsafeCell::new(Default::default())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for UnsafeCell<T> {
    fn from(t: T) -> UnsafeCell<T> {
        UnsafeCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<UnsafeCell<U>> for UnsafeCell<T> {}

#[allow(unused)]
fn assert_coerce_unsized(a: UnsafeCell<&i32>, b: Cell<&i32>, c: RefCell<&i32>) {
    let _: UnsafeCell<&dyn Send> = a;
    let _: Cell<&dyn Send> = b;
    let _: RefCell<&dyn Send> = c;
}