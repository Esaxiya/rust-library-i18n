//! Windows SEH
//!
//! Op Windows (momenteel alleen op MSVC), is het standaard afhandelingsmechanisme voor uitzonderingen Structured Exception Handling (SEH).
//! Dit is heel anders dan op Dwarf gebaseerde afhandeling van uitzonderingen (bijv. Wat andere unix-platforms gebruiken) in termen van compiler-internals, dus LLVM heeft veel extra ondersteuning nodig voor SEH.
//!
//! In een notendop, wat hier gebeurt, is:
//!
//! 1. De `panic`-functie roept de standaard Windows-functie `_CxxThrowException` aan om een C++ -achtige uitzondering te genereren, waardoor het afwikkelproces wordt geactiveerd.
//! 2.
//! Alle landingsplatforms die door de compiler worden gegenereerd, gebruiken de persoonlijkheidsfunctie `__CxxFrameHandler3`, een functie in de CRT, en de afwikkelcode in Windows zal deze persoonlijkheidsfunctie gebruiken om alle opschooncode op de stapel uit te voeren.
//!
//! 3. Alle door de compiler gegenereerde aanroepen naar `invoke` hebben een landingsplatform dat is ingesteld als een `cleanuppad` LLVM-instructie, die het begin van de opschoningsroutine aangeeft.
//! De persoonlijkheid (in stap 2, gedefinieerd in de CRT) is verantwoordelijk voor het uitvoeren van de opschoningsroutines.
//! 4. Uiteindelijk wordt de "catch"-code in de `try` intrinsiek (gegenereerd door de compiler) uitgevoerd en geeft aan dat de controle terug moet komen naar Rust.
//! Dit wordt gedaan via een `catchswitch` plus een `catchpad`-instructie in LLVM IR-termen, en uiteindelijk keert de normale besturing terug naar het programma met een `catchret`-instructie.
//!
//! Enkele specifieke verschillen met de op gcc gebaseerde afhandeling van uitzonderingen zijn:
//!
//! * Rust heeft geen aangepaste persoonlijkheidsfunctie, het is in plaats daarvan *altijd*`__CxxFrameHandler3`.Bovendien wordt er geen extra filtering uitgevoerd, dus we vangen alle C++ -uitzonderingen op die er toevallig uitzien als de soort die we gooien.
//! Merk op dat het gooien van een uitzondering in Rust sowieso ongedefinieerd gedrag is, dus dit zou in orde moeten zijn.
//! * We hebben wat gegevens om over de afwikkelingsgrens te verzenden, met name een `Box<dyn Any + Send>`.Net als bij Dwarf-uitzonderingen worden deze twee verwijzingen als een payload in de uitzondering zelf opgeslagen.
//! Op MSVC is er echter geen extra heap-toewijzing nodig omdat de call-stack behouden blijft terwijl filterfuncties worden uitgevoerd.
//! Dit betekent dat de pointers rechtstreeks naar `_CxxThrowException` worden gestuurd, die vervolgens worden hersteld in de filterfunctie om naar het stackframe van de intrinsieke `try` te worden geschreven.
//!
//! [win64]: https://docs.microsoft.com/en-us/cpp/build/exception-handling-x64
//! [llvm]: http://llvm.org/docs/ExceptionHandling.html#background-on-windows-exceptions
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(nonstandard_style)]

use alloc::boxed::Box;
use core::any::Any;
use core::mem::{self, ManuallyDrop};
use libc::{c_int, c_uint, c_void};

struct Exception {
    // Dit moet een optie zijn omdat we de uitzondering door verwijzing opvangen en de destructor ervan wordt uitgevoerd door de C++ runtime.
    // Wanneer we de Box uit de uitzondering halen, moeten we de uitzondering in een geldige staat laten zodat de destructor kan werken zonder de Box dubbel te laten vallen.
    //
    //
    data: Option<Box<dyn Any + Send>>,
}

// Allereerst een hele reeks typedefinities.Er zijn hier een paar platformspecifieke eigenaardigheden, en veel is gewoon overduidelijk gekopieerd van LLVM.Het doel van dit alles is om de onderstaande `panic`-functie te implementeren door `_CxxThrowException` aan te roepen.
//
// Deze functie heeft twee argumenten.De eerste is een verwijzing naar de gegevens die we doorgeven, in dit geval ons trait-object.Vrij gemakkelijk te vinden!Het volgende is echter ingewikkelder.
// Dit is een pointer naar een `_ThrowInfo`-structuur, en het is over het algemeen alleen bedoeld om de uitzondering te beschrijven die wordt gegenereerd.
//
// Momenteel is de definitie van dit type [1] een beetje harig, en de belangrijkste eigenaardigheid (en verschil met het online artikel) is dat op 32-bit de pointers pointers zijn, maar op 64-bit de pointers worden uitgedrukt als 32-bit offsets van de `__ImageBase`-symbool.
//
// De `ptr_t`-en `ptr!`-macro in de onderstaande modules worden gebruikt om dit uit te drukken.
//
// Het doolhof van typedefinities volgt ook nauwgezet wat LLVM uitzendt voor dit soort operaties.Als u bijvoorbeeld deze C++ -code compileert op MSVC en de LLVM IR uitzendt:
//
//      #include <stdint.h>
//
//      struct rust_panic {
//          rust_panic(const rust_panic&);
//          ~rust_panic();
//
//          uint64_t x[2];};
//
//      leegte foo() { rust_panic a = {0, 1};
//          Gooi een;}
//
// Dat is in wezen wat we proberen na te bootsen.De meeste van de onderstaande constante waarden zijn zojuist gekopieerd van LLVM,
//
// In elk geval zijn deze structuren allemaal op een vergelijkbare manier geconstrueerd, en het is gewoon een beetje uitgebreid voor ons.
//
// [1]: http://www.geoffchappell.com/studies/msvc/language/predefined/
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

#[cfg(target_arch = "x86")]
#[macro_use]
mod imp {
    pub type ptr_t = *mut u8;

    macro_rules! ptr {
        (0) => {
            core::ptr::null_mut()
        };
        ($e:expr) => {
            $e as *mut u8
        };
    }
}

#[cfg(not(target_arch = "x86"))]
#[macro_use]
mod imp {
    pub type ptr_t = u32;

    extern "C" {
        pub static __ImageBase: u8;
    }

    macro_rules! ptr {
        (0) => (0);
        ($e:expr) => {
            (($e as usize) - (&imp::__ImageBase as *const _ as usize)) as u32
        }
    }
}

#[repr(C)]
pub struct _ThrowInfo {
    pub attributes: c_uint,
    pub pmfnUnwind: imp::ptr_t,
    pub pForwardCompat: imp::ptr_t,
    pub pCatchableTypeArray: imp::ptr_t,
}

#[repr(C)]
pub struct _CatchableTypeArray {
    pub nCatchableTypes: c_int,
    pub arrayOfCatchableTypes: [imp::ptr_t; 1],
}

#[repr(C)]
pub struct _CatchableType {
    pub properties: c_uint,
    pub pType: imp::ptr_t,
    pub thisDisplacement: _PMD,
    pub sizeOrOffset: c_int,
    pub copyFunction: imp::ptr_t,
}

#[repr(C)]
pub struct _PMD {
    pub mdisp: c_int,
    pub pdisp: c_int,
    pub vdisp: c_int,
}

#[repr(C)]
pub struct _TypeDescriptor {
    pub pVFTable: *const u8,
    pub spare: *mut u8,
    pub name: [u8; 11],
}

// Merk op dat we hier bewust de regels voor naammangeling negeren: we willen niet dat C++ Rust panics kan vangen door simpelweg een `struct rust_panic` te declareren.
//
//
// Zorg er bij het wijzigen voor dat de tekenreeks voor de typenaam exact overeenkomt met de tekenreeks die wordt gebruikt in `compiler/rustc_codegen_llvm/src/intrinsic.rs`.
//
const TYPE_NAME: [u8; 11] = *b"rust_panic\0";

static mut THROW_INFO: _ThrowInfo = _ThrowInfo {
    attributes: 0,
    pmfnUnwind: ptr!(0),
    pForwardCompat: ptr!(0),
    pCatchableTypeArray: ptr!(0),
};

static mut CATCHABLE_TYPE_ARRAY: _CatchableTypeArray =
    _CatchableTypeArray { nCatchableTypes: 1, arrayOfCatchableTypes: [ptr!(0)] };

static mut CATCHABLE_TYPE: _CatchableType = _CatchableType {
    properties: 0,
    pType: ptr!(0),
    thisDisplacement: _PMD { mdisp: 0, pdisp: -1, vdisp: 0 },
    sizeOrOffset: mem::size_of::<Exception>() as c_int,
    copyFunction: ptr!(0),
};

extern "C" {
    // De leidende `\x01`-byte hier is eigenlijk een magisch signaal naar LLVM om *geen* andere verminkingen toe te passen, zoals voorvoegsel met een `_`-teken.
    //
    //
    // Dit symbool is de vtable die wordt gebruikt door C++ 's `std::type_info`.
    // Objecten van het type `std::type_info`, typebeschrijvingen, hebben een verwijzing naar deze tabel.
    // Naar typebeschrijvingen wordt verwezen door de C++ EH-structuren die hierboven zijn gedefinieerd en die we hieronder construeren.
    //
    #[link_name = "\x01??_7type_info@@6B@"]
    static TYPE_INFO_VTABLE: *const u8;
}

// Deze typebeschrijving wordt alleen gebruikt bij het genereren van een uitzondering.
// Het catch-gedeelte wordt afgehandeld door de intrinsieke try, die zijn eigen TypeDescriptor genereert.
//
// Dit is prima aangezien de MSVC-runtime stringvergelijking gebruikt voor de typenaam om overeen te komen met TypeDescriptors in plaats van pointergelijkheid.
//
static mut TYPE_DESCRIPTOR: _TypeDescriptor = _TypeDescriptor {
    pVFTable: unsafe { &TYPE_INFO_VTABLE } as *const _ as *const _,
    spare: core::ptr::null_mut(),
    name: TYPE_NAME,
};

// Destructor gebruikt als de C++ -code besluit de uitzondering vast te leggen en te verwijderen zonder deze door te geven.
// Het catch-gedeelte van de intrinsieke try stelt het eerste woord van het exception-object in op 0, zodat het wordt overgeslagen door de destructor.
//
// Merk op dat x86 Windows de "thiscall"-aanroepconventie gebruikt voor C++ -lidfuncties in plaats van de standaard "C"-aanroepconventie.
//
// De exception_copy-functie is hier een beetje speciaal: deze wordt aangeroepen door de MSVC-runtime onder een try/catch-blok en de panic die we hier genereren, wordt gebruikt als het resultaat van de uitzonderingskopie.
//
// Dit wordt gebruikt door de C++ -runtime om het vastleggen van uitzonderingen met std::exception_ptr te ondersteunen, wat we niet kunnen ondersteunen omdat Box<dyn Any>is niet te klonen.
//
//
//
//
//
macro_rules! define_cleanup {
    ($abi:tt) => {
        unsafe extern $abi fn exception_cleanup(e: *mut Exception) {
            if let Exception { data: Some(b) } = e.read() {
                drop(b);
                super::__rust_drop_panic();
            }
        }
        #[unwind(allowed)]
        unsafe extern $abi fn exception_copy(_dest: *mut Exception,
                                             _src: *mut Exception)
                                             -> *mut Exception {
            panic!("Rust panics cannot be copied");
        }
    }
}
cfg_if::cfg_if! {
   if #[cfg(target_arch = "x86")] {
       define_cleanup!("thiscall");
   } else {
       define_cleanup!("C");
   }
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    use core::intrinsics::atomic_store;

    // _CxxThrowException wordt volledig op dit stackframe uitgevoerd, dus het is niet nodig om `data` anders naar de heap over te dragen.
    // We geven gewoon een stapelaanwijzer door aan deze functie.
    //
    // De ManuallyDrop is hier nodig omdat we niet willen dat Exception wordt verwijderd bij het afwikkelen.
    // In plaats daarvan wordt het verwijderd door exception_cleanup die wordt aangeroepen door de C++ -runtime.
    //
    //
    let mut exception = ManuallyDrop::new(Exception { data: Some(data) });
    let throw_ptr = &mut exception as *mut _ as *mut _;

    // Dit ... lijkt misschien verrassend, en terecht.Op 32-bits MSVC zijn de verwijzingen tussen deze structuren precies dat, verwijzingen.
    // Op 64-bits MSVC worden de verwijzingen tussen structuren echter eerder uitgedrukt als 32-bits offsets van `__ImageBase`.
    //
    // Bijgevolg kunnen we op 32-bit MSVC al deze verwijzingen in de `static`s hierboven aangeven.
    // Op 64-bit MSVC zouden we aftrekken van pointers in statica moeten uitdrukken, wat Rust momenteel niet toestaat, dus dat kunnen we eigenlijk niet doen.
    //
    // Het op één na beste is om deze structuren tijdens runtime in te vullen (paniek is sowieso al bij de "slow path").
    // Dus hier herinterpreteren we al deze pointer-velden als 32-bits gehele getallen en slaan we de relevante waarde erin op (atomair, aangezien gelijktijdige panics kan plaatsvinden).
    //
    // Technisch gezien zal de runtime waarschijnlijk een niet-atomaire lezing van deze velden uitvoeren, maar in theorie lezen ze nooit de *verkeerde* waarde, dus het zou niet al te slecht moeten zijn ...
    //
    // In elk geval moeten we in principe zoiets doen totdat we meer bewerkingen in statica kunnen uitdrukken (en dat zullen we misschien nooit kunnen).
    //
    //
    //
    //
    //
    //
    //
    //
    atomic_store(&mut THROW_INFO.pmfnUnwind as *mut _ as *mut u32, ptr!(exception_cleanup) as u32);
    atomic_store(
        &mut THROW_INFO.pCatchableTypeArray as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE_ARRAY as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE_ARRAY.arrayOfCatchableTypes[0] as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.pType as *mut _ as *mut u32,
        ptr!(&TYPE_DESCRIPTOR as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.copyFunction as *mut _ as *mut u32,
        ptr!(exception_copy) as u32,
    );

    extern "system" {
        #[unwind(allowed)]
        fn _CxxThrowException(pExceptionObject: *mut c_void, pThrowInfo: *mut u8) -> !;
    }

    _CxxThrowException(throw_ptr, &mut THROW_INFO as *mut _ as *mut _);
}

pub unsafe fn cleanup(payload: *mut u8) -> Box<dyn Any + Send> {
    // Een NULL-payload hier betekent dat we hier zijn gekomen van de vangst (...) van __rust_try.
    // Dit gebeurt wanneer een niet-Rust buitenlandse uitzondering wordt opgemerkt.
    if payload.is_null() {
        super::__rust_foreign_exception();
    } else {
        let exception = &mut *(payload as *mut Exception);
        exception.data.take().unwrap()
    }
}

// Dit is vereist door de compiler om te bestaan (het is bijvoorbeeld een lang item), maar het wordt nooit echt aangeroepen door de compiler omdat __C_specific_handler of_except_handler3 de persoonlijkheidsfunctie is die altijd wordt gebruikt.
//
// Daarom is dit slechts een afbrekende stomp.
//
#[lang = "eh_personality"]
#[cfg(not(test))]
fn rust_eh_personality() {
    core::intrinsics::abort()
}