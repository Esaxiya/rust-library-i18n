//! panics afwikkelen voor Miri.
use alloc::boxed::Box;
use core::any::Any;

// Het type lading dat de Miri-motor voor ons voortplant door af te wikkelen.
// Moet de grootte van een aanwijzer hebben.
type Payload = Box<Box<dyn Any + Send>>;

extern "Rust" {
    /// Door Miri geleverde externe functie om te beginnen met ontspannen.
    fn miri_start_panic(payload: *mut u8) -> !;
}

pub unsafe fn panic(payload: Box<dyn Any + Send>) -> u32 {
    // De payload die we doorgeven aan `miri_start_panic` zal precies het argument zijn dat we hieronder in `cleanup` krijgen.
    // Dus we doen het maar één keer in dozen om iets ter grootte van een wijzer te krijgen.
    let payload_box: Payload = Box::new(payload);
    miri_start_panic(Box::into_raw(payload_box) as *mut u8)
}

pub unsafe fn cleanup(payload_box: *mut u8) -> Box<dyn Any + Send> {
    // Herstel de onderliggende `Box`.
    let payload_box: Payload = Box::from_raw(payload_box as *mut _);
    *payload_box
}