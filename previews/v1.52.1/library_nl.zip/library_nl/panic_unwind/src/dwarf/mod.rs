//! Hulpprogramma's voor het parseren van DWARF-gecodeerde datastromen.
//! Zie <http://www.dwarfstd.org>, DWARF-4-standaard, Sectie 7, "Data Representation"
//!

// Deze module wordt voorlopig alleen gebruikt door x86_64-pc-windows-gnu, maar we compileren hem overal om regressies te voorkomen.
//
#![allow(unused)]

#[cfg(test)]
mod tests;

pub mod eh;

use core::mem;

pub struct DwarfReader {
    pub ptr: *const u8,
}

#[repr(C, packed)]
struct Unaligned<T>(T);

impl DwarfReader {
    pub fn new(ptr: *const u8) -> DwarfReader {
        DwarfReader { ptr }
    }

    // DWARF-streams zijn verpakt, dus een u32 hoeft bijvoorbeeld niet per se op een 4-byte-grens te zijn uitgelijnd.
    // Dit kan problemen veroorzaken op platforms met strikte uitlijnvereisten.
    // Door gegevens in een "packed"-structuur te wikkelen, vertellen we de backend om "misalignment-safe"-code te genereren.
    //
    pub unsafe fn read<T: Copy>(&mut self) -> T {
        let Unaligned(result) = *(self.ptr as *const Unaligned<T>);
        self.ptr = self.ptr.add(mem::size_of::<T>());
        result
    }

    // ULEB128-en SLEB128-coderingen worden gedefinieerd in Sectie 7.6, "Variable Length Data".
    //
    pub unsafe fn read_uleb128(&mut self) -> u64 {
        let mut shift: usize = 0;
        let mut result: u64 = 0;
        let mut byte: u8;
        loop {
            byte = self.read::<u8>();
            result |= ((byte & 0x7F) as u64) << shift;
            shift += 7;
            if byte & 0x80 == 0 {
                break;
            }
        }
        result
    }

    pub unsafe fn read_sleb128(&mut self) -> i64 {
        let mut shift: u32 = 0;
        let mut result: u64 = 0;
        let mut byte: u8;
        loop {
            byte = self.read::<u8>();
            result |= ((byte & 0x7F) as u64) << shift;
            shift += 7;
            if byte & 0x80 == 0 {
                break;
            }
        }
        // sign-extend
        if shift < u64::BITS && (byte & 0x40) != 0 {
            result |= (!0 as u64) << shift;
        }
        result as i64
    }
}