//! Implementatie van panics via afwikkelen van de stapel
//!
//! Deze crate is een implementatie van panics in Rust met behulp van het "most native"-stapelafwikkelmechanisme van het platform waarvoor dit wordt gecompileerd.
//! Dit wordt momenteel in wezen onderverdeeld in drie buckets:
//!
//! 1. MSVC-doelen gebruiken SEH in het `seh.rs`-bestand.
//! 2. Emscripten gebruikt C++ -uitzonderingen in het `emcc.rs`-bestand.
//! 3. Alle andere doelen gebruiken libunwind/libgcc in het `gcc.rs`-bestand.
//!
//! Meer documentatie over elke implementatie is te vinden in de betreffende module.
//!
//!

#![no_std]
#![unstable(feature = "panic_unwind", issue = "32837")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/"
)]
#![feature(core_intrinsics)]
#![feature(int_bits_const)]
#![feature(lang_items)]
#![feature(nll)]
#![feature(panic_unwind)]
#![feature(staged_api)]
#![feature(std_internals)]
#![feature(unwind_attributes)]
#![feature(abi_thiscall)]
#![feature(rustc_attrs)]
#![feature(raw)]
#![panic_runtime]
#![feature(panic_runtime)]
// `real_imp` wordt niet gebruikt bij Miri, dus houd waarschuwingen stil.
#![cfg_attr(miri, allow(dead_code))]

use alloc::boxed::Box;
use core::any::Any;
use core::panic::BoxMeUp;

cfg_if::cfg_if! {
    if #[cfg(target_os = "emscripten")] {
        #[path = "emcc.rs"]
        mod real_imp;
    } else if #[cfg(target_os = "hermit")] {
        #[path = "hermit.rs"]
        mod real_imp;
    } else if #[cfg(target_env = "msvc")] {
        #[path = "seh.rs"]
        mod real_imp;
    } else if #[cfg(any(
        all(target_family = "windows", target_env = "gnu"),
        target_os = "psp",
        target_family = "unix",
        all(target_vendor = "fortanix", target_env = "sgx"),
    ))] {
        // De opstartobjecten van Rust runtime zijn afhankelijk van deze symbolen, dus maak ze openbaar.
        #[cfg(all(target_os="windows", target_arch = "x86", target_env="gnu"))]
        pub use real_imp::eh_frame_registry::*;
        #[path = "gcc.rs"]
        mod real_imp;
    } else {
        // Doelen die het afwikkelen niet ondersteunen.
        // - arch=wasm32
        // - os=none ("bare metal"-doelen)
        // - os=uefi
        // - nvptx64-nvidia-cuda
        // - arch=avr
        #[path = "dummy.rs"]
        mod real_imp;
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        // Gebruik de Miri-runtime.
        // We moeten nog steeds de normale runtime hierboven laden, omdat rustc verwacht dat bepaalde lang items van daaruit worden gedefinieerd.
        //
        #[path = "miri.rs"]
        mod imp;
    } else {
        // Gebruik de echte looptijd.
        use real_imp as imp;
    }
}

extern "C" {
    /// Handler in libstd wordt aangeroepen wanneer een panic-object buiten `catch_unwind` wordt neergezet.
    ///
    fn __rust_drop_panic() -> !;

    /// Handler in libstd wordt aangeroepen wanneer een buitenlandse uitzondering wordt opgevangen.
    fn __rust_foreign_exception() -> !;
}

mod dwarf;

#[rustc_std_internal_symbol]
#[allow(improper_ctypes_definitions)]
pub unsafe extern "C" fn __rust_panic_cleanup(payload: *mut u8) -> *mut (dyn Any + Send + 'static) {
    Box::into_raw(imp::cleanup(payload))
}

// Toegangspunt voor het indienen van een uitzondering, delegeert gewoon naar de platformspecifieke implementatie.
//
#[rustc_std_internal_symbol]
#[unwind(allowed)]
pub unsafe extern "C" fn __rust_start_panic(payload: *mut &mut dyn BoxMeUp) -> u32 {
    let payload = Box::from_raw((*payload).take_box());

    imp::panic(payload)
}