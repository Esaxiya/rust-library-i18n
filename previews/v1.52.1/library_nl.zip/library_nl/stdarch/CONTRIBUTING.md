# Bijdragen aan stdarch

De `stdarch` crate accepteert graag bijdragen!Eerst wil je waarschijnlijk de repository bekijken en ervoor zorgen dat de tests voor je slagen:

```
$ git clone https://github.com/rust-lang/stdarch
$ cd stdarch
$ TARGET="<your-target-arch>" ci/run.sh
```

Waarbij `<your-target-arch>` de target triple is zoals gebruikt door `rustup`, bijv. `x86_x64-unknown-linux-gnu` (zonder voorafgaande `nightly-` of iets dergelijks).
Onthoud ook dat deze repository het nachtelijke kanaal van Rust vereist!
De bovenstaande tests vereisen in feite dat nachtelijke rust de standaard op uw systeem is, om in te stellen dat `rustup default nightly` wordt gebruikt (en `rustup default stable` om terug te draaien).

Als een van de bovenstaande stappen niet werkt, [please let us know][new]!

Vervolgens kun je [find an issue][issues] helpen, we hebben er een paar geselecteerd met de [`help wanted`][help]-en [`impl-period`][impl]-tags die vooral wat hulp kunnen gebruiken. 
U bent wellicht het meest geïnteresseerd in [#40][vendor], waarbij alle intrinsieke elementen van de leverancier op x86 zijn geïmplementeerd.Die kwestie heeft een aantal goede tips over waar te beginnen!

Als je algemene vragen hebt, neem dan gerust contact op met [join us on gitter][gitter] en vraag rond!Voel je vrij om@BurntSushi of@alexcrichton te pingen met vragen.

[gitter]: https://gitter.im/rust-impl-period/WG-libs-simd

# Hoe voorbeelden te schrijven voor stdarch intrinsiek

Er zijn een paar functies die moeten worden ingeschakeld om de gegeven intrinsieke functie correct te laten werken en het voorbeeld mag alleen worden uitgevoerd door `cargo test --doc` als de functie wordt ondersteund door de CPU.

Als gevolg hiervan zal de standaard `fn main` die wordt gegenereerd door `rustdoc` niet werken (in de meeste gevallen).
Overweeg het volgende als richtlijn te gebruiken om ervoor te zorgen dat uw voorbeeld werkt zoals verwacht.

```rust
/// # // We hebben cfg_target_feature nodig om ervoor te zorgen dat het voorbeeld alleen
/// # // uitgevoerd door `cargo test --doc` wanneer de CPU de functie ondersteunt
/// # #![feature(cfg_target_feature)]
/// # // We hebben target_feature nodig om het intrinsieke te laten werken
/// # #![feature(target_feature)]
/// #
/// # // rustdoc gebruikt standaard `extern crate stdarch`, maar we hebben de
/// # // `#[macro_use]`
/// # # [macro_use] extern crate stdarch;
/// #
/// # // De echte hoofdfunctie
/// # fn main() {
/// #     // Voer dit alleen uit als `<target feature>` wordt ondersteund
/// #     if cfg_feature_enabled! ("<target feature>"){
/// #         // Maak een `worker`-functie die alleen wordt uitgevoerd als de doelfunctie
/// #         // wordt ondersteund en zorg ervoor dat `target_feature` is ingeschakeld voor uw werknemer
/// #         // function
/// #         #[target_feature(enable = "<target feature>")]
/// #         onveilige fn worker() {
/// // Schrijf hier uw voorbeeld.Functie-specifieke intrinsieke eigenschappen zullen hier werken!Ga wild!
///
/// #         }
///
/// #         onveilige { worker(); }
/// #     }
/// # }
```

Als een deel van de bovenstaande syntaxis niet bekend voorkomt, beschrijft de [Documentation as tests]-sectie van de [Rust Book] de `rustdoc`-syntaxis redelijk goed.
Zoals altijd, voel je vrij om [join us on gitter][gitter] te bezoeken en ons te vragen of je problemen hebt ondervonden, en bedankt voor je hulp bij het verbeteren van de documentatie van `stdarch`!

# Alternatieve testinstructies

Het wordt over het algemeen aanbevolen om `ci/run.sh` te gebruiken om de tests uit te voeren.
Dit werkt echter mogelijk niet voor u, bijvoorbeeld als u Windows gebruikt.

In dat geval kunt u terugvallen op het draaien van `cargo +nightly test` en `cargo +nightly test --release -p core_arch` om de codegeneratie te testen.
Merk op dat hiervoor de nachtelijke toolchain moet worden geïnstalleerd en dat `rustc` op de hoogte moet zijn van uw target triple en zijn CPU.
In het bijzonder moet u de omgevingsvariabele `TARGET` instellen zoals u zou doen voor `ci/run.sh`.
Daarnaast moet je `RUSTCFLAGS` instellen (heb de `C` nodig) om doelfuncties aan te geven, bijv `RUSTCFLAGS="-C -target-features=+avx2"`.
Je kunt `-C -target-cpu=native` ook instellen als je "just" ontwikkelt tegen je huidige CPU.

Wees gewaarschuwd dat wanneer u deze alternatieve instructies gebruikt, [things may go less smoothly than they would with `ci/run.sh`][ci-run-good], bijv
instructies voor het genereren van instructies kunnen mislukken omdat de disassembler ze een andere naam heeft gegeven, bijv
het kan `vaesenc`-instructies genereren in plaats van `aesenc`-instructies, ondanks dat ze zich hetzelfde gedragen.
Ook voeren deze instructies minder tests uit dan normaal zou worden gedaan, dus wees niet verbaasd dat wanneer u uiteindelijk een pull-request uitvoert, sommige fouten kunnen verschijnen voor tests die hier niet worden behandeld.

[new]: https://github.com/rust-lang/stdarch/issues/new
[issues]: https://github.com/rust-lang/stdarch/issues
[help]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3A%22help+wanted%22
[impl]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3Aimpl-period
[vendor]: https://github.com/rust-lang/stdarch/issues/40
[Documentation as tests]: https://doc.rust-lang.org/book/first-edition/documentation.html#documentation-as-tests
[Rust Book]: https://doc.rust-lang.org/book/first-edition
[ci-run-good]: https://github.com/rust-lang/stdarch/issues/931#issuecomment-711412126






