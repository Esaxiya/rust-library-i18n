`core::arch` - Rust's architectuurspecifieke intrinsiek van de kernbibliotheek
=======

[![core_arch_crate_badge]][core_arch_crate_link] [![core_arch_docs_badge]][core_arch_docs_link]

De `core::arch`-module implementeert architectuurafhankelijke intrinsieke gegevens (bijv. SIMD).

# Usage 

`core::arch` is beschikbaar als onderdeel van `libcore` en wordt opnieuw geëxporteerd door `libstd`.Gebruik het liever via `core::arch` of `std::arch` dan via deze crate.
Onstabiele functies zijn vaak beschikbaar in nachtelijke Rust via de `feature(stdsimd)`.

Het gebruik van `core::arch` via deze crate vereist nachtelijke Rust, en het kan (en zal) vaak kapot gaan.De enige gevallen waarin u zou moeten overwegen om het via deze crate te gebruiken, zijn:

* als u `core::arch` zelf opnieuw moet compileren, bijvoorbeeld met bepaalde doelfuncties ingeschakeld die niet zijn ingeschakeld voor `libcore`/`libstd`.
Note: als je het opnieuw moet compileren voor een niet-standaard target, geef er dan de voorkeur aan `xargo` te gebruiken en `libcore`/`libstd` opnieuw te compileren in plaats van deze crate te gebruiken.
  
* sommige functies gebruiken die mogelijk niet beschikbaar zijn, zelfs niet achter onstabiele Rust-functies.We proberen deze tot een minimum te beperken.
Als u een aantal van deze functies moet gebruiken, open dan een probleem zodat we ze in de nachtelijke Rust kunnen blootleggen en u ze vanaf daar kunt gebruiken.

# Documentation

* [Documentation - i686][i686]
* [Documentation - x86\_64][x86_64]
* [Documentation - arm][arm]
* [Documentation - aarch64][aarch64]
* [Documentation - powerpc][powerpc]
* [Documentation - powerpc64][powerpc64]
* [How to get started][contrib]
* [How to help implement intrinsics][help-implement]

[contrib]: https://github.com/rust-lang/stdarch/blob/master/CONTRIBUTING.md
[help-implement]: https://github.com/rust-lang/stdarch/issues/40
[i686]: https://rust-lang.github.io/stdarch/i686/core_arch/
[x86_64]: https://rust-lang.github.io/stdarch/x86_64/core_arch/
[arm]: https://rust-lang.github.io/stdarch/arm/core_arch/
[aarch64]: https://rust-lang.github.io/stdarch/aarch64/core_arch/
[powerpc]: https://rust-lang.github.io/stdarch/powerpc/core_arch/
[powerpc64]: https://rust-lang.github.io/stdarch/powerpc64/core_arch/

# License

`core_arch` wordt voornamelijk gedistribueerd onder de voorwaarden van zowel de MIT-licentie als de Apache-licentie (versie 2.0), waarbij delen worden gedekt door verschillende BSD-achtige licenties.

Zie LICENSE-APACHE en LICENSE-MIT voor details.

# Contribution

Tenzij u expliciet anders aangeeft, zal elke bijdrage die opzettelijk door u is ingediend voor opname in `core_arch`, zoals gedefinieerd in de Apache-2.0-licentie, een dubbele licentie hebben zoals hierboven, zonder enige aanvullende voorwaarden of condities.


[core_arch_crate_badge]: https://img.shields.io/crates/v/core_arch.svg
[core_arch_crate_link]: https://crates.io/crates/core_arch
[core_arch_docs_badge]: https://docs.rs/core_arch/badge.svg
[core_arch_docs_link]: https://docs.rs/core_arch/












