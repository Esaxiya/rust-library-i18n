use std::env;

fn main() {
    println!("cargo:rustc-cfg=core_arch_docs");

    // Wordt gebruikt om onze `#[assert_instr]`-annotaties te vertellen dat alle simd-intrinsieke elementen beschikbaar zijn om hun codegen te testen, aangezien sommige achter een extra `-Ctarget-feature=+unimplemented-simd128` staan die op dit moment geen equivalent heeft in `#[target_feature]`.
    //
    //
    //
    println!("cargo:rerun-if-env-changed=RUSTFLAGS");
    if env::var("RUSTFLAGS")
        .unwrap_or_default()
        .contains("unimplemented-simd128")
    {
        println!("cargo:rustc-cfg=all_simd");
    }
}