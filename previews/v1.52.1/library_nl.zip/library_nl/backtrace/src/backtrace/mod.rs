use core::ffi::c_void;
use core::fmt;

/// Inspecteert de huidige call-stack en geeft alle actieve frames door aan de voorziene afsluiting om een stacktracering te berekenen.
///
/// Deze functie is het werkpaard van deze bibliotheek bij het berekenen van de stacktraces voor een programma.De gegeven sluiting `cb` levert instanties van een `Frame` op die informatie over dat oproepframe op de stapel vertegenwoordigen.
/// De sluiting is gevormd frames op een top-down manier (meest recent functies eerst genoemd).
///
/// De retourwaarde van de sluiting is een indicatie of de backtrace moet doorgaan.Een retourwaarde van `false` beëindigt de backtrace en keert onmiddellijk terug.
///
/// Zodra een `Frame` is verkregen, wilt u waarschijnlijk `backtrace::resolve` bellen om de `ip` (instructieaanwijzer) of symbooladres om te zetten in een `Symbol` waarmee de naam en/of bestandsnaam/regelnummer kan worden geleerd.
///
///
/// Merk op dat dit een relatief lage functie is en als u bijvoorbeeld een backtrace wilt vastleggen om later te inspecteren, dan is het type `Backtrace` wellicht geschikter.
///
/// # Vereiste functies
///
/// Deze functie vereist dat de `std`-functie van de `backtrace` crate is ingeschakeld, en de `std`-functie is standaard ingeschakeld.
///
/// # Panics
///
/// Deze functie streeft ernaar om nooit panic te gebruiken, maar als de `cb` panics levert, zullen sommige platforms een dubbele panic dwingen om het proces af te breken.
/// Sommige platforms gebruiken een C-bibliotheek die intern callbacks gebruikt die niet kunnen worden teruggedraaid, dus paniek door `cb` kan een procesonderbreking veroorzaken.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         // ...
///
///         true // ga verder met de backtrace
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn trace<F: FnMut(&Frame) -> bool>(cb: F) {
    let _guard = crate::lock::lock();
    unsafe { trace_unsynchronized(cb) }
}

/// Hetzelfde als `trace`, alleen onveilig omdat het niet gesynchroniseerd is.
///
/// Deze functie heeft geen synchronisatiegaranties, maar is beschikbaar wanneer de `std`-functie van deze crate niet is gecompileerd.
/// Zie de `trace`-functie voor meer documentatie en voorbeelden.
///
/// # Panics
///
/// Zie informatie over `trace` voor kanttekeningen bij paniek in `cb`.
///
pub unsafe fn trace_unsynchronized<F: FnMut(&Frame) -> bool>(mut cb: F) {
    trace_imp(&mut cb)
}

/// Een trait die één frame van een backtrace voorstelt, maakte plaats voor de `trace`-functie van deze crate.
///
/// De sluiting van de traceerfunctie levert frames op en het frame wordt virtueel verzonden omdat de onderliggende implementatie niet altijd bekend is tot aan de runtime.
///
///
///
#[derive(Clone)]
pub struct Frame {
    pub(crate) inner: FrameImp,
}

impl Frame {
    /// Retourneert de huidige instructieaanwijzer van dit frame.
    ///
    /// Dit is normaal gesproken de volgende instructie die in het frame moet worden uitgevoerd, maar niet alle implementaties vermelden dit met 100% nauwkeurigheid (maar het is over het algemeen redelijk dichtbij).
    ///
    ///
    /// Het wordt aanbevolen om deze waarde door te geven aan `backtrace::resolve` om er een symboolnaam van te maken.
    ///
    ///
    pub fn ip(&self) -> *mut c_void {
        self.inner.ip()
    }

    /// Retourneert de huidige stapelaanwijzer van dit frame.
    ///
    /// In het geval dat een backend de stapelaanwijzer voor dit frame niet kan herstellen, wordt een nulaanwijzer geretourneerd.
    ///
    pub fn sp(&self) -> *mut c_void {
        self.inner.sp()
    }

    /// Retourneert het startsymbooladres van het frame van deze functie.
    ///
    /// Hiermee wordt geprobeerd de instructiepointer terug te spoelen die door `ip` is geretourneerd naar het begin van de functie, waarbij die waarde wordt geretourneerd.
    ///
    /// In sommige gevallen zullen backends echter alleen `ip` retourneren vanuit deze functie.
    ///
    /// De geretourneerde waarde kan soms worden gebruikt als `backtrace::resolve` is mislukt op de hierboven gegeven `ip`.
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.inner.symbol_address()
    }

    /// Retourneert het basisadres van de module waartoe het frame behoort.
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.inner.module_base_address()
    }
}

impl fmt::Debug for Frame {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Frame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

cfg_if::cfg_if! {
    // Dit moet op de eerste plaats komen om ervoor te zorgen dat Miri voorrang krijgt op het hostplatform
    //
    if #[cfg(miri)] {
        pub(crate) mod miri;
        use self::miri::trace as trace_imp;
        pub(crate) use self::miri::Frame as FrameImp;
    } else if #[cfg(
        any(
            all(
                unix,
                not(target_os = "emscripten"),
                not(all(target_os = "ios", target_arch = "arm")),
            ),
            all(
                target_env = "sgx",
                target_vendor = "fortanix",
            ),
        )
    )] {
        mod libunwind;
        use self::libunwind::trace as trace_imp;
        pub(crate) use self::libunwind::Frame as FrameImp;
    } else if #[cfg(all(windows, not(target_vendor = "uwp")))] {
        mod dbghelp;
        use self::dbghelp::trace as trace_imp;
        pub(crate) use self::dbghelp::Frame as FrameImp;
        #[cfg(target_env = "msvc")] // alleen gebruikt in dbghelp symbolize
        pub(crate) use self::dbghelp::StackFrame;
    } else {
        mod noop;
        use self::noop::trace as trace_imp;
        pub(crate) use self::noop::Frame as FrameImp;
    }
}