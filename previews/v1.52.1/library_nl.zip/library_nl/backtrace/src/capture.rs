use crate::PrintFmt;
use crate::{resolve, resolve_frame, trace, BacktraceFmt, Symbol, SymbolName};
use std::ffi::c_void;
use std::fmt;
use std::path::{Path, PathBuf};
use std::prelude::v1::*;

#[cfg(feature = "serde")]
use serde::{Deserialize, Serialize};

/// Vertegenwoordiging van een eigen en zelfstandige backtrace.
///
/// Deze structuur kan worden gebruikt om een backtrace op verschillende punten in een programma vast te leggen en later om te inspecteren wat de backtrace op dat moment was.
///
///
/// `Backtrace` ondersteunt mooi afdrukken van backtraces door zijn `Debug`-implementatie.
///
/// # Vereiste functies
///
/// Deze functie vereist dat de `std`-functie van de `backtrace` crate is ingeschakeld, en de `std`-functie is standaard ingeschakeld.
///
///
#[derive(Clone)]
#[cfg_attr(feature = "serialize-rustc", derive(RustcDecodable, RustcEncodable))]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
pub struct Backtrace {
    // Frames hier worden weergegeven van boven naar beneden van de stapel
    frames: Vec<BacktraceFrame>,
    // De index die volgens ons de daadwerkelijke start is van de backtrace, waarbij frames zoals `Backtrace::new` en `backtrace::trace` worden weggelaten.
    //
    actual_start_index: usize,
}

fn _assert_send_sync() {
    fn _assert<T: Send + Sync>() {}
    _assert::<Backtrace>();
}

/// Opgenomen versie van een frame in een backtrace.
///
/// Dit type wordt geretourneerd als een lijst van `Backtrace::frames` en vertegenwoordigt één stapelframe in een vastgelegde backtrace.
///
/// # Vereiste functies
///
/// Deze functie vereist dat de `std`-functie van de `backtrace` crate is ingeschakeld, en de `std`-functie is standaard ingeschakeld.
///
///
#[derive(Clone)]
pub struct BacktraceFrame {
    frame: Frame,
    symbols: Option<Vec<BacktraceSymbol>>,
}

#[derive(Clone)]
enum Frame {
    Raw(crate::Frame),
    #[allow(dead_code)]
    Deserialized {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
    },
}

impl Frame {
    fn ip(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ref f) => f.ip(),
            Frame::Deserialized { ip, .. } => ip as *mut c_void,
        }
    }

    fn symbol_address(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ref f) => f.symbol_address(),
            Frame::Deserialized { symbol_address, .. } => symbol_address as *mut c_void,
        }
    }

    fn module_base_address(&self) -> Option<*mut c_void> {
        match *self {
            Frame::Raw(ref f) => f.module_base_address(),
            Frame::Deserialized {
                module_base_address,
                ..
            } => module_base_address.map(|addr| addr as *mut c_void),
        }
    }
}

/// Opgenomen versie van een symbool in een backtrace.
///
/// Dit type wordt als een lijst uit `BacktraceFrame::symbols` geretourneerd en vertegenwoordigt de metagegevens voor een symbool in een backtrace.
///
/// # Vereiste functies
///
/// Deze functie vereist dat de `std`-functie van de `backtrace` crate is ingeschakeld, en de `std`-functie is standaard ingeschakeld.
///
///
#[derive(Clone)]
#[cfg_attr(feature = "serialize-rustc", derive(RustcDecodable, RustcEncodable))]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
pub struct BacktraceSymbol {
    name: Option<Vec<u8>>,
    addr: Option<usize>,
    filename: Option<PathBuf>,
    lineno: Option<u32>,
    colno: Option<u32>,
}

impl Backtrace {
    /// Legt een backtrace vast op de callsite van deze functie en retourneert een eigen representatie.
    ///
    /// Deze functie is handig om een backtrace weer te geven als een object in Rust.Deze geretourneerde waarde kan via threads worden verzonden en elders worden afgedrukt, en het doel van deze waarde is om volledig op zichzelf te staan.
    ///
    /// Merk op dat het op sommige platforms extreem duur kan zijn om een volledige backtrace te krijgen en op te lossen.
    /// Als de kosten te hoog zijn voor uw toepassing, is het raadzaam om in plaats daarvan `Backtrace::new_unresolved()` te gebruiken, waardoor de stap van het oplossen van symbolen (die doorgaans het langst duurt) wordt vermeden en het mogelijk is om dat naar een latere datum uit te stellen.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use backtrace::Backtrace;
    ///
    /// let current_backtrace = Backtrace::new();
    /// ```
    ///
    /// # Vereiste functies
    ///
    /// Deze functie vereist dat de `std`-functie van de `backtrace` crate is ingeschakeld, en de `std`-functie is standaard ingeschakeld.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline(never)] // wil er zeker van zijn dat hier een frame is om te verwijderen
    pub fn new() -> Backtrace {
        let mut bt = Self::create(Self::new as usize);
        bt.resolve();
        bt
    }

    /// Vergelijkbaar met `new` behalve dat dit geen symbolen oplost, dit legt de backtrace eenvoudig vast als een lijst met adressen.
    ///
    /// Op een later tijdstip kan de `resolve`-functie worden aangeroepen om de symbolen van deze backtrace om te zetten in leesbare namen.
    /// Deze functie bestaat omdat het oplossingsproces soms een aanzienlijke hoeveelheid tijd in beslag kan nemen, terwijl een backtrace maar zelden wordt afgedrukt.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use backtrace::Backtrace;
    ///
    /// let mut current_backtrace = Backtrace::new_unresolved();
    /// println!("{:?}", current_backtrace); // geen symboolnamen
    /// current_backtrace.resolve();
    /// println!("{:?}", current_backtrace); // symboolnamen nu aanwezig
    /// ```
    ///
    /// # Vereiste functies
    ///
    /// Deze functie vereist dat de `std`-functie van de `backtrace` crate is ingeschakeld, en de `std`-functie is standaard ingeschakeld.
    ///
    ///
    ///
    #[inline(never)] // wil er zeker van zijn dat hier een frame is om te verwijderen
    pub fn new_unresolved() -> Backtrace {
        Self::create(Self::new_unresolved as usize)
    }

    fn create(ip: usize) -> Backtrace {
        let mut frames = Vec::new();
        let mut actual_start_index = None;
        trace(|frame| {
            frames.push(BacktraceFrame {
                frame: Frame::Raw(frame.clone()),
                symbols: None,
            });

            if frame.symbol_address() as usize == ip && actual_start_index.is_none() {
                actual_start_index = Some(frames.len());
            }
            true
        });

        Backtrace {
            frames,
            actual_start_index: actual_start_index.unwrap_or(0),
        }
    }

    /// Retourneert de frames vanaf het moment dat deze backtrace werd vastgelegd.
    ///
    /// De eerste invoer van deze slice is waarschijnlijk de functie `Backtrace::new`, en het laatste frame is waarschijnlijk iets over hoe deze thread of de hoofdfunctie begon.
    ///
    ///
    /// # Vereiste functies
    ///
    /// Deze functie vereist dat de `std`-functie van de `backtrace` crate is ingeschakeld, en de `std`-functie is standaard ingeschakeld.
    ///
    ///
    pub fn frames(&self) -> &[BacktraceFrame] {
        &self.frames[self.actual_start_index..]
    }

    /// Als deze backtrace is gemaakt vanuit `new_unresolved`, dan zal deze functie alle adressen in de backtrace omzetten naar hun symbolische namen.
    ///
    ///
    /// Als deze backtrace eerder is opgelost of is gemaakt via `new`, doet deze functie niets.
    ///
    /// # Vereiste functies
    ///
    /// Deze functie vereist dat de `std`-functie van de `backtrace` crate is ingeschakeld, en de `std`-functie is standaard ingeschakeld.
    ///
    ///
    pub fn resolve(&mut self) {
        for frame in self.frames.iter_mut().filter(|f| f.symbols.is_none()) {
            let mut symbols = Vec::new();
            {
                let sym = |symbol: &Symbol| {
                    symbols.push(BacktraceSymbol {
                        name: symbol.name().map(|m| m.as_bytes().to_vec()),
                        addr: symbol.addr().map(|a| a as usize),
                        filename: symbol.filename().map(|m| m.to_owned()),
                        lineno: symbol.lineno(),
                        colno: symbol.colno(),
                    });
                };
                match frame.frame {
                    Frame::Raw(ref f) => resolve_frame(f, sym),
                    Frame::Deserialized { ip, .. } => {
                        resolve(ip as *mut c_void, sym);
                    }
                }
            }
            frame.symbols = Some(symbols);
        }
    }
}

impl From<Vec<BacktraceFrame>> for Backtrace {
    fn from(frames: Vec<BacktraceFrame>) -> Self {
        Backtrace {
            frames,
            actual_start_index: 0,
        }
    }
}

impl Into<Vec<BacktraceFrame>> for Backtrace {
    fn into(self) -> Vec<BacktraceFrame> {
        self.frames
    }
}

impl BacktraceFrame {
    /// Hetzelfde als `Frame::ip`
    ///
    /// # Vereiste functies
    ///
    /// Deze functie vereist dat de `std`-functie van de `backtrace` crate is ingeschakeld, en de `std`-functie is standaard ingeschakeld.
    ///
    pub fn ip(&self) -> *mut c_void {
        self.frame.ip() as *mut c_void
    }

    /// Hetzelfde als `Frame::symbol_address`
    ///
    /// # Vereiste functies
    ///
    /// Deze functie vereist dat de `std`-functie van de `backtrace` crate is ingeschakeld, en de `std`-functie is standaard ingeschakeld.
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.frame.symbol_address() as *mut c_void
    }

    /// Hetzelfde als `Frame::module_base_address`
    ///
    /// # Vereiste functies
    ///
    /// Deze functie vereist dat de `std`-functie van de `backtrace` crate is ingeschakeld, en de `std`-functie is standaard ingeschakeld.
    ///
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.frame
            .module_base_address()
            .map(|addr| addr as *mut c_void)
    }

    /// Retourneert de lijst met symbolen waarmee dit frame overeenkomt.
    ///
    /// Normaal gesproken is er slechts één symbool per frame, maar soms worden er meerdere symbolen geretourneerd als een aantal functies in één frame zijn geplaatst.
    /// Het eerste weergegeven symbool is de "innermost function", terwijl het laatste symbool het buitenste is (laatste beller).
    ///
    /// Merk op dat als dit frame afkomstig is van een onopgeloste backtrace, dit een lege lijst zal retourneren.
    ///
    /// # Vereiste functies
    ///
    /// Deze functie vereist dat de `std`-functie van de `backtrace` crate is ingeschakeld, en de `std`-functie is standaard ingeschakeld.
    ///
    ///
    ///
    ///
    pub fn symbols(&self) -> &[BacktraceSymbol] {
        self.symbols.as_ref().map(|s| &s[..]).unwrap_or(&[])
    }
}

impl BacktraceSymbol {
    /// Hetzelfde als `Symbol::name`
    ///
    /// # Vereiste functies
    ///
    /// Deze functie vereist dat de `std`-functie van de `backtrace` crate is ingeschakeld, en de `std`-functie is standaard ingeschakeld.
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.name.as_ref().map(|s| SymbolName::new(s))
    }

    /// Hetzelfde als `Symbol::addr`
    ///
    /// # Vereiste functies
    ///
    /// Deze functie vereist dat de `std`-functie van de `backtrace` crate is ingeschakeld, en de `std`-functie is standaard ingeschakeld.
    ///
    pub fn addr(&self) -> Option<*mut c_void> {
        self.addr.map(|s| s as *mut c_void)
    }

    /// Hetzelfde als `Symbol::filename`
    ///
    /// # Vereiste functies
    ///
    /// Deze functie vereist dat de `std`-functie van de `backtrace` crate is ingeschakeld, en de `std`-functie is standaard ingeschakeld.
    ///
    pub fn filename(&self) -> Option<&Path> {
        self.filename.as_ref().map(|p| &**p)
    }

    /// Hetzelfde als `Symbol::lineno`
    ///
    /// # Vereiste functies
    ///
    /// Deze functie vereist dat de `std`-functie van de `backtrace` crate is ingeschakeld, en de `std`-functie is standaard ingeschakeld.
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.lineno
    }

    /// Hetzelfde als `Symbol::colno`
    ///
    /// # Vereiste functies
    ///
    /// Deze functie vereist dat de `std`-functie van de `backtrace` crate is ingeschakeld, en de `std`-functie is standaard ingeschakeld.
    ///
    pub fn colno(&self) -> Option<u32> {
        self.colno
    }
}

impl fmt::Debug for Backtrace {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        let full = fmt.alternate();
        let (frames, style) = if full {
            (&self.frames[..], PrintFmt::Full)
        } else {
            (&self.frames[self.actual_start_index..], PrintFmt::Short)
        };

        // Bij het afdrukken van paden proberen we de cwd te strippen als deze bestaat, anders printen we het pad gewoon zoals het is.
        // Merk op dat we dit ook alleen doen voor het korte formaat, want als het vol is, willen we vermoedelijk alles afdrukken.
        //
        //
        let cwd = std::env::current_dir();
        let mut print_path =
            move |fmt: &mut fmt::Formatter<'_>, path: crate::BytesOrWideString<'_>| {
                let path = path.into_path_buf();
                if !full {
                    if let Ok(cwd) = &cwd {
                        if let Ok(suffix) = path.strip_prefix(cwd) {
                            return fmt::Display::fmt(&suffix.display(), fmt);
                        }
                    }
                }
                fmt::Display::fmt(&path.display(), fmt)
            };

        let mut f = BacktraceFmt::new(fmt, style, &mut print_path);
        f.add_context()?;
        for frame in frames {
            f.frame().backtrace_frame(frame)?;
        }
        f.finish()?;
        Ok(())
    }
}

impl Default for Backtrace {
    fn default() -> Backtrace {
        Backtrace::new()
    }
}

impl fmt::Debug for BacktraceFrame {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_struct("BacktraceFrame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

impl fmt::Debug for BacktraceSymbol {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_struct("BacktraceSymbol")
            .field("name", &self.name())
            .field("addr", &self.addr())
            .field("filename", &self.filename())
            .field("lineno", &self.lineno())
            .field("colno", &self.colno())
            .finish()
    }
}

#[cfg(feature = "serialize-rustc")]
mod rustc_serialize_impls {
    use super::*;
    use rustc_serialize::{Decodable, Decoder, Encodable, Encoder};

    #[derive(RustcEncodable, RustcDecodable)]
    struct SerializedFrame {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
        symbols: Option<Vec<BacktraceSymbol>>,
    }

    impl Decodable for BacktraceFrame {
        fn decode<D>(d: &mut D) -> Result<Self, D::Error>
        where
            D: Decoder,
        {
            let frame: SerializedFrame = SerializedFrame::decode(d)?;
            Ok(BacktraceFrame {
                frame: Frame::Deserialized {
                    ip: frame.ip,
                    symbol_address: frame.symbol_address,
                    module_base_address: frame.module_base_address,
                },
                symbols: frame.symbols,
            })
        }
    }

    impl Encodable for BacktraceFrame {
        fn encode<E>(&self, e: &mut E) -> Result<(), E::Error>
        where
            E: Encoder,
        {
            let BacktraceFrame { frame, symbols } = self;
            SerializedFrame {
                ip: frame.ip() as usize,
                symbol_address: frame.symbol_address() as usize,
                module_base_address: frame.module_base_address().map(|addr| addr as usize),
                symbols: symbols.clone(),
            }
            .encode(e)
        }
    }
}

#[cfg(feature = "serde")]
mod serde_impls {
    use super::*;
    use serde::de::Deserializer;
    use serde::ser::Serializer;
    use serde::{Deserialize, Serialize};

    #[derive(Serialize, Deserialize)]
    struct SerializedFrame {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
        symbols: Option<Vec<BacktraceSymbol>>,
    }

    impl Serialize for BacktraceFrame {
        fn serialize<S>(&self, s: S) -> Result<S::Ok, S::Error>
        where
            S: Serializer,
        {
            let BacktraceFrame { frame, symbols } = self;
            SerializedFrame {
                ip: frame.ip() as usize,
                symbol_address: frame.symbol_address() as usize,
                module_base_address: frame.module_base_address().map(|addr| addr as usize),
                symbols: symbols.clone(),
            }
            .serialize(s)
        }
    }

    impl<'a> Deserialize<'a> for BacktraceFrame {
        fn deserialize<D>(d: D) -> Result<Self, D::Error>
        where
            D: Deserializer<'a>,
        {
            let frame: SerializedFrame = SerializedFrame::deserialize(d)?;
            Ok(BacktraceFrame {
                frame: Frame::Deserialized {
                    ip: frame.ip,
                    symbol_address: frame.symbol_address,
                    module_base_address: frame.module_base_address,
                },
                symbols: frame.symbols,
            })
        }
    }
}