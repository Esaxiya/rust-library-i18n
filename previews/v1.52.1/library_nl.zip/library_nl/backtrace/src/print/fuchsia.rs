use core::fmt::{self, Write};
use core::mem::{size_of, transmute};
use core::slice::from_raw_parts;
use libc::c_char;

extern "C" {
    // dl_iterate_phdr accepteert een callback die een dl_phdr_info pointer ontvangt voor elke DSO die aan het proces is gekoppeld.
    // dl_iterate_phdr zorgt er ook voor dat de dynamische linker vergrendeld is van begin tot einde van de iteratie.
    // Als de callback een niet-nulwaarde retourneert, wordt de iteratie voortijdig beëindigd.
    // 'data' wordt bij elke aanroep doorgegeven als het derde argument voor de callback.
    // 'size' geeft de grootte van de dl_phdr_info.
    //
    #[allow(improper_ctypes)]
    fn dl_iterate_phdr(
        f: extern "C" fn(info: &dl_phdr_info, size: usize, data: &mut DsoPrinter<'_, '_>) -> i32,
        data: &mut DsoPrinter<'_, '_>,
    ) -> i32;
}

// We moeten de build-ID en enkele basisgegevens van de programmakop ontleden, wat betekent dat we ook wat spullen uit de ELF-specificatie nodig hebben.
//

const PT_LOAD: u32 = 1;
const PT_NOTE: u32 = 4;

// Nu moeten we bit voor bit de structuur repliceren van het type dl_phdr_info dat wordt gebruikt door de huidige dynamische linker van fuchsia.
// Chromium heeft ook deze ABI-grens en crashpad.
// Uiteindelijk zouden we deze gevallen willen verplaatsen om elf-zoeken te gebruiken, maar we zouden dat in de SDK moeten opgeven en dat is nog niet gedaan.
//
// Dus wij (en zij) zitten vast met deze methode die een nauwe koppeling met de fuchsia libc met zich meebrengt.
//

#[allow(non_camel_case_types)]
#[repr(C)]
struct dl_phdr_info {
    addr: *const u8,
    name: *const c_char,
    phdr: *const Elf_Phdr,
    phnum: u16,
    adds: u64,
    subs: u64,
    tls_modid: usize,
    tls_data: *const u8,
}

impl dl_phdr_info {
    fn program_headers(&self) -> PhdrIter<'_> {
        PhdrIter {
            phdrs: self.phdr_slice(),
            base: self.addr,
        }
    }
    // We kunnen niet weten of e_phoff en e_phnum geldig zijn.
    // libc zou dit echter voor ons moeten verzekeren, dus het is veilig om hier een plak te vormen.
    fn phdr_slice(&self) -> &[Elf_Phdr] {
        unsafe { from_raw_parts(self.phdr, self.phnum as usize) }
    }
}

struct PhdrIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: *const u8,
}

impl<'a> Iterator for PhdrIter<'a> {
    type Item = Phdr<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().map(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            Phdr {
                phdr,
                base: self.base,
            }
        })
    }
}

// Elf_Phdr vertegenwoordigt een 64-bits ELF-programmakop in de endianness van de doelarchitectuur.
//
#[allow(non_camel_case_types)]
#[derive(Clone, Debug)]
#[repr(C)]
struct Elf_Phdr {
    p_type: u32,
    p_flags: u32,
    p_offset: u64,
    p_vaddr: u64,
    p_paddr: u64,
    p_filesz: u64,
    p_memsz: u64,
    p_align: u64,
}

// Phdr vertegenwoordigt een geldige ELF-programmakop en de inhoud ervan.
struct Phdr<'a> {
    phdr: &'a Elf_Phdr,
    base: *const u8,
}

impl<'a> Phdr<'a> {
    // We kunnen niet controleren of p_addr of p_memsz geldig zijn.
    // Fuchsia's libc ontleedt eerst de noten, dus omdat ze hier zijn, moeten deze kopteksten geldig zijn.
    //
    // NoteIter vereist niet dat de onderliggende gegevens geldig zijn, maar wel dat de grenzen geldig zijn.
    // We vertrouwen erop dat libc ervoor heeft gezorgd dat dit hier voor ons het geval is.
    fn notes(&self) -> NoteIter<'a> {
        unsafe {
            NoteIter::new(
                self.base.add(self.phdr.p_offset as usize),
                self.phdr.p_memsz as usize,
            )
        }
    }
}

// Het notitietype voor build-ID's.
const NT_GNU_BUILD_ID: u32 = 3;

// Elf_Nhdr vertegenwoordigt een ELF-nootkop in de endianness van het doel.
#[allow(non_camel_case_types)]
#[repr(C)]
struct Elf_Nhdr {
    n_namesz: u32,
    n_descsz: u32,
    n_type: u32,
}

// Note vertegenwoordigt een ELF-notitie (koptekst + inhoud).
// De naam blijft staan als een u8-slice omdat deze niet altijd null-beëindigd is en rust het gemakkelijk genoeg maakt om te controleren of de bytes op beide manieren overeenkomen.
//
struct Note<'a> {
    name: &'a [u8],
    desc: &'a [u8],
    tipe: u32,
}

// Met NoteIter kunt u veilig een notitiesegment herhalen.
// Het wordt beëindigd zodra er een fout optreedt of er geen notities meer zijn.
// Als u ongeldige gegevens herhaalt, werkt het alsof er geen notities zijn gevonden.
struct NoteIter<'a> {
    base: &'a [u8],
    error: bool,
}

impl<'a> NoteIter<'a> {
    // Het is een invariant van de functie dat de aanwijzer en de opgegeven grootte een geldig bereik van bytes aanduiden dat allemaal kan worden gelezen.
    // De inhoud van deze bytes kan van alles zijn, maar het bereik moet geldig zijn om dit veilig te laten zijn.
    //
    unsafe fn new(base: *const u8, size: usize) -> Self {
        NoteIter {
            base: from_raw_parts(base, size),
            error: false,
        }
    }
}

// align_to lijnt 'x' uit met 'to'-byte alignment, ervan uitgaande dat 'to' een macht van 2 is.
// Dit volgt een standaardpatroon in C/C ++ ELF-parseercode waarbij (x + to, 1)&-to wordt gebruikt.
// Rust laat je het gebruik niet ontkennen, dus ik gebruik
// 2-complement-conversie om dat opnieuw te creëren.
fn align_to(x: usize, to: usize) -> usize {
    (x + to - 1) & (!to + 1)
}

// take_bytes_align4 verbruikt aantal bytes van de slice (indien aanwezig) en zorgt er bovendien voor dat de laatste slice correct is uitgelijnd.
// Als het aantal aangevraagde bytes te groot is of als de slice achteraf niet opnieuw kan worden uitgelijnd omdat er niet genoeg resterende bytes zijn, wordt None geretourneerd en wordt de slice niet gewijzigd.
//
//
//
fn take_bytes_align4<'a>(num: usize, bytes: &mut &'a [u8]) -> Option<&'a [u8]> {
    if bytes.len() < align_to(num, 4) {
        return None;
    }
    let (out, bytes_new) = bytes.split_at(num);
    *bytes = &bytes_new[align_to(num, 4) - num..];
    Some(out)
}

// Deze functie heeft geen echte invarianten die de beller moet handhaven, behalve misschien dat 'bytes' moet worden uitgelijnd voor prestaties (en op sommige architecturen juistheid).
// De waarden in de Elf_Nhdr-velden zijn misschien onzin, maar deze functie zorgt ervoor dat dit niet gebeurt.
//
//
fn take_nhdr<'a>(bytes: &mut &'a [u8]) -> Option<&'a Elf_Nhdr> {
    if size_of::<Elf_Nhdr>() > bytes.len() {
        return None;
    }
    // Dit is veilig zolang er voldoende ruimte is en we hebben dat zojuist bevestigd in de if-verklaring hierboven, dus dit zou niet onveilig moeten zijn.
    //
    let out = unsafe { transmute::<*const u8, &'a Elf_Nhdr>(bytes.as_ptr()) };
    // Merk op dat sice_of: :<Elf_Nhdr>() is altijd uitgelijnd met 4 bytes.
    *bytes = &bytes[size_of::<Elf_Nhdr>()..];
    Some(out)
}

impl<'a> Iterator for NoteIter<'a> {
    type Item = Note<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        // Kijk of we het einde hebben bereikt.
        if self.base.len() == 0 || self.error {
            return None;
        }
        // We transmuteren een nhdr, maar we overwegen zorgvuldig de resulterende struct.
        // We vertrouwen de namesz of descsz niet en we nemen geen onveilige beslissingen op basis van het type.
        //
        // Dus zelfs als we het volledige afval eruit halen, moeten we nog steeds veilig zijn.
        let nhdr = take_nhdr(&mut self.base)?;
        let name = take_bytes_align4(nhdr.n_namesz as usize, &mut self.base)?;
        let desc = take_bytes_align4(nhdr.n_descsz as usize, &mut self.base)?;
        Some(Note {
            name: name,
            desc: desc,
            tipe: nhdr.n_type,
        })
    }
}

struct Perm(u32);

/// Geeft aan dat een segment uitvoerbaar is.
const PERM_X: u32 = 0b00000001;
/// Geeft aan dat een segment beschrijfbaar is.
const PERM_W: u32 = 0b00000010;
/// Geeft aan dat een segment leesbaar is.
const PERM_R: u32 = 0b00000100;

impl core::fmt::Display for Perm {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let v = self.0;
        if v & PERM_R != 0 {
            f.write_char('r')?
        }
        if v & PERM_W != 0 {
            f.write_char('w')?
        }
        if v & PERM_X != 0 {
            f.write_char('x')?
        }
        Ok(())
    }
}

/// Vertegenwoordigt een ELF-segment tijdens runtime.
struct Segment {
    /// Geeft het virtuele runtime-adres van de inhoud van dit segment.
    addr: usize,
    /// Geeft de geheugengrootte van de inhoud van dit segment.
    size: usize,
    /// Geeft het module virtuele adres van dit segment met het ELF-bestand.
    mod_rel_addr: usize,
    /// Geeft de rechten die in het ELF-bestand zijn gevonden.
    /// Deze machtigingen zijn echter niet noodzakelijk de machtigingen die aanwezig zijn tijdens runtime.
    flags: Perm,
}

/// Hiermee kunt u segmenten van een DSO herhalen.
struct SegmentIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: usize,
}

impl Iterator for SegmentIter<'_> {
    type Item = Segment;

    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().and_then(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            if phdr.p_type != PT_LOAD {
                self.next()
            } else {
                Some(Segment {
                    addr: phdr.p_vaddr as usize + self.base,
                    size: phdr.p_memsz as usize,
                    mod_rel_addr: phdr.p_vaddr as usize,
                    flags: Perm(phdr.p_flags),
                })
            }
        })
    }
}

/// Vertegenwoordigt een ELF DSO (Dynamic Shared Object).
/// Dit type verwijst naar de gegevens die zijn opgeslagen in de eigenlijke DSO in plaats van een eigen kopie te maken.
struct Dso<'a> {
    /// De dynamische linker geeft ons altijd een naam, zelfs als de naam leeg is.
    /// In het geval van het hoofduitvoerbare bestand is deze naam leeg.
    /// In het geval van een gedeeld object zal het de soname zijn (zie DT_SONAME).
    name: &'a str,
    /// Op Fuchsia hebben vrijwel alle binaire bestanden build-ID's, maar dit is geen strikte vereiste.
    /// Er is geen manier om DSO-informatie achteraf te matchen met een echt ELF-bestand als er geen build_id is, dus we eisen dat elke DSO er hier een heeft.
    ///
    /// DSO's zonder build_id worden genegeerd.
    build_id: &'a [u8],

    base: usize,
    phdrs: &'a [Elf_Phdr],
}

impl Dso<'_> {
    /// Retourneert een iterator over segmenten in deze DSO.
    fn segments(&self) -> SegmentIter<'_> {
        SegmentIter {
            phdrs: self.phdrs.as_ref(),
            base: self.base,
        }
    }
}

struct HexSlice<'a> {
    bytes: &'a [u8],
}

impl fmt::Display for HexSlice<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        for byte in self.bytes {
            write!(f, "{:02x}", byte)?;
        }
        Ok(())
    }
}

fn get_build_id<'a>(info: &'a dl_phdr_info) -> Option<&'a [u8]> {
    for phdr in info.program_headers() {
        if phdr.phdr.p_type == PT_NOTE {
            for note in phdr.notes() {
                if note.tipe == NT_GNU_BUILD_ID && (note.name == b"GNU\0" || note.name == b"GNU") {
                    return Some(note.desc);
                }
            }
        }
    }
    None
}

/// Deze fouten coderen voor problemen die optreden bij het parseren van informatie over elke DSO.
///
enum Error {
    /// NameError betekent dat er een fout is opgetreden tijdens het converteren van een C-stijl string naar een rust string.
    ///
    NameError(core::str::Utf8Error),
    /// BuildIDError betekent dat we geen build-ID hebben gevonden.
    /// Dit kan zijn omdat de DSO geen build-ID had of omdat het segment met de build-ID een onjuiste indeling had.
    ///
    BuildIDError,
}

/// Roept 'dso' of 'error' aan voor elke DSO die door de dynamische linker aan het proces is gekoppeld.
///
///
/// # Arguments
///
/// * `visitor` - Een DsoPrinter die een van de eetmethoden heeft die voor elke DSO worden genoemd.
fn for_each_dso(mut visitor: &mut DsoPrinter<'_, '_>) {
    extern "C" fn callback(
        info: &dl_phdr_info,
        _size: usize,
        visitor: &mut DsoPrinter<'_, '_>,
    ) -> i32 {
        // dl_iterate_phdr zorgt ervoor dat info.name naar een geldige locatie verwijst.
        //
        let name_len = unsafe { libc::strlen(info.name) };
        let name_slice: &[u8] =
            unsafe { core::slice::from_raw_parts(info.name as *const u8, name_len) };
        let name = match core::str::from_utf8(name_slice) {
            Ok(name) => name,
            Err(err) => {
                return visitor.error(Error::NameError(err)) as i32;
            }
        };
        let build_id = match get_build_id(info) {
            Some(build_id) => build_id,
            None => {
                return visitor.error(Error::BuildIDError) as i32;
            }
        };
        visitor.dso(Dso {
            name: name,
            build_id: build_id,
            phdrs: info.phdr_slice(),
            base: info.addr as usize,
        }) as i32
    }
    unsafe { dl_iterate_phdr(callback, &mut visitor) };
}

struct DsoPrinter<'a, 'b> {
    writer: &'a mut core::fmt::Formatter<'b>,
    module_count: usize,
    error: core::fmt::Result,
}

impl DsoPrinter<'_, '_> {
    fn dso(&mut self, dso: Dso<'_>) -> bool {
        let mut write = || {
            write!(
                self.writer,
                "{{{{{{module:{:#x}:{}:elf:{}}}}}}}\n",
                self.module_count,
                dso.name,
                HexSlice {
                    bytes: dso.build_id.as_ref()
                }
            )?;
            for seg in dso.segments() {
                write!(
                    self.writer,
                    "{{{{{{mmap:{:#x}:{:#x}:load:{:#x}:{}:{:#x}}}}}}}\n",
                    seg.addr, seg.size, self.module_count, seg.flags, seg.mod_rel_addr
                )?;
            }
            self.module_count += 1;
            Ok(())
        };
        match write() {
            Ok(()) => false,
            Err(err) => {
                self.error = Err(err);
                true
            }
        }
    }
    fn error(&mut self, _error: Error) -> bool {
        false
    }
}

/// Deze functie drukt de Fuchsia-symboliseringsmarkering af voor alle informatie in een DSO.
pub fn print_dso_context(out: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
    out.write_str("{{{reset}}}\n")?;
    let mut visitor = DsoPrinter {
        writer: out,
        module_count: 0,
        error: Ok(()),
    };
    for_each_dso(&mut visitor);
    visitor.error
}