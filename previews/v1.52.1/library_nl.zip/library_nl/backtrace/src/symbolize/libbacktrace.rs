//! Symbolische strategie met behulp van de DWARF-parseercode in libbacktrace.
//!
//! De libbacktrace C-bibliotheek, meestal gedistribueerd met gcc, ondersteunt niet alleen het genereren van een backtrace (die we niet echt gebruiken) maar symboliseert ook de backtrace en het afhandelen van dwergfoutopsporingsinformatie over zaken als inline frames en dergelijke.
//!
//!
//! Dit is relatief gecompliceerd vanwege veel verschillende problemen hier, maar het basisidee is:
//!
//! * Eerst bellen we `backtrace_syminfo`.Dit haalt symboolinformatie uit de dynamische symbolentabel als we kunnen.
//! * Vervolgens noemen we `backtrace_pcinfo`.Dit zal debuginfo-tabellen ontleden als ze beschikbaar zijn en ons in staat stellen om informatie over inline-frames, bestandsnamen, regelnummers, enz. Te herstellen.
//!
//! Er zijn veel bedrog om de dwergtafels in libbacktrace te krijgen, maar hopelijk is dit niet het einde van de wereld en is het duidelijk genoeg als je hieronder leest.
//!
//! Dit is de standaardsymbolatiestrategie voor niet-MSVC-en niet-OSX-platforms.In libstd is dit echter de standaardstrategie voor OSX.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(bad_style)]

extern crate backtrace_sys as bt;

use core::{marker, ptr, slice};
use libc::{self, c_char, c_int, c_void, uintptr_t};

use crate::symbolize::{ResolveWhat, SymbolName};
use crate::types::BytesOrWideString;

pub enum Symbol<'a> {
    Syminfo {
        pc: uintptr_t,
        symname: *const c_char,
        _marker: marker::PhantomData<&'a ()>,
    },
    Pcinfo {
        pc: uintptr_t,
        filename: *const c_char,
        lineno: c_int,
        function: *const c_char,
        symname: *const c_char,
    },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        let symbol = |ptr: *const c_char| unsafe {
            if ptr.is_null() {
                None
            } else {
                let len = libc::strlen(ptr);
                Some(SymbolName::new(slice::from_raw_parts(
                    ptr as *const u8,
                    len,
                )))
            }
        };
        match *self {
            Symbol::Syminfo { symname, .. } => symbol(symname),
            Symbol::Pcinfo {
                function, symname, ..
            } => {
                // Geef indien mogelijk de voorkeur aan de `function`-naam die afkomstig is van debuginfo en die doorgaans nauwkeuriger kan zijn voor bijvoorbeeld inline-frames.
                // Als dat niet aanwezig is, moet u terugvallen op de naam van de symbooltabel die is opgegeven in `symname`.
                //
                // Merk op dat `function` soms wat minder nauwkeurig kan aanvoelen, bijvoorbeeld als `try<i32,closure>` wordt vermeld in plaats van `std::panicking::try::do_call`.
                //
                // Het is niet echt duidelijk waarom, maar over het algemeen lijkt de naam `function` nauwkeuriger.
                //
                //
                //
                if let Some(sym) = symbol(function) {
                    return Some(sym);
                }
                symbol(symname)
            }
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        let pc = match *self {
            Symbol::Syminfo { pc, .. } => pc,
            Symbol::Pcinfo { pc, .. } => pc,
        };
        if pc == 0 {
            None
        } else {
            Some(pc as *mut _)
        }
    }

    fn filename_bytes(&self) -> Option<&[u8]> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { filename, .. } => {
                let ptr = filename as *const u8;
                if ptr.is_null() {
                    return None;
                }
                unsafe {
                    let len = libc::strlen(filename);
                    Some(slice::from_raw_parts(ptr, len))
                }
            }
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.filename_bytes().map(BytesOrWideString::Bytes)
    }

    #[cfg(feature = "std")]
    pub fn filename(&self) -> Option<&::std::path::Path> {
        use std::path::Path;

        #[cfg(unix)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::ffi::OsStr;
            use std::os::unix::prelude::*;
            Some(Path::new(OsStr::from_bytes(bytes)))
        }

        #[cfg(windows)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::str;
            str::from_utf8(bytes).ok().map(Path::new)
        }

        self.filename_bytes().and_then(bytes2path)
    }

    pub fn lineno(&self) -> Option<u32> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { lineno, .. } => Some(lineno as u32),
        }
    }

    pub fn colno(&self) -> Option<u32> {
        None
    }
}

extern "C" fn error_cb(_data: *mut c_void, _msg: *const c_char, _errnum: c_int) {
    // doe nu niets
}

/// Type van de `data`-aanwijzer doorgegeven aan `syminfo_cb`
struct SyminfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    pc: usize,
}

extern "C" fn syminfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    symname: *const c_char,
    _symval: uintptr_t,
    _symsize: uintptr_t,
) {
    let mut bomb = crate::Bomb { enabled: true };

    // Zodra deze callback wordt aangeroepen vanuit `backtrace_syminfo`, gaan we verder met het aanroepen van `backtrace_pcinfo` wanneer we beginnen met oplossen.
    // De `backtrace_pcinfo`-functie raadpleegt debug-informatie en probeert dingen te doen zoals het herstellen van file/line-informatie en inline frames.
    // Merk echter op dat `backtrace_pcinfo` kan mislukken of niet veel kan doen als er geen foutopsporingsinformatie is, dus als dat gebeurt, zullen we de callback zeker aanroepen met ten minste één symbool van de `syminfo_cb`.
    //
    //
    //
    //
    unsafe {
        let syminfo_state = &mut *(data as *mut SyminfoState<'_>);
        let mut pcinfo_state = PcinfoState {
            symname,
            called: false,
            cb: syminfo_state.cb,
        };
        bt::backtrace_pcinfo(
            init_state(),
            syminfo_state.pc as uintptr_t,
            pcinfo_cb,
            error_cb,
            &mut pcinfo_state as *mut _ as *mut _,
        );
        if !pcinfo_state.called {
            (pcinfo_state.cb)(&super::Symbol {
                inner: Symbol::Syminfo {
                    pc: pc,
                    symname: symname,
                    _marker: marker::PhantomData,
                },
            });
        }
    }

    bomb.enabled = false;
}

/// Type van de `data`-aanwijzer doorgegeven aan `pcinfo_cb`
struct PcinfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    symname: *const c_char,
    called: bool,
}

extern "C" fn pcinfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    filename: *const c_char,
    lineno: c_int,
    function: *const c_char,
) -> c_int {
    let mut bomb = crate::Bomb { enabled: true };

    unsafe {
        let state = &mut *(data as *mut PcinfoState<'_>);
        state.called = true;
        (state.cb)(&super::Symbol {
            inner: Symbol::Pcinfo {
                pc: pc,
                filename: filename,
                lineno: lineno,
                symname: state.symname,
                function,
            },
        });
    }

    bomb.enabled = false;
    return 0;
}

// De libbacktrace API ondersteunt het aanmaken van een staat, maar het ondersteunt niet het vernietigen van een staat.
// Persoonlijk vat ik dit op als de bedoeling dat het de bedoeling is dat een staat wordt gecreëerd en dan voor altijd leeft.
//
// Ik zou graag een at_exit()-handler registreren die deze toestand opschoont, maar libbacktrace biedt geen manier om dit te doen.
//
// Met deze beperkingen heeft deze functie een statisch cachestatus die de eerste keer dat dit wordt aangevraagd, wordt berekend.
//
// Onthoud dat backtracing allemaal serieel gebeurt (één globaal slot).
//
// Merk op dat het ontbreken van synchronisatie hier te wijten is aan de vereiste dat `resolve` extern wordt gesynchroniseerd.
//
//
//
unsafe fn init_state() -> *mut bt::backtrace_state {
    static mut STATE: *mut bt::backtrace_state = 0 as *mut _;

    if !STATE.is_null() {
        return STATE;
    }

    STATE = bt::backtrace_create_state(
        load_filename(),
        // Gebruik geen threadveilige mogelijkheden van libbacktrace, aangezien we het altijd op een gesynchroniseerde manier noemen.
        //
        0,
        error_cb,
        ptr::null_mut(), // geen extra gegevens
    );

    return STATE;

    // Merk op dat om libbacktrace überhaupt te laten werken, het de DWARF-foutopsporingsinformatie voor het huidige uitvoerbare bestand moet vinden.Het doet dat doorgaans via een aantal mechanismen, waaronder, maar niet beperkt tot:
    //
    // * /proc/self/exe op ondersteunde platforms
    // * De bestandsnaam werd expliciet doorgegeven bij het aanmaken van state
    //
    // De libbacktrace-bibliotheek is een grote prop C-code.Dit betekent natuurlijk dat het beveiligingsproblemen heeft met het geheugen, vooral bij het verwerken van misvormde foutopsporingsinfo.
    // Libstd is historisch gezien veel hiervan tegengekomen.
    //
    // Als /proc/self/exe wordt gebruikt, kunnen we deze meestal negeren, omdat we aannemen dat libbacktrace "mostly correct" is en anders geen rare dingen doet met "attempted to be correct" dwerg-foutopsporingsinformatie.
    //
    //
    // Als we echter een bestandsnaam doorgeven, is het op sommige platforms (zoals BSD's) mogelijk dat een kwaadwillende actor ervoor kan zorgen dat een willekeurig bestand op die locatie wordt geplaatst.
    // Dit betekent dat als we libbacktrace over een bestandsnaam vertellen, het mogelijk een willekeurig bestand gebruikt, dat mogelijk segfaults veroorzaakt.
    // Als we libbacktrace echter niets vertellen, zal het niets doen op platforms die geen paden zoals /proc/self/exe ondersteunen!
    //
    // Gezien dit alles proberen we zo hard mogelijk om *niet* een bestandsnaam door te geven, maar we moeten op platforms die helemaal geen /proc/self/exe ondersteunen.
    //
    //
    //
    //
    //
    //
    //
    //
    cfg_if::cfg_if! {
        if #[cfg(any(target_os = "macos", target_os = "ios"))] {
            // Merk op dat we idealiter `std::env::current_exe` zouden gebruiken, maar we kunnen `std` hier niet nodig hebben.
            //
            // Gebruik `_NSGetExecutablePath` om het huidige uitvoerbare pad in een statisch gebied te laden (geef het gewoon op als het te klein is).
            //
            //
            // Merk op dat we libbacktrace hier serieus vertrouwen om niet te sterven op corrupte uitvoerbare bestanden, maar dat doet het zeker ...
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                const N: usize = 256;
                static mut BUF: [u8; N] = [0; N];
                extern {
                    fn _NSGetExecutablePath(
                        buf: *mut libc::c_char,
                        bufsize: *mut u32,
                    ) -> libc::c_int;
                }
                let mut sz: u32 = BUF.len() as u32;
                let ptr = BUF.as_mut_ptr() as *mut libc::c_char;
                if _NSGetExecutablePath(ptr, &mut sz) == 0 {
                    ptr
                } else {
                    ptr::null()
                }
            }
        } else if #[cfg(windows)] {
            use crate::windows::*;

            // Windows heeft een modus om bestanden te openen waarvan het niet kan worden verwijderd nadat het is geopend.
            // Dat is in het algemeen wat we hier willen, omdat we ervoor willen zorgen dat ons uitvoerbare bestand niet van onder ons verandert nadat we het aan libbacktrace hebben overgedragen, hopelijk de mogelijkheid om willekeurige gegevens in libbacktrace over te brengen (wat mogelijk verkeerd wordt afgehandeld) verzacht.
            //
            //
            // Gezien het feit dat we hier een beetje dansen om te proberen een soort slot op ons eigen imago te krijgen:
            //
            // * Krijg grip op het huidige proces, laad de bestandsnaam.
            // * Open een bestand met die bestandsnaam met de juiste vlaggen.
            // * Laad de bestandsnaam van het huidige proces opnieuw en zorg ervoor dat deze hetzelfde is
            //
            // Als dat allemaal lukt, hebben we in theorie inderdaad het bestand van ons proces geopend en we zijn er zeker van dat het niet zal veranderen.FWIW een heleboel hiervan is historisch gekopieerd van libstd, dus dit is mijn beste interpretatie van wat er gebeurde.
            //
            //
            //
            //
            //
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                load_filename_opt().unwrap_or(ptr::null())
            }

            unsafe fn load_filename_opt() -> Result<*const libc::c_char, ()> {
                const N: usize = 256;
                // Dit leeft in een statisch geheugen, dus we kunnen het teruggeven ...
                static mut BUF: [i8; N] = [0; N];
                // ... en dit leeft op de stapel omdat het tijdelijk is
                let mut stack_buf = [0; N];
                let name1 = query_full_name(&mut BUF)?;

                let handle = CreateFileA(
                    name1.as_ptr(),
                    GENERIC_READ,
                    FILE_SHARE_READ | FILE_SHARE_WRITE,
                    ptr::null_mut(),
                    OPEN_EXISTING,
                    0,
                    ptr::null_mut(),
                );
                if handle.is_null() {
                    return Err(());
                }

                let name2 = query_full_name(&mut stack_buf)?;
                if name1 != name2 {
                    CloseHandle(handle);
                    return Err(())
                }
                // opzettelijk `handle` hier lekken omdat als dat open staat, onze vergrendeling op deze bestandsnaam zou moeten behouden.
                //
                Ok(name1.as_ptr())
            }

            unsafe fn query_full_name(buf: &mut [i8]) -> Result<&[i8], ()> {
                let dll = GetModuleHandleA(b"kernel32.dll\0".as_ptr() as *const i8);
                if dll.is_null() {
                    return Err(())
                }
                let ptrQueryFullProcessImageNameA =
                    GetProcAddress(dll, b"QueryFullProcessImageNameA\0".as_ptr() as *const _) as usize;
                if ptrQueryFullProcessImageNameA == 0
                {
                    return Err(());
                }
                use core::mem;
                let p1 = OpenProcess(PROCESS_QUERY_INFORMATION, FALSE, GetCurrentProcessId());
                let mut len = buf.len() as u32;
                let pfnQueryFullProcessImageNameA : extern "system" fn(
                    hProcess: HANDLE,
                    dwFlags: DWORD,
                    lpExeName: LPSTR,
                    lpdwSize: PDWORD,
                ) -> BOOL = mem::transmute(ptrQueryFullProcessImageNameA);

                let rc = pfnQueryFullProcessImageNameA(p1, 0, buf.as_mut_ptr(), &mut len);
                CloseHandle(p1);

                // We willen een segment retourneren dat op nul is beëindigd, dus als alles was ingevuld en het is gelijk aan de totale lengte, stel dat dan gelijk aan mislukking.
                //
                //
                // Zorg er anders bij het retourneren van succes voor dat de nul-byte in het segment is opgenomen.
                //
                //
                if rc == 0 || len == buf.len() as u32 {
                    Err(())
                } else {
                    assert_eq!(buf[len as usize], 0);
                    Ok(&buf[..(len + 1) as usize])
                }
            }
        } else if #[cfg(target_os = "vxworks")] {
            unsafe fn load_filename() -> *const libc::c_char {
                use libc;
                use core::mem;

                const N: usize = libc::VX_RTP_NAME_LENGTH as usize + 1;
                static mut BUF: [libc::c_char; N] = [0; N];

                let mut rtp_desc : libc::RTP_DESC = mem::zeroed();
                if (libc::rtpInfoGet(0, &mut rtp_desc as *mut libc::RTP_DESC) == 0) {
                    BUF.copy_from_slice(&rtp_desc.pathName);
                    BUF.as_ptr()
                } else {
                    ptr::null()
                }
            }
        } else {
            unsafe fn load_filename() -> *const libc::c_char {
                ptr::null()
            }
        }
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let symaddr = what.address_or_ip() as usize;

    // backtrace-fouten worden momenteel onder het tapijt geveegd
    let state = init_state();
    if state.is_null() {
        return;
    }

    // Roep de `backtrace_syminfo` API aan die (door het lezen van de code) `syminfo_cb` precies één keer zou moeten aanroepen (of waarschijnlijk mislukt met een fout).
    // We doen dan meer binnen de `syminfo_cb`.
    //
    // Merk op dat we dit doen omdat `syminfo` de symbolentabel zal raadplegen en symboolnamen zal vinden, zelfs als er geen foutopsporingsinformatie in het binaire bestand staat.
    //
    //
    let mut syminfo_state = SyminfoState { pc: symaddr, cb };
    bt::backtrace_syminfo(
        state,
        symaddr as uintptr_t,
        syminfo_cb,
        error_cb,
        &mut syminfo_state as *mut _ as *mut _,
    );
}

pub unsafe fn clear_symbol_cache() {}