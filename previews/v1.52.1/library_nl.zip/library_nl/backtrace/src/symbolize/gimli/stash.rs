// wordt momenteel alleen gebruikt op Linux, dus sta dode code ergens anders toe
#![cfg_attr(not(target_os = "linux"), allow(dead_code))]

use alloc::vec;
use alloc::vec::Vec;
use core::cell::UnsafeCell;

/// Een eenvoudige arena-allocator voor bytebuffers.
pub struct Stash {
    buffers: UnsafeCell<Vec<Vec<u8>>>,
}

impl Stash {
    pub fn new() -> Stash {
        Stash {
            buffers: UnsafeCell::new(Vec::new()),
        }
    }

    /// Wijst een buffer van de opgegeven grootte toe en retourneert een veranderlijke verwijzing ernaar.
    ///
    pub fn allocate(&self, size: usize) -> &mut [u8] {
        // VEILIGHEID: dit is de enige functie die ooit een veranderlijkheid construeert
        // verwijzing naar `self.buffers`.
        let buffers = unsafe { &mut *self.buffers.get() };
        let i = buffers.len();
        buffers.push(vec![0; size]);
        // VEILIGHEID: we verwijderen nooit elementen uit `self.buffers`, dus een referentie
        // de gegevens in een willekeurige buffer zullen leven zolang `self` dat doet.
        &mut buffers[i]
    }
}