use super::{Context, Mapping, Path, Stash, Vec};
use core::convert::TryFrom;
use object::pe::{ImageDosHeader, ImageSymbol};
use object::read::pe::{ImageNtHeaders, ImageOptionalHeader, SectionTable};
use object::read::StringTable;
use object::{Bytes, LittleEndian as LE};

#[cfg(target_pointer_width = "32")]
type Pe = object::pe::ImageNtHeaders32;
#[cfg(target_pointer_width = "64")]
type Pe = object::pe::ImageNtHeaders64;

impl Mapping {
    pub fn new(path: &Path) -> Option<Mapping> {
        let map = super::mmap(path)?;
        Mapping::mk(map, |data, stash| Context::new(stash, Object::parse(data)?))
    }
}

pub struct Object<'a> {
    data: Bytes<'a>,
    sections: SectionTable<'a>,
    symbols: Vec<(usize, &'a ImageSymbol)>,
    strings: StringTable<'a>,
}

pub fn get_image_base(data: &[u8]) -> Option<usize> {
    let data = Bytes(data);
    let dos_header = ImageDosHeader::parse(data).ok()?;
    let (nt_headers, _, _) = dos_header.nt_headers::<Pe>(data).ok()?;
    usize::try_from(nt_headers.optional_header().image_base()).ok()
}

impl<'a> Object<'a> {
    fn parse(data: &'a [u8]) -> Option<Object<'a>> {
        let data = Bytes(data);
        let dos_header = ImageDosHeader::parse(data).ok()?;
        let (nt_headers, _, nt_tail) = dos_header.nt_headers::<Pe>(data).ok()?;
        let sections = nt_headers.sections(nt_tail).ok()?;
        let symtab = nt_headers.symbols(data).ok()?;
        let strings = symtab.strings();
        let image_base = usize::try_from(nt_headers.optional_header().image_base()).ok()?;

        // Verzamel alle symbolen in een lokale vector die is gesorteerd op adres en voldoende gegevens bevat om meer te weten te komen over de symboolnaam.
        // Merk op dat we alleen naar functiesymbolen kijken en ook opmerken dat de secties 1-geïndexeerd zijn omdat de nulsectie speciaal (apparently) is.
        //
        //
        //
        let mut symbols = Vec::new();
        let mut i = 0;
        let len = symtab.len();
        while i < len {
            let sym = symtab.symbol(i).ok()?;
            i += 1 + sym.number_of_aux_symbols as usize;
            let section_number = sym.section_number.get(LE);
            if sym.derived_type() != object::pe::IMAGE_SYM_DTYPE_FUNCTION || section_number == 0 {
                continue;
            }
            let addr = usize::try_from(sym.value.get(LE)).ok()?;
            let section = sections
                .section(usize::try_from(section_number).ok()?)
                .ok()?;
            let va = usize::try_from(section.virtual_address.get(LE)).ok()?;
            symbols.push((addr + va + image_base, sym));
        }
        symbols.sort_unstable_by_key(|x| x.0);
        Some(Object {
            data,
            sections,
            strings,
            symbols,
        })
    }

    pub fn section(&self, _: &Stash, name: &str) -> Option<&'a [u8]> {
        Some(
            self.sections
                .section_by_name(self.strings, name.as_bytes())?
                .1
                .pe_data(self.data)
                .ok()?
                .0,
        )
    }

    pub fn search_symtab<'b>(&'b self, addr: u64) -> Option<&'b [u8]> {
        // Merk op dat COFF, in tegenstelling tot andere formaten, niet de grootte van elk symbool insluit.
        // Zoek als laatste wanhopige poging naar het *dichtstbijzijnde*-symbool bij een bepaald adres en stuur dat terug.
        // Dit wordt echt wankel zodra symbolen worden verwijderd, omdat de symbolen die hier worden geretourneerd, totaal onjuist kunnen zijn, maar we hebben geen idee hoe we dat kunnen detecteren.
        //
        //
        //
        let addr = usize::try_from(addr).ok()?;
        let i = match self.symbols.binary_search_by_key(&addr, |p| p.0) {
            Ok(i) => i,
            // meestal staat `addr` niet in de array, maar `i` is waar we het invoegen, dus de vorige positie moet kleiner zijn dan `addr`
            //
            //
            Err(i) => i.checked_sub(1)?,
        };
        self.symbols[i].1.name(self.strings).ok()
    }

    pub(super) fn search_object_map(&self, _addr: u64) -> Option<(&Context<'_>, u64)> {
        None
    }
}