use core::{fmt, str};

cfg_if::cfg_if! {
    if #[cfg(feature = "std")] {
        use std::path::Path;
        use std::prelude::v1::*;
    }
}

use super::backtrace::Frame;
use super::types::BytesOrWideString;
use core::ffi::c_void;
use rustc_demangle::{try_demangle, Demangle};

/// Verander een adres in een symbool en geef het symbool door aan de gespecificeerde sluiting.
///
/// Deze functie zal het opgegeven adres opzoeken in gebieden zoals de lokale symbooltabel, dynamische symbooltabel of DWARF-foutopsporingsinformatie (afhankelijk van de geactiveerde implementatie) om symbolen te vinden die kunnen worden opgehaald.
///
///
/// De sluiting mag niet worden aangeroepen als er geen oplossing kon worden uitgevoerd, en het kan ook meer dan eens worden aangeroepen in het geval van inline-functies.
///
/// Opgegeven symbolen vertegenwoordigen de uitvoering op de opgegeven `addr` en retourneren file/line-paren voor dat adres (indien beschikbaar).
///
/// Merk op dat als je een `Frame` hebt, het aanbevolen is om de `resolve_frame`-functie te gebruiken in plaats van deze.
///
/// # Vereiste functies
///
/// Deze functie vereist dat de `std`-functie van de `backtrace` crate is ingeschakeld, en de `std`-functie is standaard ingeschakeld.
///
/// # Panics
///
/// Deze functie streeft ernaar om nooit panic te gebruiken, maar als de `cb` panics levert, zullen sommige platforms een dubbele panic dwingen om het proces af te breken.
/// Sommige platforms gebruiken een C-bibliotheek die intern callbacks gebruikt die niet kunnen worden teruggedraaid, dus paniek door `cb` kan een procesonderbreking veroorzaken.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         let ip = frame.ip();
///
///         backtrace::resolve(ip, |symbol| {
///             // ...
///         });
///
///         false // kijk alleen naar het bovenframe
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve<F: FnMut(&Symbol)>(addr: *mut c_void, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_unsynchronized(addr, cb) }
}

/// Verander een eerder vastgelegde frame in een symbool en geef het symbool door aan de gespecificeerde afsluiting.
///
/// Deze functie voert dezelfde functie uit als `resolve`, behalve dat er een `Frame` als argument in plaats van een adres voor nodig is.
/// Hierdoor kunnen sommige platformimplementaties van backtracing bijvoorbeeld nauwkeurigere symboolinformatie of informatie over inline-frames leveren.
///
/// Het wordt aanbevolen om dit te gebruiken als je kunt.
///
/// # Vereiste functies
///
/// Deze functie vereist dat de `std`-functie van de `backtrace` crate is ingeschakeld, en de `std`-functie is standaard ingeschakeld.
///
/// # Panics
///
/// Deze functie streeft ernaar om nooit panic te gebruiken, maar als de `cb` panics levert, zullen sommige platforms een dubbele panic dwingen om het proces af te breken.
/// Sommige platforms gebruiken een C-bibliotheek die intern callbacks gebruikt die niet kunnen worden teruggedraaid, dus paniek door `cb` kan een procesonderbreking veroorzaken.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         backtrace::resolve_frame(frame, |symbol| {
///             // ...
///         });
///
///         false // kijk alleen naar het bovenframe
///     });
/// }
/// ```
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve_frame<F: FnMut(&Symbol)>(frame: &Frame, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_frame_unsynchronized(frame, cb) }
}

pub enum ResolveWhat<'a> {
    Address(*mut c_void),
    Frame(&'a Frame),
}

impl<'a> ResolveWhat<'a> {
    #[allow(dead_code)]
    fn address_or_ip(&self) -> *mut c_void {
        match self {
            ResolveWhat::Address(a) => adjust_ip(*a),
            ResolveWhat::Frame(f) => adjust_ip(f.ip()),
        }
    }
}

// IP-waarden van stapelframes zijn meestal (always?) de instructie *na* de aanroep die de daadwerkelijke stacktrace is.
// Als je dit symboliseert, staat het filename/line-nummer één voor en misschien in de leegte als het bijna aan het einde van de functie is.
//
// Dit lijkt in principe altijd het geval te zijn op alle platforms, dus we trekken er altijd één af van een opgelost ip om het op te lossen naar de vorige oproepinstructie in plaats van dat de instructie wordt teruggestuurd.
//
//
// Idealiter zouden we dit niet doen.
// Idealiter zouden we bellers van de `resolve` API's hier nodig hebben om handmatig de -1 uit te voeren en aan te geven dat ze locatie-informatie willen voor de *vorige* instructie, niet de huidige.
// Idealiter zouden we ook exposeren op `Frame` als we inderdaad het adres zijn van de volgende instructie of de huidige.
//
// Voorlopig is dit echter een vrij nicheprobleem, dus we trekken er intern altijd een af.
// Consumenten moeten blijven werken en redelijk goede resultaten behalen, dus we moeten goed genoeg zijn.
//
//
//
//
//
//
fn adjust_ip(a: *mut c_void) -> *mut c_void {
    if a.is_null() {
        a
    } else {
        (a as usize - 1) as *mut c_void
    }
}

/// Hetzelfde als `resolve`, alleen onveilig omdat het niet gesynchroniseerd is.
///
/// Deze functie heeft geen synchronisatiegaranties, maar is beschikbaar wanneer de `std`-functie van deze crate niet is gecompileerd.
/// Zie de `resolve`-functie voor meer documentatie en voorbeelden.
///
/// # Panics
///
/// Zie informatie over `resolve` voor kanttekeningen bij paniek in `cb`.
///
pub unsafe fn resolve_unsynchronized<F>(addr: *mut c_void, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Address(addr), &mut cb)
}

/// Hetzelfde als `resolve_frame`, alleen onveilig omdat het niet gesynchroniseerd is.
///
/// Deze functie heeft geen synchronisatiegaranties, maar is beschikbaar wanneer de `std`-functie van deze crate niet is gecompileerd.
/// Zie de `resolve_frame`-functie voor meer documentatie en voorbeelden.
///
/// # Panics
///
/// Zie informatie over `resolve_frame` voor kanttekeningen bij paniek in `cb`.
///
pub unsafe fn resolve_frame_unsynchronized<F>(frame: &Frame, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Frame(frame), &mut cb)
}

/// Een trait vertegenwoordigt de resolutie van een symbool in een bestand.
///
/// Deze trait wordt geleverd als een trait-object voor de afsluiting van de `backtrace::resolve`-functie en wordt virtueel verzonden omdat onbekend is welke implementatie erachter zit.
///
///
/// Een symbool kan contextuele informatie geven over een functie, bijvoorbeeld de naam, bestandsnaam, regelnummer, precies adres, etc.
/// Niet alle informatie is echter altijd beschikbaar in een symbool, dus alle methoden retourneren een `Option`.
///
///
pub struct Symbol {
    // TODO: deze levenslange gebondenheid moet uiteindelijk worden gehandhaafd tot `Symbol`,
    // maar dat is momenteel een ingrijpende verandering.
    // Voorlopig is dit veilig aangezien `Symbol` alleen via referentie wordt uitgedeeld en niet kan worden gekloond.
    inner: imp::Symbol<'static>,
}

impl Symbol {
    /// Retourneert de naam van deze functie.
    ///
    /// De geretourneerde structuur kan worden gebruikt om verschillende eigenschappen over de symboolnaam op te vragen:
    ///
    ///
    /// * De `Display`-implementatie zal het ontwarde symbool afdrukken.
    /// * De onbewerkte `str`-waarde van het symbool is toegankelijk (als het geldige utf-8 is).
    /// * De onbewerkte bytes voor de symboolnaam zijn toegankelijk.
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.inner.name()
    }

    /// Retourneert het startadres van deze functie.
    pub fn addr(&self) -> Option<*mut c_void> {
        self.inner.addr().map(|p| p as *mut _)
    }

    /// Retourneert de onbewerkte bestandsnaam als een segment.
    /// Dit is vooral handig voor `no_std`-omgevingen.
    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.inner.filename_raw()
    }

    /// Geeft het kolomnummer terug waarvoor dit symbool momenteel wordt uitgevoerd.
    ///
    /// Alleen gimli biedt momenteel hier een waarde en zelfs dan alleen als `filename` `Some` retourneert, en daarom is het dan onderhevig aan soortgelijke voorbehouden.
    ///
    pub fn colno(&self) -> Option<u32> {
        self.inner.colno()
    }

    /// Geeft het regelnummer terug waarvoor dit symbool momenteel wordt uitgevoerd.
    ///
    /// Deze geretourneerde waarde is doorgaans `Some` als `filename` `Some` retourneert, en is bijgevolg onderhevig aan soortgelijke voorbehouden.
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.inner.lineno()
    }

    /// Geeft de bestandsnaam terug waar deze functie is gedefinieerd.
    ///
    /// Dit is momenteel alleen beschikbaar als libbacktrace of gimli wordt gebruikt (bijv
    /// unix platforms anders) en wanneer een binair bestand wordt gecompileerd met debuginfo.
    /// Als aan geen van deze voorwaarden is voldaan, wordt waarschijnlijk `None` geretourneerd.
    ///
    /// # Vereiste functies
    ///
    /// Deze functie vereist dat de `std`-functie van de `backtrace` crate is ingeschakeld, en de `std`-functie is standaard ingeschakeld.
    ///
    ///
    #[cfg(feature = "std")]
    #[allow(unreachable_code)]
    pub fn filename(&self) -> Option<&Path> {
        self.inner.filename()
    }
}

impl fmt::Debug for Symbol {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let mut d = f.debug_struct("Symbol");
        if let Some(name) = self.name() {
            d.field("name", &name);
        }
        if let Some(addr) = self.addr() {
            d.field("addr", &addr);
        }

        #[cfg(feature = "std")]
        {
            if let Some(filename) = self.filename() {
                d.field("filename", &filename);
            }
        }

        if let Some(lineno) = self.lineno() {
            d.field("lineno", &lineno);
        }
        d.finish()
    }
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        // Misschien een ontleed C++ -symbool, als het ontleden van het verminkte symbool als Rust is mislukt.
        //
        struct OptionCppSymbol<'a>(Option<::cpp_demangle::BorrowedSymbol<'a>>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(input: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(::cpp_demangle::BorrowedSymbol::new(input).ok())
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(None)
            }
        }
    } else {
        use core::marker::PhantomData;

        // Zorg ervoor dat u deze nulgrootte behoudt, zodat de `cpp_demangle`-functie geen kosten heeft wanneer deze is uitgeschakeld.
        //
        struct OptionCppSymbol<'a>(PhantomData<&'a ()>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(_: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }
        }
    }
}

/// Een omhulsel rond een symboolnaam om ergonomische accessors te bieden aan de ontwarde naam, de onbewerkte bytes, de onbewerkte tekenreeks, enz.
///
// Sta dode code toe voor wanneer de `cpp_demangle`-functie niet is ingeschakeld.
#[allow(dead_code)]
pub struct SymbolName<'a> {
    bytes: &'a [u8],
    demangled: Option<Demangle<'a>>,
    cpp_demangled: OptionCppSymbol<'a>,
}

impl<'a> SymbolName<'a> {
    /// Creëert een nieuwe symboolnaam van de onbewerkte onderliggende bytes.
    pub fn new(bytes: &'a [u8]) -> SymbolName<'a> {
        let str_bytes = str::from_utf8(bytes).ok();
        let demangled = str_bytes.and_then(|s| try_demangle(s).ok());

        let cpp = if demangled.is_none() {
            OptionCppSymbol::parse(bytes)
        } else {
            OptionCppSymbol::none()
        };

        SymbolName {
            bytes: bytes,
            demangled: demangled,
            cpp_demangled: cpp,
        }
    }

    /// Retourneert de onbewerkte (mangled)-symboolnaam als een `str` als het symbool een geldige utf-8 is.
    ///
    /// Gebruik de `Display`-implementatie als u de ontwarde versie wilt.
    pub fn as_str(&self) -> Option<&'a str> {
        self.demangled
            .as_ref()
            .map(|s| s.as_str())
            .or_else(|| str::from_utf8(self.bytes).ok())
    }

    /// Retourneert de onbewerkte symboolnaam als een lijst met bytes
    pub fn as_bytes(&self) -> &'a [u8] {
        self.bytes
    }
}

fn format_symbol_name(
    fmt: fn(&str, &mut fmt::Formatter<'_>) -> fmt::Result,
    mut bytes: &[u8],
    f: &mut fmt::Formatter<'_>,
) -> fmt::Result {
    while bytes.len() > 0 {
        match str::from_utf8(bytes) {
            Ok(name) => {
                fmt(name, f)?;
                break;
            }
            Err(err) => {
                fmt("\u{FFFD}", f)?;

                match err.error_len() {
                    Some(len) => bytes = &bytes[err.valid_up_to() + len..],
                    None => break,
                }
            }
        }
    }
    Ok(())
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else if let Some(ref cpp) = self.cpp_demangled.0 {
                    cpp.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    } else {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    }
}

cfg_if::cfg_if! {
    if #[cfg(all(feature = "std", feature = "cpp_demangle"))] {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                use std::fmt::Write;

                if let Some(ref s) = self.demangled {
                    return s.fmt(f)
                }

                // Dit kan worden afgedrukt als het ontwarde symbool niet echt geldig is, dus behandel de fout hier netjes door deze niet naar buiten toe te verspreiden.
                //
                //
                if let Some(ref cpp) = self.cpp_demangled.0 {
                    let mut s = String::new();
                    if write!(s, "{}", cpp).is_ok() {
                        return s.fmt(f)
                    }
                }

                format_symbol_name(fmt::Debug::fmt, self.bytes, f)
            }
        }
    } else {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Debug::fmt, self.bytes, f)
                }
            }
        }
    }
}

/// Probeer dat cachegeheugen dat wordt gebruikt om adressen te symboliseren, terug te vorderen.
///
/// Deze methode zal proberen om globale datastructuren vrij te geven die anders globaal of in de thread in de cache zijn opgeslagen en die typisch geparseerde DWARF-informatie of iets dergelijks vertegenwoordigen.
///
///
/// # Caveats
///
/// Hoewel deze functie altijd beschikbaar is, doet deze bij de meeste implementaties eigenlijk niets.
/// Bibliotheken zoals dbghelp of libbacktrace bieden geen faciliteiten om de toewijzing van de status ongedaan te maken en het toegewezen geheugen te beheren.
/// Voorlopig is de `gimli-symbolize` feature van deze crate de enige feature waar deze functie enig effect heeft.
///
///
///
#[cfg(feature = "std")]
pub fn clear_symbol_cache() {
    let _guard = crate::lock::lock();
    unsafe {
        imp::clear_symbol_cache();
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        mod miri;
        use miri as imp;
    } else if #[cfg(all(windows, target_env = "msvc", not(target_vendor = "uwp")))] {
        mod dbghelp;
        use dbghelp as imp;
    } else if #[cfg(all(
        feature = "libbacktrace",
        any(unix, all(windows, not(target_vendor = "uwp"), target_env = "gnu")),
        not(target_os = "fuchsia"),
        not(target_os = "emscripten"),
        not(target_env = "uclibc"),
        not(target_env = "libnx"),
    ))] {
        mod libbacktrace;
        use libbacktrace as imp;
    } else if #[cfg(all(
        feature = "gimli-symbolize",
        any(unix, windows),
        not(target_vendor = "uwp"),
        not(target_os = "emscripten"),
    ))] {
        mod gimli;
        use gimli as imp;
    } else {
        mod noop;
        use noop as imp;
    }
}