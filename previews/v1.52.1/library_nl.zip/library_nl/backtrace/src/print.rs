#[cfg(feature = "std")]
use super::{BacktraceFrame, BacktraceSymbol};
use super::{BytesOrWideString, Frame, SymbolName};
use core::ffi::c_void;
use core::fmt;

const HEX_WIDTH: usize = 2 + 2 * core::mem::size_of::<usize>();

#[cfg(target_os = "fuchsia")]
mod fuchsia;

/// Een formatter voor backtraces.
///
/// Dit type kan worden gebruikt om een backtrace af te drukken, ongeacht waar de backtrace zelf vandaan komt.
/// Als u een `Backtrace`-type heeft, gebruikt de `Debug`-implementatie dit afdrukformaat al.
///
pub struct BacktraceFmt<'a, 'b> {
    fmt: &'a mut fmt::Formatter<'b>,
    frame_index: usize,
    format: PrintFmt,
    print_path:
        &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result + 'b),
}

/// De afdrukstijlen die we kunnen afdrukken
#[derive(Copy, Clone, Eq, PartialEq)]
pub enum PrintFmt {
    /// Drukt een beknopte backtrace af die idealiter alleen relevante informatie bevat
    Short,
    /// Drukt een backtrace af die alle mogelijke informatie bevat
    Full,
    #[doc(hidden)]
    __Nonexhaustive,
}

impl<'a, 'b> BacktraceFmt<'a, 'b> {
    /// Maak een nieuwe `BacktraceFmt` die de uitvoer naar de meegeleverde `fmt` zal schrijven.
    ///
    /// Het `format`-argument bepaalt de stijl waarin de backtrace wordt afgedrukt, en het `print_path`-argument wordt gebruikt om de `BytesOrWideString`-instanties van bestandsnamen af te drukken.
    /// Dit type drukt zelf geen bestandsnamen af, maar deze callback is vereist om dit te doen.
    ///
    ///
    ///
    pub fn new(
        fmt: &'a mut fmt::Formatter<'b>,
        format: PrintFmt,
        print_path: &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result
                     + 'b),
    ) -> Self {
        BacktraceFmt {
            fmt,
            frame_index: 0,
            format,
            print_path,
        }
    }

    /// Drukt een preambule af voor de backtrace die op het punt staat te worden afgedrukt.
    ///
    /// Dit is op sommige platforms vereist om backtraces later volledig te symboliseren, en anders zou dit gewoon de eerste methode moeten zijn die u aanroept nadat u een `BacktraceFmt` hebt gemaakt.
    ///
    ///
    pub fn add_context(&mut self) -> fmt::Result {
        #[cfg(target_os = "fuchsia")]
        fuchsia::print_dso_context(self.fmt)?;
        Ok(())
    }

    /// Voegt een frame toe aan de backtrace-uitvoer.
    ///
    /// Deze commit retourneert een RAII-instantie van een `BacktraceFrameFmt` die kan worden gebruikt om daadwerkelijk een frame af te drukken, en bij vernietiging zal het de frameteller verhogen.
    ///
    ///
    pub fn frame(&mut self) -> BacktraceFrameFmt<'_, 'a, 'b> {
        BacktraceFrameFmt {
            fmt: self,
            symbol_index: 0,
        }
    }

    /// Voltooit de backtrace-uitvoer.
    ///
    /// Dit is momenteel een no-op, maar is toegevoegd voor future-compatibiliteit met backtrace-formaten.
    ///
    pub fn finish(&mut self) -> fmt::Result {
        // Momenteel een no-op-inclusief deze hook om future-toevoegingen mogelijk te maken.
        Ok(())
    }
}

/// Een formatter voor slechts één frame van een backtrace.
///
/// Dit type wordt gemaakt door de `BacktraceFmt::frame`-functie.
pub struct BacktraceFrameFmt<'fmt, 'a, 'b> {
    fmt: &'fmt mut BacktraceFmt<'a, 'b>,
    symbol_index: usize,
}

impl BacktraceFrameFmt<'_, '_, '_> {
    /// Drukt een `BacktraceFrame` af met deze frame-formatter.
    ///
    /// Hiermee worden alle `BacktraceSymbol`-instanties binnen de `BacktraceFrame` recursief afgedrukt.
    ///
    /// # Vereiste functies
    ///
    /// Deze functie vereist dat de `std`-functie van de `backtrace` crate is ingeschakeld, en de `std`-functie is standaard ingeschakeld.
    ///
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_frame(&mut self, frame: &BacktraceFrame) -> fmt::Result {
        let symbols = frame.symbols();
        for symbol in symbols {
            self.backtrace_symbol(frame, symbol)?;
        }
        if symbols.is_empty() {
            self.print_raw(frame.ip(), None, None, None)?;
        }
        Ok(())
    }

    /// Drukt een `BacktraceSymbol` af binnen een `BacktraceFrame`.
    ///
    /// # Vereiste functies
    ///
    /// Deze functie vereist dat de `std`-functie van de `backtrace` crate is ingeschakeld, en de `std`-functie is standaard ingeschakeld.
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_symbol(
        &mut self,
        frame: &BacktraceFrame,
        symbol: &BacktraceSymbol,
    ) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            // TODO: dit is niet geweldig dat we uiteindelijk niets afdrukken
            // met niet-utf8 bestandsnamen.
            // Gelukkig is bijna alles utf8, dus dit zou niet al te erg moeten zijn.
            symbol
                .filename()
                .and_then(|p| Some(BytesOrWideString::Bytes(p.to_str()?.as_bytes()))),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// Drukt een onbewerkte getraceerde `Frame` en `Symbol` af, meestal vanuit de onbewerkte callbacks van deze crate.
    ///
    pub fn symbol(&mut self, frame: &Frame, symbol: &super::Symbol) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            symbol.filename_raw(),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// Voegt een onbewerkt frame toe aan de backtrace-uitvoer.
    ///
    /// Deze methode neemt, in tegenstelling tot de vorige, de onbewerkte argumenten voor het geval ze afkomstig zijn van verschillende locaties.
    /// Merk op dat dit meerdere keren kan worden aangeroepen voor één frame.
    ///
    pub fn print_raw(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
    ) -> fmt::Result {
        self.print_raw_with_column(frame_ip, symbol_name, filename, lineno, None)
    }

    /// Voegt een onbewerkt frame toe aan de backtrace-uitvoer, inclusief kolominformatie.
    ///
    /// Deze methode neemt, net als de vorige, de onbewerkte argumenten voor het geval ze afkomstig zijn van verschillende locaties.
    /// Merk op dat dit meerdere keren kan worden aangeroepen voor één frame.
    ///
    pub fn print_raw_with_column(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Fuchsia kan niet symboliseren binnen een proces, dus het heeft een speciaal formaat dat later kan worden gebruikt om te symboliseren.
        // Druk dat af in plaats van adressen in ons eigen formaat hier af te drukken.
        //
        if cfg!(target_os = "fuchsia") {
            self.print_raw_fuchsia(frame_ip)?;
        } else {
            self.print_raw_generic(frame_ip, symbol_name, filename, lineno, colno)?;
        }
        self.symbol_index += 1;
        Ok(())
    }

    #[allow(unused_mut)]
    fn print_raw_generic(
        &mut self,
        mut frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Het is niet nodig om "null"-frames af te drukken, het betekent in feite dat de backtrace van het systeem een beetje gretig was om super ver terug te traceren.
        //
        if let PrintFmt::Short = self.fmt.format {
            if frame_ip.is_null() {
                return Ok(());
            }
        }

        // Om de TCB-grootte in de Sgx-enclave te verkleinen, willen we geen symboolresolutie-functionaliteit implementeren.
        // In plaats daarvan kunnen we de offset van het adres hier afdrukken, die later kan worden toegewezen aan de juiste functie.
        //
        #[cfg(all(feature = "std", target_env = "sgx", target_vendor = "fortanix"))]
        {
            let image_base = std::os::fortanix_sgx::mem::image_base();
            frame_ip = usize::wrapping_sub(frame_ip as usize, image_base as _) as _;
        }

        // Druk de index van het frame af, evenals de optionele instructieaanwijzer van het frame.
        // Als we voorbij het eerste symbool van dit frame zijn, drukken we gewoon de juiste witruimte af.
        //
        if self.symbol_index == 0 {
            write!(self.fmt.fmt, "{:4}: ", self.fmt.frame_index)?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$?} - ", frame_ip, HEX_WIDTH)?;
            }
        } else {
            write!(self.fmt.fmt, "      ")?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH + 3)?;
            }
        }

        // Schrijf vervolgens de symboolnaam op en gebruik de alternatieve opmaak voor meer informatie als we een volledige backtrace zijn.
        // Hier behandelen we ook symbolen die geen naam hebben,
        //
        match (symbol_name, &self.fmt.format) {
            (Some(name), PrintFmt::Short) => write!(self.fmt.fmt, "{:#}", name)?,
            (Some(name), PrintFmt::Full) => write!(self.fmt.fmt, "{}", name)?,
            (None, _) | (_, PrintFmt::__Nonexhaustive) => write!(self.fmt.fmt, "<unknown>")?,
        }
        self.fmt.fmt.write_str("\n")?;

        // En als laatste, druk het filename/line-nummer af als ze beschikbaar zijn.
        if let (Some(file), Some(line)) = (filename, lineno) {
            self.print_fileline(file, line, colno)?;
        }

        Ok(())
    }

    fn print_fileline(
        &mut self,
        file: BytesOrWideString<'_>,
        line: u32,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Filename/line worden afgedrukt op regels onder de symboolnaam, dus druk een geschikte witruimte af om onszelf een beetje rechts uit te lijnen.
        //
        if let PrintFmt::Full = self.fmt.format {
            write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH)?;
        }
        write!(self.fmt.fmt, "             at ")?;

        // Delegeer naar onze interne callback om de bestandsnaam af te drukken en vervolgens het lijnnummer af te drukken.
        //
        (self.fmt.print_path)(self.fmt.fmt, file)?;
        write!(self.fmt.fmt, ":{}", line)?;

        // Voeg kolomnummer toe, indien beschikbaar.
        if let Some(colno) = colno {
            write!(self.fmt.fmt, ":{}", colno)?;
        }

        write!(self.fmt.fmt, "\n")?;
        Ok(())
    }

    fn print_raw_fuchsia(&mut self, frame_ip: *mut c_void) -> fmt::Result {
        // We geven alleen om het eerste symbool van een frame
        if self.symbol_index == 0 {
            self.fmt.fmt.write_str("{{{bt:")?;
            write!(self.fmt.fmt, "{}:{:?}", self.fmt.frame_index, frame_ip)?;
            self.fmt.fmt.write_str("}}}\n")?;
        }
        Ok(())
    }
}

impl Drop for BacktraceFrameFmt<'_, '_, '_> {
    fn drop(&mut self) {
        self.fmt.frame_index += 1;
    }
}