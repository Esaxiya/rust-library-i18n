//! Een module om te helpen bij het beheren van dbghelp-bindingen op Windows
//!
//! Backtraces op Windows (althans voor MSVC) worden grotendeels aangedreven door `dbghelp.dll` en de verschillende functies die het bevat.
//! Deze functies worden momenteel *dynamisch* geladen in plaats van statisch naar `dbghelp.dll` te linken.
//! Dit wordt momenteel gedaan door de standaardbibliotheek (en is daar in theorie vereist), maar het is een poging om de statische dll-afhankelijkheden van een bibliotheek te verminderen, aangezien backtraces doorgaans vrij optioneel zijn.
//!
//! Dat gezegd hebbende, laadt `dbghelp.dll` bijna altijd met succes op Windows.
//!
//! Merk echter op dat aangezien we al deze ondersteuning dynamisch laden, we de onbewerkte definities in `winapi` niet echt kunnen gebruiken, maar dat we eerder de functieaanwijzertypes zelf moeten definiëren en die moeten gebruiken.
//! We willen niet echt bezig zijn met het dupliceren van winapi, dus we hebben een Cargo-functie `verify-winapi` die beweert dat alle bindingen overeenkomen met die in winapi en deze functie is ingeschakeld op CI.
//!
//! Ten slotte zult u hier opmerken dat de dll voor `dbghelp.dll` nooit wordt verwijderd, en dat is momenteel opzettelijk.
//! De gedachte is dat we het wereldwijd kunnen cachen en gebruiken tussen aanroepen naar de API, waardoor dure loads/unloads wordt vermeden.
//! Als dit een probleem is voor lekdetectoren of iets dergelijks, kunnen we de brug oversteken als we daar aankomen.
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(non_snake_case)]

use super::windows::*;
use core::mem;
use core::ptr;

// Werk rond `SymGetOptions` en `SymSetOptions` die niet aanwezig zijn in Winapi zelf.
// Anders wordt dit alleen gebruikt als we typen dubbel controleren op winapi.
//
#[cfg(feature = "verify-winapi")]
mod dbghelp {
    use crate::windows::*;
    pub use winapi::um::dbghelp::{
        StackWalk64, SymCleanup, SymFromAddrW, SymFunctionTableAccess64, SymGetLineFromAddrW64,
        SymGetModuleBase64, SymInitializeW,
    };

    extern "system" {
        // Nog niet gedefinieerd in winapi
        pub fn SymGetOptions() -> u32;
        pub fn SymSetOptions(_: u32);

        // Dit is gedefinieerd in winapi, maar het is onjuist (FIXME winapi-rs#768)
        pub fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD,
        ) -> BOOL;

        // Nog niet gedefinieerd in winapi
        pub fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW,
        ) -> BOOL;
        pub fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64,
        ) -> BOOL;
    }

    pub fn assert_equal_types<T>(a: T, _b: T) -> T {
        a
    }
}

// Deze macro wordt gebruikt om een `Dbghelp`-structuur te definiëren die intern alle functie-aanwijzers bevat die we zouden kunnen laden.
//
macro_rules! dbghelp {
    (extern "system" {
        $(fn $name:ident($($arg:ident: $argty:ty),*) -> $ret: ty;)*
    }) => (
        pub struct Dbghelp {
            /// De geladen DLL voor `dbghelp.dll`
            dll: HMODULE,

            // Elke functie-aanwijzer voor elke functie die we zouden kunnen gebruiken
            $($name: usize,)*
        }

        static mut DBGHELP: Dbghelp = Dbghelp {
            // Aanvankelijk hebben we de DLL niet geladen
            dll: 0 as *mut _,
            // Initieel worden alle functies op nul gezet om aan te geven dat ze dynamisch moeten worden geladen.
            //
            $($name: 0,)*
        };

        // Gemakstypedef voor elk functietype.
        $(pub type $name = unsafe extern "system" fn($($argty),*) -> $ret;)*

        impl Dbghelp {
            /// Pogingen om `dbghelp.dll` te openen.
            /// Retourneert succes als het werkt of een fout als `LoadLibraryW` mislukt.
            ///
            /// Panics als de bibliotheek al is geladen.
            fn ensure_open(&mut self) -> Result<(), ()> {
                if !self.dll.is_null() {
                    return Ok(())
                }
                let lib = b"dbghelp.dll\0";
                unsafe {
                    self.dll = LoadLibraryA(lib.as_ptr() as *const i8);
                    if self.dll.is_null() {
                        Err(())
                    }  else {
                        Ok(())
                    }
                }
            }

            // Functie voor elke methode die we willen gebruiken.
            // Wanneer het wordt aangeroepen, leest het de functie-aanwijzer in de cache of laadt het en retourneert de geladen waarde.
            // Er worden ladingen beweerd om te slagen.
            $(pub fn $name(&mut self) -> Option<$name> {
                unsafe {
                    if self.$name == 0 {
                        let name = concat!(stringify!($name), "\0");
                        self.$name = self.symbol(name.as_bytes())?;
                    }
                    let ret = mem::transmute::<usize, $name>(self.$name);
                    #[cfg(feature = "verify-winapi")]
                    dbghelp::assert_equal_types(ret, dbghelp::$name);
                    Some(ret)
                }
            })*

            fn symbol(&self, symbol: &[u8]) -> Option<usize> {
                unsafe {
                    match GetProcAddress(self.dll, symbol.as_ptr() as *const _) as usize {
                        0 => None,
                        n => Some(n),
                    }
                }
            }
        }

        // Gemaksproxy om de opschoningsvergrendelingen te gebruiken om naar dbghelp-functies te verwijzen.
        //
        #[allow(dead_code)]
        impl Init {
            $(pub fn $name(&self) -> $name {
                unsafe {
                    DBGHELP.$name().unwrap()
                }
            })*

            pub fn dbghelp(&self) -> *mut Dbghelp {
                unsafe {
                    &mut DBGHELP
                }
            }
        }
    )

}

const SYMOPT_DEFERRED_LOADS: DWORD = 0x00000004;

dbghelp! {
    extern "system" {
        fn SymGetOptions() -> DWORD;
        fn SymSetOptions(options: DWORD) -> ();
        fn SymInitializeW(
            handle: HANDLE,
            path: PCWSTR,
            invade: BOOL
        ) -> BOOL;
        fn SymCleanup(handle: HANDLE) -> BOOL;
        fn StackWalk64(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME64,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64
        ) -> BOOL;
        fn SymFunctionTableAccess64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> PVOID;
        fn SymGetModuleBase64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> DWORD64;
        fn SymFromAddrW(
            hProcess: HANDLE,
            Address: DWORD64,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromAddrW64(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
        fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD
        ) -> BOOL;
        fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
    }
}

pub struct Init {
    lock: HANDLE,
}

/// Initialiseer alle ondersteuning die nodig is om toegang te krijgen tot `dbghelp` API-functies vanuit deze crate.
///
///
/// Merk op dat deze functie **veilig** is, hij heeft intern zijn eigen synchronisatie.
/// Merk ook op dat het veilig is om deze functie meerdere keren recursief aan te roepen.
///
pub fn init() -> Result<Init, ()> {
    use core::sync::atomic::{AtomicUsize, Ordering::SeqCst};

    unsafe {
        // Het eerste dat we moeten doen, is deze functie synchroniseren.Dit kan gelijktijdig worden aangeroepen vanuit andere threads of recursief binnen één thread.
        // Merk echter op dat het lastiger is dan dat, omdat wat we hier gebruiken, `dbghelp`,*ook* moet worden gesynchroniseerd met alle andere bellers naar `dbghelp` in dit proces.
        //
        // Meestal zijn er niet zo veel aanroepen naar `dbghelp` binnen hetzelfde proces en we kunnen waarschijnlijk veilig aannemen dat wij de enigen zijn die er toegang toe hebben.
        // Er is echter één primaire andere gebruiker waarover we ons zorgen moeten maken, en die is ironisch genoeg onszelf, maar dan in de standaardbibliotheek.
        // De standaardbibliotheek van Rust is afhankelijk van deze crate voor backtrace-ondersteuning, en deze crate bestaat ook op crates.io.
        // Dit betekent dat als de standaardbibliotheek een panic-backtrace afdrukt, deze kan racen met deze crate afkomstig van crates.io, wat segfaults veroorzaakt.
        //
        // Om dit synchronisatieprobleem op te lossen, gebruiken we hier een Windows-specifieke truc (het is tenslotte een Windows-specifieke beperking over synchronisatie).
        // We maken een *session-local* met de naam mutex om deze oproep te beschermen.
        // De bedoeling hier is dat de standaardbibliotheek en deze crate API's op Rust-niveau niet hoeven te delen om hier te synchroniseren, maar in plaats daarvan achter de schermen kunnen werken om ervoor te zorgen dat ze met elkaar synchroniseren.
        //
        // Op die manier kunnen we er zeker van zijn dat wanneer deze functie wordt aangeroepen via de standaardbibliotheek of via crates.io, dezelfde mutex wordt opgehaald.
        //
        // Dit alles wil dus zeggen dat het eerste dat we hier doen, is dat we atomair een `HANDLE` maken die op Windows de naam mutex heeft.
        // We synchroniseren een beetje met andere threads die deze functie specifiek delen en zorgen ervoor dat er slechts één handle wordt gemaakt per instantie van deze functie.
        // Merk op dat de handle nooit wordt gesloten als deze eenmaal is opgeslagen in het global.
        //
        // Nadat we het slot daadwerkelijk hebben gebruikt, kopen we het eenvoudig en onze `Init`-handgreep die we uitdelen, is verantwoordelijk voor het uiteindelijk laten vallen.
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        static LOCK: AtomicUsize = AtomicUsize::new(0);
        let mut lock = LOCK.load(SeqCst);
        if lock == 0 {
            lock = CreateMutexA(
                ptr::null_mut(),
                0,
                "Local\\RustBacktraceMutex\0".as_ptr() as _,
            ) as usize;
            if lock == 0 {
                return Err(());
            }
            if let Err(other) = LOCK.compare_exchange(0, lock, SeqCst, SeqCst) {
                debug_assert!(other != 0);
                CloseHandle(lock as HANDLE);
                lock = other;
            }
        }
        debug_assert!(lock != 0);
        let lock = lock as HANDLE;
        let r = WaitForSingleObjectEx(lock, INFINITE, FALSE);
        debug_assert_eq!(r, 0);
        let ret = Init { lock };

        // Oké, pfff!Nu we allemaal veilig zijn gesynchroniseerd, gaan we echt beginnen met het verwerken van alles.
        // Allereerst moeten we ervoor zorgen dat `dbghelp.dll` daadwerkelijk in dit proces wordt geladen.
        // We doen dit dynamisch om een statische afhankelijkheid te vermijden.
        // Dit is van oudsher gedaan om rare koppelingsproblemen te omzeilen en is bedoeld om binaire bestanden een beetje draagbaarder te maken, aangezien dit grotendeels slechts een hulpprogramma voor het opsporen van fouten is.
        //
        //
        // Zodra we `dbghelp.dll` hebben geopend, moeten we er enkele initialisatiefuncties in aanroepen, en dat wordt hieronder meer beschreven.
        // We doen dit echter maar één keer, dus we hebben een globale booleaanse waarde die aangeeft of we al of niet klaar zijn.
        //
        //
        //
        //
        DBGHELP.ensure_open()?;

        static mut INITIALIZED: bool = false;
        if INITIALIZED {
            return Ok(ret);
        }

        let orig = DBGHELP.SymGetOptions().unwrap()();

        // Zorg ervoor dat de `SYMOPT_DEFERRED_LOADS`-vlag is ingesteld, want volgens MSVC's eigen documenten hierover: "This is the fastest, most efficient way to use the symbol handler.", dus laten we dat doen!
        //
        //
        DBGHELP.SymSetOptions().unwrap()(orig | SYMOPT_DEFERRED_LOADS);

        // Initialiseer symbolen daadwerkelijk met MSVC.Merk op dat dit kan mislukken, maar we negeren het.
        // Er is niet per se een hoop stand van de techniek voor, maar LLVM lijkt intern de retourwaarde hier te negeren en een van de ontsmettingsbibliotheken in LLVM drukt een enge waarschuwing af als dit mislukt, maar negeert het in feite op de lange termijn.
        //
        //
        // Een geval dat dit vaak naar voren komt voor Rust is dat de standaardbibliotheek en deze crate op crates.io beide willen strijden om `SymInitializeW`.
        // De standaardbibliotheek wilde in het verleden de meeste tijd initialiseren en opschonen, maar nu het deze crate gebruikt, betekent dit dat iemand eerst tot initialisatie komt en de ander die initialisatie oppikt.
        //
        //
        //
        //
        //
        //
        DBGHELP.SymInitializeW().unwrap()(GetCurrentProcess(), ptr::null_mut(), TRUE);
        INITIALIZED = true;
        Ok(ret)
    }
}

impl Drop for Init {
    fn drop(&mut self) {
        unsafe {
            let r = ReleaseMutex(self.lock);
            debug_assert!(r != 0);
        }
    }
}