# backtrace-rs

[Documentation](https://docs.rs/backtrace)

Een bibliotheek voor het verkrijgen van backtraces tijdens runtime voor Rust.
Deze bibliotheek heeft tot doel de ondersteuning van de standaardbibliotheek te verbeteren door een programma-interface te bieden om mee te werken, maar ondersteunt ook het eenvoudig afdrukken van de huidige backtrace zoals libstd's panics.

## Install

```toml
[dependencies]
backtrace = "0.3"
```

## Usage

Om eenvoudig een backtrace vast te leggen en het afhandelen ervan uit te stellen tot een later tijdstip, kunt u het `Backtrace`-type op het hoogste niveau gebruiken.

```rust
use backtrace::Backtrace;

fn main() {
    let bt = Backtrace::new();

    // do_some_work();

    println!("{:?}", bt);
}
```

Als u echter meer onbewerkte toegang tot de daadwerkelijke traceerfunctionaliteit wilt, kunt u de `trace`-en `resolve`-functies rechtstreeks gebruiken.

```rust
fn main() {
    backtrace::trace(|frame| {
        let ip = frame.ip();
        let symbol_address = frame.symbol_address();

        // Verander deze instructiewijzer in een symboolnaam
        backtrace::resolve_frame(frame, |symbol| {
            if let Some(name) = symbol.name() {
                // ...
            }
            if let Some(filename) = symbol.filename() {
                // ...
            }
        });

        true // ga door naar het volgende frame
    });
}
```

# License

Dit project is gelicentieerd onder een van

 * Apache-licentie, versie 2.0, ([LICENSE-APACHE](LICENSE-APACHE) of http://www.apache.org/licenses/LICENSE-2.0)
 * MIT-licentie ([LICENSE-MIT](LICENSE-MIT) of http://opensource.org/licenses/MIT)

naar uw keuze.

### Contribution

Tenzij u expliciet anders aangeeft, zal elke bijdrage die opzettelijk door u is ingediend voor opname in backtrace-rs, zoals gedefinieerd in de Apache-2.0-licentie, een dubbele licentie hebben zoals hierboven, zonder enige aanvullende voorwaarden of condities.







