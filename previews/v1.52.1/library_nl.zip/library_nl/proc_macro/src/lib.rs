//! Een ondersteunende bibliotheek voor macro-auteurs bij het definiëren van nieuwe macro's.
//!
//! Deze bibliotheek, geleverd door de standaarddistributie, biedt de typen die worden gebruikt in de interfaces van procedureel gedefinieerde macrodefinities zoals functieachtige macro's `#[proc_macro]`, macroattributen `#[proc_macro_attribute]` en aangepaste afleidattributen "#[proc_macro_derive]".
//!
//!
//! Zie [the book] voor meer.
//!
//! [the book]: ../book/ch19-06-macros.html#procedural-macros-for-generating-code-from-attributes
//!
//!

#![stable(feature = "proc_macro_lib", since = "1.15.0")]
#![deny(missing_docs)]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    html_playground_url = "https://play.rust-lang.org/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/",
    test(no_crate_inject, attr(deny(warnings))),
    test(attr(allow(dead_code, deprecated, unused_variables, unused_mut)))
)]
#![feature(rustc_allow_const_fn_unstable)]
#![feature(nll)]
#![feature(staged_api)]
#![feature(const_fn)]
#![feature(const_fn_fn_ptr_basics)]
#![feature(allow_internal_unstable)]
#![feature(decl_macro)]
#![feature(extern_types)]
#![feature(in_band_lifetimes)]
#![feature(negative_impls)]
#![feature(auto_traits)]
#![feature(restricted_std)]
#![feature(rustc_attrs)]
#![feature(min_specialization)]
#![recursion_limit = "256"]

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
pub mod bridge;

mod diagnostic;

#[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
pub use diagnostic::{Diagnostic, Level, MultiSpan};

use std::cmp::Ordering;
use std::ops::{Bound, RangeBounds};
use std::path::PathBuf;
use std::str::FromStr;
use std::{error, fmt, iter, mem};

/// Bepaalt of proc_macro toegankelijk is gemaakt voor het programma dat momenteel wordt uitgevoerd.
///
/// De proc_macro crate is alleen bedoeld voor gebruik binnen de implementatie van procedurele macro's.Alle functies in deze crate panic indien aangeroepen van buiten een procedurele macro, zoals vanuit een build-script of unit-test of gewoon Rust binair bestand.
///
/// Met aandacht voor Rust-bibliotheken die zijn ontworpen om zowel macro-als niet-macro-gebruiksscenario's te ondersteunen, biedt `proc_macro::is_available()` een niet-paniekerige manier om te detecteren of de infrastructuur die nodig is om de API van proc_macro te gebruiken, momenteel beschikbaar is.
/// Geeft true terug als deze wordt aangeroepen vanuit een procedurele macro, false als deze wordt aangeroepen vanuit een ander binair bestand.
///
///
///
///
///
///
///
#[unstable(feature = "proc_macro_is_available", issue = "71436")]
pub fn is_available() -> bool {
    bridge::Bridge::is_available()
}

/// Het hoofdtype dat door deze crate wordt geboden, vertegenwoordigt een abstracte stroom van tokens, of, meer specifiek, een reeks token-bomen.
/// Het type biedt interfaces voor iteratie over die token-bomen en, omgekeerd, het verzamelen van een aantal token-bomen in één stream.
///
///
/// Dit is zowel de invoer als de uitvoer van `#[proc_macro]`-, `#[proc_macro_attribute]`-en `#[proc_macro_derive]`-definities.
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Clone)]
pub struct TokenStream(bridge::client::TokenStream);

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for TokenStream {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for TokenStream {}

/// Fout geretourneerd door `TokenStream::from_str`.
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Debug)]
pub struct LexError {
    _inner: (),
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl fmt::Display for LexError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("cannot parse string into token stream")
    }
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl error::Error for LexError {}

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for LexError {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for LexError {}

impl TokenStream {
    /// Geeft een lege `TokenStream` terug die geen token-bomen bevat.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new() -> TokenStream {
        TokenStream(bridge::client::TokenStream::new())
    }

    /// Controleert of deze `TokenStream` leeg is.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn is_empty(&self) -> bool {
        self.0.is_empty()
    }
}

/// Pogingen om de string in tokens te breken en die tokens in een token-stream te parseren.
/// Kan om een aantal redenen mislukken, bijvoorbeeld als de tekenreeks ongebalanceerde scheidingstekens bevat of tekens die niet in de taal bestaan.
///
/// Alle tokens in de geparseerde stream krijgen `Span::call_site()`-reeksen.
///
/// NOTE: sommige fouten kunnen panics veroorzaken in plaats van `LexError` te retourneren.We behouden ons het recht voor om deze fouten later in `LexError`s te veranderen.
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl FromStr for TokenStream {
    type Err = LexError;

    fn from_str(src: &str) -> Result<TokenStream, LexError> {
        Ok(TokenStream(bridge::client::TokenStream::from_str(src)))
    }
}

// NB, de bridge biedt alleen `to_string`, implementeer `fmt::Display` erop gebaseerd (het omgekeerde van de gebruikelijke relatie tussen de twee).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenStream {
    fn to_string(&self) -> String {
        self.0.to_string()
    }
}

/// Drukt de token-stream af als een string die zonder verlies terug converteerbaar zou moeten zijn naar dezelfde token-stream (modulo-spans), behalve mogelijk voor `TokenTree: : Group`s met `Delimiter::None`-scheidingstekens en negatieve numerieke literals.
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Display for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// Drukt token af in een vorm die handig is voor foutopsporing.
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Debug for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("TokenStream ")?;
        f.debug_list().entries(self.clone()).finish()
    }
}

#[stable(feature = "proc_macro_token_stream_default", since = "1.45.0")]
impl Default for TokenStream {
    fn default() -> Self {
        TokenStream::new()
    }
}

#[unstable(feature = "proc_macro_quote", issue = "54722")]
pub use quote::{quote, quote_span};

/// Maakt een token-stream met een enkele token-structuur.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<TokenTree> for TokenStream {
    fn from(tree: TokenTree) -> TokenStream {
        TokenStream(bridge::client::TokenStream::from_token_tree(match tree {
            TokenTree::Group(tt) => bridge::TokenTree::Group(tt.0),
            TokenTree::Punct(tt) => bridge::TokenTree::Punct(tt.0),
            TokenTree::Ident(tt) => bridge::TokenTree::Ident(tt.0),
            TokenTree::Literal(tt) => bridge::TokenTree::Literal(tt.0),
        }))
    }
}

/// Verzamelt een aantal token-bomen in een enkele stroom.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl iter::FromIterator<TokenTree> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenTree>>(trees: I) -> Self {
        trees.into_iter().map(TokenStream::from).collect()
    }
}

/// Een "flattening"-bewerking op token-streams verzamelt token-bomen van meerdere token-streams in een enkele stream.
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl iter::FromIterator<TokenStream> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenStream>>(streams: I) -> Self {
        let mut builder = bridge::client::TokenStreamBuilder::new();
        streams.into_iter().for_each(|stream| builder.push(stream.0));
        TokenStream(builder.build())
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenTree> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenTree>>(&mut self, trees: I) {
        self.extend(trees.into_iter().map(TokenStream::from));
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenStream> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenStream>>(&mut self, streams: I) {
        // FIXME(eddyb) Gebruik een geoptimaliseerde implementatie if/when mogelijk.
        *self = iter::once(mem::replace(self, Self::new())).chain(streams).collect();
    }
}

/// Openbare implementatiedetails voor het `TokenStream`-type, zoals iterators.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub mod token_stream {
    use crate::{bridge, Group, Ident, Literal, Punct, TokenStream, TokenTree};

    /// Een iterator over `TokenStream`'s`TokenTree`s.
    /// De iteratie is "shallow", bijv. De iterator herziet niet in gescheiden groepen, en retourneert hele groepen als token-bomen.
    ///
    #[derive(Clone)]
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub struct IntoIter(bridge::client::TokenStreamIter);

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl Iterator for IntoIter {
        type Item = TokenTree;

        fn next(&mut self) -> Option<TokenTree> {
            self.0.next().map(|tree| match tree {
                bridge::TokenTree::Group(tt) => TokenTree::Group(Group(tt)),
                bridge::TokenTree::Punct(tt) => TokenTree::Punct(Punct(tt)),
                bridge::TokenTree::Ident(tt) => TokenTree::Ident(Ident(tt)),
                bridge::TokenTree::Literal(tt) => TokenTree::Literal(Literal(tt)),
            })
        }
    }

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl IntoIterator for TokenStream {
        type Item = TokenTree;
        type IntoIter = IntoIter;

        fn into_iter(self) -> IntoIter {
            IntoIter(self.0.into_iter())
        }
    }
}

/// `quote!(..)` accepteert willekeurige tokens en breidt uit naar een `TokenStream` die de invoer beschrijft.
/// `quote!(a + b)` produceert bijvoorbeeld een uitdrukking die, wanneer geëvalueerd, de `TokenStream` `[Ident("a"), Punct('+', Alone), Ident("b")]`.
///
///
/// Zonder aanhalingstekens wordt gedaan met `$`, en werkt door de enkele volgende ident als de niet-geciteerde term te nemen.
/// Gebruik `$$` om `$` zelf te citeren.
#[unstable(feature = "proc_macro_quote", issue = "54722")]
#[allow_internal_unstable(proc_macro_def_site)]
#[rustc_builtin_macro]
pub macro quote($($t:tt)*) {
    /* compiler built-in */
}

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
mod quote;

/// Een regio met broncode, samen met informatie over macro-uitbreiding.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Copy, Clone)]
pub struct Span(bridge::client::Span);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Span {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Span {}

macro_rules! diagnostic_method {
    ($name:ident, $level:expr) => {
        /// Maakt een nieuwe `Diagnostic` met de opgegeven `message` in het bereik `self`.
        ///
        #[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
        pub fn $name<T: Into<String>>(self, message: T) -> Diagnostic {
            Diagnostic::spanned(self, $level, message)
        }
    };
}

impl Span {
    /// Een bereik dat wordt opgelost op de macrodefinitiesite.
    #[unstable(feature = "proc_macro_def_site", issue = "54724")]
    pub fn def_site() -> Span {
        Span(bridge::client::Span::def_site())
    }

    /// Het bereik van de aanroep van de huidige procedurele macro.
    /// Identificatoren die met deze reeks zijn gemaakt, worden omgezet alsof ze rechtstreeks op de macro-oproeplocatie zijn geschreven (hygiëne oproeplocatie) en andere code op de macro-oproeplocatie kan er ook naar verwijzen.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn call_site() -> Span {
        Span(bridge::client::Span::call_site())
    }

    /// Een bereik dat `macro_rules`-hygiëne vertegenwoordigt, en soms wordt opgelost op de macrodefinitie-site (lokale variabelen, labels, `$crate`) en soms op de macro-oproepsite (al het andere).
    ///
    /// De spanlocatie wordt overgenomen van de call-site.
    ///
    #[stable(feature = "proc_macro_mixed_site", since = "1.45.0")]
    pub fn mixed_site() -> Span {
        Span(bridge::client::Span::mixed_site())
    }

    /// Het originele bronbestand waarnaar deze span verwijst.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_file(&self) -> SourceFile {
        SourceFile(self.0.source_file())
    }

    /// De `Span` voor de tokens in de vorige macro-uitbreiding waaruit `self` werd gegenereerd, indien aanwezig.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn parent(&self) -> Option<Span> {
        self.0.parent().map(Span)
    }

    /// De span voor de oorspronkelijke broncode waaruit `self` is gegenereerd.
    /// Als deze `Span` niet is gegenereerd door andere macro-uitbreidingen, is de geretourneerde waarde hetzelfde als `*self`.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source(&self) -> Span {
        Span(self.0.source())
    }

    /// Haalt de startende line/column in het bronbestand voor deze reeks op.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn start(&self) -> LineColumn {
        self.0.start()
    }

    /// Haalt het einde line/column in het bronbestand voor deze reeks.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn end(&self) -> LineColumn {
        self.0.end()
    }

    /// Creëert een nieuwe reeks die `self` en `other` omvat.
    ///
    /// Geeft `None` terug als `self` en `other` uit verschillende bestanden komen.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn join(&self, other: Span) -> Option<Span> {
        self.0.join(other.0).map(Span)
    }

    /// Creëert een nieuwe reeks met dezelfde line/column-informatie als `self`, maar dat lost symbolen op alsof het op `other` was.
    ///
    #[stable(feature = "proc_macro_span_resolved_at", since = "1.45.0")]
    pub fn resolved_at(&self, other: Span) -> Span {
        Span(self.0.resolved_at(other.0))
    }

    /// Maakt een nieuwe reeks met hetzelfde naamomzettingsgedrag als `self` maar met de line/column-informatie van `other`.
    ///
    #[stable(feature = "proc_macro_span_located_at", since = "1.45.0")]
    pub fn located_at(&self, other: Span) -> Span {
        other.resolved_at(*self)
    }

    /// Vergelijkt met overspanningen om te zien of ze gelijk zijn.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn eq(&self, other: &Span) -> bool {
        self.0 == other.0
    }

    /// Retourneert de brontekst achter een span.
    /// Hierdoor blijft de originele broncode behouden, inclusief spaties en opmerkingen.
    /// Het retourneert alleen een resultaat als de span overeenkomt met de echte broncode.
    ///
    /// Note: Het waarneembare resultaat van een macro mag alleen vertrouwen op de tokens en niet op deze brontekst.
    ///
    /// Het resultaat van deze functie is een optimale poging om alleen voor diagnostiek te worden gebruikt.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_text(&self) -> Option<String> {
        self.0.source_text()
    }

    diagnostic_method!(error, Level::Error);
    diagnostic_method!(warning, Level::Warning);
    diagnostic_method!(note, Level::Note);
    diagnostic_method!(help, Level::Help);
}

/// Drukt een bereik af in een vorm die handig is voor foutopsporing.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Span {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// Een lijn-kolompaar dat het begin of einde van een `Span` vertegenwoordigt.
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct LineColumn {
    /// De 1-geïndexeerde regel in het bronbestand waarop de reeks (inclusive) begint of eindigt.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub line: usize,
    /// De 0-geïndexeerde kolom (in UTF-8-tekens) in het bronbestand waarop de reeks (inclusive) begint of eindigt.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub column: usize,
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Send for LineColumn {}
#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Sync for LineColumn {}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Ord for LineColumn {
    fn cmp(&self, other: &Self) -> Ordering {
        self.line.cmp(&other.line).then(self.column.cmp(&other.column))
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialOrd for LineColumn {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

/// Het bronbestand van een bepaalde `Span`.
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Clone)]
pub struct SourceFile(bridge::client::SourceFile);

impl SourceFile {
    /// Haalt het pad naar dit bronbestand op.
    ///
    /// ### Note
    /// Als het codebereik dat aan deze `SourceFile` is gekoppeld, is gegenereerd door een externe macro, deze macro, is dit mogelijk geen echt pad op het bestandssysteem.
    /// Gebruik [`is_real`] om te controleren.
    ///
    /// Merk ook op dat zelfs als `is_real` `true` retourneert, als `--remap-path-prefix` werd doorgegeven op de opdrachtregel, het opgegeven pad mogelijk niet echt geldig is.
    ///
    ///
    /// [`is_real`]: Self::is_real
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn path(&self) -> PathBuf {
        PathBuf::from(self.0.path())
    }

    /// Geeft `true` terug als dit bronbestand een echt bronbestand is, en niet gegenereerd door de uitbreiding van een externe macro.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn is_real(&self) -> bool {
        // Dit is een hack totdat intercrate-reeksen zijn geïmplementeerd en we echte bronbestanden voor reeksen kunnen hebben gegenereerd in externe macro's.
        //
        // https://github.com/rust-lang/rust/pull/43604#issuecomment-333334368
        self.0.is_real()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl fmt::Debug for SourceFile {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("SourceFile")
            .field("path", &self.path())
            .field("is_real", &self.is_real())
            .finish()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialEq for SourceFile {
    fn eq(&self, other: &Self) -> bool {
        self.0.eq(&other.0)
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Eq for SourceFile {}

/// Een enkele token of een afgebakende reeks van token-bomen (bijv. `[1, (), ..]`).
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub enum TokenTree {
    /// Een token-stream omgeven door scheidingstekens tussen haakjes.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Group(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Group),
    /// Een identificator.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Ident(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Ident),
    /// Een enkel leesteken (`+`, `,`, `$`, etc.).
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Punct(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Punct),
    /// Een letterlijk teken (`'a'`), tekenreeks (`"hello"`), nummer (`2.3`), enz.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Literal(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Literal),
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for TokenTree {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for TokenTree {}

impl TokenTree {
    /// Retourneert het bereik van deze boom, delegerend naar de `span`-methode van de ingesloten token of een gescheiden stroom.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        match *self {
            TokenTree::Group(ref t) => t.span(),
            TokenTree::Ident(ref t) => t.span(),
            TokenTree::Punct(ref t) => t.span(),
            TokenTree::Literal(ref t) => t.span(),
        }
    }

    /// Configureert de span voor *alleen deze token*.
    ///
    /// Merk op dat als deze token een `Group` is, deze methode niet het bereik van elk van de interne tokens configureert, dit zal eenvoudig worden gedelegeerd naar de `set_span`-methode van elke variant.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        match *self {
            TokenTree::Group(ref mut t) => t.set_span(span),
            TokenTree::Ident(ref mut t) => t.set_span(span),
            TokenTree::Punct(ref mut t) => t.set_span(span),
            TokenTree::Literal(ref mut t) => t.set_span(span),
        }
    }
}

/// Drukt de token-structuur af in een vorm die handig is voor foutopsporing.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Elk van deze heeft de naam in het struct-type in de afgeleide debug, dus doe geen moeite met een extra indirecte laag
        //
        match *self {
            TokenTree::Group(ref tt) => tt.fmt(f),
            TokenTree::Ident(ref tt) => tt.fmt(f),
            TokenTree::Punct(ref tt) => tt.fmt(f),
            TokenTree::Literal(ref tt) => tt.fmt(f),
        }
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Group> for TokenTree {
    fn from(g: Group) -> TokenTree {
        TokenTree::Group(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Ident> for TokenTree {
    fn from(g: Ident) -> TokenTree {
        TokenTree::Ident(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Punct> for TokenTree {
    fn from(g: Punct) -> TokenTree {
        TokenTree::Punct(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Literal> for TokenTree {
    fn from(g: Literal) -> TokenTree {
        TokenTree::Literal(g)
    }
}

// NB, de bridge biedt alleen `to_string`, implementeer `fmt::Display` erop gebaseerd (het omgekeerde van de gebruikelijke relatie tussen de twee).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenTree {
    fn to_string(&self) -> String {
        match *self {
            TokenTree::Group(ref t) => t.to_string(),
            TokenTree::Ident(ref t) => t.to_string(),
            TokenTree::Punct(ref t) => t.to_string(),
            TokenTree::Literal(ref t) => t.to_string(),
        }
    }
}

/// Drukt de token-boomstructuur af als een string die verliesloos converteerbaar zou moeten zijn naar dezelfde token-boom (modulo-spans), behalve mogelijk voor `TokenTree: : Group`s met `Delimiter::None`-scheidingstekens en negatieve numerieke literalen.
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// Een gescheiden token-stream.
///
/// Een `Group` bevat intern een `TokenStream` die is omgeven door `Delimiter`s.
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Group(bridge::client::Group);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Group {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Group {}

/// Beschrijft hoe een reeks token-bomen wordt afgebakend.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Delimiter {
    /// `( ... )`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Parenthesis,
    /// `{ ... }`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Brace,
    /// `[ ... ]`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Bracket,
    /// `Ø ... Ø`
    /// Een impliciet scheidingsteken, dat bijvoorbeeld kan verschijnen rond tokens afkomstig van een "macro variable" `$var`.
    /// Het is belangrijk om de prioriteiten van de operator te behouden in gevallen zoals `$var * 3` waar `$var` `1 + 2` is.
    /// Impliciete scheidingstekens overleven de roundtrip van een token-stream door een string mogelijk niet.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    None,
}

impl Group {
    /// Maakt een nieuwe `Group` met het opgegeven scheidingsteken en token-stream.
    ///
    /// Deze constructor stelt de span voor deze groep in op `Span::call_site()`.
    /// Om het bereik te wijzigen, kunt u de onderstaande `set_span`-methode gebruiken.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(delimiter: Delimiter, stream: TokenStream) -> Group {
        Group(bridge::client::Group::new(delimiter, stream.0))
    }

    /// Retourneert het scheidingsteken van deze `Group`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn delimiter(&self) -> Delimiter {
        self.0.delimiter()
    }

    /// Retourneert de `TokenStream` van tokens die in deze `Group` zijn gescheiden.
    ///
    /// Merk op dat de geretourneerde token-stream niet het hierboven geretourneerde scheidingsteken bevat.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn stream(&self) -> TokenStream {
        TokenStream(self.0.stream())
    }

    /// Retourneert de span voor de scheidingstekens van deze token-stream, die de hele `Group` omvat.
    ///
    ///
    /// ```text
    /// pub fn span(&self) -> Span {
    ///            ^^^^^^^
    /// ```
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Retourneert de reeks die naar het openingsscheidingsteken van deze groep wijst.
    ///
    /// ```text
    /// pub fn span_open(&self) -> Span {
    ///                 ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_open(&self) -> Span {
        Span(self.0.span_open())
    }

    /// Retourneert de reeks die naar het sluitende scheidingsteken van deze groep wijst.
    ///
    /// ```text
    /// pub fn span_close(&self) -> Span {
    ///                        ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_close(&self) -> Span {
        Span(self.0.span_close())
    }

    /// Configureert het bereik voor de scheidingstekens van deze `Groep ', maar niet de interne tokens.
    ///
    /// Deze methode zal **niet** het bereik instellen van alle interne tokens die door deze groep worden overspannen, maar het zal alleen het bereik van het scheidingsteken tokens instellen op het niveau van de `Group`.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }
}

// NB, de bridge biedt alleen `to_string`, implementeer `fmt::Display` erop gebaseerd (het omgekeerde van de gebruikelijke relatie tussen de twee).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Group {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Drukt de groep af als een string die zonder verlies terug converteerbaar zou moeten zijn naar dezelfde groep (modulo spans), behalve mogelijk `TokenTree: : Group`s met `Delimiter::None` scheidingstekens.
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Group")
            .field("delimiter", &self.delimiter())
            .field("stream", &self.stream())
            .field("span", &self.span())
            .finish()
    }
}

/// Een `Punct` is een enkel leesteken zoals `+`, `-` of `#`.
///
/// Operatoren met meerdere tekens, zoals `+=`, worden weergegeven als twee exemplaren van `Punct`, waarbij verschillende vormen van `Spacing` worden geretourneerd.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub struct Punct(bridge::client::Punct);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Punct {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Punct {}

/// Of een `Punct` onmiddellijk wordt gevolgd door een andere `Punct` of wordt gevolgd door een andere token of witruimte.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Spacing {
    /// `+` is bijvoorbeeld `Alone` in `+ =`, `+ident` of `+()`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Alone,
    /// `+` is bijvoorbeeld `Joint` in `+=` of `'#`.
    /// Bovendien kan `'` met enkele aanhalingstekens worden samengevoegd met ID's om levens `'ident` te vormen.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Joint,
}

impl Punct {
    /// Creëert een nieuwe `Punct` op basis van het gegeven karakter en de spatiëring.
    /// Het `ch`-argument moet een geldig leesteken zijn dat is toegestaan door de taal, anders wordt de functie panic.
    ///
    /// De geretourneerde `Punct` heeft de standaardreeks `Span::call_site()` die verder kan worden geconfigureerd met de onderstaande `set_span`-methode.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(ch: char, spacing: Spacing) -> Punct {
        Punct(bridge::client::Punct::new(ch, spacing))
    }

    /// Retourneert de waarde van dit leesteken als `char`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn as_char(&self) -> char {
        self.0.as_char()
    }

    /// Retourneert de spatiëring van dit interpunctie-teken en geeft aan of het onmiddellijk wordt gevolgd door een andere `Punct` in de token-stream, zodat ze mogelijk kunnen worden gecombineerd tot een operator met meerdere tekens (`Joint`), of het wordt gevolgd door een andere token of witruimte (`Alone`), dus de operator heeft dat zeker eindigde.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn spacing(&self) -> Spacing {
        self.0.spacing()
    }

    /// Retourneert de reeks voor dit leesteken.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Configureer het bereik voor dit leesteken.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// NB, de bridge biedt alleen `to_string`, implementeer `fmt::Display` erop gebaseerd (het omgekeerde van de gebruikelijke relatie tussen de twee).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Punct {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Drukt het leesteken af als een tekenreeks die zonder verlies moet worden omgezet in hetzelfde teken.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Punct")
            .field("ch", &self.as_char())
            .field("spacing", &self.spacing())
            .field("span", &self.span())
            .finish()
    }
}

#[stable(feature = "proc_macro_punct_eq", since = "1.50.0")]
impl PartialEq<char> for Punct {
    fn eq(&self, rhs: &char) -> bool {
        self.as_char() == *rhs
    }
}

#[stable(feature = "proc_macro_punct_eq_flipped", since = "1.52.0")]
impl PartialEq<Punct> for char {
    fn eq(&self, rhs: &Punct) -> bool {
        *self == rhs.as_char()
    }
}

/// Een identifier (`ident`).
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Ident(bridge::client::Ident);

impl Ident {
    /// Maakt een nieuwe `Ident` met de opgegeven `string` en de opgegeven `span`.
    /// Het `string`-argument moet een geldige identificatie zijn die is toegestaan door de taal (inclusief trefwoorden, bijv. `self` of `fn`).Anders zal de functie panic.
    ///
    /// Merk op dat `span`, momenteel in rustc, de hygiënegegevens configureert voor deze identificatie.
    ///
    /// Vanaf dit moment kiest `Span::call_site()` expliciet voor "call-site"-hygiëne, wat betekent dat ID's die met deze reeks zijn gemaakt, worden opgelost alsof ze rechtstreeks op de locatie van de macro-oproep zijn geschreven, en dat andere code op de macro-oproepsite kan verwijzen naar hen ook.
    ///
    ///
    /// Latere overspanningen, zoals `Span::def_site()`, maken het mogelijk om in te schrijven voor "definition-site"-hygiëne, wat betekent dat ID's die met deze reeks zijn gemaakt, worden omgezet op de locatie van de macrodefinitie en dat andere code op de macro-oproepsite er niet naar kan verwijzen.
    ///
    /// Vanwege het huidige belang van hygiëne vereist deze constructeur, in tegenstelling tot andere tokens, een `Span` bij de constructie.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, false))
    }

    /// Hetzelfde als `Ident::new`, maar creëert een onbewerkte ID (`r#ident`).
    /// Het `string`-argument is een geldige identificatie die is toegestaan door de taal (inclusief trefwoorden, bijv. `fn`).
    /// Sleutelwoorden die bruikbaar zijn in padsegmenten (bijv
    /// `self`, `super`) worden niet ondersteund, en zullen een panic veroorzaken.
    #[stable(feature = "proc_macro_raw_ident", since = "1.47.0")]
    pub fn new_raw(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, true))
    }

    /// Retourneert de reeks van deze `Ident`, die de volledige tekenreeks omvat die wordt geretourneerd door [`to_string`](Self::to_string).
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Configureert het bereik van deze `Ident`, waarbij mogelijk de hygiënecontext wordt gewijzigd.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// NB, de bridge biedt alleen `to_string`, implementeer `fmt::Display` erop gebaseerd (het omgekeerde van de gebruikelijke relatie tussen de twee).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Ident {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Drukt de ID af als een tekenreeks die zonder verlies moet worden geconverteerd naar dezelfde ID.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Ident")
            .field("ident", &self.to_string())
            .field("span", &self.span())
            .finish()
    }
}

/// Een letterlijke tekenreeks (`"hello"`), byte-tekenreeks (`b"hello"`), teken (`'a'`), byteteken (`b'a'`), een geheel getal of een getal met een drijvende komma met of zonder achtervoegsel ('1', `1u8`, `2.3`, `2.3f32`).
///
/// Booleaanse letters zoals `true` en `false` horen hier niet thuis, het zijn `Ident`s.
///
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Literal(bridge::client::Literal);

macro_rules! suffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// Creëert een nieuw achtervoegsel geheel getal met de opgegeven waarde.
        ///
        /// Deze functie maakt een geheel getal zoals `1u32` waarbij de opgegeven gehele waarde het eerste deel van de token is en de integraal aan het einde ook een achtervoegsel krijgt.
        /// Letterlijke tekens die zijn gemaakt op basis van negatieve getallen, overleven mogelijk round-trips door `TokenStream` of strings niet en kunnen worden opgesplitst in twee tokens (`-` en positieve letterlijke waarden).
        ///
        ///
        /// Letterlijke letters die via deze methode zijn gemaakt, hebben standaard de `Span::call_site()`-reeks, die kan worden geconfigureerd met de onderstaande `set_span`-methode.
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::typed_integer(&n.to_string(), stringify!($kind)))
        }
    )*)
}

macro_rules! unsuffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// Creëert een nieuw niet-achtervoegsel letterlijk geheel getal met de opgegeven waarde.
        ///
        /// Deze functie maakt een geheel getal zoals `1` waarbij de opgegeven gehele waarde het eerste deel van de token is.
        /// Er is geen achtervoegsel gespecificeerd op deze token, wat betekent dat aanroepen zoals `Literal::i8_unsuffixed(1)` equivalent zijn aan `Literal::u32_unsuffixed(1)`.
        /// Letterlijke tekens die zijn gemaakt op basis van negatieve getallen, overleven mogelijk niet de rountrips tot en met `TokenStream` of strings en kunnen worden opgesplitst in twee tokens (`-` en positieve letterlijke waarden).
        ///
        ///
        /// Letterlijke letters die via deze methode zijn gemaakt, hebben standaard de `Span::call_site()`-reeks, die kan worden geconfigureerd met de onderstaande `set_span`-methode.
        ///
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::integer(&n.to_string()))
        }
    )*)
}

impl Literal {
    suffixed_int_literals! {
        u8_suffixed => u8,
        u16_suffixed => u16,
        u32_suffixed => u32,
        u64_suffixed => u64,
        u128_suffixed => u128,
        usize_suffixed => usize,
        i8_suffixed => i8,
        i16_suffixed => i16,
        i32_suffixed => i32,
        i64_suffixed => i64,
        i128_suffixed => i128,
        isize_suffixed => isize,
    }

    unsuffixed_int_literals! {
        u8_unsuffixed => u8,
        u16_unsuffixed => u16,
        u32_unsuffixed => u32,
        u64_unsuffixed => u64,
        u128_unsuffixed => u128,
        usize_unsuffixed => usize,
        i8_unsuffixed => i8,
        i16_unsuffixed => i16,
        i32_unsuffixed => i32,
        i64_unsuffixed => i64,
        i128_unsuffixed => i128,
        isize_unsuffixed => isize,
    }

    /// Creëert een nieuwe niet-achtervoegsel drijvende-komma letterlijke.
    ///
    /// Deze constructor is vergelijkbaar met die zoals `Literal::i8_unsuffixed`, waar de waarde van de float rechtstreeks naar de token wordt gestuurd, maar er wordt geen achtervoegsel gebruikt, dus het kan later in de compiler worden afgeleid als een `f64`.
    ///
    /// Letterlijke tekens die zijn gemaakt op basis van negatieve getallen, overleven mogelijk niet de rountrips tot en met `TokenStream` of strings en kunnen worden opgesplitst in twee tokens (`-` en positieve letterlijke waarden).
    ///
    /// # Panics
    ///
    /// Deze functie vereist dat de opgegeven float eindig is, als het bijvoorbeeld oneindig of NaN is, zal deze functie panic zijn.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_unsuffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// Creëert een nieuwe letterlijke suffix met drijvende komma.
    ///
    /// Deze constructor zal een letterlijke zoals `1.0f32` maken waarbij de opgegeven waarde het voorgaande deel van de token is en `f32` het achtervoegsel van de token.
    /// Deze token zal altijd worden afgeleid als een `f32` in de compiler.
    /// Letterlijke tekens die zijn gemaakt op basis van negatieve getallen, overleven mogelijk niet de rountrips tot en met `TokenStream` of strings en kunnen worden opgesplitst in twee tokens (`-` en positieve letterlijke waarden).
    ///
    ///
    /// # Panics
    ///
    /// Deze functie vereist dat de opgegeven float eindig is, als het bijvoorbeeld oneindig of NaN is, zal deze functie panic zijn.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_suffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f32(&n.to_string()))
    }

    /// Creëert een nieuwe niet-achtervoegsel drijvende-komma letterlijke.
    ///
    /// Deze constructor is vergelijkbaar met die zoals `Literal::i8_unsuffixed`, waar de waarde van de float rechtstreeks naar de token wordt gestuurd, maar er wordt geen achtervoegsel gebruikt, dus het kan later in de compiler worden afgeleid als een `f64`.
    ///
    /// Letterlijke tekens die zijn gemaakt op basis van negatieve getallen, overleven mogelijk niet de rountrips tot en met `TokenStream` of strings en kunnen worden opgesplitst in twee tokens (`-` en positieve letterlijke waarden).
    ///
    /// # Panics
    ///
    /// Deze functie vereist dat de opgegeven float eindig is, als het bijvoorbeeld oneindig of NaN is, zal deze functie panic zijn.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_unsuffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// Creëert een nieuwe letterlijke suffix met drijvende komma.
    ///
    /// Deze constructor maakt een letterlijke zoals `1.0f64` waarbij de opgegeven waarde het voorgaande deel van de token is en `f64` het achtervoegsel van de token.
    /// Deze token zal altijd worden afgeleid als een `f64` in de compiler.
    /// Letterlijke tekens die zijn gemaakt op basis van negatieve getallen, overleven mogelijk niet de rountrips tot en met `TokenStream` of strings en kunnen worden opgesplitst in twee tokens (`-` en positieve letterlijke waarden).
    ///
    ///
    /// # Panics
    ///
    /// Deze functie vereist dat de opgegeven float eindig is, als het bijvoorbeeld oneindig of NaN is, zal deze functie panic zijn.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_suffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f64(&n.to_string()))
    }

    /// Letterlijke tekenreeks.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn string(string: &str) -> Literal {
        Literal(bridge::client::Literal::string(string))
    }

    /// Letterlijk karakter.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn character(ch: char) -> Literal {
        Literal(bridge::client::Literal::character(ch))
    }

    /// Letterlijke byte-tekenreeks.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn byte_string(bytes: &[u8]) -> Literal {
        Literal(bridge::client::Literal::byte_string(bytes))
    }

    /// Retourneert de reeks die deze letterlijke waarde omvat.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Configureert het bereik dat is gekoppeld aan deze letterlijke waarde.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }

    /// Retourneert een `Span` die een subset is van `self.span()` die alleen de bronbytes in het bereik `range` bevat.
    /// Retourneert `None` als de mogelijke getrimde reeks buiten de grenzen van `self` valt.
    ///
    // FIXME(SergioBenitez): controleer of het bytebereik begint en eindigt bij een UTF-8-grens van de bron.
    // anders is het waarschijnlijk dat een panic ergens anders zal voorkomen wanneer de brontekst wordt afgedrukt.
    // FIXME(SergioBenitez): er is geen manier voor de gebruiker om te weten waarnaar `self.span()` eigenlijk verwijst, dus deze methode kan momenteel alleen blindelings worden aangeroepen.
    // `to_string()` voor het teken 'c' geeft bijvoorbeeld "'\u{63}'" terug;de gebruiker kan op geen enkele manier weten of de brontekst 'c' was of dat het '\u{63}' was.
    //
    //
    //
    //
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn subspan<R: RangeBounds<usize>>(&self, range: R) -> Option<Span> {
        // HACK(eddyb) iets dat lijkt op `Option::cloned`, maar dan voor `Bound<&T>`.
        fn cloned_bound<T: Clone>(bound: Bound<&T>) -> Bound<T> {
            match bound {
                Bound::Included(x) => Bound::Included(x.clone()),
                Bound::Excluded(x) => Bound::Excluded(x.clone()),
                Bound::Unbounded => Bound::Unbounded,
            }
        }

        self.0.subspan(cloned_bound(range.start_bound()), cloned_bound(range.end_bound())).map(Span)
    }
}

// NB, de bridge biedt alleen `to_string`, implementeer `fmt::Display` erop gebaseerd (het omgekeerde van de gebruikelijke relatie tussen de twee).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Literal {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Drukt de letterlijke waarde af als een tekenreeks die zonder verlies moet worden omgezet in dezelfde letterlijke waarde (behalve mogelijke afronding voor letterlijke waarden met drijvende komma).
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// Bijgehouden toegang tot omgevingsvariabelen.
#[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
pub mod tracked_env {
    use std::env::{self, VarError};
    use std::ffi::OsStr;

    /// Haal een omgevingsvariabele op en voeg deze toe om afhankelijkheidsinformatie op te bouwen.
    /// Build-systeem dat de compiler uitvoert, weet dat de variabele is geopend tijdens het compileren en kan de build opnieuw uitvoeren wanneer de waarde van die variabele verandert.
    ///
    /// Naast het bijhouden van de afhankelijkheid moet deze functie equivalent zijn aan `env::var` uit de standaardbibliotheek, behalve dat het argument UTF-8 moet zijn.
    ///
    #[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
    pub fn var<K: AsRef<OsStr> + AsRef<str>>(key: K) -> Result<String, VarError> {
        let key: &str = key.as_ref();
        let value = env::var(key);
        crate::bridge::client::FreeFunctions::track_env_var(key, value.as_deref().ok());
        value
    }
}