use super::super::*;
use core::num::bignum::Big32x40 as Big;
use core::num::flt2dec::strategy::dragon::*;

#[test]
fn test_mul_pow10() {
    let mut prevpow10 = Big::from_small(1);
    for i in 1..340 {
        let mut curpow10 = Big::from_small(1);
        mul_pow10(&mut curpow10, i);
        assert_eq!(curpow10, *prevpow10.clone().mul_small(10));
        prevpow10 = curpow10;
    }
}

#[test]
fn shortest_sanity_test() {
    f64_shortest_sanity_test(format_shortest);
    f32_shortest_sanity_test(format_shortest);
    more_shortest_sanity_test(format_shortest);
}

#[test]
#[cfg_attr(miri, ignore)] // Miri is te traag
fn exact_sanity_test() {
    // Deze test wordt uitgevoerd waarvan ik alleen kan aannemen dat het een hoekig geval is van de `exp2`-bibliotheekfunctie, gedefinieerd in elke C-runtime die we gebruiken.
    // In VS 2013 had deze functie blijkbaar een bug, aangezien deze test mislukt wanneer deze is gekoppeld, maar met VS 2015 lijkt de bug opgelost omdat de test prima verloopt.
    //
    // De bug lijkt een verschil te zijn in de retourwaarde van `exp2(-1057)`, waar het in VS 2013 een dubbele retourneert met het bitpatroon 0x2 en in VS 2015 0x20000 retourneert.
    //
    //
    // Negeer deze test nu gewoon volledig op MSVC, aangezien deze toch ergens anders wordt getest en we zijn niet erg geïnteresseerd in het testen van de exp2-implementatie van elk platform.
    //
    //
    //
    //
    //
    //
    if !cfg!(target_env = "msvc") {
        f64_exact_sanity_test(format_exact);
    }
    f32_exact_sanity_test(format_exact);
}

#[test]
fn test_to_shortest_str() {
    to_shortest_str_test(format_shortest);
}

#[test]
fn test_to_shortest_exp_str() {
    to_shortest_exp_str_test(format_shortest);
}

#[test]
fn test_to_exact_exp_str() {
    to_exact_exp_str_test(format_exact);
}

#[test]
fn test_to_exact_fixed_str() {
    to_exact_fixed_str_test(format_exact);
}