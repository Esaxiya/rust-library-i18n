use core::intrinsics::discriminant_value;
use core::ops::ControlFlow;

#[test]
fn control_flow_discriminants_match_result() {
    // Dit is geen stabiel oppervlak, maar helpt de `?` goedkoop te houden, zelfs als LLVM er nu niet altijd gebruik van kan maken.
    //
    // (Helaas zijn Resultaat en Optie inconsistent, dus ControlFlow kan niet beide matchen.)

    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Break(3)),
        discriminant_value(&Result::<i32, i32>::Err(3)),
    );
    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Continue(3)),
        discriminant_value(&Result::<i32, i32>::Ok(3)),
    );
}