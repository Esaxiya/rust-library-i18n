use crate::any::type_name;
use crate::fmt;
use crate::intrinsics;
use crate::mem::ManuallyDrop;
use crate::ptr;

/// Een wrapper-type om niet-geïnitialiseerde exemplaren van `T` te construeren.
///
/// # Initialisatie invariant
///
/// De compiler gaat er in het algemeen van uit dat een variabele correct is geïnitialiseerd volgens de vereisten van het type variabele.Een variabele van het referentietype moet bijvoorbeeld uitgelijnd en niet-NULL zijn.
/// Dit is een invariant die *altijd* moet worden gehandhaafd, zelfs in onveilige code.
/// Als gevolg hiervan veroorzaakt het op nul initialiseren van een variabele van het referentietype onmiddellijke [undefined behavior][ub], ongeacht of die referentie ooit wordt gebruikt om toegang te krijgen tot het geheugen:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: &i32 = unsafe { mem::zeroed() }; // ongedefinieerd gedrag!⚠️
/// // De equivalente code met `MaybeUninit<&i32>`:
/// let x: &i32 = unsafe { MaybeUninit::zeroed().assume_init() }; // ongedefinieerd gedrag!⚠️
/// ```
///
/// Dit wordt door de compiler gebruikt voor verschillende optimalisaties, zoals het elimineren van run-time checks en het optimaliseren van de `enum`-layout.
///
/// Evenzo kan volledig niet-geïnitialiseerd geheugen elke inhoud bevatten, terwijl een `bool` altijd `true` of `false` moet zijn.Daarom is het maken van een niet-geïnitialiseerde `bool` ongedefinieerd gedrag:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let b: bool = unsafe { mem::uninitialized() }; // ongedefinieerd gedrag!⚠️
/// // De equivalente code met `MaybeUninit<bool>`:
/// let b: bool = unsafe { MaybeUninit::uninit().assume_init() }; // ongedefinieerd gedrag!⚠️
/// ```
///
/// Bovendien is niet-geïnitialiseerd geheugen speciaal omdat het geen vaste waarde heeft ("fixed" betekent "it won't change without being written to").Het meerdere keren lezen van dezelfde niet-geïnitialiseerde byte kan verschillende resultaten opleveren.
/// Dit maakt het ongedefinieerd gedrag om niet-geïnitialiseerde gegevens in een variabele te hebben, zelfs als die variabele een integer-type heeft, dat anders elk *vast* bitpatroon kan bevatten:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: i32 = unsafe { mem::uninitialized() }; // ongedefinieerd gedrag!⚠️
/// // De equivalente code met `MaybeUninit<i32>`:
/// let x: i32 = unsafe { MaybeUninit::uninit().assume_init() }; // ongedefinieerd gedrag!⚠️
/// ```
/// (Merk op dat de regels rond niet-geïnitialiseerde gehele getallen nog niet definitief zijn, maar totdat ze dat zijn, is het raadzaam ze te vermijden.)
///
/// Onthoud bovendien dat de meeste typen aanvullende invarianten hebben die verder gaan dan alleen als geïnitialiseerd worden beschouwd op het typeniveau.
/// Een met `1` geïnitialiseerde [`Vec<T>`] wordt bijvoorbeeld als geïnitialiseerd beschouwd (onder de huidige implementatie; dit vormt geen stabiele garantie) omdat de enige vereiste die de compiler ervan weet, is dat de gegevenspointer niet nul mag zijn.
/// Het maken van zo'n `Vec<T>` veroorzaakt geen *onmiddellijk* ongedefinieerd gedrag, maar zal ongedefinieerd gedrag veroorzaken bij de meest veilige bewerkingen (inclusief het laten vallen ervan).
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
///
/// # Examples
///
/// `MaybeUninit<T>` dient om onveilige code in staat te stellen om te gaan met niet-geïnitialiseerde gegevens.
/// Het is een signaal voor de compiler dat aangeeft dat de gegevens hier *niet* kunnen worden geïnitialiseerd:
///
/// ```rust
/// use std::mem::MaybeUninit;
///
/// // Maak een expliciet niet-geïnitialiseerde referentie.
/// // De compiler weet dat gegevens in een `MaybeUninit<T>` ongeldig kunnen zijn, en daarom is dit geen UB:
/// let mut x = MaybeUninit::<&i32>::uninit();
/// // Stel het in op een geldige waarde.
/// unsafe { x.as_mut_ptr().write(&0); }
/// // Extraheer de geïnitialiseerde gegevens-dit is alleen toegestaan *nadat*`x` correct is geïnitialiseerd!
/////
/// let x = unsafe { x.assume_init() };
/// ```
///
/// De compiler weet dan geen verkeerde aannames of optimalisaties te doen op deze code.
///
/// U kunt `MaybeUninit<T>` beschouwen als een beetje zoals `Option<T>`, maar zonder enige runtime-tracking en zonder enige veiligheidscontrole.
///
/// ## out-pointers
///
/// U kunt `MaybeUninit<T>` gebruiken om "out-pointers" te implementeren: in plaats van gegevens van een functie te retourneren, geeft u het een pointer door aan een (uninitialized)-geheugen om het resultaat in te plaatsen.
/// Dit kan handig zijn als het voor de beller belangrijk is om te bepalen hoe het geheugen waarin het resultaat is opgeslagen, wordt toegewezen en u onnodige verplaatsingen wilt vermijden.
///
/// ```
/// use std::mem::MaybeUninit;
///
/// unsafe fn make_vec(out: *mut Vec<i32>) {
///     // `write` laat de oude inhoud niet vallen, wat belangrijk is.
///     out.write(vec![1, 2, 3]);
/// }
///
/// let mut v = MaybeUninit::uninit();
/// unsafe { make_vec(v.as_mut_ptr()); }
/// // Nu weten we dat `v` is geïnitialiseerd!Dit zorgt er ook voor dat de vector correct valt.
/////
/// let v = unsafe { v.assume_init() };
/// assert_eq!(&v, &[1, 2, 3]);
/// ```
///
/// ## Een array element voor element initialiseren
///
/// `MaybeUninit<T>` kan worden gebruikt om een groot array element voor element te initialiseren:
///
/// ```
/// use std::mem::{self, MaybeUninit};
///
/// let data = {
///     // Maak een niet-geïnitialiseerde array van `MaybeUninit`.
///     // De `assume_init` is veilig omdat het type waarvan we beweren dat het hier geïnitialiseerd is een hoop `MisschienUninit`s is, die geen initialisatie vereisen.
/////
///     let mut data: [MaybeUninit<Vec<u32>>; 1000] = unsafe {
///         MaybeUninit::uninit().assume_init()
///     };
///
///     // Het laten vallen van een `MaybeUninit` doet niets.
///     // Het gebruik van onbewerkte pointertoewijzing in plaats van `ptr::write` leidt er niet toe dat de oude niet-geïnitialiseerde waarde wordt verwijderd.
/////
///     // Ook als er een panic is tijdens deze lus, hebben we een geheugenlek, maar er is geen probleem met de geheugenveiligheid.
/////
///     for elem in &mut data[..] {
///         *elem = MaybeUninit::new(vec![42]);
///     }
///
///     // Alles is geïnitialiseerd.
///     // Transmuteer de array naar het geïnitialiseerde type.
///     unsafe { mem::transmute::<_, [Vec<u32>; 1000]>(data) }
/// };
///
/// assert_eq!(&data[0], &[42]);
/// ```
///
/// U kunt ook werken met gedeeltelijk geïnitialiseerde arrays, die u kunt vinden in datastructuren op laag niveau.
///
/// ```
/// use std::mem::MaybeUninit;
/// use std::ptr;
///
/// // Maak een niet-geïnitialiseerde array van `MaybeUninit`.
/// // De `assume_init` is veilig omdat het type waarvan we beweren dat het hier geïnitialiseerd is een hoop `MisschienUninit`s is, die geen initialisatie vereisen.
/////
/// let mut data: [MaybeUninit<String>; 1000] = unsafe { MaybeUninit::uninit().assume_init() };
/// // Tel het aantal elementen dat we hebben toegewezen.
/// let mut data_len: usize = 0;
///
/// for elem in &mut data[0..500] {
///     *elem = MaybeUninit::new(String::from("hello"));
///     data_len += 1;
/// }
///
/// // Laat voor elk item in de array vallen als we het hebben toegewezen.
/// for elem in &mut data[0..data_len] {
///     unsafe { ptr::drop_in_place(elem.as_mut_ptr()); }
/// }
/// ```
///
/// ## Een structuur veld voor veld initialiseren
///
/// U kunt `MaybeUninit<T>` en de [`std::ptr::addr_of_mut`]-macro gebruiken om structs veld voor veld te initialiseren:
///
/// ```rust
/// use std::mem::MaybeUninit;
/// use std::ptr::addr_of_mut;
///
/// #[derive(Debug, PartialEq)]
/// pub struct Foo {
///     name: String,
///     list: Vec<u8>,
/// }
///
/// let foo = {
///     let mut uninit: MaybeUninit<Foo> = MaybeUninit::uninit();
///     let ptr = uninit.as_mut_ptr();
///
///     // Initialiseren van het `name`-veld
///     unsafe { addr_of_mut!((*ptr).name).write("Bob".to_string()); }
///
///     // Initialiseren van het `list`-veld Als hier een panic is, dan lekt de `String` in het `name`-veld.
/////
///     unsafe { addr_of_mut!((*ptr).list).write(vec![0, 1, 2]); }
///
///     // Alle velden zijn geïnitialiseerd, dus we bellen `assume_init` om een geïnitialiseerde Foo te krijgen.
///     unsafe { uninit.assume_init() }
/// };
///
/// assert_eq!(
///     foo,
///     Foo {
///         name: "Bob".to_string(),
///         list: vec![0, 1, 2]
///     }
/// );
/// ```
/// [`std::ptr::addr_of_mut`]: crate::ptr::addr_of_mut
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Layout
///
/// `MaybeUninit<T>` heeft gegarandeerd dezelfde grootte, uitlijning en ABI als `T`:
///
/// ```rust
/// use std::mem::{MaybeUninit, size_of, align_of};
/// assert_eq!(size_of::<MaybeUninit<u64>>(), size_of::<u64>());
/// assert_eq!(align_of::<MaybeUninit<u64>>(), align_of::<u64>());
/// ```
///
/// Onthoud echter dat een type *met* een `MaybeUninit<T>` niet noodzakelijk dezelfde lay-out heeft;Rust garandeert in het algemeen niet dat de velden van een `Foo<T>` dezelfde volgorde hebben als een `Foo<U>`, zelfs als `T` en `U` dezelfde grootte en uitlijning hebben.
///
/// Bovendien, omdat elke bitwaarde geldig is voor een `MaybeUninit<T>`, kan de compiler geen non-zero/niche-filling-optimalisaties toepassen, wat mogelijk resulteert in een grotere omvang:
///
/// ```rust
/// # use std::mem::{MaybeUninit, size_of};
/// assert_eq!(size_of::<Option<bool>>(), 1);
/// assert_eq!(size_of::<Option<MaybeUninit<bool>>>(), 2);
/// ```
///
/// Als `T` FFI-veilig is, dan is `MaybeUninit<T>` dat ook.
///
/// Hoewel `MaybeUninit` `#[repr(transparent)]` is (wat aangeeft dat het dezelfde grootte, uitlijning en ABI garandeert als `T`), verandert dit *geen* enkele van de vorige voorbehouden.
/// `Option<T>` en `Option<MaybeUninit<T>>` kunnen nog steeds verschillende grootten hebben, en typen die een veld van het type `T` bevatten, kunnen anders ingedeeld (en groot) zijn dan wanneer dat veld `MaybeUninit<T>` zou zijn.
/// `MaybeUninit` is een vakbondstype en `#[repr(transparent)]` op vakbonden is onstabiel (zie [the tracking issue](https://github.com/rust-lang/rust/issues/60405)).
/// Na verloop van tijd kunnen de exacte garanties van `#[repr(transparent)]` op vakbonden evolueren, en `MaybeUninit` kan wel of niet `#[repr(transparent)]` blijven.
/// Dat gezegd hebbende, zal `MaybeUninit<T>`*altijd* garanderen dat het dezelfde grootte, uitlijning en ABI heeft als `T`;het is gewoon dat de manier waarop `MaybeUninit` die garantie implementeert, kan evolueren.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "maybe_uninit", since = "1.36.0")]
// Lang item, zodat we er andere soorten in kunnen verpakken.Dit is handig voor generatoren.
#[lang = "maybe_uninit"]
#[derive(Copy)]
#[repr(transparent)]
pub union MaybeUninit<T> {
    uninit: (),
    value: ManuallyDrop<T>,
}

#[stable(feature = "maybe_uninit", since = "1.36.0")]
impl<T: Copy> Clone for MaybeUninit<T> {
    #[inline(always)]
    fn clone(&self) -> Self {
        // `T::clone()` niet bellen, we kunnen niet weten of we daarvoor voldoende geïnitialiseerd zijn.
        *self
    }
}

#[stable(feature = "maybe_uninit_debug", since = "1.41.0")]
impl<T> fmt::Debug for MaybeUninit<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad(type_name::<Self>())
    }
}

impl<T> MaybeUninit<T> {
    /// Maakt een nieuwe `MaybeUninit<T>` die is geïnitialiseerd met de opgegeven waarde.
    /// Het is veilig om [`assume_init`] aan te roepen voor de retourwaarde van deze functie.
    ///
    /// Merk op dat het droppen van een `MaybeUninit<T>` nooit de 'T'-dropcode zal oproepen.
    /// Het is uw eigen verantwoordelijkheid om ervoor te zorgen dat `T` wordt verwijderd als deze wordt geïnitialiseerd.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<Vec<u8>> = MaybeUninit::new(vec![42]);
    /// ```
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(val: T) -> MaybeUninit<T> {
        MaybeUninit { value: ManuallyDrop::new(val) }
    }

    /// Maakt een nieuwe `MaybeUninit<T>` in een niet-geïnitialiseerde staat.
    ///
    /// Merk op dat het droppen van een `MaybeUninit<T>` nooit de 'T'-dropcode zal oproepen.
    /// Het is uw eigen verantwoordelijkheid om ervoor te zorgen dat `T` wordt verwijderd als deze wordt geïnitialiseerd.
    ///
    /// Zie de [type-level documentation][MaybeUninit] voor enkele voorbeelden.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<String> = MaybeUninit::uninit();
    /// ```
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    #[rustc_diagnostic_item = "maybe_uninit_uninit"]
    pub const fn uninit() -> MaybeUninit<T> {
        MaybeUninit { uninit: () }
    }

    /// Maak een nieuwe array van `MaybeUninit<T>`-items, in een niet-geïnitialiseerde staat.
    ///
    /// Note: in een future Rust-versie kan deze methode overbodig worden als de letterlijke syntaxis van de array [repeating const expressions](https://github.com/rust-lang/rust/issues/49147) toestaat.
    ///
    /// Het onderstaande voorbeeld zou dan `let mut buf = [MaybeUninit::<u8>::uninit(); 32];` kunnen gebruiken.
    ///
    /// # Examples
    ///
    /// ```no_run
    /// #![feature(maybe_uninit_uninit_array, maybe_uninit_extra, maybe_uninit_slice)]
    ///
    /// use std::mem::MaybeUninit;
    ///
    /// extern "C" {
    ///     fn read_into_buffer(ptr: *mut u8, max_len: usize) -> usize;
    /// }
    ///
    /// /// Retourneert een (mogelijk kleiner) gegevensdeel dat daadwerkelijk is gelezen
    /// fn read(buf: &mut [MaybeUninit<u8>]) -> &[u8] {
    ///     unsafe {
    ///         let len = read_into_buffer(buf.as_mut_ptr() as *mut u8, buf.len());
    ///         MaybeUninit::slice_assume_init_ref(&buf[..len])
    ///     }
    /// }
    ///
    /// let mut buf: [MaybeUninit<u8>; 32] = MaybeUninit::uninit_array();
    /// let data = read(&mut buf);
    /// ```
    ///
    #[unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[rustc_const_unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[inline(always)]
    pub const fn uninit_array<const LEN: usize>() -> [Self; LEN] {
        // VEILIGHEID: een niet-geïnitialiseerde `[MaybeUninit<_>; LEN]` is geldig.
        unsafe { MaybeUninit::<[MaybeUninit<T>; LEN]>::uninit().assume_init() }
    }

    /// Maakt een nieuwe `MaybeUninit<T>` in een niet-geïnitialiseerde staat, waarbij het geheugen wordt gevuld met `0` bytes.Het hangt van `T` af of dat al zorgt voor een goede initialisatie.
    ///
    /// `MaybeUninit<usize>::zeroed()` is bijvoorbeeld geïnitialiseerd, maar `MaybeUninit<&'static i32>::zeroed()` niet omdat verwijzingen niet null mogen zijn.
    ///
    /// Merk op dat het droppen van een `MaybeUninit<T>` nooit de 'T'-dropcode zal oproepen.
    /// Het is uw eigen verantwoordelijkheid om ervoor te zorgen dat `T` wordt verwijderd als deze wordt geïnitialiseerd.
    ///
    /// # Example
    ///
    /// Correct gebruik van deze functie: initialiseren van een struct met nul, waarbij alle velden van de struct het bitpatroon 0 als een geldige waarde kunnen bevatten.
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<(u8, bool)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// assert_eq!(x, (0, false));
    /// ```
    ///
    /// *Onjuist* gebruik van deze functie: `x.zeroed().assume_init()` aanroepen wanneer `0` geen geldig bitpatroon is voor het type:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// enum NotZero { One = 1, Two = 2 }
    ///
    /// let x = MaybeUninit::<(u8, NotZero)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// // Binnen een paar creëren we een `NotZero` die geen geldige discriminant heeft.
    /// // Dit is ongedefinieerd gedrag.⚠️
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[inline]
    #[rustc_diagnostic_item = "maybe_uninit_zeroed"]
    pub fn zeroed() -> MaybeUninit<T> {
        let mut u = MaybeUninit::<T>::uninit();
        // VEILIGHEID: `u.as_mut_ptr()` verwijst naar toegewezen geheugen.
        unsafe {
            u.as_mut_ptr().write_bytes(0u8, 1);
        }
        u
    }

    /// Stelt de waarde van de `MaybeUninit<T>` in.
    /// Dit overschrijft elke eerdere waarde zonder deze te laten vallen, dus pas op dat u deze niet twee keer gebruikt, tenzij u het uitvoeren van de destructor wilt overslaan.
    ///
    /// Voor uw gemak retourneert dit ook een veranderlijke verwijzing naar de (nu veilig geïnitialiseerde) inhoud van `self`.
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const fn write(&mut self, val: T) -> &mut T {
        *self = MaybeUninit::new(val);
        // VEILIGHEID: We hebben zojuist deze waarde geïnitialiseerd.
        unsafe { self.assume_init_mut() }
    }

    /// Haalt een pointer naar de ingesloten waarde.
    /// Het lezen van deze aanwijzer of het veranderen in een referentie is ongedefinieerd gedrag, tenzij de `MaybeUninit<T>` is geïnitialiseerd.
    /// Het schrijven naar het geheugen waarnaar deze pointer (non-transitively) verwijst, is ongedefinieerd gedrag (behalve binnen een `UnsafeCell<T>`).
    ///
    /// # Examples
    ///
    /// Correct gebruik van deze methode:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // Maak een verwijzing naar de `MaybeUninit<T>`.Dit is oké, want we hebben het geïnitialiseerd.
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// assert_eq!(x_vec.len(), 3);
    /// ```
    ///
    /// *Onjuist* gebruik van deze methode:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// // We hebben een verwijzing gemaakt naar een niet-geïnitialiseerde vector!Dit is ongedefinieerd gedrag.⚠️
    /// ```
    ///
    /// (Merk op dat de regels rond verwijzingen naar niet-geïnitialiseerde gegevens nog niet definitief zijn, maar totdat ze dat wel zijn, is het raadzaam ze te vermijden.)
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_ptr(&self) -> *const T {
        // `MaybeUninit` en `ManuallyDrop` zijn beide `repr(transparent)`, dus we kunnen de aanwijzer werpen.
        self as *const _ as *const T
    }

    /// Haalt een veranderlijke pointer naar de ingesloten waarde.
    /// Het lezen van deze aanwijzer of het veranderen in een referentie is ongedefinieerd gedrag, tenzij de `MaybeUninit<T>` is geïnitialiseerd.
    ///
    /// # Examples
    ///
    /// Correct gebruik van deze methode:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // Maak een verwijzing naar de `MaybeUninit<Vec<u32>>`.
    /// // Dit is oké, want we hebben het geïnitialiseerd.
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// x_vec.push(3);
    /// assert_eq!(x_vec.len(), 4);
    /// ```
    ///
    /// *Onjuist* gebruik van deze methode:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// // We hebben een verwijzing gemaakt naar een niet-geïnitialiseerde vector!Dit is ongedefinieerd gedrag.⚠️
    /// ```
    ///
    /// (Merk op dat de regels rond verwijzingen naar niet-geïnitialiseerde gegevens nog niet definitief zijn, maar totdat ze dat wel zijn, is het raadzaam ze te vermijden.)
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        // `MaybeUninit` en `ManuallyDrop` zijn beide `repr(transparent)`, dus we kunnen de aanwijzer werpen.
        self as *mut _ as *mut T
    }

    /// Extraheert de waarde uit de `MaybeUninit<T>`-container.Dit is een geweldige manier om ervoor te zorgen dat de gegevens worden verwijderd, omdat de resulterende `T` onderhevig is aan de gebruikelijke drop-handling.
    ///
    /// # Safety
    ///
    /// Het is aan de beller om te garanderen dat de `MaybeUninit<T>` werkelijk in een geïnitialiseerde staat verkeert.Dit aanroepen wanneer de inhoud nog niet volledig is geïnitialiseerd, veroorzaakt onmiddellijk ongedefinieerd gedrag.
    /// De [type-level documentation][inv] bevat meer informatie over deze initialisatie-invariant.
    ///
    /// [inv]: #initialization-invariant
    ///
    /// Onthoud bovendien dat de meeste typen aanvullende invarianten hebben die verder gaan dan alleen als geïnitialiseerd worden beschouwd op het typeniveau.
    /// Een met `1` geïnitialiseerde [`Vec<T>`] wordt bijvoorbeeld als geïnitialiseerd beschouwd (onder de huidige implementatie; dit vormt geen stabiele garantie) omdat de enige vereiste die de compiler ervan weet, is dat de gegevenspointer niet nul mag zijn.
    ///
    /// Het maken van zo'n `Vec<T>` veroorzaakt geen *onmiddellijk* ongedefinieerd gedrag, maar zal ongedefinieerd gedrag veroorzaken bij de meest veilige bewerkingen (inclusief het laten vallen ervan).
    ///
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    /// # Examples
    ///
    /// Correct gebruik van deze methode:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<bool>::uninit();
    /// unsafe { x.as_mut_ptr().write(true); }
    /// let x_init = unsafe { x.assume_init() };
    /// assert_eq!(x_init, true);
    /// ```
    ///
    /// *Onjuist* gebruik van deze methode:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_init = unsafe { x.assume_init() };
    /// // `x` was nog niet geïnitialiseerd, dus deze laatste regel veroorzaakte ongedefinieerd gedrag.⚠️
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    #[rustc_diagnostic_item = "assume_init"]
    pub const unsafe fn assume_init(self) -> T {
        // VEILIGHEID: de beller moet garanderen dat `self` is geïnitialiseerd.
        // Dit betekent ook dat `self` een `value`-variant moet zijn.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            ManuallyDrop::into_inner(self.value)
        }
    }

    /// Leest de waarde uit de `MaybeUninit<T>`-container.De resulterende `T` is onderhevig aan de gebruikelijke drop-handling.
    ///
    /// Waar mogelijk verdient het de voorkeur om in plaats daarvan [`assume_init`] te gebruiken, waardoor de inhoud van de `MaybeUninit<T>` niet wordt gedupliceerd.
    ///
    /// # Safety
    ///
    /// Het is aan de beller om te garanderen dat de `MaybeUninit<T>` werkelijk in een geïnitialiseerde staat verkeert.Dit aanroepen wanneer de inhoud nog niet volledig is geïnitialiseerd, veroorzaakt ongedefinieerd gedrag.
    /// De [type-level documentation][inv] bevat meer informatie over deze initialisatie-invariant.
    ///
    /// Bovendien laat dit een kopie van dezelfde gegevens achter in de `MaybeUninit<T>`.
    /// Wanneer u meerdere kopieën van de gegevens gebruikt (door `assume_init_read` meerdere keren te bellen, of eerst `assume_init_read` en vervolgens [`assume_init`] aan te roepen), is het uw verantwoordelijkheid om ervoor te zorgen dat die gegevens inderdaad worden gedupliceerd.
    ///
    ///
    /// [inv]: #initialization-invariant
    /// [`assume_init`]: MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// Correct gebruik van deze methode:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<u32>::uninit();
    /// x.write(13);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // `u32` is `Copy`, dus we kunnen meerdere keren lezen.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(None);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // Het dupliceren van een `None`-waarde is oké, dus het kan zijn dat we meerdere keren lezen.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    /// ```
    ///
    /// *Onjuist* gebruik van deze methode:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(Some(vec![0, 1, 2]));
    /// let x1 = unsafe { x.assume_init_read() };
    /// let x2 = unsafe { x.assume_init_read() };
    /// // We hebben nu twee exemplaren van dezelfde vector gemaakt, wat leidt tot een dubbelvrije ⚠️ wanneer ze allebei worden verwijderd!
    /////
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const unsafe fn assume_init_read(&self) -> T {
        // VEILIGHEID: de beller moet garanderen dat `self` is geïnitialiseerd.
        // Lezen van `self.as_ptr()` is veilig aangezien `self` moet worden geïnitialiseerd.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            self.as_ptr().read()
        }
    }

    /// Laat de ingesloten waarde vallen.
    ///
    /// Als u eigenaar bent van de `MaybeUninit`, kunt u in plaats daarvan [`assume_init`] gebruiken.
    ///
    /// # Safety
    ///
    /// Het is aan de beller om te garanderen dat de `MaybeUninit<T>` werkelijk in een geïnitialiseerde staat verkeert.Dit aanroepen wanneer de inhoud nog niet volledig is geïnitialiseerd, veroorzaakt ongedefinieerd gedrag.
    ///
    /// Bovendien moet aan alle aanvullende invarianten van het type `T` worden voldaan, aangezien de `Drop`-implementatie van `T` (of zijn leden) hierop kan vertrouwen.
    /// Een met `1` geïnitialiseerde [`Vec<T>`] wordt bijvoorbeeld als geïnitialiseerd beschouwd (onder de huidige implementatie; dit vormt geen stabiele garantie) omdat de enige vereiste die de compiler ervan weet, is dat de gegevenspointer niet nul mag zijn.
    ///
    /// Het laten vallen van zo'n `Vec<T>` zal echter ongedefinieerd gedrag veroorzaken.
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    pub unsafe fn assume_init_drop(&mut self) {
        // VEILIGHEID: de beller moet garanderen dat `self` is geïnitialiseerd en
        // voldoet aan alle invarianten van `T`.
        // Als dat het geval is, is het veilig om de waarde op zijn plaats te laten vallen.
        unsafe { ptr::drop_in_place(self.as_mut_ptr()) }
    }

    /// Haalt een gedeelde verwijzing naar de ingesloten waarde op.
    ///
    /// Dit kan handig zijn als we toegang willen krijgen tot een `MaybeUninit` die is geïnitialiseerd maar geen eigenaar zijn van de `MaybeUninit` (waardoor het gebruik van `.assume_init()`).
    ///
    /// # Safety
    ///
    /// Dit aanroepen wanneer de inhoud nog niet volledig is geïnitialiseerd, veroorzaakt ongedefinieerd gedrag: het is aan de beller om te garanderen dat de `MaybeUninit<T>` echt in een geïnitialiseerde staat is.
    ///
    ///
    /// # Examples
    ///
    /// ### Correct gebruik van deze methode:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// // Initialiseer `x`:
    /// unsafe { x.as_mut_ptr().write(vec![1, 2, 3]); }
    /// // Nu bekend is dat onze `MaybeUninit<_>` geïnitialiseerd is, is het oké om er een gedeelde verwijzing naar te maken:
    /////
    /// let x: &Vec<u32> = unsafe {
    ///     // VEILIGHEID: `x` is geïnitialiseerd.
    ///     x.assume_init_ref()
    /// };
    /// assert_eq!(x, &vec![1, 2, 3]);
    /// ```
    ///
    /// ### *Onjuiste* gebruik van deze methode:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec: &Vec<u32> = unsafe { x.assume_init_ref() };
    /// // We hebben een verwijzing gemaakt naar een niet-geïnitialiseerde vector!Dit is ongedefinieerd gedrag.⚠️
    /// ```
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{cell::Cell, mem::MaybeUninit};
    ///
    /// let b = MaybeUninit::<Cell<bool>>::uninit();
    /// // Initialiseer de `MaybeUninit` met `Cell::set`:
    /// unsafe {
    ///     b.assume_init_ref().set(true);
    ///    // ^^^^^^^^^^^^^^^
    ///    // Verwijzing naar een niet-geïnitialiseerde `Cell<bool>`: UB!
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_ref(&self) -> &T {
        // VEILIGHEID: de beller moet garanderen dat `self` is geïnitialiseerd.
        // Dit betekent ook dat `self` een `value`-variant moet zijn.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &*self.as_ptr()
        }
    }

    /// Krijgt een veranderlijke (unique)-verwijzing naar de ingesloten waarde.
    ///
    /// Dit kan handig zijn als we toegang willen krijgen tot een `MaybeUninit` die is geïnitialiseerd maar geen eigenaar zijn van de `MaybeUninit` (waardoor het gebruik van `.assume_init()`).
    ///
    /// # Safety
    ///
    /// Dit aanroepen wanneer de inhoud nog niet volledig is geïnitialiseerd, veroorzaakt ongedefinieerd gedrag: het is aan de beller om te garanderen dat de `MaybeUninit<T>` echt in een geïnitialiseerde staat is.
    /// `.assume_init_mut()` kan bijvoorbeeld niet worden gebruikt om een `MaybeUninit` te initialiseren.
    ///
    /// # Examples
    ///
    /// ### Correct gebruik van deze methode:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// # unsafe extern "C" fn initialize_buffer(buf: *mut [u8; 2048]) { *buf = [0; 2048] }
    /// # #[cfg(FALSE)]
    /// extern "C" {
    ///     /// Initialiseert *alle* bytes van de invoerbuffer.
    ///     fn initialize_buffer(buf: *mut [u8; 2048]);
    /// }
    ///
    /// let mut buf = MaybeUninit::<[u8; 2048]>::uninit();
    ///
    /// // Initialiseer `buf`:
    /// unsafe { initialize_buffer(buf.as_mut_ptr()); }
    /// // Nu weten we dat `buf` is geïnitialiseerd, dus we kunnen het `.assume_init()` gebruiken.
    /// // Het gebruik van `.assume_init()` kan echter een `memcpy` van de 2048 bytes activeren.
    /// // Om te bevestigen dat onze buffer is geïnitialiseerd zonder deze te kopiëren, upgraden we de `&mut MaybeUninit<[u8; 2048]>` naar een `&mut [u8; 2048]`:
    /////
    /// let buf: &mut [u8; 2048] = unsafe {
    ///     // VEILIGHEID: `buf` is geïnitialiseerd.
    ///     buf.assume_init_mut()
    /// };
    ///
    /// // Nu kunnen we `buf` gebruiken als een normale slice:
    /// buf.sort_unstable();
    /// assert!(
    ///     buf.windows(2).all(|pair| pair[0] <= pair[1]),
    ///     "buffer is sorted",
    /// );
    /// ```
    ///
    /// ### *Onjuiste* gebruik van deze methode:
    ///
    /// U kunt `.assume_init_mut()` niet gebruiken om een waarde te initialiseren:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut b = MaybeUninit::<bool>::uninit();
    /// unsafe {
    ///     *b.assume_init_mut() = true;
    ///     // We hebben een (mutable)-verwijzing gemaakt naar een niet-geïnitialiseerde `bool`!
    ///     // Dit is ongedefinieerd gedrag.⚠️
    /// }
    /// ```
    ///
    /// U kunt bijvoorbeeld geen [`Read`] in een niet-geïnitialiseerde buffer plaatsen:
    ///
    /// [`Read`]: https://doc.rust-lang.org/std/io/trait.Read.html
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{io, mem::MaybeUninit};
    ///
    /// fn read_chunk (reader: &'_ mut dyn io::Read) -> io::Result<[u8; 64]>
    /// {
    ///     let mut buffer = MaybeUninit::<[u8; 64]>::uninit();
    ///     reader.read_exact(unsafe { buffer.assume_init_mut() })?;
    ///                             // ^^^^^^^^^^^^^^^^^^^^^^^^
    ///                             // (mutable) verwijzing naar niet-geïnitialiseerd geheugen!
    ///                             // Dit is ongedefinieerd gedrag.
    ///     Ok(unsafe { buffer.assume_init() })
    /// }
    /// ```
    ///
    /// Evenmin kunt u directe veldtoegang gebruiken om veld-voor-veld geleidelijke initialisatie uit te voeren:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{mem::MaybeUninit, ptr};
    ///
    /// struct Foo {
    ///     a: u32,
    ///     b: u8,
    /// }
    ///
    /// let foo: Foo = unsafe {
    ///     let mut foo = MaybeUninit::<Foo>::uninit();
    ///     ptr::write(&mut foo.assume_init_mut().a as *mut u32, 1337);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) verwijzing naar niet-geïnitialiseerd geheugen!
    ///                  // Dit is ongedefinieerd gedrag.
    ///     ptr::write(&mut foo.assume_init_mut().b as *mut u8, 42);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) verwijzing naar niet-geïnitialiseerd geheugen!
    ///                  // Dit is ongedefinieerd gedrag.
    ///     foo.assume_init()
    /// };
    /// ```
    ///
    ///
    ///
    ///
    // FIXME(#76092): We vertrouwen er momenteel op dat het bovenstaande onjuist is, dwz we hebben verwijzingen naar niet-geïnitialiseerde gegevens (bijv. In `libcore/fmt/float.rs`).
    // We moeten een definitieve beslissing nemen over de regels voordat we stabiliseren.
    //
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_mut(&mut self) -> &mut T {
        // VEILIGHEID: de beller moet garanderen dat `self` is geïnitialiseerd.
        // Dit betekent ook dat `self` een `value`-variant moet zijn.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &mut *self.as_mut_ptr()
        }
    }

    /// Extraheert de waarden uit een reeks `MaybeUninit`-containers.
    ///
    /// # Safety
    ///
    /// Het is aan de beller om te garanderen dat alle elementen van de array in een geïnitialiseerde staat verkeren.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_uninit_array)]
    /// #![feature(maybe_uninit_array_assume_init)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut array: [MaybeUninit<i32>; 3] = MaybeUninit::uninit_array();
    /// array[0] = MaybeUninit::new(0);
    /// array[1] = MaybeUninit::new(1);
    /// array[2] = MaybeUninit::new(2);
    ///
    /// // VEILIGHEID: Nu veilig omdat we alle elementen hebben geïnitialiseerd
    /// let array = unsafe {
    ///     MaybeUninit::array_assume_init(array)
    /// };
    ///
    /// assert_eq!(array, [0, 1, 2]);
    /// ```
    #[unstable(feature = "maybe_uninit_array_assume_init", issue = "80908")]
    #[inline(always)]
    pub unsafe fn array_assume_init<const N: usize>(array: [Self; N]) -> [T; N] {
        // SAFETY:
        // * De beller garandeert dat alle elementen van de array worden geïnitialiseerd
        // * `MaybeUninit<T>` en T hebben gegarandeerd dezelfde lay-out
        // * Misschien valt Unint niet weg, dus er zijn geen dubbel-frees. En dus is de conversie veilig
        //
        unsafe {
            intrinsics::assert_inhabited::<[T; N]>();
            (&array as *const _ as *const [T; N]).read()
        }
    }

    /// Ervan uitgaande dat alle elementen zijn geïnitialiseerd, neem er dan een stukje van.
    ///
    /// # Safety
    ///
    /// Het is aan de beller om te garanderen dat de `MaybeUninit<T>`-elementen werkelijk in een geïnitialiseerde staat verkeren.
    ///
    /// Dit aanroepen wanneer de inhoud nog niet volledig is geïnitialiseerd, veroorzaakt ongedefinieerd gedrag.
    ///
    /// Zie [`assume_init_ref`] voor meer details en voorbeelden.
    ///
    /// [`assume_init_ref`]: MaybeUninit::assume_init_ref
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_ref(slice: &[Self]) -> &[T] {
        // VEILIGHEID: het casten van slice naar een `*const [T]` is veilig aangezien de beller dat garandeert
        // `slice` wordt geïnitialiseerd en 'MaybeUninit' heeft gegarandeerd dezelfde lay-out als `T`.
        // De verkregen pointer is geldig omdat deze verwijst naar geheugen dat eigendom is van `slice`, wat een referentie is en dus gegarandeerd geldig is voor lezen.
        //
        unsafe { &*(slice as *const [Self] as *const [T]) }
    }

    /// Ervan uitgaande dat alle elementen zijn geïnitialiseerd, zorg er dan voor dat ze een veranderlijk segment krijgen.
    ///
    /// # Safety
    ///
    /// Het is aan de beller om te garanderen dat de `MaybeUninit<T>`-elementen werkelijk in een geïnitialiseerde staat verkeren.
    ///
    /// Dit aanroepen wanneer de inhoud nog niet volledig is geïnitialiseerd, veroorzaakt ongedefinieerd gedrag.
    ///
    /// Zie [`assume_init_mut`] voor meer details en voorbeelden.
    ///
    /// [`assume_init_mut`]: MaybeUninit::assume_init_mut
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_mut(slice: &mut [Self]) -> &mut [T] {
        // VEILIGHEID: vergelijkbaar met veiligheidsopmerkingen voor `slice_get_ref`, maar we hebben een
        // veranderlijke referentie die ook gegarandeerd geldig is voor schrijven.
        unsafe { &mut *(slice as *mut [Self] as *mut [T]) }
    }

    /// Haalt een pointer naar het eerste element van de array.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_ptr(this: &[MaybeUninit<T>]) -> *const T {
        this.as_ptr() as *const T
    }

    /// Haalt een veranderlijke pointer naar het eerste element van de array.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_mut_ptr(this: &mut [MaybeUninit<T>]) -> *mut T {
        this.as_mut_ptr() as *mut T
    }

    /// Kopieert de elementen van `src` naar `this` en retourneert een veranderlijke verwijzing naar de nu geïnitialiseerde inhoud van `this`.
    ///
    /// Als `T` `Copy` niet implementeert, gebruik dan [`write_slice_cloned`]
    ///
    /// Dit is vergelijkbaar met [`slice::copy_from_slice`].
    ///
    /// # Panics
    ///
    /// Deze functie zal panic zijn als de twee plakjes verschillende lengtes hebben.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(); 32];
    /// let src = [0; 32];
    ///
    /// let init = MaybeUninit::write_slice(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = [0; 16];
    ///
    /// MaybeUninit::write_slice(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // VEILIGHEID: we hebben zojuist alle elementen van len naar de reservecapaciteit gekopieerd
    /// // de eerste src.len()-elementen van de vec zijn nu geldig.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice_cloned`]: MaybeUninit::write_slice_cloned
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Copy,
    {
        // VEILIGHEID: &[T] en&[MisschienUninit<T>] hebben dezelfde lay-out
        let uninit_src: &[MaybeUninit<T>] = unsafe { super::transmute(src) };

        this.copy_from_slice(uninit_src);

        // VEILIGHEID: geldige elementen zijn zojuist naar `this` gekopieerd, dus het is geïnitialiseerd
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }

    /// Kloneert de elementen van `src` naar `this` en retourneert een veranderlijke verwijzing naar de nu geïnitialiseerde inhoud van `this`.
    /// Alle reeds geïnitialiseerde elementen worden niet verwijderd.
    ///
    /// Als `T` `Copy` implementeert, gebruik dan [`write_slice`]
    ///
    /// Dit is vergelijkbaar met [`slice::clone_from_slice`] maar laat bestaande elementen niet vallen.
    ///
    /// # Panics
    ///
    /// Deze functie zal panic zijn als de twee plakjes verschillende lengtes hebben, of als de implementatie van `Clone` panics.
    ///
    /// Als er een panic is, worden de reeds gekloonde elementen verwijderd.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit()];
    /// let src = ["wibbly".to_string(), "wobbly".to_string(), "timey".to_string(), "wimey".to_string(), "stuff".to_string()];
    ///
    /// let init = MaybeUninit::write_slice_cloned(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = ["rust", "is", "a", "pretty", "cool", "language"];
    ///
    /// MaybeUninit::write_slice_cloned(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // VEILIGHEID: we hebben zojuist alle elementen van len gekloond naar de reservecapaciteit
    /// // de eerste src.len()-elementen van de vec zijn nu geldig.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice`]: MaybeUninit::write_slice
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice_cloned<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Clone,
    {
        // in tegenstelling tot copy_from_slice roept dit geen clone_from_slice op de slice aan, dit komt omdat `MaybeUninit<T: Clone>` Clone niet implementeert.
        //

        struct Guard<'a, T> {
            slice: &'a mut [MaybeUninit<T>],
            initialized: usize,
        }

        impl<'a, T> Drop for Guard<'a, T> {
            fn drop(&mut self) {
                let initialized_part = &mut self.slice[..self.initialized];
                // VEILIGHEID: deze onbewerkte plak bevat alleen geïnitialiseerde objecten
                // daarom is het toegestaan om het te laten vallen.
                unsafe {
                    crate::ptr::drop_in_place(MaybeUninit::slice_assume_init_mut(initialized_part));
                }
            }
        }

        assert_eq!(this.len(), src.len(), "destination and source slices have different lengths");
        // NOTE: We moeten ze expliciet op dezelfde lengte snijden
        // om grenzen te controleren die moeten worden weggelaten, en de optimizer genereert memcpy voor eenvoudige gevallen (bijvoorbeeld T= u8).
        //
        let len = this.len();
        let src = &src[..len];

        // bewaking is nodig b/c panic kan gebeuren tijdens een kloon
        let mut guard = Guard { slice: this, initialized: 0 };

        for i in 0..len {
            guard.slice[i].write(src[i].clone());
            guard.initialized += 1;
        }

        super::forget(guard);

        // VEILIGHEID: geldige elementen zijn zojuist in `this` geschreven, dus het is geïnitialiseerd
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }
}