use crate::ops::{Deref, DerefMut};
use crate::ptr;

/// Een wrapper om te voorkomen dat de compiler automatisch de 'T'-destructor aanroept.
/// Deze wrapper kost nihil.
///
/// `ManuallyDrop<T>` is onderhevig aan dezelfde lay-outoptimalisaties als `T`.
/// Als gevolg hiervan heeft het *geen effect* op de aannames die de compiler maakt over de inhoud ervan.
/// Het initialiseren van een `ManuallyDrop<&mut T>` met [`mem::zeroed`] is bijvoorbeeld ongedefinieerd gedrag.
/// Als u niet-geïnitialiseerde gegevens moet verwerken, gebruikt u in plaats daarvan [`MaybeUninit<T>`].
///
/// Merk op dat toegang tot de waarde in een `ManuallyDrop<T>` veilig is.
/// Dit betekent dat een `ManuallyDrop<T>` waarvan de inhoud is verwijderd, niet mag worden blootgesteld via een openbare veilige API.
/// Dienovereenkomstig is `ManuallyDrop::drop` onveilig.
///
/// # `ManuallyDrop` en drop order.
///
/// Rust heeft een goed gedefinieerde [drop order] waarden.
/// Om ervoor te zorgen dat velden of locals in een specifieke volgorde worden neergezet, moet u de declaraties opnieuw ordenen zodat de impliciete drop-order de juiste is.
///
/// Het is mogelijk om `ManuallyDrop` te gebruiken om de drop-order te regelen, maar dit vereist onveilige code en is moeilijk correct te doen in de aanwezigheid van afwikkelen.
///
///
/// Als u er bijvoorbeeld voor wilt zorgen dat een specifiek veld na de andere wordt verwijderd, maakt u dit het laatste veld van een struct:
///
/// ```
/// struct Context;
///
/// struct Widget {
///     children: Vec<Widget>,
///     // `context` wordt verwijderd na `children`.
///     // Rust garandeert dat velden worden weggelaten in de volgorde van aangifte.
///     context: Context,
/// }
/// ```
///
/// [drop order]: https://doc.rust-lang.org/reference/destructors.html
/// [`mem::zeroed`]: crate::mem::zeroed
/// [`MaybeUninit<T>`]: crate::mem::MaybeUninit
///
///
///
///
///
#[stable(feature = "manually_drop", since = "1.20.0")]
#[lang = "manually_drop"]
#[derive(Copy, Clone, Debug, Default, PartialEq, Eq, PartialOrd, Ord, Hash)]
#[repr(transparent)]
pub struct ManuallyDrop<T: ?Sized> {
    value: T,
}

impl<T> ManuallyDrop<T> {
    /// Wikkel een waarde om die handmatig moet worden verwijderd.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let mut x = ManuallyDrop::new(String::from("Hello World!"));
    /// x.truncate(5); // U kunt nog steeds veilig op de waarde werken
    /// assert_eq!(*x, "Hello");
    /// // Maar `Drop` zal hier niet worden uitgevoerd
    /// ```
    #[must_use = "if you don't need the wrapper, you can use `mem::forget` instead"]
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(value: T) -> ManuallyDrop<T> {
        ManuallyDrop { value }
    }

    /// Extraheert de waarde uit de `ManuallyDrop`-container.
    ///
    /// Hierdoor kan de waarde weer worden verwijderd.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let x = ManuallyDrop::new(Box::new(()));
    /// let _: Box<()> = ManuallyDrop::into_inner(x); // Dit laat de `Box` vallen.
    /// ```
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn into_inner(slot: ManuallyDrop<T>) -> T {
        slot.value
    }

    /// Haalt de waarde uit de `ManuallyDrop<T>`-container.
    ///
    /// Deze methode is in de eerste plaats bedoeld om waarden in drop te verplaatsen.
    /// In plaats van [`ManuallyDrop::drop`] te gebruiken om de waarde handmatig te verwijderen, kunt u deze methode gebruiken om de waarde te nemen en deze naar wens te gebruiken.
    ///
    /// Waar mogelijk verdient het de voorkeur om in plaats daarvan [`into_inner`][`ManuallyDrop::into_inner`] te gebruiken, waardoor de inhoud van de `ManuallyDrop<T>` niet wordt gedupliceerd.
    ///
    ///
    /// # Safety
    ///
    /// Deze functie verplaatst semantisch de ingesloten waarde zonder verder gebruik te verhinderen, waardoor de status van deze container ongewijzigd blijft.
    /// Het is uw eigen verantwoordelijkheid om ervoor te zorgen dat deze `ManuallyDrop` niet opnieuw wordt gebruikt.
    ///
    ///
    ///
    #[must_use = "if you don't need the value, you can use `ManuallyDrop::drop` instead"]
    #[stable(feature = "manually_drop_take", since = "1.42.0")]
    #[inline]
    pub unsafe fn take(slot: &mut ManuallyDrop<T>) -> T {
        // VEILIGHEID: we lezen van een referentie, wat gegarandeerd is
        // geldig zijn voor leest.
        unsafe { ptr::read(&slot.value) }
    }
}

impl<T: ?Sized> ManuallyDrop<T> {
    /// Verlaagt handmatig de ingesloten waarde.Dit is exact gelijk aan het aanroepen van [`ptr::drop_in_place`] met een pointer naar de ingesloten waarde.
    /// Als zodanig, tenzij de ingesloten waarde een ingepakte structuur is, wordt de destructor ter plaatse aangeroepen zonder de waarde te verplaatsen en kan deze dus worden gebruikt om [pinned]-gegevens veilig te verwijderen.
    ///
    /// Als u eigenaar bent van de waarde, kunt u in plaats daarvan [`ManuallyDrop::into_inner`] gebruiken.
    ///
    /// # Safety
    ///
    /// Deze functie voert de destructor van de ingesloten waarde uit.
    /// Behalve door de destructor zelf aangebrachte wijzigingen, blijft het geheugen ongewijzigd, en voor zover het de compiler betreft bevat het nog steeds een bitpatroon dat geldig is voor het type `T`.
    ///
    ///
    /// Deze "zombie"-waarde mag echter niet worden blootgesteld aan veilige code en deze functie mag niet meer dan één keer worden aangeroepen.
    /// Een waarde gebruiken nadat deze is verwijderd, of een waarde meerdere keren laten vallen, kan ongedefinieerd gedrag veroorzaken (afhankelijk van wat `drop` doet).
    /// Dit wordt normaal gesproken voorkomen door het typesysteem, maar gebruikers van `ManuallyDrop` moeten die garanties handhaven zonder hulp van de compiler.
    ///
    /// [pinned]: crate::pin
    ///
    ///
    ///
    ///
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[inline]
    pub unsafe fn drop(slot: &mut ManuallyDrop<T>) {
        // VEILIGHEID: we laten de waarde vallen waarnaar wordt verwezen door een veranderlijke referentie
        // die gegarandeerd geldig is voor schrijven.
        // Het is aan de beller om ervoor te zorgen dat `slot` niet opnieuw wordt verbroken.
        unsafe { ptr::drop_in_place(&mut slot.value) }
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> Deref for ManuallyDrop<T> {
    type Target = T;
    #[inline(always)]
    fn deref(&self) -> &T {
        &self.value
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> DerefMut for ManuallyDrop<T> {
    #[inline(always)]
    fn deref_mut(&mut self) -> &mut T {
        &mut self.value
    }
}