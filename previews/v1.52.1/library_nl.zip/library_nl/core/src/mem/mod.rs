//! Basisfuncties voor het omgaan met geheugen.
//!
//! Deze module bevat functies voor het opvragen van de grootte en uitlijning van typen, het initialiseren en manipuleren van geheugen.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::clone;
use crate::cmp;
use crate::fmt;
use crate::hash;
use crate::intrinsics;
use crate::marker::{Copy, DiscriminantKind, Sized};
use crate::ptr;

mod manually_drop;
#[stable(feature = "manually_drop", since = "1.20.0")]
pub use manually_drop::ManuallyDrop;

mod maybe_uninit;
#[stable(feature = "maybe_uninit", since = "1.36.0")]
pub use maybe_uninit::MaybeUninit;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::transmute;

/// Neemt het eigendom over en "forgets" ongeveer de waarde **zonder zijn destructor** uit te voeren.
///
/// Alle bronnen die de waarde beheert, zoals heap-geheugen of een bestandsingang, zullen voor altijd blijven hangen in een onbereikbare staat.Het garandeert echter niet dat verwijzingen naar dit geheugen geldig blijven.
///
/// * Zie [`Box::leak`] als u geheugen wilt lekken.
/// * Zie [`Box::into_raw`] als u een onbewerkte pointer naar het geheugen wilt hebben.
/// * Zie [`mem::drop`] als u een waarde op de juiste manier wilt weggooien door de destructor uit te voeren.
///
/// # Safety
///
/// `forget` is niet gemarkeerd als `unsafe`, omdat de veiligheidsgaranties van Rust geen garantie bieden dat destructors altijd zullen draaien.
/// Een programma kan bijvoorbeeld een referentiecyclus maken met [`Rc`][rc], of [`process::exit`][exit] aanroepen om af te sluiten zonder destructors uit te voeren.
/// Het toestaan van `mem::forget` van veilige code verandert dus niet fundamenteel de veiligheidsgaranties van Rust.
///
/// Dat gezegd hebbende, lekkende bronnen zoals geheugen of I/O-objecten zijn meestal ongewenst.
/// In sommige gespecialiseerde gebruikssituaties komt de behoefte aan FFI of onveilige code naar voren, maar zelfs dan heeft [`ManuallyDrop`] doorgaans de voorkeur.
///
/// Omdat het vergeten van een waarde is toegestaan, moet elke `unsafe`-code die u schrijft deze mogelijkheid toestaan.U kunt geen waarde retourneren en verwachten dat de beller noodzakelijkerwijs de destructor van de waarde zal uitvoeren.
///
/// [rc]: ../../std/rc/struct.Rc.html
/// [exit]: ../../std/process/fn.exit.html
///
/// # Examples
///
/// Het canonieke veilige gebruik van `mem::forget` is het omzeilen van de destructor van een waarde geïmplementeerd door de `Drop` trait.Dit zal bijvoorbeeld een `File` lekken, dwz
/// win de ruimte terug die door de variabele wordt ingenomen, maar sluit nooit de onderliggende systeembronnen:
///
/// ```no_run
/// use std::mem;
/// use std::fs::File;
///
/// let file = File::open("foo.txt").unwrap();
/// mem::forget(file);
/// ```
///
/// Dit is handig wanneer het eigendom van de onderliggende bron eerder werd overgedragen aan code buiten Rust, bijvoorbeeld door de onbewerkte bestandsdescriptor naar C-code te verzenden.
///
/// # Verwantschap met `ManuallyDrop`
///
/// Hoewel `mem::forget` ook kan worden gebruikt om het eigendom van *geheugen* over te dragen, is dit foutgevoelig.
/// [`ManuallyDrop`] moet in plaats daarvan worden gebruikt.Beschouw bijvoorbeeld deze code:
///
/// ```
/// use std::mem;
///
/// let mut v = vec![65, 122];
/// // Bouw een `String` met behulp van de inhoud van `v`
/// let s = unsafe { String::from_raw_parts(v.as_mut_ptr(), v.len(), v.capacity()) };
/// // lek `v` omdat het geheugen nu wordt beheerd door `s`
/// mem::forget(v);  // FOUT, v is ongeldig en mag niet worden doorgegeven aan een functie
/// assert_eq!(s, "Az");
/// // `s` wordt impliciet verwijderd en het geheugen wordt ongedaan gemaakt.
/// ```
///
/// Er zijn twee problemen met het bovenstaande voorbeeld:
///
/// * Als er meer code zou worden toegevoegd tussen de constructie van `String` en het aanroepen van `mem::forget()`, zou een panic erin een dubbele vrijgave veroorzaken omdat hetzelfde geheugen wordt afgehandeld door zowel `v` als `s`.
/// * Nadat `v.as_mut_ptr()` is aangeroepen en het eigendom van de gegevens naar `s` is verzonden, is de `v`-waarde ongeldig.
/// Zelfs als een waarde zojuist naar `mem::forget` is verplaatst (wat deze niet zal inspecteren), stellen sommige typen strikte eisen aan hun waarden waardoor ze ongeldig worden wanneer ze eraan bungelen of niet langer in bezit zijn.
/// Het op enigerlei wijze gebruiken van ongeldige waarden, inclusief het doorgeven aan of terugsturen van functies, vormt ongedefinieerd gedrag en kan de aannames van de compiler breken.
///
/// Door over te schakelen naar `ManuallyDrop` worden beide problemen vermeden:
///
/// ```
/// use std::mem::ManuallyDrop;
///
/// let v = vec![65, 122];
/// // Voordat we de `v` in zijn onbewerkte onderdelen demonteren, moet u ervoor zorgen dat hij niet valt!
/////
/// let mut v = ManuallyDrop::new(v);
/// // Demonteer nu `v`.Deze bewerkingen kunnen niet panic zijn, dus er kan geen lek zijn.
/// let (ptr, len, cap) = (v.as_mut_ptr(), v.len(), v.capacity());
/// // Bouw ten slotte een `String`.
/// let s = unsafe { String::from_raw_parts(ptr, len, cap) };
/// assert_eq!(s, "Az");
/// // `s` wordt impliciet verwijderd en het geheugen wordt ongedaan gemaakt.
/// ```
///
/// `ManuallyDrop` voorkomt robuust dubbel-vrij omdat we de destructor van `v` uitschakelen voordat we iets anders doen.
/// `mem::forget()` staat dit niet toe omdat het zijn argument opslokt en ons dwingt het alleen aan te roepen nadat we alles hebben geëxtraheerd dat we nodig hebben uit `v`.
/// Zelfs als een panic zou worden geïntroduceerd tussen de constructie van `ManuallyDrop` en het bouwen van de string (wat niet kan gebeuren in de code zoals weergegeven), zou dit resulteren in een lek en niet in een dubbele gratis.
/// Met andere woorden, `ManuallyDrop` vergist zich aan de kant van lekken in plaats van aan de kant van (dubbel) vallen.
///
/// `ManuallyDrop` voorkomt ook dat we naar "touch" `v` moeten na het overdragen van het eigendom aan `s`-de laatste stap van interactie met `v` om het te verwijderen zonder de vernietiger uit te voeren, wordt volledig vermeden.
///
///
/// [`Box`]: ../../std/boxed/struct.Box.html
/// [`Box::leak`]: ../../std/boxed/struct.Box.html#method.leak
/// [`Box::into_raw`]: ../../std/boxed/struct.Box.html#method.into_raw
/// [`mem::drop`]: drop
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[rustc_const_stable(feature = "const_forget", since = "1.46.0")]
#[stable(feature = "rust1", since = "1.0.0")]
pub const fn forget<T>(t: T) {
    let _ = ManuallyDrop::new(t);
}

/// Net als [`forget`], maar accepteert ook niet-formaatwaarden.
///
/// Deze functie is slechts een opvulstuk dat moet worden verwijderd wanneer de `unsized_locals`-functie wordt gestabiliseerd.
///
#[inline]
#[unstable(feature = "forget_unsized", issue = "none")]
pub fn forget_unsized<T: ?Sized>(t: T) {
    intrinsics::forget(t)
}

/// Retourneert de grootte van een type in bytes.
///
/// Meer specifiek is dit de offset in bytes tussen opeenvolgende elementen in een array met dat itemtype inclusief uitlijningsvulling.
///
/// Dus voor elk type `T` en lengte `n` heeft `[T; n]` een afmeting van `n * size_of::<T>()`.
///
/// Over het algemeen is de grootte van een type niet stabiel in compilaties, maar specifieke typen, zoals primitieven, zijn dat wel.
///
/// De volgende tabel geeft de grootte voor primitieven.
///
/// Type |De grootte van: :\<Type>()
/// ---- | ---------------
/// () |0 bool |1 u8 |1 u16 |2 u32 |4 u64 |8 u128 |16 i8 |1 i16 |2 i32 |4 i64 |8 i128 |16 f32 |4 f64 |8 tekens |4
///
/// Bovendien hebben `usize` en `isize` dezelfde grootte.
///
/// De typen `*const T`, `&T`, `Box<T>`, `Option<&T>` en `Option<Box<T>>` hebben allemaal dezelfde grootte.
/// Als `T` Sized is, hebben al deze typen dezelfde grootte als `usize`.
///
/// De veranderlijkheid van een aanwijzer verandert de grootte niet.Als zodanig hebben `&T` en `&mut T` dezelfde grootte.
/// Evenzo voor `*const T` en `* mut T`.
///
/// # Grootte van `#[repr(C)]`-items
///
/// De `C`-weergave voor items heeft een gedefinieerde lay-out.
/// Met deze lay-out is de grootte van items ook stabiel, zolang alle velden een stabiele grootte hebben.
///
/// ## Grootte van structuren
///
/// Voor `structs` wordt de grootte bepaald door het volgende algoritme.
///
/// Voor elk veld in de struct geordend op aangiftevolgorde:
///
/// 1. Voeg de grootte van het veld toe.
/// 2. Rond de huidige grootte af naar het dichtstbijzijnde veelvoud van de [alignment] van het volgende veld.
///
/// Rond ten slotte de grootte van de struct af op het dichtstbijzijnde veelvoud van zijn [alignment].
/// De uitlijning van de structuur is meestal de grootste uitlijning van al zijn velden;dit kan worden gewijzigd met het gebruik van `repr(align(N))`.
///
/// In tegenstelling tot `C` worden structs met een grootte van nul niet afgerond op één byte.
///
/// ## Grootte van Enums
///
/// Enums die geen andere gegevens bevatten dan de discriminant, hebben dezelfde grootte als C-enums op het platform waarvoor ze zijn samengesteld.
///
/// ## Grootte van vakbonden
///
/// De grootte van een vakbond is de grootte van het grootste veld.
///
/// In tegenstelling tot `C` worden vakbonden met een grootte van nul niet naar boven afgerond op één byte.
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// // Enkele primitieven
/// assert_eq!(4, mem::size_of::<i32>());
/// assert_eq!(8, mem::size_of::<f64>());
/// assert_eq!(0, mem::size_of::<()>());
///
/// // Sommige arrays
/// assert_eq!(8, mem::size_of::<[i32; 2]>());
/// assert_eq!(12, mem::size_of::<[i32; 3]>());
/// assert_eq!(0, mem::size_of::<[i32; 0]>());
///
///
/// // Gelijkheid van aanwijzergrootte
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<*const i32>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Box<i32>>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Option<&i32>>());
/// assert_eq!(mem::size_of::<Box<i32>>(), mem::size_of::<Option<Box<i32>>>());
/// ```
///
/// `#[repr(C)]` gebruiken.
///
/// ```
/// use std::mem;
///
/// #[repr(C)]
/// struct FieldStruct {
///     first: u8,
///     second: u16,
///     third: u8
/// }
///
/// // De grootte van het eerste veld is 1, dus tel er 1 bij op.Maat is 1.
/// // De uitlijning van het tweede veld is 2, dus tel 1 op bij de maat voor opvulling.Grootte is 2.
/// // De grootte van het tweede veld is 2, dus tel er 2 bij op.Maat is 4.
/// // De uitlijning van het derde veld is 1, dus tel 0 op bij de grootte voor opvulling.Maat is 4.
/// // De grootte van het derde veld is 1, dus tel er 1 bij op.Maat is 5.
/// // Ten slotte is de uitlijning van de structuur 2 (omdat de grootste uitlijning tussen de velden 2 is), dus tel 1 op bij de grootte voor opvulling.
/// // Maat is 6.
/// assert_eq!(6, mem::size_of::<FieldStruct>());
///
/// #[repr(C)]
/// struct TupleStruct(u8, u16, u8);
///
/// // Tuple-structuren volgen dezelfde regels.
/// assert_eq!(6, mem::size_of::<TupleStruct>());
///
/// // Merk op dat het herschikken van de velden de grootte kan verkleinen.
/// // We kunnen beide opvulbytes verwijderen door `third` voor `second` te plaatsen.
/// #[repr(C)]
/// struct FieldStructOptimized {
///     first: u8,
///     third: u8,
///     second: u16
/// }
///
/// assert_eq!(4, mem::size_of::<FieldStructOptimized>());
///
/// // Uniegrootte is de grootte van het grootste veld.
/// #[repr(C)]
/// union ExampleUnion {
///     smaller: u8,
///     larger: u16
/// }
///
/// assert_eq!(2, mem::size_of::<ExampleUnion>());
/// ```
///
/// [alignment]: align_of
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_size_of", since = "1.32.0")]
pub const fn size_of<T>() -> usize {
    intrinsics::size_of::<T>()
}

/// Retourneert de grootte van de aangewezen waarde in bytes.
///
/// Dit is meestal hetzelfde als `size_of::<T>()`.
/// Als `T`*echter* geen statisch bekende grootte heeft, bijvoorbeeld een slice [`[T]`][slice] of een [trait object], dan kan `size_of_val` worden gebruikt om de dynamisch bekende grootte te krijgen.
///
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, mem::size_of_val(y));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
pub const fn size_of_val<T: ?Sized>(val: &T) -> usize {
    // VEILIGHEID: `val` is een referentie, dus het is een geldige onbewerkte pointer
    unsafe { intrinsics::size_of_val(val) }
}

/// Retourneert de grootte van de aangewezen waarde in bytes.
///
/// Dit is meestal hetzelfde als `size_of::<T>()`.Als `T`*echter* geen statisch bekende grootte heeft, bijvoorbeeld een plak [`[T]`][slice] of een [trait object], dan kan `size_of_val_raw` worden gebruikt om de dynamisch bekende grootte te krijgen.
///
/// # Safety
///
/// Deze functie is alleen veilig om te bellen als de volgende voorwaarden gelden:
///
/// - Als `T` `Sized` is, is deze functie altijd veilig om te bellen.
/// - Als de unsized tail van `T` is:
///     - een [slice], dan moet de lengte van de slice-tail een geïnitialiseerd geheel getal zijn en moet de grootte van de *volledige waarde*(dynamische tail-lengte + prefix met statische grootte) passen in `isize`.
///     - een [trait object], dan moet het vtable-gedeelte van de pointer verwijzen naar een geldige vtable die is verkregen door een niet-dimensionale dwang, en de grootte van de *volledige waarde*(dynamische staartlengte + statisch voorvoegsel) moet passen in `isize`.
///
///     - een (unstable) [extern type], dan is deze functie altijd veilig om aan te roepen, maar kan panic of anderszins de verkeerde waarde retourneren, aangezien de lay-out van het externe type niet bekend is.
///     Dit is hetzelfde gedrag als [`size_of_val`] bij een verwijzing naar een type met een extern type staart.
///     - anders is het conservatief niet toegestaan om deze functie aan te roepen.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, unsafe { mem::size_of_val_raw(y) });
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_size_of_val_raw", issue = "46571")]
pub const unsafe fn size_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // VEILIGHEID: de beller moet een geldige onbewerkte pointer opgeven
    unsafe { intrinsics::size_of_val(val) }
}

/// Retourneert de [ABI]-vereiste minimale uitlijning van een type.
///
/// Elke verwijzing naar een waarde van het type `T` moet een veelvoud van dit getal zijn.
///
/// Dit is de uitlijning die wordt gebruikt voor struct-velden.Het kan kleiner zijn dan de uitlijning die de voorkeur heeft.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of::<i32>());
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of` instead", since = "1.2.0")]
pub fn min_align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// Retourneert de [ABI]-vereiste minimale uitlijning van het type waarde waarnaar `val` verwijst.
///
/// Elke verwijzing naar een waarde van het type `T` moet een veelvoud van dit getal zijn.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of_val` instead", since = "1.2.0")]
pub fn min_align_of_val<T: ?Sized>(val: &T) -> usize {
    // VEILIGHEID: val is een referentie, dus het is een geldige onbewerkte pointer
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Retourneert de [ABI]-vereiste minimale uitlijning van een type.
///
/// Elke verwijzing naar een waarde van het type `T` moet een veelvoud van dit getal zijn.
///
/// Dit is de uitlijning die wordt gebruikt voor struct-velden.Het kan kleiner zijn dan de uitlijning die de voorkeur heeft.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of::<i32>());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_align_of", since = "1.32.0")]
pub const fn align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// Retourneert de [ABI]-vereiste minimale uitlijning van het type waarde waarnaar `val` verwijst.
///
/// Elke verwijzing naar een waarde van het type `T` moet een veelvoud van dit getal zijn.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
#[allow(deprecated)]
pub const fn align_of_val<T: ?Sized>(val: &T) -> usize {
    // VEILIGHEID: val is een referentie, dus het is een geldige onbewerkte pointer
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Retourneert de [ABI]-vereiste minimale uitlijning van het type waarde waarnaar `val` verwijst.
///
/// Elke verwijzing naar een waarde van het type `T` moet een veelvoud van dit getal zijn.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Safety
///
/// Deze functie is alleen veilig om te bellen als de volgende voorwaarden gelden:
///
/// - Als `T` `Sized` is, is deze functie altijd veilig om te bellen.
/// - Als de unsized tail van `T` is:
///     - een [slice], dan moet de lengte van de slice-tail een geïnitialiseerd geheel getal zijn en moet de grootte van de *volledige waarde*(dynamische tail-lengte + prefix met statische grootte) passen in `isize`.
///     - een [trait object], dan moet het vtable-gedeelte van de pointer verwijzen naar een geldige vtable die is verkregen door een niet-dimensionale dwang, en de grootte van de *volledige waarde*(dynamische staartlengte + statisch voorvoegsel) moet passen in `isize`.
///
///     - een (unstable) [extern type], dan is deze functie altijd veilig om aan te roepen, maar kan panic of anderszins de verkeerde waarde retourneren, aangezien de lay-out van het externe type niet bekend is.
///     Dit is hetzelfde gedrag als [`align_of_val`] bij een verwijzing naar een type met een extern type staart.
///     - anders is het conservatief niet toegestaan om deze functie aan te roepen.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, unsafe { mem::align_of_val_raw(&5i32) });
/// ```
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_align_of_val_raw", issue = "46571")]
pub const unsafe fn align_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // VEILIGHEID: de beller moet een geldige onbewerkte pointer opgeven
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Geeft `true` terug als het laten vallen van waarden van het type `T` ertoe doet.
///
/// Dit is puur een optimalisatiehint en kan conservatief worden geïmplementeerd:
/// het kan `true` retourneren voor typen die niet echt hoeven te worden verwijderd.
/// Als zodanig zou het altijd retourneren van `true` een geldige implementatie van deze functie zijn.Als deze functie echter `false` retourneert, kunt u er zeker van zijn dat het laten vallen van `T` geen bijwerking heeft.
///
/// Implementaties op laag niveau van zaken als verzamelingen, die hun gegevens handmatig moeten verwijderen, zouden deze functie moeten gebruiken om te voorkomen dat onnodig wordt geprobeerd om al hun inhoud te verwijderen wanneer ze worden vernietigd.
///
/// Dit maakt misschien geen verschil in release-builds (waarbij een loop zonder bijwerkingen gemakkelijk wordt gedetecteerd en geëlimineerd), maar het is vaak een grote overwinning voor debug-builds.
///
/// Merk op dat [`drop_in_place`] deze controle al uitvoert, dus als uw werklast kan worden teruggebracht tot een klein aantal [`drop_in_place`]-aanroepen, is het niet nodig om dit te gebruiken.
/// Merk in het bijzonder op dat je een plak [`drop_in_place`] kunt maken, en dat zal een enkele needs_drop-controle uitvoeren voor alle waarden.
///
/// Typen als Vec dus gewoon `drop_in_place(&mut self[..])` zonder `needs_drop` expliciet te gebruiken.
/// Typen zoals [`HashMap`], aan de andere kant, moeten waarden een voor een laten vallen en zouden deze API moeten gebruiken.
///
/// [`drop_in_place`]: crate::ptr::drop_in_place
/// [`HashMap`]: ../../std/collections/struct.HashMap.html
///
/// # Examples
///
/// Hier is een voorbeeld van hoe een verzameling gebruik kan maken van `needs_drop`:
///
/// ```
/// use std::{mem, ptr};
///
/// pub struct MyCollection<T> {
/// #   data: [T; 1],
///     /* ... */
/// }
/// # impl<T> MyCollection<T> {
/// #   fn iter_mut(&mut self) -> &mut [T] { &mut self.data }
/// #   fn free_buffer(&mut self) {}
/// # }
///
/// impl<T> Drop for MyCollection<T> {
///     fn drop(&mut self) {
///         unsafe {
///             // laat de gegevens vallen
///             if mem::needs_drop::<T>() {
///                 for x in self.iter_mut() {
///                     ptr::drop_in_place(x);
///                 }
///             }
///             self.free_buffer();
///         }
///     }
/// }
/// ```
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "needs_drop", since = "1.21.0")]
#[rustc_const_stable(feature = "const_needs_drop", since = "1.36.0")]
#[rustc_diagnostic_item = "needs_drop"]
pub const fn needs_drop<T>() -> bool {
    intrinsics::needs_drop::<T>()
}

/// Retourneert de waarde van het type `T`, vertegenwoordigd door het byte-patroon geheel nul.
///
/// Dit betekent dat bijvoorbeeld de paddingbyte in `(u8, u16)` niet noodzakelijk op nul wordt gesteld.
///
/// Er is geen garantie dat een byte-patroon geheel nul een geldige waarde van een bepaald type `T` vertegenwoordigt.
/// Het byte-patroon geheel nul is bijvoorbeeld geen geldige waarde voor referentietypen (`&T`, `&mut T`) en functie-aanwijzers.
/// Het gebruik van `zeroed` op dergelijke typen veroorzaakt onmiddellijke [undefined behavior][ub] omdat [the Rust compiler assumes][inv] dat er altijd een geldige waarde is in een variabele die als geïnitialiseerd wordt beschouwd.
///
///
/// Dit heeft hetzelfde effect als [`MaybeUninit::zeroed().assume_init()`][zeroed].
/// Het is soms nuttig voor FFI, maar moet over het algemeen worden vermeden.
///
/// [zeroed]: MaybeUninit::zeroed
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [inv]: MaybeUninit#initialization-invariant
///
/// # Examples
///
/// Correct gebruik van deze functie: initialiseren van een geheel getal met nul.
///
/// ```
/// use std::mem;
///
/// let x: i32 = unsafe { mem::zeroed() };
/// assert_eq!(0, x);
/// ```
///
/// *Onjuist* gebruik van deze functie: een referentie initialiseren met nul.
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem;
///
/// let _x: &i32 = unsafe { mem::zeroed() }; // Ongedefinieerd gedrag!
/// let _y: fn() = unsafe { mem::zeroed() }; // En opnieuw!
/// ```
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_zeroed"]
pub unsafe fn zeroed<T>() -> T {
    // VEILIGHEID: de beller moet garanderen dat een nulwaarde geldig is voor `T`.
    unsafe {
        intrinsics::assert_zero_valid::<T>();
        MaybeUninit::zeroed().assume_init()
    }
}

/// Omzeilt de normale geheugeninitialisatiecontroles van Rust door te doen alsof hij een waarde van het type `T` produceert, terwijl hij helemaal niets doet.
///
/// **Deze functie is verouderd.** Gebruik in plaats daarvan [`MaybeUninit<T>`].
///
/// De reden voor deprecatie is dat de functie in principe niet correct kan worden gebruikt: het heeft hetzelfde effect als [`MaybeUninit::uninit().assume_init()`][uninit].
///
/// Zoals de [`assume_init` documentation][assume_init] uitlegt, worden die waarden [the Rust compiler assumes][inv] correct geïnitialiseerd.
/// Als gevolg hiervan bellen bv
/// `mem::uninitialized::<bool>()` veroorzaakt onmiddellijk ongedefinieerd gedrag voor het retourneren van een `bool` die niet zeker `true` of `false` is.
/// Erger nog, echt niet-geïnitialiseerd geheugen, zoals wat hier wordt geretourneerd, is speciaal omdat de compiler weet dat het geen vaste waarde heeft.
/// Dit maakt het ongedefinieerd gedrag om niet-geïnitialiseerde gegevens in een variabele te hebben, zelfs als die variabele een geheel getal heeft.
/// (Merk op dat de regels rond niet-geïnitialiseerde gehele getallen nog niet definitief zijn, maar totdat ze dat zijn, is het raadzaam ze te vermijden.)
///
/// [uninit]: MaybeUninit::uninit
/// [assume_init]: MaybeUninit::assume_init
/// [inv]: MaybeUninit#initialization-invariant
///
///
///
///
///
#[inline(always)]
#[rustc_deprecated(since = "1.39.0", reason = "use `mem::MaybeUninit` instead")]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_uninitialized"]
pub unsafe fn uninitialized<T>() -> T {
    // VEILIGHEID: de beller moet garanderen dat een unitialized waarde geldig is voor `T`.
    unsafe {
        intrinsics::assert_uninit_valid::<T>();
        MaybeUninit::uninit().assume_init()
    }
}

/// Verwisselt de waarden op twee veranderlijke locaties, zonder een van beide te de-initialiseren.
///
/// * Zie [`take`] als u wilt wisselen met een standaardwaarde of een dummy-waarde.
/// * Zie [`replace`] als u wilt ruilen met een doorgegeven waarde en de oude waarde wilt retourneren.
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// let mut x = 5;
/// let mut y = 42;
///
/// mem::swap(&mut x, &mut y);
///
/// assert_eq!(42, x);
/// assert_eq!(5, y);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn swap<T>(x: &mut T, y: &mut T) {
    // VEILIGHEID: de onbewerkte verwijzingen zijn gemaakt op basis van veilige veranderlijke verwijzingen die voldoen aan alle
    // beperkingen op `ptr::swap_nonoverlapping_one`
    unsafe {
        ptr::swap_nonoverlapping_one(x, y);
    }
}

/// Vervangt `dest` door de standaardwaarde `T`, waarbij de vorige `dest`-waarde wordt geretourneerd.
///
/// * Zie [`swap`] als u de waarden van twee variabelen wilt vervangen.
/// * Zie [`replace`] als u wilt vervangen door een doorgegeven waarde in plaats van de standaardwaarde.
///
/// # Examples
///
/// Een simpel voorbeeld:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::take(&mut v);
/// assert_eq!(vec![1, 2], old_v);
/// assert!(v.is_empty());
/// ```
///
/// `take` maakt het mogelijk om eigenaar te worden van een struct-veld door het te vervangen door een "empty"-waarde.
/// Zonder `take` kunt u problemen als deze tegenkomen:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let buf = self.buf;
///         self.buf = Vec::new();
///         buf
///     }
/// }
/// ```
///
/// Merk op dat `T` niet noodzakelijk [`Clone`] implementeert, dus het kan `self.buf` niet eens klonen en resetten.
/// Maar `take` kan worden gebruikt om de oorspronkelijke waarde van `self.buf` los te koppelen van `self`, zodat deze kan worden geretourneerd:
///
///
/// ```
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         mem::take(&mut self.buf)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf.len(), 2);
///
/// assert_eq!(buffer.get_and_reset(), vec![0, 1]);
/// assert_eq!(buffer.buf.len(), 0);
/// ```
#[inline]
#[stable(feature = "mem_take", since = "1.40.0")]
pub fn take<T: Default>(dest: &mut T) -> T {
    replace(dest, T::default())
}

/// Verplaatst `src` naar de `dest` waarnaar wordt verwezen, en retourneert de vorige `dest`-waarde.
///
/// Geen van beide waarden wordt verwijderd.
///
/// * Zie [`swap`] als u de waarden van twee variabelen wilt vervangen.
/// * Zie [`take`] als u wilt vervangen door een standaardwaarde.
///
/// # Examples
///
/// Een simpel voorbeeld:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::replace(&mut v, vec![3, 4, 5]);
/// assert_eq!(vec![1, 2], old_v);
/// assert_eq!(vec![3, 4, 5], v);
/// ```
///
/// `replace` staat consumptie van een struct-veld toe door het te vervangen door een andere waarde.
/// Zonder `replace` kunt u problemen als deze tegenkomen:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let t = self.buf[i];
///         self.buf[i] = v;
///         t
///     }
/// }
/// ```
///
/// Merk op dat `T` niet noodzakelijk [`Clone`] implementeert, dus we kunnen `self.buf[i]` niet eens klonen om de verplaatsing te vermijden.
/// Maar `replace` kan worden gebruikt om de oorspronkelijke waarde bij die index los te koppelen van `self`, zodat deze kan worden geretourneerd:
///
///
/// ```
/// # #![allow(dead_code)]
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         mem::replace(&mut self.buf[i], v)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf[0], 0);
///
/// assert_eq!(buffer.replace_index(0, 2), 0);
/// assert_eq!(buffer.buf[0], 2);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[must_use = "if you don't need the old value, you can just assign the new value directly"]
pub fn replace<T>(dest: &mut T, src: T) -> T {
    // VEILIGHEID: We lezen van `dest` maar schrijven `src` er daarna direct in,
    // zodat de oude waarde niet wordt gedupliceerd.
    // Niets valt weg en niets kan hier panic.
    unsafe {
        let result = ptr::read(dest);
        ptr::write(dest, src);
        result
    }
}

/// Beschikt over een waarde.
///
/// Dit doet dit door de implementatie van [`Drop`][drop] door het argument aan te roepen.
///
/// Dit doet effectief niets voor typen die `Copy` implementeren, bijv
/// integers.
/// Dergelijke waarden worden gekopieerd en _then_ verplaatst naar de functie, zodat de waarde blijft bestaan na deze functieaanroep.
///
///
/// Deze functie is niet magisch;het wordt letterlijk gedefinieerd als
///
/// ```
/// pub fn drop<T>(_x: T) { }
/// ```
///
/// Omdat `_x` naar de functie wordt verplaatst, wordt deze automatisch verwijderd voordat de functie terugkeert.
///
/// [drop]: Drop
///
/// # Examples
///
/// Basisgebruik:
///
/// ```
/// let v = vec![1, 2, 3];
///
/// drop(v); // verwijder expliciet de vector
/// ```
///
/// Omdat [`RefCell`] de leenregels tijdens runtime afdwingt, kan `drop` een [`RefCell`]-leen vrijgeven:
///
/// ```
/// use std::cell::RefCell;
///
/// let x = RefCell::new(1);
///
/// let mut mutable_borrow = x.borrow_mut();
/// *mutable_borrow = 1;
///
/// drop(mutable_borrow); // afstand doen van de veranderlijke lening op dit slot
///
/// let borrow = x.borrow();
/// println!("{}", *borrow);
/// ```
///
/// Gehele getallen en andere typen die [`Copy`] implementeren, worden niet beïnvloed door `drop`.
///
/// ```
/// #[derive(Copy, Clone)]
/// struct Foo(u8);
///
/// let x = 1;
/// let y = Foo(2);
/// drop(x); // een kopie van `x` wordt verplaatst en verwijderd
/// drop(y); // een kopie van `y` wordt verplaatst en verwijderd
///
/// println!("x: {}, y: {}", x, y.0); // nog steeds beschikbaar
/// ```
///
/// [`RefCell`]: crate::cell::RefCell
///
#[doc(alias = "delete")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn drop<T>(_x: T) {}

/// Interpreteert `src` als type `&U`, en leest vervolgens `src` zonder de ingesloten waarde te verplaatsen.
///
/// Deze functie zal onveilig aannemen dat de pointer `src` geldig is voor [`size_of::<U>`][size_of] bytes door `&T` naar `&U` te transmuteren en vervolgens de `&U` te lezen (behalve dat dit op een correcte manier wordt gedaan, zelfs wanneer `&U` strengere uitlijnvereisten stelt dan `&T`).
/// Het zal ook op onveilige wijze een kopie van de ingesloten waarde maken in plaats van uit `src` te gaan.
///
/// Het is geen compileerfout als `T` en `U` verschillende grootten hebben, maar het wordt sterk aangemoedigd om deze functie alleen aan te roepen als `T` en `U` dezelfde grootte hebben.Deze functie activeert [undefined behavior][ub] als `U` groter is dan `T`.
///
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// #[repr(packed)]
/// struct Foo {
///     bar: u8,
/// }
///
/// let foo_array = [10u8];
///
/// unsafe {
///     // Kopieer de gegevens van 'foo_array' en behandel deze als een 'Foo'
///     let mut foo_struct: Foo = mem::transmute_copy(&foo_array);
///     assert_eq!(foo_struct.bar, 10);
///
///     // Wijzig de gekopieerde gegevens
///     foo_struct.bar = 20;
///     assert_eq!(foo_struct.bar, 20);
/// }
///
/// // De inhoud van 'foo_array' had niet mogen veranderen
/// assert_eq!(foo_array, [10]);
/// ```
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_transmute_copy", issue = "83165")]
pub const unsafe fn transmute_copy<T, U>(src: &T) -> U {
    // Als U een hogere uitlijnvereiste heeft, is het mogelijk dat src niet correct is uitgelijnd.
    if align_of::<U>() > align_of::<T>() {
        // VEILIGHEID: `src` is een referentie die gegarandeerd geldig is voor lezen.
        // De beller moet garanderen dat de daadwerkelijke transmutatie veilig is.
        unsafe { ptr::read_unaligned(src as *const T as *const U) }
    } else {
        // VEILIGHEID: `src` is een referentie die gegarandeerd geldig is voor lezen.
        // We hebben net gecontroleerd of `src as *const U` correct was uitgelijnd.
        // De beller moet garanderen dat de daadwerkelijke transmutatie veilig is.
        unsafe { ptr::read(src as *const T as *const U) }
    }
}

/// Ondoorzichtig type dat de discriminant van een opsomming vertegenwoordigt.
///
/// Zie de [`discriminant`]-functie in deze module voor meer informatie.
#[stable(feature = "discriminant_value", since = "1.21.0")]
pub struct Discriminant<T>(<T as DiscriminantKind>::Discriminant);

// N.B. Deze implementaties van trait kunnen niet worden afgeleid omdat we geen grenzen willen aan T.

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> Copy for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> clone::Clone for Discriminant<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::PartialEq for Discriminant<T> {
    fn eq(&self, rhs: &Self) -> bool {
        self.0 == rhs.0
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::Eq for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> hash::Hash for Discriminant<T> {
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.0.hash(state);
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> fmt::Debug for Discriminant<T> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_tuple("Discriminant").field(&self.0).finish()
    }
}

/// Geeft een unieke waarde terug die de enumvariant in `v` identificeert.
///
/// Als `T` geen enum is, zal het aanroepen van deze functie niet resulteren in ongedefinieerd gedrag, maar de geretourneerde waarde is niet gespecificeerd.
///
///
/// # Stability
///
/// De discriminant van een enumvariant kan veranderen als de enum-definitie verandert.
/// Een discriminant van een variant verandert niet tussen compilaties met dezelfde compiler.
///
/// # Examples
///
/// Dit kan worden gebruikt om enums te vergelijken die gegevens bevatten, zonder rekening te houden met de feitelijke gegevens:
///
/// ```
/// use std::mem;
///
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::discriminant(&Foo::A("bar")), mem::discriminant(&Foo::A("baz")));
/// assert_eq!(mem::discriminant(&Foo::B(1)), mem::discriminant(&Foo::B(2)));
/// assert_ne!(mem::discriminant(&Foo::B(3)), mem::discriminant(&Foo::C(3)));
/// ```
///
#[stable(feature = "discriminant_value", since = "1.21.0")]
#[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
pub const fn discriminant<T>(v: &T) -> Discriminant<T> {
    Discriminant(intrinsics::discriminant_value(v))
}

/// Retourneert het aantal varianten in het enum-type `T`.
///
/// Als `T` geen enum is, zal het aanroepen van deze functie niet resulteren in ongedefinieerd gedrag, maar de geretourneerde waarde is niet gespecificeerd.
/// Evenzo, als `T` een opsomming is met meer varianten dan `usize::MAX`, is de retourwaarde niet gespecificeerd.
/// Onbewoonde varianten worden meegeteld.
///
/// # Examples
///
/// ```
/// # #![feature(never_type)]
/// # #![feature(variant_count)]
///
/// use std::mem;
///
/// enum Void {}
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::variant_count::<Void>(), 0);
/// assert_eq!(mem::variant_count::<Foo>(), 3);
///
/// assert_eq!(mem::variant_count::<Option<!>>(), 2);
/// assert_eq!(mem::variant_count::<Result<!, !>>(), 2);
/// ```
#[inline(always)]
#[unstable(feature = "variant_count", issue = "73662")]
#[rustc_const_unstable(feature = "variant_count", issue = "73662")]
pub const fn variant_count<T>() -> usize {
    intrinsics::variant_count::<T>()
}