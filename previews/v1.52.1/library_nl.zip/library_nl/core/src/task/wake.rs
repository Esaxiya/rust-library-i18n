#![stable(feature = "futures_api", since = "1.36.0")]

use crate::fmt;
use crate::marker::{PhantomData, Unpin};

/// Met een `RawWaker` kan de implementator van een taakuitvoerder een [`Waker`] maken die aangepast ontwaakgedrag biedt.
///
/// [vtable]: https://en.wikipedia.org/wiki/Virtual_method_table
///
/// Het bestaat uit een gegevenspointer en een [virtual function pointer table (vtable)][vtable] die het gedrag van de `RawWaker` aanpast.
///
///
#[derive(PartialEq, Debug)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct RawWaker {
    /// Een gegevensaanwijzer, die kan worden gebruikt om willekeurige gegevens op te slaan zoals vereist door de uitvoerder.
    /// Dit kan bijv. Zijn
    /// een type gewiste aanwijzer naar een `Arc` die aan de taak is gekoppeld.
    /// De waarde van dit veld wordt als eerste parameter doorgegeven aan alle functies die deel uitmaken van de vtable.
    ///
    data: *const (),
    /// Virtuele functieaanwijzertabel die het gedrag van deze waker aanpast.
    vtable: &'static RawWakerVTable,
}

impl RawWaker {
    /// Maakt een nieuwe `RawWaker` van de meegeleverde `data`-pointer en `vtable`.
    ///
    /// De `data`-aanwijzer kan worden gebruikt om willekeurige gegevens op te slaan, zoals vereist door de uitvoerder.Dit kan bijv. Zijn
    /// een type gewiste aanwijzer naar een `Arc` die aan de taak is gekoppeld.
    /// De waarde van deze pointer wordt als eerste parameter doorgegeven aan alle functies die deel uitmaken van de `vtable`.
    ///
    /// De `vtable` past het gedrag van een `Waker` aan die wordt gemaakt op basis van een `RawWaker`.
    /// Voor elke bewerking op de `Waker` wordt de bijbehorende functie in de `vtable` van de onderliggende `RawWaker` aangeroepen.
    ///
    ///
    ///
    #[inline]
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    pub const fn new(data: *const (), vtable: &'static RawWakerVTable) -> RawWaker {
        RawWaker { data, vtable }
    }
}

/// Een virtuele functie pointer table (vtable) die het gedrag van een [`RawWaker`] specificeert.
///
/// De aanwijzer die aan alle functies binnen de vtable wordt doorgegeven, is de `data`-aanwijzer van het omsluitende [`RawWaker`]-object.
///
/// De functies in deze structuur zijn alleen bedoeld om te worden aangeroepen op de `data`-pointer van een correct geconstrueerd [`RawWaker`]-object vanuit de [`RawWaker`]-implementatie.
/// Het aanroepen van een van de ingesloten functies met een andere `data`-aanwijzer zal ongedefinieerd gedrag veroorzaken.
///
///
///
///
#[stable(feature = "futures_api", since = "1.36.0")]
#[derive(PartialEq, Copy, Clone, Debug)]
pub struct RawWakerVTable {
    /// Deze functie wordt aangeroepen wanneer de [`RawWaker`] wordt gekloond, bijvoorbeeld wanneer de [`Waker`] waarin de [`RawWaker`] is opgeslagen, wordt gekloond.
    ///
    /// De implementatie van deze functie moet alle bronnen behouden die nodig zijn voor dit extra exemplaar van een [`RawWaker`] en de bijbehorende taak.
    /// Het aanroepen van `wake` op de resulterende [`RawWaker`] zou moeten resulteren in het ontwaken van dezelfde taak die zou zijn gewekt door de originele [`RawWaker`].
    ///
    ///
    ///
    clone: unsafe fn(*const ()) -> RawWaker,

    /// Deze functie wordt aangeroepen wanneer `wake` wordt aangeroepen op de [`Waker`].
    /// Het moet de taak activeren die bij deze [`RawWaker`] hoort.
    ///
    /// De implementatie van deze functie moet ervoor zorgen dat alle bronnen worden vrijgegeven die zijn gekoppeld aan dit exemplaar van een [`RawWaker`] en de bijbehorende taak.
    ///
    ///
    wake: unsafe fn(*const ()),

    /// Deze functie wordt aangeroepen wanneer `wake_by_ref` wordt aangeroepen op de [`Waker`].
    /// Het moet de taak activeren die bij deze [`RawWaker`] hoort.
    ///
    /// Deze functie is vergelijkbaar met `wake`, maar mag de meegeleverde gegevenspointer niet gebruiken.
    ///
    wake_by_ref: unsafe fn(*const ()),

    /// Deze functie wordt aangeroepen wanneer een [`RawWaker`] wordt verwijderd.
    ///
    /// De implementatie van deze functie moet ervoor zorgen dat alle bronnen worden vrijgegeven die zijn gekoppeld aan dit exemplaar van een [`RawWaker`] en de bijbehorende taak.
    ///
    ///
    drop: unsafe fn(*const ()),
}

impl RawWakerVTable {
    /// Maakt een nieuwe `RawWakerVTable` van de meegeleverde `clone`-, `wake`-, `wake_by_ref`-en `drop`-functies.
    ///
    /// # `clone`
    ///
    /// Deze functie wordt aangeroepen wanneer de [`RawWaker`] wordt gekloond, bijvoorbeeld wanneer de [`Waker`] waarin de [`RawWaker`] is opgeslagen, wordt gekloond.
    ///
    /// De implementatie van deze functie moet alle bronnen behouden die nodig zijn voor dit extra exemplaar van een [`RawWaker`] en de bijbehorende taak.
    /// Het aanroepen van `wake` op de resulterende [`RawWaker`] zou moeten resulteren in het ontwaken van dezelfde taak die zou zijn gewekt door de originele [`RawWaker`].
    ///
    /// # `wake`
    ///
    /// Deze functie wordt aangeroepen wanneer `wake` wordt aangeroepen op de [`Waker`].
    /// Het moet de taak activeren die bij deze [`RawWaker`] hoort.
    ///
    /// De implementatie van deze functie moet ervoor zorgen dat alle bronnen worden vrijgegeven die zijn gekoppeld aan dit exemplaar van een [`RawWaker`] en de bijbehorende taak.
    ///
    ///
    /// # `wake_by_ref`
    ///
    /// Deze functie wordt aangeroepen wanneer `wake_by_ref` wordt aangeroepen op de [`Waker`].
    /// Het moet de taak activeren die bij deze [`RawWaker`] hoort.
    ///
    /// Deze functie is vergelijkbaar met `wake`, maar mag de meegeleverde gegevenspointer niet gebruiken.
    ///
    /// # `drop`
    ///
    /// Deze functie wordt aangeroepen wanneer een [`RawWaker`] wordt verwijderd.
    ///
    /// De implementatie van deze functie moet ervoor zorgen dat alle bronnen worden vrijgegeven die zijn gekoppeld aan dit exemplaar van een [`RawWaker`] en de bijbehorende taak.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_allow_const_fn_unstable(const_fn_fn_ptr_basics)]
    pub const fn new(
        clone: unsafe fn(*const ()) -> RawWaker,
        wake: unsafe fn(*const ()),
        wake_by_ref: unsafe fn(*const ()),
        drop: unsafe fn(*const ()),
    ) -> Self {
        Self { clone, wake, wake_by_ref, drop }
    }
}

/// De `Context` van een asynchrone taak.
///
/// Momenteel dient `Context` alleen om toegang te bieden tot een `&Waker` die kan worden gebruikt om de huidige taak uit de slaapstand te halen.
///
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Context<'a> {
    waker: &'a Waker,
    // Zorg ervoor dat we future-proof zijn tegen variantie-veranderingen door de levensduur te dwingen onveranderlijk te zijn (levensduur van argument-positie is contravariant, terwijl levensduur van terugkeerpositie covariant is).
    //
    //
    //
    _marker: PhantomData<fn(&'a ()) -> &'a ()>,
}

impl<'a> Context<'a> {
    /// Maak een nieuwe `Context` van een `&Waker`.
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn from_waker(waker: &'a Waker) -> Self {
        Context { waker, _marker: PhantomData }
    }

    /// Retourneert een verwijzing naar de `Waker` voor de huidige taak.
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn waker(&self) -> &'a Waker {
        &self.waker
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Context<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Context").field("waker", &self.waker).finish()
    }
}

/// Een `Waker` is een handvat om een taak wakker te maken door de uitvoerder ervan op de hoogte te stellen dat deze klaar is om te worden uitgevoerd.
///
/// Deze handle kapselt een [`RawWaker`]-instantie in, die het executor-specifieke activeringsgedrag definieert.
///
///
/// Implementeert [`Clone`], [`Send`] en [`Sync`].
///
#[repr(transparent)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Waker {
    waker: RawWaker,
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Unpin for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Send for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Sync for Waker {}

impl Waker {
    /// Maak de taak wakker die bij deze `Waker` hoort.
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake(self) {
        // De daadwerkelijke wakeup-oproep wordt gedelegeerd via een virtuele functieaanroep naar de implementatie die is gedefinieerd door de uitvoerder.
        //
        let wake = self.waker.vtable.wake;
        let data = self.waker.data;

        // Roep geen `drop` aan-de waker wordt verbruikt door `wake`.
        crate::mem::forget(self);

        // VEILIGHEID: Dit is veilig omdat `Waker::from_raw` de enige manier is
        // om `wake` en `data` te initialiseren, waarbij de gebruiker moet bevestigen dat het contract van `RawWaker` wordt gehandhaafd.
        //
        unsafe { (wake)(data) };
    }

    /// Activeer de taak die aan deze `Waker` is gekoppeld zonder de `Waker` te verbruiken.
    ///
    /// Dit is vergelijkbaar met `wake`, maar kan iets minder efficiënt zijn in het geval dat een `Waker` in eigendom beschikbaar is.
    /// Deze methode verdient de voorkeur boven het aanroepen van `waker.clone().wake()`.
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake_by_ref(&self) {
        // De daadwerkelijke wakeup-oproep wordt gedelegeerd via een virtuele functieaanroep naar de implementatie die is gedefinieerd door de uitvoerder.
        //

        // VEILIGHEID: zie `wake`
        unsafe { (self.waker.vtable.wake_by_ref)(self.waker.data) }
    }

    /// Geeft `true` terug als deze `Waker` en een andere `Waker` dezelfde taak hebben gewekt.
    ///
    /// Deze functie werkt op een best mogelijke basis, en kan false retourneren, zelfs als de `Waker`s dezelfde taak zouden opwekken.
    /// Als deze functie echter `true` retourneert, is het gegarandeerd dat de `Waker`s dezelfde taak zullen opwekken.
    ///
    /// Deze functie wordt voornamelijk gebruikt voor optimalisatiedoeleinden.
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn will_wake(&self, other: &Waker) -> bool {
        self.waker == other.waker
    }

    /// Maakt een nieuwe `Waker` van [`RawWaker`].
    ///
    /// Het gedrag van de geretourneerde `Waker` is niet gedefinieerd als het contract gedefinieerd in de documentatie van [`RawWaker`] en [`RawWakerVTable`] niet wordt gehandhaafd.
    ///
    /// Daarom is deze methode onveilig.
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub unsafe fn from_raw(waker: RawWaker) -> Waker {
        Waker { waker }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Clone for Waker {
    #[inline]
    fn clone(&self) -> Self {
        Waker {
            // VEILIGHEID: Dit is veilig omdat `Waker::from_raw` de enige manier is
            // om `clone` en `data` te initialiseren, waarbij de gebruiker moet bevestigen dat het contract van [`RawWaker`] wordt gehandhaafd.
            //
            waker: unsafe { (self.waker.vtable.clone)(self.waker.data) },
        }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Drop for Waker {
    #[inline]
    fn drop(&mut self) {
        // VEILIGHEID: Dit is veilig omdat `Waker::from_raw` de enige manier is
        // om `drop` en `data` te initialiseren, waarbij de gebruiker moet bevestigen dat het contract van `RawWaker` wordt gehandhaafd.
        //
        unsafe { (self.waker.vtable.drop)(self.waker.data) }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Waker {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let vtable_ptr = self.waker.vtable as *const RawWakerVTable;
        f.debug_struct("Waker")
            .field("data", &self.waker.data)
            .field("vtable", &vtable_ptr)
            .finish()
    }
}