#![stable(feature = "core_hint", since = "1.27.0")]

//! Hints voor de compiler die van invloed zijn op hoe code moet worden verzonden of geoptimaliseerd.
//! Hints kunnen compilatietijd of runtime zijn.

use crate::intrinsics;

/// Informeert de compiler dat dit punt in de code niet bereikbaar is, waardoor verdere optimalisaties mogelijk zijn.
///
/// # Safety
///
/// Het bereiken van deze functie is volledig *ongedefinieerd gedrag*(UB).In het bijzonder gaat de compiler ervan uit dat alle UB nooit mag gebeuren, en zal daarom alle vertakkingen elimineren die een aanroep naar `unreachable_unchecked()` bereiken.
///
/// Zoals alle gevallen van UB, zal de compiler, als deze aanname onjuist blijkt te zijn, dat wil zeggen dat de `unreachable_unchecked()`-oproep daadwerkelijk bereikbaar is via alle mogelijke besturingsstromen, de verkeerde optimalisatiestrategie toepassen en soms zelfs schijnbaar ongerelateerde code corrumperen, waardoor moeilijke-om problemen op te lossen.
///
///
/// Gebruik deze functie alleen als u kunt aantonen dat de code deze nooit zal aanroepen.
/// Overweeg anders om de [`unreachable!`]-macro te gebruiken, die geen optimalisaties toestaat, maar wel panic wanneer deze wordt uitgevoerd.
///
/// # Example
///
/// ```
/// fn div_1(a: u32, b: u32) -> u32 {
///     use std::hint::unreachable_unchecked;
///
///     // `b.saturating_add(1)` is altijd positief (niet nul), daarom zal `checked_div` nooit `None` retourneren.
/////
///     // Daarom is de else branch onbereikbaar.
///     a.checked_div(b.saturating_add(1))
///         .unwrap_or_else(|| unsafe { unreachable_unchecked() })
/// }
///
/// assert_eq!(div_1(7, 0), 7);
/// assert_eq!(div_1(9, 1), 4);
/// assert_eq!(div_1(11, u32::MAX), 0);
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "unreachable", since = "1.27.0")]
#[rustc_const_unstable(feature = "const_unreachable_unchecked", issue = "53188")]
pub const unsafe fn unreachable_unchecked() -> ! {
    // VEILIGHEID: het veiligheidscontract voor `intrinsics::unreachable` moet
    // ondersteund worden door de beller.
    unsafe { intrinsics::unreachable() }
}

/// Zendt een machine-instructie uit om de processor te signaleren dat deze in een drukke-wacht-spin-lus ("spin lock") draait.
///
/// Bij ontvangst van het spin-loop signaal kan de processor zijn gedrag optimaliseren door bijvoorbeeld stroom te besparen of hyper-threads te wisselen.
///
/// Deze functie verschilt van [`thread::yield_now`] die direct toegeeft aan de planner van het systeem, terwijl `spin_loop` geen interactie heeft met het besturingssysteem.
///
/// Een veelvoorkomend geval voor `spin_loop` is het implementeren van bounded optimistic spinning in een CAS-lus in synchronisatieprimitieven.
/// Om problemen zoals prioriteitsinversie te voorkomen, wordt sterk aanbevolen dat de spin-lus wordt beëindigd na een eindig aantal iteraties en een geschikte blokkerende syscall is gemaakt.
///
///
/// **Opmerking**: op platforms die het ontvangen van spin-loop-hints niet ondersteunen, doet deze functie helemaal niets.
///
/// # Examples
///
/// ```
/// use std::sync::atomic::{AtomicBool, Ordering};
/// use std::sync::Arc;
/// use std::{hint, thread};
///
/// // Een gedeelde atomaire waarde die threads zullen gebruiken om te coördineren
/// let live = Arc::new(AtomicBool::new(false));
///
/// // In een achtergrondthread stellen we uiteindelijk de waarde in
/// let bg_work = {
///     let live = live.clone();
///     thread::spawn(move || {
///         // Doe wat werk en laat de waarde leven
///         do_some_work();
///         live.store(true, Ordering::Release);
///     })
/// };
///
/// // Terug op onze huidige thread wachten we tot de waarde is ingesteld
/// while !live.load(Ordering::Acquire) {
///     // De spin-loop is een hint voor de CPU dat we wachten, maar waarschijnlijk niet erg lang
/////
///     hint::spin_loop();
/// }
///
/// // De waarde is nu ingesteld
/// # fn do_some_work() {}
/// do_some_work();
/// bg_work.join()?;
/// # Ok::<(), Box<dyn core::any::Any + Send + 'static>>(())
/// ```
///
/// [`thread::yield_now`]: ../../std/thread/fn.yield_now.html
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "renamed_spin_loop", since = "1.49.0")]
pub fn spin_loop() {
    #[cfg(all(any(target_arch = "x86", target_arch = "x86_64"), target_feature = "sse2"))]
    {
        #[cfg(target_arch = "x86")]
        {
            // VEILIGHEID: de `cfg`-attr zorgt ervoor dat we dit alleen uitvoeren op x86-doelen.
            unsafe { crate::arch::x86::_mm_pause() };
        }

        #[cfg(target_arch = "x86_64")]
        {
            // VEILIGHEID: de `cfg`-attr zorgt ervoor dat we dit alleen uitvoeren op x86_64-doelen.
            unsafe { crate::arch::x86_64::_mm_pause() };
        }
    }

    #[cfg(any(target_arch = "aarch64", all(target_arch = "arm", target_feature = "v6")))]
    {
        #[cfg(target_arch = "aarch64")]
        {
            // VEILIGHEID: de `cfg`-attr zorgt ervoor dat we dit alleen uitvoeren op aarch64-doelen.
            unsafe { crate::arch::aarch64::__yield() };
        }
        #[cfg(target_arch = "arm")]
        {
            // VEILIGHEID: de `cfg` attr zorgt ervoor dat we dit alleen uitvoeren op armdoelen
            // met ondersteuning voor de v6-functie.
            unsafe { crate::arch::arm::__yield() };
        }
    }
}

/// Een identiteitsfunctie die * __ __ hint naar de compiler om maximaal pessimistisch te zijn over wat `black_box` zou kunnen doen.
///
/// In tegenstelling tot [`std::convert::identity`] wordt een Rust-compiler aangemoedigd om aan te nemen dat `black_box` `dummy` kan gebruiken op elke mogelijke geldige manier waarop Rust-code is toegestaan zonder ongedefinieerd gedrag in de aanroepende code te introduceren.
///
/// Deze eigenschap maakt `black_box` handig voor het schrijven van code waarin bepaalde optimalisaties niet gewenst zijn, zoals benchmarks.
///
/// Merk echter op dat `black_box` alleen wordt geleverd (en alleen kan worden geleverd) op basis van "best-effort".De mate waarin het optimalisaties kan blokkeren, kan variëren, afhankelijk van het gebruikte platform en de backend van de codegeneratie.
/// Programma's kunnen op geen enkele manier op `black_box` vertrouwen voor *juistheid*.
///
/// [`std::convert::identity`]: crate::convert::identity
///
///
///
#[cfg_attr(not(miri), inline)]
#[cfg_attr(miri, inline(never))]
#[unstable(feature = "test", issue = "50297")]
#[cfg_attr(miri, allow(unused_mut))]
pub fn black_box<T>(mut dummy: T) -> T {
    // We moeten "use" het argument op de een of andere manier LLVM kan niet introspecteren, en op doelen die het ondersteunen, kunnen we meestal gebruik maken van inline-assemblage om dit te doen.
    // LLVM's interpretatie van inline-assemblage is dat het, nou ja, een zwarte doos is.
    // Dit is niet de beste implementatie omdat het waarschijnlijk meer deoptimaliseert dan we willen, maar het is tot nu toe goed genoeg.
    //
    //

    #[cfg(not(miri))] // Dit is slechts een hint, dus het is prima om over te slaan in Miri.
    // VEILIGHEID: de inline montage is een no-op.
    unsafe {
        // FIXME: Kan `asm!` niet gebruiken omdat het geen MIPS en andere architecturen ondersteunt.
        llvm_asm!("" : : "r"(&mut dummy) : "memory" : "volatile");
    }

    dummy
}