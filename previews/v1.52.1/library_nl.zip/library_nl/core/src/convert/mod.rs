//! Traits voor conversies tussen typen.
//!
//! De traits in deze module bieden een manier om van het ene type naar het andere te converteren.
//! Elke trait heeft een ander doel:
//!
//! - Implementeer de [`AsRef`] trait voor goedkope referentie-naar-referentie-conversies
//! - Implementeer de [`AsMut`] trait voor goedkope veranderlijke naar veranderlijke conversies
//! - Implementeer de [`From`] trait voor het consumeren van waarde-naar-waarde-conversies
//! - Implementeer de [`Into`] trait voor het consumeren van waarde-naar-waarde-conversies naar typen buiten de huidige crate
//! - De [`TryFrom`] en [`TryInto`] traits gedragen zich als [`From`] en [`Into`], maar moeten worden geïmplementeerd wanneer de conversie kan mislukken.
//!
//! De traits in deze module worden vaak gebruikt als trait bounds voor generieke functies zodat argumenten van meerdere typen worden ondersteund.Zie de documentatie van elke trait voor voorbeelden.
//!
//! Als bibliotheekauteur zou je altijd de voorkeur moeten geven aan het implementeren van [`From<T>`][`From`] of [`TryFrom<T>`][`TryFrom`] in plaats van [`Into<U>`][`Into`] of [`TryInto<U>`][`TryInto`], aangezien [`From`] en [`TryFrom`] meer flexibiliteit bieden en gelijkwaardige [`Into`]-of [`TryInto`]-implementaties gratis aanbieden, dankzij een algemene implementatie in de standaardbibliotheek.
//! Wanneer u zich richt op een versie vóór Rust 1.41, kan het nodig zijn om [`Into`] of [`TryInto`] rechtstreeks te implementeren bij het converteren naar een type buiten de huidige crate.
//!
//! # Generieke implementaties
//!
//! - [`AsRef`] en [`AsMut`] auto-dereference als het innerlijke type een referentie is
//! - [`Van`]`<U>voor T` impliceert [`In`]`</u><T><U>voor U`</u>
//! - [`TryFrom`]`<U>for T` impliceert [`TryInto`]`</u><T><U>voor U`</u>
//! - [`From`] en [`Into`] zijn reflexief, wat betekent dat alle typen `into` zichzelf en `from` zelf kunnen
//!
//! Zie elke trait voor gebruiksvoorbeelden.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

mod num;

#[unstable(feature = "convert_float_to_int", issue = "67057")]
pub use num::FloatToInt;

/// De identiteitsfunctie.
///
/// Twee dingen zijn belangrijk om op te merken over deze functie:
///
/// - Het is niet altijd gelijk aan een sluiting zoals `|x| x`, aangezien de sluiting `x` in een ander type kan dwingen.
///
/// - Het verplaatst de invoer `x` die aan de functie is doorgegeven.
///
/// Hoewel het misschien vreemd lijkt om een functie te hebben die alleen de invoer retourneert, zijn er enkele interessante toepassingen.
///
///
/// # Examples
///
/// `identity` gebruiken om niets te doen in een reeks andere, interessante functies:
///
/// ```rust
/// use std::convert::identity;
///
/// fn manipulation(x: u32) -> u32 {
///     // Laten we net doen alsof het toevoegen van een een interessante functie is.
///     x + 1
/// }
///
/// let _arr = &[identity, manipulation];
/// ```
///
/// `identity` gebruiken als een "do nothing"-basisscenario in een voorwaardelijke:
///
/// ```rust
/// use std::convert::identity;
///
/// # let condition = true;
/// #
/// # fn manipulation(x: u32) -> u32 { x + 1 }
/// #
/// let do_stuff = if condition { manipulation } else { identity };
///
/// // Doe meer interessante dingen ...
///
/// let _results = do_stuff(42);
/// ```
///
/// `identity` gebruiken om de `Some`-varianten van een iterator van `Option<T>` te behouden:
///
/// ```rust
/// use std::convert::identity;
///
/// let iter = vec![Some(1), None, Some(3)].into_iter();
/// let filtered = iter.filter_map(identity).collect::<Vec<_>>();
/// assert_eq!(vec![1, 3], filtered);
/// ```
///
///
#[stable(feature = "convert_id", since = "1.33.0")]
#[rustc_const_stable(feature = "const_identity", since = "1.33.0")]
#[inline]
pub const fn identity<T>(x: T) -> T {
    x
}

/// Wordt gebruikt om een goedkope referentie-naar-referentie-conversie uit te voeren.
///
/// Deze trait is vergelijkbaar met [`AsMut`] die wordt gebruikt voor het converteren tussen veranderlijke referenties.
/// Als u een dure conversie moet uitvoeren, is het beter om [`From`] met type `&T` te implementeren of een aangepaste functie te schrijven.
///
/// `AsRef` heeft dezelfde handtekening als [`Borrow`], maar [`Borrow`] verschilt in enkele aspecten:
///
/// - In tegenstelling tot `AsRef` heeft [`Borrow`] een dekenim voor elke `T` en kan worden gebruikt om een referentie of een waarde te accepteren.
/// - [`Borrow`] vereist ook dat [`Hash`], [`Eq`] en [`Ord`] voor geleende waarde gelijk zijn aan die van de waarde in eigendom.
/// Om deze reden, als u slechts een enkel veld van een struct wilt lenen, kunt u `AsRef` implementeren, maar niet [`Borrow`].
///
/// **Note: Deze trait mag niet falen **.Als de conversie mislukt, gebruik dan een speciale methode die een [`Option<T>`] of een [`Result<T, E>`] retourneert.
///
/// # Generieke implementaties
///
/// - `AsRef` auto-dereferences als het innerlijke type een referentie of een veranderlijke referentie is (bijv: `foo.as_ref()` will work the same if `foo` has type   `&mut Foo` or `&&mut Foo`)
///
///
/// # Examples
///
/// Door trait bounds te gebruiken, kunnen we argumenten van verschillende typen accepteren, zolang ze kunnen worden geconverteerd naar het gespecificeerde type `T`.
///
/// Bijvoorbeeld: door een generieke functie te maken waaraan een `AsRef<str>` moet voldoen, geven we aan dat we alle verwijzingen die naar [`&str`] kunnen worden geconverteerd als argument willen accepteren.
/// Omdat zowel [`String`] als [`&str`] `AsRef<str>` implementeren, kunnen we beide accepteren als invoerargument.
///
/// [`&str`]: primitive@str
/// [`Borrow`]: crate::borrow::Borrow
/// [`Eq`]: crate::cmp::Eq
/// [`Ord`]: crate::cmp::Ord
/// [`String`]: ../../std/string/struct.String.html
///
/// ```
/// fn is_hello<T: AsRef<str>>(s: T) {
///    assert_eq!("hello", s.as_ref());
/// }
///
/// let s = "hello";
/// is_hello(s);
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsRef<T: ?Sized> {
    /// Voert de conversie uit.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_ref(&self) -> &T;
}

/// Wordt gebruikt om een goedkope veranderlijk-veranderlijke referentieconversie uit te voeren.
///
/// Deze trait is vergelijkbaar met [`AsRef`] maar wordt gebruikt voor het converteren tussen veranderlijke referenties.
/// Als u een dure conversie moet uitvoeren, is het beter om [`From`] met type `&mut T` te implementeren of een aangepaste functie te schrijven.
///
/// **Note: Deze trait mag niet falen **.Als de conversie mislukt, gebruik dan een speciale methode die een [`Option<T>`] of een [`Result<T, E>`] retourneert.
///
/// # Generieke implementaties
///
/// - `AsMut` auto-dereferences als het innerlijke type een veranderlijke referentie is (bijv: `foo.as_mut()` will work the same if `foo` has type `&mut Foo`   or `&mut &mut Foo`)
///
///
/// # Examples
///
/// Door `AsMut` te gebruiken als trait bound voor een generieke functie, kunnen we alle veranderlijke referenties accepteren die kunnen worden geconverteerd naar het type `&mut T`.
/// Omdat [`Box<T>`] `AsMut<T>` implementeert, kunnen we een functie `add_one` schrijven die alle argumenten accepteert die naar `&mut u64` kunnen worden geconverteerd.
/// Omdat [`Box<T>`] `AsMut<T>` implementeert, accepteert `add_one` ook argumenten van het type `&mut Box<u64>`:
///
/// ```
/// fn add_one<T: AsMut<u64>>(num: &mut T) {
///     *num.as_mut() += 1;
/// }
///
/// let mut boxed_num = Box::new(0);
/// add_one(&mut boxed_num);
/// assert_eq!(*boxed_num, 1);
/// ```
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsMut<T: ?Sized> {
    /// Voert de conversie uit.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_mut(&mut self) -> &mut T;
}

/// Een waarde-naar-waarde-conversie die de invoerwaarde verbruikt.Het tegenovergestelde van [`From`].
///
/// Men moet de implementatie van [`Into`] vermijden en in plaats daarvan [`From`] implementeren.
/// Het implementeren van [`From`] levert automatisch een implementatie van [`Into`] op dankzij de algemene implementatie in de standaardbibliotheek.
///
/// Gebruik liever [`Into`] boven [`From`] bij het specificeren van trait bounds op een generieke functie om er zeker van te zijn dat typen die alleen [`Into`] implementeren ook kunnen worden gebruikt.
///
/// **Note: Deze trait mag niet falen **.Gebruik [`TryInto`] als de conversie mislukt.
///
/// # Generieke implementaties
///
/// - [`Van`]`<T>for U` impliceert `Into<U> for T`
/// - [`Into`] is reflexief, wat betekent dat `Into<T> for T` is geïmplementeerd
///
/// # [`Into`] implementeren voor conversies naar externe typen in oude versies van Rust
///
/// Vóór Rust 1.41, als het bestemmingstype geen deel uitmaakte van de huidige crate, dan kon je [`From`] niet rechtstreeks implementeren.
/// Neem bijvoorbeeld deze code:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> From<Wrapper<T>> for Vec<T> {
///     fn from(w: Wrapper<T>) -> Vec<T> {
///         w.0
///     }
/// }
/// ```
/// Dit kan niet worden gecompileerd in oudere versies van de taal omdat de verweesregels van Rust vroeger iets strikter waren.
/// Om dit te omzeilen, zou u [`Into`] rechtstreeks kunnen implementeren:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> Into<Vec<T>> for Wrapper<T> {
///     fn into(self) -> Vec<T> {
///         self.0
///     }
/// }
/// ```
///
/// Het is belangrijk om te begrijpen dat [`Into`] geen [`From`]-implementatie biedt (zoals [`From`] doet met [`Into`]).
/// Daarom moet u altijd proberen [`From`] te implementeren en vervolgens terugvallen op [`Into`] als [`From`] niet kan worden geïmplementeerd.
///
/// # Examples
///
/// [`String`] implementeert [`Into`]`<`[`Vec`] `<` [`u8`]`>>`:
///
/// Om uit te drukken dat we willen dat een generieke functie alle argumenten accepteert die kunnen worden geconverteerd naar een gespecificeerd type `T`, kunnen we een trait bound van [`Into`]` gebruiken<T>'.
///
/// Bijvoorbeeld: de functie `is_hello` accepteert alle argumenten die omgezet kunnen worden in een [`Vec`]`<`[`u8`] `>`.
///
/// ```
/// fn is_hello<T: Into<Vec<u8>>>(s: T) {
///    let bytes = b"hello".to_vec();
///    assert_eq!(bytes, s.into());
/// }
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`Vec`]: ../../std/vec/struct.Vec.html
///
///
///
///
///
///
#[rustc_diagnostic_item = "into_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Into<T>: Sized {
    /// Voert de conversie uit.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into(self) -> T;
}

/// Wordt gebruikt om waarde-naar-waarde-conversies uit te voeren terwijl de invoerwaarde wordt verbruikt.Het is het omgekeerde van [`Into`].
///
/// Men zou altijd de voorkeur moeten geven aan het implementeren van `From` boven [`Into`], omdat het implementeren van `From` automatisch een implementatie van [`Into`] oplevert dankzij de algemene implementatie in de standaardbibliotheek.
///
///
/// Implementeer [`Into`] alleen wanneer u zich richt op een versie vóór Rust 1.41 en converteert naar een type buiten de huidige crate.
/// `From` was niet in staat om dit soort conversies in eerdere versies uit te voeren vanwege de verweesingsregels van Rust.
/// Zie [`Into`] voor meer details.
///
/// Gebruik liever [`Into`] dan `From` bij het specificeren van trait bounds op een generieke functie.
/// Op deze manier kunnen typen die [`Into`] direct implementeren ook als argumenten worden gebruikt.
///
/// De `From` is ook erg handig bij het afhandelen van fouten.Bij het construeren van een functie die kan mislukken, zal het retourtype over het algemeen de vorm `Result<T, E>` hebben.
/// De `From` trait vereenvoudigt het afhandelen van fouten door een functie toe te staan een enkel fouttype te retourneren dat meerdere fouttypen omvat.Zie de "Examples"-sectie en [the book][book] voor meer details.
///
/// **Note: Deze trait mag niet falen **.Gebruik [`TryFrom`] als de conversie mislukt.
///
/// # Generieke implementaties
///
/// - `From<T> for U` impliceert [`Into`]`<U>voor T`</u>
/// - `From` is reflexief, wat betekent dat `From<T> for T` is geïmplementeerd
///
/// # Examples
///
/// [`String`] implementeert `From<&str>`:
///
/// Een expliciete conversie van een `&str` naar een String gaat als volgt:
///
/// ```
/// let string = "hello".to_string();
/// let other_string = String::from("hello");
///
/// assert_eq!(string, other_string);
/// ```
///
/// Bij het uitvoeren van foutafhandeling is het vaak handig om `From` voor uw eigen fouttype te implementeren.
/// Door onderliggende fouttypen te converteren naar ons eigen aangepaste fouttype dat het onderliggende fouttype omvat, kunnen we een enkel fouttype retourneren zonder informatie over de onderliggende oorzaak te verliezen.
/// De '?'-operator converteert automatisch het onderliggende fouttype naar ons aangepaste fouttype door `Into<CliError>::into` te bellen, dat automatisch wordt verstrekt bij het implementeren van `From`.
/// De compiler leidt vervolgens af welke implementatie van `Into` moet worden gebruikt.
///
/// ```
/// use std::fs;
/// use std::io;
/// use std::num;
///
/// enum CliError {
///     IoError(io::Error),
///     ParseError(num::ParseIntError),
/// }
///
/// impl From<io::Error> for CliError {
///     fn from(error: io::Error) -> Self {
///         CliError::IoError(error)
///     }
/// }
///
/// impl From<num::ParseIntError> for CliError {
///     fn from(error: num::ParseIntError) -> Self {
///         CliError::ParseError(error)
///     }
/// }
///
/// fn open_and_parse_file(file_name: &str) -> Result<i32, CliError> {
///     let mut contents = fs::read_to_string(&file_name)?;
///     let num: i32 = contents.trim().parse()?;
///     Ok(num)
/// }
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`from`]: From::from
/// [book]: ../../book/ch09-00-error-handling.html
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "from_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(on(
    all(_Self = "&str", T = "std::string::String"),
    note = "to coerce a `{T}` into a `{Self}`, use `&*` as a prefix",
))]
pub trait From<T>: Sized {
    /// Voert de conversie uit.
    #[lang = "from"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from(_: T) -> Self;
}

/// Een poging tot conversie die `self` verbruikt, wat al dan niet duur kan zijn.
///
/// Bibliotheekauteurs zouden deze trait meestal niet rechtstreeks moeten implementeren, maar zouden de voorkeur moeten geven aan de implementatie van de [`TryFrom`] trait, die meer flexibiliteit biedt en een gelijkwaardige `TryInto`-implementatie gratis biedt, dankzij een algemene implementatie in de standaardbibliotheek.
/// Zie de documentatie voor [`Into`] voor meer informatie hierover.
///
/// # `TryInto` implementeren
///
/// Dit lijdt aan dezelfde beperkingen en redenering als het implementeren van [`Into`], zie daar voor details.
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_into_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryInto<T>: Sized {
    /// Het type dat wordt geretourneerd in het geval van een conversiefout.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// Voert de conversie uit.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_into(self) -> Result<T, Self::Error>;
}

/// Eenvoudige en veilige typeconversies die onder bepaalde omstandigheden op een gecontroleerde manier kunnen mislukken.Het is het omgekeerde van [`TryInto`].
///
/// Dit is handig wanneer u een typeconversie uitvoert die triviaal kan slagen, maar die mogelijk ook op een speciale manier moet worden behandeld.
/// Er is bijvoorbeeld geen manier om een [`i64`] naar een [`i32`] te converteren met behulp van de [`From`] trait, omdat een [`i64`] een waarde kan bevatten die een [`i32`] niet kan vertegenwoordigen, waardoor de conversie gegevens zou verliezen.
///
/// Dit kan worden afgehandeld door de [`i64`] af te kappen tot een [`i32`] (in feite de waarde van de [`i64`] modulo [`i32::MAX`] te geven) of door simpelweg [`i32::MAX`] terug te sturen, of door een andere methode.
/// De [`From`] trait is bedoeld voor perfecte conversies, dus de `TryFrom` trait informeert de programmeur wanneer een typeconversie mislukt en laat ze beslissen hoe ze ermee om moeten gaan.
///
/// # Generieke implementaties
///
/// - `TryFrom<T> for U` impliceert [`TryInto`]`<U>voor T`</u>
/// - [`try_from`] is reflexief, wat betekent dat `TryFrom<T> for T` is geïmplementeerd en niet kan falen-het bijbehorende `Error`-type voor het aanroepen van `T::try_from()` op een waarde van het type `T` is [`Infallible`].
/// Wanneer het [`!`]-type gestabiliseerd is, zijn [`Infallible`] en [`!`] equivalent.
///
/// `TryFrom<T>` kan als volgt worden geïmplementeerd:
///
/// ```
/// use std::convert::TryFrom;
///
/// struct GreaterThanZero(i32);
///
/// impl TryFrom<i32> for GreaterThanZero {
///     type Error = &'static str;
///
///     fn try_from(value: i32) -> Result<Self, Self::Error> {
///         if value <= 0 {
///             Err("GreaterThanZero only accepts value superior than zero!")
///         } else {
///             Ok(GreaterThanZero(value))
///         }
///     }
/// }
/// ```
///
/// # Examples
///
/// Zoals beschreven implementeert [`i32`] `TryFrom <` [`i64`]`>`:
///
/// ```
/// use std::convert::TryFrom;
///
/// let big_number = 1_000_000_000_000i64;
/// // Trunceert `big_number` stilletjes, vereist detectie en afhandeling van de truncatie achteraf.
/////
/// let smaller_number = big_number as i32;
/// assert_eq!(smaller_number, -727379968);
///
/// // Retourneert een fout omdat `big_number` te groot is om in een `i32` te passen.
/////
/// let try_smaller_number = i32::try_from(big_number);
/// assert!(try_smaller_number.is_err());
///
/// // Retourneert `Ok(3)`.
/// let try_successful_smaller_number = i32::try_from(3);
/// assert!(try_successful_smaller_number.is_ok());
/// ```
///
/// [`try_from`]: TryFrom::try_from
///
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_from_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryFrom<T>: Sized {
    /// Het type dat wordt geretourneerd in het geval van een conversiefout.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// Voert de conversie uit.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_from(value: T) -> Result<Self, Self::Error>;
}

////////////////////////////////////////////////////////////////////////////////
// ALGEMENE IMPLICATIES
////////////////////////////////////////////////////////////////////////////////

// Als liften over&
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// Als liften over &mut
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &mut T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// FIXME (#45742): vervang de bovenstaande impls voor&/&mut door de volgende meer algemene:
// // Zoals liften over Deref
// impl <D: ?Sized + Deref<Target: AsRef<U>>, U:? Sized> AsRef <U>voor D {fn as_ref(&self)-> &U {</u>
//
//         self.deref().as_ref()
//     }
// }

// AsMut tilt meer dan &mut op
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsMut<U> for &mut T
where
    T: AsMut<U>,
{
    fn as_mut(&mut self) -> &mut U {
        (*self).as_mut()
    }
}

// FIXME (#45742): vervang de bovenstaande impl voor &mut door de volgende meer algemene:
// // AsMut tilt DerefMut op
// impl <D: ?Sized + Deref<Target: AsMut<U>>, U:? Sized> AsMut <U>voor D {fn as_mut(&mut self)-> &mut U {</u>
//
//         self.deref_mut().as_mut()
//     }
// }

// Van impliceert Into
#[stable(feature = "rust1", since = "1.0.0")]
impl<T, U> Into<U> for T
where
    U: From<T>,
{
    fn into(self) -> U {
        U::from(self)
    }
}

// Van (en dus naar) is reflexief
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> From<T> for T {
    fn from(t: T) -> T {
        t
    }
}

/// **Stabiliteitsopmerking:** Dit impl bestaat nog niet, maar we zijn "reserving space" om het toe te voegen aan de future.
/// Zie [rust-lang/rust#64715][#64715] voor details.
///
/// [#64715]: https://github.com/rust-lang/rust/issues/64715
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[allow(unused_attributes)] // FIXME(#58633): doe in plaats daarvan een principiële oplossing.
#[rustc_reservation_impl = "permitting this impl would forbid us from adding \
                            `impl<T> From<!> for T` later; see rust-lang/rust#64715 for details"]
impl<T> From<!> for T {
    fn from(t: !) -> T {
        t
    }
}

// TryFrom impliceert TryInto
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryInto<U> for T
where
    U: TryFrom<T>,
{
    type Error = U::Error;

    fn try_into(self) -> Result<U, U::Error> {
        U::try_from(self)
    }
}

// Onfeilbare conversies zijn semantisch equivalent aan feilbare conversies met een onbewoond fouttype.
//
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryFrom<U> for T
where
    U: Into<T>,
{
    type Error = Infallible;

    fn try_from(value: U) -> Result<Self, Self::Error> {
        Ok(U::into(value))
    }
}

////////////////////////////////////////////////////////////////////////////////
// BETON IMPLEMENTEN
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsRef<[T]> for [T] {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsMut<[T]> for [T] {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for str {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "as_mut_str_for_str", since = "1.51.0")]
impl AsMut<str> for str {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

////////////////////////////////////////////////////////////////////////////////
// HET NO-FOUT FOUTTYPE
////////////////////////////////////////////////////////////////////////////////

/// Het fouttype voor fouten die nooit kunnen voorkomen.
///
/// Aangezien deze enum geen variant heeft, kan een waarde van dit type nooit echt bestaan.
/// Dit kan handig zijn voor generieke API's die [`Result`] gebruiken en het fouttype parametriseren, om aan te geven dat het resultaat altijd [`Ok`] is.
///
/// De [`TryFrom`] trait (conversie die een [`Result`] retourneert) heeft bijvoorbeeld een algemene implementatie voor alle typen waar een omgekeerde [`Into`]-implementatie bestaat.
///
/// ```ignore (illustrates std code, duplicating the impl in a doctest would be an error)
/// impl<T, U> TryFrom<U> for T where U: Into<T> {
///     type Error = Infallible;
///
///     fn try_from(value: U) -> Result<Self, Infallible> {
///         Ok(U::into(value))  // Never returns `Err`
///     }
/// }
/// ```
///
/// # Future compatibiliteit
///
/// Deze enum heeft dezelfde rol als [the `!`“never”type][never], die instabiel is in deze versie van Rust.
/// Wanneer `!` gestabiliseerd is, zijn we van plan om van `Infallible` een type-alias te maken:
///
/// ```ignore (illustrates future std change)
/// pub type Infallible = !;
/// ```
///
/// …En uiteindelijk wordt `Infallible` afgekeurd.
///
/// Er is echter één geval waarin de `!`-syntaxis kan worden gebruikt voordat `!` is gestabiliseerd als een volwaardig type: in de positie van het retourtype van een functie.
/// Concreet zijn het mogelijke implementaties voor twee verschillende functieaanwijzertypes:
///
/// ```
/// trait MyTrait {}
/// impl MyTrait for fn() -> ! {}
/// impl MyTrait for fn() -> std::convert::Infallible {}
/// ```
///
/// Omdat `Infallible` een opsomming is, is deze code geldig.
/// Wanneer `Infallible` echter een alias wordt voor de never type, zullen de twee `impl`s elkaar gaan overlappen en zullen daarom niet worden toegestaan door de trait coherentieregels van de taal.
///
///
///
///
///
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[derive(Copy)]
pub enum Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Clone for Infallible {
    fn clone(&self) -> Infallible {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Debug for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Display for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialEq for Infallible {
    fn eq(&self, _: &Infallible) -> bool {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Eq for Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialOrd for Infallible {
    fn partial_cmp(&self, _other: &Self) -> Option<crate::cmp::Ordering> {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Ord for Infallible {
    fn cmp(&self, _other: &Self) -> crate::cmp::Ordering {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl From<!> for Infallible {
    fn from(x: !) -> Self {
        x
    }
}

#[stable(feature = "convert_infallible_hash", since = "1.44.0")]
impl Hash for Infallible {
    fn hash<H: Hasher>(&self, _: &mut H) {
        match *self {}
    }
}