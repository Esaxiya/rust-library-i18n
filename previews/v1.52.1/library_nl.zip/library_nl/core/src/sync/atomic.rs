//! Atoomtypes
//!
//! Atoomtypen bieden primitieve communicatie met gedeeld geheugen tussen threads en zijn de bouwstenen van andere gelijktijdige typen.
//!
//! Deze module definieert atomaire versies van een select aantal primitieve typen, waaronder [`AtomicBool`], [`AtomicIsize`], [`AtomicUsize`], [`AtomicI8`], [`AtomicU16`], enz.
//! Atoomtypen presenteren bewerkingen die, indien correct gebruikt, updates tussen threads synchroniseren.
//!
//! Elke methode heeft een [`Ordering`] nodig die de sterkte van de geheugenbarrière voor die bewerking vertegenwoordigt.Deze volgorde is hetzelfde als de [C++20 atomic orderings][1].Zie de [nomicon][2] voor meer informatie.
//!
//! [1]: https://en.cppreference.com/w/cpp/atomic/memory_order
//! [2]: ../../../nomicon/atomics.html
//!
//! Atoomvariabelen kunnen veilig worden gedeeld tussen threads (ze implementeren [`Sync`]), maar ze bieden zelf niet het mechanisme voor het delen en volgen de [threading model](../../../std/thread/index.html#the-threading-model) van Rust.
//!
//! De meest gebruikelijke manier om een atomaire variabele te delen, is door deze in een [`Arc`][arc] te plaatsen (een gedeelde pointer met atomaire referentie).
//!
//! [arc]: ../../../std/sync/struct.Arc.html
//!
//! Atoomtypen kunnen worden opgeslagen in statische variabelen, geïnitialiseerd met behulp van de constante initializers zoals [`AtomicBool::new`].Atoomstatica worden vaak gebruikt voor luie globale initialisatie.
//!
//! # Portability
//!
//! Alle atomaire typen in deze module zijn gegarandeerd [lock-free] als ze beschikbaar zijn.Dit betekent dat ze intern geen globale mutex krijgen.Atoomtypes en operaties zijn niet gegarandeerd wachtvrij.
//! Dit betekent dat bewerkingen zoals `fetch_or` kunnen worden geïmplementeerd met een vergelijk-en-wissel-lus.
//!
//! Atoombewerkingen kunnen worden geïmplementeerd op de instructielaag met atomen van grotere afmetingen.Sommige platforms gebruiken bijvoorbeeld atomaire instructies van 4 bytes om `AtomicI8` te implementeren.
//! Merk op dat deze emulatie geen invloed mag hebben op de juistheid van de code, het is gewoon iets om op te letten.
//!
//! De atomaire typen in deze module zijn mogelijk niet op alle platforms beschikbaar.De atoomtypen zijn hier echter allemaal algemeen verkrijgbaar en kunnen in het algemeen op bestaande worden vertrouwd.Enkele opmerkelijke uitzonderingen zijn:
//!
//! * PowerPC en MIPS-platforms met 32-bits aanwijzers hebben geen `AtomicU64`-of `AtomicI64`-typen.
//! * ARM platforms zoals `armv5te` die niet voor Linux zijn, bieden alleen `load`-en `store`-bewerkingen en ondersteunen geen Compare en Swap (CAS)-bewerkingen, zoals `swap`, `fetch_add`, enz.
//! Bovendien worden deze CAS-bewerkingen op Linux geïmplementeerd via [operating system support], wat mogelijk een prestatieverlies met zich meebrengt.
//! * ARM doelen met `thumbv6m` bieden alleen `load`-en `store`-bewerkingen en bieden geen ondersteuning voor Compare en Swap (CAS)-bewerkingen, zoals `swap`, `fetch_add`, enz.
//!
//! [operating system support]: https://www.kernel.org/doc/Documentation/arm/kernel_user_helpers.txt
//!
//! Merk op dat future-platforms kunnen worden toegevoegd die ook geen ondersteuning bieden voor sommige atomaire bewerkingen.Maximaal draagbare code zal voorzichtig willen zijn met welke atomaire typen worden gebruikt.
//! `AtomicUsize` en `AtomicIsize` zijn over het algemeen de meest draagbare, maar zelfs dan zijn ze niet overal verkrijgbaar.
//! Ter referentie: de `std`-bibliotheek vereist atomics ter grootte van een pointer, hoewel `core` dat niet doet.
//!
//! Momenteel moet u `#[cfg(target_arch)]` voornamelijk gebruiken om voorwaardelijk in code te compileren met atomics.Er is ook een onstabiele `#[cfg(target_has_atomic)]` die mogelijk wordt gestabiliseerd in de future.
//!
//! [lock-free]: https://en.wikipedia.org/wiki/Non-blocking_algorithm
//!
//! # Examples
//!
//! Een simpele spinlock:
//!
//! ```
//! use std::sync::Arc;
//! use std::sync::atomic::{AtomicUsize, Ordering};
//! use std::thread;
//!
//! fn main() {
//!     let spinlock = Arc::new(AtomicUsize::new(1));
//!
//!     let spinlock_clone = Arc::clone(&spinlock);
//!     let thread = thread::spawn(move|| {
//!         spinlock_clone.store(0, Ordering::SeqCst);
//!     });
//!
//!     // Wacht tot de andere draad de vergrendeling loslaat
//!     while spinlock.load(Ordering::SeqCst) != 0 {}
//!
//!     if let Err(panic) = thread.join() {
//!         println!("Thread had an error: {:?}", panic);
//!     }
//! }
//! ```
//!
//! Houd een globale telling van live threads bij:
//!
//! ```
//! use std::sync::atomic::{AtomicUsize, Ordering};
//!
//! static GLOBAL_THREAD_COUNT: AtomicUsize = AtomicUsize::new(0);
//!
//! let old_thread_count = GLOBAL_THREAD_COUNT.fetch_add(1, Ordering::SeqCst);
//! println!("live threads: {}", old_thread_count + 1);
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]
#![cfg_attr(not(target_has_atomic_load_store = "8"), allow(dead_code))]
#![cfg_attr(not(target_has_atomic_load_store = "8"), allow(unused_imports))]

use self::Ordering::*;

use crate::cell::UnsafeCell;
use crate::fmt;
use crate::intrinsics;

use crate::hint::spin_loop;

/// Een booleaans type dat veilig kan worden gedeeld tussen threads.
///
/// Dit type heeft dezelfde weergave in het geheugen als een [`bool`].
///
/// **Opmerking**: dit type is alleen beschikbaar op platforms die atomaire belastingen en winkels van `u8` ondersteunen.
///
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(C, align(1))]
pub struct AtomicBool {
    v: UnsafeCell<u8>,
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
impl Default for AtomicBool {
    /// Maakt een `AtomicBool` die is geïnitialiseerd op `false`.
    #[inline]
    fn default() -> Self {
        Self::new(false)
    }
}

// Verzenden is impliciet geïmplementeerd voor AtomicBool.
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl Sync for AtomicBool {}

/// Een onbewerkt aanwijzertype dat veilig kan worden gedeeld tussen threads.
///
/// Dit type heeft dezelfde weergave in het geheugen als een `*mut T`.
///
/// **Opmerking**: dit type is alleen beschikbaar op platforms die atoombelastingen en winkels met pointers ondersteunen.
/// De grootte is afhankelijk van de grootte van de doelaanwijzer.
#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(target_pointer_width = "16", repr(C, align(2)))]
#[cfg_attr(target_pointer_width = "32", repr(C, align(4)))]
#[cfg_attr(target_pointer_width = "64", repr(C, align(8)))]
pub struct AtomicPtr<T> {
    p: UnsafeCell<*mut T>,
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for AtomicPtr<T> {
    /// Creëert een nul `AtomicPtr<T>`.
    fn default() -> AtomicPtr<T> {
        AtomicPtr::new(crate::ptr::null_mut())
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T> Send for AtomicPtr<T> {}
#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T> Sync for AtomicPtr<T> {}

/// Atomaire geheugenvolgorde
///
/// Geheugenvolgorde specificeert de manier waarop atomaire bewerkingen het geheugen synchroniseren.
/// In zijn zwakste [`Ordering::Relaxed`] wordt alleen het geheugen dat rechtstreeks door de bewerking wordt aangeraakt, gesynchroniseerd.
/// Aan de andere kant synchroniseert een store-load paar [`Ordering::SeqCst`]-bewerkingen ander geheugen terwijl bovendien de totale volgorde van dergelijke bewerkingen over alle threads wordt behouden.
///
///
/// De geheugenvolgorde van Rust is [the same as those of C++20](https://en.cppreference.com/w/cpp/atomic/memory_order).
///
/// Zie de [nomicon] voor meer informatie.
///
/// [nomicon]: ../../../nomicon/atomics.html
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone, Debug, Eq, PartialEq, Hash)]
#[non_exhaustive]
pub enum Ordering {
    /// Geen ordeningsbeperkingen, alleen atomaire bewerkingen.
    ///
    /// Komt overeen met [`memory_order_relaxed`] in C++ 20.
    ///
    /// [`memory_order_relaxed`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Relaxed_ordering
    #[stable(feature = "rust1", since = "1.0.0")]
    Relaxed,
    /// Indien gekoppeld aan een winkel, worden alle voorgaande bewerkingen geordend vóór elke lading van deze waarde met [`Acquire`] (of sterkere) bestelling.
    ///
    /// In het bijzonder worden alle eerdere schrijfbewerkingen zichtbaar voor alle threads die een [`Acquire`] (of sterkere) belasting van deze waarde uitvoeren.
    ///
    /// Merk op dat het gebruik van deze volgorde voor een bewerking die belastingen en opslag combineert, leidt tot een [`Relaxed`]-laadbewerking!
    ///
    /// Deze volgorde is alleen van toepassing op bewerkingen die een winkel kunnen uitvoeren.
    ///
    /// Komt overeen met [`memory_order_release`] in C++ 20.
    ///
    /// [`memory_order_release`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    Release,
    /// Indien gekoppeld aan een belasting, als de geladen waarde is geschreven door een winkelbewerking met [`Release`] (of sterkere) volgorde, dan worden alle volgende bewerkingen geordend na die winkel.
    /// In het bijzonder zullen bij alle volgende ladingen gegevens vóór de opslag worden geschreven.
    ///
    /// Merk op dat het gebruik van deze volgorde voor een bewerking die belastingen en opslag combineert, leidt tot een [`Relaxed`]-winkelbewerking!
    ///
    /// Deze volgorde is alleen van toepassing op bewerkingen die een belasting kunnen uitvoeren.
    ///
    /// Komt overeen met [`memory_order_acquire`] in C++ 20.
    ///
    /// [`memory_order_acquire`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    Acquire,
    /// Heeft de effecten van zowel [`Acquire`] als [`Release`] samen:
    /// Voor ladingen gebruikt het [`Acquire`]-ordening.Voor winkels gebruikt het de [`Release`]-volgorde.
    ///
    /// Merk op dat het in het geval van `compare_and_swap` mogelijk is dat de bewerking uiteindelijk geen enkele winkel uitvoert en daarom alleen [`Acquire`]-bestelling heeft.
    ///
    /// `AcqRel` zal echter nooit [`Relaxed`]-toegangen uitvoeren.
    ///
    /// Deze volgorde is alleen van toepassing op bewerkingen waarbij zowel ladingen als winkels worden gecombineerd.
    ///
    /// Komt overeen met [`memory_order_acq_rel`] in C++ 20.
    ///
    /// [`memory_order_acq_rel`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    #[stable(feature = "rust1", since = "1.0.0")]
    AcqRel,
    /// Zoals [`Acquire`]/[`Release`]/[`AcqRel`](voor respectievelijk laden, opslaan en laden met opslaan) met de extra garantie dat alle threads alle opeenvolgend consistente bewerkingen in dezelfde volgorde zien .
    ///
    ///
    /// Komt overeen met [`memory_order_seq_cst`] in C++ 20.
    ///
    /// [`memory_order_seq_cst`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Sequentially-consistent_ordering
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    SeqCst,
}

/// Een [`AtomicBool`] geïnitialiseerd naar `false`.
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "1.34.0",
    reason = "the `new` function is now preferred",
    suggestion = "AtomicBool::new(false)"
)]
pub const ATOMIC_BOOL_INIT: AtomicBool = AtomicBool::new(false);

#[cfg(target_has_atomic_load_store = "8")]
impl AtomicBool {
    /// Maakt een nieuwe `AtomicBool`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    ///
    /// let atomic_true  = AtomicBool::new(true);
    /// let atomic_false = AtomicBool::new(false);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_atomic_new", since = "1.32.0")]
    pub const fn new(v: bool) -> AtomicBool {
        AtomicBool { v: UnsafeCell::new(v as u8) }
    }

    /// Retourneert een veranderlijke verwijzing naar de onderliggende [`bool`].
    ///
    /// Dit is veilig omdat de veranderlijke referentie garandeert dat geen andere threads gelijktijdig toegang hebben tot de atomaire gegevens.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let mut some_bool = AtomicBool::new(true);
    /// assert_eq!(*some_bool.get_mut(), true);
    /// *some_bool.get_mut() = false;
    /// assert_eq!(some_bool.load(Ordering::SeqCst), false);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    pub fn get_mut(&mut self) -> &mut bool {
        // VEILIGHEID: de veranderlijke referentie garandeert uniek eigendom.
        unsafe { &mut *(self.v.get() as *mut bool) }
    }

    /// Krijg atomaire toegang tot een `&mut bool`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(atomic_from_mut)]
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let mut some_bool = true;
    /// let a = AtomicBool::from_mut(&mut some_bool);
    /// a.store(false, Ordering::Relaxed);
    /// assert_eq!(some_bool, false);
    /// ```
    #[inline]
    #[cfg(target_has_atomic_equal_alignment = "8")]
    #[unstable(feature = "atomic_from_mut", issue = "76314")]
    pub fn from_mut(v: &mut bool) -> &Self {
        // VEILIGHEID: de veranderlijke referentie garandeert uniek eigendom, en
        // uitlijning van zowel `bool` als `Self` is 1.
        unsafe { &*(v as *mut bool as *mut Self) }
    }

    /// Verbruikt het atomaire en retourneert de ingesloten waarde.
    ///
    /// Dit is veilig omdat het doorgeven van `self` op waarde garandeert dat geen andere threads gelijktijdig toegang hebben tot de atomaire gegevens.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    ///
    /// let some_bool = AtomicBool::new(true);
    /// assert_eq!(some_bool.into_inner(), true);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> bool {
        self.v.into_inner() != 0
    }

    /// Laadt een waarde uit de bool.
    ///
    /// `load` neemt een [`Ordering`]-argument dat de geheugenvolgorde van deze bewerking beschrijft.
    /// Mogelijke waarden zijn [`SeqCst`], [`Acquire`] en [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics als `order` [`Release`] of [`AcqRel`] is.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.load(Ordering::Relaxed), true);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn load(&self, order: Ordering) -> bool {
        // VEILIGHEID: alle dataraces worden voorkomen door atomaire intrinsiek en het ruwe
        // doorgegeven pointer is geldig omdat we het uit een referentie hebben gehaald.
        unsafe { atomic_load(self.v.get(), order) != 0 }
    }

    /// Slaat een waarde op in de bool.
    ///
    /// `store` neemt een [`Ordering`]-argument dat de geheugenvolgorde van deze bewerking beschrijft.
    /// Mogelijke waarden zijn [`SeqCst`], [`Release`] en [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics als `order` [`Acquire`] of [`AcqRel`] is.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// some_bool.store(false, Ordering::Relaxed);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn store(&self, val: bool, order: Ordering) {
        // VEILIGHEID: alle dataraces worden voorkomen door atomaire intrinsiek en het ruwe
        // doorgegeven pointer is geldig omdat we het uit een referentie hebben gehaald.
        unsafe {
            atomic_store(self.v.get(), val as u8, order);
        }
    }

    /// Slaat een waarde op in de bool en retourneert de vorige waarde.
    ///
    /// `swap` neemt een [`Ordering`]-argument dat de geheugenvolgorde van deze bewerking beschrijft.Alle bestelmodi zijn mogelijk.
    /// Merk op dat het gebruik van [`Acquire`] het opslaan onderdeel maakt van deze bewerking [`Relaxed`], en het gebruik van [`Release`] maakt het laadgedeelte [`Relaxed`].
    ///
    ///
    /// **Note:** Deze methode is alleen beschikbaar op platforms die atomaire bewerkingen op `u8` ondersteunen.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.swap(false, Ordering::Relaxed), true);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn swap(&self, val: bool, order: Ordering) -> bool {
        // VEILIGHEID: dataraces worden voorkomen door atomaire intrinsiek.
        unsafe { atomic_swap(self.v.get(), val as u8, order) != 0 }
    }

    /// Slaat een waarde op in de [`bool`] als de huidige waarde hetzelfde is als de `current`-waarde.
    ///
    /// De geretourneerde waarde is altijd de vorige waarde.Als het gelijk is aan `current`, is de waarde bijgewerkt.
    ///
    /// `compare_and_swap` accepteert ook een [`Ordering`]-argument dat de geheugenvolgorde van deze bewerking beschrijft.
    /// Merk op dat zelfs wanneer [`AcqRel`] wordt gebruikt, de bewerking kan mislukken en daarom alleen een `Acquire`-belasting kan uitvoeren, maar geen `Release`-semantiek heeft.
    /// Het gebruik van [`Acquire`] maakt het opslaan onderdeel van deze bewerking [`Relaxed`] als het gebeurt, en het gebruik van [`Release`] maakt het laadgedeelte [`Relaxed`].
    ///
    /// **Note:** Deze methode is alleen beschikbaar op platforms die atomaire bewerkingen op `u8` ondersteunen.
    ///
    /// # Migreren naar `compare_exchange` en `compare_exchange_weak`
    ///
    /// `compare_and_swap` is gelijk aan `compare_exchange` met de volgende toewijzing voor geheugenvolgorde:
    ///
    /// Origineel |Succes |Mislukking
    /// -------- | ------- | -------
    /// Ontspannen |Ontspannen |Ontspannen verwerven |Verwerven |Verkrijg release |Vrijgeven |Ontspannen AcqRel |AcqRel |Koop SeqCst |SeqCst |SeqCst
    ///
    /// `compare_exchange_weak` kan oneigenlijk mislukken, zelfs als de vergelijking slaagt, waardoor de compiler betere assemblagecode kan genereren wanneer de compar en swap in een lus wordt gebruikt.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.compare_and_swap(true, false, Ordering::Relaxed), true);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    ///
    /// assert_eq!(some_bool.compare_and_swap(true, true, Ordering::Relaxed), false);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.50.0",
        reason = "Use `compare_exchange` or `compare_exchange_weak` instead"
    )]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_and_swap(&self, current: bool, new: bool, order: Ordering) -> bool {
        match self.compare_exchange(current, new, order, strongest_failure_ordering(order)) {
            Ok(x) => x,
            Err(x) => x,
        }
    }

    /// Slaat een waarde op in de [`bool`] als de huidige waarde hetzelfde is als de `current`-waarde.
    ///
    /// De geretourneerde waarde is een resultaat dat aangeeft of de nieuwe waarde is geschreven en de vorige waarde bevat.
    /// Bij succes is deze waarde gegarandeerd gelijk aan `current`.
    ///
    /// `compare_exchange` heeft twee [`Ordering`]-argumenten nodig om de geheugenvolgorde van deze bewerking te beschrijven.
    /// `success` beschrijft de vereiste volgorde voor de lees-wijzig-schrijfbewerking die plaatsvindt als de vergelijking met `current` slaagt.
    /// `failure` beschrijft de vereiste volgorde voor de laadbewerking die plaatsvindt wanneer de vergelijking mislukt.
    /// Door [`Acquire`] als succesbestelling te gebruiken, maakt de winkel deel uit van deze operatie [`Relaxed`], en door [`Release`] te gebruiken, wordt [`Relaxed`] succesvol geladen.
    ///
    /// De volgorde van fouten kan alleen [`SeqCst`], [`Acquire`] of [`Relaxed`] zijn en moet gelijk of zwakker zijn dan de bestelling met succes.
    ///
    /// **Note:** Deze methode is alleen beschikbaar op platforms die atomaire bewerkingen op `u8` ondersteunen.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.compare_exchange(true,
    ///                                       false,
    ///                                       Ordering::Acquire,
    ///                                       Ordering::Relaxed),
    ///            Ok(true));
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    ///
    /// assert_eq!(some_bool.compare_exchange(true, true,
    ///                                       Ordering::SeqCst,
    ///                                       Ordering::Acquire),
    ///            Err(false));
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[doc(alias = "compare_and_swap")]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_exchange(
        &self,
        current: bool,
        new: bool,
        success: Ordering,
        failure: Ordering,
    ) -> Result<bool, bool> {
        // VEILIGHEID: dataraces worden voorkomen door atomaire intrinsiek.
        match unsafe {
            atomic_compare_exchange(self.v.get(), current as u8, new as u8, success, failure)
        } {
            Ok(x) => Ok(x != 0),
            Err(x) => Err(x != 0),
        }
    }

    /// Slaat een waarde op in de [`bool`] als de huidige waarde hetzelfde is als de `current`-waarde.
    ///
    /// In tegenstelling tot [`AtomicBool::compare_exchange`] is het toegestaan dat deze functie oneigenlijk faalt, zelfs als de vergelijking slaagt, wat kan resulteren in efficiëntere code op sommige platforms.
    ///
    /// De geretourneerde waarde is een resultaat dat aangeeft of de nieuwe waarde is geschreven en de vorige waarde bevat.
    ///
    /// `compare_exchange_weak` heeft twee [`Ordering`]-argumenten nodig om de geheugenvolgorde van deze bewerking te beschrijven.
    /// `success` beschrijft de vereiste volgorde voor de lees-wijzig-schrijfbewerking die plaatsvindt als de vergelijking met `current` slaagt.
    /// `failure` beschrijft de vereiste volgorde voor de laadbewerking die plaatsvindt wanneer de vergelijking mislukt.
    /// Door [`Acquire`] als succesbestelling te gebruiken, maakt de winkel deel uit van deze operatie [`Relaxed`], en door [`Release`] te gebruiken, wordt [`Relaxed`] succesvol geladen.
    /// De volgorde van fouten kan alleen [`SeqCst`], [`Acquire`] of [`Relaxed`] zijn en moet gelijk of zwakker zijn dan de bestelling met succes.
    ///
    /// **Note:** Deze methode is alleen beschikbaar op platforms die atomaire bewerkingen op `u8` ondersteunen.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let val = AtomicBool::new(false);
    ///
    /// let new = true;
    /// let mut old = val.load(Ordering::Relaxed);
    /// loop {
    ///     match val.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) {
    ///         Ok(_) => break,
    ///         Err(x) => old = x,
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[doc(alias = "compare_and_swap")]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_exchange_weak(
        &self,
        current: bool,
        new: bool,
        success: Ordering,
        failure: Ordering,
    ) -> Result<bool, bool> {
        // VEILIGHEID: dataraces worden voorkomen door atomaire intrinsiek.
        match unsafe {
            atomic_compare_exchange_weak(self.v.get(), current as u8, new as u8, success, failure)
        } {
            Ok(x) => Ok(x != 0),
            Err(x) => Err(x != 0),
        }
    }

    /// Logische "and" met een booleaanse waarde.
    ///
    /// Voert een logische "and"-bewerking uit op de huidige waarde en het argument `val`, en stelt de nieuwe waarde in op het resultaat.
    ///
    /// Retourneert de vorige waarde.
    ///
    /// `fetch_and` neemt een [`Ordering`]-argument dat de geheugenvolgorde van deze bewerking beschrijft.Alle bestelmodi zijn mogelijk.
    /// Merk op dat het gebruik van [`Acquire`] het opslaan onderdeel maakt van deze bewerking [`Relaxed`], en het gebruik van [`Release`] maakt het laadgedeelte [`Relaxed`].
    ///
    ///
    /// **Note:** Deze methode is alleen beschikbaar op platforms die atomaire bewerkingen op `u8` ondersteunen.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_and(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_and(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_and(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_and(&self, val: bool, order: Ordering) -> bool {
        // VEILIGHEID: dataraces worden voorkomen door atomaire intrinsiek.
        unsafe { atomic_and(self.v.get(), val as u8, order) != 0 }
    }

    /// Logische "nand" met een booleaanse waarde.
    ///
    /// Voert een logische "nand"-bewerking uit op de huidige waarde en het argument `val`, en stelt de nieuwe waarde in op het resultaat.
    ///
    /// Retourneert de vorige waarde.
    ///
    /// `fetch_nand` neemt een [`Ordering`]-argument dat de geheugenvolgorde van deze bewerking beschrijft.Alle bestelmodi zijn mogelijk.
    /// Merk op dat het gebruik van [`Acquire`] het opslaan onderdeel maakt van deze bewerking [`Relaxed`], en het gebruik van [`Release`] maakt het laadgedeelte [`Relaxed`].
    ///
    ///
    /// **Note:** Deze methode is alleen beschikbaar op platforms die atomaire bewerkingen op `u8` ondersteunen.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_nand(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_nand(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst) as usize, 0);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_nand(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_nand(&self, val: bool, order: Ordering) -> bool {
        // We kunnen hier atomic_nand niet gebruiken omdat dit kan resulteren in een bool met een ongeldige waarde.
        // Dit gebeurt omdat de atomaire bewerking intern wordt uitgevoerd met een 8-bits geheel getal, waarmee de bovenste 7 bits worden ingesteld.
        //
        // Dus gebruiken we gewoon fetch_xor of swap.
        if val {
            // ! (x&true)== !x We moeten de bool omkeren.
            //
            self.fetch_xor(true, order)
        } else {
            // ! (x&false)==true We moeten de bool op true zetten.
            //
            self.swap(true, order)
        }
    }

    /// Logische "or" met een booleaanse waarde.
    ///
    /// Voert een logische "or"-bewerking uit op de huidige waarde en het argument `val`, en stelt de nieuwe waarde in op het resultaat.
    ///
    /// Retourneert de vorige waarde.
    ///
    /// `fetch_or` neemt een [`Ordering`]-argument dat de geheugenvolgorde van deze bewerking beschrijft.Alle bestelmodi zijn mogelijk.
    /// Merk op dat het gebruik van [`Acquire`] het opslaan onderdeel maakt van deze bewerking [`Relaxed`], en het gebruik van [`Release`] maakt het laadgedeelte [`Relaxed`].
    ///
    ///
    /// **Note:** Deze methode is alleen beschikbaar op platforms die atomaire bewerkingen op `u8` ondersteunen.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_or(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_or(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_or(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_or(&self, val: bool, order: Ordering) -> bool {
        // VEILIGHEID: dataraces worden voorkomen door atomaire intrinsiek.
        unsafe { atomic_or(self.v.get(), val as u8, order) != 0 }
    }

    /// Logische "xor" met een booleaanse waarde.
    ///
    /// Voert een logische "xor"-bewerking uit op de huidige waarde en het argument `val`, en stelt de nieuwe waarde in op het resultaat.
    ///
    /// Retourneert de vorige waarde.
    ///
    /// `fetch_xor` neemt een [`Ordering`]-argument dat de geheugenvolgorde van deze bewerking beschrijft.Alle bestelmodi zijn mogelijk.
    /// Merk op dat het gebruik van [`Acquire`] het opslaan onderdeel maakt van deze bewerking [`Relaxed`], en het gebruik van [`Release`] maakt het laadgedeelte [`Relaxed`].
    ///
    ///
    /// **Note:** Deze methode is alleen beschikbaar op platforms die atomaire bewerkingen op `u8` ondersteunen.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_xor(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_xor(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_xor(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_xor(&self, val: bool, order: Ordering) -> bool {
        // VEILIGHEID: dataraces worden voorkomen door atomaire intrinsiek.
        unsafe { atomic_xor(self.v.get(), val as u8, order) != 0 }
    }

    /// Retourneert een veranderlijke pointer naar de onderliggende [`bool`].
    ///
    /// Het niet-atomaire lezen en schrijven van het resulterende gehele getal kan een gegevensrace zijn.
    /// Deze methode is vooral handig voor FFI, waar de functiehandtekening `*mut bool` kan gebruiken in plaats van `&AtomicBool`.
    ///
    /// Het retourneren van een `*mut`-pointer van een gedeelde verwijzing naar deze atomaire is veilig omdat de atomaire typen werken met interne veranderlijkheid.
    /// Alle wijzigingen van een atomair veranderen de waarde via een gedeelde referentie, en kunnen dit veilig doen zolang ze atomaire operaties gebruiken.
    /// Elk gebruik van de geretourneerde onbewerkte pointer vereist een `unsafe`-blok en moet nog steeds dezelfde beperking handhaven: bewerkingen erop moeten atomair zijn.
    ///
    ///
    /// # Examples
    ///
    /// ```ignore (extern-declaration)
    /// # fn main() {
    /// use std::sync::atomic::AtomicBool;
    /// extern "C" {
    ///     fn my_atomic_op(arg: *mut bool);
    /// }
    ///
    /// let mut atomic = AtomicBool::new(true);
    /// unsafe {
    ///     my_atomic_op(atomic.as_mut_ptr());
    /// }
    /// # }
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_mut_ptr", reason = "recently added", issue = "66893")]
    pub fn as_mut_ptr(&self) -> *mut bool {
        self.v.get() as *mut bool
    }

    /// Haalt de waarde op en past er een functie op toe die een optionele nieuwe waarde retourneert.Retourneert een `Result` van `Ok(previous_value)` als de functie `Some(_)` retourneert, anders `Err(previous_value)`.
    ///
    /// Note: Dit kan de functie meerdere keren aanroepen als de waarde in de tussentijd is gewijzigd van andere threads, zolang de functie `Some(_)` retourneert, maar de functie is slechts één keer toegepast op de opgeslagen waarde.
    ///
    ///
    /// `fetch_update` heeft twee [`Ordering`]-argumenten nodig om de geheugenvolgorde van deze bewerking te beschrijven.
    /// De eerste beschrijft de vereiste volgorde voor wanneer de operatie uiteindelijk slaagt, terwijl de tweede de vereiste bestelling voor ladingen beschrijft.
    /// Deze komen overeen met respectievelijk de volgorde van succes en mislukking van [`AtomicBool::compare_exchange`].
    ///
    /// Door [`Acquire`] als succesbestelling te gebruiken, maakt de winkel deel uit van deze operatie [`Relaxed`], en door [`Release`] te gebruiken, laadt de laatste succesvolle [`Relaxed`].
    /// De (failed)-laadvolgorde kan alleen [`SeqCst`], [`Acquire`] of [`Relaxed`] zijn en moet gelijk of zwakker zijn dan de succesvolle bestelling.
    ///
    /// **Note:** Deze methode is alleen beschikbaar op platforms die atomaire bewerkingen op `u8` ondersteunen.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(atomic_fetch_update)]
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let x = AtomicBool::new(false);
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(false));
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| Some(!x)), Ok(false));
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| Some(!x)), Ok(true));
    /// assert_eq!(x.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_fetch_update", reason = "recently added", issue = "78639")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_update<F>(
        &self,
        set_order: Ordering,
        fetch_order: Ordering,
        mut f: F,
    ) -> Result<bool, bool>
    where
        F: FnMut(bool) -> Option<bool>,
    {
        let mut prev = self.load(fetch_order);
        while let Some(next) = f(prev) {
            match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                x @ Ok(_) => return x,
                Err(next_prev) => prev = next_prev,
            }
        }
        Err(prev)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
impl<T> AtomicPtr<T> {
    /// Maakt een nieuwe `AtomicPtr`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicPtr;
    ///
    /// let ptr = &mut 5;
    /// let atomic_ptr  = AtomicPtr::new(ptr);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_atomic_new", since = "1.32.0")]
    pub const fn new(p: *mut T) -> AtomicPtr<T> {
        AtomicPtr { p: UnsafeCell::new(p) }
    }

    /// Retourneert een veranderlijke verwijzing naar de onderliggende aanwijzer.
    ///
    /// Dit is veilig omdat de veranderlijke referentie garandeert dat geen andere threads gelijktijdig toegang hebben tot de atomaire gegevens.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let mut atomic_ptr = AtomicPtr::new(&mut 10);
    /// *atomic_ptr.get_mut() = &mut 5;
    /// assert_eq!(unsafe { *atomic_ptr.load(Ordering::SeqCst) }, 5);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    pub fn get_mut(&mut self) -> &mut *mut T {
        self.p.get_mut()
    }

    /// Krijg atomaire toegang tot een aanwijzer.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(atomic_from_mut)]
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let mut some_ptr = &mut 123 as *mut i32;
    /// let a = AtomicPtr::from_mut(&mut some_ptr);
    /// a.store(&mut 456, Ordering::Relaxed);
    /// assert_eq!(unsafe { *some_ptr }, 456);
    /// ```
    #[inline]
    #[cfg(target_has_atomic_equal_alignment = "ptr")]
    #[unstable(feature = "atomic_from_mut", issue = "76314")]
    pub fn from_mut(v: &mut *mut T) -> &Self {
        use crate::mem::align_of;
        let [] = [(); align_of::<AtomicPtr<()>>() - align_of::<*mut ()>()];
        // SAFETY:
        //  - de veranderlijke referentie garandeert uniek eigendom.
        //  - de uitlijning van `*mut T` en `Self` is hetzelfde op alle platforms die worden ondersteund door rust, zoals hierboven geverifieerd.
        //
        unsafe { &*(v as *mut *mut T as *mut Self) }
    }

    /// Verbruikt het atomaire en retourneert de ingesloten waarde.
    ///
    /// Dit is veilig omdat het doorgeven van `self` op waarde garandeert dat geen andere threads gelijktijdig toegang hebben tot de atomaire gegevens.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicPtr;
    ///
    /// let atomic_ptr = AtomicPtr::new(&mut 5);
    /// assert_eq!(unsafe { *atomic_ptr.into_inner() }, 5);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> *mut T {
        self.p.into_inner()
    }

    /// Laadt een waarde uit de aanwijzer.
    ///
    /// `load` neemt een [`Ordering`]-argument dat de geheugenvolgorde van deze bewerking beschrijft.
    /// Mogelijke waarden zijn [`SeqCst`], [`Acquire`] en [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics als `order` [`Release`] of [`AcqRel`] is.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let value = some_ptr.load(Ordering::Relaxed);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn load(&self, order: Ordering) -> *mut T {
        // VEILIGHEID: dataraces worden voorkomen door atomaire intrinsiek.
        unsafe { atomic_load(self.p.get(), order) }
    }

    /// Slaat een waarde op in de aanwijzer.
    ///
    /// `store` neemt een [`Ordering`]-argument dat de geheugenvolgorde van deze bewerking beschrijft.
    /// Mogelijke waarden zijn [`SeqCst`], [`Release`] en [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics als `order` [`Acquire`] of [`AcqRel`] is.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr = &mut 10;
    ///
    /// some_ptr.store(other_ptr, Ordering::Relaxed);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn store(&self, ptr: *mut T, order: Ordering) {
        // VEILIGHEID: dataraces worden voorkomen door atomaire intrinsiek.
        unsafe {
            atomic_store(self.p.get(), ptr, order);
        }
    }

    /// Slaat een waarde op in de aanwijzer en retourneert de vorige waarde.
    ///
    /// `swap` neemt een [`Ordering`]-argument dat de geheugenvolgorde van deze bewerking beschrijft.Alle bestelmodi zijn mogelijk.
    /// Merk op dat het gebruik van [`Acquire`] het opslaan onderdeel maakt van deze bewerking [`Relaxed`], en het gebruik van [`Release`] maakt het laadgedeelte [`Relaxed`].
    ///
    ///
    /// **Note:** Deze methode is alleen beschikbaar op platforms die atomaire bewerkingen op pointers ondersteunen.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr = &mut 10;
    ///
    /// let value = some_ptr.swap(other_ptr, Ordering::Relaxed);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn swap(&self, ptr: *mut T, order: Ordering) -> *mut T {
        // VEILIGHEID: dataraces worden voorkomen door atomaire intrinsiek.
        unsafe { atomic_swap(self.p.get(), ptr, order) }
    }

    /// Slaat een waarde op in de aanwijzer als de huidige waarde hetzelfde is als de `current`-waarde.
    ///
    /// De geretourneerde waarde is altijd de vorige waarde.Als het gelijk is aan `current`, is de waarde bijgewerkt.
    ///
    /// `compare_and_swap` accepteert ook een [`Ordering`]-argument dat de geheugenvolgorde van deze bewerking beschrijft.
    /// Merk op dat zelfs wanneer [`AcqRel`] wordt gebruikt, de bewerking kan mislukken en daarom alleen een `Acquire`-belasting kan uitvoeren, maar geen `Release`-semantiek heeft.
    /// Het gebruik van [`Acquire`] maakt het opslaan onderdeel van deze bewerking [`Relaxed`] als het gebeurt, en het gebruik van [`Release`] maakt het laadgedeelte [`Relaxed`].
    ///
    /// **Note:** Deze methode is alleen beschikbaar op platforms die atomaire bewerkingen op pointers ondersteunen.
    ///
    /// # Migreren naar `compare_exchange` en `compare_exchange_weak`
    ///
    /// `compare_and_swap` is gelijk aan `compare_exchange` met de volgende toewijzing voor geheugenvolgorde:
    ///
    /// Origineel |Succes |Mislukking
    /// -------- | ------- | -------
    /// Ontspannen |Ontspannen |Ontspannen verwerven |Verwerven |Verkrijg release |Vrijgeven |Ontspannen AcqRel |AcqRel |Koop SeqCst |SeqCst |SeqCst
    ///
    /// `compare_exchange_weak` kan oneigenlijk mislukken, zelfs als de vergelijking slaagt, waardoor de compiler betere assemblagecode kan genereren wanneer de compar en swap in een lus wordt gebruikt.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr   = &mut 10;
    ///
    /// let value = some_ptr.compare_and_swap(ptr, other_ptr, Ordering::Relaxed);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.50.0",
        reason = "Use `compare_exchange` or `compare_exchange_weak` instead"
    )]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_and_swap(&self, current: *mut T, new: *mut T, order: Ordering) -> *mut T {
        match self.compare_exchange(current, new, order, strongest_failure_ordering(order)) {
            Ok(x) => x,
            Err(x) => x,
        }
    }

    /// Slaat een waarde op in de aanwijzer als de huidige waarde hetzelfde is als de `current`-waarde.
    ///
    /// De geretourneerde waarde is een resultaat dat aangeeft of de nieuwe waarde is geschreven en de vorige waarde bevat.
    /// Bij succes is deze waarde gegarandeerd gelijk aan `current`.
    ///
    /// `compare_exchange` heeft twee [`Ordering`]-argumenten nodig om de geheugenvolgorde van deze bewerking te beschrijven.
    /// `success` beschrijft de vereiste volgorde voor de lees-wijzig-schrijfbewerking die plaatsvindt als de vergelijking met `current` slaagt.
    /// `failure` beschrijft de vereiste volgorde voor de laadbewerking die plaatsvindt wanneer de vergelijking mislukt.
    /// Door [`Acquire`] als succesbestelling te gebruiken, maakt de winkel deel uit van deze operatie [`Relaxed`], en door [`Release`] te gebruiken, wordt [`Relaxed`] succesvol geladen.
    ///
    /// De volgorde van fouten kan alleen [`SeqCst`], [`Acquire`] of [`Relaxed`] zijn en moet gelijk of zwakker zijn dan de bestelling met succes.
    ///
    /// **Note:** Deze methode is alleen beschikbaar op platforms die atomaire bewerkingen op pointers ondersteunen.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr   = &mut 10;
    ///
    /// let value = some_ptr.compare_exchange(ptr, other_ptr,
    ///                                       Ordering::SeqCst, Ordering::Relaxed);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_exchange(
        &self,
        current: *mut T,
        new: *mut T,
        success: Ordering,
        failure: Ordering,
    ) -> Result<*mut T, *mut T> {
        // VEILIGHEID: dataraces worden voorkomen door atomaire intrinsiek.
        unsafe { atomic_compare_exchange(self.p.get(), current, new, success, failure) }
    }

    /// Slaat een waarde op in de aanwijzer als de huidige waarde hetzelfde is als de `current`-waarde.
    ///
    /// In tegenstelling tot [`AtomicPtr::compare_exchange`] is het toegestaan dat deze functie oneigenlijk faalt, zelfs als de vergelijking slaagt, wat kan resulteren in efficiëntere code op sommige platforms.
    ///
    /// De geretourneerde waarde is een resultaat dat aangeeft of de nieuwe waarde is geschreven en de vorige waarde bevat.
    ///
    /// `compare_exchange_weak` heeft twee [`Ordering`]-argumenten nodig om de geheugenvolgorde van deze bewerking te beschrijven.
    /// `success` beschrijft de vereiste volgorde voor de lees-wijzig-schrijfbewerking die plaatsvindt als de vergelijking met `current` slaagt.
    /// `failure` beschrijft de vereiste volgorde voor de laadbewerking die plaatsvindt wanneer de vergelijking mislukt.
    /// Door [`Acquire`] als succesbestelling te gebruiken, maakt de winkel deel uit van deze operatie [`Relaxed`], en door [`Release`] te gebruiken, wordt [`Relaxed`] succesvol geladen.
    /// De volgorde van fouten kan alleen [`SeqCst`], [`Acquire`] of [`Relaxed`] zijn en moet gelijk of zwakker zijn dan de bestelling met succes.
    ///
    /// **Note:** Deze methode is alleen beschikbaar op platforms die atomaire bewerkingen op pointers ondersteunen.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let some_ptr = AtomicPtr::new(&mut 5);
    ///
    /// let new = &mut 10;
    /// let mut old = some_ptr.load(Ordering::Relaxed);
    /// loop {
    ///     match some_ptr.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) {
    ///         Ok(_) => break,
    ///         Err(x) => old = x,
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_exchange_weak(
        &self,
        current: *mut T,
        new: *mut T,
        success: Ordering,
        failure: Ordering,
    ) -> Result<*mut T, *mut T> {
        // VEILIGHEID: dit intrinsieke is onveilig omdat het op een onbewerkte aanwijzer werkt
        // maar we weten zeker dat de pointer geldig is (we hebben hem zojuist gekregen van een `UnsafeCell` die we via referentie hebben) en de atomaire bewerking zelf stelt ons in staat om de `UnsafeCell`-inhoud veilig te muteren.
        //
        //
        unsafe { atomic_compare_exchange_weak(self.p.get(), current, new, success, failure) }
    }

    /// Haalt de waarde op en past er een functie op toe die een optionele nieuwe waarde retourneert.Retourneert een `Result` van `Ok(previous_value)` als de functie `Some(_)` retourneert, anders `Err(previous_value)`.
    ///
    /// Note: Dit kan de functie meerdere keren aanroepen als de waarde in de tussentijd is gewijzigd van andere threads, zolang de functie `Some(_)` retourneert, maar de functie is slechts één keer toegepast op de opgeslagen waarde.
    ///
    ///
    /// `fetch_update` heeft twee [`Ordering`]-argumenten nodig om de geheugenvolgorde van deze bewerking te beschrijven.
    /// De eerste beschrijft de vereiste volgorde voor wanneer de operatie uiteindelijk slaagt, terwijl de tweede de vereiste bestelling voor ladingen beschrijft.
    /// Deze komen overeen met respectievelijk de volgorde van succes en mislukking van [`AtomicPtr::compare_exchange`].
    ///
    /// Door [`Acquire`] als succesbestelling te gebruiken, maakt de winkel deel uit van deze operatie [`Relaxed`], en door [`Release`] te gebruiken, laadt de laatste succesvolle [`Relaxed`].
    /// De (failed)-laadvolgorde kan alleen [`SeqCst`], [`Acquire`] of [`Relaxed`] zijn en moet gelijk of zwakker zijn dan de succesvolle bestelling.
    ///
    /// **Note:** Deze methode is alleen beschikbaar op platforms die atomaire bewerkingen op pointers ondersteunen.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(atomic_fetch_update)]
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr: *mut _ = &mut 5;
    /// let some_ptr = AtomicPtr::new(ptr);
    ///
    /// let new: *mut _ = &mut 10;
    /// assert_eq!(some_ptr.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(ptr));
    /// let result = some_ptr.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| {
    ///     if x == ptr {
    ///         Some(new)
    ///     } else {
    ///         None
    ///     }
    /// });
    /// assert_eq!(result, Ok(ptr));
    /// assert_eq!(some_ptr.load(Ordering::SeqCst), new);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_fetch_update", reason = "recently added", issue = "78639")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn fetch_update<F>(
        &self,
        set_order: Ordering,
        fetch_order: Ordering,
        mut f: F,
    ) -> Result<*mut T, *mut T>
    where
        F: FnMut(*mut T) -> Option<*mut T>,
    {
        let mut prev = self.load(fetch_order);
        while let Some(next) = f(prev) {
            match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                x @ Ok(_) => return x,
                Err(next_prev) => prev = next_prev,
            }
        }
        Err(prev)
    }
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "atomic_bool_from", since = "1.24.0")]
impl From<bool> for AtomicBool {
    /// Converteert een `bool` naar een `AtomicBool`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    /// let atomic_bool = AtomicBool::from(true);
    /// assert_eq!(format!("{:?}", atomic_bool), "true")
    /// ```
    #[inline]
    fn from(b: bool) -> Self {
        Self::new(b)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_from", since = "1.23.0")]
impl<T> From<*mut T> for AtomicPtr<T> {
    #[inline]
    fn from(p: *mut T) -> Self {
        Self::new(p)
    }
}

#[allow(unused_macros)] // Deze macro wordt op sommige architecturen niet gebruikt.
macro_rules! if_not_8_bit {
    (u8, $($tt:tt)*) => { "" };
    (i8, $($tt:tt)*) => { "" };
    ($_:ident, $($tt:tt)*) => { $($tt)* };
}

#[cfg(target_has_atomic_load_store = "8")]
macro_rules! atomic_int {
    ($cfg_cas:meta,
     $cfg_align:meta,
     $stable:meta,
     $stable_cxchg:meta,
     $stable_debug:meta,
     $stable_access:meta,
     $stable_from:meta,
     $stable_nand:meta,
     $const_stable:meta,
     $stable_init_const:meta,
     $s_int_type:literal,
     $extra_feature:expr,
     $min_fn:ident, $max_fn:ident,
     $align:expr,
     $atomic_new:expr,
     $int_type:ident $atomic_type:ident $atomic_init:ident) => {
        /// Een integer-type dat veilig kan worden gedeeld tussen threads.
        ///
        /// Dit type heeft dezelfde in-memory representatie als het onderliggende integer-type, [`
        ///
        #[doc = $s_int_type]
        /// `].
        /// Zie de [module-level documentation] voor meer informatie over de verschillen tussen atomaire typen en niet-atomaire typen en voor informatie over de draagbaarheid van dit type.
        ///
        ///
        /// **Note:** Dit type is alleen beschikbaar op platforms die atomaire belastingen en winkels van [`
        ///
        #[doc = $s_int_type]
        /// `].
        ///
        /// [module-level documentation]: crate::sync::atomic
        #[$stable]
        #[repr(C, align($align))]
        pub struct $atomic_type {
            v: UnsafeCell<$int_type>,
        }

        /// Een atomair geheel getal dat is geïnitialiseerd op `0`.
        #[$stable_init_const]
        #[rustc_deprecated(
            since = "1.34.0",
            reason = "the `new` function is now preferred",
            suggestion = $atomic_new,
        )]
        pub const $atomic_init: $atomic_type = $atomic_type::new(0);

        #[$stable]
        impl Default for $atomic_type {
            #[inline]
            fn default() -> Self {
                Self::new(Default::default())
            }
        }

        #[$stable_from]
        impl From<$int_type> for $atomic_type {
            #[doc = concat!("Converts an `", stringify!($int_type), "` into an `", stringify!($atomic_type), "`.")]
            #[inline]
            fn from(v: $int_type) -> Self { Self::new(v) }
        }

        #[$stable_debug]
        impl fmt::Debug for $atomic_type {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
            }
        }

        // Verzenden is impliciet geïmplementeerd.
        #[$stable]
        unsafe impl Sync for $atomic_type {}

        impl $atomic_type {
            /// Creëert een nieuw atomair geheel getal.
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]

            #[doc = concat!("let atomic_forty_two = ", stringify!($atomic_type), "::new(42);")]
            /// ```
            #[inline]
            #[$stable]
            #[$const_stable]
            pub const fn new(v: $int_type) -> Self {
                Self {v: UnsafeCell::new(v)}
            }

            /// Retourneert een veranderlijke verwijzing naar het onderliggende gehele getal.
            ///
            /// Dit is veilig omdat de veranderlijke referentie garandeert dat geen andere threads gelijktijdig toegang hebben tot de atomaire gegevens.
            ///
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let mut some_var = ", stringify!($atomic_type), "::new(10);")]
            /// assert_eq!(*some_var.get_mut(), 10);
            /// *some_var.get_mut() =5;
            /// assert_eq!(some_var.load(Ordering::SeqCst), 5);
            /// ```
            #[inline]
            #[$stable_access]
            pub fn get_mut(&mut self) -> &mut $int_type {
                self.v.get_mut()
            }

            #[doc = concat!("Get atomic access to a `&mut ", stringify!($int_type), "`.")]

            #[doc = if_not_8_bit! {
                $int_type,
                concat!(
                    "**Note:** This function is only available on targets where `",
                    stringify!($int_type), "` has an alignment of ", $align, " bytes."
                )
            }]
            /// # Examples
            ///
            /// ```
            /// #![feature(atomic_from_mut)]
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]
            /// laat mut some_int=123;
            #[doc = concat!("let a = ", stringify!($atomic_type), "::from_mut(&mut some_int);")]
            /// a.store(100, Ordering::Relaxed);
            ///
            /// assert_eq! (some_int, 100);
            /// ```
            #[inline]
            #[$cfg_align]
            #[unstable(feature = "atomic_from_mut", issue = "76314")]
            pub fn from_mut(v: &mut $int_type) -> &Self {
                use crate::mem::align_of;
                let [] = [(); align_of::<Self>() - align_of::<$int_type>()];
                // SAFETY:
                //  - de veranderlijke referentie garandeert uniek eigendom.
                //  - de uitlijning van `$int_type` en `Self` is hetzelfde, zoals beloofd door $cfg_align en hierboven geverifieerd.
                //
                unsafe { &*(v as *mut $int_type as *mut Self) }
            }

            /// Verbruikt het atomaire en retourneert de ingesloten waarde.
            ///
            /// Dit is veilig omdat het doorgeven van `self` op waarde garandeert dat geen andere threads gelijktijdig toegang hebben tot de atomaire gegevens.
            ///
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.into_inner(), 5);
            /// ```
            #[inline]
            #[$stable_access]
            #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
            pub const fn into_inner(self) -> $int_type {
                self.v.into_inner()
            }

            /// Laadt een waarde uit het atomaire gehele getal.
            ///
            /// `load` neemt een [`Ordering`]-argument dat de geheugenvolgorde van deze bewerking beschrijft.
            /// Mogelijke waarden zijn [`SeqCst`], [`Acquire`] en [`Relaxed`].
            ///
            /// # Panics
            ///
            /// Panics als `order` [`Release`] of [`AcqRel`] is.
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.load(Ordering::Relaxed), 5);
            /// ```
            #[inline]
            #[$stable]
            pub fn load(&self, order: Ordering) -> $int_type {
                // VEILIGHEID: dataraces worden voorkomen door atomaire intrinsiek.
                unsafe { atomic_load(self.v.get(), order) }
            }

            /// Slaat een waarde op in het atomaire gehele getal.
            ///
            /// `store` neemt een [`Ordering`]-argument dat de geheugenvolgorde van deze bewerking beschrijft.
            ///  Mogelijke waarden zijn [`SeqCst`], [`Release`] en [`Relaxed`].
            ///
            /// # Panics
            ///
            /// Panics als `order` [`Acquire`] of [`AcqRel`] is.
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// some_var.store(10, Ordering::Relaxed);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            #[inline]
            #[$stable]
            pub fn store(&self, val: $int_type, order: Ordering) {
                // VEILIGHEID: dataraces worden voorkomen door atomaire intrinsiek.
                unsafe { atomic_store(self.v.get(), val, order); }
            }

            /// Slaat een waarde op in het atomaire gehele getal en retourneert de vorige waarde.
            ///
            /// `swap` neemt een [`Ordering`]-argument dat de geheugenvolgorde van deze bewerking beschrijft.Alle bestelmodi zijn mogelijk.
            /// Merk op dat het gebruik van [`Acquire`] het opslaan onderdeel maakt van deze bewerking [`Relaxed`], en het gebruik van [`Release`] maakt het laadgedeelte [`Relaxed`].
            ///
            ///
            /// **Opmerking**: deze methode is alleen beschikbaar op platforms die atomaire bewerkingen ondersteunen op
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.swap(10, Ordering::Relaxed), 5);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn swap(&self, val: $int_type, order: Ordering) -> $int_type {
                // VEILIGHEID: dataraces worden voorkomen door atomaire intrinsiek.
                unsafe { atomic_swap(self.v.get(), val, order) }
            }

            /// Slaat een waarde op in het atomaire gehele getal als de huidige waarde hetzelfde is als de `current`-waarde.
            ///
            /// De geretourneerde waarde is altijd de vorige waarde.Als het gelijk is aan `current`, is de waarde bijgewerkt.
            ///
            /// `compare_and_swap` accepteert ook een [`Ordering`]-argument dat de geheugenvolgorde van deze bewerking beschrijft.
            /// Merk op dat zelfs wanneer [`AcqRel`] wordt gebruikt, de bewerking kan mislukken en daarom alleen een `Acquire`-belasting kan uitvoeren, maar geen `Release`-semantiek heeft.
            ///
            /// Het gebruik van [`Acquire`] maakt het opslaan onderdeel van deze bewerking [`Relaxed`] als het gebeurt, en het gebruik van [`Release`] maakt het laadgedeelte [`Relaxed`].
            ///
            /// **Opmerking**: deze methode is alleen beschikbaar op platforms die atomaire bewerkingen ondersteunen op
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Migreren naar `compare_exchange` en `compare_exchange_weak`
            ///
            /// `compare_and_swap` is gelijk aan `compare_exchange` met de volgende toewijzing voor geheugenvolgorde:
            ///
            /// Origineel |Succes |Mislukking
            /// -------- | ------- | -------
            /// Ontspannen |Ontspannen |Ontspannen verwerven |Verwerven |Verkrijg release |Vrijgeven |Ontspannen AcqRel |AcqRel |Koop SeqCst |SeqCst |SeqCst
            ///
            /// `compare_exchange_weak` kan oneigenlijk mislukken, zelfs als de vergelijking slaagt, waardoor de compiler betere assemblagecode kan genereren wanneer de compar en swap in een lus wordt gebruikt.
            ///
            ///
            /// # Examples
            ///
            /// ```
            ///
            ///
            ///
            ///
            ///
            ///
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.compare_and_swap(5, 10, Ordering::Relaxed), 5);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            ///
            /// assert_eq!(some_var.compare_and_swap(6, 12, Ordering::Relaxed), 10);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            #[inline]
            #[$stable]
            #[rustc_deprecated(
                since = "1.50.0",
                reason = "Use `compare_exchange` or `compare_exchange_weak` instead")
            ]
            #[$cfg_cas]
            pub fn compare_and_swap(&self,
                                    current: $int_type,
                                    new: $int_type,
                                    order: Ordering) -> $int_type {
                match self.compare_exchange(current,
                                            new,
                                            order,
                                            strongest_failure_ordering(order)) {
                    Ok(x) => x,
                    Err(x) => x,
                }
            }

            /// Slaat een waarde op in het atomaire gehele getal als de huidige waarde hetzelfde is als de `current`-waarde.
            ///
            /// De geretourneerde waarde is een resultaat dat aangeeft of de nieuwe waarde is geschreven en de vorige waarde bevat.
            /// Bij succes is deze waarde gegarandeerd gelijk aan `current`.
            ///
            /// `compare_exchange` heeft twee [`Ordering`]-argumenten nodig om de geheugenvolgorde van deze bewerking te beschrijven.
            /// `success` beschrijft de vereiste volgorde voor de lees-wijzig-schrijfbewerking die plaatsvindt als de vergelijking met `current` slaagt.
            /// `failure` beschrijft de vereiste volgorde voor de laadbewerking die plaatsvindt wanneer de vergelijking mislukt.
            /// Door [`Acquire`] als succesbestelling te gebruiken, maakt de winkel deel uit van deze operatie [`Relaxed`], en door [`Release`] te gebruiken, wordt [`Relaxed`] succesvol geladen.
            ///
            /// De volgorde van fouten kan alleen [`SeqCst`], [`Acquire`] of [`Relaxed`] zijn en moet gelijk of zwakker zijn dan de bestelling met succes.
            ///
            /// **Opmerking**: deze methode is alleen beschikbaar op platforms die atomaire bewerkingen ondersteunen op
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.compare_exchange(5, 10,                                      Ordering::Acquire,                                      Ordering::Relaxed),
            ///
            ///            Ok(5));
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            ///
            /// assert_eq!(some_var.compare_exchange(6, 12,                                      Ordering::SeqCst,                                      Ordering::Acquire),
            ///            Err(10));
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            ///
            ///
            ///
            #[inline]
            #[$stable_cxchg]
            #[$cfg_cas]
            pub fn compare_exchange(&self,
                                    current: $int_type,
                                    new: $int_type,
                                    success: Ordering,
                                    failure: Ordering) -> Result<$int_type, $int_type> {
                // VEILIGHEID: dataraces worden voorkomen door atomaire intrinsiek.
                unsafe { atomic_compare_exchange(self.v.get(), current, new, success, failure) }
            }

            /// Slaat een waarde op in het atomaire gehele getal als de huidige waarde hetzelfde is als de `current`-waarde.
            ///
            ///
            #[doc = concat!("Unlike [`", stringify!($atomic_type), "::compare_exchange`],")]
            /// deze functie kan oneigenlijk falen, zelfs als de vergelijking slaagt, wat kan resulteren in efficiëntere code op sommige platforms.
            /// De geretourneerde waarde is een resultaat dat aangeeft of de nieuwe waarde is geschreven en de vorige waarde bevat.
            ///
            /// `compare_exchange_weak` heeft twee [`Ordering`]-argumenten nodig om de geheugenvolgorde van deze bewerking te beschrijven.
            /// `success` beschrijft de vereiste volgorde voor de lees-wijzig-schrijfbewerking die plaatsvindt als de vergelijking met `current` slaagt.
            /// `failure` beschrijft de vereiste volgorde voor de laadbewerking die plaatsvindt wanneer de vergelijking mislukt.
            /// Door [`Acquire`] als succesbestelling te gebruiken, maakt de winkel deel uit van deze operatie [`Relaxed`], en door [`Release`] te gebruiken, wordt [`Relaxed`] succesvol geladen.
            ///
            /// De volgorde van fouten kan alleen [`SeqCst`], [`Acquire`] of [`Relaxed`] zijn en moet gelijk of zwakker zijn dan de bestelling met succes.
            ///
            /// **Opmerking**: deze methode is alleen beschikbaar op platforms die atomaire bewerkingen ondersteunen op
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let val = ", stringify!($atomic_type), "::new(4);")]
            /// laat mut oud= val.load(Ordering::Relaxed);
            /// loop {let new=old * 2;
            ///     komt overeen met val.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) { Ok(_) => break, Err(x) => old = x, }}
            ///
            /// ```
            ///
            ///
            ///
            ///
            #[inline]
            #[$stable_cxchg]
            #[$cfg_cas]
            pub fn compare_exchange_weak(&self,
                                         current: $int_type,
                                         new: $int_type,
                                         success: Ordering,
                                         failure: Ordering) -> Result<$int_type, $int_type> {
                // VEILIGHEID: dataraces worden voorkomen door atomaire intrinsiek.
                unsafe {
                    atomic_compare_exchange_weak(self.v.get(), current, new, success, failure)
                }
            }

            /// Voegt toe aan de huidige waarde en retourneert de vorige waarde.
            ///
            /// Deze operatie loopt rond bij overloop.
            ///
            /// `fetch_add` neemt een [`Ordering`]-argument dat de geheugenvolgorde van deze bewerking beschrijft.Alle bestelmodi zijn mogelijk.
            /// Merk op dat het gebruik van [`Acquire`] het opslaan onderdeel maakt van deze bewerking [`Relaxed`], en het gebruik van [`Release`] maakt het laadgedeelte [`Relaxed`].
            ///
            ///
            /// **Opmerking**: deze methode is alleen beschikbaar op platforms die atomaire bewerkingen ondersteunen op
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0);")]
            /// assert_eq!(foo.fetch_add(10, Ordering::SeqCst), 0);
            /// assert_eq!(foo.load(Ordering::SeqCst), 10);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_add(&self, val: $int_type, order: Ordering) -> $int_type {
                // VEILIGHEID: dataraces worden voorkomen door atomaire intrinsiek.
                unsafe { atomic_add(self.v.get(), val, order) }
            }

            /// Trekt af van de huidige waarde en retourneert de vorige waarde.
            ///
            /// Deze operatie loopt rond bij overloop.
            ///
            /// `fetch_sub` neemt een [`Ordering`]-argument dat de geheugenvolgorde van deze bewerking beschrijft.Alle bestelmodi zijn mogelijk.
            /// Merk op dat het gebruik van [`Acquire`] het opslaan onderdeel maakt van deze bewerking [`Relaxed`], en het gebruik van [`Release`] maakt het laadgedeelte [`Relaxed`].
            ///
            ///
            /// **Opmerking**: deze methode is alleen beschikbaar op platforms die atomaire bewerkingen ondersteunen op
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(20);")]
            /// assert_eq!(foo.fetch_sub(10, Ordering::SeqCst), 20);
            /// assert_eq!(foo.load(Ordering::SeqCst), 10);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_sub(&self, val: $int_type, order: Ordering) -> $int_type {
                // VEILIGHEID: dataraces worden voorkomen door atomaire intrinsiek.
                unsafe { atomic_sub(self.v.get(), val, order) }
            }

            /// Bitwise "and" met de huidige waarde.
            ///
            /// Voert een bitsgewijze "and"-bewerking uit op de huidige waarde en het argument `val`, en stelt de nieuwe waarde in op het resultaat.
            ///
            /// Retourneert de vorige waarde.
            ///
            /// `fetch_and` neemt een [`Ordering`]-argument dat de geheugenvolgorde van deze bewerking beschrijft.Alle bestelmodi zijn mogelijk.
            /// Merk op dat het gebruik van [`Acquire`] het opslaan onderdeel maakt van deze bewerking [`Relaxed`], en het gebruik van [`Release`] maakt het laadgedeelte [`Relaxed`].
            ///
            ///
            /// **Opmerking**: deze methode is alleen beschikbaar op platforms die atomaire bewerkingen ondersteunen op
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_and(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b100001);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_and(&self, val: $int_type, order: Ordering) -> $int_type {
                // VEILIGHEID: dataraces worden voorkomen door atomaire intrinsiek.
                unsafe { atomic_and(self.v.get(), val, order) }
            }

            /// Bitwise "nand" met de huidige waarde.
            ///
            /// Voert een bitsgewijze "nand"-bewerking uit op de huidige waarde en het argument `val`, en stelt de nieuwe waarde in op het resultaat.
            ///
            /// Retourneert de vorige waarde.
            ///
            /// `fetch_nand` neemt een [`Ordering`]-argument dat de geheugenvolgorde van deze bewerking beschrijft.Alle bestelmodi zijn mogelijk.
            /// Merk op dat het gebruik van [`Acquire`] het opslaan onderdeel maakt van deze bewerking [`Relaxed`], en het gebruik van [`Release`] maakt het laadgedeelte [`Relaxed`].
            ///
            ///
            /// **Opmerking**: deze methode is alleen beschikbaar op platforms die atomaire bewerkingen ondersteunen op
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0x13);")]
            /// assert_eq!(foo.fetch_nand(0x31, Ordering::SeqCst), 0x13);
            /// assert_eq!(foo.load(Ordering::SeqCst), ! (0x13&0x31));
            /// ```
            #[inline]
            #[$stable_nand]
            #[$cfg_cas]
            pub fn fetch_nand(&self, val: $int_type, order: Ordering) -> $int_type {
                // VEILIGHEID: dataraces worden voorkomen door atomaire intrinsiek.
                unsafe { atomic_nand(self.v.get(), val, order) }
            }

            /// Bitwise "or" met de huidige waarde.
            ///
            /// Voert een bitsgewijze "or"-bewerking uit op de huidige waarde en het argument `val`, en stelt de nieuwe waarde in op het resultaat.
            ///
            /// Retourneert de vorige waarde.
            ///
            /// `fetch_or` neemt een [`Ordering`]-argument dat de geheugenvolgorde van deze bewerking beschrijft.Alle bestelmodi zijn mogelijk.
            /// Merk op dat het gebruik van [`Acquire`] het opslaan onderdeel maakt van deze bewerking [`Relaxed`], en het gebruik van [`Release`] maakt het laadgedeelte [`Relaxed`].
            ///
            ///
            /// **Opmerking**: deze methode is alleen beschikbaar op platforms die atomaire bewerkingen ondersteunen op
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_or(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b111111);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_or(&self, val: $int_type, order: Ordering) -> $int_type {
                // VEILIGHEID: dataraces worden voorkomen door atomaire intrinsiek.
                unsafe { atomic_or(self.v.get(), val, order) }
            }

            /// Bitwise "xor" met de huidige waarde.
            ///
            /// Voert een bitsgewijze "xor"-bewerking uit op de huidige waarde en het argument `val`, en stelt de nieuwe waarde in op het resultaat.
            ///
            /// Retourneert de vorige waarde.
            ///
            /// `fetch_xor` neemt een [`Ordering`]-argument dat de geheugenvolgorde van deze bewerking beschrijft.Alle bestelmodi zijn mogelijk.
            /// Merk op dat het gebruik van [`Acquire`] het opslaan onderdeel maakt van deze bewerking [`Relaxed`], en het gebruik van [`Release`] maakt het laadgedeelte [`Relaxed`].
            ///
            ///
            /// **Opmerking**: deze methode is alleen beschikbaar op platforms die atomaire bewerkingen ondersteunen op
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_xor(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b011110);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_xor(&self, val: $int_type, order: Ordering) -> $int_type {
                // VEILIGHEID: dataraces worden voorkomen door atomaire intrinsiek.
                unsafe { atomic_xor(self.v.get(), val, order) }
            }

            /// Haalt de waarde op en past er een functie op toe die een optionele nieuwe waarde retourneert.Retourneert een `Result` van `Ok(previous_value)` als de functie `Some(_)` retourneert, anders `Err(previous_value)`.
            ///
            /// Note: Dit kan de functie meerdere keren aanroepen als de waarde in de tussentijd is gewijzigd van andere threads, zolang de functie `Some(_)` retourneert, maar de functie is slechts één keer toegepast op de opgeslagen waarde.
            ///
            ///
            /// `fetch_update` heeft twee [`Ordering`]-argumenten nodig om de geheugenvolgorde van deze bewerking te beschrijven.
            /// De eerste beschrijft de vereiste volgorde voor wanneer de operatie uiteindelijk slaagt, terwijl de tweede de vereiste bestelling voor ladingen beschrijft.Deze komen overeen met de volgorde van succes en mislukking van
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", stringify!($atomic_type), "::compare_exchange`]")]
            /// respectively.
            ///
            /// Door [`Acquire`] als succesbestelling te gebruiken, maakt de winkel deel uit van deze operatie [`Relaxed`], en door [`Release`] te gebruiken, laadt de laatste succesvolle [`Relaxed`].
            /// De (failed)-laadvolgorde kan alleen [`SeqCst`], [`Acquire`] of [`Relaxed`] zijn en moet gelijk of zwakker zijn dan de succesvolle bestelling.
            ///
            /// **Opmerking**: deze methode is alleen beschikbaar op platforms die atomaire bewerkingen ondersteunen op
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```rust
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let x = ", stringify!($atomic_type), "::new(7);")]
            /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(7));
            /// assert_eq! (x.fetch_update (Ordering: : SeqCst, Ordering::SeqCst, | x | Some(x + 1)), Ok(7));
            /// assert_eq! (x.fetch_update (Ordering: : SeqCst, Ordering::SeqCst, | x | Some(x + 1)), Ok(8));
            /// assert_eq!(x.load(Ordering::SeqCst), 9);
            /// ```
            #[inline]
            #[stable(feature = "no_more_cas", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_update<F>(&self,
                                   set_order: Ordering,
                                   fetch_order: Ordering,
                                   mut f: F) -> Result<$int_type, $int_type>
            where F: FnMut($int_type) -> Option<$int_type> {
                let mut prev = self.load(fetch_order);
                while let Some(next) = f(prev) {
                    match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                        x @ Ok(_) => return x,
                        Err(next_prev) => prev = next_prev
                    }
                }
                Err(prev)
            }

            /// Maximaal met de huidige waarde.
            ///
            /// Vindt het maximum van de huidige waarde en het argument `val`, en stelt de nieuwe waarde in op het resultaat.
            ///
            /// Retourneert de vorige waarde.
            ///
            /// `fetch_max` neemt een [`Ordering`]-argument dat de geheugenvolgorde van deze bewerking beschrijft.Alle bestelmodi zijn mogelijk.
            /// Merk op dat het gebruik van [`Acquire`] het opslaan onderdeel maakt van deze bewerking [`Relaxed`], en het gebruik van [`Release`] maakt het laadgedeelte [`Relaxed`].
            ///
            ///
            /// **Opmerking**: deze methode is alleen beschikbaar op platforms die atomaire bewerkingen ondersteunen op
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// assert_eq!(foo.fetch_max(42, Ordering::SeqCst), 23);
            /// assert_eq!(foo.load(Ordering::SeqCst), 42);
            /// ```
            ///
            /// If you want to obtain the maximum value in one step, you can use the following:
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// laat bar=42;
            /// laat max_foo=foo.fetch_max (bar, Ordering::SeqCst).max(bar);
            /// beweren! (max_foo==42);
            /// ```
            #[inline]
            #[stable(feature = "atomic_min_max", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_max(&self, val: $int_type, order: Ordering) -> $int_type {
                // VEILIGHEID: dataraces worden voorkomen door atomaire intrinsiek.
                unsafe { $max_fn(self.v.get(), val, order) }
            }

            /// Minimum met de huidige waarde.
            ///
            /// Vindt het minimum van de huidige waarde en het argument `val`, en stelt de nieuwe waarde in op het resultaat.
            ///
            /// Retourneert de vorige waarde.
            ///
            /// `fetch_min` neemt een [`Ordering`]-argument dat de geheugenvolgorde van deze bewerking beschrijft.Alle bestelmodi zijn mogelijk.
            /// Merk op dat het gebruik van [`Acquire`] het opslaan onderdeel maakt van deze bewerking [`Relaxed`], en het gebruik van [`Release`] maakt het laadgedeelte [`Relaxed`].
            ///
            ///
            /// **Opmerking**: deze methode is alleen beschikbaar op platforms die atomaire bewerkingen ondersteunen op
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// assert_eq!(foo.fetch_min(42, Ordering::Relaxed), 23);
            /// assert_eq!(foo.load(Ordering::Relaxed), 23);
            /// assert_eq!(foo.fetch_min(22, Ordering::Relaxed), 23);
            /// assert_eq!(foo.load(Ordering::Relaxed), 22);
            /// ```
            ///
            /// If you want to obtain the minimum value in one step, you can use the following:
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// laat bar=12;
            /// laat min_foo=foo.fetch_min (bar, Ordering::SeqCst).min(bar);
            /// assert_eq! (min_foo, 12);
            /// ```
            #[inline]
            #[stable(feature = "atomic_min_max", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_min(&self, val: $int_type, order: Ordering) -> $int_type {
                // VEILIGHEID: dataraces worden voorkomen door atomaire intrinsiek.
                unsafe { $min_fn(self.v.get(), val, order) }
            }

            /// Retourneert een veranderlijke pointer naar het onderliggende gehele getal.
            ///
            /// Het niet-atomaire lezen en schrijven van het resulterende gehele getal kan een gegevensrace zijn.
            /// Deze methode is vooral handig voor FFI, waar de functiehandtekening kan gebruiken
            #[doc = concat!("`*mut ", stringify!($int_type), "` instead of `&", stringify!($atomic_type), "`.")]
            /// Het retourneren van een `*mut`-pointer van een gedeelde verwijzing naar deze atomaire is veilig omdat de atomaire typen werken met interne veranderlijkheid.
            /// Alle wijzigingen van een atomair veranderen de waarde via een gedeelde referentie, en kunnen dit veilig doen zolang ze atomaire operaties gebruiken.
            /// Elk gebruik van de geretourneerde onbewerkte pointer vereist een `unsafe`-blok en moet nog steeds dezelfde beperking handhaven: bewerkingen erop moeten atomair zijn.
            ///
            ///
            /// # Examples
            ///
            /// `` negeer (extern-declaration)
            ///
            /// # fn main() {
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]
            /// externe "C" {
            #[doc = concat!("    fn my_atomic_op(arg: *mut ", stringify!($int_type), ");")]
            /// }
            ///
            #[doc = concat!("let mut atomic = ", stringify!($atomic_type), "::new(1);")]

            // VEILIGHEID: veilig zolang `my_atomic_op` atomair is.
            /// onveilig {
            ///     my_atomic_op(atomic.as_mut_ptr());
            /// }
            /// # }
            /// ```
            #[inline]
            #[unstable(feature = "atomic_mut_ptr",
                   reason = "recently added",
                   issue = "66893")]
            pub fn as_mut_ptr(&self) -> *mut $int_type {
                self.v.get()
            }
        }
    }
}

#[cfg(target_has_atomic_load_store = "8")]
atomic_int! {
    cfg(target_has_atomic = "8"),
    cfg(target_has_atomic_equal_alignment = "8"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i8",
    "",
    atomic_min, atomic_max,
    1,
    "AtomicI8::new(0)",
    i8 AtomicI8 ATOMIC_I8_INIT
}
#[cfg(target_has_atomic_load_store = "8")]
atomic_int! {
    cfg(target_has_atomic = "8"),
    cfg(target_has_atomic_equal_alignment = "8"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u8",
    "",
    atomic_umin, atomic_umax,
    1,
    "AtomicU8::new(0)",
    u8 AtomicU8 ATOMIC_U8_INIT
}
#[cfg(target_has_atomic_load_store = "16")]
atomic_int! {
    cfg(target_has_atomic = "16"),
    cfg(target_has_atomic_equal_alignment = "16"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i16",
    "",
    atomic_min, atomic_max,
    2,
    "AtomicI16::new(0)",
    i16 AtomicI16 ATOMIC_I16_INIT
}
#[cfg(target_has_atomic_load_store = "16")]
atomic_int! {
    cfg(target_has_atomic = "16"),
    cfg(target_has_atomic_equal_alignment = "16"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u16",
    "",
    atomic_umin, atomic_umax,
    2,
    "AtomicU16::new(0)",
    u16 AtomicU16 ATOMIC_U16_INIT
}
#[cfg(target_has_atomic_load_store = "32")]
atomic_int! {
    cfg(target_has_atomic = "32"),
    cfg(target_has_atomic_equal_alignment = "32"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i32",
    "",
    atomic_min, atomic_max,
    4,
    "AtomicI32::new(0)",
    i32 AtomicI32 ATOMIC_I32_INIT
}
#[cfg(target_has_atomic_load_store = "32")]
atomic_int! {
    cfg(target_has_atomic = "32"),
    cfg(target_has_atomic_equal_alignment = "32"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u32",
    "",
    atomic_umin, atomic_umax,
    4,
    "AtomicU32::new(0)",
    u32 AtomicU32 ATOMIC_U32_INIT
}
#[cfg(target_has_atomic_load_store = "64")]
atomic_int! {
    cfg(target_has_atomic = "64"),
    cfg(target_has_atomic_equal_alignment = "64"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i64",
    "",
    atomic_min, atomic_max,
    8,
    "AtomicI64::new(0)",
    i64 AtomicI64 ATOMIC_I64_INIT
}
#[cfg(target_has_atomic_load_store = "64")]
atomic_int! {
    cfg(target_has_atomic = "64"),
    cfg(target_has_atomic_equal_alignment = "64"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u64",
    "",
    atomic_umin, atomic_umax,
    8,
    "AtomicU64::new(0)",
    u64 AtomicU64 ATOMIC_U64_INIT
}
#[cfg(target_has_atomic_load_store = "128")]
atomic_int! {
    cfg(target_has_atomic = "128"),
    cfg(target_has_atomic_equal_alignment = "128"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i128",
    "#![feature(integer_atomics)]\n\n",
    atomic_min, atomic_max,
    16,
    "AtomicI128::new(0)",
    i128 AtomicI128 ATOMIC_I128_INIT
}
#[cfg(target_has_atomic_load_store = "128")]
atomic_int! {
    cfg(target_has_atomic = "128"),
    cfg(target_has_atomic_equal_alignment = "128"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u128",
    "#![feature(integer_atomics)]\n\n",
    atomic_umin, atomic_umax,
    16,
    "AtomicU128::new(0)",
    u128 AtomicU128 ATOMIC_U128_INIT
}

macro_rules! atomic_int_ptr_sized {
    ( $($target_pointer_width:literal $align:literal)* ) => { $(
        #[cfg(target_has_atomic_load_store = "ptr")]
        #[cfg(target_pointer_width = $target_pointer_width)]
        atomic_int! {
            cfg(target_has_atomic = "ptr"),
            cfg(target_has_atomic_equal_alignment = "ptr"),
            stable(feature = "rust1", since = "1.0.0"),
            stable(feature = "extended_compare_and_swap", since = "1.10.0"),
            stable(feature = "atomic_debug", since = "1.3.0"),
            stable(feature = "atomic_access", since = "1.15.0"),
            stable(feature = "atomic_from", since = "1.23.0"),
            stable(feature = "atomic_nand", since = "1.27.0"),
            rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
            stable(feature = "rust1", since = "1.0.0"),
            "isize",
            "",
            atomic_min, atomic_max,
            $align,
            "AtomicIsize::new(0)",
            isize AtomicIsize ATOMIC_ISIZE_INIT
        }
        #[cfg(target_has_atomic_load_store = "ptr")]
        #[cfg(target_pointer_width = $target_pointer_width)]
        atomic_int! {
            cfg(target_has_atomic = "ptr"),
            cfg(target_has_atomic_equal_alignment = "ptr"),
            stable(feature = "rust1", since = "1.0.0"),
            stable(feature = "extended_compare_and_swap", since = "1.10.0"),
            stable(feature = "atomic_debug", since = "1.3.0"),
            stable(feature = "atomic_access", since = "1.15.0"),
            stable(feature = "atomic_from", since = "1.23.0"),
            stable(feature = "atomic_nand", since = "1.27.0"),
            rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
            stable(feature = "rust1", since = "1.0.0"),
            "usize",
            "",
            atomic_umin, atomic_umax,
            $align,
            "AtomicUsize::new(0)",
            usize AtomicUsize ATOMIC_USIZE_INIT
        }
    )* };
}

atomic_int_ptr_sized! {
    "16" 2
    "32" 4
    "64" 8
}

#[inline]
#[cfg(target_has_atomic = "8")]
fn strongest_failure_ordering(order: Ordering) -> Ordering {
    match order {
        Release => Relaxed,
        Relaxed => Relaxed,
        SeqCst => SeqCst,
        Acquire => Acquire,
        AcqRel => Acquire,
    }
}

#[inline]
unsafe fn atomic_store<T: Copy>(dst: *mut T, val: T, order: Ordering) {
    // VEILIGHEID: de beller moet zich houden aan het veiligheidscontract voor `atomic_store`.
    unsafe {
        match order {
            Release => intrinsics::atomic_store_rel(dst, val),
            Relaxed => intrinsics::atomic_store_relaxed(dst, val),
            SeqCst => intrinsics::atomic_store(dst, val),
            Acquire => panic!("there is no such thing as an acquire store"),
            AcqRel => panic!("there is no such thing as an acquire/release store"),
        }
    }
}

#[inline]
unsafe fn atomic_load<T: Copy>(dst: *const T, order: Ordering) -> T {
    // VEILIGHEID: de beller moet zich houden aan het veiligheidscontract voor `atomic_load`.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_load_acq(dst),
            Relaxed => intrinsics::atomic_load_relaxed(dst),
            SeqCst => intrinsics::atomic_load(dst),
            Release => panic!("there is no such thing as a release load"),
            AcqRel => panic!("there is no such thing as an acquire/release load"),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_swap<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // VEILIGHEID: de beller moet zich houden aan het veiligheidscontract voor `atomic_swap`.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xchg_acq(dst, val),
            Release => intrinsics::atomic_xchg_rel(dst, val),
            AcqRel => intrinsics::atomic_xchg_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xchg_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xchg(dst, val),
        }
    }
}

/// Retourneert de vorige waarde (zoals __sync_fetch_and_add).
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_add<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // VEILIGHEID: de beller moet zich houden aan het veiligheidscontract voor `atomic_add`.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xadd_acq(dst, val),
            Release => intrinsics::atomic_xadd_rel(dst, val),
            AcqRel => intrinsics::atomic_xadd_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xadd_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xadd(dst, val),
        }
    }
}

/// Retourneert de vorige waarde (zoals __sync_fetch_and_sub).
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_sub<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // VEILIGHEID: de beller moet zich houden aan het veiligheidscontract voor `atomic_sub`.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xsub_acq(dst, val),
            Release => intrinsics::atomic_xsub_rel(dst, val),
            AcqRel => intrinsics::atomic_xsub_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xsub_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xsub(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_compare_exchange<T: Copy>(
    dst: *mut T,
    old: T,
    new: T,
    success: Ordering,
    failure: Ordering,
) -> Result<T, T> {
    // VEILIGHEID: de beller moet zich houden aan het veiligheidscontract voor `atomic_compare_exchange`.
    let (val, ok) = unsafe {
        match (success, failure) {
            (Acquire, Acquire) => intrinsics::atomic_cxchg_acq(dst, old, new),
            (Release, Relaxed) => intrinsics::atomic_cxchg_rel(dst, old, new),
            (AcqRel, Acquire) => intrinsics::atomic_cxchg_acqrel(dst, old, new),
            (Relaxed, Relaxed) => intrinsics::atomic_cxchg_relaxed(dst, old, new),
            (SeqCst, SeqCst) => intrinsics::atomic_cxchg(dst, old, new),
            (Acquire, Relaxed) => intrinsics::atomic_cxchg_acq_failrelaxed(dst, old, new),
            (AcqRel, Relaxed) => intrinsics::atomic_cxchg_acqrel_failrelaxed(dst, old, new),
            (SeqCst, Relaxed) => intrinsics::atomic_cxchg_failrelaxed(dst, old, new),
            (SeqCst, Acquire) => intrinsics::atomic_cxchg_failacq(dst, old, new),
            (_, AcqRel) => panic!("there is no such thing as an acquire/release failure ordering"),
            (_, Release) => panic!("there is no such thing as a release failure ordering"),
            _ => panic!("a failure ordering can't be stronger than a success ordering"),
        }
    };
    if ok { Ok(val) } else { Err(val) }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_compare_exchange_weak<T: Copy>(
    dst: *mut T,
    old: T,
    new: T,
    success: Ordering,
    failure: Ordering,
) -> Result<T, T> {
    // VEILIGHEID: de beller moet zich houden aan het veiligheidscontract voor `atomic_compare_exchange_weak`.
    let (val, ok) = unsafe {
        match (success, failure) {
            (Acquire, Acquire) => intrinsics::atomic_cxchgweak_acq(dst, old, new),
            (Release, Relaxed) => intrinsics::atomic_cxchgweak_rel(dst, old, new),
            (AcqRel, Acquire) => intrinsics::atomic_cxchgweak_acqrel(dst, old, new),
            (Relaxed, Relaxed) => intrinsics::atomic_cxchgweak_relaxed(dst, old, new),
            (SeqCst, SeqCst) => intrinsics::atomic_cxchgweak(dst, old, new),
            (Acquire, Relaxed) => intrinsics::atomic_cxchgweak_acq_failrelaxed(dst, old, new),
            (AcqRel, Relaxed) => intrinsics::atomic_cxchgweak_acqrel_failrelaxed(dst, old, new),
            (SeqCst, Relaxed) => intrinsics::atomic_cxchgweak_failrelaxed(dst, old, new),
            (SeqCst, Acquire) => intrinsics::atomic_cxchgweak_failacq(dst, old, new),
            (_, AcqRel) => panic!("there is no such thing as an acquire/release failure ordering"),
            (_, Release) => panic!("there is no such thing as a release failure ordering"),
            _ => panic!("a failure ordering can't be stronger than a success ordering"),
        }
    };
    if ok { Ok(val) } else { Err(val) }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_and<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // VEILIGHEID: de beller moet zich houden aan het veiligheidscontract voor `atomic_and`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_and_acq(dst, val),
            Release => intrinsics::atomic_and_rel(dst, val),
            AcqRel => intrinsics::atomic_and_acqrel(dst, val),
            Relaxed => intrinsics::atomic_and_relaxed(dst, val),
            SeqCst => intrinsics::atomic_and(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_nand<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // VEILIGHEID: de beller moet zich houden aan het veiligheidscontract voor `atomic_nand`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_nand_acq(dst, val),
            Release => intrinsics::atomic_nand_rel(dst, val),
            AcqRel => intrinsics::atomic_nand_acqrel(dst, val),
            Relaxed => intrinsics::atomic_nand_relaxed(dst, val),
            SeqCst => intrinsics::atomic_nand(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_or<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // VEILIGHEID: de beller moet zich houden aan het veiligheidscontract voor `atomic_or`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_or_acq(dst, val),
            Release => intrinsics::atomic_or_rel(dst, val),
            AcqRel => intrinsics::atomic_or_acqrel(dst, val),
            Relaxed => intrinsics::atomic_or_relaxed(dst, val),
            SeqCst => intrinsics::atomic_or(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_xor<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // VEILIGHEID: de beller moet zich houden aan het veiligheidscontract voor `atomic_xor`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xor_acq(dst, val),
            Release => intrinsics::atomic_xor_rel(dst, val),
            AcqRel => intrinsics::atomic_xor_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xor_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xor(dst, val),
        }
    }
}

/// geeft de maximale waarde terug (vergelijking met teken)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_max<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // VEILIGHEID: de beller moet zich houden aan het veiligheidscontract voor `atomic_max`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_max_acq(dst, val),
            Release => intrinsics::atomic_max_rel(dst, val),
            AcqRel => intrinsics::atomic_max_acqrel(dst, val),
            Relaxed => intrinsics::atomic_max_relaxed(dst, val),
            SeqCst => intrinsics::atomic_max(dst, val),
        }
    }
}

/// geeft de min waarde terug (vergelijking met teken)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_min<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // VEILIGHEID: de beller moet zich houden aan het veiligheidscontract voor `atomic_min`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_min_acq(dst, val),
            Release => intrinsics::atomic_min_rel(dst, val),
            AcqRel => intrinsics::atomic_min_acqrel(dst, val),
            Relaxed => intrinsics::atomic_min_relaxed(dst, val),
            SeqCst => intrinsics::atomic_min(dst, val),
        }
    }
}

/// geeft de maximale waarde terug (ongetekende vergelijking)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_umax<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // VEILIGHEID: de beller moet zich houden aan het veiligheidscontract voor `atomic_umax`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_umax_acq(dst, val),
            Release => intrinsics::atomic_umax_rel(dst, val),
            AcqRel => intrinsics::atomic_umax_acqrel(dst, val),
            Relaxed => intrinsics::atomic_umax_relaxed(dst, val),
            SeqCst => intrinsics::atomic_umax(dst, val),
        }
    }
}

/// geeft de min waarde terug (ongetekende vergelijking)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_umin<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // VEILIGHEID: de beller moet zich houden aan het veiligheidscontract voor `atomic_umin`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_umin_acq(dst, val),
            Release => intrinsics::atomic_umin_rel(dst, val),
            AcqRel => intrinsics::atomic_umin_acqrel(dst, val),
            Relaxed => intrinsics::atomic_umin_relaxed(dst, val),
            SeqCst => intrinsics::atomic_umin(dst, val),
        }
    }
}

/// Een atoomomheining.
///
/// Afhankelijk van de opgegeven volgorde, voorkomt een afrastering dat de compiler en de CPU bepaalde soorten geheugenbewerkingen eromheen opnieuw ordenen.
/// Dat creëert synchronisaties-met-relaties tussen het en atomaire bewerkingen of hekken in andere threads.
///
/// Een omheining 'A' die (minstens) [`Release`]-ordeningssemantiek heeft, synchroniseert met een omheining 'B' met (minstens) [`Acquire`]-semantiek, als en slechts als er bewerkingen X en Y bestaan, die beide op een atomisch object 'M' werken, zodat A eerder wordt gesequenced X, Y wordt gesynchroniseerd voordat B en Y de verandering naar M. waarnemen.
/// Dit zorgt voor een 'vóór-afhankelijkheid' tussen A en B.
///
/// ```text
///     Thread 1                                          Thread 2
///
/// fence(Release);      A --------------
/// x.store(3, Relaxed); X ---------    |
///                                |    |
///                                |    |
///                                -------------> Y  if x.load(Relaxed) == 3 {
///                                     |-------> B      fence(Acquire);
///                                                      ...
///                                                  }
/// ```
///
/// Atomaire operaties met [`Release`]-of [`Acquire`]-semantiek kunnen ook worden gesynchroniseerd met een hekwerk.
///
/// Een hek met [`SeqCst`]-ordening, naast de semantiek van zowel [`Acquire`] als [`Release`], neemt deel aan de globale programmavolgorde van de andere [`SeqCst`]-bewerkingen en/of hekken.
///
/// Accepteert [`Acquire`]-, [`Release`]-, [`AcqRel`]-en [`SeqCst`]-bestellingen.
///
/// # Panics
///
/// Panics als `order` [`Relaxed`] is.
///
/// # Examples
///
/// ```
/// use std::sync::atomic::AtomicBool;
/// use std::sync::atomic::fence;
/// use std::sync::atomic::Ordering;
///
/// // Een wederzijdse uitsluitingsprimitief gebaseerd op spinlock.
/// pub struct Mutex {
///     flag: AtomicBool,
/// }
///
/// impl Mutex {
///     pub fn new() -> Mutex {
///         Mutex {
///             flag: AtomicBool::new(false),
///         }
///     }
///
///     pub fn lock(&self) {
///         // Wacht tot de oude waarde `false` is.
///         while self.flag.compare_and_swap(false, true, Ordering::Relaxed) != false {}
///         // Dit hek synchroniseert met winkel in `unlock`.
///         fence(Ordering::Acquire);
///     }
///
///     pub fn unlock(&self) {
///         self.flag.store(false, Ordering::Release);
///     }
/// }
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn fence(order: Ordering) {
    // VEILIGHEID: het gebruik van een atoomomheining is veilig.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_fence_acq(),
            Release => intrinsics::atomic_fence_rel(),
            AcqRel => intrinsics::atomic_fence_acqrel(),
            SeqCst => intrinsics::atomic_fence(),
            Relaxed => panic!("there is no such thing as a relaxed fence"),
        }
    }
}

/// Een geheugenomheining voor de compiler.
///
/// `compiler_fence` zendt geen machinecode uit, maar beperkt de soorten geheugenherordeningen die de compiler mag doen.Specifiek, afhankelijk van de gegeven [`Ordering`]-semantiek, kan de compiler worden verhinderd om lees-of schrijfbewerkingen van voor of na de aanroep naar de andere kant van de aanroep naar `compiler_fence` te verplaatsen.Merk op dat het **niet** de *hardware* verhindert om een dergelijke herbestelling uit te voeren.
///
/// Dit is geen probleem in een uitvoeringscontext met één thread, maar wanneer andere threads tegelijkertijd geheugen kunnen wijzigen, zijn sterkere synchronisatieprimitieven zoals [`fence`] vereist.
///
/// De herordeningen die worden voorkomen door de verschillende ordeningssemantiek zijn:
///
///  - met [`SeqCst`] is herordenen van lees-en schrijfbewerkingen op dit punt niet toegestaan.
///  - met [`Release`] kunnen voorafgaande lees-en schrijfbewerkingen niet voorbij volgende schrijfbewerkingen worden verplaatst.
///  - met [`Acquire`] kunnen volgende lees-en schrijfbewerkingen niet worden verplaatst naar voorgaande leesbewerkingen.
///  - met [`AcqRel`] worden beide bovenstaande regels afgedwongen.
///
/// `compiler_fence` is over het algemeen alleen nuttig om te voorkomen dat een thread *met zichzelf* racet.Dat wil zeggen, als een gegeven thread één stuk code uitvoert, en vervolgens wordt onderbroken, en begint met het uitvoeren van code ergens anders (terwijl het zich nog steeds in dezelfde thread bevindt, en conceptueel nog steeds op dezelfde kern).In traditionele programma's kan dit alleen gebeuren als een signaalbehandelaar is geregistreerd.
/// In meer low-level code kunnen dergelijke situaties zich ook voordoen bij het afhandelen van interrupts, bij het implementeren van groene threads met voorrang, enz.
/// Nieuwsgierige lezers worden aangemoedigd om de bespreking van [memory barriers] in de Linux-kernel te lezen.
///
/// # Panics
///
/// Panics als `order` [`Relaxed`] is.
///
/// # Examples
///
/// Zonder `compiler_fence` is de `assert_eq!` in de volgende code *niet* gegarandeerd succesvol, ondanks dat alles in een enkele thread gebeurt.
/// Om te zien waarom, onthoud dat de compiler vrij is om de winkels om te wisselen naar `IMPORTANT_VARIABLE` en `IS_READ`, aangezien ze beide `Ordering::Relaxed` zijn.Als dit het geval is en de signaalhandler wordt aangeroepen direct nadat `IS_READY` is bijgewerkt, ziet de signaalhandler `IS_READY=1`, maar `IMPORTANT_VARIABLE=0`.
/// Het gebruik van een `compiler_fence` lost deze situatie op.
///
/// ```
/// use std::sync::atomic::{AtomicBool, AtomicUsize};
/// use std::sync::atomic::Ordering;
/// use std::sync::atomic::compiler_fence;
///
/// static IMPORTANT_VARIABLE: AtomicUsize = AtomicUsize::new(0);
/// static IS_READY: AtomicBool = AtomicBool::new(false);
///
/// fn main() {
///     IMPORTANT_VARIABLE.store(42, Ordering::Relaxed);
///     // voorkomen dat eerdere schrijfbewerkingen voorbij dit punt worden verplaatst
///     compiler_fence(Ordering::Release);
///     IS_READY.store(true, Ordering::Relaxed);
/// }
///
/// fn signal_handler() {
///     if IS_READY.load(Ordering::Relaxed) {
///         assert_eq!(IMPORTANT_VARIABLE.load(Ordering::Relaxed), 42);
///     }
/// }
/// ```
///
/// [memory barriers]: https://www.kernel.org/doc/Documentation/memory-barriers.txt
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "compiler_fences", since = "1.21.0")]
pub fn compiler_fence(order: Ordering) {
    // VEILIGHEID: het gebruik van een atoomomheining is veilig.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_singlethreadfence_acq(),
            Release => intrinsics::atomic_singlethreadfence_rel(),
            AcqRel => intrinsics::atomic_singlethreadfence_acqrel(),
            SeqCst => intrinsics::atomic_singlethreadfence(),
            Relaxed => panic!("there is no such thing as a relaxed compiler fence"),
        }
    }
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "atomic_debug", since = "1.3.0")]
impl fmt::Debug for AtomicBool {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_debug", since = "1.3.0")]
impl<T> fmt::Debug for AtomicPtr<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_pointer", since = "1.24.0")]
impl<T> fmt::Pointer for AtomicPtr<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.load(Ordering::SeqCst), f)
    }
}

/// Geeft aan de processor door dat deze zich in een bezig-wacht-spin-lus ("spin lock") bevindt.
///
/// Deze functie is vervangen door [`hint::spin_loop`].
///
/// [`hint::spin_loop`]: crate::hint::spin_loop
#[inline]
#[stable(feature = "spin_loop_hint", since = "1.24.0")]
#[rustc_deprecated(since = "1.51.0", reason = "use hint::spin_loop instead")]
pub fn spin_loop_hint() {
    spin_loop()
}