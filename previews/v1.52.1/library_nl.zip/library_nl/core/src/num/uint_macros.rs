macro_rules! uint_impl {
    ($SelfT:ty, $ActualT:ty, $BITS:expr, $MaxV:expr,
        $rot:expr, $rot_op:expr, $rot_result:expr, $swap_op:expr, $swapped:expr,
        $reversed:expr, $le_bytes:expr, $be_bytes:expr,
        $to_xe_bytes_doc:expr, $from_xe_bytes_doc:expr) => {
        /// De kleinste waarde die kan worden weergegeven door dit type gehele getal.
        ///
        /// # Examples
        ///
        /// Basisgebruik:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN, 0);")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MIN: Self = 0;

        /// De grootste waarde die kan worden vertegenwoordigd door dit type gehele getal.
        ///
        /// # Examples
        ///
        /// Basisgebruik:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX, ", stringify!($MaxV), ");")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MAX: Self = !0;

        /// De grootte van dit type integer in bits.
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(int_bits_const)]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::BITS, ", stringify!($BITS), ");")]
        /// ```
        #[unstable(feature = "int_bits_const", issue = "76904")]
        pub const BITS: u32 = $BITS;

        /// Converteert een stringplak in een bepaalde basis naar een geheel getal.
        ///
        /// De tekenreeks is naar verwachting een optioneel `+`-teken, gevolgd door cijfers.
        ///
        /// Voorlopende en achterliggende witruimte vertegenwoordigen een fout.
        /// Cijfers zijn een subset van deze tekens, afhankelijk van `radix`:
        ///
        /// * `0-9`
        /// * `a-z`
        /// * `A-Z`
        ///
        /// # Panics
        ///
        /// Deze functie panics als `radix` niet in het bereik van 2 tot 36 ligt.
        ///
        /// # Examples
        ///
        /// Basisgebruik:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::from_str_radix(\"A\", 16), Ok(10));")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        pub fn from_str_radix(src: &str, radix: u32) -> Result<Self, ParseIntError> {
            from_str_radix(src, radix)
        }

        /// Retourneert het aantal enen in de binaire weergave van `self`.
        ///
        /// # Examples
        ///
        /// Basisgebruik:
        ///
        /// ```
        #[doc = concat!("let n = 0b01001100", stringify!($SelfT), ";")]
        /// assert_eq!(n.count_ones(), 3);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[doc(alias = "popcount")]
        #[doc(alias = "popcnt")]
        #[inline]
        pub const fn count_ones(self) -> u32 {
            intrinsics::ctpop(self as $ActualT) as u32
        }

        /// Retourneert het aantal nullen in de binaire weergave van `self`.
        ///
        /// # Examples
        ///
        /// Basisgebruik:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.count_zeros(), 0);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn count_zeros(self) -> u32 {
            (!self).count_ones()
        }

        /// Retourneert het aantal voorloopnullen in de binaire weergave van `self`.
        ///
        /// # Examples
        ///
        /// Basisgebruik:
        ///
        /// ```
        #[doc = concat!("let n = ", stringify!($SelfT), "::MAX >> 2;")]
        /// assert_eq!(n.leading_zeros(), 2);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn leading_zeros(self) -> u32 {
            intrinsics::ctlz(self as $ActualT) as u32
        }

        /// Retourneert het aantal volgnullen in de binaire weergave van `self`.
        ///
        ///
        /// # Examples
        ///
        /// Basisgebruik:
        ///
        /// ```
        #[doc = concat!("let n = 0b0101000", stringify!($SelfT), ";")]
        /// assert_eq!(n.trailing_zeros(), 3);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn trailing_zeros(self) -> u32 {
            intrinsics::cttz(self) as u32
        }

        /// Retourneert het aantal eerste in de binaire weergave van `self`.
        ///
        /// # Examples
        ///
        /// Basisgebruik:
        ///
        /// ```
        #[doc = concat!("let n = !(", stringify!($SelfT), "::MAX >> 2);")]
        /// assert_eq!(n.leading_ones(), 2);
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[inline]
        pub const fn leading_ones(self) -> u32 {
            (!self).leading_zeros()
        }

        /// Retourneert het aantal achterliggende enen in de binaire weergave van `self`.
        ///
        ///
        /// # Examples
        ///
        /// Basisgebruik:
        ///
        /// ```
        #[doc = concat!("let n = 0b1010111", stringify!($SelfT), ";")]
        /// assert_eq!(n.trailing_ones(), 3);
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[inline]
        pub const fn trailing_ones(self) -> u32 {
            (!self).trailing_zeros()
        }

        /// Verschuift de bits naar links met een opgegeven hoeveelheid, `n`, waarbij de afgekapte bits tot het einde van het resulterende gehele getal worden gewikkeld.
        ///
        ///
        /// Let op: dit is niet dezelfde handeling als de `<<`-schakelautomaat!
        ///
        /// # Examples
        ///
        /// Basisgebruik:
        ///
        /// ```
        #[doc = concat!("let n = ", $rot_op, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_result, ";")]

        #[doc = concat!("assert_eq!(n.rotate_left(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn rotate_left(self, n: u32) -> Self {
            intrinsics::rotate_left(self, n as $SelfT)
        }

        /// Verschuift de bits naar rechts met een gespecificeerde hoeveelheid, `n`, waarbij de afgekapte bits worden omwikkeld met het begin van het resulterende gehele getal.
        ///
        ///
        /// Let op: dit is niet dezelfde handeling als de `>>`-schakelautomaat!
        ///
        /// # Examples
        ///
        /// Basisgebruik:
        ///
        /// ```
        ///
        #[doc = concat!("let n = ", $rot_result, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_op, ";")]

        #[doc = concat!("assert_eq!(n.rotate_right(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn rotate_right(self, n: u32) -> Self {
            intrinsics::rotate_right(self, n as $SelfT)
        }

        /// Keert de bytevolgorde van het gehele getal om.
        ///
        /// # Examples
        ///
        /// Basisgebruik:
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// laat m= n.swap_bytes();
        ///
        #[doc = concat!("assert_eq!(m, ", $swapped, ");")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn swap_bytes(self) -> Self {
            intrinsics::bswap(self as $ActualT) as Self
        }

        /// Keert de volgorde van bits in het gehele getal om.
        /// De minst significante bit wordt de meest significante bit, de tweede minst significante bit wordt de tweede meest significante bit, enz.
        ///
        /// # Examples
        ///
        /// Basisgebruik:
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// laat m= n.reverse_bits();
        ///
        #[doc = concat!("assert_eq!(m, ", $reversed, ");")]
        #[doc = concat!("assert_eq!(0, 0", stringify!($SelfT), ".reverse_bits());")]
        /// ```
        #[stable(feature = "reverse_bits", since = "1.37.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        #[must_use]
        pub const fn reverse_bits(self) -> Self {
            intrinsics::bitreverse(self as $ActualT) as Self
        }

        /// Converteert een geheel getal van big endian naar de endianness van het doel.
        ///
        /// Op big endian is dit een no-op.
        /// Op Little Endian worden de bytes verwisseld.
        ///
        /// # Examples
        ///
        /// Basisgebruik:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// if cfg! (target_endian= "big"){
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n)")]
        /// } anders {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn from_be(x: Self) -> Self {
            #[cfg(target_endian = "big")]
            {
                x
            }
            #[cfg(not(target_endian = "big"))]
            {
                x.swap_bytes()
            }
        }

        /// Converteert een geheel getal van little endian naar de endianness van het doel.
        ///
        /// Op Little Endian is dit een no-op.
        /// Op big endian worden de bytes omgewisseld.
        ///
        /// # Examples
        ///
        /// Basisgebruik:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// if cfg! (target_endian= "little"){
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n)")]
        /// } anders {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn from_le(x: Self) -> Self {
            #[cfg(target_endian = "little")]
            {
                x
            }
            #[cfg(not(target_endian = "little"))]
            {
                x.swap_bytes()
            }
        }

        /// Converteert `self` naar big endian van de endianness van het doel.
        ///
        /// Op big endian is dit een no-op.
        /// Op Little Endian worden de bytes verwisseld.
        ///
        /// # Examples
        ///
        /// Basisgebruik:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// if cfg! (target_endian= "big"){
        ///     assert_eq!(n.to_be(), n)
        /// } anders { assert_eq!(n.to_be(), n.swap_bytes()) }
        ///
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn to_be(self) -> Self { // of niet te zijn?
            #[cfg(target_endian = "big")]
            {
                self
            }
            #[cfg(not(target_endian = "big"))]
            {
                self.swap_bytes()
            }
        }

        /// Converteert `self` naar little endian vanuit de endianness van het doel.
        ///
        /// Op Little Endian is dit een no-op.
        /// Op big endian worden de bytes omgewisseld.
        ///
        /// # Examples
        ///
        /// Basisgebruik:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// if cfg! (target_endian= "little"){
        ///     assert_eq!(n.to_le(), n)
        /// } anders { assert_eq!(n.to_le(), n.swap_bytes()) }
        ///
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn to_le(self) -> Self {
            #[cfg(target_endian = "little")]
            {
                self
            }
            #[cfg(not(target_endian = "little"))]
            {
                self.swap_bytes()
            }
        }

        /// Optellen van gehele getallen gecontroleerd.
        /// Berekent `self + rhs` en retourneert `None` als er sprake is van overflow.
        ///
        /// # Examples
        ///
        /// Basisgebruik:
        ///
        /// ```
        #[doc = concat!(
            "assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(1), ",
            "Some(", stringify!($SelfT), "::MAX - 1));"
        )]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(3), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_add(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_add(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Optellen van gehele getallen niet aangevinkt.Berekent `self + rhs`, ervan uitgaande dat er geen overloop kan optreden.
        /// Dit resulteert in ongedefinieerd gedrag wanneer
        #[doc = concat!("`self + rhs > ", stringify!($SelfT), "::MAX` or `self + rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_add(self, rhs: Self) -> Self {
            // VEILIGHEID: de beller moet zich houden aan het veiligheidscontract voor `unchecked_add`.
            //
            unsafe { intrinsics::unchecked_add(self, rhs) }
        }

        /// Aftrekken van gehele getallen gecontroleerd.
        /// Berekent `self - rhs` en retourneert `None` als er sprake is van overflow.
        ///
        /// # Examples
        ///
        /// Basisgebruik:
        ///
        /// ```
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_sub(1), Some(0));")]
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".checked_sub(1), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_sub(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_sub(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Aftrekken van gehele getallen niet aangevinkt.Berekent `self - rhs`, ervan uitgaande dat er geen overloop kan optreden.
        /// Dit resulteert in ongedefinieerd gedrag wanneer
        #[doc = concat!("`self - rhs > ", stringify!($SelfT), "::MAX` or `self - rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_sub(self, rhs: Self) -> Self {
            // VEILIGHEID: de beller moet zich houden aan het veiligheidscontract voor `unchecked_sub`.
            //
            unsafe { intrinsics::unchecked_sub(self, rhs) }
        }

        /// Gecontroleerde vermenigvuldiging van gehele getallen.
        /// Berekent `self * rhs` en retourneert `None` als er sprake is van overflow.
        ///
        /// # Examples
        ///
        /// Basisgebruik:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_mul(1), Some(5));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_mul(2), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_mul(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_mul(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Ongecontroleerde vermenigvuldiging met gehele getallen.Berekent `self * rhs`, ervan uitgaande dat er geen overloop kan optreden.
        /// Dit resulteert in ongedefinieerd gedrag wanneer
        #[doc = concat!("`self * rhs > ", stringify!($SelfT), "::MAX` or `self * rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_mul(self, rhs: Self) -> Self {
            // VEILIGHEID: de beller moet zich houden aan het veiligheidscontract voor `unchecked_mul`.
            //
            unsafe { intrinsics::unchecked_mul(self, rhs) }
        }

        /// Deling van gehele getallen gecontroleerd.
        /// Berekent `self / rhs` en retourneert `None` als `rhs == 0`.
        ///
        /// # Examples
        ///
        /// Basisgebruik:
        ///
        /// ```
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".checked_div(2), Some(64));")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_div(0), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                // VEILIGHEID: div door nul is hierboven aangevinkt en niet-ondertekende typen hebben geen andere
                // faalwijzen voor divisie
                Some(unsafe { intrinsics::unchecked_div(self, rhs) })
            }
        }

        /// Euclidische divisie gecontroleerd.
        /// Berekent `self.div_euclid(rhs)` en retourneert `None` als `rhs == 0`.
        ///
        /// # Examples
        ///
        /// Basisgebruik:
        ///
        /// ```
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".checked_div_euclid(2), Some(64));")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_div_euclid(0), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                Some(self.div_euclid(rhs))
            }
        }


        /// Geheel getal rest aangevinkt.
        /// Berekent `self % rhs` en retourneert `None` als `rhs == 0`.
        ///
        /// # Examples
        ///
        /// Basisgebruik:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(0), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                // VEILIGHEID: div door nul is hierboven aangevinkt en niet-ondertekende typen hebben geen andere
                // faalwijzen voor divisie
                Some(unsafe { intrinsics::unchecked_rem(self, rhs) })
            }
        }

        /// Gecontroleerd Euclidische modulo.
        /// Berekent `self.rem_euclid(rhs)` en retourneert `None` als `rhs == 0`.
        ///
        /// # Examples
        ///
        /// Basisgebruik:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(0), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                Some(self.rem_euclid(rhs))
            }
        }

        /// Gecontroleerde ontkenning.Berekent `-self` en retourneert `None` tenzij `self==
        /// 0`.
        ///
        /// Merk op dat het negeren van een positief geheel getal zal overlopen.
        ///
        /// # Examples
        ///
        /// Basisgebruik:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".checked_neg(), Some(0));")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_neg(), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn checked_neg(self) -> Option<Self> {
            let (a, b) = self.overflowing_neg();
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Shift links gecontroleerd.
        /// Berekent `self << rhs` en retourneert `None` als `rhs` groter is dan of gelijk is aan het aantal bits in `self`.
        ///
        /// # Examples
        ///
        /// Basisgebruik:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".checked_shl(4), Some(0x10));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shl(129), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shl(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shl(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Shift rechts gecontroleerd.
        /// Berekent `self >> rhs` en retourneert `None` als `rhs` groter is dan of gelijk is aan het aantal bits in `self`.
        ///
        /// # Examples
        ///
        /// Basisgebruik:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(4), Some(0x1));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(129), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shr(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shr(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Gecontroleerde machtsverheffing.
        /// Berekent `self.pow(exp)` en retourneert `None` als er sprake is van overflow.
        ///
        /// # Examples
        ///
        /// Basisgebruik:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".checked_pow(5), Some(32));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_pow(2), None);")]
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_pow(self, mut exp: u32) -> Option<Self> {
            if exp == 0 {
                return Some(1);
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = try_opt!(acc.checked_mul(base));
                }
                exp /= 2;
                base = try_opt!(base.checked_mul(base));
            }

            // sinds exp!=0, ten slotte moet de exp 1 zijn.
            // Behandel het laatste bit van de exponent apart, aangezien het achteraf kwadrateren van de basis niet nodig is en een onnodige overloop kan veroorzaken.
            //
            //

            Some(try_opt!(acc.checked_mul(base)))
        }

        /// Verzadigende toevoeging van gehele getallen.
        /// Berekent `self + rhs`, verzadigend op de numerieke grenzen in plaats van overlopend.
        ///
        /// # Examples
        ///
        /// Basisgebruik:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_add(1), 101);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_add(127), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn saturating_add(self, rhs: Self) -> Self {
            intrinsics::saturating_add(self, rhs)
        }

        /// Aftrekken van gehele getallen.
        /// Berekent `self - rhs`, verzadigend op de numerieke grenzen in plaats van overlopend.
        ///
        /// # Examples
        ///
        /// Basisgebruik:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_sub(27), 73);")]
        #[doc = concat!("assert_eq!(13", stringify!($SelfT), ".saturating_sub(127), 0);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn saturating_sub(self, rhs: Self) -> Self {
            intrinsics::saturating_sub(self, rhs)
        }

        /// Verzadiging van gehele vermenigvuldiging.
        /// Berekent `self * rhs`, verzadigend op de numerieke grenzen in plaats van overlopend.
        ///
        /// # Examples
        ///
        /// Basisgebruik:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".saturating_mul(10), 20);")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX).saturating_mul(10), ", stringify!($SelfT),"::MAX);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_mul(self, rhs: Self) -> Self {
            match self.checked_mul(rhs) {
                Some(x) => x,
                None => Self::MAX,
            }
        }

        /// Verzadiging van gehele machtsverheffing.
        /// Berekent `self.pow(exp)`, verzadigend op de numerieke grenzen in plaats van overlopend.
        ///
        /// # Examples
        ///
        /// Basisgebruik:
        ///
        /// ```
        #[doc = concat!("assert_eq!(4", stringify!($SelfT), ".saturating_pow(3), 64);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_pow(2), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_pow(self, exp: u32) -> Self {
            match self.checked_pow(exp) {
                Some(x) => x,
                None => Self::MAX,
            }
        }

        /// Wrapping (modular) toevoeging.
        /// Berekent `self + rhs` en wikkelt zich rond de grens van het type.
        ///
        /// # Examples
        ///
        /// Basisgebruik:
        ///
        /// ```
        #[doc = concat!("assert_eq!(200", stringify!($SelfT), ".wrapping_add(55), 255);")]
        #[doc = concat!("assert_eq!(200", stringify!($SelfT), ".wrapping_add(", stringify!($SelfT), "::MAX), 199);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_add(self, rhs: Self) -> Self {
            intrinsics::wrapping_add(self, rhs)
        }

        /// (modular) aftrekken verpakken.
        /// Berekent `self - rhs` en wikkelt zich rond de grens van het type.
        ///
        /// # Examples
        ///
        /// Basisgebruik:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_sub(100), 0);")]
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_sub(", stringify!($SelfT), "::MAX), 101);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_sub(self, rhs: Self) -> Self {
            intrinsics::wrapping_sub(self, rhs)
        }

        /// (modular) vermenigvuldiging verpakken.
        /// Berekent `self * rhs` en wikkelt zich rond de grens van het type.
        ///
        /// # Examples
        ///
        /// Basisgebruik:
        ///
        /// Houd er rekening mee dat dit voorbeeld wordt gedeeld tussen typen gehele getallen.
        /// Dat verklaart waarom `u8` hier wordt gebruikt.
        ///
        /// ```
        /// assert_eq!(10u8.wrapping_mul(12), 120);
        /// assert_eq!(25u8.wrapping_mul(12), 44);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
        #[inline]
        pub const fn wrapping_mul(self, rhs: Self) -> Self {
            intrinsics::wrapping_mul(self, rhs)
        }

        /// Wrapping (modular) divisie.Berekent `self / rhs`.
        /// Verpakte indeling op niet-ondertekende typen is gewoon een normale indeling.
        /// Inpakken kan nooit gebeuren.
        /// Deze functie bestaat, zodat alle bewerkingen worden verantwoord in de wikkelbewerkingen.
        ///
        ///
        /// # Examples
        ///
        /// Basisgebruik:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div(10), 10);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div(self, rhs: Self) -> Self {
            self / rhs
        }

        /// Euclidische divisie inpakken.Berekent `self.div_euclid(rhs)`.
        /// Verpakte indeling op niet-ondertekende typen is gewoon een normale indeling.
        /// Inpakken kan nooit gebeuren.
        /// Deze functie bestaat, zodat alle bewerkingen worden verantwoord in de wikkelbewerkingen.
        /// Aangezien voor de positieve gehele getallen alle gangbare definities van deling gelijk zijn, is dit exact gelijk aan `self.wrapping_div(rhs)`.
        ///
        ///
        /// # Examples
        ///
        /// Basisgebruik:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div_euclid(10), 10);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div_euclid(self, rhs: Self) -> Self {
            self / rhs
        }

        /// Rest van (modular) inpakken.Berekent `self % rhs`.
        /// Berekening van ingepakte rest op niet-ondertekende typen is slechts de normale restberekening.
        ///
        /// Inpakken kan nooit gebeuren.
        /// Deze functie bestaat, zodat alle bewerkingen worden verantwoord in de wikkelbewerkingen.
        ///
        /// # Examples
        ///
        /// Basisgebruik:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem(10), 0);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem(self, rhs: Self) -> Self {
            self % rhs
        }

        /// Euclidische modulo inpakken.Berekent `self.rem_euclid(rhs)`.
        /// Verpakte modulo-berekening op niet-ondertekende typen is slechts de normale restberekening.
        /// Inpakken kan nooit gebeuren.
        /// Deze functie bestaat, zodat alle bewerkingen worden verantwoord in de wikkelbewerkingen.
        /// Aangezien voor de positieve gehele getallen alle gangbare definities van deling gelijk zijn, is dit exact gelijk aan `self.wrapping_rem(rhs)`.
        ///
        ///
        /// # Examples
        ///
        /// Basisgebruik:
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem_euclid(10), 0);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem_euclid(self, rhs: Self) -> Self {
            self % rhs
        }

        /// (modular) negatie inpakken.
        /// Berekent `-self` en wikkelt zich rond de grens van het type.
        ///
        /// Aangezien niet-ondertekende typen geen negatieve equivalenten hebben, lopen alle toepassingen van deze functie om (behalve `-0`).
        /// Voor waarden die kleiner zijn dan het maximum van het corresponderende ondertekende type is het resultaat hetzelfde als het casten van de corresponderende waarde met teken.
        ///
        /// Alle grotere waarden zijn gelijk aan `MAX + 1 - (val - MAX - 1)`, waarbij `MAX` het maximum van het corresponderende ondertekende type is.
        ///
        /// # Examples
        ///
        /// Basisgebruik:
        ///
        /// Houd er rekening mee dat dit voorbeeld wordt gedeeld tussen typen gehele getallen.
        /// Dat verklaart waarom `i8` hier wordt gebruikt.
        ///
        /// ```
        /// assert_eq!(100i8.wrapping_neg(), -100);
        /// assert_eq!((-128i8).wrapping_neg(), -128);
        /// ```
        ///
        ///
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[inline]
        pub const fn wrapping_neg(self) -> Self {
            self.overflowing_neg().0
        }

        /// Panic-vrij bitsgewijs verschuiven naar links;
        /// levert `self << mask(rhs)` op, waarbij `mask` alle bits van hoge orde van `rhs` verwijdert die ervoor zorgen dat de verschuiving de bitbreedte van het type overschrijdt.
        ///
        /// Merk op dat dit *niet* hetzelfde is als linksom draaien;de RHS van een wikkelverschuiving-links is beperkt tot het bereik van het type, in plaats van dat de bits die uit de LHS worden geschoven naar het andere uiteinde worden teruggestuurd.
        /// De primitieve integer-typen implementeren allemaal een [`rotate_left`](Self::rotate_left)-functie, die u in plaats daarvan misschien wilt.
        ///
        /// # Examples
        ///
        /// Basisgebruik:
        ///
        /// ```
        ///
        ///
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".wrapping_shl(7), 128);")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".wrapping_shl(128), 1);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_shl(self, rhs: u32) -> Self {
            // VEILIGHEID: de maskering door de bitsize van het type zorgt ervoor dat we niet verschuiven
            // buiten de grenzen
            unsafe {
                intrinsics::unchecked_shl(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// Panic-vrije bitsgewijze verschuiving-rechts;
        /// levert `self >> mask(rhs)` op, waarbij `mask` alle bits van hoge orde van `rhs` verwijdert die ervoor zorgen dat de verschuiving de bitbreedte van het type overschrijdt.
        ///
        /// Merk op dat dit *niet* hetzelfde is als roteren-rechts;de RHS van een omhullende shift-right is beperkt tot het bereik van het type, in plaats van dat de bits die uit de LHS worden geschoven naar het andere uiteinde worden teruggestuurd.
        /// De primitieve integer-typen implementeren allemaal een [`rotate_right`](Self::rotate_right)-functie, die u in plaats daarvan misschien wilt.
        ///
        /// # Examples
        ///
        /// Basisgebruik:
        ///
        /// ```
        ///
        ///
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".wrapping_shr(7), 1);")]
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".wrapping_shr(128), 128);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_shr(self, rhs: u32) -> Self {
            // VEILIGHEID: de maskering door de bitsize van het type zorgt ervoor dat we niet verschuiven
            // buiten de grenzen
            unsafe {
                intrinsics::unchecked_shr(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// (modular) machtsverheffen verpakken.
        /// Berekent `self.pow(exp)` en wikkelt zich rond de grens van het type.
        ///
        /// # Examples
        ///
        /// Basisgebruik:
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".wrapping_pow(5), 243);")]
        /// assert_eq!(3u8.wrapping_pow(6), 217);
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc.wrapping_mul(base);
                }
                exp /= 2;
                base = base.wrapping_mul(base);
            }

            // sinds exp!=0, ten slotte moet de exp 1 zijn.
            // Behandel het laatste bit van de exponent apart, aangezien het achteraf kwadrateren van de basis niet nodig is en een onnodige overloop kan veroorzaken.
            //
            //
            acc.wrapping_mul(base)
        }

        /// Berekent `self` + `rhs`
        ///
        /// Retourneert een tupel van de optelling samen met een booleaanse waarde die aangeeft of er een rekenkundige overloop zou optreden.
        /// Als er een overflow zou zijn opgetreden, wordt de ingepakte waarde geretourneerd.
        ///
        /// # Examples
        ///
        /// Basisgebruik
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_add(2), (7, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.overflowing_add(1), (0, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_add(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::add_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// Berekent `self`, `rhs`
        ///
        /// Retourneert een tupel van de aftrekking samen met een booleaanse waarde die aangeeft of er een rekenkundige overloop zou optreden.
        /// Als er een overflow zou zijn opgetreden, wordt de ingepakte waarde geretourneerd.
        ///
        /// # Examples
        ///
        /// Basisgebruik
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_sub(2), (3, false));")]
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".overflowing_sub(1), (", stringify!($SelfT), "::MAX, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_sub(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::sub_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// Berekent de vermenigvuldiging van `self` en `rhs`.
        ///
        /// Retourneert een tupel van de vermenigvuldiging samen met een booleaanse waarde die aangeeft of er een rekenkundige overloop zou optreden.
        /// Als er een overflow zou zijn opgetreden, wordt de ingepakte waarde geretourneerd.
        ///
        /// # Examples
        ///
        /// Basisgebruik:
        ///
        /// Houd er rekening mee dat dit voorbeeld wordt gedeeld tussen typen gehele getallen.
        /// Dat verklaart waarom `u32` hier wordt gebruikt.
        ///
        /// ```
        /// assert_eq!(5u32.overflowing_mul(2), (10, false));
        /// assert_eq!(1_000_000_000u32.overflowing_mul(10), (1410065408, true));
        /// ```
        ///
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
        #[inline]
        pub const fn overflowing_mul(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::mul_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// Berekent de deler wanneer `self` wordt gedeeld door `rhs`.
        ///
        /// Retourneert een tupel van de deler samen met een booleaanse waarde die aangeeft of er een rekenkundige overloop zou optreden.
        /// Merk op dat voor niet-ondertekende gehele getallen een overloop nooit optreedt, dus de tweede waarde is altijd `false`.
        ///
        /// # Panics
        ///
        /// Deze functie zal panic zijn als `rhs` 0 is.
        ///
        /// # Examples
        ///
        /// Basisgebruik
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div(2), (2, false));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div(self, rhs: Self) -> (Self, bool) {
            (self / rhs, false)
        }

        /// Berekent het quotiënt van Euclidische deling `self.div_euclid(rhs)`.
        ///
        /// Retourneert een tupel van de deler samen met een booleaanse waarde die aangeeft of er een rekenkundige overloop zou optreden.
        /// Merk op dat voor niet-ondertekende gehele getallen een overloop nooit optreedt, dus de tweede waarde is altijd `false`.
        /// Aangezien voor de positieve gehele getallen alle gangbare definities van deling gelijk zijn, is dit exact gelijk aan `self.overflowing_div(rhs)`.
        ///
        ///
        /// # Panics
        ///
        /// Deze functie zal panic zijn als `rhs` 0 is.
        ///
        /// # Examples
        ///
        /// Basisgebruik
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div_euclid(2), (2, false));")]
        /// ```
        #[inline]
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div_euclid(self, rhs: Self) -> (Self, bool) {
            (self / rhs, false)
        }

        /// Berekent de rest als `self` wordt gedeeld door `rhs`.
        ///
        /// Retourneert een tupel van de rest na het delen, samen met een booleaanse waarde die aangeeft of er een rekenkundige overloop zou optreden.
        /// Merk op dat voor niet-ondertekende gehele getallen een overloop nooit optreedt, dus de tweede waarde is altijd `false`.
        ///
        /// # Panics
        ///
        /// Deze functie zal panic zijn als `rhs` 0 is.
        ///
        /// # Examples
        ///
        /// Basisgebruik
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem(2), (1, false));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_rem(self, rhs: Self) -> (Self, bool) {
            (self % rhs, false)
        }

        /// Berekent de rest `self.rem_euclid(rhs)` als door Euclidische deling.
        ///
        /// Retourneert een tupel van de modulo na delen samen met een booleaanse waarde die aangeeft of er een rekenkundige overloop zou optreden.
        /// Merk op dat voor niet-ondertekende gehele getallen een overloop nooit optreedt, dus de tweede waarde is altijd `false`.
        /// Aangezien voor de positieve gehele getallen alle gangbare definities van deling gelijk zijn, is deze bewerking exact gelijk aan `self.overflowing_rem(rhs)`.
        ///
        ///
        /// # Panics
        ///
        /// Deze functie zal panic zijn als `rhs` 0 is.
        ///
        /// # Examples
        ///
        /// Basisgebruik
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem_euclid(2), (1, false));")]
        /// ```
        #[inline]
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_rem_euclid(self, rhs: Self) -> (Self, bool) {
            (self % rhs, false)
        }

        /// Negeert zichzelf op een overvolle manier.
        ///
        /// Retourneert `!self + 1` met behulp van terugloopbewerkingen om de waarde te retourneren die de negatie van deze niet-ondertekende waarde vertegenwoordigt.
        /// Merk op dat bij positieve niet-ondertekende waarden altijd een overloop optreedt, maar dat het negeren van 0 niet overloopt.
        ///
        /// # Examples
        ///
        /// Basisgebruik
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".overflowing_neg(), (0, false));")]
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".overflowing_neg(), (-2i32 as ", stringify!($SelfT), ", true));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        pub const fn overflowing_neg(self) -> (Self, bool) {
            ((!self).wrapping_add(1), self != 0)
        }

        /// Verschuift zichzelf naar links door `rhs`-bits.
        ///
        /// Retourneert een tupel van de verschoven versie van self samen met een booleaanse waarde die aangeeft of de verschuivingswaarde groter of gelijk was aan het aantal bits.
        /// Als de verschuivingswaarde te groot is, wordt de waarde gemaskeerd (N-1) waar N het aantal bits is, en deze waarde wordt vervolgens gebruikt om de verschuiving uit te voeren.
        ///
        /// # Examples
        ///
        /// Basisgebruik
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".overflowing_shl(4), (0x10, false));")]
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".overflowing_shl(132), (0x10, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shl(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shl(rhs), (rhs > ($BITS - 1)))
        }

        /// Verschuift zichzelf naar rechts door `rhs`-bits.
        ///
        /// Retourneert een tupel van de verschoven versie van self samen met een booleaanse waarde die aangeeft of de verschuivingswaarde groter of gelijk was aan het aantal bits.
        /// Als de verschuivingswaarde te groot is, wordt de waarde gemaskeerd (N-1) waar N het aantal bits is, en deze waarde wordt vervolgens gebruikt om de verschuiving uit te voeren.
        ///
        /// # Examples
        ///
        /// Basisgebruik
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".overflowing_shr(4), (0x1, false));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".overflowing_shr(132), (0x1, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shr(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shr(rhs), (rhs > ($BITS - 1)))
        }

        /// Verheft zichzelf tot de kracht van `exp`, gebruikmakend van machtsverheffen door kwadratuur.
        ///
        /// Retourneert een tupel van de machtsverheffen samen met een bool die aangeeft of er een overflow heeft plaatsgevonden.
        ///
        ///
        /// # Examples
        ///
        /// Basisgebruik:
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".overflowing_pow(5), (243, false));")]
        /// assert_eq!(3u8.overflowing_pow(6), (217, waar));
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_pow(self, mut exp: u32) -> (Self, bool) {
            if exp == 0{
                return (1,false);
            }
            let mut base = self;
            let mut acc: Self = 1;
            let mut overflown = false;
            // Krasruimte voor het opslaan van resultaten van overflowing_mul.
            let mut r;

            while exp > 1 {
                if (exp & 1) == 1 {
                    r = acc.overflowing_mul(base);
                    acc = r.0;
                    overflown |= r.1;
                }
                exp /= 2;
                r = base.overflowing_mul(base);
                base = r.0;
                overflown |= r.1;
            }

            // sinds exp!=0, ten slotte moet de exp 1 zijn.
            // Behandel het laatste bit van de exponent apart, aangezien het achteraf kwadrateren van de basis niet nodig is en een onnodige overloop kan veroorzaken.
            //
            //
            r = acc.overflowing_mul(base);
            r.1 |= overflown;

            r
        }

        /// Verheft zichzelf tot de kracht van `exp`, gebruikmakend van machtsverheffen door kwadratuur.
        ///
        /// # Examples
        ///
        /// Basisgebruik:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".pow(5), 32);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc * base;
                }
                exp /= 2;
                base = base * base;
            }

            // sinds exp!=0, ten slotte moet de exp 1 zijn.
            // Behandel het laatste bit van de exponent apart, aangezien het achteraf kwadrateren van de basis niet nodig is en een onnodige overloop kan veroorzaken.
            //
            //
            acc * base
        }

        /// Voert Euclidische deling uit.
        ///
        /// Aangezien voor de positieve gehele getallen alle gangbare definities van deling gelijk zijn, is dit exact gelijk aan `self / rhs`.
        ///
        ///
        /// # Panics
        ///
        /// Deze functie zal panic zijn als `rhs` 0 is.
        ///
        /// # Examples
        ///
        /// Basisgebruik:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(7", stringify!($SelfT), ".div_euclid(4), 1); // or any other integer type")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn div_euclid(self, rhs: Self) -> Self {
            self / rhs
        }


        /// Berekent de kleinste rest van `self (mod rhs)`.
        ///
        /// Aangezien voor de positieve gehele getallen alle gangbare definities van deling gelijk zijn, is dit exact gelijk aan `self % rhs`.
        ///
        ///
        /// # Panics
        ///
        /// Deze functie zal panic zijn als `rhs` 0 is.
        ///
        /// # Examples
        ///
        /// Basisgebruik:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(7", stringify!($SelfT), ".rem_euclid(4), 3); // or any other integer type")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn rem_euclid(self, rhs: Self) -> Self {
            self % rhs
        }

        /// Retourneert `true` als en slechts als `self == 2^k` voor sommige `k`.
        ///
        /// # Examples
        ///
        /// Basisgebruik:
        ///
        /// ```
        #[doc = concat!("assert!(16", stringify!($SelfT), ".is_power_of_two());")]
        #[doc = concat!("assert!(!10", stringify!($SelfT), ".is_power_of_two());")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_is_power_of_two", since = "1.32.0")]
        #[inline]
        pub const fn is_power_of_two(self) -> bool {
            self.count_ones() == 1
        }

        // Retourneert één minder dan de volgende macht van twee.
        // (Voor 8u8 is de volgende macht van twee 8u8 en voor 6u8 is het 8u8)
        //
        // 8u8.one_less_than_next_power_of_two() ==7
        // 6u8.one_less_than_next_power_of_two() ==7
        //
        // Deze methode kan niet overlopen, omdat het in de `next_power_of_two`-overloopgevallen in plaats daarvan de maximale waarde van het type retourneert en 0 voor 0 kan retourneren.
        //
        //
        #[inline]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        const fn one_less_than_next_power_of_two(self) -> Self {
            if self <= 1 { return 0; }

            let p = self - 1;
            // VEILIGHEID: Omdat `p > 0`, het niet volledig uit voorloopnullen kan bestaan.
            // Dat betekent dat de verschuiving altijd in-bounds is en dat sommige processors (zoals intel pre-haswell) efficiëntere ctlz-intrinsiek hebben als het argument niet-nul is.
            //
            //
            let z = unsafe { intrinsics::ctlz_nonzero(p) };
            <$SelfT>::MAX >> z
        }

        /// Retourneert de kleinste macht van twee groter dan of gelijk aan `self`.
        ///
        /// Wanneer de retourwaarde overstroomt (dwz `self > (1 << (N-1))` voor type `uN`), is het panics in debug-modus en wordt de retourwaarde verpakt in 0 in de releasemodus (de enige situatie waarin de methode 0 kan retourneren).
        ///
        ///
        /// # Examples
        ///
        /// Basisgebruik:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".next_power_of_two(), 2);")]
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".next_power_of_two(), 4);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn next_power_of_two(self) -> Self {
            self.one_less_than_next_power_of_two() + 1
        }

        /// Retourneert de kleinste macht van twee groter dan of gelijk aan `n`.
        /// Als de volgende macht van twee groter is dan de maximale waarde van het type, wordt `None` geretourneerd, anders wordt de macht van twee verpakt in `Some`.
        ///
        ///
        /// # Examples
        ///
        /// Basisgebruik:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".checked_next_power_of_two(), Some(2));")]
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".checked_next_power_of_two(), Some(4));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_next_power_of_two(), None);")]
        /// ```
        #[inline]
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        pub const fn checked_next_power_of_two(self) -> Option<Self> {
            self.one_less_than_next_power_of_two().checked_add(1)
        }

        /// Retourneert de kleinste macht van twee groter dan of gelijk aan `n`.
        /// Als de volgende macht van twee groter is dan de maximale waarde van het type, wordt de geretourneerde waarde verpakt in `0`.
        ///
        ///
        /// # Examples
        ///
        /// Basisgebruik:
        ///
        /// ```
        /// #![feature(wrapping_next_power_of_two)]
        ///
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".wrapping_next_power_of_two(), 2);")]
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".wrapping_next_power_of_two(), 4);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.wrapping_next_power_of_two(), 0);")]
        /// ```
        #[unstable(feature = "wrapping_next_power_of_two", issue = "32463",
                   reason = "needs decision on wrapping behaviour")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        pub const fn wrapping_next_power_of_two(self) -> Self {
            self.one_less_than_next_power_of_two().wrapping_add(1)
        }

        /// Retourneer de geheugenrepresentatie van dit gehele getal als een byte-array in bytevolgorde big-endian (network).
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_be_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $be_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn to_be_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_be().to_ne_bytes()
        }

        /// Retourneer de geheugenrepresentatie van dit gehele getal als een byte-array in bytevolgorde little-endian.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_le_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $le_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn to_le_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_le().to_ne_bytes()
        }

        /// Retourneer de geheugenrepresentatie van dit gehele getal als een byte-array in de oorspronkelijke bytevolgorde.
        ///
        /// Aangezien de native endianness van het doelplatform wordt gebruikt, moet draagbare code in plaats daarvan [`to_be_bytes`] of [`to_le_bytes`] gebruiken.
        ///
        ///
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// [`to_be_bytes`]: Self::to_be_bytes
        /// [`to_le_bytes`]: Self::to_le_bytes
        ///
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_ne_bytes();")]
        /// assert_eq!(
        ///     bytes, als cfg! (target_endian= "big"){
        ///
        #[doc = concat!("        ", $be_bytes)]
        /// } anders {
        #[doc = concat!("        ", $le_bytes)]
        /// }
        /// );
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // VEILIGHEID: const geluid omdat gehele getallen gewone oude datatypes zijn, dus dat kunnen we altijd
        // transmuteer ze naar arrays van bytes
        #[rustc_allow_const_fn_unstable(const_fn_transmute)]
        #[inline]
        pub const fn to_ne_bytes(self) -> [u8; mem::size_of::<Self>()] {
            // VEILIGHEID: gehele getallen zijn gewone oude datatypes, dus we kunnen ze altijd naar transmuteren
            // arrays van bytes
            unsafe { mem::transmute(self) }
        }

        /// Retourneer de geheugenrepresentatie van dit gehele getal als een byte-array in de oorspronkelijke bytevolgorde.
        ///
        ///
        /// [`to_ne_bytes`] verdient waar mogelijk de voorkeur boven dit.
        ///
        /// [`to_ne_bytes`]: Self::to_ne_bytes
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(num_as_ne_bytes)]
        #[doc = concat!("let num = ", $swap_op, stringify!($SelfT), ";")]
        /// laat bytes= num.as_ne_bytes();
        /// assert_eq!(
        ///     bytes, als cfg! (target_endian= "big"){
        ///
        #[doc = concat!("        &", $be_bytes)]
        /// } anders {
        #[doc = concat!("        &", $le_bytes)]
        /// }
        /// );
        /// ```
        #[unstable(feature = "num_as_ne_bytes", issue = "76976")]
        #[inline]
        pub fn as_ne_bytes(&self) -> &[u8; mem::size_of::<Self>()] {
            // VEILIGHEID: gehele getallen zijn gewone oude datatypes, dus we kunnen ze altijd naar transmuteren
            // arrays van bytes
            unsafe { &*(self as *const Self as *const _) }
        }

        /// Maak een native endian integer-waarde op basis van de weergave ervan als een byte-array in big endian.
        ///
        ///
        #[doc = $from_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_be_bytes(", $be_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// gebruik std::convert::TryInto;
        #[doc = concat!("fn read_be_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * input=rust;
        #[doc = concat!("    ", stringify!($SelfT), "::from_be_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn from_be_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_be(Self::from_ne_bytes(bytes))
        }

        /// Maak een native endian integer-waarde op basis van de weergave ervan als een byte-array in little endian.
        ///
        ///
        #[doc = $from_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_le_bytes(", $le_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// gebruik std::convert::TryInto;
        #[doc = concat!("fn read_le_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * input=rust;
        #[doc = concat!("    ", stringify!($SelfT), "::from_le_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn from_le_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_le(Self::from_ne_bytes(bytes))
        }

        /// Maak een native endian integer-waarde op basis van de geheugenweergave als een byte-array in native endianness.
        ///
        /// Aangezien de native endianness van het doelplatform wordt gebruikt, wil draagbare code in plaats daarvan waarschijnlijk [`from_be_bytes`] of [`from_le_bytes`] gebruiken.
        ///
        ///
        /// [`from_be_bytes`]: Self::from_be_bytes
        /// [`from_le_bytes`]: Self::from_le_bytes
        ///
        ///
        ///
        #[doc = $from_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_ne_bytes(if cfg!(target_endian = \"big\") {")]
        #[doc = concat!("    ", $be_bytes, "")]
        /// } anders {
        #[doc = concat!("    ", $le_bytes, "")]
        /// });
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// gebruik std::convert::TryInto;
        #[doc = concat!("fn read_ne_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * input=rust;
        #[doc = concat!("    ", stringify!($SelfT), "::from_ne_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // VEILIGHEID: const geluid omdat gehele getallen gewone oude datatypes zijn, dus dat kunnen we altijd
        // transmuteer naar hen
        #[rustc_allow_const_fn_unstable(const_fn_transmute)]
        #[inline]
        pub const fn from_ne_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            // VEILIGHEID: gehele getallen zijn gewone oude datatypes, dus we kunnen er altijd naar transmuteren
            unsafe { mem::transmute(bytes) }
        }

        /// Nieuwe code verdient de voorkeur
        #[doc = concat!("[`", stringify!($SelfT), "::MIN", "`] instead.")]
        /// Retourneert de kleinste waarde die kan worden vertegenwoordigd door dit type gehele getal.
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_promotable]
        #[inline(always)]
        #[rustc_const_stable(feature = "const_max_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MIN` associated constant on this type")]
        pub const fn min_value() -> Self { Self::MIN }

        /// Nieuwe code verdient de voorkeur
        #[doc = concat!("[`", stringify!($SelfT), "::MAX", "`] instead.")]
        /// Retourneert de grootste waarde die kan worden vertegenwoordigd door dit type gehele getal.
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_promotable]
        #[inline(always)]
        #[rustc_const_stable(feature = "const_max_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MAX` associated constant on this type")]
        pub const fn max_value() -> Self { Self::MAX }
    }
}