//! Vrijwel directe (maar enigszins geoptimaliseerde) Rust-vertaling van Figuur 3 van "Drijvende-kommagetallen snel en nauwkeurig afdrukken" [^ 1].
//!
//!
//! [^1]: Burger, RG en Dybvig, RK 1996. Getallen met drijvende komma afdrukken
//!   snel en nauwkeurig.SIGPLAN Niet.31, 5 (mei 1996), 108-116.

use crate::cmp::Ordering;
use crate::mem::MaybeUninit;

use crate::num::bignum::Big32x40 as Big;
use crate::num::bignum::Digit32 as Digit;
use crate::num::flt2dec::estimator::estimate_scaling_factor;
use crate::num::flt2dec::{round_up, Decoded, MAX_SIG_DIGITS};

static POW10: [Digit; 10] =
    [1, 10, 100, 1000, 10000, 100000, 1000000, 10000000, 100000000, 1000000000];
static TWOPOW10: [Digit; 10] =
    [2, 20, 200, 2000, 20000, 200000, 2000000, 20000000, 200000000, 2000000000];

// vooraf berekende arrays van `Digit`s voor 10 ^ (2 ^ n)
static POW10TO16: [Digit; 2] = [0x6fc10000, 0x2386f2];
static POW10TO32: [Digit; 4] = [0, 0x85acef81, 0x2d6d415b, 0x4ee];
static POW10TO64: [Digit; 7] = [0, 0, 0xbf6a1f01, 0x6e38ed64, 0xdaa797ed, 0xe93ff9f4, 0x184f03];
static POW10TO128: [Digit; 14] = [
    0, 0, 0, 0, 0x2e953e01, 0x3df9909, 0xf1538fd, 0x2374e42f, 0xd3cff5ec, 0xc404dc08, 0xbccdb0da,
    0xa6337f19, 0xe91f2603, 0x24e,
];
static POW10TO256: [Digit; 27] = [
    0, 0, 0, 0, 0, 0, 0, 0, 0x982e7c01, 0xbed3875b, 0xd8d99f72, 0x12152f87, 0x6bde50c6, 0xcf4a6e70,
    0xd595d80f, 0x26b2716e, 0xadc666b0, 0x1d153624, 0x3c42d35a, 0x63ff540e, 0xcc5573c0, 0x65f9ef17,
    0x55bc28f2, 0x80dcc7f7, 0xf46eeddc, 0x5fdcefce, 0x553f7,
];

#[doc(hidden)]
pub fn mul_pow10(x: &mut Big, n: usize) -> &mut Big {
    debug_assert!(n < 512);
    if n & 7 != 0 {
        x.mul_small(POW10[n & 7]);
    }
    if n & 8 != 0 {
        x.mul_small(POW10[8]);
    }
    if n & 16 != 0 {
        x.mul_digits(&POW10TO16);
    }
    if n & 32 != 0 {
        x.mul_digits(&POW10TO32);
    }
    if n & 64 != 0 {
        x.mul_digits(&POW10TO64);
    }
    if n & 128 != 0 {
        x.mul_digits(&POW10TO128);
    }
    if n & 256 != 0 {
        x.mul_digits(&POW10TO256);
    }
    x
}

fn div_2pow10(x: &mut Big, mut n: usize) -> &mut Big {
    let largest = POW10.len() - 1;
    while n > largest {
        x.div_rem_small(POW10[largest]);
        n -= largest;
    }
    x.div_rem_small(TWOPOW10[n]);
    x
}

// alleen bruikbaar als `x < 16 * scale`;`scaleN` moet `scale.mul_small(N)` zijn
fn div_rem_upto_16<'a>(
    x: &'a mut Big,
    scale: &Big,
    scale2: &Big,
    scale4: &Big,
    scale8: &Big,
) -> (u8, &'a mut Big) {
    let mut d = 0;
    if *x >= *scale8 {
        x.sub(scale8);
        d += 8;
    }
    if *x >= *scale4 {
        x.sub(scale4);
        d += 4;
    }
    if *x >= *scale2 {
        x.sub(scale2);
        d += 2;
    }
    if *x >= *scale {
        x.sub(scale);
        d += 1;
    }
    debug_assert!(*x < *scale);
    (d, x)
}

/// De kortste modusimplementatie voor Dragon.
pub fn format_shortest<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    // het nummer `v` dat moet worden opgemaakt, is bekend als:
    // - gelijk aan `mant * 2^exp`;
    // - voorafgegaan door `(mant - 2 *minus)* 2^exp` in het originele type;en
    // - gevolgd door `(mant + 2 *plus)* 2^exp` in het originele type.
    //
    // uiteraard kunnen `minus` en `plus` niet nul zijn.(voor oneindigheden gebruiken we waarden die buiten het bereik vallen.) ook nemen we aan dat er ten minste één cijfer wordt gegenereerd, dwz `mant` kan ook niet nul zijn.
    //
    // dit betekent ook dat elk getal tussen `low = (mant - minus)*2^exp` en `high = (mant + plus)* 2^exp` zal worden toegewezen aan dit exacte drijvende-kommagetal, inclusief grenzen als de oorspronkelijke mantisse even was (dwz `!mant_was_odd`).
    //
    //
    //

    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());
    assert!(buf.len() >= MAX_SIG_DIGITS);

    // `a.cmp(&b) < rounding` is `if d.inclusive {a <= b} else {a < b}`
    let rounding = if d.inclusive { Ordering::Greater } else { Ordering::Equal };

    // schat `k_0` op basis van originele invoer die voldoet aan `10^(k_0-1) < high <= 10^(k_0+1)`.
    // de strakke `k` die voldoet aan `10^(k-1) < high <= 10^k` wordt later berekend.
    let mut k = estimate_scaling_factor(d.mant + d.plus, d.exp);

    // converteer `{mant, plus, minus} * 2^exp` naar de fractionele vorm zodat:
    // - `v = mant / scale`
    // - `low = (mant - minus) / scale`
    // - `high = (mant + plus) / scale`
    let mut mant = Big::from_u64(d.mant);
    let mut minus = Big::from_u64(d.minus);
    let mut plus = Big::from_u64(d.plus);
    let mut scale = Big::from_small(1);
    if d.exp < 0 {
        scale.mul_pow2(-d.exp as usize);
    } else {
        mant.mul_pow2(d.exp as usize);
        minus.mul_pow2(d.exp as usize);
        plus.mul_pow2(d.exp as usize);
    }

    // deel `mant` door `10^k`.nu `scale / 10 < mant + plus <= scale * 10`.
    if k >= 0 {
        mul_pow10(&mut scale, k as usize);
    } else {
        mul_pow10(&mut mant, -k as usize);
        mul_pow10(&mut minus, -k as usize);
        mul_pow10(&mut plus, -k as usize);
    }

    // fixup wanneer `mant + plus > scale` (of `>=`).
    // we zijn eigenlijk `scale` niet aan het aanpassen, aangezien we in plaats daarvan de initiële vermenigvuldiging kunnen overslaan.
    // nu `scale < mant + plus <= scale * 10` en we zijn klaar om cijfers te genereren.
    //
    // merk op dat `d[0]`* * nul kan zijn, wanneer `scale - plus < mant < scale`.
    // in dit geval wordt de afrondingsvoorwaarde (`up` hieronder) onmiddellijk geactiveerd.
    if scale.cmp(mant.clone().add(&plus)) < rounding {
        // gelijk aan het schalen van `scale` met 10
        k += 1;
    } else {
        mant.mul_small(10);
        minus.mul_small(10);
        plus.mul_small(10);
    }

    // cache `(2, 4, 8) * scale` voor het genereren van cijfers.
    let mut scale2 = scale.clone();
    scale2.mul_pow2(1);
    let mut scale4 = scale.clone();
    scale4.mul_pow2(2);
    let mut scale8 = scale.clone();
    scale8.mul_pow2(3);

    let mut down;
    let mut up;
    let mut i = 0;
    loop {
        // invarianten, waarbij `d[0..n-1]` cijfers zijn die tot dusver zijn gegenereerd:
        // - `v = mant / scale * 10^(k-n-1) + d[0..n-1] * 10^(k-n)`
        // - `v - low = minus / scale * 10^(k-n-1)`
        // - `high - v = plus / scale * 10^(k-n-1)`
        // - `(mant + plus) / scale <= 10` (dus `mant / scale < 10`) waarbij `d[i..j]` een afkorting is voor `d [i] * 10 ^ (ji) + ...
        // + d [j-1] * 10 + d[j]`.

        // één cijfer genereren: `d[n] = floor(mant / scale) < 10`.
        let (d, _) = div_rem_upto_16(&mut mant, &scale, &scale2, &scale4, &scale8);
        debug_assert!(d < 10);
        buf[i] = MaybeUninit::new(b'0' + d);
        i += 1;

        // dit is een vereenvoudigde beschrijving van het aangepaste Dragon-algoritme.
        // veel tussenliggende afleidingen en volledigheidsargumenten zijn gemakshalve weggelaten.
        //
        // begin met gewijzigde invarianten, aangezien we `n` hebben bijgewerkt:
        // - `v = mant / scale * 10^(k-n) + d[0..n-1] * 10^(k-n)`
        // - `v - low = minus / scale * 10^(k-n)`
        // - `high - v = plus / scale * 10^(k-n)`
        //
        // neem aan dat `d[0..n-1]` de kortste weergave is tussen `low` en `high`, dat wil zeggen dat `d[0..n-1]` aan beide volgende voorwaarden voldoet, maar `d[0..n-2]` niet:
        //
        // - `low < d[0..n-1] * 10^(k-n) < high` (bijectiviteit: cijfers worden afgerond op `v`);en
        // - `abs(v / 10^(k-n) - d[0..n-1]) <= 1/2` (het laatste cijfer is correct).
        //
        // de tweede voorwaarde vereenvoudigt tot `2 * mant <= scale`.
        // het oplossen van invarianten in termen van `mant`, `low` en `high` levert een eenvoudigere versie van de eerste voorwaarde op: `-plus < mant < minus`.
        // sinds `-plus < 0 <= mant` hebben we de juiste kortste weergave als `mant < minus` en `2 * mant <= scale`.
        // (de eerste wordt `mant <= minus` wanneer de originele mantisse even is.)
        //
        // als de tweede niet klopt (`2 * mant> scale`), moeten we het laatste cijfer verhogen.
        // dit is genoeg om die toestand te herstellen: we weten al dat de cijfergeneratie `0 <= v / 10^(k-n) - d[0..n-1] < 1` garandeert.
        // in dit geval wordt de eerste voorwaarde `-plus < mant - scale < minus`.
        // sinds `mant < scale` na de generatie hebben we `scale < mant + plus`.
        // (nogmaals, dit wordt `scale <= mant + plus` wanneer de originele mantisse even is.)
        //
        // Kortom:
        // - stop en rond `down` af (bewaar de cijfers zoals ze zijn) wanneer `mant < minus` (of `<=`).
        // - stop en rond `up` af (verhoog het laatste cijfer) wanneer `scale < mant + plus` (of `<=`).
        // - blijf anders genereren.
        //
        //
        //
        down = mant.cmp(&minus) < rounding;
        up = scale.cmp(mant.clone().add(&plus)) < rounding;
        if down || up {
            break;
        } // we hebben de kortste weergave, ga verder met de afronding

        // herstel de invarianten.
        // hierdoor wordt het algoritme altijd beëindigd: `minus` en `plus` nemen altijd toe, maar `mant` wordt afgekapt modulo `scale` en `scale` staat vast.
        //
        mant.mul_small(10);
        minus.mul_small(10);
        plus.mul_small(10);
    }

    // afronding naar boven gebeurt wanneer i) alleen de afrondingsvoorwaarde werd geactiveerd, of ii) beide voorwaarden werden geactiveerd en tiebreking de voorkeur geeft aan afronden naar boven.
    //
    //
    if up && (!down || *mant.mul_pow2(1) >= scale) {
        // als afronding de lengte verandert, moet de exponent ook veranderen.
        // het lijkt erop dat het erg moeilijk is om aan deze voorwaarde te voldoen (mogelijk onmogelijk), maar we zijn hier gewoon veilig en consistent.
        //
        // VEILIGHEID: we hebben dat geheugen hierboven geïnitialiseerd.
        if let Some(c) = round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) }) {
            buf[i] = MaybeUninit::new(c);
            i += 1;
            k += 1;
        }
    }

    // VEILIGHEID: we hebben dat geheugen hierboven geïnitialiseerd.
    (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..i]) }, k)
}

/// De exacte en vaste modusimplementatie voor Dragon.
pub fn format_exact<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());

    // schat `k_0` op basis van originele invoer die voldoet aan `10^(k_0-1) < v <= 10^(k_0+1)`.
    let mut k = estimate_scaling_factor(d.mant, d.exp);

    // `v = mant / scale`.
    let mut mant = Big::from_u64(d.mant);
    let mut scale = Big::from_small(1);
    if d.exp < 0 {
        scale.mul_pow2(-d.exp as usize);
    } else {
        mant.mul_pow2(d.exp as usize);
    }

    // deel `mant` door `10^k`.nu `scale / 10 < mant <= scale * 10`.
    if k >= 0 {
        mul_pow10(&mut scale, k as usize);
    } else {
        mul_pow10(&mut mant, -k as usize);
    }

    // fixup wanneer `mant + plus >= scale`, waarbij `plus / scale = 10^-buf.len() / 2`.
    // Om de bignum met een vaste grootte te behouden, gebruiken we eigenlijk `mant + floor(plus) >= scale`.
    // we zijn eigenlijk `scale` niet aan het aanpassen, aangezien we in plaats daarvan de initiële vermenigvuldiging kunnen overslaan.
    // opnieuw met het kortste algoritme, `d[0]` kan nul zijn, maar zal uiteindelijk naar boven worden afgerond.
    if *div_2pow10(&mut scale.clone(), buf.len()).add(&mant) >= scale {
        // gelijk aan het schalen van `scale` met 10
        k += 1;
    } else {
        mant.mul_small(10);
    }

    // als we werken met de beperking van het laatste cijfer, moeten we de buffer verkorten voordat de daadwerkelijke weergave plaatsvindt om dubbele afronding te voorkomen.
    //
    // merk op dat we de buffer opnieuw moeten vergroten als er naar boven wordt afgerond!
    let mut len = if k < limit {
        // oeps, we kunnen niet eens *één* cijfer produceren.
        // dit is mogelijk wanneer we bijvoorbeeld zoiets als 9.5 hebben en het wordt afgerond op 10.
        // we retourneren een lege buffer, met uitzondering van het latere afrondingsgeval dat optreedt bij `k == limit` en precies één cijfer moet produceren.
        //
        0
    } else if ((k as i32 - limit as i32) as usize) < buf.len() {
        (k - limit) as usize
    } else {
        buf.len()
    };

    if len > 0 {
        // cache `(2, 4, 8) * scale` voor het genereren van cijfers.
        // (Dit kan duur zijn, dus bereken ze niet als de buffer leeg is.)
        let mut scale2 = scale.clone();
        scale2.mul_pow2(1);
        let mut scale4 = scale.clone();
        scale4.mul_pow2(2);
        let mut scale8 = scale.clone();
        scale8.mul_pow2(3);

        for i in 0..len {
            if mant.is_zero() {
                // de volgende cijfers zijn allemaal nullen, we stoppen hier *niet* proberen af te ronden!vul liever de resterende cijfers in.
                //
                for c in &mut buf[i..len] {
                    *c = MaybeUninit::new(b'0');
                }
                // VEILIGHEID: we hebben dat geheugen hierboven geïnitialiseerd.
                return (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, k);
            }

            let mut d = 0;
            if mant >= scale8 {
                mant.sub(&scale8);
                d += 8;
            }
            if mant >= scale4 {
                mant.sub(&scale4);
                d += 4;
            }
            if mant >= scale2 {
                mant.sub(&scale2);
                d += 2;
            }
            if mant >= scale {
                mant.sub(&scale);
                d += 1;
            }
            debug_assert!(mant < scale);
            debug_assert!(d < 10);
            buf[i] = MaybeUninit::new(b'0' + d);
            mant.mul_small(10);
        }
    }

    // naar boven afronden als we stoppen in het midden van cijfers als de volgende cijfers exact 5000 zijn ..., controleer dan het voorgaande cijfer en probeer af te ronden naar even (dwz, vermijd afronding naar boven als het vorige cijfer even is).
    //
    //
    let order = mant.cmp(scale.mul_small(5));
    if order == Ordering::Greater
        || (order == Ordering::Equal
            // VEILIGHEID: `buf[len-1]` is geïnitialiseerd.
            && (len == 0 || unsafe { buf[len - 1].assume_init() } & 1 == 1))
    {
        // als afronding de lengte verandert, moet de exponent ook veranderen.
        // maar er is een vast aantal cijfers gevraagd, dus verander de buffer niet ...
        // VEILIGHEID: we hebben dat geheugen hierboven geïnitialiseerd.
        if let Some(c) = round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..len]) }) {
            // ... tenzij we in plaats daarvan de vaste precisie hebben gevraagd.
            // we moeten ook controleren of, als de originele buffer leeg was, het extra cijfer alleen kan worden toegevoegd als `k == limit` (edge case).
            //
            k += 1;
            if k > limit && len < buf.len() {
                buf[len] = MaybeUninit::new(c);
                len += 1;
            }
        }
    }

    // VEILIGHEID: we hebben dat geheugen hierboven geïnitialiseerd.
    (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, k)
}