//! Rust aanpassing van het Grisu3-algoritme beschreven in "Drijvende-kommagetallen snel en nauwkeurig afdrukken met gehele getallen" [^ 1].
//! Het gebruikt ongeveer 1 KB vooraf berekende tabel en is op zijn beurt erg snel voor de meeste invoer.
//!
//! [^1]: Florian Loitsch.2010. Snel drijvende-kommagetallen afdrukken en
//!   nauwkeurig met gehele getallen.SIGPLAN Niet.45, 6 (juni 2010), 233-243.
//!

use crate::mem::MaybeUninit;
use crate::num::diy_float::Fp;
use crate::num::flt2dec::{round_up, Decoded, MAX_SIG_DIGITS};

// zie de opmerkingen in `format_shortest_opt` voor de grondgedachte.
#[doc(hidden)]
pub const ALPHA: i16 = -60;
#[doc(hidden)]
pub const GAMMA: i16 = -32;

/*
# the following Python code generates this table:
for i in xrange(-308, 333, 8):
    if i >= 0: f = 10**i; e = 0
    else: f = 2**(80-4*i) // 10 **-i;e=4* i, 80
    l = f.bit_length()
    f = ((f << 64 >> (l-1)) + 1) >> 1; e += l - 64
    print '    (%#018x, %5d, %4d),' % (f, e, i)
*/

#[doc(hidden)]
pub static CACHED_POW10: [(u64, i16, i16); 81] = [
    // (f, e, k)
    (0xe61acf033d1a45df, -1087, -308),
    (0xab70fe17c79ac6ca, -1060, -300),
    (0xff77b1fcbebcdc4f, -1034, -292),
    (0xbe5691ef416bd60c, -1007, -284),
    (0x8dd01fad907ffc3c, -980, -276),
    (0xd3515c2831559a83, -954, -268),
    (0x9d71ac8fada6c9b5, -927, -260),
    (0xea9c227723ee8bcb, -901, -252),
    (0xaecc49914078536d, -874, -244),
    (0x823c12795db6ce57, -847, -236),
    (0xc21094364dfb5637, -821, -228),
    (0x9096ea6f3848984f, -794, -220),
    (0xd77485cb25823ac7, -768, -212),
    (0xa086cfcd97bf97f4, -741, -204),
    (0xef340a98172aace5, -715, -196),
    (0xb23867fb2a35b28e, -688, -188),
    (0x84c8d4dfd2c63f3b, -661, -180),
    (0xc5dd44271ad3cdba, -635, -172),
    (0x936b9fcebb25c996, -608, -164),
    (0xdbac6c247d62a584, -582, -156),
    (0xa3ab66580d5fdaf6, -555, -148),
    (0xf3e2f893dec3f126, -529, -140),
    (0xb5b5ada8aaff80b8, -502, -132),
    (0x87625f056c7c4a8b, -475, -124),
    (0xc9bcff6034c13053, -449, -116),
    (0x964e858c91ba2655, -422, -108),
    (0xdff9772470297ebd, -396, -100),
    (0xa6dfbd9fb8e5b88f, -369, -92),
    (0xf8a95fcf88747d94, -343, -84),
    (0xb94470938fa89bcf, -316, -76),
    (0x8a08f0f8bf0f156b, -289, -68),
    (0xcdb02555653131b6, -263, -60),
    (0x993fe2c6d07b7fac, -236, -52),
    (0xe45c10c42a2b3b06, -210, -44),
    (0xaa242499697392d3, -183, -36),
    (0xfd87b5f28300ca0e, -157, -28),
    (0xbce5086492111aeb, -130, -20),
    (0x8cbccc096f5088cc, -103, -12),
    (0xd1b71758e219652c, -77, -4),
    (0x9c40000000000000, -50, 4),
    (0xe8d4a51000000000, -24, 12),
    (0xad78ebc5ac620000, 3, 20),
    (0x813f3978f8940984, 30, 28),
    (0xc097ce7bc90715b3, 56, 36),
    (0x8f7e32ce7bea5c70, 83, 44),
    (0xd5d238a4abe98068, 109, 52),
    (0x9f4f2726179a2245, 136, 60),
    (0xed63a231d4c4fb27, 162, 68),
    (0xb0de65388cc8ada8, 189, 76),
    (0x83c7088e1aab65db, 216, 84),
    (0xc45d1df942711d9a, 242, 92),
    (0x924d692ca61be758, 269, 100),
    (0xda01ee641a708dea, 295, 108),
    (0xa26da3999aef774a, 322, 116),
    (0xf209787bb47d6b85, 348, 124),
    (0xb454e4a179dd1877, 375, 132),
    (0x865b86925b9bc5c2, 402, 140),
    (0xc83553c5c8965d3d, 428, 148),
    (0x952ab45cfa97a0b3, 455, 156),
    (0xde469fbd99a05fe3, 481, 164),
    (0xa59bc234db398c25, 508, 172),
    (0xf6c69a72a3989f5c, 534, 180),
    (0xb7dcbf5354e9bece, 561, 188),
    (0x88fcf317f22241e2, 588, 196),
    (0xcc20ce9bd35c78a5, 614, 204),
    (0x98165af37b2153df, 641, 212),
    (0xe2a0b5dc971f303a, 667, 220),
    (0xa8d9d1535ce3b396, 694, 228),
    (0xfb9b7cd9a4a7443c, 720, 236),
    (0xbb764c4ca7a44410, 747, 244),
    (0x8bab8eefb6409c1a, 774, 252),
    (0xd01fef10a657842c, 800, 260),
    (0x9b10a4e5e9913129, 827, 268),
    (0xe7109bfba19c0c9d, 853, 276),
    (0xac2820d9623bf429, 880, 284),
    (0x80444b5e7aa7cf85, 907, 292),
    (0xbf21e44003acdd2d, 933, 300),
    (0x8e679c2f5e44ff8f, 960, 308),
    (0xd433179d9c8cb841, 986, 316),
    (0x9e19db92b4e31ba9, 1013, 324),
    (0xeb96bf6ebadf77d9, 1039, 332),
];

#[doc(hidden)]
pub const CACHED_POW10_FIRST_E: i16 = -1087;
#[doc(hidden)]
pub const CACHED_POW10_LAST_E: i16 = 1039;

#[doc(hidden)]
pub fn cached_power(alpha: i16, gamma: i16) -> (i16, Fp) {
    let offset = CACHED_POW10_FIRST_E as i32;
    let range = (CACHED_POW10.len() as i32) - 1;
    let domain = (CACHED_POW10_LAST_E - CACHED_POW10_FIRST_E) as i32;
    let idx = ((gamma as i32) - offset) * range / domain;
    let (f, e, k) = CACHED_POW10[idx as usize];
    debug_assert!(alpha <= e && e <= gamma);
    (k, Fp { f, e })
}

/// Gegeven `x > 0`, geeft `(k, 10^k)` terug zodat `10^k <= x < 10^(k+1)`.
#[doc(hidden)]
pub fn max_pow10_no_more_than(x: u32) -> (u8, u32) {
    debug_assert!(x > 0);

    const X9: u32 = 10_0000_0000;
    const X8: u32 = 1_0000_0000;
    const X7: u32 = 1000_0000;
    const X6: u32 = 100_0000;
    const X5: u32 = 10_0000;
    const X4: u32 = 1_0000;
    const X3: u32 = 1000;
    const X2: u32 = 100;
    const X1: u32 = 10;

    if x < X4 {
        if x < X2 {
            if x < X1 { (0, 1) } else { (1, X1) }
        } else {
            if x < X3 { (2, X2) } else { (3, X3) }
        }
    } else {
        if x < X6 {
            if x < X5 { (4, X4) } else { (5, X5) }
        } else if x < X8 {
            if x < X7 { (6, X6) } else { (7, X7) }
        } else {
            if x < X9 { (8, X8) } else { (9, X9) }
        }
    }
}

/// De kortste modusimplementatie voor Grisu.
///
/// Het retourneert `None` als het anders een onnauwkeurige weergave zou retourneren.
pub fn format_shortest_opt<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> Option<(/*digits*/ &'a [u8], /*exp*/ i16)> {
    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());
    assert!(buf.len() >= MAX_SIG_DIGITS);
    assert!(d.mant + d.plus < (1 << 61)); // we hebben ten minste drie bits extra precisie nodig

    // begin met de genormaliseerde waarden met de gedeelde exponent
    let plus = Fp { f: d.mant + d.plus, e: d.exp }.normalize();
    let minus = Fp { f: d.mant - d.minus, e: d.exp }.normalize_to(plus.e);
    let v = Fp { f: d.mant, e: d.exp }.normalize_to(plus.e);

    // vind elke `cached = 10^minusk` zodat `ALPHA <= minusk + plus.e + 64 <= GAMMA`.
    // aangezien `plus` genormaliseerd is, betekent dit `2^(62 + ALPHA) <= plus * cached < 2^(64 + GAMMA)`;
    // gezien onze keuzes van `ALPHA` en `GAMMA`, plaatst dit `plus * cached` in `[4, 2^32)`.
    //
    // het is natuurlijk wenselijk om `GAMMA - ALPHA` te maximaliseren, zodat we niet veel cachemachten van 10 nodig hebben, maar er zijn enkele overwegingen:
    //
    //
    // 1. we willen `floor(plus * cached)` binnen `u32` houden, omdat het een dure opdeling nodig heeft.
    //    (dit is niet echt te vermijden, rest is vereist voor een nauwkeurige schatting.)
    // 2.
    // de rest van `floor(plus * cached)` wordt herhaaldelijk vermenigvuldigd met 10 en mag niet overlopen.
    //
    // de eerste geeft `64 + GAMMA <= 32`, terwijl de tweede `10 * 2^-ALPHA <= 2^64` geeft;
    // -60 en -32 is het maximale bereik met deze beperking, en V8 gebruikt ze ook.
    let (minusk, cached) = cached_power(ALPHA - plus.e - 64, GAMMA - plus.e - 64);

    // schaal fps.dit geeft de maximale fout van 1 ulp (bewezen uit stelling 5.1).
    let plus = plus.mul(&cached);
    let minus = minus.mul(&cached);
    let v = v.mul(&cached);
    debug_assert_eq!(plus.e, minus.e);
    debug_assert_eq!(plus.e, v.e);

    // +-actueel bereik van min
    //   | <---|---------------------- unsafe region --------------------------> |
    //   |     |                                                                 |
    //   |  |<--->|  | <--------------- safe region ---------------> |           |
    //   |  |     |  |                                               |           |
    //   | 1 ulp | 1 ulp || 1 ulp | 1 ulp || 1 ulp | 1 ulp |
    //   |<--->|<--->|                 |<--->|<--->|                 |<--->|<--->|
    //   |-----|-----|-------...-------|-----|-----|-------...-------|-----|-----|
    //   |   minus   |                 |     v     |                 |   plus    | minus1     minus0           v - 1 ulp   v + 1 ulp           plus0       plus1
    //
    //
    // boven `minus`, `v` en `plus` zijn *gekwantiseerde* benaderingen (fout <1 ulp).
    // omdat we niet weten dat de fout positief of negatief is, gebruiken we twee benaderingen die gelijk verdeeld zijn en hebben we de maximale fout van 2 ulps.
    //
    // de "unsafe region" is een liberaal interval dat we in eerste instantie genereren.
    // de "safe region" is een conservatief interval dat we alleen accepteren.
    // we beginnen met de juiste repr binnen de onveilige regio en proberen de reproductie die het dichtst bij `v` ligt te vinden, die ook binnen de veilige regio ligt.
    // als we dat niet kunnen, geven we het op.
    //
    let plus1 = plus.f + 1;
    // laat plus0 = plus.f, 1;//laat alleen voor uitleg minus0 = minus.f + 1;//alleen voor uitleg
    //
    let minus1 = minus.f - 1;
    let e = -plus.e as usize; // gedeelde exponent

    // verdeel `plus1` in integrale en fractionele delen.
    // integrale onderdelen passen gegarandeerd in u32, aangezien cachevermogen `plus < 2^32` garandeert en genormaliseerde `plus.f` altijd minder is dan `2^64 - 2^4` vanwege de precisie-eis.
    //
    let plus1int = (plus1 >> e) as u32;
    let plus1frac = plus1 & ((1 << e) - 1);

    // bereken de grootste `10^max_kappa` niet meer dan `plus1` (dus `plus1 < 10^(max_kappa+1)`).
    // dit is een bovengrens van `kappa` hieronder.
    let (max_kappa, max_ten_kappa) = max_pow10_no_more_than(plus1int);

    let mut i = 0;
    let exp = max_kappa as i16 - minusk + 1;

    // Stelling 6.2: als `k` het grootste gehele getal is st
    // `0 <= y mod 10^k <= y - x`,              dan is `V = floor(y / 10^k) * 10^k` in `[x, y]` en een van de kortste representaties (met het minimale aantal significante cijfers) in dat bereik.
    //
    //
    // vind de cijferlengte `kappa` tussen `(minus1, plus1)` volgens stelling 6.2.
    // Stelling 6.2 kan worden aangenomen om `x` uit te sluiten door in plaats daarvan `y mod 10^k < y - x` te vereisen.
    // (bijv. `x` =32000, `y` =32777; `kappa` =2 sinds 'y mod 10 ^ 3=777 <y, x=777'.) Het algoritme vertrouwt op de latere verificatiefase om `y` uit te sluiten.
    //
    let delta1 = plus1 - minus1;
    // laat delta1int=(delta1>> e) zoals gebruiken;//alleen voor uitleg
    let delta1frac = delta1 & ((1 << e) - 1);

    // render integrale onderdelen, terwijl u de nauwkeurigheid bij elke stap controleert.
    let mut kappa = max_kappa as i16;
    let mut ten_kappa = max_ten_kappa; // 10^kappa
    let mut remainder = plus1int; // cijfers die nog moeten worden weergegeven
    loop {
        // we hebben altijd ten minste één cijfer om weer te geven, als `plus1 >= 10^kappa`-invarianten:
        // - `delta1int <= remainder < 10^(kappa+1)`
        // - `plus1int = d[0..n-1] * 10^(kappa+1) + remainder`   (hieruit volgt dat `remainder = plus1int % 10^(kappa+1)`)
        //
        //

        // deel `remainder` door `10^kappa`.beide zijn geschaald door `2^-e`.
        let q = remainder / ten_kappa;
        let r = remainder % ten_kappa;
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        let plus1rem = ((r as u64) << e) + plus1frac; // ==(plus1% 10 ^ kappa) * 2 ^ e
        if plus1rem < delta1 {
            // `plus1 % 10^kappa < delta1 = plus1 - minus1`; we hebben de juiste `kappa` gevonden.
            let ten_kappa = (ten_kappa as u64) << e; // schaal 10 ^ kappa terug naar de gedeelde exponent
            return round_and_weed(
                // VEILIGHEID: we hebben dat geheugen hierboven geïnitialiseerd.
                unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) },
                exp,
                plus1rem,
                delta1,
                plus1 - v.f,
                ten_kappa,
                1,
            );
        }

        // doorbreek de lus als we alle integrale cijfers hebben weergegeven.
        // het exacte aantal cijfers is `max_kappa + 1` als `plus1 < 10^(max_kappa+1)`.
        if i > max_kappa as usize {
            debug_assert_eq!(ten_kappa, 1);
            debug_assert_eq!(kappa, 0);
            break;
        }

        // herstel invarianten
        kappa -= 1;
        ten_kappa /= 10;
        remainder = r;
    }

    // geef fractionele delen weer, terwijl u de nauwkeurigheid bij elke stap controleert.
    // deze keer vertrouwen we op herhaalde vermenigvuldigingen, omdat deling de precisie verliest.
    let mut remainder = plus1frac;
    let mut threshold = delta1frac;
    let mut ulp = 1;
    loop {
        // het volgende cijfer zou significant moeten zijn, omdat we dat hebben getest voordat we invarianten uitbreken, waarbij `m = max_kappa + 1` (#cijfers in het integrale deel):
        //
        // - `remainder < 2^e`
        // - `plus1frac * 10^(n-m) = d[m..n-1] * 2^e + remainder`

        remainder *= 10; // zal niet overstromen, `2^e * 10 < 2^64`
        threshold *= 10;
        ulp *= 10;

        // deel `remainder` door `10^kappa`.
        // beide worden geschaald door `2^e / 10^kappa`, dus de laatste is hier impliciet.
        let q = remainder >> e;
        let r = remainder & ((1 << e) - 1);
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        if r < threshold {
            let ten_kappa = 1 << e; // impliciete deler
            return round_and_weed(
                // VEILIGHEID: we hebben dat geheugen hierboven geïnitialiseerd.
                unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) },
                exp,
                r,
                threshold,
                (plus1 - v.f) * ulp,
                ten_kappa,
                ulp,
            );
        }

        // herstel invarianten
        kappa -= 1;
        remainder = r;
    }

    // we hebben alle significante cijfers van `plus1` gegenereerd, maar we weten niet zeker of dit de optimale is.
    // Als `minus1` bijvoorbeeld 3.14153 ... is en `plus1` 3.14158 ..., zijn er 5 verschillende kortste representaties van 3.14154 tot 3.14158, maar we hebben alleen de grootste.
    // we moeten achtereenvolgens het laatste cijfer verkleinen en controleren of dit de optimale weergave is.
    // er zijn maximaal 9 kandidaten (..1 t/m ..9), dus dit gaat redelijk snel.("rounding"-fase)
    //
    // de functie controleert of deze "optimal" repr daadwerkelijk binnen het ulp bereik valt, en het is ook mogelijk dat de "second-to-optimal" repr daadwerkelijk optimaal kan zijn vanwege de afrondingsfout.
    // in beide gevallen retourneert dit `None`.
    // ("weeding"-fase)
    //
    // alle argumenten worden hier geschaald met de algemene (maar impliciete) waarde `k`, zodat:
    // - `remainder = (plus1 % 10^kappa) * k`
    // - `threshold = (plus1 - minus1) * k` (en ook `remainder < threshold`)
    // - `plus1v = (plus1 - v) * k` (en ook `threshold > plus1v` van eerdere invarianten)
    // - `ten_kappa = 10^kappa * k`
    // - `ulp = 2^-e * k`
    //
    fn round_and_weed(
        buf: &mut [u8],
        exp: i16,
        remainder: u64,
        threshold: u64,
        plus1v: u64,
        ten_kappa: u64,
        ulp: u64,
    ) -> Option<(&[u8], i16)> {
        assert!(!buf.is_empty());

        // produceren twee benaderingen van `v` (eigenlijk `plus1 - v`) binnen 1.5 ulps.
        // de resulterende weergave moet de weergave zijn die het dichtst bij beide komt.
        //
        // hier wordt `plus1 - v` gebruikt aangezien berekeningen worden gedaan met betrekking tot `plus1` om overflow/underflow te vermijden (vandaar de schijnbaar verwisselde namen).
        //
        let plus1v_down = plus1v + ulp; // plus1 - (v, 1 ulp)
        let plus1v_up = plus1v - ulp; // plus1 - (v + 1 ulp)

        // verlaag het laatste cijfer en stop bij de weergave die het dichtst bij `v + 1 ulp` ligt.
        let mut plus1w = remainder; // plus1w(n) = plus1, w(n)
        {
            let last = buf.last_mut().unwrap();

            // we werken met de geschatte cijfers `w(n)`, die aanvankelijk gelijk is aan `plus1 - plus1 % 10^kappa`.nadat de lus `n` keer is uitgevoerd, `w(n) = plus1 - plus1 % 10^kappa - n * 10^kappa`.
            // we stellen `plus1w(n) = plus1 - w(n) = plus1 % 10^kappa + n * 10^kappa` in (dus `rest= plus1w(0)`) om controles te vereenvoudigen.
            // merk op dat `plus1w(n)` altijd toeneemt.
            //
            // we hebben drie voorwaarden om te beëindigen.elk van hen zal ervoor zorgen dat de lus niet verder kan gaan, maar we hebben dan ten minste één geldige weergave waarvan bekend is dat deze hoe dan ook het dichtst bij `v + 1 ulp` ligt.
            // we zullen ze kortheidshalve aanduiden als TC1 tot en met TC3.
            //
            // TC1: `w(n) <= v + 1 ulp`, dwz dit is de laatste repr die de dichtstbijzijnde is.
            // dit is gelijk aan `plus1 - w(n) = plus1w(n) >= plus1 - (v + 1 ulp) = plus1v_up`.
            // gecombineerd met TC2 (die controleert of `w(n+1)` is valid), dit voorkomt de mogelijke overflow op de berekening van `plus1w(n)`.
            //
            // TC2: `w(n+1) < minus1`, dat wil zeggen, de volgende repr rondt zeker niet af op `v`.
            // dit is gelijk aan `plus1 - w(n) + 10^kappa = plus1w(n) + 10^kappa > plus1 - minus1 = threshold`.
            // de linkerkant kan overstromen, maar we kennen `threshold > plus1v`, dus als TC1 false is, `threshold - plus1w(n) > threshold - (plus1v - 1 ulp) > 1 ulp` en we kunnen veilig testen of `threshold - plus1w(n) < 10^kappa` in plaats daarvan.
            //
            //
            // TC3: `abs(w(n) - (v + 1 ulp)) <= abs(w(n+1) - (v + 1 ulp))`, dwz de volgende repr is
            // niet dichter bij `v + 1 ulp` dan de huidige repr.
            // gegeven `z(n) = plus1v_up - plus1w(n)`, wordt dit `abs(z(n)) <= abs(z(n+1))`.opnieuw aangenomen dat TC1 false is, hebben we `z(n) > 0`.we hebben twee gevallen om te overwegen:
            //
            // - wanneer `z(n+1) >= 0`: TC3 wordt `z(n) <= z(n+1)`.
            // aangezien `plus1w(n)` toeneemt, zou `z(n)` moeten afnemen en dit is duidelijk onjuist.
            // - wanneer `z(n+1) < 0`:
            //   - TC3a: de voorwaarde is `plus1v_up < plus1w(n) + 10^kappa`.ervan uitgaande dat TC2 onwaar is, `threshold >= plus1w(n) + 10^kappa` zodat het niet kan overstromen.
            //   - TC3b: TC3 wordt `z(n) <= -z(n+1)`, dwz `plus1v_up - plus1w(n) >=     plus1w(n+1) - plus1v_up = plus1w(n) + 10^kappa - plus1v_up`.
            //   de genegeerde TC1 geeft `plus1v_up > plus1w(n)`, dus het kan niet overlopen of onderlopen in combinatie met TC3a.
            //
            // daarom moeten we stoppen wanneer `TC1 || TC2 || (TC3a && TC3b)`.het volgende is gelijk aan het omgekeerde, `!TC1 && !TC2 && (!TC3a || !TC3b)`.
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            while plus1w < plus1v_up
                && threshold - plus1w >= ten_kappa
                && (plus1w + ten_kappa < plus1v_up
                    || plus1v_up - plus1w >= plus1w + ten_kappa - plus1v_up)
            {
                *last -= 1;
                debug_assert!(*last > b'0'); // de kortste repr kan niet eindigen op `0`
                plus1w += ten_kappa;
            }
        }

        // controleer of deze weergave ook de weergave is die het dichtst bij `v - 1 ulp` ligt.
        //
        // dit is gewoon hetzelfde als de afsluitvoorwaarden voor `v + 1 ulp`, waarbij alle `plus1v_up` in plaats daarvan is vervangen door `plus1v_down`.
        // overloopanalyse geldt evenzeer.
        if plus1w < plus1v_down
            && threshold - plus1w >= ten_kappa
            && (plus1w + ten_kappa < plus1v_down
                || plus1v_down - plus1w >= plus1w + ten_kappa - plus1v_down)
        {
            return None;
        }

        // nu hebben we de weergave die het dichtst bij `v` ligt tussen `plus1` en `minus1`.
        // dit is echter te liberaal, dus we verwerpen elke `w(n)` die niet tussen `plus0` en `minus0` zit, dwz `plus1 - plus1w(n) <= minus0` of `plus1 - plus1w(n) >= plus0`.
        // we gebruiken de feiten dat `threshold = plus1 - minus1` en `plus1 - plus0 = minus0 - minus1 = 2 ulp`.
        //
        if 2 * ulp <= plus1w && plus1w <= threshold - 4 * ulp { Some((buf, exp)) } else { None }
    }
}

/// De kortste modusimplementatie voor Grisu met Dragon fallback.
///
/// Dit moet in de meeste gevallen worden gebruikt.
pub fn format_shortest<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    use crate::num::flt2dec::strategy::dragon::format_shortest as fallback;
    // VEILIGHEID: De leningscontrole is niet slim genoeg om ons `buf` te laten gebruiken
    // in de tweede branch, dus we wassen hier het leven.
    // Maar we hergebruiken `buf` alleen als `format_shortest_opt` `None` retourneerde, dus dit is oké.
    match format_shortest_opt(d, unsafe { &mut *(buf as *mut _) }) {
        Some(ret) => ret,
        None => fallback(d, buf),
    }
}

/// De exacte en vaste modusimplementatie voor Grisu.
///
/// Het retourneert `None` als het anders een onnauwkeurige weergave zou retourneren.
pub fn format_exact_opt<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> Option<(/*digits*/ &'a [u8], /*exp*/ i16)> {
    assert!(d.mant > 0);
    assert!(d.mant < (1 << 61)); // we hebben ten minste drie bits extra precisie nodig
    assert!(!buf.is_empty());

    // normaliseer en schaal `v`.
    let v = Fp { f: d.mant, e: d.exp }.normalize();
    let (minusk, cached) = cached_power(ALPHA - v.e - 64, GAMMA - v.e - 64);
    let v = v.mul(&cached);

    // verdeel `v` in integrale en fractionele delen.
    let e = -v.e as usize;
    let vint = (v.f >> e) as u32;
    let vfrac = v.f & ((1 << e) - 1);

    // zowel de oude `v` als de nieuwe `v` (geschaald door `10^-k`) heeft een fout <1 ulp (Stelling 5.1).
    // aangezien we niet weten dat de fout positief of negatief is, gebruiken we twee benaderingen die gelijk verdeeld zijn en hebben we de maximale fout van 2 ulps (hetzelfde voor het kortste geval).
    //
    //
    // het doel is om de exact afgeronde cijferreeks te vinden die zowel `v - 1 ulp` als `v + 1 ulp` gemeen hebben, zodat we maximaal vertrouwen hebben.
    // als dit niet mogelijk is, weten we niet welke de juiste uitvoer is voor `v`, dus geven we het op en vallen terug.
    //
    // `err` wordt hier gedefinieerd als `1 ulp * 2^e` (hetzelfde als de ulp in `vfrac`), en we zullen het schalen wanneer `v` wordt geschaald.
    //
    //
    //
    let mut err = 1;

    // bereken de grootste `10^max_kappa` niet meer dan `v` (dus `v < 10^(max_kappa+1)`).
    // dit is een bovengrens van `kappa` hieronder.
    let (max_kappa, max_ten_kappa) = max_pow10_no_more_than(vint);

    let mut i = 0;
    let exp = max_kappa as i16 - minusk + 1;

    // als we werken met de beperking van het laatste cijfer, moeten we de buffer verkorten voordat de daadwerkelijke weergave plaatsvindt om dubbele afronding te voorkomen.
    //
    // merk op dat we de buffer opnieuw moeten vergroten als er naar boven wordt afgerond!
    let len = if exp <= limit {
        // oeps, we kunnen niet eens *één* cijfer produceren.
        // dit is mogelijk wanneer we bijvoorbeeld zoiets als 9.5 hebben en het wordt afgerond op 10.
        //
        // in principe kunnen we `possibly_round` meteen aanroepen met een lege buffer, maar het schalen van `max_ten_kappa << e` met 10 kan leiden tot overflow.
        //
        // dus we zijn hier slordig en vergroten het foutenbereik met een factor 10.
        // dit zal het percentage vals-negatieve reacties verhogen, maar slechts heel,*heel* licht;
        // het kan alleen merkbaar uitmaken als de mantisse groter is dan 60 bits.
        //
        // VEILIGHEID: `len=0`, dus de verplichting om dit geheugen te hebben geïnitialiseerd, is triviaal.
        return unsafe {
            possibly_round(buf, 0, exp, limit, v.f / 10, (max_ten_kappa as u64) << e, err << e)
        };
    } else if ((exp as i32 - limit as i32) as usize) < buf.len() {
        (exp - limit) as usize
    } else {
        buf.len()
    };
    debug_assert!(len > 0);

    // maak integrale onderdelen.
    // de fout is volledig fractioneel, dus we hoeven het in dit deel niet te controleren.
    let mut kappa = max_kappa as i16;
    let mut ten_kappa = max_ten_kappa; // 10^kappa
    let mut remainder = vint; // cijfers die nog moeten worden weergegeven
    loop {
        // we hebben altijd minstens één cijfer om invarianten weer te geven:
        // - `remainder < 10^(kappa+1)`
        // - `vint = d[0..n-1] * 10^(kappa+1) + remainder`   (hieruit volgt dat `remainder = vint % 10^(kappa+1)`)
        //
        //

        // deel `remainder` door `10^kappa`.beide zijn geschaald door `2^-e`.
        let q = remainder / ten_kappa;
        let r = remainder % ten_kappa;
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        // is de buffer vol?voer de afrondingspas uit met de rest.
        if i == len {
            let vrem = ((r as u64) << e) + vfrac; // ==(v% 10 ^ kappa) * 2 ^ e
            // VEILIGHEID: we hebben `len` vele bytes geïnitialiseerd.
            return unsafe {
                possibly_round(buf, len, exp, limit, vrem, (ten_kappa as u64) << e, err << e)
            };
        }

        // doorbreek de lus als we alle integrale cijfers hebben weergegeven.
        // het exacte aantal cijfers is `max_kappa + 1` als `plus1 < 10^(max_kappa+1)`.
        if i > max_kappa as usize {
            debug_assert_eq!(ten_kappa, 1);
            debug_assert_eq!(kappa, 0);
            break;
        }

        // herstel invarianten
        kappa -= 1;
        ten_kappa /= 10;
        remainder = r;
    }

    // maak fractionele delen.
    //
    // in principe kunnen we doorgaan tot het laatst beschikbare cijfer en controleren op de juistheid.
    // helaas werken we met de eindige gehele getallen, dus we hebben een criterium nodig om de overflow te detecteren.
    // V8 gebruikt `remainder > err`, wat onwaar wordt wanneer de eerste significante `i`-cijfers van `v - 1 ulp` en `v` verschillen.
    // dit wijst echter te veel anderszins geldige invoer af.
    //
    // aangezien de latere fase een correcte overloopdetectie heeft, gebruiken we in plaats daarvan een strakker criterium:
    // we gaan door tot `err` groter is dan `10^kappa / 2`, zodat het bereik tussen `v - 1 ulp` en `v + 1 ulp` zeker twee of meer afgeronde representaties bevat.
    //
    // dit is hetzelfde als de eerste twee vergelijkingen van `possibly_round`, ter referentie.
    //
    let mut remainder = vfrac;
    let maxerr = 1 << (e - 1);
    while err < maxerr {
        // invarianten, waarbij `m = max_kappa + 1` (aantal cijfers in het integrale deel):
        // - `remainder < 2^e`
        // - `vfrac * 10^(n-m) = d[m..n-1] * 2^e + remainder`
        // - `err = 10^(n-m)`

        remainder *= 10; // zal niet overstromen, `2^e * 10 < 2^64`
        err *= 10; // zal niet overstromen, `err * 10 < 2^e * 5 < 2^64`

        // deel `remainder` door `10^kappa`.
        // beide worden geschaald door `2^e / 10^kappa`, dus de laatste is hier impliciet.
        let q = remainder >> e;
        let r = remainder & ((1 << e) - 1);
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        // is de buffer vol?voer de afrondingspas uit met de rest.
        if i == len {
            // VEILIGHEID: we hebben `len` vele bytes geïnitialiseerd.
            return unsafe { possibly_round(buf, len, exp, limit, r, 1 << e, err) };
        }

        // herstel invarianten
        remainder = r;
    }

    // verdere berekening is nutteloos (`possibly_round` mislukt absoluut), dus we geven het op.
    return None;

    // we hebben alle gevraagde cijfers van `v` gegenereerd, die ook hetzelfde zouden moeten zijn als de corresponderende cijfers van `v - 1 ulp`.
    // nu kijken we of er een unieke representatie is die wordt gedeeld door zowel `v - 1 ulp` als `v + 1 ulp`;dit kan hetzelfde zijn voor gegenereerde cijfers of voor de afgeronde versie van die cijfers.
    //
    // als het bereik meerdere representaties van dezelfde lengte bevat, weten we het niet zeker en moeten we in plaats daarvan `None` retourneren.
    //
    // alle argumenten worden hier geschaald met de algemene (maar impliciete) waarde `k`, zodat:
    // - `remainder = (v % 10^kappa) * k`
    // - `ten_kappa = 10^kappa * k`
    // - `ulp = 2^-e * k`
    //
    // VEILIGHEID: de eerste `len` bytes van `buf` moeten worden geïnitialiseerd.
    //
    unsafe fn possibly_round(
        buf: &mut [MaybeUninit<u8>],
        mut len: usize,
        mut exp: i16,
        limit: i16,
        remainder: u64,
        ten_kappa: u64,
        ulp: u64,
    ) -> Option<(&[u8], i16)> {
        debug_assert!(remainder < ten_kappa);

        // 10^kappa
        //    :   :   :<->:   :
        //    :   :   :   :   :
        //    : | 1 ulp | 1 ulp |:
        //    :|<--->|<--->|  :
        // ----|-----|-----|----
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // (ter referentie geeft de stippellijn de exacte waarde aan voor mogelijke weergaven in een bepaald aantal cijfers.)
        //
        //
        // fout is te groot dat er ten minste drie mogelijke weergaven zijn tussen `v - 1 ulp` en `v + 1 ulp`.
        // we kunnen niet bepalen welke de juiste is.
        //
        if ulp >= ten_kappa {
            return None;
        }

        // 10^kappa
        //   :<------->:
        //   :         :
        //   : | 1 ulp | 1 ulp |
        //   : |<--->|<--->|
        // ----|-----|-----|----
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // in feite is 1/2 ulp voldoende om twee mogelijke representaties te introduceren.
        // (onthoud dat we een unieke representatie nodig hebben voor zowel `v - 1 ulp` als `v + 1 ulp`.) dit zal niet overlopen, zoals `ulp < ten_kappa` vanaf de eerste controle.
        //
        //
        if ten_kappa - ulp <= ulp {
            return None;
        }

        // remainder
        //       :<->|                           :
        //       :   |                           :
        //       : <---------10 ^ kappa-- -------->:
        //     | :   |                           :
        //     | 1 ulp | 1 ulp |:
        //     |<--->|<--->|                     :
        // ----|-----|-----|------------------------
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // als `v + 1 ulp` dichter bij de naar beneden afgeronde weergave ligt (die al in `buf` staat), dan kunnen we veilig terugkeren.
        // merk op dat `v - 1 ulp` * kleiner kan zijn dan de huidige weergave, maar als `1 ulp < 10^kappa / 2` is deze voorwaarde voldoende:
        // de afstand tussen `v - 1 ulp` en de huidige weergave mag niet groter zijn dan `10^kappa / 2`.
        //
        // de voorwaarde is gelijk aan `remainder + ulp < 10^kappa / 2`.
        // aangezien dit gemakkelijk kan overlopen, moet u eerst controleren of `remainder < 10^kappa / 2`.
        // we hebben die `ulp < 10^kappa / 2` al geverifieerd, dus zolang `10^kappa` toch niet overstroomde, is de tweede controle prima.
        //
        //
        //
        //
        if ten_kappa - remainder > remainder && ten_kappa - 2 * remainder >= 2 * ulp {
            // VEILIGHEID: onze beller heeft dat geheugen geïnitialiseerd.
            return Some((unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, exp));
        }

        // : <-------rest------> |:
        //   :                          |   :
        //   : <---------10 ^ kappa-- ------->:
        //   :                    |     |   : |
        //   : | 1 ulp | 1 ulp |
        //   :                    |<--->|<--->|
        // -----------------------|-----|-----|-----
        //                        |     v     |                    v - 1 ulp   v + 1 ulp
        //
        // aan de andere kant, als `v - 1 ulp` dichter bij de afgeronde weergave ligt, moeten we naar boven afronden en terugkeren.
        // om dezelfde reden hoeven we `v + 1 ulp` niet te controleren.
        //
        // de voorwaarde is gelijk aan `remainder - ulp >= 10^kappa / 2`.
        // nogmaals controleren we eerst of `remainder > ulp` (merk op dat dit niet `remainder >= ulp` is, aangezien `10^kappa` nooit nul is).
        //
        // merk ook op dat `remainder - ulp <= 10^kappa`, dus de tweede controle niet overloopt.
        //
        if remainder > ulp && ten_kappa - (remainder - ulp) <= remainder - ulp {
            if let Some(c) =
                // VEILIGHEID: onze beller moet dat geheugen hebben geïnitialiseerd.
                round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..len]) })
            {
                // voeg alleen een extra cijfer toe als ons om de vaste precisie is gevraagd.
                // we moeten ook controleren of, als de originele buffer leeg was, het extra cijfer alleen kan worden toegevoegd als `exp == limit` (edge case).
                //
                exp += 1;
                if exp > limit && len < buf.len() {
                    buf[len] = MaybeUninit::new(c);
                    len += 1;
                }
            }
            // VEILIGHEID: wij en onze beller hebben dat geheugen geïnitialiseerd.
            return Some((unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, exp));
        }

        // anders zijn we gedoemd (dwz sommige waarden tussen `v - 1 ulp` en `v + 1 ulp` worden naar beneden afgerond en andere naar boven afgerond) en geven op.
        //
        None
    }
}

/// De exacte en vaste modusimplementatie voor Grisu met Dragon fallback.
///
/// Dit moet in de meeste gevallen worden gebruikt.
pub fn format_exact<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    use crate::num::flt2dec::strategy::dragon::format_exact as fallback;
    // VEILIGHEID: De leningscontrole is niet slim genoeg om ons `buf` te laten gebruiken
    // in de tweede branch, dus we wassen hier het leven.
    // Maar we hergebruiken `buf` alleen als `format_exact_opt` `None` retourneerde, dus dit is oké.
    match format_exact_opt(d, unsafe { &mut *(buf as *mut _) }, limit) {
        Some(ret) => ret,
        None => fallback(d, buf, limit),
    }
}