//! Fouttypen voor conversie naar integrale typen.

use crate::convert::Infallible;
use crate::fmt;

/// Het fouttype dat wordt geretourneerd wanneer een gecontroleerde conversie van het integrale type mislukt.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Debug, Copy, Clone, PartialEq, Eq)]
pub struct TryFromIntError(pub(crate) ());

impl TryFromIntError {
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        "out of range integral type conversion attempted"
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for TryFromIntError {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(fmt)
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl From<Infallible> for TryFromIntError {
    fn from(x: Infallible) -> TryFromIntError {
        match x {}
    }
}

#[unstable(feature = "never_type", issue = "35121")]
impl From<!> for TryFromIntError {
    fn from(never: !) -> TryFromIntError {
        // Match in plaats van te dwingen om ervoor te zorgen dat code zoals `From<Infallible> for TryFromIntError` hierboven blijft werken wanneer `Infallible` een alias voor `!` wordt.
        //
        //
        match never {}
    }
}

/// Een fout die kan worden geretourneerd bij het ontleden van een geheel getal.
///
/// Deze fout wordt gebruikt als het fouttype voor de `from_str_radix()`-functies op de primitieve integer-typen, zoals [`i8::from_str_radix`].
///
/// # Mogelijke oorzaken
///
/// Onder andere oorzaken kan `ParseIntError` worden gegooid vanwege voorloop-of volgspaties in de tekenreeks, bijvoorbeeld wanneer het wordt verkregen uit de standaardinvoer.
///
/// Door de [`str::trim()`]-methode te gebruiken, zorgt u ervoor dat er geen witruimte overblijft vóór het parseren.
///
/// # Example
///
/// ```
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {}", e);
/// }
/// ```
///
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseIntError {
    pub(super) kind: IntErrorKind,
}

/// Enum om de verschillende soorten fouten op te slaan die ertoe kunnen leiden dat het parseren van een geheel getal mislukt.
///
/// # Example
///
/// ```
/// #![feature(int_error_matching)]
///
/// # fn main() {
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {:?}", e.kind());
/// }
/// # }
/// ```
#[unstable(
    feature = "int_error_matching",
    reason = "it can be useful to match errors when making error messages \
              for integer parsing",
    issue = "22639"
)]
#[derive(Debug, Clone, PartialEq, Eq)]
#[non_exhaustive]
pub enum IntErrorKind {
    /// Waarde die wordt geparseerd, is leeg.
    ///
    /// Deze variant wordt onder meer geconstrueerd bij het ontleden van een lege string.
    Empty,
    /// Bevat een ongeldig cijfer in zijn context.
    ///
    /// Deze variant wordt onder andere geconstrueerd bij het ontleden van een string die een niet-ASCII-teken bevat.
    ///
    /// Deze variant wordt ook geconstrueerd wanneer een `+` of `-` misplaatst is binnen een string, hetzij op zichzelf, hetzij in het midden van een nummer.
    ///
    ///
    InvalidDigit,
    /// Geheel getal is te groot om op te slaan in het beoogde integer-type.
    PosOverflow,
    /// Geheel getal is te klein om op te slaan in het beoogde integer-type.
    NegOverflow,
    /// Waarde was nul
    ///
    /// Deze variant wordt verzonden als de ontledingsreeks de waarde nul heeft, wat niet is toegestaan voor typen die niet nul zijn.
    ///
    Zero,
}

impl ParseIntError {
    /// Geeft de gedetailleerde oorzaak weer van het mislukken van het parseren van een geheel getal.
    #[unstable(
        feature = "int_error_matching",
        reason = "it can be useful to match errors when making error messages \
              for integer parsing",
        issue = "22639"
    )]
    pub fn kind(&self) -> &IntErrorKind {
        &self.kind
    }
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            IntErrorKind::Empty => "cannot parse integer from empty string",
            IntErrorKind::InvalidDigit => "invalid digit found in string",
            IntErrorKind::PosOverflow => "number too large to fit in target type",
            IntErrorKind::NegOverflow => "number too small to fit in target type",
            IntErrorKind::Zero => "number would be zero for non-zero type",
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseIntError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}