//! Beetje gehannes op positieve IEEE 754-drijvers.Negatieve getallen zijn niet en hoeven niet te worden verwerkt.
//! Normale drijvende-kommagetallen hebben een canonieke weergave als (frac, exp), zodat de waarde 2 <sup>exp</sup> * is (1 + sum(frac[N-i] / 2<sup>i</sup>)) waarbij N het aantal bits is.
//!
//! Subnormalen zijn iets anders en raar, maar hetzelfde principe is van toepassing.
//!
//! Hier stellen we ze echter voor als (sig, k) met f positief, zodat de waarde f *
//! 2 <sup>e</sup> .Naast het expliciet maken van de "hidden bit", verandert dit de exponent door de zogenaamde mantisse-verschuiving.
//!
//! Anders gezegd, normaal gesproken worden drijvers geschreven als (1), maar hier worden ze geschreven als (2):
//!
//! 1. `1.101100...11 * 2^m`
//! 2. `1101100...11 * 2^n`
//!
//! We noemen (1) de **fractionele representatie** en (2) de **integrale representatie**.
//!
//! Veel functies in deze module werken alleen met normale getallen.De dec2flt-routines nemen conservatief het universeel correcte langzame pad (algoritme M) voor zeer kleine en zeer grote aantallen.
//! Dat algoritme heeft alleen next_float() nodig die subnormalen en nullen verwerkt.
//!
//!
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::convert::{TryFrom, TryInto};
use crate::fmt::{Debug, LowerExp};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;
use crate::num::FpCategory;
use crate::num::FpCategory::{Infinite, Nan, Normal, Subnormal, Zero};
use crate::ops::{Add, Div, Mul, Neg};

#[derive(Copy, Clone, Debug)]
pub struct Unpacked {
    pub sig: u64,
    pub k: i16,
}

impl Unpacked {
    pub fn new(sig: u64, k: i16) -> Self {
        Unpacked { sig, k }
    }
}

/// Een helper trait om te voorkomen dat in principe alle conversiecode voor `f32` en `f64` wordt gedupliceerd.
///
/// Zie de doc-opmerking van de bovenliggende module om te zien waarom dit nodig is.
///
/// Moet **nooit** worden geïmplementeerd voor andere typen of buiten de dec2flt-module worden gebruikt.
pub trait RawFloat:
    Copy + Debug + LowerExp + Mul<Output = Self> + Div<Output = Self> + Neg<Output = Self>
{
    const INFINITY: Self;
    const NAN: Self;
    const ZERO: Self;

    /// Type gebruikt door `to_bits` en `from_bits`.
    type Bits: Add<Output = Self::Bits> + From<u8> + TryFrom<u64>;

    /// Voert een ruwe transmutatie uit naar een geheel getal.
    fn to_bits(self) -> Self::Bits;

    /// Voert een ruwe transmutatie uit vanaf een geheel getal.
    fn from_bits(v: Self::Bits) -> Self;

    /// Retourneert de categorie waarin dit getal valt.
    fn classify(self) -> FpCategory;

    /// Retourneert de mantisse, exponent en teken als gehele getallen.
    fn integer_decode(self) -> (u64, i16, i8);

    /// Decodeert de vlotter.
    fn unpack(self) -> Unpacked;

    /// Gegoten vanaf een klein geheel getal dat exact kan worden weergegeven.
    /// Panic als het gehele getal niet kan worden weergegeven, zorgt de andere code in deze module ervoor dat dat nooit gebeurt.
    fn from_int(x: u64) -> Self;

    /// Haalt de waarde 10 <sup>e</sup> uit een vooraf berekende tabel.
    /// Panics voor `e >= CEIL_LOG5_OF_MAX_SIG`.
    fn short_fast_pow10(e: usize) -> Self;

    /// Wat de naam zegt.
    /// Het is gemakkelijker om hard te coderen dan te jongleren met intrinsieke elementen en te hopen dat LLVM het constant opvouwt.
    const CEIL_LOG5_OF_MAX_SIG: i16;

    // Een conservatieve grens voor de decimale cijfers van invoer die geen overloop of nul of kan produceren
    /// subnormalen.Waarschijnlijk de decimale exponent van de maximale normale waarde, vandaar de naam.
    const MAX_NORMAL_DIGITS: usize;

    /// Als het meest significante decimale cijfer een grotere plaatswaarde heeft, wordt het getal zeker afgerond op oneindig.
    ///
    const INF_CUTOFF: i64;

    /// Als het meest significante decimale cijfer een plaatswaarde heeft die kleiner is dan deze waarde, wordt het getal zeker afgerond op nul.
    ///
    const ZERO_CUTOFF: i64;

    /// Het aantal bits in de exponent.
    const EXP_BITS: u8;

    /// Het aantal bits in de significant,*inclusief* het verborgen bit.
    const SIG_BITS: u8;

    /// Het aantal bits in de significantie,*exclusief* het verborgen bit.
    const EXPLICIT_SIG_BITS: u8;

    /// De maximale juridische exponent in fractionele weergave.
    const MAX_EXP: i16;

    /// De minimale wettelijke exponent in fractionele weergave, met uitzondering van subnormalen.
    const MIN_EXP: i16;

    /// `MAX_EXP` voor integrale representatie, dwz met de toegepaste verschuiving.
    const MAX_EXP_INT: i16;

    /// `MAX_EXP` gecodeerd (dwz met offset bias)
    const MAX_ENCODED_EXP: i16;

    /// `MIN_EXP` voor integrale representatie, dwz met de toegepaste verschuiving.
    const MIN_EXP_INT: i16;

    /// De maximale genormaliseerde significantie in integrale representatie.
    const MAX_SIG: u64;

    /// De minimaal genormaliseerde significantie in integrale representatie.
    const MIN_SIG: u64;
}

// Meestal een oplossing voor #34344.
macro_rules! other_constants {
    ($type: ident) => {
        const EXPLICIT_SIG_BITS: u8 = Self::SIG_BITS - 1;
        const MAX_EXP: i16 = (1 << (Self::EXP_BITS - 1)) - 1;
        const MIN_EXP: i16 = -<Self as RawFloat>::MAX_EXP + 1;
        const MAX_EXP_INT: i16 = <Self as RawFloat>::MAX_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_ENCODED_EXP: i16 = (1 << Self::EXP_BITS) - 1;
        const MIN_EXP_INT: i16 = <Self as RawFloat>::MIN_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_SIG: u64 = (1 << Self::SIG_BITS) - 1;
        const MIN_SIG: u64 = 1 << (Self::SIG_BITS - 1);

        const INFINITY: Self = $type::INFINITY;
        const NAN: Self = $type::NAN;
        const ZERO: Self = 0.0;
    };
}

impl RawFloat for f32 {
    type Bits = u32;

    const SIG_BITS: u8 = 24;
    const EXP_BITS: u8 = 8;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 11;
    const MAX_NORMAL_DIGITS: usize = 35;
    const INF_CUTOFF: i64 = 40;
    const ZERO_CUTOFF: i64 = -48;
    other_constants!(f32);

    /// Retourneert de mantisse, exponent en teken als gehele getallen.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 31 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 23) & 0xff) as i16;
        let mantissa =
            if exponent == 0 { (bits & 0x7fffff) << 1 } else { (bits & 0x7fffff) | 0x800000 };
        // Exponent bias + mantisse verschuiving
        exponent -= 127 + 23;
        (mantissa as u64, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f32 {
        // rkruppe is onzeker of `as` correct rondt op alle platforms.
        debug_assert!(x as f32 == fp_to_float(Fp { f: x, e: 0 }));
        x as f32
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F32_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

impl RawFloat for f64 {
    type Bits = u64;

    const SIG_BITS: u8 = 53;
    const EXP_BITS: u8 = 11;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 23;
    const MAX_NORMAL_DIGITS: usize = 305;
    const INF_CUTOFF: i64 = 310;
    const ZERO_CUTOFF: i64 = -326;
    other_constants!(f64);

    /// Retourneert de mantisse, exponent en teken als gehele getallen.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 63 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 52) & 0x7ff) as i16;
        let mantissa = if exponent == 0 {
            (bits & 0xfffffffffffff) << 1
        } else {
            (bits & 0xfffffffffffff) | 0x10000000000000
        };
        // Exponent bias + mantisse verschuiving
        exponent -= 1023 + 52;
        (mantissa, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f64 {
        // rkruppe is onzeker of `as` correct rondt op alle platforms.
        debug_assert!(x as f64 == fp_to_float(Fp { f: x, e: 0 }));
        x as f64
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F64_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

/// Converteert een `Fp` naar het dichtstbijzijnde zweeftype van de machine.
/// Behandelt geen subnormale resultaten.
pub fn fp_to_float<T: RawFloat>(x: Fp) -> T {
    let x = x.normalize();
    // x.f is 64 bit, dus xe heeft een mantisse-verschuiving van 63
    let e = x.e + 63;
    if e > T::MAX_EXP {
        panic!("fp_to_float: exponent {} too large", e)
    } else if e > T::MIN_EXP {
        encode_normal(round_normal::<T>(x))
    } else {
        panic!("fp_to_float: exponent {} too small", e)
    }
}

/// Rond de 64-bits significantie af naar T::SIG_BITS-bits met half tot even.
/// Kan geen exponentoverloop aan.
pub fn round_normal<T: RawFloat>(x: Fp) -> Unpacked {
    let excess = 64 - T::SIG_BITS as i16;
    let half: u64 = 1 << (excess - 1);
    let (q, rem) = (x.f >> excess, x.f & ((1 << excess) - 1));
    assert_eq!(q << excess | rem, x.f);
    // Pas de mantisse-verschuiving aan
    let k = x.e + excess;
    if rem < half {
        Unpacked::new(q, k)
    } else if rem == half && (q % 2) == 0 {
        Unpacked::new(q, k)
    } else if q == T::MAX_SIG {
        Unpacked::new(T::MIN_SIG, k + 1)
    } else {
        Unpacked::new(q + 1, k)
    }
}

/// Inverse van `RawFloat::unpack()` voor genormaliseerde getallen.
/// Panics als de significantie of exponent niet geldig zijn voor genormaliseerde getallen.
pub fn encode_normal<T: RawFloat>(x: Unpacked) -> T {
    debug_assert!(
        T::MIN_SIG <= x.sig && x.sig <= T::MAX_SIG,
        "encode_normal: significand not normalized"
    );
    // Verwijder het verborgen bit
    let sig_enc = x.sig & !(1 << T::EXPLICIT_SIG_BITS);
    // Pas de exponent aan voor exponentbias en mantisseverschuiving
    let k_enc = x.k + T::MAX_EXP + T::EXPLICIT_SIG_BITS as i16;
    debug_assert!(k_enc != 0 && k_enc < T::MAX_ENCODED_EXP, "encode_normal: exponent out of range");
    // Laat het tekenbit op 0 ("+") staan, onze cijfers zijn allemaal positief
    let bits = (k_enc as u64) << T::EXPLICIT_SIG_BITS | sig_enc;
    T::from_bits(bits.try_into().unwrap_or_else(|_| unreachable!()))
}

/// Construeer een subnormaal.Een mantisse van 0 is toegestaan en construeert nul.
pub fn encode_subnormal<T: RawFloat>(significand: u64) -> T {
    assert!(significand < T::MIN_SIG, "encode_subnormal: not actually subnormal");
    // De gecodeerde exponent is 0, het tekenbit is 0, dus we hoeven alleen de bits opnieuw te interpreteren.
    T::from_bits(significand.try_into().unwrap_or_else(|_| unreachable!()))
}

/// Benader een bignum met een Fp.Rondt af binnen 0.5 ULP met half tot even.
pub fn big_to_fp(f: &Big) -> Fp {
    let end = f.bit_length();
    assert!(end != 0, "big_to_fp: unexpectedly, input is zero");
    let start = end.saturating_sub(64);
    let leading = num::get_bits(f, start, end);
    // We snijden alle bits af voorafgaand aan de index `start`, dwz we verschuiven effectief naar rechts met een hoeveelheid `start`, dus dit is ook de exponent die we nodig hebben.
    //
    let e = start as i16;
    let rounded_down = Fp { f: leading, e }.normalize();
    // Rond (half-to-even) afhankelijk van de afgekapte bits.
    match num::compare_with_half_ulp(f, start) {
        Less => rounded_down,
        Equal if leading % 2 == 0 => rounded_down,
        Equal | Greater => match leading.checked_add(1) {
            Some(f) => Fp { f, e }.normalize(),
            None => Fp { f: 1 << 63, e: e + 1 },
        },
    }
}

/// Vindt het grootste drijvende-kommagetal dat strikt kleiner is dan het argument.
/// Behandelt geen subnormalen, nul of exponent-underflow.
pub fn prev_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Infinite => panic!("prev_float: argument is infinite"),
        Nan => panic!("prev_float: argument is NaN"),
        Subnormal => panic!("prev_float: argument is subnormal"),
        Zero => panic!("prev_float: argument is zero"),
        Normal => {
            let Unpacked { sig, k } = x.unpack();
            if sig == T::MIN_SIG {
                encode_normal(Unpacked::new(T::MAX_SIG, k - 1))
            } else {
                encode_normal(Unpacked::new(sig - 1, k))
            }
        }
    }
}

// Zoek het kleinste drijvende-kommagetal dat strikt groter is dan het argument.
// Deze bewerking is verzadigend, dwz next_float(inf) ==inf.
// In tegenstelling tot de meeste code in deze module, verwerkt deze functie nul, subnormalen en oneindigheden.
// Echter, net als alle andere code hier, heeft het geen betrekking op NaN en negatieve getallen.
pub fn next_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Nan => panic!("next_float: argument is NaN"),
        Infinite => T::INFINITY,
        // Dit lijkt te mooi om waar te zijn, maar het werkt.
        // 0.0 wordt gecodeerd als het woord dat geheel nul is.Subnormalen zijn 0x000m ... m waarbij m de mantisse is.
        // In het bijzonder is de kleinste subnormale 0x0 ... 01 en de grootste 0x000F ... F.
        // Het kleinste normale nummer is 0x0010 ... 0, dus deze hoekbehuizing werkt ook.
        // Als het increment de mantisse overschrijdt, verhoogt het carry-bit de exponent zoals we willen, en worden de mantisse-bits nul.
        // Vanwege de verborgen bitconventie is dit ook precies wat we willen!
        // Ten slotte f64::MAX + 1=7eff ... f + 1=7ff0 ... 0= f64::INFINITY.
        //
        Zero | Subnormal | Normal => T::from_bits(x.to_bits() + T::Bits::from(1u8)),
    }
}