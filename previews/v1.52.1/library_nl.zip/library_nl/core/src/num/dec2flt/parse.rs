//! Een decimale reeks van het formulier valideren en ontleden:
//!
//! `(digits | digits? '.'? digits?) (('e' | 'E') ('+' | '-')? digits)?`
//!
//! Met andere woorden, standaard syntaxis met drijvende komma, met twee uitzonderingen: geen teken en geen verwerking van "inf" en "NaN".Deze worden afgehandeld door de stuurprogrammafunctie (super::dec2flt).
//!
//! Hoewel het herkennen van geldige invoer relatief eenvoudig is, moet deze module ook de talloze ongeldige variaties verwerpen, nooit panic, en talloze controles uitvoeren waarop de andere modules vertrouwen om niet op hun beurt panic (of overflow) uit te voeren.
//!
//! Om het nog erger te maken, gebeurt dat allemaal in één keer over de ingang.
//! Wees dus voorzichtig bij het wijzigen van iets, en controleer nogmaals met de andere modules.
//!
//!
use self::ParseResult::{Invalid, ShortcutToInf, ShortcutToZero, Valid};
use super::num;

#[derive(Debug)]
pub enum Sign {
    Positive,
    Negative,
}

#[derive(Debug, PartialEq, Eq)]
/// De interessante delen van een decimale reeks.
pub struct Decimal<'a> {
    pub integral: &'a [u8],
    pub fractional: &'a [u8],
    /// De decimale exponent, gegarandeerd minder dan 18 decimalen.
    pub exp: i64,
}

impl<'a> Decimal<'a> {
    pub fn new(integral: &'a [u8], fractional: &'a [u8], exp: i64) -> Decimal<'a> {
        Decimal { integral, fractional, exp }
    }
}

#[derive(Debug, PartialEq, Eq)]
pub enum ParseResult<'a> {
    Valid(Decimal<'a>),
    ShortcutToInf,
    ShortcutToZero,
    Invalid,
}

/// Controleert of de invoertekenreeks een geldig drijvende-kommagetal is en zo ja, zoek het integrale deel, het fractionele deel en de exponent erin.
/// Behandelt geen borden.
pub fn parse_decimal(s: &str) -> ParseResult<'_> {
    if s.is_empty() {
        return Invalid;
    }

    let s = s.as_bytes();
    let (integral, s) = eat_digits(s);

    match s.first() {
        None => Valid(Decimal::new(integral, b"", 0)),
        Some(&b'e' | &b'E') => {
            if integral.is_empty() {
                return Invalid; // Geen cijfers voor 'e'
            }

            parse_exp(integral, b"", &s[1..])
        }
        Some(&b'.') => {
            let (fractional, s) = eat_digits(&s[1..]);
            if integral.is_empty() && fractional.is_empty() {
                // We hebben ten minste één cijfer voor of na de punt nodig.
                return Invalid;
            }

            match s.first() {
                None => Valid(Decimal::new(integral, fractional, 0)),
                Some(&b'e' | &b'E') => parse_exp(integral, fractional, &s[1..]),
                _ => Invalid, // Trailing junk na fractioneel deel
            }
        }
        _ => Invalid, // Trailing junk na eerste cijferreeks
    }
}

/// Snijdt decimale cijfers af tot aan het eerste niet-cijferige teken.
fn eat_digits(s: &[u8]) -> (&[u8], &[u8]) {
    let pos = s.iter().position(|c| !c.is_ascii_digit()).unwrap_or(s.len());
    s.split_at(pos)
}

/// Exponent extractie en foutcontrole.
fn parse_exp<'a>(integral: &'a [u8], fractional: &'a [u8], rest: &'a [u8]) -> ParseResult<'a> {
    let (sign, rest) = match rest.first() {
        Some(&b'-') => (Sign::Negative, &rest[1..]),
        Some(&b'+') => (Sign::Positive, &rest[1..]),
        _ => (Sign::Positive, rest),
    };
    let (mut number, trailing) = eat_digits(rest);
    if !trailing.is_empty() {
        return Invalid; // Afval achter exponent
    }
    if number.is_empty() {
        return Invalid; // Lege exponent
    }
    // Op dit punt hebben we zeker een geldige reeks cijfers.Het is misschien te lang om in een `i64` te stoppen, maar als het zo groot is, is de invoer zeker nul of oneindig.
    // Aangezien elke nul in de decimale cijfers alleen de exponent met +/-1 aanpast, zou bij exp=10 ^ 18 de invoer 17 exabyte (!) nullen moeten zijn om zelfs maar in de buurt van eindig te komen.
    //
    // Dit is niet bepaald een use case waar we rekening mee moeten houden.
    //
    while number.first() == Some(&b'0') {
        number = &number[1..];
    }
    if number.len() >= 18 {
        return match sign {
            Sign::Positive => ShortcutToInf,
            Sign::Negative => ShortcutToZero,
        };
    }
    let abs_exp = num::from_str_unchecked(number);
    let e = match sign {
        Sign::Positive => abs_exp as i64,
        Sign::Negative => -(abs_exp as i64),
    };
    Valid(Decimal::new(integral, fractional, e))
}