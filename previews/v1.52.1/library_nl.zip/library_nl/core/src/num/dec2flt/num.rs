//! Hulpprogramma's voor bignums die niet zo logisch zijn om in methoden te veranderen.

// FIXME De naam van deze module is een beetje jammer, aangezien andere modules ook `core::num` importeren.

use crate::cmp::Ordering::{self, Equal, Greater, Less};

pub use crate::num::bignum::Big32x40 as Big;

/// Test of het afkappen van alle bits die minder significant zijn dan `ones_place` een relatieve fout introduceert die kleiner, gelijk of groter is dan 0.5 ULP.
///
pub fn compare_with_half_ulp(f: &Big, ones_place: usize) -> Ordering {
    if ones_place == 0 {
        return Less;
    }
    let half_bit = ones_place - 1;
    if f.get_bit(half_bit) == 0 {
        // <0.5 ULP
        return Less;
    }
    // Als alle resterende bits nul zijn, is het= 0.5 ULP, anders> 0.5 Als er geen bits meer zijn (half_bit==0), retourneert het onderstaande ook correct Equal.
    //
    for i in 0..half_bit {
        if f.get_bit(i) == 1 {
            return Greater;
        }
    }
    Equal
}

/// Converteert een ASCII-tekenreeks met alleen decimale cijfers naar een `u64`.
///
/// Voert geen controles uit op overflow of ongeldige tekens, dus als de beller niet voorzichtig is, is het resultaat nep en kan het panic zijn (hoewel het geen `unsafe` zal zijn).
/// Bovendien worden lege tekenreeksen als nul behandeld.
/// Deze functie bestaat omdat
///
/// 1. het gebruik van `FromStr` op `&[u8]` vereist `from_utf8_unchecked`, wat slecht is, en
/// 2. het samenvoegen van de resultaten van `integral.parse()` en `fractional.parse()` is ingewikkelder dan deze hele functie.
///
pub fn from_str_unchecked<'a, T>(bytes: T) -> u64
where
    T: IntoIterator<Item = &'a u8>,
{
    let mut result = 0;
    for &c in bytes {
        result = result * 10 + (c - b'0') as u64;
    }
    result
}

/// Converteert een reeks ASCII-cijfers naar een bignum.
///
/// Net als `from_str_unchecked` is deze functie afhankelijk van de parser om niet-cijfers te verwijderen.
pub fn digits_to_big(integral: &[u8], fractional: &[u8]) -> Big {
    let mut f = Big::from_small(0);
    for &c in integral.iter().chain(fractional) {
        let n = (c - b'0') as u32;
        f.mul_small(10);
        f.add_small(n);
    }
    f
}

/// Vouwt een bignum uit in een 64-bits geheel getal.Panics als het aantal te groot is.
pub fn to_u64(x: &Big) -> u64 {
    assert!(x.bit_length() < 64);
    let d = x.digits();
    if d.len() < 2 { d[0] as u64 } else { (d[1] as u64) << 32 | d[0] as u64 }
}

/// Extraheert een reeks bits.

/// Index 0 is de minst significante bit en het bereik is zoals gewoonlijk halfopen.
/// Panics indien gevraagd om meer bits te extraheren dan in het retourtype passen.
pub fn get_bits(x: &Big, start: usize, end: usize) -> u64 {
    assert!(end - start <= 64);
    let mut result: u64 = 0;
    for i in (start..end).rev() {
        result = result << 1 | x.get_bit(i) as u64;
    }
    result
}