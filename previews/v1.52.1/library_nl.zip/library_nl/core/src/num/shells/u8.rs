//! Constanten voor het 8-bits type geheel getal zonder teken.
//!
//! *[See also the `u8` primitive type][u8].*
//!
//! Nieuwe code moet de bijbehorende constanten rechtstreeks op het primitieve type gebruiken.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `u8`"
)]

int_module! { u8 }