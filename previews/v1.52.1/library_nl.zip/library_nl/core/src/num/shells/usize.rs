//! Constanten voor het niet-ondertekende integer-type ter grootte van een aanwijzer.
//!
//! *[See also the `usize` primitive type][usize].*
//!
//! Nieuwe code moet de bijbehorende constanten rechtstreeks op het primitieve type gebruiken.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `usize`"
)]

int_module! { usize }