macro_rules! int_impl {
    ($SelfT:ty, $ActualT:ident, $UnsignedT:ty, $BITS:expr, $Min:expr, $Max:expr,
     $rot:expr, $rot_op:expr, $rot_result:expr, $swap_op:expr, $swapped:expr,
     $reversed:expr, $le_bytes:expr, $be_bytes:expr,
     $to_xe_bytes_doc:expr, $from_xe_bytes_doc:expr) => {
        /// De kleinste waarde die kan worden weergegeven door dit type gehele getal.
        ///
        /// # Examples
        ///
        /// Basisgebruik:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN, ", stringify!($Min), ");")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MIN: Self = !0 ^ ((!0 as $UnsignedT) >> 1) as Self;

        /// De grootste waarde die kan worden vertegenwoordigd door dit type gehele getal.
        ///
        /// # Examples
        ///
        /// Basisgebruik:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX, ", stringify!($Max), ");")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MAX: Self = !Self::MIN;

        /// De grootte van dit type integer in bits.
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(int_bits_const)]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::BITS, ", stringify!($BITS), ");")]
        /// ```
        #[unstable(feature = "int_bits_const", issue = "76904")]
        pub const BITS: u32 = $BITS;

        /// Converteert een stringplak in een bepaalde basis naar een geheel getal.
        ///
        /// De tekenreeks is naar verwachting een optioneel `+`-of `-`-teken, gevolgd door cijfers.
        /// Voorlopende en achterliggende witruimte vertegenwoordigen een fout.
        /// Cijfers zijn een subset van deze tekens, afhankelijk van `radix`:
        ///
        ///  * `0-9`
        ///  * `a-z`
        ///  * `A-Z`
        ///
        /// # Panics
        ///
        /// Deze functie panics als `radix` niet in het bereik van 2 tot 36 ligt.
        ///
        /// # Examples
        ///
        /// Basisgebruik:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::from_str_radix(\"A\", 16), Ok(10));")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        pub fn from_str_radix(src: &str, radix: u32) -> Result<Self, ParseIntError> {
            from_str_radix(src, radix)
        }

        /// Retourneert het aantal enen in de binaire weergave van `self`.
        ///
        /// # Examples
        ///
        /// Basisgebruik:
        ///
        /// ```
        #[doc = concat!("let n = 0b100_0000", stringify!($SelfT), ";")]
        /// assert_eq!(n.count_ones(), 1);
        ///
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[doc(alias = "popcount")]
        #[doc(alias = "popcnt")]
        #[inline]
        pub const fn count_ones(self) -> u32 { (self as $UnsignedT).count_ones() }

        /// Retourneert het aantal nullen in de binaire weergave van `self`.
        ///
        /// # Examples
        ///
        /// Basisgebruik:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.count_zeros(), 1);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn count_zeros(self) -> u32 {
            (!self).count_ones()
        }

        /// Retourneert het aantal voorloopnullen in de binaire weergave van `self`.
        ///
        /// # Examples
        ///
        /// Basisgebruik:
        ///
        /// ```
        #[doc = concat!("let n = -1", stringify!($SelfT), ";")]
        /// assert_eq!(n.leading_zeros(), 0);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn leading_zeros(self) -> u32 {
            (self as $UnsignedT).leading_zeros()
        }

        /// Retourneert het aantal volgnullen in de binaire weergave van `self`.
        ///
        /// # Examples
        ///
        /// Basisgebruik:
        ///
        /// ```
        #[doc = concat!("let n = -4", stringify!($SelfT), ";")]
        /// assert_eq!(n.trailing_zeros(), 2);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn trailing_zeros(self) -> u32 {
            (self as $UnsignedT).trailing_zeros()
        }

        /// Retourneert het aantal eerste in de binaire weergave van `self`.
        ///
        /// # Examples
        ///
        /// Basisgebruik:
        ///
        /// ```
        #[doc = concat!("let n = -1", stringify!($SelfT), ";")]

        #[doc = concat!("assert_eq!(n.leading_ones(), ", stringify!($BITS), ");")]
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[inline]
        pub const fn leading_ones(self) -> u32 {
            (self as $UnsignedT).leading_ones()
        }

        /// Retourneert het aantal achterliggende enen in de binaire weergave van `self`.
        ///
        /// # Examples
        ///
        /// Basisgebruik:
        ///
        /// ```
        #[doc = concat!("let n = 3", stringify!($SelfT), ";")]
        /// assert_eq!(n.trailing_ones(), 2);
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[inline]
        pub const fn trailing_ones(self) -> u32 {
            (self as $UnsignedT).trailing_ones()
        }

        /// Verschuift de bits naar links met een opgegeven hoeveelheid, `n`, waarbij de afgekapte bits tot het einde van het resulterende gehele getal worden gewikkeld.
        ///
        ///
        /// Let op: dit is niet dezelfde handeling als de `<<`-schakelautomaat!
        ///
        /// # Examples
        ///
        /// Basisgebruik:
        ///
        /// ```
        #[doc = concat!("let n = ", $rot_op, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_result, ";")]

        #[doc = concat!("assert_eq!(n.rotate_left(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn rotate_left(self, n: u32) -> Self {
            (self as $UnsignedT).rotate_left(n) as Self
        }

        /// Verschuift de bits naar rechts met een gespecificeerde hoeveelheid, `n`, waarbij de afgekapte bits worden omwikkeld met het begin van het resulterende gehele getal.
        ///
        ///
        /// Let op: dit is niet dezelfde handeling als de `>>`-schakelautomaat!
        ///
        /// # Examples
        ///
        /// Basisgebruik:
        ///
        /// ```
        ///
        #[doc = concat!("let n = ", $rot_result, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_op, ";")]

        #[doc = concat!("assert_eq!(n.rotate_right(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn rotate_right(self, n: u32) -> Self {
            (self as $UnsignedT).rotate_right(n) as Self
        }

        /// Keert de bytevolgorde van het gehele getal om.
        ///
        /// # Examples
        ///
        /// Basisgebruik:
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// laat m= n.swap_bytes();
        ///
        #[doc = concat!("assert_eq!(m, ", $swapped, ");")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn swap_bytes(self) -> Self {
            (self as $UnsignedT).swap_bytes() as Self
        }

        /// Keert de volgorde van bits in het gehele getal om.
        /// De minst significante bit wordt de meest significante bit, de tweede minst significante bit wordt de tweede meest significante bit, enz.
        ///
        /// # Examples
        ///
        /// Basisgebruik:
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// laat m= n.reverse_bits();
        ///
        #[doc = concat!("assert_eq!(m, ", $reversed, ");")]
        #[doc = concat!("assert_eq!(0, 0", stringify!($SelfT), ".reverse_bits());")]
        /// ```
        #[stable(feature = "reverse_bits", since = "1.37.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        #[must_use]
        pub const fn reverse_bits(self) -> Self {
            (self as $UnsignedT).reverse_bits() as Self
        }

        /// Converteert een geheel getal van big endian naar de endianness van het doel.
        ///
        /// Op big endian is dit een no-op.Op Little Endian worden de bytes verwisseld.
        ///
        /// # Examples
        ///
        /// Basisgebruik:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// if cfg! (target_endian= "big"){
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n)")]
        /// } anders {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_conversions", since = "1.32.0")]
        #[inline]
        pub const fn from_be(x: Self) -> Self {
            #[cfg(target_endian = "big")]
            {
                x
            }
            #[cfg(not(target_endian = "big"))]
            {
                x.swap_bytes()
            }
        }

        /// Converteert een geheel getal van little endian naar de endianness van het doel.
        ///
        /// Op Little Endian is dit een no-op.Op big endian worden de bytes omgewisseld.
        ///
        /// # Examples
        ///
        /// Basisgebruik:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// if cfg! (target_endian= "little"){
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n)")]
        /// } anders {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_conversions", since = "1.32.0")]
        #[inline]
        pub const fn from_le(x: Self) -> Self {
            #[cfg(target_endian = "little")]
            {
                x
            }
            #[cfg(not(target_endian = "little"))]
            {
                x.swap_bytes()
            }
        }

        /// Converteert `self` naar big endian van de endianness van het doel.
        ///
        /// Op big endian is dit een no-op.Op Little Endian worden de bytes verwisseld.
        ///
        /// # Examples
        ///
        /// Basisgebruik:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// if cfg! (target_endian= "big"){
        ///     assert_eq!(n.to_be(), n)
        /// } anders { assert_eq!(n.to_be(), n.swap_bytes()) }
        ///
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_conversions", since = "1.32.0")]
        #[inline]
        pub const fn to_be(self) -> Self { // of niet te zijn?
            #[cfg(target_endian = "big")]
            {
                self
            }
            #[cfg(not(target_endian = "big"))]
            {
                self.swap_bytes()
            }
        }

        /// Converteert `self` naar little endian vanuit de endianness van het doel.
        ///
        /// Op Little Endian is dit een no-op.Op big endian worden de bytes omgewisseld.
        ///
        /// # Examples
        ///
        /// Basisgebruik:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// if cfg! (target_endian= "little"){
        ///     assert_eq!(n.to_le(), n)
        /// } anders { assert_eq!(n.to_le(), n.swap_bytes()) }
        ///
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_conversions", since = "1.32.0")]
        #[inline]
        pub const fn to_le(self) -> Self {
            #[cfg(target_endian = "little")]
            {
                self
            }
            #[cfg(not(target_endian = "little"))]
            {
                self.swap_bytes()
            }
        }

        /// Optellen van gehele getallen gecontroleerd.
        /// Berekent `self + rhs` en retourneert `None` als er sprake is van overflow.
        ///
        /// # Examples
        ///
        /// Basisgebruik:
        ///
        /// ```
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(1), Some(", stringify!($SelfT), "::MAX - 1));")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(3), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_add(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_add(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Optellen van gehele getallen niet aangevinkt.Berekent `self + rhs`, ervan uitgaande dat er geen overloop kan optreden.
        /// Dit resulteert in ongedefinieerd gedrag wanneer
        #[doc = concat!("`self + rhs > ", stringify!($SelfT), "::MAX` or `self + rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_add(self, rhs: Self) -> Self {
            // VEILIGHEID: de beller moet zich houden aan het veiligheidscontract voor `unchecked_add`.
            //
            unsafe { intrinsics::unchecked_add(self, rhs) }
        }

        /// Aftrekken van gehele getallen gecontroleerd.
        /// Berekent `self - rhs` en retourneert `None` als er sprake is van overflow.
        ///
        /// # Examples
        ///
        /// Basisgebruik:
        ///
        /// ```
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 2).checked_sub(1), Some(", stringify!($SelfT), "::MIN + 1));")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 2).checked_sub(3), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_sub(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_sub(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Aftrekken van gehele getallen niet aangevinkt.Berekent `self - rhs`, ervan uitgaande dat er geen overloop kan optreden.
        /// Dit resulteert in ongedefinieerd gedrag wanneer
        #[doc = concat!("`self - rhs > ", stringify!($SelfT), "::MAX` or `self - rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_sub(self, rhs: Self) -> Self {
            // VEILIGHEID: de beller moet zich houden aan het veiligheidscontract voor `unchecked_sub`.
            //
            unsafe { intrinsics::unchecked_sub(self, rhs) }
        }

        /// Gecontroleerde vermenigvuldiging van gehele getallen.
        /// Berekent `self * rhs` en retourneert `None` als er sprake is van overflow.
        ///
        /// # Examples
        ///
        /// Basisgebruik:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_mul(1), Some(", stringify!($SelfT), "::MAX));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_mul(2), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_mul(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_mul(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Ongecontroleerde vermenigvuldiging met gehele getallen.Berekent `self * rhs`, ervan uitgaande dat er geen overloop kan optreden.
        /// Dit resulteert in ongedefinieerd gedrag wanneer
        #[doc = concat!("`self * rhs > ", stringify!($SelfT), "::MAX` or `self * rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_mul(self, rhs: Self) -> Self {
            // VEILIGHEID: de beller moet zich houden aan het veiligheidscontract voor `unchecked_mul`.
            //
            unsafe { intrinsics::unchecked_mul(self, rhs) }
        }

        /// Deling van gehele getallen gecontroleerd.
        /// Berekent `self / rhs` en retourneert `None` als `rhs == 0` of de deling resulteert in overflow.
        ///
        /// # Examples
        ///
        /// Basisgebruik:
        ///
        /// ```
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 1).checked_div(-1), Some(", stringify!($Max), "));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_div(-1), None);")]
        #[doc = concat!("assert_eq!((1", stringify!($SelfT), ").checked_div(0), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0 || (self == Self::MIN && rhs == -1)) {
                None
            } else {
                // VEILIGHEID: div door nul en door INT_MIN zijn hierboven gecontroleerd
                Some(unsafe { intrinsics::unchecked_div(self, rhs) })
            }
        }

        /// Euclidische divisie gecontroleerd.
        /// Berekent `self.div_euclid(rhs)`, waarbij `None` wordt geretourneerd als `rhs == 0` of de deling resulteert in overflow.
        ///
        /// # Examples
        ///
        /// Basisgebruik:
        ///
        /// ```
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 1).checked_div_euclid(-1), Some(", stringify!($Max), "));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_div_euclid(-1), None);")]
        #[doc = concat!("assert_eq!((1", stringify!($SelfT), ").checked_div_euclid(0), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0 || (self == Self::MIN && rhs == -1)) {
                None
            } else {
                Some(self.div_euclid(rhs))
            }
        }

        /// Geheel getal rest aangevinkt.
        /// Berekent `self % rhs` en retourneert `None` als `rhs == 0` of de deling resulteert in overflow.
        ///
        ///
        /// # Examples
        ///
        /// Basisgebruik:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(0), None);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_rem(-1), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0 || (self == Self::MIN && rhs == -1)) {
                None
            } else {
                // VEILIGHEID: div door nul en door INT_MIN zijn hierboven gecontroleerd
                Some(unsafe { intrinsics::unchecked_rem(self, rhs) })
            }
        }

        /// Euclidische rest gecontroleerd.
        /// Berekent `self.rem_euclid(rhs)` en retourneert `None` als `rhs == 0` of de deling resulteert in overflow.
        ///
        /// # Examples
        ///
        /// Basisgebruik:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(0), None);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_rem_euclid(-1), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0 || (self == Self::MIN && rhs == -1)) {
                None
            } else {
                Some(self.rem_euclid(rhs))
            }
        }

        /// Gecontroleerde ontkenning.
        /// Berekent `-self` en retourneert `None` als `self == MIN`.
        ///
        /// # Examples
        ///
        /// Basisgebruik:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_neg(), Some(-5));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_neg(), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn checked_neg(self) -> Option<Self> {
            let (a, b) = self.overflowing_neg();
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Shift links gecontroleerd.
        /// Berekent `self << rhs` en retourneert `None` als `rhs` groter is dan of gelijk is aan het aantal bits in `self`.
        ///
        /// # Examples
        ///
        /// Basisgebruik:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".checked_shl(4), Some(0x10));")]
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".checked_shl(129), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shl(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shl(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Shift rechts gecontroleerd.
        /// Berekent `self >> rhs` en retourneert `None` als `rhs` groter is dan of gelijk is aan het aantal bits in `self`.
        ///
        /// # Examples
        ///
        /// Basisgebruik:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(4), Some(0x1));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(128), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shr(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shr(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Gecontroleerde absolute waarde.
        /// Berekent `self.abs()` en retourneert `None` als `self == MIN`.
        ///
        ///
        /// # Examples
        ///
        /// Basisgebruik:
        ///
        /// ```
        #[doc = concat!("assert_eq!((-5", stringify!($SelfT), ").checked_abs(), Some(5));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_abs(), None);")]
        /// ```
        #[stable(feature = "no_panic_abs", since = "1.13.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn checked_abs(self) -> Option<Self> {
            if self.is_negative() {
                self.checked_neg()
            } else {
                Some(self)
            }
        }

        /// Gecontroleerde machtsverheffing.
        /// Berekent `self.pow(exp)` en retourneert `None` als er sprake is van overflow.
        ///
        /// # Examples
        ///
        /// Basisgebruik:
        ///
        /// ```
        #[doc = concat!("assert_eq!(8", stringify!($SelfT), ".checked_pow(2), Some(64));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_pow(2), None);")]
        /// ```

        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_pow(self, mut exp: u32) -> Option<Self> {
            if exp == 0 {
                return Some(1);
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = try_opt!(acc.checked_mul(base));
                }
                exp /= 2;
                base = try_opt!(base.checked_mul(base));
            }
            // sinds exp!=0, ten slotte moet de exp 1 zijn.
            // Behandel het laatste bit van de exponent apart, aangezien het achteraf kwadrateren van de basis niet nodig is en een onnodige overloop kan veroorzaken.
            //
            //
            Some(try_opt!(acc.checked_mul(base)))
        }

        /// Verzadigende toevoeging van gehele getallen.
        /// Berekent `self + rhs`, verzadigend op de numerieke grenzen in plaats van overlopend.
        ///
        /// # Examples
        ///
        /// Basisgebruik:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_add(1), 101);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_add(100), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_add(-1), ", stringify!($SelfT), "::MIN);")]
        /// ```

        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_add(self, rhs: Self) -> Self {
            intrinsics::saturating_add(self, rhs)
        }

        /// Aftrekken van gehele getallen.
        /// Berekent `self - rhs`, verzadigend op de numerieke grenzen in plaats van overlopend.
        ///
        /// # Examples
        ///
        /// Basisgebruik:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_sub(127), -27);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_sub(100), ", stringify!($SelfT), "::MIN);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_sub(-1), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_sub(self, rhs: Self) -> Self {
            intrinsics::saturating_sub(self, rhs)
        }

        /// Verzadigende negatie van gehele getallen.
        /// Berekent `-self`, waarbij `MAX` wordt geretourneerd als `self == MIN` in plaats van overloopt.
        ///
        /// # Examples
        ///
        /// Basisgebruik:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_neg(), -100);")]
        #[doc = concat!("assert_eq!((-100", stringify!($SelfT), ").saturating_neg(), 100);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_neg(), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_neg(), ", stringify!($SelfT), "::MIN + 1);")]
        /// ```

        #[stable(feature = "saturating_neg", since = "1.45.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn saturating_neg(self) -> Self {
            intrinsics::saturating_sub(0, self)
        }

        /// Verzadigende absolute waarde.
        /// Berekent `self.abs()`, waarbij `MAX` wordt geretourneerd als `self == MIN` in plaats van overloopt.
        ///
        /// # Examples
        ///
        /// Basisgebruik:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_abs(), 100);")]
        #[doc = concat!("assert_eq!((-100", stringify!($SelfT), ").saturating_abs(), 100);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_abs(), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 1).saturating_abs(), ", stringify!($SelfT), "::MAX);")]
        /// ```

        #[stable(feature = "saturating_neg", since = "1.45.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn saturating_abs(self) -> Self {
            if self.is_negative() {
                self.saturating_neg()
            } else {
                self
            }
        }

        /// Verzadiging van gehele vermenigvuldiging.
        /// Berekent `self * rhs`, verzadigend op de numerieke grenzen in plaats van overlopend.
        ///
        ///
        /// # Examples
        ///
        /// Basisgebruik:
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".saturating_mul(12), 120);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_mul(10), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_mul(10), ", stringify!($SelfT), "::MIN);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_mul(self, rhs: Self) -> Self {
            match self.checked_mul(rhs) {
                Some(x) => x,
                None => if (self < 0) == (rhs < 0) {
                    Self::MAX
                } else {
                    Self::MIN
                }
            }
        }

        /// Verzadiging van gehele machtsverheffing.
        /// Berekent `self.pow(exp)`, verzadigend op de numerieke grenzen in plaats van overlopend.
        ///
        ///
        /// # Examples
        ///
        /// Basisgebruik:
        ///
        /// ```
        #[doc = concat!("assert_eq!((-4", stringify!($SelfT), ").saturating_pow(3), -64);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_pow(2), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_pow(3), ", stringify!($SelfT), "::MIN);")]
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_pow(self, exp: u32) -> Self {
            match self.checked_pow(exp) {
                Some(x) => x,
                None if self < 0 && exp % 2 == 1 => Self::MIN,
                None => Self::MAX,
            }
        }

        /// Wrapping (modular) toevoeging.
        /// Berekent `self + rhs` en wikkelt zich rond de grens van het type.
        ///
        /// # Examples
        ///
        /// Basisgebruik:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_add(27), 127);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.wrapping_add(2), ", stringify!($SelfT), "::MIN + 1);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_add(self, rhs: Self) -> Self {
            intrinsics::wrapping_add(self, rhs)
        }

        /// (modular) aftrekken verpakken.
        /// Berekent `self - rhs` en wikkelt zich rond de grens van het type.
        ///
        /// # Examples
        ///
        /// Basisgebruik:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".wrapping_sub(127), -127);")]
        #[doc = concat!("assert_eq!((-2", stringify!($SelfT), ").wrapping_sub(", stringify!($SelfT), "::MAX), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_sub(self, rhs: Self) -> Self {
            intrinsics::wrapping_sub(self, rhs)
        }

        /// (modular) vermenigvuldiging verpakken.
        /// Berekent `self * rhs` en wikkelt zich rond de grens van het type.
        ///
        /// # Examples
        ///
        /// Basisgebruik:
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".wrapping_mul(12), 120);")]
        /// assert_eq!(11i8.wrapping_mul(12), -124);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_mul(self, rhs: Self) -> Self {
            intrinsics::wrapping_mul(self, rhs)
        }

        /// Wrapping (modular) divisie.Berekent `self / rhs` en wikkelt zich rond de grens van het type.
        ///
        /// Het enige geval waarin een dergelijke omwikkeling kan voorkomen, is wanneer men `MIN / -1` verdeelt op een ondertekend type (waarbij `MIN` de negatieve minimale waarde voor het type is);dit is gelijk aan `-MIN`, een positieve waarde die te groot is om in het type weer te geven.
        /// In dat geval retourneert deze functie zelf `MIN`.
        ///
        /// # Panics
        ///
        /// Deze functie zal panic zijn als `rhs` 0 is.
        ///
        /// # Examples
        ///
        /// Basisgebruik:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div(10), 10);")]
        /// assert_eq!((-128i8).wrapping_div(-1), -128);
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div(self, rhs: Self) -> Self {
            self.overflowing_div(rhs).0
        }

        /// Euclidische divisie inpakken.
        /// Berekent `self.div_euclid(rhs)` en wikkelt zich rond de grens van het type.
        ///
        /// Wrapping vindt alleen plaats in `MIN / -1` op een ondertekend type (waarbij `MIN` de negatieve minimale waarde voor het type is).
        /// Dit is gelijk aan `-MIN`, een positieve waarde die te groot is om in het type weer te geven.
        /// In dit geval retourneert deze methode `MIN` zelf.
        ///
        /// # Panics
        ///
        /// Deze functie zal panic zijn als `rhs` 0 is.
        ///
        /// # Examples
        ///
        /// Basisgebruik:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div_euclid(10), 10);")]
        /// assert_eq!((-128i8).wrapping_div_euclid(-1), -128);
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div_euclid(self, rhs: Self) -> Self {
            self.overflowing_div_euclid(rhs).0
        }

        /// Rest van (modular) inpakken.Berekent `self % rhs` en wikkelt zich rond de grens van het type.
        ///
        /// Zo'n omslag gebeurt nooit echt wiskundig;implementatie artefacten maken `x % y` ongeldig voor `MIN / -1` op een ondertekend type (waarbij `MIN` de negatieve minimale waarde is).
        ///
        /// In dat geval retourneert deze functie `0`.
        ///
        /// # Panics
        ///
        /// Deze functie zal panic zijn als `rhs` 0 is.
        ///
        /// # Examples
        ///
        /// Basisgebruik:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem(10), 0);")]
        /// assert_eq!((-128i8).wrapping_rem(-1), 0);
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem(self, rhs: Self) -> Self {
            self.overflowing_rem(rhs).0
        }

        /// Euclidische rest inpakken.Berekent `self.rem_euclid(rhs)` en wikkelt zich rond de grens van het type.
        ///
        /// Wrapping vindt alleen plaats in `MIN % -1` op een ondertekend type (waarbij `MIN` de negatieve minimale waarde voor het type is).
        /// In dit geval retourneert deze methode 0.
        ///
        /// # Panics
        ///
        /// Deze functie zal panic zijn als `rhs` 0 is.
        ///
        /// # Examples
        ///
        /// Basisgebruik:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem_euclid(10), 0);")]
        /// assert_eq!((-128i8).wrapping_rem_euclid(-1), 0);
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem_euclid(self, rhs: Self) -> Self {
            self.overflowing_rem_euclid(rhs).0
        }

        /// Wrapping (modular) negatie.Berekent `-self` en wikkelt zich rond de grens van het type.
        ///
        /// Het enige geval waarin een dergelijke omwikkeling kan voorkomen, is wanneer men `MIN` negeert op een ondertekend type (waarbij `MIN` de negatieve minimale waarde voor het type is);dit is een positieve waarde die te groot is om in het type weer te geven.
        /// In dat geval retourneert deze functie zelf `MIN`.
        ///
        /// # Examples
        ///
        /// Basisgebruik:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_neg(), -100);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.wrapping_neg(), ", stringify!($SelfT), "::MIN);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn wrapping_neg(self) -> Self {
            self.overflowing_neg().0
        }

        /// Panic-vrij bitsgewijs verschuiven naar links;levert `self << mask(rhs)` op, waarbij `mask` alle bits van hoge orde van `rhs` verwijdert die ervoor zorgen dat de verschuiving de bitbreedte van het type overschrijdt.
        ///
        /// Merk op dat dit *niet* hetzelfde is als linksom draaien;de RHS van een wikkelverschuiving-links is beperkt tot het bereik van het type, in plaats van dat de bits die uit de LHS worden geschoven naar het andere uiteinde worden teruggestuurd.
        ///
        /// De primitieve integer-typen implementeren allemaal een [`rotate_left`](Self::rotate_left)-functie, die u in plaats daarvan misschien wilt.
        ///
        /// # Examples
        ///
        /// Basisgebruik:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!((-1", stringify!($SelfT), ").wrapping_shl(7), -128);")]
        #[doc = concat!("assert_eq!((-1", stringify!($SelfT), ").wrapping_shl(128), -1);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_shl(self, rhs: u32) -> Self {
            // VEILIGHEID: de maskering door de bitsize van het type zorgt ervoor dat we niet verschuiven
            // buiten de grenzen
            unsafe {
                intrinsics::unchecked_shl(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// Panic-vrije bitsgewijze verschuiving-rechts;levert `self >> mask(rhs)` op, waarbij `mask` alle bits van hoge orde van `rhs` verwijdert die ervoor zorgen dat de verschuiving de bitbreedte van het type overschrijdt.
        ///
        /// Merk op dat dit *niet* hetzelfde is als roteren-rechts;de RHS van een omhullende shift-right is beperkt tot het bereik van het type, in plaats van dat de bits die uit de LHS worden geschoven naar het andere uiteinde worden teruggestuurd.
        ///
        /// De primitieve integer-typen implementeren allemaal een [`rotate_right`](Self::rotate_right)-functie, die u in plaats daarvan misschien wilt.
        ///
        /// # Examples
        ///
        /// Basisgebruik:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!((-128", stringify!($SelfT), ").wrapping_shr(7), -1);")]
        /// assert_eq!((-128i16).wrapping_shr(64), -128);
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_shr(self, rhs: u32) -> Self {
            // VEILIGHEID: de maskering door de bitsize van het type zorgt ervoor dat we niet verschuiven
            // buiten de grenzen
            unsafe {
                intrinsics::unchecked_shr(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// Wrapping (modular) absolute waarde.Berekent `self.abs()` en wikkelt zich rond de grens van het type.
        ///
        /// Het enige geval waarin een dergelijke omwikkeling kan voorkomen, is wanneer men de absolute waarde van de negatieve minimale waarde voor het type neemt;dit is een positieve waarde die te groot is om in het type weer te geven.
        /// In dat geval retourneert deze functie zelf `MIN`.
        ///
        /// # Examples
        ///
        /// Basisgebruik:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_abs(), 100);")]
        #[doc = concat!("assert_eq!((-100", stringify!($SelfT), ").wrapping_abs(), 100);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.wrapping_abs(), ", stringify!($SelfT), "::MIN);")]
        /// assert_eq!((-128i8).wrapping_abs() as u8, 128);
        /// ```
        #[stable(feature = "no_panic_abs", since = "1.13.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[allow(unused_attributes)]
        #[inline]
        pub const fn wrapping_abs(self) -> Self {
             if self.is_negative() {
                 self.wrapping_neg()
             } else {
                 self
             }
        }

        /// Berekent de absolute waarde van `self` zonder enige verpakking of paniek.
        ///
        ///
        /// # Examples
        ///
        /// Basisgebruik:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".unsigned_abs(), 100", stringify!($UnsignedT), ");")]
        #[doc = concat!("assert_eq!((-100", stringify!($SelfT), ").unsigned_abs(), 100", stringify!($UnsignedT), ");")]
        /// assert_eq!((-128i8).unsigned_abs(), 128u8);
        /// ```
        #[stable(feature = "unsigned_abs", since = "1.51.0")]
        #[rustc_const_stable(feature = "unsigned_abs", since = "1.51.0")]
        #[inline]
        pub const fn unsigned_abs(self) -> $UnsignedT {
             self.wrapping_abs() as $UnsignedT
        }

        /// (modular) machtsverheffen verpakken.
        /// Berekent `self.pow(exp)` en wikkelt zich rond de grens van het type.
        ///
        /// # Examples
        ///
        /// Basisgebruik:
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".wrapping_pow(4), 81);")]
        /// assert_eq!(3i8.wrapping_pow(5), -13);
        /// assert_eq!(3i8.wrapping_pow(6), -39);
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc.wrapping_mul(base);
                }
                exp /= 2;
                base = base.wrapping_mul(base);
            }

            // sinds exp!=0, ten slotte moet de exp 1 zijn.
            // Behandel het laatste bit van de exponent apart, aangezien het achteraf kwadrateren van de basis niet nodig is en een onnodige overloop kan veroorzaken.
            //
            //
            acc.wrapping_mul(base)
        }

        /// Berekent `self` + `rhs`
        ///
        /// Retourneert een tupel van de optelling samen met een booleaanse waarde die aangeeft of er een rekenkundige overloop zou optreden.
        /// Als er een overflow zou zijn opgetreden, wordt de ingepakte waarde geretourneerd.
        ///
        /// # Examples
        ///
        /// Basisgebruik:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_add(2), (7, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.overflowing_add(1), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_add(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::add_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// Berekent `self`, `rhs`
        ///
        /// Retourneert een tupel van de aftrekking samen met een booleaanse waarde die aangeeft of er een rekenkundige overloop zou optreden.
        /// Als er een overflow zou zijn opgetreden, wordt de ingepakte waarde geretourneerd.
        ///
        /// # Examples
        ///
        /// Basisgebruik:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_sub(2), (3, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_sub(1), (", stringify!($SelfT), "::MAX, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_sub(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::sub_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// Berekent de vermenigvuldiging van `self` en `rhs`.
        ///
        /// Retourneert een tupel van de vermenigvuldiging samen met een booleaanse waarde die aangeeft of er een rekenkundige overloop zou optreden.
        /// Als er een overflow zou zijn opgetreden, wordt de ingepakte waarde geretourneerd.
        ///
        /// # Examples
        ///
        /// Basisgebruik:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_mul(2), (10, false));")]
        /// assert_eq!(1_000_000_000i32.overflowing_mul(10), (1410065408, waar));
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_mul(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::mul_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// Berekent de deler wanneer `self` wordt gedeeld door `rhs`.
        ///
        /// Retourneert een tupel van de deler samen met een booleaanse waarde die aangeeft of er een rekenkundige overloop zou optreden.
        /// Als er een overstroming zou optreden, keert het zelf terug.
        ///
        /// # Panics
        ///
        /// Deze functie zal panic zijn als `rhs` 0 is.
        ///
        /// # Examples
        ///
        /// Basisgebruik:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div(2), (2, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_div(-1), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div(self, rhs: Self) -> (Self, bool) {
            if unlikely!(self == Self::MIN && rhs == -1) {
                (self, true)
            } else {
                (self / rhs, false)
            }
        }

        /// Berekent het quotiënt van Euclidische deling `self.div_euclid(rhs)`.
        ///
        /// Retourneert een tupel van de deler samen met een booleaanse waarde die aangeeft of er een rekenkundige overloop zou optreden.
        /// Als er een overflow zou optreden, wordt `self` geretourneerd.
        ///
        /// # Panics
        ///
        /// Deze functie zal panic zijn als `rhs` 0 is.
        ///
        /// # Examples
        ///
        /// Basisgebruik:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div_euclid(2), (2, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_div_euclid(-1), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        #[inline]
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div_euclid(self, rhs: Self) -> (Self, bool) {
            if unlikely!(self == Self::MIN && rhs == -1) {
                (self, true)
            } else {
                (self.div_euclid(rhs), false)
            }
        }

        /// Berekent de rest als `self` wordt gedeeld door `rhs`.
        ///
        /// Retourneert een tupel van de rest na het delen, samen met een booleaanse waarde die aangeeft of er een rekenkundige overloop zou optreden.
        /// Als er een overflow zou optreden, wordt 0 geretourneerd.
        ///
        /// # Panics
        ///
        /// Deze functie zal panic zijn als `rhs` 0 is.
        ///
        /// # Examples
        ///
        /// Basisgebruik:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem(2), (1, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_rem(-1), (0, true));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_rem(self, rhs: Self) -> (Self, bool) {
            if unlikely!(self == Self::MIN && rhs == -1) {
                (0, true)
            } else {
                (self % rhs, false)
            }
        }


        /// Overvolle Euclidische rest.Berekent `self.rem_euclid(rhs)`.
        ///
        /// Retourneert een tupel van de rest na het delen, samen met een booleaanse waarde die aangeeft of er een rekenkundige overloop zou optreden.
        /// Als er een overflow zou optreden, wordt 0 geretourneerd.
        ///
        /// # Panics
        ///
        /// Deze functie zal panic zijn als `rhs` 0 is.
        ///
        /// # Examples
        ///
        /// Basisgebruik:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem_euclid(2), (1, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_rem_euclid(-1), (0, true));")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_rem_euclid(self, rhs: Self) -> (Self, bool) {
            if unlikely!(self == Self::MIN && rhs == -1) {
                (0, true)
            } else {
                (self.rem_euclid(rhs), false)
            }
        }


        /// Negeert zichzelf, overstroomt als dit gelijk is aan de minimumwaarde.
        ///
        /// Retourneert een tupel van de genegeerde versie van self, samen met een boolean die aangeeft of er een overflow is opgetreden.
        /// Als `self` de minimumwaarde is (bijv. `i32::MIN` voor waarden van het type `i32`), dan wordt de minimumwaarde opnieuw geretourneerd en wordt `true` geretourneerd als er een overflow optreedt.
        ///
        ///
        /// # Examples
        ///
        /// Basisgebruik:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".overflowing_neg(), (-2, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_neg(), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[allow(unused_attributes)]
        pub const fn overflowing_neg(self) -> (Self, bool) {
            if unlikely!(self == Self::MIN) {
                (Self::MIN, true)
            } else {
                (-self, false)
            }
        }

        /// Verschuift zichzelf naar links door `rhs`-bits.
        ///
        /// Retourneert een tupel van de verschoven versie van self samen met een booleaanse waarde die aangeeft of de verschuivingswaarde groter of gelijk was aan het aantal bits.
        /// Als de verschuivingswaarde te groot is, wordt de waarde gemaskeerd (N-1) waar N het aantal bits is, en deze waarde wordt vervolgens gebruikt om de verschuiving uit te voeren.
        ///
        /// # Examples
        ///
        /// Basisgebruik:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT),".overflowing_shl(4), (0x10, false));")]
        /// assert_eq!(0x1i32.overflowing_shl(36), (0x10, waar));
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shl(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shl(rhs), (rhs > ($BITS - 1)))
        }

        /// Verschuift zichzelf naar rechts door `rhs`-bits.
        ///
        /// Retourneert een tupel van de verschoven versie van self samen met een booleaanse waarde die aangeeft of de verschuivingswaarde groter of gelijk was aan het aantal bits.
        /// Als de verschuivingswaarde te groot is, wordt de waarde gemaskeerd (N-1) waar N het aantal bits is, en deze waarde wordt vervolgens gebruikt om de verschuiving uit te voeren.
        ///
        /// # Examples
        ///
        /// Basisgebruik:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".overflowing_shr(4), (0x1, false));")]
        /// assert_eq!(0x10i32.overflowing_shr(36), (0x1, waar));
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shr(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shr(rhs), (rhs > ($BITS - 1)))
        }

        /// Berekent de absolute waarde van `self`.
        ///
        /// Retourneert een tupel van de absolute versie van self samen met een booleaanse waarde die aangeeft of er een overflow is opgetreden.
        /// Als self de minimumwaarde is
        #[doc = concat!("(e.g., ", stringify!($SelfT), "::MIN for values of type ", stringify!($SelfT), "),")]
        /// dan wordt de minimumwaarde opnieuw geretourneerd en wordt true geretourneerd als er een overflow plaatsvindt.
        ///
        ///
        /// # Examples
        ///
        /// Basisgebruik:
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".overflowing_abs(), (10, false));")]
        #[doc = concat!("assert_eq!((-10", stringify!($SelfT), ").overflowing_abs(), (10, false));")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN).overflowing_abs(), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        #[stable(feature = "no_panic_abs", since = "1.13.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn overflowing_abs(self) -> (Self, bool) {
            (self.wrapping_abs(), self == Self::MIN)
        }

        /// Verheft zichzelf tot de kracht van `exp`, gebruikmakend van machtsverheffen door kwadratuur.
        ///
        /// Retourneert een tupel van de machtsverheffen samen met een bool die aangeeft of er een overflow heeft plaatsgevonden.
        ///
        ///
        /// # Examples
        ///
        /// Basisgebruik:
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".overflowing_pow(4), (81, false));")]
        /// assert_eq!(3i8.overflowing_pow(5), (-13, waar));
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_pow(self, mut exp: u32) -> (Self, bool) {
            if exp == 0 {
                return (1,false);
            }
            let mut base = self;
            let mut acc: Self = 1;
            let mut overflown = false;
            // Krasruimte voor het opslaan van resultaten van overflowing_mul.
            let mut r;

            while exp > 1 {
                if (exp & 1) == 1 {
                    r = acc.overflowing_mul(base);
                    acc = r.0;
                    overflown |= r.1;
                }
                exp /= 2;
                r = base.overflowing_mul(base);
                base = r.0;
                overflown |= r.1;
            }

            // sinds exp!=0, ten slotte moet de exp 1 zijn.
            // Behandel het laatste bit van de exponent apart, aangezien het achteraf kwadrateren van de basis niet nodig is en een onnodige overloop kan veroorzaken.
            //
            //
            r = acc.overflowing_mul(base);
            r.1 |= overflown;
            r
        }

        /// Verheft zichzelf tot de kracht van `exp`, gebruikmakend van machtsverheffen door kwadratuur.
        ///
        /// # Examples
        ///
        /// Basisgebruik:
        ///
        /// ```
        #[doc = concat!("let x: ", stringify!($SelfT), " = 2; // or any other integer type")]
        /// assert_eq!(x.pow(5), 32);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc * base;
                }
                exp /= 2;
                base = base * base;
            }

            // sinds exp!=0, ten slotte moet de exp 1 zijn.
            // Behandel het laatste bit van de exponent apart, aangezien het achteraf kwadrateren van de basis niet nodig is en een onnodige overloop kan veroorzaken.
            //
            //
            acc * base
        }

        /// Berekent het quotiënt van Euclidische deling van `self` door `rhs`.
        ///
        /// Dit berekent het gehele getal `n` zodat `self = n * rhs + self.rem_euclid(rhs)`, met `0 <= self.rem_euclid(rhs) < rhs`.
        ///
        ///
        /// Met andere woorden, het resultaat is `self / rhs` afgerond op het gehele getal `n` zodat `self >= n * rhs`.
        /// Als `self > 0`, is dit gelijk aan afronden naar nul (de standaard in Rust);
        /// als `self < 0`, is dit gelijk aan afronden naar +/-oneindig.
        ///
        /// # Panics
        ///
        /// Deze functie zal panic zijn als `rhs` 0 is of de deling resulteert in overloop.
        ///
        /// # Examples
        ///
        /// Basisgebruik:
        ///
        /// ```
        ///
        #[doc = concat!("let a: ", stringify!($SelfT), " = 7; // or any other integer type")]
        /// laat b=4;
        ///
        /// assert_eq!(a.div_euclid(b), 1); //7>=4 *1 assert_eq!(a.div_euclid(-b), -1);//7>= -4*-1 assert_eq!((-a).div_euclid(b), -2);//-7>=4 *-2 assert_eq!((-a).div_euclid(-b), 2);//-7>= -4* 2
        ///
        /// ```
        ///
        ///
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn div_euclid(self, rhs: Self) -> Self {
            let q = self / rhs;
            if self % rhs < 0 {
                return if rhs > 0 { q - 1 } else { q + 1 }
            }
            q
        }


        /// Berekent de minst niet-negatieve rest van `self (mod rhs)`.
        ///
        /// Dit wordt gedaan alsof door het Euclidische delingsalgoritme-gegeven `r = self.rem_euclid(rhs)`, `self = rhs * self.div_euclid(rhs) + r` en `0 <= r < abs(rhs)`.
        ///
        ///
        /// # Panics
        ///
        /// Deze functie zal panic zijn als `rhs` 0 is of de deling resulteert in overloop.
        ///
        /// # Examples
        ///
        /// Basisgebruik:
        ///
        /// ```
        ///
        #[doc = concat!("let a: ", stringify!($SelfT), " = 7; // or any other integer type")]
        /// laat b=4;
        ///
        /// assert_eq!(a.rem_euclid(b), 3);
        /// assert_eq!((-a).rem_euclid(b), 1);
        /// assert_eq!(a.rem_euclid(-b), 3);
        /// assert_eq!((-a).rem_euclid(-b), 1);
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn rem_euclid(self, rhs: Self) -> Self {
            let r = self % rhs;
            if r < 0 {
                if rhs < 0 {
                    r - rhs
                } else {
                    r + rhs
                }
            } else {
                r
            }
        }

        /// Berekent de absolute waarde van `self`.
        ///
        /// # Overloopgedrag
        ///
        /// De absolute waarde van
        #[doc = concat!("`", stringify!($SelfT), "::MIN`")]
        /// kan niet worden weergegeven als een
        #[doc = concat!("`", stringify!($SelfT), "`,")]
        /// en proberen te berekenen, zal een overloop veroorzaken.
        /// Dit betekent dat code in foutopsporingsmodus in dit geval een panic activeert en geoptimaliseerde code zal terugkeren
        ///
        #[doc = concat!("`", stringify!($SelfT), "::MIN`")]
        /// zonder een panic.
        ///
        /// # Examples
        ///
        /// Basisgebruik:
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".abs(), 10);")]
        #[doc = concat!("assert_eq!((-10", stringify!($SelfT), ").abs(), 10);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[allow(unused_attributes)]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn abs(self) -> Self {
            // Merk op dat de#[inline] hierboven betekent dat de overflow-semantiek van de aftrekking afhangt van de crate waarin we inline worden geplaatst.
            //
            //
            if self.is_negative() {
                -self
            } else {
                self
            }
        }

        /// Retourneert een getal dat het teken van `self` vertegenwoordigt.
        ///
        ///  - `0` als het aantal nul is
        ///  - `1` als het aantal positief is
        ///  - `-1` als het aantal negatief is
        ///
        /// # Examples
        ///
        /// Basisgebruik:
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".signum(), 1);")]
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".signum(), 0);")]
        #[doc = concat!("assert_eq!((-10", stringify!($SelfT), ").signum(), -1);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_sign", since = "1.47.0")]
        #[inline]
        pub const fn signum(self) -> Self {
            match self {
                n if n > 0 =>  1,
                0          =>  0,
                _          => -1,
            }
        }

        /// Retourneert `true` als `self` positief is en `false` als het getal nul of negatief is.
        ///
        ///
        /// # Examples
        ///
        /// Basisgebruik:
        ///
        /// ```
        #[doc = concat!("assert!(10", stringify!($SelfT), ".is_positive());")]
        #[doc = concat!("assert!(!(-10", stringify!($SelfT), ").is_positive());")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn is_positive(self) -> bool { self > 0 }

        /// Retourneert `true` als `self` negatief is en `false` als het getal nul of positief is.
        ///
        ///
        /// # Examples
        ///
        /// Basisgebruik:
        ///
        /// ```
        #[doc = concat!("assert!((-10", stringify!($SelfT), ").is_negative());")]
        #[doc = concat!("assert!(!10", stringify!($SelfT), ".is_negative());")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn is_negative(self) -> bool { self < 0 }

        /// Retourneer de geheugenrepresentatie van dit gehele getal als een byte-array in bytevolgorde big-endian (network).
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_be_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $be_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn to_be_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_be().to_ne_bytes()
        }

        /// Retourneer de geheugenrepresentatie van dit gehele getal als een byte-array in bytevolgorde little-endian.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_le_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $le_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn to_le_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_le().to_ne_bytes()
        }

        /// Retourneer de geheugenrepresentatie van dit gehele getal als een byte-array in de oorspronkelijke bytevolgorde.
        ///
        /// Aangezien de native endianness van het doelplatform wordt gebruikt, moet draagbare code in plaats daarvan [`to_be_bytes`] of [`to_le_bytes`] gebruiken.
        ///
        ///
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// [`to_be_bytes`]: Self::to_be_bytes
        /// [`to_le_bytes`]: Self::to_le_bytes
        ///
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_ne_bytes();")]
        /// assert_eq!(
        ///     bytes, als cfg! (target_endian= "big"){
        ///
        #[doc = concat!("        ", $be_bytes)]
        /// } anders {
        #[doc = concat!("        ", $le_bytes)]
        /// }
        /// );
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // VEILIGHEID: const geluid omdat gehele getallen gewone oude datatypes zijn, dus dat kunnen we altijd
        // transmuteer ze naar arrays van bytes
        #[rustc_allow_const_fn_unstable(const_fn_transmute)]
        #[inline]
        pub const fn to_ne_bytes(self) -> [u8; mem::size_of::<Self>()] {
            // VEILIGHEID: gehele getallen zijn gewone oude datatypes, dus we kunnen ze altijd naar transmuteren
            // arrays van bytes
            unsafe { mem::transmute(self) }
        }

        /// Retourneer de geheugenrepresentatie van dit gehele getal als een byte-array in de oorspronkelijke bytevolgorde.
        ///
        ///
        /// [`to_ne_bytes`] verdient waar mogelijk de voorkeur boven dit.
        ///
        /// [`to_ne_bytes`]: Self::to_ne_bytes
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(num_as_ne_bytes)]
        #[doc = concat!("let num = ", $swap_op, stringify!($SelfT), ";")]
        /// laat bytes= num.as_ne_bytes();
        /// assert_eq!(
        ///     bytes, als cfg! (target_endian= "big"){
        ///
        #[doc = concat!("        &", $be_bytes)]
        /// } anders {
        #[doc = concat!("        &", $le_bytes)]
        /// }
        /// );
        /// ```
        #[unstable(feature = "num_as_ne_bytes", issue = "76976")]
        #[inline]
        pub fn as_ne_bytes(&self) -> &[u8; mem::size_of::<Self>()] {
            // VEILIGHEID: gehele getallen zijn gewone oude datatypes, dus we kunnen ze altijd naar transmuteren
            // arrays van bytes
            unsafe { &*(self as *const Self as *const _) }
        }

        /// Maak een geheel getal op basis van de weergave ervan als een byte-array in big endian.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_be_bytes(", $be_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// gebruik std::convert::TryInto;
        #[doc = concat!("fn read_be_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * input=rust;
        #[doc = concat!("    ", stringify!($SelfT), "::from_be_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn from_be_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_be(Self::from_ne_bytes(bytes))
        }

        /// Maak een geheel getal uit de weergave ervan als een byte-array in little endian.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_le_bytes(", $le_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// gebruik std::convert::TryInto;
        #[doc = concat!("fn read_le_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * input=rust;
        #[doc = concat!("    ", stringify!($SelfT), "::from_le_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn from_le_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_le(Self::from_ne_bytes(bytes))
        }

        /// Maak een geheel getal uit de geheugenweergave als een byte-array in native endianness.
        ///
        /// Aangezien de native endianness van het doelplatform wordt gebruikt, wil draagbare code in plaats daarvan waarschijnlijk [`from_be_bytes`] of [`from_le_bytes`] gebruiken.
        ///
        ///
        /// [`from_be_bytes`]: Self::from_be_bytes
        /// [`from_le_bytes`]: Self::from_le_bytes
        ///
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_ne_bytes(if cfg!(target_endian = \"big\") {")]
        #[doc = concat!("    ", $be_bytes)]
        /// } anders {
        #[doc = concat!("    ", $le_bytes)]
        /// });
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// gebruik std::convert::TryInto;
        #[doc = concat!("fn read_ne_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * input=rust;
        #[doc = concat!("    ", stringify!($SelfT), "::from_ne_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // VEILIGHEID: const geluid omdat gehele getallen gewone oude datatypes zijn, dus dat kunnen we altijd
        // transmuteer naar hen
        #[rustc_allow_const_fn_unstable(const_fn_transmute)]
        #[inline]
        pub const fn from_ne_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            // VEILIGHEID: gehele getallen zijn gewone oude datatypes, dus we kunnen er altijd naar transmuteren
            unsafe { mem::transmute(bytes) }
        }

        /// Nieuwe code verdient de voorkeur
        #[doc = concat!("[`", stringify!($SelfT), "::MIN", "`] instead.")]
        /// Retourneert de kleinste waarde die kan worden vertegenwoordigd door dit type gehele getal.
        #[stable(feature = "rust1", since = "1.0.0")]
        #[inline(always)]
        #[rustc_promotable]
        #[rustc_const_stable(feature = "const_min_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MIN` associated constant on this type")]
        pub const fn min_value() -> Self {
            Self::MIN
        }

        /// Nieuwe code verdient de voorkeur
        #[doc = concat!("[`", stringify!($SelfT), "::MAX", "`] instead.")]
        /// Retourneert de grootste waarde die kan worden vertegenwoordigd door dit type gehele getal.
        #[stable(feature = "rust1", since = "1.0.0")]
        #[inline(always)]
        #[rustc_promotable]
        #[rustc_const_stable(feature = "const_max_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MAX` associated constant on this type")]
        pub const fn max_value() -> Self {
            Self::MAX
        }
    }
}