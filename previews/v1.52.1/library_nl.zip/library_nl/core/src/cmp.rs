//! Functionaliteit voor bestellen en vergelijken.
//!
//! Deze module bevat verschillende tools voor het ordenen en vergelijken van waarden.Samengevat:
//!
//! * [`Eq`] en [`PartialEq`] zijn traits waarmee u respectievelijk totale en gedeeltelijke gelijkheid tussen waarden kunt definiëren.
//! Door ze te implementeren, worden de `==`-en `!=`-operators overbelast.
//! * [`Ord`] en [`PartialOrd`] zijn traits waarmee u respectievelijk totale en gedeeltelijke ordeningen tussen waarden kunt definiëren.
//!
//! Door ze te implementeren, worden de `<`-, `<=`-, `>`-en `>=`-operators overbelast.
//! * [`Ordering`] is een opsomming die wordt geretourneerd door de hoofdfuncties van [`Ord`] en [`PartialOrd`], en beschrijft een ordening.
//! * [`Reverse`] is een structuur waarmee u eenvoudig een volgorde kunt omkeren.
//! * [`max`] en [`min`] zijn functies die voortbouwen op [`Ord`] en waarmee u het maximum of minimum van twee waarden kunt vinden.
//!
//! Zie de respectieve documentatie van elk item in de lijst voor meer informatie.
//!
//! [`max`]: Ord::max
//! [`min`]: Ord::min
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use self::Ordering::*;

/// Trait voor gelijkheidsvergelijkingen die [partial equivalence relations](https://en.wikipedia.org/wiki/Partial_equivalence_relation) zijn.
///
/// Deze trait staat gedeeltelijke gelijkheid toe, voor typen die geen volledige equivalentierelatie hebben.
/// Bijvoorbeeld in drijvende-kommagetallen `NaN != NaN`, dus drijvende-kommatypen implementeren `PartialEq` maar niet [`trait@Eq`].
///
/// Formeel moet de gelijkheid zijn (voor alle `a`, `b`, `c` van het type `A`, `B`, `C`):
///
/// - **Symmetrisch**: als `A: PartialEq<B>` en `B: PartialEq<A>`, dan betekent **`a==b`` b==a`**;en
///
/// - **Overgankelijk**: als `A: PartialEq<B>` en `B: PartialEq<C>` en `A:
///   PartialEq<C>`, dan **` a==b`en `b == c` impliceert`a==c`**.
///
/// Merk op dat de `B: PartialEq<A>` (symmetric) en `A: PartialEq<C>` (transitive) impls niet gedwongen zijn te bestaan, maar deze vereisten zijn van toepassing wanneer ze bestaan.
///
/// ## Derivable
///
/// Deze trait kan gebruikt worden met `#[derive]`.Wanneer 'afgeleid' wordt op structs, zijn twee instanties gelijk als alle velden gelijk zijn, en niet gelijk als alle velden niet gelijk zijn.Wanneer 'afgeleid' wordt op enums, is elke variant gelijk aan zichzelf en niet gelijk aan de andere varianten.
///
/// ## Hoe kan ik `PartialEq` implementeren?
///
/// `PartialEq` vereist alleen dat de [`eq`]-methode wordt geïmplementeerd;[`ne`] wordt standaard in termen ervan gedefinieerd.Elke handmatige implementatie van [`ne`]*moet* de regel respecteren dat [`eq`] een strikte inverse is van [`ne`];dat wil zeggen, `!(a == b)` als en slechts als `a != b`.
///
/// Implementaties van `PartialEq`, [`PartialOrd`] en [`Ord`]*moeten* met elkaar overeenkomen.Het is gemakkelijk om ze per ongeluk oneens te maken door een deel van de traits af te leiden en andere handmatig te implementeren.
///
/// Een voorbeeldimplementatie voor een domein waarin twee boeken als hetzelfde boek worden beschouwd als hun ISBN-nummer overeenkomt, zelfs als de formaten verschillen:
///
/// ```
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// impl PartialEq for Book {
///     fn eq(&self, other: &Self) -> bool {
///         self.isbn == other.isbn
///     }
/// }
///
/// let b1 = Book { isbn: 3, format: BookFormat::Paperback };
/// let b2 = Book { isbn: 3, format: BookFormat::Ebook };
/// let b3 = Book { isbn: 10, format: BookFormat::Paperback };
///
/// assert!(b1 == b2);
/// assert!(b1 != b3);
/// ```
///
/// ## Hoe kan ik twee verschillende typen vergelijken?
///
/// Het type waarmee u kunt vergelijken wordt bepaald door de parameter type `PartialEq '.
/// Laten we bijvoorbeeld onze vorige code een beetje aanpassen:
///
/// ```
/// // Het leidt implementeert<BookFormat>==<BookFormat>vergelijkingen
/// #[derive(PartialEq)]
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// // Implementeren<Book>==<BookFormat>vergelijkingen
/// impl PartialEq<BookFormat> for Book {
///     fn eq(&self, other: &BookFormat) -> bool {
///         self.format == *other
///     }
/// }
///
/// // Implementeren<BookFormat>==<Book>vergelijkingen
/// impl PartialEq<Book> for BookFormat {
///     fn eq(&self, other: &Book) -> bool {
///         *self == other.format
///     }
/// }
///
/// let b1 = Book { isbn: 3, format: BookFormat::Paperback };
///
/// assert!(b1 == BookFormat::Paperback);
/// assert!(BookFormat::Ebook != b1);
/// ```
///
/// Door `impl PartialEq for Book` te veranderen in `impl PartialEq<BookFormat> for Book`, staan we toe dat `BookFormat`s worden vergeleken met`Book`s.
///
/// Een vergelijking zoals hierboven, waarbij sommige velden van de structuur worden genegeerd, kan gevaarlijk zijn.Het kan gemakkelijk leiden tot een onbedoelde schending van de vereisten voor een gedeeltelijke equivalentierelatie.
/// Als we bijvoorbeeld de bovenstaande implementatie van `PartialEq<Book>` voor `BookFormat` zouden behouden en een implementatie van `PartialEq<Book>` voor `Book` zouden toevoegen (ofwel via een `#[derive]` of via de handmatige implementatie uit het eerste voorbeeld), dan zou het resultaat de transitiviteit schenden:
///
///
/// ```should_panic
/// #[derive(PartialEq)]
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// #[derive(PartialEq)]
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// impl PartialEq<BookFormat> for Book {
///     fn eq(&self, other: &BookFormat) -> bool {
///         self.format == *other
///     }
/// }
///
/// impl PartialEq<Book> for BookFormat {
///     fn eq(&self, other: &Book) -> bool {
///         *self == other.format
///     }
/// }
///
/// fn main() {
///     let b1 = Book { isbn: 1, format: BookFormat::Paperback };
///     let b2 = Book { isbn: 2, format: BookFormat::Paperback };
///
///     assert!(b1 == BookFormat::Paperback);
///     assert!(BookFormat::Paperback == b2);
///
///     // The following should hold by transitivity but doesn't.
///     assert!(b1 == b2); // <-- PANICS
/// }
/// ```
///
/// # Examples
///
/// ```
/// let x: u32 = 0;
/// let y: u32 = 1;
///
/// assert_eq!(x == y, false);
/// assert_eq!(x.eq(&y), false);
/// ```
///
/// [`eq`]: PartialEq::eq
/// [`ne`]: PartialEq::ne
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "eq"]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = "==")]
#[doc(alias = "!=")]
#[rustc_on_unimplemented(
    message = "can't compare `{Self}` with `{Rhs}`",
    label = "no implementation for `{Self} == {Rhs}`"
)]
pub trait PartialEq<Rhs: ?Sized = Self> {
    /// Deze methode test of `self`-en `other`-waarden gelijk zijn, en wordt gebruikt door `==`.
    ///
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn eq(&self, other: &Rhs) -> bool;

    /// Deze methode test voor `!=`.
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn ne(&self, other: &Rhs) -> bool {
        !self.eq(other)
    }
}

/// Leid een macro af die een impl van de trait `PartialEq` genereert.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, structural_match)]
pub macro PartialEq($item:item) {
    /* compiler built-in */
}

/// Trait voor gelijkheidsvergelijkingen die [equivalence relations](https://en.wikipedia.org/wiki/Equivalence_relation) zijn.
///
/// Dit betekent dat, behalve dat `a == b` en `a != b` strikte invers zijn, de gelijkheid (voor alle `a`, `b` en `c`) moet zijn:
///
/// - reflexive: `a == a`;
/// - symmetrisch: `a == b` impliceert `b == a`;en
/// - transitief: `a == b` en `b == c` impliceert `a == c`.
///
/// Deze eigenschap kan niet worden gecontroleerd door de compiler, en daarom impliceert `Eq` [`PartialEq`] en heeft het geen extra methoden.
///
/// ## Derivable
///
/// Deze trait kan gebruikt worden met `#[derive]`.
/// Wanneer 'afgeleid' wordt, omdat `Eq` geen extra methoden heeft, informeert het de compiler alleen dat dit een equivalentierelatie is in plaats van een gedeeltelijke equivalentierelatie.
///
/// Merk op dat de `derive`-strategie vereist dat alle velden `Eq` zijn, wat niet altijd gewenst is.
///
/// ## Hoe kan ik `Eq` implementeren?
///
/// Als u de `derive`-strategie niet kunt gebruiken, specificeer dan dat uw type `Eq` implementeert, die geen methoden heeft:
///
/// ```
/// enum BookFormat { Paperback, Hardback, Ebook }
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
/// impl PartialEq for Book {
///     fn eq(&self, other: &Self) -> bool {
///         self.isbn == other.isbn
///     }
/// }
/// impl Eq for Book {}
/// ```
///
///
///
///
///
#[doc(alias = "==")]
#[doc(alias = "!=")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Eq: PartialEq<Self> {
    // deze methode wordt alleen gebruikt door#[afleiden] om te beweren dat elk onderdeel van een type#[afleiden] zelf implementeert, de huidige afleidende infrastructuur betekent dat deze bewering zonder een methode op deze trait bijna onmogelijk is.
    //
    //
    // Dit mag nooit met de hand worden uitgevoerd.
    //
    //
    //
    #[doc(hidden)]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn assert_receiver_is_total_eq(&self) {}
}

/// Leid een macro af die een impl van de trait `Eq` genereert.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_eq, structural_match)]
pub macro Eq($item:item) {
    /* compiler built-in */
}

// FIXME: deze structuur wordt uitsluitend gebruikt door#[afleiden] aan
// beweren dat elk onderdeel van een type Vgl.
//
// Deze structuur mag nooit in gebruikerscode verschijnen.
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(feature = "derive_eq", reason = "deriving hack, should not be public", issue = "none")]
pub struct AssertParamIsEq<T: Eq + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// Een `Ordering` is het resultaat van een vergelijking tussen twee waarden.
///
/// # Examples
///
/// ```
/// use std::cmp::Ordering;
///
/// let result = 1.cmp(&2);
/// assert_eq!(Ordering::Less, result);
///
/// let result = 1.cmp(&1);
/// assert_eq!(Ordering::Equal, result);
///
/// let result = 2.cmp(&1);
/// assert_eq!(Ordering::Greater, result);
/// ```
#[derive(Clone, Copy, PartialEq, Debug, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub enum Ordering {
    /// Een ordening waarbij een vergeleken waarde kleiner is dan een andere.
    #[stable(feature = "rust1", since = "1.0.0")]
    Less = -1,
    /// Een ordening waarbij een vergeleken waarde gelijk is aan een andere.
    #[stable(feature = "rust1", since = "1.0.0")]
    Equal = 0,
    /// Een ordening waarbij een vergeleken waarde groter is dan een andere.
    #[stable(feature = "rust1", since = "1.0.0")]
    Greater = 1,
}

impl Ordering {
    /// Retourneert `true` als de bestelling de `Equal`-variant is.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_eq(), false);
    /// assert_eq!(Ordering::Equal.is_eq(), true);
    /// assert_eq!(Ordering::Greater.is_eq(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_eq(self) -> bool {
        matches!(self, Equal)
    }

    /// Retourneert `true` als de bestelling niet de `Equal`-variant is.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_ne(), true);
    /// assert_eq!(Ordering::Equal.is_ne(), false);
    /// assert_eq!(Ordering::Greater.is_ne(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_ne(self) -> bool {
        !matches!(self, Equal)
    }

    /// Retourneert `true` als de bestelling de `Less`-variant is.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_lt(), true);
    /// assert_eq!(Ordering::Equal.is_lt(), false);
    /// assert_eq!(Ordering::Greater.is_lt(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_lt(self) -> bool {
        matches!(self, Less)
    }

    /// Retourneert `true` als de bestelling de `Greater`-variant is.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_gt(), false);
    /// assert_eq!(Ordering::Equal.is_gt(), false);
    /// assert_eq!(Ordering::Greater.is_gt(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_gt(self) -> bool {
        matches!(self, Greater)
    }

    /// Retourneert `true` als de bestelling de `Less`-of `Equal`-variant is.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_le(), true);
    /// assert_eq!(Ordering::Equal.is_le(), true);
    /// assert_eq!(Ordering::Greater.is_le(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_le(self) -> bool {
        !matches!(self, Greater)
    }

    /// Retourneert `true` als de bestelling de `Greater`-of `Equal`-variant is.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_ge(), false);
    /// assert_eq!(Ordering::Equal.is_ge(), true);
    /// assert_eq!(Ordering::Greater.is_ge(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_ge(self) -> bool {
        !matches!(self, Less)
    }

    /// Keert de `Ordering` om.
    ///
    /// * `Less` wordt `Greater`.
    /// * `Greater` wordt `Less`.
    /// * `Equal` wordt `Equal`.
    ///
    /// # Examples
    ///
    /// Basisgedrag:
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.reverse(), Ordering::Greater);
    /// assert_eq!(Ordering::Equal.reverse(), Ordering::Equal);
    /// assert_eq!(Ordering::Greater.reverse(), Ordering::Less);
    /// ```
    ///
    /// Deze methode kan worden gebruikt om een vergelijking om te keren:
    ///
    /// ```
    /// let data: &mut [_] = &mut [2, 10, 5, 8];
    ///
    /// // sorteer de array van groot naar klein.
    /// data.sort_by(|a, b| a.cmp(b).reverse());
    ///
    /// let b: &mut [_] = &mut [10, 8, 5, 2];
    /// assert!(data == b);
    /// ```
    #[inline]
    #[must_use]
    #[rustc_const_stable(feature = "const_ordering", since = "1.48.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn reverse(self) -> Ordering {
        match self {
            Less => Greater,
            Equal => Equal,
            Greater => Less,
        }
    }

    /// Ketens twee ordeningen.
    ///
    /// Retourneert `self` als het niet `Equal` is.Anders retourneert `other`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = Ordering::Equal.then(Ordering::Less);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then(Ordering::Equal);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then(Ordering::Greater);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Equal.then(Ordering::Equal);
    /// assert_eq!(result, Ordering::Equal);
    ///
    /// let x: (i64, i64, i64) = (1, 2, 7);
    /// let y: (i64, i64, i64) = (1, 5, 3);
    /// let result = x.0.cmp(&y.0).then(x.1.cmp(&y.1)).then(x.2.cmp(&y.2));
    ///
    /// assert_eq!(result, Ordering::Less);
    /// ```
    #[inline]
    #[must_use]
    #[rustc_const_stable(feature = "const_ordering", since = "1.48.0")]
    #[stable(feature = "ordering_chaining", since = "1.17.0")]
    pub const fn then(self, other: Ordering) -> Ordering {
        match self {
            Equal => other,
            _ => self,
        }
    }

    /// Keten de volgorde met de gegeven functie.
    ///
    /// Retourneert `self` als het geen `Equal` is.
    /// Roept anders `f` aan en retourneert het resultaat.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = Ordering::Equal.then_with(|| Ordering::Less);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then_with(|| Ordering::Equal);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then_with(|| Ordering::Greater);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Equal.then_with(|| Ordering::Equal);
    /// assert_eq!(result, Ordering::Equal);
    ///
    /// let x: (i64, i64, i64) = (1, 2, 7);
    /// let y: (i64, i64, i64) = (1, 5, 3);
    /// let result = x.0.cmp(&y.0).then_with(|| x.1.cmp(&y.1)).then_with(|| x.2.cmp(&y.2));
    ///
    /// assert_eq!(result, Ordering::Less);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "ordering_chaining", since = "1.17.0")]
    pub fn then_with<F: FnOnce() -> Ordering>(self, f: F) -> Ordering {
        match self {
            Equal => f(),
            _ => self,
        }
    }
}

/// Een hulpstructuur voor omgekeerde volgorde.
///
/// Deze structuur is een hulpmiddel voor gebruik met functies zoals [`Vec::sort_by_key`] en kan worden gebruikt om de volgorde van een deel van een sleutel om te keren.
///
///
/// [`Vec::sort_by_key`]: ../../std/vec/struct.Vec.html#method.sort_by_key
///
/// # Examples
///
/// ```
/// use std::cmp::Reverse;
///
/// let mut v = vec![1, 2, 3, 4, 5, 6];
/// v.sort_by_key(|&num| (num > 3, Reverse(num)));
/// assert_eq!(v, vec![3, 2, 1, 6, 5, 4]);
/// ```
#[derive(PartialEq, Eq, Debug, Copy, Clone, Default, Hash)]
#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
#[repr(transparent)]
pub struct Reverse<T>(#[stable(feature = "reverse_cmp_key", since = "1.19.0")] pub T);

#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
impl<T: PartialOrd> PartialOrd for Reverse<T> {
    #[inline]
    fn partial_cmp(&self, other: &Reverse<T>) -> Option<Ordering> {
        other.0.partial_cmp(&self.0)
    }

    #[inline]
    fn lt(&self, other: &Self) -> bool {
        other.0 < self.0
    }
    #[inline]
    fn le(&self, other: &Self) -> bool {
        other.0 <= self.0
    }
    #[inline]
    fn gt(&self, other: &Self) -> bool {
        other.0 > self.0
    }
    #[inline]
    fn ge(&self, other: &Self) -> bool {
        other.0 >= self.0
    }
}

#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
impl<T: Ord> Ord for Reverse<T> {
    #[inline]
    fn cmp(&self, other: &Reverse<T>) -> Ordering {
        other.0.cmp(&self.0)
    }
}

/// Trait voor typen die een [total order](https://en.wikipedia.org/wiki/Total_order) vormen.
///
/// Een bestelling is een totale bestelling als dit het geval is (voor alle `a`, `b` en `c`):
///
/// - totaal en asymmetrisch: precies een van `a < b`, `a == b` of `a > b` is waar;en
/// - transitief, `a < b` en `b < c` impliceert `a < c`.Hetzelfde moet gelden voor zowel `==` als `>`.
///
/// ## Derivable
///
/// Deze trait kan gebruikt worden met `#[derive]`.
/// Wanneer `afgeleid` wordt op structs, zal het een [lexicographic](https://en.wikipedia.org/wiki/Lexicographic_order)-ordening produceren op basis van de top-to-bottom declaratie-volgorde van de struct-leden.
///
/// Wanneer 'afgeleid' wordt van enums, worden varianten gesorteerd op hun discriminerende volgorde van boven naar beneden.
///
/// ## Lexicografische vergelijking
///
/// Lexicografische vergelijking is een bewerking met de volgende eigenschappen:
///  - Twee reeksen worden element voor element vergeleken.
///  - Het eerste niet-overeenkomende element definieert welke reeks lexicografisch kleiner of groter is dan de andere.
///  - Als de ene reeks een voorvoegsel is van een andere, is de kortere reeks lexicografisch minder dan de andere.
///  - Als twee reeksen equivalente elementen hebben en dezelfde lengte hebben, zijn de reeksen lexicografisch gelijk.
///  - Een lege reeks is lexicografisch minder dan een niet-lege reeks.
///  - Twee lege reeksen zijn lexicografisch gelijk.
///
/// ## Hoe kan ik `Ord` implementeren?
///
/// `Ord` vereist dat het type ook [`PartialOrd`] en [`Eq`] is (waarvoor [`PartialEq`] vereist is).
///
/// Dan moet u een implementatie voor [`cmp`] definiëren.Misschien vindt u het handig om [`cmp`] te gebruiken in de velden van uw type.
///
/// Implementaties van [`PartialEq`], [`PartialOrd`] en `Ord`*moeten* met elkaar overeenkomen.
/// Dat wil zeggen, `a.cmp(b) == Ordering::Equal` als en slechts als `a == b` en `Some(a.cmp(b)) == a.partial_cmp(b)` voor alle `a` en `b`.
/// Het is gemakkelijk om ze per ongeluk oneens te maken door een deel van de traits af te leiden en andere handmatig te implementeren.
///
/// Hier is een voorbeeld waarin u mensen alleen op lengte wilt sorteren, zonder rekening te houden met `id` en `name`:
///
/// ```
/// use std::cmp::Ordering;
///
/// #[derive(Eq)]
/// struct Person {
///     id: u32,
///     name: String,
///     height: u32,
/// }
///
/// impl Ord for Person {
///     fn cmp(&self, other: &Self) -> Ordering {
///         self.height.cmp(&other.height)
///     }
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         Some(self.cmp(other))
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// [`cmp`]: Ord::cmp
///
///
///
#[doc(alias = "<")]
#[doc(alias = ">")]
#[doc(alias = "<=")]
#[doc(alias = ">=")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Ord: Eq + PartialOrd<Self> {
    /// Deze methode retourneert een [`Ordering`] tussen `self` en `other`.
    ///
    /// Volgens afspraak retourneert `self.cmp(&other)` de volgorde die overeenkomt met de uitdrukking `self <operator> other` indien waar.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(5.cmp(&10), Ordering::Less);
    /// assert_eq!(10.cmp(&5), Ordering::Greater);
    /// assert_eq!(5.cmp(&5), Ordering::Equal);
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn cmp(&self, other: &Self) -> Ordering;

    /// Vergelijkt en retourneert het maximum van twee waarden.
    ///
    /// Retourneert het tweede argument als de vergelijking bepaalt dat ze gelijk zijn.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(2, 1.max(2));
    /// assert_eq!(2, 2.max(2));
    /// ```
    #[stable(feature = "ord_max_min", since = "1.21.0")]
    #[inline]
    #[must_use]
    fn max(self, other: Self) -> Self
    where
        Self: Sized,
    {
        max_by(self, other, Ord::cmp)
    }

    /// Vergelijkt en retourneert het minimum van twee waarden.
    ///
    /// Retourneert het eerste argument als de vergelijking bepaalt dat ze gelijk zijn.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(1, 1.min(2));
    /// assert_eq!(2, 2.min(2));
    /// ```
    #[stable(feature = "ord_max_min", since = "1.21.0")]
    #[inline]
    #[must_use]
    fn min(self, other: Self) -> Self
    where
        Self: Sized,
    {
        min_by(self, other, Ord::cmp)
    }

    /// Beperk een waarde tot een bepaald interval.
    ///
    /// Retourneert `max` als `self` groter is dan `max`, en `min` als `self` kleiner is dan `min`.
    /// Anders retourneert dit `self`.
    ///
    /// # Panics
    ///
    /// Panics als `min > max`.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!((-3).clamp(-2, 1) == -2);
    /// assert!(0.clamp(-2, 1) == 0);
    /// assert!(2.clamp(-2, 1) == 1);
    /// ```
    #[must_use]
    #[stable(feature = "clamp", since = "1.50.0")]
    fn clamp(self, min: Self, max: Self) -> Self
    where
        Self: Sized,
    {
        assert!(min <= max);
        if self < min {
            min
        } else if self > max {
            max
        } else {
            self
        }
    }
}

/// Leid een macro af die een impl van de trait `Ord` genereert.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics)]
pub macro Ord($item:item) {
    /* compiler built-in */
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Eq for Ordering {}

#[stable(feature = "rust1", since = "1.0.0")]
impl Ord for Ordering {
    #[inline]
    fn cmp(&self, other: &Ordering) -> Ordering {
        (*self as i32).cmp(&(*other as i32))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialOrd for Ordering {
    #[inline]
    fn partial_cmp(&self, other: &Ordering) -> Option<Ordering> {
        (*self as i32).partial_cmp(&(*other as i32))
    }
}

/// Trait voor waarden die kunnen worden vergeleken voor een sorteervolgorde.
///
/// De vergelijking moet voor alle `a`, `b` en `c` voldoen aan:
///
/// - asymmetrie: als `a < b` dan `!(a > b)`, evenals `a > b` die `!(a < b)` impliceert;en
/// - transitiviteit: `a < b` en `b < c` impliceert `a < c`.Hetzelfde moet gelden voor zowel `==` als `>`.
///
/// Merk op dat deze vereisten betekenen dat de trait zelf symmetrisch en transitief moet worden geïmplementeerd: als `T: PartialOrd<U>` en `U: PartialOrd<V>` dan `U: PartialOrd<T>` en `T:
///
/// PartialOrd<V>`.
///
/// ## Derivable
///
/// Deze trait kan gebruikt worden met `#[derive]`.Wanneer `afgeleid` wordt op structs, zal het een lexicografische ordening produceren op basis van de van boven naar beneden aangiftevolgorde van de leden van de struct.
/// Wanneer 'afgeleid' wordt van enums, worden varianten gesorteerd op hun discriminerende volgorde van boven naar beneden.
///
/// ## Hoe kan ik `PartialOrd` implementeren?
///
/// `PartialOrd` vereist alleen implementatie van de [`partial_cmp`]-methode, terwijl de andere worden gegenereerd op basis van standaardimplementaties.
///
/// Het blijft echter mogelijk om de andere afzonderlijk te implementeren voor typen die geen totale bestelling hebben.
/// Bijvoorbeeld, voor getallen met drijvende komma, `NaN < 0 == false` en `NaN >= 0 == false` (cf.
/// IEEE 754-2008 sectie 5.11).
///
/// `PartialOrd` vereist dat uw type [`PartialEq`] is.
///
/// Implementaties van [`PartialEq`], `PartialOrd` en [`Ord`]*moeten* met elkaar overeenkomen.
/// Het is gemakkelijk om ze per ongeluk oneens te maken door een deel van de traits af te leiden en andere handmatig te implementeren.
///
/// Als uw type [`Ord`] is, kunt u [`partial_cmp`] implementeren door [`cmp`] te gebruiken:
///
/// ```
/// use std::cmp::Ordering;
///
/// #[derive(Eq)]
/// struct Person {
///     id: u32,
///     name: String,
///     height: u32,
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         Some(self.cmp(other))
///     }
/// }
///
/// impl Ord for Person {
///     fn cmp(&self, other: &Self) -> Ordering {
///         self.height.cmp(&other.height)
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// Mogelijk vindt u het ook handig om [`partial_cmp`] te gebruiken in de velden van uw type.
/// Hier is een voorbeeld van `Person`-typen die een `height`-veld met drijvende komma hebben dat het enige veld is dat wordt gebruikt voor het sorteren:
///
/// ```
/// use std::cmp::Ordering;
///
/// struct Person {
///     id: u32,
///     name: String,
///     height: f64,
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         self.height.partial_cmp(&other.height)
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// # Examples
///
/// ```
/// let x : u32 = 0;
/// let y : u32 = 1;
///
/// assert_eq!(x < y, true);
/// assert_eq!(x.lt(&y), true);
/// ```
///
/// [`partial_cmp`]: PartialOrd::partial_cmp
/// [`cmp`]: Ord::cmp
///
///
///
///
#[lang = "partial_ord"]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = ">")]
#[doc(alias = "<")]
#[doc(alias = "<=")]
#[doc(alias = ">=")]
#[rustc_on_unimplemented(
    message = "can't compare `{Self}` with `{Rhs}`",
    label = "no implementation for `{Self} < {Rhs}` and `{Self} > {Rhs}`"
)]
pub trait PartialOrd<Rhs: ?Sized = Self>: PartialEq<Rhs> {
    /// Deze methode retourneert een volgorde tussen `self`-en `other`-waarden als die bestaat.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = 1.0.partial_cmp(&2.0);
    /// assert_eq!(result, Some(Ordering::Less));
    ///
    /// let result = 1.0.partial_cmp(&1.0);
    /// assert_eq!(result, Some(Ordering::Equal));
    ///
    /// let result = 2.0.partial_cmp(&1.0);
    /// assert_eq!(result, Some(Ordering::Greater));
    /// ```
    ///
    /// Als vergelijking onmogelijk is:
    ///
    /// ```
    /// let result = f64::NAN.partial_cmp(&1.0);
    /// assert_eq!(result, None);
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn partial_cmp(&self, other: &Rhs) -> Option<Ordering>;

    /// Deze methode test minder dan (voor `self` en `other`) en wordt gebruikt door de `<`-operator.
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 < 2.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 < 1.0;
    /// assert_eq!(result, false);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn lt(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Less))
    }

    /// Deze methode test kleiner dan of gelijk aan (voor `self` en `other`) en wordt gebruikt door de `<=`-operator.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 <= 2.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 <= 2.0;
    /// assert_eq!(result, true);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn le(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Less | Equal))
    }

    /// Deze methode test groter dan (voor `self` en `other`) en wordt gebruikt door de `>`-operator.
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 > 2.0;
    /// assert_eq!(result, false);
    ///
    /// let result = 2.0 > 2.0;
    /// assert_eq!(result, false);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn gt(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Greater))
    }

    /// Deze methode test groter dan of gelijk aan (voor `self` en `other`) en wordt gebruikt door de `>=`-operator.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 2.0 >= 1.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 >= 2.0;
    /// assert_eq!(result, true);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn ge(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Greater | Equal))
    }
}

/// Leid een macro af die een impl van de trait `PartialOrd` genereert.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics)]
pub macro PartialOrd($item:item) {
    /* compiler built-in */
}

/// Vergelijkt en retourneert het minimum van twee waarden.
///
/// Retourneert het eerste argument als de vergelijking bepaalt dat ze gelijk zijn.
///
/// Gebruikt intern een alias voor [`Ord::min`].
///
/// # Examples
///
/// ```
/// use std::cmp;
///
/// assert_eq!(1, cmp::min(1, 2));
/// assert_eq!(2, cmp::min(2, 2));
/// ```
#[inline]
#[must_use]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn min<T: Ord>(v1: T, v2: T) -> T {
    v1.min(v2)
}

/// Retourneert het minimum van twee waarden met betrekking tot de opgegeven vergelijkingsfunctie.
///
/// Retourneert het eerste argument als de vergelijking bepaalt dat ze gelijk zijn.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::min_by(-2, 1, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), 1);
/// assert_eq!(cmp::min_by(-2, 2, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), -2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn min_by<T, F: FnOnce(&T, &T) -> Ordering>(v1: T, v2: T, compare: F) -> T {
    match compare(&v1, &v2) {
        Ordering::Less | Ordering::Equal => v1,
        Ordering::Greater => v2,
    }
}

/// Retourneert het element dat de minimumwaarde van de opgegeven functie geeft.
///
/// Retourneert het eerste argument als de vergelijking bepaalt dat ze gelijk zijn.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::min_by_key(-2, 1, |x: &i32| x.abs()), 1);
/// assert_eq!(cmp::min_by_key(-2, 2, |x: &i32| x.abs()), -2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn min_by_key<T, F: FnMut(&T) -> K, K: Ord>(v1: T, v2: T, mut f: F) -> T {
    min_by(v1, v2, |v1, v2| f(v1).cmp(&f(v2)))
}

/// Vergelijkt en retourneert het maximum van twee waarden.
///
/// Retourneert het tweede argument als de vergelijking bepaalt dat ze gelijk zijn.
///
/// Gebruikt intern een alias voor [`Ord::max`].
///
/// # Examples
///
/// ```
/// use std::cmp;
///
/// assert_eq!(2, cmp::max(1, 2));
/// assert_eq!(2, cmp::max(2, 2));
/// ```
#[inline]
#[must_use]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn max<T: Ord>(v1: T, v2: T) -> T {
    v1.max(v2)
}

/// Retourneert het maximum van twee waarden met betrekking tot de opgegeven vergelijkingsfunctie.
///
/// Retourneert het tweede argument als de vergelijking bepaalt dat ze gelijk zijn.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::max_by(-2, 1, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), -2);
/// assert_eq!(cmp::max_by(-2, 2, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), 2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn max_by<T, F: FnOnce(&T, &T) -> Ordering>(v1: T, v2: T, compare: F) -> T {
    match compare(&v1, &v2) {
        Ordering::Less | Ordering::Equal => v2,
        Ordering::Greater => v1,
    }
}

/// Retourneert het element dat de maximale waarde van de opgegeven functie geeft.
///
/// Retourneert het tweede argument als de vergelijking bepaalt dat ze gelijk zijn.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::max_by_key(-2, 1, |x: &i32| x.abs()), -2);
/// assert_eq!(cmp::max_by_key(-2, 2, |x: &i32| x.abs()), 2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn max_by_key<T, F: FnMut(&T) -> K, K: Ord>(v1: T, v2: T, mut f: F) -> T {
    max_by(v1, v2, |v1, v2| f(v1).cmp(&f(v2)))
}

// Implementatie van PartialEq, Eq, PartialOrd en Ord voor primitieve typen
mod impls {
    use crate::cmp::Ordering::{self, Equal, Greater, Less};
    use crate::hint::unreachable_unchecked;

    macro_rules! partial_eq_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialEq for $t {
                #[inline]
                fn eq(&self, other: &$t) -> bool { (*self) == (*other) }
                #[inline]
                fn ne(&self, other: &$t) -> bool { (*self) != (*other) }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialEq for () {
        #[inline]
        fn eq(&self, _other: &()) -> bool {
            true
        }
        #[inline]
        fn ne(&self, _other: &()) -> bool {
            false
        }
    }

    partial_eq_impl! {
        bool char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 f32 f64
    }

    macro_rules! eq_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl Eq for $t {}
        )*)
    }

    eq_impl! { () bool char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 }

    macro_rules! partial_ord_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialOrd for $t {
                #[inline]
                fn partial_cmp(&self, other: &$t) -> Option<Ordering> {
                    match (self <= other, self >= other) {
                        (false, false) => None,
                        (false, true) => Some(Greater),
                        (true, false) => Some(Less),
                        (true, true) => Some(Equal),
                    }
                }
                #[inline]
                fn lt(&self, other: &$t) -> bool { (*self) < (*other) }
                #[inline]
                fn le(&self, other: &$t) -> bool { (*self) <= (*other) }
                #[inline]
                fn ge(&self, other: &$t) -> bool { (*self) >= (*other) }
                #[inline]
                fn gt(&self, other: &$t) -> bool { (*self) > (*other) }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialOrd for () {
        #[inline]
        fn partial_cmp(&self, _: &()) -> Option<Ordering> {
            Some(Equal)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialOrd for bool {
        #[inline]
        fn partial_cmp(&self, other: &bool) -> Option<Ordering> {
            Some(self.cmp(other))
        }
    }

    partial_ord_impl! { f32 f64 }

    macro_rules! ord_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialOrd for $t {
                #[inline]
                fn partial_cmp(&self, other: &$t) -> Option<Ordering> {
                    Some(self.cmp(other))
                }
                #[inline]
                fn lt(&self, other: &$t) -> bool { (*self) < (*other) }
                #[inline]
                fn le(&self, other: &$t) -> bool { (*self) <= (*other) }
                #[inline]
                fn ge(&self, other: &$t) -> bool { (*self) >= (*other) }
                #[inline]
                fn gt(&self, other: &$t) -> bool { (*self) > (*other) }
            }

            #[stable(feature = "rust1", since = "1.0.0")]
            impl Ord for $t {
                #[inline]
                fn cmp(&self, other: &$t) -> Ordering {
                    // De volgorde hier is belangrijk om een meer optimale montage te genereren.
                    // Zie <https://github.com/rust-lang/rust/issues/63758> voor meer informatie.
                    if *self < *other { Less }
                    else if *self == *other { Equal }
                    else { Greater }
                }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl Ord for () {
        #[inline]
        fn cmp(&self, _other: &()) -> Ordering {
            Equal
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl Ord for bool {
        #[inline]
        fn cmp(&self, other: &bool) -> Ordering {
            // Gieten naar i8's en het verschil omzetten in een bestelling genereert een meer optimale montage.
            //
            // Zie <https://github.com/rust-lang/rust/issues/66780> voor meer informatie.
            match (*self as i8) - (*other as i8) {
                -1 => Less,
                0 => Equal,
                1 => Greater,
                // VEILIGHEID: bool omdat i8 0 of 1 retourneert, dus het verschil kan niets anders zijn
                _ => unsafe { unreachable_unchecked() },
            }
        }
    }

    ord_impl! { char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 }

    #[unstable(feature = "never_type", issue = "35121")]
    impl PartialEq for ! {
        fn eq(&self, _: &!) -> bool {
            *self
        }
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Eq for ! {}

    #[unstable(feature = "never_type", issue = "35121")]
    impl PartialOrd for ! {
        fn partial_cmp(&self, _: &!) -> Option<Ordering> {
            *self
        }
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Ord for ! {
        fn cmp(&self, _: &!) -> Ordering {
            *self
        }
    }

    // &aanwijzingen

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&B> for &A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialOrd<&B> for &A
    where
        A: PartialOrd<B>,
    {
        #[inline]
        fn partial_cmp(&self, other: &&B) -> Option<Ordering> {
            PartialOrd::partial_cmp(*self, *other)
        }
        #[inline]
        fn lt(&self, other: &&B) -> bool {
            PartialOrd::lt(*self, *other)
        }
        #[inline]
        fn le(&self, other: &&B) -> bool {
            PartialOrd::le(*self, *other)
        }
        #[inline]
        fn gt(&self, other: &&B) -> bool {
            PartialOrd::gt(*self, *other)
        }
        #[inline]
        fn ge(&self, other: &&B) -> bool {
            PartialOrd::ge(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Ord for &A
    where
        A: Ord,
    {
        #[inline]
        fn cmp(&self, other: &Self) -> Ordering {
            Ord::cmp(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Eq for &A where A: Eq {}

    // &mut pointers

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&mut B> for &mut A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&mut B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&mut B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialOrd<&mut B> for &mut A
    where
        A: PartialOrd<B>,
    {
        #[inline]
        fn partial_cmp(&self, other: &&mut B) -> Option<Ordering> {
            PartialOrd::partial_cmp(*self, *other)
        }
        #[inline]
        fn lt(&self, other: &&mut B) -> bool {
            PartialOrd::lt(*self, *other)
        }
        #[inline]
        fn le(&self, other: &&mut B) -> bool {
            PartialOrd::le(*self, *other)
        }
        #[inline]
        fn gt(&self, other: &&mut B) -> bool {
            PartialOrd::gt(*self, *other)
        }
        #[inline]
        fn ge(&self, other: &&mut B) -> bool {
            PartialOrd::ge(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Ord for &mut A
    where
        A: Ord,
    {
        #[inline]
        fn cmp(&self, other: &Self) -> Ordering {
            Ord::cmp(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Eq for &mut A where A: Eq {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&mut B> for &A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&mut B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&mut B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&B> for &mut A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
}