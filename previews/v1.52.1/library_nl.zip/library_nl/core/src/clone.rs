//! De `Clone` trait voor typen die niet 'impliciet gekopieerd' kunnen worden.
//!
//! In Rust zijn sommige eenvoudige typen "implicitly copyable" en wanneer u ze toewijst of als argumenten doorgeeft, krijgt de ontvanger een kopie, waarbij de oorspronkelijke waarde op zijn plaats blijft.
//! Deze typen hebben geen toewijzing nodig om te kopiëren en hebben geen finalizers (dwz ze bevatten geen boxen in eigendom of implementeren [`Drop`]), dus de compiler beschouwt ze als goedkoop en veilig om te kopiëren.
//!
//! Voor andere typen moeten expliciet kopieën worden gemaakt, volgens afspraak de [`Clone`] trait implementeren en de [`clone`]-methode aanroepen.
//!
//! [`clone`]: Clone::clone
//!
//! Basis gebruiksvoorbeeld:
//!
//! ```
//! let s = String::new(); // String-type implementeert Clone
//! let copy = s.clone(); // zodat we het kunnen klonen
//! ```
//!
//! Om de Clone trait gemakkelijk te implementeren, kunt u ook `#[derive(Clone)]` gebruiken.Voorbeeld:
//!
//! ```
//! #[derive(Clone)] // we voegen de kloon trait toe aan de Morpheus-structuur
//! struct Morpheus {
//!    blue_pill: f32,
//!    red_pill: i64,
//! }
//!
//! fn main() {
//!    let f = Morpheus { blue_pill: 0.0, red_pill: 0 };
//!    let copy = f.clone(); // en nu kunnen we het klonen!
//! }
//! ```
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

/// Een veel voorkomende trait voor de mogelijkheid om een object expliciet te dupliceren.
///
/// Verschilt van [`Copy`] doordat [`Copy`] impliciet en extreem goedkoop is, terwijl `Clone` altijd expliciet is en al dan niet duur is.
/// Om deze kenmerken af te dwingen, staat Rust u niet toe om [`Copy`] opnieuw te implementeren, maar u mag `Clone` opnieuw implementeren en willekeurige code uitvoeren.
///
/// Aangezien `Clone` algemener is dan [`Copy`], kunt u automatisch ook alles [`Copy`] `Clone` maken.
///
/// ## Derivable
///
/// Deze trait kan worden gebruikt met `#[derive]` als alle velden `Clone` zijn.De `afgeleide` implementatie van [`Clone`] roept [`clone`] op elk veld aan.
///
/// [`clone`]: Clone::clone
///
/// Voor een generieke structuur implementeert `#[derive]` `Clone` voorwaardelijk door gebonden `Clone` toe te voegen aan generieke parameters.
///
/// ```
/// // `derive` implementeert Clone for Reading<T>wanneer T is Clone.
/// #[derive(Clone)]
/// struct Reading<T> {
///     frequency: T,
/// }
/// ```
///
/// ## Hoe kan ik `Clone` implementeren?
///
/// Typen die [`Copy`] zijn, zouden een triviale implementatie van `Clone` moeten hebben.Meer formeel:
/// als `T: Copy`, `x: T` en `y: &T`, dan is `let x = y.clone();` equivalent aan `let x = *y;`.
/// Handmatige implementaties moeten ervoor zorgen dat deze invariant gehandhaafd blijft;onveilige code mag er echter niet op vertrouwen om de geheugenveiligheid te garanderen.
///
/// Een voorbeeld is een generieke structuur met een functieaanwijzer.In dit geval kan de implementatie van `Clone` niet worden 'afgeleid', maar kan deze worden geïmplementeerd als:
///
/// ```
/// struct Generate<T>(fn() -> T);
///
/// impl<T> Copy for Generate<T> {}
///
/// impl<T> Clone for Generate<T> {
///     fn clone(&self) -> Self {
///         *self
///     }
/// }
/// ```
///
/// ## Extra uitvoerders
///
/// Naast de [implementors listed below][impls] implementeren de volgende typen ook `Clone`:
///
/// * Functie-itemtypen (dwz de verschillende typen die voor elke functie zijn gedefinieerd)
/// * Functieaanwijzertypen (bijv. `fn() -> i32`)
/// * Array-typen, voor alle formaten, als het itemtype ook `Clone` implementeert (bijvoorbeeld `[i32; 123456]`)
/// * Tuple-typen, als elke component ook `Clone` implementeert (bijv.`()`, `(i32, bool)`)
/// * Sluitingstypen, als ze geen waarde uit de omgeving halen of als al dergelijke vastgelegde waarden `Clone` zelf implementeren.
///   Merk op dat variabelen die zijn vastgelegd door gedeelde referentie altijd `Clone` implementeren (zelfs als de referent dat niet doet), terwijl variabelen die zijn vastgelegd door veranderlijke referentie nooit `Clone` implementeren.
///
///
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "clone"]
#[rustc_diagnostic_item = "Clone"]
pub trait Clone: Sized {
    /// Retourneert een kopie van de waarde.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(noop_method_call)]
    /// let hello = "Hello"; // &str implementeert Clone
    ///
    /// assert_eq!("Hello", hello.clone());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "cloning is often expensive and is not expected to have side effects"]
    fn clone(&self) -> Self;

    /// Voert kopieeropdrachten uit vanaf `source`.
    ///
    /// `a.clone_from(&b)` is equivalent aan `a = b.clone()` in functionaliteit, maar kan worden overschreven om de bronnen van `a` opnieuw te gebruiken om onnodige toewijzingen te voorkomen.
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn clone_from(&mut self, source: &Self) {
        *self = source.clone()
    }
}

/// Leid een macro af die een impl van de trait `Clone` genereert.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Clone($item:item) {
    /* compiler built-in */
}

// FIXME(aburka): deze structuren worden uitsluitend gebruikt door#[afgeleid] om te beweren dat elke component van een type Clone of Copy implementeert.
//
//
// Deze structuren mogen nooit in gebruikerscode verschijnen.
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsClone<T: Clone + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsCopy<T: Copy + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// Implementaties van `Clone` voor primitieve typen.
///
/// Implementaties die niet kunnen worden beschreven in Rust worden geïmplementeerd in `traits::SelectionContext::copy_clone_conditions()` in `rustc_trait_selection`.
///
///
mod impls {

    use super::Clone;

    macro_rules! impl_clone {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Clone for $t {
                    #[inline]
                    fn clone(&self) -> Self {
                        *self
                    }
                }
            )*
        }
    }

    impl_clone! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Clone for ! {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *const T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *mut T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// Gedeelde referenties kunnen worden gekloond, maar veranderlijke referenties *kunnen niet*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for &T {
        #[inline]
        #[rustc_diagnostic_item = "noop_method_clone"]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// Gedeelde referenties kunnen worden gekloond, maar veranderlijke referenties *kunnen niet*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> !Clone for &mut T {}
}