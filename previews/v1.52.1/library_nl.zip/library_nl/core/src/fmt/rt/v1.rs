//! Dit is een interne module die wordt gebruikt door de ifmt!looptijd.Deze structuren worden naar statische arrays verzonden om formaatreeksen van tevoren te precompileren.
//!
//! Deze definities zijn vergelijkbaar met hun `ct`-equivalenten, maar verschillen doordat deze statisch kunnen worden toegewezen en enigszins zijn geoptimaliseerd voor de runtime
//!
//!
#![allow(missing_debug_implementations)]

#[derive(Copy, Clone)]
pub struct Argument {
    pub position: usize,
    pub format: FormatSpec,
}

#[derive(Copy, Clone)]
pub struct FormatSpec {
    pub fill: char,
    pub align: Alignment,
    pub flags: u32,
    pub precision: Count,
    pub width: Count,
}

/// Mogelijke uitlijningen die kunnen worden aangevraagd als onderdeel van een opmaakrichtlijn.
#[derive(Copy, Clone, PartialEq, Eq)]
pub enum Alignment {
    /// Indicatie dat de inhoud links uitgelijnd moet zijn.
    Left,
    /// Indicatie dat de inhoud rechts uitgelijnd moet zijn.
    Right,
    /// Indicatie dat de inhoud in het midden moet worden uitgelijnd.
    Center,
    /// Er is geen uitlijning aangevraagd.
    Unknown,
}

/// Gebruikt door [width](https://doc.rust-lang.org/std/fmt/#width)-en [precision](https://doc.rust-lang.org/std/fmt/#precision)-voorschrijvers.
#[derive(Copy, Clone)]
pub enum Count {
    /// Opgegeven met een letterlijk getal, slaat de waarde op
    Is(usize),
    /// Gespecificeerd met behulp van `$`-en `*`-syntaxis, slaat de index op in `args`
    Param(usize),
    /// Niet gespecificeerd
    Implied,
}