/// Een trait voor het aanpassen van het gedrag van de `?`-operator.
///
/// Een type dat `Try` implementeert, is er een dat een canonieke manier heeft om het te bekijken in termen van een success/failure-dichotomie.
/// Deze trait maakt het mogelijk om zowel die succes-of foutwaarden uit een bestaande instantie te extraheren als een nieuwe instantie te maken op basis van een succes-of mislukkingswaarde.
///
///
#[unstable(feature = "try_trait", issue = "42327")]
#[rustc_on_unimplemented(
    on(
        all(
            any(from_method = "from_error", from_method = "from_ok"),
            from_desugaring = "QuestionMark"
        ),
        message = "the `?` operator can only be used in {ItemContext} \
                    that returns `Result` or `Option` \
                    (or another type that implements `{Try}`)",
        label = "cannot use the `?` operator in {ItemContext} that returns `{Self}`",
        enclosing_scope = "this function should return `Result` or `Option` to accept `?`"
    ),
    on(
        all(from_method = "into_result", from_desugaring = "QuestionMark"),
        message = "the `?` operator can only be applied to values \
                    that implement `{Try}`",
        label = "the `?` operator cannot be applied to type `{Self}`"
    )
)]
#[doc(alias = "?")]
#[lang = "try"]
pub trait Try {
    /// Het type van deze waarde wanneer deze als succesvol wordt beschouwd.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Ok;
    /// Het type van deze waarde wanneer het wordt gezien als mislukt.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Error;

    /// Past de "?"-operator toe.Een terugkeer van `Ok(t)` betekent dat de uitvoering normaal moet worden voortgezet, en het resultaat van `?` is de waarde `t`.
    /// Een terugkeer van `Err(e)` betekent dat de uitvoering moet branch naar de binnenste omhullende `catch`, of terugkeren van de functie.
    ///
    /// Als een `Err(e)`-resultaat wordt geretourneerd, is de waarde `e` "wrapped" in het retourtype van de omsluitende scope (die zelf `Try` moet implementeren).
    ///
    /// In het bijzonder wordt de waarde `X::from_error(From::from(e))` geretourneerd, waarbij `X` het retourneringstype is van de omsluitende functie.
    ///
    ///
    ///
    #[lang = "into_result"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn into_result(self) -> Result<Self::Ok, Self::Error>;

    /// Wikkel een foutwaarde om het samengestelde resultaat te construeren.
    /// `Result::Err(x)` en `Result::from_error(x)` zijn bijvoorbeeld equivalent.
    #[lang = "from_error"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_error(v: Self::Error) -> Self;

    /// Wikkel een OK-waarde om het samengestelde resultaat te construeren.
    /// `Result::Ok(x)` en `Result::from_ok(x)` zijn bijvoorbeeld equivalent.
    #[lang = "from_ok"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_ok(v: Self::Ok) -> Self;
}