/// De versie van de oproepoperator die een onveranderlijke ontvanger neemt.
///
/// Instanties van `Fn` kunnen herhaaldelijk worden aangeroepen zonder de status te muteren.
///
/// *Deze trait (`Fn`) is niet te verwarren met [function pointers] (`fn`).*
///
/// `Fn` wordt automatisch geïmplementeerd door afsluitingen die alleen onveranderlijke verwijzingen naar vastgelegde variabelen aannemen of helemaal niets vastleggen, evenals (safe) [function pointers] (met enkele voorbehouden, zie hun documentatie voor meer details).
///
/// Bovendien, voor elk type `F` dat `Fn` implementeert, implementeert `&F` ook `Fn`.
///
/// Omdat zowel [`FnMut`] als [`FnOnce`] supertraits zijn van `Fn`, kan elk exemplaar van `Fn` worden gebruikt als een parameter waar een [`FnMut`] of [`FnOnce`] wordt verwacht.
///
/// Gebruik `Fn` als een bound wanneer u een parameter van een functieachtig type wilt accepteren en deze herhaaldelijk en zonder mutatiestatus moet aanroepen (bijv. Wanneer u deze gelijktijdig aanroept).
/// Als u dergelijke strikte vereisten niet nodig heeft, gebruik dan [`FnMut`] of [`FnOnce`] als grenzen.
///
/// Zie de [chapter on closures in *The Rust Programming Language*][book] voor meer informatie over dit onderwerp.
///
/// Ook opmerkelijk is de speciale syntaxis voor `Fn` traits (bijv
/// `Fn(usize, bool) -> usize`).Wie geïnteresseerd is in de technische details hiervan, kan verwijzen naar [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Een afsluiting bellen
///
/// ```
/// let square = |x| x * x;
/// assert_eq!(square(5), 25);
/// ```
///
/// ## Met behulp van een `Fn`-parameter
///
/// ```
/// fn call_with_one<F>(func: F) -> usize
///     where F: Fn(usize) -> usize {
///     func(1)
/// }
///
/// let double = |x| x * 2;
/// assert_eq!(call_with_one(double), 2);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{Fn}<{Args}>` closure, found `{Self}`",
    label = "expected an `Fn<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // zodat regex erop kan vertrouwen dat `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait Fn<Args>: FnMut<Args> {
    /// Voert de oproepbewerking uit.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call(&self, args: Args) -> Self::Output;
}

/// De versie van de oproepoperator die een veranderlijke ontvanger nodig heeft.
///
/// Instanties van `FnMut` kunnen herhaaldelijk worden aangeroepen en kunnen de status muteren.
///
/// `FnMut` wordt automatisch geïmplementeerd door middel van sluitingen die veranderlijke verwijzingen naar vastgelegde variabelen accepteren, evenals alle typen die [`Fn`] implementeren, bijvoorbeeld (safe) [function pointers] (aangezien `FnMut` een superieur is van [`Fn`]).
/// Bovendien implementeert `&mut F` voor elk type `F` dat `FnMut` implementeert, ook `FnMut`.
///
/// Omdat [`FnOnce`] een supertrait is van `FnMut`, kan elke instantie van `FnMut` worden gebruikt waar een [`FnOnce`] wordt verwacht, en aangezien [`Fn`] een substraat is van `FnMut`, kan elke instantie van [`Fn`] worden gebruikt waar `FnMut` wordt verwacht.
///
/// Gebruik `FnMut` als een grens als u een parameter van het functieachtige type wilt accepteren en deze herhaaldelijk moet aanroepen, terwijl u hem toestaat de status te muteren.
/// Als u niet wilt dat de parameter de status muteert, gebruikt u [`Fn`] als een grens;als je het niet herhaaldelijk hoeft te bellen, gebruik dan [`FnOnce`].
///
/// Zie de [chapter on closures in *The Rust Programming Language*][book] voor meer informatie over dit onderwerp.
///
/// Ook opmerkelijk is de speciale syntaxis voor `Fn` traits (bijv
/// `Fn(usize, bool) -> usize`).Wie geïnteresseerd is in de technische details hiervan, kan verwijzen naar [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Roep een veranderlijk vastleggende sluiting op
///
/// ```
/// let mut x = 5;
/// {
///     let mut square_x = || x *= x;
///     square_x();
/// }
/// assert_eq!(x, 25);
/// ```
///
/// ## Met behulp van een `FnMut`-parameter
///
/// ```
/// fn do_twice<F>(mut func: F)
///     where F: FnMut()
/// {
///     func();
///     func();
/// }
///
/// let mut x: usize = 1;
/// {
///     let add_two_to_x = || x += 2;
///     do_twice(add_two_to_x);
/// }
///
/// assert_eq!(x, 5);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn_mut"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnMut}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnMut<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // zodat regex erop kan vertrouwen dat `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnMut<Args>: FnOnce<Args> {
    /// Voert de oproepbewerking uit.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_mut(&mut self, args: Args) -> Self::Output;
}

/// De versie van de oproepoperator die een ontvanger op basis van waarde neemt.
///
/// Instanties van `FnOnce` kunnen worden aangeroepen, maar zijn mogelijk niet meerdere keren oproepbaar.Daarom, als het enige dat bekend is over een type is dat het `FnOnce` implementeert, kan het maar één keer worden aangeroepen.
///
/// `FnOnce` wordt automatisch geïmplementeerd door sluitingen die vastgelegde variabelen zouden kunnen verbruiken, evenals alle typen die [`FnMut`] implementeren, bijv. (safe) [function pointers] (aangezien `FnOnce` een supertrait is van [`FnMut`]).
///
///
/// Omdat zowel [`Fn`] als [`FnMut`] subtraits zijn van `FnOnce`, kan elk exemplaar van [`Fn`] of [`FnMut`] worden gebruikt waar een `FnOnce` wordt verwacht.
///
/// Gebruik `FnOnce` als een grens als u een parameter van het functieachtige type wilt accepteren en deze maar één keer hoeft aan te roepen.
/// Als u de parameter herhaaldelijk moet aanroepen, gebruik dan [`FnMut`] als een grens;als je het ook nodig hebt om de staat niet te muteren, gebruik dan [`Fn`].
///
/// Zie de [chapter on closures in *The Rust Programming Language*][book] voor meer informatie over dit onderwerp.
///
/// Ook opmerkelijk is de speciale syntaxis voor `Fn` traits (bijv
/// `Fn(usize, bool) -> usize`).Wie geïnteresseerd is in de technische details hiervan, kan verwijzen naar [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Met behulp van een `FnOnce`-parameter
///
/// ```
/// fn consume_with_relish<F>(func: F)
///     where F: FnOnce() -> String
/// {
///     // `func` verbruikt zijn vastgelegde variabelen, dus het kan niet meer dan één keer worden uitgevoerd.
/////
///     println!("Consumed: {}", func());
///
///     println!("Delicious!");
///
///     // Als u `func()` opnieuw probeert aan te roepen, wordt een `use of moved value`-fout gegenereerd voor `func`.
/////
/// }
///
/// let x = String::from("x");
/// let consume_and_return_x = move || x;
/// consume_with_relish(consume_and_return_x);
///
/// // `consume_and_return_x` kan op dit moment niet meer worden ingeroepen
/// ```
///
///
///
///
///
///
///
///
#[lang = "fn_once"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnOnce}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnOnce<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // zodat regex erop kan vertrouwen dat `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnOnce<Args> {
    /// Het geretourneerde type nadat de oproepoperator is gebruikt.
    #[lang = "fn_once_output"]
    #[stable(feature = "fn_once_output", since = "1.12.0")]
    type Output;

    /// Voert de oproepbewerking uit.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_once(self, args: Args) -> Self::Output;
}

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> Fn<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call(&self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &F
    where
        F: Fn<A>,
    {
        type Output = F::Output;

        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &mut F
    where
        F: FnMut<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &mut F
    where
        F: FnMut<A>,
    {
        type Output = F::Output;
        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }
}