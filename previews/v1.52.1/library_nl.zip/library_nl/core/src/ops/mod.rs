//! Overbelastbare operators.
//!
//! Door deze traits te implementeren, kun je bepaalde operators overbelasten.
//!
//! Sommige van deze traits worden geïmporteerd door de prelude, dus ze zijn beschikbaar in elk Rust-programma.Alleen operators die worden ondersteund door traits kunnen worden overbelast.
//! De opteloperator (`+`) kan bijvoorbeeld worden overbelast via de [`Add`] trait, maar aangezien de toewijzingsoperator (`=`) geen ondersteuning heeft bij trait, is er geen manier om de semantiek ervan te overbelasten.
//! Bovendien biedt deze module geen mechanisme om nieuwe operators aan te maken.
//! Als overbelasting zonder eigenschappen of aangepaste operatoren vereist zijn, moet u naar macro's of compiler-plug-ins kijken om de syntaxis van Rust uit te breiden.
//!
//! Implementaties van operator traits zouden in hun respectievelijke contexten niet verrassend moeten zijn, rekening houdend met hun gebruikelijke betekenissen en [operator precedence].
//! Bij het implementeren van [`Mul`] zou de bewerking bijvoorbeeld enige gelijkenis moeten hebben met vermenigvuldiging (en verwachte eigenschappen zoals associativiteit moeten delen).
//!
//! Merk op dat de operators `&&` en `||` kortsluiten, dwz ze evalueren alleen hun tweede operand als deze bijdraagt aan het resultaat.Aangezien dit gedrag niet kan worden afgedwongen door traits, worden `&&` en `||` niet ondersteund als overbelastbare operators.
//!
//! Veel van de operators nemen hun operanden op waarde.In niet-generieke contexten met ingebouwde typen is dit meestal geen probleem.
//! Het gebruik van deze operators in generieke code vereist echter enige aandacht als waarden moeten worden hergebruikt, in plaats van ze door de operators te laten gebruiken.Een optie is om af en toe [`clone`] te gebruiken.
//! Een andere optie is om op de betrokken typen te vertrouwen en aanvullende operatorimplementaties voor referenties te bieden.
//! Voor een door de gebruiker gedefinieerd type `T` dat toevoeging zou moeten ondersteunen, is het waarschijnlijk een goed idee om zowel `T` als `&T` de traits [`Add<T>`][`Add`] en [`Add<&T>`][`Add`] te laten implementeren, zodat generieke code kan worden geschreven zonder onnodig klonen.
//!
//!
//! # Examples
//!
//! Dit voorbeeld maakt een `Point`-structuur die [`Add`] en [`Sub`] implementeert, en laat vervolgens zien hoe je twee `Point`s.
//!
//! ```rust
//! use std::ops::{Add, Sub};
//!
//! #[derive(Debug, Copy, Clone, PartialEq)]
//! struct Point {
//!     x: i32,
//!     y: i32,
//! }
//!
//! impl Add for Point {
//!     type Output = Self;
//!
//!     fn add(self, other: Self) -> Self {
//!         Self {x: self.x + other.x, y: self.y + other.y}
//!     }
//! }
//!
//! impl Sub for Point {
//!     type Output = Self;
//!
//!     fn sub(self, other: Self) -> Self {
//!         Self {x: self.x - other.x, y: self.y - other.y}
//!     }
//! }
//!
//! assert_eq!(Point {x: 3, y: 3}, Point {x: 1, y: 0} + Point {x: 2, y: 3});
//! assert_eq!(Point {x: -1, y: -3}, Point {x: 1, y: 0} - Point {x: 2, y: 3});
//! ```
//!
//! Zie de documentatie voor elke trait voor een voorbeeldimplementatie.
//!
//! De [`Fn`], [`FnMut`] en [`FnOnce`] traits worden geïmplementeerd door typen die kunnen worden aangeroepen als functies.Merk op dat [`Fn`] `&self` nodig heeft, [`FnMut`] `&mut self` en [`FnOnce`] `self`.
//! Deze komen overeen met de drie soorten methoden die kunnen worden aangeroepen op een instantie: call-by-reference, call-by-mutable-reference en call-by-value.
//! Het meest voorkomende gebruik van deze traits is om te fungeren als begrenzingen voor functies op een hoger niveau die functies of sluitingen als argumenten aannemen.
//!
//! Een [`Fn`] als parameter nemen:
//!
//! ```rust
//! fn call_with_one<F>(func: F) -> usize
//!     where F: Fn(usize) -> usize
//! {
//!     func(1)
//! }
//!
//! let double = |x| x * 2;
//! assert_eq!(call_with_one(double), 2);
//! ```
//!
//! Een [`FnMut`] als parameter nemen:
//!
//! ```rust
//! fn do_twice<F>(mut func: F)
//!     where F: FnMut()
//! {
//!     func();
//!     func();
//! }
//!
//! let mut x: usize = 1;
//! {
//!     let add_two_to_x = || x += 2;
//!     do_twice(add_two_to_x);
//! }
//!
//! assert_eq!(x, 5);
//! ```
//!
//! Een [`FnOnce`] als parameter nemen:
//!
//! ```rust
//! fn consume_with_relish<F>(func: F)
//!     where F: FnOnce() -> String
//! {
//!     // `func` verbruikt zijn vastgelegde variabelen, dus het kan niet meer dan één keer worden uitgevoerd
//!     //
//!     println!("Consumed: {}", func());
//!
//!     println!("Delicious!");
//!
//!     // Als u `func()` opnieuw probeert aan te roepen, wordt een `use of moved value`-fout gegenereerd voor `func`
//!     //
//! }
//!
//! let x = String::from("x");
//! let consume_and_return_x = move || x;
//! consume_with_relish(consume_and_return_x);
//!
//! // `consume_and_return_x` kan op dit moment niet meer worden ingeroepen
//! ```
//!
//! [`clone`]: Clone::clone
//! [operator precedence]: ../../reference/expressions.html#expression-precedence
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

mod arith;
mod bit;
mod control_flow;
mod deref;
mod drop;
mod function;
mod generator;
mod index;
mod range;
mod r#try;
mod unsize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::arith::{Add, Div, Mul, Neg, Rem, Sub};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::arith::{AddAssign, DivAssign, MulAssign, RemAssign, SubAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::bit::{BitAnd, BitOr, BitXor, Not, Shl, Shr};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::bit::{BitAndAssign, BitOrAssign, BitXorAssign, ShlAssign, ShrAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::deref::{Deref, DerefMut};

#[unstable(feature = "receiver_trait", issue = "none")]
pub use self::deref::Receiver;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::drop::Drop;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::function::{Fn, FnMut, FnOnce};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::index::{Index, IndexMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::range::{Range, RangeFrom, RangeFull, RangeTo};

#[stable(feature = "inclusive_range", since = "1.26.0")]
pub use self::range::{Bound, RangeBounds, RangeInclusive, RangeToInclusive};

#[unstable(feature = "try_trait", issue = "42327")]
pub use self::r#try::Try;

#[unstable(feature = "generator_trait", issue = "43122")]
pub use self::generator::{Generator, GeneratorState};

#[unstable(feature = "coerce_unsized", issue = "27732")]
pub use self::unsize::CoerceUnsized;

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
pub use self::unsize::DispatchFromDyn;

#[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
pub use self::control_flow::ControlFlow;