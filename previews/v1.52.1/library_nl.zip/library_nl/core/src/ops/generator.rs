use crate::marker::Unpin;
use crate::pin::Pin;

/// Het resultaat van een hervatting van de generator.
///
/// Deze enum wordt geretourneerd door de `Generator::resume`-methode en geeft de mogelijke retourwaarden van een generator aan.
/// Momenteel komt dit overeen met een ophangpunt (`Yielded`) of een aansluitpunt (`Complete`).
///
#[derive(Clone, Copy, PartialEq, PartialOrd, Eq, Ord, Debug, Hash)]
#[lang = "generator_state"]
#[unstable(feature = "generator_trait", issue = "43122")]
pub enum GeneratorState<Y, R> {
    /// De generator is opgeschort met een waarde.
    ///
    /// Deze status geeft aan dat een generator is onderbroken en komt doorgaans overeen met een `yield`-instructie.
    /// De waarde in deze variant komt overeen met de uitdrukking die is doorgegeven aan `yield` en stelt generatoren in staat om elke keer dat ze een waarde opleveren, een waarde op te geven.
    ///
    ///
    Yielded(Y),

    /// De generator aangevuld met een retourwaarde.
    ///
    /// Deze status geeft aan dat een generator de uitvoering heeft voltooid met de opgegeven waarde.
    /// Zodra een generator `Complete` heeft geretourneerd, wordt het als een programmeerfout beschouwd om `resume` opnieuw aan te roepen.
    ///
    Complete(R),
}

/// De trait geïmplementeerd door ingebouwde generatortypes.
///
/// Generatoren, ook wel coroutines genoemd, zijn momenteel een experimentele taalfunctie in Rust.
/// Toegevoegde [RFC 2033]-generatoren zijn momenteel bedoeld om in de eerste plaats een bouwsteen te bieden voor de async/await-syntaxis, maar zullen waarschijnlijk ook een ergonomische definitie bieden voor iteratoren en andere primitieven.
///
///
/// De syntaxis en semantiek voor generatoren is onstabiel en vereist een verdere RFC voor stabilisatie.Op dit moment is de syntaxis echter als een sluiting:
///
/// ```rust
/// #![feature(generators, generator_trait)]
///
/// use std::ops::{Generator, GeneratorState};
/// use std::pin::Pin;
///
/// fn main() {
///     let mut generator = || {
///         yield 1;
///         return "foo"
///     };
///
///     match Pin::new(&mut generator).resume(()) {
///         GeneratorState::Yielded(1) => {}
///         _ => panic!("unexpected return from resume"),
///     }
///     match Pin::new(&mut generator).resume(()) {
///         GeneratorState::Complete("foo") => {}
///         _ => panic!("unexpected return from resume"),
///     }
/// }
/// ```
///
/// Meer documentatie over generatoren is te vinden in het onstabiele boek.
///
/// [RFC 2033]: https://github.com/rust-lang/rfcs/pull/2033
///
///
///
///
#[lang = "generator"]
#[unstable(feature = "generator_trait", issue = "43122")]
#[fundamental]
pub trait Generator<R = ()> {
    /// Het type waarde dat deze generator oplevert.
    ///
    /// Dit geassocieerde type komt overeen met de `yield`-expressie en de waarden die elke keer dat een generator oplevert, mogen worden geretourneerd.
    ///
    /// Een iterator-als-een-generator zou bijvoorbeeld dit type waarschijnlijk `T` hebben, het type wordt herhaald.
    ///
    type Yield;

    /// Het type waarde dat deze generator retourneert.
    ///
    /// Dit komt overeen met het type dat wordt geretourneerd door een generator, hetzij met een `return`-instructie, hetzij impliciet als de laatste uitdrukking van een letterlijke generator.
    /// futures zou dit bijvoorbeeld gebruiken als `Result<T, E>` omdat het een voltooide future vertegenwoordigt.
    ///
    ///
    type Return;

    /// Hervat de uitvoering van deze generator.
    ///
    /// Deze functie hervat de uitvoering van de generator of start de uitvoering als dit nog niet is gebeurd.
    /// Deze oproep keert terug naar het laatste opschortingspunt van de generator en hervat de uitvoering vanaf de laatste `yield`.
    /// De generator zal doorgaan met uitvoeren totdat het ofwel oplevert of terugkeert, op welk punt deze functie zal terugkeren.
    ///
    /// # Winstwaarde
    ///
    /// De `GeneratorState`-enum die door deze functie wordt geretourneerd, geeft aan in welke staat de generator zich bevindt bij terugkeer.
    /// Als de `Yielded`-variant wordt geretourneerd, heeft de generator een ophangpunt bereikt en is er een waarde afgegeven.
    /// Generatoren in deze staat zijn beschikbaar voor hervatting op een later punt.
    ///
    /// Als `Complete` wordt geretourneerd, is de generator volledig klaar met de opgegeven waarde.Het is ongeldig om de generator opnieuw te starten.
    ///
    /// # Panics
    ///
    /// Deze functie kan panic zijn als deze wordt aangeroepen nadat de `Complete`-variant eerder is geretourneerd.
    /// Hoewel generator-letterlijke tekens in de taal gegarandeerd panic zijn bij hervatting na `Complete`, is dit niet gegarandeerd voor alle implementaties van de `Generator` trait.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn resume(self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return>;
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R>, R> Generator<R> for Pin<&mut G> {
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume((*self).as_mut(), arg)
    }
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R> + Unpin, R> Generator<R> for &mut G {
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume(Pin::new(&mut *self), arg)
    }
}