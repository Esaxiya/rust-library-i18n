/// Aangepaste code binnen de destructor.
///
/// Als een waarde niet langer nodig is, zal Rust een "destructor" op die waarde draaien.
/// De meest gebruikelijke manier waarop een waarde niet langer nodig is, is wanneer deze buiten het bereik valt.Destructors kunnen nog steeds rennen in andere omstandigheden, maar we gaan ons hier concentreren op de reikwijdte van de voorbeelden.
/// Voor meer informatie over enkele van die andere gevallen, zie de [the reference]-sectie over destructors.
///
/// [the reference]: https://doc.rust-lang.org/reference/destructors.html
///
/// Deze destructor bestaat uit twee componenten:
/// - Een aanroep naar `Drop::drop` voor die waarde, als deze speciale `Drop` trait is geïmplementeerd voor zijn type.
/// - De automatisch gegenereerde "drop glue" die recursief de vernietigers van alle velden met deze waarde oproept.
///
/// Aangezien Rust automatisch de vernietigers van alle ingesloten velden oproept, hoeft u `Drop` in de meeste gevallen niet te implementeren.
/// Maar er zijn enkele gevallen waarin het nuttig is, bijvoorbeeld voor typen die een bron rechtstreeks beheren.
/// Die bron kan geheugen zijn, het kan een bestandsdescriptor zijn, het kan een netwerkaansluiting zijn.
/// Zodra een waarde van dat type niet langer zal worden gebruikt, moet het zijn bron "clean up" maken door het geheugen vrij te maken of het bestand of de socket te sluiten.
/// Dit is de taak van een destructor, en dus de taak van `Drop::drop`.
///
/// ## Examples
///
/// Laten we het volgende programma eens bekijken om destructors in actie te zien:
///
/// ```rust
/// struct HasDrop;
///
/// impl Drop for HasDrop {
///     fn drop(&mut self) {
///         println!("Dropping HasDrop!");
///     }
/// }
///
/// struct HasTwoDrops {
///     one: HasDrop,
///     two: HasDrop,
/// }
///
/// impl Drop for HasTwoDrops {
///     fn drop(&mut self) {
///         println!("Dropping HasTwoDrops!");
///     }
/// }
///
/// fn main() {
///     let _x = HasTwoDrops { one: HasDrop, two: HasDrop };
///     println!("Running!");
/// }
/// ```
///
/// Rust zal eerst `Drop::drop` aanroepen voor `_x` en vervolgens voor zowel `_x.one` als `_x.two`, wat betekent dat als u dit uitvoert, wordt afgedrukt
///
/// ```text
/// Running!
/// Dropping HasTwoDrops!
/// Dropping HasDrop!
/// Dropping HasDrop!
/// ```
///
/// Zelfs als we de implementatie van `Drop` voor `HasTwoDrop` verwijderen, worden de vernietigers van de velden nog steeds aangeroepen.
/// Dit zou resulteren in
///
/// ```test
/// Running!
/// Dropping HasDrop!
/// Dropping HasDrop!
/// ```
///
/// ## U kunt `Drop::drop` niet zelf bellen
///
/// Omdat `Drop::drop` wordt gebruikt om een waarde op te schonen, kan het gevaarlijk zijn om deze waarde te gebruiken nadat de methode is aangeroepen.
/// Omdat `Drop::drop` geen eigenaar wordt van zijn invoer, voorkomt Rust misbruik door u niet toe te staan `Drop::drop` rechtstreeks te bellen.
///
/// Met andere woorden, als u in het bovenstaande voorbeeld `Drop::drop` expliciet aanroept, krijgt u een compilatiefout.
///
/// Als je de destructor van een waarde expliciet wilt aanroepen, kan in plaats daarvan [`mem::drop`] worden gebruikt.
///
/// [`mem::drop`]: drop
///
/// ## Bestelling neerzetten
///
/// Welke van onze twee `HasDrop` valt echter het eerst uit?Voor structs is het dezelfde volgorde waarin ze worden gedeclareerd: eerst `one`, dan `two`.
/// Als u dit zelf wilt proberen, kunt u `HasDrop` hierboven aanpassen zodat het wat gegevens bevat, zoals een geheel getal, en deze vervolgens gebruiken in de `println!` in `Drop`.
/// Dit gedrag wordt gegarandeerd door de taal.
///
/// In tegenstelling tot structs worden lokale variabelen in omgekeerde volgorde weggelaten:
///
/// ```rust
/// struct Foo;
///
/// impl Drop for Foo {
///     fn drop(&mut self) {
///         println!("Dropping Foo!")
///     }
/// }
///
/// struct Bar;
///
/// impl Drop for Bar {
///     fn drop(&mut self) {
///         println!("Dropping Bar!")
///     }
/// }
///
/// fn main() {
///     let _foo = Foo;
///     let _bar = Bar;
/// }
/// ```
///
/// Dit wordt afgedrukt
///
/// ```text
/// Dropping Bar!
/// Dropping Foo!
/// ```
///
/// Zie [the reference] voor de volledige regels.
///
/// [the reference]: https://doc.rust-lang.org/reference/destructors.html
///
/// ## `Copy` en `Drop` zijn exclusief
///
/// U kunt niet zowel [`Copy`] als `Drop` op hetzelfde type implementeren.Typen die `Copy` zijn, worden impliciet gedupliceerd door de compiler, waardoor het erg moeilijk is om te voorspellen wanneer en hoe vaak destructors zullen worden uitgevoerd.
///
/// Als zodanig kunnen deze typen geen destructors hebben.
///
///
///
///
///
///
///
///
///
///
#[lang = "drop"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Drop {
    /// Voert de destructor uit voor dit type.
    ///
    /// Deze methode wordt impliciet aangeroepen wanneer de waarde buiten het bereik valt en kan niet expliciet worden aangeroepen (dit is compilatiefout [E0040]).
    /// De [`mem::drop`]-functie in de prelude kan echter worden gebruikt om de `Drop`-implementatie van het argument aan te roepen.
    ///
    /// Wanneer deze methode is aangeroepen, is de toewijzing van `self` nog niet opgeheven.
    /// Dat gebeurt pas nadat de methode is afgelopen.
    /// Als dit niet het geval was, zou `self` een bungelende referentie zijn.
    ///
    /// # Panics
    ///
    /// Aangezien een [`panic!`] `drop` zal aanroepen terwijl deze afwikkelt, zal elke [`panic!`] in een `drop`-implementatie waarschijnlijk worden afgebroken.
    ///
    /// Merk op dat zelfs als dit panics is, de waarde wordt beschouwd als verwijderd;
    /// u moet ervoor zorgen dat `drop` niet opnieuw wordt gebeld.
    /// Dit wordt normaal gesproken automatisch afgehandeld door de compiler, maar bij gebruik van onveilige code kan dit soms onbedoeld gebeuren, vooral bij gebruik van [`ptr::drop_in_place`].
    ///
    ///
    /// [E0040]: ../../error-index.html#E0040 [`panic!`]: crate::panic!
    /// [`mem::drop`]: drop
    /// [`ptr::drop_in_place`]: crate::ptr::drop_in_place
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn drop(&mut self);
}