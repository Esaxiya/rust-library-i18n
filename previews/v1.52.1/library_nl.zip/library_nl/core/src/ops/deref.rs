/// Wordt gebruikt voor onveranderlijke dereferentie-bewerkingen, zoals `*v`.
///
/// Behalve dat het wordt gebruikt voor expliciete dereferentiebewerkingen met de (unary) `*`-operator in onveranderlijke contexten, wordt `Deref` in veel omstandigheden ook impliciet door de compiler gebruikt.
/// Dit mechanisme wordt ['`Deref` coercion'][more] genoemd.
/// In veranderlijke contexten wordt [`DerefMut`] gebruikt.
///
/// Het implementeren van `Deref` voor slimme wijzers maakt het gemakkelijker om toegang te krijgen tot de gegevens erachter, en daarom implementeren ze `Deref`.
/// Aan de andere kant zijn de regels met betrekking tot `Deref` en [`DerefMut`] specifiek ontworpen om slimme wijzers tegemoet te komen.
/// Daarom moet **`Deref` alleen worden geïmplementeerd voor slimme wijzers** om verwarring te voorkomen.
///
/// Om vergelijkbare redenen **zou deze trait nooit moeten falen**.Falen tijdens dereferentie kan zeer verwarrend zijn wanneer `Deref` impliciet wordt aangeroepen.
///
/// # Meer over `Deref`-dwang
///
/// Als `T` `Deref<Target = U>` implementeert en `x` een waarde is van het type `T`, dan:
///
/// * In onveranderlijke contexten is `*x` (waarbij `T` noch een referentie noch een onbewerkte pointer is) gelijk aan `* Deref::deref(&x)`.
/// * Waarden van het type `&T` worden gedwongen tot waarden van het type `&U`
/// * `T` implementeert impliciet alle (immutable)-methoden van het type `U`.
///
/// Bezoek voor meer details [the chapter in *The Rust Programming Language*][book] en de referentie-secties over [the dereference operator][ref-deref-op], [method resolution] en [type coercions].
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// Een struct met een enkel veld dat toegankelijk is door dereferentie van de struct.
///
/// ```
/// use std::ops::Deref;
///
/// struct DerefExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// let x = DerefExample { value: 'a' };
/// assert_eq!('a', *x);
/// ```
///
///
///
///
///
///
///
#[lang = "deref"]
#[doc(alias = "*")]
#[doc(alias = "&*")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Deref"]
pub trait Deref {
    /// Het resulterende type na dereferentie.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_target"]
    #[cfg_attr(not(bootstrap), lang = "deref_target")]
    type Target: ?Sized;

    /// Dereferenties de waarde.
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_method"]
    fn deref(&self) -> &Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &T {
    type Target = T;

    #[rustc_diagnostic_item = "noop_method_deref"]
    fn deref(&self) -> &T {
        *self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !DerefMut for &T {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &mut T {
    type Target = T;

    fn deref(&self) -> &T {
        *self
    }
}

/// Wordt gebruikt voor veranderlijke dereferentie-bewerkingen, zoals in `*v = 1;`.
///
/// Behalve dat het wordt gebruikt voor expliciete dereferentiebewerkingen met de (unary) `*`-operator in veranderlijke contexten, wordt `DerefMut` in veel omstandigheden ook impliciet gebruikt door de compiler.
/// Dit mechanisme wordt ['`Deref` coercion'][more] genoemd.
/// In onveranderlijke contexten wordt [`Deref`] gebruikt.
///
/// Het implementeren van `DerefMut` voor slimme wijzers maakt het muteren van de gegevens erachter gemakkelijk, daarom implementeren ze `DerefMut`.
/// Aan de andere kant zijn de regels met betrekking tot [`Deref`] en `DerefMut` specifiek ontworpen om slimme wijzers tegemoet te komen.
/// Daarom moet **`DerefMut` alleen worden geïmplementeerd voor slimme wijzers** om verwarring te voorkomen.
///
/// Om vergelijkbare redenen **zou deze trait nooit moeten falen**.Falen tijdens dereferentie kan buitengewoon verwarrend zijn wanneer `DerefMut` impliciet wordt aangeroepen.
///
/// # Meer over `Deref`-dwang
///
/// Als `T` `DerefMut<Target = U>` implementeert en `x` een waarde is van het type `T`, dan:
///
/// * In veranderlijke contexten is `*x` (waarbij `T` noch een referentie noch een onbewerkte pointer is) gelijk aan `* DerefMut::deref_mut(&mut x)`.
/// * Waarden van het type `&mut T` worden gedwongen tot waarden van het type `&mut U`
/// * `T` implementeert impliciet alle (mutable)-methoden van het type `U`.
///
/// Bezoek voor meer details [the chapter in *The Rust Programming Language*][book] en de referentie-secties over [the dereference operator][ref-deref-op], [method resolution] en [type coercions].
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// Een struct met een enkel veld dat kan worden gewijzigd door dereferentie van de struct.
///
/// ```
/// use std::ops::{Deref, DerefMut};
///
/// struct DerefMutExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefMutExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// impl<T> DerefMut for DerefMutExample<T> {
///     fn deref_mut(&mut self) -> &mut Self::Target {
///         &mut self.value
///     }
/// }
///
/// let mut x = DerefMutExample { value: 'a' };
/// *x = 'b';
/// assert_eq!('b', *x);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "deref_mut"]
#[doc(alias = "*")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DerefMut: Deref {
    /// Verandert de waarde op veranderlijke wijze.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn deref_mut(&mut self) -> &mut Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for &mut T {
    fn deref_mut(&mut self) -> &mut T {
        *self
    }
}

/// Geeft aan dat een struct kan worden gebruikt als methode-ontvanger, zonder de `arbitrary_self_types`-functie.
///
/// Dit wordt geïmplementeerd door stdlib-aanwijzertypen zoals `Box<T>`, `Rc<T>`, `&T` en `Pin<P>`.
#[lang = "receiver"]
#[unstable(feature = "receiver_trait", issue = "none")]
#[doc(hidden)]
pub trait Receiver {
    // Empty.
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &T {}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &mut T {}