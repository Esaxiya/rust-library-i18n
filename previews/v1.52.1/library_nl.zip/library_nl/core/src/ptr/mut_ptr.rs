use super::*;
use crate::cmp::Ordering::{self, Equal, Greater, Less};
use crate::intrinsics;
use crate::slice::{self, SliceIndex};

#[lang = "mut_ptr"]
impl<T: ?Sized> *mut T {
    /// Geeft `true` terug als de aanwijzer null is.
    ///
    /// Houd er rekening mee dat niet-formaat typen veel mogelijke nulpunten hebben, aangezien alleen de aanwijzer voor onbewerkte gegevens wordt beschouwd, niet hun lengte, vtable, enz.
    /// Daarom is het mogelijk dat twee verwijzingen die nul zijn, nog steeds niet gelijk zijn aan elkaar.
    ///
    /// ## Gedrag tijdens const evaluatie
    ///
    /// Wanneer deze functie wordt gebruikt tijdens const-evaluatie, kan het `false` retourneren voor verwijzingen die tijdens runtime null blijken te zijn.
    /// In het bijzonder, wanneer een aanwijzer naar een bepaald geheugen zodanig wordt verschoven buiten zijn grenzen dat de resulterende aanwijzer nul is, retourneert de functie nog steeds `false`.
    ///
    /// Er is geen manier voor CTFE om de absolute positie van dat geheugen te weten, dus we kunnen niet zeggen of de aanwijzer nul is of niet.
    ///
    /// # Examples
    ///
    /// Basisgebruik:
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    /// assert!(!ptr.is_null());
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_ptr_is_null", issue = "74939")]
    #[inline]
    pub const fn is_null(self) -> bool {
        // Vergelijk via een cast met een dunne aanwijzer, dus dikke wijzers beschouwen hun "data"-deel alleen voor nulheid.
        //
        (self as *mut u8).guaranteed_eq(null_mut())
    }

    /// Werpt naar een aanwijzer van een ander type.
    #[stable(feature = "ptr_cast", since = "1.38.0")]
    #[rustc_const_stable(feature = "const_ptr_cast", since = "1.38.0")]
    #[inline]
    pub const fn cast<U>(self) -> *mut U {
        self as _
    }

    /// Decomponeer een (mogelijk brede) pointer in zijn adres-en metadatacomponenten.
    ///
    /// De aanwijzer kan later worden gereconstrueerd met [`from_raw_parts_mut`].
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (*mut (), <T as super::Pointee>::Metadata) {
        (self.cast(), super::metadata(self))
    }

    /// Retourneert `None` als de pointer null is, of retourneert een gedeelde verwijzing naar de waarde verpakt in `Some`.Als de waarde mogelijk niet is geïnitialiseerd, moet in plaats daarvan [`as_uninit_ref`] worden gebruikt.
    ///
    /// Zie [`as_mut`] voor de veranderlijke tegenhanger.
    ///
    /// [`as_uninit_ref`]: #method.as_uninit_ref-1
    /// [`as_mut`]: #method.as_mut
    ///
    /// # Safety
    ///
    /// Wanneer u deze methode aanroept, moet u ervoor zorgen dat *ofwel* de aanwijzer NULL is *of* dat al het volgende waar is:
    ///
    /// * De aanwijzer moet correct zijn uitgelijnd.
    ///
    /// * Het moet "dereferencable" zijn in de zin die is gedefinieerd in [the module documentation].
    ///
    /// * De pointer moet verwijzen naar een geïnitialiseerd exemplaar van `T`.
    ///
    /// * U moet de aliasingregels van Rust afdwingen, aangezien de geretourneerde levensduur `'a` willekeurig wordt gekozen en niet noodzakelijk de werkelijke levensduur van de gegevens weerspiegelt.
    ///   In het bijzonder, gedurende deze levensduur, mag het geheugen waarnaar de aanwijzer verwijst niet worden gemuteerd (behalve binnen `UnsafeCell`).
    ///
    /// Dit geldt zelfs als het resultaat van deze methode niet wordt gebruikt!
    /// (Het gedeelte over geïnitialiseerd worden is nog niet volledig beslist, maar totdat dit het geval is, is de enige veilige benadering ervoor te zorgen dat ze inderdaad worden geïnitialiseerd.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Basisgebruik:
    ///
    /// ```
    /// let ptr: *mut u8 = &mut 10u8 as *mut u8;
    ///
    /// unsafe {
    ///     if let Some(val_back) = ptr.as_ref() {
    ///         println!("We got back the value: {}!", val_back);
    ///     }
    /// }
    /// ```
    ///
    /// # Null-ongecontroleerde versie
    ///
    /// Als u zeker weet dat de aanwijzer nooit nul kan zijn en op zoek bent naar een soort `as_ref_unchecked` die de `&T` retourneert in plaats van `Option<&T>`, weet dan dat u de verwijzing naar de aanwijzer direct kunt herleiden.
    ///
    ///
    /// ```
    /// let ptr: *mut u8 = &mut 10u8 as *mut u8;
    ///
    /// unsafe {
    ///     let val_back = &*ptr;
    ///     println!("We got back the value: {}!", val_back);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_as_ref", since = "1.9.0")]
    #[inline]
    pub unsafe fn as_ref<'a>(self) -> Option<&'a T> {
        // VEILIGHEID: de beller moet garanderen dat `self` geldig is voor een
        // referentie als het niet nul is.
        if self.is_null() { None } else { unsafe { Some(&*self) } }
    }

    /// Retourneert `None` als de pointer null is, of retourneert een gedeelde verwijzing naar de waarde verpakt in `Some`.
    /// In tegenstelling tot [`as_ref`] hoeft de waarde hiervoor niet te worden geïnitialiseerd.
    ///
    /// Zie [`as_uninit_mut`] voor de veranderlijke tegenhanger.
    ///
    /// [`as_ref`]: #method.as_ref-1
    /// [`as_uninit_mut`]: #method.as_uninit_mut
    ///
    /// # Safety
    ///
    /// Wanneer u deze methode aanroept, moet u ervoor zorgen dat *ofwel* de aanwijzer NULL is *of* dat al het volgende waar is:
    ///
    /// * De aanwijzer moet correct zijn uitgelijnd.
    ///
    /// * Het moet "dereferencable" zijn in de zin die is gedefinieerd in [the module documentation].
    ///
    /// * U moet de aliasingregels van Rust afdwingen, aangezien de geretourneerde levensduur `'a` willekeurig wordt gekozen en niet noodzakelijk de werkelijke levensduur van de gegevens weerspiegelt.
    ///
    ///   In het bijzonder, gedurende deze levensduur, mag het geheugen waarnaar de aanwijzer verwijst niet worden gemuteerd (behalve binnen `UnsafeCell`).
    ///
    /// Dit geldt zelfs als het resultaat van deze methode niet wordt gebruikt!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Basisgebruik:
    ///
    /// ```
    /// #![feature(ptr_as_uninit)]
    ///
    /// let ptr: *mut u8 = &mut 10u8 as *mut u8;
    ///
    /// unsafe {
    ///     if let Some(val_back) = ptr.as_uninit_ref() {
    ///         println!("We got back the value: {}!", val_back.assume_init());
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref<'a>(self) -> Option<&'a MaybeUninit<T>>
    where
        T: Sized,
    {
        // VEILIGHEID: de beller moet garanderen dat `self` voldoet aan alle
        // vereisten voor een referentie.
        if self.is_null() { None } else { Some(unsafe { &*(self as *const MaybeUninit<T>) }) }
    }

    /// Berekent de offset van een aanwijzer.
    ///
    /// `count` is in eenheden van T;bijv. een `count` van 3 vertegenwoordigt een pointeroffset van `3 * size_of::<T>()` bytes.
    ///
    /// # Safety
    ///
    /// Als een van de volgende voorwaarden wordt geschonden, is het resultaat Ongedefinieerd gedrag:
    ///
    /// * Zowel de begin-als de resulterende aanwijzer moeten zich binnen grenzen of één byte voorbij het einde van hetzelfde toegewezen object bevinden.
    /// Merk op dat in Rust elke (stack-allocated)-variabele wordt beschouwd als een afzonderlijk toegewezen object.
    ///
    /// * De berekende offset,**in bytes**, kan een `isize` niet overstromen.
    ///
    /// * De offset die binnen grenzen is, kan niet vertrouwen op "wrapping around" de adresruimte.Dat wil zeggen, de som van oneindige precisie,**in bytes**, moet in een usize passen.
    ///
    /// De compiler en de standaardbibliotheek proberen over het algemeen ervoor te zorgen dat toewijzingen nooit een grootte bereiken waarbij een offset een probleem is.
    /// `Vec` en `Box` zorgen er bijvoorbeeld voor dat ze nooit meer dan `isize::MAX` bytes toewijzen, dus `vec.as_ptr().add(vec.len())` is altijd veilig.
    ///
    /// De meeste platforms kunnen in wezen niet eens zo'n toewijzing construeren.
    /// Geen enkel bekend 64-bits platform kan bijvoorbeeld ooit een verzoek voor 2 <sup>63</sup> bytes verwerken vanwege paginatabelbeperkingen of het opsplitsen van de adresruimte.
    /// Sommige 32-bits en 16-bits platforms kunnen echter met succes een verzoek indienen voor meer dan `isize::MAX` bytes met zaken als Physical Address Extension.
    ///
    /// Als zodanig kan geheugen dat rechtstreeks is verkregen van allocators of geheugen toegewezen bestanden * te groot zijn om met deze functie te werken.
    ///
    /// Overweeg in plaats daarvan [`wrapping_offset`] te gebruiken als aan deze beperkingen moeilijk te voldoen is.
    /// Het enige voordeel van deze methode is dat het agressievere compiler-optimalisaties mogelijk maakt.
    ///
    /// [`wrapping_offset`]: #method.wrapping_offset
    ///
    /// # Examples
    ///
    /// Basisgebruik:
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    ///
    /// unsafe {
    ///     println!("{}", *ptr.offset(1));
    ///     println!("{}", *ptr.offset(2));
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn offset(self, count: isize) -> *mut T
    where
        T: Sized,
    {
        // VEILIGHEID: de beller moet zich houden aan het veiligheidscontract voor `offset`.
        // De verkregen pointer is geldig voor schrijfbewerkingen, aangezien de beller moet garanderen dat hij naar hetzelfde toegewezen object verwijst als `self`.
        //
        unsafe { intrinsics::offset(self, count) as *mut T }
    }

    /// Berekent de offset van een aanwijzer met behulp van omloopberekeningen.
    /// `count` is in eenheden van T;bijv. een `count` van 3 vertegenwoordigt een pointeroffset van `3 * size_of::<T>()` bytes.
    ///
    /// # Safety
    ///
    /// Deze bewerking zelf is altijd veilig, maar het gebruik van de resulterende aanwijzer is dat niet.
    ///
    /// De resulterende aanwijzer blijft gekoppeld aan hetzelfde toegewezen object waarnaar `self` verwijst.
    /// Het mag *niet* worden gebruikt om toegang te krijgen tot een ander toegewezen object.Merk op dat in Rust elke (stack-allocated)-variabele wordt beschouwd als een afzonderlijk toegewezen object.
    ///
    /// Met andere woorden, `let z = x.wrapping_offset((y as isize) - (x as isize))` maakt `z`*niet* hetzelfde als `y`, zelfs als we aannemen dat `T` de grootte `1` heeft en er geen overloop is: `z` is nog steeds verbonden met het object waaraan `x` is gekoppeld, en dereferentie is ongedefinieerd gedrag tenzij `x` en `y` wijst naar hetzelfde toegewezen object.
    ///
    /// In vergelijking met [`offset`] vertraagt deze methode in feite de vereiste om binnen hetzelfde toegewezen object te blijven: [`offset`] is onmiddellijk ongedefinieerd gedrag bij het overschrijden van objectgrenzen;`wrapping_offset` produceert een pointer, maar leidt nog steeds tot ongedefinieerd gedrag als een pointer wordt verwijderd wanneer deze buiten het bereik van het object is waaraan het is gekoppeld.
    /// [`offset`] kan beter worden geoptimaliseerd en verdient dus de voorkeur in prestatiegevoelige code.
    ///
    /// De vertraagde controle houdt alleen rekening met de waarde van de pointer waarnaar werd verwezen, niet met de tussenliggende waarden die zijn gebruikt tijdens de berekening van het eindresultaat.
    /// `x.wrapping_offset(o).wrapping_offset(o.wrapping_neg())` is bijvoorbeeld altijd hetzelfde als `x`.Met andere woorden, het verlaten van het toegewezen object en het later opnieuw invoeren is toegestaan.
    ///
    /// Als u objectgrenzen moet overschrijden, plaatst u de aanwijzer op een geheel getal en voert u de berekeningen daar uit.
    ///
    /// [`offset`]: #method.offset
    ///
    /// # Examples
    ///
    /// Basisgebruik:
    ///
    /// ```
    /// // Herhaal met behulp van een onbewerkte aanwijzer in stappen van twee elementen
    /// let mut data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *mut u8 = data.as_mut_ptr();
    /// let step = 2;
    /// let end_rounded_up = ptr.wrapping_offset(6);
    ///
    /// while ptr != end_rounded_up {
    ///     unsafe {
    ///         *ptr = 0;
    ///     }
    ///     ptr = ptr.wrapping_offset(step);
    /// }
    /// assert_eq!(&data, &[0, 2, 0, 4, 0]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_wrapping_offset", since = "1.16.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_offset(self, count: isize) -> *mut T
    where
        T: Sized,
    {
        // VEILIGHEID: de intrinsieke `arith_offset` heeft geen vereisten om te worden gebeld.
        unsafe { intrinsics::arith_offset(self, count) as *mut T }
    }

    /// Retourneert `None` als de pointer null is, of retourneert een unieke verwijzing naar de waarde verpakt in `Some`.Als de waarde mogelijk niet is geïnitialiseerd, moet in plaats daarvan [`as_uninit_mut`] worden gebruikt.
    ///
    /// Zie [`as_ref`] voor de gedeelde tegenhanger.
    ///
    /// [`as_uninit_mut`]: #method.as_uninit_mut
    /// [`as_ref`]: #method.as_ref-1
    ///
    /// # Safety
    ///
    /// Wanneer u deze methode aanroept, moet u ervoor zorgen dat *ofwel* de aanwijzer NULL is *of* dat al het volgende waar is:
    ///
    /// * De aanwijzer moet correct zijn uitgelijnd.
    ///
    /// * Het moet "dereferencable" zijn in de zin die is gedefinieerd in [the module documentation].
    ///
    /// * De pointer moet verwijzen naar een geïnitialiseerd exemplaar van `T`.
    ///
    /// * U moet de aliasingregels van Rust afdwingen, aangezien de geretourneerde levensduur `'a` willekeurig wordt gekozen en niet noodzakelijk de werkelijke levensduur van de gegevens weerspiegelt.
    ///   In het bijzonder mag het geheugen waarnaar de aanwijzer verwijst, gedurende deze levensduur niet worden geopend (gelezen of geschreven) via een andere aanwijzer.
    ///
    /// Dit geldt zelfs als het resultaat van deze methode niet wordt gebruikt!
    /// (Het gedeelte over geïnitialiseerd worden is nog niet volledig beslist, maar totdat dit het geval is, is de enige veilige benadering ervoor te zorgen dat ze inderdaad worden geïnitialiseerd.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Basisgebruik:
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    /// let first_value = unsafe { ptr.as_mut().unwrap() };
    /// *first_value = 4;
    /// # assert_eq!(s, [4, 2, 3]);
    /// println!("{:?}", s); // Het zal afdrukken: "[4, 2, 3]".
    /// ```
    ///
    /// # Null-ongecontroleerde versie
    ///
    /// Als u zeker weet dat de aanwijzer nooit nul kan zijn en op zoek bent naar een soort `as_mut_unchecked` die de `&mut T` retourneert in plaats van `Option<&mut T>`, weet dan dat u de verwijzing naar de aanwijzer direct kunt herleiden.
    ///
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    /// let first_value = unsafe { &mut *ptr };
    /// *first_value = 4;
    /// # assert_eq!(s, [4, 2, 3]);
    /// println!("{:?}", s); // Het zal afdrukken: "[4, 2, 3]".
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_as_ref", since = "1.9.0")]
    #[inline]
    pub unsafe fn as_mut<'a>(self) -> Option<&'a mut T> {
        // VEILIGHEID: de beller moet garanderen dat `self` geldig is voor
        // een veranderlijke referentie als deze niet nul is.
        if self.is_null() { None } else { unsafe { Some(&mut *self) } }
    }

    /// Retourneert `None` als de pointer null is, of retourneert een unieke verwijzing naar de waarde verpakt in `Some`.
    /// In tegenstelling tot [`as_mut`] hoeft de waarde hiervoor niet te worden geïnitialiseerd.
    ///
    /// Zie [`as_uninit_ref`] voor de gedeelde tegenhanger.
    ///
    /// [`as_mut`]: #method.as_mut
    /// [`as_uninit_ref`]: #method.as_uninit_ref-1
    ///
    /// # Safety
    ///
    /// Wanneer u deze methode aanroept, moet u ervoor zorgen dat *ofwel* de aanwijzer NULL is *of* dat al het volgende waar is:
    ///
    /// * De aanwijzer moet correct zijn uitgelijnd.
    ///
    /// * Het moet "dereferencable" zijn in de zin die is gedefinieerd in [the module documentation].
    ///
    /// * U moet de aliasingregels van Rust afdwingen, aangezien de geretourneerde levensduur `'a` willekeurig wordt gekozen en niet noodzakelijk de werkelijke levensduur van de gegevens weerspiegelt.
    ///
    ///   In het bijzonder mag het geheugen waarnaar de aanwijzer verwijst, gedurende deze levensduur niet worden geopend (gelezen of geschreven) via een andere aanwijzer.
    ///
    /// Dit geldt zelfs als het resultaat van deze methode niet wordt gebruikt!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_mut<'a>(self) -> Option<&'a mut MaybeUninit<T>>
    where
        T: Sized,
    {
        // VEILIGHEID: de beller moet garanderen dat `self` voldoet aan alle
        // vereisten voor een referentie.
        if self.is_null() { None } else { Some(unsafe { &mut *(self as *mut MaybeUninit<T>) }) }
    }

    /// Geeft terug of twee aanwijzers gegarandeerd gelijk zijn.
    ///
    /// Tijdens runtime gedraagt deze functie zich als `self == other`.
    /// In sommige contexten (bijv. Compilatietijdevaluatie) is het echter niet altijd mogelijk om de gelijkheid van twee pointers te bepalen, dus deze functie kan ten onrechte `false` retourneren voor pointers die later feitelijk gelijk blijken te zijn.
    ///
    /// Maar wanneer het `true` retourneert, zijn de aanwijzers gegarandeerd gelijk.
    ///
    /// Deze functie is de spiegel van [`guaranteed_ne`], maar niet zijn omgekeerde.Er zijn pointervergelijkingen waarvoor beide functies `false` retourneren.
    ///
    /// [`guaranteed_ne`]: #method.guaranteed_ne
    ///
    /// De geretourneerde waarde kan veranderen afhankelijk van de compilerversie en onveilige code is mogelijk niet afhankelijk van het resultaat van deze functie voor deugdelijkheid.
    /// Het wordt aanbevolen om deze functie alleen te gebruiken voor prestatie-optimalisaties waarbij valse `false`-retourwaarden door deze functie geen invloed hebben op de uitkomst, maar alleen op de prestatie.
    /// De gevolgen van het gebruik van deze methode om ervoor te zorgen dat runtime-en compilatietijdcode zich anders gedragen, zijn niet onderzocht.
    /// Deze methode mag niet worden gebruikt om dergelijke verschillen te introduceren, en het mag ook niet worden gestabiliseerd voordat we dit probleem beter begrijpen.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[inline]
    pub const fn guaranteed_eq(self, other: *mut T) -> bool
    where
        T: Sized,
    {
        intrinsics::ptr_guaranteed_eq(self as *const _, other as *const _)
    }

    /// Geeft terug of twee aanwijzers gegarandeerd ongelijk zijn.
    ///
    /// Tijdens runtime gedraagt deze functie zich als `self != other`.
    /// In sommige contexten (bijv. Compilatietijdevaluatie) is het echter niet altijd mogelijk om de ongelijkheid van twee pointers te bepalen, dus deze functie kan ten onrechte `false` retourneren voor pointers die later feitelijk ongelijk blijken te zijn.
    ///
    /// Maar wanneer het `true` retourneert, zijn de aanwijzers gegarandeerd ongelijk.
    ///
    /// Deze functie is de spiegel van [`guaranteed_eq`], maar niet zijn omgekeerde.Er zijn pointervergelijkingen waarvoor beide functies `false` retourneren.
    ///
    /// [`guaranteed_eq`]: #method.guaranteed_eq
    ///
    /// De geretourneerde waarde kan veranderen afhankelijk van de compilerversie en onveilige code is mogelijk niet afhankelijk van het resultaat van deze functie voor deugdelijkheid.
    /// Het wordt aanbevolen om deze functie alleen te gebruiken voor prestatie-optimalisaties waarbij valse `false`-retourwaarden door deze functie geen invloed hebben op de uitkomst, maar alleen op de prestatie.
    /// De gevolgen van het gebruik van deze methode om ervoor te zorgen dat runtime-en compilatietijdcode zich anders gedragen, zijn niet onderzocht.
    /// Deze methode mag niet worden gebruikt om dergelijke verschillen te introduceren, en het mag ook niet worden gestabiliseerd voordat we dit probleem beter begrijpen.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[inline]
    pub const unsafe fn guaranteed_ne(self, other: *mut T) -> bool
    where
        T: Sized,
    {
        intrinsics::ptr_guaranteed_ne(self as *const _, other as *const _)
    }

    /// Berekent de afstand tussen twee wijzers.De geretourneerde waarde is in eenheden van T: de afstand in bytes wordt gedeeld door `mem::size_of::<T>()`.
    ///
    /// Deze functie is het omgekeerde van [`offset`].
    ///
    /// [`offset`]: #method.offset-1
    ///
    /// # Safety
    ///
    /// Als een van de volgende voorwaarden wordt geschonden, is het resultaat Ongedefinieerd gedrag:
    ///
    /// * Zowel de startaanwijzer als de andere aanwijzer moeten zich binnen grenzen of één byte voorbij het einde van hetzelfde toegewezen object bevinden.
    /// Merk op dat in Rust elke (stack-allocated)-variabele wordt beschouwd als een afzonderlijk toegewezen object.
    ///
    /// * Beide aanwijzers moeten *zijn afgeleid van* een aanwijzer naar hetzelfde object.
    ///   (Zie hieronder voor een voorbeeld.)
    ///
    /// * De afstand tussen de aanwijzers, in bytes, moet een exact veelvoud zijn van de grootte van `T`.
    ///
    /// * De afstand tussen de pointers,**in bytes**, kan een `isize` niet overschrijden.
    ///
    /// * De afstand die binnen grenzen is, kan niet vertrouwen op "wrapping around" de adresruimte.
    ///
    /// Rust-typen zijn nooit groter dan `isize::MAX` en Rust-toewijzingen wikkelen zich nooit rond de adresruimte, dus twee verwijzingen binnen een bepaalde waarde van elk Rust-type `T` zullen altijd voldoen aan de laatste twee voorwaarden.
    ///
    /// De standaardbibliotheek zorgt er over het algemeen ook voor dat toewijzingen nooit een grootte bereiken waarbij een offset een probleem is.
    /// `Vec` en `Box` zorgen er bijvoorbeeld voor dat ze nooit meer dan `isize::MAX` bytes toewijzen, dus `ptr_into_vec.offset_from(vec.as_ptr())` voldoet altijd aan de laatste twee voorwaarden.
    ///
    /// De meeste platforms kunnen in wezen niet eens zo'n grote toewijzing construeren.
    /// Geen enkel bekend 64-bits platform kan bijvoorbeeld ooit een verzoek voor 2 <sup>63</sup> bytes verwerken vanwege paginatabelbeperkingen of het opsplitsen van de adresruimte.
    /// Sommige 32-bits en 16-bits platforms kunnen echter met succes een verzoek indienen voor meer dan `isize::MAX` bytes met zaken als Physical Address Extension.
    /// Als zodanig kan geheugen dat rechtstreeks is verkregen van allocators of geheugen toegewezen bestanden * te groot zijn om met deze functie te werken.
    /// (Merk op dat [`offset`] en [`add`] ook een vergelijkbare beperking hebben en daarom ook niet kunnen worden gebruikt voor zulke grote toewijzingen.)
    ///
    /// [`add`]: #method.add
    ///
    /// # Panics
    ///
    /// Deze functie panics als `T` een Zero-Sized Type ("ZST") is.
    ///
    /// # Examples
    ///
    /// Basisgebruik:
    ///
    /// ```
    /// let mut a = [0; 5];
    /// let ptr1: *mut i32 = &mut a[1];
    /// let ptr2: *mut i32 = &mut a[3];
    /// unsafe {
    ///     assert_eq!(ptr2.offset_from(ptr1), 2);
    ///     assert_eq!(ptr1.offset_from(ptr2), -2);
    ///     assert_eq!(ptr1.offset(2), ptr2);
    ///     assert_eq!(ptr2.offset(-2), ptr1);
    /// }
    /// ```
    ///
    /// *Onjuist* gebruik:
    ///
    /// ```rust,no_run
    /// let ptr1 = Box::into_raw(Box::new(0u8));
    /// let ptr2 = Box::into_raw(Box::new(1u8));
    /// let diff = (ptr2 as isize).wrapping_sub(ptr1 as isize);
    /// // Maak ptr2_other een "alias" van ptr2, maar afgeleid van ptr1.
    /// let ptr2_other = (ptr1 as *mut u8).wrapping_offset(diff);
    /// assert_eq!(ptr2 as usize, ptr2_other as usize);
    /// // Aangezien ptr2_other en ptr2 zijn afgeleid van pointers naar verschillende objecten, is het berekenen van hun offset ongedefinieerd gedrag, ook al verwijzen ze naar hetzelfde adres!
    /////
    /////
    /// unsafe {
    ///     let zero = ptr2_other.offset_from(ptr2); // Ongedefinieerd gedrag
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_offset_from", since = "1.47.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    #[inline]
    pub const unsafe fn offset_from(self, origin: *const T) -> isize
    where
        T: Sized,
    {
        // VEILIGHEID: de beller moet zich houden aan het veiligheidscontract voor `offset_from`.
        unsafe { (self as *const T).offset_from(origin) }
    }

    /// Berekent de offset van een aanwijzer (gemak voor `.offset(count as isize)`).
    ///
    /// `count` is in eenheden van T;bijv. een `count` van 3 vertegenwoordigt een pointeroffset van `3 * size_of::<T>()` bytes.
    ///
    /// # Safety
    ///
    /// Als een van de volgende voorwaarden wordt geschonden, is het resultaat Ongedefinieerd gedrag:
    ///
    /// * Zowel de begin-als de resulterende aanwijzer moeten zich binnen grenzen of één byte voorbij het einde van hetzelfde toegewezen object bevinden.
    /// Merk op dat in Rust elke (stack-allocated)-variabele wordt beschouwd als een afzonderlijk toegewezen object.
    ///
    /// * De berekende offset,**in bytes**, kan een `isize` niet overstromen.
    ///
    /// * De offset die binnen grenzen is, kan niet vertrouwen op "wrapping around" de adresruimte.Dat wil zeggen, de som met oneindige precisie moet passen in een `usize`.
    ///
    /// De compiler en de standaardbibliotheek proberen over het algemeen ervoor te zorgen dat toewijzingen nooit een grootte bereiken waarbij een offset een probleem is.
    /// `Vec` en `Box` zorgen er bijvoorbeeld voor dat ze nooit meer dan `isize::MAX` bytes toewijzen, dus `vec.as_ptr().add(vec.len())` is altijd veilig.
    ///
    /// De meeste platforms kunnen in wezen niet eens zo'n toewijzing construeren.
    /// Geen enkel bekend 64-bits platform kan bijvoorbeeld ooit een verzoek voor 2 <sup>63</sup> bytes verwerken vanwege paginatabelbeperkingen of het opsplitsen van de adresruimte.
    /// Sommige 32-bits en 16-bits platforms kunnen echter met succes een verzoek indienen voor meer dan `isize::MAX` bytes met zaken als Physical Address Extension.
    ///
    /// Als zodanig kan geheugen dat rechtstreeks is verkregen van allocators of geheugen toegewezen bestanden * te groot zijn om met deze functie te werken.
    ///
    /// Overweeg in plaats daarvan [`wrapping_add`] te gebruiken als aan deze beperkingen moeilijk te voldoen is.
    /// Het enige voordeel van deze methode is dat het agressievere compiler-optimalisaties mogelijk maakt.
    ///
    /// [`wrapping_add`]: #method.wrapping_add
    ///
    /// # Examples
    ///
    /// Basisgebruik:
    ///
    /// ```
    /// let s: &str = "123";
    /// let ptr: *const u8 = s.as_ptr();
    ///
    /// unsafe {
    ///     println!("{}", *ptr.add(1) as char);
    ///     println!("{}", *ptr.add(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn add(self, count: usize) -> Self
    where
        T: Sized,
    {
        // VEILIGHEID: de beller moet zich houden aan het veiligheidscontract voor `offset`.
        unsafe { self.offset(count as isize) }
    }

    /// Berekent de offset van een aanwijzer (gemak voor `.offset ((tel als isize).wrapping_neg())`).
    ///
    /// `count` is in eenheden van T;bijv. een `count` van 3 vertegenwoordigt een pointeroffset van `3 * size_of::<T>()` bytes.
    ///
    /// # Safety
    ///
    /// Als een van de volgende voorwaarden wordt geschonden, is het resultaat Ongedefinieerd gedrag:
    ///
    /// * Zowel de begin-als de resulterende aanwijzer moeten zich binnen grenzen of één byte voorbij het einde van hetzelfde toegewezen object bevinden.
    /// Merk op dat in Rust elke (stack-allocated)-variabele wordt beschouwd als een afzonderlijk toegewezen object.
    ///
    /// * De berekende offset mag niet groter zijn dan `isize::MAX`**bytes**.
    ///
    /// * De offset die binnen grenzen is, kan niet vertrouwen op "wrapping around" de adresruimte.Dat wil zeggen, de som met oneindige precisie moet passen in een gebruik.
    ///
    /// De compiler en de standaardbibliotheek proberen over het algemeen ervoor te zorgen dat toewijzingen nooit een grootte bereiken waarbij een offset een probleem is.
    /// `Vec` en `Box` zorgen er bijvoorbeeld voor dat ze nooit meer dan `isize::MAX` bytes toewijzen, dus `vec.as_ptr().add(vec.len()).sub(vec.len())` is altijd veilig.
    ///
    /// De meeste platforms kunnen in wezen niet eens zo'n toewijzing construeren.
    /// Geen enkel bekend 64-bits platform kan bijvoorbeeld ooit een verzoek voor 2 <sup>63</sup> bytes verwerken vanwege paginatabelbeperkingen of het opsplitsen van de adresruimte.
    /// Sommige 32-bits en 16-bits platforms kunnen echter met succes een verzoek indienen voor meer dan `isize::MAX` bytes met zaken als Physical Address Extension.
    ///
    /// Als zodanig kan geheugen dat rechtstreeks is verkregen van allocators of geheugen toegewezen bestanden * te groot zijn om met deze functie te werken.
    ///
    /// Overweeg in plaats daarvan [`wrapping_sub`] te gebruiken als aan deze beperkingen moeilijk te voldoen is.
    /// Het enige voordeel van deze methode is dat het agressievere compiler-optimalisaties mogelijk maakt.
    ///
    /// [`wrapping_sub`]: #method.wrapping_sub
    ///
    /// # Examples
    ///
    /// Basisgebruik:
    ///
    /// ```
    /// let s: &str = "123";
    ///
    /// unsafe {
    ///     let end: *const u8 = s.as_ptr().add(3);
    ///     println!("{}", *end.sub(1) as char);
    ///     println!("{}", *end.sub(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn sub(self, count: usize) -> Self
    where
        T: Sized,
    {
        // VEILIGHEID: de beller moet zich houden aan het veiligheidscontract voor `offset`.
        unsafe { self.offset((count as isize).wrapping_neg()) }
    }

    /// Berekent de offset van een aanwijzer met behulp van omloopberekeningen.
    /// (gemak voor `.wrapping_offset(count as isize)`)
    ///
    /// `count` is in eenheden van T;bijv. een `count` van 3 vertegenwoordigt een pointeroffset van `3 * size_of::<T>()` bytes.
    ///
    /// # Safety
    ///
    /// Deze bewerking zelf is altijd veilig, maar het gebruik van de resulterende aanwijzer is dat niet.
    ///
    /// De resulterende aanwijzer blijft gekoppeld aan hetzelfde toegewezen object waarnaar `self` verwijst.
    /// Het mag *niet* worden gebruikt om toegang te krijgen tot een ander toegewezen object.Merk op dat in Rust elke (stack-allocated)-variabele wordt beschouwd als een afzonderlijk toegewezen object.
    ///
    /// Met andere woorden, `let z = x.wrapping_add((y as usize) - (x as usize))` maakt `z`*niet* hetzelfde als `y`, zelfs als we aannemen dat `T` de grootte `1` heeft en er geen overloop is: `z` is nog steeds verbonden met het object waaraan `x` is gekoppeld, en dereferentie is ongedefinieerd gedrag tenzij `x` en `y` wijst naar hetzelfde toegewezen object.
    ///
    /// In vergelijking met [`add`] vertraagt deze methode in feite de vereiste om binnen hetzelfde toegewezen object te blijven: [`add`] is onmiddellijk ongedefinieerd gedrag bij het overschrijden van objectgrenzen;`wrapping_add` produceert een pointer, maar leidt nog steeds tot ongedefinieerd gedrag als een pointer wordt verwijderd wanneer deze buiten het bereik van het object is waaraan het is gekoppeld.
    /// [`add`] kan beter worden geoptimaliseerd en verdient dus de voorkeur in prestatiegevoelige code.
    ///
    /// De vertraagde controle houdt alleen rekening met de waarde van de pointer waarnaar werd verwezen, niet met de tussenliggende waarden die zijn gebruikt tijdens de berekening van het eindresultaat.
    /// `x.wrapping_add(o).wrapping_sub(o)` is bijvoorbeeld altijd hetzelfde als `x`.Met andere woorden, het verlaten van het toegewezen object en het later opnieuw invoeren is toegestaan.
    ///
    /// Als u objectgrenzen moet overschrijden, plaatst u de aanwijzer op een geheel getal en voert u de berekeningen daar uit.
    ///
    /// [`add`]: #method.add
    ///
    /// # Examples
    ///
    /// Basisgebruik:
    ///
    /// ```
    /// // Herhaal met behulp van een onbewerkte aanwijzer in stappen van twee elementen
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let step = 2;
    /// let end_rounded_up = ptr.wrapping_add(6);
    ///
    /// // Deze lus drukt "1, 3, 5, " af
    /// while ptr != end_rounded_up {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_add(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_add(self, count: usize) -> Self
    where
        T: Sized,
    {
        self.wrapping_offset(count as isize)
    }

    /// Berekent de offset van een aanwijzer met behulp van omloopberekeningen.
    /// (gemak voor `.wrapping_offset ((count as isize).wrapping_neg())`)
    ///
    /// `count` is in eenheden van T;bijv. een `count` van 3 vertegenwoordigt een pointeroffset van `3 * size_of::<T>()` bytes.
    ///
    /// # Safety
    ///
    /// Deze bewerking zelf is altijd veilig, maar het gebruik van de resulterende aanwijzer is dat niet.
    ///
    /// De resulterende aanwijzer blijft gekoppeld aan hetzelfde toegewezen object waarnaar `self` verwijst.
    /// Het mag *niet* worden gebruikt om toegang te krijgen tot een ander toegewezen object.Merk op dat in Rust elke (stack-allocated)-variabele wordt beschouwd als een afzonderlijk toegewezen object.
    ///
    /// Met andere woorden, `let z = x.wrapping_sub((x as usize) - (y as usize))` maakt `z`*niet* hetzelfde als `y`, zelfs als we aannemen dat `T` de grootte `1` heeft en er geen overloop is: `z` is nog steeds verbonden met het object waaraan `x` is gekoppeld, en dereferentie is ongedefinieerd gedrag tenzij `x` en `y` wijst naar hetzelfde toegewezen object.
    ///
    /// In vergelijking met [`sub`] vertraagt deze methode in feite de vereiste om binnen hetzelfde toegewezen object te blijven: [`sub`] is onmiddellijk ongedefinieerd gedrag bij het overschrijden van objectgrenzen;`wrapping_sub` produceert een pointer, maar leidt nog steeds tot ongedefinieerd gedrag als een pointer wordt verwijderd wanneer deze buiten het bereik van het object is waaraan het is gekoppeld.
    /// [`sub`] kan beter worden geoptimaliseerd en verdient dus de voorkeur in prestatiegevoelige code.
    ///
    /// De vertraagde controle houdt alleen rekening met de waarde van de pointer waarnaar werd verwezen, niet met de tussenliggende waarden die zijn gebruikt tijdens de berekening van het eindresultaat.
    /// `x.wrapping_add(o).wrapping_sub(o)` is bijvoorbeeld altijd hetzelfde als `x`.Met andere woorden, het verlaten van het toegewezen object en het later opnieuw invoeren is toegestaan.
    ///
    /// Als u objectgrenzen moet overschrijden, plaatst u de aanwijzer op een geheel getal en voert u de berekeningen daar uit.
    ///
    /// [`sub`]: #method.sub
    ///
    /// # Examples
    ///
    /// Basisgebruik:
    ///
    /// ```
    /// // Herhaal met behulp van een onbewerkte pointer in stappen van twee elementen (backwards)
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let start_rounded_down = ptr.wrapping_sub(2);
    /// ptr = ptr.wrapping_add(4);
    /// let step = 2;
    /// // Deze lus drukt "5, 3, 1, " af
    /// while ptr != start_rounded_down {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_sub(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_sub(self, count: usize) -> Self
    where
        T: Sized,
    {
        self.wrapping_offset((count as isize).wrapping_neg())
    }

    /// Stelt de aanwijzerwaarde in op `ptr`.
    ///
    /// In het geval dat `self` een (fat)-pointer naar een niet-formaat type is, heeft deze bewerking alleen invloed op het pointergedeelte, terwijl dit voor (thin)-wijzers naar een formaattype hetzelfde effect heeft als een eenvoudige toewijzing.
    ///
    /// De resulterende pointer heeft de herkomst `val`, dwz voor een fat pointer is deze bewerking semantisch hetzelfde als het maken van een nieuwe fat pointer met de data pointer-waarde van `val` maar de metadata van `self`.
    ///
    ///
    /// # Examples
    ///
    /// Deze functie is vooral handig om bytesgewijze aanwijzerberekeningen toe te staan op mogelijk dikke aanwijzers:
    ///
    /// ```
    /// #![feature(set_ptr_value)]
    /// # use core::fmt::Debug;
    /// let mut arr: [i32; 3] = [1, 2, 3];
    /// let mut ptr = &mut arr[0] as *mut dyn Debug;
    /// let thin = ptr as *mut u8;
    /// unsafe {
    ///     ptr = ptr.set_ptr_value(thin.add(8));
    ///     # assert_eq!(*(ptr as *mut i32), 3);
    ///     println!("{:?}", &*ptr); // zal "3" afdrukken
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "set_ptr_value", issue = "75091")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[inline]
    pub fn set_ptr_value(mut self, val: *mut u8) -> Self {
        let thin = &mut self as *mut *mut T as *mut *mut u8;
        // VEILIGHEID: In het geval van een dunne aanwijzer is deze handeling identiek
        // tot een eenvoudige opdracht.
        // In het geval van een fat pointer, met de huidige fat pointer layout-implementatie, is het eerste veld van zo'n pointer altijd de data pointer, die eveneens is toegewezen.
        //
        unsafe { *thin = val };
        self
    }

    /// Leest de waarde van `self` zonder deze te verplaatsen.
    /// Dit laat het geheugen in `self` ongewijzigd.
    ///
    /// Zie [`ptr::read`] voor veiligheidsoverwegingen en voorbeelden.
    ///
    /// [`ptr::read`]: crate::ptr::read()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
    #[inline]
    pub const unsafe fn read(self) -> T
    where
        T: Sized,
    {
        // VEILIGHEID: de beller moet zich houden aan het veiligheidscontract voor ``.
        unsafe { read(self) }
    }

    /// Voert een vluchtige aflezing uit van de waarde van `self` zonder deze te verplaatsen.Dit laat het geheugen in `self` ongewijzigd.
    ///
    /// Vluchtige bewerkingen zijn bedoeld om in te werken op het I/O-geheugen en worden gegarandeerd niet weggelaten of opnieuw gerangschikt door de compiler voor andere vluchtige bewerkingen.
    ///
    ///
    /// Zie [`ptr::read_volatile`] voor veiligheidsoverwegingen en voorbeelden.
    ///
    /// [`ptr::read_volatile`]: crate::ptr::read_volatile()
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn read_volatile(self) -> T
    where
        T: Sized,
    {
        // VEILIGHEID: de beller moet zich houden aan het veiligheidscontract voor `read_volatile`.
        unsafe { read_volatile(self) }
    }

    /// Leest de waarde van `self` zonder deze te verplaatsen.
    /// Dit laat het geheugen in `self` ongewijzigd.
    ///
    /// In tegenstelling tot `read` is de aanwijzer mogelijk niet uitgelijnd.
    ///
    /// Zie [`ptr::read_unaligned`] voor veiligheidsoverwegingen en voorbeelden.
    ///
    /// [`ptr::read_unaligned`]: crate::ptr::read_unaligned()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
    #[inline]
    pub const unsafe fn read_unaligned(self) -> T
    where
        T: Sized,
    {
        // VEILIGHEID: de beller moet zich houden aan het veiligheidscontract voor `read_unaligned`.
        unsafe { read_unaligned(self) }
    }

    /// Kopieert `count * size_of<T>`-bytes van `self` naar `dest`.
    /// De bron en de bestemming kunnen elkaar overlappen.
    ///
    /// NOTE: dit heeft dezelfde * argumentvolgorde als [`ptr::copy`].
    ///
    /// Zie [`ptr::copy`] voor veiligheidsoverwegingen en voorbeelden.
    ///
    /// [`ptr::copy`]: crate::ptr::copy()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_to(self, dest: *mut T, count: usize)
    where
        T: Sized,
    {
        // VEILIGHEID: de beller moet zich houden aan het veiligheidscontract voor `copy`.
        unsafe { copy(self, dest, count) }
    }

    /// Kopieert `count * size_of<T>`-bytes van `self` naar `dest`.
    /// De bron en de bestemming mogen *niet* elkaar overlappen.
    ///
    /// NOTE: dit heeft dezelfde * argumentvolgorde als [`ptr::copy_nonoverlapping`].
    ///
    /// Zie [`ptr::copy_nonoverlapping`] voor veiligheidsoverwegingen en voorbeelden.
    ///
    /// [`ptr::copy_nonoverlapping`]: crate::ptr::copy_nonoverlapping()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_to_nonoverlapping(self, dest: *mut T, count: usize)
    where
        T: Sized,
    {
        // VEILIGHEID: de beller moet zich houden aan het veiligheidscontract voor `copy_nonoverlapping`.
        unsafe { copy_nonoverlapping(self, dest, count) }
    }

    /// Kopieert `count * size_of<T>`-bytes van `src` naar `self`.
    /// De bron en de bestemming kunnen elkaar overlappen.
    ///
    /// NOTE: dit heeft de *tegenovergestelde* argumentvolgorde van [`ptr::copy`].
    ///
    /// Zie [`ptr::copy`] voor veiligheidsoverwegingen en voorbeelden.
    ///
    /// [`ptr::copy`]: crate::ptr::copy()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_from(self, src: *const T, count: usize)
    where
        T: Sized,
    {
        // VEILIGHEID: de beller moet zich houden aan het veiligheidscontract voor `copy`.
        unsafe { copy(src, self, count) }
    }

    /// Kopieert `count * size_of<T>`-bytes van `src` naar `self`.
    /// De bron en de bestemming mogen *niet* elkaar overlappen.
    ///
    /// NOTE: dit heeft de *tegenovergestelde* argumentvolgorde van [`ptr::copy_nonoverlapping`].
    ///
    /// Zie [`ptr::copy_nonoverlapping`] voor veiligheidsoverwegingen en voorbeelden.
    ///
    /// [`ptr::copy_nonoverlapping`]: crate::ptr::copy_nonoverlapping()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_from_nonoverlapping(self, src: *const T, count: usize)
    where
        T: Sized,
    {
        // VEILIGHEID: de beller moet zich houden aan het veiligheidscontract voor `copy_nonoverlapping`.
        unsafe { copy_nonoverlapping(src, self, count) }
    }

    /// Voert de destructor (indien aanwezig) van de gewezen waarde uit.
    ///
    /// Zie [`ptr::drop_in_place`] voor veiligheidsoverwegingen en voorbeelden.
    ///
    /// [`ptr::drop_in_place`]: crate::ptr::drop_in_place()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn drop_in_place(self) {
        // VEILIGHEID: de beller moet zich houden aan het veiligheidscontract voor `drop_in_place`.
        unsafe { drop_in_place(self) }
    }

    /// Overschrijft een geheugenlocatie met de gegeven waarde zonder de oude waarde te lezen of te laten vallen.
    ///
    ///
    /// Zie [`ptr::write`] voor veiligheidsoverwegingen en voorbeelden.
    ///
    /// [`ptr::write`]: crate::ptr::write()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn write(self, val: T)
    where
        T: Sized,
    {
        // VEILIGHEID: de beller moet zich houden aan het veiligheidscontract voor `write`.
        unsafe { write(self, val) }
    }

    /// Roept memset op de opgegeven pointer aan, waarbij `count * size_of::<T>()`-bytes geheugen worden ingesteld, beginnend bij `self` tot `val`.
    ///
    ///
    /// Zie [`ptr::write_bytes`] voor veiligheidsoverwegingen en voorbeelden.
    ///
    /// [`ptr::write_bytes`]: crate::ptr::write_bytes()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn write_bytes(self, val: u8, count: usize)
    where
        T: Sized,
    {
        // VEILIGHEID: de beller moet zich houden aan het veiligheidscontract voor `write_bytes`.
        unsafe { write_bytes(self, val, count) }
    }

    /// Voert een vluchtige schrijfbewerking uit van een geheugenlocatie met de opgegeven waarde zonder de oude waarde te lezen of te laten vallen.
    ///
    /// Vluchtige bewerkingen zijn bedoeld om in te werken op het I/O-geheugen en worden gegarandeerd niet weggelaten of opnieuw gerangschikt door de compiler voor andere vluchtige bewerkingen.
    ///
    ///
    /// Zie [`ptr::write_volatile`] voor veiligheidsoverwegingen en voorbeelden.
    ///
    /// [`ptr::write_volatile`]: crate::ptr::write_volatile()
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn write_volatile(self, val: T)
    where
        T: Sized,
    {
        // VEILIGHEID: de beller moet zich houden aan het veiligheidscontract voor `write_volatile`.
        unsafe { write_volatile(self, val) }
    }

    /// Overschrijft een geheugenlocatie met de gegeven waarde zonder de oude waarde te lezen of te laten vallen.
    ///
    ///
    /// In tegenstelling tot `write` is de aanwijzer mogelijk niet uitgelijnd.
    ///
    /// Zie [`ptr::write_unaligned`] voor veiligheidsoverwegingen en voorbeelden.
    ///
    /// [`ptr::write_unaligned`]: crate::ptr::write_unaligned()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_write", issue = "none")]
    #[inline]
    pub const unsafe fn write_unaligned(self, val: T)
    where
        T: Sized,
    {
        // VEILIGHEID: de beller moet zich houden aan het veiligheidscontract voor `write_unaligned`.
        unsafe { write_unaligned(self, val) }
    }

    /// Vervangt de waarde op `self` door `src`, waarbij de oude waarde wordt geretourneerd, zonder ook maar iets te laten vallen.
    ///
    ///
    /// Zie [`ptr::replace`] voor veiligheidsoverwegingen en voorbeelden.
    ///
    /// [`ptr::replace`]: crate::ptr::replace()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn replace(self, src: T) -> T
    where
        T: Sized,
    {
        // VEILIGHEID: de beller moet zich houden aan het veiligheidscontract voor `replace`.
        unsafe { replace(self, src) }
    }

    /// Verwisselt de waarden op twee veranderlijke locaties van hetzelfde type, zonder ook te de-initialiseren.
    /// Ze kunnen elkaar overlappen, in tegenstelling tot `mem::swap`, dat verder equivalent is.
    ///
    /// Zie [`ptr::swap`] voor veiligheidsoverwegingen en voorbeelden.
    ///
    /// [`ptr::swap`]: crate::ptr::swap()
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn swap(self, with: *mut T)
    where
        T: Sized,
    {
        // VEILIGHEID: de beller moet zich houden aan het veiligheidscontract voor `swap`.
        unsafe { swap(self, with) }
    }

    /// Berekent de offset die moet worden toegepast op de aanwijzer om deze uit te lijnen met `align`.
    ///
    /// Als het niet mogelijk is om de pointer uit te lijnen, retourneert de implementatie `usize::MAX`.
    /// Het is toegestaan dat de implementatie *altijd*`usize::MAX` retourneert.
    /// Alleen de prestaties van uw algoritme kunnen afhangen van het verkrijgen van een bruikbare compensatie hier, niet van de juistheid ervan.
    ///
    /// De offset wordt uitgedrukt in aantal `T`-elementen, en niet in bytes.De geretourneerde waarde kan worden gebruikt met de `wrapping_add`-methode.
    ///
    /// Er zijn geen enkele garanties dat het verschuiven van de aanwijzer niet overloopt of verder gaat dan de toewijzing waarnaar de aanwijzer verwijst.
    ///
    /// Het is aan de beller om ervoor te zorgen dat de geretourneerde offset correct is in alle termen behalve uitlijning.
    ///
    /// # Panics
    ///
    /// De functie panics als `align` geen macht van twee is.
    ///
    /// # Examples
    ///
    /// Toegang tot aangrenzende `u8` als `u16`
    ///
    /// ```
    /// # fn foo(n: usize) {
    /// # use std::mem::align_of;
    /// # unsafe {
    /// let x = [5u8, 6u8, 7u8, 8u8, 9u8];
    /// let ptr = x.as_ptr().add(n) as *const u8;
    /// let offset = ptr.align_offset(align_of::<u16>());
    /// if offset < x.len() - n - 1 {
    ///     let u16_ptr = ptr.add(offset) as *const u16;
    ///     assert_ne!(*u16_ptr, 500);
    /// } else {
    ///     // terwijl de aanwijzer kan worden uitgelijnd via `offset`, zou hij buiten de toewijzing wijzen
    /////
    /// }
    /// # } }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "align_offset", since = "1.36.0")]
    pub fn align_offset(self, align: usize) -> usize
    where
        T: Sized,
    {
        if !align.is_power_of_two() {
            panic!("align_offset: align is not a power-of-two");
        }
        // VEILIGHEID: `align` is gecontroleerd als een macht van 2 hierboven
        unsafe { align_offset(self, align) }
    }
}

#[lang = "mut_slice_ptr"]
impl<T> *mut [T] {
    /// Retourneert de lengte van een onbewerkt segment.
    ///
    /// De geretourneerde waarde is het aantal **elementen**, niet het aantal bytes.
    ///
    /// Deze functie is veilig, zelfs als de onbewerkte plak niet naar een plakverwijzing kan worden gecast omdat de aanwijzer nul of niet uitgelijnd is.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len)]
    /// use std::ptr;
    ///
    /// let slice: *mut [i8] = ptr::slice_from_raw_parts_mut(ptr::null_mut(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    pub const fn len(self) -> usize {
        #[cfg(bootstrap)]
        {
            // VEILIGHEID: dit is veilig omdat `*const [T]` en `FatPtr<T>` dezelfde lay-out hebben.
            // Alleen `std` kan deze garantie geven.
            unsafe { Repr { rust_mut: self }.raw }.len
        }
        #[cfg(not(bootstrap))]
        metadata(self)
    }

    /// Retourneert een onbewerkte aanwijzer naar de buffer van het segment.
    ///
    /// Dit komt overeen met het casten van `self` naar `*mut T`, maar meer type-veilig.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get)]
    /// use std::ptr;
    ///
    /// let slice: *mut [i8] = ptr::slice_from_raw_parts_mut(ptr::null_mut(), 3);
    /// assert_eq!(slice.as_mut_ptr(), 0 as *mut i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_mut_ptr(self) -> *mut T {
        self as *mut T
    }

    /// Retourneert een onbewerkte pointer naar een element of subslice, zonder de grenzen te controleren.
    ///
    /// Het aanroepen van deze methode met een out-of-bounds index of wanneer `self` niet kan worden afgeleid, is *[ongedefinieerd gedrag]* zelfs als de resulterende pointer niet wordt gebruikt.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get)]
    ///
    /// let x = &mut [1, 2, 4] as *mut [i32];
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked_mut(1), x.as_mut_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(self, index: I) -> *mut I::Output
    where
        I: SliceIndex<[T]>,
    {
        // VEILIGHEID: de beller zorgt ervoor dat `self` niet kan worden verwezen en `index` in-bounds is.
        unsafe { index.get_unchecked_mut(self) }
    }

    /// Retourneert `None` als de pointer null is, of retourneert een gedeeld segment naar de waarde verpakt in `Some`.
    /// In tegenstelling tot [`as_ref`] hoeft de waarde hiervoor niet te worden geïnitialiseerd.
    ///
    /// Zie [`as_uninit_slice_mut`] voor de veranderlijke tegenhanger.
    ///
    /// [`as_ref`]: #method.as_ref-1
    /// [`as_uninit_slice_mut`]: #method.as_uninit_slice_mut
    ///
    /// # Safety
    ///
    /// Wanneer u deze methode aanroept, moet u ervoor zorgen dat *ofwel* de aanwijzer NULL is *of* dat al het volgende waar is:
    ///
    /// * De pointer moet [valid] zijn voor leesbewerkingen voor `ptr.len() * mem::size_of::<T>()` vele bytes, en hij moet correct zijn uitgelijnd.Dit betekent in het bijzonder:
    ///
    ///     * Het volledige geheugenbereik van deze slice moet zich in een enkel toegewezen object bevinden!
    ///       Segmenten kunnen nooit meerdere toegewezen objecten omvatten.
    ///
    ///     * De aanwijzer moet worden uitgelijnd, zelfs voor segmenten met een lengte van nul.
    ///     Een reden hiervoor is dat optimalisaties van de lay-out van de opsomming mogelijk afhankelijk zijn van verwijzingen (inclusief segmenten van elke lengte) die zijn uitgelijnd en niet nul zijn om ze te onderscheiden van andere gegevens.
    ///
    ///     U kunt een aanwijzer verkrijgen die bruikbaar is als `data` voor segmenten met een lengte van nul met behulp van [`NonNull::dangling()`].
    ///
    /// * De totale grootte `ptr.len() * mem::size_of::<T>()` van het segment mag niet groter zijn dan `isize::MAX`.
    ///   Zie de veiligheidsdocumentatie van [`pointer::offset`].
    ///
    /// * U moet de aliasingregels van Rust afdwingen, aangezien de geretourneerde levensduur `'a` willekeurig wordt gekozen en niet noodzakelijk de werkelijke levensduur van de gegevens weerspiegelt.
    ///   In het bijzonder, gedurende deze levensduur, mag het geheugen waarnaar de aanwijzer verwijst niet worden gemuteerd (behalve binnen `UnsafeCell`).
    ///
    /// Dit geldt zelfs als het resultaat van deze methode niet wordt gebruikt!
    ///
    /// Zie ook [`slice::from_raw_parts`][].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice<'a>(self) -> Option<&'a [MaybeUninit<T>]> {
        if self.is_null() {
            None
        } else {
            // VEILIGHEID: de beller moet zich houden aan het veiligheidscontract voor `as_uninit_slice`.
            Some(unsafe { slice::from_raw_parts(self as *const MaybeUninit<T>, self.len()) })
        }
    }

    /// Retourneert `None` als de pointer null is, of retourneert een uniek segment naar de waarde verpakt in `Some`.
    /// In tegenstelling tot [`as_mut`] hoeft de waarde hiervoor niet te worden geïnitialiseerd.
    ///
    /// Zie [`as_uninit_slice`] voor de gedeelde tegenhanger.
    ///
    /// [`as_mut`]: #method.as_mut
    /// [`as_uninit_slice`]: #method.as_uninit_slice-1
    ///
    /// # Safety
    ///
    /// Wanneer u deze methode aanroept, moet u ervoor zorgen dat *ofwel* de aanwijzer NULL is *of* dat al het volgende waar is:
    ///
    /// * De pointer moet [valid] zijn voor lees-en schrijfbewerkingen voor `ptr.len() * mem::size_of::<T>()` vele bytes, en hij moet correct zijn uitgelijnd.Dit betekent in het bijzonder:
    ///
    ///     * Het volledige geheugenbereik van deze slice moet zich in een enkel toegewezen object bevinden!
    ///       Segmenten kunnen nooit meerdere toegewezen objecten omvatten.
    ///
    ///     * De aanwijzer moet worden uitgelijnd, zelfs voor segmenten met een lengte van nul.
    ///     Een reden hiervoor is dat optimalisaties van de lay-out van de opsomming mogelijk afhankelijk zijn van verwijzingen (inclusief segmenten van elke lengte) die zijn uitgelijnd en niet nul zijn om ze te onderscheiden van andere gegevens.
    ///
    ///     U kunt een aanwijzer verkrijgen die bruikbaar is als `data` voor segmenten met een lengte van nul met behulp van [`NonNull::dangling()`].
    ///
    /// * De totale grootte `ptr.len() * mem::size_of::<T>()` van het segment mag niet groter zijn dan `isize::MAX`.
    ///   Zie de veiligheidsdocumentatie van [`pointer::offset`].
    ///
    /// * U moet de aliasingregels van Rust afdwingen, aangezien de geretourneerde levensduur `'a` willekeurig wordt gekozen en niet noodzakelijk de werkelijke levensduur van de gegevens weerspiegelt.
    ///   In het bijzonder mag het geheugen waarnaar de aanwijzer verwijst, gedurende deze levensduur niet worden geopend (gelezen of geschreven) via een andere aanwijzer.
    ///
    /// Dit geldt zelfs als het resultaat van deze methode niet wordt gebruikt!
    ///
    /// Zie ook [`slice::from_raw_parts_mut`][].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice_mut<'a>(self) -> Option<&'a mut [MaybeUninit<T>]> {
        if self.is_null() {
            None
        } else {
            // VEILIGHEID: de beller moet zich houden aan het veiligheidscontract voor `as_uninit_slice_mut`.
            Some(unsafe { slice::from_raw_parts_mut(self as *mut MaybeUninit<T>, self.len()) })
        }
    }
}

// Gelijkheid voor aanwijzingen
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> PartialEq for *mut T {
    #[inline]
    fn eq(&self, other: &*mut T) -> bool {
        *self == *other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Eq for *mut T {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Ord for *mut T {
    #[inline]
    fn cmp(&self, other: &*mut T) -> Ordering {
        if self < other {
            Less
        } else if self == other {
            Equal
        } else {
            Greater
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> PartialOrd for *mut T {
    #[inline]
    fn partial_cmp(&self, other: &*mut T) -> Option<Ordering> {
        Some(self.cmp(other))
    }

    #[inline]
    fn lt(&self, other: &*mut T) -> bool {
        *self < *other
    }

    #[inline]
    fn le(&self, other: &*mut T) -> bool {
        *self <= *other
    }

    #[inline]
    fn gt(&self, other: &*mut T) -> bool {
        *self > *other
    }

    #[inline]
    fn ge(&self, other: &*mut T) -> bool {
        *self >= *other
    }
}