//! Beheer het geheugen handmatig door middel van onbewerkte aanwijzingen.
//!
//! *[See also the pointer primitive types](pointer).*
//!
//! # Safety
//!
//! Veel functies in deze module nemen onbewerkte verwijzingen als argumenten en lezen van of schrijven ernaar.Om dit veilig te laten zijn, moeten deze aanwijzingen *geldig* zijn.
//! Of een pointer geldig is, hangt af van de bewerking waarvoor deze wordt gebruikt (lezen of schrijven) en de omvang van het geheugen dat wordt benaderd (dwz hoeveel bytes zijn read/written).
//! De meeste functies gebruiken `*mut T` en `* const T` om slechts één waarde te benaderen, in welk geval de documentatie de grootte weglaat en impliciet aanneemt dat het `size_of::<T>()` bytes zijn.
//!
//! De precieze regels voor geldigheid zijn nog niet bepaald.De garanties die op dit punt worden geboden, zijn zeer minimaal:
//!
//! * Een [null]-pointer is *nooit* geldig, zelfs niet voor toegang tot [size zero][zst].
//! * Om een pointer geldig te laten zijn, is het noodzakelijk, maar niet altijd voldoende, dat de pointer *niet-verwijsbaar* is: het geheugenbereik van de gegeven grootte, beginnend bij de pointer, moet allemaal binnen de grenzen van een enkel toegewezen object liggen.
//!
//! Merk op dat in Rust elke (stack-allocated)-variabele wordt beschouwd als een afzonderlijk toegewezen object.
//! * Zelfs voor bewerkingen van [size zero][zst], mag de pointer niet naar niet-toegewezen geheugen wijzen, dwz dat de toewijzing van de toewijzing aanwijzers ongeldig maakt, zelfs voor bewerkingen ter grootte van nul.
//! Het casten van elk niet-nul geheel getal *letterlijk* naar een pointer is echter geldig voor toegangen met een grootte van nul, zelfs als er op dat adres geheugen aanwezig is en de toewijzing wordt opgeheven.
//! Dit komt overeen met het schrijven van uw eigen allocator: het toewijzen van objecten ter grootte van nul is niet erg moeilijk.
//! De canonieke manier om een aanwijzer te verkrijgen die geldig is voor toegangen met een grootte van nul, is [`NonNull::dangling`].
//! * Alle toegangen die worden uitgevoerd door functies in deze module zijn *niet-atomair* in de zin van [atomic operations] die wordt gebruikt om te synchroniseren tussen threads.
//! Dit betekent dat het ongedefinieerd gedrag is om twee gelijktijdige toegangen uit te voeren naar dezelfde locatie vanaf verschillende threads, tenzij beide toegangen alleen uit het geheugen worden gelezen.
//! Merk op dat dit expliciet [`read_volatile`] en [`write_volatile`] omvat: vluchtige toegangen kunnen niet worden gebruikt voor synchronisatie tussen threads.
//! * Het resultaat van het casten van een verwijzing naar een aanwijzer is geldig zolang het onderliggende object live is en er geen verwijzing (alleen onbewerkte aanwijzers) wordt gebruikt om toegang te krijgen tot hetzelfde geheugen.
//!
//! Deze axioma's, samen met een zorgvuldig gebruik van [`offset`] voor aanwijzerberekeningen, zijn voldoende om veel nuttige dingen correct in onveilige code te implementeren.
//! Naarmate de [aliasing]-regels worden bepaald, zullen uiteindelijk sterkere garanties worden geboden.
//! Zie voor meer informatie de [book] en de sectie in de referentie over [undefined behavior][ub].
//!
//! ## Alignment
//!
//! Geldige onbewerkte aanwijzers zoals hierboven gedefinieerd zijn niet noodzakelijk correct uitgelijnd (waarbij "proper"-uitlijning wordt gedefinieerd door het puntentype, dwz `*const T` moet worden uitgelijnd met `mem::align_of::<T>()`).
//! De meeste functies vereisen echter dat hun argumenten correct zijn uitgelijnd, en zullen deze vereiste expliciet vermelden in hun documentatie.
//! Opvallende uitzonderingen hierop zijn [`read_unaligned`] en [`write_unaligned`].
//!
//! Wanneer een functie een juiste uitlijning vereist, gebeurt dit zelfs als de toegang de grootte 0 heeft, dwz zelfs als het geheugen niet daadwerkelijk wordt aangeraakt.Overweeg in dergelijke gevallen [`NonNull::dangling`] te gebruiken.
//!
//! [aliasing]: ../../nomicon/aliasing.html
//! [book]: ../../book/ch19-01-unsafe-rust.html#dereferencing-a-raw-pointer
//! [ub]: ../../reference/behavior-considered-undefined.html
//! [zst]: ../../nomicon/exotic-sizes.html#zero-sized-types-zsts
//! [atomic operations]: crate::sync::atomic
//! [`offset`]: pointer::offset
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering;
use crate::fmt;
use crate::hash;
use crate::intrinsics::{self, abort, is_aligned_and_not_null};
use crate::mem::{self, MaybeUninit};

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::copy_nonoverlapping;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::copy;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::write_bytes;

#[cfg(not(bootstrap))]
mod metadata;
#[cfg(not(bootstrap))]
pub(crate) use metadata::PtrRepr;
#[cfg(not(bootstrap))]
#[unstable(feature = "ptr_metadata", issue = "81513")]
pub use metadata::{from_raw_parts, from_raw_parts_mut, metadata, DynMetadata, Pointee, Thin};

mod non_null;
#[stable(feature = "nonnull", since = "1.25.0")]
pub use non_null::NonNull;

mod unique;
#[unstable(feature = "ptr_internals", issue = "none")]
pub use unique::Unique;

mod const_ptr;
mod mut_ptr;

/// Voert de destructor (indien aanwezig) van de gewezen waarde uit.
///
/// Dit is semantisch equivalent aan het aanroepen van [`ptr::read`] en het negeren van het resultaat, maar heeft de volgende voordelen:
///
/// * Het is *vereist* om `drop_in_place` te gebruiken om niet-formaat typen zoals trait-objecten te verwijderen, omdat ze niet op de stapel kunnen worden uitgelezen en normaal kunnen worden neergezet.
///
/// * Het is vriendelijker voor de optimizer om dit te doen boven [`ptr::read`] wanneer handmatig toegewezen geheugen wordt verwijderd (bijv. In de implementaties van `Box`/`Rc`/`Vec`), aangezien de compiler niet hoeft te bewijzen dat het geluid klopt om de kopie te verwijderen.
///
///
/// * Het kan worden gebruikt om [pinned]-gegevens te verwijderen wanneer `T` niet `repr(packed)` is (vastgezette gegevens mogen niet worden verplaatst voordat ze worden verwijderd).
///
/// Niet-uitgelijnde waarden kunnen niet op hun plaats worden neergezet, ze moeten eerst met [`ptr::read_unaligned`] naar een uitgelijnde locatie worden gekopieerd.Voor verpakte structs wordt deze verplaatsing automatisch gedaan door de compiler.
/// Dit betekent dat de velden met verpakte structs niet op hun plaats vallen.
///
/// [`ptr::read`]: self::read
/// [`ptr::read_unaligned`]: self::read_unaligned
/// [pinned]: crate::pin
///
/// # Safety
///
/// Gedrag is niet gedefinieerd als een van de volgende voorwaarden wordt geschonden:
///
/// * `to_drop` moet [valid] zijn voor zowel lees-als schrijfbewerkingen.
///
/// * `to_drop` moet correct zijn uitgelijnd.
///
/// * De waarde waarnaar `to_drop` verwijst, moet geldig zijn voor het laten vallen, wat kan betekenen dat het aanvullende invarianten moet handhaven, dit is type-afhankelijk.
///
/// Bovendien, als `T` niet [`Copy`] is, kan het gebruik van de aanwijzende waarde na het aanroepen van `drop_in_place` ongedefinieerd gedrag veroorzaken.Merk op dat `*to_drop = foo` telt als een gebruik, omdat hierdoor de waarde weer wordt verwijderd.
/// [`write()`] kan worden gebruikt om gegevens te overschrijven zonder dat deze worden verwijderd.
///
/// Merk op dat zelfs als `T` de grootte `0` heeft, de aanwijzer niet-NULL moet zijn en correct uitgelijnd.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Verwijder handmatig het laatste item uit een vector:
///
/// ```
/// use std::ptr;
/// use std::rc::Rc;
///
/// let last = Rc::new(1);
/// let weak = Rc::downgrade(&last);
///
/// let mut v = vec![Rc::new(0), last];
///
/// unsafe {
///     // Haal een onbewerkte pointer naar het laatste element in `v`.
///     let ptr = &mut v[1] as *mut _;
///     // Verkort `v` om te voorkomen dat het laatste item valt.
///     // Dat doen we eerst om problemen te voorkomen als de `drop_in_place` onder panics.
///     v.set_len(1);
///     // Zonder een oproep `drop_in_place` zou het laatste item nooit worden verwijderd en zou het geheugen dat het beheert, worden gelekt.
/////
///     ptr::drop_in_place(ptr);
/// }
///
/// assert_eq!(v, &[0.into()]);
///
/// // Zorg ervoor dat het laatste item is verwijderd.
/// assert!(weak.upgrade().is_none());
/// ```
///
/// Merk op dat de compiler deze kopie automatisch uitvoert bij het droppen van ingepakte structs, dwz dat u zich gewoonlijk geen zorgen hoeft te maken over dergelijke problemen, tenzij u `drop_in_place` handmatig aanroept.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "drop_in_place", since = "1.8.0")]
#[lang = "drop_in_place"]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // Code maakt hier niet uit, deze wordt door de compiler vervangen door de echte droplijm.
    //

    // VEILIGHEID: zie opmerking hierboven
    unsafe { drop_in_place(to_drop) }
}

/// Creëert een null-onbewerkte aanwijzer.
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let p: *const i32 = ptr::null();
/// assert!(p.is_null());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_ptr_null", since = "1.32.0")]
pub const fn null<T>() -> *const T {
    0 as *const T
}

/// Creëert een nul veranderlijke onbewerkte aanwijzer.
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let p: *mut i32 = ptr::null_mut();
/// assert!(p.is_null());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_ptr_null", since = "1.32.0")]
pub const fn null_mut<T>() -> *mut T {
    0 as *mut T
}

#[cfg(bootstrap)]
#[repr(C)]
pub(crate) union Repr<T> {
    pub(crate) rust: *const [T],
    rust_mut: *mut [T],
    pub(crate) raw: FatPtr<T>,
}

#[cfg(bootstrap)]
#[repr(C)]
pub(crate) struct FatPtr<T> {
    data: *const T,
    pub(crate) len: usize,
}

#[cfg(bootstrap)]
// Handmatige impl nodig om `T: Clone`-gebonden te vermijden.
impl<T> Clone for FatPtr<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[cfg(bootstrap)]
// Handmatige impl nodig om `T: Copy`-gebonden te vermijden.
impl<T> Copy for FatPtr<T> {}

/// Vormt een onbewerkte plak van een aanwijzer en een lengte.
///
/// Het `len`-argument is het aantal **elementen**, niet het aantal bytes.
///
/// Deze functie is veilig, maar het daadwerkelijk gebruiken van de retourwaarde is onveilig.
/// Zie de documentatie van [`slice::from_raw_parts`] voor veiligheidsvereisten voor segmenten.
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
///
/// # Examples
///
/// ```rust
/// use std::ptr;
///
/// // maak een slice-aanwijzer wanneer u begint met een aanwijzer naar het eerste element
/// let x = [5, 6, 7];
/// let raw_pointer = x.as_ptr();
/// let slice = ptr::slice_from_raw_parts(raw_pointer, 3);
/// assert_eq!(unsafe { &*slice }[2], 7);
/// ```
#[inline]
#[stable(feature = "slice_from_raw_parts", since = "1.42.0")]
#[rustc_const_unstable(feature = "const_slice_from_raw_parts", issue = "67456")]
pub const fn slice_from_raw_parts<T>(data: *const T, len: usize) -> *const [T] {
    #[cfg(bootstrap)]
    {
        // VEILIGHEID: Toegang tot de waarde van de `Repr`-unie is veilig sinds * const [T]
        //
        // en FatPtr hebben dezelfde geheugenlay-outs.Alleen std kan deze garantie geven.
        unsafe { Repr { raw: FatPtr { data, len } }.rust }
    }
    #[cfg(not(bootstrap))]
    from_raw_parts(data.cast(), len)
}

/// Voert dezelfde functionaliteit uit als [`slice_from_raw_parts`], behalve dat een onbewerkte veranderlijke plak wordt geretourneerd, in tegenstelling tot een onbewerkte, onveranderlijke plak.
///
///
/// Zie de documentatie van [`slice_from_raw_parts`] voor meer details.
///
/// Deze functie is veilig, maar het daadwerkelijk gebruiken van de retourwaarde is onveilig.
/// Zie de documentatie van [`slice::from_raw_parts_mut`] voor veiligheidsvereisten voor segmenten.
///
/// [`slice::from_raw_parts_mut`]: crate::slice::from_raw_parts_mut
///
/// # Examples
///
/// ```rust
/// use std::ptr;
///
/// let x = &mut [5, 6, 7];
/// let raw_pointer = x.as_mut_ptr();
/// let slice = ptr::slice_from_raw_parts_mut(raw_pointer, 3);
///
/// unsafe {
///     (*slice)[2] = 99; // wijs een waarde toe aan een index in het segment
/// };
///
/// assert_eq!(unsafe { &*slice }[2], 99);
/// ```
#[inline]
#[stable(feature = "slice_from_raw_parts", since = "1.42.0")]
#[rustc_const_unstable(feature = "const_slice_from_raw_parts", issue = "67456")]
pub const fn slice_from_raw_parts_mut<T>(data: *mut T, len: usize) -> *mut [T] {
    #[cfg(bootstrap)]
    {
        // VEILIGHEID: Toegang tot de waarde van de `Repr`-unie is veilig sinds * mut [T]
        // en FatPtr hebben dezelfde geheugenlay-outs
        unsafe { Repr { raw: FatPtr { data, len } }.rust_mut }
    }
    #[cfg(not(bootstrap))]
    from_raw_parts_mut(data.cast(), len)
}

/// Verwisselt de waarden op twee veranderlijke locaties van hetzelfde type, zonder ook te de-initialiseren.
///
/// Maar op de volgende twee uitzonderingen na, is deze functie semantisch equivalent aan [`mem::swap`]:
///
///
/// * Het werkt op basis van ruwe aanwijzingen in plaats van verwijzingen.
/// Als er referenties beschikbaar zijn, verdient [`mem::swap`] de voorkeur.
///
/// * De twee gewezen waarden kunnen elkaar overlappen.
/// Als de waarden elkaar overlappen, wordt het overlappende geheugengebied van `x` gebruikt.
/// Dit wordt gedemonstreerd in het tweede voorbeeld hieronder.
///
/// # Safety
///
/// Gedrag is niet gedefinieerd als een van de volgende voorwaarden wordt geschonden:
///
/// * Zowel `x` als `y` moeten [valid] zijn voor zowel lezen als schrijven.
///
/// * Zowel `x` als `y` moeten correct zijn uitgelijnd.
///
/// Merk op dat zelfs als `T` de grootte `0` heeft, de aanwijzers niet-NULL moeten zijn en correct uitgelijnd.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Twee niet-overlappende regio's verwisselen:
///
/// ```
/// use std::ptr;
///
/// let mut array = [0, 1, 2, 3];
///
/// let x = array[0..].as_mut_ptr() as *mut [u32; 2]; // dit is `array[0..2]`
/// let y = array[2..].as_mut_ptr() as *mut [u32; 2]; // dit is `array[2..4]`
///
/// unsafe {
///     ptr::swap(x, y);
///     assert_eq!([2, 3, 0, 1], array);
/// }
/// ```
///
/// Twee overlappende regio's verwisselen:
///
/// ```
/// use std::ptr;
///
/// let mut array = [0, 1, 2, 3];
///
/// let x = array[0..].as_mut_ptr() as *mut [u32; 3]; // dit is `array[0..3]`
/// let y = array[1..].as_mut_ptr() as *mut [u32; 3]; // dit is `array[1..4]`
///
/// unsafe {
///     ptr::swap(x, y);
///     // De indices `1..3` van de slice overlappen `x` en `y`.
///     // Redelijke resultaten zouden voor hen `[2, 3]` zijn, zodat indices `0..3` `[1, 2, 3]` zijn (overeenkomend met `y` vóór de `swap`);of dat ze `[0, 1]` zijn, zodat indices `1..4` `[0, 1, 2]` zijn (overeenkomend met `x` vóór de `swap`).
/////
///     // Deze implementatie is gedefinieerd om de laatste keuze te maken.
/////
///     assert_eq!([1, 0, 1, 2], array);
/// }
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
pub const unsafe fn swap<T>(x: *mut T, y: *mut T) {
    // Geef onszelf wat krasruimte om mee te werken.
    // We hoeven ons geen zorgen te maken over vallen: de `MaybeUninit` doet niets als hij valt.
    let mut tmp = MaybeUninit::<T>::uninit();

    // Voer de swap VEILIGHEID uit: de beller moet garanderen dat `x` en `y` geldig zijn voor schrijven en correct zijn uitgelijnd.
    // `tmp` kan `x` of `y` niet overlappen omdat `tmp` zojuist op de stapel is toegewezen als een afzonderlijk toegewezen object.
    //
    //
    //
    unsafe {
        copy_nonoverlapping(x, tmp.as_mut_ptr(), 1);
        copy(y, x, 1); // `x` en `y` kunnen elkaar overlappen
        copy_nonoverlapping(tmp.as_ptr(), y, 1);
    }
}

/// Wisselt `count * size_of::<T>()`-bytes tussen de twee geheugengebieden, beginnend bij `x` en `y`.
/// De twee regio's mogen elkaar *niet* overlappen.
///
/// # Safety
///
/// Gedrag is niet gedefinieerd als een van de volgende voorwaarden wordt geschonden:
///
/// * Zowel `x` als `y` moeten [valid] zijn voor zowel lees-als schrijfbewerkingen van `count *
///   De grootte van: :<T>() `bytes.
///
/// * Zowel `x` als `y` moeten correct zijn uitgelijnd.
///
/// * Het geheugengebied dat begint bij `x` met een grootte van `count *
///   De grootte van: :<T>() `bytes mogen *niet* overlappen met het geheugengebied beginnend bij `y` met dezelfde grootte.
///
/// Merk op dat zelfs als de effectief gekopieerde grootte (`count * size_of: :<T>()`) is `0`, de aanwijzers moeten niet-NULL zijn en correct uitgelijnd.
///
///
/// [valid]: self#safety
///
/// # Examples
///
/// Basisgebruik:
///
/// ```
/// use std::ptr;
///
/// let mut x = [1, 2, 3, 4];
/// let mut y = [7, 8, 9];
///
/// unsafe {
///     ptr::swap_nonoverlapping(x.as_mut_ptr(), y.as_mut_ptr(), 2);
/// }
///
/// assert_eq!(x, [7, 8, 3, 4]);
/// assert_eq!(y, [1, 2, 9]);
/// ```
///
#[inline]
#[stable(feature = "swap_nonoverlapping", since = "1.27.0")]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
pub const unsafe fn swap_nonoverlapping<T>(x: *mut T, y: *mut T, count: usize) {
    let x = x as *mut u8;
    let y = y as *mut u8;
    let len = mem::size_of::<T>() * count;
    // VEILIGHEID: de beller moet garanderen dat `x` en `y` zijn
    // geldig voor schrijven en correct uitgelijnd.
    unsafe { swap_nonoverlapping_bytes(x, y, len) }
}

#[inline]
pub(crate) unsafe fn swap_nonoverlapping_one<T>(x: *mut T, y: *mut T) {
    // Voor typen die kleiner zijn dan de blokoptimalisatie hieronder, hoeft u alleen maar direct te wisselen om pessimisering van codegen te voorkomen.
    //
    if mem::size_of::<T>() < 32 {
        // VEILIGHEID: de beller moet garanderen dat `x` en `y` geldig zijn
        // voor schrijven, correct uitgelijnd en niet-overlappend.
        unsafe {
            let z = read(x);
            copy_nonoverlapping(y, x, 1);
            write(y, z);
        }
    } else {
        // VEILIGHEID: de beller moet zich houden aan het veiligheidscontract voor `swap_nonoverlapping`.
        unsafe { swap_nonoverlapping(x, y, 1) };
    }
}

#[inline]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
const unsafe fn swap_nonoverlapping_bytes(x: *mut u8, y: *mut u8, len: usize) {
    // De benadering hier is om simd te gebruiken om x&y efficiënt te wisselen.
    // Uit tests blijkt dat het omwisselen van 32 bytes of 64 bytes tegelijk het meest efficiënt is voor Intel Haswell E-processors.
    // LLVM kan beter optimaliseren als we een structuur een #[repr(simd)] geven, zelfs als we deze structuur niet rechtstreeks gebruiken.
    //
    //
    // FIXME repr(simd) verbroken op emscripten en redox
    #[cfg_attr(not(any(target_os = "emscripten", target_os = "redox")), repr(simd))]
    struct Block(u64, u64, u64, u64);
    struct UnalignedBlock(u64, u64, u64, u64);

    let block_size = mem::size_of::<Block>();

    // Loop door x&y, kopieer ze `Block` per keer De optimizer moet de lus volledig afrollen voor de meeste typen NB
    // We kunnen geen for-lus gebruiken omdat de `range`-impl `mem::swap` recursief aanroept
    //
    let mut i = 0;
    while i + block_size <= len {
        // Creëer wat niet-geïnitialiseerd geheugen als krasruimte Door hier `t` te declareren, wordt voorkomen dat de stapel wordt uitgelijnd wanneer deze lus niet wordt gebruikt
        //
        let mut t = mem::MaybeUninit::<Block>::uninit();
        let t = t.as_mut_ptr() as *mut u8;

        // VEILIGHEID: Als `i < len`, en als beller moet garanderen dat `x` en `y` geldig zijn
        // voor `len` bytes moeten `x + i` en `y + i` geldige adressen zijn, die voldoen aan het veiligheidscontract voor `add`.
        //
        // De beller moet ook garanderen dat `x` en `y` geldig zijn voor schrijven, correct zijn uitgelijnd en niet overlappen, wat voldoet aan het veiligheidscontract voor `copy_nonoverlapping`.
        //
        //
        unsafe {
            let x = x.add(i);
            let y = y.add(i);

            // Verwissel een blok bytes van x&y, gebruik t als een tijdelijke buffer Dit moet worden geoptimaliseerd tot efficiënte SIMD-bewerkingen, indien beschikbaar
            //
            copy_nonoverlapping(x, t, block_size);
            copy_nonoverlapping(y, x, block_size);
            copy_nonoverlapping(t, y, block_size);
        }
        i += block_size;
    }

    if i < len {
        // Verwissel alle resterende bytes
        let mut t = mem::MaybeUninit::<UnalignedBlock>::uninit();
        let rem = len - i;

        let t = t.as_mut_ptr() as *mut u8;

        // VEILIGHEID: zie vorige veiligheidscommentaar.
        unsafe {
            let x = x.add(i);
            let y = y.add(i);

            copy_nonoverlapping(x, t, rem);
            copy_nonoverlapping(y, x, rem);
            copy_nonoverlapping(t, y, rem);
        }
    }
}

/// Verplaatst `src` naar de puntige `dst` en retourneert de vorige `dst`-waarde.
///
/// Geen van beide waarden wordt verwijderd.
///
/// Deze functie is semantisch equivalent aan [`mem::replace`] behalve dat het werkt met onbewerkte verwijzingen in plaats van verwijzingen.
/// Als er referenties beschikbaar zijn, verdient [`mem::replace`] de voorkeur.
///
/// # Safety
///
/// Gedrag is niet gedefinieerd als een van de volgende voorwaarden wordt geschonden:
///
/// * `dst` moet [valid] zijn voor zowel lees-als schrijfbewerkingen.
///
/// * `dst` moet correct zijn uitgelijnd.
///
/// * `dst` moet verwijzen naar een correct geïnitialiseerde waarde van het type `T`.
///
/// Merk op dat zelfs als `T` de grootte `0` heeft, de aanwijzer niet-NULL moet zijn en correct uitgelijnd.
///
/// [valid]: self#safety
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let mut rust = vec!['b', 'u', 's', 't'];
///
/// // `mem::replace` zou hetzelfde effect hebben zonder het onveilige blok te vereisen.
/////
/// let b = unsafe {
///     ptr::replace(&mut rust[0], 'r')
/// };
///
/// assert_eq!(b, 'b');
/// assert_eq!(rust, &['r', 'u', 's', 't']);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn replace<T>(dst: *mut T, mut src: T) -> T {
    // VEILIGHEID: de beller moet garanderen dat `dst` geldig is om te zijn
    // cast naar een veranderlijke referentie (geldig voor schrijven, uitgelijnd, geïnitialiseerd), en kan `src` niet overlappen aangezien `dst` naar een duidelijk toegewezen object moet verwijzen.
    //
    //
    unsafe {
        mem::swap(&mut *dst, &mut src); // kan niet overlappen
    }
    src
}

/// Leest de waarde van `src` zonder deze te verplaatsen.Dit laat het geheugen in `src` ongewijzigd.
///
/// # Safety
///
/// Gedrag is niet gedefinieerd als een van de volgende voorwaarden wordt geschonden:
///
/// * `src` moet [valid] zijn voor lezen.
///
/// * `src` moet correct zijn uitgelijnd.Gebruik [`read_unaligned`] als dit niet het geval is.
///
/// * `src` moet verwijzen naar een correct geïnitialiseerde waarde van het type `T`.
///
/// Merk op dat zelfs als `T` de grootte `0` heeft, de aanwijzer niet-NULL moet zijn en correct uitgelijnd.
///
/// # Examples
///
/// Basisgebruik:
///
/// ```
/// let x = 12;
/// let y = &x as *const i32;
///
/// unsafe {
///     assert_eq!(std::ptr::read(y), 12);
/// }
/// ```
///
/// [`mem::swap`] handmatig implementeren:
///
/// ```
/// use std::ptr;
///
/// fn swap<T>(a: &mut T, b: &mut T) {
///     unsafe {
///         // Maak een bitsgewijze kopie van de waarde op `a` in `tmp`.
///         let tmp = ptr::read(a);
///
///         // Op dit punt afsluiten (ofwel door expliciet terug te keren of door een functie aan te roepen die panics is) zou de waarde in `tmp` laten vallen terwijl naar dezelfde waarde nog steeds wordt verwezen door `a`.
///         // Dit kan ongedefinieerd gedrag veroorzaken als `T` niet `Copy` is.
/////
/////
///
///         // Maak een bitsgewijze kopie van de waarde op `b` in `a`.
///         // Dit is veilig omdat veranderlijke verwijzingen geen alias kunnen maken.
///         ptr::copy_nonoverlapping(b, a, 1);
///
///         // Zoals hierboven, kan het afsluiten hier ongedefinieerd gedrag veroorzaken, omdat naar dezelfde waarde wordt verwezen door `a` en `b`.
/////
///
///         // Verplaats `tmp` naar `b`.
///         ptr::write(b, tmp);
///
///         // `tmp` is verplaatst (`write` neemt eigenaar van zijn tweede argument), dus wordt hier impliciet niets weggelaten.
/////
///     }
/// }
///
/// let mut foo = "foo".to_owned();
/// let mut bar = "bar".to_owned();
///
/// swap(&mut foo, &mut bar);
///
/// assert_eq!(foo, "bar");
/// assert_eq!(bar, "foo");
/// ```
///
/// ## Eigendom van de geretourneerde waarde
///
/// `read` maakt een bitsgewijze kopie van `T`, ongeacht of `T` [`Copy`] is.
/// Als `T` niet [`Copy`] is, kan het gebruik van zowel de geretourneerde waarde als de waarde op `*src` de geheugenveiligheid schenden.
/// Merk op dat het toewijzen aan `*src` telt als een gebruik omdat het zal proberen de waarde op `* src` te laten vallen.
///
/// [`write()`] kan worden gebruikt om gegevens te overschrijven zonder dat deze worden verwijderd.
///
/// ```
/// use std::ptr;
///
/// let mut s = String::from("foo");
/// unsafe {
///     // `s2` verwijst nu naar hetzelfde onderliggende geheugen als `s`.
///     let mut s2: String = ptr::read(&s);
///
///     assert_eq!(s2, "foo");
///
///     // Door aan `s2` toe te wijzen, wordt de oorspronkelijke waarde verwijderd.
///     // Na dit punt mag `s` niet langer worden gebruikt, omdat het onderliggende geheugen is vrijgemaakt.
/////
///     s2 = String::default();
///     assert_eq!(s2, "");
///
///     // Toewijzing aan `s` zou ervoor zorgen dat de oude waarde weer wordt verwijderd, wat resulteert in ongedefinieerd gedrag.
/////
///     // s= String::from("bar");//FOUT
///
///     // `ptr::write` kan worden gebruikt om een waarde te overschrijven zonder deze te verwijderen.
///     ptr::write(&mut s, String::from("bar"));
/// }
///
/// assert_eq!(s, "bar");
/// ```
///
/// [valid]: self#safety
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
pub const unsafe fn read<T>(src: *const T) -> T {
    let mut tmp = MaybeUninit::<T>::uninit();
    // VEILIGHEID: de beller moet garanderen dat `src` geldig is voor lezen.
    // `src` `tmp` kan niet overlappen omdat `tmp` zojuist op de stapel is toegewezen als een afzonderlijk toegewezen object.
    //
    //
    // Omdat we zojuist een geldige waarde in `tmp` hebben geschreven, is deze gegarandeerd correct geïnitialiseerd.
    //
    unsafe {
        copy_nonoverlapping(src, tmp.as_mut_ptr(), 1);
        tmp.assume_init()
    }
}

/// Leest de waarde van `src` zonder deze te verplaatsen.Dit laat het geheugen in `src` ongewijzigd.
///
/// In tegenstelling tot [`read`] werkt `read_unaligned` met niet-uitgelijnde aanwijzers.
///
/// # Safety
///
/// Gedrag is niet gedefinieerd als een van de volgende voorwaarden wordt geschonden:
///
/// * `src` moet [valid] zijn voor lezen.
///
/// * `src` moet verwijzen naar een correct geïnitialiseerde waarde van het type `T`.
///
/// Net als [`read`] maakt `read_unaligned` een bitsgewijze kopie van `T`, ongeacht of `T` [`Copy`] is.
/// Als `T` niet [`Copy`] is, kan het gebruik van zowel de geretourneerde waarde als de waarde op `*src` [violate memory safety][read-ownership].
///
/// Merk op dat zelfs als `T` de grootte `0` heeft, de aanwijzer niet-NULL mag zijn.
///
/// [read-ownership]: read#ownership-of-the-returned-value
/// [valid]: self#safety
///
/// ## Op `packed`-structs
///
/// Het is momenteel onmogelijk om onbewerkte verwijzingen te maken naar niet-uitgelijnde velden van een verpakte structuur.
///
/// Als u probeert een onbewerkte aanwijzer te maken naar een `unaligned`-structveld met een uitdrukking zoals `&packed.unaligned as *const FieldType`, wordt een tussenliggende niet-uitgelijnde verwijzing gemaakt voordat deze wordt geconverteerd naar een onbewerkte aanwijzer.
///
/// Dat deze verwijzing tijdelijk is en onmiddellijk wordt uitgebracht, is niet van belang, aangezien de compiler altijd verwacht dat verwijzingen correct zijn uitgelijnd.
/// Als gevolg hiervan veroorzaakt het gebruik van `&packed.unaligned as *const FieldType` onmiddellijk* ongedefinieerd gedrag * in uw programma.
///
/// Een voorbeeld van wat je niet moet doen en hoe dit zich verhoudt tot `read_unaligned` is:
///
/// ```no_run
/// #[repr(packed, C)]
/// struct Packed {
///     _padding: u8,
///     unaligned: u32,
/// }
///
/// let packed = Packed {
///     _padding: 0x00,
///     unaligned: 0x01020304,
/// };
///
/// let v = unsafe {
///     // Hier proberen we het adres te nemen van een 32-bits geheel getal dat niet is uitgelijnd.
///     let unaligned =
///         // Hier wordt een tijdelijke niet-uitgelijnde referentie gemaakt die resulteert in ongedefinieerd gedrag, ongeacht of de referentie wordt gebruikt of niet.
/////
///         &packed.unaligned
///         // Casten naar een onbewerkte aanwijzer helpt niet;de fout is al gebeurd.
///         as *const u32;
///
///     let v = std::ptr::read_unaligned(unaligned);
///
///     v
/// };
/// ```
///
/// Rechtstreekse toegang tot niet-uitgelijnde velden met bijvoorbeeld `packed.unaligned` is echter veilig.
///
///
///
///
///
///
// FIXME: Werk documenten bij op basis van het resultaat van RFC #2582 en vrienden.
/// # Examples
///
/// Lees een gebruikswaarde uit een bytebuffer:
///
/// ```
/// use std::mem;
///
/// fn read_usize(x: &[u8]) -> usize {
///     assert!(x.len() >= mem::size_of::<usize>());
///
///     let ptr = x.as_ptr() as *const usize;
///
///     unsafe { ptr.read_unaligned() }
/// }
/// ```
#[inline]
#[stable(feature = "ptr_unaligned", since = "1.17.0")]
#[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
pub const unsafe fn read_unaligned<T>(src: *const T) -> T {
    let mut tmp = MaybeUninit::<T>::uninit();
    // VEILIGHEID: de beller moet garanderen dat `src` geldig is voor lezen.
    // `src` `tmp` kan niet overlappen omdat `tmp` zojuist op de stapel is toegewezen als een afzonderlijk toegewezen object.
    //
    //
    // Omdat we zojuist een geldige waarde in `tmp` hebben geschreven, is deze gegarandeerd correct geïnitialiseerd.
    //
    unsafe {
        copy_nonoverlapping(src as *const u8, tmp.as_mut_ptr() as *mut u8, mem::size_of::<T>());
        tmp.assume_init()
    }
}

/// Overschrijft een geheugenlocatie met de gegeven waarde zonder de oude waarde te lezen of te laten vallen.
///
/// `write` laat de inhoud van `dst` niet vallen.
/// Dit is veilig, maar het kan toewijzingen of bronnen lekken, dus zorg ervoor dat u een object dat moet worden verwijderd, niet overschrijft.
///
///
/// Bovendien laat het `src` niet vallen.Semantisch wordt `src` verplaatst naar de locatie waarnaar wordt verwezen door `dst`.
///
/// Dit is geschikt voor het initialiseren van niet-geïnitialiseerd geheugen, of het overschrijven van geheugen dat voorheen [`read`] was.
///
/// # Safety
///
/// Gedrag is niet gedefinieerd als een van de volgende voorwaarden wordt geschonden:
///
/// * `dst` moet [valid] zijn voor schrijven.
///
/// * `dst` moet correct zijn uitgelijnd.Gebruik [`write_unaligned`] als dit niet het geval is.
///
/// Merk op dat zelfs als `T` de grootte `0` heeft, de aanwijzer niet-NULL moet zijn en correct uitgelijnd.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Basisgebruik:
///
/// ```
/// let mut x = 0;
/// let y = &mut x as *mut i32;
/// let z = 12;
///
/// unsafe {
///     std::ptr::write(y, z);
///     assert_eq!(std::ptr::read(y), 12);
/// }
/// ```
///
/// [`mem::swap`] handmatig implementeren:
///
/// ```
/// use std::ptr;
///
/// fn swap<T>(a: &mut T, b: &mut T) {
///     unsafe {
///         // Maak een bitsgewijze kopie van de waarde op `a` in `tmp`.
///         let tmp = ptr::read(a);
///
///         // Op dit punt afsluiten (ofwel door expliciet terug te keren of door een functie aan te roepen die panics is) zou de waarde in `tmp` laten vallen terwijl naar dezelfde waarde nog steeds wordt verwezen door `a`.
///         // Dit kan ongedefinieerd gedrag veroorzaken als `T` niet `Copy` is.
/////
/////
///
///         // Maak een bitsgewijze kopie van de waarde op `b` in `a`.
///         // Dit is veilig omdat veranderlijke verwijzingen geen alias kunnen maken.
///         ptr::copy_nonoverlapping(b, a, 1);
///
///         // Zoals hierboven, kan het afsluiten hier ongedefinieerd gedrag veroorzaken, omdat naar dezelfde waarde wordt verwezen door `a` en `b`.
/////
///
///         // Verplaats `tmp` naar `b`.
///         ptr::write(b, tmp);
///
///         // `tmp` is verplaatst (`write` neemt eigenaar van zijn tweede argument), dus wordt hier impliciet niets weggelaten.
/////
///     }
/// }
///
/// let mut foo = "foo".to_owned();
/// let mut bar = "bar".to_owned();
///
/// swap(&mut foo, &mut bar);
///
/// assert_eq!(foo, "bar");
/// assert_eq!(bar, "foo");
/// ```
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn write<T>(dst: *mut T, src: T) {
    // We roepen de intrinsieke gegevens rechtstreeks aan om functieaanroepen in de gegenereerde code te vermijden, aangezien `intrinsics::copy_nonoverlapping` een wrapper-functie is.
    //
    extern "rust-intrinsic" {
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // VEILIGHEID: de beller moet garanderen dat `dst` geldig is voor schrijven.
    // `dst` `src` kan niet overlappen omdat de beller veranderlijke toegang heeft tot `dst` terwijl `src` eigendom is van deze functie.
    //
    unsafe {
        copy_nonoverlapping(&src as *const T, dst, 1);
        intrinsics::forget(src);
    }
}

/// Overschrijft een geheugenlocatie met de gegeven waarde zonder de oude waarde te lezen of te laten vallen.
///
/// In tegenstelling tot [`write()`] is de aanwijzer mogelijk niet uitgelijnd.
///
/// `write_unaligned` laat de inhoud van `dst` niet vallen.Dit is veilig, maar het kan toewijzingen of bronnen lekken, dus zorg ervoor dat u een object dat moet worden verwijderd, niet overschrijft.
///
/// Bovendien laat het `src` niet vallen.Semantisch wordt `src` verplaatst naar de locatie waarnaar wordt verwezen door `dst`.
///
/// Dit is geschikt voor het initialiseren van niet-geïnitialiseerd geheugen of het overschrijven van geheugen dat eerder is gelezen met [`read_unaligned`].
///
/// # Safety
///
/// Gedrag is niet gedefinieerd als een van de volgende voorwaarden wordt geschonden:
///
/// * `dst` moet [valid] zijn voor schrijven.
///
/// Merk op dat zelfs als `T` de grootte `0` heeft, de aanwijzer niet-NULL mag zijn.
///
/// [valid]: self#safety
///
/// ## Op `packed`-structs
///
/// Het is momenteel onmogelijk om onbewerkte verwijzingen te maken naar niet-uitgelijnde velden van een verpakte structuur.
///
/// Als u probeert een onbewerkte aanwijzer te maken naar een `unaligned`-structveld met een uitdrukking zoals `&packed.unaligned as *const FieldType`, wordt een tussenliggende niet-uitgelijnde verwijzing gemaakt voordat deze wordt geconverteerd naar een onbewerkte aanwijzer.
///
/// Dat deze verwijzing tijdelijk is en onmiddellijk wordt uitgebracht, is niet van belang, aangezien de compiler altijd verwacht dat verwijzingen correct zijn uitgelijnd.
/// Als gevolg hiervan veroorzaakt het gebruik van `&packed.unaligned as *const FieldType` onmiddellijk* ongedefinieerd gedrag * in uw programma.
///
/// Een voorbeeld van wat je niet moet doen en hoe dit zich verhoudt tot `write_unaligned` is:
///
/// ```no_run
/// #[repr(packed, C)]
/// struct Packed {
///     _padding: u8,
///     unaligned: u32,
/// }
///
/// let v = 0x01020304;
/// let mut packed: Packed = unsafe { std::mem::zeroed() };
///
/// let v = unsafe {
///     // Hier proberen we het adres te nemen van een 32-bits geheel getal dat niet is uitgelijnd.
///     let unaligned =
///         // Hier wordt een tijdelijke niet-uitgelijnde referentie gemaakt die resulteert in ongedefinieerd gedrag, ongeacht of de referentie wordt gebruikt of niet.
/////
///         &mut packed.unaligned
///         // Casten naar een onbewerkte aanwijzer helpt niet;de fout is al gebeurd.
///         as *mut u32;
///
///     std::ptr::write_unaligned(unaligned, v);
///
///     v
/// };
/// ```
///
/// Rechtstreekse toegang tot niet-uitgelijnde velden met bijvoorbeeld `packed.unaligned` is echter veilig.
///
///
///
///
///
///
///
///
///
// FIXME: Werk documenten bij op basis van het resultaat van RFC #2582 en vrienden.
/// # Examples
///
/// Schrijf een usize-waarde naar een bytebuffer:
///
/// ```
/// use std::mem;
///
/// fn write_usize(x: &mut [u8], val: usize) {
///     assert!(x.len() >= mem::size_of::<usize>());
///
///     let ptr = x.as_mut_ptr() as *mut usize;
///
///     unsafe { ptr.write_unaligned(val) }
/// }
/// ```
#[inline]
#[stable(feature = "ptr_unaligned", since = "1.17.0")]
#[rustc_const_unstable(feature = "const_ptr_write", issue = "none")]
pub const unsafe fn write_unaligned<T>(dst: *mut T, src: T) {
    // VEILIGHEID: de beller moet garanderen dat `dst` geldig is voor schrijven.
    // `dst` `src` kan niet overlappen omdat de beller veranderlijke toegang heeft tot `dst` terwijl `src` eigendom is van deze functie.
    //
    unsafe {
        copy_nonoverlapping(&src as *const T as *const u8, dst as *mut u8, mem::size_of::<T>());
        // We roepen het intrinsieke rechtstreeks aan om functieaanroepen in de gegenereerde code te vermijden.
        intrinsics::forget(src);
    }
}

/// Voert een vluchtige aflezing uit van de waarde van `src` zonder deze te verplaatsen.Dit laat het geheugen in `src` ongewijzigd.
///
/// Vluchtige bewerkingen zijn bedoeld om in te werken op het I/O-geheugen en worden gegarandeerd niet weggelaten of opnieuw gerangschikt door de compiler voor andere vluchtige bewerkingen.
///
/// # Notes
///
/// Rust heeft momenteel geen rigoureus en formeel gedefinieerd geheugenmodel, dus de precieze semantiek van wat "volatile" hier betekent, is onderhevig aan verandering in de tijd.
/// Dat gezegd hebbende, de semantiek zal bijna altijd vergelijkbaar zijn met die van [C11's definition of volatile][c11].
///
/// De compiler mag de relatieve volgorde of het aantal vluchtige geheugenbewerkingen niet wijzigen.
/// Vluchtige geheugenbewerkingen op typen met een grootte van nul (bijvoorbeeld als een type met een grootte van nul wordt doorgegeven aan `read_volatile`) zijn noops en kunnen worden genegeerd.
///
/// [c11]: http://www.open-std.org/jtc1/sc22/wg14/www/docs/n1570.pdf
///
/// # Safety
///
/// Gedrag is niet gedefinieerd als een van de volgende voorwaarden wordt geschonden:
///
/// * `src` moet [valid] zijn voor lezen.
///
/// * `src` moet correct zijn uitgelijnd.
///
/// * `src` moet verwijzen naar een correct geïnitialiseerde waarde van het type `T`.
///
/// Net als [`read`] maakt `read_volatile` een bitsgewijze kopie van `T`, ongeacht of `T` [`Copy`] is.
/// Als `T` niet [`Copy`] is, kan het gebruik van zowel de geretourneerde waarde als de waarde op `*src` [violate memory safety][read-ownership].
/// Het opslaan van niet-[`Copy`]-typen in vluchtig geheugen is echter vrijwel zeker onjuist.
///
/// Merk op dat zelfs als `T` de grootte `0` heeft, de aanwijzer niet-NULL moet zijn en correct uitgelijnd.
///
/// [valid]: self#safety
/// [read-ownership]: read#ownership-of-the-returned-value
///
/// Net als in C, heeft de vraag of een operatie vluchtig is, geen enkele invloed op vragen met betrekking tot gelijktijdige toegang vanaf meerdere threads.Vluchtige toegangen gedragen zich in dat opzicht precies als niet-atomaire toegangen.
///
/// In het bijzonder is een race tussen een `read_volatile` en een schrijfoperatie naar dezelfde locatie ongedefinieerd gedrag.
///
/// # Examples
///
/// Basisgebruik:
///
/// ```
/// let x = 12;
/// let y = &x as *const i32;
///
/// unsafe {
///     assert_eq!(std::ptr::read_volatile(y), 12);
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "volatile", since = "1.9.0")]
pub unsafe fn read_volatile<T>(src: *const T) -> T {
    if cfg!(debug_assertions) && !is_aligned_and_not_null(src) {
        // Niet in paniek raken om de impact van codegen kleiner te houden.
        abort();
    }
    // VEILIGHEID: de beller moet zich houden aan het veiligheidscontract voor `volatile_load`.
    unsafe { intrinsics::volatile_load(src) }
}

/// Voert een vluchtige schrijfbewerking uit van een geheugenlocatie met de opgegeven waarde zonder de oude waarde te lezen of te laten vallen.
///
/// Vluchtige bewerkingen zijn bedoeld om in te werken op het I/O-geheugen en worden gegarandeerd niet weggelaten of opnieuw gerangschikt door de compiler voor andere vluchtige bewerkingen.
///
/// `write_volatile` laat de inhoud van `dst` niet vallen.Dit is veilig, maar het kan toewijzingen of bronnen lekken, dus zorg ervoor dat u een object dat moet worden verwijderd, niet overschrijft.
///
/// Bovendien laat het `src` niet vallen.Semantisch wordt `src` verplaatst naar de locatie waarnaar wordt verwezen door `dst`.
///
/// # Notes
///
/// Rust heeft momenteel geen rigoureus en formeel gedefinieerd geheugenmodel, dus de precieze semantiek van wat "volatile" hier betekent, is onderhevig aan verandering in de tijd.
/// Dat gezegd hebbende, de semantiek zal bijna altijd vergelijkbaar zijn met die van [C11's definition of volatile][c11].
///
/// De compiler mag de relatieve volgorde of het aantal vluchtige geheugenbewerkingen niet wijzigen.
/// Vluchtige geheugenbewerkingen op typen met een grootte van nul (bijvoorbeeld als een type met een grootte van nul wordt doorgegeven aan `write_volatile`) zijn noops en kunnen worden genegeerd.
///
/// [c11]: http://www.open-std.org/jtc1/sc22/wg14/www/docs/n1570.pdf
///
/// # Safety
///
/// Gedrag is niet gedefinieerd als een van de volgende voorwaarden wordt geschonden:
///
/// * `dst` moet [valid] zijn voor schrijven.
///
/// * `dst` moet correct zijn uitgelijnd.
///
/// Merk op dat zelfs als `T` de grootte `0` heeft, de aanwijzer niet-NULL moet zijn en correct uitgelijnd.
///
/// [valid]: self#safety
///
/// Net als in C, heeft de vraag of een operatie vluchtig is, geen enkele invloed op vragen met betrekking tot gelijktijdige toegang vanaf meerdere threads.Vluchtige toegangen gedragen zich in dat opzicht precies als niet-atomaire toegangen.
///
/// Met name een race tussen een `write_volatile` en een andere bewerking (lezen of schrijven) op dezelfde locatie is ongedefinieerd gedrag.
///
/// # Examples
///
/// Basisgebruik:
///
/// ```
/// let mut x = 0;
/// let y = &mut x as *mut i32;
/// let z = 12;
///
/// unsafe {
///     std::ptr::write_volatile(y, z);
///     assert_eq!(std::ptr::read_volatile(y), 12);
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "volatile", since = "1.9.0")]
pub unsafe fn write_volatile<T>(dst: *mut T, src: T) {
    if cfg!(debug_assertions) && !is_aligned_and_not_null(dst) {
        // Niet in paniek raken om de impact van codegen kleiner te houden.
        abort();
    }
    // VEILIGHEID: de beller moet zich houden aan het veiligheidscontract voor `volatile_store`.
    unsafe {
        intrinsics::volatile_store(dst, src);
    }
}

/// Lijn de aanwijzer `p` uit.
///
/// Bereken de offset (in termen van elementen van `stride` stride) die moet worden toegepast op pointer `p` zodat pointer `p` wordt uitgelijnd met `a`.
///
/// Note: Deze implementatie is zorgvuldig afgestemd op niet panic.Het is hiervoor UB naar panic.
/// De enige echte wijziging die hier kan worden aangebracht, is de wijziging van `INV_TABLE_MOD_16` en bijbehorende constanten.
///
/// Als we ooit besluiten om het mogelijk te maken om het intrinsieke met `a` te noemen dat geen macht van twee is, zal het waarschijnlijk verstandiger zijn om gewoon over te schakelen naar een naïeve implementatie in plaats van te proberen dit aan te passen aan die verandering.
///
///
/// Voor vragen ga naar@nagisa.
///
///
///
#[lang = "align_offset"]
pub(crate) unsafe fn align_offset<T: Sized>(p: *const T, a: usize) -> usize {
    // FIXME(#75598): Direct gebruik van deze intrinsieke eigenschappen verbetert codegen significant op opt-niveau <=
    // 1, waar de methodeversies van deze bewerkingen niet inline zijn.
    use intrinsics::{
        unchecked_shl, unchecked_shr, unchecked_sub, wrapping_add, wrapping_mul, wrapping_sub,
    };

    /// Bereken multiplicatieve modulaire inverse van `x` modulo `m`.
    ///
    /// Deze implementatie is op maat gemaakt voor `align_offset` en kent de volgende randvoorwaarden:
    ///
    /// * `m` is een macht van twee;
    /// * `x < m`; (als `x ≥ m`, geef in plaats daarvan `x % m` door)
    ///
    /// Implementatie van deze functie zal niet panic.Ooit.
    #[inline]
    unsafe fn mod_inv(x: usize, m: usize) -> usize {
        /// Multiplicatieve modulaire inverse tafel modulo 2⁴=16.
        ///
        /// Merk op dat deze tabel geen waarden bevat waar inverse niet bestaat (bijv. Voor `0⁻¹ mod 16`, `2⁻¹ mod 16`, enz.)
        ///
        const INV_TABLE_MOD_16: [u8; 8] = [1, 11, 13, 7, 9, 3, 5, 15];
        /// Modulo waarvoor de `INV_TABLE_MOD_16` bedoeld is.
        const INV_TABLE_MOD: usize = 16;
        /// INV_TABLE_MOD²
        const INV_TABLE_MOD_SQUARED: usize = INV_TABLE_MOD * INV_TABLE_MOD;

        let table_inverse = INV_TABLE_MOD_16[(x & (INV_TABLE_MOD - 1)) >> 1] as usize;
        // VEILIGHEID: `m` moet een macht van twee zijn, dus niet-nul.
        let m_minus_one = unsafe { unchecked_sub(m, 1) };
        if m <= INV_TABLE_MOD {
            table_inverse & m_minus_one
        } else {
            // We herhalen "up" met behulp van de volgende formule:
            //
            // $$ xy ≡ 1 (mod 2ⁿ) → xy (2, xy) ≡ 1 (mod 2²ⁿ) $$
            //
            // tot 2²ⁿ ≥ m.Dan kunnen we reduceren tot onze gewenste `m` door het resultaat `mod m` te nemen.
            let mut inverse = table_inverse;
            let mut going_mod = INV_TABLE_MOD_SQUARED;
            loop {
                // y=y * (2, xy) mod n
                //
                // Merk op dat we hier opzettelijk wrapping-operaties gebruiken-de originele formule gebruikt bijvoorbeeld aftrekking `mod n`.
                // Het is prima om ze in plaats daarvan `mod usize::MAX` te doen, omdat we aan het einde toch het resultaat `mod n` nemen.
                //
                //
                inverse = wrapping_mul(inverse, wrapping_sub(2usize, wrapping_mul(x, inverse)));
                if going_mod >= m {
                    return inverse & m_minus_one;
                }
                going_mod = wrapping_mul(going_mod, going_mod);
            }
        }
    }

    let stride = mem::size_of::<T>();
    // VEILIGHEID: `a` is een macht van twee, dus niet nul.
    let a_minus_one = unsafe { unchecked_sub(a, 1) };
    if stride == 1 {
        // `stride == 1` case kan eenvoudiger worden berekend via `-p (mod a)`, maar dit verhindert LLVM's mogelijkheid om instructies zoals `lea` te selecteren.In plaats daarvan berekenen we
        //
        //    round_up_to_next_alignment(p, a) - p
        //
        // die operaties verdeelt over de dragende, maar `and` voldoende pessimeert zodat LLVM de verschillende optimalisaties die het kent, kan gebruiken.
        //
        //
        return wrapping_sub(
            wrapping_add(p as usize, a_minus_one) & wrapping_sub(0, a),
            p as usize,
        );
    }

    let pmoda = p as usize & a_minus_one;
    if pmoda == 0 {
        // Al uitgelijnd.Ja!
        return 0;
    } else if stride == 0 {
        // Als de aanwijzer niet is uitgelijnd, en het element heeft een grootte van nul, dan zal geen enkel aantal elementen de aanwijzer uitlijnen.
        //
        return usize::MAX;
    }

    let smoda = stride & a_minus_one;
    // VEILIGHEID: a is macht van twee en dus niet nul.stride==0 case wordt hierboven afgehandeld.
    let gcdpow = unsafe { intrinsics::cttz_nonzero(stride).min(intrinsics::cttz_nonzero(a)) };
    // VEILIGHEID: gcdpow heeft een bovengrens die maximaal het aantal bits in een usize is.
    let gcd = unsafe { unchecked_shl(1usize, gcdpow) };

    // VEILIGHEID: ggd is altijd groter dan of gelijk aan 1.
    if p as usize & unsafe { unchecked_sub(gcd, 1) } == 0 {
        // Deze branch lost de volgende lineaire congruentievergelijking op:
        //
        // ` p + so = 0 mod a `
        //
        // `p` hier is de pointerwaarde, `s`, stride van `T`, `o` offset in `T`s, en `a`, de gevraagde uitlijning.
        //
        // Met `g = gcd(a, s)`, en de bovenstaande voorwaarde die beweert dat `p` ook deelbaar is door `g`, kunnen we `a' = a/g`, `s' = s/g`, `p' = p/g` aanduiden, dan wordt dit gelijk aan:
        //
        // ` p' + s'o = 0 mod a' `
        // ` o = (a' - (p' mod a')) * (s'^-1 mod a') `
        //
        // De eerste term is "the relative alignment of `p` to `a`" (gedeeld door `g`), de tweede term is "how does incrementing `p` by `s` bytes change the relative alignment of `p`" (opnieuw gedeeld door `g`).
        //
        // Deling door `g` is nodig om de inverse goed gevormd te maken als `a` en `s` niet co-prime zijn.
        //
        // Bovendien is het resultaat dat door deze oplossing wordt geproduceerd niet "minimal", dus het is noodzakelijk om het resultaat `o mod lcm(s, a)` te nemen.We kunnen `lcm(s, a)` vervangen door slechts een `a'`.
        //
        //
        //
        //
        //

        // VEILIGHEID: `gcdpow` heeft een bovengrens die niet groter is dan het aantal achterliggende 0-bits in `a`.
        //
        let a2 = unsafe { unchecked_shr(a, gcdpow) };
        // VEILIGHEID: `a2` is niet nul.Het verschuiven van `a` door `gcdpow` kan geen van de ingestelde bits verschuiven
        // in `a` (waarvan het er precies één heeft).
        let a2minus1 = unsafe { unchecked_sub(a2, 1) };
        // VEILIGHEID: `gcdpow` heeft een bovengrens die niet groter is dan het aantal achterliggende 0-bits in `a`.
        //
        let s2 = unsafe { unchecked_shr(smoda, gcdpow) };
        // VEILIGHEID: `gcdpow` heeft een bovengrens die niet groter is dan het aantal achterliggende 0-bits in
        // `a`.
        // Bovendien kan de aftrekking niet overlopen, omdat `a2 = a >> gcdpow` altijd strikt groter zal zijn dan `(p % a) >> gcdpow`.
        let minusp2 = unsafe { unchecked_sub(a2, unchecked_shr(pmoda, gcdpow)) };
        // VEILIGHEID: `a2` is een kracht van twee, zoals hierboven bewezen.`s2` is strikt kleiner dan `a2`
        // omdat `(s % a) >> gcdpow` strikt kleiner is dan `a >> gcdpow`.
        return wrapping_mul(minusp2, unsafe { mod_inv(s2, a2) }) & a2minus1;
    }

    // Helemaal niet uit te lijnen.
    usize::MAX
}

/// Vergelijkt ruwe aanwijzingen voor gelijkheid.
///
/// Dit is hetzelfde als het gebruik van de `==`-operator, maar minder algemeen:
/// de argumenten moeten ruwe `*const T`-aanwijzers zijn, niet iets dat `PartialEq` implementeert.
///
/// Dit kan worden gebruikt om `&T`-referenties (die impliciet naar `*const T` dwingen) te vergelijken op basis van hun adres in plaats van de waarden waarnaar ze verwijzen te vergelijken (wat de `PartialEq for &T`-implementatie doet).
///
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let five = 5;
/// let other_five = 5;
/// let five_ref = &five;
/// let same_five_ref = &five;
/// let other_five_ref = &other_five;
///
/// assert!(five_ref == same_five_ref);
/// assert!(ptr::eq(five_ref, same_five_ref));
///
/// assert!(five_ref == other_five_ref);
/// assert!(!ptr::eq(five_ref, other_five_ref));
/// ```
///
/// Plakjes worden ook vergeleken op hun lengte (vetwijzers):
///
/// ```
/// let a = [1, 2, 3];
/// assert!(std::ptr::eq(&a[..3], &a[..3]));
/// assert!(!std::ptr::eq(&a[..2], &a[..3]));
/// assert!(!std::ptr::eq(&a[0..2], &a[1..3]));
/// ```
///
/// Traits worden ook vergeleken door hun implementatie:
///
/// ```
/// #[repr(transparent)]
/// struct Wrapper { member: i32 }
///
/// trait Trait {}
/// impl Trait for Wrapper {}
/// impl Trait for i32 {}
///
/// let wrapper = Wrapper { member: 10 };
///
/// // Aanwijzers hebben gelijke adressen.
/// assert!(std::ptr::eq(
///     &wrapper as *const Wrapper as *const u8,
///     &wrapper.member as *const i32 as *const u8
/// ));
///
/// // Objecten hebben gelijke adressen, maar `Trait` heeft verschillende implementaties.
/// assert!(!std::ptr::eq(
///     &wrapper as &dyn Trait,
///     &wrapper.member as &dyn Trait,
/// ));
/// assert!(!std::ptr::eq(
///     &wrapper as &dyn Trait as *const dyn Trait,
///     &wrapper.member as &dyn Trait as *const dyn Trait,
/// ));
///
/// // Door de referentie naar een `*const u8` te converteren, wordt op adres vergeleken.
/// assert!(std::ptr::eq(
///     &wrapper as &dyn Trait as *const dyn Trait as *const u8,
///     &wrapper.member as &dyn Trait as *const dyn Trait as *const u8,
/// ));
/// ```
///
///
#[stable(feature = "ptr_eq", since = "1.17.0")]
#[inline]
pub fn eq<T: ?Sized>(a: *const T, b: *const T) -> bool {
    a == b
}

/// Hash een ruwe aanwijzer.
///
/// Dit kan worden gebruikt om een `&T`-referentie (die impliciet naar `*const T` dwingt) te hashen aan de hand van het adres in plaats van de waarde waarnaar deze verwijst (wat de `Hash for &T`-implementatie doet).
///
///
/// # Examples
///
/// ```
/// use std::collections::hash_map::DefaultHasher;
/// use std::hash::{Hash, Hasher};
/// use std::ptr;
///
/// let five = 5;
/// let five_ref = &five;
///
/// let mut hasher = DefaultHasher::new();
/// ptr::hash(five_ref, &mut hasher);
/// let actual = hasher.finish();
///
/// let mut hasher = DefaultHasher::new();
/// (five_ref as *const i32).hash(&mut hasher);
/// let expected = hasher.finish();
///
/// assert_eq!(actual, expected);
/// ```
///
#[stable(feature = "ptr_hash", since = "1.35.0")]
pub fn hash<T: ?Sized, S: hash::Hasher>(hashee: *const T, into: &mut S) {
    use crate::hash::Hash;
    hashee.hash(into);
}

// Impliceert voor functie-aanwijzingen
macro_rules! fnptr_impls_safety_abi {
    ($FnTy: ty, $($Arg: ident),*) => {
        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> PartialEq for $FnTy {
            #[inline]
            fn eq(&self, other: &Self) -> bool {
                *self as usize == *other as usize
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> Eq for $FnTy {}

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> PartialOrd for $FnTy {
            #[inline]
            fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
                (*self as usize).partial_cmp(&(*other as usize))
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> Ord for $FnTy {
            #[inline]
            fn cmp(&self, other: &Self) -> Ordering {
                (*self as usize).cmp(&(*other as usize))
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> hash::Hash for $FnTy {
            fn hash<HH: hash::Hasher>(&self, state: &mut HH) {
                state.write_usize(*self as usize)
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> fmt::Pointer for $FnTy {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                // HACK: De tussenliggende cast zoals gebruikt is vereist voor AVR
                // zodat de adresruimte van de bronfunctiepointer behouden blijft in de laatste functiepointer.
                //
                //
                // https://github.com/avr-rust/rust/issues/143
                fmt::Pointer::fmt(&(*self as usize as *const ()), f)
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> fmt::Debug for $FnTy {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                // HACK: De tussenliggende cast zoals gebruikt is vereist voor AVR
                // zodat de adresruimte van de bronfunctiepointer behouden blijft in de laatste functiepointer.
                //
                //
                // https://github.com/avr-rust/rust/issues/143
                fmt::Pointer::fmt(&(*self as usize as *const ()), f)
            }
        }
    }
}

macro_rules! fnptr_impls_args {
    ($($Arg: ident),+) => {
        fnptr_impls_safety_abi! { extern "Rust" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { extern "C" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { extern "C" fn($($Arg),+ , ...) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "Rust" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "C" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "C" fn($($Arg),+ , ...) -> Ret, $($Arg),+ }
    };
    () => {
        // Geen variadische functies met 0 parameters
        fnptr_impls_safety_abi! { extern "Rust" fn() -> Ret, }
        fnptr_impls_safety_abi! { extern "C" fn() -> Ret, }
        fnptr_impls_safety_abi! { unsafe extern "Rust" fn() -> Ret, }
        fnptr_impls_safety_abi! { unsafe extern "C" fn() -> Ret, }
    };
}

fnptr_impls_args! {}
fnptr_impls_args! { A }
fnptr_impls_args! { A, B }
fnptr_impls_args! { A, B, C }
fnptr_impls_args! { A, B, C, D }
fnptr_impls_args! { A, B, C, D, E }
fnptr_impls_args! { A, B, C, D, E, F }
fnptr_impls_args! { A, B, C, D, E, F, G }
fnptr_impls_args! { A, B, C, D, E, F, G, H }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J, K }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J, K, L }

/// Maak een `const` onbewerkte pointer naar een plaats, zonder een tussenliggende referentie te maken.
///
/// Het maken van een referentie met `&`/`&mut` is alleen toegestaan als de pointer correct is uitgelijnd en naar geïnitialiseerde gegevens verwijst.
/// Voor gevallen waarin die vereisten niet gelden, moeten in plaats daarvan onbewerkte verwijzingen worden gebruikt.
/// `&expr as *const _` maakt echter een referentie voordat deze naar een onbewerkte pointer wordt gecast, en die referentie is onderworpen aan dezelfde regels als alle andere referenties.
///
/// Deze macro kan een onbewerkte pointer *maken zonder* eerst een referentie te maken.
///
/// # Example
///
/// ```
/// use std::ptr;
///
/// #[repr(packed)]
/// struct Packed {
///     f1: u8,
///     f2: u16,
/// }
///
/// let packed = Packed { f1: 1, f2: 2 };
/// // `&packed.f2` zou een niet-uitgelijnde referentie creëren, en dus ongedefinieerd gedrag zijn!
/// let raw_f2 = ptr::addr_of!(packed.f2);
/// assert_eq!(unsafe { raw_f2.read_unaligned() }, 2);
/// ```
///
#[stable(feature = "raw_ref_macros", since = "1.51.0")]
#[rustc_macro_transparency = "semitransparent"]
#[allow_internal_unstable(raw_ref_op)]
pub macro addr_of($place:expr) {
    &raw const $place
}

/// Maak een `mut` onbewerkte pointer naar een plaats, zonder een tussenliggende referentie te maken.
///
/// Het maken van een referentie met `&`/`&mut` is alleen toegestaan als de pointer correct is uitgelijnd en naar geïnitialiseerde gegevens verwijst.
/// Voor gevallen waarin die vereisten niet gelden, moeten in plaats daarvan onbewerkte verwijzingen worden gebruikt.
/// `&mut expr as *mut _` maakt echter een referentie voordat deze naar een onbewerkte pointer wordt gecast, en die referentie is onderworpen aan dezelfde regels als alle andere referenties.
///
/// Deze macro kan een onbewerkte pointer *maken zonder* eerst een referentie te maken.
///
/// # Example
///
/// ```
/// use std::ptr;
///
/// #[repr(packed)]
/// struct Packed {
///     f1: u8,
///     f2: u16,
/// }
///
/// let mut packed = Packed { f1: 1, f2: 2 };
/// // `&mut packed.f2` zou een niet-uitgelijnde referentie creëren, en dus ongedefinieerd gedrag zijn!
/// let raw_f2 = ptr::addr_of_mut!(packed.f2);
/// unsafe { raw_f2.write_unaligned(42); }
/// assert_eq!({packed.f2}, 42); // `{...}` dwingt het kopiëren van het veld in plaats van het maken van een referentie.
/// ```
///
#[stable(feature = "raw_ref_macros", since = "1.51.0")]
#[rustc_macro_transparency = "semitransparent"]
#[allow_internal_unstable(raw_ref_op)]
pub macro addr_of_mut($place:expr) {
    &raw mut $place
}