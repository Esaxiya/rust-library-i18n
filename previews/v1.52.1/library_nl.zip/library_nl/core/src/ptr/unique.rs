use crate::convert::From;
use crate::fmt;
use crate::marker::{PhantomData, Unsize};
use crate::mem;
use crate::ops::{CoerceUnsized, DispatchFromDyn};

/// Een wrapper rond een onbewerkte niet-nul `*mut T` die aangeeft dat de bezitter van deze wrapper eigenaar is van de referent.
/// Handig voor het bouwen van abstracties zoals `Box<T>`, `Vec<T>`, `String` en `HashMap<K, V>`.
///
/// In tegenstelling tot `*mut T` gedraagt `Unique<T>` zich "as if", het was een instantie van `T`.
/// Het implementeert `Send`/`Sync` als `T` `Send`/`Sync` is.
/// Het impliceert ook het soort sterke aliasinggaranties dat een instantie van `T` kan verwachten:
/// de referent van de aanwijzer mag niet worden gewijzigd zonder een uniek pad naar zijn eigen Unique.
///
/// Als u niet zeker weet of het juist is om `Unique` voor uw doeleinden te gebruiken, overweeg dan om `NonNull` te gebruiken, die een zwakkere semantiek heeft.
///
///
/// In tegenstelling tot `*mut T` moet de aanwijzer altijd niet nul zijn, zelfs als er nooit dereferentie naar de aanwijzer wordt gemaakt.
/// Dit is zodat enums deze verboden waarde als discriminant kunnen gebruiken-`Option<Unique<T>>` heeft dezelfde grootte als `Unique<T>`.
/// De aanwijzer kan echter nog steeds bungelen als er niet naar wordt verwezen.
///
/// In tegenstelling tot `*mut T` is `Unique<T>` covariant ten opzichte van `T`.
/// Dit moet altijd correct zijn voor elk type dat voldoet aan de aliasvereisten van Unique.
///
///
///
#[unstable(
    feature = "ptr_internals",
    issue = "none",
    reason = "use `NonNull` instead and consider `PhantomData<T>` \
              (if you also use `#[may_dangle]`), `Send`, and/or `Sync`"
)]
#[doc(hidden)]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
pub struct Unique<T: ?Sized> {
    pointer: *const T,
    // NOTE: deze marker heeft geen gevolgen voor variantie, maar is wel noodzakelijk
    // zodat dropck begrijpt dat we logischerwijs een `T` bezitten.
    //
    // Zie voor details:
    // https://github.com/rust-lang/rfcs/blob/master/text/0769-sound-generic-drop.md#phantom-data
    _marker: PhantomData<T>,
}

/// `Unique` aanwijzers zijn `Send` als `T` `Send` is, omdat de gegevens waarnaar ze verwijzen niet-alias zijn.
/// Merk op dat deze aliasing-invariant niet wordt afgedwongen door het typesysteem;de abstractie die de `Unique` gebruikt, moet deze afdwingen.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Send + ?Sized> Send for Unique<T> {}

/// `Unique` aanwijzers zijn `Sync` als `T` `Sync` is, omdat de gegevens waarnaar ze verwijzen niet-alias zijn.
/// Merk op dat deze aliasing-invariant niet wordt afgedwongen door het typesysteem;de abstractie die de `Unique` gebruikt, moet deze afdwingen.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Sync + ?Sized> Sync for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: Sized> Unique<T> {
    /// Creëert een nieuwe `Unique` die bungelt, maar goed uitgelijnd.
    ///
    /// Dit is handig voor het initialiseren van typen die lui toewijzen, zoals `Vec::new` doet.
    ///
    /// Merk op dat de pointerwaarde mogelijk een geldige pointer naar een `T` vertegenwoordigt, wat betekent dat deze niet mag worden gebruikt als een "not yet initialized" sentinel-waarde.
    /// Typen die lui toewijzen, moeten de initialisatie op een andere manier volgen.
    ///
    ///
    ///
    #[inline]
    pub const fn dangling() -> Self {
        // VEILIGHEID: mem::align_of() retourneert een geldige pointer die niet nul is.De
        // voorwaarden om new_unchecked() te bellen worden dus gerespecteerd.
        unsafe { Unique::new_unchecked(mem::align_of::<T>() as *mut T) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Unique<T> {
    /// Maakt een nieuwe `Unique`.
    ///
    /// # Safety
    ///
    /// `ptr` mag niet nul zijn.
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // VEILIGHEID: de beller moet garanderen dat `ptr` niet nul is.
        unsafe { Unique { pointer: ptr as _, _marker: PhantomData } }
    }

    /// Maakt een nieuwe `Unique` als `ptr` niet nul is.
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // VEILIGHEID: De aanwijzer is al gecontroleerd en is niet nul.
            Some(unsafe { Unique { pointer: ptr as _, _marker: PhantomData } })
        } else {
            None
        }
    }

    /// Verwerft de onderliggende `*mut`-aanwijzer.
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// Dereferenties van de inhoud.
    ///
    /// De resulterende levensduur is aan zichzelf gebonden, dus dit gedraagt zich "as if", het was eigenlijk een instantie van T die wordt geleend.
    /// Gebruik `&*my_ptr.as_ptr()` als een langere levensduur van de (unbound) nodig is.
    ///
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // VEILIGHEID: de beller moet garanderen dat `self` voldoet aan alle
        // vereisten voor een referentie.
        unsafe { &*self.as_ptr() }
    }

    /// Dereferenties van de inhoud op veranderlijke wijze.
    ///
    /// De resulterende levensduur is aan zichzelf gebonden, dus dit gedraagt zich "as if", het was eigenlijk een instantie van T die wordt geleend.
    /// Gebruik `&mut *my_ptr.as_ptr()` als een langere levensduur van de (unbound) nodig is.
    ///
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // VEILIGHEID: de beller moet garanderen dat `self` voldoet aan alle
        // vereisten voor een veranderlijke referentie.
        unsafe { &mut *self.as_ptr() }
    }

    /// Werpt naar een aanwijzer van een ander type.
    #[inline]
    pub const fn cast<U>(self) -> Unique<U> {
        // VEILIGHEID: Unique::new_unchecked() creëert een nieuwe unieke en behoeften
        // de gegeven aanwijzer om niet nul te zijn.
        // Omdat we onszelf als een aanwijzer doorgeven, kan het niet nul zijn.
        unsafe { Unique::new_unchecked(self.as_ptr() as *mut U) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Clone for Unique<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Copy for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Debug for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Pointer for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<&mut T> for Unique<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // VEILIGHEID: Een veranderlijke referentie mag niet null zijn
        unsafe { Unique { pointer: reference as *mut T, _marker: PhantomData } }
    }
}