use crate::cmp::Ordering;
use crate::convert::From;
use crate::fmt;
use crate::hash;
use crate::marker::Unsize;
use crate::mem::{self, MaybeUninit};
use crate::ops::{CoerceUnsized, DispatchFromDyn};
use crate::ptr::Unique;
use crate::slice::{self, SliceIndex};

/// `*mut T` maar niet-nul en covariant.
///
/// Dit is vaak het juiste om te gebruiken bij het bouwen van datastructuren met behulp van onbewerkte verwijzingen, maar is uiteindelijk gevaarlijker in het gebruik vanwege de aanvullende eigenschappen.Als u niet zeker weet of u `NonNull<T>` moet gebruiken, gebruik dan gewoon `*mut T`!
///
/// In tegenstelling tot `*mut T` moet de aanwijzer altijd niet nul zijn, zelfs als er nooit dereferentie naar de aanwijzer wordt gemaakt.Dit is zodat enums deze verboden waarde als discriminant kunnen gebruiken-`Option<NonNull<T>>` heeft dezelfde grootte als `* mut T`.
/// De aanwijzer kan echter nog steeds bungelen als er niet naar wordt verwezen.
///
/// In tegenstelling tot `*mut T`, werd `NonNull<T>` gekozen om covariant te zijn ten opzichte van `T`.Dit maakt het mogelijk om `NonNull<T>` te gebruiken bij het bouwen van covariante typen, maar introduceert het risico van ondeugdelijkheid indien gebruikt in een type dat eigenlijk niet covariant zou moeten zijn.
/// (De tegenovergestelde keuze werd gemaakt voor `*mut T`, hoewel technisch gezien de ondeugdelijkheid alleen kon worden veroorzaakt door het aanroepen van onveilige functies.)
///
/// Covariantie is correct voor de meeste veilige abstracties, zoals `Box`, `Rc`, `Arc`, `Vec` en `LinkedList`.Dit is het geval omdat ze een openbare API bieden die de normale gedeelde XOR-veranderlijke regels van Rust volgt.
///
/// Als uw type niet veilig covariant kan zijn, moet u ervoor zorgen dat het een extra veld bevat om invariantie te bieden.Vaak is dit veld van het type [`PhantomData`], zoals `PhantomData<Cell<T>>` of `PhantomData<&'a mut T>`.
///
/// Merk op dat `NonNull<T>` een `From`-instantie heeft voor `&T`.Dit verandert echter niets aan het feit dat muteren via een (pointer afgeleid van een) gedeelde referentie ongedefinieerd gedrag is, tenzij de mutatie plaatsvindt binnen een [`UnsafeCell<T>`].Hetzelfde geldt voor het creëren van een veranderlijke referentie op basis van een gedeelde referentie.
///
/// Wanneer u deze `From`-instantie zonder `UnsafeCell<T>` gebruikt, is het uw eigen verantwoordelijkheid om ervoor te zorgen dat `as_mut` nooit wordt aangeroepen en `as_ptr` nooit voor mutatie wordt gebruikt.
///
/// [`PhantomData`]: crate::marker::PhantomData
/// [`UnsafeCell<T>`]: crate::cell::UnsafeCell
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "nonnull", since = "1.25.0")]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
#[rustc_nonnull_optimization_guaranteed]
pub struct NonNull<T: ?Sized> {
    pointer: *const T,
}

/// `NonNull` pointers zijn niet `Send` omdat de gegevens waarnaar ze verwijzen mogelijk een alias hebben.
// NB, deze implic is niet nodig, maar zou betere foutmeldingen moeten opleveren.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Send for NonNull<T> {}

/// `NonNull` pointers zijn niet `Sync` omdat de gegevens waarnaar ze verwijzen mogelijk een alias hebben.
// NB, deze implic is niet nodig, maar zou betere foutmeldingen moeten opleveren.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Sync for NonNull<T> {}

impl<T: Sized> NonNull<T> {
    /// Creëert een nieuwe `NonNull` die bungelt, maar goed uitgelijnd.
    ///
    /// Dit is handig voor het initialiseren van typen die lui toewijzen, zoals `Vec::new` doet.
    ///
    /// Merk op dat de pointerwaarde mogelijk een geldige pointer naar een `T` vertegenwoordigt, wat betekent dat deze niet mag worden gebruikt als een "not yet initialized" sentinel-waarde.
    /// Typen die lui toewijzen, moeten de initialisatie op een andere manier volgen.
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_dangling", since = "1.32.0")]
    #[inline]
    pub const fn dangling() -> Self {
        // VEILIGHEID: mem::align_of() retourneert een gebruik dat niet gelijk is aan nul, dat vervolgens wordt gecast
        // naar een * mut T.
        // Daarom is `ptr` niet nul en worden de voorwaarden voor het aanroepen van new_unchecked() gerespecteerd.
        unsafe {
            let ptr = mem::align_of::<T>() as *mut T;
            NonNull::new_unchecked(ptr)
        }
    }

    /// Retourneert een gedeelde verwijzing naar de waarde.In tegenstelling tot [`as_ref`] hoeft de waarde hiervoor niet te worden geïnitialiseerd.
    ///
    /// Zie [`as_uninit_mut`] voor de veranderlijke tegenhanger.
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    ///
    /// # Safety
    ///
    /// Wanneer u deze methode aanroept, moet u ervoor zorgen dat al het volgende waar is:
    ///
    /// * De aanwijzer moet correct zijn uitgelijnd.
    ///
    /// * Het moet "dereferencable" zijn in de zin die is gedefinieerd in [the module documentation].
    ///
    /// * U moet de aliasingregels van Rust afdwingen, aangezien de geretourneerde levensduur `'a` willekeurig wordt gekozen en niet noodzakelijk de werkelijke levensduur van de gegevens weerspiegelt.
    ///
    ///   In het bijzonder, gedurende deze levensduur, mag het geheugen waarnaar de aanwijzer verwijst niet worden gemuteerd (behalve binnen `UnsafeCell`).
    ///
    /// Dit geldt zelfs als het resultaat van deze methode niet wordt gebruikt!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref(&self) -> &MaybeUninit<T> {
        // VEILIGHEID: de beller moet garanderen dat `self` voldoet aan alle
        // vereisten voor een referentie.
        unsafe { &*self.cast().as_ptr() }
    }

    /// Retourneert een unieke verwijzing naar de waarde.In tegenstelling tot [`as_mut`] hoeft de waarde hiervoor niet te worden geïnitialiseerd.
    ///
    /// Zie [`as_uninit_ref`] voor de gedeelde tegenhanger.
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    ///
    /// # Safety
    ///
    /// Wanneer u deze methode aanroept, moet u ervoor zorgen dat al het volgende waar is:
    ///
    /// * De aanwijzer moet correct zijn uitgelijnd.
    ///
    /// * Het moet "dereferencable" zijn in de zin die is gedefinieerd in [the module documentation].
    ///
    /// * U moet de aliasingregels van Rust afdwingen, aangezien de geretourneerde levensduur `'a` willekeurig wordt gekozen en niet noodzakelijk de werkelijke levensduur van de gegevens weerspiegelt.
    ///
    ///   In het bijzonder mag het geheugen waarnaar de aanwijzer verwijst, gedurende deze levensduur niet worden geopend (gelezen of geschreven) via een andere aanwijzer.
    ///
    /// Dit geldt zelfs als het resultaat van deze methode niet wordt gebruikt!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_mut(&mut self) -> &mut MaybeUninit<T> {
        // VEILIGHEID: de beller moet garanderen dat `self` voldoet aan alle
        // vereisten voor een referentie.
        unsafe { &mut *self.cast().as_ptr() }
    }
}

impl<T: ?Sized> NonNull<T> {
    /// Maakt een nieuwe `NonNull`.
    ///
    /// # Safety
    ///
    /// `ptr` mag niet nul zijn.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_new_unchecked", since = "1.32.0")]
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // VEILIGHEID: de beller moet garanderen dat `ptr` niet nul is.
        unsafe { NonNull { pointer: ptr as _ } }
    }

    /// Maakt een nieuwe `NonNull` als `ptr` niet nul is.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // VEILIGHEID: De aanwijzer is al aangevinkt en is niet nul
            Some(unsafe { Self::new_unchecked(ptr) })
        } else {
            None
        }
    }

    /// Voert dezelfde functionaliteit uit als [`std::ptr::from_raw_parts`], behalve dat een `NonNull`-pointer wordt geretourneerd, in tegenstelling tot een onbewerkte `*const`-pointer.
    ///
    ///
    /// Zie de documentatie van [`std::ptr::from_raw_parts`] voor meer details.
    ///
    /// [`std::ptr::from_raw_parts`]: crate::ptr::from_raw_parts
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn from_raw_parts(
        data_address: NonNull<()>,
        metadata: <T as super::Pointee>::Metadata,
    ) -> NonNull<T> {
        // VEILIGHEID: het resultaat van `ptr::from::raw_parts_mut` is niet nul omdat `data_address` dat wel is.
        unsafe {
            NonNull::new_unchecked(super::from_raw_parts_mut(data_address.as_ptr(), metadata))
        }
    }

    /// Decomponeer een (mogelijk brede) pointer in zijn adres-en metadatacomponenten.
    ///
    /// De aanwijzer kan later worden gereconstrueerd met [`NonNull::from_raw_parts`].
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (NonNull<()>, <T as super::Pointee>::Metadata) {
        (self.cast(), super::metadata(self.as_ptr()))
    }

    /// Verwerft de onderliggende `*mut`-aanwijzer.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// Retourneert een gedeelde verwijzing naar de waarde.Als de waarde mogelijk niet is geïnitialiseerd, moet in plaats daarvan [`as_uninit_ref`] worden gebruikt.
    ///
    /// Zie [`as_mut`] voor de veranderlijke tegenhanger.
    ///
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    /// [`as_mut`]: NonNull::as_mut
    ///
    /// # Safety
    ///
    /// Wanneer u deze methode aanroept, moet u ervoor zorgen dat al het volgende waar is:
    ///
    /// * De aanwijzer moet correct zijn uitgelijnd.
    ///
    /// * Het moet "dereferencable" zijn in de zin die is gedefinieerd in [the module documentation].
    ///
    /// * De pointer moet verwijzen naar een geïnitialiseerd exemplaar van `T`.
    ///
    /// * U moet de aliasingregels van Rust afdwingen, aangezien de geretourneerde levensduur `'a` willekeurig wordt gekozen en niet noodzakelijk de werkelijke levensduur van de gegevens weerspiegelt.
    ///
    ///   In het bijzonder, gedurende deze levensduur, mag het geheugen waarnaar de aanwijzer verwijst niet worden gemuteerd (behalve binnen `UnsafeCell`).
    ///
    /// Dit geldt zelfs als het resultaat van deze methode niet wordt gebruikt!
    /// (Het gedeelte over geïnitialiseerd worden is nog niet volledig beslist, maar totdat dit het geval is, is de enige veilige benadering ervoor te zorgen dat ze inderdaad worden geïnitialiseerd.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // VEILIGHEID: de beller moet garanderen dat `self` voldoet aan alle
        // vereisten voor een referentie.
        unsafe { &*self.as_ptr() }
    }

    /// Retourneert een unieke verwijzing naar de waarde.Als de waarde mogelijk niet is geïnitialiseerd, moet in plaats daarvan [`as_uninit_mut`] worden gebruikt.
    ///
    /// Zie [`as_ref`] voor de gedeelde tegenhanger.
    ///
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    /// [`as_ref`]: NonNull::as_ref
    ///
    /// # Safety
    ///
    /// Wanneer u deze methode aanroept, moet u ervoor zorgen dat al het volgende waar is:
    ///
    /// * De aanwijzer moet correct zijn uitgelijnd.
    ///
    /// * Het moet "dereferencable" zijn in de zin die is gedefinieerd in [the module documentation].
    ///
    /// * De pointer moet verwijzen naar een geïnitialiseerd exemplaar van `T`.
    ///
    /// * U moet de aliasingregels van Rust afdwingen, aangezien de geretourneerde levensduur `'a` willekeurig wordt gekozen en niet noodzakelijk de werkelijke levensduur van de gegevens weerspiegelt.
    ///
    ///   In het bijzonder mag het geheugen waarnaar de aanwijzer verwijst, gedurende deze levensduur niet worden geopend (gelezen of geschreven) via een andere aanwijzer.
    ///
    /// Dit geldt zelfs als het resultaat van deze methode niet wordt gebruikt!
    /// (Het gedeelte over geïnitialiseerd worden is nog niet volledig beslist, maar totdat dit het geval is, is de enige veilige benadering ervoor te zorgen dat ze inderdaad worden geïnitialiseerd.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // VEILIGHEID: de beller moet garanderen dat `self` voldoet aan alle
        // vereisten voor een veranderlijke referentie.
        unsafe { &mut *self.as_ptr() }
    }

    /// Werpt naar een aanwijzer van een ander type.
    #[stable(feature = "nonnull_cast", since = "1.27.0")]
    #[rustc_const_stable(feature = "const_nonnull_cast", since = "1.32.0")]
    #[inline]
    pub const fn cast<U>(self) -> NonNull<U> {
        // VEILIGHEID: `self` is een `NonNull`-pointer die noodzakelijkerwijs niet nul is
        unsafe { NonNull::new_unchecked(self.as_ptr() as *mut U) }
    }
}

impl<T> NonNull<[T]> {
    /// Maakt een niet-nul onbewerkt segment van een dunne aanwijzer en een lengte.
    ///
    /// Het `len`-argument is het aantal **elementen**, niet het aantal bytes.
    ///
    /// Deze functie is veilig, maar het verwijderen van de geretourneerde waarde is onveilig.
    /// Zie de documentatie van [`slice::from_raw_parts`] voor veiligheidsvereisten voor segmenten.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(nonnull_slice_from_raw_parts)]
    ///
    /// use std::ptr::NonNull;
    ///
    /// // maak een slice-aanwijzer wanneer u begint met een aanwijzer naar het eerste element
    /// let mut x = [5, 6, 7];
    /// let nonnull_pointer = NonNull::new(x.as_mut_ptr()).unwrap();
    /// let slice = NonNull::slice_from_raw_parts(nonnull_pointer, 3);
    /// assert_eq!(unsafe { slice.as_ref()[2] }, 7);
    /// ```
    ///
    /// (Merk op dat dit voorbeeld kunstmatig een gebruik van deze methode demonstreert, maar `let slice= NonNull::from(&x[..]);` would be a better way to write code like this.)
    ///
    #[unstable(feature = "nonnull_slice_from_raw_parts", issue = "71941")]
    #[rustc_const_unstable(feature = "const_nonnull_slice_from_raw_parts", issue = "71941")]
    #[inline]
    pub const fn slice_from_raw_parts(data: NonNull<T>, len: usize) -> Self {
        // VEILIGHEID: `data` is een `NonNull`-pointer die noodzakelijkerwijs niet nul is
        unsafe { Self::new_unchecked(super::slice_from_raw_parts_mut(data.as_ptr(), len)) }
    }

    /// Retourneert de lengte van een onbewerkt segment dat niet nul is.
    ///
    /// De geretourneerde waarde is het aantal **elementen**, niet het aantal bytes.
    ///
    /// Deze functie is veilig, zelfs wanneer de niet-nul onbewerkte slice niet kan worden afgeleid naar een slice omdat de pointer geen geldig adres heeft.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    #[inline]
    pub const fn len(self) -> usize {
        self.as_ptr().len()
    }

    /// Retourneert een niet-nul-aanwijzer naar de buffer van het segment.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_non_null_ptr(), NonNull::new(1 as *mut i8).unwrap());
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_non_null_ptr(self) -> NonNull<T> {
        // VEILIGHEID: We weten dat `self` niet nul is.
        unsafe { NonNull::new_unchecked(self.as_ptr().as_mut_ptr()) }
    }

    /// Retourneert een onbewerkte aanwijzer naar de buffer van het segment.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_mut_ptr(), 1 as *mut i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_mut_ptr(self) -> *mut T {
        self.as_non_null_ptr().as_ptr()
    }

    /// Retourneert een gedeelde verwijzing naar een segment van mogelijk niet-geïnitialiseerde waarden.In tegenstelling tot [`as_ref`] hoeft de waarde hiervoor niet te worden geïnitialiseerd.
    ///
    /// Zie [`as_uninit_slice_mut`] voor de veranderlijke tegenhanger.
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_slice_mut`]: NonNull::as_uninit_slice_mut
    ///
    /// # Safety
    ///
    /// Wanneer u deze methode aanroept, moet u ervoor zorgen dat al het volgende waar is:
    ///
    /// * De pointer moet [valid] zijn voor leesbewerkingen voor `ptr.len() * mem::size_of::<T>()` vele bytes, en hij moet correct zijn uitgelijnd.Dit betekent in het bijzonder:
    ///
    ///     * Het volledige geheugenbereik van deze slice moet zich in een enkel toegewezen object bevinden!
    ///       Segmenten kunnen nooit meerdere toegewezen objecten omvatten.
    ///
    ///     * De aanwijzer moet worden uitgelijnd, zelfs voor segmenten met een lengte van nul.
    ///     Een reden hiervoor is dat optimalisaties van de lay-out van de opsomming mogelijk afhankelijk zijn van verwijzingen (inclusief segmenten van elke lengte) die zijn uitgelijnd en niet nul zijn om ze te onderscheiden van andere gegevens.
    ///
    ///     U kunt een aanwijzer verkrijgen die bruikbaar is als `data` voor segmenten met een lengte van nul met behulp van [`NonNull::dangling()`].
    ///
    /// * De totale grootte `ptr.len() * mem::size_of::<T>()` van het segment mag niet groter zijn dan `isize::MAX`.
    ///   Zie de veiligheidsdocumentatie van [`pointer::offset`].
    ///
    /// * U moet de aliasingregels van Rust afdwingen, aangezien de geretourneerde levensduur `'a` willekeurig wordt gekozen en niet noodzakelijk de werkelijke levensduur van de gegevens weerspiegelt.
    ///   In het bijzonder, gedurende deze levensduur, mag het geheugen waarnaar de aanwijzer verwijst niet worden gemuteerd (behalve binnen `UnsafeCell`).
    ///
    /// Dit geldt zelfs als het resultaat van deze methode niet wordt gebruikt!
    ///
    /// Zie ook [`slice::from_raw_parts`].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice(&self) -> &[MaybeUninit<T>] {
        // VEILIGHEID: de beller moet zich houden aan het veiligheidscontract voor `as_uninit_slice`.
        unsafe { slice::from_raw_parts(self.cast().as_ptr(), self.len()) }
    }

    /// Retourneert een unieke verwijzing naar een segment met mogelijk niet-geïnitialiseerde waarden.In tegenstelling tot [`as_mut`] hoeft de waarde hiervoor niet te worden geïnitialiseerd.
    ///
    /// Zie [`as_uninit_slice`] voor de gedeelde tegenhanger.
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_slice`]: NonNull::as_uninit_slice
    ///
    /// # Safety
    ///
    /// Wanneer u deze methode aanroept, moet u ervoor zorgen dat al het volgende waar is:
    ///
    /// * De pointer moet [valid] zijn voor lees-en schrijfbewerkingen voor `ptr.len() * mem::size_of::<T>()` vele bytes, en hij moet correct zijn uitgelijnd.Dit betekent in het bijzonder:
    ///
    ///     * Het volledige geheugenbereik van deze slice moet zich in een enkel toegewezen object bevinden!
    ///       Segmenten kunnen nooit meerdere toegewezen objecten omvatten.
    ///
    ///     * De aanwijzer moet worden uitgelijnd, zelfs voor segmenten met een lengte van nul.
    ///     Een reden hiervoor is dat optimalisaties van de lay-out van de opsomming mogelijk afhankelijk zijn van verwijzingen (inclusief segmenten van elke lengte) die zijn uitgelijnd en niet nul zijn om ze te onderscheiden van andere gegevens.
    ///
    ///     U kunt een aanwijzer verkrijgen die bruikbaar is als `data` voor segmenten met een lengte van nul met behulp van [`NonNull::dangling()`].
    ///
    /// * De totale grootte `ptr.len() * mem::size_of::<T>()` van het segment mag niet groter zijn dan `isize::MAX`.
    ///   Zie de veiligheidsdocumentatie van [`pointer::offset`].
    ///
    /// * U moet de aliasingregels van Rust afdwingen, aangezien de geretourneerde levensduur `'a` willekeurig wordt gekozen en niet noodzakelijk de werkelijke levensduur van de gegevens weerspiegelt.
    ///   In het bijzonder mag het geheugen waarnaar de aanwijzer verwijst, gedurende deze levensduur niet worden geopend (gelezen of geschreven) via een andere aanwijzer.
    ///
    /// Dit geldt zelfs als het resultaat van deze methode niet wordt gebruikt!
    ///
    /// Zie ook [`slice::from_raw_parts_mut`].
    ///
    /// [valid]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(allocator_api, ptr_as_uninit)]
    ///
    /// use std::alloc::{Allocator, Layout, Global};
    /// use std::mem::MaybeUninit;
    /// use std::ptr::NonNull;
    ///
    /// let memory: NonNull<[u8]> = Global.allocate(Layout::new::<[u8; 32]>())?;
    /// // Dit is veilig omdat `memory` geldig is voor lezen en schrijven voor `memory.len()` vele bytes.
    /// // Merk op dat het aanroepen van `memory.as_mut()` hier niet is toegestaan, omdat de inhoud mogelijk niet is geïnitialiseerd.
    /// # #[allow(unused_variables)]
    /// let slice: &mut [MaybeUninit<u8>] = unsafe { memory.as_uninit_slice_mut() };
    /// # Ok::<_, std::alloc::AllocError>(())
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice_mut(&self) -> &mut [MaybeUninit<T>] {
        // VEILIGHEID: de beller moet zich houden aan het veiligheidscontract voor `as_uninit_slice_mut`.
        unsafe { slice::from_raw_parts_mut(self.cast().as_ptr(), self.len()) }
    }

    /// Retourneert een onbewerkte pointer naar een element of subslice, zonder de grenzen te controleren.
    ///
    /// Het aanroepen van deze methode met een out-of-bounds index of wanneer `self` niet kan worden afgeleid, is *[ongedefinieerd gedrag]* zelfs als de resulterende pointer niet wordt gebruikt.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let x = &mut [1, 2, 4];
    /// let x = NonNull::slice_from_raw_parts(NonNull::new(x.as_mut_ptr()).unwrap(), x.len());
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked_mut(1).as_ptr(), x.as_non_null_ptr().as_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(self, index: I) -> NonNull<I::Output>
    where
        I: SliceIndex<[T]>,
    {
        // VEILIGHEID: de beller zorgt ervoor dat `self` niet kan worden verwezen en `index` in-bounds is.
        // Als gevolg hiervan kan de resulterende pointer niet NULL zijn.
        unsafe { NonNull::new_unchecked(self.as_ptr().get_unchecked_mut(index)) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Clone for NonNull<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Copy for NonNull<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Debug for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Pointer for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Eq for NonNull<T> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialEq for NonNull<T> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        self.as_ptr() == other.as_ptr()
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Ord for NonNull<T> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        self.as_ptr().cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialOrd for NonNull<T> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.as_ptr().partial_cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> hash::Hash for NonNull<T> {
    #[inline]
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.as_ptr().hash(state)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<Unique<T>> for NonNull<T> {
    #[inline]
    fn from(unique: Unique<T>) -> Self {
        // VEILIGHEID: Een unieke aanwijzer kan niet nul zijn, dus de voorwaarden voor
        // new_unchecked() worden gerespecteerd.
        unsafe { NonNull::new_unchecked(unique.as_ptr()) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&mut T> for NonNull<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // VEILIGHEID: Een veranderlijke referentie mag niet null zijn.
        unsafe { NonNull { pointer: reference as *mut T } }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&T> for NonNull<T> {
    #[inline]
    fn from(reference: &T) -> Self {
        // VEILIGHEID: Een verwijzing kan niet null zijn, dus de voorwaarden voor
        // new_unchecked() worden gerespecteerd.
        unsafe { NonNull { pointer: reference as *const T } }
    }
}