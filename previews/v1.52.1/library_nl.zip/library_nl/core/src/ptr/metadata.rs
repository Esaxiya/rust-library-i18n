#![unstable(feature = "ptr_metadata", issue = "81513")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

/// Biedt het type metagegevens van de aanwijzer van elk willekeurig type met aanwijzer.
///
/// # Metagegevens van de aanwijzer
///
/// Onbewerkte aanwijzertypen en referentietypes in Rust kunnen worden gezien als bestaande uit twee delen:
/// een gegevenspointer die het geheugenadres van de waarde bevat, en enkele metagegevens.
///
/// Voor typen met een statische grootte (die de `Sized` traits implementeren) en voor `extern`-typen, wordt gezegd dat de aanwijzers "dun" zijn: metagegevens hebben een grootte van nul en het type is `()`.
///
///
/// Er wordt gezegd dat verwijzingen naar [dynamically-sized types][dst] "breed" of "dik" zijn, ze hebben metadata ter grootte van een ander formaat:
///
/// * Voor structs waarvan het laatste veld een DST is, zijn metadata de metadata voor het laatste veld
/// * Voor het `str`-type is metadata de lengte in bytes als `usize`
/// * Voor slice-typen zoals `[T]` is metadata de lengte in items als `usize`
/// * Voor trait-objecten zoals `dyn SomeTrait` is metadata [`DynMetadata<Self>`][DynMetadata] (bijv.`DynMetadata<dyn SomeTrait>`)
///
/// In de future kan de Rust-taal nieuwe soorten typen krijgen die verschillende pointer-metadata hebben.
///
/// [dst]: https://doc.rust-lang.org/nomicon/exotic-sizes.html#dynamically-sized-types-dsts
///
/// # De `Pointee` trait
///
/// Het punt van deze trait is het bijbehorende `Metadata`-type, dat `()` of `usize` of `DynMetadata<_>` is, zoals hierboven beschreven.
/// Het wordt automatisch geïmplementeerd voor elk type.
/// Aangenomen kan worden dat het in een generieke context wordt geïmplementeerd, zelfs zonder een overeenkomstige binding.
///
/// # Usage
///
/// Ruwe pointers kunnen met hun [`to_raw_parts`]-methode worden ontleed in de data-adres-en metadatacomponenten.
///
/// Als alternatief kunnen alleen metagegevens worden geëxtraheerd met de [`metadata`]-functie.
/// Een verwijzing kan worden doorgegeven aan [`metadata`] en impliciet worden afgedwongen.
///
/// Een (possibly-wide)-aanwijzer kan weer worden samengesteld uit zijn adres en metadata met [`from_raw_parts`] of [`from_raw_parts_mut`].
///
/// [`to_raw_parts`]: *const::to_raw_parts
///
///
///
///
///
///
///
///
///
#[lang = "pointee_trait"]
pub trait Pointee {
    /// Het type voor metadata in verwijzingen en verwijzingen naar `Self`.
    #[lang = "metadata_type"]
    // NOTE: Houd trait bounds in `static_assert_expected_bounds_for_metadata`
    //
    // in `library/core/src/ptr/metadata.rs` synchroon met die hier:
    type Metadata: Copy + Send + Sync + Ord + Hash + Unpin;
}

/// Aanwijzers naar typen die deze trait-alias implementeren, zijn "dun".
///
/// Dit omvat statisch 'grootte'-typen en `extern`-typen.
///
/// # Example
///
/// ```rust
/// #![feature(ptr_metadata)]
///
/// fn this_never_panics<T: std::ptr::Thin>() {
///     assert_eq!(std::mem::size_of::<&T>(), std::mem::size_of::<usize>())
/// }
/// ```
#[unstable(feature = "ptr_metadata", issue = "81513")]
// NOTE: dit niet stabiliseren voordat de aliassen van trait stabiel zijn in de taal?
pub trait Thin = Pointee<Metadata = ()>;

/// Extraheer de metagegevenscomponent van een aanwijzer.
///
/// Waarden van het type `*mut T`, `&T` of `&mut T` kunnen rechtstreeks aan deze functie worden doorgegeven, aangezien ze impliciet dwingen tot `* const T`.
///
///
/// # Example
///
/// ```
/// #![feature(ptr_metadata)]
///
/// assert_eq!(std::ptr::metadata("foo"), 3_usize);
/// ```
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn metadata<T: ?Sized>(ptr: *const T) -> <T as Pointee>::Metadata {
    // VEILIGHEID: Toegang tot de waarde van de `PtrRepr`-unie is veilig sinds * const T
    // en PtrComponents<T>dezelfde geheugenlay-outs hebben.
    // Alleen std kan deze garantie geven.
    unsafe { PtrRepr { const_ptr: ptr }.components.metadata }
}

/// Vormt een (possibly-wide)-onbewerkte pointer op basis van een gegevensadres en metagegevens.
///
/// Deze functie is veilig, maar de geretourneerde aanwijzer is niet per se veilig om de verwijzing te verwijderen.
/// Zie voor coupes de documentatie van [`slice::from_raw_parts`] voor veiligheidsvereisten.
/// Voor trait-objecten moeten de metadata afkomstig zijn van een pointer naar hetzelfde onderliggende gewiste type.
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts<T: ?Sized>(
    data_address: *const (),
    metadata: <T as Pointee>::Metadata,
) -> *const T {
    // VEILIGHEID: Toegang tot de waarde van de `PtrRepr`-unie is veilig sinds * const T
    // en PtrComponents<T>dezelfde geheugenlay-outs hebben.
    // Alleen std kan deze garantie geven.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.const_ptr }
}

/// Voert dezelfde functionaliteit uit als [`from_raw_parts`], behalve dat een onbewerkte `*mut`-aanwijzer wordt geretourneerd, in tegenstelling tot een onbewerkte `* const`-aanwijzer.
///
///
/// Zie de documentatie van [`from_raw_parts`] voor meer details.
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts_mut<T: ?Sized>(
    data_address: *mut (),
    metadata: <T as Pointee>::Metadata,
) -> *mut T {
    // VEILIGHEID: Toegang tot de waarde van de `PtrRepr`-unie is veilig sinds * const T
    // en PtrComponents<T>dezelfde geheugenlay-outs hebben.
    // Alleen std kan deze garantie geven.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.mut_ptr }
}

#[repr(C)]
pub(crate) union PtrRepr<T: ?Sized> {
    pub(crate) const_ptr: *const T,
    pub(crate) mut_ptr: *mut T,
    pub(crate) components: PtrComponents<T>,
}

#[repr(C)]
pub(crate) struct PtrComponents<T: ?Sized> {
    pub(crate) data_address: *const (),
    pub(crate) metadata: <T as Pointee>::Metadata,
}

// Handmatige impl nodig om `T: Copy`-gebonden te vermijden.
impl<T: ?Sized> Copy for PtrComponents<T> {}

// Handmatige impl nodig om `T: Clone`-gebonden te vermijden.
impl<T: ?Sized> Clone for PtrComponents<T> {
    fn clone(&self) -> Self {
        *self
    }
}

/// De metadata voor een `Dyn = dyn SomeTrait` trait-objecttype.
///
/// Het is een pointer naar een vtable (virtuele oproeptabel) die alle benodigde informatie vertegenwoordigt om het betontype te manipuleren dat is opgeslagen in een trait-object.
/// De vtable bevat met name:
///
/// * type maat
/// * type uitlijning
/// * een pointer naar de `drop_in_place` impl van het type (kan een no-op zijn voor gewone oude data)
/// * verwijst naar alle methoden voor de implementatie van het type van de trait
///
/// Merk op dat de eerste drie speciaal zijn omdat ze nodig zijn om elk trait-object toe te wijzen, te verwijderen en ongedaan te maken.
///
/// Het is mogelijk om deze structuur een naam te geven met een typeparameter die geen `dyn` trait-object is (bijvoorbeeld `DynMetadata<u64>`), maar om geen betekenisvolle waarde van die structuur te verkrijgen.
///
///
///
///
#[lang = "dyn_metadata"]
pub struct DynMetadata<Dyn: ?Sized> {
    vtable_ptr: &'static VTable,
    phantom: crate::marker::PhantomData<Dyn>,
}

/// Het gemeenschappelijke voorvoegsel van alle vtables.Het wordt gevolgd door functiewijzers voor trait-methoden.
///
/// Privé-implementatiedetail van `DynMetadata::size_of` enz.
#[repr(C)]
struct VTable {
    drop_in_place: fn(*mut ()),
    size_of: usize,
    align_of: usize,
}

impl<Dyn: ?Sized> DynMetadata<Dyn> {
    /// Retourneert de grootte van het type dat aan deze vtable is gekoppeld.
    #[inline]
    pub fn size_of(self) -> usize {
        self.vtable_ptr.size_of
    }

    /// Retourneert de uitlijning van het type dat aan deze vtable is gekoppeld.
    #[inline]
    pub fn align_of(self) -> usize {
        self.vtable_ptr.align_of
    }

    /// Retourneert de grootte en uitlijning samen als een `Layout`
    #[inline]
    pub fn layout(self) -> crate::alloc::Layout {
        // VEILIGHEID: de compiler heeft deze vtable uitgezonden voor een concreet Rust-type dat
        // is bekend dat het een geldige lay-out heeft.Dezelfde grondgedachte als in `Layout::for_value`.
        unsafe { crate::alloc::Layout::from_size_align_unchecked(self.size_of(), self.align_of()) }
    }
}

unsafe impl<Dyn: ?Sized> Send for DynMetadata<Dyn> {}
unsafe impl<Dyn: ?Sized> Sync for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> fmt::Debug for DynMetadata<Dyn> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("DynMetadata").field(&(self.vtable_ptr as *const VTable)).finish()
    }
}

// Handmatige impls nodig om `Dyn: $Trait`-grenzen te vermijden.

impl<Dyn: ?Sized> Unpin for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Copy for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Clone for DynMetadata<Dyn> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

impl<Dyn: ?Sized> Eq for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> PartialEq for DynMetadata<Dyn> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        crate::ptr::eq::<VTable>(self.vtable_ptr, other.vtable_ptr)
    }
}

impl<Dyn: ?Sized> Ord for DynMetadata<Dyn> {
    #[inline]
    fn cmp(&self, other: &Self) -> crate::cmp::Ordering {
        (self.vtable_ptr as *const VTable).cmp(&(other.vtable_ptr as *const VTable))
    }
}

impl<Dyn: ?Sized> PartialOrd for DynMetadata<Dyn> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<crate::cmp::Ordering> {
        Some(self.cmp(other))
    }
}

impl<Dyn: ?Sized> Hash for DynMetadata<Dyn> {
    #[inline]
    fn hash<H: Hasher>(&self, hasher: &mut H) {
        crate::ptr::hash::<VTable, _>(self.vtable_ptr, hasher)
    }
}