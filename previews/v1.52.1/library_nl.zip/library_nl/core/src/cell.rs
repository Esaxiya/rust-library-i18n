//! Deelbare veranderlijke containers.
//!
//! De geheugenveiligheid van Rust is gebaseerd op deze regel: Gegeven een object `T` is het alleen mogelijk om een van de volgende te hebben:
//!
//! - Met verschillende onveranderlijke verwijzingen (`&T`) naar het object (ook bekend als **aliasing**).
//! - Met één veranderlijke referentie (`&mut T`) naar het object (ook bekend als **veranderlijkheid**).
//!
//! Dit wordt afgedwongen door de Rust-compiler.Er zijn echter situaties waarin deze regel niet flexibel genoeg is.Soms is het nodig om meerdere verwijzingen naar een object te hebben en het toch te muteren.
//!
//! Deelbare, veranderlijke containers bestaan om veranderlijkheid op een gecontroleerde manier mogelijk te maken, zelfs in de aanwezigheid van aliasing.Zowel [`Cell<T>`] als [`RefCell<T>`] maken het mogelijk om dit op een enkele manier te doen.
//! Noch `Cell<T>` noch `RefCell<T>` zijn echter thread-safe (ze implementeren [`Sync`] niet).
//! Als u aliasing en mutatie tussen meerdere threads moet doen, is het mogelijk om de typen [`Mutex<T>`], [`RwLock<T>`] of [`atomic`] te gebruiken.
//!
//! Waarden van de typen `Cell<T>` en `RefCell<T>` kunnen worden gemuteerd via gedeelde verwijzingen (bijv
//! het gewone `&T`-type), terwijl de meeste Rust-typen alleen kunnen worden gemuteerd door middel van unieke (`&mut T`) referenties.
//! We zeggen dat `Cell<T>` en `RefCell<T>` 'innerlijke veranderlijkheid' bieden, in tegenstelling tot typische Rust-typen die 'erfelijke veranderlijkheid' vertonen.
//!
//! Celtypes zijn er in twee smaken: `Cell<T>` en `RefCell<T>`.`Cell<T>` implementeert interne veranderlijkheid door waarden in en uit de `Cell<T>` te verplaatsen.
//! Om referenties te gebruiken in plaats van waarden, moet men het `RefCell<T>`-type gebruiken, een schrijfvergrendeling verkrijgen alvorens te muteren.`Cell<T>` biedt methoden om de huidige interne waarde op te halen en te wijzigen:
//!
//!  - Voor typen die [`Copy`] implementeren, haalt de [`get`](Cell::get)-methode de huidige interne waarde op.
//!  - Voor typen die [`Default`] implementeren, vervangt de [`take`](Cell::take)-methode de huidige interne waarde door [`Default::default()`] en retourneert de vervangen waarde.
//!  - Voor alle typen vervangt de [`replace`](Cell::replace)-methode de huidige interne waarde en retourneert de vervangen waarde en de [`into_inner`](Cell::into_inner)-methode gebruikt de `Cell<T>` en retourneert de interne waarde.
//!  Bovendien vervangt de [`set`](Cell::set)-methode de interne waarde en laat de vervangen waarde vallen.
//!
//! `RefCell<T>` gebruikt de levensduren van Rust om 'dynamisch lenen' te implementeren, een proces waarbij men aanspraak kan maken op tijdelijke, exclusieve, veranderlijke toegang tot de innerlijke waarde.
//! Leent voor `RefCell<T>`s worden 'tijdens runtime' gevolgd, in tegenstelling tot de oorspronkelijke referentietypes van Rust die volledig statisch worden gevolgd tijdens het compileren.
//! Omdat `RefCell<T>`-leningen dynamisch zijn, is het mogelijk om te proberen een waarde te lenen die al mutabel is geleend;wanneer dit gebeurt, resulteert dit in thread panic.
//!
//! # Wanneer kies je voor innerlijke veranderlijkheid?
//!
//! De meer algemene erfelijke veranderlijkheid, waarbij men unieke toegang moet hebben om een waarde te muteren, is een van de belangrijkste taalelementen die Rust in staat stelt sterk te redeneren over pointer-aliasing, waardoor crashbugs statisch worden voorkomen.
//! Daarom heeft overgeërfde veranderlijkheid de voorkeur, en innerlijke veranderlijkheid is iets van een laatste redmiddel.
//! Aangezien celtypen mutatie mogelijk maken waar het anders niet zou zijn toegestaan, zijn er gevallen waarin innerlijke veranderlijkheid gepast zou kunnen zijn, of zelfs *moet* worden gebruikt, bijv.
//!
//! * Introductie van veranderlijkheid 'inside' van iets onveranderlijks
//! * Implementatiedetails van logisch onveranderlijke methoden.
//! * Muterende implementaties van [`Clone`].
//!
//! ## Introductie van veranderlijkheid 'inside' van iets onveranderlijks
//!
//! Veel gedeelde slimme aanwijzertypen, waaronder [`Rc<T>`] en [`Arc<T>`], bieden containers die kunnen worden gekloond en gedeeld tussen meerdere partijen.
//! Omdat de ingesloten waarden vermenigvuldigd kunnen zijn, kunnen ze alleen worden geleend met `&`, niet met `&mut`.
//! Zonder cellen zou het überhaupt onmogelijk zijn om gegevens binnen deze slimme wijzers te muteren.
//!
//! Het is dan heel gebruikelijk om een `RefCell<T>` in gedeelde aanwijzertypes te plaatsen om veranderlijkheid opnieuw te introduceren:
//!
//! ```
//! use std::cell::{RefCell, RefMut};
//! use std::collections::HashMap;
//! use std::rc::Rc;
//!
//! fn main() {
//!     let shared_map: Rc<RefCell<_>> = Rc::new(RefCell::new(HashMap::new()));
//!     // Maak een nieuw blok om de reikwijdte van de dynamische lening te beperken
//!     {
//!         let mut map: RefMut<_> = shared_map.borrow_mut();
//!         map.insert("africa", 92388);
//!         map.insert("kyoto", 11837);
//!         map.insert("piccadilly", 11826);
//!         map.insert("marbles", 38);
//!     }
//!
//!     // Merk op dat als we de vorige lening van de cache niet buiten bereik hadden laten vallen, de volgende lening een dynamische thread panic zou veroorzaken.
//!     //
//!     // Dit is het grootste gevaar bij het gebruik van `RefCell`.
//!     let total: i32 = shared_map.borrow().values().sum();
//!     println!("{}", total);
//! }
//! ```
//!
//! Merk op dat dit voorbeeld `Rc<T>` gebruikt en niet `Arc<T>`.'RefCell<T>`s zijn voor scenario's met één thread.Overweeg om [`RwLock<T>`] of [`Mutex<T>`] te gebruiken als je gedeelde veranderlijkheid nodig hebt in een situatie met meerdere threads.
//!
//! ## Implementatiedetails van logisch onveranderlijke methoden
//!
//! Af en toe kan het wenselijk zijn om niet in een API te laten zien dat er mutatie plaatsvindt "under the hood".
//! Dit kan zijn omdat de operatie logischerwijs onveranderlijk is, maar caching dwingt bijvoorbeeld de implementatie om mutatie uit te voeren;of omdat u mutatie moet gebruiken om een trait-methode te implementeren die oorspronkelijk was gedefinieerd om `&self` te gebruiken.
//!
//!
//! ```
//! # #![allow(dead_code)]
//! use std::cell::RefCell;
//!
//! struct Graph {
//!     edges: Vec<(i32, i32)>,
//!     span_tree_cache: RefCell<Option<Vec<(i32, i32)>>>
//! }
//!
//! impl Graph {
//!     fn minimum_spanning_tree(&self) -> Vec<(i32, i32)> {
//!         self.span_tree_cache.borrow_mut()
//!             .get_or_insert_with(|| self.calc_span_tree())
//!             .clone()
//!     }
//!
//!     fn calc_span_tree(&self) -> Vec<(i32, i32)> {
//!         // Hier komt een dure berekening voor
//!         vec![]
//!     }
//! }
//! ```
//!
//! ## Muterende implementaties van `Clone`
//!
//! Dit is gewoon een speciaal, maar veel voorkomend geval van het vorige: veranderlijkheid verbergen voor operaties die onveranderlijk lijken te zijn.
//! De [`clone`](Clone::clone)-methode verandert naar verwachting de bronwaarde niet en er wordt verklaard dat deze `&self` accepteert, niet `&mut self`.
//! Daarom moet elke mutatie die plaatsvindt in de `clone`-methode celtypen gebruiken.
//! [`Rc<T>`] handhaaft bijvoorbeeld zijn referentietellingen binnen een `Cell<T>`.
//!
//! ```
//! use std::cell::Cell;
//! use std::ptr::NonNull;
//! use std::process::abort;
//! use std::marker::PhantomData;
//!
//! struct Rc<T: ?Sized> {
//!     ptr: NonNull<RcBox<T>>,
//!     phantom: PhantomData<RcBox<T>>,
//! }
//!
//! struct RcBox<T: ?Sized> {
//!     strong: Cell<usize>,
//!     refcount: Cell<usize>,
//!     value: T,
//! }
//!
//! impl<T: ?Sized> Clone for Rc<T> {
//!     fn clone(&self) -> Rc<T> {
//!         self.inc_strong();
//!         Rc {
//!             ptr: self.ptr,
//!             phantom: PhantomData,
//!         }
//!     }
//! }
//!
//! trait RcBoxPtr<T: ?Sized> {
//!
//!     fn inner(&self) -> &RcBox<T>;
//!
//!     fn strong(&self) -> usize {
//!         self.inner().strong.get()
//!     }
//!
//!     fn inc_strong(&self) {
//!         self.inner()
//!             .strong
//!             .set(self.strong()
//!                      .checked_add(1)
//!                      .unwrap_or_else(|| abort() ));
//!     }
//! }
//!
//! impl<T: ?Sized> RcBoxPtr<T> for Rc<T> {
//!    fn inner(&self) -> &RcBox<T> {
//!        unsafe {
//!            self.ptr.as_ref()
//!        }
//!    }
//! }
//! ```
//!
//! [`Arc<T>`]: ../../std/sync/struct.Arc.html
//! [`Rc<T>`]: ../../std/rc/struct.Rc.html
//! [`RwLock<T>`]: ../../std/sync/struct.RwLock.html
//! [`Mutex<T>`]: ../../std/sync/struct.Mutex.html
//! [`atomic`]: ../../core/sync/atomic/index.html
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering;
use crate::fmt::{self, Debug, Display};
use crate::marker::Unsize;
use crate::mem;
use crate::ops::{CoerceUnsized, Deref, DerefMut};
use crate::ptr;

/// Een veranderlijke geheugenlocatie.
///
/// # Examples
///
/// In dit voorbeeld kunt u zien dat `Cell<T>` mutatie mogelijk maakt binnen een onveranderlijke structuur.
/// Met andere woorden, het maakt "interior mutability" mogelijk.
///
/// ```
/// use std::cell::Cell;
///
/// struct SomeStruct {
///     regular_field: u8,
///     special_field: Cell<u8>,
/// }
///
/// let my_struct = SomeStruct {
///     regular_field: 0,
///     special_field: Cell::new(1),
/// };
///
/// let new_value = 100;
///
/// // FOUT: `my_struct` is onveranderlijk
/// // my_struct.regular_field =nieuwe_waarde;
///
/// // WERKT: hoewel `my_struct` onveranderlijk is, is `special_field` een `Cell`,
/// // die altijd kan worden gemuteerd
/// my_struct.special_field.set(new_value);
/// assert_eq!(my_struct.special_field.get(), new_value);
/// ```
///
/// Zie de [module-level documentation](self) voor meer.
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
pub struct Cell<T: ?Sized> {
    value: UnsafeCell<T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for Cell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for Cell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Copy> Clone for Cell<T> {
    #[inline]
    fn clone(&self) -> Cell<T> {
        Cell::new(self.get())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Cell<T> {
    /// Creëert een `Cell<T>`, met de `Default`-waarde voor T.
    #[inline]
    fn default() -> Cell<T> {
        Cell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialEq + Copy> PartialEq for Cell<T> {
    #[inline]
    fn eq(&self, other: &Cell<T>) -> bool {
        self.get() == other.get()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: Eq + Copy> Eq for Cell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: PartialOrd + Copy> PartialOrd for Cell<T> {
    #[inline]
    fn partial_cmp(&self, other: &Cell<T>) -> Option<Ordering> {
        self.get().partial_cmp(&other.get())
    }

    #[inline]
    fn lt(&self, other: &Cell<T>) -> bool {
        self.get() < other.get()
    }

    #[inline]
    fn le(&self, other: &Cell<T>) -> bool {
        self.get() <= other.get()
    }

    #[inline]
    fn gt(&self, other: &Cell<T>) -> bool {
        self.get() > other.get()
    }

    #[inline]
    fn ge(&self, other: &Cell<T>) -> bool {
        self.get() >= other.get()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: Ord + Copy> Ord for Cell<T> {
    #[inline]
    fn cmp(&self, other: &Cell<T>) -> Ordering {
        self.get().cmp(&other.get())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for Cell<T> {
    fn from(t: T) -> Cell<T> {
        Cell::new(t)
    }
}

impl<T> Cell<T> {
    /// Maakt een nieuwe `Cell` met de opgegeven waarde.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> Cell<T> {
        Cell { value: UnsafeCell::new(value) }
    }

    /// Stelt de ingesloten waarde in.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// c.set(10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn set(&self, val: T) {
        let old = self.replace(val);
        drop(old);
    }

    /// Wisselt de waarden van twee cellen om.
    /// Het verschil met `std::mem::swap` is dat deze functie geen `&mut`-referentie vereist.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c1 = Cell::new(5i32);
    /// let c2 = Cell::new(10i32);
    /// c1.swap(&c2);
    /// assert_eq!(10, c1.get());
    /// assert_eq!(5, c2.get());
    /// ```
    #[inline]
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn swap(&self, other: &Self) {
        if ptr::eq(self, other) {
            return;
        }
        // VEILIGHEID: Dit kan riskant zijn als het wordt aangeroepen vanuit afzonderlijke threads, maar `Cell`
        // is `!Sync`, dus dit zal niet gebeuren.
        // Dit zal ook geen enkele aanwijzing ongeldig maken, aangezien `Cell` ervoor zorgt dat niets anders naar een van deze `Cell`s zal verwijzen.
        //
        unsafe {
            ptr::swap(self.value.get(), other.value.get());
        }
    }

    /// Vervangt de ingesloten waarde door `val` en retourneert de oude ingesloten waarde.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let cell = Cell::new(5);
    /// assert_eq!(cell.get(), 5);
    /// assert_eq!(cell.replace(10), 5);
    /// assert_eq!(cell.get(), 10);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn replace(&self, val: T) -> T {
        // VEILIGHEID: Dit kan dataraces veroorzaken als deze wordt aangeroepen vanuit een aparte thread,
        // maar `Cell` is `!Sync`, dus dit zal niet gebeuren.
        mem::replace(unsafe { &mut *self.value.get() }, val)
    }

    /// Maakt de waarde los.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.into_inner();
    ///
    /// assert_eq!(five, 5);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value.into_inner()
    }
}

impl<T: Copy> Cell<T> {
    /// Retourneert een kopie van de ingesloten waarde.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let five = c.get();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get(&self) -> T {
        // VEILIGHEID: Dit kan dataraces veroorzaken als deze wordt aangeroepen vanuit een aparte thread,
        // maar `Cell` is `!Sync`, dus dit zal niet gebeuren.
        unsafe { *self.value.get() }
    }

    /// Werkt de ingesloten waarde bij met behulp van een functie en retourneert de nieuwe waarde.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_update)]
    ///
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let new = c.update(|x| x + 1);
    ///
    /// assert_eq!(new, 6);
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[unstable(feature = "cell_update", issue = "50186")]
    pub fn update<F>(&self, f: F) -> T
    where
        F: FnOnce(T) -> T,
    {
        let old = self.get();
        let new = f(old);
        self.set(new);
        new
    }
}

impl<T: ?Sized> Cell<T> {
    /// Retourneert een onbewerkte aanwijzer naar de onderliggende gegevens in deze cel.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    #[rustc_const_stable(feature = "const_cell_as_ptr", since = "1.32.0")]
    pub const fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// Retourneert een veranderlijke verwijzing naar de onderliggende gegevens.
    ///
    /// Deze aanroep leent `Cell` veranderlijk (tijdens het compileren), wat garandeert dat we de enige referentie hebben.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let mut c = Cell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// Retourneert een `&Cell<T>` van een `&mut T`
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[inline]
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn from_mut(t: &mut T) -> &Cell<T> {
        // VEILIGHEID: `&mut` zorgt voor een unieke toegang.
        unsafe { &*(t as *mut T as *const Cell<T>) }
    }
}

impl<T: Default> Cell<T> {
    /// Neemt de waarde van de cel over, waardoor `Default::default()` op zijn plaats blijft.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<Cell<U>> for Cell<T> {}

impl<T> Cell<[T]> {
    /// Retourneert een `&[Cell<T>]` van een `&Cell<[T]>`
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn as_slice_of_cells(&self) -> &[Cell<T>] {
        // VEILIGHEID: `Cell<T>` heeft dezelfde geheugenlay-out als `T`.
        unsafe { &*(self as *const Cell<[T]> as *const [Cell<T>]) }
    }
}

/// Een veranderlijke geheugenlocatie met dynamisch gecontroleerde uitleenregels
///
/// Zie de [module-level documentation](self) voor meer.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefCell<T: ?Sized> {
    borrow: Cell<BorrowFlag>,
    value: UnsafeCell<T>,
}

/// Een fout geretourneerd door [`RefCell::try_borrow`].
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already mutably borrowed", f)
    }
}

/// Een fout geretourneerd door [`RefCell::try_borrow_mut`].
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowMutError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowMutError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already borrowed", f)
    }
}

// Positieve waarden vertegenwoordigen het aantal actieve `Ref`.Negatieve waarden vertegenwoordigen het aantal actieve `RefMut`.
// Meerdere `RefMut`s kunnen alleen actief zijn als ze verwijzen naar verschillende, niet-overlappende componenten van een `RefCell` (bijv. Verschillende bereiken van een slice).
//
// `Ref` en `RefMut` zijn beide twee woorden groot, en dus zullen er waarschijnlijk nooit genoeg `Ref`s of`RefMut`s bestaan om de helft van het `usize` bereik te overlopen.
// Een `BorrowFlag` zal dus waarschijnlijk nooit overlopen of onderlopen.
// Dit is echter geen garantie, aangezien een pathologisch programma herhaaldelijk mem::forget `Ref`s of`RefMut`s.
// Alle code moet dus expliciet controleren op overloop en onderloop om onveiligheid te voorkomen, of zich in ieder geval correct te gedragen in het geval dat er overloop of onderloop optreedt (zie bijvoorbeeld BorrowRef::new).
//
//
//
//
//
//
type BorrowFlag = isize;
const UNUSED: BorrowFlag = 0;

#[inline(always)]
fn is_writing(x: BorrowFlag) -> bool {
    x < UNUSED
}

#[inline(always)]
fn is_reading(x: BorrowFlag) -> bool {
    x > UNUSED
}

impl<T> RefCell<T> {
    /// Maakt een nieuwe `RefCell` met `value`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_refcell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> RefCell<T> {
        RefCell { value: UnsafeCell::new(value), borrow: Cell::new(UNUSED) }
    }

    /// Verbruikt de `RefCell` en retourneert de ingepakte waarde.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let five = c.into_inner();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    #[inline]
    pub const fn into_inner(self) -> T {
        // Aangezien deze functie `self` (de `RefCell`) op waarde neemt, verifieert de compiler statisch dat het momenteel niet geleend is.
        //
        self.value.into_inner()
    }

    /// Vervangt de ingepakte waarde door een nieuwe, waarbij de oude waarde wordt geretourneerd, zonder een van beide te de-initialiseren.
    ///
    ///
    /// Deze functie komt overeen met [`std::mem::replace`](../mem/fn.replace.html).
    ///
    /// # Panics
    ///
    /// Panics als de waarde momenteel wordt uitgeleend.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace(6);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace", since = "1.24.0")]
    #[track_caller]
    pub fn replace(&self, t: T) -> T {
        mem::replace(&mut *self.borrow_mut(), t)
    }

    /// Vervangt de ingepakte waarde door een nieuwe berekend op basis van `f`, waarbij de oude waarde wordt geretourneerd, zonder een van beide te de-initialiseren.
    ///
    ///
    /// # Panics
    ///
    /// Panics als de waarde momenteel wordt uitgeleend.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace_with(|&mut old| old + 1);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace_swap", since = "1.35.0")]
    #[track_caller]
    pub fn replace_with<F: FnOnce(&mut T) -> T>(&self, f: F) -> T {
        let mut_borrow = &mut *self.borrow_mut();
        let replacement = f(mut_borrow);
        mem::replace(mut_borrow, replacement)
    }

    /// Verwisselt de ingepakte waarde van `self` met de ingepakte waarde van `other`, zonder een van beide te de-initialiseren.
    ///
    ///
    /// Deze functie komt overeen met [`std::mem::swap`](../mem/fn.swap.html).
    ///
    /// # Panics
    ///
    /// Panics als de waarde in een van beide `RefCell` momenteel is geleend.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let c = RefCell::new(5);
    /// let d = RefCell::new(6);
    /// c.swap(&d);
    /// assert_eq!(c, RefCell::new(6));
    /// assert_eq!(d, RefCell::new(5));
    /// ```
    #[inline]
    #[stable(feature = "refcell_swap", since = "1.24.0")]
    pub fn swap(&self, other: &Self) {
        mem::swap(&mut *self.borrow_mut(), &mut *other.borrow_mut())
    }
}

impl<T: ?Sized> RefCell<T> {
    /// Leent onveranderlijk de ingepakte waarde.
    ///
    /// De lening duurt totdat de geretourneerde `Ref` het bereik verlaat.
    /// Er kunnen meerdere onveranderlijke leningen tegelijkertijd worden afgesloten.
    ///
    /// # Panics
    ///
    /// Panics als de waarde momenteel mutabel geleend is.
    /// Gebruik [`try_borrow`](#method.try_borrow) voor een niet-paniekerige variant.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let borrowed_five = c.borrow();
    /// let borrowed_five2 = c.borrow();
    /// ```
    ///
    /// Een voorbeeld van panic:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let m = c.borrow_mut();
    /// let b = c.borrow(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow(&self) -> Ref<'_, T> {
        self.try_borrow().expect("already mutably borrowed")
    }

    /// Leent onveranderlijk de ingepakte waarde en retourneert een fout als de waarde momenteel veranderlijk wordt geleend.
    ///
    ///
    /// De lening duurt totdat de geretourneerde `Ref` het bereik verlaat.
    /// Er kunnen meerdere onveranderlijke leningen tegelijkertijd worden afgesloten.
    ///
    /// Dit is de niet-paniekerige variant van [`borrow`](#method.borrow).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(c.try_borrow().is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow().is_ok());
    /// }
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow(&self) -> Result<Ref<'_, T>, BorrowError> {
        match BorrowRef::new(&self.borrow) {
            // VEILIGHEID: `BorrowRef` zorgt ervoor dat er alleen onveranderlijke toegang is
            // aan de waarde terwijl geleend.
            Some(b) => Ok(Ref { value: unsafe { &*self.value.get() }, borrow: b }),
            None => Err(BorrowError { _private: () }),
        }
    }

    /// Leent mutabel de ingepakte waarde.
    ///
    /// Het lenen duurt totdat de geretourneerde `RefMut` of alle `RefMut`s die ervan zijn afgeleid de scope verlaten.
    ///
    /// De waarde kan niet worden geleend zolang deze lening actief is.
    ///
    /// # Panics
    ///
    /// Panics als de waarde momenteel wordt uitgeleend.
    /// Gebruik [`try_borrow_mut`](#method.try_borrow_mut) voor een niet-paniekerige variant.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new("hello".to_owned());
    ///
    /// *c.borrow_mut() = "bonjour".to_owned();
    ///
    /// assert_eq!(&*c.borrow(), "bonjour");
    /// ```
    ///
    /// Een voorbeeld van panic:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let m = c.borrow();
    ///
    /// let b = c.borrow_mut(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow_mut(&self) -> RefMut<'_, T> {
        self.try_borrow_mut().expect("already borrowed")
    }

    /// Leent mutabel de ingepakte waarde en retourneert een fout als de waarde momenteel wordt geleend.
    ///
    ///
    /// Het lenen duurt totdat de geretourneerde `RefMut` of alle `RefMut`s die ervan zijn afgeleid de scope verlaten.
    /// De waarde kan niet worden geleend zolang deze lening actief is.
    ///
    /// Dit is de niet-paniekerige variant van [`borrow_mut`](#method.borrow_mut).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow_mut().is_err());
    /// }
    ///
    /// assert!(c.try_borrow_mut().is_ok());
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow_mut(&self) -> Result<RefMut<'_, T>, BorrowMutError> {
        match BorrowRefMut::new(&self.borrow) {
            // VEILIGHEID: `BorrowRef` garandeert een unieke toegang.
            Some(b) => Ok(RefMut { value: unsafe { &mut *self.value.get() }, borrow: b }),
            None => Err(BorrowMutError { _private: () }),
        }
    }

    /// Retourneert een onbewerkte aanwijzer naar de onderliggende gegevens in deze cel.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    pub fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// Retourneert een veranderlijke verwijzing naar de onderliggende gegevens.
    ///
    /// Deze aanroep leent `RefCell` veranderlijk (tijdens het compileren), dus er zijn geen dynamische controles nodig.
    ///
    /// Wees echter voorzichtig: deze methode verwacht dat `self` veranderlijk is, wat over het algemeen niet het geval is bij gebruik van een `RefCell`.
    ///
    /// Bekijk in plaats daarvan de [`borrow_mut`]-methode als `self` niet veranderlijk is.
    ///
    /// Houd er ook rekening mee dat deze methode alleen voor speciale omstandigheden is en meestal niet is wat u wilt.
    /// Gebruik in geval van twijfel [`borrow_mut`].
    ///
    /// [`borrow_mut`]: RefCell::borrow_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c, RefCell::new(6));
    /// ```
    ///
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// Maak het effect van gelekte bewakers op de geleende staat van de `RefCell` ongedaan.
    ///
    /// Deze oproep is vergelijkbaar met [`get_mut`] maar meer gespecialiseerd.
    /// Het leent `RefCell` op een veranderlijke manier om er zeker van te zijn dat er geen lenen bestaan en stelt vervolgens de status van gedeelde lenen opnieuw in.
    /// Dit is relevant als sommige `Ref`-of `RefMut`-leningen zijn gelekt.
    ///
    /// [`get_mut`]: RefCell::get_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(0);
    /// std::mem::forget(c.borrow_mut());
    ///
    /// assert!(c.try_borrow().is_err());
    /// c.undo_leak();
    /// assert!(c.try_borrow().is_ok());
    /// ```
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn undo_leak(&mut self) -> &mut T {
        *self.borrow.get_mut() = UNUSED;
        self.get_mut()
    }

    /// Leent onveranderlijk de ingepakte waarde en retourneert een fout als de waarde momenteel veranderlijk wordt geleend.
    ///
    /// # Safety
    ///
    /// In tegenstelling tot `RefCell::borrow` is deze methode onveilig omdat het geen `Ref` retourneert, waardoor de leenvlag onaangetast blijft.
    /// Het veranderlijk lenen van de `RefCell` terwijl de referentie die door deze methode wordt geretourneerd, leeft, is ongedefinieerd gedrag.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_ok());
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "borrow_state", since = "1.37.0")]
    #[inline]
    pub unsafe fn try_borrow_unguarded(&self) -> Result<&T, BorrowError> {
        if !is_writing(self.borrow.get()) {
            // VEILIGHEID: We controleren of er nu niemand actief aan het schrijven is, maar dat is het wel
            // de verantwoordelijkheid van de beller om ervoor te zorgen dat niemand schrijft totdat de geretourneerde referentie niet langer in gebruik is.
            // `self.value.get()` verwijst ook naar de waarde die eigendom is van `self` en is dus gegarandeerd geldig voor de levensduur van `self`.
            //
            //
            Ok(unsafe { &*self.value.get() })
        } else {
            Err(BorrowError { _private: () })
        }
    }
}

impl<T: Default> RefCell<T> {
    /// Neemt de ingepakte waarde, waardoor `Default::default()` op zijn plaats blijft.
    ///
    /// # Panics
    ///
    /// Panics als de waarde momenteel wordt uitgeleend.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "refcell_take", since = "1.50.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for RefCell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for RefCell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for RefCell<T> {
    /// # Panics
    ///
    /// Panics als de waarde momenteel mutabel geleend is.
    #[inline]
    #[track_caller]
    fn clone(&self) -> RefCell<T> {
        RefCell::new(self.borrow().clone())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for RefCell<T> {
    /// Creëert een `RefCell<T>`, met de `Default`-waarde voor T.
    #[inline]
    fn default() -> RefCell<T> {
        RefCell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for RefCell<T> {
    /// # Panics
    ///
    /// Panics als de waarde in een van beide `RefCell` momenteel is geleend.
    #[inline]
    fn eq(&self, other: &RefCell<T>) -> bool {
        *self.borrow() == *other.borrow()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: ?Sized + Eq> Eq for RefCell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for RefCell<T> {
    /// # Panics
    ///
    /// Panics als de waarde in een van beide `RefCell` momenteel is geleend.
    #[inline]
    fn partial_cmp(&self, other: &RefCell<T>) -> Option<Ordering> {
        self.borrow().partial_cmp(&*other.borrow())
    }

    /// # Panics
    ///
    /// Panics als de waarde in een van beide `RefCell` momenteel is geleend.
    #[inline]
    fn lt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() < *other.borrow()
    }

    /// # Panics
    ///
    /// Panics als de waarde in een van beide `RefCell` momenteel is geleend.
    #[inline]
    fn le(&self, other: &RefCell<T>) -> bool {
        *self.borrow() <= *other.borrow()
    }

    /// # Panics
    ///
    /// Panics als de waarde in een van beide `RefCell` momenteel is geleend.
    #[inline]
    fn gt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() > *other.borrow()
    }

    /// # Panics
    ///
    /// Panics als de waarde in een van beide `RefCell` momenteel is geleend.
    #[inline]
    fn ge(&self, other: &RefCell<T>) -> bool {
        *self.borrow() >= *other.borrow()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + Ord> Ord for RefCell<T> {
    /// # Panics
    ///
    /// Panics als de waarde in een van beide `RefCell` momenteel is geleend.
    #[inline]
    fn cmp(&self, other: &RefCell<T>) -> Ordering {
        self.borrow().cmp(&*other.borrow())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for RefCell<T> {
    fn from(t: T) -> RefCell<T> {
        RefCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<RefCell<U>> for RefCell<T> {}

struct BorrowRef<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl<'b> BorrowRef<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRef<'b>> {
        let b = borrow.get().wrapping_add(1);
        if !is_reading(b) {
            // Toenemende lenen kunnen in de volgende gevallen resulteren in een niet-afleesbare waarde (<=0):
            // 1. Het was <0, dwz er zijn schrijfleningen, dus we kunnen een leeslening niet toestaan vanwege de referentie-aliasingregels van Rust
            // 2.
            // Het was isize::MAX (het maximale aantal leesleningen) en het liep over in isize::MIN (het maximale aantal schrijfleningen), dus we kunnen geen extra leeslening toestaan omdat isize niet zoveel leesleningen kan vertegenwoordigen (dit kan alleen gebeuren als je mem::forget meer dan een kleine constante hoeveelheid `Ref`s, wat geen goede gewoonte is)
            //
            //
            //
            //
            None
        } else {
            // Het ophogen van lenen kan in deze gevallen resulteren in een leeswaarde (> 0):
            // 1. Het was=0, dat wil zeggen dat het niet is geleend, en we nemen de eerste gelezen lening
            // 2. Het was> 0 en <isize::MAX, dwz
            // er waren gelezen lenen, en isize is groot genoeg om weer te geven dat er nog een gelezen leen is
            borrow.set(b);
            Some(BorrowRef { borrow })
        }
    }
}

impl Drop for BorrowRef<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        self.borrow.set(borrow - 1);
    }
}

impl Clone for BorrowRef<'_> {
    #[inline]
    fn clone(&self) -> Self {
        // Aangezien deze Ref bestaat, weten we dat de leenvlag een leeslening is.
        //
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        // Voorkom dat de uitleenbalie overloopt in een schrijflening.
        //
        assert!(borrow != isize::MAX);
        self.borrow.set(borrow + 1);
        BorrowRef { borrow: self.borrow }
    }
}

/// Wikkelt een geleende verwijzing naar een waarde in een `RefCell`-doos.
/// Een wrapper-type voor een onveranderlijk geleende waarde van een `RefCell<T>`.
///
/// Zie de [module-level documentation](self) voor meer.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Ref<'b, T: ?Sized + 'b> {
    value: &'b T,
    borrow: BorrowRef<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Ref<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

impl<'b, T: ?Sized> Ref<'b, T> {
    /// Kopieert een `Ref`.
    ///
    /// De `RefCell` is al onveranderlijk geleend, dus dit kan niet falen.
    ///
    /// Dit is een bijbehorende functie die moet worden gebruikt als `Ref::clone(...)`.
    /// Een `Clone`-implementatie of een methode zou het wijdverbreide gebruik van `r.borrow().clone()` om de inhoud van een `RefCell` te klonen verstoren.
    ///
    ///
    #[stable(feature = "cell_extras", since = "1.15.0")]
    #[inline]
    pub fn clone(orig: &Ref<'b, T>) -> Ref<'b, T> {
        Ref { value: orig.value, borrow: orig.borrow.clone() }
    }

    /// Maakt een nieuwe `Ref` voor een onderdeel van de geleende data.
    ///
    /// De `RefCell` is al onveranderlijk geleend, dus dit kan niet falen.
    ///
    /// Dit is een bijbehorende functie die moet worden gebruikt als `Ref::map(...)`.
    /// Een methode zou de methoden met dezelfde naam op de inhoud van een `RefCell` die via `Deref` worden gebruikt, verstoren.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// let b1: Ref<(u32, char)> = c.borrow();
    /// let b2: Ref<u32> = Ref::map(b1, |t| &t.0);
    /// assert_eq!(*b2, 5)
    /// ```
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Ref<'b, U>
    where
        F: FnOnce(&T) -> &U,
    {
        Ref { value: f(orig.value), borrow: orig.borrow }
    }

    /// Maakt een nieuwe `Ref` voor een optioneel onderdeel van de geleende data.
    /// De originele bewaker wordt geretourneerd als een `Err(..)` als de sluiting `None` retourneert.
    ///
    /// De `RefCell` is al onveranderlijk geleend, dus dit kan niet falen.
    ///
    /// Dit is een bijbehorende functie die moet worden gebruikt als `Ref::filter_map(...)`.
    /// Een methode zou de methoden met dezelfde naam op de inhoud van een `RefCell` die via `Deref` worden gebruikt, verstoren.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    /// let b1: Ref<Vec<u32>> = c.borrow();
    /// let b2: Result<Ref<u32>, _> = Ref::filter_map(b1, |v| v.get(1));
    /// assert_eq!(*b2.unwrap(), 2);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Result<Ref<'b, U>, Self>
    where
        F: FnOnce(&T) -> Option<&U>,
    {
        match f(orig.value) {
            Some(value) => Ok(Ref { value, borrow: orig.borrow }),
            None => Err(orig),
        }
    }

    /// Splitst een `Ref` in meerdere `Ref`s voor verschillende componenten van de geleende data.
    ///
    /// De `RefCell` is al onveranderlijk geleend, dus dit kan niet falen.
    ///
    /// Dit is een bijbehorende functie die moet worden gebruikt als `Ref::map_split(...)`.
    /// Een methode zou de methoden met dezelfde naam op de inhoud van een `RefCell` die via `Deref` worden gebruikt, verstoren.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{Ref, RefCell};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow();
    /// let (begin, end) = Ref::map_split(borrow, |slice| slice.split_at(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// ```
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(orig: Ref<'b, T>, f: F) -> (Ref<'b, U>, Ref<'b, V>)
    where
        F: FnOnce(&T) -> (&U, &V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (Ref { value: a, borrow }, Ref { value: b, borrow: orig.borrow })
    }

    /// Omzetten in een verwijzing naar de onderliggende data.
    ///
    /// De onderliggende `RefCell` kan nooit meer veranderlijk geleend worden en zal altijd al onveranderlijk geleend lijken.
    ///
    /// Het is geen goed idee om meer dan een constant aantal referenties te lekken.
    /// De `RefCell` kan onveranderlijk weer worden geleend als er in totaal slechts een kleiner aantal lekken is opgetreden.
    ///
    /// Dit is een bijbehorende functie die moet worden gebruikt als `Ref::leak(...)`.
    /// Een methode zou de methoden met dezelfde naam op de inhoud van een `RefCell` die via `Deref` worden gebruikt, verstoren.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, Ref};
    /// let cell = RefCell::new(0);
    ///
    /// let value = Ref::leak(cell.borrow());
    /// assert_eq!(*value, 0);
    ///
    /// assert!(cell.try_borrow().is_ok());
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: Ref<'b, T>) -> &'b T {
        // Door deze Ref te vergeten, zorgen we ervoor dat de leenteller in de RefCell niet terug kan naar UNUSED binnen de levensduur `'b`.
        // Het resetten van de referentietrackingstatus zou een unieke verwijzing naar de geleende RefCell vereisen.
        // Er kunnen geen verdere veranderlijke verwijzingen worden gemaakt op basis van de originele cel.
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Ref<'b, U>> for Ref<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Ref<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

impl<'b, T: ?Sized> RefMut<'b, T> {
    /// Maakt een nieuwe `RefMut` voor een onderdeel van de geleende data, bijvoorbeeld een enumvariant.
    ///
    /// De `RefCell` is al uitwisselbaar geleend, dus dit kan niet falen.
    ///
    /// Dit is een bijbehorende functie die moet worden gebruikt als `RefMut::map(...)`.
    /// Een methode zou de methoden met dezelfde naam op de inhoud van een `RefCell` die via `Deref` worden gebruikt, verstoren.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// {
    ///     let b1: RefMut<(u32, char)> = c.borrow_mut();
    ///     let mut b2: RefMut<u32> = RefMut::map(b1, |t| &mut t.0);
    ///     assert_eq!(*b2, 5);
    ///     *b2 = 42;
    /// }
    /// assert_eq!(*c.borrow(), (42, 'b'));
    /// ```
    ///
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> RefMut<'b, U>
    where
        F: FnOnce(&mut T) -> &mut U,
    {
        // FIXME(nll-rfc#40): lenen-check repareren
        let RefMut { value, borrow } = orig;
        RefMut { value: f(value), borrow }
    }

    /// Maakt een nieuwe `RefMut` voor een optioneel onderdeel van de geleende data.
    /// De originele bewaker wordt geretourneerd als een `Err(..)` als de sluiting `None` retourneert.
    ///
    /// De `RefCell` is al uitwisselbaar geleend, dus dit kan niet falen.
    ///
    /// Dit is een bijbehorende functie die moet worden gebruikt als `RefMut::filter_map(...)`.
    /// Een methode zou de methoden met dezelfde naam op de inhoud van een `RefCell` die via `Deref` worden gebruikt, verstoren.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    ///
    /// {
    ///     let b1: RefMut<Vec<u32>> = c.borrow_mut();
    ///     let mut b2: Result<RefMut<u32>, _> = RefMut::filter_map(b1, |v| v.get_mut(1));
    ///
    ///     if let Ok(mut b2) = b2 {
    ///         *b2 += 2;
    ///     }
    /// }
    ///
    /// assert_eq!(*c.borrow(), vec![1, 4, 3]);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> Result<RefMut<'b, U>, Self>
    where
        F: FnOnce(&mut T) -> Option<&mut U>,
    {
        // FIXME(nll-rfc#40): lenen-check repareren
        let RefMut { value, borrow } = orig;
        let value = value as *mut T;
        // VEILIGHEID: functie behoudt een exclusieve referentie voor de duur
        // van zijn aanroep via `orig`, en de pointer wordt alleen verwijderd binnen de functieaanroep, waardoor de exclusieve verwijzing nooit kan ontsnappen.
        //
        //
        match f(unsafe { &mut *value }) {
            Some(value) => Ok(RefMut { value, borrow }),
            None => {
                // VEILIGHEID: hetzelfde als hierboven.
                Err(RefMut { value: unsafe { &mut *value }, borrow })
            }
        }
    }

    /// Splitst een `RefMut` in meerdere `RefMut`s voor verschillende componenten van de geleende data.
    ///
    /// De onderliggende `RefCell` zal veranderlijk geleend blijven totdat beide geretourneerde `RefMut`s buiten de scope vallen.
    ///
    /// De `RefCell` is al uitwisselbaar geleend, dus dit kan niet falen.
    ///
    /// Dit is een bijbehorende functie die moet worden gebruikt als `RefMut::map_split(...)`.
    /// Een methode zou de methoden met dezelfde naam op de inhoud van een `RefCell` die via `Deref` worden gebruikt, verstoren.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow_mut();
    /// let (mut begin, mut end) = RefMut::map_split(borrow, |slice| slice.split_at_mut(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// begin.copy_from_slice(&[4, 3]);
    /// end.copy_from_slice(&[2, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(
        orig: RefMut<'b, T>,
        f: F,
    ) -> (RefMut<'b, U>, RefMut<'b, V>)
    where
        F: FnOnce(&mut T) -> (&mut U, &mut V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (RefMut { value: a, borrow }, RefMut { value: b, borrow: orig.borrow })
    }

    /// Omzetten in een veranderlijke verwijzing naar de onderliggende gegevens.
    ///
    /// De onderliggende `RefCell` kan niet opnieuw worden geleend en zal altijd al mutabel geleend blijken te zijn, waardoor de teruggestuurde verwijzing de enige naar het interieur is.
    ///
    ///
    /// Dit is een bijbehorende functie die moet worden gebruikt als `RefMut::leak(...)`.
    /// Een methode zou de methoden met dezelfde naam op de inhoud van een `RefCell` die via `Deref` worden gebruikt, verstoren.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, RefMut};
    /// let cell = RefCell::new(0);
    ///
    /// let value = RefMut::leak(cell.borrow_mut());
    /// assert_eq!(*value, 0);
    /// *value = 1;
    ///
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: RefMut<'b, T>) -> &'b mut T {
        // Door deze BorrowRefMut te vergeten zorgen we ervoor dat de leenteller in de RefCell niet terug kan naar UNUSED binnen de levensduur `'b`.
        // Het resetten van de referentietrackingstatus zou een unieke verwijzing naar de geleende RefCell vereisen.
        // Er kunnen geen verdere verwijzingen worden gemaakt van de oorspronkelijke cel binnen die levensduur, waardoor de huidige lening de enige referentie is voor de resterende levensduur.
        //
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

struct BorrowRefMut<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl Drop for BorrowRefMut<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        self.borrow.set(borrow + 1);
    }
}

impl<'b> BorrowRefMut<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRefMut<'b>> {
        // NOTE: In tegenstelling tot BorrowRefMut::clone wordt nieuw aangeroepen om de initiaal te maken
        // veranderlijke referentie, en dus mogen er momenteel geen bestaande referenties zijn.
        // Dus hoewel kloon de veranderlijke refcount verhoogt, staan we hier expliciet alleen toe om van ONGEBRUIKT naar ONGEBRUIKT te gaan, 1.
        //
        match borrow.get() {
            UNUSED => {
                borrow.set(UNUSED - 1);
                Some(BorrowRefMut { borrow })
            }
            _ => None,
        }
    }

    // Klonen een `BorrowRefMut`.
    //
    // Dit is alleen geldig als elke `BorrowRefMut` wordt gebruikt om een veranderlijke verwijzing naar een duidelijk, niet-overlappend bereik van het oorspronkelijke object te volgen.
    //
    // Dit zit niet in een Clone-impl, dus de code roept dit niet impliciet aan.
    #[inline]
    fn clone(&self) -> BorrowRefMut<'b> {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        // Voorkom dat de uitleenbalie onderloopt.
        assert!(borrow != isize::MIN);
        self.borrow.set(borrow - 1);
        BorrowRefMut { borrow: self.borrow }
    }
}

/// Een wrapper-type voor een veranderlijk geleende waarde van een `RefCell<T>`.
///
/// Zie de [module-level documentation](self) voor meer.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefMut<'b, T: ?Sized + 'b> {
    value: &'b mut T,
    borrow: BorrowRefMut<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for RefMut<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for RefMut<'_, T> {
    #[inline]
    fn deref_mut(&mut self) -> &mut T {
        self.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<RefMut<'b, U>> for RefMut<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for RefMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

/// De kernprimitief voor innerlijke veranderlijkheid in Rust.
///
/// Als u een referentie `&T` heeft, voert de compiler normaal gesproken in Rust optimalisaties uit op basis van de wetenschap dat `&T` verwijst naar onveranderlijke gegevens.Het muteren van die gegevens, bijvoorbeeld via een alias of door een `&T` in een `&mut T` te transmuteren, wordt als ongedefinieerd gedrag beschouwd.
/// `UnsafeCell<T>` opt-out van de onveranderlijkheidsgarantie voor `&T`: een gedeelde referentie `&UnsafeCell<T>` kan verwijzen naar gegevens die worden gemuteerd.Dit heet "interior mutability".
///
/// Alle andere typen die interne veranderlijkheid mogelijk maken, zoals `Cell<T>` en `RefCell<T>`, gebruiken intern `UnsafeCell` om hun gegevens in te pakken.
///
/// Merk op dat alleen de onveranderlijkheidsgarantie voor gedeelde referenties wordt beïnvloed door `UnsafeCell`.De uniekheidsgarantie voor veranderlijke verwijzingen blijft onaangetast.Er is *geen* legale manier om aliasing `&mut` te verkrijgen, zelfs niet met `UnsafeCell<T>`.
///
/// De `UnsafeCell` API zelf is technisch heel eenvoudig: [`.get()`] geeft je een ruwe pointer `*mut T` naar de inhoud ervan.Het is aan _you_ als abstractie-ontwerper om die onbewerkte pointer correct te gebruiken.
///
/// [`.get()`]: `UnsafeCell::get`
///
/// De precieze Rust-aliasingregels zijn enigszins in beweging, maar de belangrijkste punten zijn niet omstreden:
///
/// - Als u een veilige referentie maakt met levensduur `'a` (ofwel een `&T`-of `&mut T`-referentie) die toegankelijk is via veilige code (bijvoorbeeld omdat u deze hebt geretourneerd), dan mag u de gegevens niet openen op een manier die in tegenspraak is met die referentie voor de rest van `'a`.
/// Dit betekent bijvoorbeeld dat als u de `*mut T` van een `UnsafeCell<T>` neemt en deze naar een `&T` cast, de gegevens in `T` onveranderlijk moeten blijven (uiteraard modulo alle `UnsafeCell`-gegevens die in `T` worden gevonden) totdat de levensduur van die referentie verloopt.
/// Evenzo, als u een `&mut T`-referentie maakt die wordt vrijgegeven voor veilige code, mag u geen toegang krijgen tot de gegevens in de `UnsafeCell` totdat die referentie verloopt.
///
/// - U moet te allen tijde dataraces vermijden.Als meerdere threads toegang hebben tot dezelfde `UnsafeCell`, dan moeten alle schrijfbewerkingen een juiste happen-before-relatie hebben met alle andere toegangen (of gebruik atomics).
///
/// Om te helpen bij het juiste ontwerp, worden de volgende scenario's expliciet legaal verklaard voor single-threaded code:
///
/// 1. Een `&T`-referentie kan worden vrijgegeven naar veilige code en daar kan deze naast andere `&T`-referenties bestaan, maar niet met een `&mut T`
///
/// 2. Een `&mut T`-referentie kan worden vrijgegeven naar veilige code, op voorwaarde dat er geen andere `&mut T` of `&T` naast bestaat.Een `&mut T` moet altijd uniek zijn.
///
/// Merk op dat terwijl het muteren van de inhoud van een `&UnsafeCell<T>` (zelfs terwijl andere `&UnsafeCell<T>` verwijst naar de alias van de cel) ok is (op voorwaarde dat je de bovenstaande invarianten op een andere manier afdwingt), het nog steeds ongedefinieerd gedrag is om meerdere `&mut UnsafeCell<T>` aliassen te hebben.
/// Dat wil zeggen, `UnsafeCell` is een wrapper die is ontworpen om een speciale interactie te hebben met _shared_ accesses (_i.e._, via een `&UnsafeCell<_>`-referentie);er is geen enkele magie bij het omgaan met _exclusive_ accesses (_e.g._, via een `&mut UnsafeCell<_>`): noch de cel noch de ingepakte waarde mag worden gealiast voor de duur van die `&mut`-lening.
///
/// Dit wordt getoond door de [`.get_mut()`]-accessor, een _safe_ getter die een `&mut T` oplevert.
///
/// [`.get_mut()`]: `UnsafeCell::get_mut`
///
/// # Examples
///
/// Hier is een voorbeeld dat laat zien hoe u de inhoud van een `UnsafeCell<_>` degelijk kunt muteren, ondanks dat er meerdere verwijzingen zijn die de cel alias geven:
///
/// ```
/// use std::cell::UnsafeCell;
///
/// let x: UnsafeCell<i32> = 42.into();
/// // Krijg meerdere/gedeelde verwijzingen naar dezelfde `x`.
/// let (p1, p2): (&UnsafeCell<i32>, &UnsafeCell<i32>) = (&x, &x);
///
/// unsafe {
///     // VEILIGHEID: binnen deze scope zijn er geen andere verwijzingen naar de inhoud van `x`,
///     // dus die van ons is in feite uniek.
///     let p1_exclusive: &mut i32 = &mut *p1.get(); // -- lenen-+
///     *p1_exclusive += 27; // |
/// } // <---------- kan niet verder gaan dan dit punt -------------------+
///
/// unsafe {
///     // VEILIGHEID: binnen dit bereik verwacht niemand exclusieve toegang te hebben tot de inhoud van `x`,
///     // zodat we meerdere gedeelde toegangen tegelijkertijd kunnen hebben.
///     let p2_shared: &i32 = &*p2.get();
///     assert_eq!(*p2_shared, 42 + 27);
///     let p1_shared: &i32 = &*p1.get();
///     assert_eq!(*p1_shared, *p2_shared);
/// }
/// ```
///
/// Het volgende voorbeeld laat zien dat exclusieve toegang tot een `UnsafeCell<T>` exclusieve toegang tot zijn `T` impliceert:
///
/// ```rust
/// #![forbid(unsafe_code)] // met exclusieve toegangen,
///                         // `UnsafeCell` is een transparante no-op-wrapper, dus `unsafe` is hier niet nodig.
/////
/// use std::cell::UnsafeCell;
///
/// let mut x: UnsafeCell<i32> = 42.into();
///
/// // Krijg een door compileren gecontroleerde unieke referentie naar `x`.
/// let p_unique: &mut UnsafeCell<i32> = &mut x;
/// // Met een exclusieve referentie kunnen we de inhoud gratis muteren.
/// *p_unique.get_mut() = 0;
/// // Of, equivalent:
/// x = UnsafeCell::new(0);
///
/// // Als we de waarde bezitten, kunnen we de inhoud gratis extraheren.
/// let contents: i32 = x.into_inner();
/// assert_eq!(contents, 0);
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "unsafe_cell"]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
#[repr(no_niche)] // rust-lang/rust#68303.
pub struct UnsafeCell<T: ?Sized> {
    value: T,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for UnsafeCell<T> {}

impl<T> UnsafeCell<T> {
    /// Construeert een nieuwe instantie van `UnsafeCell` die de opgegeven waarde omhult.
    ///
    ///
    /// Alle toegang tot de innerlijke waarde via methoden is `unsafe`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafe_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> UnsafeCell<T> {
        UnsafeCell { value }
    }

    /// Maakt de waarde los.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.into_inner();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value
    }
}

impl<T: ?Sized> UnsafeCell<T> {
    /// Krijgt een veranderlijke pointer naar de ingepakte waarde.
    ///
    /// Dit kan naar elke soort aanwijzer worden geworpen.
    /// Zorg ervoor dat de toegang uniek is (geen actieve referenties, veranderlijk of niet) bij het casten naar `&mut T`, en zorg ervoor dat er geen mutaties of veranderlijke aliassen plaatsvinden bij het casten naar `&T`
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.get();
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafecell_get", since = "1.32.0")]
    pub const fn get(&self) -> *mut T {
        // We kunnen de aanwijzer gewoon van `UnsafeCell<T>` naar `T` casten vanwege #[repr(transparent)].
        // Dit maakt gebruik van de speciale status van libstd, er is geen garantie voor gebruikerscode dat dit zal werken in future-versies van de compiler!
        //
        self as *const UnsafeCell<T> as *const T as *mut T
    }

    /// Retourneert een veranderlijke verwijzing naar de onderliggende gegevens.
    ///
    /// Deze aanroep leent de `UnsafeCell` veranderlijk (tijdens het compileren), wat garandeert dat we de enige referentie hebben.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let mut c = UnsafeCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(*c.get_mut(), 6);
    /// ```
    #[inline]
    #[stable(feature = "unsafe_cell_get_mut", since = "1.50.0")]
    pub fn get_mut(&mut self) -> &mut T {
        &mut self.value
    }

    /// Krijgt een veranderlijke pointer naar de ingepakte waarde.
    /// Het verschil met [`get`] is dat deze functie een onbewerkte pointer accepteert, wat handig is om te voorkomen dat er tijdelijke verwijzingen worden gemaakt.
    ///
    /// Het resultaat kan naar een aanwijzer van welke soort dan ook worden gegoten.
    /// Zorg ervoor dat de toegang uniek is (geen actieve referenties, veranderlijk of niet) bij het casten naar `&mut T`, en zorg ervoor dat er geen mutaties of veranderlijke aliassen plaatsvinden bij het casten naar `&T`.
    ///
    ///
    /// [`get`]: UnsafeCell::get()
    ///
    /// # Examples
    ///
    /// Voor geleidelijke initialisatie van een `UnsafeCell` is `raw_get` vereist, omdat voor het aanroepen van `get` een verwijzing naar niet-geïnitialiseerde gegevens moet worden gemaakt:
    ///
    /// ```
    /// #![feature(unsafe_cell_raw_get)]
    /// use std::cell::UnsafeCell;
    /// use std::mem::MaybeUninit;
    ///
    /// let m = MaybeUninit::<UnsafeCell<i32>>::uninit();
    /// unsafe { UnsafeCell::raw_get(m.as_ptr()).write(5); }
    /// let uc = unsafe { m.assume_init() };
    ///
    /// assert_eq!(uc.into_inner(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "unsafe_cell_raw_get", issue = "66358")]
    pub const fn raw_get(this: *const Self) -> *mut T {
        // We kunnen de aanwijzer gewoon van `UnsafeCell<T>` naar `T` casten vanwege #[repr(transparent)].
        // Dit maakt gebruik van de speciale status van libstd, er is geen garantie voor gebruikerscode dat dit zal werken in future-versies van de compiler!
        //
        this as *const T as *mut T
    }
}

#[stable(feature = "unsafe_cell_default", since = "1.10.0")]
impl<T: Default> Default for UnsafeCell<T> {
    /// Creëert een `UnsafeCell`, met de `Default`-waarde voor T.
    fn default() -> UnsafeCell<T> {
        UnsafeCell::new(Default::default())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for UnsafeCell<T> {
    fn from(t: T) -> UnsafeCell<T> {
        UnsafeCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<UnsafeCell<U>> for UnsafeCell<T> {}

#[allow(unused)]
fn assert_coerce_unsized(a: UnsafeCell<&i32>, b: Cell<&i32>, c: RefCell<&i32>) {
    let _: UnsafeCell<&dyn Send> = a;
    let _: Cell<&dyn Send> = b;
    let _: RefCell<&dyn Send> = c;
}