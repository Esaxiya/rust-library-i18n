//! Een module om met geleende data te werken.

#![stable(feature = "rust1", since = "1.0.0")]

/// Een trait voor het lenen van data.
///
/// In Rust is het gebruikelijk om verschillende weergaven van een type te bieden voor verschillende gebruiksscenario's.
/// Opslaglocatie en beheer voor een waarde kunnen bijvoorbeeld specifiek worden gekozen als geschikt voor een bepaald gebruik via aanwijzertypen zoals [`Box<T>`] of [`Rc<T>`].
/// Naast deze generieke wrappers die met elk type kunnen worden gebruikt, bieden sommige typen optionele facetten die mogelijk dure functionaliteit bieden.
/// Een voorbeeld van een dergelijk type is [`String`] dat de mogelijkheid toevoegt om een string uit te breiden naar de standaard [`str`].
/// Dit vereist het overbodig houden van aanvullende informatie voor een eenvoudige, onveranderlijke string.
///
/// Deze typen geven toegang tot de onderliggende gegevens door middel van verwijzingen naar het type van die gegevens.Er wordt gezegd dat ze 'geleend zijn als' dat type.
/// Een [`Box<T>`] kan bijvoorbeeld worden geleend als `T`, terwijl een [`String`] kan worden geleend als `str`.
///
/// Typen geven aan dat ze kunnen worden geleend als een type `T` door `Borrow<T>` te implementeren, waarbij een verwijzing wordt gegeven naar een `T` in de [`borrow`]-methode van trait.Een type is gratis te lenen als verschillende soorten.
/// Als het veranderlijk wil lenen als het type-waardoor de onderliggende gegevens kunnen worden gewijzigd, kan het aanvullend [`BorrowMut<T>`] implementeren.
///
/// Verder moet bij het leveren van implementaties voor aanvullende traits worden overwogen of ze zich identiek moeten gedragen als die van het onderliggende type als gevolg van het optreden als een representatie van dat onderliggende type.
/// Generieke code gebruikt meestal `Borrow<T>` wanneer het vertrouwt op het identieke gedrag van deze aanvullende trait-implementaties.
/// Deze traits zullen waarschijnlijk verschijnen als extra trait bounds.
///
/// In het bijzonder moeten `Eq`, `Ord` en `Hash` equivalent zijn voor geleende en in bezit zijnde waarden: `x.borrow() == y.borrow()` zou hetzelfde resultaat moeten geven als `x == y`.
///
/// Als generieke code alleen hoeft te werken voor alle typen die een verwijzing naar gerelateerd type `T` kunnen bieden, is het vaak beter om [`AsRef<T>`] te gebruiken, omdat meer typen deze veilig kunnen implementeren.
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
/// [`Mutex<T>`]: ../../std/sync/struct.Mutex.html
/// [`Rc<T>`]: ../../std/rc/struct.Rc.html
/// [`String`]: ../../std/string/struct.String.html
/// [`borrow`]: Borrow::borrow
///
/// # Examples
///
/// Als gegevensverzameling bezit [`HashMap<K, V>`] zowel sleutels als waarden.Als de feitelijke gegevens van de sleutel zijn verpakt in een soort beheerstype, zou het echter nog steeds mogelijk moeten zijn om naar een waarde te zoeken met behulp van een verwijzing naar de gegevens van de sleutel.
/// Als de sleutel bijvoorbeeld een string is, wordt deze waarschijnlijk opgeslagen met de hash-map als een [`String`], terwijl het mogelijk zou moeten zijn om te zoeken met een [`&str`][`str`].
/// `insert` moet dus op een `String` werken, terwijl `get` een `&str` moet kunnen gebruiken.
///
/// Iets vereenvoudigd zien de relevante onderdelen van `HashMap<K, V>` er als volgt uit:
///
/// ```
/// use std::borrow::Borrow;
/// use std::hash::Hash;
///
/// pub struct HashMap<K, V> {
///     # marker: ::std::marker::PhantomData<(K, V)>,
///     // velden weggelaten
/// }
///
/// impl<K, V> HashMap<K, V> {
///     pub fn insert(&self, key: K, value: V) -> Option<V>
///     where K: Hash + Eq
///     {
///         # unimplemented!()
///         // ...
///     }
///
///     pub fn get<Q>(&self, k: &Q) -> Option<&V>
///     where
///         K: Borrow<Q>,
///         Q: Hash + Eq + ?Sized
///     {
///         # unimplemented!()
///         // ...
///     }
/// }
/// ```
///
/// De volledige hash-map is generiek over een sleuteltype `K`.Omdat deze sleutels worden opgeslagen met de hash-map, moet dit type de gegevens van de sleutel bezitten.
/// Bij het invoegen van een sleutel/waarde-paar krijgt de kaart zo'n `K` en moet hij de juiste hash-bucket vinden en controleren of de sleutel al aanwezig is op basis van die `K`.Het vereist daarom `K: Hash + Eq`.
///
/// Wanneer u echter naar een waarde op de kaart zoekt, moet u altijd een dergelijke waarde in eigendom creëren als u een verwijzing naar een `K` moet opgeven als de sleutel om naar te zoeken.
/// Voor string-sleutels zou dit betekenen dat een `String`-waarde moet worden gemaakt alleen voor het zoeken naar gevallen waarin alleen een `str` beschikbaar is.
///
/// In plaats daarvan is de `get`-methode generiek ten opzichte van het type onderliggende sleuteldata, genaamd `Q` in de bovenstaande methodehandtekening.Het stelt dat `K` leent als een `Q` door die `K: Borrow<Q>` te vereisen.
/// Door bovendien `Q: Hash + Eq` te vereisen, geeft het de vereiste aan dat `K` en `Q` implementaties van de `Hash` en `Eq` traits hebben die identieke resultaten opleveren.
///
/// De implementatie van `get` is in het bijzonder afhankelijk van identieke implementaties van `Hash` door de hash-bucket van de sleutel te bepalen door `Hash::hash` aan te roepen op de `Q`-waarde, ook al heeft het de sleutel ingevoegd op basis van de hash-waarde die is berekend op basis van de `K`-waarde.
///
///
/// Als gevolg hiervan breekt de hash-map als een `K` die een `Q`-waarde omhult, een andere hash produceert dan `Q`.Stel je bijvoorbeeld voor dat je een type hebt dat een string omhult, maar ASCII-letters vergelijkt en hun hoofdletter negeert:
///
/// ```
/// pub struct CaseInsensitiveString(String);
///
/// impl PartialEq for CaseInsensitiveString {
///     fn eq(&self, other: &Self) -> bool {
///         self.0.eq_ignore_ascii_case(&other.0)
///     }
/// }
///
/// impl Eq for CaseInsensitiveString { }
/// ```
///
/// Omdat twee gelijke waarden dezelfde hash-waarde moeten produceren, moet de implementatie van `Hash` ook ASCII-hoofdletters negeren:
///
/// ```
/// # use std::hash::{Hash, Hasher};
/// # pub struct CaseInsensitiveString(String);
/// impl Hash for CaseInsensitiveString {
///     fn hash<H: Hasher>(&self, state: &mut H) {
///         for c in self.0.as_bytes() {
///             c.to_ascii_lowercase().hash(state)
///         }
///     }
/// }
/// ```
///
/// Kan `CaseInsensitiveString` `Borrow<str>` implementeren?Het kan zeker een verwijzing naar een stringplak geven via de bijbehorende string die eigendom is.
/// Maar omdat de `Hash`-implementatie verschilt, gedraagt het zich anders dan `str` en moet het daarom in feite `Borrow<str>` niet implementeren.
/// Als het anderen toegang wil geven tot de onderliggende `str`, kan het dat doen via `AsRef<str>` die geen extra vereisten met zich meebrengt.
///
/// [`Hash`]: crate::hash::Hash
/// [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
/// [`String`]: ../../std/string/struct.String.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Borrow"]
pub trait Borrow<Borrowed: ?Sized> {
    /// Leent onveranderlijk van een eigendomswaarde.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::borrow::Borrow;
    ///
    /// fn check<T: Borrow<str>>(s: T) {
    ///     assert_eq!("Hello", s.borrow());
    /// }
    ///
    /// let s = "Hello".to_string();
    ///
    /// check(s);
    ///
    /// let s = "Hello";
    ///
    /// check(s);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn borrow(&self) -> &Borrowed;
}

/// Een trait voor het onderling lenen van data.
///
/// Als aanvulling op [`Borrow<T>`] staat deze trait een type toe om te lenen als een onderliggend type door een veranderlijke referentie te verstrekken.
/// Zie [`Borrow<T>`] voor meer informatie over lenen als een ander type.
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait BorrowMut<Borrowed: ?Sized>: Borrow<Borrowed> {
    /// Leent veranderlijk van een eigendomswaarde.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::borrow::BorrowMut;
    ///
    /// fn check<T: BorrowMut<[i32]>>(mut v: T) {
    ///     assert_eq!(&mut [1, 2, 3], v.borrow_mut());
    /// }
    ///
    /// let v = vec![1, 2, 3];
    ///
    /// check(v);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn borrow_mut(&mut self) -> &mut Borrowed;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for T {
    #[rustc_diagnostic_item = "noop_method_borrow"]
    fn borrow(&self) -> &T {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> BorrowMut<T> for T {
    fn borrow_mut(&mut self) -> &mut T {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for &T {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for &mut T {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> BorrowMut<T> for &mut T {
    fn borrow_mut(&mut self) -> &mut T {
        &mut **self
    }
}