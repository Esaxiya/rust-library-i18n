//! impl char {}

use crate::intrinsics::likely;
use crate::slice;
use crate::str::from_utf8_unchecked_mut;
use crate::unicode::printable::is_printable;
use crate::unicode::{self, conversions};

use super::*;

#[lang = "char"]
impl char {
    /// Het hoogste geldige codepunt dat een `char` kan hebben.
    ///
    /// Een `char` is een [Unicode Scalar Value], wat betekent dat het een [Code Point] is, maar alleen binnen een bepaald bereik.
    /// `MAX` is het hoogste geldige codepunt dat een geldige [Unicode Scalar Value] is.
    ///
    /// [Unicode Scalar Value]: http://www.unicode.org/glossary/#unicode_scalar_value
    /// [Code Point]: http://www.unicode.org/glossary/#code_point
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const MAX: char = '\u{10ffff}';

    /// `U+FFFD REPLACEMENT CHARACTER` () wordt in Unicode gebruikt om een decoderingsfout weer te geven.
    ///
    /// Het kan bijvoorbeeld voorkomen bij het geven van slecht gevormde UTF-8-bytes aan [`String::from_utf8_lossy`](string/struct.String.html#method.from_utf8_lossy).
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const REPLACEMENT_CHARACTER: char = '\u{FFFD}';

    /// De versie van [Unicode](http://www.unicode.org/) waarop de Unicode-onderdelen van `char`-en `str`-methoden zijn gebaseerd.
    ///
    /// Er worden regelmatig nieuwe versies van Unicode uitgebracht en vervolgens worden alle methoden in de standaardbibliotheek die afhankelijk zijn van Unicode, bijgewerkt.
    /// Daarom verandert het gedrag van sommige `char`-en `str`-methoden en de waarde van deze constante in de loop van de tijd.
    /// Dit wordt *niet* beschouwd als een ingrijpende verandering.
    ///
    /// Het versienummeringsschema wordt uitgelegd in [Unicode 11.0 or later, Section 3.1 Versions of the Unicode Standard](https://www.unicode.org/versions/Unicode11.0.0/ch03.pdf#page=4).
    ///
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const UNICODE_VERSION: (u8, u8, u8) = crate::unicode::UNICODE_VERSION;

    /// Creëert een iterator over de UTF-16 gecodeerde codepunten in `iter`, waarbij ongepaarde surrogaten worden geretourneerd als `Err`s.
    ///
    ///
    /// # Examples
    ///
    /// Basisgebruik:
    ///
    /// ```
    /// use std::char::decode_utf16;
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///         .map(|r| r.map_err(|e| e.unpaired_surrogate()))
    ///         .collect::<Vec<_>>(),
    ///     vec![
    ///         Ok('𝄞'),
    ///         Ok('m'), Ok('u'), Ok('s'),
    ///         Err(0xDD1E),
    ///         Ok('i'), Ok('c'),
    ///         Err(0xD834)
    ///     ]
    /// );
    /// ```
    ///
    /// Een lossy decoder kan worden verkregen door `Err`-resultaten te vervangen door het vervangende teken:
    ///
    /// ```
    /// use std::char::{decode_utf16, REPLACEMENT_CHARACTER};
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///        .map(|r| r.unwrap_or(REPLACEMENT_CHARACTER))
    ///        .collect::<String>(),
    ///     "𝄞mus�ic�"
    /// );
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn decode_utf16<I: IntoIterator<Item = u16>>(iter: I) -> DecodeUtf16<I::IntoIter> {
        super::decode::decode_utf16(iter)
    }

    /// Converteert een `u32` naar een `char`.
    ///
    /// Merk op dat alle `char`s geldige [`u32`] s zijn, en kunnen gecast worden met
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// Het omgekeerde is echter niet waar: niet alle geldige [`u32`] s zijn geldige` tekens.
    /// `from_u32()` zal `None` retourneren als de invoer geen geldige waarde is voor een `char`.
    ///
    /// Zie [`from_u32_unchecked`] voor een onveilige versie van deze functie die deze controles negeert.
    ///
    ///
    /// [`from_u32_unchecked`]: #method.from_u32_unchecked
    ///
    /// # Examples
    ///
    /// Basisgebruik:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x2764);
    ///
    /// assert_eq!(Some('❤'), c);
    /// ```
    ///
    /// `None` retourneren wanneer de invoer geen geldige `char` is:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x110000);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_u32(i: u32) -> Option<char> {
        super::convert::from_u32(i)
    }

    /// Converteert een `u32` naar een `char`, waarbij de geldigheid wordt genegeerd.
    ///
    /// Merk op dat alle `char`s geldige [`u32`] s zijn, en kunnen gecast worden met
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// Het omgekeerde is echter niet waar: niet alle geldige [`u32`] s zijn geldige` tekens.
    /// `from_u32_unchecked()` zal dit negeren en blindelings casten naar `char`, waardoor mogelijk een ongeldige wordt aangemaakt.
    ///
    ///
    /// # Safety
    ///
    /// Deze functie is onveilig, omdat het ongeldige `char`-waarden kan construeren.
    ///
    /// Zie de [`from_u32`]-functie voor een veilige versie van deze functie.
    ///
    /// [`from_u32`]: #method.from_u32
    ///
    /// # Examples
    ///
    /// Basisgebruik:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = unsafe { char::from_u32_unchecked(0x2764) };
    ///
    /// assert_eq!('❤', c);
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub unsafe fn from_u32_unchecked(i: u32) -> char {
        // VEILIGHEID: het veiligheidscontract moet worden nageleefd door de beller.
        unsafe { super::convert::from_u32_unchecked(i) }
    }

    /// Converteert een cijfer in de opgegeven radix naar een `char`.
    ///
    /// Een 'radix' wordt hier soms ook wel een 'base' genoemd.
    /// Een radix van twee geeft een binair getal aan, een radix van tien, decimaal en een radix van zestien, hexadecimaal, om enkele gemeenschappelijke waarden te geven.
    ///
    /// Willekeurige radices worden ondersteund.
    ///
    /// `from_digit()` zal `None` teruggeven als de invoer geen cijfer in de opgegeven radix is.
    ///
    /// # Panics
    ///
    /// Panics indien gegeven een radix groter dan 36.
    ///
    /// # Examples
    ///
    /// Basisgebruik:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(4, 10);
    ///
    /// assert_eq!(Some('4'), c);
    ///
    /// // Decimaal 11 is een enkel cijfer in basis 16
    /// let c = char::from_digit(11, 16);
    ///
    /// assert_eq!(Some('b'), c);
    /// ```
    ///
    /// `None` retourneren als de invoer geen cijfer is:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(20, 10);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    /// Een grote radix passeren, waardoor een panic ontstaat:
    ///
    /// ```should_panic
    /// use std::char;
    ///
    /// // this panics
    /// char::from_digit(1, 37);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_digit(num: u32, radix: u32) -> Option<char> {
        super::convert::from_digit(num, radix)
    }

    /// Controleert of een `char` een cijfer is in de opgegeven radix.
    ///
    /// Een 'radix' wordt hier soms ook wel een 'base' genoemd.
    /// Een radix van twee geeft een binair getal aan, een radix van tien, decimaal en een radix van zestien, hexadecimaal, om enkele gemeenschappelijke waarden te geven.
    ///
    /// Willekeurige radices worden ondersteund.
    ///
    /// In vergelijking met [`is_numeric()`] herkent deze functie alleen de tekens `0-9`, `a-z` en `A-Z`.
    ///
    /// 'Digit' wordt gedefinieerd als alleen de volgende tekens:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// Zie [`is_numeric()`] voor een uitgebreider begrip van 'digit'.
    ///
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Panics
    ///
    /// Panics indien gegeven een radix groter dan 36.
    ///
    /// # Examples
    ///
    /// Basisgebruik:
    ///
    /// ```
    /// assert!('1'.is_digit(10));
    /// assert!('f'.is_digit(16));
    /// assert!(!'f'.is_digit(10));
    /// ```
    ///
    /// Een grote radix passeren, waardoor een panic ontstaat:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.is_digit(37);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_digit(self, radix: u32) -> bool {
        self.to_digit(radix).is_some()
    }

    /// Converteert een `char` naar een cijfer in de opgegeven radix.
    ///
    /// Een 'radix' wordt hier soms ook wel een 'base' genoemd.
    /// Een radix van twee geeft een binair getal aan, een radix van tien, decimaal en een radix van zestien, hexadecimaal, om enkele gemeenschappelijke waarden te geven.
    ///
    /// Willekeurige radices worden ondersteund.
    ///
    /// 'Digit' wordt gedefinieerd als alleen de volgende tekens:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// # Errors
    ///
    /// Geeft `None` terug als de `char` niet verwijst naar een cijfer in de opgegeven radix.
    ///
    /// # Panics
    ///
    /// Panics indien gegeven een radix groter dan 36.
    ///
    /// # Examples
    ///
    /// Basisgebruik:
    ///
    /// ```
    /// assert_eq!('1'.to_digit(10), Some(1));
    /// assert_eq!('f'.to_digit(16), Some(15));
    /// ```
    ///
    /// Het doorgeven van een niet-cijfer resulteert in een mislukking:
    ///
    /// ```
    /// assert_eq!('f'.to_digit(10), None);
    /// assert_eq!('z'.to_digit(16), None);
    /// ```
    ///
    /// Een grote radix passeren, waardoor een panic ontstaat:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.to_digit(37);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_digit(self, radix: u32) -> Option<u32> {
        assert!(radix <= 36, "to_digit: radix is too high (maximum 36)");
        // de code is hier opgesplitst om de uitvoeringssnelheid te verbeteren voor gevallen waarin de `radix` constant is en 10 of kleiner
        //
        let val = if likely(radix <= 10) {
            // Als er geen cijfer is, wordt een getal groter dan een radix gemaakt.
            (self as u32).wrapping_sub('0' as u32)
        } else {
            match self {
                '0'..='9' => self as u32 - '0' as u32,
                'a'..='z' => self as u32 - 'a' as u32 + 10,
                'A'..='Z' => self as u32 - 'A' as u32 + 10,
                _ => return None,
            }
        };

        if val < radix { Some(val) } else { None }
    }

    /// Geeft een iterator terug die de hexadecimale Unicode-escape van een teken oplevert als `char`s.
    ///
    /// Dit zal tekens met de Rust-syntaxis van de vorm `\u{NNNNNN}` laten ontsnappen, waarbij `NNNNNN` een hexadecimale weergave is.
    ///
    ///
    /// # Examples
    ///
    /// Als iterator:
    ///
    /// ```
    /// for c in '❤'.escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// `println!` rechtstreeks gebruiken:
    ///
    /// ```
    /// println!("{}", '❤'.escape_unicode());
    /// ```
    ///
    /// Beide zijn gelijk aan:
    ///
    /// ```
    /// println!("\\u{{2764}}");
    /// ```
    ///
    /// `to_string` gebruiken:
    ///
    /// ```
    /// assert_eq!('❤'.escape_unicode().to_string(), "\\u{2764}");
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_unicode(self) -> EscapeUnicode {
        let c = self as u32;

        // or-ing 1 zorgt ervoor dat voor c==0 de code berekent dat één cijfer moet worden afgedrukt en (wat hetzelfde is) de (31, 32) underflow vermijdt
        //
        //
        let msb = 31 - (c | 1).leading_zeros();

        // de index van het meest significante hexadecimale cijfer
        let ms_hex_digit = msb / 4;
        EscapeUnicode {
            c: self,
            state: EscapeUnicodeState::Backslash,
            hex_digit_idx: ms_hex_digit as usize,
        }
    }

    /// Een uitgebreide versie van `escape_debug` die optioneel het ontsnappen van Extended Grapheme-codepunten mogelijk maakt.
    /// Hierdoor kunnen we tekens zoals niet-spatiëringmarkeringen beter opmaken wanneer ze aan het begin van een string staan.
    ///
    #[inline]
    pub(crate) fn escape_debug_ext(self, escape_grapheme_extended: bool) -> EscapeDebug {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            _ if escape_grapheme_extended && self.is_grapheme_extended() => {
                EscapeDefaultState::Unicode(self.escape_unicode())
            }
            _ if is_printable(self) => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDebug(EscapeDefault { state: init_state })
    }

    /// Retourneert een iterator die de letterlijke escape-code van een teken oplevert als `char`s.
    ///
    /// Dit zal de karakters ontsnappen die vergelijkbaar zijn met de `Debug`-implementaties van `str` of `char`.
    ///
    ///
    /// # Examples
    ///
    /// Als iterator:
    ///
    /// ```
    /// for c in '\n'.escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// `println!` rechtstreeks gebruiken:
    ///
    /// ```
    /// println!("{}", '\n'.escape_debug());
    /// ```
    ///
    /// Beide zijn gelijk aan:
    ///
    /// ```
    /// println!("\\n");
    /// ```
    ///
    /// `to_string` gebruiken:
    ///
    /// ```
    /// assert_eq!('\n'.escape_debug().to_string(), "\\n");
    /// ```
    ///
    #[stable(feature = "char_escape_debug", since = "1.20.0")]
    #[inline]
    pub fn escape_debug(self) -> EscapeDebug {
        self.escape_debug_ext(true)
    }

    /// Retourneert een iterator die de letterlijke escape-code van een teken oplevert als `char`s.
    ///
    /// De standaardinstelling is gekozen met een voorkeur voor het produceren van letterlijke teksten die legaal zijn in verschillende talen, waaronder C++ 11 en vergelijkbare talen uit de C-familie.
    /// De exacte regels zijn:
    ///
    /// * Tab is ontsnapt als `\t`.
    /// * Carriage return is ontsnapt als `\r`.
    /// * De lijntoevoer is ontsnapt als `\n`.
    /// * Enkele aanhalingstekens worden ontsnapt als `\'`.
    /// * Dubbel aanhalingsteken is ontsnapt als `\"`.
    /// * Backslash is ontsnapt als `\\`.
    /// * Elk teken in het 'afdrukbare ASCII'-bereik `0x20` .. `0x7e` inclusief is niet ontsnapt.
    /// * Alle andere tekens krijgen hexadecimale Unicode-escapes;zie [`escape_unicode`].
    ///
    /// [`escape_unicode`]: #method.escape_unicode
    ///
    /// # Examples
    ///
    /// Als iterator:
    ///
    /// ```
    /// for c in '"'.escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// `println!` rechtstreeks gebruiken:
    ///
    /// ```
    /// println!("{}", '"'.escape_default());
    /// ```
    ///
    /// Beide zijn gelijk aan:
    ///
    /// ```
    /// println!("\\\"");
    /// ```
    ///
    /// `to_string` gebruiken:
    ///
    /// ```
    /// assert_eq!('"'.escape_default().to_string(), "\\\"");
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_default(self) -> EscapeDefault {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            '\x20'..='\x7e' => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDefault { state: init_state }
    }

    /// Retourneert het aantal bytes dat deze `char` nodig zou hebben indien gecodeerd in UTF-8.
    ///
    /// Dat aantal bytes ligt altijd tussen 1 en 4, inclusief.
    ///
    /// # Examples
    ///
    /// Basisgebruik:
    ///
    /// ```
    /// let len = 'A'.len_utf8();
    /// assert_eq!(len, 1);
    ///
    /// let len = 'ß'.len_utf8();
    /// assert_eq!(len, 2);
    ///
    /// let len = 'ℝ'.len_utf8();
    /// assert_eq!(len, 3);
    ///
    /// let len = '💣'.len_utf8();
    /// assert_eq!(len, 4);
    /// ```
    ///
    /// Het `&str`-type garandeert dat de inhoud UTF-8 is, en dus kunnen we de lengte vergelijken die nodig zou zijn als elk codepunt zou worden weergegeven als een `char` versus in de `&str` zelf:
    ///
    ///
    /// ```
    /// // als tekens
    /// let eastern = '東';
    /// let capital = '京';
    ///
    /// // beide kunnen worden weergegeven als drie bytes
    /// assert_eq!(3, eastern.len_utf8());
    /// assert_eq!(3, capital.len_utf8());
    ///
    /// // als &str zijn deze twee gecodeerd in UTF-8
    /// let tokyo = "東京";
    ///
    /// let len = eastern.len_utf8() + capital.len_utf8();
    ///
    /// // we kunnen zien dat ze in totaal zes bytes in beslag nemen ...
    /// assert_eq!(6, tokyo.len());
    ///
    /// // ... net als de &str
    /// assert_eq!(len, tokyo.len());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf8(self) -> usize {
        len_utf8(self as u32)
    }

    /// Geeft het aantal 16-bits code-eenheden terug dat deze `char` nodig zou hebben indien gecodeerd in UTF-16.
    ///
    ///
    /// Zie de documentatie voor [`len_utf8()`] voor meer uitleg van dit concept.
    /// Deze functie is een spiegel, maar dan voor UTF-16 in plaats van UTF-8.
    ///
    /// [`len_utf8()`]: #method.len_utf8
    ///
    /// # Examples
    ///
    /// Basisgebruik:
    ///
    /// ```
    /// let n = 'ß'.len_utf16();
    /// assert_eq!(n, 1);
    ///
    /// let len = '💣'.len_utf16();
    /// assert_eq!(len, 2);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf16(self) -> usize {
        let ch = self as u32;
        if (ch & 0xFFFF) == ch { 1 } else { 2 }
    }

    /// Codeert dit teken als UTF-8 in de opgegeven bytebuffer en retourneert vervolgens het subgedeelte van de buffer dat het gecodeerde teken bevat.
    ///
    ///
    /// # Panics
    ///
    /// Panics als de buffer niet groot genoeg is.
    /// Een buffer met een lengte van vier is groot genoeg om elke `char` te coderen.
    ///
    /// # Examples
    ///
    /// In beide voorbeelden heeft 'ß' twee bytes nodig om te coderen.
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = 'ß'.encode_utf8(&mut b);
    ///
    /// assert_eq!(result, "ß");
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// Een buffer die te klein is:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// 'ß'.encode_utf8(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf8(self, dst: &mut [u8]) -> &mut str {
        // VEILIGHEID: `char` is geen surrogaat, dus dit is geldige UTF-8.
        unsafe { from_utf8_unchecked_mut(encode_utf8_raw(self as u32, dst)) }
    }

    /// Codeert dit teken als UTF-16 in de meegeleverde `u16`-buffer en retourneert vervolgens het subgedeelte van de buffer dat het gecodeerde teken bevat.
    ///
    ///
    /// # Panics
    ///
    /// Panics als de buffer niet groot genoeg is.
    /// Een buffer met een lengte van 2 is groot genoeg om elke `char` te coderen.
    ///
    /// # Examples
    ///
    /// In beide voorbeelden heeft '𝕊' twee `u16`s nodig om te coderen.
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = '𝕊'.encode_utf16(&mut b);
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// Een buffer die te klein is:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// '𝕊'.encode_utf16(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf16(self, dst: &mut [u16]) -> &mut [u16] {
        encode_utf16_raw(self as u32, dst)
    }

    /// Geeft `true` terug als deze `char` de eigenschap `Alphabetic` heeft.
    ///
    /// `Alphabetic` wordt beschreven in Hoofdstuk 4 (Karaktereigenschappen) van de [Unicode Standard] en gespecificeerd in de [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Basisgebruik:
    ///
    /// ```
    /// assert!('a'.is_alphabetic());
    /// assert!('京'.is_alphabetic());
    ///
    /// let c = '💝';
    /// // liefde is veel, maar het is niet alfabetisch
    /// assert!(!c.is_alphabetic());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphabetic(self) -> bool {
        match self {
            'a'..='z' | 'A'..='Z' => true,
            c => c > '\x7f' && unicode::Alphabetic(c),
        }
    }

    /// Geeft `true` terug als deze `char` de eigenschap `Lowercase` heeft.
    ///
    /// `Lowercase` wordt beschreven in Hoofdstuk 4 (Karaktereigenschappen) van de [Unicode Standard] en gespecificeerd in de [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Basisgebruik:
    ///
    /// ```
    /// assert!('a'.is_lowercase());
    /// assert!('δ'.is_lowercase());
    /// assert!(!'A'.is_lowercase());
    /// assert!(!'Δ'.is_lowercase());
    ///
    /// // De verschillende Chinese scripts en interpunctie hebben geen hoofdletter, en dus:
    /// assert!(!'中'.is_lowercase());
    /// assert!(!' '.is_lowercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_lowercase(self) -> bool {
        match self {
            'a'..='z' => true,
            c => c > '\x7f' && unicode::Lowercase(c),
        }
    }

    /// Geeft `true` terug als deze `char` de eigenschap `Uppercase` heeft.
    ///
    /// `Uppercase` wordt beschreven in Hoofdstuk 4 (Karaktereigenschappen) van de [Unicode Standard] en gespecificeerd in de [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Basisgebruik:
    ///
    /// ```
    /// assert!(!'a'.is_uppercase());
    /// assert!(!'δ'.is_uppercase());
    /// assert!('A'.is_uppercase());
    /// assert!('Δ'.is_uppercase());
    ///
    /// // De verschillende Chinese scripts en interpunctie hebben geen hoofdletter, en dus:
    /// assert!(!'中'.is_uppercase());
    /// assert!(!' '.is_uppercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_uppercase(self) -> bool {
        match self {
            'A'..='Z' => true,
            c => c > '\x7f' && unicode::Uppercase(c),
        }
    }

    /// Geeft `true` terug als deze `char` de eigenschap `White_Space` heeft.
    ///
    /// `White_Space` wordt gespecificeerd in de [Unicode Character Database][ucd] [`PropList.txt`].
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`PropList.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/PropList.txt
    ///
    /// # Examples
    ///
    /// Basisgebruik:
    ///
    /// ```
    /// assert!(' '.is_whitespace());
    ///
    /// // een niet-afbrekende ruimte
    /// assert!('\u{A0}'.is_whitespace());
    ///
    /// assert!(!'越'.is_whitespace());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_whitespace(self) -> bool {
        match self {
            ' ' | '\x09'..='\x0d' => true,
            c => c > '\x7f' && unicode::White_Space(c),
        }
    }

    /// Retourneert `true` als deze `char` voldoet aan [`is_alphabetic()`] of [`is_numeric()`].
    ///
    /// [`is_alphabetic()`]: #method.is_alphabetic
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Examples
    ///
    /// Basisgebruik:
    ///
    /// ```
    /// assert!('٣'.is_alphanumeric());
    /// assert!('7'.is_alphanumeric());
    /// assert!('৬'.is_alphanumeric());
    /// assert!('¾'.is_alphanumeric());
    /// assert!('①'.is_alphanumeric());
    /// assert!('K'.is_alphanumeric());
    /// assert!('و'.is_alphanumeric());
    /// assert!('藏'.is_alphanumeric());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphanumeric(self) -> bool {
        self.is_alphabetic() || self.is_numeric()
    }

    /// Geeft `true` terug als deze `char` de algemene categorie voor besturingscodes heeft.
    ///
    /// Besturingscodes (codepunten met de algemene categorie `Cc`) worden beschreven in Hoofdstuk 4 (Karaktereigenschappen) van de [Unicode Standard] en gespecificeerd in de [Unicode Character Database][ucd] [`UnicodeData.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// Basisgebruik:
    ///
    /// ```
    /// // U + 009C, STRING TERMINATOR
    /// assert!(''.is_control());
    /// assert!(!'q'.is_control());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_control(self) -> bool {
        unicode::Cc(self)
    }

    /// Geeft `true` terug als deze `char` de eigenschap `Grapheme_Extend` heeft.
    ///
    /// `Grapheme_Extend` wordt beschreven in [Unicode Standard Annex #29 (Unicode Text Segmentation)][uax29] en gespecificeerd in [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [uax29]: https://www.unicode.org/reports/tr29/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    #[inline]
    pub(crate) fn is_grapheme_extended(self) -> bool {
        unicode::Grapheme_Extend(self)
    }

    /// Geeft `true` terug als deze `char` een van de algemene categorieën voor getallen heeft.
    ///
    /// De algemene categorieën voor getallen (`Nd` voor decimale cijfers, `Nl` voor letterachtige numerieke tekens en `No` voor andere numerieke tekens) worden gespecificeerd in de [Unicode Character Database][ucd] [`UnicodeData.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// Basisgebruik:
    ///
    /// ```
    /// assert!('٣'.is_numeric());
    /// assert!('7'.is_numeric());
    /// assert!('৬'.is_numeric());
    /// assert!('¾'.is_numeric());
    /// assert!('①'.is_numeric());
    /// assert!(!'K'.is_numeric());
    /// assert!(!'و'.is_numeric());
    /// assert!(!'藏'.is_numeric());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_numeric(self) -> bool {
        match self {
            '0'..='9' => true,
            c => c > '\x7f' && unicode::N(c),
        }
    }

    /// Geeft een iterator terug die de toewijzing in kleine letters van deze `char` als een of meer oplevert
    /// `char`s.
    ///
    /// Als deze `char` geen toewijzing in kleine letters heeft, levert de iterator dezelfde `char` op.
    ///
    /// Als deze `char` een één-op-één toewijzing in kleine letters heeft die wordt gegeven door de [Unicode Character Database][ucd] [`UnicodeData.txt`], levert de iterator die `char` op.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// Als deze `char` speciale overwegingen vereist (bijv. Meerdere `char`s), levert de iterator de`char` (s) op die door [`SpecialCasing.txt`] worden gegeven.
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// Deze bewerking voert een onvoorwaardelijke mapping uit zonder maatwerk.Dat wil zeggen, de conversie is onafhankelijk van context en taal.
    ///
    /// In de [Unicode Standard] bespreekt Hoofdstuk 4 (Karaktereigenschappen) case mapping in het algemeen en Hoofdstuk 3 (Conformance) bespreekt het standaard algoritme voor case-conversie.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// Als iterator:
    ///
    /// ```
    /// for c in 'İ'.to_lowercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// `println!` rechtstreeks gebruiken:
    ///
    /// ```
    /// println!("{}", 'İ'.to_lowercase());
    /// ```
    ///
    /// Beide zijn gelijk aan:
    ///
    /// ```
    /// println!("i\u{307}");
    /// ```
    ///
    /// `to_string` gebruiken:
    ///
    /// ```
    /// assert_eq!('C'.to_lowercase().to_string(), "c");
    ///
    /// // Soms is het resultaat meer dan één teken:
    /// assert_eq!('İ'.to_lowercase().to_string(), "i\u{307}");
    ///
    /// // Tekens die niet zowel hoofdletters als kleine letters bevatten, worden naar zichzelf geconverteerd.
    /////
    /// assert_eq!('山'.to_lowercase().to_string(), "山");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_lowercase(self) -> ToLowercase {
        ToLowercase(CaseMappingIter::new(conversions::to_lower(self)))
    }

    /// Retourneert een iterator die de hoofdlettertoewijzing van deze `char` als een of meer oplevert
    /// `char`s.
    ///
    /// Als deze `char` geen hoofdlettertoewijzing heeft, levert de iterator dezelfde `char` op.
    ///
    /// Als deze `char` een een-op-een hoofdlettertoewijzing heeft die wordt gegeven door de [Unicode Character Database][ucd] [`UnicodeData.txt`], levert de iterator die `char` op.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// Als deze `char` speciale overwegingen vereist (bijv. Meerdere `char`s), levert de iterator de`char` (s) op die door [`SpecialCasing.txt`] worden gegeven.
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// Deze bewerking voert een onvoorwaardelijke mapping uit zonder maatwerk.Dat wil zeggen, de conversie is onafhankelijk van context en taal.
    ///
    /// In de [Unicode Standard] bespreekt Hoofdstuk 4 (Karaktereigenschappen) case mapping in het algemeen en Hoofdstuk 3 (Conformance) bespreekt het standaard algoritme voor case-conversie.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// Als iterator:
    ///
    /// ```
    /// for c in 'ß'.to_uppercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// `println!` rechtstreeks gebruiken:
    ///
    /// ```
    /// println!("{}", 'ß'.to_uppercase());
    /// ```
    ///
    /// Beide zijn gelijk aan:
    ///
    /// ```
    /// println!("SS");
    /// ```
    ///
    /// `to_string` gebruiken:
    ///
    /// ```
    /// assert_eq!('c'.to_uppercase().to_string(), "C");
    ///
    /// // Soms is het resultaat meer dan één teken:
    /// assert_eq!('ß'.to_uppercase().to_string(), "SS");
    ///
    /// // Tekens die niet zowel hoofdletters als kleine letters bevatten, worden naar zichzelf geconverteerd.
    /////
    /// assert_eq!('山'.to_uppercase().to_string(), "山");
    /// ```
    ///
    /// # Opmerking over de locatie
    ///
    /// In het Turks heeft het equivalent van 'i' in het Latijn vijf vormen in plaats van twee:
    ///
    /// * 'Dotless': I/ı, soms geschreven ï
    /// * 'Dotted': İ/i
    ///
    /// Merk op dat de kleine gestippelde 'i' hetzelfde is als het Latijn.Daarom:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    /// ```
    ///
    /// De waarde van `upper_i` is hier afhankelijk van de taal van de tekst: als we in `en-US` zijn, zou het `"I"` moeten zijn, maar als we in `tr_TR` zijn, zou het `"İ"` moeten zijn.
    /// `to_uppercase()` houdt hier geen rekening mee, en dus:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    ///
    /// assert_eq!(upper_i, "I");
    /// ```
    ///
    /// geldt over talen heen.
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_uppercase(self) -> ToUppercase {
        ToUppercase(CaseMappingIter::new(conversions::to_upper(self)))
    }

    /// Controleert of de waarde binnen het ASCII-bereik valt.
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.32.0")]
    #[inline]
    pub const fn is_ascii(&self) -> bool {
        *self as u32 <= 0x7F
    }

    /// Maakt een kopie van de waarde in ASCII-equivalent in hoofdletters.
    ///
    /// ASCII-letters 'a' tot 'z' worden toegewezen aan 'A' tot 'Z', maar niet-ASCII-letters blijven ongewijzigd.
    ///
    /// Gebruik [`make_ascii_uppercase()`] om de waarde ter plekke in hoofdletters te zetten.
    ///
    /// Gebruik [`to_uppercase()`] om ASCII-tekens in hoofdletters te gebruiken naast niet-ASCII-tekens.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('A', ascii.to_ascii_uppercase());
    /// assert_eq!('❤', non_ascii.to_ascii_uppercase());
    /// ```
    ///
    /// [`make_ascii_uppercase()`]: #method.make_ascii_uppercase
    /// [`to_uppercase()`]: #method.to_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_uppercase(&self) -> char {
        if self.is_ascii_lowercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// Maakt een kopie van de waarde in zijn ASCII-equivalent in kleine letters.
    ///
    /// ASCII-letters 'A' tot 'Z' worden toegewezen aan 'a' tot 'z', maar niet-ASCII-letters blijven ongewijzigd.
    ///
    /// Gebruik [`make_ascii_lowercase()`] om de waarde op zijn plaats in kleine letters te zetten.
    ///
    /// Gebruik [`to_lowercase()`] om ASCII-tekens in kleine letters naast niet-ASCII-tekens te gebruiken.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'A';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('a', ascii.to_ascii_lowercase());
    /// assert_eq!('❤', non_ascii.to_ascii_lowercase());
    /// ```
    ///
    /// [`make_ascii_lowercase()`]: #method.make_ascii_lowercase
    /// [`to_lowercase()`]: #method.to_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_lowercase(&self) -> char {
        if self.is_ascii_uppercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// Controleert of twee waarden een ASCII-hoofdletterongevoelige overeenkomst zijn.
    ///
    /// Gelijk aan `to_ascii_lowercase(a) == to_ascii_lowercase(b)`.
    ///
    /// # Examples
    ///
    /// ```
    /// let upper_a = 'A';
    /// let lower_a = 'a';
    /// let lower_z = 'z';
    ///
    /// assert!(upper_a.eq_ignore_ascii_case(&lower_a));
    /// assert!(upper_a.eq_ignore_ascii_case(&upper_a));
    /// assert!(!upper_a.eq_ignore_ascii_case(&lower_z));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn eq_ignore_ascii_case(&self, other: &char) -> bool {
        self.to_ascii_lowercase() == other.to_ascii_lowercase()
    }

    /// Converteert dit type ter plekke naar het ASCII-equivalent in hoofdletters.
    ///
    /// ASCII-letters 'a' tot 'z' worden toegewezen aan 'A' tot 'Z', maar niet-ASCII-letters blijven ongewijzigd.
    ///
    /// Gebruik [`to_ascii_uppercase()`] om een nieuwe waarde in hoofdletters te retourneren zonder de bestaande te wijzigen.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'a';
    ///
    /// ascii.make_ascii_uppercase();
    ///
    /// assert_eq!('A', ascii);
    /// ```
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        *self = self.to_ascii_uppercase();
    }

    /// Converteert dit type ter plaatse naar het ASCII-equivalent in kleine letters.
    ///
    /// ASCII-letters 'A' tot 'Z' worden toegewezen aan 'a' tot 'z', maar niet-ASCII-letters blijven ongewijzigd.
    ///
    /// Gebruik [`to_ascii_lowercase()`] om een nieuwe lagere waarde te retourneren zonder de bestaande te wijzigen.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'A';
    ///
    /// ascii.make_ascii_lowercase();
    ///
    /// assert_eq!('a', ascii);
    /// ```
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        *self = self.to_ascii_lowercase();
    }

    /// Controleert of de waarde een alfabetisch ASCII-teken is:
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z', of
    /// - U + 0061 'a' ..=U + 007A 'z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphabetic());
    /// assert!(uppercase_g.is_ascii_alphabetic());
    /// assert!(a.is_ascii_alphabetic());
    /// assert!(g.is_ascii_alphabetic());
    /// assert!(!zero.is_ascii_alphabetic());
    /// assert!(!percent.is_ascii_alphabetic());
    /// assert!(!space.is_ascii_alphabetic());
    /// assert!(!lf.is_ascii_alphabetic());
    /// assert!(!esc.is_ascii_alphabetic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphabetic(&self) -> bool {
        matches!(*self, 'A'..='Z' | 'a'..='z')
    }

    /// Controleert of de waarde een ASCII-hoofdletter is:
    /// U + 0041 'A' ..=U + 005A 'Z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_uppercase());
    /// assert!(uppercase_g.is_ascii_uppercase());
    /// assert!(!a.is_ascii_uppercase());
    /// assert!(!g.is_ascii_uppercase());
    /// assert!(!zero.is_ascii_uppercase());
    /// assert!(!percent.is_ascii_uppercase());
    /// assert!(!space.is_ascii_uppercase());
    /// assert!(!lf.is_ascii_uppercase());
    /// assert!(!esc.is_ascii_uppercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_uppercase(&self) -> bool {
        matches!(*self, 'A'..='Z')
    }

    /// Controleert of de waarde een ASCII-teken in kleine letters is:
    /// U + 0061 'a' ..=U + 007A 'z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_lowercase());
    /// assert!(!uppercase_g.is_ascii_lowercase());
    /// assert!(a.is_ascii_lowercase());
    /// assert!(g.is_ascii_lowercase());
    /// assert!(!zero.is_ascii_lowercase());
    /// assert!(!percent.is_ascii_lowercase());
    /// assert!(!space.is_ascii_lowercase());
    /// assert!(!lf.is_ascii_lowercase());
    /// assert!(!esc.is_ascii_lowercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_lowercase(&self) -> bool {
        matches!(*self, 'a'..='z')
    }

    /// Controleert of de waarde een alfanumeriek ASCII-teken is:
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z', of
    /// - U + 0061 'a' ..=U + 007A 'z', of
    /// - U + 0030 '0' ..=U + 0039 '9'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphanumeric());
    /// assert!(uppercase_g.is_ascii_alphanumeric());
    /// assert!(a.is_ascii_alphanumeric());
    /// assert!(g.is_ascii_alphanumeric());
    /// assert!(zero.is_ascii_alphanumeric());
    /// assert!(!percent.is_ascii_alphanumeric());
    /// assert!(!space.is_ascii_alphanumeric());
    /// assert!(!lf.is_ascii_alphanumeric());
    /// assert!(!esc.is_ascii_alphanumeric());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphanumeric(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='Z' | 'a'..='z')
    }

    /// Controleert of de waarde een ASCII-decimaal cijfer is:
    /// U + 0030 '0' ..=U + 0039 '9'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_digit());
    /// assert!(!uppercase_g.is_ascii_digit());
    /// assert!(!a.is_ascii_digit());
    /// assert!(!g.is_ascii_digit());
    /// assert!(zero.is_ascii_digit());
    /// assert!(!percent.is_ascii_digit());
    /// assert!(!space.is_ascii_digit());
    /// assert!(!lf.is_ascii_digit());
    /// assert!(!esc.is_ascii_digit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_digit(&self) -> bool {
        matches!(*self, '0'..='9')
    }

    /// Controleert of de waarde een ASCII hexadecimaal cijfer is:
    ///
    /// - U + 0030 '0' ..=U + 0039 '9', of
    /// - U + 0041 'A' ..=U + 0046 'F', of
    /// - U + 0061 'a' ..=U + 0066 'f'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_hexdigit());
    /// assert!(!uppercase_g.is_ascii_hexdigit());
    /// assert!(a.is_ascii_hexdigit());
    /// assert!(!g.is_ascii_hexdigit());
    /// assert!(zero.is_ascii_hexdigit());
    /// assert!(!percent.is_ascii_hexdigit());
    /// assert!(!space.is_ascii_hexdigit());
    /// assert!(!lf.is_ascii_hexdigit());
    /// assert!(!esc.is_ascii_hexdigit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_hexdigit(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='F' | 'a'..='f')
    }

    /// Controleert of de waarde een ASCII-leesteken is:
    ///
    /// - U + 0021 ..=U + 002F `! " # $ % & ' ( ) * + , - . /`, of
    /// - U + 003A ..=U + 0040 `: ; < = > ? @`, of
    /// - U + 005B ..=U + 0060 ``[\] ^ _``, of
    /// - U + 007B ..=U + 007E `{ | } ~`
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_punctuation());
    /// assert!(!uppercase_g.is_ascii_punctuation());
    /// assert!(!a.is_ascii_punctuation());
    /// assert!(!g.is_ascii_punctuation());
    /// assert!(!zero.is_ascii_punctuation());
    /// assert!(percent.is_ascii_punctuation());
    /// assert!(!space.is_ascii_punctuation());
    /// assert!(!lf.is_ascii_punctuation());
    /// assert!(!esc.is_ascii_punctuation());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_punctuation(&self) -> bool {
        matches!(*self, '!'..='/' | ':'..='@' | '['..='`' | '{'..='~')
    }

    /// Controleert of de waarde een ASCII-grafisch teken is:
    /// U + 0021 '!' ..=U + 007E '~'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_graphic());
    /// assert!(uppercase_g.is_ascii_graphic());
    /// assert!(a.is_ascii_graphic());
    /// assert!(g.is_ascii_graphic());
    /// assert!(zero.is_ascii_graphic());
    /// assert!(percent.is_ascii_graphic());
    /// assert!(!space.is_ascii_graphic());
    /// assert!(!lf.is_ascii_graphic());
    /// assert!(!esc.is_ascii_graphic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_graphic(&self) -> bool {
        matches!(*self, '!'..='~')
    }

    /// Controleert of de waarde een ASCII-witruimteteken is:
    /// U + 0020 SPACE, U + 0009 HORIZONTALE TAB, U + 000A LIJNVOER, U + 000C FORM FEED, of U + 000D VERVOERRETOUR.
    ///
    /// Rust gebruikt de WhatWG Infra Standard's [definition of ASCII whitespace][infra-aw].Er zijn verschillende andere definities die veel worden gebruikt.
    /// [the POSIX locale][pct] bevat bijvoorbeeld U + 000B VERTICALE TAB en alle bovenstaande tekens, maar-van dezelfde specificatie-[de standaardregel voor "field splitting" in de Bourne shell][bfs] houdt rekening met *alleen* SPACE, HORIZONTALE TAB en LINE FEED als witruimte.
    ///
    ///
    /// Als u een programma schrijft dat een bestaand bestandsformaat zal verwerken, controleer dan wat de definitie van witruimte in dat formaat is voordat u deze functie gebruikt.
    ///
    /// [infra-aw]: https://infra.spec.whatwg.org/#ascii-whitespace
    /// [pct]: http://pubs.opengroup.org/onlinepubs/9699919799/basedefs/V1_chap07.html#tag_07_03_01
    /// [bfs]: http://pubs.opengroup.org/onlinepubs/9699919799/utilities/V3_chap02.html#tag_18_06_05
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_whitespace());
    /// assert!(!uppercase_g.is_ascii_whitespace());
    /// assert!(!a.is_ascii_whitespace());
    /// assert!(!g.is_ascii_whitespace());
    /// assert!(!zero.is_ascii_whitespace());
    /// assert!(!percent.is_ascii_whitespace());
    /// assert!(space.is_ascii_whitespace());
    /// assert!(lf.is_ascii_whitespace());
    /// assert!(!esc.is_ascii_whitespace());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_whitespace(&self) -> bool {
        matches!(*self, '\t' | '\n' | '\x0C' | '\r' | ' ')
    }

    /// Controleert of de waarde een ASCII-controleteken is:
    /// U + 0000 NUL ..=U + 001F UNIT SEPARATOR, of U + 007F DELETE.
    /// Merk op dat de meeste ASCII-witruimtetekens controletekens zijn, maar SPACE is dat niet.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_control());
    /// assert!(!uppercase_g.is_ascii_control());
    /// assert!(!a.is_ascii_control());
    /// assert!(!g.is_ascii_control());
    /// assert!(!zero.is_ascii_control());
    /// assert!(!percent.is_ascii_control());
    /// assert!(!space.is_ascii_control());
    /// assert!(lf.is_ascii_control());
    /// assert!(esc.is_ascii_control());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_control(&self) -> bool {
        matches!(*self, '\0'..='\x1F' | '\x7F')
    }
}

#[inline]
const fn len_utf8(code: u32) -> usize {
    if code < MAX_ONE_B {
        1
    } else if code < MAX_TWO_B {
        2
    } else if code < MAX_THREE_B {
        3
    } else {
        4
    }
}

/// Codeert een onbewerkte u32-waarde als UTF-8 in de opgegeven bytebuffer en retourneert vervolgens het subgedeelte van de buffer dat het gecodeerde teken bevat.
///
///
/// In tegenstelling tot `char::encode_utf8` verwerkt deze methode ook codepunten in het surrogaatbereik.
/// (Het creëren van een `char` in het surrogaatbereik is UB.) Het resultaat is geldige [generalized UTF-8] maar niet geldige UTF-8.
///
/// [generalized UTF-8]: https://simonsapin.github.io/wtf-8/#generalized-utf8
///
/// # Panics
///
/// Panics als de buffer niet groot genoeg is.
/// Een buffer met een lengte van vier is groot genoeg om elke `char` te coderen.
///
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf8_raw(code: u32, dst: &mut [u8]) -> &mut [u8] {
    let len = len_utf8(code);
    match (len, &mut dst[..]) {
        (1, [a, ..]) => {
            *a = code as u8;
        }
        (2, [a, b, ..]) => {
            *a = (code >> 6 & 0x1F) as u8 | TAG_TWO_B;
            *b = (code & 0x3F) as u8 | TAG_CONT;
        }
        (3, [a, b, c, ..]) => {
            *a = (code >> 12 & 0x0F) as u8 | TAG_THREE_B;
            *b = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *c = (code & 0x3F) as u8 | TAG_CONT;
        }
        (4, [a, b, c, d, ..]) => {
            *a = (code >> 18 & 0x07) as u8 | TAG_FOUR_B;
            *b = (code >> 12 & 0x3F) as u8 | TAG_CONT;
            *c = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *d = (code & 0x3F) as u8 | TAG_CONT;
        }
        _ => panic!(
            "encode_utf8: need {} bytes to encode U+{:X}, but the buffer has {}",
            len,
            code,
            dst.len(),
        ),
    };
    &mut dst[..len]
}

/// Codeert een onbewerkte u32-waarde als UTF-16 in de meegeleverde `u16`-buffer en retourneert vervolgens het subgedeelte van de buffer dat het gecodeerde teken bevat.
///
///
/// In tegenstelling tot `char::encode_utf16` verwerkt deze methode ook codepunten in het surrogaatbereik.
/// (Het maken van een `char` in het surrogaatbereik is UB.)
///
/// # Panics
///
/// Panics als de buffer niet groot genoeg is.
/// Een buffer met een lengte van 2 is groot genoeg om elke `char` te coderen.
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf16_raw(mut code: u32, dst: &mut [u16]) -> &mut [u16] {
    // VEILIGHEID: elke arm controleert of er voldoende bits zijn om in te schrijven
    unsafe {
        if (code & 0xFFFF) == code && !dst.is_empty() {
            // De BMP valt erdoorheen
            *dst.get_unchecked_mut(0) = code as u16;
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 1)
        } else if dst.len() >= 2 {
            // Aanvullende vliegtuigen breken in surrogaten in.
            code -= 0x1_0000;
            *dst.get_unchecked_mut(0) = 0xD800 | ((code >> 10) as u16);
            *dst.get_unchecked_mut(1) = 0xDC00 | ((code as u16) & 0x3FF);
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 2)
        } else {
            panic!(
                "encode_utf16: need {} units to encode U+{:X}, but the buffer has {}",
                from_u32_unchecked(code).len_utf16(),
                code,
                dst.len(),
            )
        }
    }
}