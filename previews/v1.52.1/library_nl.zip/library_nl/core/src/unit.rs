use crate::iter::FromIterator;

/// Vouwt alle eenheiditems van een iterator samen in één.
///
/// Dit is handiger in combinatie met abstracties van een hoger niveau, zoals verzamelen naar een `Result<(), E>` waar je alleen om fouten geeft:
///
///
/// ```
/// use std::io::*;
/// let data = vec![1, 2, 3, 4, 5];
/// let res: Result<()> = data.iter()
///     .map(|x| writeln!(stdout(), "{}", x))
///     .collect();
/// assert!(res.is_ok());
/// ```
#[stable(feature = "unit_from_iter", since = "1.23.0")]
impl FromIterator<()> for () {
    fn from_iter<I: IntoIterator<Item = ()>>(iter: I) -> Self {
        iter.into_iter().for_each(|()| {})
    }
}