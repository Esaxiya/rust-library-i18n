use crate::ops::DerefMut;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// Een interface voor het omgaan met asynchrone iteratoren.
///
/// Dit is de hoofdstroom trait.
/// Zie de [module-level documentation] voor meer informatie over het concept van streams in het algemeen.
/// In het bijzonder wilt u misschien weten hoe u [implement `Stream`][impl].
///
/// [module-level documentation]: index.html
/// [impl]: index.html#implementing-stream
#[unstable(feature = "async_stream", issue = "79024")]
#[must_use = "streams do nothing unless polled"]
pub trait Stream {
    /// Het type items dat door de stream wordt opgeleverd.
    type Item;

    /// Probeer de volgende waarde van deze stream op te halen, registreer de huidige taak voor wake-up als de waarde nog niet beschikbaar is, en retourneer `None` als de stream is uitgeput.
    ///
    /// # Winstwaarde
    ///
    /// Er zijn verschillende mogelijke retourwaarden, die elk een afzonderlijke stroomstatus aangeven:
    ///
    /// - `Poll::Pending` betekent dat de volgende waarde van deze stream nog niet klaar is.Implementaties zorgen ervoor dat de huidige taak wordt geïnformeerd wanneer de volgende waarde mogelijk gereed is.
    ///
    /// - `Poll::Ready(Some(val))` betekent dat de stream met succes een waarde heeft geproduceerd, `val`, en mogelijk verdere waarden kan produceren bij volgende `poll_next`-aanroepen.
    ///
    /// - `Poll::Ready(None)` betekent dat de stream is beëindigd en dat `poll_next` niet opnieuw mag worden aangeroepen.
    ///
    /// # Panics
    ///
    /// Zodra een stream is voltooid (`Ready(None)` from `poll_next`) geretourneerd, de `poll_next`-methode opnieuw aanroepen kan panic, voor altijd blokkeren of andere soorten problemen veroorzaken; de `Stream` trait stelt geen eisen aan de effecten van een dergelijke oproep.
    ///
    /// Omdat de `poll_next`-methode echter niet als `unsafe` is gemarkeerd, zijn de gebruikelijke regels van Rust van toepassing: oproepen mogen nooit ongedefinieerd gedrag veroorzaken (geheugenbeschadiging, onjuist gebruik van `unsafe`-functies of iets dergelijks), ongeacht de status van de stream.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>>;

    /// Retourneert de grenzen voor de resterende lengte van de stream.
    ///
    /// In het bijzonder retourneert `size_hint()` een tuple waarbij het eerste element de ondergrens is en het tweede element de bovengrens.
    ///
    /// De tweede helft van het tupel dat wordt geretourneerd, is een [`Option`]`<`[`usize`] `>`.
    /// Een [`None`] betekent hier dat er ofwel geen bekende bovengrens is, of dat de bovengrens groter is dan [`usize`].
    ///
    /// # Implementatie notities
    ///
    /// Het wordt niet afgedwongen dat een stroomimplementatie het aangegeven aantal elementen oplevert.Een buggy-stream kan minder opleveren dan de ondergrens of meer dan de bovengrens van elementen.
    ///
    /// `size_hint()` is primair bedoeld om te worden gebruikt voor optimalisaties zoals het reserveren van ruimte voor de elementen van de stream, maar mag niet vertrouwd worden om bijvoorbeeld grenscontroles in onveilige code weg te laten.
    /// Een onjuiste implementatie van `size_hint()` mag niet leiden tot schendingen van de geheugenveiligheid.
    ///
    /// Dat gezegd hebbende, zou de implementatie een juiste schatting moeten geven, omdat het anders in strijd zou zijn met het protocol van trait.
    ///
    /// De standaardimplementatie retourneert `(0,` [`None`]`)`wat correct is voor elke stream.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<S: ?Sized + Stream + Unpin> Stream for &mut S {
    type Item = S::Item;

    fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        S::poll_next(Pin::new(&mut **self), cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<P> Stream for Pin<P>
where
    P: DerefMut + Unpin,
    P::Target: Stream,
{
    type Item = <P::Target as Stream>::Item;

    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        self.get_mut().as_mut().poll_next(cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}