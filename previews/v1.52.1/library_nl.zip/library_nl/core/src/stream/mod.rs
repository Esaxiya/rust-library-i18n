//! Samengestelde asynchrone iteratie.
//!
//! Als futures asynchrone waarden zijn, zijn streams asynchrone iteratoren.
//! Als je merkt dat je een soort asynchrone verzameling hebt en een bewerking op de elementen van die verzameling moet uitvoeren, kom je snel 'streams' tegen.
//! Streams worden veel gebruikt in idiomatische asynchrone Rust-code, dus het is de moeite waard om ermee vertrouwd te raken.
//!
//! Voordat we meer uitleggen, laten we het hebben over hoe deze module is gestructureerd:
//!
//! # Organization
//!
//! Deze module is grotendeels ingedeeld naar type:
//!
//! * [Traits] vormen het kerngedeelte: deze traits bepalen wat voor soort streams er zijn en wat je ermee kunt doen.De methoden van deze traits zijn de moeite waard om wat extra studietijd in te steken.
//! * Functies bieden een aantal handige manieren om enkele basisstreams te maken.
//! * Structs zijn vaak de retourtypen van de verschillende methoden op de traits van deze module.Meestal wil je kijken naar de methode die de `struct` maakt, in plaats van naar de `struct` zelf.
//! Voor meer details over waarom, zie '[Implementing Stream](#Implementing-stream)'.
//!
//! [Traits]: #traits
//!
//! Dat is het!Laten we in beken graven.
//!
//! # Stream
//!
//! Het hart en de ziel van deze module is de [`Stream`] trait.De kern van [`Stream`] ziet er als volgt uit:
//!
//! ```
//! # use core::task::{Context, Poll};
//! # use core::pin::Pin;
//! trait Stream {
//!     type Item;
//!     fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>>;
//! }
//! ```
//!
//! In tegenstelling tot `Iterator` maakt `Stream` onderscheid tussen de [`poll_next`]-methode die wordt gebruikt bij het implementeren van een `Stream` en een (to-be-implemented) `next`-methode die wordt gebruikt bij het consumeren van een stream.
//!
//! Consumenten van `Stream` hoeven alleen rekening te houden met `next`, die, wanneer deze wordt aangeroepen, een future retourneert die `Option<Stream::Item>` oplevert.
//!
//! De future die door `next` wordt geretourneerd, levert `Some(Item)` op zolang er elementen zijn, en zodra ze allemaal zijn uitgeput, levert `None` op om aan te geven dat de iteratie is voltooid.
//! Als we wachten op iets asynchroon om op te lossen, zal de future wachten tot de stream klaar is om weer op te geven.
//!
//! Individuele streams kunnen ervoor kiezen om de iteratie te hervatten, en dus het opnieuw bellen van `next` kan uiteindelijk op een gegeven moment `Some(Item)` weer opleveren.
//!
//! De volledige definitie van [`Stream`] omvat ook een aantal andere methoden, maar het zijn standaardmethoden, bovenop [`poll_next`] gebouwd, en dus krijg je ze gratis.
//!
//! [`Poll`]: super::task::Poll
//! [`poll_next`]: Stream::poll_next
//!
//! # Implementeren van Stream
//!
//! Het maken van een eigen stream omvat twee stappen: het maken van een `struct` om de status van de stream vast te houden en vervolgens [`Stream`] implementeren voor die `struct`.
//!
//! Laten we een stream maken met de naam `Counter` die telt van `1` tot `5`:
//!
//! ```no_run
//! #![feature(async_stream)]
//! # use core::stream::Stream;
//! # use core::task::{Context, Poll};
//! # use core::pin::Pin;
//!
//! // Ten eerste de structuur:
//!
//! /// Een stream die telt van één tot vijf
//! struct Counter {
//!     count: usize,
//! }
//!
//! // we willen dat onze telling bij één begint, dus laten we een new()-methode toevoegen om te helpen.
//! // Dit is niet strikt noodzakelijk, maar wel handig.
//! // Merk op dat we `count` op nul starten, we zullen zien waarom in `poll_next()`'s-implementatie hieronder.
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // Vervolgens implementeren we `Stream` voor onze `Counter`:
//!
//! impl Stream for Counter {
//!     // we zullen rekenen met usize
//!     type Item = usize;
//!
//!     // poll_next() is de enige vereiste methode
//!     fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
//!         // Verhoog onze telling.Daarom zijn we bij nul begonnen.
//!         self.count += 1;
//!
//!         // Controleer of we klaar zijn met tellen of niet.
//!         if self.count < 6 {
//!             Poll::Ready(Some(self.count))
//!         } else {
//!             Poll::Ready(None)
//!         }
//!     }
//! }
//! ```
//!
//! # Laziness
//!
//! Streams zijn *lui*.Dit betekent dat alleen het maken van een stream _do_ niet veel oplevert.Er gebeurt eigenlijk niets totdat u `next` belt.
//! Dit is soms een bron van verwarring bij het maken van een stream uitsluitend vanwege de bijwerkingen.
//! De compiler zal ons waarschuwen voor dit soort gedrag:
//!
//! ```text
//! warning: unused result that must be used: streams do nothing unless polled
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

mod stream;

pub use stream::Stream;