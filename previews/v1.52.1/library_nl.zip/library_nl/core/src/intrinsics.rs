//! Compiler intrinsiek.
//!
//! De bijbehorende definities zijn in `compiler/rustc_codegen_llvm/src/intrinsic.rs`.
//! De bijbehorende const-implementaties zijn in `compiler/rustc_mir/src/interpret/intrinsics.rs`
//!
//! # Const intrinsiek
//!
//! Note: eventuele wijzigingen in de inhoud van de inhoud moeten met het taalteam worden besproken.
//! Dit omvat veranderingen in de stabiliteit van de constness.
//!
//! Om een intrinsiek bruikbaar te maken tijdens het compileren, moet je de implementatie kopiëren van <https://github.com/rust-lang/miri/blob/master/src/shims/intrinsics.rs> naar `compiler/rustc_mir/src/interpret/intrinsics.rs` en een `#[rustc_const_unstable(feature = "foo", issue = "01234")]` toevoegen aan het intrinsieke.
//!
//!
//! Als een intrinsiek moet worden gebruikt vanaf een `const fn` met een `rustc_const_stable`-attribuut, moet het intrinsieke attribuut ook `rustc_const_stable` zijn.
//! Een dergelijke wijziging zou niet moeten worden gedaan zonder T-lang-overleg, omdat het een functie in de taal inbrengt die niet kan worden gerepliceerd in gebruikerscode zonder compilerondersteuning.
//!
//! # Volatiles
//!
//! De vluchtige intrinsieke gegevens bieden bewerkingen die bedoeld zijn om in te werken op het I/O-geheugen, die gegarandeerd niet opnieuw worden gerangschikt door de compiler voor andere vluchtige intrinsieke gegevens.Zie de LLVM-documentatie op [[volatile]].
//!
//! [volatile]: http://llvm.org/docs/LangRef.html#volatile-memory-accesses
//!
//! # Atomics
//!
//! De atomaire intrinsieke gegevens bieden algemene atomaire bewerkingen op machinewoorden, met meerdere mogelijke geheugenvolgorden.Ze gehoorzamen dezelfde semantiek als C++ 11.Zie de LLVM-documentatie op [[atomics]].
//!
//! [atomics]: http://llvm.org/docs/Atomics.html
//!
//! Een snelle opfriscursus over het bestellen van geheugen:
//!
//! * Verwerven, een barrière voor het verwerven van een slot.Daaropvolgende lees-en schrijfbewerkingen vinden plaats na de barrière.
//! * Release, een barrière voor het vrijgeven van een slot.Voorafgaand lezen en schrijven vindt plaats vóór de slagboom.
//! * Opeenvolgend consistente, opeenvolgend consistente bewerkingen gebeuren gegarandeerd in de juiste volgorde.Dit is de standaardmodus voor het werken met atomaire typen en is gelijk aan de `volatile` van Java.
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![unstable(
    feature = "core_intrinsics",
    reason = "intrinsics are unlikely to ever be stabilized, instead \
                      they should be used through stabilized interfaces \
                      in the rest of the standard library",
    issue = "none"
)]
#![allow(missing_docs)]

use crate::marker::DiscriminantKind;
use crate::mem;

// Deze invoer wordt gebruikt om intra-doc-koppelingen te vereenvoudigen
#[allow(unused_imports)]
#[cfg(all(target_has_atomic = "8", target_has_atomic = "32", target_has_atomic = "ptr"))]
use crate::sync::atomic::{self, AtomicBool, AtomicI32, AtomicIsize, AtomicU32, Ordering};

#[stable(feature = "drop_in_place", since = "1.8.0")]
#[rustc_deprecated(
    reason = "no longer an intrinsic - use `ptr::drop_in_place` directly",
    since = "1.52.0"
)]
#[inline]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // VEILIGHEID: zie `ptr::drop_in_place`
    unsafe { crate::ptr::drop_in_place(to_drop) }
}

extern "rust-intrinsic" {
    // NB, deze intrinsieke gegevens nemen onbewerkte verwijzingen omdat ze het gealiaste geheugen muteren, wat niet geldig is voor `&` of `&mut`.
    //

    /// Slaat een waarde op als de huidige waarde hetzelfde is als de `old`-waarde.
    ///
    /// De gestabiliseerde versie van deze intrinsieke versie is beschikbaar op de [`atomic`]-typen via de `compare_exchange`-methode door [`Ordering::SeqCst`] door te geven als zowel de `success`-als `failure`-parameters.
    ///
    /// Bijvoorbeeld, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Slaat een waarde op als de huidige waarde hetzelfde is als de `old`-waarde.
    ///
    /// De gestabiliseerde versie van deze intrinsieke versie is beschikbaar op de [`atomic`]-typen via de `compare_exchange`-methode door [`Ordering::Acquire`] door te geven als zowel de `success`-als `failure`-parameters.
    ///
    /// Bijvoorbeeld, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Slaat een waarde op als de huidige waarde hetzelfde is als de `old`-waarde.
    ///
    /// De gestabiliseerde versie van deze intrinsieke versie is beschikbaar op de [`atomic`]-typen via de `compare_exchange`-methode door [`Ordering::Release`] door te geven als de `success` en [`Ordering::Relaxed`] als de `failure`-parameters.
    /// Bijvoorbeeld, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Slaat een waarde op als de huidige waarde hetzelfde is als de `old`-waarde.
    ///
    /// De gestabiliseerde versie van deze intrinsieke versie is beschikbaar op de [`atomic`]-typen via de `compare_exchange`-methode door [`Ordering::AcqRel`] door te geven als de `success` en [`Ordering::Acquire`] als de `failure`-parameters.
    /// Bijvoorbeeld, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Slaat een waarde op als de huidige waarde hetzelfde is als de `old`-waarde.
    ///
    /// De gestabiliseerde versie van deze intrinsieke versie is beschikbaar op de [`atomic`]-typen via de `compare_exchange`-methode door [`Ordering::Relaxed`] door te geven als zowel de `success`-als `failure`-parameters.
    ///
    /// Bijvoorbeeld, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Slaat een waarde op als de huidige waarde hetzelfde is als de `old`-waarde.
    ///
    /// De gestabiliseerde versie van deze intrinsieke versie is beschikbaar op de [`atomic`]-typen via de `compare_exchange`-methode door [`Ordering::SeqCst`] door te geven als de `success` en [`Ordering::Relaxed`] als de `failure`-parameters.
    /// Bijvoorbeeld, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Slaat een waarde op als de huidige waarde hetzelfde is als de `old`-waarde.
    ///
    /// De gestabiliseerde versie van deze intrinsieke versie is beschikbaar op de [`atomic`]-typen via de `compare_exchange`-methode door [`Ordering::SeqCst`] door te geven als de `success` en [`Ordering::Acquire`] als de `failure`-parameters.
    /// Bijvoorbeeld, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Slaat een waarde op als de huidige waarde hetzelfde is als de `old`-waarde.
    ///
    /// De gestabiliseerde versie van deze intrinsieke versie is beschikbaar op de [`atomic`]-typen via de `compare_exchange`-methode door [`Ordering::Acquire`] door te geven als de `success` en [`Ordering::Relaxed`] als de `failure`-parameters.
    /// Bijvoorbeeld, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Slaat een waarde op als de huidige waarde hetzelfde is als de `old`-waarde.
    ///
    /// De gestabiliseerde versie van deze intrinsieke versie is beschikbaar op de [`atomic`]-typen via de `compare_exchange`-methode door [`Ordering::AcqRel`] door te geven als de `success` en [`Ordering::Relaxed`] als de `failure`-parameters.
    /// Bijvoorbeeld, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// Slaat een waarde op als de huidige waarde hetzelfde is als de `old`-waarde.
    ///
    /// De gestabiliseerde versie van deze intrinsieke versie is beschikbaar op de [`atomic`]-typen via de `compare_exchange_weak`-methode door [`Ordering::SeqCst`] door te geven als zowel de `success`-als `failure`-parameters.
    ///
    /// Bijvoorbeeld, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Slaat een waarde op als de huidige waarde hetzelfde is als de `old`-waarde.
    ///
    /// De gestabiliseerde versie van deze intrinsieke versie is beschikbaar op de [`atomic`]-typen via de `compare_exchange_weak`-methode door [`Ordering::Acquire`] door te geven als zowel de `success`-als `failure`-parameters.
    ///
    /// Bijvoorbeeld, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Slaat een waarde op als de huidige waarde hetzelfde is als de `old`-waarde.
    ///
    /// De gestabiliseerde versie van deze intrinsieke versie is beschikbaar op de [`atomic`]-typen via de `compare_exchange_weak`-methode door [`Ordering::Release`] door te geven als de `success` en [`Ordering::Relaxed`] als de `failure`-parameters.
    /// Bijvoorbeeld, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Slaat een waarde op als de huidige waarde hetzelfde is als de `old`-waarde.
    ///
    /// De gestabiliseerde versie van deze intrinsieke versie is beschikbaar op de [`atomic`]-typen via de `compare_exchange_weak`-methode door [`Ordering::AcqRel`] door te geven als de `success` en [`Ordering::Acquire`] als de `failure`-parameters.
    /// Bijvoorbeeld, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Slaat een waarde op als de huidige waarde hetzelfde is als de `old`-waarde.
    ///
    /// De gestabiliseerde versie van deze intrinsieke versie is beschikbaar op de [`atomic`]-typen via de `compare_exchange_weak`-methode door [`Ordering::Relaxed`] door te geven als zowel de `success`-als `failure`-parameters.
    ///
    /// Bijvoorbeeld, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Slaat een waarde op als de huidige waarde hetzelfde is als de `old`-waarde.
    ///
    /// De gestabiliseerde versie van deze intrinsieke versie is beschikbaar op de [`atomic`]-typen via de `compare_exchange_weak`-methode door [`Ordering::SeqCst`] door te geven als de `success` en [`Ordering::Relaxed`] als de `failure`-parameters.
    /// Bijvoorbeeld, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Slaat een waarde op als de huidige waarde hetzelfde is als de `old`-waarde.
    ///
    /// De gestabiliseerde versie van deze intrinsieke versie is beschikbaar op de [`atomic`]-typen via de `compare_exchange_weak`-methode door [`Ordering::SeqCst`] door te geven als de `success` en [`Ordering::Acquire`] als de `failure`-parameters.
    /// Bijvoorbeeld, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Slaat een waarde op als de huidige waarde hetzelfde is als de `old`-waarde.
    ///
    /// De gestabiliseerde versie van deze intrinsieke versie is beschikbaar op de [`atomic`]-typen via de `compare_exchange_weak`-methode door [`Ordering::Acquire`] door te geven als de `success` en [`Ordering::Relaxed`] als de `failure`-parameters.
    /// Bijvoorbeeld, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Slaat een waarde op als de huidige waarde hetzelfde is als de `old`-waarde.
    ///
    /// De gestabiliseerde versie van deze intrinsieke versie is beschikbaar op de [`atomic`]-typen via de `compare_exchange_weak`-methode door [`Ordering::AcqRel`] door te geven als de `success` en [`Ordering::Relaxed`] als de `failure`-parameters.
    /// Bijvoorbeeld, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// Laadt de huidige waarde van de aanwijzer.
    ///
    /// De gestabiliseerde versie van deze intrinsieke versie is beschikbaar op de [`atomic`]-typen via de `load`-methode door [`Ordering::SeqCst`] door te geven als de `order`.
    /// Bijvoorbeeld, [`AtomicBool::load`].
    ///
    pub fn atomic_load<T: Copy>(src: *const T) -> T;
    /// Laadt de huidige waarde van de aanwijzer.
    ///
    /// De gestabiliseerde versie van deze intrinsieke versie is beschikbaar op de [`atomic`]-typen via de `load`-methode door [`Ordering::Acquire`] door te geven als de `order`.
    /// Bijvoorbeeld, [`AtomicBool::load`].
    ///
    pub fn atomic_load_acq<T: Copy>(src: *const T) -> T;
    /// Laadt de huidige waarde van de aanwijzer.
    ///
    /// De gestabiliseerde versie van deze intrinsieke versie is beschikbaar op de [`atomic`]-typen via de `load`-methode door [`Ordering::Relaxed`] door te geven als de `order`.
    /// Bijvoorbeeld, [`AtomicBool::load`].
    ///
    pub fn atomic_load_relaxed<T: Copy>(src: *const T) -> T;
    pub fn atomic_load_unordered<T: Copy>(src: *const T) -> T;

    /// Slaat de waarde op de opgegeven geheugenlocatie op.
    ///
    /// De gestabiliseerde versie van deze intrinsieke versie is beschikbaar op de [`atomic`]-typen via de `store`-methode door [`Ordering::SeqCst`] door te geven als de `order`.
    /// Bijvoorbeeld, [`AtomicBool::store`].
    ///
    pub fn atomic_store<T: Copy>(dst: *mut T, val: T);
    /// Slaat de waarde op de opgegeven geheugenlocatie op.
    ///
    /// De gestabiliseerde versie van deze intrinsieke versie is beschikbaar op de [`atomic`]-typen via de `store`-methode door [`Ordering::Release`] door te geven als de `order`.
    /// Bijvoorbeeld, [`AtomicBool::store`].
    ///
    pub fn atomic_store_rel<T: Copy>(dst: *mut T, val: T);
    /// Slaat de waarde op de opgegeven geheugenlocatie op.
    ///
    /// De gestabiliseerde versie van deze intrinsieke versie is beschikbaar op de [`atomic`]-typen via de `store`-methode door [`Ordering::Relaxed`] door te geven als de `order`.
    /// Bijvoorbeeld, [`AtomicBool::store`].
    ///
    pub fn atomic_store_relaxed<T: Copy>(dst: *mut T, val: T);
    pub fn atomic_store_unordered<T: Copy>(dst: *mut T, val: T);

    /// Slaat de waarde op de opgegeven geheugenlocatie op, waarbij de oude waarde wordt geretourneerd.
    ///
    /// De gestabiliseerde versie van deze intrinsieke versie is beschikbaar op de [`atomic`]-typen via de `swap`-methode door [`Ordering::SeqCst`] door te geven als de `order`.
    /// Bijvoorbeeld, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg<T: Copy>(dst: *mut T, src: T) -> T;
    /// Slaat de waarde op de opgegeven geheugenlocatie op, waarbij de oude waarde wordt geretourneerd.
    ///
    /// De gestabiliseerde versie van deze intrinsieke versie is beschikbaar op de [`atomic`]-typen via de `swap`-methode door [`Ordering::Acquire`] door te geven als de `order`.
    /// Bijvoorbeeld, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Slaat de waarde op de opgegeven geheugenlocatie op, waarbij de oude waarde wordt geretourneerd.
    ///
    /// De gestabiliseerde versie van deze intrinsieke versie is beschikbaar op de [`atomic`]-typen via de `swap`-methode door [`Ordering::Release`] door te geven als de `order`.
    /// Bijvoorbeeld, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Slaat de waarde op de opgegeven geheugenlocatie op, waarbij de oude waarde wordt geretourneerd.
    ///
    /// De gestabiliseerde versie van deze intrinsieke versie is beschikbaar op de [`atomic`]-typen via de `swap`-methode door [`Ordering::AcqRel`] door te geven als de `order`.
    /// Bijvoorbeeld, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Slaat de waarde op de opgegeven geheugenlocatie op, waarbij de oude waarde wordt geretourneerd.
    ///
    /// De gestabiliseerde versie van deze intrinsieke versie is beschikbaar op de [`atomic`]-typen via de `swap`-methode door [`Ordering::Relaxed`] door te geven als de `order`.
    /// Bijvoorbeeld, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Voegt toe aan de huidige waarde en retourneert de vorige waarde.
    ///
    /// De gestabiliseerde versie van deze intrinsieke versie is beschikbaar op de [`atomic`]-typen via de `fetch_add`-methode door [`Ordering::SeqCst`] door te geven als de `order`.
    /// Bijvoorbeeld, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd<T: Copy>(dst: *mut T, src: T) -> T;
    /// Voegt toe aan de huidige waarde en retourneert de vorige waarde.
    ///
    /// De gestabiliseerde versie van deze intrinsieke versie is beschikbaar op de [`atomic`]-typen via de `fetch_add`-methode door [`Ordering::Acquire`] door te geven als de `order`.
    /// Bijvoorbeeld, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Voegt toe aan de huidige waarde en retourneert de vorige waarde.
    ///
    /// De gestabiliseerde versie van deze intrinsieke versie is beschikbaar op de [`atomic`]-typen via de `fetch_add`-methode door [`Ordering::Release`] door te geven als de `order`.
    /// Bijvoorbeeld, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Voegt toe aan de huidige waarde en retourneert de vorige waarde.
    ///
    /// De gestabiliseerde versie van deze intrinsieke versie is beschikbaar op de [`atomic`]-typen via de `fetch_add`-methode door [`Ordering::AcqRel`] door te geven als de `order`.
    /// Bijvoorbeeld, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Voegt toe aan de huidige waarde en retourneert de vorige waarde.
    ///
    /// De gestabiliseerde versie van deze intrinsieke versie is beschikbaar op de [`atomic`]-typen via de `fetch_add`-methode door [`Ordering::Relaxed`] door te geven als de `order`.
    /// Bijvoorbeeld, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Trek af van de huidige waarde en retourneer de vorige waarde.
    ///
    /// De gestabiliseerde versie van deze intrinsieke versie is beschikbaar op de [`atomic`]-typen via de `fetch_sub`-methode door [`Ordering::SeqCst`] door te geven als de `order`.
    /// Bijvoorbeeld, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub<T: Copy>(dst: *mut T, src: T) -> T;
    /// Trek af van de huidige waarde en retourneer de vorige waarde.
    ///
    /// De gestabiliseerde versie van deze intrinsieke versie is beschikbaar op de [`atomic`]-typen via de `fetch_sub`-methode door [`Ordering::Acquire`] door te geven als de `order`.
    /// Bijvoorbeeld, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Trek af van de huidige waarde en retourneer de vorige waarde.
    ///
    /// De gestabiliseerde versie van deze intrinsieke versie is beschikbaar op de [`atomic`]-typen via de `fetch_sub`-methode door [`Ordering::Release`] door te geven als de `order`.
    /// Bijvoorbeeld, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Trek af van de huidige waarde en retourneer de vorige waarde.
    ///
    /// De gestabiliseerde versie van deze intrinsieke versie is beschikbaar op de [`atomic`]-typen via de `fetch_sub`-methode door [`Ordering::AcqRel`] door te geven als de `order`.
    /// Bijvoorbeeld, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Trek af van de huidige waarde en retourneer de vorige waarde.
    ///
    /// De gestabiliseerde versie van deze intrinsieke versie is beschikbaar op de [`atomic`]-typen via de `fetch_sub`-methode door [`Ordering::Relaxed`] door te geven als de `order`.
    /// Bijvoorbeeld, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitsgewijs en met de huidige waarde, waarbij de vorige waarde wordt geretourneerd.
    ///
    /// De gestabiliseerde versie van deze intrinsieke versie is beschikbaar op de [`atomic`]-typen via de `fetch_and`-methode door [`Ordering::SeqCst`] door te geven als de `order`.
    /// Bijvoorbeeld, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitsgewijs en met de huidige waarde, waarbij de vorige waarde wordt geretourneerd.
    ///
    /// De gestabiliseerde versie van deze intrinsieke versie is beschikbaar op de [`atomic`]-typen via de `fetch_and`-methode door [`Ordering::Acquire`] door te geven als de `order`.
    /// Bijvoorbeeld, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitsgewijs en met de huidige waarde, waarbij de vorige waarde wordt geretourneerd.
    ///
    /// De gestabiliseerde versie van deze intrinsieke versie is beschikbaar op de [`atomic`]-typen via de `fetch_and`-methode door [`Ordering::Release`] door te geven als de `order`.
    /// Bijvoorbeeld, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitsgewijs en met de huidige waarde, waarbij de vorige waarde wordt geretourneerd.
    ///
    /// De gestabiliseerde versie van deze intrinsieke versie is beschikbaar op de [`atomic`]-typen via de `fetch_and`-methode door [`Ordering::AcqRel`] door te geven als de `order`.
    /// Bijvoorbeeld, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitsgewijs en met de huidige waarde, waarbij de vorige waarde wordt geretourneerd.
    ///
    /// De gestabiliseerde versie van deze intrinsieke versie is beschikbaar op de [`atomic`]-typen via de `fetch_and`-methode door [`Ordering::Relaxed`] door te geven als de `order`.
    /// Bijvoorbeeld, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitsgewijs nen met de huidige waarde, waarbij de vorige waarde wordt geretourneerd.
    ///
    /// De gestabiliseerde versie van deze intrinsieke versie is beschikbaar op het [`AtomicBool`]-type via de `fetch_nand`-methode door [`Ordering::SeqCst`] door te geven als de `order`.
    /// Bijvoorbeeld, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitsgewijs nen met de huidige waarde, waarbij de vorige waarde wordt geretourneerd.
    ///
    /// De gestabiliseerde versie van deze intrinsieke versie is beschikbaar op het [`AtomicBool`]-type via de `fetch_nand`-methode door [`Ordering::Acquire`] door te geven als de `order`.
    /// Bijvoorbeeld, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitsgewijs nen met de huidige waarde, waarbij de vorige waarde wordt geretourneerd.
    ///
    /// De gestabiliseerde versie van deze intrinsieke versie is beschikbaar op het [`AtomicBool`]-type via de `fetch_nand`-methode door [`Ordering::Release`] door te geven als de `order`.
    /// Bijvoorbeeld, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitsgewijs nen met de huidige waarde, waarbij de vorige waarde wordt geretourneerd.
    ///
    /// De gestabiliseerde versie van deze intrinsieke versie is beschikbaar op het [`AtomicBool`]-type via de `fetch_nand`-methode door [`Ordering::AcqRel`] door te geven als de `order`.
    /// Bijvoorbeeld, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitsgewijs nen met de huidige waarde, waarbij de vorige waarde wordt geretourneerd.
    ///
    /// De gestabiliseerde versie van deze intrinsieke versie is beschikbaar op het [`AtomicBool`]-type via de `fetch_nand`-methode door [`Ordering::Relaxed`] door te geven als de `order`.
    /// Bijvoorbeeld, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitsgewijs of met de huidige waarde, waarbij de vorige waarde wordt geretourneerd.
    ///
    /// De gestabiliseerde versie van deze intrinsieke versie is beschikbaar op de [`atomic`]-typen via de `fetch_or`-methode door [`Ordering::SeqCst`] door te geven als de `order`.
    /// Bijvoorbeeld, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitsgewijs of met de huidige waarde, waarbij de vorige waarde wordt geretourneerd.
    ///
    /// De gestabiliseerde versie van deze intrinsieke versie is beschikbaar op de [`atomic`]-typen via de `fetch_or`-methode door [`Ordering::Acquire`] door te geven als de `order`.
    /// Bijvoorbeeld, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitsgewijs of met de huidige waarde, waarbij de vorige waarde wordt geretourneerd.
    ///
    /// De gestabiliseerde versie van deze intrinsieke versie is beschikbaar op de [`atomic`]-typen via de `fetch_or`-methode door [`Ordering::Release`] door te geven als de `order`.
    /// Bijvoorbeeld, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitsgewijs of met de huidige waarde, waarbij de vorige waarde wordt geretourneerd.
    ///
    /// De gestabiliseerde versie van deze intrinsieke versie is beschikbaar op de [`atomic`]-typen via de `fetch_or`-methode door [`Ordering::AcqRel`] door te geven als de `order`.
    /// Bijvoorbeeld, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitsgewijs of met de huidige waarde, waarbij de vorige waarde wordt geretourneerd.
    ///
    /// De gestabiliseerde versie van deze intrinsieke versie is beschikbaar op de [`atomic`]-typen via de `fetch_or`-methode door [`Ordering::Relaxed`] door te geven als de `order`.
    /// Bijvoorbeeld, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitsgewijze xor met de huidige waarde, waarbij de vorige waarde wordt geretourneerd.
    ///
    /// De gestabiliseerde versie van deze intrinsieke versie is beschikbaar op de [`atomic`]-typen via de `fetch_xor`-methode door [`Ordering::SeqCst`] door te geven als de `order`.
    /// Bijvoorbeeld, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitsgewijze xor met de huidige waarde, waarbij de vorige waarde wordt geretourneerd.
    ///
    /// De gestabiliseerde versie van deze intrinsieke versie is beschikbaar op de [`atomic`]-typen via de `fetch_xor`-methode door [`Ordering::Acquire`] door te geven als de `order`.
    /// Bijvoorbeeld, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitsgewijze xor met de huidige waarde, waarbij de vorige waarde wordt geretourneerd.
    ///
    /// De gestabiliseerde versie van deze intrinsieke versie is beschikbaar op de [`atomic`]-typen via de `fetch_xor`-methode door [`Ordering::Release`] door te geven als de `order`.
    /// Bijvoorbeeld, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitsgewijze xor met de huidige waarde, waarbij de vorige waarde wordt geretourneerd.
    ///
    /// De gestabiliseerde versie van deze intrinsieke versie is beschikbaar op de [`atomic`]-typen via de `fetch_xor`-methode door [`Ordering::AcqRel`] door te geven als de `order`.
    /// Bijvoorbeeld, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitsgewijze xor met de huidige waarde, waarbij de vorige waarde wordt geretourneerd.
    ///
    /// De gestabiliseerde versie van deze intrinsieke versie is beschikbaar op de [`atomic`]-typen via de `fetch_xor`-methode door [`Ordering::Relaxed`] door te geven als de `order`.
    /// Bijvoorbeeld, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Maximaal met de huidige waarde met behulp van een ondertekende vergelijking.
    ///
    /// De gestabiliseerde versie van deze intrinsieke versie is beschikbaar op de [`atomic`]-ondertekende integer-typen via de `fetch_max`-methode door [`Ordering::SeqCst`] door te geven als de `order`.
    /// Bijvoorbeeld, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maximaal met de huidige waarde met behulp van een ondertekende vergelijking.
    ///
    /// De gestabiliseerde versie van deze intrinsieke versie is beschikbaar op de [`atomic`]-ondertekende integer-typen via de `fetch_max`-methode door [`Ordering::Acquire`] door te geven als de `order`.
    /// Bijvoorbeeld, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maximaal met de huidige waarde met behulp van een ondertekende vergelijking.
    ///
    /// De gestabiliseerde versie van deze intrinsieke versie is beschikbaar op de [`atomic`]-ondertekende integer-typen via de `fetch_max`-methode door [`Ordering::Release`] door te geven als de `order`.
    /// Bijvoorbeeld, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maximaal met de huidige waarde met behulp van een ondertekende vergelijking.
    ///
    /// De gestabiliseerde versie van deze intrinsieke versie is beschikbaar op de [`atomic`]-ondertekende integer-typen via de `fetch_max`-methode door [`Ordering::AcqRel`] door te geven als de `order`.
    /// Bijvoorbeeld, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maximaal met de huidige waarde.
    ///
    /// De gestabiliseerde versie van deze intrinsieke versie is beschikbaar op de [`atomic`]-ondertekende integer-typen via de `fetch_max`-methode door [`Ordering::Relaxed`] door te geven als de `order`.
    /// Bijvoorbeeld, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Minimum met de huidige waarde met behulp van een ondertekende vergelijking.
    ///
    /// De gestabiliseerde versie van deze intrinsieke versie is beschikbaar op de [`atomic`]-ondertekende integer-typen via de `fetch_min`-methode door [`Ordering::SeqCst`] door te geven als de `order`.
    /// Bijvoorbeeld, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum met de huidige waarde met behulp van een ondertekende vergelijking.
    ///
    /// De gestabiliseerde versie van deze intrinsieke versie is beschikbaar op de [`atomic`]-ondertekende integer-typen via de `fetch_min`-methode door [`Ordering::Acquire`] door te geven als de `order`.
    /// Bijvoorbeeld, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum met de huidige waarde met behulp van een ondertekende vergelijking.
    ///
    /// De gestabiliseerde versie van deze intrinsieke versie is beschikbaar op de [`atomic`]-ondertekende integer-typen via de `fetch_min`-methode door [`Ordering::Release`] door te geven als de `order`.
    /// Bijvoorbeeld, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum met de huidige waarde met behulp van een ondertekende vergelijking.
    ///
    /// De gestabiliseerde versie van deze intrinsieke versie is beschikbaar op de [`atomic`]-ondertekende integer-typen via de `fetch_min`-methode door [`Ordering::AcqRel`] door te geven als de `order`.
    /// Bijvoorbeeld, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum met de huidige waarde met behulp van een ondertekende vergelijking.
    ///
    /// De gestabiliseerde versie van deze intrinsieke versie is beschikbaar op de [`atomic`]-ondertekende integer-typen via de `fetch_min`-methode door [`Ordering::Relaxed`] door te geven als de `order`.
    /// Bijvoorbeeld, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Minimum met de huidige waarde met behulp van een niet-ondertekende vergelijking.
    ///
    /// De gestabiliseerde versie van deze intrinsieke versie is beschikbaar op de [`atomic`] niet-ondertekende integer-typen via de `fetch_min`-methode door [`Ordering::SeqCst`] door te geven als de `order`.
    /// Bijvoorbeeld, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum met de huidige waarde met behulp van een niet-ondertekende vergelijking.
    ///
    /// De gestabiliseerde versie van deze intrinsieke versie is beschikbaar op de [`atomic`] niet-ondertekende integer-typen via de `fetch_min`-methode door [`Ordering::Acquire`] door te geven als de `order`.
    /// Bijvoorbeeld, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum met de huidige waarde met behulp van een niet-ondertekende vergelijking.
    ///
    /// De gestabiliseerde versie van deze intrinsieke versie is beschikbaar op de [`atomic`] niet-ondertekende integer-typen via de `fetch_min`-methode door [`Ordering::Release`] door te geven als de `order`.
    /// Bijvoorbeeld, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum met de huidige waarde met behulp van een niet-ondertekende vergelijking.
    ///
    /// De gestabiliseerde versie van deze intrinsieke versie is beschikbaar op de [`atomic`] niet-ondertekende integer-typen via de `fetch_min`-methode door [`Ordering::AcqRel`] door te geven als de `order`.
    /// Bijvoorbeeld, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum met de huidige waarde met behulp van een niet-ondertekende vergelijking.
    ///
    /// De gestabiliseerde versie van deze intrinsieke versie is beschikbaar op de [`atomic`] niet-ondertekende integer-typen via de `fetch_min`-methode door [`Ordering::Relaxed`] door te geven als de `order`.
    /// Bijvoorbeeld, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Maximaal met de huidige waarde met behulp van een niet-ondertekende vergelijking.
    ///
    /// De gestabiliseerde versie van deze intrinsieke versie is beschikbaar op de [`atomic`] niet-ondertekende integer-typen via de `fetch_max`-methode door [`Ordering::SeqCst`] door te geven als de `order`.
    /// Bijvoorbeeld, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maximaal met de huidige waarde met behulp van een niet-ondertekende vergelijking.
    ///
    /// De gestabiliseerde versie van deze intrinsieke versie is beschikbaar op de [`atomic`] niet-ondertekende integer-typen via de `fetch_max`-methode door [`Ordering::Acquire`] door te geven als de `order`.
    /// Bijvoorbeeld, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maximaal met de huidige waarde met behulp van een niet-ondertekende vergelijking.
    ///
    /// De gestabiliseerde versie van deze intrinsieke versie is beschikbaar op de [`atomic`] niet-ondertekende integer-typen via de `fetch_max`-methode door [`Ordering::Release`] door te geven als de `order`.
    /// Bijvoorbeeld, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maximaal met de huidige waarde met behulp van een niet-ondertekende vergelijking.
    ///
    /// De gestabiliseerde versie van deze intrinsieke versie is beschikbaar op de [`atomic`] niet-ondertekende integer-typen via de `fetch_max`-methode door [`Ordering::AcqRel`] door te geven als de `order`.
    /// Bijvoorbeeld, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maximaal met de huidige waarde met behulp van een niet-ondertekende vergelijking.
    ///
    /// De gestabiliseerde versie van deze intrinsieke versie is beschikbaar op de [`atomic`] niet-ondertekende integer-typen via de `fetch_max`-methode door [`Ordering::Relaxed`] door te geven als de `order`.
    /// Bijvoorbeeld, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// De intrinsieke `prefetch` is een hint voor de codegenerator om een prefetch-instructie in te voegen, indien ondersteund;anders is het een no-op.
    /// Prefetches hebben geen effect op het gedrag van het programma, maar kunnen de prestatiekenmerken ervan veranderen.
    ///
    /// Het `locality`-argument moet een constant geheel getal zijn en is een temporele localiteitsspecificatie die loopt van (0), geen localiteit, tot (3), extreem lokaal in cache bewaren.
    ///
    ///
    /// Deze intrinsieke heeft geen stabiele tegenhanger.
    ///
    ///
    pub fn prefetch_read_data<T>(data: *const T, locality: i32);
    /// De intrinsieke `prefetch` is een hint voor de codegenerator om een prefetch-instructie in te voegen, indien ondersteund;anders is het een no-op.
    /// Prefetches hebben geen effect op het gedrag van het programma, maar kunnen de prestatiekenmerken ervan veranderen.
    ///
    /// Het `locality`-argument moet een constant geheel getal zijn en is een temporele localiteitsspecificatie die loopt van (0), geen localiteit, tot (3), extreem lokaal in cache bewaren.
    ///
    ///
    /// Deze intrinsieke heeft geen stabiele tegenhanger.
    ///
    ///
    pub fn prefetch_write_data<T>(data: *const T, locality: i32);
    /// De intrinsieke `prefetch` is een hint voor de codegenerator om een prefetch-instructie in te voegen, indien ondersteund;anders is het een no-op.
    /// Prefetches hebben geen effect op het gedrag van het programma, maar kunnen de prestatiekenmerken ervan veranderen.
    ///
    /// Het `locality`-argument moet een constant geheel getal zijn en is een temporele localiteitsspecificatie die loopt van (0), geen localiteit, tot (3), extreem lokaal in cache bewaren.
    ///
    ///
    /// Deze intrinsieke heeft geen stabiele tegenhanger.
    ///
    ///
    pub fn prefetch_read_instruction<T>(data: *const T, locality: i32);
    /// De intrinsieke `prefetch` is een hint voor de codegenerator om een prefetch-instructie in te voegen, indien ondersteund;anders is het een no-op.
    /// Prefetches hebben geen effect op het gedrag van het programma, maar kunnen de prestatiekenmerken ervan veranderen.
    ///
    /// Het `locality`-argument moet een constant geheel getal zijn en is een temporele localiteitsspecificatie die loopt van (0), geen localiteit, tot (3), extreem lokaal in cache bewaren.
    ///
    ///
    /// Deze intrinsieke heeft geen stabiele tegenhanger.
    ///
    ///
    pub fn prefetch_write_instruction<T>(data: *const T, locality: i32);
}

extern "rust-intrinsic" {
    /// Een atoomomheining.
    ///
    /// De gestabiliseerde versie van deze intrinsieke versie is beschikbaar in [`atomic::fence`] door [`Ordering::SeqCst`] door te geven als de `order`.
    ///
    ///
    pub fn atomic_fence();
    /// Een atoomomheining.
    ///
    /// De gestabiliseerde versie van deze intrinsieke versie is beschikbaar in [`atomic::fence`] door [`Ordering::Acquire`] door te geven als de `order`.
    ///
    ///
    pub fn atomic_fence_acq();
    /// Een atoomomheining.
    ///
    /// De gestabiliseerde versie van deze intrinsieke versie is beschikbaar in [`atomic::fence`] door [`Ordering::Release`] door te geven als de `order`.
    ///
    ///
    pub fn atomic_fence_rel();
    /// Een atoomomheining.
    ///
    /// De gestabiliseerde versie van deze intrinsieke versie is beschikbaar in [`atomic::fence`] door [`Ordering::AcqRel`] door te geven als de `order`.
    ///
    ///
    pub fn atomic_fence_acqrel();

    /// Een geheugenbarrière voor alleen compilers.
    ///
    /// Geheugentoegang wordt door de compiler nooit opnieuw geordend over deze barrière, maar er worden geen instructies voor verzonden.
    /// Dit is geschikt voor bewerkingen op dezelfde thread die kunnen worden onderdrukt, zoals bij interactie met signaalbehandelaars.
    ///
    /// De gestabiliseerde versie van deze intrinsieke versie is beschikbaar in [`atomic::compiler_fence`] door [`Ordering::SeqCst`] door te geven als de `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence();
    /// Een geheugenbarrière voor alleen compilers.
    ///
    /// Geheugentoegang wordt door de compiler nooit opnieuw geordend over deze barrière, maar er worden geen instructies voor verzonden.
    /// Dit is geschikt voor bewerkingen op dezelfde thread die kunnen worden onderdrukt, zoals bij interactie met signaalbehandelaars.
    ///
    /// De gestabiliseerde versie van deze intrinsieke versie is beschikbaar in [`atomic::compiler_fence`] door [`Ordering::Acquire`] door te geven als de `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acq();
    /// Een geheugenbarrière voor alleen compilers.
    ///
    /// Geheugentoegang wordt door de compiler nooit opnieuw geordend over deze barrière, maar er worden geen instructies voor verzonden.
    /// Dit is geschikt voor bewerkingen op dezelfde thread die kunnen worden onderdrukt, zoals bij interactie met signaalbehandelaars.
    ///
    /// De gestabiliseerde versie van deze intrinsieke versie is beschikbaar in [`atomic::compiler_fence`] door [`Ordering::Release`] door te geven als de `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_rel();
    /// Een geheugenbarrière voor alleen compilers.
    ///
    /// Geheugentoegang wordt door de compiler nooit opnieuw geordend over deze barrière, maar er worden geen instructies voor verzonden.
    /// Dit is geschikt voor bewerkingen op dezelfde thread die kunnen worden onderdrukt, zoals bij interactie met signaalbehandelaars.
    ///
    /// De gestabiliseerde versie van deze intrinsieke versie is beschikbaar in [`atomic::compiler_fence`] door [`Ordering::AcqRel`] door te geven als de `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acqrel();

    /// Magie intrinsiek die zijn betekenis ontleent aan attributen die aan de functie zijn gekoppeld.
    ///
    /// Dataflow gebruikt dit bijvoorbeeld om statische beweringen te injecteren, zodat `rustc_peek(potentially_uninitialized)` daadwerkelijk dubbel controleert of dataflow inderdaad heeft berekend dat deze niet is geïnitialiseerd op dat punt in de controlestroom.
    ///
    ///
    /// Deze intrinsieke code mag niet buiten de compiler worden gebruikt.
    ///
    ///
    ///
    pub fn rustc_peek<T>(_: T) -> T;

    /// Breekt de uitvoering van het proces af.
    ///
    /// Een gebruiksvriendelijkere en stabielere versie van deze bewerking is [`std::process::abort`](../../std/process/fn.abort.html).
    ///
    pub fn abort() -> !;

    /// Informeert de optimizer dat dit punt in de code niet bereikbaar is, waardoor verdere optimalisaties mogelijk zijn.
    ///
    /// NB, dit is heel anders dan de `unreachable!()`-macro: In tegenstelling tot de macro, die panics uitvoert wanneer deze wordt uitgevoerd, is het *ongedefinieerd gedrag* om code te bereiken die met deze functie is gemarkeerd.
    ///
    ///
    /// De gestabiliseerde versie van deze intrinsieke is [`core::hint::unreachable_unchecked`](crate::hint::unreachable_unchecked).
    ///
    ///
    #[rustc_const_unstable(feature = "const_unreachable_unchecked", issue = "53188")]
    pub fn unreachable() -> !;

    /// Informeert de optimizer dat een voorwaarde altijd waar is.
    /// Als de voorwaarde onwaar is, is het gedrag niet gedefinieerd.
    ///
    /// Er wordt geen code gegenereerd voor deze intrinsieke code, maar de optimizer zal proberen deze (en de staat) tussen de passages te behouden, wat de optimalisatie van de omringende code kan verstoren en de prestaties kan verminderen.
    /// Het mag niet worden gebruikt als de invariant zelf door de optimizer kan worden ontdekt, of als het geen significante optimalisaties mogelijk maakt.
    ///
    /// Deze intrinsieke heeft geen stabiele tegenhanger.
    ///
    ///
    ///
    #[rustc_const_unstable(feature = "const_assume", issue = "76972")]
    pub fn assume(b: bool);

    /// Hints voor de compiler dat de voorwaarde branch waarschijnlijk waar is.
    /// Retourneert de waarde die eraan is doorgegeven.
    ///
    /// Elk ander gebruik dan met `if`-statements zal waarschijnlijk geen effect hebben.
    ///
    /// Deze intrinsieke heeft geen stabiele tegenhanger.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn likely(b: bool) -> bool;

    /// Hints voor de compiler dat de voorwaarde branch waarschijnlijk onwaar is.
    /// Retourneert de waarde die eraan is doorgegeven.
    ///
    /// Elk ander gebruik dan met `if`-statements zal waarschijnlijk geen effect hebben.
    ///
    /// Deze intrinsieke heeft geen stabiele tegenhanger.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn unlikely(b: bool) -> bool;

    /// Voert een breakpoint-trap uit, voor inspectie door een debugger.
    ///
    /// Deze intrinsieke heeft geen stabiele tegenhanger.
    pub fn breakpoint();

    /// De grootte van een type in bytes.
    ///
    /// Meer specifiek is dit de offset in bytes tussen opeenvolgende items van hetzelfde type, inclusief uitlijningsvulling.
    ///
    ///
    /// De gestabiliseerde versie van deze intrinsieke is [`core::mem::size_of`](crate::mem::size_of).
    #[rustc_const_stable(feature = "const_size_of", since = "1.40.0")]
    pub fn size_of<T>() -> usize;

    /// De minimale uitlijning van een type.
    ///
    /// De gestabiliseerde versie van deze intrinsieke versie is [`core::mem::align_of`](crate::mem::align_of).
    #[rustc_const_stable(feature = "const_min_align_of", since = "1.40.0")]
    pub fn min_align_of<T>() -> usize;
    /// De voorkeursuitlijning van een type.
    ///
    /// Deze intrinsieke heeft geen stabiele tegenhanger.
    #[rustc_const_unstable(feature = "const_pref_align_of", issue = "none")]
    pub fn pref_align_of<T>() -> usize;

    /// De grootte van de waarde waarnaar wordt verwezen in bytes.
    ///
    /// De gestabiliseerde versie van deze intrinsieke is [`mem::size_of_val`].
    #[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
    pub fn size_of_val<T: ?Sized>(_: *const T) -> usize;
    /// De vereiste uitlijning van de waarde waarnaar wordt verwezen.
    ///
    /// De gestabiliseerde versie van deze intrinsieke is [`core::mem::align_of_val`](crate::mem::align_of_val).
    #[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
    pub fn min_align_of_val<T: ?Sized>(_: *const T) -> usize;

    /// Haalt een statisch string-segment op dat de naam van een type bevat.
    ///
    /// De gestabiliseerde versie van deze intrinsieke versie is [`core::any::type_name`](crate::any::type_name).
    #[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
    pub fn type_name<T: ?Sized>() -> &'static str;

    /// Haalt een identificatie op die globaal uniek is voor het opgegeven type.
    /// Deze functie retourneert dezelfde waarde voor een type, ongeacht de crate waarin het wordt aangeroepen.
    ///
    ///
    /// De gestabiliseerde versie van deze intrinsieke is [`core::any::TypeId::of`](crate::any::TypeId::of).
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub fn type_id<T: ?Sized + 'static>() -> u64;

    /// Een bewaker voor onveilige functies die nooit kunnen worden uitgevoerd als `T` onbewoond is:
    /// Dit zal statisch panic zijn, of niets doen.
    ///
    /// Deze intrinsieke heeft geen stabiele tegenhanger.
    #[rustc_const_unstable(feature = "const_assert_type", issue = "none")]
    pub fn assert_inhabited<T>();

    /// Een bewaker voor onveilige functies die nooit kunnen worden uitgevoerd als `T` geen nulinitialisatie toestaat: dit zal statisch panic doen of niets doen.
    ///
    ///
    /// Deze intrinsieke heeft geen stabiele tegenhanger.
    pub fn assert_zero_valid<T>();

    /// Een bewaker voor onveilige functies die nooit kunnen worden uitgevoerd als `T` ongeldige bitpatronen heeft: dit zal statisch panic zijn of niets doen.
    ///
    ///
    /// Deze intrinsieke heeft geen stabiele tegenhanger.
    pub fn assert_uninit_valid<T>();

    /// Krijgt een verwijzing naar een statische `Location` die aangeeft waar deze werd aangeroepen.
    ///
    /// Overweeg om in plaats daarvan [`core::panic::Location::caller`](crate::panic::Location::caller) te gebruiken.
    #[rustc_const_unstable(feature = "const_caller_location", issue = "76156")]
    pub fn caller_location() -> &'static crate::panic::Location<'static>;

    /// Verplaatst een waarde buiten het bereik zonder druppellijm te laten lopen.
    ///
    /// Dit bestaat alleen voor [`mem::forget_unsized`];normale `forget` gebruikt in plaats daarvan `ManuallyDrop`.
    ///
    #[rustc_const_unstable(feature = "const_intrinsic_forget", issue = "none")]
    pub fn forget<T: ?Sized>(_: T);

    /// Herinterpreteert de bits van een waarde van het ene type als een ander type.
    ///
    /// Beide typen moeten dezelfde maat hebben.
    /// Noch het origineel, noch het resultaat mag een [invalid value](../../nomicon/what-unsafe-does.html) zijn.
    ///
    /// `transmute` is semantisch equivalent aan een bitsgewijze verplaatsing van het ene type naar het andere.Het kopieert de bits van de bronwaarde naar de bestemmingswaarde en vergeet vervolgens het origineel.
    /// Het is gelijk aan C's `memcpy` onder de motorkap, net als `transmute_copy`.
    ///
    /// Omdat `transmute` een bewerking op basis van waarde is, is het uitlijnen van de *getransmuteerde waarden zelf* geen probleem.
    /// Net als bij elke andere functie, zorgt de compiler er al voor dat zowel `T` als `U` correct zijn uitgelijnd.
    /// Bij het transmuteren van waarden die *ergens anders* wijzen (zoals aanwijzers, verwijzingen, kaders…), moet de beller ervoor zorgen dat de waarden waarnaar wordt verwezen correct zijn uitgelijnd.
    ///
    /// `transmute` is **ongelooflijk** onveilig.Er zijn een groot aantal manieren om [undefined behavior][ub] met deze functie te veroorzaken.`transmute` zou het absolute laatste redmiddel moeten zijn.
    ///
    /// De [nomicon](../../nomicon/transmutes.html) heeft aanvullende documentatie.
    ///
    /// [ub]: ../../reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// Er zijn een paar dingen waar `transmute` erg handig voor is.
    ///
    /// Een aanwijzer in een functie-aanwijzer veranderen.Dit is *niet* overdraagbaar naar machines waar functiewijzers en gegevensaanwijzers verschillende grootten hebben.
    ///
    /// ```
    /// fn foo() -> i32 {
    ///     0
    /// }
    /// let pointer = foo as *const ();
    /// let function = unsafe {
    ///     std::mem::transmute::<*const (), fn() -> i32>(pointer)
    /// };
    /// assert_eq!(function(), 0);
    /// ```
    ///
    /// Een leven verlengen of een onveranderlijk leven verkorten.Dit is geavanceerde, zeer onveilige Rust!
    ///
    /// ```
    /// struct R<'a>(&'a i32);
    /// unsafe fn extend_lifetime<'b>(r: R<'b>) -> R<'static> {
    ///     std::mem::transmute::<R<'b>, R<'static>>(r)
    /// }
    ///
    /// unsafe fn shorten_invariant_lifetime<'b, 'c>(r: &'b mut R<'static>)
    ///                                              -> &'b mut R<'c> {
    ///     std::mem::transmute::<&'b mut R<'static>, &'b mut R<'c>>(r)
    /// }
    /// ```
    ///
    /// # Alternatives
    ///
    /// Wanhoop niet: veel toepassingen van `transmute` kunnen op andere manieren worden bereikt.
    /// Hieronder staan veelvoorkomende toepassingen van `transmute` die kunnen worden vervangen door veiligere constructies.
    ///
    /// Onbewerkte bytes(`&[u8]`) omzetten in `u32`, `f64`, enz .:
    ///
    /// ```
    /// let raw_bytes = [0x78, 0x56, 0x34, 0x12];
    ///
    /// let num = unsafe {
    ///     std::mem::transmute::<[u8; 4], u32>(raw_bytes)
    /// };
    ///
    /// // gebruik in plaats daarvan `u32::from_ne_bytes`
    /// let num = u32::from_ne_bytes(raw_bytes);
    /// // of gebruik `u32::from_le_bytes` of `u32::from_be_bytes` om de endianness te specificeren
    /// let num = u32::from_le_bytes(raw_bytes);
    /// assert_eq!(num, 0x12345678);
    /// let num = u32::from_be_bytes(raw_bytes);
    /// assert_eq!(num, 0x78563412);
    /// ```
    ///
    /// Een aanwijzer in een `usize` veranderen:
    ///
    /// ```
    /// let ptr = &0;
    /// let ptr_num_transmute = unsafe {
    ///     std::mem::transmute::<&i32, usize>(ptr)
    /// };
    ///
    /// // Gebruik in plaats daarvan een `as`-cast
    /// let ptr_num_cast = ptr as *const i32 as usize;
    /// ```
    ///
    /// Een `*mut T` in een `&mut T` veranderen:
    ///
    /// ```
    /// let ptr: *mut i32 = &mut 0;
    /// let ref_transmuted = unsafe {
    ///     std::mem::transmute::<*mut i32, &mut i32>(ptr)
    /// };
    ///
    /// // Gebruik in plaats daarvan een reborrow
    /// let ref_casted = unsafe { &mut *ptr };
    /// ```
    ///
    /// Een `&mut T` in een `&mut U` veranderen:
    ///
    /// ```
    /// let ptr = &mut 0;
    /// let val_transmuted = unsafe {
    ///     std::mem::transmute::<&mut i32, &mut u32>(ptr)
    /// };
    ///
    /// // Stel nu `as` en reborrowing samen, merk op dat de chaining van `as` `as` niet transitief is
    /////
    /// let val_casts = unsafe { &mut *(ptr as *mut i32 as *mut u32) };
    /// ```
    ///
    /// Een `&str` in een `&[u8]` veranderen:
    ///
    /// ```
    /// // dit is geen goede manier om dit te doen.
    /// let slice = unsafe { std::mem::transmute::<&str, &[u8]>("Rust") };
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // Je zou `str::as_bytes` kunnen gebruiken
    /// let slice = "Rust".as_bytes();
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // Of gebruik gewoon een bytetekenreeks, als u controle heeft over de letterlijke tekenreeks
    /////
    /// assert_eq!(b"Rust", &[82, 117, 115, 116]);
    /// ```
    ///
    /// Een `Vec<&T>` in een `Vec<Option<&T>>` veranderen.
    ///
    /// Om het binnentype van de inhoud van een container te transmuteren, moet u ervoor zorgen dat u geen van de invarianten van de container schendt.
    /// Voor `Vec` betekent dit dat zowel de grootte *als de uitlijning* van de binnenste typen moeten overeenkomen.
    /// Andere containers kunnen afhankelijk zijn van de grootte van het type, de uitlijning of zelfs de `TypeId`, in welk geval transmuteren helemaal niet mogelijk zou zijn zonder de container-invarianten te schenden.
    ///
    ///
    /// ```
    /// let store = [0, 1, 2, 3];
    /// let v_orig = store.iter().collect::<Vec<&i32>>();
    ///
    /// // kloon de vector, want we zullen ze later opnieuw gebruiken
    /// let v_clone = v_orig.clone();
    ///
    /// // Transmute gebruiken: dit is afhankelijk van de niet-gespecificeerde datalay-out van `Vec`, wat een slecht idee is en ongedefinieerd gedrag kan veroorzaken.
    /////
    /// // Het is echter geen kopie.
    /// let v_transmuted = unsafe {
    ///     std::mem::transmute::<Vec<&i32>, Vec<Option<&i32>>>(v_clone)
    /// };
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // Dit is de aanbevolen, veilige manier.
    /// // Het kopieert echter de volledige vector naar een nieuwe array.
    /// let v_collected = v_clone.into_iter()
    ///                          .map(Some)
    ///                          .collect::<Vec<Option<&i32>>>();
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // Dit is de juiste niet-kopiëren, onveilige manier van "transmuting" a `Vec`, zonder te vertrouwen op de datalay-out.
    /// // In plaats van `transmute` letterlijk aan te roepen, voeren we een pointer cast uit, maar wat betreft het converteren van het originele innerlijke type (`&i32`) naar de nieuwe (`Option<&i32>`), heeft dit allemaal dezelfde voorbehouden.
    /////
    /// // Raadpleeg naast de bovenstaande informatie ook de [`from_raw_parts`]-documentatie.
    /////
    /// let v_from_raw = unsafe {
    ///     // FIXME Update dit wanneer vec_into_raw_parts gestabiliseerd is.
    ///     // Zorg ervoor dat de originele vector niet valt.
    ///     let mut v_clone = std::mem::ManuallyDrop::new(v_clone);
    ///     Vec::from_raw_parts(v_clone.as_mut_ptr() as *mut Option<&i32>,
    ///                         v_clone.len(),
    ///                         v_clone.capacity())
    /// };
    /// ```
    ///
    /// [`from_raw_parts`]: ../../std/vec/struct.Vec.html#method.from_raw_parts
    ///
    /// `split_at_mut` implementeren:
    ///
    /// ```
    /// use std::{slice, mem};
    ///
    /// // Er zijn meerdere manieren om dit te doen, en er zijn meerdere problemen met de volgende (transmute)-manier.
    /////
    /// fn split_at_mut_transmute<T>(slice: &mut [T], mid: usize)
    ///                              -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = mem::transmute::<&mut [T], &mut [T]>(slice);
    ///         // ten eerste: transmuteren is niet type veilig;het controleert alleen of T en
    ///         // U heeft dezelfde maat.
    ///         // Ten tweede, hier heb je twee veranderlijke verwijzingen die naar hetzelfde geheugen verwijzen.
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // Dit lost de typeveiligheidsproblemen op;`&mut *` geeft u* alleen *een `&mut T` vanaf een `&mut T` of `* mut T`.
    /////
    /// fn split_at_mut_casts<T>(slice: &mut [T], mid: usize)
    ///                          -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = &mut *(slice as *mut [T]);
    ///         // je hebt echter nog steeds twee veranderlijke verwijzingen die naar hetzelfde geheugen verwijzen.
    /////
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // Dit is hoe de standaardbibliotheek het doet.
    /// // Dit is de beste methode als u zoiets als dit moet doen
    /// fn split_at_stdlib<T>(slice: &mut [T], mid: usize)
    ///                       -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let ptr = slice.as_mut_ptr();
    ///         // Dit heeft nu drie veranderlijke verwijzingen die naar hetzelfde geheugen wijzen.`slice`, de rvalue ret.0 en de rvalue ret.1.
    ///         // `slice` wordt nooit gebruikt na `let ptr = ...`, en dus kan men het behandelen als "dead", en daarom heb je maar twee echte veranderlijke plakjes.
    /////
    /////
    /////
    ///         (slice::from_raw_parts_mut(ptr, mid),
    ///          slice::from_raw_parts_mut(ptr.add(mid), len - mid))
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    // NOTE: Hoewel dit de intrinsieke const stabiel maakt, hebben we een aantal aangepaste code in const fn
    // controles die het gebruik ervan binnen `const fn` verhinderen.
    #[rustc_const_stable(feature = "const_transmute", since = "1.46.0")]
    #[rustc_diagnostic_item = "transmute"]
    pub fn transmute<T, U>(e: T) -> U;

    /// Geeft `true` terug als het werkelijke type gegeven als `T` druppellijm vereist;geeft `false` terug als het werkelijke type dat voor `T` is opgegeven, `Copy` implementeert.
    ///
    ///
    /// Als het werkelijke type geen droplijm vereist of `Copy` implementeert, is de geretourneerde waarde van deze functie niet gespecificeerd.
    ///
    /// De gestabiliseerde versie van deze intrinsieke is [`mem::needs_drop`](crate::mem::needs_drop).
    ///
    ///
    #[rustc_const_stable(feature = "const_needs_drop", since = "1.40.0")]
    pub fn needs_drop<T>() -> bool;

    /// Berekent de offset van een aanwijzer.
    ///
    /// Dit is intrinsiek geïmplementeerd om conversie naar en van een geheel getal te voorkomen, aangezien de conversie aliasing-informatie zou weggooien.
    ///
    /// # Safety
    ///
    /// Zowel de begin-als de resulterende aanwijzer moeten zich binnen grenzen of één byte voorbij het einde van een toegewezen object bevinden.
    /// Als een van beide aanwijzers buiten het bereik valt of als er rekenkundige overloop optreedt, zal elk verder gebruik van de geretourneerde waarde resulteren in ongedefinieerd gedrag.
    ///
    ///
    /// De gestabiliseerde versie van deze intrinsieke is [`pointer::offset`].
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn offset<T>(dst: *const T, offset: isize) -> *const T;

    /// Berekent de offset van een aanwijzer, mogelijk in omloop.
    ///
    /// Dit is intrinsiek geïmplementeerd om conversie van en naar een geheel getal te vermijden, aangezien de conversie bepaalde optimalisaties verhindert.
    ///
    /// # Safety
    ///
    /// In tegenstelling tot de intrinsieke `offset`, beperkt deze intrinsieke waarde de resulterende pointer niet om naar of één byte voorbij het einde van een toegewezen object te wijzen, en wordt deze omhuld met twee-complement-rekenkunde.
    /// De resulterende waarde is niet noodzakelijk geldig om te worden gebruikt om daadwerkelijk toegang te krijgen tot geheugen.
    ///
    /// De gestabiliseerde versie van deze intrinsieke is [`pointer::wrapping_offset`].
    ///
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn arith_offset<T>(dst: *const T, offset: isize) -> *const T;

    /// Gelijk aan de juiste intrinsieke `llvm.memcpy.p0i8.0i8.*`, met een afmeting van `count`*`size_of::<T>()` en een uitlijning van
    ///
    /// `min_align_of::<T>()`
    ///
    /// De vluchtige parameter is ingesteld op `true`, dus deze wordt niet geoptimaliseerd tenzij de grootte gelijk is aan nul.
    ///
    /// Deze intrinsieke heeft geen stabiele tegenhanger.
    ///
    pub fn volatile_copy_nonoverlapping_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// Gelijk aan de juiste intrinsieke `llvm.memmove.p0i8.0i8.*`, met een afmeting van `count* size_of::<T>()` en een uitlijning van
    ///
    /// `min_align_of::<T>()`
    ///
    /// De vluchtige parameter is ingesteld op `true`, dus deze wordt niet geoptimaliseerd tenzij de grootte gelijk is aan nul.
    ///
    /// Deze intrinsieke heeft geen stabiele tegenhanger.
    ///
    pub fn volatile_copy_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// Equivalent aan de juiste intrinsieke `llvm.memset.p0i8.*`, met een afmeting van `count* size_of::<T>()` en een uitlijning van `min_align_of::<T>()`.
    ///
    ///
    /// De vluchtige parameter is ingesteld op `true`, dus deze wordt niet geoptimaliseerd tenzij de grootte gelijk is aan nul.
    ///
    /// Deze intrinsieke heeft geen stabiele tegenhanger.
    ///
    ///
    pub fn volatile_set_memory<T>(dst: *mut T, val: u8, count: usize);

    /// Voert een vluchtige belasting uit vanaf de `src`-aanwijzer.
    ///
    /// De gestabiliseerde versie van deze intrinsieke is [`core::ptr::read_volatile`](crate::ptr::read_volatile).
    pub fn volatile_load<T>(src: *const T) -> T;
    /// Voert een vluchtige opslag uit naar de `dst`-aanwijzer.
    ///
    /// De gestabiliseerde versie van deze intrinsieke versie is [`core::ptr::write_volatile`](crate::ptr::write_volatile).
    pub fn volatile_store<T>(dst: *mut T, val: T);

    /// Voert een vluchtige belasting uit vanaf de `src`-aanwijzer. De aanwijzer hoeft niet te worden uitgelijnd.
    ///
    ///
    /// Deze intrinsieke heeft geen stabiele tegenhanger.
    pub fn unaligned_volatile_load<T>(src: *const T) -> T;
    /// Voert een vluchtige opslag uit naar de `dst`-aanwijzer.
    /// De aanwijzer hoeft niet te worden uitgelijnd.
    ///
    /// Deze intrinsieke heeft geen stabiele tegenhanger.
    pub fn unaligned_volatile_store<T>(dst: *mut T, val: T);

    /// Retourneert de vierkantswortel van een `f32`
    ///
    /// De gestabiliseerde versie van deze intrinsieke is
    /// [`f32::sqrt`](../../std/primitive.f32.html#method.sqrt)
    pub fn sqrtf32(x: f32) -> f32;
    /// Retourneert de vierkantswortel van een `f64`
    ///
    /// De gestabiliseerde versie van deze intrinsieke is
    /// [`f64::sqrt`](../../std/primitive.f64.html#method.sqrt)
    pub fn sqrtf64(x: f64) -> f64;

    /// Verhoogt een `f32` tot een geheel getal.
    ///
    /// De gestabiliseerde versie van deze intrinsieke is
    /// [`f32::powi`](../../std/primitive.f32.html#method.powi)
    pub fn powif32(a: f32, x: i32) -> f32;
    /// Verhoogt een `f64` tot een geheel getal.
    ///
    /// De gestabiliseerde versie van deze intrinsieke is
    /// [`f64::powi`](../../std/primitive.f64.html#method.powi)
    pub fn powif64(a: f64, x: i32) -> f64;

    /// Retourneert de sinus van een `f32`.
    ///
    /// De gestabiliseerde versie van deze intrinsieke is
    /// [`f32::sin`](../../std/primitive.f32.html#method.sin)
    pub fn sinf32(x: f32) -> f32;
    /// Retourneert de sinus van een `f64`.
    ///
    /// De gestabiliseerde versie van deze intrinsieke is
    /// [`f64::sin`](../../std/primitive.f64.html#method.sin)
    pub fn sinf64(x: f64) -> f64;

    /// Retourneert de cosinus van een `f32`.
    ///
    /// De gestabiliseerde versie van deze intrinsieke is
    /// [`f32::cos`](../../std/primitive.f32.html#method.cos)
    pub fn cosf32(x: f32) -> f32;
    /// Retourneert de cosinus van een `f64`.
    ///
    /// De gestabiliseerde versie van deze intrinsieke is
    /// [`f64::cos`](../../std/primitive.f64.html#method.cos)
    pub fn cosf64(x: f64) -> f64;

    /// Verhoogt een `f32` naar een `f32`-vermogen.
    ///
    /// De gestabiliseerde versie van deze intrinsieke is
    /// [`f32::powf`](../../std/primitive.f32.html#method.powf)
    pub fn powf32(a: f32, x: f32) -> f32;
    /// Verhoogt een `f64` naar een `f64`-vermogen.
    ///
    /// De gestabiliseerde versie van deze intrinsieke is
    /// [`f64::powf`](../../std/primitive.f64.html#method.powf)
    pub fn powf64(a: f64, x: f64) -> f64;

    /// Retourneert de exponentiële waarde van een `f32`.
    ///
    /// De gestabiliseerde versie van deze intrinsieke is
    /// [`f32::exp`](../../std/primitive.f32.html#method.exp)
    pub fn expf32(x: f32) -> f32;
    /// Retourneert de exponentiële waarde van een `f64`.
    ///
    /// De gestabiliseerde versie van deze intrinsieke is
    /// [`f64::exp`](../../std/primitive.f64.html#method.exp)
    pub fn expf64(x: f64) -> f64;

    /// Retourneert 2 verheven tot de kracht van een `f32`.
    ///
    /// De gestabiliseerde versie van deze intrinsieke is
    /// [`f32::exp2`](../../std/primitive.f32.html#method.exp2)
    pub fn exp2f32(x: f32) -> f32;
    /// Retourneert 2 verheven tot de kracht van een `f64`.
    ///
    /// De gestabiliseerde versie van deze intrinsieke is
    /// [`f64::exp2`](../../std/primitive.f64.html#method.exp2)
    pub fn exp2f64(x: f64) -> f64;

    /// Retourneert de natuurlijke logaritme van een `f32`.
    ///
    /// De gestabiliseerde versie van deze intrinsieke is
    /// [`f32::ln`](../../std/primitive.f32.html#method.ln)
    pub fn logf32(x: f32) -> f32;
    /// Retourneert de natuurlijke logaritme van een `f64`.
    ///
    /// De gestabiliseerde versie van deze intrinsieke is
    /// [`f64::ln`](../../std/primitive.f64.html#method.ln)
    pub fn logf64(x: f64) -> f64;

    /// Retourneert de logaritme met grondtal 10 van een `f32`.
    ///
    /// De gestabiliseerde versie van deze intrinsieke is
    /// [`f32::log10`](../../std/primitive.f32.html#method.log10)
    pub fn log10f32(x: f32) -> f32;
    /// Retourneert de logaritme met grondtal 10 van een `f64`.
    ///
    /// De gestabiliseerde versie van deze intrinsieke is
    /// [`f64::log10`](../../std/primitive.f64.html#method.log10)
    pub fn log10f64(x: f64) -> f64;

    /// Retourneert de logaritme met grondtal 2 van een `f32`.
    ///
    /// De gestabiliseerde versie van deze intrinsieke is
    /// [`f32::log2`](../../std/primitive.f32.html#method.log2)
    pub fn log2f32(x: f32) -> f32;
    /// Retourneert de logaritme met grondtal 2 van een `f64`.
    ///
    /// De gestabiliseerde versie van deze intrinsieke is
    /// [`f64::log2`](../../std/primitive.f64.html#method.log2)
    pub fn log2f64(x: f64) -> f64;

    /// Retourneert `a * b + c` voor `f32`-waarden.
    ///
    /// De gestabiliseerde versie van deze intrinsieke is
    /// [`f32::mul_add`](../../std/primitive.f32.html#method.mul_add)
    pub fn fmaf32(a: f32, b: f32, c: f32) -> f32;
    /// Retourneert `a * b + c` voor `f64`-waarden.
    ///
    /// De gestabiliseerde versie van deze intrinsieke is
    /// [`f64::mul_add`](../../std/primitive.f64.html#method.mul_add)
    pub fn fmaf64(a: f64, b: f64, c: f64) -> f64;

    /// Retourneert de absolute waarde van een `f32`.
    ///
    /// De gestabiliseerde versie van deze intrinsieke is
    /// [`f32::abs`](../../std/primitive.f32.html#method.abs)
    pub fn fabsf32(x: f32) -> f32;
    /// Retourneert de absolute waarde van een `f64`.
    ///
    /// De gestabiliseerde versie van deze intrinsieke is
    /// [`f64::abs`](../../std/primitive.f64.html#method.abs)
    pub fn fabsf64(x: f64) -> f64;

    /// Retourneert het minimum van twee `f32`-waarden.
    ///
    /// De gestabiliseerde versie van deze intrinsieke is
    /// [`f32::min`]
    pub fn minnumf32(x: f32, y: f32) -> f32;
    /// Retourneert het minimum van twee `f64`-waarden.
    ///
    /// De gestabiliseerde versie van deze intrinsieke is
    /// [`f64::min`]
    pub fn minnumf64(x: f64, y: f64) -> f64;
    /// Retourneert het maximum van twee `f32`-waarden.
    ///
    /// De gestabiliseerde versie van deze intrinsieke is
    /// [`f32::max`]
    pub fn maxnumf32(x: f32, y: f32) -> f32;
    /// Retourneert het maximum van twee `f64`-waarden.
    ///
    /// De gestabiliseerde versie van deze intrinsieke is
    /// [`f64::max`]
    pub fn maxnumf64(x: f64, y: f64) -> f64;

    /// Kopieert het teken van `y` naar `x` voor `f32`-waarden.
    ///
    /// De gestabiliseerde versie van deze intrinsieke is
    /// [`f32::copysign`](../../std/primitive.f32.html#method.copysign)
    pub fn copysignf32(x: f32, y: f32) -> f32;
    /// Kopieert het teken van `y` naar `x` voor `f64`-waarden.
    ///
    /// De gestabiliseerde versie van deze intrinsieke is
    /// [`f64::copysign`](../../std/primitive.f64.html#method.copysign)
    pub fn copysignf64(x: f64, y: f64) -> f64;

    /// Retourneert het grootste gehele getal kleiner dan of gelijk aan `f32`.
    ///
    /// De gestabiliseerde versie van deze intrinsieke is
    /// [`f32::floor`](../../std/primitive.f32.html#method.floor)
    pub fn floorf32(x: f32) -> f32;
    /// Retourneert het grootste gehele getal kleiner dan of gelijk aan `f64`.
    ///
    /// De gestabiliseerde versie van deze intrinsieke is
    /// [`f64::floor`](../../std/primitive.f64.html#method.floor)
    pub fn floorf64(x: f64) -> f64;

    /// Retourneert het kleinste gehele getal groter dan of gelijk aan `f32`.
    ///
    /// De gestabiliseerde versie van deze intrinsieke is
    /// [`f32::ceil`](../../std/primitive.f32.html#method.ceil)
    pub fn ceilf32(x: f32) -> f32;
    /// Retourneert het kleinste gehele getal groter dan of gelijk aan `f64`.
    ///
    /// De gestabiliseerde versie van deze intrinsieke is
    /// [`f64::ceil`](../../std/primitive.f64.html#method.ceil)
    pub fn ceilf64(x: f64) -> f64;

    /// Retourneert het gehele deel van een `f32`.
    ///
    /// De gestabiliseerde versie van deze intrinsieke is
    /// [`f32::trunc`](../../std/primitive.f32.html#method.trunc)
    pub fn truncf32(x: f32) -> f32;
    /// Retourneert het gehele deel van een `f64`.
    ///
    /// De gestabiliseerde versie van deze intrinsieke is
    /// [`f64::trunc`](../../std/primitive.f64.html#method.trunc)
    pub fn truncf64(x: f64) -> f64;

    /// Retourneert het dichtstbijzijnde gehele getal naar een `f32`.
    /// Kan een onnauwkeurige drijvende-komma-uitzondering veroorzaken als het argument geen geheel getal is.
    pub fn rintf32(x: f32) -> f32;
    /// Retourneert het dichtstbijzijnde gehele getal naar een `f64`.
    /// Kan een onnauwkeurige drijvende-komma-uitzondering veroorzaken als het argument geen geheel getal is.
    pub fn rintf64(x: f64) -> f64;

    /// Retourneert het dichtstbijzijnde gehele getal naar een `f32`.
    ///
    /// Deze intrinsieke heeft geen stabiele tegenhanger.
    pub fn nearbyintf32(x: f32) -> f32;
    /// Retourneert het dichtstbijzijnde gehele getal naar een `f64`.
    ///
    /// Deze intrinsieke heeft geen stabiele tegenhanger.
    pub fn nearbyintf64(x: f64) -> f64;

    /// Retourneert het dichtstbijzijnde gehele getal naar een `f32`.Rondt gevallen halverwege af van nul af.
    ///
    /// De gestabiliseerde versie van deze intrinsieke is
    /// [`f32::round`](../../std/primitive.f32.html#method.round)
    pub fn roundf32(x: f32) -> f32;
    /// Retourneert het dichtstbijzijnde gehele getal naar een `f64`.Rondt gevallen halverwege af van nul af.
    ///
    /// De gestabiliseerde versie van deze intrinsieke is
    /// [`f64::round`](../../std/primitive.f64.html#method.round)
    pub fn roundf64(x: f64) -> f64;

    /// Float-toevoeging die optimalisaties mogelijk maakt op basis van algebraïsche regels.
    /// Kan aannemen dat de invoer eindig is.
    ///
    /// Deze intrinsieke heeft geen stabiele tegenhanger.
    pub fn fadd_fast<T: Copy>(a: T, b: T) -> T;

    /// Float-aftrekking die optimalisaties mogelijk maakt op basis van algebraïsche regels.
    /// Kan aannemen dat de invoer eindig is.
    ///
    /// Deze intrinsieke heeft geen stabiele tegenhanger.
    pub fn fsub_fast<T: Copy>(a: T, b: T) -> T;

    /// Float-vermenigvuldiging die optimalisaties mogelijk maakt op basis van algebraïsche regels.
    /// Kan aannemen dat de invoer eindig is.
    ///
    /// Deze intrinsieke heeft geen stabiele tegenhanger.
    pub fn fmul_fast<T: Copy>(a: T, b: T) -> T;

    /// Float-indeling die optimalisaties mogelijk maakt op basis van algebraïsche regels.
    /// Kan aannemen dat de invoer eindig is.
    ///
    /// Deze intrinsieke heeft geen stabiele tegenhanger.
    pub fn fdiv_fast<T: Copy>(a: T, b: T) -> T;

    /// Zwevende rest die optimalisaties mogelijk maakt op basis van algebraïsche regels.
    /// Kan aannemen dat de invoer eindig is.
    ///
    /// Deze intrinsieke heeft geen stabiele tegenhanger.
    pub fn frem_fast<T: Copy>(a: T, b: T) -> T;

    /// Converteren met fptoui/fptosi van LLVM, die undef kan retourneren voor waarden buiten het bereik
    /// (<https://github.com/rust-lang/rust/issues/10184>)
    ///
    /// Gestabiliseerd als [`f32::to_int_unchecked`] en [`f64::to_int_unchecked`].
    pub fn float_to_int_unchecked<Float: Copy, Int: Copy>(value: Float) -> Int;

    /// Retourneert het aantal bits dat is ingesteld in een geheel getal van het type `T`
    ///
    /// De gestabiliseerde versies van deze intrinsieke zijn beschikbaar op de integer primitieven via de `count_ones`-methode.
    /// Bijvoorbeeld,
    /// [`u32::count_ones`]
    #[rustc_const_stable(feature = "const_ctpop", since = "1.40.0")]
    pub fn ctpop<T: Copy>(x: T) -> T;

    /// Retourneert het aantal eerste niet-ingestelde bits (zeroes) in een geheel getal van het type `T`.
    ///
    /// De gestabiliseerde versies van deze intrinsieke zijn beschikbaar op de integer primitieven via de `leading_zeros`-methode.
    /// Bijvoorbeeld,
    /// [`u32::leading_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 3);
    /// ```
    ///
    /// Een `x` met de waarde `0` retourneert de bitbreedte van `T`.
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0u16;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 16);
    /// ```
    #[rustc_const_stable(feature = "const_ctlz", since = "1.40.0")]
    pub fn ctlz<T: Copy>(x: T) -> T;

    /// Zoals `ctlz`, maar extra onveilig omdat het `undef` retourneert wanneer het een `x` krijgt met de waarde `0`.
    ///
    ///
    /// Deze intrinsieke heeft geen stabiele tegenhanger.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz_nonzero;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = unsafe { ctlz_nonzero(x) };
    /// assert_eq!(num_leading, 3);
    /// ```
    #[rustc_const_stable(feature = "constctlz", since = "1.50.0")]
    pub fn ctlz_nonzero<T: Copy>(x: T) -> T;

    /// Retourneert het aantal achterliggende niet-ingestelde bits (zeroes) in een geheel getal van het type `T`.
    ///
    /// De gestabiliseerde versies van deze intrinsieke zijn beschikbaar op de integer primitieven via de `trailing_zeros`-methode.
    /// Bijvoorbeeld,
    /// [`u32::trailing_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 3);
    /// ```
    ///
    /// Een `x` met de waarde `0` retourneert de bitbreedte van `T`:
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0u16;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 16);
    /// ```
    #[rustc_const_stable(feature = "const_cttz", since = "1.40.0")]
    pub fn cttz<T: Copy>(x: T) -> T;

    /// Zoals `cttz`, maar extra onveilig omdat het `undef` retourneert wanneer het een `x` krijgt met de waarde `0`.
    ///
    ///
    /// Deze intrinsieke heeft geen stabiele tegenhanger.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz_nonzero;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = unsafe { cttz_nonzero(x) };
    /// assert_eq!(num_trailing, 3);
    /// ```
    #[rustc_const_unstable(feature = "const_cttz", issue = "none")]
    pub fn cttz_nonzero<T: Copy>(x: T) -> T;

    /// Keert de bytes om in een geheel getal van het type `T`.
    ///
    /// De gestabiliseerde versies van deze intrinsieke zijn beschikbaar op de integer primitieven via de `swap_bytes`-methode.
    /// Bijvoorbeeld,
    /// [`u32::swap_bytes`]
    #[rustc_const_stable(feature = "const_bswap", since = "1.40.0")]
    pub fn bswap<T: Copy>(x: T) -> T;

    /// Keert de bits in een geheel getal van het type `T` om.
    ///
    /// De gestabiliseerde versies van deze intrinsieke zijn beschikbaar op de integer primitieven via de `reverse_bits`-methode.
    /// Bijvoorbeeld,
    /// [`u32::reverse_bits`]
    #[rustc_const_stable(feature = "const_bitreverse", since = "1.40.0")]
    pub fn bitreverse<T: Copy>(x: T) -> T;

    /// Voert gecontroleerde optelling van gehele getallen uit.
    ///
    /// De gestabiliseerde versies van deze intrinsieke zijn beschikbaar op de integer primitieven via de `overflowing_add`-methode.
    /// Bijvoorbeeld,
    /// [`u32::overflowing_add`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn add_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Voert gecontroleerde aftrekking van gehele getallen uit
    ///
    /// De gestabiliseerde versies van deze intrinsieke zijn beschikbaar op de integer primitieven via de `overflowing_sub`-methode.
    /// Bijvoorbeeld,
    /// [`u32::overflowing_sub`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn sub_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Voert gecontroleerde vermenigvuldiging met gehele getallen uit
    ///
    /// De gestabiliseerde versies van deze intrinsieke zijn beschikbaar op de integer primitieven via de `overflowing_mul`-methode.
    /// Bijvoorbeeld,
    /// [`u32::overflowing_mul`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn mul_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Voert een exacte deling uit, resulterend in ongedefinieerd gedrag waarbij `x % y != 0` of `y == 0` of `x == T::MIN && y == -1`
    ///
    ///
    /// Deze intrinsieke heeft geen stabiele tegenhanger.
    pub fn exact_div<T: Copy>(x: T, y: T) -> T;

    /// Voert een ongecontroleerde deling uit, resulterend in ongedefinieerd gedrag waarbij `y == 0` of `x == T::MIN && y == -1`
    ///
    ///
    /// Veilige wrappers voor deze intrinsieke zijn beschikbaar op de integer primitieven via de `checked_div`-methode.
    /// Bijvoorbeeld,
    /// [`u32::checked_div`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_div<T: Copy>(x: T, y: T) -> T;
    /// Retourneert de rest van een niet-aangevinkte deling, wat resulteert in ongedefinieerd gedrag bij `y == 0` of `x == T::MIN && y == -1`
    ///
    ///
    /// Veilige wrappers voor deze intrinsieke zijn beschikbaar op de integer primitieven via de `checked_rem`-methode.
    /// Bijvoorbeeld,
    /// [`u32::checked_rem`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_rem<T: Copy>(x: T, y: T) -> T;

    /// Voert een ongecontroleerde verschuiving naar links uit, resulterend in ongedefinieerd gedrag bij `y < 0` of `y >= N`, waarbij N de breedte is van T in bits.
    ///
    ///
    /// Veilige wrappers voor deze intrinsieke zijn beschikbaar op de integer primitieven via de `checked_shl`-methode.
    /// Bijvoorbeeld,
    /// [`u32::checked_shl`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shl<T: Copy>(x: T, y: T) -> T;
    /// Voert een ongecontroleerde verschuiving naar rechts uit, wat resulteert in ongedefinieerd gedrag bij `y < 0` of `y >= N`, waarbij N de breedte is van T in bits.
    ///
    ///
    /// Veilige wrappers voor deze intrinsieke zijn beschikbaar op de integer primitieven via de `checked_shr`-methode.
    /// Bijvoorbeeld,
    /// [`u32::checked_shr`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shr<T: Copy>(x: T, y: T) -> T;

    /// Retourneert het resultaat van een niet-aangevinkte toevoeging, resulterend in ongedefinieerd gedrag bij `x + y > T::MAX` of `x + y < T::MIN`.
    ///
    ///
    /// Deze intrinsieke heeft geen stabiele tegenhanger.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_add<T: Copy>(x: T, y: T) -> T;

    /// Retourneert het resultaat van een ongecontroleerde aftrekking, resulterend in ongedefinieerd gedrag bij `x - y > T::MAX` of `x - y < T::MIN`.
    ///
    ///
    /// Deze intrinsieke heeft geen stabiele tegenhanger.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_sub<T: Copy>(x: T, y: T) -> T;

    /// Retourneert het resultaat van een ongecontroleerde vermenigvuldiging, resulterend in ongedefinieerd gedrag bij `x *y > T::MAX` of `x* y < T::MIN`.
    ///
    ///
    /// Deze intrinsieke heeft geen stabiele tegenhanger.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_mul<T: Copy>(x: T, y: T) -> T;

    /// Voert roteren naar links uit.
    ///
    /// De gestabiliseerde versies van deze intrinsieke zijn beschikbaar op de integer primitieven via de `rotate_left`-methode.
    /// Bijvoorbeeld,
    /// [`u32::rotate_left`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_left<T: Copy>(x: T, y: T) -> T;

    /// Voert rechtsom draaien uit.
    ///
    /// De gestabiliseerde versies van deze intrinsieke zijn beschikbaar op de integer primitieven via de `rotate_right`-methode.
    /// Bijvoorbeeld,
    /// [`u32::rotate_right`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_right<T: Copy>(x: T, y: T) -> T;

    /// Geeft als resultaat (a + b) mod 2 <sup>N</sup>, waarbij N de breedte is van T in bits.
    ///
    /// De gestabiliseerde versies van deze intrinsieke zijn beschikbaar op de integer primitieven via de `wrapping_add`-methode.
    /// Bijvoorbeeld,
    /// [`u32::wrapping_add`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_add<T: Copy>(a: T, b: T) -> T;
    /// Geeft als resultaat (a, b) mod 2 <sup>N</sup>, waarbij N de breedte is van T in bits.
    ///
    /// De gestabiliseerde versies van deze intrinsieke zijn beschikbaar op de integer primitieven via de `wrapping_sub`-methode.
    /// Bijvoorbeeld,
    /// [`u32::wrapping_sub`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_sub<T: Copy>(a: T, b: T) -> T;
    /// Geeft als resultaat (a * b) mod 2 <sup>N</sup>, waarbij N de breedte is van T in bits.
    ///
    /// De gestabiliseerde versies van deze intrinsieke zijn beschikbaar op de integer primitieven via de `wrapping_mul`-methode.
    /// Bijvoorbeeld,
    /// [`u32::wrapping_mul`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_mul<T: Copy>(a: T, b: T) -> T;

    /// Berekent `a + b`, verzadigend op numerieke grenzen.
    ///
    /// De gestabiliseerde versies van deze intrinsieke zijn beschikbaar op de integer primitieven via de `saturating_add`-methode.
    /// Bijvoorbeeld,
    /// [`u32::saturating_add`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_add<T: Copy>(a: T, b: T) -> T;
    /// Berekent `a - b`, verzadigend op numerieke grenzen.
    ///
    /// De gestabiliseerde versies van deze intrinsieke zijn beschikbaar op de integer primitieven via de `saturating_sub`-methode.
    /// Bijvoorbeeld,
    /// [`u32::saturating_sub`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_sub<T: Copy>(a: T, b: T) -> T;

    /// Retourneert de waarde van de discriminant voor de variant in 'v';
    /// als `T` geen discriminatie heeft, retourneert `0`.
    ///
    /// De gestabiliseerde versie van deze intrinsieke is [`core::mem::discriminant`](crate::mem::discriminant).
    #[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
    pub fn discriminant_value<T>(v: &T) -> <T as DiscriminantKind>::Discriminant;

    /// Geeft als resultaat het aantal varianten van het type `T` dat naar een `usize` is gegoten;
    /// als `T` geen varianten heeft, geeft het `0` terug.Onbewoonde varianten worden meegeteld.
    ///
    /// De te stabiliseren versie van deze intrinsieke versie is [`mem::variant_count`].
    #[rustc_const_unstable(feature = "variant_count", issue = "73662")]
    pub fn variant_count<T>() -> usize;

    /// Rust's "try catch"-constructie die de functie pointer `try_fn` aanroept met de data pointer `data`.
    ///
    /// Het derde argument is een functie die wordt aangeroepen als er een panic optreedt.
    /// Deze functie neemt de gegevenspointer en een pointer mee naar het doelspecifieke uitzonderingsobject dat is opgevangen.
    ///
    /// Zie voor meer informatie de broncode van de compiler en de catch-implementatie van std.
    ///
    pub fn r#try(try_fn: fn(*mut u8), data: *mut u8, catch_fn: fn(*mut u8, *mut u8)) -> i32;

    /// Zendt een `!nontemporal`-winkel uit volgens LLVM (zie hun documenten).
    /// Zal waarschijnlijk nooit stabiel worden.
    pub fn nontemporal_store<T>(ptr: *mut T, val: T);

    /// Zie documentatie van `<*const T>::offset_from` voor details.
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    pub fn ptr_offset_from<T>(ptr: *const T, base: *const T) -> isize;

    /// Zie documentatie van `<*const T>::guaranteed_eq` voor details.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_eq<T>(ptr: *const T, other: *const T) -> bool;

    /// Zie documentatie van `<*const T>::guaranteed_ne` voor details.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_ne<T>(ptr: *const T, other: *const T) -> bool;

    /// Wijs toe tijdens het compileren.Mag tijdens runtime niet worden aangeroepen.
    #[rustc_const_unstable(feature = "const_heap", issue = "79597")]
    pub fn const_allocate(size: usize, align: usize) -> *mut u8;
}

// Sommige functies zijn hier gedefinieerd omdat ze per ongeluk in deze module beschikbaar zijn gemaakt op stable.
// Zie <https://github.com/rust-lang/rust/issues/15702>.
// (`transmute` valt ook in deze categorie, maar kan niet worden ingepakt vanwege de controle dat `T` en `U` dezelfde grootte hebben.)
//

/// Controleert of `ptr` correct is uitgelijnd ten opzichte van `align_of::<T>()`.
///
pub(crate) fn is_aligned_and_not_null<T>(ptr: *const T) -> bool {
    !ptr.is_null() && ptr as usize % mem::align_of::<T>() == 0
}

/// Kopieert `count *size_of::<T>()`-bytes van `src` naar `dst`.De bron en bestemming mogen* niet * elkaar overlappen.
///
/// Gebruik in plaats daarvan [`copy`] voor geheugengebieden die elkaar kunnen overlappen.
///
/// `copy_nonoverlapping` is semantisch equivalent aan C's [`memcpy`], maar met de argumentvolgorde verwisseld.
///
/// [`memcpy`]: https://en.cppreference.com/w/c/string/byte/memcpy
///
/// # Safety
///
/// Gedrag is niet gedefinieerd als een van de volgende voorwaarden wordt geschonden:
///
/// * `src` moet [valid] zijn voor het lezen van `count * size_of::<T>()` bytes.
///
/// * `dst` moet [valid] zijn voor schrijven van `count * size_of::<T>()` bytes.
///
/// * Zowel `src` als `dst` moeten correct zijn uitgelijnd.
///
/// * Het geheugengebied dat begint bij `src` met een grootte van `count *
///   De grootte van: :<T>() `bytes mogen *niet* overlappen met het geheugengebied beginnend bij `dst` met dezelfde grootte.
///
/// Net als [`read`] maakt `copy_nonoverlapping` een bitsgewijze kopie van `T`, ongeacht of `T` [`Copy`] is.
/// Als `T` niet [`Copy`] is, kunt u met *beide* de waarden in de regio die begint met `*src` en de regio die begint met `* dst` [violate memory safety][read-ownership] gebruiken.
///
///
/// Merk op dat zelfs als de effectief gekopieerde grootte (`count * size_of: :<T>()`) is `0`, de aanwijzers moeten niet-NULL zijn en correct uitgelijnd.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// [`Vec::append`] handmatig implementeren:
///
/// ```
/// use std::ptr;
///
/// /// Verplaatst alle elementen van `src` naar `dst`, waardoor `src` leeg blijft.
/// fn append<T>(dst: &mut Vec<T>, src: &mut Vec<T>) {
///     let src_len = src.len();
///     let dst_len = dst.len();
///
///     // Zorg ervoor dat `dst` voldoende capaciteit heeft om de hele `src` te bevatten.
///     dst.reserve(src_len);
///
///     unsafe {
///         // De aanroep van offset is altijd veilig omdat `Vec` nooit meer dan `isize::MAX` bytes zal toewijzen.
/////
///         let dst_ptr = dst.as_mut_ptr().offset(dst_len as isize);
///         let src_ptr = src.as_ptr();
///
///         // Kap `src` af zonder de inhoud ervan te verwijderen.
///         // We doen dit eerst om problemen te voorkomen in het geval iets verderop in panics.
///         src.set_len(0);
///
///         // De twee regio's kunnen elkaar niet overlappen omdat veranderlijke referenties geen alias hebben, en twee verschillende vectors kunnen niet hetzelfde geheugen bezitten.
/////
/////
///         ptr::copy_nonoverlapping(src_ptr, dst_ptr, src_len);
///
///         // Informeer `dst` dat het nu de inhoud van `src` bevat.
///         dst.set_len(dst_len + src_len);
///     }
/// }
///
/// let mut a = vec!['r'];
/// let mut b = vec!['u', 's', 't'];
///
/// append(&mut a, &mut b);
///
/// assert_eq!(a, &['r', 'u', 's', 't']);
/// assert!(b.is_empty());
/// ```
///
/// [`Vec::append`]: ../../std/vec/struct.Vec.html#method.append
///
///
///
///
///
#[doc(alias = "memcpy")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: Voer deze controles alleen tijdens runtime uit
    /*if cfg!(debug_assertions)
        && !(is_aligned_and_not_null(src)
            && is_aligned_and_not_null(dst)
            && is_nonoverlapping(src, dst, count))
    {
        // Niet in paniek raken om de impact van codegen kleiner te houden.
        abort();
    }*/

    // VEILIGHEID: het veiligheidscontract voor `copy_nonoverlapping` moet zijn
    // ondersteund door de beller.
    unsafe { copy_nonoverlapping(src, dst, count) }
}

/// Kopieert `count * size_of::<T>()`-bytes van `src` naar `dst`.De bron en de bestemming kunnen elkaar overlappen.
///
/// Als de bron en de bestemming *nooit* zullen overlappen, kan [`copy_nonoverlapping`] in plaats daarvan worden gebruikt.
///
/// `copy` is semantisch equivalent aan C's [`memmove`], maar met de argumentvolgorde verwisseld.
/// Het kopiëren vindt plaats alsof de bytes van `src` naar een tijdelijke array zijn gekopieerd en vervolgens van de array naar `dst`.
///
/// [`memmove`]: https://en.cppreference.com/w/c/string/byte/memmove
///
/// # Safety
///
/// Gedrag is niet gedefinieerd als een van de volgende voorwaarden wordt geschonden:
///
/// * `src` moet [valid] zijn voor het lezen van `count * size_of::<T>()` bytes.
///
/// * `dst` moet [valid] zijn voor schrijven van `count * size_of::<T>()` bytes.
///
/// * Zowel `src` als `dst` moeten correct zijn uitgelijnd.
///
/// Net als [`read`] maakt `copy` een bitsgewijze kopie van `T`, ongeacht of `T` [`Copy`] is.
/// Als `T` niet [`Copy`] is, kan het gebruik van zowel de waarden in de regio die begint met `*src` als de regio die begint met `* dst` [violate memory safety][read-ownership] gebruiken.
///
///
/// Merk op dat zelfs als de effectief gekopieerde grootte (`count * size_of: :<T>()`) is `0`, de aanwijzers moeten niet-NULL zijn en correct uitgelijnd.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Maak efficiënt een Rust vector vanuit een onveilige buffer:
///
/// ```
/// use std::ptr;
///
/// /// # Safety
//////
/// /// * `ptr` moet correct zijn uitgelijnd voor het type en niet-nul.
/// /// * `ptr` moet geldig zijn voor het lezen van aaneengesloten `elts`-elementen van het type `T`.
/// /// * Deze elementen mogen niet worden gebruikt nadat deze functie is aangeroepen, tenzij `T: Copy`.
/// # #[allow(dead_code)]
/// unsafe fn from_buf_raw<T>(ptr: *const T, elts: usize) -> Vec<T> {
///     let mut dst = Vec::with_capacity(elts);
///
///     // VEILIGHEID: Onze voorwaarde zorgt ervoor dat de bron op één lijn ligt en geldig is,
///     // en `Vec::with_capacity` zorgt ervoor dat we bruikbare ruimte hebben om ze te schrijven.
///     ptr::copy(ptr, dst.as_mut_ptr(), elts);
///
///     // VEILIGHEID: We hebben het eerder met zoveel capaciteit gemaakt,
///     // en de vorige `copy` heeft deze elementen geïnitialiseerd.
///     dst.set_len(elts);
///     dst
/// }
/// ```
///
///
///
///
///
#[doc(alias = "memmove")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: Voer deze controles alleen tijdens runtime uit
    /*if cfg!(debug_assertions) && !(is_aligned_and_not_null(src) && is_aligned_and_not_null(dst)) {
        // Niet in paniek raken om de impact van codegen kleiner te houden.
        abort();
    }*/

    // VEILIGHEID: het veiligheidscontract voor `copy` moet worden nageleefd door de beller.
    unsafe { copy(src, dst, count) }
}

/// Stelt `count * size_of::<T>()`-bytes geheugen in, beginnend bij `dst` tot `val`.
///
/// `write_bytes` is vergelijkbaar met C's [`memset`], maar stelt `count * size_of::<T>()`-bytes in op `val`.
///
/// [`memset`]: https://en.cppreference.com/w/c/string/byte/memset
///
/// # Safety
///
/// Gedrag is niet gedefinieerd als een van de volgende voorwaarden wordt geschonden:
///
/// * `dst` moet [valid] zijn voor schrijven van `count * size_of::<T>()` bytes.
///
/// * `dst` moet correct zijn uitgelijnd.
///
/// Bovendien moet de beller ervoor zorgen dat het schrijven van `count * size_of::<T>()`-bytes naar het opgegeven geheugengebied resulteert in een geldige waarde van `T`.
/// Het gebruik van een geheugengebied getypt als een `T` dat de ongeldige waarde `T` bevat, is ongedefinieerd gedrag.
///
/// Merk op dat zelfs als de effectief gekopieerde grootte (`count * size_of: :<T>()`) is `0`, de pointer moet niet-NULL zijn en correct uitgelijnd.
///
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Basisgebruik:
///
/// ```
/// use std::ptr;
///
/// let mut vec = vec![0u32; 4];
/// unsafe {
///     let vec_ptr = vec.as_mut_ptr();
///     ptr::write_bytes(vec_ptr, 0xfe, 2);
/// }
/// assert_eq!(vec, [0xfefefefe, 0xfefefefe, 0, 0]);
/// ```
///
/// Een ongeldige waarde creëren:
///
/// ```
/// use std::ptr;
///
/// let mut v = Box::new(0i32);
///
/// unsafe {
///     // Lekt de eerder vastgehouden waarde door de `Box<T>` te overschrijven met een null-aanwijzer.
/////
///     ptr::write_bytes(&mut v as *mut Box<i32>, 0, 1);
/// }
///
/// // Op dit punt resulteert het gebruik of het laten vallen van `v` in ongedefinieerd gedrag.
/// // drop(v); // ERROR
///
/// // Zelfs lekkende `v` "uses" het, en dus is ongedefinieerd gedrag.
/// // mem::forget(v); // ERROR
///
/// // In feite is `v` ongeldig volgens indelingsinvarianten van het basistype, dus *elke* bewerking die erop wordt aangeraakt, is ongedefinieerd gedrag.
/////
/// // laat v2 =v;//FOUT
///
/// unsafe {
///     // Laten we in plaats daarvan een geldige waarde invoeren
///     ptr::write(&mut v as *mut Box<i32>, Box::new(42i32));
/// }
///
/// // Nu is de doos in orde
/// assert_eq!(*v, 42);
/// ```
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[inline]
pub unsafe fn write_bytes<T>(dst: *mut T, val: u8, count: usize) {
    extern "rust-intrinsic" {
        fn write_bytes<T>(dst: *mut T, val: u8, count: usize);
    }

    debug_assert!(is_aligned_and_not_null(dst), "attempt to write to unaligned or null pointer");

    // VEILIGHEID: het veiligheidscontract voor `write_bytes` moet worden nageleefd door de beller.
    unsafe { write_bytes(dst, val, count) }
}