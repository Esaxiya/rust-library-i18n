//! Panic ondersteuning voor libcore
//!
//! De kernbibliotheek kan paniek niet definiëren, maar het *verklaart* paniek.
//! Dit betekent dat de functies binnen libcore zijn toegestaan voor panic, maar om nuttig te zijn moet een stroomopwaartse crate paniek definiëren om libcore te gebruiken.
//! De huidige interface voor paniek is:
//!
//! ```
//! fn panic_impl(pi: &core::panic::PanicInfo<'_>) -> !
//! # { loop {} }
//! ```
//!
//! Deze definitie staat paniek toe bij elk algemeen bericht, maar het staat niet toe om te falen met een `Box<Any>`-waarde.
//! (`PanicInfo` bevat alleen een `&(dyn Any + Send)`, waarvoor we een dummy-waarde invullen in `PanicInfo: : internal_constructor`.) De reden hiervoor is dat libcore niet mag toekennen.
//!
//!
//! Deze module bevat een paar andere paniekfuncties, maar dit zijn slechts de noodzakelijke lange items voor de compiler.Alle panics worden door deze ene functie geleid.
//! Het daadwerkelijke symbool wordt gedeclareerd via het `#[panic_handler]`-attribuut.
//!
//!
//!

#![allow(dead_code, missing_docs)]
#![unstable(
    feature = "core_panic",
    reason = "internal details of the implementation of the `panic!` and related macros",
    issue = "none"
)]

use crate::fmt;
use crate::panic::{Location, PanicInfo};

/// De onderliggende implementatie van de `panic!`-macro van libcore wanneer er geen opmaak wordt gebruikt.
#[cold]
// nooit inline tenzij panic_immediate_abort om code-bloat op de call-sites zoveel mogelijk te voorkomen
//
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic"] // nodig door codegen voor panic op overflow en andere `Assert` MIR-terminators
pub fn panic(expr: &'static str) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // Gebruik Arguments::new_v1 in plaats van format_args! ("{}", Expr) om de overhead mogelijk te verkleinen.
    // Het format_args!macro gebruikt str's Display trait om expr te schrijven, dat Formatter::pad aanroept, wat string afkappen en opvullen moet accommoderen (ook al wordt hier geen gebruikt).
    //
    // Door Arguments::new_v1 te gebruiken, kan de compiler Formatter::pad weglaten uit het binaire uitvoerbestand, wat tot enkele kilobytes kan besparen.
    //
    //
    panic_fmt(fmt::Arguments::new_v1(&[expr], &[]));
}

#[inline]
#[track_caller]
#[lang = "panic_str"] // nodig voor const-geëvalueerde panics
pub fn panic_str(expr: &str) -> ! {
    panic_fmt(format_args!("{}", expr));
}

#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic_bounds_check"] // nodig door codegen voor panic op OOB array/slice-toegang
fn panic_bounds_check(index: usize, len: usize) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    panic!("index out of bounds: the len is {} but the index is {}", len, index)
}

/// De onderliggende implementatie van de `panic!`-macro van libcore wanneer opmaak wordt gebruikt.
#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[cfg_attr(feature = "panic_immediate_abort", inline)]
#[track_caller]
pub fn panic_fmt(fmt: fmt::Arguments<'_>) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // OPMERKING Deze functie overschrijdt nooit de FFI-grens;het is een Rust-naar-Rust-aanroep die wordt omgezet in de `#[panic_handler]`-functie.
    //
    extern "Rust" {
        #[lang = "panic_impl"]
        fn panic_impl(pi: &PanicInfo<'_>) -> !;
    }

    let pi = PanicInfo::internal_constructor(Some(&fmt), Location::caller());

    // VEILIGHEID: `panic_impl` is gedefinieerd in de veilige Rust-code en is dus veilig om te bellen.
    unsafe { panic_impl(&pi) }
}

#[derive(Debug)]
#[doc(hidden)]
pub enum AssertKind {
    Eq,
    Ne,
}

/// Interne functie voor `assert_eq!`-en `assert_ne!`-macro's
#[cold]
#[track_caller]
#[doc(hidden)]
pub fn assert_failed<T, U>(
    kind: AssertKind,
    left: &T,
    right: &U,
    args: Option<fmt::Arguments<'_>>,
) -> !
where
    T: fmt::Debug + ?Sized,
    U: fmt::Debug + ?Sized,
{
    #[track_caller]
    fn inner(
        kind: AssertKind,
        left: &dyn fmt::Debug,
        right: &dyn fmt::Debug,
        args: Option<fmt::Arguments<'_>>,
    ) -> ! {
        let op = match kind {
            AssertKind::Eq => "==",
            AssertKind::Ne => "!=",
        };

        match args {
            Some(args) => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`: {}"#,
                op, left, right, args
            ),
            None => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`"#,
                op, left, right,
            ),
        }
    }
    inner(kind, &left, &right, args)
}