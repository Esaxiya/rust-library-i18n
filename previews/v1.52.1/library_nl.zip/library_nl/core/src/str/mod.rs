//! String manipulatie.
//!
//! Zie de [`std::str`]-module voor meer details.
//!
//! [`std::str`]: ../../std/str/index.html

#![stable(feature = "rust1", since = "1.0.0")]

mod converts;
mod error;
mod iter;
mod traits;
mod validations;

use self::pattern::Pattern;
use self::pattern::{DoubleEndedSearcher, ReverseSearcher, Searcher};

use crate::char;
use crate::mem;
use crate::slice::{self, SliceIndex};

pub mod pattern;

#[unstable(feature = "str_internals", issue = "none")]
#[allow(missing_docs)]
pub mod lossy;

#[stable(feature = "rust1", since = "1.0.0")]
pub use converts::{from_utf8, from_utf8_unchecked};

#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub use converts::{from_utf8_mut, from_utf8_unchecked_mut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use error::{ParseBoolError, Utf8Error};

#[stable(feature = "rust1", since = "1.0.0")]
pub use traits::FromStr;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Bytes, CharIndices, Chars, Lines, SplitWhitespace};

#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated)]
pub use iter::LinesAny;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplit, RSplitTerminator, Split, SplitTerminator};

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplitN, SplitN};

#[stable(feature = "str_matches", since = "1.2.0")]
pub use iter::{Matches, RMatches};

#[stable(feature = "str_match_indices", since = "1.5.0")]
pub use iter::{MatchIndices, RMatchIndices};

#[stable(feature = "encode_utf16", since = "1.8.0")]
pub use iter::EncodeUtf16;

#[stable(feature = "str_escape", since = "1.34.0")]
pub use iter::{EscapeDebug, EscapeDefault, EscapeUnicode};

#[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
pub use iter::SplitAsciiWhitespace;

#[stable(feature = "split_inclusive", since = "1.51.0")]
pub use iter::SplitInclusive;

#[unstable(feature = "str_internals", issue = "none")]
pub use validations::next_code_point;

use iter::MatchIndicesInternal;
use iter::SplitInternal;
use iter::{MatchesInternal, SplitNInternal};

use validations::truncate_to_char_boundary;

#[inline(never)]
#[cold]
#[track_caller]
fn slice_error_fail(s: &str, begin: usize, end: usize) -> ! {
    const MAX_DISPLAY_LENGTH: usize = 256;
    let (truncated, s_trunc) = truncate_to_char_boundary(s, MAX_DISPLAY_LENGTH);
    let ellipsis = if truncated { "[...]" } else { "" };

    // 1. buiten de grenzen
    if begin > s.len() || end > s.len() {
        let oob_index = if begin > s.len() { begin } else { end };
        panic!("byte index {} is out of bounds of `{}`{}", oob_index, s_trunc, ellipsis);
    }

    // 2. begin <=einde
    assert!(
        begin <= end,
        "begin <= end ({} <= {}) when slicing `{}`{}",
        begin,
        end,
        s_trunc,
        ellipsis
    );

    // 3. karaktergrens
    let index = if !s.is_char_boundary(begin) { begin } else { end };
    // vind het personage
    let mut char_start = index;
    while !s.is_char_boundary(char_start) {
        char_start -= 1;
    }
    // `char_start` moet kleiner zijn dan len en een char boundary
    let ch = s[char_start..].chars().next().unwrap();
    let char_range = char_start..char_start + ch.len_utf8();
    panic!(
        "byte index {} is not a char boundary; it is inside {:?} (bytes {:?}) of `{}`{}",
        index, ch, char_range, s_trunc, ellipsis
    );
}

#[lang = "str"]
#[cfg(not(test))]
impl str {
    /// Retourneert de lengte van `self`.
    ///
    /// Deze lengte is in bytes, niet [`char`] s of grafemen.
    /// Met andere woorden, het is misschien niet wat een mens de lengte van de draad beschouwt.
    ///
    /// [`char`]: prim@char
    ///
    /// # Examples
    ///
    /// Basisgebruik:
    ///
    /// ```
    /// let len = "foo".len();
    /// assert_eq!(3, len);
    ///
    /// assert_eq!("ƒoo".len(), 4); // zin in f!
    /// assert_eq!("ƒoo".chars().count(), 3);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_str_len", since = "1.32.0")]
    #[inline]
    pub const fn len(&self) -> usize {
        self.as_bytes().len()
    }

    /// Geeft `true` terug als `self` een lengte heeft van nul bytes.
    ///
    /// # Examples
    ///
    /// Basisgebruik:
    ///
    /// ```
    /// let s = "";
    /// assert!(s.is_empty());
    ///
    /// let s = "not empty";
    /// assert!(!s.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_str_is_empty", since = "1.32.0")]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Controleert of de 'index'-byte de eerste byte is in een UTF-8-codepuntreeks of het einde van de tekenreeks.
    ///
    ///
    /// Het begin en einde van de string (wanneer `index== self.len()`) als grenzen worden beschouwd.
    ///
    /// Retourneert `false` als `index` groter is dan `self.len()`.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// assert!(s.is_char_boundary(0));
    /// // begin van `老`
    /// assert!(s.is_char_boundary(6));
    /// assert!(s.is_char_boundary(s.len()));
    ///
    /// // tweede byte van `ö`
    /// assert!(!s.is_char_boundary(2));
    ///
    /// // derde byte van `老`
    /// assert!(!s.is_char_boundary(8));
    /// ```
    ///
    #[stable(feature = "is_char_boundary", since = "1.9.0")]
    #[inline]
    pub fn is_char_boundary(&self, index: usize) -> bool {
        // 0 en len zijn altijd oké.
        // Test expliciet op 0, zodat het de controle gemakkelijk kan optimaliseren en het lezen van stringgegevens in dat geval kan overslaan.
        //
        if index == 0 || index == self.len() {
            return true;
        }
        match self.as_bytes().get(index) {
            None => false,
            // Dit is bitmagie equivalent aan: b <128 ||b>=192
            Some(&b) => (b as i8) >= -0x40,
        }
    }

    /// Converteert een string-slice naar een byte-slice.
    /// Gebruik de functie [`from_utf8`] om het bytesegment weer in een stringplak te converteren.
    ///
    /// # Examples
    ///
    /// Basisgebruik:
    ///
    /// ```
    /// let bytes = "bors".as_bytes();
    /// assert_eq!(b"bors", bytes);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "str_as_bytes", since = "1.32.0")]
    #[inline(always)]
    #[allow(unused_attributes)]
    #[rustc_allow_const_fn_unstable(const_fn_transmute)]
    pub const fn as_bytes(&self) -> &[u8] {
        // VEILIGHEID: const geluid omdat we twee typen transmuteren met dezelfde lay-out
        unsafe { mem::transmute(self) }
    }

    /// Converteert een veranderlijk string-segment naar een veranderlijk byte-segment.
    ///
    /// # Safety
    ///
    /// De beller moet ervoor zorgen dat de inhoud van de slice UTF-8 geldig is voordat de lening eindigt en de onderliggende `str` wordt gebruikt.
    ///
    ///
    /// Gebruik van een `str` waarvan de inhoud niet geldig is UTF-8 is ongedefinieerd gedrag.
    ///
    /// # Examples
    ///
    /// Basisgebruik:
    ///
    /// ```
    /// let mut s = String::from("Hello");
    /// let bytes = unsafe { s.as_bytes_mut() };
    ///
    /// assert_eq!(b"Hello", bytes);
    /// ```
    ///
    /// Mutability:
    ///
    /// ```
    /// let mut s = String::from("🗻∈🌏");
    ///
    /// unsafe {
    ///     let bytes = s.as_bytes_mut();
    ///
    ///     bytes[0] = 0xF0;
    ///     bytes[1] = 0x9F;
    ///     bytes[2] = 0x8D;
    ///     bytes[3] = 0x94;
    /// }
    ///
    /// assert_eq!("🍔∈🌏", s);
    /// ```
    #[stable(feature = "str_mut_extras", since = "1.20.0")]
    #[inline(always)]
    pub unsafe fn as_bytes_mut(&mut self) -> &mut [u8] {
        // VEILIGHEID: de cast van `&str` naar `&[u8]` is veilig sinds `str`
        // heeft dezelfde layout als `&[u8]` (alleen libstd kan deze garantie geven).
        // De verwijzing naar de aanwijzer is veilig omdat deze afkomstig is van een veranderlijke verwijzing die gegarandeerd geldig is voor schrijfbewerkingen.
        //
        unsafe { &mut *(self as *mut str as *mut [u8]) }
    }

    /// Converteert een stringplak naar een onbewerkte pointer.
    ///
    /// Omdat stringplakken een segment van bytes zijn, wijst de onbewerkte pointer naar een [`u8`].
    /// Deze aanwijzer wijst naar de eerste byte van de stringplak.
    ///
    /// De beller moet ervoor zorgen dat er nooit naar de teruggezonden aanwijzer wordt geschreven.
    /// Gebruik [`as_mut_ptr`] als u de inhoud van de stringplak moet muteren.
    ///
    ///
    /// [`as_mut_ptr`]: str::as_mut_ptr
    ///
    /// # Examples
    ///
    /// Basisgebruik:
    ///
    /// ```
    /// let s = "Hello";
    /// let ptr = s.as_ptr();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "rustc_str_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(&self) -> *const u8 {
        self as *const str as *const u8
    }

    /// Converteert een veranderlijk string-segment naar een onbewerkte pointer.
    ///
    /// Omdat stringplakken een segment van bytes zijn, wijst de onbewerkte pointer naar een [`u8`].
    /// Deze aanwijzer wijst naar de eerste byte van de stringplak.
    ///
    /// Het is uw verantwoordelijkheid om ervoor te zorgen dat de string slice alleen wordt gewijzigd op een manier dat deze geldig blijft UTF-8.
    ///
    ///
    #[stable(feature = "str_as_mut_ptr", since = "1.36.0")]
    #[inline]
    pub fn as_mut_ptr(&mut self) -> *mut u8 {
        self as *mut str as *mut u8
    }

    /// Retourneert een subslice van `str`.
    ///
    /// Dit is het niet-paniekerige alternatief voor het indexeren van de `str`.
    /// Geeft [`None`] terug wanneer een equivalente indexeringsbewerking panic zou zijn.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = String::from("🗻∈🌏");
    ///
    /// assert_eq!(Some("🗻"), v.get(0..4));
    ///
    /// // indices niet op UTF-8-sequentiegrenzen
    /// assert!(v.get(1..).is_none());
    /// assert!(v.get(..8).is_none());
    ///
    /// // buiten de grenzen
    /// assert!(v.get(..42).is_none());
    /// ```
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub fn get<I: SliceIndex<str>>(&self, i: I) -> Option<&I::Output> {
        i.get(self)
    }

    /// Retourneert een veranderlijk subdeel van `str`.
    ///
    /// Dit is het niet-paniekerige alternatief voor het indexeren van de `str`.
    /// Geeft [`None`] terug wanneer een equivalente indexeringsbewerking panic zou zijn.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = String::from("hello");
    /// // juiste lengte
    /// assert!(v.get_mut(0..5).is_some());
    /// // buiten de grenzen
    /// assert!(v.get_mut(..42).is_none());
    /// assert_eq!(Some("he"), v.get_mut(0..2).map(|v| &*v));
    ///
    /// assert_eq!("hello", v);
    /// {
    ///     let s = v.get_mut(0..2);
    ///     let s = s.map(|s| {
    ///         s.make_ascii_uppercase();
    ///         &*s
    ///     });
    ///     assert_eq!(Some("HE"), s);
    /// }
    /// assert_eq!("HEllo", v);
    /// ```
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub fn get_mut<I: SliceIndex<str>>(&mut self, i: I) -> Option<&mut I::Output> {
        i.get_mut(self)
    }

    /// Retourneert een niet-aangevinkte subslice van `str`.
    ///
    /// Dit is het ongecontroleerde alternatief voor het indexeren van de `str`.
    ///
    /// # Safety
    ///
    /// Bellers van deze functie zijn ervoor verantwoordelijk dat aan deze voorwaarden is voldaan:
    ///
    /// * De startindex mag de eindindex niet overschrijden;
    /// * Indexen moeten binnen de grenzen van het originele segment liggen;
    /// * Indexen moeten op UTF-8-sequentiegrenzen liggen.
    ///
    /// Als dat niet lukt, kan de geretourneerde stringplak verwijzen naar ongeldig geheugen of de invarianten schenden die worden gecommuniceerd door het `str`-type.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let v = "🗻∈🌏";
    /// unsafe {
    ///     assert_eq!("🗻", v.get_unchecked(0..4));
    ///     assert_eq!("∈", v.get_unchecked(4..7));
    ///     assert_eq!("🌏", v.get_unchecked(7..11));
    /// }
    /// ```
    ///
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub unsafe fn get_unchecked<I: SliceIndex<str>>(&self, i: I) -> &I::Output {
        // VEILIGHEID: de beller moet zich houden aan het veiligheidscontract voor `get_unchecked`;
        // het segment kan worden ontkoppeld omdat `self` een veilige referentie is.
        // De geretourneerde pointer is veilig omdat impls van `SliceIndex` moeten garanderen dat dit zo is.
        unsafe { &*i.get_unchecked(self) }
    }

    /// Retourneert een veranderlijk, ongecontroleerd subdeel van `str`.
    ///
    /// Dit is het ongecontroleerde alternatief voor het indexeren van de `str`.
    ///
    /// # Safety
    ///
    /// Bellers van deze functie zijn ervoor verantwoordelijk dat aan deze voorwaarden is voldaan:
    ///
    /// * De startindex mag de eindindex niet overschrijden;
    /// * Indexen moeten binnen de grenzen van het originele segment liggen;
    /// * Indexen moeten op UTF-8-sequentiegrenzen liggen.
    ///
    /// Als dat niet lukt, kan de geretourneerde stringplak verwijzen naar ongeldig geheugen of de invarianten schenden die worden gecommuniceerd door het `str`-type.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = String::from("🗻∈🌏");
    /// unsafe {
    ///     assert_eq!("🗻", v.get_unchecked_mut(0..4));
    ///     assert_eq!("∈", v.get_unchecked_mut(4..7));
    ///     assert_eq!("🌏", v.get_unchecked_mut(7..11));
    /// }
    /// ```
    ///
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I: SliceIndex<str>>(&mut self, i: I) -> &mut I::Output {
        // VEILIGHEID: de beller moet zich houden aan het veiligheidscontract voor `get_unchecked_mut`;
        // het segment kan worden ontkoppeld omdat `self` een veilige referentie is.
        // De geretourneerde pointer is veilig omdat impls van `SliceIndex` moeten garanderen dat dit zo is.
        unsafe { &mut *i.get_unchecked_mut(self) }
    }

    /// Maakt een stringplak van een ander stringplak en omzeilt veiligheidscontroles.
    ///
    /// Dit wordt over het algemeen niet aanbevolen, wees voorzichtig!Zie [`str`] en [`Index`] voor een veilig alternatief.
    ///
    ///
    /// [`Index`]: crate::ops::Index
    ///
    /// Dit nieuwe segment gaat van `begin` naar `end`, inclusief `begin` maar exclusief `end`.
    ///
    /// Zie de [`slice_mut_unchecked`]-methode om in plaats daarvan een veranderlijke string-slice te krijgen.
    ///
    /// [`slice_mut_unchecked`]: str::slice_mut_unchecked
    ///
    /// # Safety
    ///
    /// Bellers van deze functie zijn ervoor verantwoordelijk dat aan drie voorwaarden is voldaan:
    ///
    /// * `begin` mag niet groter zijn dan `end`.
    /// * `begin` en `end` moeten byteposities binnen de stringplak zijn.
    /// * `begin` en `end` moet op de sequentiegrenzen van UTF-8 liggen.
    ///
    /// # Examples
    ///
    /// Basisgebruik:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// unsafe {
    ///     assert_eq!("Löwe 老虎 Léopard", s.slice_unchecked(0, 21));
    /// }
    ///
    /// let s = "Hello, world!";
    ///
    /// unsafe {
    ///     assert_eq!("world", s.slice_unchecked(7, 12));
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.29.0", reason = "use `get_unchecked(begin..end)` instead")]
    #[inline]
    pub unsafe fn slice_unchecked(&self, begin: usize, end: usize) -> &str {
        // VEILIGHEID: de beller moet zich houden aan het veiligheidscontract voor `get_unchecked`;
        // het segment kan worden ontkoppeld omdat `self` een veilige referentie is.
        // De geretourneerde pointer is veilig omdat impls van `SliceIndex` moeten garanderen dat dit zo is.
        unsafe { &*(begin..end).get_unchecked(self) }
    }

    /// Maakt een stringplak van een ander stringplak en omzeilt veiligheidscontroles.
    /// Dit wordt over het algemeen niet aanbevolen, wees voorzichtig!Zie [`str`] en [`IndexMut`] voor een veilig alternatief.
    ///
    ///
    /// [`IndexMut`]: crate::ops::IndexMut
    ///
    /// Dit nieuwe segment gaat van `begin` naar `end`, inclusief `begin` maar exclusief `end`.
    ///
    /// Zie de [`slice_unchecked`]-methode om in plaats daarvan een onveranderlijke string-slice te krijgen.
    ///
    /// [`slice_unchecked`]: str::slice_unchecked
    ///
    /// # Safety
    ///
    /// Bellers van deze functie zijn ervoor verantwoordelijk dat aan drie voorwaarden is voldaan:
    ///
    /// * `begin` mag niet groter zijn dan `end`.
    /// * `begin` en `end` moeten byteposities binnen de stringplak zijn.
    /// * `begin` en `end` moet op de sequentiegrenzen van UTF-8 liggen.
    ///
    ///
    ///
    ///
    #[stable(feature = "str_slice_mut", since = "1.5.0")]
    #[rustc_deprecated(since = "1.29.0", reason = "use `get_unchecked_mut(begin..end)` instead")]
    #[inline]
    pub unsafe fn slice_mut_unchecked(&mut self, begin: usize, end: usize) -> &mut str {
        // VEILIGHEID: de beller moet zich houden aan het veiligheidscontract voor `get_unchecked_mut`;
        // het segment kan worden ontkoppeld omdat `self` een veilige referentie is.
        // De geretourneerde pointer is veilig omdat impls van `SliceIndex` moeten garanderen dat dit zo is.
        unsafe { &mut *(begin..end).get_unchecked_mut(self) }
    }

    /// Verdeel een snaarschijf in twee bij een index.
    ///
    /// Het argument, `mid`, moet een byte-offset zijn vanaf het begin van de tekenreeks.
    /// Het moet zich ook op de grens van een UTF-8-codepunt bevinden.
    ///
    /// De twee geretourneerde segmenten gaan van het begin van de string slice naar `mid` en van `mid` naar het einde van de string slice.
    ///
    /// Zie de [`split_at_mut`]-methode om in plaats daarvan veranderlijke stringplakken te krijgen.
    ///
    /// [`split_at_mut`]: str::split_at_mut
    ///
    /// # Panics
    ///
    /// Panics als `mid` zich niet op een UTF-8 codepuntgrens bevindt, of als het voorbij het einde van het laatste codepunt van de stringplak is.
    ///
    ///
    /// # Examples
    ///
    /// Basisgebruik:
    ///
    /// ```
    /// let s = "Per Martin-Löf";
    ///
    /// let (first, last) = s.split_at(3);
    ///
    /// assert_eq!("Per", first);
    /// assert_eq!(" Martin-Löf", last);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "str_split_at", since = "1.4.0")]
    pub fn split_at(&self, mid: usize) -> (&str, &str) {
        // is_char_boundary controleert of de index in [0, .len()]
        if self.is_char_boundary(mid) {
            // VEILIGHEID: heb net gecontroleerd of `mid` zich op een tekengrens bevindt.
            unsafe { (self.get_unchecked(0..mid), self.get_unchecked(mid..self.len())) }
        } else {
            slice_error_fail(self, 0, mid)
        }
    }

    /// Verdeel een veranderlijke snaarschijf in twee bij een index.
    ///
    /// Het argument, `mid`, moet een byte-offset zijn vanaf het begin van de tekenreeks.
    /// Het moet zich ook op de grens van een UTF-8-codepunt bevinden.
    ///
    /// De twee geretourneerde segmenten gaan van het begin van de string slice naar `mid` en van `mid` naar het einde van de string slice.
    ///
    /// Zie de [`split_at`]-methode om in plaats daarvan onveranderlijke stringplakken te krijgen.
    ///
    /// [`split_at`]: str::split_at
    ///
    /// # Panics
    ///
    /// Panics als `mid` zich niet op een UTF-8 codepuntgrens bevindt, of als het voorbij het einde van het laatste codepunt van de stringplak is.
    ///
    ///
    /// # Examples
    ///
    /// Basisgebruik:
    ///
    /// ```
    /// let mut s = "Per Martin-Löf".to_string();
    /// {
    ///     let (first, last) = s.split_at_mut(3);
    ///     first.make_ascii_uppercase();
    ///     assert_eq!("PER", first);
    ///     assert_eq!(" Martin-Löf", last);
    /// }
    /// assert_eq!("PER Martin-Löf", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "str_split_at", since = "1.4.0")]
    pub fn split_at_mut(&mut self, mid: usize) -> (&mut str, &mut str) {
        // is_char_boundary controleert of de index in [0, .len()]
        if self.is_char_boundary(mid) {
            let len = self.len();
            let ptr = self.as_mut_ptr();
            // VEILIGHEID: heb net gecontroleerd of `mid` zich op een tekengrens bevindt.
            unsafe {
                (
                    from_utf8_unchecked_mut(slice::from_raw_parts_mut(ptr, mid)),
                    from_utf8_unchecked_mut(slice::from_raw_parts_mut(ptr.add(mid), len - mid)),
                )
            }
        } else {
            slice_error_fail(self, 0, mid)
        }
    }

    /// Geeft een iterator terug over de [`char`] s van een string slice.
    ///
    /// Omdat een stringplak uit geldige UTF-8 bestaat, kunnen we door een stringplak doorlopen met [`char`].
    /// Deze methode retourneert zo'n iterator.
    ///
    /// Het is belangrijk om te onthouden dat [`char`] een Unicode-scalaire waarde vertegenwoordigt en mogelijk niet overeenkomt met uw idee van wat een 'character' is.
    ///
    /// Iteratie over grafeemclusters is misschien wat u eigenlijk wilt.
    /// Deze functionaliteit wordt niet geleverd door de standaardbibliotheek van Rust, controleer in plaats daarvan crates.io.
    ///
    /// # Examples
    ///
    /// Basisgebruik:
    ///
    /// ```
    /// let word = "goodbye";
    ///
    /// let count = word.chars().count();
    /// assert_eq!(7, count);
    ///
    /// let mut chars = word.chars();
    ///
    /// assert_eq!(Some('g'), chars.next());
    /// assert_eq!(Some('o'), chars.next());
    /// assert_eq!(Some('o'), chars.next());
    /// assert_eq!(Some('d'), chars.next());
    /// assert_eq!(Some('b'), chars.next());
    /// assert_eq!(Some('y'), chars.next());
    /// assert_eq!(Some('e'), chars.next());
    ///
    /// assert_eq!(None, chars.next());
    /// ```
    ///
    /// Onthoud dat [`char`] s mogelijk niet overeenkomen met uw intuïtie over karakters:
    ///
    /// [`char`]: prim@char
    ///
    /// ```
    /// let y = "y̆";
    ///
    /// let mut chars = y.chars();
    ///
    /// assert_eq!(Some('y'), chars.next()); // niet 'y̆'
    /// assert_eq!(Some('\u{0306}'), chars.next());
    ///
    /// assert_eq!(None, chars.next());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chars(&self) -> Chars<'_> {
        Chars { iter: self.as_bytes().iter() }
    }

    /// Geeft een iterator terug over de [`char`] s van een string slice, en hun posities.
    ///
    /// Omdat een stringplak uit geldige UTF-8 bestaat, kunnen we door een stringplak doorlopen met [`char`].
    /// Deze methode retourneert een iterator van beide [`char`] s, evenals hun byteposities.
    ///
    /// De iterator levert tupels op.De positie is eerste, de [`char`] is de tweede.
    ///
    /// # Examples
    ///
    /// Basisgebruik:
    ///
    /// ```
    /// let word = "goodbye";
    ///
    /// let count = word.char_indices().count();
    /// assert_eq!(7, count);
    ///
    /// let mut char_indices = word.char_indices();
    ///
    /// assert_eq!(Some((0, 'g')), char_indices.next());
    /// assert_eq!(Some((1, 'o')), char_indices.next());
    /// assert_eq!(Some((2, 'o')), char_indices.next());
    /// assert_eq!(Some((3, 'd')), char_indices.next());
    /// assert_eq!(Some((4, 'b')), char_indices.next());
    /// assert_eq!(Some((5, 'y')), char_indices.next());
    /// assert_eq!(Some((6, 'e')), char_indices.next());
    ///
    /// assert_eq!(None, char_indices.next());
    /// ```
    ///
    /// Onthoud dat [`char`] s mogelijk niet overeenkomen met uw intuïtie over karakters:
    ///
    /// [`char`]: prim@char
    ///
    /// ```
    /// let yes = "y̆es";
    ///
    /// let mut char_indices = yes.char_indices();
    ///
    /// assert_eq!(Some((0, 'y')), char_indices.next()); // niet (0, 'y̆')
    /// assert_eq!(Some((1, '\u{0306}')), char_indices.next());
    ///
    /// // let op de 3 hier, het laatste teken nam twee bytes in beslag
    /// assert_eq!(Some((3, 'e')), char_indices.next());
    /// assert_eq!(Some((4, 's')), char_indices.next());
    ///
    /// assert_eq!(None, char_indices.next());
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn char_indices(&self) -> CharIndices<'_> {
        CharIndices { front_offset: 0, iter: self.chars() }
    }

    /// Een iterator over de bytes van een stringplak.
    ///
    /// Omdat een string slice uit een reeks bytes bestaat, kunnen we een string slice voor byte doorlopen.
    /// Deze methode retourneert zo'n iterator.
    ///
    /// # Examples
    ///
    /// Basisgebruik:
    ///
    /// ```
    /// let mut bytes = "bors".bytes();
    ///
    /// assert_eq!(Some(b'b'), bytes.next());
    /// assert_eq!(Some(b'o'), bytes.next());
    /// assert_eq!(Some(b'r'), bytes.next());
    /// assert_eq!(Some(b's'), bytes.next());
    ///
    /// assert_eq!(None, bytes.next());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn bytes(&self) -> Bytes<'_> {
        Bytes(self.as_bytes().iter().copied())
    }

    /// Splitst een string segment door witruimte.
    ///
    /// De geretourneerde iterator retourneert stringplakken die subsegmenten zijn van het originele stringplak, gescheiden door een willekeurige hoeveelheid witruimte.
    ///
    ///
    /// 'Whitespace' wordt gedefinieerd volgens de voorwaarden van de Unicode Derived Core Property `White_Space`.
    /// Als u in plaats daarvan alleen wilt splitsen op ASCII-witruimte, gebruikt u [`split_ascii_whitespace`].
    ///
    /// [`split_ascii_whitespace`]: str::split_ascii_whitespace
    ///
    /// # Examples
    ///
    /// Basisgebruik:
    ///
    /// ```
    /// let mut iter = "A few words".split_whitespace();
    ///
    /// assert_eq!(Some("A"), iter.next());
    /// assert_eq!(Some("few"), iter.next());
    /// assert_eq!(Some("words"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    /// Er wordt rekening gehouden met alle soorten witruimte:
    ///
    /// ```
    /// let mut iter = " Mary   had\ta\u{2009}little  \n\t lamb".split_whitespace();
    /// assert_eq!(Some("Mary"), iter.next());
    /// assert_eq!(Some("had"), iter.next());
    /// assert_eq!(Some("a"), iter.next());
    /// assert_eq!(Some("little"), iter.next());
    /// assert_eq!(Some("lamb"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[stable(feature = "split_whitespace", since = "1.1.0")]
    #[inline]
    pub fn split_whitespace(&self) -> SplitWhitespace<'_> {
        SplitWhitespace { inner: self.split(IsWhitespace).filter(IsNotEmpty) }
    }

    /// Splitst een string-segment op basis van ASCII-witruimte.
    ///
    /// De geretourneerde iterator retourneert stringsegmenten die subsegmenten zijn van het oorspronkelijke reekssegment, gescheiden door een willekeurige hoeveelheid ASCII-witruimte.
    ///
    ///
    /// Gebruik [`split_whitespace`] om in plaats daarvan te splitsen op Unicode `Whitespace`.
    ///
    /// [`split_whitespace`]: str::split_whitespace
    ///
    /// # Examples
    ///
    /// Basisgebruik:
    ///
    /// ```
    /// let mut iter = "A few words".split_ascii_whitespace();
    ///
    /// assert_eq!(Some("A"), iter.next());
    /// assert_eq!(Some("few"), iter.next());
    /// assert_eq!(Some("words"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    /// Er wordt rekening gehouden met alle soorten ASCII-witruimte:
    ///
    /// ```
    /// let mut iter = " Mary   had\ta little  \n\t lamb".split_ascii_whitespace();
    /// assert_eq!(Some("Mary"), iter.next());
    /// assert_eq!(Some("had"), iter.next());
    /// assert_eq!(Some("a"), iter.next());
    /// assert_eq!(Some("little"), iter.next());
    /// assert_eq!(Some("lamb"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    #[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
    #[inline]
    pub fn split_ascii_whitespace(&self) -> SplitAsciiWhitespace<'_> {
        let inner =
            self.as_bytes().split(IsAsciiWhitespace).filter(BytesIsNotEmpty).map(UnsafeBytesToStr);
        SplitAsciiWhitespace { inner }
    }

    /// Een iterator over de lijnen van een string, als stringplakken.
    ///
    /// Regels worden afgesloten met een nieuwe regel (`\n`) of een regelterugloop met een regelinvoer (`\r\n`).
    ///
    /// Het einde van de laatste regel is optioneel.
    /// Een tekenreeks die eindigt met het einde van een laatste regel, retourneert dezelfde regels als een verder identieke tekenreeks zonder het einde van een laatste regel.
    ///
    ///
    /// # Examples
    ///
    /// Basisgebruik:
    ///
    /// ```
    /// let text = "foo\r\nbar\n\nbaz\n";
    /// let mut lines = text.lines();
    ///
    /// assert_eq!(Some("foo"), lines.next());
    /// assert_eq!(Some("bar"), lines.next());
    /// assert_eq!(Some(""), lines.next());
    /// assert_eq!(Some("baz"), lines.next());
    ///
    /// assert_eq!(None, lines.next());
    /// ```
    ///
    /// Het einde van de laatste regel is niet vereist:
    ///
    /// ```
    /// let text = "foo\nbar\n\r\nbaz";
    /// let mut lines = text.lines();
    ///
    /// assert_eq!(Some("foo"), lines.next());
    /// assert_eq!(Some("bar"), lines.next());
    /// assert_eq!(Some(""), lines.next());
    /// assert_eq!(Some("baz"), lines.next());
    ///
    /// assert_eq!(None, lines.next());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn lines(&self) -> Lines<'_> {
        Lines(self.split_terminator('\n').map(LinesAnyMap))
    }

    /// Een iterator over de lijnen van een string.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.4.0", reason = "use lines() instead now")]
    #[inline]
    #[allow(deprecated)]
    pub fn lines_any(&self) -> LinesAny<'_> {
        LinesAny(self.lines())
    }

    /// Retourneert een iterator van `u16` over de tekenreeks die is gecodeerd als UTF-16.
    ///
    /// # Examples
    ///
    /// Basisgebruik:
    ///
    /// ```
    /// let text = "Zażółć gęślą jaźń";
    ///
    /// let utf8_len = text.len();
    /// let utf16_len = text.encode_utf16().count();
    ///
    /// assert!(utf16_len <= utf8_len);
    /// ```
    #[stable(feature = "encode_utf16", since = "1.8.0")]
    pub fn encode_utf16(&self) -> EncodeUtf16<'_> {
        EncodeUtf16 { chars: self.chars(), extra: 0 }
    }

    /// Geeft `true` terug als het gegeven patroon overeenkomt met een sub-segment van dit string-segment.
    ///
    /// Retourneert `false` als dat niet het geval is.
    ///
    /// De [pattern] kan een `&str`, [`char`] zijn, een stuk [`char`] s, of een functie of sluiting die bepaalt of een teken overeenkomt.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Basisgebruik:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.contains("nana"));
    /// assert!(!bananas.contains("apples"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn contains<'a, P: Pattern<'a>>(&'a self, pat: P) -> bool {
        pat.is_contained_in(self)
    }

    /// Retourneert `true` als het opgegeven patroon overeenkomt met een voorvoegsel van deze tekenreeks.
    ///
    /// Retourneert `false` als dat niet het geval is.
    ///
    /// De [pattern] kan een `&str`, [`char`] zijn, een stuk [`char`] s, of een functie of sluiting die bepaalt of een teken overeenkomt.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Basisgebruik:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.starts_with("bana"));
    /// assert!(!bananas.starts_with("nana"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn starts_with<'a, P: Pattern<'a>>(&'a self, pat: P) -> bool {
        pat.is_prefix_of(self)
    }

    /// Retourneert `true` als het opgegeven patroon overeenkomt met een achtervoegsel van deze tekenreeks.
    ///
    /// Retourneert `false` als dat niet het geval is.
    ///
    /// De [pattern] kan een `&str`, [`char`] zijn, een stuk [`char`] s, of een functie of sluiting die bepaalt of een teken overeenkomt.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Basisgebruik:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.ends_with("anas"));
    /// assert!(!bananas.ends_with("nana"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ends_with<'a, P>(&'a self, pat: P) -> bool
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        pat.is_suffix_of(self)
    }

    /// Retourneert de byte-index van het eerste teken van deze stringplak die overeenkomt met het patroon.
    ///
    /// Retourneert [`None`] als het patroon niet overeenkomt.
    ///
    /// De [pattern] kan een `&str`, [`char`] zijn, een stuk [`char`] s, of een functie of sluiting die bepaalt of een teken overeenkomt.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Eenvoudige patronen:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard Gepardi";
    ///
    /// assert_eq!(s.find('L'), Some(0));
    /// assert_eq!(s.find('é'), Some(14));
    /// assert_eq!(s.find("pard"), Some(17));
    /// ```
    ///
    /// Complexere patronen met puntloze stijl en sluitingen:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// assert_eq!(s.find(char::is_whitespace), Some(5));
    /// assert_eq!(s.find(char::is_lowercase), Some(1));
    /// assert_eq!(s.find(|c: char| c.is_whitespace() || c.is_lowercase()), Some(1));
    /// assert_eq!(s.find(|c: char| (c < 'o') && (c > 'a')), Some(4));
    /// ```
    ///
    /// Het patroon niet vinden:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// let x: &[_] = &['1', '2'];
    ///
    /// assert_eq!(s.find(x), None);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn find<'a, P: Pattern<'a>>(&'a self, pat: P) -> Option<usize> {
        pat.into_searcher(self).next_match().map(|(i, _)| i)
    }

    /// Retourneert de byte-index voor het eerste teken van de meest rechtse overeenkomst van het patroon in deze stringplak.
    ///
    /// Retourneert [`None`] als het patroon niet overeenkomt.
    ///
    /// De [pattern] kan een `&str`, [`char`] zijn, een stuk [`char`] s, of een functie of sluiting die bepaalt of een teken overeenkomt.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Eenvoudige patronen:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard Gepardi";
    ///
    /// assert_eq!(s.rfind('L'), Some(13));
    /// assert_eq!(s.rfind('é'), Some(14));
    /// assert_eq!(s.rfind("pard"), Some(24));
    /// ```
    ///
    /// Meer complexe patronen met sluitingen:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// assert_eq!(s.rfind(char::is_whitespace), Some(12));
    /// assert_eq!(s.rfind(char::is_lowercase), Some(20));
    /// ```
    ///
    /// Het patroon niet vinden:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// let x: &[_] = &['1', '2'];
    ///
    /// assert_eq!(s.rfind(x), None);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rfind<'a, P>(&'a self, pat: P) -> Option<usize>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        pat.into_searcher(self).next_match_back().map(|(i, _)| i)
    }

    /// Een iterator over subtekenreeksen van deze stringplak, gescheiden door tekens die overeenkomen met een patroon.
    ///
    /// De [pattern] kan een `&str`, [`char`] zijn, een stuk [`char`] s, of een functie of sluiting die bepaalt of een teken overeenkomt.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Iterator gedrag
    ///
    /// De geretourneerde iterator is een [`DoubleEndedIterator`] als het patroon een omgekeerde zoekopdracht toestaat en forward/reverse-zoekopdracht dezelfde elementen oplevert.
    /// Dit geldt bijvoorbeeld voor [`char`], maar niet voor `&str`.
    ///
    /// Als het patroon een omgekeerde zoekopdracht toestaat, maar de resultaten kunnen verschillen van een voorwaartse zoekopdracht, kan de [`rsplit`]-methode worden gebruikt.
    ///
    /// [`rsplit`]: str::rsplit
    ///
    /// # Examples
    ///
    /// Eenvoudige patronen:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".split(' ').collect();
    /// assert_eq!(v, ["Mary", "had", "a", "little", "lamb"]);
    ///
    /// let v: Vec<&str> = "".split('X').collect();
    /// assert_eq!(v, [""]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".split('X').collect();
    /// assert_eq!(v, ["lion", "", "tiger", "leopard"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".split("::").collect();
    /// assert_eq!(v, ["lion", "tiger", "leopard"]);
    ///
    /// let v: Vec<&str> = "abc1def2ghi".split(char::is_numeric).collect();
    /// assert_eq!(v, ["abc", "def", "ghi"]);
    ///
    /// let v: Vec<&str> = "lionXtigerXleopard".split(char::is_uppercase).collect();
    /// assert_eq!(v, ["lion", "tiger", "leopard"]);
    /// ```
    ///
    /// Als het patroon een segment van tekens is, splitst u op elk voorkomen van een van de tekens:
    ///
    /// ```
    /// let v: Vec<&str> = "2020-11-03 23:59".split(&['-', ' ', ':', '@'][..]).collect();
    /// assert_eq!(v, ["2020", "11", "03", "23", "59"]);
    /// ```
    ///
    /// Een complexer patroon, met een sluiting:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".split(|c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["abc", "def", "ghi"]);
    /// ```
    ///
    /// Als een string meerdere aaneengesloten scheidingstekens bevat, krijg je lege strings in de uitvoer:
    ///
    /// ```
    /// let x = "||||a||b|c".to_string();
    /// let d: Vec<_> = x.split('|').collect();
    ///
    /// assert_eq!(d, &["", "", "", "", "a", "", "b", "c"]);
    /// ```
    ///
    /// Aaneengesloten scheidingstekens worden gescheiden door de lege tekenreeks.
    ///
    /// ```
    /// let x = "(///)".to_string();
    /// let d: Vec<_> = x.split('/').collect();
    ///
    /// assert_eq!(d, &["(", "", "", ")"]);
    /// ```
    ///
    /// Scheidingstekens aan het begin of einde van een tekenreeks worden begrensd door lege tekenreeksen.
    ///
    /// ```
    /// let d: Vec<_> = "010".split("0").collect();
    /// assert_eq!(d, &["", "1", ""]);
    /// ```
    ///
    /// Als de lege tekenreeks als scheidingsteken wordt gebruikt, wordt elk teken in de tekenreeks gescheiden, samen met het begin en het einde van de tekenreeks.
    ///
    /// ```
    /// let f: Vec<_> = "rust".split("").collect();
    /// assert_eq!(f, &["", "r", "u", "s", "t", ""]);
    /// ```
    ///
    /// Aaneengesloten scheidingstekens kunnen tot mogelijk verrassend gedrag leiden wanneer witruimte als scheidingsteken wordt gebruikt.Deze code is correct:
    ///
    /// ```
    /// let x = "    a  b c".to_string();
    /// let d: Vec<_> = x.split(' ').collect();
    ///
    /// assert_eq!(d, &["", "", "", "", "a", "", "b", "c"]);
    /// ```
    ///
    /// Het geeft _not_ u:
    ///
    /// ```,ignore
    /// assert_eq!(d, &["a", "b", "c"]);
    /// ```
    ///
    /// Gebruik [`split_whitespace`] voor dit gedrag.
    ///
    /// [`split_whitespace`]: str::split_whitespace
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split<'a, P: Pattern<'a>>(&'a self, pat: P) -> Split<'a, P> {
        Split(SplitInternal {
            start: 0,
            end: self.len(),
            matcher: pat.into_searcher(self),
            allow_trailing_empty: true,
            finished: false,
        })
    }

    /// Een iterator over subtekenreeksen van deze stringplak, gescheiden door tekens die overeenkomen met een patroon.
    /// Verschilt van de iterator geproduceerd door `split` doordat `split_inclusive` het overeenkomende deel verlaat als de terminator van de substring.
    ///
    ///
    /// De [pattern] kan een `&str`, [`char`] zijn, een stuk [`char`] s, of een functie of sluiting die bepaalt of een teken overeenkomt.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb\nlittle lamb\nlittle lamb."
    ///     .split_inclusive('\n').collect();
    /// assert_eq!(v, ["Mary had a little lamb\n", "little lamb\n", "little lamb."]);
    /// ```
    ///
    /// Als het laatste element van de string overeenkomt, wordt dat element beschouwd als de terminator van de voorgaande substring.
    /// Die substring is het laatste item dat door de iterator wordt geretourneerd.
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb\nlittle lamb\nlittle lamb.\n"
    ///     .split_inclusive('\n').collect();
    /// assert_eq!(v, ["Mary had a little lamb\n", "little lamb\n", "little lamb.\n"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive<'a, P: Pattern<'a>>(&'a self, pat: P) -> SplitInclusive<'a, P> {
        SplitInclusive(SplitInternal {
            start: 0,
            end: self.len(),
            matcher: pat.into_searcher(self),
            allow_trailing_empty: false,
            finished: false,
        })
    }

    /// Een iterator over subtekenreeksen van de gegeven stringplak, gescheiden door tekens die overeenkomen met een patroon en in omgekeerde volgorde worden weergegeven.
    ///
    /// De [pattern] kan een `&str`, [`char`] zijn, een stuk [`char`] s, of een functie of sluiting die bepaalt of een teken overeenkomt.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Iterator gedrag
    ///
    /// De geretourneerde iterator vereist dat het patroon omgekeerd zoeken ondersteunt, en het zal een [`DoubleEndedIterator`] zijn als een forward/reverse-zoekopdracht dezelfde elementen oplevert.
    ///
    ///
    /// Voor iteratie vanaf de voorkant kan de [`split`]-methode worden gebruikt.
    ///
    /// [`split`]: str::split
    ///
    /// # Examples
    ///
    /// Eenvoudige patronen:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".rsplit(' ').collect();
    /// assert_eq!(v, ["lamb", "little", "a", "had", "Mary"]);
    ///
    /// let v: Vec<&str> = "".rsplit('X').collect();
    /// assert_eq!(v, [""]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".rsplit('X').collect();
    /// assert_eq!(v, ["leopard", "tiger", "", "lion"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".rsplit("::").collect();
    /// assert_eq!(v, ["leopard", "tiger", "lion"]);
    /// ```
    ///
    /// Een complexer patroon, met een sluiting:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".rsplit(|c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["ghi", "def", "abc"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplit<'a, P>(&'a self, pat: P) -> RSplit<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplit(self.split(pat).0)
    }

    /// Een iterator over subtekenreeksen van de gegeven stringplak, gescheiden door tekens die overeenkomen met een patroon.
    ///
    /// De [pattern] kan een `&str`, [`char`] zijn, een stuk [`char`] s, of een functie of sluiting die bepaalt of een teken overeenkomt.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// Equivalent aan [`split`], behalve dat de afsluitende subtekenreeks wordt overgeslagen als deze leeg is.
    ///
    /// [`split`]: str::split
    ///
    /// Deze methode kan worden gebruikt voor stringgegevens die _terminated_ zijn, in plaats van _separated_ met een patroon.
    ///
    /// # Iterator gedrag
    ///
    /// De geretourneerde iterator is een [`DoubleEndedIterator`] als het patroon een omgekeerde zoekopdracht toestaat en forward/reverse-zoekopdracht dezelfde elementen oplevert.
    /// Dit geldt bijvoorbeeld voor [`char`], maar niet voor `&str`.
    ///
    /// Als het patroon een omgekeerde zoekopdracht toestaat, maar de resultaten kunnen verschillen van een voorwaartse zoekopdracht, kan de [`rsplit_terminator`]-methode worden gebruikt.
    ///
    /// [`rsplit_terminator`]: str::rsplit_terminator
    ///
    /// # Examples
    ///
    /// Basisgebruik:
    ///
    /// ```
    /// let v: Vec<&str> = "A.B.".split_terminator('.').collect();
    /// assert_eq!(v, ["A", "B"]);
    ///
    /// let v: Vec<&str> = "A..B..".split_terminator(".").collect();
    /// assert_eq!(v, ["A", "", "B", ""]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_terminator<'a, P: Pattern<'a>>(&'a self, pat: P) -> SplitTerminator<'a, P> {
        SplitTerminator(SplitInternal { allow_trailing_empty: false, ..self.split(pat).0 })
    }

    /// Een iterator over subtekenreeksen van `self`, gescheiden door tekens die overeenkomen met een patroon en in omgekeerde volgorde worden weergegeven.
    ///
    /// De [pattern] kan een `&str`, [`char`] zijn, een stuk [`char`] s, of een functie of sluiting die bepaalt of een teken overeenkomt.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// Equivalent aan [`split`], behalve dat de afsluitende subtekenreeks wordt overgeslagen als deze leeg is.
    ///
    /// [`split`]: str::split
    ///
    /// Deze methode kan worden gebruikt voor stringgegevens die _terminated_ zijn, in plaats van _separated_ met een patroon.
    ///
    /// # Iterator gedrag
    ///
    /// De geretourneerde iterator vereist dat het patroon omgekeerd zoeken ondersteunt, en het zal dubbel worden beëindigd als een forward/reverse-zoekopdracht dezelfde elementen oplevert.
    ///
    ///
    /// Voor iteratie vanaf de voorkant kan de [`split_terminator`]-methode worden gebruikt.
    ///
    /// [`split_terminator`]: str::split_terminator
    ///
    /// # Examples
    ///
    /// ```
    /// let v: Vec<&str> = "A.B.".rsplit_terminator('.').collect();
    /// assert_eq!(v, ["B", "A"]);
    ///
    /// let v: Vec<&str> = "A..B..".rsplit_terminator(".").collect();
    /// assert_eq!(v, ["", "B", "", "A"]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplit_terminator<'a, P>(&'a self, pat: P) -> RSplitTerminator<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplitTerminator(self.split_terminator(pat).0)
    }

    /// Een iterator over subtekenreeksen van de opgegeven tekenreeks, gescheiden door een patroon, beperkt tot het retourneren van maximaal `n`-items.
    ///
    /// Als `n`-subtekenreeksen worden geretourneerd, bevat de laatste subtekenreeks (de `n`de substring) de rest van de string.
    ///
    /// De [pattern] kan een `&str`, [`char`] zijn, een stuk [`char`] s, of een functie of sluiting die bepaalt of een teken overeenkomt.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Iterator gedrag
    ///
    /// De geretourneerde iterator zal niet dubbel worden beëindigd, omdat het niet efficiënt is om te ondersteunen.
    ///
    /// Als het patroon omgekeerd zoeken toestaat, kan de [`rsplitn`]-methode worden gebruikt.
    ///
    /// [`rsplitn`]: str::rsplitn
    ///
    /// # Examples
    ///
    /// Eenvoudige patronen:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lambda".splitn(3, ' ').collect();
    /// assert_eq!(v, ["Mary", "had", "a little lambda"]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".splitn(3, "X").collect();
    /// assert_eq!(v, ["lion", "", "tigerXleopard"]);
    ///
    /// let v: Vec<&str> = "abcXdef".splitn(1, 'X').collect();
    /// assert_eq!(v, ["abcXdef"]);
    ///
    /// let v: Vec<&str> = "".splitn(1, 'X').collect();
    /// assert_eq!(v, [""]);
    /// ```
    ///
    /// Een complexer patroon, met een sluiting:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".splitn(2, |c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["abc", "defXghi"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn<'a, P: Pattern<'a>>(&'a self, n: usize, pat: P) -> SplitN<'a, P> {
        SplitN(SplitNInternal { iter: self.split(pat).0, count: n })
    }

    /// Een iterator over subtekenreeksen van deze stringplak, gescheiden door een patroon, beginnend vanaf het einde van de string, beperkt tot het retourneren van maximaal `n`-items.
    ///
    ///
    /// Als `n`-subtekenreeksen worden geretourneerd, bevat de laatste subtekenreeks (de `n`de substring) de rest van de string.
    ///
    /// De [pattern] kan een `&str`, [`char`] zijn, een stuk [`char`] s, of een functie of sluiting die bepaalt of een teken overeenkomt.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Iterator gedrag
    ///
    /// De geretourneerde iterator zal niet dubbel worden beëindigd, omdat het niet efficiënt is om te ondersteunen.
    ///
    /// Voor het splitsen van voren kan de [`splitn`]-methode worden gebruikt.
    ///
    /// [`splitn`]: str::splitn
    ///
    /// # Examples
    ///
    /// Eenvoudige patronen:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".rsplitn(3, ' ').collect();
    /// assert_eq!(v, ["lamb", "little", "Mary had a"]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".rsplitn(3, 'X').collect();
    /// assert_eq!(v, ["leopard", "tiger", "lionX"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".rsplitn(2, "::").collect();
    /// assert_eq!(v, ["leopard", "lion::tiger"]);
    /// ```
    ///
    /// Een complexer patroon, met een sluiting:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".rsplitn(2, |c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["ghi", "abc1def"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn<'a, P>(&'a self, n: usize, pat: P) -> RSplitN<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplitN(self.splitn(n, pat).0)
    }

    /// Splitst de tekenreeks bij de eerste keer dat het opgegeven scheidingsteken voorkomt en retourneert een voorvoegsel vóór het scheidingsteken en een achtervoegsel na het scheidingsteken.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("cfg".split_once('='), None);
    /// assert_eq!("cfg=foo".split_once('='), Some(("cfg", "foo")));
    /// assert_eq!("cfg=foo=bar".split_once('='), Some(("cfg", "foo=bar")));
    /// ```
    #[stable(feature = "str_split_once", since = "1.52.0")]
    #[inline]
    pub fn split_once<'a, P: Pattern<'a>>(&'a self, delimiter: P) -> Option<(&'a str, &'a str)> {
        let (start, end) = delimiter.into_searcher(self).next_match()?;
        Some((&self[..start], &self[end..]))
    }

    /// Splitst de tekenreeks op de laatste keer dat het opgegeven scheidingsteken voorkomt en retourneert een voorvoegsel vóór het scheidingsteken en een achtervoegsel na het scheidingsteken.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("cfg".rsplit_once('='), None);
    /// assert_eq!("cfg=foo".rsplit_once('='), Some(("cfg", "foo")));
    /// assert_eq!("cfg=foo=bar".rsplit_once('='), Some(("cfg=foo", "bar")));
    /// ```
    #[stable(feature = "str_split_once", since = "1.52.0")]
    #[inline]
    pub fn rsplit_once<'a, P>(&'a self, delimiter: P) -> Option<(&'a str, &'a str)>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        let (start, end) = delimiter.into_searcher(self).next_match_back()?;
        Some((&self[..start], &self[end..]))
    }

    /// Een iterator over de disjuncte overeenkomsten van een patroon binnen de gegeven stringplak.
    ///
    /// De [pattern] kan een `&str`, [`char`] zijn, een stuk [`char`] s, of een functie of sluiting die bepaalt of een teken overeenkomt.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Iterator gedrag
    ///
    /// De geretourneerde iterator is een [`DoubleEndedIterator`] als het patroon een omgekeerde zoekopdracht toestaat en forward/reverse-zoekopdracht dezelfde elementen oplevert.
    /// Dit geldt bijvoorbeeld voor [`char`], maar niet voor `&str`.
    ///
    /// Als het patroon een omgekeerde zoekopdracht toestaat, maar de resultaten kunnen verschillen van een voorwaartse zoekopdracht, kan de [`rmatches`]-methode worden gebruikt.
    ///
    /// [`rmatches`]: str::matches
    ///
    /// # Examples
    ///
    /// Basisgebruik:
    ///
    /// ```
    /// let v: Vec<&str> = "abcXXXabcYYYabc".matches("abc").collect();
    /// assert_eq!(v, ["abc", "abc", "abc"]);
    ///
    /// let v: Vec<&str> = "1abc2abc3".matches(char::is_numeric).collect();
    /// assert_eq!(v, ["1", "2", "3"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "str_matches", since = "1.2.0")]
    #[inline]
    pub fn matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> Matches<'a, P> {
        Matches(MatchesInternal(pat.into_searcher(self)))
    }

    /// Een iterator over de disjuncte overeenkomsten van een patroon binnen deze stringplak, die in omgekeerde volgorde wordt opgeleverd.
    ///
    /// De [pattern] kan een `&str`, [`char`] zijn, een stuk [`char`] s, of een functie of sluiting die bepaalt of een teken overeenkomt.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Iterator gedrag
    ///
    /// De geretourneerde iterator vereist dat het patroon omgekeerd zoeken ondersteunt, en het zal een [`DoubleEndedIterator`] zijn als een forward/reverse-zoekopdracht dezelfde elementen oplevert.
    ///
    ///
    /// Voor iteratie vanaf de voorkant kan de [`matches`]-methode worden gebruikt.
    ///
    /// [`matches`]: str::matches
    ///
    /// # Examples
    ///
    /// Basisgebruik:
    ///
    /// ```
    /// let v: Vec<&str> = "abcXXXabcYYYabc".rmatches("abc").collect();
    /// assert_eq!(v, ["abc", "abc", "abc"]);
    ///
    /// let v: Vec<&str> = "1abc2abc3".rmatches(char::is_numeric).collect();
    /// assert_eq!(v, ["3", "2", "1"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "str_matches", since = "1.2.0")]
    #[inline]
    pub fn rmatches<'a, P>(&'a self, pat: P) -> RMatches<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RMatches(self.matches(pat).0)
    }

    /// Een iterator over de disjuncte overeenkomsten van een patroon binnen deze stringplak, evenals de index waarmee de overeenkomst begint.
    ///
    /// Voor overeenkomsten van `pat` binnen `self` die elkaar overlappen, worden alleen de indices geretourneerd die overeenkomen met de eerste overeenkomst.
    ///
    /// De [pattern] kan een `&str`, [`char`] zijn, een stuk [`char`] s, of een functie of sluiting die bepaalt of een teken overeenkomt.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Iterator gedrag
    ///
    /// De geretourneerde iterator is een [`DoubleEndedIterator`] als het patroon een omgekeerde zoekopdracht toestaat en forward/reverse-zoekopdracht dezelfde elementen oplevert.
    /// Dit geldt bijvoorbeeld voor [`char`], maar niet voor `&str`.
    ///
    /// Als het patroon een omgekeerde zoekopdracht toestaat, maar de resultaten kunnen verschillen van een voorwaartse zoekopdracht, kan de [`rmatch_indices`]-methode worden gebruikt.
    ///
    /// [`rmatch_indices`]: str::match_indices
    ///
    /// # Examples
    ///
    /// Basisgebruik:
    ///
    /// ```
    /// let v: Vec<_> = "abcXXXabcYYYabc".match_indices("abc").collect();
    /// assert_eq!(v, [(0, "abc"), (6, "abc"), (12, "abc")]);
    ///
    /// let v: Vec<_> = "1abcabc2".match_indices("abc").collect();
    /// assert_eq!(v, [(1, "abc"), (4, "abc")]);
    ///
    /// let v: Vec<_> = "ababa".match_indices("aba").collect();
    /// assert_eq!(v, [(0, "aba")]); // alleen de eerste `aba`
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "str_match_indices", since = "1.5.0")]
    #[inline]
    pub fn match_indices<'a, P: Pattern<'a>>(&'a self, pat: P) -> MatchIndices<'a, P> {
        MatchIndices(MatchIndicesInternal(pat.into_searcher(self)))
    }

    /// Een iterator over de disjuncte overeenkomsten van een patroon binnen `self`, die in omgekeerde volgorde samen met de index van de overeenkomst wordt weergegeven.
    ///
    /// Voor overeenkomsten van `pat` binnen `self` die elkaar overlappen, worden alleen de indices geretourneerd die overeenkomen met de laatste overeenkomst.
    ///
    /// De [pattern] kan een `&str`, [`char`] zijn, een stuk [`char`] s, of een functie of sluiting die bepaalt of een teken overeenkomt.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Iterator gedrag
    ///
    /// De geretourneerde iterator vereist dat het patroon omgekeerd zoeken ondersteunt, en het zal een [`DoubleEndedIterator`] zijn als een forward/reverse-zoekopdracht dezelfde elementen oplevert.
    ///
    ///
    /// Voor iteratie vanaf de voorkant kan de [`match_indices`]-methode worden gebruikt.
    ///
    /// [`match_indices`]: str::match_indices
    ///
    /// # Examples
    ///
    /// Basisgebruik:
    ///
    /// ```
    /// let v: Vec<_> = "abcXXXabcYYYabc".rmatch_indices("abc").collect();
    /// assert_eq!(v, [(12, "abc"), (6, "abc"), (0, "abc")]);
    ///
    /// let v: Vec<_> = "1abcabc2".rmatch_indices("abc").collect();
    /// assert_eq!(v, [(4, "abc"), (1, "abc")]);
    ///
    /// let v: Vec<_> = "ababa".rmatch_indices("aba").collect();
    /// assert_eq!(v, [(2, "aba")]); // alleen de laatste `aba`
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "str_match_indices", since = "1.5.0")]
    #[inline]
    pub fn rmatch_indices<'a, P>(&'a self, pat: P) -> RMatchIndices<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RMatchIndices(self.match_indices(pat).0)
    }

    /// Retourneert een stringplak waarvan de voorloop-en volgspaties zijn verwijderd.
    ///
    /// 'Whitespace' wordt gedefinieerd volgens de voorwaarden van de Unicode Derived Core Property `White_Space`.
    ///
    ///
    /// # Examples
    ///
    /// Basisgebruik:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!("Hello\tworld", s.trim());
    /// ```
    #[inline]
    #[must_use = "this returns the trimmed string as a slice, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn trim(&self) -> &str {
        self.trim_matches(|c: char| c.is_whitespace())
    }

    /// Retourneert een stringplak waarvan de voorloopspaties zijn verwijderd.
    ///
    /// 'Whitespace' wordt gedefinieerd volgens de voorwaarden van de Unicode Derived Core Property `White_Space`.
    ///
    /// # Directionaliteit van tekst
    ///
    /// Een string is een reeks bytes.
    /// `start` betekent in deze context de eerste positie van die bytestring;voor een taal van links naar rechts, zoals Engels of Russisch, is dit de linkerkant en voor talen van rechts naar links zoals Arabisch of Hebreeuws is dit de rechterkant.
    ///
    ///
    /// # Examples
    ///
    /// Basisgebruik:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    /// assert_eq!("Hello\tworld\t", s.trim_start());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English  ";
    /// assert!(Some('E') == s.trim_start().chars().next());
    ///
    /// let s = "  עברית  ";
    /// assert!(Some('ע') == s.trim_start().chars().next());
    /// ```
    ///
    ///
    #[inline]
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_start(&self) -> &str {
        self.trim_start_matches(|c: char| c.is_whitespace())
    }

    /// Retourneert een string-segment waarvan de spaties aan het einde zijn verwijderd.
    ///
    /// 'Whitespace' wordt gedefinieerd volgens de voorwaarden van de Unicode Derived Core Property `White_Space`.
    ///
    /// # Directionaliteit van tekst
    ///
    /// Een string is een reeks bytes.
    /// `end` betekent in deze context de laatste positie van die bytestring;voor een taal van links naar rechts, zoals Engels of Russisch, is dit de rechterkant en voor talen van rechts naar links zoals Arabisch of Hebreeuws is dit de linkerkant.
    ///
    ///
    /// # Examples
    ///
    /// Basisgebruik:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    /// assert_eq!(" Hello\tworld", s.trim_end());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English  ";
    /// assert!(Some('h') == s.trim_end().chars().rev().next());
    ///
    /// let s = "  עברית  ";
    /// assert!(Some('ת') == s.trim_end().chars().rev().next());
    /// ```
    ///
    ///
    #[inline]
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_end(&self) -> &str {
        self.trim_end_matches(|c: char| c.is_whitespace())
    }

    /// Retourneert een stringplak waarvan de voorloopspaties zijn verwijderd.
    ///
    /// 'Whitespace' wordt gedefinieerd volgens de voorwaarden van de Unicode Derived Core Property `White_Space`.
    ///
    /// # Directionaliteit van tekst
    ///
    /// Een string is een reeks bytes.
    /// 'Left' betekent in deze context de eerste positie van die bytestring;voor een taal als Arabisch of Hebreeuws die 'van rechts naar links' zijn in plaats van 'van links naar rechts', is dit de _right_-kant, niet de linkerkant.
    ///
    ///
    /// # Examples
    ///
    /// Basisgebruik:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!("Hello\tworld\t", s.trim_left());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English";
    /// assert!(Some('E') == s.trim_left().chars().next());
    ///
    /// let s = "  עברית";
    /// assert!(Some('ע') == s.trim_left().chars().next());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_start`",
        suggestion = "trim_start"
    )]
    pub fn trim_left(&self) -> &str {
        self.trim_start()
    }

    /// Retourneert een string-segment waarvan de spaties aan het einde zijn verwijderd.
    ///
    /// 'Whitespace' wordt gedefinieerd volgens de voorwaarden van de Unicode Derived Core Property `White_Space`.
    ///
    /// # Directionaliteit van tekst
    ///
    /// Een string is een reeks bytes.
    /// 'Right' betekent in deze context de laatste positie van die bytestring;voor een taal als Arabisch of Hebreeuws die 'van rechts naar links' in plaats van 'van links naar rechts' zijn, is dit de _left_-kant, niet de rechterkant.
    ///
    ///
    /// # Examples
    ///
    /// Basisgebruik:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!(" Hello\tworld", s.trim_right());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "English  ";
    /// assert!(Some('h') == s.trim_right().chars().rev().next());
    ///
    /// let s = "עברית  ";
    /// assert!(Some('ת') == s.trim_right().chars().rev().next());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_end`",
        suggestion = "trim_end"
    )]
    pub fn trim_right(&self) -> &str {
        self.trim_end()
    }

    /// Retourneert een stringplak met alle voor-en achtervoegsels die overeenkomen met een patroon dat herhaaldelijk is verwijderd.
    ///
    /// De [pattern] kan een [`char`] zijn, een plak van [`char`] s, of een functie of sluiting die bepaalt of een teken overeenkomt.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Eenvoudige patronen:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_matches('1'), "foo1bar");
    /// assert_eq!("123foo1bar123".trim_matches(char::is_numeric), "foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_matches(x), "foo1bar");
    /// ```
    ///
    /// Een complexer patroon, met een sluiting:
    ///
    /// ```
    /// assert_eq!("1foo1barXX".trim_matches(|c| c == '1' || c == 'X'), "foo1bar");
    /// ```
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn trim_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: DoubleEndedSearcher<'a>>,
    {
        let mut i = 0;
        let mut j = 0;
        let mut matcher = pat.into_searcher(self);
        if let Some((a, b)) = matcher.next_reject() {
            i = a;
            j = b; // Onthoud de vroegst bekende overeenkomst, corrigeer deze hieronder als
            // laatste wedstrijd is anders
        }
        if let Some((_, b)) = matcher.next_reject_back() {
            j = b;
        }
        // VEILIGHEID: Van `Searcher` is bekend dat het geldige indices retourneert.
        unsafe { self.get_unchecked(i..j) }
    }

    /// Retourneert een stringplak met alle voorvoegsels die overeenkomen met een patroon dat herhaaldelijk is verwijderd.
    ///
    /// De [pattern] kan een `&str`, [`char`] zijn, een stuk [`char`] s, of een functie of sluiting die bepaalt of een teken overeenkomt.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Directionaliteit van tekst
    ///
    /// Een string is een reeks bytes.
    /// `start` betekent in deze context de eerste positie van die bytestring;voor een taal van links naar rechts, zoals Engels of Russisch, is dit de linkerkant en voor talen van rechts naar links zoals Arabisch of Hebreeuws is dit de rechterkant.
    ///
    ///
    /// # Examples
    ///
    /// Basisgebruik:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_start_matches('1'), "foo1bar11");
    /// assert_eq!("123foo1bar123".trim_start_matches(char::is_numeric), "foo1bar123");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_start_matches(x), "foo1bar12");
    /// ```
    ///
    ///
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_start_matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> &'a str {
        let mut i = self.len();
        let mut matcher = pat.into_searcher(self);
        if let Some((a, _)) = matcher.next_reject() {
            i = a;
        }
        // VEILIGHEID: Van `Searcher` is bekend dat het geldige indices retourneert.
        unsafe { self.get_unchecked(i..self.len()) }
    }

    /// Retourneert een stringplak waarvan het voorvoegsel is verwijderd.
    ///
    /// Als de tekenreeks begint met het patroon `prefix`, retourneert de subtekenreeks na het voorvoegsel, verpakt in `Some`.
    /// In tegenstelling tot `trim_start_matches` verwijdert deze methode het voorvoegsel precies één keer.
    ///
    /// Als de tekenreeks niet begint met `prefix`, wordt `None` geretourneerd.
    ///
    /// De [pattern] kan een `&str`, [`char`] zijn, een stuk [`char`] s, of een functie of sluiting die bepaalt of een teken overeenkomt.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("foo:bar".strip_prefix("foo:"), Some("bar"));
    /// assert_eq!("foo:bar".strip_prefix("bar"), None);
    /// assert_eq!("foofoo".strip_prefix("foo"), Some("foo"));
    /// ```
    #[must_use = "this returns the remaining substring as a new slice, \
                  without modifying the original"]
    #[stable(feature = "str_strip", since = "1.45.0")]
    pub fn strip_prefix<'a, P: Pattern<'a>>(&'a self, prefix: P) -> Option<&'a str> {
        prefix.strip_prefix_of(self)
    }

    /// Retourneert een stringplak waarvan het achtervoegsel is verwijderd.
    ///
    /// Als de tekenreeks eindigt met het patroon `suffix`, retourneert de subtekenreeks vóór het achtervoegsel, verpakt in `Some`.
    /// In tegenstelling tot `trim_end_matches` verwijdert deze methode het achtervoegsel precies één keer.
    ///
    /// Als de tekenreeks niet eindigt op `suffix`, wordt `None` geretourneerd.
    ///
    /// De [pattern] kan een `&str`, [`char`] zijn, een stuk [`char`] s, of een functie of sluiting die bepaalt of een teken overeenkomt.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("bar:foo".strip_suffix(":foo"), Some("bar"));
    /// assert_eq!("bar:foo".strip_suffix("bar"), None);
    /// assert_eq!("foofoo".strip_suffix("foo"), Some("foo"));
    /// ```
    #[must_use = "this returns the remaining substring as a new slice, \
                  without modifying the original"]
    #[stable(feature = "str_strip", since = "1.45.0")]
    pub fn strip_suffix<'a, P>(&'a self, suffix: P) -> Option<&'a str>
    where
        P: Pattern<'a>,
        <P as Pattern<'a>>::Searcher: ReverseSearcher<'a>,
    {
        suffix.strip_suffix_of(self)
    }

    /// Retourneert een stringplak met alle achtervoegsels die overeenkomen met een patroon dat herhaaldelijk is verwijderd.
    ///
    /// De [pattern] kan een `&str`, [`char`] zijn, een stuk [`char`] s, of een functie of sluiting die bepaalt of een teken overeenkomt.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Directionaliteit van tekst
    ///
    /// Een string is een reeks bytes.
    /// `end` betekent in deze context de laatste positie van die bytestring;voor een taal van links naar rechts, zoals Engels of Russisch, is dit de rechterkant en voor talen van rechts naar links zoals Arabisch of Hebreeuws is dit de linkerkant.
    ///
    ///
    /// # Examples
    ///
    /// Eenvoudige patronen:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_end_matches('1'), "11foo1bar");
    /// assert_eq!("123foo1bar123".trim_end_matches(char::is_numeric), "123foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_end_matches(x), "12foo1bar");
    /// ```
    ///
    /// Een complexer patroon, met een sluiting:
    ///
    /// ```
    /// assert_eq!("1fooX".trim_end_matches(|c| c == '1' || c == 'X'), "1foo");
    /// ```
    ///
    ///
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_end_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        let mut j = 0;
        let mut matcher = pat.into_searcher(self);
        if let Some((_, b)) = matcher.next_reject_back() {
            j = b;
        }
        // VEILIGHEID: Van `Searcher` is bekend dat het geldige indices retourneert.
        unsafe { self.get_unchecked(0..j) }
    }

    /// Retourneert een stringplak met alle voorvoegsels die overeenkomen met een patroon dat herhaaldelijk is verwijderd.
    ///
    /// De [pattern] kan een `&str`, [`char`] zijn, een stuk [`char`] s, of een functie of sluiting die bepaalt of een teken overeenkomt.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Directionaliteit van tekst
    ///
    /// Een string is een reeks bytes.
    /// 'Left' betekent in deze context de eerste positie van die bytestring;voor een taal als Arabisch of Hebreeuws die 'van rechts naar links' zijn in plaats van 'van links naar rechts', is dit de _right_-kant, niet de linkerkant.
    ///
    ///
    /// # Examples
    ///
    /// Basisgebruik:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_left_matches('1'), "foo1bar11");
    /// assert_eq!("123foo1bar123".trim_left_matches(char::is_numeric), "foo1bar123");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_left_matches(x), "foo1bar12");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_start_matches`",
        suggestion = "trim_start_matches"
    )]
    pub fn trim_left_matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> &'a str {
        self.trim_start_matches(pat)
    }

    /// Retourneert een stringplak met alle achtervoegsels die overeenkomen met een patroon dat herhaaldelijk is verwijderd.
    ///
    /// De [pattern] kan een `&str`, [`char`] zijn, een stuk [`char`] s, of een functie of sluiting die bepaalt of een teken overeenkomt.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Directionaliteit van tekst
    ///
    /// Een string is een reeks bytes.
    /// 'Right' betekent in deze context de laatste positie van die bytestring;voor een taal als Arabisch of Hebreeuws die 'van rechts naar links' in plaats van 'van links naar rechts' zijn, is dit de _left_-kant, niet de rechterkant.
    ///
    ///
    /// # Examples
    ///
    /// Eenvoudige patronen:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_right_matches('1'), "11foo1bar");
    /// assert_eq!("123foo1bar123".trim_right_matches(char::is_numeric), "123foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_right_matches(x), "12foo1bar");
    /// ```
    ///
    /// Een complexer patroon, met een sluiting:
    ///
    /// ```
    /// assert_eq!("1fooX".trim_right_matches(|c| c == '1' || c == 'X'), "1foo");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_end_matches`",
        suggestion = "trim_end_matches"
    )]
    pub fn trim_right_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        self.trim_end_matches(pat)
    }

    /// Parseert deze string slice in een ander type.
    ///
    /// Omdat `parse` zo algemeen is, kan het problemen veroorzaken met type-inferentie.
    /// Als zodanig is `parse` een van de weinige keren dat je de syntaxis ziet die liefkozend bekend staat als de 'turbofish': `::<>`.
    ///
    /// Dit helpt het inferentie-algoritme specifiek te begrijpen naar welk type u probeert te ontleden.
    ///
    /// `parse` kan ontleden in elk type dat de [`FromStr`] trait implementeert.
    ///

    /// # Errors
    ///
    /// Zal [`Err`] retourneren als het niet mogelijk is om deze string slice in het gewenste type te parseren.
    ///
    ///
    /// [`Err`]: FromStr::Err
    ///
    /// # Examples
    ///
    /// Basisgebruik
    ///
    /// ```
    /// let four: u32 = "4".parse().unwrap();
    ///
    /// assert_eq!(4, four);
    /// ```
    ///
    /// De 'turbofish' gebruiken in plaats van `four` te annoteren:
    ///
    /// ```
    /// let four = "4".parse::<u32>();
    ///
    /// assert_eq!(Ok(4), four);
    /// ```
    ///
    /// Niet parseren:
    ///
    /// ```
    /// let nope = "j".parse::<u32>();
    ///
    /// assert!(nope.is_err());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn parse<F: FromStr>(&self) -> Result<F, F::Err> {
        FromStr::from_str(self)
    }

    /// Controleert of alle tekens in deze tekenreeks binnen het ASCII-bereik vallen.
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = "hello!\n";
    /// let non_ascii = "Grüße, Jürgen ❤";
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        // We kunnen hier elke byte als teken behandelen: alle multibyte-tekens beginnen met een byte die niet in het ascii-bereik ligt, dus we zullen daar al stoppen.
        //
        //
        self.as_bytes().is_ascii()
    }

    /// Controleert of twee strings een ASCII-hoofdletterongevoelige overeenkomst zijn.
    ///
    /// Hetzelfde als `to_ascii_lowercase(a) == to_ascii_lowercase(b)`, maar zonder tijdelijke bestanden toe te wijzen en te kopiëren.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert!("Ferris".eq_ignore_ascii_case("FERRIS"));
    /// assert!("Ferrös".eq_ignore_ascii_case("FERRöS"));
    /// assert!(!"Ferrös".eq_ignore_ascii_case("FERRÖS"));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &str) -> bool {
        self.as_bytes().eq_ignore_ascii_case(other.as_bytes())
    }

    /// Zet deze tekenreeks ter plekke om in het ASCII-equivalent in hoofdletters.
    ///
    /// ASCII-letters 'a' tot 'z' worden toegewezen aan 'A' tot 'Z', maar niet-ASCII-letters blijven ongewijzigd.
    ///
    /// Gebruik [`to_ascii_uppercase()`] om een nieuwe waarde in hoofdletters te retourneren zonder de bestaande te wijzigen.
    ///
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("Grüße, Jürgen ❤");
    ///
    /// s.make_ascii_uppercase();
    ///
    /// assert_eq!("GRüßE, JüRGEN ❤", s);
    /// ```
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        // VEILIGHEID: veilig omdat we twee typen transmuteren met dezelfde lay-out.
        let me = unsafe { self.as_bytes_mut() };
        me.make_ascii_uppercase()
    }

    /// Zet deze tekenreeks ter plekke om in het ASCII-equivalent in kleine letters.
    ///
    /// ASCII-letters 'A' tot 'Z' worden toegewezen aan 'a' tot 'z', maar niet-ASCII-letters blijven ongewijzigd.
    ///
    /// Gebruik [`to_ascii_lowercase()`] om een nieuwe lagere waarde te retourneren zonder de bestaande te wijzigen.
    ///
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("GRÜßE, JÜRGEN ❤");
    ///
    /// s.make_ascii_lowercase();
    ///
    /// assert_eq!("grÜße, jÜrgen ❤", s);
    /// ```
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        // VEILIGHEID: veilig omdat we twee typen transmuteren met dezelfde lay-out.
        let me = unsafe { self.as_bytes_mut() };
        me.make_ascii_lowercase()
    }

    /// Retourneer een iterator die aan elk teken in `self` ontsnapt met [`char::escape_debug`].
    ///
    ///
    /// Note: alleen uitgebreide grafeem-codepunten die met de tekenreeks beginnen, worden ontsnapt.
    ///
    /// # Examples
    ///
    /// Als iterator:
    ///
    /// ```
    /// for c in "❤\n!".escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// `println!` rechtstreeks gebruiken:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_debug());
    /// ```
    ///
    /// Beide zijn gelijk aan:
    ///
    /// ```
    /// println!("❤\\n!");
    /// ```
    ///
    /// `to_string` gebruiken:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_debug().to_string(), "❤\\n!");
    /// ```
    ///
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_debug(&self) -> EscapeDebug<'_> {
        let mut chars = self.chars();
        EscapeDebug {
            inner: chars
                .next()
                .map(|first| first.escape_debug_ext(true))
                .into_iter()
                .flatten()
                .chain(chars.flat_map(CharEscapeDebugContinue)),
        }
    }

    /// Retourneer een iterator die aan elk teken in `self` ontsnapt met [`char::escape_default`].
    ///
    ///
    /// # Examples
    ///
    /// Als iterator:
    ///
    /// ```
    /// for c in "❤\n!".escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// `println!` rechtstreeks gebruiken:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_default());
    /// ```
    ///
    /// Beide zijn gelijk aan:
    ///
    /// ```
    /// println!("\\u{{2764}}\\n!");
    /// ```
    ///
    /// `to_string` gebruiken:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_default().to_string(), "\\u{2764}\\n!");
    /// ```
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_default(&self) -> EscapeDefault<'_> {
        EscapeDefault { inner: self.chars().flat_map(CharEscapeDefault) }
    }

    /// Retourneer een iterator die aan elk teken in `self` ontsnapt met [`char::escape_unicode`].
    ///
    ///
    /// # Examples
    ///
    /// Als iterator:
    ///
    /// ```
    /// for c in "❤\n!".escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// `println!` rechtstreeks gebruiken:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_unicode());
    /// ```
    ///
    /// Beide zijn gelijk aan:
    ///
    /// ```
    /// println!("\\u{{2764}}\\u{{a}}\\u{{21}}");
    /// ```
    ///
    /// `to_string` gebruiken:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_unicode().to_string(), "\\u{2764}\\u{a}\\u{21}");
    /// ```
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_unicode(&self) -> EscapeUnicode<'_> {
        EscapeUnicode { inner: self.chars().flat_map(CharEscapeUnicode) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<[u8]> for str {
    #[inline]
    fn as_ref(&self) -> &[u8] {
        self.as_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Default for &str {
    /// Creëert een lege str
    #[inline]
    fn default() -> Self {
        ""
    }
}

#[stable(feature = "default_mut_str", since = "1.28.0")]
impl Default for &mut str {
    /// Creëert een lege veranderlijke str
    #[inline]
    fn default() -> Self {
        // VEILIGHEID: De lege string is geldig UTF-8.
        unsafe { from_utf8_unchecked_mut(&mut []) }
    }
}

impl_fn_for_zst! {
    /// Een benoembaar, kloonbaar fn-type
    #[derive(Clone)]
    struct LinesAnyMap impl<'a> Fn = |line: &'a str| -> &'a str {
        let l = line.len();
        if l > 0 && line.as_bytes()[l - 1] == b'\r' { &line[0 .. l - 1] }
        else { line }
    };

    #[derive(Clone)]
    struct CharEscapeDebugContinue impl Fn = |c: char| -> char::EscapeDebug {
        c.escape_debug_ext(false)
    };

    #[derive(Clone)]
    struct CharEscapeUnicode impl Fn = |c: char| -> char::EscapeUnicode {
        c.escape_unicode()
    };
    #[derive(Clone)]
    struct CharEscapeDefault impl Fn = |c: char| -> char::EscapeDefault {
        c.escape_default()
    };

    #[derive(Clone)]
    struct IsWhitespace impl Fn = |c: char| -> bool {
        c.is_whitespace()
    };

    #[derive(Clone)]
    struct IsAsciiWhitespace impl Fn = |byte: &u8| -> bool {
        byte.is_ascii_whitespace()
    };

    #[derive(Clone)]
    struct IsNotEmpty impl<'a, 'b> Fn = |s: &'a &'b str| -> bool {
        !s.is_empty()
    };

    #[derive(Clone)]
    struct BytesIsNotEmpty impl<'a, 'b> Fn = |s: &'a &'b [u8]| -> bool {
        !s.is_empty()
    };

    #[derive(Clone)]
    struct UnsafeBytesToStr impl<'a> Fn = |bytes: &'a [u8]| -> &'a str {
        // VEILIGHEID: niet veilig
        unsafe { from_utf8_unchecked(bytes) }
    };
}