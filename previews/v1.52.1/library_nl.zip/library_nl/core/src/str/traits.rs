//! Trait implementaties voor `str`.

use crate::cmp::Ordering;
use crate::ops;
use crate::ptr;
use crate::slice::SliceIndex;

use super::ParseBoolError;

/// Implementeert het ordenen van snaren.
///
/// Strings zijn gerangschikt op [lexicographically](Ord#lexicographical-comparison) op basis van hun bytewaarden.
/// Dit rangschikt Unicode-codepunten op basis van hun posities in de codegrafieken.
/// Dit is niet noodzakelijk hetzelfde als de "alphabetical"-volgorde, die per taal en landinstelling verschilt.
/// Het sorteren van tekenreeksen volgens cultureel geaccepteerde standaarden vereist landspecifieke gegevens die buiten het bereik van het `str`-type vallen.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Ord for str {
    #[inline]
    fn cmp(&self, other: &str) -> Ordering {
        self.as_bytes().cmp(other.as_bytes())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for str {
    #[inline]
    fn eq(&self, other: &str) -> bool {
        self.as_bytes() == other.as_bytes()
    }
    #[inline]
    fn ne(&self, other: &str) -> bool {
        !(*self).eq(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Eq for str {}

/// Implementeert vergelijkingsbewerkingen op strings.
///
/// Strings worden [lexicographically](Ord#lexicographical-comparison) vergeleken op basis van hun bytewaarden.
/// Hiermee worden Unicode-codepunten vergeleken op basis van hun posities in de codegrafieken.
/// Dit is niet noodzakelijk hetzelfde als de "alphabetical"-volgorde, die per taal en landinstelling verschilt.
/// Het vergelijken van strings volgens cultureel geaccepteerde standaarden vereist locale-specifieke gegevens die buiten het bereik van het `str`-type vallen.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl PartialOrd for str {
    #[inline]
    fn partial_cmp(&self, other: &str) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::Index<I> for str
where
    I: SliceIndex<str>,
{
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &I::Output {
        index.index(self)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::IndexMut<I> for str
where
    I: SliceIndex<str>,
{
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut I::Output {
        index.index_mut(self)
    }
}

#[inline(never)]
#[cold]
#[track_caller]
fn str_index_overflow_fail() -> ! {
    panic!("attempted to index str up to maximum usize");
}

/// Implementeert deelstring-slicing met de syntaxis `&self[..]` of `&mut self[..]`.
///
/// Retourneert een segment van de hele tekenreeks, dwz retourneert `&self` of `&mut self`.Komt overeen met '&self [0 ..
/// len] 'of'&mut self [0 ..
/// len]`.
/// In tegenstelling tot andere indexeringsbewerkingen, kan dit nooit panic.
///
/// Deze bewerking is *O*(1).
///
/// Vóór 1.20.0 werden deze indexeringsbewerkingen nog steeds ondersteund door directe implementatie van `Index` en `IndexMut`.
///
/// Gelijk aan `&self[0 .. len]` of `&mut self[0 .. len]`.
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFull {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        Some(slice)
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        Some(slice)
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        slice
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        slice
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        slice
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        slice
    }
}

/// Implementeert deelstring-slicing met de syntaxis `&self[begin .. end]` of `&mut self[begin .. end]`.
///
/// Retourneert een segment van de opgegeven tekenreeks uit het bytebereik [`begin`, `end`).
///
/// Deze bewerking is *O*(1).
///
/// Vóór 1.20.0 werden deze indexeringsbewerkingen nog steeds ondersteund door directe implementatie van `Index` en `IndexMut`.
///
/// # Panics
///
/// Panics als `begin` of `end` niet verwijst naar de beginbyte-offset van een teken (zoals gedefinieerd door `is_char_boundary`), als `begin > end` of als `end > len`.
///
///
/// # Examples
///
/// ```
/// let s = "Löwe 老虎 Léopard";
/// assert_eq!(&s[0 .. 1], "L");
///
/// assert_eq!(&s[1 .. 9], "öwe 老");
///
/// // deze zullen panic:
/// // byte 2 ligt binnen `ö`:
/// // &s [2 ..3];
///
/// // byte 8 ligt binnen `老`&s [1 ..
/// // 8];
///
/// // byte 100 is buiten de string&s [3 ..
/// // 100];
/// ```
///
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::Range<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // VEILIGHEID: heb net gecontroleerd of `start` en `end` zich op een tekengrens bevinden,
            // en we geven een veilige referentie door, dus de geretourneerde waarde zal er ook één zijn.
            // We hebben ook de char-grenzen gecontroleerd, dus dit is een geldige UTF-8.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // VEILIGHEID: heb net gecontroleerd of `start` en `end` zich op een tekengrens bevinden.
            // We weten dat de aanwijzer uniek is omdat we hem van `slice` hebben gekregen.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // VEILIGHEID: de beller garandeert dat `self` zich binnen de grenzen van `slice` bevindt
        // die voldoet aan alle voorwaarden voor `add`.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // VEILIGHEID: zie opmerkingen voor `get_unchecked`.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, self.end);
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        // is_char_boundary controleert of de index zich in [0 bevindt, .len()] kan `get` niet hergebruiken zoals hierboven, vanwege NLL-problemen
        //
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // VEILIGHEID: heb net gecontroleerd of `start` en `end` zich op een tekengrens bevinden,
            // en we geven een veilige referentie door, dus de geretourneerde waarde zal er ook één zijn.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, self.end)
        }
    }
}

/// Implementeert deelstring-slicing met de syntaxis `&self[.. end]` of `&mut self[.. end]`.
///
/// Retourneert een segment van de opgegeven tekenreeks uit het bytebereik [`0`, `end`).
/// Gelijk aan `&self[0 .. end]` of `&mut self[0 .. end]`.
///
/// Deze bewerking is *O*(1).
///
/// Vóór 1.20.0 werden deze indexeringsbewerkingen nog steeds ondersteund door directe implementatie van `Index` en `IndexMut`.
///
/// # Panics
///
/// Panics als `end` niet verwijst naar de beginbyte-offset van een teken (zoals gedefinieerd door `is_char_boundary`), of als `end > len`.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeTo<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.end) {
            // VEILIGHEID: heb net gecontroleerd of `end` zich op een tekengrens bevindt,
            // en we geven een veilige referentie door, dus de geretourneerde waarde zal er ook één zijn.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.end) {
            // VEILIGHEID: heb net gecontroleerd of `end` zich op een tekengrens bevindt,
            // en we geven een veilige referentie door, dus de geretourneerde waarde zal er ook één zijn.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        let ptr = slice.as_ptr();
        ptr::slice_from_raw_parts(ptr, self.end) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        let ptr = slice.as_mut_ptr();
        ptr::slice_from_raw_parts_mut(ptr, self.end) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let end = self.end;
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, 0, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.end) {
            // VEILIGHEID: heb net gecontroleerd of `end` zich op een tekengrens bevindt,
            // en we geven een veilige referentie door, dus de geretourneerde waarde zal er ook één zijn.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, 0, self.end)
        }
    }
}

/// Implementeert deelstring-slicing met de syntaxis `&self[begin ..]` of `&mut self[begin ..]`.
///
/// Retourneert een segment van de opgegeven tekenreeks uit het bytebereik [`begin`, `len`).Gelijk aan&self [begin ..
/// len] 'of'&mut self [begin ..
/// len]`.
///
/// Deze bewerking is *O*(1).
///
/// Vóór 1.20.0 werden deze indexeringsbewerkingen nog steeds ondersteund door directe implementatie van `Index` en `IndexMut`.
///
/// # Panics
///
/// Panics als `begin` niet verwijst naar de beginbyte-offset van een teken (zoals gedefinieerd door `is_char_boundary`), of als `begin > len`.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFrom<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.start) {
            // VEILIGHEID: heb net gecontroleerd of `start` zich op een tekengrens bevindt,
            // en we geven een veilige referentie door, dus de geretourneerde waarde zal er ook één zijn.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.start) {
            // VEILIGHEID: heb net gecontroleerd of `start` zich op een tekengrens bevindt,
            // en we geven een veilige referentie door, dus de geretourneerde waarde zal er ook één zijn.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // VEILIGHEID: de beller garandeert dat `self` zich binnen de grenzen van `slice` bevindt
        // die voldoet aan alle voorwaarden voor `add`.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // VEILIGHEID: identiek aan `get_unchecked`.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, slice.len());
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.start) {
            // VEILIGHEID: heb net gecontroleerd of `start` zich op een tekengrens bevindt,
            // en we geven een veilige referentie door, dus de geretourneerde waarde zal er ook één zijn.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, slice.len())
        }
    }
}

/// Implementeert deelstring-slicing met de syntaxis `&self[begin ..= end]` of `&mut self[begin ..= end]`.
///
/// Retourneert een segment van de opgegeven tekenreeks uit het bytebereik [`begin`, `end`].Gelijk aan `&self [begin .. end + 1]` of `&mut self[begin .. end + 1]`, behalve als `end` de maximale waarde voor `usize` heeft.
///
/// Deze bewerking is *O*(1).
///
/// # Panics
///
/// Panics als `begin` niet verwijst naar de beginbyte-offset van een teken (zoals gedefinieerd door `is_char_boundary`), als `end` niet verwijst naar de eindbyte-offset van een teken (`end + 1` is ofwel een beginbyte-offset of gelijk aan `len`), als `begin > end`, of als `end >= len`.
///
///
///
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // VEILIGHEID: de beller moet zich houden aan het veiligheidscontract voor `get_unchecked`.
        unsafe { self.into_slice_range().get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // VEILIGHEID: de beller moet zich houden aan het veiligheidscontract voor `get_unchecked_mut`.
        unsafe { self.into_slice_range().get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index_mut(slice)
    }
}

/// Implementeert deelstring-slicing met de syntaxis `&self[..= end]` of `&mut self[..= end]`.
///
/// Retourneert een segment van de opgegeven tekenreeks uit het bytebereik [0, `end`].
/// Gelijk aan `&self [0 .. end + 1]`, behalve als `end` de maximale waarde voor `usize` heeft.
///
/// Deze bewerking is *O*(1).
///
/// # Panics
///
/// Panics als `end` niet verwijst naar de eindbyte-offset van een teken (`end + 1` is ofwel een beginbyte-offset zoals gedefinieerd door `is_char_boundary`, of gelijk aan `len`), of als `end >= len`.
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeToInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // VEILIGHEID: de beller moet zich houden aan het veiligheidscontract voor `get_unchecked`.
        unsafe { (..self.end + 1).get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // VEILIGHEID: de beller moet zich houden aan het veiligheidscontract voor `get_unchecked_mut`.
        unsafe { (..self.end + 1).get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index_mut(slice)
    }
}

/// Parseer een waarde uit een tekenreeks
///
/// De [`from_str`]-methode van `FromStr 'wordt vaak impliciet gebruikt, via de [`parse`]-methode van [` str`].
/// Zie de documentatie van [`parse`] voor voorbeelden.
///
/// [`from_str`]: FromStr::from_str
/// [`parse`]: str::parse
///
/// `FromStr` heeft geen levenslange parameter, en dus kun je alleen typen parseren die zelf geen levenslange parameter bevatten.
///
/// Met andere woorden, u kunt een `i32` parseren met `FromStr`, maar geen `&i32`.
/// U kunt een structuur ontleden die een `i32` bevat, maar niet een structuur die een `&i32` bevat.
///
/// # Examples
///
/// Basisimplementatie van `FromStr` op een voorbeeld `Point`-type:
///
/// ```
/// use std::str::FromStr;
/// use std::num::ParseIntError;
///
/// #[derive(Debug, PartialEq)]
/// struct Point {
///     x: i32,
///     y: i32
/// }
///
/// impl FromStr for Point {
///     type Err = ParseIntError;
///
///     fn from_str(s: &str) -> Result<Self, Self::Err> {
///         let coords: Vec<&str> = s.trim_matches(|p| p == '(' || p == ')' )
///                                  .split(',')
///                                  .collect();
///
///         let x_fromstr = coords[0].parse::<i32>()?;
///         let y_fromstr = coords[1].parse::<i32>()?;
///
///         Ok(Point { x: x_fromstr, y: y_fromstr })
///     }
/// }
///
/// let p = Point::from_str("(1,2)");
/// assert_eq!(p.unwrap(), Point{ x: 1, y: 2} )
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait FromStr: Sized {
    /// De bijbehorende fout die kan worden geretourneerd door het parseren.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Err;

    /// Parseert een tekenreeks `s` om een waarde van dit type te retourneren.
    ///
    /// Als het parseren is gelukt, retourneert u de waarde binnen [`Ok`], anders retourneert u een fout die specifiek is voor de binnenkant van [`Err`] als de tekenreeks niet goed is opgemaakt.
    /// Het fouttype is specifiek voor de implementatie van de trait.
    ///
    /// # Examples
    ///
    /// Basisgebruik met [`i32`], een type dat `FromStr` implementeert:
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// let s = "5";
    /// let x = i32::from_str(s).unwrap();
    ///
    /// assert_eq!(5, x);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_str(s: &str) -> Result<Self, Self::Err>;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for bool {
    type Err = ParseBoolError;

    /// Ontleed een `bool` uit een string.
    ///
    /// Levert een `Result<bool, ParseBoolError>` op, omdat `s` al dan niet echt parseerbaar kan zijn.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// assert_eq!(FromStr::from_str("true"), Ok(true));
    /// assert_eq!(FromStr::from_str("false"), Ok(false));
    /// assert!(<bool as FromStr>::from_str("not even a boolean").is_err());
    /// ```
    ///
    /// Merk op dat in veel gevallen de `.parse()`-methode op `str` geschikter is.
    ///
    /// ```
    /// assert_eq!("true".parse(), Ok(true));
    /// assert_eq!("false".parse(), Ok(false));
    /// assert!("not even a boolean".parse::<bool>().is_err());
    /// ```
    #[inline]
    fn from_str(s: &str) -> Result<bool, ParseBoolError> {
        match s {
            "true" => Ok(true),
            "false" => Ok(false),
            _ => Err(ParseBoolError { _priv: () }),
        }
    }
}