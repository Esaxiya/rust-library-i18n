//! Manieren om een `str` te maken van een bytesegment.

use crate::mem;

use super::validations::run_utf8_validation;
use super::Utf8Error;

/// Converteert een stukje bytes naar een string-segment.
///
/// Een stringplak ([`&str`]) is gemaakt van bytes ([`u8`]) en een bytesegment ([`&[u8]`][byteslice]) is gemaakt van bytes, dus deze functie converteert tussen de twee.
/// Niet alle bytesegmenten zijn echter geldige stringplakjes: [`&str`] vereist dat het geldige UTF-8 is.
/// `from_utf8()` controleert of de bytes geldige UTF-8 zijn, en voert vervolgens de conversie uit.
///
/// [`&str`]: str
/// [byteslice]: slice
///
/// Als u zeker weet dat het bytesegment geldig UTF-8 is, en u niet de overhead van de geldigheidscontrole wilt oplopen, is er een onveilige versie van deze functie, [`from_utf8_unchecked`], die hetzelfde gedrag vertoont maar de controle overslaat.
///
///
/// Als je een `String` nodig hebt in plaats van een `&str`, overweeg dan [`String::from_utf8`][string].
///
/// [string]: ../../std/string/struct.String.html#method.from_utf8
///
/// Omdat je een `[u8; N]` kunt stapelen, en je kunt er een [`&[u8]`][byteslice] van nemen, is deze functie een manier om een stapel toegewezen te krijgen.Er is een voorbeeld hiervan in de voorbeeldensectie hieronder.
///
/// [byteslice]: slice
///
/// # Errors
///
/// Retourneert `Err` als de slice niet UTF-8 is met een beschrijving waarom de opgegeven slice niet UTF-8 is.
///
/// # Examples
///
/// Basisgebruik:
///
/// ```
/// use std::str;
///
/// // enkele bytes, in een vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // We weten dat deze bytes geldig zijn, dus gebruik gewoon `unwrap()`.
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// Onjuiste bytes:
///
/// ```
/// use std::str;
///
/// // enkele ongeldige bytes, in een vector
/// let sparkle_heart = vec![0, 159, 146, 150];
///
/// assert!(str::from_utf8(&sparkle_heart).is_err());
/// ```
///
/// Zie de documenten voor [`Utf8Error`] voor meer details over de soorten fouten die kunnen worden geretourneerd.
///
/// EEN "stack allocated string":
///
/// ```
/// use std::str;
///
/// // enkele bytes, in een aan een stapel toegewezen array
/// let sparkle_heart = [240, 159, 146, 150];
///
/// // We weten dat deze bytes geldig zijn, dus gebruik gewoon `unwrap()`.
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_utf8(v: &[u8]) -> Result<&str, Utf8Error> {
    run_utf8_validation(v)?;
    // VEILIGHEID: Ik heb net validatie uitgevoerd.
    Ok(unsafe { from_utf8_unchecked(v) })
}

/// Converteert een veranderlijk segment van bytes naar een veranderlijk segment van de string.
///
/// # Examples
///
/// Basisgebruik:
///
/// ```
/// use std::str;
///
/// // "Hello, Rust!" als een veranderlijke vector
/// let mut hellorust = vec![72, 101, 108, 108, 111, 44, 32, 82, 117, 115, 116, 33];
///
/// // Omdat we weten dat deze bytes geldig zijn, kunnen we `unwrap()` gebruiken
/// let outstr = str::from_utf8_mut(&mut hellorust).unwrap();
///
/// assert_eq!("Hello, Rust!", outstr);
/// ```
///
/// Onjuiste bytes:
///
/// ```
/// use std::str;
///
/// // Enkele ongeldige bytes in een veranderlijke vector
/// let mut invalid = vec![128, 223];
///
/// assert!(str::from_utf8_mut(&mut invalid).is_err());
/// ```
/// Zie de documenten voor [`Utf8Error`] voor meer details over de soorten fouten die kunnen worden geretourneerd.
///
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub fn from_utf8_mut(v: &mut [u8]) -> Result<&mut str, Utf8Error> {
    run_utf8_validation(v)?;
    // VEILIGHEID: Ik heb net validatie uitgevoerd.
    Ok(unsafe { from_utf8_unchecked_mut(v) })
}

/// Converteert een stukje bytes naar een string-slice zonder te controleren of de string geldige UTF-8 bevat.
///
/// Zie de veilige versie, [`from_utf8`], voor meer informatie.
///
/// # Safety
///
/// Deze functie is onveilig omdat het niet controleert of de bytes die eraan worden doorgegeven geldige UTF-8 zijn.
/// Als deze beperking wordt geschonden, resulteert dit in ongedefinieerd gedrag, aangezien de rest van Rust aanneemt dat [`&str`] 's geldig zijn UTF-8.
///
///
/// [`&str`]: str
///
/// # Examples
///
/// Basisgebruik:
///
/// ```
/// use std::str;
///
/// // enkele bytes, in een vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// let sparkle_heart = unsafe {
///     str::from_utf8_unchecked(&sparkle_heart)
/// };
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_str_from_utf8_unchecked", issue = "75196")]
#[rustc_allow_const_fn_unstable(const_fn_transmute)]
pub const unsafe fn from_utf8_unchecked(v: &[u8]) -> &str {
    // VEILIGHEID: de beller moet garanderen dat de bytes `v` geldig zijn UTF-8.
    // Vertrouwt er ook op dat `&str` en `&[u8]` dezelfde lay-out hebben.
    unsafe { mem::transmute(v) }
}

/// Converteert een stukje bytes naar een string-slice zonder te controleren of de string geldige UTF-8 bevat;veranderlijke versie.
///
///
/// Zie de onveranderlijke versie, [`from_utf8_unchecked()`] voor meer informatie.
///
/// # Examples
///
/// Basisgebruik:
///
/// ```
/// use std::str;
///
/// let mut heart = vec![240, 159, 146, 150];
/// let heart = unsafe { str::from_utf8_unchecked_mut(&mut heart) };
///
/// assert_eq!("💖", heart);
/// ```
#[inline]
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub unsafe fn from_utf8_unchecked_mut(v: &mut [u8]) -> &mut str {
    // VEILIGHEID: de beller moet garanderen dat de bytes `v`
    // zijn geldig UTF-8, dus de cast naar `*mut str` is veilig.
    // Ook is de verwijzing naar de aanwijzer veilig omdat die aanwijzer afkomstig is van een verwijzing die gegarandeerd geldig is voor schrijfbewerkingen.
    //
    unsafe { &mut *(v as *mut [u8] as *mut str) }
}