#![stable(feature = "futures_api", since = "1.36.0")]

use crate::marker::Unpin;
use crate::ops;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// Een future vertegenwoordigt een asynchrone berekening.
///
/// Een future is een waarde die mogelijk nog niet klaar is met rekenen.
/// Dit soort "asynchronous value" maakt het mogelijk dat een thread nuttig werk blijft doen terwijl hij wacht tot de waarde beschikbaar komt.
///
///
/// # De `poll`-methode
///
/// De kernmethode van future, `poll`,*probeert* de future om te zetten in een uiteindelijke waarde.
/// Deze methode blokkeert niet als de waarde niet gereed is.
/// In plaats daarvan is de huidige taak gepland om te worden gewekt wanneer het mogelijk is om verdere vooruitgang te boeken door opnieuw te "peilen".
/// De `context` die is doorgegeven aan de `poll`-methode kan een [`Waker`] leveren, wat een handvat is om de huidige taak wakker te maken.
///
/// Als je een future gebruikt, roep je `poll` over het algemeen niet rechtstreeks aan, maar `.await` de waarde.
///
/// [`Waker`]: crate::task::Waker
///
///
///
#[doc(spotlight)]
#[must_use = "futures do nothing unless you `.await` or poll them"]
#[stable(feature = "futures_api", since = "1.36.0")]
#[lang = "future_trait"]
#[rustc_on_unimplemented(label = "`{Self}` is not a future", message = "`{Self}` is not a future")]
pub trait Future {
    /// Het soort waarde dat bij voltooiing wordt geproduceerd.
    #[stable(feature = "futures_api", since = "1.36.0")]
    type Output;

    /// Probeer de future om te zetten naar een definitieve waarde, en registreer de huidige taak voor ontwaken als de waarde nog niet beschikbaar is.
    ///
    /// # Winstwaarde
    ///
    /// Deze functie geeft als resultaat:
    ///
    /// - [`Poll::Pending`] als de future nog niet klaar is
    /// - [`Poll::Ready(val)`] met als resultaat `val` van deze future als het succesvol is afgerond.
    ///
    /// Zodra een future is voltooid, mogen clients deze niet opnieuw `poll` gebruiken.
    ///
    /// Wanneer een future nog niet gereed is, retourneert `poll` `Poll::Pending` en slaat een kloon op van de [`Waker`] gekopieerd van de huidige [`Context`].
    /// Deze [`Waker`] wordt vervolgens gewekt zodra de future vooruitgang kan boeken.
    /// Een future die wacht tot een socket leesbaar wordt, roept bijvoorbeeld `.clone()` op de [`Waker`] op en slaat deze op.
    /// Wanneer ergens anders een signaal arriveert dat aangeeft dat de socket leesbaar is, wordt [`Waker::wake`] aangeroepen en wordt de taak van socket future gewekt.
    /// Zodra een taak is gewekt, moet deze opnieuw proberen de future te `poll`, wat al dan niet een definitieve waarde kan produceren.
    ///
    /// Merk op dat bij meerdere oproepen naar `poll`, alleen de [`Waker`] van de [`Context`] die is doorgegeven aan de meest recente oproep moet worden gepland om te worden gewekt.
    ///
    /// # Runtime-kenmerken
    ///
    /// Futures alleen zijn *inert*;ze moeten *actief* worden gepolst om vooruitgang te boeken, wat betekent dat elke keer dat de huidige taak wordt gewekt, deze actief opnieuw moet 'pollen' in afwachting van futures waarin hij nog steeds interesse heeft.
    ///
    /// De `poll`-functie wordt niet herhaaldelijk in een strakke lus aangeroepen-in plaats daarvan mag deze alleen worden aangeroepen als de future aangeeft dat hij klaar is om vooruitgang te boeken (door `wake()`).
    /// Als u bekend bent met de `poll(2)`-of `select(2)`-syscalls op Unix, is het vermeldenswaard dat futures meestal *niet* dezelfde problemen heeft als "all wakeups must poll all events";ze lijken meer op `epoll(4)`.
    ///
    /// Een implementatie van `poll` moet ernaar streven om snel terug te keren en mag niet blokkeren.Snel terugkeren voorkomt onnodig verstoppen van threads of event-loops.
    /// Als het van tevoren bekend is dat een aanroep naar `poll` een tijdje kan duren, moet het werk worden verplaatst naar een threadpool (of iets dergelijks) om ervoor te zorgen dat `poll` snel kan terugkeren.
    ///
    /// # Panics
    ///
    /// Zodra een future is voltooid (`Ready` van `poll` geretourneerd), kan het opnieuw aanroepen van de `poll`-methode panic, voor altijd blokkeren of andere soorten problemen veroorzaken;de `Future` trait stelt geen eisen aan de effecten van zo'n oproep.
    /// Omdat de `poll`-methode echter niet als `unsafe` is gemarkeerd, zijn de gebruikelijke regels van Rust van toepassing: oproepen mogen nooit ongedefinieerd gedrag veroorzaken (geheugenbeschadiging, onjuist gebruik van `unsafe`-functies of iets dergelijks), ongeacht de status van future.
    ///
    ///
    /// [`Poll::Ready(val)`]: Poll::Ready
    /// [`Waker`]: crate::task::Waker
    /// [`Waker::wake`]: crate::task::Waker::wake
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[lang = "poll"]
    #[stable(feature = "futures_api", since = "1.36.0")]
    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output>;
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<F: ?Sized + Future + Unpin> Future for &mut F {
    type Output = F::Output;

    fn poll(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        F::poll(Pin::new(&mut **self), cx)
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<P> Future for Pin<P>
where
    P: Unpin + ops::DerefMut<Target: Future>,
{
    type Output = <<P as ops::Deref>::Target as Future>::Output;

    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        Pin::get_mut(self).as_mut().poll(cx)
    }
}