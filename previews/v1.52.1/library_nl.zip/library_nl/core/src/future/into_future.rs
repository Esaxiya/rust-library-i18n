use crate::future::Future;

/// Conversie naar een `Future`.
#[unstable(feature = "into_future", issue = "67644")]
pub trait IntoFuture {
    /// De output die de future na voltooiing zal produceren.
    #[unstable(feature = "into_future", issue = "67644")]
    type Output;

    /// In welk soort future veranderen we dit?
    #[unstable(feature = "into_future", issue = "67644")]
    type Future: Future<Output = Self::Output>;

    /// Creëert een future van een waarde.
    #[unstable(feature = "into_future", issue = "67644")]
    fn into_future(self) -> Self::Future;
}

#[unstable(feature = "into_future", issue = "67644")]
impl<F: Future> IntoFuture for F {
    type Output = F::Output;
    type Future = F;

    fn into_future(self) -> Self::Future {
        self
    }
}