#![stable(feature = "futures_api", since = "1.36.0")]

//! Asynchrone waarden.

use crate::{
    ops::{Generator, GeneratorState},
    pin::Pin,
    ptr::NonNull,
    task::{Context, Poll},
};

mod future;
mod into_future;
mod pending;
mod poll_fn;
mod ready;

#[stable(feature = "futures_api", since = "1.36.0")]
pub use self::future::Future;

#[unstable(feature = "into_future", issue = "67644")]
pub use into_future::IntoFuture;

#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use pending::{pending, Pending};
#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use ready::{ready, Ready};

#[unstable(feature = "future_poll_fn", issue = "72302")]
pub use poll_fn::{poll_fn, PollFn};

/// Dit type is nodig omdat:
///
/// a) Generatoren kunnen `for<'a, 'b> Generator<&'a mut Context<'b>>` niet implementeren, dus we moeten een onbewerkte pointer doorgeven (zie <https://github.com/rust-lang/rust/issues/68923>).
///
/// b) Raw pointers en `NonNull` zijn niet `Send` of `Sync`, dus dat zou elke future non-Send/Sync ook maken, en dat willen we niet.
///
/// Het vereenvoudigt ook de HIR-verlaging van `.await`.
///
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[derive(Debug, Copy, Clone)]
pub struct ResumeTy(NonNull<Context<'static>>);

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Send for ResumeTy {}

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Sync for ResumeTy {}

/// Wikkel een generator in een future.
///
/// Deze functie retourneert een `GenFuture` eronder, maar verbergt deze in `impl Trait` om betere foutmeldingen te geven (`impl Future` in plaats van `GenFuture<[closure.....]>`).
///
// Dit is `const` om extra fouten te voorkomen nadat we hersteld zijn van `const async fn`
#[lang = "from_generator"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[rustc_const_unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub const fn from_generator<T>(gen: T) -> impl Future<Output = T::Return>
where
    T: Generator<ResumeTy, Yield = ()>,
{
    #[rustc_diagnostic_item = "gen_future"]
    struct GenFuture<T: Generator<ResumeTy, Yield = ()>>(T);

    // We vertrouwen op het feit dat async/await futures onroerend is om zelfreferentiële leningen te creëren in de onderliggende generator.
    //
    impl<T: Generator<ResumeTy, Yield = ()>> !Unpin for GenFuture<T> {}

    impl<T: Generator<ResumeTy, Yield = ()>> Future for GenFuture<T> {
        type Output = T::Return;
        fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
            // VEILIGHEID: Veilig omdat we !Unpin + !Drop zijn, en dit is slechts een projectie in het veld.
            let gen = unsafe { Pin::map_unchecked_mut(self, |s| &mut s.0) };

            // Hervat de generator en verander de `&mut Context` in een onbewerkte `NonNull`-aanwijzer.
            // De `.await`-verlaging zal dat veilig terug naar een `&mut Context` werpen.
            match gen.resume(ResumeTy(NonNull::from(cx).cast::<Context<'static>>())) {
                GeneratorState::Yielded(()) => Poll::Pending,
                GeneratorState::Complete(x) => Poll::Ready(x),
            }
        }
    }

    GenFuture(gen)
}

#[lang = "get_context"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub unsafe fn get_context<'a, 'b>(cx: ResumeTy) -> &'a mut Context<'b> {
    // VEILIGHEID: de beller moet garanderen dat `cx.0` een geldige pointer is
    // dat voldoet aan alle eisen voor een veranderlijke referentie.
    unsafe { &mut *cx.0.as_ptr().cast() }
}