Panics de huidige thread.

Hierdoor kan een programma onmiddellijk worden beëindigd en feedback geven aan de beller van het programma.
`panic!` moet worden gebruikt wanneer een programma een onherstelbare staat bereikt.

Deze macro is de perfecte manier om voorwaarden te bevestigen in voorbeeldcode en in tests.
`panic!` is nauw verbonden met de `unwrap`-methode van zowel [`Option`][ounwrap]-als [`Result`][runwrap]-enums.
Beide implementaties roepen `panic!` aan wanneer ze zijn ingesteld op [`None`]-of [`Err`]-varianten.

Als u `panic!()` gebruikt, kunt u een string-payload specificeren, die is opgebouwd met behulp van de [`format!`]-syntaxis.
Die payload wordt gebruikt bij het injecteren van de panic in de aanroepende Rust-thread, waardoor de thread volledig naar panic gaat.

Het gedrag van de standaard `std` hook, dwz
de code die direct wordt uitgevoerd nadat de panic is aangeroepen, is om de berichtpayload af te drukken naar `stderr` samen met de file/line/column-informatie van de `panic!()`-oproep.

U kunt de panic hook opheffen met [`std::panic::set_hook()`].
Binnen de hook kan een panic worden benaderd als een `&dyn Any + Send`, die ofwel een `&str` of `String` bevat voor normale `panic!()`-aanroepen.
Voor panic met een waarde van een ander ander type, kan [`panic_any`] worden gebruikt.

[`Result`] enum is vaak een betere oplossing voor het herstellen van fouten dan het gebruik van de `panic!`-macro.
Deze macro moet worden gebruikt om te voorkomen dat u doorgaat met het gebruik van onjuiste waarden, zoals van externe bronnen.
Gedetailleerde informatie over het afhandelen van fouten is te vinden in de [book].

Zie ook de macro [`compile_error!`], voor het verhogen van fouten tijdens het compileren.

[ounwrap]: Option::unwrap
[runwrap]: Result::unwrap
[`std::panic::set_hook()`]: ../std/panic/fn.set_hook.html
[`panic_any`]: ../std/panic/fn.panic_any.html
[`Box`]: ../std/boxed/struct.Box.html
[`Any`]: crate::any::Any
[`format!`]: ../std/macro.format.html
[book]: ../book/ch09-00-error-handling.html

# Huidige implementatie

Als de hoofdthread panics het zal al uw threads beëindigen en uw programma beëindigen met code `101`.

# Examples

```should_panic
# #![allow(unreachable_code)]
panic!();
panic!("this is a terrible mistake!");
panic!("this is a {} {message}", "fancy", message = "message");
std::panic::panic_any(4); // panic with the value of 4 to be collected elsewhere
```





