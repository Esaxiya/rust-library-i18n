#[doc = include_str!("panic.md")]
#[macro_export]
#[rustc_builtin_macro = "core_panic"]
#[allow_internal_unstable(edition_panic)]
#[stable(feature = "core", since = "1.6.0")]
#[rustc_diagnostic_item = "core_panic_macro"]
macro_rules! panic {
    // Breidt uit naar `$crate::panic::panic_2015` of `$crate::panic::panic_2021`, afhankelijk van de editie van de beller.
    //
    ($($arg:tt)*) => {
        /* compiler built-in */
    };
}

/// Beweert dat twee uitdrukkingen gelijk zijn aan elkaar (met behulp van [`PartialEq`]).
///
/// Op panic zal deze macro de waarden van de expressies met hun debug-representaties afdrukken.
///
///
/// Net als [`assert!`] heeft deze macro een tweede formulier, waar een aangepast panic-bericht kan worden verstrekt.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// assert_eq!(a, b);
///
/// assert_eq!(a, b, "we are testing addition with {} and {}", a, b);
/// ```
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_eq {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // De onderstaande reborrows zijn opzettelijk.
                    // Zonder hen wordt het stack-slot voor de lening geïnitialiseerd voordat de waarden worden vergeleken, wat leidt tot een merkbare vertraging.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // De onderstaande reborrows zijn opzettelijk.
                    // Zonder hen wordt het stack-slot voor de lening geïnitialiseerd voordat de waarden worden vergeleken, wat leidt tot een merkbare vertraging.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// Beweert dat twee uitdrukkingen niet gelijk zijn aan elkaar (met behulp van [`PartialEq`]).
///
/// Op panic zal deze macro de waarden van de expressies met hun debug-representaties afdrukken.
///
///
/// Net als [`assert!`] heeft deze macro een tweede formulier, waar een aangepast panic-bericht kan worden verstrekt.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// assert_ne!(a, b);
///
/// assert_ne!(a, b, "we are testing that the values are not equal");
/// ```
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_ne {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // De onderstaande reborrows zijn opzettelijk.
                    // Zonder hen wordt het stack-slot voor de lening geïnitialiseerd voordat de waarden worden vergeleken, wat leidt tot een merkbare vertraging.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&($left), &($right)) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // De onderstaande reborrows zijn opzettelijk.
                    // Zonder hen wordt het stack-slot voor de lening geïnitialiseerd voordat de waarden worden vergeleken, wat leidt tot een merkbare vertraging.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// Beweert dat een booleaanse expressie tijdens runtime `true` is.
///
/// Hierdoor wordt de [`panic!`]-macro aangeroepen als de opgegeven expressie tijdens runtime niet kan worden geëvalueerd naar `true`.
///
/// Net als [`assert!`] heeft deze macro ook een tweede versie, waar een aangepast panic-bericht kan worden verstrekt.
///
/// # Uses
///
/// In tegenstelling tot [`assert!`] zijn `debug_assert!`-instructies standaard alleen ingeschakeld in niet-geoptimaliseerde builds.
/// Een geoptimaliseerde build zal geen `debug_assert!`-instructies uitvoeren tenzij `-C debug-assertions` wordt doorgegeven aan de compiler.
/// Dit maakt `debug_assert!` nuttig voor cheques die te duur zijn om aanwezig te zijn in een release-build, maar die tijdens de ontwikkeling nuttig kunnen zijn.
/// Het resultaat van het uitbreiden van `debug_assert!` wordt altijd type gecontroleerd.
///
/// Een niet-gecontroleerde bewering zorgt ervoor dat een programma in een inconsistente staat blijft draaien, wat onverwachte gevolgen kan hebben, maar geen onveiligheid introduceert, zolang dit alleen gebeurt in veilige code.
///
/// De prestatiekosten van beweringen zijn echter in het algemeen niet meetbaar.
/// Het vervangen van [`assert!`] door `debug_assert!` wordt dus alleen aangemoedigd na grondige profilering, en nog belangrijker, alleen in veilige code!
///
/// # Examples
///
/// ```
/// // het panic-bericht voor deze beweringen is de stringified waarde van de gegeven uitdrukking.
/////
/// debug_assert!(true);
///
/// fn some_expensive_computation() -> bool { true } // een heel eenvoudige functie
/// debug_assert!(some_expensive_computation());
///
/// // beweren met een aangepast bericht
/// let x = true;
/// debug_assert!(x, "x wasn't true!");
///
/// let a = 3; let b = 27;
/// debug_assert!(a + b == 30, "a = {}, b = {}", a, b);
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "debug_assert_macro"]
macro_rules! debug_assert {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert!($($arg)*); })
}

/// Beweert dat twee uitdrukkingen aan elkaar gelijk zijn.
///
/// Op panic zal deze macro de waarden van de expressies met hun debug-representaties afdrukken.
///
/// In tegenstelling tot [`assert_eq!`] zijn `debug_assert_eq!`-instructies standaard alleen ingeschakeld in niet-geoptimaliseerde builds.
/// Een geoptimaliseerde build zal geen `debug_assert_eq!`-instructies uitvoeren tenzij `-C debug-assertions` wordt doorgegeven aan de compiler.
/// Dit maakt `debug_assert_eq!` nuttig voor cheques die te duur zijn om aanwezig te zijn in een release-build, maar die tijdens de ontwikkeling nuttig kunnen zijn.
///
/// Het resultaat van het uitbreiden van `debug_assert_eq!` wordt altijd type gecontroleerd.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// debug_assert_eq!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! debug_assert_eq {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_eq!($($arg)*); })
}

/// Beweert dat twee uitdrukkingen niet gelijk zijn aan elkaar.
///
/// Op panic zal deze macro de waarden van de expressies met hun debug-representaties afdrukken.
///
/// In tegenstelling tot [`assert_ne!`] zijn `debug_assert_ne!`-instructies standaard alleen ingeschakeld in niet-geoptimaliseerde builds.
/// Een geoptimaliseerde build zal geen `debug_assert_ne!`-instructies uitvoeren tenzij `-C debug-assertions` wordt doorgegeven aan de compiler.
/// Dit maakt `debug_assert_ne!` nuttig voor cheques die te duur zijn om aanwezig te zijn in een release-build, maar die tijdens de ontwikkeling nuttig kunnen zijn.
///
/// Het resultaat van het uitbreiden van `debug_assert_ne!` wordt altijd type gecontroleerd.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// debug_assert_ne!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
macro_rules! debug_assert_ne {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_ne!($($arg)*); })
}

/// Geeft terug of de gegeven uitdrukking overeenkomt met een van de gegeven patronen.
///
/// Net als in een `match`-expressie, kan het patroon optioneel worden gevolgd door `if` en een guard-expressie die toegang heeft tot namen die aan het patroon zijn gebonden.
///
///
/// # Examples
///
/// ```
/// let foo = 'f';
/// assert!(matches!(foo, 'A'..='Z' | 'a'..='z'));
///
/// let bar = Some(4);
/// assert!(matches!(bar, Some(x) if x > 2));
/// ```
#[macro_export]
#[stable(feature = "matches_macro", since = "1.42.0")]
macro_rules! matches {
    ($expression:expr, $( $pattern:pat )|+ $( if $guard: expr )? $(,)?) => {
        match $expression {
            $( $pattern )|+ $( if $guard )? => true,
            _ => false
        }
    }
}

/// Maakt een resultaat uit de verpakking of propageert de fout ervan.
///
/// De `?`-operator is toegevoegd om `try!` te vervangen en moet in plaats daarvan worden gebruikt.
/// Bovendien is `try` een gereserveerd woord in Rust 2018, dus als u het moet gebruiken, moet u de [raw-identifier syntax][ris] gebruiken: `r#try`.
///
///
/// [ris]: https://doc.rust-lang.org/nightly/rust-by-example/compatibility/raw_identifiers.html
///
/// `try!` komt overeen met de gegeven [`Result`].In het geval van de `Ok`-variant heeft de uitdrukking de waarde van de ingepakte waarde.
///
/// In het geval van de `Err`-variant haalt het de interne fout op.`try!` voert vervolgens de conversie uit met behulp van `From`.
/// Dit zorgt voor automatische conversie tussen gespecialiseerde fouten en meer algemene fouten.
/// De resulterende fout wordt dan onmiddellijk geretourneerd.
///
/// Vanwege de vroege terugkeer kan `try!` alleen worden gebruikt in functies die [`Result`] retourneren.
///
/// # Examples
///
/// ```
/// use std::io;
/// use std::fs::File;
/// use std::io::prelude::*;
///
/// enum MyError {
///     FileWriteError
/// }
///
/// impl From<io::Error> for MyError {
///     fn from(e: io::Error) -> MyError {
///         MyError::FileWriteError
///     }
/// }
///
/// // De voorkeursmethode voor het snel retourneren van fouten
/// fn write_to_file_question() -> Result<(), MyError> {
///     let mut file = File::create("my_best_friends.txt")?;
///     file.write_all(b"This is a list of my best friends.")?;
///     Ok(())
/// }
///
/// // De vorige methode voor het snel retourneren van fouten
/// fn write_to_file_using_try() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     r#try!(file.write_all(b"This is a list of my best friends."));
///     Ok(())
/// }
///
/// // Dit komt overeen met:
/// fn write_to_file_using_match() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     match file.write_all(b"This is a list of my best friends.") {
///         Ok(v) => v,
///         Err(e) => return Err(From::from(e)),
///     }
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "1.39.0", reason = "use the `?` operator instead")]
#[doc(alias = "?")]
macro_rules! r#try {
    ($expr:expr $(,)?) => {
        match $expr {
            $crate::result::Result::Ok(val) => val,
            $crate::result::Result::Err(err) => {
                return $crate::result::Result::Err($crate::convert::From::from(err));
            }
        }
    };
}

/// Schrijft opgemaakte gegevens naar een buffer.
///
/// Deze macro accepteert een 'writer', een opmaaktekenreeks en een lijst met argumenten.
/// Argumenten worden opgemaakt volgens de opgegeven opmaakreeks en het resultaat wordt doorgegeven aan de schrijver.
/// De schrijver kan elke waarde zijn met een `write_fmt`-methode;over het algemeen komt dit van een implementatie van ofwel de [`fmt::Write`] of de [`io::Write`] trait.
/// De macro retourneert alles wat de `write_fmt`-methode retourneert;gewoonlijk een [`fmt::Result`] of een [`io::Result`].
///
/// Zie [`std::fmt`] voor meer informatie over de syntaxis van de format string.
///
/// [`std::fmt`]: ../std/fmt/index.html
/// [`fmt::Write`]: crate::fmt::Write
/// [`io::Write`]: ../std/io/trait.Write.html
/// [`fmt::Result`]: crate::fmt::Result
/// [`io::Result`]: ../std/io/type.Result.html
///
/// # Examples
///
/// ```
/// use std::io::Write;
///
/// fn main() -> std::io::Result<()> {
///     let mut w = Vec::new();
///     write!(&mut w, "test")?;
///     write!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(w, b"testformatted arguments");
///     Ok(())
/// }
/// ```
///
/// Een module kan zowel `std::fmt::Write` als `std::io::Write` importeren en `write!` aanroepen voor objecten die een van beide implementeren, aangezien objecten doorgaans niet beide implementeren.
///
/// De module moet echter de gekwalificeerde traits importeren, zodat hun namen niet conflicteren:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     write!(&mut s, "{} {}", "abc", 123)?; // gebruikt fmt::Write::write_fmt
///     write!(&mut v, "s = {:?}", s)?; // gebruikt io::Write::write_fmt
///     assert_eq!(v, b"s = \"abc 123\"");
///     Ok(())
/// }
/// ```
///
/// Note: Deze macro kan ook worden gebruikt in `no_std`-opstellingen.
/// In een `no_std` opstelling ben je verantwoordelijk voor de implementatie details van de componenten.
///
/// ```no_run
/// # extern crate core;
/// use core::fmt::Write;
///
/// struct Example;
///
/// impl Write for Example {
///     fn write_str(&mut self, _s: &str) -> core::fmt::Result {
///          unimplemented!();
///     }
/// }
///
/// let mut m = Example{};
/// write!(&mut m, "Hello World").expect("Not written");
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! write {
    ($dst:expr, $($arg:tt)*) => ($dst.write_fmt($crate::format_args!($($arg)*)))
}

/// Schrijf opgemaakte gegevens in een buffer, met een nieuwe regel toegevoegd.
///
/// Op alle platforms is de nieuwe regel alleen het LINE FEED-teken (`\n`/`U+000A`) (geen extra CARRIAGE RETURN (`\r`/`U+000D`).
///
/// Zie [`write!`] voor meer informatie.Zie [`std::fmt`] voor informatie over de syntaxis van de opmaakreeks.
///
/// [`std::fmt`]: ../std/fmt/index.html
///
/// # Examples
///
/// ```
/// use std::io::{Write, Result};
///
/// fn main() -> Result<()> {
///     let mut w = Vec::new();
///     writeln!(&mut w)?;
///     writeln!(&mut w, "test")?;
///     writeln!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(&w[..], "\ntest\nformatted arguments\n".as_bytes());
///     Ok(())
/// }
/// ```
///
/// Een module kan zowel `std::fmt::Write` als `std::io::Write` importeren en `write!` aanroepen voor objecten die een van beide implementeren, aangezien objecten doorgaans niet beide implementeren.
/// De module moet echter de gekwalificeerde traits importeren, zodat hun namen niet conflicteren:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     writeln!(&mut s, "{} {}", "abc", 123)?; // gebruikt fmt::Write::write_fmt
///     writeln!(&mut v, "s = {:?}", s)?; // gebruikt io::Write::write_fmt
///     assert_eq!(v, b"s = \"abc 123\\n\"\n");
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(format_args_nl)]
macro_rules! writeln {
    ($dst:expr $(,)?) => (
        $crate::write!($dst, "\n")
    );
    ($dst:expr, $($arg:tt)*) => (
        $dst.write_fmt($crate::format_args_nl!($($arg)*))
    );
}

/// Geeft een onbereikbare code aan.
///
/// Dit is handig wanneer de compiler niet kan vaststellen dat bepaalde code onbereikbaar is.Bijvoorbeeld:
///
/// * Match armen met bewakingsvoorwaarden.
/// * Lussen die dynamisch eindigen.
/// * Iteratoren die dynamisch eindigen.
///
/// Als de vaststelling dat de code onbereikbaar is onjuist blijkt te zijn, wordt het programma onmiddellijk beëindigd met een [`panic!`].
///
/// De onveilige tegenhanger van deze macro is de [`unreachable_unchecked`]-functie, die ongedefinieerd gedrag zal veroorzaken als de code wordt bereikt.
///
///
/// [`unreachable_unchecked`]: crate::hint::unreachable_unchecked
///
/// # Panics
///
/// Dit zal altijd [`panic!`] zijn.
///
/// # Examples
///
/// Match armen:
///
/// ```
/// # #[allow(dead_code)]
/// fn foo(x: Option<i32>) {
///     match x {
///         Some(n) if n >= 0 => println!("Some(Non-negative)"),
///         Some(n) if n <  0 => println!("Some(Negative)"),
///         Some(_)           => unreachable!(), // compileerfout als er commentaar wordt gegeven
///         None              => println!("None")
///     }
/// }
/// ```
///
/// Iterators:
///
/// ```
/// # #[allow(dead_code)]
/// fn divide_by_three(x: u32) -> u32 { // een van de slechtste implementaties van x/3
///     for i in 0.. {
///         if 3*i < i { panic!("u32 overflow"); }
///         if x < 3*i { return i-1; }
///     }
///     unreachable!();
/// }
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unreachable {
    () => ({
        $crate::panic!("internal error: entered unreachable code")
    });
    ($msg:expr $(,)?) => ({
        $crate::unreachable!("{}", $msg)
    });
    ($fmt:expr, $($arg:tt)*) => ({
        $crate::panic!($crate::concat!("internal error: entered unreachable code: ", $fmt), $($arg)*)
    });
}

/// Geeft niet-geïmplementeerde code aan door in paniek te raken met een bericht van "not implemented".
///
/// Hierdoor kan je code typecontrole uitvoeren, wat handig is als je een prototype maakt of een trait implementeert waarvoor meerdere methoden nodig zijn die je niet allemaal wilt gebruiken.
///
/// Het verschil tussen `unimplemented!` en [`todo!`] is dat terwijl `todo!` de intentie heeft om de functionaliteit later te implementeren en het bericht "not yet implemented" is, `unimplemented!` dergelijke claims niet maakt.
/// Zijn bericht is "not implemented".
/// Ook zullen sommige IDE's `todo!` S markeren.
///
/// # Panics
///
/// Dit zal altijd [`panic!`] zijn omdat `unimplemented!` slechts een afkorting is voor `panic!` met een vast, specifiek bericht.
///
/// Net als `panic!` heeft deze macro een tweede formulier voor het weergeven van aangepaste waarden.
///
/// # Examples
///
/// Stel dat we een trait `Foo` hebben:
///
/// ```
/// trait Foo {
///     fn bar(&self) -> u8;
///     fn baz(&self);
///     fn qux(&self) -> Result<u64, ()>;
/// }
/// ```
///
/// We willen `Foo` implementeren voor 'MyStruct', maar om de een of andere reden heeft het alleen zin om de `bar()`-functie te implementeren.
/// `baz()` en `qux()` zullen nog steeds moeten worden gedefinieerd in onze implementatie van `Foo`, maar we kunnen `unimplemented!` gebruiken in hun definities om onze code te laten compileren.
///
/// We willen nog steeds dat ons programma stopt met draaien als de niet-geïmplementeerde methoden worden bereikt.
///
/// ```
/// # trait Foo {
/// #     fn bar(&self) -> u8;
/// #     fn baz(&self);
/// #     fn qux(&self) -> Result<u64, ()>;
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) -> u8 {
///         1 + 1
///     }
///
///     fn baz(&self) {
///         // Het heeft geen zin om `baz` een `MyStruct` te gebruiken, dus we hebben hier helemaal geen logica.
/////
///         // Hierdoor wordt "thread 'main' panicked at 'not implemented'" weergegeven.
///         unimplemented!();
///     }
///
///     fn qux(&self) -> Result<u64, ()> {
///         // We hebben hier wat logica, we kunnen een bericht toevoegen aan niet geïmplementeerd!om onze weglating weer te geven.
///         // Dit zal weergeven: "thread 'main' panicked at 'not implemented: MyStruct isn't quxable'".
/////
/////
///         unimplemented!("MyStruct isn't quxable");
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
/// }
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unimplemented {
    () => ($crate::panic!("not implemented"));
    ($($arg:tt)+) => ($crate::panic!("not implemented: {}", $crate::format_args!($($arg)+)));
}

/// Geeft onvoltooide code aan.
///
/// Dit kan handig zijn als u prototypen maakt en alleen uw codetypecontrole wilt hebben.
///
/// Het verschil tussen [`unimplemented!`] en `todo!` is dat terwijl `todo!` de intentie heeft om de functionaliteit later te implementeren en het bericht "not yet implemented" is, `unimplemented!` dergelijke claims niet maakt.
/// Zijn bericht is "not implemented".
/// Ook zullen sommige IDE's `todo!` S markeren.
///
/// # Panics
///
/// Dit zal altijd [`panic!`] zijn.
///
/// # Examples
///
/// Hier is een voorbeeld van een code die in uitvoering is.We hebben een trait `Foo`:
///
/// ```
/// trait Foo {
///     fn bar(&self);
///     fn baz(&self);
/// }
/// ```
///
/// We willen `Foo` op een van onze typen implementeren, maar we willen ook eerst aan alleen `bar()` werken.Om onze code te laten compileren, moeten we `baz()` implementeren, zodat we `todo!` kunnen gebruiken:
///
/// ```
/// # trait Foo {
/// #     fn bar(&self);
/// #     fn baz(&self);
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) {
///         // implementatie komt hier
///     }
///
///     fn baz(&self) {
///         // laten we ons voorlopig geen zorgen maken over de implementatie van baz()
///         todo!();
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
///
///     // we gebruiken niet eens baz(), dus dit is prima.
/// }
/// ```
///
///
///
///
#[macro_export]
#[stable(feature = "todo_macro", since = "1.40.0")]
macro_rules! todo {
    () => ($crate::panic!("not yet implemented"));
    ($($arg:tt)+) => ($crate::panic!("not yet implemented: {}", $crate::format_args!($($arg)+)));
}

/// Definities van ingebouwde macro's.
///
/// De meeste macro-eigenschappen (stabiliteit, zichtbaarheid, etc.) worden hier uit de broncode gehaald, met uitzondering van uitbreidingsfuncties die macro-invoer omzetten in uitvoer, die functies worden geleverd door de compiler.
///
///
pub(crate) mod builtin {

    /// Zorgt ervoor dat compilatie mislukt met het gegeven foutbericht wanneer deze wordt aangetroffen.
    ///
    /// Deze macro moet worden gebruikt wanneer een crate een voorwaardelijke compilatiestrategie gebruikt om betere foutmeldingen te geven voor foutieve omstandigheden.
    ///
    /// Het is de vorm op compilerniveau van [`panic!`], maar geeft een foutmelding tijdens *compilatie* in plaats van tijdens *runtime*.
    ///
    /// # Examples
    ///
    /// Twee van dergelijke voorbeelden zijn macro's en `#[cfg]`-omgevingen.
    ///
    /// Zend een betere compileerfout uit als een macro ongeldige waarden krijgt doorgegeven.
    /// Zonder de laatste branch zou de compiler nog steeds een foutmelding geven, maar de foutmelding zou de twee geldige waarden niet vermelden.
    ///
    /// ```compile_fail
    /// macro_rules! give_me_foo_or_bar {
    ///     (foo) => {};
    ///     (bar) => {};
    ///     ($x:ident) => {
    ///         compile_error!("This macro only accepts `foo` or `bar`");
    ///     }
    /// }
    ///
    /// give_me_foo_or_bar!(neither);
    /// // ^ will fail at compile time with message "This macro only accepts `foo` or `bar`"
    /// ```
    ///
    /// Stuur een compilatiefout uit als een van een aantal functies niet beschikbaar is.
    ///
    /// ```compile_fail
    /// #[cfg(not(any(feature = "foo", feature = "bar")))]
    /// compile_error!("Either feature \"foo\" or \"bar\" must be enabled for this crate.");
    /// ```
    ///
    #[stable(feature = "compile_error_macro", since = "1.20.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! compile_error {
        ($msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Construeert parameters voor de andere macro's voor stringopmaak.
    ///
    /// Deze macro functioneert door een letterlijke opmaakstring te nemen die `{}` bevat voor elk extra doorgegeven argument.
    /// `format_args!` bereidt de aanvullende parameters voor om ervoor te zorgen dat de uitvoer kan worden geïnterpreteerd als een tekenreeks en canonicaliseert de argumenten tot een enkel type.
    /// Elke waarde die de [`Display`] trait implementeert, kan aan `format_args!` worden doorgegeven, evenals elke [`Debug`]-implementatie binnen de opmaakreeks aan een `{:?}`.
    ///
    ///
    /// Deze macro produceert een waarde van het type [`fmt::Arguments`].Deze waarde kan worden doorgegeven aan de macro's in [`std::fmt`] voor het uitvoeren van een nuttige omleiding.
    /// Alle andere opmaakmacro's ([`format! '], [`write!`], [`println!`], enz.) Worden via deze proxyserver uitgevoerd.
    /// `format_args!`, in tegenstelling tot de afgeleide macro's, worden heap-toewijzingen vermeden.
    ///
    /// U kunt de [`fmt::Arguments`]-waarde gebruiken die `format_args!` retourneert in `Debug`-en `Display`-contexten, zoals hieronder te zien is.
    /// Het voorbeeld laat ook zien dat `Debug` en `Display` hetzelfde opmaken: de geïnterpoleerde opmaakstring in `format_args!`.
    ///
    /// ```rust
    /// let debug = format!("{:?}", format_args!("{} foo {:?}", 1, 2));
    /// let display = format!("{}", format_args!("{} foo {:?}", 1, 2));
    /// assert_eq!("1 foo 2", display);
    /// assert_eq!(display, debug);
    /// ```
    ///
    /// Zie de documentatie in [`std::fmt`] voor meer informatie.
    ///
    /// [`Display`]: crate::fmt::Display
    /// [`Debug`]: crate::fmt::Debug
    /// [`fmt::Arguments`]: crate::fmt::Arguments
    /// [`std::fmt`]: ../std/fmt/index.html
    /// [`format!`]: ../std/macro.format.html
    /// [`println!`]: ../std/macro.println.html
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// let s = fmt::format(format_args!("hello {}", "world"));
    /// assert_eq!(s, format!("hello {}", "world"));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// Hetzelfde als `format_args`, maar voegt uiteindelijk een nieuwe regel toe.
    #[unstable(
        feature = "format_args_nl",
        issue = "none",
        reason = "`format_args_nl` is only for internal \
                  language use and is subject to change"
    )]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args_nl {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// Inspecteert een omgevingsvariabele tijdens het compileren.
    ///
    /// Deze macro wordt tijdens het compileren uitgebreid naar de waarde van de genoemde omgevingsvariabele, wat een uitdrukking van het type `&'static str` oplevert.
    ///
    ///
    /// Als de omgevingsvariabele niet is gedefinieerd, wordt er een compilatiefout gegenereerd.
    /// Gebruik in plaats daarvan de [`option_env!`]-macro om geen compilatiefout te veroorzaken.
    ///
    /// # Examples
    ///
    /// ```
    /// let path: &'static str = env!("PATH");
    /// println!("the $PATH variable at the time of compiling was: {}", path);
    /// ```
    ///
    /// U kunt het foutbericht aanpassen door een string als tweede parameter door te geven:
    ///
    /// ```compile_fail
    /// let doc: &'static str = env!("documentation", "what's that?!");
    /// ```
    ///
    /// Als de omgevingsvariabele `documentation` niet is gedefinieerd, krijgt u de volgende foutmelding:
    ///
    /// ```text
    /// error: what's that?!
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
        ($name:expr, $error_msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Inspecteert optioneel een omgevingsvariabele tijdens het compileren.
    ///
    /// Als de genoemde omgevingsvariabele aanwezig is tijdens het compileren, zal dit uitbreiden naar een expressie van het type `Option<&'static str>` waarvan de waarde `Some` is van de waarde van de omgevingsvariabele.
    /// Als de omgevingsvariabele niet aanwezig is, wordt deze uitgebreid naar `None`.
    /// Zie [`Option<T>`][Option] voor meer informatie over dit type.
    ///
    /// Een compilatietijdfout wordt nooit verzonden bij gebruik van deze macro, ongeacht of de omgevingsvariabele aanwezig is of niet.
    ///
    /// # Examples
    ///
    /// ```
    /// let key: Option<&'static str> = option_env!("SECRET_KEY");
    /// println!("the secret key might be: {:?}", key);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! option_env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Voegt ID's samen tot één ID.
    ///
    /// Deze macro gebruikt een willekeurig aantal door komma's gescheiden ID's en voegt ze allemaal samen tot één, wat een uitdrukking oplevert die een nieuwe ID is.
    /// Merk op dat hygiëne ervoor zorgt dat deze macro geen lokale variabelen kan vastleggen.
    /// Als algemene regel zijn macro's ook alleen toegestaan in de positie van een item, instructie of uitdrukking.
    /// Dat betekent dat hoewel u deze macro kunt gebruiken om naar bestaande variabelen, functies of modules enz. Te verwijzen, u er geen nieuwe mee kunt definiëren.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(concat_idents)]
    ///
    /// # fn main() {
    /// fn foobar() -> u32 { 23 }
    ///
    /// let f = concat_idents!(foo, bar);
    /// println!("{}", f());
    ///
    /// // fn concat_idents! (nieuw, leuk, naam) { }//niet op deze manier bruikbaar!
    /// # }
    /// ```
    ///
    ///
    ///
    #[unstable(
        feature = "concat_idents",
        issue = "29599",
        reason = "`concat_idents` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat_idents {
        ($($e:ident),+ $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Voegt letterlijke tekens samen tot een statisch tekenreekssegment.
    ///
    /// Deze macro accepteert een willekeurig aantal door komma's gescheiden letterlijke tekens, wat een uitdrukking van het type `&'static str` oplevert die alle van links naar rechts samengevoegde letterlijke tekens vertegenwoordigt.
    ///
    ///
    /// Letterlijke waarden voor gehele getallen en drijvende komma worden aaneengeschakeld om te worden samengevoegd.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = concat!("test", 10, 'b', true);
    /// assert_eq!(s, "test10btrue");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat {
        ($($e:expr),* $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Breidt uit naar het regelnummer waarop het werd aangeroepen.
    ///
    /// Met [`column!`] en [`file!`] bieden deze macro's foutopsporingsinformatie voor ontwikkelaars over de locatie binnen de bron.
    ///
    /// De uitgebreide uitdrukking heeft het type `u32` en is gebaseerd op 1, dus de eerste regel in elk bestand evalueert naar 1, de tweede naar 2, enz.
    /// Dit komt overeen met foutmeldingen van gewone compilers of populaire editors.
    /// De geretourneerde regel is *niet noodzakelijk* de regel van de `line!`-aanroep zelf, maar eerder de eerste macro-aanroep die leidt naar de aanroep van de `line!`-macro.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_line = line!();
    /// println!("defined on line: {}", current_line);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! line {
        () => {
            /* compiler built-in */
        };
    }

    /// Breidt uit naar het kolomnummer waarop het werd aangeroepen.
    ///
    /// Met [`line!`] en [`file!`] bieden deze macro's foutopsporingsinformatie voor ontwikkelaars over de locatie binnen de bron.
    ///
    /// De uitgebreide uitdrukking heeft het type `u32` en is gebaseerd op 1, dus de eerste kolom in elke regel resulteert in 1, de tweede in 2, enz.
    /// Dit komt overeen met foutmeldingen van gewone compilers of populaire editors.
    /// De geretourneerde kolom is *niet noodzakelijk* de regel van de `column!`-aanroep zelf, maar eerder de eerste macro-aanroep die leidt naar de aanroep van de `column!`-macro.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_col = column!();
    /// println!("defined on column: {}", current_col);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! column {
        () => {
            /* compiler built-in */
        };
    }

    /// Breidt uit naar de bestandsnaam waarin het werd aangeroepen.
    ///
    /// Met [`line!`] en [`column!`] bieden deze macro's foutopsporingsinformatie voor ontwikkelaars over de locatie binnen de bron.
    ///
    /// De uitgebreide uitdrukking heeft het type `&'static str` en het geretourneerde bestand is niet de aanroep van de `file!`-macro zelf, maar eerder de eerste macro-aanroep die leidt tot de aanroep van de `file!`-macro.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let this_file = file!();
    /// println!("defined in file: {}", this_file);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! file {
        () => {
            /* compiler built-in */
        };
    }

    /// Stringent zijn argumenten.
    ///
    /// Deze macro levert een expressie van het type `&'static str` op, wat de stringificatie is van alle tokens die aan de macro zijn doorgegeven.
    /// Er worden geen beperkingen gesteld aan de syntaxis van de macro-aanroep zelf.
    ///
    /// Merk op dat de uitgebreide resultaten van de invoer tokens kunnen veranderen in de future.U moet voorzichtig zijn als u op de output vertrouwt.
    ///
    /// # Examples
    ///
    /// ```
    /// let one_plus_one = stringify!(1 + 1);
    /// assert_eq!(one_plus_one, "1 + 1");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! stringify {
        ($($t:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Bevat een UTF-8-gecodeerd bestand als een string.
    ///
    /// Het bestand bevindt zich relatief ten opzichte van het huidige bestand (vergelijkbaar met hoe modules worden gevonden).
    /// Het opgegeven pad wordt tijdens het compileren op een platformspecifieke manier geïnterpreteerd.
    /// Een aanroep met een Windows-pad dat backslashes `\` bevat, zou bijvoorbeeld niet correct compileren op Unix.
    ///
    ///
    /// Deze macro levert een expressie van het type `&'static str` op, wat de inhoud van het bestand is.
    ///
    /// # Examples
    ///
    /// Stel dat er twee bestanden in dezelfde map zijn met de volgende inhoud:
    ///
    /// Bestand 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// Bestand 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_str = include_str!("spanish.in");
    ///     assert_eq!(my_str, "adiós\n");
    ///     print!("{}", my_str);
    /// }
    /// ```
    ///
    /// Door 'main.rs' te compileren en het resulterende binaire bestand uit te voeren, wordt "adiós" afgedrukt.
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_str {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Bevat een bestand als verwijzing naar een byte-array.
    ///
    /// Het bestand bevindt zich relatief ten opzichte van het huidige bestand (vergelijkbaar met hoe modules worden gevonden).
    /// Het opgegeven pad wordt tijdens het compileren op een platformspecifieke manier geïnterpreteerd.
    /// Een aanroep met een Windows-pad dat backslashes `\` bevat, zou bijvoorbeeld niet correct compileren op Unix.
    ///
    ///
    /// Deze macro levert een expressie van het type `&'static [u8; N]` op, wat de inhoud van het bestand is.
    ///
    /// # Examples
    ///
    /// Stel dat er twee bestanden in dezelfde map zijn met de volgende inhoud:
    ///
    /// Bestand 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// Bestand 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let bytes = include_bytes!("spanish.in");
    ///     assert_eq!(bytes, b"adi\xc3\xb3s\n");
    ///     print!("{}", String::from_utf8_lossy(bytes));
    /// }
    /// ```
    ///
    /// Door 'main.rs' te compileren en het resulterende binaire bestand uit te voeren, wordt "adiós" afgedrukt.
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_bytes {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Breidt uit naar een tekenreeks die het huidige modulepad vertegenwoordigt.
    ///
    /// Het huidige modulepad kan worden gezien als de hiërarchie van modules die teruggaan naar de crate root.
    /// De eerste component van het teruggezonden pad is de naam van de crate die momenteel wordt gecompileerd.
    ///
    /// # Examples
    ///
    /// ```
    /// mod test {
    ///     pub fn foo() {
    ///         assert!(module_path!().ends_with("test"));
    ///     }
    /// }
    ///
    /// test::foo();
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! module_path {
        () => {
            /* compiler built-in */
        };
    }

    /// Evalueert booleaanse combinaties van configuratievlaggen tijdens het compileren.
    ///
    /// Naast het `#[cfg]`-attribuut is deze macro beschikbaar om booleaanse expressie-evaluatie van configuratievlaggen mogelijk te maken.
    /// Dit leidt vaak tot minder dubbele code.
    ///
    /// De syntaxis die aan deze macro wordt gegeven, is dezelfde syntaxis als het kenmerk [`cfg`].
    ///
    /// `cfg!`, in tegenstelling tot `#[cfg]`, verwijdert het geen enkele code en evalueert het alleen naar true of false.
    /// Alle blokken in een if/else-expressie moeten bijvoorbeeld geldig zijn wanneer `cfg!` wordt gebruikt voor de voorwaarde, ongeacht wat `cfg!` evalueert.
    ///
    ///
    /// [`cfg`]: ../reference/conditional-compilation.html#the-cfg-attribute
    ///
    /// # Examples
    ///
    /// ```
    /// let my_directory = if cfg!(windows) {
    ///     "windows-specific-directory"
    /// } else {
    ///     "unix-directory"
    /// };
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! cfg {
        ($($cfg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Parseert een bestand als een uitdrukking of een item volgens de context.
    ///
    /// Het bestand bevindt zich relatief ten opzichte van het huidige bestand (vergelijkbaar met hoe modules worden gevonden).Het opgegeven pad wordt tijdens het compileren op een platformspecifieke manier geïnterpreteerd.
    /// Een aanroep met een Windows-pad dat backslashes `\` bevat, zou bijvoorbeeld niet correct compileren op Unix.
    ///
    /// Het gebruik van deze macro is vaak een slecht idee, want als het bestand als een uitdrukking wordt geparseerd, wordt het op onhygiënische wijze in de omringende code geplaatst.
    /// Dit kan ertoe leiden dat variabelen of functies verschillen van wat het bestand verwachtte als er variabelen of functies zijn die dezelfde naam hebben in het huidige bestand.
    ///
    ///
    /// # Examples
    ///
    /// Stel dat er twee bestanden in dezelfde map zijn met de volgende inhoud:
    ///
    /// Bestand 'monkeys.in':
    ///
    /// ```ignore (only-for-syntax-highlight)
    /// ['🙈', '🙊', '🙉']
    ///     .iter()
    ///     .cycle()
    ///     .take(6)
    ///     .collect::<String>()
    /// ```
    ///
    /// Bestand 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_string = include!("monkeys.in");
    ///     assert_eq!("🙈🙊🙉🙈🙊🙉", my_string);
    ///     println!("{}", my_string);
    /// }
    /// ```
    ///
    /// Door 'main.rs' te compileren en het resulterende binaire bestand uit te voeren, wordt "🙈🙊🙉🙈🙊🙉" afgedrukt.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Beweert dat een booleaanse expressie tijdens runtime `true` is.
    ///
    /// Hierdoor wordt de [`panic!`]-macro aangeroepen als de opgegeven expressie tijdens runtime niet kan worden geëvalueerd naar `true`.
    ///
    /// # Uses
    ///
    /// Beweringen worden altijd gecontroleerd in zowel debug-als release-builds en kunnen niet worden uitgeschakeld.
    /// Zie [`debug_assert!`] voor beweringen die niet standaard zijn ingeschakeld in release-builds.
    ///
    /// Onveilige code kan vertrouwen op `assert!` om runtime-invarianten af te dwingen die, indien overtreden, tot onveiligheid kunnen leiden.
    ///
    /// Andere use-cases van `assert!` zijn onder meer het testen en afdwingen van runtime-invarianten in veilige code (waarvan de overtreding niet kan resulteren in onveiligheid).
    ///
    ///
    /// # Aangepaste berichten
    ///
    /// Deze macro heeft een tweede vorm, waar een aangepast panic-bericht kan worden geleverd met of zonder argumenten voor opmaak.
    /// Zie [`std::fmt`] voor syntaxis voor dit formulier.
    /// Expressies die als indelingsargumenten worden gebruikt, worden alleen geëvalueerd als de bewering mislukt.
    ///
    /// [`std::fmt`]: ../std/fmt/index.html
    ///
    /// # Examples
    ///
    /// ```
    /// // het panic-bericht voor deze beweringen is de stringified waarde van de gegeven uitdrukking.
    /////
    /// assert!(true);
    ///
    /// fn some_computation() -> bool { true } // een heel eenvoudige functie
    ///
    /// assert!(some_computation());
    ///
    /// // beweren met een aangepast bericht
    /// let x = true;
    /// assert!(x, "x wasn't true!");
    ///
    /// let a = 3; let b = 27;
    /// assert!(a + b == 30, "a = {}, b = {}", a, b);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    #[rustc_diagnostic_item = "assert_macro"]
    #[allow_internal_unstable(core_panic, edition_panic)]
    macro_rules! assert {
        ($cond:expr $(,)?) => {{ /* compiler built-in */ }};
        ($cond:expr, $($arg:tt)+) => {{ /* compiler built-in */ }};
    }

    /// Inline montage.
    ///
    /// Lees de [unstable book] voor het gebruik.
    ///
    /// [unstable book]: ../unstable-book/library-features/asm.html
    #[unstable(
        feature = "asm",
        issue = "72016",
        reason = "inline assembly is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! asm {
        ("assembly template",
            $(operands,)*
            $(options($(option),*))?
        ) => {
            /* compiler built-in */
        };
    }

    /// Inline-montage in LLVM-stijl.
    ///
    /// Lees de [unstable book] voor het gebruik.
    ///
    /// [unstable book]: ../unstable-book/library-features/llvm-asm.html
    #[unstable(
        feature = "llvm_asm",
        issue = "70173",
        reason = "prefer using the new asm! syntax instead"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! llvm_asm {
        ("assembly template"
                        : $("output"(operand),)*
                        : $("input"(operand),)*
                        : $("clobbers",)*
                        : $("options",)*) => {
            /* compiler built-in */
        };
    }

    /// Inline-montage op moduleniveau.
    #[unstable(
        feature = "global_asm",
        issue = "35119",
        reason = "`global_asm!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! global_asm {
        ("assembly") => {
            /* compiler built-in */
        };
    }

    /// Afdrukken gaan tokens door naar de standaarduitvoer.
    #[unstable(
        feature = "log_syntax",
        issue = "29598",
        reason = "`log_syntax!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! log_syntax {
        ($($arg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Schakelt traceringfunctionaliteit in of uit die wordt gebruikt voor het opsporen van fouten in andere macro's.
    #[unstable(
        feature = "trace_macros",
        issue = "29598",
        reason = "`trace_macros` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! trace_macros {
        (true) => {{ /* compiler built-in */ }};
        (false) => {{ /* compiler built-in */ }};
    }

    /// Kenmerkmacro die wordt gebruikt om afleidingsmacro's toe te passen.
    #[cfg(not(bootstrap))]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    pub macro derive($item:item) {
        /* compiler built-in */
    }

    /// Kenmerkmacro toegepast op een functie om er een eenheidstest van te maken.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test($item:item) {
        /* compiler built-in */
    }

    /// Kenmerkmacro toegepast op een functie om er een benchmarktest van te maken.
    #[unstable(
        feature = "test",
        issue = "50297",
        soft,
        reason = "`bench` is a part of custom test frameworks which are unstable"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro bench($item:item) {
        /* compiler built-in */
    }

    /// Een implementatiedetail van de `#[test]`-en `#[bench]`-macro's.
    #[unstable(
        feature = "custom_test_frameworks",
        issue = "50297",
        reason = "custom test frameworks are an unstable feature"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test_case($item:item) {
        /* compiler built-in */
    }

    /// Attribuutmacro toegepast op een statisch om deze als globale allocator te registreren.
    ///
    /// Zie ook [`std::alloc::GlobalAlloc`](../std/alloc/trait.GlobalAlloc.html).
    #[stable(feature = "global_allocator", since = "1.28.0")]
    #[allow_internal_unstable(rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro global_allocator($item:item) {
        /* compiler built-in */
    }

    /// Behoudt het item waarop het is toegepast als het doorgegeven pad toegankelijk is en verwijdert het anders.
    #[unstable(
        feature = "cfg_accessible",
        issue = "64797",
        reason = "`cfg_accessible` is not fully implemented"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_accessible($item:item) {
        /* compiler built-in */
    }

    /// Breidt alle `#[cfg]`-en `#[cfg_attr]`-attributen uit in het codefragment waarop het wordt toegepast.
    #[cfg(not(bootstrap))]
    #[unstable(
        feature = "cfg_eval",
        issue = "82679",
        reason = "`cfg_eval` is a recently implemented feature"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_eval($($tt:tt)*) {
        /* compiler built-in */
    }

    /// Onstabiel implementatiedetail van de `rustc`-compiler, gebruik.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics, libstd_sys_internals)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcDecodable($item:item) {
        /* compiler built-in */
    }

    /// Onstabiel implementatiedetail van de `rustc`-compiler, gebruik.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcEncodable($item:item) {
        /* compiler built-in */
    }
}