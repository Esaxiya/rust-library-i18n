//! Samenstelbare externe iteratie.
//!
//! Als je merkt dat je een soort verzameling hebt en een bewerking op de elementen van die verzameling moet uitvoeren, kom je snel 'iterators' tegen.
//! Iterators worden veel gebruikt in idiomatische Rust-code, dus het is de moeite waard om ermee vertrouwd te raken.
//!
//! Voordat we meer uitleggen, laten we het hebben over hoe deze module is gestructureerd:
//!
//! # Organization
//!
//! Deze module is grotendeels ingedeeld naar type:
//!
//! * [Traits] vormen het kerngedeelte: deze traits bepalen wat voor soort iteratoren er zijn en wat je ermee kunt doen.De methoden van deze traits zijn de moeite waard om wat extra studietijd in te steken.
//! * [Functions] bieden een aantal handige manieren om enkele basisherhalingen te maken.
//! * [Structs] zijn vaak de retourtypen van de verschillende methoden op de traits van deze module.Meestal wil je kijken naar de methode die de `struct` maakt, in plaats van naar de `struct` zelf.
//! Voor meer details over waarom, zie '[Implementing Iterator](#implementatie-iterator)'.
//!
//! [Traits]: #traits
//! [Functions]: #functions
//! [Structs]: #structs
//!
//! Dat is het!Laten we in iteratoren graven.
//!
//! # Iterator
//!
//! Het hart en de ziel van deze module is de [`Iterator`] trait.De kern van [`Iterator`] ziet er als volgt uit:
//!
//! ```
//! trait Iterator {
//!     type Item;
//!     fn next(&mut self) -> Option<Self::Item>;
//! }
//! ```
//!
//! Een iterator heeft een methode, [`next`], die, wanneer deze wordt aangeroepen, een [`Option`]` retourneert<Item>'.
//! [`next`] zal [`Some(Item)`] retourneren zolang er elementen zijn, en als ze allemaal uitgeput zijn, zal `None` retourneren om aan te geven dat de iteratie is voltooid.
//! Individuele iterators kunnen ervoor kiezen om de iteratie te hervatten, en dus kan het opnieuw aanroepen van [`next`] uiteindelijk op een gegeven moment [`Some(Item)`] weer teruggeven (zie bijvoorbeeld [`TryIter`]).
//!
//!
//! De volledige definitie van [`Iterator`] omvat ook een aantal andere methoden, maar het zijn standaardmethoden, gebouwd bovenop [`next`], en dus krijg je ze gratis.
//!
//! Iteratoren zijn ook samen te stellen en het is gebruikelijk om ze aan elkaar te koppelen om complexere vormen van verwerking uit te voeren.Zie de [Adapters](#adapters)-sectie hieronder voor meer details.
//!
//! [`Some(Item)`]: Some
//! [`next`]: Iterator::next
//! [`TryIter`]: ../../std/sync/mpsc/struct.TryIter.html
//!
//! # De drie vormen van iteratie
//!
//! Er zijn drie veelgebruikte methoden om iterators uit een verzameling te maken:
//!
//! * `iter()`, die zich herhaalt over `&T`.
//! * `iter_mut()`, die zich herhaalt over `&mut T`.
//! * `into_iter()`, die zich herhaalt over `T`.
//!
//! Verschillende dingen in de standaardbibliotheek kunnen een of meer van de drie implementeren, indien van toepassing.
//!
//! # Iterator implementeren
//!
//! Het maken van een eigen iterator omvat twee stappen: het maken van een `struct` om de status van de iterator vast te houden en vervolgens [`Iterator`] voor die `struct` implementeren.
//! Dit is de reden waarom er zoveel `struct`s in deze module zijn: er is er een voor elke iterator en iteratoradapter.
//!
//! Laten we een iterator maken met de naam `Counter` die telt van `1` tot `5`:
//!
//! ```
//! // Ten eerste de structuur:
//!
//! /// Een iterator die telt van één tot vijf
//! struct Counter {
//!     count: usize,
//! }
//!
//! // we willen dat onze telling bij één begint, dus laten we een new()-methode toevoegen om te helpen.
//! // Dit is niet strikt noodzakelijk, maar wel handig.
//! // Merk op dat we `count` op nul starten, we zullen zien waarom in `next()`'s-implementatie hieronder.
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // Vervolgens implementeren we `Iterator` voor onze `Counter`:
//!
//! impl Iterator for Counter {
//!     // we zullen rekenen met usize
//!     type Item = usize;
//!
//!     // next() is de enige vereiste methode
//!     fn next(&mut self) -> Option<Self::Item> {
//!         // Verhoog onze telling.Daarom zijn we bij nul begonnen.
//!         self.count += 1;
//!
//!         // Controleer of we klaar zijn met tellen of niet.
//!         if self.count < 6 {
//!             Some(self.count)
//!         } else {
//!             None
//!         }
//!     }
//! }
//!
//! // En nu kunnen we het gebruiken!
//!
//! let mut counter = Counter::new();
//!
//! assert_eq!(counter.next(), Some(1));
//! assert_eq!(counter.next(), Some(2));
//! assert_eq!(counter.next(), Some(3));
//! assert_eq!(counter.next(), Some(4));
//! assert_eq!(counter.next(), Some(5));
//! assert_eq!(counter.next(), None);
//! ```
//!
//! [`next`] op deze manier aanroepen wordt repetitief.Rust heeft een constructie die [`next`] op uw iterator kan aanroepen, totdat het `None` bereikt.Laten we dat nu bespreken.
//!
//! Merk ook op dat `Iterator` een standaardimplementatie biedt van methoden zoals `nth` en `fold` die `next` intern aanroepen.
//! Het is echter ook mogelijk om een aangepaste implementatie van methoden zoals `nth` en `fold` te schrijven als een iterator ze efficiënter kan berekenen zonder `next` aan te roepen.
//!
//! # `for` loops en `IntoIterator`
//!
//! De `for`-loop-syntaxis van Rust is eigenlijk suiker voor iterators.Hier is een eenvoudig voorbeeld van `for`:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Hierdoor worden de nummers één tot en met vijf afgedrukt, elk op een eigen regel.Maar je zult hier iets opmerken: we hebben nooit iets op onze vector gebeld om een iterator te maken.Wat geeft?
//!
//! Er is een trait in de standaardbibliotheek om iets naar een iterator te converteren: [`IntoIterator`].
//! Deze trait heeft één methode, [`into_iter`], die het ding dat [`IntoIterator`] implementeert, omzet in een iterator.
//! Laten we die `for`-lus nog eens bekijken, en waar de compiler het naar omzet:
//!
//! [`into_iter`]: IntoIterator::into_iter
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Rust ontsuikert dit tot:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//! {
//!     let result = match IntoIterator::into_iter(values) {
//!         mut iter => loop {
//!             let next;
//!             match iter.next() {
//!                 Some(val) => next = val,
//!                 None => break,
//!             };
//!             let x = next;
//!             let () = { println!("{}", x); };
//!         },
//!     };
//!     result
//! }
//! ```
//!
//! Ten eerste noemen we `into_iter()` op de waarde.Vervolgens matchen we op de iterator die terugkeert, waarbij we [`next`] keer op keer aanroepen totdat we een `None` zien.
//! Op dat moment zijn we `break` uit de lus en zijn we klaar met itereren.
//!
//! Er is nog een subtiel stukje hier: de standaardbibliotheek bevat een interessante implementatie van [`IntoIterator`]:
//!
//! ```ignore (only-for-syntax-highlight)
//! impl<I: Iterator> IntoIterator for I
//! ```
//!
//! Met andere woorden, alle [`Iterator`] s implementeren [`IntoIterator`], door gewoon zichzelf terug te keren.Dit betekent twee dingen:
//!
//! 1. Als u een [`Iterator`] schrijft, kunt u deze gebruiken met een `for`-lus.
//! 2. Als je een collectie maakt, zal het implementeren van [`IntoIterator`] ervoor zorgen dat je collectie kan worden gebruikt met de `for`-lus.
//!
//! # Itereren door middel van verwijzing
//!
//! Omdat [`into_iter()`] `self` op waarde neemt, verbruikt het gebruik van een `for`-lus om een verzameling te herhalen die verzameling.Vaak wilt u een verzameling herhalen zonder deze te consumeren.
//! Veel collecties bieden methoden die iteratoren bieden over referenties, gewoonlijk respectievelijk `iter()` en `iter_mut()` genoemd:
//!
//! ```
//! let mut values = vec![41];
//! for x in values.iter_mut() {
//!     *x += 1;
//! }
//! for x in values.iter() {
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1); // `values` is nog steeds eigendom van deze functie.
//! ```
//!
//! Als een verzamelingstype `C` `iter()` levert, implementeert het meestal ook `IntoIterator` voor `&C`, met een implementatie die alleen `iter()` aanroept.
//! Evenzo implementeert een verzameling `C` die `iter_mut()` levert in het algemeen `IntoIterator` voor `&mut C` door te delegeren naar `iter_mut()`.Dit maakt een handige steno mogelijk:
//!
//! ```
//! let mut values = vec![41];
//! for x in &mut values { // hetzelfde als `values.iter_mut()`
//!     *x += 1;
//! }
//! for x in &values { // hetzelfde als `values.iter()`
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1);
//! ```
//!
//! Hoewel veel collecties `iter()` bieden, bieden niet alle `iter_mut()`.
//! Het muteren van de sleutels van een [`HashSet<T>`] of [`HashMap<K, V>`] zou de verzameling bijvoorbeeld in een inconsistente staat kunnen brengen als de sleutel-hashes veranderen, dus deze verzamelingen bieden alleen `iter()` aan.
//!
//! [`into_iter()`]: IntoIterator::into_iter
//! [`HashSet<T>`]: ../../std/collections/struct.HashSet.html
//! [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
//!
//! # Adapters
//!
//! Functies die een [`Iterator`] nemen en een andere [`Iterator`] retourneren, worden vaak 'iteratoradapters' genoemd, omdat ze een vorm zijn van de 'adapter
//! pattern'.
//!
//! Veelgebruikte iteratoradapters zijn [`map`], [`take`] en [`filter`].
//! Zie hun documentatie voor meer informatie.
//!
//! Als een iteratoradapter panics is, bevindt de iterator zich in een niet-gespecificeerde (maar geheugenveilige) toestand.
//! Het is ook niet gegarandeerd dat deze toestand hetzelfde blijft in alle versies van Rust, dus u moet niet vertrouwen op de exacte waarden die worden geretourneerd door een iterator die in paniek raakte.
//!
//! [`map`]: Iterator::map
//! [`take`]: Iterator::take
//! [`filter`]: Iterator::filter
//!
//! # Laziness
//!
//! Iterators (en iterator [adapters](#adapters)) zijn *lui*. Dit betekent dat alleen het maken van een iterator _do_ niet veel oplevert. Er gebeurt eigenlijk niets totdat je [`next`] aanroept.
//! Dit is soms een bron van verwarring bij het maken van een iterator uitsluitend vanwege de bijwerkingen.
//! De [`map`]-methode roept bijvoorbeeld een afsluiting aan op elk element waarover het itereert:
//!
//! ```
//! # #![allow(unused_must_use)]
//! let v = vec![1, 2, 3, 4, 5];
//! v.iter().map(|x| println!("{}", x));
//! ```
//!
//! Hiermee worden geen waarden afgedrukt, omdat we alleen een iterator hebben gemaakt in plaats van deze te gebruiken.De compiler zal ons waarschuwen voor dit soort gedrag:
//!
//! ```text
//! warning: unused result that must be used: iterators are lazy and
//! do nothing unless consumed
//! ```
//!
//! De idiomatische manier om een [`map`] te schrijven vanwege de bijwerkingen is door een `for`-lus te gebruiken of de [`for_each`]-methode aan te roepen:
//!
//! ```
//! let v = vec![1, 2, 3, 4, 5];
//!
//! v.iter().for_each(|x| println!("{}", x));
//! // or
//! for x in &v {
//!     println!("{}", x);
//! }
//! ```
//!
//! [`map`]: Iterator::map
//! [`for_each`]: Iterator::for_each
//!
//! Een andere veelgebruikte manier om een iterator te evalueren, is door de [`collect`]-methode te gebruiken om een nieuwe verzameling te produceren.
//!
//! [`collect`]: Iterator::collect
//!
//! # Infinity
//!
//! Iteratoren hoeven niet eindig te zijn.Een bereik met een open einde is bijvoorbeeld een oneindige iterator:
//!
//! ```
//! let numbers = 0..;
//! ```
//!
//! Het is gebruikelijk om de [`take`] iteratoradapter te gebruiken om een oneindige iterator in een eindige te veranderen:
//!
//! ```
//! let numbers = 0..;
//! let five_numbers = numbers.take(5);
//!
//! for number in five_numbers {
//!     println!("{}", number);
//! }
//! ```
//!
//! Hierdoor worden de nummers `0` tot en met `4` afgedrukt, elk op een eigen regel.
//!
//! Houd er rekening mee dat methoden op oneindige iteratoren, zelfs die waarvoor een resultaat wiskundig in eindige tijd kan worden bepaald, mogelijk niet worden beëindigd.
//! Specifiek, methoden zoals [`min`], die in het algemeen elk element in de iterator moeten doorlopen, zullen waarschijnlijk niet succesvol terugkeren voor een oneindige iterator.
//!
//! ```no_run
//! let ones = std::iter::repeat(1);
//! let least = ones.min().unwrap(); // Oh nee!Een oneindige lus!
//! // `ones.min()` veroorzaakt een oneindige lus, dus we zullen dit punt niet bereiken!
//! println!("The smallest number one is {}.", least);
//! ```
//!
//! [`take`]: Iterator::take
//! [`min`]: Iterator::min
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::Iterator;

#[unstable(
    feature = "step_trait",
    reason = "likely to be replaced by finer-grained traits",
    issue = "42168"
)]
pub use self::range::Step;

#[stable(feature = "iter_empty", since = "1.2.0")]
pub use self::sources::{empty, Empty};
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub use self::sources::{from_fn, FromFn};
#[stable(feature = "iter_once", since = "1.2.0")]
pub use self::sources::{once, Once};
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub use self::sources::{once_with, OnceWith};
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::sources::{repeat, Repeat};
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub use self::sources::{repeat_with, RepeatWith};
#[stable(feature = "iter_successors", since = "1.34.0")]
pub use self::sources::{successors, Successors};

#[stable(feature = "fused", since = "1.26.0")]
pub use self::traits::FusedIterator;
#[unstable(issue = "none", feature = "inplace_iteration")]
pub use self::traits::InPlaceIterable;
#[unstable(feature = "trusted_len", issue = "37572")]
pub use self::traits::TrustedLen;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::{
    DoubleEndedIterator, ExactSizeIterator, Extend, FromIterator, IntoIterator, Product, Sum,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::adapters::Cloned;
#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::adapters::Copied;
#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::adapters::Flatten;
#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::adapters::MapWhile;
#[unstable(feature = "inplace_iteration", issue = "none")]
pub use self::adapters::SourceIter;
#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::adapters::StepBy;
#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::adapters::TrustedRandomAccess;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::adapters::{
    Chain, Cycle, Enumerate, Filter, FilterMap, FlatMap, Fuse, Inspect, Map, Peekable, Rev, Scan,
    Skip, SkipWhile, Take, TakeWhile, Zip,
};
#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::adapters::{Intersperse, IntersperseWith};

pub(crate) use self::adapters::process_results;

mod adapters;
mod range;
mod sources;
mod traits;