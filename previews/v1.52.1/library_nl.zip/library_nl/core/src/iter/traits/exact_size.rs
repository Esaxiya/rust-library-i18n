/// Een iterator die de exacte lengte kent.
///
/// Veel [`Iterator`] s weten niet hoe vaak ze zullen herhalen, maar sommigen wel.
/// Als een iterator weet hoe vaak hij kan itereren, kan het nuttig zijn om toegang tot die informatie te geven.
/// Als u bijvoorbeeld achteruit wilt herhalen, is het een goed begin om te weten waar het einde is.
///
/// Wanneer u een `ExactSizeIterator` implementeert, moet u ook [`Iterator`] implementeren.
/// Wanneer u dit doet, moet de implementatie van [`Iterator::size_hint`]* * de exacte grootte van de iterator retourneren.
///
/// De [`len`]-methode heeft een standaardimplementatie, dus u moet deze meestal niet implementeren.
/// Het is echter mogelijk dat u een beter presterende implementatie kunt bieden dan de standaardimplementatie, dus het is logisch om deze in dit geval te overschrijven.
///
///
/// Merk op dat deze trait een veilige trait is en als zodanig *niet* en *niet* kan garanderen dat de geretourneerde lengte correct is.
/// Dit betekent dat `unsafe`-code **niet** mag vertrouwen op de juistheid van [`Iterator::size_hint`].
/// De onstabiele en onveilige [`TrustedLen`](super::marker::TrustedLen) trait geeft deze extra garantie.
///
/// [`len`]: ExactSizeIterator::len
///
/// # Examples
///
/// Basisgebruik:
///
/// ```
/// // een eindig bereik weet precies hoe vaak het zal herhalen
/// let five = 0..5;
///
/// assert_eq!(5, five.len());
/// ```
///
/// In de [module-level docs] hebben we een [`Iterator`] geïmplementeerd, `Counter`.
/// Laten we er ook `ExactSizeIterator` voor implementeren:
///
/// [module-level docs]: crate::iter
///
/// ```
/// # struct Counter {
/// #     count: usize,
/// # }
/// # impl Counter {
/// #     fn new() -> Counter {
/// #         Counter { count: 0 }
/// #     }
/// # }
/// # impl Iterator for Counter {
/// #     type Item = usize;
/// #     fn next(&mut self) -> Option<Self::Item> {
/// #         self.count += 1;
/// #         if self.count < 6 {
/// #             Some(self.count)
/// #         } else {
/// #             None
/// #         }
/// #     }
/// # }
/// impl ExactSizeIterator for Counter {
///     // We kunnen eenvoudig het resterende aantal iteraties berekenen.
///     fn len(&self) -> usize {
///         5 - self.count
///     }
/// }
///
/// // En nu kunnen we het gebruiken!
///
/// let counter = Counter::new();
///
/// assert_eq!(5, counter.len());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ExactSizeIterator: Iterator {
    /// Retourneert de exacte lengte van de iterator.
    ///
    /// De implementatie zorgt ervoor dat de iterator exact `len()` meer keer een [`Some(T)`]-waarde retourneert, voordat [`None`] wordt geretourneerd.
    ///
    /// Deze methode heeft een standaardimplementatie, dus u moet deze meestal niet rechtstreeks implementeren.
    /// Als u echter voor een efficiëntere implementatie kunt zorgen, kunt u dat doen.
    /// Zie de [trait-level]-documenten voor een voorbeeld.
    ///
    /// Deze functie heeft dezelfde veiligheidsgaranties als de [`Iterator::size_hint`]-functie.
    ///
    /// [trait-level]: ExactSizeIterator
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// Basisgebruik:
    ///
    /// ```
    /// // een eindig bereik weet precies hoe vaak het zal herhalen
    /// let five = 0..5;
    ///
    /// assert_eq!(5, five.len());
    /// ```
    ///
    ///
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn len(&self) -> usize {
        let (lower, upper) = self.size_hint();
        // Note: Deze bewering is overdreven defensief, maar controleert de invariant
        // gegarandeerd door de trait.
        // Als deze trait rust-internal was, zouden we debug_assert !;assert_eq!zal ook alle Rust-gebruikersimplementaties controleren.
        //
        assert_eq!(upper, Some(lower));
        lower
    }

    /// Retourneert `true` als de iterator leeg is.
    ///
    /// Deze methode heeft een standaardimplementatie met [`ExactSizeIterator::len()`], dus u hoeft deze niet zelf te implementeren.
    ///
    ///
    /// # Examples
    ///
    /// Basisgebruik:
    ///
    /// ```
    /// #![feature(exact_size_is_empty)]
    ///
    /// let mut one_element = std::iter::once(0);
    /// assert!(!one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), Some(0));
    /// assert!(one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), None);
    /// ```
    #[inline]
    #[unstable(feature = "exact_size_is_empty", issue = "35428")]
    fn is_empty(&self) -> bool {
        self.len() == 0
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator + ?Sized> ExactSizeIterator for &mut I {
    fn len(&self) -> usize {
        (**self).len()
    }
    fn is_empty(&self) -> bool {
        (**self).is_empty()
    }
}