/// Conversie van een [`Iterator`].
///
/// Door `FromIterator` voor een type te implementeren, definieert u hoe het wordt gemaakt op basis van een iterator.
/// Dit is gebruikelijk voor typen die een soort verzameling beschrijven.
///
/// [`FromIterator::from_iter()`] wordt zelden expliciet aangeroepen en wordt in plaats daarvan gebruikt via de [`Iterator::collect()`]-methode.
///
/// Zie de [`Iterator::collect()`]'s-documentatie voor meer voorbeelden.
///
/// Zie ook: [`IntoIterator`].
///
/// # Examples
///
/// Basisgebruik:
///
/// ```
/// use std::iter::FromIterator;
///
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v = Vec::from_iter(five_fives);
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// [`Iterator::collect()`] gebruiken om `FromIterator` impliciet te gebruiken:
///
/// ```
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v: Vec<i32> = five_fives.collect();
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// `FromIterator` implementeren voor uw type:
///
/// ```
/// use std::iter::FromIterator;
///
/// // Een voorbeeldcollectie, dat is maar een wikkel over Vec<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Laten we het een paar methoden geven, zodat we er een kunnen maken en er dingen aan kunnen toevoegen.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // en we zullen FromIterator implementeren
/// impl FromIterator<i32> for MyCollection {
///     fn from_iter<I: IntoIterator<Item=i32>>(iter: I) -> Self {
///         let mut c = MyCollection::new();
///
///         for i in iter {
///             c.add(i);
///         }
///
///         c
///     }
/// }
///
/// // Nu kunnen we een nieuwe iterator maken ...
/// let iter = (0..5).into_iter();
///
/// // ... en maak er een MyCollection van
/// let c = MyCollection::from_iter(iter);
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
///
/// // verzamel ook werken!
///
/// let iter = (0..5).into_iter();
/// let c: MyCollection = iter.collect();
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "a value of type `{Self}` cannot be built from an iterator \
               over elements of type `{A}`",
    label = "value of type `{Self}` cannot be built from `std::iter::Iterator<Item={A}>`"
)]
pub trait FromIterator<A>: Sized {
    /// Creëert een waarde uit een iterator.
    ///
    /// Zie de [module-level documentation] voor meer.
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// Basisgebruik:
    ///
    /// ```
    /// use std::iter::FromIterator;
    ///
    /// let five_fives = std::iter::repeat(5).take(5);
    ///
    /// let v = Vec::from_iter(five_fives);
    ///
    /// assert_eq!(v, vec![5, 5, 5, 5, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_iter<T: IntoIterator<Item = A>>(iter: T) -> Self;
}

/// Conversie naar een [`Iterator`].
///
/// Door `IntoIterator` voor een type te implementeren, definieert u hoe het zal worden geconverteerd naar een iterator.
/// Dit is gebruikelijk voor typen die een soort verzameling beschrijven.
///
/// Een voordeel van het implementeren van `IntoIterator` is dat uw type [work with Rust's `for` loop syntax](crate::iter#for-loops-and-intoiterator) zal zijn.
///
///
/// Zie ook: [`FromIterator`].
///
/// # Examples
///
/// Basisgebruik:
///
/// ```
/// let v = vec![1, 2, 3];
/// let mut iter = v.into_iter();
///
/// assert_eq!(Some(1), iter.next());
/// assert_eq!(Some(2), iter.next());
/// assert_eq!(Some(3), iter.next());
/// assert_eq!(None, iter.next());
/// ```
/// `IntoIterator` implementeren voor uw type:
///
/// ```
/// // Een voorbeeldcollectie, dat is maar een wikkel over Vec<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Laten we het een paar methoden geven, zodat we er een kunnen maken en er dingen aan kunnen toevoegen.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // en we zullen IntoIterator implementeren
/// impl IntoIterator for MyCollection {
///     type Item = i32;
///     type IntoIter = std::vec::IntoIter<Self::Item>;
///
///     fn into_iter(self) -> Self::IntoIter {
///         self.0.into_iter()
///     }
/// }
///
/// // Nu kunnen we een nieuwe collectie maken ...
/// let mut c = MyCollection::new();
///
/// // ... voeg er wat dingen aan toe ...
/// c.add(0);
/// c.add(1);
/// c.add(2);
///
/// // ... en verander het dan in een Iterator:
/// for (i, n) in c.into_iter().enumerate() {
///     assert_eq!(i as i32, n);
/// }
/// ```
///
/// Het is gebruikelijk om `IntoIterator` te gebruiken als een trait bound.Hierdoor kan het type invoerverzameling veranderen, zolang het nog een iterator is.
/// Extra grenzen kunnen worden gespecificeerd door te beperken tot
/// `Item`:
///
/// ```rust
/// fn collect_as_strings<T>(collection: T) -> Vec<String>
/// where
///     T: IntoIterator,
///     T::Item: std::fmt::Debug,
/// {
///     collection
///         .into_iter()
///         .map(|item| format!("{:?}", item))
///         .collect()
/// }
/// ```
///
///
#[rustc_diagnostic_item = "IntoIterator"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait IntoIterator {
    /// Het type elementen dat wordt herhaald.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// In wat voor soort iterator veranderen we dit?
    #[stable(feature = "rust1", since = "1.0.0")]
    type IntoIter: Iterator<Item = Self::Item>;

    /// Creëert een iterator van een waarde.
    ///
    /// Zie de [module-level documentation] voor meer.
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// Basisgebruik:
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    /// let mut iter = v.into_iter();
    ///
    /// assert_eq!(Some(1), iter.next());
    /// assert_eq!(Some(2), iter.next());
    /// assert_eq!(Some(3), iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    #[lang = "into_iter"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into_iter(self) -> Self::IntoIter;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator> IntoIterator for I {
    type Item = I::Item;
    type IntoIter = I;

    fn into_iter(self) -> I {
        self
    }
}

/// Breid een collectie uit met de inhoud van een iterator.
///
/// Iteratoren produceren een reeks waarden, en verzamelingen kunnen ook worden gezien als een reeks waarden.
/// De `Extend` trait overbrugt deze kloof, waardoor u een collectie kunt uitbreiden door de inhoud van die iterator op te nemen.
/// Bij het uitbreiden van een collectie met een reeds bestaande sleutel, wordt dat item bijgewerkt of, in het geval van collecties die meerdere items met gelijke sleutels toestaan, wordt dat item ingevoegd.
///
///
/// # Examples
///
/// Basisgebruik:
///
/// ```
/// // Je kunt een string uitbreiden met enkele karakters:
/// let mut message = String::from("The first three letters are: ");
///
/// message.extend(&['a', 'b', 'c']);
///
/// assert_eq!("abc", &message[29..32]);
/// ```
///
/// `Extend` implementeren:
///
/// ```
/// // Een voorbeeldcollectie, dat is maar een wikkel over Vec<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Laten we het een paar methoden geven, zodat we er een kunnen maken en er dingen aan kunnen toevoegen.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // aangezien MyCollection een lijst met i32's heeft, implementeren we Extend voor i32
/// impl Extend<i32> for MyCollection {
///
///     // Dit is een beetje eenvoudiger met de handtekening van het concrete type: we kunnen uitbreiden op alles wat kan worden omgezet in een Iterator die ons i32s geeft.
///     // Omdat we i32s nodig hebben om in MyCollection te plaatsen.
/////
///     fn extend<T: IntoIterator<Item=i32>>(&mut self, iter: T) {
///
///         // De implementatie is heel eenvoudig: loop door de iterator en add() elk element voor onszelf.
/////
///         for elem in iter {
///             self.add(elem);
///         }
///     }
/// }
///
/// let mut c = MyCollection::new();
///
/// c.add(5);
/// c.add(6);
/// c.add(7);
///
/// // laten we onze collectie uitbreiden met nog drie nummers
/// c.extend(vec![1, 2, 3]);
///
/// // we hebben deze elementen aan het einde toegevoegd
/// assert_eq!("MyCollection([5, 6, 7, 1, 2, 3])", format!("{:?}", c));
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Extend<A> {
    /// Breidt een collectie uit met de inhoud van een iterator.
    ///
    /// Omdat dit de enige vereiste methode is voor deze trait, bevatten de [trait-level]-documenten meer details.
    ///
    ///
    /// [trait-level]: Extend
    ///
    /// # Examples
    ///
    /// Basisgebruik:
    ///
    /// ```
    /// // Je kunt een string uitbreiden met enkele karakters:
    /// let mut message = String::from("abc");
    ///
    /// message.extend(['d', 'e', 'f'].iter());
    ///
    /// assert_eq!("abcdef", &message);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn extend<T: IntoIterator<Item = A>>(&mut self, iter: T);

    /// Breidt een collectie uit met precies één element.
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_one(&mut self, item: A) {
        self.extend(Some(item));
    }

    /// Reserveert capaciteit in een collectie voor het opgegeven aantal aanvullende elementen.
    ///
    /// De standaardimplementatie doet niets.
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_reserve(&mut self, additional: usize) {
        let _ = additional;
    }
}

#[stable(feature = "extend_for_unit", since = "1.28.0")]
impl Extend<()> for () {
    fn extend<T: IntoIterator<Item = ()>>(&mut self, iter: T) {
        iter.into_iter().for_each(drop)
    }
    fn extend_one(&mut self, _item: ()) {}
}