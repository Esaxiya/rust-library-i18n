/// Een iterator die altijd `None` blijft opleveren als hij uitgeput is.
///
/// Door een gefuseerde iterator aan te roepen die eenmaal `None` heeft geretourneerd, wordt [`None`] gegarandeerd weer geretourneerd.
/// Deze trait moet worden geïmplementeerd door alle iterators die zich op deze manier gedragen, omdat het het mogelijk maakt om [`Iterator::fuse()`] te optimaliseren.
///
///
/// Note: Over het algemeen zou u `FusedIterator` niet in generieke grenzen moeten gebruiken als u een gefuseerde iterator nodig heeft.
/// In plaats daarvan zou je gewoon [`Iterator::fuse()`] op de iterator moeten aanroepen.
/// Als de iterator al is gefuseerd, is de extra [`Fuse`]-wrapper een no-op zonder prestatieverlies.
///
/// [`Fuse`]: crate::iter::Fuse
///
#[stable(feature = "fused", since = "1.26.0")]
#[rustc_unsafe_specialization_marker]
pub trait FusedIterator: Iterator {}

#[stable(feature = "fused", since = "1.26.0")]
impl<I: FusedIterator + ?Sized> FusedIterator for &mut I {}

/// Een iterator die een nauwkeurige lengte rapporteert met size_hint.
///
/// De iterator geeft een hint van de grootte weer waarbij deze ofwel exact is (ondergrens is gelijk aan bovengrens), of de bovengrens is [`None`].
///
/// De bovengrens mag alleen [`None`] zijn als de werkelijke iteratorlengte groter is dan [`usize::MAX`].
/// In dat geval moet de ondergrens [`usize::MAX`] zijn, wat resulteert in een [`Iterator::size_hint()`] of `(usize::MAX, None)`.
///
/// De iterator moet precies het aantal elementen produceren dat het heeft gerapporteerd of divergeren voordat het einde is bereikt.
///
/// # Safety
///
/// Deze trait mag alleen worden uitgevoerd als het contract wordt gehandhaafd.
/// Consumenten van deze trait moeten de bovengrens van [`Iterator::size_hint()`]’s inspecteren.
///
///
///
#[unstable(feature = "trusted_len", issue = "37572")]
#[rustc_unsafe_specialization_marker]
pub unsafe trait TrustedLen: Iterator {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<I: TrustedLen + ?Sized> TrustedLen for &mut I {}

/// Een iterator die bij het opleveren van een item ten minste één element uit de onderliggende [`SourceIter`] heeft gehaald.
///
/// Het aanroepen van een methode die de iterator voortschrijdt, bijv
/// [`next()`] of [`try_fold()`], garandeert dat voor elke stap ten minste één waarde van de onderliggende bron van de iterator is verwijderd en dat het resultaat van de iteratorketen op zijn plaats kan worden ingevoegd, ervan uitgaande dat structurele beperkingen van de bron een dergelijke invoeging mogelijk maken.
///
/// Met andere woorden, deze trait geeft aan dat een iteratorpijplijn ter plaatse kan worden verzameld.
///
/// [`SourceIter`]: crate::iter::SourceIter
/// [`next()`]: Iterator::next
/// [`try_fold()`]: Iterator::try_fold
///
///
#[unstable(issue = "none", feature = "inplace_iteration")]
pub unsafe trait InPlaceIterable: Iterator {}