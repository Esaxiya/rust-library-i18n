// ignore-tidy-filelength Dit bestand bestaat bijna uitsluitend uit de definitie van `Iterator`.
// We kunnen dat niet opsplitsen in meerdere bestanden.
//

use crate::cmp::{self, Ordering};
use crate::ops::{ControlFlow, Try};

use super::super::TrustedRandomAccess;
use super::super::{Chain, Cloned, Copied, Cycle, Enumerate, Filter, FilterMap, Fuse};
use super::super::{FlatMap, Flatten};
use super::super::{FromIterator, Intersperse, IntersperseWith, Product, Sum, Zip};
use super::super::{
    Inspect, Map, MapWhile, Peekable, Rev, Scan, Skip, SkipWhile, StepBy, Take, TakeWhile,
};

fn _assert_is_object_safe(_: &dyn Iterator<Item = ()>) {}

/// Een interface voor het omgaan met iteratoren.
///
/// Dit is de belangrijkste iterator trait.
/// Zie de [module-level documentation] voor meer informatie over het concept van iteratoren in het algemeen.
/// In het bijzonder wilt u misschien weten hoe u [implement `Iterator`][impl].
///
/// [module-level documentation]: crate::iter
/// [impl]: crate::iter#implementing-iterator
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    on(
        _Self = "[std::ops::Range<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..end]` is an array of one `Range`; you might have meant to have a `Range` \
                without the brackets: `start..end`"
    ),
    on(
        _Self = "[std::ops::RangeFrom<Idx>; 1]",
        label = "if you meant to iterate from a value onwards, remove the square brackets",
        note = "`[start..]` is an array of one `RangeFrom`; you might have meant to have a \
              `RangeFrom` without the brackets: `start..`, keeping in mind that iterating over an \
              unbounded iterator will run forever unless you `break` or `return` from within the \
              loop"
    ),
    on(
        _Self = "[std::ops::RangeTo<Idx>; 1]",
        label = "if you meant to iterate until a value, remove the square brackets and add a \
                 starting value",
        note = "`[..end]` is an array of one `RangeTo`; you might have meant to have a bounded \
                `Range` without the brackets: `0..end`"
    ),
    on(
        _Self = "[std::ops::RangeInclusive<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..=end]` is an array of one `RangeInclusive`; you might have meant to have a \
              `RangeInclusive` without the brackets: `start..=end`"
    ),
    on(
        _Self = "[std::ops::RangeToInclusive<Idx>; 1]",
        label = "if you meant to iterate until a value (including it), remove the square brackets \
                 and add a starting value",
        note = "`[..=end]` is an array of one `RangeToInclusive`; you might have meant to have a \
                bounded `RangeInclusive` without the brackets: `0..=end`"
    ),
    on(
        _Self = "std::ops::RangeTo<Idx>",
        label = "if you meant to iterate until a value, add a starting value",
        note = "`..end` is a `RangeTo`, which cannot be iterated on; you might have meant to have a \
              bounded `Range`: `0..end`"
    ),
    on(
        _Self = "std::ops::RangeToInclusive<Idx>",
        label = "if you meant to iterate until a value (including it), add a starting value",
        note = "`..=end` is a `RangeToInclusive`, which cannot be iterated on; you might have meant \
              to have a bounded `RangeInclusive`: `0..=end`"
    ),
    on(
        _Self = "&str",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "std::string::String",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "[]",
        label = "borrow the array with `&` or call `.iter()` on it to iterate over it",
        note = "arrays are not iterators, but slices like the following are: `&[1, 2, 3]`"
    ),
    on(
        _Self = "{integral}",
        note = "if you want to iterate between `start` until a value `end`, use the exclusive range \
              syntax `start..end` or the inclusive range syntax `start..=end`"
    ),
    label = "`{Self}` is not an iterator",
    message = "`{Self}` is not an iterator"
)]
#[doc(spotlight)]
#[rustc_diagnostic_item = "Iterator"]
#[must_use = "iterators are lazy and do nothing unless consumed"]
pub trait Iterator {
    /// Het type elementen dat wordt herhaald.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// Gaat de iterator vooruit en retourneert de volgende waarde.
    ///
    /// Retourneert [`None`] wanneer de iteratie is voltooid.
    /// Individuele iteratorimplementaties kunnen ervoor kiezen om de iteratie te hervatten, en dus het opnieuw aanroepen van `next()` kan uiteindelijk op een gegeven moment [`Some(Item)`] weer teruggeven.
    ///
    ///
    /// [`Some(Item)`]: Some
    ///
    /// # Examples
    ///
    /// Basisgebruik:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // Een aanroep naar next() retourneert de volgende waarde ...
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    ///
    /// // ... en dan Geen als het voorbij is.
    /// assert_eq!(None, iter.next());
    ///
    /// // Meer oproepen kunnen `None` wel of niet retourneren.Hier zullen ze altijd.
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[lang = "next"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next(&mut self) -> Option<Self::Item>;

    /// Retourneert de grenzen van de resterende lengte van de iterator.
    ///
    /// In het bijzonder retourneert `size_hint()` een tuple waarbij het eerste element de ondergrens is en het tweede element de bovengrens.
    ///
    /// De tweede helft van het tupel dat wordt geretourneerd, is een [`Option`]`<`[`usize`] `>`.
    /// Een [`None`] betekent hier dat er ofwel geen bekende bovengrens is, of dat de bovengrens groter is dan [`usize`].
    ///
    /// # Implementatie notities
    ///
    /// Het wordt niet afgedwongen dat een iteratorimplementatie het aangegeven aantal elementen oplevert.Een buggy-iterator kan minder opleveren dan de ondergrens of meer dan de bovengrens van elementen.
    ///
    /// `size_hint()` is primair bedoeld om te worden gebruikt voor optimalisaties zoals het reserveren van ruimte voor de elementen van de iterator, maar mag niet vertrouwd worden om bijvoorbeeld grenscontroles in onveilige code weg te laten.
    /// Een onjuiste implementatie van `size_hint()` mag niet leiden tot schendingen van de geheugenveiligheid.
    ///
    /// Dat gezegd hebbende, zou de implementatie een juiste schatting moeten geven, omdat het anders in strijd zou zijn met het protocol van trait.
    ///
    /// De standaardimplementatie retourneert `(0,` [`None`]`)`wat correct is voor elke iterator.
    ///
    /// [`usize`]: type@usize
    ///
    /// # Examples
    ///
    /// Basisgebruik:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let iter = a.iter();
    ///
    /// assert_eq!((3, Some(3)), iter.size_hint());
    /// ```
    ///
    /// Een complexer voorbeeld:
    ///
    /// ```
    /// // De even nummers van nul tot tien.
    /// let iter = (0..10).filter(|x| x % 2 == 0);
    ///
    /// // We kunnen van nul tot tien keer herhalen.
    /// // Weten dat het er precies vijf zijn, zou niet mogelijk zijn zonder filter() uit te voeren.
    /// assert_eq!((0, Some(10)), iter.size_hint());
    ///
    /// // Laten we nog vijf getallen toevoegen met chain()
    /// let iter = (0..10).filter(|x| x % 2 == 0).chain(15..20);
    ///
    /// // nu worden beide grenzen met vijf verhoogd
    /// assert_eq!((5, Some(15)), iter.size_hint());
    /// ```
    ///
    /// `None` retourneren voor een bovengrens:
    ///
    /// ```
    /// // een oneindige iterator heeft geen bovengrens en de maximaal mogelijke ondergrens
    /////
    /// let iter = 0..;
    ///
    /// assert_eq!((usize::MAX, None), iter.size_hint());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }

    /// Gebruikt de iterator, telt het aantal iteraties en retourneert deze.
    ///
    /// Deze methode roept [`next`] herhaaldelijk aan totdat [`None`] wordt aangetroffen, en retourneert het aantal keren dat [`Some`] is gezien.
    /// Merk op dat [`next`] minstens één keer moet worden aangeroepen, zelfs als de iterator geen elementen heeft.
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Overloopgedrag
    ///
    /// De methode beschermt niet tegen overflows, dus het tellen van elementen van een iterator met meer dan [`usize::MAX`]-elementen levert ofwel het verkeerde resultaat op of panics.
    ///
    /// Als debug-beweringen zijn ingeschakeld, is een panic gegarandeerd.
    ///
    /// # Panics
    ///
    /// Deze functie kan panic zijn als de iterator meer dan [`usize::MAX`]-elementen heeft.
    ///
    /// # Examples
    ///
    /// Basisgebruik:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().count(), 3);
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().count(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn count(self) -> usize
    where
        Self: Sized,
    {
        self.fold(
            0,
            #[rustc_inherit_overflow_checks]
            |count, _| count + 1,
        )
    }

    /// Gebruikt de iterator en retourneert het laatste element.
    ///
    /// Deze methode evalueert de iterator totdat deze [`None`] retourneert.
    /// Terwijl het dit doet, houdt het het huidige element bij.
    /// Nadat [`None`] is geretourneerd, retourneert `last()` het laatste element dat het heeft gezien.
    ///
    /// # Examples
    ///
    /// Basisgebruik:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().last(), Some(&3));
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().last(), Some(&5));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn last(self) -> Option<Self::Item>
    where
        Self: Sized,
    {
        #[inline]
        fn some<T>(_: Option<T>, x: T) -> Option<T> {
            Some(x)
        }

        self.fold(None, some)
    }

    /// Gaat de iterator vooruit met `n`-elementen.
    ///
    /// Deze methode zal gretig `n`-elementen overslaan door [`next`] tot `n` keer aan te roepen totdat [`None`] wordt aangetroffen.
    ///
    /// `advance_by(n)` zal [`Ok(())`][Ok] retourneren als de iterator met succes door `n`-elementen gaat, of [`Err(k)`][Err] als [`None`] wordt aangetroffen, waarbij `k` het aantal elementen is waarmee de iterator wordt vooruitgeschoven voordat de elementen opraken (dwz
    /// de lengte van de iterator).
    /// Merk op dat `k` altijd kleiner is dan `n`.
    ///
    /// Het aanroepen van `advance_by(0)` verbruikt geen elementen en retourneert altijd [`Ok(())`][Ok].
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// Basisgebruik:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_by(2), Ok(()));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.advance_by(0), Ok(()));
    /// assert_eq!(iter.advance_by(100), Err(1)); // alleen `&4` werd overgeslagen
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next().ok_or(i)?;
        }
        Ok(())
    }

    /// Retourneert het `n`de element van de iterator.
    ///
    /// Zoals bij de meeste indexeringsbewerkingen, begint het tellen vanaf nul, dus `nth(0)` retourneert de eerste waarde, `nth(1)` de tweede, enzovoort.
    ///
    /// Merk op dat alle voorgaande elementen, evenals het geretourneerde element, zullen worden verbruikt uit de iterator.
    /// Dat betekent dat de voorgaande elementen worden weggegooid, en ook dat het meerdere keren aanroepen van `nth(0)` op dezelfde iterator verschillende elementen zal retourneren.
    ///
    ///
    /// `nth()` zal [`None`] teruggeven als `n` groter is dan of gelijk is aan de lengte van de iterator.
    ///
    /// # Examples
    ///
    /// Basisgebruik:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(1), Some(&2));
    /// ```
    ///
    /// Door `nth()` meerdere keren aan te roepen, wordt de iterator niet teruggespoeld:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth(1), Some(&2));
    /// assert_eq!(iter.nth(1), None);
    /// ```
    ///
    /// `None` retourneren als er minder dan `n + 1`-elementen zijn:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(10), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_by(n).ok()?;
        self.next()
    }

    /// Creëert een iterator die op hetzelfde punt begint, maar bij elke iteratie met het opgegeven aantal stappen.
    ///
    /// Opmerking 1: Het eerste element van de iterator wordt altijd geretourneerd, ongeacht de gegeven stap.
    ///
    /// Opmerking 2: het tijdstip waarop genegeerde elementen worden opgehaald, staat niet vast.
    /// `StepBy` gedraagt zich als de reeks `next(), nth(step-1), nth(step-1),…`, maar is ook vrij om zich te gedragen als de reeks
    ///
    /// `advance_n_and_return_first(step), advance_n_and_return_first(step), …`
    /// Welke manier wordt gebruikt, kan voor sommige iteratoren veranderen om prestatieredenen.
    /// De tweede manier zal de iterator eerder vooruit helpen en kan meer items verbruiken.
    ///
    /// `advance_n_and_return_first` is het equivalent van:
    ///
    /// ```
    /// fn advance_n_and_return_first<I>(iter: &mut I, total_step: usize) -> Option<I::Item>
    /// where
    ///     I: Iterator,
    /// {
    ///     let next = iter.next();
    ///     if total_step > 1 {
    ///         iter.nth(total_step-2);
    ///     }
    ///     next
    /// }
    /// ```
    ///
    /// # Panics
    ///
    /// De methode zal panic zijn als de gegeven stap `0` is.
    ///
    /// # Examples
    ///
    /// Basisgebruik:
    ///
    /// ```
    /// let a = [0, 1, 2, 3, 4, 5];
    /// let mut iter = a.iter().step_by(2);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_step_by", since = "1.28.0")]
    fn step_by(self, step: usize) -> StepBy<Self>
    where
        Self: Sized,
    {
        StepBy::new(self, step)
    }

    /// Neemt twee iteratoren en maakt een nieuwe iterator over beide in volgorde.
    ///
    /// `chain()` zal een nieuwe iterator retourneren die eerst de waarden van de eerste iterator zal herhalen en vervolgens de waarden van de tweede iterator.
    ///
    /// Met andere woorden, het verbindt twee iteratoren met elkaar in een ketting.🔗
    ///
    /// [`once`] wordt vaak gebruikt om een enkele waarde aan te passen aan een keten van andere soorten iteratie.
    ///
    /// # Examples
    ///
    /// Basisgebruik:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().chain(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Omdat het argument voor `chain()` [`IntoIterator`] gebruikt, kunnen we alles doorgeven dat kan worden omgezet in een [`Iterator`], niet alleen een [`Iterator`] zelf.
    /// Segmenten (`&[T]`) implementeren bijvoorbeeld [`IntoIterator`] en kunnen dus rechtstreeks aan `chain()` worden doorgegeven:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().chain(s2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Als u met de Windows API werkt, wilt u misschien [`OsStr`] naar `Vec<u16>` converteren:
    ///
    /// ```
    /// #[cfg(windows)]
    /// fn os_str_to_utf16(s: &std::ffi::OsStr) -> Vec<u16> {
    ///     use std::os::windows::ffi::OsStrExt;
    ///     s.encode_wide().chain(std::iter::once(0)).collect()
    /// }
    /// ```
    ///
    /// [`once`]: crate::iter::once
    /// [`OsStr`]: ../../std/ffi/struct.OsStr.html
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn chain<U>(self, other: U) -> Chain<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator<Item = Self::Item>,
    {
        Chain::new(self, other.into_iter())
    }

    /// 'Ritst' twee iterators op tot een enkele iterator van paren.
    ///
    /// `zip()` geeft een nieuwe iterator terug die zal itereren over twee andere iteratoren, waarbij een tupel wordt geretourneerd waarbij het eerste element uit de eerste iterator komt en het tweede element uit de tweede iterator.
    ///
    ///
    /// Met andere woorden, het ritst twee iterators samen tot één.
    ///
    /// Als een van de iteratoren [`None`] retourneert, retourneert [`next`] van de gezipte iterator [`None`].
    /// Als de eerste iterator [`None`] retourneert, zal `zip` kortsluiten en wordt `next` niet aangeroepen op de tweede iterator.
    ///
    /// # Examples
    ///
    /// Basisgebruik:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().zip(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Omdat het argument voor `zip()` [`IntoIterator`] gebruikt, kunnen we alles doorgeven dat kan worden omgezet in een [`Iterator`], niet alleen een [`Iterator`] zelf.
    /// Segmenten (`&[T]`) implementeren bijvoorbeeld [`IntoIterator`] en kunnen dus rechtstreeks aan `zip()` worden doorgegeven:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().zip(s2);
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `zip()` wordt vaak gebruikt om een oneindige iterator naar een eindige iterator te zippen.
    /// Dit werkt omdat de eindige iterator uiteindelijk [`None`] retourneert en de rits beëindigt.Zippen met `(0..)` kan veel op [`enumerate`] lijken:
    ///
    /// ```
    /// let enumerate: Vec<_> = "foo".chars().enumerate().collect();
    ///
    /// let zipper: Vec<_> = (0..).zip("foo".chars()).collect();
    ///
    /// assert_eq!((0, 'f'), enumerate[0]);
    /// assert_eq!((0, 'f'), zipper[0]);
    ///
    /// assert_eq!((1, 'o'), enumerate[1]);
    /// assert_eq!((1, 'o'), zipper[1]);
    ///
    /// assert_eq!((2, 'o'), enumerate[2]);
    /// assert_eq!((2, 'o'), zipper[2]);
    /// ```
    ///
    /// [`enumerate`]: Iterator::enumerate
    /// [`next`]: Iterator::next
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn zip<U>(self, other: U) -> Zip<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator,
    {
        Zip::new(self, other.into_iter())
    }

    /// Creëert een nieuwe iterator die een kopie van `separator` plaatst tussen aangrenzende items van de originele iterator.
    ///
    /// Als `separator` [`Clone`] niet implementeert of elke keer moet worden berekend, gebruik dan [`intersperse_with`].
    ///
    ///
    /// # Examples
    ///
    /// Basisgebruik:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let mut a = [0, 1, 2].iter().intersperse(&100);
    /// assert_eq!(a.next(), Some(&0));   // Het eerste element van `a`.
    /// assert_eq!(a.next(), Some(&100)); // De afscheider.
    /// assert_eq!(a.next(), Some(&1));   // Het volgende element van `a`.
    /// assert_eq!(a.next(), Some(&100)); // De afscheider.
    /// assert_eq!(a.next(), Some(&2));   // Het laatste element van `a`.
    /// assert_eq!(a.next(), None);       // De iterator is voltooid.
    /// ```
    ///
    /// `intersperse` kan erg handig zijn om items van een iterator samen te voegen met een gemeenschappelijk element:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let hello = ["Hello", "World", "!"].iter().copied().intersperse(" ").collect::<String>();
    /// assert_eq!(hello, "Hello World !");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse_with`]: Iterator::intersperse_with
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse(self, separator: Self::Item) -> Intersperse<Self>
    where
        Self: Sized,
        Self::Item: Clone,
    {
        Intersperse::new(self, separator)
    }

    /// Maakt een nieuwe iterator die een item dat door `separator` is gegenereerd, tussen aangrenzende items van de oorspronkelijke iterator plaatst.
    ///
    /// De sluiting wordt elke keer dat een item tussen twee aangrenzende items uit de onderliggende iterator wordt geplaatst, exact één keer aangeroepen;
    /// in het bijzonder wordt de sluiting niet aangeroepen als de onderliggende iterator minder dan twee items oplevert en nadat het laatste item is opgeleverd.
    ///
    ///
    /// Als het item van de iterator [`Clone`] implementeert, kan het gemakkelijker zijn om [`intersperse`] te gebruiken.
    ///
    /// # Examples
    ///
    /// Basisgebruik:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// #[derive(PartialEq, Debug)]
    /// struct NotClone(usize);
    ///
    /// let v = vec![NotClone(0), NotClone(1), NotClone(2)];
    /// let mut it = v.into_iter().intersperse_with(|| NotClone(99));
    ///
    /// assert_eq!(it.next(), Some(NotClone(0)));  // Het eerste element van `v`.
    /// assert_eq!(it.next(), Some(NotClone(99))); // De afscheider.
    /// assert_eq!(it.next(), Some(NotClone(1)));  // Het volgende element van `v`.
    /// assert_eq!(it.next(), Some(NotClone(99))); // De afscheider.
    /// assert_eq!(it.next(), Some(NotClone(2)));  // Het laatste element van `v`.
    /// assert_eq!(it.next(), None);               // De iterator is voltooid.
    /// ```
    ///
    /// `intersperse_with` kan worden gebruikt in situaties waarin het scheidingsteken moet worden berekend:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let src = ["Hello", "to", "all", "people", "!!"].iter().copied();
    ///
    /// // De sluiting ontleent op veranderlijke wijze zijn context om een item te genereren.
    /// let mut happy_emojis = [" ❤️ ", " 😀 "].iter().copied();
    /// let separator = || happy_emojis.next().unwrap_or(" 🦀 ");
    ///
    /// let result = src.intersperse_with(separator).collect::<String>();
    /// assert_eq!(result, "Hello ❤️ to 😀 all 🦀 people 🦀 !!");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse`]: Iterator::intersperse
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse_with<G>(self, separator: G) -> IntersperseWith<Self, G>
    where
        Self: Sized,
        G: FnMut() -> Self::Item,
    {
        IntersperseWith::new(self, separator)
    }

    /// Neemt een afsluiting en creëert een iterator die die afsluiting op elk element oproept.
    ///
    /// `map()` transformeert de ene iterator in de andere, door middel van zijn argument:
    /// iets dat [`FnMut`] implementeert.Het produceert een nieuwe iterator die deze afsluiting op elk element van de oorspronkelijke iterator noemt.
    ///
    /// Als je goed bent in typen, kun je `map()` als volgt zien:
    /// Als je een iterator hebt die je elementen van een bepaald type `A` geeft, en je wilt een iterator van een ander type `B`, dan kun je `map()` gebruiken, een afsluiting doorgeven die een `A` nodig heeft en een `B` retourneert.
    ///
    ///
    /// `map()` is conceptueel vergelijkbaar met een [`for`]-lus.Omdat `map()` echter lui is, kan deze het beste worden gebruikt wanneer u al met andere iterators werkt.
    /// Als je een soort looping uitvoert voor een bijwerking, wordt het als idiomatischer beschouwd om [`for`] dan `map()` te gebruiken.
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    /// [`FnMut`]: crate::ops::FnMut
    ///
    /// # Examples
    ///
    /// Basisgebruik:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().map(|x| 2 * x);
    ///
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), Some(6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Als je een bijwerking hebt, geef dan de voorkeur aan [`for`] boven `map()`:
    ///
    /// ```
    /// # #![allow(unused_must_use)]
    /// // doe dit niet:
    /// (0..5).map(|x| println!("{}", x));
    ///
    /// // het zal niet eens worden uitgevoerd, omdat het lui is.Rust zal u hiervoor waarschuwen.
    ///
    /// // Gebruik in plaats daarvan voor:
    /// for x in 0..5 {
    ///     println!("{}", x);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn map<B, F>(self, f: F) -> Map<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> B,
    {
        Map::new(self, f)
    }

    /// Roept een afsluiting op voor elk element van een iterator.
    ///
    /// Dit komt overeen met het gebruik van een [`for`]-lus op de iterator, hoewel `break` en `continue` niet mogelijk zijn vanaf een sluiting.
    /// Het is over het algemeen idiomatischer om een `for`-lus te gebruiken, maar `for_each` is mogelijk beter leesbaar bij het verwerken van items aan het einde van langere iteratorketens.
    ///
    /// In sommige gevallen kan `for_each` ook sneller zijn dan een lus, omdat het interne iteratie zal gebruiken op adapters zoals `Chain`.
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// # Examples
    ///
    /// Basisgebruik:
    ///
    /// ```
    /// use std::sync::mpsc::channel;
    ///
    /// let (tx, rx) = channel();
    /// (0..5).map(|x| x * 2 + 1)
    ///       .for_each(move |x| tx.send(x).unwrap());
    ///
    /// let v: Vec<_> =  rx.iter().collect();
    /// assert_eq!(v, vec![1, 3, 5, 7, 9]);
    /// ```
    ///
    /// Voor zo'n klein voorbeeld is een `for`-lus misschien schoner, maar `for_each` heeft misschien de voorkeur om een functionele stijl te behouden met langere iterators:
    ///
    /// ```
    /// (0..5).flat_map(|x| x * 100 .. x * 110)
    ///       .enumerate()
    ///       .filter(|&(i, x)| (i + x) % 3 == 0)
    ///       .for_each(|(i, x)| println!("{}:{}", i, x));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_for_each", since = "1.21.0")]
    fn for_each<F>(self, f: F)
    where
        Self: Sized,
        F: FnMut(Self::Item),
    {
        #[inline]
        fn call<T>(mut f: impl FnMut(T)) -> impl FnMut((), T) {
            move |(), item| f(item)
        }

        self.fold((), call(f));
    }

    /// Creëert een iterator die een afsluiting gebruikt om te bepalen of een element moet worden opgeleverd.
    ///
    /// Gegeven een element moet de sluiting `true` of `false` retourneren.De geretourneerde iterator levert alleen de elementen op waarvoor de sluiting true retourneert.
    ///
    /// # Examples
    ///
    /// Basisgebruik:
    ///
    /// ```
    /// let a = [0i32, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| x.is_positive());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Omdat de afsluiting die is doorgegeven aan `filter()` een referentie aanneemt, en veel iteratoren de referenties herhalen, leidt dit tot een mogelijk verwarrende situatie, waarbij het type afsluiting een dubbele referentie is:
    ///
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| **x > 1); // twee * s nodig!
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Het is gebruikelijk om in plaats daarvan destructurering op het argument te gebruiken om er een weg te halen:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&x| *x > 1); // Beiden en *
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// of allebei:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&&x| x > 1); // twee &s
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// van deze lagen.
    ///
    /// Merk op dat `iter.filter(f).next()` gelijk is aan `iter.find(f)`.
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter<P>(self, predicate: P) -> Filter<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        Filter::new(self, predicate)
    }

    /// Creëert een iterator die zowel filtert als in kaart brengt.
    ///
    /// De geretourneerde iterator levert alleen de `waarde`s op waarvoor de geleverde afsluiting `Some(value)` retourneert.
    ///
    /// `filter_map` kan worden gebruikt om ketens van [`filter`] en [`map`] beknopter te maken.
    /// Het onderstaande voorbeeld laat zien hoe een `map().filter().map()` kan worden ingekort tot een enkele aanroep naar `filter_map`.
    ///
    ///
    /// [`filter`]: Iterator::filter
    /// [`map`]: Iterator::map
    ///
    /// # Examples
    ///
    /// Basisgebruik:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    ///
    /// let mut iter = a.iter().filter_map(|s| s.parse().ok());
    ///
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Hier is hetzelfde voorbeeld, maar met [`filter`] en [`map`]:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    /// let mut iter = a.iter().map(|s| s.parse()).filter(|s| s.is_ok()).map(|s| s.unwrap());
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter_map<B, F>(self, f: F) -> FilterMap<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        FilterMap::new(self, f)
    }

    /// Creëert een iterator die zowel het huidige aantal iteraties als de volgende waarde geeft.
    ///
    /// De geretourneerde iterator levert paren `(i, val)` op, waarbij `i` de huidige iteratie-index is en `val` de waarde die door de iterator wordt geretourneerd.
    ///
    ///
    /// `enumerate()` houdt zijn telling als een [`usize`].
    /// Als u wilt tellen met een geheel getal met een andere grootte, biedt de [`zip`]-functie vergelijkbare functionaliteit.
    ///
    /// # Overloopgedrag
    ///
    /// De methode beschermt niet tegen overlopen, dus het opsommen van meer dan [`usize::MAX`]-elementen levert ofwel het verkeerde resultaat op of panics.
    /// Als debug-beweringen zijn ingeschakeld, is een panic gegarandeerd.
    ///
    /// # Panics
    ///
    /// De geretourneerde iterator zou panic kunnen zijn als de te retourneren index een [`usize`] zou overstromen.
    ///
    /// [`usize`]: type@usize
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ['a', 'b', 'c'];
    ///
    /// let mut iter = a.iter().enumerate();
    ///
    /// assert_eq!(iter.next(), Some((0, &'a')));
    /// assert_eq!(iter.next(), Some((1, &'b')));
    /// assert_eq!(iter.next(), Some((2, &'c')));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn enumerate(self) -> Enumerate<Self>
    where
        Self: Sized,
    {
        Enumerate::new(self)
    }

    /// Creëert een iterator die [`peek`] kan gebruiken om naar het volgende element van de iterator te kijken zonder het te verbruiken.
    ///
    /// Voegt een [`peek`]-methode toe aan een iterator.Zie de documentatie voor meer informatie.
    ///
    /// Merk op dat de onderliggende iterator nog steeds geavanceerd is wanneer [`peek`] voor de eerste keer wordt aangeroepen: om het volgende element op te halen, wordt [`next`] aangeroepen op de onderliggende iterator, vandaar eventuele bijwerkingen (bijv.
    ///
    /// iets anders dan het ophalen van de volgende waarde) van de [`next`]-methode zal plaatsvinden.
    ///
    /// [`peek`]: Peekable::peek
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// Basisgebruik:
    ///
    /// ```
    /// let xs = [1, 2, 3];
    ///
    /// let mut iter = xs.iter().peekable();
    ///
    /// // peek() laat ons kijken in de future
    /// assert_eq!(iter.peek(), Some(&&1));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), Some(&2));
    ///
    /// // we kunnen peek() meerdere keren gebruiken, de iterator gaat niet verder
    /// assert_eq!(iter.peek(), Some(&&3));
    /// assert_eq!(iter.peek(), Some(&&3));
    ///
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // nadat de iterator is voltooid, is peek() dat ook
    /// assert_eq!(iter.peek(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn peekable(self) -> Peekable<Self>
    where
        Self: Sized,
    {
        Peekable::new(self)
    }

    /// Creëert een iterator die de elementen ['overslaat'] op basis van een predikaat.
    ///
    /// [`skip`]: Iterator::skip
    ///
    /// `skip_while()` neemt een afsluiting als argument.Het roept deze sluiting op voor elk element van de iterator en negeert elementen totdat het `false` retourneert.
    ///
    /// Nadat `false` is geretourneerd, is de `skip_while()`'s-taak voorbij en worden de rest van de elementen opgeleverd.
    ///
    /// # Examples
    ///
    /// Basisgebruik:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Omdat de afsluiting die aan `skip_while()` is doorgegeven een referentie aanneemt, en veel iteratoren de referenties herhalen, leidt dit tot een mogelijk verwarrende situatie, waarbij het type van het afsluitingsargument een dubbele referentie is:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0); // twee * s nodig!
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Stoppen na een eerste `false`:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// // terwijl dit false zou zijn geweest, aangezien we al een false hebben, wordt skip_while() niet meer gebruikt
    /////
    /// assert_eq!(iter.next(), Some(&-2));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip_while<P>(self, predicate: P) -> SkipWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        SkipWhile::new(self, predicate)
    }

    /// Creëert een iterator die elementen oplevert op basis van een predikaat.
    ///
    /// `take_while()` neemt een afsluiting als argument.Het zal deze sluiting op elk element van de iterator aanroepen, en elementen opleveren terwijl het `true` retourneert.
    ///
    /// Nadat `false` is geretourneerd, is de `take_while()`'s-taak voorbij en worden de rest van de elementen genegeerd.
    ///
    /// # Examples
    ///
    /// Basisgebruik:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Omdat de afsluiting die is doorgegeven aan `take_while()` een referentie aanneemt, en veel iteratoren de referenties herhalen, leidt dit tot een mogelijk verwarrende situatie, waarbij het type afsluiting een dubbele referentie is:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0); // twee * s nodig!
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Stoppen na een eerste `false`:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    ///
    /// // We hebben meer elementen die kleiner zijn dan nul, maar aangezien we al een false hebben, wordt take_while() niet meer gebruikt
    /////
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Omdat `take_while()` naar de waarde moet kijken om te zien of deze moet worden opgenomen of niet, zullen consumerende iterators zien dat deze wordt verwijderd:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<i32> = iter.by_ref()
    ///                            .take_while(|n| **n != 3)
    ///                            .cloned()
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// De `3` is er niet meer, omdat hij werd verbruikt om te zien of de iteratie zou moeten stoppen, maar hij werd niet teruggeplaatst in de iterator.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take_while<P>(self, predicate: P) -> TakeWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        TakeWhile::new(self, predicate)
    }

    /// Creëert een iterator die zowel elementen oplevert op basis van een predikaat als kaarten.
    ///
    /// `map_while()` neemt een afsluiting als argument.
    /// Het zal deze sluiting op elk element van de iterator aanroepen, en elementen opleveren terwijl het [`Some(_)`][`Some`] retourneert.
    ///
    /// # Examples
    ///
    /// Basisgebruik:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter().map_while(|x| 16i32.checked_div(*x));
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Hier is hetzelfde voorbeeld, maar met [`take_while`] en [`map`]:
    ///
    /// [`take_while`]: Iterator::take_while
    /// [`map`]: Iterator::map
    ///
    /// ```
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter()
    ///                 .map(|x| 16i32.checked_div(*x))
    ///                 .take_while(|x| x.is_some())
    ///                 .map(|x| x.unwrap());
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Stoppen na een eerste [`None`]:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [0, 1, 2, -3, 4, 5, -6];
    ///
    /// let iter = a.iter().map_while(|x| u32::try_from(*x).ok());
    /// let vec = iter.collect::<Vec<_>>();
    ///
    /// // We hebben meer elementen die in u32 (4, 5) zouden kunnen passen, maar `map_while` retourneerde `None` voor `-3` (aangezien de `predicate` `None` retourneerde) en `collect` stopt bij de eerste `None` die werd aangetroffen.
    /////
    /// assert_eq!(vec, vec![0, 1, 2]);
    /// ```
    ///
    /// Omdat `map_while()` naar de waarde moet kijken om te zien of deze moet worden opgenomen of niet, zullen consumerende iterators zien dat deze wordt verwijderd:
    ///
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [1, 2, -3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<u32> = iter.by_ref()
    ///                            .map_while(|n| u32::try_from(*n).ok())
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// De `-3` is er niet meer, omdat hij werd verbruikt om te zien of de iteratie zou moeten stoppen, maar hij werd niet teruggeplaatst in de iterator.
    ///
    /// Merk op dat in tegenstelling tot [`take_while`] deze iterator **niet** gefuseerd is.
    /// Het is ook niet gespecificeerd wat deze iterator retourneert nadat de eerste [`None`] is geretourneerd.
    /// Als je gefuseerde iterator nodig hebt, gebruik dan [`fuse`].
    ///
    /// [`fuse`]: Iterator::fuse
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
    fn map_while<B, P>(self, predicate: P) -> MapWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> Option<B>,
    {
        MapWhile::new(self, predicate)
    }

    /// Creëert een iterator die de eerste `n`-elementen overslaat.
    ///
    /// Nadat ze zijn geconsumeerd, worden de rest van de elementen meegegeven.
    /// In plaats van deze methode rechtstreeks te overschrijven, overschrijft u in plaats daarvan de `nth`-methode.
    ///
    /// # Examples
    ///
    /// Basisgebruik:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().skip(2);
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip(self, n: usize) -> Skip<Self>
    where
        Self: Sized,
    {
        Skip::new(self, n)
    }

    /// Creëert een iterator die de eerste `n`-elementen oplevert.
    ///
    /// # Examples
    ///
    /// Basisgebruik:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().take(2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `take()` wordt vaak gebruikt met een oneindige iterator, om het eindig te maken:
    ///
    /// ```
    /// let mut iter = (0..).take(3);
    ///
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Als er minder dan `n`-elementen beschikbaar zijn, beperkt `take` zich tot de grootte van de onderliggende iterator:
    ///
    ///
    /// ```
    /// let v = vec![1, 2];
    /// let mut iter = v.into_iter().take(5);
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take(self, n: usize) -> Take<Self>
    where
        Self: Sized,
    {
        Take::new(self, n)
    }

    /// Een iteratoradapter vergelijkbaar met [`fold`] die de interne status vasthoudt en een nieuwe iterator produceert.
    ///
    /// [`fold`]: Iterator::fold
    ///
    /// `scan()` heeft twee argumenten: een initiële waarde die de interne toestand kiemt, en een afsluiting met twee argumenten, de eerste is een veranderlijke verwijzing naar de interne toestand en het tweede een iteratorelement.
    ///
    /// De sluiting kan worden toegewezen aan de interne status om de status tussen iteraties te delen.
    ///
    /// Bij iteratie wordt de afsluiting toegepast op elk element van de iterator en wordt de retourwaarde van de afsluiting, een [`Option`], door de iterator verkregen.
    ///
    /// # Examples
    ///
    /// Basisgebruik:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().scan(1, |state, &x| {
    ///     // bij elke iteratie vermenigvuldigen we de toestand met het element
    ///     *state = *state * x;
    ///
    ///     // dan geven we de ontkenning van de staat
    ///     Some(-*state)
    /// });
    ///
    /// assert_eq!(iter.next(), Some(-1));
    /// assert_eq!(iter.next(), Some(-2));
    /// assert_eq!(iter.next(), Some(-6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn scan<St, B, F>(self, initial_state: St, f: F) -> Scan<Self, St, F>
    where
        Self: Sized,
        F: FnMut(&mut St, Self::Item) -> Option<B>,
    {
        Scan::new(self, initial_state, f)
    }

    /// Creëert een iterator die werkt als een kaart, maar de geneste structuur vlakker maakt.
    ///
    /// De [`map`]-adapter is erg handig, maar alleen als het sluitingsargument waarden oplevert.
    /// Als het in plaats daarvan een iterator produceert, is er een extra indirecte laag.
    /// `flat_map()` verwijdert deze extra laag vanzelf.
    ///
    /// U kunt `flat_map(f)` beschouwen als het semantische equivalent van [`map`] ping, en vervolgens [`flatten`] ing zoals in `map(f).flatten()`.
    ///
    /// Een andere manier om over `flat_map()` te denken: de sluiting van [`map`] geeft één item voor elk element terug, en `flat_map()`'s sluiting geeft een iterator voor elk element terug.
    ///
    ///
    /// [`map`]: Iterator::map
    /// [`flatten`]: Iterator::flatten
    ///
    /// # Examples
    ///
    /// Basisgebruik:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() geeft een iterator terug
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn flat_map<U, F>(self, f: F) -> FlatMap<Self, U, F>
    where
        Self: Sized,
        U: IntoIterator,
        F: FnMut(Self::Item) -> U,
    {
        FlatMap::new(self, f)
    }

    /// Creëert een iterator die geneste structuur vlakker maakt.
    ///
    /// Dit is handig als u een iterator van iteratoren heeft of een iterator van dingen die in iteratoren kunnen worden omgezet en u één niveau van indirectheid wilt verwijderen.
    ///
    ///
    /// # Examples
    ///
    /// Basisgebruik:
    ///
    /// ```
    /// let data = vec![vec![1, 2, 3, 4], vec![5, 6]];
    /// let flattened = data.into_iter().flatten().collect::<Vec<u8>>();
    /// assert_eq!(flattened, &[1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    /// In kaart brengen en vervolgens afvlakken:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() geeft een iterator terug
    /// let merged: String = words.iter()
    ///                           .map(|s| s.chars())
    ///                           .flatten()
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// U kunt dit ook herschrijven in termen van [`flat_map()`], wat in dit geval de voorkeur heeft omdat het de bedoeling duidelijker overbrengt:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() geeft een iterator terug
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// Bij afvlakken wordt slechts één nestniveau tegelijk verwijderd:
    ///
    /// ```
    /// let d3 = [[[1, 2], [3, 4]], [[5, 6], [7, 8]]];
    ///
    /// let d2 = d3.iter().flatten().collect::<Vec<_>>();
    /// assert_eq!(d2, [&[1, 2], &[3, 4], &[5, 6], &[7, 8]]);
    ///
    /// let d1 = d3.iter().flatten().flatten().collect::<Vec<_>>();
    /// assert_eq!(d1, [&1, &2, &3, &4, &5, &6, &7, &8]);
    /// ```
    ///
    /// Hier zien we dat `flatten()` geen "deep"-afvlakking uitvoert.
    /// In plaats daarvan wordt slechts één nestniveau verwijderd.Dat wil zeggen, als u `flatten()` een driedimensionale array gebruikt, is het resultaat tweedimensionaal en niet eendimensionaal.
    /// Om een eendimensionale structuur te krijgen, moet je opnieuw `flatten()` gebruiken.
    ///
    /// [`flat_map()`]: Iterator::flat_map
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_flatten", since = "1.29.0")]
    fn flatten(self) -> Flatten<Self>
    where
        Self: Sized,
        Self::Item: IntoIterator,
    {
        Flatten::new(self)
    }

    /// Creëert een iterator die eindigt na de eerste [`None`].
    ///
    /// Nadat een iterator [`None`] heeft geretourneerd, kunnen future-aanroepen [`Some(T)`] wel of niet opnieuw opleveren.
    /// `fuse()` past een iterator aan en zorgt ervoor dat nadat een [`None`] is gegeven, deze altijd [`None`] voor altijd zal retourneren.
    ///
    ///
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// Basisgebruik:
    ///
    /// ```
    /// // een iterator die afwisselt tussen Some en None
    /// struct Alternate {
    ///     state: i32,
    /// }
    ///
    /// impl Iterator for Alternate {
    ///     type Item = i32;
    ///
    ///     fn next(&mut self) -> Option<i32> {
    ///         let val = self.state;
    ///         self.state = self.state + 1;
    ///
    ///         // als het even is, Some(i32), anders None
    ///         if val % 2 == 0 {
    ///             Some(val)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    ///
    /// let mut iter = Alternate { state: 0 };
    ///
    /// // we kunnen onze iterator heen en weer zien gaan
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    ///
    /// // echter, zodra we het fuseren ...
    /// let mut iter = iter.fuse();
    ///
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    ///
    /// // het zal altijd `None` retourneren na de eerste keer.
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fuse(self) -> Fuse<Self>
    where
        Self: Sized,
    {
        Fuse::new(self)
    }

    /// Doet iets met elk element van een iterator en geeft de waarde door.
    ///
    /// Wanneer u iterators gebruikt, zult u er vaak meerdere aan elkaar koppelen.
    /// Terwijl u aan dergelijke code werkt, wilt u misschien kijken wat er op verschillende delen in de pijplijn gebeurt.Om dat te doen, voegt u een oproep naar `inspect()` in.
    ///
    /// Het komt vaker voor dat `inspect()` wordt gebruikt als een foutopsporingsprogramma dan dat het voorkomt in uw uiteindelijke code, maar toepassingen kunnen het nuttig vinden in bepaalde situaties waarin fouten moeten worden gelogd voordat ze worden verwijderd.
    ///
    ///
    /// # Examples
    ///
    /// Basisgebruik:
    ///
    /// ```
    /// let a = [1, 4, 2, 3];
    ///
    /// // deze iteratorsequentie is complex.
    /// let sum = a.iter()
    ///     .cloned()
    ///     .filter(|x| x % 2 == 0)
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    ///
    /// // laten we enkele inspect()-oproepen toevoegen om te onderzoeken wat er gebeurt
    /// let sum = a.iter()
    ///     .cloned()
    ///     .inspect(|x| println!("about to filter: {}", x))
    ///     .filter(|x| x % 2 == 0)
    ///     .inspect(|x| println!("made it through filter: {}", x))
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    /// ```
    ///
    /// Dit zal afdrukken:
    ///
    /// ```text
    /// 6
    /// about to filter: 1
    /// about to filter: 4
    /// made it through filter: 4
    /// about to filter: 2
    /// made it through filter: 2
    /// about to filter: 3
    /// 6
    /// ```
    ///
    /// Logboekfouten voordat u ze weggooit:
    ///
    /// ```
    /// let lines = ["1", "2", "a"];
    ///
    /// let sum: i32 = lines
    ///     .iter()
    ///     .map(|line| line.parse::<i32>())
    ///     .inspect(|num| {
    ///         if let Err(ref e) = *num {
    ///             println!("Parsing error: {}", e);
    ///         }
    ///     })
    ///     .filter_map(Result::ok)
    ///     .sum();
    ///
    /// println!("Sum: {}", sum);
    /// ```
    ///
    /// Dit zal afdrukken:
    ///
    /// ```text
    /// Parsing error: invalid digit found in string
    /// Sum: 3
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn inspect<F>(self, f: F) -> Inspect<Self, F>
    where
        Self: Sized,
        F: FnMut(&Self::Item),
    {
        Inspect::new(self, f)
    }

    /// Leent een iterator in plaats van deze te consumeren.
    ///
    /// Dit is handig om iteratoradapters toe te staan terwijl u het eigendom van de originele iterator behoudt.
    ///
    ///
    /// # Examples
    ///
    /// Basisgebruik:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let iter = a.iter();
    ///
    /// let sum: i32 = iter.take(5).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 6);
    ///
    /// // als we iter opnieuw proberen te gebruiken, zal het niet werken.
    /// // De volgende regel geeft "fout: gebruik van verplaatste waarde: `iter`
    /// // assert_eq!(iter.next(), None);
    ///
    /// // laten we dat nog eens proberen
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // in plaats daarvan voegen we een .by_ref() toe
    /// let sum: i32 = iter.by_ref().take(2).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 3);
    ///
    /// // nu is dit prima:
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn by_ref(&mut self) -> &mut Self
    where
        Self: Sized,
    {
        self
    }

    /// Transformeert een iterator in een verzameling.
    ///
    /// `collect()` kan alles nemen wat iterabel is en er een relevante verzameling van maken.
    /// Dit is een van de krachtigere methoden in de standaardbibliotheek, die in verschillende contexten wordt gebruikt.
    ///
    /// Het meest basale patroon waarin `collect()` wordt gebruikt, is om de ene collectie in een andere te veranderen.
    /// Je neemt een verzameling, belt er [`iter`] op, voert een aantal transformaties uit en aan het einde `collect()`.
    ///
    /// `collect()` kan ook instanties van typen maken die geen typische verzamelingen zijn.
    /// Een [`String`] kan bijvoorbeeld worden opgebouwd uit [`char`] s, en een iterator van [`Result<T, E>`][`Result`]-items kan worden verzameld in `Result<Collection<T>, E>`.
    ///
    /// Zie onderstaande voorbeelden voor meer.
    ///
    /// Omdat `collect()` zo algemeen is, kan het problemen veroorzaken met type-inferentie.
    /// Als zodanig is `collect()` een van de weinige keren dat je de syntaxis ziet die liefkozend bekend staat als de 'turbofish': `::<>`.
    /// Dit helpt het inferentie-algoritme specifiek te begrijpen in welke verzameling u probeert te verzamelen.
    ///
    /// # Examples
    ///
    /// Basisgebruik:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled: Vec<i32> = a.iter()
    ///                          .map(|&x| x * 2)
    ///                          .collect();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Merk op dat we de `: Vec<i32>` aan de linkerkant nodig hadden.Dit komt omdat we in plaats daarvan bijvoorbeeld in een [`VecDeque<T>`] kunnen verzamelen:
    ///
    /// [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let a = [1, 2, 3];
    ///
    /// let doubled: VecDeque<i32> = a.iter().map(|&x| x * 2).collect();
    ///
    /// assert_eq!(2, doubled[0]);
    /// assert_eq!(4, doubled[1]);
    /// assert_eq!(6, doubled[2]);
    /// ```
    ///
    /// De 'turbofish' gebruiken in plaats van `doubled` te annoteren:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<i32>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Omdat `collect()` alleen geeft om wat je verzamelt, kun je nog steeds een gedeeltelijke type-hint, `_`, gebruiken met de turbofish:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<_>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// `collect()` gebruiken om een [`String`] te maken:
    ///
    /// ```
    /// let chars = ['g', 'd', 'k', 'k', 'n'];
    ///
    /// let hello: String = chars.iter()
    ///     .map(|&x| x as u8)
    ///     .map(|x| (x + 1) as char)
    ///     .collect();
    ///
    /// assert_eq!("hello", hello);
    /// ```
    ///
    /// Als je een lijst hebt met [`Resultaat<T, E>`][`Resultaat`] s, u kunt `collect()` gebruiken om te zien of een van deze mislukt:
    ///
    /// ```
    /// let results = [Ok(1), Err("nope"), Ok(3), Err("bad")];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // geeft ons de eerste fout
    /// assert_eq!(Err("nope"), result);
    ///
    /// let results = [Ok(1), Ok(3)];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // geeft ons de lijst met antwoorden
    /// assert_eq!(Ok(vec![1, 3]), result);
    /// ```
    ///
    /// [`iter`]: Iterator::next
    /// [`String`]: ../../std/string/struct.String.html
    /// [`char`]: type@char
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "if you really need to exhaust the iterator, consider `.for_each(drop)` instead"]
    fn collect<B: FromIterator<Self::Item>>(self) -> B
    where
        Self: Sized,
    {
        FromIterator::from_iter(self)
    }

    /// Gebruikt een iterator en maakt er twee verzamelingen van.
    ///
    /// Het predikaat dat aan `partition()` is doorgegeven, kan `true` of `false` retourneren.
    /// `partition()` geeft een paar terug, alle elementen waarvoor het `true` heeft geretourneerd, en alle elementen waarvoor het `false` heeft geretourneerd.
    ///
    ///
    /// Zie ook [`is_partitioned()`] en [`partition_in_place()`].
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// Basisgebruik:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let (even, odd): (Vec<i32>, Vec<i32>) = a
    ///     .iter()
    ///     .partition(|&n| n % 2 == 0);
    ///
    /// assert_eq!(even, vec![2]);
    /// assert_eq!(odd, vec![1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn partition<B, F>(self, f: F) -> (B, B)
    where
        Self: Sized,
        B: Default + Extend<Self::Item>,
        F: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn extend<'a, T, B: Extend<T>>(
            mut f: impl FnMut(&T) -> bool + 'a,
            left: &'a mut B,
            right: &'a mut B,
        ) -> impl FnMut((), T) + 'a {
            move |(), x| {
                if f(&x) {
                    left.extend_one(x);
                } else {
                    right.extend_one(x);
                }
            }
        }

        let mut left: B = Default::default();
        let mut right: B = Default::default();

        self.fold((), extend(f, &mut left, &mut right));

        (left, right)
    }

    /// Herschikt de elementen van deze iterator *op zijn plaats* volgens het gegeven predikaat, zodat alle elementen die `true` retourneren, voorafgaan aan alle elementen die `false` retourneren.
    ///
    /// Retourneert het aantal gevonden `true`-elementen.
    ///
    /// De relatieve volgorde van gepartitioneerde items wordt niet behouden.
    ///
    /// Zie ook [`is_partitioned()`] en [`partition()`].
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition()`]: Iterator::partition
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_partition_in_place)]
    ///
    /// let mut a = [1, 2, 3, 4, 5, 6, 7];
    ///
    /// // Partition op zijn plaats tussen evens en odds
    /// let i = a.iter_mut().partition_in_place(|&n| n % 2 == 0);
    ///
    /// assert_eq!(i, 3);
    /// assert!(a[..i].iter().all(|&n| n % 2 == 0)); // evens
    /// assert!(a[i..].iter().all(|&n| n % 2 == 1)); // odds
    /// ```
    #[unstable(feature = "iter_partition_in_place", reason = "new API", issue = "62543")]
    fn partition_in_place<'a, T: 'a, P>(mut self, ref mut predicate: P) -> usize
    where
        Self: Sized + DoubleEndedIterator<Item = &'a mut T>,
        P: FnMut(&T) -> bool,
    {
        // FIXME: moeten we ons zorgen maken over het overlopen van de telling?De enige manier om meer te hebben dan
        // `usize::MAX` veranderlijke verwijzingen zijn met ZST's, die niet handig zijn om te partitioneren ...

        // Deze "factory"-sluitfuncties bestaan om genericiteit in `Self` te voorkomen.

        #[inline]
        fn is_false<'a, T>(
            predicate: &'a mut impl FnMut(&T) -> bool,
            true_count: &'a mut usize,
        ) -> impl FnMut(&&mut T) -> bool + 'a {
            move |x| {
                let p = predicate(&**x);
                *true_count += p as usize;
                !p
            }
        }

        #[inline]
        fn is_true<T>(predicate: &mut impl FnMut(&T) -> bool) -> impl FnMut(&&mut T) -> bool + '_ {
            move |x| predicate(&**x)
        }

        // Zoek herhaaldelijk de eerste `false` en verwissel deze met de laatste `true`.
        let mut true_count = 0;
        while let Some(head) = self.find(is_false(predicate, &mut true_count)) {
            if let Some(tail) = self.rfind(is_true(predicate)) {
                crate::mem::swap(head, tail);
                true_count += 1;
            } else {
                break;
            }
        }
        true_count
    }

    /// Controleert of de elementen van deze iterator zijn gepartitioneerd volgens het opgegeven predikaat, zodat alle elementen die `true` retourneren, voorafgaan aan alle elementen die `false` retourneren.
    ///
    ///
    /// Zie ook [`partition()`] en [`partition_in_place()`].
    ///
    /// [`partition()`]: Iterator::partition
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_is_partitioned)]
    ///
    /// assert!("Iterator".chars().is_partitioned(char::is_uppercase));
    /// assert!(!"IntoIterator".chars().is_partitioned(char::is_uppercase));
    /// ```
    #[unstable(feature = "iter_is_partitioned", reason = "new API", issue = "62544")]
    fn is_partitioned<P>(mut self, mut predicate: P) -> bool
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        // Ofwel testen alle items `true`, of de eerste clausule stopt bij `false` en we controleren of er daarna geen `true`-items meer zijn.
        //
        self.all(&mut predicate) || !self.any(predicate)
    }

    /// Een iteratormethode die een functie toepast zolang deze met succes terugkeert, waarbij een enkele, definitieve waarde wordt geproduceerd.
    ///
    /// `try_fold()` heeft twee argumenten: een beginwaarde en een afsluiting met twee argumenten: een 'accumulator' en een element.
    /// De sluiting keert ofwel met succes terug, met de waarde die de accumulator zou moeten hebben voor de volgende iteratie, of het retourneert een mislukking, met een foutwaarde die onmiddellijk (short-circuiting) wordt doorgegeven aan de beller.
    ///
    ///
    /// De beginwaarde is de waarde die de accumulator zal hebben bij de eerste oproep.Als het toepassen van de sluiting is geslaagd voor elk element van de iterator, retourneert `try_fold()` de laatste accumulator als geslaagd.
    ///
    /// Vouwen is handig wanneer u een verzameling van iets heeft en er een enkele waarde uit wilt halen.
    ///
    /// # Opmerking voor uitvoerders
    ///
    /// Verschillende van de andere (forward)-methoden hebben standaardimplementaties in termen van deze, dus probeer dit expliciet te implementeren als het iets beters kan doen dan de standaard `for`-lusimplementatie.
    ///
    /// Probeer in het bijzonder om deze aanroep `try_fold()` te hebben op de interne onderdelen waaruit deze iterator is samengesteld.
    /// Als er meerdere oproepen nodig zijn, kan de `?`-operator handig zijn om de accumulatorwaarde aan een ketting te koppelen, maar pas op voor invarianten die moeten worden gehandhaafd voordat deze vroege terugkeert.
    /// Dit is een `&mut self`-methode, dus de iteratie moet worden hervat nadat hier een fout is opgetreden.
    ///
    /// # Examples
    ///
    /// Basisgebruik:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // de gecontroleerde som van alle elementen van de array
    /// let sum = a.iter().try_fold(0i8, |acc, &x| acc.checked_add(x));
    ///
    /// assert_eq!(sum, Some(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = [10, 20, 30, 100, 40, 50];
    /// let mut it = a.iter();
    ///
    /// // Dit bedrag loopt over als je het 100-element toevoegt
    /// let sum = it.try_fold(0i8, |acc, &x| acc.checked_add(x));
    /// assert_eq!(sum, None);
    ///
    /// // Omdat het kortsluiting maakte, zijn de resterende elementen nog steeds beschikbaar via de iterator.
    /////
    /// assert_eq!(it.len(), 2);
    /// assert_eq!(it.next(), Some(&40));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// Een iteratormethode die een feilbare functie toepast op elk item in de iterator, stopt bij de eerste fout en die fout retourneert.
    ///
    ///
    /// Dit kan ook worden gezien als de feilbare vorm van [`for_each()`] of als de staatloze versie van [`try_fold()`].
    ///
    /// [`for_each()`]: Iterator::for_each
    /// [`try_fold()`]: Iterator::try_fold
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fs::rename;
    /// use std::io::{stdout, Write};
    /// use std::path::Path;
    ///
    /// let data = ["no_tea.txt", "stale_bread.json", "torrential_rain.png"];
    ///
    /// let res = data.iter().try_for_each(|x| writeln!(stdout(), "{}", x));
    /// assert!(res.is_ok());
    ///
    /// let mut it = data.iter().cloned();
    /// let res = it.try_for_each(|x| rename(x, Path::new(x).with_extension("old")));
    /// assert!(res.is_err());
    /// // Er is kortsluiting opgetreden, dus de resterende items zitten nog in de iterator:
    /// assert_eq!(it.next(), Some("stale_bread.json"));
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_for_each<F, R>(&mut self, f: F) -> R
    where
        Self: Sized,
        F: FnMut(Self::Item) -> R,
        R: Try<Ok = ()>,
    {
        #[inline]
        fn call<T, R>(mut f: impl FnMut(T) -> R) -> impl FnMut((), T) -> R {
            move |(), x| f(x)
        }

        self.try_fold((), call(f))
    }

    /// Vouwt elk element in een accumulator door een bewerking toe te passen, waardoor het eindresultaat wordt geretourneerd.
    ///
    /// `fold()` heeft twee argumenten: een beginwaarde en een afsluiting met twee argumenten: een 'accumulator' en een element.
    /// De sluiting retourneert de waarde die de accumulator zou moeten hebben voor de volgende iteratie.
    ///
    /// De beginwaarde is de waarde die de accumulator zal hebben bij de eerste oproep.
    ///
    /// Na het toepassen van deze sluiting op elk element van de iterator, retourneert `fold()` de accumulator.
    ///
    /// Deze bewerking wordt soms 'reduce' of 'inject' genoemd.
    ///
    /// Vouwen is handig wanneer u een verzameling van iets heeft en er een enkele waarde uit wilt halen.
    ///
    /// Note: `fold()` en soortgelijke methoden die de hele iterator doorlopen, eindigen mogelijk niet voor oneindige iteratoren, zelfs niet op traits waarvoor een resultaat in eindige tijd kan worden bepaald.
    ///
    /// Note: [`reduce()`] kan worden gebruikt om het eerste element als beginwaarde te gebruiken, als het accumulatortype en het itemtype hetzelfde zijn.
    ///
    /// # Opmerking voor uitvoerders
    ///
    /// Verschillende van de andere (forward)-methoden hebben standaardimplementaties in termen van deze, dus probeer dit expliciet te implementeren als het iets beters kan doen dan de standaard `for`-lusimplementatie.
    ///
    ///
    /// Probeer in het bijzonder om deze aanroep `fold()` te hebben op de interne onderdelen waaruit deze iterator is samengesteld.
    ///
    /// # Examples
    ///
    /// Basisgebruik:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // de som van alle elementen van de array
    /// let sum = a.iter().fold(0, |acc, x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// Laten we hier elke stap van de iteratie doorlopen:
    ///
    /// | element | acc | x | result |
    /// |---------|-----|---|--------|
    /// |         | 0   |   |        |
    /// | 1       | 0   | 1 | 1      |
    /// | 2       | 1   | 2 | 3      |
    /// | 3       | 3   | 3 | 6      |
    ///
    /// En dus, ons uiteindelijke resultaat, `6`.
    ///
    /// Het is normaal dat mensen die niet veel iterators hebben gebruikt een `for`-lus gebruiken met een lijst met dingen om een resultaat op te bouwen.Die kunnen worden omgezet in `fold()`s:
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let mut result = 0;
    ///
    /// // for loop:
    /// for i in &numbers {
    ///     result = result + i;
    /// }
    ///
    /// // fold:
    /// let result2 = numbers.iter().fold(0, |acc, &x| acc + x);
    ///
    /// // ze zijn hetzelfde
    /// assert_eq!(result, result2);
    /// ```
    ///
    /// [`reduce()`]: Iterator::reduce
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[doc(alias = "reduce")]
    #[doc(alias = "inject")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x);
        }
        accum
    }

    /// Reduceert de elementen tot één door herhaaldelijk een reducerende bewerking toe te passen.
    ///
    /// Als de iterator leeg is, geeft hij [`None`] terug;retourneert anders het resultaat van de verlaging.
    ///
    /// Voor iterators met ten minste één element is dit hetzelfde als [`fold()`] met het eerste element van de iterator als de beginwaarde, waarbij elk volgend element erin wordt gevouwen.
    ///
    ///
    /// [`fold()`]: Iterator::fold
    ///
    /// # Example
    ///
    /// Vind de maximale waarde:
    ///
    /// ```
    /// fn find_max<I>(iter: I) -> Option<I::Item>
    ///     where I: Iterator,
    ///           I::Item: Ord,
    /// {
    ///     iter.reduce(|a, b| {
    ///         if a >= b { a } else { b }
    ///     })
    /// }
    /// let a = [10, 20, 5, -23, 0];
    /// let b: [u32; 0] = [];
    ///
    /// assert_eq!(find_max(a.iter()), Some(&20));
    /// assert_eq!(find_max(b.iter()), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_fold_self", since = "1.51.0")]
    fn reduce<F>(mut self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(Self::Item, Self::Item) -> Self::Item,
    {
        let first = self.next()?;
        Some(self.fold(first, f))
    }

    /// Test of elk element van de iterator overeenkomt met een predikaat.
    ///
    /// `all()` neemt een sluiting die `true` of `false` retourneert.Het past deze sluiting toe op elk element van de iterator, en als ze allemaal `true` retourneren, doet `all()` dat ook.
    /// Als een van hen `false` retourneert, retourneert het `false`.
    ///
    /// `all()` is kortsluiting;met andere woorden, het stopt met verwerken zodra het een `false` vindt, aangezien het resultaat, wat er ook gebeurt, ook `false` zal zijn.
    ///
    ///
    /// Een lege iterator retourneert `true`.
    ///
    /// # Examples
    ///
    /// Basisgebruik:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().all(|&x| x > 0));
    ///
    /// assert!(!a.iter().all(|&x| x > 2));
    /// ```
    ///
    /// Stoppen bij de eerste `false`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(!iter.all(|&x| x != 2));
    ///
    /// // we kunnen nog steeds `iter` gebruiken, omdat er meer elementen zijn.
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    ///
    ///
    #[doc(alias = "every")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn all<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::CONTINUE } else { ControlFlow::BREAK }
            }
        }
        self.try_fold((), check(f)) == ControlFlow::CONTINUE
    }

    /// Test of een element van de iterator overeenkomt met een predikaat.
    ///
    /// `any()` neemt een sluiting die `true` of `false` retourneert.Het past deze sluiting toe op elk element van de iterator, en als een van hen `true` retourneert, doet `any()` dat ook.
    /// Als ze allemaal `false` retourneren, retourneert het `false`.
    ///
    /// `any()` is kortsluiting;met andere woorden, het stopt met verwerken zodra het een `true` vindt, aangezien het resultaat, wat er ook gebeurt, ook `true` zal zijn.
    ///
    ///
    /// Een lege iterator retourneert `false`.
    ///
    /// # Examples
    ///
    /// Basisgebruik:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().any(|&x| x > 0));
    ///
    /// assert!(!a.iter().any(|&x| x > 5));
    /// ```
    ///
    /// Stoppen bij de eerste `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(iter.any(|&x| x != 2));
    ///
    /// // we kunnen nog steeds `iter` gebruiken, omdat er meer elementen zijn.
    /// assert_eq!(iter.next(), Some(&2));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn any<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::BREAK } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(f)) == ControlFlow::BREAK
    }

    /// Zoekt naar een element van een iterator dat aan een predikaat voldoet.
    ///
    /// `find()` neemt een sluiting die `true` of `false` retourneert.
    /// Het past deze sluiting toe op elk element van de iterator, en als een van hen `true` retourneert, retourneert `find()` [`Some(element)`].
    /// Als ze allemaal `false` retourneren, retourneert het [`None`].
    ///
    /// `find()` is kortsluiting;met andere woorden, het stopt met verwerken zodra de sluiting `true` retourneert.
    ///
    /// Omdat `find()` een verwijzing aanneemt, en veel iteratoren verwijzingen herhalen, leidt dit tot een mogelijk verwarrende situatie waarin het argument een dubbele verwijzing is.
    ///
    /// U kunt dit effect zien in de onderstaande voorbeelden, met `&&x`.
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// Basisgebruik:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 5), None);
    /// ```
    ///
    /// Stoppen bij de eerste `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.find(|&&x| x == 2), Some(&2));
    ///
    /// // we kunnen nog steeds `iter` gebruiken, omdat er meer elementen zijn.
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    /// Merk op dat `iter.find(f)` gelijk is aan `iter.filter(f).next()`.
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn find<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(predicate)).break_value()
    }

    /// Past de functie toe op de elementen van iterator en retourneert het eerste niet-geen resultaat.
    ///
    ///
    /// `iter.find_map(f)` is gelijk aan `iter.filter_map(f).next()`.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ["lol", "NaN", "2", "5"];
    ///
    /// let first_number = a.iter().find_map(|s| s.parse().ok());
    ///
    /// assert_eq!(first_number, Some(2));
    /// ```
    #[inline]
    #[stable(feature = "iterator_find_map", since = "1.30.0")]
    fn find_map<B, F>(&mut self, f: F) -> Option<B>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        #[inline]
        fn check<T, B>(mut f: impl FnMut(T) -> Option<B>) -> impl FnMut((), T) -> ControlFlow<B> {
            move |(), x| match f(x) {
                Some(x) => ControlFlow::Break(x),
                None => ControlFlow::CONTINUE,
            }
        }

        self.try_fold((), check(f)).break_value()
    }

    /// Past de functie toe op de elementen van iterator en retourneert het eerste echte resultaat of de eerste fout.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_find)]
    ///
    /// let a = ["1", "2", "lol", "NaN", "5"];
    ///
    /// let is_my_num = |s: &str, search: i32| -> Result<bool, std::num::ParseIntError> {
    ///     Ok(s.parse::<i32>()?  == search)
    /// };
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 2));
    /// assert_eq!(result, Ok(Some(&"2")));
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 5));
    /// assert!(result.is_err());
    /// ```
    #[inline]
    #[unstable(feature = "try_find", reason = "new API", issue = "63178")]
    fn try_find<F, R>(&mut self, f: F) -> Result<Option<Self::Item>, R::Error>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> R,
        R: Try<Ok = bool>,
    {
        #[inline]
        fn check<F, T, R>(mut f: F) -> impl FnMut((), T) -> ControlFlow<Result<T, R::Error>>
        where
            F: FnMut(&T) -> R,
            R: Try<Ok = bool>,
        {
            move |(), x| match f(&x).into_result() {
                Ok(false) => ControlFlow::CONTINUE,
                Ok(true) => ControlFlow::Break(Ok(x)),
                Err(x) => ControlFlow::Break(Err(x)),
            }
        }

        self.try_fold((), check(f)).break_value().transpose()
    }

    /// Zoekt naar een element in een iterator en retourneert zijn index.
    ///
    /// `position()` neemt een sluiting die `true` of `false` retourneert.
    /// Het past deze sluiting toe op elk element van de iterator, en als een van hen `true` retourneert, retourneert `position()` [`Some(index)`].
    /// Als ze allemaal `false` retourneren, retourneert het [`None`].
    ///
    /// `position()` is kortsluiting;met andere woorden, het stopt met verwerken zodra het een `true` vindt.
    ///
    /// # Overloopgedrag
    ///
    /// De methode beschermt niet tegen overlopen, dus als er meer dan [`usize::MAX`] niet-overeenkomende elementen zijn, levert het ofwel het verkeerde resultaat op of panics.
    ///
    /// Als debug-beweringen zijn ingeschakeld, is een panic gegarandeerd.
    ///
    /// # Panics
    ///
    /// Deze functie kan panic zijn als de iterator meer dan `usize::MAX` niet-overeenkomende elementen heeft.
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// Basisgebruik:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().position(|&x| x == 2), Some(1));
    ///
    /// assert_eq!(a.iter().position(|&x| x == 5), None);
    /// ```
    ///
    /// Stoppen bij de eerste `true`:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.position(|&x| x >= 2), Some(1));
    ///
    /// // we kunnen nog steeds `iter` gebruiken, omdat er meer elementen zijn.
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // De geretourneerde index is afhankelijk van de iteratorstatus
    /// assert_eq!(iter.position(|&x| x == 4), Some(0));
    ///
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn position<P>(&mut self, predicate: P) -> Option<usize>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            #[rustc_inherit_overflow_checks]
            move |i, x| {
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i + 1) }
            }
        }

        self.try_fold(0, check(predicate)).break_value()
    }

    /// Zoekt naar een element in een iterator van rechts en retourneert zijn index.
    ///
    /// `rposition()` neemt een sluiting die `true` of `false` retourneert.
    /// Het past deze sluiting toe op elk element van de iterator, beginnend vanaf het einde, en als een van hen `true` retourneert, retourneert `rposition()` [`Some(index)`].
    ///
    /// Als ze allemaal `false` retourneren, retourneert het [`None`].
    ///
    /// `rposition()` is kortsluiting;met andere woorden, het stopt met verwerken zodra het een `true` vindt.
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// Basisgebruik:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 3), Some(2));
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 5), None);
    /// ```
    ///
    /// Stoppen bij de eerste `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rposition(|&x| x == 2), Some(1));
    ///
    /// // we kunnen nog steeds `iter` gebruiken, omdat er meer elementen zijn.
    /// assert_eq!(iter.next(), Some(&1));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rposition<P>(&mut self, predicate: P) -> Option<usize>
    where
        P: FnMut(Self::Item) -> bool,
        Self: Sized + ExactSizeIterator + DoubleEndedIterator,
    {
        // Hier is geen overloopcontrole nodig, omdat `ExactSizeIterator` impliceert dat het aantal elementen in een `usize` past.
        //
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            move |i, x| {
                let i = i - 1;
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i) }
            }
        }

        let n = self.len();
        self.try_rfold(n, check(predicate)).break_value()
    }

    /// Retourneert het maximale element van een iterator.
    ///
    /// Als meerdere elementen even maximum zijn, wordt het laatste element geretourneerd.
    /// Als de iterator leeg is, wordt [`None`] geretourneerd.
    ///
    /// # Examples
    ///
    /// Basisgebruik:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().max(), Some(&3));
    /// assert_eq!(b.iter().max(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn max(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.max_by(Ord::cmp)
    }

    /// Retourneert het minimumelement van een iterator.
    ///
    /// Als meerdere elementen even minimaal zijn, wordt het eerste element geretourneerd.
    /// Als de iterator leeg is, wordt [`None`] geretourneerd.
    ///
    /// # Examples
    ///
    /// Basisgebruik:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().min(), Some(&1));
    /// assert_eq!(b.iter().min(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn min(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.min_by(Ord::cmp)
    }

    /// Retourneert het element dat de maximale waarde van de opgegeven functie geeft.
    ///
    ///
    /// Als meerdere elementen even maximum zijn, wordt het laatste element geretourneerd.
    /// Als de iterator leeg is, wordt [`None`] geretourneerd.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by_key(|x| x.abs()).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn max_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).max_by(compare)?;
        Some(x)
    }

    /// Retourneert het element dat de maximale waarde geeft met betrekking tot de opgegeven vergelijkingsfunctie.
    ///
    ///
    /// Als meerdere elementen even maximum zijn, wordt het laatste element geretourneerd.
    /// Als de iterator leeg is, wordt [`None`] geretourneerd.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by(|x, y| x.cmp(y)).unwrap(), 5);
    /// ```
    #[inline]
    #[stable(feature = "iter_max_by", since = "1.15.0")]
    fn max_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::max_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// Retourneert het element dat de minimumwaarde van de opgegeven functie geeft.
    ///
    ///
    /// Als meerdere elementen even minimaal zijn, wordt het eerste element geretourneerd.
    /// Als de iterator leeg is, wordt [`None`] geretourneerd.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by_key(|x| x.abs()).unwrap(), 0);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn min_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).min_by(compare)?;
        Some(x)
    }

    /// Retourneert het element dat de minimumwaarde geeft met betrekking tot de opgegeven vergelijkingsfunctie.
    ///
    ///
    /// Als meerdere elementen even minimaal zijn, wordt het eerste element geretourneerd.
    /// Als de iterator leeg is, wordt [`None`] geretourneerd.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by(|x, y| x.cmp(y)).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_min_by", since = "1.15.0")]
    fn min_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::min_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// Keert de richting van een iterator om.
    ///
    /// Gewoonlijk herhalen iteratoren van links naar rechts.
    /// Na het gebruik van `rev()`, zal een iterator in plaats daarvan van rechts naar links itereren.
    ///
    /// Dit is alleen mogelijk als de iterator een einde heeft, dus `rev()` werkt alleen op [`DoubleEndedIterator`] s.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().rev();
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[doc(alias = "reverse")]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rev(self) -> Rev<Self>
    where
        Self: Sized + DoubleEndedIterator,
    {
        Rev::new(self)
    }

    /// Converteert een iterator van paren naar een paar containers.
    ///
    /// `unzip()` verbruikt een hele iterator van paren en produceert twee verzamelingen: een van de linkerelementen van de paren en een van de rechterelementen.
    ///
    ///
    /// Deze functie is in zekere zin het tegenovergestelde van [`zip`].
    ///
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// Basisgebruik:
    ///
    /// ```
    /// let a = [(1, 2), (3, 4)];
    ///
    /// let (left, right): (Vec<_>, Vec<_>) = a.iter().cloned().unzip();
    ///
    /// assert_eq!(left, [1, 3]);
    /// assert_eq!(right, [2, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn unzip<A, B, FromA, FromB>(self) -> (FromA, FromB)
    where
        FromA: Default + Extend<A>,
        FromB: Default + Extend<B>,
        Self: Sized + Iterator<Item = (A, B)>,
    {
        fn extend<'a, A, B>(
            ts: &'a mut impl Extend<A>,
            us: &'a mut impl Extend<B>,
        ) -> impl FnMut((), (A, B)) + 'a {
            move |(), (t, u)| {
                ts.extend_one(t);
                us.extend_one(u);
            }
        }

        let mut ts: FromA = Default::default();
        let mut us: FromB = Default::default();

        let (lower_bound, _) = self.size_hint();
        if lower_bound > 0 {
            ts.extend_reserve(lower_bound);
            us.extend_reserve(lower_bound);
        }

        self.fold((), extend(&mut ts, &mut us));

        (ts, us)
    }

    /// Creëert een iterator die al zijn elementen kopieert.
    ///
    /// Dit is handig als je een iterator over `&T` hebt, maar je hebt een iterator over `T` nodig.
    ///
    ///
    /// # Examples
    ///
    /// Basisgebruik:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_copied: Vec<_> = a.iter().copied().collect();
    ///
    /// // gekopieerd is hetzelfde als .map(|&x| x)
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_copied, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "iter_copied", since = "1.36.0")]
    fn copied<'a, T: 'a>(self) -> Copied<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Copy,
    {
        Copied::new(self)
    }

    /// Creëert een iterator die al zijn elementen [`clone`] bevat.
    ///
    /// Dit is handig als je een iterator over `&T` hebt, maar je hebt een iterator over `T` nodig.
    ///
    ///
    /// [`clone`]: Clone::clone
    ///
    /// # Examples
    ///
    /// Basisgebruik:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_cloned: Vec<_> = a.iter().cloned().collect();
    ///
    /// // gekloond is hetzelfde als .map(|&x| x), voor gehele getallen
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_cloned, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn cloned<'a, T: 'a>(self) -> Cloned<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Clone,
    {
        Cloned::new(self)
    }

    /// Herhaalt een iterator eindeloos.
    ///
    /// In plaats van te stoppen bij [`None`], zal de iterator in plaats daarvan opnieuw starten, vanaf het begin.Nadat het opnieuw is herhaald, begint het opnieuw bij het begin.En opnieuw.
    /// En opnieuw.
    /// Forever.
    ///
    /// # Examples
    ///
    /// Basisgebruik:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut it = a.iter().cycle();
    ///
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    fn cycle(self) -> Cycle<Self>
    where
        Self: Sized + Clone,
    {
        Cycle::new(self)
    }

    /// Sommeert de elementen van een iterator.
    ///
    /// Neemt elk element, telt ze bij elkaar op en retourneert het resultaat.
    ///
    /// Een lege iterator retourneert de nulwaarde van het type.
    ///
    /// # Panics
    ///
    /// Wanneer `sum()` wordt aangeroepen en een primitief integer-type wordt geretourneerd, zal deze methode panic zijn als de berekening overloopt en debug-beweringen zijn ingeschakeld.
    ///
    ///
    /// # Examples
    ///
    /// Basisgebruik:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let sum: i32 = a.iter().sum();
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn sum<S>(self) -> S
    where
        Self: Sized,
        S: Sum<Self::Item>,
    {
        Sum::sum(self)
    }

    /// Herhaalt de hele iterator en vermenigvuldigt alle elementen
    ///
    /// Een lege iterator retourneert de enige waarde van het type.
    ///
    /// # Panics
    ///
    /// Wanneer `product()` wordt aangeroepen en een primitief integer-type wordt geretourneerd, zal de methode panic zijn als de berekening overloopt en debug-beweringen zijn ingeschakeld.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// fn factorial(n: u32) -> u32 {
    ///     (1..=n).product()
    /// }
    /// assert_eq!(factorial(0), 1);
    /// assert_eq!(factorial(1), 1);
    /// assert_eq!(factorial(5), 120);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn product<P>(self) -> P
    where
        Self: Sized,
        P: Product<Self::Item>,
    {
        Product::product(self)
    }

    /// [Lexicographically](Ord#lexicographical-comparison) vergelijkt de elementen van deze [`Iterator`] met die van een ander.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1].iter().cmp([1].iter()), Ordering::Equal);
    /// assert_eq!([1].iter().cmp([1, 2].iter()), Ordering::Less);
    /// assert_eq!([1, 2].iter().cmp([1].iter()), Ordering::Greater);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn cmp<I>(self, other: I) -> Ordering
    where
        I: IntoIterator<Item = Self::Item>,
        Self::Item: Ord,
        Self: Sized,
    {
        self.cmp_by(other, |x, y| x.cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) vergelijkt de elementen van deze [`Iterator`] met die van een ander met betrekking tot de gespecificeerde vergelijkingsfunctie.
    ///
    ///
    /// # Examples
    ///
    /// Basisgebruik:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| x.cmp(&y)), Ordering::Less);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (x * x).cmp(&y)), Ordering::Equal);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (2 * x).cmp(&y)), Ordering::Greater);
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn cmp_by<I, F>(mut self, other: I, mut cmp: F) -> Ordering
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Ordering,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Ordering::Equal;
                    } else {
                        return Ordering::Less;
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Ordering::Greater,
                Some(val) => val,
            };

            match cmp(x, y) {
                Ordering::Equal => (),
                non_eq => return non_eq,
            }
        }
    }

    /// [Lexicographically](Ord#lexicographical-comparison) vergelijkt de elementen van deze [`Iterator`] met die van een ander.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1.].iter().partial_cmp([1.].iter()), Some(Ordering::Equal));
    /// assert_eq!([1.].iter().partial_cmp([1., 2.].iter()), Some(Ordering::Less));
    /// assert_eq!([1., 2.].iter().partial_cmp([1.].iter()), Some(Ordering::Greater));
    ///
    /// assert_eq!([f64::NAN].iter().partial_cmp([1.].iter()), None);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn partial_cmp<I>(self, other: I) -> Option<Ordering>
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp_by(other, |x, y| x.partial_cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) vergelijkt de elementen van deze [`Iterator`] met die van een ander met betrekking tot de gespecificeerde vergelijkingsfunctie.
    ///
    ///
    /// # Examples
    ///
    /// Basisgebruik:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1.0, 2.0, 3.0, 4.0];
    /// let ys = [1.0, 4.0, 9.0, 16.0];
    ///
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| x.partial_cmp(&y)),
    ///     Some(Ordering::Less)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (x * x).partial_cmp(&y)),
    ///     Some(Ordering::Equal)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (2.0 * x).partial_cmp(&y)),
    ///     Some(Ordering::Greater)
    /// );
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn partial_cmp_by<I, F>(mut self, other: I, mut partial_cmp: F) -> Option<Ordering>
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Option<Ordering>,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Some(Ordering::Equal);
                    } else {
                        return Some(Ordering::Less);
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Some(Ordering::Greater),
                Some(val) => val,
            };

            match partial_cmp(x, y) {
                Some(Ordering::Equal) => (),
                non_eq => return non_eq,
            }
        }
    }

    /// Bepaalt of de elementen van deze [`Iterator`] gelijk zijn aan die van een ander.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().eq([1].iter()), true);
    /// assert_eq!([1].iter().eq([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn eq<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        self.eq_by(other, |x, y| x == y)
    }

    /// Bepaalt of de elementen van deze [`Iterator`] gelijk zijn aan die van een ander met betrekking tot de gespecificeerde gelijkheidsfunctie.
    ///
    ///
    /// # Examples
    ///
    /// Basisgebruik:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert!(xs.iter().eq_by(&ys, |&x, &y| x * x == y));
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn eq_by<I, F>(mut self, other: I, mut eq: F) -> bool
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> bool,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => return other.next().is_none(),
                Some(val) => val,
            };

            let y = match other.next() {
                None => return false,
                Some(val) => val,
            };

            if !eq(x, y) {
                return false;
            }
        }
    }

    /// Bepaalt of de elementen van deze [`Iterator`] ongelijk zijn aan die van een ander.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ne([1].iter()), false);
    /// assert_eq!([1].iter().ne([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ne<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        !self.eq(other)
    }

    /// Bepaalt of de elementen van deze [`Iterator`] [lexicographically](Ord#lexicographical-comparison) kleiner zijn dan die van een andere.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().lt([1].iter()), false);
    /// assert_eq!([1].iter().lt([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().lt([1].iter()), false);
    /// assert_eq!([1, 2].iter().lt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn lt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Less)
    }

    /// Bepaalt of de elementen van deze [`Iterator`] [lexicographically](Ord#lexicographical-comparison) kleiner of gelijk zijn aan die van een ander.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().le([1].iter()), true);
    /// assert_eq!([1].iter().le([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().le([1].iter()), false);
    /// assert_eq!([1, 2].iter().le([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn le<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Less | Ordering::Equal))
    }

    /// Bepaalt of de elementen van deze [`Iterator`] [lexicographically](Ord#lexicographical-comparison) groter zijn dan die van een andere.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().gt([1].iter()), false);
    /// assert_eq!([1].iter().gt([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().gt([1].iter()), true);
    /// assert_eq!([1, 2].iter().gt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn gt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Greater)
    }

    /// Bepaalt of de elementen van deze [`Iterator`] [lexicographically](Ord#lexicographical-comparison) groter of gelijk zijn aan die van een ander.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ge([1].iter()), true);
    /// assert_eq!([1].iter().ge([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().ge([1].iter()), true);
    /// assert_eq!([1, 2].iter().ge([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ge<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Greater | Ordering::Equal))
    }

    /// Controleert of de elementen van deze iterator zijn gesorteerd.
    ///
    /// Dat wil zeggen dat voor elk element `a` en het volgende element `b`, `a <= b` moet staan.Als de iterator precies nul of één element oplevert, wordt `true` geretourneerd.
    ///
    /// Merk op dat als `Self::Item` alleen `PartialOrd` is, maar niet `Ord`, de bovenstaande definitie impliceert dat deze functie `false` retourneert als twee opeenvolgende items niet vergelijkbaar zijn.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted());
    /// assert!(![1, 3, 2, 4].iter().is_sorted());
    /// assert!([0].iter().is_sorted());
    /// assert!(std::iter::empty::<i32>().is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted(self) -> bool
    where
        Self: Sized,
        Self::Item: PartialOrd,
    {
        self.is_sorted_by(PartialOrd::partial_cmp)
    }

    /// Controleert of de elementen van deze iterator zijn gesorteerd met behulp van de opgegeven vergelijkingsfunctie.
    ///
    /// In plaats van `PartialOrd::partial_cmp` te gebruiken, gebruikt deze functie de gegeven `compare`-functie om de volgorde van twee elementen te bepalen.
    /// Afgezien daarvan is het gelijk aan [`is_sorted`];zie de documentatie voor meer informatie.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![1, 3, 2, 4].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!([0].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(std::iter::empty::<i32>().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// ```
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by<F>(mut self, compare: F) -> bool
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Option<Ordering>,
    {
        #[inline]
        fn check<'a, T>(
            last: &'a mut T,
            mut compare: impl FnMut(&T, &T) -> Option<Ordering> + 'a,
        ) -> impl FnMut(T) -> bool + 'a {
            move |curr| {
                if let Some(Ordering::Greater) | None = compare(&last, &curr) {
                    return false;
                }
                *last = curr;
                true
            }
        }

        let mut last = match self.next() {
            Some(e) => e,
            None => return true,
        };

        self.all(check(&mut last, compare))
    }

    /// Controleert of de elementen van deze iterator zijn gesorteerd met behulp van de gegeven sleutelextractiefunctie.
    ///
    /// In plaats van de elementen van de iterator rechtstreeks te vergelijken, vergelijkt deze functie de sleutels van de elementen, zoals bepaald door `f`.
    /// Afgezien daarvan is het gelijk aan [`is_sorted`];zie de documentatie voor meer informatie.
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].iter().is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].iter().is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by_key<F, K>(self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> K,
        K: PartialOrd,
    {
        self.map(f).is_sorted()
    }

    /// Zie [TrustedRandomAccess]
    // De ongebruikelijke naam is om naambotsingen in methodresolutie te voorkomen, zie #76479.
    //
    #[inline]
    #[doc(hidden)]
    #[unstable(feature = "trusted_random_access", issue = "none")]
    unsafe fn __iterator_get_unchecked(&mut self, _idx: usize) -> Self::Item
    where
        Self: TrustedRandomAccess,
    {
        unreachable!("Always specialized");
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator + ?Sized> Iterator for &mut I {
    type Item = I::Item;
    fn next(&mut self) -> Option<I::Item> {
        (**self).next()
    }
    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_by(n)
    }
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        (**self).nth(n)
    }
}