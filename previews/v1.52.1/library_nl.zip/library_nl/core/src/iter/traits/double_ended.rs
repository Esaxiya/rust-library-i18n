use crate::ops::{ControlFlow, Try};

/// Een iterator die elementen van beide uiteinden kan opleveren.
///
/// Iets dat `DoubleEndedIterator` implementeert, heeft een extra mogelijkheid ten opzichte van iets dat [`Iterator`] implementeert: de mogelijkheid om ook `Item`s van de achterkant als van de voorkant te nemen.
///
///
/// Het is belangrijk op te merken dat zowel heen als weer op hetzelfde bereik werken en elkaar niet kruisen: de iteratie is voorbij als ze elkaar in het midden ontmoeten.
///
/// Op een vergelijkbare manier als het [`Iterator`]-protocol, zodra een `DoubleEndedIterator` [`None`] retourneert van een [`next_back()`], kan het opnieuw oproepen wel of niet [`Some`] teruggeven.
/// [`next()`] en [`next_back()`] zijn hiervoor uitwisselbaar.
///
/// [`next_back()`]: DoubleEndedIterator::next_back
/// [`next()`]: Iterator::next
///
/// # Examples
///
/// Basisgebruik:
///
/// ```
/// let numbers = vec![1, 2, 3, 4, 5, 6];
///
/// let mut iter = numbers.iter();
///
/// assert_eq!(Some(&1), iter.next());
/// assert_eq!(Some(&6), iter.next_back());
/// assert_eq!(Some(&5), iter.next_back());
/// assert_eq!(Some(&2), iter.next());
/// assert_eq!(Some(&3), iter.next());
/// assert_eq!(Some(&4), iter.next());
/// assert_eq!(None, iter.next());
/// assert_eq!(None, iter.next_back());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DoubleEndedIterator: Iterator {
    /// Verwijdert en retourneert een element aan het einde van de iterator.
    ///
    /// Retourneert `None` als er geen elementen meer zijn.
    ///
    /// De [trait-level]-documenten bevatten meer details.
    ///
    /// [trait-level]: DoubleEndedIterator
    ///
    /// # Examples
    ///
    /// Basisgebruik:
    ///
    /// ```
    /// let numbers = vec![1, 2, 3, 4, 5, 6];
    ///
    /// let mut iter = numbers.iter();
    ///
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&6), iter.next_back());
    /// assert_eq!(Some(&5), iter.next_back());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    /// assert_eq!(Some(&4), iter.next());
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next_back());
    /// ```
    ///
    /// # Remarks
    ///
    /// De elementen die worden opgeleverd door de methoden van `DoubleEndedIterator 'kunnen verschillen van de elementen die worden opgeleverd door de methoden van [` Iterator']:
    ///
    ///
    /// ```
    /// let vec = vec![(1, 'a'), (1, 'b'), (1, 'c'), (2, 'a'), (2, 'b')];
    /// let uniq_by_fst_comp = || {
    ///     let mut seen = std::collections::HashSet::new();
    ///     vec.iter().copied().filter(move |x| seen.insert(x.0))
    /// };
    ///
    /// assert_eq!(uniq_by_fst_comp().last(), Some((2, 'a')));
    /// assert_eq!(uniq_by_fst_comp().next_back(), Some((2, 'b')));
    ///
    /// assert_eq!(
    ///     uniq_by_fst_comp().fold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(1, 'a'), (2, 'a')]
    /// );
    /// assert_eq!(
    ///     uniq_by_fst_comp().rfold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(2, 'b'), (1, 'c')]
    /// );
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next_back(&mut self) -> Option<Self::Item>;

    /// Verhoogt de iterator van achteren door `n`-elementen.
    ///
    /// `advance_back_by` is de omgekeerde versie van [`advance_by`].Deze methode zal gretig `n`-elementen overslaan, beginnend vanaf de achterkant door [`next_back`] tot `n` keer aan te roepen totdat [`None`] wordt aangetroffen.
    ///
    /// `advance_back_by(n)` zal [`Ok(())`] retourneren als de iterator met succes door `n`-elementen gaat, of [`Err(k)`] als [`None`] wordt aangetroffen, waarbij `k` het aantal elementen is waarmee de iterator wordt vooruitgeschoven voordat de elementen opraken (dwz
    /// de lengte van de iterator).
    /// Merk op dat `k` altijd kleiner is dan `n`.
    ///
    /// Het aanroepen van `advance_back_by(0)` verbruikt geen elementen en retourneert altijd [`Ok(())`].
    ///
    /// [`advance_by`]: Iterator::advance_by
    /// [`next_back`]: DoubleEndedIterator::next_back
    ///
    /// # Examples
    ///
    /// Basisgebruik:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [3, 4, 5, 6];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_back_by(2), Ok(()));
    /// assert_eq!(iter.next_back(), Some(&4));
    /// assert_eq!(iter.advance_back_by(0), Ok(()));
    /// assert_eq!(iter.advance_back_by(100), Err(1)); // alleen `&3` werd overgeslagen
    /// ```
    ///
    /// [`Ok(())`]: Ok
    /// [`Err(k)`]: Err
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next_back().ok_or(i)?;
        }
        Ok(())
    }

    /// Retourneert het 'n'-de element vanaf het einde van de iterator.
    ///
    /// Dit is in wezen de omgekeerde versie van [`Iterator::nth()`].
    /// Hoewel het tellen, zoals bij de meeste indexeringsbewerkingen, begint bij nul, retourneert `nth_back(0)` de eerste waarde vanaf het einde, `nth_back(1)` de tweede, enzovoort.
    ///
    ///
    /// Merk op dat alle elementen tussen het einde en het geretourneerde element zullen worden verbruikt, inclusief het geretourneerde element.
    /// Dit betekent ook dat het meerdere keren aanroepen van `nth_back(0)` op dezelfde iterator verschillende elementen zal retourneren.
    ///
    /// `nth_back()` zal [`None`] teruggeven als `n` groter is dan of gelijk is aan de lengte van de iterator.
    ///
    /// # Examples
    ///
    /// Basisgebruik:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(2), Some(&1));
    /// ```
    ///
    /// Door `nth_back()` meerdere keren aan te roepen, wordt de iterator niet teruggespoeld:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth_back(1), Some(&2));
    /// assert_eq!(iter.nth_back(1), None);
    /// ```
    ///
    /// `None` retourneren als er minder dan `n + 1`-elementen zijn:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(10), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_nth_back", since = "1.37.0")]
    fn nth_back(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_back_by(n).ok()?;
        self.next_back()
    }

    /// Dit is de omgekeerde versie van [`Iterator::try_fold()`]: het heeft elementen nodig vanaf de achterkant van de iterator.
    ///
    ///
    /// # Examples
    ///
    /// Basisgebruik:
    ///
    /// ```
    /// let a = ["1", "2", "3"];
    /// let sum = a.iter()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert_eq!(sum, Ok(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = ["1", "rust", "3"];
    /// let mut it = a.iter();
    /// let sum = it
    ///     .by_ref()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert!(sum.is_err());
    ///
    /// // Omdat het kortsluiting maakte, zijn de resterende elementen nog steeds beschikbaar via de iterator.
    /////
    /// assert_eq!(it.next_back(), Some(&"1"));
    /// ```
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// Een iteratormethode die de elementen van de iterator reduceert tot een enkele, uiteindelijke waarde, beginnend vanaf de achterkant.
    ///
    /// Dit is de omgekeerde versie van [`Iterator::fold()`]: het heeft elementen nodig vanaf de achterkant van de iterator.
    ///
    /// `rfold()` heeft twee argumenten: een beginwaarde en een afsluiting met twee argumenten: een 'accumulator' en een element.
    /// De sluiting retourneert de waarde die de accumulator zou moeten hebben voor de volgende iteratie.
    ///
    /// De beginwaarde is de waarde die de accumulator zal hebben bij de eerste oproep.
    ///
    /// Na het toepassen van deze sluiting op elk element van de iterator, retourneert `rfold()` de accumulator.
    ///
    /// Deze bewerking wordt soms 'reduce' of 'inject' genoemd.
    ///
    /// Vouwen is handig wanneer u een verzameling van iets heeft en er een enkele waarde uit wilt halen.
    ///
    /// # Examples
    ///
    /// Basisgebruik:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // de som van alle elementen van a
    /// let sum = a.iter()
    ///            .rfold(0, |acc, &x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// In dit voorbeeld wordt een string opgebouwd, beginnend met een beginwaarde en doorlopend met elk element van achteren naar voren:
    ///
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let zero = "0".to_string();
    ///
    /// let result = numbers.iter().rfold(zero, |acc, &x| {
    ///     format!("({} + {})", x, acc)
    /// });
    ///
    /// assert_eq!(result, "(1 + (2 + (3 + (4 + (5 + 0)))))");
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfold", since = "1.27.0")]
    fn rfold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x);
        }
        accum
    }

    /// Zoekt vanaf de achterkant naar een element van een iterator dat aan een predikaat voldoet.
    ///
    /// `rfind()` neemt een sluiting die `true` of `false` retourneert.
    /// Het past deze sluiting toe op elk element van de iterator, beginnend bij het einde, en als een van hen `true` retourneert, retourneert `rfind()` [`Some(element)`].
    /// Als ze allemaal `false` retourneren, retourneert het [`None`].
    ///
    /// `rfind()` is kortsluiting;met andere woorden, het stopt met verwerken zodra de sluiting `true` retourneert.
    ///
    /// Omdat `rfind()` een verwijzing aanneemt, en veel iteratoren verwijzingen herhalen, leidt dit tot een mogelijk verwarrende situatie waarin het argument een dubbele verwijzing is.
    ///
    /// U kunt dit effect zien in de onderstaande voorbeelden, met `&&x`.
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// Basisgebruik:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 5), None);
    /// ```
    ///
    /// Stoppen bij de eerste `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rfind(|&&x| x == 2), Some(&2));
    ///
    /// // we kunnen nog steeds `iter` gebruiken, omdat er meer elementen zijn.
    /// assert_eq!(iter.next_back(), Some(&1));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfind", since = "1.27.0")]
    fn rfind<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_rfold((), check(predicate)).break_value()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, I: DoubleEndedIterator + ?Sized> DoubleEndedIterator for &'a mut I {
    fn next_back(&mut self) -> Option<I::Item> {
        (**self).next_back()
    }
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_back_by(n)
    }
    fn nth_back(&mut self, n: usize) -> Option<I::Item> {
        (**self).nth_back(n)
    }
}