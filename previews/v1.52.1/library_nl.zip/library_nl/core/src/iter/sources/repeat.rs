use crate::iter::{FusedIterator, TrustedLen};

/// Creëert een nieuwe iterator die een enkel element eindeloos herhaalt.
///
/// De `repeat()`-functie herhaalt een enkele waarde keer op keer.
///
/// Oneindige iteratoren zoals `repeat()` worden vaak gebruikt met adapters zoals [`Iterator::take()`], om ze eindig te maken.
///
/// Als het elementtype van de iterator dat je nodig hebt `Clone` niet implementeert, of als je het herhaalde element niet in het geheugen wilt bewaren, kun je in plaats daarvan de functie [`repeat_with()`] gebruiken.
///
///
/// [`repeat_with()`]: crate::iter::repeat_with
///
/// # Examples
///
/// Basisgebruik:
///
/// ```
/// use std::iter;
///
/// // de nummer vier 4ever:
/// let mut fours = iter::repeat(4);
///
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
///
/// // ja, nog steeds vier
/// assert_eq!(Some(4), fours.next());
/// ```
///
/// Eindig worden met [`Iterator::take()`]:
///
/// ```
/// use std::iter;
///
/// // dat laatste voorbeeld was te veel vieren.Laten we maar vier vieren hebben.
/// let mut four_fours = iter::repeat(4).take(4);
///
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
///
/// // ... en nu zijn we klaar
/// assert_eq!(None, four_fours.next());
/// ```
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn repeat<T: Clone>(elt: T) -> Repeat<T> {
    Repeat { element: elt }
}

/// Een iterator die een element eindeloos herhaalt.
///
/// Deze `struct` is gemaakt door de [`repeat()`]-functie.Zie de documentatie voor meer.
#[derive(Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Repeat<A> {
    element: A,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> Iterator for Repeat<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> DoubleEndedIterator for Repeat<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Clone> FusedIterator for Repeat<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Clone> TrustedLen for Repeat<A> {}