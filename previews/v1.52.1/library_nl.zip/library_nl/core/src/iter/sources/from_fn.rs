use crate::fmt;

/// Creëert een nieuwe iterator waarbij elke iteratie de voorziene afsluiting `F: FnMut() -> Option<T>` aanroept.
///
/// Dit maakt het mogelijk om een aangepaste iterator met elk gedrag te maken zonder de meer uitgebreide syntaxis te gebruiken van het maken van een speciaal type en de [`Iterator`] trait ervoor te implementeren.
///
/// Merk op dat de `FromFn`-iterator geen aannames doet over het gedrag van de sluiting, en daarom conservatief [`FusedIterator`] niet implementeert, of [`Iterator::size_hint()`] overschrijft van de standaard `(0, None)`.
///
///
/// De sluiting kan vastleggingen en de omgeving ervan gebruiken om de status door iteraties te volgen.Afhankelijk van hoe de iterator wordt gebruikt, kan het nodig zijn om het [`move`]-sleutelwoord op de sluiting op te geven.
///
/// [`move`]: ../../std/keyword.move.html
/// [`FusedIterator`]: crate::iter::FusedIterator
///
/// # Examples
///
/// Laten we de teller-iterator van [module-level documentation] opnieuw implementeren:
///
/// [module-level documentation]: crate::iter
///
/// ```
/// let mut count = 0;
/// let counter = std::iter::from_fn(move || {
///     // Verhoog onze telling.Daarom zijn we bij nul begonnen.
///     count += 1;
///
///     // Controleer of we klaar zijn met tellen of niet.
///     if count < 6 {
///         Some(count)
///     } else {
///         None
///     }
/// });
/// assert_eq!(counter.collect::<Vec<_>>(), &[1, 2, 3, 4, 5]);
/// ```
///
///
///
///
///
#[inline]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub fn from_fn<T, F>(f: F) -> FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    FromFn(f)
}

/// Een iterator waarbij elke iteratie de meegeleverde sluiting `F: FnMut() -> Option<T>` aanroept.
///
/// Deze `struct` is gemaakt door de [`iter::from_fn()`]-functie.
/// Zie de documentatie voor meer.
///
/// [`iter::from_fn()`]: from_fn
#[derive(Clone)]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub struct FromFn<F>(F);

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<T, F> Iterator for FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<Self::Item> {
        (self.0)()
    }
}

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<F> fmt::Debug for FromFn<F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("FromFn").finish()
    }
}