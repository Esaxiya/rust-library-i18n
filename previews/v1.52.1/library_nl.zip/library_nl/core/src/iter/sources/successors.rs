use crate::{fmt, iter::FusedIterator};

/// Creëert een nieuwe iterator waarin elk volgend item wordt berekend op basis van het voorgaande.
///
/// De iterator begint met het opgegeven eerste item (indien aanwezig) en roept de gegeven `FnMut(&T) -> Option<T>`-sluiting aan om de opvolger van elk item te berekenen.
///
///
/// ```
/// use std::iter::successors;
///
/// let powers_of_10 = successors(Some(1_u16), |n| n.checked_mul(10));
/// assert_eq!(powers_of_10.collect::<Vec<_>>(), &[1, 10, 100, 1_000, 10_000]);
/// ```
#[stable(feature = "iter_successors", since = "1.34.0")]
pub fn successors<T, F>(first: Option<T>, succ: F) -> Successors<T, F>
where
    F: FnMut(&T) -> Option<T>,
{
    // Als deze functie `impl Iterator<Item=T>` retourneerde, zou deze gebaseerd kunnen zijn op `unfold` en geen speciaal type nodig hebben.
    //
    // Als u echter een `Successors<T, F>`-type heeft, kan het `Clone` zijn als `T` en `F` dat zijn.
    Successors { next: first, succ }
}

/// Een nieuwe iterator waarbij elk opeenvolgend item wordt berekend op basis van het voorgaande.
///
/// Deze `struct` is gemaakt door de [`iter::successors()`]-functie.
/// Zie de documentatie voor meer.
///
/// [`iter::successors()`]: successors
#[derive(Clone)]
#[stable(feature = "iter_successors", since = "1.34.0")]
pub struct Successors<T, F> {
    next: Option<T>,
    succ: F,
}

#[stable(feature = "iter_successors", since = "1.34.0")]
impl<T, F> Iterator for Successors<T, F>
where
    F: FnMut(&T) -> Option<T>,
{
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<Self::Item> {
        let item = self.next.take()?;
        self.next = (self.succ)(&item);
        Some(item)
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.next.is_some() { (1, None) } else { (0, Some(0)) }
    }
}

#[stable(feature = "iter_successors", since = "1.34.0")]
impl<T, F> FusedIterator for Successors<T, F> where F: FnMut(&T) -> Option<T> {}

#[stable(feature = "iter_successors", since = "1.34.0")]
impl<T: fmt::Debug, F> fmt::Debug for Successors<T, F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Successors").field("next", &self.next).finish()
    }
}