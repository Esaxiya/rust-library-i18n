use crate::iter::{FusedIterator, TrustedLen};

/// Creëert een iterator die een element precies één keer oplevert.
///
/// Dit wordt gewoonlijk gebruikt om een enkele waarde aan te passen aan een [`chain()`] van andere soorten iteratie.
/// Misschien heb je een iterator die bijna alles dekt, maar heb je een extra speciaal geval nodig.
/// Misschien heb je een functie die op iteratoren werkt, maar hoef je maar één waarde te verwerken.
///
/// [`chain()`]: Iterator::chain
///
/// # Examples
///
/// Basisgebruik:
///
/// ```
/// use std::iter;
///
/// // een is het eenzaamste nummer
/// let mut one = iter::once(1);
///
/// assert_eq!(Some(1), one.next());
///
/// // slechts één, dat is alles wat we krijgen
/// assert_eq!(None, one.next());
/// ```
///
/// Samen koppelen met een andere iterator.
/// Laten we zeggen dat we elk bestand van de `.foo`-directory willen herhalen, maar ook een configuratiebestand,
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // we moeten converteren van een iterator van DirEntry-s naar een iterator van PathBufs, dus we gebruiken map
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // nu onze iterator alleen voor ons configuratiebestand
/// let config = iter::once(PathBuf::from(".foorc"));
///
/// // keten de twee iteratoren aan elkaar tot één grote iterator
/// let files = dirs.chain(config);
///
/// // dit geeft ons alle bestanden in zowel .foo als .foorc
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
#[stable(feature = "iter_once", since = "1.2.0")]
pub fn once<T>(value: T) -> Once<T> {
    Once { inner: Some(value).into_iter() }
}

/// Een iterator die precies één keer een element oplevert.
///
/// Deze `struct` is gemaakt door de [`once()`]-functie.Zie de documentatie voor meer.
#[derive(Clone, Debug)]
#[stable(feature = "iter_once", since = "1.2.0")]
pub struct Once<T> {
    inner: crate::option::IntoIter<T>,
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> Iterator for Once<T> {
    type Item = T;

    fn next(&mut self) -> Option<T> {
        self.inner.next()
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> DoubleEndedIterator for Once<T> {
    fn next_back(&mut self) -> Option<T> {
        self.inner.next_back()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> ExactSizeIterator for Once<T> {
    fn len(&self) -> usize {
        self.inner.len()
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T> TrustedLen for Once<T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Once<T> {}