use crate::iter::{FusedIterator, TrustedLen};

/// Creëert een nieuwe iterator die elementen van het type `A` eindeloos herhaalt door de meegeleverde sluiting toe te passen, de repeater, `F: FnMut() -> A`.
///
/// De `repeat_with()`-functie roept de repeater keer op keer op.
///
/// Oneindige iteratoren zoals `repeat_with()` worden vaak gebruikt met adapters zoals [`Iterator::take()`], om ze eindig te maken.
///
/// Als het elementtype van de iterator dat je nodig hebt [`Clone`] implementeert, en het is OK om het bronelement in het geheugen te houden, zou je in plaats daarvan de functie [`repeat()`] moeten gebruiken.
///
///
/// Een iterator geproduceerd door `repeat_with()` is geen [`DoubleEndedIterator`].
/// Als je `repeat_with()` nodig hebt om een [`DoubleEndedIterator`] te retourneren, open dan een GitHub-probleem met een uitleg van je gebruiksscenario.
///
/// [`repeat()`]: crate::iter::repeat
/// [`DoubleEndedIterator`]: crate::iter::DoubleEndedIterator
///
/// # Examples
///
/// Basisgebruik:
///
/// ```
/// use std::iter;
///
/// // laten we aannemen dat we een waarde hebben van een type dat niet `Clone` is of die nog niet in het geheugen willen hebben omdat het duur is:
/////
/// #[derive(PartialEq, Debug)]
/// struct Expensive;
///
/// // een bepaalde waarde voor altijd:
/// let mut things = iter::repeat_with(|| Expensive);
///
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// ```
///
/// Mutatie gebruiken en eindig gaan:
///
/// ```rust
/// use std::iter;
///
/// // Van de nulde tot de derde macht van twee:
/// let mut curr = 1;
/// let mut pow2 = iter::repeat_with(|| { let tmp = curr; curr *= 2; tmp })
///                     .take(4);
///
/// assert_eq!(Some(1), pow2.next());
/// assert_eq!(Some(2), pow2.next());
/// assert_eq!(Some(4), pow2.next());
/// assert_eq!(Some(8), pow2.next());
///
/// // ... en nu zijn we klaar
/// assert_eq!(None, pow2.next());
/// ```
///
///
///
///
#[inline]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub fn repeat_with<A, F: FnMut() -> A>(repeater: F) -> RepeatWith<F> {
    RepeatWith { repeater }
}

/// Een iterator die elementen van het type `A` eindeloos herhaalt door de meegeleverde sluiting `F: FnMut() -> A` toe te passen.
///
///
/// Deze `struct` is gemaakt door de [`repeat_with()`]-functie.
/// Zie de documentatie voor meer.
#[derive(Copy, Clone, Debug)]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub struct RepeatWith<F> {
    repeater: F,
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> Iterator for RepeatWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some((self.repeater)())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> FusedIterator for RepeatWith<F> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A, F: FnMut() -> A> TrustedLen for RepeatWith<F> {}