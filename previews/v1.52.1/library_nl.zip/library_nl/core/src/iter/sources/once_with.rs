use crate::iter::{FusedIterator, TrustedLen};

/// Creëert een iterator die lui een waarde genereert, precies één keer door de verstrekte sluiting aan te roepen.
///
/// Dit wordt gewoonlijk gebruikt om een enkele waardegenerator aan te passen aan een [`chain()`] van andere soorten iteratie.
/// Misschien heb je een iterator die bijna alles dekt, maar heb je een extra speciaal geval nodig.
/// Misschien heb je een functie die op iteratoren werkt, maar hoef je maar één waarde te verwerken.
///
/// In tegenstelling tot [`once()`] zal deze functie de waarde lui op verzoek genereren.
///
/// [`chain()`]: Iterator::chain
/// [`once()`]: crate::iter::once
///
/// # Examples
///
/// Basisgebruik:
///
/// ```
/// use std::iter;
///
/// // een is het eenzaamste nummer
/// let mut one = iter::once_with(|| 1);
///
/// assert_eq!(Some(1), one.next());
///
/// // slechts één, dat is alles wat we krijgen
/// assert_eq!(None, one.next());
/// ```
///
/// Samen koppelen met een andere iterator.
/// Laten we zeggen dat we elk bestand van de `.foo`-directory willen herhalen, maar ook een configuratiebestand,
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // we moeten converteren van een iterator van DirEntry-s naar een iterator van PathBufs, dus we gebruiken map
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // nu onze iterator alleen voor ons configuratiebestand
/// let config = iter::once_with(|| PathBuf::from(".foorc"));
///
/// // keten de twee iteratoren aan elkaar tot één grote iterator
/// let files = dirs.chain(config);
///
/// // dit geeft ons alle bestanden in zowel .foo als .foorc
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
///
#[inline]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub fn once_with<A, F: FnOnce() -> A>(gen: F) -> OnceWith<F> {
    OnceWith { gen: Some(gen) }
}

/// Een iterator die een enkel element van het type `A` oplevert door de meegeleverde sluiting `F: FnOnce() -> A` toe te passen.
///
///
/// Deze `struct` is gemaakt door de [`once_with()`]-functie.
/// Zie de documentatie voor meer.
#[derive(Clone, Debug)]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub struct OnceWith<F> {
    gen: Option<F>,
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> Iterator for OnceWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        let f = self.gen.take()?;
        Some(f())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.gen.iter().size_hint()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> DoubleEndedIterator for OnceWith<F> {
    fn next_back(&mut self) -> Option<A> {
        self.next()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> ExactSizeIterator for OnceWith<F> {
    fn len(&self) -> usize {
        self.gen.iter().len()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> FusedIterator for OnceWith<F> {}

#[stable(feature = "iter_once_with", since = "1.43.0")]
unsafe impl<A, F: FnOnce() -> A> TrustedLen for OnceWith<F> {}