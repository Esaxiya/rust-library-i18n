use crate::iter::{InPlaceIterable, Iterator};
use crate::ops::{ControlFlow, Try};

mod chain;
mod cloned;
mod copied;
mod cycle;
mod enumerate;
mod filter;
mod filter_map;
mod flatten;
mod fuse;
mod inspect;
mod intersperse;
mod map;
mod map_while;
mod peekable;
mod rev;
mod scan;
mod skip;
mod skip_while;
mod step_by;
mod take;
mod take_while;
mod zip;

pub use self::{
    chain::Chain, cycle::Cycle, enumerate::Enumerate, filter::Filter, filter_map::FilterMap,
    flatten::FlatMap, fuse::Fuse, inspect::Inspect, map::Map, peekable::Peekable, rev::Rev,
    scan::Scan, skip::Skip, skip_while::SkipWhile, take::Take, take_while::TakeWhile, zip::Zip,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::cloned::Cloned;

#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::step_by::StepBy;

#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::flatten::Flatten;

#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::copied::Copied;

#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::intersperse::{Intersperse, IntersperseWith};

#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::map_while::MapWhile;

#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::zip::TrustedRandomAccess;

/// Deze trait biedt transitieve toegang tot het bronstadium in een interator-adapterpijplijn onder de voorwaarden dat
/// * de iteratorbron `S` implementeert zelf `SourceIter<Source = S>`
/// * er is een delegerende implementatie van deze trait voor elke adapter in de pijplijn tussen de bron en de pijplijnconsument.
///
/// Als de bron een iteratorstructuur is die eigenaar is (gewoonlijk `IntoIter` genoemd), kan dit handig zijn voor het specialiseren van [`FromIterator`]-implementaties of het herstellen van de resterende elementen nadat een iterator gedeeltelijk is uitgeput.
///
///
/// Merk op dat implementaties niet noodzakelijkerwijs toegang hoeven te bieden tot de binnenste bron van een pijplijn.Een stateful tussenadapter kan gretig een deel van de pijplijn evalueren en de interne opslag als bron blootleggen.
///
/// De trait is onveilig omdat uitvoerders extra veiligheidseigenschappen moeten handhaven.
/// Zie [`as_inner`] voor details.
///
/// # Examples
///
/// Een gedeeltelijk verbruikte bron ophalen:
///
/// ```
/// # #![feature(inplace_iteration)]
/// # use std::iter::SourceIter;
///
/// let mut iter = vec![9, 9, 9].into_iter().map(|i| i * i);
/// let _ = iter.next();
/// let mut remainder = std::mem::replace(unsafe { iter.as_inner() }, Vec::new().into_iter());
/// println!("n = {} elements remaining", remainder.len());
/// ```
///
/// [`FromIterator`]: crate::iter::FromIterator
/// [`as_inner`]: SourceIter::as_inner
///
///
///
///
///
#[unstable(issue = "none", feature = "inplace_iteration")]
pub unsafe trait SourceIter {
    /// Een bronstadium in een iteratorpijplijn.
    type Source: Iterator;

    /// Haal de bron op van een iteratorpijplijn.
    ///
    /// # Safety
    ///
    /// Implementaties van moeten dezelfde veranderlijke referentie gedurende hun levensduur retourneren, tenzij ze worden vervangen door een beller.
    /// Bellers mogen de referentie alleen vervangen als ze de iteratie hebben gestopt en de iterator-pijplijn verwijderen na het extraheren van de bron.
    ///
    /// Dit betekent dat iteratoradapters erop kunnen vertrouwen dat de bron niet verandert tijdens iteratie, maar dat ze er niet op kunnen vertrouwen in hun Drop-implementaties.
    ///
    /// Door deze methode te implementeren, geven adapters alleen privétoegang tot hun bron op en kunnen ze alleen vertrouwen op garanties die zijn gemaakt op basis van de typen ontvangers van de methode.
    /// Het gebrek aan beperkte toegang vereist ook dat adapters de openbare API van de bron moeten handhaven, zelfs als ze toegang hebben tot de interne onderdelen ervan.
    ///
    /// Bellers moeten op hun beurt verwachten dat de bron zich in een staat bevindt die consistent is met de openbare API, aangezien adapters die tussen de bron en de bron zitten dezelfde toegang hebben.
    /// In het bijzonder kan een adapter meer elementen hebben verbruikt dan strikt noodzakelijk.
    ///
    /// Het algemene doel van deze vereisten is om de consument van een pijpleiding gebruik te laten maken
    /// * wat er in de bron blijft nadat de iteratie is gestopt
    /// * het geheugen dat ongebruikt is geworden door het vooruitgaan van een consumerende iterator
    ///
    /// [`next()`]: Iterator::next()
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn as_inner(&mut self) -> &mut Self::Source;
}

/// Een iteratoradapter die uitvoer produceert zolang de onderliggende iterator `Result::Ok`-waarden produceert.
///
///
/// Als er een fout optreedt, stopt de iterator en wordt de fout opgeslagen.
///
pub(crate) struct ResultShunt<'a, I, E> {
    iter: I,
    error: &'a mut Result<(), E>,
}

/// Verwerk de gegeven iterator alsof het een `T` opleverde in plaats van een `Result<T, _>`.
/// Eventuele fouten zullen de innerlijke iterator stoppen en het algehele resultaat zal een fout zijn.
///
pub(crate) fn process_results<I, T, E, F, U>(iter: I, mut f: F) -> Result<U, E>
where
    I: Iterator<Item = Result<T, E>>,
    for<'a> F: FnMut(ResultShunt<'a, I, E>) -> U,
{
    let mut error = Ok(());
    let shunt = ResultShunt { iter, error: &mut error };
    let value = f(shunt);
    error.map(|()| value)
}

impl<I, T, E> Iterator for ResultShunt<'_, I, E>
where
    I: Iterator<Item = Result<T, E>>,
{
    type Item = T;

    fn next(&mut self) -> Option<Self::Item> {
        self.find(|_| true)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.error.is_err() {
            (0, Some(0))
        } else {
            let (_, upper) = self.iter.size_hint();
            (0, upper)
        }
    }

    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let error = &mut *self.error;
        self.iter
            .try_fold(init, |acc, x| match x {
                Ok(x) => ControlFlow::from_try(f(acc, x)),
                Err(e) => {
                    *error = Err(e);
                    ControlFlow::Break(try { acc })
                }
            })
            .into_try()
    }

    fn fold<B, F>(mut self, init: B, fold: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_fold(init, ok(fold)).unwrap()
    }
}