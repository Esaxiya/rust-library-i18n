use crate::{iter::FusedIterator, ops::Try};

/// Een iterator die zich eindeloos herhaalt.
///
/// Deze `struct` is gemaakt door de [`cycle`]-methode op [`Iterator`].
/// Zie de documentatie voor meer.
///
/// [`cycle`]: Iterator::cycle
/// [`Iterator`]: trait.Iterator.html
#[derive(Clone, Debug)]
#[must_use = "iterators are lazy and do nothing unless consumed"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Cycle<I> {
    orig: I,
    iter: I,
}

impl<I: Clone> Cycle<I> {
    pub(in crate::iter) fn new(iter: I) -> Cycle<I> {
        Cycle { orig: iter.clone(), iter }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> Iterator for Cycle<I>
where
    I: Clone + Iterator,
{
    type Item = <I as Iterator>::Item;

    #[inline]
    fn next(&mut self) -> Option<<I as Iterator>::Item> {
        match self.iter.next() {
            None => {
                self.iter = self.orig.clone();
                self.iter.next()
            }
            y => y,
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        // de cyclus-iterator is ofwel leeg of oneindig
        match self.orig.size_hint() {
            sz @ (0, Some(0)) => sz,
            (0, _) => (0, None),
            _ => (usize::MAX, None),
        }
    }

    #[inline]
    fn try_fold<Acc, F, R>(&mut self, mut acc: Acc, mut f: F) -> R
    where
        F: FnMut(Acc, Self::Item) -> R,
        R: Try<Ok = Acc>,
    {
        // herhaal de huidige iterator volledig.
        // dit is nodig omdat `self.iter` leeg kan zijn, zelfs als `self.orig` dat niet is
        acc = self.iter.try_fold(acc, &mut f)?;
        self.iter = self.orig.clone();

        // voltooi een volledige cyclus en houd bij of de gefietste iterator leeg is of niet.
        // we moeten vroeg terugkeren in het geval van een lege iterator om een oneindige lus te voorkomen
        //
        let mut is_empty = true;
        acc = self.iter.try_fold(acc, |acc, x| {
            is_empty = false;
            f(acc, x)
        })?;

        if is_empty {
            return try { acc };
        }

        loop {
            self.iter = self.orig.clone();
            acc = self.iter.try_fold(acc, &mut f)?;
        }
    }

    // Geen `fold`-overschrijving, omdat `fold` niet veel zin heeft voor `Cycle`, en we kunnen niets beters doen dan de standaardinstelling.
    //
}

#[stable(feature = "fused", since = "1.26.0")]
impl<I> FusedIterator for Cycle<I> where I: Clone + Iterator {}