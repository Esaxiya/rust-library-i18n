#![allow(missing_docs)]
#![unstable(feature = "raw", issue = "27751")]

//! Bevat struct-definities voor de lay-out van ingebouwde compilertypes.
//!
//! Ze kunnen worden gebruikt als doelen van transmuteert in onveilige code om de onbewerkte representaties rechtstreeks te manipuleren.
//!
//!
//! Hun definitie moet altijd overeenkomen met de ABI die is gedefinieerd in `rustc_middle::ty::layout`.
//!

/// De weergave van een trait-object zoals `&dyn SomeTrait`.
///
/// Deze structuur heeft dezelfde lay-out als typen zoals `&dyn SomeTrait` en `Box<dyn AnotherTrait>`.
///
/// `TraitObject` komt gegarandeerd overeen met lay-outs, maar het is niet het type trait-objecten (bijv. de velden zijn niet direct toegankelijk op een `&dyn SomeTrait`) noch heeft het controle over die lay-out (het veranderen van de definitie zal de lay-out van een `&dyn SomeTrait` niet wijzigen).
///
/// Het is alleen ontworpen om te worden gebruikt door onveilige code die de details op laag niveau moet manipuleren.
///
/// Er is geen manier om generiek naar alle trait-objecten te verwijzen, dus de enige manier om waarden van dit type te creëren is met functies zoals [`std::mem::transmute`][transmute].
/// Evenzo is de enige manier om een echt trait-object te maken op basis van een `TraitObject`-waarde, met `transmute`.
///
/// [transmute]: crate::intrinsics::transmute
///
/// Het synthetiseren van een trait-object met niet-overeenkomende typen-een waarbij de vtable niet overeenkomt met het type waarde waarnaar de gegevenspointer verwijst-leidt hoogstwaarschijnlijk tot ongedefinieerd gedrag.
///
/// # Examples
///
/// ```
/// #![feature(raw)]
///
/// use std::{mem, raw};
///
/// // een voorbeeld trait
/// trait Foo {
///     fn bar(&self) -> i32;
/// }
///
/// impl Foo for i32 {
///     fn bar(&self) -> i32 {
///          *self + 1
///     }
/// }
///
/// let value: i32 = 123;
///
/// // laat de compiler een trait-object maken
/// let object: &dyn Foo = &value;
///
/// // kijk naar de ruwe weergave
/// let raw_object: raw::TraitObject = unsafe { mem::transmute(object) };
///
/// // de data pointer is het adres van `value`
/// assert_eq!(raw_object.data as *const i32, &value as *const _);
///
/// let other_value: i32 = 456;
///
/// // construeer een nieuw object, wijzend naar een andere `i32`, en zorg ervoor dat u de `i32` vtable van `object` gebruikt
/////
/// let synthesized: &dyn Foo = unsafe {
///      mem::transmute(raw::TraitObject {
///          data: &other_value as *const _ as *mut (),
///          vtable: raw_object.vtable,
///      })
/// };
///
/// // het zou moeten werken alsof we rechtstreeks een trait-object uit `other_value` hadden geconstrueerd
/////
/// assert_eq!(synthesized.bar(), 457);
/// ```
///
///
///
///
///
///
///
///
///
#[repr(C)]
#[derive(Copy, Clone)]
#[allow(missing_debug_implementations)]
pub struct TraitObject {
    pub data: *mut (),
    pub vtable: *mut (),
}