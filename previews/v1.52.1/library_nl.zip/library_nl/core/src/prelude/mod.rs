//! De libcore prelude
//!
//! Deze module is bedoeld voor gebruikers van libcore die ook niet naar libstd linken.
//! Deze module wordt standaard geïmporteerd als `#![no_std]` op dezelfde manier wordt gebruikt als de prelude van de standaardbibliotheek.
//!

#![stable(feature = "core_prelude", since = "1.4.0")]

pub mod v1;

/// De 2015-versie van de kern prelude.
///
/// Zie de [module-level documentation](self) voor meer.
#[unstable(feature = "prelude_2015", issue = "none")]
pub mod rust_2015 {
    #[unstable(feature = "prelude_2015", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// De 2018-versie van de kern prelude.
///
/// Zie de [module-level documentation](self) voor meer.
#[unstable(feature = "prelude_2018", issue = "none")]
pub mod rust_2018 {
    #[unstable(feature = "prelude_2018", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// De 2021-versie van de kern prelude.
///
/// Zie de [module-level documentation](self) voor meer.
#[unstable(feature = "prelude_2021", issue = "none")]
pub mod rust_2021 {
    #[unstable(feature = "prelude_2021", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;

    // FIXME: Voeg meer dingen toe.
}