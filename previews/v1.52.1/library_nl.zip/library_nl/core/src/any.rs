//! Deze module implementeert de `Any` trait, die dynamisch typen van elk `'static`-type mogelijk maakt door middel van runtime-reflectie.
//!
//! `Any` zelf kan worden gebruikt om een `TypeId` te krijgen, en heeft meer mogelijkheden bij gebruik als een trait-object.
//! Als `&dyn Any` (een geleend trait-object), heeft het de `is`-en `downcast_ref`-methoden om te testen of de ingesloten waarde van een bepaald type is en om een verwijzing naar de innerlijke waarde als een type te krijgen.
//! Als `&mut dyn Any` is er ook de `downcast_mut`-methode om een veranderlijke verwijzing naar de innerlijke waarde te krijgen.
//! `Box<dyn Any>` voegt de `downcast`-methode toe, die probeert te converteren naar een `Box<T>`.
//! Zie de [`Box`]-documentatie voor de volledige details.
//!
//! Merk op dat `&dyn Any` beperkt is tot het testen of een waarde van een gespecificeerd concreet type is, en niet kan worden gebruikt om te testen of een type een trait implementeert.
//!
//! [`Box`]: ../../std/boxed/struct.Box.html
//!
//! # Slimme wijzers en `dyn Any`
//!
//! Een gedrag dat in gedachten moet worden gehouden bij het gebruik van `Any` als een trait-object, vooral met typen als `Box<dyn Any>` of `Arc<dyn Any>`, is dat het simpelweg aanroepen van `.type_id()` op de waarde de `TypeId` van de *container* produceert, niet het onderliggende trait-object.
//!
//! Dit kan worden vermeden door de slimme aanwijzer in plaats daarvan om te zetten in een `&dyn Any`, die de `TypeId` van het object retourneert.
//! Bijvoorbeeld:
//!
//! ```
//! use std::any::{Any, TypeId};
//!
//! let boxed: Box<dyn Any> = Box::new(3_i32);
//!
//! // Dit wil je waarschijnlijk eerder:
//! let actual_id = (&*boxed).type_id();
//! // ... dan dit:
//! let boxed_id = boxed.type_id();
//!
//! assert_eq!(actual_id, TypeId::of::<i32>());
//! assert_eq!(boxed_id, TypeId::of::<Box<dyn Any>>());
//! ```
//!
//! # Examples
//!
//! Beschouw een situatie waarin we een waarde willen uitloggen die aan een functie is doorgegeven.
//! We kennen de waarde waaraan we werken Debug implementeert, maar we kennen het concrete type niet.We willen bepaalde typen een speciale behandeling geven: in dit geval het afdrukken van de lengte van String-waarden voorafgaand aan hun waarde.
//! We kennen het concrete type van onze waarde niet tijdens het compileren, dus we moeten in plaats daarvan runtime-reflectie gebruiken.
//!
//! ```rust
//! use std::fmt::Debug;
//! use std::any::Any;
//!
//! // Logger-functie voor elk type dat Debug implementeert.
//! fn log<T: Any + Debug>(value: &T) {
//!     let value_any = value as &dyn Any;
//!
//!     // Probeer onze waarde om te zetten naar een `String`.
//!     // Als dit lukt, willen we zowel de lengte van de string als de waarde ervan uitvoeren.
//!     // Zo niet, dan is het een ander type: print het gewoon zonder opsmuk uit.
//!     match value_any.downcast_ref::<String>() {
//!         Some(as_string) => {
//!             println!("String ({}): {}", as_string.len(), as_string);
//!         }
//!         None => {
//!             println!("{:?}", value);
//!         }
//!     }
//! }
//!
//! // Deze functie wil zijn parameter uitloggen alvorens ermee te werken.
//! fn do_work<T: Any + Debug>(value: &T) {
//!     log(value);
//!     // ... doe wat ander werk
//! }
//!
//! fn main() {
//!     let my_string = "Hello World".to_string();
//!     do_work(&my_string);
//!
//!     let my_i8: i8 = 100;
//!     do_work(&my_i8);
//! }
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::intrinsics;

///////////////////////////////////////////////////////////////////////////////
// Elke trait
///////////////////////////////////////////////////////////////////////////////

/// Een trait om dynamisch typen te emuleren.
///
/// De meeste typen implementeren `Any`.Elk type dat een niet-'statische' referentie bevat, doet dat echter niet.
/// Zie de [module-level documentation][mod] voor meer details.
///
/// [mod]: crate::any
// Deze trait is niet onveilig, hoewel we vertrouwen op de specifieke kenmerken van zijn enige impl's `type_id`-functie in onveilige code (bijv. `downcast`).Normaal gesproken zou dat een probleem zijn, maar omdat de enige impl van `Any` een algemene implementatie is, kan geen enkele andere code `Any` implementeren.
//
// We zouden deze trait onveilig kunnen maken-het zou geen breuk veroorzaken, aangezien we alle implementaties controleren-maar we kiezen ervoor om dit niet te doen, omdat dat niet echt nodig is en gebruikers kan verwarren over het onderscheid tussen onveilige traits en onveilige methoden (bijv. `type_id` zou nog steeds veilig zijn om te bellen, maar we zouden dit waarschijnlijk in de documentatie willen aangeven).
//
//
//
//
//
//
//
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Any: 'static {
    /// Haalt de `TypeId` van `self`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string(s: &dyn Any) -> bool {
    ///     TypeId::of::<String>() == s.type_id()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "get_type_id", since = "1.34.0")]
    fn type_id(&self) -> TypeId;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: 'static + ?Sized> Any for T {
    fn type_id(&self) -> TypeId {
        TypeId::of::<T>()
    }
}

///////////////////////////////////////////////////////////////////////////////
// Uitbreidingsmethoden voor alle trait-objecten.
///////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

// Zorg ervoor dat het resultaat van bijvoorbeeld het samenvoegen van een draad kan worden afgedrukt en dus gebruikt met `unwrap`.
// Kan uiteindelijk niet meer nodig zijn als verzending werkt met upcasting.
//
#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any + Send {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

#[stable(feature = "any_send_sync_methods", since = "1.28.0")]
impl fmt::Debug for dyn Any + Send + Sync {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

impl dyn Any {
    /// Retourneert `true` als het omkaderde type hetzelfde is als `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &dyn Any) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        // Haal `TypeId` op van het type waarmee deze functie is geïnstantieerd.
        let t = TypeId::of::<T>();

        // Haal `TypeId` op van het type in het trait-object (`self`).
        let concrete = self.type_id();

        // Vergelijk beide `TypeId`s op gelijkheid.
        t == concrete
    }

    /// Retourneert een verwijzing naar de omkaderde waarde als deze van het type `T` is, of `None` als dat niet het geval is.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &dyn Any) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        if self.is::<T>() {
            // VEILIGHEID: even nagekeken of we naar het juiste type wijzen, en daar kunnen we op vertrouwen
            // die controleren op geheugenveiligheid omdat we Any voor alle typen hebben geïmplementeerd;er kunnen geen andere impls bestaan, aangezien ze in strijd zouden zijn met onze impl.
            //
            unsafe { Some(&*(self as *const dyn Any as *const T)) }
        } else {
            None
        }
    }

    /// Retourneert een veranderlijke verwijzing naar de omkaderde waarde als deze van het type `T` is, of `None` als dat niet het geval is.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut dyn Any) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        if self.is::<T>() {
            // VEILIGHEID: even nagekeken of we naar het juiste type wijzen, en daar kunnen we op vertrouwen
            // die controleren op geheugenveiligheid omdat we Any voor alle typen hebben geïmplementeerd;er kunnen geen andere impls bestaan, aangezien ze in strijd zouden zijn met onze impl.
            //
            unsafe { Some(&mut *(self as *mut dyn Any as *mut T)) }
        } else {
            None
        }
    }
}

impl dyn Any + Send {
    /// Stuurt door naar de methode die is gedefinieerd op het type `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// Stuurt door naar de methode die is gedefinieerd op het type `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// Stuurt door naar de methode die is gedefinieerd op het type `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

impl dyn Any + Send + Sync {
    /// Stuurt door naar de methode die is gedefinieerd op het type `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send + Sync)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// Stuurt door naar de methode die is gedefinieerd op het type `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send + Sync)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// Stuurt door naar de methode die is gedefinieerd op het type `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send + Sync)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

///////////////////////////////////////////////////////////////////////////////
// TypeID en zijn methoden
///////////////////////////////////////////////////////////////////////////////

/// Een `TypeId` vertegenwoordigt een wereldwijd unieke identificatie voor een type.
///
/// Elke `TypeId` is een ondoorzichtig object dat geen inspectie toelaat van wat erin zit, maar wel basisbewerkingen zoals klonen, vergelijken, afdrukken en weergeven.
///
///
/// Een `TypeId` is momenteel alleen beschikbaar voor typen die worden toegeschreven aan `'static`, maar deze beperking kan worden verwijderd in de future.
///
/// Hoewel `TypeId` `Hash`, `PartialOrd` en `Ord` implementeert, is het vermeldenswaard dat de hashes en volgorde tussen Rust-releases zal variëren.
/// Pas op dat u er niet op vertrouwt in uw code!
///
///
///
#[derive(Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Debug, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct TypeId {
    t: u64,
}

impl TypeId {
    /// Geeft de `TypeId` terug van het type waarmee deze generieke functie is geïnstantieerd.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string<T: ?Sized + Any>(_s: &T) -> bool {
    ///     TypeId::of::<String>() == TypeId::of::<T>()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub const fn of<T: ?Sized + 'static>() -> TypeId {
        TypeId { t: intrinsics::type_id::<T>() }
    }
}

/// Retourneert de naam van een type als een tekenreeks.
///
/// # Note
///
/// Dit is bedoeld voor diagnostisch gebruik.
/// De exacte inhoud en het formaat van de geretourneerde tekenreeks zijn niet gespecificeerd, behalve dat het een beste beschrijving van het type is.
/// Onder de strings die `type_name::<Option<String>>()` kan retourneren, zijn bijvoorbeeld `"Option<String>"` en `"std::option::Option<std::string::String>"`.
///
///
/// De geretourneerde tekenreeks mag niet worden beschouwd als een unieke identificatie van een type, aangezien meerdere typen kunnen worden toegewezen aan dezelfde typenaam.
/// Evenzo is er geen garantie dat alle delen van een type in de geretourneerde tekenreeks zullen voorkomen: levensduurspecificaties zijn bijvoorbeeld momenteel niet opgenomen.
/// Bovendien kan de uitvoer tussen versies van de compiler veranderen.
///
/// De huidige implementatie gebruikt dezelfde infrastructuur als compilerdiagnostiek en debuginfo, maar dit is niet gegarandeerd.
///
/// # Examples
///
/// ```rust
/// assert_eq!(
///     std::any::type_name::<Option<String>>(),
///     "core::option::Option<alloc::string::String>",
/// );
/// ```
///
///
///
///
#[stable(feature = "type_name", since = "1.38.0")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name<T: ?Sized>() -> &'static str {
    intrinsics::type_name::<T>()
}

/// Retourneert de naam van het type van de aangewezen waarde als een tekenreeks.
/// Dit is hetzelfde als `type_name::<T>()`, maar kan worden gebruikt als het type variabele niet gemakkelijk beschikbaar is.
///
/// # Note
///
/// Dit is bedoeld voor diagnostisch gebruik.De exacte inhoud en het formaat van de string worden niet gespecificeerd, behalve dat het een beste beschrijving van het type is.
/// `type_name_of_val::<Option<String>>(None)` kan bijvoorbeeld `"Option<String>"` of `"std::option::Option<std::string::String>"` retourneren, maar niet `"foobar"`.
///
/// Bovendien kan de uitvoer tussen versies van de compiler veranderen.
///
/// Deze functie lost trait-objecten niet op, wat betekent dat `type_name_of_val(&7u32 as &dyn Debug)` `"dyn Debug"` kan retourneren, maar niet `"u32"`.
///
/// De typenaam moet niet worden beschouwd als een unieke identificatie van een type;
/// meerdere typen kunnen dezelfde typenaam hebben.
///
/// De huidige implementatie gebruikt dezelfde infrastructuur als compilerdiagnostiek en debuginfo, maar dit is niet gegarandeerd.
///
/// # Examples
///
/// Drukt de standaard typen integer en float af.
///
/// ```rust
/// #![feature(type_name_of_val)]
/// use std::any::type_name_of_val;
///
/// let x = 1;
/// println!("{}", type_name_of_val(&x));
/// let y = 1.0;
/// println!("{}", type_name_of_val(&y));
/// ```
///
///
///
///
///
///
#[unstable(feature = "type_name_of_val", issue = "66359")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name_of_val<T: ?Sized>(_val: &T) -> &'static str {
    type_name::<T>()
}