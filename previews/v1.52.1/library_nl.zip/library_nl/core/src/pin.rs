//! Typen die gegevens vastzetten op hun locatie in het geheugen.
//!
//! Het is soms handig om objecten te hebben die gegarandeerd niet bewegen, in die zin dat hun plaatsing in het geheugen niet verandert en er dus op kan worden vertrouwd.
//! Een goed voorbeeld van een dergelijk scenario is het bouwen van zelfreferentiële structuren, aangezien het verplaatsen van een object met verwijzingen naar zichzelf deze ongeldig maakt, wat ongedefinieerd gedrag zou kunnen veroorzaken.
//!
//! Op een hoog niveau zorgt een [`Pin<P>`] ervoor dat de pointee van elk pointertype `P` een stabiele locatie in het geheugen heeft, wat betekent dat het niet ergens anders heen kan worden verplaatst en dat het geheugen niet kan worden vrijgemaakt totdat het wordt verwijderd.We zeggen dat de spits "pinned" is.Dingen worden subtieler bij het bespreken van typen die vastgezette met niet-vastgezette gegevens combineren;[see below](#projections-and-structural-pinning) voor meer details.
//!
//! Standaard zijn alle typen in Rust verplaatsbaar.
//! Met Rust kunnen alle typen op waarde worden doorgegeven, en met gewone smart-pointer-typen zoals [`Box<T>`] en `&mut T` kunnen de waarden die ze bevatten worden vervangen en verplaatst: u kunt een [`Box<T>`] verlaten of u kunt [`mem::swap`] gebruiken.
//! [`Pin<P>`] wikkelt een aanwijzer type `P`, dus [`Pin`]`<`[`Box`] `<T>>`functioneert als een gewone
//!
//! [`Box<T>`]: when een [`Pin`]`<`[`Box`] `<T>>`wordt verwijderd, evenals de inhoud ervan, en het geheugen krijgt
//!
//! toegewezen.Evenzo lijkt [`Pin`]`<&mut T>`veel op `&mut T`.Met [`Pin<P>`] kunnen clients echter niet daadwerkelijk een [`Box<T>`] of `&mut T` verkrijgen voor vastgezette gegevens, wat inhoudt dat u geen bewerkingen zoals [`mem::swap`] kunt gebruiken:
//!
//! ```
//! use std::pin::Pin;
//! fn swap_pins<T>(x: Pin<&mut T>, y: Pin<&mut T>) {
//!     // `mem::swap` heeft `&mut T` nodig, maar we kunnen het niet krijgen.
//!     // We zitten vast, we kunnen de inhoud van deze referenties niet ruilen.
//!     // We zouden `Pin::get_unchecked_mut` kunnen gebruiken, maar dat is niet voor niets onveilig:
//!     // we mogen het niet gebruiken om dingen uit de `Pin` te verplaatsen.
//! }
//! ```
//!
//! Het is de moeite waard om te herhalen dat [`Pin<P>`]*niets* verandert aan het feit dat een Rust-compiler alle typen als verplaatsbaar beschouwt.[`mem::swap`] blijft oproepbaar voor elke `T`.In plaats daarvan voorkomt [`Pin<P>`] dat bepaalde *waarden*(waarnaar wordt verwezen door aanwijzers verpakt in [`Pin<P>`]) worden verplaatst door het onmogelijk te maken om methoden aan te roepen waarvoor `&mut T` vereist is (zoals [`mem::swap`]).
//!
//! [`Pin<P>`] kan worden gebruikt om elk aanwijzertype `P` in te pakken, en als zodanig werkt het samen met [`Deref`] en [`DerefMut`].Een [`Pin<P>`] waarbij `P: Deref` moet worden beschouwd als een "`P`-style pointer" naar een vastgezette `P::Target`-dus een [`Pin`]`<`[`Box`] '<T>> `is een eigen pointer naar een vastgezette `T`, en een [` Pin`]`<`[`Rc`]`<T>> `is een referentie-getelde pointer naar een vastgezette `T`.
//! Voor correctheid vertrouwt [`Pin<P>`] op de implementaties van [`Deref`] en [`DerefMut`] om niet uit hun `self`-parameter te komen, en alleen om een pointer terug te sturen naar vastgezette gegevens wanneer ze worden aangeroepen op een vastgezette aanwijzer.
//!
//! # `Unpin`
//!
//! Veel typen zijn altijd vrij verplaatsbaar, zelfs als ze zijn vastgemaakt, omdat ze niet afhankelijk zijn van een stabiel adres.Dit omvat alle basistypen (zoals [`bool`], [`i32`] en referenties) evenals typen die uitsluitend uit deze typen bestaan.Typen die zich niets aantrekken van pinning, implementeren de [`Unpin`] auto-trait, die het effect van [`Pin<P>`] opheft.
//! Voor `T: Unpin`, [`Pin`]`<`[`Box`] `<T>>`en [`Box<T>`] werken identiek, net als [`Pin`] `<&mut T>` en `&mut T`.
//!
//! Merk op dat pinning en [`Unpin`] alleen het aangewezen type `P::Target` beïnvloeden, niet het aanwijzertype `P` zelf dat in [`Pin<P>`] is ingepakt.Of [`Box<T>`] bijvoorbeeld [`Unpin`] is of niet, heeft geen invloed op het gedrag van [`Pin`]`<`[`Box`] '<T>> `(hier is `T` het puntige type).
//!
//! # Voorbeeld: zelfreferentiële structuur
//!
//! Voordat we meer in detail treden om de garanties en keuzes in verband met `Pin<T>` uit te leggen, bespreken we enkele voorbeelden van hoe het kan worden gebruikt.
//! Voel je vrij om [skip to where the theoretical discussion continues](#drop-guarantee).
//!
//! ```rust
//! use std::pin::Pin;
//! use std::marker::PhantomPinned;
//! use std::ptr::NonNull;
//!
//! // Dit is een zelfreferentiële structuur omdat het segmentveld naar het dataveld verwijst.
//! // We kunnen de samensteller daarover niet informeren met een normale referentie, omdat dit patroon niet kan worden beschreven met de gebruikelijke leenregels.
//! //
//! // In plaats daarvan gebruiken we een onbewerkte aanwijzer, hoewel een aanwijzer waarvan bekend is dat deze niet nul is, omdat we weten dat deze naar de tekenreeks wijst.
//! //
//! struct Unmovable {
//!     data: String,
//!     slice: NonNull<String>,
//!     _pin: PhantomPinned,
//! }
//!
//! impl Unmovable {
//!     // Om ervoor te zorgen dat de gegevens niet worden verplaatst wanneer de functie terugkeert, plaatsen we ze in de heap waar ze zullen blijven gedurende de levensduur van het object, en de enige manier om er toegang toe te krijgen is via een wijzer ernaar.
//!     //
//!     //
//!     fn new(data: String) -> Pin<Box<Self>> {
//!         let res = Unmovable {
//!             data,
//!             // we maken de aanwijzer pas als de gegevens op hun plaats zijn, anders is deze al verplaatst voordat we zelfs maar begonnen zijn
//!             //
//!             slice: NonNull::dangling(),
//!             _pin: PhantomPinned,
//!         };
//!         let mut boxed = Box::pin(res);
//!
//!         let slice = NonNull::from(&boxed.data);
//!         // we weten dat dit veilig is omdat het wijzigen van een veld niet de hele structuur verplaatst
//!         unsafe {
//!             let mut_ref: Pin<&mut Self> = Pin::as_mut(&mut boxed);
//!             Pin::get_unchecked_mut(mut_ref).slice = slice;
//!         }
//!         boxed
//!     }
//! }
//!
//! let unmoved = Unmovable::new("hello".to_string());
//! // De aanwijzer moet naar de juiste locatie wijzen, zolang de structuur niet is verplaatst.
//! //
//! // Ondertussen zijn we vrij om de aanwijzer te verplaatsen.
//! # #[allow(unused_mut)]
//! let mut still_unmoved = unmoved;
//! assert_eq!(still_unmoved.slice, NonNull::from(&still_unmoved.data));
//!
//! // Omdat ons type Unpin niet implementeert, kan dit niet worden gecompileerd:
//! // let mut new_unmoved= Unmovable::new("world".to_string());
//! // std::mem::swap(&mut *still_unmoved, &mut *new_unmoved);
//! ```
//!
//! # Voorbeeld: opdringerige dubbel gelinkte lijst
//!
//! In een opdringerige dubbelgekoppelde lijst wijst de collectie eigenlijk niet het geheugen voor de elementen zelf toe.
//! De toewijzing wordt gecontroleerd door de klanten en elementen kunnen leven op een stapelframe dat korter meegaat dan de collectie.
//!
//! Om dit te laten werken, heeft elk element verwijzingen naar zijn voorganger en opvolger in de lijst.Elementen kunnen alleen worden toegevoegd als ze zijn vastgemaakt, omdat het verplaatsen van de elementen de aanwijzers ongeldig zou maken.Bovendien zal de [`Drop`]-implementatie van een gekoppeld lijstelement de verwijzingen van zijn voorganger en opvolger patchen om zichzelf van de lijst te verwijderen.
//!
//! Cruciaal is dat we erop moeten kunnen vertrouwen dat [`drop`] wordt gebeld.Als een element ongedaan gemaakt zou kunnen worden of anderszins ongeldig zou kunnen worden gemaakt zonder [`drop`] aan te roepen, zouden de verwijzingen ernaar van de aangrenzende elementen ongeldig worden, wat de datastructuur zou breken.
//!
//! Daarom wordt pinning ook geleverd met een ["drop"]-gerelateerde garantie.
//!
//! # `Drop` guarantee
//!
//! Het doel van pinning is om te kunnen vertrouwen op de plaatsing van sommige gegevens in het geheugen.
//! Om dit te laten werken, is niet alleen het verplaatsen van de gegevens beperkt;het ongedaan maken, herbestemmen of anderszins ongeldig maken van het geheugen dat wordt gebruikt om de gegevens op te slaan, is ook beperkt.
//! Concreet, voor vastgezette gegevens moet u de invariant handhaven dat *het geheugen niet ongeldig wordt gemaakt of opnieuw wordt gebruikt vanaf het moment dat het wordt vastgezet tot wanneer [`drop`] wordt aangeroepen*.Pas als [`drop`] terugkeert of panics, kan het geheugen worden hergebruikt.
//!
//! Geheugen kan "invalidated" zijn door de toewijzing te ongedaan maken, maar ook door een [`Some(v)`] te vervangen door [`None`], of [`Vec::set_len`] naar "kill" te bellen met een aantal elementen van een vector.Het kan worden hergebruikt door [`ptr::write`] te gebruiken om het te overschrijven zonder eerst de destructor te bellen.Niets van dit alles is toegestaan voor vastgezette gegevens zonder [`drop`] aan te roepen.
//!
//! Dit is precies het soort garantie dat de opdringerige gelinkte lijst uit de vorige sectie correct moet functioneren.
//!
//! Merk op dat deze garantie *niet* betekent dat geheugen niet lekt!Het is nog steeds helemaal oké om [`drop`] nooit aan te roepen op een vastgezet element (je kunt bijvoorbeeld nog steeds [`mem::forget`] aanroepen op een [`Pin`]`<`[`Box`] `<T>>`).In het voorbeeld van de dubbelgekoppelde lijst zou dat element gewoon in de lijst blijven staan.U mag de opslag *echter niet vrijgeven of hergebruiken zonder [`drop`]* te bellen.
//!
//! # `Drop` implementation
//!
//! Als uw type pinning gebruikt (zoals de twee bovenstaande voorbeelden), moet u voorzichtig zijn bij het implementeren van [`Drop`].De [`drop`]-functie accepteert `&mut self`, maar dit wordt *zelfs genoemd als uw type eerder was vastgezet*!Het is alsof de compiler automatisch [`Pin::get_unchecked_mut`] aanroept.
//!
//! Dit kan nooit een probleem veroorzaken in veilige code, omdat het implementeren van een type dat afhankelijk is van pinnen onveilige code vereist, maar houd er rekening mee dat het besluit om gebruik te maken van pinning in uw type (bijvoorbeeld door een bewerking uit te voeren op [`Pin`]`<&Self>`of [`Pin`] `<&mut Self>`) heeft ook gevolgen voor uw [`Drop`]-implementatie: als een element van uw type had kunnen worden vastgezet, moet u [`Drop`] behandelen als impliciet het nemen van [`Pin`]`<&mut Zelf>`.
//!
//!
//! U kunt `Drop` bijvoorbeeld als volgt implementeren:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # struct Type { }
//! impl Drop for Type {
//!     fn drop(&mut self) {
//!         // `new_unchecked` is oké omdat we weten dat deze waarde nooit meer wordt gebruikt nadat deze is verwijderd.
//!         //
//!         inner_drop(unsafe { Pin::new_unchecked(self)});
//!         fn inner_drop(this: Pin<&mut Type>) {
//!             // De werkelijke drop-code komt hier.
//!         }
//!     }
//! }
//! ```
//!
//! De functie `inner_drop` heeft het type dat [`drop`]*zou moeten* hebben, dus dit zorgt ervoor dat je `self`/`this` niet per ongeluk gebruikt op een manier die in strijd is met pinnen.
//!
//! Bovendien, als uw type `#[repr(packed)]` is, zal de compiler automatisch velden verplaatsen om ze te kunnen verwijderen.Het zou dat zelfs kunnen doen voor velden die toevallig voldoende op elkaar zijn afgestemd.Als gevolg hiervan kunt u pinning niet gebruiken met een `#[repr(packed)]`-type.
//!
//! # Projecties en structurele pinning
//!
//! Bij het werken met vastgezette structs, rijst de vraag hoe men toegang kan krijgen tot de velden van die struct in een methode die slechts [`Pin`]`<&mut Struct>`nodig heeft.
//! De gebruikelijke benadering is om hulpmethoden (zogenaamde *projecties*) te schrijven die [`Pin`]`<&mut Struct>`in een verwijzing naar het veld veranderen, maar welk type moet die verwijzing hebben?Is het [`Pin`]`<&mut Field>`of `&mut Field`?
//! Dezelfde vraag doet zich voor bij de velden van een `enum`, en ook bij het overwegen van container/wrapper-typen zoals [`Vec<T>`], [`Box<T>`] of [`RefCell<T>`].
//! (Deze vraag is van toepassing op zowel veranderlijke als gedeelde verwijzingen, we gebruiken hier alleen het meest voorkomende geval van veranderlijke verwijzingen ter illustratie.)
//!
//! Het blijkt dat het eigenlijk aan de auteur van de datastructuur is om te beslissen of de vastgezette projectie voor een bepaald veld [`Pin`]`<&mut Struct>`in [`Pin`] `<&mut Field> 'verandert of `&mut Field`.Er zijn echter enkele beperkingen, en de belangrijkste beperking is *consistentie*:
//! elk veld kan *ofwel* worden geprojecteerd op een vastgezette referentie,*of* hebben het vastzetten verwijderd als onderdeel van de projectie.
//! Als beide worden gedaan voor hetzelfde veld, is dat waarschijnlijk ondeugdelijk!
//!
//! Als auteur van een datastructuur mag u voor elk veld beslissen of u "propagates" aan dit veld vastzet of niet.
//! Vastzetten dat zich voortplant, wordt ook wel "structural" genoemd, omdat het de structuur van het type volgt.
//! In de volgende paragrafen beschrijven we de afwegingen die bij beide keuzes gemaakt moeten worden.
//!
//! ## Pinning *is niet* structureel voor `field`
//!
//! Het lijkt misschien contra-intuïtief dat het veld van een vastgezette structuur misschien niet is vastgezet, maar dat is eigenlijk de gemakkelijkste keuze: als er nooit een [`Pin`]`<&mut Field>`wordt gemaakt, kan er niets misgaan!Dus als u besluit dat een bepaald veld geen structurele pinning heeft, hoeft u er alleen maar voor te zorgen dat u nooit een vastgezette verwijzing naar dat veld maakt.
//!
//! Velden zonder structureel vastzetten kunnen een projectiemethode hebben die [`Pin`]`<&mut Struct>`in `&mut Field` verandert:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # type Field = i32;
//! # struct Struct { field: Field }
//! impl Struct {
//!     fn pin_get_field(self: Pin<&mut Self>) -> &mut Field {
//!         // Dit is oké, want `field` wordt nooit als vastgezet beschouwd.
//!         unsafe { &mut self.get_unchecked_mut().field }
//!     }
//! }
//! ```
//!
//! U kunt ook `impl Unpin for Struct`*gebruiken, zelfs als* het type `field` niet [`Unpin`] is.Wat dat type denkt over vastzetten is niet relevant als er nooit een [`Pin`]`<&mut Field>`wordt gemaakt.
//!
//! ## Pinning *is* structureel voor `field`
//!
//! De andere optie is om te beslissen dat pinning "structural" voor `field` is, wat betekent dat als de struct is vastgezet, het veld dat ook is.
//!
//! Dit maakt het mogelijk om een projectie te schrijven die een [`Pin`]`<&mut Field>`creëert, en daarmee getuigt dat het veld is vastgezet:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # type Field = i32;
//! # struct Struct { field: Field }
//! impl Struct {
//!     fn pin_get_field(self: Pin<&mut Self>) -> Pin<&mut Field> {
//!         // Dit is oké omdat `field` is vastgezet wanneer `self` is.
//!         unsafe { self.map_unchecked_mut(|s| &mut s.field) }
//!     }
//! }
//! ```
//!
//! Aan structureel vastzetten zijn echter een paar extra vereisten verbonden:
//!
//! 1. De struct mag alleen [`Unpin`] zijn als alle structurele velden [`Unpin`] zijn.Dit is de standaard, maar [`Unpin`] is een veilige trait, dus als auteur van de struct is het jouw verantwoordelijkheid *niet* om iets als `impl<T> Unpin for Struct<T>` toe te voegen.
//! (Merk op dat het toevoegen van een projectiebewerking onveilige code vereist, dus het feit dat [`Unpin`] een veilige trait is, verbreekt niet het principe dat u zich hier alleen zorgen over hoeft te maken als u `onveilig` gebruikt.)
//! 2. De destructor van de struct mag structurele velden niet uit zijn argumentatie halen.Dit is het exacte punt dat naar voren werd gebracht in de [previous section][drop-impl]: `drop` neemt `&mut self`, maar de struct (en dus zijn velden) is mogelijk eerder vastgezet.
//!     U moet garanderen dat u geen veld binnen uw [`Drop`]-implementatie verplaatst.
//!     In het bijzonder, zoals eerder uitgelegd, betekent dit dat uw struct *niet*`#[repr(packed)]` moet zijn.
//!     Zie dat gedeelte voor het schrijven van [`drop`] op een manier dat de compiler u kan helpen om niet per ongeluk pinning te verbreken.
//! 3. U moet ervoor zorgen dat u de [`Drop` guarantee][drop-guarantee] ondersteunt:
//!     Zodra uw structuur is vastgezet, wordt het geheugen dat de inhoud bevat niet overschreven of ongedaan gemaakt zonder de destructors van de inhoud op te roepen.
//!     Dit kan lastig zijn, zoals getuige van [`VecDeque<T>`]: de destructor van [`VecDeque<T>`] kan [`drop`] niet op alle elementen aanroepen als een van de destructors panics.Dit is in strijd met de [`Drop`]-garantie, omdat het ertoe kan leiden dat elementen ongedaan worden gemaakt zonder dat hun destructor wordt aangeroepen.([`VecDeque<T>`] heeft geen pinning-projecties, dus dit veroorzaakt geen ondeugdelijkheid.)
//! 4. U mag geen andere bewerkingen aanbieden die ertoe kunnen leiden dat gegevens uit de structurele velden worden verplaatst wanneer uw type is vastgemaakt.Als de struct bijvoorbeeld een [`Option<T>`] bevat en er is een 'take'-achtige bewerking met type `fn(Pin<&mut Struct<T>>) -> Option<T>`, kan die bewerking worden gebruikt om een `T` uit een vastgezette `Struct<T>` te verplaatsen-wat betekent dat vastzetten niet structureel kan zijn voor het veld dat dit bevat gegevens.
//!
//!     Voor een complexer voorbeeld van het verplaatsen van gegevens uit een vastgezet type, stel je voor dat [`RefCell<T>`] een methode `fn get_pin_mut(self: Pin<&mut Self>) -> Pin<&mut T>` had.
//!     Dan kunnen we het volgende doen:
//!
//!     ```compile_fail
//!     fn exploit_ref_cell<T>(rc: Pin<&mut RefCell<T>>) {
//!         { let p = rc.as_mut().get_pin_mut(); } // Here we get pinned access to the `T`.
//!         let rc_shr: &RefCell<T> = rc.into_ref().get_ref();
//!         let b = rc_shr.borrow_mut();
//!         let content = &mut *b; // And here we have `&mut T` to the same data.
//!     }
//!     ```
//!
//!     Dit is catastrofaal, het betekent dat we eerst de inhoud van de [`RefCell<T>`] kunnen vastpinnen (met behulp van `RefCell::get_pin_mut`) en die inhoud vervolgens kunnen verplaatsen met behulp van de veranderlijke referentie die we later hebben gekregen.
//!
//! ## Examples
//!
//! Voor een type als [`Vec<T>`] zijn beide mogelijkheden (structureel vastzetten of niet) zinvol.
//! Een [`Vec<T>`] met structureel vastzetten kan `get_pin`/`get_pin_mut`-methoden hebben om vastgezette verwijzingen naar elementen te krijgen.Het kon echter *niet* toestaan dat [`pop`][Vec::pop] wordt aangeroepen op een vastgezette [`Vec<T>`], omdat dat de (structureel vastgezette) inhoud zou verplaatsen!Evenmin kon het [`push`][Vec::push] toestaan, dat de inhoud opnieuw zou kunnen toewijzen en dus ook zou verplaatsen.
//!
//! Een [`Vec<T>`] zonder structureel vastzetten zou `impl<T> Unpin for Vec<T>` kunnen zijn, omdat de inhoud nooit wordt vastgezet en de [`Vec<T>`] zelf ook prima kan worden verplaatst.
//! Op dat moment heeft pinnen helemaal geen effect op de vector.
//!
//! In de standaardbibliotheek hebben aanwijzertypen over het algemeen geen structurele pinning, en dus bieden ze geen pinning-projecties.Dit is de reden waarom `Box<T>: Unpin` geldt voor alle `T`.
//! Het is logisch om dit te doen voor aanwijzertypes, omdat het verplaatsen van de `Box<T>` de `T` niet echt beweegt: de [`Box<T>`] kan vrij verplaatsbaar zijn (ook bekend als `Unpin`), zelfs als de `T` dat niet is.In feite zelfs [`Pin`]`<`[`Box`] `<T>>`en [`Pin`] `<&mut T>` zijn altijd [`Unpin`] zelf, om dezelfde reden: hun inhoud (de `T`) is vastgezet, maar de aanwijzers zelf kunnen worden verplaatst zonder de vastgezette gegevens te verplaatsen.
//! Voor zowel [`Box<T>`] als [`Pin`]`<`[`Box`] `<T>>`, of de inhoud is vastgezet, is volledig onafhankelijk van het feit of de aanwijzer is vastgezet, wat betekent dat vastzetten *niet* structureel is.
//!
//! Wanneer u een [`Future`]-combinator implementeert, heeft u meestal een structurele pinning nodig voor de geneste futures, omdat u hiernaar vastgezette verwijzingen moet krijgen om [`poll`] aan te roepen.
//! Maar als je combinator andere gegevens bevat die niet hoeven te worden vastgezet, kun je die velden niet structureel maken en er dus vrijelijk toegang toe krijgen met een veranderlijke referentie, zelfs als je gewoon [`Pin`]` <&mut Self> '(zoals zoals in uw eigen [`poll`]-implementatie).
//!
//! [`Deref`]: crate::ops::Deref
//! [`DerefMut`]: crate::ops::DerefMut
//! [`mem::swap`]: crate::mem::swap
//! [`mem::forget`]: crate::mem::forget
//! [`Box<T>`]: ../../std/boxed/struct.Box.html
//! [`Vec<T>`]: ../../std/vec/struct.Vec.html
//! [`Vec::set_len`]: ../../std/vec/struct.Vec.html#method.set_len
//! [`Box`]: ../../std/boxed/struct.Box.html
//! [Vec::pop]: ../../std/vec/struct.Vec.html#method.pop
//! [Vec::push]: ../../std/vec/struct.Vec.html#method.push
//! [`Rc`]: ../../std/rc/struct.Rc.html
//! [`RefCell<T>`]: crate::cell::RefCell
//! [`drop`]: Drop::drop
//! [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
//! [`Some(v)`]: Some
//! [`ptr::write`]: crate::ptr::write
//! [`Future`]: crate::future::Future
//! [drop-impl]: #drop-implementation
//! [drop-guarantee]: #drop-guarantee
//! [`poll`]: crate::future::Future::poll
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "pin", since = "1.33.0")]

use crate::cmp::{self, PartialEq, PartialOrd};
use crate::fmt;
use crate::hash::{Hash, Hasher};
use crate::marker::{Sized, Unpin};
use crate::ops::{CoerceUnsized, Deref, DerefMut, DispatchFromDyn, Receiver};

/// Een vastgezette aanwijzer.
///
/// Dit is een omhulsel rond een soort aanwijzer die ervoor zorgt dat de aanwijzer "pin" zijn waarde op zijn plaats krijgt, waardoor wordt voorkomen dat de waarde waarnaar wordt verwezen door die aanwijzer wordt verplaatst, tenzij het [`Unpin`] implementeert.
///
///
/// *Zie de [`pin` module]-documentatie voor uitleg over pinnen.*
///
/// [`pin` module]: self
///
// Note: de `Clone` hieronder afgeleid veroorzaakt ondeugdelijkheid zoals het mogelijk is om te implementeren
// `Clone` voor veranderlijke verwijzingen.
// Zie <https://internals.rust-lang.org/t/unsoundness-in-pin/11311> voor meer details.
#[stable(feature = "pin", since = "1.33.0")]
#[lang = "pin"]
#[fundamental]
#[repr(transparent)]
#[derive(Copy, Clone)]
pub struct Pin<P> {
    pointer: P,
}

// De volgende implementaties zijn niet afgeleid om geluidsproblemen te voorkomen.
// `&self.pointer` mag niet toegankelijk zijn voor niet-vertrouwde trait-implementaties.
//
// Zie <https://internals.rust-lang.org/t/unsoundness-in-pin/11311/73> voor meer details.
//

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref, Q: Deref> PartialEq<Pin<Q>> for Pin<P>
where
    P::Target: PartialEq<Q::Target>,
{
    fn eq(&self, other: &Pin<Q>) -> bool {
        P::Target::eq(self, other)
    }

    fn ne(&self, other: &Pin<Q>) -> bool {
        P::Target::ne(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Eq>> Eq for Pin<P> {}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref, Q: Deref> PartialOrd<Pin<Q>> for Pin<P>
where
    P::Target: PartialOrd<Q::Target>,
{
    fn partial_cmp(&self, other: &Pin<Q>) -> Option<cmp::Ordering> {
        P::Target::partial_cmp(self, other)
    }

    fn lt(&self, other: &Pin<Q>) -> bool {
        P::Target::lt(self, other)
    }

    fn le(&self, other: &Pin<Q>) -> bool {
        P::Target::le(self, other)
    }

    fn gt(&self, other: &Pin<Q>) -> bool {
        P::Target::gt(self, other)
    }

    fn ge(&self, other: &Pin<Q>) -> bool {
        P::Target::ge(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Ord>> Ord for Pin<P> {
    fn cmp(&self, other: &Self) -> cmp::Ordering {
        P::Target::cmp(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Hash>> Hash for Pin<P> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        P::Target::hash(self, state);
    }
}

impl<P: Deref<Target: Unpin>> Pin<P> {
    /// Construeer een nieuwe `Pin<P>` rond een pointer naar enkele gegevens van een type dat [`Unpin`] implementeert.
    ///
    /// In tegenstelling tot `Pin::new_unchecked` is deze methode veilig omdat de pointer `P` dereferenties naar een [`Unpin`]-type verwijst, waardoor de pinning-garanties worden geannuleerd.
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn new(pointer: P) -> Pin<P> {
        // VEILIGHEID: de waarde waarnaar wordt verwezen is `Unpin`, en heeft dus geen vereisten
        // rond pinnen.
        unsafe { Pin::new_unchecked(pointer) }
    }

    /// Pakt deze `Pin<P>` uit en retourneert de onderliggende pointer.
    ///
    /// Dit vereist dat de gegevens in deze `Pin` [`Unpin`] zijn, zodat we de pinning-invarianten kunnen negeren bij het uitpakken.
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin_into_inner", since = "1.39.0")]
    pub const fn into_inner(pin: Pin<P>) -> P {
        pin.pointer
    }
}

impl<P: Deref> Pin<P> {
    /// Construeer een nieuwe `Pin<P>` rond een verwijzing naar enkele gegevens van een type dat al dan niet `Unpin` implementeert.
    ///
    /// Als `pointer` verwijst naar een `Unpin`-type, moet in plaats daarvan `Pin::new` worden gebruikt.
    ///
    /// # Safety
    ///
    /// Deze constructor is onveilig omdat we niet kunnen garanderen dat de gegevens waarnaar door `pointer` wordt verwezen, worden vastgezet, wat betekent dat de gegevens niet worden verplaatst of dat de opslag ongeldig wordt totdat deze wordt verwijderd.
    /// Als de geconstrueerde `Pin<P>` niet garandeert dat de gegevens waarnaar `P` verwijst, vastgezet zijn, is dat een schending van het API-contract en kan dit leiden tot ongedefinieerd gedrag in latere (safe)-bewerkingen.
    ///
    /// Door deze methode te gebruiken, maakt u een promise over de `P::Deref`-en `P::DerefMut`-implementaties, als deze bestaan.
    /// Het belangrijkste is dat ze hun `self`-argumenten niet mogen verlaten: `Pin::as_mut` en `Pin::as_ref` zullen `DerefMut::deref_mut` en `Deref::deref`*aanroepen op de vastgezette pointer* en verwachten dat deze methoden de vastzetinvarianten handhaven.
    /// Bovendien, door deze methode aan te roepen promise dat de referentie `P` dereferenties naar niet meer zal worden verplaatst;in het bijzonder mag het niet mogelijk zijn om een `&mut P::Target` te verkrijgen en vervolgens uit die referentie te gaan (met bijvoorbeeld [`mem::swap`]).
    ///
    ///
    /// Het aanroepen van `Pin::new_unchecked` op een `&'a mut T` is bijvoorbeeld onveilig, want hoewel u het gedurende de gegeven levensduur `'a` kunt vastpinnen, heeft u geen controle over of het vastgehouden wordt zodra `'a` eindigt:
    ///
    /// ```
    /// use std::mem;
    /// use std::pin::Pin;
    ///
    /// fn move_pinned_ref<T>(mut a: T, mut b: T) {
    ///     unsafe {
    ///         let p: Pin<&mut T> = Pin::new_unchecked(&mut a);
    ///         // Dit zou moeten betekenen dat de pointee `a` nooit meer kan bewegen.
    ///     }
    ///     mem::swap(&mut a, &mut b);
    ///     // Het adres van `a` is veranderd in `b`'s stack slot, dus `a` is verplaatst, ook al hebben we het eerder vastgezet!We hebben het vastgezette API-contract geschonden.
    /////
    /// }
    /// ```
    ///
    /// Een waarde die eenmaal is vastgezet, moet voor altijd vast blijven staan (tenzij het type `Unpin` implementeert).
    ///
    /// Evenzo is het aanroepen van `Pin::new_unchecked` op een `Rc<T>` onveilig omdat er aliassen kunnen zijn voor dezelfde gegevens die niet onderhevig zijn aan de pinning-beperkingen:
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::pin::Pin;
    ///
    /// fn move_pinned_rc<T>(mut x: Rc<T>) {
    ///     let pinned = unsafe { Pin::new_unchecked(Rc::clone(&x)) };
    ///     {
    ///         let p: Pin<&T> = pinned.as_ref();
    ///         // Dit zou moeten betekenen dat de spits nooit meer kan bewegen.
    ///     }
    ///     drop(pinned);
    ///     let content = Rc::get_mut(&mut x).unwrap();
    ///     // Als `x` de enige referentie was, hebben we een veranderlijke verwijzing naar gegevens die we hierboven hebben vastgemaakt, die we zouden kunnen gebruiken om deze te verplaatsen zoals we in het vorige voorbeeld hebben gezien.
    ///     // We hebben het vastgezette API-contract geschonden.
    /////
    ///  }
    ///  ```
    ///
    /// [`mem::swap`]: crate::mem::swap
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[lang = "new_unchecked"]
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const unsafe fn new_unchecked(pointer: P) -> Pin<P> {
        Pin { pointer }
    }

    /// Haalt een vastgezette gedeelde referentie op van deze vastgezette aanwijzer.
    ///
    /// Dit is een generieke methode om van `&Pin<Pointer<T>>` naar `Pin<&T>` te gaan.
    /// Het is veilig omdat, als onderdeel van het contract van `Pin::new_unchecked`, de spits niet kan bewegen nadat `Pin<Pointer<T>>` is gemaakt.
    ///
    /// "Malicious" implementaties van `Pointer::Deref` worden eveneens uitgesloten door het contract van `Pin::new_unchecked`.
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn as_ref(&self) -> Pin<&P::Target> {
        // VEILIGHEID: zie documentatie over deze functie
        unsafe { Pin::new_unchecked(&*self.pointer) }
    }

    /// Pakt deze `Pin<P>` uit en retourneert de onderliggende pointer.
    ///
    /// # Safety
    ///
    /// Deze functie is onveilig.U moet garanderen dat u de pointer `P` als vastgezet blijft behandelen nadat u deze functie hebt aangeroepen, zodat de invarianten op het type `Pin` kunnen worden gehandhaafd.
    /// Als de code die de resulterende `P` gebruikt de pinning-invarianten niet blijft behouden, is dat een schending van het API-contract en kan dit leiden tot ongedefinieerd gedrag in latere (safe)-bewerkingen.
    ///
    ///
    /// Als de onderliggende gegevens [`Unpin`] zijn, moet in plaats daarvan [`Pin::into_inner`] worden gebruikt.
    ///
    ///
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin_into_inner", since = "1.39.0")]
    pub const unsafe fn into_inner_unchecked(pin: Pin<P>) -> P {
        pin.pointer
    }
}

impl<P: DerefMut> Pin<P> {
    /// Haalt een vastgezette, veranderlijke referentie op van deze vastgezette aanwijzer.
    ///
    /// Dit is een generieke methode om van `&mut Pin<Pointer<T>>` naar `Pin<&mut T>` te gaan.
    /// Het is veilig omdat, als onderdeel van het contract van `Pin::new_unchecked`, de spits niet kan bewegen nadat `Pin<Pointer<T>>` is gemaakt.
    ///
    /// "Malicious" implementaties van `Pointer::DerefMut` worden eveneens uitgesloten door het contract van `Pin::new_unchecked`.
    ///
    /// Deze methode is handig wanneer u meerdere aanroepen doet naar functies die het vastgezette type gebruiken.
    ///
    /// # Example
    ///
    /// ```
    /// use std::pin::Pin;
    ///
    /// # struct Type {}
    /// impl Type {
    ///     fn method(self: Pin<&mut Self>) {
    ///         // doe iets
    ///     }
    ///
    ///     fn call_method_twice(mut self: Pin<&mut Self>) {
    ///         // `method` verbruikt `self`, dus rebootmorgen de `Pin<&mut Self>` via `as_mut`.
    ///         self.as_mut().method();
    ///         self.as_mut().method();
    ///     }
    /// }
    /// ```
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn as_mut(&mut self) -> Pin<&mut P::Target> {
        // VEILIGHEID: zie documentatie over deze functie
        unsafe { Pin::new_unchecked(&mut *self.pointer) }
    }

    /// Wijst een nieuwe waarde toe aan het geheugen achter de vastgezette referentie.
    ///
    /// Hierdoor worden vastgezette gegevens overschreven, maar dat is oké: de destructor wordt uitgevoerd voordat deze wordt overschreven, dus geen garantie voor vastzetten wordt geschonden.
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn set(&mut self, value: P::Target)
    where
        P::Target: Sized,
    {
        *(self.pointer) = value;
    }
}

impl<'a, T: ?Sized> Pin<&'a T> {
    /// Construeert een nieuwe pin door de binnenwaarde in kaart te brengen.
    ///
    /// Als u bijvoorbeeld een `Pin` van een veld van iets wilt krijgen, kunt u dit gebruiken om toegang te krijgen tot dat veld in één regel code.
    /// Er zijn echter verschillende valstrikken bij deze "pinning projections";
    /// zie de [`pin` module]-documentatie voor meer details over dat onderwerp.
    ///
    /// # Safety
    ///
    /// Deze functie is onveilig.
    /// U moet garanderen dat de gegevens die u retourneert niet worden verplaatst zolang de argumentwaarde niet wordt verplaatst (bijvoorbeeld omdat het een van de velden met die waarde is), en ook dat u het argument dat u ontvangt niet verlaat de interieurfunctie.
    ///
    ///
    /// [`pin` module]: self#projections-and-structural-pinning
    ///
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    pub unsafe fn map_unchecked<U, F>(self, func: F) -> Pin<&'a U>
    where
        U: ?Sized,
        F: FnOnce(&T) -> &U,
    {
        let pointer = &*self.pointer;
        let new_pointer = func(pointer);

        // VEILIGHEID: het veiligheidscontract voor `new_unchecked` moet zijn
        // ondersteund door de beller.
        unsafe { Pin::new_unchecked(new_pointer) }
    }

    /// Haalt een gedeelde referentie uit een speld.
    ///
    /// Dit is veilig omdat het niet mogelijk is om uit een gedeelde referentie te gaan.
    /// Het lijkt misschien alsof er hier een probleem is met de interne veranderlijkheid: het *is* zelfs mogelijk om een `T` uit een `&RefCell<T>` te halen.
    /// Dit is echter geen probleem zolang er niet ook een `Pin<&T>` bestaat die naar dezelfde gegevens verwijst, en met `RefCell<T>` kunt u geen vastgezette verwijzing naar de inhoud maken.
    ///
    /// Zie de discussie over ["pinning projections"] voor meer details.
    ///
    /// Note: `Pin` implementeert ook `Deref` naar het doel, dat kan worden gebruikt om toegang te krijgen tot de innerlijke waarde.
    /// `Deref` biedt echter alleen een referentie die zo lang leeft als de lening van de `Pin`, niet de levensduur van de `Pin` zelf.
    /// Met deze methode kan de `Pin` worden omgezet in een referentie met dezelfde levensduur als de originele `Pin`.
    ///
    /// ["pinning projections"]: self#projections-and-structural-pinning
    ///
    ///
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn get_ref(self) -> &'a T {
        self.pointer
    }
}

impl<'a, T: ?Sized> Pin<&'a mut T> {
    /// Verandert deze `Pin<&mut T>` in een `Pin<&T>` met dezelfde levensduur.
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn into_ref(self) -> Pin<&'a T> {
        Pin { pointer: self.pointer }
    }

    /// Krijgt een veranderlijke verwijzing naar de gegevens in deze `Pin`.
    ///
    /// Dit vereist dat de gegevens in deze `Pin` `Unpin` zijn.
    ///
    /// Note: `Pin` implementeert ook `DerefMut` in de gegevens, die kunnen worden gebruikt om toegang te krijgen tot de innerlijke waarde.
    /// `DerefMut` biedt echter alleen een referentie die zo lang leeft als de lening van de `Pin`, niet de levensduur van de `Pin` zelf.
    ///
    /// Met deze methode kan de `Pin` worden omgezet in een referentie met dezelfde levensduur als de originele `Pin`.
    ///
    #[inline(always)]
    #[stable(feature = "pin", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn get_mut(self) -> &'a mut T
    where
        T: Unpin,
    {
        self.pointer
    }

    /// Krijgt een veranderlijke verwijzing naar de gegevens in deze `Pin`.
    ///
    /// # Safety
    ///
    /// Deze functie is onveilig.
    /// U moet garanderen dat u de gegevens nooit uit de veranderlijke referentie haalt die u ontvangt wanneer u deze functie aanroept, zodat de invarianten op het `Pin`-type kunnen worden gehandhaafd.
    ///
    ///
    /// Als de onderliggende gegevens `Unpin` zijn, moet in plaats daarvan `Pin::get_mut` worden gebruikt.
    ///
    #[inline(always)]
    #[stable(feature = "pin", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const unsafe fn get_unchecked_mut(self) -> &'a mut T {
        self.pointer
    }

    /// Construeer een nieuwe pin door de binnenwaarde in kaart te brengen.
    ///
    /// Als u bijvoorbeeld een `Pin` van een veld van iets wilt krijgen, kunt u dit gebruiken om toegang te krijgen tot dat veld in één regel code.
    /// Er zijn echter verschillende valstrikken bij deze "pinning projections";
    /// zie de [`pin` module]-documentatie voor meer details over dat onderwerp.
    ///
    /// # Safety
    ///
    /// Deze functie is onveilig.
    /// U moet garanderen dat de gegevens die u retourneert niet worden verplaatst zolang de argumentwaarde niet wordt verplaatst (bijvoorbeeld omdat het een van de velden met die waarde is), en ook dat u het argument dat u ontvangt niet verlaat de interieurfunctie.
    ///
    ///
    /// [`pin` module]: self#projections-and-structural-pinning
    ///
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    pub unsafe fn map_unchecked_mut<U, F>(self, func: F) -> Pin<&'a mut U>
    where
        U: ?Sized,
        F: FnOnce(&mut T) -> &mut U,
    {
        // VEILIGHEID: de beller is verantwoordelijk voor het niet verplaatsen van het
        // waarde uit deze referentie.
        let pointer = unsafe { Pin::get_unchecked_mut(self) };
        let new_pointer = func(pointer);
        // VEILIGHEID: omdat de waarde van `this` gegarandeerd niet heeft
        // is verhuisd, is deze oproep naar `new_unchecked` veilig.
        unsafe { Pin::new_unchecked(new_pointer) }
    }
}

impl<T: ?Sized> Pin<&'static T> {
    /// Haal een vastgezette referentie op van een statische referentie.
    ///
    /// Dit is veilig, omdat `T` wordt geleend voor de `'static`-levensduur, die nooit eindigt.
    ///
    #[unstable(feature = "pin_static_ref", issue = "78186")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn static_ref(r: &'static T) -> Pin<&'static T> {
        // VEILIGHEID: De 'statische lening garandeert dat de gegevens dat niet zullen zijn
        // moved/invalidated totdat het valt (wat nooit is).
        unsafe { Pin::new_unchecked(r) }
    }
}

impl<T: ?Sized> Pin<&'static mut T> {
    /// Haal een vastgezette veranderlijke referentie op van een statische veranderlijke referentie.
    ///
    /// Dit is veilig, omdat `T` wordt geleend voor de `'static`-levensduur, die nooit eindigt.
    ///
    #[unstable(feature = "pin_static_ref", issue = "78186")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn static_mut(r: &'static mut T) -> Pin<&'static mut T> {
        // VEILIGHEID: De 'statische lening garandeert dat de gegevens dat niet zullen zijn
        // moved/invalidated totdat het valt (wat nooit is).
        unsafe { Pin::new_unchecked(r) }
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: Deref> Deref for Pin<P> {
    type Target = P::Target;
    fn deref(&self) -> &P::Target {
        Pin::get_ref(Pin::as_ref(self))
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: DerefMut<Target: Unpin>> DerefMut for Pin<P> {
    fn deref_mut(&mut self) -> &mut P::Target {
        Pin::get_mut(Pin::as_mut(self))
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<P: Receiver> Receiver for Pin<P> {}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Debug> fmt::Debug for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.pointer, f)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Display> fmt::Display for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&self.pointer, f)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Pointer> fmt::Pointer for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.pointer, f)
    }
}

// Note: dit betekent dat elk impl van `CoerceUnsized` dat dwang van
// een type dat `Deref<Target=impl !Unpin>` impliceert naar een type dat impliceert dat `Deref<Target=Unpin>` ondeugdelijk is.
// Een dergelijk implic zou echter waarschijnlijk om andere redenen ondeugdelijk zijn, dus we moeten er alleen voor zorgen dat dergelijke implicaties niet in std terechtkomen.
//
//
#[stable(feature = "pin", since = "1.33.0")]
impl<P, U> CoerceUnsized<Pin<U>> for Pin<P> where P: CoerceUnsized<U> {}

#[stable(feature = "pin", since = "1.33.0")]
impl<P, U> DispatchFromDyn<Pin<U>> for Pin<P> where P: DispatchFromDyn<U> {}