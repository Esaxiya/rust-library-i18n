//! Primitieve traits en typen die basiseigenschappen van typen vertegenwoordigen.
//!
//! Rust-typen kunnen op verschillende handige manieren worden geclassificeerd op basis van hun intrinsieke eigenschappen.
//! Deze classificaties worden weergegeven als traits.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cell::UnsafeCell;
use crate::cmp;
use crate::fmt::Debug;
use crate::hash::Hash;
use crate::hash::Hasher;

/// Typen die over draadgrenzen heen kunnen worden overgedragen.
///
/// Deze trait wordt automatisch geïmplementeerd wanneer de compiler bepaalt dat deze geschikt is.
///
/// Een voorbeeld van een niet-'Verzenden'-type is de referentie-tel pointer [`rc::Rc`][`Rc`].
/// Als twee threads proberen om [`Rc`] s te klonen die naar dezelfde referentiewaarde verwijzen, kunnen ze proberen de referentietelling tegelijkertijd bij te werken, wat [undefined behavior][ub] is omdat [`Rc`] geen atomaire bewerkingen gebruikt.
///
/// Zijn neef [`sync::Arc`][arc] gebruikt atomaire bewerkingen (met enige overhead) en is dus `Send`.
///
/// Zie [the Nomicon](../../nomicon/send-and-sync.html) voor meer details.
///
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "send_trait")]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be sent between threads safely",
    label = "`{Self}` cannot be sent between threads safely"
)]
pub unsafe auto trait Send {
    // empty.
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *mut T {}

/// Typen met een constante grootte die bekend is tijdens het compileren.
///
/// Alle typeparameters hebben een impliciete grens van `Sized`.De speciale syntaxis `?Sized` kan worden gebruikt om deze binding te verwijderen als deze niet geschikt is.
///
/// ```
/// # #![allow(dead_code)]
/// struct Foo<T>(T);
/// struct Bar<T: ?Sized>(T);
///
/// // struct FooUse(Foo<[i32]>);//error: Sized is niet geïmplementeerd voor [i32]
/// struct BarUse(Bar<[i32]>); // OK
/// ```
///
/// De enige uitzondering is het impliciete `Self`-type van een trait.
/// Een trait heeft geen impliciete `Sized`-binding aangezien dit incompatibel is met [trait object] s waar de trait per definitie met alle mogelijke implementors moet werken, en dus elke grootte kan hebben.
///
///
/// Hoewel je met Rust `Sized` aan een trait kunt binden, kun je het later niet gebruiken om een trait-object te vormen:
///
/// ```
/// # #![allow(unused_variables)]
/// trait Foo { }
/// trait Bar: Sized { }
///
/// struct Impl;
/// impl Foo for Impl { }
/// impl Bar for Impl { }
///
/// let x: &dyn Foo = &Impl;    // OK
/// // laat y: &dyn Bar= &Impl;//fout: de trait `Bar` kan niet in een object worden gemaakt
/////
/// ```
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "sized"]
#[rustc_on_unimplemented(
    message = "the size for values of type `{Self}` cannot be known at compilation time",
    label = "doesn't have a size known at compile-time"
)]
#[fundamental] // bijvoorbeeld voor Default, wat vereist dat `[T]: !Default` evalueerbaar is
#[rustc_specialization_trait]
pub trait Sized {
    // Empty.
}

/// Typen die "unsized" kunnen zijn tot een type met dynamische afmetingen.
///
/// Het formaat van het array-type `[i8; 2]` implementeert bijvoorbeeld `Unsize<[i8]>` en `Unsize<dyn fmt::Debug>`.
///
/// Alle implementaties van `Unsize` worden automatisch geleverd door de compiler.
///
/// `Unsize` is geïmplementeerd voor:
///
/// - `[T; N]` is `Unsize<[T]>`
/// - `T` is `Unsize<dyn Trait>` wanneer `T: Trait`
/// - `Foo<..., T, ...>` is `Unsize<Foo<..., U, ...>>` als:
///   - `T: Unsize<U>`
///   - Foo is een struct
///   - Alleen het laatste veld van `Foo` heeft een type waarbij `T` betrokken is
///   - `T` maakt geen deel uit van het type van andere velden
///   - `Bar<T>: Unsize<Bar<U>>`, als het laatste veld van `Foo` het type `Bar<T>` heeft
///
/// `Unsize` wordt samen met [`ops::CoerceUnsized`] gebruikt om "user-defined"-containers zoals [`Rc`] typen met dynamische afmetingen te laten bevatten.
/// Zie de [DST coercion RFC][RFC982] en [the nomicon entry on coercion][nomicon-coerce] voor meer details.
///
/// [`ops::CoerceUnsized`]: crate::ops::CoerceUnsized
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [RFC982]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
#[unstable(feature = "unsize", issue = "27732")]
#[lang = "unsize"]
pub trait Unsize<T: ?Sized> {
    // Empty.
}

/// Vereiste trait voor constanten die worden gebruikt in patroonovereenkomsten.
///
/// Elk type dat `PartialEq` afleidt, implementeert automatisch deze trait,*ongeacht* of de typeparameters `Eq` implementeren.
///
/// Als een `const`-item een type bevat dat deze trait niet implementeert, dan implementeert dat type (1.) `PartialEq` niet (wat betekent dat de constante die vergelijkingsmethode niet biedt, waarvan de codegeneratie aanneemt dat deze beschikbaar is), of (2.) implementeert het *zijn eigen* versie van `PartialEq` (waarvan we aannemen dat deze niet overeenkomt met een structurele gelijkheidsvergelijking).
///
///
/// In elk van de twee bovenstaande scenario's weigeren we het gebruik van een dergelijke constante in een patroonovereenkomst.
///
/// Zie ook de [structural match RFC][RFC1445] en [issue 63438] die motiveerden om van op attributen gebaseerd ontwerp naar deze trait te migreren.
///
/// [RFC1445]: https://github.com/rust-lang/rfcs/blob/master/text/1445-restrict-constants-in-patterns.md
/// [issue 63438]: https://github.com/rust-lang/rust/issues/63438
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(PartialEq)]`")]
#[lang = "structural_peq"]
pub trait StructuralPartialEq {
    // Empty.
}

/// Vereiste trait voor constanten die worden gebruikt in patroonovereenkomsten.
///
/// Elk type dat `Eq` afleidt, implementeert automatisch deze trait,*ongeacht* of de typeparameters `Eq` implementeren.
///
/// Dit is een hack om een beperking in ons type systeem te omzeilen.
///
/// # Background
///
/// We willen eisen dat typen consts die in patroonovereenkomsten worden gebruikt, het attribuut `#[derive(PartialEq, Eq)]` hebben.
///
/// In een meer ideale wereld zouden we die vereiste kunnen controleren door te controleren of het gegeven type zowel de `StructuralPartialEq` trait *als* de `Eq` trait implementeert.
/// U kunt echter ADT's hebben die *doen*`derive(PartialEq, Eq)`, en een geval zijn waarvan we willen dat de compiler deze accepteert, en toch slaagt het type van de constante er niet in om `Eq` te implementeren.
///
/// Namelijk een geval als dit:
///
/// ```rust
/// #[derive(PartialEq, Eq)]
/// struct Wrap<X>(X);
///
/// fn higher_order(_: &()) { }
///
/// const CFN: Wrap<fn(&())> = Wrap(higher_order);
///
/// fn main() {
///     match CFN {
///         CFN => {}
///         _ => {}
///     }
/// }
/// ```
///
/// (Het probleem in de bovenstaande code is dat `Wrap<fn(&())>` `PartialEq`, noch `Eq` implementeert, omdat 'for <' a> fn(&'a _)` does not implement those traits.)
///
/// Daarom kunnen we niet vertrouwen op een naïeve controle voor `StructuralPartialEq` en alleen voor `Eq`.
///
/// Als een hack om dit te omzeilen, gebruiken we twee afzonderlijke traits die door elk van de twee afgeleide (`#[derive(PartialEq)]` en `#[derive(Eq)]`) worden geïnjecteerd en controleren of beide aanwezig zijn als onderdeel van de structurele matchcontrole.
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(Eq)]`")]
#[lang = "structural_teq"]
pub trait StructuralEq {
    // Empty.
}

/// Typen waarvan de waarden eenvoudig kunnen worden gedupliceerd door bits te kopiëren.
///
/// Variabele bindingen hebben standaard 'verplaatsingssemantiek'.Met andere woorden:
///
/// ```
/// #[derive(Debug)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `x` is verhuisd naar `y`, en kan dus niet worden gebruikt
///
/// // println! ("{: ?}", x);//fout: gebruik van verplaatste waarde
/// ```
///
/// Als een type echter `Copy` implementeert, heeft het in plaats daarvan 'semantiek kopiëren':
///
/// ```
/// // We kunnen een `Copy`-implementatie afleiden.
/// // `Clone` is ook vereist, aangezien het een supertraps van `Copy` is.
/// #[derive(Debug, Copy, Clone)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `y` is een kopie van `x`
///
/// println!("{:?}", x); // A-OK!
/// ```
///
/// Het is belangrijk op te merken dat in deze twee voorbeelden het enige verschil is of je na de toewijzing toegang hebt tot `x`.
/// Onder de motorkap kunnen zowel een kopie als een verplaatsing ertoe leiden dat bits in het geheugen worden gekopieerd, hoewel dit soms wordt geoptimaliseerd.
///
/// ## Hoe kan ik `Copy` implementeren?
///
/// Er zijn twee manieren om `Copy` op uw type te implementeren.De eenvoudigste is om `derive` te gebruiken:
///
/// ```
/// #[derive(Copy, Clone)]
/// struct MyStruct;
/// ```
///
/// U kunt `Copy` en `Clone` ook handmatig implementeren:
///
/// ```
/// struct MyStruct;
///
/// impl Copy for MyStruct { }
///
/// impl Clone for MyStruct {
///     fn clone(&self) -> MyStruct {
///         *self
///     }
/// }
/// ```
///
/// Er is een klein verschil tussen de twee: de `derive`-strategie plaatst ook een `Copy` gebonden aan typeparameters, wat niet altijd gewenst is.
///
/// ## Wat is het verschil tussen `Copy` en `Clone`?
///
/// Kopieën gebeuren impliciet, bijvoorbeeld als onderdeel van een toewijzing `y = x`.Het gedrag van `Copy` is niet overbelast;het is altijd een simpele bitgewijze kopie.
///
/// Klonen is een expliciete actie, `x.clone()`.De implementatie van [`Clone`] kan elk typespecifiek gedrag bieden dat nodig is om waarden veilig te dupliceren.
/// De implementatie van [`Clone`] voor [`String`] moet bijvoorbeeld de buffer voor de tekenreeks naar de heap kopiëren.
/// Een eenvoudige bitsgewijze kopie van [`String`]-waarden zou alleen de pointer kopiëren, wat leidt tot een dubbele vrije regel.
/// Om deze reden is [`String`] [`Clone`] maar niet `Copy`.
///
/// [`Clone`] is een superieur van `Copy`, dus alles wat `Copy` is, moet ook [`Clone`] implementeren.
/// Als een type `Copy` is, hoeft de [`Clone`]-implementatie alleen `*self` te retourneren (zie het voorbeeld hierboven).
///
/// ## Wanneer kan mijn type `Copy` zijn?
///
/// Een type kan `Copy` implementeren als alle componenten `Copy` implementeren.Deze structuur kan bijvoorbeeld `Copy` zijn:
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Copy, Clone)]
/// struct Point {
///    x: i32,
///    y: i32,
/// }
/// ```
///
/// Een struct kan `Copy` zijn en [`i32`] is `Copy`, daarom komt `Point` in aanmerking om `Copy` te zijn.
/// Overweeg daarentegen
///
/// ```
/// # #![allow(dead_code)]
/// # struct Point;
/// struct PointList {
///     points: Vec<Point>,
/// }
/// ```
///
/// De struct `PointList` kan `Copy` niet implementeren, omdat [`Vec<T>`] geen `Copy` is.Als we proberen een `Copy`-implementatie af te leiden, krijgen we een foutmelding:
///
/// ```text
/// the trait `Copy` may not be implemented for this type; field `points` does not implement `Copy`
/// ```
///
/// Gedeelde referenties (`&T`) zijn ook `Copy`, dus een type kan `Copy` zijn, zelfs als het gedeelde referenties bevat van typen `T` die *niet*`Copy` zijn.
/// Beschouw de volgende structuur, die `Copy` kan implementeren, omdat het alleen een *gedeelde referentie* bevat naar ons niet-`Kopieer` type `PointList` van bovenaf:
///
/// ```
/// # #![allow(dead_code)]
/// # struct PointList;
/// #[derive(Copy, Clone)]
/// struct PointListWrapper<'a> {
///     point_list_ref: &'a PointList,
/// }
/// ```
///
/// ## Wanneer *kan* mijn type niet `Copy` zijn?
///
/// Sommige typen kunnen niet veilig worden gekopieerd.Het kopiëren van `&mut T` zou bijvoorbeeld een alias veranderlijke referentie creëren.
/// Het kopiëren van [`String`] zou de verantwoordelijkheid voor het beheren van de buffer van de [`String`] dupliceren, wat leidt tot een dubbele gratis.
///
/// Om het laatste geval te generaliseren, kan elk type dat [`Drop`] implementeert, geen `Copy` zijn, omdat het een bron beheert naast zijn eigen [`size_of::<T>`]-bytes.
///
/// Als je `Copy` probeert te implementeren op een struct of enum die niet-`Copy` gegevens bevat, krijg je de fout [E0204].
///
/// [E0204]: ../../error-index.html#E0204
///
/// ## Wanneer *moet* mijn type `Copy` zijn?
///
/// Over het algemeen geldt dat als uw type _can_ `Copy` implementeert, dit zou moeten.
/// Houd er echter rekening mee dat het implementeren van `Copy` deel uitmaakt van de openbare API van uw type.
/// Als het type in de future niet-`Copy` zou kunnen worden, kan het verstandig zijn om de `Copy`-implementatie nu weg te laten, om een verbroken API-wijziging te voorkomen.
///
/// ## Extra uitvoerders
///
/// Naast de [implementors listed below][impls] implementeren de volgende typen ook `Copy`:
///
/// * Functie-itemtypen (dwz de verschillende typen die voor elke functie zijn gedefinieerd)
/// * Functieaanwijzertypen (bijv. `fn() -> i32`)
/// * Array-typen, voor alle formaten, als het itemtype ook `Copy` implementeert (bijvoorbeeld `[i32; 123456]`)
/// * Tuple-typen, als elke component ook `Copy` implementeert (bijv.`()`, `(i32, bool)`)
/// * Sluitingstypen, als ze geen waarde uit de omgeving halen of als al dergelijke vastgelegde waarden `Copy` zelf implementeren.
///   Merk op dat variabelen die zijn vastgelegd door gedeelde referentie altijd `Copy` implementeren (zelfs als de referent dat niet doet), terwijl variabelen die zijn vastgelegd door veranderlijke referentie nooit `Copy` implementeren.
///
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
/// [`String`]: ../../std/string/struct.String.html
/// [`size_of::<T>`]: crate::mem::size_of
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "copy"]
// FIXME(matthewjasper) Hierdoor kan een type worden gekopieerd dat `Copy` niet implementeert vanwege onbevredigde levenslange grenzen (`A<'_>` kopiëren wanneer alleen `A<'static>: Copy` en `A<'_>: Clone`).
// We hebben dit attribuut hier voorlopig alleen omdat er nogal wat bestaande specialisaties op `Copy` zijn die al bestaan in de standaardbibliotheek, en er is geen manier om dit gedrag nu veilig te hebben.
//
//
//
//
#[rustc_unsafe_specialization_marker]
pub trait Copy: Clone {
    // Empty.
}

/// Leid een macro af die een impl van de trait `Copy` genereert.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Copy($item:item) {
    /* compiler built-in */
}

/// Typen waarvoor het veilig is om verwijzingen tussen threads te delen.
///
/// Deze trait wordt automatisch geïmplementeerd wanneer de compiler bepaalt dat deze geschikt is.
///
/// De precieze definitie is: een type `T` is [`Sync`] als en slechts als `&T` [`Send`] is.
/// Met andere woorden, als er geen mogelijkheid is van [undefined behavior][ub] (inclusief dataraces) bij het doorgeven van `&T`-referenties tussen threads.
///
/// Zoals je zou verwachten, zijn primitieve typen zoals [`u8`] en [`f64`] allemaal [`Sync`], en dat geldt ook voor eenvoudige geaggregeerde typen die ze bevatten, zoals tuples, structs en enums.
/// Meer voorbeelden van basistypen [`Sync`] zijn "immutable"-typen zoals `&T` en die met eenvoudige erfelijke veranderlijkheid, zoals [`Box<T>`][box], [`Vec<T>`][vec] en de meeste andere soorten verzamelingen.
///
/// (Generieke parameters moeten [`Sync`] zijn om hun container [`Sync`] te laten zijn.)
///
/// Een ietwat verrassende consequentie van de definitie is dat `&mut T` `Sync` is (als `T` `Sync` is), ook al lijkt het erop dat dit een niet-gesynchroniseerde mutatie kan opleveren.
/// De truc is dat een veranderlijke referentie achter een gedeelde referentie (dat wil zeggen, `& &mut T`) alleen-lezen wordt, alsof het een `& &T` is.
/// Er is dus geen risico op een datarace.
///
/// Typen die geen `Sync` zijn, zijn die met "interior mutability" in een niet-thread-veilige vorm, zoals [`Cell`][cell] en [`RefCell`][refcell].
/// Deze typen maken mutatie van hun inhoud mogelijk, zelfs via een onveranderlijke, gedeelde referentie.
/// De `set`-methode op [`Cell<T>`][cell] neemt bijvoorbeeld `&self`, dus het vereist alleen een gedeelde referentie [`&Cell<T>`][cell].
/// De methode voert geen synchronisatie uit, dus [`Cell`][cell] kan geen `Sync` zijn.
///
/// Een ander voorbeeld van een niet-`Sync` type is de referentie-tel pointer [`Rc`][rc].
/// Gegeven een referentie [`&Rc<T>`][rc], kunt u een nieuwe [`Rc<T>`][rc] klonen, waarbij u de referentietellingen op een niet-atomaire manier wijzigt.
///
/// Voor gevallen waarin een draadveilige interne mutabiliteit nodig is, biedt Rust [atomic data types], evenals expliciete vergrendeling via [`sync::Mutex`][mutex] en [`sync::RwLock`][rwlock].
/// Deze typen zorgen ervoor dat elke mutatie geen dataraces kan veroorzaken, daarom zijn de typen `Sync`.
/// Evenzo biedt [`sync::Arc`][arc] een threadveilige analoog van [`Rc`][rc].
///
/// Alle typen met interne veranderlijkheid moeten ook de [`cell::UnsafeCell`][unsafecell]-wrapper rond de value(s) gebruiken die kan worden gemuteerd via een gedeelde referentie.
/// Als u dit niet doet, is [undefined behavior][ub].
/// Bijvoorbeeld, [`transmute`][transmute]-ing van `&T` naar `&mut T` is ongeldig.
///
/// Zie [the Nomicon][nomicon-send-and-sync] voor meer details over `Sync`.
///
/// [box]: ../../std/boxed/struct.Box.html
/// [vec]: ../../std/vec/struct.Vec.html
/// [cell]: crate::cell::Cell
/// [refcell]: crate::cell::RefCell
/// [rc]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [atomic data types]: crate::sync::atomic
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [unsafecell]: crate::cell::UnsafeCell
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [transmute]: crate::mem::transmute
/// [nomicon-send-and-sync]: ../../nomicon/send-and-sync.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "sync_trait")]
#[lang = "sync"]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be shared between threads safely",
    label = "`{Self}` cannot be shared between threads safely"
)]
pub unsafe auto trait Sync {
    // FIXME(estebank): zodra de ondersteuning voor het toevoegen van notities in `rustc_on_unimplemented` in bèta belandt, en het is uitgebreid om te controleren of er ergens in de vereiste keten een sluiting is, verleng deze dan als zodanig (#48534):
    //
    //
    // ```
    // on(
    //     closure,
    //     note="`{Self}` cannot be shared safely, consider marking the closure `move`"
    // ),
    // ```

    // Empty
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *mut T {}

macro_rules! impls {
    ($t: ident) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Hash for $t<T> {
            #[inline]
            fn hash<H: Hasher>(&self, _: &mut H) {}
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialEq for $t<T> {
            fn eq(&self, _other: &$t<T>) -> bool {
                true
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Eq for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialOrd for $t<T> {
            fn partial_cmp(&self, _other: &$t<T>) -> Option<cmp::Ordering> {
                Option::Some(cmp::Ordering::Equal)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Ord for $t<T> {
            fn cmp(&self, _other: &$t<T>) -> cmp::Ordering {
                cmp::Ordering::Equal
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Copy for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Clone for $t<T> {
            fn clone(&self) -> Self {
                Self
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Default for $t<T> {
            fn default() -> Self {
                Self
            }
        }

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralPartialEq for $t<T> {}

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralEq for $t<T> {}
    };
}

/// Zero-size type gebruikt om dingen te markeren die "act like" ze bezitten een `T`.
///
/// Door een `PhantomData<T>`-veld aan uw type toe te voegen, vertelt de compiler dat uw type zich gedraagt alsof het een waarde van het type `T` opslaat, ook al is dat niet echt zo.
/// Deze informatie wordt gebruikt bij het berekenen van bepaalde veiligheidseigenschappen.
///
/// Zie [the Nomicon](../../nomicon/phantom-data.html) voor een meer diepgaande uitleg over het gebruik van `PhantomData<T>`.
///
/// # Een akelige opmerking 👻👻👻
///
/// Hoewel ze allebei enge namen hebben, zijn `PhantomData` en 'fantoomtypen' gerelateerd, maar niet identiek.Een fantoomtypeparameter is gewoon een typeparameter die nooit wordt gebruikt.
/// In Rust zorgt dit er vaak voor dat de compiler klaagt, en de oplossing is om een "dummy"-gebruik toe te voegen via `PhantomData`.
///
/// # Examples
///
/// ## Ongebruikte levensduurparameters
///
/// Misschien wel de meest voorkomende use-case voor `PhantomData` is een struct met een ongebruikte levensduurparameter, meestal als onderdeel van een onveilige code.
/// Hier is bijvoorbeeld een struct `Slice` met twee aanwijzers van het type `*const T`, die vermoedelijk ergens naar een array wijzen:
///
/// ```compile_fail,E0392
/// struct Slice<'a, T> {
///     start: *const T,
///     end: *const T,
/// }
/// ```
///
/// Het is de bedoeling dat de onderliggende data alleen geldig is voor de levensduur `'a`, dus `Slice` mag `'a` niet overleven.
/// Deze intentie komt echter niet tot uiting in de code, aangezien de levensduur `'a` niet wordt gebruikt en het daarom niet duidelijk is op welke gegevens het van toepassing is.
/// We kunnen dit corrigeren door de compiler te vertellen om *te handelen alsof* de `Slice`-structuur een referentie `&'a T` bevat:
///
/// ```
/// use std::marker::PhantomData;
///
/// # #[allow(dead_code)]
/// struct Slice<'a, T: 'a> {
///     start: *const T,
///     end: *const T,
///     phantom: PhantomData<&'a T>,
/// }
/// ```
///
/// Dit vereist op zijn beurt ook de annotatie `T: 'a`, die aangeeft dat alle verwijzingen in `T` geldig zijn gedurende de levensduur `'a`.
///
/// Bij het initialiseren van een `Slice` geeft u simpelweg de waarde `PhantomData` op voor het veld `phantom`:
///
/// ```
/// # #![allow(dead_code)]
/// # use std::marker::PhantomData;
/// # struct Slice<'a, T: 'a> {
/// #     start: *const T,
/// #     end: *const T,
/// #     phantom: PhantomData<&'a T>,
/// # }
/// fn borrow_vec<T>(vec: &Vec<T>) -> Slice<'_, T> {
///     let ptr = vec.as_ptr();
///     Slice {
///         start: ptr,
///         end: unsafe { ptr.add(vec.len()) },
///         phantom: PhantomData,
///     }
/// }
/// ```
///
/// ## Ongebruikte typeparameters
///
/// Het komt soms voor dat je ongebruikte typeparameters hebt die aangeven naar welk type gegevens een structuur "tied" is, ook al worden die gegevens niet daadwerkelijk in de structuur zelf gevonden.
/// Hier is een voorbeeld waar dit zich voordoet met [FFI].
/// De vreemde interface gebruikt handvatten van het type `*mut ()` om te verwijzen naar Rust-waarden van verschillende typen.
/// We volgen het Rust-type met behulp van een phantom-type-parameter op de struct `ExternalResource` die een handle omhult.
///
/// [FFI]: ../../book/ch19-01-unsafe-rust.html#using-extern-functions-to-call-external-code
///
/// ```
/// # #![allow(dead_code)]
/// # trait ResType { }
/// # struct ParamType;
/// # mod foreign_lib {
/// #     pub fn new(_: usize) -> *mut () { 42 as *mut () }
/// #     pub fn do_stuff(_: *mut (), _: usize) {}
/// # }
/// # fn convert_params(_: ParamType) -> usize { 42 }
/// use std::marker::PhantomData;
/// use std::mem;
///
/// struct ExternalResource<R> {
///    resource_handle: *mut (),
///    resource_type: PhantomData<R>,
/// }
///
/// impl<R: ResType> ExternalResource<R> {
///     fn new() -> Self {
///         let size_of_res = mem::size_of::<R>();
///         Self {
///             resource_handle: foreign_lib::new(size_of_res),
///             resource_type: PhantomData,
///         }
///     }
///
///     fn do_stuff(&self, param: ParamType) {
///         let foreign_params = convert_params(param);
///         foreign_lib::do_stuff(self.resource_handle, foreign_params);
///     }
/// }
/// ```
///
/// ## Eigendom en de dropcheck
///
/// Als u een veld van het type `PhantomData<T>` toevoegt, geeft u aan dat uw type gegevens van het type `T` bezit.Dit houdt op zijn beurt in dat wanneer uw type wordt verwijderd, het een of meer instanties van het type `T` kan laten vallen.
/// Dit heeft invloed op de [drop check]-analyse van de Rust-compiler.
///
/// Als uw struct niet de gegevens van het type `T`*bezit*, is het beter om een referentietype te gebruiken, zoals `PhantomData<&'a T>` (ideally) of `PhantomData<*const T>` (als er geen levensduur van toepassing is), om geen eigendom aan te duiden.
///
///
/// [drop check]: ../../nomicon/dropck.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "phantom_data"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct PhantomData<T: ?Sized>;

impls! { PhantomData }

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Sync + ?Sized> Send for &T {}
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Send + ?Sized> Send for &mut T {}
}

/// Compiler-interne trait gebruikt om het type enum-discriminanten aan te geven.
///
/// Deze trait wordt automatisch voor elk type geïmplementeerd en voegt geen garanties toe aan [`mem::Discriminant`].
/// Het is **ongedefinieerd gedrag** om tussen `DiscriminantKind::Discriminant` en `mem::Discriminant` te transmuteren.
///
/// [`mem::Discriminant`]: crate::mem::Discriminant
///
#[unstable(
    feature = "discriminant_kind",
    issue = "none",
    reason = "this trait is unlikely to ever be stabilized, use `mem::discriminant` instead"
)]
#[lang = "discriminant_kind"]
pub trait DiscriminantKind {
    /// Het type discriminant, dat moet voldoen aan de trait bounds vereist door `mem::Discriminant`.
    ///
    #[lang = "discriminant_type"]
    type Discriminant: Clone + Copy + Debug + Eq + PartialEq + Hash + Send + Sync + Unpin;
}

/// Compiler-interne trait gebruikt om te bepalen of een type intern `UnsafeCell` bevat, maar niet via een indirecte.
///
/// Dit heeft bijvoorbeeld invloed op of een `static` van dat type in een alleen-lezen statisch geheugen of in een schrijfbaar statisch geheugen wordt geplaatst.
///
#[lang = "freeze"]
pub(crate) unsafe auto trait Freeze {}

impl<T: ?Sized> !Freeze for UnsafeCell<T> {}
unsafe impl<T: ?Sized> Freeze for PhantomData<T> {}
unsafe impl<T: ?Sized> Freeze for *const T {}
unsafe impl<T: ?Sized> Freeze for *mut T {}
unsafe impl<T: ?Sized> Freeze for &T {}
unsafe impl<T: ?Sized> Freeze for &mut T {}

/// Typen die veilig kunnen worden verplaatst nadat ze zijn vastgemaakt.
///
/// Rust heeft zelf geen notie van onroerende typen en beschouwt verhuizingen (bijv. Door toewijzing of [`mem::replace`]) altijd als veilig.
///
/// Het [`Pin`][Pin]-type wordt in plaats daarvan gebruikt om bewegingen door het typesysteem te voorkomen.Aanwijzers `P<T>` verpakt in de [`Pin<P<T>>`][Pin]-wikkel kunnen niet worden verwijderd.
/// Zie de [`pin` module]-documentatie voor meer informatie over vastzetten.
///
/// Door de `Unpin` trait voor `T` te implementeren, worden de beperkingen van het vastzetten van het type opgeheven, waardoor `T` uit [`Pin<P<T>>`][Pin] kan worden verplaatst met functies zoals [`mem::replace`].
///
///
/// `Unpin` heeft helemaal geen gevolgen voor niet-vastgezette gegevens.
/// In het bijzonder verplaatst [`mem::replace`] `!Unpin`-gegevens graag (het werkt voor elke `&mut T`, niet alleen voor `T: Unpin`).
/// U kunt [`mem::replace`] echter niet gebruiken op gegevens die in een [`Pin<P<T>>`][Pin] zijn verpakt, omdat u de daarvoor benodigde `&mut T` niet kunt krijgen, en *dat* is wat dit systeem doet werken.
///
/// Dus dit kan bijvoorbeeld alleen worden gedaan op typen die `Unpin` implementeren:
///
/// ```rust
/// # #![allow(unused_must_use)]
/// use std::mem;
/// use std::pin::Pin;
///
/// let mut string = "this".to_string();
/// let mut pinned_string = Pin::new(&mut string);
///
/// // We hebben een veranderlijke referentie nodig om `mem::replace` aan te roepen.
/// // We kunnen een dergelijke referentie verkrijgen door (implicitly) `Pin::deref_mut` aan te roepen, maar dat is alleen mogelijk omdat `String` `Unpin` implementeert.
/////
/// mem::replace(&mut *pinned_string, "other".to_string());
/// ```
///
/// Deze trait wordt voor vrijwel elk type automatisch geïmplementeerd.
///
/// [`mem::replace`]: crate::mem::replace
/// [Pin]: crate::pin::Pin
/// [`pin` module]: crate::pin
///
///
///
///
///
///
#[stable(feature = "pin", since = "1.33.0")]
#[rustc_on_unimplemented(
    on(_Self = "std::future::Future", note = "consider using `Box::pin`",),
    message = "`{Self}` cannot be unpinned"
)]
#[lang = "unpin"]
pub auto trait Unpin {}

/// Een markeringstype dat `Unpin` niet implementeert.
///
/// Als een type een `PhantomPinned` bevat, wordt `Unpin` niet standaard geïmplementeerd.
#[stable(feature = "pin", since = "1.33.0")]
#[derive(Debug, Default, Copy, Clone, Eq, PartialEq, Ord, PartialOrd, Hash)]
pub struct PhantomPinned;

#[stable(feature = "pin", since = "1.33.0")]
impl !Unpin for PhantomPinned {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a T {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a mut T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *const T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *mut T {}

/// Implementaties van `Copy` voor primitieve typen.
///
/// Implementaties die niet kunnen worden beschreven in Rust worden geïmplementeerd in `traits::SelectionContext::copy_clone_conditions()` in `rustc_trait_selection`.
///
///
mod copy_impls {

    use super::Copy;

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Copy for ! {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *const T {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *mut T {}

    /// Gedeelde referenties kunnen worden gekopieerd, maar veranderlijke referenties *kunnen niet*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for &T {}
}