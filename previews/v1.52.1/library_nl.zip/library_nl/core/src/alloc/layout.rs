use crate::cmp;
use crate::fmt;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ptr::NonNull;

// Hoewel deze functie op één plaats wordt gebruikt en de implementatie ervan kan worden geïntegreerd, hebben de eerdere pogingen om dit te doen rustc langzamer gemaakt:
//
//
// * https://github.com/rust-lang/rust/pull/72189
// * https://github.com/rust-lang/rust/pull/79827
//
const fn size_align<T>() -> (usize, usize) {
    (mem::size_of::<T>(), mem::align_of::<T>())
}

/// Lay-out van een geheugenblok.
///
/// Een exemplaar van `Layout` beschrijft een bepaalde indeling van het geheugen.
/// Je bouwt een `Layout` op als input om aan een allocator te geven.
///
/// Alle lay-outs hebben een bijbehorende grootte en een kracht van twee uitlijning.
///
/// (Merk op dat lay-outs *niet* vereist zijn om een grootte te hebben die niet nul is, ook al vereist `GlobalAlloc` dat alle geheugenverzoeken een grootte hebben die niet nul is.
/// Een beller moet ervoor zorgen dat aan dit soort voorwaarden wordt voldaan, specifieke allocators gebruiken met lossere vereisten, of de soepelere `Allocator`-interface gebruiken.)
///
///
///
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[lang = "alloc_layout"]
pub struct Layout {
    // grootte van het gevraagde geheugenblok, gemeten in bytes.
    size_: usize,

    // uitlijning van het gevraagde geheugenblok, gemeten in bytes.
    // we zorgen ervoor dat dit altijd een macht van twee is, omdat API's zoals `posix_memalign` dit vereisen en het een redelijke beperking is om lay-outconstructors op te leggen.
    //
    //
    // (We hebben echter niet analoog nodig `align>= sizeof(void *)`, even though that is* also* a requirement of `posix_memalign`.)
    //
    //
    align_: NonZeroUsize,
}

impl Layout {
    /// Construeert een `Layout` van een gegeven `size` en `align`, of retourneert `LayoutError` als niet aan een van de volgende voorwaarden wordt voldaan:
    ///
    /// * `align` mag niet nul zijn,
    ///
    /// * `align` moet een macht van twee zijn,
    ///
    /// * `size`, indien afgerond naar het dichtstbijzijnde veelvoud van `align`, mag niet overlopen (dwz de afgeronde waarde moet kleiner zijn dan of gelijk zijn aan `usize::MAX`).
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn from_size_align(size: usize, align: usize) -> Result<Self, LayoutError> {
        if !align.is_power_of_two() {
            return Err(LayoutError { private: () });
        }

        // (macht-van-twee impliceert align!=0.)

        // Afgeronde maat is:
        //   size_rounded_up=(size + align, 1)&! (align, 1);
        //
        // We weten van bovenaf dat align!=0.
        // Als het toevoegen (uitlijnen, 1) niet overloopt, is het naar boven afronden prima.
        //
        // Omgekeerd zal&-masking met! (Align, 1) alleen low-order-bits aftrekken.
        // Dus als er een overloop optreedt met de som, kan het&-masker niet genoeg aftrekken om die overloop ongedaan te maken.
        //
        //
        // Bovenstaande impliceert dat het controleren op sommatie-overflow zowel noodzakelijk als voldoende is.
        //
        if size > usize::MAX - (align - 1) {
            return Err(LayoutError { private: () });
        }

        // VEILIGHEID: de voorwaarden voor `from_size_align_unchecked` waren
        // hierboven gecontroleerd.
        unsafe { Ok(Layout::from_size_align_unchecked(size, align)) }
    }

    /// Creëert een lay-out, waarbij alle controles worden omzeild.
    ///
    /// # Safety
    ///
    /// Deze functie is onveilig omdat het de voorwaarden van [`Layout::from_size_align`] niet verifieert.
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub const unsafe fn from_size_align_unchecked(size: usize, align: usize) -> Self {
        // VEILIGHEID: de beller moet ervoor zorgen dat `align` groter is dan nul.
        Layout { size_: size, align_: unsafe { NonZeroUsize::new_unchecked(align) } }
    }

    /// De minimumgrootte in bytes voor een geheugenblok van deze lay-out.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn size(&self) -> usize {
        self.size_
    }

    /// De minimale byte-uitlijning voor een geheugenblok van deze lay-out.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn align(&self) -> usize {
        self.align_.get()
    }

    /// Construeert een `Layout` die geschikt is om een waarde van het type `T` vast te houden.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout_const_new", since = "1.42.0")]
    #[inline]
    pub const fn new<T>() -> Self {
        let (size, align) = size_align::<T>();
        // VEILIGHEID: de uitlijning wordt gegarandeerd door Rust als een macht van twee en
        // de combo size + align past gegarandeerd in onze adresruimte.
        // Gebruik daarom de niet-aangevinkte constructor hier om te voorkomen dat code panics wordt ingevoegd als deze niet goed genoeg is geoptimaliseerd.
        //
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Produceert een lay-out die een record beschrijft dat kan worden gebruikt om een ondersteunende structuur voor `T` toe te wijzen (wat een trait kan zijn of een ander niet-formaat type zoals een slice).
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub fn for_value<T: ?Sized>(t: &T) -> Self {
        let (size, align) = (mem::size_of_val(t), mem::align_of_val(t));
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // VEILIGHEID: zie redenering in `new` voor waarom dit de onveilige variant gebruikt
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Produceert een lay-out die een record beschrijft dat kan worden gebruikt om een ondersteunende structuur voor `T` toe te wijzen (wat een trait kan zijn of een ander niet-formaat type zoals een slice).
    ///
    /// # Safety
    ///
    /// Deze functie is alleen veilig om te bellen als de volgende voorwaarden gelden:
    ///
    /// - Als `T` `Sized` is, is deze functie altijd veilig om te bellen.
    /// - Als de unsized tail van `T` is:
    ///     - a [slice], dan moet de lengte van de slice-tail een geïnitialiseerd geheel getal zijn en moet de grootte van de *volledige waarde*(dynamische tail-lengte + prefix met statische grootte) passen in `isize`.
    ///     - een [trait object], dan moet het vtable-gedeelte van de pointer verwijzen naar een geldige vtable voor het type `T` verkregen door een unsizing coersion, en de grootte van de *volledige waarde*(dynamische staartlengte + statisch formaat prefix) moet passen in `isize`.
    ///
    ///     - een (unstable) [extern type], dan is deze functie altijd veilig om aan te roepen, maar kan panic of anderszins de verkeerde waarde retourneren, aangezien de lay-out van het externe type niet bekend is.
    ///     Dit is hetzelfde gedrag als [`Layout::for_value`] bij een verwijzing naar een extern type staart.
    ///     - anders is het conservatief niet toegestaan om deze functie aan te roepen.
    ///
    /// [trait object]: ../../book/ch17-02-trait-objects.html
    /// [extern type]: ../../unstable-book/language-features/extern-types.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "layout_for_ptr", issue = "69835")]
    pub unsafe fn for_value_raw<T: ?Sized>(t: *const T) -> Self {
        // VEILIGHEID: we geven de voorwaarden van deze functies door aan de beller
        let (size, align) = unsafe { (mem::size_of_val_raw(t), mem::align_of_val_raw(t)) };
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // VEILIGHEID: zie redenering in `new` voor waarom dit de onveilige variant gebruikt
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Creëert een `NonNull` die bungelt, maar goed is uitgelijnd voor deze lay-out.
    ///
    /// Merk op dat de pointerwaarde mogelijk een geldige pointer vertegenwoordigt, wat betekent dat deze niet mag worden gebruikt als een "not yet initialized"-sentinelwaarde.
    /// Typen die lui toewijzen, moeten de initialisatie op een andere manier volgen.
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub const fn dangling(&self) -> NonNull<u8> {
        // VEILIGHEID: uitlijnen is gegarandeerd niet-nul
        unsafe { NonNull::new_unchecked(self.align() as *mut u8) }
    }

    /// Creëert een lay-out die de record beschrijft die een waarde kan bevatten met dezelfde lay-out als `self`, maar die ook is uitgelijnd met uitlijning `align` (gemeten in bytes).
    ///
    ///
    /// Als `self` al voldoet aan de voorgeschreven uitlijning, retourneert hij `self`.
    ///
    /// Merk op dat deze methode geen opvulling toevoegt aan de totale grootte, ongeacht of de geretourneerde lay-out een andere uitlijning heeft.
    /// Met andere woorden, als `K` maat 16 heeft, heeft `K.align_to(32)`*nog* maat 16.
    ///
    /// Retourneert een fout als de combinatie van `self.size()` en de opgegeven `align` in strijd is met de voorwaarden die worden vermeld in [`Layout::from_size_align`].
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn align_to(&self, align: usize) -> Result<Self, LayoutError> {
        Layout::from_size_align(self.size(), cmp::max(self.align(), align))
    }

    /// Retourneert de hoeveelheid opvulling die we moeten invoegen na `self` om ervoor te zorgen dat het volgende adres voldoet aan `align` (gemeten in bytes).
    ///
    /// Als `self.size()` bijvoorbeeld 9 is, retourneert `self.padding_needed_for(4)` 3, omdat dat het minimum aantal bytes aan opvulling is dat nodig is om een adres met 4 uitgelijnd te krijgen (ervan uitgaande dat het corresponderende geheugenblok begint bij een adres met 4 uitlijnen).
    ///
    ///
    /// De geretourneerde waarde van deze functie heeft geen betekenis als `align` geen macht van twee is.
    ///
    /// Merk op dat het nut van de geretourneerde waarde vereist dat `align` kleiner is dan of gelijk is aan de uitlijning van het startadres voor het hele toegewezen geheugenblok.Een manier om aan deze beperking te voldoen, is door ervoor te zorgen dat `align <= self.align()`.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "const_alloc_layout", issue = "67521")]
    #[inline]
    pub const fn padding_needed_for(&self, align: usize) -> usize {
        let len = self.size();

        // Afgeronde waarde is:
        //   len_rounded_up=(len + align, 1)&! (align, 1);
        // en dan geven we het verschil in opvulling terug: `len_rounded_up - len`.
        //
        // We gebruiken modulaire rekenkunde gedurende:
        //
        // 1. align is gegarandeerd> 0, dus align, 1 is altijd geldig.
        //
        // 2.
        // `len + align - 1` kan maximaal `align - 1` overstromen, dus het&-masker met `!(align - 1)` zorgt ervoor dat in het geval van overflow `len_rounded_up` zelf 0 zal zijn.
        //
        //    Dus de geretourneerde opvulling, wanneer toegevoegd aan `len`, levert 0 op, wat triviaal voldoet aan de uitlijning `align`.
        //
        // (Pogingen om geheugenblokken toe te wijzen waarvan de grootte en opvulling op de bovenstaande manier overlopen, zouden er natuurlijk voor moeten zorgen dat de allocator toch een fout geeft.)
        //
        //
        //
        //

        let len_rounded_up = len.wrapping_add(align).wrapping_sub(1) & !align.wrapping_sub(1);
        len_rounded_up.wrapping_sub(len)
    }

    /// Maakt een lay-out door de grootte van deze lay-out af te ronden tot een veelvoud van de uitlijning van de lay-out.
    ///
    ///
    /// Dit komt overeen met het toevoegen van het resultaat van `padding_needed_for` aan de huidige grootte van de lay-out.
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn pad_to_align(&self) -> Layout {
        let pad = self.padding_needed_for(self.align());
        // Dit kan niet overstromen.Citeren uit de invariant van Layout:
        // > `size`, afgerond naar het dichtstbijzijnde veelvoud van `align`,
        // > mag niet overlopen (dwz de afgeronde waarde moet kleiner zijn dan
        // > `usize::MAX`)
        let new_size = self.size() + pad;

        Layout::from_size_align(new_size, self.align()).unwrap()
    }

    /// Maakt een lay-out die het record beschrijft voor `n`-instanties van `self`, met een geschikte hoeveelheid opvulling tussen elk om ervoor te zorgen dat elke instantie de gevraagde grootte en uitlijning krijgt.
    /// Bij succes wordt `(k, offs)` geretourneerd, waarbij `k` de lay-out van de array is en `offs` de afstand tussen het begin van elk element in de array.
    ///
    /// Geeft bij rekenkundige overloop `LayoutError` terug.
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat(&self, n: usize) -> Result<(Self, usize), LayoutError> {
        // Dit kan niet overstromen.Citeren uit de invariant van Layout:
        // > `size`, afgerond naar het dichtstbijzijnde veelvoud van `align`,
        // > mag niet overlopen (dwz de afgeronde waarde moet kleiner zijn dan
        // > `usize::MAX`)
        let padded_size = self.size() + self.padding_needed_for(self.align());
        let alloc_size = padded_size.checked_mul(n).ok_or(LayoutError { private: () })?;

        // VEILIGHEID: self.align is al bekend als geldig en alloc_size is
        // al opgevuld.
        unsafe { Ok((Layout::from_size_align_unchecked(alloc_size, self.align()), padded_size)) }
    }

    /// Maakt een lay-out met een beschrijving van het record voor `self` gevolgd door `next`, inclusief eventuele benodigde opvulling om ervoor te zorgen dat `next` correct wordt uitgelijnd, maar *geen opvulling achteraan*.
    ///
    /// Om de lay-out van C-weergave `repr(C)` overeen te laten komen, moet u `pad_to_align` aanroepen nadat u de lay-out met alle velden hebt uitgebreid.
    /// (Er is geen manier om de standaard Rust-weergave-indeling `repr(Rust)`, as it is unspecified.)
    ///
    /// Merk op dat de uitlijning van de resulterende lay-out het maximum zal zijn van die van `self` en `next`, om uitlijning van beide delen te garanderen.
    ///
    /// Geeft als resultaat `Ok((k, offset))`, waarbij `k` de lay-out is van het aaneengeschakelde record en `offset` de relatieve locatie, in bytes, is van het begin van de `next` die is ingesloten in het aaneengeschakelde record (ervan uitgaande dat het record zelf begint bij offset 0).
    ///
    ///
    /// Geeft bij rekenkundige overloop `LayoutError` terug.
    ///
    /// # Examples
    ///
    /// Om de lay-out van een `#[repr(C)]`-structuur en de offsets van de velden te berekenen op basis van de lay-outs van de velden:
    ///
    /// ```rust
    /// # use std::alloc::{Layout, LayoutError};
    /// pub fn repr_c(fields: &[Layout]) -> Result<(Layout, Vec<usize>), LayoutError> {
    ///     let mut offsets = Vec::new();
    ///     let mut layout = Layout::from_size_align(0, 1)?;
    ///     for &field in fields {
    ///         let (new_layout, offset) = layout.extend(field)?;
    ///         layout = new_layout;
    ///         offsets.push(offset);
    ///     }
    ///     // Vergeet niet om af te ronden met `pad_to_align`!
    ///     Ok((layout.pad_to_align(), offsets))
    /// }
    /// # // test of het werkt
    /// # #[repr(C)] struct S { a: u64, b: u32, c: u16, d: u32 }
    /// # let s = Layout::new::<S>();
    /// # let u16 = Layout::new::<u16>();
    /// # let u32 = Layout::new::<u32>();
    /// # let u64 = Layout::new::<u64>();
    /// # assert_eq!(repr_c(&[u64, u32, u16, u32]), Ok((s, vec![0, 8, 12, 16])));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn extend(&self, next: Self) -> Result<(Self, usize), LayoutError> {
        let new_align = cmp::max(self.align(), next.align());
        let pad = self.padding_needed_for(next.align());

        let offset = self.size().checked_add(pad).ok_or(LayoutError { private: () })?;
        let new_size = offset.checked_add(next.size()).ok_or(LayoutError { private: () })?;

        let layout = Layout::from_size_align(new_size, new_align)?;
        Ok((layout, offset))
    }

    /// Maakt een lay-out die het record beschrijft voor `n`-instanties van `self`, zonder opvulling tussen elke instantie.
    ///
    /// Merk op dat, in tegenstelling tot `repeat`, `repeat_packed` niet garandeert dat de herhaalde exemplaren van `self` correct zullen worden uitgelijnd, zelfs als een bepaald exemplaar van `self` correct is uitgelijnd.
    /// Met andere woorden, als de lay-out die wordt geretourneerd door `repeat_packed` wordt gebruikt om een array toe te wijzen, is het niet gegarandeerd dat alle elementen in de array correct worden uitgelijnd.
    ///
    /// Geeft bij rekenkundige overloop `LayoutError` terug.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat_packed(&self, n: usize) -> Result<Self, LayoutError> {
        let size = self.size().checked_mul(n).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(size, self.align())
    }

    /// Maakt een lay-out met een beschrijving van het record voor `self` gevolgd door `next` zonder extra opvulling tussen de twee.
    /// Aangezien er geen opvulling wordt ingevoegd, is de uitlijning van `next` niet relevant en wordt deze *helemaal* niet opgenomen in de resulterende lay-out.
    ///
    ///
    /// Geeft bij rekenkundige overloop `LayoutError` terug.
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn extend_packed(&self, next: Self) -> Result<Self, LayoutError> {
        let new_size = self.size().checked_add(next.size()).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(new_size, self.align())
    }

    /// Maakt een lay-out met een beschrijving van het record voor een `[T; n]`.
    ///
    /// Geeft bij rekenkundige overloop `LayoutError` terug.
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn array<T>(n: usize) -> Result<Self, LayoutError> {
        let (layout, offset) = Layout::new::<T>().repeat(n)?;
        debug_assert_eq!(offset, mem::size_of::<T>());
        Ok(layout.pad_to_align())
    }
}

#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
pub type LayoutErr = LayoutError;

/// De parameters die aan `Layout::from_size_align` of een andere `Layout`-constructor zijn gegeven, voldoen niet aan de gedocumenteerde beperkingen.
///
///
#[stable(feature = "alloc_layout_error", since = "1.50.0")]
#[derive(Clone, PartialEq, Eq, Debug)]
pub struct LayoutError {
    private: (),
}

// (we hebben dit nodig voor stroomafwaartse impl van trait Error)
#[stable(feature = "alloc_layout", since = "1.28.0")]
impl fmt::Display for LayoutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("invalid parameters to Layout::from_size_align")
    }
}