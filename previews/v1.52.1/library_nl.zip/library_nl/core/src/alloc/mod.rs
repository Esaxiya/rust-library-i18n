//! Geheugentoewijzing API's

#![stable(feature = "alloc_module", since = "1.28.0")]

mod global;
mod layout;

#[stable(feature = "global_alloc", since = "1.28.0")]
pub use self::global::GlobalAlloc;
#[stable(feature = "alloc_layout", since = "1.28.0")]
pub use self::layout::Layout;
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
#[allow(deprecated, deprecated_in_future)]
pub use self::layout::LayoutErr;

#[stable(feature = "alloc_layout_error", since = "1.50.0")]
pub use self::layout::LayoutError;

use crate::fmt;
use crate::ptr::{self, NonNull};

/// De `AllocError`-fout geeft een toewijzingsfout aan die te wijten kan zijn aan uitputting van bronnen of aan iets fout bij het combineren van de opgegeven invoerargumenten met deze allocator.
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[derive(Copy, Clone, PartialEq, Eq, Debug)]
pub struct AllocError;

// (we hebben dit nodig voor stroomafwaartse impl van trait Error)
#[unstable(feature = "allocator_api", issue = "32838")]
impl fmt::Display for AllocError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("memory allocation failed")
    }
}

/// Een implementatie van `Allocator` kan willekeurige gegevensblokken die zijn beschreven via [`Layout`][] toewijzen, vergroten, verkleinen en ongedaan maken.
///
/// `Allocator` is ontworpen om te worden geïmplementeerd op ZST's, referenties of slimme pointers omdat het hebben van een allocator zoals `MyAlloc([u8; N])` niet kan worden verplaatst zonder de pointers naar het toegewezen geheugen bij te werken.
///
/// In tegenstelling tot [`GlobalAlloc`][] zijn toewijzingen ter grootte van nul toegestaan in `Allocator`.
/// Als een onderliggende allocator dit niet ondersteunt (zoals jemalloc) of een null-pointer retourneert (zoals `libc::malloc`), moet dit worden opgevangen door de implementatie.
///
/// ### Momenteel toegewezen geheugen
///
/// Sommige van de methoden vereisen dat een geheugenblok *momenteel wordt toegewezen* via een allocator.Dit betekent dat:
///
/// * het startadres voor dat geheugenblok was eerder geretourneerd door [`allocate`], [`grow`] of [`shrink`], en
///
/// * het geheugenblok is vervolgens niet ongedaan gemaakt, waarbij blokken ofwel direct worden ongedaan gemaakt door te worden doorgegeven aan [`deallocate`] of zijn gewijzigd door te worden doorgegeven aan [`grow`] of [`shrink`] die `Ok` retourneert.
///
/// Als `grow` of `shrink` `Err` hebben geretourneerd, blijft de doorgegeven pointer geldig.
///
/// [`allocate`]: Allocator::allocate
/// [`grow`]: Allocator::grow
/// [`shrink`]: Allocator::shrink
/// [`deallocate`]: Allocator::deallocate
///
/// ### Geheugenaanpassing
///
/// Sommige methoden vereisen dat een lay-out *past* in een geheugenblok.
/// Wat het betekent voor een lay-out naar "fit" een geheugenblok betekent (of equivalent, voor een geheugenblok naar "fit" een lay-out), is dat de volgende voorwaarden moeten gelden:
///
/// * Het blok moet worden toegewezen met dezelfde uitlijning als [`layout.align()`], en
///
/// * De meegeleverde [`layout.size()`] moet binnen het bereik `min ..= max` vallen, waarbij:
///   - `min` is de grootte van de lay-out die het meest recent is gebruikt om het blok toe te wijzen, en
///   - `max` is de laatste werkelijke grootte die is geretourneerd door [`allocate`], [`grow`] of [`shrink`].
///
/// [`layout.align()`]: Layout::align
/// [`layout.size()`]: Layout::size
///
/// # Safety
///
/// * Geheugenblokken die door een allocator worden geretourneerd, moeten verwijzen naar een geldig geheugen en hun geldigheid behouden totdat de instantie en al zijn klonen zijn verwijderd,
///
/// * het klonen of verplaatsen van de allocator mag de door deze allocator geretourneerde geheugenblokken niet ongeldig maken.Een gekloonde allocator moet zich gedragen als dezelfde allocator, en
///
/// * elke pointer naar een geheugenblok dat [*currently allocated*] is, kan worden doorgegeven aan elke andere methode van de allocator.
///
/// [*currently allocated*]: #currently-allocated-memory
///
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
pub unsafe trait Allocator {
    /// Probeert een geheugenblok toe te wijzen.
    ///
    /// Bij succes wordt een [`NonNull<[u8]>`][NonNull] geretourneerd die voldoet aan de garanties voor grootte en uitlijning van `layout`.
    ///
    /// Het geretourneerde blok kan een grotere grootte hebben dan gespecificeerd door `layout.size()`, en de inhoud ervan kan al dan niet geïnitialiseerd zijn.
    ///
    /// # Errors
    ///
    /// Het teruggeven van `Err` geeft aan dat het geheugen is uitgeput of dat `layout` niet voldoet aan de beperkingen van de allocator of uitlijning.
    ///
    /// Implementaties worden aangemoedigd om `Err` terug te geven na uitputting van het geheugen in plaats van in paniek te raken of af te breken, maar dit is geen strikte vereiste.
    /// (Specifiek: het is *legaal* om deze trait te implementeren bovenop een onderliggende native toewijzingsbibliotheek die wordt afgebroken bij geheugenuitputting.)
    ///
    /// Cliënten die de berekening willen afbreken als reactie op een allocatiefout, worden aangemoedigd om de [`handle_alloc_error`]-functie aan te roepen in plaats van `panic!` of iets dergelijks rechtstreeks aan te roepen.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError>;

    /// Gedraagt zich als `allocate`, maar zorgt er ook voor dat het geretourneerde geheugen op nul wordt geïnitialiseerd.
    ///
    /// # Errors
    ///
    /// Het teruggeven van `Err` geeft aan dat het geheugen is uitgeput of dat `layout` niet voldoet aan de beperkingen van de allocator of uitlijning.
    ///
    /// Implementaties worden aangemoedigd om `Err` terug te geven na uitputting van het geheugen in plaats van in paniek te raken of af te breken, maar dit is geen strikte vereiste.
    /// (Specifiek: het is *legaal* om deze trait te implementeren bovenop een onderliggende native toewijzingsbibliotheek die wordt afgebroken bij geheugenuitputting.)
    ///
    /// Cliënten die de berekening willen afbreken als reactie op een allocatiefout, worden aangemoedigd om de [`handle_alloc_error`]-functie aan te roepen in plaats van `panic!` of iets dergelijks rechtstreeks aan te roepen.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        let ptr = self.allocate(layout)?;
        // VEILIGHEID: `alloc` retourneert een geldig geheugenblok
        unsafe { ptr.as_non_null_ptr().as_ptr().write_bytes(0, ptr.len()) }
        Ok(ptr)
    }

    /// Wijst het geheugen terug waarnaar wordt verwezen door `ptr`.
    ///
    /// # Safety
    ///
    /// * `ptr` moet een blok geheugen [*currently allocated*] aangeven via deze allocator, en
    /// * `layout` moet [*fit*] dat blok geheugen.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout);

    /// Pogingen om het geheugenblok uit te breiden.
    ///
    /// Retourneert een nieuwe [`NonNull<[u8]>`][NonNull] met een pointer en de werkelijke grootte van het toegewezen geheugen.De aanwijzer is geschikt voor het vasthouden van gegevens beschreven door `new_layout`.
    /// Om dit te bereiken, kan de allocator de toewijzing waarnaar wordt verwezen door `ptr` uitbreiden om in de nieuwe lay-out te passen.
    ///
    /// Als dit `Ok` retourneert, is het eigendom van het geheugenblok waarnaar wordt verwezen door `ptr` overgedragen aan deze allocator.
    /// Het geheugen kan al dan niet zijn vrijgemaakt en moet als onbruikbaar worden beschouwd, tenzij het opnieuw werd teruggestuurd naar de beller via de retourwaarde van deze methode.
    ///
    /// Als deze methode `Err` retourneert, is het eigendom van het geheugenblok niet overgedragen aan deze allocator en blijft de inhoud van het geheugenblok ongewijzigd.
    ///
    /// # Safety
    ///
    /// * `ptr` moet via deze allocator een blok geheugen [*currently allocated*] aanduiden.
    /// * `old_layout` moet [*fit*] dat blok geheugen gebruiken (het `new_layout`-argument hoeft er niet in te passen.).
    /// * `new_layout.size()` moet groter zijn dan of gelijk zijn aan `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Geeft `Err` terug als de nieuwe lay-out niet voldoet aan de beperkingen van de allocator en uitlijning van de allocator, of als groeien anders mislukt.
    ///
    /// Implementaties worden aangemoedigd om `Err` terug te geven na uitputting van het geheugen in plaats van in paniek te raken of af te breken, maar dit is geen strikte vereiste.
    /// (Specifiek: het is *legaal* om deze trait te implementeren bovenop een onderliggende native toewijzingsbibliotheek die wordt afgebroken bij geheugenuitputting.)
    ///
    /// Cliënten die de berekening willen afbreken als reactie op een allocatiefout, worden aangemoedigd om de [`handle_alloc_error`]-functie aan te roepen in plaats van `panic!` of iets dergelijks rechtstreeks aan te roepen.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // VEILIGHEID: omdat `new_layout.size()` groter moet zijn dan of gelijk moet zijn aan
        // `old_layout.size()`, zowel de oude als de nieuwe geheugentoewijzing zijn geldig voor lees-en schrijfbewerkingen voor `old_layout.size()`-bytes.
        // Omdat de oude toewijzing nog niet is opgeheven, kan deze `new_ptr` niet overlappen.
        // De oproep naar `copy_nonoverlapping` is dus veilig.
        // Het veiligheidscontract voor `dealloc` moet worden gehandhaafd door de beller.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Gedraagt zich als `grow`, maar zorgt er ook voor dat de nieuwe inhoud op nul wordt gezet voordat deze wordt geretourneerd.
    ///
    /// Het geheugenblok zal de volgende inhoud bevatten na een geslaagde oproep naar
    /// `grow_zeroed`:
    ///   * Bytes `0..old_layout.size()` blijven behouden van de oorspronkelijke toewijzing.
    ///   * Bytes `old_layout.size()..old_size` worden behouden of op nul gezet, afhankelijk van de implementatie van de allocator.
    ///   `old_size` verwijst naar de grootte van het geheugenblok voorafgaand aan de `grow_zeroed`-oproep, die groter kan zijn dan de grootte die oorspronkelijk was aangevraagd toen het werd toegewezen.
    ///   * Bytes `old_size..new_size` worden op nul gezet.`new_size` verwijst naar de grootte van het geheugenblok dat wordt geretourneerd door de `grow_zeroed`-aanroep.
    ///
    /// # Safety
    ///
    /// * `ptr` moet via deze allocator een blok geheugen [*currently allocated*] aanduiden.
    /// * `old_layout` moet [*fit*] dat blok geheugen gebruiken (het `new_layout`-argument hoeft er niet in te passen.).
    /// * `new_layout.size()` moet groter zijn dan of gelijk zijn aan `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Geeft `Err` terug als de nieuwe lay-out niet voldoet aan de beperkingen van de allocator en uitlijning van de allocator, of als groeien anders mislukt.
    ///
    /// Implementaties worden aangemoedigd om `Err` terug te geven na uitputting van het geheugen in plaats van in paniek te raken of af te breken, maar dit is geen strikte vereiste.
    /// (Specifiek: het is *legaal* om deze trait te implementeren bovenop een onderliggende native toewijzingsbibliotheek die wordt afgebroken bij geheugenuitputting.)
    ///
    /// Cliënten die de berekening willen afbreken als reactie op een allocatiefout, worden aangemoedigd om de [`handle_alloc_error`]-functie aan te roepen in plaats van `panic!` of iets dergelijks rechtstreeks aan te roepen.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate_zeroed(new_layout)?;

        // VEILIGHEID: omdat `new_layout.size()` groter moet zijn dan of gelijk moet zijn aan
        // `old_layout.size()`, zowel de oude als de nieuwe geheugentoewijzing zijn geldig voor lees-en schrijfbewerkingen voor `old_layout.size()`-bytes.
        // Omdat de oude toewijzing nog niet is opgeheven, kan deze `new_ptr` niet overlappen.
        // De oproep naar `copy_nonoverlapping` is dus veilig.
        // Het veiligheidscontract voor `dealloc` moet worden gehandhaafd door de beller.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Pogingen om het geheugenblok te verkleinen.
    ///
    /// Retourneert een nieuwe [`NonNull<[u8]>`][NonNull] met een pointer en de werkelijke grootte van het toegewezen geheugen.De aanwijzer is geschikt voor het vasthouden van gegevens beschreven door `new_layout`.
    /// Om dit te bereiken, kan de allocator de toewijzing waarnaar wordt verwezen door `ptr` verkleinen om in de nieuwe lay-out te passen.
    ///
    /// Als dit `Ok` retourneert, is het eigendom van het geheugenblok waarnaar wordt verwezen door `ptr` overgedragen aan deze allocator.
    /// Het geheugen kan al dan niet zijn vrijgemaakt en moet als onbruikbaar worden beschouwd, tenzij het opnieuw werd teruggestuurd naar de beller via de retourwaarde van deze methode.
    ///
    /// Als deze methode `Err` retourneert, is het eigendom van het geheugenblok niet overgedragen aan deze allocator en blijft de inhoud van het geheugenblok ongewijzigd.
    ///
    /// # Safety
    ///
    /// * `ptr` moet via deze allocator een blok geheugen [*currently allocated*] aanduiden.
    /// * `old_layout` moet [*fit*] dat blok geheugen gebruiken (het `new_layout`-argument hoeft er niet in te passen.).
    /// * `new_layout.size()` moet kleiner zijn dan of gelijk zijn aan `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Geeft `Err` terug als de nieuwe lay-out niet voldoet aan de beperkingen van de allocator en uitlijning van de allocator, of als het verkleinen anders niet lukt.
    ///
    /// Implementaties worden aangemoedigd om `Err` terug te geven na uitputting van het geheugen in plaats van in paniek te raken of af te breken, maar dit is geen strikte vereiste.
    /// (Specifiek: het is *legaal* om deze trait te implementeren bovenop een onderliggende native toewijzingsbibliotheek die wordt afgebroken bij geheugenuitputting.)
    ///
    /// Cliënten die de berekening willen afbreken als reactie op een allocatiefout, worden aangemoedigd om de [`handle_alloc_error`]-functie aan te roepen in plaats van `panic!` of iets dergelijks rechtstreeks aan te roepen.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() <= old_layout.size(),
            "`new_layout.size()` must be smaller than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // VEILIGHEID: omdat `new_layout.size()` lager dan of gelijk aan moet zijn
        // `old_layout.size()`, zowel de oude als de nieuwe geheugentoewijzing zijn geldig voor lees-en schrijfbewerkingen voor `new_layout.size()`-bytes.
        // Omdat de oude toewijzing nog niet is opgeheven, kan deze `new_ptr` niet overlappen.
        // De oproep naar `copy_nonoverlapping` is dus veilig.
        // Het veiligheidscontract voor `dealloc` moet worden gehandhaafd door de beller.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), new_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Maakt een "by reference"-adapter voor dit exemplaar van `Allocator`.
    ///
    /// De geretourneerde adapter implementeert ook `Allocator` en leent deze gewoon.
    #[inline(always)]
    fn by_ref(&self) -> &Self
    where
        Self: Sized,
    {
        self
    }
}

#[unstable(feature = "allocator_api", issue = "32838")]
unsafe impl<A> Allocator for &A
where
    A: Allocator + ?Sized,
{
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate(layout)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate_zeroed(layout)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        // VEILIGHEID: het veiligheidscontract moet worden nageleefd door de beller
        unsafe { (**self).deallocate(ptr, layout) }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // VEILIGHEID: het veiligheidscontract moet worden nageleefd door de beller
        unsafe { (**self).grow(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // VEILIGHEID: het veiligheidscontract moet worden nageleefd door de beller
        unsafe { (**self).grow_zeroed(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // VEILIGHEID: het veiligheidscontract moet worden nageleefd door de beller
        unsafe { (**self).shrink(ptr, old_layout, new_layout) }
    }
}