use crate::alloc::Layout;
use crate::cmp;
use crate::ptr;

/// Een geheugentoewijzing die kan worden geregistreerd als de standaardbibliotheek via het kenmerk `#[global_allocator]`.
///
/// Sommige van de methoden vereisen dat een geheugenblok *momenteel wordt toegewezen* via een allocator.Dit betekent dat:
///
/// * het startadres voor dat geheugenblok was eerder geretourneerd door een eerdere aanroep naar een toewijzingsmethode zoals `alloc`, en
///
/// * het geheugenblok is vervolgens niet ongedaan gemaakt, waarbij blokken worden ongedaan gemaakt ofwel door te worden doorgegeven aan een ongedaan maken van de toewijzing, zoals `dealloc`, of door te worden doorgegeven aan een herallocatiemethode die een niet-nul-pointer retourneert.
///
///
/// # Example
///
/// ```no_run
/// use std::alloc::{GlobalAlloc, Layout, alloc};
/// use std::ptr::null_mut;
///
/// struct MyAllocator;
///
/// unsafe impl GlobalAlloc for MyAllocator {
///     unsafe fn alloc(&self, _layout: Layout) -> *mut u8 { null_mut() }
///     unsafe fn dealloc(&self, _ptr: *mut u8, _layout: Layout) {}
/// }
///
/// #[global_allocator]
/// static A: MyAllocator = MyAllocator;
///
/// fn main() {
///     unsafe {
///         assert!(alloc(Layout::new::<u32>()).is_null())
///     }
/// }
/// ```
///
/// # Safety
///
/// De `GlobalAlloc` trait is om een aantal redenen een `unsafe` trait, en uitvoerders moeten ervoor zorgen dat ze zich aan deze contracten houden:
///
/// * Het is ongedefinieerd gedrag als globale allocators tot rust komen.Deze beperking kan worden opgeheven in de future, maar momenteel kan een panic van een van deze functies leiden tot geheugenonveiligheid.
///
/// * `Layout` Query's en berekeningen in het algemeen moeten correct zijn.Bellers van deze trait mogen vertrouwen op de contracten die voor elke methode zijn gedefinieerd, en uitvoerders moeten ervoor zorgen dat dergelijke contracten waar blijven.
///
/// * U mag er niet op vertrouwen dat toewijzingen daadwerkelijk plaatsvinden, zelfs niet als er expliciete heap-toewijzingen in de bron zijn.
/// De optimizer kan ongebruikte toewijzingen detecteren die hij ofwel volledig kan elimineren of naar de stapel kan verplaatsen en dus nooit de toewijzer kan aanroepen.
/// Het optimalisatieprogramma kan verder aannemen dat toewijzing onfeilbaar is, dus code die vroeger faalde vanwege fouten in de allocator, kan nu plotseling werken omdat de optimizer rond de behoefte aan een toewijzing heeft gewerkt.
/// Meer concreet is het volgende codevoorbeeld ondeugdelijk, ongeacht of uw aangepaste allocator het mogelijk maakt om te tellen hoeveel toewijzingen er zijn gebeurd.
///
///   ```rust,ignore (unsound and has placeholders)
///   drop(Box::new(42));
///   let number_of_heap_allocs = /* call private allocator API */;
///   unsafe { std::intrinsics::assume(number_of_heap_allocs > 0); }
///   ```
///
///   Merk op dat de hierboven genoemde optimalisaties niet de enige optimalisatie zijn die kan worden toegepast.U kunt er over het algemeen niet op vertrouwen dat heap-toewijzingen plaatsvinden als ze kunnen worden verwijderd zonder het programmagedrag te veranderen.
///   Of toewijzingen al dan niet plaatsvinden, maakt geen deel uit van het programmagedrag, zelfs als het zou kunnen worden gedetecteerd via een allocator die toewijzingen bijhoudt door af te drukken of anderszins bijwerkingen heeft.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
pub unsafe trait GlobalAlloc {
    /// Wijs geheugen toe zoals beschreven door de gegeven `layout`.
    ///
    /// Retourneert een aanwijzer naar nieuw toegewezen geheugen, of null om een toewijzingsfout aan te geven.
    ///
    /// # Safety
    ///
    /// Deze functie is onveilig omdat ongedefinieerd gedrag kan optreden als de beller er niet voor zorgt dat `layout` een grootte heeft die niet gelijk is aan nul.
    ///
    /// (Extensie-subtraits kunnen meer specifieke gedragsgrenzen bieden, bijvoorbeeld een sentinel-adres of een null-pointer garanderen in reactie op een toewijzingsverzoek ter grootte van nul.)
    ///
    /// Het toegewezen geheugenblok kan al dan niet worden geïnitialiseerd.
    ///
    /// # Errors
    ///
    /// Het retourneren van een null-aanwijzer geeft aan dat het geheugen is uitgeput of dat `layout` niet voldoet aan de beperkingen van deze allocator of uitlijning.
    ///
    /// Implementaties worden aangemoedigd om null terug te geven bij geheugenuitputting in plaats van af te breken, maar dit is geen strikte vereiste.
    /// (Specifiek: het is *legaal* om deze trait te implementeren bovenop een onderliggende native toewijzingsbibliotheek die wordt afgebroken bij geheugenuitputting.)
    ///
    /// Cliënten die de berekening willen afbreken als reactie op een allocatiefout, worden aangemoedigd om de [`handle_alloc_error`]-functie aan te roepen in plaats van `panic!` of iets dergelijks rechtstreeks aan te roepen.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn alloc(&self, layout: Layout) -> *mut u8;

    /// Wijs het geheugenblok toe aan de gegeven `ptr`-pointer met de gegeven `layout`.
    ///
    /// # Safety
    ///
    /// Deze functie is onveilig omdat ongedefinieerd gedrag kan optreden als de beller niet voor al het volgende zorgt:
    ///
    ///
    /// * `ptr` moet een geheugenblok aangeven dat momenteel via deze allocator is toegewezen,
    ///
    /// * `layout` moet dezelfde lay-out hebben die werd gebruikt om dat blok geheugen toe te wijzen.
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn dealloc(&self, ptr: *mut u8, layout: Layout);

    /// Gedraagt zich als `alloc`, maar zorgt er ook voor dat de inhoud op nul wordt gezet voordat deze wordt geretourneerd.
    ///
    /// # Safety
    ///
    /// Deze functie is onveilig om dezelfde redenen als `alloc`.
    /// Het toegewezen geheugenblok wordt echter gegarandeerd geïnitialiseerd.
    ///
    /// # Errors
    ///
    /// Het retourneren van een null-pointer geeft aan dat het geheugen is uitgeput of dat `layout` niet voldoet aan de beperkingen van de allocator of uitlijning, net als in `alloc`.
    ///
    /// Cliënten die de berekening willen afbreken als reactie op een allocatiefout, worden aangemoedigd om de [`handle_alloc_error`]-functie aan te roepen in plaats van `panic!` of iets dergelijks rechtstreeks aan te roepen.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn alloc_zeroed(&self, layout: Layout) -> *mut u8 {
        let size = layout.size();
        // VEILIGHEID: het veiligheidscontract voor `alloc` moet worden nageleefd door de beller.
        let ptr = unsafe { self.alloc(layout) };
        if !ptr.is_null() {
            // VEILIGHEID: als de toewijzing is gelukt, wordt de regio van `ptr`
            // met de grootte `size` is gegarandeerd geldig voor schrijfbewerkingen.
            unsafe { ptr::write_bytes(ptr, 0, size) };
        }
        ptr
    }

    /// Verklein of vergroot een geheugenblok tot de gegeven `new_size`.
    /// Het blok wordt beschreven door de gegeven `ptr`-pointer en `layout`.
    ///
    /// Als dit een niet-nul pointer retourneert, is het eigendom van het geheugenblok waarnaar wordt verwezen door `ptr` overgedragen aan deze allocator.
    /// Het geheugen kan al dan niet ongedaan gemaakt zijn en moet als onbruikbaar worden beschouwd (tenzij het natuurlijk weer naar de beller werd teruggestuurd via de retourwaarde van deze methode).
    /// Het nieuwe geheugenblok wordt toegewezen met `layout`, maar met de `size` geüpdatet naar `new_size`.
    /// Deze nieuwe lay-out moet worden gebruikt bij het ongedaan maken van de toewijzing van het nieuwe geheugenblok met `dealloc`.
    /// Het bereik `0..min(layout.size(), new_size) `van het nieuwe geheugenblok heeft gegarandeerd dezelfde waarden als het originele blok.
    ///
    /// Als deze methode null retourneert, is het eigendom van het geheugenblok niet overgedragen aan deze allocator en blijft de inhoud van het geheugenblok ongewijzigd.
    ///
    /// # Safety
    ///
    /// Deze functie is onveilig omdat ongedefinieerd gedrag kan optreden als de beller niet voor al het volgende zorgt:
    ///
    /// * `ptr` moet momenteel worden toegewezen via deze allocator,
    ///
    /// * `layout` moet dezelfde lay-out hebben die werd gebruikt om dat blok geheugen toe te wijzen,
    ///
    /// * `new_size` moet groter zijn dan nul.
    ///
    /// * `new_size`, indien afgerond op het dichtstbijzijnde veelvoud van `layout.align()`, mag niet overlopen (dwz de afgeronde waarde moet kleiner zijn dan `usize::MAX`).
    ///
    /// (Extensie-subtraits kunnen meer specifieke gedragsgrenzen bieden, bijvoorbeeld een sentinel-adres of een null-pointer garanderen in reactie op een toewijzingsverzoek ter grootte van nul.)
    ///
    /// # Errors
    ///
    /// Retourneert null als de nieuwe lay-out niet voldoet aan de beperkingen voor grootte en uitlijning van de allocator, of als herverdeling anders mislukt.
    ///
    /// Implementaties worden aangemoedigd om null terug te geven bij geheugenuitputting in plaats van in paniek te raken of af te breken, maar dit is geen strikte vereiste.
    /// (Specifiek: het is *legaal* om deze trait te implementeren bovenop een onderliggende native toewijzingsbibliotheek die wordt afgebroken bij geheugenuitputting.)
    ///
    /// Cliënten die de berekening willen afbreken als reactie op een herallocatiefout, worden aangemoedigd om de [`handle_alloc_error`]-functie aan te roepen in plaats van `panic!` of iets dergelijks rechtstreeks aan te roepen.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn realloc(&self, ptr: *mut u8, layout: Layout, new_size: usize) -> *mut u8 {
        // VEILIGHEID: de beller moet ervoor zorgen dat de `new_size` niet overstroomt.
        // `layout.align()` komt van een `Layout` en is dus gegarandeerd geldig.
        let new_layout = unsafe { Layout::from_size_align_unchecked(new_size, layout.align()) };
        // VEILIGHEID: de beller moet ervoor zorgen dat `new_layout` groter is dan nul.
        let new_ptr = unsafe { self.alloc(new_layout) };
        if !new_ptr.is_null() {
            // VEILIGHEID: het eerder toegewezen blok mag het nieuw toegewezen blok niet overlappen.
            // Het veiligheidscontract voor `dealloc` moet worden gehandhaafd door de beller.
            unsafe {
                ptr::copy_nonoverlapping(ptr, new_ptr, cmp::min(layout.size(), new_size));
                self.dealloc(ptr, layout);
            }
        }
        new_ptr
    }
}