//! Definieert de iterator die eigendom is van de `IntoIter` voor arrays.

use crate::{
    fmt,
    iter::{ExactSizeIterator, FusedIterator, TrustedLen},
    mem::{self, MaybeUninit},
    ops::Range,
    ptr,
};

/// Een [array]-iterator op basis van waarde.
#[stable(feature = "array_value_iter", since = "1.51.0")]
pub struct IntoIter<T, const N: usize> {
    /// Dit is de array waarover we herhalen.
    ///
    /// Elementen met index `i` waar `alive.start <= i < alive.end` nog niet zijn opgeleverd en zijn geldige array-items.
    /// Elementen met indexen `i < alive.start` of `i >= alive.end` zijn al opgeleverd en mogen niet meer worden benaderd!Die dode elementen kunnen zelfs in een volledig niet-geïnitialiseerde staat verkeren!
    ///
    ///
    /// Dus de invarianten zijn:
    /// - `data[alive]` leeft (dwz bevat geldige elementen)
    /// - `data[..alive.start]` en `data[alive.end..]` zijn dood (dwz de elementen waren al gelezen en mogen niet meer worden aangeraakt!)
    ///
    ///
    ///
    data: [MaybeUninit<T>; N],

    /// De elementen in `data` die nog niet zijn opgeleverd.
    ///
    /// Invariants:
    /// - `alive.start <= alive.end`
    /// - `alive.end <= N`
    alive: Range<usize>,
}

impl<T, const N: usize> IntoIter<T, N> {
    /// Creëert een nieuwe iterator over de gegeven `array`.
    ///
    /// *Opmerking*: deze methode is mogelijk verouderd in de future, na [`IntoIterator` is implemented for arrays][array-into-iter].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::array;
    ///
    /// for value in array::IntoIter::new([1, 2, 3, 4, 5]) {
    ///     // Het type `value` is hier een `i32`, in plaats van `&i32`
    ///     let _: i32 = value;
    /// }
    /// ```
    /// [array-into-iter]: https://github.com/rust-lang/rust/pull/65819
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn new(array: [T; N]) -> Self {
        // VEILIGHEID: De transmutatie hier is eigenlijk veilig.De documenten van `MaybeUninit`
        // promise:
        //
        // > `MaybeUninit<T>` heeft gegarandeerd dezelfde grootte en uitlijning
        // > als `T`.
        //
        // De documenten laten zelfs een transmutatie zien van een array van `MaybeUninit<T>` naar een array van `T`.
        //
        //
        // Daarmee voldoet deze initialisatie aan de invarianten.

        // FIXME(LukasKalbertodt): gebruik hier eigenlijk `mem::transmute`, als het eenmaal werkt met const generics:
        //     `mem::transmute::<[T; N], [MaybeUninit<T>; N]>(array)`
        //
        // Tot die tijd kunnen we `mem::transmute_copy` gebruiken om een bitsgewijze kopie als een ander type te maken, en dan `array` vergeten zodat deze niet wordt verwijderd.
        //
        //
        unsafe {
            let iter = Self { data: mem::transmute_copy(&array), alive: 0..N };
            mem::forget(array);
            iter
        }
    }

    /// Retourneert een onveranderlijk segment van alle elementen die nog niet zijn opgeleverd.
    ///
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_slice(&self) -> &[T] {
        // VEILIGHEID: We weten dat alle elementen in `alive` correct zijn geïnitialiseerd.
        unsafe {
            let slice = self.data.get_unchecked(self.alive.clone());
            MaybeUninit::slice_assume_init_ref(slice)
        }
    }

    /// Retourneert een veranderlijk segment van alle elementen die nog niet zijn opgeleverd.
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        // VEILIGHEID: We weten dat alle elementen in `alive` correct zijn geïnitialiseerd.
        unsafe {
            let slice = self.data.get_unchecked_mut(self.alive.clone());
            MaybeUninit::slice_assume_init_mut(slice)
        }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Iterator for IntoIter<T, N> {
    type Item = T;
    fn next(&mut self) -> Option<Self::Item> {
        // Haal de volgende index van voren.
        //
        // Door `alive.start` met 1 te verhogen, blijft de invariant met betrekking tot `alive` behouden.
        // Door deze wijziging is de levende zone echter voor een korte tijd niet meer `data[alive]`, maar `data[idx..alive.end]`.
        //
        self.alive.next().map(|idx| {
            // Lees het element uit de array.
            // VEILIGHEID: `idx` is een index in de voormalige "alive"-regio van het
            // array.Het lezen van dit element betekent dat `data[idx]` nu als dood wordt beschouwd (dwz niet aanraken).
            // Omdat `idx` het begin was van de levend-zone, is de levend-zone nu weer `data[alive]`, waarbij alle invarianten worden hersteld.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        let len = self.len();
        (len, Some(len))
    }

    fn count(self) -> usize {
        self.len()
    }

    fn last(mut self) -> Option<Self::Item> {
        self.next_back()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> DoubleEndedIterator for IntoIter<T, N> {
    fn next_back(&mut self) -> Option<Self::Item> {
        // Haal de volgende index van achteren.
        //
        // Door `alive.end` met 1 te verlagen, blijft de invariant met betrekking tot `alive` behouden.
        // Door deze wijziging is de levende zone echter voor een korte tijd niet meer `data[alive]`, maar `data[alive.start..=idx]`.
        //
        self.alive.next_back().map(|idx| {
            // Lees het element uit de array.
            // VEILIGHEID: `idx` is een index in de voormalige "alive"-regio van het
            // array.Het lezen van dit element betekent dat `data[idx]` nu als dood wordt beschouwd (dwz niet aanraken).
            // Omdat `idx` het einde was van de levend-zone, is de levend-zone nu weer `data[alive]`, waarbij alle invarianten worden hersteld.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Drop for IntoIter<T, N> {
    fn drop(&mut self) {
        // VEILIGHEID: Dit is veilig: `as_mut_slice` retourneert exact het sub-segment
        // van elementen die nog niet zijn verwijderd en die nog moeten worden verwijderd.
        //
        unsafe { ptr::drop_in_place(self.as_mut_slice()) }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> ExactSizeIterator for IntoIter<T, N> {
    fn len(&self) -> usize {
        // Zal nooit onderlopen vanwege de invariante `alive.start <=
        // alive.end`.
        self.alive.end - self.alive.start
    }
    fn is_empty(&self) -> bool {
        self.alive.is_empty()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> FusedIterator for IntoIter<T, N> {}

// De iterator geeft inderdaad de juiste lengte weer.
// Het aantal "alive"-elementen (dat nog steeds wordt opgeleverd) is de lengte van het bereik `alive`.
// Dit bereik wordt in lengte verkleind in `next` of `next_back`.
// Het wordt in die methoden altijd met 1 verlaagd, maar alleen als `Some(_)` wordt geretourneerd.
#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
unsafe impl<T, const N: usize> TrustedLen for IntoIter<T, N> {}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: Clone, const N: usize> Clone for IntoIter<T, N> {
    fn clone(&self) -> Self {
        // Merk op dat we niet echt exact hetzelfde bereik hoeven te matchen, dus we kunnen gewoon naar offset 0 klonen, ongeacht waar `self` is.
        //
        let mut new = Self { data: MaybeUninit::uninit_array(), alive: 0..0 };

        // Kloon alle levende elementen.
        for (src, dst) in self.as_slice().iter().zip(&mut new.data) {
            // Schrijf een kloon naar de nieuwe array en werk vervolgens het actieve bereik bij.
            // Als je panics klonen, zullen we de vorige items correct verwijderen.
            dst.write(src.clone());
            new.alive.end += 1;
        }

        new
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: fmt::Debug, const N: usize> fmt::Debug for IntoIter<T, N> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Print alleen de elementen die nog niet zijn opgeleverd: we hebben geen toegang meer tot de opgehaalde elementen.
        //
        f.debug_tuple("IntoIter").field(&self.as_slice()).finish()
    }
}