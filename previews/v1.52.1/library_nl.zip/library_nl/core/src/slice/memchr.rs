// Originele implementatie overgenomen van rust-memchr.
// Copyright 2015 Andrew Gallant, bluss en Nicolas Koch

use crate::cmp;
use crate::mem;

const LO_U64: u64 = 0x0101010101010101;
const HI_U64: u64 = 0x8080808080808080;

// Gebruik afkapping.
const LO_USIZE: usize = LO_U64 as usize;
const HI_USIZE: usize = HI_U64 as usize;
const USIZE_BYTES: usize = mem::size_of::<usize>();

/// Geeft `true` terug als `x` een nulbyte bevat.
///
/// Van *Matters Computational*, J. Arndt:
///
/// "Het idee is om er één af te trekken van elk van de bytes en vervolgens te zoeken naar bytes waar de lening zich heeft voortgeplant tot aan de belangrijkste
///
/// bit."
#[inline]
fn contains_zero_byte(x: usize) -> bool {
    x.wrapping_sub(LO_USIZE) & !x & HI_USIZE != 0
}

#[cfg(target_pointer_width = "16")]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) << 8 | b as usize
}

#[cfg(not(target_pointer_width = "16"))]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) * (usize::MAX / 255)
}

/// Retourneert de eerste index die overeenkomt met de byte `x` in `text`.
#[inline]
pub fn memchr(x: u8, text: &[u8]) -> Option<usize> {
    // Snel pad voor kleine plakjes
    if text.len() < 2 * USIZE_BYTES {
        return text.iter().position(|elt| *elt == x);
    }

    memchr_general_case(x, text)
}

fn memchr_general_case(x: u8, text: &[u8]) -> Option<usize> {
    // Scan op een enkele bytewaarde door twee `usize`-woorden tegelijk te lezen.
    //
    // Splits `text` in drie delen
    // - niet-uitgelijnd eerste deel, vóór het eerste woord uitgelijnd adres in tekst
    // - body, scan per 2 woorden per keer
    // - het laatste resterende deel, <2 woordgrootte

    // zoeken tot aan een uitgelijnde grens
    let len = text.len();
    let ptr = text.as_ptr();
    let mut offset = ptr.align_offset(USIZE_BYTES);

    if offset > 0 {
        offset = cmp::min(offset, len);
        if let Some(index) = text[..offset].iter().position(|elt| *elt == x) {
            return Some(index);
        }
    }

    // doorzoek de body van de tekst
    let repeated_x = repeat_byte(x);
    while offset <= len - 2 * USIZE_BYTES {
        // VEILIGHEID: het while-predikaat garandeert een afstand van minstens 2 * usize_bytes
        // tussen de offset en het einde van de slice.
        unsafe {
            let u = *(ptr.add(offset) as *const usize);
            let v = *(ptr.add(offset + USIZE_BYTES) as *const usize);

            // breken als er een overeenkomende byte is
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset += USIZE_BYTES * 2;
    }

    // Zoek de byte na het punt waarop de body-loop is gestopt.
    text[offset..].iter().position(|elt| *elt == x).map(|i| offset + i)
}

/// Retourneert de laatste index die overeenkomt met de byte `x` in `text`.
pub fn memrchr(x: u8, text: &[u8]) -> Option<usize> {
    // Scan op een enkele bytewaarde door twee `usize`-woorden tegelijk te lezen.
    //
    // Splits `text` in drie delen:
    // - niet uitgelijnde staart, na het laatste woord uitgelijnd adres in de tekst,
    // - body, gescand met 2 woorden tegelijk,
    // - de eerste resterende bytes, <2 woordgrootte.
    let len = text.len();
    let ptr = text.as_ptr();
    type Chunk = usize;

    let (min_aligned_offset, max_aligned_offset) = {
        // We noemen dit alleen om de lengte van het voorvoegsel en achtervoegsel te verkrijgen.
        // In het midden verwerken we altijd twee brokjes tegelijk.
        // VEILIGHEID: het omzetten van `[u8]` naar `[usize]` is veilig, behalve voor verschillen in grootte die door `align_to` worden afgehandeld.
        //
        let (prefix, _, suffix) = unsafe { text.align_to::<(Chunk, Chunk)>() };
        (prefix.len(), len - suffix.len())
    };

    let mut offset = max_aligned_offset;
    if let Some(index) = text[offset..].iter().rposition(|elt| *elt == x) {
        return Some(offset + index);
    }

    // Doorzoek de body van de tekst, zorg ervoor dat we min_aligned_offset niet kruisen.
    // offset is altijd uitgelijnd, dus alleen het testen van `>` is voldoende en voorkomt mogelijke overflow.
    //
    let repeated_x = repeat_byte(x);
    let chunk_bytes = mem::size_of::<Chunk>();

    while offset > min_aligned_offset {
        // VEILIGHEID: offset begint bij len, suffix.len(), zolang deze groter is dan
        // min_aligned_offset (prefix.len()) de resterende afstand is minstens 2 * chunk_bytes.
        unsafe {
            let u = *(ptr.offset(offset as isize - 2 * chunk_bytes as isize) as *const Chunk);
            let v = *(ptr.offset(offset as isize - chunk_bytes as isize) as *const Chunk);

            // Breek als er een overeenkomende byte is.
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset -= 2 * chunk_bytes;
    }

    // Zoek de byte vóór het punt waarop de body-loop is gestopt.
    text[..offset].iter().rposition(|elt| *elt == x)
}