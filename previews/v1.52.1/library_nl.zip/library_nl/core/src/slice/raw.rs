//! Gratis functies om `&[T]` en `&mut [T]` te maken.

use crate::array;
use crate::intrinsics::is_aligned_and_not_null;
use crate::mem;
use crate::ptr;

/// Vormt een segment van een aanwijzer en een lengte.
///
/// Het `len`-argument is het aantal **elementen**, niet het aantal bytes.
///
/// # Safety
///
/// Gedrag is niet gedefinieerd als een van de volgende voorwaarden wordt geschonden:
///
/// * `data` moet [valid] zijn voor leesbewerkingen voor `len * mem::size_of::<T>()` veel bytes, en het moet correct zijn uitgelijnd.Dit betekent in het bijzonder:
///
///     * Het volledige geheugenbereik van deze slice moet zich in een enkel toegewezen object bevinden!
///       Segmenten kunnen nooit meerdere toegewezen objecten omvatten.Zie [below](#incorrect-usage) voor een voorbeeld dat hier ten onrechte geen rekening mee houdt.
///     * `data` moet niet nul zijn en uitgelijnd, zelfs voor segmenten met lengte nul.
///     Een reden hiervoor is dat optimalisaties van de lay-out van de opsomming mogelijk afhankelijk zijn van verwijzingen (inclusief segmenten van elke lengte) die zijn uitgelijnd en niet nul zijn om ze te onderscheiden van andere gegevens.
///     U kunt een aanwijzer verkrijgen die bruikbaar is als `data` voor segmenten met een lengte van nul met behulp van [`NonNull::dangling()`].
///
/// * `data` moet verwijzen naar `len` opeenvolgende correct geïnitialiseerde waarden van het type `T`.
///
/// * Het geheugen waarnaar wordt verwezen door het geretourneerde segment mag niet worden gemuteerd gedurende de levensduur `'a`, behalve binnen een `UnsafeCell`.
///
/// * De totale grootte `len * mem::size_of::<T>()` van het segment mag niet groter zijn dan `isize::MAX`.
///   Zie de veiligheidsdocumentatie van [`pointer::offset`].
///
/// # Caveat
///
/// De levensduur van het geretourneerde segment wordt afgeleid uit het gebruik ervan.
/// Om onbedoeld misbruik te voorkomen, wordt aangeraden om de levensduur te koppelen aan de levensduur van de bron die veilig is in de context, bijvoorbeeld door een hulpfunctie te bieden die de levensduur van een hostwaarde voor de slice neemt, of door expliciete annotatie.
///
///
/// # Examples
///
/// ```
/// use std::slice;
///
/// // manifesteren een segment voor een enkel element
/// let x = 42;
/// let ptr = &x as *const _;
/// let slice = unsafe { slice::from_raw_parts(ptr, 1) };
/// assert_eq!(slice[0], 42);
/// ```
///
/// ### Onjuist gebruik
///
/// De volgende `join_slices`-functie is **ongezond** ⚠️
///
/// ```rust,no_run
/// use std::slice;
///
/// fn join_slices<'a, T>(fst: &'a [T], snd: &'a [T]) -> &'a [T] {
///     let fst_end = fst.as_ptr().wrapping_add(fst.len());
///     let snd_start = snd.as_ptr();
///     assert_eq!(fst_end, snd_start, "Slices must be contiguous!");
///     unsafe {
///         // De bovenstaande bewering zorgt ervoor dat `fst` en `snd` aaneengesloten zijn, maar ze kunnen zich nog steeds in _different allocated objects_ bevinden, in welk geval het maken van deze slice een ongedefinieerd gedrag is.
/////
/////
///         slice::from_raw_parts(fst.as_ptr(), fst.len() + snd.len())
///     }
/// }
///
/// fn main() {
///     // `a` en `b` zijn verschillende toegewezen objecten ...
///     let a = 42;
///     let b = 27;
///     // ... die niettemin aaneengesloten in het geheugen kunnen worden opgemaakt: |een |b |
///     let _ = join_slices(slice::from_ref(&a), slice::from_ref(&b)); // UB
/// }
/// ```
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts<'a, T>(data: *const T, len: usize) -> &'a [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // VEILIGHEID: de beller moet zich houden aan het veiligheidscontract voor `from_raw_parts`.
    unsafe { &*ptr::slice_from_raw_parts(data, len) }
}

/// Voert dezelfde functionaliteit uit als [`from_raw_parts`], behalve dat een veranderlijk segment wordt geretourneerd.
///
/// # Safety
///
/// Gedrag is niet gedefinieerd als een van de volgende voorwaarden wordt geschonden:
///
/// * `data` moet [valid] zijn voor zowel lees-als schrijfbewerkingen voor `len * mem::size_of::<T>()` vele bytes, en het moet correct zijn uitgelijnd.Dit betekent in het bijzonder:
///
///     * Het volledige geheugenbereik van deze slice moet zich in een enkel toegewezen object bevinden!
///       Segmenten kunnen nooit meerdere toegewezen objecten omvatten.
///     * `data` moet niet nul zijn en uitgelijnd, zelfs voor segmenten met lengte nul.
///     Een reden hiervoor is dat optimalisaties van de lay-out van de opsomming mogelijk afhankelijk zijn van verwijzingen (inclusief segmenten van elke lengte) die zijn uitgelijnd en niet nul zijn om ze te onderscheiden van andere gegevens.
///
///     U kunt een aanwijzer verkrijgen die bruikbaar is als `data` voor segmenten met een lengte van nul met behulp van [`NonNull::dangling()`].
///
/// * `data` moet verwijzen naar `len` opeenvolgende correct geïnitialiseerde waarden van het type `T`.
///
/// * Het geheugen waarnaar door het geretourneerde segment wordt verwezen, mag gedurende de levensduur `'a` niet worden geopend via een andere aanwijzer (niet afgeleid van de geretourneerde waarde).
///   Zowel lees-als schrijftoegang is verboden.
///
/// * De totale grootte `len * mem::size_of::<T>()` van het segment mag niet groter zijn dan `isize::MAX`.
///   Zie de veiligheidsdocumentatie van [`pointer::offset`].
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts_mut<'a, T>(data: *mut T, len: usize) -> &'a mut [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // VEILIGHEID: de beller moet zich houden aan het veiligheidscontract voor `from_raw_parts_mut`.
    unsafe { &mut *ptr::slice_from_raw_parts_mut(data, len) }
}

/// Converteert een verwijzing naar T naar een plak met lengte 1 (zonder te kopiëren).
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_ref<T>(s: &T) -> &[T] {
    array::from_ref(s)
}

/// Converteert een verwijzing naar T naar een plak met lengte 1 (zonder te kopiëren).
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_mut<T>(s: &mut T) -> &mut [T] {
    array::from_mut(s)
}