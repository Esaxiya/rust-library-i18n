//! Segmenten sorteren
//!
//! Deze module bevat een sorteeralgoritme gebaseerd op Orson Peters 'patroonvernietigende quicksort, gepubliceerd op: <https://github.com/orlp/pdqsort>
//!
//!
//! Onstabiel sorteren is compatibel met libcore omdat het geen geheugen toewijst, in tegenstelling tot onze stabiele sorteerimplementatie.
//!

// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// Wanneer ze worden verwijderd, worden kopieën van `src` naar `dest`.
struct CopyOnDrop<T> {
    src: *mut T,
    dest: *mut T,
}

impl<T> Drop for CopyOnDrop<T> {
    fn drop(&mut self) {
        // VEILIGHEID: Dit is een helper class.
        //          Raadpleeg het gebruik voor de juistheid.
        //          Men moet er namelijk zeker van zijn dat `src` en `dst` elkaar niet overlappen, zoals vereist door `ptr::copy_nonoverlapping`.
        unsafe {
            ptr::copy_nonoverlapping(self.src, self.dest, 1);
        }
    }
}

/// Verschuift het eerste element naar rechts totdat het een groter of gelijk element tegenkomt.
fn shift_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // VEILIGHEID: De onveilige bewerkingen hieronder omvatten indexering zonder een gebonden controle (`get_unchecked` en `get_unchecked_mut`)
    // en het kopiëren van geheugen (`ptr::copy_nonoverlapping`).
    //
    // een.Indexering:
    //  1. We hebben de grootte van de array gecontroleerd op>=2.
    //  2. Al het indexeren dat we zullen doen is altijd tussen maximaal {0 <= index < len}.
    //
    // b.Geheugen kopiëren
    //  1. We krijgen verwijzingen naar referenties die gegarandeerd geldig zijn.
    //  2. Ze kunnen elkaar niet overlappen omdat we verwijzingen krijgen naar verschilindices van de plak.
    //     Namelijk `i` en `i-1`.
    //  3. Als de plak correct is uitgelijnd, zijn de elementen correct uitgelijnd.
    //     Het is de verantwoordelijkheid van de beller om ervoor te zorgen dat de slice correct is uitgelijnd.
    //
    // Zie opmerkingen hieronder voor meer informatie.
    unsafe {
        // Als de eerste twee elementen niet in orde zijn ...
        if len >= 2 && is_less(v.get_unchecked(1), v.get_unchecked(0)) {
            // Lees het eerste element in een aan een stapel toegewezen variabele.
            // Als een volgende vergelijkingsoperatie panics, wordt `hole` verwijderd en wordt het element automatisch terug in de slice geschreven.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(0)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(1) };
            ptr::copy_nonoverlapping(v.get_unchecked(1), v.get_unchecked_mut(0), 1);

            for i in 2..len {
                if !is_less(v.get_unchecked(i), &*tmp) {
                    break;
                }

                // Verplaats 'i' element een plaats naar links, waardoor het gat naar rechts verschuift.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i - 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` wordt gedropt en kopieert dus `tmp` naar het resterende gat in `v`.
        }
    }
}

/// Verschuift het laatste element naar links totdat het een kleiner of gelijk element tegenkomt.
fn shift_tail<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // VEILIGHEID: De onveilige bewerkingen hieronder omvatten indexering zonder een gebonden controle (`get_unchecked` en `get_unchecked_mut`)
    // en het kopiëren van geheugen (`ptr::copy_nonoverlapping`).
    //
    // een.Indexering:
    //  1. We hebben de grootte van de array gecontroleerd op>=2.
    //  2. Al het indexeren dat we zullen doen is altijd tussen maximaal `0 <= index < len-1`.
    //
    // b.Geheugen kopiëren
    //  1. We krijgen verwijzingen naar referenties die gegarandeerd geldig zijn.
    //  2. Ze kunnen elkaar niet overlappen omdat we verwijzingen krijgen naar verschilindices van de plak.
    //     Namelijk `i` en `i+1`.
    //  3. Als de plak correct is uitgelijnd, zijn de elementen correct uitgelijnd.
    //     Het is de verantwoordelijkheid van de beller om ervoor te zorgen dat de slice correct is uitgelijnd.
    //
    // Zie opmerkingen hieronder voor meer informatie.
    unsafe {
        // Als de laatste twee elementen niet in orde zijn ...
        if len >= 2 && is_less(v.get_unchecked(len - 1), v.get_unchecked(len - 2)) {
            // Lees het laatste element in een aan een stapel toegewezen variabele.
            // Als een volgende vergelijkingsoperatie panics, wordt `hole` verwijderd en wordt het element automatisch terug in de slice geschreven.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(len - 1)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(len - 2) };
            ptr::copy_nonoverlapping(v.get_unchecked(len - 2), v.get_unchecked_mut(len - 1), 1);

            for i in (0..len - 2).rev() {
                if !is_less(&*tmp, v.get_unchecked(i)) {
                    break;
                }

                // Verplaats 'i' element een plaats naar rechts, waardoor het gat naar links verschuift.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i + 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` wordt gedropt en kopieert dus `tmp` naar het resterende gat in `v`.
        }
    }
}

/// Sorteert een plak gedeeltelijk door verschillende niet in de juiste volgorde geplaatste elementen te verschuiven.
///
/// Retourneert `true` als het segment aan het einde is gesorteerd.Deze functie is *O*(*n*) in het slechtste geval.
#[cold]
fn partial_insertion_sort<T, F>(v: &mut [T], is_less: &mut F) -> bool
where
    F: FnMut(&T, &T) -> bool,
{
    // Maximumaantal aangrenzende niet-werkende paren dat wordt verschoven.
    const MAX_STEPS: usize = 5;
    // Als de slice korter is, verplaats dan geen elementen.
    const SHORTEST_SHIFTING: usize = 50;

    let len = v.len();
    let mut i = 1;

    for _ in 0..MAX_STEPS {
        // VEILIGHEID: We hebben de gebonden controle al expliciet gedaan met `i < len`.
        // Al onze daaropvolgende indexeringen zijn alleen in het bereik `0 <= index < len`
        unsafe {
            // Zoek het volgende paar aangrenzende buiten dienst gestelde elementen.
            while i < len && !is_less(v.get_unchecked(i), v.get_unchecked(i - 1)) {
                i += 1;
            }
        }

        // Zijn we klaar?
        if i == len {
            return true;
        }

        // Verplaats geen elementen op korte arrays, dat heeft prestatiekosten.
        if len < SHORTEST_SHIFTING {
            return false;
        }

        // Verwissel het gevonden paar elementen.Dit plaatst ze in de juiste volgorde.
        v.swap(i - 1, i);

        // Schuif het kleinere element naar links.
        shift_tail(&mut v[..i], is_less);
        // Schuif het grotere element naar rechts.
        shift_head(&mut v[i..], is_less);
    }

    // Het lukte niet om de plak in het beperkte aantal stappen te sorteren.
    false
}

/// Sorteert een segment met behulp van invoegsortering, wat *O*(*n*^ 2) in het slechtste geval is.
fn insertion_sort<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    for i in 1..v.len() {
        shift_tail(&mut v[..i + 1], is_less);
    }
}

/// Sorteert `v` met behulp van heapsort, wat *O*(*n*\*log(* n*)) worst-case.
#[cold]
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub fn heapsort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Deze binaire heap respecteert de invariante `parent >= child`.
    let mut sift_down = |v: &mut [T], mut node| {
        loop {
            // Kinderen van `node`:
            let left = 2 * node + 1;
            let right = 2 * node + 2;

            // Kies het grotere kind.
            let greater =
                if right < v.len() && is_less(&v[left], &v[right]) { right } else { left };

            // Stop als de invariant op `node` blijft.
            if greater >= v.len() || !is_less(&v[node], &v[greater]) {
                break;
            }

            // Verwissel `node` met het grotere kind, beweeg een stap naar beneden en ga verder met zeven.
            v.swap(node, greater);
            node = greater;
        }
    };

    // Bouw de hoop op in lineaire tijd.
    for i in (0..v.len() / 2).rev() {
        sift_down(v, i);
    }

    // Haal maximale elementen uit de hoop.
    for i in (1..v.len()).rev() {
        v.swap(0, i);
        sift_down(&mut v[..i], 0);
    }
}

/// Partities `v` in elementen kleiner dan `pivot`, gevolgd door elementen groter dan of gelijk aan `pivot`.
///
///
/// Retourneert het aantal elementen kleiner dan `pivot`.
///
/// Het partitioneren wordt blok voor blok uitgevoerd om de kosten van vertakkingsoperaties te minimaliseren.
/// Dit idee wordt gepresenteerd in de [BlockQuicksort][pdf]-paper.
///
/// [pdf]: http://drops.dagstuhl.de/opus/volltexte/2016/6389/pdf/LIPIcs-ESA-2016-38.pdf
fn partition_in_blocks<T, F>(v: &mut [T], pivot: &T, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // Aantal elementen in een typisch blok.
    const BLOCK: usize = 128;

    // Het partitioneringsalgoritme herhaalt de volgende stappen totdat het is voltooid:
    //
    // 1. Traceer een blok vanaf de linkerkant om elementen te identificeren die groter zijn dan of gelijk zijn aan het draaipunt.
    // 2. Traceer een blok vanaf de rechterkant om elementen te identificeren die kleiner zijn dan het draaipunt.
    // 3. Verwissel de geïdentificeerde elementen tussen de linker-en rechterkant.
    //
    // We bewaren de volgende variabelen voor een blok elementen:
    //
    // 1. `block` - Aantal elementen in het blok.
    // 2. `start` - Start de aanwijzer in de `offsets`-array.
    // 3. `end` - Eindaanwijzer in de `offsets`-array.
    // 4. `offsets, indices van buiten gebruik gestelde elementen binnen het blok.

    // Het huidige blok aan de linkerkant (van `l` tot `l.add(block_l)`).
    let mut l = v.as_mut_ptr();
    let mut block_l = BLOCK;
    let mut start_l = ptr::null_mut();
    let mut end_l = ptr::null_mut();
    let mut offsets_l = [MaybeUninit::<u8>::uninit(); BLOCK];

    // Het huidige blok aan de rechterkant (van `r.sub(block_r)` to `r`).
    // VEILIGHEID: De documentatie voor .add() vermeldt specifiek dat `vec.as_ptr().add(vec.len())` altijd veilig is`
    let mut r = unsafe { l.add(v.len()) };
    let mut block_r = BLOCK;
    let mut start_r = ptr::null_mut();
    let mut end_r = ptr::null_mut();
    let mut offsets_r = [MaybeUninit::<u8>::uninit(); BLOCK];

    // FIXME: Als we VLA's krijgen, probeer dan in plaats daarvan een array met de lengte `min(v.len(), 2 * BLOCK) `te maken
    // dan twee arrays van vaste grootte met een lengte van `BLOCK`.VLA's zijn wellicht efficiënter voor het cachegeheugen.

    // Retourneert het aantal elementen tussen de aanwijzers `l` (inclusive) en `r` (exclusive).
    fn width<T>(l: *mut T, r: *mut T) -> usize {
        assert!(mem::size_of::<T>() > 0);
        (r as usize - l as usize) / mem::size_of::<T>()
    }

    loop {
        // We zijn klaar met het blok voor blok partitioneren als `l` en `r` heel dichtbij komen.
        // Daarna doen we wat patch-up werk om de resterende elementen ertussen te verdelen.
        let is_done = width(l, r) <= 2 * BLOCK;

        if is_done {
            // Aantal resterende elementen (nog steeds niet vergeleken met het draaipunt).
            let mut rem = width(l, r);
            if start_l < end_l || start_r < end_r {
                rem -= BLOCK;
            }

            // Pas de blokgroottes aan zodat het linker-en rechterblok elkaar niet overlappen, maar perfect uitgelijnd worden om de hele resterende opening te bedekken.
            //
            if start_l < end_l {
                block_r = rem;
            } else if start_r < end_r {
                block_l = rem;
            } else {
                block_l = rem / 2;
                block_r = rem - block_l;
            }
            debug_assert!(block_l <= BLOCK && block_r <= BLOCK);
            debug_assert!(width(l, r) == block_l + block_r);
        }

        if start_l == end_l {
            // Traceer `block_l`-elementen vanaf de linkerkant.
            start_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            end_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            let mut elem = l;

            for i in 0..block_l {
                // VEILIGHEID: De onderstaande onveiligheidsoperaties hebben betrekking op het gebruik van de `offset`.
                //         Volgens de voorwaarden die door de functie worden vereist, voldoen we eraan omdat:
                //         1. `offsets_l` is stack-toegewezen, en dus beschouwd als een afzonderlijk toegewezen object.
                //         2. De functie `is_less` retourneert een `bool`.
                //            Het casten van een `bool` zal `isize` nooit overstromen.
                //         3. We hebben gegarandeerd dat `block_l` `<= BLOCK` zal zijn.
                //            Bovendien was `end_l` aanvankelijk ingesteld op de beginpointer van `offsets_` die op de stapel werd gedeclareerd.
                //            We weten dus dat zelfs in het ergste geval (alle aanroepen van `is_less` retourneren false) we slechts maximaal 1 byte voorbij het einde zullen zijn.
                //        Een andere onveiligheidsoperatie hier is het derefereren van `elem`.
                //        `elem` was echter aanvankelijk de beginwijzer naar de slice, die altijd geldig is.
                unsafe {
                    // Branchless vergelijking.
                    *end_l = i as u8;
                    end_l = end_l.offset(!is_less(&*elem, pivot) as isize);
                    elem = elem.offset(1);
                }
            }
        }

        if start_r == end_r {
            // Traceer `block_r`-elementen vanaf de rechterkant.
            start_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            end_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            let mut elem = r;

            for i in 0..block_r {
                // VEILIGHEID: De onderstaande onveiligheidsoperaties hebben betrekking op het gebruik van de `offset`.
                //         Volgens de voorwaarden die door de functie worden vereist, voldoen we eraan omdat:
                //         1. `offsets_r` is stack-toegewezen, en dus beschouwd als een afzonderlijk toegewezen object.
                //         2. De functie `is_less` retourneert een `bool`.
                //            Het casten van een `bool` zal `isize` nooit overstromen.
                //         3. We hebben gegarandeerd dat `block_r` `<= BLOCK` zal zijn.
                //            Bovendien was `end_r` aanvankelijk ingesteld op de beginpointer van `offsets_` die op de stapel werd gedeclareerd.
                //            We weten dus dat zelfs in het ergste geval (alle aanroepen van `is_less` retourneren true) we slechts maximaal 1 byte voorbij het einde zullen zijn.
                //        Een andere onveiligheidsoperatie hier is het derefereren van `elem`.
                //        `elem` was echter aanvankelijk `1 *sizeof(T)` voorbij het einde en we verlagen het met `1* sizeof(T)` voordat we er toegang toe kregen.
                //        Bovendien werd beweerd dat `block_r` kleiner was dan `BLOCK` en `elem` zal daarom hoogstens naar het begin van de slice wijzen.
                unsafe {
                    // Branchless vergelijking.
                    elem = elem.offset(-1);
                    *end_r = i as u8;
                    end_r = end_r.offset(is_less(&*elem, pivot) as isize);
                }
            }
        }

        // Aantal niet-werkende elementen om te wisselen tussen de linker-en rechterkant.
        let count = cmp::min(width(start_l, end_l), width(start_r, end_r));

        if count > 0 {
            macro_rules! left {
                () => {
                    l.offset(*start_l as isize)
                };
            }
            macro_rules! right {
                () => {
                    r.offset(-(*start_r as isize) - 1)
                };
            }

            // In plaats van één paar tegelijk te verwisselen, is het efficiënter om een cyclische permutatie uit te voeren.
            // Dit is niet strikt gelijk aan omwisselen, maar levert een soortgelijk resultaat op met minder geheugenbewerkingen.
            //
            unsafe {
                let tmp = ptr::read(left!());
                ptr::copy_nonoverlapping(right!(), left!(), 1);

                for _ in 1..count {
                    start_l = start_l.offset(1);
                    ptr::copy_nonoverlapping(left!(), right!(), 1);
                    start_r = start_r.offset(1);
                    ptr::copy_nonoverlapping(right!(), left!(), 1);
                }

                ptr::copy_nonoverlapping(&tmp, right!(), 1);
                mem::forget(tmp);
                start_l = start_l.offset(1);
                start_r = start_r.offset(1);
            }
        }

        if start_l == end_l {
            // Alle out-of-order-elementen in het linkerblok zijn verplaatst.Ga naar het volgende blok.
            l = unsafe { l.offset(block_l as isize) };
        }

        if start_r == end_r {
            // Alle out-of-order-elementen in het rechterblok zijn verplaatst.Ga naar het vorige blok.
            r = unsafe { r.offset(-(block_r as isize)) };
        }

        if is_done {
            break;
        }
    }

    // Het enige dat nu overblijft is hoogstens één blok (links of rechts) met defecte elementen die moeten worden verplaatst.
    // Dergelijke resterende elementen kunnen eenvoudig naar het einde binnen hun blok worden verschoven.
    //

    if start_l < end_l {
        // Het linkerblok blijft.
        // Verplaats de resterende elementen die niet in de juiste volgorde staan, helemaal naar rechts.
        debug_assert_eq!(width(l, r), block_l);
        while start_l < end_l {
            unsafe {
                end_l = end_l.offset(-1);
                ptr::swap(l.offset(*end_l as isize), r.offset(-1));
                r = r.offset(-1);
            }
        }
        width(v.as_mut_ptr(), r)
    } else if start_r < end_r {
        // Het rechterblok blijft.
        // Verplaats de resterende elementen die niet in de juiste volgorde staan helemaal naar links.
        debug_assert_eq!(width(l, r), block_r);
        while start_r < end_r {
            unsafe {
                end_r = end_r.offset(-1);
                ptr::swap(l, r.offset(-(*end_r as isize) - 1));
                l = l.offset(1);
            }
        }
        width(v.as_mut_ptr(), l)
    } else {
        // Niets anders te doen, we zijn klaar.
        width(v.as_mut_ptr(), l)
    }
}

/// Partities `v` in elementen kleiner dan `v[pivot]`, gevolgd door elementen groter dan of gelijk aan `v[pivot]`.
///
///
/// Retourneert een tupel van:
///
/// 1. Aantal elementen kleiner dan `v[pivot]`.
/// 2. Waar als `v` al was gepartitioneerd.
fn partition<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    let (mid, was_partitioned) = {
        // Plaats het draaipunt aan het begin van de plak.
        v.swap(0, pivot);
        let (pivot, v) = v.split_at_mut(1);
        let pivot = &mut pivot[0];

        // Lees het draaipunt in een aan een stapel toegewezen variabele voor efficiëntie.
        // Als een volgende vergelijkingsoperatie panics is, wordt het draaipunt automatisch teruggeschreven in de slice.
        let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
        let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
        let pivot = &*tmp;

        // Zoek het eerste paar elementen die niet in de juiste volgorde staan.
        let mut l = 0;
        let mut r = v.len();

        // VEILIGHEID: De onderstaande onveiligheid betreft het indexeren van een array.
        // Voor de eerste: we controleren de grenzen hier al met `l < r`.
        // Voor de tweede: we hebben aanvankelijk `l == 0` en `r == v.len()` en we hebben die `l < r` bij elke indexeringsoperatie gecontroleerd.
        //                     Vanaf hier weten we dat `r` ten minste `r == l` moet zijn, waarvan werd aangetoond dat het geldig was vanaf de eerste.
        unsafe {
            // Zoek het eerste element dat groter is dan of gelijk is aan het draaipunt.
            while l < r && is_less(v.get_unchecked(l), pivot) {
                l += 1;
            }

            // Zoek het laatste element dat kleiner is dan het draaipunt.
            while l < r && !is_less(v.get_unchecked(r - 1), pivot) {
                r -= 1;
            }
        }

        (l + partition_in_blocks(&mut v[l..r], pivot, is_less), l >= r)

        // `_pivot_guard` gaat buiten het bereik en schrijft het draaipunt (dat een aan een stapel toegewezen variabele is) terug naar de plak waar het oorspronkelijk was.
        // Deze stap is cruciaal om de veiligheid te waarborgen!
        //
    };

    // Plaats het draaipunt tussen de twee partities.
    v.swap(0, mid);

    (mid, was_partitioned)
}

/// Partities `v` in elementen gelijk aan `v[pivot]` gevolgd door elementen groter dan `v[pivot]`.
///
/// Retourneert het aantal elementen dat gelijk is aan het draaipunt.
/// Aangenomen wordt dat `v` geen elementen bevat die kleiner zijn dan het draaipunt.
fn partition_equal<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // Plaats het draaipunt aan het begin van de plak.
    v.swap(0, pivot);
    let (pivot, v) = v.split_at_mut(1);
    let pivot = &mut pivot[0];

    // Lees het draaipunt in een aan een stapel toegewezen variabele voor efficiëntie.
    // Als een volgende vergelijkingsoperatie panics is, wordt het draaipunt automatisch teruggeschreven in de slice.
    // VEILIGHEID: De aanwijzer hier is geldig omdat deze wordt verkregen uit een verwijzing naar een segment.
    let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
    let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
    let pivot = &*tmp;

    // Verdeel nu de plak.
    let mut l = 0;
    let mut r = v.len();
    loop {
        // VEILIGHEID: De onderstaande onveiligheid betreft het indexeren van een array.
        // Voor de eerste: we controleren de grenzen hier al met `l < r`.
        // Voor de tweede: we hebben aanvankelijk `l == 0` en `r == v.len()` en we hebben die `l < r` bij elke indexeringsoperatie gecontroleerd.
        //                     Vanaf hier weten we dat `r` ten minste `r == l` moet zijn, waarvan werd aangetoond dat het geldig was vanaf de eerste.
        unsafe {
            // Zoek het eerste element dat groter is dan het draaipunt.
            while l < r && !is_less(pivot, v.get_unchecked(l)) {
                l += 1;
            }

            // Zoek het laatste element dat gelijk is aan het draaipunt.
            while l < r && is_less(pivot, v.get_unchecked(r - 1)) {
                r -= 1;
            }

            // Zijn we klaar?
            if l >= r {
                break;
            }

            // Verwissel het gevonden paar niet in de juiste volgorde geplaatste elementen.
            r -= 1;
            ptr::swap(v.get_unchecked_mut(l), v.get_unchecked_mut(r));
            l += 1;
        }
    }

    // We vonden `l`-elementen gelijk aan het draaipunt.Voeg 1 toe om rekening te houden met het draaipunt zelf.
    l + 1

    // `_pivot_guard` gaat buiten het bereik en schrijft het draaipunt (dat een aan een stapel toegewezen variabele is) terug naar de plak waar het oorspronkelijk was.
    // Deze stap is cruciaal om de veiligheid te waarborgen!
}

/// Verspreidt enkele elementen in een poging om patronen te doorbreken die onevenwichtige partities in quicksort kunnen veroorzaken.
///
#[cold]
fn break_patterns<T>(v: &mut [T]) {
    let len = v.len();
    if len >= 8 {
        // Pseudowillekeurige nummergenerator van het "Xorshift RNGs"-artikel van George Marsaglia.
        let mut random = len as u32;
        let mut gen_u32 = || {
            random ^= random << 13;
            random ^= random >> 17;
            random ^= random << 5;
            random
        };
        let mut gen_usize = || {
            if usize::BITS <= 32 {
                gen_u32() as usize
            } else {
                (((gen_u32() as u64) << 32) | (gen_u32() as u64)) as usize
            }
        };

        // Neem willekeurige getallen modulo dit getal.
        // Het nummer past in `usize` omdat `len` niet groter is dan `isize::MAX`.
        let modulus = len.next_power_of_two();

        // Sommige spilkandidaten bevinden zich in de buurt van deze index.Laten we ze willekeurig maken.
        let pos = len / 4 * 2;

        for i in 0..3 {
            // Genereer een willekeurig getal modulo `len`.
            // Om kostbare bewerkingen te vermijden, nemen we het eerst modulo een macht van twee, en verlagen het vervolgens met `len` totdat het in het bereik `[0, len - 1]` past.
            //
            let mut other = gen_usize() & (modulus - 1);

            // `other` is gegarandeerd kleiner dan `2 * len`.
            if other >= len {
                other -= len;
            }

            v.swap(pos - 1 + i, other);
        }
    }
}

/// Kiest een draaipunt in `v` en retourneert de index en `true` als het segment waarschijnlijk al is gesorteerd.
///
/// Elementen in `v` kunnen tijdens het proces opnieuw worden gerangschikt.
fn choose_pivot<T, F>(v: &mut [T], is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    // Minimale lengte om de mediaan-of-medianen-methode te kiezen.
    // Kortere segmenten gebruiken de eenvoudige mediaan-van-drie-methode.
    const SHORTEST_MEDIAN_OF_MEDIANS: usize = 50;
    // Maximaal aantal swaps dat in deze functie kan worden uitgevoerd.
    const MAX_SWAPS: usize = 4 * 3;

    let len = v.len();

    // Drie indices waarbij we een spil gaan kiezen.
    let mut a = len / 4 * 1;
    let mut b = len / 4 * 2;
    let mut c = len / 4 * 3;

    // Telt het totale aantal swaps dat we gaan uitvoeren tijdens het sorteren van indices.
    let mut swaps = 0;

    if len >= 8 {
        // Wisselt indices zodat `v[a] <= v[b]`.
        let mut sort2 = |a: &mut usize, b: &mut usize| unsafe {
            if is_less(v.get_unchecked(*b), v.get_unchecked(*a)) {
                ptr::swap(a, b);
                swaps += 1;
            }
        };

        // Wisselt indices zodat `v[a] <= v[b] <= v[c]`.
        let mut sort3 = |a: &mut usize, b: &mut usize, c: &mut usize| {
            sort2(a, b);
            sort2(b, c);
            sort2(a, b);
        };

        if len >= SHORTEST_MEDIAN_OF_MEDIANS {
            // Vindt de mediaan van `v[a - 1], v[a], v[a + 1]` en slaat de index op in `a`.
            let mut sort_adjacent = |a: &mut usize| {
                let tmp = *a;
                sort3(&mut (tmp - 1), a, &mut (tmp + 1));
            };

            // Vind medianen in de buurt van `a`, `b` en `c`.
            sort_adjacent(&mut a);
            sort_adjacent(&mut b);
            sort_adjacent(&mut c);
        }

        // Zoek de mediaan tussen `a`, `b` en `c`.
        sort3(&mut a, &mut b, &mut c);
    }

    if swaps < MAX_SWAPS {
        (b, swaps == 0)
    } else {
        // Het maximale aantal swaps is uitgevoerd.
        // De kans is groot dat de slice daalt of grotendeels daalt, dus omkeren zal waarschijnlijk helpen om het sneller te sorteren.
        v.reverse();
        (len - 1 - b, true)
    }
}

/// Sorteert `v` recursief.
///
/// Als de slice een voorganger had in de originele array, wordt deze gespecificeerd als `pred`.
///
/// `limit` is het aantal toegestane ongebalanceerde partities voordat wordt overgeschakeld naar `heapsort`.
/// Indien nul, schakelt deze functie onmiddellijk over naar heapsort.
fn recurse<'a, T, F>(mut v: &'a mut [T], is_less: &mut F, mut pred: Option<&'a T>, mut limit: u32)
where
    F: FnMut(&T, &T) -> bool,
{
    // Segmenten tot deze lengte worden gesorteerd met behulp van invoegsortering.
    const MAX_INSERTION: usize = 20;

    // Waar als de laatste partitionering redelijk in evenwicht was.
    let mut was_balanced = true;
    // Waar als de laatste partitionering de elementen niet door elkaar heeft geschud (het segment was al gepartitioneerd).
    let mut was_partitioned = true;

    loop {
        let len = v.len();

        // Zeer korte plakjes worden gesorteerd met invoegsortering.
        if len <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // Als er te veel slechte draaischijfkeuzes zijn gemaakt, ga dan gewoon terug naar Heapsort om de `O(n * log(n))` in het slechtste geval te garanderen.
        //
        if limit == 0 {
            heapsort(v, is_less);
            return;
        }

        // Als de laatste partitionering onevenwichtig was, probeer dan patronen in de slice te doorbreken door enkele elementen in het rond te schudden.
        // Hopelijk kiezen we deze keer voor een beter draaipunt.
        if !was_balanced {
            break_patterns(v);
            limit -= 1;
        }

        // Kies een draaipunt en probeer te raden of het segment al is gesorteerd.
        let (pivot, likely_sorted) = choose_pivot(v, is_less);

        // Als de laatste partitionering fatsoenlijk was uitgebalanceerd en de elementen niet door elkaar werden geschud, en als pivotselectie voorspelt, is de slice waarschijnlijk al gesorteerd ...
        //
        if was_balanced && was_partitioned && likely_sorted {
            // Probeer verschillende elementen die niet in de juiste volgorde staan te identificeren en ze naar de juiste posities te verplaatsen.
            // Als de plak uiteindelijk volledig is gesorteerd, zijn we klaar.
            if partial_insertion_sort(v, is_less) {
                return;
            }
        }

        // Als het gekozen draaipunt gelijk is aan de voorganger, dan is dit het kleinste element in de plak.
        // Verdeel het segment in elementen gelijk aan en elementen groter dan het draaipunt.
        // Dit geval treedt meestal op als de slice veel dubbele elementen bevat.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // Ga door met het sorteren van elementen die groter zijn dan het draaipunt.
                v = &mut { v }[mid..];
                continue;
            }
        }

        // Verdeel de plak.
        let (mid, was_p) = partition(v, pivot, is_less);
        was_balanced = cmp::min(mid, len - mid) >= len / 8;
        was_partitioned = was_p;

        // Splits het segment in `left`, `pivot` en `right`.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        // Herhaal alleen naar de korte zijde om het totale aantal recursieve oproepen te minimaliseren en minder stackruimte te verbruiken.
        // Ga dan gewoon verder met de langere zijde (dit lijkt op staartrecursie).
        //
        if left.len() < right.len() {
            recurse(left, is_less, pred, limit);
            v = right;
            pred = Some(pivot);
        } else {
            recurse(right, is_less, Some(pivot), limit);
            v = left;
        }
    }
}

/// Sorteert `v` met behulp van patroonvernietigende quicksort, wat *O*(*n*\*log(* n*)) worst-case.
pub fn quicksort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Sorteren heeft geen zinvol gedrag op typen met een grootte van nul.
    if mem::size_of::<T>() == 0 {
        return;
    }

    // Beperk het aantal onevenwichtige partities tot `floor(log2(len)) + 1`.
    let limit = usize::BITS - v.len().leading_zeros();

    recurse(v, &mut is_less, None, limit);
}

fn partition_at_index_loop<'a, T, F>(
    mut v: &'a mut [T],
    mut index: usize,
    is_less: &mut F,
    mut pred: Option<&'a T>,
) where
    F: FnMut(&T, &T) -> bool,
{
    loop {
        // Voor plakjes tot deze lengte is het waarschijnlijk sneller om ze eenvoudig te sorteren.
        const MAX_INSERTION: usize = 10;
        if v.len() <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // Kies een draaipunt
        let (pivot, _) = choose_pivot(v, is_less);

        // Als het gekozen draaipunt gelijk is aan de voorganger, dan is dit het kleinste element in de plak.
        // Verdeel het segment in elementen gelijk aan en elementen groter dan het draaipunt.
        // Dit geval treedt meestal op als de slice veel dubbele elementen bevat.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // Als we onze index zijn gepasseerd, zijn we goed.
                if mid > index {
                    return;
                }

                // Ga anders verder met het sorteren van elementen die groter zijn dan het draaipunt.
                v = &mut v[mid..];
                index = index - mid;
                pred = None;
                continue;
            }
        }

        let (mid, _) = partition(v, pivot, is_less);

        // Splits het segment in `left`, `pivot` en `right`.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        if mid < index {
            v = right;
            index = index - mid - 1;
            pred = Some(pivot);
        } else if mid > index {
            v = left;
        } else {
            // Als mid==index, dan zijn we klaar, aangezien partition() garandeerde dat alle elementen na mid groter of gelijk zijn aan mid.
            //
            return;
        }
    }
}

pub fn partition_at_index<T, F>(
    v: &mut [T],
    index: usize,
    mut is_less: F,
) -> (&mut [T], &mut T, &mut [T])
where
    F: FnMut(&T, &T) -> bool,
{
    use cmp::Ordering::Greater;
    use cmp::Ordering::Less;

    if index >= v.len() {
        panic!("partition_at_index index {} greater than length of slice {}", index, v.len());
    }

    if mem::size_of::<T>() == 0 {
        // Sorteren heeft geen zinvol gedrag op typen met een grootte van nul.Niets doen.
    } else if index == v.len() - 1 {
        // Zoek max-element en plaats het op de laatste positie van de array.
        // We zijn vrij om `unwrap()` hier te gebruiken omdat we weten dat v niet leeg mag zijn.
        let (max_index, _) = v
            .iter()
            .enumerate()
            .max_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(max_index, index);
    } else if index == 0 {
        // Zoek het min-element en plaats het in de eerste positie van de array.
        // We zijn vrij om `unwrap()` hier te gebruiken omdat we weten dat v niet leeg mag zijn.
        let (min_index, _) = v
            .iter()
            .enumerate()
            .min_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(min_index, index);
    } else {
        partition_at_index_loop(v, index, &mut is_less, None);
    }

    let (left, right) = v.split_at_mut(index);
    let (pivot, right) = right.split_at_mut(1);
    let pivot = &mut pivot[0];
    (left, pivot, right)
}