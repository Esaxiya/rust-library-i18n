//! Macro's die worden gebruikt door iterators van slice.

// Inlining is_empty en len maakt een enorm verschil in prestaties
macro_rules! is_empty {
    // De manier waarop we de lengte van een ZST-iterator coderen, werkt zowel voor ZST als niet-ZST.
    //
    ($self: ident) => {
        $self.ptr.as_ptr() as *const T == $self.end
    };
}

// Om enkele grenscontroles te verwijderen (zie `position`), berekenen we de lengte op een ietwat onverwachte manier.
// (Getest door `codegen/slice-position-bounds-check`.)
macro_rules! len {
    ($self: ident) => {{
        #![allow(unused_unsafe)] // we worden soms gebruikt in een onveilig blok

        let start = $self.ptr;
        let size = size_from_ptr(start.as_ptr());
        if size == 0 {
            // Deze _cannot_ gebruikt `unchecked_sub` omdat we afhankelijk zijn van wrapping om de lengte van lange ZST-slice-iterators weer te geven.
            //
            ($self.end as usize).wrapping_sub(start.as_ptr() as usize)
        } else {
            // We weten dat `start <= end`, dus het beter kan doen dan `offset_from`, die moet worden ondertekend.
            // Door hier de juiste vlaggen in te stellen, kunnen we LLVM dit vertellen, wat het helpt om grenscontroles te verwijderen.
            // VEILIGHEID: Door het type invariant, `start <= end`
            //
            let diff = unsafe { unchecked_sub($self.end as usize, start.as_ptr() as usize) };
            // Door LLVM ook te vertellen dat de pointers precies een veelvoud van de lettergrootte uit elkaar liggen, kan het `len() == 0` optimaliseren tot `start == end` in plaats van `(end - start) < size`.
            //
            // VEILIGHEID: Door het type invariant zijn de wijzers uitgelijnd zodat de
            //         afstand tussen hen moet een veelvoud van de grootte van de spitzen zijn
            //
            unsafe { exact_div(diff, size) }
        }
    }};
}

// De gedeelde definitie van de `Iter`-en `IterMut`-iteratoren
macro_rules! iterator {
    (
        struct $name:ident -> $ptr:ty,
        $elem:ty,
        $raw_mut:tt,
        {$( $mut_:tt )?},
        {$($extra:tt)*}
    ) => {
        // Retourneert het eerste element en verplaatst het begin van de iterator 1 naar voren.
        // Verbetert de prestaties aanzienlijk in vergelijking met een inline-functie.
        // De iterator mag niet leeg zijn.
        macro_rules! next_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.post_inc_start(1)}
        }

        // Retourneert het laatste element en verplaatst het einde van de iterator 1 achteruit.
        // Verbetert de prestaties aanzienlijk in vergelijking met een inline-functie.
        // De iterator mag niet leeg zijn.
        macro_rules! next_back_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.pre_dec_end(1)}
        }

        // Verkleint de iterator wanneer T een ZST is, door het einde van de iterator `n` naar achteren te verplaatsen.
        // `n` mag niet groter zijn dan `self.len()`.
        macro_rules! zst_shrink {
            ($self: ident, $n: ident) => {
                $self.end = ($self.end as * $raw_mut u8).wrapping_offset(-$n) as * $raw_mut T;
            }
        }

        impl<'a, T> $name<'a, T> {
            // Helperfunctie voor het maken van een segment van de iterator.
            #[inline(always)]
            fn make_slice(&self) -> &'a [T] {
                // VEILIGHEID: de iterator is gemaakt op basis van een plak met aanwijzer
                // `self.ptr` en lengte `len!(self)`.
                // Dit garandeert dat aan alle voorwaarden voor `from_raw_parts` is voldaan.
                unsafe { from_raw_parts(self.ptr.as_ptr(), len!(self)) }
            }

            // Helperfunctie om de start van de iterator naar voren te verplaatsen met `offset`-elementen, waardoor de oude start wordt hersteld.
            //
            // Onveilig omdat de offset niet groter mag zijn dan `self.len()`.
            #[inline(always)]
            unsafe fn post_inc_start(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    let old = self.ptr.as_ptr();
                    // VEILIGHEID: de beller garandeert dat `offset` niet groter is dan `self.len()`,
                    // dus deze nieuwe aanwijzer bevindt zich in `self` en is dus gegarandeerd niet-nul.
                    self.ptr = unsafe { NonNull::new_unchecked(self.ptr.as_ptr().offset(offset)) };
                    old
                }
            }

            // Helperfunctie om het einde van de iterator naar achteren te verplaatsen door `offset`-elementen, waardoor het nieuwe einde wordt geretourneerd.
            //
            // Onveilig omdat de offset niet groter mag zijn dan `self.len()`.
            #[inline(always)]
            unsafe fn pre_dec_end(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    // VEILIGHEID: de beller garandeert dat `offset` niet groter is dan `self.len()`,
                    // die gegarandeerd niet overloopt bij een `isize`.
                    // De resulterende aanwijzer bevindt zich ook binnen de grenzen van `slice`, die voldoet aan de andere vereisten voor `offset`.
                    self.end = unsafe { self.end.offset(-offset) };
                    self.end
                }
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T> ExactSizeIterator for $name<'_, T> {
            #[inline(always)]
            fn len(&self) -> usize {
                len!(self)
            }

            #[inline(always)]
            fn is_empty(&self) -> bool {
                is_empty!(self)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> Iterator for $name<'a, T> {
            type Item = $elem;

            #[inline]
            fn next(&mut self) -> Option<$elem> {
                // kan worden geïmplementeerd met plakjes, maar dit vermijdt grenscontroles

                // VEILIGHEID: `assume`-oproepen zijn veilig sinds de startwijzer van een slice
                // moet niet-nul zijn, en coupes over niet-ZST's moeten ook een niet-nul-eindpointer hebben.
                // De aanroep naar `next_unchecked!` is veilig omdat we eerst controleren of de iterator leeg is.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                let exact = len!(self);
                (exact, Some(exact))
            }

            #[inline]
            fn count(self) -> usize {
                len!(self)
            }

            #[inline]
            fn nth(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // Deze iterator is nu leeg.
                    if mem::size_of::<T>() == 0 {
                        // We moeten het op deze manier doen omdat `ptr` misschien nooit 0 is, maar `end` zou dat wel kunnen zijn (vanwege wrapping).
                        //
                        self.end = self.ptr.as_ptr();
                    } else {
                        // VEILIGHEID: end kan niet 0 zijn als T niet ZST is, omdat ptr niet 0 is en end>=ptr
                        unsafe {
                            self.ptr = NonNull::new_unchecked(self.end as *mut T);
                        }
                    }
                    return None;
                }
                // VEILIGHEID: We zijn binnen grenzen.`post_inc_start` doet zelfs voor ZST's het juiste.
                unsafe {
                    self.post_inc_start(n as isize);
                    Some(next_unchecked!(self))
                }
            }

            #[inline]
            fn last(mut self) -> Option<$elem> {
                self.next_back()
            }

            // We overschrijven de standaardimplementatie, die `try_fold` gebruikt, omdat deze eenvoudige implementatie minder LLVM-IR genereert en sneller kan worden gecompileerd.
            //
            //
            #[inline]
            fn for_each<F>(mut self, mut f: F)
            where
                Self: Sized,
                F: FnMut(Self::Item),
            {
                while let Some(x) = self.next() {
                    f(x);
                }
            }

            // We overschrijven de standaardimplementatie, die `try_fold` gebruikt, omdat deze eenvoudige implementatie minder LLVM-IR genereert en sneller kan worden gecompileerd.
            //
            //
            #[inline]
            fn all<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if !f(x) {
                        return false;
                    }
                }
                true
            }

            // We overschrijven de standaardimplementatie, die `try_fold` gebruikt, omdat deze eenvoudige implementatie minder LLVM-IR genereert en sneller kan worden gecompileerd.
            //
            //
            #[inline]
            fn any<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if f(x) {
                        return true;
                    }
                }
                false
            }

            // We overschrijven de standaardimplementatie, die `try_fold` gebruikt, omdat deze eenvoudige implementatie minder LLVM-IR genereert en sneller kan worden gecompileerd.
            //
            //
            #[inline]
            fn find<P>(&mut self, mut predicate: P) -> Option<Self::Item>
            where
                Self: Sized,
                P: FnMut(&Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if predicate(&x) {
                        return Some(x);
                    }
                }
                None
            }

            // We overschrijven de standaardimplementatie, die `try_fold` gebruikt, omdat deze eenvoudige implementatie minder LLVM-IR genereert en sneller kan worden gecompileerd.
            //
            //
            #[inline]
            fn find_map<B, F>(&mut self, mut f: F) -> Option<B>
            where
                Self: Sized,
                F: FnMut(Self::Item) -> Option<B>,
            {
                while let Some(x) = self.next() {
                    if let Some(y) = f(x) {
                        return Some(y);
                    }
                }
                None
            }

            // We overschrijven de standaardimplementatie, die `try_fold` gebruikt, omdat deze eenvoudige implementatie minder LLVM-IR genereert en sneller kan worden gecompileerd.
            // Ook vermijdt de `assume` een grenscontrole.
            //
            #[inline]
            #[rustc_inherit_overflow_checks]
            fn position<P>(&mut self, mut predicate: P) -> Option<usize> where
                Self: Sized,
                P: FnMut(Self::Item) -> bool,
            {
                let n = len!(self);
                let mut i = 0;
                while let Some(x) = self.next() {
                    if predicate(x) {
                        // VEILIGHEID: we zijn gegarandeerd binnen de grenzen van de lus-invariant:
                        // wanneer `i >= n`, `self.next()` `None` retourneert en de lus breekt.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                    i += 1;
                }
                None
            }

            // We overschrijven de standaardimplementatie, die `try_fold` gebruikt, omdat deze eenvoudige implementatie minder LLVM-IR genereert en sneller kan worden gecompileerd.
            // Ook vermijdt de `assume` een grenscontrole.
            //
            #[inline]
            fn rposition<P>(&mut self, mut predicate: P) -> Option<usize> where
                P: FnMut(Self::Item) -> bool,
                Self: Sized + ExactSizeIterator + DoubleEndedIterator
            {
                let n = len!(self);
                let mut i = n;
                while let Some(x) = self.next_back() {
                    i -= 1;
                    if predicate(x) {
                        // VEILIGHEID: `i` moet lager zijn dan `n` aangezien het begint bij `n`
                        // en neemt alleen maar af.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                }
                None
            }

            #[doc(hidden)]
            unsafe fn __iterator_get_unchecked(&mut self, idx: usize) -> Self::Item {
                // VEILIGHEID: de beller moet garanderen dat `i` binnen de grenzen van
                // de onderliggende slice, zodat `i` een `isize` niet kan overstromen, en de geretourneerde referenties verwijzen gegarandeerd naar een element van de slice en zijn dus gegarandeerd geldig.
                //
                // Merk ook op dat de beller ook garandeert dat we nooit meer met dezelfde index worden aangeroepen, en dat er geen andere methoden worden aangeroepen om toegang te krijgen tot dit subdeel, dus het is geldig dat de geretourneerde referentie veranderlijk is in het geval van
                //
                // `IterMut`
                //
                //
                //
                //
                unsafe { & $( $mut_ )? * self.ptr.as_ptr().add(idx) }
            }

            $($extra)*
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> DoubleEndedIterator for $name<'a, T> {
            #[inline]
            fn next_back(&mut self) -> Option<$elem> {
                // kan worden geïmplementeerd met plakjes, maar dit vermijdt grenscontroles

                // VEILIGHEID: `assume`-aanroepen zijn veilig omdat de startpointer van een slice niet nul mag zijn,
                // en plakjes over niet-ZST's moeten ook een eindpointer hebben die niet nul is.
                // De aanroep naar `next_back_unchecked!` is veilig omdat we eerst controleren of de iterator leeg is.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_back_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn nth_back(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // Deze iterator is nu leeg.
                    self.end = self.ptr.as_ptr();
                    return None;
                }
                // VEILIGHEID: We zijn binnen grenzen.`pre_dec_end` doet zelfs voor ZST's het juiste.
                unsafe {
                    self.pre_dec_end(n as isize);
                    Some(next_back_unchecked!(self))
                }
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<T> FusedIterator for $name<'_, T> {}

        #[unstable(feature = "trusted_len", issue = "37572")]
        unsafe impl<T> TrustedLen for $name<'_, T> {}
    }
}

macro_rules! forward_iterator {
    ($name:ident: $elem:ident, $iter_of:ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, $elem, P> Iterator for $name<'a, $elem, P>
        where
            P: FnMut(&T) -> bool,
        {
            type Item = $iter_of;

            #[inline]
            fn next(&mut self) -> Option<$iter_of> {
                self.inner.next()
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                self.inner.size_hint()
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<'a, $elem, P> FusedIterator for $name<'a, $elem, P> where P: FnMut(&T) -> bool {}
    };
}