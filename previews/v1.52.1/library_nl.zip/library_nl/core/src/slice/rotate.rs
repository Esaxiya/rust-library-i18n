// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// Roteert het bereik `[mid-left, mid+right)` zodat het element op `mid` het eerste element wordt.Op equivalente wijze worden de `left`-elementen van het bereik naar links of `right`-elementen naar rechts geroteerd.
///
/// # Safety
///
/// Het opgegeven bereik moet geldig zijn voor lezen en schrijven.
///
/// # Algorithm
///
/// Algoritme 1 wordt gebruikt voor kleine waarden van `left + right` of voor grote `T`.
/// De elementen worden één voor één naar hun eindposities verplaatst, beginnend bij `mid - left` en verder door `right`-stappen modulo `left + right`, zodat er slechts één tijdelijk nodig is.
/// Uiteindelijk komen we terug bij `mid - left`.
/// Als `gcd(left + right, right)` echter niet 1 is, worden in de bovenstaande stappen elementen overgeslagen.
/// Bijvoorbeeld:
///
/// ```text
/// left = 10, right = 6
/// the `^` indicates an element in its final place
/// 6 7 8 9 10 11 12 13 14 15 . 0 1 2 3 4 5
/// after using one step of the above algorithm (The X will be overwritten at the end of the round,
/// and 12 is stored in a temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 2 3 4 5
///               ^
/// after using another step (now 2 is in the temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///               ^                 ^
/// after the third step (the steps wrap around, and 8 is in the temporary):
/// X 7 2 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///     ^         ^                 ^
/// after 7 more steps, the round ends with the temporary 0 getting put in the X:
/// 0 7 2 9 4 11 6 13 8 15 . 10 1 12 3 14 5
/// ^   ^   ^    ^    ^       ^    ^    ^
/// ```
///
/// Gelukkig is het aantal overgeslagen elementen tussen voltooide elementen altijd gelijk, dus we kunnen gewoon onze startpositie compenseren en meer rondes doen (het totale aantal rondes is de `gcd(left + right, right)` value).
///
/// Het eindresultaat is dat alle elementen één keer en slechts één keer worden afgerond.
///
/// Algoritme 2 wordt gebruikt als `left + right` groot is, maar `min(left, right)` klein genoeg om in een stapelbuffer te passen.
/// De `min(left, right)`-elementen worden naar de buffer gekopieerd, `memmove` wordt op de andere toegepast en de elementen op de buffer worden teruggeplaatst in het gat aan de andere kant van waar ze vandaan kwamen.
///
/// Algoritmen die kunnen worden gevectoriseerd, presteren beter dan het bovenstaande zodra `left + right` groot genoeg wordt.
/// Algoritme 1 kan worden gevectoriseerd door meerdere ronden tegelijk te chunken en uit te voeren, maar er zijn gemiddeld te weinig ronden totdat `left + right` enorm is, en het ergste geval van een enkele ronde is er altijd.
/// In plaats daarvan gebruikt algoritme 3 het herhaaldelijk verwisselen van `min(left, right)`-elementen totdat er een kleiner rotatieprobleem overblijft.
///
/// ```text
/// left = 11, right = 4
/// [4 5 6 7 8 9 10 11 12 13 14 . 0 1 2 3]
///                  ^  ^  ^  ^   ^ ^ ^ ^ swapping the right most elements with elements to the left
/// [4 5 6 7 8 9 10 . 0 1 2 3] 11 12 13 14
///        ^ ^ ^  ^   ^ ^ ^ ^ swapping these
/// [4 5 6 . 0 1 2 3] 7 8 9 10 11 12 13 14
/// we cannot swap any more, but a smaller rotation problem is left to solve
/// ```
/// bij `left < right` gebeurt het wisselen van links.
///
///
///
///
///
pub unsafe fn ptr_rotate<T>(mut left: usize, mut mid: *mut T, mut right: usize) {
    type BufType = [usize; 32];
    if mem::size_of::<T>() == 0 {
        return;
    }
    loop {
        // N.B. de onderstaande algoritmen kunnen mislukken als deze gevallen niet worden gecontroleerd
        if (right == 0) || (left == 0) {
            return;
        }
        if (left + right < 24) || (mem::size_of::<T>() > mem::size_of::<[usize; 4]>()) {
            // Algoritme 1 Microbenchmarks geven aan dat de gemiddelde prestatie voor willekeurige verschuivingen tot ongeveer `left + right == 32` beter is, maar de slechtste prestatie zelfs rond de 16.
            // 24 werd gekozen als middenweg.
            // Als de grootte van `T` groter is dan 4 `usize`s, presteert dit algoritme ook beter dan andere algoritmen.
            //
            //
            let x = unsafe { mid.sub(left) };
            // begin van de eerste ronde
            let mut tmp: T = unsafe { x.read() };
            let mut i = right;
            // `gcd` kan van tevoren worden gevonden door `gcd(left + right, right)` te berekenen, maar het is sneller om één lus te maken die de gcd als bijwerking berekent, en dan de rest van het stuk te doen
            //
            //
            let mut gcd = right;
            // benchmarks laten zien dat het sneller is om tijdelijke bestanden helemaal door te wisselen in plaats van één tijdelijke tekst één keer te lezen, achteruit te kopiëren en die tijdelijke helemaal aan het einde te schrijven.
            // Dit is mogelijk te wijten aan het feit dat het wisselen of vervangen van tijdelijke bestanden slechts één geheugenadres in de lus gebruikt in plaats van er twee te moeten beheren.
            //
            //
            loop {
                tmp = unsafe { x.add(i).replace(tmp) };
                // in plaats van `i` te verhogen en vervolgens te controleren of het buiten de grenzen valt, kijken we of `i` bij de volgende stap buiten de grenzen valt.
                // Dit voorkomt het omwikkelen van pointers of `usize`.
                //
                if i >= left {
                    i -= left;
                    if i == 0 {
                        // einde van de eerste ronde
                        unsafe { x.write(tmp) };
                        break;
                    }
                    // deze voorwaarde moet hier zijn als `left + right >= 15`
                    if i < gcd {
                        gcd = i;
                    }
                } else {
                    i += right;
                }
            }
            // maak het stuk af met meer rondes
            for start in 1..gcd {
                tmp = unsafe { x.add(start).read() };
                i = start + right;
                loop {
                    tmp = unsafe { x.add(i).replace(tmp) };
                    if i >= left {
                        i -= left;
                        if i == start {
                            unsafe { x.add(start).write(tmp) };
                            break;
                        }
                    } else {
                        i += right;
                    }
                }
            }
            return;
        // `T` is geen type met een grootte van nul, dus het is prima om te delen door de grootte.
        } else if cmp::min(left, right) <= mem::size_of::<BufType>() / mem::size_of::<T>() {
            // Algoritme 2 De `[T; 0]` hier is om ervoor te zorgen dat dit op de juiste manier is uitgelijnd voor T
            //
            let mut rawarray = MaybeUninit::<(BufType, [T; 0])>::uninit();
            let buf = rawarray.as_mut_ptr() as *mut T;
            let dim = unsafe { mid.sub(left).add(right) };
            if left <= right {
                unsafe {
                    ptr::copy_nonoverlapping(mid.sub(left), buf, left);
                    ptr::copy(mid, mid.sub(left), right);
                    ptr::copy_nonoverlapping(buf, dim, left);
                }
            } else {
                unsafe {
                    ptr::copy_nonoverlapping(mid, buf, right);
                    ptr::copy(mid.sub(left), dim, left);
                    ptr::copy_nonoverlapping(buf, mid.sub(left), right);
                }
            }
            return;
        } else if left >= right {
            // Algoritme 3 Er is een alternatieve manier om te ruilen, waarbij wordt gezocht naar waar de laatste ruil van dit algoritme zou zijn, en om te wisselen met behulp van dat laatste fragment in plaats van aangrenzende brokken te wisselen zoals dit algoritme doet, maar deze manier is nog steeds sneller.
            //
            //
            //
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(right), mid, right);
                    mid = mid.sub(right);
                }
                left -= right;
                if left < right {
                    break;
                }
            }
        } else {
            // Algoritme 3, `left < right`
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(left), mid, left);
                    mid = mid.add(left);
                }
                right -= left;
                if right < left {
                    break;
                }
            }
        }
    }
}