//! Bewerkingen op ASCII `[u8]`.

use crate::mem;

#[lang = "slice_u8"]
#[cfg(not(test))]
impl [u8] {
    /// Controleert of alle bytes in dit segment binnen het ASCII-bereik vallen.
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        is_ascii(self)
    }

    /// Controleert of twee segmenten een ASCII-hoofdletterongevoelige overeenkomst zijn.
    ///
    /// Hetzelfde als `to_ascii_lowercase(a) == to_ascii_lowercase(b)`, maar zonder tijdelijke bestanden toe te wijzen en te kopiëren.
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &[u8]) -> bool {
        self.len() == other.len() && self.iter().zip(other).all(|(a, b)| a.eq_ignore_ascii_case(b))
    }

    /// Zet dit segment ter plekke om naar het ASCII-equivalent in hoofdletters.
    ///
    /// ASCII-letters 'a' tot 'z' worden toegewezen aan 'A' tot 'Z', maar niet-ASCII-letters blijven ongewijzigd.
    ///
    /// Gebruik [`to_ascii_uppercase`] om een nieuwe waarde in hoofdletters te retourneren zonder de bestaande te wijzigen.
    ///
    ///
    /// [`to_ascii_uppercase`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        for byte in self {
            byte.make_ascii_uppercase();
        }
    }

    /// Converteert dit segment ter plekke naar het ASCII-equivalent in kleine letters.
    ///
    /// ASCII-letters 'A' tot 'Z' worden toegewezen aan 'a' tot 'z', maar niet-ASCII-letters blijven ongewijzigd.
    ///
    /// Gebruik [`to_ascii_lowercase`] om een nieuwe lagere waarde te retourneren zonder de bestaande te wijzigen.
    ///
    ///
    /// [`to_ascii_lowercase`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        for byte in self {
            byte.make_ascii_lowercase();
        }
    }
}

/// Geeft `true` terug als een byte in het woord `v` nonascii (>=128) is.
/// Gesnuffeld van `../str/mod.rs`, dat iets soortgelijks doet voor utf8-validatie.
#[inline]
fn contains_nonascii(v: usize) -> bool {
    const NONASCII_MASK: usize = 0x80808080_80808080u64 as usize;
    (NONASCII_MASK & v) != 0
}

/// Geoptimaliseerde ASCII-test die bewerkingen per keer gebruikt in plaats van bewerkingen per byte (indien mogelijk).
///
/// Het algoritme dat we hier gebruiken, is vrij eenvoudig.Als `s` te kort is, controleren we gewoon elke byte en zijn we er klaar mee.Anders:
///
/// - Lees het eerste woord met een niet-uitgelijnde lading.
/// - Lijn de aanwijzer uit, lees de volgende woorden tot het einde met uitgelijnde belastingen.
/// - Lees de laatste `usize` van `s` met een niet-uitgelijnde belasting.
///
/// Als een van deze ladingen iets produceert waarvoor `contains_nonascii` (above) true retourneert, weten we dat het antwoord onwaar is.
///
///
///
#[inline]
fn is_ascii(s: &[u8]) -> bool {
    const USIZE_SIZE: usize = mem::size_of::<usize>();

    let len = s.len();
    let align_offset = s.as_ptr().align_offset(USIZE_SIZE);

    // Als we niets zouden winnen van de woord-voor-een-tijd-implementatie, val dan terug op een scalaire lus.
    //
    // We doen dit ook voor architecturen waar `size_of::<usize>()` niet voldoende is uitgelijnd voor `usize`, omdat het een rare edge-zaak is.
    //
    //
    if len < USIZE_SIZE || len < align_offset || USIZE_SIZE < mem::align_of::<usize>() {
        return s.iter().all(|b| b.is_ascii());
    }

    // We lezen altijd het eerste woord niet uitgelijnd, wat betekent dat `align_offset` dat wel is
    // 0, zouden we dezelfde waarde opnieuw lezen voor de uitgelijnde uitlezing.
    let offset_to_aligned = if align_offset == 0 { USIZE_SIZE } else { align_offset };

    let start = s.as_ptr();
    // VEILIGHEID: We verifiëren `len < USIZE_SIZE` hierboven.
    let first_word = unsafe { (start as *const usize).read_unaligned() };

    if contains_nonascii(first_word) {
        return false;
    }
    // We hebben dit hierboven enigszins impliciet gecontroleerd.
    // Merk op dat `offset_to_aligned` `align_offset` of `USIZE_SIZE` is, beide worden hierboven expliciet aangevinkt.
    //
    debug_assert!(offset_to_aligned <= len);

    // VEILIGHEID: word_ptr is de (correct uitgelijnde) usize ptr die we gebruiken om de
    // middelste stuk van de plak.
    let mut word_ptr = unsafe { start.add(offset_to_aligned) as *const usize };

    // `byte_pos` is de byte-index van `word_ptr`, gebruikt voor lus-eindcontroles.
    let mut byte_pos = offset_to_aligned;

    // Paranoia controleert de uitlijning, aangezien we op het punt staan een aantal niet-uitgelijnde ladingen te doen.
    // In de praktijk zou dit echter onmogelijk moeten zijn, behoudens een bug in `align_offset`.
    //
    debug_assert_eq!((word_ptr as usize) % mem::align_of::<usize>(), 0);

    // Lees de volgende woorden tot het laatst uitgelijnde woord, met uitzondering van het laatst uitgelijnde woord op zichzelf om later in staartcontrole uit te voeren, om er zeker van te zijn dat de staart altijd één `usize` is tot maximaal branch `byte_pos == len` extra.
    //
    //
    while byte_pos < len - USIZE_SIZE {
        debug_assert!(
            // Controleer of het lezen binnen de perken is
            (word_ptr as usize + USIZE_SIZE) <= (start.wrapping_add(len) as usize) &&
            // En dat kloppen onze aannames over `byte_pos`.
            (word_ptr as usize) - (start as usize) == byte_pos
        );

        // VEILIGHEID: We weten dat de `word_ptr` correct is uitgelijnd (vanwege
        // `align_offset`), en we weten dat we genoeg bytes hebben tussen `word_ptr` en het einde
        let word = unsafe { word_ptr.read() };
        if contains_nonascii(word) {
            return false;
        }

        byte_pos += USIZE_SIZE;
        // VEILIGHEID: We kennen die `byte_pos <= len - USIZE_SIZE`, wat dat betekent
        // na deze `add` zal `word_ptr` hoogstens one-past-the-end zijn.
        word_ptr = unsafe { word_ptr.add(1) };
    }

    // Sanity check om er zeker van te zijn dat er echt maar één `usize` over is.
    // Dit moet worden gegarandeerd door onze lusconditie.
    debug_assert!(byte_pos <= len && len - byte_pos <= USIZE_SIZE);

    // VEILIGHEID: Dit is afhankelijk van `len >= USIZE_SIZE`, die we aan het begin controleren.
    let last_word = unsafe { (start.add(len - USIZE_SIZE) as *const usize).read_unaligned() };

    !contains_nonascii(last_word)
}