#![feature(no_core)]
#![no_core]

// Zie rustc-std-workspace-core voor waarom deze crate nodig is.

// Hernoem de crate om conflicten met de alloc-module in liballoc te voorkomen.
extern crate alloc as foo;

pub use foo::*;