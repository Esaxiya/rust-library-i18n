/// Maakt een [`Vec`] met de argumenten.
///
/// `vec!` staat toe dat `Vec`s worden gedefinieerd met dezelfde syntaxis als array-expressies.
/// Er zijn twee vormen van deze macro:
///
/// - Maak een [`Vec`] met een bepaalde lijst met elementen:
///
/// ```
/// let v = vec![1, 2, 3];
/// assert_eq!(v[0], 1);
/// assert_eq!(v[1], 2);
/// assert_eq!(v[2], 3);
/// ```
///
/// - Maak een [`Vec`] van een bepaald element en grootte:
///
/// ```
/// let v = vec![1; 3];
/// assert_eq!(v, [1, 1, 1]);
/// ```
///
/// Merk op dat in tegenstelling tot matrixuitdrukkingen deze syntaxis alle elementen ondersteunt die [`Clone`] implementeren en dat het aantal elementen geen constante hoeft te zijn.
///
/// Dit zal `clone` gebruiken om een uitdrukking te dupliceren, dus men moet voorzichtig zijn met het gebruik hiervan met typen met een niet-standaard `Clone`-implementatie.
/// Bijvoorbeeld `vec![Rc::new(1);5] `zal een vector maken van vijf verwijzingen naar dezelfde omkaderde integerwaarde, niet vijf verwijzingen naar onafhankelijk omkaderde gehele getallen.
///
///
/// Merk ook op dat `vec![expr; 0]` is toegestaan, en een lege vector produceert.
/// Dit zal echter nog steeds `expr` evalueren en de resulterende waarde onmiddellijk laten vallen, dus houd rekening met bijwerkingen.
///
/// [`Vec`]: crate::vec::Vec
///
///
///
///
///
#[cfg(not(test))]
#[doc(alias = "alloc")]
#[doc(alias = "malloc")]
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(box_syntax, liballoc_internals)]
macro_rules! vec {
    () => (
        $crate::__rust_force_expr!($crate::vec::Vec::new())
    );
    ($elem:expr; $n:expr) => (
        $crate::__rust_force_expr!($crate::vec::from_elem($elem, $n))
    );
    ($($x:expr),+ $(,)?) => (
        $crate::__rust_force_expr!(<[_]>::into_vec(box [$($x),+]))
    );
}

// HACK(japaric): met cfg(test) is de inherente `[T]::into_vec`-methode, die vereist is voor deze macrodefinitie, niet beschikbaar.
// Gebruik in plaats daarvan de `slice::into_vec`-functie die alleen beschikbaar is met cfg(test) NB zie de slice::hack-module in slice.rs voor meer informatie
//
//
#[cfg(test)]
macro_rules! vec {
    () => (
        $crate::vec::Vec::new()
    );
    ($elem:expr; $n:expr) => (
        $crate::vec::from_elem($elem, $n)
    );
    ($($x:expr),*) => (
        $crate::slice::into_vec(box [$($x),*])
    );
    ($($x:expr,)*) => (vec![$($x),*])
}

/// Creëert een `String` met behulp van interpolatie van runtime-expressies.
///
/// Het eerste argument dat `format!` ontvangt, is een opmaakreeks.Dit moet een letterlijke tekenreeks zijn.De kracht van de opmaakreeks zit in de `{}` s die zijn opgenomen.
///
/// Extra parameters die aan `format!` worden doorgegeven, vervangen de `{}` s in de opmaakstring in de opgegeven volgorde, tenzij benoemde of positionele parameters worden gebruikt;zie [`std::fmt`] voor meer informatie.
///
///
/// Een veelgebruikt gebruik voor `format!` is aaneenschakeling en interpolatie van strings.
/// Dezelfde conventie wordt gebruikt met [`print!`]-en [`write!`]-macro's, afhankelijk van de beoogde bestemming van de string.
///
/// Gebruik de [`to_string`]-methode om een enkele waarde naar een string te converteren.Dit zal de [`Display`]-opmaak trait gebruiken.
///
/// [`std::fmt`]: ../std/fmt/index.html
/// [`print!`]: ../std/macro.print.html
/// [`write!`]: core::write
/// [`to_string`]: crate::string::ToString
/// [`Display`]: core::fmt::Display
///
/// # Panics
///
/// `format!` panics als een opmaak van trait-implementatie een fout retourneert.
/// Dit duidt op een onjuiste implementatie, aangezien `fmt::Write for String` zelf nooit een fout retourneert.
///
/// # Examples
///
/// ```
/// format!("test");
/// format!("hello {}", "world!");
/// format!("x = {}, y = {y}", 10, y = 30);
/// ```
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "format_macro")]
macro_rules! format {
    ($($arg:tt)*) => {{
        let res = $crate::fmt::format($crate::__export::format_args!($($arg)*));
        res
    }}
}

/// Forceer AST-knoop naar een uitdrukking om de diagnostiek in patroonpositie te verbeteren.
#[doc(hidden)]
#[macro_export]
#[unstable(feature = "liballoc_internals", issue = "none", reason = "implementation detail")]
macro_rules! __rust_force_expr {
    ($e:expr) => {
        $e
    };
}