//! Aanwijzers voor het tellen van referenties met één thread.'Rc' staat voor 'Reference
//! Counted'.
//!
//! Het type [`Rc<T>`][`Rc`] biedt gedeeld eigendom van een waarde van het type `T`, toegewezen in de heap.
//! Het aanroepen van [`clone`][clone] op [`Rc`] produceert een nieuwe pointer naar dezelfde allocatie in de heap.
//! Wanneer de laatste [`Rc`]-pointer naar een bepaalde toewijzing wordt vernietigd, wordt de waarde die is opgeslagen in die toewijzing (vaak "inner value" genoemd) ook verwijderd.
//!
//! Gedeelde verwijzingen in Rust staan standaard geen mutatie toe, en [`Rc`] is geen uitzondering: je kunt over het algemeen geen veranderlijke verwijzing krijgen naar iets in een [`Rc`].
//! Als je veranderlijkheid nodig hebt, plaats dan een [`Cell`] of [`RefCell`] in de [`Rc`];zie [an example of mutability inside an `Rc`][mutability].
//!
//! [`Rc`] maakt gebruik van niet-atomaire referentietelling.
//! Dit betekent dat de overhead erg laag is, maar een [`Rc`] kan niet tussen threads worden verzonden, en bijgevolg implementeert [`Rc`] [`Send`][send] niet.
//! Als resultaat zal de Rust compiler *tijdens het compileren* controleren of je geen [`Rc`] s tussen threads verstuurt.
//! Als u atoomreferentietelling met meerdere threads nodig heeft, gebruikt u [`sync::Arc`][arc].
//!
//! De [`downgrade`][downgrade]-methode kan worden gebruikt om een niet-eigenaar [`Weak`]-pointer te maken.
//! Een [`Weak`]-pointer kan worden [`upgrade`][upgrade] naar een [`Rc`], maar dit zal [`None`] retourneren als de waarde die is opgeslagen in de toewijzing al is verwijderd.
//! Met andere woorden, `Weak`-aanwijzers houden de waarde binnen de toewijzing niet levend;ze *houden* echter de toewijzing (de ondersteunende opslag voor de innerlijke waarde) levend.
//!
//! Een cyclus tussen [`Rc`]-pointers zal nooit worden opgeheven.
//! Om deze reden wordt [`Weak`] gebruikt om cycli te doorbreken.
//! Een boom kan bijvoorbeeld sterke [`Rc`]-aanwijzers hebben van bovenliggende knooppunten naar kinderen, en [`Weak`]-verwijzingen van kinderen terug naar hun ouders.
//!
//! `Rc<T>` automatisch dereferenties naar `T` (via de [`Deref`] trait), dus je kunt de methoden van `T` aanroepen op een waarde van het type [`Rc<T>`][`Rc`].
//! Om naamconflicten met de methoden van 'T' te voorkomen, zijn de methoden van [`Rc<T>`][`Rc`] zelf geassocieerde functies, aangeroepen met [fully qualified syntax]:
//!
//! ```
//! use std::rc::Rc;
//!
//! let my_rc = Rc::new(());
//! Rc::downgrade(&my_rc);
//! ```
//!
//! 'Rc<T>Implementaties van traits zoals `Clone` kunnen ook worden aangeroepen met behulp van volledig gekwalificeerde syntaxis.
//! Sommige mensen geven er de voorkeur aan om volledig gekwalificeerde syntaxis te gebruiken, terwijl anderen liever de syntaxis van method-call gebruiken.
//!
//! ```
//! use std::rc::Rc;
//!
//! let rc = Rc::new(());
//! // Syntaxis van method-call
//! let rc2 = rc.clone();
//! // Volledig gekwalificeerde syntaxis
//! let rc3 = Rc::clone(&rc);
//! ```
//!
//! [`Weak<T>`][`Weak`] verwijst niet automatisch naar `T`, omdat de innerlijke waarde mogelijk al is verwijderd.
//!
//! # Referenties klonen
//!
//! Het creëren van een nieuwe referentie naar dezelfde allocatie als een bestaande referentie getelde pointer wordt gedaan met behulp van de `Clone` trait geïmplementeerd voor [`Rc<T>`][`Rc`] en [`Weak<T>`][`Weak`].
//!
//!
//! ```
//! use std::rc::Rc;
//!
//! let foo = Rc::new(vec![1.0, 2.0, 3.0]);
//! // De twee onderstaande syntaxis zijn equivalent.
//! let a = foo.clone();
//! let b = Rc::clone(&foo);
//! // a en b wijzen beide naar dezelfde geheugenlocatie als foo.
//! ```
//!
//! De `Rc::clone(&from)`-syntaxis is de meest idiomatische omdat deze de betekenis van de code explicieter weergeeft.
//! In het bovenstaande voorbeeld maakt deze syntaxis het gemakkelijker om te zien dat deze code een nieuwe referentie maakt in plaats van de hele inhoud van foo te kopiëren.
//!
//! # Examples
//!
//! Beschouw een scenario waarin een set van `Gadget`s eigendom is van een bepaalde `Owner`.
//! We willen dat onze `Gadget`s naar hun `Owner` wijzen.We kunnen dit niet doen met uniek eigendom, omdat meer dan één gadget tot dezelfde `Owner` kan behoren.
//! [`Rc`] stelt ons in staat om een `Owner` te delen tussen meerdere `Gadget`s, en de `Owner` toegewezen te houden zolang een `Gadget` ernaar wijst.
//!
//! ```
//! use std::rc::Rc;
//!
//! struct Owner {
//!     name: String,
//!     // ... andere velden
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... andere velden
//! }
//!
//! fn main() {
//!     // Maak een `Owner` met referentie.
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!         }
//!     );
//!
//!     // Maak `Gadget`s behorende tot `gadget_owner`.
//!     // Het klonen van de `Rc<Owner>` geeft ons een nieuwe pointer naar dezelfde `Owner`-toewijzing, waardoor de referentietelling in het proces wordt verhoogd.
//!     //
//!     let gadget1 = Gadget {
//!         id: 1,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!     let gadget2 = Gadget {
//!         id: 2,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!
//!     // Gooi onze lokale variabele `gadget_owner` weg.
//!     drop(gadget_owner);
//!
//!     // Ondanks dat we `gadget_owner` hebben laten vallen, kunnen we nog steeds de naam van de `Owner` van de `Gadget`s.
//!     // Dit komt omdat we slechts een enkele `Rc<Owner>` hebben laten vallen, niet de `Owner` waarnaar deze verwijst.
//!     // Zolang er andere `Rc<Owner>` zijn die naar dezelfde `Owner`-toewijzing wijzen, blijft deze actief.
//!     // De veldprojectie `gadget1.owner.name` werkt omdat `Rc<Owner>` automatisch dereferenties naar `Owner` leidt.
//!     //
//!     //
//!     println!("Gadget {} owned by {}", gadget1.id, gadget1.owner.name);
//!     println!("Gadget {} owned by {}", gadget2.id, gadget2.owner.name);
//!
//!     // Aan het einde van de functie worden `gadget1` en `gadget2` vernietigd, en daarmee de laatst getelde verwijzingen naar onze `Owner`.
//!     // Gadget Man wordt nu ook vernietigd.
//!     //
//! }
//! ```
//!
//! Als onze vereisten veranderen, en we ook in staat moeten zijn om van `Owner` naar `Gadget` te gaan, zullen we problemen tegenkomen.
//! Een [`Rc`]-aanwijzer van `Owner` tot `Gadget` introduceert een cyclus.
//! Dit betekent dat hun referentietellingen nooit 0 kunnen bereiken en dat de toewijzing nooit zal worden vernietigd:
//! een geheugenlek.Om dit te omzeilen, kunnen we [`Weak`]-pointers gebruiken.
//!
//! Rust maakt het eigenlijk enigszins moeilijk om deze lus in de eerste plaats te produceren.Om te eindigen met twee waarden die naar elkaar wijzen, moet een van hen veranderlijk zijn.
//! Dit is moeilijk omdat [`Rc`] geheugenveiligheid afdwingt door alleen gedeelde verwijzingen te geven naar de waarde die het verpakt, en deze staan geen directe mutatie toe.
//! We moeten het deel van de waarde dat we willen muteren in een [`RefCell`] wikkelen, die *innerlijke veranderlijkheid* biedt: een methode om veranderlijkheid te bereiken via een gedeelde referentie.
//! [`RefCell`] dwingt de leenregels van Rust tijdens runtime af.
//!
//! ```
//! use std::rc::Rc;
//! use std::rc::Weak;
//! use std::cell::RefCell;
//!
//! struct Owner {
//!     name: String,
//!     gadgets: RefCell<Vec<Weak<Gadget>>>,
//!     // ... andere velden
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... andere velden
//! }
//!
//! fn main() {
//!     // Maak een `Owner` met referentie.
//!     // Merk op dat we de `Owner`'s vector van`Gadget`s in een `RefCell` hebben geplaatst zodat we deze kunnen muteren via een gedeelde referentie.
//!     //
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!             gadgets: RefCell::new(vec![]),
//!         }
//!     );
//!
//!     // Maak `Gadget`s behorende tot `gadget_owner`, zoals eerder.
//!     let gadget1 = Rc::new(
//!         Gadget {
//!             id: 1,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!     let gadget2 = Rc::new(
//!         Gadget {
//!             id: 2,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!
//!     // Voeg de `Gadget`s toe aan hun `Owner`.
//!     {
//!         let mut gadgets = gadget_owner.gadgets.borrow_mut();
//!         gadgets.push(Rc::downgrade(&gadget1));
//!         gadgets.push(Rc::downgrade(&gadget2));
//!
//!         // `RefCell` dynamisch lenen eindigt hier.
//!     }
//!
//!     // Herhaal onze `Gadget`s, druk hun details af.
//!     for gadget_weak in gadget_owner.gadgets.borrow().iter() {
//!
//!         // `gadget_weak` is een `Weak<Gadget>`.
//!         // Omdat `Weak`-aanwijzers niet kunnen garanderen dat de toewijzing nog steeds bestaat, moeten we `upgrade` aanroepen, wat een `Option<Rc<Gadget>>` retourneert.
//!         //
//!         //
//!         // In dit geval weten we dat de toewijzing nog steeds bestaat, dus we gewoon `unwrap` de `Option`.
//!         // In een meer gecompliceerd programma heeft u wellicht een goede foutafhandeling nodig voor een `None`-resultaat.
//!         //
//!
//!         let gadget = gadget_weak.upgrade().unwrap();
//!         println!("Gadget {} owned by {}", gadget.id, gadget.owner.name);
//!     }
//!
//!     // Aan het einde van de functie worden `gadget_owner`, `gadget1` en `gadget2` vernietigd.
//!     // Er zijn nu geen sterke (`Rc`)-verwijzingen naar de gadgets, dus ze zijn vernietigd.
//!     // Dit zet de referentietelling op Gadget Man op nul, dus hij wordt ook vernietigd.
//!     //
//! }
//! ```
//!
//! [clone]: Clone::clone
//! [`Cell`]: core::cell::Cell
//! [`RefCell`]: core::cell::RefCell
//! [send]: core::marker::Send
//! [arc]: crate::sync::Arc
//! [`Deref`]: core::ops::Deref
//! [downgrade]: Rc::downgrade
//! [upgrade]: Weak::upgrade
//! [mutability]: core::cell#introducing-mutability-inside-of-something-immutable
//! [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[cfg(not(test))]
use crate::boxed::Box;
#[cfg(test)]
use std::boxed::Box;

use core::any::Any;
use core::borrow;
use core::cell::Cell;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::abort;
use core::iter;
use core::marker::{self, PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, forget, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

// Dit is repr(C) tot future-proof tegen mogelijke veldherschikking, die anderszins veilige [into|from]_raw() van transmuteerbare innerlijke types zou verstoren.
//
//
#[repr(C)]
struct RcBox<T: ?Sized> {
    strong: Cell<usize>,
    weak: Cell<usize>,
    value: T,
}

/// Een aanwijzer voor het tellen van referenties met één thread.'Rc' staat voor 'Reference
/// Counted'.
///
/// Zie de [module-level documentation](./index.html) voor meer details.
///
/// De inherente methoden van `Rc` zijn alle bijbehorende functies, wat betekent dat u ze moet aanroepen als bijvoorbeeld [`Rc::get_mut(&mut value)`][get_mut] in plaats van `value.get_mut()`.
/// Dit vermijdt conflicten met methoden van het binnentype `T`.
///
/// [get_mut]: Rc::get_mut
///
#[cfg_attr(not(test), rustc_diagnostic_item = "Rc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Rc<T: ?Sized> {
    ptr: NonNull<RcBox<T>>,
    phantom: PhantomData<RcBox<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Send for Rc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Sync for Rc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Rc<U>> for Rc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T> {}

impl<T: ?Sized> Rc<T> {
    #[inline(always)]
    fn inner(&self) -> &RcBox<T> {
        // Deze onveiligheid is ok, want zolang deze Rc leeft, zijn we er zeker van dat de binnenste aanwijzer geldig is.
        //
        unsafe { self.ptr.as_ref() }
    }

    fn from_inner(ptr: NonNull<RcBox<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut RcBox<T>) -> Self {
        Self::from_inner(unsafe { NonNull::new_unchecked(ptr) })
    }
}

impl<T> Rc<T> {
    /// Construeert een nieuwe `Rc<T>`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(value: T) -> Rc<T> {
        // Er is een impliciete zwakke aanwijzer die eigendom is van alle sterke aanwijzingen, wat ervoor zorgt dat de zwakke vernietiger nooit de toewijzing vrijmaakt terwijl de sterke vernietiger actief is, zelfs als de zwakke aanwijzer in de sterke aanwijzer is opgeslagen.
        //
        //
        //
        Self::from_inner(
            Box::leak(box RcBox { strong: Cell::new(1), weak: Cell::new(1), value }).into(),
        )
    }

    /// Construeert een nieuwe `Rc<T>` met een zwakke verwijzing naar zichzelf.
    /// Als u probeert de zwakke referentie te upgraden voordat deze functie retourneert, resulteert dit in een `None`-waarde.
    ///
    /// De zwakke referentie kan echter vrij worden gekloond en worden opgeslagen voor gebruik op een later tijdstip.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Gadget {
    ///     self_weak: Weak<Self>,
    ///     // ... meer velden
    /// }
    /// impl Gadget {
    ///     pub fn new() -> Rc<Self> {
    ///         Rc::new_cyclic(|self_weak| {
    ///             Gadget { self_weak: self_weak.clone(), /* ... */ }
    ///         })
    ///     }
    /// }
    /// ```
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Rc<T> {
        // Construeer de binnenste in de "uninitialized"-toestand met een enkele zwakke referentie.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box RcBox {
            strong: Cell::new(0),
            weak: Cell::new(1),
            value: mem::MaybeUninit::<T>::uninit(),
        })
        .into();

        let init_ptr: NonNull<RcBox<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // Het is belangrijk dat we het eigendom van de zwakke aanwijzer niet opgeven, anders kan het geheugen worden vrijgemaakt tegen de tijd dat `data_fn` terugkeert.
        // Als we echt het eigendom zouden willen overdragen, zouden we een extra zwakke aanwijzer voor onszelf kunnen creëren, maar dit zou resulteren in extra updates van de zwakke referentietelling die anders misschien niet nodig zou zijn.
        //
        //
        //
        //
        let data = data_fn(&weak);

        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).value), data);

            let prev_value = (*inner).strong.get();
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
            (*inner).strong.set(1);
        }

        let strong = Rc::from_inner(init_ptr);

        // Sterke referenties zouden gezamenlijk een gedeelde zwakke referentie moeten hebben, dus voer de destructor niet uit voor onze oude zwakke referentie.
        //
        mem::forget(weak);
        strong
    }

    /// Construeert een nieuwe `Rc` met niet-geïnitialiseerde inhoud.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Uitgestelde initialisatie:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Construeert een nieuwe `Rc` met niet-geïnitialiseerde inhoud, waarbij het geheugen wordt gevuld met `0`-bytes.
    ///
    ///
    /// Zie [`MaybeUninit::zeroed`][zeroed] voor voorbeelden van correct en incorrect gebruik van deze methode.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Construeert een nieuwe `Rc<T>`, die een fout retourneert als de toewijzing mislukt
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::rc::Rc;
    ///
    /// let five = Rc::try_new(5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn try_new(value: T) -> Result<Rc<T>, AllocError> {
        // Er is een impliciete zwakke aanwijzer die eigendom is van alle sterke aanwijzingen, wat ervoor zorgt dat de zwakke vernietiger nooit de toewijzing vrijmaakt terwijl de sterke vernietiger actief is, zelfs als de zwakke aanwijzer in de sterke aanwijzer is opgeslagen.
        //
        //
        //
        Ok(Self::from_inner(
            Box::leak(Box::try_new(RcBox { strong: Cell::new(1), weak: Cell::new(1), value })?)
                .into(),
        ))
    }

    /// Construeert een nieuwe `Rc` met niet-geïnitialiseerde inhoud, waarbij een fout wordt geretourneerd als de toewijzing mislukt
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // Uitgestelde initialisatie:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// Construeert een nieuwe `Rc` met niet-geïnitialiseerde inhoud, waarbij het geheugen wordt gevuld met `0`-bytes, en geeft een foutmelding als de toewijzing mislukt
    ///
    ///
    /// Zie [`MaybeUninit::zeroed`][zeroed] voor voorbeelden van correct en incorrect gebruik van deze methode.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// Construeert een nieuwe `Pin<Rc<T>>`.
    /// Als `T` `Unpin` niet implementeert, wordt `value` in het geheugen vastgezet en kan deze niet worden verplaatst.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(value: T) -> Pin<Rc<T>> {
        unsafe { Pin::new_unchecked(Rc::new(value)) }
    }

    /// Retourneert de binnenste waarde als de `Rc` precies één sterke referentie heeft.
    ///
    /// Anders wordt een [`Err`] geretourneerd met dezelfde `Rc` die is doorgegeven.
    ///
    ///
    /// Dit zal lukken, zelfs als er uitstekende zwakke referenties zijn.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new(3);
    /// assert_eq!(Rc::try_unwrap(x), Ok(3));
    ///
    /// let x = Rc::new(4);
    /// let _y = Rc::clone(&x);
    /// assert_eq!(*Rc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if Rc::strong_count(&this) == 1 {
            unsafe {
                let val = ptr::read(&*this); // kopieer het ingesloten object

                // Geef aan Weaks aan dat ze niet kunnen worden gepromoot door de sterke telling te verlagen, en verwijder vervolgens de impliciete "strong weak"-aanwijzer terwijl je ook de drop-logica afhandelt door gewoon een nep-Weak te maken.
                //
                //
                //
                this.inner().dec_strong();
                let _weak = Weak { ptr: this.ptr };
                forget(this);
                Ok(val)
            }
        } else {
            Err(this)
        }
    }
}

impl<T> Rc<[T]> {
    /// Construeert een nieuwe door referentie getelde slice met niet-geïnitialiseerde inhoud.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Uitgestelde initialisatie:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe { Rc::from_ptr(Rc::allocate_for_slice(len)) }
    }

    /// Construeert een nieuwe door referentie getelde plak met niet-geïnitialiseerde inhoud, waarbij het geheugen wordt gevuld met `0` bytes.
    ///
    ///
    /// Zie [`MaybeUninit::zeroed`][zeroed] voor voorbeelden van correct en incorrect gebruik van deze methode.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let values = Rc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut RcBox<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Rc<mem::MaybeUninit<T>> {
    /// Converteert naar `Rc<T>`.
    ///
    /// # Safety
    ///
    /// Net als bij [`MaybeUninit::assume_init`] is het aan de beller om te garanderen dat de innerlijke waarde echt in een geïnitialiseerde staat verkeert.
    ///
    /// Dit aanroepen wanneer de inhoud nog niet volledig is geïnitialiseerd, veroorzaakt onmiddellijk ongedefinieerd gedrag.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Uitgestelde initialisatie:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<T> {
        Rc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Rc<[mem::MaybeUninit<T>]> {
    /// Converteert naar `Rc<[T]>`.
    ///
    /// # Safety
    ///
    /// Net als bij [`MaybeUninit::assume_init`] is het aan de beller om te garanderen dat de innerlijke waarde echt in een geïnitialiseerde staat verkeert.
    ///
    /// Dit aanroepen wanneer de inhoud nog niet volledig is geïnitialiseerd, veroorzaakt onmiddellijk ongedefinieerd gedrag.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Uitgestelde initialisatie:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<[T]> {
        unsafe { Rc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Rc<T> {
    /// Verbruikt de `Rc` en retourneert de ingepakte aanwijzer.
    ///
    /// Om een geheugenlek te voorkomen, moet de pointer terug worden geconverteerd naar een `Rc` met behulp van [`Rc::from_raw`][from_raw].
    ///
    ///
    /// [from_raw]: Rc::from_raw
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// Biedt een onbewerkte verwijzing naar de gegevens.
    ///
    /// De tellingen worden op geen enkele manier beïnvloed en de `Rc` wordt niet verbruikt.
    /// De aanwijzer is geldig zolang er sterke tellingen in de `Rc` zijn.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let y = Rc::clone(&x);
    /// let x_ptr = Rc::as_ptr(&x);
    /// assert_eq!(x_ptr, Rc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(this.ptr);

        // VEILIGHEID: Dit kan niet door Deref::deref of Rc::inner gaan omdat
        // dit is vereist om de herkomst van raw/mut te behouden, zodat bijv
        // `get_mut` kan door de aanwijzer schrijven nadat de Rc is hersteld via `from_raw`.
        unsafe { ptr::addr_of_mut!((*ptr).value) }
    }

    /// Construeert een `Rc<T>` op basis van een onbewerkte pointer.
    ///
    /// De onbewerkte pointer moet eerder zijn geretourneerd door een aanroep naar [`Rc<U>::into_raw`][into_raw], waarbij `U` dezelfde grootte en uitlijning moet hebben als `T`.
    /// Dit is triviaal waar als `U` `T` is.
    /// Merk op dat als `U` niet `T` is maar dezelfde grootte en uitlijning heeft, dit in feite hetzelfde is als het transmuteren van verschillende typen referenties.
    /// Zie [`mem::transmute`][transmute] voor meer informatie over welke beperkingen in dit geval van toepassing zijn.
    ///
    /// De gebruiker van `from_raw` moet ervoor zorgen dat een specifieke waarde van `T` maar één keer wordt verwijderd.
    ///
    /// Deze functie is onveilig omdat oneigenlijk gebruik kan leiden tot onveiligheid van het geheugen, zelfs als de geretourneerde `Rc<T>` nooit wordt benaderd.
    ///
    /// [into_raw]: Rc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    ///
    /// unsafe {
    ///     // Converteer terug naar een `Rc` om lekken te voorkomen.
    ///     let x = Rc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // Verdere oproepen naar `Rc::from_raw(x_ptr)` zouden geheugenonveilig zijn.
    /// }
    ///
    /// // Het geheugen werd vrijgemaakt toen `x` hierboven buiten het bereik viel, dus `x_ptr` bungelt nu!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        let offset = unsafe { data_offset(ptr) };

        // Keer de offset om om de originele RcBox te vinden.
        let rc_ptr =
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) };

        unsafe { Self::from_ptr(rc_ptr) }
    }

    /// Maakt een nieuwe [`Weak`]-pointer voor deze toewijzing.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        this.inner().inc_weak();
        // Zorg ervoor dat we geen bungelende Zwak maken
        debug_assert!(!is_dangling(this.ptr.as_ptr()));
        Weak { ptr: this.ptr }
    }

    /// Haalt het aantal [`Weak`]-verwijzingen naar deze toewijzing op.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _weak_five = Rc::downgrade(&five);
    ///
    /// assert_eq!(1, Rc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        this.inner().weak() - 1
    }

    /// Haalt het aantal sterke (`Rc`)-verwijzingen naar deze toewijzing.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _also_five = Rc::clone(&five);
    ///
    /// assert_eq!(2, Rc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong()
    }

    /// Geeft `true` terug als er geen andere `Rc`-of [`Weak`]-verwijzingen naar deze toewijzing zijn.
    ///
    #[inline]
    fn is_unique(this: &Self) -> bool {
        Rc::weak_count(this) == 0 && Rc::strong_count(this) == 1
    }

    /// Retourneert een veranderlijke verwijzing naar de opgegeven `Rc`, als er geen andere `Rc`-of [`Weak`]-verwijzingen naar dezelfde toewijzing zijn.
    ///
    ///
    /// Geeft anders [`None`] terug, omdat het niet veilig is om een gedeelde waarde te muteren.
    ///
    /// Zie ook [`make_mut`][make_mut], die [`clone`][clone] de innerlijke waarde zal geven als er andere aanwijzingen zijn.
    ///
    /// [make_mut]: Rc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(3);
    /// *Rc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Rc::clone(&x);
    /// assert!(Rc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if Rc::is_unique(this) { unsafe { Some(Rc::get_mut_unchecked(this)) } } else { None }
    }

    /// Retourneert een veranderlijke verwijzing naar de opgegeven `Rc`, zonder enige controle.
    ///
    /// Zie ook [`get_mut`], die veilig is en de juiste controles uitvoert.
    ///
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Safety
    ///
    /// Alle andere `Rc`-of [`Weak`]-verwijzingen naar dezelfde toewijzing mogen niet worden verwijderd voor de duur van de geretourneerde lening.
    ///
    /// Dit is triviaal het geval als dergelijke verwijzingen niet bestaan, bijvoorbeeld direct na `Rc::new`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(String::new());
    /// unsafe {
    ///     Rc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // We zorgen ervoor dat *niet* een referentie wordt gemaakt die de "count"-velden dekt, aangezien dit in strijd zou zijn met toegang tot de referentietellingen (bijv.
        // door `Weak`).
        unsafe { &mut (*this.ptr.as_ptr()).value }
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// Geeft `true` terug als de twee `Rc`s naar dezelfde toewijzing wijzen (in een geest vergelijkbaar met [`ptr::eq`]).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let same_five = Rc::clone(&five);
    /// let other_five = Rc::new(5);
    ///
    /// assert!(Rc::ptr_eq(&five, &same_five));
    /// assert!(!Rc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: Clone> Rc<T> {
    /// Maakt een veranderlijke verwijzing naar de gegeven `Rc`.
    ///
    /// Als er andere `Rc`-verwijzingen naar dezelfde toewijzing zijn, dan `make_mut` [`clone`] de innerlijke waarde naar een nieuwe toewijzing om uniek eigendom te garanderen.
    /// Dit wordt ook wel clone-on-write genoemd.
    ///
    /// Als er geen andere `Rc`-verwijzingen naar deze toewijzing zijn, worden [`Weak`]-verwijzingen naar deze toewijzing ontkoppeld.
    ///
    /// Zie ook [`get_mut`], dat zal mislukken in plaats van te klonen.
    ///
    /// [`clone`]: Clone::clone
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(5);
    ///
    /// *Rc::make_mut(&mut data) += 1;        // Zal niets klonen
    /// let mut other_data = Rc::clone(&data);    // Zal geen interne gegevens klonen
    /// *Rc::make_mut(&mut data) += 1;        // Kloneert innerlijke gegevens
    /// *Rc::make_mut(&mut data) += 1;        // Zal niets klonen
    /// *Rc::make_mut(&mut other_data) *= 2;  // Zal niets klonen
    ///
    /// // Nu wijzen `data` en `other_data` naar verschillende toewijzingen.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    /// [`Weak`] aanwijzingen zullen worden losgekoppeld:
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(75);
    /// let weak = Rc::downgrade(&data);
    ///
    /// assert!(75 == *data);
    /// assert!(75 == *weak.upgrade().unwrap());
    ///
    /// *Rc::make_mut(&mut data) += 1;
    ///
    /// assert!(76 == *data);
    /// assert!(weak.upgrade().is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        if Rc::strong_count(this) != 1 {
            // Ik moet de gegevens klonen, er zijn andere RC's.
            // Wijs vooraf geheugen toe om de gekloonde waarde rechtstreeks te kunnen schrijven.
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = rc.assume_init();
            }
        } else if Rc::weak_count(this) != 0 {
            // Kan gewoon de gegevens stelen, het enige dat overblijft zijn Weaks
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);

                this.inner().dec_strong();
                // Verwijder impliciete sterk-zwakke ref (het is hier niet nodig om een nep-Weak te maken-we weten dat andere Weaks voor ons kunnen opruimen)
                //
                this.inner().dec_weak();
                ptr::write(this, rc.assume_init());
            }
        }
        // Deze onveiligheid is oké omdat we er zeker van zijn dat de teruggezonden aanwijzer de *enige* aanwijzer is die ooit zal worden teruggestuurd naar T.
        // Onze referentietelling is op dit punt gegarandeerd 1, en we vereisten dat de `Rc<T>` zelf `mut` was, dus we retourneren de enige mogelijke referentie naar de toewijzing.
        //
        //
        //
        unsafe { &mut this.ptr.as_mut().value }
    }
}

impl Rc<dyn Any> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// Probeer de `Rc<dyn Any>` neer te halen tot een concreet type.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::rc::Rc;
    ///
    /// fn print_if_string(value: Rc<dyn Any>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Rc::new(my_string));
    /// print_if_string(Rc::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Rc<T>, Rc<dyn Any>> {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<RcBox<T>>();
            forget(self);
            Ok(Rc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T: ?Sized> Rc<T> {
    /// Wijst een `RcBox<T>` toe met voldoende ruimte voor een mogelijk niet-gedimensioneerde innerlijke waarde waar de waarde de opgegeven lay-out heeft.
    ///
    /// De functie `mem_to_rcbox` wordt aangeroepen met de datapointer en moet een (mogelijk dikke)-pointer teruggeven voor de `RcBox<T>`.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> *mut RcBox<T> {
        // Bereken de lay-out met behulp van de gegeven waardelay-out.
        // Voorheen werd de lay-out berekend op de uitdrukking `&*(ptr as* const RcBox<T>)`, maar dit creëerde een verkeerd uitgelijnde referentie (zie #54908).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Rc::try_allocate_for_layout(value_layout, allocate, mem_to_rcbox)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// Wijst een `RcBox<T>` toe met voldoende ruimte voor een mogelijk niet-gedimensioneerde innerlijke waarde waarbij de waarde de opgegeven lay-out heeft, waarbij een fout wordt geretourneerd als de toewijzing mislukt.
    ///
    ///
    /// De functie `mem_to_rcbox` wordt aangeroepen met de datapointer en moet een (mogelijk dikke)-pointer teruggeven voor de `RcBox<T>`.
    ///
    ///
    #[inline]
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> Result<*mut RcBox<T>, AllocError> {
        // Bereken de lay-out met behulp van de gegeven waardelay-out.
        // Voorheen werd de lay-out berekend op de uitdrukking `&*(ptr as* const RcBox<T>)`, maar dit creëerde een verkeerd uitgelijnde referentie (zie #54908).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();

        // Wijs toe voor de lay-out.
        let ptr = allocate(layout)?;

        // Initialiseer de RcBox
        let inner = mem_to_rcbox(ptr.as_non_null_ptr().as_ptr());
        unsafe {
            debug_assert_eq!(Layout::for_value(&*inner), layout);

            ptr::write(&mut (*inner).strong, Cell::new(1));
            ptr::write(&mut (*inner).weak, Cell::new(1));
        }

        Ok(inner)
    }

    /// Wijst een `RcBox<T>` toe met voldoende ruimte voor een niet-bemeten innerlijke waarde
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut RcBox<T> {
        // Wijs toe aan de `RcBox<T>` met behulp van de opgegeven waarde.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut RcBox<T>).set_ptr_value(mem),
            )
        }
    }

    fn from_box(v: Box<T>) -> Rc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // Kopieer de waarde als bytes
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).value as *mut _ as *mut u8,
                value_size,
            );

            // Maak de toewijzing vrij zonder de inhoud ervan te laten vallen
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Rc<[T]> {
    /// Wijst een `RcBox<[T]>` toe met de opgegeven lengte.
    unsafe fn allocate_for_slice(len: usize) -> *mut RcBox<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut RcBox<[T]>,
            )
        }
    }

    /// Kopieer elementen van slice naar nieuw toegewezen Rc <\[T\]>
    ///
    /// Onveilig omdat de beller eigenaar moet worden of `T: Copy` moet binden
    unsafe fn copy_from_slice(v: &[T]) -> Rc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());
            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).value as *mut [T] as *mut T, v.len());
            Self::from_ptr(ptr)
        }
    }

    /// Construeert een `Rc<[T]>` op basis van een iterator waarvan bekend is dat deze een bepaalde grootte heeft.
    ///
    /// Gedrag is niet gedefinieerd als de maat verkeerd is.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Rc<[T]> {
        // Panic bewaken tijdens het klonen van T-elementen.
        // In het geval van een panic worden elementen die in de nieuwe RcBox zijn geschreven, verwijderd en wordt het geheugen vrijgemaakt.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // Wijzer naar eerste element
            let elems = &mut (*ptr).value as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // Alles duidelijk.Vergeet de bewaker zodat hij de nieuwe RcBox niet bevrijdt.
            forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// Specialisatie trait gebruikt voor `From<&[T]>`.
trait RcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Rc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Rc<T> {
    type Target = T;

    #[inline(always)]
    fn deref(&self) -> &T {
        &self.inner().value
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Rc<T> {
    /// Laat de `Rc` vallen.
    ///
    /// Dit verlaagt het aantal sterke referenties.
    /// Als het aantal sterke referenties nul bereikt, zijn de enige andere referenties (indien aanwezig) [`Weak`], dus we `drop` de innerlijke waarde.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Rc::new(Foo);
    /// let foo2 = Rc::clone(&foo);
    ///
    /// drop(foo);    // Drukt niets af
    /// drop(foo2);   // Drukt "dropped!" af
    /// ```
    fn drop(&mut self) {
        unsafe {
            self.inner().dec_strong();
            if self.inner().strong() == 0 {
                // vernietig het bevatte object
                ptr::drop_in_place(Self::get_mut_unchecked(self));

                // verwijder de impliciete "strong weak"-aanwijzer nu we de inhoud hebben vernietigd.
                //
                self.inner().dec_weak();

                if self.inner().weak() == 0 {
                    Global.deallocate(self.ptr.cast(), Layout::for_value(self.ptr.as_ref()));
                }
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Rc<T> {
    /// Maakt een kloon van de `Rc`-aanwijzer.
    ///
    /// Dit creëert een andere aanwijzer naar dezelfde toewijzing, waardoor het aantal sterke referenties toeneemt.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let _ = Rc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Rc<T> {
        self.inner().inc_strong();
        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Rc<T> {
    /// Maakt een nieuwe `Rc<T>`, met de `Default`-waarde voor `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x: Rc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    #[inline]
    fn default() -> Rc<T> {
        Rc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait RcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Rc<T>) -> bool;
    fn ne(&self, other: &Rc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    default fn eq(&self, other: &Rc<T>) -> bool {
        **self == **other
    }

    #[inline]
    default fn ne(&self, other: &Rc<T>) -> bool {
        **self != **other
    }
}

// Hack om specialisatie op `Eq` mogelijk te maken, ook al heeft `Eq` een methode.
#[rustc_unsafe_specialization_marker]
pub(crate) trait MarkerEq: PartialEq<Self> {}

impl<T: Eq> MarkerEq for T {}

/// We doen deze specialisatie hier, en niet als een algemenere optimalisatie op `&T`, omdat het anders kosten zou toevoegen aan alle gelijkheidscontroles op refs.
/// We gaan ervan uit dat `Rc`s worden gebruikt om grote waarden op te slaan, die traag klonen, maar ook zwaar zijn om te controleren op gelijkheid, waardoor deze kosten zich gemakkelijker terugverdienen.
///
/// Het is ook waarschijnlijker dat er twee `Rc`-klonen zijn, die naar dezelfde waarde wijzen, dan twee `&T`s.
///
/// We kunnen dit alleen doen als `T: Eq` als een `PartialEq` opzettelijk irreflexief is.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + MarkerEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        Rc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        !Rc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Rc<T> {
    /// Gelijkheid voor twee `Rc`s.
    ///
    /// Twee `Rc`s zijn gelijk als hun innerlijke waarden gelijk zijn, zelfs als ze in verschillende toewijzingen zijn opgeslagen.
    ///
    /// Als `T` ook `Eq` implementeert (wat reflexiviteit van gelijkheid impliceert), zijn twee `Rc`s die naar dezelfde toewijzing wijzen altijd gelijk.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five == Rc::new(5));
    /// ```
    ///
    ///
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        RcEqIdent::eq(self, other)
    }

    /// Ongelijkheid voor twee `Rc`s.
    ///
    /// Twee `Rc`s zijn ongelijk als hun innerlijke waarden ongelijk zijn.
    ///
    /// Als `T` ook `Eq` implementeert (wat reflexiviteit van gelijkheid impliceert), zijn twee `Rc`s die naar dezelfde toewijzing verwijzen nooit ongelijk.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five != Rc::new(6));
    /// ```
    ///
    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        RcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Rc<T> {
    /// Gedeeltelijke vergelijking voor twee `Rc`s.
    ///
    /// De twee worden vergeleken door `partial_cmp()` op hun innerlijke waarden aan te roepen.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Rc::new(6)));
    /// ```
    #[inline(always)]
    fn partial_cmp(&self, other: &Rc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// Minder dan vergelijking voor twee `Rc`s.
    ///
    /// De twee worden vergeleken door `<` op hun innerlijke waarden aan te roepen.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five < Rc::new(6));
    /// ```
    #[inline(always)]
    fn lt(&self, other: &Rc<T>) -> bool {
        **self < **other
    }

    /// 'Kleiner dan of gelijk aan' vergelijking voor twee `Rc`s.
    ///
    /// De twee worden vergeleken door `<=` op hun innerlijke waarden aan te roepen.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five <= Rc::new(5));
    /// ```
    #[inline(always)]
    fn le(&self, other: &Rc<T>) -> bool {
        **self <= **other
    }

    /// Groter dan vergelijking voor twee `Rc`s.
    ///
    /// De twee worden vergeleken door `>` op hun innerlijke waarden aan te roepen.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five > Rc::new(4));
    /// ```
    #[inline(always)]
    fn gt(&self, other: &Rc<T>) -> bool {
        **self > **other
    }

    /// 'Groter dan of gelijk aan' vergelijking voor twee `Rc`s.
    ///
    /// De twee worden vergeleken door `>=` op hun innerlijke waarden aan te roepen.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five >= Rc::new(5));
    /// ```
    #[inline(always)]
    fn ge(&self, other: &Rc<T>) -> bool {
        **self >= **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Rc<T> {
    /// Vergelijking voor twee `Rc`s.
    ///
    /// De twee worden vergeleken door `cmp()` op hun innerlijke waarden aan te roepen.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Rc::new(6)));
    /// ```
    #[inline]
    fn cmp(&self, other: &Rc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Rc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Rc<T> {
    fn from(t: T) -> Self {
        Rc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Rc<[T]> {
    /// Wijs een referentie-geteld segment toe en vul het door 'v'-items te klonen.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Rc<[i32]> = Rc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Rc<[T]> {
        <Self as RcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Rc<str> {
    /// Wijs een stringplak met een referentietelling toe en kopieer `v` erin.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let shared: Rc<str> = Rc::from("statue");
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Rc<str> {
        let rc = Rc::<[u8]>::from(v.as_bytes());
        unsafe { Rc::from_raw(Rc::into_raw(rc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Rc<str> {
    /// Wijs een stringplak met een referentietelling toe en kopieer `v` erin.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: String = "statue".to_owned();
    /// let shared: Rc<str> = Rc::from(original);
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Rc<str> {
        Rc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Rc<T> {
    /// Verplaats een omkaderd object naar een nieuwe, referentie getelde, toewijzing.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<i32> = Box::new(1);
    /// let shared: Rc<i32> = Rc::from(original);
    /// assert_eq!(1, *shared);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Rc<T> {
        Rc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Rc<[T]> {
    /// Wijs een door referentie geteld segment toe en verplaats de items van 'v' erin.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<Vec<i32>> = Box::new(vec![1, 2, 3]);
    /// let shared: Rc<Vec<i32>> = Rc::from(original);
    /// assert_eq!(vec![1, 2, 3], *shared);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Rc<[T]> {
        unsafe {
            let rc = Rc::copy_from_slice(&v);

            // Laat de Vec zijn geheugen vrijmaken, maar vernietig de inhoud niet
            v.set_len(0);

            rc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Rc<B>
where
    B: ToOwned + ?Sized,
    Rc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Rc<B> {
        match cow {
            Cow::Borrowed(s) => Rc::from(s),
            Cow::Owned(s) => Rc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Rc<[T]>> for Rc<[T; N]> {
    type Error = Rc<[T]>;

    fn try_from(boxed_slice: Rc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Rc::from_raw(Rc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Rc<[T]> {
    /// Neemt elk element in de `Iterator` en verzamelt het in een `Rc<[T]>`.
    ///
    /// # Prestatiekenmerken
    ///
    /// ## Het algemene geval
    ///
    /// In het algemene geval wordt het verzamelen in `Rc<[T]>` gedaan door eerst in een `Vec<T>` te verzamelen.Dat wil zeggen, bij het schrijven van het volgende:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// dit gedraagt zich alsof we schreven:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // De eerste set toewijzingen vindt hier plaats.
    ///     .into(); // Een tweede toewijzing voor `Rc<[T]>` gebeurt hier.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// Dit zal zo vaak toewijzen als nodig is voor het construeren van de `Vec<T>` en dan zal het eenmaal worden toegewezen om de `Vec<T>` in de `Rc<[T]>` te veranderen.
    ///
    ///
    /// ## Iteratoren van bekende lengte
    ///
    /// Wanneer uw `Iterator` `TrustedLen` implementeert en een exacte grootte heeft, wordt er een enkele toewijzing gemaakt voor de `Rc<[T]>`.Bijvoorbeeld:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).collect(); // Hier vindt slechts een enkele toewijzing plaats.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToRcSlice::to_rc_slice(iter.into_iter())
    }
}

/// Specialisatie trait gebruikt voor het verzamelen in `Rc<[T]>`.
trait ToRcSlice<T>: Iterator<Item = T> + Sized {
    fn to_rc_slice(self) -> Rc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToRcSlice<T> for I {
    default fn to_rc_slice(self) -> Rc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToRcSlice<T> for I {
    fn to_rc_slice(self) -> Rc<[T]> {
        // Dit is het geval voor een `TrustedLen`-iterator.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // VEILIGHEID: We moeten ervoor zorgen dat de iterator een exacte lengte heeft en dat hebben we ook.
                Rc::from_iter_exact(self, low)
            }
        } else {
            // Terugvallen op de normale implementatie.
            self.collect::<Vec<T>>().into()
        }
    }
}

/// `Weak` is een versie van [`Rc`] die een niet-eigendomsreferentie bevat naar de beheerde toewijzing.De toewijzing is toegankelijk door [`upgrade`] op de `Weak`-pointer aan te roepen, die een [`Option`]`<`[`Rc`] `retourneert<T>>`.
///
/// Omdat een `Weak`-referentie niet meetelt voor het eigendom, zal het niet voorkomen dat de waarde die is opgeslagen in de allocatie wordt verwijderd, en `Weak` zelf geeft geen garanties dat de waarde nog steeds aanwezig is.
/// Het kan dus [`None`] retourneren wanneer [`upgrade`] d.
/// Merk echter op dat een `Weak`-referentie *wel* voorkomt dat de toewijzing zelf (de back-store) wordt ongedaan gemaakt.
///
/// Een `Weak`-aanwijzer is handig om een tijdelijke verwijzing te bewaren naar de toewijzing die wordt beheerd door [`Rc`] zonder te voorkomen dat de innerlijke waarde wordt verwijderd.
/// Het wordt ook gebruikt om circulaire verwijzingen tussen [`Rc`]-aanwijzers te voorkomen, aangezien wederzijdse verwijzingen nooit zouden toestaan dat een van beide [`Rc`] wordt verwijderd.
/// Een boom kan bijvoorbeeld sterke [`Rc`]-aanwijzers hebben van bovenliggende knooppunten naar kinderen, en `Weak`-verwijzingen van kinderen terug naar hun ouders.
///
/// De typische manier om een `Weak`-pointer te verkrijgen, is door [`Rc::downgrade`] aan te roepen.
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
///
///
#[stable(feature = "rc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // Dit is een `NonNull` om de grootte van dit type in enums te optimaliseren, maar het is niet noodzakelijk een geldige pointer.
    //
    // `Weak::new` stelt dit in op `usize::MAX` zodat het geen ruimte op de heap hoeft toe te wijzen.
    // Dat is geen waarde die een echte pointer ooit zal hebben, omdat RcBox ten minste 2 uitlijning heeft.
    // Dit is alleen mogelijk als `T: Sized`;niet-formaat `T` bengelt nooit.
    //
    ptr: NonNull<RcBox<T>>,
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Send for Weak<T> {}
#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

impl<T> Weak<T> {
    /// Construeert een nieuwe `Weak<T>`, zonder geheugen toe te wijzen.
    /// [`upgrade`] aanroepen voor de retourwaarde geeft altijd [`None`].
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut RcBox<T>).expect("MAX is not 0") }
    }
}

pub(crate) fn is_dangling<T: ?Sized>(ptr: *mut T) -> bool {
    let address = ptr as *mut () as usize;
    address == usize::MAX
}

/// Helper-type om toegang te krijgen tot de referentietellingen zonder beweringen over het gegevensveld te doen.
///
struct WeakInner<'a> {
    weak: &'a Cell<usize>,
    strong: &'a Cell<usize>,
}

impl<T: ?Sized> Weak<T> {
    /// Geeft een onbewerkte pointer terug naar het object `T` waarnaar door deze `Weak<T>` wordt verwezen.
    ///
    /// De aanwijzer is alleen geldig als er sterke referenties zijn.
    /// De aanwijzer kan bungelen, niet uitgelijnd of anders zelfs [`null`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::ptr;
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// // Beide wijzen naar hetzelfde object
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // De sterke hier houdt het in leven, dus we hebben nog steeds toegang tot het object.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // Maar nu niet meer.
    /// // We kunnen weak.as_ptr() doen, maar toegang tot de aanwijzer zou tot ongedefinieerd gedrag leiden.
    /// // assert_eq! ("hallo", onveilige {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // Als de wijzer bungelt, sturen we de schildwacht direct terug.
            // Dit kan geen geldig payload-adres zijn, aangezien de payload minstens zo uitgelijnd is als RcBox (usize).
            ptr as *const T
        } else {
            // VEILIGHEID: als is_dangling false retourneert, kan de pointer worden ontkoppeld.
            // De payload kan op dit punt worden verlaagd en we moeten de herkomst behouden, dus gebruik onbewerkte pointermanipulatie.
            //
            unsafe { ptr::addr_of_mut!((*ptr).value) }
        }
    }

    /// Verbruikt de `Weak<T>` en verandert deze in een onbewerkte aanwijzer.
    ///
    /// Dit zet de zwakke aanwijzer om in een onbewerkte aanwijzer, terwijl het eigendom van één zwakke referentie behouden blijft (het zwakke aantal wordt niet gewijzigd door deze bewerking).
    /// Het kan weer worden omgezet in de `Weak<T>` met [`from_raw`].
    ///
    /// Dezelfde beperkingen voor toegang tot het doel van de aanwijzer als bij [`as_ptr`] zijn van toepassing.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Rc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Rc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// Converteert een eerder door [`into_raw`] gemaakte onbewerkte pointer terug naar `Weak<T>`.
    ///
    /// Dit kan worden gebruikt om veilig een sterke referentie te krijgen (door later [`upgrade`] aan te roepen) of om de zwakke telling ongedaan te maken door de `Weak<T>` te laten vallen.
    ///
    /// Het neemt eigendom van één zwakke referentie (met uitzondering van de pointers gemaakt door [`new`], aangezien deze niets bezitten; de methode werkt er nog steeds op).
    ///
    /// # Safety
    ///
    /// De aanwijzer moet afkomstig zijn van de [`into_raw`] en moet nog steeds zijn potentieel zwakke referentie bezitten.
    ///
    /// Het is toegestaan dat de sterke telling 0 is op het moment dat dit wordt aangeroepen.
    /// Desalniettemin neemt dit het eigendom over van één zwakke referentie die momenteel wordt weergegeven als een onbewerkte pointer (de zwakke telling wordt niet gewijzigd door deze bewerking) en daarom moet het worden gepaard met een eerdere aanroep naar [`into_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    ///
    /// let raw_1 = Rc::downgrade(&strong).into_raw();
    /// let raw_2 = Rc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Rc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Rc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // Verlaag de laatste zwakke telling.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`new`]: Weak::new
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // Zie Weak::as_ptr voor context over hoe de invoerpointer wordt afgeleid.

        let ptr = if is_dangling(ptr as *mut T) {
            // Dit is een bungelende Zwakke.
            ptr as *mut RcBox<T>
        } else {
            // Anders zijn we er zeker van dat de aanwijzer afkomstig was van een niet-verwarrende Weak.
            // VEILIGHEID: data_offset is veilig om aan te roepen, aangezien ptr verwijst naar een echte (mogelijk weggelaten) T.
            let offset = unsafe { data_offset(ptr) };
            // We keren dus de offset om om de hele RcBox te krijgen.
            // VEILIGHEID: de aanwijzer is afkomstig van een zwakke, dus deze offset is veilig.
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // VEILIGHEID: we hebben nu de originele Weak-aanwijzer hersteld, dus we kunnen de Weak creëren.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }

    /// Pogingen om de `Weak`-pointer te upgraden naar een [`Rc`], waardoor het laten vallen van de innerlijke waarde wordt vertraagd als dit lukt.
    ///
    ///
    /// Geeft [`None`] terug als de innerlijke waarde sindsdien is verwijderd.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    ///
    /// let strong_five: Option<Rc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // Vernietig alle sterke punten.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Rc<T>> {
        let inner = self.inner()?;
        if inner.strong() == 0 {
            None
        } else {
            inner.inc_strong();
            Some(Rc::from_inner(self.ptr))
        }
    }

    /// Hiermee wordt het aantal sterke (`Rc`)-aanwijzers opgehaald dat naar deze toewijzing verwijst.
    ///
    /// Als `self` is gemaakt met [`Weak::new`], retourneert dit 0.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong() } else { 0 }
    }

    /// Haalt het aantal `Weak`-aanwijzers op dat naar deze toewijzing verwijst.
    ///
    /// Als er geen sterke punten overblijven, levert dit nul op.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                if inner.strong() > 0 {
                    inner.weak() - 1 // trek de impliciete zwakke ptr af
                } else {
                    0
                }
            })
            .unwrap_or(0)
    }

    /// Geeft `None` terug als de aanwijzer bungelt en er geen toegewezen `RcBox` is (dwz wanneer deze `Weak` is gemaakt door `Weak::new`).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // We zorgen ervoor dat *niet* een referentie wordt gemaakt die het "data"-veld dekt, aangezien het veld gelijktijdig kan worden gemuteerd (als bijvoorbeeld de laatste `Rc` wordt verwijderd, wordt het dataveld op zijn plaats neergezet).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// Geeft `true` terug als de twee `Zwakke`s naar dezelfde toewijzing wijzen (vergelijkbaar met [`ptr::eq`]), of als beide niet naar een toewijzing verwijzen (omdat ze zijn gemaakt met `Weak::new()`).
    ///
    ///
    /// # Notes
    ///
    /// Aangezien dit pointers vergelijkt, betekent dit dat `Weak::new()` aan elkaar gelijk zal zijn, ook al verwijzen ze niet naar enige toewijzing.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let first_rc = Rc::new(5);
    /// let first = Rc::downgrade(&first_rc);
    /// let second = Rc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(5);
    /// let third = Rc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// `Weak::new`.
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(());
    /// let third = Rc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// Laat de `Weak`-aanwijzer vallen.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Rc::new(Foo);
    /// let weak_foo = Rc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // Drukt niets af
    /// drop(foo);        // Drukt "dropped!" af
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        inner.dec_weak();
        // de zwakke telling begint bij 1 en gaat pas naar nul als alle sterke punten verdwenen zijn.
        //
        if inner.weak() == 0 {
            unsafe {
                Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr()));
            }
        }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// Maakt een kloon van de `Weak`-aanwijzer die naar dezelfde toewijzing verwijst.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let weak_five = Rc::downgrade(&Rc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        if let Some(inner) = self.inner() {
            inner.inc_weak()
        }
        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// Construeert een nieuwe `Weak<T>`, waarbij geheugen voor `T` wordt toegewezen zonder deze te initialiseren.
    /// [`upgrade`] aanroepen voor de retourwaarde geeft altijd [`None`].
    ///
    /// [`None`]: Option
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

// NOTE: We checkten_add hier om veilig met mem::forget om te gaan.Vooral
// als je mem::forget Rcs (of Weaks) hebt, kan de ref-telling overlopen, en dan kun je de toewijzing vrijgeven terwijl openstaande Rcs (of Weaks) bestaan.
//
// We stoppen omdat dit zo'n gedegenereerd scenario is dat het ons niet kan schelen wat er gebeurt-geen enkel echt programma zou dit ooit mogen meemaken.
//
// Dit zou een verwaarloosbare overhead moeten hebben, omdat je deze niet echt hoeft te klonen in Rust dankzij eigendom en verplaatsingssemantiek.
//
//

#[doc(hidden)]
trait RcInnerPtr {
    fn weak_ref(&self) -> &Cell<usize>;
    fn strong_ref(&self) -> &Cell<usize>;

    #[inline]
    fn strong(&self) -> usize {
        self.strong_ref().get()
    }

    #[inline]
    fn inc_strong(&self) {
        let strong = self.strong();

        // We willen afbreken bij overloop in plaats van de waarde te laten vallen.
        // De referentietelling zal nooit nul zijn wanneer dit wordt aangeroepen;
        // Desalniettemin voegen we hier een abort in om LLVM te laten doorschemeren naar een anders gemiste optimalisatie.
        //
        if strong == 0 || strong == usize::MAX {
            abort();
        }
        self.strong_ref().set(strong + 1);
    }

    #[inline]
    fn dec_strong(&self) {
        self.strong_ref().set(self.strong() - 1);
    }

    #[inline]
    fn weak(&self) -> usize {
        self.weak_ref().get()
    }

    #[inline]
    fn inc_weak(&self) {
        let weak = self.weak();

        // We willen afbreken bij overloop in plaats van de waarde te laten vallen.
        // De referentietelling zal nooit nul zijn wanneer dit wordt aangeroepen;
        // Desalniettemin voegen we hier een abort in om LLVM te laten doorschemeren naar een anders gemiste optimalisatie.
        //
        if weak == 0 || weak == usize::MAX {
            abort();
        }
        self.weak_ref().set(weak + 1);
    }

    #[inline]
    fn dec_weak(&self) {
        self.weak_ref().set(self.weak() - 1);
    }
}

impl<T: ?Sized> RcInnerPtr for RcBox<T> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        &self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        &self.strong
    }
}

impl<'a> RcInnerPtr for WeakInner<'a> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        self.strong
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Rc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Rc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Rc<T> {}

/// Verkrijg de offset binnen een `RcBox` voor de payload achter een aanwijzer.
///
/// # Safety
///
/// De pointer moet verwijzen naar (en geldige metadata hebben voor) een eerder geldige instantie van T, maar de T mag worden verwijderd.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // Lijn de niet-gedimensioneerde waarde uit met het uiteinde van de RcBox.
    // Omdat RcBox repr(C) is, zal het altijd het laatste veld in het geheugen zijn.
    // VEILIGHEID: aangezien de enige mogelijke niet-bemeten typen plakjes zijn, trait-objecten,
    // en externe types, is de input veiligheidsvereiste momenteel voldoende om te voldoen aan de vereisten van align_of_val_raw;dit is een implementatiedetail van de taal waarop niet kan worden vertrouwd buiten std.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<RcBox<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}