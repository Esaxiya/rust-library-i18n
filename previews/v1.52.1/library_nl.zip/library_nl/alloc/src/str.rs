//! Unicode-reekssegmenten.
//!
//! *[See also the `str` primitive type](str).*
//!
//! Het `&str`-type is een van de twee belangrijkste stringtypen, de andere is `String`.
//! In tegenstelling tot zijn `String`-tegenhanger, wordt de inhoud geleend.
//!
//! # Basisgebruik
//!
//! Een eenvoudige tekenreeksverklaring van het type `&str`:
//!
//! ```
//! let hello_world = "Hello, World!";
//! ```
//!
//! Hier hebben we een letterlijke tekenreeks verklaard, ook wel bekend als een tekenreeksplak.
//! Letterlijke tekenreeksen hebben een statische levensduur, wat betekent dat de tekenreeks `hello_world` gegarandeerd geldig is voor de duur van het hele programma.
//!
//! We kunnen ook de levensduur van `hello_world` expliciet specificeren:
//!
//! ```
//! let hello_world: &'static str = "Hello, world!";
//! ```

#![stable(feature = "rust1", since = "1.0.0")]
// Veel van de toepassingen in deze module worden alleen gebruikt in de testconfiguratie.
// Het is schoner om de waarschuwing unused_imports gewoon uit te schakelen dan ze te repareren.
#![allow(unused_imports)]

use core::borrow::{Borrow, BorrowMut};
use core::iter::FusedIterator;
use core::mem;
use core::ptr;
use core::str::pattern::{DoubleEndedSearcher, Pattern, ReverseSearcher, Searcher};
use core::unicode::conversions;

use crate::borrow::ToOwned;
use crate::boxed::Box;
use crate::slice::{Concat, Join, SliceIndex};
use crate::string::String;
use crate::vec::Vec;

#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::pattern;
#[stable(feature = "encode_utf16", since = "1.8.0")]
pub use core::str::EncodeUtf16;
#[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
pub use core::str::SplitAsciiWhitespace;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::SplitWhitespace;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{from_utf8, from_utf8_mut, Bytes, CharIndices, Chars};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{from_utf8_unchecked, from_utf8_unchecked_mut, ParseBoolError};
#[stable(feature = "str_escape", since = "1.34.0")]
pub use core::str::{EscapeDebug, EscapeDefault, EscapeUnicode};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{FromStr, Utf8Error};
#[allow(deprecated)]
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{Lines, LinesAny};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{MatchIndices, RMatchIndices};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{Matches, RMatches};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{RSplit, Split};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{RSplitN, SplitN};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{RSplitTerminator, SplitTerminator};

/// Note: `str` in `Concat<str>` heeft hier geen betekenis.
/// Dit type parameter van de trait bestaat alleen om een ander impl.
#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<S: Borrow<str>> Concat<str> for [S] {
    type Output = String;

    fn concat(slice: &Self) -> String {
        Join::join(slice, "")
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<S: Borrow<str>> Join<&str> for [S] {
    type Output = String;

    fn join(slice: &Self, sep: &str) -> String {
        unsafe { String::from_utf8_unchecked(join_generic_copy(slice, sep.as_bytes())) }
    }
}

macro_rules! specialize_for_lengths {
    ($separator:expr, $target:expr, $iter:expr; $($num:expr),*) => {{
        let mut target = $target;
        let iter = $iter;
        let sep_bytes = $separator;
        match $separator.len() {
            $(
                // loops met hardgecodeerde maten lopen veel sneller en specialiseren de cases met kleine separatorlengtes
                //
                $num => {
                    for s in iter {
                        copy_slice_and_advance!(target, sep_bytes);
                        let content_bytes = s.borrow().as_ref();
                        copy_slice_and_advance!(target, content_bytes);
                    }
                },
            )*
            _ => {
                // willekeurige terugval van de grootte die niet gelijk is aan nul
                for s in iter {
                    copy_slice_and_advance!(target, sep_bytes);
                    let content_bytes = s.borrow().as_ref();
                    copy_slice_and_advance!(target, content_bytes);
                }
            }
        }
        target
    }}
}

macro_rules! copy_slice_and_advance {
    ($target:expr, $bytes:expr) => {
        let len = $bytes.len();
        let (head, tail) = { $target }.split_at_mut(len);
        head.copy_from_slice($bytes);
        $target = tail;
    };
}

// Geoptimaliseerde join-implementatie die werkt voor zowel Vec<T>(T: Copy) en String's innerlijke vec Momenteel is er in (2018-05-13) een bug met type-inferentie en specialisatie (zie uitgave #36262) Om deze reden is SliceConcat<T>is niet gespecialiseerd in T: Copy en SliceConcat<str>is de enige gebruiker van deze functie.
// Het wordt op zijn plaats gelaten voor de tijd dat dat is opgelost.
//
// de grenzen voor String-join zijn S: Borrow<str>en voor Vec-join Lenen <[T]> [T] en str beide impliceren AsRef <[T]> voor sommige T
// => s.borrow().as_ref() en we hebben altijd plakjes
//
//
//
fn join_generic_copy<B, T, S>(slice: &[S], sep: &[T]) -> Vec<T>
where
    T: Copy,
    B: AsRef<[T]> + ?Sized,
    S: Borrow<B>,
{
    let sep_len = sep.len();
    let mut iter = slice.iter();

    // de eerste plak is de enige zonder een scheidingsteken ervoor
    let first = match iter.next() {
        Some(first) => first,
        None => return vec![],
    };

    // bereken de exacte totale lengte van de samengevoegde Vec als de `len`-berekening overloopt, we panic we zouden toch geen geheugen meer hebben en voor de rest van de functie is de volledige Vec vooraf toegewezen voor veiligheid
    //
    //
    //
    let reserved_len = sep_len
        .checked_mul(iter.len())
        .and_then(|n| {
            slice.iter().map(|s| s.borrow().as_ref().len()).try_fold(n, usize::checked_add)
        })
        .expect("attempt to join into collection with len > usize::MAX");

    // bereid een niet-geïnitialiseerde buffer voor
    let mut result = Vec::with_capacity(reserved_len);
    debug_assert!(result.capacity() >= reserved_len);

    result.extend_from_slice(first.borrow().as_ref());

    unsafe {
        let pos = result.len();
        let target = result.get_unchecked_mut(pos..reserved_len);

        // kopie scheidingsteken en doorsneden zonder grenzen controles genereren loops met hardgecodeerde offsets voor kleine scheidingstekens enorme verbeteringen mogelijk (~ x2)
        //
        //
        let remain = specialize_for_lengths!(sep, target, iter; 0, 1, 2, 3, 4);

        // Een rare leenimplementatie kan verschillende plakjes opleveren voor de lengteberekening en de daadwerkelijke kopie.
        //
        // Zorg ervoor dat we geen niet-geïnitialiseerde bytes aan de beller blootstellen.
        let result_len = reserved_len - remain.len();
        result.set_len(result_len);
    }
    result
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Borrow<str> for String {
    #[inline]
    fn borrow(&self) -> &str {
        &self[..]
    }
}

#[stable(feature = "string_borrow_mut", since = "1.36.0")]
impl BorrowMut<str> for String {
    #[inline]
    fn borrow_mut(&mut self) -> &mut str {
        &mut self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ToOwned for str {
    type Owned = String;
    #[inline]
    fn to_owned(&self) -> String {
        unsafe { String::from_utf8_unchecked(self.as_bytes().to_owned()) }
    }

    fn clone_into(&self, target: &mut String) {
        let mut b = mem::take(target).into_bytes();
        self.as_bytes().clone_into(&mut b);
        *target = unsafe { String::from_utf8_unchecked(b) }
    }
}

/// Methoden voor snaarplakken.
#[lang = "str_alloc"]
#[cfg(not(test))]
impl str {
    /// Converteert een `Box<str>` naar een `Box<[u8]>` zonder te kopiëren of toe te wijzen.
    ///
    /// # Examples
    ///
    /// Basisgebruik:
    ///
    /// ```
    /// let s = "this is a string";
    /// let boxed_str = s.to_owned().into_boxed_str();
    /// let boxed_bytes = boxed_str.into_boxed_bytes();
    /// assert_eq!(*boxed_bytes, *s.as_bytes());
    /// ```
    #[stable(feature = "str_box_extras", since = "1.20.0")]
    #[inline]
    pub fn into_boxed_bytes(self: Box<str>) -> Box<[u8]> {
        self.into()
    }

    /// Vervangt alle overeenkomsten van een patroon door een andere tekenreeks.
    ///
    /// `replace` maakt een nieuwe [`String`] aan en kopieert de gegevens van deze stringplak erin.
    /// Terwijl het dit doet, probeert het overeenkomsten van een patroon te vinden.
    /// Als het er een vindt, worden ze vervangen door de vervangende string slice.
    ///
    /// # Examples
    ///
    /// Basisgebruik:
    ///
    /// ```
    /// let s = "this is old";
    ///
    /// assert_eq!("this is new", s.replace("old", "new"));
    /// ```
    ///
    /// Als het patroon niet overeenkomt:
    ///
    /// ```
    /// let s = "this is old";
    /// assert_eq!(s, s.replace("cookie monster", "little lamb"));
    /// ```
    #[must_use = "this returns the replaced string as a new allocation, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn replace<'a, P: Pattern<'a>>(&'a self, from: P, to: &str) -> String {
        let mut result = String::new();
        let mut last_end = 0;
        for (start, part) in self.match_indices(from) {
            result.push_str(unsafe { self.get_unchecked(last_end..start) });
            result.push_str(to);
            last_end = start + part.len();
        }
        result.push_str(unsafe { self.get_unchecked(last_end..self.len()) });
        result
    }

    /// Vervangt de eerste N overeenkomsten van een patroon door een andere tekenreeks.
    ///
    /// `replacen` maakt een nieuwe [`String`] aan en kopieert de gegevens van deze stringplak erin.
    /// Terwijl het dit doet, probeert het overeenkomsten van een patroon te vinden.
    /// Als het er een vindt, vervangt het ze maximaal `count` keer door de vervangende string slice.
    ///
    /// # Examples
    ///
    /// Basisgebruik:
    ///
    /// ```
    /// let s = "foo foo 123 foo";
    /// assert_eq!("new new 123 foo", s.replacen("foo", "new", 2));
    /// assert_eq!("faa fao 123 foo", s.replacen('o', "a", 3));
    /// assert_eq!("foo foo new23 foo", s.replacen(char::is_numeric, "new", 1));
    /// ```
    ///
    /// Als het patroon niet overeenkomt:
    ///
    /// ```
    /// let s = "this is old";
    /// assert_eq!(s, s.replacen("cookie monster", "little lamb", 10));
    /// ```
    #[must_use = "this returns the replaced string as a new allocation, \
                  without modifying the original"]
    #[stable(feature = "str_replacen", since = "1.16.0")]
    pub fn replacen<'a, P: Pattern<'a>>(&'a self, pat: P, to: &str, count: usize) -> String {
        // Hoop de tijden van herverdeling te verkorten
        let mut result = String::with_capacity(32);
        let mut last_end = 0;
        for (start, part) in self.match_indices(pat).take(count) {
            result.push_str(unsafe { self.get_unchecked(last_end..start) });
            result.push_str(to);
            last_end = start + part.len();
        }
        result.push_str(unsafe { self.get_unchecked(last_end..self.len()) });
        result
    }

    /// Retourneert het equivalent in kleine letters van deze string slice, als een nieuwe [`String`].
    ///
    /// 'Lowercase' wordt gedefinieerd volgens de voorwaarden van de Unicode Derived Core Property `Lowercase`.
    ///
    /// Aangezien sommige tekens kunnen worden uitgebreid tot meerdere tekens bij het wijzigen van hoofdlettergebruik, retourneert deze functie een [`String`] in plaats van de parameter ter plaatse te wijzigen.
    ///
    ///
    /// # Examples
    ///
    /// Basisgebruik:
    ///
    /// ```
    /// let s = "HELLO";
    ///
    /// assert_eq!("hello", s.to_lowercase());
    /// ```
    ///
    /// Een lastig voorbeeld, met sigma:
    ///
    /// ```
    /// let sigma = "Σ";
    ///
    /// assert_eq!("σ", sigma.to_lowercase());
    ///
    /// // maar aan het einde van een woord is het ς, niet σ:
    /// let odysseus = "ὈΔΥΣΣΕΎΣ";
    ///
    /// assert_eq!("ὀδυσσεύς", odysseus.to_lowercase());
    /// ```
    ///
    /// Talen zonder hoofdletters/kleine letters worden niet gewijzigd:
    ///
    /// ```
    /// let new_year = "农历新年";
    ///
    /// assert_eq!(new_year, new_year.to_lowercase());
    /// ```
    ///
    ///
    #[stable(feature = "unicode_case_mapping", since = "1.2.0")]
    pub fn to_lowercase(&self) -> String {
        let mut s = String::with_capacity(self.len());
        for (i, c) in self[..].char_indices() {
            if c == 'Σ' {
                // Σ wordt toegewezen aan σ, behalve aan het einde van een woord waar het wordt toegewezen aan ς.
                // Dit is de enige voorwaardelijke (contextual) maar taalonafhankelijke mapping in `SpecialCasing.txt`, dus codeer het in plaats van een generiek "condition"-mechanisme.
                //
                // See https://github.com/rust-lang/rust/issues/26035
                //
                map_uppercase_sigma(self, i, &mut s)
            } else {
                match conversions::to_lower(c) {
                    [a, '\0', _] => s.push(a),
                    [a, b, '\0'] => {
                        s.push(a);
                        s.push(b);
                    }
                    [a, b, c] => {
                        s.push(a);
                        s.push(b);
                        s.push(c);
                    }
                }
            }
        }
        return s;

        fn map_uppercase_sigma(from: &str, i: usize, to: &mut String) {
            // See http://www.unicode.org/versions/Unicode7.0.0/ch03.pdf#G33992
            // voor de definitie van `Final_Sigma`.
            debug_assert!('Σ'.len_utf8() == 2);
            let is_word_final = case_ignoreable_then_cased(from[..i].chars().rev())
                && !case_ignoreable_then_cased(from[i + 2..].chars());
            to.push_str(if is_word_final { "ς" } else { "σ" });
        }

        fn case_ignoreable_then_cased<I: Iterator<Item = char>>(iter: I) -> bool {
            use core::unicode::{Case_Ignorable, Cased};
            match iter.skip_while(|&c| Case_Ignorable(c)).next() {
                Some(c) => Cased(c),
                None => false,
            }
        }
    }

    /// Retourneert het equivalent in hoofdletters van deze tekenreeks, als een nieuwe [`String`].
    ///
    /// 'Uppercase' wordt gedefinieerd volgens de voorwaarden van de Unicode Derived Core Property `Uppercase`.
    ///
    /// Aangezien sommige tekens kunnen worden uitgebreid tot meerdere tekens bij het wijzigen van hoofdlettergebruik, retourneert deze functie een [`String`] in plaats van de parameter ter plaatse te wijzigen.
    ///
    ///
    /// # Examples
    ///
    /// Basisgebruik:
    ///
    /// ```
    /// let s = "hello";
    ///
    /// assert_eq!("HELLO", s.to_uppercase());
    /// ```
    ///
    /// Scripts zonder hoofdletters/kleine letters worden niet gewijzigd:
    ///
    /// ```
    /// let new_year = "农历新年";
    ///
    /// assert_eq!(new_year, new_year.to_uppercase());
    /// ```
    ///
    /// Eén personage kan meerdere worden:
    ///
    /// ```
    /// let s = "tschüß";
    ///
    /// assert_eq!("TSCHÜSS", s.to_uppercase());
    /// ```
    ///
    #[stable(feature = "unicode_case_mapping", since = "1.2.0")]
    pub fn to_uppercase(&self) -> String {
        let mut s = String::with_capacity(self.len());
        for c in self[..].chars() {
            match conversions::to_upper(c) {
                [a, '\0', _] => s.push(a),
                [a, b, '\0'] => {
                    s.push(a);
                    s.push(b);
                }
                [a, b, c] => {
                    s.push(a);
                    s.push(b);
                    s.push(c);
                }
            }
        }
        s
    }

    /// Converteert een [`Box<str>`] naar een [`String`] zonder te kopiëren of toe te wijzen.
    ///
    /// # Examples
    ///
    /// Basisgebruik:
    ///
    /// ```
    /// let string = String::from("birthday gift");
    /// let boxed_str = string.clone().into_boxed_str();
    ///
    /// assert_eq!(boxed_str.into_string(), string);
    /// ```
    #[stable(feature = "box_str", since = "1.4.0")]
    #[inline]
    pub fn into_string(self: Box<str>) -> String {
        let slice = Box::<[u8]>::from(self);
        unsafe { String::from_utf8_unchecked(slice.into_vec()) }
    }

    /// Maakt een nieuwe [`String`] door een string `n` keer te herhalen.
    ///
    /// # Panics
    ///
    /// Deze functie zal panic zijn als de capaciteit zou overlopen.
    ///
    /// # Examples
    ///
    /// Basisgebruik:
    ///
    /// ```
    /// assert_eq!("abc".repeat(4), String::from("abcabcabcabc"));
    /// ```
    ///
    /// A panic bij overloop:
    ///
    /// ```should_panic
    /// // this will panic at runtime
    /// "0123456789abcdef".repeat(usize::MAX);
    /// ```
    #[stable(feature = "repeat_str", since = "1.16.0")]
    pub fn repeat(&self, n: usize) -> String {
        unsafe { String::from_utf8_unchecked(self.as_bytes().repeat(n)) }
    }

    /// Retourneert een kopie van deze tekenreeks waarbij elk teken wordt toegewezen aan het ASCII-equivalent in hoofdletters.
    ///
    ///
    /// ASCII-letters 'a' tot 'z' worden toegewezen aan 'A' tot 'Z', maar niet-ASCII-letters blijven ongewijzigd.
    ///
    /// Gebruik [`make_ascii_uppercase`] om de waarde ter plekke in hoofdletters te zetten.
    ///
    /// Gebruik [`to_uppercase`] om ASCII-tekens in hoofdletters te gebruiken naast niet-ASCII-tekens.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Grüße, Jürgen ❤";
    ///
    /// assert_eq!("GRüßE, JüRGEN ❤", s.to_ascii_uppercase());
    /// ```
    ///
    /// [`make_ascii_uppercase`]: str::make_ascii_uppercase
    /// [`to_uppercase`]: #method.to_uppercase
    ///
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_uppercase(&self) -> String {
        let mut bytes = self.as_bytes().to_vec();
        bytes.make_ascii_uppercase();
        // make_ascii_uppercase() behoudt de UTF-8-invariant.
        unsafe { String::from_utf8_unchecked(bytes) }
    }

    /// Retourneert een kopie van deze tekenreeks waarbij elk teken wordt toegewezen aan het ASCII-equivalent in kleine letters.
    ///
    ///
    /// ASCII-letters 'A' tot 'Z' worden toegewezen aan 'a' tot 'z', maar niet-ASCII-letters blijven ongewijzigd.
    ///
    /// Gebruik [`make_ascii_lowercase`] om de waarde op zijn plaats in kleine letters te zetten.
    ///
    /// Gebruik [`to_lowercase`] om ASCII-tekens in kleine letters naast niet-ASCII-tekens te gebruiken.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Grüße, Jürgen ❤";
    ///
    /// assert_eq!("grüße, jürgen ❤", s.to_ascii_lowercase());
    /// ```
    ///
    /// [`make_ascii_lowercase`]: str::make_ascii_lowercase
    /// [`to_lowercase`]: #method.to_lowercase
    ///
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_lowercase(&self) -> String {
        let mut bytes = self.as_bytes().to_vec();
        bytes.make_ascii_lowercase();
        // make_ascii_lowercase() behoudt de UTF-8-invariant.
        unsafe { String::from_utf8_unchecked(bytes) }
    }
}

/// Converteert een boxed slice bytes naar een boxed string slice zonder te controleren of de string geldige UTF-8 bevat.
///
///
/// # Examples
///
/// Basisgebruik:
///
/// ```
/// let smile_utf8 = Box::new([226, 152, 186]);
/// let smile = unsafe { std::str::from_boxed_utf8_unchecked(smile_utf8) };
///
/// assert_eq!("☺", &*smile);
/// ```
#[stable(feature = "str_box_extras", since = "1.20.0")]
#[inline]
pub unsafe fn from_boxed_utf8_unchecked(v: Box<[u8]>) -> Box<str> {
    unsafe { Box::from_raw(Box::into_raw(v) as *mut str) }
}