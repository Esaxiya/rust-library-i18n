//! Een prioriteitswachtrij geïmplementeerd met een binaire heap.
//!
//! Invoegen en popping van het grootste element hebben een tijdcomplexiteit van *O*(log(*n*)).
//! Het controleren van het grootste element is *O*(1).Het omzetten van een vector naar een binaire heap kan ter plaatse worden gedaan en heeft *O*(*n*) complexiteit.
//! Een binaire heap kan ook worden geconverteerd naar een gesorteerde vector in-place, waardoor deze kan worden gebruikt voor een *O*(*n*\*log(* n*)) in-place heapsort.
//!
//! # Examples
//!
//! Dit is een groter voorbeeld dat [Dijkstra's algorithm][dijkstra] implementeert om de [shortest path problem][sssp] op een [directed graph][dir_graph] op te lossen.
//!
//! Het laat zien hoe u [`BinaryHeap`] met aangepaste typen kunt gebruiken.
//!
//! [dijkstra]: https://en.wikipedia.org/wiki/Dijkstra%27s_algorithm
//! [sssp]: https://en.wikipedia.org/wiki/Shortest_path_problem
//! [dir_graph]: https://en.wikipedia.org/wiki/Directed_graph
//!
//! ```
//! use std::cmp::Ordering;
//! use std::collections::BinaryHeap;
//!
//! #[derive(Copy, Clone, Eq, PartialEq)]
//! struct State {
//!     cost: usize,
//!     position: usize,
//! }
//!
//! // De prioriteitswachtrij is afhankelijk van `Ord`.
//! // Implementeer de trait expliciet zodat de wachtrij een min-heap wordt in plaats van een max-heap.
//! //
//! impl Ord for State {
//!     fn cmp(&self, other: &Self) -> Ordering {
//!         // Merk op dat we de bestelling op kosten omdraaien.
//!         // In het geval van een gelijkspel vergelijken we posities, deze stap is nodig om implementaties van `PartialEq` en `Ord` consistent te maken.
//!         //
//!         other.cost.cmp(&self.cost)
//!             .then_with(|| self.position.cmp(&other.position))
//!     }
//! }
//!
//! // `PartialOrd` moet ook worden geïmplementeerd.
//! impl PartialOrd for State {
//!     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
//!         Some(self.cmp(other))
//!     }
//! }
//!
//! // Elk knooppunt wordt weergegeven als een `usize`, voor een kortere implementatie.
//! struct Edge {
//!     node: usize,
//!     cost: usize,
//! }
//!
//! // Dijkstra's kortste pad-algoritme.
//!
//! // Begin bij `start` en gebruik `dist` om de huidige kortste afstand naar elk knooppunt te volgen.Deze implementatie is niet geheugenefficiënt omdat het dubbele knooppunten in de wachtrij kan achterlaten.
//! //
//! // Het gebruikt ook `usize::MAX` als een sentinel-waarde, voor een eenvoudigere implementatie.
//! //
//! fn shortest_path(adj_list: &Vec<Vec<Edge>>, start: usize, goal: usize) -> Option<usize> {
//!     // dist [node]=huidige kortste afstand van `start` tot `node`
//!     let mut dist: Vec<_> = (0..adj_list.len()).map(|_| usize::MAX).collect();
//!
//!     let mut heap = BinaryHeap::new();
//!
//!     // We zijn bij `start`, zonder kosten
//!     dist[start] = 0;
//!     heap.push(State { cost: 0, position: start });
//!
//!     // Onderzoek eerst de grens met goedkopere knooppunten (min-heap)
//!     while let Some(State { cost, position }) = heap.pop() {
//!         // Als alternatief hadden we alle kortste paden kunnen blijven zoeken
//!         if position == goal { return Some(cost); }
//!
//!         // Belangrijk omdat we misschien al een betere manier hebben gevonden
//!         if cost > dist[position] { continue; }
//!
//!         // Kijk voor elk knooppunt dat we kunnen bereiken of we een manier kunnen vinden met lagere kosten om door dit knooppunt te gaan
//!         //
//!         for edge in &adj_list[position] {
//!             let next = State { cost: cost + edge.cost, position: edge.node };
//!
//!             // Zo ja, voeg het dan toe aan de grens en ga verder
//!             if next.cost < dist[next.position] {
//!                 heap.push(next);
//!                 // Ontspanning, we hebben nu een betere manier gevonden
//!                 dist[next.position] = next.cost;
//!             }
//!         }
//!     }
//!
//!     // Doel niet bereikbaar
//!     None
//! }
//!
//! fn main() {
//!     // Dit is de gerichte grafiek die we gaan gebruiken.
//!     // De knooppuntnummers komen overeen met de verschillende toestanden en de edge-gewichten symboliseren de kosten van het verplaatsen van het ene knooppunt naar het andere.
//!     //
//!     // Merk op dat de randen eenrichtingsverkeer zijn.
//!     //
//!     //                  7
//!     //          +-----------------+
//!     //          |                 |
//!     //          v 1 2 |2
//!     //          0-----> 1-- ---> 3-- -> 4
//!     //          |        ^        ^      ^
//!     //          |        | 1      |      |
//!     //          |        |        | 3    | 1          +------> 2 -------+      |
//!     //           10 ||
//!     //                   +---------------+
//!     //
//!     // De grafiek wordt weergegeven als een aangrenzende lijst waarbij elke index, die overeenkomt met een knooppuntwaarde, een lijst met uitgaande randen heeft.
//!     // Gekozen vanwege zijn efficiëntie.
//!     //
//!     //
//!     //
//!     let graph = vec![
//!         // Knooppunt 0
//!         vec![Edge { node: 2, cost: 10 },
//!              Edge { node: 1, cost: 1 }],
//!         // Knooppunt 1
//!         vec![Edge { node: 3, cost: 2 }],
//!         // Knooppunt 2
//!         vec![Edge { node: 1, cost: 1 },
//!              Edge { node: 3, cost: 3 },
//!              Edge { node: 4, cost: 1 }],
//!         // Knooppunt 3
//!         vec![Edge { node: 0, cost: 7 },
//!              Edge { node: 4, cost: 2 }],
//!         // Knooppunt 4
//!         vec![]];
//!
//!     assert_eq!(shortest_path(&graph, 0, 1), Some(1));
//!     assert_eq!(shortest_path(&graph, 0, 3), Some(3));
//!     assert_eq!(shortest_path(&graph, 3, 0), Some(7));
//!     assert_eq!(shortest_path(&graph, 0, 4), Some(5));
//!     assert_eq!(shortest_path(&graph, 4, 0), None);
//! }
//! ```
//!
//!

#![allow(missing_docs)]
#![stable(feature = "rust1", since = "1.0.0")]

use core::fmt;
use core::iter::{FromIterator, FusedIterator, InPlaceIterable, SourceIter, TrustedLen};
use core::mem::{self, swap, ManuallyDrop};
use core::ops::{Deref, DerefMut};
use core::ptr;

use crate::slice;
use crate::vec::{self, AsIntoIter, Vec};

use super::SpecExtend;

/// Een prioriteitswachtrij geïmplementeerd met een binaire heap.
///
/// Dit wordt een max-heap.
///
/// Het is een logische fout dat een item zodanig wordt gewijzigd dat de volgorde van het item ten opzichte van een ander item, zoals bepaald door de `Ord` trait, verandert terwijl het zich in de heap bevindt.
///
/// Dit is normaal gesproken alleen mogelijk via `Cell`, `RefCell`, globale status, I/O of onveilige code.
/// Het gedrag dat het gevolg is van een dergelijke logische fout is niet gespecificeerd, maar zal niet resulteren in ongedefinieerd gedrag.
/// Dit kan panics, onjuiste resultaten, afgebroken, geheugenlekken en niet-beëindiging omvatten.
///
/// # Examples
///
/// ```
/// use std::collections::BinaryHeap;
///
/// // Met type-inferentie kunnen we een expliciete type-handtekening weglaten (wat in dit voorbeeld `BinaryHeap<i32>` zou zijn).
/////
/// let mut heap = BinaryHeap::new();
///
/// // We kunnen een kijkje gebruiken om naar het volgende item in de hoop te kijken.
/// // In dit geval zijn er nog geen items, dus we krijgen geen.
/// assert_eq!(heap.peek(), None);
///
/// // Laten we wat scores toevoegen ...
/// heap.push(1);
/// heap.push(5);
/// heap.push(2);
///
/// // Nu zie je het belangrijkste item in de hoop.
/// assert_eq!(heap.peek(), Some(&5));
///
/// // We kunnen de lengte van een hoop controleren.
/// assert_eq!(heap.len(), 3);
///
/// // We kunnen de items in de heap herhalen, hoewel ze in een willekeurige volgorde worden geretourneerd.
/////
/// for x in &heap {
///     println!("{}", x);
/// }
///
/// // Als we deze partituren in plaats daarvan poppen, moeten ze op volgorde terugkomen.
/// assert_eq!(heap.pop(), Some(5));
/// assert_eq!(heap.pop(), Some(2));
/// assert_eq!(heap.pop(), Some(1));
/// assert_eq!(heap.pop(), None);
///
/// // We kunnen alle resterende items opruimen.
/// heap.clear();
///
/// // De hoop zou nu leeg moeten zijn.
/// assert!(heap.is_empty())
/// ```
///
/// ## Min-heap
///
/// Ofwel `std::cmp::Reverse` of een aangepaste `Ord`-implementatie kan worden gebruikt om van `BinaryHeap` een min-heap te maken.
/// Hierdoor retourneert `heap.pop()` de kleinste waarde in plaats van de grootste.
///
/// ```
/// use std::collections::BinaryHeap;
/// use std::cmp::Reverse;
///
/// let mut heap = BinaryHeap::new();
///
/// // Wikkel waarden in `Reverse`
/// heap.push(Reverse(1));
/// heap.push(Reverse(5));
/// heap.push(Reverse(2));
///
/// // Als we deze partituren nu poppen, zouden ze in omgekeerde volgorde terug moeten komen.
/// assert_eq!(heap.pop(), Some(Reverse(1)));
/// assert_eq!(heap.pop(), Some(Reverse(2)));
/// assert_eq!(heap.pop(), Some(Reverse(5)));
/// assert_eq!(heap.pop(), None);
/// ```
///
/// # Tijdscomplexiteit
///
/// | [push] | [pop]     | [peek]/[peek\_mut] |
/// |--------|-----------|--------------------|
/// | O(1)~  | *O*(log(*n*)) | *O*(1)               |
///
/// De waarde voor `push` zijn verwachte kosten;de methodedocumentatie geeft een meer gedetailleerde analyse.
///
/// [push]: BinaryHeap::push
/// [pop]: BinaryHeap::pop
/// [peek]: BinaryHeap::peek
/// [peek\_mut]: BinaryHeap::peek_mut
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "BinaryHeap")]
pub struct BinaryHeap<T> {
    data: Vec<T>,
}

/// Structuur met een veranderlijke verwijzing naar het beste item op een `BinaryHeap`.
///
///
/// Deze `struct` is gemaakt door de [`peek_mut`]-methode op [`BinaryHeap`].
/// Zie de documentatie voor meer.
///
/// [`peek_mut`]: BinaryHeap::peek_mut
#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
pub struct PeekMut<'a, T: 'a + Ord> {
    heap: &'a mut BinaryHeap<T>,
    sift: bool,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: Ord + fmt::Debug> fmt::Debug for PeekMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("PeekMut").field(&self.heap.data[0]).finish()
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> Drop for PeekMut<'_, T> {
    fn drop(&mut self) {
        if self.sift {
            // VEILIGHEID: PeekMut wordt alleen geïnstantieerd voor niet-lege hopen.
            unsafe { self.heap.sift_down(0) };
        }
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> Deref for PeekMut<'_, T> {
    type Target = T;
    fn deref(&self) -> &T {
        debug_assert!(!self.heap.is_empty());
        // VEILIG: PeekMut wordt alleen geïnstantieerd voor niet-lege hopen
        unsafe { self.heap.data.get_unchecked(0) }
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> DerefMut for PeekMut<'_, T> {
    fn deref_mut(&mut self) -> &mut T {
        debug_assert!(!self.heap.is_empty());
        self.sift = true;
        // VEILIG: PeekMut wordt alleen geïnstantieerd voor niet-lege hopen
        unsafe { self.heap.data.get_unchecked_mut(0) }
    }
}

impl<'a, T: Ord> PeekMut<'a, T> {
    /// Verwijdert de gepiekte waarde uit de heap en retourneert deze.
    #[stable(feature = "binary_heap_peek_mut_pop", since = "1.18.0")]
    pub fn pop(mut this: PeekMut<'a, T>) -> T {
        let value = this.heap.pop().unwrap();
        this.sift = false;
        value
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for BinaryHeap<T> {
    fn clone(&self) -> Self {
        BinaryHeap { data: self.data.clone() }
    }

    fn clone_from(&mut self, source: &Self) {
        self.data.clone_from(&source.data);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Default for BinaryHeap<T> {
    /// Creëert een lege `BinaryHeap<T>`.
    #[inline]
    fn default() -> BinaryHeap<T> {
        BinaryHeap::new()
    }
}

#[stable(feature = "binaryheap_debug", since = "1.4.0")]
impl<T: fmt::Debug> fmt::Debug for BinaryHeap<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self.iter()).finish()
    }
}

impl<T: Ord> BinaryHeap<T> {
    /// Creëert een lege `BinaryHeap` als een max-heap.
    ///
    /// # Examples
    ///
    /// Basisgebruik:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new() -> BinaryHeap<T> {
        BinaryHeap { data: vec![] }
    }

    /// Creëert een lege `BinaryHeap` met een specifieke capaciteit.
    /// Dit wijst vooraf voldoende geheugen toe voor `capacity`-elementen, zodat de `BinaryHeap` niet opnieuw hoeft te worden toegewezen totdat deze minstens zoveel waarden bevat.
    ///
    ///
    /// # Examples
    ///
    /// Basisgebruik:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::with_capacity(10);
    /// heap.push(4);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> BinaryHeap<T> {
        BinaryHeap { data: Vec::with_capacity(capacity) }
    }

    /// Retourneert een veranderlijke verwijzing naar het grootste item in de binaire heap, of `None` als het leeg is.
    ///
    /// Note: Als de `PeekMut`-waarde is gelekt, is de heap mogelijk in een inconsistente staat.
    ///
    /// # Examples
    ///
    /// Basisgebruik:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// assert!(heap.peek_mut().is_none());
    ///
    /// heap.push(1);
    /// heap.push(5);
    /// heap.push(2);
    /// {
    ///     let mut val = heap.peek_mut().unwrap();
    ///     *val = 0;
    /// }
    /// assert_eq!(heap.peek(), Some(&2));
    /// ```
    ///
    /// # Tijdscomplexiteit
    ///
    /// Als het item is gewijzigd, is de tijdcomplexiteit in het slechtste geval *O*(log(*n*)), anders is het *O*(1).
    ///
    ///
    ///
    #[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
    pub fn peek_mut(&mut self) -> Option<PeekMut<'_, T>> {
        if self.is_empty() { None } else { Some(PeekMut { heap: self, sift: false }) }
    }

    /// Verwijdert het grootste item uit de binaire heap en geeft het terug, of `None` als het leeg is.
    ///
    ///
    /// # Examples
    ///
    /// Basisgebruik:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert_eq!(heap.pop(), Some(3));
    /// assert_eq!(heap.pop(), Some(1));
    /// assert_eq!(heap.pop(), None);
    /// ```
    ///
    /// # Tijdscomplexiteit
    ///
    /// De ongunstigste kosten van `pop` op een hoop met *n*-elementen zijn *O*(log(*n*)).
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<T> {
        self.data.pop().map(|mut item| {
            if !self.is_empty() {
                swap(&mut item, &mut self.data[0]);
                // VEILIGHEID: !self.is_empty() betekent dat self.len()> 0
                unsafe { self.sift_down_to_bottom(0) };
            }
            item
        })
    }

    /// Duwt een item naar de binaire heap.
    ///
    /// # Examples
    ///
    /// Basisgebruik:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.push(3);
    /// heap.push(5);
    /// heap.push(1);
    ///
    /// assert_eq!(heap.len(), 3);
    /// assert_eq!(heap.peek(), Some(&5));
    /// ```
    ///
    /// # Tijdscomplexiteit
    ///
    /// De verwachte kosten van `push`, gemiddeld over elke mogelijke volgorde van de elementen die worden geduwd, en over een voldoende groot aantal duwbewegingen, zijn *O*(1).
    ///
    /// Dit is de meest betekenisvolle kostenstatistiek bij het pushen van elementen die *niet* al in een gesorteerd patroon zitten.
    ///
    /// De tijdcomplexiteit neemt af als elementen in overwegend oplopende volgorde worden geduwd.
    /// In het ergste geval worden elementen in oplopende gesorteerde volgorde gepusht en is de geamortiseerde kostprijs per push *O*(log(*n*)) tegen een hoop met *n* elementen.
    ///
    /// De slechtste kosten van een *enkele* oproep naar `push` zijn *O*(*n*).Het ergste geval doet zich voor wanneer de capaciteit is uitgeput en het formaat moet worden aangepast.
    /// De kosten voor het wijzigen van het formaat zijn afgeschreven in de vorige cijfers.
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, item: T) {
        let old_len = self.len();
        self.data.push(item);
        // VEILIGHEID: sinds we een nieuw item hebben gepusht, betekent dit dat
        //  old_len= self.len(), 1 <self.len()
        unsafe { self.sift_up(0, old_len) };
    }

    /// Gebruikt de `BinaryHeap` en retourneert een vector in gesorteerde (ascending)-volgorde.
    ///
    ///
    /// # Examples
    ///
    /// Basisgebruik:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![1, 2, 4, 5, 7]);
    /// heap.push(6);
    /// heap.push(3);
    ///
    /// let vec = heap.into_sorted_vec();
    /// assert_eq!(vec, [1, 2, 3, 4, 5, 6, 7]);
    /// ```
    #[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
    pub fn into_sorted_vec(mut self) -> Vec<T> {
        let mut end = self.len();
        while end > 1 {
            end -= 1;
            // VEILIGHEID: `end` gaat van `self.len() - 1` naar 1 (beide inbegrepen),
            //  dus het is altijd een geldige index om toegang te krijgen.
            //  Het is veilig om toegang te krijgen tot index 0 (dwz `ptr`), omdat
            //  1 <=end <self.len(), wat self.len()>=2 betekent.
            unsafe {
                let ptr = self.data.as_mut_ptr();
                ptr::swap(ptr, ptr.add(end));
            }
            // VEILIGHEID: `end` gaat van `self.len() - 1` naar 1 (beide inbegrepen) dus:
            //  0 <1 <=einde <= self.len(), 1 <self.len() Wat betekent 0 <einde en einde <self.len().
            //
            unsafe { self.sift_down_range(0, end) };
        }
        self.into_vec()
    }

    // De implementaties van sift_up en sift_down gebruiken onveilige blokken om een element uit de vector te halen (een gat achterlatend), langs de andere te schuiven en het verwijderde element terug te verplaatsen naar de vector op de uiteindelijke locatie van het gat.
    //
    // Het `Hole`-type wordt gebruikt om dit weer te geven en ervoor te zorgen dat het gat aan het einde van zijn bereik wordt gevuld, zelfs op panic.
    // Het gebruik van een hole vermindert de constante factor in vergelijking met het gebruik van swaps, waarbij twee keer zoveel zetten nodig zijn.
    //
    //
    //
    //

    /// # Safety
    ///
    /// De beller moet garanderen dat `pos < self.len()`.
    unsafe fn sift_up(&mut self, start: usize, pos: usize) -> usize {
        // Verwijder de waarde bij `pos` en maak een gat.
        // VEILIGHEID: De beller garandeert dat pos <self.len()
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };

        while hole.pos() > start {
            let parent = (hole.pos() - 1) / 2;

            // VEILIGHEID: hole.pos()> start>=0, wat hole.pos()> 0 betekent
            //  en dus hole.pos(), 1 kan niet onderlopen.
            //  Dit garandeert dat ouder <hole.pos() dus het is een geldige index en ook!= hole.pos().
            //
            if hole.element() <= unsafe { hole.get(parent) } {
                break;
            }

            // VEILIGHEID: hetzelfde als hierboven
            unsafe { hole.move_to(parent) };
        }

        hole.pos()
    }

    /// Neem een element bij `pos` en verplaats het naar beneden, terwijl de kinderen groter zijn.
    ///
    ///
    /// # Safety
    ///
    /// De beller moet garanderen dat `pos < end <= self.len()`.
    unsafe fn sift_down_range(&mut self, pos: usize, end: usize) {
        // VEILIGHEID: De beller garandeert dat pos <end <= self.len().
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };
        let mut child = 2 * hole.pos() + 1;

        // Lus invariant: kind==2 * hole.pos() + 1.
        while child <= end.saturating_sub(2) {
            // vergelijk met de grootste van de twee kinderen VEILIGHEID: kind <end, 1 <self.len() en kind + 1 <end <= self.len(), dus het zijn geldige indexen.
            //
            //  kind==2 *hole.pos() + 1!= hole.pos() en kind + 1==2* hole.pos() + 2!= hole.pos().
            // FIXME: 2 *hole.pos() + 1 of 2* hole.pos() + 2 kunnen overlopen als T een ZST is
            //
            //
            //
            child += unsafe { hole.get(child) <= hole.get(child + 1) } as usize;

            // als we al in orde zijn, stop dan.
            // VEILIGHEID: kind is nu of het oude kind of het oude kind + 1
            //  We hebben al bewezen dat beide <self.len() en!= hole.pos() zijn
            if hole.element() >= unsafe { hole.get(child) } {
                return;
            }

            // VEILIGHEID: hetzelfde als hierboven.
            unsafe { hole.move_to(child) };
            child = 2 * hole.pos() + 1;
        }

        // VEILIGHEID: &&kortsluiting, wat betekent dat in de
        //  tweede voorwaarde het is al waar dat child==end, 1 <self.len().
        if child == end - 1 && hole.element() < unsafe { hole.get(child) } {
            // VEILIGHEID: het is al bewezen dat het kind een geldige index is en
            //  kind==2 * hole.pos() + 1!= hole.pos().
            unsafe { hole.move_to(child) };
        }
    }

    /// # Safety
    ///
    /// De beller moet garanderen dat `pos < self.len()`.
    unsafe fn sift_down(&mut self, pos: usize) {
        let len = self.len();
        // VEILIGHEID: pos <len wordt gegarandeerd door de beller en
        //  uiteraard len= self.len() <= self.len().
        unsafe { self.sift_down_range(pos, len) };
    }

    /// Neem een element op `pos` en verplaats het helemaal naar beneden over de hoop, en zeef het dan omhoog naar zijn positie.
    ///
    ///
    /// Note: Dit is sneller wanneer bekend is dat het element groot is/dichter bij de bodem moet zijn.
    ///
    /// # Safety
    ///
    /// De beller moet garanderen dat `pos < self.len()`.
    ///
    unsafe fn sift_down_to_bottom(&mut self, mut pos: usize) {
        let end = self.len();
        let start = pos;

        // VEILIGHEID: De beller garandeert dat pos <self.len().
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };
        let mut child = 2 * hole.pos() + 1;

        // Lus invariant: kind==2 * hole.pos() + 1.
        while child <= end.saturating_sub(2) {
            // VEILIGHEID: kind <end, 1 <self.len() en
            //  child + 1 <end <= self.len(), dus het zijn geldige indexen.
            //  kind==2 *hole.pos() + 1!= hole.pos() en kind + 1==2* hole.pos() + 2!= hole.pos().
            //
            // FIXME: 2 *hole.pos() + 1 of 2* hole.pos() + 2 kunnen overlopen als T een ZST is
            //
            child += unsafe { hole.get(child) <= hole.get(child + 1) } as usize;

            // VEILIGHEID: hetzelfde als hierboven
            unsafe { hole.move_to(child) };
            child = 2 * hole.pos() + 1;
        }

        if child == end - 1 {
            // VEILIGHEID: child==end, 1 <self.len(), dus het is een geldige index
            //  en kind==2 * hole.pos() + 1!= hole.pos().
            unsafe { hole.move_to(child) };
        }
        pos = hole.pos();
        drop(hole);

        // VEILIGHEID: pos is de positie in het gat en was al bewezen
        //  om een geldige index te zijn.
        unsafe { self.sift_up(start, pos) };
    }

    fn rebuild(&mut self) {
        let mut n = self.len() / 2;
        while n > 0 {
            n -= 1;
            // VEILIGHEID: n begint bij self.len()/2 en daalt tot 0.
            //  Het enige geval wanneer! (N <self.len()) is if self.len() ==0, maar het wordt uitgesloten door de lusvoorwaarde.
            //
            unsafe { self.sift_down(n) };
        }
    }

    /// Verplaatst alle elementen van `other` naar `self`, waardoor `other` leeg blijft.
    ///
    /// # Examples
    ///
    /// Basisgebruik:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    ///
    /// let v = vec![-10, 1, 2, 3, 3];
    /// let mut a = BinaryHeap::from(v);
    ///
    /// let v = vec![-20, 5, 43];
    /// let mut b = BinaryHeap::from(v);
    ///
    /// a.append(&mut b);
    ///
    /// assert_eq!(a.into_sorted_vec(), [-20, -10, 1, 2, 3, 3, 5, 43]);
    /// assert!(b.is_empty());
    /// ```
    #[stable(feature = "binary_heap_append", since = "1.11.0")]
    pub fn append(&mut self, other: &mut Self) {
        if self.len() < other.len() {
            swap(self, other);
        }

        if other.is_empty() {
            return;
        }

        #[inline(always)]
        fn log2_fast(x: usize) -> usize {
            (usize::BITS - x.leading_zeros() - 1) as usize
        }

        // `rebuild` neemt O(len1 + len2)-bewerkingen en ongeveer 2 *(len1 + len2) vergelijkingen in het slechtste geval, terwijl `extend` O(len2* log(len1))-bewerkingen uitvoert en ongeveer 1 *len2* log_2(len1)-vergelijkingen in het ergste geval, uitgaande van len1>= len2.
        // Voor grotere hopen volgt het kruispunt niet langer deze redenering en is empirisch bepaald.
        //
        //
        //
        //
        #[inline]
        fn better_to_rebuild(len1: usize, len2: usize) -> bool {
            let tot_len = len1 + len2;
            if tot_len <= 2048 {
                2 * tot_len < len2 * log2_fast(len1)
            } else {
                2 * tot_len < len2 * 11
            }
        }

        if better_to_rebuild(self.len(), other.len()) {
            self.data.append(&mut other.data);
            self.rebuild();
        } else {
            self.extend(other.drain());
        }
    }

    /// Retourneert een iterator die elementen in heapvolgorde ophaalt.
    /// De opgehaalde elementen worden verwijderd uit de oorspronkelijke heap.
    /// De overige elementen worden verwijderd bij het neerzetten in heap-volgorde.
    ///
    /// Note:
    /// * `.drain_sorted()` is *O*(*n*\*log(* n*)); veel langzamer dan `.drain()`.
    ///   In de meeste gevallen moet u de laatste gebruiken.
    ///
    /// # Examples
    ///
    /// Basisgebruik:
    ///
    /// ```
    /// #![feature(binary_heap_drain_sorted)]
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![1, 2, 3, 4, 5]);
    /// assert_eq!(heap.len(), 5);
    ///
    /// drop(heap.drain_sorted()); // verwijdert alle elementen in heap-volgorde
    /// assert_eq!(heap.len(), 0);
    /// ```
    #[inline]
    #[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
    pub fn drain_sorted(&mut self) -> DrainSorted<'_, T> {
        DrainSorted { inner: self }
    }

    /// Behoudt alleen de elementen die zijn gespecificeerd door het predikaat.
    ///
    /// Met andere woorden, verwijder alle elementen `e` zodat `f(&e)` `false` retourneert.
    /// De elementen worden in ongesorteerde (en niet-gespecificeerde) volgorde bezocht.
    ///
    /// # Examples
    ///
    /// Basisgebruik:
    ///
    /// ```
    /// #![feature(binary_heap_retain)]
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![-10, -5, 1, 2, 4, 13]);
    ///
    /// heap.retain(|x| x % 2 == 0); // houd alleen even nummers
    ///
    /// assert_eq!(heap.into_sorted_vec(), [-10, 2, 4])
    /// ```
    #[unstable(feature = "binary_heap_retain", issue = "71503")]
    pub fn retain<F>(&mut self, f: F)
    where
        F: FnMut(&T) -> bool,
    {
        self.data.retain(f);
        self.rebuild();
    }
}

impl<T> BinaryHeap<T> {
    /// Retourneert een iterator die alle waarden in de onderliggende vector bezoekt, in willekeurige volgorde.
    ///
    ///
    /// # Examples
    ///
    /// Basisgebruik:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4]);
    ///
    /// // Druk 1, 2, 3, 4 in willekeurige volgorde af
    /// for x in heap.iter() {
    ///     println!("{}", x);
    /// }
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter { iter: self.data.iter() }
    }

    /// Retourneert een iterator die elementen in heapvolgorde ophaalt.
    /// Deze methode verbruikt de oorspronkelijke heap.
    ///
    /// # Examples
    ///
    /// Basisgebruik:
    ///
    /// ```
    /// #![feature(binary_heap_into_iter_sorted)]
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4, 5]);
    ///
    /// assert_eq!(heap.into_iter_sorted().take(2).collect::<Vec<_>>(), vec![5, 4]);
    /// ```
    #[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
    pub fn into_iter_sorted(self) -> IntoIterSorted<T> {
        IntoIterSorted { inner: self }
    }

    /// Retourneert het grootste item in de binaire heap, of `None` als het leeg is.
    ///
    /// # Examples
    ///
    /// Basisgebruik:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// assert_eq!(heap.peek(), None);
    ///
    /// heap.push(1);
    /// heap.push(5);
    /// heap.push(2);
    /// assert_eq!(heap.peek(), Some(&5));
    ///
    /// ```
    ///
    /// # Tijdscomplexiteit
    ///
    /// De kosten zijn *O*(1) in het ergste geval.
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn peek(&self) -> Option<&T> {
        self.data.get(0)
    }

    /// Retourneert het aantal elementen dat de binaire heap kan bevatten zonder opnieuw toe te wijzen.
    ///
    /// # Examples
    ///
    /// Basisgebruik:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::with_capacity(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.data.capacity()
    }

    /// Reserveert de minimumcapaciteit voor precies `additional` meer elementen die in de gegeven `BinaryHeap` moeten worden ingevoegd.
    /// Doet niets als de capaciteit al voldoende is.
    ///
    /// Merk op dat de allocator de collectie meer ruimte kan geven dan hij vraagt.
    /// Daarom kan er niet op worden vertrouwd dat de capaciteit precies minimaal is.
    /// Geef de voorkeur aan [`reserve`] als future-inserties worden verwacht.
    ///
    /// # Panics
    ///
    /// Panics als de nieuwe capaciteit overloopt `usize`.
    ///
    /// # Examples
    ///
    /// Basisgebruik:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.reserve_exact(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    ///
    /// [`reserve`]: BinaryHeap::reserve
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.data.reserve_exact(additional);
    }

    /// Reserveert capaciteit voor minstens `additional` meer elementen die in de `BinaryHeap` moeten worden ingevoegd.
    /// De collectie kan meer ruimte reserveren om frequente herverdelingen te voorkomen.
    ///
    /// # Panics
    ///
    /// Panics als de nieuwe capaciteit overloopt `usize`.
    ///
    /// # Examples
    ///
    /// Basisgebruik:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.reserve(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.data.reserve(additional);
    }

    /// Gooit zoveel mogelijk extra capaciteit weg.
    ///
    /// # Examples
    ///
    /// Basisgebruik:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap: BinaryHeap<i32> = BinaryHeap::with_capacity(100);
    ///
    /// assert!(heap.capacity() >= 100);
    /// heap.shrink_to_fit();
    /// assert!(heap.capacity() == 0);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        self.data.shrink_to_fit();
    }

    /// Gooit capaciteit met een ondergrens terug.
    ///
    /// De capaciteit blijft minimaal zo groot als zowel de lengte als de geleverde waarde.
    ///
    ///
    /// Als de huidige capaciteit lager is dan de ondergrens, is dit een no-op.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// use std::collections::BinaryHeap;
    /// let mut heap: BinaryHeap<i32> = BinaryHeap::with_capacity(100);
    ///
    /// assert!(heap.capacity() >= 100);
    /// heap.shrink_to(10);
    /// assert!(heap.capacity() >= 10);
    /// ```
    #[inline]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        self.data.shrink_to(min_capacity)
    }

    /// Gebruikt de `BinaryHeap` en retourneert de onderliggende vector in willekeurige volgorde.
    ///
    ///
    /// # Examples
    ///
    /// Basisgebruik:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4, 5, 6, 7]);
    /// let vec = heap.into_vec();
    ///
    /// // Zal in een bepaalde volgorde afdrukken
    /// for x in vec {
    ///     println!("{}", x);
    /// }
    /// ```
    #[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
    pub fn into_vec(self) -> Vec<T> {
        self.into()
    }

    /// Retourneert de lengte van de binaire heap.
    ///
    /// # Examples
    ///
    /// Basisgebruik:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert_eq!(heap.len(), 2);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.data.len()
    }

    /// Controleert of de binaire heap leeg is.
    ///
    /// # Examples
    ///
    /// Basisgebruik:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    ///
    /// assert!(heap.is_empty());
    ///
    /// heap.push(3);
    /// heap.push(5);
    /// heap.push(1);
    ///
    /// assert!(!heap.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Wist de binaire heap en retourneert een iterator over de verwijderde elementen.
    ///
    /// De elementen worden in willekeurige volgorde verwijderd.
    ///
    /// # Examples
    ///
    /// Basisgebruik:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert!(!heap.is_empty());
    ///
    /// for x in heap.drain() {
    ///     println!("{}", x);
    /// }
    ///
    /// assert!(heap.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain(&mut self) -> Drain<'_, T> {
        Drain { iter: self.data.drain(..) }
    }

    /// Verwijdert alle items uit de binaire heap.
    ///
    /// # Examples
    ///
    /// Basisgebruik:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert!(!heap.is_empty());
    ///
    /// heap.clear();
    ///
    /// assert!(heap.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.drain();
    }
}

/// Hole vertegenwoordigt een hole in een slice, dwz een index zonder geldige waarde (omdat deze is verplaatst of gedupliceerd).
///
/// In drop herstelt `Hole` de slice door de hole-positie te vullen met de waarde die oorspronkelijk was verwijderd.
///
struct Hole<'a, T: 'a> {
    data: &'a mut [T],
    elt: ManuallyDrop<T>,
    pos: usize,
}

impl<'a, T> Hole<'a, T> {
    /// Maak een nieuwe `Hole` aan bij index `pos`.
    ///
    /// Onveilig omdat pos zich binnen het gegevenssegment moet bevinden.
    #[inline]
    unsafe fn new(data: &'a mut [T], pos: usize) -> Self {
        debug_assert!(pos < data.len());
        // VEILIG: pos moet in de plak zitten
        let elt = unsafe { ptr::read(data.get_unchecked(pos)) };
        Hole { data, elt: ManuallyDrop::new(elt), pos }
    }

    #[inline]
    fn pos(&self) -> usize {
        self.pos
    }

    /// Retourneert een verwijzing naar het verwijderde element.
    #[inline]
    fn element(&self) -> &T {
        &self.elt
    }

    /// Retourneert een verwijzing naar het element op `index`.
    ///
    /// Onveilig omdat index binnen het gegevenssegment moet zijn en niet gelijk aan pos.
    #[inline]
    unsafe fn get(&self, index: usize) -> &T {
        debug_assert!(index != self.pos);
        debug_assert!(index < self.data.len());
        unsafe { self.data.get_unchecked(index) }
    }

    /// Verplaats de hole naar een nieuwe locatie
    ///
    /// Onveilig omdat index binnen het gegevenssegment moet zijn en niet gelijk aan pos.
    #[inline]
    unsafe fn move_to(&mut self, index: usize) {
        debug_assert!(index != self.pos);
        debug_assert!(index < self.data.len());
        unsafe {
            let ptr = self.data.as_mut_ptr();
            let index_ptr: *const _ = ptr.add(index);
            let hole_ptr = ptr.add(self.pos);
            ptr::copy_nonoverlapping(index_ptr, hole_ptr, 1);
        }
        self.pos = index;
    }
}

impl<T> Drop for Hole<'_, T> {
    #[inline]
    fn drop(&mut self) {
        // vul het gat opnieuw
        unsafe {
            let pos = self.pos;
            ptr::copy_nonoverlapping(&*self.elt, self.data.get_unchecked_mut(pos), 1);
        }
    }
}

/// Een iterator over de elementen van een `BinaryHeap`.
///
/// Deze `struct` is gemaakt door [`BinaryHeap::iter()`].
/// Zie de documentatie voor meer.
///
/// [`iter`]: BinaryHeap::iter
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Iter<'a, T: 'a> {
    iter: slice::Iter<'a, T>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for Iter<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Iter").field(&self.iter.as_slice()).finish()
    }
}

// FIXME(#26925) Verwijderen ten gunste van `#[derive(Clone)]`
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Clone for Iter<'_, T> {
    fn clone(&self) -> Self {
        Iter { iter: self.iter.clone() }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for Iter<'a, T> {
    type Item = &'a T;

    #[inline]
    fn next(&mut self) -> Option<&'a T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }

    #[inline]
    fn last(self) -> Option<&'a T> {
        self.iter.last()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for Iter<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a T> {
        self.iter.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for Iter<'_, T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Iter<'_, T> {}

/// Een iterator die de elementen van een `BinaryHeap` bezit.
///
/// Deze `struct` is gemaakt door [`BinaryHeap::into_iter()`] (geleverd door de `IntoIterator` trait).
/// Zie de documentatie voor meer.
///
/// [`into_iter`]: BinaryHeap::into_iter
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Clone)]
pub struct IntoIter<T> {
    iter: vec::IntoIter<T>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for IntoIter<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("IntoIter").field(&self.iter.as_slice()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Iterator for IntoIter<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> DoubleEndedIterator for IntoIter<T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.iter.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for IntoIter<T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for IntoIter<T> {}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<T> SourceIter for IntoIter<T> {
    type Source = IntoIter<T>;

    #[inline]
    unsafe fn as_inner(&mut self) -> &mut Self::Source {
        self
    }
}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<I> InPlaceIterable for IntoIter<I> {}

impl<I> AsIntoIter for IntoIter<I> {
    type Item = I;

    fn as_into_iter(&mut self) -> &mut vec::IntoIter<Self::Item> {
        &mut self.iter
    }
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
#[derive(Clone, Debug)]
pub struct IntoIterSorted<T> {
    inner: BinaryHeap<T>,
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> Iterator for IntoIterSorted<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.inner.pop()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let exact = self.inner.len();
        (exact, Some(exact))
    }
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> ExactSizeIterator for IntoIterSorted<T> {}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> FusedIterator for IntoIterSorted<T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T: Ord> TrustedLen for IntoIterSorted<T> {}

/// Een uitputtende iterator over de elementen van een `BinaryHeap`.
///
/// Deze `struct` is gemaakt door [`BinaryHeap::drain()`].
/// Zie de documentatie voor meer.
///
/// [`drain`]: BinaryHeap::drain
#[stable(feature = "drain", since = "1.6.0")]
#[derive(Debug)]
pub struct Drain<'a, T: 'a> {
    iter: vec::Drain<'a, T>,
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> Iterator for Drain<'_, T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> DoubleEndedIterator for Drain<'_, T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.iter.next_back()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> ExactSizeIterator for Drain<'_, T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Drain<'_, T> {}

/// Een uitputtende iterator over de elementen van een `BinaryHeap`.
///
/// Deze `struct` is gemaakt door [`BinaryHeap::drain_sorted()`].
/// Zie de documentatie voor meer.
///
/// [`drain_sorted`]: BinaryHeap::drain_sorted
#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
#[derive(Debug)]
pub struct DrainSorted<'a, T: Ord> {
    inner: &'a mut BinaryHeap<T>,
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<'a, T: Ord> Drop for DrainSorted<'a, T> {
    /// Verwijdert heap-elementen in heap-volgorde.
    fn drop(&mut self) {
        struct DropGuard<'r, 'a, T: Ord>(&'r mut DrainSorted<'a, T>);

        impl<'r, 'a, T: Ord> Drop for DropGuard<'r, 'a, T> {
            fn drop(&mut self) {
                while self.0.inner.pop().is_some() {}
            }
        }

        while let Some(item) = self.inner.pop() {
            let guard = DropGuard(self);
            drop(item);
            mem::forget(guard);
        }
    }
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> Iterator for DrainSorted<'_, T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.inner.pop()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let exact = self.inner.len();
        (exact, Some(exact))
    }
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> ExactSizeIterator for DrainSorted<'_, T> {}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> FusedIterator for DrainSorted<'_, T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T: Ord> TrustedLen for DrainSorted<'_, T> {}

#[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
impl<T: Ord> From<Vec<T>> for BinaryHeap<T> {
    /// Verandert een `Vec<T>` in een `BinaryHeap<T>`.
    ///
    /// Deze conversie gebeurt ter plaatse en heeft *O*(*n*) tijdcomplexiteit.
    fn from(vec: Vec<T>) -> BinaryHeap<T> {
        let mut heap = BinaryHeap { data: vec };
        heap.rebuild();
        heap
    }
}

#[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
impl<T> From<BinaryHeap<T>> for Vec<T> {
    /// Verandert een `BinaryHeap<T>` in een `Vec<T>`.
    ///
    /// Deze conversie vereist geen gegevensverplaatsing of toewijzing en heeft een constante tijdcomplexiteit.
    ///
    fn from(heap: BinaryHeap<T>) -> Vec<T> {
        heap.data
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> FromIterator<T> for BinaryHeap<T> {
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> BinaryHeap<T> {
        BinaryHeap::from(iter.into_iter().collect::<Vec<_>>())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> IntoIterator for BinaryHeap<T> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// Creëert een veeleisende iterator, dat wil zeggen een iterator die elke waarde in willekeurige volgorde uit de binaire heap verplaatst.
    /// De binaire heap kan niet worden gebruikt nadat deze is aangeroepen.
    ///
    /// # Examples
    ///
    /// Basisgebruik:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4]);
    ///
    /// // Druk 1, 2, 3, 4 in willekeurige volgorde af
    /// for x in heap.into_iter() {
    ///     // x heeft type i32, niet &i32
    ///     println!("{}", x);
    /// }
    /// ```
    ///
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { iter: self.data.into_iter() }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a BinaryHeap<T> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Extend<T> for BinaryHeap<T> {
    #[inline]
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        <Self as SpecExtend<I>>::spec_extend(self, iter);
    }

    #[inline]
    fn extend_one(&mut self, item: T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

impl<T: Ord, I: IntoIterator<Item = T>> SpecExtend<I> for BinaryHeap<T> {
    default fn spec_extend(&mut self, iter: I) {
        self.extend_desugared(iter.into_iter());
    }
}

impl<T: Ord> SpecExtend<BinaryHeap<T>> for BinaryHeap<T> {
    fn spec_extend(&mut self, ref mut other: BinaryHeap<T>) {
        self.append(other);
    }
}

impl<T: Ord> BinaryHeap<T> {
    fn extend_desugared<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        let iterator = iter.into_iter();
        let (lower, _) = iterator.size_hint();

        self.reserve(lower);

        iterator.for_each(move |elem| self.push(elem));
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: 'a + Ord + Copy> Extend<&'a T> for BinaryHeap<T> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &item: &'a T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}