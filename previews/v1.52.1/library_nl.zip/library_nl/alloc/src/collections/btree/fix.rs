use super::map::MIN_LEN;
use super::node::{marker, ForceResult::*, Handle, LeftOrRight::*, NodeRef, Root};

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Slaat een mogelijk ondervol knooppunt in door te fuseren met of te stelen van een broer of zus.
    /// Als dit lukt maar ten koste gaat van het verkleinen van het bovenliggende knooppunt, wordt dat gekrompen bovenliggende knooppunt geretourneerd.
    /// Geeft een `Err` terug als het knooppunt een lege root is.
    ///
    fn fix_node_through_parent(
        self,
    ) -> Result<Option<NodeRef<marker::Mut<'a>, K, V, marker::Internal>>, Self> {
        let len = self.len();
        if len >= MIN_LEN {
            Ok(None)
        } else {
            match self.choose_parent_kv() {
                Ok(Left(mut left_parent_kv)) => {
                    if left_parent_kv.can_merge() {
                        let parent = left_parent_kv.merge_tracking_parent();
                        Ok(Some(parent))
                    } else {
                        left_parent_kv.bulk_steal_left(MIN_LEN - len);
                        Ok(None)
                    }
                }
                Ok(Right(mut right_parent_kv)) => {
                    if right_parent_kv.can_merge() {
                        let parent = right_parent_kv.merge_tracking_parent();
                        Ok(Some(parent))
                    } else {
                        right_parent_kv.bulk_steal_right(MIN_LEN - len);
                        Ok(None)
                    }
                }
                Err(root) => {
                    if len > 0 {
                        Ok(None)
                    } else {
                        Err(root)
                    }
                }
            }
        }
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Slaat een mogelijk underfull-knooppunt op, en als dat ervoor zorgt dat het bovenliggende knooppunt krimpt, slaat het de bovenliggende knoop recursief op.
    /// Geeft `true` terug als het de boom heeft gerepareerd, `false` als het niet kon omdat het hoofdknooppunt leeg raakte.
    ///
    /// Deze methode verwacht niet dat voorouders al underfull zijn bij binnenkomst en panics als het een lege voorouder tegenkomt.
    ///
    ///
    ///
    pub fn fix_node_and_affected_ancestors(mut self) -> bool {
        loop {
            match self.fix_node_through_parent() {
                Ok(Some(parent)) => self = parent.forget_type(),
                Ok(None) => return true,
                Err(_) => return false,
            }
        }
    }
}

impl<K, V> Root<K, V> {
    /// Verwijdert lege niveaus aan de bovenkant, maar houdt een leeg blad als de hele boom leeg is.
    pub fn fix_top(&mut self) {
        while self.height() > 0 && self.len() == 0 {
            self.pop_internal_level();
        }
    }

    /// Slaat eventuele underfull-knooppunten op of voegt ze samen aan de rechterrand van de boom.
    /// De andere knooppunten, die niet de root of de meest rechtse edge zijn, moeten al minstens MIN_LEN-elementen hebben.
    ///
    pub fn fix_right_border(&mut self) {
        self.fix_top();
        if self.len() > 0 {
            self.borrow_mut().last_kv().fix_right_border_of_right_edge();
            self.fix_top();
        }
    }

    /// De symmetrische kloon van `fix_right_border`.
    pub fn fix_left_border(&mut self) {
        self.fix_top();
        if self.len() > 0 {
            self.borrow_mut().first_kv().fix_left_border_of_left_edge();
            self.fix_top();
        }
    }

    /// Sla eventuele underfull-knooppunten op aan de rechterrand van de boom.
    /// De andere knooppunten, die niet de root of de meest rechtse edge zijn, moeten voorbereid zijn om maximaal MIN_LEN-elementen te laten stelen.
    ///
    pub fn fix_right_border_of_plentiful(&mut self) {
        let mut cur_node = self.borrow_mut();
        while let Internal(internal) = cur_node.force() {
            // Controleer of het meest rechtse kind onvoldoende is.
            let mut last_kv = internal.last_kv().consider_for_balancing();
            debug_assert!(last_kv.left_child_len() >= MIN_LEN * 2);
            let right_child_len = last_kv.right_child_len();
            if right_child_len < MIN_LEN {
                // We moeten stelen.
                last_kv.bulk_steal_left(MIN_LEN - right_child_len);
            }

            // Ga verder naar beneden.
            cur_node = last_kv.into_right_child();
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::KV> {
    fn fix_left_border_of_left_edge(mut self) {
        while let Internal(internal_kv) = self.force() {
            self = internal_kv.fix_left_child().first_kv();
            debug_assert!(self.reborrow().into_node().len() > MIN_LEN);
        }
    }

    fn fix_right_border_of_right_edge(mut self) {
        while let Internal(internal_kv) = self.force() {
            self = internal_kv.fix_right_child().last_kv();
            debug_assert!(self.reborrow().into_node().len() > MIN_LEN);
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    /// Slaat het linkerkind op, ervan uitgaande dat het rechterkind niet underfull is, en voorziet in een extra element om de kinderen beurtelings te laten fuseren zonder underfull te worden.
    ///
    /// Geeft het linkerkind terug.
    ///
    fn fix_left_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        let mut internal_kv = self.consider_for_balancing();
        let left_len = internal_kv.left_child_len();
        debug_assert!(internal_kv.right_child_len() >= MIN_LEN);
        if internal_kv.can_merge() {
            internal_kv.merge_tracking_child()
        } else {
            // `MIN_LEN + 1` om opnieuw aanpassen te voorkomen als het samenvoegen op het volgende niveau plaatsvindt.
            let count = (MIN_LEN + 1).saturating_sub(left_len);
            if count > 0 {
                internal_kv.bulk_steal_right(count);
            }
            internal_kv.into_left_child()
        }
    }

    /// Slaat het rechterkind op, ervan uitgaande dat het linkerkind niet underfull is, en voorziet in een extra element om de kinderen beurtelings te laten fuseren zonder underfull te worden.
    ///
    /// Keert terug waar het juiste kind terecht is gekomen.
    ///
    fn fix_right_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        let mut internal_kv = self.consider_for_balancing();
        let right_len = internal_kv.right_child_len();
        debug_assert!(internal_kv.left_child_len() >= MIN_LEN);
        if internal_kv.can_merge() {
            internal_kv.merge_tracking_child()
        } else {
            // `MIN_LEN + 1` om opnieuw aanpassen te voorkomen als het samenvoegen op het volgende niveau plaatsvindt.
            let count = (MIN_LEN + 1).saturating_sub(right_len);
            if count > 0 {
                internal_kv.bulk_steal_left(count);
            }
            internal_kv.into_right_child()
        }
    }
}