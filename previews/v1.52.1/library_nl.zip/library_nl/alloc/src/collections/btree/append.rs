use super::merge_iter::MergeIterInner;
use super::node::{self, Root};
use core::iter::FusedIterator;

impl<K, V> Root<K, V> {
    /// Voegt alle sleutel/waarde-paren toe vanuit de vereniging van twee oplopende iteratoren, waarbij een `length`-variabele gaandeweg wordt verhoogd.Dit laatste maakt het gemakkelijker voor de beller om een lek te voorkomen wanneer een drop-handler in paniek raakt.
    ///
    /// Als beide iteratoren dezelfde sleutel produceren, verwijdert deze methode het paar van de linker iterator en voegt het paar van de rechter iterator toe.
    ///
    /// Als je wilt dat de boom in een strikt oplopende volgorde eindigt, zoals bij een `BTreeMap`, moeten beide iteratoren de sleutels in strikt oplopende volgorde produceren, elk groter dan alle sleutels in de boom, inclusief alle sleutels die bij het invoeren al in de boom staan.
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn append_from_sorted_iters<I>(&mut self, left: I, right: I, length: &mut usize)
    where
        K: Ord,
        I: Iterator<Item = (K, V)> + FusedIterator,
    {
        // We bereiden ons voor om `left` en `right` samen te voegen tot een gesorteerde reeks in lineaire tijd.
        let iter = MergeIter(MergeIterInner::new(left, right));

        // Ondertussen bouwen we een boom uit de gesorteerde reeks in lineaire tijd.
        self.bulk_push(iter, length)
    }

    /// Duwt alle sleutel/waarde-paren naar het einde van de boomstructuur, waarbij een `length`-variabele gaandeweg wordt verhoogd.
    /// Dit laatste maakt het gemakkelijker voor de beller om een lek te voorkomen wanneer de iterator in paniek raakt.
    ///
    pub fn bulk_push<I>(&mut self, iter: I, length: &mut usize)
    where
        I: Iterator<Item = (K, V)>,
    {
        let mut cur_node = self.borrow_mut().last_leaf_edge().into_node();
        // Herhaal alle sleutel/waarde-paren en duw ze in knooppunten op het juiste niveau.
        for (key, value) in iter {
            // Probeer het sleutel/waarde-paar naar het huidige leaf-knooppunt te pushen.
            if cur_node.len() < node::CAPACITY {
                cur_node.push(key, value);
            } else {
                // Geen ruimte meer, ga omhoog en duw daar.
                let mut open_node;
                let mut test_node = cur_node.forget_type();
                loop {
                    match test_node.ascend() {
                        Ok(parent) => {
                            let parent = parent.into_node();
                            if parent.len() < node::CAPACITY {
                                // Vond een knoop met ruimte over, druk hier.
                                open_node = parent;
                                break;
                            } else {
                                // Ga weer naar boven.
                                test_node = parent.forget_type();
                            }
                        }
                        Err(_) => {
                            // We staan bovenaan, maken een nieuw rootknooppunt en pushen daar.
                            open_node = self.push_internal_level();
                            break;
                        }
                    }
                }

                // Druk op sleutel/waarde-paar en nieuwe rechter substructuur.
                let tree_height = open_node.height() - 1;
                let mut right_tree = Root::new();
                for _ in 0..tree_height {
                    right_tree.push_internal_level();
                }
                open_node.push(key, value, right_tree);

                // Ga weer naar het meest rechtse blad.
                cur_node = open_node.forget_type().last_leaf_edge().into_node();
            }

            // Verhoog de lengte bij elke iteratie om ervoor te zorgen dat de kaart de toegevoegde elementen laat vallen, zelfs als de iterator in paniek raakt.
            //
            *length += 1;
        }
        self.fix_right_border_of_plentiful();
    }
}

// Een iterator voor het samenvoegen van twee gesorteerde reeksen tot één
struct MergeIter<K, V, I: Iterator<Item = (K, V)>>(MergeIterInner<I>);

impl<K: Ord, V, I> Iterator for MergeIter<K, V, I>
where
    I: Iterator<Item = (K, V)> + FusedIterator,
{
    type Item = (K, V);

    /// Als twee sleutels gelijk zijn, wordt het sleutel/waarde-paar geretourneerd vanuit de juiste bron.
    fn next(&mut self) -> Option<(K, V)> {
        let (a_next, b_next) = self.0.nexts(|a: &(K, V), b: &(K, V)| K::cmp(&a.0, &b.0));
        b_next.or(a_next)
    }
}