use core::borrow::Borrow;
use core::ops::RangeBounds;
use core::ptr;

use super::node::{marker, ForceResult::*, Handle, NodeRef};

pub struct LeafRange<BorrowType, K, V> {
    pub front: Option<Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>>,
    pub back: Option<Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>>,
}

impl<BorrowType, K, V> LeafRange<BorrowType, K, V> {
    pub fn none() -> Self {
        LeafRange { front: None, back: None }
    }

    pub fn is_empty(&self) -> bool {
        self.front == self.back
    }

    /// Verwijdert tijdelijk een ander, onveranderlijk equivalent van dezelfde reeks.
    pub fn reborrow(&self) -> LeafRange<marker::Immut<'_>, K, V> {
        LeafRange {
            front: self.front.as_ref().map(|f| f.reborrow()),
            back: self.back.as_ref().map(|b| b.reborrow()),
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Vindt de verschillende bladranden die een bepaald bereik in een boom afbakenen.
    /// Retourneert een paar verschillende handvatten in dezelfde boom of een paar lege opties.
    ///
    /// # Safety
    ///
    /// Tenzij `BorrowType` `Immut` is, mag u de dubbele handvatten niet gebruiken om dezelfde KV twee keer te bezoeken.
    unsafe fn find_leaf_edges_spanning_range<Q: ?Sized, R>(
        self,
        range: R,
    ) -> LeafRange<BorrowType, K, V>
    where
        Q: Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        match self.search_tree_for_bifurcation(&range) {
            Err(_) => LeafRange::none(),
            Ok((
                node,
                lower_edge_idx,
                upper_edge_idx,
                mut lower_child_bound,
                mut upper_child_bound,
            )) => {
                let mut lower_edge = unsafe { Handle::new_edge(ptr::read(&node), lower_edge_idx) };
                let mut upper_edge = unsafe { Handle::new_edge(node, upper_edge_idx) };
                loop {
                    match (lower_edge.force(), upper_edge.force()) {
                        (Leaf(f), Leaf(b)) => return LeafRange { front: Some(f), back: Some(b) },
                        (Internal(f), Internal(b)) => {
                            (lower_edge, lower_child_bound) =
                                f.descend().find_lower_bound_edge(lower_child_bound);
                            (upper_edge, upper_child_bound) =
                                b.descend().find_upper_bound_edge(upper_child_bound);
                        }
                        _ => unreachable!("BTreeMap has different depths"),
                    }
                }
            }
        }
    }
}

/// Gelijk aan `(root1.first_leaf_edge(), root2.last_leaf_edge())` maar efficiënter.
fn full_range<BorrowType: marker::BorrowType, K, V>(
    root1: NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    root2: NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
) -> LeafRange<BorrowType, K, V> {
    let mut min_node = root1;
    let mut max_node = root2;
    loop {
        let front = min_node.first_edge();
        let back = max_node.last_edge();
        match (front.force(), back.force()) {
            (Leaf(f), Leaf(b)) => {
                return LeafRange { front: Some(f), back: Some(b) };
            }
            (Internal(min_int), Internal(max_int)) => {
                min_node = min_int.descend();
                max_node = max_int.descend();
            }
            _ => unreachable!("BTreeMap has different depths"),
        };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Immut<'a>, K, V, marker::LeafOrInternal> {
    /// Vindt het paar bladranden dat een bepaald bereik in een boom begrenst.
    ///
    /// Het resultaat is alleen zinvol als de boom is geordend op sleutel, zoals de boom in een `BTreeMap` is.
    ///
    pub fn range_search<Q, R>(self, range: R) -> LeafRange<marker::Immut<'a>, K, V>
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        // VEILIGHEID: ons type lening is onveranderlijk.
        unsafe { self.find_leaf_edges_spanning_range(range) }
    }

    /// Vindt het paar bladranden die een hele boom afbakenen.
    pub fn full_range(self) -> LeafRange<marker::Immut<'a>, K, V> {
        full_range(self, self)
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::ValMut<'a>, K, V, marker::LeafOrInternal> {
    /// Splitst een unieke referentie in een paar bladranden die een bepaald bereik afbakenen.
    /// Het resultaat zijn niet-unieke referenties die (some)-mutatie mogelijk maken, die zorgvuldig moet worden gebruikt.
    ///
    /// Het resultaat is alleen zinvol als de boom is geordend op sleutel, zoals de boom in een `BTreeMap` is.
    ///
    ///
    /// # Safety
    /// Gebruik de dubbele handvatten niet om dezelfde KV twee keer te bezoeken.
    ///
    pub fn range_search<Q, R>(self, range: R) -> LeafRange<marker::ValMut<'a>, K, V>
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        unsafe { self.find_leaf_edges_spanning_range(range) }
    }

    /// Splitst een unieke referentie in een paar bladranden die het volledige bereik van de boom afbakenen.
    /// De resultaten zijn niet-unieke referenties die mutatie mogelijk maken (alleen van waarden), dus moeten voorzichtig worden gebruikt.
    ///
    pub fn full_range(self) -> LeafRange<marker::ValMut<'a>, K, V> {
        // We dupliceren de root NodeRef hier-we zullen nooit dezelfde KV twee keer bezoeken en nooit eindigen met overlappende waarde-verwijzingen.
        //
        let self2 = unsafe { ptr::read(&self) };
        full_range(self, self2)
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// Splitst een unieke referentie in een paar bladranden die het volledige bereik van de boom afbakenen.
    /// De resultaten zijn niet-unieke referenties die een enorm destructieve mutatie mogelijk maken, dus moeten met de grootste zorg worden gebruikt.
    ///
    pub fn full_range(self) -> LeafRange<marker::Dying, K, V> {
        // We dupliceren de root NodeRef hier-we zullen er nooit toegang toe krijgen op een manier die de referenties die zijn verkregen van de root overlapt.
        //
        let self2 = unsafe { ptr::read(&self) };
        full_range(self, self2)
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>
{
    /// Gegeven een leaf edge-handle, retourneert [`Result::Ok`] met een handle naar de naburige KV aan de rechterkant, die zich ofwel in hetzelfde leaf-knooppunt of in een voorouderknooppunt bevindt.
    ///
    /// Als het blad edge de laatste in de boom is, retourneert [`Result::Err`] met het hoofdknooppunt.
    pub fn next_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    > {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.right_kv() {
                Ok(kv) => return Ok(kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge.forget_node_type(),
                    Err(root) => return Err(root),
                },
            }
        }
    }

    /// Gegeven een leaf edge-handle, retourneert [`Result::Ok`] met een handle naar de aangrenzende KV aan de linkerkant, die zich ofwel in hetzelfde leaf-knooppunt of in een voorouderknooppunt bevindt.
    ///
    /// Als het blad edge de eerste in de boom is, retourneert [`Result::Err`] met het hoofdknooppunt.
    pub fn next_back_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    > {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.left_kv() {
                Ok(kv) => return Ok(kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge.forget_node_type(),
                    Err(root) => return Err(root),
                },
            }
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// Gegeven een interne edge-handle, retourneert [`Result::Ok`] met een handle naar de aangrenzende KV aan de rechterkant, die zich ofwel in hetzelfde interne knooppunt of in een bovenliggend knooppunt bevindt.
    ///
    /// Als de interne edge de laatste in de boom is, retourneert [`Result::Err`] met het hoofdknooppunt.
    pub fn next_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        let mut edge = self;
        loop {
            edge = match edge.right_kv() {
                Ok(internal_kv) => return Ok(internal_kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge,
                    Err(root) => return Err(root),
                },
            }
        }
    }
}

impl<K, V> Handle<NodeRef<marker::Dying, K, V, marker::Leaf>, marker::Edge> {
    /// Gegeven een handle edge in een stervende boom, retourneert het volgende blad edge aan de rechterkant, en het sleutel-waardepaar daartussenin, dat zich ofwel in hetzelfde bladknooppunt, in een voorouderknooppunt bevindt, of niet bestaat.
    ///
    ///
    /// Met deze methode wordt ook de toewijzing ongedaan gemaakt van elke node(s) die het einde bereikt.
    /// Dit houdt in dat als er geen sleutel-waardepaar meer bestaat, de volledige rest van de boom is opgeheven en er niets meer is om terug te keren.
    ///
    /// # Safety
    /// De opgegeven edge mag niet eerder zijn geretourneerd door tegenhanger `deallocating_next_back`.
    ///
    ///
    ///
    unsafe fn deallocating_next(self) -> Option<(Self, (K, V))> {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.right_kv() {
                Ok(kv) => {
                    let k = unsafe { ptr::read(kv.reborrow().into_kv().0) };
                    let v = unsafe { ptr::read(kv.reborrow().into_kv().1) };
                    return Some((kv.next_leaf_edge(), (k, v)));
                }
                Err(last_edge) => match unsafe { last_edge.into_node().deallocate_and_ascend() } {
                    Some(parent_edge) => parent_edge.forget_node_type(),
                    None => return None,
                },
            }
        }
    }

    /// Gegeven een handle edge in een stervende boom, retourneert het volgende blad edge aan de linkerkant en het sleutel/waardepaar daartussenin, dat zich ofwel in hetzelfde bladknooppunt, in een voorouderknooppunt bevindt, of niet bestaat.
    ///
    ///
    /// Met deze methode wordt ook de toewijzing ongedaan gemaakt van elke node(s) die het einde bereikt.
    /// Dit houdt in dat als er geen sleutel-waardepaar meer bestaat, de volledige rest van de boom is opgeheven en er niets meer is om terug te keren.
    ///
    /// # Safety
    /// De opgegeven edge mag niet eerder zijn geretourneerd door tegenhanger `deallocating_next`.
    ///
    ///
    ///
    unsafe fn deallocating_next_back(self) -> Option<(Self, (K, V))> {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.left_kv() {
                Ok(kv) => {
                    let k = unsafe { ptr::read(kv.reborrow().into_kv().0) };
                    let v = unsafe { ptr::read(kv.reborrow().into_kv().1) };
                    return Some((kv.next_back_leaf_edge(), (k, v)));
                }
                Err(last_edge) => match unsafe { last_edge.into_node().deallocate_and_ascend() } {
                    Some(parent_edge) => parent_edge.forget_node_type(),
                    None => return None,
                },
            }
        }
    }

    /// Wijst een stapel knooppunten uit van het blad tot aan de wortel.
    /// Dit is de enige manier om de rest van een boom ongedaan te maken nadat `deallocating_next` en `deallocating_next_back` aan beide kanten van de boom hebben geknabbeld en dezelfde edge hebben geraakt.
    /// Omdat het alleen bedoeld is om te worden aangeroepen wanneer alle sleutels en waarden zijn geretourneerd, wordt er geen opschoning uitgevoerd op een van de sleutels of waarden.
    ///
    ///
    ///
    pub fn deallocating_end(self) {
        let mut edge = self.forget_node_type();
        while let Some(parent_edge) = unsafe { edge.into_node().deallocate_and_ascend() } {
            edge = parent_edge.forget_node_type();
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Immut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Verplaatst de handle edge naar het volgende blad edge en retourneert verwijzingen naar de sleutel en de waarde ertussen.
    ///
    ///
    /// # Safety
    /// Er moet nog een KV zijn in de afgelegde richting.
    pub unsafe fn next_unchecked(&mut self) -> (&'a K, &'a V) {
        super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (kv.next_leaf_edge(), kv.into_kv())
        })
    }

    /// Verplaatst de handle edge naar de vorige leaf edge en retourneert verwijzingen naar de sleutel en de waarde ertussen.
    ///
    ///
    /// # Safety
    /// Er moet nog een KV zijn in de afgelegde richting.
    pub unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a V) {
        super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_back_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (kv.next_back_leaf_edge(), kv.into_kv())
        })
    }
}

impl<'a, K, V> Handle<NodeRef<marker::ValMut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Verplaatst de handle edge naar het volgende blad edge en retourneert verwijzingen naar de sleutel en de waarde ertussen.
    ///
    ///
    /// # Safety
    /// Er moet nog een KV zijn in de afgelegde richting.
    pub unsafe fn next_unchecked(&mut self) -> (&'a K, &'a mut V) {
        let kv = super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (unsafe { ptr::read(&kv) }.next_leaf_edge(), kv)
        });
        // Volgens benchmarks gaat dit als laatste sneller.
        kv.into_kv_valmut()
    }

    /// Verplaatst de leaf edge-handle naar het vorige leaf en retourneert verwijzingen naar de sleutel en de waarde ertussen.
    ///
    ///
    /// # Safety
    /// Er moet nog een KV zijn in de afgelegde richting.
    pub unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a mut V) {
        let kv = super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_back_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (unsafe { ptr::read(&kv) }.next_back_leaf_edge(), kv)
        });
        // Volgens benchmarks gaat dit als laatste sneller.
        kv.into_kv_valmut()
    }
}

impl<K, V> Handle<NodeRef<marker::Dying, K, V, marker::Leaf>, marker::Edge> {
    /// Verplaatst de leaf edge-handle naar het volgende leaf edge en retourneert de sleutel en waarde daartussen, waarbij elk achtergebleven knooppunt ongedaan wordt gemaakt terwijl de corresponderende edge in het bovenliggende knooppunt blijft hangen.
    ///
    /// # Safety
    /// - Er moet nog een KV zijn in de afgelegde richting.
    /// - Die KV was niet eerder teruggestuurd door tegenhanger `next_back_unchecked` op een kopie van de handvatten die werden gebruikt om de boom te doorkruisen.
    ///
    /// De enige veilige manier om verder te gaan met de bijgewerkte handle is door deze te vergelijken, te laten vallen, deze methode opnieuw aan te roepen onder voorbehoud van zijn veiligheidsvoorwaarden, of tegenhanger `next_back_unchecked` aan te roepen onder zijn veiligheidsvoorwaarden.
    ///
    ///
    ///
    ///
    ///
    pub unsafe fn deallocating_next_unchecked(&mut self) -> (K, V) {
        super::mem::replace(self, |leaf_edge| unsafe {
            leaf_edge.deallocating_next().unwrap_unchecked()
        })
    }

    /// Verplaatst de leaf edge-handle naar het vorige leaf edge en retourneert de sleutel en waarde daartussen, waarbij elk achtergebleven knooppunt ongedaan wordt gemaakt terwijl de corresponderende edge in het bovenliggende knooppunt blijft hangen.
    ///
    /// # Safety
    /// - Er moet nog een KV zijn in de afgelegde richting.
    /// - Dat blad edge werd niet eerder teruggestuurd door tegenhanger `next_unchecked` op een kopie van de handvatten die werden gebruikt om de boom te doorkruisen.
    ///
    /// De enige veilige manier om verder te gaan met de bijgewerkte handle is door deze te vergelijken, te laten vallen, deze methode opnieuw aan te roepen onder voorbehoud van zijn veiligheidsvoorwaarden, of tegenhanger `next_unchecked` aan te roepen onder voorbehoud van zijn veiligheidsvoorwaarden.
    ///
    ///
    ///
    ///
    ///
    pub unsafe fn deallocating_next_back_unchecked(&mut self) -> (K, V) {
        super::mem::replace(self, |leaf_edge| unsafe {
            leaf_edge.deallocating_next_back().unwrap_unchecked()
        })
    }
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Retourneert het meest linkse blad edge in of onder een knooppunt, met andere woorden, de edge die je als eerste nodig hebt bij het vooruit navigeren (of als laatste bij het achteruit navigeren).
    ///
    #[inline]
    pub fn first_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        let mut node = self;
        loop {
            match node.force() {
                Leaf(leaf) => return leaf.first_edge(),
                Internal(internal) => node = internal.first_edge().descend(),
            }
        }
    }

    /// Retourneert het meest rechtse blad edge in of onder een knooppunt, met andere woorden, de edge die je als laatste nodig hebt bij het vooruit navigeren (of als eerste bij achteruit navigeren).
    ///
    #[inline]
    pub fn last_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        let mut node = self;
        loop {
            match node.force() {
                Leaf(leaf) => return leaf.last_edge(),
                Internal(internal) => node = internal.last_edge().descend(),
            }
        }
    }
}

pub enum Position<BorrowType, K, V> {
    Leaf(NodeRef<BorrowType, K, V, marker::Leaf>),
    Internal(NodeRef<BorrowType, K, V, marker::Internal>),
    InternalKV(Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV>),
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Immut<'a>, K, V, marker::LeafOrInternal> {
    /// Bezoekt bladknooppunten en interne KV's in volgorde van oplopende sleutels, en bezoekt ook interne knooppunten als geheel in een diepte eerste volgorde, wat betekent dat interne knooppunten voorafgaan aan hun individuele KV's en hun onderliggende knooppunten.
    ///
    ///
    pub fn visit_nodes_in_order<F>(self, mut visit: F)
    where
        F: FnMut(Position<marker::Immut<'a>, K, V>),
    {
        match self.force() {
            Leaf(leaf) => visit(Position::Leaf(leaf)),
            Internal(internal) => {
                visit(Position::Internal(internal));
                let mut edge = internal.first_edge();
                loop {
                    edge = match edge.descend().force() {
                        Leaf(leaf) => {
                            visit(Position::Leaf(leaf));
                            match edge.next_kv() {
                                Ok(kv) => {
                                    visit(Position::InternalKV(kv));
                                    kv.right_edge()
                                }
                                Err(_) => return,
                            }
                        }
                        Internal(internal) => {
                            visit(Position::Internal(internal));
                            internal.first_edge()
                        }
                    }
                }
            }
        }
    }

    /// Berekent het aantal elementen in een (sub) boom.
    pub fn calc_length(self) -> usize {
        let mut result = 0;
        self.visit_nodes_in_order(|pos| match pos {
            Position::Leaf(node) => result += node.len(),
            Position::Internal(node) => result += node.len(),
            Position::InternalKV(_) => (),
        });
        result
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>
{
    /// Geeft het blad edge terug dat het dichtst bij een KV ligt voor voorwaartse navigatie.
    pub fn next_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        match self.force() {
            Leaf(leaf_kv) => leaf_kv.right_edge(),
            Internal(internal_kv) => {
                let next_internal_edge = internal_kv.right_edge();
                next_internal_edge.descend().first_leaf_edge()
            }
        }
    }

    /// Geeft het blad edge terug dat het dichtst bij een KV ligt voor achterwaartse navigatie.
    pub fn next_back_leaf_edge(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        match self.force() {
            Leaf(leaf_kv) => leaf_kv.left_edge(),
            Internal(internal_kv) => {
                let next_internal_edge = internal_kv.left_edge();
                next_internal_edge.descend().last_leaf_edge()
            }
        }
    }
}