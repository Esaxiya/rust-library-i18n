use core::marker::PhantomData;
use core::ptr::NonNull;

/// Modelleert een reborrow van een unieke referentie, als je weet dat de reborrow en al zijn nakomelingen (dwz alle verwijzingen en referenties die ervan zijn afgeleid) op een bepaald moment niet meer zullen worden gebruikt, waarna je de originele unieke referentie opnieuw wilt gebruiken .
///
///
/// De leningscontrole handelt dit stapelen van leningen meestal voor u af, maar sommige controlestromen die dit stapelen bewerkstelligen, zijn te ingewikkeld voor de compiler om te volgen.
/// Met een `DormantMutRef` kunt u zelf lenen controleren, terwijl u nog steeds de gestapelde aard ervan uitdrukt en de onbewerkte pointercode inkapselt die nodig is om dit te doen zonder ongedefinieerd gedrag.
///
///
///
///
///
pub struct DormantMutRef<'a, T> {
    ptr: NonNull<T>,
    _marker: PhantomData<&'a mut T>,
}

unsafe impl<'a, T> Sync for DormantMutRef<'a, T> where &'a mut T: Sync {}
unsafe impl<'a, T> Send for DormantMutRef<'a, T> where &'a mut T: Send {}

impl<'a, T> DormantMutRef<'a, T> {
    /// Leg een unieke lening vast en maak deze onmiddellijk opnieuw beschikbaar.
    /// Voor de compiler is de levensduur van de nieuwe referentie hetzelfde als de levensduur van de originele referentie, maar u promise om deze voor een kortere periode te gebruiken.
    ///
    pub fn new(t: &'a mut T) -> (&'a mut T, Self) {
        let ptr = NonNull::from(t);
        // VEILIGHEID: we houden de lening vast gedurende 'a via `_marker`, en we stellen bloot
        // alleen deze referentie, dus uniek.
        let new_ref = unsafe { &mut *ptr.as_ptr() };
        (new_ref, Self { ptr, _marker: PhantomData })
    }

    /// Keer terug naar de unieke lening die aanvankelijk werd vastgelegd.
    ///
    /// # Safety
    ///
    /// De reborrow moet zijn beëindigd, dwz de verwijzing die door `new` wordt geretourneerd en alle pointers en verwijzingen die ervan zijn afgeleid, mogen niet meer worden gebruikt.
    ///
    pub unsafe fn awaken(self) -> &'a mut T {
        // VEILIGHEID: onze eigen veiligheidsvoorwaarden impliceren dat deze referentie opnieuw uniek is.
        unsafe { &mut *self.ptr.as_ptr() }
    }
}

#[cfg(test)]
mod tests;