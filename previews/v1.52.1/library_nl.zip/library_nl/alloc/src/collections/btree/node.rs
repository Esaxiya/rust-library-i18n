// Dit is een poging tot implementatie volgens het ideaal
//
// ```
// struct BTreeMap<K, V> {
//     height: usize,
//     root: Option<Box<Node<K, V, height>>>
// }
//
// struct Node<K, V, height: usize> {
//     keys: [K; 2 * B - 1],
//     vals: [V; 2 * B - 1],
//     edges: [if height > 0 { Box<Node<K, V, height - 1>> } else { () }; 2 * B],
//     parent: Option<(NonNull<Node<K, V, height + 1>>, u16)>,
//     len: u16,
// }
// ```
//
// Omdat Rust eigenlijk geen afhankelijke typen en polymorfe recursie heeft, doen we het met veel onveiligheid.
//

// Een belangrijk doel van deze module is om complexiteit te vermijden door de boom te behandelen als een generieke (zij het vreemd gevormde) container en het vermijden van de meeste B-Tree-invarianten.
//
// Als zodanig maakt het deze module niet uit of de items gesorteerd zijn, welke knooppunten underfull kunnen zijn, of zelfs wat underfull betekent.We vertrouwen echter op enkele invarianten:
//
// - Bomen moeten uniform depth/height hebben.Dit betekent dat elk pad naar een blad vanaf een bepaald knooppunt exact dezelfde lengte heeft.
// - Een knooppunt met de lengte `n` heeft `n`-sleutels, `n`-waarden en `n + 1`-randen.
//   Dit houdt in dat zelfs een leeg knooppunt minstens één edge heeft.
//   Voor een bladknooppunt betekent "having an edge" alleen dat we een positie in het knooppunt kunnen identificeren, aangezien bladranden leeg zijn en geen gegevensweergave nodig hebben.
// In een intern knooppunt identificeert een edge zowel een positie als een pointer naar een kindknooppunt.
//
//
//

use core::marker::PhantomData;
use core::mem::{self, MaybeUninit};
use core::ptr::{self, NonNull};
use core::slice::SliceIndex;

use crate::alloc::{Allocator, Global, Layout};
use crate::boxed::Box;

const B: usize = 6;
pub const CAPACITY: usize = 2 * B - 1;
pub const MIN_LEN_AFTER_SPLIT: usize = B - 1;
const KV_IDX_CENTER: usize = B - 1;
const EDGE_IDX_LEFT_OF_CENTER: usize = B - 1;
const EDGE_IDX_RIGHT_OF_CENTER: usize = B;

/// De onderliggende weergave van bladknooppunten en een deel van de weergave van interne knooppunten.
struct LeafNode<K, V> {
    /// We willen covariant zijn in `K` en `V`.
    parent: Option<NonNull<InternalNode<K, V>>>,

    /// De index van dit knooppunt in de `edges`-array van het bovenliggende knooppunt.
    /// `*node.parent.edges[node.parent_idx]` zou hetzelfde moeten zijn als `node`.
    /// Dit wordt alleen gegarandeerd geïnitialiseerd als `parent` niet nul is.
    parent_idx: MaybeUninit<u16>,

    /// Het aantal sleutels en waarden dat dit knooppunt opslaat.
    len: u16,

    /// De arrays die de feitelijke gegevens van het knooppunt opslaan.
    /// Alleen de eerste `len`-elementen van elke array worden geïnitialiseerd en zijn geldig.
    keys: [MaybeUninit<K>; CAPACITY],
    vals: [MaybeUninit<V>; CAPACITY],
}

impl<K, V> LeafNode<K, V> {
    /// Initialiseert ter plaatse een nieuwe `LeafNode`.
    unsafe fn init(this: *mut Self) {
        // Als algemeen beleid laten we velden niet geïnitialiseerd als ze dat kunnen, omdat dit zowel iets sneller als gemakkelijker te volgen zou moeten zijn in Valgrind.
        //
        unsafe {
            // parent_idx, keys en vals zijn allemaal MaybeUninit
            ptr::addr_of_mut!((*this).parent).write(None);
            ptr::addr_of_mut!((*this).len).write(0);
        }
    }

    /// Creëert een nieuwe boxed `LeafNode`.
    fn new() -> Box<Self> {
        unsafe {
            let mut leaf = Box::new_uninit();
            LeafNode::init(leaf.as_mut_ptr());
            leaf.assume_init()
        }
    }
}

/// De onderliggende weergave van interne knooppunten.Net als bij `LeafNode`s, deze moeten worden verborgen achter`BoxedNode`s om te voorkomen dat niet-geïnitialiseerde sleutels en waarden worden verwijderd.
/// Elke pointer naar een `InternalNode` kan direct naar een pointer naar het onderliggende `LeafNode`-gedeelte van het knooppunt worden gestuurd, waardoor code generiek kan reageren op leaf-en interne knooppunten zonder zelfs maar te hoeven controleren naar welke van de twee een aanwijzer wijst.
///
/// Deze eigenschap wordt mogelijk gemaakt door het gebruik van `repr(C)`.
///
#[repr(C)]
// gdb_providers.py gebruikt deze typenaam voor introspectie.
struct InternalNode<K, V> {
    data: LeafNode<K, V>,

    /// De verwijzingen naar de kinderen van dit knooppunt.
    /// `len + 1` van deze worden als geïnitialiseerd en geldig beschouwd, behalve dat tegen het einde, terwijl de boom wordt vastgehouden door leentype `Dying`, sommige van deze aanwijzingen bungelen.
    ///
    edges: [MaybeUninit<BoxedNode<K, V>>; 2 * B],
}

impl<K, V> InternalNode<K, V> {
    /// Creëert een nieuwe boxed `InternalNode`.
    ///
    /// # Safety
    /// Een invariant van interne knooppunten is dat ze ten minste één geïnitialiseerde en geldige edge hebben.
    /// Deze functie stelt niet zo'n edge in.
    ///
    unsafe fn new() -> Box<Self> {
        unsafe {
            let mut node = Box::<Self>::new_uninit();
            // We hoeven alleen de gegevens te initialiseren;de randen zijn MisschienUninit.
            LeafNode::init(ptr::addr_of_mut!((*node.as_mut_ptr()).data));
            node.assume_init()
        }
    }
}

/// Een beheerde, niet-nulwijzer naar een knooppunt.Dit is ofwel een pointer in eigendom naar `LeafNode<K, V>` of een pointer in eigendom naar `InternalNode<K, V>`.
///
/// `BoxedNode` bevat echter geen informatie over welke van de twee typen knooppunten het werkelijk bevat, en, gedeeltelijk vanwege dit gebrek aan informatie, is het geen afzonderlijk type en heeft het geen destructor.
///
///
///
type BoxedNode<K, V> = NonNull<LeafNode<K, V>>;

/// Het hoofdknooppunt van een boom in eigendom.
///
/// Merk op dat dit geen destructor heeft en handmatig moet worden opgeruimd.
pub type Root<K, V> = NodeRef<marker::Owned, K, V, marker::LeafOrInternal>;

impl<K, V> Root<K, V> {
    /// Retourneert een nieuwe boom in eigendom, met zijn eigen hoofdknooppunt dat aanvankelijk leeg is.
    pub fn new() -> Self {
        NodeRef::new_leaf().forget_type()
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Leaf> {
    fn new_leaf() -> Self {
        Self::from_new_leaf(LeafNode::new())
    }

    fn from_new_leaf(leaf: Box<LeafNode<K, V>>) -> Self {
        NodeRef { height: 0, node: NonNull::from(Box::leak(leaf)), _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Internal> {
    fn new_internal(child: Root<K, V>) -> Self {
        let mut new_node = unsafe { InternalNode::new() };
        new_node.edges[0].write(child.node);
        unsafe { NodeRef::from_new_internal(new_node, child.height + 1) }
    }

    /// # Safety
    /// `height` mag niet nul zijn.
    unsafe fn from_new_internal(internal: Box<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        let node = NonNull::from(Box::leak(internal)).cast();
        let mut this = NodeRef { height, node, _marker: PhantomData };
        this.borrow_mut().correct_all_childrens_parent_links();
        this
    }
}

impl<K, V, Type> NodeRef<marker::Owned, K, V, Type> {
    /// Leent mutabel het eigen root-knooppunt.
    /// In tegenstelling tot `reborrow_mut` is dit veilig omdat de geretourneerde waarde niet kan worden gebruikt om de root te vernietigen, en er kunnen geen andere verwijzingen naar de boom zijn.
    ///
    pub fn borrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Leent enigszins veranderlijk het eigen root-knooppunt.
    pub fn borrow_valmut(&mut self) -> NodeRef<marker::ValMut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Gaat onomkeerbaar over naar een referentie die verplaatsing mogelijk maakt en destructieve methoden biedt en weinig anders.
    ///
    pub fn into_dying(self) -> NodeRef<marker::Dying, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// Voegt een nieuw intern knooppunt toe met een enkele edge die naar het vorige rootknooppunt wijst, maakt van dat nieuwe knooppunt het rootknooppunt en retourneert het.
    /// Dit verhoogt de hoogte met 1 en is het tegenovergestelde van `pop_internal_level`.
    ///
    pub fn push_internal_level(&mut self) -> NodeRef<marker::Mut<'_>, K, V, marker::Internal> {
        super::mem::take_mut(self, |old_root| NodeRef::new_internal(old_root).forget_type());

        // `self.borrow_mut()`, behalve dat we gewoon vergaten dat we nu intern zijn:
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Verwijdert het interne hoofdknooppunt, waarbij het eerste onderliggende knooppunt wordt gebruikt als het nieuwe hoofdknooppunt.
    /// Omdat het alleen bedoeld is om te worden aangeroepen als het hoofdknooppunt slechts één kind heeft, wordt er niet opgeschoond voor de sleutels, waarden en andere kinderen.
    ///
    /// Dit verlaagt de hoogte met 1 en is het tegenovergestelde van `push_internal_level`.
    ///
    /// Vereist exclusieve toegang tot het `Root`-object, maar niet tot het rootknooppunt;
    /// het maakt geen andere handvatten of verwijzingen naar het hoofdknooppunt ongeldig.
    ///
    /// Panics als er geen intern niveau is, dwz als het rootknooppunt een blad is.
    pub fn pop_internal_level(&mut self) {
        assert!(self.height > 0);

        let top = self.node;

        // VEILIGHEID: we beweerden intern te zijn.
        let internal_self = unsafe { self.borrow_mut().cast_to_internal_unchecked() };
        // VEILIGHEID: we hebben exclusief `self` geleend en het leentype is exclusief.
        let internal_node = unsafe { &mut *NodeRef::as_internal_ptr(&internal_self) };
        // VEILIGHEID: de eerste edge wordt altijd geïnitialiseerd.
        self.node = unsafe { internal_node.edges[0].assume_init_read() };
        self.height -= 1;
        self.clear_parent_link();

        unsafe {
            Global.deallocate(top.cast(), Layout::new::<InternalNode<K, V>>());
        }
    }
}

// N.B. `NodeRef` is altijd covariant in `K` en `V`, zelfs als de `BorrowType` `Mut` is.
// Dit is technisch verkeerd, maar kan niet resulteren in enige onveiligheid vanwege intern gebruik van `NodeRef` omdat we volledig generiek blijven over `K` en `V`.
//
// Wanneer een openbaar type `NodeRef` echter omhult, moet u ervoor zorgen dat het de juiste variantie heeft.
//
/// Een verwijzing naar een knooppunt.
///
/// Dit type heeft een aantal parameters die bepalen hoe het werkt:
/// - `BorrowType`: Een dummy-type dat het soort lenen beschrijft en een leven lang meegaat.
///    - Als dit `Immut<'a>` is, gedraagt de `NodeRef` zich ongeveer als `&'a Node`.
///    - Als dit `ValMut<'a>` is, gedraagt de `NodeRef` zich ongeveer als `&'a Node` met betrekking tot sleutels en boomstructuur, maar laat hij ook veel veranderlijke verwijzingen naar waarden in de hele boom naast elkaar bestaan.
///    - Als dit `Mut<'a>` is, gedraagt de `NodeRef` zich ongeveer als `&'a mut Node`, hoewel invoegmethoden een veranderlijke pointer naar een waarde naast elkaar laten bestaan.
///    - Als dit `Owned` is, gedraagt de `NodeRef` zich ongeveer als `Box<Node>`, maar heeft hij geen destructor en moet hij handmatig worden opgeschoond.
///    - Als dit `Dying` is, gedraagt de `NodeRef` zich nog steeds ongeveer als `Box<Node>`, maar heeft hij methoden om de boom stukje bij beetje te vernietigen, en gewone methoden, hoewel ze niet zijn gemarkeerd als onveilig om aan te roepen, kunnen UB aanroepen als ze onjuist worden aangeroepen.
///
///   Aangezien elke `NodeRef` het mogelijk maakt door de boom te navigeren, is `BorrowType` effectief van toepassing op de hele boom, niet alleen op het knooppunt zelf.
/// - `K` en `V`: dit zijn de soorten sleutels en waarden die zijn opgeslagen in de knooppunten.
/// - `Type`: Dit kan `Leaf`, `Internal` of `LeafOrInternal` zijn.
/// Als dit `Leaf` is, wijst de `NodeRef` naar een leaf-knooppunt, als dit `Internal` is, wijst de `NodeRef` naar een intern knooppunt, en als dit `LeafOrInternal` is, kan de `NodeRef` naar elk type knooppunt wijzen.
///   `Type` heet `NodeType` wanneer het buiten `NodeRef` wordt gebruikt.
///
/// Zowel `BorrowType` als `NodeType` beperken de methoden die we implementeren om gebruik te maken van statische veiligheid.Er zijn beperkingen in de manier waarop we dergelijke beperkingen kunnen toepassen:
/// - Voor elke typeparameter kunnen we alleen een methode generiek of voor één bepaald type definiëren.
/// We kunnen bijvoorbeeld een methode als `into_kv` niet generiek definiëren voor alle `BorrowType`, of eenmalig voor alle typen die een leven lang meegaan, omdat we willen dat deze `&'a`-referenties retourneert.
///   Daarom definiëren we het alleen voor het minst krachtige type `Immut<'a>`.
/// - We kunnen geen impliciete dwang krijgen van bijvoorbeeld `Mut<'a>` tot `Immut<'a>`.
///   Daarom moeten we `reborrow` expliciet aanroepen op een krachtigere `NodeRef` om een methode als `into_kv` te bereiken.
///
/// Alle methoden op `NodeRef` die een soort referentie retourneren, ofwel:
/// - Neem `self` op waarde en retourneer de levensduur die door `BorrowType` wordt gedragen.
///   Soms moeten we, om een dergelijke methode aan te roepen, `reborrow_mut` aanroepen.
/// - Neem `self` als referentie en (implicitly) retourneert de levensduur van die referentie, in plaats van de levensduur die wordt gedragen door `BorrowType`.
/// Op die manier garandeert de leningscontrole dat de `NodeRef` geleend blijft zolang de geretourneerde referentie wordt gebruikt.
///   De methoden die insertie ondersteunen, buigen deze regel door een onbewerkte pointer terug te geven, dwz een referentie zonder enige levensduur.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
pub struct NodeRef<BorrowType, K, V, Type> {
    /// Het aantal niveaus dat het knooppunt en het niveau van bladeren uit elkaar liggen, een constante van het knooppunt die niet volledig kan worden beschreven door `Type`, en dat het knooppunt zelf niet opslaat.
    /// We hoeven alleen de hoogte van het hoofdknooppunt op te slaan en de hoogte van elk ander knooppunt daaruit af te leiden.
    /// Moet nul zijn als `Type` `Leaf` is en niet-nul als `Type` `Internal` is.
    ///
    ///
    height: usize,
    /// De aanwijzer naar het blad of interne knooppunt.
    /// De definitie van `InternalNode` zorgt ervoor dat de pointer hoe dan ook geldig is.
    node: NonNull<LeafNode<K, V>>,
    _marker: PhantomData<(BorrowType, Type)>,
}

impl<'a, K: 'a, V: 'a, Type> Copy for NodeRef<marker::Immut<'a>, K, V, Type> {}
impl<'a, K: 'a, V: 'a, Type> Clone for NodeRef<marker::Immut<'a>, K, V, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

unsafe impl<BorrowType, K: Sync, V: Sync, Type> Sync for NodeRef<BorrowType, K, V, Type> {}

unsafe impl<'a, K: Sync + 'a, V: Sync + 'a, Type> Send for NodeRef<marker::Immut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::Mut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::ValMut<'a>, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Owned, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Dying, K, V, Type> {}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Pak een knooppuntreferentie uit die is verpakt als `NodeRef::parent`.
    fn from_internal(node: NonNull<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        NodeRef { height, node: node.cast(), _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Geeft de gegevens van een intern knooppunt weer.
    ///
    /// Retourneert een onbewerkte ptr om te voorkomen dat andere verwijzingen naar dit knooppunt ongeldig worden.
    fn as_internal_ptr(this: &Self) -> *mut InternalNode<K, V> {
        // VEILIGHEID: het statische knooppunttype is `Internal`.
        this.node.as_ptr() as *mut InternalNode<K, V>
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Leent exclusieve toegang tot de gegevens van een intern knooppunt.
    fn as_internal_mut(&mut self) -> &mut InternalNode<K, V> {
        let ptr = Self::as_internal_ptr(self);
        unsafe { &mut *ptr }
    }
}

impl<BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// Vindt de lengte van het knooppunt.Dit is het aantal sleutels of waarden.
    /// Het aantal randen is `len() + 1`.
    /// Merk op dat, ondanks dat het veilig is, het aanroepen van deze functie het neveneffect kan hebben dat veranderlijke verwijzingen die onveilige code heeft gecreëerd ongeldig worden verklaard.
    ///
    pub fn len(&self) -> usize {
        // Cruciaal is dat we hier alleen toegang hebben tot het `len`-veld.
        // Als BorrowType marker::ValMut is, kunnen er uitstaande veranderlijke verwijzingen zijn naar waarden die we niet ongeldig mogen maken.
        unsafe { usize::from((*Self::as_leaf_ptr(self)).len) }
    }

    /// Retourneert het aantal niveaus dat het knooppunt en de bladeren uit elkaar staan.
    /// Een hoogte nul betekent dat het knooppunt zelf een blad is.
    /// Als je bomen voorstelt met de wortel bovenaan, zegt het nummer op welke hoogte de knoop verschijnt.
    /// Als je je bomen voorstelt met bladeren bovenop, geeft het getal aan hoe hoog de boom boven het knooppunt uitsteekt.
    ///
    pub fn height(&self) -> usize {
        self.height
    }

    /// Verwijdert tijdelijk een andere, onveranderlijke verwijzing naar hetzelfde knooppunt.
    pub fn reborrow(&self) -> NodeRef<marker::Immut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Geeft het bladgedeelte van een blad of interne knoop weer.
    ///
    /// Retourneert een onbewerkte ptr om te voorkomen dat andere verwijzingen naar dit knooppunt ongeldig worden.
    fn as_leaf_ptr(this: &Self) -> *mut LeafNode<K, V> {
        // Het knooppunt moet geldig zijn voor ten minste het LeafNode-gedeelte.
        // Dit is geen verwijzing in het NodeRef-type omdat we niet weten of het uniek of gedeeld moet zijn.
        //
        this.node.as_ptr()
    }
}

impl<BorrowType: marker::BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// Vindt de ouder van het huidige knooppunt.
    /// Geeft `Ok(handle)` terug als het huidige knooppunt daadwerkelijk een ouder heeft, waarbij `handle` verwijst naar de edge van de ouder die naar het huidige knooppunt verwijst.
    ///
    /// Geeft `Err(self)` terug als het huidige knooppunt geen ouder heeft, en geeft de originele `NodeRef` terug.
    ///
    /// De naam van de methode gaat ervan uit dat u bomen afbeeldt met het hoofdknooppunt bovenaan.
    ///
    /// `edge.descend().ascend().unwrap()` en `node.ascend().unwrap().descend()` zouden beide, na succes, niets moeten doen.
    ///
    pub fn ascend(
        self,
    ) -> Result<Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>, Self> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // We moeten onbewerkte verwijzingen naar knooppunten gebruiken omdat, als BorrowType marker::ValMut is, er mogelijk uitstaande veranderlijke verwijzingen naar waarden zijn die we niet ongeldig mogen maken.
        //
        let leaf_ptr: *const _ = Self::as_leaf_ptr(&self);
        unsafe { (*leaf_ptr).parent }
            .as_ref()
            .map(|parent| Handle {
                node: NodeRef::from_internal(*parent, self.height + 1),
                idx: unsafe { usize::from((*leaf_ptr).parent_idx.assume_init()) },
                _marker: PhantomData,
            })
            .ok_or(self)
    }

    pub fn first_edge(self) -> Handle<Self, marker::Edge> {
        unsafe { Handle::new_edge(self, 0) }
    }

    pub fn last_edge(self) -> Handle<Self, marker::Edge> {
        let len = self.len();
        unsafe { Handle::new_edge(self, len) }
    }

    /// Merk op dat `self` niet leeg mag zijn.
    pub fn first_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, 0) }
    }

    /// Merk op dat `self` niet leeg mag zijn.
    pub fn last_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, len - 1) }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Immut<'a>, K, V, Type> {
    /// Laat het bladgedeelte van een blad of interne knoop in een onveranderlijke boom zien.
    fn into_leaf(self) -> &'a LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&self);
        // VEILIGHEID: er kunnen geen veranderlijke verwijzingen zijn naar deze boom die is geleend als `Immut`.
        unsafe { &*ptr }
    }

    /// Leent een blik op de sleutels die in het knooppunt zijn opgeslagen.
    pub fn keys(&self) -> &[K] {
        let leaf = self.into_leaf();
        unsafe {
            MaybeUninit::slice_assume_init_ref(leaf.keys.get_unchecked(..usize::from(leaf.len)))
        }
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// Vergelijkt met `ascend`, krijgt een verwijzing naar het bovenliggende knooppunt van een knooppunt, maar deelt ook de toewijzing van het huidige knooppunt in het proces uit.
    /// Dit is onveilig omdat het huidige knooppunt nog steeds toegankelijk is ondanks dat de toewijzing is opgeheven.
    ///
    pub unsafe fn deallocate_and_ascend(
        self,
    ) -> Option<Handle<NodeRef<marker::Dying, K, V, marker::Internal>, marker::Edge>> {
        let height = self.height;
        let node = self.node;
        let ret = self.ascend().ok();
        unsafe {
            Global.deallocate(
                node.cast(),
                if height > 0 {
                    Layout::new::<InternalNode<K, V>>()
                } else {
                    Layout::new::<LeafNode<K, V>>()
                },
            );
        }
        ret
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Onveilig beweert aan de compiler de statische informatie dat dit knooppunt een `Leaf` is.
    unsafe fn cast_to_leaf_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
        debug_assert!(self.height == 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Onveilig beweert aan de compiler de statische informatie dat dit knooppunt een `Internal` is.
    unsafe fn cast_to_internal_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        debug_assert!(self.height > 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Verwijdert tijdelijk een andere, veranderlijke verwijzing naar hetzelfde knooppunt.Pas op, aangezien deze methode erg gevaarlijk is, dubbel zo omdat het misschien niet meteen gevaarlijk lijkt.
    ///
    /// Omdat veranderlijke aanwijzers overal in de boom kunnen zwerven, kan de geretourneerde aanwijzer gemakkelijk worden gebruikt om de originele aanwijzer te laten bungelen, buiten het bereik of ongeldig te maken onder gestapelde leenregels.
    ///
    ///
    ///
    ///
    // FIXME(@gereeter) overweeg om nog een andere typeparameter toe te voegen aan `NodeRef` die het gebruik van navigatiemethoden op reborrowed pointers beperkt, waardoor deze onveiligheid wordt voorkomen.
    //
    //
    unsafe fn reborrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Leent exclusieve toegang tot het bladgedeelte van elk blad of interne knoop.
    fn as_leaf_mut(&mut self) -> &mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(self);
        // VEILIGHEID: we hebben exclusieve toegang tot het volledige knooppunt.
        unsafe { &mut *ptr }
    }

    /// Biedt exclusieve toegang tot het bladgedeelte van elk blad of interne knoop.
    fn into_leaf_mut(mut self) -> &'a mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&mut self);
        // VEILIGHEID: we hebben exclusieve toegang tot het volledige knooppunt.
        unsafe { &mut *ptr }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Leent exclusieve toegang tot een element van de sleutelopslagruimte.
    ///
    /// # Safety
    /// `index` is binnen de grenzen van 0..CAPACITY
    unsafe fn key_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<K>], Output = Output>,
    {
        // VEILIGHEID: de beller kan geen andere methoden op zichzelf aanroepen
        // totdat de key slice-referentie wordt verwijderd, omdat we unieke toegang hebben gedurende de levensduur van de lening.
        //
        unsafe { self.as_leaf_mut().keys.as_mut_slice().get_unchecked_mut(index) }
    }

    /// Leent exclusieve toegang tot een element of deel van het waardeopslaggebied van het knooppunt.
    ///
    /// # Safety
    /// `index` is binnen de grenzen van 0..CAPACITY
    unsafe fn val_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<V>], Output = Output>,
    {
        // VEILIGHEID: de beller kan geen andere methoden op zichzelf aanroepen
        // totdat de waardeschijfreferentie wordt verwijderd, omdat we unieke toegang hebben gedurende de levensduur van de lening.
        //
        unsafe { self.as_leaf_mut().vals.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Leent exclusieve toegang tot een element of deel van het opslaggebied van het knooppunt voor edge-inhoud.
    ///
    /// # Safety
    /// `index` ligt binnen de grenzen van 0..CAPACITY + 1
    unsafe fn edge_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<BoxedNode<K, V>>], Output = Output>,
    {
        // VEILIGHEID: de beller kan geen andere methoden op zichzelf aanroepen
        // totdat de edge-slice-referentie wordt verwijderd, omdat we unieke toegang hebben gedurende de levensduur van de lening.
        //
        unsafe { self.as_internal_mut().edges.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K, V, Type> NodeRef<marker::ValMut<'a>, K, V, Type> {
    /// # Safety
    /// - Het knooppunt heeft meer dan `idx` geïnitialiseerde elementen.
    unsafe fn into_key_val_mut_at(mut self, idx: usize) -> (&'a K, &'a mut V) {
        // We maken alleen een verwijzing naar het ene element waarin we geïnteresseerd zijn, om aliasing te voorkomen met openstaande verwijzingen naar andere elementen, in het bijzonder die welke in eerdere iteraties aan de beller zijn teruggekeerd.
        //
        //
        let leaf = Self::as_leaf_ptr(&mut self);
        let keys = unsafe { ptr::addr_of!((*leaf).keys) };
        let vals = unsafe { ptr::addr_of_mut!((*leaf).vals) };
        // We moeten dwingen tot niet-bemeten array-aanwijzers vanwege Rust-probleem #74679.
        let keys: *const [_] = keys;
        let vals: *mut [_] = vals;
        let key = unsafe { (&*keys.get_unchecked(idx)).assume_init_ref() };
        let val = unsafe { (&mut *vals.get_unchecked_mut(idx)).assume_init_mut() };
        (key, val)
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Leent exclusieve toegang tot de lengte van het knooppunt.
    pub fn len_mut(&mut self) -> &mut u16 {
        &mut self.as_leaf_mut().len
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Stelt de link van het knooppunt in op zijn bovenliggende edge, zonder andere verwijzingen naar het knooppunt ongeldig te maken.
    ///
    fn set_parent_link(&mut self, parent: NonNull<InternalNode<K, V>>, parent_idx: usize) {
        let leaf = Self::as_leaf_ptr(self);
        unsafe { (*leaf).parent = Some(parent) };
        unsafe { (*leaf).parent_idx.write(parent_idx as u16) };
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// Wist de link van de root naar zijn bovenliggende edge.
    fn clear_parent_link(&mut self) {
        let mut root_node = self.borrow_mut();
        let leaf = root_node.as_leaf_mut();
        leaf.parent = None;
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
    /// Voegt een sleutel/waarde-paar toe aan het einde van het knooppunt.
    pub fn push(&mut self, key: K, val: V) {
        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// # Safety
    /// Elk item dat door `range` wordt geretourneerd, is een geldige edge-index voor het knooppunt.
    unsafe fn correct_childrens_parent_links<R: Iterator<Item = usize>>(&mut self, range: R) {
        for i in range {
            debug_assert!(i <= self.len());
            unsafe { Handle::new_edge(self.reborrow_mut(), i) }.correct_parent_link();
        }
    }

    fn correct_all_childrens_parent_links(&mut self) {
        let len = self.len();
        unsafe { self.correct_childrens_parent_links(0..=len) };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Voegt een sleutel/waarde-paar toe, en een edge om naar de rechterkant van dat paar te gaan, naar het einde van het knooppunt.
    ///
    pub fn push(&mut self, key: K, val: V, edge: Root<K, V>) {
        assert!(edge.height == self.height - 1);

        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
            self.edge_area_mut(idx + 1).write(edge.node);
            Handle::new_edge(self.reborrow_mut(), idx + 1).correct_parent_link();
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Controleert of een knooppunt een `Internal`-knooppunt of een `Leaf`-knooppunt is.
    pub fn force(
        self,
    ) -> ForceResult<
        NodeRef<BorrowType, K, V, marker::Leaf>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        if self.height == 0 {
            ForceResult::Leaf(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        } else {
            ForceResult::Internal(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        }
    }
}

/// Een verwijzing naar een specifiek sleutel/waarde-paar of edge binnen een knooppunt.
/// De parameter `Node` moet een `NodeRef` zijn, terwijl de `Type` `KV` kan zijn (wat een handle op een sleutelwaardepaar betekent) of `Edge` (wat een handle op een edge betekent).
///
/// Merk op dat zelfs `Leaf`-knooppunten `Edge`-handvatten kunnen hebben.
/// In plaats van een aanwijzer naar een kindknooppunt weer te geven, vertegenwoordigen deze de spaties waar kindwijzers tussen de sleutelwaardeparen zouden gaan.
/// In een knooppunt met lengte 2 zijn er bijvoorbeeld 3 mogelijke edge-locaties, één links van het knooppunt, één tussen de twee paren en één rechts van het knooppunt.
///
///
pub struct Handle<Node, Type> {
    node: Node,
    idx: usize,
    _marker: PhantomData<Type>,
}

impl<Node: Copy, Type> Copy for Handle<Node, Type> {}
// We hebben niet de volledige algemeenheid van `#[derive(Clone)]` nodig, aangezien de enige keer dat `Node` kan worden 'gekloond', is wanneer het een onveranderlijke referentie is en daarom `Copy`.
//
impl<Node: Copy, Type> Clone for Handle<Node, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

impl<Node, Type> Handle<Node, Type> {
    /// Haalt het knooppunt op dat het edge-of sleutelwaardepaar bevat waarnaar deze handle verwijst.
    pub fn into_node(self) -> Node {
        self.node
    }

    /// Retourneert de positie van deze handle in het knooppunt.
    pub fn idx(&self) -> usize {
        self.idx
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV> {
    /// Maakt een nieuwe handle aan voor een sleutel/waarde-paar in `node`.
    /// Onveilig omdat de beller ervoor moet zorgen dat `idx < node.len()`.
    pub unsafe fn new_kv(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx < node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx) }
    }

    pub fn right_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx + 1) }
    }
}

impl<BorrowType, K, V, NodeType> NodeRef<BorrowType, K, V, NodeType> {
    /// Kan een openbare implementatie van PartialEq zijn, maar wordt alleen in deze module gebruikt.
    fn eq(&self, other: &Self) -> bool {
        let Self { node, height, _marker } = self;
        if node.eq(&other.node) {
            debug_assert_eq!(*height, other.height);
            true
        } else {
            false
        }
    }
}

impl<BorrowType, K, V, NodeType, HandleType> PartialEq
    for Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    fn eq(&self, other: &Self) -> bool {
        let Self { node, idx, _marker } = self;
        node.eq(&other.node) && *idx == other.idx
    }
}

impl<BorrowType, K, V, NodeType, HandleType>
    Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    /// Verwijdert tijdelijk een andere, onveranderlijke handgreep op dezelfde locatie.
    pub fn reborrow(&self) -> Handle<NodeRef<marker::Immut<'_>, K, V, NodeType>, HandleType> {
        // We kunnen Handle::new_kv of Handle::new_edge niet gebruiken omdat we ons type niet kennen
        Handle { node: self.node.reborrow(), idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, Type> {
    /// Onveilig beweert aan de compiler de statische informatie dat het knooppunt van de handle een `Leaf` is.
    pub unsafe fn cast_to_leaf_unchecked(
        self,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, Type> {
        let node = unsafe { self.node.cast_to_leaf_unchecked() };
        Handle { node, idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, NodeType, HandleType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, HandleType> {
    /// Verwijdert tijdelijk een andere, veranderlijke handgreep op dezelfde locatie.
    /// Pas op, aangezien deze methode erg gevaarlijk is, dubbel zo omdat het misschien niet meteen gevaarlijk lijkt.
    ///
    ///
    /// Zie `NodeRef::reborrow_mut` voor meer informatie.
    pub unsafe fn reborrow_mut(
        &mut self,
    ) -> Handle<NodeRef<marker::Mut<'_>, K, V, NodeType>, HandleType> {
        // We kunnen Handle::new_kv of Handle::new_edge niet gebruiken omdat we ons type niet kennen
        Handle { node: unsafe { self.node.reborrow_mut() }, idx: self.idx, _marker: PhantomData }
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
    /// Creëert een nieuwe handle naar een edge in `node`.
    /// Onveilig omdat de beller ervoor moet zorgen dat `idx <= node.len()`.
    pub unsafe fn new_edge(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx <= node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx > 0 {
            Ok(unsafe { Handle::new_kv(self.node, self.idx - 1) })
        } else {
            Err(self)
        }
    }

    pub fn right_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx < self.node.len() {
            Ok(unsafe { Handle::new_kv(self.node, self.idx) })
        } else {
            Err(self)
        }
    }
}

pub enum LeftOrRight<T> {
    Left(T),
    Right(T),
}

/// Gegeven een edge-index waar we willen invoegen in een knooppunt gevuld tot capaciteit, berekent een verstandige KV-index van een splitspunt en waar de invoeging moet worden uitgevoerd.
///
/// Het doel van het splitsingspunt is dat de sleutel en waarde ervan in een bovenliggende node terechtkomen;
/// de toetsen, waarden en randen links van het splitspunt worden het linkerkind;
/// de toetsen, waarden en randen rechts van het splitspunt worden het rechter kind.
fn splitpoint(edge_idx: usize) -> (usize, LeftOrRight<usize>) {
    debug_assert!(edge_idx <= CAPACITY);
    // Rust uitgave #74834 probeert deze symmetrische regels uit te leggen.
    match edge_idx {
        0..EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER - 1, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_RIGHT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Right(0)),
        _ => (KV_IDX_CENTER + 1, LeftOrRight::Right(edge_idx - (KV_IDX_CENTER + 1 + 1))),
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Voegt een nieuw sleutelwaardepaar in tussen de sleutelwaardeparen rechts en links van deze edge.
    /// Bij deze methode wordt ervan uitgegaan dat er voldoende ruimte in het knooppunt is om het nieuwe paar te laten passen.
    ///
    /// De geretourneerde aanwijzer verwijst naar de ingevoegde waarde.
    ///
    fn insert_fit(&mut self, key: K, val: V) -> *mut V {
        debug_assert!(self.node.len() < CAPACITY);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            *self.node.len_mut() = new_len as u16;

            self.node.val_area_mut(self.idx).assume_init_mut()
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Voegt een nieuw sleutelwaardepaar in tussen de sleutelwaardeparen rechts en links van deze edge.
    /// Met deze methode wordt het knooppunt gesplitst als er niet genoeg ruimte is.
    ///
    /// De geretourneerde aanwijzer verwijst naar de ingevoegde waarde.
    fn insert(mut self, key: K, val: V) -> (InsertResult<'a, K, V, marker::Leaf>, *mut V) {
        if self.node.len() < CAPACITY {
            let val_ptr = self.insert_fit(key, val);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            (InsertResult::Fit(kv), val_ptr)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            let val_ptr = insertion_edge.insert_fit(key, val);
            (InsertResult::Split(result), val_ptr)
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// Corrigeert de bovenliggende pointer en index in het onderliggende knooppunt waarnaar deze edge linkt.
    /// Dit is handig wanneer de volgorde van de randen is gewijzigd,
    fn correct_parent_link(self) {
        // Maak een backpointer zonder andere verwijzingen naar het knooppunt ongeldig te maken.
        let ptr = unsafe { NonNull::new_unchecked(NodeRef::as_internal_ptr(&self.node)) };
        let idx = self.idx;
        let mut child = self.descend();
        child.set_parent_link(ptr, idx);
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// Voegt een nieuw sleutelwaardepaar en een edge in die naar rechts van dat nieuwe paar gaan tussen deze edge en het sleutelwaardepaar rechts van deze edge.
    /// Bij deze methode wordt ervan uitgegaan dat er voldoende ruimte in het knooppunt is om het nieuwe paar te laten passen.
    ///
    fn insert_fit(&mut self, key: K, val: V, edge: Root<K, V>) {
        debug_assert!(self.node.len() < CAPACITY);
        debug_assert!(edge.height == self.node.height - 1);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            slice_insert(self.node.edge_area_mut(..new_len + 1), self.idx + 1, edge.node);
            *self.node.len_mut() = new_len as u16;

            self.node.correct_childrens_parent_links(self.idx + 1..new_len + 1);
        }
    }

    /// Voegt een nieuw sleutelwaardepaar en een edge in die naar rechts van dat nieuwe paar gaan tussen deze edge en het sleutelwaardepaar rechts van deze edge.
    /// Met deze methode wordt het knooppunt gesplitst als er niet genoeg ruimte is.
    ///
    fn insert(
        mut self,
        key: K,
        val: V,
        edge: Root<K, V>,
    ) -> InsertResult<'a, K, V, marker::Internal> {
        assert!(edge.height == self.node.height - 1);

        if self.node.len() < CAPACITY {
            self.insert_fit(key, val, edge);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            InsertResult::Fit(kv)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            insertion_edge.insert_fit(key, val, edge);
            InsertResult::Split(result)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Voegt een nieuw sleutelwaardepaar in tussen de sleutelwaardeparen rechts en links van deze edge.
    /// Deze methode splitst het knooppunt als er niet genoeg ruimte is en probeert het afgesplitste gedeelte recursief in het bovenliggende knooppunt in te voegen, totdat de root is bereikt.
    ///
    ///
    /// Als het geretourneerde resultaat een `Fit` is, kan het knooppunt van de handle dit knooppunt van edge of een voorouder zijn.
    /// Als het geretourneerde resultaat een `Split` is, is het veld `left` het hoofdknooppunt.
    /// De geretourneerde aanwijzer verwijst naar de ingevoegde waarde.
    pub fn insert_recursing(
        self,
        key: K,
        value: V,
    ) -> (InsertResult<'a, K, V, marker::LeafOrInternal>, *mut V) {
        let (mut split, val_ptr) = match self.insert(key, value) {
            (InsertResult::Fit(handle), ptr) => {
                return (InsertResult::Fit(handle.forget_node_type()), ptr);
            }
            (InsertResult::Split(split), val_ptr) => (split.forget_node_type(), val_ptr),
        };

        loop {
            split = match split.left.ascend() {
                Ok(parent) => match parent.insert(split.kv.0, split.kv.1, split.right) {
                    InsertResult::Fit(handle) => {
                        return (InsertResult::Fit(handle.forget_node_type()), val_ptr);
                    }
                    InsertResult::Split(split) => split.forget_node_type(),
                },
                Err(root) => {
                    return (InsertResult::Split(SplitResult { left: root, ..split }), val_ptr);
                }
            };
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// Vindt het knooppunt waarnaar door deze edge wordt verwezen.
    ///
    /// De naam van de methode gaat ervan uit dat u bomen afbeeldt met het hoofdknooppunt bovenaan.
    ///
    /// `edge.descend().ascend().unwrap()` en `node.ascend().unwrap().descend()` zouden beide, na succes, niets moeten doen.
    ///
    pub fn descend(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // We moeten onbewerkte verwijzingen naar knooppunten gebruiken omdat, als BorrowType marker::ValMut is, er mogelijk uitstaande veranderlijke verwijzingen naar waarden zijn die we niet ongeldig mogen maken.
        // U hoeft zich geen zorgen te maken over toegang tot het hoogteveld, want die waarde wordt gekopieerd.
        // Pas op dat, zodra de node pointer is dereferentie, we toegang krijgen tot de edge-array met een verwijzing (Rust issue #73987) en alle andere verwijzingen naar of binnen de array ongeldig maken, als die er in de buurt zijn.
        //
        //
        //
        //
        let parent_ptr = NodeRef::as_internal_ptr(&self.node);
        let node = unsafe { (*parent_ptr).edges.get_unchecked(self.idx).assume_init_read() };
        NodeRef { node, height: self.node.height - 1, _marker: PhantomData }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Immut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv(self) -> (&'a K, &'a V) {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf();
        let k = unsafe { leaf.keys.get_unchecked(self.idx).assume_init_ref() };
        let v = unsafe { leaf.vals.get_unchecked(self.idx).assume_init_ref() };
        (k, v)
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn key_mut(&mut self) -> &mut K {
        unsafe { self.node.key_area_mut(self.idx).assume_init_mut() }
    }

    pub fn into_val_mut(self) -> &'a mut V {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf_mut();
        unsafe { leaf.vals.get_unchecked_mut(self.idx).assume_init_mut() }
    }
}

impl<'a, K, V, NodeType> Handle<NodeRef<marker::ValMut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv_valmut(self) -> (&'a K, &'a mut V) {
        unsafe { self.node.into_key_val_mut_at(self.idx) }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn kv_mut(&mut self) -> (&mut K, &mut V) {
        debug_assert!(self.idx < self.node.len());
        // We kunnen geen aparte sleutel-en waardemethoden aanroepen, omdat het aanroepen van de tweede de verwijzing ongeldig maakt die door de eerste wordt geretourneerd.
        //
        unsafe {
            let leaf = self.node.as_leaf_mut();
            let key = leaf.keys.get_unchecked_mut(self.idx).assume_init_mut();
            let val = leaf.vals.get_unchecked_mut(self.idx).assume_init_mut();
            (key, val)
        }
    }

    /// Vervang de sleutel en waarde waarnaar de KV-handle verwijst.
    pub fn replace_kv(&mut self, k: K, v: V) -> (K, V) {
        let (key, val) = self.kv_mut();
        (mem::replace(key, k), mem::replace(val, v))
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    /// Helpt bij implementaties van `split` voor een bepaalde `NodeType`, door voor bladgegevens te zorgen.
    ///
    fn split_leaf_data(&mut self, new_node: &mut LeafNode<K, V>) -> (K, V) {
        debug_assert!(self.idx < self.node.len());
        let old_len = self.node.len();
        let new_len = old_len - self.idx - 1;
        new_node.len = new_len as u16;
        unsafe {
            let k = self.node.key_area_mut(self.idx).assume_init_read();
            let v = self.node.val_area_mut(self.idx).assume_init_read();

            move_to_slice(
                self.node.key_area_mut(self.idx + 1..old_len),
                &mut new_node.keys[..new_len],
            );
            move_to_slice(
                self.node.val_area_mut(self.idx + 1..old_len),
                &mut new_node.vals[..new_len],
            );

            *self.node.len_mut() = self.idx as u16;
            (k, v)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::KV> {
    /// Splitst het onderliggende knooppunt in drie delen:
    ///
    /// - Het knooppunt wordt afgekapt om alleen de sleutel/waarde-paren links van deze handle te bevatten.
    /// - De sleutel en waarde waarnaar door deze handle wordt verwezen, worden geëxtraheerd.
    /// - Alle sleutel/waarde-paren aan de rechterkant van deze handle worden in een nieuw toegewezen knooppunt geplaatst.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Leaf> {
        let mut new_node = LeafNode::new();

        let kv = self.split_leaf_data(&mut new_node);

        let right = NodeRef::from_new_leaf(new_node);
        SplitResult { left: self.node, kv, right }
    }

    /// Verwijdert het sleutel/waarde-paar waarnaar door deze handle wordt verwezen en retourneert het, samen met de edge waarin het sleutel/waarde-paar is samengevouwen.
    ///
    pub fn remove(
        mut self,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        let old_len = self.node.len();
        unsafe {
            let k = slice_remove(self.node.key_area_mut(..old_len), self.idx);
            let v = slice_remove(self.node.val_area_mut(..old_len), self.idx);
            *self.node.len_mut() = (old_len - 1) as u16;
            ((k, v), self.left_edge())
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    /// Splitst het onderliggende knooppunt in drie delen:
    ///
    /// - Het knooppunt wordt afgekapt om alleen de randen en sleutel/waarde-paren links van deze handle te bevatten.
    /// - De sleutel en waarde waarnaar door deze handle wordt verwezen, worden geëxtraheerd.
    /// - Alle randen en sleutel/waarde-paren aan de rechterkant van deze handle worden in een nieuw toegewezen knooppunt geplaatst.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Internal> {
        let old_len = self.node.len();
        unsafe {
            let mut new_node = InternalNode::new();
            let kv = self.split_leaf_data(&mut new_node.data);
            let new_len = usize::from(new_node.data.len);
            move_to_slice(
                self.node.edge_area_mut(self.idx + 1..old_len + 1),
                &mut new_node.edges[..new_len + 1],
            );

            let height = self.node.height;
            let right = NodeRef::from_new_internal(new_node, height);

            SplitResult { left: self.node, kv, right }
        }
    }
}

/// Vertegenwoordigt een sessie voor het evalueren en uitvoeren van een evenwichtsoperatie rond een intern sleutel/waarde-paar.
///
pub struct BalancingContext<'a, K, V> {
    parent: Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV>,
    left_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    right_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    pub fn consider_for_balancing(self) -> BalancingContext<'a, K, V> {
        let self1 = unsafe { ptr::read(&self) };
        let self2 = unsafe { ptr::read(&self) };
        BalancingContext {
            parent: self,
            left_child: self1.left_edge().descend(),
            right_child: self2.right_edge().descend(),
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Kiest een evenwichtscontext waarbij het knooppunt als kind betrokken is, dus tussen de KV direct links of rechts in het bovenliggende knooppunt.
    /// Retourneert een `Err` als er geen ouder is.
    /// Panics als de ouder leeg is.
    ///
    /// Geeft de voorkeur aan de linkerkant, om optimaal te zijn als het gegeven knooppunt op de een of andere manier ondervol is, wat hier alleen betekent dat het minder elementen heeft dan zijn linkerbroer of zus, en dan zijn rechterbroer, als ze bestaan.
    /// In dat geval gaat het samenvoegen met de linkerbroer of zus sneller, omdat we alleen de N-elementen van het knooppunt hoeven te verplaatsen, in plaats van ze naar rechts te verplaatsen en meer dan N-elementen naar voren te verplaatsen.
    /// Stelen van de linkerbroer of zus is doorgaans ook sneller, omdat we alleen de N-elementen van het knooppunt naar rechts hoeven te verschuiven, in plaats van ten minste N van de elementen van de broer of zus naar links te verschuiven.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn choose_parent_kv(self) -> Result<LeftOrRight<BalancingContext<'a, K, V>>, Self> {
        match unsafe { ptr::read(&self) }.ascend() {
            Ok(parent_edge) => match parent_edge.left_kv() {
                Ok(left_parent_kv) => Ok(LeftOrRight::Left(BalancingContext {
                    parent: unsafe { ptr::read(&left_parent_kv) },
                    left_child: left_parent_kv.left_edge().descend(),
                    right_child: self,
                })),
                Err(parent_edge) => match parent_edge.right_kv() {
                    Ok(right_parent_kv) => Ok(LeftOrRight::Right(BalancingContext {
                        parent: unsafe { ptr::read(&right_parent_kv) },
                        left_child: self,
                        right_child: right_parent_kv.right_edge().descend(),
                    })),
                    Err(_) => unreachable!("empty internal node"),
                },
            },
            Err(root) => Err(root),
        }
    }
}

impl<'a, K, V> BalancingContext<'a, K, V> {
    pub fn left_child_len(&self) -> usize {
        self.left_child.len()
    }

    pub fn right_child_len(&self) -> usize {
        self.right_child.len()
    }

    pub fn into_left_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.left_child
    }

    pub fn into_right_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.right_child
    }

    /// Geeft terug of samenvoegen mogelijk is, dwz of er voldoende ruimte is in een knooppunt om de centrale KV te combineren met beide aangrenzende onderliggende knooppunten.
    ///
    pub fn can_merge(&self) -> bool {
        self.left_child.len() + 1 + self.right_child.len() <= CAPACITY
    }
}

impl<'a, K: 'a, V: 'a> BalancingContext<'a, K, V> {
    /// Voert een samenvoeging uit en laat een afsluiting beslissen wat er wordt geretourneerd.
    fn do_merge<
        F: FnOnce(
            NodeRef<marker::Mut<'a>, K, V, marker::Internal>,
            NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
        ) -> R,
        R,
    >(
        self,
        result: F,
    ) -> R {
        let Handle { node: mut parent_node, idx: parent_idx, _marker } = self.parent;
        let old_parent_len = parent_node.len();
        let mut left_node = self.left_child;
        let old_left_len = left_node.len();
        let mut right_node = self.right_child;
        let right_len = right_node.len();
        let new_left_len = old_left_len + 1 + right_len;

        assert!(new_left_len <= CAPACITY);

        unsafe {
            *left_node.len_mut() = new_left_len as u16;

            let parent_key = slice_remove(parent_node.key_area_mut(..old_parent_len), parent_idx);
            left_node.key_area_mut(old_left_len).write(parent_key);
            move_to_slice(
                right_node.key_area_mut(..right_len),
                left_node.key_area_mut(old_left_len + 1..new_left_len),
            );

            let parent_val = slice_remove(parent_node.val_area_mut(..old_parent_len), parent_idx);
            left_node.val_area_mut(old_left_len).write(parent_val);
            move_to_slice(
                right_node.val_area_mut(..right_len),
                left_node.val_area_mut(old_left_len + 1..new_left_len),
            );

            slice_remove(&mut parent_node.edge_area_mut(..old_parent_len + 1), parent_idx + 1);
            parent_node.correct_childrens_parent_links(parent_idx + 1..old_parent_len);
            *parent_node.len_mut() -= 1;

            if parent_node.height > 1 {
                // VEILIGHEID: de hoogte van de knooppunten die worden samengevoegd is één onder de hoogte
                // van het knooppunt van deze edge, dus boven nul, dus ze zijn intern.
                let mut left_node = left_node.reborrow_mut().cast_to_internal_unchecked();
                let mut right_node = right_node.cast_to_internal_unchecked();
                move_to_slice(
                    right_node.edge_area_mut(..right_len + 1),
                    left_node.edge_area_mut(old_left_len + 1..new_left_len + 1),
                );

                left_node.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);

                Global.deallocate(right_node.node.cast(), Layout::new::<InternalNode<K, V>>());
            } else {
                Global.deallocate(right_node.node.cast(), Layout::new::<LeafNode<K, V>>());
            }
        }
        result(parent_node, left_node)
    }

    /// Voegt het sleutel-waardepaar van de parent en beide aangrenzende child-knooppunten samen in het linker child-knooppunt en retourneert het verkleinde parent-knooppunt.
    ///
    ///
    /// Panics tenzij we `.can_merge()`.
    pub fn merge_tracking_parent(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        self.do_merge(|parent, _child| parent)
    }

    /// Voegt het sleutel/waarde-paar van de ouder en beide aangrenzende onderliggende knooppunten samen in het linkerkindknooppunt en retourneert dat onderliggende knooppunt.
    ///
    ///
    /// Panics tenzij we `.can_merge()`.
    pub fn merge_tracking_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.do_merge(|_parent, child| child)
    }

    /// Voegt het sleutel-waardepaar van de ouder en beide aangrenzende kindknooppunten samen in het linkerkindknooppunt en retourneert de edge-handle in dat kindknooppunt waar het bijgehouden kind edge terechtkwam,
    ///
    ///
    /// Panics tenzij we `.can_merge()`.
    ///
    pub fn merge_tracking_child_edge(
        self,
        track_edge_idx: LeftOrRight<usize>,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        let old_left_len = self.left_child.len();
        let right_len = self.right_child.len();
        assert!(match track_edge_idx {
            LeftOrRight::Left(idx) => idx <= old_left_len,
            LeftOrRight::Right(idx) => idx <= right_len,
        });
        let child = self.merge_tracking_child();
        let new_idx = match track_edge_idx {
            LeftOrRight::Left(idx) => idx,
            LeftOrRight::Right(idx) => old_left_len + 1 + idx,
        };
        unsafe { Handle::new_edge(child, new_idx) }
    }

    /// Verwijdert een sleutel/waarde-paar van het linkerkind en plaatst het in de sleutel/waarde-opslag van de parent, terwijl het oude parent-sleutel/waarde-paar naar het rechterkind wordt geduwd.
    ///
    /// Retourneert een handle naar de edge in het rechterkind die overeenkomt met waar de oorspronkelijke edge gespecificeerd door `track_right_edge_idx` terechtkwam.
    ///
    pub fn steal_left(
        mut self,
        track_right_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_left(1);
        unsafe { Handle::new_edge(self.right_child, 1 + track_right_edge_idx) }
    }

    /// Verwijdert een sleutel/waarde-paar van het rechterkind en plaatst het in de sleutel/waarde-opslag van de parent, terwijl het oude parent-sleutel/waarde-paar naar het linkerkind wordt geduwd.
    ///
    /// Retourneert een handle naar de edge in het linkerkind gespecificeerd door `track_left_edge_idx`, dat niet is verplaatst.
    ///
    pub fn steal_right(
        mut self,
        track_left_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_right(1);
        unsafe { Handle::new_edge(self.left_child, track_left_edge_idx) }
    }

    /// Dit steelt vergelijkbaar met `steal_left`, maar steelt meerdere elementen tegelijk.
    pub fn bulk_steal_left(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // Zorg ervoor dat we veilig kunnen stelen.
            assert!(old_right_len + count <= CAPACITY);
            assert!(old_left_len >= count);

            let new_left_len = old_left_len - count;
            let new_right_len = old_right_len + count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // Verplaats bladgegevens.
            {
                // Maak ruimte voor gestolen elementen in het juiste kind.
                slice_shr(right_node.key_area_mut(..new_right_len), count);
                slice_shr(right_node.val_area_mut(..new_right_len), count);

                // Verplaats elementen van het linkerkind naar het rechterkind.
                move_to_slice(
                    left_node.key_area_mut(new_left_len + 1..old_left_len),
                    right_node.key_area_mut(..count - 1),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len + 1..old_left_len),
                    right_node.val_area_mut(..count - 1),
                );

                // Verplaats het meest linkse gestolen paar naar de ouder.
                let k = left_node.key_area_mut(new_left_len).assume_init_read();
                let v = left_node.val_area_mut(new_left_len).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // Verplaats het sleutel/waarde-paar van de ouder naar het juiste kind.
                right_node.key_area_mut(count - 1).write(k);
                right_node.val_area_mut(count - 1).write(v);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // Maak ruimte voor gestolen randen.
                    slice_shr(right.edge_area_mut(..new_right_len + 1), count);

                    // Steel randen.
                    move_to_slice(
                        left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                        right.edge_area_mut(..count),
                    );

                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }

    /// De symmetrische kloon van `bulk_steal_left`.
    pub fn bulk_steal_right(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // Zorg ervoor dat we veilig kunnen stelen.
            assert!(old_left_len + count <= CAPACITY);
            assert!(old_right_len >= count);

            let new_left_len = old_left_len + count;
            let new_right_len = old_right_len - count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // Verplaats bladgegevens.
            {
                // Verplaats het meest rechtse gestolen paar naar de ouder.
                let k = right_node.key_area_mut(count - 1).assume_init_read();
                let v = right_node.val_area_mut(count - 1).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // Verplaats het sleutel/waarde-paar van de ouder naar het linkerkind.
                left_node.key_area_mut(old_left_len).write(k);
                left_node.val_area_mut(old_left_len).write(v);

                // Verplaats elementen van het rechterkind naar het linkerkind.
                move_to_slice(
                    right_node.key_area_mut(..count - 1),
                    left_node.key_area_mut(old_left_len + 1..new_left_len),
                );
                move_to_slice(
                    right_node.val_area_mut(..count - 1),
                    left_node.val_area_mut(old_left_len + 1..new_left_len),
                );

                // Vul het gat waar gestolen elementen waren.
                slice_shl(right_node.key_area_mut(..old_right_len), count);
                slice_shl(right_node.val_area_mut(..old_right_len), count);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // Steel randen.
                    move_to_slice(
                        right.edge_area_mut(..count),
                        left.edge_area_mut(old_left_len + 1..new_left_len + 1),
                    );

                    // Vul het gat waar vroeger gestolen randen waren.
                    slice_shl(right.edge_area_mut(..old_right_len + 1), count);

                    left.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);
                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Leaf> {
    /// Verwijdert alle statische informatie die beweert dat dit knooppunt een `Leaf`-knooppunt is.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Verwijdert alle statische informatie die beweert dat dit knooppunt een `Internal`-knooppunt is.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V, Type> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, Type> {
    /// Controleert of het onderliggende knooppunt een `Internal`-knooppunt of een `Leaf`-knooppunt is.
    pub fn force(
        self,
    ) -> ForceResult<
        Handle<NodeRef<BorrowType, K, V, marker::Leaf>, Type>,
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, Type>,
    > {
        match self.node.force() {
            ForceResult::Leaf(node) => {
                ForceResult::Leaf(Handle { node, idx: self.idx, _marker: PhantomData })
            }
            ForceResult::Internal(node) => {
                ForceResult::Internal(Handle { node, idx: self.idx, _marker: PhantomData })
            }
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
    /// Verplaats het achtervoegsel na `self` van het ene knooppunt naar het andere.`right` moet leeg zijn.
    /// De eerste edge van `right` blijft ongewijzigd.
    pub fn move_suffix(
        &mut self,
        right: &mut NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    ) {
        unsafe {
            let new_left_len = self.idx;
            let mut left_node = self.reborrow_mut().into_node();
            let old_left_len = left_node.len();

            let new_right_len = old_left_len - new_left_len;
            let mut right_node = right.reborrow_mut();

            assert!(right_node.len() == 0);
            assert!(left_node.height == right_node.height);

            if new_right_len > 0 {
                *left_node.len_mut() = new_left_len as u16;
                *right_node.len_mut() = new_right_len as u16;

                move_to_slice(
                    left_node.key_area_mut(new_left_len..old_left_len),
                    right_node.key_area_mut(..new_right_len),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len..old_left_len),
                    right_node.val_area_mut(..new_right_len),
                );
                match (left_node.force(), right_node.force()) {
                    (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                        move_to_slice(
                            left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                            right.edge_area_mut(1..new_right_len + 1),
                        );
                        right.correct_childrens_parent_links(1..new_right_len + 1);
                    }
                    (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                    _ => unreachable!(),
                }
            }
        }
    }
}

pub enum ForceResult<Leaf, Internal> {
    Leaf(Leaf),
    Internal(Internal),
}

/// Resultaat van invoeging, wanneer een knooppunt groter moest worden dan zijn capaciteit.
pub struct SplitResult<'a, K, V, NodeType> {
    // Gewijzigde knoop in bestaande boom met elementen en randen die aan de linkerkant van `kv` horen.
    pub left: NodeRef<marker::Mut<'a>, K, V, NodeType>,
    // Een sleutel en waarde worden afgesplitst, om ergens anders in te voegen.
    pub kv: (K, V),
    // Eigendom, niet-gekoppeld, nieuw knooppunt met elementen en randen die aan de rechterkant van `kv` horen.
    pub right: NodeRef<marker::Owned, K, V, NodeType>,
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Leaf> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Internal> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

pub enum InsertResult<'a, K, V, NodeType> {
    Fit(Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV>),
    Split(SplitResult<'a, K, V, NodeType>),
}

pub mod marker {
    use core::marker::PhantomData;

    pub enum Leaf {}
    pub enum Internal {}
    pub enum LeafOrInternal {}

    pub enum Owned {}
    pub enum Dying {}
    pub struct Immut<'a>(PhantomData<&'a ()>);
    pub struct Mut<'a>(PhantomData<&'a mut ()>);
    pub struct ValMut<'a>(PhantomData<&'a mut ()>);

    pub trait BorrowType {
        // Of knooppuntreferenties van dit leentype het doorlopen naar andere knooppunten in de boom toestaan.
        //
        const PERMITS_TRAVERSAL: bool = true;
    }
    impl BorrowType for Owned {
        // Traversal is niet nodig, het gebeurt met het resultaat van `borrow_mut`.
        // Door traversal uit te schakelen en alleen nieuwe verwijzingen naar roots te maken, weten we dat elke verwijzing van het `Owned`-type naar een rootknooppunt is.
        //
        const PERMITS_TRAVERSAL: bool = false;
    }
    impl BorrowType for Dying {}
    impl<'a> BorrowType for Immut<'a> {}
    impl<'a> BorrowType for Mut<'a> {}
    impl<'a> BorrowType for ValMut<'a> {}

    pub enum KV {}
    pub enum Edge {}
}

/// Voegt een waarde in een segment van geïnitialiseerde elementen in, gevolgd door een niet-geïnitialiseerd element.
///
/// # Safety
/// Het segment heeft meer dan `idx`-elementen.
unsafe fn slice_insert<T>(slice: &mut [MaybeUninit<T>], idx: usize, val: T) {
    unsafe {
        let len = slice.len();
        debug_assert!(len > idx);
        let slice_ptr = slice.as_mut_ptr();
        if len > idx + 1 {
            ptr::copy(slice_ptr.add(idx), slice_ptr.add(idx + 1), len - idx - 1);
        }
        (*slice_ptr.add(idx)).write(val);
    }
}

/// Verwijdert en retourneert een waarde uit een segment van alle geïnitialiseerde elementen, waarbij een achterliggend niet-geïnitialiseerd element achterblijft.
///
///
/// # Safety
/// Het segment heeft meer dan `idx`-elementen.
unsafe fn slice_remove<T>(slice: &mut [MaybeUninit<T>], idx: usize) -> T {
    unsafe {
        let len = slice.len();
        debug_assert!(idx < len);
        let slice_ptr = slice.as_mut_ptr();
        let ret = (*slice_ptr.add(idx)).assume_init_read();
        ptr::copy(slice_ptr.add(idx + 1), slice_ptr.add(idx), len - idx - 1);
        ret
    }
}

/// Verschuift de elementen in de `distance`-posities van een segment naar links.
///
/// # Safety
/// Het segment heeft minimaal `distance`-elementen.
unsafe fn slice_shl<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr.add(distance), slice_ptr, slice.len() - distance);
    }
}

/// Verschuift de elementen in de `distance`-posities van een segment naar rechts.
///
/// # Safety
/// Het segment heeft minimaal `distance`-elementen.
unsafe fn slice_shr<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr, slice_ptr.add(distance), slice.len() - distance);
    }
}

/// Verplaatst alle waarden van een segment met geïnitialiseerde elementen naar een segment met niet-geïnitialiseerde elementen, waarbij `src` achterblijft als niet-geïnitialiseerd.
///
/// Werkt als `dst.copy_from_slice(src)`, maar vereist niet dat `T` `Copy` is.
fn move_to_slice<T>(src: &mut [MaybeUninit<T>], dst: &mut [MaybeUninit<T>]) {
    assert!(src.len() == dst.len());
    unsafe {
        ptr::copy_nonoverlapping(src.as_ptr(), dst.as_mut_ptr(), src.len());
    }
}

#[cfg(test)]
mod tests;