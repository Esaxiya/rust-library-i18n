use crate::fmt::Debug;
use std::cmp::Ordering;
use std::sync::atomic::{AtomicUsize, Ordering::SeqCst};

/// Een blauwdruk voor dummy-instanties van crashtests die bepaalde gebeurtenissen bewaken.
/// Sommige instanties kunnen op een gegeven moment worden geconfigureerd als panic.
/// Gebeurtenissen zijn `clone`, `drop` of een anonieme `query`.
///
/// Crashtestdummy's worden geïdentificeerd en geordend op id, zodat ze als sleutels in een BTreeMap kunnen worden gebruikt.
/// De implementatie die opzettelijk wordt gebruikt, is niet afhankelijk van iets dat is gedefinieerd in de crate, behalve de `Debug` trait.
///
#[derive(Debug)]
pub struct CrashTestDummy {
    id: usize,
    cloned: AtomicUsize,
    dropped: AtomicUsize,
    queried: AtomicUsize,
}

impl CrashTestDummy {
    /// Creëert een crashtest-dummy-ontwerp.De `id` bepaalt de volgorde en gelijkheid van instanties.
    pub fn new(id: usize) -> CrashTestDummy {
        CrashTestDummy {
            id,
            cloned: AtomicUsize::new(0),
            dropped: AtomicUsize::new(0),
            queried: AtomicUsize::new(0),
        }
    }

    /// Maakt een instantie van een crashtest-dummy die registreert welke gebeurtenissen hij meemaakt en optioneel panics.
    ///
    pub fn spawn(&self, panic: Panic) -> Instance<'_> {
        Instance { origin: self, panic }
    }

    /// Geeft terug hoe vaak exemplaren van de dummy zijn gekloond.
    pub fn cloned(&self) -> usize {
        self.cloned.load(SeqCst)
    }

    /// Geeft terug hoe vaak instanties van de dummy zijn verwijderd.
    pub fn dropped(&self) -> usize {
        self.dropped.load(SeqCst)
    }

    /// Geeft terug hoe vaak instanties van de dummy hun `query`-lid hebben aangeroepen.
    pub fn queried(&self) -> usize {
        self.queried.load(SeqCst)
    }
}

#[derive(Debug)]
pub struct Instance<'a> {
    origin: &'a CrashTestDummy,
    panic: Panic,
}

#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub enum Panic {
    Never,
    InClone,
    InDrop,
    InQuery,
}

impl Instance<'_> {
    pub fn id(&self) -> usize {
        self.origin.id
    }

    /// Een anonieme vraag, waarvan het resultaat al is gegeven.
    pub fn query<R>(&self, result: R) -> R {
        self.origin.queried.fetch_add(1, SeqCst);
        if self.panic == Panic::InQuery {
            panic!("panic in `query`");
        }
        result
    }
}

impl Clone for Instance<'_> {
    fn clone(&self) -> Self {
        self.origin.cloned.fetch_add(1, SeqCst);
        if self.panic == Panic::InClone {
            panic!("panic in `clone`");
        }
        Self { origin: self.origin, panic: Panic::Never }
    }
}

impl Drop for Instance<'_> {
    fn drop(&mut self) {
        self.origin.dropped.fetch_add(1, SeqCst);
        if self.panic == Panic::InDrop {
            panic!("panic in `drop`");
        }
    }
}

impl PartialOrd for Instance<'_> {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.id().partial_cmp(&other.id())
    }
}

impl Ord for Instance<'_> {
    fn cmp(&self, other: &Self) -> Ordering {
        self.id().cmp(&other.id())
    }
}

impl PartialEq for Instance<'_> {
    fn eq(&self, other: &Self) -> bool {
        self.id().eq(&other.id())
    }
}

impl Eq for Instance<'_> {}