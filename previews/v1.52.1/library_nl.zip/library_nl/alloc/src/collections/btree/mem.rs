use core::intrinsics;
use core::mem;
use core::ptr;

/// Dit vervangt de waarde achter de unieke `v`-referentie door de relevante functie aan te roepen.
///
///
/// Als er een panic optreedt in de `change`-sluiting, wordt het hele proces afgebroken.
#[allow(dead_code)] // Bewaar als illustratie en voor future-gebruik
#[inline]
pub fn take_mut<T>(v: &mut T, change: impl FnOnce(T) -> T) {
    replace(v, |value| (change(value), ()))
}

/// Dit vervangt de waarde achter de unieke `v`-referentie door de relevante functie aan te roepen, en retourneert een onderweg verkregen resultaat.
///
///
/// Als er een panic optreedt in de `change`-sluiting, wordt het hele proces afgebroken.
#[inline]
pub fn replace<T, R>(v: &mut T, change: impl FnOnce(T) -> (T, R)) -> R {
    struct PanicGuard;
    impl Drop for PanicGuard {
        fn drop(&mut self) {
            intrinsics::abort()
        }
    }
    let guard = PanicGuard;
    let value = unsafe { ptr::read(v) };
    let (new_value, ret) = change(value);
    unsafe {
        ptr::write(v, new_value);
    }
    mem::forget(guard);
    ret
}