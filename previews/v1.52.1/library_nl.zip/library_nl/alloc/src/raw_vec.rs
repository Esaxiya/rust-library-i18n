#![unstable(feature = "raw_vec_internals", reason = "implementation detail", issue = "none")]
#![doc(hidden)]

use core::alloc::LayoutError;
use core::cmp;
use core::intrinsics;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::Drop;
use core::ptr::{self, NonNull, Unique};
use core::slice;

use crate::alloc::{handle_alloc_error, Allocator, Global, Layout};
use crate::boxed::Box;
use crate::collections::TryReserveError::{self, *};

#[cfg(test)]
mod tests;

enum AllocInit {
    /// De inhoud van het nieuwe geheugen is niet geïnitialiseerd.
    Uninitialized,
    /// Het nieuwe geheugen wordt gegarandeerd op nul gezet.
    Zeroed,
}

/// Een hulpprogramma op laag niveau voor het ergonomischer toewijzen, opnieuw toewijzen en ongedaan maken van een buffer met geheugen op de heap zonder dat u zich zorgen hoeft te maken over alle betrokken hoekgevallen.
///
/// Dit type is uitstekend geschikt voor het bouwen van uw eigen datastructuren zoals Vec en VecDeque.
/// Vooral:
///
/// * Produceert `Unique::dangling()` op typen van nulformaat.
/// * Produceert `Unique::dangling()` op toewijzingen met lengte nul.
/// * Voorkomt het vrijmaken van `Unique::dangling()`.
/// * Vangt alle overflows op in capaciteitsberekeningen (promoot ze naar "capacity overflow" panics).
/// * Beschermt tegen 32-bits systemen die meer dan isize::MAX bytes toewijzen.
/// * Beschermt tegen het overlopen van uw lengte.
/// * Roept `handle_alloc_error` op voor feilbare toewijzingen.
/// * Bevat een `ptr::Unique` en geeft de gebruiker dus alle gerelateerde voordelen.
/// * Gebruikt het overschot dat wordt geretourneerd door de verdeler om de grootste beschikbare capaciteit te gebruiken.
///
/// Dit type inspecteert op geen enkele manier het geheugen dat het beheert.Wanneer het valt,*zal het* zijn geheugen vrijmaken, maar *zal het* niet * proberen om zijn inhoud te laten vallen.
/// Het is aan de gebruiker van `RawVec` om de feitelijke dingen *die zijn opgeslagen* in een `RawVec` af te handelen.
///
/// Merk op dat het overschot van typen met een grootte van nul altijd oneindig is, dus `capacity()` retourneert altijd `usize::MAX`.
/// Dit betekent dat je voorzichtig moet zijn wanneer je dit type met een `Box<[T]>` omschakelt, aangezien `capacity()` niet de lengte zal opleveren.
///
///
#[allow(missing_debug_implementations)]
pub struct RawVec<T, A: Allocator = Global> {
    ptr: Unique<T>,
    cap: usize,
    alloc: A,
}

impl<T> RawVec<T, Global> {
    /// HACK(Centril): Dit bestaat omdat `#[unstable]` `const fn`s niet hoeven te voldoen aan `min_const_fn` en ze dus ook niet kunnen worden aangeroepen in`min_const_fn`s.
    ///
    /// Als u `RawVec<T>::new` of afhankelijkheden wijzigt, zorg er dan voor dat u niets introduceert dat `min_const_fn` echt zou schenden.
    ///
    /// NOTE: We zouden deze hack kunnen vermijden en de conformiteit met een `#[rustc_force_min_const_fn]`-attribuut kunnen controleren dat conformiteit met `min_const_fn` vereist, maar niet noodzakelijkerwijs het aanroepen ervan in `stable(...) const fn`/gebruikerscode toestaat om `foo` niet in te schakelen wanneer `#[rustc_const_unstable(feature = "foo", issue = "01234")]` aanwezig is.
    ///
    ///
    ///
    ///
    ///
    ///
    pub const NEW: Self = Self::new();

    /// Creëert de grootst mogelijke `RawVec` (op de systeemheap) zonder.
    /// Als `T` een positieve grootte heeft, dan is dit een `RawVec` met capaciteit `0`.
    /// Als `T` de grootte nul heeft, maakt het een `RawVec` met capaciteit `usize::MAX`.
    /// Handig voor het implementeren van uitgestelde toewijzing.
    ///
    pub const fn new() -> Self {
        Self::new_in(Global)
    }

    /// Creëert een `RawVec` (op de systeemheap) met precies de capaciteits-en uitlijnvereisten voor een `[T; capacity]`.
    /// Dit komt overeen met het aanroepen van `RawVec::new` wanneer `capacity` `0` is of `T` de grootte nul heeft.
    /// Merk op dat als `T` de grootte nul heeft, dit betekent dat u *geen* een `RawVec` krijgt met de gevraagde capaciteit.
    ///
    /// # Panics
    ///
    /// Panics als de gevraagde capaciteit groter is dan `isize::MAX` bytes.
    ///
    /// # Aborts
    ///
    /// Wordt afgebroken op OOM.
    ///
    ///
    #[inline]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// Zoals `with_capacity`, maar garandeert dat de buffer op nul wordt gezet.
    #[inline]
    pub fn with_capacity_zeroed(capacity: usize) -> Self {
        Self::with_capacity_zeroed_in(capacity, Global)
    }

    /// Reconstitueert een `RawVec` op basis van een aanwijzer en capaciteit.
    ///
    /// # Safety
    ///
    /// De `ptr` moet worden toegewezen (op de systeemheap) en met de opgegeven `capacity`.
    /// De `capacity` kan niet groter zijn dan `isize::MAX` voor typen met afmetingen.(alleen een probleem op 32-bits systemen).
    /// ZST vectors kan een capaciteit hebben tot `usize::MAX`.
    /// Als de `ptr` en `capacity` afkomstig zijn van een `RawVec`, dan is dit gegarandeerd.
    #[inline]
    pub unsafe fn from_raw_parts(ptr: *mut T, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, capacity, Global) }
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    // Tiny Vecs zijn dom.Ga verder naar:
    // - 8 als de elementgrootte 1 is, omdat elke heap-allocator waarschijnlijk een verzoek van minder dan 8 bytes naar ten minste 8 bytes zal afronden.
    //
    // - 4 als elementen middelgroot zijn (<=1 KiB).
    // - 1 anders, om te voorkomen dat u te veel ruimte verspilt aan zeer korte Vec's.
    const MIN_NON_ZERO_CAP: usize = if mem::size_of::<T>() == 1 {
        8
    } else if mem::size_of::<T>() <= 1024 {
        4
    } else {
        1
    };

    /// Zoals `new`, maar geparametriseerd over de keuze van de allocator voor de geretourneerde `RawVec`.
    ///
    #[rustc_allow_const_fn_unstable(const_fn)]
    pub const fn new_in(alloc: A) -> Self {
        // `cap: 0` betekent "unallocated".typen met een grootte van nul worden genegeerd.
        Self { ptr: Unique::dangling(), cap: 0, alloc }
    }

    /// Zoals `with_capacity`, maar geparametriseerd over de keuze van de allocator voor de geretourneerde `RawVec`.
    ///
    #[inline]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Uninitialized, alloc)
    }

    /// Zoals `with_capacity_zeroed`, maar geparametriseerd over de keuze van de allocator voor de geretourneerde `RawVec`.
    ///
    #[inline]
    pub fn with_capacity_zeroed_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Zeroed, alloc)
    }

    /// Verandert een `Box<[T]>` in een `RawVec<T>`.
    pub fn from_box(slice: Box<[T], A>) -> Self {
        unsafe {
            let (slice, alloc) = Box::into_raw_with_allocator(slice);
            RawVec::from_raw_parts_in(slice.as_mut_ptr(), slice.len(), alloc)
        }
    }

    /// Converteert de volledige buffer naar `Box<[MaybeUninit<T>]>` met de opgegeven `len`.
    ///
    /// Merk op dat dit alle `cap`-wijzigingen die mogelijk zijn uitgevoerd, correct zal reconstrueren.(Zie beschrijving van type voor details.)
    ///
    /// # Safety
    ///
    /// * `len` moet groter zijn dan of gelijk zijn aan de meest recent aangevraagde capaciteit, en
    /// * `len` moet kleiner zijn dan of gelijk zijn aan `self.capacity()`.
    ///
    /// Merk op dat de gevraagde capaciteit en `self.capacity()` kunnen verschillen, aangezien een allocator overbezet kan zijn en een groter geheugenblok kan retourneren dan gevraagd.
    ///
    ///
    pub unsafe fn into_box(self, len: usize) -> Box<[MaybeUninit<T>], A> {
        // Sanity-check de ene helft van de veiligheidsvereiste (we kunnen de andere helft niet controleren).
        debug_assert!(
            len <= self.capacity(),
            "`len` must be smaller than or equal to `self.capacity()`"
        );

        let me = ManuallyDrop::new(self);
        unsafe {
            let slice = slice::from_raw_parts_mut(me.ptr() as *mut MaybeUninit<T>, len);
            Box::from_raw_in(slice, ptr::read(&me.alloc))
        }
    }

    fn allocate_in(capacity: usize, init: AllocInit, alloc: A) -> Self {
        if mem::size_of::<T>() == 0 {
            Self::new_in(alloc)
        } else {
            // We vermijden `unwrap_or_else` hier omdat het de hoeveelheid gegenereerde LLVM IR opzwelt.
            //
            let layout = match Layout::array::<T>(capacity) {
                Ok(layout) => layout,
                Err(_) => capacity_overflow(),
            };
            match alloc_guard(layout.size()) {
                Ok(_) => {}
                Err(_) => capacity_overflow(),
            }
            let result = match init {
                AllocInit::Uninitialized => alloc.allocate(layout),
                AllocInit::Zeroed => alloc.allocate_zeroed(layout),
            };
            let ptr = match result {
                Ok(ptr) => ptr,
                Err(_) => handle_alloc_error(layout),
            };

            Self {
                ptr: unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) },
                cap: Self::capacity_from_bytes(ptr.len()),
                alloc,
            }
        }
    }

    /// Reconstitueert een `RawVec` op basis van een aanwijzer, capaciteit en allocator.
    ///
    /// # Safety
    ///
    /// De `ptr` moet worden toegewezen (via de gegeven allocator `alloc`), en met de gegeven `capacity`.
    /// De `capacity` kan niet groter zijn dan `isize::MAX` voor typen met afmetingen.
    /// (alleen een probleem op 32-bits systemen).
    /// ZST vectors kan een capaciteit hebben tot `usize::MAX`.
    /// Als de `ptr` en `capacity` afkomstig zijn van een `RawVec` gemaakt via `alloc`, dan is dit gegarandeerd.
    ///
    #[inline]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, capacity: usize, alloc: A) -> Self {
        Self { ptr: unsafe { Unique::new_unchecked(ptr) }, cap: capacity, alloc }
    }

    /// Krijgt een onbewerkte aanwijzer naar het begin van de toewijzing.
    /// Merk op dat dit `Unique::dangling()` is als `capacity == 0` of `T` de grootte nul heeft.
    /// In het eerste geval moet u voorzichtig zijn.
    #[inline]
    pub fn ptr(&self) -> *mut T {
        self.ptr.as_ptr()
    }

    /// Krijgt de capaciteit van de toewijzing.
    ///
    /// Dit is altijd `usize::MAX` als `T` de grootte nul heeft.
    #[inline(always)]
    pub fn capacity(&self) -> usize {
        if mem::size_of::<T>() == 0 { usize::MAX } else { self.cap }
    }

    /// Retourneert een gedeelde verwijzing naar de allocator die deze `RawVec` ondersteunt.
    pub fn allocator(&self) -> &A {
        &self.alloc
    }

    fn current_memory(&self) -> Option<(NonNull<u8>, Layout)> {
        if mem::size_of::<T>() == 0 || self.cap == 0 {
            None
        } else {
            // We hebben een toegewezen hoeveelheid geheugen, dus we kunnen runtime-controles omzeilen om onze huidige lay-out te krijgen.
            //
            unsafe {
                let align = mem::align_of::<T>();
                let size = mem::size_of::<T>() * self.cap;
                let layout = Layout::from_size_align_unchecked(size, align);
                Some((self.ptr.cast().into(), layout))
            }
        }
    }

    /// Zorgt ervoor dat de buffer ten minste voldoende ruimte bevat om `len + additional`-elementen te bevatten.
    /// Als het niet al voldoende capaciteit heeft, zal het voldoende ruimte en comfortabele vrije ruimte opnieuw toewijzen om afgeschreven *O*(1) gedrag te krijgen.
    ///
    /// Zal dit gedrag beperken als het zichzelf onnodig naar panic zou leiden.
    ///
    /// Als `len` groter is dan `self.capacity()`, kan het zijn dat hierdoor de gevraagde ruimte niet daadwerkelijk wordt toegewezen.
    /// Dit is niet echt onveilig, maar de onveilige code *jij* schrijft die afhankelijk is van het gedrag van deze functie kan breken.
    ///
    /// Dit is ideaal voor het implementeren van een bulk-push-operatie zoals `extend`.
    ///
    /// # Panics
    ///
    /// Panics als de nieuwe capaciteit groter is dan `isize::MAX` bytes.
    ///
    /// # Aborts
    ///
    /// Wordt afgebroken op OOM.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![feature(raw_vec_internals)]
    /// # extern crate alloc;
    /// # use std::ptr;
    /// # use alloc::raw_vec::RawVec;
    /// struct MyVec<T> {
    ///     buf: RawVec<T>,
    ///     len: usize,
    /// }
    ///
    /// impl<T: Clone> MyVec<T> {
    ///     pub fn push_all(&mut self, elems: &[T]) {
    ///         self.buf.reserve(self.len, elems.len());
    ///         // reserve zou zijn afgebroken of in paniek zijn geraakt als de len groter was dan `isize::MAX`, dus dit is veilig om nu uit te schakelen.
    /////
    ///         for x in elems {
    ///             unsafe {
    ///                 ptr::write(self.buf.ptr().add(self.len), x.clone());
    ///             }
    ///             self.len += 1;
    ///         }
    ///     }
    /// }
    /// # fn main() {
    /// #   let mut vector = MyVec { buf: RawVec::new(), len: 0 };
    /// #   vector.push_all(&[1, 3, 5, 7, 9]);
    /// # }
    /// ```
    ///
    ///
    pub fn reserve(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve(len, additional));
    }

    /// Hetzelfde als `reserve`, maar keert terug bij fouten in plaats van in paniek te raken of af te breken.
    pub fn try_reserve(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) {
            self.grow_amortized(len, additional)
        } else {
            Ok(())
        }
    }

    /// Zorgt ervoor dat de buffer ten minste voldoende ruimte bevat om `len + additional`-elementen te bevatten.
    /// Als dit nog niet het geval is, wordt de minimaal benodigde hoeveelheid geheugen opnieuw toegewezen.
    /// Over het algemeen is dit precies de hoeveelheid geheugen die nodig is, maar in principe is het de allocator vrij om meer terug te geven dan we hebben gevraagd.
    ///
    ///
    /// Als `len` groter is dan `self.capacity()`, kan het zijn dat hierdoor de gevraagde ruimte niet daadwerkelijk wordt toegewezen.
    /// Dit is niet echt onveilig, maar de onveilige code *jij* schrijft die afhankelijk is van het gedrag van deze functie kan breken.
    ///
    /// # Panics
    ///
    /// Panics als de nieuwe capaciteit groter is dan `isize::MAX` bytes.
    ///
    /// # Aborts
    ///
    /// Wordt afgebroken op OOM.
    ///
    ///
    pub fn reserve_exact(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve_exact(len, additional));
    }

    /// Hetzelfde als `reserve_exact`, maar keert terug bij fouten in plaats van in paniek te raken of af te breken.
    pub fn try_reserve_exact(
        &mut self,
        len: usize,
        additional: usize,
    ) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) { self.grow_exact(len, additional) } else { Ok(()) }
    }

    /// Verkleint de toewijzing tot het opgegeven bedrag.
    /// Als het opgegeven bedrag 0 is, wordt de toewijzing feitelijk volledig ongedaan gemaakt.
    ///
    /// # Panics
    ///
    /// Panics als de opgegeven hoeveelheid *groter* is dan de huidige capaciteit.
    ///
    /// # Aborts
    ///
    /// Wordt afgebroken op OOM.
    pub fn shrink_to_fit(&mut self, amount: usize) {
        handle_reserve(self.shrink(amount));
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    /// Geeft terug als de buffer moet groeien om aan de benodigde extra capaciteit te voldoen.
    /// Hoofdzakelijk gebruikt om inlining reserve-oproepen mogelijk te maken zonder inlining `grow`.
    fn needs_to_grow(&self, len: usize, additional: usize) -> bool {
        additional > self.capacity().wrapping_sub(len)
    }

    fn capacity_from_bytes(excess: usize) -> usize {
        debug_assert_ne!(mem::size_of::<T>(), 0);
        excess / mem::size_of::<T>()
    }

    fn set_ptr(&mut self, ptr: NonNull<[u8]>) {
        self.ptr = unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) };
        self.cap = Self::capacity_from_bytes(ptr.len());
    }

    // Deze methode wordt meestal meerdere keren geïnstantieerd.Dus we willen dat het zo klein mogelijk is, om de compilatietijden te verbeteren.
    // Maar we willen ook dat zoveel mogelijk van de inhoud statisch berekenbaar is, om de gegenereerde code sneller te laten werken.
    // Daarom is deze methode zorgvuldig geschreven, zodat alle code die afhankelijk is van `T` erin zit, terwijl zoveel mogelijk code die niet afhankelijk is van `T`, zich in functies bevindt die niet-generiek zijn boven `T`.
    //
    //
    //
    //
    fn grow_amortized(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        // Dit wordt verzekerd door de aanroepcontexten.
        debug_assert!(additional > 0);

        if mem::size_of::<T>() == 0 {
            // Omdat we een capaciteit van `usize::MAX` retourneren wanneer `elem_size` is
            // 0, betekent hier noodzakelijkerwijs dat de `RawVec` overvol is.
            return Err(CapacityOverflow);
        }

        // Helaas kunnen we niets aan deze controles doen.
        let required_cap = len.checked_add(additional).ok_or(CapacityOverflow)?;

        // Dit garandeert een exponentiële groei.
        // De verdubbeling kan niet overlopen omdat `cap <= isize::MAX` en het type `cap` `usize` is.
        let cap = cmp::max(self.cap * 2, required_cap);
        let cap = cmp::max(Self::MIN_NON_ZERO_CAP, cap);

        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` is niet-generiek ten opzichte van `T`.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    // De beperkingen op deze methode zijn vrijwel hetzelfde als die op `grow_amortized`, maar deze methode wordt meestal minder vaak geïnstantieerd, dus het is minder kritisch.
    //
    //
    fn grow_exact(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if mem::size_of::<T>() == 0 {
            // Aangezien we een capaciteit van `usize::MAX` retourneren wanneer de lettergrootte is
            // 0, betekent hier noodzakelijkerwijs dat de `RawVec` overvol is.
            return Err(CapacityOverflow);
        }

        let cap = len.checked_add(additional).ok_or(CapacityOverflow)?;
        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` is niet-generiek ten opzichte van `T`.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    fn shrink(&mut self, amount: usize) -> Result<(), TryReserveError> {
        assert!(amount <= self.capacity(), "Tried to shrink to a larger capacity");

        let (ptr, layout) = if let Some(mem) = self.current_memory() { mem } else { return Ok(()) };
        let new_size = amount * mem::size_of::<T>();

        let ptr = unsafe {
            let new_layout = Layout::from_size_align_unchecked(new_size, layout.align());
            self.alloc.shrink(ptr, layout, new_layout).map_err(|_| TryReserveError::AllocError {
                layout: new_layout,
                non_exhaustive: (),
            })?
        };
        self.set_ptr(ptr);
        Ok(())
    }
}

// Deze functie valt buiten `RawVec` om compilatietijden te minimaliseren.Zie de opmerking boven `RawVec::grow_amortized` voor details.
// (De parameter `A` is niet significant, omdat het aantal verschillende `A`-typen dat in de praktijk wordt gezien, veel kleiner is dan het aantal `T`-typen.)
//
//
#[inline(never)]
fn finish_grow<A>(
    new_layout: Result<Layout, LayoutError>,
    current_memory: Option<(NonNull<u8>, Layout)>,
    alloc: &mut A,
) -> Result<NonNull<[u8]>, TryReserveError>
where
    A: Allocator,
{
    // Controleer hier op de fout om de grootte van `RawVec::grow_*` te minimaliseren.
    let new_layout = new_layout.map_err(|_| CapacityOverflow)?;

    alloc_guard(new_layout.size())?;

    let memory = if let Some((ptr, old_layout)) = current_memory {
        debug_assert_eq!(old_layout.align(), new_layout.align());
        unsafe {
            // De allocator controleert op gelijkheid van uitlijning
            intrinsics::assume(old_layout.align() == new_layout.align());
            alloc.grow(ptr, old_layout, new_layout)
        }
    } else {
        alloc.allocate(new_layout)
    };

    memory.map_err(|_| AllocError { layout: new_layout, non_exhaustive: () })
}

unsafe impl<#[may_dangle] T, A: Allocator> Drop for RawVec<T, A> {
    /// Maakt het geheugen vrij dat eigendom is van de `RawVec`*zonder* te proberen de inhoud te verwijderen.
    fn drop(&mut self) {
        if let Some((ptr, layout)) = self.current_memory() {
            unsafe { self.alloc.deallocate(ptr, layout) }
        }
    }
}

// Centrale functie voor het afhandelen van reservefouten.
#[inline]
fn handle_reserve(result: Result<(), TryReserveError>) {
    match result {
        Err(CapacityOverflow) => capacity_overflow(),
        Err(AllocError { layout, .. }) => handle_alloc_error(layout),
        Ok(()) => { /* yay */ }
    }
}

// We moeten het volgende garanderen:
// * We wijzen nooit `> isize::MAX`-objecten met bytegrootte toe.
// * We overstromen `usize::MAX` niet en wijzen eigenlijk te weinig toe.
//
// Op 64-bit hoeven we alleen maar te controleren op overflow, aangezien het zeker zal mislukken om `> isize::MAX`-bytes toe te wijzen.
// Op 32-bit en 16-bit moeten we hiervoor een extra bewaker toevoegen voor het geval we op een platform draaien dat alle 4GB aan gebruikersruimte kan gebruiken, bijvoorbeeld PAE of x32.
//
//

#[inline]
fn alloc_guard(alloc_size: usize) -> Result<(), TryReserveError> {
    if usize::BITS < 64 && alloc_size > isize::MAX as usize {
        Err(CapacityOverflow)
    } else {
        Ok(())
    }
}

// Eén centrale functie verantwoordelijk voor het melden van capaciteitsoverschrijdingen.
// Dit zorgt ervoor dat de codegeneratie met betrekking tot deze panics minimaal is, aangezien er maar één locatie is die panics is in plaats van een stel in de module.
//
fn capacity_overflow() -> ! {
    panic!("capacity overflow");
}