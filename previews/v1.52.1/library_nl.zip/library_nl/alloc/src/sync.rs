#![stable(feature = "rust1", since = "1.0.0")]

//! Draadveilige verwijzingen voor het tellen van referenties.
//!
//! Zie de [`Arc<T>`][Arc]-documentatie voor meer details.

use core::any::Any;
use core::borrow;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::hint;
use core::intrinsics::abort;
use core::iter;
use core::marker::{PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;
use core::sync::atomic;
use core::sync::atomic::Ordering::{Acquire, Relaxed, Release, SeqCst};

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::rc::is_dangling;
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

/// Een zachte limiet voor het aantal verwijzingen dat naar een `Arc` mag worden gemaakt.
///
/// Als u deze limiet overschrijdt, wordt uw programma afgebroken (hoewel niet noodzakelijk) bij _exactly_ `MAX_REFCOUNT + 1`-referenties.
///
const MAX_REFCOUNT: usize = (isize::MAX) as usize;

#[cfg(not(sanitize = "thread"))]
macro_rules! acquire {
    ($x:expr) => {
        atomic::fence(Acquire)
    };
}

// ThreadSanitizer ondersteunt geen geheugenomheiningen.
// Om vals-positieve rapporten in Arc/Weak-implementatie te voorkomen, gebruikt u in plaats daarvan atoombelastingen voor synchronisatie.
//
#[cfg(sanitize = "thread")]
macro_rules! acquire {
    ($x:expr) => {
        $x.load(Acquire)
    };
}

/// Een veilige referentie-telwijzer.'Arc' staat voor 'Atomically Reference Counted'.
///
/// Het type `Arc<T>` biedt gedeeld eigendom van een waarde van het type `T`, toegewezen in de heap.Het aanroepen van [`clone`][clone] op `Arc` produceert een nieuwe `Arc`-instantie, die verwijst naar dezelfde toewijzing op de heap als de bron `Arc`, terwijl het aantal referenties wordt verhoogd.
/// Wanneer de laatste `Arc`-pointer naar een bepaalde toewijzing wordt vernietigd, wordt de waarde die is opgeslagen in die toewijzing (vaak "inner value" genoemd) ook verwijderd.
///
/// Gedeelde verwijzingen in Rust staan standaard geen mutatie toe, en `Arc` is geen uitzondering: je kunt over het algemeen geen veranderlijke verwijzing krijgen naar iets in een `Arc`.Als u via een `Arc` moet muteren, gebruikt u [`Mutex`][mutex], [`RwLock`][rwlock] of een van de [`Atomic`][atomic]-typen.
///
/// ## Draadveiligheid
///
/// In tegenstelling tot [`Rc<T>`] gebruikt `Arc<T>` atomaire bewerkingen voor het tellen van referenties.Dit betekent dat het draadveilig is.Het nadeel is dat atomaire bewerkingen duurder zijn dan gewone geheugentoegang.Als u geen toewijzingen met verwijzingen tussen threads deelt, overweeg dan om [`Rc<T>`] te gebruiken voor lagere overhead.
/// [`Rc<T>`] is een veilige standaard, omdat de compiler elke poging opvangt om een [`Rc<T>`] tussen threads te verzenden.
/// Een bibliotheek kan echter voor `Arc<T>` kiezen om bibliotheekgebruikers meer flexibiliteit te geven.
///
/// `Arc<T>` zal [`Send`] en [`Sync`] implementeren zolang de `T` [`Send`] en [`Sync`] implementeert.
/// Waarom kunt u geen `T`-type dat niet geschikt is voor schroefdraad in een `Arc<T>` plaatsen om het schroefdraadveilig te maken?In het begin is dit misschien een beetje contra-intuïtief: is het tenslotte niet het punt van `Arc<T>`-threadveiligheid?De sleutel is dit: `Arc<T>` maakt het thread-safe om meerdere eigenaren van dezelfde data te hebben, maar het voegt geen thread-veiligheid toe aan zijn data.
///
/// Overweeg `Arc <` [`RefCell<T>`]`>`.
/// [`RefCell<T>`] is niet [`Sync`], en als `Arc<T>` altijd [`Send`] was, `Arc <` [`RefCell<T>`]`>`zou ook zijn.
/// Maar dan hebben we een probleem:
/// [`RefCell<T>`] is niet draadveilig;het houdt het aantal leningen bij met behulp van niet-atomaire bewerkingen.
///
/// Uiteindelijk betekent dit dat u `Arc<T>` mogelijk moet koppelen met een soort [`std::sync`]-type, meestal [`Mutex<T>`][mutex].
///
/// ## Cycli doorbreken met `Weak`
///
/// De [`downgrade`][downgrade]-methode kan worden gebruikt om een niet-eigenaar [`Weak`]-pointer te maken.Een [`Weak`]-pointer kan worden [`upgrade`][upgrade] naar een `Arc`, maar dit zal [`None`] retourneren als de waarde die is opgeslagen in de toewijzing al is verwijderd.
/// Met andere woorden, `Weak`-aanwijzers houden de waarde binnen de toewijzing niet levend;ze *houden* echter de toewijzing (de ondersteunende opslag voor de waarde) levend.
///
/// Een cyclus tussen `Arc`-pointers zal nooit worden opgeheven.
/// Om deze reden wordt [`Weak`] gebruikt om cycli te doorbreken.Een boom kan bijvoorbeeld sterke `Arc`-aanwijzers hebben van bovenliggende knooppunten naar kinderen, en [`Weak`]-verwijzingen van kinderen terug naar hun ouders.
///
/// # Referenties klonen
///
/// Het creëren van een nieuwe referentie van een bestaande referentie-getelde pointer wordt gedaan met behulp van de `Clone` trait geïmplementeerd voor [`Arc<T>`][Arc] en [`Weak<T>`][Weak].
///
/// ```
/// use std::sync::Arc;
/// let foo = Arc::new(vec![1.0, 2.0, 3.0]);
/// // De twee onderstaande syntaxis zijn equivalent.
/// let a = foo.clone();
/// let b = Arc::clone(&foo);
/// // a, b en foo zijn allemaal bogen die naar dezelfde geheugenlocatie wijzen
/// ```
///
/// ## `Deref` behavior
///
/// `Arc<T>` automatisch dereferenties naar `T` (via de [`Deref`][deref] trait), dus je kunt de methoden van 'T' aanroepen op een waarde van het type `Arc<T>`.Om naamconflicten met de methoden van 'T' te voorkomen, zijn de methoden van `Arc<T>` zelf geassocieerde functies, aangeroepen met [fully qualified syntax]:
///
/// ```
/// use std::sync::Arc;
///
/// let my_arc = Arc::new(());
/// Arc::downgrade(&my_arc);
/// ```
///
/// 'Boog<T>Implementaties van traits zoals `Clone` kunnen ook worden aangeroepen met behulp van volledig gekwalificeerde syntaxis.
/// Sommige mensen geven er de voorkeur aan om volledig gekwalificeerde syntaxis te gebruiken, terwijl anderen liever de syntaxis van method-call gebruiken.
///
/// ```
/// use std::sync::Arc;
///
/// let arc = Arc::new(());
/// // Syntaxis van method-call
/// let arc2 = arc.clone();
/// // Volledig gekwalificeerde syntaxis
/// let arc3 = Arc::clone(&arc);
/// ```
///
/// [`Weak<T>`][Weak] verwijst niet automatisch naar `T`, omdat de innerlijke waarde mogelijk al is verwijderd.
///
/// [`Rc<T>`]: crate::rc::Rc
/// [clone]: Clone::clone
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [atomic]: core::sync::atomic
/// [`Send`]: core::marker::Send
/// [`Sync`]: core::marker::Sync
/// [deref]: core::ops::Deref
/// [downgrade]: Arc::downgrade
/// [upgrade]: Weak::upgrade
/// [`RefCell<T>`]: core::cell::RefCell
/// [`std::sync`]: ../../std/sync/index.html
/// [`Arc::clone(&from)`]: Arc::clone
/// [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
///
/// # Examples
///
/// Een aantal onveranderlijke gegevens delen tussen threads:
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
// Merk op dat we **deze tests hier niet** uitvoeren.
// De windows-builders worden super ongelukkig als een thread de hoofdthread overleeft en vervolgens tegelijkertijd wordt afgesloten (iets loopt vast), dus we vermijden dit gewoon volledig door deze tests niet uit te voeren.
//
//
/// ```no_run
/// use std::sync::Arc;
/// use std::thread;
///
/// let five = Arc::new(5);
///
/// for _ in 0..10 {
///     let five = Arc::clone(&five);
///
///     thread::spawn(move || {
///         println!("{:?}", five);
///     });
/// }
/// ```
///
/// Een veranderlijke [`AtomicUsize`] delen:
///
/// [`AtomicUsize`]: core::sync::atomic::AtomicUsize
///
/// ```no_run
/// use std::sync::Arc;
/// use std::sync::atomic::{AtomicUsize, Ordering};
/// use std::thread;
///
/// let val = Arc::new(AtomicUsize::new(5));
///
/// for _ in 0..10 {
///     let val = Arc::clone(&val);
///
///     thread::spawn(move || {
///         let v = val.fetch_add(1, Ordering::SeqCst);
///         println!("{:?}", v);
///     });
/// }
/// ```
///
/// Zie de [`rc` documentation][rc_examples] voor meer voorbeelden van het tellen van referenties in het algemeen.
///
///
/// [rc_examples]: crate::rc#examples
#[cfg_attr(not(test), rustc_diagnostic_item = "Arc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Arc<T: ?Sized> {
    ptr: NonNull<ArcInner<T>>,
    phantom: PhantomData<ArcInner<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Arc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Arc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Arc<U>> for Arc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Arc<U>> for Arc<T> {}

impl<T: ?Sized> Arc<T> {
    fn from_inner(ptr: NonNull<ArcInner<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut ArcInner<T>) -> Self {
        unsafe { Self::from_inner(NonNull::new_unchecked(ptr)) }
    }
}

/// `Weak` is een versie van [`Arc`] die een niet-eigendomsreferentie bevat naar de beheerde toewijzing.
/// De toewijzing is toegankelijk door [`upgrade`] aan te roepen op de `Weak`-pointer, die een [`Option`]`<`[`Arc`] `retourneert<T>>`.
///
/// Omdat een `Weak`-referentie niet meetelt voor het eigendom, zal het niet voorkomen dat de waarde die is opgeslagen in de allocatie wordt verwijderd, en `Weak` zelf geeft geen garanties dat de waarde nog steeds aanwezig is.
///
/// Het kan dus [`None`] retourneren wanneer [`upgrade`] d.
/// Merk echter op dat een `Weak`-referentie *wel* voorkomt dat de toewijzing zelf (de back-store) wordt ongedaan gemaakt.
///
/// Een `Weak`-aanwijzer is handig om een tijdelijke verwijzing te bewaren naar de toewijzing die wordt beheerd door [`Arc`] zonder te voorkomen dat de innerlijke waarde wordt verwijderd.
/// Het wordt ook gebruikt om circulaire verwijzingen tussen [`Arc`]-aanwijzers te voorkomen, aangezien wederzijdse verwijzingen nooit zouden toestaan dat een van beide [`Arc`] wordt verwijderd.
/// Een boom kan bijvoorbeeld sterke [`Arc`]-aanwijzers hebben van bovenliggende knooppunten naar kinderen, en `Weak`-verwijzingen van kinderen terug naar hun ouders.
///
/// De typische manier om een `Weak`-pointer te verkrijgen, is door [`Arc::downgrade`] aan te roepen.
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
#[stable(feature = "arc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // Dit is een `NonNull` om de grootte van dit type in enums te optimaliseren, maar het is niet noodzakelijk een geldige pointer.
    //
    // `Weak::new` stelt dit in op `usize::MAX` zodat het geen ruimte op de heap hoeft toe te wijzen.
    // Dat is geen waarde die een echte pointer ooit zal hebben, omdat RcBox ten minste 2 uitlijning heeft.
    // Dit is alleen mogelijk als `T: Sized`;niet-formaat `T` bengelt nooit.
    //
    ptr: NonNull<ArcInner<T>>,
}

#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Weak<T> {}
#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

// Dit is repr(C) tot future-proof tegen mogelijke veldherschikking, die anderszins veilige [into|from]_raw() van transmuteerbare innerlijke types zou verstoren.
//
//
#[repr(C)]
struct ArcInner<T: ?Sized> {
    strong: atomic::AtomicUsize,

    // de waarde usize::MAX fungeert als een wachtpost voor tijdelijk "locking" de mogelijkheid om zwakke punten te upgraden of sterke punten te downgraden;dit wordt gebruikt om races in `make_mut` en `get_mut` te vermijden.
    //
    //
    weak: atomic::AtomicUsize,

    data: T,
}

unsafe impl<T: ?Sized + Sync + Send> Send for ArcInner<T> {}
unsafe impl<T: ?Sized + Sync + Send> Sync for ArcInner<T> {}

impl<T> Arc<T> {
    /// Construeert een nieuwe `Arc<T>`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(data: T) -> Arc<T> {
        // Start de telling van de zwakke aanwijzer als 1, wat de zwakke aanwijzer is die wordt vastgehouden door alle sterke wijzers (kinda), zie std/rc.rs voor meer informatie
        //
        let x: Box<_> = box ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        };
        Self::from_inner(Box::leak(x).into())
    }

    /// Construeert een nieuwe `Arc<T>` met een zwakke verwijzing naar zichzelf.
    /// Als u probeert de zwakke referentie te upgraden voordat deze functie retourneert, resulteert dit in een `None`-waarde.
    /// De zwakke referentie kan echter vrij worden gekloond en worden opgeslagen voor gebruik op een later tijdstip.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    ///
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo {
    ///     me: Weak<Foo>,
    /// }
    ///
    /// let foo = Arc::new_cyclic(|me| Foo {
    ///     me: me.clone(),
    /// });
    /// ```
    #[inline]
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Arc<T> {
        // Construeer de binnenste in de "uninitialized"-toestand met een enkele zwakke referentie.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box ArcInner {
            strong: atomic::AtomicUsize::new(0),
            weak: atomic::AtomicUsize::new(1),
            data: mem::MaybeUninit::<T>::uninit(),
        })
        .into();
        let init_ptr: NonNull<ArcInner<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // Het is belangrijk dat we het eigendom van de zwakke aanwijzer niet opgeven, anders kan het geheugen worden vrijgemaakt tegen de tijd dat `data_fn` terugkeert.
        // Als we echt het eigendom zouden willen overdragen, zouden we een extra zwakke aanwijzer voor onszelf kunnen creëren, maar dit zou resulteren in extra updates van de zwakke referentietelling die anders misschien niet nodig zou zijn.
        //
        //
        //
        //
        let data = data_fn(&weak);

        // Nu kunnen we de innerlijke waarde correct initialiseren en onze zwakke referentie omzetten in een sterke referentie.
        //
        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).data), data);

            // Het bovenstaande schrijven naar het dataveld moet zichtbaar zijn voor alle threads die een niet-nul sterke telling waarnemen.
            // Daarom hebben we minimaal "Release"-bestelling nodig om te synchroniseren met de `compare_exchange_weak` in `Weak::upgrade`.
            //
            // "Acquire" bestellen is niet verplicht.
            // Bij het overwegen van het mogelijke gedrag van `data_fn`, hoeven we alleen te kijken naar wat het zou kunnen doen met een verwijzing naar een niet-upgradebare `Weak`:
            //
            // - Het kan de `Weak`*klonen*, waardoor het aantal zwakke referenties toeneemt.
            // - Het kan die klonen laten vallen, waardoor het aantal zwakke referenties afneemt (maar nooit tot nul).
            //
            // Deze bijwerkingen hebben op geen enkele manier invloed op ons en er zijn geen andere bijwerkingen mogelijk met alleen veilige code.
            //
            //
            let prev_value = (*inner).strong.fetch_add(1, Release);
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
        }

        let strong = Arc::from_inner(init_ptr);

        // Sterke referenties zouden gezamenlijk een gedeelde zwakke referentie moeten hebben, dus voer de destructor niet uit voor onze oude zwakke referentie.
        //
        mem::forget(weak);
        strong
    }

    /// Construeert een nieuwe `Arc` met niet-geïnitialiseerde inhoud.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Uitgestelde initialisatie:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Construeert een nieuwe `Arc` met niet-geïnitialiseerde inhoud, waarbij het geheugen wordt gevuld met `0`-bytes.
    ///
    ///
    /// Zie [`MaybeUninit::zeroed`][zeroed] voor voorbeelden van correct en incorrect gebruik van deze methode.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Construeert een nieuwe `Pin<Arc<T>>`.
    /// Als `T` `Unpin` niet implementeert, wordt `data` in het geheugen vastgezet en kan deze niet worden verplaatst.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(data: T) -> Pin<Arc<T>> {
        unsafe { Pin::new_unchecked(Arc::new(data)) }
    }

    /// Construeert een nieuwe `Arc<T>`, die een fout retourneert als de toewijzing mislukt.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::sync::Arc;
    ///
    /// let five = Arc::try_new(5)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new(data: T) -> Result<Arc<T>, AllocError> {
        // Start de telling van de zwakke aanwijzer als 1, wat de zwakke aanwijzer is die wordt vastgehouden door alle sterke wijzers (kinda), zie std/rc.rs voor meer informatie
        //
        let x: Box<_> = Box::try_new(ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        })?;
        Ok(Self::from_inner(Box::leak(x).into()))
    }

    /// Construeert een nieuwe `Arc` met niet-geïnitialiseerde inhoud en geeft een foutmelding als de toewijzing mislukt.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // Uitgestelde initialisatie:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// Construeert een nieuwe `Arc` met niet-geïnitialiseerde inhoud, waarbij het geheugen wordt gevuld met `0`-bytes, en geeft een foutmelding als de toewijzing mislukt.
    ///
    ///
    /// Zie [`MaybeUninit::zeroed`][zeroed] voor voorbeelden van correct en incorrect gebruik van deze methode.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// Retourneert de binnenste waarde als de `Arc` precies één sterke referentie heeft.
    ///
    /// Anders wordt een [`Err`] geretourneerd met dezelfde `Arc` die is doorgegeven.
    ///
    ///
    /// Dit zal lukken, zelfs als er uitstekende zwakke referenties zijn.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new(3);
    /// assert_eq!(Arc::try_unwrap(x), Ok(3));
    ///
    /// let x = Arc::new(4);
    /// let _y = Arc::clone(&x);
    /// assert_eq!(*Arc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if this.inner().strong.compare_exchange(1, 0, Relaxed, Relaxed).is_err() {
            return Err(this);
        }

        acquire!(this.inner().strong);

        unsafe {
            let elem = ptr::read(&this.ptr.as_ref().data);

            // Maak een zwakke aanwijzer om de impliciete sterk-zwakke verwijzing op te ruimen
            let _weak = Weak { ptr: this.ptr };
            mem::forget(this);

            Ok(elem)
        }
    }
}

impl<T> Arc<[T]> {
    /// Construeert een nieuwe atomair-referentie getelde slice met niet-geïnitialiseerde inhoud.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Uitgestelde initialisatie:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe { Arc::from_ptr(Arc::allocate_for_slice(len)) }
    }

    /// Construeert een nieuwe atomair-referentie getelde slice met niet-geïnitialiseerde inhoud, waarbij het geheugen wordt gevuld met `0` bytes.
    ///
    ///
    /// Zie [`MaybeUninit::zeroed`][zeroed] voor voorbeelden van correct en incorrect gebruik van deze methode.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let values = Arc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut ArcInner<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Arc<mem::MaybeUninit<T>> {
    /// Converteert naar `Arc<T>`.
    ///
    /// # Safety
    ///
    /// Net als bij [`MaybeUninit::assume_init`] is het aan de beller om te garanderen dat de innerlijke waarde echt in een geïnitialiseerde staat verkeert.
    ///
    /// Dit aanroepen wanneer de inhoud nog niet volledig is geïnitialiseerd, veroorzaakt onmiddellijk ongedefinieerd gedrag.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Uitgestelde initialisatie:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<T> {
        Arc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Arc<[mem::MaybeUninit<T>]> {
    /// Converteert naar `Arc<[T]>`.
    ///
    /// # Safety
    ///
    /// Net als bij [`MaybeUninit::assume_init`] is het aan de beller om te garanderen dat de innerlijke waarde echt in een geïnitialiseerde staat verkeert.
    ///
    /// Dit aanroepen wanneer de inhoud nog niet volledig is geïnitialiseerd, veroorzaakt onmiddellijk ongedefinieerd gedrag.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Uitgestelde initialisatie:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<[T]> {
        unsafe { Arc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// Verbruikt de `Arc` en retourneert de ingepakte aanwijzer.
    ///
    /// Om een geheugenlek te voorkomen, moet de pointer terug worden geconverteerd naar een `Arc` met behulp van [`Arc::from_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// Biedt een onbewerkte verwijzing naar de gegevens.
    ///
    /// De tellingen worden op geen enkele manier beïnvloed en de `Arc` wordt niet verbruikt.
    /// De aanwijzer is geldig zolang er sterke tellingen in de `Arc` zijn.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let y = Arc::clone(&x);
    /// let x_ptr = Arc::as_ptr(&x);
    /// assert_eq!(x_ptr, Arc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(this.ptr);

        // VEILIGHEID: Dit kan niet door Deref::deref of RcBoxPtr::inner gaan omdat
        // dit is vereist om de herkomst van raw/mut te behouden, zodat bijv
        // `get_mut` kan door de aanwijzer schrijven nadat de Rc is hersteld via `from_raw`.
        unsafe { ptr::addr_of_mut!((*ptr).data) }
    }

    /// Construeert een `Arc<T>` op basis van een onbewerkte pointer.
    ///
    /// De onbewerkte pointer moet eerder zijn geretourneerd door een aanroep naar [`Arc<U>::into_raw`][into_raw], waarbij `U` dezelfde grootte en uitlijning moet hebben als `T`.
    /// Dit is triviaal waar als `U` `T` is.
    /// Merk op dat als `U` niet `T` is maar dezelfde grootte en uitlijning heeft, dit in feite hetzelfde is als het transmuteren van verschillende typen referenties.
    /// Zie [`mem::transmute`][transmute] voor meer informatie over welke beperkingen in dit geval van toepassing zijn.
    ///
    /// De gebruiker van `from_raw` moet ervoor zorgen dat een specifieke waarde van `T` maar één keer wordt verwijderd.
    ///
    /// Deze functie is onveilig omdat oneigenlijk gebruik kan leiden tot onveiligheid van het geheugen, zelfs als de geretourneerde `Arc<T>` nooit wordt benaderd.
    ///
    /// [into_raw]: Arc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    ///
    /// unsafe {
    ///     // Converteer terug naar een `Arc` om lekken te voorkomen.
    ///     let x = Arc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // Verdere oproepen naar `Arc::from_raw(x_ptr)` zouden geheugenonveilig zijn.
    /// }
    ///
    /// // Het geheugen werd vrijgemaakt toen `x` hierboven buiten het bereik viel, dus `x_ptr` bungelt nu!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        unsafe {
            let offset = data_offset(ptr);

            // Keer de offset om om de originele ArcInner te vinden.
            let arc_ptr = (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset));

            Self::from_ptr(arc_ptr)
        }
    }

    /// Maakt een nieuwe [`Weak`]-pointer voor deze toewijzing.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        // Dit Relaxed is OK omdat we de waarde in de CAS hieronder controleren.
        //
        let mut cur = this.inner().weak.load(Relaxed);

        loop {
            // controleer of de zwakke teller momenteel "locked" is;als dat zo is, draai dan.
            if cur == usize::MAX {
                hint::spin_loop();
                cur = this.inner().weak.load(Relaxed);
                continue;
            }

            // NOTE: deze code negeert momenteel de mogelijkheid van overflow
            // naar usize::MAX;in het algemeen moeten zowel Rc als Arc worden aangepast om met overloop om te gaan.
            //

            // In tegenstelling tot Clone(), hebben we dit nodig als Acquire-leesbewerking om te synchroniseren met het schrijven dat afkomstig is van `is_unique`, zodat de gebeurtenissen voorafgaand aan dat schrijven plaatsvinden voordat dit wordt gelezen.
            //
            //
            match this.inner().weak.compare_exchange_weak(cur, cur + 1, Acquire, Relaxed) {
                Ok(_) => {
                    // Zorg ervoor dat we geen bungelende Zwak maken
                    debug_assert!(!is_dangling(this.ptr.as_ptr()));
                    return Weak { ptr: this.ptr };
                }
                Err(old) => cur = old,
            }
        }
    }

    /// Haalt het aantal [`Weak`]-verwijzingen naar deze toewijzing op.
    ///
    /// # Safety
    ///
    /// Deze methode op zichzelf is veilig, maar het correct gebruiken ervan vereist extra zorg.
    /// Een andere thread kan het aantal zwakke punten op elk moment wijzigen, mogelijk ook tussen het aanroepen van deze methode en het reageren op het resultaat.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _weak_five = Arc::downgrade(&five);
    ///
    /// // Deze bewering is deterministisch omdat we de `Arc` of `Weak` niet tussen threads hebben gedeeld.
    /////
    /// assert_eq!(1, Arc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        let cnt = this.inner().weak.load(SeqCst);
        // Als de zwakke telling momenteel is vergrendeld, was de waarde van de telling 0 net voordat de vergrendeling werd aangenomen.
        //
        if cnt == usize::MAX { 0 } else { cnt - 1 }
    }

    /// Haalt het aantal sterke (`Arc`)-verwijzingen naar deze toewijzing.
    ///
    /// # Safety
    ///
    /// Deze methode op zichzelf is veilig, maar het correct gebruiken ervan vereist extra zorg.
    /// Een andere thread kan de sterke telling op elk moment wijzigen, mogelijk ook tussen het aanroepen van deze methode en het reageren op het resultaat.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _also_five = Arc::clone(&five);
    ///
    /// // Deze bewering is deterministisch omdat we de `Arc` niet tussen threads hebben gedeeld.
    /////
    /// assert_eq!(2, Arc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong.load(SeqCst)
    }

    /// Verhoogt het aantal sterke referenties op de `Arc<T>` dat is gekoppeld aan de meegeleverde aanwijzer met één.
    ///
    /// # Safety
    ///
    /// De pointer moet zijn verkregen via `Arc::into_raw` en de bijbehorende `Arc`-instantie moet geldig zijn (bijv
    /// de sterke telling moet ten minste 1) zijn voor de duur van deze methode.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // Deze bewering is deterministisch omdat we de `Arc` niet tussen threads hebben gedeeld.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn increment_strong_count(ptr: *const T) {
        // Behoud Arc, maar raak refcount niet aan door ManuallyDrop in te pakken
        let arc = unsafe { mem::ManuallyDrop::new(Arc::<T>::from_raw(ptr)) };
        // Verhoog nu het opnieuw tellen, maar laat het nieuwe opnieuw tellen ook niet vallen
        let _arc_clone: mem::ManuallyDrop<_> = arc.clone();
    }

    /// Verlaagt het aantal sterke referenties op de `Arc<T>` dat is gekoppeld aan de meegeleverde aanwijzer met één.
    ///
    /// # Safety
    ///
    /// De pointer moet zijn verkregen via `Arc::into_raw` en de bijbehorende `Arc`-instantie moet geldig zijn (bijv
    /// de sterke telling moet ten minste 1) zijn bij het aanroepen van deze methode.
    /// Deze methode kan worden gebruikt om de laatste `Arc` en back-upopslag vrij te geven, maar **mag niet** worden aangeroepen nadat de laatste `Arc` is vrijgegeven.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // Die beweringen zijn deterministisch omdat we de `Arc` niet tussen threads hebben gedeeld.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    ///     Arc::decrement_strong_count(ptr);
    ///     assert_eq!(1, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn decrement_strong_count(ptr: *const T) {
        unsafe { mem::drop(Arc::from_raw(ptr)) };
    }

    #[inline]
    fn inner(&self) -> &ArcInner<T> {
        // Deze onveiligheid is oké, want zolang deze boog leeft, zijn we er zeker van dat de binnenste wijzer geldig is.
        // Bovendien weten we dat de `ArcInner`-structuur zelf `Sync` is, omdat de interne data ook `Sync` is, dus we lenen een onveranderlijke pointer naar deze inhoud.
        //
        //
        //
        unsafe { self.ptr.as_ref() }
    }

    // Niet-inlined deel van `drop`.
    #[inline(never)]
    unsafe fn drop_slow(&mut self) {
        // Vernietig de gegevens op dit moment, ook al maken we de boxtoewijzing zelf misschien niet vrij (er kunnen nog steeds zwakke punten rondslingeren).
        //
        unsafe { ptr::drop_in_place(Self::get_mut_unchecked(self)) };

        // Laat de zwakke scheidsrechter vallen die gezamenlijk wordt vastgehouden door alle sterke referenties
        drop(Weak { ptr: self.ptr });
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// Geeft `true` terug als de twee `Arc`s naar dezelfde toewijzing wijzen (in een ader vergelijkbaar met [`ptr::eq`]).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let same_five = Arc::clone(&five);
    /// let other_five = Arc::new(5);
    ///
    /// assert!(Arc::ptr_eq(&five, &same_five));
    /// assert!(!Arc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: ?Sized> Arc<T> {
    /// Wijst een `ArcInner<T>` toe met voldoende ruimte voor een mogelijk niet-gedimensioneerde innerlijke waarde waar de waarde de opgegeven lay-out heeft.
    ///
    /// De functie `mem_to_arcinner` wordt aangeroepen met de datapointer en moet een (mogelijk dikke)-pointer teruggeven voor de `ArcInner<T>`.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> *mut ArcInner<T> {
        // Bereken de lay-out met behulp van de gegeven waardelay-out.
        // Voorheen werd de lay-out berekend op de uitdrukking `&*(ptr as* const ArcInner<T>)`, maar dit creëerde een verkeerd uitgelijnde referentie (zie #54908).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Arc::try_allocate_for_layout(value_layout, allocate, mem_to_arcinner)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// Wijst een `ArcInner<T>` toe met voldoende ruimte voor een mogelijk niet-gedimensioneerde innerlijke waarde waarbij de waarde de opgegeven lay-out heeft, en geeft een foutmelding als de toewijzing mislukt.
    ///
    ///
    /// De functie `mem_to_arcinner` wordt aangeroepen met de datapointer en moet een (mogelijk dikke)-pointer teruggeven voor de `ArcInner<T>`.
    ///
    ///
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> Result<*mut ArcInner<T>, AllocError> {
        // Bereken de lay-out met behulp van de gegeven waardelay-out.
        // Voorheen werd de lay-out berekend op de uitdrukking `&*(ptr as* const ArcInner<T>)`, maar dit creëerde een verkeerd uitgelijnde referentie (zie #54908).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();

        let ptr = allocate(layout)?;

        // Initialiseer de ArcInner
        let inner = mem_to_arcinner(ptr.as_non_null_ptr().as_ptr());
        debug_assert_eq!(unsafe { Layout::for_value(&*inner) }, layout);

        unsafe {
            ptr::write(&mut (*inner).strong, atomic::AtomicUsize::new(1));
            ptr::write(&mut (*inner).weak, atomic::AtomicUsize::new(1));
        }

        Ok(inner)
    }

    /// Wijst een `ArcInner<T>` toe met voldoende ruimte voor een niet-bemeten innerlijke waarde.
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut ArcInner<T> {
        // Wijs toe aan de `ArcInner<T>` met behulp van de opgegeven waarde.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut ArcInner<T>).set_ptr_value(mem) as *mut ArcInner<T>,
            )
        }
    }

    fn from_box(v: Box<T>) -> Arc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // Kopieer de waarde als bytes
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).data as *mut _ as *mut u8,
                value_size,
            );

            // Maak de toewijzing vrij zonder de inhoud ervan te laten vallen
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Arc<[T]> {
    /// Wijst een `ArcInner<[T]>` toe met de opgegeven lengte.
    unsafe fn allocate_for_slice(len: usize) -> *mut ArcInner<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut ArcInner<[T]>,
            )
        }
    }

    /// Kopieer elementen van slice naar nieuw toegewezen Arc <\[T\]>
    ///
    /// Onveilig omdat de beller eigenaar moet worden of `T: Copy` moet binden.
    unsafe fn copy_from_slice(v: &[T]) -> Arc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());

            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).data as *mut [T] as *mut T, v.len());

            Self::from_ptr(ptr)
        }
    }

    /// Construeert een `Arc<[T]>` op basis van een iterator waarvan bekend is dat deze een bepaalde grootte heeft.
    ///
    /// Gedrag is niet gedefinieerd als de maat verkeerd is.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Arc<[T]> {
        // Panic bewaken tijdens het klonen van T-elementen.
        // In het geval van een panic worden elementen die in de nieuwe ArcInner zijn geschreven, verwijderd en wordt het geheugen vrijgemaakt.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // Wijzer naar eerste element
            let elems = &mut (*ptr).data as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // Alles duidelijk.Vergeet de bewaker zodat hij de nieuwe ArcInner niet bevrijdt.
            mem::forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// Specialisatie trait gebruikt voor `From<&[T]>`.
trait ArcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Arc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Arc<T> {
    /// Maakt een kloon van de `Arc`-aanwijzer.
    ///
    /// Dit creëert een andere aanwijzer naar dezelfde toewijzing, waardoor het aantal sterke referenties toeneemt.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let _ = Arc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Arc<T> {
        // Het gebruik van een ontspannen volgorde is hier in orde, omdat kennis van de originele referentie voorkomt dat andere threads het object ten onrechte verwijderen.
        //
        // Zoals uitgelegd in de [Boost documentation][1], kan het verhogen van de referentieteller altijd worden gedaan met memory_order_relaxed: nieuwe referenties naar een object kunnen alleen worden gevormd op basis van een bestaande referentie, en het doorgeven van een bestaande referentie van de ene thread naar de andere moet al de vereiste synchronisatie opleveren.
        //
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        //
        //
        //
        //
        //
        let old_size = self.inner().strong.fetch_add(1, Relaxed);

        // We moeten echter oppassen voor massale heropnames voor het geval iemand Arcs 'mem: : vergeet'.
        // Als we dit niet doen, kan de telling overlopen en zullen gebruikers-after free gebruiken.
        // We verzadigen racistisch tot `isize::MAX` in de veronderstelling dat er geen ~2 miljard threads zijn die het aantal referenties in één keer verhogen.
        //
        // Deze branch zal nooit in een realistisch programma worden opgenomen.
        //
        // We breken af omdat zo'n programma ongelooflijk gedegenereerd is, en we geven er niet om het te ondersteunen.
        //
        //
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Arc<T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        &self.inner().data
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Arc<T> {}

impl<T: Clone> Arc<T> {
    /// Maakt een veranderlijke verwijzing naar de gegeven `Arc`.
    ///
    /// Als er andere `Arc`-of [`Weak`]-verwijzingen zijn naar dezelfde toewijzing, dan zal `make_mut` een nieuwe toewijzing creëren en [`clone`][clone] aanroepen op de innerlijke waarde om uniek eigendom te garanderen.
    /// Dit wordt ook wel clone-on-write genoemd.
    ///
    /// Merk op dat dit verschilt van het gedrag van [`Rc::make_mut`] dat alle resterende `Weak`-pointers loskoppelt.
    ///
    /// Zie ook [`get_mut`][get_mut], die eerder zal mislukken dan klonen.
    ///
    /// [clone]: Clone::clone
    /// [get_mut]: Arc::get_mut
    /// [`Rc::make_mut`]: super::rc::Rc::make_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut data = Arc::new(5);
    ///
    /// *Arc::make_mut(&mut data) += 1;         // Zal niets klonen
    /// let mut other_data = Arc::clone(&data); // Zal geen interne gegevens klonen
    /// *Arc::make_mut(&mut data) += 1;         // Kloneert innerlijke gegevens
    /// *Arc::make_mut(&mut data) += 1;         // Zal niets klonen
    /// *Arc::make_mut(&mut other_data) *= 2;   // Zal niets klonen
    ///
    /// // Nu wijzen `data` en `other_data` naar verschillende toewijzingen.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        // Merk op dat we zowel een sterke referentie als een zwakke referentie hebben.
        // Het vrijgeven van alleen onze sterke referentie zal er op zichzelf niet toe leiden dat de toewijzing van de herinnering ongedaan wordt gemaakt.
        //
        // Gebruik Acquire om er zeker van te zijn dat we alle schrijfbewerkingen naar `weak` zien die plaatsvinden voordat de release naar `strong` schrijft (dwz afneemt).
        // Omdat we een zwakke telling hebben, is er geen kans dat de ArcInner zelf kan worden opgeheven.
        //
        //
        //
        if this.inner().strong.compare_exchange(1, 0, Acquire, Relaxed).is_err() {
            // Er bestaat nog een sterke aanwijzer, dus we moeten klonen.
            // Wijs vooraf geheugen toe om de gekloonde waarde rechtstreeks te kunnen schrijven.
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = arc.assume_init();
            }
        } else if this.inner().weak.load(Relaxed) != 1 {
            // Ontspannen volstaat in het bovenstaande omdat dit in wezen een optimalisatie is: we racen altijd met het laten vallen van zwakke punten.
            // In het ergste geval krijgen we onnodig een nieuwe Arc toegewezen.
            //

            // We hebben de laatste sterke scheidsrechter verwijderd, maar er zijn nog meer zwakke scheidsrechters over.
            // We verplaatsen de inhoud naar een nieuwe Arc en maken de andere zwakke scheidsrechters ongeldig.
            //

            // Merk op dat het niet mogelijk is dat het lezen van `weak` usize::MAX oplevert (dwz vergrendeld), aangezien de zwakke telling alleen kan worden vergrendeld door een thread met een sterke referentie.
            //
            //

            // Materialiseer onze eigen impliciete zwakke aanwijzer, zodat deze de ArcInner indien nodig kan opschonen.
            //
            let _weak = Weak { ptr: this.ptr };

            // Kan gewoon de gegevens stelen, het enige dat overblijft zijn Weaks
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);
                ptr::write(this, arc.assume_init());
            }
        } else {
            // Wij waren de enige referentie van beide soorten;stoot het sterke aantal scheidsrechters weer op.
            //
            this.inner().strong.store(1, Release);
        }

        // Net als bij `get_mut()` is de onveiligheid ok, omdat onze referentie óf uniek was om mee te beginnen, óf er een werd bij het klonen van de inhoud.
        //
        unsafe { Self::get_mut_unchecked(this) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// Retourneert een veranderlijke verwijzing naar de opgegeven `Arc`, als er geen andere `Arc`-of [`Weak`]-verwijzingen naar dezelfde toewijzing zijn.
    ///
    ///
    /// Geeft anders [`None`] terug, omdat het niet veilig is om een gedeelde waarde te muteren.
    ///
    /// Zie ook [`make_mut`][make_mut], die [`clone`][clone] de innerlijke waarde zal geven als er andere aanwijzingen zijn.
    ///
    /// [make_mut]: Arc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(3);
    /// *Arc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Arc::clone(&x);
    /// assert!(Arc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if this.is_unique() {
            // Deze onveiligheid is oké omdat we er zeker van zijn dat de teruggezonden aanwijzer de *enige* aanwijzer is die ooit zal worden teruggestuurd naar T.
            // Onze referentietelling is op dit punt gegarandeerd 1, en we vereisten dat de Arc zelf `mut` was, dus we retourneren de enige mogelijke verwijzing naar de innerlijke gegevens.
            //
            //
            //
            unsafe { Some(Arc::get_mut_unchecked(this)) }
        } else {
            None
        }
    }

    /// Retourneert een veranderlijke verwijzing naar de opgegeven `Arc`, zonder enige controle.
    ///
    /// Zie ook [`get_mut`], die veilig is en de juiste controles uitvoert.
    ///
    /// [`get_mut`]: Arc::get_mut
    ///
    /// # Safety
    ///
    /// Alle andere `Arc`-of [`Weak`]-verwijzingen naar dezelfde toewijzing mogen niet worden verwijderd voor de duur van de geretourneerde lening.
    ///
    /// Dit is triviaal het geval als dergelijke verwijzingen niet bestaan, bijvoorbeeld direct na `Arc::new`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(String::new());
    /// unsafe {
    ///     Arc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // We zorgen ervoor dat *niet* een referentie wordt gemaakt die de "count"-velden dekt, omdat dit een alias zou zijn met gelijktijdige toegang tot de referentietellingen (bijv.
        // door `Weak`).
        unsafe { &mut (*this.ptr.as_ptr()).data }
    }

    /// Bepaal of dit de unieke verwijzing is (inclusief zwakke verwijzingen) naar de onderliggende gegevens.
    ///
    ///
    /// Merk op dat hiervoor het vergrendelen van de zwakke ref-telling vereist is.
    fn is_unique(&mut self) -> bool {
        // vergrendel het aantal zwakke wijzers als we de enige zwakke wijzerhouder lijken te zijn.
        //
        // Het verwervingslabel hier zorgt voor een 'happen-before'-relatie met alle schrijfbewerkingen naar `strong` (in het bijzonder in `Weak::upgrade`) voorafgaand aan het verlagen van de `weak`-telling (via `Weak::drop`, die release gebruikt).
        // Als de geüpgradede zwakke ref nooit is verwijderd, zal de CAS hier mislukken, dus het kan ons niet schelen om te synchroniseren.
        //
        //
        //
        if self.inner().weak.compare_exchange(1, usize::MAX, Acquire, Relaxed).is_ok() {
            // Dit moet een `Acquire` zijn om te synchroniseren met het verlagen van de `strong`-teller in `drop`-de enige toegang die plaatsvindt wanneer een van de andere dan de laatste referentie wordt verwijderd.
            //
            //
            let unique = self.inner().strong.load(Acquire) == 1;

            // De release die hier schrijft, wordt gesynchroniseerd met het lezen in `downgrade`, waardoor effectief wordt voorkomen dat het bovenstaande lezen van `strong` na het schrijven plaatsvindt.
            //
            //
            self.inner().weak.store(1, Release); // laat het slot los
            unique
        } else {
            false
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Arc<T> {
    /// Laat de `Arc` vallen.
    ///
    /// Dit verlaagt het aantal sterke referenties.
    /// Als het aantal sterke referenties nul bereikt, zijn de enige andere referenties (indien aanwezig) [`Weak`], dus we `drop` de innerlijke waarde.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Arc::new(Foo);
    /// let foo2 = Arc::clone(&foo);
    ///
    /// drop(foo);    // Drukt niets af
    /// drop(foo2);   // Drukt "dropped!" af
    /// ```
    #[inline]
    fn drop(&mut self) {
        // Omdat `fetch_sub` al atomair is, hoeven we niet te synchroniseren met andere threads, tenzij we het object gaan verwijderen.
        // Dezelfde logica is van toepassing op de onderstaande `fetch_sub` op de `weak`-telling.
        //
        if self.inner().strong.fetch_sub(1, Release) != 1 {
            return;
        }

        // Dit hekwerk is nodig om herschikking van het gebruik van de gegevens en verwijdering van de gegevens te voorkomen.
        // Omdat het is gemarkeerd met `Release`, wordt het afnemen van de referentietelling gesynchroniseerd met deze `Acquire`-afrastering.
        // Dit betekent dat het gebruik van de gegevens plaatsvindt voordat de referentietelling wordt verlaagd, wat gebeurt vóór deze afrastering, wat gebeurt vóór het verwijderen van de gegevens.
        //
        // Zoals uitgelegd in de [Boost documentation][1],
        //
        // > Het is belangrijk om elke mogelijke toegang tot het object in één af te dwingen
        // > thread (via een bestaande referentie) om *te gebeuren voordat* wordt verwijderd
        // > het object in een andere draad.Dit wordt bereikt door een "release"
        // > bewerking na het verwijderen van een referentie (elke toegang tot het object
        // > via deze verwijzing moet duidelijk eerder zijn gebeurd), en een
        // > "acquire" bewerking voordat u het object verwijdert.
        //
        // In het bijzonder, hoewel de inhoud van een Arc meestal onveranderlijk is, is het mogelijk om innerlijke schrijfacties te hebben naar zoiets als een Mutex<T>.
        // Aangezien een Mutex niet wordt opgehaald wanneer deze wordt verwijderd, kunnen we niet vertrouwen op de synchronisatielogica om schrijfacties in thread A zichtbaar te maken voor een destructor die in thread B draait.
        //
        //
        // Merk ook op dat de Acquire-afrastering hier waarschijnlijk kan worden vervangen door een Acquire-belasting, die de prestaties in zeer moeilijke situaties zou kunnen verbeteren.Zie [2].
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        // [2]: (https://github.com/rust-lang/rust/pull/41714)
        //
        //
        //
        //
        //
        //
        //
        acquire!(self.inner().strong);

        unsafe {
            self.drop_slow();
        }
    }
}

impl Arc<dyn Any + Send + Sync> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// Probeer de `Arc<dyn Any + Send + Sync>` neer te halen tot een concreet type.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::sync::Arc;
    ///
    /// fn print_if_string(value: Arc<dyn Any + Send + Sync>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Arc::new(my_string));
    /// print_if_string(Arc::new(0i8));
    /// ```
    pub fn downcast<T>(self) -> Result<Arc<T>, Self>
    where
        T: Any + Send + Sync + 'static,
    {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<ArcInner<T>>();
            mem::forget(self);
            Ok(Arc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T> Weak<T> {
    /// Construeert een nieuwe `Weak<T>`, zonder geheugen toe te wijzen.
    /// [`upgrade`] aanroepen voor de retourwaarde geeft altijd [`None`].
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut ArcInner<T>).expect("MAX is not 0") }
    }
}

/// Helper-type om toegang te krijgen tot de referentietellingen zonder beweringen over het gegevensveld te doen.
///
struct WeakInner<'a> {
    weak: &'a atomic::AtomicUsize,
    strong: &'a atomic::AtomicUsize,
}

impl<T: ?Sized> Weak<T> {
    /// Geeft een onbewerkte pointer terug naar het object `T` waarnaar door deze `Weak<T>` wordt verwezen.
    ///
    /// De aanwijzer is alleen geldig als er sterke referenties zijn.
    /// De aanwijzer kan bungelen, niet uitgelijnd of anders zelfs [`null`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::ptr;
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// // Beide wijzen naar hetzelfde object
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // De sterke hier houdt het in leven, dus we hebben nog steeds toegang tot het object.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // Maar nu niet meer.
    /// // We kunnen weak.as_ptr() doen, maar toegang tot de aanwijzer zou tot ongedefinieerd gedrag leiden.
    /// // assert_eq! ("hallo", onveilige {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // Als de wijzer bungelt, sturen we de schildwacht direct terug.
            // Dit kan geen geldig payload-adres zijn, aangezien de payload minstens zo uitgelijnd is als ArcInner (usize).
            ptr as *const T
        } else {
            // VEILIGHEID: als is_dangling false retourneert, kan de pointer worden ontkoppeld.
            // De payload kan op dit punt worden verlaagd en we moeten de herkomst behouden, dus gebruik onbewerkte pointermanipulatie.
            //
            unsafe { ptr::addr_of_mut!((*ptr).data) }
        }
    }

    /// Verbruikt de `Weak<T>` en verandert deze in een onbewerkte aanwijzer.
    ///
    /// Dit zet de zwakke aanwijzer om in een onbewerkte aanwijzer, terwijl het eigendom van één zwakke referentie behouden blijft (het zwakke aantal wordt niet gewijzigd door deze bewerking).
    /// Het kan weer worden omgezet in de `Weak<T>` met [`from_raw`].
    ///
    /// Dezelfde beperkingen voor toegang tot het doel van de aanwijzer als bij [`as_ptr`] zijn van toepassing.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Arc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Arc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// Converteert een eerder door [`into_raw`] gemaakte onbewerkte pointer terug naar `Weak<T>`.
    ///
    /// Dit kan worden gebruikt om veilig een sterke referentie te krijgen (door later [`upgrade`] aan te roepen) of om de zwakke telling ongedaan te maken door de `Weak<T>` te laten vallen.
    ///
    /// Het neemt eigendom van één zwakke referentie (met uitzondering van de pointers gemaakt door [`new`], aangezien deze niets bezitten; de methode werkt er nog steeds op).
    ///
    /// # Safety
    ///
    /// De aanwijzer moet afkomstig zijn van de [`into_raw`] en moet nog steeds zijn potentieel zwakke referentie bezitten.
    ///
    /// Het is toegestaan dat de sterke telling 0 is op het moment dat dit wordt aangeroepen.
    /// Desalniettemin neemt dit het eigendom over van één zwakke referentie die momenteel wordt weergegeven als een onbewerkte pointer (de zwakke telling wordt niet gewijzigd door deze bewerking) en daarom moet het worden gepaard met een eerdere aanroep naar [`into_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    ///
    /// let raw_1 = Arc::downgrade(&strong).into_raw();
    /// let raw_2 = Arc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Arc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Arc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // Verlaag de laatste zwakke telling.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`new`]: Weak::new
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`forget`]: std::mem::forget
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // Zie Weak::as_ptr voor context over hoe de invoerpointer wordt afgeleid.

        let ptr = if is_dangling(ptr as *mut T) {
            // Dit is een bungelende Zwakke.
            ptr as *mut ArcInner<T>
        } else {
            // Anders zijn we er zeker van dat de aanwijzer afkomstig was van een niet-verwarrende Weak.
            // VEILIGHEID: data_offset is veilig om aan te roepen, aangezien ptr verwijst naar een echte (mogelijk weggelaten) T.
            let offset = unsafe { data_offset(ptr) };
            // We keren dus de offset om om de hele RcBox te krijgen.
            // VEILIGHEID: de aanwijzer is afkomstig van een zwakke, dus deze offset is veilig.
            unsafe { (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // VEILIGHEID: we hebben nu de originele Weak-aanwijzer hersteld, dus we kunnen de Weak creëren.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }
}

impl<T: ?Sized> Weak<T> {
    /// Pogingen om de `Weak`-pointer te upgraden naar een [`Arc`], waardoor het laten vallen van de innerlijke waarde wordt vertraagd als dit lukt.
    ///
    ///
    /// Geeft [`None`] terug als de innerlijke waarde sindsdien is verwijderd.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    ///
    /// let strong_five: Option<Arc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // Vernietig alle sterke punten.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Arc<T>> {
        // We gebruiken een CAS-lus om de sterke telling te verhogen in plaats van een fetch_add, aangezien deze functie de referentietelling nooit van nul naar één zou moeten brengen.
        //
        //
        let inner = self.inner()?;

        // Ontspannen belasting omdat elke schrijfwijze van 0 die we kunnen waarnemen het veld in een permanent nul-toestand laat (dus een "stale"-lezing van 0 is prima), en elke andere waarde wordt bevestigd via de CAS hieronder.
        //
        //
        //
        let mut n = inner.strong.load(Relaxed);

        loop {
            if n == 0 {
                return None;
            }

            // Zie opmerkingen in `Arc::clone` voor waarom we dit doen (voor `mem::forget`).
            if n > MAX_REFCOUNT {
                abort();
            }

            // Relaxed is prima voor het geval van mislukking, omdat we geen verwachtingen hebben over de nieuwe staat.
            // Acquire is nodig om het succesgeval te synchroniseren met `Arc::new_cyclic`, wanneer de innerlijke waarde kan worden geïnitialiseerd nadat `Weak`-referenties al zijn gemaakt.
            // In dat geval verwachten we de volledig geïnitialiseerde waarde te observeren.
            //
            match inner.strong.compare_exchange_weak(n, n + 1, Acquire, Relaxed) {
                Ok(_) => return Some(Arc::from_inner(self.ptr)), // null hierboven aangevinkt
                Err(old) => n = old,
            }
        }
    }

    /// Hiermee wordt het aantal sterke (`Arc`)-aanwijzers opgehaald dat naar deze toewijzing verwijst.
    ///
    /// Als `self` is gemaakt met [`Weak::new`], retourneert dit 0.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong.load(SeqCst) } else { 0 }
    }

    /// Geeft een benadering van het aantal `Weak`-pointers dat naar deze toewijzing verwijst.
    ///
    /// Als `self` is gemaakt met [`Weak::new`], of als er geen overgebleven sterke punten zijn, levert dit 0 op.
    ///
    /// # Accuracy
    ///
    /// Vanwege implementatiedetails kan de geretourneerde waarde 1 afwijken in beide richtingen wanneer andere threads een `Arc` of`Weak` manipuleren die naar dezelfde toewijzing wijzen.
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                let weak = inner.weak.load(SeqCst);
                let strong = inner.strong.load(SeqCst);
                if strong == 0 {
                    0
                } else {
                    // Omdat we hebben waargenomen dat er ten minste één sterke aanwijzer was na het lezen van de zwakke telling, weten we dat de impliciete zwakke referentie (aanwezig wanneer er sterke referenties bestaan) er nog steeds was toen we de zwakke telling observeerden, en kunnen deze daarom veilig aftrekken.
                    //
                    //
                    //
                    //
                    weak - 1
                }
            })
            .unwrap_or(0)
    }

    /// Geeft `None` terug als de aanwijzer bungelt en er geen toegewezen `ArcInner` is (dwz wanneer deze `Weak` is gemaakt door `Weak::new`).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // We zorgen ervoor dat *niet* een referentie wordt gemaakt die het "data"-veld dekt, aangezien het veld gelijktijdig kan worden gemuteerd (als bijvoorbeeld de laatste `Arc` wordt verwijderd, wordt het dataveld op zijn plaats neergezet).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// Geeft `true` terug als de twee `Zwakke`s naar dezelfde toewijzing wijzen (vergelijkbaar met [`ptr::eq`]), of als beide niet naar een toewijzing verwijzen (omdat ze zijn gemaakt met `Weak::new()`).
    ///
    ///
    /// # Notes
    ///
    /// Aangezien dit pointers vergelijkt, betekent dit dat `Weak::new()` aan elkaar gelijk zal zijn, ook al verwijzen ze niet naar enige toewijzing.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let first_rc = Arc::new(5);
    /// let first = Arc::downgrade(&first_rc);
    /// let second = Arc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(5);
    /// let third = Arc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// `Weak::new`.
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(());
    /// let third = Arc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// Maakt een kloon van de `Weak`-aanwijzer die naar dezelfde toewijzing verwijst.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let weak_five = Arc::downgrade(&Arc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        let inner = if let Some(inner) = self.inner() {
            inner
        } else {
            return Weak { ptr: self.ptr };
        };
        // Zie opmerkingen in Arc::clone() voor waarom dit ontspannen is.
        // Dit kan een fetch_add gebruiken (waarbij de vergrendeling wordt genegeerd) omdat de zwakke telling alleen is vergrendeld waar *geen andere* zwakke punten bestaan.
        //
        // (In dat geval kunnen we deze code dus niet uitvoeren).
        let old_size = inner.weak.fetch_add(1, Relaxed);

        // Zie opmerkingen in Arc::clone() voor waarom we dit doen (voor mem::forget).
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// Construeert een nieuwe `Weak<T>`, zonder geheugen toe te wijzen.
    /// [`upgrade`] aanroepen voor de retourwaarde geeft altijd [`None`].
    ///
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// Laat de `Weak`-aanwijzer vallen.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Arc::new(Foo);
    /// let weak_foo = Arc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // Drukt niets af
    /// drop(foo);        // Drukt "dropped!" af
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        // Als we erachter komen dat we de laatste zwakke aanwijzer waren, is het tijd om de toewijzing van de gegevens volledig ongedaan te maken.Zie de discussie in Arc::drop() over de geheugenvolgorde
        //
        // Het is hier niet nodig om de vergrendelde status te controleren, omdat de zwakke telling alleen kan worden vergrendeld als er precies één zwakke ref was, wat betekent dat de drop pas daarna op die resterende zwakke ref kan lopen, wat alleen kan gebeuren nadat de vergrendeling is vrijgegeven.
        //
        //
        //
        //
        //
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        if inner.weak.fetch_sub(1, Release) == 1 {
            acquire!(inner.weak);
            unsafe { Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr())) }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait ArcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Arc<T>) -> bool;
    fn ne(&self, other: &Arc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    default fn eq(&self, other: &Arc<T>) -> bool {
        **self == **other
    }
    #[inline]
    default fn ne(&self, other: &Arc<T>) -> bool {
        **self != **other
    }
}

/// We doen deze specialisatie hier, en niet als een algemenere optimalisatie op `&T`, omdat het anders kosten zou toevoegen aan alle gelijkheidscontroles op refs.
/// We nemen aan dat `Arc`s worden gebruikt om grote waarden op te slaan, die langzaam te klonen zijn, maar ook zwaar om te controleren op gelijkheid, waardoor deze kosten zich gemakkelijker terugverdienen.
///
/// Het is ook waarschijnlijker dat er twee `Arc`-klonen zijn, die naar dezelfde waarde wijzen, dan twee `&T`s.
///
/// We kunnen dit alleen doen als `T: Eq` als een `PartialEq` opzettelijk irreflexief is.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + crate::rc::MarkerEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        Arc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        !Arc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Arc<T> {
    /// Gelijkheid voor twee `Arc`s.
    ///
    /// Twee `Arc`s zijn gelijk als hun innerlijke waarden gelijk zijn, zelfs als ze in verschillende toewijzingen zijn opgeslagen.
    ///
    /// Als `T` ook `Eq` implementeert (wat reflexiviteit van gelijkheid impliceert), zijn twee `Arc`s die naar dezelfde toewijzing wijzen altijd gelijk.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five == Arc::new(5));
    /// ```
    ///
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::eq(self, other)
    }

    /// Ongelijkheid voor twee `Arc`s.
    ///
    /// Twee `Arc`s zijn ongelijk als hun innerlijke waarden ongelijk zijn.
    ///
    /// Als `T` ook `Eq` implementeert (wat reflexiviteit van gelijkheid impliceert), zijn twee `Arc`s die naar dezelfde waarde wijzen nooit ongelijk.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five != Arc::new(6));
    /// ```
    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Arc<T> {
    /// Gedeeltelijke vergelijking voor twee `Arc`s.
    ///
    /// De twee worden vergeleken door `partial_cmp()` op hun innerlijke waarden aan te roepen.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Arc::new(6)));
    /// ```
    fn partial_cmp(&self, other: &Arc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// Minder dan vergelijking voor twee `Arc`s.
    ///
    /// De twee worden vergeleken door `<` op hun innerlijke waarden aan te roepen.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five < Arc::new(6));
    /// ```
    fn lt(&self, other: &Arc<T>) -> bool {
        *(*self) < *(*other)
    }

    /// 'Kleiner dan of gelijk aan' vergelijking voor twee 'Arc`s.
    ///
    /// De twee worden vergeleken door `<=` op hun innerlijke waarden aan te roepen.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five <= Arc::new(5));
    /// ```
    fn le(&self, other: &Arc<T>) -> bool {
        *(*self) <= *(*other)
    }

    /// Groter dan vergelijking voor twee `Arc`s.
    ///
    /// De twee worden vergeleken door `>` op hun innerlijke waarden aan te roepen.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five > Arc::new(4));
    /// ```
    fn gt(&self, other: &Arc<T>) -> bool {
        *(*self) > *(*other)
    }

    /// 'Groter dan of gelijk aan' vergelijking voor twee 'Arc`s.
    ///
    /// De twee worden vergeleken door `>=` op hun innerlijke waarden aan te roepen.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five >= Arc::new(5));
    /// ```
    fn ge(&self, other: &Arc<T>) -> bool {
        *(*self) >= *(*other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Arc<T> {
    /// Vergelijking voor twee `Arc`s.
    ///
    /// De twee worden vergeleken door `cmp()` op hun innerlijke waarden aan te roepen.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Arc::new(6)));
    /// ```
    fn cmp(&self, other: &Arc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Arc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Arc<T> {
    /// Maakt een nieuwe `Arc<T>`, met de `Default`-waarde voor `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x: Arc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    fn default() -> Arc<T> {
        Arc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Arc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Arc<T> {
    fn from(t: T) -> Self {
        Arc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Arc<[T]> {
    /// Wijs een referentie-geteld segment toe en vul het door 'v'-items te klonen.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Arc<[T]> {
        <Self as ArcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Arc<str> {
    /// Wijs een `str` met referentie toe en kopieer `v` erin.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let shared: Arc<str> = Arc::from("eggplant");
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Arc<str> {
        let arc = Arc::<[u8]>::from(v.as_bytes());
        unsafe { Arc::from_raw(Arc::into_raw(arc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Arc<str> {
    /// Wijs een `str` met referentie toe en kopieer `v` erin.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: String = "eggplant".to_owned();
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Arc<str> {
        Arc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Arc<T> {
    /// Verplaats een omkaderd object naar een nieuwe, referentie getelde toewijzing.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Box<str> = Box::from("eggplant");
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Arc<T> {
        Arc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Arc<[T]> {
    /// Wijs een door referentie geteld segment toe en verplaats de items van 'v' erin.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Vec<i32> = vec![1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(unique);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Arc<[T]> {
        unsafe {
            let arc = Arc::copy_from_slice(&v);

            // Laat de Vec zijn geheugen vrijmaken, maar vernietig de inhoud niet
            v.set_len(0);

            arc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Arc<B>
where
    B: ToOwned + ?Sized,
    Arc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Arc<B> {
        match cow {
            Cow::Borrowed(s) => Arc::from(s),
            Cow::Owned(s) => Arc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Arc<[T]>> for Arc<[T; N]> {
    type Error = Arc<[T]>;

    fn try_from(boxed_slice: Arc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Arc::from_raw(Arc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Arc<[T]> {
    /// Neemt elk element in de `Iterator` en verzamelt het in een `Arc<[T]>`.
    ///
    /// # Prestatiekenmerken
    ///
    /// ## Het algemene geval
    ///
    /// In het algemene geval wordt het verzamelen in `Arc<[T]>` gedaan door eerst in een `Vec<T>` te verzamelen.Dat wil zeggen, bij het schrijven van het volgende:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// dit gedraagt zich alsof we schreven:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // De eerste set toewijzingen vindt hier plaats.
    ///     .into(); // Een tweede toewijzing voor `Arc<[T]>` gebeurt hier.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// Dit zal zo vaak toewijzen als nodig is voor het construeren van de `Vec<T>` en dan zal het eenmaal worden toegewezen om de `Vec<T>` in de `Arc<[T]>` te veranderen.
    ///
    ///
    /// ## Iteratoren van bekende lengte
    ///
    /// Wanneer uw `Iterator` `TrustedLen` implementeert en een exacte grootte heeft, wordt er een enkele toewijzing gemaakt voor de `Arc<[T]>`.Bijvoorbeeld:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).collect(); // Hier vindt slechts een enkele toewijzing plaats.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToArcSlice::to_arc_slice(iter.into_iter())
    }
}

/// Specialisatie trait gebruikt voor het verzamelen in `Arc<[T]>`.
trait ToArcSlice<T>: Iterator<Item = T> + Sized {
    fn to_arc_slice(self) -> Arc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToArcSlice<T> for I {
    default fn to_arc_slice(self) -> Arc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToArcSlice<T> for I {
    fn to_arc_slice(self) -> Arc<[T]> {
        // Dit is het geval voor een `TrustedLen`-iterator.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // VEILIGHEID: We moeten ervoor zorgen dat de iterator een exacte lengte heeft en dat hebben we ook.
                Arc::from_iter_exact(self, low)
            }
        } else {
            // Terugvallen op de normale implementatie.
            self.collect::<Vec<T>>().into()
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Arc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Arc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Arc<T> {}

/// Verkrijg de offset binnen een `ArcInner` voor de payload achter een aanwijzer.
///
/// # Safety
///
/// De pointer moet verwijzen naar (en geldige metadata hebben voor) een eerder geldige instantie van T, maar de T mag worden verwijderd.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // Lijn de niet-gedimensioneerde waarde uit met het uiteinde van de ArcInner.
    // Omdat RcBox repr(C) is, zal het altijd het laatste veld in het geheugen zijn.
    // VEILIGHEID: aangezien de enige mogelijke niet-bemeten typen plakjes zijn, trait-objecten,
    // en externe types, is de input veiligheidsvereiste momenteel voldoende om te voldoen aan de vereisten van align_of_val_raw;dit is een implementatiedetail van de taal waarop niet kan worden vertrouwd buiten std.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<ArcInner<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}