//! Het alloc Prelude
//!
//! Het doel van deze module is om de invoer van veelgebruikte items van de `alloc` crate te verminderen door een globimport toe te voegen aan de bovenkant van de modules:
//!
//!
//! ```
//! # #![allow(unused_imports)]
//! #![feature(alloc_prelude)]
//! extern crate alloc;
//! use alloc::prelude::v1::*;
//! ```

#![unstable(feature = "alloc_prelude", issue = "58935")]

pub mod v1;