//! Hulpprogramma's voor het formatteren en afdrukken van `String`s.
//!
//! Deze module bevat de runtime-ondersteuning voor de [`format!`]-syntaxisextensie.
//! Deze macro is geïmplementeerd in de compiler om aanroepen naar deze module te verzenden om argumenten tijdens runtime in strings op te maken.
//!
//! # Usage
//!
//! De [`format!`]-macro is bedoeld om bekend te zijn voor degenen die afkomstig zijn van de `printf`/`fprintf`-functies van C of de `str.format`-functie van Python.
//!
//! Enkele voorbeelden van de [`format!`]-extensie zijn:
//!
//! ```
//! format!("Hello");                 // => "Hello"
//! format!("Hello, {}!", "world");   // => "Hello, world!"
//! format!("The number is {}", 1);   // => "The number is 1"
//! format!("{:?}", (3, 4));          // => "(3, 4)"
//! format!("{value}", value=4);      // => "4"
//! format!("{} {}", 1, 2);           // => "1 2"
//! format!("{:04}", 42);             // => "0042" met voorloopnullen
//! ```
//!
//! Hieruit kun je zien dat het eerste argument een opmaakstring is.De compiler vereist dat dit een letterlijke tekenreeks is;het kan geen variabele zijn die is doorgegeven (om geldigheidscontrole uit te voeren).
//! De compiler zal dan de format string ontleden en bepalen of de lijst met opgegeven argumenten geschikt is om door te geven aan deze format string.
//!
//! Gebruik de [`to_string`]-methode om een enkele waarde naar een string te converteren.Dit zal de [`Display`]-opmaak trait gebruiken.
//!
//! ## Positionele parameters
//!
//! Elk opmaakargument mag specificeren naar welk waardeargument het verwijst, en als het wordt weggelaten, wordt aangenomen dat het "the next argument" is.
//! De opmaakreeks `{} {} {}` zou bijvoorbeeld drie parameters hebben, en ze zouden in dezelfde volgorde worden opgemaakt als waarin ze zijn opgegeven.
//! De opmaakreeks `{2} {1} {0}` zou argumenten echter in omgekeerde volgorde opmaken.
//!
//! Het kan een beetje lastig worden als je de twee soorten positionele specifiers met elkaar gaat vermengen.De specificatie "next argument" kan worden gezien als een iterator over het argument.
//! Elke keer dat een "next argument"-specificatie wordt gezien, gaat de iterator verder.Dit leidt tot gedrag als dit:
//!
//! ```
//! format!("{1} {} {0} {}", 1, 2); // => "2 1 1 2"
//! ```
//!
//! De interne iterator over het argument is niet vooruitgeschoven tegen de tijd dat de eerste `{}` wordt gezien, dus het drukt het eerste argument af.Bij het bereiken van de tweede `{}` is de iterator vooruitgegaan naar het tweede argument.
//! Parameters die hun argument expliciet benoemen, hebben in wezen geen invloed op parameters die een argument niet benoemen in termen van positionele specificaties.
//!
//! Een format string is vereist om al zijn argumenten te gebruiken, anders is het een compileerfout.U kunt in de opmaakreeks meerdere keren naar hetzelfde argument verwijzen.
//!
//! ## Benoemde parameters
//!
//! Rust zelf heeft geen Python-achtig equivalent van benoemde parameters voor een functie, maar de [`format!`]-macro is een syntaxisextensie waarmee het benoemde parameters kan gebruiken.
//! Benoemde parameters staan aan het einde van de lijst met argumenten en hebben de syntaxis:
//!
//! ```text
//! identifier '=' expression
//! ```
//!
//! De volgende [`format!`]-expressies gebruiken bijvoorbeeld allemaal het benoemde argument:
//!
//! ```
//! format!("{argument}", argument = "test");   // => "test"
//! format!("{name} {}", 1, name = 2);          // => "2 1"
//! format!("{a} {c} {b}", a="a", b='b', c=3);  // => "a 3 b"
//! ```
//!
//! Het is niet geldig om positionele parameters (die zonder namen) achter argumenten met namen te plaatsen.Net als bij positionele parameters is het niet geldig om benoemde parameters op te geven die niet worden gebruikt door de format string.
//!
//! # Opmaakparameters
//!
//! Elk argument dat wordt opgemaakt, kan worden getransformeerd door een aantal opmaakparameters (corresponderend met `format_spec` in [the syntax](#syntax)). Deze parameters hebben invloed op de stringvoorstelling van wat er wordt opgemaakt.
//!
//! ## Width
//!
//! ```
//! // Al deze drukken "Hello x !" af
//! println!("Hello {:5}!", "x");
//! println!("Hello {:1$}!", "x", 5);
//! println!("Hello {1:0$}!", 5, "x");
//! println!("Hello {:width$}!", "x", width = 5);
//! ```
//!
//! Dit is een parameter voor de "minimum width" die het formaat zou moeten innemen.
//! Als de tekenreeks van de waarde niet zoveel tekens vult, wordt de opvulling gespecificeerd door fill/alignment gebruikt om de vereiste ruimte in te nemen (zie hieronder).
//!
//! De waarde voor de breedte kan ook worden opgegeven als een [`usize`] in de lijst met parameters door een postfix `$` toe te voegen, waarmee wordt aangegeven dat het tweede argument een [`usize`] is die de breedte specificeert.
//!
//! Verwijzen naar een argument met de dollar-syntaxis heeft geen invloed op de "next argument"-teller, dus het is meestal een goed idee om naar argumenten op positie te verwijzen of benoemde argumenten te gebruiken.
//!
//! ## Fill/Alignment
//!
//! ```
//! assert_eq!(format!("Hello {:<5}!", "x"),  "Hello x    !");
//! assert_eq!(format!("Hello {:-<5}!", "x"), "Hello x----!");
//! assert_eq!(format!("Hello {:^5}!", "x"),  "Hello   x  !");
//! assert_eq!(format!("Hello {:>5}!", "x"),  "Hello     x!");
//! ```
//!
//! Het optionele vulteken en de uitlijning worden normaal gesproken samen met de parameter [`width`](#width) geleverd.Het moet worden gedefinieerd vóór `width`, direct na de `:`.
//! Dit geeft aan dat als de waarde die wordt opgemaakt kleiner is dan `width`, er extra tekens omheen worden afgedrukt.
//! Vullen is er in de volgende varianten voor verschillende uitlijningen:
//!
//! * `[fill]<` - het argument is links uitgelijnd in `width`-kolommen
//! * `[fill]^` - het argument is gecentreerd in `width`-kolommen
//! * `[fill]>` - het argument is rechts uitgelijnd in `width`-kolommen
//!
//! De standaard [fill/alignment](#fillalignment) voor niet-numerieke tekens is een spatie en links uitgelijnd.De standaardinstelling voor numerieke opmaak is ook een spatie, maar dan rechts uitgelijnd.
//! Als de vlag `0` (zie hieronder) is opgegeven voor numerieke tekens, is het impliciete vulteken `0`.
//!
//! Houd er rekening mee dat uitlijning mogelijk niet door sommige typen wordt geïmplementeerd.In het bijzonder is het over het algemeen niet geïmplementeerd voor de `Debug` trait.
//! Een goede manier om ervoor te zorgen dat opvulling wordt toegepast, is door uw invoer te formatteren en vervolgens deze resulterende tekenreeks op te vullen om uw uitvoer te verkrijgen:
//!
//! ```
//! println!("Hello {:^15}!", format!("{:?}", Some("hi"))); // => "Hallo Some("hi")!"
//! ```
//!
//! ## Sign/`#`/`0`
//!
//! ```
//! assert_eq!(format!("Hello {:+}!", 5), "Hello +5!");
//! assert_eq!(format!("{:#x}!", 27), "0x1b!");
//! assert_eq!(format!("Hello {:05}!", 5),  "Hello 00005!");
//! assert_eq!(format!("Hello {:05}!", -5), "Hello -0005!");
//! assert_eq!(format!("{:#010x}!", 27), "0x0000001b!");
//! ```
//!
//! Dit zijn allemaal vlaggen die het gedrag van de formatter veranderen.
//!
//! * `+` - Dit is bedoeld voor numerieke typen en geeft aan dat het teken altijd moet worden afgedrukt.Positieve tekens worden nooit standaard afgedrukt en het negatieve teken wordt alleen standaard afgedrukt voor de `Signed` trait.
//! Deze vlag geeft aan dat het juiste teken (`+` of `-`) altijd moet worden afgedrukt.
//! * `-` - Momenteel niet gebruikt
//! * `#` - Deze vlag geeft aan dat de "alternate"-afdrukvorm moet worden gebruikt.De alternatieve vormen zijn:
//!     * `#?` - druk de [`Debug`]-opmaak mooi af
//!     * `#x` - voorafgaat het argument met een `0x`
//!     * `#X` - voorafgaat het argument met een `0x`
//!     * `#b` - voorafgaat het argument met een `0b`
//!     * `#o` - voorafgaat het argument met een `0o`
//! * `0` - Dit wordt gebruikt om voor integer-formaten aan te geven dat de opvulling naar `width` zowel moet worden gedaan met een `0`-teken als om tekenbewust te zijn.
//! Een formaat als `{:08}` zou `00000001` opleveren voor het gehele getal `1`, terwijl hetzelfde formaat `-0000001` zou opleveren voor het gehele getal `-1`.
//! Merk op dat de negatieve versie één nul minder heeft dan de positieve versie.
//!         Houd er rekening mee dat opvulnullen altijd na het teken (indien aanwezig) en vóór de cijfers worden geplaatst.Bij gebruik in combinatie met de `#`-vlag is een vergelijkbare regel van toepassing: opvulnullen worden ingevoegd na het voorvoegsel maar vóór de cijfers.
//!         Het voorvoegsel is opgenomen in de totale breedte.
//!
//! ## Precision
//!
//! Voor niet-numerieke typen kan dit worden beschouwd als een "maximum width".
//! Als de resulterende tekenreeks langer is dan deze breedte, wordt deze afgekapt tot zoveel tekens en wordt die afgekapte waarde verzonden met de juiste `fill`, `alignment` en `width` als die parameters zijn ingesteld.
//!
//! Voor integrale typen wordt dit genegeerd.
//!
//! Voor typen met drijvende komma geeft dit aan hoeveel cijfers achter de komma moeten worden afgedrukt.
//!
//! Er zijn drie mogelijke manieren om de gewenste `precision` te specificeren:
//!
//! 1. Een geheel getal `.N`:
//!
//!    het gehele getal `N` zelf is de precisie.
//!
//! 2. Een geheel getal of naam gevolgd door dollarteken `.N$`:
//!
//!    gebruik format *argument*`N` (dat een `usize` moet zijn) als de precisie.
//!
//! 3. Een asterisk `.*`:
//!
//!    `.*` betekent dat deze `{...}` is geassocieerd met *twee* indelingsinvoer in plaats van één: de eerste invoer bevat de `usize`-precisie en de tweede bevat de waarde die moet worden afgedrukt.
//!    Merk op dat in dit geval, als men de formaatreeks `{<arg>:<spec>.*}` gebruikt, het `<arg>`-gedeelte verwijst naar de* waarde * om af te drukken, en de `precision` moet in de invoer komen voorafgaand aan `<arg>`.
//!
//! De volgende aanroepen drukken bijvoorbeeld allemaal hetzelfde af `Hello x is 0.01000`:
//!
//! ```
//! // Hallo {arg 0 ("x")} is {arg 1 (0.01) with precision specified inline (5)}
//! println!("Hello {0} is {1:.5}", "x", 0.01);
//!
//! // Hallo {arg 1 ("x")} is {arg 2 (0.01) with precision specified in arg 0 (5)}
//! println!("Hello {1} is {2:.0$}", 5, "x", 0.01);
//!
//! // Hallo {arg 0 ("x")} is {arg 2 (0.01) with precision specified in arg 1 (5)}
//! println!("Hello {0} is {2:.1$}", "x", 5, 0.01);
//!
//! // Hallo {next arg ("x")} is {second of next two args (0.01) with precision specified in first of next two args (5)}
//! //
//! println!("Hello {} is {:.*}",    "x", 5, 0.01);
//!
//! // Hallo {next arg ("x")} is {arg 2 (0.01) with precision specified in its predecessor (5)}
//! //
//! println!("Hello {} is {2:.*}",   "x", 5, 0.01);
//!
//! // Hallo {next arg ("x")} is {arg "number" (0.01) with precision specified in arg "prec" (5)}
//! //
//! println!("Hello {} is {number:.prec$}", "x", prec = 5, number = 0.01);
//! ```
//!
//! Terwijl deze:
//!
//! ```
//! println!("{}, `{name:.*}` has 3 fractional digits", "Hello", 3, name=1234.56);
//! println!("{}, `{name:.*}` has 3 characters", "Hello", 3, name="1234.56");
//! println!("{}, `{name:>8.*}` has 3 right-aligned characters", "Hello", 3, name="1234.56");
//! ```
//!
//! print drie significant verschillende dingen:
//!
//! ```text
//! Hello, `1234.560` has 3 fractional digits
//! Hello, `123` has 3 characters
//! Hello, `     123` has 3 right-aligned characters
//! ```
//!
//! ## Localization
//!
//! In sommige programmeertalen hangt het gedrag van tekenreeksopmaakfuncties af van de landinstelling van het besturingssysteem.
//! De formaatfuncties die door de standaardbibliotheek van Rust worden geleverd, hebben geen enkel concept van locale en zullen op alle systemen dezelfde resultaten opleveren, ongeacht de gebruikersconfiguratie.
//!
//! De volgende code zal bijvoorbeeld altijd `1.5` afdrukken, zelfs als de landinstelling van het systeem een ander decimaal scheidingsteken dan een punt gebruikt.
//!
//! ```
//! println!("The value is {}", 1.5);
//! ```
//!
//! # Escaping
//!
//! De letterlijke tekens `{` en `}` kunnen in een string worden opgenomen door ze vooraf te laten gaan met hetzelfde teken.Het `{`-teken wordt bijvoorbeeld geëscaped met `{{` en het `}`-teken wordt geëscaped met `}}`.
//!
//! ```
//! assert_eq!(format!("Hello {{}}"), "Hello {}");
//! assert_eq!(format!("{{ Hello"), "{ Hello");
//! ```
//!
//! # Syntax
//!
//! Samenvattend vindt u hier de volledige grammatica van opmaakstrings.
//! De syntaxis voor de gebruikte opmaaktaal is afkomstig uit andere talen, dus het mag niet te vreemd zijn.Argumenten zijn opgemaakt met Python-achtige syntaxis, wat betekent dat argumenten worden omgeven door `{}` in plaats van de C-achtige `%`.
//! De eigenlijke grammatica voor de opmaaksyntaxis is:
//!
//! ```text
//! format_string := text [ maybe_format text ] *
//! maybe_format := '{' '{' | '}' '}' | format
//! format := '{' [ argument ] [ ':' format_spec ] '}'
//! argument := integer | identifier
//!
//! format_spec := [[fill]align][sign]['#']['0'][width]['.' precision]type
//! fill := character
//! align := '<' | '^' | '>'
//! sign := '+' | '-'
//! width := count
//! precision := count | '*'
//! type := '' | '?' | 'x?' | 'X?' | identifier
//! count := parameter | integer
//! parameter := argument '$'
//! ```
//! In de bovenstaande grammatica mag `text` geen `'{'`-of `'}'`-tekens bevatten.
//!
//! # traits
//!
//! Wanneer u vraagt dat een argument wordt opgemaakt met een bepaald type, vraagt u feitelijk dat een argument wordt toegeschreven aan een bepaalde trait.
//! Hierdoor kunnen meerdere daadwerkelijke typen worden geformatteerd via `{:x}` (zoals zowel [`i8`] als [`isize`]).De huidige toewijzing van typen aan traits is:
//!
//! * *niets* ⇒ [`Display`]
//! * `?` ⇒ [`Debug`]
//! * `x?` ⇒ [`Debug`] met hexadecimale gehele getallen in kleine letters
//! * `X?` ⇒ [`Debug`] met hexadecimale gehele getallen in hoofdletters
//! * `o` ⇒ [`Octal`]
//! * `x` ⇒ [`LowerHex`]
//! * `X` ⇒ [`UpperHex`]
//! * `p` ⇒ [`Pointer`]
//! * `b` ⇒ [`Binary`]
//! * `e` ⇒ [`LowerExp`]
//! * `E` ⇒ [`UpperExp`]
//!
//! Dit betekent dat elk type argument dat de [`fmt::Binary`][`Binary`] trait implementeert, vervolgens kan worden opgemaakt met `{:b}`.Implementaties zijn ook voorzien voor deze traits voor een aantal primitieve typen door de standaardbibliotheek.
//!
//! Als er geen formaat is opgegeven (zoals in `{}` of `{:6}`), dan is het gebruikte formaat trait de [`Display`] trait.
//!
//! Wanneer u een formaat trait implementeert voor uw eigen type, moet u een methode van de handtekening implementeren:
//!
//! ```
//! # #![allow(dead_code)]
//! # use std::fmt;
//! # struct Foo; // ons aangepaste type
//! # impl fmt::Display for Foo {
//! fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//! # write!(f, "testing, testing")
//! # } }
//! ```
//!
//! Uw type zal worden doorgegeven als `self` door verwijzing, en dan moet de functie uitvoer naar de `f.buf`-stream sturen.Het is aan elke trait-implementatie van het formaat om correct te voldoen aan de gevraagde opmaakparameters.
//! De waarden van deze parameters worden vermeld in de velden van de [`Formatter`]-structuur.Om hierbij te helpen, biedt de [`Formatter`]-structuur ook enkele hulpmethoden.
//!
//! Bovendien is de geretourneerde waarde van deze functie [`fmt::Result`], een type-alias van [`Resultaat`]`<(),`[`std: : fmt::Error`] `>`.
//! Formatteringsimplementaties moeten ervoor zorgen dat ze fouten uit de [`Formatter`] verspreiden (bijv. Bij het aanroepen van [`write!`]).
//! Ze mogen echter nooit onechte fouten retourneren.
//! Dat wil zeggen, een opmaakimplementatie moet en mag alleen een fout retourneren als de doorgegeven [`Formatter`] een fout retourneert.
//! Dit komt omdat, in tegenstelling tot wat de functiehandtekening suggereert, stringopmaak een onfeilbare operatie is.
//! Deze functie retourneert alleen een resultaat omdat het schrijven naar de onderliggende stream kan mislukken en het moet een manier bieden om het feit dat er een fout is opgetreden in de stack door te geven.
//!
//! Een voorbeeld van het implementeren van de opmaak traits zou er als volgt uitzien:
//!
//! ```
//! use std::fmt;
//!
//! #[derive(Debug)]
//! struct Vector2D {
//!     x: isize,
//!     y: isize,
//! }
//!
//! impl fmt::Display for Vector2D {
//!     fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//!         // De `f`-waarde implementeert de `Write` trait, en dat is wat het schrijven!macro verwacht.
//!         // Merk op dat deze opmaak de verschillende vlaggen negeert die zijn voorzien om strings op te maken.
//!         //
//!         write!(f, "({}, {})", self.x, self.y)
//!     }
//! }
//!
//! // Verschillende traits maken verschillende vormen van uitvoer van een bepaald type mogelijk.
//! // De betekenis van dit formaat is om de grootte van een vector af te drukken.
//! impl fmt::Binary for Vector2D {
//!     fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//!         let magnitude = (self.x * self.x + self.y * self.y) as f64;
//!         let magnitude = magnitude.sqrt();
//!
//!         // Respecteer de opmaakvlaggen door de helper-methode `pad_integral` op het Formatter-object te gebruiken.
//!         // Zie de methodedocumentatie voor details, en de functie `pad` kan worden gebruikt om strings op te vullen.
//!         //
//!         //
//!         let decimals = f.precision().unwrap_or(3);
//!         let string = format!("{:.*}", decimals, magnitude);
//!         f.pad_integral(true, "", &string)
//!     }
//! }
//!
//! fn main() {
//!     let myvector = Vector2D { x: 3, y: 4 };
//!
//!     println!("{}", myvector);       // => "(3, 4)"
//!     println!("{:?}", myvector);     // => "Vector2D {x: 3, y:4}"
//!     println!("{:10.3b}", myvector); // => "     5.000"
//! }
//! ```
//!
//! ### `fmt::Display` versus `fmt::Debug`
//!
//! Deze twee opmaak traits hebben verschillende doelen:
//!
//! - [`fmt::Display`][`Display`] implementaties beweren dat het type te allen tijde getrouw kan worden weergegeven als een UTF-8-string.Het is **niet** te verwachten dat alle typen de [`Display`] trait implementeren.
//! - [`fmt::Debug`][`Debug`] implementaties moeten worden geïmplementeerd voor **alle** openbare typen.
//!   De output zal typisch de interne toestand zo getrouw mogelijk weergeven.
//!   Het doel van de [`Debug`] trait is om het debuggen van Rust-code te vergemakkelijken.In de meeste gevallen is het gebruik van `#[derive(Debug)]` voldoende en wordt aanbevolen.
//!
//! Enkele voorbeelden van de output van beide traits:
//!
//! ```
//! assert_eq!(format!("{} {:?}", 3, 4), "3 4");
//! assert_eq!(format!("{} {:?}", 'a', 'b'), "a 'b'");
//! assert_eq!(format!("{} {:?}", "foo\n", "bar\n"), "foo\n \"bar\\n\"");
//! ```
//!
//! # Gerelateerde macro's
//!
//! Er zijn een aantal verwante macro's in de [`format!`]-familie.Degenen die momenteel worden geïmplementeerd zijn:
//!
//! ```ignore (only-for-syntax-highlight)
//! format!      // described above
//! write!       // first argument is a &mut io::Write, the destination
//! writeln!     // same as write but appends a newline
//! print!       // the format string is printed to the standard output
//! println!     // same as print but appends a newline
//! eprint!      // the format string is printed to the standard error
//! eprintln!    // same as eprint but appends a newline
//! format_args! // described below.
//! ```
//!
//! ### `write!`
//!
//! Dit en [`writeln!`] zijn twee macro's die worden gebruikt om de format string naar een gespecificeerde stream te sturen.Dit wordt gebruikt om tussentijdse toewijzingen van formaatstrings te voorkomen en in plaats daarvan direct de uitvoer te schrijven.
//! Onder de motorkap roept deze functie feitelijk de [`write_fmt`]-functie op die is gedefinieerd op de [`std::io::Write`] trait.
//! Voorbeeldgebruik is:
//!
//! ```
//! # #![allow(unused_must_use)]
//! use std::io::Write;
//! let mut w = Vec::new();
//! write!(&mut w, "Hello {}!", "world");
//! ```
//!
//! ### `print!`
//!
//! Dit en [`println!`] zenden hun uitvoer uit naar stdout.Net als bij de [`write!`]-macro is het doel van deze macro's om tussentijdse toewijzingen bij het afdrukken van uitvoer te vermijden.Voorbeeldgebruik is:
//!
//! ```
//! print!("Hello {}!", "world");
//! println!("I have a newline {}", "character at the end");
//! ```
//!
//! ### `eprint!`
//!
//! De [`eprint!`]-en [`eprintln!`]-macro's zijn identiek aan respectievelijk [`print!`] en [`println!`], behalve dat ze hun uitvoer naar stderr sturen.
//!
//! ### `format_args!`
//!
//! Dit is een merkwaardige macro die wordt gebruikt om veilig een ondoorzichtig object te passeren dat de opmaakreeks beschrijft.Dit object vereist geen heap-toewijzingen om te maken en het verwijst alleen naar informatie op de stapel.
//! Onder de motorkap worden alle gerelateerde macro's hierop geïmplementeerd.
//! Ten eerste is een voorbeeld van gebruik:
//!
//! ```
//! # #![allow(unused_must_use)]
//! use std::fmt;
//! use std::io::{self, Write};
//!
//! let mut some_writer = io::stdout();
//! write!(&mut some_writer, "{}", format_args!("print with a {}", "macro"));
//!
//! fn my_fmt_fn(args: fmt::Arguments) {
//!     write!(&mut io::stdout(), "{}", args);
//! }
//! my_fmt_fn(format_args!(", or a {} too", "function"));
//! ```
//!
//! Het resultaat van de [`format_args!`]-macro is een waarde van het type [`fmt::Arguments`].
//! Deze structuur kan vervolgens worden doorgegeven aan de [`write`]-en [`format`]-functies binnen deze module om de format string te verwerken.
//! Het doel van deze macro is om tussentijdse toewijzingen nog verder te voorkomen bij het omgaan met opmaakstrings.
//!
//! Een logboekregistratiebibliotheek zou bijvoorbeeld de standaardopmaaksyntaxis kunnen gebruiken, maar het zou deze structuur intern doorgeven totdat is bepaald waar de uitvoer naar toe moet gaan.
//!
//! [`fmt::Result`]: Result
//! [`Result`]: core::result::Result
//! [`std::fmt::Error`]: Error
//! [`write!`]: core::write
//! [`write`]: core::write
//! [`format!`]: crate::format
//! [`to_string`]: crate::string::ToString
//! [`writeln!`]: core::writeln
//! [`write_fmt`]: ../../std/io/trait.Write.html#method.write_fmt
//! [`std::io::Write`]: ../../std/io/trait.Write.html
//! [`print!`]: ../../std/macro.print.html
//! [`println!`]: ../../std/macro.println.html
//! [`eprint!`]: ../../std/macro.eprint.html
//! [`eprintln!`]: ../../std/macro.eprintln.html
//! [`format_args!`]: core::format_args
//! [`fmt::Arguments`]: Arguments
//! [`format`]: crate::format
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[unstable(feature = "fmt_internals", issue = "none")]
pub use core::fmt::rt;
#[stable(feature = "fmt_flags_align", since = "1.28.0")]
pub use core::fmt::Alignment;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::Error;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{write, ArgumentV1, Arguments};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Binary, Octal};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Debug, Display};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{DebugList, DebugMap, DebugSet, DebugStruct, DebugTuple};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Formatter, Result, Write};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{LowerExp, UpperExp};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{LowerHex, Pointer, UpperHex};

use crate::string;

/// De `format`-functie heeft een [`Arguments`]-structuur en retourneert de resulterende opgemaakte tekenreeks.
///
///
/// De [`Arguments`]-instantie kan worden gemaakt met de [`format_args!`]-macro.
///
/// # Examples
///
/// Basisgebruik:
///
/// ```
/// use std::fmt;
///
/// let s = fmt::format(format_args!("Hello, {}!", "world"));
/// assert_eq!(s, "Hello, world!");
/// ```
///
/// Houd er rekening mee dat het gebruik van [`format!`] de voorkeur kan hebben.
/// Example:
///
/// ```
/// let s = format!("Hello, {}!", "world");
/// assert_eq!(s, "Hello, world!");
/// ```
///
/// [`format_args!`]: core::format_args
/// [`format!`]: crate::format
#[stable(feature = "rust1", since = "1.0.0")]
pub fn format(args: Arguments<'_>) -> string::String {
    let capacity = args.estimated_capacity();
    let mut output = string::String::with_capacity(capacity);
    output.write_fmt(args).expect("a formatting trait implementation returned an error");
    output
}