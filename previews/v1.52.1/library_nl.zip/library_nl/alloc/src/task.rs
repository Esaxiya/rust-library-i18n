#![stable(feature = "wake_trait", since = "1.51.0")]
//! Types en Traits voor het werken met asynchrone taken.
use core::mem::ManuallyDrop;
use core::task::{RawWaker, RawWakerVTable, Waker};

use crate::sync::Arc;

/// De implementatie van het wekken van een taak op een uitvoerder.
///
/// Deze trait kan worden gebruikt om een [`Waker`] te maken.
/// Een uitvoerder kan een implementatie van deze trait definiëren en die gebruiken om een Waker te construeren om door te geven aan de taken die op die uitvoerder worden uitgevoerd.
///
/// Deze trait is een geheugenveilig en ergonomisch alternatief voor het construeren van een [`RawWaker`].
/// Het ondersteunt het algemene executor-ontwerp waarin de gegevens die worden gebruikt om een taak te activeren, worden opgeslagen in een [`Arc`].
/// Sommige uitvoerders (vooral die voor embedded systemen) kunnen deze API niet gebruiken, daarom bestaat [`RawWaker`] als alternatief voor die systemen.
///
/// [arc]: ../../std/sync/struct.Arc.html
///
/// # Examples
///
/// Een standaard `block_on`-functie die een future neemt en deze volledig uitvoert op de huidige thread.
///
/// **Note:** In dit voorbeeld wordt juistheid ingeruild voor eenvoud.
/// Om impasses te voorkomen, moeten implementaties van productiekwaliteit ook tussenliggende aanroepen naar `thread::unpark` en geneste aanroepen afhandelen.
///
///
/// ```rust
/// use std::future::Future;
/// use std::sync::Arc;
/// use std::task::{Context, Poll, Wake};
/// use std::thread::{self, Thread};
///
/// /// Een waker die de huidige thread wakker maakt wanneer hij wordt gebeld.
/// struct ThreadWaker(Thread);
///
/// impl Wake for ThreadWaker {
///     fn wake(self: Arc<Self>) {
///         self.0.unpark();
///     }
/// }
///
/// /// Voer een future uit tot voltooiing op de huidige thread.
/// fn block_on<T>(fut: impl Future<Output = T>) -> T {
///     // Pin de future zodat deze kan worden gepolld.
///     let mut fut = Box::pin(fut);
///
///     // Maak een nieuwe context die moet worden doorgegeven aan de future.
///     let t = thread::current();
///     let waker = Arc::new(ThreadWaker(t)).into();
///     let mut cx = Context::from_waker(&waker);
///
///     // Voer de future uit tot het einde.
///     loop {
///         match fut.as_mut().poll(&mut cx) {
///             Poll::Ready(res) => return res,
///             Poll::Pending => thread::park(),
///         }
///     }
/// }
///
/// block_on(async {
///     println!("Hi from inside a future!");
/// });
/// ```
///
///
///
///
#[stable(feature = "wake_trait", since = "1.51.0")]
pub trait Wake {
    /// Maak deze taak wakker.
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake(self: Arc<Self>);

    /// Wek deze taak zonder de waker te consumeren.
    ///
    /// Als een uitvoerder een goedkopere manier ondersteunt om wakker te worden zonder de waker te verbruiken, zou deze deze methode moeten overschrijven.
    /// Standaard wordt de [`Arc`] gekloond en wordt [`wake`] op de kloon aangeroepen.
    ///
    /// [`wake`]: Wake::wake
    ///
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake_by_ref(self: &Arc<Self>) {
        self.clone().wake();
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for Waker {
    fn from(waker: Arc<W>) -> Waker {
        // VEILIGHEID: Dit is veilig omdat raw_waker veilig construeert
        // een RawWaker van Arc<W>.
        unsafe { Waker::from_raw(raw_waker(waker)) }
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for RawWaker {
    fn from(waker: Arc<W>) -> RawWaker {
        raw_waker(waker)
    }
}

// NB: Deze privéfunctie voor het bouwen van een RawWaker wordt gebruikt in plaats van
// door dit in de `From<Arc<W>> for RawWaker` impl te integreren, om ervoor te zorgen dat de veiligheid van `From<Arc<W>> for Waker` niet afhangt van de juiste trait dispatch, roepen beide impls deze functie direct en expliciet aan.
//
//
//
#[inline(always)]
fn raw_waker<W: Wake + Send + Sync + 'static>(waker: Arc<W>) -> RawWaker {
    // Verhoog de referentietelling van de boog om deze te klonen.
    unsafe fn clone_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) -> RawWaker {
        unsafe { Arc::increment_strong_count(waker as *const W) };
        RawWaker::new(
            waker as *const (),
            &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
        )
    }

    // Wakker worden op waarde en de boog naar de Wake::wake-functie verplaatsen
    unsafe fn wake<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { Arc::from_raw(waker as *const W) };
        <W as Wake>::wake(waker);
    }

    // Wakker worden door middel van referentie, wikkel de waker in ManuallyDrop om te voorkomen dat hij valt
    unsafe fn wake_by_ref<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { ManuallyDrop::new(Arc::from_raw(waker as *const W)) };
        <W as Wake>::wake_by_ref(&waker);
    }

    // Verlaag de referentietelling van de Arc on drop
    unsafe fn drop_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        unsafe { Arc::decrement_strong_count(waker as *const W) };
    }

    RawWaker::new(
        Arc::into_raw(waker) as *const (),
        &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
    )
}