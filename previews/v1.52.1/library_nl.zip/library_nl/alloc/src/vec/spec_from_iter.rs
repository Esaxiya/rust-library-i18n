use core::mem::ManuallyDrop;
use core::ptr::{self};
use core::slice::{self};

use super::{IntoIter, SpecExtend, SpecFromIterNested, Vec};

/// Specialisatie trait gebruikt voor Vec::from_iter
///
/// ## De delegatiegrafiek:
///
/// ```text
/// +-------------+
/// |FromIterator |
/// +-+-----------+
///   |
///   v
/// +-+-------------------------------+  +---------------------+
/// |SpecFromIter                  +---->+SpecFromIterNested   |
/// |where I:                      |  |  |where I:             |
/// |  Iterator (default)----------+  |  |  Iterator (default) |
/// |  vec::IntoIter               |  |  |  TrustedLen         |
/// |  SourceIterMarker---fallback-+  |  |                     |
/// |  slice::Iter                    |  |                     |
/// |  Iterator<Item = &Clone>        |  +---------------------+
/// +---------------------------------+
/// ```
pub(super) trait SpecFromIter<T, I> {
    fn from_iter(iter: I) -> Self;
}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T>,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIterNested::from_iter(iterator)
    }
}

impl<T> SpecFromIter<T, IntoIter<T>> for Vec<T> {
    fn from_iter(iterator: IntoIter<T>) -> Self {
        // Een veelvoorkomend geval is het doorgeven van een vector naar een functie die onmiddellijk opnieuw wordt verzameld in een vector.
        // We kunnen dit kortsluiten als de IntoIter helemaal niet is voortgeschreden.
        // Als het geavanceerd is, kunnen we het geheugen ook hergebruiken en de gegevens naar voren verplaatsen.
        // Maar we doen dit alleen als de resulterende Vec niet meer ongebruikte capaciteit zou hebben dan het creëren via de generieke FromIterator-implementatie.
        //
        // Die beperking is niet strikt noodzakelijk aangezien het allocatiegedrag van Vec opzettelijk niet gespecificeerd is.
        // Maar het is een conservatieve keuze.
        //
        let has_advanced = iterator.buf.as_ptr() as *const _ != iterator.ptr;
        if !has_advanced || iterator.len() >= iterator.cap / 2 {
            unsafe {
                let it = ManuallyDrop::new(iterator);
                if has_advanced {
                    ptr::copy(it.ptr, it.buf.as_ptr(), it.len());
                }
                return Vec::from_raw_parts(it.buf.as_ptr(), it.len(), it.cap);
            }
        }

        let mut vec = Vec::new();
        // moet delegeren naar spec_extend() aangezien extend() zelf delegeert naar spec_from voor lege Vecs
        //
        vec.spec_extend(iterator);
        vec
    }
}

impl<'a, T: 'a, I> SpecFromIter<&'a T, I> for Vec<T>
where
    I: Iterator<Item = &'a T>,
    T: Clone,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIter::from_iter(iterator.cloned())
    }
}

// Dit maakt gebruik van `iterator.as_slice().to_vec()` omdat spec_extend meer stappen moet ondernemen om te redeneren over de uiteindelijke capaciteit + lengte en dus meer werk moet verzetten.
// `to_vec()` wijst direct het juiste bedrag toe en vult het exact.
//
//
impl<'a, T: 'a + Clone> SpecFromIter<&'a T, slice::Iter<'a, T>> for Vec<T> {
    #[cfg(not(test))]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        iterator.as_slice().to_vec()
    }

    // HACK(japaric): met cfg(test) is de inherente `[T]::to_vec`-methode, die vereist is voor deze methodedefinitie, niet beschikbaar.
    // Gebruik in plaats daarvan de `slice::to_vec`-functie die alleen beschikbaar is met cfg(test) NB zie de slice::hack-module in slice.rs voor meer informatie
    //
    //
    #[cfg(test)]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        crate::slice::to_vec(iterator.as_slice(), crate::alloc::Global)
    }
}