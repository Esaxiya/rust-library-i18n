//! Een aaneengesloten, uitbreidbaar array-type met heap-toegewezen inhoud, geschreven `Vec<T>`.
//!
//! Vectors hebben `O(1)`-indexering, afgeschreven `O(1)`-push (tot het einde) en `O(1)`-pop (vanaf het einde).
//!
//!
//! Vectors zorgen ervoor dat ze nooit meer dan `isize::MAX` bytes toewijzen.
//!
//! # Examples
//!
//! U kunt expliciet een [`Vec`] maken met [`Vec::new`]:
//!
//! ```
//! let v: Vec<i32> = Vec::new();
//! ```
//!
//! ... of door de [`vec!`]-macro te gebruiken:
//!
//! ```
//! let v: Vec<i32> = vec![];
//!
//! let v = vec![1, 2, 3, 4, 5];
//!
//! let v = vec![0; 10]; // tien nullen
//! ```
//!
//! U kunt [`push`]-waarden aan het einde van een vector plaatsen (waardoor de vector naar behoefte zal groeien):
//!
//! ```
//! let mut v = vec![1, 2];
//!
//! v.push(3);
//! ```
//!
//! Popping-waarden werken op vrijwel dezelfde manier:
//!
//! ```
//! let mut v = vec![1, 2];
//!
//! let two = v.pop();
//! ```
//!
//! Vectors ondersteunt ook indexering (via de [`Index`] en [`IndexMut`] traits):
//!
//! ```
//! let mut v = vec![1, 2, 3];
//! let three = v[2];
//! v[1] = v[1] + 5;
//! ```
//!
//! [`push`]: Vec::push
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::cmp::{self, Ordering};
use core::convert::TryFrom;
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::{arith_offset, assume};
use core::iter::FromIterator;
use core::marker::PhantomData;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::{self, Index, IndexMut, Range, RangeBounds};
use core::ptr::{self, NonNull};
use core::slice::{self, SliceIndex};

use crate::alloc::{Allocator, Global};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::collections::TryReserveError;
use crate::raw_vec::RawVec;

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
pub use self::drain_filter::DrainFilter;

mod drain_filter;

#[stable(feature = "vec_splice", since = "1.21.0")]
pub use self::splice::Splice;

mod splice;

#[stable(feature = "drain", since = "1.6.0")]
pub use self::drain::Drain;

mod drain;

mod cow;

pub(crate) use self::into_iter::AsIntoIter;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::into_iter::IntoIter;

mod into_iter;

use self::is_zero::IsZero;

mod is_zero;

mod source_iter_marker;

mod partial_eq;

use self::spec_from_elem::SpecFromElem;

mod spec_from_elem;

use self::set_len_on_drop::SetLenOnDrop;

mod set_len_on_drop;

use self::in_place_drop::InPlaceDrop;

mod in_place_drop;

use self::spec_from_iter_nested::SpecFromIterNested;

mod spec_from_iter_nested;

use self::spec_from_iter::SpecFromIter;

mod spec_from_iter;

use self::spec_extend::SpecExtend;

mod spec_extend;

/// Een aaneengesloten kweekbaar array-type, geschreven als `Vec<T>` en uitgesproken als 'vector'.
///
/// # Examples
///
/// ```
/// let mut vec = Vec::new();
/// vec.push(1);
/// vec.push(2);
///
/// assert_eq!(vec.len(), 2);
/// assert_eq!(vec[0], 1);
///
/// assert_eq!(vec.pop(), Some(2));
/// assert_eq!(vec.len(), 1);
///
/// vec[0] = 7;
/// assert_eq!(vec[0], 7);
///
/// vec.extend([1, 2, 3].iter().copied());
///
/// for x in &vec {
///     println!("{}", x);
/// }
/// assert_eq!(vec, [7, 1, 2, 3]);
/// ```
///
/// De [`vec!`]-macro is bedoeld om de initialisatie gemakkelijker te maken:
///
/// ```
/// let mut vec = vec![1, 2, 3];
/// vec.push(4);
/// assert_eq!(vec, [1, 2, 3, 4]);
/// ```
///
/// Het kan ook elk element van een `Vec<T>` initialiseren met een bepaalde waarde.
/// Dit kan efficiënter zijn dan toewijzing en initialisatie in afzonderlijke stappen uitvoeren, vooral bij het initialiseren van een vector met nullen:
///
/// ```
/// let vec = vec![0; 5];
/// assert_eq!(vec, [0, 0, 0, 0, 0]);
///
/// // Het volgende is equivalent, maar mogelijk langzamer:
/// let mut vec = Vec::with_capacity(5);
/// vec.resize(5, 0);
/// assert_eq!(vec, [0, 0, 0, 0, 0]);
/// ```
///
/// Zie [Capacity and Reallocation](#capacity-and-reallocation) voor meer informatie.
///
/// Gebruik een `Vec<T>` als een efficiënte stapel:
///
/// ```
/// let mut stack = Vec::new();
///
/// stack.push(1);
/// stack.push(2);
/// stack.push(3);
///
/// while let Some(top) = stack.pop() {
///     // Drukt 3, 2, 1 af
///     println!("{}", top);
/// }
/// ```
///
/// # Indexing
///
/// Het `Vec`-type geeft toegang tot waarden per index, omdat het de [`Index`] trait implementeert.Een voorbeeld zal explicieter zijn:
///
/// ```
/// let v = vec![0, 2, 4, 6];
/// println!("{}", v[1]); // het zal '2' weergeven
/// ```
///
/// Wees echter voorzichtig: als u probeert toegang te krijgen tot een index die niet in de `Vec` staat, zal uw software panic!Je kan dit niet doen:
///
/// ```should_panic
/// let v = vec![0, 2, 4, 6];
/// println!("{}", v[6]); // it will panic!
/// ```
///
/// Gebruik [`get`] en [`get_mut`] als u wilt controleren of de index in de `Vec` staat.
///
/// # Slicing
///
/// Een `Vec` kan veranderlijk zijn.Aan de andere kant zijn segmenten alleen-lezen objecten.
/// Gebruik [`&`] om een [slice][prim@slice] te krijgen.Voorbeeld:
///
/// ```
/// fn read_slice(slice: &[usize]) {
///     // ...
/// }
///
/// let v = vec![0, 1];
/// read_slice(&v);
///
/// // ... en dat is alles!
/// // je kunt het ook als volgt doen:
/// let u: &[usize] = &v;
/// // of zo:
/// let u: &[_] = &v;
/// ```
///
/// In Rust is het gebruikelijker om plakjes als argumenten door te geven in plaats van vectors wanneer u alleen leestoegang wilt bieden.Hetzelfde geldt voor [`String`] en [`&str`].
///
/// # Capaciteit en herverdeling
///
/// De capaciteit van een vector is de hoeveelheid ruimte die is toegewezen aan eventuele future-elementen die aan de vector zullen worden toegevoegd.Dit moet niet worden verward met de *lengte* van een vector, die het aantal feitelijke elementen binnen de vector specificeert.
/// Als de lengte van een vector de capaciteit overschrijdt, wordt de capaciteit automatisch verhoogd, maar moeten de elementen opnieuw worden toegewezen.
///
/// Een vector met capaciteit 10 en lengte 0 zou bijvoorbeeld een lege vector zijn met ruimte voor 10 extra elementen.Als u 10 of minder elementen op de vector duwt, verandert de capaciteit niet en vindt er geen herverdeling plaats.
/// Als de lengte van de vector echter wordt vergroot tot 11, moet deze opnieuw worden toegewezen, wat langzaam kan zijn.Om deze reden wordt het aanbevolen om waar mogelijk [`Vec::with_capacity`] te gebruiken om aan te geven hoe groot de vector naar verwachting zal worden.
///
/// # Guarantees
///
/// Vanwege zijn ongelooflijk fundamentele aard geeft `Vec` veel garanties over zijn ontwerp.Dit zorgt ervoor dat het in het algemeen zo laag mogelijk is en op primitieve manieren correct kan worden gemanipuleerd door onveilige code.Merk op dat deze garanties verwijzen naar een niet-gekwalificeerde `Vec<T>`.
/// Als er aanvullende typeparameters worden toegevoegd (bijvoorbeeld om aangepaste allocatoren te ondersteunen), kan het gedrag veranderen door hun standaardwaarden te overschrijven.
///
/// Het meest fundamentele is dat `Vec` een triplet (pointer, capaciteit, lengte) is en altijd zal zijn.Niet meer niet minder.De volgorde van deze velden is volledig niet gespecificeerd, en u moet de juiste methoden gebruiken om deze te wijzigen.
/// De pointer zal nooit null zijn, dus dit type is geoptimaliseerd voor null-pointer.
///
/// Het is echter mogelijk dat de aanwijzer niet echt naar toegewezen geheugen wijst.
/// In het bijzonder, als je een `Vec` met capaciteit 0 construeert via [`Vec::new`], [`vec![]`][`vec!`], [`Vec::with_capacity(0)`][`Vec::with_capacity`], of door [`shrink_to_fit`] aan te roepen op een lege Vec, zal het geen geheugen toewijzen.Evenzo, als u typen met een grootte van nul opslaat in een `Vec`, wordt er geen ruimte voor toegewezen.
/// *Merk op dat in dit geval de `Vec` mogelijk geen [`capacity`] van 0* rapporteert.
/// `Vec` zal toewijzen als en alleen als [`mem: : size_of::<T>`]`() * capacity()> 0`.
/// Over het algemeen zijn de toewijzingsdetails van `Vec` erg subtiel-als u van plan bent geheugen toe te wijzen met behulp van een `Vec` en het voor iets anders te gebruiken (ofwel om door te geven aan onveilige code, of om uw eigen geheugengestuurde verzameling te bouwen), wees er dan zeker van om dit geheugen ongedaan te maken door `from_raw_parts` te gebruiken om de `Vec` te herstellen en het vervolgens te laten vallen.
///
/// Als een `Vec`* * toegewezen geheugen heeft, bevindt het geheugen waarnaar het verwijst zich op de heap (zoals gedefinieerd door de allocator Rust is standaard geconfigureerd om te gebruiken), en de pointer wijst naar [`len`] geïnitialiseerde, aaneengesloten elementen in volgorde kijk of je het tot een slice hebt gedwongen), gevolgd door [`capacity`]`,`[`len`] logisch niet-geïnitialiseerde, aaneengesloten elementen.
///
///
/// Een vector met de elementen `'a'` en `'b'` met capaciteit 4 kan worden gevisualiseerd zoals hieronder.Het bovenste deel is de `Vec`-structuur, het bevat een aanwijzer naar de kop van de toewijzing in de hoop, lengte en capaciteit.
/// Het onderste deel is de toewijzing op de heap, een aaneengesloten geheugenblok.
///
/// ```text
///             ptr      len  capacity
///        +--------+--------+--------+
///        | 0x0123 |      2 |      4 |
///        +--------+--------+--------+
///             |
///             v
/// Heap   +--------+--------+--------+--------+
///        |    'a' |    'b' | uninit | uninit |
///        +--------+--------+--------+--------+
/// ```
///
/// - **uninit** staat voor geheugen dat niet is geïnitialiseerd, zie [`MaybeUninit`].
/// - Note: de ABI is niet stabiel en `Vec` geeft geen garanties over zijn geheugenlayout (inclusief de volgorde van velden).
///
/// `Vec` zal nooit een "small optimization" uitvoeren waarbij elementen daadwerkelijk op de stapel zijn opgeslagen om twee redenen:
///
/// * Het zou het voor onveilige code moeilijker maken om een `Vec` correct te manipuleren.De inhoud van een `Vec` zou geen stabiel adres hebben als het alleen zou worden verplaatst, en het zou moeilijker zijn om te bepalen of een `Vec` daadwerkelijk geheugen had toegewezen.
///
/// * Het zou de algemene zaak bestraffen en bij elke toegang een extra branch opleveren.
///
/// `Vec` zal zichzelf nooit automatisch krimpen, zelfs niet als hij helemaal leeg is.Dit zorgt ervoor dat er geen onnodige allocaties of deallocaties plaatsvinden.Het legen van een `Vec` en het vervolgens weer vullen tot dezelfde [`len`] mag geen oproepen naar de allocator veroorzaken.Gebruik [`shrink_to_fit`] of [`shrink_to`] als u ongebruikt geheugen wilt vrijmaken.
///
/// [`push`] en [`insert`] zal nooit (her) alloceren als de gerapporteerde capaciteit voldoende is.[`push`] en [`insert`]*zullen*(her) toewijzen als [`len`]`==`[`capacity`].Dat wil zeggen, de gerapporteerde capaciteit is volledig nauwkeurig en er kan op worden vertrouwd.Het kan zelfs worden gebruikt om handmatig het geheugen vrij te maken dat is toegewezen door een `Vec`, indien gewenst.
/// Bulk-invoegmethoden *kunnen* opnieuw worden toegewezen, zelfs als dit niet nodig is.
///
/// `Vec` garandeert geen specifieke groeistrategie bij herallocatie wanneer vol, noch wanneer [`reserve`] wordt aangeroepen.De huidige strategie is fundamenteel en het kan wenselijk zijn om een niet-constante groeifactor te gebruiken.Welke strategie ook wordt gebruikt, zal natuurlijk *O*(1) afgeschreven [`push`] garanderen.
///
/// `vec![x; n]`, `vec![a, b, c, d]` en [`Vec::with_capacity(n)`][`Vec::with_capacity`] zullen allemaal een `Vec` produceren met precies de gevraagde capaciteit.
/// Als [`len`]`==`[`capacity`], (zoals het geval is voor de [`vec!`]-macro), dan kan een `Vec<T>` worden geconverteerd van en naar een [`Box<[T]>`][owned slice] zonder de elementen opnieuw toe te wijzen of te verplaatsen.
///
/// `Vec` overschrijft niet specifiek alle gegevens die eruit worden verwijderd, maar bewaart deze ook niet specifiek.Het niet-geïnitialiseerde geheugen is krasruimte die het kan gebruiken zoals het wil.Het zal over het algemeen gewoon doen wat het meest efficiënt is of anderszins gemakkelijk te implementeren.Vertrouw er niet op dat verwijderde gegevens worden gewist om veiligheidsredenen.
/// Zelfs als u een `Vec` laat vallen, kan de buffer ervan eenvoudig worden hergebruikt door een andere `Vec`.
/// Zelfs als u het geheugen van een "Vec" eerst op nul zet, kan dat niet echt gebeuren omdat de optimizer dit niet als een neveneffect beschouwt dat moet worden behouden.
/// Er is één geval dat we echter niet zullen verbreken: het is altijd geldig om `unsafe`-code te gebruiken om naar de overtollige capaciteit te schrijven en vervolgens de lengte te vergroten.
///
/// Momenteel garandeert `Vec` niet de volgorde waarin elementen worden verwijderd.
/// De volgorde is in het verleden gewijzigd en kan weer veranderen.
///
/// [`get`]: ../../std/vec/struct.Vec.html#method.get
/// [`get_mut`]: ../../std/vec/struct.Vec.html#method.get_mut
/// [`String`]: crate::string::String
/// [`&str`]: type@str
/// [`shrink_to_fit`]: Vec::shrink_to_fit
/// [`shrink_to`]: Vec::shrink_to
/// [`capacity`]: Vec::capacity
/// [`mem::size_of::<T>`]: core::mem::size_of
/// [`len`]: Vec::len
/// [`push`]: Vec::push
/// [`insert`]: Vec::insert
/// [`reserve`]: Vec::reserve
/// [`MaybeUninit`]: core::mem::MaybeUninit
/// [owned slice]: Box
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "vec_type")]
pub struct Vec<T, #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global> {
    buf: RawVec<T, A>,
    len: usize,
}

////////////////////////////////////////////////////////////////////////////////
// Inherente methoden
////////////////////////////////////////////////////////////////////////////////

impl<T> Vec<T> {
    /// Construeert een nieuwe, lege `Vec<T>`.
    ///
    /// De vector zal niet toewijzen totdat er elementen op zijn gedrukt.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(unused_mut)]
    /// let mut vec: Vec<i32> = Vec::new();
    /// ```
    #[inline]
    #[rustc_const_stable(feature = "const_vec_new", since = "1.39.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> Self {
        Vec { buf: RawVec::NEW, len: 0 }
    }

    /// Construeert een nieuwe, lege `Vec<T>` met de opgegeven capaciteit.
    ///
    /// De vector zal exact `capacity`-elementen kunnen bevatten zonder opnieuw toe te wijzen.
    /// Als `capacity` 0 is, zal de vector niet toewijzen.
    ///
    /// Het is belangrijk op te merken dat hoewel de geretourneerde vector de *capaciteit* heeft opgegeven, de vector een nul *lengte* heeft.
    ///
    /// Voor een verklaring van het verschil tussen lengte en capaciteit, zie *[Capaciteit en herverdeling]*.
    ///
    /// [Capacity and reallocation]: #capacity-and-reallocation
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    ///
    /// // De vector bevat geen items, ook al heeft hij capaciteit voor meer
    /// assert_eq!(vec.len(), 0);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // Deze worden allemaal gedaan zonder opnieuw toe te wijzen ...
    /// for i in 0..10 {
    ///     vec.push(i);
    /// }
    /// assert_eq!(vec.len(), 10);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // ... maar hierdoor kan de vector opnieuw worden toegewezen
    /// vec.push(11);
    /// assert_eq!(vec.len(), 11);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    #[inline]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// Maakt rechtstreeks een `Vec<T>` van de ruwe componenten van een andere vector.
    ///
    /// # Safety
    ///
    /// Dit is hoogst onveilig vanwege het aantal invarianten dat niet wordt gecontroleerd:
    ///
    /// * `ptr` moet eerder zijn toegewezen via [`String`]/`Vec<T>`(tenminste, het is hoogstwaarschijnlijk onjuist als dat niet het geval was).
    /// * `T` moet dezelfde grootte en uitlijning hebben als waaraan `ptr` is toegewezen.
    ///   (`T` met een minder strikte uitlijning is niet voldoende, de uitlijning moet echt gelijk zijn om te voldoen aan de [`dealloc`]-vereiste dat geheugen moet worden toegewezen en ongedaan gemaakt met dezelfde lay-out.)
    ///
    /// * `length` moet kleiner zijn dan of gelijk zijn aan `capacity`.
    /// * `capacity` moet de capaciteit zijn waaraan de aanwijzer is toegewezen.
    ///
    /// Het overtreden hiervan kan problemen veroorzaken zoals het beschadigen van de interne datastructuren van de allocator.Het is bijvoorbeeld **niet** veilig om een `Vec<u8>` te bouwen van een pointer naar een C `char`-array met lengte `size_t`.
    /// Het is ook niet veilig om er een te bouwen van een `Vec<u16>` en zijn lengte, omdat de allocator geeft om de uitlijning, en deze twee typen hebben verschillende uitlijningen.
    /// De buffer is toegewezen met uitlijning 2 (voor `u16`), maar nadat deze in een `Vec<u8>` is veranderd, wordt de toewijzing ongedaan gemaakt met uitlijning 1.
    ///
    /// Het eigendom van `ptr` wordt effectief overgedragen aan de `Vec<T>`, die vervolgens de inhoud van het geheugen waarnaar de aanwijzer verwijst naar believen kan ongedaan maken, opnieuw toewijzen of wijzigen.
    /// Zorg ervoor dat niets anders de aanwijzer gebruikt nadat deze functie is aangeroepen.
    ///
    /// [`String`]: crate::string::String
    /// [`dealloc`]: crate::alloc::GlobalAlloc::dealloc
    ///
    /// # Examples
    ///
    /// ```
    /// use std::ptr;
    /// use std::mem;
    ///
    /// let v = vec![1, 2, 3];
    ///
    ///     // FIXME Update dit wanneer vec_into_raw_parts gestabiliseerd is.
    ///     // Voorkom het uitvoeren van `v`'s destructor, zodat we de volledige controle hebben over de toewijzing.
    /////
    /// let mut v = mem::ManuallyDrop::new(v);
    ///
    /// // Haal de verschillende belangrijke stukjes informatie over `v` tevoorschijn
    /// let p = v.as_mut_ptr();
    /// let len = v.len();
    /// let cap = v.capacity();
    ///
    /// unsafe {
    ///     // Overschrijf geheugen met 4, 5, 6
    ///     for i in 0..len as isize {
    ///         ptr::write(p.offset(i), 4 + i);
    ///     }
    ///
    ///     // Zet alles weer samen in een Vec
    ///     let rebuilt = Vec::from_raw_parts(p, len, cap);
    ///     assert_eq!(rebuilt, [4, 5, 6]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_raw_parts(ptr: *mut T, length: usize, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, length, capacity, Global) }
    }
}

impl<T, A: Allocator> Vec<T, A> {
    /// Construeert een nieuwe, lege `Vec<T, A>`.
    ///
    /// De vector zal niet toewijzen totdat er elementen op zijn gedrukt.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// # #[allow(unused_mut)]
    /// let mut vec: Vec<i32, _> = Vec::new_in(System);
    /// ```
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub const fn new_in(alloc: A) -> Self {
        Vec { buf: RawVec::new_in(alloc), len: 0 }
    }

    /// Construeert een nieuwe, lege `Vec<T, A>` met de opgegeven capaciteit met de meegeleverde allocator.
    ///
    /// De vector zal exact `capacity`-elementen kunnen bevatten zonder opnieuw toe te wijzen.
    /// Als `capacity` 0 is, zal de vector niet toewijzen.
    ///
    /// Het is belangrijk op te merken dat hoewel de geretourneerde vector de *capaciteit* heeft opgegeven, de vector een nul *lengte* heeft.
    ///
    /// Voor een verklaring van het verschil tussen lengte en capaciteit, zie *[Capaciteit en herverdeling]*.
    ///
    /// [Capacity and reallocation]: #capacity-and-reallocation
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut vec = Vec::with_capacity_in(10, System);
    ///
    /// // De vector bevat geen items, ook al heeft hij capaciteit voor meer
    /// assert_eq!(vec.len(), 0);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // Deze worden allemaal gedaan zonder opnieuw toe te wijzen ...
    /// for i in 0..10 {
    ///     vec.push(i);
    /// }
    /// assert_eq!(vec.len(), 10);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // ... maar hierdoor kan de vector opnieuw worden toegewezen
    /// vec.push(11);
    /// assert_eq!(vec.len(), 11);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Vec { buf: RawVec::with_capacity_in(capacity, alloc), len: 0 }
    }

    /// Maakt rechtstreeks een `Vec<T, A>` van de ruwe componenten van een andere vector.
    ///
    /// # Safety
    ///
    /// Dit is hoogst onveilig vanwege het aantal invarianten dat niet wordt gecontroleerd:
    ///
    /// * `ptr` moet eerder zijn toegewezen via [`String`]/`Vec<T>`(tenminste, het is hoogstwaarschijnlijk onjuist als dat niet het geval was).
    /// * `T` moet dezelfde grootte en uitlijning hebben als waaraan `ptr` is toegewezen.
    ///   (`T` met een minder strikte uitlijning is niet voldoende, de uitlijning moet echt gelijk zijn om te voldoen aan de [`dealloc`]-vereiste dat geheugen moet worden toegewezen en ongedaan gemaakt met dezelfde lay-out.)
    ///
    /// * `length` moet kleiner zijn dan of gelijk zijn aan `capacity`.
    /// * `capacity` moet de capaciteit zijn waaraan de aanwijzer is toegewezen.
    ///
    /// Het overtreden hiervan kan problemen veroorzaken zoals het beschadigen van de interne datastructuren van de allocator.Het is bijvoorbeeld **niet** veilig om een `Vec<u8>` te bouwen van een pointer naar een C `char`-array met lengte `size_t`.
    /// Het is ook niet veilig om er een te bouwen van een `Vec<u16>` en zijn lengte, omdat de allocator geeft om de uitlijning, en deze twee typen hebben verschillende uitlijningen.
    /// De buffer is toegewezen met uitlijning 2 (voor `u16`), maar nadat deze in een `Vec<u8>` is veranderd, wordt de toewijzing ongedaan gemaakt met uitlijning 1.
    ///
    /// Het eigendom van `ptr` wordt effectief overgedragen aan de `Vec<T>`, die vervolgens de inhoud van het geheugen waarnaar de aanwijzer verwijst naar believen kan ongedaan maken, opnieuw toewijzen of wijzigen.
    /// Zorg ervoor dat niets anders de aanwijzer gebruikt nadat deze functie is aangeroepen.
    ///
    /// [`String`]: crate::string::String
    /// [`dealloc`]: crate::alloc::GlobalAlloc::dealloc
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// use std::ptr;
    /// use std::mem;
    ///
    /// let mut v = Vec::with_capacity_in(3, System);
    /// v.push(1);
    /// v.push(2);
    /// v.push(3);
    ///
    ///     // FIXME Update dit wanneer vec_into_raw_parts gestabiliseerd is.
    ///     // Voorkom het uitvoeren van `v`'s destructor, zodat we de volledige controle hebben over de toewijzing.
    /////
    /// let mut v = mem::ManuallyDrop::new(v);
    ///
    /// // Haal de verschillende belangrijke stukjes informatie over `v` tevoorschijn
    /// let p = v.as_mut_ptr();
    /// let len = v.len();
    /// let cap = v.capacity();
    /// let alloc = v.allocator();
    ///
    /// unsafe {
    ///     // Overschrijf geheugen met 4, 5, 6
    ///     for i in 0..len as isize {
    ///         ptr::write(p.offset(i), 4 + i);
    ///     }
    ///
    ///     // Zet alles weer samen in een Vec
    ///     let rebuilt = Vec::from_raw_parts_in(p, len, cap, alloc.clone());
    ///     assert_eq!(rebuilt, [4, 5, 6]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, length: usize, capacity: usize, alloc: A) -> Self {
        unsafe { Vec { buf: RawVec::from_raw_parts_in(ptr, capacity, alloc), len: length } }
    }

    /// Ontleedt een `Vec<T>` in zijn onbewerkte componenten.
    ///
    /// Retourneert de onbewerkte pointer naar de onderliggende gegevens, de lengte van de vector (in elementen) en de toegewezen capaciteit van de gegevens (in elementen).
    /// Dit zijn dezelfde argumenten in dezelfde volgorde als de argumenten voor [`from_raw_parts`].
    ///
    /// Na het aanroepen van deze functie is de beller verantwoordelijk voor het geheugen dat voorheen door de `Vec` werd beheerd.
    /// De enige manier om dit te doen, is door de onbewerkte pointer, lengte en capaciteit terug te converteren naar een `Vec` met de [`from_raw_parts`]-functie, zodat de destructor de opruiming kan uitvoeren.
    ///
    ///
    /// [`from_raw_parts`]: Vec::from_raw_parts
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_into_raw_parts)]
    /// let v: Vec<i32> = vec![-1, 0, 1];
    ///
    /// let (ptr, len, cap) = v.into_raw_parts();
    ///
    /// let rebuilt = unsafe {
    ///     // We kunnen nu wijzigingen aanbrengen in de componenten, zoals het transmuteren van de onbewerkte pointer naar een compatibel type.
    /////
    ///     let ptr = ptr as *mut u32;
    ///
    ///     Vec::from_raw_parts(ptr, len, cap)
    /// };
    /// assert_eq!(rebuilt, [4294967295, 0, 1]);
    /// ```
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts(self) -> (*mut T, usize, usize) {
        let mut me = ManuallyDrop::new(self);
        (me.as_mut_ptr(), me.len(), me.capacity())
    }

    /// Ontleedt een `Vec<T>` in zijn onbewerkte componenten.
    ///
    /// Retourneert de onbewerkte pointer naar de onderliggende gegevens, de lengte van de vector (in elementen), de toegewezen capaciteit van de gegevens (in elementen) en de allocator.
    /// Dit zijn dezelfde argumenten in dezelfde volgorde als de argumenten voor [`from_raw_parts_in`].
    ///
    /// Na het aanroepen van deze functie is de beller verantwoordelijk voor het geheugen dat voorheen door de `Vec` werd beheerd.
    /// De enige manier om dit te doen, is door de onbewerkte pointer, lengte en capaciteit terug te converteren naar een `Vec` met de [`from_raw_parts_in`]-functie, zodat de destructor de opruiming kan uitvoeren.
    ///
    ///
    /// [`from_raw_parts_in`]: Vec::from_raw_parts_in
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, vec_into_raw_parts)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut v: Vec<i32, System> = Vec::new_in(System);
    /// v.push(-1);
    /// v.push(0);
    /// v.push(1);
    ///
    /// let (ptr, len, cap, alloc) = v.into_raw_parts_with_alloc();
    ///
    /// let rebuilt = unsafe {
    ///     // We kunnen nu wijzigingen aanbrengen in de componenten, zoals het transmuteren van de onbewerkte pointer naar een compatibel type.
    /////
    ///     let ptr = ptr as *mut u32;
    ///
    ///     Vec::from_raw_parts_in(ptr, len, cap, alloc)
    /// };
    /// assert_eq!(rebuilt, [4294967295, 0, 1]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts_with_alloc(self) -> (*mut T, usize, usize, A) {
        let mut me = ManuallyDrop::new(self);
        let len = me.len();
        let capacity = me.capacity();
        let ptr = me.as_mut_ptr();
        let alloc = unsafe { ptr::read(me.allocator()) };
        (ptr, len, capacity, alloc)
    }

    /// Geeft het aantal elementen terug dat de vector kan bevatten zonder opnieuw toe te wijzen.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let vec: Vec<i32> = Vec::with_capacity(10);
    /// assert_eq!(vec.capacity(), 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.buf.capacity()
    }

    /// Reserveert capaciteit voor minstens `additional` meer elementen die in de gegeven `Vec<T>` moeten worden ingevoegd.
    /// De collectie kan meer ruimte reserveren om frequente herverdelingen te voorkomen.
    /// Nadat `reserve` is aangeroepen, is de capaciteit groter dan of gelijk aan `self.len() + additional`.
    /// Doet niets als de capaciteit al voldoende is.
    ///
    /// # Panics
    ///
    /// Panics als de nieuwe capaciteit groter is dan `isize::MAX` bytes.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.reserve(10);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.buf.reserve(self.len, additional);
    }

    /// Reserveert de minimumcapaciteit voor precies `additional` meer elementen die in de gegeven `Vec<T>` moeten worden ingevoegd.
    ///
    /// Nadat `reserve_exact` is aangeroepen, is de capaciteit groter dan of gelijk aan `self.len() + additional`.
    /// Doet niets als de capaciteit al voldoende is.
    ///
    /// Merk op dat de allocator de collectie meer ruimte kan geven dan hij vraagt.
    /// Daarom kan er niet op worden vertrouwd dat de capaciteit precies minimaal is.
    /// Geef de voorkeur aan `reserve` als future-inserties worden verwacht.
    ///
    /// # Panics
    ///
    /// Panics als de nieuwe capaciteit overloopt `usize`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.reserve_exact(10);
    /// assert!(vec.capacity() >= 11);
    /// ```
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.buf.reserve_exact(self.len, additional);
    }

    /// Probeert capaciteit te reserveren voor ten minste `additional` meer elementen die in de gegeven `Vec<T>` moeten worden ingevoegd.
    /// De collectie kan meer ruimte reserveren om frequente herverdelingen te voorkomen.
    /// Nadat `try_reserve` is aangeroepen, is de capaciteit groter dan of gelijk aan `self.len() + additional`.
    /// Doet niets als de capaciteit al voldoende is.
    ///
    /// # Errors
    ///
    /// Als de capaciteit overstroomt of de allocator een storing meldt, wordt er een fout geretourneerd.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &[u32]) -> Result<Vec<u32>, TryReserveError> {
    ///     let mut output = Vec::new();
    ///
    ///     // Reserveer de herinnering vooraf, als we dat niet kunnen
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Nu weten we dat OOM dit niet kan midden in ons complexe werk
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // erg ingewikkeld
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[doc(alias = "realloc")]
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.buf.try_reserve(self.len, additional)
    }

    /// Probeert de minimumcapaciteit te reserveren voor exact `additional`-elementen die in de gegeven `Vec<T>` moeten worden ingevoegd.
    /// Nadat `try_reserve_exact` is aangeroepen, is de capaciteit groter dan of gelijk aan `self.len() + additional` als het `Ok(())` retourneert.
    ///
    /// Doet niets als de capaciteit al voldoende is.
    ///
    /// Merk op dat de allocator de collectie meer ruimte kan geven dan hij vraagt.
    /// Daarom kan er niet op worden vertrouwd dat de capaciteit precies minimaal is.
    /// Geef de voorkeur aan `reserve` als future-inserties worden verwacht.
    ///
    /// # Errors
    ///
    /// Als de capaciteit overstroomt of de allocator een storing meldt, wordt er een fout geretourneerd.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &[u32]) -> Result<Vec<u32>, TryReserveError> {
    ///     let mut output = Vec::new();
    ///
    ///     // Reserveer de herinnering vooraf, als we dat niet kunnen
    ///     output.try_reserve_exact(data.len())?;
    ///
    ///     // Nu weten we dat OOM dit niet kan midden in ons complexe werk
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // erg ingewikkeld
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[doc(alias = "realloc")]
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.buf.try_reserve_exact(self.len, additional)
    }

    /// Verkleint de capaciteit van de vector zoveel mogelijk.
    ///
    /// Het zal zo dicht mogelijk bij de lengte naar beneden vallen, maar de allocator kan de vector nog steeds informeren dat er ruimte is voor nog een paar elementen.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    /// assert_eq!(vec.capacity(), 10);
    /// vec.shrink_to_fit();
    /// assert!(vec.capacity() >= 3);
    /// ```
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        // De capaciteit is nooit kleiner dan de lengte, en er is niets te doen als ze gelijk zijn, dus we kunnen de panic-case in `RawVec::shrink_to_fit` vermijden door hem alleen met een grotere capaciteit te noemen.
        //
        //
        if self.capacity() > self.len {
            self.buf.shrink_to_fit(self.len);
        }
    }

    /// Verkleint de capaciteit van de vector met een ondergrens.
    ///
    /// De capaciteit blijft minimaal zo groot als zowel de lengte als de geleverde waarde.
    ///
    ///
    /// Als de huidige capaciteit lager is dan de ondergrens, is dit een no-op.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    /// assert_eq!(vec.capacity(), 10);
    /// vec.shrink_to(4);
    /// assert!(vec.capacity() >= 4);
    /// vec.shrink_to(0);
    /// assert!(vec.capacity() >= 3);
    /// ```
    #[doc(alias = "realloc")]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        if self.capacity() > min_capacity {
            self.buf.shrink_to_fit(cmp::max(self.len, min_capacity));
        }
    }

    /// Converteert de vector naar [`Box<[T]>`][owned slice].
    ///
    /// Merk op dat hierdoor de overtollige capaciteit wegvalt.
    ///
    /// [owned slice]: Box
    ///
    /// # Examples
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    ///
    /// let slice = v.into_boxed_slice();
    /// ```
    ///
    /// Eventuele overtollige capaciteit wordt verwijderd:
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    ///
    /// assert_eq!(vec.capacity(), 10);
    /// let slice = vec.into_boxed_slice();
    /// assert_eq!(slice.into_vec().capacity(), 3);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_boxed_slice(mut self) -> Box<[T], A> {
        unsafe {
            self.shrink_to_fit();
            let me = ManuallyDrop::new(self);
            let buf = ptr::read(&me.buf);
            let len = me.len();
            buf.into_box(len).assume_init()
        }
    }

    /// Verkort de vector, behoudt de eerste `len`-elementen en laat de rest vallen.
    ///
    /// Als `len` groter is dan de huidige lengte van de vector, heeft dit geen effect.
    ///
    /// De [`drain`]-methode kan `truncate` emuleren, maar zorgt ervoor dat de overtollige elementen worden geretourneerd in plaats van verwijderd.
    ///
    ///
    /// Merk op dat deze methode geen effect heeft op de toegewezen capaciteit van de vector.
    ///
    /// # Examples
    ///
    /// Een vector met vijf elementen afkappen tot twee elementen:
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4, 5];
    /// vec.truncate(2);
    /// assert_eq!(vec, [1, 2]);
    /// ```
    ///
    /// Er vindt geen afkapping plaats wanneer `len` groter is dan de huidige lengte van de vector:
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.truncate(8);
    /// assert_eq!(vec, [1, 2, 3]);
    /// ```
    ///
    /// Afkappen wanneer `len == 0` gelijk is aan het aanroepen van de [`clear`]-methode.
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.truncate(0);
    /// assert_eq!(vec, []);
    /// ```
    ///
    /// [`clear`]: Vec::clear
    /// [`drain`]: Vec::drain
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn truncate(&mut self, len: usize) {
        // Dit is veilig omdat:
        //
        // * het aan `drop_in_place` doorgegeven slice is geldig;het geval `len > self.len` vermijdt het creëren van een ongeldig segment, en
        // * de `len` van de vector wordt verkleind voordat `drop_in_place` wordt aangeroepen, zodat er geen waarde twee keer wordt weggelaten in het geval dat `drop_in_place` één keer naar panic zou gaan (als het twee keer panics is, wordt het programma afgebroken).
        //
        //
        //
        unsafe {
            // Note: Het is opzettelijk dat dit `>` is en niet `>=`.
            //       Het wijzigen naar `>=` heeft in sommige gevallen negatieve gevolgen voor de prestaties.
            //       Zie #78884 voor meer.
            if len > self.len {
                return;
            }
            let remaining_len = self.len - len;
            let s = ptr::slice_from_raw_parts_mut(self.as_mut_ptr().add(len), remaining_len);
            self.len = len;
            ptr::drop_in_place(s);
        }
    }

    /// Extraheert een segment met de volledige vector.
    ///
    /// Gelijk aan `&s[..]`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::io::{self, Write};
    /// let buffer = vec![1, 2, 3, 5, 8];
    /// io::sink().write(buffer.as_slice()).unwrap();
    /// ```
    #[inline]
    #[stable(feature = "vec_as_slice", since = "1.7.0")]
    pub fn as_slice(&self) -> &[T] {
        self
    }

    /// Extraheert een veranderlijk deel van de volledige vector.
    ///
    /// Gelijk aan `&mut s[..]`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::io::{self, Read};
    /// let mut buffer = vec![0; 3];
    /// io::repeat(0b101).read_exact(buffer.as_mut_slice()).unwrap();
    /// ```
    #[inline]
    #[stable(feature = "vec_as_slice", since = "1.7.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        self
    }

    /// Retourneert een onbewerkte pointer naar de buffer van de vector.
    ///
    /// De beller moet ervoor zorgen dat de vector de pointer overleeft die deze functie retourneert, anders zal het naar garbage wijzen.
    /// Het wijzigen van de vector kan ertoe leiden dat de buffer opnieuw wordt toegewezen, waardoor eventuele verwijzingen ernaar ongeldig worden.
    ///
    /// De beller moet er ook voor zorgen dat het geheugen waarnaar de pointer (non-transitively) verwijst, nooit wordt weggeschreven (behalve in een `UnsafeCell`) met deze pointer of een daarvan afgeleide pointer.
    /// Gebruik [`as_mut_ptr`] als u de inhoud van het segment moet muteren.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = vec![1, 2, 4];
    /// let x_ptr = x.as_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         assert_eq!(*x_ptr.add(i), 1 << i);
    ///     }
    /// }
    /// ```
    ///
    /// [`as_mut_ptr`]: Vec::as_mut_ptr
    ///
    ///
    ///
    #[stable(feature = "vec_as_ptr", since = "1.37.0")]
    #[inline]
    pub fn as_ptr(&self) -> *const T {
        // We schaduwen de slice-methode met dezelfde naam om te voorkomen dat we door `deref` gaan, wat een tussenliggende referentie creëert.
        //
        let ptr = self.buf.ptr();
        unsafe {
            assume(!ptr.is_null());
        }
        ptr
    }

    /// Retourneert een onveilige veranderlijke pointer naar de buffer van de vector.
    ///
    /// De beller moet ervoor zorgen dat de vector de pointer overleeft die deze functie retourneert, anders zal het naar garbage wijzen.
    ///
    /// Het wijzigen van de vector kan ertoe leiden dat de buffer opnieuw wordt toegewezen, waardoor eventuele verwijzingen ernaar ongeldig worden.
    ///
    /// # Examples
    ///
    /// ```
    /// // Wijs vector toe die groot genoeg is voor 4 elementen.
    /// let size = 4;
    /// let mut x: Vec<i32> = Vec::with_capacity(size);
    /// let x_ptr = x.as_mut_ptr();
    ///
    /// // Initialiseer elementen via onbewerkte pointer-schrijfbewerkingen en stel vervolgens de lengte in.
    /// unsafe {
    ///     for i in 0..size {
    ///         *x_ptr.add(i) = i as i32;
    ///     }
    ///     x.set_len(size);
    /// }
    /// assert_eq!(&*x, &[0, 1, 2, 3]);
    /// ```
    ///
    #[stable(feature = "vec_as_ptr", since = "1.37.0")]
    #[inline]
    pub fn as_mut_ptr(&mut self) -> *mut T {
        // We schaduwen de slice-methode met dezelfde naam om te voorkomen dat we door `deref_mut` gaan, wat een tussenliggende referentie creëert.
        //
        let ptr = self.buf.ptr();
        unsafe {
            assume(!ptr.is_null());
        }
        ptr
    }

    /// Retourneert een verwijzing naar de onderliggende allocator.
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn allocator(&self) -> &A {
        self.buf.allocator()
    }

    /// Forceert de lengte van de vector tot `new_len`.
    ///
    /// Dit is een bewerking op laag niveau die geen van de normale invarianten van het type handhaaft.
    /// Normaal gesproken gebeurt het wijzigen van de lengte van een vector in plaats daarvan met een van de veilige bewerkingen, zoals [`truncate`], [`resize`], [`extend`] of [`clear`].
    ///
    ///
    /// [`truncate`]: Vec::truncate
    /// [`resize`]: Vec::resize
    /// [`extend`]: Extend::extend
    /// [`clear`]: Vec::clear
    ///
    /// # Safety
    ///
    /// - `new_len` moet kleiner zijn dan of gelijk zijn aan [`capacity()`].
    /// - De elementen op `old_len..new_len` moeten worden geïnitialiseerd.
    ///
    /// [`capacity()`]: Vec::capacity
    ///
    /// # Examples
    ///
    /// Deze methode kan handig zijn voor situaties waarin de vector dient als buffer voor andere code, met name via FFI:
    ///
    /// ```no_run
    /// # #![allow(dead_code)]
    /// # // Dit is slechts een minimaal skelet voor het doc-voorbeeld;
    /// # // Gebruik dit niet als uitgangspunt voor een echte bibliotheek.
    /// # pub struct StreamWrapper { strm: *mut std::ffi::c_void }
    /// # const Z_OK: i32 = 0;
    /// # extern "C" {
    /// #     fn deflateGetDictionary(
    /// #         strm: *mut std::ffi::c_void,
    /// #         dictionary: *mut u8,
    /// #         dictLength: *mut usize,
    /// #     ) -> i32;
    /// # }
    /// # impl StreamWrapper {
    /// pub fn get_dictionary(&self) -> Option<Vec<u8>> {
    ///     // Volgens de documenten van de FFI-methode, "32768 bytes is always enough".
    ///     let mut dict = Vec::with_capacity(32_768);
    ///     let mut dict_length = 0;
    ///     // VEILIGHEID: wanneer `deflateGetDictionary` `Z_OK` retourneert, geldt het volgende:
    ///     // 1. `dict_length` elementen werden geïnitialiseerd.
    ///     // 2.
    ///     // `dict_length` <=de capaciteit (32_768) waardoor `set_len` veilig kan worden gebeld.
    ///     unsafe {
    ///         // Doe de FFI-oproep ...
    ///         let r = deflateGetDictionary(self.strm, dict.as_mut_ptr(), &mut dict_length);
    ///         if r == Z_OK {
    ///             // ... en werk de lengte bij naar wat werd geïnitialiseerd.
    ///             dict.set_len(dict_length);
    ///             Some(dict)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    /// # }
    /// ```
    ///
    /// Hoewel het volgende voorbeeld geluid is, is er een geheugenlek aangezien de binnenste vectors niet werd vrijgemaakt voorafgaand aan de `set_len`-aanroep:
    ///
    /// ```
    /// let mut vec = vec![vec![1, 0, 0],
    ///                    vec![0, 1, 0],
    ///                    vec![0, 0, 1]];
    /// // SAFETY:
    /// // 1. `old_len..0` is leeg, dus er hoeven geen elementen te worden geïnitialiseerd.
    /// // 2. `0 <= capacity` bevat altijd wat `capacity` is.
    /// unsafe {
    ///     vec.set_len(0);
    /// }
    /// ```
    ///
    /// Normaal gesproken zou men hier in plaats daarvan [`clear`] gebruiken om de inhoud correct te laten vallen en dus geen geheugen te lekken.
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn set_len(&mut self, new_len: usize) {
        debug_assert!(new_len <= self.capacity());

        self.len = new_len;
    }

    /// Verwijdert een element uit de vector en geeft het terug.
    ///
    /// Het verwijderde element wordt vervangen door het laatste element van de vector.
    ///
    /// Dit behoudt de ordening niet, maar is O(1).
    ///
    /// # Panics
    ///
    /// Panics als `index` buiten het bereik is.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec!["foo", "bar", "baz", "qux"];
    ///
    /// assert_eq!(v.swap_remove(1), "bar");
    /// assert_eq!(v, ["foo", "qux", "baz"]);
    ///
    /// assert_eq!(v.swap_remove(0), "foo");
    /// assert_eq!(v, ["baz", "qux"]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn swap_remove(&mut self, index: usize) -> T {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("swap_remove index (is {}) should be < len (is {})", index, len);
        }

        let len = self.len();
        if index >= len {
            assert_failed(index, len);
        }
        unsafe {
            // We vervangen self [index] door het laatste element.
            // Merk op dat als de bovenstaande grenscontrole slaagt, er een laatste element moet zijn (dat zelf [index] zelf kan zijn).
            //
            let last = ptr::read(self.as_ptr().add(len - 1));
            let hole = self.as_mut_ptr().add(index);
            self.set_len(len - 1);
            ptr::replace(hole, last)
        }
    }

    /// Voegt een element in op positie `index` binnen de vector, waarbij alle elementen erna naar rechts worden verschoven.
    ///
    ///
    /// # Panics
    ///
    /// Panics als `index > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.insert(1, 4);
    /// assert_eq!(vec, [1, 4, 2, 3]);
    /// vec.insert(4, 5);
    /// assert_eq!(vec, [1, 4, 2, 3, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn insert(&mut self, index: usize, element: T) {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("insertion index (is {}) should be <= len (is {})", index, len);
        }

        let len = self.len();
        if index > len {
            assert_failed(index, len);
        }

        // ruimte voor het nieuwe element
        if len == self.buf.capacity() {
            self.reserve(1);
        }

        unsafe {
            // onfeilbaar De plek om de nieuwe waarde te plaatsen
            //
            {
                let p = self.as_mut_ptr().add(index);
                // Verschuif alles om ruimte te maken.
                // (Het 'index'-element dupliceren op twee opeenvolgende plaatsen.)
                ptr::copy(p, p.offset(1), len - index);
                // Schrijf het in en overschrijf de eerste kopie van het 'index'-element.
                //
                ptr::write(p, element);
            }
            self.set_len(len + 1);
        }
    }

    /// Verwijdert en retourneert het element op positie `index` binnen de vector, waarbij alle elementen erna naar links worden verschoven.
    ///
    ///
    /// # Panics
    ///
    /// Panics als `index` buiten het bereik is.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// assert_eq!(v.remove(1), 2);
    /// assert_eq!(v, [1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, index: usize) -> T {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("removal index (is {}) should be < len (is {})", index, len);
        }

        let len = self.len();
        if index >= len {
            assert_failed(index, len);
        }
        unsafe {
            // infallible
            let ret;
            {
                // de plaats waar we vandaan komen.
                let ptr = self.as_mut_ptr().add(index);
                // kopieer het uit, onveilig met tegelijkertijd een kopie van de waarde op de stapel en in de vector.
                //
                ret = ptr::read(ptr);

                // Schuif alles naar beneden om die plek in te vullen.
                ptr::copy(ptr.offset(1), ptr, len - index - 1);
            }
            self.set_len(len - 1);
            ret
        }
    }

    /// Behoudt alleen de elementen die zijn gespecificeerd door het predikaat.
    ///
    /// Met andere woorden, verwijder alle elementen `e` zodat `f(&e)` `false` retourneert.
    /// Deze methode werkt op zijn plaats, bezoekt elk element precies één keer in de oorspronkelijke volgorde en behoudt de volgorde van de behouden elementen.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4];
    /// vec.retain(|&x| x % 2 == 0);
    /// assert_eq!(vec, [2, 4]);
    /// ```
    ///
    /// Omdat de elementen precies één keer in de oorspronkelijke volgorde worden bezocht, kan de externe toestand worden gebruikt om te beslissen welke elementen behouden moeten worden.
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4, 5];
    /// let keep = [false, true, true, false, true];
    /// let mut iter = keep.iter();
    /// vec.retain(|_| *iter.next().unwrap());
    /// assert_eq!(vec, [2, 3, 5]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> bool,
    {
        let original_len = self.len();
        // Voorkom dubbele val als de valbeschermer niet is uitgevoerd, aangezien we tijdens het proces enkele gaten kunnen maken.
        //
        unsafe { self.set_len(0) };

        // Vec: [Kept, Kept, Hole, Hole, Hole, Hole, Unchecked, Unchecked]
        //      | <-verwerkt len-> |^-naast om te controleren
        //                  | <-verwijderde cnt-> |
        //      | <-original_len-> |Kept: Elementen waarvan het predikaat true retourneert.
        //
        // Hole: Verplaatste of neergelaten elementensleuf.
        // Niet aangevinkt: niet aangevinkte geldige elementen.
        //
        // Deze drop guard wordt aangeroepen wanneer predikaat of `drop` van element in paniek raakt.
        // Het verschuift ongecontroleerde elementen om gaten te bedekken en `set_len` naar de juiste lengte.
        // In gevallen waarin predikaat en `drop` nooit in paniek raken, wordt het geoptimaliseerd.
        struct BackshiftOnDrop<'a, T, A: Allocator> {
            v: &'a mut Vec<T, A>,
            processed_len: usize,
            deleted_cnt: usize,
            original_len: usize,
        }

        impl<T, A: Allocator> Drop for BackshiftOnDrop<'_, T, A> {
            fn drop(&mut self) {
                if self.deleted_cnt > 0 {
                    // VEILIGHEID: Niet-aangevinkte items die achterblijven, moeten geldig zijn, aangezien we ze nooit aanraken.
                    unsafe {
                        ptr::copy(
                            self.v.as_ptr().add(self.processed_len),
                            self.v.as_mut_ptr().add(self.processed_len - self.deleted_cnt),
                            self.original_len - self.processed_len,
                        );
                    }
                }
                // VEILIGHEID: Nadat de gaten zijn gevuld, bevinden alle items zich in een aangrenzend geheugen.
                unsafe {
                    self.v.set_len(self.original_len - self.deleted_cnt);
                }
            }
        }

        let mut g = BackshiftOnDrop { v: self, processed_len: 0, deleted_cnt: 0, original_len };

        while g.processed_len < original_len {
            // VEILIGHEID: Niet aangevinkt element moet geldig zijn.
            let cur = unsafe { &mut *g.v.as_mut_ptr().add(g.processed_len) };
            if !f(cur) {
                // Ga vroeg vooruit om dubbele val te voorkomen als `drop_in_place` in paniek raakte.
                g.processed_len += 1;
                g.deleted_cnt += 1;
                // VEILIGHEID: We raken dit element nooit meer aan nadat het is gevallen.
                unsafe { ptr::drop_in_place(cur) };
                // We hebben de toonbank al vooruitgeschoven.
                continue;
            }
            if g.deleted_cnt > 0 {
                // VEILIGHEID: `deleted_cnt`> 0, dus de gatsleuf mag het huidige element niet overlappen.
                // We gebruiken kopiëren voor verplaatsing en raken dit element nooit meer aan.
                unsafe {
                    let hole_slot = g.v.as_mut_ptr().add(g.processed_len - g.deleted_cnt);
                    ptr::copy_nonoverlapping(cur, hole_slot, 1);
                }
            }
            g.processed_len += 1;
        }

        // Alle items zijn verwerkt.Dit kan door LLVM worden geoptimaliseerd naar `set_len`.
        drop(g);
    }

    /// Verwijdert alle opeenvolgende elementen in de vector, behalve de eerste, die naar dezelfde sleutel leiden.
    ///
    ///
    /// Als de vector is gesorteerd, worden alle duplicaten verwijderd.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![10, 20, 21, 30, 20];
    ///
    /// vec.dedup_by_key(|i| *i / 10);
    ///
    /// assert_eq!(vec, [10, 20, 30, 20]);
    /// ```
    #[stable(feature = "dedup_by", since = "1.16.0")]
    #[inline]
    pub fn dedup_by_key<F, K>(&mut self, mut key: F)
    where
        F: FnMut(&mut T) -> K,
        K: PartialEq,
    {
        self.dedup_by(|a, b| key(a) == key(b))
    }

    /// Verwijdert alle elementen behalve de eerste van opeenvolgende elementen in de vector die voldoen aan een gegeven gelijkheidsrelatie.
    ///
    /// De `same_bucket`-functie krijgt verwijzingen naar twee elementen uit de vector en moet bepalen of de elementen gelijk zijn.
    /// De elementen worden doorgegeven in tegengestelde volgorde van hun volgorde in het segment, dus als `same_bucket(a, b)` `true` retourneert, wordt `a` verwijderd.
    ///
    ///
    /// Als de vector is gesorteerd, worden alle duplicaten verwijderd.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec!["foo", "bar", "Bar", "baz", "bar"];
    ///
    /// vec.dedup_by(|a, b| a.eq_ignore_ascii_case(b));
    ///
    /// assert_eq!(vec, ["foo", "bar", "baz", "bar"]);
    /// ```
    ///
    #[stable(feature = "dedup_by", since = "1.16.0")]
    pub fn dedup_by<F>(&mut self, mut same_bucket: F)
    where
        F: FnMut(&mut T, &mut T) -> bool,
    {
        let len = self.len();
        if len <= 1 {
            return;
        }

        /* INVARIANT: vec.len() > read >= write > write-1 >= 0 */
        struct FillGapOnDrop<'a, T, A: core::alloc::Allocator> {
            /* Offset of the element we want to check if it is duplicate */
            read: usize,

            /* Offset of the place where we want to place the non-duplicate
             * when we find it. */
            write: usize,

            /* The Vec that would need correction if `same_bucket` panicked */
            vec: &'a mut Vec<T, A>,
        }

        impl<'a, T, A: core::alloc::Allocator> Drop for FillGapOnDrop<'a, T, A> {
            fn drop(&mut self) {
                /* This code gets executed when `same_bucket` panics */

                /* SAFETY: invariant guarantees that `read - write`
                 * and `len - read` never overflow and that the copy is always
                 * in-bounds. */
                unsafe {
                    let ptr = self.vec.as_mut_ptr();
                    let len = self.vec.len();

                    /* How many items were left when `same_bucket` paniced.
                     * Basically vec[read..].len() */
                    let items_left = len.wrapping_sub(self.read);

                    /* Pointer to first item in vec[write..write+items_left] slice */
                    let dropped_ptr = ptr.add(self.write);
                    /* Pointer to first item in vec[read..] slice */
                    let valid_ptr = ptr.add(self.read);

                    /* Copy `vec[read..]` to `vec[write..write+items_left]`.
                     * The slices can overlap, so `copy_nonoverlapping` cannot be used */
                    ptr::copy(valid_ptr, dropped_ptr, items_left);

                    /* How many items have been already dropped
                     * Basically vec[read..write].len() */
                    let dropped = self.read.wrapping_sub(self.write);

                    self.vec.set_len(len - dropped);
                }
            }
        }

        let mut gap = FillGapOnDrop { read: 1, write: 1, vec: self };
        let ptr = gap.vec.as_mut_ptr();

        /* Drop items while going through Vec, it should be more efficient than
         * doing slice partition_dedup + truncate */

        /* SAFETY: Because of the invariant, read_ptr, prev_ptr and write_ptr
         * are always in-bounds and read_ptr never aliases prev_ptr */
        unsafe {
            while gap.read < len {
                let read_ptr = ptr.add(gap.read);
                let prev_ptr = ptr.add(gap.write.wrapping_sub(1));

                if same_bucket(&mut *read_ptr, &mut *prev_ptr) {
                    /* We have found duplicate, drop it in-place */
                    ptr::drop_in_place(read_ptr);
                } else {
                    let write_ptr = ptr.add(gap.write);

                    /* Because `read_ptr` can be equal to `write_ptr`, we either
                     * have to use `copy` or conditional `copy_nonoverlapping`.
                     * Looks like the first option is faster. */
                    ptr::copy(read_ptr, write_ptr, 1);

                    /* We have filled that place, so go further */
                    gap.write += 1;
                }

                gap.read += 1;
            }

            /* Technically we could let `gap` clean up with its Drop, but
             * when `same_bucket` is guaranteed to not panic, this bloats a little
             * the codegen, so we just do it manually */
            gap.vec.set_len(gap.write);
            mem::forget(gap);
        }
    }

    /// Voegt een element toe aan de achterkant van een verzameling.
    ///
    /// # Panics
    ///
    /// Panics als de nieuwe capaciteit groter is dan `isize::MAX` bytes.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2];
    /// vec.push(3);
    /// assert_eq!(vec, [1, 2, 3]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, value: T) {
        // Dit zal panic of afgebroken als we> isize::MAX bytes zouden toewijzen of als de lengtetoename zou overlopen voor typen met een grootte van nul.
        //
        if self.len == self.buf.capacity() {
            self.reserve(1);
        }
        unsafe {
            let end = self.as_mut_ptr().add(self.len);
            ptr::write(end, value);
            self.len += 1;
        }
    }

    /// Verwijdert het laatste element uit een vector en geeft het terug, of [`None`] als het leeg is.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// assert_eq!(vec.pop(), Some(3));
    /// assert_eq!(vec, [1, 2]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<T> {
        if self.len == 0 {
            None
        } else {
            unsafe {
                self.len -= 1;
                Some(ptr::read(self.as_ptr().add(self.len())))
            }
        }
    }

    /// Verplaatst alle elementen van `other` naar `Self`, waardoor `other` leeg blijft.
    ///
    /// # Panics
    ///
    /// Panics als het aantal elementen in de vector groter is dan `usize`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// let mut vec2 = vec![4, 5, 6];
    /// vec.append(&mut vec2);
    /// assert_eq!(vec, [1, 2, 3, 4, 5, 6]);
    /// assert_eq!(vec2, []);
    /// ```
    #[inline]
    #[stable(feature = "append", since = "1.4.0")]
    pub fn append(&mut self, other: &mut Self) {
        unsafe {
            self.append_elements(other.as_slice() as _);
            other.set_len(0);
        }
    }

    /// Voegt elementen toe aan `Self` vanuit een andere buffer.
    #[inline]
    unsafe fn append_elements(&mut self, other: *const [T]) {
        let count = unsafe { (*other).len() };
        self.reserve(count);
        let len = self.len();
        unsafe { ptr::copy_nonoverlapping(other as *const T, self.as_mut_ptr().add(len), count) };
        self.len += count;
    }

    /// Creëert een drainerende iterator die het gespecificeerde bereik in de vector verwijdert en de verwijderde items oplevert.
    ///
    /// Wanneer de iterator **wordt verwijderd**, worden alle elementen in het bereik verwijderd uit de vector, zelfs als de iterator niet volledig is verbruikt.
    /// Als de iterator **niet** wordt verwijderd (met bijvoorbeeld [`mem::forget`]), is het niet gespecificeerd hoeveel elementen er worden verwijderd.
    ///
    /// # Panics
    ///
    /// Panics als het startpunt groter is dan het eindpunt of als het eindpunt groter is dan de lengte van de vector.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// let u: Vec<_> = v.drain(1..).collect();
    /// assert_eq!(v, &[1]);
    /// assert_eq!(u, &[2, 3]);
    ///
    /// // Een volledig assortiment maakt de vector leeg
    /// v.drain(..);
    /// assert_eq!(v, &[]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_, T, A>
    where
        R: RangeBounds<usize>,
    {
        // Geheugen veiligheid
        //
        // Wanneer de Drain voor het eerst wordt gemaakt, wordt de lengte van de bron vector verkort om ervoor te zorgen dat er helemaal geen niet-geïnitialiseerde of verhuisde elementen toegankelijk zijn als de destructor van de Drain nooit aan de gang komt.
        //
        //
        // Drain zal ptr::read de waarden verwijderen die moeten worden verwijderd.
        // Als u klaar bent, wordt de resterende staart van de vec teruggekopieerd om het gat te bedekken en wordt de lengte van de vector hersteld naar de nieuwe lengte.
        //
        //
        //
        let len = self.len();
        let Range { start, end } = slice::range(range, ..len);

        unsafe {
            // stel self.vec lengtes in om te starten, om er zeker van te zijn dat Drain lekt
            self.set_len(start);
            // Gebruik het lenen in de IterMut om het leengedrag van de hele Drain-iterator aan te geven (zoals &mut T).
            //
            let range_slice = slice::from_raw_parts_mut(self.as_mut_ptr().add(start), end - start);
            Drain {
                tail_start: end,
                tail_len: len - end,
                iter: range_slice.iter(),
                vec: NonNull::from(self),
            }
        }
    }

    /// Wist de vector en verwijdert alle waarden.
    ///
    /// Merk op dat deze methode geen effect heeft op de toegewezen capaciteit van de vector.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    ///
    /// v.clear();
    ///
    /// assert!(v.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.truncate(0)
    }

    /// Retourneert het aantal elementen in de vector, ook wel de 'length' genoemd.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = vec![1, 2, 3];
    /// assert_eq!(a.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.len
    }

    /// Geeft `true` terug als de vector geen elementen bevat.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = Vec::new();
    /// assert!(v.is_empty());
    ///
    /// v.push(1);
    /// assert!(!v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Splitst de verzameling in twee bij de opgegeven index.
    ///
    /// Geeft een nieuw toegewezen vector terug die de elementen in het bereik `[at, len)` bevat.
    /// Na de oproep blijft de originele vector achter met de elementen `[0, at)` met de vorige capaciteit ongewijzigd.
    ///
    ///
    /// # Panics
    ///
    /// Panics als `at > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// let vec2 = vec.split_off(1);
    /// assert_eq!(vec, [1]);
    /// assert_eq!(vec2, [2, 3]);
    /// ```
    #[inline]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    #[stable(feature = "split_off", since = "1.4.0")]
    pub fn split_off(&mut self, at: usize) -> Self
    where
        A: Clone,
    {
        #[cold]
        #[inline(never)]
        fn assert_failed(at: usize, len: usize) -> ! {
            panic!("`at` split index (is {}) should be <= len (is {})", at, len);
        }

        if at > self.len() {
            assert_failed(at, self.len());
        }

        if at == 0 {
            // de nieuwe vector kan de originele buffer overnemen en de kopie vermijden
            return mem::replace(
                self,
                Vec::with_capacity_in(self.capacity(), self.allocator().clone()),
            );
        }

        let other_len = self.len - at;
        let mut other = Vec::with_capacity_in(other_len, self.allocator().clone());

        // Maak `set_len` onveilig en kopieer items naar `other`.
        unsafe {
            self.set_len(at);
            other.set_len(other_len);

            ptr::copy_nonoverlapping(self.as_ptr().add(at), other.as_mut_ptr(), other.len());
        }
        other
    }

    /// Wijzigt de grootte van de `Vec` op zijn plaats zodat `len` gelijk is aan `new_len`.
    ///
    /// Als `new_len` groter is dan `len`, wordt de `Vec` uitgebreid met het verschil, waarbij elke extra sleuf wordt gevuld met het resultaat van het aanroepen van de sluiting `f`.
    ///
    /// De retourwaarden van `f` komen in de `Vec` terecht in de volgorde waarin ze zijn gegenereerd.
    ///
    /// Als `new_len` kleiner is dan `len`, wordt de `Vec` eenvoudigweg afgekapt.
    ///
    /// Deze methode maakt gebruik van een sluiting om bij elke push nieuwe waarden te creëren.Als je liever een [`Clone`] een bepaalde waarde hebt, gebruik dan [`Vec::resize`].
    /// Als je de [`Default`] trait wilt gebruiken om waarden te genereren, kun je [`Default::default`] doorgeven als het tweede argument.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.resize_with(5, Default::default);
    /// assert_eq!(vec, [1, 2, 3, 0, 0]);
    ///
    /// let mut vec = vec![];
    /// let mut p = 1;
    /// vec.resize_with(4, || { p *= 2; p });
    /// assert_eq!(vec, [2, 4, 8, 16]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "vec_resize_with", since = "1.33.0")]
    pub fn resize_with<F>(&mut self, new_len: usize, f: F)
    where
        F: FnMut() -> T,
    {
        let len = self.len();
        if new_len > len {
            self.extend_with(new_len - len, ExtendFunc(f));
        } else {
            self.truncate(new_len);
        }
    }

    /// Verbruikt en lekt de `Vec`, waarbij een veranderlijke verwijzing naar de inhoud wordt geretourneerd, `&'a mut [T]`.
    /// Merk op dat het type `T` de gekozen levensduur `'a` moet overleven.
    /// Als het type alleen statische referenties heeft, of helemaal geen, dan kan dit worden gekozen als `'static`.
    ///
    /// Deze functie is vergelijkbaar met de [`leak`][Box::leak]-functie op [`Box`], behalve dat er geen manier is om het gelekte geheugen te herstellen.
    ///
    ///
    /// Deze functie is vooral handig voor gegevens die de rest van de levensduur van het programma meegaan.
    /// Het laten vallen van de geretourneerde referentie veroorzaakt een geheugenlek.
    ///
    /// # Examples
    ///
    /// Eenvoudig gebruik:
    ///
    /// ```
    /// let x = vec![1, 2, 3];
    /// let static_ref: &'static mut [usize] = x.leak();
    /// static_ref[0] += 1;
    /// assert_eq!(static_ref, &[2, 2, 3]);
    /// ```
    ///
    ///
    #[stable(feature = "vec_leak", since = "1.47.0")]
    #[inline]
    pub fn leak<'a>(self) -> &'a mut [T]
    where
        A: 'a,
    {
        Box::leak(self.into_boxed_slice())
    }

    /// Retourneert de resterende reservecapaciteit van de vector als een schijf van `MaybeUninit<T>`.
    ///
    /// Het geretourneerde segment kan worden gebruikt om de vector te vullen met gegevens (bijv
    /// door uit een bestand te lezen) voordat u de gegevens markeert als geïnitialiseerd met behulp van de [`set_len`]-methode.
    ///
    ///
    /// [`set_len`]: Vec::set_len
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_spare_capacity, maybe_uninit_extra)]
    ///
    /// // Wijs vector toe die groot genoeg is voor 10 elementen.
    /// let mut v = Vec::with_capacity(10);
    ///
    /// // Vul de eerste 3 elementen in.
    /// let uninit = v.spare_capacity_mut();
    /// uninit[0].write(0);
    /// uninit[1].write(1);
    /// uninit[2].write(2);
    ///
    /// // Markeer de eerste 3 elementen van de vector als geïnitialiseerd.
    /// unsafe {
    ///     v.set_len(3);
    /// }
    ///
    /// assert_eq!(&v, &[0, 1, 2]);
    /// ```
    ///
    #[unstable(feature = "vec_spare_capacity", issue = "75017")]
    #[inline]
    pub fn spare_capacity_mut(&mut self) -> &mut [MaybeUninit<T>] {
        // Note:
        // Deze methode is niet geïmplementeerd in termen van `split_at_spare_mut`, om ongeldigmaking van verwijzingen naar de buffer te voorkomen.
        //
        unsafe {
            slice::from_raw_parts_mut(
                self.as_mut_ptr().add(self.len) as *mut MaybeUninit<T>,
                self.buf.capacity() - self.len,
            )
        }
    }

    /// Geeft vector-inhoud terug als een plak van `T`, samen met de resterende reservecapaciteit van de vector als een plak van `MaybeUninit<T>`.
    ///
    /// De geretourneerde schijf met reservecapaciteit kan worden gebruikt om de vector met gegevens te vullen (bijvoorbeeld door uit een bestand te lezen) voordat de gegevens worden gemarkeerd als geïnitialiseerd met behulp van de [`set_len`]-methode.
    ///
    /// [`set_len`]: Vec::set_len
    ///
    /// Merk op dat dit een low-level API is, die met zorg moet worden gebruikt voor optimalisatiedoeleinden.
    /// Als u gegevens aan een `Vec` moet toevoegen, kunt u [`push`], [`extend`], [`extend_from_slice`], [`extend_from_within`], [`insert`], [`append`], [`resize`] of [`resize_with`] gebruiken, afhankelijk van uw exacte behoeften.
    ///
    ///
    /// [`push`]: Vec::push
    /// [`extend`]: Vec::extend
    /// [`extend_from_slice`]: Vec::extend_from_slice
    /// [`extend_from_within`]: Vec::extend_from_within
    /// [`insert`]: Vec::insert
    /// [`append`]: Vec::append
    /// [`resize`]: Vec::resize
    /// [`resize_with`]: Vec::resize_with
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_split_at_spare, maybe_uninit_extra)]
    ///
    /// let mut v = vec![1, 1, 2];
    ///
    /// // Reserveer extra ruimte die groot genoeg is voor 10 elementen.
    /// v.reserve(10);
    ///
    /// let (init, uninit) = v.split_at_spare_mut();
    /// let sum = init.iter().copied().sum::<u32>();
    ///
    /// // Vul de volgende 4 elementen in.
    /// uninit[0].write(sum);
    /// uninit[1].write(sum * 2);
    /// uninit[2].write(sum * 3);
    /// uninit[3].write(sum * 4);
    ///
    /// // Markeer de 4 elementen van de vector als geïnitialiseerd.
    /// unsafe {
    ///     let len = v.len();
    ///     v.set_len(len + 4);
    /// }
    ///
    /// assert_eq!(&v, &[1, 1, 2, 4, 8, 12, 16]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_split_at_spare", issue = "81944")]
    #[inline]
    pub fn split_at_spare_mut(&mut self) -> (&mut [T], &mut [MaybeUninit<T>]) {
        // SAFETY:
        // - len wordt genegeerd en dus nooit gewijzigd
        let (init, spare, _) = unsafe { self.split_at_spare_mut_with_len() };
        (init, spare)
    }

    /// Veiligheid: het wijzigen van geretourneerde .2 (&mut usize) wordt als hetzelfde beschouwd als het aanroepen van `.set_len(_)`.
    ///
    /// Deze methode wordt gebruikt om unieke toegang te hebben tot alle vec-onderdelen tegelijk in `extend_from_within`.
    unsafe fn split_at_spare_mut_with_len(
        &mut self,
    ) -> (&mut [T], &mut [MaybeUninit<T>], &mut usize) {
        let Range { start: ptr, end: spare_ptr } = self.as_mut_ptr_range();
        let spare_ptr = spare_ptr.cast::<MaybeUninit<T>>();
        let spare_len = self.buf.capacity() - self.len;

        // SAFETY:
        // - `ptr` is gegarandeerd geldig voor `len`-elementen
        // - `spare_ptr` wijst een element voorbij de buffer, zodat het niet overlapt met `initialized`
        unsafe {
            let initialized = slice::from_raw_parts_mut(ptr, self.len);
            let spare = slice::from_raw_parts_mut(spare_ptr, spare_len);

            (initialized, spare, &mut self.len)
        }
    }
}

impl<T: Clone, A: Allocator> Vec<T, A> {
    /// Wijzigt de grootte van de `Vec` op zijn plaats zodat `len` gelijk is aan `new_len`.
    ///
    /// Als `new_len` groter is dan `len`, wordt de `Vec` uitgebreid met het verschil, waarbij elke extra sleuf wordt gevuld met `value`.
    ///
    /// Als `new_len` kleiner is dan `len`, wordt de `Vec` eenvoudigweg afgekapt.
    ///
    /// Deze methode vereist `T` om [`Clone`] te implementeren om de doorgegeven waarde te kunnen klonen.
    /// Als u meer flexibiliteit nodig heeft (of wilt vertrouwen op [`Default`] in plaats van [`Clone`]), gebruik dan [`Vec::resize_with`].
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec!["hello"];
    /// vec.resize(3, "world");
    /// assert_eq!(vec, ["hello", "world", "world"]);
    ///
    /// let mut vec = vec![1, 2, 3, 4];
    /// vec.resize(2, 0);
    /// assert_eq!(vec, [1, 2]);
    /// ```
    ///
    ///
    #[stable(feature = "vec_resize", since = "1.5.0")]
    pub fn resize(&mut self, new_len: usize, value: T) {
        let len = self.len();

        if new_len > len {
            self.extend_with(new_len - len, ExtendElement(value))
        } else {
            self.truncate(new_len);
        }
    }

    /// Klonen en voegt alle elementen in een plak toe aan de `Vec`.
    ///
    /// Itereert over de slice `other`, kloont elk element en voegt het vervolgens toe aan deze `Vec`.
    /// De `other` vector wordt op volgorde doorlopen.
    ///
    /// Merk op dat deze functie hetzelfde is als [`extend`], behalve dat het gespecialiseerd is om in plaats daarvan met segmenten te werken.
    ///
    /// Als en wanneer Rust specialisatie krijgt, zal deze functie waarschijnlijk verouderd zijn (maar nog steeds beschikbaar).
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.extend_from_slice(&[2, 3, 4]);
    /// assert_eq!(vec, [1, 2, 3, 4]);
    /// ```
    ///
    /// [`extend`]: Vec::extend
    ///
    #[stable(feature = "vec_extend_from_slice", since = "1.6.0")]
    pub fn extend_from_slice(&mut self, other: &[T]) {
        self.spec_extend(other.iter())
    }

    /// Kopieert elementen uit de `src`-reeks naar het einde van de vector.
    ///
    /// ## Examples
    ///
    /// ```
    /// #![feature(vec_extend_from_within)]
    ///
    /// let mut vec = vec![0, 1, 2, 3, 4];
    ///
    /// vec.extend_from_within(2..);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4]);
    ///
    /// vec.extend_from_within(..2);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4, 0, 1]);
    ///
    /// vec.extend_from_within(4..8);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4, 0, 1, 4, 2, 3, 4]);
    /// ```
    #[unstable(feature = "vec_extend_from_within", issue = "81656")]
    pub fn extend_from_within<R>(&mut self, src: R)
    where
        R: RangeBounds<usize>,
    {
        let range = slice::range(src, ..self.len());
        self.reserve(range.len());

        // SAFETY:
        // - `slice::range` garandeert dat het opgegeven bereik geldig is voor het indexeren van self
        unsafe {
            self.spec_extend_from_within(range);
        }
    }
}

// Deze code generaliseert `extend_with_{element,default}`.
trait ExtendWith<T> {
    fn next(&mut self) -> T;
    fn last(self) -> T;
}

struct ExtendElement<T>(T);
impl<T: Clone> ExtendWith<T> for ExtendElement<T> {
    fn next(&mut self) -> T {
        self.0.clone()
    }
    fn last(self) -> T {
        self.0
    }
}

struct ExtendDefault;
impl<T: Default> ExtendWith<T> for ExtendDefault {
    fn next(&mut self) -> T {
        Default::default()
    }
    fn last(self) -> T {
        Default::default()
    }
}

struct ExtendFunc<F>(F);
impl<T, F: FnMut() -> T> ExtendWith<T> for ExtendFunc<F> {
    fn next(&mut self) -> T {
        (self.0)()
    }
    fn last(mut self) -> T {
        (self.0)()
    }
}

impl<T, A: Allocator> Vec<T, A> {
    /// Verleng de vector met `n`-waarden, met behulp van de gegeven generator.
    fn extend_with<E: ExtendWith<T>>(&mut self, n: usize, mut value: E) {
        self.reserve(n);

        unsafe {
            let mut ptr = self.as_mut_ptr().add(self.len());
            // Gebruik SetLenOnDrop om een bug te omzeilen waarbij de compiler de winkel mogelijk niet realiseert via `ptr` tot en met self.set_len(), geen alias.
            //
            //
            let mut local_len = SetLenOnDrop::new(&mut self.len);

            // Schrijf alle elementen behalve de laatste
            for _ in 1..n {
                ptr::write(ptr, value.next());
                ptr = ptr.offset(1);
                // Verhoog de lengte in elke stap in geval next() panics
                local_len.increment_len(1);
            }

            if n > 0 {
                // We kunnen het laatste element rechtstreeks schrijven zonder onnodig te klonen
                ptr::write(ptr, value.last());
                local_len.increment_len(1);
            }

            // len ingesteld door scoopbeschermer
        }
    }
}

impl<T: PartialEq, A: Allocator> Vec<T, A> {
    /// Verwijdert opeenvolgende herhaalde elementen in de vector volgens de [`PartialEq`] trait-implementatie.
    ///
    ///
    /// Als de vector is gesorteerd, worden alle duplicaten verwijderd.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 2, 3, 2];
    ///
    /// vec.dedup();
    ///
    /// assert_eq!(vec, [1, 2, 3, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn dedup(&mut self) {
        self.dedup_by(|a, b| a == b)
    }
}

////////////////////////////////////////////////////////////////////////////////
// Interne methoden en functies
////////////////////////////////////////////////////////////////////////////////

#[doc(hidden)]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_elem<T: Clone>(elem: T, n: usize) -> Vec<T> {
    <T as SpecFromElem>::from_elem(elem, n, Global)
}

#[doc(hidden)]
#[unstable(feature = "allocator_api", issue = "32838")]
pub fn from_elem_in<T: Clone, A: Allocator>(elem: T, n: usize, alloc: A) -> Vec<T, A> {
    <T as SpecFromElem>::from_elem(elem, n, alloc)
}

trait ExtendFromWithinSpec {
    /// # Safety
    ///
    /// - `src` moet een geldige index zijn
    /// - `self.capacity() - self.len()` moet `>= src.len()` zijn
    unsafe fn spec_extend_from_within(&mut self, src: Range<usize>);
}

impl<T: Clone, A: Allocator> ExtendFromWithinSpec for Vec<T, A> {
    default unsafe fn spec_extend_from_within(&mut self, src: Range<usize>) {
        // SAFETY:
        // - len wordt pas verhoogd na het initialiseren van elementen
        let (this, spare, len) = unsafe { self.split_at_spare_mut_with_len() };

        // SAFETY:
        // - beller garandeert dat src een geldige index is
        let to_clone = unsafe { this.get_unchecked(src) };

        to_clone
            .iter()
            .cloned()
            .zip(spare.iter_mut())
            .map(|(src, dst)| dst.write(src))
            // Note:
            // - Element is zojuist geïnitialiseerd met `MaybeUninit::write`, dus het is oké om len te verhogen
            // - len wordt na elk element verhoogd om lekken te voorkomen (zie uitgave #82533)
            .for_each(|_| *len += 1);
    }
}

impl<T: Copy, A: Allocator> ExtendFromWithinSpec for Vec<T, A> {
    unsafe fn spec_extend_from_within(&mut self, src: Range<usize>) {
        let count = src.len();
        {
            let (init, spare) = self.split_at_spare_mut();

            // SAFETY:
            // - beller garandeert dat `src` een geldige index is
            let source = unsafe { init.get_unchecked(src) };

            // SAFETY:
            // - Beide aanwijzers zijn gemaakt op basis van unieke plakreferenties (`&mut [_]`), zodat ze geldig zijn en elkaar niet overlappen.
            //
            // - Elementen zijn: Kopiëren, dus het is OK om ze te kopiëren, zonder iets met de originele waarden te doen
            // - `count` is gelijk aan de len van `source`, dus de bron is geldig voor `count`-leesbewerkingen
            // - `.reserve(count)` garandeert dat `spare.len() >= count` dus reserve geldig is voor `count`-schrijfbewerkingen
            //
            //
            //
            unsafe { ptr::copy_nonoverlapping(source.as_ptr(), spare.as_mut_ptr() as _, count) };
        }

        // SAFETY:
        // - De elementen zijn zojuist geïnitialiseerd door `copy_nonoverlapping`
        self.len += count;
    }
}

////////////////////////////////////////////////////////////////////////////////
// Veelgebruikte trait-implementaties voor Vec
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> ops::Deref for Vec<T, A> {
    type Target = [T];

    fn deref(&self) -> &[T] {
        unsafe { slice::from_raw_parts(self.as_ptr(), self.len) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> ops::DerefMut for Vec<T, A> {
    fn deref_mut(&mut self) -> &mut [T] {
        unsafe { slice::from_raw_parts_mut(self.as_mut_ptr(), self.len) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone, A: Allocator + Clone> Clone for Vec<T, A> {
    #[cfg(not(test))]
    fn clone(&self) -> Self {
        let alloc = self.allocator().clone();
        <[T]>::to_vec_in(&**self, alloc)
    }

    // HACK(japaric): met cfg(test) is de inherente `[T]::to_vec`-methode, die vereist is voor deze methodedefinitie, niet beschikbaar.
    // Gebruik in plaats daarvan de `slice::to_vec`-functie die alleen beschikbaar is met cfg(test) NB zie de slice::hack-module in slice.rs voor meer informatie
    //
    //
    #[cfg(test)]
    fn clone(&self) -> Self {
        let alloc = self.allocator().clone();
        crate::slice::to_vec(&**self, alloc)
    }

    fn clone_from(&mut self, other: &Self) {
        // laat alles vallen dat niet zal worden overschreven
        self.truncate(other.len());

        // self.len <= other.len vanwege het afkappen hierboven, dus de segmenten hier zijn altijd in-bounds.
        //
        let (init, tail) = other.split_at(self.len());

        // hergebruik de ingesloten waarden allocations/resources.
        self.clone_from_slice(init);
        self.extend_from_slice(tail);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Hash, A: Allocator> Hash for Vec<T, A> {
    #[inline]
    fn hash<H: Hasher>(&self, state: &mut H) {
        Hash::hash(&**self, state)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "vector indices are of type `usize` or ranges of `usize`",
    label = "vector indices are of type `usize` or ranges of `usize`"
)]
impl<T, I: SliceIndex<[T]>, A: Allocator> Index<I> for Vec<T, A> {
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &Self::Output {
        Index::index(&**self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "vector indices are of type `usize` or ranges of `usize`",
    label = "vector indices are of type `usize` or ranges of `usize`"
)]
impl<T, I: SliceIndex<[T]>, A: Allocator> IndexMut<I> for Vec<T, A> {
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut Self::Output {
        IndexMut::index_mut(&mut **self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> FromIterator<T> for Vec<T> {
    #[inline]
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> Vec<T> {
        <Self as SpecFromIter<T, I::IntoIter>>::from_iter(iter.into_iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> IntoIterator for Vec<T, A> {
    type Item = T;
    type IntoIter = IntoIter<T, A>;

    /// Creëert een consumerende iterator, dat wil zeggen een die elke waarde uit de vector verplaatst (van begin tot einde).
    /// De vector kan na het aanroepen niet worden gebruikt.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = vec!["a".to_string(), "b".to_string()];
    /// for s in v.into_iter() {
    ///     // s heeft het type String, niet &String
    ///     println!("{}", s);
    /// }
    /// ```
    ///
    #[inline]
    fn into_iter(self) -> IntoIter<T, A> {
        unsafe {
            let mut me = ManuallyDrop::new(self);
            let alloc = ptr::read(me.allocator());
            let begin = me.as_mut_ptr();
            let end = if mem::size_of::<T>() == 0 {
                arith_offset(begin as *const i8, me.len() as isize) as *const T
            } else {
                begin.add(me.len()) as *const T
            };
            let cap = me.buf.capacity();
            IntoIter {
                buf: NonNull::new_unchecked(begin),
                phantom: PhantomData,
                cap,
                alloc,
                ptr: begin,
                end,
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, A: Allocator> IntoIterator for &'a Vec<T, A> {
    type Item = &'a T;
    type IntoIter = slice::Iter<'a, T>;

    fn into_iter(self) -> slice::Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, A: Allocator> IntoIterator for &'a mut Vec<T, A> {
    type Item = &'a mut T;
    type IntoIter = slice::IterMut<'a, T>;

    fn into_iter(self) -> slice::IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> Extend<T> for Vec<T, A> {
    #[inline]
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        <Self as SpecExtend<T, I::IntoIter>>::spec_extend(self, iter.into_iter())
    }

    #[inline]
    fn extend_one(&mut self, item: T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

impl<T, A: Allocator> Vec<T, A> {
    // leaf-methode waaraan verschillende SpecFrom/SpecExtend-implementaties delegeren wanneer ze geen verdere optimalisaties hebben om toe te passen
    //
    fn extend_desugared<I: Iterator<Item = T>>(&mut self, mut iterator: I) {
        // Dit is het geval voor een algemene iterator.
        //
        // Deze functie zou het morele equivalent moeten zijn van:
        //
        //      voor item in iterator {
        //          self.push(item);
        //      }
        while let Some(element) = iterator.next() {
            let len = self.len();
            if len == self.capacity() {
                let (lower, _) = iterator.size_hint();
                self.reserve(lower.saturating_add(1));
            }
            unsafe {
                ptr::write(self.as_mut_ptr().add(len), element);
                // NB kan niet overlopen omdat we de adresruimte hadden moeten toewijzen
                self.set_len(len + 1);
            }
        }
    }

    /// Creëert een splitsing-iterator die het gespecificeerde bereik in de vector vervangt door de gegeven `replace_with`-iterator en de verwijderde items oplevert.
    ///
    /// `replace_with` hoeft niet dezelfde lengte te hebben als `range`.
    ///
    /// `range` wordt verwijderd, zelfs als de iterator niet tot het einde wordt verbruikt.
    ///
    /// Het is niet gespecificeerd hoeveel elementen uit de vector worden verwijderd als de `Splice`-waarde wordt gelekt.
    ///
    /// De invoer-iterator `replace_with` wordt alleen verbruikt als de `Splice`-waarde wordt verwijderd.
    ///
    /// Dit is optimaal als:
    ///
    /// * De staart (elementen in de vector na `range`) is leeg,
    /// * of `replace_with` levert minder of gelijke elementen op dan de lengte van 'bereik'
    /// * of de ondergrens van zijn `size_hint()` is exact.
    ///
    /// Anders wordt een tijdelijke vector toegewezen en wordt de staart twee keer verplaatst.
    ///
    /// # Panics
    ///
    /// Panics als het startpunt groter is dan het eindpunt of als het eindpunt groter is dan de lengte van de vector.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// let new = [7, 8];
    /// let u: Vec<_> = v.splice(..2, new.iter().cloned()).collect();
    /// assert_eq!(v, &[7, 8, 3]);
    /// assert_eq!(u, &[1, 2]);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "vec_splice", since = "1.21.0")]
    pub fn splice<R, I>(&mut self, range: R, replace_with: I) -> Splice<'_, I::IntoIter, A>
    where
        R: RangeBounds<usize>,
        I: IntoIterator<Item = T>,
    {
        Splice { drain: self.drain(range), replace_with: replace_with.into_iter() }
    }

    /// Creëert een iterator die een afsluiting gebruikt om te bepalen of een element moet worden verwijderd.
    ///
    /// Als de sluiting waar terugkeert, wordt het element verwijderd en meegegeven.
    /// Als de afsluiting false retourneert, blijft het element in de vector en wordt het niet meegegeven door de iterator.
    ///
    /// Het gebruik van deze methode is gelijk aan de volgende code:
    ///
    /// ```
    /// # let some_predicate = |x: &mut i32| { *x == 2 || *x == 3 || *x == 6 };
    /// # let mut vec = vec![1, 2, 3, 4, 5, 6];
    /// let mut i = 0;
    /// while i != vec.len() {
    ///     if some_predicate(&mut vec[i]) {
    ///         let val = vec.remove(i);
    ///         // uw code hier
    ///     } else {
    ///         i += 1;
    ///     }
    /// }
    ///
    /// # assert_eq!(vec, vec![1, 4, 5]);
    /// ```
    ///
    /// Maar `drain_filter` is gemakkelijker te gebruiken.
    /// `drain_filter` is ook efficiënter, omdat het de elementen van de array in bulk kan terugschakelen.
    ///
    /// Merk op dat `drain_filter` u ook elk element in de filtersluiting laat muteren, ongeacht of u ervoor kiest om het te behouden of te verwijderen.
    ///
    ///
    /// # Examples
    ///
    /// Een array splitsen in evens en odds, waarbij de oorspronkelijke toewijzing opnieuw wordt gebruikt:
    ///
    /// ```
    /// #![feature(drain_filter)]
    /// let mut numbers = vec![1, 2, 3, 4, 5, 6, 8, 9, 11, 13, 14, 15];
    ///
    /// let evens = numbers.drain_filter(|x| *x % 2 == 0).collect::<Vec<_>>();
    /// let odds = numbers;
    ///
    /// assert_eq!(evens, vec![2, 4, 6, 8, 14]);
    /// assert_eq!(odds, vec![1, 3, 5, 9, 11, 13, 15]);
    /// ```
    ///
    #[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
    pub fn drain_filter<F>(&mut self, filter: F) -> DrainFilter<'_, T, F, A>
    where
        F: FnMut(&mut T) -> bool,
    {
        let old_len = self.len();

        // Bescherm ons tegen lekken (versterking van het lek)
        unsafe {
            self.set_len(0);
        }

        DrainFilter { vec: self, idx: 0, del: 0, old_len, pred: filter, panic_flag: false }
    }
}

/// Breid de implementatie uit die elementen uit referenties kopieert voordat ze naar de Vec worden gepusht.
///
/// Deze implementatie is gespecialiseerd voor slice-iterators, waar het [`copy_from_slice`] gebruikt om de hele slice in één keer toe te voegen.
///
///
/// [`copy_from_slice`]: slice::copy_from_slice
#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: Copy + 'a, A: Allocator + 'a> Extend<&'a T> for Vec<T, A> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.spec_extend(iter.into_iter())
    }

    #[inline]
    fn extend_one(&mut self, &item: &'a T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

/// Implementeert vergelijking van vectors, [lexicographically](core::cmp::Ord#lexicographical-comparison).
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialOrd, A: Allocator> PartialOrd for Vec<T, A> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        PartialOrd::partial_cmp(&**self, &**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Eq, A: Allocator> Eq for Vec<T, A> {}

/// Implementeert het bestellen van vectors, [lexicographically](core::cmp::Ord#lexicographical-comparison).
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord, A: Allocator> Ord for Vec<T, A> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        Ord::cmp(&**self, &**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T, A: Allocator> Drop for Vec<T, A> {
    fn drop(&mut self) {
        unsafe {
            // gebruik drop voor [T] gebruik een onbewerkte slice om naar de elementen van de vector te verwijzen als het zwakste noodzakelijke type;
            //
            // zou in bepaalde gevallen geldigheidskwesties kunnen vermijden
            ptr::drop_in_place(ptr::slice_from_raw_parts_mut(self.as_mut_ptr(), self.len))
        }
        // RawVec zorgt voor de deallocation
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for Vec<T> {
    /// Creëert een lege `Vec<T>`.
    fn default() -> Vec<T> {
        Vec::new()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug, A: Allocator> fmt::Debug for Vec<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> AsRef<Vec<T, A>> for Vec<T, A> {
    fn as_ref(&self) -> &Vec<T, A> {
        self
    }
}

#[stable(feature = "vec_as_mut", since = "1.5.0")]
impl<T, A: Allocator> AsMut<Vec<T, A>> for Vec<T, A> {
    fn as_mut(&mut self) -> &mut Vec<T, A> {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> AsRef<[T]> for Vec<T, A> {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "vec_as_mut", since = "1.5.0")]
impl<T, A: Allocator> AsMut<[T]> for Vec<T, A> {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> From<&[T]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: &[T]) -> Vec<T> {
        s.to_vec()
    }
    #[cfg(test)]
    fn from(s: &[T]) -> Vec<T> {
        crate::slice::to_vec(s, Global)
    }
}

#[stable(feature = "vec_from_mut", since = "1.19.0")]
impl<T: Clone> From<&mut [T]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: &mut [T]) -> Vec<T> {
        s.to_vec()
    }
    #[cfg(test)]
    fn from(s: &mut [T]) -> Vec<T> {
        crate::slice::to_vec(s, Global)
    }
}

#[stable(feature = "vec_from_array", since = "1.44.0")]
impl<T, const N: usize> From<[T; N]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: [T; N]) -> Vec<T> {
        <[T]>::into_vec(box s)
    }
    #[cfg(test)]
    fn from(s: [T; N]) -> Vec<T> {
        crate::slice::into_vec(box s)
    }
}

#[stable(feature = "vec_from_cow_slice", since = "1.14.0")]
impl<'a, T> From<Cow<'a, [T]>> for Vec<T>
where
    [T]: ToOwned<Owned = Vec<T>>,
{
    fn from(s: Cow<'a, [T]>) -> Vec<T> {
        s.into_owned()
    }
}

// note: test trekt libstd aan, wat hier fouten veroorzaakt
#[cfg(not(test))]
#[stable(feature = "vec_from_box", since = "1.18.0")]
impl<T, A: Allocator> From<Box<[T], A>> for Vec<T, A> {
    fn from(s: Box<[T], A>) -> Self {
        let len = s.len();
        Self { buf: RawVec::from_box(s), len }
    }
}

// note: test trekt libstd aan, wat hier fouten veroorzaakt
#[cfg(not(test))]
#[stable(feature = "box_from_vec", since = "1.20.0")]
impl<T, A: Allocator> From<Vec<T, A>> for Box<[T], A> {
    fn from(v: Vec<T, A>) -> Self {
        v.into_boxed_slice()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl From<&str> for Vec<u8> {
    fn from(s: &str) -> Vec<u8> {
        From::from(s.as_bytes())
    }
}

#[stable(feature = "array_try_from_vec", since = "1.48.0")]
impl<T, A: Allocator, const N: usize> TryFrom<Vec<T, A>> for [T; N] {
    type Error = Vec<T, A>;

    /// Haalt de volledige inhoud van de `Vec<T>` als een array op, als de grootte exact overeenkomt met die van de aangevraagde array.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::convert::TryInto;
    /// assert_eq!(vec![1, 2, 3].try_into(), Ok([1, 2, 3]));
    /// assert_eq!(<Vec<i32>>::new().try_into(), Ok([]));
    /// ```
    ///
    /// Als de lengte niet overeenkomt, komt de invoer terug in `Err`:
    ///
    /// ```
    /// use std::convert::TryInto;
    /// let r: Result<[i32; 4], _> = (0..10).collect::<Vec<_>>().try_into();
    /// assert_eq!(r, Err(vec![0, 1, 2, 3, 4, 5, 6, 7, 8, 9]));
    /// ```
    ///
    /// Als je het goed vindt om alleen een voorvoegsel van de `Vec<T>` te krijgen, kun je eerst [`.truncate(N)`](Vec::truncate) bellen.
    ///
    /// ```
    /// use std::convert::TryInto;
    /// let mut v = String::from("hello world").into_bytes();
    /// v.sort();
    /// v.truncate(2);
    /// let [a, b]: [_; 2] = v.try_into().unwrap();
    /// assert_eq!(a, b' ');
    /// assert_eq!(b, b'd');
    /// ```
    fn try_from(mut vec: Vec<T, A>) -> Result<[T; N], Vec<T, A>> {
        if vec.len() != N {
            return Err(vec);
        }

        // VEILIGHEID: `.set_len(0)` is altijd gezond.
        unsafe { vec.set_len(0) };

        // VEILIGHEID: De aanwijzer van een "Vec" is altijd correct uitgelijnd, en
        // de uitlijning die de array nodig heeft, is dezelfde als de items.
        // We hebben eerder gecontroleerd of we voldoende artikelen hebben.
        // De items vallen niet dubbel omdat de `set_len` de `Vec` vertelt ze ook niet te laten vallen.
        //
        let array = unsafe { ptr::read(vec.as_ptr() as *const [T; N]) };
        Ok(array)
    }
}