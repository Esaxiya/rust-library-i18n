use core::iter::{InPlaceIterable, SourceIter};
use core::mem::{self, ManuallyDrop};
use core::ptr::{self};

use super::{AsIntoIter, InPlaceDrop, SpecFromIter, SpecFromIterNested, Vec};

/// Specialisatiemarker voor het verzamelen van een iteratorpijplijn in een Vec terwijl de brontoewijzing opnieuw wordt gebruikt, dwz
/// het uitvoeren van de pijplijn op zijn plaats.
///
/// De SourceIter-ouder trait is nodig voor de specialiserende functie om toegang te krijgen tot de allocatie die moet worden hergebruikt.
/// Maar het is niet voldoende dat de specialisatie geldig is.
/// Zie aanvullende grenzen op de impl.
#[rustc_unsafe_specialization_marker]
pub(super) trait SourceIterMarker: SourceIter<Source: AsIntoIter> {}

// De std-interne SourceIter/InPlaceIterable traits worden alleen geïmplementeerd door kettingen van Adapter <Adapter<Adapter<IntoIter>>> (allemaal eigendom van core/std).
// Extra beperkingen op de adapterimplementaties (buiten `impl<I: Trait> Trait for Adapter<I>`) hangen alleen af van andere traits die al zijn gemarkeerd als specialisatie traits (Copy, TrustedRandomAccess, FusedIterator).
//
// I.e. de marker is niet afhankelijk van de levensduur van door de gebruiker geleverde typen.Modulo the Copy hole, waar verschillende andere specialisaties al van afhankelijk zijn.
//
//
impl<T> SourceIterMarker for T where T: SourceIter<Source: AsIntoIter> + InPlaceIterable {}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T> + SourceIterMarker,
{
    default fn from_iter(mut iterator: I) -> Self {
        // Aanvullende eisen die niet kunnen worden uitgedrukt via trait bounds.We vertrouwen in plaats daarvan op const eval:
        // a) geen ZST's omdat er geen toewijzing zou zijn om opnieuw te gebruiken en pointer-rekenkunde zou panic b) de grootte zou overeenkomen zoals vereist door het Alloc-contract c) de uitlijningen komen overeen zoals vereist door het Alloc-contract
        //
        //
        //
        if mem::size_of::<T>() == 0
            || mem::size_of::<T>()
                != mem::size_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
            || mem::align_of::<T>()
                != mem::align_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
        {
            // terugvallen op meer generieke implementaties
            return SpecFromIterNested::from_iter(iterator);
        }

        let (src_buf, src_ptr, dst_buf, dst_end, cap) = unsafe {
            let inner = iterator.as_inner().as_into_iter();
            (
                inner.buf.as_ptr(),
                inner.ptr,
                inner.buf.as_ptr() as *mut T,
                inner.end as *const T,
                inner.cap,
            )
        };

        // gebruik sindsdien try-fold
        // - het vectoriseert beter voor sommige iteratoradapters
        // - in tegenstelling tot de meeste interne iteratiemethoden, is er alleen een &mut-zelf nodig
        // - het laat ons de schrijfwijzer door zijn ingewanden halen en hem uiteindelijk terughalen
        let sink = InPlaceDrop { inner: dst_buf, dst: dst_buf };
        let sink = iterator
            .try_fold::<_, _, Result<_, !>>(sink, write_in_place_with_drop(dst_end))
            .unwrap();
        // iteratie is gelukt, laat het hoofd niet vallen
        let dst = ManuallyDrop::new(sink).dst;

        let src = unsafe { iterator.as_inner().as_into_iter() };
        // controleer of het SourceIter-contract werd gehandhaafd voorbehoud: als ze dat niet waren, halen we het misschien niet eens tot dit punt
        //
        debug_assert_eq!(src_buf, src.buf.as_ptr());
        // check InPlaceIterable contract.Dit is alleen mogelijk als de iterator de bronpointer helemaal vooruit heeft gezet.
        // Als het ongecontroleerde toegang via TrustedRandomAccess gebruikt, blijft de bronpointer in de oorspronkelijke positie en kunnen we deze niet als referentie gebruiken
        //
        if src.ptr != src_ptr {
            debug_assert!(
                dst as *const _ <= src.ptr,
                "InPlaceIterable contract violation, write pointer advanced beyond read pointer"
            );
        }

        // laat alle resterende waarden aan de staart van de bron vallen, maar voorkom dat de toewijzing zelf wegvalt zodra IntoIter buiten het bereik valt als de drop panics dan lekken we ook alle verzamelde elementen in dst_buf
        //
        //
        src.forget_allocation_drop_remaining();

        let vec = unsafe {
            let len = dst.offset_from(dst_buf) as usize;
            Vec::from_raw_parts(dst_buf, len, cap)
        };

        vec
    }
}

fn write_in_place_with_drop<T>(
    src_end: *const T,
) -> impl FnMut(InPlaceDrop<T>, T) -> Result<InPlaceDrop<T>, !> {
    move |mut sink, item| {
        unsafe {
            // het InPlaceIterable-contract kan hier niet precies worden geverifieerd, omdat try_fold een exclusieve verwijzing heeft naar de bronpointer. We kunnen alleen controleren of het nog steeds binnen bereik is
            //
            //
            debug_assert!(sink.dst as *const _ <= src_end, "InPlaceIterable contract violation");
            ptr::write(sink.dst, item);
            sink.dst = sink.dst.add(1);
        }
        Ok(sink)
    }
}