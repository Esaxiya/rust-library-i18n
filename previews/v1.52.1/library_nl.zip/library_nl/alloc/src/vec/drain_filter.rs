use crate::alloc::{Allocator, Global};
use core::ptr::{self};
use core::slice::{self};

use super::Vec;

/// Een iterator die een sluiting gebruikt om te bepalen of een element moet worden verwijderd.
///
/// Deze structuur is gemaakt door [`Vec::drain_filter`].
/// Zie de documentatie voor meer.
///
/// # Example
///
/// ```
/// #![feature(drain_filter)]
///
/// let mut v = vec![0, 1, 2];
/// let iter: std::vec::DrainFilter<_, _> = v.drain_filter(|x| *x % 2 == 0);
/// ```
#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
#[derive(Debug)]
pub struct DrainFilter<
    'a,
    T,
    F,
    #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global,
> where
    F: FnMut(&mut T) -> bool,
{
    pub(super) vec: &'a mut Vec<T, A>,
    /// De index van het item dat zal worden geïnspecteerd bij de volgende aanroep van `next`.
    pub(super) idx: usize,
    /// Het aantal items dat tot nu toe (removed) is afgevoerd.
    pub(super) del: usize,
    /// De oorspronkelijke lengte van `vec` voorafgaand aan het aftappen.
    pub(super) old_len: usize,
    /// Het predikaat van de filtertest.
    pub(super) pred: F,
    /// Een vlag die aangeeft dat een panic is opgetreden in het filtertestpredikaat.
    /// Dit wordt gebruikt als een hint in de drop-implementatie om consumptie van de rest van de `DrainFilter` te voorkomen.
    /// Alle niet-verwerkte items worden teruggeschakeld in de `vec`, maar er worden geen items meer verwijderd of getest door het filterpredikaat.
    ///
    ///
    pub(super) panic_flag: bool,
}

impl<T, F, A: Allocator> DrainFilter<'_, T, F, A>
where
    F: FnMut(&mut T) -> bool,
{
    /// Retourneert een verwijzing naar de onderliggende allocator.
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn allocator(&self) -> &A {
        self.vec.allocator()
    }
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T, F, A: Allocator> Iterator for DrainFilter<'_, T, F, A>
where
    F: FnMut(&mut T) -> bool,
{
    type Item = T;

    fn next(&mut self) -> Option<T> {
        unsafe {
            while self.idx < self.old_len {
                let i = self.idx;
                let v = slice::from_raw_parts_mut(self.vec.as_mut_ptr(), self.old_len);
                self.panic_flag = true;
                let drained = (self.pred)(&mut v[i]);
                self.panic_flag = false;
                // Update de index *nadat* het predikaat is aangeroepen.
                // Als de index eerder wordt bijgewerkt en het predikaat panics, zou het element op deze index worden gelekt.
                //
                self.idx += 1;
                if drained {
                    self.del += 1;
                    return Some(ptr::read(&v[i]));
                } else if self.del > 0 {
                    let del = self.del;
                    let src: *const T = &v[i];
                    let dst: *mut T = &mut v[i - del];
                    ptr::copy_nonoverlapping(src, dst, 1);
                }
            }
            None
        }
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, Some(self.old_len - self.idx))
    }
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T, F, A: Allocator> Drop for DrainFilter<'_, T, F, A>
where
    F: FnMut(&mut T) -> bool,
{
    fn drop(&mut self) {
        struct BackshiftOnDrop<'a, 'b, T, F, A: Allocator>
        where
            F: FnMut(&mut T) -> bool,
        {
            drain: &'b mut DrainFilter<'a, T, F, A>,
        }

        impl<'a, 'b, T, F, A: Allocator> Drop for BackshiftOnDrop<'a, 'b, T, F, A>
        where
            F: FnMut(&mut T) -> bool,
        {
            fn drop(&mut self) {
                unsafe {
                    if self.drain.idx < self.drain.old_len && self.drain.del > 0 {
                        // Dit is een behoorlijk verknoeide toestand, en er is niet echt iets goeds om te doen.
                        // We willen niet blijven proberen om `pred` uit te voeren, dus we schakelen alle niet-verwerkte elementen terug en vertellen de vec dat ze nog steeds bestaan.
                        //
                        // De backshift is vereist om te voorkomen dat het laatste succesvol gedraineerde item dubbel wordt gedropt voorafgaand aan een panic in het predikaat.
                        //
                        //
                        let ptr = self.drain.vec.as_mut_ptr();
                        let src = ptr.add(self.drain.idx);
                        let dst = src.sub(self.drain.del);
                        let tail_len = self.drain.old_len - self.drain.idx;
                        src.copy_to(dst, tail_len);
                    }
                    self.drain.vec.set_len(self.drain.old_len - self.drain.del);
                }
            }
        }

        let backshift = BackshiftOnDrop { drain: self };

        // Probeer alle resterende elementen te consumeren als het filterpredikaat nog niet in paniek is geraakt.
        // We zullen alle resterende elementen terugschakelen, of we nu al in paniek zijn geraakt of dat het verbruik hier panics is.
        //
        if !backshift.drain.panic_flag {
            backshift.drain.for_each(drop);
        }
    }
}