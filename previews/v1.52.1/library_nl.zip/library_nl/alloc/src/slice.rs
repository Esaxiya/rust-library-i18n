//! Een weergave van dynamisch formaat in een aaneengesloten reeks, `[T]`.
//!
//! *[See also the slice primitive type](slice).*
//!
//! Segmenten zijn een weergave van een geheugenblok dat wordt weergegeven als een aanwijzer en een lengte.
//!
//! ```
//! // het snijden van een Vec
//! let vec = vec![1, 2, 3];
//! let int_slice = &vec[..];
//! // het dwingen van een array tot een slice
//! let str_slice: &[&str] = &["one", "two", "three"];
//! ```
//!
//! Segmenten zijn ofwel veranderlijk of gedeeld.
//! Het gedeelde slice-type is `&[T]`, terwijl het veranderlijke slice-type `&mut [T]` is, waarbij `T` het elementtype vertegenwoordigt.
//! U kunt bijvoorbeeld het geheugenblok waarnaar een veranderlijke slice verwijst, muteren:
//!
//! ```
//! let x = &mut [1, 2, 3];
//! x[1] = 7;
//! assert_eq!(x, &[1, 7, 3]);
//! ```
//!
//! Hier zijn enkele dingen die deze module bevat:
//!
//! ## Structs
//!
//! Er zijn verschillende structs die handig zijn voor segmenten, zoals [`Iter`], dat iteratie over een segment vertegenwoordigt.
//!
//! ## Trait implementaties
//!
//! Er zijn verschillende implementaties van algemene traits voor plakjes.Enkele voorbeelden zijn:
//!
//! * [`Clone`]
//! * [`Eq`], [`Ord`], voor segmenten waarvan het elementtype [`Eq`] of [`Ord`] is.
//! * [`Hash`] - voor segmenten waarvan het elementtype [`Hash`] is.
//!
//! ## Iteration
//!
//! De plakjes implementeren `IntoIterator`.De iterator levert verwijzingen op naar de segmentelementen.
//!
//! ```
//! let numbers = &[0, 1, 2];
//! for n in numbers {
//!     println!("{} is a number!", n);
//! }
//! ```
//!
//! De veranderlijke plak levert veranderlijke verwijzingen naar de elementen op:
//!
//! ```
//! let mut scores = [7, 8, 9];
//! for score in &mut scores[..] {
//!     *score += 1;
//! }
//! ```
//!
//! Deze iterator levert veranderlijke verwijzingen naar de elementen van de slice, dus terwijl het elementtype van de slice `i32` is, is het elementtype van de iterator `&mut i32`.
//!
//!
//! * [`.iter`] en [`.iter_mut`] zijn de expliciete methoden om de standaard iteratoren te retourneren.
//! * Andere methoden die iteratoren retourneren, zijn [`.split`], [`.splitn`], [`.chunks`], [`.windows`] en meer.
//!
//! [`Hash`]: core::hash::Hash
//! [`.iter`]: slice::iter
//! [`.iter_mut`]: slice::iter_mut
//! [`.split`]: slice::split
//! [`.splitn`]: slice::splitn
//! [`.chunks`]: slice::chunks
//! [`.windows`]: slice::windows
//!
//!
//!
//!
//!
//!
//!
//!
#![stable(feature = "rust1", since = "1.0.0")]
// Veel van de toepassingen in deze module worden alleen gebruikt in de testconfiguratie.
// Het is schoner om de waarschuwing unused_imports gewoon uit te schakelen dan ze te repareren.
#![cfg_attr(test, allow(unused_imports, dead_code))]

use core::borrow::{Borrow, BorrowMut};
use core::cmp::Ordering::{self, Less};
use core::mem::{self, size_of};
use core::ptr;

use crate::alloc::{Allocator, Global};
use crate::borrow::ToOwned;
use crate::boxed::Box;
use crate::vec::Vec;

#[unstable(feature = "slice_range", issue = "76393")]
pub use core::slice::range;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunks;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunksMut;
#[unstable(feature = "array_windows", issue = "75027")]
pub use core::slice::ArrayWindows;
#[stable(feature = "slice_get_slice", since = "1.28.0")]
pub use core::slice::SliceIndex;
#[stable(feature = "from_ref", since = "1.28.0")]
pub use core::slice::{from_mut, from_ref};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{from_raw_parts, from_raw_parts_mut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Chunks, Windows};
#[stable(feature = "chunks_exact", since = "1.31.0")]
pub use core::slice::{ChunksExact, ChunksExactMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{ChunksMut, Split, SplitMut};
#[unstable(feature = "slice_group_by", issue = "80552")]
pub use core::slice::{GroupBy, GroupByMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Iter, IterMut};
#[stable(feature = "rchunks", since = "1.31.0")]
pub use core::slice::{RChunks, RChunksExact, RChunksExactMut, RChunksMut};
#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub use core::slice::{RSplit, RSplitMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{RSplitN, RSplitNMut, SplitN, SplitNMut};

////////////////////////////////////////////////////////////////////////////////
// Basismethoden voor slice-extensie
////////////////////////////////////////////////////////////////////////////////

// HACK(japaric) nodig voor de implementatie van de `vec!`-macro tijdens het testen. NB, zie de `hack`-module in dit bestand voor meer details.
//
#[cfg(test)]
pub use hack::into_vec;

// HACK(japaric) nodig voor de implementatie van `Vec::clone` tijdens het testen NB, zie de `hack` module in dit bestand voor meer details.
//
#[cfg(test)]
pub use hack::to_vec;

// HACK(japaric): Met cfg(test) is `impl [T]` niet beschikbaar, deze drie functies zijn eigenlijk methoden die in `impl [T]` staan maar niet in `core::slice::SliceExt`, we moeten deze functies leveren voor de `test_permutations`-test
//
//
//
mod hack {
    use core::alloc::Allocator;

    use crate::boxed::Box;
    use crate::vec::Vec;

    // We moeten hier geen inline-attribuut aan toevoegen, omdat dit meestal in de `vec!`-macro wordt gebruikt en prestatie-regressie veroorzaakt.
    // Zie #71204 voor bespreking en prestatie-resultaten.
    //
    pub fn into_vec<T, A: Allocator>(b: Box<[T], A>) -> Vec<T, A> {
        unsafe {
            let len = b.len();
            let (b, alloc) = Box::into_raw_with_allocator(b);
            Vec::from_raw_parts_in(b as *mut T, len, len, alloc)
        }
    }

    #[inline]
    pub fn to_vec<T: ConvertVec, A: Allocator>(s: &[T], alloc: A) -> Vec<T, A> {
        T::to_vec(s, alloc)
    }

    pub trait ConvertVec {
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A>
        where
            Self: Sized;
    }

    impl<T: Clone> ConvertVec for T {
        #[inline]
        default fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            struct DropGuard<'a, T, A: Allocator> {
                vec: &'a mut Vec<T, A>,
                num_init: usize,
            }
            impl<'a, T, A: Allocator> Drop for DropGuard<'a, T, A> {
                #[inline]
                fn drop(&mut self) {
                    // SAFETY:
                    // items zijn gemarkeerd als geïnitialiseerd in de onderstaande lus
                    unsafe {
                        self.vec.set_len(self.num_init);
                    }
                }
            }
            let mut vec = Vec::with_capacity_in(s.len(), alloc);
            let mut guard = DropGuard { vec: &mut vec, num_init: 0 };
            let slots = guard.vec.spare_capacity_mut();
            // .take(slots.len()) is nodig voor LLVM om grenscontroles te verwijderen en heeft een betere codegen dan zip.
            //
            for (i, b) in s.iter().enumerate().take(slots.len()) {
                guard.num_init = i;
                slots[i].write(b.clone());
            }
            core::mem::forget(guard);
            // SAFETY:
            // de vec is hierboven op ten minste deze lengte toegewezen en geïnitialiseerd.
            unsafe {
                vec.set_len(s.len());
            }
            vec
        }
    }

    impl<T: Copy> ConvertVec for T {
        #[inline]
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            let mut v = Vec::with_capacity_in(s.len(), alloc);
            // SAFETY:
            // hierboven toegewezen met de capaciteit van `s`, en initialiseren naar `s.len()` in ptr::copy_to_non_overlapping hieronder.
            //
            unsafe {
                s.as_ptr().copy_to_nonoverlapping(v.as_mut_ptr(), s.len());
                v.set_len(s.len());
            }
            v
        }
    }
}

#[lang = "slice_alloc"]
#[cfg_attr(not(test), rustc_diagnostic_item = "slice")]
#[cfg(not(test))]
impl<T> [T] {
    /// Sorteert de plak.
    ///
    /// Deze sortering is stabiel (dwz herschikt geen gelijke elementen) en *O*(*n*\*log(* n*)) worst-case.
    ///
    /// Indien van toepassing heeft onstabiele sortering de voorkeur omdat dit over het algemeen sneller is dan stabiel sorteren en er geen extra geheugen wordt toegewezen.
    /// Zie [`sort_unstable`](slice::sort_unstable).
    ///
    /// # Huidige implementatie
    ///
    /// Het huidige algoritme is een adaptieve, iteratieve samenvoegsoort geïnspireerd door [timsort](https://en.wikipedia.org/wiki/Timsort).
    /// Het is ontworpen om erg snel te zijn in gevallen waarin de plak bijna is gesorteerd, of bestaat uit twee of meer gesorteerde reeksen die na elkaar zijn samengevoegd.
    ///
    ///
    /// Het wijst ook tijdelijke opslag toe die half zo groot is als `self`, maar voor korte plakjes wordt in plaats daarvan een niet-allocerende invoegsortering gebruikt.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5, 4, 1, -3, 2];
    ///
    /// v.sort();
    /// assert!(v == [-5, -3, 1, 2, 4]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort(&mut self)
    where
        T: Ord,
    {
        merge_sort(self, |a, b| a.lt(b));
    }

    /// Sorteert het segment met een vergelijkingsfunctie.
    ///
    /// Deze sortering is stabiel (dwz herschikt geen gelijke elementen) en *O*(*n*\*log(* n*)) worst-case.
    ///
    /// De vergelijkingsfunctie moet een totale ordening definiëren voor de elementen in de plak.Als de volgorde niet totaal is, is de volgorde van de elementen niet gespecificeerd.
    /// Een bestelling is een totale bestelling als dit het geval is (voor alle `a`, `b` en `c`):
    ///
    /// * totaal en antisymmetrisch: precies een van `a < b`, `a == b` of `a > b` is waar, en
    /// * transitief, `a < b` en `b < c` impliceert `a < c`.Hetzelfde moet gelden voor zowel `==` als `>`.
    ///
    /// Hoewel [`f64`] [`Ord`] bijvoorbeeld niet implementeert omdat `NaN != NaN`, kunnen we `partial_cmp` gebruiken als onze sorteerfunctie als we weten dat de slice geen `NaN` bevat.
    ///
    ///
    /// ```
    /// let mut floats = [5f64, 4.0, 1.0, 3.0, 2.0];
    /// floats.sort_by(|a, b| a.partial_cmp(b).unwrap());
    /// assert_eq!(floats, [1.0, 2.0, 3.0, 4.0, 5.0]);
    /// ```
    ///
    /// Indien van toepassing heeft onstabiele sortering de voorkeur omdat dit over het algemeen sneller is dan stabiel sorteren en er geen extra geheugen wordt toegewezen.
    /// Zie [`sort_unstable_by`](slice::sort_unstable_by).
    ///
    /// # Huidige implementatie
    ///
    /// Het huidige algoritme is een adaptieve, iteratieve samenvoegsoort geïnspireerd door [timsort](https://en.wikipedia.org/wiki/Timsort).
    /// Het is ontworpen om erg snel te zijn in gevallen waarin de plak bijna is gesorteerd, of bestaat uit twee of meer gesorteerde reeksen die na elkaar zijn samengevoegd.
    ///
    /// Het wijst ook tijdelijke opslag toe die half zo groot is als `self`, maar voor korte plakjes wordt in plaats daarvan een niet-allocerende invoegsortering gebruikt.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [5, 4, 1, 3, 2];
    /// v.sort_by(|a, b| a.cmp(b));
    /// assert!(v == [1, 2, 3, 4, 5]);
    ///
    /// // omgekeerd sorteren
    /// v.sort_by(|a, b| b.cmp(a));
    /// assert!(v == [5, 4, 3, 2, 1]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort_by<F>(&mut self, mut compare: F)
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        merge_sort(self, |a, b| compare(a, b) == Less);
    }

    /// Sorteert het segment met een sleutelextractiefunctie.
    ///
    /// Deze sortering is stabiel (dwz de volgorde van gelijke elementen wordt niet gewijzigd) en *O*(*m*\* * n *\* log(*n*)) worst-case, waarbij de sleutelfunctie *O*(*m*) is.
    ///
    /// Voor dure sleutelfuncties (bijv
    /// functies die geen eenvoudige toegang tot eigendommen of basisbewerkingen zijn), zal [`sort_by_cached_key`](slice::sort_by_cached_key) waarschijnlijk aanzienlijk sneller zijn, aangezien het de elementensleutels niet herberekent.
    ///
    ///
    /// Indien van toepassing heeft onstabiele sortering de voorkeur omdat dit over het algemeen sneller is dan stabiel sorteren en er geen extra geheugen wordt toegewezen.
    /// Zie [`sort_unstable_by_key`](slice::sort_unstable_by_key).
    ///
    /// # Huidige implementatie
    ///
    /// Het huidige algoritme is een adaptieve, iteratieve samenvoegsoort geïnspireerd door [timsort](https://en.wikipedia.org/wiki/Timsort).
    /// Het is ontworpen om erg snel te zijn in gevallen waarin de plak bijna is gesorteerd, of bestaat uit twee of meer gesorteerde reeksen die na elkaar zijn samengevoegd.
    ///
    /// Het wijst ook tijdelijke opslag toe die half zo groot is als `self`, maar voor korte plakjes wordt in plaats daarvan een niet-allocerende invoegsortering gebruikt.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// v.sort_by_key(|k| k.abs());
    /// assert!(v == [1, 2, -3, 4, -5]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_key", since = "1.7.0")]
    #[inline]
    pub fn sort_by_key<K, F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        merge_sort(self, |a, b| f(a).lt(&f(b)));
    }

    /// Sorteert het segment met een sleutelextractiefunctie.
    ///
    /// Tijdens het sorteren wordt de sleutelfunctie slechts één keer per element aangeroepen.
    ///
    /// Deze sortering is stabiel (dwz, gelijke elementen niet opnieuw ordenen) en *O*(*m*\* * n *+* n *\* log(*n*)) worst-case, waarbij de sleutelfunctie *O*(*m*) is .
    ///
    /// Voor eenvoudige sleutelfuncties (bijv. Functies die toegang tot eigendommen of basisbewerkingen zijn), is [`sort_by_key`](slice::sort_by_key) waarschijnlijk sneller.
    ///
    /// # Huidige implementatie
    ///
    /// Het huidige algoritme is gebaseerd op [pattern-defeating quicksort][pdqsort] van Orson Peters, dat het snelle gemiddelde geval van gerandomiseerde quicksort combineert met het snelle slechtste geval van heapsort, terwijl lineaire tijd wordt bereikt op plakjes met bepaalde patronen.
    /// Het gebruikt enige randomisatie om gedegenereerde gevallen te voorkomen, maar met een vaste seed om altijd deterministisch gedrag te bieden.
    ///
    /// In het ergste geval wijst het algoritme tijdelijke opslag in een `Vec<(K, usize)>` de lengte van de plak toe.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 32, -3, 2];
    ///
    /// v.sort_by_cached_key(|k| k.to_string());
    /// assert!(v == [-3, -5, 2, 32, 4]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_cached_key", since = "1.34.0")]
    #[inline]
    pub fn sort_by_cached_key<K, F>(&mut self, f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        // Helper-macro voor het indexeren van onze vector door het kleinst mogelijke type, om toewijzing te verminderen.
        macro_rules! sort_by_key {
            ($t:ty, $slice:ident, $f:ident) => {{
                let mut indices: Vec<_> =
                    $slice.iter().map($f).enumerate().map(|(i, k)| (k, i as $t)).collect();
                // De elementen van `indices` zijn uniek, aangezien ze geïndexeerd zijn, dus elke soort zal stabiel zijn ten opzichte van het originele segment.
                // We gebruiken hier `sort_unstable` omdat het minder geheugentoewijzing vereist.
                //
                indices.sort_unstable();
                for i in 0..$slice.len() {
                    let mut index = indices[i].1;
                    while (index as usize) < i {
                        index = indices[index as usize].1;
                    }
                    indices[i].1 = index;
                    $slice.swap(i, index as usize);
                }
            }};
        }

        let sz_u8 = mem::size_of::<(K, u8)>();
        let sz_u16 = mem::size_of::<(K, u16)>();
        let sz_u32 = mem::size_of::<(K, u32)>();
        let sz_usize = mem::size_of::<(K, usize)>();

        let len = self.len();
        if len < 2 {
            return;
        }
        if sz_u8 < sz_u16 && len <= (u8::MAX as usize) {
            return sort_by_key!(u8, self, f);
        }
        if sz_u16 < sz_u32 && len <= (u16::MAX as usize) {
            return sort_by_key!(u16, self, f);
        }
        if sz_u32 < sz_usize && len <= (u32::MAX as usize) {
            return sort_by_key!(u32, self, f);
        }
        sort_by_key!(usize, self, f)
    }

    /// Kopieert `self` naar een nieuwe `Vec`.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = [10, 40, 30];
    /// let x = s.to_vec();
    /// // Hier kunnen `s` en `x` onafhankelijk worden gewijzigd.
    /// ```
    #[rustc_conversion_suggestion]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_vec(&self) -> Vec<T>
    where
        T: Clone,
    {
        self.to_vec_in(Global)
    }

    /// Kopieert `self` naar een nieuwe `Vec` met een allocator.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let s = [10, 40, 30];
    /// let x = s.to_vec_in(System);
    /// // Hier kunnen `s` en `x` onafhankelijk worden gewijzigd.
    /// ```
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn to_vec_in<A: Allocator>(&self, alloc: A) -> Vec<T, A>
    where
        T: Clone,
    {
        // NB, zie de `hack`-module in dit bestand voor meer details.
        hack::to_vec(self, alloc)
    }

    /// Zet `self` om in een vector zonder klonen of toewijzing.
    ///
    /// De resulterende vector kan via `Vec<T>`into_boxed_slice`-methode.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let s: Box<[i32]> = Box::new([10, 40, 30]);
    /// let x = s.into_vec();
    /// // `s` kan niet meer worden gebruikt omdat het is geconverteerd naar `x`.
    ///
    /// assert_eq!(x, vec![10, 40, 30]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn into_vec<A: Allocator>(self: Box<Self, A>) -> Vec<T, A> {
        // NB, zie de `hack`-module in dit bestand voor meer details.
        hack::into_vec(self)
    }

    /// Creëert een vector door een plak `n` keer te herhalen.
    ///
    /// # Panics
    ///
    /// Deze functie zal panic zijn als de capaciteit zou overlopen.
    ///
    /// # Examples
    ///
    /// Basisgebruik:
    ///
    /// ```
    /// assert_eq!([1, 2].repeat(3), vec![1, 2, 1, 2, 1, 2]);
    /// ```
    ///
    /// A panic bij overloop:
    ///
    /// ```should_panic
    /// // this will panic at runtime
    /// b"0123456789abcdef".repeat(usize::MAX);
    /// ```
    #[stable(feature = "repeat_generic_slice", since = "1.40.0")]
    pub fn repeat(&self, n: usize) -> Vec<T>
    where
        T: Copy,
    {
        if n == 0 {
            return Vec::new();
        }

        // Als `n` groter is dan nul, kan deze worden gesplitst als `n = 2^expn + rem (2^expn > rem, expn >= 0, rem >= 0)`.
        // `2^expn` is het nummer dat wordt vertegenwoordigd door de meest linkse '1'-bit van `n`, en `rem` is het resterende deel van `n`.
        //
        //

        // `Vec` gebruiken om toegang te krijgen tot `set_len()`.
        let capacity = self.len().checked_mul(n).expect("capacity overflow");
        let mut buf = Vec::with_capacity(capacity);

        // `2^expn` herhaling wordt gedaan door `buf` `expn`-tijden te verdubbelen.
        buf.extend(self);
        {
            let mut m = n >> 1;
            // Als `m > 0`, zijn er resterende bits tot de meest linkse '1'.
            while m > 0 {
                // `buf.extend(buf)`:
                unsafe {
                    ptr::copy_nonoverlapping(
                        buf.as_ptr(),
                        (buf.as_mut_ptr() as *mut T).add(buf.len()),
                        buf.len(),
                    );
                    // `buf` heeft een capaciteit van `self.len() * n`.
                    let buf_len = buf.len();
                    buf.set_len(buf_len * 2);
                }

                m >>= 1;
            }
        }

        // `rem` (`=n, 2 ^ expn`) herhaling wordt gedaan door de eerste `rem`-herhalingen van `buf` zelf te kopiëren.
        //
        let rem_len = capacity - buf.len(); // `self.len() * rem`
        if rem_len > 0 {
            // `buf.extend(buf[0 .. rem_len])`:
            unsafe {
                // Dit overlapt niet sinds `2^expn > rem`.
                ptr::copy_nonoverlapping(
                    buf.as_ptr(),
                    (buf.as_mut_ptr() as *mut T).add(buf.len()),
                    rem_len,
                );
                // `buf.len() + rem_len` is gelijk aan `buf.capacity()` (`= self.len() * n`).
                buf.set_len(capacity);
            }
        }
        buf
    }

    /// Vlakt een plak `T` af tot een enkele waarde `Self::Output`.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].concat(), "helloworld");
    /// assert_eq!([[1, 2], [3, 4]].concat(), [1, 2, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn concat<Item: ?Sized>(&self) -> <Self as Concat<Item>>::Output
    where
        Self: Concat<Item>,
    {
        Concat::concat(self)
    }

    /// Vlakt een plak `T` af tot een enkele waarde `Self::Output`, waarbij een bepaald scheidingsteken tussen elk wordt geplaatst.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].join(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].join(&0), [1, 2, 0, 3, 4]);
    /// assert_eq!([[1, 2], [3, 4]].join(&[0, 0][..]), [1, 2, 0, 0, 3, 4]);
    /// ```
    #[stable(feature = "rename_connect_to_join", since = "1.3.0")]
    pub fn join<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }

    /// Vlakt een plak `T` af tot een enkele waarde `Self::Output`, waarbij een bepaald scheidingsteken tussen elk wordt geplaatst.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(deprecated)]
    /// assert_eq!(["hello", "world"].connect(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].connect(&0), [1, 2, 0, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.3.0", reason = "renamed to join")]
    pub fn connect<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }
}

#[lang = "slice_u8_alloc"]
#[cfg(not(test))]
impl [u8] {
    /// Retourneert een vector met een kopie van dit segment waarin elke byte wordt toegewezen aan het ASCII-equivalent in hoofdletters.
    ///
    ///
    /// ASCII-letters 'a' tot 'z' worden toegewezen aan 'A' tot 'Z', maar niet-ASCII-letters blijven ongewijzigd.
    ///
    /// Gebruik [`make_ascii_uppercase`] om de waarde ter plekke in hoofdletters te zetten.
    ///
    /// [`make_ascii_uppercase`]: u8::make_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_uppercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_uppercase();
        me
    }

    /// Retourneert een vector met een kopie van dit segment waarin elke byte wordt toegewezen aan het ASCII-equivalent in kleine letters.
    ///
    ///
    /// ASCII-letters 'A' tot 'Z' worden toegewezen aan 'a' tot 'z', maar niet-ASCII-letters blijven ongewijzigd.
    ///
    /// Gebruik [`make_ascii_lowercase`] om de waarde op zijn plaats in kleine letters te zetten.
    ///
    /// [`make_ascii_lowercase`]: u8::make_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_lowercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_lowercase();
        me
    }
}

////////////////////////////////////////////////////////////////////////////////
// Extensie traits voor segmenten over specifieke soorten gegevens
////////////////////////////////////////////////////////////////////////////////

/// Helper trait voor [`[T]: : concat`](slice::concat).
///
/// Note: de `Item` type parameter wordt niet gebruikt in deze trait, maar het staat toe dat impls meer generiek zijn.
/// Zonder dit krijgen we deze foutmelding:
///
/// ```error
/// error[E0207]: the type parameter `T` is not constrained by the impl trait, self type, or predica
///    --> src/liballoc/slice.rs:608:6
///     |
/// 608 | impl<T: Clone, V: Borrow<[T]>> Concat for [V] {
///     |      ^ unconstrained type parameter
/// ```
///
/// Dit komt omdat er `V`-typen kunnen bestaan met meerdere `Borrow<[_]>`-impls, zodat meerdere `T`-typen van toepassing zijn:
///
///
/// ```
/// # #[allow(dead_code)]
/// pub struct Foo(Vec<u32>, Vec<String>);
///
/// impl std::borrow::Borrow<[u32]> for Foo {
///     fn borrow(&self) -> &[u32] { &self.0 }
/// }
///
/// impl std::borrow::Borrow<[String]> for Foo {
///     fn borrow(&self) -> &[String] { &self.1 }
/// }
/// ```
///
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Concat<Item: ?Sized> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// Het resulterende type na aaneenschakeling
    type Output;

    /// Implementatie van [`[T]: : concat`](slice::concat)
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn concat(slice: &Self) -> Self::Output;
}

/// Helper trait voor [`[T]: : join`](slice::join)
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Join<Separator> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// Het resulterende type na aaneenschakeling
    type Output;

    /// Implementatie van [`[T]: : join`](slice::join)
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn join(slice: &Self, sep: Separator) -> Self::Output;
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Concat<T> for [V] {
    type Output = Vec<T>;

    fn concat(slice: &Self) -> Vec<T> {
        let size = slice.iter().map(|slice| slice.borrow().len()).sum();
        let mut result = Vec::with_capacity(size);
        for v in slice {
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&T> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &T) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size = slice.iter().map(|v| v.borrow().len()).sum::<usize>() + slice.len() - 1;
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.push(sep.clone());
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&[T]> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &[T]) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size =
            slice.iter().map(|v| v.borrow().len()).sum::<usize>() + sep.len() * (slice.len() - 1);
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.extend_from_slice(sep);
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

////////////////////////////////////////////////////////////////////////////////
// Standaard trait-implementaties voor plakjes
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Borrow<[T]> for Vec<T> {
    fn borrow(&self) -> &[T] {
        &self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> BorrowMut<[T]> for Vec<T> {
    fn borrow_mut(&mut self) -> &mut [T] {
        &mut self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> ToOwned for [T] {
    type Owned = Vec<T>;
    #[cfg(not(test))]
    fn to_owned(&self) -> Vec<T> {
        self.to_vec()
    }

    #[cfg(test)]
    fn to_owned(&self) -> Vec<T> {
        hack::to_vec(self, Global)
    }

    fn clone_into(&self, target: &mut Vec<T>) {
        // laat alles in het doel vallen dat niet zal worden overschreven
        target.truncate(self.len());

        // target.len <= self.len vanwege het afkappen hierboven, dus de segmenten hier zijn altijd in-bounds.
        //
        let (init, tail) = self.split_at(target.len());

        // hergebruik de ingesloten waarden allocations/resources.
        target.clone_from_slice(init);
        target.extend_from_slice(tail);
    }
}

////////////////////////////////////////////////////////////////////////////////
// Sorting
////////////////////////////////////////////////////////////////////////////////

/// Voegt `v[0]` in de voorgesorteerde reeks `v[1..]` in zodat de hele `v[..]` wordt gesorteerd.
///
/// Dit is de integrale subroutine van invoegsortering.
fn insert_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    if v.len() >= 2 && is_less(&v[1], &v[0]) {
        unsafe {
            // Er zijn drie manieren om invoeging hier te implementeren:
            //
            // 1. Verwissel aangrenzende elementen totdat de eerste zijn eindbestemming bereikt.
            //    Op deze manier kopiëren we echter gegevens rond meer dan nodig is.
            //    Als elementen grote structuren zijn (duur om te kopiëren), zal deze methode traag zijn.
            //
            // 2. Herhaal totdat de juiste plaats voor het eerste element is gevonden.
            // Verplaats vervolgens de elementen erop om er ruimte voor te maken en plaats het uiteindelijk in het resterende gat.
            // Dit is een goede methode.
            //
            // 3. Kopieer het eerste element naar een tijdelijke variabele.Herhaal totdat de juiste plaats ervoor is gevonden.
            // Kopieer, terwijl we doorgaan, elk doorlopen element naar de daarvoor bestemde sleuf.
            // Kopieer ten slotte gegevens van de tijdelijke variabele naar het resterende gat.
            // Deze methode is erg goed.
            // Benchmarks lieten iets betere prestaties zien dan met de 2e methode.
            //
            // Alle methoden werden gebenchmarkt en de derde liet de beste resultaten zien.Dus die hebben we gekozen.
            let mut tmp = mem::ManuallyDrop::new(ptr::read(&v[0]));

            // De tussenliggende status van het invoegproces wordt altijd gevolgd door `hole`, wat twee doelen dient:
            // 1. Beschermt de integriteit van `v` tegen panics in `is_less`.
            // 2. Vult uiteindelijk het resterende gat in `v`.
            //
            // Panic veiligheid:
            //
            // Als `is_less` panics op enig moment tijdens het proces, `hole` zal vallen en het gat in `v` vullen met `tmp`, waardoor ervoor wordt gezorgd dat `v` nog steeds elk object vasthoudt dat het aanvankelijk precies één keer vasthield.
            //
            //
            //
            let mut hole = InsertionHole { src: &mut *tmp, dest: &mut v[1] };
            ptr::copy_nonoverlapping(&v[1], &mut v[0], 1);

            for i in 2..v.len() {
                if !is_less(&v[i], &*tmp) {
                    break;
                }
                ptr::copy_nonoverlapping(&v[i], &mut v[i - 1], 1);
                hole.dest = &mut v[i];
            }
            // `hole` wordt gedropt en kopieert dus `tmp` naar het resterende gat in `v`.
        }
    }

    // Wanneer ze worden verwijderd, worden kopieën van `src` naar `dest`.
    struct InsertionHole<T> {
        src: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for InsertionHole<T> {
        fn drop(&mut self) {
            unsafe {
                ptr::copy_nonoverlapping(self.src, self.dest, 1);
            }
        }
    }
}

/// Voegt niet-afnemende runs `v[..mid]` en `v[mid..]` samen met `buf` als tijdelijke opslag, en slaat het resultaat op in `v[..]`.
///
/// # Safety
///
/// De twee segmenten mogen niet leeg zijn en `mid` moet binnen grenzen zijn.
/// Buffer `buf` moet lang genoeg zijn om een kopie van de kortere plak te bevatten.
/// `T` mag ook geen type zijn met de grootte nul.
unsafe fn merge<T, F>(v: &mut [T], mid: usize, buf: *mut T, is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    let v = v.as_mut_ptr();
    let (v_mid, v_end) = unsafe { (v.add(mid), v.add(len)) };

    // Het samenvoegingsproces kopieert eerst de kortere run naar `buf`.
    // Vervolgens traceert het de nieuw gekopieerde run en de langere run vooruit (of achteruit), waarbij de volgende niet-verbruikte elementen worden vergeleken en de kleinere (of grotere) wordt gekopieerd naar `v`.
    //
    // Zodra de kortere oplage volledig is opgebruikt, is het proces voltooid.Als de langere run eerst wordt verbruikt, moeten we alles wat er over is van de kortere run kopiëren naar het resterende gat in `v`.
    //
    // De tussenliggende status van het proces wordt altijd gevolgd door `hole`, dat twee doelen dient:
    // 1. Beschermt de integriteit van `v` tegen panics in `is_less`.
    // 2. Vult het resterende gat in `v` als de langere run eerst wordt verbruikt.
    //
    // Panic veiligheid:
    //
    // Als `is_less` panics op enig moment tijdens het proces, `hole` valt en het gat in `v` vult met het niet-verbruikte bereik in `buf`, waardoor ervoor wordt gezorgd dat `v` nog steeds elk object vasthoudt dat het aanvankelijk precies één keer vasthield.
    //
    //
    //
    //
    //
    let mut hole;

    if mid <= len - mid {
        // De linker run is korter.
        unsafe {
            ptr::copy_nonoverlapping(v, buf, mid);
            hole = MergeHole { start: buf, end: buf.add(mid), dest: v };
        }

        // In eerste instantie wijzen deze verwijzingen naar het begin van hun arrays.
        let left = &mut hole.start;
        let mut right = v_mid;
        let out = &mut hole.dest;

        while *left < hole.end && right < v_end {
            // Consumeer de mindere kant.
            // Indien gelijk, geef dan de voorkeur aan de linker run om de stabiliteit te behouden.
            unsafe {
                let to_copy = if is_less(&*right, &**left) {
                    get_and_increment(&mut right)
                } else {
                    get_and_increment(left)
                };
                ptr::copy_nonoverlapping(to_copy, get_and_increment(out), 1);
            }
        }
    } else {
        // De juiste run is korter.
        unsafe {
            ptr::copy_nonoverlapping(v_mid, buf, len - mid);
            hole = MergeHole { start: buf, end: buf.add(len - mid), dest: v_mid };
        }

        // In eerste instantie wijzen deze wijzers voorbij de uiteinden van hun arrays.
        let left = &mut hole.dest;
        let right = &mut hole.end;
        let mut out = v_end;

        while v < *left && buf < *right {
            // Consumeer de grotere kant.
            // Indien gelijk, geef dan de voorkeur aan de juiste run om de stabiliteit te behouden.
            unsafe {
                let to_copy = if is_less(&*right.offset(-1), &*left.offset(-1)) {
                    decrement_and_get(left)
                } else {
                    decrement_and_get(right)
                };
                ptr::copy_nonoverlapping(to_copy, decrement_and_get(&mut out), 1);
            }
        }
    }
    // Ten slotte wordt `hole` verwijderd.
    // Als de kortere run niet volledig was opgebruikt, wordt de rest ervan nu naar het gat in `v` gekopieerd.

    unsafe fn get_and_increment<T>(ptr: &mut *mut T) -> *mut T {
        let old = *ptr;
        *ptr = unsafe { ptr.offset(1) };
        old
    }

    unsafe fn decrement_and_get<T>(ptr: &mut *mut T) -> *mut T {
        *ptr = unsafe { ptr.offset(-1) };
        *ptr
    }

    // Wanneer het wordt verwijderd, wordt het bereik `start..end` naar `dest..` gekopieerd.
    struct MergeHole<T> {
        start: *mut T,
        end: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for MergeHole<T> {
        fn drop(&mut self) {
            // `T` is geen type met een grootte van nul, dus het is prima om te delen door de grootte.
            let len = (self.end as usize - self.start as usize) / mem::size_of::<T>();
            unsafe {
                ptr::copy_nonoverlapping(self.start, self.dest, len);
            }
        }
    }
}

/// Deze samenvoegingssoort leent enkele (maar niet alle) ideeën van TimSort, die in detail [here](http://svn.python.org/projects/python/trunk/Objects/listsort.txt) wordt beschreven.
///
///
/// Het algoritme identificeert strikt dalende en niet-dalende subreeksen, die natuurlijke runs worden genoemd.Er is een stapel lopende runs die nog moet worden samengevoegd.
/// Elke nieuw gevonden run wordt op de stapel geduwd en vervolgens worden enkele paren aangrenzende runs samengevoegd totdat aan deze twee invarianten is voldaan:
///
/// 1. voor elke `i` in `1..runs.len()`: `runs[i - 1].len > runs[i].len`
/// 2. voor elke `i` in `2..runs.len()`: `runs[i - 2].len > runs[i - 1].len + runs[i].len`
///
/// De invarianten zorgen ervoor dat de totale looptijd *O*(*n*\*log(* n*)) worst-case.
///
///
fn merge_sort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Segmenten tot deze lengte worden gesorteerd met behulp van invoegsortering.
    const MAX_INSERTION: usize = 20;
    // Zeer korte runs worden uitgebreid met behulp van invoegsortering om ten minste zoveel elementen te omvatten.
    const MIN_RUN: usize = 10;

    // Sorteren heeft geen zinvol gedrag op typen met een grootte van nul.
    if size_of::<T>() == 0 {
        return;
    }

    let len = v.len();

    // Korte arrays worden ter plaatse gesorteerd via invoegsortering om toewijzingen te voorkomen.
    if len <= MAX_INSERTION {
        if len >= 2 {
            for i in (0..len - 1).rev() {
                insert_head(&mut v[i..], &mut is_less);
            }
        }
        return;
    }

    // Wijs een buffer toe om als werkgeheugen te gebruiken.We houden de lengte 0 zodat we er ondiepe kopieën van de inhoud van `v` in kunnen bewaren zonder het risico te lopen dat de dtors op kopieën draaien als `is_less` panics.
    //
    // Bij het samenvoegen van twee gesorteerde runs, bevat deze buffer een kopie van de kortere run, die altijd maximaal `len / 2` lang zal zijn.
    //
    let mut buf = Vec::with_capacity(len / 2);

    // Om natuurlijke runs in `v` te identificeren, verplaatsen we deze achteruit.
    // Dat lijkt misschien een vreemde beslissing, maar bedenk wel dat fusies vaker in de tegenovergestelde richting gaan (forwards).
    // Volgens benchmarks gaat voorwaarts samenvoegen iets sneller dan achterwaarts samenvoegen.
    // Concluderend: het identificeren van runs door achteruit te gaan, verbetert de prestaties.
    let mut runs = vec![];
    let mut end = len;
    while end > 0 {
        // Zoek de volgende natuurlijke run en draai deze om als deze strikt daalt.
        let mut start = end - 1;
        if start > 0 {
            start -= 1;
            unsafe {
                if is_less(v.get_unchecked(start + 1), v.get_unchecked(start)) {
                    while start > 0 && is_less(v.get_unchecked(start), v.get_unchecked(start - 1)) {
                        start -= 1;
                    }
                    v[start..end].reverse();
                } else {
                    while start > 0 && !is_less(v.get_unchecked(start), v.get_unchecked(start - 1))
                    {
                        start -= 1;
                    }
                }
            }
        }

        // Voeg wat meer elementen in de aanloop in als deze te kort is.
        // Invoegsortering is sneller dan samenvoegsortering in korte reeksen, dus dit verbetert de prestaties aanzienlijk.
        while start > 0 && end - start < MIN_RUN {
            start -= 1;
            insert_head(&mut v[start..end], &mut is_less);
        }

        // Duw deze run op de stapel.
        runs.push(Run { start, len: end - start });
        end = start;

        // Voeg enkele paren aangrenzende runs samen om aan de invarianten te voldoen.
        while let Some(r) = collapse(&runs) {
            let left = runs[r + 1];
            let right = runs[r];
            unsafe {
                merge(
                    &mut v[left.start..right.start + right.len],
                    left.len,
                    buf.as_mut_ptr(),
                    &mut is_less,
                );
            }
            runs[r] = Run { start: left.start, len: left.len + right.len };
            runs.remove(r + 1);
        }
    }

    // Ten slotte moet er precies één run in de stapel overblijven.
    debug_assert!(runs.len() == 1 && runs[0].start == 0 && runs[0].len == len);

    // Onderzoekt de stapel runs en identificeert het volgende paar runs dat moet worden samengevoegd.
    // Meer specifiek, als `Some(r)` wordt geretourneerd, betekent dit dat `runs[r]` en `runs[r + 1]` vervolgens moeten worden samengevoegd.
    // Als het algoritme in plaats daarvan moet doorgaan met het bouwen van een nieuwe run, wordt `None` geretourneerd.
    //
    // TimSort is berucht om zijn buggy-implementaties, zoals hier beschreven:
    // http://envisage-project.eu/timsort-specification-and-verification/
    //
    // De kern van het verhaal is: we moeten de invarianten op de bovenste vier runs op de stapel afdwingen.
    // Het afdwingen ervan op alleen de top drie is niet voldoende om ervoor te zorgen dat de invarianten nog steeds geldig zijn voor *alle* runs in de stapel.
    //
    // Deze functie controleert correct invarianten voor de top vier runs.
    // Bovendien, als de bovenste run begint bij index 0, zal het altijd een samenvoegbewerking vereisen totdat de stapel volledig is samengevouwen, om het sorteren te voltooien.
    //
    //
    #[inline]
    fn collapse(runs: &[Run]) -> Option<usize> {
        let n = runs.len();
        if n >= 2
            && (runs[n - 1].start == 0
                || runs[n - 2].len <= runs[n - 1].len
                || (n >= 3 && runs[n - 3].len <= runs[n - 2].len + runs[n - 1].len)
                || (n >= 4 && runs[n - 4].len <= runs[n - 3].len + runs[n - 2].len))
        {
            if n >= 3 && runs[n - 3].len < runs[n - 1].len { Some(n - 3) } else { Some(n - 2) }
        } else {
            None
        }
    }

    #[derive(Clone, Copy)]
    struct Run {
        start: usize,
        len: usize,
    }
}