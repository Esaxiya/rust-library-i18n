//! Implementatie van Rust panics via procesonderbrekingen
//!
//! In vergelijking met de implementatie via afwikkeling, is deze crate *veel* eenvoudiger!Dat gezegd hebbende, het is niet zo veelzijdig, maar hier gaat het!
//!

#![no_std]
#![unstable(feature = "panic_abort", issue = "32837")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/"
)]
#![panic_runtime]
#![allow(unused_features)]
#![feature(core_intrinsics)]
#![feature(nll)]
#![feature(panic_runtime)]
#![feature(std_internals)]
#![feature(staged_api)]
#![feature(rustc_attrs)]
#![feature(asm)]

use core::any::Any;
use core::panic::BoxMeUp;

#[rustc_std_internal_symbol]
#[allow(improper_ctypes_definitions)]
pub unsafe extern "C" fn __rust_panic_cleanup(_: *mut u8) -> *mut (dyn Any + Send + 'static) {
    unreachable!()
}

// "Leak" het laadvermogen en de vulring tot de relevante afbreken op het betreffende platform.
#[rustc_std_internal_symbol]
pub unsafe extern "C" fn __rust_start_panic(_payload: *mut &mut dyn BoxMeUp) -> u32 {
    abort();

    cfg_if::cfg_if! {
        if #[cfg(unix)] {
            unsafe fn abort() -> ! {
                libc::abort();
            }
        } else if #[cfg(any(target_os = "hermit",
                            all(target_vendor = "fortanix", target_env = "sgx")
        ))] {
            unsafe fn abort() -> ! {
                // bel std::sys::abort_internal
                extern "C" {
                    pub fn __rust_abort() -> !;
                }
                __rust_abort();
            }
        } else if #[cfg(all(windows, not(miri)))] {
            // Gebruik op Windows het processorspecifieke __fastfail-mechanisme.In Windows 8 en later wordt het proces onmiddellijk beëindigd zonder dat er in-process uitzonderingshandlers worden uitgevoerd.
            // In eerdere versies van Windows wordt deze reeks instructies behandeld als een toegangsschending, waardoor het proces wordt beëindigd, maar zonder noodzakelijkerwijs alle uitzonderingshandlers te omzeilen.
            //
            //
            // https://docs.microsoft.com/en-us/cpp/intrinsics/fastfail
            //
            // Note: dit is dezelfde implementatie als in libstd's `abort_internal`
            //
            //
            //
            unsafe fn abort() -> ! {
                const FAST_FAIL_FATAL_APP_EXIT: usize = 7;
                cfg_if::cfg_if! {
                    if #[cfg(any(target_arch = "x86", target_arch = "x86_64"))] {
                        asm!("int $$0x29", in("ecx") FAST_FAIL_FATAL_APP_EXIT);
                    } else if #[cfg(all(target_arch = "arm", target_feature = "thumb-mode"))] {
                        asm!(".inst 0xDEFB", in("r0") FAST_FAIL_FATAL_APP_EXIT);
                    } else if #[cfg(target_arch = "aarch64")] {
                        asm!("brk 0xF003", in("x0") FAST_FAIL_FATAL_APP_EXIT);
                    } else {
                        core::intrinsics::abort();
                    }
                }
                core::intrinsics::unreachable();
            }
        } else {
            unsafe fn abort() -> ! {
                core::intrinsics::abort();
            }
        }
    }
}

// Dit ... is een beetje vreemd.De tl; dr;is dat dit nodig is om correct te linken, de langere uitleg staat hieronder.
//
// Op dit moment zijn de binaire bestanden van libcore/libstd die we verzenden allemaal gecompileerd met `-C panic=unwind`.Dit wordt gedaan om ervoor te zorgen dat de binaire bestanden maximaal compatibel zijn met zoveel mogelijk situaties.
// De compiler heeft echter een "personality function" nodig voor alle functies die met `-C panic=unwind` zijn gecompileerd.Deze persoonlijkheidsfunctie is hard gecodeerd naar het symbool `rust_eh_personality` en wordt gedefinieerd door het item `eh_personality` lang.
//
// So...
// waarom definieer je dat lang item hier niet gewoon?Goede vraag!De manier waarop panic-runtimes zijn gekoppeld, is eigenlijk een beetje subtiel, omdat ze "sort of" zijn in de crate-winkel van de compiler, maar alleen echt zijn gekoppeld als een andere niet echt is gekoppeld.
//
// Dit betekent dat zowel deze crate als de panic_unwind crate kunnen verschijnen in de crate-winkel van de compiler, en als beide het `eh_personality` lang-item definiëren, zal er een fout optreden.
//
// Om dit af te handelen, vereist de compiler alleen dat de `eh_personality` is gedefinieerd als de panic-runtime die wordt gekoppeld de afwikkelende runtime is, en anders is het niet vereist om te worden gedefinieerd (terecht).
// In dit geval definieert deze bibliotheek dit symbool echter alleen, dus er is ergens een persoonlijkheid.
//
// In wezen is dit symbool zojuist gedefinieerd om te worden aangesloten op libcore/libstd-binaire bestanden, maar het mag nooit worden aangeroepen omdat we helemaal geen verbinding maken in een afwikkelende runtime.
//
//
//
//
//
//
//
//
//
//
//
//
pub mod personalities {
    #[rustc_std_internal_symbol]
    #[cfg(not(any(
        all(target_arch = "wasm32", not(target_os = "emscripten"),),
        all(target_os = "windows", target_env = "gnu", target_arch = "x86_64",),
    )))]
    pub extern "C" fn rust_eh_personality() {}

    // Op x86_64-pc-windows-gnu gebruiken we onze eigen persoonlijkheidsfunctie die `ExceptionContinueSearch` moet retourneren terwijl we al onze frames doorgeven.
    //
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86_64"))]
    pub extern "C" fn rust_eh_personality(
        _record: usize,
        _frame: usize,
        _context: usize,
        _dispatcher: usize,
    ) -> u32 {
        1 // `ExceptionContinueSearch`
    }

    // Net als hierboven komt dit overeen met het `eh_catch_typeinfo` lang-item dat momenteel alleen op Emscripten wordt gebruikt.
    //
    // Aangezien panics geen uitzonderingen genereert en buitenlandse uitzonderingen momenteel UB zijn met -C panic=abort (hoewel dit onderhevig kan zijn aan wijzigingen), zullen catch_unwind-aanroepen dit typeinfo nooit gebruiken.
    //
    //
    //
    #[rustc_std_internal_symbol]
    #[allow(non_upper_case_globals)]
    #[cfg(target_os = "emscripten")]
    static rust_eh_catch_typeinfo: [usize; 2] = [0; 2];

    // Deze twee worden aangeroepen door onze opstartobjecten op i686-pc-windows-gnu, maar ze hoeven niets te doen, dus de lichamen zijn nops.
    //
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86"))]
    pub extern "C" fn rust_eh_register_frames() {}
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86"))]
    pub extern "C" fn rust_eh_unregister_frames() {}
}