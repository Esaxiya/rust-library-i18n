// rsbegin.o en rsend.o zijn de zogenaamde "compiler runtime startup objects".
// Ze bevatten code die nodig is om de compilerruntime correct te initialiseren.
//
// Wanneer een uitvoerbare of dylib-afbeelding is gekoppeld, zijn alle gebruikerscode en bibliotheken "sandwiched" tussen deze twee objectbestanden, dus code of gegevens van rsbegin.o worden de eerste in de respectievelijke secties van de afbeelding, terwijl code en gegevens van rsend.o de laatste worden.
// Dit effect kan worden gebruikt om symbolen aan het begin of aan het einde van een sectie te plaatsen, en om eventueel vereiste kop-of voetteksten in te voegen.
//
// Merk op dat het feitelijke ingangspunt van de module zich bevindt in het C runtime-opstartobject (gewoonlijk `crtX.o` genoemd), dat vervolgens initialisatie-callbacks van andere runtime-componenten oproept (geregistreerd via nog een andere speciale afbeeldingssectie).
//
//
//
//
//
//

#![feature(no_core)]
#![feature(lang_items)]
#![feature(auto_traits)]
#![crate_type = "rlib"]
#![no_core]
#![allow(non_camel_case_types)]

#[lang = "sized"]
trait Sized {}
#[lang = "sync"]
auto trait Sync {}
#[lang = "copy"]
trait Copy {}
#[lang = "freeze"]
auto trait Freeze {}

#[lang = "drop_in_place"]
#[inline]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    drop_in_place(to_drop);
}

#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frames {
    #[no_mangle]
    #[link_section = ".eh_frame"]
    // Markeert het begin van het stapelframe met informatie over het afwikkelen
    pub static __EH_FRAME_BEGIN__: [u8; 0] = [];

    // Krasruimte voor de interne boekhouding van de afwikkelaar.
    // Dit wordt gedefinieerd als `struct object` in $ GCC/unsind-dw2-fde.h.
    static mut OBJ: [isize; 6] = [0; 6];

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                impl ::Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    // Ontspan info registration/deregistration-routines.
    // Zie de documenten van libpanic_unwind.
    extern "C" {
        fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8);
        fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8);
    }

    unsafe extern "C" fn init() {
        // registreren afwikkelen info over het opstarten van de module
        rust_eh_register_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    unsafe extern "C" fn uninit() {
        // uitschrijven bij afsluiten
        rust_eh_unregister_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    // MinGW-specifieke init/uninit-routineregistratie
    pub mod mingw_init {
        // De opstartobjecten van MinGW (crt0.o/dllcrt0.o) zullen globale constructors aanroepen in de .ctors-en .dtors-secties bij het opstarten en afsluiten.
        // In het geval van DLL's wordt dit gedaan wanneer de DLL wordt geladen en verwijderd.
        //
        // De linker sorteert de secties, wat ervoor zorgt dat onze callbacks aan het einde van de lijst staan.
        // Omdat constructors in omgekeerde volgorde worden uitgevoerd, zorgt dit ervoor dat onze callbacks de eerste en de laatste zijn die worden uitgevoerd.
        //
        //

        #[link_section = ".ctors.65535"] // .ctors. *: C initialisatie callbacks
        pub static P_INIT: unsafe extern "C" fn() = super::init;

        #[link_section = ".dtors.65535"] // .dtors. *: C beëindiging callbacks
        pub static P_UNINIT: unsafe extern "C" fn() = super::uninit;
    }
}