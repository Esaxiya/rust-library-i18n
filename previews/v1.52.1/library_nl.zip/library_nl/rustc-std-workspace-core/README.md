# De `rustc-std-workspace-core` crate

Deze crate is een shim en een lege crate die gewoon afhankelijk is van `libcore` en al zijn inhoud opnieuw exporteert.
De crate is de crux om de standaardbibliotheek in staat te stellen afhankelijk te zijn van crates van crates.io

Crates op crates.io waarvan de standaardbibliotheek afhankelijk is, moeten afhankelijk zijn van de `rustc-std-workspace-core` crate van crates.io, die leeg is.

We gebruiken `[patch]` om het in deze repository naar deze crate te overschrijven.
Als resultaat zal crates op crates.io een afhankelijkheid van edge tot `libcore` tekenen, de versie die in deze repository is gedefinieerd.
Dat zou alle afhankelijkheidsranden moeten trekken om ervoor te zorgen dat Cargo crates met succes bouwt!

Merk op dat crates op crates.io afhankelijk moet zijn van deze crate met de naam `core` om alles correct te laten werken.Om dat te doen kunnen ze gebruiken:

```toml
core = { version = "1.0.0", optional = true, package = 'rustc-std-workspace-core' }
```

Door het gebruik van de `package`-sleutel wordt de crate hernoemd naar `core`, wat betekent dat het eruit zal zien als

```
--extern core=.../librustc_std_workspace_core-XXXXXXX.rlib
```

wanneer Cargo de compiler aanroept, die voldoet aan de impliciete `extern crate core`-richtlijn die door de compiler is geïnjecteerd.




