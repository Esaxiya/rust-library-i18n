#![feature(no_core)]
#![no_core]

// rustc-std-የመስሪያ ቦታ-ኮር ይህ crate አስፈላጊ ነው ለምን ለ ይመልከቱ.

// በ liballoc ውስጥ ከሚሰጡት ሞዱል ጋር ላለመጋጨት የ crate ን እንደገና ይሰይሙ።
extern crate alloc as foo;

pub use foo::*;