//! አዲስ ማክሮዎችን ሲገልጹ ለማክሮ ደራሲዎች የድጋፍ ቤተ-መጽሐፍት ፡፡
//!
//! በመደበኛ ቤተ-መጽሐፍት የተሰጠው ይህ ቤተ-መጽሐፍት እንደ ተግባር ያሉ ማክሮዎች `#[proc_macro]` ፣ ማክሮ ባህሪዎች `#[proc_macro_attribute]` እና ብጁ የሚመጡ ባህሪዎች `#[proc_macro_derive]` በመሳሰሉ በሂደት በተገለጹ የማክሮ ትርጓሜዎች ውስጥ የሚበሉትን ዓይነቶች ያቀርባል ፡፡
//!
//!
//! ለተጨማሪ [the book] ይመልከቱ።
//!
//! [the book]: ../book/ch19-06-macros.html#procedural-macros-for-generating-code-from-attributes
//!
//!

#![stable(feature = "proc_macro_lib", since = "1.15.0")]
#![deny(missing_docs)]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    html_playground_url = "https://play.rust-lang.org/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/",
    test(no_crate_inject, attr(deny(warnings))),
    test(attr(allow(dead_code, deprecated, unused_variables, unused_mut)))
)]
#![feature(rustc_allow_const_fn_unstable)]
#![feature(nll)]
#![feature(staged_api)]
#![feature(const_fn)]
#![feature(const_fn_fn_ptr_basics)]
#![feature(allow_internal_unstable)]
#![feature(decl_macro)]
#![feature(extern_types)]
#![feature(in_band_lifetimes)]
#![feature(negative_impls)]
#![feature(auto_traits)]
#![feature(restricted_std)]
#![feature(rustc_attrs)]
#![feature(min_specialization)]
#![recursion_limit = "256"]

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
pub mod bridge;

mod diagnostic;

#[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
pub use diagnostic::{Diagnostic, Level, MultiSpan};

use std::cmp::Ordering;
use std::ops::{Bound, RangeBounds};
use std::path::PathBuf;
use std::str::FromStr;
use std::{error, fmt, iter, mem};

/// proc_macro ወደ አሁን እያሄደ ፕሮግራም ተደራሽ ተደርጓል ይወስናል.
///
/// አዋጁ_ማክሮ crate የአሠራር ማክሮዎችን ተግባራዊ ለማድረግ ብቻ የታሰበ ነው ፡፡በዚህ crate panic ውስጥ ሁሉም ተግባራት ከሆነ እንደ አንድ ግንባታ ስክሪፕት ወይም ዩኒት ፈተና ወይም ተራ Rust ሁለትዮሽ ጀምሮ እንደ የ ሥርዓታዊ ማክሮ ውጪ ከ ተጠርቷል.
///
/// ሁለቱንም ለማክሮ እና ለማክሮ ያልሆኑ አጠቃቀም ጉዳዮችን ለመደገፍ የተነደፉትን የ Rust ቤተመፃህፍት ከግምት ውስጥ በማስገባት `proc_macro::is_available()` የ proc_macro ኤፒአይን ለመጠቀም የሚያስፈልጉ መሠረተ ልማቶች በአሁኑ ጊዜ የሚገኙ መሆናቸውን ለመመልከት አስፈሪ ያልሆነ መንገድ ይሰጣል ፡፡
/// ከሂደቱ ማክሮ ውስጥ ከተጠራ ወደ እውነት ይመለሳል ፣ ከማንኛውም ሁለትዮሽ ከተጣራ ሐሰተኛ ነው።
///
///
///
///
///
///
///
#[unstable(feature = "proc_macro_is_available", issue = "71436")]
pub fn is_available() -> bool {
    bridge::Bridge::is_available()
}

/// ተጨማሪ በተለይም, tokens አንድ ረቂቅ ዥረት የሚወክል ወይም ይህንን crate የቀረበ ዋናው አይነት, token ዛፎች ተከታታይ.
/// አይነቱ በእነዚያ የ token ዛፎች ላይ ለዝግጅት እና እንዲሁም በተቃራኒው በርካታ የ token ዛፎችን በአንድ ጅረት ለመሰብሰብ በይነገጽ ይሰጣል ፡፡
///
///
/// ይህ የ `#[proc_macro]` ፣ `#[proc_macro_attribute]` እና `#[proc_macro_derive]` ትርጓሜዎች ግብዓት እና ውፅዓት ነው ፡፡
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Clone)]
pub struct TokenStream(bridge::client::TokenStream);

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for TokenStream {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for TokenStream {}

/// ስህተት ከ `TokenStream::from_str` ተመልሷል።
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Debug)]
pub struct LexError {
    _inner: (),
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl fmt::Display for LexError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("cannot parse string into token stream")
    }
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl error::Error for LexError {}

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for LexError {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for LexError {}

impl TokenStream {
    /// ምንም token ዛፎችን ያልያዘ ባዶ `TokenStream` ን ይመልሳል።
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new() -> TokenStream {
        TokenStream(bridge::client::TokenStream::new())
    }

    /// ይህ `TokenStream` ባዶ ከሆነ ይፈትሻል።
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn is_empty(&self) -> bool {
        self.0.is_empty()
    }
}

/// ሕብረቁምፊውን ወደ tokens ለመስበር እና እነዚያን tokens ን ወደ token ዥረት ለመተንተን የተደረጉ ሙከራዎች ፡፡
/// ለምሳሌ በብዙ ምክንያቶች ሊከሽፍ ይችላል ፣ ለምሳሌ ፣ ሕብረቁምፊው ሚዛኑን የጠበቀ ወሰን ወይም በቋንቋው ውስጥ የሌሉ ገጸ-ባህሪያትን የያዘ ከሆነ።
///
/// በ ሊተነተን ዥረት ውስጥ ሁሉም tokens `Span::call_site()` ጥማድ ያግኙ.
///
/// NOTE: `LexError` ን ከመመለስ ይልቅ አንዳንድ ስህተቶች panics ን ሊያስከትሉ ይችላሉ።እነዚህን ስህተቶች በኋላ ወደ `LexError`s የመቀየር መብታችን የተጠበቀ ነው ፡፡
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl FromStr for TokenStream {
    type Err = LexError;

    fn from_str(src: &str) -> Result<TokenStream, LexError> {
        Ok(TokenStream(bridge::client::TokenStream::from_str(src)))
    }
}

// ኤን.ቢ ፣ ድልድዩ `to_string` ን ብቻ ይሰጣል ፣ በእሱ ላይ የተመሠረተ `fmt::Display` ን ይተግብሩ (በሁለቱ መካከል ያለው የተለመደ ግንኙነት በተቃራኒው) ፡፡
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenStream {
    fn to_string(&self) -> String {
        self.0.to_string()
    }
}

/// የ `Zentoken0Z` ዥረትን ያለምንም ኪሳራ ወደ ተመሳሳይ የ token ዥረት (ሞዱሎ ስፖኖች) ሊለዋወጥ ይችላል ተብሎ እንደታሰበው ህትመት ያትማል ፣ ምናልባት `TokenTree: : Group`s በ `Delimiter::None` ገዳቢዎች እና በአሉታዊ የቁጥር ቁጥሮች
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Display for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// በአንድ ቅጽ ላይ አሻራ token ለማረም አመቺ.
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Debug for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("TokenStream ")?;
        f.debug_list().entries(self.clone()).finish()
    }
}

#[stable(feature = "proc_macro_token_stream_default", since = "1.45.0")]
impl Default for TokenStream {
    fn default() -> Self {
        TokenStream::new()
    }
}

#[unstable(feature = "proc_macro_quote", issue = "54722")]
pub use quote::{quote, quote_span};

/// አንዲት ነጠላ token ዛፍ የያዘ token ዥረት ይፈጥራል.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<TokenTree> for TokenStream {
    fn from(tree: TokenTree) -> TokenStream {
        TokenStream(bridge::client::TokenStream::from_token_tree(match tree {
            TokenTree::Group(tt) => bridge::TokenTree::Group(tt.0),
            TokenTree::Punct(tt) => bridge::TokenTree::Punct(tt.0),
            TokenTree::Ident(tt) => bridge::TokenTree::Ident(tt.0),
            TokenTree::Literal(tt) => bridge::TokenTree::Literal(tt.0),
        }))
    }
}

/// በአንድ ዥረት ወደ token ዛፎች በርካታ ይሰበስባል.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl iter::FromIterator<TokenTree> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenTree>>(trees: I) -> Self {
        trees.into_iter().map(TokenStream::from).collect()
    }
}

/// በ token ዥረቶች ላይ የ‹XXXX›ክወና ከ token ዥረቶች ውስጥ የ token ዛፎችን ከአንድ ዥረት ይሰበስባል ፡፡
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl iter::FromIterator<TokenStream> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenStream>>(streams: I) -> Self {
        let mut builder = bridge::client::TokenStreamBuilder::new();
        streams.into_iter().for_each(|stream| builder.push(stream.0));
        TokenStream(builder.build())
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenTree> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenTree>>(&mut self, trees: I) {
        self.extend(trees.into_iter().map(TokenStream::from));
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenStream> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenStream>>(&mut self, streams: I) {
        // FIXME(eddyb) በተቻለ መጠን የተመቻቸ ትግበራ if/when ይጠቀሙ።
        *self = iter::once(mem::replace(self, Self::new())).chain(streams).collect();
    }
}

/// ለ‹XXXXX›አይነት እንደ የህዝብ ማመላለሻ ዝርዝሮች።
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub mod token_stream {
    use crate::{bridge, Group, Ident, Literal, Punct, TokenStream, TokenTree};

    /// በ‹TokenStream``s TokenTree`s ላይ አንድ ተደጋጋሚ ፡፡
    /// የ ተደጋጋሚነት ለተደጋጋሚ በመመስረት ነው ቡድኖች ወደ recurse አይደለም ያለውን ለምሳሌ "shallow",,, እና ይመለሳል token ዛፎች እንደ ሙሉ ቡድኖች ነው.
    ///
    #[derive(Clone)]
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub struct IntoIter(bridge::client::TokenStreamIter);

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl Iterator for IntoIter {
        type Item = TokenTree;

        fn next(&mut self) -> Option<TokenTree> {
            self.0.next().map(|tree| match tree {
                bridge::TokenTree::Group(tt) => TokenTree::Group(Group(tt)),
                bridge::TokenTree::Punct(tt) => TokenTree::Punct(Punct(tt)),
                bridge::TokenTree::Ident(tt) => TokenTree::Ident(Ident(tt)),
                bridge::TokenTree::Literal(tt) => TokenTree::Literal(Literal(tt)),
            })
        }
    }

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl IntoIterator for TokenStream {
        type Item = TokenTree;
        type IntoIter = IntoIter;

        fn into_iter(self) -> IntoIter {
            IntoIter(self.0.into_iter())
        }
    }
}

/// `quote!(..)` የዘፈቀደ tokens ን ይቀበላል እና ግቤቱን ወደ ሚገልጽ `TokenStream` ያስፋፋል።
/// ለምሳሌ ፣ `quote!(a + b)` አገላለፅን ያወጣል ፣ ሲገመገም የ `TokenStream` `[Ident("a") ፣ Punct('+', Alone) ፣ Ident("b")]`.
///
///
/// ማራገፍ በ `$` ይከናወናል ፣ እና የሚሠራውን ነጠላ መታወቂያ እንደ ያልተጠቀሰ ቃል በመውሰድ ይሠራል።
/// `$` ን ለመጥቀስ `$$` ን ይጠቀሙ።
#[unstable(feature = "proc_macro_quote", issue = "54722")]
#[allow_internal_unstable(proc_macro_def_site)]
#[rustc_builtin_macro]
pub macro quote($($t:tt)*) {
    /* compiler built-in */
}

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
mod quote;

/// የመነሻ ኮድ ክልል ፣ ከማክሮ ማስፋፊያ መረጃ ጋር ፡፡
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Copy, Clone)]
pub struct Span(bridge::client::Span);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Span {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Span {}

macro_rules! diagnostic_method {
    ($name:ident, $level:expr) => {
        /// በተሰጠው X0 `self` በተሰጠው `message` አዲስ `Diagnostic` ን ይፈጥራል።
        ///
        #[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
        pub fn $name<T: Into<String>>(self, message: T) -> Diagnostic {
            Diagnostic::spanned(self, $level, message)
        }
    };
}

impl Span {
    /// በ ማክሮ ትርጉም ጣቢያ ላይ አንድ ስንዝር መሆኑን ውሳኔህን.
    #[unstable(feature = "proc_macro_def_site", issue = "54724")]
    pub fn def_site() -> Span {
        Span(bridge::client::Span::def_site())
    }

    /// የአሁኑ በሥርዓታዊ ማክሮ መካከል አማላጅ ርዝማኔ.
    /// በዚህ ጊዜ የተፈጠሩ መታወቂያዎች በቀጥታ በማክሮ ጥሪ ቦታ (የጥሪ ጣቢያ ንፅህና) የተፃፉ ያህል መፍትሄ ያገኛሉ እንዲሁም በማክሮ የጥሪ ጣቢያው ላይ ያለው ሌላ ኮድ እነሱንም ሊያመለክት ይችላል ፡፡
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn call_site() -> Span {
        Span(bridge::client::Span::call_site())
    }

    /// የ‹XXXX›ንፅህናን የሚወክል ፣ እና አንዳንድ ጊዜ በማክሮ ትርጉም ጣቢያ (የአከባቢ ተለዋዋጮች ፣ መለያዎች ፣ `$crate`) እና አንዳንዴም በማክሮ የጥሪ ጣቢያ (ሌሎች ሁሉም ነገሮች) ይፈታል ፡፡
    ///
    /// የስፋቱ ቦታ ከጥሪው ጣቢያው ተወስዷል።
    ///
    #[stable(feature = "proc_macro_mixed_site", since = "1.45.0")]
    pub fn mixed_site() -> Span {
        Span(bridge::client::Span::mixed_site())
    }

    /// የመጀመሪያው ምንጭ ፋይል የሆነውን ይህንን ስንዝር ነጥቦች ውስጥ.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_file(&self) -> SourceFile {
        SourceFile(self.0.source_file())
    }

    /// `self` ካለ የመነጨ ነበር ይህም ከ ቀደም ማክሮ ማስፋፊያ ውስጥ tokens ለ `Span`.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn parent(&self) -> Option<Span> {
        self.0.parent().map(Span)
    }

    /// `self` የመነጨው የመነሻ ምንጭ ኮድ ርዝመት።
    /// ይህ `Span` ከሌሎቹ ማክሮ ማስፋፊያዎች ካልተፈጠረ ታዲያ የመመለሻ ዋጋ ከ `*self` ጋር ተመሳሳይ ነው።
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source(&self) -> Span {
        Span(self.0.source())
    }

    /// ለዚህ ስንዝር የሚሆን ምንጭ ፋይል ውስጥ ጀምሮ line/column ያገኛል.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn start(&self) -> LineColumn {
        self.0.start()
    }

    /// ለዚህ ስንዝር የሚሆን ምንጭ ፋይል ውስጥ እንዲያጠናቅቁ line/column ያገኛል.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn end(&self) -> LineColumn {
        self.0.end()
    }

    /// `self` እና `other` ን የሚያካትት አዲስ ጊዜን ይፈጥራል።
    ///
    /// `self` እና `other` የተለያዩ ፋይሎች ከ ከሆነ ይመልሳል `None`.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn join(&self, other: Span) -> Option<Span> {
        self.0.join(other.0).map(Span)
    }

    /// እንደ `self` ተመሳሳይ የ line/column መረጃ ያለው አዲስ ጊዜን ይፈጥራል ነገር ግን ያ ምልክቶችን በ‹XXXX›እንደሆነ ይፈታል ፡፡
    ///
    #[stable(feature = "proc_macro_span_resolved_at", since = "1.45.0")]
    pub fn resolved_at(&self, other: Span) -> Span {
        Span(self.0.resolved_at(other.0))
    }

    /// ከ `self` ጋር ተመሳሳይ የስም ጥራት ባህሪ ያለው አዲስ ስፋትን ይፈጥራል ግን በ `other` የ line/column መረጃ።
    ///
    #[stable(feature = "proc_macro_span_located_at", since = "1.45.0")]
    pub fn located_at(&self, other: Span) -> Span {
        other.resolved_at(*self)
    }

    /// እኩል መሆናቸውን ለማየት ከስፋቶች ጋር ያወዳድራል።
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn eq(&self, other: &Span) -> bool {
        self.0 == other.0
    }

    /// ከእስፔን በስተጀርባ የምንጭ ጽሑፍን ይመልሳል።
    /// ይህ ቦታዎችን እና አስተያየቶችን ጨምሮ ዋናውን ምንጭ ኮድ ይጠብቃል።
    /// ስንዝር እውነተኛ ምንጭ ኮድ ጋር አብሮ የሚሄድ ከሆነ ብቻ ውጤት ይመልሳል.
    ///
    /// Note: የማክሮ ታዛቢ ውጤት በ tokens ላይ ብቻ መተማመን አለበት እና በዚህ ምንጭ ጽሑፍ ላይ አይደለም ፡፡
    ///
    /// የዚህ ተግባር ውጤት ብቻ ዲያግኖስቲክስ ሊውል ወደ አንድ የተሻለ ጥረት ነው.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_text(&self) -> Option<String> {
        self.0.source_text()
    }

    diagnostic_method!(error, Level::Error);
    diagnostic_method!(warning, Level::Warning);
    diagnostic_method!(note, Level::Note);
    diagnostic_method!(help, Level::Help);
}

/// ለማረም ምቹ በሆነ ቅጽ ላይ ስፓን ያትማል።
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Span {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// የ `Span` መጀመሪያ ወይም መጨረሻ የሚወክል የመስመር-አምድ ጥንድ።
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct LineColumn {
    /// (inclusive) ን የሚጀምርበት ወይም የሚያበቃበት ምንጭ ፋይል ውስጥ ባለ 1 ጠቋሚ መስመር።
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub line: usize,
    /// ምንጭ ፋይል የሆነውን ላይ ስንዝር ይጀምራል ወይም ጫፎች (inclusive) ውስጥ 0-የተሰናዳ አምድ (UTF-8 ፊደላት).
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub column: usize,
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Send for LineColumn {}
#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Sync for LineColumn {}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Ord for LineColumn {
    fn cmp(&self, other: &Self) -> Ordering {
        self.line.cmp(&other.line).then(self.column.cmp(&other.column))
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialOrd for LineColumn {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

/// የተሰጠው `Span` ምንጭ ፋይል።
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Clone)]
pub struct SourceFile(bridge::client::SourceFile);

impl SourceFile {
    /// ወደዚህ ምንጭ ፋይል የሚወስደውን መንገድ ያገኛል።
    ///
    /// ### Note
    /// ከዚህ `SourceFile` ጋር የተጎዳኘው ኮድ ስንዝር ውጫዊ ማክሮ, በዚህ ማክሮ የመነጨ ከሆነ, ይህ በስርዓተ ላይ ትክክለኛ ዱካ መሆን ይችላል.
    /// ለማጣራት [`is_real`] ን ይጠቀሙ።
    ///
    /// በተጨማሪም `--remap-path-prefix` በትእዛዝ መስመር ላይ አለፈ ነበር ከሆነ `is_real`, `true` ይመልሳል እንኳ በዚያ ማስታወሻ, የተሰጠው እንደ መንገድ በእርግጥ ልክ ላይሆን ይችላል.
    ///
    ///
    /// [`is_real`]: Self::is_real
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn path(&self) -> PathBuf {
        PathBuf::from(self.0.path())
    }

    /// ይህ የምንጭ ፋይል እውነተኛ ምንጭ ፋይል ከሆነ እና በውጭ ማክሮ ማስፋፊያ ካልተፈጠረ `true` ን ይመልሳል።
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn is_real(&self) -> bool {
        // intercrate ጥማድ ተግባራዊ ሲሆን እኛም ውጫዊ ውስጥ ከተነደፈ የመነጨ ጥማድ ለማግኘት እውነተኛ ምንጭ ፋይሎች ይችላል ድረስ ይህ ኡሁ ነው.
        //
        // https://github.com/rust-lang/rust/pull/43604#issuecomment-333334368
        self.0.is_real()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl fmt::Debug for SourceFile {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("SourceFile")
            .field("path", &self.path())
            .field("is_real", &self.is_real())
            .finish()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialEq for SourceFile {
    fn eq(&self, other: &Self) -> bool {
        self.0.eq(&other.0)
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Eq for SourceFile {}

/// አንድ ነጠላ token ወይም የተወሰነ የ token ዛፎች (ለምሳሌ `[1, (), ..]`)።
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub enum TokenTree {
    /// አንድ token ዥረት ቅንፍ ገደብ ተከባ.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Group(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Group),
    /// መለያ
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Ident(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Ident),
    /// አንድ ነጠላ የስርዓተ ነጥብ ቁምፊ (`+`, `,`, `$`, ወዘተ).
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Punct(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Punct),
    /// ቃል በቃል ቁምፊ (`'a'`) ፣ ክር (`"hello"`) ፣ ቁጥር (`2.3`) ፣ ወዘተ።
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Literal(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Literal),
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for TokenTree {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for TokenTree {}

impl TokenTree {
    /// ለተያዘው token ወይም ለተወሰነ ዥረት የ `span` ዘዴን በመስጠት የዚህን ዛፍ ርዝመት ይመልሳል።
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        match *self {
            TokenTree::Group(ref t) => t.span(),
            TokenTree::Ident(ref t) => t.span(),
            TokenTree::Punct(ref t) => t.span(),
            TokenTree::Literal(ref t) => t.span(),
        }
    }

    /// ስፋቱን ለ *ለዚህ token* ብቻ ያዋቅራል።
    ///
    /// ልብ ይበሉ ይህ token `Group` ከሆነ ይህ ዘዴ የእያንዳንዱን ውስጣዊ tokens ርዝመት አያዋቅርም ፣ ይህ በቀላሉ ወደ እያንዳንዱ የ‹`set_span`›ዘዴ ይወክላል ፡፡
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        match *self {
            TokenTree::Group(ref mut t) => t.set_span(span),
            TokenTree::Ident(ref mut t) => t.set_span(span),
            TokenTree::Punct(ref mut t) => t.set_span(span),
            TokenTree::Literal(ref mut t) => t.set_span(span),
        }
    }
}

/// የ token ዛፍን ለማረም ምቹ በሆነ ቅጽ ያትማል ፡፡
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // እያንዳንዳቸው በተገኘው ማረም ውስጥ ባለው የመዋቅር ዓይነት ውስጥ ስያሜ አላቸው ፣ ስለሆነም በተዘዋዋሪ ተጨማሪ ንብርብር አይረብሹ
        //
        match *self {
            TokenTree::Group(ref tt) => tt.fmt(f),
            TokenTree::Ident(ref tt) => tt.fmt(f),
            TokenTree::Punct(ref tt) => tt.fmt(f),
            TokenTree::Literal(ref tt) => tt.fmt(f),
        }
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Group> for TokenTree {
    fn from(g: Group) -> TokenTree {
        TokenTree::Group(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Ident> for TokenTree {
    fn from(g: Ident) -> TokenTree {
        TokenTree::Ident(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Punct> for TokenTree {
    fn from(g: Punct) -> TokenTree {
        TokenTree::Punct(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Literal> for TokenTree {
    fn from(g: Literal) -> TokenTree {
        TokenTree::Literal(g)
    }
}

// ኤን.ቢ ፣ ድልድዩ `to_string` ን ብቻ ይሰጣል ፣ በእሱ ላይ የተመሠረተ `fmt::Display` ን ይተግብሩ (በሁለቱ መካከል ያለው የተለመደ ግንኙነት በተቃራኒው) ፡፡
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenTree {
    fn to_string(&self) -> String {
        match *self {
            TokenTree::Group(ref t) => t.to_string(),
            TokenTree::Ident(ref t) => t.to_string(),
            TokenTree::Punct(ref t) => t.to_string(),
            TokenTree::Literal(ref t) => t.to_string(),
        }
    }
}

/// የ‹Xentoken0Z›ዛፍን ያለምንም ኪሳራ ወደ ተመሳሳይ የ‹token ዛፍ›(ሞዱሎ እስፔኖች) ሊለዋወጥ ይችላል ተብሎ በሚታሰበው ገመድ ያትማል ፣ ምናልባትም‹TokenTree: : የቡድን›በ‹`Delimiter::None` X›ገዳቢዎች እና አሉታዊ የቁጥር ቁጥሮች ፡፡
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// የተወሰነ የ token ዥረት።
///
/// አንድ `Group` በውስጥ Delimiter`s`ተከቦ ነው ይህም አንድ `TokenStream` ይዟል.
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Group(bridge::client::Group);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Group {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Group {}

/// የ token ዛፎች ቅደም ተከተል እንዴት እንደሚገደብ ይገልጻል።
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Delimiter {
    /// `( ... )`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Parenthesis,
    /// `{ ... }`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Brace,
    /// `[ ... ]`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Bracket,
    /// `Ø ... Ø`
    /// አንድ ስውር ገዳቢ, ይህ ለምሳሌ ያህል, አንድ "macro variable" `$var` የሚመጡ tokens ዙሪያ ሊታይ ይችላል.
    /// `$var` `1 + 2` ባለበት እንደ `$var * 3` ባሉ ጉዳዮች ላይ ኦፕሬተርን ቅድሚያ መስጠት አስፈላጊ ነው ፡፡
    /// በውስጥ የሚታወቅ ገደብ ሕብረቁምፊ በኩል token ዥረት መካከል roundtrip በሕይወት ይችላል.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    None,
}

impl Group {
    /// በተሰጠው ገዳቢ እና token ዥረት አዲስ `Group` ን ይፈጥራል።
    ///
    /// ይህ ገንቢ የዚህን ቡድን ስፋቱን ወደ `Span::call_site()` ያዘጋጃል።
    /// ስፋቱን ለመለወጥ ከዚህ በታች ያለውን የ `set_span` ዘዴን መጠቀም ይችላሉ።
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(delimiter: Delimiter, stream: TokenStream) -> Group {
        Group(bridge::client::Group::new(delimiter, stream.0))
    }

    /// የዚህን `Group` ወሰን ይመልሳል
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn delimiter(&self) -> Delimiter {
        self.0.delimiter()
    }

    /// ይመለሳል በዚህ `Group` ላይ በመመስረት ነው ያሉት tokens ያለውን `TokenStream`.
    ///
    /// ማስታወሻ ተመልሶ token ዥረት ወደ ገዳቢ ከላይ ተመለሱ አያጠቃልልም ነው.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn stream(&self) -> TokenStream {
        TokenStream(self.0.stream())
    }

    /// መላውን `Group` ን በመዘርጋት የዚህ የ token ዥረት ወሰን ስፋት ይመልሳል።
    ///
    ///
    /// ```text
    /// pub fn span(&self) -> Span {
    ///            ^^^^^^^
    /// ```
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// ወደዚህ ቡድን የመክፈቻ ወሰን የሚያመለክት ጊዜን ይመልሳል።
    ///
    /// ```text
    /// pub fn span_open(&self) -> Span {
    ///                 ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_open(&self) -> Span {
        Span(self.0.span_open())
    }

    /// ወደዚህ ቡድን የመዝጊያ ወሰን የሚያመለክት ጊዜን ይመልሳል።
    ///
    /// ```text
    /// pub fn span_close(&self) -> Span {
    ///                        ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_close(&self) -> Span {
        Span(self.0.span_close())
    }

    /// የዚህ `የቡድን` ወሰን ሰጭዎችን ያዋቅራል ፣ ግን ውስጣዊ tokens አይደለም።
    ///
    /// ይህ ዘዴ ** ** የውስጥ tokens በዚህ ቡድን ይከፈላል ሁሉ ስንዝር ማዘጋጀት, ነገር ግን ይልቅ ብቻ `Group` ደረጃ ላይ ገዳቢ tokens ያለውን ስንዝር ማዘጋጀት ይሆናል.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }
}

// ኤን.ቢ ፣ ድልድዩ `to_string` ን ብቻ ይሰጣል ፣ በእሱ ላይ የተመሠረተ `fmt::Display` ን ይተግብሩ (በሁለቱ መካከል ያለው የተለመደ ግንኙነት በተቃራኒው) ፡፡
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Group {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// ከ‹XXXX ወሰን›ጋር ምናልባት`TokenTree: : Group`s `ካልሆነ በስተቀር ቡድኑን ያለምንም ኪሳራ ወደ ተመሳሳይ ቡድን (ሞዱሎ እስፔኖች) መለወጥ እንዳለበት ሕብረቁምፊ ያትማል ፡፡
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Group")
            .field("delimiter", &self.delimiter())
            .field("stream", &self.stream())
            .field("span", &self.span())
            .finish()
    }
}

/// `Punct` እንደ `+` ፣ `-` ወይም `#` ያሉ አንድ ነጠላ ስርዓተ-ነጥብ ቁምፊ ነው።
///
/// እንደ `+=` ያሉ ባለብዙ ቁምፊ አንቀሳቃሾች እንደ `Punct` ሁለት አጋጣሚዎች ይወከላሉ ፡፡
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub struct Punct(bridge::client::Punct);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Punct {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Punct {}

/// አንድ `Punct` ሌላ `Punct` በ ወዲያውኑ ተከትሎ ወይም ሌላ token ወይም አርጌ ተከትሎ ነው አይሁን.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Spacing {
    /// ለምሳሌ ፣ `+` በ `+ =` ፣ `+ident` ወይም `+()` ውስጥ `Alone` ነው ፡፡
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Alone,
    /// ለምሳሌ ፣ `+` በ `+=` ወይም `'#` ውስጥ `Joint` ነው ፡፡
    /// በተጨማሪም ፣ ነጠላ ዋጋ `'` የሕይወት ዘመን `'ident` ን ለመመስረት ከለሚዎች ጋር መቀላቀል ይችላል።
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Joint,
}

impl Punct {
    /// ከተሰጠው ገጸ-ባህሪ እና ክፍተት አዲስ `Punct` ን ይፈጥራል።
    /// የ `ch` ክርክር በቋንቋው የተፈቀደ ትክክለኛ ስርዓተ-ነጥብ ቁምፊ መሆን አለበት ፣ አለበለዚያ ተግባሩ panic ይሆናል።
    ///
    /// የ ተመለሰ `Punct` ተጨማሪ ከታች ያለውን `set_span` ስልት ጋር ሊዋቀር ይችላል `Span::call_site()` ነባሪውን ዕድሜ ይኖረዋል.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(ch: char, spacing: Spacing) -> Punct {
        Punct(bridge::client::Punct::new(ch, spacing))
    }

    /// `char` እንደ በዚህ የስርዓተ ነጥብ ቁምፊ ያለውን እሴት ይመልሳል.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn as_char(&self) -> char {
        self.0.as_char()
    }

    /// የዚህ ስርዓተ-ነጥብ ቁምፊ ክፍተትን ይመልሳል ፣ ይህም ወዲያውኑ በ‹token›ዥረት ውስጥ ሌላ‹`Punct`›መከተሉን ያሳያል ፣ ስለሆነም እነሱ ወደ ባለብዙ-ባህርይ ኦፕሬተር (`Joint`) ሊደባለቁ ይችላሉ ፣ ወይም ደግሞ አንዳንድ ሌሎች token ወይም የነፃ ቦታ (`Alone`) ን ይከተላል ስለዚህ ኦፕሬተሩ በእርግጠኝነት አለው አልቋል.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn spacing(&self) -> Spacing {
        self.0.spacing()
    }

    /// ለዚህ የሥርዓት ሥርዓተ-ቁምፊ ቁምፊ ድምርን ይመልሳል።
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// ለዚህ ስርዓተ-ነጥብ ስርዓተ-ጥለት ስፋትን ያዋቅሩ።
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// ኤን.ቢ ፣ ድልድዩ `to_string` ን ብቻ ይሰጣል ፣ በእሱ ላይ የተመሠረተ `fmt::Display` ን ይተግብሩ (በሁለቱ መካከል ያለው የተለመደ ግንኙነት በተቃራኒው) ፡፡
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Punct {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// ተመሳሳይ ቁምፊ ወደ losslessly የሚመነዘር ወደ ኋላ መሆን እንዳለበት እንደ ሕብረቁምፊ የስርዓተ ነጥብ ቁምፊ አሻራ.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Punct")
            .field("ch", &self.as_char())
            .field("spacing", &self.spacing())
            .field("span", &self.span())
            .finish()
    }
}

#[stable(feature = "proc_macro_punct_eq", since = "1.50.0")]
impl PartialEq<char> for Punct {
    fn eq(&self, rhs: &char) -> bool {
        self.as_char() == *rhs
    }
}

#[stable(feature = "proc_macro_punct_eq_flipped", since = "1.52.0")]
impl PartialEq<Punct> for char {
    fn eq(&self, rhs: &Punct) -> bool {
        *self == rhs.as_char()
    }
}

/// መለያ (`ident`).
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Ident(bridge::client::Ident);

impl Ident {
    /// በተጠቀሰው `string` እንዲሁም በተጠቀሰው `span` አዲስ `Ident` ን ይፈጥራል።
    /// የ `string` ክርክር በቋንቋው የሚፈቀድ ትክክለኛ መለያ መሆን አለበት (ቁልፍ ቃላትን ጨምሮ ፣ ለምሳሌ `self` ወይም `fn`)።አለበለዚያ, ተግባር panic ያደርጋል.
    ///
    /// `span` ፣ በአሁኑ ጊዜ በ rustc ውስጥ ፣ የዚህ መለያ ለንፅህና መረጃን እንደሚያዋቅር ልብ ይበሉ።
    ///
    /// `Span::call_site()` በግልጽ ያስወጣዎታል-በ "call-site" ንፅህና ትርጉም ወደ እነርሱ ማክሮ ጥሪ ቦታ ላይ በቀጥታ የተጻፉት ከሆነ እንደ በዚህ ስንዝር ጋር የተፈጠሩ መለያዎችን መፍትሔ ይሆናል, እና ማክሮ ጥሪ ጣቢያ ላይ ሌላ ኮድ ለማመልከት ይችላሉ በዚህ ጊዜ እንደ እነሱም እንዲሁ ፡፡
    ///
    ///
    /// `Span::def_site()` ያሉ በኋላ ሊቃውንት ይህን ስንዝር ጋር የተፈጠሩ መለያዎችን እነሱን ለማመልከት አይችሉም በ ማክሮ ጥሪ ጣቢያ ላይ ማክሮ ትርጉም እና ሌሎች ኮድ አካባቢ ላይ መፍትሄ ይሆናል ማለት "definition-site" አጠባበቅ ወደ መርጦ-ውስጥ ያስችላቸዋል.
    ///
    /// ምክንያት አጠባበቅ በዚህ ግንበኛ የአሁኑ አስፈላጊነት, ሌሎች tokens በተለየ ግንባታ ላይ መጠቀስ አንድ `Span` ይጠይቃል.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, false))
    }

    /// `Ident::new` ተመሳሳይ, ነገር ግን አንድ ጥሬ መለያ (`r#ident`) ይፈጥራል.
    /// የ `string` ክርክር (ለምሳሌ `fn`, ቁልፍ ቃላትን ጨምሮ) ቋንቋ በሚፈቅደው ልክ የሆነ መለያ ይሆናል.
    /// ዱካ ክፍሎች ውስጥ ሊውል የሚችል የሆኑ ቁልፍ ቃላት (ለምሳሌ
    /// `self`, `) Super` አይደገፉም, እና አንድ panic ያደርጋል.
    #[stable(feature = "proc_macro_raw_ident", since = "1.47.0")]
    pub fn new_raw(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, true))
    }

    /// በ [`to_string`](Self::to_string) የተመለሰውን ሙሉውን ሕብረቁምፊ በማካተት የዚህን የ `Ident` ርዝመት ያወጣል።
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// ምናልባትም በውስጡ አጠባበቅ አውድ መቀየር በዚህ `Ident` ላይ ስንዝር, ያዋቅራል.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// ኤን.ቢ ፣ ድልድዩ `to_string` ን ብቻ ይሰጣል ፣ በእሱ ላይ የተመሠረተ `fmt::Display` ን ይተግብሩ (በሁለቱ መካከል ያለው የተለመደ ግንኙነት በተቃራኒው) ፡፡
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Ident {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// መለያ ወደ መለያ ወደ መለያው ያለምንም ኪሳራ ሊለዋወጥ እንደሚገባው መለያውን ያወጣል።
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Ident")
            .field("ident", &self.to_string())
            .field("span", &self.span())
            .finish()
    }
}

/// ቃል በቃል (`"hello"`) ፣ ባይት ሕብረቁምፊ (`b"hello"`) ፣ ቁምፊ (`'a'`) ፣ ባይት ቁምፊ (`b'a'`) ፣ አንድ ኢንቲጀር ወይም ተንሳፋፊ ነጥብ ቁጥር በቅጥያ ቅጥያ ወይም ያለ (`1` ፣ `1u8` ፣ `2.3` ፣ `2.3f32`)።
///
/// እንደ `true` እና `false` ያሉ የቦሊያንኛ ጽሑፎች እዚህ አይገኙም ፣ እነሱ `መታወቂያዎች` ናቸው ፡፡
///
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Literal(bridge::client::Literal);

macro_rules! suffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// ድሕረ ቅጥያ ኢንቲጀር ቃል በቃል አዲስ የተገለጸውን እሴት ጋር ይፈጥራል.
        ///
        /// በተጠቀሰው ኢንቲጀር ዋጋ token የመጀመሪያ ክፍል ነው እንዲሁም ዓቢይ ደግሞ መጨረሻ ላይ ድሕረ ቅጥያ ነው የት ይህ ተግባር `1u32` እንደ አንድ ኢንቲጀር ይፈጥራል.
        /// አሉታዊ ቁጥሮች የተፈጠረ Literals `TokenStream` ወይም ሕብረ በኩል ክብ-ጉዞዎችን መኖር ይችላል እና ሁለት tokens (`-` እና አወንታዊ በቃል) ውስጥ ሰርጎ ገብቶ ሊሆን ይችላል.
        ///
        ///
        /// በዚህ ዘዴ አማካኝነት የተፈጠሩ Literals ከዚህ በታች ያለውን `set_span` ስልት ጋር ሊዋቀር ይችላል በነባሪነት `Span::call_site()` ስንዝር አለን.
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::typed_integer(&n.to_string(), stringify!($kind)))
        }
    )*)
}

macro_rules! unsuffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// ከተጠቀሰው እሴት ጋር አዲስ ያልተሞላ ኢንቲጀር ቃል በቃል ይፈጥራል።
        ///
        /// ይህ ተግባር የተጠቀሰው ኢንቲጀር እሴት የ token የመጀመሪያ ክፍል ሆኖ የሚገኝበትን `1` የመሰለ ኢንቲጀር ይፈጥራል።
        /// በዚህ token ላይ ምንም ቅጥያ አልተገለጸም ፣ ማለትም እንደ `Literal::i8_unsuffixed(1)` ያሉ ልመናዎች ከ `Literal::u32_unsuffixed(1)` ጋር እኩል ናቸው ማለት ነው ፡፡
        /// ከአሉታዊ ቁጥሮች የተፈጠሩ ስነ-ፅሁፎች በ‹XXXXXX›ወይም በ‹XXXXX›ወይም በ‹XXXX›ሕብረቁምፊዎች በኩል በሕይወት አይቆዩም እና በሁለት tokens (`-` እና አዎንታዊ ቃል በቃል) ይከፈላሉ ፡፡
        ///
        ///
        /// በዚህ ዘዴ አማካኝነት የተፈጠሩ Literals ከዚህ በታች ያለውን `set_span` ስልት ጋር ሊዋቀር ይችላል በነባሪነት `Span::call_site()` ስንዝር አለን.
        ///
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::integer(&n.to_string()))
        }
    )*)
}

impl Literal {
    suffixed_int_literals! {
        u8_suffixed => u8,
        u16_suffixed => u16,
        u32_suffixed => u32,
        u64_suffixed => u64,
        u128_suffixed => u128,
        usize_suffixed => usize,
        i8_suffixed => i8,
        i16_suffixed => i16,
        i32_suffixed => i32,
        i64_suffixed => i64,
        i128_suffixed => i128,
        isize_suffixed => isize,
    }

    unsuffixed_int_literals! {
        u8_unsuffixed => u8,
        u16_unsuffixed => u16,
        u32_unsuffixed => u32,
        u64_unsuffixed => u64,
        u128_unsuffixed => u128,
        usize_unsuffixed => usize,
        i8_unsuffixed => i8,
        i16_unsuffixed => i16,
        i32_unsuffixed => i32,
        i64_unsuffixed => i64,
        i128_unsuffixed => i128,
        isize_unsuffixed => isize,
    }

    /// አዲስ ያልተሞላ ተንሳፋፊ-ነጥብ ቃል በቃል ይፈጥራል።
    ///
    /// ይህም በኋላ አጠናቃሪ ውስጥ `f64` መሆን አያመለክትም ይችላል, ስለዚህ ይህ ግንበኛ, የ እንዲንሳፈፍ ያለው ዋጋ token በቀጥታ ወደ ከመነጋገሩ ነው ነገር ግን ምንም ቅጥያ ጥቅም ላይ የት `Literal::i8_unsuffixed` እንደ ሰዎች ጋር ተመሳሳይ ነው.
    ///
    /// ከአሉታዊ ቁጥሮች የተፈጠሩ ስነ-ፅሁፎች በ‹XXXXXX›ወይም በ‹XXXXX›ወይም በ‹XXXX›ሕብረቁምፊዎች በኩል በሕይወት አይቆዩም እና በሁለት tokens (`-` እና አዎንታዊ ቃል በቃል) ይከፈላሉ ፡፡
    ///
    /// # Panics
    ///
    /// ይህ ተግባር የተጠቀሰው ተንሳፋፊ ውስን መሆን ይጠይቃል ፣ ለምሳሌ ማለቂያ የሌለው ከሆነ ወይም ናን ይህ ተግባር panic ን ያደርገዋል።
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_unsuffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// አዲስ ድሕረ ቅጥያ ተንሳፋፊ-ነጥብ በቃል ይፈጥራል.
    ///
    /// ይህ ግንበኛ የተገለጸው እሴቱ የ token ቀዳሚው ክፍል ሲሆን `f32` ደግሞ የ token ቅፅል የሆነ ቃል በቃል እንደ `1.0f32` ይፈጥራል።
    /// ይህ token ሁልጊዜ አጠናቃሪ ውስጥ አንድ `f32` ለመሆን አያመለክትም ይደረጋል.
    /// ከአሉታዊ ቁጥሮች የተፈጠሩ ስነ-ፅሁፎች በ‹XXXXXX›ወይም በ‹XXXXX›ወይም በ‹XXXX›ሕብረቁምፊዎች በኩል በሕይወት አይቆዩም እና በሁለት tokens (`-` እና አዎንታዊ ቃል በቃል) ይከፈላሉ ፡፡
    ///
    ///
    /// # Panics
    ///
    /// ይህ ተግባር የተጠቀሰው ተንሳፋፊ ውስን መሆን ይጠይቃል ፣ ለምሳሌ ማለቂያ የሌለው ከሆነ ወይም ናን ይህ ተግባር panic ን ያደርገዋል።
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_suffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f32(&n.to_string()))
    }

    /// አዲስ ያልተሞላ ተንሳፋፊ-ነጥብ ቃል በቃል ይፈጥራል።
    ///
    /// ይህም በኋላ አጠናቃሪ ውስጥ `f64` መሆን አያመለክትም ይችላል, ስለዚህ ይህ ግንበኛ, የ እንዲንሳፈፍ ያለው ዋጋ token በቀጥታ ወደ ከመነጋገሩ ነው ነገር ግን ምንም ቅጥያ ጥቅም ላይ የት `Literal::i8_unsuffixed` እንደ ሰዎች ጋር ተመሳሳይ ነው.
    ///
    /// ከአሉታዊ ቁጥሮች የተፈጠሩ ስነ-ፅሁፎች በ‹XXXXXX›ወይም በ‹XXXXX›ወይም በ‹XXXX›ሕብረቁምፊዎች በኩል በሕይወት አይቆዩም እና በሁለት tokens (`-` እና አዎንታዊ ቃል በቃል) ይከፈላሉ ፡፡
    ///
    /// # Panics
    ///
    /// ይህ ተግባር የተጠቀሰው ተንሳፋፊ ውስን መሆን ይጠይቃል ፣ ለምሳሌ ማለቂያ የሌለው ከሆነ ወይም ናን ይህ ተግባር panic ን ያደርገዋል።
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_unsuffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// አዲስ ድሕረ ቅጥያ ተንሳፋፊ-ነጥብ በቃል ይፈጥራል.
    ///
    /// በተጠቀሰው ዋጋ token መካከል ባለው አካል ነው `f64` ወደ token ያለውን ቅጥያ ነው የት ይህ ግንበኛ `1.0f64` እንደ በቃል ይፈጥራል.
    /// ይህ token ሁልጊዜ አጠናቃሪ ውስጥ አንድ `f64` ለመሆን አያመለክትም ይደረጋል.
    /// ከአሉታዊ ቁጥሮች የተፈጠሩ ስነ-ፅሁፎች በ‹XXXXXX›ወይም በ‹XXXXX›ወይም በ‹XXXX›ሕብረቁምፊዎች በኩል በሕይወት አይቆዩም እና በሁለት tokens (`-` እና አዎንታዊ ቃል በቃል) ይከፈላሉ ፡፡
    ///
    ///
    /// # Panics
    ///
    /// ይህ ተግባር የተጠቀሰው ተንሳፋፊ ውስን መሆን ይጠይቃል ፣ ለምሳሌ ማለቂያ የሌለው ከሆነ ወይም ናን ይህ ተግባር panic ን ያደርገዋል።
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_suffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f64(&n.to_string()))
    }

    /// ሕብረቁምፊ ቃል በቃል።
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn string(string: &str) -> Literal {
        Literal(bridge::client::Literal::string(string))
    }

    /// ካራክተር በቃል.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn character(ch: char) -> Literal {
        Literal(bridge::client::Literal::character(ch))
    }

    /// ባይት ሕብረቁምፊ ቃል በቃል።
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn byte_string(bytes: &[u8]) -> Literal {
        Literal(bridge::client::Literal::byte_string(bytes))
    }

    /// ይህ ቃል በቃል ያካትት ስንዝር ያወጣል.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// ለዚህ ቃል በቃል የተዛመደውን ስፋትን ያዋቅራል።
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }

    /// ብቻ ምንጭ የያዘ `self.span()` ስብስብ የሆነ ክልል `range` ውስጥ ባይቶች የሆነ `Span` ያወጣል.
    /// የ እንቢ-ሊሆን ሊቆረጥ ስንዝር `self` ላይ ገደቦች ውጭ ከሆነ `None` ይመልሳል.
    ///
    // FIXME(SergioBenitez): ወደ ባይት ክልል ምንጭ የሆነ UTF-8 ወሰን ላይ ይጀምራል እና ጫፎች መሆኑን ያረጋግጡ.
    // አለበለዚያ የምንጭ ጽሑፍ በሚታተምበት ጊዜ panic በሌላ ቦታ ሊከሰት ይችላል ፡፡
    // FIXME(SergioBenitez): ተጠቃሚው ይህን ዘዴ በአሁኑ ጊዜ ብቻ በጭፍን ተብሎ ሊሆን ይችላል, ስለዚህ `self.span()` እንዲያውም, ወደ Maps ምን ማወቅ ምንም መንገድ የለም.
    // ለምሳሌ ያህል, `to_string()` ገጸ ለ 'c' "'\u{63}'" ይመልሳል;ተጠቃሚው ምንጭ ጽሑፍ 'c' እንደሆነ ማወቅ ወይም '\u{63}' ነበር አለመሆኑን ምንም መንገድ የለም.
    //
    //
    //
    //
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn subspan<R: RangeBounds<usize>>(&self, range: R) -> Option<Span> {
        // HACK(eddyb) `Option::cloned` ከርኅራኄ ነገር ግን `Bound<&T>` ለ.
        fn cloned_bound<T: Clone>(bound: Bound<&T>) -> Bound<T> {
            match bound {
                Bound::Included(x) => Bound::Included(x.clone()),
                Bound::Excluded(x) => Bound::Excluded(x.clone()),
                Bound::Unbounded => Bound::Unbounded,
            }
        }

        self.0.subspan(cloned_bound(range.start_bound()), cloned_bound(range.end_bound())).map(Span)
    }
}

// ኤን.ቢ ፣ ድልድዩ `to_string` ን ብቻ ይሰጣል ፣ በእሱ ላይ የተመሠረተ `fmt::Display` ን ይተግብሩ (በሁለቱ መካከል ያለው የተለመደ ግንኙነት በተቃራኒው) ፡፡
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Literal {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// ህትመቶች (ነጥብ literals ተንሳፋፊ ለ በተቻለ አቆጣጠሩ በስተቀር) ተመሳሳይ ቃል በቃል ወደ losslessly የሚመነዘር ወደ ኋላ መሆን እንዳለበት እንደ ሕብረቁምፊ ቃል በቃል.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// የአከባቢ ተለዋዋጭዎችን ተከታትሏል ፡፡
#[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
pub mod tracked_env {
    use std::env::{self, VarError};
    use std::ffi::OsStr;

    /// አካባቢ ተለዋዋጭ ሰርስረው እና ጥገኝነት መረጃ ለመገንባት ለማከል.
    /// የ አጠናቃሪ ከመፈጸሙ በግንባታ ስርዓት ተለዋዋጭ ማጠናቀር ጊዜ የተደረሰበት ታውቃላችሁ, እና ይህ ተለዋዋጭ ዋጋ ሲቀየር ወደ ግንባታ ፍተሻዎችን ይችላሉ.
    ///
    /// ክርክሩ UTF-8 መሆን አለበት ካልሆነ በስተቀር ከጥገኝነት መከታተል በተጨማሪ ይህ ተግባር ከመደበኛ ቤተ-መጽሐፍት `env::var` ጋር እኩል መሆን አለበት።
    ///
    #[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
    pub fn var<K: AsRef<OsStr> + AsRef<str>>(key: K) -> Result<String, VarError> {
        let key: &str = key.as_ref();
        let value = env::var(key);
        crate::bridge::client::FreeFunctions::track_env_var(key, value.as_deref().ok());
        value
    }
}