# የ `rustc-std-workspace-core` crate

ይህ crate በቀላሉ በ `libcore` ላይ የሚመረኮዝ እና ሁሉንም ይዘቶቹን እንደገና የሚያስተላልፍ ሻማ እና ባዶ crate ነው።
የ crate crates.io ከ crates ላይ የተመካ ወደ መደበኛ ቤተ መጻሕፍት የማብቃት ያለውን ክሩክስ ነው

crates.io ላይ Crates መደበኛ ቤተ-መጽሐፍት ባዶ ነው crates.io ጀምሮ `rustc-std-workspace-core` crate ላይ የተመካ ለማድረግ ፍላጎት ላይ የተመሰረተ ነው.

በዚህ ማከማቻ ውስጥ ይህንን crate ወደ ሊሽረው `[patch]` ይጠቀማሉ.
በዚህም ምክንያት, crates.io ላይ crates `libcore` አንድ ጥገኝነት edge, በዚህ ማከማቻ ውስጥ በተገለጸው ስሪት ይቀርባል.
ይህ Cargo crates በተሳካ ይገነባል ለማረጋገጥ ሁሉም ጥገኝነት ጠርዞች መቅረብ አለባቸው!

crates.io ላይ crates በትክክል ሥራ ላይ ሁሉም ነገር ስም `core` ጋር በዚህ crate ላይ መተማመን ይኖርብናል መሆኑን ልብ በል.እነሱ መጠቀም እንደሚችሉ ለማድረግ:

```toml
core = { version = "1.0.0", optional = true, package = 'rustc-std-workspace-core' }
```

የ `package` ቁልፍ አጠቃቀም በኩል crate እንደሚመስል ትርጉም, `core` ተሰይሟል ነው

```
--extern core=.../librustc_std_workspace_core-XXXXXXX.rlib
```

Cargo ወደ አጠናቃሪ invokes ጊዜ ስውር `extern crate core` መመሪያ አርኪ ወደ አጠናቃሪ አጠገብ በክትባቶች.




