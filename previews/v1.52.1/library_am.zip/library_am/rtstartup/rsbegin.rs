// rsbegin.o እና rsend.o የ እንዲህ ተብሎ "compiler runtime startup objects" ናቸው.
// የአቀራባዩን ጊዜ በትክክል ለማስጀመር የሚያስፈልገውን ኮድ ይይዛሉ ፡፡
//
// ተከናዋኝ ወይም dylib ምስል የተገናኘ ጊዜ rsend.o ከ ኮድ እና ውሂብ የመጨረሻ ሰዎች እንዲሆኑ በአንጻሩ rsbegin.o ከ ኮድ ወይም ውሂብ, በመጀመሪያ ምስል በሚመለከታቸው ክፍሎች ላይ እንዲሆኑ ስለዚህ, ሁሉም የተጠቃሚ ኮድ እና ቤተ እነዚህ ሁለት የነገር ፋይሎች መካከል "sandwiched" ናቸው.
// ይህ ውጤት ምልክቶችን በአንድ ክፍል መጀመሪያ ወይም መጨረሻ ላይ ለማስቀመጥ እንዲሁም ማንኛውንም የሚያስፈልጉ ራስጌዎችን ወይም ግርጌዎችን ለማስገባት ሊያገለግል ይችላል ፡፡
//
// ትክክለኛ ሞዱል መግቢያ ነጥብ ከዚያም (ገና ሌላ ልዩ ምስል ክፍል በኩል የተመዘገበ) ሌሎች የሚፈጀውን ክፍሎች ማስጀመር callbacks invokes ይህም (አብዛኛውን ጊዜ `crtX.o` ይባላል) ወደ ሐ የሚፈጀውን በጅምር ነገር, ውስጥ የሚገኝ መሆኑን ልብ በል.
//
//
//
//
//
//

#![feature(no_core)]
#![feature(lang_items)]
#![feature(auto_traits)]
#![crate_type = "rlib"]
#![no_core]
#![allow(non_camel_case_types)]

#[lang = "sized"]
trait Sized {}
#[lang = "sync"]
auto trait Sync {}
#[lang = "copy"]
trait Copy {}
#[lang = "freeze"]
auto trait Freeze {}

#[lang = "drop_in_place"]
#[inline]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    drop_in_place(to_drop);
}

#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frames {
    #[no_mangle]
    #[link_section = ".eh_frame"]
    // የቁልል ፍሬም መጀመርያ ምልክቶች መዘርጋት የመረጃ ክፍልን
    pub static __EH_FRAME_BEGIN__: [u8; 0] = [];

    // ላልተነጠፈ የውስጥ መፅሃፍ ማቆያ ቦታ መቧጨር ፡፡
    // ይህ $ GCC/libgcc/የምናወራበት-dw2-fde.h ውስጥ `struct object` ተብሎ ይገለጻል.
    static mut OBJ: [isize; 6] = [0; 6];

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                impl ::Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    // ከለመድነው መረጃ registration/deregistration እለታዊ.
    // libpanic_unwind ያለውን ሰነዶች ይመልከቱ.
    extern "C" {
        fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8);
        fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8);
    }

    unsafe extern "C" fn init() {
        // ሞጁል ጅምር ላይ ከለመድነው መረጃ ይመዘግባል
        rust_eh_register_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    unsafe extern "C" fn uninit() {
        // ሲዘጋ UNREGISTER
        rust_eh_unregister_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    // MinGW-ተኮር init/uninit ተዕለት ምዝገባ
    pub mod mingw_init {
        // የሚንGW ጅምር ዕቃዎች (crt0.o/dllcrt0.o) ጅምር እና መውጫ ላይ በ .ctors እና .dtors ክፍሎች ውስጥ ዓለም አቀፍ ገንቢዎችን ይጠራሉ ፡፡
        // የ DLL ሊጫን እና አውርደን ጊዜ DLLs ሁኔታ ውስጥ, ይህን እንዳደረገ ነው.
        //
        // የ linker የእኛ callbacks ዝርዝር መጨረሻ ላይ የሚገኙት መሆኑን ያረጋግጣል ያለውን ክፍሎች, ይከታቸዋል.
        // constructors በግልባጭ ቅደም ተከተል ላይ የሚሄዱ ናቸው በመሆኑ, ይህንን ያረጋግጣል የእኛ callbacks ከተገደለ የመጀመሪያ እና የመጨረሻዎቹ ሰዎች ናቸው.
        //
        //

        #[link_section = ".ctors.65535"] // .ctors *: . ሲ መነሳት callbacks
        pub static P_INIT: unsafe extern "C" fn() = super::init;

        #[link_section = ".dtors.65535"] // .dtors *: . ሲ መቋረጥ callbacks
        pub static P_UNINIT: unsafe extern "C" fn() = super::uninit;
    }
}