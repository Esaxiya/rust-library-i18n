//! ሂደት ቢያስወርዱ በኩል Rust panics ትግበራ
//!
//! የመተርተሩ በኩል ወደ አፈፃፀም ጋር ሲነፃፀር ጊዜ, ይህ crate *ብዙ* ቀላል ነው!ፍጡር አለ, ይሄድና እዚህ ላይ በጣም እንደ ሁለገብ አይደለም, ነገር ግን!
//!

#![no_std]
#![unstable(feature = "panic_abort", issue = "32837")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/"
)]
#![panic_runtime]
#![allow(unused_features)]
#![feature(core_intrinsics)]
#![feature(nll)]
#![feature(panic_runtime)]
#![feature(std_internals)]
#![feature(staged_api)]
#![feature(rustc_attrs)]
#![feature(asm)]

use core::any::Any;
use core::panic::BoxMeUp;

#[rustc_std_internal_symbol]
#[allow(improper_ctypes_definitions)]
pub unsafe extern "C" fn __rust_panic_cleanup(_: *mut u8) -> *mut (dyn Any + Send + 'static) {
    unreachable!()
}

// "Leak" በጥያቄ ውስጥ ያለው መድረክ ላይ አግባብ አጨንግፍ ወደ የክፍያ እና ሺም.
#[rustc_std_internal_symbol]
pub unsafe extern "C" fn __rust_start_panic(_payload: *mut &mut dyn BoxMeUp) -> u32 {
    abort();

    cfg_if::cfg_if! {
        if #[cfg(unix)] {
            unsafe fn abort() -> ! {
                libc::abort();
            }
        } else if #[cfg(any(target_os = "hermit",
                            all(target_vendor = "fortanix", target_env = "sgx")
        ))] {
            unsafe fn abort() -> ! {
                // ጥሪ std::sys::abort_internal
                extern "C" {
                    pub fn __rust_abort() -> !;
                }
                __rust_abort();
            }
        } else if #[cfg(all(windows, not(miri)))] {
            // Windows ላይ, ስልት __fastfail ያለውን አንጎለ-ተኮር ይጠቀማሉ.በ Windows 8 እና ከዚያ በኋላ ይህ በሂደት ላይ ያሉ ልዩ ተቆጣጣሪዎችን ሳያካሂድ ወዲያውኑ ሂደቱን ያቋርጣል።
            // Windows ቀደም ስሪቶች ውስጥ, መመሪያዎችን ይህ ቅደም ተከተል ሂደት ማቋረጥ ግን የግድ ሁሉንም በስተቀር ተቆጣጣሪዎች ለማለፍ ያለ አንድ መዳረሻ ጥሰት ተደርገው ይወሰዳሉ.
            //
            //
            // https://docs.microsoft.com/en-us/cpp/intrinsics/fastfail
            //
            // Note: ይህ libstd ዎቹ `abort_internal` ውስጥ ተመሳሳይ ትግበራ ነው
            //
            //
            //
            unsafe fn abort() -> ! {
                const FAST_FAIL_FATAL_APP_EXIT: usize = 7;
                cfg_if::cfg_if! {
                    if #[cfg(any(target_arch = "x86", target_arch = "x86_64"))] {
                        asm!("int $$0x29", in("ecx") FAST_FAIL_FATAL_APP_EXIT);
                    } else if #[cfg(all(target_arch = "arm", target_feature = "thumb-mode"))] {
                        asm!(".inst 0xDEFB", in("r0") FAST_FAIL_FATAL_APP_EXIT);
                    } else if #[cfg(target_arch = "aarch64")] {
                        asm!("brk 0xF003", in("x0") FAST_FAIL_FATAL_APP_EXIT);
                    } else {
                        core::intrinsics::abort();
                    }
                }
                core::intrinsics::unreachable();
            }
        } else {
            unsafe fn abort() -> ! {
                core::intrinsics::abort();
            }
        }
    }
}

// ይህ ... አንድ ሚስጥራዊ የሆነ ትንሽ ነው.የ tl; dr;በትክክል ለማገናኘት ይህ ያስፈልጋል ፣ ረዘም ያለ ማብራሪያ ከዚህ በታች ነው።
//
// አሁን የምንጭነው የ libcore/libstd ሁለትዮሽ ሁሉም በ `-C panic=unwind` ተሰብስቧል ፡፡ይህ በሁለትዮሾችዎ በተቻለ መጠን ብዙ ሁኔታዎች እንደ ጋር ቢበዛ ቢበዛ ተኳሃኝ መሆናቸውን ለማረጋገጥ ነው.
// የ አጠናቃሪ, ይሁን እንጂ, `-C panic=unwind` ጋር የተጠናቀሩ ሁሉም ተግባራት የሚሆን "personality function" ይጠይቃል.ይህ ስብዕና ተግባር ምልክት `rust_eh_personality` ወደ hardcoded ነው እና `eh_personality` lang ንጥል በ የተገለጸ ነው.
//
// So...
// ለምን እዚህ ብቻ መሆኑን lang ንጥል ለመግለጽ አይደለም?ጥሩ ጥያቄ!panic runtimes ውስጥ የተገናኙ መንገድ በተጨባጭ ጥቂት እነርሱ አጠናቃሪ ዎቹ crate መደብር ውስጥ "sort of" ነዎት ውስጥ ስውር, ነገር ግን ሌላ በእርግጥ አልተገናኘም ከሆነ ብቻ በትክክል የተገናኘ ነው.
//
// ይህ ማለት ይህ crate እና panic_unwind crate በአቀራባሪው የ crate መደብር ውስጥ ሊታዩ ይችላሉ ማለት ነው ፣ እና ሁለቱም የ‹`eh_personality` X›ንጥል ንጥል ቢገልጹ ከዚያ ያ ስህተት ያስከትላል ፡፡
//
// ይህንን ለማስተናገድ አዘጋጁ `eh_personality` ን ብቻ ይፈልጋል የሚገለፀው የ panic የስራ ጊዜው የሚለቀቅበት ጊዜ ከሆነ እና ካልሆነም እንዲገለፅ አይጠየቅም (በትክክል) ፡፡
// በዚህ አጋጣሚ ግን ይህ ቤተ-መጽሐፍት ይህንን ምልክት ብቻ ይገልጻል ስለሆነም ቢያንስ አንድ ቦታ አንድ ሰው አለ ፡፡
//
// በመሠረቱ ይህ ምልክት ብቻ libcore/libstd በሁለትዮሾችዎ እስከ ባለገመድ ለማግኘት ፍቺ ነው, ነገር ግን እኛ በሁሉም ላይ አንድ የመተርተሩ የሚፈጀውን ጊዜ ውስጥ ማገናኘት እንጂ እንደ ተብሎ ፈጽሞ አይገባም.
//
//
//
//
//
//
//
//
//
//
//
//
pub mod personalities {
    #[rustc_std_internal_symbol]
    #[cfg(not(any(
        all(target_arch = "wasm32", not(target_os = "emscripten"),),
        all(target_os = "windows", target_env = "gnu", target_arch = "x86_64",),
    )))]
    pub extern "C" fn rust_eh_personality() {}

    // x86_64-PC-መስኮቶችን-gnu ላይ እኛ ሁላችንም ያለንን ፍሬሞች ላይ ሲያልፍ ነን እንደ ፍላጎቶች `ExceptionContinueSearch` መመለስ መሆኑን የራሳችንን ባሕርያት ተግባር ይጠቀሙ.
    //
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86_64"))]
    pub extern "C" fn rust_eh_personality(
        _record: usize,
        _frame: usize,
        _context: usize,
        _dispatcher: usize,
    ) -> u32 {
        1 // `ExceptionContinueSearch`
    }

    // ከላይ ካለው ጋር ተመሳሳይ ፣ ይህ በአሁኑ ጊዜ በኤምስክሪፕት ላይ ብቻ ከሚሰራው የ `eh_catch_typeinfo` ላንግ ንጥል ጋር ይዛመዳል።
    //
    // panics ማመንጨት አይደለም በመሆኑ የማይካተቱ እና የውጭ የማይካተቱ በአሁኑ ናቸው ub ጋር -C panic=አጨንግፍ (ይህ ለውጥ ተገዢ ሊሆን ይችላል ቢሆንም), ማንኛውም catch_unwind ጥሪዎች ይህን typeinfo አይጠቀምበትም.
    //
    //
    //
    #[rustc_std_internal_symbol]
    #[allow(non_upper_case_globals)]
    #[cfg(target_os = "emscripten")]
    static rust_eh_catch_typeinfo: [usize; 2] = [0; 2];

    // እነዚህ ሁለት i686-PC-መስኮቶች-gnu ላይ በሚነሳበት ነገሮች የተጠሩ ናቸው, ነገር ግን እነርሱ አካላት nops ናቸው, ስለዚህ ምንም ነገር ማድረግ አያስፈልግዎትም.
    //
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86"))]
    pub extern "C" fn rust_eh_register_frames() {}
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86"))]
    pub extern "C" fn rust_eh_unregister_frames() {}
}