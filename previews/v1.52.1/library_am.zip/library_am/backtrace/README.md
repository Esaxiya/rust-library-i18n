# backtrace-rs

[Documentation](https://docs.rs/backtrace)

ለ Rust በሚሰራበት ሰዓት የጀርባ ትራክቶችን ለማግኘት ቤተ-መጽሐፍት።
ይህ ቤተመፃህፍት አብሮ ለመስራት የሚያስችል የፕሮግራም በይነገጽ በማቅረብ የመደበኛ ቤተመፃህፍት ድጋፍን ለማሳደግ ያለመ ሲሆን እንደ ሊስትስትድ panics ያሉ የአሁኑን ጀርባዎችን በቀላሉ ለማተምም ይደግፋል ፡፡

## Install

```toml
[dependencies]
backtrace = "0.3"
```

## Usage

የኋላ ታሪክን ለመያዝ እና ከእሱ ጋር የሚደረገውን ግንኙነት ለሌላ ጊዜ ለማስተላለፍ ፣ የከፍተኛ ደረጃ `Backtrace` ዓይነትን መጠቀም ይችላሉ።

```rust
use backtrace::Backtrace;

fn main() {
    let bt = Backtrace::new();

    // do_some_work();

    println!("{:?}", bt);
}
```

ሆኖም ግን ለእውነተኛው ዱካ ፍለጋ የበለጠ ጥሬ መዳረሻ ማግኘት ከፈለጉ የ `trace` እና `resolve` ተግባሮችን በቀጥታ መጠቀም ይችላሉ።

```rust
fn main() {
    backtrace::trace(|frame| {
        let ip = frame.ip();
        let symbol_address = frame.symbol_address();

        // ይህንን መመሪያ ጠቋሚ ወደ ምልክት ስም ይፍቱ
        backtrace::resolve_frame(frame, |symbol| {
            if let Some(name) = symbol.name() {
                // ...
            }
            if let Some(filename) = symbol.filename() {
                // ...
            }
        });

        true // ወደ ቀጣዩ ክፈፍ መሄድዎን ይቀጥሉ
    });
}
```

# License

ይህ ፕሮጀክት በሁለቱም በኩል ፈቃድ ተሰጥቷል

 * Apache ፈቃድ ፣ ሥሪት 2.0 ፣ ([LICENSE-APACHE](LICENSE-APACHE) ወይም http://www.apache.org/licenses/LICENSE-2.0)
 * MIT ፈቃድ ([LICENSE-MIT](LICENSE-MIT) ወይም http://opensource.org/licenses/MIT)

በአማራጭዎ ፡፡

### Contribution

በግልፅ ካልገለጹ በስተቀር ፣ በ Apache-2.0 ፈቃድ ውስጥ በተገለጸው መሠረት በእራስዎ በ backtrace-rs ውስጥ እንዲካተት ሆን ተብሎ የሚቀርብ ማንኛውም መዋጮ ከዚህ በላይ ምንም ተጨማሪ ውሎች ወይም ሁኔታዎች ሳይኖር ከላይ እንደ ሁለት ፈቃድ ሊኖረው ይገባል።







