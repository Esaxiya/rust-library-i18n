#[cfg(feature = "std")]
use super::{BacktraceFrame, BacktraceSymbol};
use super::{BytesOrWideString, Frame, SymbolName};
use core::ffi::c_void;
use core::fmt;

const HEX_WIDTH: usize = 2 + 2 * core::mem::size_of::<usize>();

#[cfg(target_os = "fuchsia")]
mod fuchsia;

/// ለኋላ ማሳያዎች ቅርጸት።
///
/// ይህ አይነት ምንም backtrace በራሱ የሚመጣው ከየት አንድ backtrace ማተም ጥቅም ላይ ሊውል ይችላል.
/// የ `Backtrace` ዓይነት ካለዎት የእሱ `Debug` አተገባበር አስቀድሞ ይህንን የህትመት ቅርጸት ይጠቀማል።
///
pub struct BacktraceFmt<'a, 'b> {
    fmt: &'a mut fmt::Formatter<'b>,
    frame_index: usize,
    format: PrintFmt,
    print_path:
        &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result + 'b),
}

/// እኛ ማተም ይችላሉ ማተሚያ ያለው ቅጦች
#[derive(Copy, Clone, Eq, PartialEq)]
pub enum PrintFmt {
    /// በሐሳብ ደረጃ ብቻ ተገቢ የሆኑ መረጃዎችን የያዘ አንድ terser backtrace አሻራ
    Short,
    /// ሁሉም በተቻለ መረጃ የያዘ backtrace አሻራ
    Full,
    #[doc(hidden)]
    __Nonexhaustive,
}

impl<'a, 'b> BacktraceFmt<'a, 'b> {
    /// የቀረበው `fmt` ውጽዓት መጻፍ ይህም አዲስ `BacktraceFmt` ፍጠር.
    ///
    /// የ `format` ሙግት backtrace ታትሟል ውስጥ ያለውን ቅጥ መቆጣጠር, እና `print_path` ክርክር የፋይል ስሞች መካከል `BytesOrWideString` አብነቶችን ማተም ጥቅም ላይ ይውላል.
    /// ይህ አይነት ራሱ የፋይል ማንኛውም ማተም ለማድረግ አይደለም, ነገር ግን ይህ ተዘዋዋሪ እንዲህ ማድረግ ያስፈልጋል.
    ///
    ///
    ///
    pub fn new(
        fmt: &'a mut fmt::Formatter<'b>,
        format: PrintFmt,
        print_path: &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result
                     + 'b),
    ) -> Self {
        BacktraceFmt {
            fmt,
            frame_index: 0,
            format,
            print_path,
        }
    }

    /// ስለሚታተመው የኋላ ታሪክ መግቢያ ያትማል ፡፡
    ///
    /// የኋላ ኋላ ሙሉ ለሙሉ ተምሳሌት ሆኖ እንዲታይ ለማድረግ በአንዳንድ መድረኮች ላይ ይህ ያስፈልጋል ፣ እና አለበለዚያ `BacktraceFmt` ን ከፈጠሩ በኋላ ይህ የሚደውሉት የመጀመሪያ ዘዴ ብቻ መሆን አለበት።
    ///
    ///
    pub fn add_context(&mut self) -> fmt::Result {
        #[cfg(target_os = "fuchsia")]
        fuchsia::print_dso_context(self.fmt)?;
        Ok(())
    }

    /// ወደ backtrace ውፅዓት አንድ ፍሬም ያክላል.
    ///
    /// ይህ ይመለሳል በእርግጥ አንድ ፍሬም ማተም ላይ ሊውል የሚችል አንድ `BacktraceFrameFmt` አንድ RAII ለምሳሌ አደራ, እና ጥፋት ላይ ክፈፍ ቆጣሪ አልጨመረም ይሆናል.
    ///
    ///
    pub fn frame(&mut self) -> BacktraceFrameFmt<'_, 'a, 'b> {
        BacktraceFrameFmt {
            fmt: self,
            symbol_index: 0,
        }
    }

    /// የ backtrace ውፅዓት ያጠናቅቃል.
    ///
    /// ይህ በአሁኑ ጊዜ ምርጫ-አልባ ነገር ግን ለ future ተኳኋኝነት ከበስተጀርባ ቅርፀቶች ጋር ታክሏል።
    ///
    pub fn finish(&mut self) -> fmt::Result {
        // የ future ጭማሪዎችን ለመፍቀድ በአሁኑ ጊዜ ያለ ምርጫ-ይህንን hook ን ጨምሮ ፡፡
        Ok(())
    }
}

/// አንድ የኋላ ታሪክ አንድ ክፈፍ ብቻ ቅርጸት።
///
/// ይህ አይነት በ `BacktraceFmt::frame` ተግባር የተፈጠረ ነው።
pub struct BacktraceFrameFmt<'fmt, 'a, 'b> {
    fmt: &'fmt mut BacktraceFmt<'a, 'b>,
    symbol_index: usize,
}

impl BacktraceFrameFmt<'_, '_, '_> {
    /// አንድ `BacktraceFrame` ይህ ፍሬም formatter ጋር አሻራ.
    ///
    /// ይህ recursively የ `BacktraceFrame` ውስጥ ሁሉ `BacktraceSymbol` አጋጣሚዎች ማተም ይሆናል.
    ///
    /// # አስፈላጊ ባህሪዎች
    ///
    /// ይህ ተግባር የ `backtrace` crate የ `std` ባህሪው እንዲነቃ ይፈልጋል ፣ እና የ `std` ባህሪው በነባሪነት ነቅቷል።
    ///
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_frame(&mut self, frame: &BacktraceFrame) -> fmt::Result {
        let symbols = frame.symbols();
        for symbol in symbols {
            self.backtrace_symbol(frame, symbol)?;
        }
        if symbols.is_empty() {
            self.print_raw(frame.ip(), None, None, None)?;
        }
        Ok(())
    }

    /// በ `BacktraceFrame` ውስጥ `BacktraceSymbol` ን ያትማል።
    ///
    /// # አስፈላጊ ባህሪዎች
    ///
    /// ይህ ተግባር የ `backtrace` crate የ `std` ባህሪው እንዲነቃ ይፈልጋል ፣ እና የ `std` ባህሪው በነባሪነት ነቅቷል።
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_symbol(
        &mut self,
        frame: &BacktraceFrame,
        symbol: &BacktraceSymbol,
    ) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            // TODO: ይህ እኛ ማንኛውንም ነገር ማተም እስከ መጨረሻ አይደለም አይደለም ታላቅ ነው
            // utf8 ባልሆኑ የፋይል ስሞች።
            // ደስ የሚለው ነገር ሁሉም ነገር ማለት ይቻላል utf8 ነው ስለሆነም ይህ በጣም መጥፎ መሆን የለበትም።
            symbol
                .filename()
                .and_then(|p| Some(BytesOrWideString::Bytes(p.to_str()?.as_bytes()))),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// የህትመት ጥሬ በተለምዶ ይህ crate ያለውን ጥሬ callbacks ውስጥ ሆነው, `Frame` እና `Symbol` ከመሠረቱ.
    ///
    pub fn symbol(&mut self, frame: &Frame, symbol: &super::Symbol) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            symbol.filename_raw(),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// ወደኋላ አፈፃፀም ጥሬ ፍሬም ያክላል።
    ///
    /// ይህ ዘዴ ከቀዳሚው በተለየ መልኩ ጥሬ ክርክሮችን ከተለያዩ አካባቢዎች የሚመጡ ቢሆኑም ይወስዳል ፡፡
    /// ይህ አንድ ክፈፍ በርካታ ጊዜያት ተብሎ ሊሆን እንደሚችል ልብ ይበሉ.
    ///
    pub fn print_raw(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
    ) -> fmt::Result {
        self.print_raw_with_column(frame_ip, symbol_name, filename, lineno, None)
    }

    /// የዓምድ መረጃን ጨምሮ ወደኋላ አፈፃፀም ጥሬ ክፈፍ ያክላል።
    ///
    /// ይህ ዘዴ እንደ ቀደመው ሁሉ ጥሬ ክርክሮችን ከተለያዩ አካባቢዎች የሚመጡ ቢሆኑም ይወስዳል ፡፡
    /// ይህ አንድ ክፈፍ በርካታ ጊዜያት ተብሎ ሊሆን እንደሚችል ልብ ይበሉ.
    ///
    pub fn print_raw_with_column(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // ፉሺያ በሂደት ውስጥ ምስልን ማመልከት አልቻለችም ስለሆነም በኋላ ላይ ለማመልከት ሊያገለግል የሚችል ልዩ ቅርጸት አለው ፡፡
        // አድራሻዎችን በራሳችን ቅርጸት ከማተም ይልቅ ያንን እዚህ ያትሙ።
        //
        if cfg!(target_os = "fuchsia") {
            self.print_raw_fuchsia(frame_ip)?;
        } else {
            self.print_raw_generic(frame_ip, symbol_name, filename, lineno, colno)?;
        }
        self.symbol_index += 1;
        Ok(())
    }

    #[allow(unused_mut)]
    fn print_raw_generic(
        &mut self,
        mut frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // "null" ፍሬሞችን ለማተም አያስፈልግም, ይህ በመሠረቱ ብቻ ሥርዓት backtrace ኋላ እጅግ በጣም ሩቅ ማየት ብንችል ትንሽ ጓጉቶ ነበር ማለት ነው.
        //
        if let PrintFmt::Short = self.fmt.format {
            if frame_ip.is_null() {
                return Ok(());
            }
        }

        // በ Sgx enclave ውስጥ የ TCB መጠንን ለመቀነስ የምልክት ጥራት ተግባራዊነትን ተግባራዊ ማድረግ አንፈልግም።
        // ከዚህ ይልቅ, እኛ ወደ በኋላ ላይ ትክክለኛ ተግባር ጋር ማፕ መደረግ የሚችል እዚህ አድራሻ, ስለ የሚካካስበት ማተም ይችላሉ.
        //
        #[cfg(all(feature = "std", target_env = "sgx", target_vendor = "fortanix"))]
        {
            let image_base = std::os::fortanix_sgx::mem::image_base();
            frame_ip = usize::wrapping_sub(frame_ip as usize, image_base as _) as _;
        }

        // የማእቀፉ ጠቋሚ እንዲሁም ፍሬም አማራጭ መመሪያ ጠቋሚ ያትሙ.
        // በዚህ ክፈፍ የመጀመሪያው ምልክት ባሻገር ከሆኑ ብቻ ተገቢ አርጌ ማተም ቢሆንም.
        //
        if self.symbol_index == 0 {
            write!(self.fmt.fmt, "{:4}: ", self.fmt.frame_index)?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$?} - ", frame_ip, HEX_WIDTH)?;
            }
        } else {
            write!(self.fmt.fmt, "      ")?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH + 3)?;
            }
        }

        // እኛ ሙሉ backtrace ከሆንክ ተጨማሪ መረጃ ለማግኘት ቅርጸት አማራጭ በመጠቀም ምልክት ስም ወጥቶ ቀጣይ እስከ ጻፍ.
        // እዚህ እኛ ደግሞ አንድ ስም የላቸውም ይህም ምልክቶች መያዝ
        //
        match (symbol_name, &self.fmt.format) {
            (Some(name), PrintFmt::Short) => write!(self.fmt.fmt, "{:#}", name)?,
            (Some(name), PrintFmt::Full) => write!(self.fmt.fmt, "{}", name)?,
            (None, _) | (_, PrintFmt::__Nonexhaustive) => write!(self.fmt.fmt, "<unknown>")?,
        }
        self.fmt.fmt.write_str("\n")?;

        // እና, እስከ ይቆያል የፈለጉት ሰው የሚገኙ ከሆነ filename/line ቁጥር አትመው.
        if let (Some(file), Some(line)) = (filename, lineno) {
            self.print_fileline(file, line, colno)?;
        }

        Ok(())
    }

    fn print_fileline(
        &mut self,
        file: BytesOrWideString<'_>,
        line: u32,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Filename/line በምልክቱ ስም ስር ባሉ መስመሮች ላይ ታትመዋል ፣ ስለሆነም እራሳችንን በቀኝ ለማስተካከል ለመለየት አንዳንድ ተገቢውን የነፃ ቦታ ያትሙ።
        //
        if let PrintFmt::Full = self.fmt.format {
            write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH)?;
        }
        write!(self.fmt.fmt, "             at ")?;

        // የፋይል ስሙን ለማተም እና ከዚያ የመስመር ቁጥሩን ለማተም ወደ ውስጣዊ ጥሪችን ጥሪ ያድርጉ።
        //
        (self.fmt.print_path)(self.fmt.fmt, file)?;
        write!(self.fmt.fmt, ":{}", line)?;

        // ካለ የአምድ ቁጥር ያክሉ።
        if let Some(colno) = colno {
            write!(self.fmt.fmt, ":{}", colno)?;
        }

        write!(self.fmt.fmt, "\n")?;
        Ok(())
    }

    fn print_raw_fuchsia(&mut self, frame_ip: *mut c_void) -> fmt::Result {
        // እኛ ስለ ፍሬም የመጀመሪያ ምልክት ብቻ እንጨነቃለን
        if self.symbol_index == 0 {
            self.fmt.fmt.write_str("{{{bt:")?;
            write!(self.fmt.fmt, "{}:{:?}", self.fmt.frame_index, frame_ip)?;
            self.fmt.fmt.write_str("}}}\n")?;
        }
        Ok(())
    }
}

impl Drop for BacktraceFrameFmt<'_, '_, '_> {
    fn drop(&mut self) {
        self.fmt.frame_index += 1;
    }
}