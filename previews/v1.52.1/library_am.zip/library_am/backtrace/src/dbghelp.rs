//! በ Windows ላይ dbghelp ማሰሪያዎችን ለማስተዳደር የሚረዳ ሞዱል
//!
//! በ Windows (ቢያንስ ለኤም.ኤስ.ቪ.ኤስ.) የኋላ ማሳያዎች በአብዛኛው በ‹`dbghelp.dll`›እና በውስጣቸው ባሉት የተለያዩ ተግባራት አማካይነት የተጎለበቱ ናቸው ፡፡
//! እነዚህ ተግባራት በአሁኑ ጊዜ በቁጥር ከ `dbghelp.dll` ጋር ከመገናኘት ይልቅ *በተለዋጭ* ተጭነዋል።
//! ይህ በአሁኑ ጊዜ የሚከናወነው በመደበኛ ቤተመፃህፍት (እና እዚያ ውስጥ በንድፈ-ሀሳብ ነው) ፣ ነገር ግን የኋላ መሄጃዎች በተለምዶ አማራጭ እንደመሆናቸው መጠን የቤተ-መጻህፍት የማይለዋወጥ የዲኤልኤ ጥገኛዎችን ለመቀነስ ለማገዝ የሚደረግ ጥረት ነው።
//!
//! ይህ እንዳለ ሆኖ `dbghelp.dll` ሁልጊዜ ማለት ይቻላል በተሳካ ሁኔታ በ Windows ላይ ይጫናል።
//!
//! ማስታወሻ ይህ እኛ ሲሆኑ መጫን ጀምሮ ይህ ሁሉ ድጋፍ ልውጥውጥ እኛ በትክክል `winapi` ውስጥ ጥሬ ትርጓሜዎች መጠቀም አይችሉም, ነገር ግን ይልቁን እኛ ተግባር ጠቋሚ አይነቶች እራሳችንን እና አጠቃቀም መሆኑን ለመግለጽ ያስፈልገናል ቢሆንም.
//! እኛ ዊናፒን በማባዛት ንግድ ውስጥ በእውነት አንፈልግም ፣ ስለሆነም ሁሉም ማሰሪያዎች በዊናፒ ውስጥ ካሉ ጋር እንደሚዛመዱ እና ይህ ባህሪ በሲአይኤ ላይ እንደነቃ የሚያረጋግጥ የ Cargo ባህሪ `verify-winapi` አለን ፡፡
//!
//! በመጨረሻም ፣ እዚህ ለ `dbghelp.dll` ያለው ዲኤልኤል በጭራሽ እንዳልወረደ ያስተውሉ እና ያ በአሁኑ ጊዜ ሆን ተብሎ ነው ፡፡
//! አስተሳሰቡ በዓለም አቀፍ ደረጃ መሸጎጥ እና ውድ ኤክስኤክስክስን በማስወገድ ወደ ኤፒአይ ጥሪዎች መካከል ልንጠቀምበት እንችላለን የሚል ነው ፡፡
//! ይህ ለፈሳሽ መርማሪዎች ችግር ከሆነ ወይም እንደዚያ ያለ ነገር እዚያ ስንደርስ ድልድዩን ማቋረጥ እንችላለን ፡፡
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(non_snake_case)]

use super::windows::*;
use core::mem;
use core::ptr;

// በ `SymGetOptions` እና `SymSetOptions` ዙሪያ ይሰሩ በራሱ ዊናፒ ውስጥ አለመገኘት ፡፡
// እኛ winapi ላይ ድርብ-ለፊደል አይነቶች በሚሆኑበት ጊዜ አለበለዚያ ይህ ብቻ ጥቅም ላይ ውሏል.
//
#[cfg(feature = "verify-winapi")]
mod dbghelp {
    use crate::windows::*;
    pub use winapi::um::dbghelp::{
        StackWalk64, SymCleanup, SymFromAddrW, SymFunctionTableAccess64, SymGetLineFromAddrW64,
        SymGetModuleBase64, SymInitializeW,
    };

    extern "system" {
        // ገና winapi ውስጥ ፍቺ አይደለም
        pub fn SymGetOptions() -> u32;
        pub fn SymSetOptions(_: u32);

        // ይህ winapi ውስጥ ፍቺ, ነገር ግን ትክክል ነው ነው (FIXME winapi-rs#768)
        pub fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD,
        ) -> BOOL;

        // ገና winapi ውስጥ ፍቺ አይደለም
        pub fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW,
        ) -> BOOL;
        pub fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64,
        ) -> BOOL;
    }

    pub fn assert_equal_types<T>(a: T, _b: T) -> T {
        a
    }
}

// ይህ ማክሮ እኛ ልንጭናቸው የምንችላቸውን ሁሉንም የአሠራር አመልካቾች በውስጣቸው የያዘውን የ `Dbghelp` መዋቅርን ለመግለጽ ያገለግላል ፡፡
//
macro_rules! dbghelp {
    (extern "system" {
        $(fn $name:ident($($arg:ident: $argty:ty),*) -> $ret: ty;)*
    }) => (
        pub struct Dbghelp {
            /// የተጫነው ዲኤልኤል ለ `dbghelp.dll`
            dll: HMODULE,

            // እኛ መጠቀም እንችላለን እያንዳንዱ ተግባር በእያንዳንዱ ተግባር ጠቋሚ
            $($name: usize,)*
        }

        static mut DBGHELP: Dbghelp = Dbghelp {
            // በመጀመሪያ ዲኤልኤልን አልጫንም
            dll: 0 as *mut _,
            // ሁሉም ተግባራት ለማለት ዜሮ ከተዋቀረ ናቸው Initiall እነርሱ ዳይናሚክ መጫን ይኖርብናል.
            //
            $($name: 0,)*
        };

        // ለእያንዳንዱ ተግባር ዓይነት ምቾት ታይፔድ።
        $(pub type $name = unsafe extern "system" fn($($argty),*) -> $ret;)*

        impl Dbghelp {
            /// `dbghelp.dll` ን ለመክፈት ሙከራዎች።
            /// ከሰራ ስኬትን ይመልሳል ወይም `LoadLibraryW` ካልተሳካ ስህተት።
            ///
            /// ቤተ-መጽሐፍት ቀድሞውኑ ከተጫነ Panics
            fn ensure_open(&mut self) -> Result<(), ()> {
                if !self.dll.is_null() {
                    return Ok(())
                }
                let lib = b"dbghelp.dll\0";
                unsafe {
                    self.dll = LoadLibraryA(lib.as_ptr() as *const i8);
                    if self.dll.is_null() {
                        Err(())
                    }  else {
                        Ok(())
                    }
                }
            }

            // እኛ መጠቀም የሚፈልጉትን እያንዳንዱ ዘዴ ተግባር.
            // ሲጠራው የተሸጎጠውን ተግባር ጠቋሚ ያነባል ወይም ይጫነው እና የተጫነውን እሴት ይመልሳል።
            // ጭነቶች እንዲሳኩ ተረጋግጠዋል ፡፡
            $(pub fn $name(&mut self) -> Option<$name> {
                unsafe {
                    if self.$name == 0 {
                        let name = concat!(stringify!($name), "\0");
                        self.$name = self.symbol(name.as_bytes())?;
                    }
                    let ret = mem::transmute::<usize, $name>(self.$name);
                    #[cfg(feature = "verify-winapi")]
                    dbghelp::assert_equal_types(ret, dbghelp::$name);
                    Some(ret)
                }
            })*

            fn symbol(&self, symbol: &[u8]) -> Option<usize> {
                unsafe {
                    match GetProcAddress(self.dll, symbol.as_ptr() as *const _) as usize {
                        0 => None,
                        n => Some(n),
                    }
                }
            }
        }

        // የ dbghelp ተግባራትን ለማጣቀሻ የጽዳት ቁልፎችን ለመጠቀም የምቾት ተኪ ፡፡
        //
        #[allow(dead_code)]
        impl Init {
            $(pub fn $name(&self) -> $name {
                unsafe {
                    DBGHELP.$name().unwrap()
                }
            })*

            pub fn dbghelp(&self) -> *mut Dbghelp {
                unsafe {
                    &mut DBGHELP
                }
            }
        }
    )

}

const SYMOPT_DEFERRED_LOADS: DWORD = 0x00000004;

dbghelp! {
    extern "system" {
        fn SymGetOptions() -> DWORD;
        fn SymSetOptions(options: DWORD) -> ();
        fn SymInitializeW(
            handle: HANDLE,
            path: PCWSTR,
            invade: BOOL
        ) -> BOOL;
        fn SymCleanup(handle: HANDLE) -> BOOL;
        fn StackWalk64(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME64,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64
        ) -> BOOL;
        fn SymFunctionTableAccess64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> PVOID;
        fn SymGetModuleBase64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> DWORD64;
        fn SymFromAddrW(
            hProcess: HANDLE,
            Address: DWORD64,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromAddrW64(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
        fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD
        ) -> BOOL;
        fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
    }
}

pub struct Init {
    lock: HANDLE,
}

/// የ `dbghelp` ኤፒአይ ተግባሮችን ከዚህ crate ለመድረስ አስፈላጊ የሆኑትን ሁሉንም ድጋፎች ያስጀምሩ ፡፡
///
///
/// ይህንን ተግባር **አስተማማኝ** መሆኑን ልብ ይበሉ, ይህም በውስጣዊ የራሱ ማመሳሰልን አለው.
/// እንዲሁም ይህንን ተግባር ደጋግመው ደጋግመው ለመጥራት ደህንነቱ የተጠበቀ መሆኑን ልብ ይበሉ ፡፡
///
pub fn init() -> Result<Init, ()> {
    use core::sync::atomic::{AtomicUsize, Ordering::SeqCst};

    unsafe {
        // እኛ ምን ማድረግ ይኖርብናል የመጀመሪያው ነገር ይህን ተግባር ለማስመር ነው.ይህ ከሌሎች ክሮች ወይም በአንዱ ክር ውስጥ በተመሳሳይ ጊዜ ሊጠራ ይችላል ፡፡
        // ከዚያ የበለጠ አስቸጋሪ መሆኑን ልብ ይበሉ ፣ ምክንያቱም እዚህ የምንጠቀመው ፣ `dbghelp` ፣*እንዲሁም* በዚህ ሂደት ውስጥ ካሉ ሌሎች ሁሉም ደዋዮች ጋር ወደ `dbghelp` መመሳሰል አለበት ፡፡
        //
        // በተለምዶ በተመሳሳይ ሂደት ውስጥ ወደ `dbghelp` ብዙ ጥሪዎች የሉም እናም እኛ የምንደርስበት እኛ ብቻ ነን ብለን በደህና መገመት እንችላለን ፡፡
        // ሆኖም እኛ መጨነቅ ያለብን አንድ ተቀዳሚ ሌላ ተጠቃሚ አለ ፣ እሱ ራሱ አስቂኝ ነው ፣ ግን በመደበኛ ቤተ-መጽሐፍት ውስጥ።
        // የ Rust መደበኛ ቤተ-መጽሐፍት ለዳግም ድጋፍ ድጋፍ በዚህ crate ላይ የተመሠረተ ሲሆን ይህ crate ደግሞ በ crates.io ላይም ይገኛል።
        // መደበኛ ቤተ መጻሕፍት አንድ panic backtrace ማተም ከሆነ ይህ crate segfaults መንስኤ, crates.io እንደመጣ ጋር ይወዳደሩ ዘንድ ይህ ማለት.
        //
        // ይህንን የማመሳሰል ችግር ለመፍታት ለማገዝ እዚህ ጋር ዊንዶውስ-ተኮር ዘዴን እንቀጥራለን (ከሁሉም በኋላ ስለ ማመሳሰል የዊንዶውስ የተወሰነ ገደብ ነው) ፡፡
        // እኛ ይህን ጥሪ ለመጠበቅ *ክፍለ-አካባቢያዊ* የተባለ mutex መፍጠር.
        // እዚህ አስበን መደበኛ ቤተ መጻሕፍት ይህ crate እዚህ ለማመሳሰል Rust-ደረጃ አይዎች ማጋራት የለብዎትም ግን ይልቁንስ ከመድረክ በስተጀርባ ሥራ እርስ በርሳቸው ጋር ለማረጋገጥ እነሱ ሲሆኑ ማመሳሰልን ማድረግ እንደሚችሉ ነው.
        //
        // ያ ተግባር በመደበኛ ቤተ-መጽሐፍት በኩል ወይም በ crates.io በኩል በሚጠራበት ጊዜ በዚያው ተመሳሳይ ሙዝ እየተገኘ መሆኑን እርግጠኛ መሆን እንችላለን ፡፡
        //
        // ስለዚህ ያ ሁሉ እኛ እዚህ የምናደርገው የመጀመሪያው ነገር በአቶሚክ XXXXXXXXXXXXXXXXXXXXXXXXXXX ን እንፈጥራለን ማለት ነው ፡፡
        // ይህንን ተግባር በተለይ ከሚካፈሉት ሌሎች ክሮች ጋር በጥቂቱ እናመሳስል እና በዚህ ተግባር ለምሳሌ አንድ እጀታ ብቻ መፈጠሩን እናረጋግጣለን ፡፡
        // በዓለም አቀፍ ደረጃ ከተከማቸ በኋላ እጀታው በጭራሽ እንደማይዘጋ ልብ ይበሉ ፡፡
        //
        // በእውነቱ ቁልፉን ከሄድን በኋላ በቀላሉ እናገኘዋለን ፣ እና አሳልፈን የምንሰጠው የ `Init` እጀታችን በስተመጨረሻው የመጣል ኃላፊነት አለበት።
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        static LOCK: AtomicUsize = AtomicUsize::new(0);
        let mut lock = LOCK.load(SeqCst);
        if lock == 0 {
            lock = CreateMutexA(
                ptr::null_mut(),
                0,
                "Local\\RustBacktraceMutex\0".as_ptr() as _,
            ) as usize;
            if lock == 0 {
                return Err(());
            }
            if let Err(other) = LOCK.compare_exchange(0, lock, SeqCst, SeqCst) {
                debug_assert!(other != 0);
                CloseHandle(lock as HANDLE);
                lock = other;
            }
        }
        debug_assert!(lock != 0);
        let lock = lock as HANDLE;
        let r = WaitForSingleObjectEx(lock, INFINITE, FALSE);
        debug_assert_eq!(r, 0);
        let ret = Init { lock };

        // እሺ ፣ እሺ!አሁን ሁላችንም በደህና ስለመሳሰልን በእውነቱ ሁሉንም ነገር ማቀናጀት እንጀምር ፡፡
        // በመጀመሪያ ደረጃ `dbghelp.dll` በእውነቱ በዚህ ሂደት ውስጥ መጫኑን ማረጋገጥ አለብን ፡፡
        // የማይንቀሳቀስ ጥገኝነትን ለማስወገድ ይህንን በተለዋጭ ሁኔታ እናደርጋለን።
        // ይህም በታሪካዊ እንግዳ ማገናኘት ጉዳዮች ዙሪያ ሥራ ላይ ያደረገውን ተደርጓል ይህ በአብዛኛው ብቻ ማረም የመገልገያ ስለሆነ ትንሽ ተጨማሪ ተንቀሳቃሽ በሁለትዮሾችዎ በማድረግ ላይ የታሰበ ነው.
        //
        //
        // አንዴ `dbghelp.dll` ን ከከፈትነው በውስጡ አንዳንድ የመነሻ ተግባሮችን መጥራት ያስፈልገናል ፣ ያ ደግሞ ከዚህ በታች በዝርዝር ተገልጻል ፡፡
        // እኛ ገና ወይም ሲጨርሱ እንደሆነ የሚያመለክት አቀፍ ቡሊያን አግኝተዋል ስለዚህ እኛ ብቻ ቢሆንም, አንድ ጊዜ ይህን ማድረግ.
        //
        //
        //
        //
        DBGHELP.ensure_open()?;

        static mut INITIALIZED: bool = false;
        if INITIALIZED {
            return Ok(ret);
        }

        let orig = DBGHELP.SymGetOptions().unwrap()();

        // "This is the fastest, most efficient way to use the symbol handler.", እንዲሁ ዎቹ ይህን ያድርግ; ይህ ስለ MSVC በራሱ ሰነዶች መሠረት ምክንያቱም `SYMOPT_DEFERRED_LOADS` ባንዲራ, መዋቀሩን ያረጋግጡ!
        //
        //
        DBGHELP.SymSetOptions().unwrap()(orig | SYMOPT_DEFERRED_LOADS);

        // በእውነቱ ምልክቶችን በ MSVC ያስጀምሩ።ይህ ሊከሽፍ እንደሚችል ልብ ይበሉ ፣ ግን እኛ ችላ እንለዋለን።
        // ለዚህ በአንድ ጊዜ አንድ ቶን የቀደመ ጥበብ የለም ፣ ግን LLVM በውስጣዊ የመመለሻ ዋጋን እዚህ ያለ ይመስላል እና በ LLVM ውስጥ ካሉ የንፅህና ማጽጃ ቤተ-መጻሕፍት አንዱ ይህ ካልተሳካ አስፈሪ ማስጠንቀቂያ ያትማል ፣ ግን በመሠረቱ በረጅም ጊዜ ውስጥ ችላ ይባላል ፡፡
        //
        //
        // ይህ Rust ዕጣ እስከ የሚመጣ አንድ ጉዳይ መደበኛ መጽሐፍት እና crates.io በሁለቱም ላይ ይህን crate `SymInitializeW` ለ መወዳደር የሚፈልጉ መሆኑን ነው.
        // ደረጃውን የጠበቀ ቤተ-መጽሐፍት በታሪክ ውስጥ ያኔ ብዙ ጊዜ ማፅዳትን ለማስጀመር ፈለገ ፣ ግን አሁን ይህንን crate እየተጠቀመ ስለሆነ አንድ ሰው መጀመሪያ ወደ መጀመሪያው ደረጃ ይደርሳል ሌላኛው ደግሞ ያንን ጅምርን ይመርጣል ማለት ነው ፡፡
        //
        //
        //
        //
        //
        //
        DBGHELP.SymInitializeW().unwrap()(GetCurrentProcess(), ptr::null_mut(), TRUE);
        INITIALIZED = true;
        Ok(ret)
    }
}

impl Drop for Init {
    fn drop(&mut self) {
        unsafe {
            let r = ReleaseMutex(self.lock);
            debug_assert!(r != 0);
        }
    }
}