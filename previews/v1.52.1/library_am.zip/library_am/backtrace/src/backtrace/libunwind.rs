//! libunwind/gcc_s/etc አይዎችን በመጠቀም Backtrace ድጋፍ.
//!
//! ይህ ሞጁል የ libunwind-style ኤ.ፒ.አይ.ዎችን በመጠቀም ቁልል የመፈታተን ችሎታ ይ containsል ፡፡
//! ማስታወሻ በዚያ libunwind-እንደ ኤ ማስፈጸሚያዎች አንድ ስብስብ ነው, ይህም አንድ ጊዜ ብቻ ይልቅ መለቃቀም መሆን ላይ ሁሉንም አብዛኞቹ ጋር ተኳሃኝ ለመሆን እየሞከረ ነው.
//!
//!
//! የ libunwind ኤ `_Unwind_Backtrace` የተጎላበተው እና ልምምድ ውስጥ backtrace በማመንጨት ላይ በጣም አስተማማኝ ነው.
//! እሱ እንዴት እንደሚያደርግ ሙሉ በሙሉ ግልፅ አይደለም (የፍሬም ጠቋሚዎች? Eh_frame info? ሁለቱም?) ግን የሚሰራ ይመስላል!
//!
//! የዚህ ሞጁል ውስብስብነት አብዛኛው በሊባውዊንድ አተገባበር ላይ የተለያዩ የመድረክ ልዩነቶችን ያስተናግዳል ፡፡
//! አለበለዚያ ይህ ለ libunwind ኤ.ፒ.አይ.ዎች የሚያገናኝ ቀጥተኛ ቀጥተኛ Rust ነው።
//!
//! በአሁኑ ጊዜ ዊንዶውስ ላልሆኑ ሁሉም የመሳሪያ ስርዓቶች ነባሪ ማራገፊያ ኤ.ፒ.አይ.
//!
//!
//!

use super::super::Bomb;
use core::ffi::c_void;

pub enum Frame {
    Raw(*mut uw::_Unwind_Context),
    Cloned {
        ip: *mut c_void,
        sp: *mut c_void,
        symbol_address: *mut c_void,
    },
}

// በጥሬ ሊቢንዊን ጠቋሚ አማካኝነት በቀላሉ ሊነበብ በሚችል የፋሽን ፋሽን ብቻ መድረስ አለበት ፣ ስለሆነም `Sync` ነው።
// በ `Clone` በኩል ወደ ሌሎች ክሮች ስንልክ ሁል ጊዜ የውስጥ ጠቋሚዎችን ወደማይያዝ ስሪት እንሸጋገራለን ፣ ስለሆነም እኛ `Send` መሆን አለብን ፡፡
//
//
unsafe impl Send for Frame {}
unsafe impl Sync for Frame {}

impl Frame {
    pub fn ip(&self) -> *mut c_void {
        let ctx = match *self {
            Frame::Raw(ctx) => ctx,
            Frame::Cloned { ip, .. } => return ip,
        };
        unsafe { uw::_Unwind_GetIP(ctx) as *mut c_void }
    }

    pub fn sp(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ctx) => unsafe { uw::get_sp(ctx) as *mut c_void },
            Frame::Cloned { sp, .. } => sp,
        }
    }

    pub fn symbol_address(&self) -> *mut c_void {
        if let Frame::Cloned { symbol_address, .. } = *self {
            return symbol_address;
        }

        // በ OSX `_Unwind_FindEnclosingFunction`` ላይ ጠቋሚውን ወደ ... ግልፅ ያልሆነ ነገር የሚመልስ ይመስላል።
        // በእርግጠኝነት በማንኛውም ምክንያት የመከለል ተግባር አይደለም ፡፡
        // እዚህ ምን እየተደረገ እንዳለ ለእኔ ሙሉ በሙሉ ግልፅ አይደለም ፣ ስለሆነም ይህንን በአእምሮዎ ይገምቱ እና ip ን ሁልጊዜ ይመልሱ ፡፡
        //
        // የ `skip_inner_frames.rs` ሙከራ በዚህ አንቀፅ ምክንያት በ OSX ላይ እንደተዘለ ልብ ይበሉ ፣ እና ይህ ከተስተካከለ ያ በንድፈ ሀሳብ ሙከራው በ OSX ላይ ሊሠራ ይችላል!
        //
        //
        //
        if cfg!(target_os = "macos") || cfg!(target_os = "ios") {
            self.ip()
        } else {
            unsafe { uw::_Unwind_FindEnclosingFunction(self.ip()) }
        }
    }

    pub fn module_base_address(&self) -> Option<*mut c_void> {
        None
    }
}

impl Clone for Frame {
    fn clone(&self) -> Frame {
        Frame::Cloned {
            ip: self.ip(),
            sp: self.sp(),
            symbol_address: self.symbol_address(),
        }
    }
}

#[inline(always)]
pub unsafe fn trace(mut cb: &mut dyn FnMut(&super::Frame) -> bool) {
    uw::_Unwind_Backtrace(trace_fn, &mut cb as *mut _ as *mut _);

    extern "C" fn trace_fn(
        ctx: *mut uw::_Unwind_Context,
        arg: *mut c_void,
    ) -> uw::_Unwind_Reason_Code {
        let cb = unsafe { &mut *(arg as *mut &mut dyn FnMut(&super::Frame) -> bool) };
        let cx = super::Frame {
            inner: Frame::Raw(ctx),
        };

        let mut bomb = Bomb { enabled: true };
        let keep_going = cb(&cx);
        bomb.enabled = false;

        if keep_going {
            uw::_URC_NO_REASON
        } else {
            uw::_URC_FAILURE
        }
    }
}

/// ለኋላ ማሳያዎች ያገለገሉ የቤተ-መጽሐፍት በይነገጽን ያራግፉ
///
/// ልብ ይበሉ የሞት ኮድ እዚህ ላይ ብቻ ነው ምክንያቱም iOS ሁሉንም አይጠቀምም ነገር ግን ተጨማሪ የመሣሪያ ስርዓት ተኮር ውቅሮችን ማከል ኮዱን በጣም ያረክሳል።
///
///
#[allow(non_camel_case_types)]
#[allow(non_snake_case)]
#[allow(dead_code)]
mod uw {
    pub use self::_Unwind_Reason_Code::*;

    use core::ffi::c_void;

    #[repr(C)]
    pub enum _Unwind_Reason_Code {
        _URC_NO_REASON = 0,
        _URC_FOREIGN_EXCEPTION_CAUGHT = 1,
        _URC_FATAL_PHASE2_ERROR = 2,
        _URC_FATAL_PHASE1_ERROR = 3,
        _URC_NORMAL_STOP = 4,
        _URC_END_OF_STACK = 5,
        _URC_HANDLER_FOUND = 6,
        _URC_INSTALL_CONTEXT = 7,
        _URC_CONTINUE_UNWIND = 8,
        _URC_FAILURE = 9, // በ ARM EABI ብቻ ጥቅም ላይ የዋለ
    }

    pub enum _Unwind_Context {}

    pub type _Unwind_Trace_Fn =
        extern "C" fn(ctx: *mut _Unwind_Context, arg: *mut c_void) -> _Unwind_Reason_Code;

    extern "C" {
        // በ iOS ላይ ምንም ተወላጅ _Unwind_Backtrace የለም
        #[cfg(not(all(target_os = "ios", target_arch = "arm")))]
        pub fn _Unwind_Backtrace(
            trace: _Unwind_Trace_Fn,
            trace_argument: *mut c_void,
        ) -> _Unwind_Reason_Code;

        // ከ GCC 4.2.0 ጀምሮ የሚገኝ ፣ ለአላማችን ጥሩ መሆን አለበት
        #[cfg(all(
            not(all(target_os = "android", target_arch = "arm")),
            not(all(target_os = "freebsd", target_arch = "arm")),
            not(all(target_os = "linux", target_arch = "arm"))
        ))]
        pub fn _Unwind_GetIP(ctx: *mut _Unwind_Context) -> libc::uintptr_t;

        #[cfg(all(
            not(all(target_os = "android", target_arch = "arm")),
            not(all(target_os = "freebsd", target_arch = "arm")),
            not(all(target_os = "linux", target_arch = "arm"))
        ))]
        pub fn _Unwind_FindEnclosingFunction(pc: *mut c_void) -> *mut c_void;

        #[cfg(all(
            not(all(target_os = "android", target_arch = "arm")),
            not(all(target_os = "freebsd", target_arch = "arm")),
            not(all(target_os = "linux", target_arch = "arm")),
            not(all(target_os = "linux", target_arch = "s390x"))
        ))]
        // ይህ ተግባር የተሳሳተ ቃል ነው-የዚህን ክፈፍ ቀኖናዊ ፍሬም አድራሻ (የደዋይ ፍሬም SP) ከማግኘት ይልቅ የዚህን ክፈፍ SP ይመልሳል።
        //
        //
        // https://github.com/libunwind/libunwind/blob/d32956507cf29d9b1a98a8bce53c78623908f4fe/src/unwind/GetCFA.c#L28-L35
        //
        #[link_name = "_Unwind_GetCFA"]
        pub fn get_sp(ctx: *mut _Unwind_Context) -> libc::uintptr_t;
    }

    // s390x ገለልተኛ የሆነ የሲኤፍኤ ዋጋን ይጠቀማል ፣ ስለሆነም በ _Unwind_GetCFA ላይ ከመተማመን ይልቅ የቁልፍ ጠቋሚው (%r15) ን ለማግኘት _Unwind_GetGR ን መጠቀም አለብን።
    //
    //
    #[cfg(all(target_os = "linux", target_arch = "s390x"))]
    pub unsafe fn get_sp(ctx: *mut _Unwind_Context) -> libc::uintptr_t {
        extern "C" {
            pub fn _Unwind_GetGR(ctx: *mut _Unwind_Context, index: libc::c_int) -> libc::uintptr_t;
        }
        _Unwind_GetGR(ctx, 15)
    }

    // እኛ የማክሮዎች የማስፋፊያ የያዘ ተግባራት ለመግለጽ ስለዚህ android እና ክንዱ ላይ, ተግባር `_Unwind_GetIP` እና ሌሎች ስብስብ, ማክሮዎችን ናቸው.
    //
    //
    // TODO: ሊያገኙት ከቻሉ እነዚህን ማክሮዎች ከሚገልጸው የራስጌ ፋይል ጋር ያገናኙ።
    // (እኔ fitzgen ፣ ከእነዚህ ማክሮ መስፋፋቶች አንዳንዶቹ በመጀመሪያ የተዋሱትን የራስጌ ፋይል ማግኘት አልቻልኩም ፡፡)
    //
    //
    #[cfg(any(
        all(target_os = "android", target_arch = "arm"),
        all(target_os = "freebsd", target_arch = "arm"),
        all(target_os = "linux", target_arch = "arm")
    ))]
    pub use self::arm::*;
    #[cfg(any(
        all(target_os = "android", target_arch = "arm"),
        all(target_os = "freebsd", target_arch = "arm"),
        all(target_os = "linux", target_arch = "arm")
    ))]
    mod arm {
        pub use super::*;
        #[repr(C)]
        enum _Unwind_VRS_Result {
            _UVRSR_OK = 0,
            _UVRSR_NOT_IMPLEMENTED = 1,
            _UVRSR_FAILED = 2,
        }
        #[repr(C)]
        enum _Unwind_VRS_RegClass {
            _UVRSC_CORE = 0,
            _UVRSC_VFP = 1,
            _UVRSC_FPA = 2,
            _UVRSC_WMMXD = 3,
            _UVRSC_WMMXC = 4,
        }
        #[repr(C)]
        enum _Unwind_VRS_DataRepresentation {
            _UVRSD_UINT32 = 0,
            _UVRSD_VFPX = 1,
            _UVRSD_FPAX = 2,
            _UVRSD_UINT64 = 3,
            _UVRSD_FLOAT = 4,
            _UVRSD_DOUBLE = 5,
        }

        type _Unwind_Word = libc::c_uint;
        extern "C" {
            fn _Unwind_VRS_Get(
                ctx: *mut _Unwind_Context,
                klass: _Unwind_VRS_RegClass,
                word: _Unwind_Word,
                repr: _Unwind_VRS_DataRepresentation,
                data: *mut c_void,
            ) -> _Unwind_VRS_Result;
        }

        pub unsafe fn _Unwind_GetIP(ctx: *mut _Unwind_Context) -> libc::uintptr_t {
            let mut val: _Unwind_Word = 0;
            let ptr = &mut val as *mut _Unwind_Word;
            let _ = _Unwind_VRS_Get(
                ctx,
                _Unwind_VRS_RegClass::_UVRSC_CORE,
                15,
                _Unwind_VRS_DataRepresentation::_UVRSD_UINT32,
                ptr as *mut c_void,
            );
            (val & !1) as libc::uintptr_t
        }

        // R13 በእጁ ላይ የተቆለለው ጠቋሚ ነው ፡፡
        const SP: _Unwind_Word = 13;

        pub unsafe fn get_sp(ctx: *mut _Unwind_Context) -> libc::uintptr_t {
            let mut val: _Unwind_Word = 0;
            let ptr = &mut val as *mut _Unwind_Word;
            let _ = _Unwind_VRS_Get(
                ctx,
                _Unwind_VRS_RegClass::_UVRSC_CORE,
                SP,
                _Unwind_VRS_DataRepresentation::_UVRSD_UINT32,
                ptr as *mut c_void,
            );
            val as libc::uintptr_t
        }

        // ይህ ተግባር በ Android ወይም ARM/Linux ላይም ስለሌለ ምርጫ-አልባ ይሁኑ ፡፡
        //
        pub unsafe fn _Unwind_FindEnclosingFunction(pc: *mut c_void) -> *mut c_void {
            pc
        }
    }
}