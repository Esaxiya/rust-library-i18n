use core::ffi::c_void;
use core::fmt;

/// የአሁኑን ጥሪ-ቁልል ተመለከተ, ወደ መዘጋት ወደ ሁሉም ንቁ ክፈፎች በማለፍ አንድ ቁልል ለማስላት የቀረበው.
///
/// ይህ ተግባር ለፕሮግራም የቁልል ዱካዎችን በማስላት የዚህ ቤተ-መጽሐፍት ሥራ ነው ፡፡በተሰጠው መዘጋት `cb` በቁልሉ ላይ መሆኑን ጥሪ ክፈፍ በተመለከተ መረጃ የሚወክሉ ይህም `Frame` አብነቶችን አፈራ ነው.
/// የ መዘጋት አንድ ከላይ-ወደታች ፋሽን ክፈፎች አልሰጠም ነው (በጣም በቅርቡ ለመጀመሪያ ተግባራት ይባላል).
///
/// የመዘጋቱ የመመለሻ ዋጋ የኋላው መቀጠል መቀጠል እንዳለበት አመላካች ነው።የ `false` የመመለሻ እሴት የጀርባውን ጀርባ ያቋርጣል እና ወዲያውኑ ይመለሳል።
///
/// አንድ `Frame` አግኝተዋል አንዴ አይቀርም ስም እና/ወይም የፋይል ስም/መስመር ቁጥር መማር ይቻላል ይህም በኩል `Symbol` ወደ `ip` (መመሪያ ጠቋሚ) ወይም ምልክት አድራሻ ለመለወጥ `backtrace::resolve` መደወል ይፈልጋሉ ይሆናል.
///
///
/// ይህ በአንጻራዊ ሁኔታ ዝቅተኛ-ደረጃ ፈንክሽን ነው እና የሚፈልጉ ከሆነ, ለምሳሌ ያህል, አንድ backtrace ለመያዝ መሆኑን ማስታወሻ ከዚያም `Backtrace` አይነት ይበልጥ ተገቢ ሊሆን ይችላል; በኋላ ሊመረመሩ ዘንድ.
///
/// # አስፈላጊ ባህሪዎች
///
/// ይህ ተግባር የ `backtrace` crate የ `std` ባህሪው እንዲነቃ ይፈልጋል ፣ እና የ `std` ባህሪው በነባሪነት ነቅቷል።
///
/// # Panics
///
/// ይህ ተግባር በጭራሽ panic ን ለማድረግ ይጥራል ፣ ግን `cb` panics ን ከሰጠ ከዚያ አንዳንድ መድረኮች ሂደቱን ለማቋረጥ ሁለት እጥፍ panic ያስገድዳሉ።
/// አንዳንድ መድረኮች በውስጥ በኩል ሊፈጠሩ የማይችሉ የጥሪ መልሶችን በውስጣቸው የሚጠቀመውን C ቤተ-መጻሕፍት ይጠቀማሉ ፣ ስለሆነም ከ `cb` መፍራት የሂደቱን ፅንስ ማስወረድ ሊያስነሳ ይችላል ፡፡
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         // ...
///
///         true // የኋላ ኋላ ይቀጥሉ
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn trace<F: FnMut(&Frame) -> bool>(cb: F) {
    let _guard = crate::lock::lock();
    unsafe { trace_unsynchronized(cb) }
}

/// ከ `trace` ጋር ተመሳሳይ ፣ የማይመሳሰል ስለሆነ ደህንነቱ የተጠበቀ ብቻ።
///
/// ይህ ተግባር ማመሳሰል guarentees አላቸው ነገር ግን ይህ crate ውስጥ `std` ባህሪ የተጠናቀሩ አይደለም ሲገኝ ነው ማለት አይደለም.
/// ተጨማሪ ሰነድ እና ምሳሌዎችን ለማግኘት `trace` ተግባር ይመልከቱ.
///
/// # Panics
///
/// በ `cb` መፍራት ላይ ለሚገኙ ማስጠንቀቂያዎች በ `trace` ላይ መረጃ ይመልከቱ።
///
pub unsafe fn trace_unsynchronized<F: FnMut(&Frame) -> bool>(mut cb: F) {
    trace_imp(&mut cb)
}

/// አንድ የኋላ ታሪክ አንድ ክፈፍ የሚወክል trait ለዚህ የ‹crate›`trace` ተግባር ተሰጠ ፡፡
///
/// የክትትል ተግባሩ መዘጋት ፍሬሞች ይሰጣቸዋል ፣ እና መሠረታዊው አተገባበር እስከ ሩጫ ሰዓት ድረስ ሁልጊዜ ስለማይታወቅ ክፈፉ በእውነቱ ይላካል።
///
///
///
#[derive(Clone)]
pub struct Frame {
    pub(crate) inner: FrameImp,
}

impl Frame {
    /// ይህ ፍሬም የአሁኑ መመሪያ ጠቋሚ ያወጣል.
    ///
    /// ይህ በመደበኛነት ፍሬም ውስጥ ለማስፈጸም በሚቀጥለው መመሪያ ነው, ነገር ግን ሁሉም ማስፈጸሚያዎች 100% ትክክለኛነት ጋር ይህ ዝርዝር (ግን ቆንጆ ቅርብ በአጠቃላይ ነው).
    ///
    ///
    /// ወደ ምልክት ስም ለመቀየር ይህንን እሴት ወደ `backtrace::resolve` ማስተላለፍ ይመከራል።
    ///
    ///
    pub fn ip(&self) -> *mut c_void {
        self.inner.ip()
    }

    /// የዚህን ክፈፍ የአሁኑን የቁልፍ ጠቋሚ ይመልሳል።
    ///
    /// የኋላ ደጀን ለዚህ ፍሬም ቁልል ጠቋሚውን መልሶ ማግኘት የማይችል ከሆነ ፣ አንድ የከንቱ ጠቋሚ ተመልሷል።
    ///
    pub fn sp(&self) -> *mut c_void {
        self.inner.sp()
    }

    /// የዚህን ተግባር ፍሬም መነሻ ምልክት አድራሻ ይመልሳል።
    ///
    /// ይህ ዋጋውን በመመለስ በ `ip` የተመለሰውን መመሪያ ጠቋሚ ወደ ተግባሩ መጀመሪያ ለመመለስ ይሞክራል።
    ///
    /// በአንዳንድ ሁኔታዎች ግን ፣ የኋላ ማበረታቻዎች `ip` ን ከዚህ ተግባር ብቻ ይመልሳሉ።
    ///
    /// ከላይ በተጠቀሰው `ip` ላይ `backtrace::resolve` ካልተሳካ የተመለሰው እሴት አንዳንድ ጊዜ ጥቅም ላይ ሊውል ይችላል ፡፡
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.inner.symbol_address()
    }

    /// ክፈፉ ያለበትበትን ሞዱል የመሠረታዊ አድራሻ ይመልሳል።
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.inner.module_base_address()
    }
}

impl fmt::Debug for Frame {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Frame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

cfg_if::cfg_if! {
    // ይህ Miri አስተናጋጁ መድረክ ላይ ቅድሚያ የሚወስድ መሆኑን ለማረጋገጥ, አስቀድሞ ሊመጣ ያስፈልገዋል
    //
    if #[cfg(miri)] {
        pub(crate) mod miri;
        use self::miri::trace as trace_imp;
        pub(crate) use self::miri::Frame as FrameImp;
    } else if #[cfg(
        any(
            all(
                unix,
                not(target_os = "emscripten"),
                not(all(target_os = "ios", target_arch = "arm")),
            ),
            all(
                target_env = "sgx",
                target_vendor = "fortanix",
            ),
        )
    )] {
        mod libunwind;
        use self::libunwind::trace as trace_imp;
        pub(crate) use self::libunwind::Frame as FrameImp;
    } else if #[cfg(all(windows, not(target_vendor = "uwp")))] {
        mod dbghelp;
        use self::dbghelp::trace as trace_imp;
        pub(crate) use self::dbghelp::Frame as FrameImp;
        #[cfg(target_env = "msvc")] // በምልክት በ dbghelp ውስጥ ብቻ ጥቅም ላይ ውሏል
        pub(crate) use self::dbghelp::StackFrame;
    } else {
        mod noop;
        use self::noop::trace as trace_imp;
        pub(crate) use self::noop::Frame as FrameImp;
    }
}