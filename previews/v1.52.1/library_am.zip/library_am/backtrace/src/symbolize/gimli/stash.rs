// አሁን በ Linux ላይ ብቻ ጥቅም ላይ ውሏል ፣ ስለሆነም የሞተውን ኮድ በሌላ ቦታ ይፍቀዱ
#![cfg_attr(not(target_os = "linux"), allow(dead_code))]

use alloc::vec;
use alloc::vec::Vec;
use core::cell::UnsafeCell;

/// ለባይት ቋቶች ቀለል ያለ የአረና ማከፋፈያ።
pub struct Stash {
    buffers: UnsafeCell<Vec<Vec<u8>>>,
}

impl Stash {
    pub fn new() -> Stash {
        Stash {
            buffers: UnsafeCell::new(Vec::new()),
        }
    }

    /// የተገለጸውን መጠን ቋት ይመድባል እና የሚለዋወጥ ማጣቀሻውን ይመልሳል።
    ///
    pub fn allocate(&self, size: usize) -> &mut [u8] {
        // ደህንነት-የሚለዋወጥ የሚችል የሚገነባ ብቸኛው ተግባር ይህ ነው
        // ወደ `self.buffers` ማጣቀሻ.
        let buffers = unsafe { &mut *self.buffers.get() };
        let i = buffers.len();
        buffers.push(vec![0; size]);
        // ደህንነት-አባሎችን በጭራሽ ከ `self.buffers` አናስወግድም ፣ ስለዚህ ማጣቀሻ
        // `self` እስካለ ድረስ በማንኛውም ቋት ውስጥ ላለ መረጃ ይኖራል ፡፡
        &mut buffers[i]
    }
}