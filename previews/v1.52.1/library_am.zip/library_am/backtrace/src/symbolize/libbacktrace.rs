//! በ libbacktrace ውስጥ የ DWARF-መተላለፊያ ኮድ በመጠቀም የምልክት ስልት።
//!
//! በተለምዶ ከ gcc ጋር የሚሰራጨው የ libbacktrace C ቤተ-መጽሐፍት የኋላ ታሪክን ማመንጨት ብቻ አይደለም (እኛ በእውነቱ የማንጠቀምበትን) ይደግፋል ፣ ግን የኋላ ኋላ ምሳሌን ያሳያል እና እንደ ረቂቅ ክፈፎች እና ምን እንደ ላሉት ያሉ ድንክ ማረም መረጃዎችን ያስተናግዳል ፡፡
//!
//!
//! እዚህ በብዙ የተለያዩ ስጋቶች ምክንያት ይህ በአንፃራዊነት ውስብስብ ነው ፣ ግን መሠረታዊው ሀሳብ-
//!
//! * መጀመሪያ `backtrace_syminfo` ብለን እንጠራዋለን ፡፡ይህ የምንችል ከሆነ ከተለዋጭ ምልክት ሰንጠረ symbol የምልክት መረጃን ያገኛል።
//! * ቀጥሎ `backtrace_pcinfo` ብለን እንጠራዋለን ፡፡ይህ የአዳኝ ሰንጠረ tablesችን የሚገኙ ከሆነ በጥልቀት ይተነትናል እንዲሁም ስለ የመስመር ፍሬሞች ፣ የፋይል ስሞች ፣ የመስመር ቁጥሮች ፣ ወዘተ መረጃ እንድናገኝ ያስችለናል ፡፡
//!
//! ድንክ ሰንጠረ tablesችን ወደ libbacktrace ለማስገባት ብዙ ማታለያዎች አሉ ፣ ግን ተስፋችን የዓለም መጨረሻ አለመሆኑን እና ከዚህ በታች ሲያነቡ በቂ ግልፅ ነው ፡፡
//!
//! ይህ ያልሆኑ MSVC ያልሆኑ OSX መድረኮች ነባሪ symbolication ስትራቴጂ ነው.በ libstd ውስጥ ይህ ለ OSX ነባሪ ስልቱ ቢሆንም ፡፡
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(bad_style)]

extern crate backtrace_sys as bt;

use core::{marker, ptr, slice};
use libc::{self, c_char, c_int, c_void, uintptr_t};

use crate::symbolize::{ResolveWhat, SymbolName};
use crate::types::BytesOrWideString;

pub enum Symbol<'a> {
    Syminfo {
        pc: uintptr_t,
        symname: *const c_char,
        _marker: marker::PhantomData<&'a ()>,
    },
    Pcinfo {
        pc: uintptr_t,
        filename: *const c_char,
        lineno: c_int,
        function: *const c_char,
        symname: *const c_char,
    },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        let symbol = |ptr: *const c_char| unsafe {
            if ptr.is_null() {
                None
            } else {
                let len = libc::strlen(ptr);
                Some(SymbolName::new(slice::from_raw_parts(
                    ptr as *const u8,
                    len,
                )))
            }
        };
        match *self {
            Symbol::Syminfo { symname, .. } => symbol(symname),
            Symbol::Pcinfo {
                function, symname, ..
            } => {
                // ከተቻለ ከ‹debuginfo›የሚመጣውን የ‹XXXX›ስም ይመርጣል እና ለምሳሌ ለውስጠ-መስመር ፍሬሞች የበለጠ ትክክለኛ ሊሆን ይችላል ፡፡
                // ያ ካልሆነ በ `symname` ውስጥ ወደተጠቀሰው የምልክት ሰንጠረዥ ስም ቢመለሱም ያ ካልሆነ።
                //
                // ልብ ይበሉ አንዳንድ ጊዜ `function` በተወሰነ ደረጃ ትክክል ያልሆነ ስሜት ሊሰማው እንደሚችል ልብ ይበሉ ፣ ለምሳሌ `try<i32,closure>` ን ከ `std::panicking::try::do_call` በታች አድርጎ መዘርዘር።
                //
                // በእርግጥ ለምን እንደሆነ ግልጽ አይደለም, ነገር ግን በአጠቃላይ በ `function` ስም ይበልጥ ትክክለኛ ይመስላል.
                //
                //
                //
                if let Some(sym) = symbol(function) {
                    return Some(sym);
                }
                symbol(symname)
            }
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        let pc = match *self {
            Symbol::Syminfo { pc, .. } => pc,
            Symbol::Pcinfo { pc, .. } => pc,
        };
        if pc == 0 {
            None
        } else {
            Some(pc as *mut _)
        }
    }

    fn filename_bytes(&self) -> Option<&[u8]> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { filename, .. } => {
                let ptr = filename as *const u8;
                if ptr.is_null() {
                    return None;
                }
                unsafe {
                    let len = libc::strlen(filename);
                    Some(slice::from_raw_parts(ptr, len))
                }
            }
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.filename_bytes().map(BytesOrWideString::Bytes)
    }

    #[cfg(feature = "std")]
    pub fn filename(&self) -> Option<&::std::path::Path> {
        use std::path::Path;

        #[cfg(unix)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::ffi::OsStr;
            use std::os::unix::prelude::*;
            Some(Path::new(OsStr::from_bytes(bytes)))
        }

        #[cfg(windows)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::str;
            str::from_utf8(bytes).ok().map(Path::new)
        }

        self.filename_bytes().and_then(bytes2path)
    }

    pub fn lineno(&self) -> Option<u32> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { lineno, .. } => Some(lineno as u32),
        }
    }

    pub fn colno(&self) -> Option<u32> {
        None
    }
}

extern "C" fn error_cb(_data: *mut c_void, _msg: *const c_char, _errnum: c_int) {
    // ለአሁን ምንም አታድርግ
}

/// የ `data` ጠቋሚ አይነት ወደ `syminfo_cb` ተላል .ል
struct SyminfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    pc: usize,
}

extern "C" fn syminfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    symname: *const c_char,
    _symval: uintptr_t,
    _symsize: uintptr_t,
) {
    let mut bomb = crate::Bomb { enabled: true };

    // ከዚህ ተዘዋዋሪ `backtrace_syminfo` ከ የምታሰበው አንዴ ብለን `backtrace_pcinfo` መደወል ተጨማሪ መሄድ ለመፍታት ሲጀምሩ.
    // የ‹XXXXXXXXXXXXXX መረጃን መልሶ ማግኘት እና እንዲሁም በተዘረዘሩ ክፈፎች ላይ ያሉ ነገሮችን ለማረም የ‹XXXX›መረጃን ያማክራል ፡፡
    // ምንም እንኳን‹`backtrace_pcinfo`›የማረም መረጃ ከሌለ ብዙ ሊሳካ ወይም እንደማይችል ልብ ይበሉ ፣ ስለዚህ ይህ ከተከሰተ ከ‹XXXXXXXXXXXXXXX›ጋር ቢያንስ አንድ ጥሪን እንደምንጠራው ልብ ይበሉ ፡፡
    //
    //
    //
    //
    unsafe {
        let syminfo_state = &mut *(data as *mut SyminfoState<'_>);
        let mut pcinfo_state = PcinfoState {
            symname,
            called: false,
            cb: syminfo_state.cb,
        };
        bt::backtrace_pcinfo(
            init_state(),
            syminfo_state.pc as uintptr_t,
            pcinfo_cb,
            error_cb,
            &mut pcinfo_state as *mut _ as *mut _,
        );
        if !pcinfo_state.called {
            (pcinfo_state.cb)(&super::Symbol {
                inner: Symbol::Syminfo {
                    pc: pc,
                    symname: symname,
                    _marker: marker::PhantomData,
                },
            });
        }
    }

    bomb.enabled = false;
}

/// የ `data` ጠቋሚ አይነት ወደ `pcinfo_cb` ተላል .ል
struct PcinfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    symname: *const c_char,
    called: bool,
}

extern "C" fn pcinfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    filename: *const c_char,
    lineno: c_int,
    function: *const c_char,
) -> c_int {
    let mut bomb = crate::Bomb { enabled: true };

    unsafe {
        let state = &mut *(data as *mut PcinfoState<'_>);
        state.called = true;
        (state.cb)(&super::Symbol {
            inner: Symbol::Pcinfo {
                pc: pc,
                filename: filename,
                lineno: lineno,
                symname: state.symname,
                function,
            },
        });
    }

    bomb.enabled = false;
    return 0;
}

// የ libbacktrace ኤፒአይ ሁኔታ መፍጠርን ይደግፋል ፣ ነገር ግን አንድን ሀገር መደገፉን አይደግፍም ፡፡
// እኔ በግሌ ይሄን የምወስደው ክልል እንዲፈጠር እና ከዚያ በኋላ ለዘላለም እንዲኖር ነው ለማለት ነው ፡፡
//
// ይህንን ሁኔታ የሚያጸዳ የ at_exit() መቆጣጠሪያን መመዝገብ እፈልጋለሁ ፣ ግን libbacktrace ይህን ለማድረግ ምንም መንገድ አይሰጥም ፡፡
//
// በእነዚህ ገደቦች ይህ ተግባር ለመጀመሪያ ጊዜ ሲጠየቅ የሚሰላ የማይንቀሳቀስ መሸጎጫ ሁኔታ አለው ፡፡
//
// ሁሉም backtracing (አንድ ዓለም አቀፍ መቆለፍ) serially ይከሰታል መሆኑን አስታውስ.
//
// እዚህ ላይ የማመሳሰል እጥረት `resolve` ን ከውጭ ማመሳሰል ከሚለው መስፈርት የተነሳ ልብ ይበሉ ፡፡
//
//
//
unsafe fn init_state() -> *mut bt::backtrace_state {
    static mut STATE: *mut bt::backtrace_state = 0 as *mut _;

    if !STATE.is_null() {
        return STATE;
    }

    STATE = bt::backtrace_create_state(
        load_filename(),
        // ሁሌም በተመሳሰለ ፋሽን የምንጠራው ስለሆነ የ libbacktrace የጥበቃ ደህንነቶች ችሎታ አይለማመዱ ፡፡
        //
        0,
        error_cb,
        ptr::null_mut(), // ምንም ተጨማሪ ውሂብ የለም
    );

    return STATE;

    // ለ libbacktrace በሁሉም እንዲሠራ ለአሁኑ ተፈፃሚነት የ DWARF ማረም መረጃን መፈለግ እንዳለበት ልብ ይበሉ ፡፡እሱ በተለምዶ በበርካታ ስልቶች በኩል ያንን ያጠቃልላል ፣ ግን በዚህ አልተገደበም ፡፡
    //
    // * /proc/self/exe በሚደገፉ መድረኮች ላይ
    // * ሁኔታ በሚፈጥሩበት ጊዜ የፋይል ስሙ በግልጽ ተላል passedል
    //
    // የ libbacktrace ቤተ-መጽሐፍት ትልቅ የ‹ሲ›ኮድ ነው ፡፡ይህ በተፈጥሮ የማስታወስ ደህንነት ተጋላጭነቶች አግኝቷል ማለት ነው ፣ በተለይም የተሳሳተ የተሳሳተ debuginfo ን በሚይዙበት ጊዜ ፡፡
    // ሊብስትድ እነዚህን በታሪክ ውስጥ በብዛት አግኝቷል ፡፡
    //
    // /proc/self/exe ጥቅም ላይ ከዋለ ታዲያ የ libbacktrace "mostly correct" ነው ብለን መገመት እንችላለን ፣ እና ካልሆነ ግን በ "attempted to be correct" ድንክ ማረም መረጃ ያልተለመዱ ነገሮችን አያደርግም ፡፡
    //
    //
    // በፋይሉ ስም ውስጥ ካለፍን ግን በአንዳንድ መድረኮች ላይ (እንደ ቢ.ኤስ.ዲ.ኤስ.) ተንኮል አዘል ተዋንያን የዘፈቀደ ፋይል በዚያ ቦታ እንዲቀመጥ የሚያደርግበት ሁኔታ ሊኖር ይችላል ፡፡
    // ይህ ማለት ስለ ፋይል ስም ለ libbacktrace የምንነግር ከሆነ የዘፈቀደ ፋይልን በመጠቀም ሊሆን ይችላል ፣ ምናልባትም ሴግሎችን ያስከትላል ፡፡
    // ለ libbacktrace ምንም ነገር ካልነገርን ግን እንደ /proc/self/exe ያሉ ዱካዎችን በማይደግፉ መድረኮች ላይ ምንም አያደርግም!
    //
    // በፋይል ስም *ላለማለፍ* በተቻለ መጠን የተቻለንን ሁሉ ስንመለከት ግን /proc/self/exe ን በጭራሽ በማይደግፉ መድረኮች ላይ መሆን አለብን ፡፡
    //
    //
    //
    //
    //
    //
    //
    //
    cfg_if::cfg_if! {
        if #[cfg(any(target_os = "macos", target_os = "ios"))] {
            // በጥሩ ሁኔታ `std::env::current_exe` ን እንደምንጠቀም ልብ ይበሉ ፣ ግን እዚህ `std` ን አንፈልግም ፡፡
            //
            // የአሁኑን ሊሠራ የሚችል መንገድ ወደ የማይንቀሳቀስ አከባቢ ለመጫን `_NSGetExecutablePath` ን ይጠቀሙ (በጣም ትንሽ ከሆነ ብቻ ይተው)።
            //
            //
            // በሙስና አስፈፃሚዎች ላይ ላለመሞት እዚህ ላይ የ libbacktrace ን በጥብቅ እንደምናምን ልብ ይበሉ ፣ ግን በእርግጥ ያደርገዋል ...
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                const N: usize = 256;
                static mut BUF: [u8; N] = [0; N];
                extern {
                    fn _NSGetExecutablePath(
                        buf: *mut libc::c_char,
                        bufsize: *mut u32,
                    ) -> libc::c_int;
                }
                let mut sz: u32 = BUF.len() as u32;
                let ptr = BUF.as_mut_ptr() as *mut libc::c_char;
                if _NSGetExecutablePath(ptr, &mut sz) == 0 {
                    ptr
                } else {
                    ptr::null()
                }
            }
        } else if #[cfg(windows)] {
            use crate::windows::*;

            // Windows ከተከፈተ በኋላ መሰረዝ የማይችልበት የመክፈቻ ዘዴ አለው ፡፡
            // ያ በአጠቃላይ እኛ እዚህ የምንፈልገው ነው ምክንያቱም እኛ የምንሰራው ስራችን ወደ libbacktrace ከሰጠነው በኋላ የእኛ ተፈፃሚነት ከእኛ በታች እንዳይለወጥ ማረጋገጥ እንፈልጋለን ፣ እናም በዘፈቀደ መረጃ ወደ libbacktrace የማለፍ ችሎታን በመቀነስ (ምናልባትም የተሳሳተ ሊሆን ይችላል) ፡፡
            //
            //
            // እኛ በራሳችን ምስል ላይ አንድ ዓይነት መቆለፊያ ለማግኘት ለመሞከር እዚህ ጥቂት ጭፈራዎች እናደርጋለን ፡፡
            //
            // * ለአሁኑ ሂደት አንድ እጀታ ያግኙ ፣ የፋይል ስሙን ይጫኑ ፡፡
            // * ከቀኝ ባንዲራዎች ጋር ለዚያ የፋይል ስም ፋይል ይክፈቱ።
            // * ያው መሆኑን ያረጋግጡ የአሁኑን የፋይል ስም እንደገና ይጫኑ
            //
            // ያ ሁሉ የሚያልፍ ከሆነ እኛ በእውነተኛ ደረጃ የሂደታችንን ፋይል ከፍተናል እናም እንደማይለወጥ ዋስትና ተሰጥቶናል ፡፡FWIW የዚህ ስብስብ ከ libstd በታሪክ ይገለበጣል ፣ ስለሆነም ይህ ስለተከናወነው የእኔ ምርጥ ትርጓሜ ነው ፡፡
            //
            //
            //
            //
            //
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                load_filename_opt().unwrap_or(ptr::null())
            }

            unsafe fn load_filename_opt() -> Result<*const libc::c_char, ()> {
                const N: usize = 256;
                // እኛ መመለስ ይችላሉ, ስለዚህ ይህ የማይንቀሳቀስ ትውስታ ውስጥ ይኖራል ..
                static mut BUF: [i8; N] = [0; N];
                // ... እና ቁልል ላይ ይህን ሕይወት ይህ ጊዜያዊ ነው ጀምሮ
                let mut stack_buf = [0; N];
                let name1 = query_full_name(&mut BUF)?;

                let handle = CreateFileA(
                    name1.as_ptr(),
                    GENERIC_READ,
                    FILE_SHARE_READ | FILE_SHARE_WRITE,
                    ptr::null_mut(),
                    OPEN_EXISTING,
                    0,
                    ptr::null_mut(),
                );
                if handle.is_null() {
                    return Err(());
                }

                let name2 = query_full_name(&mut stack_buf)?;
                if name1 != name2 {
                    CloseHandle(handle);
                    return Err(())
                }
                // ይህ ክፍት ያለው ይህ ፋይል ስም ላይ ያለን መቆለፊያ ጠብቆ ይገባል ምክንያቱም ሆን እዚህ `handle` አያሳልፍም.
                //
                Ok(name1.as_ptr())
            }

            unsafe fn query_full_name(buf: &mut [i8]) -> Result<&[i8], ()> {
                let dll = GetModuleHandleA(b"kernel32.dll\0".as_ptr() as *const i8);
                if dll.is_null() {
                    return Err(())
                }
                let ptrQueryFullProcessImageNameA =
                    GetProcAddress(dll, b"QueryFullProcessImageNameA\0".as_ptr() as *const _) as usize;
                if ptrQueryFullProcessImageNameA == 0
                {
                    return Err(());
                }
                use core::mem;
                let p1 = OpenProcess(PROCESS_QUERY_INFORMATION, FALSE, GetCurrentProcessId());
                let mut len = buf.len() as u32;
                let pfnQueryFullProcessImageNameA : extern "system" fn(
                    hProcess: HANDLE,
                    dwFlags: DWORD,
                    lpExeName: LPSTR,
                    lpdwSize: PDWORD,
                ) -> BOOL = mem::transmute(ptrQueryFullProcessImageNameA);

                let rc = pfnQueryFullProcessImageNameA(p1, 0, buf.as_mut_ptr(), &mut len);
                CloseHandle(p1);

                // ኑል የተቋረጠውን ቁርጥራጭ መመለስ እንፈልጋለን ፣ ስለዚህ ሁሉም ነገር ተሞልቶ ከሆነ እና ከጠቅላላው ርዝመት ጋር እኩል ከሆነ ከዚያ ያንን ከመውደቅ ጋር ያመሳስላል።
                //
                //
                // አለበለዚያ እርግጠኛ nul ባይት ወደ ቁራጭ ውስጥ የተካተተ ነው የተሳካ እንዲሆን ሲመለሱ.
                //
                //
                if rc == 0 || len == buf.len() as u32 {
                    Err(())
                } else {
                    assert_eq!(buf[len as usize], 0);
                    Ok(&buf[..(len + 1) as usize])
                }
            }
        } else if #[cfg(target_os = "vxworks")] {
            unsafe fn load_filename() -> *const libc::c_char {
                use libc;
                use core::mem;

                const N: usize = libc::VX_RTP_NAME_LENGTH as usize + 1;
                static mut BUF: [libc::c_char; N] = [0; N];

                let mut rtp_desc : libc::RTP_DESC = mem::zeroed();
                if (libc::rtpInfoGet(0, &mut rtp_desc as *mut libc::RTP_DESC) == 0) {
                    BUF.copy_from_slice(&rtp_desc.pathName);
                    BUF.as_ptr()
                } else {
                    ptr::null()
                }
            }
        } else {
            unsafe fn load_filename() -> *const libc::c_char {
                ptr::null()
            }
        }
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let symaddr = what.address_or_ip() as usize;

    // የኋላ ስህተቶች በአሁኑ ጊዜ ምንጣፍ ስር ተጠርገዋል
    let state = init_state();
    if state.is_null() {
        return;
    }

    // ለ `backtrace_syminfo` ኤ.ፒ.አይ ይደውሉ (ኮዱን ከማንበብ) ወደ `syminfo_cb` በትክክል አንዴ ሊደውልለት (ወይም ምናልባት በግምት በስህተት ካልተሳካ) ፡፡
    // ከዚያ በ `syminfo_cb` ውስጥ የበለጠ እንይዛለን።
    //
    // `syminfo` ይህንን የምናደርገው በሁለትዮሽ ውስጥ ምንም የማረም መረጃ ባይኖርም የምልክት ስሞችን በማግኘት የምልክት ሰንጠረዥን ስለሚመለከት ነው ፡፡
    //
    //
    let mut syminfo_state = SyminfoState { pc: symaddr, cb };
    bt::backtrace_syminfo(
        state,
        symaddr as uintptr_t,
        syminfo_cb,
        error_cb,
        &mut syminfo_state as *mut _ as *mut _,
    );
}

pub unsafe fn clear_symbol_cache() {}