use core::{fmt, str};

cfg_if::cfg_if! {
    if #[cfg(feature = "std")] {
        use std::path::Path;
        use std::prelude::v1::*;
    }
}

use super::backtrace::Frame;
use super::types::BytesOrWideString;
use core::ffi::c_void;
use rustc_demangle::{try_demangle, Demangle};

/// ምልክቱን ወደተጠቀሰው መዘጋት በማስተላለፍ አድራሻውን ወደ አንድ ምልክት ይፍቱ ፡፡
///
/// ይህ ተግባር ማስገዛት ምልክቶችን ለማግኘት እንደ የአካባቢው ምልክት ጠረጴዛ, ተለዋዋጭ ምልክት ጠረጴዛ, ወይም (የተገበሩ ትግበራ ላይ የሚወሰን) ድንክ ማረሚያ መረጃ እንደ አካባቢዎች ውስጥ በተሰጠው አድራሻ ይመለከታል.
///
///
/// መፍታት ካልተቻለ መዘጋቱ ሊጠራ አይችልም ፣ እንዲሁም በተዘረዘሩት ተግባራት ውስጥም ከአንድ ጊዜ በላይ ሊጠራ ይችላል ፡፡
///
/// የተሰጡት ምልክቶች በተጠቀሰው `addr` ላይ አፈፃፀሙን ይወክላሉ ፣ ለዚያ አድራሻ የ file/line ጥንዶችን ይመልሳሉ (ካለ) ፡፡
///
/// ከዚያም አንድ `Frame` አለን ከሆነ ይመከራል መሆኑን ማስታወሻ ይህ ሰው ይልቅ `resolve_frame` ተግባር መጠቀም.
///
/// # አስፈላጊ ባህሪዎች
///
/// ይህ ተግባር የ `backtrace` crate የ `std` ባህሪው እንዲነቃ ይፈልጋል ፣ እና የ `std` ባህሪው በነባሪነት ነቅቷል።
///
/// # Panics
///
/// ይህ ተግባር በጭራሽ panic ን ለማድረግ ይጥራል ፣ ግን `cb` panics ን ከሰጠ ከዚያ አንዳንድ መድረኮች ሂደቱን ለማቋረጥ ሁለት እጥፍ panic ያስገድዳሉ።
/// አንዳንድ መድረኮች በውስጥ በኩል ሊፈጠሩ የማይችሉ የጥሪ መልሶችን በውስጣቸው የሚጠቀመውን C ቤተ-መጻሕፍት ይጠቀማሉ ፣ ስለሆነም ከ `cb` መፍራት የሂደቱን ፅንስ ማስወረድ ሊያስነሳ ይችላል ፡፡
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         let ip = frame.ip();
///
///         backtrace::resolve(ip, |symbol| {
///             // ...
///         });
///
///         false // የላይኛው ክፈፉን ብቻ ይመልከቱ
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve<F: FnMut(&Symbol)>(addr: *mut c_void, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_unsynchronized(addr, cb) }
}

/// ቀደም ሲል በተጠቀሱት መዘጋት ወደ ምልክት በማለፍ, ምልክት ወደ ፍሬም መቅረጽ ይፍቱ.
///
/// ይህ ፋክትቲን ከአድራሻ ይልቅ `Frame` ን እንደ ክርክር ከሚወስድ በስተቀር እንደ `resolve` ተመሳሳይ ተግባር ያከናውናል ፡፡
/// ይህ backtracing አንዳንድ መድረክ አፈጻጸም ለምሳሌ የመስመር ፍሬሞች የበለጠ ትክክለኛ ምልክት መረጃ ወይም መረጃ መስጠት መፍቀድ ይችላሉ.
///
/// ከቻሉ ይህንን እንዲጠቀሙ ይመከራል ፡፡
///
/// # አስፈላጊ ባህሪዎች
///
/// ይህ ተግባር የ `backtrace` crate የ `std` ባህሪው እንዲነቃ ይፈልጋል ፣ እና የ `std` ባህሪው በነባሪነት ነቅቷል።
///
/// # Panics
///
/// ይህ ተግባር በጭራሽ panic ን ለማድረግ ይጥራል ፣ ግን `cb` panics ን ከሰጠ ከዚያ አንዳንድ መድረኮች ሂደቱን ለማቋረጥ ሁለት እጥፍ panic ያስገድዳሉ።
/// አንዳንድ መድረኮች በውስጥ በኩል ሊፈጠሩ የማይችሉ የጥሪ መልሶችን በውስጣቸው የሚጠቀመውን C ቤተ-መጻሕፍት ይጠቀማሉ ፣ ስለሆነም ከ `cb` መፍራት የሂደቱን ፅንስ ማስወረድ ሊያስነሳ ይችላል ፡፡
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         backtrace::resolve_frame(frame, |symbol| {
///             // ...
///         });
///
///         false // የላይኛው ክፈፉን ብቻ ይመልከቱ
///     });
/// }
/// ```
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve_frame<F: FnMut(&Symbol)>(frame: &Frame, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_frame_unsynchronized(frame, cb) }
}

pub enum ResolveWhat<'a> {
    Address(*mut c_void),
    Frame(&'a Frame),
}

impl<'a> ResolveWhat<'a> {
    #[allow(dead_code)]
    fn address_or_ip(&self) -> *mut c_void {
        match self {
            ResolveWhat::Address(a) => adjust_ip(*a),
            ResolveWhat::Frame(f) => adjust_ip(f.ip()),
        }
    }
}

// ቁልል ፍሬሞች ከ ፒ እሴቶች ትክክለኛ ቁልል ነው የሚል ጥሪ *በኋላ* በተለምዶ መመሪያ (always?) ናቸው.
// ይህንን በምልክት ማድረጉ የ filename/line ቁጥሩ አንድ ወደ ፊት እንዲሄድ እና ምናልባትም ወደ ሥራው መጨረሻ ላይ ከሆነ ወደ ባዶነት ያስከትላል ፡፡
//
// ይህ በመሠረቱ በሁሉም የመሣሪያ ስርዓቶች ላይ ሁልጊዜ የሚከሰት ይመስላል ፣ ስለሆነም መመሪያውን ከመመለስ ይልቅ ወደ ቀድሞው የጥሪ መመሪያ ለመፍታት አንድ ከተፈታ ip ላይ አንድ ጊዜ እንቀንሳለን።
//
//
// በሐሳብ ደረጃ እኛ ይህንን አናደርግም ነበር ፡፡
// በጥሩ ሁኔታ የ `resolve` ኤ.ፒ.አይ.ዎች ደዋዮች -1 ን በእጅ እንዲያደርጉ እና የአሁኑን ሳይሆን ለ *ቀዳሚው* መመሪያ የአካባቢ መረጃ እንደሚፈልጉ እንዲያስቀምጡ እንፈልጋለን ፡፡
// በእውነቱ እኛ የሚቀጥለው መመሪያ ወይም የአሁኑ አድራሻ ከሆንን በ `Frame` ላይም ቢሆን ማጋለጥ እንፈልጋለን።
//
// ለጊዜው ምንም እንኳን ይህ በጣም ጥሩ ትኩረት የሚስብ ጉዳይ ስለሆነ በውስጣችን ሁል ጊዜ አንዱን እንቀንሳለን ፡፡
// ሸማቾች መስራታቸውን እና ጥሩ ጥሩ ውጤቶችን ማግኘታቸውን መቀጠል አለባቸው ፣ ስለዚህ እኛ በቂ መሆን አለብን።
//
//
//
//
//
//
fn adjust_ip(a: *mut c_void) -> *mut c_void {
    if a.is_null() {
        a
    } else {
        (a as usize - 1) as *mut c_void
    }
}

/// ከ `resolve` ጋር ተመሳሳይ ፣ የማይመሳሰል ስለሆነ ደህንነቱ የተጠበቀ ብቻ።
///
/// ይህ ተግባር ማመሳሰል guarentees አላቸው ነገር ግን ይህ crate ውስጥ `std` ባህሪ የተጠናቀሩ አይደለም ሲገኝ ነው ማለት አይደለም.
/// ለተጨማሪ ሰነዶች እና ምሳሌዎች የ `resolve` ተግባርን ይመልከቱ።
///
/// # Panics
///
/// `cb` ሳልገባ ላይ caveats ለ `resolve` ላይ መረጃ ይመልከቱ.
///
pub unsafe fn resolve_unsynchronized<F>(addr: *mut c_void, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Address(addr), &mut cb)
}

/// ከ `resolve_frame` ጋር ተመሳሳይ ፣ የማይመሳሰል ስለሆነ ደህንነቱ የተጠበቀ ብቻ።
///
/// ይህ ተግባር ማመሳሰል guarentees አላቸው ነገር ግን ይህ crate ውስጥ `std` ባህሪ የተጠናቀሩ አይደለም ሲገኝ ነው ማለት አይደለም.
/// ተጨማሪ ሰነድ እና ምሳሌዎችን ለማግኘት `resolve_frame` ተግባር ይመልከቱ.
///
/// # Panics
///
/// በ `cb` መፍራት ላይ ለሚገኙ ማስጠንቀቂያዎች በ `resolve_frame` ላይ መረጃ ይመልከቱ።
///
pub unsafe fn resolve_frame_unsynchronized<F>(frame: &Frame, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Frame(frame), &mut cb)
}

/// በፋይሉ ውስጥ የአንድ ምልክት ጥራት የሚወክል አንድ trait
///
/// ይህ trait ለ‹XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXUUZZUZZI እንደ እንደ ተሰጠው እና ከጀርባው የትኛው አተገባበር እንዳለ ስለማያውቅ በትክክል ይላካል ፡፡
///
///
/// አንድ ምልክት ወዘተ ዐውደ ተግባር በተመለከተ መረጃ, ለምሳሌ ስም, ፋይል ስም, መስመር ቁጥር, ትክክለኛ አድራሻ, መስጠት ይችላሉ
/// ሁሉም መረጃዎች ሁልጊዜ በምልክት ውስጥ አይገኙም ፣ ሆኖም ግን ፣ ስለዚህ ሁሉም ዘዴዎች `Option` ን ይመልሳሉ።
///
///
pub struct Symbol {
    // TODO: ይህ የሕይወት ዘመን ውሎ አድሮ እስከ `Symbol` ድረስ መታገስ አለበት ፣
    // ግን ያ አሁን ሰበር ለውጥ ነው ፡፡
    // `Symbol` በጭራሽ በማጣቀሻ ብቻ ስለሚሰጥ እና አሁን ሊደለል ስለማይችል ይህ አሁን ደህንነቱ የተጠበቀ ነው ፡፡
    inner: imp::Symbol<'static>,
}

impl Symbol {
    /// የዚህን ተግባር ስም ይመልሳል።
    ///
    /// የተመለሰው መዋቅር ስለ ምልክት ስም የተለያዩ ንብረቶችን ለመጠየቅ ሊያገለግል ይችላል-
    ///
    ///
    /// * የ `Display` ትግበራ የተጠላለፈውን ምልክት ያትማል ፡፡
    /// * የምልክቱ ጥሬ የ `str` እሴት ሊደረስበት ይችላል (ትክክለኛ utf-8 ከሆነ)።
    /// * ለምልክት ስም ጥሬ ባይት መድረስ ይቻላል ፡፡
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.inner.name()
    }

    /// የዚህን ተግባር መነሻ አድራሻ ይመልሳል።
    pub fn addr(&self) -> Option<*mut c_void> {
        self.inner.addr().map(|p| p as *mut _)
    }

    /// ጥሬ የፋይል ስሙን እንደ ቁርጥራጭ ይመልሳል።
    /// ይህ በዋናነት ለ `no_std` አካባቢዎች ጠቃሚ ነው ፡፡
    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.inner.filename_raw()
    }

    /// ይህ ምልክት በአሁኑ መፈጸም ነው የት ለ የአምድ ቁጥር ይመልሳል.
    ///
    /// በአሁኑ ጊዜ ዋጋ ያለው እዚህ ብቻ ነው ፣ እና ከዚያ እንኳን `filename` `Some` ን ከመለሰ ብቻ የሚሰጥ ፣ እና ስለሆነም በተመሳሳይ ተመሳሳይ ማስጠንቀቂያዎች ተገዢ ነው።
    ///
    pub fn colno(&self) -> Option<u32> {
        self.inner.colno()
    }

    /// ይህ ምልክት በአሁኑ መፈጸም ነው የት የመስመር ቁጥር ይመልሳል.
    ///
    /// `filename` `Some` ን ከመለሰ ይህ የመመለሻ ዋጋ በተለምዶ `Some` ነው እናም ስለሆነም ለተመሳሳይ ማስጠንቀቂያዎች ተገዢ ነው።
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.inner.lineno()
    }

    /// ይህ ተግባር የተገለጸበትን የፋይል ስም ይመልሳል።
    ///
    /// ይህ በአሁኑ ጊዜ ሊብስተር ትራክት ወይም ጂሚሊ ጥቅም ላይ ሲውል ብቻ ነው (ለምሳሌ
    /// unix ሌሎች የመሣሪያ ስርዓቶች) እና ሁለትዮሽ ከ debuginfo ጋር ሲደመር።
    /// ከእነዚህ ሁኔታዎች ውስጥ አንዳቸውም ካልተሟሉ ይህ ምናልባት `None` ን ይመለሳል።
    ///
    /// # አስፈላጊ ባህሪዎች
    ///
    /// ይህ ተግባር የ `backtrace` crate የ `std` ባህሪው እንዲነቃ ይፈልጋል ፣ እና የ `std` ባህሪው በነባሪነት ነቅቷል።
    ///
    ///
    #[cfg(feature = "std")]
    #[allow(unreachable_code)]
    pub fn filename(&self) -> Option<&Path> {
        self.inner.filename()
    }
}

impl fmt::Debug for Symbol {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let mut d = f.debug_struct("Symbol");
        if let Some(name) = self.name() {
            d.field("name", &name);
        }
        if let Some(addr) = self.addr() {
            d.field("addr", &addr);
        }

        #[cfg(feature = "std")]
        {
            if let Some(filename) = self.filename() {
                d.field("filename", &filename);
            }
        }

        if let Some(lineno) = self.lineno() {
            d.field("lineno", &lineno);
        }
        d.finish()
    }
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        // ምናልባት አንድ ሊተነተን ሲ ++ ምልክት, Rust አልተሳካም እንደ mangled ምልክት በመተንተን ከሆነ.
        //
        struct OptionCppSymbol<'a>(Option<::cpp_demangle::BorrowedSymbol<'a>>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(input: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(::cpp_demangle::BorrowedSymbol::new(input).ok())
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(None)
            }
        }
    } else {
        use core::marker::PhantomData;

        // የ `cpp_demangle` ባህሪው ሲሰናከል ምንም ወጪ እንዳይኖረው ፣ ይህንን ዜሮ መጠን መያዙን ያረጋግጡ።
        //
        struct OptionCppSymbol<'a>(PhantomData<&'a ()>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(_: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }
        }
    }
}

/// ለተጠቂው ስም ፣ ጥሬ ባይት ፣ ጥሬ ገመድ ፣ ወዘተ ergonomic ተደራሽዎችን ለማቅረብ በምልክት ስም መጠቅለያ ፡፡
///
// የ `cpp_demangle` ባህሪው ባልነቃበት ጊዜ የሞተውን ኮድ ይፍቀዱ።
#[allow(dead_code)]
pub struct SymbolName<'a> {
    bytes: &'a [u8],
    demangled: Option<Demangle<'a>>,
    cpp_demangled: OptionCppSymbol<'a>,
}

impl<'a> SymbolName<'a> {
    /// ከጥሬው በታች ባይት አዲስ የምልክት ስም ይፈጥራል።
    pub fn new(bytes: &'a [u8]) -> SymbolName<'a> {
        let str_bytes = str::from_utf8(bytes).ok();
        let demangled = str_bytes.and_then(|s| try_demangle(s).ok());

        let cpp = if demangled.is_none() {
            OptionCppSymbol::parse(bytes)
        } else {
            OptionCppSymbol::none()
        };

        SymbolName {
            bytes: bytes,
            demangled: demangled,
            cpp_demangled: cpp,
        }
    }

    /// ምልክቱ የሚሰራ utf-8 ከሆነ ጥሬ የ (mangled) ምልክት ስም እንደ `str` ይመልሳል።
    ///
    /// የተጠላለፈውን ስሪት ከፈለጉ የ `Display` አተገባበሩን ይጠቀሙ።
    pub fn as_str(&self) -> Option<&'a str> {
        self.demangled
            .as_ref()
            .map(|s| s.as_str())
            .or_else(|| str::from_utf8(self.bytes).ok())
    }

    /// ባይት ዝርዝር እንደ ጥሬ ምልክት ስም ይመልሳል
    pub fn as_bytes(&self) -> &'a [u8] {
        self.bytes
    }
}

fn format_symbol_name(
    fmt: fn(&str, &mut fmt::Formatter<'_>) -> fmt::Result,
    mut bytes: &[u8],
    f: &mut fmt::Formatter<'_>,
) -> fmt::Result {
    while bytes.len() > 0 {
        match str::from_utf8(bytes) {
            Ok(name) => {
                fmt(name, f)?;
                break;
            }
            Err(err) => {
                fmt("\u{FFFD}", f)?;

                match err.error_len() {
                    Some(len) => bytes = &bytes[err.valid_up_to() + len..],
                    None => break,
                }
            }
        }
    }
    Ok(())
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else if let Some(ref cpp) = self.cpp_demangled.0 {
                    cpp.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    } else {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    }
}

cfg_if::cfg_if! {
    if #[cfg(all(feature = "std", feature = "cpp_demangle"))] {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                use std::fmt::Write;

                if let Some(ref s) = self.demangled {
                    return s.fmt(f)
                }

                // ይህ demangled ምልክት በእርግጥ ትክክል አይደለም ከሆነ ማተም, ስለዚህ outwards ይህ እንዲባዙ አይደለም በማድረግ ማራኪ እዚህ ላይ ስህተት ለማስተናገድ ይችላል.
                //
                //
                if let Some(ref cpp) = self.cpp_demangled.0 {
                    let mut s = String::new();
                    if write!(s, "{}", cpp).is_ok() {
                        return s.fmt(f)
                    }
                }

                format_symbol_name(fmt::Debug::fmt, self.bytes, f)
            }
        }
    } else {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Debug::fmt, self.bytes, f)
                }
            }
        }
    }
}

/// አድራሻዎችን በምሳሌ ለማስረዳት ያንን የተሸጎጠ ማህደረ ትውስታ ለማስመለስ ሙከራ ፡፡
///
/// ይህ ዘዴ በዓለም አቀፍ ደረጃ የተሸጎጡ ወይም በተለምዶ የተተነተነ DWARF መረጃን ወይም ተመሳሳይን በሚወክል ክር ውስጥ የሚገኙ ማንኛውንም ዓለም አቀፋዊ የመረጃ መዋቅሮችን ለመልቀቅ ይሞክራል።
///
///
/// # Caveats
///
/// ይህ ተግባር ሁልጊዜ ይገኛል ቢሆንም ይህ በእርግጥ በጣም ማስፈጸሚያዎች ላይ ምንም ነገር ማድረግ አይደለም.
/// እንደ dbghelp ወይም libbacktrace ያሉ ቤተ-መጻህፍት ግዛትን ለማከፋፈል እና የተመደበውን ማህደረ ትውስታ ለማስተዳደር የሚያስችሉ ተቋማትን አያቀርቡም ፡፡
/// አሁን በዚህ crate ውስጥ `gimli-symbolize` ባህሪ በዚህ ተግባር ማንኛውም ተጽዕኖ ያለው ቦታ ብቻ ባህሪ ነው.
///
///
///
#[cfg(feature = "std")]
pub fn clear_symbol_cache() {
    let _guard = crate::lock::lock();
    unsafe {
        imp::clear_symbol_cache();
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        mod miri;
        use miri as imp;
    } else if #[cfg(all(windows, target_env = "msvc", not(target_vendor = "uwp")))] {
        mod dbghelp;
        use dbghelp as imp;
    } else if #[cfg(all(
        feature = "libbacktrace",
        any(unix, all(windows, not(target_vendor = "uwp"), target_env = "gnu")),
        not(target_os = "fuchsia"),
        not(target_os = "emscripten"),
        not(target_env = "uclibc"),
        not(target_env = "libnx"),
    ))] {
        mod libbacktrace;
        use libbacktrace as imp;
    } else if #[cfg(all(
        feature = "gimli-symbolize",
        any(unix, windows),
        not(target_vendor = "uwp"),
        not(target_os = "emscripten"),
    ))] {
        mod gimli;
        use gimli as imp;
    } else {
        mod noop;
        use noop as imp;
    }
}