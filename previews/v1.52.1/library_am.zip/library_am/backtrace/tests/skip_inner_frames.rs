use backtrace::Backtrace;

// ይህ ሙከራ የሚሠራው የምልክት መነሻ አድራሻውን ሪፖርት በሚያደርጉ ክፈፎች ላይ የሚሰራ የ `symbol_address` ተግባር ባላቸው መድረኮች ላይ ብቻ ነው።
// በዚህ ምክንያት በጥቂት መድረኮች ላይ ብቻ ነቅቷል።
//
const ENABLED: bool = cfg!(all(
    // Windows በእውነቱ አልተሞከረም ፣ እና OSX በእውነቱ የተከለለ ክፈፍ መፈለግን አይደግፍም ፣ ስለዚህ ይህንን ያሰናክሉ
    //
    target_os = "linux",
    // በ‹ARM›ላይ የመከለል ተግባርን በመፈለግ ላይ ip ን በራሱ ይመልሳል ፡፡
    not(target_arch = "arm"),
));

#[test]
fn backtrace_new_unresolved_should_start_with_call_site_trace() {
    if !ENABLED {
        return;
    }
    let mut b = Backtrace::new_unresolved();
    b.resolve();
    println!("{:?}", b);

    assert!(!b.frames().is_empty());

    let this_ip = backtrace_new_unresolved_should_start_with_call_site_trace as usize;
    println!("this_ip: {:?}", this_ip as *const usize);
    let frame_ip = b.frames().first().unwrap().symbol_address() as usize;
    assert_eq!(this_ip, frame_ip);
}

#[test]
fn backtrace_new_should_start_with_call_site_trace() {
    if !ENABLED {
        return;
    }
    let b = Backtrace::new();
    println!("{:?}", b);

    assert!(!b.frames().is_empty());

    let this_ip = backtrace_new_should_start_with_call_site_trace as usize;
    let frame_ip = b.frames().first().unwrap().symbol_address() as usize;
    assert_eq!(this_ip, frame_ip);
}