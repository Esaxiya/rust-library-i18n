# ለስታራክቸር አስተዋፅዖ ማድረግ

የ `stdarch` crate አስተዋጽኦች ለመቀበል በላይ ፈቃደኛ ነው!በመጀመሪያ እርስዎ ምናልባት ማከማቻ ይመልከቱ ይፈልጋሉ ያገኛሉ እና ፈተናዎች ለእናንተ ማለፍ መሆኑን ያረጋግጡ:

```
$ git clone https://github.com/rust-lang/stdarch
$ cd stdarch
$ TARGET="<your-target-arch>" ci/run.sh
```

`<your-target-arch>` (በማንኛውም ባለፈው `nightly-` ወይም ተመሳሳይ ያለ) ሶስቴ እንደ `rustup` የተጠቀመበት ዒላማ, ለምሳሌ `x86_x64-unknown-linux-gnu` ነው የት ነው.
እንዲሁም ይህ ማከማቻ የ Rust የሌሊት ሰርጥ እንደሚያስፈልገው ያስታውሱ!
ከላይ ያሉት ሙከራዎች በእውነቱ `rustup default nightly` ን (እና ለመመለስ `rustup default stable` ን) ለማዘጋጀት በስርዓትዎ ላይ ነባሪ እንዲሆን በየምሽቱ rust ን ይፈልጋሉ ፡፡

ከላይ እርምጃዎች ውስጥ ማናቸውም ካልሰሩ, [please let us know][new]!

ቀጥሎ [find an issue][issues] ላይ ለመርዳት የሚችለው እስከ እኛም በተለይ አንዳንድ እርዳታ መጠቀም ይችላል ይህም [`help wanted`][help] እና [`impl-period`][impl] መለያዎች ጋር ጥቂት መርጠዋል. 
አንተ በጣም x86 ላይ ሁሉንም አቅራቢ intrinsics በመተግበር, [#40][vendor] ሊፈልጉት ይችላሉ.ይህ ጉዳይ ዎቹ ለመጀመር የት ስለ አንዳንድ ጥሩ ዘዴውን አግኝቷል!

አጠቃላይ ጥያቄዎች ካሉዎት ለ [join us on gitter][gitter] ነፃነት ይሰማዎት እና ዙሪያውን ይጠይቁ!ጥያቄዎች ጋር ፒንግ ወይ@BurntSushi ወይም@alexcrichton ነፃ ይሰማቸዋል.

[gitter]: https://gitter.im/rust-impl-period/WG-libs-simd

# stdarch intrinsics ምሳሌዎችን መጻፍ እንደሚቻል

ለተጠቀሰው ውስጣዊ ሁኔታ በትክክል እንዲሠራ መንቃት ያለባቸው ጥቂት ባህሪዎች አሉ እና ምሳሌው በ‹XXXX›መከናወን ያለበት ባህሪው በሲፒዩ ሲደገፍ ብቻ ነው ፡፡

በዚህ ምክንያት በ `rustdoc` የተፈጠረው ነባሪ `fn main` አይሰራም (በአብዛኛዎቹ ጉዳዮች)።
የሚጠበቅ እንደ ምሳሌ ሥራ ለማረጋገጥ እንደ መመሪያ የሚከተለውን በመጠቀም እንመልከት.

```rust
/// # // እኛም ምሳሌ ብቻ ነው ለማረጋገጥ cfg_target_feature ያስፈልገዋል
/// # // የ ሲፒዩ ባህሪ የሚደግፍ ጊዜ `cargo test --doc` የሚካሄድ
/// # #![feature(cfg_target_feature)]
/// # // እኛ ስራ ወደ ነጥሎ ለ target_feature ያስፈልገዋል
/// # #![feature(target_feature)]
/// #
/// # // በነባሪነት rustdoc `extern crate stdarch` ይጠቀማል, ነገር ግን እኛ ያስፈልገናል
/// # // `#[macro_use]`
/// # # [macro_use] extern crate stdarch;
/// #
/// # // እውነተኛው ዋና ተግባር
/// # fn main() {
/// #     // `<target feature>` የሚደገፍ ከሆነ ብቻ ይህን አሂድ
/// #     cfg_fe ባህሪ_ ከነቃ! ("<target feature>"){
/// #         // ብቻ ዒላማ ባህሪ ከሆነ አሂድ ይሆናል አንድ `worker` ተግባር ፍጠር
/// #         // የሚደገፉ እና `target_feature` የ ሰራተኛ ነቅቷል መሆኑን ማረጋገጥ ነው
/// #         // function
/// #         #[target_feature(enable = "<target feature>")]
/// #         ያልተጠበቀ fn worker() {
/// // ምሳሌዎን እዚህ ይፃፉ ፡፡የባህሪ ልዩ ውስጣዊ ነገሮች እዚህ ይሰራሉ!ወደ ዱር ይሂዱ!
///
/// #         }
///
/// #         ደህንነቱ ያልተጠበቀ { worker(); }
/// #     }
/// # }
```

ከላይ ከተዘረዘሩት አገባብ መካከል የተወሰኑት የማይመስሉ ከሆነ የ [Rust Book] የ [Documentation as tests] ክፍል የ `rustdoc` አገባብን በጥሩ ሁኔታ ይገልጻል ፡፡
እንደተለመደው ፣ ለ‹[join us on gitter][gitter]›ነፃነት ይሰማዎት እና ማንኛውንም ንክሻዎችን ይምቱ እንደሆነ ይጠይቁ እና የ `stdarch` ሰነዶችን ለማሻሻል ስለረዱዎት እናመሰግናለን!

# አማራጭ ሙከራ መመሪያዎች

ሙከራዎችን ለማካሄድ በአጠቃላይ `ci/run.sh` ን እንዲጠቀሙ ይመከራል ፡፡
ሆኖም ይህ ለእርስዎ ላይሠራ ይችላል ፣ ለምሳሌ Windows ላይ ከሆኑ ፡፡

ያ ከሆነ የኮዱን ማመንጨት ለመፈተሽ `cargo +nightly test` እና `cargo +nightly test --release -p core_arch` ን ወደሚያሄዱበት መመለስ ይችላሉ።
ልብ ይበሉ እነዚህ የምሽቱን የመሳሪያ ሰንሰለቶች እንዲጫኑ እና ለ `rustc` ስለ ዒላማዎ ሶስት እና ስለ ሲፒዩው እንዲያውቁ ይጠይቁ ፡፡
በተለይም ለ‹`ci/run.sh` X›እንደሚያደርጉት የ‹`TARGET`›አከባቢን ማቀናበር ያስፈልግዎታል ፡፡
በተጨማሪም እርስዎ ኢላማ ባህሪያት, ለምሳሌ ለማመላከት `RUSTCFLAGS` (አስፈላጊ የ `C`) ማዘጋጀት አለብዎት `RUSTCFLAGS="-C -target-features=+avx2"`.
እርስዎ "just" የአሁኑ ሲፒዩ ላይ በማደግ ላይ ከሆነ ደግሞ `-C -target-cpu=native` ማቀናበር ይችላሉ.

እነዚህን አማራጭ መመሪያዎች ሲጠቀሙ [things may go less smoothly than they would with `ci/run.sh`][ci-run-good] ለምሳሌ ማስጠንቀቂያ ይስጡ
የመመሪያ ትውልድ ሙከራዎች ሊከሽፉ ይችላሉ ምክንያቱም ቀራጩ በተለያየ ስም ስለሰየማቸው ፣ ለምሳሌ
እነሱን ተመሳሳይ ጠባይ ቢኖሩም `vaesenc` ይልቅ `aesenc` መመሪያዎችን ማመንጨት ይችላል.
በተጨማሪም እነዚህ መመሪያዎች ስለዚህ ውሎ አድሮ ጊዜ አንዳንድ ስህተቶች እዚህ ያልተሸፈኑ ፈተናዎች ለ ማሳየት ይችላል የዝርጋታ ለመጠየቅ እንደሆነ አትደነቁ አይደለም, በተለምዶ ሊደረግ ነበር ያነሰ ፈተናዎች ያስፈጽማል.

[new]: https://github.com/rust-lang/stdarch/issues/new
[issues]: https://github.com/rust-lang/stdarch/issues
[help]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3A%22help+wanted%22
[impl]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3Aimpl-period
[vendor]: https://github.com/rust-lang/stdarch/issues/40
[Documentation as tests]: https://doc.rust-lang.org/book/first-edition/documentation.html#documentation-as-tests
[Rust Book]: https://doc.rust-lang.org/book/first-edition
[ci-run-good]: https://github.com/rust-lang/stdarch/issues/931#issuecomment-711412126






