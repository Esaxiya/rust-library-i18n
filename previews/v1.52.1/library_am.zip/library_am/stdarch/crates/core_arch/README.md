`core::arch` - Rust ዎቹ ዋና መጽሐፍት መዋቅረ-ተኮር intrinsics
=======

[![core_arch_crate_badge]][core_arch_crate_link] [![core_arch_docs_badge]][core_arch_docs_link]

የ `core::arch` ሞጁል በሥነ-ሕንጻ ላይ ጥገኛ የሆኑ ውስጣዊ ነገሮችን (ለምሳሌ ሲምዲ) ይተገበራል።

# Usage 

`core::arch` የ `libcore` አካል ሆኖ የሚገኝ ሲሆን በ `libstd` እንደገና ይላካል ፡፡ከዚህ crate በኩል ይልቅ `core::arch` ወይም `std::arch` በኩል መጠቀም እመርጣለሁ.
ያልተረጋጋ ባህሪያት `feature(stdsimd)` በኩል በየምሽቱ Rust ውስጥ ብዙውን ይገኛሉ.

በዚህ crate በኩል `core::arch` ን በመጠቀም በየምሽቱ Rust ን ይፈልጋል ፣ እና ብዙ ጊዜ መሰባበር ይችላል (እና)።ይህን crate በኩል መጠቀም ግምት ውስጥ ይገባል ውስጥ ብቻ ሁኔታዎች ናቸው:

* እናንተ ያስፈልገናል ከሆነ በተለይ ዒላማ-ባህሪያት `libcore`/`libstd` አልነቁም ናቸው ከነቃ ጋር, ለምሳሌ `core::arch` ራስህን, ዳግም ይተነትናል.
Note: እናንተ ከፈለጉ መደበኛ ያልሆነ የዒላማ ለ ዳግም ያጠናቅራል, `xargo` እና መጠቀም ይመርጣሉ እባክዎ ዳግም-ማጠናቀር ተገቢ ሆኖ `libcore`/`libstd` ይልቅ ይህን crate በመጠቀም.
  
* ከተረጋጋ የ Rust ባህሪዎች በስተጀርባ እንኳ የማይገኙ አንዳንድ ባህሪያትን በመጠቀም።እኛ ቢያንስ እነዚህን ለማቆየት ይሞክሩ.
ከነዚህ ባህሪዎች ውስጥ የተወሰኑትን ለመጠቀም ከፈለጉ እባክዎን አንድ ጉዳይ ይክፈቱ እኛ በየምሽቱ Rust ውስጥ ልናጋልጣቸው እና ከዚያ እነሱን መጠቀም ይችላሉ ፡፡

# Documentation

* [Documentation - i686][i686]
* [Documentation - x86\_64][x86_64]
* [Documentation - arm][arm]
* [Documentation - aarch64][aarch64]
* [Documentation - powerpc][powerpc]
* [Documentation - powerpc64][powerpc64]
* [How to get started][contrib]
* [How to help implement intrinsics][help-implement]

[contrib]: https://github.com/rust-lang/stdarch/blob/master/CONTRIBUTING.md
[help-implement]: https://github.com/rust-lang/stdarch/issues/40
[i686]: https://rust-lang.github.io/stdarch/i686/core_arch/
[x86_64]: https://rust-lang.github.io/stdarch/x86_64/core_arch/
[arm]: https://rust-lang.github.io/stdarch/arm/core_arch/
[aarch64]: https://rust-lang.github.io/stdarch/aarch64/core_arch/
[powerpc]: https://rust-lang.github.io/stdarch/powerpc/core_arch/
[powerpc64]: https://rust-lang.github.io/stdarch/powerpc64/core_arch/

# License

`core_arch` በዋናነት በ MIT ፈቃድ እና በ Apache ፈቃድ (ሥሪት 2.0) ፣ በተለያዩ የቢ.ኤስ.ዲ.ኤስ መሰል ፈቃዶች በተሸፈኑ ክፍሎች ይሰራጫል ፡፡

ፍቃድ-APACHE, እና ዝርዝሮች ፈቃድ-MIT ተመልከት.

# Contribution

ከእናንተ በስተቀር በግልጽ ሁኔታ ካልሆነ, የ Apache-2.0 ፈቃድ ውስጥ ፍቺ እንደ ሆን, በእናንተ በኩል `core_arch` ውስጥ እንዲካተት ያስረከብከው ማንኛውም መዋጮ, ማናቸውም ተጨማሪ ውሎች ወይም ሁኔታዎች ያለ, ከላይ እንደ ፈቃድ ባለሁለት ይሆናል.


[core_arch_crate_badge]: https://img.shields.io/crates/v/core_arch.svg
[core_arch_crate_link]: https://crates.io/crates/core_arch
[core_arch_docs_badge]: https://docs.rs/core_arch/badge.svg
[core_arch_docs_link]: https://docs.rs/core_arch/












