//! AArch64 intrinsics.
//!
//! ኒዮን የ ማጣቀሻ [ARM's NEON Intrinsics Reference][arm_ref] ነው.
//! የ [ARM's NEON Intrinsics Online Database][arm_dat] በተጨማሪም ጠቃሚ ነው.
//!
//! [arm_ref]: http://infocenter.arm.com/help/topic/com.arm.doc.ihi0073a/IHI0073A_arm_neon_intrinsics_ref.pdf
//! [arm_dat]: https://developer.arm.com/technologies/neon/intrinsics

mod v8;
pub use self::v8::*;

mod neon;
pub use self::neon::*;

mod tme;
pub use self::tme::*;

mod crc;
pub use self::crc::*;

mod prefetch;
pub use self::prefetch::*;

pub use super::acle::*;

#[cfg(test)]
use stdarch_test::assert_instr;

/// ወጥመድ መመሪያ `BRK 1` ያመነጫል
#[cfg_attr(test, assert_instr(brk))]
#[inline]
pub unsafe fn brk() -> ! {
    crate::intrinsics::abort()
}

#[cfg(test)]
pub(crate) mod test_support;