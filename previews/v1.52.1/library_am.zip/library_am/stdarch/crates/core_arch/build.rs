use std::env;

fn main() {
    println!("cargo:rustc-cfg=core_arch_docs");

    // አንዳንዶች በአሁኑ ጊዜ በ `#[target_feature]` ውስጥ ምንም ተመሳሳይነት ከሌለው ተጨማሪ `-Ctarget-feature=+unimplemented-simd128` በስተጀርባ ስለሚገኙ ፣ ሁሉም ተመሳሳይ ቀለል ያሉ መሠረታዊ ሥርዓቶች ኮዴጌናቸውን ለመፈተሽ የሚገኙ መሆናቸውን ለ‹XXXX›ማብራሪያዎቻችን ለመናገር ጥቅም ላይ ይውላል ፡፡
    //
    //
    //
    println!("cargo:rerun-if-env-changed=RUSTFLAGS");
    if env::var("RUSTFLAGS")
        .unwrap_or_default()
        .contains("unimplemented-simd128")
    {
        println!("cargo:rustc-cfg=all_simd");
    }
}