//! Windows SEH
//!
//! (በአሁኑ ጊዜ ብቻ MSVC ላይ) Windows ላይ, ስልት አያያዝ ነባሪ በስተቀር (SEH) አያያዝ ለየት የተዋቀረ ነው.
//! LLVM SEH ተጨማሪ ድጋፍ ጥሩ ስምምነት ሊኖረው ያስፈልጋል ስለዚህ ይህ አጠናቃሪ ኢንተርናል አኳያ (ሌሎች unix መድረኮች የሚጠቀሙ ምን ለምሳሌ,) ድንክ የተመሠረተ የማይካተት ይልቅ ፈጽሞ የተለየ ነው.
//!
//! በአጭሩ, ነገር እዚህ ይከሰታል ነው:
//!
//! 1. የ የመተርተሩ ሂደት መጠቀማቸውን, ልዩ ያሉ-የ `panic` ተግባር አንድ ሲ ++ መወርወር ደረጃውን Windows ተግባር `_CxxThrowException` ይጠራዋል.
//! 2.
//! በ አጠናቃሪ የመነጨ ሁሉም ማረፊያ አበጥ ያለ ባሕርይ ተግባር `__CxxFrameHandler3`, ከ CRT ውስጥ አንድ ተግባር ለመጠቀም, እና Windows ውስጥ የመተርተሩ ኮድ ቁልል ላይ ሁሉ ጽዳት ኮድ ለማስፈጸም ይህንን ስብዕና ተግባር ይጠቀማሉ.
//!
//! 3. `invoke` ወደ ሁሉም አጠናቃሪ-የመነጩ ጥሪዎች በተከሰተበት ተዕለት መጀመሪያ ያመለክታል አንድ `cleanuppad` LLVM መመሪያ, እንደ አንድ ማረፊያ ሰሌዳ ስብስብ አለን.
//! (ከ CRT ላይ በተገለጸው ደረጃ 2,) ስብእና ጽዳት እለታዊ የሩጫ ኃላፊነት ነው.
//! 4. በመጨረሻም በ `try` ውስጣዊ (በአቀራባሪው የመነጨ) የ "catch" ኮድ ተፈፃሚ ሲሆን ቁጥጥር ወደ Rust ተመልሶ መምጣት እንዳለበት ያመላክታል ፡፡
//! ይህ `catchswitch` ሲደመር በመጨረሻም አንድ `catchret` መመሪያ ጋር ወደ ፕሮግራሙ መደበኛ ቁጥጥር በመመለስ LLVM ዒርሼሜሽ ውል ውስጥ `catchpad` መመሪያ, በኩል ነው የሚደረገው.
//!
//! የ gcc-የተመሰረተ የማይካተት አንዳንድ የተወሰኑ ልዩነቶች የሚከተሉት ናቸው:
//!
//! * Rust ምንም ብጁ ስብዕና ተግባር የለውም ፣ ይልቁንስ *ሁልጊዜ*`__CxxFrameHandler3` ነው።እኛ ዓይነት እኛ ሲሆኑ መወርወር እንደሚመስሉ ላይ ሊደርስ ማንኛውም ሲ ++ የማይካተቱ የምታጠምድ እስከ መጨረሻ እንዲሁ በተጨማሪም, ምንም ተጨማሪ ማጣራት, አይከናወንም.
//! ማስታወሻ Rust ወደ የሚፈቀድበት ጥሎ ያልተገለጸ ባህሪ ለማንኛውም ነው, ስለዚህ ይህ ጥሩ ሊሆን ይገባል.
//! * እኛ የመተርተሩ ወሰን, በተለይ አንድ `Box<dyn Any + Send>` በመላ የማስተላለፍ አንዳንድ ውሂብ አሉን.ድንክ የማይካተቱ ጋር እንደ እነዚህ ሁለት ዘዴውን በስተቀር በራሱ ውስጥ የክፍያ ሆነው ይከማቻሉ.
//! የማጣሪያ ተግባራት የተገደሉ ናቸው እያለ ጥሪ ቁልል ተጠብቆ ነው ምክንያቱም MSVC ላይ ይሁን, ተጨማሪ ቁልል ምደባ ምንም አስፈላጊ ነው.
//! ከዚያም ማጣሪያ ተግባር ውስጥ አስመለሰ ናቸው ያለውን ዘዴውን `_CxxThrowException` በቀጥታ አለፈ መሆኑን ይህ ማለት የ `try` ነጥሎ ውስጥ ከተተችው ክፈፍ ወደ የተጻፈው ዘንድ.
//!
//! [win64]: https://docs.microsoft.com/en-us/cpp/build/exception-handling-x64
//! [llvm]: http://llvm.org/docs/ExceptionHandling.html#background-on-windows-exceptions
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(nonstandard_style)]

use alloc::boxed::Box;
use core::any::Any;
use core::mem::{self, ManuallyDrop};
use libc::{c_int, c_uint, c_void};

struct Exception {
    // እኛ ማጣቀሻ በ በስተቀር ለመያዝ እና destructor በ C++ የሚፈጀውን ተገድሏል ነው; ምክንያቱም ይህ ፍላጎቶች አንድ አማራጭ ይሆናል.
    // እኛ በስተቀር ውጭ ሣጥን ለመውሰድ ጊዜ, ድርብ-በመጣል ወደ ሣጥን ያለ መሮጥ በውስጡ destructor ትክክለኛ ሁኔታ በስተቀር መተው ይኖርብናል.
    //
    //
    data: Option<Box<dyn Any + Send>>,
}

// በመጀመሪያ እስከ ዓይነት ትርጉሞች አንድ ቅልም.እዚህ ጥቂት መድረክ-ተኮር oddities, እና ልክ የሚቆጥሩ LLVM ከ ተገልብጧል ነው ዘንድ ብዙ ነገር አለ.በዚህ ሁሉ ዓላማ `_CxxThrowException` አንድ ጥሪ አማካይነት ከዚህ በታች ያለውን `panic` ተግባር ለመተግበር ነው.
//
// ይህ ተግባር ሁለት ነጋሪ እሴቶች ይወስዳል.የመጀመሪያው በዚህ ጉዳይ ላይ ያለን trait ነገር ነው ብለን ውስጥ በማለፍ የተደረገበትን ውሂብ, አንድ ጠቋሚ ነው.ለማግኘት በጣም ቀላል!ቀጣዩ, ይሁን እንጂ, ይበልጥ ውስብስብ ነው.
// ይህ `_ThrowInfo` መዋቅር አንድ ጠቋሚ ነው, እና በአጠቃላይ ልክ ብቻ ይጣላል እየተደረገ በስተቀር ለመግለጽ የታሰበ ነው.
//
// በአሁኑ ጊዜ የዚህ ዓይነቱ [1] ፍቺ ትንሽ ፀጉራማ ነው ፣ እና ዋነኛው ያልተለመደ (እና ከኦንላይን መጣጥፉ የተለየ ነው) በ 32 ቢት ጠቋሚዎች ጠቋሚዎች ናቸው ነገር ግን በ 64 ቢት ጠቋሚዎች ከ 32 ቢት ቅኝቶች ተገልፀዋል `__ImageBase` ምልክት.
//
// ይህንን ለመግለጽ ከዚህ በታች ባሉት ሞጁሎች ውስጥ `ptr_t` እና `ptr!` macro ጥቅም ላይ ይውላሉ ፡፡
//
// የአይነት ትርጓሜዎች እልህ ለእንዲህ ዓይነቱ አሠራር ኤልኤልቪኤም ምን እንደሚል በቅርብ ይከተላል ፡፡ለምሳሌ ፣ ይህንን የ C++ ኮድ በ MSVC ላይ ካጠናቀሩ እና LLVM IR ን ከለቀቁ
//
//      #include <stdint.h>
//
//      የንድፍ ዝገት_ፓኒክ
//          rust_panic(const rust_panic&);
//          ~rust_panic();
//
//          uint64_t x[2];};
//
//      ባዶነት foo() { rust_panic a = {0, 1};
//          መጣል ሀ;}
//
// በመሠረቱ እኛ ለመምሰል የምንሞክረው ያ ነው ፡፡ከታች ብቻ LLVM ከ ተገልብጧል ነበር በቀጣይነት እሴቶች መካከል አብዛኞቹ,
//
// ያም ሆነ ይህ ፣ እነዚህ መዋቅሮች ሁሉ በተመሳሳይ መልኩ የተገነቡ ናቸው ፣ እና ለእኛ በተወሰነ መልኩ ግስጋሴ ነው ፡፡
//
// [1]: http://www.geoffchappell.com/studies/msvc/language/predefined/
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

#[cfg(target_arch = "x86")]
#[macro_use]
mod imp {
    pub type ptr_t = *mut u8;

    macro_rules! ptr {
        (0) => {
            core::ptr::null_mut()
        };
        ($e:expr) => {
            $e as *mut u8
        };
    }
}

#[cfg(not(target_arch = "x86"))]
#[macro_use]
mod imp {
    pub type ptr_t = u32;

    extern "C" {
        pub static __ImageBase: u8;
    }

    macro_rules! ptr {
        (0) => (0);
        ($e:expr) => {
            (($e as usize) - (&imp::__ImageBase as *const _ as usize)) as u32
        }
    }
}

#[repr(C)]
pub struct _ThrowInfo {
    pub attributes: c_uint,
    pub pmfnUnwind: imp::ptr_t,
    pub pForwardCompat: imp::ptr_t,
    pub pCatchableTypeArray: imp::ptr_t,
}

#[repr(C)]
pub struct _CatchableTypeArray {
    pub nCatchableTypes: c_int,
    pub arrayOfCatchableTypes: [imp::ptr_t; 1],
}

#[repr(C)]
pub struct _CatchableType {
    pub properties: c_uint,
    pub pType: imp::ptr_t,
    pub thisDisplacement: _PMD,
    pub sizeOrOffset: c_int,
    pub copyFunction: imp::ptr_t,
}

#[repr(C)]
pub struct _PMD {
    pub mdisp: c_int,
    pub pdisp: c_int,
    pub vdisp: c_int,
}

#[repr(C)]
pub struct _TypeDescriptor {
    pub pVFTable: *const u8,
    pub spare: *mut u8,
    pub name: [u8; 11],
}

// እዚህ ሆን ብለን የስም ማጥፊያ ደንቦችን ችላ እንደምንል ልብ ይበሉ-C `struct rust_panic` X ን በማወጅ Rust panics ን መያዝ እንዲችል አንፈልግም ፡፡
//
//
// በሚቀይሩበት ጊዜ የዓይነቱ ስም ሕብረቁምፊ በ `compiler/rustc_codegen_llvm/src/intrinsic.rs` ውስጥ ከተጠቀመው ጋር በትክክል መጣጣሙን ያረጋግጡ።
//
const TYPE_NAME: [u8; 11] = *b"rust_panic\0";

static mut THROW_INFO: _ThrowInfo = _ThrowInfo {
    attributes: 0,
    pmfnUnwind: ptr!(0),
    pForwardCompat: ptr!(0),
    pCatchableTypeArray: ptr!(0),
};

static mut CATCHABLE_TYPE_ARRAY: _CatchableTypeArray =
    _CatchableTypeArray { nCatchableTypes: 1, arrayOfCatchableTypes: [ptr!(0)] };

static mut CATCHABLE_TYPE: _CatchableType = _CatchableType {
    properties: 0,
    pType: ptr!(0),
    thisDisplacement: _PMD { mdisp: 0, pdisp: -1, vdisp: 0 },
    sizeOrOffset: mem::size_of::<Exception>() as c_int,
    copyFunction: ptr!(0),
};

extern "C" {
    // እዚህ እየመራ `\x01` ባይት *አንድ `_` ቁምፊ ጋር prefixing እንደ ማንኛውም ሌላ mangling ተግባራዊ ሳይሆን* በእርግጥ ወደ LLVM ወደ አስማታዊ ምልክት ነው.
    //
    //
    // ይህ ምልክት C++ 's `std::type_info` የሚጠቀሙባቸውን vtable ነው.
    // አይነት `std::type_info`, አይነት መግለጫዎች, ዒላማ ይህ ሰንጠረዥ አንድ ጠቋሚ አላቸው.
    // አይነት መግለጫዎች ከላይ በተገለጸው ሲ ++ EH መዋቅሮች በ የተጠቆመው ናቸው; እኛም ከዚህ በታች መገንባት ነው.
    //
    #[link_name = "\x01??_7type_info@@6B@"]
    static TYPE_INFO_VTABLE: *const u8;
}

// ይህ ዓይነቱ ገላጭ ለየት ያለ ሁኔታ ሲጥል ብቻ ነው ጥቅም ላይ የሚውለው ፡፡
// የመያዣው ክፍል የሚከናወነው የራሱ የሆነ TypeDescriptor ን በሚያመነጭ በሙከራ ውስጣዊ ነው ፡፡
//
// ከጠቋሚ እኩልነት ይልቅ የ‹TypeDescriptors›ን ለማዛመድ የ‹MSVC›ጊዜ በአይነቱ ስም ላይ የሕብረቁምፊ ንፅፅርን ስለሚጠቀም ይህ ጥሩ ነው ፡፡
//
static mut TYPE_DESCRIPTOR: _TypeDescriptor = _TypeDescriptor {
    pVFTable: unsafe { &TYPE_INFO_VTABLE } as *const _ as *const _,
    spare: core::ptr::null_mut(),
    name: TYPE_NAME,
};

// በ C++ ኮድ ከሆነ ጥቅም ላይ Destructor በስተቀር ለመያዝ እና እንዲባዙ ያለ ይጣሉት ከወሰነ.
// የሙከራ ውስጠኛው የመያዣው ክፍል ልዩውን ነገር የመጀመሪያውን ቃል ወደ 0 ያዘጋጃል ፣ ይህም በአጥፊው እንዲዘለል ነው።
//
// ከነባሪ የ "C" ጥሪ ስብሰባ ይልቅ x86 Windows ለ C++ አባል ተግባራት የ "thiscall" ጥሪ ስብሰባን እንደሚጠቀም ልብ ይበሉ ፡፡
//
// ልዩ_ኮፒ ተግባር እዚህ ትንሽ ለየት ያለ ነው-በ‹XXXX›ብሎክ ስር በ‹MSVC›ጊዜ ጥሪ የተጠየቀ ሲሆን እዚህ የምናመነጨው panic እንደ ልዩ ቅጂው ጥቅም ላይ ይውላል ፡፡
//
// ይህ እኛ ሣጥን ምክንያቱም አይደግፍም የሚችል std::exception_ptr ጋር መያዝ የማይካተቱትን ለመደገፍ ሲ ++ የሚፈጀውን ጊዜ ጥቅም ላይ ነው<dyn Any>ሁሉን አቀፍ አይደለም ፡፡
//
//
//
//
//
macro_rules! define_cleanup {
    ($abi:tt) => {
        unsafe extern $abi fn exception_cleanup(e: *mut Exception) {
            if let Exception { data: Some(b) } = e.read() {
                drop(b);
                super::__rust_drop_panic();
            }
        }
        #[unwind(allowed)]
        unsafe extern $abi fn exception_copy(_dest: *mut Exception,
                                             _src: *mut Exception)
                                             -> *mut Exception {
            panic!("Rust panics cannot be copied");
        }
    }
}
cfg_if::cfg_if! {
   if #[cfg(target_arch = "x86")] {
       define_cleanup!("thiscall");
   } else {
       define_cleanup!("C");
   }
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    use core::intrinsics::atomic_store;

    // _CxxThrowException የሚያስፈጽም ሙሉ ለሙሉ በዚህ ቁልል ክፈፍ ላይ, እንዲሁ አለበለዚያ ክምር ወደ `data` ለማስተላለፍ አያስፈልግም ነው.
    // የቁልል ጠቋሚ ወደዚህ ተግባር ብቻ እናልፋለን ፡፡
    //
    // እኛ የመተርተሩ ጊዜ ለየት ተቋርጧል መሆን አልፈልግም ጀምሮ ManuallyDrop እዚህ ላይ አስፈላጊ ነው.
    // በምትኩ በ C++ ጊዜ በሚጠይቀው ልዩ_ምክንያታዊነት ይጣላል።
    //
    //
    let mut exception = ManuallyDrop::new(Exception { data: Some(data) });
    let throw_ptr = &mut exception as *mut _ as *mut _;

    // ይህ ... አስገራሚ ይመስላል ፣ እና በትክክልም እንዲሁ።32-ቢት MSVC ላይ እነዚህ መዋቅር መካከል ያለውን ዘዴውን, ዘዴውን ብቻ መሆኑን ነው.
    // በ 64 ቢት ኤም.ሲ.ኤስ.ቪ ላይ ግን በመዋቅሮች መካከል ያሉት ጠቋሚዎች ከ 3200 ቢት ቅናሽ ከ‹XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX/2
    //
    // ስለሆነም በ 32 ቢት ኤም.ሲ.ቪ. ላይ እነዚህን ሁሉ አመልካቾች ከላይ ባለው `የማይንቀሳቀስ` ውስጥ ማወጅ እንችላለን ፡፡
    // በ 64 ቢት ኤም.ሲ.ኤስ.ቪ ላይ በአሁኑ ጊዜ Rust የማይፈቅድለትን በስታቲስቲክስ ውስጥ ጠቋሚዎችን መቀነስ አለብን ፣ ስለሆነም በእውነቱ ይህንን ማድረግ አንችልም ፡፡
    //
    // ቀጣዩ ምርጥ ነገር ፣ ከዚያ እነዚህን መዋቅሮች በወቅቱ መሞላት ነው (አስፈሪነት ቀድሞውኑ "slow path" ነው) ፡፡
    // ስለዚህ እዚህ እኛ እነዚህን ሁሉ የጠቋሚ መስኮች እንደ 32 ቢት ኢንቲጀርቶች እንደገና እንተረጉማቸዋለን እና ከዚያ ተገቢውን እሴት ወደ ውስጡ እናከማቸዋለን (በአቶሚክ ፣ በተመሳሳይ ጊዜ panics እየተከሰተ ሊሆን ይችላል) ፡፡
    //
    // በቴክኒካዊ ወደ የሚፈጀውን ምናልባት በእነዚህ መስኮች nonatomic የተነበበ ማድረግ, ነገር ግን በጣም መጥፎ መሆን የለበትም ስለዚህ ንድፈ ውስጥ እነሱ *እሴት* የተሳሳተ ማንበብ ፈጽሞ ...
    //
    // በማንኛውም ሁኔታ ፣ በስታቲክስ ውስጥ ተጨማሪ ክዋኔዎችን እስከምንገልጽ ድረስ በመሠረቱ እንደዚህ የመሰለ ነገር ማድረግ ያስፈልገናል (እና በጭራሽ አንችልም) ፡፡
    //
    //
    //
    //
    //
    //
    //
    //
    atomic_store(&mut THROW_INFO.pmfnUnwind as *mut _ as *mut u32, ptr!(exception_cleanup) as u32);
    atomic_store(
        &mut THROW_INFO.pCatchableTypeArray as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE_ARRAY as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE_ARRAY.arrayOfCatchableTypes[0] as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.pType as *mut _ as *mut u32,
        ptr!(&TYPE_DESCRIPTOR as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.copyFunction as *mut _ as *mut u32,
        ptr!(exception_copy) as u32,
    );

    extern "system" {
        #[unwind(allowed)]
        fn _CxxThrowException(pExceptionObject: *mut c_void, pThrowInfo: *mut u8) -> !;
    }

    _CxxThrowException(throw_ptr, &mut THROW_INFO as *mut _ as *mut _);
}

pub unsafe fn cleanup(payload: *mut u8) -> Box<dyn Any + Send> {
    // እዚህ አንድ ሙሉ ክፍያ (ጭነት) እዚህ ከ __ Trust_try ከያዝነው (...) ደርሰናል ማለት ነው።
    // ይህ የሚሆነው የ Rust ያልሆነ የውጭ ልዩነት ሲያዝ ነው።
    if payload.is_null() {
        super::__rust_foreign_exception();
    } else {
        let exception = &mut *(payload as *mut Exception);
        exception.data.take().unwrap()
    }
}

// ይህ በአቀናባሪው እንዲኖር ይፈለጋል (ለምሳሌ ፣ ላንግ ንጥል ነው) ፣ ግን በእውነቱ በአቀናባሪው አይጠራም ምክንያቱም __C_specific_handler ወይም _ Except_handler3 ሁል ጊዜም ጥቅም ላይ የሚውለው የባህሪ ተግባር ነው።
//
// ስለሆነም ይህ የሚያጠፋው ግንድ ነው ፡፡
//
#[lang = "eh_personality"]
#[cfg(not(test))]
fn rust_eh_personality() {
    core::intrinsics::abort()
}