//! panics ን ለ Miri መፍታት።
use alloc::boxed::Box;
use core::any::Any;

// ያለው የክፍያ አይነት የ Miri ሞተር ለእኛ የመተርተሩ በኩል ያስፋፋል ነው.
// ጠቋሚ-መጠን ያላቸው መሆን አለበት.
type Payload = Box<Box<dyn Any + Send>>;

extern "Rust" {
    /// የመተርተሩ ለመጀመር extern ተግባር Miri የቀረበ.
    fn miri_start_panic(payload: *mut u8) -> !;
}

pub unsafe fn panic(payload: Box<dyn Any + Send>) -> u32 {
    // ወደ `miri_start_panic` የምናልፈው የክፍያ ጭነት በትክክል በ `cleanup` ውስጥ የምናገኘው ክርክር ይሆናል ፡፡
    // እኛ አንድ ጊዜ ብቻ ወደላይ ሳጥን ስለዚህ ነገር ጠቋሚ መጠን ለማግኘት.
    let payload_box: Payload = Box::new(payload);
    miri_start_panic(Box::into_raw(payload_box) as *mut u8)
}

pub unsafe fn cleanup(payload_box: *mut u8) -> Box<dyn Any + Send> {
    // ከስር `Box` Recover.
    let payload_box: Payload = Box::from_raw(payload_box as *mut _);
    *payload_box
}