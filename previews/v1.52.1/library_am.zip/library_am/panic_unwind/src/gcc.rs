//! panics ትግበራ (በአንዳንድ መልክ) libgcc/libunwind የታጀበ.
//!
//! "Exception Handling in LLVM" (llvm.org/docs/ExceptionHandling.html) እና የተገናኙ ሰነዶች ይመልከቱ የመተርተሩ የማይካተት እና ቁልል ላይ የጀርባ ለ.
//! እነዚህ ደግሞ ጥሩ ያነባል ናቸው:
//!  * <https://itanium-cxx-abi.github.io/cxx-abi/abi-eh.html>
//!  * <http://monoinfinito.wordpress.com/series/exception-handling-in-c/>
//!  * <http://www.airs.com/blog/index.php?s=exception+frames>
//!
//! ## አጭር ማጠቃለያ
//!
//! የፍለጋ ደረጃ እና ጽዳት ዙር: የማይካተት ሁለት ደረጃዎች ውስጥ ይከሰታል.
//!
//! በሁለቱም ደረጃዎች ውስጥ unwinder ("module" እዚህ ክወና ሞዱል, ማለትም, አንድ executable ወይም ተለዋዋጭ መጽሐፍት ያመለክታል) የአሁኑ ሂደት ዎቹ ሞዱሎች ውስጥ ከተተችው ክፈፍ የምናወራበት ክፍሎች እስከ ታች በመጠቀም መረጃ ከላይ ቁልል ፍሬሞች ያሳይዎታል.
//!
//!
//! እያንዳንዱ ቁልል ክፈፍ ያህል, ይህም የእርሱ አድራሻ ደግሞ የምናወራበት መረጃ ክፍል ውስጥ የተከማቸ ነው ተጓዳኝ "personality routine", invokes.
//!
//! የፍለጋ ደረጃ ላይ, አንድ ስብዕና ተዕለት ያለውን የሥራ በስተቀር ነገር ይጣላል እየተደረገ መመርመር, እና በዚያ ቁልል ክፈፍ ላይ እንነጠቃለን ያለበት እንደሆነ ለመወሰን ነው.የ ተቆጣጣሪ ክፈፍ ተለይቷል አንዴ ለማፅዳት ዙር ይጀምራል.
//!
//! በተከሰተበት ደረጃ ውስጥ, unwinder እንደገና እያንዳንዱን ስብዕና ተዕለት invokes.
//! በዚህ ጊዜ ይህ ጽዳት ኮድ ፍላጎት ለአሁኑ ቁልል ፍሬም ያላቸዉን ዘንድ ይህም (ካለ) ይወስናል.እንዲህ ከሆነ, ቁጥጥር, destructors invokes ይህም "landing pad", ከያዘህ የማስታወስ, ወዘተ ተግባር አካል ውስጥ ልዩ branch ተላልፈዋል ነው
//! ወደ ማረፊያ ሰሌዳ መጨረሻ ላይ, ቁጥጥር ወደ unwinder እና የመተርተሩ ከስራ ወደ ኋላ ይተላለፋል.
//!
//! ቁልል በ ተቆጣጣሪ ፍሬም ደረጃ unwound ታች, የመተርተሩ ማቆሚያዎች እና የመጨረሻው ስብዕና ቆይቷል አንዴ ተዕለት ዝውውር የሚይዘው ለማገድ ይቆጣጠራሉ.
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

use alloc::boxed::Box;
use core::any::Any;

use crate::dwarf::eh::{self, EHAction, EHContext};
use libc::{c_int, uintptr_t};
use unwind as uw;

#[repr(C)]
struct Exception {
    _uwe: uw::_Unwind_Exception,
    cause: Box<dyn Any + Send>,
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    let exception = Box::new(Exception {
        _uwe: uw::_Unwind_Exception {
            exception_class: rust_exception_class(),
            exception_cleanup,
            private: [0; uw::unwinder_private_data_size],
        },
        cause: data,
    });
    let exception_param = Box::into_raw(exception) as *mut uw::_Unwind_Exception;
    return uw::_Unwind_RaiseException(exception_param) as u32;

    extern "C" fn exception_cleanup(
        _unwind_code: uw::_Unwind_Reason_Code,
        exception: *mut uw::_Unwind_Exception,
    ) {
        unsafe {
            let _: Box<Exception> = Box::from_raw(exception as *mut Exception);
            super::__rust_drop_panic();
        }
    }
}

pub unsafe fn cleanup(ptr: *mut u8) -> Box<dyn Any + Send> {
    let exception = ptr as *mut uw::_Unwind_Exception;
    if (*exception).exception_class != rust_exception_class() {
        uw::_Unwind_DeleteException(exception);
        super::__rust_foreign_exception();
    } else {
        let exception = Box::from_raw(exception as *mut Exception);
        exception.cause
    }
}

// Rust የሰጠው የተለየ ክፍል ለይቶ.
// ይህ በስተቀር በራሳቸው የሚፈጀውን ጊዜ በ ተጣለ እንደሆነ ለማወቅ ስብዕና ተዕለት የሚጠቀሙበት ነው.
fn rust_exception_class() -> uw::_Unwind_Exception_Class {
    // MOZ\0 ዝገት-ሻጭ, ቋንቋ
    0x4d4f5a_00_52555354
}

// መታወቂያዎች ለእያንዳንዱ ሥነ ሕንፃ ለ LLVM ያለው TargetLowering::getExceptionPointerRegister() እና TargetLowering::getExceptionSelectorRegister() ከ ከፍ መመዝገብ, ከዚያም በተለምዶ (ምዝገባ ፍቺ ሰንጠረዦች በኩል ድንክ ምዝገባ ቁጥሮች ጋር ማፕ<arch>RegisterInfo.td,) "DwarfRegNum" መፈለግ.
//
// በተጨማሪም http://llvm.org/docs/WritingAnLLVMBackend.html#defining-a-register ተመልከት.
//
//

#[cfg(target_arch = "x86")]
const UNWIND_DATA_REG: (i32, i32) = (0, 2); // ኢኤአክስ ፣ ኢዲኤክስ

#[cfg(target_arch = "x86_64")]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // RAX, RDX

#[cfg(any(target_arch = "arm", target_arch = "aarch64"))]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // R0, R1/X0, X1

#[cfg(any(target_arch = "mips", target_arch = "mips64"))]
const UNWIND_DATA_REG: (i32, i32) = (4, 5); // A0, A1

#[cfg(any(target_arch = "powerpc", target_arch = "powerpc64"))]
const UNWIND_DATA_REG: (i32, i32) = (3, 4); // R3, R4/X3, X4

#[cfg(target_arch = "s390x")]
const UNWIND_DATA_REG: (i32, i32) = (6, 7); // R6, R7

#[cfg(any(target_arch = "sparc", target_arch = "sparc64"))]
const UNWIND_DATA_REG: (i32, i32) = (24, 25); // I0, I1

#[cfg(target_arch = "hexagon")]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // R0, R1

#[cfg(any(target_arch = "riscv64", target_arch = "riscv32"))]
const UNWIND_DATA_REG: (i32, i32) = (10, 11); // x10, x11

// የሚከተሉት ኮድ GCC ዎቹ ሲ እና ሲ ++ ስብዕና ተዕለት ላይ የተመሠረተ ነው.ለማጣቀሻ ተመልከት:
// https://github.com/gcc-mirror/gcc/blob/master/libstdc++-v3/libsupc++/eh_personality.cc
// https://github.com/gcc-mirror/gcc/blob/trunk/libgcc/unwind-c.c

cfg_if::cfg_if! {
    if #[cfg(all(target_arch = "arm", not(target_os = "ios"), not(target_os = "netbsd")))] {
        // ARM EHABI ስብዕና ተዕለት.
        // http://infocenter.arm.com/help/topic/com.arm.doc.ihi0038b/IHI0038B_ehabi.pdf
        //
        // iOS ይህ SjLj የመተርተሩ የሚጠቀም በመሆኑ ይልቅ ነባሪ ተዕለት ይጠቀማል.
        #[lang = "eh_personality"]
        unsafe extern "C" fn rust_eh_personality(state: uw::_Unwind_State,
                                                 exception_object: *mut uw::_Unwind_Exception,
                                                 context: *mut uw::_Unwind_Context)
                                                 -> uw::_Unwind_Reason_Code {
            let state = state as c_int;
            let action = state & uw::_US_ACTION_MASK as c_int;
            let search_phase = if action == uw::_US_VIRTUAL_UNWIND_FRAME as c_int {
                // ARM ላይ Backtraces ሁኔታ ጋር ስብዕና ተዕለት እጠራለሁ==_US_VIRTUAL_UNWIND_FRAME |_US_FORCE_UNWIND.
                // በእነዚህ ሁኔታዎች ውስጥ እኛ አለበለዚያ ሁሉ backtraces __rust_try ላይ ያበቃል ነበር, በቁልሉ የመተርተሩ መቀጠል ይፈልጋሉ
                //
                //
                if state & uw::_US_FORCE_UNWIND as c_int != 0 {
                    return continue_unwind(exception_object, context);
                }
                true
            } else if action == uw::_US_UNWIND_FRAME_STARTING as c_int {
                false
            } else if action == uw::_US_UNWIND_FRAME_RESUME as c_int {
                return continue_unwind(exception_object, context);
            } else {
                return uw::_URC_FAILURE;
            };

            // የ DWARF ያልተስተካከለ _Unwind_Context እንደ ተግባሩ እና እንደ ኤል.ኤስ.ዲ አመልካቾች ያሉ ነገሮችን እንደሚይዝ ይገምታል ፣ ሆኖም ግን ARM EHABI ለየት ያለ ነገር ውስጥ ያስገባቸዋል ፡፡
            // ብቻ አውድ ጠቋሚ መውሰድ ይህም _Unwind_GetLanguageSpecificData() ላሉ ተግባራት, ስለ ፊርማ ለማቆየት, GCC ስብዕና እለታዊ አንድ ጠቋሚ ARM ዎቹ "scratch register" (r12) ለ ተይዟል አካባቢ በመጠቀም, አውድ ውስጥ exception_object ወደ ደብቆት.
            //
            //
            //
            //
            uw::_Unwind_SetGR(context,
                              uw::UNWIND_POINTER_REG,
                              exception_object as uw::_Unwind_Ptr);
            // ... ይበልጥ አጋፔ አቀራረብ ድንክ የተኳሃኝነት ተግባራት ለማለፍ ያለን libunwind ማሰሪያዎች ውስጥ ARM ዎቹ _Unwind_Context ሙሉ ትርጉም መስጠት እና በቀጥታ ከዚያ የሚያስፈልጉ ውሂብ ማምጣት ይሆናል.
            //
            //

            let eh_action = match find_eh_action(context) {
                Ok(action) => action,
                Err(_) => return uw::_URC_FAILURE,
            };
            if search_phase {
                match eh_action {
                    EHAction::None |
                    EHAction::Cleanup(_) => return continue_unwind(exception_object, context),
                    EHAction::Catch(_) => {
                        // EHABI በስተቀር ዕቃ መካከል ግርዶሽ መሸጎጫ ውስጥ SP ዋጋ ለማዘመን ስብዕና ተዕለት ይጠይቃል.
                        //
                        (*exception_object).private[5] =
                            uw::_Unwind_GetGR(context, uw::UNWIND_SP_REG);
                        return uw::_URC_HANDLER_FOUND;
                    }
                    EHAction::Terminate => return uw::_URC_FAILURE,
                }
            } else {
                match eh_action {
                    EHAction::None => return continue_unwind(exception_object, context),
                    EHAction::Cleanup(lpad) |
                    EHAction::Catch(lpad) => {
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.0,
                                          exception_object as uintptr_t);
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.1, 0);
                        uw::_Unwind_SetIP(context, lpad);
                        return uw::_URC_INSTALL_CONTEXT;
                    }
                    EHAction::Terminate => return uw::_URC_FAILURE,
                }
            }

            // ARM EHABI ላይ ያለውን ስብዕና ተዕለት በትክክል (ARM EHABI ሰከንድ ከመመለሳቸው በፊት አንድ ነጠላ ቁልል ክፈፍ የመተርተሩ ኃላፊነት ነው.
            // 6.1).
            unsafe fn continue_unwind(exception_object: *mut uw::_Unwind_Exception,
                                      context: *mut uw::_Unwind_Context)
                                      -> uw::_Unwind_Reason_Code {
                if __gnu_unwind_frame(exception_object, context) == uw::_URC_NO_REASON {
                    uw::_URC_CONTINUE_UNWIND
                } else {
                    uw::_URC_FAILURE
                }
            }
            // libgcc ውስጥ ፍቺ
            extern "C" {
                fn __gnu_unwind_frame(exception_object: *mut uw::_Unwind_Exception,
                                      context: *mut uw::_Unwind_Context)
                                      -> uw::_Unwind_Reason_Code;
            }
        }
    } else {
        // በቀጥታ አብዛኞቹ ዒላማዎች ላይ ሆነ በተዘዋዋሪ SEH በኩል Windows x86_64 ላይ የሚውለው ነባሪ ስብዕና ተዕለት,.
        //
        unsafe extern "C" fn rust_eh_personality_impl(version: c_int,
                                                      actions: uw::_Unwind_Action,
                                                      _exception_class: uw::_Unwind_Exception_Class,
                                                      exception_object: *mut uw::_Unwind_Exception,
                                                      context: *mut uw::_Unwind_Context)
                                                      -> uw::_Unwind_Reason_Code {
            if version != 1 {
                return uw::_URC_FATAL_PHASE1_ERROR;
            }
            let eh_action = match find_eh_action(context) {
                Ok(action) => action,
                Err(_) => return uw::_URC_FATAL_PHASE1_ERROR,
            };
            if actions as i32 & uw::_UA_SEARCH_PHASE as i32 != 0 {
                match eh_action {
                    EHAction::None |
                    EHAction::Cleanup(_) => uw::_URC_CONTINUE_UNWIND,
                    EHAction::Catch(_) => uw::_URC_HANDLER_FOUND,
                    EHAction::Terminate => uw::_URC_FATAL_PHASE1_ERROR,
                }
            } else {
                match eh_action {
                    EHAction::None => uw::_URC_CONTINUE_UNWIND,
                    EHAction::Cleanup(lpad) |
                    EHAction::Catch(lpad) => {
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.0,
                            exception_object as uintptr_t);
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.1, 0);
                        uw::_Unwind_SetIP(context, lpad);
                        uw::_URC_INSTALL_CONTEXT
                    }
                    EHAction::Terminate => uw::_URC_FATAL_PHASE2_ERROR,
                }
            }
        }

        cfg_if::cfg_if! {
            if #[cfg(all(windows, target_arch = "x86_64", target_env = "gnu"))] {
                // (LSDA AKA) ወደ የምናወራበት ተቆጣጣሪ ውሂብ GCC-ተኳሃኝ ኢንኮዲንግ ይጠቀማል ግን x86_64 MinGW ዒላማዎች ላይ, የመተርተሩ ዘዴ SEH ነው.
                //
                #[lang = "eh_personality"]
                #[allow(nonstandard_style)]
                unsafe extern "C" fn rust_eh_personality(exceptionRecord: *mut uw::EXCEPTION_RECORD,
                        establisherFrame: uw::LPVOID,
                        contextRecord: *mut uw::CONTEXT,
                        dispatcherContext: *mut uw::DISPATCHER_CONTEXT)
                        -> uw::EXCEPTION_DISPOSITION {
                    uw::_GCC_specific_handler(exceptionRecord,
                                             establisherFrame,
                                             contextRecord,
                                             dispatcherContext,
                                             rust_eh_personality_impl)
                }
            } else {
                // የእኛን ዒላማዎች አብዛኞቹ የ ስብዕና ተዕለት.
                #[lang = "eh_personality"]
                unsafe extern "C" fn rust_eh_personality(version: c_int,
                        actions: uw::_Unwind_Action,
                        exception_class: uw::_Unwind_Exception_Class,
                        exception_object: *mut uw::_Unwind_Exception,
                        context: *mut uw::_Unwind_Context)
                        -> uw::_Unwind_Reason_Code {
                    rust_eh_personality_impl(version,
                                             actions,
                                             exception_class,
                                             exception_object,
                                             context)
                }
            }
        }
    }
}

unsafe fn find_eh_action(context: *mut uw::_Unwind_Context) -> Result<EHAction, ()> {
    let lsda = uw::_Unwind_GetLanguageSpecificData(context) as *const u8;
    let mut ip_before_instr: c_int = 0;
    let ip = uw::_Unwind_GetIPInfo(context, &mut ip_before_instr);
    let eh_context = EHContext {
        // መመለስ አድራሻ LSDA ክልል ሠንጠረዥ ውስጥ በሚቀጥለው IP ክልል ውስጥ ሊሆን ይችላል ይህም ጥሪ መመሪያ, ባለፉት 1 ባይት ይጠቁማል.
        //
        ip: if ip_before_instr != 0 { ip } else { ip - 1 },
        func_start: uw::_Unwind_GetRegionStart(context),
        get_text_start: &|| uw::_Unwind_GetTextRelBase(context),
        get_data_start: &|| uw::_Unwind_GetDataRelBase(context),
    };
    eh::find_eh_action(lsda, &eh_context)
}

// ከለመድነው መረጃ ምዝገባ ማስመሰል
//
// እያንዳንዱ ሞዱል ምስል የሆነ ክፈፍ የምናወራበት መረጃ ክፍል (አብዛኛውን ጊዜ ".eh_frame") ይዟል.አንድ ሞዱል ሂደት ወደ loaded/unloaded ነው ጊዜ unwinder ትውስታ ውስጥ በዚህ ክፍል አካባቢ በተመለከተ መረጃ አለበት.ይህ ማሳካት ዘዴዎች ከመድረክ ይለያያሉ.
// በአንዳንዶቹ ላይ (ለምሳሌ ፣ Linux) ፣ አላስፈላጊው የመረበሽ የመረጃ ክፍሎችን በራሱ ሊያገኝ ይችላል (በአሁኑ ጊዜ የተጫኑ ሞጁሎችን በ dl_iterate_phdr() API and finding their ".eh_frame" sections) በኩል በተከታታይ በመቁጠር ፤ ሌሎች እንደ Windows ያሉ ሞጁሎች አላስፈላጊ በሆነ የመረጃ ክፍሎቻቸውን በክፍት ኤ.ፒ.አይ. በኩል በንቃት እንዲመዘገቡ ይፈልጋሉ) ፡፡
//
//
// ይህ ሞዱል የተጠቀሱት እና GCC የሚፈጀውን ጋር ያለንን መረጃ መመዝገብ rsbegin.rs ከ ተብለው የትኞቹ ሁለት ምልክቶች ይገልፃል.
// ቁልል የመተርተሩ ትግበራ libgcc_eh ወደ ፊት አዘገያቸው (አሁን) ነው, ይሁን እንጂ Rust crates በማንኛውም GCC የሚፈጀውን ጋር የሚችሉ ግጭቶች ለማስወገድ እነዚህ Rust-ተኮር የመግቢያ ነጥቦችን መጠቀም.
//
//
//
//
//
//
//
//
#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frame_registry {
    extern "C" {
        fn __register_frame_info(eh_frame_begin: *const u8, object: *mut u8);
        fn __deregister_frame_info(eh_frame_begin: *const u8, object: *mut u8);
    }

    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8) {
        __register_frame_info(eh_frame_begin, object);
    }

    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8) {
        __deregister_frame_info(eh_frame_begin, object);
    }
}