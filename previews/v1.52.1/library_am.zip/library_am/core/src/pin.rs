//! በማስታወሻ ውስጥ መረጃን ወደ ቦታው የሚሰኩ አይነቶች።
//!
//! በማስታወሻ ውስጥ የተቀመጡበት ቦታ የማይለወጥ እና በዚህም ሊታመን በሚችልበት ሁኔታ እንዳይንቀሳቀስ የተረጋገጡ ዕቃዎች መኖራቸው አንዳንድ ጊዜ ጠቃሚ ነው ፡፡
//! አንድ ነገር ከጠቋሚዎች ጋር ወደራሱ ማዛወር ዋጋ ቢስ ያደርጋቸዋል ፣ ይህም ያልተገለጸ ባህሪን ሊያስከትል ስለሚችል የእንደዚህ ዓይነቱ ሁኔታ ዋና ምሳሌ የራስ-አመላካች አሰራሮችን መገንባት ነው ፡፡
//!
//! በከፍተኛ ደረጃ አንድ [`Pin<P>`] የየትኛውም ጠቋሚ አይነት `P` ጠቋሚ በማስታወሻ ውስጥ የተረጋጋ ቦታ እንዳለው ያረጋግጣል ፣ ይህም ማለት ወደ ሌላ ቦታ ሊንቀሳቀስ የማይችል እና እስከሚወርድ ድረስ የማስታወሻ ማህደረ ትውስታው ሊከፋፈል አይችልም ማለት ነው ፡፡እኛ ጠቋሚው "pinned" ነው እንላለን ፡፡ከተሰካ መረጃ ጋር ተጣብቀው ስለሚጣመሩ አይነቶች ሲወያዩ ነገሮች የበለጠ ስውር ይሆናሉ ፡፡ለተጨማሪ ዝርዝሮች [see below](#projections-and-structural-pinning)
//!
//! በነባሪነት ፣ በ Rust ውስጥ ያሉት ሁሉም ዓይነቶች ተንቀሳቃሽ ናቸው።
//! Rust ሁሉንም ዓይነቶች በእሴት ማለፍን ይፈቅዳል ፣ እና እንደ [`Box<T>`] እና `&mut T` ያሉ የተለመዱ ስማርት-ጠቋሚ ዓይነቶች የያዙትን እሴቶች መተካት እና ማንቀሳቀስ ይፈቅዳሉ-ከ [`Box<T>`] መውጣት ይችላሉ ወይም [`mem::swap`] ን መጠቀም ይችላሉ ፡፡
//! [`Pin<P>`] የጠቋሚ አይነት `P` ን ይሸፍናል ፣ ስለዚህ [`Pin`]`<`[`Box`]] `<T>እንደ መደበኛ ሁሉ ይሠራል
//!
//! [`Box<T>`]: when አንድ [`Pin`]`<`[`Box`] `<T>> ይወድቃል ፣ ይዘቶቹም እንዲሁ ይወርዳሉ እና ማህደረ ትውስታው ይነሳል
//!
//! የተከፋፈለበተመሳሳይ ፣ [`Pin`]`<&mut T>` እንደ `&mut T` ያለ ብዙ ነው።ሆኖም ፣ [`Pin<P>`] ደንበኞች በእውነቱ [`Box<T>`] ወይም `&mut T` ን ለተሰካ ውሂብ እንዲያገኙ አይፈቅድም ፣ ይህም እንደ‹XXXX›ያሉ ክዋኔዎችን መጠቀም አይችሉም ማለት ነው ፡፡
//!
//! ```
//! use std::pin::Pin;
//! fn swap_pins<T>(x: Pin<&mut T>, y: Pin<&mut T>) {
//!     // `mem::swap` `&mut T` ይፈልጋል ፣ ግን ልናገኘው አንችልም።
//!     // ተጣብቀናል ፣ የእነዚህን ማጣቀሻዎች ይዘቶች መለዋወጥ አንችልም ፡፡
//!     // `Pin::get_unchecked_mut` ን ልንጠቀም እንችላለን ፣ ግን ያ ምክንያቱ ደህንነቱ የተጠበቀ ነው-
//!     // ነገሮችን ከ `Pin` ለማውጣት እንድንጠቀምበት አልተፈቀደልንም።
//! }
//! ```
//!
//! [`Pin<P>`] የ Rust አጠናቃሪ ሁሉንም አይነቶች ተንቀሳቃሽ አድርጎ የመቁጠሩን እውነታ *እንደማይለውጥ* እንደገና መናገሩ ተገቢ ነው።[`mem::swap`] ለማንኛውም `T` ሊመረጥ የሚችል ሆኖ ይቆያል።ይልቁንም [`Pin<P>`] በእነሱ ላይ `&mut T` ን የሚጠይቁ ዘዴዎችን ለመጥራት የማይቻል በመሆኑ የተወሰኑ *እሴቶችን*(በ [`Pin<P>`] በተጠቀሱት ጠቋሚዎች የተጠቆመ) እንዳይንቀሳቀስ ይከላከላል ፡፡
//!
//! [`Pin<P>`] ማንኛውንም የጠቋሚ አይነት `P` ለመጠቅለል ሊያገለግል ይችላል ፣ እና እንደዛ ከ [`Deref`] እና [`DerefMut`] ጋር ይገናኛል።`P: Deref` ከተሰካው `P::Target` እንደ "`P`-style pointer" መታየት ያለበት [`Pin<P>`]-ስለዚህ ፣ አንድ ``Pin`] `<` [`Box`]`<T>>"ለተሰካው `T` የባለቤትነት ጠቋሚ እና የ""ፒን"] "<" ["Rc"] "<T>> ለተሰካው `T` በማጣቀሻ የተቆጠረ ጠቋሚ ነው።
//! ለትክክለኝነት ፣ [`Pin<P>`] በ [`Deref`] እና [`DerefMut`] አተገባበርዎች ላይ የሚመረኮዘው ከ‹`self`›ልኬታቸው ላለመውጣት እና በተጠቆመ ጠቋሚ ላይ ሲጠሩ ጠቋሚውን ወደ ተሰካ ውሂብ ለመመለስ ብቻ ነው ፡፡
//!
//! # `Unpin`
//!
//! በተረጋጋ አድራሻ መኖሩ ላይ ስለማይተማመኑ ብዙ ዓይነቶች ሁልጊዜ በሚሰኩበት ጊዜ እንኳን በነፃነት ተንቀሳቃሽ ናቸው።ይህ ሁሉንም መሰረታዊ ዓይነቶች (እንደ [`bool`] ፣ [`i32`] እና ማጣቀሻዎች) እንዲሁም የእነዚህን ዓይነቶች ብቻ የሚያካትቱ ዓይነቶችን ያጠቃልላል ፡፡ስለ መቆንጠጥ ግድ የማይሰጣቸው ዓይነቶች የ [`Pin<P>`] ውጤትን የሚሽረው የ [`Unpin`] ራስ-trait ን ይተገበራሉ።
//! ለ `T: Unpin` ፣ [`Pin`]`<`[`Box`] `<T>> እና [`Box<T>`] በተመሳሳይ መልኩ እንደ [`Pin`]` <&mut T> `እና `&mut T` ይሰራሉ ፡፡
//!
//! ልብ ይበሉ እና [`Unpin`] በ [`Pin<P>`] ውስጥ የተጠለፈውን የጠቋሚ አይነት `P` ሳይሆን ጠቋሚውን ዓይነት `P::Target` ብቻ ነው የሚመለከቱት።ለምሳሌ ፣ [`Box<T>`] [`Unpin`] ነው ወይም አለመሆኑ በ [`Pin`]`<`[`Box`] `ባህሪ ላይ ምንም ተጽዕኖ የለውም<T>> (እዚህ ፣ `T` የተጠቆመው ዓይነት ነው)።
//!
//! # ምሳሌ-የራስ-አመላካች አወቃቀር
//!
//! ከ `Pin<T>` ጋር የተዛመዱ ዋስትናዎችን እና ምርጫዎችን ለማብራራት ወደ ተጨማሪ ዝርዝሮች ከመሄዳችን በፊት እንዴት ጥቅም ላይ እንደሚውል አንዳንድ ምሳሌዎችን እንወያያለን ፡፡
//! ወደ [skip to where the theoretical discussion continues](#drop-guarantee) ነፃነት ይሰማዎት።
//!
//! ```rust
//! use std::pin::Pin;
//! use std::marker::PhantomPinned;
//! use std::ptr::NonNull;
//!
//! // የተቆራረጠ መስክ ወደ የመረጃ መስክ ስለሚጠቁም ይህ የራስ-አመላካች መዋቅር ነው።
//! // ይህ ንድፍ በተለመደው የብድር ደንቦች ሊገለጽ ስለማይችል ስለ አዛilerው በመደበኛ ማጣቀሻ ስለዚህ ማሳወቅ አንችልም።
//! //
//! // በምትኩ ጥሬው ጠቋሚ እንጠቀማለን ፣ ምንም እንኳን ዋጋ ቢስ መሆኑ የሚታወቅ ቢሆንም ፣ ወደ ገመድ ላይ እያመለከተ እንዳለ እናውቃለን ፡፡
//! //
//! struct Unmovable {
//!     data: String,
//!     slice: NonNull<String>,
//!     _pin: PhantomPinned,
//! }
//!
//! impl Unmovable {
//!     // ተግባሩ በሚመለስበት ጊዜ መረጃው የማይንቀሳቀስ መሆኑን ለማረጋገጥ ለእቃው ዕድሜ ልክ በሚቆይበት ክምር ውስጥ እናስቀምጠዋለን እና እሱን ለመድረስ ብቸኛው መንገድ ጠቋሚ በኩል ነው ፡፡
//!     //
//!     //
//!     fn new(data: String) -> Pin<Box<Self>> {
//!         let res = Unmovable {
//!             data,
//!             // ጠቋሚውን የምንፈጥረው ውሂቡ በቦታው ከተገኘ ብቻ ነው አለበለዚያ እኛ ከመጀመራችን በፊት ቀድሞውኑም ይንቀሳቀሳል
//!             //
//!             slice: NonNull::dangling(),
//!             _pin: PhantomPinned,
//!         };
//!         let mut boxed = Box::pin(res);
//!
//!         let slice = NonNull::from(&boxed.data);
//!         // እርሻ መቀየር አጠቃላይ መዋቅሩን ስለማያንቀሳቅስ ይህ ደህንነቱ የተጠበቀ መሆኑን እናውቃለን
//!         unsafe {
//!             let mut_ref: Pin<&mut Self> = Pin::as_mut(&mut boxed);
//!             Pin::get_unchecked_mut(mut_ref).slice = slice;
//!         }
//!         boxed
//!     }
//! }
//!
//! let unmoved = Unmovable::new("hello".to_string());
//! // መዋቅሩ እስካልተንቀሳቀሰ ድረስ ጠቋሚው ወደ ትክክለኛው ቦታ መጠቆም አለበት።
//! //
//! // ይህ በእንዲህ እንዳለ ጠቋሚውን ለማንቀሳቀስ ነፃ ነን።
//! # #[allow(unused_mut)]
//! let mut still_unmoved = unmoved;
//! assert_eq!(still_unmoved.slice, NonNull::from(&still_unmoved.data));
//!
//! // የእኛ ዓይነት `Unpin` ን ስለማይተገብር ይህ ማጠናቀር ይሳነዋል
//! // mut new_unmoved= Unmovable::new("world".to_string()) ን እንተው
//! // std::mem::swap(&mut *still_unmoved, &mut *new_unmoved);
//! ```
//!
//! # ምሳሌ-ጣልቃ-ገብነት በሁለት-ተገናኝ-ዝርዝር
//!
//! በድርብ ጣልቃ-ገብነት በተዘረዘረ ዝርዝር ውስጥ ስብስቡ በትክክል ማህደረ ትውስታውን ለእራሱ አካላት አይመድበውም ፡፡
//! ምደባ በደንበኞች ቁጥጥር ስር ነው ፣ እና ንጥረነገሮች ከስብስቡ አጭር በሆነው በሚቆለሉበት ክፈፍ ላይ መኖር ይችላሉ።
//!
//! ይህንን ሥራ ለመሥራት እያንዳንዱ ንጥረ ነገር በዝርዝሩ ውስጥ ከቀደመው እና ለተተኪው ጠቋሚዎች አሉት ፡፡ንጥረ ነገሮች ሲጨመሩ ብቻ ሊታከሉ ይችላሉ ፣ ምክንያቱም ንጥረ ነገሮቹን ማዘዋወር ጠቋሚዎቹን ዋጋ ቢስ ያደርገዋል።በተጨማሪም ፣ የተገናኘ ዝርዝር አባል የ‹XXXX›አተገባበር እራሱን ከዝርዝሩ ውስጥ ለማስወገድ የቀደመውን እና ተተኪውን ጠቋሚዎችን ይጠግናል ፡፡
//!
//! በወሳኝ ሁኔታ ፣ በተጠራው [`drop`] ላይ መተማመን መቻል አለብን።ኤለመንት ኤክስኤክስኤክስ ([`drop`]) ን ሳይጠራ ሊተላለፍ ወይም በሌላ መንገድ ዋጋ ቢስ ከሆነ ፣ ከጎረቤቶቹ አካላት ውስጥ ያሉት አመልካቾች ዋጋ ቢስ ይሆናሉ ፣ ይህም የውሂብ አሠራሩን ይሰብራል ፡፡
//!
//! ስለዚህ መሰካት ከ [`ጠብታ]` ጋር በተዛመደ ዋስትናም ይመጣል።
//!
//! # `Drop` guarantee
//!
//! የመሰካት ዓላማ በማስታወሻ ውስጥ አንዳንድ መረጃዎችን በማስቀመጥ ላይ መተማመን መቻል ነው ፡፡
//! ይህንን ስራ ለመስራት መረጃውን ማንቀሳቀስ ብቻ የተከለከለ ነው ፡፡መረጃውን ለማከማቸት የሚያገለግል ማህደረ ትውስታን ማካፈል ፣ እንደገና መተካት ወይም በሌላ መንገድ ዋጋ ቢስ ማድረግም የተከለከለ ነው።
//! እንደ እውነቱ ከሆነ ፣ ለተሰካ ውሂብ [`drop`] * እስከሚጠራበት ጊዜ ድረስ ማህደረ ትውስታው ከተሰነቀቀበት ጊዜ አንስቶ ልክ እንደማይሆን ወይም እንደማይመለስ የማይለዋወጥ ሁኔታን መጠበቅ አለብዎት።[`drop`] ከተመለሰ ወይም panics አንዴ ብቻ ፣ ማህደረ ትውስታ እንደገና ጥቅም ላይ ሊውል ይችላል።
//!
//! ማህደረ ትውስታ በውል ስምሪት "invalidated" ሊሆን ይችላል ፣ ግን [`Some(v)`] ን በ [`None`] በመተካት ወይም ከ vector አንዳንድ ንጥረ ነገሮችን [`Vec::set_len`] ን ወደ "kill" በመደወል ፡፡መጀመሪያ አጥፊውን ሳይጠራ እንደገና እንዲጽፍ [`ptr::write`] ን በመጠቀም እንደገና ሊመለስ ይችላል።[`drop`] ን ሳይጠራ ለተሰካ ውሂብ ከእነዚህ ውስጥ አንዳቸውም አይፈቀዱም ፡፡
//!
//! ከቀደመው ክፍል ውስጥ ጣልቃ-ገብነት የተገናኘው ዝርዝር በትክክል እንዲሠራ የሚያስፈልገው ይህ ዓይነት ዋስትና ነው ፡፡
//!
//! ይህ ዋስትና *እንደማያስታውስ ልብ ይበሉ* ማህደረ ትውስታ አይፈስም!በተሰካ ንጥረ ነገር ላይ [`drop`] ን መጥራት አሁንም ቢሆን ሙሉ በሙሉ ጥሩ አይደለም (ለምሳሌ ፣ አሁንም በ `ፒን`] ላይ [`mem::forget`] ብለው መደወል ይችላሉ <`[` Box`]`<T>>))በእጥፍ-ተያያዥነት ባለው ዝርዝር ውስጥ ያ ንጥረ ነገር በዝርዝሩ ውስጥ ብቻ ይቀራል።ሆኖም `[drop`]*ን ሳይጠሩ* ማከማቻውን ነፃ ማውጣት ወይም እንደገና መጠቀም አይችሉም ፡፡
//!
//! # `Drop` implementation
//!
//! የእርስዎ ዓይነት መቆንጠጥን የሚጠቀም ከሆነ (ለምሳሌ ከላይ እንደ ሁለቱ ምሳሌዎች) ፣ [`Drop`] ን ሲተገብሩ ጥንቃቄ ማድረግ አለብዎት ፡፡የ [`drop`] ተግባር `&mut self` ይወስዳል ፣ ግን ይህ ይባላል *ምንም እንኳን የእርስዎ አይነት ከዚህ በፊት ቢሰካ**!አዘጋጁ በራስ-ሰር [`Pin::get_unchecked_mut`] ብሎ የጠራ ያህል ነው።
//!
//! ይህ በምስማር ላይ የሚመረኮዝ ዓይነትን መተግበር ደህንነቱ የተጠበቀ ኮድ የሚጠይቅ ስለሆነ በጭራሽ በደህንነት ኮድ ውስጥ ችግር ሊፈጥር አይችልም ፣ ነገር ግን በአይነትዎ ውስጥ ፒንጌን ለመጠቀም መወሰኑን ይገንዘቡ (ለምሳሌ በ [`Pin`] `&&&on >`ወይም [`Pin`] `<&mut Self>`) ለ [`Drop`] አተገባበርዎ እንዲሁ ውጤቶች አሉት-የእርስዎ ዓይነት አንድ አካል ተለጥፎ ቢሆን ኖሮ [`Drop`] ን በተዘዋዋሪ እንደሚወስደው ``Pin`] `<&mut ራስ>
//!
//!
//! ለምሳሌ `Drop` ን እንደሚከተለው መተግበር ይችላሉ
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # struct Type { }
//! impl Drop for Type {
//!     fn drop(&mut self) {
//!         // `new_unchecked` ደህና ነው ምክንያቱም ይህ እሴት ከወረደ በኋላ እንደገና ጥቅም ላይ እንደማይውል እናውቃለን።
//!         //
//!         inner_drop(unsafe { Pin::new_unchecked(self)});
//!         fn inner_drop(this: Pin<&mut Type>) {
//!             // ትክክለኛው የመጣል ኮድ እዚህ ይሄዳል።
//!         }
//!     }
//! }
//! ```
//!
//! `inner_drop` ተግባር [`drop`]* * ሊኖረው የሚገባው ዓይነት አለው ፣ ስለሆነም ይህ በድንገት ከ‹ፒንንግ›ጋር በሚጋጭ ሁኔታ `self`/`this` ን አለመጠቀምዎን ያረጋግጣል ፡፡
//!
//! በተጨማሪም ፣ የእርስዎ ዓይነት `#[repr(packed)]` ከሆነ አሰባሳቢው መስኮችን መጣል እንዲችል በራስ-ሰር ያንቀሳቅሳል።በበቂ ሁኔታ ለተመሳሰሉ መስኮች እንኳን ያንን ያደርግ ይሆናል።በዚህ ምክንያት በ‹`#[repr(packed)]`›አይነት መሰካት መጠቀም አይችሉም ፡፡
//!
//! # ትንበያዎች እና መዋቅራዊ መቆንጠጥ
//!
//! ከተሰቀሉት ህጎች ጋር ሲሰሩ አንድ ሰው የ `መዋቅሩን` መስኮች [`Pin`]` <&mut Struct>> ን በሚወስድ ዘዴ እንዴት መድረስ ይችላል የሚለው ጥያቄ ይነሳል።
//! የተለመደው አካሄድ የ ረዳት ዘዴዎችን መፃፍ ነው (*ትንበያ* ተብሎ የሚጠራው) ወደ [`Pin`]`<&mut Struct>> ወደ እርሻው ማጣቀሻ የሚቀይር ነው ፣ ግን ያ ማጣቀሻ ምን ዓይነት ሊኖረው ይገባል?እሱ [`Pin`]` <&mut Field> `ወይም `&mut Field` ነው?
//! ተመሳሳይ ጥያቄ የሚነሳው ከ‹`enum`›መስኮች እና እንዲሁም እንደ [`Vec<T>`] ፣ [`Box<T>`] ወይም [`RefCell<T>`] ያሉ የ container/wrapper ዓይነቶችን ሲያስቡ ነው ፡፡
//! (ይህ ጥያቄ ለሁለቱም ሊለወጡ እና ሊጋሩ ዋቢዎችን ይመለከታል ፣ እኛ እዚህ ምሳሌን ለመለወጥ እዚህ ላይ የሚለዋወጥ ማጣቀሻዎችን በጣም የተለመደውን ጉዳይ እንጠቀማለን ፡፡)
//!
//! ለአንድ የተወሰነ መስክ የታሰበው ትንበያ [`Pin`]`<&mut Struct>`ወደ [`Pin`]`<&mut Field>`ወይም `&mut Field`.ምንም እንኳን አንዳንድ ገደቦች አሉ ፣ እና በጣም አስፈላጊው ገደብ *ወጥነት* ነው:
//! እያንዳንዱ መስክ *ለተሰቀለው ማጣቀሻ ይተነብያል ፣* ወይም * እንደ ትንበያው አካል መቆንጠጥን ማስወገድ ይችላል።
//! ሁለቱም ለአንድ መስክ ከተሠሩ ያ ጥሩ ያልሆነ ይሆናል!
//!
//! የመረጃ አወቃቀር ደራሲ እንደመሆንዎ መጠን "propagates" ን በዚህ መስክ ላይ መሰካት ወይም አለመሆን ለእያንዳንዱ መስክ ይወስናሉ ፡፡
//! የዓይነቱን አወቃቀር ስለሚከተል የሚያሰራጭ መቆንጠጥ "structural" ተብሎም ይጠራል።
//! በሚቀጥሉት ንዑስ ክፍሎች ለሁለቱም ምርጫ መደረግ ያለባቸውን ታሳቢዎች እንገልፃለን ፡፡
//!
//! ## ለ‹`field` X›መሰካት * መዋቅራዊ አይደለም
//!
//! የታሰረ መዋቅሩ መስክ ላይ ላይሰካ የሚችል ላይሆን የሚችል ይመስላል ፣ ግን ይህ በጣም ቀላሉ ምርጫ ነው `[Pin`] `&&Field>` በጭራሽ ካልተፈጠረ ፣ ምንም ስህተት ሊፈጠር አይችልም!ስለዚህ ፣ አንዳንድ መስክ መዋቅራዊ መቆንጠጥ እንደሌለው ከወሰኑ ፣ እርስዎ ማረጋገጥ ያለብዎት ነገር ቢኖር ለዚያ መስክ በጭራሽ የተሰካ ማመሳከሪያ አለመፍጠር ነው።
//!
//! ያለ መዋቅራዊ መሰካት መስኮች [`Pin`]`<&mut Struct>`ን ወደ `&mut Field` የሚቀይር የፕሮጀክት ዘዴ ሊኖራቸው ይችላል
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # type Field = i32;
//! # struct Struct { field: Field }
//! impl Struct {
//!     fn pin_get_field(self: Pin<&mut Self>) -> &mut Field {
//!         // ይህ ምንም ችግር የለውም ምክንያቱም `field` በጭራሽ እንደ ተሰካ ተደርጎ አይቆጠርም ፡፡
//!         unsafe { &mut self.get_unchecked_mut().field }
//!     }
//! }
//! ```
//!
//! የ `field` ዓይነት [`Unpin`] ባይሆንም እንኳ‹`impl Unpin for Struct`›ይችላሉ ፡፡ያ ዓይነት (`Pin`]`<&mut Field>`መቼም በማይፈጠርበት ጊዜ ስለ መሰካት ያስባል የሚለው አግባብነት የለውም ፡፡
//!
//! ## መቆንጠጥ * ለ‹`field` X›መዋቅራዊ ነው
//!
//! ሌላኛው አማራጭ መለጠፍ ለ `field` "structural" ነው ብሎ መወሰን ነው ፣ ማለትም መዋቅሩ ከተሰቀለ ያ መስክም እንዲሁ ነው ፡፡
//!
//! ይህ [`Pin`]`<&mut Field>`ን የሚፈጥር ትንበያ መጻፍ ያስችለዋል ፣ በዚህም መስኩ እንደተሰካ ይመሰክራል-
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # type Field = i32;
//! # struct Struct { field: Field }
//! impl Struct {
//!     fn pin_get_field(self: Pin<&mut Self>) -> Pin<&mut Field> {
//!         // `field` `self` በሚሆንበት ጊዜ የተሰካ ስለሆነ ይህ ምንም ችግር የለውም።
//!         unsafe { self.map_unchecked_mut(|s| &mut s.field) }
//!     }
//! }
//! ```
//!
//! ሆኖም ፣ መዋቅራዊ መቆንጠጥ ከጥቂት ተጨማሪ መስፈርቶች ጋር ይመጣል-
//!
//! 1. ሁሉም መዋቅራዊ መስኮች [`Unpin`] ከሆኑ ብቻ መዋቅሩ [`Unpin`] መሆን አለበት።ይህ ነባሪው ነው ፣ ግን [`Unpin`] ደህንነቱ የተጠበቀ trait ነው ፣ ስለሆነም የመዋቅር ደራሲው እንደ `impl<T> Unpin for Struct<T>` ያለ ነገር ማከል የእርስዎ *ሳይሆን* የእርስዎ ኃላፊነት ነው።
//! (የፕሮጀክት ሥራን መጨመር ደህንነቱ ያልተጠበቀ ኮድ እንደሚያስፈልግ ልብ ይበሉ ፣ ስለሆነም [`Unpin`] ደህንነቱ የተጠበቀ trait መሆኑ `ደህንነቱ ያልተጠበቀ` ከተጠቀሙ ብቻ ስለዚህ ማናቸውም መጨነቅ ያለብዎትን መርህ አይጥስም ፡፡)
//! 2. የመዋቅሩ አጥፊ የመዋቅር መስኮችን ከክርክሩ ማላቀቅ የለበትም ፡፡ይህ በ‹XXXX›ውስጥ የተነሳው ትክክለኛ ነጥብ ነው `drop` `&mut self` ን ይወስዳል ፣ ግን መዋቅሩ (እና ስለሆነም የእሱ መስኮች) ከዚህ በፊት ተሰክተው ሊሆን ይችላል ፡፡
//!     በእርስዎ [`Drop`] ትግበራ ውስጥ አንድ መስክ እንዳይንቀሳቀሱ ዋስትና መስጠት አለብዎት።
//!     በተለይም ቀደም ሲል እንደተብራራው ይህ ማለት የእርስዎ መዋቅር `#[repr(packed)]` መሆን የለበትም * መሆን የለበትም ማለት ነው ፡፡
//!     [`drop`] ን እንዴት እንደሚጽፉ አሰባሳቢው በድንገት መቆንጠጥን እንዳያቋርጡ በሚረዳዎት መንገድ ያንን ክፍል ይመልከቱ።
//! 3. [`Drop` guarantee][drop-guarantee] ን እንደጠበቁ ማረጋገጥ አለብዎት
//!     አንዴ መዋቅርዎ ከተሰካ በኋላ ይዘቱን የያዘው ማህደረ ትውስታ የይዘቱን አጥፊዎች ሳይጠራ አይፃፍም ወይም አይተላለፍም ፡፡
//!     በ [`VecDeque<T>`] እንደተመሰከረለት ይህ አስቸጋሪ ሊሆን ይችላል-የ [`VecDeque<T>`] አጥፊ አንዱ አጥፊዎች panics ከሆኑ በሁሉም አካላት ላይ [`drop`] ን መጥራት ያቅተዋል ፡፡ይህ የ‹[`Drop`]›ዋስትና ይጥሳል ፣ ምክንያቱም ንጥረ ነገሮቻቸው አጥፊዎቻቸው ሳይጠሩ ወደተለያዩ ቦታዎች እንዲዛወሩ ሊያደርግ ይችላል ፡፡([`VecDeque<T>`] ምንም የማጣቀሻ ግምቶች የሉትም ፣ ስለሆነም ይህ ብልሹነትን አያስከትልም።)
//! 4. የእርስዎ ዓይነት ሲሰካ መረጃው ከመዋቅራዊ መስኮች እንዲወጣ የሚያደርጉ ሌሎች ክዋኔዎችን ማቅረብ የለብዎትም።ለምሳሌ ፣ መዋቅሩ [`Option<T>`] ን ከያዘ እና ከ‹XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX አንድ ዓይነት X0XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX tare na-መረጃ
//!
//!     መረጃን ከተሰካ አይነት ለማንቀሳቀስ ለተወሳሰበ ምሳሌ ፣ [`RefCell<T>`] `fn get_pin_mut(self: Pin<&mut Self>) -> Pin<&mut T>` የሆነ ዘዴ ቢኖረው ያስቡ ፡፡
//!     ከዚያ የሚከተሉትን ማድረግ እንችላለን-
//!
//!     ```compile_fail
//!     fn exploit_ref_cell<T>(rc: Pin<&mut RefCell<T>>) {
//!         { let p = rc.as_mut().get_pin_mut(); } // Here we get pinned access to the `T`.
//!         let rc_shr: &RefCell<T> = rc.into_ref().get_ref();
//!         let b = rc_shr.borrow_mut();
//!         let content = &mut *b; // And here we have `&mut T` to the same data.
//!     }
//!     ```
//!
//!     ይህ አሰቃቂ ነው ፣ በመጀመሪያ የ [`RefCell<T>`] ን ይዘት (`RefCell::get_pin_mut` ን በመጠቀም) መሰካት እና ከዚያ በኋላ ያገኘነውን ተለዋጭ ማጣቀሻ በመጠቀም ያንን ይዘት ማንቀሳቀስ እንችላለን ማለት ነው።
//!
//! ## Examples
//!
//! ለ‹XXXX›አይነት ሁለቱም ዕድሎች (መዋቅራዊ መቆንጠጥ ወይም አለመሆን) ትርጉም አላቸው ፡፡
//! ከመዋቅራዊ መቆንጠጥ ጋር አንድ [`Vec<T>`] የ‹አባሎችን›ለማጣቀሻ ማጣቀሻዎችን ለማግኘት የ `get_pin`/`get_pin_mut` ዘዴዎች ሊኖረው ይችላል ፡፡ሆኖም ፣ በተሰቀለው [`Vec<T>`] ላይ [`pop`][Vec::pop] ን ለመደወል *መፍቀድ* አልቻለም ፣ ምክንያቱም ያ (በመዋቅራዊ ሁኔታ የተሰኩ) ይዘቶችን ያንቀሳቅሳል!እንዲሁም [`push`][Vec::push] ን ሊፈቅድለት አይችልም ፣ ይህም ሊለዋወጥ እና በዚህም ይዘቱን ሊያንቀሳቅስ ይችላል።
//!
//! ያለ መዋቅራዊ መቆንጠጥ ያለ [`Vec<T>`] `impl<T> Unpin for Vec<T>` ይችላል ፣ ምክንያቱም ይዘቶቹ በጭራሽ አልተሰኩም እና [`Vec<T>`] ራሱ እንዲሁ በመንቀሳቀስ ጥሩ ነው።
//! በዚያን ጊዜ መሰካት በጭራሽ በ vector ላይ ምንም ተጽዕኖ የለውም ፡፡
//!
//! በመደበኛ ቤተ-መጽሐፍት ውስጥ የጠቋሚ ዓይነቶች በአጠቃላይ መዋቅራዊ መቆንጠጥ የላቸውም ፣ ስለሆነም የመቁረጫ ግምቶችን አይሰጡም።ለዚህ ነው `Box<T>: Unpin` ለሁሉም `T` የሚይዝ።
//! ለጠቋሚ ዓይነቶች ይህንን ማድረጉ ምክንያታዊ ነው ፣ ምክንያቱም `Box<T>` ን ማንቀሳቀስ `T` ን በትክክል አያዛወረውም ፣ [`Box<T>`] ምንም እንኳን `T` ባይሆንም እንኳ በነፃነት ተንቀሳቃሽ (aka `Unpin`) ሊሆን ይችላል።በእውነቱ ፣ እንኳን [`Pin`]`<`[`Box`] `<T>>`እና [`Pin`] `<&mut T>` ሁልጊዜ ራሳቸው [`Unpin`] ናቸው ፣ በተመሳሳይ ምክንያት ይዘታቸው (`T`) ተለጥ ,ል ፣ ግን ጠቋሚዎቹ እራሳቸው የተሰካውን ውሂብ ሳይያንቀሳቅሱ ሊንቀሳቀሱ ይችላሉ።
//! ለሁለቱም [`Box<T>`] እና [`Pin`]`<`[`Box`] `<T>> ፣ ይዘቱ ቢሰካ ጠቋሚው ከተሰካ ወይም ሙሉ በሙሉ ገለልተኛ ነው ፣ ማለትም መቆንጠጥ * መዋቅራዊ አይደለም።
//!
//! የ [`Future`] ጥምርን በሚተገብሩበት ጊዜ [`poll`] ን ለመደወል የተጠቆሙ ማጣቀሻዎችን ማግኘት ስለሚያስፈልግዎት አብዛኛውን ጊዜ ለተጎዱት futures መዋቅራዊ መቆንጠጥ ያስፈልግዎታል ፡፡
//! ነገር ግን አጣማሪዎ ሌላ ማንጠልጠያ የማያስፈልግ ሌላ መረጃ ከያዘ እነዚያን መስኮች መዋቅራዊ እንዳይሆኑ ሊያደርጉዋቸው ይችላሉ ፣ ስለሆነም ልክ `[Pin`] `<&mut Self>` (እንደዚህ ያሉ) ቢኖሩም በሚለዋወጥ ማጣቀሻ በነፃ ሊያገኙዋቸው ይችላሉ። በእራስዎ የ [`poll`] ትግበራ)
//!
//! [`Deref`]: crate::ops::Deref
//! [`DerefMut`]: crate::ops::DerefMut
//! [`mem::swap`]: crate::mem::swap
//! [`mem::forget`]: crate::mem::forget
//! [`Box<T>`]: ../../std/boxed/struct.Box.html
//! [`Vec<T>`]: ../../std/vec/struct.Vec.html
//! [`Vec::set_len`]: ../../std/vec/struct.Vec.html#method.set_len
//! [`Box`]: ../../std/boxed/struct.Box.html
//! [Vec::pop]: ../../std/vec/struct.Vec.html#method.pop
//! [Vec::push]: ../../std/vec/struct.Vec.html#method.push
//! [`Rc`]: ../../std/rc/struct.Rc.html
//! [`RefCell<T>`]: crate::cell::RefCell
//! [`drop`]: Drop::drop
//! [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
//! [`Some(v)`]: Some
//! [`ptr::write`]: crate::ptr::write
//! [`Future`]: crate::future::Future
//! [drop-impl]: #drop-implementation
//! [drop-guarantee]: #drop-guarantee
//! [`poll`]: crate::future::Future::poll
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "pin", since = "1.33.0")]

use crate::cmp::{self, PartialEq, PartialOrd};
use crate::fmt;
use crate::hash::{Hash, Hasher};
use crate::marker::{Sized, Unpin};
use crate::ops::{CoerceUnsized, Deref, DerefMut, DispatchFromDyn, Receiver};

/// የተሰካ ጠቋሚ ፡፡
///
/// ይህ XA [`Unpin`] ን እስካልተተገበረ ድረስ ያ ጠቋሚ የተጠቆመውን እሴት እንዳይንቀሳቀስ የሚያደርገውን ያንን ጠቋሚ "pin" ን በቦታው ላይ እሴቱን የሚያደርግ መጠቅለያ መጠቅለያ ነው ፡፡
///
///
/// *ስለ መቆንጠጥ ማብራሪያ የ [`pin` module] ሰነድን ይመልከቱ ፡፡*
///
/// [`pin` module]: self
///
// Note: ከዚህ በታች ያለው የ‹XXXXXXXXXXXXXXXXXXXXXXX ተግባራዊ ማድረግ በተቻለ መጠን ያልተለመደ ያደርገዋል
// `Clone` ለሚለዋወጥ ማጣቀሻዎች።
// ለተጨማሪ ዝርዝሮች <https://internals.rust-lang.org/t/unsoundness-in-pin/11311> ን ይመልከቱ።
#[stable(feature = "pin", since = "1.33.0")]
#[lang = "pin"]
#[fundamental]
#[repr(transparent)]
#[derive(Copy, Clone)]
pub struct Pin<P> {
    pointer: P,
}

// የድምፅ ጉዳዮችን ለማስወገድ የሚከተሉት ትግበራዎች አልተገኙም ፡፡
// `&self.pointer` ለማይታመኑ የ trait አፈፃፀም ተደራሽ መሆን የለበትም ፡፡
//
// ለተጨማሪ ዝርዝሮች <https://internals.rust-lang.org/t/unsoundness-in-pin/11311/73> ን ይመልከቱ።
//

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref, Q: Deref> PartialEq<Pin<Q>> for Pin<P>
where
    P::Target: PartialEq<Q::Target>,
{
    fn eq(&self, other: &Pin<Q>) -> bool {
        P::Target::eq(self, other)
    }

    fn ne(&self, other: &Pin<Q>) -> bool {
        P::Target::ne(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Eq>> Eq for Pin<P> {}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref, Q: Deref> PartialOrd<Pin<Q>> for Pin<P>
where
    P::Target: PartialOrd<Q::Target>,
{
    fn partial_cmp(&self, other: &Pin<Q>) -> Option<cmp::Ordering> {
        P::Target::partial_cmp(self, other)
    }

    fn lt(&self, other: &Pin<Q>) -> bool {
        P::Target::lt(self, other)
    }

    fn le(&self, other: &Pin<Q>) -> bool {
        P::Target::le(self, other)
    }

    fn gt(&self, other: &Pin<Q>) -> bool {
        P::Target::gt(self, other)
    }

    fn ge(&self, other: &Pin<Q>) -> bool {
        P::Target::ge(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Ord>> Ord for Pin<P> {
    fn cmp(&self, other: &Self) -> cmp::Ordering {
        P::Target::cmp(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Hash>> Hash for Pin<P> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        P::Target::hash(self, state);
    }
}

impl<P: Deref<Target: Unpin>> Pin<P> {
    /// [`Unpin`] ን ለተተገበረው አንድ ዓይነት መረጃ ጠቋሚ ዙሪያ አዲስ `Pin<P>` ን ይገንቡ ፡፡
    ///
    /// እንደ `Pin::new_unchecked` ሳይሆን ይህ ዘዴ ደህንነቱ የተጠበቀ ነው ፣ ምክንያቱም ጠቋሚው `P` ስለ‹[`Unpin`]›ዓይነት መሰረዝ ፣ ይህም የመቁረጥ ዋስትናዎችን ይሰርዛል ፡፡
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn new(pointer: P) -> Pin<P> {
        // ደህንነት-የተጠቀሰው እሴት `Unpin` ነው ፣ ስለሆነም ምንም መስፈርቶች የሉትም
        // በመሰካት ዙሪያ።
        unsafe { Pin::new_unchecked(pointer) }
    }

    /// መሠረታዊውን ጠቋሚውን በመመለስ ይህንን `Pin<P>` ን ይከፍታል።
    ///
    /// እኛ ስንፈታ የፒንጊንግ ወራሪዎችን ችላ ማለት እንድንችል በዚህ `Pin` ውስጥ ያለው መረጃ [`Unpin`] መሆኑን ይጠይቃል።
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin_into_inner", since = "1.39.0")]
    pub const fn into_inner(pin: Pin<P>) -> P {
        pin.pointer
    }
}

impl<P: Deref> Pin<P> {
    /// `Unpin` ን ተግባራዊ ሊያደርግ ወይም ላይችል ለሚችል የአንድ ዓይነት ውሂብ ማጣቀሻ ዙሪያ አዲስ `Pin<P>` ይገንቡ ፡፡
    ///
    /// የ `pointer` ዓይነት መግለጫዎች ለ‹`Unpin`›ዓይነት ከሆነ ፣ በምትኩ `Pin::new` ጥቅም ላይ መዋል አለባቸው ፡፡
    ///
    /// # Safety
    ///
    /// ይህ ግንበኛ ደህንነቱ የተጠበቀ አይደለም ምክንያቱም በ `pointer` የተጠቆመው መረጃ መሰካቱን ማረጋገጥ አንችልም ፣ ማለትም መረጃው እስኪወድቅ ድረስ አይንቀሳቀስም ወይም ማከማቻው ዋጋ የለውም ፡፡
    /// የተገነባው `Pin<P>` `P` መረጃው ለመሰካት ማረጋገጫ ካልሰጠ ያ የኤ.ፒ.አይ. ውል መጣስ እና በኋለኞቹ የ (safe) ክዋኔዎች ላይ ወደማይገለጽ ባህሪ ሊያመራ ይችላል።
    ///
    /// ይህንን ዘዴ በመጠቀም እርስዎ ካሉ ስለ `P::Deref` እና `P::DerefMut` ማስፈጸሚያዎች promise እያደረጉ ነው ፡፡
    /// ከሁሉም በላይ ፣ ከ‹`self` ክርክሮቻቸው›መውጣት የለባቸውም-`Pin::as_mut` እና `Pin::as_ref` በተሰካው ጠቋሚ ላይ‹`DerefMut::deref_mut`›እና‹`Deref::deref` *›ብለው ይጠሩና እነዚህ ዘዴዎች የፒንጌንግ ኢንቫይሬተሮችን እንደሚጠብቁ ይጠብቃሉ ፡፡
    /// በተጨማሪም ፣ ይህንን ዘዴ በመጥራት እርስዎ promise ን በማጣቀሻ የ `P` መዛግብት እንደገና ወደ ቦታው አይወሰዱም ፣በተለይም `&mut P::Target` ን ማግኘት እና ከዚያ ከዚያ ማጣቀሻ መውጣት (ለምሳሌ [`mem::swap`] ን በመጠቀም) መቻል የለበትም ፡፡
    ///
    ///
    /// ለምሳሌ ፣ `Pin::new_unchecked` ን በ `&'a mut T` ላይ መደወል ደህንነቱ የተጠበቀ ነው ምክንያቱም ለተጠቀሰው የሕይወት ዘመን `'a` መሰካት ቢችሉም `'a` ን ካበቁ በኋላ ተጣብቆ መቆየቱን የሚቆጣጠር ምንም ቁጥጥር የላቸውም
    ///
    /// ```
    /// use std::mem;
    /// use std::pin::Pin;
    ///
    /// fn move_pinned_ref<T>(mut a: T, mut b: T) {
    ///     unsafe {
    ///         let p: Pin<&mut T> = Pin::new_unchecked(&mut a);
    ///         // ይህ ማለት ጠቋሚው `a` እንደገና መንቀሳቀስ አይችልም ማለት አለበት።
    ///     }
    ///     mem::swap(&mut a, &mut b);
    ///     // የ `a` አድራሻ ወደ `b` ቁልል መክፈቻ ተቀየረ ፣ ስለሆነም `a` ቀደም ሲል ካስቀመጥነውም ጋር ተንቀሳቅሷል!የመቆንጠጫ ኤፒአይ ውልን ጥሰናል።
    /////
    /// }
    /// ```
    ///
    /// አንድ እሴት አንዴ ከተሰካ በኋላ ለዘለዓለም እንደተሰካ መቆየት አለበት (የእሱ ዓይነት `Unpin` ን ካልተተገበረ)።
    ///
    /// በተመሳሳይ ሁኔታ `Pin::new_unchecked` ን በ `Rc<T>` ላይ መደወል ደህንነቱ የተጠበቀ ነው ፣ ምክንያቱም የመቆንጠጫ ገደቦች የማይገደቡ ተመሳሳይ ውሂብ ስሞች ሊኖሩ ይችላሉ-
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::pin::Pin;
    ///
    /// fn move_pinned_rc<T>(mut x: Rc<T>) {
    ///     let pinned = unsafe { Pin::new_unchecked(Rc::clone(&x)) };
    ///     {
    ///         let p: Pin<&T> = pinned.as_ref();
    ///         // ይህ ማለት ጠቋሚው ዳግመኛ መንቀሳቀስ አይችልም ማለት ነው ፡፡
    ///     }
    ///     drop(pinned);
    ///     let content = Rc::get_mut(&mut x).unwrap();
    ///     // አሁን `x` ብቸኛው ማጣቀሻ ቢሆን ኖሮ ከዚህ በፊት በምሳሌው ላይ እንዳየነው እሱን ለማንቀሳቀስ ልንጠቀምበት የምንችለው ከላይ ለቆንነው መረጃ የሚለዋወጥ ማጣቀሻ አለን ፡፡
    ///     // የመቆንጠጫ ኤፒአይ ውልን ጥሰናል።
    /////
    ///  }
    ///  ```
    ///
    /// [`mem::swap`]: crate::mem::swap
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[lang = "new_unchecked"]
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const unsafe fn new_unchecked(pointer: P) -> Pin<P> {
        Pin { pointer }
    }

    /// ከዚህ ከተሰካ ጠቋሚ የተሰካ የተጋራ ማጣቀሻ ያገኛል።
    ///
    /// ከ `&Pin<Pointer<T>>` ወደ `Pin<&T>` ለመሄድ ይህ አጠቃላይ ዘዴ ነው።
    /// ደህንነቱ የተጠበቀ ነው ፣ ምክንያቱም የ‹XXXX›አካል እንደመሆኑ መጠን ጠቋሚው `Pin<Pointer<T>>` ከተፈጠረ በኋላ መንቀሳቀስ አይችልም ፡፡
    ///
    /// "Malicious" የ `Pointer::Deref` ትግበራዎች እንዲሁ በ `Pin::new_unchecked` ውል አይገለሉም።
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn as_ref(&self) -> Pin<&P::Target> {
        // ደህንነት በዚህ ተግባር ላይ ሰነዶችን ይመልከቱ
        unsafe { Pin::new_unchecked(&*self.pointer) }
    }

    /// መሠረታዊውን ጠቋሚውን በመመለስ ይህንን `Pin<P>` ን ይከፍታል።
    ///
    /// # Safety
    ///
    /// ይህ ተግባር ደህንነቱ የተጠበቀ አይደለም ፡፡በ `Pin` ዓይነት ላይ ያሉ የማይለዋወጡ ሰዎች እንዲፀኑ ይህንን ተግባር ከጠሩት በኋላ ጠቋሚውን `P` ን እንደ ተሰካ ማየቱን ለመቀጠል ዋስትና መስጠት አለብዎት።
    /// የተገኘውን ኤክስኤክስኤክስ (XXXX) በመጠቀም ያለው ኮድ የኤፒአይ ውልን የሚጥስ መቆንጠጫ መለዋወጫዎችን ማቆየቱን ካልቀጠለ እና በኋላ ላይ በ (safe) ክዋኔዎች ውስጥ ወደማይገለጽ ባህሪ ሊያመራ ይችላል ፡፡
    ///
    ///
    /// መሠረታዊው መረጃ [`Unpin`] ከሆነ በምትኩ [`Pin::into_inner`] ጥቅም ላይ መዋል አለበት።
    ///
    ///
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin_into_inner", since = "1.39.0")]
    pub const unsafe fn into_inner_unchecked(pin: Pin<P>) -> P {
        pin.pointer
    }
}

impl<P: DerefMut> Pin<P> {
    /// ከዚህ ከተሰካ ጠቋሚ የተሰካ ተለዋጭ ተለዋዋጭ ማጣቀሻ ያገኛል።
    ///
    /// ከ `&mut Pin<Pointer<T>>` ወደ `Pin<&mut T>` ለመሄድ ይህ አጠቃላይ ዘዴ ነው።
    /// ደህንነቱ የተጠበቀ ነው ፣ ምክንያቱም የ‹XXXX›አካል እንደመሆኑ መጠን ጠቋሚው `Pin<Pointer<T>>` ከተፈጠረ በኋላ መንቀሳቀስ አይችልም ፡፡
    ///
    /// "Malicious" የ `Pointer::DerefMut` ትግበራዎች በተመሳሳይ በ `Pin::new_unchecked` ውል አይገለሉም።
    ///
    /// የታጠፈውን ዓይነት ለሚበሉ ተግባራት ብዙ ጥሪዎችን ሲያደርጉ ይህ ዘዴ ጠቃሚ ነው ፡፡
    ///
    /// # Example
    ///
    /// ```
    /// use std::pin::Pin;
    ///
    /// # struct Type {}
    /// impl Type {
    ///     fn method(self: Pin<&mut Self>) {
    ///         // አንድ ነገር አድርግ
    ///     }
    ///
    ///     fn call_method_twice(mut self: Pin<&mut Self>) {
    ///         // `method` `self` ን ይወስዳል ፣ ስለሆነም `Pin<&mut Self>` ን በ `as_mut` በኩል እንደገና ያስገቡ።
    ///         self.as_mut().method();
    ///         self.as_mut().method();
    ///     }
    /// }
    /// ```
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn as_mut(&mut self) -> Pin<&mut P::Target> {
        // ደህንነት በዚህ ተግባር ላይ ሰነዶችን ይመልከቱ
        unsafe { Pin::new_unchecked(&mut *self.pointer) }
    }

    /// ከተሰካው ማጣቀሻ በስተጀርባ ለማስታወስ አዲስ እሴት ይመድባል።
    ///
    /// ይህ የተሰካ መረጃን በላዩ ላይ ይጽፋል ፣ ግን ያ ደህና ነው ፣ አጥፊው ከመልቀቁ በፊት ይሮጣል ፣ ስለሆነም የመሰካት ዋስትና አይጣስም።
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn set(&mut self, value: P::Target)
    where
        P::Target: Sized,
    {
        *(self.pointer) = value;
    }
}

impl<'a, T: ?Sized> Pin<&'a T> {
    /// የውስጥ እሴቱን በካርታ አዲስ ፒን ይገነባል ፡፡
    ///
    /// ለምሳሌ ፣ አንድ ነገር `Pin` የሆነ ነገር ለማግኘት ከፈለጉ በአንድ መስመር ኮድ ውስጥ ወደዚያ መስክ ለመድረስ ይህንን ሊጠቀሙበት ይችላሉ።
    /// ሆኖም ፣ ከእነዚህ "pinning projections" ጋር በርካታ ማጭበርበሮች አሉ ፡፡
    /// በዚያ ርዕስ ላይ ለተጨማሪ ዝርዝሮች የ [`pin` module] ሰነድን ይመልከቱ ፡፡
    ///
    /// # Safety
    ///
    /// ይህ ተግባር ደህንነቱ የተጠበቀ አይደለም ፡፡
    /// የክርክሩ እሴቱ እስካልተንቀሳቀሰ ድረስ እርስዎ የሚመልሱት ውሂብ የማይንቀሳቀስ መሆኑን ማረጋገጥ አለብዎ (ለምሳሌ ፣ ከዚያ ዋጋ መስኮች አንዱ ስለሆነ) ፣ እና እርስዎም ከተቀበሉት ክርክር ላለመውጣት ውስጣዊ ተግባሩ.
    ///
    ///
    /// [`pin` module]: self#projections-and-structural-pinning
    ///
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    pub unsafe fn map_unchecked<U, F>(self, func: F) -> Pin<&'a U>
    where
        U: ?Sized,
        F: FnOnce(&T) -> &U,
    {
        let pointer = &*self.pointer;
        let new_pointer = func(pointer);

        // ደህንነት-ለ `new_unchecked` ደህንነት ውል መሆን አለበት
        // በተጠሪው ደገፈ ፡፡
        unsafe { Pin::new_unchecked(new_pointer) }
    }

    /// ከፒን አንድ የተጋራ ማጣቀሻ ያገኛል።
    ///
    /// ከተጋራ ማጣቀሻ መውጣት የማይቻል ስለሆነ ይህ ደህንነቱ የተጠበቀ ነው።
    /// በውስጣዊ ተለዋዋጭነት ላይ እዚህ ጉዳይ ያለ መስሎ ሊታይ ይችላል-በእውነቱ ፣ `T` ን ከ `&RefCell<T>` ለማንቀሳቀስ * ይቻላል ፡፡
    /// ሆኖም ፣ ተመሳሳይ ውሂብ የሚያመለክት ኤክስኤክስኤክስ እስከሌለ ድረስ ይህ ችግር አይደለም ፣ እና `RefCell<T>` በይዘቶቹ ላይ የተሰካ ማጣቀሻ እንዲፈጥሩ አይፈቅድልዎትም።
    ///
    /// ለተጨማሪ ዝርዝሮች በ ["pinning projections"] ላይ ውይይቱን ይመልከቱ ፡፡
    ///
    /// Note: `Pin` በተጨማሪ `Deref` ን ወደ ዒላማው ይተገብራል ፣ ይህም ውስጣዊ እሴቱን ለመድረስ ሊያገለግል ይችላል ፡፡
    /// ይሁን እንጂ `Deref` ብቻ ለረጅም `Pin` ወደ `Pin` በራሱ ሳይሆን በሕይወት ዘመኑ ቢዋስ እንደ የሚኖር አንድ የማመሳከሪያ ይሰጣል.
    /// ይህ ዘዴ `Pin` ን ከመጀመሪያው `Pin` ጋር ካለው ተመሳሳይ የሕይወት ዘመን ጋር ወደ ማጣቀሻ እንዲቀይር ያስችለዋል።
    ///
    /// ["pinning projections"]: self#projections-and-structural-pinning
    ///
    ///
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn get_ref(self) -> &'a T {
        self.pointer
    }
}

impl<'a, T: ?Sized> Pin<&'a mut T> {
    /// በተመሳሳይ የሕይወት ዘመን ይህንን `Pin<&mut T>` ወደ `Pin<&T>` ይቀይረዋል ፡፡
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn into_ref(self) -> Pin<&'a T> {
        Pin { pointer: self.pointer }
    }

    /// በዚህ `Pin` ውስጥ ያለው ውሂብ የሚለዋወጥ ማጣቀሻ ያገኛል።
    ///
    /// ይህ በዚህ `Pin` ውስጥ ያለው መረጃ `Unpin` መሆኑን ይጠይቃል።
    ///
    /// Note: `Pin` በተጨማሪ `DerefMut` ን ወደ ውሂቡ ይተገብራል ፣ ይህም ውስጣዊ እሴቱን ለመድረስ ሊያገለግል ይችላል።
    /// ይሁን እንጂ `DerefMut` ብቻ ለረጅም `Pin` ወደ `Pin` በራሱ ሳይሆን በሕይወት ዘመኑ ቢዋስ እንደ የሚኖር አንድ የማመሳከሪያ ይሰጣል.
    ///
    /// ይህ ዘዴ `Pin` ን ከመጀመሪያው `Pin` ጋር ካለው ተመሳሳይ የሕይወት ዘመን ጋር ወደ ማጣቀሻ እንዲቀይር ያስችለዋል።
    ///
    #[inline(always)]
    #[stable(feature = "pin", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn get_mut(self) -> &'a mut T
    where
        T: Unpin,
    {
        self.pointer
    }

    /// በዚህ `Pin` ውስጥ ያለው ውሂብ የሚለዋወጥ ማጣቀሻ ያገኛል።
    ///
    /// # Safety
    ///
    /// ይህ ተግባር ደህንነቱ የተጠበቀ አይደለም ፡፡
    /// በ `Pin` ዓይነት ላይ ያሉ የማይለዋወጡ ሰዎች እንዲፀኑ ይህንን ተግባር ሲደውሉ መረጃውን ከሚቀበለው ከሚለዋወጥ ማጣቀሻ ውጭ በጭራሽ እንደማያስወጡ ማረጋገጥ አለብዎ ፡፡
    ///
    ///
    /// መሠረታዊው መረጃ `Unpin` ከሆነ በምትኩ `Pin::get_mut` ጥቅም ላይ መዋል አለበት።
    ///
    #[inline(always)]
    #[stable(feature = "pin", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const unsafe fn get_unchecked_mut(self) -> &'a mut T {
        self.pointer
    }

    /// የውስጥ እሴቱን በካርታ አዲስ ፒን ይገንቡ ፡፡
    ///
    /// ለምሳሌ ፣ አንድ ነገር `Pin` የሆነ ነገር ለማግኘት ከፈለጉ በአንድ መስመር ኮድ ውስጥ ወደዚያ መስክ ለመድረስ ይህንን ሊጠቀሙበት ይችላሉ።
    /// ሆኖም ፣ ከእነዚህ "pinning projections" ጋር በርካታ ማጭበርበሮች አሉ ፡፡
    /// በዚያ ርዕስ ላይ ለተጨማሪ ዝርዝሮች የ [`pin` module] ሰነድን ይመልከቱ ፡፡
    ///
    /// # Safety
    ///
    /// ይህ ተግባር ደህንነቱ የተጠበቀ አይደለም ፡፡
    /// የክርክሩ እሴቱ እስካልተንቀሳቀሰ ድረስ እርስዎ የሚመልሱት ውሂብ የማይንቀሳቀስ መሆኑን ማረጋገጥ አለብዎ (ለምሳሌ ፣ ከዚያ ዋጋ መስኮች አንዱ ስለሆነ) ፣ እና እርስዎም ከተቀበሉት ክርክር ላለመውጣት ውስጣዊ ተግባሩ.
    ///
    ///
    /// [`pin` module]: self#projections-and-structural-pinning
    ///
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    pub unsafe fn map_unchecked_mut<U, F>(self, func: F) -> Pin<&'a mut U>
    where
        U: ?Sized,
        F: FnOnce(&mut T) -> &mut U,
    {
        // ደህንነት ደዋዩ/ላልተንቀሳቀሰ ሃላፊነት አለበት
        // እሴት ከዚህ ማጣቀሻ ውጭ።
        let pointer = unsafe { Pin::get_unchecked_mut(self) };
        let new_pointer = func(pointer);
        // ደህንነት-የ `this` ዋጋ እንደሌለው የተረጋገጠ ነው
        // ወደ ውጭ ተወስዷል ፣ ይህ ወደ `new_unchecked` የሚደረግ ጥሪ ደህንነቱ የተጠበቀ ነው።
        unsafe { Pin::new_unchecked(new_pointer) }
    }
}

impl<T: ?Sized> Pin<&'static T> {
    /// ከአንድ የማይንቀሳቀስ ማጣቀሻ የተሰካ ማጣቀሻ ያግኙ።
    ///
    /// ይህ ደህንነቱ የተጠበቀ ነው ፣ ምክንያቱም `T` ለ `'static` ዕድሜው ተበድረዋል ፣ ይህም በጭራሽ አያልቅም።
    ///
    #[unstable(feature = "pin_static_ref", issue = "78186")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn static_ref(r: &'static T) -> Pin<&'static T> {
        // ደህንነት-‹የማይንቀሳቀስ ብድር መረጃው እንደማይሆን ዋስትና ይሰጣል
        // moved/invalidated እስኪወድቅ ድረስ (በጭራሽ አይሆንም) ፡፡
        unsafe { Pin::new_unchecked(r) }
    }
}

impl<T: ?Sized> Pin<&'static mut T> {
    /// ከተለዋጭ ከሚለዋወጥ ማጣቀሻ የተሰካ ተለዋጭ ተለዋጭ ማጣቀሻ ያግኙ።
    ///
    /// ይህ ደህንነቱ የተጠበቀ ነው ፣ ምክንያቱም `T` ለ `'static` ዕድሜው ተበድረዋል ፣ ይህም በጭራሽ አያልቅም።
    ///
    #[unstable(feature = "pin_static_ref", issue = "78186")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn static_mut(r: &'static mut T) -> Pin<&'static mut T> {
        // ደህንነት-‹የማይንቀሳቀስ ብድር መረጃው እንደማይሆን ዋስትና ይሰጣል
        // moved/invalidated እስኪወድቅ ድረስ (በጭራሽ አይሆንም) ፡፡
        unsafe { Pin::new_unchecked(r) }
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: Deref> Deref for Pin<P> {
    type Target = P::Target;
    fn deref(&self) -> &P::Target {
        Pin::get_ref(Pin::as_ref(self))
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: DerefMut<Target: Unpin>> DerefMut for Pin<P> {
    fn deref_mut(&mut self) -> &mut P::Target {
        Pin::get_mut(Pin::as_mut(self))
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<P: Receiver> Receiver for Pin<P> {}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Debug> fmt::Debug for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.pointer, f)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Display> fmt::Display for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&self.pointer, f)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Pointer> fmt::Pointer for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.pointer, f)
    }
}

// Note: ይህ ማለት ማስገደድን የሚፈቅድ ማንኛውም የ‹XXXX›impl ማለት ነው
// X0 `Deref<Target=Unpin>` ን ወደ ሚያስደስት ዓይነት `Deref<Target=impl !Unpin>` ን የሚስብ ዓይነት ትክክል አይደለም።
// ምንም እንኳን እንደዚህ ያለ ማበረታቻ በሌሎች ምክንያቶች ምናልባት ጥሩ ላይሆን ይችላል ፣ ስለሆነም እንደዚህ ያሉ ግምቶች በ std ውስጥ እንዲያርፉ ላለመፍቀድ ጥንቃቄ ማድረግ አለብን ፡፡
//
//
#[stable(feature = "pin", since = "1.33.0")]
impl<P, U> CoerceUnsized<Pin<U>> for Pin<P> where P: CoerceUnsized<U> {}

#[stable(feature = "pin", since = "1.33.0")]
impl<P, U> DispatchFromDyn<Pin<U>> for Pin<P> where P: DispatchFromDyn<U> {}