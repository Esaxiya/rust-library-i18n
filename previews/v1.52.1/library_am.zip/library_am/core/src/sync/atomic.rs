//! የአቶሚክ ዓይነቶች
//!
//! የአቶሚክ ዓይነቶች በክሮች መካከል ጥንታዊ የጋራ ማህደረ ትውስታ ግንኙነትን ይሰጣሉ ፣ እና የሌሎች ተጓዳኝ ዓይነቶች ግንባታ ብሎኮች ናቸው ፡፡
//!
//! ይህ ሞጁል [`AtomicBool`] ፣ [`AtomicIsize`] ፣ [`AtomicUsize`] ፣ [`AtomicI8`] ፣ [`AtomicU16`] ፣ ወዘተ ጨምሮ የተመረጡ የጥንት ዓይነቶች የአቶሚክ ስሪቶችን ይገልጻል ፡፡
//! የአቶሚክ ዓይነቶች በትክክል ጥቅም ላይ ሲውሉ ክሮች መካከል ዝመናዎችን የሚያመሳስሉ ክዋኔዎችን ያቀርባሉ ፡፡
//!
//! እያንዳንዱ ዘዴ ለዚያ ክወና የማስታወሻ መሰናክል ጥንካሬን የሚወክል [`Ordering`] ን ይወስዳል።እነዚህ ትዕዛዞች ከ [C++20 atomic orderings][1] ጋር ተመሳሳይ ናቸው።ለበለጠ መረጃ [nomicon][2] ን ይመልከቱ ፡፡
//!
//! [1]: https://en.cppreference.com/w/cpp/atomic/memory_order
//! [2]: ../../../nomicon/atomics.html
//!
//! የአቶሚክ ተለዋዋጮች በክሮች መካከል ለመጋራት ደህንነታቸው የተጠበቀ ነው ([`Sync`] ን ይተገብራሉ) ግን እነሱ ራሳቸው የመጋራት ዘዴን አይሰጡም እና የ Rust [threading model](../../../std/thread/index.html#the-threading-model) ን ይከተላሉ።
//!
//! የአቶሚክ ተለዋዋጭን ለማጋራት በጣም የተለመደው መንገድ ወደ [`Arc`][arc] (በአቶሚክ-ማጣቀሻ-የተቆጠረ የተጋራ ጠቋሚ) ውስጥ ማስገባት ነው ፡፡
//!
//! [arc]: ../../../std/sync/struct.Arc.html
//!
//! እንደ‹0000›ያሉ ቋሚ አነቃቂዎችን በመጠቀም የተጀመሩ የአቶሚክ ዓይነቶች በተንቀሳቃሽ ተለዋዋጮች ውስጥ ሊቀመጡ ይችላሉ ፡፡አቶሚክ ስታቲክስ ብዙውን ጊዜ ሰነፍ ለሆነ ዓለም አቀፍ ጅምር ሥራ ላይ ይውላሉ ፡፡
//!
//! # Portability
//!
//! በዚህ ሞጁል ውስጥ ያሉት ሁሉም የአቶሚክ ዓይነቶች ካሉ እነሱ [lock-free] እንዲሆኑ የተረጋገጠ ነው ፡፡ይህ ማለት እነሱ በዓለም አቀፍ ደረጃ የአካል ለውጥን አያገኙም ማለት ነው ፡፡የአቶሚክ ዓይነቶች እና ክዋኔዎች ከጥበቃ ነፃ የመሆን ዋስትና የላቸውም ፡፡
//! ይህ ማለት እንደ `fetch_or` ያሉ ክዋኔዎች በንፅፅር እና-ስዋፕ ሉፕ ሊተገበሩ ይችላሉ ማለት ነው።
//!
//! የአቶሚክ ክዋኔዎች በትላልቅ መጠኖች አቶሚክ በመመሪያው ንብርብር ላይ ሊተገበሩ ይችላሉ ፡፡ለምሳሌ አንዳንድ መድረኮች `AtomicI8` ን ለመተግበር ባለ 4 ባይት አቶሚክ መመሪያዎችን ይጠቀማሉ።
//! ይህ አስመሳይነት በኮድ ትክክለኛነት ላይ ተጽዕኖ ሊኖረው እንደማይገባ ልብ ሊባል የሚገባው ጉዳይ ነው ፡፡
//!
//! በዚህ ሞጁል ውስጥ የሚገኙት የአቶሚክ ዓይነቶች በሁሉም የመሣሪያ ስርዓቶች ላይ ላይገኙ ይችላሉ ፡፡እዚህ ያሉት የአቶሚክ ዓይነቶች ሁሉም በሰፊው ይገኛሉ ፣ ሆኖም በአጠቃላይ በነባር ላይ ሊመሰረቱ ይችላሉ ፡፡አንዳንድ የሚታወቁ ልዩነቶች-
//!
//! * PowerPC እና የ 32 ቢት ጠቋሚዎች ያላቸው የ MIPS መድረኮች `AtomicU64` ወይም `AtomicI64` አይነቶች የላቸውም።
//! * ARM ለ Linux ያልሆኑ እንደ `armv5te` ያሉ መድረኮች የ `load` እና `store` ስራዎችን ብቻ የሚያቀርቡ ሲሆን እንደ `swap` ፣ `fetch_add` ፣ ወዘተ ያሉ ንፅፅር እና ስዋፕ (CAS) ክዋኔዎችን አይደግፉም ፡፡
//! በተጨማሪም በ‹XXXX›ላይ እነዚህ የ CAS ክዋኔዎች በ‹[operating system support]›በኩል ይተገበራሉ ፣ ይህም ከአፈፃፀም ቅጣት ጋር ሊመጣ ይችላል ፡፡
//! * ARM `thumbv6m` ያላቸው ዒላማዎች `load` እና `store` ክዋኔዎችን ብቻ ይሰጣሉ ፣ እና እንደ `swap` ፣ `fetch_add` ፣ ወዘተ ያሉ ንፅፅር እና ስዋፕ (CAS) ክዋኔዎችን አይደግፉም ፡፡
//!
//! [operating system support]: https://www.kernel.org/doc/Documentation/arm/kernel_user_helpers.txt
//!
//! የ future መድረኮች ሊጨመሩ እንደሚችሉ ልብ ይበሉ እንዲሁም ለአንዳንድ የአቶሚክ ክወናዎች ድጋፍ የለውም ፡፡ቢበዛ ተንቀሳቃሽ ኮድ የትኞቹ የአቶሚክ ዓይነቶች ጥቅም ላይ እንደዋሉ መጠንቀቅ ይፈልጋል ፡፡
//! `AtomicUsize` እና `AtomicIsize` በአጠቃላይ በጣም ተንቀሳቃሽ ናቸው ፣ ግን ከዚያ በኋላ ግን በሁሉም ቦታ አይገኙም ፡፡
//! ለማጣቀሻ የ `std` ቤተ-መጽሐፍት ጠቋሚ መጠን ያላቸውን አቶሚክስ ይፈልጋል ፣ ምንም እንኳን `core` ባይፈልግም ፡፡
//!
//! በአሁኑ ጊዜ `#[cfg(target_arch)]` ን በዋነኝነት ከአቶሚክ ጋር በኮድ ለማጠናቀር መጠቀም ያስፈልግዎታል ፡፡በ future ውስጥ ሊረጋጋ የሚችል ያልተረጋጋ `#[cfg(target_has_atomic)]` አለ።
//!
//! [lock-free]: https://en.wikipedia.org/wiki/Non-blocking_algorithm
//!
//! # Examples
//!
//! ቀላል ሽክርክሪት
//!
//! ```
//! use std::sync::Arc;
//! use std::sync::atomic::{AtomicUsize, Ordering};
//! use std::thread;
//!
//! fn main() {
//!     let spinlock = Arc::new(AtomicUsize::new(1));
//!
//!     let spinlock_clone = Arc::clone(&spinlock);
//!     let thread = thread::spawn(move|| {
//!         spinlock_clone.store(0, Ordering::SeqCst);
//!     });
//!
//!     // መቆለፊያውን ለመልቀቅ ሌላውን ክር ይጠብቁ
//!     while spinlock.load(Ordering::SeqCst) != 0 {}
//!
//!     if let Err(panic) = thread.join() {
//!         println!("Thread had an error: {:?}", panic);
//!     }
//! }
//! ```
//!
//! የቀጥታ ክሮች ዓለምአቀፍ ቆጠራን ይያዙ-
//!
//! ```
//! use std::sync::atomic::{AtomicUsize, Ordering};
//!
//! static GLOBAL_THREAD_COUNT: AtomicUsize = AtomicUsize::new(0);
//!
//! let old_thread_count = GLOBAL_THREAD_COUNT.fetch_add(1, Ordering::SeqCst);
//! println!("live threads: {}", old_thread_count + 1);
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]
#![cfg_attr(not(target_has_atomic_load_store = "8"), allow(dead_code))]
#![cfg_attr(not(target_has_atomic_load_store = "8"), allow(unused_imports))]

use self::Ordering::*;

use crate::cell::UnsafeCell;
use crate::fmt;
use crate::intrinsics;

use crate::hint::spin_loop;

/// በክሮች መካከል በደህና ሊጋራ የሚችል የቦሌ ዓይነት።
///
/// ይህ አይነት በማስታወሻ ማህደረ ትውስታ ውክልና ([`bool`]) አለው።
///
/// **ማስታወሻ**:-ይህ ዓይነቱ የአቶሚክ ጭነት እና የ `u8` መደብሮችን በሚደግፉ መድረኮች ላይ ብቻ ይገኛል።
///
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(C, align(1))]
pub struct AtomicBool {
    v: UnsafeCell<u8>,
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
impl Default for AtomicBool {
    /// ወደ `false` የተጀመረ `AtomicBool` ን ይፈጥራል።
    #[inline]
    fn default() -> Self {
        Self::new(false)
    }
}

// መላክ በተዘዋዋሪ ለ AtomicBool ተተግብሯል።
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl Sync for AtomicBool {}

/// በክር መካከል በደህና ሊጋራ የሚችል ጥሬ የጠቋሚ አይነት።
///
/// ይህ አይነት በማስታወሻ ማህደረ ትውስታ ውክልና (`*mut T`) አለው።
///
/// **ማስታወሻ**:-ይህ ዓይነቱ የአቶሚክ ጭነት እና የጠቋሚዎችን መደብሮች በሚደግፉ መድረኮች ላይ ብቻ ይገኛል ፡፡
/// መጠኑ በእላማው ጠቋሚ መጠን ላይ የተመሠረተ ነው።
#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(target_pointer_width = "16", repr(C, align(2)))]
#[cfg_attr(target_pointer_width = "32", repr(C, align(4)))]
#[cfg_attr(target_pointer_width = "64", repr(C, align(8)))]
pub struct AtomicPtr<T> {
    p: UnsafeCell<*mut T>,
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for AtomicPtr<T> {
    /// ባዶ `AtomicPtr<T>` ን ይፈጥራል።
    fn default() -> AtomicPtr<T> {
        AtomicPtr::new(crate::ptr::null_mut())
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T> Send for AtomicPtr<T> {}
#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T> Sync for AtomicPtr<T> {}

/// አቶሚክ የማስታወስ ማዘዣዎች
///
/// የማስታወሻ ማዘዣዎች የአቶሚክ አሠራሮች ማህደረ ትውስታን የሚያመሳስሉበትን መንገድ ይገልፃሉ ፡፡
/// በጣም ደካማ በሆነው [`Ordering::Relaxed`] ውስጥ በቀዶ ጥገናው በቀጥታ የሚነካው ማህደረ ትውስታ ብቻ ነው የሚመሳሰለው።
/// በሌላ በኩል ፣ የ [`Ordering::SeqCst`] ክዋኔቶች የመደብር ጭነት ጥንድ ሌላ ማህደረ ትውስታን ያመሳስላል ፣ እንዲሁም በአጠቃላይ በሁሉም ክሮች ውስጥ እንደዚህ ያሉ ክዋኔዎችን አጠቃላይ ቅደም ተከተል ይጠብቃል።
///
///
/// የ Rust የማስታወሻ ቅደም ተከተሎች [the same as those of C++20](https://en.cppreference.com/w/cpp/atomic/memory_order) ናቸው።
///
/// ለበለጠ መረጃ [nomicon] ን ይመልከቱ ፡፡
///
/// [nomicon]: ../../../nomicon/atomics.html
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone, Debug, Eq, PartialEq, Hash)]
#[non_exhaustive]
pub enum Ordering {
    /// የትእዛዝ ገደቦች የሉም ፣ የአቶሚክ ክወናዎች ብቻ ፡፡
    ///
    /// በ C++ 20 ውስጥ ከ [`memory_order_relaxed`] ጋር ይዛመዳል።
    ///
    /// [`memory_order_relaxed`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Relaxed_ordering
    #[stable(feature = "rust1", since = "1.0.0")]
    Relaxed,
    /// ከመደብር ጋር ሲደመሩ ሁሉም ቀዳሚ ክዋኔዎች በ [`Acquire`] (ወይም የበለጠ ጠንካራ) ትዕዛዝ ከማንኛውም የዚህ ዋጋ ጭነት በፊት ይታዘዛሉ።
    ///
    /// በተለይም ሁሉም የቀደሙት ጽሑፎች የዚህ እሴት የ [`Acquire`] (ወይም የበለጠ ጠንካራ) ጭነት ለሚያከናውን ለሁሉም ክሮች ይታያሉ ፡፡
    ///
    /// ሸክሞችን እና ሱቆችን ለሚቀላቀል አሠራር ይህንን ማዘዣ መጠቀሙ ወደ [`Relaxed`] ጭነት ክወና እንደሚያመራ ያስተውሉ!
    ///
    /// ይህ ማዘዣ ሱቅ ለሚያከናውን ክዋኔዎች ብቻ የሚያገለግል ነው።
    ///
    /// በ C++ 20 ውስጥ ከ [`memory_order_release`] ጋር ይዛመዳል።
    ///
    /// [`memory_order_release`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    Release,
    /// ከተጫነው ዋጋ [`Release`] (ወይም ጠንካራ) አደራደር ጋር አንድ መደብር ቀዶ ተጽፎ ቢሆን አንድ ሸክም ጋር ተዳምሮ ጊዜ: በዚያን ጊዜ ሁሉም ተከታታይ ቀዶ ከመደብሩ በኋላ አዘዘ ይሆናሉ.
    /// በተለይም ሁሉም ቀጣይ ሸክሞች ከመደብሩ በፊት የተጻፈ ውሂብ ያያሉ ፡፡
    ///
    /// ሸክሞችን እና ሱቆችን ለሚደባለቅ ክዋኔ ይህንን ማዘዣ መጠቀሙ ወደ [`Relaxed`] መደብር ሥራ እንደሚመራ ያስተውሉ!
    ///
    /// ይህ ትዕዛዝ ሸክምን ለሚፈጽሙ ክዋኔዎች ብቻ የሚተገበር ነው።
    ///
    /// በ C++ 20 ውስጥ ከ [`memory_order_acquire`] ጋር ይዛመዳል።
    ///
    /// [`memory_order_acquire`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    Acquire,
    /// ሁለቱም የ [`Acquire`] እና [`Release`] ውጤቶች በአንድ ላይ አላቸው
    /// ለጭነቶች [`Acquire`] ማዘዣን ይጠቀማል።ለመደብሮች የ [`Release`] ማዘዣን ይጠቀማል።
    ///
    /// በ‹XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX ላይ መካከል ውስጥ እና ሲስተም ኦፕሬቲንግ ኦፕሬቲንግ ኦፕሬቲንግ ሲስተም/`compare_and_swap` ን በተመለከተ ክዋኔው ምንም መደብር ሳያከናውን ሊጠናቀቅ ይችላል እና ስለሆነም የ [`Acquire`] ማዘዣ ብቻ አለው ፡፡
    ///
    /// ሆኖም ፣ `AcqRel` የ [`Relaxed`] መዳረሻዎችን በጭራሽ አያከናውንም።
    ///
    /// ይህ ትዕዛዝ ለሁለቱም ጭነቶች እና መደብሮች ለሚያቀናጁ ክዋኔዎች ብቻ ተፈጻሚ ይሆናል።
    ///
    /// በ C++ 20 ውስጥ ከ [`memory_order_acq_rel`] ጋር ይዛመዳል።
    ///
    /// [`memory_order_acq_rel`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    #[stable(feature = "rust1", since = "1.0.0")]
    AcqRel,
    /// እንደ [`Acquire`]/[`Release`]//`AcqRel`](ለጭነት ፣ ለሱቅ እና ለመደብሮች ጭነት በቅደም ተከተል) ሁሉም ክሮች ሁሉንም በቅደም ተከተል ወጥነት ያላቸውን ክዋኔዎች በተመሳሳይ ቅደም ተከተል እንደሚመለከቱ ተጨማሪ ዋስትና .
    ///
    ///
    /// በ C++ 20 ውስጥ ከ [`memory_order_seq_cst`] ጋር ይዛመዳል።
    ///
    /// [`memory_order_seq_cst`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Sequentially-consistent_ordering
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    SeqCst,
}

/// አንድ [`AtomicBool`] ወደ `false` ተጀምሯል።
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "1.34.0",
    reason = "the `new` function is now preferred",
    suggestion = "AtomicBool::new(false)"
)]
pub const ATOMIC_BOOL_INIT: AtomicBool = AtomicBool::new(false);

#[cfg(target_has_atomic_load_store = "8")]
impl AtomicBool {
    /// አዲስ `AtomicBool` ይፈጥራል።
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    ///
    /// let atomic_true  = AtomicBool::new(true);
    /// let atomic_false = AtomicBool::new(false);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_atomic_new", since = "1.32.0")]
    pub const fn new(v: bool) -> AtomicBool {
        AtomicBool { v: UnsafeCell::new(v as u8) }
    }

    /// ለታች [`bool`] የሚለዋወጥ ማጣቀሻ ይመልሳል።
    ///
    /// ይህ ደህንነቱ የተጠበቀ ነው ፣ ምክንያቱም የሚለዋወጥ ማጣቀሻ ሌሎች ክሮች በተመሳሳይ ጊዜ የአቶሚክ መረጃን እንደማይደርሱ ዋስትና ይሰጣል።
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let mut some_bool = AtomicBool::new(true);
    /// assert_eq!(*some_bool.get_mut(), true);
    /// *some_bool.get_mut() = false;
    /// assert_eq!(some_bool.load(Ordering::SeqCst), false);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    pub fn get_mut(&mut self) -> &mut bool {
        // ደህንነት-የሚለዋወጥ ማጣቀሻ ልዩ ባለቤትነትን ያረጋግጣል ፡፡
        unsafe { &mut *(self.v.get() as *mut bool) }
    }

    /// ወደ ኤክስኤክስኤክስ የአቶሚክ መዳረሻ ያግኙ ፡፡
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(atomic_from_mut)]
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let mut some_bool = true;
    /// let a = AtomicBool::from_mut(&mut some_bool);
    /// a.store(false, Ordering::Relaxed);
    /// assert_eq!(some_bool, false);
    /// ```
    #[inline]
    #[cfg(target_has_atomic_equal_alignment = "8")]
    #[unstable(feature = "atomic_from_mut", issue = "76314")]
    pub fn from_mut(v: &mut bool) -> &Self {
        // ደህንነት-የሚለዋወጥ ማጣቀሻ ልዩ ባለቤትነትን ያረጋግጣል ፣ እና
        // የ `bool` እና `Self` ሁለቱም አሰላለፍ 1 ነው።
        unsafe { &*(v as *mut bool as *mut Self) }
    }

    /// አቶሚክን ይበላል እና የያዘውን እሴት ይመልሳል።
    ///
    /// `self` ን በእሴት ማለፍ ሌላ ምንም ክሮች በተመሳሳይ ጊዜ የአቶሚክ መረጃን እንደማያገኙ ዋስትና ስለሚሰጥ ይህ ደህንነቱ የተጠበቀ ነው።
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    ///
    /// let some_bool = AtomicBool::new(true);
    /// assert_eq!(some_bool.into_inner(), true);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> bool {
        self.v.into_inner() != 0
    }

    /// አንድ እሴት ከ bool ይጫናል።
    ///
    /// `load` የዚህን ክዋኔ ማህደረ ትውስታ ቅደም ተከተል የሚገልጽ የ [`Ordering`] ክርክር ይወስዳል።
    /// ሊሆኑ የሚችሉ እሴቶች [`SeqCst`] ፣ [`Acquire`] እና [`Relaxed`] ናቸው ፡፡
    ///
    /// # Panics
    ///
    /// `order` [`Release`] ወይም [`AcqRel`] ከሆነ Panics
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.load(Ordering::Relaxed), true);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn load(&self, order: Ordering) -> bool {
        // ደህንነት-ማንኛውም የውሂብ ውድድሮች በአቶሚክ ውስጣዊ እና በጥሬው ይከላከላሉ
        // ጠቋሚው የገባነው ከማጣቀሻ ስላገኘነው ነው ፡፡
        unsafe { atomic_load(self.v.get(), order) != 0 }
    }

    /// እሴት ወደ bool ያከማቻል።
    ///
    /// `store` የዚህን ክዋኔ ማህደረ ትውስታ ቅደም ተከተል የሚገልጽ የ [`Ordering`] ክርክር ይወስዳል።
    /// ሊሆኑ የሚችሉ እሴቶች [`SeqCst`] ፣ [`Release`] እና [`Relaxed`] ናቸው ፡፡
    ///
    /// # Panics
    ///
    /// `order` [`Acquire`] ወይም [`AcqRel`] ከሆነ Panics
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// some_bool.store(false, Ordering::Relaxed);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn store(&self, val: bool, order: Ordering) {
        // ደህንነት-ማንኛውም የውሂብ ውድድሮች በአቶሚክ ውስጣዊ እና በጥሬው ይከላከላሉ
        // ጠቋሚው የገባነው ከማጣቀሻ ስላገኘነው ነው ፡፡
        unsafe {
            atomic_store(self.v.get(), val as u8, order);
        }
    }

    /// የቀደመውን እሴት በመመለስ በ bool ውስጥ እሴት ያከማቻል።
    ///
    /// `swap` የዚህን ክዋኔ የማስታወስ ቅደም ተከተል የሚገልጽ የ [`Ordering`] ክርክር ይወስዳል።ሁሉም የትእዛዝ ሁነታዎች ይቻላል ፡፡
    /// [`Acquire`] ን መጠቀም የዚህ ክወና መደብር [`Relaxed`] ክፍል እንደሚያደርገው ልብ ይበሉ ፣ እና [`Release`] ን በመጠቀም የጭነት ክፍልን [`Relaxed`] ያደርገዋል።
    ///
    ///
    /// **Note:** ይህ ዘዴ የሚገኘው በ `u8` ላይ የአቶሚክ ሥራዎችን በሚደግፉ መድረኮች ላይ ብቻ ነው ፡፡
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.swap(false, Ordering::Relaxed), true);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn swap(&self, val: bool, order: Ordering) -> bool {
        // ደህንነት የውሂብ ውድድሮች በአቶሚክ ውስጣዊ ነገሮች ተከልክለዋል ፡፡
        unsafe { atomic_swap(self.v.get(), val as u8, order) != 0 }
    }

    /// የአሁኑ ዋጋ ከ `current` እሴት ጋር ተመሳሳይ ከሆነ እሴት ወደ [`bool`] ያከማቻል።
    ///
    /// የመመለሻ እሴት ሁልጊዜ የቀደመው እሴት ነው።ከ `current` ጋር እኩል ከሆነ እሴቱ ዘምኗል።
    ///
    /// `compare_and_swap` እንዲሁም የዚህን ክዋኔ የማስታወስ ቅደም ተከተል የሚገልጽ የ [`Ordering`] ክርክር ይወስዳል።
    /// [`AcqRel`] ን በሚጠቀሙበት ጊዜ እንኳን ክዋኔው ሊከሽፍ እንደሚችል እና ስለሆነም የ `Acquire` ጭነት ብቻ እንደሚያከናውን ልብ ይበሉ ፣ ግን የ `Release` ፍቺ የለውም ፡፡
    /// [`Acquire`] ን መጠቀም ከተከሰተ የዚህ ክወና የመደብር ክፍል [`Relaxed`] ያደርገዋል ፣ እና [`Release`] ን በመጠቀም የጭነት ክፍልን [`Relaxed`] ያደርገዋል።
    ///
    /// **Note:** ይህ ዘዴ የሚገኘው በ `u8` ላይ የአቶሚክ ሥራዎችን በሚደግፉ መድረኮች ላይ ብቻ ነው ፡፡
    ///
    /// # ወደ `compare_exchange` እና `compare_exchange_weak` መሰደድ
    ///
    /// `compare_and_swap` ለማስታወሻ ቅደም ተከተል ከሚከተለው ካርታ ጋር ከ `compare_exchange` ጋር እኩል ነው-
    ///
    /// ኦሪጅናል |ስኬት |አለመሳካት
    /// -------- | ------- | -------
    /// ዘና ፈታ |ዘና ፈታ |ዘና ያለ ግዥ |ያግኙ |መልቀቂያ ያግኙ |መልቀቅ |ዘና ያለ AcqRel |AcqRel |SeqCst ን ያግኙ |SeqCst |SeqCst
    ///
    /// `compare_exchange_weak` ንፅፅሩ በሚሳካበት ጊዜም እንኳ በቅጽበት እንዲከሽፍ ይፈቀድለታል ፣ ይህም አነፃፃሪው እና ቀለበቱ በክብ ውስጥ በሚጠቀሙበት ጊዜ አሰባሳቢው የተሻለ የመሰብሰቢያ ኮድ እንዲያመነጭ ያስችለዋል።
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.compare_and_swap(true, false, Ordering::Relaxed), true);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    ///
    /// assert_eq!(some_bool.compare_and_swap(true, true, Ordering::Relaxed), false);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.50.0",
        reason = "Use `compare_exchange` or `compare_exchange_weak` instead"
    )]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_and_swap(&self, current: bool, new: bool, order: Ordering) -> bool {
        match self.compare_exchange(current, new, order, strongest_failure_ordering(order)) {
            Ok(x) => x,
            Err(x) => x,
        }
    }

    /// የአሁኑ ዋጋ ከ `current` እሴት ጋር ተመሳሳይ ከሆነ እሴት ወደ [`bool`] ያከማቻል።
    ///
    /// የመመለሻ ዋጋ አዲሱ እሴት እንደተፃፈ እና የቀደመውን እሴት መያዙን የሚያመለክት ውጤት ነው ፡፡
    /// በስኬት ላይ ይህ እሴት ከ `current` ጋር እኩል እንደሚሆን የተረጋገጠ ነው ፡፡
    ///
    /// `compare_exchange` የዚህን ክዋኔ የማስታወስ ቅደም ተከተል ለማስረዳት ሁለት [`Ordering`] ክርክሮችን ይወስዳል ፡፡
    /// `success` ከ `current` ጋር ያለው ንፅፅር ከተሳካ ለሚከናወነው የንባብ-ማሻሻያ-የመፃፍ ሥራ አስፈላጊ የሆነውን ትዕዛዝ ያብራራል።
    /// `failure` ንፅፅሩ ሳይሳካ ሲቀር ለሚከናወነው የጭነት ሥራ የሚያስፈልገውን ቅደም ተከተል ይገልጻል ፡፡
    /// [`Acquire`] ን እንደ ስኬት ማዘዣ መጠቀሙ የዚህ ክዋኔ ሱቅ [`Relaxed`] አካል ያደርገዋል ፣ እና [`Release`] ን በመጠቀም የተሳካ ጭነት [`Relaxed`] ያደርገዋል።
    ///
    /// የስህተት ማዘዣው [`SeqCst`] ፣ [`Acquire`] ወይም [`Relaxed`] ብቻ ሊሆን ይችላል እና ከስኬት ማዘዣው ጋር እኩል ወይም ደካማ መሆን አለበት።
    ///
    /// **Note:** ይህ ዘዴ የሚገኘው በ `u8` ላይ የአቶሚክ ሥራዎችን በሚደግፉ መድረኮች ላይ ብቻ ነው ፡፡
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.compare_exchange(true,
    ///                                       false,
    ///                                       Ordering::Acquire,
    ///                                       Ordering::Relaxed),
    ///            Ok(true));
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    ///
    /// assert_eq!(some_bool.compare_exchange(true, true,
    ///                                       Ordering::SeqCst,
    ///                                       Ordering::Acquire),
    ///            Err(false));
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[doc(alias = "compare_and_swap")]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_exchange(
        &self,
        current: bool,
        new: bool,
        success: Ordering,
        failure: Ordering,
    ) -> Result<bool, bool> {
        // ደህንነት የውሂብ ውድድሮች በአቶሚክ ውስጣዊ ነገሮች ተከልክለዋል ፡፡
        match unsafe {
            atomic_compare_exchange(self.v.get(), current as u8, new as u8, success, failure)
        } {
            Ok(x) => Ok(x != 0),
            Err(x) => Err(x != 0),
        }
    }

    /// የአሁኑ ዋጋ ከ `current` እሴት ጋር ተመሳሳይ ከሆነ እሴት ወደ [`bool`] ያከማቻል።
    ///
    /// ከኤክስኤክስኤክስክስክስክስክስክስክስክስክስክስክስክስክስክስክስክስክስክስክስክስ ([`AtomicBool::compare_exchange`]) በተለየ መልኩ ይህ ተግባር በአንዳንድ መድረኮች ላይ የበለጠ ቀልጣፋ ኮድ ሊያመጣ የሚችል ንፅፅር በሚሳካበት ጊዜም እንኳ በጥቂቱ እንዲከሽፍ ይፈቀድለታል ፡፡
    ///
    /// የመመለሻ ዋጋ አዲሱ እሴት እንደተፃፈ እና የቀደመውን እሴት መያዙን የሚያመለክት ውጤት ነው ፡፡
    ///
    /// `compare_exchange_weak` የዚህን ክዋኔ የማስታወስ ቅደም ተከተል ለማስረዳት ሁለት [`Ordering`] ክርክሮችን ይወስዳል ፡፡
    /// `success` ከ `current` ጋር ያለው ንፅፅር ከተሳካ ለሚከናወነው የንባብ-ማሻሻያ-የመፃፍ ሥራ አስፈላጊ የሆነውን ትዕዛዝ ያብራራል።
    /// `failure` ንፅፅሩ ሳይሳካ ሲቀር ለሚከናወነው የጭነት ሥራ የሚያስፈልገውን ቅደም ተከተል ይገልጻል ፡፡
    /// [`Acquire`] ን እንደ ስኬት ማዘዣ መጠቀሙ የዚህ ክዋኔ ሱቅ [`Relaxed`] አካል ያደርገዋል ፣ እና [`Release`] ን በመጠቀም የተሳካ ጭነት [`Relaxed`] ያደርገዋል።
    /// የስህተት ማዘዣው [`SeqCst`] ፣ [`Acquire`] ወይም [`Relaxed`] ብቻ ሊሆን ይችላል እና ከስኬት ማዘዣው ጋር እኩል ወይም ደካማ መሆን አለበት።
    ///
    /// **Note:** ይህ ዘዴ የሚገኘው በ `u8` ላይ የአቶሚክ ሥራዎችን በሚደግፉ መድረኮች ላይ ብቻ ነው ፡፡
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let val = AtomicBool::new(false);
    ///
    /// let new = true;
    /// let mut old = val.load(Ordering::Relaxed);
    /// loop {
    ///     match val.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) {
    ///         Ok(_) => break,
    ///         Err(x) => old = x,
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[doc(alias = "compare_and_swap")]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_exchange_weak(
        &self,
        current: bool,
        new: bool,
        success: Ordering,
        failure: Ordering,
    ) -> Result<bool, bool> {
        // ደህንነት የውሂብ ውድድሮች በአቶሚክ ውስጣዊ ነገሮች ተከልክለዋል ፡፡
        match unsafe {
            atomic_compare_exchange_weak(self.v.get(), current as u8, new as u8, success, failure)
        } {
            Ok(x) => Ok(x != 0),
            Err(x) => Err(x != 0),
        }
    }

    /// አመክንዮአዊ "and" ከቦሊያን እሴት ጋር።
    ///
    /// አሁን ባለው እሴት እና በክርክሩ `val` ላይ አመክንዮአዊ የ "and" ክዋኔን ያከናውን እና አዲሱን እሴት ለውጤቱ ያወጣል ፡፡
    ///
    /// የቀደመውን እሴት ይመልሳል።
    ///
    /// `fetch_and` የዚህን ክዋኔ የማስታወስ ቅደም ተከተል የሚገልጽ የ [`Ordering`] ክርክር ይወስዳል።ሁሉም የትእዛዝ ሁነታዎች ይቻላል ፡፡
    /// [`Acquire`] ን መጠቀም የዚህ ክወና መደብር [`Relaxed`] ክፍል እንደሚያደርገው ልብ ይበሉ ፣ እና [`Release`] ን በመጠቀም የጭነት ክፍልን [`Relaxed`] ያደርገዋል።
    ///
    ///
    /// **Note:** ይህ ዘዴ የሚገኘው በ `u8` ላይ የአቶሚክ ሥራዎችን በሚደግፉ መድረኮች ላይ ብቻ ነው ፡፡
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_and(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_and(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_and(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_and(&self, val: bool, order: Ordering) -> bool {
        // ደህንነት የውሂብ ውድድሮች በአቶሚክ ውስጣዊ ነገሮች ተከልክለዋል ፡፡
        unsafe { atomic_and(self.v.get(), val as u8, order) != 0 }
    }

    /// አመክንዮአዊ "nand" ከቦሊያን እሴት ጋር።
    ///
    /// አሁን ባለው እሴት እና በክርክሩ `val` ላይ አመክንዮአዊ የ "nand" ክዋኔን ያከናውን እና አዲሱን እሴት ለውጤቱ ያወጣል ፡፡
    ///
    /// የቀደመውን እሴት ይመልሳል።
    ///
    /// `fetch_nand` የዚህን ክዋኔ የማስታወስ ቅደም ተከተል የሚገልጽ የ [`Ordering`] ክርክር ይወስዳል።ሁሉም የትእዛዝ ሁነታዎች ይቻላል ፡፡
    /// [`Acquire`] ን መጠቀም የዚህ ክወና መደብር [`Relaxed`] ክፍል እንደሚያደርገው ልብ ይበሉ ፣ እና [`Release`] ን በመጠቀም የጭነት ክፍልን [`Relaxed`] ያደርገዋል።
    ///
    ///
    /// **Note:** ይህ ዘዴ የሚገኘው በ `u8` ላይ የአቶሚክ ሥራዎችን በሚደግፉ መድረኮች ላይ ብቻ ነው ፡፡
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_nand(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_nand(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst) as usize, 0);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_nand(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_nand(&self, val: bool, order: Ordering) -> bool {
        // አቶሚክ_አንዳን እዚህ መጠቀም አንችልም ምክንያቱም ዋጋ ቢስ በሆነ ዋጋ bool ሊያስከትል ይችላል ፡፡
        // ይህ የሚሆነው የአቶሚክ አሠራር በ 8 ቢት ኢንቲጀር በውስጠኛው ስለሆነ ፣ ይህም የላይኛውን 7 ቢት ያዘጋጃል ፡፡
        //
        // ስለዚህ እኛ በምትኩ fetch_xor ወይም ስዋፕ ብቻ እንጠቀማለን።
        if val {
            // ! (x&true)== !x የ bool ን መገልበጥ አለብን።
            //
            self.fetch_xor(true, order)
        } else {
            // ! (x&false)==እውነት bool ን ወደ እውነት ማቀናበር አለብን።
            //
            self.swap(true, order)
        }
    }

    /// አመክንዮአዊ "or" ከቦሊያን እሴት ጋር።
    ///
    /// አሁን ባለው እሴት እና በክርክሩ `val` ላይ አመክንዮአዊ የ "or" ክዋኔን ያከናውን እና አዲሱን እሴት ለውጤቱ ያወጣል ፡፡
    ///
    /// የቀደመውን እሴት ይመልሳል።
    ///
    /// `fetch_or` የዚህን ክዋኔ የማስታወስ ቅደም ተከተል የሚገልጽ የ [`Ordering`] ክርክር ይወስዳል።ሁሉም የትእዛዝ ሁነታዎች ይቻላል ፡፡
    /// [`Acquire`] ን መጠቀም የዚህ ክወና መደብር [`Relaxed`] ክፍል እንደሚያደርገው ልብ ይበሉ ፣ እና [`Release`] ን በመጠቀም የጭነት ክፍልን [`Relaxed`] ያደርገዋል።
    ///
    ///
    /// **Note:** ይህ ዘዴ የሚገኘው በ `u8` ላይ የአቶሚክ ሥራዎችን በሚደግፉ መድረኮች ላይ ብቻ ነው ፡፡
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_or(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_or(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_or(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_or(&self, val: bool, order: Ordering) -> bool {
        // ደህንነት የውሂብ ውድድሮች በአቶሚክ ውስጣዊ ነገሮች ተከልክለዋል ፡፡
        unsafe { atomic_or(self.v.get(), val as u8, order) != 0 }
    }

    /// አመክንዮአዊ "xor" ከቦሊያን እሴት ጋር።
    ///
    /// አሁን ባለው እሴት እና በክርክሩ `val` ላይ አመክንዮአዊ የ "xor" ክዋኔን ያከናውን እና አዲሱን እሴት ለውጤቱ ያወጣል ፡፡
    ///
    /// የቀደመውን እሴት ይመልሳል።
    ///
    /// `fetch_xor` የዚህን ክዋኔ የማስታወስ ቅደም ተከተል የሚገልጽ የ [`Ordering`] ክርክር ይወስዳል።ሁሉም የትእዛዝ ሁነታዎች ይቻላል ፡፡
    /// [`Acquire`] ን መጠቀም የዚህ ክወና መደብር [`Relaxed`] ክፍል እንደሚያደርገው ልብ ይበሉ ፣ እና [`Release`] ን በመጠቀም የጭነት ክፍልን [`Relaxed`] ያደርገዋል።
    ///
    ///
    /// **Note:** ይህ ዘዴ የሚገኘው በ `u8` ላይ የአቶሚክ ሥራዎችን በሚደግፉ መድረኮች ላይ ብቻ ነው ፡፡
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_xor(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_xor(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_xor(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_xor(&self, val: bool, order: Ordering) -> bool {
        // ደህንነት የውሂብ ውድድሮች በአቶሚክ ውስጣዊ ነገሮች ተከልክለዋል ፡፡
        unsafe { atomic_xor(self.v.get(), val as u8, order) != 0 }
    }

    /// ሊለዋወጥ የሚችል ጠቋሚ ወደታች [`bool`] ይመልሳል።
    ///
    /// አቶሚክ ያልሆኑ ንባቦችን እና በተፈጠረው ኢንቲጀር ላይ መፃፍ የውሂብ ውድድር ሊሆን ይችላል ፡፡
    /// ይህ ዘዴ ለኤፍኤፍአይ በጣም ጠቃሚ ነው ፣ የትግበራ ፊርማ ከ `&AtomicBool` ይልቅ `*mut bool` ን ሊጠቀም ይችላል።
    ///
    /// የአቶሚክ ዓይነቶች ከውስጣዊ ተለዋዋጭነት ጋር ስለሚሠሩ የ‹XXXX›ጠቋሚውን ወደዚህ አቶሚክ ከተጋራ ማጣቀሻ መመለስ ደህንነቱ የተጠበቀ ነው ፡፡
    /// የአቶሚክ ማሻሻያዎች ሁሉም ለውጦች በጋራ ማጣቀሻ አማካይነት ዋጋውን ይለውጣሉ ፣ እናም የአቶሚክ አሠራሮችን እስከጠቀሙ ድረስ በደህና ማድረግ ይችላሉ።
    /// የተመለሰው ጥሬ አመላካች ማንኛውም አጠቃቀም የ `unsafe` ማገጃን ይጠይቃል እና አሁንም ተመሳሳይ ገደቡን መጠበቅ አለበት-በእሱ ላይ የሚከናወኑ ተግባራት አቶሚክ መሆን አለባቸው ፡፡
    ///
    ///
    /// # Examples
    ///
    /// ```ignore (extern-declaration)
    /// # fn main() {
    /// use std::sync::atomic::AtomicBool;
    /// extern "C" {
    ///     fn my_atomic_op(arg: *mut bool);
    /// }
    ///
    /// let mut atomic = AtomicBool::new(true);
    /// unsafe {
    ///     my_atomic_op(atomic.as_mut_ptr());
    /// }
    /// # }
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_mut_ptr", reason = "recently added", issue = "66893")]
    pub fn as_mut_ptr(&self) -> *mut bool {
        self.v.get() as *mut bool
    }

    /// እሴቱን ያወጣል እና አማራጭ አዲስ እሴትን የሚያስመልስ ተግባርን በእሱ ላይ ይተገበራል።ተግባሩ `Some(_)` ን ከተመለሰ ሌላ `Err(previous_value)` ከሆነ የ `Result` የ `Ok(previous_value)` ይመልሳል።
    ///
    /// Note: ተግባሩ `Some(_)` ን እስከመለሰ ድረስ እሴቱ ከሌላው ክሮች ውስጥ እሴቱ ከተቀየረ ይህ ተግባሩን ብዙ ጊዜ ሊጠራው ይችላል ፣ ነገር ግን ተግባሩ ለተከማቸው እሴት አንድ ጊዜ ብቻ ይተገበራል።
    ///
    ///
    /// `fetch_update` የዚህን ክዋኔ የማስታወስ ቅደም ተከተል ለማስረዳት ሁለት [`Ordering`] ክርክሮችን ይወስዳል ፡፡
    /// የመጀመሪያው ክዋኔው በመጨረሻ ሲሳካ አስፈላጊ የሆነውን ቅደም ተከተል የሚገልጽ ሲሆን ሁለተኛው ደግሞ ስለ ጭነት አስፈላጊ የሆነውን ቅደም ተከተል ይገልጻል ፡፡
    /// እነዚህ በቅደም ተከተል ከ‹[`AtomicBool::compare_exchange`] X›ስኬት እና ውድቀት ትዕዛዞች ጋር ይዛመዳሉ ፡፡
    ///
    /// [`Acquire`] ን እንደ ስኬት ማዘዣ መጠቀሙ የዚህ ክዋኔ ሱቅ [`Relaxed`] አካል ያደርገዋል ፣ እና [`Release`] ን በመጠቀም የመጨረሻውን ስኬታማ ጭነት [`Relaxed`] ያደርገዋል።
    /// የ (failed) ጭነት ማዘዣ [`SeqCst`] ፣ [`Acquire`] ወይም [`Relaxed`] ብቻ ሊሆን ይችላል እና ከስኬት ማዘዣው ጋር እኩል ወይም ደካማ መሆን አለበት።
    ///
    /// **Note:** ይህ ዘዴ የሚገኘው በ `u8` ላይ የአቶሚክ ሥራዎችን በሚደግፉ መድረኮች ላይ ብቻ ነው ፡፡
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(atomic_fetch_update)]
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let x = AtomicBool::new(false);
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(false));
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| Some(!x)), Ok(false));
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| Some(!x)), Ok(true));
    /// assert_eq!(x.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_fetch_update", reason = "recently added", issue = "78639")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_update<F>(
        &self,
        set_order: Ordering,
        fetch_order: Ordering,
        mut f: F,
    ) -> Result<bool, bool>
    where
        F: FnMut(bool) -> Option<bool>,
    {
        let mut prev = self.load(fetch_order);
        while let Some(next) = f(prev) {
            match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                x @ Ok(_) => return x,
                Err(next_prev) => prev = next_prev,
            }
        }
        Err(prev)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
impl<T> AtomicPtr<T> {
    /// አዲስ `AtomicPtr` ይፈጥራል።
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicPtr;
    ///
    /// let ptr = &mut 5;
    /// let atomic_ptr  = AtomicPtr::new(ptr);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_atomic_new", since = "1.32.0")]
    pub const fn new(p: *mut T) -> AtomicPtr<T> {
        AtomicPtr { p: UnsafeCell::new(p) }
    }

    /// ለታች ጠቋሚው የሚለዋወጥ ማጣቀሻ ይመልሳል።
    ///
    /// ይህ ደህንነቱ የተጠበቀ ነው ፣ ምክንያቱም የሚለዋወጥ ማጣቀሻ ሌሎች ክሮች በተመሳሳይ ጊዜ የአቶሚክ መረጃን እንደማይደርሱ ዋስትና ይሰጣል።
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let mut atomic_ptr = AtomicPtr::new(&mut 10);
    /// *atomic_ptr.get_mut() = &mut 5;
    /// assert_eq!(unsafe { *atomic_ptr.load(Ordering::SeqCst) }, 5);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    pub fn get_mut(&mut self) -> &mut *mut T {
        self.p.get_mut()
    }

    /// ወደ ጠቋሚ የአቶሚክ መዳረሻ ያግኙ።
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(atomic_from_mut)]
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let mut some_ptr = &mut 123 as *mut i32;
    /// let a = AtomicPtr::from_mut(&mut some_ptr);
    /// a.store(&mut 456, Ordering::Relaxed);
    /// assert_eq!(unsafe { *some_ptr }, 456);
    /// ```
    #[inline]
    #[cfg(target_has_atomic_equal_alignment = "ptr")]
    #[unstable(feature = "atomic_from_mut", issue = "76314")]
    pub fn from_mut(v: &mut *mut T) -> &Self {
        use crate::mem::align_of;
        let [] = [(); align_of::<AtomicPtr<()>>() - align_of::<*mut ()>()];
        // SAFETY:
        //  - ሊለዋወጥ የሚችል ማጣቀሻ ልዩ ባለቤትነትን ያረጋግጣል ፡፡
        //  - የ `*mut T` እና `Self` አሰላለፍ ከዚህ በላይ በተረጋገጠው በ rust በሚደገፉ ሁሉም መድረኮች ላይ አንድ አይነት ነው።
        //
        unsafe { &*(v as *mut *mut T as *mut Self) }
    }

    /// አቶሚክን ይበላል እና የያዘውን እሴት ይመልሳል።
    ///
    /// `self` ን በእሴት ማለፍ ሌላ ምንም ክሮች በተመሳሳይ ጊዜ የአቶሚክ መረጃን እንደማያገኙ ዋስትና ስለሚሰጥ ይህ ደህንነቱ የተጠበቀ ነው።
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicPtr;
    ///
    /// let atomic_ptr = AtomicPtr::new(&mut 5);
    /// assert_eq!(unsafe { *atomic_ptr.into_inner() }, 5);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> *mut T {
        self.p.into_inner()
    }

    /// ከጠቋሚው እሴት ይጫናል።
    ///
    /// `load` የዚህን ክዋኔ ማህደረ ትውስታ ቅደም ተከተል የሚገልጽ የ [`Ordering`] ክርክር ይወስዳል።
    /// ሊሆኑ የሚችሉ እሴቶች [`SeqCst`] ፣ [`Acquire`] እና [`Relaxed`] ናቸው ፡፡
    ///
    /// # Panics
    ///
    /// `order` [`Release`] ወይም [`AcqRel`] ከሆነ Panics
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let value = some_ptr.load(Ordering::Relaxed);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn load(&self, order: Ordering) -> *mut T {
        // ደህንነት የውሂብ ውድድሮች በአቶሚክ ውስጣዊ ነገሮች ተከልክለዋል ፡፡
        unsafe { atomic_load(self.p.get(), order) }
    }

    /// ወደ ጠቋሚው እሴት ያከማቻል።
    ///
    /// `store` የዚህን ክዋኔ ማህደረ ትውስታ ቅደም ተከተል የሚገልጽ የ [`Ordering`] ክርክር ይወስዳል።
    /// ሊሆኑ የሚችሉ እሴቶች [`SeqCst`] ፣ [`Release`] እና [`Relaxed`] ናቸው ፡፡
    ///
    /// # Panics
    ///
    /// `order` [`Acquire`] ወይም [`AcqRel`] ከሆነ Panics
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr = &mut 10;
    ///
    /// some_ptr.store(other_ptr, Ordering::Relaxed);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn store(&self, ptr: *mut T, order: Ordering) {
        // ደህንነት የውሂብ ውድድሮች በአቶሚክ ውስጣዊ ነገሮች ተከልክለዋል ፡፡
        unsafe {
            atomic_store(self.p.get(), ptr, order);
        }
    }

    /// የቀደመውን እሴት በመመለስ ጠቋሚ ውስጥ እሴት ያከማቻል።
    ///
    /// `swap` የዚህን ክዋኔ የማስታወስ ቅደም ተከተል የሚገልጽ የ [`Ordering`] ክርክር ይወስዳል።ሁሉም የትእዛዝ ሁነታዎች ይቻላል ፡፡
    /// [`Acquire`] ን መጠቀም የዚህ ክወና መደብር [`Relaxed`] ክፍል እንደሚያደርገው ልብ ይበሉ ፣ እና [`Release`] ን በመጠቀም የጭነት ክፍልን [`Relaxed`] ያደርገዋል።
    ///
    ///
    /// **Note:** ይህ ዘዴ በጠቋሚዎች ላይ የአቶሚክ ሥራዎችን በሚደግፉ መድረኮች ላይ ብቻ ይገኛል ፡፡
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr = &mut 10;
    ///
    /// let value = some_ptr.swap(other_ptr, Ordering::Relaxed);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn swap(&self, ptr: *mut T, order: Ordering) -> *mut T {
        // ደህንነት የውሂብ ውድድሮች በአቶሚክ ውስጣዊ ነገሮች ተከልክለዋል ፡፡
        unsafe { atomic_swap(self.p.get(), ptr, order) }
    }

    /// የአሁኑ ዋጋ ከ `current` እሴት ጋር ተመሳሳይ ከሆነ ወደ ጠቋሚው እሴት ያከማቻል።
    ///
    /// የመመለሻ እሴት ሁልጊዜ የቀደመው እሴት ነው።ከ `current` ጋር እኩል ከሆነ እሴቱ ዘምኗል።
    ///
    /// `compare_and_swap` እንዲሁም የዚህን ክዋኔ የማስታወስ ቅደም ተከተል የሚገልጽ የ [`Ordering`] ክርክር ይወስዳል።
    /// [`AcqRel`] ን በሚጠቀሙበት ጊዜ እንኳን ክዋኔው ሊከሽፍ እንደሚችል እና ስለሆነም የ `Acquire` ጭነት ብቻ እንደሚያከናውን ልብ ይበሉ ፣ ግን የ `Release` ፍቺ የለውም ፡፡
    /// [`Acquire`] ን መጠቀም ከተከሰተ የዚህ ክወና የመደብር ክፍል [`Relaxed`] ያደርገዋል ፣ እና [`Release`] ን በመጠቀም የጭነት ክፍልን [`Relaxed`] ያደርገዋል።
    ///
    /// **Note:** ይህ ዘዴ በጠቋሚዎች ላይ የአቶሚክ ሥራዎችን በሚደግፉ መድረኮች ላይ ብቻ ይገኛል ፡፡
    ///
    /// # ወደ `compare_exchange` እና `compare_exchange_weak` መሰደድ
    ///
    /// `compare_and_swap` ለማስታወሻ ቅደም ተከተል ከሚከተለው ካርታ ጋር ከ `compare_exchange` ጋር እኩል ነው-
    ///
    /// ኦሪጅናል |ስኬት |አለመሳካት
    /// -------- | ------- | -------
    /// ዘና ፈታ |ዘና ፈታ |ዘና ያለ ግዥ |ያግኙ |መልቀቂያ ያግኙ |መልቀቅ |ዘና ያለ AcqRel |AcqRel |SeqCst ን ያግኙ |SeqCst |SeqCst
    ///
    /// `compare_exchange_weak` ንፅፅሩ በሚሳካበት ጊዜም እንኳ በቅጽበት እንዲከሽፍ ይፈቀድለታል ፣ ይህም አነፃፃሪው እና ቀለበቱ በክብ ውስጥ በሚጠቀሙበት ጊዜ አሰባሳቢው የተሻለ የመሰብሰቢያ ኮድ እንዲያመነጭ ያስችለዋል።
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr   = &mut 10;
    ///
    /// let value = some_ptr.compare_and_swap(ptr, other_ptr, Ordering::Relaxed);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.50.0",
        reason = "Use `compare_exchange` or `compare_exchange_weak` instead"
    )]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_and_swap(&self, current: *mut T, new: *mut T, order: Ordering) -> *mut T {
        match self.compare_exchange(current, new, order, strongest_failure_ordering(order)) {
            Ok(x) => x,
            Err(x) => x,
        }
    }

    /// የአሁኑ ዋጋ ከ `current` እሴት ጋር ተመሳሳይ ከሆነ ወደ ጠቋሚው እሴት ያከማቻል።
    ///
    /// የመመለሻ ዋጋ አዲሱ እሴት እንደተፃፈ እና የቀደመውን እሴት መያዙን የሚያመለክት ውጤት ነው ፡፡
    /// በስኬት ላይ ይህ እሴት ከ `current` ጋር እኩል እንደሚሆን የተረጋገጠ ነው ፡፡
    ///
    /// `compare_exchange` የዚህን ክዋኔ የማስታወስ ቅደም ተከተል ለማስረዳት ሁለት [`Ordering`] ክርክሮችን ይወስዳል ፡፡
    /// `success` ከ `current` ጋር ያለው ንፅፅር ከተሳካ ለሚከናወነው የንባብ-ማሻሻያ-የመፃፍ ሥራ አስፈላጊ የሆነውን ትዕዛዝ ያብራራል።
    /// `failure` ንፅፅሩ ሳይሳካ ሲቀር ለሚከናወነው የጭነት ሥራ የሚያስፈልገውን ቅደም ተከተል ይገልጻል ፡፡
    /// [`Acquire`] ን እንደ ስኬት ማዘዣ መጠቀሙ የዚህ ክዋኔ ሱቅ [`Relaxed`] አካል ያደርገዋል ፣ እና [`Release`] ን በመጠቀም የተሳካ ጭነት [`Relaxed`] ያደርገዋል።
    ///
    /// የስህተት ማዘዣው [`SeqCst`] ፣ [`Acquire`] ወይም [`Relaxed`] ብቻ ሊሆን ይችላል እና ከስኬት ማዘዣው ጋር እኩል ወይም ደካማ መሆን አለበት።
    ///
    /// **Note:** ይህ ዘዴ በጠቋሚዎች ላይ የአቶሚክ ሥራዎችን በሚደግፉ መድረኮች ላይ ብቻ ይገኛል ፡፡
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr   = &mut 10;
    ///
    /// let value = some_ptr.compare_exchange(ptr, other_ptr,
    ///                                       Ordering::SeqCst, Ordering::Relaxed);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_exchange(
        &self,
        current: *mut T,
        new: *mut T,
        success: Ordering,
        failure: Ordering,
    ) -> Result<*mut T, *mut T> {
        // ደህንነት የውሂብ ውድድሮች በአቶሚክ ውስጣዊ ነገሮች ተከልክለዋል ፡፡
        unsafe { atomic_compare_exchange(self.p.get(), current, new, success, failure) }
    }

    /// የአሁኑ ዋጋ ከ `current` እሴት ጋር ተመሳሳይ ከሆነ ወደ ጠቋሚው እሴት ያከማቻል።
    ///
    /// ከኤክስኤክስኤክስክስክስክስክስክስክስክስክስክስክስክስክስክስክስክስክስክስክስክስ ([`AtomicPtr::compare_exchange`]) በተለየ መልኩ ይህ ተግባር በአንዳንድ መድረኮች ላይ የበለጠ ቀልጣፋ ኮድ ሊያመጣ የሚችል ንፅፅር በሚሳካበት ጊዜም እንኳ በጥቂቱ እንዲከሽፍ ይፈቀድለታል ፡፡
    ///
    /// የመመለሻ ዋጋ አዲሱ እሴት እንደተፃፈ እና የቀደመውን እሴት መያዙን የሚያመለክት ውጤት ነው ፡፡
    ///
    /// `compare_exchange_weak` የዚህን ክዋኔ የማስታወስ ቅደም ተከተል ለማስረዳት ሁለት [`Ordering`] ክርክሮችን ይወስዳል ፡፡
    /// `success` ከ `current` ጋር ያለው ንፅፅር ከተሳካ ለሚከናወነው የንባብ-ማሻሻያ-የመፃፍ ሥራ አስፈላጊ የሆነውን ትዕዛዝ ያብራራል።
    /// `failure` ንፅፅሩ ሳይሳካ ሲቀር ለሚከናወነው የጭነት ሥራ የሚያስፈልገውን ቅደም ተከተል ይገልጻል ፡፡
    /// [`Acquire`] ን እንደ ስኬት ማዘዣ መጠቀሙ የዚህ ክዋኔ ሱቅ [`Relaxed`] አካል ያደርገዋል ፣ እና [`Release`] ን በመጠቀም የተሳካ ጭነት [`Relaxed`] ያደርገዋል።
    /// የስህተት ማዘዣው [`SeqCst`] ፣ [`Acquire`] ወይም [`Relaxed`] ብቻ ሊሆን ይችላል እና ከስኬት ማዘዣው ጋር እኩል ወይም ደካማ መሆን አለበት።
    ///
    /// **Note:** ይህ ዘዴ በጠቋሚዎች ላይ የአቶሚክ ሥራዎችን በሚደግፉ መድረኮች ላይ ብቻ ይገኛል ፡፡
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let some_ptr = AtomicPtr::new(&mut 5);
    ///
    /// let new = &mut 10;
    /// let mut old = some_ptr.load(Ordering::Relaxed);
    /// loop {
    ///     match some_ptr.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) {
    ///         Ok(_) => break,
    ///         Err(x) => old = x,
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_exchange_weak(
        &self,
        current: *mut T,
        new: *mut T,
        success: Ordering,
        failure: Ordering,
    ) -> Result<*mut T, *mut T> {
        // ደህንነት-ይህ መሠረታዊ ነገር በጥሬ ጠቋሚ ላይ ስለሚሠራ ደህንነቱ የተጠበቀ ነው
        // ነገር ግን ጠቋሚው ትክክለኛ መሆኑን እናውቃለን (አሁን ያገኘነው በማጣቀሻ ካገኘነው `UnsafeCell` ነው) እና የአቶሚክ አሠራር ራሱ የ `UnsafeCell` ይዘቶችን በደህና ለመለወጥ ያስችለናል ፡፡
        //
        //
        unsafe { atomic_compare_exchange_weak(self.p.get(), current, new, success, failure) }
    }

    /// እሴቱን ያወጣል እና አማራጭ አዲስ እሴትን የሚያስመልስ ተግባርን በእሱ ላይ ይተገበራል።ተግባሩ `Some(_)` ን ከተመለሰ ሌላ `Err(previous_value)` ከሆነ የ `Result` የ `Ok(previous_value)` ይመልሳል።
    ///
    /// Note: ተግባሩ `Some(_)` ን እስከመለሰ ድረስ እሴቱ ከሌላው ክሮች ውስጥ እሴቱ ከተቀየረ ይህ ተግባሩን ብዙ ጊዜ ሊጠራው ይችላል ፣ ነገር ግን ተግባሩ ለተከማቸው እሴት አንድ ጊዜ ብቻ ይተገበራል።
    ///
    ///
    /// `fetch_update` የዚህን ክዋኔ የማስታወስ ቅደም ተከተል ለማስረዳት ሁለት [`Ordering`] ክርክሮችን ይወስዳል ፡፡
    /// የመጀመሪያው ክዋኔው በመጨረሻ ሲሳካ አስፈላጊ የሆነውን ቅደም ተከተል የሚገልጽ ሲሆን ሁለተኛው ደግሞ ስለ ጭነት አስፈላጊ የሆነውን ቅደም ተከተል ይገልጻል ፡፡
    /// እነዚህ በቅደም ተከተል ከ‹[`AtomicPtr::compare_exchange`] X›ስኬት እና ውድቀት ትዕዛዞች ጋር ይዛመዳሉ ፡፡
    ///
    /// [`Acquire`] ን እንደ ስኬት ማዘዣ መጠቀሙ የዚህ ክዋኔ ሱቅ [`Relaxed`] አካል ያደርገዋል ፣ እና [`Release`] ን በመጠቀም የመጨረሻውን ስኬታማ ጭነት [`Relaxed`] ያደርገዋል።
    /// የ (failed) ጭነት ማዘዣ [`SeqCst`] ፣ [`Acquire`] ወይም [`Relaxed`] ብቻ ሊሆን ይችላል እና ከስኬት ማዘዣው ጋር እኩል ወይም ደካማ መሆን አለበት።
    ///
    /// **Note:** ይህ ዘዴ በጠቋሚዎች ላይ የአቶሚክ ሥራዎችን በሚደግፉ መድረኮች ላይ ብቻ ይገኛል ፡፡
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(atomic_fetch_update)]
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr: *mut _ = &mut 5;
    /// let some_ptr = AtomicPtr::new(ptr);
    ///
    /// let new: *mut _ = &mut 10;
    /// assert_eq!(some_ptr.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(ptr));
    /// let result = some_ptr.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| {
    ///     if x == ptr {
    ///         Some(new)
    ///     } else {
    ///         None
    ///     }
    /// });
    /// assert_eq!(result, Ok(ptr));
    /// assert_eq!(some_ptr.load(Ordering::SeqCst), new);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_fetch_update", reason = "recently added", issue = "78639")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn fetch_update<F>(
        &self,
        set_order: Ordering,
        fetch_order: Ordering,
        mut f: F,
    ) -> Result<*mut T, *mut T>
    where
        F: FnMut(*mut T) -> Option<*mut T>,
    {
        let mut prev = self.load(fetch_order);
        while let Some(next) = f(prev) {
            match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                x @ Ok(_) => return x,
                Err(next_prev) => prev = next_prev,
            }
        }
        Err(prev)
    }
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "atomic_bool_from", since = "1.24.0")]
impl From<bool> for AtomicBool {
    /// `bool` ን ወደ `AtomicBool` ይቀይረዋል።
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    /// let atomic_bool = AtomicBool::from(true);
    /// assert_eq!(format!("{:?}", atomic_bool), "true")
    /// ```
    #[inline]
    fn from(b: bool) -> Self {
        Self::new(b)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_from", since = "1.23.0")]
impl<T> From<*mut T> for AtomicPtr<T> {
    #[inline]
    fn from(p: *mut T) -> Self {
        Self::new(p)
    }
}

#[allow(unused_macros)] // ይህ ማክሮ በአንዳንድ የሕንፃ ሕንፃዎች ላይ ጥቅም ላይ ያልዋለ ሆኖ ያበቃል ፡፡
macro_rules! if_not_8_bit {
    (u8, $($tt:tt)*) => { "" };
    (i8, $($tt:tt)*) => { "" };
    ($_:ident, $($tt:tt)*) => { $($tt)* };
}

#[cfg(target_has_atomic_load_store = "8")]
macro_rules! atomic_int {
    ($cfg_cas:meta,
     $cfg_align:meta,
     $stable:meta,
     $stable_cxchg:meta,
     $stable_debug:meta,
     $stable_access:meta,
     $stable_from:meta,
     $stable_nand:meta,
     $const_stable:meta,
     $stable_init_const:meta,
     $s_int_type:literal,
     $extra_feature:expr,
     $min_fn:ident, $max_fn:ident,
     $align:expr,
     $atomic_new:expr,
     $int_type:ident $atomic_type:ident $atomic_init:ident) => {
        /// በክሮች መካከል በደህና ሊጋራ የሚችል የኢቲጀር ዓይነት።
        ///
        /// ይህ አይነት ከስር እንደ ኢንቲጀር ዓይነት ተመሳሳይ የማስታወሻ ውክልና አለው ፣ [`
        ///
        #[doc = $s_int_type]
        /// `].
        /// በአቶሚክ አይነቶች እና በአቶሚክ ዓይነቶች መካከል ስላለው ልዩነት እንዲሁም ስለ የዚህ አይነት ተንቀሳቃሽነት መረጃ እባክዎን [module-level documentation] ን ይመልከቱ ፡፡
        ///
        ///
        /// **Note:** ይህ አይነት የሚገኘው የአቶሚክ ጭነቶች እና የ `` መደብሮች በሚደግፉ መድረኮች ላይ ብቻ ነው
        ///
        #[doc = $s_int_type]
        /// `].
        ///
        /// [module-level documentation]: crate::sync::atomic
        #[$stable]
        #[repr(C, align($align))]
        pub struct $atomic_type {
            v: UnsafeCell<$int_type>,
        }

        /// የአቶሚክ ኢንቲጀር ወደ `0` ተጀምሯል።
        #[$stable_init_const]
        #[rustc_deprecated(
            since = "1.34.0",
            reason = "the `new` function is now preferred",
            suggestion = $atomic_new,
        )]
        pub const $atomic_init: $atomic_type = $atomic_type::new(0);

        #[$stable]
        impl Default for $atomic_type {
            #[inline]
            fn default() -> Self {
                Self::new(Default::default())
            }
        }

        #[$stable_from]
        impl From<$int_type> for $atomic_type {
            #[doc = concat!("Converts an `", stringify!($int_type), "` into an `", stringify!($atomic_type), "`.")]
            #[inline]
            fn from(v: $int_type) -> Self { Self::new(v) }
        }

        #[$stable_debug]
        impl fmt::Debug for $atomic_type {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
            }
        }

        // መላክ በተዘዋዋሪ ተተግብሯል ፡፡
        #[$stable]
        unsafe impl Sync for $atomic_type {}

        impl $atomic_type {
            /// አዲስ የአቶሚክ ኢንቲጀር ይፈጥራል።
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]

            #[doc = concat!("let atomic_forty_two = ", stringify!($atomic_type), "::new(42);")]
            /// ```
            #[inline]
            #[$stable]
            #[$const_stable]
            pub const fn new(v: $int_type) -> Self {
                Self {v: UnsafeCell::new(v)}
            }

            /// ለታችኛው ኢንቲጀር የሚለዋወጥ ማጣቀሻ ይመልሳል።
            ///
            /// ይህ ደህንነቱ የተጠበቀ ነው ፣ ምክንያቱም የሚለዋወጥ ማጣቀሻ ሌሎች ክሮች በተመሳሳይ ጊዜ የአቶሚክ መረጃን እንደማይደርሱ ዋስትና ይሰጣል።
            ///
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let mut some_var = ", stringify!($atomic_type), "::new(10);")]
            /// assert_eq!(*some_var.get_mut(), 10);
            /// *some_var.get_mut() =5;
            /// assert_eq!(some_var.load(Ordering::SeqCst), 5);
            /// ```
            #[inline]
            #[$stable_access]
            pub fn get_mut(&mut self) -> &mut $int_type {
                self.v.get_mut()
            }

            #[doc = concat!("Get atomic access to a `&mut ", stringify!($int_type), "`.")]

            #[doc = if_not_8_bit! {
                $int_type,
                concat!(
                    "**Note:** This function is only available on targets where `",
                    stringify!($int_type), "` has an alignment of ", $align, " bytes."
                )
            }]
            /// # Examples
            ///
            /// ```
            /// #![feature(atomic_from_mut)]
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]
            /// mut some_int=123;
            #[doc = concat!("let a = ", stringify!($atomic_type), "::from_mut(&mut some_int);")]
            /// a.store(100, Ordering::Relaxed);
            ///
            /// አረጋግጥ! (የተወሰነ_ንት ፣ 100);
            /// ```
            #[inline]
            #[$cfg_align]
            #[unstable(feature = "atomic_from_mut", issue = "76314")]
            pub fn from_mut(v: &mut $int_type) -> &Self {
                use crate::mem::align_of;
                let [] = [(); align_of::<Self>() - align_of::<$int_type>()];
                // SAFETY:
                //  - ሊለዋወጥ የሚችል ማጣቀሻ ልዩ ባለቤትነትን ያረጋግጣል ፡፡
                //  - የ `$int_type` እና `Self` አሰላለፍ በ $cfg_align እንደታሰበው እና ከላይ እንደተረጋገጠው ተመሳሳይ ነው።
                //
                unsafe { &*(v as *mut $int_type as *mut Self) }
            }

            /// አቶሚክን ይበላል እና የያዘውን እሴት ይመልሳል።
            ///
            /// `self` ን በእሴት ማለፍ ሌላ ምንም ክሮች በተመሳሳይ ጊዜ የአቶሚክ መረጃን እንደማያገኙ ዋስትና ስለሚሰጥ ይህ ደህንነቱ የተጠበቀ ነው።
            ///
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.into_inner(), 5);
            /// ```
            #[inline]
            #[$stable_access]
            #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
            pub const fn into_inner(self) -> $int_type {
                self.v.into_inner()
            }

            /// እሴት ከአቶሚክ ኢንቲጀር ይጫናል።
            ///
            /// `load` የዚህን ክዋኔ ማህደረ ትውስታ ቅደም ተከተል የሚገልጽ የ [`Ordering`] ክርክር ይወስዳል።
            /// ሊሆኑ የሚችሉ እሴቶች [`SeqCst`] ፣ [`Acquire`] እና [`Relaxed`] ናቸው ፡፡
            ///
            /// # Panics
            ///
            /// `order` [`Release`] ወይም [`AcqRel`] ከሆነ Panics
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.load(Ordering::Relaxed), 5);
            /// ```
            #[inline]
            #[$stable]
            pub fn load(&self, order: Ordering) -> $int_type {
                // ደህንነት የውሂብ ውድድሮች በአቶሚክ ውስጣዊ ነገሮች ተከልክለዋል ፡፡
                unsafe { atomic_load(self.v.get(), order) }
            }

            /// እሴት ወደ አቶሚክ ኢንቲጀር ያከማቻል።
            ///
            /// `store` የዚህን ክዋኔ ማህደረ ትውስታ ቅደም ተከተል የሚገልጽ የ [`Ordering`] ክርክር ይወስዳል።
            ///  ሊሆኑ የሚችሉ እሴቶች [`SeqCst`] ፣ [`Release`] እና [`Relaxed`] ናቸው ፡፡
            ///
            /// # Panics
            ///
            /// `order` [`Acquire`] ወይም [`AcqRel`] ከሆነ Panics
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// some_var.store(10, Ordering::Relaxed);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            #[inline]
            #[$stable]
            pub fn store(&self, val: $int_type, order: Ordering) {
                // ደህንነት የውሂብ ውድድሮች በአቶሚክ ውስጣዊ ነገሮች ተከልክለዋል ፡፡
                unsafe { atomic_store(self.v.get(), val, order); }
            }

            /// የቀደመውን እሴት በመመለስ በአቶሚክ ኢንቲጀር ውስጥ እሴት ያከማቻል።
            ///
            /// `swap` የዚህን ክዋኔ የማስታወስ ቅደም ተከተል የሚገልጽ የ [`Ordering`] ክርክር ይወስዳል።ሁሉም የትእዛዝ ሁነታዎች ይቻላል ፡፡
            /// [`Acquire`] ን መጠቀም የዚህ ክወና መደብር [`Relaxed`] ክፍል እንደሚያደርገው ልብ ይበሉ ፣ እና [`Release`] ን በመጠቀም የጭነት ክፍልን [`Relaxed`] ያደርገዋል።
            ///
            ///
            /// **ማስታወሻ**-ይህ ዘዴ የሚገኘው የአቶሚክ አሠራሮችን በሚደግፉ መድረኮች ላይ ብቻ ነው
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.swap(10, Ordering::Relaxed), 5);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn swap(&self, val: $int_type, order: Ordering) -> $int_type {
                // ደህንነት የውሂብ ውድድሮች በአቶሚክ ውስጣዊ ነገሮች ተከልክለዋል ፡፡
                unsafe { atomic_swap(self.v.get(), val, order) }
            }

            /// የአሁኑ ዋጋ ከ‹XXXXXXXXXXX›ዋጋ ጋር ተመሳሳይ ከሆነ እሴት ወደ አቶሚክ ኢንቲጀር ያከማቻል ፡፡
            ///
            /// የመመለሻ እሴት ሁልጊዜ የቀደመው እሴት ነው።ከ `current` ጋር እኩል ከሆነ እሴቱ ዘምኗል።
            ///
            /// `compare_and_swap` እንዲሁም የዚህን ክዋኔ የማስታወስ ቅደም ተከተል የሚገልጽ የ [`Ordering`] ክርክር ይወስዳል።
            /// [`AcqRel`] ን በሚጠቀሙበት ጊዜ እንኳን ክዋኔው ሊከሽፍ እንደሚችል እና ስለሆነም የ `Acquire` ጭነት ብቻ እንደሚያከናውን ልብ ይበሉ ፣ ግን የ `Release` ፍቺ የለውም ፡፡
            ///
            /// [`Acquire`] ን መጠቀም ከተከሰተ የዚህ ክወና የመደብር ክፍል [`Relaxed`] ያደርገዋል ፣ እና [`Release`] ን በመጠቀም የጭነት ክፍልን [`Relaxed`] ያደርገዋል።
            ///
            /// **ማስታወሻ**-ይህ ዘዴ የሚገኘው የአቶሚክ አሠራሮችን በሚደግፉ መድረኮች ላይ ብቻ ነው
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # ወደ `compare_exchange` እና `compare_exchange_weak` መሰደድ
            ///
            /// `compare_and_swap` ለማስታወሻ ቅደም ተከተል ከሚከተለው ካርታ ጋር ከ `compare_exchange` ጋር እኩል ነው-
            ///
            /// ኦሪጅናል |ስኬት |አለመሳካት
            /// -------- | ------- | -------
            /// ዘና ፈታ |ዘና ፈታ |ዘና ያለ ግዥ |ያግኙ |መልቀቂያ ያግኙ |መልቀቅ |ዘና ያለ AcqRel |AcqRel |SeqCst ን ያግኙ |SeqCst |SeqCst
            ///
            /// `compare_exchange_weak` ንፅፅሩ በሚሳካበት ጊዜም እንኳ በቅጽበት እንዲከሽፍ ይፈቀድለታል ፣ ይህም አነፃፃሪው እና ቀለበቱ በክብ ውስጥ በሚጠቀሙበት ጊዜ አሰባሳቢው የተሻለ የመሰብሰቢያ ኮድ እንዲያመነጭ ያስችለዋል።
            ///
            ///
            /// # Examples
            ///
            /// ```
            ///
            ///
            ///
            ///
            ///
            ///
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.compare_and_swap(5, 10, Ordering::Relaxed), 5);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            ///
            /// assert_eq!(some_var.compare_and_swap(6, 12, Ordering::Relaxed), 10);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            #[inline]
            #[$stable]
            #[rustc_deprecated(
                since = "1.50.0",
                reason = "Use `compare_exchange` or `compare_exchange_weak` instead")
            ]
            #[$cfg_cas]
            pub fn compare_and_swap(&self,
                                    current: $int_type,
                                    new: $int_type,
                                    order: Ordering) -> $int_type {
                match self.compare_exchange(current,
                                            new,
                                            order,
                                            strongest_failure_ordering(order)) {
                    Ok(x) => x,
                    Err(x) => x,
                }
            }

            /// የአሁኑ ዋጋ ከ‹XXXXXXXXXXX›ዋጋ ጋር ተመሳሳይ ከሆነ እሴት ወደ አቶሚክ ኢንቲጀር ያከማቻል ፡፡
            ///
            /// የመመለሻ ዋጋ አዲሱ እሴት እንደተፃፈ እና የቀደመውን እሴት መያዙን የሚያመለክት ውጤት ነው ፡፡
            /// በስኬት ላይ ይህ እሴት ከ `current` ጋር እኩል እንደሚሆን የተረጋገጠ ነው ፡፡
            ///
            /// `compare_exchange` የዚህን ክዋኔ የማስታወስ ቅደም ተከተል ለማስረዳት ሁለት [`Ordering`] ክርክሮችን ይወስዳል ፡፡
            /// `success` ከ `current` ጋር ያለው ንፅፅር ከተሳካ ለሚከናወነው የንባብ-ማሻሻያ-የመፃፍ ሥራ አስፈላጊ የሆነውን ትዕዛዝ ያብራራል።
            /// `failure` ንፅፅሩ ሳይሳካ ሲቀር ለሚከናወነው የጭነት ሥራ የሚያስፈልገውን ቅደም ተከተል ይገልጻል ፡፡
            /// [`Acquire`] ን እንደ ስኬት ማዘዣ መጠቀሙ የዚህ ክዋኔ ሱቅ [`Relaxed`] አካል ያደርገዋል ፣ እና [`Release`] ን በመጠቀም የተሳካ ጭነት [`Relaxed`] ያደርገዋል።
            ///
            /// የስህተት ማዘዣው [`SeqCst`] ፣ [`Acquire`] ወይም [`Relaxed`] ብቻ ሊሆን ይችላል እና ከስኬት ማዘዣው ጋር እኩል ወይም ደካማ መሆን አለበት።
            ///
            /// **ማስታወሻ**-ይህ ዘዴ የሚገኘው የአቶሚክ አሠራሮችን በሚደግፉ መድረኮች ላይ ብቻ ነው
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.compare_exchange(5, 10,                                      Ordering::Acquire,                                      Ordering::Relaxed),
            ///
            ///            Ok(5));
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            ///
            /// assert_eq!(some_var.compare_exchange(6, 12,                                      Ordering::SeqCst,                                      Ordering::Acquire),
            ///            Err(10));
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            ///
            ///
            ///
            #[inline]
            #[$stable_cxchg]
            #[$cfg_cas]
            pub fn compare_exchange(&self,
                                    current: $int_type,
                                    new: $int_type,
                                    success: Ordering,
                                    failure: Ordering) -> Result<$int_type, $int_type> {
                // ደህንነት የውሂብ ውድድሮች በአቶሚክ ውስጣዊ ነገሮች ተከልክለዋል ፡፡
                unsafe { atomic_compare_exchange(self.v.get(), current, new, success, failure) }
            }

            /// የአሁኑ ዋጋ ከ‹XXXXXXXXXXX›ዋጋ ጋር ተመሳሳይ ከሆነ እሴት ወደ አቶሚክ ኢንቲጀር ያከማቻል ፡፡
            ///
            ///
            #[doc = concat!("Unlike [`", stringify!($atomic_type), "::compare_exchange`],")]
            /// ይህ ተግባር ንፅፅሩ በሚሳካበት ጊዜም እንኳ በስህተት እንዲከሽፍ ይፈቀድለታል ፣ ይህም በአንዳንድ መድረኮች ላይ የበለጠ ቀልጣፋ ኮድ ያስከትላል።
            /// የመመለሻ ዋጋ አዲሱ እሴት እንደተፃፈ እና የቀደመውን እሴት መያዙን የሚያመለክት ውጤት ነው ፡፡
            ///
            /// `compare_exchange_weak` የዚህን ክዋኔ የማስታወስ ቅደም ተከተል ለማስረዳት ሁለት [`Ordering`] ክርክሮችን ይወስዳል ፡፡
            /// `success` ከ `current` ጋር ያለው ንፅፅር ከተሳካ ለሚከናወነው የንባብ-ማሻሻያ-የመፃፍ ሥራ አስፈላጊ የሆነውን ትዕዛዝ ያብራራል።
            /// `failure` ንፅፅሩ ሳይሳካ ሲቀር ለሚከናወነው የጭነት ሥራ የሚያስፈልገውን ቅደም ተከተል ይገልጻል ፡፡
            /// [`Acquire`] ን እንደ ስኬት ማዘዣ መጠቀሙ የዚህ ክዋኔ ሱቅ [`Relaxed`] አካል ያደርገዋል ፣ እና [`Release`] ን በመጠቀም የተሳካ ጭነት [`Relaxed`] ያደርገዋል።
            ///
            /// የስህተት ማዘዣው [`SeqCst`] ፣ [`Acquire`] ወይም [`Relaxed`] ብቻ ሊሆን ይችላል እና ከስኬት ማዘዣው ጋር እኩል ወይም ደካማ መሆን አለበት።
            ///
            /// **ማስታወሻ**-ይህ ዘዴ የሚገኘው የአቶሚክ አሠራሮችን በሚደግፉ መድረኮች ላይ ብቻ ነው
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let val = ", stringify!($atomic_type), "::new(4);")]
            /// ሙት አሮጌ ይሁን= val.load(Ordering::Relaxed);
            /// loop {let አዲስ=አሮጌ * 2;
            ///     ግጥሚያ val.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) { Ok(_) => break, Err(x) => old = x, }}
            ///
            /// ```
            ///
            ///
            ///
            ///
            #[inline]
            #[$stable_cxchg]
            #[$cfg_cas]
            pub fn compare_exchange_weak(&self,
                                         current: $int_type,
                                         new: $int_type,
                                         success: Ordering,
                                         failure: Ordering) -> Result<$int_type, $int_type> {
                // ደህንነት የውሂብ ውድድሮች በአቶሚክ ውስጣዊ ነገሮች ተከልክለዋል ፡፡
                unsafe {
                    atomic_compare_exchange_weak(self.v.get(), current, new, success, failure)
                }
            }

            /// የቀደመውን እሴት በመመለስ አሁን ባለው እሴት ላይ ይጨምራል።
            ///
            /// ይህ ክዋኔ በተትረፈረፈ መጠን ዙሪያውን ያጠቃልላል ፡፡
            ///
            /// `fetch_add` የዚህን ክዋኔ የማስታወስ ቅደም ተከተል የሚገልጽ የ [`Ordering`] ክርክር ይወስዳል።ሁሉም የትእዛዝ ሁነታዎች ይቻላል ፡፡
            /// [`Acquire`] ን መጠቀም የዚህ ክወና መደብር [`Relaxed`] ክፍል እንደሚያደርገው ልብ ይበሉ ፣ እና [`Release`] ን በመጠቀም የጭነት ክፍልን [`Relaxed`] ያደርገዋል።
            ///
            ///
            /// **ማስታወሻ**-ይህ ዘዴ የሚገኘው የአቶሚክ አሠራሮችን በሚደግፉ መድረኮች ላይ ብቻ ነው
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0);")]
            /// assert_eq!(foo.fetch_add(10, Ordering::SeqCst), 0);
            /// assert_eq!(foo.load(Ordering::SeqCst), 10);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_add(&self, val: $int_type, order: Ordering) -> $int_type {
                // ደህንነት የውሂብ ውድድሮች በአቶሚክ ውስጣዊ ነገሮች ተከልክለዋል ፡፡
                unsafe { atomic_add(self.v.get(), val, order) }
            }

            /// የቀደመውን እሴት በመመለስ ከአሁኑ እሴት ንዑስ።
            ///
            /// ይህ ክዋኔ በተትረፈረፈ መጠን ዙሪያውን ያጠቃልላል ፡፡
            ///
            /// `fetch_sub` የዚህን ክዋኔ የማስታወስ ቅደም ተከተል የሚገልጽ የ [`Ordering`] ክርክር ይወስዳል።ሁሉም የትእዛዝ ሁነታዎች ይቻላል ፡፡
            /// [`Acquire`] ን መጠቀም የዚህ ክወና መደብር [`Relaxed`] ክፍል እንደሚያደርገው ልብ ይበሉ ፣ እና [`Release`] ን በመጠቀም የጭነት ክፍልን [`Relaxed`] ያደርገዋል።
            ///
            ///
            /// **ማስታወሻ**-ይህ ዘዴ የሚገኘው የአቶሚክ አሠራሮችን በሚደግፉ መድረኮች ላይ ብቻ ነው
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(20);")]
            /// assert_eq!(foo.fetch_sub(10, Ordering::SeqCst), 20);
            /// assert_eq!(foo.load(Ordering::SeqCst), 10);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_sub(&self, val: $int_type, order: Ordering) -> $int_type {
                // ደህንነት የውሂብ ውድድሮች በአቶሚክ ውስጣዊ ነገሮች ተከልክለዋል ፡፡
                unsafe { atomic_sub(self.v.get(), val, order) }
            }

            /// Bitwise "and" ከአሁኑ እሴት ጋር።
            ///
            /// አሁን ባለው እሴት እና በክርክሩ `val` ላይ በትንሹ የ "and" ክዋኔን ያከናውን እና አዲሱን እሴት ለውጤቱ ያዘጋጃል።
            ///
            /// የቀደመውን እሴት ይመልሳል።
            ///
            /// `fetch_and` የዚህን ክዋኔ የማስታወስ ቅደም ተከተል የሚገልጽ የ [`Ordering`] ክርክር ይወስዳል።ሁሉም የትእዛዝ ሁነታዎች ይቻላል ፡፡
            /// [`Acquire`] ን መጠቀም የዚህ ክወና መደብር [`Relaxed`] ክፍል እንደሚያደርገው ልብ ይበሉ ፣ እና [`Release`] ን በመጠቀም የጭነት ክፍልን [`Relaxed`] ያደርገዋል።
            ///
            ///
            /// **ማስታወሻ**-ይህ ዘዴ የሚገኘው የአቶሚክ አሠራሮችን በሚደግፉ መድረኮች ላይ ብቻ ነው
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_and(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b100001);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_and(&self, val: $int_type, order: Ordering) -> $int_type {
                // ደህንነት የውሂብ ውድድሮች በአቶሚክ ውስጣዊ ነገሮች ተከልክለዋል ፡፡
                unsafe { atomic_and(self.v.get(), val, order) }
            }

            /// Bitwise "nand" ከአሁኑ እሴት ጋር።
            ///
            /// አሁን ባለው እሴት እና በክርክሩ `val` ላይ በትንሹ የ "nand" ክዋኔን ያከናውን እና አዲሱን እሴት ለውጤቱ ያዘጋጃል።
            ///
            /// የቀደመውን እሴት ይመልሳል።
            ///
            /// `fetch_nand` የዚህን ክዋኔ የማስታወስ ቅደም ተከተል የሚገልጽ የ [`Ordering`] ክርክር ይወስዳል።ሁሉም የትእዛዝ ሁነታዎች ይቻላል ፡፡
            /// [`Acquire`] ን መጠቀም የዚህ ክወና መደብር [`Relaxed`] ክፍል እንደሚያደርገው ልብ ይበሉ ፣ እና [`Release`] ን በመጠቀም የጭነት ክፍልን [`Relaxed`] ያደርገዋል።
            ///
            ///
            /// **ማስታወሻ**-ይህ ዘዴ የሚገኘው የአቶሚክ አሠራሮችን በሚደግፉ መድረኮች ላይ ብቻ ነው
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0x13);")]
            /// assert_eq!(foo.fetch_nand(0x31, Ordering::SeqCst), 0x13);
            /// assert_eq!(foo.load(Ordering::SeqCst), (0x13 እና 0x31));
            /// ```
            #[inline]
            #[$stable_nand]
            #[$cfg_cas]
            pub fn fetch_nand(&self, val: $int_type, order: Ordering) -> $int_type {
                // ደህንነት የውሂብ ውድድሮች በአቶሚክ ውስጣዊ ነገሮች ተከልክለዋል ፡፡
                unsafe { atomic_nand(self.v.get(), val, order) }
            }

            /// Bitwise "or" ከአሁኑ እሴት ጋር።
            ///
            /// አሁን ባለው እሴት እና በክርክሩ `val` ላይ በትንሹ የ "or" ክዋኔን ያከናውን እና አዲሱን እሴት ለውጤቱ ያወጣል ፡፡
            ///
            /// የቀደመውን እሴት ይመልሳል።
            ///
            /// `fetch_or` የዚህን ክዋኔ የማስታወስ ቅደም ተከተል የሚገልጽ የ [`Ordering`] ክርክር ይወስዳል።ሁሉም የትእዛዝ ሁነታዎች ይቻላል ፡፡
            /// [`Acquire`] ን መጠቀም የዚህ ክወና መደብር [`Relaxed`] ክፍል እንደሚያደርገው ልብ ይበሉ ፣ እና [`Release`] ን በመጠቀም የጭነት ክፍልን [`Relaxed`] ያደርገዋል።
            ///
            ///
            /// **ማስታወሻ**-ይህ ዘዴ የሚገኘው የአቶሚክ አሠራሮችን በሚደግፉ መድረኮች ላይ ብቻ ነው
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_or(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b111111);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_or(&self, val: $int_type, order: Ordering) -> $int_type {
                // ደህንነት የውሂብ ውድድሮች በአቶሚክ ውስጣዊ ነገሮች ተከልክለዋል ፡፡
                unsafe { atomic_or(self.v.get(), val, order) }
            }

            /// Bitwise "xor" ከአሁኑ እሴት ጋር።
            ///
            /// አሁን ባለው እሴት እና በክርክሩ `val` ላይ በትንሹ የ "xor" ክዋኔን ያከናውን እና አዲሱን እሴት ለውጤቱ ያዘጋጃል።
            ///
            /// የቀደመውን እሴት ይመልሳል።
            ///
            /// `fetch_xor` የዚህን ክዋኔ የማስታወስ ቅደም ተከተል የሚገልጽ የ [`Ordering`] ክርክር ይወስዳል።ሁሉም የትእዛዝ ሁነታዎች ይቻላል ፡፡
            /// [`Acquire`] ን መጠቀም የዚህ ክወና መደብር [`Relaxed`] ክፍል እንደሚያደርገው ልብ ይበሉ ፣ እና [`Release`] ን በመጠቀም የጭነት ክፍልን [`Relaxed`] ያደርገዋል።
            ///
            ///
            /// **ማስታወሻ**-ይህ ዘዴ የሚገኘው የአቶሚክ አሠራሮችን በሚደግፉ መድረኮች ላይ ብቻ ነው
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_xor(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b011110);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_xor(&self, val: $int_type, order: Ordering) -> $int_type {
                // ደህንነት የውሂብ ውድድሮች በአቶሚክ ውስጣዊ ነገሮች ተከልክለዋል ፡፡
                unsafe { atomic_xor(self.v.get(), val, order) }
            }

            /// እሴቱን ያወጣል እና አማራጭ አዲስ እሴትን የሚያስመልስ ተግባርን በእሱ ላይ ይተገበራል።ተግባሩ `Some(_)` ን ከተመለሰ ሌላ `Err(previous_value)` ከሆነ የ `Result` የ `Ok(previous_value)` ይመልሳል።
            ///
            /// Note: ተግባሩ `Some(_)` ን እስከመለሰ ድረስ እሴቱ ከሌላው ክሮች ውስጥ እሴቱ ከተቀየረ ይህ ተግባሩን ብዙ ጊዜ ሊጠራው ይችላል ፣ ነገር ግን ተግባሩ ለተከማቸው እሴት አንድ ጊዜ ብቻ ይተገበራል።
            ///
            ///
            /// `fetch_update` የዚህን ክዋኔ የማስታወስ ቅደም ተከተል ለማስረዳት ሁለት [`Ordering`] ክርክሮችን ይወስዳል ፡፡
            /// የመጀመሪያው ክዋኔው በመጨረሻ ሲሳካ አስፈላጊ የሆነውን ቅደም ተከተል የሚገልጽ ሲሆን ሁለተኛው ደግሞ ስለ ጭነት አስፈላጊ የሆነውን ቅደም ተከተል ይገልጻል ፡፡እነዚህ ከ‹ስኬት እና ውድቀት ትዕዛዞች›ጋር ይዛመዳሉ
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", stringify!($atomic_type), "::compare_exchange`]")]
            /// respectively.
            ///
            /// [`Acquire`] ን እንደ ስኬት ማዘዣ መጠቀሙ የዚህ ክዋኔ ሱቅ [`Relaxed`] አካል ያደርገዋል ፣ እና [`Release`] ን በመጠቀም የመጨረሻውን ስኬታማ ጭነት [`Relaxed`] ያደርገዋል።
            /// የ (failed) ጭነት ማዘዣ [`SeqCst`] ፣ [`Acquire`] ወይም [`Relaxed`] ብቻ ሊሆን ይችላል እና ከስኬት ማዘዣው ጋር እኩል ወይም ደካማ መሆን አለበት።
            ///
            /// **ማስታወሻ**-ይህ ዘዴ የሚገኘው የአቶሚክ አሠራሮችን በሚደግፉ መድረኮች ላይ ብቻ ነው
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```rust
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let x = ", stringify!($atomic_type), "::new(7);")]
            /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(7));
            /// (x.fetch_update (ማዘዝ: : SeqCst, Ordering::SeqCst, | x | Some(x + 1)),) Ok(7));
            /// (x.fetch_update (ማዘዝ: : SeqCst, Ordering::SeqCst, | x | Some(x + 1)),) Ok(8));
            /// assert_eq!(x.load(Ordering::SeqCst), 9);
            /// ```
            #[inline]
            #[stable(feature = "no_more_cas", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_update<F>(&self,
                                   set_order: Ordering,
                                   fetch_order: Ordering,
                                   mut f: F) -> Result<$int_type, $int_type>
            where F: FnMut($int_type) -> Option<$int_type> {
                let mut prev = self.load(fetch_order);
                while let Some(next) = f(prev) {
                    match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                        x @ Ok(_) => return x,
                        Err(next_prev) => prev = next_prev
                    }
                }
                Err(prev)
            }

            /// ከአሁኑ እሴት ጋር ከፍተኛው ፡፡
            ///
            /// የአሁኑን እሴት እና ክርክሩን `val` ከፍተኛውን ያገኛል እና አዲሱን እሴት ወደ ውጤቱ ያዘጋጃል።
            ///
            /// የቀደመውን እሴት ይመልሳል።
            ///
            /// `fetch_max` የዚህን ክዋኔ የማስታወስ ቅደም ተከተል የሚገልጽ የ [`Ordering`] ክርክር ይወስዳል።ሁሉም የትእዛዝ ሁነታዎች ይቻላል ፡፡
            /// [`Acquire`] ን መጠቀም የዚህ ክወና መደብር [`Relaxed`] ክፍል እንደሚያደርገው ልብ ይበሉ ፣ እና [`Release`] ን በመጠቀም የጭነት ክፍልን [`Relaxed`] ያደርገዋል።
            ///
            ///
            /// **ማስታወሻ**-ይህ ዘዴ የሚገኘው የአቶሚክ አሠራሮችን በሚደግፉ መድረኮች ላይ ብቻ ነው
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// assert_eq!(foo.fetch_max(42, Ordering::SeqCst), 23);
            /// assert_eq!(foo.load(Ordering::SeqCst), 42);
            /// ```
            ///
            /// If you want to obtain the maximum value in one step, you can use the following:
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// እንሂድ አሞሌ=42;
            /// max_foo=foo.fetch_max (ባር ፣ Ordering::SeqCst).max(bar);
            /// አረጋግጥ! (max_foo==42);
            /// ```
            #[inline]
            #[stable(feature = "atomic_min_max", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_max(&self, val: $int_type, order: Ordering) -> $int_type {
                // ደህንነት የውሂብ ውድድሮች በአቶሚክ ውስጣዊ ነገሮች ተከልክለዋል ፡፡
                unsafe { $max_fn(self.v.get(), val, order) }
            }

            /// አነስተኛ ከሆነው የአሁኑ ዋጋ ጋር።
            ///
            /// የአሁኑን እሴት እና ክርክሩን `val` ዝቅተኛውን አግኝቶ አዲሱን እሴት ለውጤቱ ያዘጋጃል።
            ///
            /// የቀደመውን እሴት ይመልሳል።
            ///
            /// `fetch_min` የዚህን ክዋኔ የማስታወስ ቅደም ተከተል የሚገልጽ የ [`Ordering`] ክርክር ይወስዳል።ሁሉም የትእዛዝ ሁነታዎች ይቻላል ፡፡
            /// [`Acquire`] ን መጠቀም የዚህ ክወና መደብር [`Relaxed`] ክፍል እንደሚያደርገው ልብ ይበሉ ፣ እና [`Release`] ን በመጠቀም የጭነት ክፍልን [`Relaxed`] ያደርገዋል።
            ///
            ///
            /// **ማስታወሻ**-ይህ ዘዴ የሚገኘው የአቶሚክ አሠራሮችን በሚደግፉ መድረኮች ላይ ብቻ ነው
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// assert_eq!(foo.fetch_min(42, Ordering::Relaxed), 23);
            /// assert_eq!(foo.load(Ordering::Relaxed), 23);
            /// assert_eq!(foo.fetch_min(22, Ordering::Relaxed), 23);
            /// assert_eq!(foo.load(Ordering::Relaxed), 22);
            /// ```
            ///
            /// If you want to obtain the minimum value in one step, you can use the following:
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// እንሂድ አሞሌ=12;
            /// min_foo=foo.fetch_min (ባር ፣ Ordering::SeqCst).min(bar);
            /// ማረጋገጫ (ደቂቃ_ፉ ፣ 12);
            /// ```
            #[inline]
            #[stable(feature = "atomic_min_max", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_min(&self, val: $int_type, order: Ordering) -> $int_type {
                // ደህንነት የውሂብ ውድድሮች በአቶሚክ ውስጣዊ ነገሮች ተከልክለዋል ፡፡
                unsafe { $min_fn(self.v.get(), val, order) }
            }

            /// የሚለዋወጥ ጠቋሚውን ወደ መሰረታዊው ኢንቲጀር ይመልሳል።
            ///
            /// አቶሚክ ያልሆኑ ንባቦችን እና በተፈጠረው ኢንቲጀር ላይ መፃፍ የውሂብ ውድድር ሊሆን ይችላል ፡፡
            /// የተግባር ፊርማው ሊጠቀምበት ለሚችለው ለ FFI ይህ ዘዴ በአብዛኛው ጠቃሚ ነው
            #[doc = concat!("`*mut ", stringify!($int_type), "` instead of `&", stringify!($atomic_type), "`.")]
            /// የአቶሚክ ዓይነቶች ከውስጣዊ ተለዋዋጭነት ጋር ስለሚሠሩ የ‹XXXX›ጠቋሚውን ወደዚህ አቶሚክ ከተጋራ ማጣቀሻ መመለስ ደህንነቱ የተጠበቀ ነው ፡፡
            /// የአቶሚክ ማሻሻያዎች ሁሉም ለውጦች በጋራ ማጣቀሻ አማካይነት ዋጋውን ይለውጣሉ ፣ እናም የአቶሚክ አሠራሮችን እስከጠቀሙ ድረስ በደህና ማድረግ ይችላሉ።
            /// የተመለሰው ጥሬ አመላካች ማንኛውም አጠቃቀም የ `unsafe` ማገጃን ይጠይቃል እና አሁንም ተመሳሳይ ገደቡን መጠበቅ አለበት-በእሱ ላይ የሚከናወኑ ተግባራት አቶሚክ መሆን አለባቸው ፡፡
            ///
            ///
            /// # Examples
            ///
            /// (extern-declaration) ን ችላ በል
            ///
            /// # fn main() {
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]
            /// ውጫዊ "C" {
            #[doc = concat!("    fn my_atomic_op(arg: *mut ", stringify!($int_type), ");")]
            /// }
            ///
            #[doc = concat!("let mut atomic = ", stringify!($atomic_type), "::new(1);")]

            // ደህንነት-`my_atomic_op` አቶሚክ እስከሆነ ድረስ ደህና ፡፡
            /// ደህንነቱ ያልተጠበቀ {
            ///     my_atomic_op(atomic.as_mut_ptr());
            /// }
            /// # }
            /// ```
            #[inline]
            #[unstable(feature = "atomic_mut_ptr",
                   reason = "recently added",
                   issue = "66893")]
            pub fn as_mut_ptr(&self) -> *mut $int_type {
                self.v.get()
            }
        }
    }
}

#[cfg(target_has_atomic_load_store = "8")]
atomic_int! {
    cfg(target_has_atomic = "8"),
    cfg(target_has_atomic_equal_alignment = "8"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i8",
    "",
    atomic_min, atomic_max,
    1,
    "AtomicI8::new(0)",
    i8 AtomicI8 ATOMIC_I8_INIT
}
#[cfg(target_has_atomic_load_store = "8")]
atomic_int! {
    cfg(target_has_atomic = "8"),
    cfg(target_has_atomic_equal_alignment = "8"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u8",
    "",
    atomic_umin, atomic_umax,
    1,
    "AtomicU8::new(0)",
    u8 AtomicU8 ATOMIC_U8_INIT
}
#[cfg(target_has_atomic_load_store = "16")]
atomic_int! {
    cfg(target_has_atomic = "16"),
    cfg(target_has_atomic_equal_alignment = "16"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i16",
    "",
    atomic_min, atomic_max,
    2,
    "AtomicI16::new(0)",
    i16 AtomicI16 ATOMIC_I16_INIT
}
#[cfg(target_has_atomic_load_store = "16")]
atomic_int! {
    cfg(target_has_atomic = "16"),
    cfg(target_has_atomic_equal_alignment = "16"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u16",
    "",
    atomic_umin, atomic_umax,
    2,
    "AtomicU16::new(0)",
    u16 AtomicU16 ATOMIC_U16_INIT
}
#[cfg(target_has_atomic_load_store = "32")]
atomic_int! {
    cfg(target_has_atomic = "32"),
    cfg(target_has_atomic_equal_alignment = "32"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i32",
    "",
    atomic_min, atomic_max,
    4,
    "AtomicI32::new(0)",
    i32 AtomicI32 ATOMIC_I32_INIT
}
#[cfg(target_has_atomic_load_store = "32")]
atomic_int! {
    cfg(target_has_atomic = "32"),
    cfg(target_has_atomic_equal_alignment = "32"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u32",
    "",
    atomic_umin, atomic_umax,
    4,
    "AtomicU32::new(0)",
    u32 AtomicU32 ATOMIC_U32_INIT
}
#[cfg(target_has_atomic_load_store = "64")]
atomic_int! {
    cfg(target_has_atomic = "64"),
    cfg(target_has_atomic_equal_alignment = "64"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i64",
    "",
    atomic_min, atomic_max,
    8,
    "AtomicI64::new(0)",
    i64 AtomicI64 ATOMIC_I64_INIT
}
#[cfg(target_has_atomic_load_store = "64")]
atomic_int! {
    cfg(target_has_atomic = "64"),
    cfg(target_has_atomic_equal_alignment = "64"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u64",
    "",
    atomic_umin, atomic_umax,
    8,
    "AtomicU64::new(0)",
    u64 AtomicU64 ATOMIC_U64_INIT
}
#[cfg(target_has_atomic_load_store = "128")]
atomic_int! {
    cfg(target_has_atomic = "128"),
    cfg(target_has_atomic_equal_alignment = "128"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i128",
    "#![feature(integer_atomics)]\n\n",
    atomic_min, atomic_max,
    16,
    "AtomicI128::new(0)",
    i128 AtomicI128 ATOMIC_I128_INIT
}
#[cfg(target_has_atomic_load_store = "128")]
atomic_int! {
    cfg(target_has_atomic = "128"),
    cfg(target_has_atomic_equal_alignment = "128"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u128",
    "#![feature(integer_atomics)]\n\n",
    atomic_umin, atomic_umax,
    16,
    "AtomicU128::new(0)",
    u128 AtomicU128 ATOMIC_U128_INIT
}

macro_rules! atomic_int_ptr_sized {
    ( $($target_pointer_width:literal $align:literal)* ) => { $(
        #[cfg(target_has_atomic_load_store = "ptr")]
        #[cfg(target_pointer_width = $target_pointer_width)]
        atomic_int! {
            cfg(target_has_atomic = "ptr"),
            cfg(target_has_atomic_equal_alignment = "ptr"),
            stable(feature = "rust1", since = "1.0.0"),
            stable(feature = "extended_compare_and_swap", since = "1.10.0"),
            stable(feature = "atomic_debug", since = "1.3.0"),
            stable(feature = "atomic_access", since = "1.15.0"),
            stable(feature = "atomic_from", since = "1.23.0"),
            stable(feature = "atomic_nand", since = "1.27.0"),
            rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
            stable(feature = "rust1", since = "1.0.0"),
            "isize",
            "",
            atomic_min, atomic_max,
            $align,
            "AtomicIsize::new(0)",
            isize AtomicIsize ATOMIC_ISIZE_INIT
        }
        #[cfg(target_has_atomic_load_store = "ptr")]
        #[cfg(target_pointer_width = $target_pointer_width)]
        atomic_int! {
            cfg(target_has_atomic = "ptr"),
            cfg(target_has_atomic_equal_alignment = "ptr"),
            stable(feature = "rust1", since = "1.0.0"),
            stable(feature = "extended_compare_and_swap", since = "1.10.0"),
            stable(feature = "atomic_debug", since = "1.3.0"),
            stable(feature = "atomic_access", since = "1.15.0"),
            stable(feature = "atomic_from", since = "1.23.0"),
            stable(feature = "atomic_nand", since = "1.27.0"),
            rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
            stable(feature = "rust1", since = "1.0.0"),
            "usize",
            "",
            atomic_umin, atomic_umax,
            $align,
            "AtomicUsize::new(0)",
            usize AtomicUsize ATOMIC_USIZE_INIT
        }
    )* };
}

atomic_int_ptr_sized! {
    "16" 2
    "32" 4
    "64" 8
}

#[inline]
#[cfg(target_has_atomic = "8")]
fn strongest_failure_ordering(order: Ordering) -> Ordering {
    match order {
        Release => Relaxed,
        Relaxed => Relaxed,
        SeqCst => SeqCst,
        Acquire => Acquire,
        AcqRel => Acquire,
    }
}

#[inline]
unsafe fn atomic_store<T: Copy>(dst: *mut T, val: T, order: Ordering) {
    // ደህንነት-ደዋዩ ለ `atomic_store` የደህንነትን ውል ማክበር አለበት ፡፡
    unsafe {
        match order {
            Release => intrinsics::atomic_store_rel(dst, val),
            Relaxed => intrinsics::atomic_store_relaxed(dst, val),
            SeqCst => intrinsics::atomic_store(dst, val),
            Acquire => panic!("there is no such thing as an acquire store"),
            AcqRel => panic!("there is no such thing as an acquire/release store"),
        }
    }
}

#[inline]
unsafe fn atomic_load<T: Copy>(dst: *const T, order: Ordering) -> T {
    // ደህንነት-ደዋዩ ለ `atomic_load` የደህንነትን ውል ማክበር አለበት ፡፡
    unsafe {
        match order {
            Acquire => intrinsics::atomic_load_acq(dst),
            Relaxed => intrinsics::atomic_load_relaxed(dst),
            SeqCst => intrinsics::atomic_load(dst),
            Release => panic!("there is no such thing as a release load"),
            AcqRel => panic!("there is no such thing as an acquire/release load"),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_swap<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // ደህንነት-ደዋዩ ለ `atomic_swap` የደህንነትን ውል ማክበር አለበት ፡፡
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xchg_acq(dst, val),
            Release => intrinsics::atomic_xchg_rel(dst, val),
            AcqRel => intrinsics::atomic_xchg_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xchg_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xchg(dst, val),
        }
    }
}

/// የቀደመውን እሴት ይመልሳል (እንደ __sync_fetch_and_add)።
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_add<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // ደህንነት-ደዋዩ ለ `atomic_add` የደህንነትን ውል ማክበር አለበት ፡፡
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xadd_acq(dst, val),
            Release => intrinsics::atomic_xadd_rel(dst, val),
            AcqRel => intrinsics::atomic_xadd_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xadd_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xadd(dst, val),
        }
    }
}

/// የቀደመውን እሴት ይመልሳል (እንደ __sync_fetch_and_sub)።
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_sub<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // ደህንነት-ደዋዩ ለ `atomic_sub` የደህንነትን ውል ማክበር አለበት ፡፡
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xsub_acq(dst, val),
            Release => intrinsics::atomic_xsub_rel(dst, val),
            AcqRel => intrinsics::atomic_xsub_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xsub_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xsub(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_compare_exchange<T: Copy>(
    dst: *mut T,
    old: T,
    new: T,
    success: Ordering,
    failure: Ordering,
) -> Result<T, T> {
    // ደህንነት-ደዋዩ ለ `atomic_compare_exchange` የደህንነትን ውል ማክበር አለበት ፡፡
    let (val, ok) = unsafe {
        match (success, failure) {
            (Acquire, Acquire) => intrinsics::atomic_cxchg_acq(dst, old, new),
            (Release, Relaxed) => intrinsics::atomic_cxchg_rel(dst, old, new),
            (AcqRel, Acquire) => intrinsics::atomic_cxchg_acqrel(dst, old, new),
            (Relaxed, Relaxed) => intrinsics::atomic_cxchg_relaxed(dst, old, new),
            (SeqCst, SeqCst) => intrinsics::atomic_cxchg(dst, old, new),
            (Acquire, Relaxed) => intrinsics::atomic_cxchg_acq_failrelaxed(dst, old, new),
            (AcqRel, Relaxed) => intrinsics::atomic_cxchg_acqrel_failrelaxed(dst, old, new),
            (SeqCst, Relaxed) => intrinsics::atomic_cxchg_failrelaxed(dst, old, new),
            (SeqCst, Acquire) => intrinsics::atomic_cxchg_failacq(dst, old, new),
            (_, AcqRel) => panic!("there is no such thing as an acquire/release failure ordering"),
            (_, Release) => panic!("there is no such thing as a release failure ordering"),
            _ => panic!("a failure ordering can't be stronger than a success ordering"),
        }
    };
    if ok { Ok(val) } else { Err(val) }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_compare_exchange_weak<T: Copy>(
    dst: *mut T,
    old: T,
    new: T,
    success: Ordering,
    failure: Ordering,
) -> Result<T, T> {
    // ደህንነት-ደዋዩ ለ `atomic_compare_exchange_weak` የደህንነትን ውል ማክበር አለበት ፡፡
    let (val, ok) = unsafe {
        match (success, failure) {
            (Acquire, Acquire) => intrinsics::atomic_cxchgweak_acq(dst, old, new),
            (Release, Relaxed) => intrinsics::atomic_cxchgweak_rel(dst, old, new),
            (AcqRel, Acquire) => intrinsics::atomic_cxchgweak_acqrel(dst, old, new),
            (Relaxed, Relaxed) => intrinsics::atomic_cxchgweak_relaxed(dst, old, new),
            (SeqCst, SeqCst) => intrinsics::atomic_cxchgweak(dst, old, new),
            (Acquire, Relaxed) => intrinsics::atomic_cxchgweak_acq_failrelaxed(dst, old, new),
            (AcqRel, Relaxed) => intrinsics::atomic_cxchgweak_acqrel_failrelaxed(dst, old, new),
            (SeqCst, Relaxed) => intrinsics::atomic_cxchgweak_failrelaxed(dst, old, new),
            (SeqCst, Acquire) => intrinsics::atomic_cxchgweak_failacq(dst, old, new),
            (_, AcqRel) => panic!("there is no such thing as an acquire/release failure ordering"),
            (_, Release) => panic!("there is no such thing as a release failure ordering"),
            _ => panic!("a failure ordering can't be stronger than a success ordering"),
        }
    };
    if ok { Ok(val) } else { Err(val) }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_and<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // ደህንነት-ደዋዩ ለ `atomic_and` የደህንነትን ውል ማክበር አለበት
    unsafe {
        match order {
            Acquire => intrinsics::atomic_and_acq(dst, val),
            Release => intrinsics::atomic_and_rel(dst, val),
            AcqRel => intrinsics::atomic_and_acqrel(dst, val),
            Relaxed => intrinsics::atomic_and_relaxed(dst, val),
            SeqCst => intrinsics::atomic_and(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_nand<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // ደህንነት-ደዋዩ ለ `atomic_nand` የደህንነትን ውል ማክበር አለበት
    unsafe {
        match order {
            Acquire => intrinsics::atomic_nand_acq(dst, val),
            Release => intrinsics::atomic_nand_rel(dst, val),
            AcqRel => intrinsics::atomic_nand_acqrel(dst, val),
            Relaxed => intrinsics::atomic_nand_relaxed(dst, val),
            SeqCst => intrinsics::atomic_nand(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_or<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // ደህንነት-ደዋዩ ለ `atomic_or` የደህንነትን ውል ማክበር አለበት
    unsafe {
        match order {
            Acquire => intrinsics::atomic_or_acq(dst, val),
            Release => intrinsics::atomic_or_rel(dst, val),
            AcqRel => intrinsics::atomic_or_acqrel(dst, val),
            Relaxed => intrinsics::atomic_or_relaxed(dst, val),
            SeqCst => intrinsics::atomic_or(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_xor<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // ደህንነት-ደዋዩ ለ `atomic_xor` የደህንነትን ውል ማክበር አለበት
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xor_acq(dst, val),
            Release => intrinsics::atomic_xor_rel(dst, val),
            AcqRel => intrinsics::atomic_xor_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xor_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xor(dst, val),
        }
    }
}

/// ከፍተኛውን እሴት ይመልሳል (የተፈረመ ንፅፅር)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_max<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // ደህንነት-ደዋዩ ለ `atomic_max` የደህንነትን ውል ማክበር አለበት
    unsafe {
        match order {
            Acquire => intrinsics::atomic_max_acq(dst, val),
            Release => intrinsics::atomic_max_rel(dst, val),
            AcqRel => intrinsics::atomic_max_acqrel(dst, val),
            Relaxed => intrinsics::atomic_max_relaxed(dst, val),
            SeqCst => intrinsics::atomic_max(dst, val),
        }
    }
}

/// የደቂቃውን እሴት ይመልሳል (የተፈረመ ንፅፅር)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_min<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // ደህንነት-ደዋዩ ለ `atomic_min` የደህንነትን ውል ማክበር አለበት
    unsafe {
        match order {
            Acquire => intrinsics::atomic_min_acq(dst, val),
            Release => intrinsics::atomic_min_rel(dst, val),
            AcqRel => intrinsics::atomic_min_acqrel(dst, val),
            Relaxed => intrinsics::atomic_min_relaxed(dst, val),
            SeqCst => intrinsics::atomic_min(dst, val),
        }
    }
}

/// ከፍተኛውን እሴት ይመልሳል (ያልተፈረመ ንፅፅር)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_umax<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // ደህንነት-ደዋዩ ለ `atomic_umax` የደህንነትን ውል ማክበር አለበት
    unsafe {
        match order {
            Acquire => intrinsics::atomic_umax_acq(dst, val),
            Release => intrinsics::atomic_umax_rel(dst, val),
            AcqRel => intrinsics::atomic_umax_acqrel(dst, val),
            Relaxed => intrinsics::atomic_umax_relaxed(dst, val),
            SeqCst => intrinsics::atomic_umax(dst, val),
        }
    }
}

/// የደቂቃውን እሴት ይመልሳል (ያልተፈረመ ንፅፅር)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_umin<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // ደህንነት-ደዋዩ ለ `atomic_umin` የደህንነትን ውል ማክበር አለበት
    unsafe {
        match order {
            Acquire => intrinsics::atomic_umin_acq(dst, val),
            Release => intrinsics::atomic_umin_rel(dst, val),
            AcqRel => intrinsics::atomic_umin_acqrel(dst, val),
            Relaxed => intrinsics::atomic_umin_relaxed(dst, val),
            SeqCst => intrinsics::atomic_umin(dst, val),
        }
    }
}

/// አቶሚክ አጥር ፡፡
///
/// በተጠቀሰው ትዕዛዝ ላይ በመመርኮዝ አጥር አጠናቃሪውን እና ሲፒዩን በዙሪያው ያሉትን የተወሰኑ የማስታወሻ ሥራዎችን እንደገና እንዳያስተላልፍ ይከላከላል ፡፡
/// ያ በእሱ እና በአቶሚክ አሠራሮች ወይም በሌሎች ክሮች ውስጥ ያሉ አጥር መካከል የሚመሳሰሉ-ግንኙነቶችን ይፈጥራል።
///
/// አ XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX/XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX ላይ ካለው አጥር ጋር ይመሳሰላል ፡፡ X ፣ Y ለ ቢ እና Y ለውጡን ከመታየቱ በፊት ተመሳስሏል ፡፡
/// ይህ በ A እና ለ መካከል ከመከሰቱ በፊት-ይከሰታል ፡፡
///
/// ```text
///     Thread 1                                          Thread 2
///
/// fence(Release);      A --------------
/// x.store(3, Relaxed); X ---------    |
///                                |    |
///                                |    |
///                                -------------> Y  if x.load(Relaxed) == 3 {
///                                     |-------> B      fence(Acquire);
///                                                      ...
///                                                  }
/// ```
///
/// የአቶሚክ ክዋኔዎች ከ‹XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX/XXX///[`Acquire`]/emicics/ጋር የአቶሚክ ሥራዎች እንዲሁ ከአጥር ጋር ሊመሳሰሉ ይችላሉ ፡፡
///
/// [`SeqCst`] X እና [`Release`] ፍች/ትርጓሜ ካለው በተጨማሪ [`SeqCst`] ማዘዣ ያለው አጥር በሌላው የ [`SeqCst`] ኦፕሬሽኖች እና/ወይም አጥሮች በዓለም አቀፍ የፕሮግራም ቅደም ተከተል ውስጥ ይሳተፋል ፡፡
///
/// [`Acquire`] ፣ [`Release`] ፣ [`AcqRel`] እና [`SeqCst`] ትዕዛዞችን ይቀበላል።
///
/// # Panics
///
/// `order` [`Relaxed`] ከሆነ Panics።
///
/// # Examples
///
/// ```
/// use std::sync::atomic::AtomicBool;
/// use std::sync::atomic::fence;
/// use std::sync::atomic::Ordering;
///
/// // ስፒንሎክ ላይ የተመሠረተ አንድ የጋራ ማግለል ጥንታዊ።
/// pub struct Mutex {
///     flag: AtomicBool,
/// }
///
/// impl Mutex {
///     pub fn new() -> Mutex {
///         Mutex {
///             flag: AtomicBool::new(false),
///         }
///     }
///
///     pub fn lock(&self) {
///         // አሮጌው እሴት `false` እስኪሆን ድረስ ይጠብቁ።
///         while self.flag.compare_and_swap(false, true, Ordering::Relaxed) != false {}
///         // ይህ አጥር በ `unlock` ውስጥ ካለው መደብር ጋር ይመሳሰላል።
///         fence(Ordering::Acquire);
///     }
///
///     pub fn unlock(&self) {
///         self.flag.store(false, Ordering::Release);
///     }
/// }
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn fence(order: Ordering) {
    // ደህንነት-አቶሚክ አጥርን መጠቀም ደህንነቱ የተጠበቀ ነው ፡፡
    unsafe {
        match order {
            Acquire => intrinsics::atomic_fence_acq(),
            Release => intrinsics::atomic_fence_rel(),
            AcqRel => intrinsics::atomic_fence_acqrel(),
            SeqCst => intrinsics::atomic_fence(),
            Relaxed => panic!("there is no such thing as a relaxed fence"),
        }
    }
}

/// አጠናቃሪ የማስታወሻ አጥር።
///
/// `compiler_fence` ምንም የማሽን ኮድ አያወጣም ፣ ግን አጠናቃሪው እንደገና እንዲሰራ የተፈቀደውን የማስታወስ አይነቶች ይገድባል።በተለይም በተጠቀሰው የ [`Ordering`] ፍች ላይ በመመርኮዝ አዘጋጁ ወደ ሌላኛው ጥሪ ወደ `compiler_fence` ከመደወሉ በፊት ወይም በኋላ ከመነበብ ወይም ከመፃፍ ሊከለከል ይችላል ፡፡*ሃርድዌር* እንደዚህ ያለ ዳግም ትዕዛዝ እንዳያደርግ **እንደማያደርግ** ልብ ይበሉ።
///
/// ይህ በአንድ ክር ፣ በአፈፃፀም አውድ ውስጥ ችግር አይደለም ፣ ግን ሌሎች ክሮች በተመሳሳይ ጊዜ ማህደረ ትውስታን ሊቀይሩ በሚችሉበት ጊዜ እንደ [`fence`] ያሉ ጠንካራ የማመሳሰል የመጀመሪያዎች ያስፈልጋሉ።
///
/// በተለያዩ የትእዛዝ ፍችዎች የተከለከለው እንደገና ማዘዣ-
///
///  - ከ [`SeqCst`] ጋር ፣ በዚህ ነጥብ ላይ የንባብ እና እንደገና መፃፍ አይፈቀድም።
///  - በ [`Release`] ፣ የቀደሙት ንባቦች እና ጽሑፎች ያለፉትን ቀጣይ ጽሑፎች ማንቀሳቀስ አይችሉም።
///  - በ [`Acquire`] ፣ ቀጣይ ንባቦች እና ጽሑፎች ከቀዳሚው ንባብ ቀድመው ሊንቀሳቀሱ አይችሉም።
///  - ከ [`AcqRel`] ጋር ፣ ከላይ የተጠቀሱት ሁለቱም ህጎች ተፈጻሚ ይሆናሉ።
///
/// `compiler_fence` አንድ ክር ከራሱ ጋር * እንዳይወዳደር ለመከላከል ብቻ ጠቃሚ ነው።ይኸውም ፣ አንድ የተሰጠው ክር አንድን ቁራጭ የሚያከናውን ከሆነ እና ከዚያ ከተቋረጠ እና በሌላ ቦታ ኮድን ማስፈፀም ይጀምራል (አሁንም በተመሳሳይ ክር ውስጥ እያለ እና ፅንሰ-ሀሳቡ አሁንም በተመሳሳይ ኮር ላይ)።በባህላዊ ፕሮግራሞች ውስጥ ይህ ሊገኝ የሚችለው የምልክት ተቆጣጣሪ ሲመዘገብ ብቻ ነው ፡፡
/// ይበልጥ በዝቅተኛ ደረጃ ኮድ ውስጥ ፣ ማቋረጦችን ሲያስተናግዱ ፣ አረንጓዴ ክሮችን ከቅድመ-emption ጋር ሲተገበሩ ፣ ወዘተ የመሳሰሉት ሁኔታዎች ሊከሰቱ ይችላሉ።
/// የማወቅ ጉጉት ያላቸው አንባቢዎች ስለ [memory barriers] የ Linux የከርነል ውይይት እንዲያነቡ ይበረታታሉ።
///
/// # Panics
///
/// `order` [`Relaxed`] ከሆነ Panics።
///
/// # Examples
///
/// ያለ‹XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX `ጋር` UXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX `` የ X0XX.
/// ለምን እንደሆነ ለማየት አሰባሳቢው ሁለቱም መደብሮች `Ordering::Relaxed` ስለሆኑ መደብሮቹን ወደ `IMPORTANT_VARIABLE` እና `IS_READ` ለመለዋወጥ ነፃ መሆኑን ያስታውሱ ፡፡ከሆነ ፣ እና `IS_READY` ከተዘመነ በኋላ የምልክት መቆጣጠሪያው ወዲያውኑ ተጠርቷል ፣ ከዚያ የምልክት መቆጣጠሪያው `IS_READY=1` ን ይመለከታል ፣ ግን `IMPORTANT_VARIABLE=0`።
/// የ `compiler_fence` መድሃኒቶችን በመጠቀም ይህንን ሁኔታ ፡፡
///
/// ```
/// use std::sync::atomic::{AtomicBool, AtomicUsize};
/// use std::sync::atomic::Ordering;
/// use std::sync::atomic::compiler_fence;
///
/// static IMPORTANT_VARIABLE: AtomicUsize = AtomicUsize::new(0);
/// static IS_READY: AtomicBool = AtomicBool::new(false);
///
/// fn main() {
///     IMPORTANT_VARIABLE.store(42, Ordering::Relaxed);
///     // የቀደሙ ጽሑፎች ከዚህ ነጥብ እንዳይንቀሳቀሱ ይከላከሉ
///     compiler_fence(Ordering::Release);
///     IS_READY.store(true, Ordering::Relaxed);
/// }
///
/// fn signal_handler() {
///     if IS_READY.load(Ordering::Relaxed) {
///         assert_eq!(IMPORTANT_VARIABLE.load(Ordering::Relaxed), 42);
///     }
/// }
/// ```
///
/// [memory barriers]: https://www.kernel.org/doc/Documentation/memory-barriers.txt
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "compiler_fences", since = "1.21.0")]
pub fn compiler_fence(order: Ordering) {
    // ደህንነት-አቶሚክ አጥርን መጠቀም ደህንነቱ የተጠበቀ ነው ፡፡
    unsafe {
        match order {
            Acquire => intrinsics::atomic_singlethreadfence_acq(),
            Release => intrinsics::atomic_singlethreadfence_rel(),
            AcqRel => intrinsics::atomic_singlethreadfence_acqrel(),
            SeqCst => intrinsics::atomic_singlethreadfence(),
            Relaxed => panic!("there is no such thing as a relaxed compiler fence"),
        }
    }
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "atomic_debug", since = "1.3.0")]
impl fmt::Debug for AtomicBool {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_debug", since = "1.3.0")]
impl<T> fmt::Debug for AtomicPtr<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_pointer", since = "1.24.0")]
impl<T> fmt::Pointer for AtomicPtr<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.load(Ordering::SeqCst), f)
    }
}

/// አንጎለ ኮምፒውተሩ በስራ-መጠባበቂያ ዑደት (`ስፒን ቁልፍ`) ውስጥ እንዳለ ምልክት ይሰጣል።
///
/// ይህ ተግባር ለ‹XXXX›ን ተቋርጧል ፡፡
///
/// [`hint::spin_loop`]: crate::hint::spin_loop
#[inline]
#[stable(feature = "spin_loop_hint", since = "1.24.0")]
#[rustc_deprecated(since = "1.51.0", reason = "use hint::spin_loop instead")]
pub fn spin_loop_hint() {
    spin_loop()
}