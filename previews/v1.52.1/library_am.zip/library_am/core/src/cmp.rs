//! አደራደር እና ንጽጽር ለ ተግባራዊነት.
//!
//! ይህ ሞጁል እሴቶችን ለማዘዝ እና ለማነፃፀር የተለያዩ መሣሪያዎችን ይ containsል ፡፡በማጠቃለያው:
//!
//! * [`Eq`] እና [`PartialEq`] እናንተ እንደቅደም, እሴቶች መካከል ጠቅላላ እና ከፊል እኩልነት ለመግለጽ የሚፈቅዱ traits ናቸው.
//! እነሱን ተግባራዊ በ `==` እና `!=` ከዋኞችን overloads.
//! * [`Ord`] እና [`PartialOrd`] እናንተ እንደቅደም, እሴቶች መካከል ጠቅላላ እና ከፊል orderings ለመግለጽ የሚፈቅዱ traits ናቸው.
//!
//! እነሱን ተግባራዊ ማድረግ የ `<` ፣ `<=` ፣ `>` እና `>=` ኦፕሬተሮችን ከመጠን በላይ ጭነት ይጫናል ፡፡
//! * [`Ordering`] በ [`Ord`] እና [`PartialOrd`] ዋና ተግባራት የተመለሰ enum ሲሆን ትዕዛዝ መስጠትንም ይገልጻል።
//! * [`Reverse`] በቀላሉ አንድ አደራደር መቀልበስ የሚፈቅድ struct ነው.
//! * [`max`] እና [`min`] ከ [`Ord`] የሚገነቡ እና ከፍተኛውን ወይም ዝቅተኛውን ሁለት እሴቶችን እንዲያገኙ የሚያስችሉዎት ተግባራት ናቸው።
//!
//! ለተጨማሪ ዝርዝሮች በዝርዝሩ ውስጥ የእያንዳንዱን ንጥል ተዛማጅ ሰነዶችን ይመልከቱ ፡፡
//!
//! [`max`]: Ord::max
//! [`min`]: Ord::min
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use self::Ordering::*;

/// [partial equivalence relations](https://en.wikipedia.org/wiki/Partial_equivalence_relation) ለሆኑ የእኩልነት ንፅፅሮች Trait
///
/// ይህ trait ሙሉ አቻነት ግንኙነት የሌላቸው አይነቶች, ከፊል እኩልነት ለማግኘት ያስችላል.
/// ለምሳሌ ፣ በተንሳፋፊ ቁጥር ቁጥሮች `NaN != NaN` ውስጥ ፣ ስለሆነም ተንሳፋፊ የነጥብ ዓይነቶች `PartialEq` ን ይተገብራሉ ግን [`trait@Eq`] አይደለም ፡፡
///
/// በመደበኛነት እኩልነት መሆን አለበት (ለሁሉም `a` ፣ `b` ፣ `c` ዓይነት `A` ፣ `B` ፣ `C`):
///
/// - **ሲቀነስ**: `A: PartialEq<B>` እና `B: PartialEq<A>`, ከዚያም **`አንድ==b` ን`አንድምታ ከሆነ ለ==A`**;እና
///
/// - **ተሻጋሪ**: `A: PartialEq<B>` እና `B: PartialEq<C>` እና "A:
///   ከፊል ኢ<C>`, ከዚያም **` አንድ==b`ን እና `b == c`**`አንድ==c` ያመለክታል.
///
/// የ `B: PartialEq<A>` (symmetric) እና `A: PartialEq<C>` (transitive) አሻራዎች እንዲኖሩ የማይገደዱ መሆናቸውን ልብ ይበሉ ፣ ግን እነዚህ መስፈርቶች በሚኖሩበት ጊዜ ሁሉ ይተገበራሉ።
///
/// ## Derivable
///
/// ይህ trait ከ `#[derive]` ጋር ሊያገለግል ይችላል።በእቅዶች ላይ ሲወርድ ሁሉም መስኮች እኩል ከሆኑ ሁለት አጋጣሚዎች እኩል ናቸው ፣ እና ማናቸውም እርሻዎች እኩል ካልሆኑ እኩል አይደሉም ፡፡በኤንሱም ላይ `derive`d` በሚሆንበት ጊዜ እያንዳንዱ ልዩነት ከራሱ ጋር እኩል ነው እና ከሌሎቹ ልዩነቶች ጋር እኩል አይሆንም ፡፡
///
/// ## `PartialEq` ን እንዴት ተግባራዊ ማድረግ እችላለሁ?
///
/// `PartialEq` እንዲተገበር የ [`eq`] ዘዴን ብቻ ይፈልጋል;[`ne`] በነባሪነቱ በእሱ ይገለጻል ፡፡[`ne`] ማንኛውም በእጅ ትግበራ *የግድ*[`eq`] [`ne`] የሆነ ጥብቅ ተገላቢጦሽ ነው የሚለውን ደንብ ማክበር;ማለትም `!(a == b)` ከሆነ እና ከሆነ `a != b` ብቻ ነው።
///
/// የ `PartialEq` ፣ [`PartialOrd`] እና [`Ord`]*ትግበራዎች* እርስ በርሳቸው መስማማት አለባቸው።እሱም በድንገት traits አንዳንድ ከጠብመንጃ እና በእጅ ሌሎችን ተግባራዊ በማድረግ እነሱን አልስማማም ማድረግ ቀላል ነው.
///
/// ያላቸውን ISBN ግጥሚያዎች ከሆነ ሁለት መጻሕፍት ቅርጸቶች ይለያያል እንኳ ቢሆን ተመሳሳይ መጽሐፍ ይቆጠራሉ ውስጥ አንድ ጎራ ምሳሌ ትግበራ:
///
/// ```
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// impl PartialEq for Book {
///     fn eq(&self, other: &Self) -> bool {
///         self.isbn == other.isbn
///     }
/// }
///
/// let b1 = Book { isbn: 3, format: BookFormat::Paperback };
/// let b2 = Book { isbn: 3, format: BookFormat::Ebook };
/// let b3 = Book { isbn: 10, format: BookFormat::Paperback };
///
/// assert!(b1 == b2);
/// assert!(b1 != b3);
/// ```
///
/// ## ሁለት የተለያዩ አይነቶችን እንዴት ማወዳደር እችላለሁ?
///
/// አይነት እርስዎ PartialEq`ዎቹ አይነት መለኪያ`የሚቆጣጠረው ጋር ማወዳደር ይችላሉ.
/// ለምሳሌ ያህል, ዎቹ የእኛን ቀደም ኮድ ትንሽ ልታሻችላቸው እንመልከት:
///
/// ```
/// // የ ሊሆኗቸው መሳሪያዎች<BookFormat>==<BookFormat>ንፅፅሮች
/// #[derive(PartialEq)]
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// // ይተግብሩ<Book>==<BookFormat>ንፅፅሮች
/// impl PartialEq<BookFormat> for Book {
///     fn eq(&self, other: &BookFormat) -> bool {
///         self.format == *other
///     }
/// }
///
/// // ይተግብሩ<BookFormat>==<Book>ንፅፅሮች
/// impl PartialEq<Book> for BookFormat {
///     fn eq(&self, other: &Book) -> bool {
///         *self == other.format
///     }
/// }
///
/// let b1 = Book { isbn: 3, format: BookFormat::Paperback };
///
/// assert!(b1 == BookFormat::Paperback);
/// assert!(BookFormat::Ebook != b1);
/// ```
///
/// `impl PartialEq<BookFormat> for Book` ወደ `impl PartialEq for Book` በመቀየር, እኛ BookFormat`s Book`s `ጋር ሲነጻጸር ዘንድ` ፍቀድ.
///
/// የመዋቅር አንዳንድ መስኮችን ችላ በማለት ከላይ ካለው ጋር ማነፃፀር አደገኛ ሊሆን ይችላል ፡፡ለከፊል ተመጣጣኝ ግንኙነት ፍላጎቶችን ወደማይፈለግ መጣስ በቀላሉ ሊያመራ ይችላል ፡፡
/// እኛ `BookFormat` ለ `PartialEq<Book>` መካከል ከላይ ትግበራ ጠብቄአለሁ እና (ወይ አንድ `#[derive]` በኩል ወይም የመጀመሪያው ምሳሌ ጀምሮ በእጅ ትግበራ በኩል) `Book` ለ `PartialEq<Book>` አንድ አፈፃፀም ታክሎ ከሆነ ለምሳሌ ያህል, ከዚያም ውጤት transitivity የሚጥሱ ነበር:
///
///
/// ```should_panic
/// #[derive(PartialEq)]
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// #[derive(PartialEq)]
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// impl PartialEq<BookFormat> for Book {
///     fn eq(&self, other: &BookFormat) -> bool {
///         self.format == *other
///     }
/// }
///
/// impl PartialEq<Book> for BookFormat {
///     fn eq(&self, other: &Book) -> bool {
///         *self == other.format
///     }
/// }
///
/// fn main() {
///     let b1 = Book { isbn: 1, format: BookFormat::Paperback };
///     let b2 = Book { isbn: 2, format: BookFormat::Paperback };
///
///     assert!(b1 == BookFormat::Paperback);
///     assert!(BookFormat::Paperback == b2);
///
///     // The following should hold by transitivity but doesn't.
///     assert!(b1 == b2); // <-- PANICS
/// }
/// ```
///
/// # Examples
///
/// ```
/// let x: u32 = 0;
/// let y: u32 = 1;
///
/// assert_eq!(x == y, false);
/// assert_eq!(x.eq(&y), false);
/// ```
///
/// [`eq`]: PartialEq::eq
/// [`ne`]: PartialEq::ne
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "eq"]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = "==")]
#[doc(alias = "!=")]
#[rustc_on_unimplemented(
    message = "can't compare `{Self}` with `{Rhs}`",
    label = "no implementation for `{Self} == {Rhs}`"
)]
pub trait PartialEq<Rhs: ?Sized = Self> {
    /// `self` እና `other` ይህ ዘዴ ፈተናዎች እኩል እንዲሆኑ አድርጎ ይመለከተዋል; እንዲሁም `==` ላይ ውሏል.
    ///
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn eq(&self, other: &Rhs) -> bool;

    /// ይህ ዘዴ `!=` ለ ይፈትናል.
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn ne(&self, other: &Rhs) -> bool {
        !self.eq(other)
    }
}

/// የ `trait `PartialEq` ን ውጤት የሚያመነጭ ማክሮን ያግኙ ፡፡
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, structural_match)]
pub macro PartialEq($item:item) {
    /* compiler built-in */
}

/// [equivalence relations](https://en.wikipedia.org/wiki/Equivalence_relation) የትኞቹ እኩልነት ንጽጽሮችን ለ Trait.
///
/// `a == b` እና `a != b` ጥብቅ inverses ከመሆን በተጨማሪ, እኩልነትና (ሁሉም `a`, `b` እና `c` ለ) መሆን አለበት ይህ ማለት:
///
/// - reflexive: `a == a`;
/// - የተመጣጠነ: `a == b` `b == a` ን ያመለክታልእና
/// - ተሻጋሪ-`a == b` እና `b == c` `a == c` ን ያመለክታል ፡፡
///
/// ይህ ንብረት በአቀራባሪው ሊረጋገጥ አይችልም ፣ ስለሆነም `Eq` [`PartialEq`] ን ያመለክታል ፣ እና ምንም ተጨማሪ ዘዴዎች የሉትም።
///
/// ## Derivable
///
/// ይህ trait ከ `#[derive]` ጋር ሊያገለግል ይችላል።
/// `ሲመጣ` ፣ `Eq` ምንም ተጨማሪ ዘዴ ስለሌለው ፣ ይህ ከከፊል የእኩልነት ግንኙነት ይልቅ ይህ የእኩልነት ዝምድና መሆኑን ለአቀናባሪው ማሳወቅ ብቻ ነው።
///
/// የ `derive` ስትራቴጂ ሁሉንም መስኮች እንደሚፈልግ ልብ ይበሉ `Eq` ናቸው ፣ ይህ ሁልጊዜ የማይፈለግ ነው።
///
/// ## `Eq` ን እንዴት ተግባራዊ ማድረግ እችላለሁ?
///
/// የ `derive` ስትራቴጂ መጠቀም ካልቻሉ, የሚዘረዝሩ ምንም ዘዴዎች ያለው የእርስዎ አይነት መሳሪያዎች `Eq`:
///
/// ```
/// enum BookFormat { Paperback, Hardback, Ebook }
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
/// impl PartialEq for Book {
///     fn eq(&self, other: &Self) -> bool {
///         self.isbn == other.isbn
///     }
/// }
/// impl Eq for Book {}
/// ```
///
///
///
///
///
#[doc(alias = "==")]
#[doc(alias = "!=")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Eq: PartialEq<Self> {
    // በዚህ ዘዴ#በማድረግ ብቻ ጥቅም ላይ ውሏል አንድ አይነት መሳሪያዎች#እያንዳንዱ አካል ራሱ [ከጠብመንጃ] መሆኑን አጽኖት ወደ [ከጠብመንጃ], በዚህ trait ላይ ያለ ዘዴ መጠቀም ያለ ይህ አባባል እያደረገ የአሁኑ ያካበቱት የመሰረተ ልማት ማለት ይቻላል የማይቻል ነው.
    //
    //
    // ይህ በጭራሽ በእጅ መተግበር የለበትም ፡፡
    //
    //
    //
    #[doc(hidden)]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn assert_receiver_is_total_eq(&self) {}
}

/// የ trait `Eq` አንድ impl በማመንጨት ሊሆኗቸው ማክሮ.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_eq, structural_match)]
pub macro Eq($item:item) {
    /* compiler built-in */
}

// FIXME: ይህ struct#[ማግኘት] ላይ በ ብቻ ጥቅም ላይ ውሏል
// አንድ አይነት መሳሪያዎች EQ ያንን ሁሉ አካል አጽኖት.
//
// ይህ አወቃቀር በተጠቃሚ ኮድ ውስጥ በጭራሽ መታየት የለበትም።
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(feature = "derive_eq", reason = "deriving hack, should not be public", issue = "none")]
pub struct AssertParamIsEq<T: Eq + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// `Ordering` በሁለት እሴቶች መካከል ያለው ንፅፅር ውጤት ነው።
///
/// # Examples
///
/// ```
/// use std::cmp::Ordering;
///
/// let result = 1.cmp(&2);
/// assert_eq!(Ordering::Less, result);
///
/// let result = 1.cmp(&1);
/// assert_eq!(Ordering::Equal, result);
///
/// let result = 2.cmp(&1);
/// assert_eq!(Ordering::Greater, result);
/// ```
#[derive(Clone, Copy, PartialEq, Debug, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub enum Ordering {
    /// የንፅፅር እሴት ከሌላው ያነሰ በሚሆንበት ቦታ ማዘዝ።
    #[stable(feature = "rust1", since = "1.0.0")]
    Less = -1,
    /// አንድ ሲነፃፀር እሴት ሌላው ጋር እኩል ነው በሆነበት አደራደር.
    #[stable(feature = "rust1", since = "1.0.0")]
    Equal = 0,
    /// አንድ ሲነፃፀር እሴት ሌላ ይበልጣል ቦታ አንድ አደራደር.
    #[stable(feature = "rust1", since = "1.0.0")]
    Greater = 1,
}

impl Ordering {
    /// ትዕዛዙ የ `Equal` ልዩነት ከሆነ `true` ን ይመልሳል።
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_eq(), false);
    /// assert_eq!(Ordering::Equal.is_eq(), true);
    /// assert_eq!(Ordering::Greater.is_eq(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_eq(self) -> bool {
        matches!(self, Equal)
    }

    /// ሰርዓት የ `Equal` ተለዋጭ አይደለም ከሆነ `true` ይመልሳል.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_ne(), true);
    /// assert_eq!(Ordering::Equal.is_ne(), false);
    /// assert_eq!(Ordering::Greater.is_ne(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_ne(self) -> bool {
        !matches!(self, Equal)
    }

    /// ትዕዛዙ የ `Less` ልዩነት ከሆነ `true` ን ይመልሳል።
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_lt(), true);
    /// assert_eq!(Ordering::Equal.is_lt(), false);
    /// assert_eq!(Ordering::Greater.is_lt(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_lt(self) -> bool {
        matches!(self, Less)
    }

    /// ትዕዛዙ የ `Greater` ልዩነት ከሆነ `true` ን ይመልሳል።
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_gt(), false);
    /// assert_eq!(Ordering::Equal.is_gt(), false);
    /// assert_eq!(Ordering::Greater.is_gt(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_gt(self) -> bool {
        matches!(self, Greater)
    }

    /// ትዕዛዙ የ `Less` ወይም `Equal` ልዩነት ከሆነ `true` ን ይመልሳል።
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_le(), true);
    /// assert_eq!(Ordering::Equal.is_le(), true);
    /// assert_eq!(Ordering::Greater.is_le(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_le(self) -> bool {
        !matches!(self, Greater)
    }

    /// ትዕዛዙ የ `Greater` ወይም `Equal` ልዩነት ከሆነ `true` ን ይመልሳል።
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_ge(), false);
    /// assert_eq!(Ordering::Equal.is_ge(), true);
    /// assert_eq!(Ordering::Greater.is_ge(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_ge(self) -> bool {
        !matches!(self, Less)
    }

    /// `Ordering` ን ይቀልብሳል።
    ///
    /// * `Less` `Greater` ይሆናል።
    /// * `Greater` `Less` ይሆናል።
    /// * `Equal` `Equal` ይሆናል።
    ///
    /// # Examples
    ///
    /// መሰረታዊ ባህሪ
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.reverse(), Ordering::Greater);
    /// assert_eq!(Ordering::Equal.reverse(), Ordering::Equal);
    /// assert_eq!(Ordering::Greater.reverse(), Ordering::Less);
    /// ```
    ///
    /// ይህ ዘዴ ንፅፅርን ለመቀልበስ ሊያገለግል ይችላል-
    ///
    /// ```
    /// let data: &mut [_] = &mut [2, 10, 5, 8];
    ///
    /// // ድርድርን ከትልቁ እስከ ትንሹ ደርድር።
    /// data.sort_by(|a, b| a.cmp(b).reverse());
    ///
    /// let b: &mut [_] = &mut [10, 8, 5, 2];
    /// assert!(data == b);
    /// ```
    #[inline]
    #[must_use]
    #[rustc_const_stable(feature = "const_ordering", since = "1.48.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn reverse(self) -> Ordering {
        match self {
            Less => Greater,
            Equal => Equal,
            Greater => Less,
        }
    }

    /// ሰንሰለቶች ሁለት ቅደም ተከተሎች ፡፡
    ///
    /// ይህ `Equal` አይደለም ጊዜ ተመላሾች `self`.አለበለዚያ `other` ን ይመልሳል።
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = Ordering::Equal.then(Ordering::Less);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then(Ordering::Equal);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then(Ordering::Greater);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Equal.then(Ordering::Equal);
    /// assert_eq!(result, Ordering::Equal);
    ///
    /// let x: (i64, i64, i64) = (1, 2, 7);
    /// let y: (i64, i64, i64) = (1, 5, 3);
    /// let result = x.0.cmp(&y.0).then(x.1.cmp(&y.1)).then(x.2.cmp(&y.2));
    ///
    /// assert_eq!(result, Ordering::Less);
    /// ```
    #[inline]
    #[must_use]
    #[rustc_const_stable(feature = "const_ordering", since = "1.48.0")]
    #[stable(feature = "ordering_chaining", since = "1.17.0")]
    pub const fn then(self, other: Ordering) -> Ordering {
        match self {
            Equal => other,
            _ => self,
        }
    }

    /// ከተሰጠው ተግባር ጋር ትዕዛዙን ሰንሰለቶች
    ///
    /// `Equal` በማይሆንበት ጊዜ `self` ን ይመልሳል።
    /// አለበለዚያ `f` ን ይደውላል እና ውጤቱን ይመልሳል።
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = Ordering::Equal.then_with(|| Ordering::Less);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then_with(|| Ordering::Equal);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then_with(|| Ordering::Greater);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Equal.then_with(|| Ordering::Equal);
    /// assert_eq!(result, Ordering::Equal);
    ///
    /// let x: (i64, i64, i64) = (1, 2, 7);
    /// let y: (i64, i64, i64) = (1, 5, 3);
    /// let result = x.0.cmp(&y.0).then_with(|| x.1.cmp(&y.1)).then_with(|| x.2.cmp(&y.2));
    ///
    /// assert_eq!(result, Ordering::Less);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "ordering_chaining", since = "1.17.0")]
    pub fn then_with<F: FnOnce() -> Ordering>(self, f: F) -> Ordering {
        match self {
            Equal => f(),
            _ => self,
        }
    }
}

/// ለተገላቢጦሽ ትዕዛዝ ረዳት መዋቅር።
///
/// ይህ struct ረዳት [`Vec::sort_by_key`] ላሉ ተግባራት ጋር ሊውል እና ትዕዛዝ ቁልፍ አካል መቀልበስ ላይ ሊውል ይችላል ነው.
///
///
/// [`Vec::sort_by_key`]: ../../std/vec/struct.Vec.html#method.sort_by_key
///
/// # Examples
///
/// ```
/// use std::cmp::Reverse;
///
/// let mut v = vec![1, 2, 3, 4, 5, 6];
/// v.sort_by_key(|&num| (num > 3, Reverse(num)));
/// assert_eq!(v, vec![3, 2, 1, 6, 5, 4]);
/// ```
#[derive(PartialEq, Eq, Debug, Copy, Clone, Default, Hash)]
#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
#[repr(transparent)]
pub struct Reverse<T>(#[stable(feature = "reverse_cmp_key", since = "1.19.0")] pub T);

#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
impl<T: PartialOrd> PartialOrd for Reverse<T> {
    #[inline]
    fn partial_cmp(&self, other: &Reverse<T>) -> Option<Ordering> {
        other.0.partial_cmp(&self.0)
    }

    #[inline]
    fn lt(&self, other: &Self) -> bool {
        other.0 < self.0
    }
    #[inline]
    fn le(&self, other: &Self) -> bool {
        other.0 <= self.0
    }
    #[inline]
    fn gt(&self, other: &Self) -> bool {
        other.0 > self.0
    }
    #[inline]
    fn ge(&self, other: &Self) -> bool {
        other.0 >= self.0
    }
}

#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
impl<T: Ord> Ord for Reverse<T> {
    #[inline]
    fn cmp(&self, other: &Reverse<T>) -> Ordering {
        other.0.cmp(&self.0)
    }
}

/// አንድ [total order](https://en.wikipedia.org/wiki/Total_order) ቅርጽ እንደሆነ አይነቶች Trait.
///
/// አንድ ትዕዛዝ (ሁሉም `a`, `b` እና `c` ለ) ይህ ከሆነ አንድ ጠቅላላ ቅደም ተከተል ነው:
///
/// - ጠቅላላ እና ያልተመጣጠነ-በትክክል ከ `a < b` ፣ `a == b` ወይም `a > b` እውነት ነው ፣እና
/// - ተሻጋሪ, `a < b` እና `b < c` `a < c` ያመለክታል.`==` እና `>` ለሁለቱም ተመሳሳይ የግድ መያዝ.
///
/// ## Derivable
///
/// ይህ trait ከ `#[derive]` ጋር ሊያገለግል ይችላል።
/// በ‹ስትራንድ›ላይ ሲወርድ ፣ በመዋቅሩ አባላት ከላይ እስከ ታች ባለው የማስታወቂያ ትዕዛዝ ላይ በመመርኮዝ የ [lexicographic](https://en.wikipedia.org/wiki/Lexicographic_order) ቅደም ተከተል ያስገኛል ፡፡
///
/// በኤንኤሞች ላይ ሲወርድ ልዩ ልዩ ዓይነቶች ከላይ እስከ ታች ባለው አድሎአዊ ትዕዛዝ ይታዘዛሉ ፡፡
///
/// ## የቃላት አጻጻፍ ንፅፅር
///
/// የሬክሲኮግራፊክ ንፅፅር ከሚከተሉት ባህሪዎች ጋር የሚደረግ ክወና ነው-
///  - ሁለት ተከታታይ አባል በ አባል ሲነፃፀር ነው.
///  - የመጀመሪያው ያልተዛባ አካል ከሌይኮግራፊክ ያነሰ ወይም የሚበልጥ የትኛው ቅደም ተከተል እንደሆነ ይገልጻል።
///  - አንድ ቅደም ተከተል ከሌላው የቅድመ-ቅጥያ ከሆነ አጭሩ ቅደም ተከተል ከሌላው ጋር በስነ-መለኪያው ያነሰ ነው።
///  - ሁለት ቅደም ተከተል ተመጣጣኝ ንጥረ ያላቸው እና ተመሳሳይ ርዝመት ናቸው ከሆነ, ከዚያም ተከታታይ lexicographically እኩል ናቸው.
///  - ባዶ ቅደም ተከተል ከማንኛውም ባዶ ያልሆኑ ቅደም ተከተሎች በስነ-ልሳናዊ አነጋገር ያነሰ ነው።
///  - ሁለት ባዶ ቅደም ተከተሎች በስነ-አነጋገር እኩል ናቸው።
///
/// ## እንዴት ብዬ `Ord` መተግበር እንችላለን?
///
/// `Ord` ዓይነቱም [`PartialOrd`] እና [`Eq`] ([`PartialEq`] ን የሚፈልግ) መሆን ይፈልጋል።
///
/// ከዚያም [`cmp`] አንድ አፈፃፀም መግለጽ አለበት.በእርስዎ ዓይነት መስኮች ላይ [`cmp`] ን መጠቀሙ ጠቃሚ ሆኖ ሊያገኙት ይችላሉ ፡፡
///
/// የ [`PartialEq`] ፣ [`PartialOrd`] እና `Ord`*ትግበራዎች* እርስ በርሳቸው መስማማት አለባቸው።
/// ያ ማለት `a.cmp(b) == Ordering::Equal` ከሆነ እና ለሁሉም `a` እና `b` ከሆነ `a == b` እና `Some(a.cmp(b)) == a.partial_cmp(b)` ከሆነ ብቻ ፡፡
/// አንዳንድ የ traits ን በማግኘት እና ሌሎችን በእጅ በመተግበር በአጋጣሚ እንዲስማሙ ማድረግ ቀላል ነው ፡፡
///
/// እዚህ ቁመት ብቻ የሚንቀው `id` እና `name` ሰዎችን ለመደርደር ይፈልጋሉ ቦታ አንድ ምሳሌ ይኸውና:
///
/// ```
/// use std::cmp::Ordering;
///
/// #[derive(Eq)]
/// struct Person {
///     id: u32,
///     name: String,
///     height: u32,
/// }
///
/// impl Ord for Person {
///     fn cmp(&self, other: &Self) -> Ordering {
///         self.height.cmp(&other.height)
///     }
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         Some(self.cmp(other))
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// [`cmp`]: Ord::cmp
///
///
///
#[doc(alias = "<")]
#[doc(alias = ">")]
#[doc(alias = "<=")]
#[doc(alias = ">=")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Ord: Eq + PartialOrd<Self> {
    /// ይህ ዘዴ በ `self` እና `other` መካከል [`Ordering`] ን ይመልሳል።
    ///
    /// በስምምነት ፣ `self.cmp(&other)` እውነት ከሆነ `self <operator> other` ከሚለው አገላለጽ ጋር የሚዛመድ ቅደም ተከተል ይመልሳል።
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(5.cmp(&10), Ordering::Less);
    /// assert_eq!(10.cmp(&5), Ordering::Greater);
    /// assert_eq!(5.cmp(&5), Ordering::Equal);
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn cmp(&self, other: &Self) -> Ordering;

    /// ከፍተኛውን ሁለት እሴቶች ያወዳድራል እንዲሁም ይመልሳል።
    ///
    /// ንፅፅሩ እኩል እንዲሆኑ ከወሰነ ሁለተኛውን ክርክር ይመልሳል ፡፡
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(2, 1.max(2));
    /// assert_eq!(2, 2.max(2));
    /// ```
    #[stable(feature = "ord_max_min", since = "1.21.0")]
    #[inline]
    #[must_use]
    fn max(self, other: Self) -> Self
    where
        Self: Sized,
    {
        max_by(self, other, Ord::cmp)
    }

    /// አነስተኛውን ሁለት እሴቶች ያወዳድራል እንዲሁም ይመልሳል።
    ///
    /// ንፅፅሩ እኩል እንዲሆኑ ከወሰነ የመጀመሪያውን ክርክር ይመልሳል።
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(1, 1.min(2));
    /// assert_eq!(2, 2.min(2));
    /// ```
    #[stable(feature = "ord_max_min", since = "1.21.0")]
    #[inline]
    #[must_use]
    fn min(self, other: Self) -> Self
    where
        Self: Sized,
    {
        min_by(self, other, Ord::cmp)
    }

    /// እሴትን ለተወሰነ ክፍተት ይገድቡ።
    ///
    /// `self` ያነሰ `min` በላይ ከሆነ `self` `max` ይበልጣል, እና `min` ከሆነ `max` ይመልሳል.
    /// አለበለዚያ ይህ `self` ን ይመልሳል።
    ///
    /// # Panics
    ///
    /// `min > max` ከሆነ Panics።
    ///
    /// # Examples
    ///
    /// ```
    /// assert!((-3).clamp(-2, 1) == -2);
    /// assert!(0.clamp(-2, 1) == 0);
    /// assert!(2.clamp(-2, 1) == 1);
    /// ```
    #[must_use]
    #[stable(feature = "clamp", since = "1.50.0")]
    fn clamp(self, min: Self, max: Self) -> Self
    where
        Self: Sized,
    {
        assert!(min <= max);
        if self < min {
            min
        } else if self > max {
            max
        } else {
            self
        }
    }
}

/// የ trait `Ord` አንድ impl በማመንጨት ሊሆኗቸው ማክሮ.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics)]
pub macro Ord($item:item) {
    /* compiler built-in */
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Eq for Ordering {}

#[stable(feature = "rust1", since = "1.0.0")]
impl Ord for Ordering {
    #[inline]
    fn cmp(&self, other: &Ordering) -> Ordering {
        (*self as i32).cmp(&(*other as i32))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialOrd for Ordering {
    #[inline]
    fn partial_cmp(&self, other: &Ordering) -> Option<Ordering> {
        (*self as i32).partial_cmp(&(*other as i32))
    }
}

/// ለአንድ ዓይነት ትዕዛዝ ሊነፃፀሩ ለሚችሉ እሴቶች Trait
///
/// የ ንጽጽር ሁሉ `a`, `b` እና `c` ለ, ማርካት አለበት:
///
/// - asymmetry: `a < b` ከዚያም `!(a > b)`, እንዲሁም `a > b` `!(a < b)` አይተረጎሙም ከሆነ;እና
/// - መተላለፍ: `a < b` እና `b < c` `a < c` ን ያመለክታል ፡፡`==` እና `>` ለሁለቱም ተመሳሳይ የግድ መያዝ.
///
/// ማስታወሻ እነዚህ መስፈርቶች በ trait ራሱ symmetrically እና transitively ተግባራዊ መሆን አለበት ማለት እንደሆነ: ከሆነ `T: PartialOrd<U>` እና `U: PartialOrd<V>` ከዚያም `U: PartialOrd<T>` እና `ቲ:
///
/// PartialOrd<V>`.
///
/// ## Derivable
///
/// ይህ trait ከ `#[derive]` ጋር ሊያገለግል ይችላል።structs ላይ derive`d ጊዜ`, ይህ struct አባላት ወደ ከፍተኛ-ወደ-ታች መግለጫ ትዕዛዝ ላይ የተመሠረተ lexicographic አደራደር ያፈራል.
/// በኤንኤሞች ላይ ሲወርድ ልዩ ልዩ ዓይነቶች ከላይ እስከ ታች ባለው አድሎአዊ ትዕዛዝ ይታዘዛሉ ፡፡
///
/// ## `PartialOrd` ን እንዴት ተግባራዊ ማድረግ እችላለሁ?
///
/// `PartialOrd` ብቻ ነባሪ አፈጻጸም የመነጩ ሌሎች ጋር [`partial_cmp`] ዘዴ አተገባበር, ይጠይቃል.
///
/// ሆኖም አጠቃላይ ትዕዛዝ ለሌላቸው ዓይነቶች ሌሎቹን በተናጠል ለመተግበር አሁንም ይቀራል ፡፡
/// ለምሳሌ ፣ ለመንሳፈፊያ ነጥብ ቁጥሮች ፣ `NaN < 0 == false` እና `NaN >= 0 == false` (ዝ.ከ.
/// IEEE 754-2008 ክፍል 5.11).
///
/// `PartialOrd` የእርስዎ ዓይነት [`PartialEq`] እንዲሆን ይፈልጋል።
///
/// የ [`PartialEq`] ፣ `PartialOrd` እና [`Ord`]*ትግበራዎች* እርስ በርሳቸው መስማማት አለባቸው።
/// አንዳንድ የ traits ን በማግኘት እና ሌሎችን በእጅ በመተግበር በአጋጣሚ እንዲስማሙ ማድረግ ቀላል ነው ፡፡
///
/// የእርስዎ አይነት [`Ord`] ከሆነ, [`cmp`] በመጠቀም [`partial_cmp`] ተግባራዊ ይችላሉ:
///
/// ```
/// use std::cmp::Ordering;
///
/// #[derive(Eq)]
/// struct Person {
///     id: u32,
///     name: String,
///     height: u32,
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         Some(self.cmp(other))
///     }
/// }
///
/// impl Ord for Person {
///     fn cmp(&self, other: &Self) -> Ordering {
///         self.height.cmp(&other.height)
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// እንዲሁም በእርስዎ ዓይነት መስኮች ላይ [`partial_cmp`] ን መጠቀሙ ጠቃሚ ሆኖ ሊያገኙት ይችላሉ ፡፡
/// ለመደርደር የሚያገለግል ብቸኛ መስክ የሆነ ተንሳፋፊ-ነጥብ `height` መስክ ያላቸው የ `Person` ዓይነቶች ምሳሌ ይኸውልዎት-
///
/// ```
/// use std::cmp::Ordering;
///
/// struct Person {
///     id: u32,
///     name: String,
///     height: f64,
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         self.height.partial_cmp(&other.height)
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// # Examples
///
/// ```
/// let x : u32 = 0;
/// let y : u32 = 1;
///
/// assert_eq!(x < y, true);
/// assert_eq!(x.lt(&y), true);
/// ```
///
/// [`partial_cmp`]: PartialOrd::partial_cmp
/// [`cmp`]: Ord::cmp
///
///
///
///
#[lang = "partial_ord"]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = ">")]
#[doc(alias = "<")]
#[doc(alias = "<=")]
#[doc(alias = ">=")]
#[rustc_on_unimplemented(
    message = "can't compare `{Self}` with `{Rhs}`",
    label = "no implementation for `{Self} < {Rhs}` and `{Self} > {Rhs}`"
)]
pub trait PartialOrd<Rhs: ?Sized = Self>: PartialEq<Rhs> {
    /// ይህ ዘዴ አንድ ካለ በ `self` እና `other` እሴቶች መካከል ያለውን ቅደም ተከተል ይመልሳል።
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = 1.0.partial_cmp(&2.0);
    /// assert_eq!(result, Some(Ordering::Less));
    ///
    /// let result = 1.0.partial_cmp(&1.0);
    /// assert_eq!(result, Some(Ordering::Equal));
    ///
    /// let result = 2.0.partial_cmp(&1.0);
    /// assert_eq!(result, Some(Ordering::Greater));
    /// ```
    ///
    /// ማነፃፀር የማይቻል ሲሆን
    ///
    /// ```
    /// let result = f64::NAN.partial_cmp(&1.0);
    /// assert_eq!(result, None);
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn partial_cmp(&self, other: &Rhs) -> Option<Ordering>;

    /// ይህ ዘዴ ያነሰ (`self` እና `other` ለ) ከ ይፈትናል እና `<` ከዋኝ የሚጠቀሙበት ነው.
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 < 2.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 < 1.0;
    /// assert_eq!(result, false);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn lt(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Less))
    }

    /// ይህ ዘዴ ፍተሻዎች ወይም (`self` እና `other` ለ) እኩል እና `<=` ከዋኝ ውሏል ያነሰ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 <= 2.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 <= 2.0;
    /// assert_eq!(result, true);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn le(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Less | Equal))
    }

    /// ይህ ዘዴ (`self` እና `other` ለ) ይበልጣል ይፈትናል እና `>` ከዋኝ የሚጠቀሙበት ነው.
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 > 2.0;
    /// assert_eq!(result, false);
    ///
    /// let result = 2.0 > 2.0;
    /// assert_eq!(result, false);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn gt(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Greater))
    }

    /// ይህ ዘዴ (`self` እና `other` ለ) እኩል እና `>=` ከዋኝ ጥቅም ላይ የበለጠ ወይም የሚበልጥ ይፈትናል.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 2.0 >= 1.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 >= 2.0;
    /// assert_eq!(result, true);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn ge(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Greater | Equal))
    }
}

/// የ `trait `PartialOrd` ን ውጤት የሚያመነጭ ማክሮን ያግኙ ፡፡
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics)]
pub macro PartialOrd($item:item) {
    /* compiler built-in */
}

/// አነስተኛውን ሁለት እሴቶች ያወዳድራል እንዲሁም ይመልሳል።
///
/// ንፅፅሩ እኩል እንዲሆኑ ከወሰነ የመጀመሪያውን ክርክር ይመልሳል።
///
/// በውስጠ-ስያሜ ወደ [`Ord::min`] ይጠቀማል።
///
/// # Examples
///
/// ```
/// use std::cmp;
///
/// assert_eq!(1, cmp::min(1, 2));
/// assert_eq!(2, cmp::min(2, 2));
/// ```
#[inline]
#[must_use]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn min<T: Ord>(v1: T, v2: T) -> T {
    v1.min(v2)
}

/// ከተጠቀሰው የንፅፅር ተግባር አንጻር አነስተኛውን ሁለት እሴቶችን ይመልሳል።
///
/// ንፅፅሩ እኩል እንዲሆኑ ከወሰነ የመጀመሪያውን ክርክር ይመልሳል።
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::min_by(-2, 1, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), 1);
/// assert_eq!(cmp::min_by(-2, 2, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), -2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn min_by<T, F: FnOnce(&T, &T) -> Ordering>(v1: T, v2: T, compare: F) -> T {
    match compare(&v1, &v2) {
        Ordering::Less | Ordering::Equal => v1,
        Ordering::Greater => v2,
    }
}

/// ይመልሳል በተጠቀሰው ተግባር ከ ዝቅተኛ ዋጋ የሚሰጠው መሆኑን አባል.
///
/// ንፅፅሩ እኩል እንዲሆኑ ከወሰነ የመጀመሪያውን ክርክር ይመልሳል።
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::min_by_key(-2, 1, |x: &i32| x.abs()), 1);
/// assert_eq!(cmp::min_by_key(-2, 2, |x: &i32| x.abs()), -2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn min_by_key<T, F: FnMut(&T) -> K, K: Ord>(v1: T, v2: T, mut f: F) -> T {
    min_by(v1, v2, |v1, v2| f(v1).cmp(&f(v2)))
}

/// ከፍተኛውን ሁለት እሴቶች ያወዳድራል እንዲሁም ይመልሳል።
///
/// ንፅፅሩ እኩል እንዲሆኑ ከወሰነ ሁለተኛውን ክርክር ይመልሳል ፡፡
///
/// በውስጠ-ስያሜ ወደ [`Ord::max`] ይጠቀማል።
///
/// # Examples
///
/// ```
/// use std::cmp;
///
/// assert_eq!(2, cmp::max(1, 2));
/// assert_eq!(2, cmp::max(2, 2));
/// ```
#[inline]
#[must_use]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn max<T: Ord>(v1: T, v2: T) -> T {
    v1.max(v2)
}

/// በተጠቀሱት ንጽጽር ተግባር ጋር በተያያዘ ሁለት እሴቶች ከፍተኛው ያወጣል.
///
/// ንፅፅሩ እኩል እንዲሆኑ ከወሰነ ሁለተኛውን ክርክር ይመልሳል ፡፡
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::max_by(-2, 1, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), -2);
/// assert_eq!(cmp::max_by(-2, 2, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), 2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn max_by<T, F: FnOnce(&T, &T) -> Ordering>(v1: T, v2: T, compare: F) -> T {
    match compare(&v1, &v2) {
        Ordering::Less | Ordering::Equal => v2,
        Ordering::Greater => v1,
    }
}

/// ይመልሳል በተጠቀሰው ተግባር ጀምሮ ከፍተኛ ዋጋ የሚሰጠው መሆኑን አባል.
///
/// ንፅፅሩ እኩል እንዲሆኑ ከወሰነ ሁለተኛውን ክርክር ይመልሳል ፡፡
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::max_by_key(-2, 1, |x: &i32| x.abs()), -2);
/// assert_eq!(cmp::max_by_key(-2, 2, |x: &i32| x.abs()), 2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn max_by_key<T, F: FnMut(&T) -> K, K: Ord>(v1: T, v2: T, mut f: F) -> T {
    max_by(v1, v2, |v1, v2| f(v1).cmp(&f(v2)))
}

// የጥንታዊ ዓይነቶች የ PartialEq ፣ Eq ፣ PartialOrd እና Ord ትግበራ
mod impls {
    use crate::cmp::Ordering::{self, Equal, Greater, Less};
    use crate::hint::unreachable_unchecked;

    macro_rules! partial_eq_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialEq for $t {
                #[inline]
                fn eq(&self, other: &$t) -> bool { (*self) == (*other) }
                #[inline]
                fn ne(&self, other: &$t) -> bool { (*self) != (*other) }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialEq for () {
        #[inline]
        fn eq(&self, _other: &()) -> bool {
            true
        }
        #[inline]
        fn ne(&self, _other: &()) -> bool {
            false
        }
    }

    partial_eq_impl! {
        bool char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 f32 f64
    }

    macro_rules! eq_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl Eq for $t {}
        )*)
    }

    eq_impl! { () bool char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 }

    macro_rules! partial_ord_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialOrd for $t {
                #[inline]
                fn partial_cmp(&self, other: &$t) -> Option<Ordering> {
                    match (self <= other, self >= other) {
                        (false, false) => None,
                        (false, true) => Some(Greater),
                        (true, false) => Some(Less),
                        (true, true) => Some(Equal),
                    }
                }
                #[inline]
                fn lt(&self, other: &$t) -> bool { (*self) < (*other) }
                #[inline]
                fn le(&self, other: &$t) -> bool { (*self) <= (*other) }
                #[inline]
                fn ge(&self, other: &$t) -> bool { (*self) >= (*other) }
                #[inline]
                fn gt(&self, other: &$t) -> bool { (*self) > (*other) }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialOrd for () {
        #[inline]
        fn partial_cmp(&self, _: &()) -> Option<Ordering> {
            Some(Equal)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialOrd for bool {
        #[inline]
        fn partial_cmp(&self, other: &bool) -> Option<Ordering> {
            Some(self.cmp(other))
        }
    }

    partial_ord_impl! { f32 f64 }

    macro_rules! ord_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialOrd for $t {
                #[inline]
                fn partial_cmp(&self, other: &$t) -> Option<Ordering> {
                    Some(self.cmp(other))
                }
                #[inline]
                fn lt(&self, other: &$t) -> bool { (*self) < (*other) }
                #[inline]
                fn le(&self, other: &$t) -> bool { (*self) <= (*other) }
                #[inline]
                fn ge(&self, other: &$t) -> bool { (*self) >= (*other) }
                #[inline]
                fn gt(&self, other: &$t) -> bool { (*self) > (*other) }
            }

            #[stable(feature = "rust1", since = "1.0.0")]
            impl Ord for $t {
                #[inline]
                fn cmp(&self, other: &$t) -> Ordering {
                    // የበለጠ ተስማሚ ስብሰባ ለመፍጠር እዚህ ያለው ትዕዛዝ አስፈላጊ ነው።
                    // ለተጨማሪ መረጃ <https://github.com/rust-lang/rust/issues/63758> ን ይመልከቱ።
                    if *self < *other { Less }
                    else if *self == *other { Equal }
                    else { Greater }
                }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl Ord for () {
        #[inline]
        fn cmp(&self, _other: &()) -> Ordering {
            Equal
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl Ord for bool {
        #[inline]
        fn cmp(&self, other: &bool) -> Ordering {
            // ወደ i8 ቶች መውሰድ እና ልዩነቱን ወደ ትዕዛዝ ማዘዋወር የበለጠ ጥሩ ስብሰባን ይፈጥራል።
            //
            // ለተጨማሪ መረጃ <https://github.com/rust-lang/rust/issues/66780> ን ይመልከቱ።
            match (*self as i8) - (*other as i8) {
                -1 => Less,
                0 => Equal,
                1 => Greater,
                // ደህንነት: bool ልዩነት ሌላ ምንም ሊሆን አይችልም, ስለዚህ i8, 0 ወይም 1 ይመልሳል እንደ
                _ => unsafe { unreachable_unchecked() },
            }
        }
    }

    ord_impl! { char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 }

    #[unstable(feature = "never_type", issue = "35121")]
    impl PartialEq for ! {
        fn eq(&self, _: &!) -> bool {
            *self
        }
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Eq for ! {}

    #[unstable(feature = "never_type", issue = "35121")]
    impl PartialOrd for ! {
        fn partial_cmp(&self, _: &!) -> Option<Ordering> {
            *self
        }
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Ord for ! {
        fn cmp(&self, _: &!) -> Ordering {
            *self
        }
    }

    // &ጠቋሚዎች

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&B> for &A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialOrd<&B> for &A
    where
        A: PartialOrd<B>,
    {
        #[inline]
        fn partial_cmp(&self, other: &&B) -> Option<Ordering> {
            PartialOrd::partial_cmp(*self, *other)
        }
        #[inline]
        fn lt(&self, other: &&B) -> bool {
            PartialOrd::lt(*self, *other)
        }
        #[inline]
        fn le(&self, other: &&B) -> bool {
            PartialOrd::le(*self, *other)
        }
        #[inline]
        fn gt(&self, other: &&B) -> bool {
            PartialOrd::gt(*self, *other)
        }
        #[inline]
        fn ge(&self, other: &&B) -> bool {
            PartialOrd::ge(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Ord for &A
    where
        A: Ord,
    {
        #[inline]
        fn cmp(&self, other: &Self) -> Ordering {
            Ord::cmp(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Eq for &A where A: Eq {}

    // &mut pointers

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&mut B> for &mut A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&mut B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&mut B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialOrd<&mut B> for &mut A
    where
        A: PartialOrd<B>,
    {
        #[inline]
        fn partial_cmp(&self, other: &&mut B) -> Option<Ordering> {
            PartialOrd::partial_cmp(*self, *other)
        }
        #[inline]
        fn lt(&self, other: &&mut B) -> bool {
            PartialOrd::lt(*self, *other)
        }
        #[inline]
        fn le(&self, other: &&mut B) -> bool {
            PartialOrd::le(*self, *other)
        }
        #[inline]
        fn gt(&self, other: &&mut B) -> bool {
            PartialOrd::gt(*self, *other)
        }
        #[inline]
        fn ge(&self, other: &&mut B) -> bool {
            PartialOrd::ge(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Ord for &mut A
    where
        A: Ord,
    {
        #[inline]
        fn cmp(&self, other: &Self) -> Ordering {
            Ord::cmp(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Eq for &mut A where A: Eq {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&mut B> for &A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&mut B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&mut B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&B> for &mut A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
}