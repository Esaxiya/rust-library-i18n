//! አማራጭ እሴቶች።
//!
//! ዓይነት [`Option`] አማራጭ እሴትን ይወክላል-እያንዳንዱ [`Option`] ወይ [`Some`] ነው እና እሴት ይይዛል ፣ ወይም [`None`] ነው ፣ እና አያደርግም።
//! [`Option`] ዓይነቶች በ Rust ኮድ ውስጥ በጣም ብዙ ናቸው ፣ ምክንያቱም እነሱ በርካታ አጠቃቀሞች አሏቸው ፡፡
//!
//! * የመጀመሪያ እሴቶች
//! * በጠቅላላው የግብዓት ክልል ላይ ያልተገለጹ ተግባሮችን እሴቶችን ይመልሱ (ከፊል ተግባራት)
//! * ኤክስኤክስክስ በስህተት የሚመለስበት ቀላል ስህተቶችን በሌላ መንገድ ሪፖርት ለማድረግ ዋጋ ይመለስ
//! * አማራጭ የመዋቅር መስኮች
//! * ሊበደሩ ወይም "taken" ሊሆኑ የሚችሉ መስኮች ያዋቅሩ
//! * አማራጭ ተግባር ክርክሮች
//! * የማይነጣጠሉ ጠቋሚዎች
//! * ነገሮችን ከአስቸጋሪ ሁኔታዎች ውስጥ መለዋወጥ
//!
//! የ [`None`] ጉዳይ ዋጋን በመጠየቅ እና እርምጃ ለመውሰድ የ [`Option`] ዎች በተለምዶ ከንድፍ ተዛማጅነት ጋር ይጣመራሉ።
//!
//!
//! ```
//! fn divide(numerator: f64, denominator: f64) -> Option<f64> {
//!     if denominator == 0.0 {
//!         None
//!     } else {
//!         Some(numerator / denominator)
//!     }
//! }
//!
//! // የተግባሩ መመለሻ ዋጋ አማራጭ ነው
//! let result = divide(2.0, 3.0);
//!
//! // እሴቱን ለማምጣት የንድፍ ግጥሚያ
//! match result {
//!     // መከፋፈሉ ትክክል ነበር
//!     Some(x) => println!("Result: {}", x),
//!     // መከፋፈሉ ዋጋ የለውም
//!     None    => println!("Cannot divide by 0"),
//! }
//! ```
//!
//!
//!
//!
//!
// FIXME: `Option` ን ከብዙ ዘዴዎች ጋር በተግባር እንዴት እንደሚውል አሳይ
//
//! # አማራጮች እና ጠቋሚዎች ("nullable" አመልካቾች)
//!
//! የ Rust ጠቋሚ ዓይነቶች ሁልጊዜ ወደ ትክክለኛ ቦታ መጠቆም አለባቸው ፡፡የ "null" ማጣቀሻዎች የሉም።በምትኩ ፣ Rust እንደ አማራጭ ባለ ሣጥን ፣*`አማራጭ* አመልካቾች አሉት ፣ [` አማራጭ `]` <`[` Box<T>"]">
//!
//! የሚከተለው ምሳሌ የ [`i32`] አማራጭ ሣጥን ለመፍጠር [`Option`] ን ይጠቀማል ፡፡
//! ልብ ይበሉ በመጀመሪያ የውስጠኛውን [`i32`] እሴት ለመጠቀም የ `check_optional` ተግባር ሳጥኑ ዋጋ እንዳለው ወይም አለመሆኑን ለመለየት የንድፍ ማዛመጃን መጠቀም እንደሚያስፈልገው (ማለትም ፣ [`Some(...)`][`Some`]) ነው ወይም ([`None`]) አይደለም) ፡፡
//!
//!
//! ```
//! let optional = None;
//! check_optional(optional);
//!
//! let optional = Some(Box::new(9000));
//! check_optional(optional);
//!
//! fn check_optional(optional: Option<Box<i32>>) {
//!     match optional {
//!         Some(p) => println!("has value {}", p),
//!         None => println!("has no value"),
//!     }
//! }
//! ```
//!
//! # Representation
//!
//! Rust የሚከተሉትን ዓይነቶች `T` ለማመቻቸት ዋስትና ይሰጣል [`Option<T>`] ከ `T` ጋር ተመሳሳይ መጠን አለው
//!
//! * [`Box<U>`]
//! * `&U`
//! * `&mut U`
//! * `fn`, `extern "C" fn`
//! * [`num::NonZero*`]
//! * [`ptr::NonNull<U>`]
//! * `#[repr(transparent)]` በዚህ ዝርዝር ውስጥ በአንዱ ዓይነቶች ዙሪያ የተገነባ ፡፡
//!
//! ከዚህ በላይ ለተጠቀሱት ጉዳዮች አንድ ሰው [`mem::transmute`] ከሁሉም ትክክለኛ የ `T` እስከ `Option<T>` እና ከ `Some::<T>(_)` እስከ `T` (ግን `None::<T>` ን ወደ `T` ማስተላለፍ ያልተገለጸ ባህሪ ነው) መሆኑ የተረጋገጠ ነው ፡፡
//!
//! # Examples
//!
//! በ [`Option`] ላይ መሠረታዊ ንድፍ ማዛመድ:
//!
//! ```
//! let msg = Some("howdy");
//!
//! // ወደ ተያዘው ገመድ ማጣቀሻ ይውሰዱ
//! if let Some(m) = &msg {
//!     println!("{}", *m);
//! }
//!
//! // አማራጩን በማጥፋት የተገኘውን ሕብረቁምፊ ያስወግዱ
//! let unwrapped_msg = msg.unwrap_or("default message");
//! ```
//!
//! ከሉፕ በፊት ውጤቱን ለ [`None`] ያስጀምሩ
//!
//! ```
//! enum Kingdom { Plant(u32, &'static str), Animal(u32, &'static str) }
//!
//! // በውስጡ ለመፈለግ የውሂብ ዝርዝር።
//! let all_the_big_things = [
//!     Kingdom::Plant(250, "redwood"),
//!     Kingdom::Plant(230, "noble fir"),
//!     Kingdom::Plant(229, "sugar pine"),
//!     Kingdom::Animal(25, "blue whale"),
//!     Kingdom::Animal(19, "fin whale"),
//!     Kingdom::Animal(15, "north pacific right whale"),
//! ];
//!
//! // እኛ ትልቁ እንስሳ ስም ለመፈለግ ይሄዳሉ ፣ ግን ለመጀመር አሁን `None` ን አግኝተናል ፡፡
//! //
//! let mut name_of_biggest_animal = None;
//! let mut size_of_biggest_animal = 0;
//! for big_thing in &all_the_big_things {
//!     match *big_thing {
//!         Kingdom::Animal(size, name) if size > size_of_biggest_animal => {
//!             // አሁን የአንዳንድ ትልቅ እንስሳ ስም አግኝተናል
//!             size_of_biggest_animal = size;
//!             name_of_biggest_animal = Some(name);
//!         }
//!         Kingdom::Animal(..) | Kingdom::Plant(..) => ()
//!     }
//! }
//!
//! match name_of_biggest_animal {
//!     Some(name) => println!("the biggest animal is {}", name),
//!     None => println!("there are no animals :("),
//! }
//! ```
//!
//! [`Box<T>`]: ../../std/boxed/struct.Box.html
//! [`Box<U>`]: ../../std/boxed/struct.Box.html
//! [`num::NonZero*`]: crate::num
//! [`ptr::NonNull<U>`]: crate::ptr::NonNull
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::iter::{FromIterator, FusedIterator, TrustedLen};
use crate::pin::Pin;
use crate::{
    fmt, hint, mem,
    ops::{self, Deref, DerefMut},
};

/// የ `Option` ዓይነት።ለተጨማሪ [the module level documentation](self) ን ይመልከቱ።
#[derive(Copy, PartialEq, PartialOrd, Eq, Ord, Debug, Hash)]
#[rustc_diagnostic_item = "option_type"]
#[stable(feature = "rust1", since = "1.0.0")]
pub enum Option<T> {
    /// ዋጋ የለውም
    #[lang = "None"]
    #[stable(feature = "rust1", since = "1.0.0")]
    None,
    /// የተወሰነ ዋጋ `T`
    #[lang = "Some"]
    #[stable(feature = "rust1", since = "1.0.0")]
    Some(#[stable(feature = "rust1", since = "1.0.0")] T),
}

/////////////////////////////////////////////////////////////////////////////
// ይተይቡ ይተይቡ
/////////////////////////////////////////////////////////////////////////////

impl<T> Option<T> {
    /////////////////////////////////////////////////////////////////////////
    // ያሉትን እሴቶች በመጠየቅ ላይ
    /////////////////////////////////////////////////////////////////////////

    /// አማራጩ የ [`Some`] እሴት ከሆነ `true` ን ይመልሳል።
    ///
    /// # Examples
    ///
    /// ```
    /// let x: Option<u32> = Some(2);
    /// assert_eq!(x.is_some(), true);
    ///
    /// let x: Option<u32> = None;
    /// assert_eq!(x.is_some(), false);
    /// ```
    #[must_use = "if you intended to assert that this has a value, consider `.unwrap()` instead"]
    #[inline]
    #[rustc_const_stable(feature = "const_option", since = "1.48.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn is_some(&self) -> bool {
        matches!(*self, Some(_))
    }

    /// አማራጩ የ [`None`] እሴት ከሆነ `true` ን ይመልሳል።
    ///
    /// # Examples
    ///
    /// ```
    /// let x: Option<u32> = Some(2);
    /// assert_eq!(x.is_none(), false);
    ///
    /// let x: Option<u32> = None;
    /// assert_eq!(x.is_none(), true);
    /// ```
    #[must_use = "if you intended to assert that this doesn't have a value, consider \
                  `.and_then(|| panic!(\"`Option` had a value when expected `None`\"))` instead"]
    #[inline]
    #[rustc_const_stable(feature = "const_option", since = "1.48.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn is_none(&self) -> bool {
        !self.is_some()
    }

    /// አማራጩ የተሰጠውን እሴት የያዘ የ [`Some`] እሴት ከሆነ `true` ን ይመልሳል።
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_result_contains)]
    ///
    /// let x: Option<u32> = Some(2);
    /// assert_eq!(x.contains(&2), true);
    ///
    /// let x: Option<u32> = Some(3);
    /// assert_eq!(x.contains(&2), false);
    ///
    /// let x: Option<u32> = None;
    /// assert_eq!(x.contains(&2), false);
    /// ```
    #[must_use]
    #[inline]
    #[unstable(feature = "option_result_contains", issue = "62358")]
    pub fn contains<U>(&self, x: &U) -> bool
    where
        U: PartialEq<T>,
    {
        match self {
            Some(y) => x == y,
            None => false,
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // ከማጣቀሻዎች ጋር ለመስራት አስማሚ
    /////////////////////////////////////////////////////////////////////////

    /// ከ `&Option<T>` ወደ `Option<&T>` ይቀይራል።
    ///
    /// # Examples
    ///
    /// ዋናውን በመጠበቅ `አማራጭ <` [`String`]`>`ወደ`አማራጭ </[usize`] `> ይለውጣል ፡፡
    /// የ‹XXXX›ዘዴ የመጀመሪያውን የ‹`self`›ን ክርክር በእሴይቱ ይወስዳል ፣ ስለሆነም ይህ ዘዴ በመጀመሪያ `as_ref` ን በመጠቀም የመጀመሪያውን `Option` ን ወደ መጀመሪያው እሴት ውስጥ ወዳለው እሴት ለመጥቀስ ይጠቀማል ፡፡
    ///
    ///
    /// [`map`]: Option::map
    /// [`String`]: ../../std/string/struct.String.html
    ///
    /// ```
    /// let text: Option<String> = Some("Hello, world!".to_string());
    /// // በመጀመሪያ ፣ `Option<String>` ን ወደ `Option<&String>` ከ `as_ref` ጋር ይጣሉት ፣ ከዚያ *ያ* በ‹`map`›ይበሉ ፣ `text` ን በመደርደር ላይ ይተዉ ፡፡
    /////
    /// let text_length: Option<usize> = text.as_ref().map(|s| s.len());
    /// println!("still can print text: {:?}", text);
    /// ```
    ///
    #[inline]
    #[rustc_const_stable(feature = "const_option", since = "1.48.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn as_ref(&self) -> Option<&T> {
        match *self {
            Some(ref x) => Some(x),
            None => None,
        }
    }

    /// ከ `&mut Option<T>` ወደ `Option<&mut T>` ይቀይራል።
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = Some(2);
    /// match x.as_mut() {
    ///     Some(v) => *v = 42,
    ///     None => {},
    /// }
    /// assert_eq!(x, Some(42));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn as_mut(&mut self) -> Option<&mut T> {
        match *self {
            Some(ref mut x) => Some(x),
            None => None,
        }
    }

    /// ከ [`Pin`]`<&አማራጭ የተለወጡ<T>> ወደ"አማራጭ <"["Pin`]" <&T>> ".
    #[inline]
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn as_pin_ref(self: Pin<&Self>) -> Option<Pin<&T>> {
        // ደህንነት `x` ከ `self` ስለመጣ ለመሰካት የተረጋገጠ ነው
        // የተሰካ.
        unsafe { Pin::get_ref(self).as_ref().map(|x| Pin::new_unchecked(x)) }
    }

    /// ከ [`Pin`]`<&mut አማራጭ<T>> ወደ"አማራጭ <"["Pin`]" <&mut T>> ".
    #[inline]
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn as_pin_mut(self: Pin<&mut Self>) -> Option<Pin<&mut T>> {
        // ደህንነት `get_unchecked_mut` ን `Option` ን በ `self` ውስጥ ለማንቀሳቀስ በጭራሽ ጥቅም ላይ አይውልም ፡፡
        // `x` ለመሰካት የተረጋገጠ ነው ምክንያቱም ከተሰካው `self` የመጣ ነው።
        unsafe { Pin::get_unchecked_mut(self).as_mut().map(|x| Pin::new_unchecked(x)) }
    }

    /////////////////////////////////////////////////////////////////////////
    // ወደ ተያዙ እሴቶች ማግኘት
    /////////////////////////////////////////////////////////////////////////

    /// የ `self` ዋጋን በመያዝ የያዘውን የ [`Some`] እሴት ይመልሳል።
    ///
    /// # Panics
    ///
    /// `msg` ከሚሰጠው ብጁ panic መልእክት ጋር እሴቱ [`None`] ከሆነ Panics
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("value");
    /// assert_eq!(x.expect("fruits are healthy"), "value");
    /// ```
    ///
    /// ```should_panic
    /// let x: Option<&str> = None;
    /// x.expect("fruits are healthy"); // panics with `fruits are healthy`
    /// ```
    #[inline]
    #[track_caller]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn expect(self, msg: &str) -> T {
        match self {
            Some(val) => val,
            None => expect_failed(msg),
        }
    }

    /// የ `self` ዋጋን በመያዝ የያዘውን የ [`Some`] እሴት ይመልሳል።
    ///
    /// ምክንያቱም ይህ ተግባር panic ሊሆን ስለሚችል በአጠቃላይ አጠቃቀሙ ተስፋ ይቆርጣል ፡፡
    /// በምትኩ ፣ የንድፍ ማዛመድን ለመጠቀም እና የ [`None`] ጉዳይን በግልፅ ለማስተናገድ ይመርጣሉ ፣ ወይም ወደ [`unwrap_or`] ፣ [`unwrap_or_else`] ወይም [`unwrap_or_default`] ይደውሉ።
    ///
    ///
    /// [`unwrap_or`]: Option::unwrap_or
    /// [`unwrap_or_else`]: Option::unwrap_or_else
    /// [`unwrap_or_default`]: Option::unwrap_or_default
    ///
    /// # Panics
    ///
    /// የራስ እሴት ከ [`None`] ጋር እኩል ከሆነ Panics።
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("air");
    /// assert_eq!(x.unwrap(), "air");
    /// ```
    ///
    /// ```should_panic
    /// let x: Option<&str> = None;
    /// assert_eq!(x.unwrap(), "air"); // fails
    /// ```
    ///
    #[inline]
    #[track_caller]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_option", issue = "67441")]
    pub const fn unwrap(self) -> T {
        match self {
            Some(val) => val,
            None => panic!("called `Option::unwrap()` on a `None` value"),
        }
    }

    /// የያዘውን የ [`Some`] እሴት ወይም የቀረበውን ነባሪ ይመልሳል።
    ///
    /// ወደ `unwrap_or` የተላለፉ ክርክሮች በጉጉት ይገመገማሉ;የተግባር ጥሪ ውጤትን የሚያልፉ ከሆነ በስንፍና የሚገመገም [`unwrap_or_else`] ን እንዲጠቀሙ ይመከራል።
    ///
    ///
    /// [`unwrap_or_else`]: Option::unwrap_or_else
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(Some("car").unwrap_or("bike"), "car");
    /// assert_eq!(None.unwrap_or("bike"), "bike");
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn unwrap_or(self, default: T) -> T {
        match self {
            Some(x) => x,
            None => default,
        }
    }

    /// የያዘውን የ [`Some`] እሴት ይመልሳል ወይም ከመዘጋቱ ይሰላል።
    ///
    /// # Examples
    ///
    /// ```
    /// let k = 10;
    /// assert_eq!(Some(4).unwrap_or_else(|| 2 * k), 4);
    /// assert_eq!(None.unwrap_or_else(|| 2 * k), 20);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn unwrap_or_else<F: FnOnce() -> T>(self, f: F) -> T {
        match self {
            Some(x) => x,
            None => f(),
        }
    }

    /// እሴቱ [`None`] አለመሆኑን ሳያረጋግጥ የ `self` ዋጋን በመያዝ የተገኘውን የ [`Some`] እሴት ይመልሳል።
    ///
    ///
    /// # Safety
    ///
    /// ይህንን ዘዴ በ [`None`] ላይ መጥራት *[ያልተገለጸ ባህሪ]* ነው።
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_result_unwrap_unchecked)]
    /// let x = Some("air");
    /// assert_eq!(unsafe { x.unwrap_unchecked() }, "air");
    /// ```
    ///
    /// ```no_run
    /// #![feature(option_result_unwrap_unchecked)]
    /// let x: Option<&str> = None;
    /// assert_eq!(unsafe { x.unwrap_unchecked() }, "air"); // ያልተገለጸ ባህሪ!
    /// ```
    #[inline]
    #[track_caller]
    #[unstable(feature = "option_result_unwrap_unchecked", reason = "newly added", issue = "81383")]
    pub unsafe fn unwrap_unchecked(self) -> T {
        debug_assert!(self.is_some());
        match self {
            Some(val) => val,
            // ደህንነት-የደህንነቱ ውል በደዋዩ መከበር አለበት ፡፡
            None => unsafe { hint::unreachable_unchecked() },
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // የተያዙ እሴቶችን መለወጥ
    /////////////////////////////////////////////////////////////////////////

    /// ተግባርን በያዘ እሴት ላይ በመተግበር ከ `Option<T>` እስከ `Option<U>` ካርታዎችን ያሳያል ፡፡
    ///
    /// # Examples
    ///
    /// ዋናውን በመብላት አንድ `አማራጭ <` [`String`]`>`ወደ`አማራጭ </[usize`] `> ይለውጣል ፡፡
    ///
    /// [`String`]: ../../std/string/struct.String.html
    /// ```
    /// let maybe_some_string = Some(String::from("Hello, World!"));
    /// // `Option::map` `maybe_some_string` ን የሚወስድ ራስን *በእሴት* ይወስዳል
    /// let maybe_some_len = maybe_some_string.map(|s| s.len());
    ///
    /// assert_eq!(maybe_some_len, Some(13));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn map<U, F: FnOnce(T) -> U>(self, f: F) -> Option<U> {
        match self {
            Some(x) => Some(f(x)),
            None => None,
        }
    }

    /// ለተያዘው እሴት (ካለ) ተግባርን ይተገበራል ፣ ወይም የቀረበውን ነባሪ ይመልሳል (ካልሆነ)።
    ///
    /// ወደ `map_or` የተላለፉ ክርክሮች በጉጉት ይገመገማሉ;የተግባር ጥሪ ውጤትን የሚያልፉ ከሆነ በስንፍና የሚገመገም [`map_or_else`] ን እንዲጠቀሙ ይመከራል።
    ///
    ///
    /// [`map_or_else`]: Option::map_or_else
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("foo");
    /// assert_eq!(x.map_or(42, |v| v.len()), 3);
    ///
    /// let x: Option<&str> = None;
    /// assert_eq!(x.map_or(42, |v| v.len()), 42);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn map_or<U, F: FnOnce(T) -> U>(self, default: U, f: F) -> U {
        match self {
            Some(t) => f(t),
            None => default,
        }
    }

    /// አንድ ተግባር ለያዘው እሴት ይተገበራል (ካለ) ወይም ነባሪን ያሰላል (ካልሆነ)።
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let k = 21;
    ///
    /// let x = Some("foo");
    /// assert_eq!(x.map_or_else(|| 2 * k, |v| v.len()), 3);
    ///
    /// let x: Option<&str> = None;
    /// assert_eq!(x.map_or_else(|| 2 * k, |v| v.len()), 42);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn map_or_else<U, D: FnOnce() -> U, F: FnOnce(T) -> U>(self, default: D, f: F) -> U {
        match self {
            Some(t) => f(t),
            None => default(),
        }
    }

    /// `Option<T>` ን ወደ [`Result<T, E>`] ፣ ካርታ [`Some(v)`] ን ወደ [`Ok(v)`] እና [`None`] ወደ [`Err(err)`] ይቀይረዋል ፡፡
    ///
    /// ወደ `ok_or` የተላለፉ ክርክሮች በጉጉት ይገመገማሉ;የተግባር ጥሪ ውጤትን የሚያልፉ ከሆነ በስንፍና የሚገመገም [`ok_or_else`] ን እንዲጠቀሙ ይመከራል።
    ///
    ///
    /// [`Ok(v)`]: Ok
    /// [`Err(err)`]: Err
    /// [`Some(v)`]: Some
    /// [`ok_or_else`]: Option::ok_or_else
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("foo");
    /// assert_eq!(x.ok_or(0), Ok("foo"));
    ///
    /// let x: Option<&str> = None;
    /// assert_eq!(x.ok_or(0), Err(0));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ok_or<E>(self, err: E) -> Result<T, E> {
        match self {
            Some(v) => Ok(v),
            None => Err(err),
        }
    }

    /// `Option<T>` ን ወደ [`Result<T, E>`] ፣ ካርታ [`Some(v)`] ን ወደ [`Ok(v)`] እና [`None`] ወደ [`Err(err())`] ይቀይረዋል ፡፡
    ///
    ///
    /// [`Ok(v)`]: Ok
    /// [`Err(err())`]: Err
    /// [`Some(v)`]: Some
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("foo");
    /// assert_eq!(x.ok_or_else(|| 0), Ok("foo"));
    ///
    /// let x: Option<&str> = None;
    /// assert_eq!(x.ok_or_else(|| 0), Err(0));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ok_or_else<E, F: FnOnce() -> E>(self, err: F) -> Result<T, E> {
        match self {
            Some(v) => Ok(v),
            None => Err(err()),
        }
    }

    /// `value` ን ወደ አማራጩ ያስገባል ከዚያም ለእሱ የሚለዋወጥ ማጣቀሻ ይመልሳል።
    ///
    /// አማራጩ ቀድሞውኑ እሴት ከያዘ አሮጌው እሴት ወርዷል።
    ///
    /// # Example
    ///
    /// ```
    /// #![feature(option_insert)]
    ///
    /// let mut opt = None;
    /// let val = opt.insert(1);
    /// assert_eq!(*val, 1);
    /// assert_eq!(opt.unwrap(), 1);
    /// let val = opt.insert(2);
    /// assert_eq!(*val, 2);
    /// *val = 3;
    /// assert_eq!(opt.unwrap(), 3);
    /// ```
    #[inline]
    #[unstable(feature = "option_insert", reason = "newly added", issue = "78271")]
    pub fn insert(&mut self, value: T) -> &mut T {
        *self = Some(value);

        match self {
            Some(v) => v,
            // ደህንነት-ከላይ ያለው ኮድ አማራጩን ሞላው
            None => unsafe { hint::unreachable_unchecked() },
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // ኢተራክተር ገንቢዎች
    /////////////////////////////////////////////////////////////////////////

    /// ሊኖርበት በሚችለው እሴት ላይ አንድ ተደጋጋሚ ይመልሳል።
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some(4);
    /// assert_eq!(x.iter().next(), Some(&4));
    ///
    /// let x: Option<u32> = None;
    /// assert_eq!(x.iter().next(), None);
    /// ```
    #[inline]
    #[rustc_const_unstable(feature = "const_option", issue = "67441")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn iter(&self) -> Iter<'_, T> {
        Iter { inner: Item { opt: self.as_ref() } }
    }

    /// ሊኖርበት በሚችለው እሴት ላይ የሚለዋወጥ ተደጋጋሚ ይመልሳል።
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = Some(4);
    /// match x.iter_mut().next() {
    ///     Some(v) => *v = 42,
    ///     None => {},
    /// }
    /// assert_eq!(x, Some(42));
    ///
    /// let mut x: Option<u32> = None;
    /// assert_eq!(x.iter_mut().next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        IterMut { inner: Item { opt: self.as_mut() } }
    }

    /////////////////////////////////////////////////////////////////////////
    // የቦሊያን ክዋኔዎች በእሴቶቹ ላይ ፣ በጉጉት እና ሰነፎች
    /////////////////////////////////////////////////////////////////////////

    /// አማራጩ [`None`] ከሆነ [`None`] ን ይመልሳል ፣ አለበለዚያ `optb` ን ይመልሳል።
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some(2);
    /// let y: Option<&str> = None;
    /// assert_eq!(x.and(y), None);
    ///
    /// let x: Option<u32> = None;
    /// let y = Some("foo");
    /// assert_eq!(x.and(y), None);
    ///
    /// let x = Some(2);
    /// let y = Some("foo");
    /// assert_eq!(x.and(y), Some("foo"));
    ///
    /// let x: Option<u32> = None;
    /// let y: Option<&str> = None;
    /// assert_eq!(x.and(y), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn and<U>(self, optb: Option<U>) -> Option<U> {
        match self {
            Some(_) => optb,
            None => None,
        }
    }

    /// አማራጩ [`None`] ከሆነ [`None`] ን ይመልሳል ፣ አለበለዚያ በተጠቀለለው እሴት `f` ን ይደውላል እና ውጤቱን ይመልሳል።
    ///
    ///
    /// አንዳንድ ቋንቋዎች ይህንን ክዋኔ ጠፍጣፋ ብለው ይጠሩታል።
    ///
    /// # Examples
    ///
    /// ```
    /// fn sq(x: u32) -> Option<u32> { Some(x * x) }
    /// fn nope(_: u32) -> Option<u32> { None }
    ///
    /// assert_eq!(Some(2).and_then(sq).and_then(sq), Some(16));
    /// assert_eq!(Some(2).and_then(sq).and_then(nope), None);
    /// assert_eq!(Some(2).and_then(nope).and_then(sq), None);
    /// assert_eq!(None.and_then(sq).and_then(sq), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn and_then<U, F: FnOnce(T) -> Option<U>>(self, f: F) -> Option<U> {
        match self {
            Some(x) => f(x),
            None => None,
        }
    }

    /// አማራጩ [`None`] ከሆነ [`None`] ን ይመልሳል ፣ አለበለዚያ `predicate` ን በተጠቀለለው እሴት ይጠራል እና ይመልሳል
    ///
    ///
    /// - [`Some(t)`] `predicate` `true` ን ከመለሰ (`t` የተጠቀለለው እሴት ባለበት) ፣ እና
    /// - [`None`] `predicate` `false` ን ከመለሰ።
    ///
    /// ይህ ተግባር ከ [`Iterator::filter()`] ጋር ተመሳሳይ ነው የሚሰራው።
    /// `Option<T>` ከአንድ ወይም ከዜሮ አካላት በላይ ተደጋጋሚ ነው ብለው መገመት ይችላሉ።
    /// `filter()` የትኞቹን ንጥረ ነገሮች መጠበቅ እንዳለባቸው እንዲወስኑ ያስችልዎታል።
    ///
    /// # Examples
    ///
    /// ```rust
    /// fn is_even(n: &i32) -> bool {
    ///     n % 2 == 0
    /// }
    ///
    /// assert_eq!(None.filter(is_even), None);
    /// assert_eq!(Some(3).filter(is_even), None);
    /// assert_eq!(Some(4).filter(is_even), Some(4));
    /// ```
    ///
    /// [`Some(t)`]: Some
    ///
    #[inline]
    #[stable(feature = "option_filter", since = "1.27.0")]
    pub fn filter<P: FnOnce(&T) -> bool>(self, predicate: P) -> Self {
        if let Some(x) = self {
            if predicate(&x) {
                return Some(x);
            }
        }
        None
    }

    /// እሴትን ከያዘ አማራጩን ይመልሳል ፣ አለበለዚያ `optb` ን ይመልሳል።
    ///
    /// ወደ `or` የተላለፉ ክርክሮች በጉጉት ይገመገማሉ;የተግባር ጥሪ ውጤትን የሚያልፉ ከሆነ በስንፍና የሚገመገም [`or_else`] ን እንዲጠቀሙ ይመከራል።
    ///
    ///
    /// [`or_else`]: Option::or_else
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some(2);
    /// let y = None;
    /// assert_eq!(x.or(y), Some(2));
    ///
    /// let x = None;
    /// let y = Some(100);
    /// assert_eq!(x.or(y), Some(100));
    ///
    /// let x = Some(2);
    /// let y = Some(100);
    /// assert_eq!(x.or(y), Some(2));
    ///
    /// let x: Option<u32> = None;
    /// let y = None;
    /// assert_eq!(x.or(y), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn or(self, optb: Option<T>) -> Option<T> {
        match self {
            Some(_) => self,
            None => optb,
        }
    }

    /// እሴት ካለው አማራጩን ይመልሳል ፣ አለበለዚያ `f` ን ይደውላል እና ውጤቱን ይመልሳል።
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// fn nobody() -> Option<&'static str> { None }
    /// fn vikings() -> Option<&'static str> { Some("vikings") }
    ///
    /// assert_eq!(Some("barbarians").or_else(vikings), Some("barbarians"));
    /// assert_eq!(None.or_else(vikings), Some("vikings"));
    /// assert_eq!(None.or_else(nobody), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn or_else<F: FnOnce() -> Option<T>>(self, f: F) -> Option<T> {
        match self {
            Some(_) => self,
            None => f(),
        }
    }

    /// በትክክል ከ `self` ፣ `optb` [`Some`] ከሆነ [`Some`] ን ይመልሳል ፣ አለበለዚያ [`None`] ን ይመልሳል።
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some(2);
    /// let y: Option<u32> = None;
    /// assert_eq!(x.xor(y), Some(2));
    ///
    /// let x: Option<u32> = None;
    /// let y = Some(2);
    /// assert_eq!(x.xor(y), Some(2));
    ///
    /// let x = Some(2);
    /// let y = Some(2);
    /// assert_eq!(x.xor(y), None);
    ///
    /// let x: Option<u32> = None;
    /// let y: Option<u32> = None;
    /// assert_eq!(x.xor(y), None);
    /// ```
    #[inline]
    #[stable(feature = "option_xor", since = "1.37.0")]
    pub fn xor(self, optb: Option<T>) -> Option<T> {
        match (self, optb) {
            (Some(a), None) => Some(a),
            (None, Some(b)) => Some(b),
            _ => None,
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // የመግቢያ መሰል ክዋኔዎች ከሌሉ ለማስገባት እና ማጣቀሻ ለመመለስ
    /////////////////////////////////////////////////////////////////////////

    /// [`None`] ከሆነ ወደ `value` አማራጮችን ያስገባል ፣ ከዚያ ወደ ሚያለው እሴት የሚለዋወጥ ማጣቀሻ ይመልሳል።
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = None;
    ///
    /// {
    ///     let y: &mut u32 = x.get_or_insert(5);
    ///     assert_eq!(y, &5);
    ///
    ///     *y = 7;
    /// }
    ///
    /// assert_eq!(x, Some(7));
    /// ```
    #[inline]
    #[stable(feature = "option_entry", since = "1.20.0")]
    pub fn get_or_insert(&mut self, value: T) -> &mut T {
        self.get_or_insert_with(|| value)
    }

    /// ነባሪው እሴቱ [`None`] ከሆነ ወደ አማራጩ ያስገባል ፣ ከዚያ ወደ ሚያለው እሴት የሚለዋወጥ ማጣቀሻ ይመልሳል።
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_get_or_insert_default)]
    ///
    /// let mut x = None;
    ///
    /// {
    ///     let y: &mut u32 = x.get_or_insert_default();
    ///     assert_eq!(y, &0);
    ///
    ///     *y = 7;
    /// }
    ///
    /// assert_eq!(x, Some(7));
    /// ```
    #[inline]
    #[unstable(feature = "option_get_or_insert_default", issue = "82901")]
    pub fn get_or_insert_default(&mut self) -> &mut T
    where
        T: Default,
    {
        self.get_or_insert_with(Default::default)
    }

    /// [`None`] ከሆነ ከ `f` የተሰላ እሴት ወደ አማራጩ ያስገባል ፣ ከዚያ ወደ ሚያለው እሴት የሚለዋወጥ ማጣቀሻ ይመልሳል።
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = None;
    ///
    /// {
    ///     let y: &mut u32 = x.get_or_insert_with(|| 5);
    ///     assert_eq!(y, &5);
    ///
    ///     *y = 7;
    /// }
    ///
    /// assert_eq!(x, Some(7));
    /// ```
    #[inline]
    #[stable(feature = "option_entry", since = "1.20.0")]
    pub fn get_or_insert_with<F: FnOnce() -> T>(&mut self, f: F) -> &mut T {
        if let None = *self {
            *self = Some(f());
        }

        match self {
            Some(v) => v,
            // ደህንነት: ለ `self` የ `None` ልዩነት በ `Some` ሊተካ ነበር
            // ከላይ ባለው ኮድ ውስጥ ልዩነት
            None => unsafe { hint::unreachable_unchecked() },
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // Misc
    /////////////////////////////////////////////////////////////////////////

    /// [`None`] ን በእሱ ምትክ በመተው እሴቱን ከአማራጭ ይወስዳል።
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = Some(2);
    /// let y = x.take();
    /// assert_eq!(x, None);
    /// assert_eq!(y, Some(2));
    ///
    /// let mut x: Option<u32> = None;
    /// let y = x.take();
    /// assert_eq!(x, None);
    /// assert_eq!(y, None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn take(&mut self) -> Option<T> {
        mem::take(self)
    }

    /// በአማራጩ ውስጥ ያለውን ትክክለኛ እሴት በመለኪያ ውስጥ በተተካው ይተካዋል ፣ ከቀረበም የድሮውን እሴት ይመልሳል ፣ [`Some`] ን አንድም ሳያጠፋ ሳይተው በቦታው ይተዉታል።
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = Some(2);
    /// let old = x.replace(5);
    /// assert_eq!(x, Some(5));
    /// assert_eq!(old, Some(2));
    ///
    /// let mut x = None;
    /// let old = x.replace(3);
    /// assert_eq!(x, Some(3));
    /// assert_eq!(old, None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "option_replace", since = "1.31.0")]
    pub fn replace(&mut self, value: T) -> Option<T> {
        mem::replace(self, Some(value))
    }

    /// ዚፕስ `self` ከሌላ `Option` ጋር።
    ///
    /// `self` `Some(s)` እና `other` `Some(o)` ከሆነ ይህ ዘዴ `Some((s, o))` ን ይመልሳል።
    /// አለበለዚያ `None` ተመልሷል።
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some(1);
    /// let y = Some("hi");
    /// let z = None::<u8>;
    ///
    /// assert_eq!(x.zip(y), Some((1, "hi")));
    /// assert_eq!(x.zip(z), None);
    /// ```
    #[stable(feature = "option_zip_option", since = "1.46.0")]
    pub fn zip<U>(self, other: Option<U>) -> Option<(T, U)> {
        match (self, other) {
            (Some(a), Some(b)) => Some((a, b)),
            _ => None,
        }
    }

    /// ዚፕስ `self` እና ሌላ `Option` ከ `f` ተግባር ጋር።
    ///
    /// `self` `Some(s)` እና `other` `Some(o)` ከሆነ ይህ ዘዴ `Some(f(s, o))` ን ይመልሳል።
    /// አለበለዚያ `None` ተመልሷል።
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_zip)]
    ///
    /// #[derive(Debug, PartialEq)]
    /// struct Point {
    ///     x: f64,
    ///     y: f64,
    /// }
    ///
    /// impl Point {
    ///     fn new(x: f64, y: f64) -> Self {
    ///         Self { x, y }
    ///     }
    /// }
    ///
    /// let x = Some(17.5);
    /// let y = Some(42.7);
    ///
    /// assert_eq!(x.zip_with(y, Point::new), Some(Point { x: 17.5, y: 42.7 }));
    /// assert_eq!(x.zip_with(None, Point::new), None);
    /// ```
    #[unstable(feature = "option_zip", issue = "70086")]
    pub fn zip_with<U, F, R>(self, other: Option<U>, f: F) -> Option<R>
    where
        F: FnOnce(T, U) -> R,
    {
        Some(f(self?, other?))
    }
}

impl<T: Copy> Option<&T> {
    /// የምርጫውን ይዘቶች በመገልበጥ አንድ `Option<&T>` ን ወደ `Option<T>` ካርታዎች ያሳያል ፡፡
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x = 12;
    /// let opt_x = Some(&x);
    /// assert_eq!(opt_x, Some(&12));
    /// let copied = opt_x.copied();
    /// assert_eq!(copied, Some(12));
    /// ```
    #[stable(feature = "copied", since = "1.35.0")]
    pub fn copied(self) -> Option<T> {
        self.map(|&t| t)
    }
}

impl<T: Copy> Option<&mut T> {
    /// የምርጫውን ይዘቶች በመገልበጥ አንድ `Option<&mut T>` ን ወደ `Option<T>` ካርታዎች ያሳያል ፡፡
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = 12;
    /// let opt_x = Some(&mut x);
    /// assert_eq!(opt_x, Some(&mut 12));
    /// let copied = opt_x.copied();
    /// assert_eq!(copied, Some(12));
    /// ```
    #[stable(feature = "copied", since = "1.35.0")]
    pub fn copied(self) -> Option<T> {
        self.map(|&mut t| t)
    }
}

impl<T: Clone> Option<&T> {
    /// የአማራጭውን ይዘቶች በማጣመር አንድ `Option<&T>` ን ወደ `Option<T>` ካርታዎች ፡፡
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x = 12;
    /// let opt_x = Some(&x);
    /// assert_eq!(opt_x, Some(&12));
    /// let cloned = opt_x.cloned();
    /// assert_eq!(cloned, Some(12));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn cloned(self) -> Option<T> {
        self.map(|t| t.clone())
    }
}

impl<T: Clone> Option<&mut T> {
    /// የአማራጭውን ይዘቶች በማጣመር አንድ `Option<&mut T>` ን ወደ `Option<T>` ካርታዎች ፡፡
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = 12;
    /// let opt_x = Some(&mut x);
    /// assert_eq!(opt_x, Some(&mut 12));
    /// let cloned = opt_x.cloned();
    /// assert_eq!(cloned, Some(12));
    /// ```
    #[stable(since = "1.26.0", feature = "option_ref_mut_cloned")]
    pub fn cloned(self) -> Option<T> {
        self.map(|t| t.clone())
    }
}

impl<T: fmt::Debug> Option<T> {
    /// [`None`] ን ሲጠብቅ እና ምንም ሳይመልስ `self` ን ይወስዳል።
    ///
    /// # Panics
    ///
    /// የ Panics እሴቱ [`Some`] ከሆነ ፣ የተላለፈውን መልእክት እና የ [`Some`] ይዘትን ጨምሮ ከ panic መልእክት ጋር።
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_expect_none)]
    ///
    /// use std::collections::HashMap;
    /// let mut squares = HashMap::new();
    /// for i in -10..=10 {
    ///     // ሁሉም ቁልፎች ልዩ ስለሆኑ ይህ panic አይሆንም።
    ///     squares.insert(i, i * i).expect_none("duplicate key");
    /// }
    /// ```
    ///
    /// ```should_panic
    /// #![feature(option_expect_none)]
    ///
    /// use std::collections::HashMap;
    /// let mut sqrts = HashMap::new();
    /// for i in -10..=10 {
    ///     // This will panic, since both negative and positive `i` will
    ///     // insert the same `i * i` key, returning the old `Some(i)`.
    ///     sqrts.insert(i * i, i).expect_none("duplicate key");
    /// }
    /// ```
    #[inline]
    #[track_caller]
    #[unstable(feature = "option_expect_none", reason = "newly added", issue = "62633")]
    pub fn expect_none(self, msg: &str) {
        if let Some(val) = self {
            expect_none_failed(msg, &val);
        }
    }

    /// [`None`] ን ሲጠብቅ እና ምንም ሳይመልስ `self` ን ይወስዳል።
    ///
    /// # Panics
    ///
    /// Panics እሴቱ [`Some`] ከሆነ ፣ በብጁ `panic` መልእክት በ ``Some` `እሴት የቀረበ።
    ///
    ///
    /// [`Some(v)`]: Some
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_unwrap_none)]
    ///
    /// use std::collections::HashMap;
    /// let mut squares = HashMap::new();
    /// for i in -10..=10 {
    ///     // ሁሉም ቁልፎች ልዩ ስለሆኑ ይህ panic አይሆንም።
    ///     squares.insert(i, i * i).unwrap_none();
    /// }
    /// ```
    ///
    /// ```should_panic
    /// #![feature(option_unwrap_none)]
    ///
    /// use std::collections::HashMap;
    /// let mut sqrts = HashMap::new();
    /// for i in -10..=10 {
    ///     // This will panic, since both negative and positive `i` will
    ///     // insert the same `i * i` key, returning the old `Some(i)`.
    ///     sqrts.insert(i * i, i).unwrap_none();
    /// }
    /// ```
    #[inline]
    #[track_caller]
    #[unstable(feature = "option_unwrap_none", reason = "newly added", issue = "62633")]
    pub fn unwrap_none(self) {
        if let Some(val) = self {
            expect_none_failed("called `Option::unwrap_none()` on a `Some` value", &val);
        }
    }
}

impl<T: Default> Option<T> {
    /// የያዘውን የ [`Some`] እሴት ወይም ነባሪ ይመልሳል
    ///
    /// የ `self` ን ክርክር ይወስዳል ከዚያ [`Some`] ከሆነ የያዘውን እሴት ይመልሳል ፣ አለበለዚያ [`None`] ከሆነ ለዚያ ዓይነት [default value] ን ይመልሳል።
    ///
    ///
    /// # Examples
    ///
    /// በጥሩ ሁኔታ የተሰሩ ሕብረቁምፊዎችን ወደ 0 (የቁጥር ነባሪዎች እሴት) ወደ አንድ ቁጥር ይለውጣል።
    /// [`parse`] በስህተት ላይ [`None`] ን በመመለስ [`FromStr`] ን ወደሚያስፈጽም ሌላ ዓይነት ሕብረቁምፊ ይለውጣል።
    ///
    /// ```
    /// let good_year_from_input = "1909";
    /// let bad_year_from_input = "190blarg";
    /// let good_year = good_year_from_input.parse().ok().unwrap_or_default();
    /// let bad_year = bad_year_from_input.parse().ok().unwrap_or_default();
    ///
    /// assert_eq!(1909, good_year);
    /// assert_eq!(0, bad_year);
    /// ```
    ///
    /// [default value]: Default::default
    /// [`parse`]: str::parse
    /// [`FromStr`]: crate::str::FromStr
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn unwrap_or_default(self) -> T {
        match self {
            Some(x) => x,
            None => Default::default(),
        }
    }
}

impl<T: Deref> Option<T> {
    /// ከ `Option<T>` (ወይም `&Option<T>`) ወደ `Option<&T::Target>` ይቀይራል።
    ///
    /// የመጀመሪያውን (አማራጩን) በቦታው ይተወዋል ፣ ከዋናው ጋር በማጣቀሻ አዲስን በመፍጠር ይዘቱን በ [`Deref`] በኩል በማስገደድ ፡፡
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x: Option<String> = Some("hey".to_owned());
    /// assert_eq!(x.as_deref(), Some("hey"));
    ///
    /// let x: Option<String> = None;
    /// assert_eq!(x.as_deref(), None);
    /// ```
    #[stable(feature = "option_deref", since = "1.40.0")]
    pub fn as_deref(&self) -> Option<&T::Target> {
        self.as_ref().map(|t| t.deref())
    }
}

impl<T: DerefMut> Option<T> {
    /// ከ `Option<T>` (ወይም `&mut Option<T>`) ወደ `Option<&mut T::Target>` ይቀይራል።
    ///
    /// ወደ ውስጠኛው የ `Deref::Target` ዓይነት የሚለዋወጥ ማጣቀሻ የያዘ አዲስን በመፍጠር የመጀመሪያውን `Option` በቦታው ይተዋል ፡፡
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x: Option<String> = Some("hey".to_owned());
    /// assert_eq!(x.as_deref_mut().map(|x| {
    ///     x.make_ascii_uppercase();
    ///     x
    /// }), Some("HEY".to_owned().as_mut_str()));
    /// ```
    #[stable(feature = "option_deref", since = "1.40.0")]
    pub fn as_deref_mut(&mut self) -> Option<&mut T::Target> {
        self.as_mut().map(|t| t.deref_mut())
    }
}

impl<T, E> Option<Result<T, E>> {
    /// የ [`Result`] `Option` ን ወደ [`Result`] ወደ `Option` ይተላለፋል ፡፡
    ///
    /// [`None`] ወደ [`Ok`]`(`[None`]])` ካርታ ይደረጋል ፡፡
    /// [`Some`]`(`[`Ok`] `(_))` and [`Some`]`(`[`Err`] `(_))` to [`Ok`]`()`[`Some`] `(_))` and [`Err`]`(_)`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #[derive(Debug, Eq, PartialEq)]
    /// struct SomeErr;
    ///
    /// let x: Result<Option<i32>, SomeErr> = Ok(Some(5));
    /// let y: Option<Result<i32, SomeErr>> = Some(Ok(5));
    /// assert_eq!(x, y.transpose());
    /// ```
    #[inline]
    #[stable(feature = "transpose_result", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_option", issue = "67441")]
    pub const fn transpose(self) -> Result<Option<T>, E> {
        match self {
            Some(Ok(x)) => Ok(Some(x)),
            Some(Err(e)) => Err(e),
            None => Ok(None),
        }
    }
}

// የ .expect() ን ራሱ መጠን መጠን ለመቀነስ ይህ የተለየ ተግባር ነው።
#[inline(never)]
#[cold]
#[track_caller]
fn expect_failed(msg: &str) -> ! {
    panic!("{}", msg)
}

// የ .expect_none() ን ራሱ መጠን መጠን ለመቀነስ ይህ የተለየ ተግባር ነው።
#[inline(never)]
#[cold]
#[track_caller]
fn expect_none_failed(msg: &str, value: &dyn fmt::Debug) -> ! {
    panic!("{}: {:?}", msg, value)
}

/////////////////////////////////////////////////////////////////////////////
// የ Trait ትግበራዎች
/////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for Option<T> {
    #[inline]
    fn clone(&self) -> Self {
        match self {
            Some(x) => Some(x.clone()),
            None => None,
        }
    }

    #[inline]
    fn clone_from(&mut self, source: &Self) {
        match (self, source) {
            (Some(to), Some(from)) => to.clone_from(from),
            (to, from) => *to = from.clone(),
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for Option<T> {
    /// [`None`][Option::None] ን ይመልሳል።
    ///
    /// # Examples
    ///
    /// ```
    /// let opt: Option<u32> = Option::default();
    /// assert!(opt.is_none());
    /// ```
    #[inline]
    fn default() -> Option<T> {
        None
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> IntoIterator for Option<T> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// ሊኖርበት ከሚችለው እሴት በላይ የሚበላ ተደጋጋሚ ይመልሳል።
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("string");
    /// let v: Vec<&str> = x.into_iter().collect();
    /// assert_eq!(v, ["string"]);
    ///
    /// let x = None;
    /// let v: Vec<&str> = x.into_iter().collect();
    /// assert!(v.is_empty());
    /// ```
    #[inline]
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { inner: Item { opt: self } }
    }
}

#[stable(since = "1.4.0", feature = "option_iter")]
impl<'a, T> IntoIterator for &'a Option<T> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(since = "1.4.0", feature = "option_iter")]
impl<'a, T> IntoIterator for &'a mut Option<T> {
    type Item = &'a mut T;
    type IntoIter = IterMut<'a, T>;

    fn into_iter(self) -> IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(since = "1.12.0", feature = "option_from")]
impl<T> From<T> for Option<T> {
    /// ቅጂዎች `val` ወደ አዲስ `Some`።
    ///
    /// # Examples
    ///
    /// ```
    /// let o: Option<u8> = Option::from(67);
    ///
    /// assert_eq!(Some(67), o);
    /// ```
    fn from(val: T) -> Option<T> {
        Some(val)
    }
}

#[stable(feature = "option_ref_from_ref_option", since = "1.30.0")]
impl<'a, T> From<&'a Option<T>> for Option<&'a T> {
    /// ከ `&Option<T>` ወደ `Option<&T>` ይቀይራል።
    ///
    /// # Examples
    ///
    /// ዋናውን በመጠበቅ `አማራጭ <` [`String`]`>`ወደ`አማራጭ </[usize`] `> ይለውጣል ፡፡
    /// የ‹XXXX›ዘዴ የመጀመሪያውን የ‹`self`›ን ክርክር በእሴይቱ ይወስዳል ፣ ስለሆነም ይህ ዘዴ በመጀመሪያ `as_ref` ን በመጠቀም የመጀመሪያውን `Option` ን ወደ መጀመሪያው እሴት ውስጥ ወዳለው እሴት ለመጥቀስ ይጠቀማል ፡፡
    ///
    ///
    /// [`map`]: Option::map
    /// [`String`]: ../../std/string/struct.String.html
    ///
    /// ```
    /// let s: Option<String> = Some(String::from("Hello, Rustaceans!"));
    /// let o: Option<usize> = Option::from(&s).map(|ss: &String| ss.len());
    ///
    /// println!("Can still print s: {:?}", s);
    ///
    /// assert_eq!(o, Some(18));
    /// ```
    ///
    fn from(o: &'a Option<T>) -> Option<&'a T> {
        o.as_ref()
    }
}

#[stable(feature = "option_ref_from_ref_option", since = "1.30.0")]
impl<'a, T> From<&'a mut Option<T>> for Option<&'a mut T> {
    /// ከ `&mut Option<T>` ወደ `Option<&mut T>` ይቀይራል
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = Some(String::from("Hello"));
    /// let o: Option<&mut String> = Option::from(&mut s);
    ///
    /// match o {
    ///     Some(t) => *t = String::from("Hello, Rustaceans!"),
    ///     None => (),
    /// }
    ///
    /// assert_eq!(s, Some(String::from("Hello, Rustaceans!")));
    /// ```
    fn from(o: &'a mut Option<T>) -> Option<&'a mut T> {
        o.as_mut()
    }
}

/////////////////////////////////////////////////////////////////////////////
// የአማራጭ ተቃዋሚዎች
/////////////////////////////////////////////////////////////////////////////

#[derive(Clone, Debug)]
struct Item<A> {
    opt: Option<A>,
}

impl<A> Iterator for Item<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        self.opt.take()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        match self.opt {
            Some(_) => (1, Some(1)),
            None => (0, Some(0)),
        }
    }
}

impl<A> DoubleEndedIterator for Item<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        self.opt.take()
    }
}

impl<A> ExactSizeIterator for Item<A> {}
impl<A> FusedIterator for Item<A> {}
unsafe impl<A> TrustedLen for Item<A> {}

/// የ [`Option`] ን የ [`Some`] ልዩነት በማጣቀሻ ላይ አንድ ተደጋጋሚ።
///
/// [`Option`] [`Some`] ከሆነ ተደጋጋሚው አንድ ዋጋ ያስገኛል ፣ ካልሆነ ግን የለም።
///
/// ይህ `struct` በ [`Option::iter`] ተግባር የተፈጠረ ነው።
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug)]
pub struct Iter<'a, A: 'a> {
    inner: Item<&'a A>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, A> Iterator for Iter<'a, A> {
    type Item = &'a A;

    #[inline]
    fn next(&mut self) -> Option<&'a A> {
        self.inner.next()
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, A> DoubleEndedIterator for Iter<'a, A> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a A> {
        self.inner.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> ExactSizeIterator for Iter<'_, A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A> FusedIterator for Iter<'_, A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A> TrustedLen for Iter<'_, A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> Clone for Iter<'_, A> {
    #[inline]
    fn clone(&self) -> Self {
        Iter { inner: self.inner.clone() }
    }
}

/// አንድ የ [`Option`] የ‹[`Some`]›ልዩነት በሚቀያየር ማጣቀሻ ላይ አንድ ተደጋጋሚ።
///
/// [`Option`] [`Some`] ከሆነ ተደጋጋሚው አንድ ዋጋ ያስገኛል ፣ ካልሆነ ግን የለም።
///
/// ይህ `struct` በ [`Option::iter_mut`] ተግባር የተፈጠረ ነው።
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug)]
pub struct IterMut<'a, A: 'a> {
    inner: Item<&'a mut A>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, A> Iterator for IterMut<'a, A> {
    type Item = &'a mut A;

    #[inline]
    fn next(&mut self) -> Option<&'a mut A> {
        self.inner.next()
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, A> DoubleEndedIterator for IterMut<'a, A> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a mut A> {
        self.inner.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> ExactSizeIterator for IterMut<'_, A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A> FusedIterator for IterMut<'_, A> {}
#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A> TrustedLen for IterMut<'_, A> {}

/// በ‹X0XX›ልዩነት ውስጥ ካለው እሴት በላይ አንድ ተደጋጋሚ
///
/// [`Option`] [`Some`] ከሆነ ተደጋጋሚው አንድ ዋጋ ያስገኛል ፣ ካልሆነ ግን የለም።
///
/// ይህ `struct` በ [`Option::into_iter`] ተግባር የተፈጠረ ነው።
#[derive(Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct IntoIter<A> {
    inner: Item<A>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> Iterator for IntoIter<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        self.inner.next()
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> DoubleEndedIterator for IntoIter<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        self.inner.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> ExactSizeIterator for IntoIter<A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A> FusedIterator for IntoIter<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A> TrustedLen for IntoIter<A> {}

/////////////////////////////////////////////////////////////////////////////
// FromIterator
/////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, V: FromIterator<A>> FromIterator<Option<A>> for Option<V> {
    /// እያንዳንዱን ንጥረ ነገር በ [`Iterator`] ውስጥ ይወስዳል-[`None`][Option::None] ከሆነ ተጨማሪ ንጥረ ነገሮች አይወሰዱም እና [`None`][Option::None] ተመልሷል።
    /// ምንም [`None`][Option::None] መከሰት የለበትም ፣ የእያንዳንዱ [`Option`] እሴቶች ያለው መያዣ ተመልሷል።
    ///
    /// # Examples
    ///
    /// በ vector ውስጥ እያንዳንዱን ኢንቲጀር የሚጨምር ምሳሌ ይኸውልዎት።
    /// ስሌቱ ከመጠን በላይ ፍሰት በሚያስገኝበት ጊዜ `None` ን የሚመልስ የተረጋገጠ የ `add` ልዩነት እንጠቀማለን።
    ///
    /// ```
    /// let items = vec![0_u16, 1, 2];
    ///
    /// let res: Option<Vec<u16>> = items
    ///     .iter()
    ///     .map(|x| x.checked_add(1))
    ///     .collect();
    ///
    /// assert_eq!(res, Some(vec![1, 2, 3]));
    /// ```
    ///
    /// እንደሚመለከቱት ፣ ይህ የሚጠበቁትን ፣ ትክክለኛ እቃዎችን ይመልሳል ፡፡
    ///
    /// አንዱን ከሌላው የብዙ ቁጥሮች ዝርዝር ለመቀነስ የሚሞክር ሌላ ምሳሌ ይኸውልዎት ፣ በዚህ ጊዜ የውሃ ውስጥ ፍሰት መኖሩን ይፈትሻል ፡፡
    ///
    /// ```
    /// let items = vec![2_u16, 1, 0];
    ///
    /// let res: Option<Vec<u16>> = items
    ///     .iter()
    ///     .map(|x| x.checked_sub(1))
    ///     .collect();
    ///
    /// assert_eq!(res, None);
    /// ```
    ///
    /// የመጨረሻው ንጥረ ነገር ዜሮ ስለሆነ በውኃ ውስጥ ይፈስ ነበር።ስለሆነም የተገኘው እሴት `None` ነው።
    ///
    /// ከመጀመሪያው `None` በኋላ ምንም ተጨማሪ አካላት ከ `iter` እንደማይወሰዱ የሚያሳይ በቀድሞው ምሳሌ ላይ አንድ ልዩነት ይኸውልዎት ፡፡
    ///
    /// ```
    /// let items = vec![3_u16, 2, 1, 10];
    ///
    /// let mut shared = 0;
    ///
    /// let res: Option<Vec<u16>> = items
    ///     .iter()
    ///     .map(|x| { shared += x; x.checked_sub(2) })
    ///     .collect();
    ///
    /// assert_eq!(res, None);
    /// assert_eq!(shared, 6);
    /// ```
    ///
    /// ሦስተኛው ንጥረ ነገር የውሃ ፍሰትን ስለፈጠረ ተጨማሪ ንጥረ ነገሮች አልተወሰዱም ስለሆነም የ `shared` የመጨረሻው እሴት 16 አይደለም 6 (= `3 + 2 + 1`) ነው።
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    fn from_iter<I: IntoIterator<Item = Option<A>>>(iter: I) -> Option<V> {
        // FIXME(#11084): ይህ የአፈፃፀም ስህተት በሚዘጋበት ጊዜ ይህ በ Iterator::scan ሊተካ ይችላል።
        //

        iter.into_iter().map(|x| x.ok_or(())).collect::<Result<_, _>>().ok()
    }
}

/// የሙከራ ኦፕሬተር (`?`) ን ወደ `None` እሴት በመተግበር የሚመጣው የስህተት ዓይነት።
/// `x?` (`x` `Option<T>` በሆነበት ቦታ) ወደ እርስዎ የስህተት አይነት እንዲቀየር መፍቀድ ከፈለጉ `impl From<NoneError>` ን ለ `YourErrorType` መተግበር ይችላሉ።
///
/// ያ ከሆነ `Result<_, YourErrorType>` ን በሚመልስ ተግባር ውስጥ `x?` የ `None` እሴት ወደ `Err` ውጤት ይተረጉመዋል።
#[rustc_diagnostic_item = "none_error"]
#[unstable(feature = "try_trait", issue = "42327")]
#[derive(Clone, Copy, PartialEq, PartialOrd, Eq, Ord, Debug, Hash)]
pub struct NoneError;

#[unstable(feature = "try_trait", issue = "42327")]
impl<T> ops::Try for Option<T> {
    type Ok = T;
    type Error = NoneError;

    #[inline]
    fn into_result(self) -> Result<T, NoneError> {
        self.ok_or(NoneError)
    }

    #[inline]
    fn from_ok(v: T) -> Self {
        Some(v)
    }

    #[inline]
    fn from_error(_: NoneError) -> Self {
        None
    }
}

impl<T> Option<Option<T>> {
    /// ከ X01X ወደ X00X ይቀይራል
    ///
    /// # Examples
    ///
    /// መሠረታዊ አጠቃቀም
    ///
    /// ```
    /// let x: Option<Option<u32>> = Some(Some(6));
    /// assert_eq!(Some(6), x.flatten());
    ///
    /// let x: Option<Option<u32>> = Some(None);
    /// assert_eq!(None, x.flatten());
    ///
    /// let x: Option<Option<u32>> = None;
    /// assert_eq!(None, x.flatten());
    /// ```
    ///
    /// ዝርግ በአንድ ጊዜ አንድ የጎጆ ጎጆን ብቻ ያስወግዳል-
    ///
    /// ```
    /// let x: Option<Option<Option<u32>>> = Some(Some(Some(6)));
    /// assert_eq!(Some(Some(6)), x.flatten());
    /// assert_eq!(Some(6), x.flatten().flatten());
    /// ```
    #[inline]
    #[stable(feature = "option_flattening", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_option", issue = "67441")]
    pub const fn flatten(self) -> Option<T> {
        match self {
            Some(inner) => inner,
            None => None,
        }
    }
}