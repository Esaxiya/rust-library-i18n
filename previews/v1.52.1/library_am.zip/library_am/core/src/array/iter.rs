//! የ `IntoIter` ድርድሮች ለ ለተደጋጋሚ ባለቤትነት ይገልፃል.

use crate::{
    fmt,
    iter::{ExactSizeIterator, FusedIterator, TrustedLen},
    mem::{self, MaybeUninit},
    ops::Range,
    ptr,
};

/// አንድ በ-እሴት [array] ለተደጋጋሚ.
#[stable(feature = "array_value_iter", since = "1.51.0")]
pub struct IntoIter<T, const N: usize> {
    /// ይህ እኛ እየተለዋወጥን የምንሰራው ድርድር ነው ፡፡
    ///
    /// `alive.start <= i < alive.end` ገና ያልተሰጠባቸው እና ትክክለኛ የድርድር ግቤቶች ከሆኑበት መረጃ ጠቋሚ `i` ጋር ንጥረ ነገሮች።
    /// መረጃ ጠቋሚ `i < alive.start` ወይም `i >= alive.end` ያላቸው ንጥረ ነገሮች ቀድሞውኑ ተሰጥተዋል እናም ከእንግዲህ መድረስ የለባቸውም!እነዚህ ሙታን ንጥረ እንኳን ሙሉ በሙሉ uninitialized ሁኔታ ውስጥ ሊሆን ይችላል!
    ///
    ///
    /// ስለዚህ invariants ናቸው:
    /// - `data[alive]` ነው በህይወት (ማለትም ትክክል አባሎችን ይዟል)
    /// - `data[..alive.start]` እና `data[alive.end..]` ሞተዋል (ማለትም አባላቱ ቀድሞውኑ የተነበቡ ስለሆነ ከእንግዲህ መንካት የለባቸውም!)
    ///
    ///
    ///
    data: [MaybeUninit<T>; N],

    /// በ `data` ውስጥ ገና ያልተሰጡ ንጥረ ነገሮች።
    ///
    /// Invariants:
    /// - `alive.start <= alive.end`
    /// - `alive.end <= N`
    alive: Range<usize>,
}

impl<T, const N: usize> IntoIter<T, N> {
    /// የተሰጠው `array` ላይ አዲስ ለተደጋጋሚ ይፈጥራል.
    ///
    /// *ማስታወሻ*: ይህ ዘዴ ከ [`IntoIterator` is implemented for arrays][array-into-iter] በኋላ በ future ውስጥ ሊወድቅ ይችላል።
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::array;
    ///
    /// for value in array::IntoIter::new([1, 2, 3, 4, 5]) {
    ///     // `value` ዓይነት `&i32` ፋንታ, እዚህ `i32` ነው
    ///     let _: i32 = value;
    /// }
    /// ```
    /// [array-into-iter]: https://github.com/rust-lang/rust/pull/65819
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn new(array: [T; N]) -> Self {
        // ደህንነት እዚህ ያለው ትራንስፎርሜሽን በእውነቱ ደህና ነው ፡፡የ `MaybeUninit` ሰነዶች
        // promise:
        //
        // > `MaybeUninit<T>` ተመሳሳይ መጠን እና አሰላለፍ እንዲኖረው ዋስትና ነው
        // > እንደ `T`.
        //
        // ሰነዶች እንኳን ከ‹`MaybeUninit<T>`›ድርድር እስከ‹`T` X›ስብስብ ሽግግርን ያሳያሉ ፡፡
        //
        //
        // በመያዝ ይህ ማስጀመር የሚያጠግብ invariants.

        // FIXME(LukasKalbertodt): ከ‹‹XXXXXX›XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXDXDDDDDDDXlo ኮምፒተር/ጄኔቲክስ ጋር ከተሰራ በኋላ በትክክል `mem::transmute` ን እዚህ ይጠቀሙ ፡፡
        //     `mem::transmute::<[T; N], [MaybeUninit<T>; N]>(array)`
        //
        // እስከዚያ ድረስ, እኛ አንድ የተለየ አይነት እንደ አንድ bitwise ቅጂ ለመፍጠር `mem::transmute_copy` መጠቀም ይችላሉ, ከዚያ አንጠበጠቡ አይደለም ስለዚህ `array` አይረሳም.
        //
        //
        unsafe {
            let iter = Self { data: mem::transmute_copy(&array), alive: 0..N };
            mem::forget(array);
            iter
        }
    }

    /// እስካሁን ያልተሰጡትን ሁሉንም ንጥረ ነገሮች የማይለዋወጥ ቁርጥራጭ ይመልሳል።
    ///
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_slice(&self) -> &[T] {
        // ደህንነት በ `alive` ውስጥ ያሉ ሁሉም ንጥረ ነገሮች በትክክል የተጀመሩ መሆናቸውን እናውቃለን።
        unsafe {
            let slice = self.data.get_unchecked(self.alive.clone());
            MaybeUninit::slice_assume_init_ref(slice)
        }
    }

    /// እስካሁን ያልተሰጡትን ሁሉንም ንጥረ ነገሮች የሚለዋወጥ ቁራጭ ይመልሳል።
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        // ደህንነት በ `alive` ውስጥ ያሉ ሁሉም ንጥረ ነገሮች በትክክል የተጀመሩ መሆናቸውን እናውቃለን።
        unsafe {
            let slice = self.data.get_unchecked_mut(self.alive.clone());
            MaybeUninit::slice_assume_init_mut(slice)
        }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Iterator for IntoIter<T, N> {
    type Item = T;
    fn next(&mut self) -> Option<Self::Item> {
        // የሚቀጥለውን መረጃ ጠቋሚ ከፊት በኩል ያግኙ ፡፡
        //
        // `alive.start` ን በ 1 መጨመር `alive` ን በተመለከተ የማይለዋወጥ ያደርገዋል ፡፡
        // ሆኖም ፣ በዚህ ለውጥ ምክንያት ፣ ለአጭር ጊዜ ፣ ህያው ዞን ከእንግዲህ `data[alive]` አይደለም ፣ ግን `data[idx..alive.end]` ነው።
        //
        self.alive.next().map(|idx| {
            // ንጥረ ነገሩን ከድርድሩ ያንብቡ።
            // ደህንነት `idx` ወደ የቀድሞው የ "alive" ክልል መረጃ ጠቋሚ ነው
            // ድርድር.ይህንን ንጥረ ነገር ማንበብ ማለት `data[idx]` አሁን እንደሞተ ይቆጠራል ማለት ነው (ማለትም አትንኩ)።
            // `idx` የሕያው-ዞን ጅምር እንደነበረ ፣ ሕያው የሆነው ዞን አሁን ሁሉንም የማይለዋወጡትን ወደነበሩበት በመመለስ እንደገና `data[alive]` ነው ፡፡
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        let len = self.len();
        (len, Some(len))
    }

    fn count(self) -> usize {
        self.len()
    }

    fn last(mut self) -> Option<Self::Item> {
        self.next_back()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> DoubleEndedIterator for IntoIter<T, N> {
    fn next_back(&mut self) -> Option<Self::Item> {
        // የሚቀጥለውን መረጃ ጠቋሚ ከጀርባ ያግኙ።
        //
        // 1 በ `alive.end` እየቀነሰ `alive` በተመለከተ invariant ያቆያል.
        // ሆኖም ፣ በዚህ ለውጥ ምክንያት ፣ ለአጭር ጊዜ ፣ ህያው ዞን ከእንግዲህ `data[alive]` አይደለም ፣ ግን `data[alive.start..=idx]` ነው።
        //
        self.alive.next_back().map(|idx| {
            // ንጥረ ነገሩን ከድርድሩ ያንብቡ።
            // ደህንነት `idx` ወደ የቀድሞው የ "alive" ክልል መረጃ ጠቋሚ ነው
            // ድርድር.ይህንን ንጥረ ነገር ማንበብ ማለት `data[idx]` አሁን እንደሞተ ይቆጠራል ማለት ነው (ማለትም አትንኩ)።
            // `idx` የሕያው-ዞኑ መጨረሻ እንደነበረ ፣ ሕያው የሆነው ዞን አሁን ሁሉንም የማይለዋወጡትን ወደነበሩበት በመመለስ እንደገና `data[alive]` ነው ፡፡
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Drop for IntoIter<T, N> {
    fn drop(&mut self) {
        // ደህንነት ይህ ደህንነቱ የተጠበቀ ነው `as_mut_slice` ንዑስ ክፍሉን በትክክል ይመልሳል
        // እስካሁን ያልተነሱ እና ሊጣሉ የቀሩ አካላት።
        //
        unsafe { ptr::drop_in_place(self.as_mut_slice()) }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> ExactSizeIterator for IntoIter<T, N> {
    fn len(&self) -> usize {
        // ፈጽሞ underflow ምክንያት invariant ወደ `alive.start <=
        // alive.end`.
        self.alive.end - self.alive.start
    }
    fn is_empty(&self) -> bool {
        self.alive.is_empty()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> FusedIterator for IntoIter<T, N> {}

// ተደጋጋሚው በትክክል ትክክለኛውን ርዝመት ሪፖርት ያደርጋል ፡፡
// የ "alive" ንጥረ ነገሮች ብዛት (አሁንም ቢሆን የሚሰጠው) የ `alive` ክልል ርዝመት ነው።
// ይህ ክልል በ `next` ወይም `next_back` ውስጥ ርዝመቱ ቀንሷል ፡፡
// በእነዚያ ዘዴዎች ውስጥ ሁል ጊዜ በ 1 ቀንሷል ፣ ግን `Some(_)` ከተመለሰ ብቻ።
#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
unsafe impl<T, const N: usize> TrustedLen for IntoIter<T, N> {}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: Clone, const N: usize> Clone for IntoIter<T, N> {
    fn clone(&self) -> Self {
        // ማስታወሻ ፣ በእውነቱ ትክክለኛውን ተመሳሳይ የሕይወት ክልል ማዛመድ አያስፈልገንም ፣ ስለሆነም `self` የትም ቢሆን የትኛውም ቢሆን 0 ን ለማካካስ እንችላለን ፡፡
        //
        let mut new = Self { data: MaybeUninit::uninit_array(), alive: 0..0 };

        // ሁሉንም ህያው አካላት ይሰብስቡ።
        for (src, dst) in self.as_slice().iter().zip(&mut new.data) {
            // በአዲሱ ድርድር ውስጥ አንድ ክሎንን ይጻፉ ፣ ከዚያ ሕያው የሆነውን ክልል ያዘምኑ።
            // panics ን መልበስ ከሆነ ፣ የቀደሙትን ዕቃዎች በትክክል እንጥላለን።
            dst.write(src.clone());
            new.alive.end += 1;
        }

        new
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: fmt::Debug, const N: usize> fmt::Debug for IntoIter<T, N> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // ገና ያልተሰጡትን አካላት ብቻ ያትሙ-ያፈሩትን ንጥረ ነገሮች ከእንግዲህ መድረስ አንችልም ፡፡
        //
        f.debug_tuple("IntoIter").field(&self.as_slice()).finish()
    }
}