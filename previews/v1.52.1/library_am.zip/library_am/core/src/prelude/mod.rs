//! ሊብኮር ቅድመ-መከላከያ
//!
//! ይህ ሞጁል ለሊብስትራድ እንዲሁም ለማያገናኙ የሊብኮር ተጠቃሚዎች የታሰበ ነው ፡፡
//! `#![no_std]` እንደ መደበኛው ቤተ-መጽሐፍት prelude በተመሳሳይ ሁኔታ ጥቅም ላይ ሲውል ይህ ሞጁል በነባሪ ነው የሚመጣው።
//!

#![stable(feature = "core_prelude", since = "1.4.0")]

pub mod v1;

/// የዋናው prelude የ 2015 ስሪት።
///
/// ለተጨማሪ [module-level documentation](self) ን ይመልከቱ።
#[unstable(feature = "prelude_2015", issue = "none")]
pub mod rust_2015 {
    #[unstable(feature = "prelude_2015", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// የዋናው prelude የ 2018 ስሪት።
///
/// ለተጨማሪ [module-level documentation](self) ን ይመልከቱ።
#[unstable(feature = "prelude_2018", issue = "none")]
pub mod rust_2018 {
    #[unstable(feature = "prelude_2018", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// የ 2021 ዋናው የ prelude ስሪት።
///
/// ለተጨማሪ [module-level documentation](self) ን ይመልከቱ።
#[unstable(feature = "prelude_2021", issue = "none")]
pub mod rust_2021 {
    #[unstable(feature = "prelude_2021", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;

    // FIXME: ተጨማሪ ነገሮችን ያክሉ።
}