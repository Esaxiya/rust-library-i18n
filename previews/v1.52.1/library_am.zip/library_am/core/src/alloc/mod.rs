//! የማህደረ ትውስታ ምደባ ኤ.ፒ.አይ.ዎች

#![stable(feature = "alloc_module", since = "1.28.0")]

mod global;
mod layout;

#[stable(feature = "global_alloc", since = "1.28.0")]
pub use self::global::GlobalAlloc;
#[stable(feature = "alloc_layout", since = "1.28.0")]
pub use self::layout::Layout;
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
#[allow(deprecated, deprecated_in_future)]
pub use self::layout::LayoutErr;

#[stable(feature = "alloc_layout_error", since = "1.50.0")]
pub use self::layout::LayoutError;

use crate::fmt;
use crate::ptr::{self, NonNull};

/// የ `AllocError` ስህተት በዚህ allocator ጋር በተሰጠው ግቤት ጭቅጭቅ በማጣመር ጊዜ ሃብት በዴካም ወይም የሆነ ችግር ምክንያት ሊሆን ይችላል ዘንድ አንድ ምደባ አለመሳካት ያመለክታል.
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[derive(Copy, Clone, PartialEq, Eq, Debug)]
pub struct AllocError;

// (እኛ trait ስህተት ውስጥ ተፋሰስ impl ይህን ያስፈልጋቸዋል)
#[unstable(feature = "allocator_api", issue = "32838")]
impl fmt::Display for AllocError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("memory allocation failed")
    }
}

/// የ `Allocator` ትግበራ በ [`Layout`][] በኩል የተገለጹ የዘፈቀደ ብሎኮችን ሊመድብ ፣ ሊያድግ ፣ ሊቀንስ እና ሊያከፋፍል ይችላል ፡፡
///
/// `Allocator` እንደ `MyAlloc([u8; N])` ያለ አከፋፋይ መጠቆሚያዎችን ወደ ተመደበው ማህደረ ትውስታ ሳያሻሽሉ ሊዘዋወሩ ስለማይችሉ በ ZSTs ፣ በማጣቀሻዎች ወይም በዘመናዊ ጠቋሚዎች ላይ እንዲተገበር ነው።
///
/// እንደ [`GlobalAlloc`][] ሳይሆን ፣ ዜሮ መጠን ያላቸው ምደባዎች በ `Allocator` ውስጥ ይፈቀዳሉ።
/// ከስር ያለው አከፋፋይ ይህንን የማይደግፍ ከሆነ (እንደ ጀማልካል) ወይም የከንቱ ጠቋሚ (ለምሳሌ `libc::malloc`) ካልመለሰ ይህ በአፈፃፀም ሊያዝ ይገባል።
///
/// ### በአሁኑ ጊዜ የተመደበ ማህደረ ትውስታ
///
/// ዘዴዎች አንዳንዶቹ ትውስታ የማገጃ *በአሁኑ ጊዜ አንድ allocator በኩል* ይመደባል እንደሆነ ይጠይቃሉ.ይህ ማለት
///
/// * ለዚያ የማስታወሻ ማገጃ መነሻ አድራሻ ቀደም ሲል በ [`allocate`] ፣ [`grow`] ወይም [`shrink`] እና
///
/// * ብሎኮች በቀጥታ ወደ [`deallocate`] ተላልፈው በቀጥታ የሚተላለፉ ወይም ወደ [`grow`] ወይም `Ok` ን የሚመልስ [`shrink`] በሚለውጡበት ቦታ የማስታወሻ ማገጃው ከዚህ በኋላ አልተከፋፈለም ፡፡
///
/// `grow` ወይም `shrink` `Err` ን ከመለሱ ፣ የተላለፈው ጠቋሚ ልክ ሆኖ ይቀጥላል።
///
/// [`allocate`]: Allocator::allocate
/// [`grow`]: Allocator::grow
/// [`shrink`]: Allocator::shrink
/// [`deallocate`]: Allocator::deallocate
///
/// ### የማስታወሻ መገጣጠሚያ
///
/// ዘዴዎች መካከል አንዳንዶቹ ያስፈልጋቸዋል አቀማመጥ *የሚመጥን* ትውስታ የማገጃ ነው.
/// አንድ ትውስታ የማገጃ ማለት "fit" አንድ አቀማመጥ ለ ማለት ነው (ወይም equivalently, "fit" አንድ ትውስታ የማገጃ አቀማመጥ ለ) የሚከተሉት ሁኔታዎች መያዝ እንዳለባቸው ምንድን ነው:
///
/// * እገዳው ከ [`layout.align()`] ጋር በተመሳሳይ አሰላለፍ መመደብ አለበት ፣ እና
///
/// * የቀረበው [`layout.size()`] በ `min ..= max` ክልል ውስጥ መውደቅ አለበት ፣ በሚከተሉት
///   - `min` ብሎኩን ለመመደብ በጣም በቅርብ ጊዜ ጥቅም ላይ የዋለው የአቀማመጥ መጠን ነው ፣ እና
///   - `max` ከ [`allocate`] ፣ [`grow`] ወይም [`shrink`] የተመለሰው የመጨረሻው ትክክለኛ መጠን ነው።
///
/// [`layout.align()`]: Layout::align
/// [`layout.size()`]: Layout::size
///
/// # Safety
///
/// * ከአከፋፋይ የተመለሱ የማስታወሻ ማገጃዎች ወደ ትክክለኛ ማህደረ ትውስታ መጠቆም እና ምሳሌው እና ሁሉም ክሎኖቹ እስኪወገዱ ድረስ ትክክለኛነታቸውን መጠበቅ አለባቸው ፣
///
/// * የ allocator ከዚህ allocator ተመለሰ ሊያሳጣ ትውስታ ብሎኮች የለባቸውም መውሰድ በክሎኒንግ ወይም.ባለ አንድ ሰዓት ሰጭ እንደ ተመደበው ጠባይ ማሳየት አለበት ፣ እና
///
/// * [*currently allocated*] ነው ትውስታ የማገጃ ማንኛውም ጠቋሚ allocator ማንኛውም ሌላ ዘዴ ሊተላለፍ ይችላል.
///
/// [*currently allocated*]: #currently-allocated-memory
///
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
pub unsafe trait Allocator {
    /// ሙከራዎችን ትውስታ አንድ የማገጃ ለመመደብ.
    ///
    /// በስኬት ላይ የ `layout` መጠን እና የማጣጣም ዋስትናዎችን የሚያሟላ የ [`NonNull<[u8]>`][NonNull] ስብሰባን ይመልሳል።
    ///
    /// የ ተመልሶ የማገጃ `layout.size()` የተገለጸው በላይ ትልቅ መጠን ሊኖራቸው ይችላል, እና ወይም ይዘቶቹ አልተነሳም ላይኖራቸው ይችላል ይችላል.
    ///
    /// # Errors
    ///
    /// `Err` ን መመለስ አንድም ማህደረ ትውስታ እንደደከመ ወይም `layout` የአከፋፋዩን መጠን ወይም የአቀራረብ ገደቦችን የማያሟላ መሆኑን ያሳያል።
    ///
    /// ትግበራዎች ከመደናገጥ ወይም ፅንስ ከማስወረድ ይልቅ በማስታወስ ድካም ላይ `Err` ን እንዲመልሱ ይበረታታሉ ፣ ግን ይህ ጥብቅ መስፈርት አይደለም ፡፡
    /// (በተለይም በማስታወስ ድካሙ ላይ የሚወርደውን በመሰረታዊ የቤት ድልድል ቤተ-መጽሐፍት ላይ ይህን trait ተግባራዊ ማድረግ *ህጋዊ* ነው) ፡፡
    ///
    /// ከምደባ ስህተት ጋር ተያይዞ ስሌትን ለማስቀረት የሚፈልጉ ደንበኞች በቀጥታ `panic!` ወይም ተመሳሳይ ከመጠየቅ ይልቅ የ [`handle_alloc_error`] ተግባርን እንዲጠሩ ይበረታታሉ ፡፡
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError>;

    /// እንደ `allocate` ባህሪዎች ፣ ግን የተመለሰው ማህደረ ትውስታ በዜሮ የተጀመረ መሆኑን ያረጋግጣል።
    ///
    /// # Errors
    ///
    /// `Err` ን መመለስ አንድም ማህደረ ትውስታ እንደደከመ ወይም `layout` የአከፋፋዩን መጠን ወይም የአቀራረብ ገደቦችን የማያሟላ መሆኑን ያሳያል።
    ///
    /// ትግበራዎች ከመደናገጥ ወይም ፅንስ ከማስወረድ ይልቅ በማስታወስ ድካም ላይ `Err` ን እንዲመልሱ ይበረታታሉ ፣ ግን ይህ ጥብቅ መስፈርት አይደለም ፡፡
    /// (በተለይም በማስታወስ ድካሙ ላይ የሚወርደውን በመሰረታዊ የቤት ድልድል ቤተ-መጽሐፍት ላይ ይህን trait ተግባራዊ ማድረግ *ህጋዊ* ነው) ፡፡
    ///
    /// ከምደባ ስህተት ጋር ተያይዞ ስሌትን ለማስቀረት የሚፈልጉ ደንበኞች በቀጥታ `panic!` ወይም ተመሳሳይ ከመጠየቅ ይልቅ የ [`handle_alloc_error`] ተግባርን እንዲጠሩ ይበረታታሉ ፡፡
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        let ptr = self.allocate(layout)?;
        // ደህንነት: `alloc` ትክክለኛ ትውስታ የማገጃ ይመልሳል
        unsafe { ptr.as_non_null_ptr().as_ptr().write_bytes(0, ptr.len()) }
        Ok(ptr)
    }

    /// በ `ptr` የተጠቀሰውን ማህደረ ትውስታ ያከፋፍላል።
    ///
    /// # Safety
    ///
    /// * `ptr` ይህ allocator በኩል ትውስታ [*currently allocated*] አንድ የማገጃ ያመለክታል, እና አለበት
    /// * `layout` የግድ [*fit*] ትውስታ የማገጃ ነው.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout);

    /// የማስታወሻ ማገጃውን ለማራዘም የተደረጉ ሙከራዎች።
    ///
    /// አንድ ጠቋሚ እና መመደቡን ትውስታ ትክክለኛ መጠን የያዘ አዲስ [`NonNull<[u8]>`][NonNull] ያወጣል.የ ጠቋሚ `new_layout` በ ተገልጿል ውሂብ ይዞ ተስማሚ ነው.
    /// ይህን ለመፈጸም, ወደ allocator በአዲሱ አቀማመጥ ለማስማማት `ptr` በ የተጠቀሱት ድልድል ማራዘም ይችላል.
    ///
    /// ይህ `Ok` ን ከተመለሰ ታዲያ በ `ptr` የተጠቀሰው የማስታወሻ ማገጃ ባለቤትነት ወደዚህ አከፋፋይ ተላል hasል።
    /// ማህደረ ትውስታው ነፃ ሊሆን ወይም ላይሆን ይችላል ፣ እናም በዚህ ዘዴ ተመላሽ ዋጋ እንደገና ወደ ደዋዩ ካልተላለፈ በስተቀር ጥቅም ላይ የማይውል ተደርጎ ሊወሰድ ይገባል።
    ///
    /// ይህ ዘዴ `Err` ን ከተመለሰ ታዲያ የማስታወሻ ማገጃው ባለቤትነት ወደዚህ አከፋፋይ አልተላለፈም ፣ እና የማስታወሻ ማገጃው ይዘት አልተለወጠም።
    ///
    /// # Safety
    ///
    /// * `ptr` በዚህ አከፋፋይ በኩል የማስታወሻ [*currently allocated*] ን ማመልከት አለበት።
    /// * `old_layout` ይህ [*fit*] ያለበት የማስታወሻ ማገጃ (የ `new_layout` ክርክር እሱን መግጠም አያስፈልገውም።)።
    /// * `new_layout.size()` ከ `old_layout.size()` የበለጠ ወይም እኩል መሆን አለበት።
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// አዲሱ አቀማመጥ የአከፋፋዩን የመጠን እና የማጣጣም ገደቦችን የማያሟላ ከሆነ ወይም ደግሞ ማደግ ካልተሳካ `Err` ን ይመልሳል።
    ///
    /// ትግበራዎች ከመደናገጥ ወይም ፅንስ ከማስወረድ ይልቅ በማስታወስ ድካም ላይ `Err` ን እንዲመልሱ ይበረታታሉ ፣ ግን ይህ ጥብቅ መስፈርት አይደለም ፡፡
    /// (በተለይም በማስታወስ ድካሙ ላይ የሚወርደውን በመሰረታዊ የቤት ድልድል ቤተ-መጽሐፍት ላይ ይህን trait ተግባራዊ ማድረግ *ህጋዊ* ነው) ፡፡
    ///
    /// ከምደባ ስህተት ጋር ተያይዞ ስሌትን ለማስቀረት የሚፈልጉ ደንበኞች በቀጥታ `panic!` ወይም ተመሳሳይ ከመጠየቅ ይልቅ የ [`handle_alloc_error`] ተግባርን እንዲጠሩ ይበረታታሉ ፡፡
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // ደህንነት-ምክንያቱም `new_layout.size()` ከእኩል የበለጠ ወይም እኩል መሆን አለበት
        // `old_layout.size()`, የድሮው እና አዲሱ የማስታወሻ ምደባ ለንባብ እና ለ `old_layout.size()` ባይት ይጽፋል ፡፡
        // እንዲሁም ፣ የድሮው ምደባ ገና አልተከፋፈለም ፣ `new_ptr` ን መደራረብ አይችልም።
        // ስለዚህ ወደ `copy_nonoverlapping` የሚደረገው ጥሪ ደህንነቱ የተጠበቀ ነው።
        // ለ‹`dealloc` X›የደኅንነት ውል በተጠሪው መደገፍ አለበት ፡፡
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// እንደ `grow` ባህሪዎች አለው ፣ ግን አዲስ ይዘቶች ከመመለሳቸው በፊት ወደ ዜሮ መዋቀራቸውን ያረጋግጣል።
    ///
    /// ከተሳካ ጥሪ በኋላ የማስታወሻ ማገጃው የሚከተሉትን ይዘቶች ይይዛል
    /// `grow_zeroed`:
    ///   * ባይቶች `0..old_layout.size()` ከመጀመሪያው ምደባ ተጠብቀዋል።
    ///   * ባይቶች `old_layout.size()..old_size` ወይ allocator አፈፃፀም ላይ በመመስረት, ተጠብቆ ወይም zeroed ይደረጋል.
    ///   `old_size` ይህ የተመደበ ጊዜ መጀመሪያ የተጠየቀው መሆኑን መጠን ይልቅ ተለቅ ሊሆን ይችላል ይህም `grow_zeroed` ጥሪ, በፊት ትውስታ የማገጃ መጠን ያመለክታል.
    ///   * ባይቶች `old_size..new_size` ዜሮ ናቸው ፡፡`new_size` በ `grow_zeroed` ጥሪ የተመለሱ የማስታወስ የማገጃ መጠን ያመለክታል.
    ///
    /// # Safety
    ///
    /// * `ptr` በዚህ አከፋፋይ በኩል የማስታወሻ [*currently allocated*] ን ማመልከት አለበት።
    /// * `old_layout` ይህ [*fit*] ያለበት የማስታወሻ ማገጃ (የ `new_layout` ክርክር እሱን መግጠም አያስፈልገውም።)።
    /// * `new_layout.size()` ከ `old_layout.size()` የበለጠ ወይም እኩል መሆን አለበት።
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// አዲሱ አቀማመጥ የአከፋፋዩን የመጠን እና የማጣጣም ገደቦችን የማያሟላ ከሆነ ወይም ደግሞ ማደግ ካልተሳካ `Err` ን ይመልሳል።
    ///
    /// ትግበራዎች ከመደናገጥ ወይም ፅንስ ከማስወረድ ይልቅ በማስታወስ ድካም ላይ `Err` ን እንዲመልሱ ይበረታታሉ ፣ ግን ይህ ጥብቅ መስፈርት አይደለም ፡፡
    /// (በተለይም በማስታወስ ድካሙ ላይ የሚወርደውን በመሰረታዊ የቤት ድልድል ቤተ-መጽሐፍት ላይ ይህን trait ተግባራዊ ማድረግ *ህጋዊ* ነው) ፡፡
    ///
    /// ከምደባ ስህተት ጋር ተያይዞ ስሌትን ለማስቀረት የሚፈልጉ ደንበኞች በቀጥታ `panic!` ወይም ተመሳሳይ ከመጠየቅ ይልቅ የ [`handle_alloc_error`] ተግባርን እንዲጠሩ ይበረታታሉ ፡፡
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate_zeroed(new_layout)?;

        // ደህንነት-ምክንያቱም `new_layout.size()` ከእኩል የበለጠ ወይም እኩል መሆን አለበት
        // `old_layout.size()`, የድሮው እና አዲሱ የማስታወሻ ምደባ ለንባብ እና ለ `old_layout.size()` ባይት ይጽፋል ፡፡
        // እንዲሁም ፣ የድሮው ምደባ ገና አልተከፋፈለም ፣ `new_ptr` ን መደራረብ አይችልም።
        // ስለዚህ ወደ `copy_nonoverlapping` የሚደረገው ጥሪ ደህንነቱ የተጠበቀ ነው።
        // ለ‹`dealloc` X›የደኅንነት ውል በተጠሪው መደገፍ አለበት ፡፡
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// የማስታወሻውን ማገጃ ለመቀነስ ሙከራዎች።
    ///
    /// አንድ ጠቋሚ እና መመደቡን ትውስታ ትክክለኛ መጠን የያዘ አዲስ [`NonNull<[u8]>`][NonNull] ያወጣል.የ ጠቋሚ `new_layout` በ ተገልጿል ውሂብ ይዞ ተስማሚ ነው.
    /// ይህንን ለማሳካት አከፋፋዩ አዲሱን አቀማመጥ ለማስማማት በ `ptr` የተጠቀሰው ምደባ ሊቀንስ ይችላል።
    ///
    /// ይህ `Ok` ን ከተመለሰ ታዲያ በ `ptr` የተጠቀሰው የማስታወሻ ማገጃ ባለቤትነት ወደዚህ አከፋፋይ ተላል hasል።
    /// ማህደረ ትውስታው ነፃ ሊሆን ወይም ላይሆን ይችላል ፣ እናም በዚህ ዘዴ ተመላሽ ዋጋ እንደገና ወደ ደዋዩ ካልተላለፈ በስተቀር ጥቅም ላይ የማይውል ተደርጎ ሊወሰድ ይገባል።
    ///
    /// ይህ ዘዴ `Err` ን ከተመለሰ ታዲያ የማስታወሻ ማገጃው ባለቤትነት ወደዚህ አከፋፋይ አልተላለፈም ፣ እና የማስታወሻ ማገጃው ይዘት አልተለወጠም።
    ///
    /// # Safety
    ///
    /// * `ptr` በዚህ አከፋፋይ በኩል የማስታወሻ [*currently allocated*] ን ማመልከት አለበት።
    /// * `old_layout` ይህ [*fit*] ያለበት የማስታወሻ ማገጃ (የ `new_layout` ክርክር እሱን መግጠም አያስፈልገውም።)።
    /// * `new_layout.size()` ያነሰ መሆን ወይም `old_layout.size()` ጋር እኩል መሆን አለባቸው.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// አዲሱ አቀማመጥ የአከፋፋዩን የመጠን እና የማጣጣም ገደቦችን የማያሟላ ከሆነ ወይም ደግሞ መቀነስ ከቀነሰ `Err` ን ይመልሳል።
    ///
    /// ትግበራዎች ከመደናገጥ ወይም ፅንስ ከማስወረድ ይልቅ በማስታወስ ድካም ላይ `Err` ን እንዲመልሱ ይበረታታሉ ፣ ግን ይህ ጥብቅ መስፈርት አይደለም ፡፡
    /// (በተለይም በማስታወስ ድካሙ ላይ የሚወርደውን በመሰረታዊ የቤት ድልድል ቤተ-መጽሐፍት ላይ ይህን trait ተግባራዊ ማድረግ *ህጋዊ* ነው) ፡፡
    ///
    /// ከምደባ ስህተት ጋር ተያይዞ ስሌትን ለማስቀረት የሚፈልጉ ደንበኞች በቀጥታ `panic!` ወይም ተመሳሳይ ከመጠየቅ ይልቅ የ [`handle_alloc_error`] ተግባርን እንዲጠሩ ይበረታታሉ ፡፡
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() <= old_layout.size(),
            "`new_layout.size()` must be smaller than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // ደህንነት-ምክንያቱም `new_layout.size()` ከ ወይም በታች መሆን አለበት
        // `old_layout.size()`, የድሮው እና አዲሱ የማስታወሻ ምደባ ለንባብ እና ለ `new_layout.size()` ባይት ይጽፋል ፡፡
        // እንዲሁም ፣ የድሮው ምደባ ገና አልተከፋፈለም ፣ `new_ptr` ን መደራረብ አይችልም።
        // ስለዚህ ወደ `copy_nonoverlapping` የሚደረገው ጥሪ ደህንነቱ የተጠበቀ ነው።
        // ለ‹`dealloc` X›የደኅንነት ውል በተጠሪው መደገፍ አለበት ፡፡
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), new_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// ለዚህ የ `Allocator` ምሳሌ የ "by reference" አስማሚ ይፈጥራል።
    ///
    /// የተመለሰው አስማሚ ደግሞ `Allocator` ን ይተገብራል እናም በቀላሉ ይህንን ይበደር።
    #[inline(always)]
    fn by_ref(&self) -> &Self
    where
        Self: Sized,
    {
        self
    }
}

#[unstable(feature = "allocator_api", issue = "32838")]
unsafe impl<A> Allocator for &A
where
    A: Allocator + ?Sized,
{
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate(layout)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate_zeroed(layout)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        // ደህንነት-የደህንነቱ ውል በደዋዩ መከበር አለበት
        unsafe { (**self).deallocate(ptr, layout) }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // ደህንነት-የደህንነቱ ውል በደዋዩ መከበር አለበት
        unsafe { (**self).grow(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // ደህንነት-የደህንነቱ ውል በደዋዩ መከበር አለበት
        unsafe { (**self).grow_zeroed(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // ደህንነት-የደህንነቱ ውል በደዋዩ መከበር አለበት
        unsafe { (**self).shrink(ptr, old_layout, new_layout) }
    }
}