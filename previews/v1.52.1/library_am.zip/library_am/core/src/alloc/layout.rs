use crate::cmp;
use crate::fmt;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ptr::NonNull;

// ይህ ተግባር በአንድ ቦታ ጥቅም ላይ የሚውል ሲሆን አፈፃፀሙም በዝርዝር ሊገለጽ ቢችልም ቀደም ሲል የተደረጉት ሙከራዎች rustc ን ቀርፋፋ አድርገውታል ፡፡
//
//
// * https://github.com/rust-lang/rust/pull/72189
// * https://github.com/rust-lang/rust/pull/79827
//
const fn size_align<T>() -> (usize, usize) {
    (mem::size_of::<T>(), mem::align_of::<T>())
}

/// የማስታወሻ ማገጃ አቀማመጥ።
///
/// `Layout` አንድ ለምሳሌ ትውስታ አንድ የተወሰነ አቀማመጥ ይገልጻል.
/// አንድ allocator ወደ ለመስጠት አንድ ግብዓት እንደ `Layout` የሚያንጽ.
///
/// ሁሉም አቀማመጦች ተጓዳኝ መጠን እና የሁለት-ኃይል አሰላለፍ አላቸው።
///
/// (ምንም እንኳን `GlobalAlloc` ሁሉም የማስታወሻ ጥያቄዎች በመጠን ዜሮ ያልሆኑ እንዲሆኑ ቢያስፈልግም አቀማመጦች ዜሮ ያልሆኑ መጠን እንዲኖራቸው * እንዳልፈለጉ ልብ ይበሉ ፡፡
/// አንድ የደዋይ ወይ እንዲህ ያለ ሁኔታ ከተሸናፊ መስፈርቶች ጋር, አጠቃቀም ተኮር allocators መሟላታቸውን ለማረጋገጥ, ወይም እያላላ `Allocator` በይነገፅ መጠቀም አለበት.)
///
///
///
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[lang = "alloc_layout"]
pub struct Layout {
    // በባይቶች የሚለካው የተጠየቀው የማስታወሻ መጠን።
    size_: usize,

    // በባይቶች የሚለካው የተጠየቀውን የማስታወሻ ማገጃ አሰላለፍ።
    // እንደ ኤፒአይ ያሉ እንደ `posix_memalign` የሚጠይቁት እና በአቀማመጥ ገንቢዎች ላይ መጫን ምክንያታዊ እገዳ ስለሆነ ይህ ሁል ጊዜ የሁለት-ኃይል መሆኑን እናረጋግጣለን።
    //
    //
    // (ሆኖም ፣ እኛ በተመሳሳይ መልኩ `አሰላለፍ>= sizeof(void *)`, even though that is* also* a requirement of `posix_memalign`.)) አንፈልግም
    //
    //
    align_: NonZeroUsize,
}

impl Layout {
    /// ከሚከተሉት ሁኔታዎች ማንኛቸውም ተገናኘን አይደለም ከሆነ አንድ `Layout` በተወሰነ `size` እና `align`, ወይም ይመለሳል `LayoutError` ከ Constructs:
    ///
    /// * `align` ዜሮ መሆን አለበት,
    ///
    /// * `align` ከሁለት የሆነ ኃይል መሆን አለበት,
    ///
    /// * `size`, `align` መካከል ቅርብ በርካታ እስከ የተጠጋጋ ጊዜ, ፍሰት (ማለትም, የተጠጋጋ ዋጋ ያነሰ `usize::MAX` እኩል ወይም በላይ መሆን አለበት) የለበትም.
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn from_size_align(size: usize, align: usize) -> Result<Self, LayoutError> {
        if !align.is_power_of_two() {
            return Err(LayoutError { private: () });
        }

        // (ኃይል-መካከል-ሁለት align አንድምታ!=0.)

        // ክበባዊ እስከ መጠን ነው:
        //   size_rounded_up=(መጠን + አሰላለፍ, 1) እና (አሰላለፍ, 1)!;
        //
        // ያንን አሰላለፍ ከላይ እናውቃለን!=0.
        // (አሰልፍ, 1) በማከል ከሆነ ፍሰት, ከዚያም ጥሩ ይሆናል እስከ በማጠጋጋት አይደለም.
        //
        // በተቃራኒው ፣ እና-መመረጥ! (አሰልፍ ፣ 1) ዝቅተኛ የትእዛዝ-ቢቶችን ብቻ ይቀነሳል።
        // ስለሆነም በድምሩ ከመጠን በላይ ፍሰት ከተከሰተ የ&-mask ያንን ፍሰት ለመቀልበስ በቂ መቀነስ አይችልም።
        //
        //
        // ከዚህ በላይ ማጠቃለያ ከመጠን በላይ መሞከሩ አስፈላጊ እና በቂ ነው ፡፡
        //
        if size > usize::MAX - (align - 1) {
            return Err(LayoutError { private: () });
        }

        // ደህንነት-የ `from_size_align_unchecked` ቅድመ ሁኔታዎች ነበሩ
        // ከላይ ምልክት ተደርጎበታል ፡፡
        unsafe { Ok(Layout::from_size_align_unchecked(size, align)) }
    }

    /// ሁሉንም ቼኮች በማለፍ አቀማመጥን ይፈጥራል።
    ///
    /// # Safety
    ///
    /// ከ [`Layout::from_size_align`] ቅድመ ሁኔታዎችን ስለማያረጋግጥ ይህ ተግባር ደህንነቱ የተጠበቀ ነው።
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub const unsafe fn from_size_align_unchecked(size: usize, align: usize) -> Self {
        // ደህንነት-ደዋዩ `align` ከዜሮ በላይ መሆኑን ማረጋገጥ አለበት ፡፡
        Layout { size_: size, align_: unsafe { NonZeroUsize::new_unchecked(align) } }
    }

    /// ይህን አቀማመጥ አንድ ትውስታ የማገጃ ለ ባይቶች ውስጥ አነስተኛውን መጠን.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn size(&self) -> usize {
        self.size_
    }

    /// ይህን አቀማመጥ አንድ ትውስታ የማገጃ የሚሆን ዝቅተኛውን ባይት አሰላለፍ.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn align(&self) -> usize {
        self.align_.get()
    }

    /// የ `T` ዓይነት እሴት ለመያዝ ተስማሚ የሆነ `Layout` ን ይገነባል።
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout_const_new", since = "1.42.0")]
    #[inline]
    pub const fn new<T>() -> Self {
        let (size, align) = size_align::<T>();
        // ደህንነት-አሰላለፉ የሁለት እና የሁለት ኃይል እንዲሆን በ Rust የተረጋገጠ ነው
        // መጠኑ + አሰላለፍ ጥምር በአድራሻችን ቦታ ላይ እንደሚስማማ የተረጋገጠ ነው።
        // በዚህ ምክንያት በደንብ ካልተስተካከለ ያንን panics ኮድ ለማስገባት ያልተፈተሸውን ገንቢ እዚህ ይጠቀሙ ፡፡
        //
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// ለ‹`T` X›የመጠባበቂያ መዋቅር ለመመደብ ሊያገለግል የሚችል መዝገብ የሚገልጽ አቀማመጥን ያወጣል (ይህም እንደ trait ወይም እንደ ቁራጭ ያለ ሌላ ያልተመዘገበ ዓይነት ሊሆን ይችላል) ፡፡
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub fn for_value<T: ?Sized>(t: &T) -> Self {
        let (size, align) = (mem::size_of_val(t), mem::align_of_val(t));
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // ደህንነት-ይህ ደህንነቱ ያልተጠበቀ ልዩነትን ለምን እንደሚጠቀምበት በ `new` ውስጥ ምክንያታዊውን ይመልከቱ
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// ለ‹`T` X›የመጠባበቂያ መዋቅር ለመመደብ ሊያገለግል የሚችል መዝገብ የሚገልጽ አቀማመጥን ያወጣል (ይህም እንደ trait ወይም እንደ ቁራጭ ያለ ሌላ ያልተመዘገበ ዓይነት ሊሆን ይችላል) ፡፡
    ///
    /// # Safety
    ///
    /// የሚከተሉት ሁኔታዎች መያዝ ከሆነ ይህ ተግባር ጥሪ ብቻ ደህና ነው:
    ///
    /// - `T` `Sized` ከሆነ ይህ ተግባር ለመደወል ሁልጊዜ ደህና ነው።
    /// - የ `T` ያልተለካው ጅራት ከሆነ:
    ///     - አንድ [slice] ፣ ከዚያ የተቆራረጠ የጅራቱ ርዝመት ውስጠ-ህዋስ (ኢንቲጀር) መሆን አለበት ፣ እና የ *አጠቃላይ እሴቱ* መጠን (ተለዋዋጭ ጅራት ርዝመት + ስታትስቲክስ መጠን ያለው ቅድመ ቅጥያ) በ `isize` ውስጥ መመጣጠን አለበት።
    ///     - አንድ [trait object] ፣ ከዚያ የጠቋሚው ተቆጣጣሪ ክፍል በማያስችል ማስገደድ ለተገኘው የ `T` ዓይነት ትክክለኛ የሆነ አመላካች መጠቆም አለበት ፣ እና የ *አጠቃላይ እሴቱ* መጠን (ተለዋዋጭ ጅራት ርዝመት + በቁጥር መጠን ያለው ቅድመ ቅጥያ) በ `isize` ውስጥ መቀመጥ አለበት።
    ///
    ///     - አንድ (unstable) [extern type] ፣ ከዚያ ይህ ተግባር ሁል ጊዜ ለመጥራት ደህና ነው ፣ ግን የውጪው ዓይነት አቀማመጥ ስለማይታወቅ panic ወይም አለበለዚያ የተሳሳተ ዋጋን ይመልስ።
    ///     ወደ ውጫዊ ዓይነት ጅራት በማጣቀሻ ላይ ይህ እንደ [`Layout::for_value`] ተመሳሳይ ባህሪ ነው።
    ///     - አለበለዚያ, ይህ conservatively ይህን ተግባር ለመጥራት አልተፈቀደለትም.
    ///
    /// [trait object]: ../../book/ch17-02-trait-objects.html
    /// [extern type]: ../../unstable-book/language-features/extern-types.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "layout_for_ptr", issue = "69835")]
    pub unsafe fn for_value_raw<T: ?Sized>(t: *const T) -> Self {
        // ደህንነት-የእነዚህን ተግባራት ቅድመ ሁኔታ ለደዋዩ እናስተላልፋለን
        let (size, align) = unsafe { (mem::size_of_val_raw(t), mem::align_of_val_raw(t)) };
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // ደህንነት-ይህ ደህንነቱ ያልተጠበቀ ልዩነትን ለምን እንደሚጠቀምበት በ `new` ውስጥ ምክንያታዊውን ይመልከቱ
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// ለዚህ አቀማመጥ የተንጠለጠለ ግን በጥሩ ሁኔታ የተስተካከለ `NonNull` ን ይፈጥራል።
    ///
    /// የ የጠቋሚ እሴት የሚችሉ አንድ "not yet initialized" ዘብ እሴት ሆኖ ሊያገለግል አይችልም ይህን የግድ ማለት የሚሰራ ጠቋሚ, ሊወክል እንደሚችል ልብ ይበሉ.
    /// ታካቾች ለመመደብ ዘንድ አይነቶች በሌላ መንገድ ማስጀመር መከታተል አለባቸው.
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub const fn dangling(&self) -> NonNull<u8> {
        // ደህንነት-አሰላለፍ ዜሮ ያልሆነ እንዲሆን የተረጋገጠ ነው
        unsafe { NonNull::new_unchecked(self.align() as *mut u8) }
    }

    /// ከ‹XXXXXXXX›ጋር ተመሳሳይ አቀማመጥ ያለው እሴት መያዝ የሚችል መዝገብን የሚገልጽ አቀማመጥን ይፈጥራል ፣ ግን ያ ደግሞ ከ‹`align`›አሰላለፍ ጋር ይመሳሰላል (በባይቶች ይለካል) ፡፡
    ///
    ///
    /// `self` አስቀድሞ በተሰጠህ አሰላለፍ የሚያሟላ ከሆነ, ከዚያም `self` ይመልሳል.
    ///
    /// የተመለሰው አቀማመጥ የተለየ አሰላለፍ ቢኖረውም ይህ ዘዴ በጠቅላላው መጠን ምንም ማጠፊያ እንደማያክል ልብ ይበሉ ፡፡
    /// `K` መጠን 16 እንዳለው ከሆነ በሌላ አነጋገር, `K.align_to(32)`*አሁንም* መጠን 16 ይኖራቸዋል.
    ///
    /// የ `self.size()` እና የተሰጠው `align` ጥምረት በ [`Layout::from_size_align`] ውስጥ የተዘረዘሩትን ሁኔታዎች የሚጥስ ከሆነ ስህተት ይመልሳል።
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn align_to(&self, align: usize) -> Result<Self, LayoutError> {
        Layout::from_size_align(self.size(), cmp::max(self.align(), align))
    }

    /// ይመለሳል (ባይቶች ውስጥ የሚለካው) እኛም በሚከተለው አድራሻ `align` ያረካል መሆኑን ለማረጋገጥ `self` በኋላ ማስገባት አለበት ድብዳብ መጠን.
    ///
    /// `self.size()` 9 ከሆነ በዚያ ድብዳብ መካከል የባይት ዝቅተኛ ቁጥር (አንድ 4-ተሰልፏል አድራሻ ላይ ያለውን ተጓዳኝ ትውስታ የማገጃ ሲጀምር ብለን ካሰብን) የ 4-ተሰልፏል አድራሻ ማግኘት ያስፈልጋል ነው ምክንያቱም ለምሳሌ, ከዚያም `self.padding_needed_for(4)`, 3 ይመልሳል.
    ///
    ///
    /// `align` የኃይል-የሁለት ካልሆነ የዚህ ተግባር ተመላሽ ዋጋ ትርጉም የለውም።
    ///
    /// የተመለሰው እሴት መገልገያ `align` ን ለጠቅላላው ለተመደበው የማስታወሻ ማህደሩ መነሻ አድራሻ አሰላለፍ ያነሰ ወይም እኩል መሆንን እንደሚፈልግ ልብ ይበሉ።ይህንን ገደብ ለማርካት አንዱ መንገድ `align <= self.align()` ን ማረጋገጥ ነው ፡፡
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "const_alloc_layout", issue = "67521")]
    #[inline]
    pub const fn padding_needed_for(&self, align: usize) -> usize {
        let len = self.size();

        // የተጠጋጋ እሴት
        //   len_rounded_up=(len + align, 1)&! (አሰልፍ ፣ 1);
        // ከዚያም እኛ ድብዳብ ልዩነት ይመለሳል: `len_rounded_up - len`.
        //
        // ሞዱል ሂሳብን በአጠቃላይ እንጠቀማለን
        //
        // 1. አሰላለፍ> 0 መሆኑ የተረጋገጠ ነው ፣ ስለሆነም አሰልፍ ፣ 1 ሁልጊዜ የሚሰራ ነው።
        //
        // 2.
        // `len + align - 1` ቢበዛ `align - 1` ሊበዛ ይችላል ፣ ስለሆነም&-mask ከ `!(align - 1)` ጋር ከመጠን በላይ ከሆነ `len_rounded_up` ራሱ 0 እንደሚሆን ያረጋግጣል።
        //
        //    በመሆኑም `len` ታክሏል ጊዜ ተመልሶ ድብዳብ: 0, ይህም ዋጋ ቢስ የሚያጠግብ አሰላለፍ `align` ያፈራላቸዋል.
        //
        // (በእርግጥ ከላይ በተጠቀሰው መንገድ ከመጠን በላይ እና ከመጠን በላይ የመጥለቅለቅ ችሎታ ያላቸው የማስታወሻ ክፍሎችን ለመመደብ የሚደረግ ሙከራ አከፋፋዩ ለማንኛውም ስህተት እንዲሰጥ ሊያደርገው ይችላል ፡፡)
        //
        //
        //
        //

        let len_rounded_up = len.wrapping_add(align).wrapping_sub(1) & !align.wrapping_sub(1);
        len_rounded_up.wrapping_sub(len)
    }

    /// የዚህን አቀማመጥ መጠን እስከ ብዙ የአቀማመጥ አሰላለፍ ድረስ በመደርደር አቀማመጥን ይፈጥራል።
    ///
    ///
    /// ይህ የ `padding_needed_for` ን ውጤት በአቀማመጥ የአሁኑ መጠን ላይ ከመደመር ጋር እኩል ነው።
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn pad_to_align(&self) -> Layout {
        let pad = self.padding_needed_for(self.align());
        // ይህ ሊጥለቀለቅ አይችልም።ከአቀማመጥ የማይለዋወጥን በመጥቀስ-
        // > `size`, ጊዜ, `align` መካከል ቅርብ በርካታ እስከ የተጠጋጋ
        // > መትፋት የለበትም (ማለትም ፣ የተጠጋጋው እሴት ከዚህ በታች መሆን አለበት)
        // > `usize::MAX`)
        let new_size = self.size() + pad;

        Layout::from_size_align(new_size, self.align()).unwrap()
    }

    /// እያንዳንዱ ምሳሌ የተጠየቀውን መጠን እና አሰላለፍ መሰጠቱን ለማረጋገጥ በእያንዳንዳቸው መካከል ተስማሚ መጠን ያለው መቅዘፊያ ለ‹XXXX›ክስተቶች መዝገብ የሚገልጽ አቀማመጥን ይፈጥራል ፡፡
    /// በስኬት ላይ X0 `(k, offs)` ን ይመልሳል `k` የድርድር አቀማመጥ ሲሆን `offs` ደግሞ በድርድሩ ውስጥ ባለው እያንዳንዱ ንጥረ ነገር ጅምር መካከል ያለው ርቀት ነው።
    ///
    /// በሂሳብ ብዛት (ፍሰት) ላይ ፣ `LayoutError` ን ይመልሳል።
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat(&self, n: usize) -> Result<(Self, usize), LayoutError> {
        // ይህ ሊጥለቀለቅ አይችልም።ከአቀማመጥ የማይለዋወጥን በመጥቀስ-
        // > `size`, ጊዜ, `align` መካከል ቅርብ በርካታ እስከ የተጠጋጋ
        // > መትፋት የለበትም (ማለትም ፣ የተጠጋጋው እሴት ከዚህ በታች መሆን አለበት)
        // > `usize::MAX`)
        let padded_size = self.size() + self.padding_needed_for(self.align());
        let alloc_size = padded_size.checked_mul(n).ok_or(LayoutError { private: () })?;

        // ደህንነት self.align ቀድሞውኑ ዋጋ ያለው እንደሆነ እና የምደባ_ሲዝ መጠን እንደነበረ ታውቋል
        // ቀድሞ የታሸገ ፡፡
        unsafe { Ok((Layout::from_size_align_unchecked(alloc_size, self.align()), padded_size)) }
    }

    /// `self` መዝገብ የሚገልጽ አቀማመጥ `next` በአግባቡ የሚጣጣም ይሆናል መሆኑን ለማረጋገጥ ማንኛውም አስፈላጊ ድብዳብ ጨምሮ, `next` ተከትሎ ይፈጥራል, ነገር ግን *ምንም ትሬሊንግ ድብዳብ*.
    ///
    /// ከ C ውክልና አቀማመጥ `repr(C)` ጋር ለማዛመድ አቀማመጡን ከሁሉም መስኮች ጋር ካራዘሙ በኋላ ወደ `pad_to_align` መደወል ይኖርብዎታል።
    /// (ነባሪውን Rust ውክልና አቀማመጥ `repr(Rust)`, as it is unspecified.)) ለማዛመድ ምንም መንገድ የለም
    ///
    /// የ የሚያስከትለውን አቀማመጥ አሰላለፍ ሁለቱም ክፍሎች አሰላለፍ ለማረጋገጥ, `self` እና `next` ሰዎች መካከል ከፍተኛውን ይሆናል መሆኑን ልብ ይበሉ.
    ///
    /// X0 `Ok((k, offset))` ይመለሳል ፣ `k` የተጠናቀረው መዝገብ አቀማመጥ ሲሆን `offset` ደግሞ በተጣመረ መዝገብ ውስጥ የተካተተው የ `next` ጅምር መነሻ ፣ አንፃራዊ ሥፍራ ሲሆን ፣ መዝገቡ ራሱ ከ 0 ጋር ሲነፃፀር ይጀምራል)።
    ///
    ///
    /// በሂሳብ ብዛት (ፍሰት) ላይ ፣ `LayoutError` ን ይመልሳል።
    ///
    /// # Examples
    ///
    /// አንድ `#[repr(C)]` መዋቅር ያለውን አቀማመጥ እና መስኮች 'አቀማመጦችን ከ መስኮች መካከል ማካካሻዎች ማስላት:
    ///
    /// ```rust
    /// # use std::alloc::{Layout, LayoutError};
    /// pub fn repr_c(fields: &[Layout]) -> Result<(Layout, Vec<usize>), LayoutError> {
    ///     let mut offsets = Vec::new();
    ///     let mut layout = Layout::from_size_align(0, 1)?;
    ///     for &field in fields {
    ///         let (new_layout, offset) = layout.extend(field)?;
    ///         layout = new_layout;
    ///         offsets.push(offset);
    ///     }
    ///     // በ `pad_to_align` ለማጠናቀቅ ያስታውሱ!
    ///     Ok((layout.pad_to_align(), offsets))
    /// }
    /// # // እንደሚሰራ ሞክር
    /// # #[repr(C)] struct S { a: u64, b: u32, c: u16, d: u32 }
    /// # let s = Layout::new::<S>();
    /// # let u16 = Layout::new::<u16>();
    /// # let u32 = Layout::new::<u32>();
    /// # let u64 = Layout::new::<u64>();
    /// # assert_eq!(repr_c(&[u64, u32, u16, u32]), Ok((s, vec![0, 8, 12, 16])));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn extend(&self, next: Self) -> Result<(Self, usize), LayoutError> {
        let new_align = cmp::max(self.align(), next.align());
        let pad = self.padding_needed_for(next.align());

        let offset = self.size().checked_add(pad).ok_or(LayoutError { private: () })?;
        let new_size = offset.checked_add(next.size()).ok_or(LayoutError { private: () })?;

        let layout = Layout::from_size_align(new_size, new_align)?;
        Ok((layout, offset))
    }

    /// በእያንዳንዱ ምሳሌ መካከል ምንም ንጣፍ ሳይኖር ለ `self` ክስተቶች የ `n` ክስተቶች መዝገብን የሚገልጽ አቀማመጥን ይፈጥራል።
    ///
    /// ልብ ይበሉ ፣ ከ `repeat` በተለየ ፣ `repeat_packed` ምንም እንኳን የተሰጠው የ `self` ምሳሌ በትክክል ቢዛመድም የ `self` ተደጋጋሚ ሁኔታዎች በትክክል እንደሚዛመዱ ዋስትና አይሰጥም ፡፡
    /// በሌላ አገላለጽ በ `repeat_packed` የተመለሰው አቀማመጥ አንድ ድርድር ለመመደብ የሚያገለግል ከሆነ በድርድሩ ውስጥ ያሉት ሁሉም አካላት በትክክል መጣጣማቸው ዋስትና የለውም።
    ///
    /// በሂሳብ ብዛት (ፍሰት) ላይ ፣ `LayoutError` ን ይመልሳል።
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat_packed(&self, n: usize) -> Result<Self, LayoutError> {
        let size = self.size().checked_mul(n).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(size, self.align())
    }

    /// በሁለቱ መካከል ምንም ተጨማሪ ንጣፍ የሌለበት የ `self` ን ተከትሎ የ `self` ን መዝገብ የሚገልጽ አቀማመጥን ይፈጥራል።
    /// ምንም ማጠፊያ ስላልገባ ፣ የ `next` አሰላለፍ አግባብነት የለውም ፣ እና በሚመጣው አቀማመጥ ውስጥ *በጭራሽ* አልተካተተም።
    ///
    ///
    /// በሂሳብ ብዛት (ፍሰት) ላይ ፣ `LayoutError` ን ይመልሳል።
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn extend_packed(&self, next: Self) -> Result<Self, LayoutError> {
        let new_size = self.size().checked_add(next.size()).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(new_size, self.align())
    }

    /// ለ `[T; n]` መዝገብን የሚገልጽ አቀማመጥን ይፈጥራል።
    ///
    /// በሂሳብ ብዛት (ፍሰት) ላይ ፣ `LayoutError` ን ይመልሳል።
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn array<T>(n: usize) -> Result<Self, LayoutError> {
        let (layout, offset) = Layout::new::<T>().repeat(n)?;
        debug_assert_eq!(offset, mem::size_of::<T>());
        Ok(layout.pad_to_align())
    }
}

#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
pub type LayoutErr = LayoutError;

/// `Layout::from_size_align` ወይም በሰነድ ገደቦችን አያከብሩም አንዳንድ ሌሎች `Layout` ግንበኛ የተሰጠውን ግቤቶች.
///
///
#[stable(feature = "alloc_layout_error", since = "1.50.0")]
#[derive(Clone, PartialEq, Eq, Debug)]
pub struct LayoutError {
    private: (),
}

// (እኛ trait ስህተት ውስጥ ተፋሰስ impl ይህን ያስፈልጋቸዋል)
#[stable(feature = "alloc_layout", since = "1.28.0")]
impl fmt::Display for LayoutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("invalid parameters to Layout::from_size_align")
    }
}