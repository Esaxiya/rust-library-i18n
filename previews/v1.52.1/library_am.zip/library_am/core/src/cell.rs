//! ሊጋራ የሚችል ተለዋዋጭ መያዣዎች።
//!
//! የ Rust ማህደረ ትውስታ ደህንነት በዚህ ደንብ ላይ የተመሠረተ ነው-`T` ን ከተመለከተ ከሚከተሉት ውስጥ አንዱን ብቻ ማግኘት ይቻላል ፡፡
//!
//! - በነገሩ በርካታ በማይለወጥ ማጣቀሻዎች (`&T`) መኖሩ (በተጨማሪ **aliasing** በመባል ይታወቃል).
//! - ወደ ነገሩ አንድ ተለዋጭ ማጣቀሻ (`&mut T`) ያለው (‹**mutability** በመባልም ይታወቃል›) ፡፡
//!
//! ይህ በ Rust አጠናቃሪ ይተገበራል።ሆኖም ፣ ይህ ደንብ በቂ ተጣጣፊ የማይሆንባቸው ሁኔታዎች አሉ።አንዳንድ ጊዜ አንድ ነገር ለማድረግ በርካታ ማጣቀሻዎችም አሏቸው እና ገና ትጀምሩ ያስፈልጋል.
//!
//! ሊጋሩ ሊቀየሩ ኮንቴይነሮች እንኳ aliasing ፊት አንድ ቁጥጥር መልኩ ፈቃድ mutability ወደ የለም.ሁለቱም [`Cell<T>`] እና [`RefCell<T>`] ይህንን በነጠላ ክር መንገድ ለማድረግ ይፈቅዳሉ ፡፡
//! ይሁን እንጂ `Cell<T>` ሆነ `RefCell<T>` ቢሆን (እነርሱ [`Sync`] በስራ አይደለም) ክር የተጠበቀ ነው.
//! በበርካታ ክሮች መካከል ተለጣፊ እና ሚውቴሽን ማድረግ ከፈለጉ [`Mutex<T>`] ፣ [`RwLock<T>`] ወይም [`atomic`] ዓይነቶችን መጠቀም ይቻላል ፡፡
//!
//! የ `Cell<T>` እና `RefCell<T>` አይነቶች እሴቶች የተጋሩ ማጣቀሻዎች በኩል mutated ሊሆን ይችላል (ማለትም
//! የተለመደው የ `&T` ዓይነት) ፣ ግን አብዛኛዎቹ የ Rust ዓይነቶች በልዩ (`&mut T`) ማጣቀሻዎች ብቻ ሊለወጡ ይችላሉ።
//! እኛ `Cell<T>` እና `RefCell<T>` የተለመደ Rust አይነቶች መሆኑን ኤግዚቢሽን 'ከወረሱት mutability' ጋር በማነጻጸር, 'የውስጥ mutability' ማቅረብ እንደሆነ ይናገራሉ.
//!
//! `Cell<T>` እና `RefCell<T>`: የሕዋስ አይነቶች ሁለት ጣዕም ውስጥ ይመጣሉ.ውስጥ እና `Cell<T>` ውጭ እሴቶች በመውሰድ `Cell<T>` መሳሪያዎች የውስጥ mutability.
//! ከእሴቶች ይልቅ ማጣቀሻዎችን ለመጠቀም አንድ ሰው‹M01X›ን ከመጠቀምዎ በፊት የጽሑፍ ቁልፍን ማግኘት አለበት ፡፡`Cell<T>` ሰርስሮ እና የአሁኑን የውስጥ ዋጋ ለመለወጥ ዘዴዎች ያቀርባል:
//!
//!  - [`Copy`] ን ለሚተገብሩ ዓይነቶች የ [`get`](Cell::get) ዘዴ የአሁኑን ውስጣዊ እሴት ያወጣል ፡፡
//!  - [`Default`] ን ለሚተገብሩ ዓይነቶች የ [`take`](Cell::take) ዘዴ የአሁኑን ውስጣዊ እሴት በ [`Default::default()`] ይተካዋል እና የተተካውን እሴት ይመልሳል።
//!  - ለሁሉም ዓይነቶች የ‹XXXX›ዘዴ የአሁኑን ውስጣዊ እሴት በመተካት የተተካውን እሴት ይመልሳል እና የ [`into_inner`](Cell::into_inner) ዘዴ `Cell<T>` ን ይወስዳል እና የውስጥ እሴቱን ይመልሳል ፡፡
//!  በተጨማሪም ፣ የ‹XXXXXXXXXXXXX›ዘዴ ተተኪውን እሴት በመተው ውስጣዊ እሴቱን ይተካል።
//!
//! `RefCell<T>` ‹ተለዋዋጭ ብድር›ን ለመተግበር የ Rust ን የሕይወት ዘመንን ይጠቀማል ፣ አንድ ሰው ጊዜያዊ ፣ ልዩ ፣ ተለዋጭ እና ለውስጣዊ እሴቱን ማግኘት የሚችልበት ሂደት ነው ፡፡
//! ቦርሶች ለ `RefCell`<T>ከ Rust ተወላጅ የማጣቀሻ አይነቶች በተለየ `በተጠናቀቁበት ጊዜ` ክትትል ይደረግባቸዋል ፣ በሚጠናቀረው ጊዜ።
//! የ `RefCell<T>` ብድሮች ተለዋዋጭ ስለሆኑ ቀድሞውኑ በሚበዛ ሁኔታ የተበደረውን እሴት ለመበደር መሞከር ይቻላል ፤ይህ በሚሆንበት ጊዜ panic ን ያስገኛል ፡፡
//!
//! # የውስጥ ለውጥን መቼ እንደሚመርጡ
//!
//! አንድ እሴት ትጀምሩ ዘንድ ልዩ መዳረሻ ሊኖረው ይገባል የት ይበልጥ የተለመደ የወረሱት mutability, በማይለወጥ የብልሽት ሳንካዎች በመከላከል, የጠቋሚ aliasing ስለ አጥብቆ ምክንያት ወደ Rust የሚያስችል ቁልፍ ቋንቋ ንጥረ ነገሮች መካከል አንዱ ነው.
//! በዚህ ምክንያት ፣ በዘር የሚተላለፍ ተለዋጭነት ተመራጭ ነው ፣ እና የውስጣዊ ሁኔታ መለዋወጥ የመጨረሻ አማራጭ ነገር ነው።
//! የሕዋስ ዓይነቶች ሚውቴሽን በሌላ መልኩ እንዲፈቀድ በሚከለከልበት ጊዜ የሚያነቃ በመሆኑ ፣ ውስጣዊ ለውጡን መለዋወጥ ተገቢ ሊሆንባቸው የሚችሉባቸው አጋጣሚዎች አሉ ፣ ወይም * ** እንኳን ጥቅም ላይ መዋል አለባቸው ፣ ለምሳሌ
//!
//! * ነገር በማይለወጥ መካከል በማስተዋወቅ mutability 'inside'
//! * የአመክንዮ-የማይለዋወጥ ዘዴዎች የትግበራ ዝርዝሮች ፡፡
//! * የ [`Clone`] ትግበራዎችን መለወጥ
//!
//! ## ነገር በማይለወጥ መካከል በማስተዋወቅ mutability 'inside'
//!
//! [`Rc<T>`] እና [`Arc<T>`] ን ጨምሮ ብዙ የተጋሩ ዘመናዊ የጠቋሚ ጠቋሚ ዓይነቶች በበርካታ ወገኖች መካከል ሊበዙ እና ሊጋሩ የሚችሉ መያዣዎችን ይሰጣሉ ፡፡
//! የ ይዞ እሴቶች ስለሚቀር-ተገናኝቷል ስለዚህም ሊሆን ይችላል ምክንያቱም እነርሱ ብቻ `&` ሳይሆን `&mut` ጋር በውሰት ይቻላል.
//! ሕዋሳት ያለ ሁሉ እነዚህ ዘመናዊ ዘዴውን መካከል ትጀምሩ ውሂብ በውስጥ የማይቻል ይሆናል.
//!
//! ይህ ሳይሳኩ mutability ጋር የተጋራ ጠቋሚ አይነቶች ውስጥ አንድ `RefCell<T>` ለማስቀመጥ ከዚያም በጣም የተለመደ ነው:
//!
//! ```
//! use std::cell::{RefCell, RefMut};
//! use std::collections::HashMap;
//! use std::rc::Rc;
//!
//! fn main() {
//!     let shared_map: Rc<RefCell<_>> = Rc::new(RefCell::new(HashMap::new()));
//!     // ተለዋዋጭ ብድርን ወሰን ለመገደብ አዲስ ማገጃ ይፍጠሩ
//!     {
//!         let mut map: RefMut<_> = shared_map.borrow_mut();
//!         map.insert("africa", 92388);
//!         map.insert("kyoto", 11837);
//!         map.insert("piccadilly", 11826);
//!         map.insert("marbles", 38);
//!     }
//!
//!     // የቀደመውን የመሸጎጫ ብድር ከአቅጣጫው እንዲወድቅ ባንፈቅድ ኖሮ ከዚያ የሚቀጥለው ብድር ተለዋዋጭ ክር panic ን ያስከትላል ፡፡
//!     //
//!     // `RefCell` ን የመጠቀም ዋነኛው አደጋ ይህ ነው ፡፡
//!     let total: i32 = shared_map.borrow().values().sum();
//!     println!("{}", total);
//! }
//! ```
//!
//! ይህ ምሳሌ `Rc<T>` ን እና `Arc<T>` ን እንደማይጠቀም ልብ ይበሉ ፡፡`RefCell`<T>s ነጠላ-ክር ክርክር ሁኔታዎች ናቸው ፡፡እርስዎ ባለብዙ ተከታታይ ሁኔታ ውስጥ mutability የተጋሩ ከፈለጉ [`RwLock<T>`] ወይም [`Mutex<T>`] በመጠቀም ያስቡበት.
//!
//! ## ምክንያታቸው-በማይለወጥ ዘዴዎች ትግበራ ዝርዝሮች
//!
//! አልፎ አልፎ በኤክስ.አይ.ፒ. ውስጥ "under the hood" እየተከሰተ ሚውቴሽን አለማጋለጡ ይፈለግ ይሆናል ፡፡
//! ይህ ምናልባት ምክንያታዊ በሆነ መልኩ ክዋኔው የማይለዋወጥ ስለሆነ ሊሆን ይችላል ፣ ግን ለምሳሌ ፣ መሸጎጥ አፈፃፀሙ ሚውቴሽን እንዲያከናውን ያስገድደዋል ፤ወይም `&self` ን ለመውሰድ በመጀመሪያ የተገለጸውን የ trait ዘዴን ለመተግበር ሚውቴሽን መጠቀም አለብዎት ፡፡
//!
//!
//! ```
//! # #![allow(dead_code)]
//! use std::cell::RefCell;
//!
//! struct Graph {
//!     edges: Vec<(i32, i32)>,
//!     span_tree_cache: RefCell<Option<Vec<(i32, i32)>>>
//! }
//!
//! impl Graph {
//!     fn minimum_spanning_tree(&self) -> Vec<(i32, i32)> {
//!         self.span_tree_cache.borrow_mut()
//!             .get_or_insert_with(|| self.calc_span_tree())
//!             .clone()
//!     }
//!
//!     fn calc_span_tree(&self) -> Vec<(i32, i32)> {
//!         // ውድ ስሌት እዚህ ይሄዳል
//!         vec![]
//!     }
//! }
//! ```
//!
//! ## የ `Clone` ትግበራዎችን መለወጥ
//!
//! በማይለወጥ የሚመስሉ ክወናዎች መደበቅ mutability: ይህ በቀላሉ አንድ ልዩ ነገር ግን የተለመደ, ቀዳሚው ጉዳይ ነው.
//! የ [`clone`](Clone::clone) ዘዴ የምንጭ ዋጋውን እንደማይለውጠው ይጠበቃል ፣ እና `&mut self` ን ሳይሆን `&self` ን እንደሚወስድ ታወጀ ፡፡
//! ስለዚህ, `clone` ስልት ውስጥ ለሚከሰቱ ማንኛውም የሚውቴሽን ሕዋስ አይነቶች መጠቀም አለበት.
//! ለምሳሌ ፣ [`Rc<T>`] በ `Cell<T>` ውስጥ የማጣቀሻ ቁጥሮቹን ይይዛል።
//!
//! ```
//! use std::cell::Cell;
//! use std::ptr::NonNull;
//! use std::process::abort;
//! use std::marker::PhantomData;
//!
//! struct Rc<T: ?Sized> {
//!     ptr: NonNull<RcBox<T>>,
//!     phantom: PhantomData<RcBox<T>>,
//! }
//!
//! struct RcBox<T: ?Sized> {
//!     strong: Cell<usize>,
//!     refcount: Cell<usize>,
//!     value: T,
//! }
//!
//! impl<T: ?Sized> Clone for Rc<T> {
//!     fn clone(&self) -> Rc<T> {
//!         self.inc_strong();
//!         Rc {
//!             ptr: self.ptr,
//!             phantom: PhantomData,
//!         }
//!     }
//! }
//!
//! trait RcBoxPtr<T: ?Sized> {
//!
//!     fn inner(&self) -> &RcBox<T>;
//!
//!     fn strong(&self) -> usize {
//!         self.inner().strong.get()
//!     }
//!
//!     fn inc_strong(&self) {
//!         self.inner()
//!             .strong
//!             .set(self.strong()
//!                      .checked_add(1)
//!                      .unwrap_or_else(|| abort() ));
//!     }
//! }
//!
//! impl<T: ?Sized> RcBoxPtr<T> for Rc<T> {
//!    fn inner(&self) -> &RcBox<T> {
//!        unsafe {
//!            self.ptr.as_ref()
//!        }
//!    }
//! }
//! ```
//!
//! [`Arc<T>`]: ../../std/sync/struct.Arc.html
//! [`Rc<T>`]: ../../std/rc/struct.Rc.html
//! [`RwLock<T>`]: ../../std/sync/struct.RwLock.html
//! [`Mutex<T>`]: ../../std/sync/struct.Mutex.html
//! [`atomic`]: ../../core/sync/atomic/index.html
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering;
use crate::fmt::{self, Debug, Display};
use crate::marker::Unsize;
use crate::mem;
use crate::ops::{CoerceUnsized, Deref, DerefMut};
use crate::ptr;

/// ሊለወጥ የሚችል የማስታወሻ ቦታ።
///
/// # Examples
///
/// በዚህ ምሳሌ ውስጥ, እናንተ `Cell<T>` አንድ በማይለወጥ struct ውስጥ የሚውቴሽን ያስችላል መሆኑን ማየት እንችላለን.
/// በሌላ አነጋገር, ይህ "interior mutability" ያስችላል.
///
/// ```
/// use std::cell::Cell;
///
/// struct SomeStruct {
///     regular_field: u8,
///     special_field: Cell<u8>,
/// }
///
/// let my_struct = SomeStruct {
///     regular_field: 0,
///     special_field: Cell::new(1),
/// };
///
/// let new_value = 100;
///
/// // ስህተት: `my_struct` መዋቲ ነው
/// // my_struct.regular_field =አዲስ_ዋጋ;
///
/// // ስራዎች-ምንም እንኳን `my_struct` የማይለወጥ ቢሆንም `special_field` `Cell` ነው ፣
/// // ሁልጊዜ ሊለወጥ ይችላል
/// my_struct.special_field.set(new_value);
/// assert_eq!(my_struct.special_field.get(), new_value);
/// ```
///
/// ለተጨማሪ [module-level documentation](self) ን ይመልከቱ።
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
pub struct Cell<T: ?Sized> {
    value: UnsafeCell<T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for Cell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for Cell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Copy> Clone for Cell<T> {
    #[inline]
    fn clone(&self) -> Cell<T> {
        Cell::new(self.get())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Cell<T> {
    /// አንድ `Cell<T>` ቲ ለ `Default` ዋጋ ጋር, ፈጠራዎች
    #[inline]
    fn default() -> Cell<T> {
        Cell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialEq + Copy> PartialEq for Cell<T> {
    #[inline]
    fn eq(&self, other: &Cell<T>) -> bool {
        self.get() == other.get()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: Eq + Copy> Eq for Cell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: PartialOrd + Copy> PartialOrd for Cell<T> {
    #[inline]
    fn partial_cmp(&self, other: &Cell<T>) -> Option<Ordering> {
        self.get().partial_cmp(&other.get())
    }

    #[inline]
    fn lt(&self, other: &Cell<T>) -> bool {
        self.get() < other.get()
    }

    #[inline]
    fn le(&self, other: &Cell<T>) -> bool {
        self.get() <= other.get()
    }

    #[inline]
    fn gt(&self, other: &Cell<T>) -> bool {
        self.get() > other.get()
    }

    #[inline]
    fn ge(&self, other: &Cell<T>) -> bool {
        self.get() >= other.get()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: Ord + Copy> Ord for Cell<T> {
    #[inline]
    fn cmp(&self, other: &Cell<T>) -> Ordering {
        self.get().cmp(&other.get())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for Cell<T> {
    fn from(t: T) -> Cell<T> {
        Cell::new(t)
    }
}

impl<T> Cell<T> {
    /// የተሰጠው ዋጋ የያዘ አዲስ `Cell` ይፈጥራል.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> Cell<T> {
        Cell { value: UnsafeCell::new(value) }
    }

    /// የ የያዘ ዋጋ ያስቀምጣል.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// c.set(10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn set(&self, val: T) {
        let old = self.replace(val);
        drop(old);
    }

    /// የሁለት ሴሎችን እሴቶች ይቀይራል።
    /// `std::mem::swap` ጋር ልዩነት ይህንን ተግባር `&mut` ማጣቀሻ አይጠይቅም ነው.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c1 = Cell::new(5i32);
    /// let c2 = Cell::new(10i32);
    /// c1.swap(&c2);
    /// assert_eq!(10, c1.get());
    /// assert_eq!(5, c2.get());
    /// ```
    #[inline]
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn swap(&self, other: &Self) {
        if ptr::eq(self, other) {
            return;
        }
        // ደህንነት: ይህ በተለየ ተከታታዮች ከ ተብሎ ከሆነ አደገኛ ሊሆን, ነገር ግን `Cell` ይችላሉ
        // ይህ ሊሆን አይችልም, ስለዚህ `!Sync` ነው.
        // `Cell` ወደ እነዚህ የ‹ሴል›አንዳቸውም የሚያመለክተው ሌላ ነገር እንደሌለ እርግጠኛ ስለማይሆን ይህ ደግሞ ማንኛውንም ጠቋሚዎችን ዋጋ አይሰጥም ፡፡
        //
        unsafe {
            ptr::swap(self.value.get(), other.value.get());
        }
    }

    /// የተገኘውን እሴት በ `val` ይተካዋል ፣ እና ያገኘውን አሮጌ እሴት ይመልሳል።
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let cell = Cell::new(5);
    /// assert_eq!(cell.get(), 5);
    /// assert_eq!(cell.replace(10), 5);
    /// assert_eq!(cell.get(), 10);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn replace(&self, val: T) -> T {
        // ደህንነት: በተለየ ተከታታይ ከ ተብሎ ከሆነ ይህ, የውሂብ ውድድሮች ሊያስከትል ይችላል
        // ግን `Cell` `!Sync` ነው ስለዚህ ይህ አይሆንም ፡፡
        mem::replace(unsafe { &mut *self.value.get() }, val)
    }

    /// እሴት Unwraps.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.into_inner();
    ///
    /// assert_eq!(five, 5);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value.into_inner()
    }
}

impl<T: Copy> Cell<T> {
    /// የያዘውን እሴት ቅጅ ይመልሳል።
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let five = c.get();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get(&self) -> T {
        // ደህንነት: በተለየ ተከታታይ ከ ተብሎ ከሆነ ይህ, የውሂብ ውድድሮች ሊያስከትል ይችላል
        // ግን `Cell` `!Sync` ነው ስለዚህ ይህ አይሆንም ፡፡
        unsafe { *self.value.get() }
    }

    /// አንድን ተግባር በመጠቀም የያዘውን እሴት ያዘምናል እና አዲሱን እሴት ይመልሳል።
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_update)]
    ///
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let new = c.update(|x| x + 1);
    ///
    /// assert_eq!(new, 6);
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[unstable(feature = "cell_update", issue = "50186")]
    pub fn update<F>(&self, f: F) -> T
    where
        F: FnOnce(T) -> T,
    {
        let old = self.get();
        let new = f(old);
        self.set(new);
        new
    }
}

impl<T: ?Sized> Cell<T> {
    /// ጥሬ ጠቋሚ በዚህ ሕዋስ ውስጥ ወዳለው መሠረታዊ መረጃ ይመልሳል።
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    #[rustc_const_stable(feature = "const_cell_as_ptr", since = "1.32.0")]
    pub const fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// ለታችኛው ውሂብ የሚለዋወጥ ማጣቀሻ ይመልሳል።
    ///
    /// ይህ ጥሪ ብቸኛ ማጣቀሻ መያዙን የሚያረጋግጥ `Cell` ን በሚስብ (በሚሰበስብ ጊዜ) ያበድራል።
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let mut c = Cell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// አንድ `&mut T` ከ `&Cell<T>` ይመልሳል
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[inline]
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn from_mut(t: &mut T) -> &Cell<T> {
        // ደህንነት: `&mut` ልዩ መዳረሻን ያረጋግጣል።
        unsafe { &*(t as *mut T as *const Cell<T>) }
    }
}

impl<T: Default> Cell<T> {
    /// የራሱ ቦታ `Default::default()` በመተው ወደ ሕዋስ እሴት ይወስዳል.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<Cell<U>> for Cell<T> {}

impl<T> Cell<[T]> {
    /// ከ `&Cell<[T]>` አንድ `&[Cell<T>]` ይመልሳል
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn as_slice_of_cells(&self) -> &[Cell<T>] {
        // ደህንነት: `Cell<T>` `T` ተመሳሳይ ትውስታ አቀማመጥ አለው.
        unsafe { &*(self as *const Cell<[T]> as *const [Cell<T>]) }
    }
}

/// ተለዋዋጭ በሆነ ሁኔታ ከተፈተሹ የብድር ደንቦች ጋር የሚለዋወጥ የማህደረ ትውስታ ቦታ
///
/// ለተጨማሪ [module-level documentation](self) ን ይመልከቱ።
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefCell<T: ?Sized> {
    borrow: Cell<BorrowFlag>,
    value: UnsafeCell<T>,
}

/// በ [`RefCell::try_borrow`] የተመለሰ ስህተት።
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already mutably borrowed", f)
    }
}

/// አንድ ስህተት [`RefCell::try_borrow_mut`] የተመለሱ.
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowMutError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowMutError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already borrowed", f)
    }
}

// አዎንታዊ እሴቶች የ `Ref` ገባሪ ቁጥርን ይወክላሉ።አሉታዊ እሴቶች የ `RefMut` ገባሪ ቁጥርን ይወክላሉ።
// ብዙ `RefMut`s በአንድ ጊዜ ንቁ ሊሆኑ የሚችሉት የ `RefCell` ን የተለያዩ እና የማይረከቡ ክፍሎችን የሚያመለክቱ ከሆነ ብቻ ነው (ለምሳሌ ፣ የተለያዩ የቁራጭ ቁርጥራጭ)።
//
// `Ref` እና `RefMut` ሁለቱም ሁለት ቃላት በመጠን ነው ፣ ስለሆነም የ `usize` ክልል ግማሹን ለመጥለቅ በሕልውናቸው ውስጥ በቂ `Ref`s`ወይም`RefMut`s` በጭራሽ ላይኖር ይችላል ፡፡
// በመሆኑም አንድ `BorrowFlag` ፈቃድ ምናልባት ፈጽሞ የትርፍ ወይም underflow.
// አንድ ከተወሰደ ፕሮግራም በተደጋጋሚ ከዚያም mem::forget `Ref`s ወይም`RefMut`s መፍጠር እና ይችላል ሆኖ ግን, ይህ, ያለ ዋስትና አይደለም.
// ስለሆነም ደህንነታቸውን ለማስቀረት ሁሉም ኮድ ከመጠን በላይ እና የጎርፍ መጥለቅለቅን በግልፅ ማረጋገጥ አለበት ፣ ወይም ደግሞ ፍሰት ወይም የጎርፍ ፍሰት በሚከሰትበት ጊዜ ቢያንስ ቢያንስ በትክክል ጠባይ ማሳየት (ለምሳሌ BorrowRef::new ን ይመልከቱ) ፡፡
//
//
//
//
//
//
type BorrowFlag = isize;
const UNUSED: BorrowFlag = 0;

#[inline(always)]
fn is_writing(x: BorrowFlag) -> bool {
    x < UNUSED
}

#[inline(always)]
fn is_reading(x: BorrowFlag) -> bool {
    x > UNUSED
}

impl<T> RefCell<T> {
    /// `value` ን የያዘ አዲስ `RefCell` ን ይፈጥራል።
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_refcell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> RefCell<T> {
        RefCell { value: UnsafeCell::new(value), borrow: Cell::new(UNUSED) }
    }

    /// የ `RefCell` ወደ ተጠመጠመ ዋጋ ሲመለሱ, ተቆጣጥሮታል.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let five = c.into_inner();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    #[inline]
    pub const fn into_inner(self) -> T {
        // ይህ ተግባር `self` (`RefCell`) ን በእሴት ስለሚወስድ አጠናቃሪው በአሁኑ ጊዜ እንዳልተዋሰ በስታቲስቲክስ ያረጋግጣል።
        //
        self.value.into_inner()
    }

    /// ከሁለቱ አንዱን deinitializing ያለ, አሮጌውን ዋጋ በመመለስ, አንድን አዲስ ሰው ጋር ተጠቅልሎ ዋጋ ይተካል.
    ///
    ///
    /// ይህ ተግባር ከ [`std::mem::replace`](../mem/fn.replace.html) ጋር ይዛመዳል።
    ///
    /// # Panics
    ///
    /// Panics ዋጋ በአሁኑ የተዋሰው ከሆነ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace(6);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace", since = "1.24.0")]
    #[track_caller]
    pub fn replace(&self, t: T) -> T {
        mem::replace(&mut *self.borrow_mut(), t)
    }

    /// የተጠቀለለውን እሴት ከ `f` በተቆጠረ አዲስ ይተካዋል ፣ የቀደመውን እሴት ይመልሳል ፣ አንዳቸውንም ሳይለዩ።
    ///
    ///
    /// # Panics
    ///
    /// Panics ዋጋ በአሁኑ የተዋሰው ከሆነ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace_with(|&mut old| old + 1);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace_swap", since = "1.35.0")]
    #[track_caller]
    pub fn replace_with<F: FnOnce(&mut T) -> T>(&self, f: F) -> T {
        let mut_borrow = &mut *self.borrow_mut();
        let replacement = f(mut_borrow);
        mem::replace(mut_borrow, replacement)
    }

    /// የ `self` መጠቅለያውን እሴት ከ `other` መጠቅለያ እሴት ጋር ያስተካክላል ፣ አንዳቸውንም ሳይለዩ።
    ///
    ///
    /// ይህ ተግባር [`std::mem::swap`](../mem/fn.swap.html) ጋር ይዛመዳል.
    ///
    /// # Panics
    ///
    /// Panics ወይ `RefCell` ውስጥ ያለውን ዋጋ በአሁኑ የተዋሰው ከሆነ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let c = RefCell::new(5);
    /// let d = RefCell::new(6);
    /// c.swap(&d);
    /// assert_eq!(c, RefCell::new(6));
    /// assert_eq!(d, RefCell::new(5));
    /// ```
    #[inline]
    #[stable(feature = "refcell_swap", since = "1.24.0")]
    pub fn swap(&self, other: &Self) {
        mem::swap(&mut *self.borrow_mut(), &mut *other.borrow_mut())
    }
}

impl<T: ?Sized> RefCell<T> {
    /// ላይለዋወጥ ያለውን ተጠቅልሎ ዋጋ ይበደራል.
    ///
    /// ብድሩ የተመለሰው `Ref` መውጫ እስከሚወጣ ድረስ ይቆያል።
    /// በርካታ በማይለወጥ ይበደራል በአንድ ጊዜ ውጭ ሊወሰድ ይችላል.
    ///
    /// # Panics
    ///
    /// እሴቱ በአሁኑ ጊዜ በተለዋጭነት ከተበደረ Panics
    /// ለማያስደነግጥ ልዩነት ፣ [`try_borrow`](#method.try_borrow) ን ይጠቀሙ።
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let borrowed_five = c.borrow();
    /// let borrowed_five2 = c.borrow();
    /// ```
    ///
    /// panic ምሳሌ:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let m = c.borrow_mut();
    /// let b = c.borrow(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow(&self) -> Ref<'_, T> {
        self.try_borrow().expect("already mutably borrowed")
    }

    /// የተጠጋጋውን ዋጋ በማያወላውል ተበድሮ ፣ እሴቱ በአሁኑ ጊዜ በሚዛን ተለዋጭ ብድር ከተገኘ ስህተት ይመልሳል።
    ///
    ///
    /// ብድሩ የተመለሰው `Ref` መውጫ እስከሚወጣ ድረስ ይቆያል።
    /// በርካታ በማይለወጥ ይበደራል በአንድ ጊዜ ውጭ ሊወሰድ ይችላል.
    ///
    /// ይህ [`borrow`](#method.borrow) ያለውን ያልሆኑ ሳልገባ ተለዋጭ ነው.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(c.try_borrow().is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow().is_ok());
    /// }
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow(&self) -> Result<Ref<'_, T>, BorrowError> {
        match BorrowRef::new(&self.borrow) {
            // ደህንነት: `BorrowRef` ብቻ መዋቲ መዳረሻ መኖሩን ያረጋግጣል
            // በተበደረበት ጊዜ ወደ እሴቱ።
            Some(b) => Ok(Ref { value: unsafe { &*self.value.get() }, borrow: b }),
            None => Err(BorrowError { _private: () }),
        }
    }

    /// የታጠፈውን ዋጋ በሚስጥር በብድር ያበድራል።
    ///
    /// ወደ ቢዋስ ወደ ተመልሶ `RefMut` ወይም መውጫ ወሰን የተገኘ ሁሉ `RefMut`s ድረስ ይቆያል.
    ///
    /// ይህ ብድር በሚሠራበት ጊዜ እሴቱ ሊበደር አይችልም።
    ///
    /// # Panics
    ///
    /// Panics ዋጋ በአሁኑ የተዋሰው ከሆነ.
    /// ያልሆነ ሳልገባ ተለዋጭ, [`try_borrow_mut`](#method.try_borrow_mut) ይጠቀሙ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new("hello".to_owned());
    ///
    /// *c.borrow_mut() = "bonjour".to_owned();
    ///
    /// assert_eq!(&*c.borrow(), "bonjour");
    /// ```
    ///
    /// panic ምሳሌ:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let m = c.borrow();
    ///
    /// let b = c.borrow_mut(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow_mut(&self) -> RefMut<'_, T> {
        self.try_borrow_mut().expect("already borrowed")
    }

    /// Mutably ዋጋ በአሁኑ የተዋሰው ከሆነ ስህተት ሲመለሱ, ወደ ተጠቅልሎ ዋጋ ይበደራል.
    ///
    ///
    /// ወደ ቢዋስ ወደ ተመልሶ `RefMut` ወይም መውጫ ወሰን የተገኘ ሁሉ `RefMut`s ድረስ ይቆያል.
    /// ይህ ብድር በሚሠራበት ጊዜ እሴቱ ሊበደር አይችልም።
    ///
    /// ይህ የ [`borrow_mut`](#method.borrow_mut) የማይደናገጥ ልዩነት ነው።
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow_mut().is_err());
    /// }
    ///
    /// assert!(c.try_borrow_mut().is_ok());
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow_mut(&self) -> Result<RefMut<'_, T>, BorrowMutError> {
        match BorrowRefMut::new(&self.borrow) {
            // ደህንነት: `BorrowRef` ልዩ መዳረሻ ያረጋግጣል.
            Some(b) => Ok(RefMut { value: unsafe { &mut *self.value.get() }, borrow: b }),
            None => Err(BorrowMutError { _private: () }),
        }
    }

    /// ጥሬ ጠቋሚ በዚህ ሕዋስ ውስጥ ወዳለው መሠረታዊ መረጃ ይመልሳል።
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    pub fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// ለታችኛው ውሂብ የሚለዋወጥ ማጣቀሻ ይመልሳል።
    ///
    /// ይህ ጥሪ `RefCell` ን በሚበዛ ሁኔታ ያበድራል (በማጠናቀር-ጊዜ) ስለዚህ ተለዋዋጭ ፍተሻዎች አያስፈልጉም።
    ///
    /// ሆኖም ጠንቃቃ ይሁኑ-ይህ ዘዴ `self` ሊለዋወጥ እንደሚችል ይጠብቃል ፣ ይህ በአጠቃላይ `RefCell` ን ሲጠቀሙ ጉዳዩ አይደለም።
    ///
    /// `self` ሊቀየሩ አይደለም ይልቁንስ ከሆነ [`borrow_mut`] ዘዴ ላይ ይመልከቱ.
    ///
    /// እንዲሁም እባክዎን ይህ ዘዴ ለልዩ ሁኔታዎች ብቻ እንደሆነ እና ብዙውን ጊዜ እርስዎ የሚፈልጉት እንዳልሆነ ይገንዘቡ ፡፡
    /// ጥርጣሬ ካለዎት በምትኩ [`borrow_mut`] ይጠቀሙ።
    ///
    /// [`borrow_mut`]: RefCell::borrow_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c, RefCell::new(6));
    /// ```
    ///
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// የ `RefCell` ያለውን ቢዋስ ሁኔታ ላይ ድርስ ጠባቂዎቹ ውጤት ቀልብስ.
    ///
    /// ይህ ጥሪ ከ [`get_mut`] ጋር ተመሳሳይ ነው ግን የበለጠ ልዩ ነው።
    /// ይህ `RefCell` mutably ምንም ይበደራል ሕልውና ለማረጋገጥ ይበደራል ከዚያም የተጋሩ ይበደራል እየተከታተሉ ሁኔታ ያስጀምረዋል.
    /// አንዳንድ የ `Ref` ወይም `RefMut` ብድሮች ፈስሰው ከሆነ ይህ ተገቢ ነው።
    ///
    /// [`get_mut`]: RefCell::get_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(0);
    /// std::mem::forget(c.borrow_mut());
    ///
    /// assert!(c.try_borrow().is_err());
    /// c.undo_leak();
    /// assert!(c.try_borrow().is_ok());
    /// ```
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn undo_leak(&mut self) -> &mut T {
        *self.borrow.get_mut() = UNUSED;
        self.get_mut()
    }

    /// የተጠጋጋውን ዋጋ በማያወላውል ተበድሮ ፣ እሴቱ በአሁኑ ጊዜ በሚዛን ተለዋጭ ብድር ከተገኘ ስህተት ይመልሳል።
    ///
    /// # Safety
    ///
    /// ከኤክስኤክስኤክስክስክስክስክስክስክስክስክስክስክስክስክስክስክስክስክስክስክስክስክስክስክስክስክስክስክስኤክስኤክስክስክስክስክስክስክስክስክስክስክስክስክስክስክስክስክስክስክስክስክስክስክስክስክስክስክስክስክስክስክስክስክስክስክስክስክስክስክስክስክስክስክስክስክስክስክስክስክስክስክስክስክስክስክስክስክስክስክስክስክስክስክስክስክስክስክስክስክስክስ) ይልቅ እንደ‹XXXXX›XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXDXX
    /// በ ማጣቀሻ በዚህ ዘዴ የተመለሱ ሳለ Mutably ሕያው ነው `RefCell` መበደር ያልተገለጸ ባህሪ ነው.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_ok());
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "borrow_state", since = "1.37.0")]
    #[inline]
    pub unsafe fn try_borrow_unguarded(&self) -> Result<&T, BorrowError> {
        if !is_writing(self.borrow.get()) {
            // ደህንነት-አሁን ማንም በንቃት እየፃፈ አለመሆኑን እናረጋግጣለን ፣ ግን እንደዚያ ነው
            // ወደ ተመልሶ ማጣቀሻ አጠቃቀም ውስጥ ከእንግዲህ ወዲህ የለም ድረስ ጠሪ ኃላፊነት መሆኑን ማንም ይጽፋል ለማረጋገጥ.
            // እንዲሁም ፣ `self.value.get()` የሚያመለክተው በ `self` የተያዘውን እሴት ስለሆነ ስለሆነም ለ‹`self` X›ዕድሜ ልክ ሆኖ የተረጋገጠ ነው ፡፡
            //
            //
            Ok(unsafe { &*self.value.get() })
        } else {
            Err(BorrowError { _private: () })
        }
    }
}

impl<T: Default> RefCell<T> {
    /// `Default::default()` ን በእሱ ቦታ በመተው የተጠቀለለውን እሴት ይወስዳል።
    ///
    /// # Panics
    ///
    /// Panics ዋጋ በአሁኑ የተዋሰው ከሆነ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "refcell_take", since = "1.50.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for RefCell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for RefCell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for RefCell<T> {
    /// # Panics
    ///
    /// እሴቱ በአሁኑ ጊዜ በተለዋጭነት ከተበደረ Panics
    #[inline]
    #[track_caller]
    fn clone(&self) -> RefCell<T> {
        RefCell::new(self.borrow().clone())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for RefCell<T> {
    /// አንድ `RefCell<T>` ቲ ለ `Default` ዋጋ ጋር, ፈጠራዎች
    #[inline]
    fn default() -> RefCell<T> {
        RefCell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for RefCell<T> {
    /// # Panics
    ///
    /// Panics ወይ `RefCell` ውስጥ ያለውን ዋጋ በአሁኑ የተዋሰው ከሆነ.
    #[inline]
    fn eq(&self, other: &RefCell<T>) -> bool {
        *self.borrow() == *other.borrow()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: ?Sized + Eq> Eq for RefCell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for RefCell<T> {
    /// # Panics
    ///
    /// Panics ወይ `RefCell` ውስጥ ያለውን ዋጋ በአሁኑ የተዋሰው ከሆነ.
    #[inline]
    fn partial_cmp(&self, other: &RefCell<T>) -> Option<Ordering> {
        self.borrow().partial_cmp(&*other.borrow())
    }

    /// # Panics
    ///
    /// Panics ወይ `RefCell` ውስጥ ያለውን ዋጋ በአሁኑ የተዋሰው ከሆነ.
    #[inline]
    fn lt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() < *other.borrow()
    }

    /// # Panics
    ///
    /// Panics ወይ `RefCell` ውስጥ ያለውን ዋጋ በአሁኑ የተዋሰው ከሆነ.
    #[inline]
    fn le(&self, other: &RefCell<T>) -> bool {
        *self.borrow() <= *other.borrow()
    }

    /// # Panics
    ///
    /// Panics ወይ `RefCell` ውስጥ ያለውን ዋጋ በአሁኑ የተዋሰው ከሆነ.
    #[inline]
    fn gt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() > *other.borrow()
    }

    /// # Panics
    ///
    /// Panics ወይ `RefCell` ውስጥ ያለውን ዋጋ በአሁኑ የተዋሰው ከሆነ.
    #[inline]
    fn ge(&self, other: &RefCell<T>) -> bool {
        *self.borrow() >= *other.borrow()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + Ord> Ord for RefCell<T> {
    /// # Panics
    ///
    /// Panics ወይ `RefCell` ውስጥ ያለውን ዋጋ በአሁኑ የተዋሰው ከሆነ.
    #[inline]
    fn cmp(&self, other: &RefCell<T>) -> Ordering {
        self.borrow().cmp(&*other.borrow())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for RefCell<T> {
    fn from(t: T) -> RefCell<T> {
        RefCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<RefCell<U>> for RefCell<T> {}

struct BorrowRef<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl<'b> BorrowRef<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRef<'b>> {
        let b = borrow.get().wrapping_add(1);
        if !is_reading(b) {
            // ብድርን መጨመር በእነዚህ ጉዳዮች ላይ የንባብ ያልሆነ እሴት (<=0) ሊያስከትል ይችላል-
            // 1. እሱ <0 ነበር ፣ ማለትም የብድር መፃህፍት አሉ ፣ ስለሆነም በ Rust ማጣቀሻ ስም የለሽ ህጎች ምክንያት የንባብ ብድርን አንፈቅድም
            // 2.
            // እሱ isize::MAX ነበር (ከፍተኛው የንባብ ብድር) እና ወደ isize::MIN ሞልቶ ነበር (ከፍተኛው የጽሑፍ ብድር) ስለዚህ ተጨማሪ የንባብ ብድርን መፍቀድ አንችልም ምክንያቱም isize ብዙ ንባብ ብድሮችን ሊወክል ስለማይችል (ይህ ሊሆን የሚችለው እ.ኤ.አ. እርስዎ mem::forget ከአንድ አነስተኛ ቋሚ መጠን `Ref`s የበለጠ` ፣ ይህ ጥሩ ልምምድ አይደለም)
            //
            //
            //
            //
            None
        } else {
            // ብድርን መጨመር በእነዚህ አጋጣሚዎች የንባብ እሴት (> 0) ሊያስከትል ይችላል-
            // 1. =0 ነበር ፣ ማለትም አልተበደረም ፣ እና የመጀመሪያውን የንባብ ብድር እንወስዳለን
            // 2. ይህ ነበረ> 0 እና <isize::MAX, ማለትም
            // በዚያ የተነበቡ ይበደራል ነበሩ, እና isize አንድ ተጨማሪ ያንብቡ ቢዋስ ያለው ለመወከል ትልቅ በቂ ነው
            borrow.set(b);
            Some(BorrowRef { borrow })
        }
    }
}

impl Drop for BorrowRef<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        self.borrow.set(borrow - 1);
    }
}

impl Clone for BorrowRef<'_> {
    #[inline]
    fn clone(&self) -> Self {
        // ይህ ዳኛ አለ በመሆኑ, እኛ ቢዋስ መጠቆም የንባብ ቢዋስ ነው ያውቃሉ.
        //
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        // የብድር ቆጣሪ ወደ የጽሑፍ ብድር እንዳይፈስ ይከላከሉ ፡፡
        //
        assert!(borrow != isize::MAX);
        self.borrow.set(borrow + 1);
        BorrowRef { borrow: self.borrow }
    }
}

/// አንድ `RefCell` ሳጥን ውስጥ አንድ እሴት የተዋሰው ማጣቀሻ ይጠቀለላል.
/// አንድ `RefCell<T>` ከ ላይለዋወጥ በውሰት ዋጋ የሚሆን መጠቅለያ አይነት.
///
/// ለተጨማሪ [module-level documentation](self) ን ይመልከቱ።
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Ref<'b, T: ?Sized + 'b> {
    value: &'b T,
    borrow: BorrowRef<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Ref<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

impl<'b, T: ?Sized> Ref<'b, T> {
    /// አንድ `Ref` ቅጅዎች።
    ///
    /// የ `RefCell` አስቀድሞ ላይለዋወጥ በውሰት ነው, ስለዚህ ይህ እንዳይጠፋ አይችልም.
    ///
    /// ይህ `Ref::clone(...)` ሆነው ሊያገለግሉ ለማድረግ የሚያስፈልገው አንድ ተጓዳኝ ተግባር ነው.
    /// የ `Clone` አተገባበር ወይም ዘዴ የ‹`RefCell` X›ይዘቶችን ለማጣመር የ‹`r.borrow().clone()`›ሰፊ አጠቃቀም ላይ ጣልቃ ይገባል ፡፡
    ///
    ///
    #[stable(feature = "cell_extras", since = "1.15.0")]
    #[inline]
    pub fn clone(orig: &Ref<'b, T>) -> Ref<'b, T> {
        Ref { value: orig.value, borrow: orig.borrow.clone() }
    }

    /// የ የተዋሰው ውሂብ አካል አዲስ `Ref` ያደርገዋል.
    ///
    /// የ `RefCell` አስቀድሞ ላይለዋወጥ በውሰት ነው, ስለዚህ ይህ እንዳይጠፋ አይችልም.
    ///
    /// ይህ `Ref::map(...)` ሆነው ሊያገለግሉ ለማድረግ የሚያስፈልገው አንድ ተጓዳኝ ተግባር ነው.
    /// አንድ ዘዴ `Deref` በኩል የዋለ `RefCell` ይዘቶች ላይ ተመሳሳይ ስም ዘዴዎች ጣልቃ ነበር.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// let b1: Ref<(u32, char)> = c.borrow();
    /// let b2: Ref<u32> = Ref::map(b1, |t| &t.0);
    /// assert_eq!(*b2, 5)
    /// ```
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Ref<'b, U>
    where
        F: FnOnce(&T) -> &U,
    {
        Ref { value: f(orig.value), borrow: orig.borrow }
    }

    /// ለተበዳሪው የውሂብ አማራጭ አካል አዲስ `Ref` ያደርገዋል።
    /// መዘጋቱ `None` ን ከተመለሰ ዋናው ጥበቃ እንደ `Err(..)` ተመልሷል።
    ///
    /// የ `RefCell` አስቀድሞ ላይለዋወጥ በውሰት ነው, ስለዚህ ይህ እንዳይጠፋ አይችልም.
    ///
    /// ይህ `Ref::filter_map(...)` ሆነው ሊያገለግሉ ለማድረግ የሚያስፈልገው አንድ ተጓዳኝ ተግባር ነው.
    /// አንድ ዘዴ `Deref` በኩል የዋለ `RefCell` ይዘቶች ላይ ተመሳሳይ ስም ዘዴዎች ጣልቃ ነበር.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    /// let b1: Ref<Vec<u32>> = c.borrow();
    /// let b2: Result<Ref<u32>, _> = Ref::filter_map(b1, |v| v.get(1));
    /// assert_eq!(*b2.unwrap(), 2);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Result<Ref<'b, U>, Self>
    where
        F: FnOnce(&T) -> Option<&U>,
    {
        match f(orig.value) {
            Some(value) => Ok(Ref { value, borrow: orig.borrow }),
            None => Err(orig),
        }
    }

    /// በርካታ `Ref`s ወደ አንድ `Ref` ወደ የተዋሰው ውሂብ የተለያዩ ክፍሎች ለ ይለውጠዋል.
    ///
    /// የ `RefCell` አስቀድሞ ላይለዋወጥ በውሰት ነው, ስለዚህ ይህ እንዳይጠፋ አይችልም.
    ///
    /// ይህ `Ref::map_split(...)` ሆነው ሊያገለግሉ ለማድረግ የሚያስፈልገው አንድ ተጓዳኝ ተግባር ነው.
    /// አንድ ዘዴ `Deref` በኩል የዋለ `RefCell` ይዘቶች ላይ ተመሳሳይ ስም ዘዴዎች ጣልቃ ነበር.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{Ref, RefCell};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow();
    /// let (begin, end) = Ref::map_split(borrow, |slice| slice.split_at(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// ```
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(orig: Ref<'b, T>, f: F) -> (Ref<'b, U>, Ref<'b, V>)
    where
        F: FnOnce(&T) -> (&U, &V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (Ref { value: a, borrow }, Ref { value: b, borrow: orig.borrow })
    }

    /// ከስር ያለው ውሂብ ወደ ማጣቀሻ ወደ ይለውጡ.
    ///
    /// መሠረታዊው `RefCell` በጭራሽ በሚታይ መልኩ በብድር ሊበደር የማይችል ሲሆን ሁልጊዜም በማይቀየር ሁኔታ አስቀድሞ የተዋሰ ይመስላል።
    ///
    /// ከተከታታይ ቁጥር ማጣቀሻዎች በላይ ማፍሰስ ጥሩ ሀሳብ አይደለም ፡፡
    /// ጭሱን ብቻ አነስ ቁጥር በጠቅላላው ተከስቷል ከሆነ የ `RefCell` ላይለዋወጥ እንደገና ተውሼ ይቻላል.
    ///
    /// ይህ እንደ `Ref::leak(...)` ሆኖ ሊያገለግል የሚችል ተጓዳኝ ተግባር ነው።
    /// አንድ ዘዴ `Deref` በኩል የዋለ `RefCell` ይዘቶች ላይ ተመሳሳይ ስም ዘዴዎች ጣልቃ ነበር.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, Ref};
    /// let cell = RefCell::new(0);
    ///
    /// let value = Ref::leak(cell.borrow());
    /// assert_eq!(*value, 0);
    ///
    /// assert!(cell.try_borrow().is_ok());
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: Ref<'b, T>) -> &'b T {
        // ይህንን ማጣቀሻ በመርሳት በ RefCell ውስጥ ያለው የብድር ቆጣሪ በሕይወት ዘመን `'b` ውስጥ ወደ UNUSED መመለስ እንደማይችል እናረጋግጣለን ፡፡
        // የማጣቀሻ መከታተያ ሁኔታን እንደገና ማስጀመር ለተበደረው RefCell ልዩ ማጣቀሻ ይፈልጋል።
        // ከመጀመሪያው ሕዋስ ተጨማሪ የሚለወጡ ማጣቀሻዎች ሊፈጠሩ አይችሉም።
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Ref<'b, U>> for Ref<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Ref<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

impl<'b, T: ?Sized> RefMut<'b, T> {
    /// የ የተዋሰው ውሂብ, ለምሳሌ, አንድ enum ተለዋጭ አካል አዲስ `RefMut` ያደርገዋል.
    ///
    /// ኤክስኤክስኤክስ ቀድሞውኑ በሚታይ መልኩ ብድር ነው ፣ ስለሆነም ይህ ሊሳካ አይችልም።
    ///
    /// ይህ እንደ `RefMut::map(...)` ሆኖ ሊያገለግል የሚችል ተጓዳኝ ተግባር ነው።
    /// አንድ ዘዴ `Deref` በኩል የዋለ `RefCell` ይዘቶች ላይ ተመሳሳይ ስም ዘዴዎች ጣልቃ ነበር.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// {
    ///     let b1: RefMut<(u32, char)> = c.borrow_mut();
    ///     let mut b2: RefMut<u32> = RefMut::map(b1, |t| &mut t.0);
    ///     assert_eq!(*b2, 5);
    ///     *b2 = 42;
    /// }
    /// assert_eq!(*c.borrow(), (42, 'b'));
    /// ```
    ///
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> RefMut<'b, U>
    where
        F: FnOnce(&mut T) -> &mut U,
    {
        // FIXME(nll-rfc#40): ያስተካክሉ የብድር-ቼክ
        let RefMut { value, borrow } = orig;
        RefMut { value: f(value), borrow }
    }

    /// ለተበዳሪው የውሂብ አማራጭ አካል አዲስ `RefMut` ያደርገዋል።
    /// መዘጋቱ `None` ን ከተመለሰ ዋናው ጥበቃ እንደ `Err(..)` ተመልሷል።
    ///
    /// ኤክስኤክስኤክስ ቀድሞውኑ በሚታይ መልኩ ብድር ነው ፣ ስለሆነም ይህ ሊሳካ አይችልም።
    ///
    /// ይህ እንደ `RefMut::filter_map(...)` ሆኖ ሊያገለግል የሚችል ተጓዳኝ ተግባር ነው።
    /// አንድ ዘዴ `Deref` በኩል የዋለ `RefCell` ይዘቶች ላይ ተመሳሳይ ስም ዘዴዎች ጣልቃ ነበር.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    ///
    /// {
    ///     let b1: RefMut<Vec<u32>> = c.borrow_mut();
    ///     let mut b2: Result<RefMut<u32>, _> = RefMut::filter_map(b1, |v| v.get_mut(1));
    ///
    ///     if let Ok(mut b2) = b2 {
    ///         *b2 += 2;
    ///     }
    /// }
    ///
    /// assert_eq!(*c.borrow(), vec![1, 4, 3]);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> Result<RefMut<'b, U>, Self>
    where
        F: FnOnce(&mut T) -> Option<&mut U>,
    {
        // FIXME(nll-rfc#40): ያስተካክሉ የብድር-ቼክ
        let RefMut { value, borrow } = orig;
        let value = value as *mut T;
        // ደህንነት-ተግባር ለተወሰነ ጊዜ ብቻ ልዩ ማጣቀሻ ይይዛል
        // በ `orig` በኩል የሚጠራ ሲሆን ጠቋሚው ብቸኛ ማጣቀሻውን እንዲያመልጥ የማይፈቅድለት የተግባሩ ጥሪ ውስጥ ብቻ የተጠቀሰው ነው ፡፡
        //
        //
        match f(unsafe { &mut *value }) {
            Some(value) => Ok(RefMut { value, borrow }),
            None => {
                // ደህንነት-ከላይ ካለው ጋር ተመሳሳይ ፡፡
                Err(RefMut { value: unsafe { &mut *value }, borrow })
            }
        }
    }

    /// ለተበደሩት የውሂብ አካላት አንድ `RefMut` ን ወደ በርካታ‹RefMut`s ይከፈላል ፡፡
    ///
    /// ሁለቱም የ‹RefMut›ስፋት ከክልላቸው እስከሚወጡ ድረስ ያለው መሠረታዊ `RefCell` በሚበዳሪነት እንደተበደረ ይቆያል ፡፡
    ///
    /// ኤክስኤክስኤክስ ቀድሞውኑ በሚታይ መልኩ ብድር ነው ፣ ስለሆነም ይህ ሊሳካ አይችልም።
    ///
    /// ይህ `RefMut::map_split(...)` ሆነው ሊያገለግሉ ለማድረግ የሚያስፈልገው አንድ ተጓዳኝ ተግባር ነው.
    /// አንድ ዘዴ `Deref` በኩል የዋለ `RefCell` ይዘቶች ላይ ተመሳሳይ ስም ዘዴዎች ጣልቃ ነበር.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow_mut();
    /// let (mut begin, mut end) = RefMut::map_split(borrow, |slice| slice.split_at_mut(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// begin.copy_from_slice(&[4, 3]);
    /// end.copy_from_slice(&[2, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(
        orig: RefMut<'b, T>,
        f: F,
    ) -> (RefMut<'b, U>, RefMut<'b, V>)
    where
        F: FnOnce(&mut T) -> (&mut U, &mut V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (RefMut { value: a, borrow }, RefMut { value: b, borrow: orig.borrow })
    }

    /// ወደ መሰረታዊው መረጃ ወደ ሚውቴሽን ማጣቀሻ ይለውጡ።
    ///
    /// መሠረታዊው `RefCell` እንደገና ሊበደር የማይችል ሲሆን ሁል ጊዜም በሚበዛ መልኩ እንደተበደረ ሆኖ ይታያል ፣ የተመለሰውን ማጣቀሻ ብቸኛው የውስጠኛው ክፍል ያደርገዋል።
    ///
    ///
    /// ይህ እንደ `RefMut::leak(...)` ሆኖ ሊያገለግል የሚችል ተጓዳኝ ተግባር ነው።
    /// አንድ ዘዴ `Deref` በኩል የዋለ `RefCell` ይዘቶች ላይ ተመሳሳይ ስም ዘዴዎች ጣልቃ ነበር.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, RefMut};
    /// let cell = RefCell::new(0);
    ///
    /// let value = RefMut::leak(cell.borrow_mut());
    /// assert_eq!(*value, 0);
    /// *value = 1;
    ///
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: RefMut<'b, T>) -> &'b mut T {
        // ይህንን BorrowRefMut በመርሳት በ RefCell ውስጥ ያለው የብድር ቆጣሪ በሕይወት ዘመን `'b` ውስጥ ወደ UNUSED መመለስ እንደማይችል እናረጋግጣለን።
        // የማጣቀሻ መከታተያ ሁኔታን እንደገና ማስጀመር ለተበደረው RefCell ልዩ ማጣቀሻ ይፈልጋል።
        // በዚያ የሕይወት ዘመን ውስጥ ከዋናው ሕዋስ ምንም ተጨማሪ ማጣቀሻዎች ሊፈጠሩ አይችሉም ፣ የአሁኑን ብድር ለቀሪው የሕይወት ዘመን ብቸኛ ማጣቀሻ ያደርገዋል ፡፡
        //
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

struct BorrowRefMut<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl Drop for BorrowRefMut<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        self.borrow.set(borrow + 1);
    }
}

impl<'b> BorrowRefMut<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRefMut<'b>> {
        // NOTE: ከ BorrowRefMut::clone በተለየ መልኩ የመጀመሪያውን ለመፍጠር አዲስ ተጠርቷል
        // የሚለዋወጥ ማጣቀሻ ፣ እና ስለዚህ በአሁኑ ጊዜ ምንም ነባር ማጣቀሻዎች መኖር የለባቸውም።
        // በመሆኑም ለቅጂ ጭማሪዎች ወደ ሊቀየሩ refcount እዚህ እኛ በግልጽ ብቻ ጥቅም ላይ ያልዋለ ወደ ላይ ያልዋለ ከ 1 በመሄድ መፍቀድ ሳለ.
        //
        match borrow.get() {
            UNUSED => {
                borrow.set(UNUSED - 1);
                Some(BorrowRefMut { borrow })
            }
            _ => None,
        }
    }

    // ክሎኖች አንድ `BorrowRefMut`።
    //
    // እያንዳንዱ `BorrowRefMut` የመጀመሪያው ነገር አንድ የተለየ, nonoverlapping ክልል አንድ ሊቀየሩ ማጣቀሻ ለመከታተል ጥቅም ላይ ከሆነ ይህ ብቻ የሚሰራ ነው.
    //
    // ይህ ኮድ በተዘዋዋሪ እንዳይጠራው ይህ በ Clone impl ውስጥ የለም።
    #[inline]
    fn clone(&self) -> BorrowRefMut<'b> {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        // underflowing ከ ቢዋስ ቆጣሪ ይከላከሉ.
        assert!(borrow != isize::MIN);
        self.borrow.set(borrow - 1);
        BorrowRefMut { borrow: self.borrow }
    }
}

/// ከ‹XXXX›ጋር በሚበዛ ሁኔታ ለተበደረ እሴት መጠቅለያ አይነት።
///
/// ለተጨማሪ [module-level documentation](self) ን ይመልከቱ።
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefMut<'b, T: ?Sized + 'b> {
    value: &'b mut T,
    borrow: BorrowRefMut<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for RefMut<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for RefMut<'_, T> {
    #[inline]
    fn deref_mut(&mut self) -> &mut T {
        self.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<RefMut<'b, U>> for RefMut<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for RefMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

/// Rust ውስጥ የውስጥ mutability ለ አስመስሏቸዋል ዋና.
///
/// የማጣቀሻ `&T` ካለዎት በመደበኛነት በ Rust ውስጥ አሰባሳቢው `&T` ወደ የማይለዋወጥ ውሂብ በሚጠቁም ዕውቀት ላይ በመመርኮዝ ማመቻቸት ያካሂዳል።ተለዋጭ በኩል ወይም `&mut T` ወደ አንድ `&T` transmuting ለምሳሌ ውሂብ, Mutating, ያልተገለጸ ባህሪ ይቆጠራል.
/// `UnsafeCell<T>` ያስወጣዎታል-ውጭ `&T` የሚሆን የማይለወጥ ዋስትና: የተጋራ ማጣቀሻ `&UnsafeCell<T>` mutated እየተደረገ መሆኑን ውሂብ መጠቆም ይችላል.ይህ "interior mutability" ይባላል.
///
/// እንደ `Cell<T>` እና `RefCell<T>` ያሉ ውስጣዊ መለዋወጥን የሚፈቅዱ ሌሎች ሁሉም ዓይነቶች በውስጣቸው መረጃዎቻቸውን ለመጠቅለል `UnsafeCell` ን ይጠቀማሉ ፡፡
///
/// የተጋሩ ማጣቀሻዎች ያህል ብቻ የማይለወጥ ዋስትና `UnsafeCell` ተጽዕኖ መሆኑን ልብ በል.ለሚለዋወጥ ማጣቀሻዎች ልዩ ዋስትና ተጽዕኖ አልተደረገም ፡፡ከ `UnsafeCell<T>` ጋር እንኳን ቢሆን `&mut` ን መጠየቅያ ለማግኘት *ምንም* ህጋዊ መንገድ የለም።
///
/// የ `UnsafeCell` ኤ ራሱ በቴክኒካዊ በጣም ቀላል ነው: [`.get()`] እርስዎ ይዘቱን ወደ ጥሬ የጠቋሚ `*mut T` ይሰጣል.በትክክል ይህ ጥሬ ጠቋሚ ለመጠቀም የአብስትራክት ነዳፊ እንደ _you_ ድረስ ነው.
///
/// [`.get()`]: `UnsafeCell::get`
///
/// ትክክለኛው የ Rust መጠሪያ ህጎች በተወሰነ ደረጃ እየተለዋወጡ ናቸው ፣ ግን ዋና ዋና ነጥቦቹ አከራካሪ አይደሉም-
///
/// - በህይወትዎ `'a` (በ `&T` ወይም `&mut T` ማጣቀሻ) ደህንነቱ በተጠበቀ ኮድ ተደራሽ የሆነ ደህንነቱ የተጠበቀ ማጣቀሻ ከፈጠሩ (ለምሳሌ እርስዎ ስለመለሱት) ፣ ከዚያ ለተቀረው ያንን ማጣቀሻ በሚቃረን በማንኛውም መንገድ መረጃውን መድረስ የለብዎትም ፡፡ የ `'a`።
/// ለምሳሌ ያህል, አንድ `UnsafeCell<T>` ከ `*mut T` እንዲወስዱና `&T` ጋር የማወጣ ከሆንሁ: እንግዲህ `T` ውስጥ ያለውን ውሂብ በማይለወጥ መቆየት እንዳለባቸው ይህ ማለት ማጣቀሻ የህይወት ጊዜው ድረስ (ማንኛውም `UnsafeCell` ውሂብ እርግጥ ነው, `T` ውስጥ የሚገኘው ሞዱሎ).
/// ደህንነትዎን ኮድ በተለቀቀ አንድ `&mut T` ማጣቀሻ መፍጠር ከሆነ ማጣቀሻ ጊዜው ድረስ በተመሳሳይም, ከዚያም ወደ `UnsafeCell` ውስጥ ያለውን ውሂብ መድረስ አለበት.
///
/// - በማንኛውም ጊዜ የውሂብ ውድድሮችን ማስወገድ አለብዎት።ብዙ ክሮች ወደ ተመሳሳይ `UnsafeCell` መዳረሻ ካላቸው ፣ ከዚያ ማንኛውም ጽሁፎች ከሁሉም መድረሻዎች ጋር ከመዛመዳቸው በፊት (ወይም አቶሚክስን ከመጠቀም) በፊት በትክክል መከሰት አለበት ፡፡
///
/// ለትክክለኛው ዲዛይን ለማገዝ የሚከተሉት ሁኔታዎች ለአንድ ነጠላ ክር ኮድ በሕጋዊነት ታውቀዋል-
///
/// 1. የ `&T` ማጣቀሻ ለደህንነት ኮድ ሊለቀቅ ይችላል እና እዚያም ከሌሎች የ `&T` ማጣቀሻዎች ጋር አብሮ ሊኖር ይችላል ፣ ግን ከ `&mut T` ጋር አይደለም
///
/// 2. አንድ `&mut T` ማጣቀሻ ጋር ቢሆን ሌላ `&mut T` ሆነ `&T` አብሮ ላይ ሊኖሩ የቀረበ አስተማማኝ ኮድ ይፋ ሊሆኑ ይችላሉ.አንድ `&mut T` ሁልጊዜ ልዩ መሆን አለበት.
///
/// አንድ `&UnsafeCell<T>` ይዘቶች mutating እያስቀመጠ (ሕዋስ ቅጽል ሌሎች `&UnsafeCell<T>` ማጣቀሻዎች እንኳ) እሺ ነው (ከላይ invariants በሌላ መንገድ ለማስፈጸም የቀረበ) መሆኑን ልብ በል, አሁንም በርካታ `&mut UnsafeCell<T>` ቅጽሎች ማድረግ ያልተገለጸ ባህሪ ነው.
/// ማለትም `UnsafeCell` በ `&UnsafeCell<_>` ማጣቀሻ በኩል ከ _shared_ accesses (_i.e._ ጋር ልዩ መስተጋብር እንዲኖር ተደርጎ የተሠራ መጠቅለያ ነው);በ `&mut UnsafeCell<_>` በኩል ከ _exclusive_ accesses (_e.g._ ጋር በሚገናኝበት ጊዜ ምንም ዓይነት አስማት የለም):-ሴል ወይም የተጠቀለለው እሴት ለዚያ `&mut` በሚበደርበት ጊዜ ተለዋጭ ሊሆኑ አይችሉም።
///
/// ይህ በ [`.get_mut()`] ተደራሽነት ይገለጻል ፣ ይህም `&mut T` ን የሚያመጣ _safe_ getter ነው።
///
/// [`.get_mut()`]: `UnsafeCell::get_mut`
///
/// # Examples
///
/// እዚህ ለመዳኑ ሕዋስ aliasing በርካታ ማጣቀሻዎች በዚያ ሰው ቢሆንም አንድ `UnsafeCell<_>` ይዘቶችን ትጀምሩ እንደሚቻል የሚያሳይ አንድ ምሳሌ ነው:
///
/// ```
/// use std::cell::UnsafeCell;
///
/// let x: UnsafeCell<i32> = 42.into();
/// // ለተመሳሳይ `x` በርካታ/ተመሳሳይ/የተጋሩ ማጣቀሻዎችን ያግኙ።
/// let (p1, p2): (&UnsafeCell<i32>, &UnsafeCell<i32>) = (&x, &x);
///
/// unsafe {
///     // ደህንነት: ይህን ወሰን ውስጥ x`ይዘቶች`ምንም ሌሎች ማጣቀሻዎች አሉ,
///     // ስለዚህ የእኛ ውጤታማ በሆነ መልኩ ልዩ ነው ፡፡
///     let p1_exclusive: &mut i32 = &mut *p1.get(); // -- መበደር-+
///     *p1_exclusive += 27; // |
/// } // <---------- ከዚህ ነጥብ ማለፍ አይችልም -------------------+
///
/// unsafe {
///     // ደህንነት: ይህን ወሰን ማንም x`ይዘቶች`ብቸኛ መዳረሻ እንዲኖራቸው ይጠብቃል ውስጥ,
///     // ስለዚህ እኛ ንደመኖሩ በርካታ የተጋሩ የመጠቀሚያ ጊዜ ሊኖረው ይችላል.
///     let p2_shared: &i32 = &*p2.get();
///     assert_eq!(*p2_shared, 42 + 27);
///     let p1_shared: &i32 = &*p1.get();
///     assert_eq!(*p1_shared, *p2_shared);
/// }
/// ```
///
/// የሚከተለው ምሳሌ አንድ `UnsafeCell<T>` ብቸኛ መዳረሻ የራሱ `T` ብቸኛ መዳረሻ ያመለክታል እውነታ አጉልቶ:
///
/// ```rust
/// #![forbid(unsafe_code)] // በልዩ መድረሻዎች ፣
///                         // `UnsafeCell` አንድ ግልጽ ምንም-op መጠቅለያ, እዚህ `unsafe` በጣም አያስፈልግም ነው.
/////
/// use std::cell::UnsafeCell;
///
/// let mut x: UnsafeCell<i32> = 42.into();
///
/// // ወደ `x` በጥምር-ጊዜ የተረጋገጠ ልዩ ማጣቀሻ ያግኙ።
/// let p_unique: &mut UnsafeCell<i32> = &mut x;
/// // በልዩ ማጣቀሻ ይዘቱን በነፃ መለወጥ እንችላለን ፡፡
/// *p_unique.get_mut() = 0;
/// // ወይም በእኩል
/// x = UnsafeCell::new(0);
///
/// // የእሴቱ ባለቤት ስንሆን ይዘቱን በነፃ ማውጣት እንችላለን ፡፡
/// let contents: i32 = x.into_inner();
/// assert_eq!(contents, 0);
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "unsafe_cell"]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
#[repr(no_niche)] // rust-lang/rust#68303.
pub struct UnsafeCell<T: ?Sized> {
    value: T,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for UnsafeCell<T> {}

impl<T> UnsafeCell<T> {
    /// የተጠቀሰውን እሴት የሚሸፍን አዲስ የ `UnsafeCell` ምሳሌ ይገነባል።
    ///
    ///
    /// በስልቶች በኩል ወደ ውስጣዊ እሴቱ ሁሉም መዳረሻ `unsafe` ነው።
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafe_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> UnsafeCell<T> {
        UnsafeCell { value }
    }

    /// እሴት Unwraps.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.into_inner();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value
    }
}

impl<T: ?Sized> UnsafeCell<T> {
    /// ወደ መጠቅለያው እሴት የሚለዋወጥ ጠቋሚ ያገኛል።
    ///
    /// ይህ ለማንኛውም ዓይነት ጠቋሚ ሊጣል ይችላል ፡፡
    /// ወደ `&mut T` ሲወርዱ መድረሻው ልዩ (ምንም ንቁ ማጣቀሻዎች የሉም ፣ ሊለወጡ ወይም ሊለወጡ አይችሉም) ያረጋግጡ ፣ እና ወደ `&T` ሲወስዱ የሚቀጥሉ ሚውቴሽን ወይም የሚለወጡ ተለዋጭ ስሞች አለመኖራቸውን ያረጋግጡ ፡፡
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.get();
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafecell_get", since = "1.32.0")]
    pub const fn get(&self) -> *mut T {
        // እኛ ብቻ #[repr(transparent)] የተነሳ `T` ወደ `UnsafeCell<T>` ከ ጠቋሚ መውሰድ ይችላሉ.
        // ይህ libstd ልዩ ሁኔታ የሚያጋልጥ, ይህ አጠናቃሪ ውስጥ future ስሪቶች ውስጥ ይሰራል መሆኑን የተጠቃሚ ኮድ ምንም ዋስትና የለም!
        //
        self as *const UnsafeCell<T> as *const T as *mut T
    }

    /// ለታችኛው ውሂብ የሚለዋወጥ ማጣቀሻ ይመልሳል።
    ///
    /// ይህ ጥሪ እኛ ብቻ ማጣቀሻ ከማገኘውም ዋስትና ይህም (ማጠናቀር-ጊዜ) mutably ያለውን `UnsafeCell` ይበደራል.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let mut c = UnsafeCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(*c.get_mut(), 6);
    /// ```
    #[inline]
    #[stable(feature = "unsafe_cell_get_mut", since = "1.50.0")]
    pub fn get_mut(&mut self) -> &mut T {
        &mut self.value
    }

    /// ወደ መጠቅለያው እሴት የሚለዋወጥ ጠቋሚ ያገኛል።
    /// [`get`] ወደ ያለውን ልዩነት ይህን ተግባር ጊዜያዊ ማጣቀሻዎች መፍጠር ማስወገድ ጠቃሚ የሆነ ጥሬ ጠቋሚ, የሚቀበለው ነው.
    ///
    /// ውጤቱ ለማንኛውም ዓይነት ጠቋሚ ሊጣል ይችላል ፡፡
    /// ወደ `&mut T` ሲወርዱ መድረሱ ልዩ (ምንም ንቁ ማጣቀሻዎች የሉም ፣ ሊለዋወጥ ወይም ሊለዋወጥ የሚችል) መሆኑን ያረጋግጡ ፣ እና ወደ `&T` በሚወስዱበት ጊዜ የሚቀጥሉ ሚውቴሽን ወይም የሚለወጡ ተለዋጭ ስሞች አለመኖራቸውን ያረጋግጡ ፡፡
    ///
    ///
    /// [`get`]: UnsafeCell::get()
    ///
    /// # Examples
    ///
    /// `get` ን መጥራት ያልታወቀ መረጃ ማጣቀሻ መፍጠርን ስለሚጠይቅ የ `UnsafeCell` ቀስ በቀስ ጅምር `raw_get` ን ይፈልጋል ፡፡
    ///
    /// ```
    /// #![feature(unsafe_cell_raw_get)]
    /// use std::cell::UnsafeCell;
    /// use std::mem::MaybeUninit;
    ///
    /// let m = MaybeUninit::<UnsafeCell<i32>>::uninit();
    /// unsafe { UnsafeCell::raw_get(m.as_ptr()).write(5); }
    /// let uc = unsafe { m.assume_init() };
    ///
    /// assert_eq!(uc.into_inner(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "unsafe_cell_raw_get", issue = "66358")]
    pub const fn raw_get(this: *const Self) -> *mut T {
        // እኛ ብቻ #[repr(transparent)] የተነሳ `T` ወደ `UnsafeCell<T>` ከ ጠቋሚ መውሰድ ይችላሉ.
        // ይህ libstd ልዩ ሁኔታ የሚያጋልጥ, ይህ አጠናቃሪ ውስጥ future ስሪቶች ውስጥ ይሰራል መሆኑን የተጠቃሚ ኮድ ምንም ዋስትና የለም!
        //
        this as *const T as *mut T
    }
}

#[stable(feature = "unsafe_cell_default", since = "1.10.0")]
impl<T: Default> Default for UnsafeCell<T> {
    /// አንድ `UnsafeCell` ቲ ለ `Default` ዋጋ ጋር, ፈጠራዎች
    fn default() -> UnsafeCell<T> {
        UnsafeCell::new(Default::default())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for UnsafeCell<T> {
    fn from(t: T) -> UnsafeCell<T> {
        UnsafeCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<UnsafeCell<U>> for UnsafeCell<T> {}

#[allow(unused)]
fn assert_coerce_unsized(a: UnsafeCell<&i32>, b: Cell<&i32>, c: RefCell<&i32>) {
    let _: UnsafeCell<&dyn Send> = a;
    let _: Cell<&dyn Send> = b;
    let _: RefCell<&dyn Send> = c;
}