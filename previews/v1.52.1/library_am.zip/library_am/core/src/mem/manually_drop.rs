use crate::ops::{Deref, DerefMut};
use crate::ptr;

/// በራስ `T` ዎቹ destructor በመደወል ከ አሰራርን አጠናቃሪ ወደ አንድ መጠቅለያ.
/// ይህ መጠቅለያ 0-ወጭ ነው።
///
/// `ManuallyDrop<T>` እንደ `T` ተመሳሳይ የአቀማመጥ ማመቻቸት ተገዢ ነው።
/// በዚህ ምክንያት አጠናቃጁ ስለ ይዘቱ በሚወስዳቸው ግምቶች ላይ *ምንም ውጤት* የለውም ፡፡
/// ለምሳሌ ፣ `ManuallyDrop<&mut T>` ን ከ [`mem::zeroed`] ጋር ማስጀመር ያልተገለጸ ባህሪ ነው።
/// ያልታወቁ መረጃዎችን ማስተናገድ ከፈለጉ በምትኩ [`MaybeUninit<T>`] ን ይጠቀሙ።
///
/// አንድ `ManuallyDrop<T>` ውስጥ ዋጋ መድረስ አስተማማኝ መሆኑን ልብ ይበሉ.
/// ይህ ማለት ይዘቱ የወረደ `ManuallyDrop<T>` በሕዝብ ደህንነት ኤፒአይ በኩል መጋለጥ የለበትም ማለት ነው።
/// ከዚህ ጋር በሚመሳሰል መልኩ, `ManuallyDrop::drop` አደገኛ ነው.
///
/// # `ManuallyDrop` እና ትዕዛዝ ጣል.
///
/// Rust እሴቶች በደንብ የተገለጸ [drop order] አለው.
/// , መስኮች ወይም የአካባቢው ሰዎች በአንድ የተወሰነ ትዕዛዝ ጣለች መሆናቸውን ለማረጋገጥ በ ስውር በሆነ ጠብታ ትዕዛዝ ትክክለኛው ሰው ነው እንደዚህ መሆኑን እወጃዎች ለመደርደር.
///
/// ይህ ይጣሉ ትዕዛዝ ለመቆጣጠር `ManuallyDrop` መጠቀም ይቻላል, ነገር ግን ይህን ደህንነቱ ያልተጠበቀ ኮድ ይጠይቃል እና የመተርተሩ ፊት በትክክል ማድረግ አስቸጋሪ ነው.
///
///
/// ለምሳሌ ፣ አንድ የተወሰነ መስክ ከሌሎቹ በኋላ እንደወደቀ ማረጋገጥ ከፈለጉ ፣ የመዋቅር የመጨረሻ መስክ ያድርጉት-
///
/// ```
/// struct Context;
///
/// struct Widget {
///     children: Vec<Widget>,
///     // `context` `children` በኋላ ተቋርጧል ይሆናል.
///     // Rust በአዋጅ ቅደም ተከተል መስኮች መውደቃቸውን ያረጋግጣል ፡፡
///     context: Context,
/// }
/// ```
///
/// [drop order]: https://doc.rust-lang.org/reference/destructors.html
/// [`mem::zeroed`]: crate::mem::zeroed
/// [`MaybeUninit<T>`]: crate::mem::MaybeUninit
///
///
///
///
///
#[stable(feature = "manually_drop", since = "1.20.0")]
#[lang = "manually_drop"]
#[derive(Copy, Clone, Debug, Default, PartialEq, Eq, PartialOrd, Ord, Hash)]
#[repr(transparent)]
pub struct ManuallyDrop<T: ?Sized> {
    value: T,
}

impl<T> ManuallyDrop<T> {
    /// አንድ እሴት መጠቅለል በእጅ ተቋርጧል ይሆናል.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let mut x = ManuallyDrop::new(String::from("Hello World!"));
    /// x.truncate(5); // አሁንም በእሴቱ ላይ ደህንነቱ በተጠበቀ ሁኔታ መሥራት ይችላሉ
    /// assert_eq!(*x, "Hello");
    /// // ነገር ግን `Drop` እዚህ ማስኬድ አይችልም
    /// ```
    #[must_use = "if you don't need the wrapper, you can use `mem::forget` instead"]
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(value: T) -> ManuallyDrop<T> {
        ManuallyDrop { value }
    }

    /// የ `ManuallyDrop` መያዣ ከ እሴትን.
    ///
    /// ይህ ዋጋ እንደገና ተቋርጧል ያስችለዋል.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let x = ManuallyDrop::new(Box::new(()));
    /// let _: Box<()> = ManuallyDrop::into_inner(x); // ይህ `Box` ዝቅ.
    /// ```
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn into_inner(slot: ManuallyDrop<T>) -> T {
        slot.value
    }

    /// የ `ManuallyDrop<T>` መያዣ ውጭ ከ ዋጋ ይወስዳል.
    ///
    /// ይህ ዘዴ በዋነኝነት ጠብታ ውስጥ እሴቶች ውጭ መንቀሳቀስ የታሰበ ነው.
    /// ይልቅ በእጅ ዋጋ መጣል [`ManuallyDrop::drop`] መጠቀም, እናንተ ዋጋ ለመውሰድ ይህንን ዘዴ መጠቀም እና ይሁን የተፈለገውን መጠቀም ይችላሉ.
    ///
    /// በሚቻልበት ጊዜ በምትኩ [`into_inner`][`ManuallyDrop::into_inner`] ን መጠቀም ተመራጭ ነው ፣ ይህም የ `ManuallyDrop<T>` ይዘት ማባዛትን ይከለክላል።
    ///
    ///
    /// # Safety
    ///
    /// ይህ ተግባር የዚህን አጠቃቀም ሁኔታ ሳይለወጥ በመተው ተጨማሪ አጠቃቀምን ሳይጨምር በቅደም ተከተል የያዘውን እሴት ያወጣል ፡፡
    /// ይህ `ManuallyDrop` እንደገና ጥቅም አይደለም መሆኑን ማረጋገጥ የእርስዎ ኃላፊነት ነው.
    ///
    ///
    ///
    #[must_use = "if you don't need the value, you can use `ManuallyDrop::drop` instead"]
    #[stable(feature = "manually_drop_take", since = "1.42.0")]
    #[inline]
    pub unsafe fn take(slot: &mut ManuallyDrop<T>) -> T {
        // ደህንነት: እኛ ዋስትና ነው ማጣቀሻ, ከ በማንበብ ነው
        // ለንባብ ትክክለኛ መሆን
        unsafe { ptr::read(&slot.value) }
    }
}

impl<T: ?Sized> ManuallyDrop<T> {
    /// እራስዎ የያዘ ዋጋ ዝቅ.ይህ የያዘ እሴት ጠቋሚ ጋር [`ptr::drop_in_place`] በመጥራት ጋር በትክክል እኩል ነው.
    /// ስለሆነም ፣ የተያዘው እሴት የታሸገ መዋቅር ካልሆነ በስተቀር አጥፊው እሴቱን ሳይነካ በቦታው ይጠራል ፣ ስለሆነም የ [pinned] መረጃን በደህና ለመጣል ሊያገለግል ይችላል።
    ///
    /// እናንተ ዋጋ ባለቤትነት ካለዎት, በምትኩ [`ManuallyDrop::into_inner`] መጠቀም ይችላሉ.
    ///
    /// # Safety
    ///
    /// ይህ ተግባር የያዘ ዋጋ ያለውን destructor ይሰራል.
    /// በ destructor በራሱ የተደረጉ ለውጦች ይልቅ ሌላ, ትውስታ ሳይለወጥ ትተው እንዲሁ እስከ አጠናቃሪ በተመለከተ ነው እንደ ገና ዓይነት `T` ልክ ነው ትንሽ-ጥለት ተካሄደ ነው.
    ///
    ///
    /// ይሁን እንጂ, ይህ "zombie" ዋጋ ደህንነት ኮድ ተጋላጭ መሆን የለበትም, እና ይህን ተግባር ከአንድ ጊዜ በላይ ተብሎ መሆን የለበትም.
    /// (`drop` ምን ላይ የሚወሰን) ያልተገለጸ ባህሪ ሊያስከትል ይችላል, ይህም አንጠበጠቡ ከተሰጠ በኋላ ዋጋ መጠቀም, ወይም ዋጋ በርካታ ጊዜ መጣል.
    /// ይህ በመደበኛነት አይነት ስርዓት ከለከላቸው ነው, ነገር ግን `ManuallyDrop` ተጠቃሚዎች ወደ አጠናቃሪ ከ እርዳታ ያለ እነዚህን ዋስትናዎች መደገፍ አለበት.
    ///
    /// [pinned]: crate::pin
    ///
    ///
    ///
    ///
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[inline]
    pub unsafe fn drop(slot: &mut ManuallyDrop<T>) {
        // ደህንነት: እኛ አንድ ሊቀየሩ በዋቢነት ጠቁሟል ዋጋ የሚጥል ነው
        // ይህም ጽፏል ትክክለኛ ሆኖ የተረጋገጠ ነው.
        // `slot` እንደገና እንዳልወደቀ ማረጋገጥ የደዋዩ ነው።
        unsafe { ptr::drop_in_place(&mut slot.value) }
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> Deref for ManuallyDrop<T> {
    type Target = T;
    #[inline(always)]
    fn deref(&self) -> &T {
        &self.value
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> DerefMut for ManuallyDrop<T> {
    #[inline(always)]
    fn deref_mut(&mut self) -> &mut T {
        &mut self.value
    }
}