//! ማህደረ ትውስታን ለመቋቋም መሰረታዊ ተግባራት.
//!
//! ይህ ሞዱል, መጠንና ዓይነት አሰላለፍ የኢንዴክሱን በማስጀመር እና ትውስታ ማታለላቸውን የሚሆን ተግባር ይዟል.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::clone;
use crate::cmp;
use crate::fmt;
use crate::hash;
use crate::intrinsics;
use crate::marker::{Copy, DiscriminantKind, Sized};
use crate::ptr;

mod manually_drop;
#[stable(feature = "manually_drop", since = "1.20.0")]
pub use manually_drop::ManuallyDrop;

mod maybe_uninit;
#[stable(feature = "maybe_uninit", since = "1.36.0")]
pub use maybe_uninit::MaybeUninit;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::transmute;

/// በውስጡ destructor **እያሄደ ያለ ዋጋ ስለ ባለቤትነት እና "forgets"** ይወስዳል.
///
/// እንደ ክምር ትውስታ ወይም ፋይል እጀታ እንደ ዋጋ የሚያቀናብር ማንኛውም ሀብቶች, አንድ አይደረስበትም ሁኔታ ውስጥ ለዘላለም አልወጣ ይሆናል.ይሁን እንጂ ይህን ትውስታ ዘዴውን ትክክለኛ ይቆያል መሆኑን አያረጋግጥም.
///
/// * አንተ ትውስታ አያሳልፍም ከፈለጉ, [`Box::leak`] ተመልከት.
/// * እርስዎ ትውስታ አንድ ጥሬ ጠቋሚ ለማግኘት ከፈለጉ, [`Box::into_raw`] ተመልከት.
/// * አንተ በውስጡ destructor ሮጦ, በአግባቡ ዋጋ ቆሻሻን ማስወገድ ከፈለጉ, [`mem::drop`] ተመልከት.
///
/// # Safety
///
/// `forget` የ Rust ደህንነት ዋስትናዎች አጥፊዎች ሁል ጊዜ እንደሚሰሩ ዋስትና ስለማያካትት እንደ `unsafe` ምልክት አልተደረገም።
/// ለምሳሌ ፣ አንድ ፕሮግራም [`Rc`][rc] ን በመጠቀም የማጣቀሻ ዑደት መፍጠር ይችላል ፣ ወይም አጥፊዎችን ሳይሮጥ ለመውጣት [`process::exit`][exit] ይደውሉ።
/// በመሆኑም ደህና ኮድ ከ `mem::forget` መፍቀድ በመሰረቱ Rust የደህንነት ዋስትና አይለወጥም.
///
/// ይህ እንደ ማህደረ ትውስታ ወይም ብዙውን ጊዜ መጥፎ ነው I/O ነገሮችን እንደ ሀብቶች የሚያፈስ አለ.
/// አስፈላጊነት FFI ወይም አደገኛ ኮድ አንዳንድ ልዩ አጠቃቀም ጉዳዮች ውስጥ ይመጣል, ነገር ግን እንዲያውም ከዚያ, [`ManuallyDrop`] በተለምዶ ይመረጣል.
///
/// ዋጋን መርሳት ስለሚፈቀድ ፣ እርስዎ የሚጽፉት ማንኛውም የ `unsafe` ኮድ ለዚህ ዕድል መፍቀድ አለበት።አንድ እሴት ለመመለስ እና የደዋዩን የግድ ዋጋ ያለው destructor የሚሄዱ መጠበቅ አንችልም.
///
/// [rc]: ../../std/rc/struct.Rc.html
/// [exit]: ../../std/process/fn.exit.html
///
/// # Examples
///
/// የ‹`mem::forget`›ቀኖናዊ ደህንነቱ የተጠበቀ አጠቃቀም በ `Drop` trait የተተገበረውን የእሴት አጥፊን መሻገር ነው ፡፡ለምሳሌ ፣ ይህ `File` ን ያፈሳል ፣ ማለትም
/// ወደ ተለዋዋጭ የወሰዱትን ቦታ ግን ፈጽሞ የቅርብ የተነሳበትን ሥርዓት ሃብት መልሶ ይገባኛል:
///
/// ```no_run
/// use std::mem;
/// use std::fs::File;
///
/// let file = File::open("foo.txt").unwrap();
/// mem::forget(file);
/// ```
///
/// ከስር ሀብት ባለቤትነት ቀደም C ኮድ ወደ ጥሬ ፋይል ገላጭ በማስተላለፍ, ለምሳሌ Rust መካከል ኮድ ውጪ ተዛወርኩ ጊዜ ይህ ጠቃሚ ነው.
///
/// # `ManuallyDrop` ጋር ግንኙነት
///
/// `mem::forget` የ *ማህደረ ትውስታ* ባለቤትነትን ለማስተላለፍ ሊያገለግል የሚችል ቢሆንም ፣ ይህን ማድረጉ ለስህተት የተጋለጠ ነው።
/// [`ManuallyDrop`] በምትኩ ላይ መዋል አለበት.ለምሳሌ ይህንን ኮድ እንመልከት-
///
/// ```
/// use std::mem;
///
/// let mut v = vec![65, 122];
/// // የ `v` ን ይዘቶች በመጠቀም `String` ን ይገንቡ
/// let s = unsafe { String::from_raw_parts(v.as_mut_ptr(), v.len(), v.capacity()) };
/// // በውስጡ ትውስታ አሁን `s` የሚተዳደር ነው ምክንያቱም `v` አያሳልፍም
/// mem::forget(v);  // ስህተት ፣ ቁ ልክ ያልሆነ ስለሆነ ወደ ተግባር መተላለፍ የለበትም
/// assert_eq!(s, "Az");
/// // `s` በተዘዋዋሪ ተቋርጧል እና የማስታወስ deallocated ነው.
/// ```
///
/// ከላይ ምሳሌ ጋር ሁለት ጉዳዮች አሉ:
///
/// * በ `String` ግንባታ እና በ `mem::forget()` ጥሪ መካከል ተጨማሪ ኮድ ቢታከልበት በውስጡ አንድ panic ሁለት እጥፍ ነፃ ያስከትላል ፣ ምክንያቱም ተመሳሳይ ማህደረ ትውስታ በሁለቱም `v` እና `s` ይካሄዳል።
/// * `v.as_mut_ptr()` በመደወል እና `s` ወደ ውሂብ ባለቤትነት በማስተላለፍ በኋላ `v` ዋጋ ልክ ያልሆነ ነው.
/// አንድ እሴት ብቻ (ተዘዋውሮ አይደለም ይህም) `mem::forget` ተወስዷል እንኳ አንዳንድ ዓይነቶች ተንጠልጥለው ወይም ከአሁን በኋላ የተያዘ ጊዜ እነርሱ ልክ የሚያደርጉ ያላቸውን እሴቶች ላይ ጥብቅ መስፈርቶች አላቸው.
/// ዋጋቢስ እሴቶችን በማንኛውም መንገድ መጠቀምን ፣ ወደእነሱ ማስተላለፍን ወይም ከተግባሮች መመለስን ጨምሮ ፣ ያልተገለፀ ባህሪይ ነው እናም በአቀራባዩ የተሰጡትን ግምቶች ይሰብራል ፡፡
///
/// ወደ `ManuallyDrop` መቀየር ሁለቱንም ችግሮች ያስወግዳል-
///
/// ```
/// use std::mem::ManuallyDrop;
///
/// let v = vec![65, 122];
/// // እኛ በውስጡ ጥሬ ክፍሎች ወደ `v` መፈታታት በፊት እርግጠኛ ተቋርጧል ሊያገኙ አይደለም እናደርጋለን!
/////
/// let mut v = ManuallyDrop::new(v);
/// // አሁን, መፈታታት `v`.እነዚህ ክወናዎች panic, ስለዚህ ተሰርዞበት ሊኖር አይችልም አይችልም.
/// let (ptr, len, cap) = (v.as_mut_ptr(), v.len(), v.capacity());
/// // በመጨረሻም, አንድ `String` ለመገንባት.
/// let s = unsafe { String::from_raw_parts(ptr, len, cap) };
/// assert_eq!(s, "Az");
/// // `s` በተዘዋዋሪ ተቋርጧል እና የማስታወስ deallocated ነው.
/// ```
///
/// `ManuallyDrop` ሌላ ማንኛውንም ነገር ከማድረግዎ በፊት የ `v` አጥፊን እናሰናክላለን ምክንያቱም ድርብ-ነፃን በጥብቅ ይከላከላል ፡፡
/// `mem::forget()` ይህንን አይፈቅድም ምክንያቱም ክርክሩን ስለሚወስድ ከ `v` የምንፈልገውን ማንኛውንም ነገር ካወጣን በኋላ ብቻ እንድንደውል ያስገድደናል ፡፡
/// በ‹XXXXXXXXXXXXXXXXXXX ግንባታ እና ህብረቁምፊውን በመገንባት መካከል አንድ‹panic›ቢተዋወቅም (እንደሚታየው በኮዱ ውስጥ ሊከሰት አይችልም) ፣ ፍሰትን ያስከትላል እና እጥፍ ነፃ አይሆንም ፡፡
/// በሌላ አገላለጽ `ManuallyDrop` (ድርብ-) በመጣል ጎን ከመሳሳት ይልቅ በማፍሰሱ በኩል ይሳሳታል።
///
/// እንዲሁም `ManuallyDrop` የባለቤትነት መብቱን ወደ `s` ካስተላለፍን በኋላ ወደ "touch" `v` እንዳናደርግ ይከለክለናል-አጥፊውን ሳያስኬድ እሱን ለማስወገድ ከ `v` ጋር የመገናኘት የመጨረሻው እርምጃ ሙሉ በሙሉ ተቆጥቧል ፡፡
///
///
/// [`Box`]: ../../std/boxed/struct.Box.html
/// [`Box::leak`]: ../../std/boxed/struct.Box.html#method.leak
/// [`Box::into_raw`]: ../../std/boxed/struct.Box.html#method.into_raw
/// [`mem::drop`]: drop
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[rustc_const_stable(feature = "const_forget", since = "1.46.0")]
#[stable(feature = "rust1", since = "1.0.0")]
pub const fn forget<T>(t: T) {
    let _ = ManuallyDrop::new(t);
}

/// ልክ እንደ [`forget`] ፣ ግን ደግሞ ያልተመዘኑ እሴቶችን ይቀበላል።
///
/// የ `unsized_locals` ባህሪው ሲረጋጋ ይህ ተግባር እንዲወገድ የታሰበ shim ነው።
///
#[inline]
#[unstable(feature = "forget_unsized", issue = "none")]
pub fn forget_unsized<T: ?Sized>(t: T) {
    intrinsics::forget(t)
}

/// በባይቶች ውስጥ የአንድ ዓይነት መጠን ይመልሳል።
///
/// በይበልጥ ፣ ይህ የእቃ መጫኛ ንጣፎችን ጨምሮ ከእዚያ የንጥል ዓይነት ጋር በአንድ ድርድር ውስጥ በተከታታይ አካላት መካከል ባይትስ ማካካሻ ነው።
///
/// ስለዚህ ፣ ለማንኛውም ዓይነት `T` እና ርዝመት `n` ፣ `[T; n]` የ `n * size_of::<T>()` መጠን አለው።
///
/// በአጠቃላይ ፣ የአንድ ዓይነት መጠን በማጠናከሪያዎች ላይ የተረጋጋ አይደለም ፣ ግን እንደ ቅድመ-ቅጦች ያሉ የተወሰኑ ዓይነቶች ናቸው ፡፡
///
/// የሚከተለው ሰንጠረዥ ለቀዳሚዎች መጠኑን ይሰጣል ፡፡
///
/// ዓይነት |መጠን: :\<Type>()
/// ---- | ---------------
/// () |0 bool |1 u8 |1 u16 |2 u32 |4 u64 |8 u128 |16 i8 |1 i16 |2 i32 |4 i64 |8 i128 |16 f32 |4 f64 |8 ቻርጅ |4
///
/// በተጨማሪም `usize` እና `isize` ተመሳሳይ መጠን አላቸው ፡፡
///
/// `*const T`, `&T`, `Box<T>`, `Option<&T>` እና `Option<Box<T>>` ዓይነቶች ተመሳሳይ መጠን አላቸው ፡፡
/// `T` መጠን ካለው ፣ እነዚህ ሁሉ ዓይነቶች ከ‹XXXX›ጋር ተመሳሳይ መጠን አላቸው።
///
/// የአንድ ጠቋሚ ተለዋዋጭነት መጠኑን አይለውጠውም።እንደዚሁ `&T` እና `&mut T` ተመሳሳይ መጠን አላቸው ፡፡
/// እንደዚሁ ለ `*const T` እና `* mut T`።
///
/// # የ `#[repr(C)]` ንጥሎች መጠን
///
/// ለንጥሎች የ `C` ውክልና የተወሰነ አቀማመጥ አለው።
/// በዚህ አቀማመጥ ፣ ሁሉም መስኮች የተረጋጋ መጠን እስካላቸው ድረስ የእቃዎች መጠን እንዲሁ የተረጋጋ ነው።
///
/// ## የእቅዶች መጠን
///
/// ለ `structs` መጠኑ በሚከተለው ስልተ-ቀመር ይወሰናል።
///
/// ለእያንዳንዱ መስክ በአዋጅ ትዕዛዝ በታዘዘው መዋቅር ውስጥ
///
/// 1. የእርሻውን መጠን ያክሉ ፡፡
/// 2. የአሁኑን መጠን ወደ ቀጣዩ የመስክ ኤክስኤክስክስክስክስ ቅርብ ወደሆነው ብዙ ያሰባስቡ ፡፡
///
/// በመጨረሻም የህንፃውን መጠን ወደ ቅርብ ወደሆነው የ‹XXXX›ክብ ያዙ ፡፡
/// የመዋቅር አሰላለፍ አብዛኛውን ጊዜ ከሁሉም መስኮች ትልቁ አሰላለፍ ነው ፤ይህ በ `repr(align(N))` አጠቃቀም ሊለወጥ ይችላል።
///
/// ከኤክስኤክስክስክስክስክስክስክስክስ ዜሮዎች መጠን እስከ አንድ ባይት በመጠን አይመዘገቡም ፡፡
///
/// ## የኤንሞች መጠን
///
/// ከአድሎአዊነት ውጭ ሌላ መረጃ የማይይዙ Enum በተሰበሰበው መድረክ ላይ እንደ C enums ተመሳሳይ መጠን አላቸው ፡፡
///
/// ## የህብረቶች መጠን
///
/// የአንድነት መጠን ትልቁ የእርሻ መጠኑ ነው ፡፡
///
/// `C` በተለየ መልኩ, ወደ ዜሮ መጠን ያላቸው ማኅበራት መጠን አንድ ባይት ወደ ቅርቡ አይደለም.
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// // አንዳንድ primitives
/// assert_eq!(4, mem::size_of::<i32>());
/// assert_eq!(8, mem::size_of::<f64>());
/// assert_eq!(0, mem::size_of::<()>());
///
/// // አንዳንድ አደራደሮች
/// assert_eq!(8, mem::size_of::<[i32; 2]>());
/// assert_eq!(12, mem::size_of::<[i32; 3]>());
/// assert_eq!(0, mem::size_of::<[i32; 0]>());
///
///
/// // የጠቋሚ መጠን እኩልነት
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<*const i32>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Box<i32>>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Option<&i32>>());
/// assert_eq!(mem::size_of::<Box<i32>>(), mem::size_of::<Option<Box<i32>>>());
/// ```
///
/// `#[repr(C)]` ን በመጠቀም።
///
/// ```
/// use std::mem;
///
/// #[repr(C)]
/// struct FieldStruct {
///     first: u8,
///     second: u16,
///     third: u8
/// }
///
/// // የመጀመሪያው መስክ መጠኑ 1 ነው ፣ ስለሆነም በመጠን 1 ይጨምሩ ፡፡መጠን 1 ነው.
/// // የሁለተኛው መስክ አሰላለፍ 2 ነው ፣ ስለሆነም ለቅጥነት መጠን 1 ይጨምሩ።መጠን 2 ነው.
/// // ሁለተኛው መስክ መጠን እንዲሁ መጠን ወደ 2 መጨመር, 2 ነው.መጠኑ 4 ነው።
/// // ሦስተኛው መስክ አሰላለፍ እንዲሁ ድብዳብ ያህል መጠን 0 መጨመር, 1 ነው.መጠን 4 ነው.
/// // ሦስተኛው መስክ መጠን እንዲሁ መጠን 1 መጨመር, 1 ነው.መጠን 5 ነው.
/// // በመጨረሻም, struct ያለውን አሰላለፍ (በውስጡ መስኮች መካከል ትልቁ አሰላለፍ 2 ስለሆነ), ስለዚህ ድብዳብ ያህል መጠን ወደ 1 ማከል 2 ነው.
/// // መጠኑ 6 ነው።
/// assert_eq!(6, mem::size_of::<FieldStruct>());
///
/// #[repr(C)]
/// struct TupleStruct(u8, u16, u8);
///
/// // Tuple structs ተመሳሳይ ደንቦች ይከተላሉ.
/// assert_eq!(6, mem::size_of::<TupleStruct>());
///
/// // መስኮች ማስተካከሎች መጠን ዝቅ የሚችል መሆኑን ልብ ይበሉ.
/// // እኛ `second` በፊት `third` በማድረግ ሁለቱም ድብዳብ ባይት ማስወገድ ይችላሉ.
/// #[repr(C)]
/// struct FieldStructOptimized {
///     first: u8,
///     third: u8,
///     second: u16
/// }
///
/// assert_eq!(4, mem::size_of::<FieldStructOptimized>());
///
/// // ህብረት መጠን ትልቁ ሜዳ የሚያክል ነው.
/// #[repr(C)]
/// union ExampleUnion {
///     smaller: u8,
///     larger: u16
/// }
///
/// assert_eq!(2, mem::size_of::<ExampleUnion>());
/// ```
///
/// [alignment]: align_of
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_size_of", since = "1.32.0")]
pub const fn size_of<T>() -> usize {
    intrinsics::size_of::<T>()
}

/// በባይቶች ውስጥ የጠቆመውን እሴት መጠን ይመልሳል።
///
/// ይህ ብዙውን ጊዜ ከ `size_of::<T>()` ጋር ተመሳሳይ ነው።
/// ሆኖም ፣ `T`* * በቁጥር የማይታወቅ መጠን ሲኖረው ፣ ለምሳሌ ፣ አንድ ቁራጭ [`[T]`][slice] ወይም [trait object] ፣ ከዚያ `size_of_val` በተንቀሳቃሽ-የታወቀ መጠን ለማግኘት ሊያገለግል ይችላል።
///
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, mem::size_of_val(y));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
pub const fn size_of_val<T: ?Sized>(val: &T) -> usize {
    // ደህንነት `val` ማጣቀሻ ስለሆነ ትክክለኛ የጥሬ ጠቋሚ ነው
    unsafe { intrinsics::size_of_val(val) }
}

/// በባይቶች ውስጥ የጠቆመውን እሴት መጠን ይመልሳል።
///
/// ይህ ብዙውን ጊዜ ከ `size_of::<T>()` ጋር ተመሳሳይ ነው።ሆኖም ፣ `T`* * በቁጥር የማይታወቅ መጠን ሲኖረው ፣ ለምሳሌ ፣ አንድ ቁራጭ [`[T]`][slice] ወይም [trait object] ፣ ከዚያ `size_of_val_raw` ተለዋዋጭ-የታወቀውን መጠን ለማግኘት ሊያገለግል ይችላል።
///
/// # Safety
///
/// የሚከተሉት ሁኔታዎች መያዝ ከሆነ ይህ ተግባር ጥሪ ብቻ ደህና ነው:
///
/// - `T` `Sized` ከሆነ ይህ ተግባር ለመደወል ሁልጊዜ ደህና ነው።
/// - የ `T` ያልተለካው ጅራት ከሆነ:
///     - አንድ [slice] ፣ ከዚያ የተቆራረጠ ጅራቱ ርዝመት የተጀመረ ኢንቲጀር መሆን አለበት ፣ እና የ *አጠቃላይ እሴቱ* መጠን (ተለዋዋጭ ጅራት ርዝመት + ስታትስቲክስ መጠን ያለው ቅድመ ቅጥያ) በ `isize` ውስጥ መመጣጠን አለበት።
///     - አንድ [trait object] ፣ ከዚያ የጠቋሚው ተቆጣጣሪ ክፍል በማያስፈልግ ማስገደድ የተገኘውን ትክክለኛ የገቢ ምንጭ ማመልከት አለበት ፣ እና የ *አጠቃላይ እሴት* መጠን (ተለዋዋጭ ጅራት ርዝመት + እና መጠናዊ መጠን ያለው ቅድመ ቅጥያ) በ `isize` ውስጥ ሊገጥም ይገባል።
///
///     - አንድ (unstable) [extern type] ፣ ከዚያ ይህ ተግባር ሁል ጊዜ ለመጥራት ደህና ነው ፣ ግን የውጪው ዓይነት አቀማመጥ ስለማይታወቅ panic ወይም አለበለዚያ የተሳሳተ ዋጋን ይመልስ።
///     የውጭ ዓይነት ጭራ ካለው ዓይነት ጋር በማጣቀሻ ላይ ይህ እንደ [`size_of_val`] ተመሳሳይ ባህሪ ነው።
///     - አለበለዚያ, ይህ conservatively ይህን ተግባር ለመጥራት አልተፈቀደለትም.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, unsafe { mem::size_of_val_raw(y) });
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_size_of_val_raw", issue = "46571")]
pub const unsafe fn size_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // ደህንነት-ደዋዩ ትክክለኛ ጥሬ ጠቋሚ ማቅረብ አለበት
    unsafe { intrinsics::size_of_val(val) }
}

/// የ [ABI] ን የሚፈለግ የዝቅተኛ አሰላለፍ ይመልሳል።
///
/// ለ `T` ዓይነት እሴት የሚጠቅስ እያንዳንዱ የዚህ ቁጥር ብዙ መሆን አለበት።
///
/// ይህ ለግንባታ መስኮች ጥቅም ላይ የዋለው አሰላለፍ ነው።ከተመረጠው አሰላለፍ ያነሰ ሊሆን ይችላል።
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of::<i32>());
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of` instead", since = "1.2.0")]
pub fn min_align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// ኤክስኤክስኤክስ የሚያመለክተው የዋጋ ዓይነት የ [ABI] ተፈላጊውን ዝቅተኛ አሰላለፍ ይመልሳል።
///
/// ለ `T` ዓይነት እሴት የሚጠቅስ እያንዳንዱ የዚህ ቁጥር ብዙ መሆን አለበት።
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of_val` instead", since = "1.2.0")]
pub fn min_align_of_val<T: ?Sized>(val: &T) -> usize {
    // ደህንነት-ቫል ማጣቀሻ ስለሆነ ትክክለኛ ጥሬ አመልካች ነው
    unsafe { intrinsics::min_align_of_val(val) }
}

/// የ [ABI] ን የሚፈለግ የዝቅተኛ አሰላለፍ ይመልሳል።
///
/// ለ `T` ዓይነት እሴት የሚጠቅስ እያንዳንዱ የዚህ ቁጥር ብዙ መሆን አለበት።
///
/// ይህ ለግንባታ መስኮች ጥቅም ላይ የዋለው አሰላለፍ ነው።ከተመረጠው አሰላለፍ ያነሰ ሊሆን ይችላል።
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of::<i32>());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_align_of", since = "1.32.0")]
pub const fn align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// ኤክስኤክስኤክስ የሚያመለክተው የዋጋ ዓይነት የ [ABI] ተፈላጊውን ዝቅተኛ አሰላለፍ ይመልሳል።
///
/// ለ `T` ዓይነት እሴት የሚጠቅስ እያንዳንዱ የዚህ ቁጥር ብዙ መሆን አለበት።
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
#[allow(deprecated)]
pub const fn align_of_val<T: ?Sized>(val: &T) -> usize {
    // ደህንነት-ቫል ማጣቀሻ ስለሆነ ትክክለኛ ጥሬ አመልካች ነው
    unsafe { intrinsics::min_align_of_val(val) }
}

/// ኤክስኤክስኤክስ የሚያመለክተው የዋጋ ዓይነት የ [ABI] ተፈላጊውን ዝቅተኛ አሰላለፍ ይመልሳል።
///
/// ለ `T` ዓይነት እሴት የሚጠቅስ እያንዳንዱ የዚህ ቁጥር ብዙ መሆን አለበት።
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Safety
///
/// የሚከተሉት ሁኔታዎች መያዝ ከሆነ ይህ ተግባር ጥሪ ብቻ ደህና ነው:
///
/// - `T` `Sized` ከሆነ ይህ ተግባር ለመደወል ሁልጊዜ ደህና ነው።
/// - የ `T` ያልተለካው ጅራት ከሆነ:
///     - አንድ [slice] ፣ ከዚያ የተቆራረጠ ጅራቱ ርዝመት የተጀመረ ኢንቲጀር መሆን አለበት ፣ እና የ *አጠቃላይ እሴቱ* መጠን (ተለዋዋጭ ጅራት ርዝመት + ስታትስቲክስ መጠን ያለው ቅድመ ቅጥያ) በ `isize` ውስጥ መመጣጠን አለበት።
///     - አንድ [trait object] ፣ ከዚያ የጠቋሚው ተቆጣጣሪ ክፍል በማያስፈልግ ማስገደድ የተገኘውን ትክክለኛ የገቢ ምንጭ ማመልከት አለበት ፣ እና የ *አጠቃላይ እሴት* መጠን (ተለዋዋጭ ጅራት ርዝመት + እና መጠናዊ መጠን ያለው ቅድመ ቅጥያ) በ `isize` ውስጥ ሊገጥም ይገባል።
///
///     - አንድ (unstable) [extern type] ፣ ከዚያ ይህ ተግባር ሁል ጊዜ ለመጥራት ደህና ነው ፣ ግን የውጪው ዓይነት አቀማመጥ ስለማይታወቅ panic ወይም አለበለዚያ የተሳሳተ ዋጋን ይመልስ።
///     የውጭ ዓይነት ጭራ ካለው ዓይነት ጋር በማጣቀሻ ላይ ይህ እንደ [`align_of_val`] ተመሳሳይ ባህሪ ነው።
///     - አለበለዚያ, ይህ conservatively ይህን ተግባር ለመጥራት አልተፈቀደለትም.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, unsafe { mem::align_of_val_raw(&5i32) });
/// ```
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_align_of_val_raw", issue = "46571")]
pub const unsafe fn align_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // ደህንነት-ደዋዩ ትክክለኛ ጥሬ ጠቋሚ ማቅረብ አለበት
    unsafe { intrinsics::min_align_of_val(val) }
}

/// የ `T` ዓይነት እሴቶችን ከወደቁ `true` ን ይመልሳል።
///
/// ይህ ሙሉ በሙሉ የማመቻቸት ፍንጭ ነው ፣ እናም በወግ ሊተገበር ይችላል-
/// በትክክል መጣል ለማያስፈልጋቸው ዓይነቶች `true` ን ሊመልስ ይችላል።
/// እንደዚህ ሁልጊዜ `true` ን መመለስ የዚህ ተግባር ትክክለኛ ትግበራ ይሆናል ፡፡ሆኖም ይህ ተግባር `false` ን በትክክል ከመለሰ ታዲያ እርግጠኛ መሆን ይችላሉ `T` ን መጣል ምንም የጎንዮሽ ጉዳት የለውም።
///
/// እንደ ስብስቦች ያሉ ነገሮች ዝቅተኛ ደረጃ ትግበራዎች መረጃዎቻቸውን በእጅ መጣል የሚያስፈልጋቸው ሲደመሰሱ ሁሉንም ይዘቶች ለመጣል አላስፈላጊ ሙከራን ለማስወገድ ይህንን ተግባር መጠቀም አለባቸው ፡፡
///
/// ይህ በመልቀቂያ ግንባታዎች ላይ ለውጥ ማምጣት ላይችል ይችላል (የጎንዮሽ ጉዳቶች የሌሉት ዑደት በቀላሉ የሚታወቅበት እና የሚጠፋበት) ፣ ግን ብዙውን ጊዜ ለማረም ግንባታዎች ትልቅ ድል ነው ፡፡
///
/// [`drop_in_place`] ይህን ቼክ ቀድሞውኑ እንደሚያከናውን ልብ ይበሉ ፣ ስለሆነም የሥራ ጫናዎ ወደ ጥቂት የ [`drop_in_place`] ጥሪዎች ሊቀንስ የሚችል ከሆነ ይህን በመጠቀም አላስፈላጊ ነው።
/// በተለይም [`drop_in_place`] ቁርጥራጭ ማድረግ እንደሚችሉ ያስተውሉ እና ያ ለሁሉም እሴቶች አንድ ነጠላ_የሚያስፈልገው ፍተሻ ያደርጋል።
///
/// እንደ Vec ያሉ አይነቶች ስለሆነም `needs_drop` ን በግልጽ ሳይጠቀሙ `drop_in_place(&mut self[..])` ብቻ ናቸው ፡፡
/// እንደ [`HashMap`] ያሉ ዓይነቶች ፣ በተቃራኒው እሴቶችን አንድ በአንድ መጣል አለባቸው እና ይህን ኤፒአይ መጠቀም አለባቸው።
///
/// [`drop_in_place`]: crate::ptr::drop_in_place
/// [`HashMap`]: ../../std/collections/struct.HashMap.html
///
/// # Examples
///
/// አንድ ስብስብ `needs_drop` ን እንዴት እንደሚጠቀምበት ምሳሌ ይኸውልዎት-
///
/// ```
/// use std::{mem, ptr};
///
/// pub struct MyCollection<T> {
/// #   data: [T; 1],
///     /* ... */
/// }
/// # impl<T> MyCollection<T> {
/// #   fn iter_mut(&mut self) -> &mut [T] { &mut self.data }
/// #   fn free_buffer(&mut self) {}
/// # }
///
/// impl<T> Drop for MyCollection<T> {
///     fn drop(&mut self) {
///         unsafe {
///             // ውሂብ ጣል
///             if mem::needs_drop::<T>() {
///                 for x in self.iter_mut() {
///                     ptr::drop_in_place(x);
///                 }
///             }
///             self.free_buffer();
///         }
///     }
/// }
/// ```
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "needs_drop", since = "1.21.0")]
#[rustc_const_stable(feature = "const_needs_drop", since = "1.36.0")]
#[rustc_diagnostic_item = "needs_drop"]
pub const fn needs_drop<T>() -> bool {
    intrinsics::needs_drop::<T>()
}

/// በሁሉም ዜሮ ባይት-ንድፍ የተወከለውን ዓይነት `T` ዋጋ ይመልሳል።
///
/// ይህ ማለት ፣ ለምሳሌ ፣ በ `(u8, u16)` ውስጥ ያለው ቀዘፋ ባይት የግድ ዜሮ አይደለም።
///
/// ሁሉም ዜሮ ባይት-ጥለት የአንዳንድ ዓይነት `T` ትክክለኛ ዋጋን እንደሚወክል ምንም ማረጋገጫ የለም።
/// ለምሳሌ ፣ የሁሉም-ዜሮ ባይት ንድፍ ለማመሳከሪያ ዓይነቶች (`&T` ፣ `&mut T`) እና ለተግባሮች ጠቋሚዎች ትክክለኛ እሴት አይደለም ፡፡
/// በእንደዚህ ዓይነቶቹ ዓይነቶች ላይ `zeroed` ን መጠቀም ወዲያውኑ [undefined behavior][ub] ን ያስከትላል ምክንያቱም [the Rust compiler assumes][inv] እንደ ተነሳሽነት በሚቆጥረው ተለዋዋጭ ውስጥ ሁል ጊዜ ትክክለኛ ዋጋ ያለው ነው ፡፡
///
///
/// ይህ ከ [`MaybeUninit::zeroed().assume_init()`][zeroed] ጋር ተመሳሳይ ውጤት አለው።
/// ለ FFI አንዳንድ ጊዜ ጠቃሚ ነው ፣ ግን በአጠቃላይ መወገድ አለበት።
///
/// [zeroed]: MaybeUninit::zeroed
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [inv]: MaybeUninit#initialization-invariant
///
/// # Examples
///
/// የዚህ ተግባር ትክክለኛ አጠቃቀም-ኢንቲጀር ከዜሮ ጋር ማስጀመር።
///
/// ```
/// use std::mem;
///
/// let x: i32 = unsafe { mem::zeroed() };
/// assert_eq!(0, x);
/// ```
///
/// የዚህ ተግባር *ትክክል ያልሆነ* አጠቃቀም-ከዜሮ ጋር ማጣቀሻን ማስጀመር ፡፡
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem;
///
/// let _x: &i32 = unsafe { mem::zeroed() }; // ያልተገለጸ ባህሪ!
/// let _y: fn() = unsafe { mem::zeroed() }; // እንደገና!
/// ```
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_zeroed"]
pub unsafe fn zeroed<T>() -> T {
    // ደህንነት ደዋዩ ዜሮ የሆነ እሴት ለ `T` ዋጋ ያለው መሆኑን ማረጋገጥ አለበት ፡፡
    unsafe {
        intrinsics::assert_zero_valid::<T>();
        MaybeUninit::zeroed().assume_init()
    }
}

/// የ Rust ን መደበኛ የማስታወሻ-ጅምር ቼኮችን በ‹XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX value {0} ላይ የተለጠፈ]
///
/// **ይህ ተግባር ተቋርጧል።** በምትኩ [`MaybeUninit<T>`] ን ይጠቀሙ።
///
/// የመቀነስ ምክንያት በመሠረቱ ተግባሩ በትክክል ጥቅም ላይ መዋል አለመቻሉ ነው-እንደ [`MaybeUninit::uninit().assume_init()`][uninit] ተመሳሳይ ውጤት አለው ፡፡
///
/// [`assume_init` documentation][assume_init] እንደሚያብራራው [the Rust compiler assumes][inv] እሴቶች በትክክል ተጀምረዋል ፡፡
/// በዚህ ምክንያት ፣ መደወል ለምሳሌ
/// `mem::uninitialized::<bool>()` በእርግጠኝነት `true` ወይም `false` ያልሆነ `bool` ን ለመመለስ ወዲያውኑ ያልተገለጸ ባህሪን ያስከትላል ፡፡
/// በጣም የከፋ ፣ በእውነቱ እዚህ ላይ እንደተመለሰው በእውነቱ ያልተነገረ ማህደረ ትውስታ ልዩ ነው አሰባሳቢው የተወሰነ ዋጋ እንደሌለው ያውቃል ፡፡
/// ይህ ተለዋዋጭ ምንም እንኳን ኢንቲጀር (ኢንቲጀር) አይነት ቢኖረውም እንኳ ተለዋዋጭ በሆነ ውስጥ ያልታወቁ መረጃዎች መኖራቸው ያልተገለጸ ባህሪ ያደርገዋል ፡፡
/// (ልብ-ወለድ ቁጥር ቁጥሮች ዙሪያ ያሉ ሕጎች ገና ያልተጠናቀቁ መሆናቸውን ልብ ይበሉ ፣ ግን እስከሚጠናቀቁ ድረስ እነሱን ማስወገድ ተገቢ ነው ፡፡)
///
/// [uninit]: MaybeUninit::uninit
/// [assume_init]: MaybeUninit::assume_init
/// [inv]: MaybeUninit#initialization-invariant
///
///
///
///
///
#[inline(always)]
#[rustc_deprecated(since = "1.39.0", reason = "use `mem::MaybeUninit` instead")]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_uninitialized"]
pub unsafe fn uninitialized<T>() -> T {
    // ደህንነት-ደዋዩ ያልተነገረ እሴት ለ `T` ዋጋ ያለው መሆኑን ማረጋገጥ አለበት ፡፡
    unsafe {
        intrinsics::assert_uninit_valid::<T>();
        MaybeUninit::uninit().assume_init()
    }
}

/// እሴቶቹን በአንዱ ላይ ሳይነኩ በሁለት ሊለወጡ በሚችሉ ቦታዎች ይለዋወጣል።
///
/// * በነባሪ ወይም በደሚ እሴት ለመለዋወጥ ከፈለጉ [`take`] ን ይመልከቱ።
/// * ካለፈው እሴት ጋር መለዋወጥ ከፈለጉ የድሮውን እሴት ይመልሱ ፣ [`replace`] ን ይመልከቱ።
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// let mut x = 5;
/// let mut y = 42;
///
/// mem::swap(&mut x, &mut y);
///
/// assert_eq!(42, x);
/// assert_eq!(5, y);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn swap<T>(x: &mut T, y: &mut T) {
    // ደህንነት-ጥሬ አመላካቾች ሁሉንም ከሚያረካቸው ደህንነታቸው ከሚለወጡ ተለዋዋጭ ማጣቀሻዎች ተፈጥረዋል
    // በ `ptr::swap_nonoverlapping_one` ላይ ገደቦች
    unsafe {
        ptr::swap_nonoverlapping_one(x, y);
    }
}

/// የቀደመውን `dest` እሴት በመመለስ `dest` ን በነባሪ የ `T` እሴት ይተካል።
///
/// * የሁለት ተለዋዋጮችን እሴቶች ለመተካት ከፈለጉ [`swap`] ን ይመልከቱ።
/// * በነባሪው እሴት ምትክ በተላለፈው እሴት መተካት ከፈለጉ [`replace`] ን ይመልከቱ።
///
/// # Examples
///
/// ቀላል ምሳሌ
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::take(&mut v);
/// assert_eq!(vec![1, 2], old_v);
/// assert!(v.is_empty());
/// ```
///
/// `take` በ‹XXXXXXXXXXXXXXXXXXXXXXXXXX/XXXXXXXXXXXXXXXXXX ዋጋ ጋር በመተካት የህንፃ መስክን በባለቤትነት መውሰድ ይፈቅዳል ፡፡
/// ያለ `take` እንደዚህ ያሉ ጉዳዮችን ሊያጋጥሙ ይችላሉ-
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let buf = self.buf;
///         self.buf = Vec::new();
///         buf
///     }
/// }
/// ```
///
/// `T` የግድ [`Clone`] ን እንደማይተገብር ልብ ይበሉ ፣ ስለሆነም `self.buf` ን እንኳን በአንድ ላይ ማያያዝ እና ዳግም ማስጀመር አይችልም።
/// ግን `take` እንዲመለስ ለማስቻል የ `self.buf` ን የመጀመሪያ እሴት ከ `self` ለማለያየት ሊያገለግል ይችላል-
///
///
/// ```
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         mem::take(&mut self.buf)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf.len(), 2);
///
/// assert_eq!(buffer.get_and_reset(), vec![0, 1]);
/// assert_eq!(buffer.buf.len(), 0);
/// ```
#[inline]
#[stable(feature = "mem_take", since = "1.40.0")]
pub fn take<T: Default>(dest: &mut T) -> T {
    replace(dest, T::default())
}

/// የቀደመውን `dest` እሴት በመመለስ `src` ን ወደ ተጠቀሰው `dest` ይዛወራል።
///
/// ሁለቱም እሴት አልተቀነሰም ፡፡
///
/// * የሁለት ተለዋዋጮችን እሴቶች ለመተካት ከፈለጉ [`swap`] ን ይመልከቱ።
/// * በነባሪ እሴት መተካት ከፈለጉ [`take`] ን ይመልከቱ።
///
/// # Examples
///
/// ቀላል ምሳሌ
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::replace(&mut v, vec![3, 4, 5]);
/// assert_eq!(vec![1, 2], old_v);
/// assert_eq!(vec![3, 4, 5], v);
/// ```
///
/// `replace` የመዋቅር መስክን በሌላ እሴት በመተካት መጠቀምን ይፈቅዳል።
/// ያለ `replace` እንደዚህ ያሉ ጉዳዮችን ሊያጋጥሙ ይችላሉ-
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let t = self.buf[i];
///         self.buf[i] = v;
///         t
///     }
/// }
/// ```
///
/// `T` [`Clone`] ን በትክክል ተግባራዊ እንደማያደርግ ልብ ይበሉ ፣ ስለሆነም እንቅስቃሴውን ለማስቀረት እንኳን `self.buf[i]` ን እንኳን ማገናኘት አንችልም።
/// ነገር ግን `replace` በዚያ መረጃ ጠቋሚ ላይ የመጀመሪያውን እሴት ከ `self` ለማለያየት ሊያገለግል ይችላል ፣ ይህም እንዲመለስ ያስችለዋል
///
///
/// ```
/// # #![allow(dead_code)]
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         mem::replace(&mut self.buf[i], v)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf[0], 0);
///
/// assert_eq!(buffer.replace_index(0, 2), 0);
/// assert_eq!(buffer.buf[0], 2);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[must_use = "if you don't need the old value, you can just assign the new value directly"]
pub fn replace<T>(dest: &mut T, src: T) -> T {
    // ደህንነት: ከ `dest` እናነባለን ግን በቀጥታ ከዚያ በኋላ በቀጥታ `src` ን ይፃፉ ፣
    // አሮጌ እሴት አልተባዛም ፡፡
    // ምንም ነገር አልተጣለም እዚህ ምንም የለም panic።
    unsafe {
        let result = ptr::read(dest);
        ptr::write(dest, src);
        result
    }
}

/// የአንድ እሴት መወገድ።
///
/// ይህ የክርክሩ አተገባበር [`Drop`][drop] ን በመጥራት ያደርገዋል ፡፡
///
/// `Copy` ን ለሚተገብሩ ዓይነቶች ይህ ምንም ውጤታማ አያደርግም ፣ ለምሳሌ
/// integers.
/// እንደነዚህ ዓይነቶቹ እሴቶች ይገለበጣሉ እና _then_ ወደ ተግባሩ ተወስደዋል ፣ ስለሆነም እሴቱ ከዚህ ተግባር ጥሪ በኋላ ይቀጥላል።
///
///
/// ይህ ተግባር አስማት አይደለም;ቃል በቃል እንደሚተረጎም ነው
///
/// ```
/// pub fn drop<T>(_x: T) { }
/// ```
///
/// `_x` ወደ ተግባር ስለሚወሰድ ተግባሩ ከመመለሱ በፊት በራስ-ሰር ይጣላል ፡፡
///
/// [drop]: Drop
///
/// # Examples
///
/// መሠረታዊ አጠቃቀም
///
/// ```
/// let v = vec![1, 2, 3];
///
/// drop(v); // በግልጽ የ vector ጣል
/// ```
///
/// [`RefCell`] በወቅቱ የብድር ደንቦችን ስለሚያከብር `drop` የ [`RefCell`] ብድር ሊለቅ ይችላል-
///
/// ```
/// use std::cell::RefCell;
///
/// let x = RefCell::new(1);
///
/// let mut mutable_borrow = x.borrow_mut();
/// *mutable_borrow = 1;
///
/// drop(mutable_borrow); // በዚህ ማስገቢያ ላይ ሊቀየሩ ቢዋስ እንደማይለቁ
///
/// let borrow = x.borrow();
/// println!("{}", *borrow);
/// ```
///
/// [`Copy`] ን የሚተገብሩ ውህዶች እና ሌሎች ዓይነቶች በ `drop` ተጽዕኖ አይኖራቸውም።
///
/// ```
/// #[derive(Copy, Clone)]
/// struct Foo(u8);
///
/// let x = 1;
/// let y = Foo(2);
/// drop(x); // `x` ቅጂ ተንቀሳቅሷል እና ተቋርጧል ነው
/// drop(y); // የ `y` ቅጅ ተንቀሳቅሷል እና ተጥሏል
///
/// println!("x: {}, y: {}", x, y.0); // አሁንም ይገኛሉ
/// ```
///
/// [`RefCell`]: crate::cell::RefCell
///
#[doc(alias = "delete")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn drop<T>(_x: T) {}

/// `src` ን እንደ `&U` ዓይነት ይተረጉመዋል ፣ እና ከዚያ የያዘውን እሴት ሳይያንቀሳቅሱ `src` ን ያነባል።
///
/// ይህ ተግባር ጠቋሚው `src` `&T` ን ወደ `&U` በማስተላለፍ እና ከዚያ `&U` ን በማንበብ ጠቋሚው `src` ለ [`size_of::<U>`][size_of] ባይት ልክ ነው ብሎ ይገምታል (ይህ `&U` ከ `&T` የበለጠ ጥብቅ የማጣሪያ መስፈርቶችን በሚያደርግበት ጊዜ እንኳን በትክክል በሚከናወን መንገድ ካልሆነ በስተቀር)።
/// እንዲሁም ከ `src` ከመነሳት ይልቅ በውስጡ ያለውን እሴት ቅጂ ደህንነቱ በተጠበቀ ሁኔታ ይፈጥራል።
///
/// `T` እና `U` የተለያዩ መጠኖች ካሏቸው የስብስብ ጊዜ ስህተት አይደለም ፣ ግን `T` እና `U` ተመሳሳይ መጠን ያላቸውን ይህንን ተግባር ብቻ ለመጥራት በጣም ይበረታታል ፡፡`U` ከ `T` የበለጠ ከሆነ ይህ ተግባር [undefined behavior][ub] ን ያስነሳል።
///
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// #[repr(packed)]
/// struct Foo {
///     bar: u8,
/// }
///
/// let foo_array = [10u8];
///
/// unsafe {
///     // መረጃውን ከ 'foo_array' ገልብጠው እንደ 'Foo' አድርገው ይያዙት
///     let mut foo_struct: Foo = mem::transmute_copy(&foo_array);
///     assert_eq!(foo_struct.bar, 10);
///
///     // የ ተቀድቷል ውሂብ ለመቀየር
///     foo_struct.bar = 20;
///     assert_eq!(foo_struct.bar, 20);
/// }
///
/// // 'foo_array' ይዘቶች ተቀይረዋል አይገባም
/// assert_eq!(foo_array, [10]);
/// ```
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_transmute_copy", issue = "83165")]
pub const unsafe fn transmute_copy<T, U>(src: &T) -> U {
    // ዩ ከፍ ያለ አሰላለፍ መስፈርት ካለው ፣ src በተገቢው ሁኔታ ላይመሳሰል ይችላል።
    if align_of::<U>() > align_of::<T>() {
        // ደህንነት `src` ለንባብ ዋጋ ያለው ዋስትና ያለው ማጣቀሻ ነው ፡፡
        // ደዋዩ ትክክለኛውን የመተላለፍ ደህንነቱ የተጠበቀ መሆኑን ማረጋገጥ አለበት ፡፡
        unsafe { ptr::read_unaligned(src as *const T as *const U) }
    } else {
        // ደህንነት `src` ለንባብ ዋጋ ያለው ዋስትና ያለው ማጣቀሻ ነው ፡፡
        // `src as *const U` በትክክል መጣጣሙን አሁን ፈትሸናል።
        // ደዋዩ ትክክለኛውን የመተላለፍ ደህንነቱ የተጠበቀ መሆኑን ማረጋገጥ አለበት ፡፡
        unsafe { ptr::read(src as *const T as *const U) }
    }
}

/// ግልጽ ያልሆነ ዓይነት የአንድን ሰው አድልኦ የሚያመለክት ፡፡
///
/// ለበለጠ መረጃ በዚህ ሞጁል ውስጥ የ [`discriminant`] ተግባርን ይመልከቱ።
#[stable(feature = "discriminant_value", since = "1.21.0")]
pub struct Discriminant<T>(<T as DiscriminantKind>::Discriminant);

// N.B. እነዚህ የ trait ትግበራዎች ሊገኙ አይችሉም ምክንያቱም በቲ ላይ ምንም ወሰን አንፈልግም ፡፡

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> Copy for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> clone::Clone for Discriminant<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::PartialEq for Discriminant<T> {
    fn eq(&self, rhs: &Self) -> bool {
        self.0 == rhs.0
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::Eq for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> hash::Hash for Discriminant<T> {
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.0.hash(state);
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> fmt::Debug for Discriminant<T> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_tuple("Discriminant").field(&self.0).finish()
    }
}

/// በ‹XXXX›ውስጥ ያለውን የ enum ተለዋጭ ልዩ ዋጋን ይመልሳል።
///
/// ኤክስኤክስኤክስ ኤንኤም ካልሆነ ፣ ይህንን ተግባር መጥራት ያልተገለፀ ባህሪን አያመጣም ፣ ግን የመመለሻው ዋጋ አልተገለጸም።
///
///
/// # Stability
///
/// የኤንዩም ልዩነት አድልዖው የግለሰቦቹ ትርጉም ከተለወጠ ሊለወጥ ይችላል ፡፡
/// የአንድ የተወሰነ ልዩነት አድልዎ ከተመሳሳዩ አሰባሳቢ ጋር በማጠናቀር መካከል አይቀየርም።
///
/// # Examples
///
/// ትክክለኛውን መረጃ ከግምት ውስጥ ሳያስገባ ይህ መረጃን የሚያጓጉዙ መረጃዎችን ለማነፃፀር ሊያገለግል ይችላል-
///
/// ```
/// use std::mem;
///
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::discriminant(&Foo::A("bar")), mem::discriminant(&Foo::A("baz")));
/// assert_eq!(mem::discriminant(&Foo::B(1)), mem::discriminant(&Foo::B(2)));
/// assert_ne!(mem::discriminant(&Foo::B(3)), mem::discriminant(&Foo::C(3)));
/// ```
///
#[stable(feature = "discriminant_value", since = "1.21.0")]
#[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
pub const fn discriminant<T>(v: &T) -> Discriminant<T> {
    Discriminant(intrinsics::discriminant_value(v))
}

/// በኤንኤም `T` አይነት ውስጥ የአይነቶች ብዛት ይመልሳል።
///
/// ኤክስኤክስኤክስ ኤንኤም ካልሆነ ፣ ይህንን ተግባር መጥራት ያልተገለፀ ባህሪን አያመጣም ፣ ግን የመመለሻው ዋጋ አልተገለጸም።
/// እኩል ፣ `T` ከ `usize::MAX` የበለጠ ብዛት ያላቸው ኤንዩም ከሆነ የመመለሻው ዋጋ አልተገለጸም።
/// የማይኖሩ ተለዋጮች ይቆጠራሉ ፡፡
///
/// # Examples
///
/// ```
/// # #![feature(never_type)]
/// # #![feature(variant_count)]
///
/// use std::mem;
///
/// enum Void {}
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::variant_count::<Void>(), 0);
/// assert_eq!(mem::variant_count::<Foo>(), 3);
///
/// assert_eq!(mem::variant_count::<Option<!>>(), 2);
/// assert_eq!(mem::variant_count::<Result<!, !>>(), 2);
/// ```
#[inline(always)]
#[unstable(feature = "variant_count", issue = "73662")]
#[rustc_const_unstable(feature = "variant_count", issue = "73662")]
pub const fn variant_count<T>() -> usize {
    intrinsics::variant_count::<T>()
}