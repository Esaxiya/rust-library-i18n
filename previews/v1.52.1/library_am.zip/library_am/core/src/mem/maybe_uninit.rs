use crate::any::type_name;
use crate::fmt;
use crate::intrinsics;
use crate::mem::ManuallyDrop;
use crate::ptr;

/// አንድ መጠቅለያ አይነት `T` መካከል uninitialized አብነቶችን ለመገንባት.
///
/// # ማስጀመር invariant
///
/// የ አጠናቃሪ, በአጠቃላይ ውስጥ አንድ ተለዋዋጭ በትክክል ተለዋዋጭ ያለው ዓይነት መስፈርቶች መሠረት አልተነሳም ነው ይገምታል.ለምሳሌ ያህል, የማጣቀሻ አይነት ተለዋዋጭ የሚጣጣም መሆን አለበት እና አልቦ ያልኾነ.
/// ይህ *ሁልጊዜ* እንኳ ያልተጠበቀ ኮድ ውስጥ ከተላለፈው መሆን ያለበት አንድ invariant ነው.
/// በዚህም, የማጣቀሻ አይነት ተለዋዋጭ ዜሮ-በማስጀመር ቅጽበታዊ [undefined behavior][ub], የማጣቀሻ መዳረሻ ማህደረ ትውስታ ጥቅም ላይ እንደሆነ ምንም ያስከትላል:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: &i32 = unsafe { mem::zeroed() }; // ያልተገለጸ ባህሪ!⚠️
/// // `MaybeUninit<&i32>` ጋር ተመጣጣኝ ኮድ:
/// let x: &i32 = unsafe { MaybeUninit::zeroed().assume_init() }; // ያልተገለጸ ባህሪ!⚠️
/// ```
///
/// ይህም እንደ አሂድ-ጊዜ ቼኮች eliding እና `enum` አቀማመጥ ሲያመቻቹ እንደ የተለያዩ ማሳደጊያዎች, ለ አጠናቃሪ መጠቀሚያ ነው.
///
/// አንድ `bool` ሁልጊዜ `true` ወይም `false` መሆን አለበት ሳለ በተመሳሳይም, ሙሉ በሙሉ uninitialized ትውስታ, ማንኛውም ይዘት ሊኖረው ይችላል.በመሆኑም, አንድ uninitialized `bool` መፍጠር ያልተገለጸ ባህሪ ነው:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let b: bool = unsafe { mem::uninitialized() }; // ያልተገለጸ ባህሪ!⚠️
/// // `MaybeUninit<bool>` ጋር ተመጣጣኝ ኮድ:
/// let b: bool = unsafe { MaybeUninit::uninit().assume_init() }; // ያልተገለጸ ባህሪ!⚠️
/// ```
///
/// በተጨማሪም ፣ ያልታወቀ ማህደረ ትውስታ ቋሚ እሴት ("fixed" ትርጉም "it won't change without being written to") ስለሌለው ልዩ ነው።ተመሳሳይ uninitialized ባይት በርካታ ጊዜ በማንበብ የተለያዩ ውጤቶች መስጠት ይችላሉ.
/// ይህም በዚያ ተለዋዋጭ አለበለዚያ ማንኛውም *ቋሚ* ቢት ስርዓተ ጥለት መያዝ ከሚችለው ኢንቲጀር አይነት, ያለው እንኳ ተለዋዋጭ ውስጥ uninitialized ውሂብ እንዲኖራቸው ባህሪ ያልተበየነ ያደርገዋል:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: i32 = unsafe { mem::uninitialized() }; // ያልተገለጸ ባህሪ!⚠️
/// // `MaybeUninit<i32>` ጋር ተመጣጣኝ ኮድ:
/// let x: i32 = unsafe { MaybeUninit::uninit().assume_init() }; // ያልተገለጸ ባህሪ!⚠️
/// ```
/// (ልብ-ወለድ ቁጥር ቁጥሮች ዙሪያ ያሉ ሕጎች ገና ያልተጠናቀቁ መሆናቸውን ልብ ይበሉ ፣ ግን እስከሚጠናቀቁ ድረስ እነሱን ማስወገድ ተገቢ ነው ፡፡)
///
/// በዚያ አናት ላይ, አብዛኞቹ ዓይነቶች ብቻ ዓይነት ደረጃ ላይ አልተነሳም ከመቆጠር ባሻገር ተጨማሪ invariants እንዳላቸው አስታውስ.
/// ለምሳሌ ያህል, አንድ `1`-አልተነሳም [`Vec<T>`] አልተነሳም ተደርጎ ነው (የአሁኑን አተገባበር ሥር; ይህ የተረጋጋ ዋስትና ይቆጠራል አይደለም) ስለ አጠናቃሪ ስለ ያውቃል ብቸኛ መመዘኛ ውሂብ ጠቋሚ ያልሆኑ አልቦ መሆን አለበት እንደሆነ ነው ምክንያቱም.
/// እንዲህ ያለ `Vec<T>`*ወዲያውኑ* ያልተገለጸ ባህሪ ምክንያት, ነገር ግን አብዛኛዎቹ ደህና ቀዶ ጋር ያልተገለጸ ባህሪ ያስከትላል (ይህ ሲከቱ ጨምሮ) አይደለም መፍጠር.
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
///
/// # Examples
///
/// `MaybeUninit<T>` uninitialized ውሂብ ለመቋቋም ያልተጠበቀ ኮድ ማንቃት ያገለግላል.
/// እዚህ ያለው መረጃ *ሊጀመር* እንደማይችል የሚያመለክተው ለኮሚተሩ ምልክት ነው ፡፡
///
/// ```rust
/// use std::mem::MaybeUninit;
///
/// // አንድ በግልጽ uninitialized ማጣቀሻ ይፍጠሩ.
/// // አሰባሳቢው በ `MaybeUninit<T>` ውስጥ ያለው መረጃ ልክ ያልሆነ ሊሆን እንደሚችል ያውቃል ፣ ስለሆነም ይህ ዩቢ አይደለም
/// let mut x = MaybeUninit::<&i32>::uninit();
/// // ትክክለኛ እሴት ያዘጋጁት.
/// unsafe { x.as_mut_ptr().write(&0); }
/// // የተጀመረውን መረጃ ያውጡ-ይህ የሚፈቀደው *በትክክል* ከጀመሩ በኋላ * * ብቻ ነው!
/////
/// let x = unsafe { x.assume_init() };
/// ```
///
/// አሰባሳቢው በዚህ ኮድ ላይ ምንም የተሳሳቱ ግምቶች ወይም ማመቻቸት ላለማድረግ ያውቃል።
///
/// የ `Option<T>` እንደ ትንሽ እንደሆነ ግን አሂድ-ጊዜ ትራኪንግ ማንኛውም ያለ እና የደህንነት ቼኮች ማንኛውም ያለ `MaybeUninit<T>` ማሰብ እንችላለን.
///
/// ## out-pointers
///
/// ይልቁንስ ተግባር ውሂብ የመመለስ, ይህም ወደ ውጤት ለማስቀመጥ አንዳንድ (uninitialized) ትውስታ አንድ ጠቋሚ ማለፍ: አንተ "out-pointers" ለመተግበር `MaybeUninit<T>` መጠቀም ይችላሉ.
/// ይህ ውጤት መመደቡን ቢጸዳም ውስጥ የሚከማች ነው እንዴት ትውስታ ቁጥጥር ወደ ጠሪው ጠቃሚ ነው ይህ ጠቃሚ ሊሆን ይችላል, እና አላስፈላጊ ይንቀሳቀሳል ማስወገድ ይፈልጋሉ.
///
/// ```
/// use std::mem::MaybeUninit;
///
/// unsafe fn make_vec(out: *mut Vec<i32>) {
///     // `write` አስፈላጊ ነው; አሮጌው ይዘቶችን መጣል አይደለም.
///     out.write(vec![1, 2, 3]);
/// }
///
/// let mut v = MaybeUninit::uninit();
/// unsafe { make_vec(v.as_mut_ptr()); }
/// // አሁን `v` እንደተጀመረ እናውቃለን!ይህ ደግሞ እርግጠኛ vector በአግባቡ አንጠበጠቡ ይቻላሉ ያደርጋል.
/////
/// let v = unsafe { v.assume_init() };
/// assert_eq!(&v, &[1, 2, 3]);
/// ```
///
/// ## አንድ ድርድር አባል-በ-አባል ማስጀመር
///
/// `MaybeUninit<T>` አባል-በ-ንጥረ ትልቅ ድርድር ማስጀመር ላይ ሊውል ይችላል:
///
/// ```
/// use std::mem::{self, MaybeUninit};
///
/// let data = {
///     // `MaybeUninit` አንድ uninitialized ድርድር ይፍጠሩ.
///     // እኛ እዚህ አልተነሳም ሊሆን ከሚሉ ናቸው ዓይነት መነሳት የማያስፈልጋቸው ይህም MaybeUninit`s`ስብስብ ነው ምክንያቱም `assume_init` ደህንነቱ የተጠበቀ ነው.
/////
///     let mut data: [MaybeUninit<Vec<u32>>; 1000] = unsafe {
///         MaybeUninit::uninit().assume_init()
///     };
///
///     // `MaybeUninit` ን መጣል ምንም አያደርግም።
///     // በመሆኑም ጥሬ የጠቋሚ ምደባ በመጠቀም ይልቅ `ptr::write` አሮጌውን uninitialized እሴት ሊያልፍ ሊያደርግ አይደለም.
/////
///     // አንድ panic በዚህ ምልልስ ወቅት ካለ በተጨማሪም, እኛ አንድ ትውስታ በሚያወጣበት አለኝ, ነገር ግን ምንም ትውስታ ደህንነት ጉዳይ አለ.
/////
///     for elem in &mut data[..] {
///         *elem = MaybeUninit::new(vec![42]);
///     }
///
///     // ሁሉም ነገር ተጀምሯል ፡፡
///     // ድርድርን ወደ መጀመሪያው ዓይነት ያስተላልፉ።
///     unsafe { mem::transmute::<_, [Vec<u32>; 1000]>(data) }
/// };
///
/// assert_eq!(&data[0], &[42]);
/// ```
///
/// በተጨማሪም ዝቅተኛ-ደረጃ datastructures ውስጥ ሊገኝ የሚችል በከፊል አልተነሳም ድርድሮች, ጋር መስራት ይችላሉ.
///
/// ```
/// use std::mem::MaybeUninit;
/// use std::ptr;
///
/// // `MaybeUninit` አንድ uninitialized ድርድር ይፍጠሩ.
/// // እኛ እዚህ አልተነሳም ሊሆን ከሚሉ ናቸው ዓይነት መነሳት የማያስፈልጋቸው ይህም MaybeUninit`s`ስብስብ ነው ምክንያቱም `assume_init` ደህንነቱ የተጠበቀ ነው.
/////
/// let mut data: [MaybeUninit<String>; 1000] = unsafe { MaybeUninit::uninit().assume_init() };
/// // እኛ የተመደበ ሊሆን ንጥረ ብዛት ይቁጠሩ.
/// let mut data_len: usize = 0;
///
/// for elem in &mut data[0..500] {
///     *elem = MaybeUninit::new(String::from("hello"));
///     data_len += 1;
/// }
///
/// // እኛ የተመደበ ከሆነ በድርድሩ ውስጥ ለእያንዳንዱ ንጥል ማኖር.
/// for elem in &mut data[0..data_len] {
///     unsafe { ptr::drop_in_place(elem.as_mut_ptr()); }
/// }
/// ```
///
/// ## - መስክ በ መስክ-አንድ struct በማስጀመር
///
/// የመስክ መስክን በመስክ ለመጀመር `MaybeUninit<T>` ን እና [`std::ptr::addr_of_mut`] ማክሮን መጠቀም ይችላሉ-
///
/// ```rust
/// use std::mem::MaybeUninit;
/// use std::ptr::addr_of_mut;
///
/// #[derive(Debug, PartialEq)]
/// pub struct Foo {
///     name: String,
///     list: Vec<u8>,
/// }
///
/// let foo = {
///     let mut uninit: MaybeUninit<Foo> = MaybeUninit::uninit();
///     let ptr = uninit.as_mut_ptr();
///
///     // የ `name` መስክ በማስጀመር
///     unsafe { addr_of_mut!((*ptr).name).write("Bob".to_string()); }
///
///     // የ `list` መስክ በማስጀመር ከዚያም `String` ወደ `name` መስክ ፍንጣቂዎች ውስጥ, እዚህ panic ካለ.
/////
///     unsafe { addr_of_mut!((*ptr).list).write(vec![0, 1, 2]); }
///
///     // ሁሉም መስኮች እኛ አልተነሳም Foo ለማግኘት `assume_init` ይደውሉ ስለዚህ, አልተነሳም ናቸው.
///     unsafe { uninit.assume_init() }
/// };
///
/// assert_eq!(
///     foo,
///     Foo {
///         name: "Bob".to_string(),
///         list: vec![0, 1, 2]
///     }
/// );
/// ```
/// [`std::ptr::addr_of_mut`]: crate::ptr::addr_of_mut
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Layout
///
/// `MaybeUninit<T>` `T` ጋር ተመሳሳይ መጠን, አሰላለፍ እና ABI እንዲኖረው ዋስትና ነው:
///
/// ```rust
/// use std::mem::{MaybeUninit, size_of, align_of};
/// assert_eq!(size_of::<MaybeUninit<u64>>(), size_of::<u64>());
/// assert_eq!(align_of::<MaybeUninit<u64>>(), align_of::<u64>());
/// ```
///
/// ይሁን እንጂ አንድ `MaybeUninit<T>` የግድ ተመሳሳይ አቀማመጥ አይደለም *አንድ ዓይነት* የያዘ መሆኑን ማስታወስ;Rust አንድ `Foo<T>` እርሻ `T` እና `U` ተመሳሳይ መጠን እና አሰላለፍ አላቸው እንኳ አንድ `Foo<U>` ተመሳሳይ ቅደም እንዳላቸው በአጠቃላይ ዋስትና ውስጥ አያደርግም.
///
/// ማንኛውም ቢት እሴት ትክክለኛ ነው; ከዚህም የተነሳ አንድ `MaybeUninit<T>` ለ አጠናቃሪ የሚችሉ ሰፋ መጠን ምክንያት, non-zero/niche-filling ማትባቶችን ተግባራዊ አይችልም:
///
/// ```rust
/// # use std::mem::{MaybeUninit, size_of};
/// assert_eq!(size_of::<Option<bool>>(), 1);
/// assert_eq!(size_of::<Option<MaybeUninit<bool>>>(), 2);
/// ```
///
/// `T` FFI-አስተማማኝ ከሆነ, ታዲያ እንዲህ `MaybeUninit<T>` ነው.
///
/// `MaybeUninit` `#[repr(transparent)]` ቢሆንም (ተመሳሳይ መጠን ፣ አሰላለፍ እና ኤቢአይ እንደ `T` ዋስትና ይሰጣል) ፣ ይህ *ከዚህ በፊት የነበሩትን ማንኛውንም ማስጠንቀቂያዎች* አይለውጠውም።
/// `Option<T>` እና `Option<MaybeUninit<T>>` አሁንም በተለያዩ መጠኖች ሊኖራቸው ይችላል, እና አይነት `T` አንድ መስክ የያዙ አይነቶች በዚያ መስክ `MaybeUninit<T>` ከሆነ በተለየ (እና መጠን ያላቸው) ወደ ውጭ አኖሩት ይችላል.
/// `MaybeUninit` ([the tracking issue](https://github.com/rust-lang/rust/issues/60405)) ማየት ህብረት አይነት ነው, እና ማኅበራት ላይ `#[repr(transparent)]` ያልተረጋጋ ነው.
/// ከጊዜ በኋላ, ማህበራት ላይ `#[repr(transparent)]` ትክክለኛ ዋስትናዎች በዝግመተ ይችላሉ, እና `MaybeUninit` ወይም `#[repr(transparent)]` መቆየት ይችላል ይችላሉ አይደለም.
/// ያ ፣ `MaybeUninit<T>`*ልክ* ተመሳሳይ *መጠን ፣ አሰላለፍ እና ኤቢአይ እንደ `T` እንዳለው* ሁልጊዜ * ያረጋግጣል ፤ይህ መንገድ `MaybeUninit` መሳሪያዎች ዋስትና በዝግመተ ዘንድ ብቻ መሆኑን ነው.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "maybe_uninit", since = "1.36.0")]
// Lang ንጥል ስለዚህ እኛ ሌሎች አይነቶች ለመጠቅለል ይችላሉ.ይህ ለጄነሬተሮች ጠቃሚ ነው ፡፡
#[lang = "maybe_uninit"]
#[derive(Copy)]
#[repr(transparent)]
pub union MaybeUninit<T> {
    uninit: (),
    value: ManuallyDrop<T>,
}

#[stable(feature = "maybe_uninit", since = "1.36.0")]
impl<T: Copy> Clone for MaybeUninit<T> {
    #[inline(always)]
    fn clone(&self) -> Self {
        // `T::clone()` ን አለመጥራት ፣ ለዚያ በቂ ጅምር እንደጀመርን ማወቅ አንችልም ፡፡
        *self
    }
}

#[stable(feature = "maybe_uninit_debug", since = "1.41.0")]
impl<T> fmt::Debug for MaybeUninit<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad(type_name::<Self>())
    }
}

impl<T> MaybeUninit<T> {
    /// የተሰጠው ዋጋ ጋር አልተነሳም አዲስ `MaybeUninit<T>` ይፈጥራል.
    /// ይህ ተግባር መመለስ ዋጋ ላይ [`assume_init`] መጥራት ደህንነቱ የተጠበቀ ነው.
    ///
    /// አንድ `MaybeUninit<T>` ሲከቱ `T` ዎቹ ጠብታ ኮድ ይደውሉ ፈጽሞ መሆኑን ልብ በል.
    /// እሱም ይህን አልተነሳም የምንገባ ከሆነ እርግጠኛ `T` ተቋርጧል የማያገኘው ማድረግ የእርስዎ ኃላፊነት ነው.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<Vec<u8>> = MaybeUninit::new(vec![42]);
    /// ```
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(val: T) -> MaybeUninit<T> {
        MaybeUninit { value: ManuallyDrop::new(val) }
    }

    /// ባልተለመደ ሁኔታ ውስጥ አዲስ `MaybeUninit<T>` ን ይፈጥራል።
    ///
    /// አንድ `MaybeUninit<T>` ሲከቱ `T` ዎቹ ጠብታ ኮድ ይደውሉ ፈጽሞ መሆኑን ልብ በል.
    /// እሱም ይህን አልተነሳም የምንገባ ከሆነ እርግጠኛ `T` ተቋርጧል የማያገኘው ማድረግ የእርስዎ ኃላፊነት ነው.
    ///
    /// አንዳንድ ምሳሌዎችን ለማግኘት [type-level documentation][MaybeUninit] ይመልከቱ.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<String> = MaybeUninit::uninit();
    /// ```
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    #[rustc_diagnostic_item = "maybe_uninit_uninit"]
    pub const fn uninit() -> MaybeUninit<T> {
        MaybeUninit { uninit: () }
    }

    /// አንድ uninitialized ሁኔታ ውስጥ, `MaybeUninit<T>` ንጥሎች አዲስ የድርድር ፍጠር.
    ///
    /// Note: ድርድር በቃል አገባብ [repeating const expressions](https://github.com/rust-lang/rust/issues/49147) ያስችላል ጊዜ future Rust ስሪት ውስጥ ይህን ዘዴ አላስፈላጊ ሊሆን ይችላል.
    ///
    /// ምሳሌ ከዚህ በታች ከዚያም `let mut buf = [MaybeUninit::<u8>::uninit(); 32];` መጠቀም ይችላል.
    ///
    /// # Examples
    ///
    /// ```no_run
    /// #![feature(maybe_uninit_uninit_array, maybe_uninit_extra, maybe_uninit_slice)]
    ///
    /// use std::mem::MaybeUninit;
    ///
    /// extern "C" {
    ///     fn read_into_buffer(ptr: *mut u8, max_len: usize) -> usize;
    /// }
    ///
    /// /// በእውነቱ የተነበበ (ምናልባትም ትንሽ) የውሂብ ቁርጥራጭ ይመልሳል
    /// fn read(buf: &mut [MaybeUninit<u8>]) -> &[u8] {
    ///     unsafe {
    ///         let len = read_into_buffer(buf.as_mut_ptr() as *mut u8, buf.len());
    ///         MaybeUninit::slice_assume_init_ref(&buf[..len])
    ///     }
    /// }
    ///
    /// let mut buf: [MaybeUninit<u8>; 32] = MaybeUninit::uninit_array();
    /// let data = read(&mut buf);
    /// ```
    ///
    #[unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[rustc_const_unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[inline(always)]
    pub const fn uninit_array<const LEN: usize>() -> [Self; LEN] {
        // ደህንነት: አንድ `[MaybeUninit<_>; LEN]` ልክ ነው uninitialized.
        unsafe { MaybeUninit::<[MaybeUninit<T>; LEN]>::uninit().assume_init() }
    }

    /// አዲስ `MaybeUninit<T>` ትውስታ `0` ባይት ተሞልቶ ጋር አንድ uninitialized ሁኔታ ይፈጥራል.በዚያ አስቀድሞ ተገቢውን ማስጀመር ለ ያደርገዋል አለመሆኑን `T` ላይ ይወሰናል.
    ///
    /// ለምሳሌ ያህል, `MaybeUninit<usize>::zeroed()` አልተነሳም ነው, ነገር ግን ማጣቀሻዎች ባዶ መሆን የለበትም ምክንያቱም `MaybeUninit<&'static i32>::zeroed()` አይደለም.
    ///
    /// አንድ `MaybeUninit<T>` ሲከቱ `T` ዎቹ ጠብታ ኮድ ይደውሉ ፈጽሞ መሆኑን ልብ በል.
    /// እሱም ይህን አልተነሳም የምንገባ ከሆነ እርግጠኛ `T` ተቋርጧል የማያገኘው ማድረግ የእርስዎ ኃላፊነት ነው.
    ///
    /// # Example
    ///
    /// የዚህ ተግባር ትክክለኛ አጠቃቀም-ሁሉም የመዋቅር መስኮች ቢት-ጥለት 0 ን እንደ ትክክለኛ እሴት መያዝ የሚችሉበት ከዜሮ ጋር መዋቅርን መጀመር።
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<(u8, bool)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// assert_eq!(x, (0, false));
    /// ```
    ///
    /// *ይህን ተግባር የተሳሳተ* አጠቃቀም: `0` ዓይነት ትክክለኛ ትንሽ-ጥለት አይደለም ጊዜ `x.zeroed().assume_init()` ጥሪ:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// enum NotZero { One = 1, Two = 2 }
    ///
    /// let x = MaybeUninit::<(u8, NotZero)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// // በአንድ ጥንድ ውስጥ ትክክለኛ አድልዎ የሌለውን `NotZero` እንፈጥራለን ፡፡
    /// // ይህ ያልተገለጸ ባህሪ ነው.⚠️
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[inline]
    #[rustc_diagnostic_item = "maybe_uninit_zeroed"]
    pub fn zeroed() -> MaybeUninit<T> {
        let mut u = MaybeUninit::<T>::uninit();
        // ደህንነት: `u.as_mut_ptr()` የተመደበ ትውስታ ይጠቁማል.
        unsafe {
            u.as_mut_ptr().write_bytes(0u8, 1);
        }
        u
    }

    /// የ `MaybeUninit<T>` ዋጋን ያስቀምጣል።
    /// ይህ የ destructor በማሄድ መዝለል ይፈልጋሉ በስተቀር ይህን ሁለቴ ለመጠቀም መጠንቀቅ, ይህም በመጣል ያለ ማንኛውም ቀዳሚ እሴት overwrites.
    ///
    /// ለእርስዎ ምቾት ሲባል, ይህ ደግሞ `self` መካከል (አሁን በደህና አልተነሳም) ይዘቶችን አንድ ሊቀየሩ ማጣቀሻ ይመልሳል.
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const fn write(&mut self, val: T) -> &mut T {
        *self = MaybeUninit::new(val);
        // ደህንነት: እኛ ብቻ በዚህ ዋጋ አልተነሳም.
        unsafe { self.assume_init_mut() }
    }

    /// ወደ የያዘ ዋጋ አንድ ጠቋሚ ያገኛል.
    /// ከዚህ ጠቋሚ በማንበብ ወይም ማጣቀሻ ወረወረው ዘወር የ `MaybeUninit<T>` አልተነሳም በስተቀር ያልተገለጸ ባህሪ ነው.
    /// ይህ ጠቋሚ (non-transitively) ነጥቦች (አንድ `UnsafeCell<T>` ውስጥ በስተቀር) ያልተገለጸ ባህሪ መሆኑን ትውስታ መጻፍ.
    ///
    /// # Examples
    ///
    /// በዚህ ዘዴ ትክክለኛ አጠቃቀም:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // ወደ `MaybeUninit<T>` ማጣቀሻ ይፍጠሩ።እኛ አልተነሳም; ምክንያቱም ይህ ችግር የለውም.
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// assert_eq!(x_vec.len(), 3);
    /// ```
    ///
    /// *ይህን ዘዴ የተሳሳተ* አጠቃቀም:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// // ለማይታወቅ vector ማጣቀሻ ፈጥረናል!ይህ ያልተገለጸ ባህሪ ነው.⚠️
    /// ```
    ///
    /// (ማስታወቂያ uninitialized ውሂብ ማጣቀሻ ዙሪያ ደንቦች ገና ይጠናቀቃል አይደሉም, ነገር ግን እነሱ ናቸው ድረስ እነሱን ማስወገድ ይመረጣል.)
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_ptr(&self) -> *const T {
        // `MaybeUninit` እና `ManuallyDrop` ሁለቱም `repr(transparent)` ናቸው ስለሆነም ጠቋሚውን መጣል እንችላለን።
        self as *const _ as *const T
    }

    /// ለያዘው እሴት የሚለዋወጥ ጠቋሚ ያገኛል።
    /// ከዚህ ጠቋሚ በማንበብ ወይም ማጣቀሻ ወረወረው ዘወር የ `MaybeUninit<T>` አልተነሳም በስተቀር ያልተገለጸ ባህሪ ነው.
    ///
    /// # Examples
    ///
    /// በዚህ ዘዴ ትክክለኛ አጠቃቀም:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // ወደ `MaybeUninit<Vec<u32>>` ማጣቀሻ ይፍጠሩ።
    /// // እኛ አልተነሳም; ምክንያቱም ይህ ችግር የለውም.
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// x_vec.push(3);
    /// assert_eq!(x_vec.len(), 4);
    /// ```
    ///
    /// *ይህን ዘዴ የተሳሳተ* አጠቃቀም:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// // ለማይታወቅ vector ማጣቀሻ ፈጥረናል!ይህ ያልተገለጸ ባህሪ ነው.⚠️
    /// ```
    ///
    /// (ማስታወቂያ uninitialized ውሂብ ማጣቀሻ ዙሪያ ደንቦች ገና ይጠናቀቃል አይደሉም, ነገር ግን እነሱ ናቸው ድረስ እነሱን ማስወገድ ይመረጣል.)
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        // `MaybeUninit` እና `ManuallyDrop` ሁለቱም `repr(transparent)` ናቸው ስለሆነም ጠቋሚውን መጣል እንችላለን።
        self as *mut _ as *mut T
    }

    /// የ `MaybeUninit<T>` መያዣ ከ እሴትን.ይህ ምክንያት `T` በተለመደው ጠብታ አያያዝ ተገዢ ነው ምክንያቱም ውሂብ አንጠበጠቡ ማግኘት መሆኑን ለማረጋገጥ ትልቅ መንገድ ነው.
    ///
    /// # Safety
    ///
    /// `MaybeUninit<T>` በእውነቱ በተጀመረው ሁኔታ ውስጥ መሆኑን ማረጋገጥ የደዋዩ ነው ፡፡ይዘቱ ገና ሙሉ በሙሉ ባልተጀመረበት ጊዜ ይህንን መጥራት ወዲያውኑ ያልተገለጸ ባህሪ ያስከትላል ፡፡
    /// የ [type-level documentation][inv] በዚህ ማስጀመር invariant በተመለከተ ተጨማሪ መረጃ ይይዛል.
    ///
    /// [inv]: #initialization-invariant
    ///
    /// በዚያ አናት ላይ, አብዛኞቹ ዓይነቶች ብቻ ዓይነት ደረጃ ላይ አልተነሳም ከመቆጠር ባሻገር ተጨማሪ invariants እንዳላቸው አስታውስ.
    /// ለምሳሌ ያህል, አንድ `1`-አልተነሳም [`Vec<T>`] አልተነሳም ተደርጎ ነው (የአሁኑን አተገባበር ሥር; ይህ የተረጋጋ ዋስትና ይቆጠራል አይደለም) ስለ አጠናቃሪ ስለ ያውቃል ብቸኛ መመዘኛ ውሂብ ጠቋሚ ያልሆኑ አልቦ መሆን አለበት እንደሆነ ነው ምክንያቱም.
    ///
    /// እንዲህ ያለ `Vec<T>`*ወዲያውኑ* ያልተገለጸ ባህሪ ምክንያት, ነገር ግን አብዛኛዎቹ ደህና ቀዶ ጋር ያልተገለጸ ባህሪ ያስከትላል (ይህ ሲከቱ ጨምሮ) አይደለም መፍጠር.
    ///
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    /// # Examples
    ///
    /// በዚህ ዘዴ ትክክለኛ አጠቃቀም:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<bool>::uninit();
    /// unsafe { x.as_mut_ptr().write(true); }
    /// let x_init = unsafe { x.assume_init() };
    /// assert_eq!(x_init, true);
    /// ```
    ///
    /// *ይህን ዘዴ የተሳሳተ* አጠቃቀም:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_init = unsafe { x.assume_init() };
    /// // `x` ገና አልተጀመረም ስለዚህ ይህ የመጨረሻው መስመር ያልተገለጸ ባህሪን አስከትሏል ፡፡⚠️
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    #[rustc_diagnostic_item = "assume_init"]
    pub const unsafe fn assume_init(self) -> T {
        // ደህንነት: `self` አልተነሳም ነው የደወለው የግድ ዋስትና.
        // ይህ ደግሞ `self` አንድ `value` ተለዋጭ መሆን አለበት ማለት ነው.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            ManuallyDrop::into_inner(self.value)
        }
    }

    /// የ `MaybeUninit<T>` መያዣ ከ እሴት ያነባል.ወደ ምክንያት `T` በተለመደው ጠብታ አያያዝ ተገዢ ነው.
    ///
    /// በተቻለ መጠን, ይህ የትኛው ያግዳቸዋል ወደ `MaybeUninit<T>` ይዘት አስመስሎ መሥራት, በምትኩ [`assume_init`] መጠቀም ይመረጣል.
    ///
    /// # Safety
    ///
    /// ይህ `MaybeUninit<T>` በእርግጥ አልተነሳም ሁኔታ ውስጥ ነው ዋስትና ወደ ደዋዩ ድረስ ነው.ይዘቱ ገና ሙሉ በሙሉ ያልተገለጸ ጠባይ መንስኤ አልተነሳም ጊዜ ይህን በመደወል.
    /// የ [type-level documentation][inv] በዚህ ማስጀመር invariant በተመለከተ ተጨማሪ መረጃ ይይዛል.
    ///
    /// ከዚህም በላይ ይህ ቅጠሎች ወደ `MaybeUninit<T>` ውስጥ ተመሳሳይ የውሂብ በስተጀርባ ቅጂ.
    /// (`assume_init_read` በርካታ ጊዜያት በመደወል, ወይም በመጀመሪያ ከዚያም `assume_init_read` እና [`assume_init`] በመደወል) ውሂብ በርካታ ቅጂዎች በመጠቀም ጊዜ, በዚያ ውሂብ በእርግጥ የተባዙ ሊሆን ይችላል መሆኑን ማረጋገጥ የእርስዎ ኃላፊነት ነው.
    ///
    ///
    /// [inv]: #initialization-invariant
    /// [`assume_init`]: MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// በዚህ ዘዴ ትክክለኛ አጠቃቀም:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<u32>::uninit();
    /// x.write(13);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // `u32` እኛ በርካታ ጊዜ ማንበብ ይችላሉ እንዲሁ `Copy` ነው.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(None);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // የ `None` እሴት ማባዛት ጥሩ ነው ፣ ስለሆነም ብዙ ጊዜ እናነባለን።
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    /// ```
    ///
    /// *ይህን ዘዴ የተሳሳተ* አጠቃቀም:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(Some(vec![0, 1, 2]));
    /// let x1 = unsafe { x.assume_init_read() };
    /// let x2 = unsafe { x.assume_init_read() };
    /// // አሁን, በዚሁ vector ሁለት ቅጂዎች የተፈጠሩ ሁለቱም GET ተቋርጧል ጊዜ ድርብ-ነጻ ⚠️ የሚያደርስ!
    /////
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const unsafe fn assume_init_read(&self) -> T {
        // ደህንነት: `self` አልተነሳም ነው የደወለው የግድ ዋስትና.
        // `self` አልተነሳም ያለበት በመሆኑ `self.as_ptr()` በማንበብ ላይ ደህንነቱ የተጠበቀ ነው.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            self.as_ptr().read()
        }
    }

    /// ቦታ የያዘ ዋጋ ዝቅ.
    ///
    /// የ `MaybeUninit` ባለቤትነት ካለዎት, በምትኩ [`assume_init`] መጠቀም ይችላሉ.
    ///
    /// # Safety
    ///
    /// ይህ `MaybeUninit<T>` በእርግጥ አልተነሳም ሁኔታ ውስጥ ነው ዋስትና ወደ ደዋዩ ድረስ ነው.ይዘቱ ገና ሙሉ በሙሉ ያልተገለጸ ጠባይ መንስኤ አልተነሳም ጊዜ ይህን በመደወል.
    ///
    /// `T` (ወይም አባላቱ) መካከል `Drop` አፈፃፀም በዚህ ላይ መተማመን ይችላሉ እንደ አናት ላይ, ዓይነት `T` ሁሉ ተጨማሪ invariants, መሟላት አለባቸው.
    /// ለምሳሌ ያህል, አንድ `1`-አልተነሳም [`Vec<T>`] አልተነሳም ተደርጎ ነው (የአሁኑን አተገባበር ሥር; ይህ የተረጋጋ ዋስትና ይቆጠራል አይደለም) ስለ አጠናቃሪ ስለ ያውቃል ብቸኛ መመዘኛ ውሂብ ጠቋሚ ያልሆኑ አልቦ መሆን አለበት እንደሆነ ነው ምክንያቱም.
    ///
    /// እንደዚህ ያለ `Vec<T>` ሲከቱ ይሁን ያልተገለጸ ባህሪ ያስከትላል.
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    pub unsafe fn assume_init_drop(&mut self) {
        // ደህንነት: `self` መሆኑን የደዋይ የግድ ዋስትና አልተነሳም ነው እና
        // የሚያጠግብ `T` ሁሉ invariants.
        // ይህ ሁኔታ ከሆነ ቦታ ላይ ዋጋ ሲከቱ ደህንነቱ የተጠበቀ ነው.
        unsafe { ptr::drop_in_place(self.as_mut_ptr()) }
    }

    /// በያዘው እሴት ላይ የጋራ ማጣቀሻ ያገኛል።
    ///
    /// እኛ አልተነሳም ተደርጓል ግን `.assume_init()`) መጠቀምን ለመከላከል የ `MaybeUninit` (ባለቤትነት የሌላቸው አንድ `MaybeUninit` ለመድረስ ይፈልጋሉ ጊዜ ይህ ጠቃሚ ሊሆን ይችላል.
    ///
    /// # Safety
    ///
    /// ይዘቱ ገና ሙሉ በሙሉ ባልተጀመረበት ጊዜ ይህንን መጥራት ያልተገለጸ ባህሪን ያስከትላል-`MaybeUninit<T>` በእውነቱ በተነሳበት ሁኔታ ውስጥ መሆኑን ማረጋገጥ የደዋዩ ነው።
    ///
    ///
    /// # Examples
    ///
    /// ### በዚህ ዘዴ ትክክለኛ አጠቃቀም:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// // `x` ን ያስጀምሩ
    /// unsafe { x.as_mut_ptr().write(vec![1, 2, 3]); }
    /// // አሁን `MaybeUninit<_>` አልተነሳም ዘንድ የታወቀ ነው, ነገሩ ወደ አንድ የተጋራ ማጣቀሻ ለመፍጠር ደህና ነው:
    /////
    /// let x: &Vec<u32> = unsafe {
    ///     // ደህንነት: `x` አልተነሳም ተደርጓል.
    ///     x.assume_init_ref()
    /// };
    /// assert_eq!(x, &vec![1, 2, 3]);
    /// ```
    ///
    /// ### *ትክክል ያልሆነ* የዚህ ስልት ለሚከተሉት:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec: &Vec<u32> = unsafe { x.assume_init_ref() };
    /// // ለማይታወቅ vector ማጣቀሻ ፈጥረናል!ይህ ያልተገለጸ ባህሪ ነው.⚠️
    /// ```
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{cell::Cell, mem::MaybeUninit};
    ///
    /// let b = MaybeUninit::<Cell<bool>>::uninit();
    /// // የ `MaybeUninit` `Cell::set` በመጠቀም ያስጀምራል:
    /// unsafe {
    ///     b.assume_init_ref().set(true);
    ///    // ^^^^^^^^^^^^^^^
    ///    // አንድ uninitialized `Cell<bool>` ማጣቀሻ: ub!
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_ref(&self) -> &T {
        // ደህንነት: `self` አልተነሳም ነው የደወለው የግድ ዋስትና.
        // ይህ ደግሞ `self` አንድ `value` ተለዋጭ መሆን አለበት ማለት ነው.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &*self.as_ptr()
        }
    }

    /// ወደ የያዘ እሴት ሊቀየሩ (unique) ማጣቀሻ ያገኛል.
    ///
    /// እኛ አልተነሳም ተደርጓል ግን `.assume_init()`) መጠቀምን ለመከላከል የ `MaybeUninit` (ባለቤትነት የሌላቸው አንድ `MaybeUninit` ለመድረስ ይፈልጋሉ ጊዜ ይህ ጠቃሚ ሊሆን ይችላል.
    ///
    /// # Safety
    ///
    /// ይዘቱ ገና ሙሉ በሙሉ ባልተጀመረበት ጊዜ ይህንን መጥራት ያልተገለጸ ባህሪን ያስከትላል-`MaybeUninit<T>` በእውነቱ በተነሳበት ሁኔታ ውስጥ መሆኑን ማረጋገጥ የደዋዩ ነው።
    /// ለምሳሌ ያህል, `.assume_init_mut()` አንድ `MaybeUninit` ማስጀመር ጥቅም ላይ ሊውል አይችልም.
    ///
    /// # Examples
    ///
    /// ### በዚህ ዘዴ ትክክለኛ አጠቃቀም:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// # unsafe extern "C" fn initialize_buffer(buf: *mut [u8; 2048]) { *buf = [0; 2048] }
    /// # #[cfg(FALSE)]
    /// extern "C" {
    ///     /// Initializes የግቤት ቋት ሁሉ *ወደ ባይት*.
    ///     fn initialize_buffer(buf: *mut [u8; 2048]);
    /// }
    ///
    /// let mut buf = MaybeUninit::<[u8; 2048]>::uninit();
    ///
    /// // መጀመር `buf`:
    /// unsafe { initialize_buffer(buf.as_mut_ptr()); }
    /// // አሁን `buf` እንደተጀመረ እናውቃለን ፣ ስለሆነም `.assume_init()` ልናደርገው እንችላለን።
    /// // ይሁን እንጂ, `.assume_init()` በመጠቀም 2048 ባይትስ የሆነ `memcpy` ሊያስነሳ ይችላል.
    /// // የመጠባበቂያ ቋታችን ሳይገለብጠው የተጀመረ መሆኑን ለማረጋገጥ `&mut MaybeUninit<[u8; 2048]>` ን ወደ `&mut [u8; 2048]` እናሻሽለዋለን ፡፡
    /////
    /// let buf: &mut [u8; 2048] = unsafe {
    ///     // ደህንነት: `buf` አልተነሳም ተደርጓል.
    ///     buf.assume_init_mut()
    /// };
    ///
    /// // አሁን `buf` ን እንደ ተለመደው ቁርጥራጭ ልንጠቀምበት እንችላለን
    /// buf.sort_unstable();
    /// assert!(
    ///     buf.windows(2).all(|pair| pair[0] <= pair[1]),
    ///     "buffer is sorted",
    /// );
    /// ```
    ///
    /// ### *ትክክል ያልሆነ* የዚህ ስልት ለሚከተሉት:
    ///
    /// እሴትን ለማስጀመር `.assume_init_mut()` ን መጠቀም አይችሉም
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut b = MaybeUninit::<bool>::uninit();
    /// unsafe {
    ///     *b.assume_init_mut() = true;
    ///     // እኛ አንድ uninitialized `bool` አንድ (mutable) ማጣቀሻ ፈጥረዋል!
    ///     // ይህ ያልተገለጸ ባህሪ ነው.⚠️
    /// }
    /// ```
    ///
    /// ለምሳሌ ያህል, አንድ uninitialized ቋት ውስጥ አይደለም [`Read`] ማድረግ ይችላል:
    ///
    /// [`Read`]: https://doc.rust-lang.org/std/io/trait.Read.html
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{io, mem::MaybeUninit};
    ///
    /// fn read_chunk (reader: &'_ mut dyn io::Read) -> io::Result<[u8; 64]>
    /// {
    ///     let mut buffer = MaybeUninit::<[u8; 64]>::uninit();
    ///     reader.read_exact(unsafe { buffer.assume_init_mut() })?;
    ///                             // ^^^^^^^^^^^^^^^^^^^^^^^^
    ///                             // (mutable) ያልታሰበ ማህደረ ትውስታን መጥቀስ!
    ///                             // ይህ ያልተገለጸ ባህሪ ነው ፡፡
    ///     Ok(unsafe { buffer.assume_init() })
    /// }
    /// ```
    ///
    /// ወይም እርስዎ መስክ-በ-መስክ በቀስ ማስጀመር ለማድረግ ቀጥተኛ መስክ መዳረሻ መጠቀም ይችላሉ:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{mem::MaybeUninit, ptr};
    ///
    /// struct Foo {
    ///     a: u32,
    ///     b: u8,
    /// }
    ///
    /// let foo: Foo = unsafe {
    ///     let mut foo = MaybeUninit::<Foo>::uninit();
    ///     ptr::write(&mut foo.assume_init_mut().a as *mut u32, 1337);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) ያልታሰበ ማህደረ ትውስታን መጥቀስ!
    ///                  // ይህ ያልተገለጸ ባህሪ ነው ፡፡
    ///     ptr::write(&mut foo.assume_init_mut().b as *mut u8, 42);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) ያልታሰበ ማህደረ ትውስታን መጥቀስ!
    ///                  // ይህ ያልተገለጸ ባህሪ ነው ፡፡
    ///     foo.assume_init()
    /// };
    /// ```
    ///
    ///
    ///
    ///
    // FIXME(#76092): በአሁኑ ጊዜ ማለትም, ትክክል መሆን ከላይ ያለውን መተማመን, እኛ (`libcore/fmt/float.rs` ውስጥ, ለምሳሌ) uninitialized ውሂብ ማጣቀሻ አላቸው.
    // እኛ ማረጋጋት በፊት ደንቦች በተመለከተ የመጨረሻ ውሳኔ ማድረግ አለበት.
    //
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_mut(&mut self) -> &mut T {
        // ደህንነት: `self` አልተነሳም ነው የደወለው የግድ ዋስትና.
        // ይህ ደግሞ `self` አንድ `value` ተለዋጭ መሆን አለበት ማለት ነው.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &mut *self.as_mut_ptr()
        }
    }

    /// `MaybeUninit` መያዣዎች ከአንድ ድርድር እሴቶች ያወጣል.
    ///
    /// # Safety
    ///
    /// ሁሉም የሰልፍ አካላት በተነሳሽነት ሁኔታ ውስጥ መሆናቸውን ማረጋገጥ የደዋዩ ነው።
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_uninit_array)]
    /// #![feature(maybe_uninit_array_assume_init)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut array: [MaybeUninit<i32>; 3] = MaybeUninit::uninit_array();
    /// array[0] = MaybeUninit::new(0);
    /// array[1] = MaybeUninit::new(1);
    /// array[2] = MaybeUninit::new(2);
    ///
    /// // ደህንነት: እኛ ሁሉንም ነገሮች initialised እንደ አሁን ደህና
    /// let array = unsafe {
    ///     MaybeUninit::array_assume_init(array)
    /// };
    ///
    /// assert_eq!(array, [0, 1, 2]);
    /// ```
    #[unstable(feature = "maybe_uninit_array_assume_init", issue = "80908")]
    #[inline(always)]
    pub unsafe fn array_assume_init<const N: usize>(array: [Self; N]) -> [T; N] {
        // SAFETY:
        // * በድርድሩ ሁሉንም ክፍሎች አልተነሳም ናቸው የደዋይ ዋስትና
        // * `MaybeUninit<T>` እና ቲ ተመሳሳይ አቀማመጥ እንዲኖራቸው ዋስትና ተሰጥቷቸዋል
        // * MaybeUnint መጣል የለውም, ስለዚህ ምንም ድርብ-ከያዘህ አሉ እንደዚሁም ወደ ልወጣ አስተማማኝ ነው
        //
        unsafe {
            intrinsics::assert_inhabited::<[T; N]>();
            (&array as *const _ as *const [T; N]).read()
        }
    }

    /// ሁሉም አካላት እንደተጀመሩ በማሰብ አንድ ቁራጭ ያግኙላቸው ፡፡
    ///
    /// # Safety
    ///
    /// የ `MaybeUninit<T>` አካላት በእውነቱ በተነሳሽነት ውስጥ መሆናቸውን ማረጋገጥ ለደዋዩ ነው።
    ///
    /// ይዘቱ ገና ሙሉ በሙሉ ያልተገለጸ ጠባይ መንስኤ አልተነሳም ጊዜ ይህን በመደወል.
    ///
    /// ተጨማሪ ዝርዝር እና ምሳሌዎችን ለማግኘት [`assume_init_ref`] ይመልከቱ.
    ///
    /// [`assume_init_ref`]: MaybeUninit::assume_init_ref
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_ref(slice: &[Self]) -> &[T] {
        // ደህንነት: የ `*const [T]` ወደ ቁራጭ የሚጥሉ ጠሪ ዋስትና መሆኑን ጀምሮ አስተማማኝ ነው
        // `slice` አልተነሳም ነው, and`MaybeUninit` `T` ተመሳሳይ አቀማመጥ ያላቸው የተረጋገጠ ነው.
        // ይህ ማጣቀሻ ነው በዚህም ያነባል ትክክለኛ ሆኖ ዋስትና ይህም `slice` ባለቤትነት ትውስታ የሚያመለክተው ጀምሮ ከተገኘው ጠቋሚ ትክክል ነው.
        //
        unsafe { &*(slice as *const [Self] as *const [T]) }
    }

    /// ንጥረ አልተነሳም ናቸው ሁሉ ጉረኞች, እነርሱ አንድ ሊቀየሩ ቁራጭ ያግኙ.
    ///
    /// # Safety
    ///
    /// የ `MaybeUninit<T>` አካላት በእውነቱ በተነሳሽነት ውስጥ መሆናቸውን ማረጋገጥ ለደዋዩ ነው።
    ///
    /// ይዘቱ ገና ሙሉ በሙሉ ያልተገለጸ ጠባይ መንስኤ አልተነሳም ጊዜ ይህን በመደወል.
    ///
    /// ለተጨማሪ ዝርዝሮች እና ምሳሌዎች [`assume_init_mut`] ን ይመልከቱ።
    ///
    /// [`assume_init_mut`]: MaybeUninit::assume_init_mut
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_mut(slice: &mut [Self]) -> &mut [T] {
        // ደህንነት ለ `slice_get_ref` ከደህንነት ማስታወሻዎች ጋር ተመሳሳይ ነው ፣ ግን እኛ አለን
        // በተጨማሪም ዋስትና ነው ሊቀየሩ ማጣቀሻ ይጽፋል የሚሰራ ይሆናል.
        unsafe { &mut *(slice as *mut [Self] as *mut [T]) }
    }

    /// በድርድሩ የመጀመሪያ አባል አንድ ጠቋሚ ያገኛል.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_ptr(this: &[MaybeUninit<T>]) -> *const T {
        this.as_ptr() as *const T
    }

    /// ለድርድሩ የመጀመሪያ አካል የሚለዋወጥ ጠቋሚ ያገኛል።
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_mut_ptr(this: &mut [MaybeUninit<T>]) -> *mut T {
        this.as_mut_ptr() as *mut T
    }

    /// `this` ውስጥ አሁን initalized ይዘቶችን አንድ ሊቀየሩ ማጣቀሻ መመለስ `src` ከ `this` ወደ ቅጂዎች ንጥረ ነገሮች,.
    ///
    /// `T` `Copy` ለመተግበር አይደለም ከሆነ, [`write_slice_cloned`] ይጠቀሙ
    ///
    /// ይህ [`slice::copy_from_slice`] ጋር ተመሳሳይ ነው.
    ///
    /// # Panics
    ///
    /// ይህ ተግባር panic ሁለት ገባዎች የተለያየ ርዝመት ያላቸው ከሆነ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(); 32];
    /// let src = [0; 32];
    ///
    /// let init = MaybeUninit::write_slice(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = [0; 16];
    ///
    /// MaybeUninit::write_slice(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // ደህንነት-እኛ አሁን የብድር ሁሉንም ንጥረ ነገሮች ወደ ትርፍ አቅም ገልብጠናል
    /// // ወደ vec የመጀመሪያ src.len() ንጥረ አሁን ልክ ናቸው.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice_cloned`]: MaybeUninit::write_slice_cloned
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Copy,
    {
        // ደህንነት: &[T] እና&[MaybeUninit<T>] ተመሳሳይ አቀማመጥ አላቸው
        let uninit_src: &[MaybeUninit<T>] = unsafe { super::transmute(src) };

        this.copy_from_slice(uninit_src);

        // ደህንነት: ይህም initalized ነው, ስለዚህ ልክ ንጥረ ነገሮች ብቻ `this` ወደ ተገልብጠዋል
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }

    /// ኤክስፐርቶችን ከ `src` ወደ `this` ይደውላል ፣ አሁን ወደ ተፈጥሮአዊ የ `this` ይዘቶች የሚለዋወጥ ማጣቀሻ ይመልሳል።
    /// ማንኛውም አስቀድሞ initalized ክፍሎች ተቋርጧል አይሆንም.
    ///
    /// `T` መሳሪያዎች `Copy`, አጠቃቀም [`write_slice`] ከሆነ
    ///
    /// ይህ [`slice::clone_from_slice`] ጋር ተመሳሳይ ነው ነገር ግን ነባር አባላትን መጣል አይደለም.
    ///
    /// # Panics
    ///
    /// ይህ ተግባር ሁለት ገባዎች panic የተለያየ ርዝመት ያላቸው, ወይም ከሆነ `Clone` panics አፈፃፀም ከሆነ.
    ///
    /// panic ካለ ቀድሞውኑ የተጫኑ ንጥረ ነገሮች ይጣላሉ።
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit()];
    /// let src = ["wibbly".to_string(), "wobbly".to_string(), "timey".to_string(), "wimey".to_string(), "stuff".to_string()];
    ///
    /// let init = MaybeUninit::write_slice_cloned(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = ["rust", "is", "a", "pretty", "cool", "language"];
    ///
    /// MaybeUninit::write_slice_cloned(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // ደህንነት: እኛ ብቻ ትርፍ አቅም ወደ LEN ሁሉ ክፍሎች በላብራቶሪ
    /// // ወደ vec የመጀመሪያ src.len() ንጥረ አሁን ልክ ናቸው.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice`]: MaybeUninit::write_slice
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice_cloned<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Clone,
    {
        // copy_from_slice በተለየ መልኩ ይህንን `MaybeUninit<T: Clone>` አባዛ በስራ አይደለም ምክንያቱም ይህ ነው ቁራጭ ላይ clone_from_slice መደወል አይደለም.
        //

        struct Guard<'a, T> {
            slice: &'a mut [MaybeUninit<T>],
            initialized: usize,
        }

        impl<'a, T> Drop for Guard<'a, T> {
            fn drop(&mut self) {
                let initialized_part = &mut self.slice[..self.initialized];
                // ደህንነት: ይህ ጥሬ ቁራጭ ብቻ አልተነሳም ነገሮችን ይይዛል
                // ይህ ይጣሉት የተፈቀደለት ለምን እንደሆነ ነው.
                unsafe {
                    crate::ptr::drop_in_place(MaybeUninit::slice_assume_init_mut(initialized_part));
                }
            }
        }

        assert_eq!(this.len(), src.len(), "destination and source slices have different lengths");
        // NOTE: በተመሳሳይ ተመሳሳይ ርዝመት ላይ በግልጽ እነሱን መቁረጥ ያስፈልገናል
        // ለፊደል ወሰን ለ elided ዘንድ, እና አመቻች (ለምሳሌ T= u8 ለ) ቀላል ጉዳዮች memcpy ያመነጫል.
        //
        let len = this.len();
        let src = &src[..len];

        // ዘብ b/c panic አንድ ለቅጂ ወቅት ሊከሰት ይችላል ያስፈልጋል
        let mut guard = Guard { slice: this, initialized: 0 };

        for i in 0..len {
            guard.slice[i].write(src[i].clone());
            guard.initialized += 1;
        }

        super::forget(guard);

        // ደህንነት-ልክ የሆኑ ንጥረ ነገሮች በ `this` ውስጥ የተፃፉ ስለሆኑ አካባቢያዊ ነው
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }
}