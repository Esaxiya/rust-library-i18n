//! ክዋኔዎች በ ASCII `[u8]` ላይ።

use crate::mem;

#[lang = "slice_u8"]
#[cfg(not(test))]
impl [u8] {
    /// በዚህ ቁርጥራጭ ውስጥ ያሉት ሁሉም ባይቶች በ ASCII ክልል ውስጥ ካሉ ያረጋግጡ።
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        is_ascii(self)
    }

    /// ሁለት ቁርጥራጭ የ ASCII ጉዳይ-የማይነካ ግጥሚያ መሆናቸውን ያረጋግጣል ፡፡
    ///
    /// `to_ascii_lowercase(a) == to_ascii_lowercase(b)` ጋር ተመሳሳይ ፣ ግን ጊዜያዊዎችን ሳይመድቡ እና ሳይገለብጡ።
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &[u8]) -> bool {
        self.len() == other.len() && self.iter().zip(other).all(|(a, b)| a.eq_ignore_ascii_case(b))
    }

    /// ይህንን ቁራጭ ወደ ASCII የላይኛው ጉዳይ ተመጣጣኝ በቦታው ይለውጠዋል።
    ///
    /// የ ASCII ፊደሎች ከ 'a' እስከ 'z' ወደ 'A' እስከ 'Z' ካርታ ይደረጋሉ ፣ ግን የ ASCII ያልሆኑ ፊደላት አልተለወጡም ፡፡
    ///
    /// ነባሩን ሳይቀይር አዲስ ባለከፍተኛ ዋጋ እሴት ለመመለስ [`to_ascii_uppercase`] ን ይጠቀሙ።
    ///
    ///
    /// [`to_ascii_uppercase`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        for byte in self {
            byte.make_ascii_uppercase();
        }
    }

    /// ይህንን ቁራጭ ወደ ASCII ዝቅተኛ ፊደል አቻው በቦታው ይለውጠዋል።
    ///
    /// የ ASCII ፊደሎች ከ 'A' እስከ 'Z' ወደ 'a' እስከ 'z' ካርታ ይደረጋሉ ፣ ግን የ ASCII ያልሆኑ ፊደላት አልተለወጡም ፡፡
    ///
    /// ነባሩን ሳይቀይር አዲስ ዝቅተኛ ዋጋ ያለው እሴት ለመመለስ [`to_ascii_lowercase`] ን ይጠቀሙ።
    ///
    ///
    /// [`to_ascii_lowercase`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        for byte in self {
            byte.make_ascii_lowercase();
        }
    }
}

/// `v` በሚለው ቃል ውስጥ ማንኛውም ባይት nonascii ከሆነ `true` ን ይመልሳል (>=128)።
/// ለ utf8 ማረጋገጫ ተመሳሳይ ነገር ከሚሰራ ከ‹XXXXX›‹Sarfed›፡፡
#[inline]
fn contains_nonascii(v: usize) -> bool {
    const NONASCII_MASK: usize = 0x80808080_80808080u64 as usize;
    (NONASCII_MASK & v) != 0
}

/// ቢት-በ-ጊዜ ስራዎች (በሚቻልበት ጊዜ) ምትክ የአጠቃቀም-ጊዜ ክወናዎችን የሚጠቀም የተመቻቸ ASCII ሙከራ።
///
/// እዚህ የምንጠቀምበት ስልተ ቀመር በጣም ቀላል ነው።`s` በጣም አጭር ከሆነ እያንዳንዱ ባይት ብቻ እንፈትሻለን እና እንጨርስበታለን ፡፡ያለበለዚያ
///
/// - የመጀመሪያውን ቃል ባልተስተካከለ ጭነት ያንብቡ።
/// - ጠቋሚውን ያስተካክሉ ፣ በተከታታይ ጭነቶች እስከ መጨረሻው ድረስ የሚቀጥሉትን ቃላት ያንብቡ።
/// - ባልተስተካከለ ጭነት የመጨረሻውን `usize` ከ `s` ያንብቡ።
///
/// ከነዚህ ጭነቶች ውስጥ አንዳቸውም ቢሆኑ `contains_nonascii` (above) ወደ እውነት የሚመለስበትን አንድ ነገር ካፈሩ መልሱ የተሳሳተ መሆኑን እናውቃለን ፡፡
///
///
///
#[inline]
fn is_ascii(s: &[u8]) -> bool {
    const USIZE_SIZE: usize = mem::size_of::<usize>();

    let len = s.len();
    let align_offset = s.as_ptr().align_offset(USIZE_SIZE);

    // በየወቅቱ ከሚፈጽመው ቃል ምንም ነገር የማናገኝ ከሆነ ወደ ሚዛን ማዞሪያ (ሪሰርች) እንመለስ ፡፡
    //
    // እኛ ደግሞ ይህን የምንሰራው `size_of::<usize>()` ለ `usize` በቂ የማይሆንበት ለሥነ-ሕንጻዎች ነው ፣ ምክንያቱም ያልተለመደ የ edge ጉዳይ ስለሆነ ፡፡
    //
    //
    if len < USIZE_SIZE || len < align_offset || USIZE_SIZE < mem::align_of::<usize>() {
        return s.iter().all(|b| b.is_ascii());
    }

    // የመጀመሪያውን ቃል ያልተስተካከለ እናነባለን ፣ ይህም ማለት `align_offset` ነው ማለት ነው
    // 0 ፣ ለተመሳሰለው ንባብ እንደገና ተመሳሳይ እሴት እናነባለን ፡፡
    let offset_to_aligned = if align_offset == 0 { USIZE_SIZE } else { align_offset };

    let start = s.as_ptr();
    // ደህንነት-እኛ `len < USIZE_SIZE` ን እናረጋግጣለን ፡፡
    let first_word = unsafe { (start as *const usize).read_unaligned() };

    if contains_nonascii(first_word) {
        return false;
    }
    // በተወሰነ ደረጃ በተዘዋዋሪ ይህንን ከላይ ፈትሸናል ፡፡
    // `offset_to_aligned` ወይ `align_offset` ወይም `USIZE_SIZE` መሆኑን ልብ ይበሉ ፣ ሁለቱም በግልጽ ከላይ እንደተፈተሹ ፡፡
    //
    debug_assert!(offset_to_aligned <= len);

    // ደህንነት ቃል-ptr እኛ ለማንበብ የምንጠቀምበት (በትክክል የተስተካከለ) የአጠቃቀም ptr ነው
    // የተቆራረጠ መካከለኛ ቁራጭ ፡፡
    let mut word_ptr = unsafe { start.add(offset_to_aligned) as *const usize };

    // `byte_pos` ለሉፕ መጨረሻ ቼኮች ጥቅም ላይ የዋለው የ `word_ptr` ባይት መረጃ ጠቋሚ ነው።
    let mut byte_pos = offset_to_aligned;

    // ያልተመደቡ ጭነቶች ብዙ ስለምንሠራ ፓራኖኒያ ስለ አሰላለፍ አሰሳ ፈትሽ ፡፡
    // በተግባር ግን ይህ በ `align_offset` ውስጥ ስህተትን ማገድ የማይቻል መሆን አለበት ፡፡
    //
    debug_assert_eq!((word_ptr as usize) % mem::align_of::<usize>(), 0);

    // ጅራቱ ሁልጊዜ በጅራት ፍተሻ ውስጥ የሚከናወነውን የመጨረሻውን የተጣጣመውን ቃል በራሱ ሳይጨምር እስከ መጨረሻው የተስማማውን ቃል ድረስ የሚከተሉትን ቃላትን ያንብቡ ፣ ቢበዛ ተጨማሪ branch `byte_pos == len` ን ለመጨመር አንድ ጊዜ አንድ `usize` ነው ፡፡
    //
    //
    while byte_pos < len - USIZE_SIZE {
        debug_assert!(
            // የንባብ ገደብ ውስጥ መሆኑን የንጽህና ቁጥጥር
            (word_ptr as usize + USIZE_SIZE) <= (start.wrapping_add(len) as usize) &&
            // እና ስለ `byte_pos` ያለን ግምቶች ያንን ይይዛሉ።
            (word_ptr as usize) - (start as usize) == byte_pos
        );

        // ደህንነት: `word_ptr` በትክክል የተስተካከለ መሆኑን እናውቃለን (በ ምክንያት
        // `align_offset`) ፣ እና በ `word_ptr` እና በመጨረሻው መካከል በቂ ባይት እንዳሉን እናውቃለን
        let word = unsafe { word_ptr.read() };
        if contains_nonascii(word) {
            return false;
        }

        byte_pos += USIZE_SIZE;
        // ደህንነት: እኛ `byte_pos <= len - USIZE_SIZE` እናውቃለን ፣ ያ ማለት
        // ከዚህ `add` በኋላ ፣ `word_ptr` ቢበዛ አንድ-መጨረሻ-ይሆናል።
        word_ptr = unsafe { word_ptr.add(1) };
    }

    // አንድ `usize` ብቻ ይቀራል የሚለውን ለማረጋገጥ የንፅህና ቁጥጥር ፡፡
    // ይህ በሉፕ ሁኔታችን ሊረጋገጥ ይገባል ፡፡
    debug_assert!(byte_pos <= len && len - byte_pos <= USIZE_SIZE);

    // ደህንነት ይህ በመነሻችን በምንፈትነው `len >= USIZE_SIZE` ላይ የተመሠረተ ነው ፡፡
    let last_word = unsafe { (start.add(len - USIZE_SIZE) as *const usize).read_unaligned() };

    !contains_nonascii(last_word)
}