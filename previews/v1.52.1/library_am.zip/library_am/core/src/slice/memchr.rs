// ከ rust-memchr የተወሰደ የመጀመሪያ ትግበራ ፡፡
// የቅጂ መብት 2015 አንድሪው ጋላንት ፣ ብሉስ እና ኒኮላስ ኮች

use crate::cmp;
use crate::mem;

const LO_U64: u64 = 0x0101010101010101;
const HI_U64: u64 = 0x8080808080808080;

// መቆራረጥን ይጠቀሙ ፡፡
const LO_USIZE: usize = LO_U64 as usize;
const HI_USIZE: usize = HI_U64 as usize;
const USIZE_BYTES: usize = mem::size_of::<usize>();

/// `x` ማንኛውንም ዜሮ ባይት ከያዘ `true` ን ይመልሳል።
///
/// ከ *ጉዳዮች ስሌት*፣ ጄ አርንድ:
///
/// ሀሳቡ ከእያንዳንዱ ባይት አንድን በመቀነስ ከዚያም ብድሩ እስከ መጨረሻው በጣም የተስፋፋበትን ባይት መፈለግ ነው
///
/// bit."
#[inline]
fn contains_zero_byte(x: usize) -> bool {
    x.wrapping_sub(LO_USIZE) & !x & HI_USIZE != 0
}

#[cfg(target_pointer_width = "16")]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) << 8 | b as usize
}

#[cfg(not(target_pointer_width = "16"))]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) * (usize::MAX / 255)
}

/// በ‹XXXX›ውስጥ ባይት `x` ጋር የሚዛመድ የመጀመሪያውን መረጃ ጠቋሚ ይመልሳል።
#[inline]
pub fn memchr(x: u8, text: &[u8]) -> Option<usize> {
    // ለአነስተኛ ቁርጥራጮች ፈጣን መንገድ
    if text.len() < 2 * USIZE_BYTES {
        return text.iter().position(|elt| *elt == x);
    }

    memchr_general_case(x, text)
}

fn memchr_general_case(x: u8, text: &[u8]) -> Option<usize> {
    // ሁለት የ `usize` ቃላትን በአንድ ጊዜ በማንበብ ለአንድ ነጠላ ባይት እሴት ይቃኙ ፡፡
    //
    // `text` ን በሦስት ክፍሎች ይክፈሉ
    // - ያልተስተካከለ የመጀመሪያ ክፍል ፣ በጽሑፉ ከመጀመሪያው ቃል የተስተካከለ አድራሻ በፊት
    // - ሰውነት ፣ በአንድ ጊዜ በ 2 ቃላት ይቃኙ
    // - የመጨረሻው ቀሪ ክፍል ፣ <2 የቃላት መጠን

    // እስከ የተስተካከለ ድንበር ፈልግ
    let len = text.len();
    let ptr = text.as_ptr();
    let mut offset = ptr.align_offset(USIZE_BYTES);

    if offset > 0 {
        offset = cmp::min(offset, len);
        if let Some(index) = text[..offset].iter().position(|elt| *elt == x) {
            return Some(index);
        }
    }

    // የጽሑፉን አካል ፈልግ
    let repeated_x = repeat_byte(x);
    while offset <= len - 2 * USIZE_BYTES {
        // ደህንነት-የዚህ ጊዜ ግምት ቢያንስ 2 * usize_bytes ርቀት ያረጋግጣል
        // በማካካሻ እና በመቁረጥ መጨረሻ መካከል።
        unsafe {
            let u = *(ptr.add(offset) as *const usize);
            let v = *(ptr.add(offset + USIZE_BYTES) as *const usize);

            // የሚዛመድ ባይት ካለ ይሰብሩ
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset += USIZE_BYTES * 2;
    }

    // የሰውነት ማዞሪያው ከቆመበት ነጥብ በኋላ ባይት ይፈልጉ።
    text[offset..].iter().position(|elt| *elt == x).map(|i| offset + i)
}

/// በ `text` ውስጥ ካለው ባይት `x` ጋር የሚዛመድ የመጨረሻውን ማውጫ ይመልሳል።
pub fn memrchr(x: u8, text: &[u8]) -> Option<usize> {
    // ሁለት የ `usize` ቃላትን በአንድ ጊዜ በማንበብ ለአንድ ነጠላ ባይት እሴት ይቃኙ ፡፡
    //
    // `text` ን በሦስት ክፍሎች ይክፈሉ
    // - ያልተስተካከለ ጅራት ፣ ከመጨረሻው ቃል ጋር ከተመሳሰለ አድራሻ በኋላ በጽሑፍ ውስጥ ፣
    // - አካል ፣ በአንድ ጊዜ በ 2 ቃላቶች የተቃኘ ፣
    // - የመጀመሪያዎቹ ቀሪ ባቶች ፣ <2 ቃል መጠን።
    let len = text.len();
    let ptr = text.as_ptr();
    type Chunk = usize;

    let (min_aligned_offset, max_aligned_offset) = {
        // የቅድመ ቅጥያ እና ቅጥያውን ርዝመት ለማግኘት ይህንን ብለን እንጠራዋለን ፡፡
        // በመሃል ላይ ሁሌም ሁለት ቁርጥራጮችን በአንድ ጊዜ እንሰራለን ፡፡
        // ደህንነት በ `align_to` ከሚያዙት የመጠን ልዩነቶች በስተቀር `[u8]` ን ወደ `[usize]` ማስተላለፍ ደህንነቱ የተጠበቀ ነው ፡፡
        //
        let (prefix, _, suffix) = unsafe { text.align_to::<(Chunk, Chunk)>() };
        (prefix.len(), len - suffix.len())
    };

    let mut offset = max_aligned_offset;
    if let Some(index) = text[offset..].iter().rposition(|elt| *elt == x) {
        return Some(offset + index);
    }

    // የጽሑፉን አካል ይፈልጉ ፣ በሚኒን_መስመር_ማቋረጣችንን ያረጋግጡ ፡፡
    // ማካካሻ ሁል ጊዜ የተስተካከለ ነው ፣ ስለሆነም `>` ን መሞከር ብቻ በቂ ነው እናም ሊመጣ ከሚችለው ፍሰት ይርቃል።
    //
    let repeated_x = repeat_byte(x);
    let chunk_bytes = mem::size_of::<Chunk>();

    while offset > min_aligned_offset {
        // ደህንነት: ማካካሻ የሚጀምረው በሊን ፣ suffix.len() ነው ፣ የሚበልጥ እስከሆነ ድረስ
        // min_aligned_offset (prefix.len()) የቀረው ርቀት ቢያንስ 2 * ቁራጭ_ቢቶች ነው።
        unsafe {
            let u = *(ptr.offset(offset as isize - 2 * chunk_bytes as isize) as *const Chunk);
            let v = *(ptr.offset(offset as isize - chunk_bytes as isize) as *const Chunk);

            // የሚዛመድ ባይት ካለ ይሰብሩ።
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset -= 2 * chunk_bytes;
    }

    // የሰውነት ማዞሪያው ከመቆሙ በፊት ባይት ይፈልጉ።
    text[..offset].iter().rposition(|elt| *elt == x)
}