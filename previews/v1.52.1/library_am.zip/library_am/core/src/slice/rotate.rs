// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// የ `[mid-left, mid+right)` ን ክልል ያሽከረክራል ፣ ስለሆነም በ `mid` ያለው አካል የመጀመሪያ አካል ይሆናል።በእኩልነት ፣ የክልሉን `left` አባሎችን ወደ ግራ ወይም የ `right` አባሎችን ወደ ቀኝ ያሽከረክራል።
///
/// # Safety
///
/// የተጠቀሰው ክልል ለንባብ እና ለመፃፍ ልክ መሆን አለበት ፡፡
///
/// # Algorithm
///
/// አልጎሪዝም 1 ለ `left + right` እሴቶች ወይም ለትልቅ `T` ጥቅም ላይ ይውላል።
/// ንጥረ ነገሮቹ አንድ በአንድ በ `mid - left` በመጀመር በ `right` ደረጃዎች ሞዱሎ `left + right` በማደግ ወደ መጨረሻ ቦታዎቻቸው ይዛወራሉ ፣ እንደዚህ አንድ ጊዜያዊ ብቻ ያስፈልጋል።
/// በመጨረሻም ወደ `mid - left` ተመልሰን እንመጣለን ፡፡
/// ሆኖም ፣ `gcd(left + right, right)` 1 ካልሆነ ፣ ከላይ ያሉት እርምጃዎች ከአባላት በላይ ዘለሉ።
/// ለምሳሌ:
///
/// ```text
/// left = 10, right = 6
/// the `^` indicates an element in its final place
/// 6 7 8 9 10 11 12 13 14 15 . 0 1 2 3 4 5
/// after using one step of the above algorithm (The X will be overwritten at the end of the round,
/// and 12 is stored in a temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 2 3 4 5
///               ^
/// after using another step (now 2 is in the temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///               ^                 ^
/// after the third step (the steps wrap around, and 8 is in the temporary):
/// X 7 2 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///     ^         ^                 ^
/// after 7 more steps, the round ends with the temporary 0 getting put in the X:
/// 0 7 2 9 4 11 6 13 8 15 . 10 1 12 3 14 5
/// ^   ^   ^    ^    ^       ^    ^    ^
/// ```
///
/// እንደ እድል ሆኖ ፣ በተጠናቀቁ አካላት መካከል የተሟሉ ንጥረ ነገሮች ቁጥር ሁል ጊዜ እኩል ነው ፣ ስለሆነም የመነሻ ቦታችንን ማካካስ እና ተጨማሪ ዙሮችን ማድረግ እንችላለን (የአጠቃላይ ዙሮች ብዛት `gcd(left + right, right)` value) ነው።
///
/// የመጨረሻው ውጤት ሁሉም ንጥረ ነገሮች አንዴ እና አንዴ ብቻ ይጠናቀቃሉ።
///
/// `left + right` ትልቅ ከሆነ ግን ስልኩ ስልተ ቀመር 2 ጥቅም ላይ ይውላል ፣ ግን `min(left, right)` አነስተኛ በሆነ የቁልፍ ቋት ላይ ለመጫን በቂ ነው።
/// የ `min(left, right)` ንጥረ ነገሮች በመጠባበቂያው ላይ ይገለበጣሉ ፣ `memmove` በሌሎች ላይ ይተገበራል ፣ እና በመያዣው ላይ ያሉት ደግሞ ወደተነሱበት ተቃራኒው ጎን ወደ ቀዳዳው ይመለሳሉ።
///
/// ኤክስኤክስኤክስ (`left + right`) በበቂ መጠን ሲጨምር ከላይ ከተጠቀሰው በላይ በቬክተር ሊደረድሩ የሚችሉ ስልተ ቀመሮች ፡፡
/// አልጎሪዝም 1 በአንድ ጊዜ ብዙ ዙሮችን በመቁረጥ እና በማከናወን ሊመረመር ይችላል ፣ ግን `left + right` በጣም ግዙፍ እስከሆነ ድረስ በአማካይ በጣም ጥቂት ዙሮች አሉ ፣ እና የአንድ ዙር በጣም መጥፎው ሁኔታ ሁል ጊዜም አለ።
/// ይልቁንም አልጎሪዝም 3 አነስተኛ የማሽከርከር ችግር እስከሚቀር ድረስ የ `min(left, right)` አባሎችን ተደጋጋሚ መለዋወጥ ይጠቀማል።
///
/// ```text
/// left = 11, right = 4
/// [4 5 6 7 8 9 10 11 12 13 14 . 0 1 2 3]
///                  ^  ^  ^  ^   ^ ^ ^ ^ swapping the right most elements with elements to the left
/// [4 5 6 7 8 9 10 . 0 1 2 3] 11 12 13 14
///        ^ ^ ^  ^   ^ ^ ^ ^ swapping these
/// [4 5 6 . 0 1 2 3] 7 8 9 10 11 12 13 14
/// we cannot swap any more, but a smaller rotation problem is left to solve
/// ```
/// `left < right` በሚለውጠው ጊዜ ምትክ በምትኩ ከግራ ይከሰታል።
///
///
///
///
///
pub unsafe fn ptr_rotate<T>(mut left: usize, mut mid: *mut T, mut right: usize) {
    type BufType = [usize; 32];
    if mem::size_of::<T>() == 0 {
        return;
    }
    loop {
        // N.B. እነዚህ ጉዳዮች ካልተጣሩ ከዚህ በታች ያሉት ስልተ ቀመሮች ሊሳኩ ይችላሉ
        if (right == 0) || (left == 0) {
            return;
        }
        if (left + right < 24) || (mem::size_of::<T>() > mem::size_of::<[usize; 4]>()) {
            // አልጎሪዝም 1 ማይክሮቤንማርክ እንደሚያመለክተው በዘፈቀደ ለሚፈጠሩ ለውጦች አማካይ አፈፃፀም እስከ `left + right == 32` አካባቢ ድረስ የተሻለው ነው ፣ ግን በጣም የከፋው አፈፃፀም እስከ 16 አካባቢ እንኳን ይሰብራል።
            // 24 መካከለኛ ስፍራ ሆኖ ተመርጧል ፡፡
            // የ `T` መጠን ከ 4 `usize`s የበለጠ` ከሆነ ይህ ስልተ ቀመር ሌሎች ስልተ ቀመሮችንም ይበልጣል።
            //
            //
            let x = unsafe { mid.sub(left) };
            // የመጀመሪያ ዙር መጀመሪያ
            let mut tmp: T = unsafe { x.read() };
            let mut i = right;
            // `gcd` `gcd(left + right, right)` ን በማስላት ከእጅ በፊት ሊገኝ ይችላል ፣ ግን የጂ.ሲ.ዲ.ን እንደ የጎንዮሽ ጉዳት የሚያሰላ አንድ አንጓን ማከናወን ፈጣን ነው ፣ ከዚያ የቀረውን ቁራጭ
            //
            //
            let mut gcd = right;
            // መመዘኛዎች እንደሚያሳዩት አንድ ጊዜያዊ አንድ ጊዜ ከማንበብ ፣ ወደ ኋላ በመገልበጥ ፣ እና በመጨረሻው ጊዜያዊ ጊዜያዊ ጽሑፍን ከመፃፍ ይልቅ ሁሉንም ጊዜ መለዋወጥ ፈጣን መሆኑን ያሳያል ፡፡
            // ይህ ሊሆን የቻለበት ምክንያት ጊዜያዎችን መለወጥ ወይም መተካት ሁለቱን ማስተዳደር ከመፈለግ ይልቅ በክብደቱ ውስጥ አንድ የማህደረ ትውስታ አድራሻ ብቻ ስለሚጠቀም ነው ፡፡
            //
            //
            loop {
                tmp = unsafe { x.add(i).replace(tmp) };
                // `i` ን ከመጨመር እና ከዚያ ከክልሎች ውጭ መሆኑን ከመፈተሽ ይልቅ `i` በሚቀጥለው ጭማሪ ላይ ካለው ወሰን ውጭ የሚሄድ መሆኑን እንፈትሻለን ፡፡
                // ይህ ማንኛውንም ጠቋሚዎችን ወይም `usize` ን መጠቅለልን ይከላከላል።
                //
                if i >= left {
                    i -= left;
                    if i == 0 {
                        // የመጀመሪያው ዙር መጨረሻ
                        unsafe { x.write(tmp) };
                        break;
                    }
                    // `left + right >= 15` ከሆነ ይህ ሁኔታዊ እዚህ መሆን አለበት
                    if i < gcd {
                        gcd = i;
                    }
                } else {
                    i += right;
                }
            }
            // ክሩክን በበለጠ ዙሮች ጨርስ
            for start in 1..gcd {
                tmp = unsafe { x.add(start).read() };
                i = start + right;
                loop {
                    tmp = unsafe { x.add(i).replace(tmp) };
                    if i >= left {
                        i -= left;
                        if i == start {
                            unsafe { x.add(start).write(tmp) };
                            break;
                        }
                    } else {
                        i += right;
                    }
                }
            }
            return;
        // `T` ዜሮ-መጠን ዓይነት አይደለም ፣ ስለሆነም በመጠን መጠቀሙ ጥሩ ነው።
        } else if cmp::min(left, right) <= mem::size_of::<BufType>() / mem::size_of::<T>() {
            // አልጎሪዝም 2 `[T; 0]` እዚህ ላይ ይህ ለቲ በትክክል መጣጣሙን ማረጋገጥ ነው
            //
            let mut rawarray = MaybeUninit::<(BufType, [T; 0])>::uninit();
            let buf = rawarray.as_mut_ptr() as *mut T;
            let dim = unsafe { mid.sub(left).add(right) };
            if left <= right {
                unsafe {
                    ptr::copy_nonoverlapping(mid.sub(left), buf, left);
                    ptr::copy(mid, mid.sub(left), right);
                    ptr::copy_nonoverlapping(buf, dim, left);
                }
            } else {
                unsafe {
                    ptr::copy_nonoverlapping(mid, buf, right);
                    ptr::copy(mid.sub(left), dim, left);
                    ptr::copy_nonoverlapping(buf, mid.sub(left), right);
                }
            }
            return;
        } else if left >= right {
            // ስልተ-ቀመር 3 የዚህ ስልተ-ቀመር የመጨረሻው ስዋፕ የት እንደሚገኝ መፈለግ እና ይህ ስልተ-ቀመር እንደሚያደርገው በአጠገብ ያሉ ቁርጥራጮችን ከመቀየር ይልቅ ያ የመጨረሻውን ቼክ በመጠቀም መለዋወጥ ሌላ አማራጭ መንገድ አለ ፣ ግን ይህ መንገድ አሁንም ፈጣን ነው።
            //
            //
            //
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(right), mid, right);
                    mid = mid.sub(right);
                }
                left -= right;
                if left < right {
                    break;
                }
            }
        } else {
            // ስልተ-ቀመር 3 ፣ `left < right`
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(left), mid, left);
                    mid = mid.add(left);
                }
                right -= left;
                if right < left {
                    break;
                }
            }
        }
    }
}