//! `&[T]` እና `&mut [T]` ን ለመፍጠር ነፃ ተግባራት ፡፡

use crate::array;
use crate::intrinsics::is_aligned_and_not_null;
use crate::mem;
use crate::ptr;

/// ከጠቋሚ እና ርዝመት አንድ ቁራጭ ይሠራል ፡፡
///
/// የ‹XXXX›ክርክር የ **አባሎች ብዛት ነው**፣ ባይቶች ቁጥር አይደለም።
///
/// # Safety
///
/// ከሚከተሉት ሁኔታዎች ውስጥ አንዳቸውም ቢጣሱ ባህሪይ አልተገለጸም-
///
/// * `data` ለ `len * mem::size_of::<T>()` ብዙ ባይቶች ለማንበብ [valid] መሆን አለበት ፣ እና በትክክል መመሳሰል አለበት።ይህ ማለት በተለይ
///
///     * የዚህ ቁራጭ አጠቃላይ የማስታወሻ ክልል በአንድ በተመደበ ነገር ውስጥ መያዝ አለበት!
///       ቁርጥራጮች በብዙ በተመደቡ ነገሮች ላይ በጭራሽ መዘርጋት አይችሉም።ይህንን ከግምት ውስጥ ካላስገባ በስህተት ምሳሌ [below](#incorrect-usage) ን ይመልከቱ ፡፡
///     * `data` ለዜሮ-ርዝመት ቁርጥራጮች እንኳን የማይሰራ እና የተስተካከለ መሆን አለበት።
///     ለዚህ አንደኛው ምክንያት የ‹Enum›አቀማመጥ ማመቻቸት በማጣቀሻዎች ላይ ሊመረኮዝ ስለሚችል ነው (ማንኛውንም ርዝመት ያላቸውን ቁርጥራጮችን ጨምሮ) ከሌሎች መረጃዎች ለመለየት በሚመሳሰሉ እና ዋጋ ቢስ ይሆናሉ ፡፡
///     [`NonNull::dangling()`] ን በመጠቀም ለዜሮ-ርዝመት ቁርጥራጮች እንደ `data` የሚያገለግል ጠቋሚ ማግኘት ይችላሉ ፡፡
///
/// * `data` የ `T` ዓይነት በትክክል የተጀመሩ እሴቶችን በተከታታይ ወደ `len` ማመልከት አለበት።
///
/// * በተመለሰው ቁራጭ የተጠቀሰው ማህደረ ትውስታ ከ‹`UnsafeCell` X›በስተቀር በሕይወት ዘመን `'a` ዕድሜው ሁሉ መለወጥ የለበትም ፡፡
///
/// * የተቆራረጠው አጠቃላይ መጠን `len * mem::size_of::<T>()` ከ `isize::MAX` ያልበለጠ መሆን አለበት።
///   የ [`pointer::offset`] የደህንነት ሰነድን ይመልከቱ ፡፡
///
/// # Caveat
///
/// ለተመለሰው ቁራጭ የሕይወት ዘመን ከአጠቃቀሙ የመነጨ ነው ፡፡
/// በአጋጣሚ ያለአግባብ መጠቀምን ለመከላከል በሕይወት ዘመኑ ከየትኛውም ምንጭ ሕይወት ጋር ደህንነቱ የተጠበቀ ከሆነ ጋር ለማያያዝ የተጠቆመ ነው ፣ ለምሳሌ ለተቆራጩ የአስተናጋጅ ዋጋን የሚቆይ ረዳት ተግባርን በመስጠት ወይም በግልፅ ማብራሪያ ፡፡
///
///
/// # Examples
///
/// ```
/// use std::slice;
///
/// // ለአንድ ነጠላ አካል ቁርጥራጭ ይግለጹ
/// let x = 42;
/// let ptr = &x as *const _;
/// let slice = unsafe { slice::from_raw_parts(ptr, 1) };
/// assert_eq!(slice[0], 42);
/// ```
///
/// ### የተሳሳተ አጠቃቀም
///
/// የሚከተለው የ `join_slices` ተግባር **ጥሩ ያልሆነ** ⚠️ ነው
///
/// ```rust,no_run
/// use std::slice;
///
/// fn join_slices<'a, T>(fst: &'a [T], snd: &'a [T]) -> &'a [T] {
///     let fst_end = fst.as_ptr().wrapping_add(fst.len());
///     let snd_start = snd.as_ptr();
///     assert_eq!(fst_end, snd_start, "Slices must be contiguous!");
///     unsafe {
///         // ከላይ ያለው ማረጋገጫ `fst` እና `snd` ተያያዥ መሆናቸውን ያረጋግጣል ፣ ግን አሁንም በ‹XXXX›ውስጥ ሊኖሩ ይችላሉ ፣ በዚህ ሁኔታ ውስጥ ይህን ቁርጥራጭ መፍጠሩ ያልተገለጸ ባህሪ ነው ፡፡
/////
/////
///         slice::from_raw_parts(fst.as_ptr(), fst.len() + snd.len())
///     }
/// }
///
/// fn main() {
///     // `a` እና `b` የተለያዩ የተመደቡ ነገሮች ናቸው ...
///     let a = 42;
///     let b = 27;
///     // ... ሆኖም ግን በትዝታ ውስጥ በግልጽ የተቀመጠ ሊሆን ይችላል |ሀ |ለ |
///     let _ = join_slices(slice::from_ref(&a), slice::from_ref(&b)); // UB
/// }
/// ```
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts<'a, T>(data: *const T, len: usize) -> &'a [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // ደህንነት-ደዋዩ ለ `from_raw_parts` የደህንነትን ውል ማክበር አለበት ፡፡
    unsafe { &*ptr::slice_from_raw_parts(data, len) }
}

/// የሚለዋወጥ ቁራጭ ከተመለሰ በስተቀር እንደ [`from_raw_parts`] ተመሳሳይ ተግባር ያከናውናል።
///
/// # Safety
///
/// ከሚከተሉት ሁኔታዎች ውስጥ አንዳቸውም ቢጣሱ ባህሪይ አልተገለጸም-
///
/// * `data` ለ `len * mem::size_of::<T>()` ብዙ ባይቶች ለሁለቱም ለማንበብ እና ለመጻፍ [valid] መሆን አለበት ፣ እና በትክክል መመሳሰል አለበት።ይህ ማለት በተለይ
///
///     * የዚህ ቁራጭ አጠቃላይ የማስታወሻ ክልል በአንድ በተመደበ ነገር ውስጥ መያዝ አለበት!
///       ቁርጥራጮች በብዙ በተመደቡ ነገሮች ላይ በጭራሽ መዘርጋት አይችሉም።
///     * `data` ለዜሮ-ርዝመት ቁርጥራጮች እንኳን የማይሰራ እና የተስተካከለ መሆን አለበት።
///     ለዚህ አንደኛው ምክንያት የ‹Enum›አቀማመጥ ማመቻቸት በማጣቀሻዎች ላይ ሊመረኮዝ ስለሚችል ነው (ማንኛውንም ርዝመት ያላቸውን ቁርጥራጮችን ጨምሮ) ከሌሎች መረጃዎች ለመለየት በሚመሳሰሉ እና ዋጋ ቢስ ይሆናሉ ፡፡
///
///     [`NonNull::dangling()`] ን በመጠቀም ለዜሮ-ርዝመት ቁርጥራጮች እንደ `data` የሚያገለግል ጠቋሚ ማግኘት ይችላሉ ፡፡
///
/// * `data` የ `T` ዓይነት በትክክል የተጀመሩ እሴቶችን በተከታታይ ወደ `len` ማመልከት አለበት።
///
/// * በተመለሰው ቁርጥራጭ የተጠቀሰው ማህደረ ትውስታ በህይወት ዘመን `'a` ዕድሜው በማንኛውም ሌላ ጠቋሚ (ከመመለሻ እሴት ያልተገኘ) መድረስ የለበትም።
///   ሁለቱም የንባብ እና የፅሁፍ መድረሻዎች የተከለከሉ ናቸው ፡፡
///
/// * የተቆራረጠው አጠቃላይ መጠን `len * mem::size_of::<T>()` ከ `isize::MAX` ያልበለጠ መሆን አለበት።
///   የ [`pointer::offset`] የደህንነት ሰነድን ይመልከቱ ፡፡
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts_mut<'a, T>(data: *mut T, len: usize) -> &'a mut [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // ደህንነት-ደዋዩ ለ `from_raw_parts_mut` የደህንነትን ውል ማክበር አለበት ፡፡
    unsafe { &mut *ptr::slice_from_raw_parts_mut(data, len) }
}

/// ማጣቀሻውን ወደ ቲ ወደ 1 ቁራጭ ቁራጭ (ሳይገለብጥ) ይለውጣል።
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_ref<T>(s: &T) -> &[T] {
    array::from_ref(s)
}

/// ማጣቀሻውን ወደ ቲ ወደ 1 ቁራጭ ቁራጭ (ሳይገለብጥ) ይለውጣል።
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_mut<T>(s: &mut T) -> &mut [T] {
    array::from_mut(s)
}