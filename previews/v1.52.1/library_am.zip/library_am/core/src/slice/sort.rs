//! የተቆራረጠ መደርደር
//!
//! ይህ ሞጁል በ‹ኦርሰን ፒተርስ›ስርዓተ-ጥለት-ድል-ፈጣን ሙከራ ላይ የተመሠረተ የመለየት ስልተ ቀመር ይ containsል-በ <https://github.com/orlp/pdqsort>
//!
//!
//! እንደ የተረጋጋ የመለየት አተገባበራችን ያልተረጋጋ ድርደራ ከሊብኮር ጋር ተኳሃኝ ነው ምክንያቱም ማህደረ ትውስታን አይመድብም ፡፡
//!

// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// ሲጣሉ ፣ ከ `src` ወደ `dest` ቅጂዎች ፡፡
struct CopyOnDrop<T> {
    src: *mut T,
    dest: *mut T,
}

impl<T> Drop for CopyOnDrop<T> {
    fn drop(&mut self) {
        // ደህንነት ይህ ረዳት ክፍል ነው ፡፡
        //          እባክዎን ለትክክለኛነቱ አጠቃቀሙን ይመልከቱ ፡፡
        //          ይኸውም አንድ ሰው `src` እና `dst` በ `ptr::copy_nonoverlapping` በሚፈለገው መሠረት እንደማይደራደሩ እርግጠኛ መሆን አለበት።
        unsafe {
            ptr::copy_nonoverlapping(self.src, self.dest, 1);
        }
    }
}

/// ትልቁን ወይም እኩል የሆነ ንጥረ ነገር እስኪያገኝ ድረስ የመጀመሪያውን ንጥረ ነገር ወደ ቀኝ ያዛውረዋል።
fn shift_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // ደህንነት ከዚህ በታች ያሉት ደህንነታቸው ያልተጠበቀ ክንውኖች ያለገደብ ቼክ ማውጫ ማውጫ (`get_unchecked` እና `get_unchecked_mut`) ያካትታሉ
    // እና ማህደረ ትውስታ (`ptr::copy_nonoverlapping`) ን መቅዳት.
    //
    // ሀ.ማውጫ
    //  1. የዝርዝሩን መጠን ወደ>=2 መርምረናል ፡፡
    //  2. እኛ የምናደርጋቸው ሁሉም ማውጫዎች ቢበዛ ሁልጊዜ በ {0 <= index < len} መካከል ናቸው።
    //
    // ለ.የማስታወሻ ቅጅ
    //  1. ትክክለኛ እንዲሆኑ የተረጋገጡ የማጣቀሻዎችን አመልካቾች እያገኘን ነው ፡፡
    //  2. ለተቆራረጡ የልዩነት ጠቋሚዎች ጠቋሚዎችን ስለምናገኝ መደራረብ አይችሉም ፡፡
    //     ይኸውም `i` እና `i-1`።
    //  3. ቁራሹ በትክክል ከተስተካከለ አባላቱ በትክክል ተስተካክለዋል።
    //     ቁርጥራጩ በትክክል መጣጣሙን ማረጋገጥ የደዋዩ ሃላፊነት ነው።
    //
    // ለተጨማሪ ዝርዝር አስተያየቶችን ከዚህ በታች ይመልከቱ ፡፡
    unsafe {
        // የመጀመሪያዎቹ ሁለት አካላት ከትእዛዝ ውጭ ከሆኑ ...
        if len >= 2 && is_less(v.get_unchecked(1), v.get_unchecked(0)) {
            // የመጀመሪያውን ንጥረ ነገር በተከመረበት ተለዋዋጭ ውስጥ ያንብቡ።
            // የሚከተለው የንጽጽር ሥራ panics ከሆነ `hole` ይወርዳል እና ኤለመንቱን በራስ-ሰር ወደ ቁራጭ ይጽፋል።
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(0)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(1) };
            ptr::copy_nonoverlapping(v.get_unchecked(1), v.get_unchecked_mut(0), 1);

            for i in 2..len {
                if !is_less(v.get_unchecked(i), &*tmp) {
                    break;
                }

                // ቀዳዳውን ወደ ቀኝ በማዞር `i`-th አባልን አንድ ቦታ ወደ ግራ ያንቀሳቅሱ።
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i - 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` ይወድቃል እናም `tmp` ን ወደ ቀሪው ቀዳዳ በ `v` ውስጥ ይገለብጣል ፡፡
        }
    }
}

/// የመጨረሻውን ንጥረ ነገር ትንሽ ወይም እኩል የሆነ ንጥረ ነገር እስኪያጋጥም ድረስ ወደ ግራ ያዛውረዋል።
fn shift_tail<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // ደህንነት ከዚህ በታች ያሉት ደህንነታቸው ያልተጠበቀ ክንውኖች ያለገደብ ቼክ ማውጫ ማውጫ (`get_unchecked` እና `get_unchecked_mut`) ያካትታሉ
    // እና ማህደረ ትውስታ (`ptr::copy_nonoverlapping`) ን መቅዳት.
    //
    // ሀ.ማውጫ
    //  1. የዝርዝሩን መጠን ወደ>=2 መርምረናል ፡፡
    //  2. እኛ የምናደርጋቸው ሁሉም ማውጫዎች ቢበዛ ሁልጊዜ በ `0 <= index < len-1` መካከል ናቸው።
    //
    // ለ.የማስታወሻ ቅጅ
    //  1. ትክክለኛ እንዲሆኑ የተረጋገጡ የማጣቀሻዎችን አመልካቾች እያገኘን ነው ፡፡
    //  2. ለተቆራረጡ የልዩነት ጠቋሚዎች ጠቋሚዎችን ስለምናገኝ መደራረብ አይችሉም ፡፡
    //     ይኸውም `i` እና `i+1`።
    //  3. ቁራሹ በትክክል ከተስተካከለ አባላቱ በትክክል ተስተካክለዋል።
    //     ቁርጥራጩ በትክክል መጣጣሙን ማረጋገጥ የደዋዩ ሃላፊነት ነው።
    //
    // ለተጨማሪ ዝርዝር አስተያየቶችን ከዚህ በታች ይመልከቱ ፡፡
    unsafe {
        // የመጨረሻዎቹ ሁለት አካላት ከትእዛዝ ውጭ ከሆኑ ...
        if len >= 2 && is_less(v.get_unchecked(len - 1), v.get_unchecked(len - 2)) {
            // የመጨረሻውን ንጥረ ነገር በተቆለለ የተመደበ ተለዋዋጭ ውስጥ ያንብቡ።
            // የሚከተለው የንጽጽር ሥራ panics ከሆነ `hole` ይወርዳል እና ኤለመንቱን በራስ-ሰር ወደ ቁራጭ ይጽፋል።
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(len - 1)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(len - 2) };
            ptr::copy_nonoverlapping(v.get_unchecked(len - 2), v.get_unchecked_mut(len - 1), 1);

            for i in (0..len - 2).rev() {
                if !is_less(&*tmp, v.get_unchecked(i)) {
                    break;
                }

                // ቀዳዳውን ወደ ግራ በማዞር `i`-th አባልን ወደ አንድ ቦታ ይውሰዱት።
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i + 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` ይወድቃል እናም `tmp` ን ወደ ቀሪው ቀዳዳ በ `v` ውስጥ ይገለብጣል ፡፡
        }
    }
}

/// ብዙ ከትእዛዝ ውጪ የሆኑ አባሎችን ዙሪያውን በመለወጥ በከፊል ቁርጥራጭ ይለያል ፡፡
///
/// ቁራጭ በመጨረሻ ከተስተካከለ `true` ን ይመልሳል።ይህ ተግባር *O*(*n*) በጣም የከፋ ጉዳይ ነው።
#[cold]
fn partial_insertion_sort<T, F>(v: &mut [T], is_less: &mut F) -> bool
where
    F: FnMut(&T, &T) -> bool,
{
    // የሚዛወሩ ከቅርብ ውጭ ከትእዛዝ ውጭ የሆኑ ጥንዶች ብዛት።
    const MAX_STEPS: usize = 5;
    // ቁራጩ ከዚህ አጠር ያለ ከሆነ ማንኛውንም አባላትን አይለውጡ ፡፡
    const SHORTEST_SHIFTING: usize = 50;

    let len = v.len();
    let mut i = 1;

    for _ in 0..MAX_STEPS {
        // ደህንነት-እኛ በ‹XXXX›ላይ በትክክል የታሰርነውን በግልፅ አደረግን ፡፡
        // ሁሉም የእኛ ቀጣይ ማውጫ በ `0 <= index < len` ክልል ውስጥ ብቻ ነው ያለው
        unsafe {
            // የሚቀጥለውን ጥንድ ከትእዛዝ ውጭ የሆኑ አባላትን ያግኙ።
            while i < len && !is_less(v.get_unchecked(i), v.get_unchecked(i - 1)) {
                i += 1;
            }
        }

        // ጨርሰናል?
        if i == len {
            return true;
        }

        // የአፈፃፀም ዋጋ ባለው አጭር ድርድሮች ላይ አባሎችን አይቀይሩ።
        if len < SHORTEST_SHIFTING {
            return false;
        }

        // የተገኙትን ጥንድ ንጥረ ነገሮች ይቀያይሩ።ይህ በትክክለኛው ቅደም ተከተል ያስቀምጣቸዋል ፡፡
        v.swap(i - 1, i);

        // ትንሹን ንጥረ ነገር ወደ ግራ ያዛውሩ።
        shift_tail(&mut v[..i], is_less);
        // ትልቁን ንጥረ ነገር ወደ ቀኝ ያዛውሩ።
        shift_head(&mut v[i..], is_less);
    }

    // በተገደበው የእርምጃዎች ቁጥር ውስጥ ቁራጭ መደርደር አልተሳካም።
    false
}

/// የማስገቢያ ዓይነትን በመጠቀም አንድ ቁራጭ ይለያል ፣ ይህም *O*(*n*^ 2) በጣም የከፋ ነው።
fn insertion_sort<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    for i in 1..v.len() {
        shift_tail(&mut v[..i + 1], is_less);
    }
}

/// `v` በመጠቀም heapsort, ይህም ዋስትና *ሆይ*(*n*\*log(* n*)) የከፋው-ሁኔታ በአይነታቸው.
#[cold]
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub fn heapsort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // ይህ የሁለትዮሽ ክምር የማይለዋወጥ `parent >= child` ን ያከብራል።
    let mut sift_down = |v: &mut [T], mut node| {
        loop {
            // የ `node` ልጆች
            let left = 2 * node + 1;
            let right = 2 * node + 2;

            // ትልቁን ልጅ ይምረጡ ፡፡
            let greater =
                if right < v.len() && is_less(&v[left], &v[right]) { right } else { left };

            // የማይለዋወጥ ሰው በ `node` ላይ ቢይዝ ያቁሙ።
            if greater >= v.len() || !is_less(&v[node], &v[greater]) {
                break;
            }

            // `node` ን ከትልቁ ልጅ ጋር ይቀያይሩ ፣ አንድ እርምጃ ወደ ታች ይሂዱ እና ማጣሪያውን ይቀጥሉ።
            v.swap(node, greater);
            node = greater;
        }
    };

    // በመስመራዊ ጊዜ ውስጥ ክምርውን ይገንቡ ፡፡
    for i in (0..v.len() / 2).rev() {
        sift_down(v, i);
    }

    // ከከፍታው ውስጥ ከፍተኛውን ንጥረ ነገሮችን ብቅ ይበሉ ፡፡
    for i in (1..v.len()).rev() {
        v.swap(0, i);
        sift_down(&mut v[..i], 0);
    }
}

/// ክፍልፋዮች `v` ከ `pivot` ያነሱ ንጥረ ነገሮችን ይከተላሉ ፣ ከዚያ ከ `pivot` የሚበልጡ ወይም እኩል ናቸው።
///
///
/// ከ `pivot` ያነሱ የንጥሎች ብዛት ይመልሳል።
///
/// የቅርንጫፍ ሥራዎችን ወጪ ለመቀነስ ሲባል መከፋፈል በብሎክ-ብሎክ ይከናወናል ፡፡
/// ይህ ሀሳብ በ [BlockQuicksort][pdf] ወረቀት ውስጥ ቀርቧል ፡፡
///
/// [pdf]: http://drops.dagstuhl.de/opus/volltexte/2016/6389/pdf/LIPIcs-ESA-2016-38.pdf
fn partition_in_blocks<T, F>(v: &mut [T], pivot: &T, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // በተለመደው ማገጃ ውስጥ ያሉት ንጥረ ነገሮች ብዛት።
    const BLOCK: usize = 128;

    // የክፋይ አልጎሪዝም እስኪያልቅ ድረስ የሚከተሉትን ደረጃዎች ይደግማል
    //
    // 1. ከምሰሶው በላይ ወይም እኩል የሆኑ አባሎችን ለመለየት ከግራ በኩል አንድ ብሎክን ይከታተሉ።
    // 2. ከምሰሶው ያነሱ አባሎችን ለመለየት ከቀኝ በኩል አንድ ብሎክ ይከታተሉ።
    // 3. የታወቁትን አካላት በግራ እና በቀኝ በኩል ይለዋወጡ ፡፡
    //
    // የሚከተሉትን ንጥረ ነገሮች ለተለዋጭ አካላት እንጠብቃለን
    //
    // 1. `block` - በማገጃው ውስጥ ያሉት ንጥረ ነገሮች ብዛት።
    // 2. `start` - ጠቋሚውን ወደ `offsets` ድርድር ይጀምሩ።
    // 3. `end` - የመጨረሻ ጠቋሚ ወደ `offsets` ድርድር።
    // 4. በማገጃው ውስጥ ከትዕዛዝ ውጭ የሆኑ ንጥረ ነገሮች ማውጫዎች ፣

    // በግራ በኩል ያለው የአሁኑ አግድ (ከ `l` እስከ `l.add(block_l)`))።
    let mut l = v.as_mut_ptr();
    let mut block_l = BLOCK;
    let mut start_l = ptr::null_mut();
    let mut end_l = ptr::null_mut();
    let mut offsets_l = [MaybeUninit::<u8>::uninit(); BLOCK];

    // በቀኝ በኩል ያለው የአሁኑ አግድ (ከ `r.sub(block_r)` to `r`))።
    // ደህንነት-የ .add() ሰነዶች በተለይ `vec.as_ptr().add(vec.len())` ሁል ጊዜም ደህና መሆኑን ይጠቅሳሉ
    let mut r = unsafe { l.add(v.len()) };
    let mut block_r = BLOCK;
    let mut start_r = ptr::null_mut();
    let mut end_r = ptr::null_mut();
    let mut offsets_r = [MaybeUninit::<u8>::uninit(); BLOCK];

    // FIXME: VLAs ስናገኝ ፣ አንድ ረድፍ የ `min(v.len() ድርድር ለመፍጠር ይሞክሩ ፣ 2 * አግድ) ይልቁንስ
    // ከሁለት የ `BLOCK` ርዝመት ሁለት ቋሚ መጠን ያላቸው ድርድሮች።VLAs መሸጎጫ ቀልጣፋ ሊሆኑ ይችላሉ ፡፡

    // በጠቋሚዎች `l` (inclusive) እና `r` (exclusive) መካከል ያሉትን የንጥሎች ብዛት ይመልሳል።
    fn width<T>(l: *mut T, r: *mut T) -> usize {
        assert!(mem::size_of::<T>() > 0);
        (r as usize - l as usize) / mem::size_of::<T>()
    }

    loop {
        // `l` እና `r` በጣም ሲቀራረቡ በብሎክ-በ-ክፍልፍል ክፍፍልን ጨርሰናል ፡፡
        // ከዚያ የተቀሩትን ንጥረ ነገሮች በመካከላቸው ለመከፋፈል አንዳንድ የማጣበቂያ ሥራ እንሠራለን ፡፡
        let is_done = width(l, r) <= 2 * BLOCK;

        if is_done {
            // የቀሩት አካላት ብዛት (አሁንም ከምሰሶው ጋር አይወዳደርም)።
            let mut rem = width(l, r);
            if start_l < end_l || start_r < end_r {
                rem -= BLOCK;
            }

            // የግራ እና የቀኝ ማገጃው እንዳይደራረብ የማገጃ መጠኖችን ያስተካክሉ ፣ ግን ቀሪውን ክፍተት በሙሉ ለመሸፈን ፍጹም በሆነ ሁኔታ ይጣጣሙ።
            //
            if start_l < end_l {
                block_r = rem;
            } else if start_r < end_r {
                block_l = rem;
            } else {
                block_l = rem / 2;
                block_r = rem - block_l;
            }
            debug_assert!(block_l <= BLOCK && block_r <= BLOCK);
            debug_assert!(width(l, r) == block_l + block_r);
        }

        if start_l == end_l {
            // ከግራ በኩል የ `block_l` አባሎችን ይከታተሉ።
            start_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            end_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            let mut elem = l;

            for i in 0..block_l {
                // ደህንነት-ከዚህ በታች ያሉት ደህንነታቸው ያልተጠበቀ ስራዎች የ `offset` አጠቃቀምን ያካትታሉ ፡፡
                //         በተግባሩ በሚፈለጉት ሁኔታዎች መሠረት እኛ እናርካቸዋለን ምክንያቱም
                //         1. `offsets_l` በተደራረበ የተመደበ ነው ፣ ስለሆነም የተለየ የተመደበ ነገር ተደርጎ ይወሰዳል።
                //         2. `is_less` ተግባር `bool` ን ይመልሳል።
                //            `bool` ን መጣል `isize` ን በጭራሽ አያልፍም።
                //         3. `block_l` `<= BLOCK` እንደሚሆን ዋስትና ሰጥተናል ፡፡
                //            በተጨማሪም ፣ `end_l` መጀመሪያ ላይ በቁጥቋጦው ላይ ለታወጀው የ `offsets_` የመጀመሪያ ጠቋሚ ተዘጋጅቷል ፡፡
                //            ስለሆነም ፣ በጣም በከፋ ሁኔታ ውስጥ እንኳን (የ‹XXXXXXXXXXXXXXXXXXXXCACA`R) ሁሉም ሐሳቦች ወደ ሐሰት እንደሚመለሱ እናውቃለን ፣ ቢበዛ መጨረሻውን በ 1 ባይት ብቻ እንደሆንን እናውቃለን ፡፡
                //        እዚህ ሌላ ደህንነቱ የተጠበቀ ክወና `elem` ን ማዛወር ነው።
                //        ሆኖም ፣ `elem` መጀመሪያ ላይ ሁል ጊዜ የሚሰራውን ቁራጭ መጀመሪያ ጠቋሚ ነበር።
                unsafe {
                    // ቅርንጫፍ አልባ ንፅፅር.
                    *end_l = i as u8;
                    end_l = end_l.offset(!is_less(&*elem, pivot) as isize);
                    elem = elem.offset(1);
                }
            }
        }

        if start_r == end_r {
            // ከቀኝ በኩል የ `block_r` አባሎችን ይከታተሉ።
            start_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            end_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            let mut elem = r;

            for i in 0..block_r {
                // ደህንነት-ከዚህ በታች ያሉት ደህንነታቸው ያልተጠበቀ ስራዎች የ `offset` አጠቃቀምን ያካትታሉ ፡፡
                //         በተግባሩ በሚፈለጉት ሁኔታዎች መሠረት እኛ እናርካቸዋለን ምክንያቱም
                //         1. `offsets_r` በተደራረበ የተመደበ ነው ፣ ስለሆነም የተለየ የተመደበ ነገር ተደርጎ ይወሰዳል።
                //         2. `is_less` ተግባር `bool` ን ይመልሳል።
                //            `bool` ን መጣል `isize` ን በጭራሽ አያልፍም።
                //         3. `block_r` `<= BLOCK` እንደሚሆን ዋስትና ሰጥተናል ፡፡
                //            በተጨማሪም ፣ `end_r` መጀመሪያ ላይ በቁጥቋጦው ላይ ለታወጀው የ `offsets_` የመጀመሪያ ጠቋሚ ተዘጋጅቷል ፡፡
                //            ስለሆነም ፣ በጣም በከፋ ሁኔታ ውስጥ እንኳን (የ `is_less` ሁሉም ልመናዎች ወደ እውነት እንደሚመለሱ) እኛ መጨረሻውን የምናልፈው ቢበዛ 1 ባይት ብቻ እንደሆንን እናውቃለን።
                //        እዚህ ሌላ ደህንነቱ የተጠበቀ ክወና `elem` ን ማዛወር ነው።
                //        ሆኖም ፣ `elem` በመጀመሪያ መጨረሻ ላይ `1 *sizeof(T)` ነበር እና እኛ ከመድረሱ በፊት በ `1* sizeof(T)` ቀንሰነው ፡፡
                //        በተጨማሪም ፣ `block_r` ከ `BLOCK` በታች መሆኑን የተረጋገጠ ሲሆን `elem` ደግሞ ቢበዛ ወደ ቁራጭ መጀመሪያ ይጠቁማል ፡፡
                unsafe {
                    // ቅርንጫፍ አልባ ንፅፅር.
                    elem = elem.offset(-1);
                    *end_r = i as u8;
                    end_r = end_r.offset(is_less(&*elem, pivot) as isize);
                }
            }
        }

        // በግራ እና በቀኝ በኩል ለመቀያየር ከትእዛዝ ውጭ የሆኑ ንጥረ ነገሮች ብዛት።
        let count = cmp::min(width(start_l, end_l), width(start_r, end_r));

        if count > 0 {
            macro_rules! left {
                () => {
                    l.offset(*start_l as isize)
                };
            }
            macro_rules! right {
                () => {
                    r.offset(-(*start_r as isize) - 1)
                };
            }

            // አንድ ጥንድ በወቅቱ ከመቀየር ይልቅ የብስክሌት ሽግግርን ማከናወን የበለጠ ውጤታማ ነው።
            // ይህ ከመለዋወጥ ጋር በጥብቅ አይመሳሰልም ፣ ግን አነስተኛ የማስታወስ ክዋኔዎችን በመጠቀም ተመሳሳይ ውጤት ያስገኛል።
            //
            unsafe {
                let tmp = ptr::read(left!());
                ptr::copy_nonoverlapping(right!(), left!(), 1);

                for _ in 1..count {
                    start_l = start_l.offset(1);
                    ptr::copy_nonoverlapping(left!(), right!(), 1);
                    start_r = start_r.offset(1);
                    ptr::copy_nonoverlapping(right!(), left!(), 1);
                }

                ptr::copy_nonoverlapping(&tmp, right!(), 1);
                mem::forget(tmp);
                start_l = start_l.offset(1);
                start_r = start_r.offset(1);
            }
        }

        if start_l == end_l {
            // በግራ እገዳው ውስጥ ያሉት ሁሉም ከትዕዛዝ ውጭ የሆኑ አካላት ተንቀሳቅሰዋል።ወደ ቀጣዩ ማገጃ ይሂዱ።
            l = unsafe { l.offset(block_l as isize) };
        }

        if start_r == end_r {
            // በትክክለኛው አግድ ውስጥ ከትዕዛዝ ውጭ ያሉ ሁሉም አካላት ተንቀሳቅሰዋል።ወደ ቀዳሚው ማገጃ ይሂዱ።
            r = unsafe { r.offset(-(block_r as isize)) };
        }

        if is_done {
            break;
        }
    }

    // አሁን የሚቀረው ቢበዛ አንድ ብሎክ ነው (በግራ ወይም በቀኝ) የሚንቀሳቀሱ ከትእዛዝ ውጭ አካላት ያሉት ፡፡
    // እንደነዚህ ያሉት ቀሪ አካላት በቀላሉ በእገታቸው ውስጥ ወደ መጨረሻው ሊዘዋወሩ ይችላሉ ፡፡
    //

    if start_l < end_l {
        // የግራ ማገጃው ይቀራል።
        // ቀሪዎቹን ከትእዛዝ ውጭ የሆኑትን ወደ ቀኝ ቀኝ ያንቀሳቅሱ።
        debug_assert_eq!(width(l, r), block_l);
        while start_l < end_l {
            unsafe {
                end_l = end_l.offset(-1);
                ptr::swap(l.offset(*end_l as isize), r.offset(-1));
                r = r.offset(-1);
            }
        }
        width(v.as_mut_ptr(), r)
    } else if start_r < end_r {
        // ትክክለኛው ማገጃ ይቀራል
        // ቀሪዎቹን ከትእዛዝ ውጭ የሆኑትን ወደ ግራ ግራው ያንቀሳቅሱ።
        debug_assert_eq!(width(l, r), block_r);
        while start_r < end_r {
            unsafe {
                end_r = end_r.offset(-1);
                ptr::swap(l, r.offset(-(*end_r as isize) - 1));
                l = l.offset(1);
            }
        }
        width(v.as_mut_ptr(), l)
    } else {
        // ሌላ ምንም ማድረግ የለብንም ፣ ጨርሰናል ፡፡
        width(v.as_mut_ptr(), l)
    }
}

/// ክፍልፋዮች `v` ከ `v[pivot]` ያነሱ ንጥረ ነገሮችን ይከተላሉ ፣ ከዚያ ደግሞ ከ `v[pivot]` የሚበልጡ ወይም እኩል ናቸው።
///
///
/// አንድ ጥንድ ይመልሳል
///
/// 1. ከ `v[pivot]` ያነሱ ንጥረ ነገሮች ብዛት።
/// 2. `v` ቀድሞውኑ ከተከፈለ እውነት ነው።
fn partition<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    let (mid, was_partitioned) = {
        // በተቆራረጡ መጀመሪያ ላይ ምሰሶውን ያስቀምጡ ፡፡
        v.swap(0, pivot);
        let (pivot, v) = v.split_at_mut(1);
        let pivot = &mut pivot[0];

        // ቅልጥፍናን ለማግኘት ምሰሶውን በተደራራቢ በተመደበ ተለዋዋጭ ውስጥ ያንብቡ ፡፡
        // የሚከተለው የንፅፅር ክዋኔ panics ከሆነ ምሰሶው በራስ-ሰር ወደ ቁራጭ ይፃፋል።
        let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
        let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
        let pivot = &*tmp;

        // ከትእዛዝ ውጭ የመጀመሪያዎቹን ጥንድ ያግኙ።
        let mut l = 0;
        let mut r = v.len();

        // ደህንነት-ከዚህ በታች ያለው ደህንነቱ የተጠበቀ ድርድርን ጠቋሚ ማድረግን ያካትታል ፡፡
        // ለመጀመሪያው-እኛ ቀድሞውኑ እዚህ በ `l < r` በመፈተሽ ላይ ያሉትን ወሰን እናደርጋለን ፡፡
        // ለሁለተኛው-በመጀመሪያ እኛ `l == 0` እና `r == v.len()` አለን እናም በእያንዳንዱ የመረጃ ጠቋሚ ሥራ ላይ ያንን `l < r` ን ፈትሸናል ፡፡
        //                     ከእዚህ ጀምሮ `r` ከመጀመሪያው ጀምሮ ልክ ሆኖ እንደታየው ቢያንስ `r == l` መሆን እንዳለበት እናውቃለን ፡፡
        unsafe {
            // ከምስሶው የበለጠ ወይም እኩል የሆነውን የመጀመሪያውን ንጥረ ነገር ያግኙ።
            while l < r && is_less(v.get_unchecked(l), pivot) {
                l += 1;
            }

            // የመጨረሻውን ንጥረ ነገር ምሰሶውን ትንሽ ያግኙ።
            while l < r && !is_less(v.get_unchecked(r - 1), pivot) {
                r -= 1;
            }
        }

        (l + partition_in_blocks(&mut v[l..r], pivot, is_less), l >= r)

        // `_pivot_guard` ከቦታ ወጥቶ ምሰሶውን (በቁልል የተመደበ ተለዋዋጭ ነው) መጀመሪያ ወደነበረበት ቁራጭ ይጽፋል ፡፡
        // ደህንነትን ለማረጋገጥ ይህ እርምጃ ወሳኝ ነው!
        //
    };

    // በሁለቱ ክፍልፋዮች መካከል ምሰሶውን ያስቀምጡ ፡፡
    v.swap(0, mid);

    (mid, was_partitioned)
}

/// ክፍልፋዮች `v` ከ `v[pivot]` ጋር እኩል ወደሆኑ ንጥረ ነገሮች እና ከ `v[pivot]` በላይ የሆኑ ንጥረ ነገሮችን ይከተላሉ።
///
/// ከምሰሶው ጋር እኩል የሆነውን የንጥሎች ብዛት ይመልሳል።
/// `v` ከምሰሶው ያነሱ ንጥረ ነገሮችን እንደማይይዝ ይታሰባል።
fn partition_equal<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // በተቆራረጡ መጀመሪያ ላይ ምሰሶውን ያስቀምጡ ፡፡
    v.swap(0, pivot);
    let (pivot, v) = v.split_at_mut(1);
    let pivot = &mut pivot[0];

    // ቅልጥፍናን ለማግኘት ምሰሶውን በተደራራቢ በተመደበ ተለዋዋጭ ውስጥ ያንብቡ ፡፡
    // የሚከተለው የንፅፅር ክዋኔ panics ከሆነ ምሰሶው በራስ-ሰር ወደ ቁራጭ ይፃፋል።
    // ደህንነት እዚህ ያለው ጠቋሚ ትክክለኛ ነው ምክንያቱም ከተቆራረጠ አንድ ማጣቀሻ የተገኘ ነው ፡፡
    let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
    let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
    let pivot = &*tmp;

    // አሁን ቁርጥራጩን ክፈል ፡፡
    let mut l = 0;
    let mut r = v.len();
    loop {
        // ደህንነት-ከዚህ በታች ያለው ደህንነቱ የተጠበቀ ድርድርን ጠቋሚ ማድረግን ያካትታል ፡፡
        // ለመጀመሪያው-እኛ ቀድሞውኑ እዚህ በ `l < r` በመፈተሽ ላይ ያሉትን ወሰን እናደርጋለን ፡፡
        // ለሁለተኛው-በመጀመሪያ እኛ `l == 0` እና `r == v.len()` አለን እናም በእያንዳንዱ የመረጃ ጠቋሚ ሥራ ላይ ያንን `l < r` ን ፈትሸናል ፡፡
        //                     ከእዚህ ጀምሮ `r` ከመጀመሪያው ጀምሮ ልክ ሆኖ እንደታየው ቢያንስ `r == l` መሆን እንዳለበት እናውቃለን ፡፡
        unsafe {
            // ከምሰሶው የበለጠውን የመጀመሪያውን ንጥረ ነገር ያግኙ።
            while l < r && !is_less(pivot, v.get_unchecked(l)) {
                l += 1;
            }

            // የመጨረሻውን አካል ከምሰሶው ጋር እኩል ያግኙ።
            while l < r && is_less(pivot, v.get_unchecked(r - 1)) {
                r -= 1;
            }

            // ጨርሰናል?
            if l >= r {
                break;
            }

            // የተገኙትን ጥንድ ከትእዛዝ ውጭ ይለዋወጡ።
            r -= 1;
            ptr::swap(v.get_unchecked_mut(l), v.get_unchecked_mut(r));
            l += 1;
        }
    }

    // የ `l` አባላትን ከምሰሶው ጋር እኩል አገኘን ፡፡ለምሰሶው ራሱ መለያ 1 ያክሉ።
    l + 1

    // `_pivot_guard` ከቦታ ወጥቶ ምሰሶውን (በቁልል የተመደበ ተለዋዋጭ ነው) መጀመሪያ ወደነበረበት ቁራጭ ይጽፋል ፡፡
    // ደህንነትን ለማረጋገጥ ይህ እርምጃ ወሳኝ ነው!
}

/// በተመጣጣኝ ፍጥነት ሚዛናዊ ያልሆነ ክፍልፋዮችን ሊያስከትሉ የሚችሉ ቅጦችን ለመስበር በመሞከር ዙሪያውን አንዳንድ ክፍሎችን ይበትናል።
///
#[cold]
fn break_patterns<T>(v: &mut [T]) {
    let len = v.len();
    if len >= 8 {
        // ከ‹XXXX›ወረቀት በ‹ጆርጅ ማርዛሊያ›የውሸት-ኢንደመር ቁጥር ማመንጫ ፡፡
        let mut random = len as u32;
        let mut gen_u32 = || {
            random ^= random << 13;
            random ^= random >> 17;
            random ^= random << 5;
            random
        };
        let mut gen_usize = || {
            if usize::BITS <= 32 {
                gen_u32() as usize
            } else {
                (((gen_u32() as u64) << 32) | (gen_u32() as u64)) as usize
            }
        };

        // የዘፈቀደ ቁጥሮች ውሰድ ይህን ቁጥር ሞዱሎ።
        // `len` ከ `isize::MAX` የማይበልጥ ስለሆነ ቁጥሩ ከ `usize` ጋር ይገጥማል።
        let modulus = len.next_power_of_two();

        // አንዳንድ የምሰሶ እጩዎች በዚህ መረጃ ጠቋሚ አቅራቢያ ይገኛሉ ፡፡እነሱን በዘፈቀደ እናድርጋቸው ፡፡
        let pos = len / 4 * 2;

        for i in 0..3 {
            // የዘፈቀደ ቁጥር ሞዱሎ `len` ይፍጠሩ።
            // ሆኖም ፣ ውድ የሆኑ ክዋኔዎችን ለማስቀረት በመጀመሪያ እኛ የሁለት ሞዱሎ ሀይልን እንወስደዋለን ፣ እና ከዚያ በ `[0, len - 1]` ክልል ውስጥ እስከሚገባ ድረስ በ `len` እንቀንሳለን።
            //
            let mut other = gen_usize() & (modulus - 1);

            // `other` ከ `2 * len` በታች እንደሚሆን ዋስትና ተሰጥቷል።
            if other >= len {
                other -= len;
            }

            v.swap(pos - 1 + i, other);
        }
    }
}

/// በ `v` ውስጥ ምሰሶ ይመርጣል እና ቁርጥራጭ ቀድሞውኑ ከተስተካከለ መረጃ ጠቋሚውን እና `true` ን ይመልሳል።
///
/// በ‹XXXX›ውስጥ ያሉ ንጥረ ነገሮች በሂደቱ እንደገና ሊታዘዙ ይችላሉ ፡፡
fn choose_pivot<T, F>(v: &mut [T], is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    // መካከለኛ-መካከለኛ ዘዴን ለመምረጥ አነስተኛ ርዝመት።
    // አጫጭር ቁርጥራጮች ቀላሉን-ከሶስት ዘዴ ይጠቀማሉ ፡፡
    const SHORTEST_MEDIAN_OF_MEDIANS: usize = 50;
    // በዚህ ተግባር ውስጥ ሊከናወኑ የሚችሉ ከፍተኛው የስዋፕ ብዛት።
    const MAX_SWAPS: usize = 4 * 3;

    let len = v.len();

    // ሶስት ምሰሶዎችን የምንመረጥበት አቅራቢያ ነው ፡፡
    let mut a = len / 4 * 1;
    let mut b = len / 4 * 2;
    let mut c = len / 4 * 3;

    // መረጃ ጠቋሚዎችን በሚለዩበት ጊዜ ልናከናውንባቸው የምንችላቸውን አጠቃላይ ስዋፕ ብዛት ይቆጥራል ፡፡
    let mut swaps = 0;

    if len >= 8 {
        // ስዋፕስ ኢንዴክሶች ስለዚህ `v[a] <= v[b]`።
        let mut sort2 = |a: &mut usize, b: &mut usize| unsafe {
            if is_less(v.get_unchecked(*b), v.get_unchecked(*a)) {
                ptr::swap(a, b);
                swaps += 1;
            }
        };

        // ስዋፕስ ኢንዴክሶች ስለዚህ `v[a] <= v[b] <= v[c]`።
        let mut sort3 = |a: &mut usize, b: &mut usize, c: &mut usize| {
            sort2(a, b);
            sort2(b, c);
            sort2(a, b);
        };

        if len >= SHORTEST_MEDIAN_OF_MEDIANS {
            // የ `v[a - 1], v[a], v[a + 1]` ን መካከለኛ ያገኝና መረጃ ጠቋሚውን ወደ `a` ያከማቻል።
            let mut sort_adjacent = |a: &mut usize| {
                let tmp = *a;
                sort3(&mut (tmp - 1), a, &mut (tmp + 1));
            };

            // በ `a` ፣ `b` እና `c` አካባቢዎች ውስጥ መካከለኛዎችን ያግኙ ፡፡
            sort_adjacent(&mut a);
            sort_adjacent(&mut b);
            sort_adjacent(&mut c);
        }

        // መካከለኛውን በ `a` ፣ `b` እና `c` መካከል ያግኙ።
        sort3(&mut a, &mut b, &mut c);
    }

    if swaps < MAX_SWAPS {
        (b, swaps == 0)
    } else {
        // ከፍተኛው የስዋፕ ብዛት ተከናውኗል ፡፡
        // ቁራጭ ቁልቁል እየወረደ ወይም በአብዛኛው እየወረደ ነው ፣ ስለሆነም መቀልበስ ምናልባት በፍጥነት ለመደርደር ይረዳል ፡፡
        v.reverse();
        (len - 1 - b, true)
    }
}

/// Surs `v` ን እንደገና ደጋግሞ።
///
/// ቁራጭ በመጀመሪያው ድርድር ውስጥ አንድ ቀዳሚ ነበረው ከሆነ እንደ `pred` ይገለጻል።
///
/// `limit` ወደ `heapsort` ከመቀየርዎ በፊት የተፈቀዱ ሚዛናዊ ያልሆኑ ክፍፍሎች ቁጥር ነው።
/// ዜሮ ከሆነ ይህ ተግባር ወዲያውኑ ወደ ድንክ ሥራ ይለወጣል።
fn recurse<'a, T, F>(mut v: &'a mut [T], is_less: &mut F, mut pred: Option<&'a T>, mut limit: u32)
where
    F: FnMut(&T, &T) -> bool,
{
    // እስከዚህ ርዝመት ድረስ ያሉት ቁርጥራጮች የማስገቢያ ዓይነትን በመጠቀም ይደረደራሉ ፡፡
    const MAX_INSERTION: usize = 20;

    // እውነት ነው የመጨረሻው ክፍፍል በተመጣጣኝ ሚዛናዊ ከሆነ።
    let mut was_balanced = true;
    // እውነት ነው የመጨረሻው ክፍፍል አባላትን ካላደባለቀ (ቁርጥጩ ቀድሞውኑ ተከፍሏል)።
    let mut was_partitioned = true;

    loop {
        let len = v.len();

        // በጣም አጭር ቁርጥራጮች የማስገቢያ ዓይነትን በመጠቀም ይደረደራሉ ፡፡
        if len <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // በጣም ብዙ መጥፎ የምሰሶ ምርጫዎች ከተደረጉ ፣ የ `O(n * log(n))` በጣም የከፋ ጉዳይን ለማረጋገጥ በቀላሉ ወደ ኋላ ተመልሰህ ወደ ኋላ ተመልሰህ ወደ ኋላ ተመልሰህ ወደ አናት ሂድ ፡፡
        //
        if limit == 0 {
            heapsort(v, is_less);
            return;
        }

        // የመጨረሻው ክፍፍል ሚዛናዊ ካልሆነ ፣ በዙሪያው ያሉትን አንዳንድ አካላት በማዛወር በተቆራጩ ውስጥ ቅጦችን ለመስበር ይሞክሩ።
        // በዚህ ጊዜ የተሻለ ምሰሶ እንደምንመርጥ ተስፋ እናደርጋለን ፡፡
        if !was_balanced {
            break_patterns(v);
            limit -= 1;
        }

        // ምሰሶውን ይምረጡ እና ቁርጥራጭ ቀድሞውኑ እንደተስተካከለ ለመገመት ይሞክሩ።
        let (pivot, likely_sorted) = choose_pivot(v, is_less);

        // የመጨረሻው ክፍፍል በትክክል ሚዛናዊ ከሆነ እና አባላትን ካላደባለቀ ፣ እና የምስሶ ምርጫው ቁራጩ ቀድሞውኑ የተስተካከለ ሊሆን ይችላል የሚል ግምት ካለው ...
        //
        if was_balanced && was_partitioned && likely_sorted {
            // ከትእዛዝ ውጭ የሆኑ ብዙ አባላትን ለይቶ ለማወቅ እና ቦታዎችን ለማስተካከል ለመቀየር ይሞክሩ።
            // ቁርጥራጩ ሙሉ በሙሉ ተስተካክሎ ከጨረሰ ፣ ጨርሰናል ፡፡
            if partial_insertion_sort(v, is_less) {
                return;
            }
        }

        // የተመረጠው ምሰሶ ከቀዳሚው ጋር እኩል ከሆነ ፣ በተቆራረጡ ውስጥ ያለው አነስተኛ ንጥረ ነገር ነው።
        // ቁርጥራጩን ከምስሶው ጋር በሚበልጡ እና በሚመሳሰሉ አካላት ይከፋፍሉ።
        // ቁርጥራጭ ብዙ የተባዙ አባሎችን ሲይዝ ይህ ጉዳይ ብዙውን ጊዜ ይመታል ፡፡
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // ከምሰሶው የሚበልጡ አባላትን መደርደርን ይቀጥሉ።
                v = &mut { v }[mid..];
                continue;
            }
        }

        // ቁርጥራጩን ክፍልፍል ፡፡
        let (mid, was_p) = partition(v, pivot, is_less);
        was_balanced = cmp::min(mid, len - mid) >= len / 8;
        was_partitioned = was_p;

        // ቁርጥራጩን ወደ `left` ፣ `pivot` እና `right` ይከፍሉ ፡፡
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        // ጠቅላላውን የመደጋገም ጥሪዎች ቁጥር ለመቀነስ እና አነስተኛ የቁልል ቦታን ለመመገብ ብቻ በአጭሩ በኩል ይመልሱ።
        // ከዚያ በረጅሙ ጎን ብቻ ይቀጥሉ (ይህ ከጅራት መመለስ ጋር ተመሳሳይ ነው)።
        //
        if left.len() < right.len() {
            recurse(left, is_less, pred, limit);
            v = right;
            pred = Some(pivot);
        } else {
            recurse(right, is_less, Some(pivot), limit);
            v = left;
        }
    }
}

/// ስርዓተ-ጥለት የሚያጣጥል ፈጣን ፈለግ በመጠቀም XXXXXXXXXXXXXXXXXXXXXXXXXXXEeee ይህም *O*(*n*\*log(* n*)) በጣም የከፋ ጉዳይ ነው)።
pub fn quicksort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // መደርደር በዜሮ መጠን ዓይነቶች ላይ ትርጉም ያለው ባህሪ የለውም ፡፡
    if mem::size_of::<T>() == 0 {
        return;
    }

    // የተመጣጠነ ክፍልፋዮች ብዛት ወደ `floor(log2(len)) + 1` ይገድቡ።
    let limit = usize::BITS - v.len().leading_zeros();

    recurse(v, &mut is_less, None, limit);
}

fn partition_at_index_loop<'a, T, F>(
    mut v: &'a mut [T],
    mut index: usize,
    is_less: &mut F,
    mut pred: Option<&'a T>,
) where
    F: FnMut(&T, &T) -> bool,
{
    loop {
        // እስከዚህ ርዝመት ድረስ ለሚሰነጣጥሩ ቁርጥራጮች በቀላሉ ለመደርደር ምናልባት ፈጣን ነው ፡፡
        const MAX_INSERTION: usize = 10;
        if v.len() <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // ምሰሶ ይምረጡ
        let (pivot, _) = choose_pivot(v, is_less);

        // የተመረጠው ምሰሶ ከቀዳሚው ጋር እኩል ከሆነ ፣ በተቆራረጡ ውስጥ ያለው አነስተኛ ንጥረ ነገር ነው።
        // ቁርጥራጩን ከምስሶው ጋር በሚበልጡ እና በሚመሳሰሉ አካላት ይከፋፍሉ።
        // ቁርጥራጭ ብዙ የተባዙ አባሎችን ሲይዝ ይህ ጉዳይ ብዙውን ጊዜ ይመታል ፡፡
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // የእኛን ማውጫ (ኢንዴክስ) ካሳለፍን ከዚያ ጥሩ ነን ፡፡
                if mid > index {
                    return;
                }

                // አለበለዚያ ከምሰሶው የሚበልጡ አባሎችን መደርደርን ይቀጥሉ።
                v = &mut v[mid..];
                index = index - mid;
                pred = None;
                continue;
            }
        }

        let (mid, _) = partition(v, pivot, is_less);

        // ቁርጥራጩን ወደ `left` ፣ `pivot` እና `right` ይከፍሉ ፡፡
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        if mid < index {
            v = right;
            index = index - mid - 1;
            pred = Some(pivot);
        } else if mid > index {
            v = left;
        } else {
            // partition() አጋማሽ በኋላ ሁሉንም ነገሮች የበለጠ ናቸው ወይም አጋማሽ ጋር እኩል መሆኑን ዋስትና ጀምሮ አጋማሽ==ኢንዴክስ ከሆኑ, ከዚያም እኛ, ጨርሰዋል.
            //
            return;
        }
    }
}

pub fn partition_at_index<T, F>(
    v: &mut [T],
    index: usize,
    mut is_less: F,
) -> (&mut [T], &mut T, &mut [T])
where
    F: FnMut(&T, &T) -> bool,
{
    use cmp::Ordering::Greater;
    use cmp::Ordering::Less;

    if index >= v.len() {
        panic!("partition_at_index index {} greater than length of slice {}", index, v.len());
    }

    if mem::size_of::<T>() == 0 {
        // መደርደር በዜሮ መጠን ዓይነቶች ላይ ትርጉም ያለው ባህሪ የለውም ፡፡ምንም ነገር አታድርግ ፡፡
    } else if index == v.len() - 1 {
        // ከፍተኛውን ንጥረ ነገር ይፈልጉ እና በድርድሩ የመጨረሻ ቦታ ላይ ያድርጉት።
        // እኛ ባዶ መሆን እንደሌለብን ስለምናውቅ እዚህ `unwrap()` ን ለመጠቀም ነፃ ነን።
        let (max_index, _) = v
            .iter()
            .enumerate()
            .max_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(max_index, index);
    } else if index == 0 {
        // ደቂቃ ንጥረ ነገር ይፈልጉ እና በድርድሩ የመጀመሪያ ቦታ ላይ ያድርጉት።
        // እኛ ባዶ መሆን እንደሌለብን ስለምናውቅ እዚህ `unwrap()` ን ለመጠቀም ነፃ ነን።
        let (min_index, _) = v
            .iter()
            .enumerate()
            .min_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(min_index, index);
    } else {
        partition_at_index_loop(v, index, &mut is_less, None);
    }

    let (left, right) = v.split_at_mut(index);
    let (pivot, right) = right.split_at_mut(1);
    let pivot = &mut pivot[0];
    (left, pivot, right)
}