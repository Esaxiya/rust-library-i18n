//! በተቆራረጡ አንቀሳቃሾች የሚጠቀሙ ማክሮዎች ፡፡

// ባዶ እና ብድርን ማስመዝገብ ከፍተኛ የአፈፃፀም ለውጥ ያመጣል
macro_rules! is_empty {
    // የ ZST ተደጋጋሚ ርዝመት የምንለዋወጥበት መንገድ ይህ ለ ZST እና ለ ZST ላልሆኑ ይሠራል።
    //
    ($self: ident) => {
        $self.ptr.as_ptr() as *const T == $self.end
    };
}

// አንዳንድ የድንበር ቼኮችን ለማስወገድ (`position` ን ይመልከቱ) ፣ በተወሰነ ባልጠበቀው መንገድ ርዝመቱን እናሰላለን።
// (በ‹codegen/slice-position-bound-check››ተፈትኗል ፡፡)
macro_rules! len {
    ($self: ident) => {{
        #![allow(unused_unsafe)] // እኛ አንዳንድ ጊዜ ደህንነቱ ባልተጠበቀ ማገጃ ውስጥ እንጠቀማለን

        let start = $self.ptr;
        let size = size_from_ptr(start.as_ptr());
        if size == 0 {
            // ይህ _cannot_ የ `unchecked_sub` ን ይጠቀማል ምክንያቱም እኛ በመጠቅለል ላይ በመመርኮዝ ረዥም የ ZST ቁርጥራጭ አነቃቂዎችን ርዝመት ይወክላል ፡፡
            //
            ($self.end as usize).wrapping_sub(start.as_ptr() as usize)
        } else {
            // `start <= end` መሆኑን እናውቃለን ፣ ስለሆነም በተፈረመ ሁኔታ ማስተላለፍ ከሚያስፈልገው ከ `offset_from` በተሻለ ሊያከናውን ይችላል።
            // እዚህ ተስማሚ ባንዲራዎችን በማቀናበር ለ LLVM ይህንን መናገር እንችላለን ፣ ይህም የድንበር ፍተሻዎችን ለማስወገድ ይረዳል ፡፡
            // ደህንነት-በማይለዋወጥ ዓይነት ፣ `start <= end`
            //
            let diff = unsafe { unchecked_sub($self.end as usize, start.as_ptr() as usize) };
            // ለኤልኤልቪኤም እንዲሁ ጠቋሚዎቹ በትክክለኛው የአይነት ብዛታቸው የተለዩ መሆናቸውን ከ `(end - start) < size` ይልቅ `len() == 0` ን ወደ `start == end` ማመቻቸት ይችላል ፡፡
            //
            // ደህንነት-በአይነቱ የማይለዋወጥ ጠቋሚዎች እንዲሁ ተስተካክለዋል
            //         በመካከላቸው ያለው ርቀት ባለብዙ ጠቋሚ መጠን መሆን አለበት
            //
            unsafe { exact_div(diff, size) }
        }
    }};
}

// የ `Iter` እና `IterMut` ተመላሾች የጋራ ትርጉም
macro_rules! iterator {
    (
        struct $name:ident -> $ptr:ty,
        $elem:ty,
        $raw_mut:tt,
        {$( $mut_:tt )?},
        {$($extra:tt)*}
    ) => {
        // የመጀመሪያውን ንጥረ ነገር ይመልሳል እና የተደጋጋሚውን ጅምር በ 1 ወደ ፊት ያራምዳል።
        // ከተሰየመ ተግባር ጋር ሲነፃፀር አፈፃፀምን በእጅጉ ያሻሽላል።
        // ተደጋጋሚው ባዶ መሆን የለበትም።
        macro_rules! next_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.post_inc_start(1)}
        }

        // የመጨረሻውን ንጥረ ነገር ይመልሳል እና የአመልካቹን መጨረሻ በ 1 ወደ ኋላ ይመልሳል።
        // ከተሰየመ ተግባር ጋር ሲነፃፀር አፈፃፀምን በእጅጉ ያሻሽላል።
        // ተደጋጋሚው ባዶ መሆን የለበትም።
        macro_rules! next_back_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.pre_dec_end(1)}
        }

        // የተደጋጋሚውን መጨረሻ በ `n` ወደኋላ በማዞር ቲ ZST በሚሆንበት ጊዜ ተደጋጋሚውን ይቀንሳል።
        // `n` ከ `self.len()` መብለጥ የለበትም።
        macro_rules! zst_shrink {
            ($self: ident, $n: ident) => {
                $self.end = ($self.end as * $raw_mut u8).wrapping_offset(-$n) as * $raw_mut T;
            }
        }

        impl<'a, T> $name<'a, T> {
            // ከተደጋጋሚው አንድ ቁራጭ ለመፍጠር የረዳቱ ተግባር።
            #[inline(always)]
            fn make_slice(&self) -> &'a [T] {
                // ደህንነት-ተደጋጋሚው ጠቋሚ ካለው ቁራጭ የተፈጠረ ነው
                // `self.ptr` እና ርዝመት `len!(self)`.
                // ይህ ለ `from_raw_parts` ሁሉም ቅድመ-ሁኔታዎች መሟላታቸውን ያረጋግጣል ፡፡
                unsafe { from_raw_parts(self.ptr.as_ptr(), len!(self)) }
            }

            // የድግግሞሹን ጅምር በ `offset` አካላት ወደ ፊት ለማንቀሳቀስ የረዳቱ ተግባር ፣ የድሮውን ጅምር ይመልሳል።
            //
            // ማካካሻ ከ `self.len()` መብለጥ የለበትም ምክንያቱም ደህንነቱ ያልተጠበቀ።
            #[inline(always)]
            unsafe fn post_inc_start(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    let old = self.ptr.as_ptr();
                    // ደህንነት ደዋዩ `offset` ከ `self.len()` እንደማይበልጥ ዋስትና ይሰጣል ፣
                    // ስለዚህ ይህ አዲስ ጠቋሚ `self` ውስጥ ነው እናም ስለሆነም ዋጋ ቢስ እንደሚሆን ዋስትና ይሰጣል።
                    self.ptr = unsafe { NonNull::new_unchecked(self.ptr.as_ptr().offset(offset)) };
                    old
                }
            }

            // አዲሱን መጨረሻ በመመለስ የተደጋጋሚውን መጨረሻ በ `offset` አካላት ወደ ኋላ ለማንቀሳቀስ የረዳት ተግባር።
            //
            // ማካካሻ ከ `self.len()` መብለጥ የለበትም ምክንያቱም ደህንነቱ ያልተጠበቀ።
            #[inline(always)]
            unsafe fn pre_dec_end(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    // ደህንነት ደዋዩ `offset` ከ `self.len()` እንደማይበልጥ ዋስትና ይሰጣል ፣
                    // `isize` ን ላለማጥለቅ የተረጋገጠ።
                    // እንዲሁም የተገኘው ጠቋሚ በ X0 `slice` ገደቦች ውስጥ ነው ፣ ይህም ለ `offset` ሌሎች መስፈርቶችን ያሟላል ፡፡
                    self.end = unsafe { self.end.offset(-offset) };
                    self.end
                }
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T> ExactSizeIterator for $name<'_, T> {
            #[inline(always)]
            fn len(&self) -> usize {
                len!(self)
            }

            #[inline(always)]
            fn is_empty(&self) -> bool {
                is_empty!(self)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> Iterator for $name<'a, T> {
            type Item = $elem;

            #[inline]
            fn next(&mut self) -> Option<$elem> {
                // በመቁረጥ ሊተገበር ይችላል ፣ ግን ይህ የድንበር ፍተሻዎችን ያስወግዳል

                // ደህንነት-የተቆራረጠ ጅምር ጠቋሚ ጀምሮ የ `assume` ጥሪዎች ደህንነታቸው የተጠበቀ ነው
                // ባዶ-ያልሆነ መሆን አለበት ፣ እና ዜድ-አልባ በሆኑት ላይ ያሉ ቁርጥራጮችም እንዲሁ የኑል ያልሆነ የመጨረሻ ጠቋሚ ሊኖራቸው ይገባል።
                // ተደጋጋሚው መጀመሪያ ባዶ መሆኑን ስለምናረጋግጥ ወደ `next_unchecked!` ጥሪው ደህንነቱ የተጠበቀ ነው።
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                let exact = len!(self);
                (exact, Some(exact))
            }

            #[inline]
            fn count(self) -> usize {
                len!(self)
            }

            #[inline]
            fn nth(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // ይህ ተሟጋች አሁን ባዶ ነው ፡፡
                    if mem::size_of::<T>() == 0 {
                        // `ptr` በጭራሽ 0 ላይሆን ስለሚችል በዚህ መንገድ ማድረግ አለብን ፣ ግን `end` ሊሆን ይችላል (በመጠቅለል ምክንያት)።
                        //
                        self.end = self.ptr.as_ptr();
                    } else {
                        // ደህንነት ቲቲ ZST ካልሆነ መጨረሻው 0 ሊሆን አይችልም ምክንያቱም ptr 0 አይደለም እና መጨረሻ>=ptr
                        unsafe {
                            self.ptr = NonNull::new_unchecked(self.end as *mut T);
                        }
                    }
                    return None;
                }
                // ደህንነት እኛ ወሰን ውስጥ ነን ፡፡`post_inc_start` ለ ZSTs እንኳን ትክክለኛውን ነገር ያደርጋል።
                unsafe {
                    self.post_inc_start(n as isize);
                    Some(next_unchecked!(self))
                }
            }

            #[inline]
            fn last(mut self) -> Option<$elem> {
                self.next_back()
            }

            // `try_fold` ን የሚጠቀመውን ነባሪ አተገባበርን እናሸንፋለን ፣ ምክንያቱም ይህ ቀላል አተገባበር አነስተኛ LLVM IR ይፈጥራል እና ለመሰብሰብ ፈጣን ነው።
            //
            //
            #[inline]
            fn for_each<F>(mut self, mut f: F)
            where
                Self: Sized,
                F: FnMut(Self::Item),
            {
                while let Some(x) = self.next() {
                    f(x);
                }
            }

            // `try_fold` ን የሚጠቀመውን ነባሪ አተገባበርን እናሸንፋለን ፣ ምክንያቱም ይህ ቀላል አተገባበር አነስተኛ LLVM IR ይፈጥራል እና ለመሰብሰብ ፈጣን ነው።
            //
            //
            #[inline]
            fn all<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if !f(x) {
                        return false;
                    }
                }
                true
            }

            // `try_fold` ን የሚጠቀመውን ነባሪ አተገባበርን እናሸንፋለን ፣ ምክንያቱም ይህ ቀላል አተገባበር አነስተኛ LLVM IR ይፈጥራል እና ለመሰብሰብ ፈጣን ነው።
            //
            //
            #[inline]
            fn any<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if f(x) {
                        return true;
                    }
                }
                false
            }

            // `try_fold` ን የሚጠቀመውን ነባሪ አተገባበርን እናሸንፋለን ፣ ምክንያቱም ይህ ቀላል አተገባበር አነስተኛ LLVM IR ይፈጥራል እና ለመሰብሰብ ፈጣን ነው።
            //
            //
            #[inline]
            fn find<P>(&mut self, mut predicate: P) -> Option<Self::Item>
            where
                Self: Sized,
                P: FnMut(&Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if predicate(&x) {
                        return Some(x);
                    }
                }
                None
            }

            // `try_fold` ን የሚጠቀመውን ነባሪ አተገባበርን እናሸንፋለን ፣ ምክንያቱም ይህ ቀላል አተገባበር አነስተኛ LLVM IR ይፈጥራል እና ለመሰብሰብ ፈጣን ነው።
            //
            //
            #[inline]
            fn find_map<B, F>(&mut self, mut f: F) -> Option<B>
            where
                Self: Sized,
                F: FnMut(Self::Item) -> Option<B>,
            {
                while let Some(x) = self.next() {
                    if let Some(y) = f(x) {
                        return Some(y);
                    }
                }
                None
            }

            // `try_fold` ን የሚጠቀመውን ነባሪ አተገባበርን እናሸንፋለን ፣ ምክንያቱም ይህ ቀላል አተገባበር አነስተኛ LLVM IR ይፈጥራል እና ለመሰብሰብ ፈጣን ነው።
            // እንዲሁም `assume` የድንበር ፍተሻን ያስወግዳል።
            //
            #[inline]
            #[rustc_inherit_overflow_checks]
            fn position<P>(&mut self, mut predicate: P) -> Option<usize> where
                Self: Sized,
                P: FnMut(Self::Item) -> bool,
            {
                let n = len!(self);
                let mut i = 0;
                while let Some(x) = self.next() {
                    if predicate(x) {
                        // ደህንነት: በሉፕ የማይለዋወጥ ድንበር ውስጥ እንድንሆን ዋስትና ተሰጥቶናል-
                        // `i >= n` ፣ `self.next()` `None` ን ሲመልስ እና ቀለበቱ ሲሰበር።
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                    i += 1;
                }
                None
            }

            // `try_fold` ን የሚጠቀመውን ነባሪ አተገባበርን እናሸንፋለን ፣ ምክንያቱም ይህ ቀላል አተገባበር አነስተኛ LLVM IR ይፈጥራል እና ለመሰብሰብ ፈጣን ነው።
            // እንዲሁም `assume` የድንበር ፍተሻን ያስወግዳል።
            //
            #[inline]
            fn rposition<P>(&mut self, mut predicate: P) -> Option<usize> where
                P: FnMut(Self::Item) -> bool,
                Self: Sized + ExactSizeIterator + DoubleEndedIterator
            {
                let n = len!(self);
                let mut i = n;
                while let Some(x) = self.next_back() {
                    i -= 1;
                    if predicate(x) {
                        // ደህንነት: `i` ከ `n` ጀምሮ ጀምሮ ከ `n` በታች መሆን አለበት
                        // እና እየቀነሰ ብቻ ነው ፡፡
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                }
                None
            }

            #[doc(hidden)]
            unsafe fn __iterator_get_unchecked(&mut self, idx: usize) -> Self::Item {
                // ደህንነት-ደዋዩ `i` ን ወሰን እንዳለው ማረጋገጥ አለበት
                // መሠረታዊው ቁራጭ ፣ ስለሆነም `i` `isize` ን ሊያጥለቀልቅ ስለማይችል የተመለሱት ማጣቀሻዎች የተቆራረጠውን አንድ አካል ለማመልከት የተረጋገጠ በመሆኑ ትክክለኛ ሆኖ እንዲገኝ የተረጋገጠ ነው ፡፡
                //
                // በተጨማሪም ደዋዩ እንደገና በተመሳሳይ ኢንዴክስ ያልተጠራን መሆናችንን እና እንዲሁም ይህንን ንዑስ ክፍልን የሚያገኙ ሌሎች ዘዴዎች አለመጠራታቸውን ያረጋግጣል ፣ ስለሆነም የተመለሰው ማጣቀሻ በ
                //
                // `IterMut`
                //
                //
                //
                //
                unsafe { & $( $mut_ )? * self.ptr.as_ptr().add(idx) }
            }

            $($extra)*
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> DoubleEndedIterator for $name<'a, T> {
            #[inline]
            fn next_back(&mut self) -> Option<$elem> {
                // በመቁረጥ ሊተገበር ይችላል ፣ ግን ይህ የድንበር ፍተሻዎችን ያስወግዳል

                // ደህንነት: የ `assume` ጥሪዎች የተቆራረጠ የመነሻ ጠቋሚ ዋጋ ቢስ መሆን አለበት ፣
                // እና ዜድ-አልባ ባልሆኑት ላይ ያሉ ቁርጥራጮች እንዲሁ ባዶ ያልሆነ የመጨረሻ ጠቋሚ ሊኖራቸው ይገባል።
                // ተደጋጋሚው መጀመሪያ ባዶ መሆኑን ስለምናረጋግጥ ወደ `next_back_unchecked!` ጥሪው ደህንነቱ የተጠበቀ ነው።
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_back_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn nth_back(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // ይህ ተሟጋች አሁን ባዶ ነው ፡፡
                    self.end = self.ptr.as_ptr();
                    return None;
                }
                // ደህንነት እኛ ወሰን ውስጥ ነን ፡፡`pre_dec_end` ለ ZSTs እንኳን ትክክለኛውን ነገር ያደርጋል።
                unsafe {
                    self.pre_dec_end(n as isize);
                    Some(next_back_unchecked!(self))
                }
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<T> FusedIterator for $name<'_, T> {}

        #[unstable(feature = "trusted_len", issue = "37572")]
        unsafe impl<T> TrustedLen for $name<'_, T> {}
    }
}

macro_rules! forward_iterator {
    ($name:ident: $elem:ident, $iter_of:ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, $elem, P> Iterator for $name<'a, $elem, P>
        where
            P: FnMut(&T) -> bool,
        {
            type Item = $iter_of;

            #[inline]
            fn next(&mut self) -> Option<$iter_of> {
                self.inner.next()
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                self.inner.size_hint()
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<'a, $elem, P> FusedIterator for $name<'a, $elem, P> where P: FnMut(&T) -> bool {}
    };
}