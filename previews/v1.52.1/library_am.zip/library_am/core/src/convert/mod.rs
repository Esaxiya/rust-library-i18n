//! በአይነቶች መካከል ለሚደረጉ ልወጣዎች Traits
//!
//! በዚህ ሞጁል ውስጥ ያለው traits ወደ ሌላ አይነት አንድ ዓይነት ለመለወጥ መንገድ ይሰጣሉ.
//! እያንዳንዱ trait የተለየ ዓላማ የሚያገለግል:
//!
//! - ለዝቅተኛ የማጣቀሻ-ወደ-ማጣቀሻ ልወጣዎች [`AsRef`] trait ይተግብሩ
//! - ለዝቅተኛ ተለዋዋጭ-ወደ-ሊለዋወጥ ልወጣዎች [`AsMut`] trait ይተግብሩ
//! - ዋጋ-ወደ-እሴት ልወጣዎችን ለመብላት [`From`] trait ን ይተግብሩ
//! - ከአሁኑ crate ውጭ ላሉት ዓይነቶች ዋጋ-ወደ-እሴት ልወጣዎችን ለመብላት [`Into`] trait ን ይተግብሩ
//! - የ [`TryFrom`] እና [`TryInto`] traits [`From`] እና [`Into`] ዓይነት ጠባይ, ነገር ግን ልወጣው ላይሳኩ ይችላሉ ጊዜ ተግባራዊ መሆን አለበት.
//!
//! በዚህ ሞጁል ውስጥ ያለው traits ብዙውን ጊዜ በርካታ አይነቶች ጭቅጭቅ የሚደገፉ ናቸው እንደዚህ መሆኑን ሁሉን አቀፍ ተግባራት trait bounds ሆነው ጥቅም ላይ ይውላሉ.ለአብነት የእያንዳንዱን trait ሰነድ ይመልከቱ ፡፡
//!
//! ቤተ መጽሐፍት ደራሲ እንደመሆኑ መጠን, ሁልጊዜ [`From`] እና [`TryFrom`] በሚቀያየረው እንዲሰጡ እና በነጻ መደበኛ ቤተ-መጽሐፍት ውስጥ አንድ ብርድ አፈፃፀም ምስጋና ተመጣጣኝ [`Into`] ወይም [`TryInto`] ማስፈጸሚያዎች ማቅረብ እንደ [`From<T>`][`From`] ወይም [`TryFrom<T>`][`TryFrom`] ይልቅ [`Into<U>`][`Into`] ወይም [`TryInto<U>`][`TryInto`] ተግባራዊ ይመርጣሉ ይገባል.
//! ከ Rust 1.41 በፊት ያለውን ስሪት ሲያነጣጥሩ አሁን ካለው የ crate ውጭ ወደ አንድ ዓይነት ሲቀይሩ [`Into`] ወይም [`TryInto`] ን በቀጥታ መተግበር አስፈላጊ ሊሆን ይችላል ፡፡
//!
//! # አጠቃላይ አተገባበር
//!
//! - [`AsRef`] እና የውስጠኛው ዓይነት ማጣቀሻ ከሆነ እና [`AsMut`] ራስ-ሰር-ጽሑፍ
//! - ከ `] <U>ለ` T [impo`] ን ያመለክታል</u><T><U>ለ U`</u>
//! - [`TryFrom`]`<U>for T` implies [`TryInto`]`</u><T><U>ለ U`</u>
//! - [`From`] እና [`Into`] ቀልጣፋ ናቸው ፣ ይህ ማለት ሁሉም ዓይነቶች `into` ራሳቸውን እና `from` ን እራሳቸውን ይችላሉ ማለት ነው
//!
//! ለአጠቃቀም ምሳሌዎች እያንዳንዱን trait ይመልከቱ ፡፡
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

mod num;

#[unstable(feature = "convert_float_to_int", issue = "67057")]
pub use num::FloatToInt;

/// ማንነት ተግባር.
///
/// ሁለት ነገሮች ለዚህ ተግባር ስለ ማስታወሻ ጠቃሚ ናቸው;
///
/// - መዝጊያው `x` ን ወደ ሌላ ዓይነት ሊያስገድደው ስለሚችል ሁልጊዜ እንደ `|x| x` ካለው መዘጋት ጋር እኩል አይደለም።
///
/// - ይህ `x` ወደ ተግባር አለፈ የግቤት ያነሳሳቸዋል.
///
/// ይህም ብቻ ይመለሳል የግቤት ወደኋላ አንድ ተግባር ያላቸው አስገራሚ ሊመስል ይችል ይሆናል ቢሆንም, አንዳንድ ሳቢ አጠቃቀሞች አሉ.
///
///
/// # Examples
///
/// ሌሎች, ማራኪ, ተግባራት ከተከታታይ ውስጥ ምንም ነገር ማድረግ `identity` መጠቀም:
///
/// ```rust
/// use std::convert::identity;
///
/// fn manipulation(x: u32) -> u32 {
///     // ዎቹ አንድ ማከል ላይ አንድ አስደሳች ተግባር ነው መስለው እንመልከት.
///     x + 1
/// }
///
/// let _arr = &[identity, manipulation];
/// ```
///
/// በሁኔታ ውስጥ `identity` ን እንደ "do nothing" መሰረታዊ ጉዳይ መጠቀም-
///
/// ```rust
/// use std::convert::identity;
///
/// # let condition = true;
/// #
/// # fn manipulation(x: u32) -> u32 { x + 1 }
/// #
/// let do_stuff = if condition { manipulation } else { identity };
///
/// // የበለጠ አስደሳች ነገሮችን ያድርጉ ...
///
/// let _results = do_stuff(42);
/// ```
///
/// ወደ `Some` ለመጠበቅ `identity` በመጠቀም `Option<T>` አንድ ለተደጋጋሚ ተለዋጮች:
///
/// ```rust
/// use std::convert::identity;
///
/// let iter = vec![Some(1), None, Some(3)].into_iter();
/// let filtered = iter.filter_map(identity).collect::<Vec<_>>();
/// assert_eq!(vec![1, 3], filtered);
/// ```
///
///
#[stable(feature = "convert_id", since = "1.33.0")]
#[rustc_const_stable(feature = "const_identity", since = "1.33.0")]
#[inline]
pub const fn identity<T>(x: T) -> T {
    x
}

/// ርካሽ የማጣቀሻ-ወደ-ማጣቀሻ ልወጣ ለማድረግ ጥቅም ላይ ይውላል ፡፡
///
/// ይህ trait ሊቀየሩ ማጣቀሻዎች መካከል ለመቀየር ጥቅም ላይ ነው [`AsMut`] ጋር ተመሳሳይ ነው.
/// አንድ ውድ ልወጣ ማድረግ ይኖርብናል ከሆነ አይነት `&T` ጋር [`From`] በስራ ወይም ብጁ ተግባር ለመጻፍ የተሻለ ነው.
///
/// `AsRef` [`Borrow`] ተመሳሳይ ፊርማ አለው, ነገር ግን [`Borrow`] ጥቂት ዘርፎች ላይ የተለየ ነው;
///
/// - `AsRef` በተለየ [`Borrow`] ማንኛውም `T` አንድ ብርድ impl አለው, እና ማጣቀሻ ወይም እሴት ለመቀበል ጥቅም ላይ ሊውል ይችላል.
/// - [`Borrow`] እንዲሁም ለተበደረው እሴት [`Hash`] ፣ [`Eq`] እና [`Ord`] ከባለቤትነት ዋጋ ጋር እኩል መሆንን ይጠይቃል።
/// አንድ struct ብቻ በነጠላ መስክ መበደር የሚፈልጉ ከሆነ በዚህ ምክንያት, እናንተ `AsRef` እንጂ [`Borrow`] ተግባራዊ ይችላሉ.
///
/// **Note: ይህ trait መውደቅ የለበትም **።ልወጣው ሊሳካ ካልቻለ [`Option<T>`] ወይም [`Result<T, E>`] ን የሚመልስ ልዩ ዘዴን ይጠቀሙ።
///
/// # አጠቃላይ አተገባበር
///
/// - `AsRef` በራስ-dereferences ውስጣዊ አይነት ማጣቀሻ ወይም ሊቀየሩ ማጣቀሻ ከሆነ (ለምሳሌ: `foo.as_ref()` will work the same if `foo` has type   `&mut Foo` or `&&mut Foo`)
///
///
/// # Examples
///
/// trait bounds ን በመጠቀም ወደተጠቀሰው ዓይነት `T` መለወጥ እስከቻሉ ድረስ የተለያዩ አይነቶች ክርክሮችን መቀበል እንችላለን ፡፡
///
/// ለምሳሌ: አንድ `AsRef<str>` የሚወስድ አንድ ሁሉን አቀፍ ተግባር በመፍጠር እኛ እኛ ጭቅጭቅ እንደ [`&str`] ሊቀየር የሚችል ሁሉ ማጣቀሻዎች መቀበል እንደሚፈልጉ መግለጽ.
/// [`String`] እና [`&str`] ሁለቱም `AsRef<str>` ተግባራዊ በመሆኑ እኛ ግብዓት ክርክር እንደ ሆነ መቀበል ይችላሉ.
///
/// [`&str`]: primitive@str
/// [`Borrow`]: crate::borrow::Borrow
/// [`Eq`]: crate::cmp::Eq
/// [`Ord`]: crate::cmp::Ord
/// [`String`]: ../../std/string/struct.String.html
///
/// ```
/// fn is_hello<T: AsRef<str>>(s: T) {
///    assert_eq!("hello", s.as_ref());
/// }
///
/// let s = "hello";
/// is_hello(s);
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsRef<T: ?Sized> {
    /// ልወጣውን ያከናውናል።
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_ref(&self) -> &T;
}

/// ርካሽ ተለዋጭ-ወደ-ሚውቴሽን የማጣቀሻ ልወጣ ለማድረግ ጥቅም ላይ ይውላል።
///
/// ይህ trait ከ [`AsRef`] ጋር ተመሳሳይ ነው ግን በሚለዋወጥ ማጣቀሻዎች መካከል ለመቀየር ያገለግላል።
/// አንድ ውድ ልወጣ ማድረግ ይኖርብናል ከሆነ አይነት `&mut T` ጋር [`From`] በስራ ወይም ብጁ ተግባር ለመጻፍ የተሻለ ነው.
///
/// **Note: ይህ trait መውደቅ የለበትም **።ልወጣው ሊሳካ ካልቻለ [`Option<T>`] ወይም [`Result<T, E>`] ን የሚመልስ ልዩ ዘዴን ይጠቀሙ።
///
/// # አጠቃላይ አተገባበር
///
/// - `AsMut` የውስጠኛው ዓይነት ሊለዋወጥ የሚችል ማጣቀሻ ከሆነ ራስ-ሰር መዝገቦች (ለምሳሌ ፦ `foo.as_mut()` will work the same if `foo` has type `&mut Foo`   or `&mut &mut Foo`)
///
///
/// # Examples
///
/// ለጠቅላላ ተግባር `AsMut` ን እንደ trait bound በመጠቀም ወደ `&mut T` ዓይነት ሊለወጡ የሚችሉ ሁሉንም የሚቀየሩ ማጣቀሻዎችን መቀበል እንችላለን ፡፡
/// [`Box<T>`] `AsMut<T>` የሚያስፈጽም በመሆኑ እኛ `&mut u64` ሊቀየር የሚችል ሁሉ ጭቅጭቅ የሚወስድ አንድ ተግባር `add_one` መጻፍ ይችላሉ.
/// [`Box<T>`] `AsMut<T>` ን ስለሚተገብር ፣ `add_one` እንዲሁ የ `&mut Box<u64>` ዓይነት ክርክሮችን ይቀበላል-
///
/// ```
/// fn add_one<T: AsMut<u64>>(num: &mut T) {
///     *num.as_mut() += 1;
/// }
///
/// let mut boxed_num = Box::new(0);
/// add_one(&mut boxed_num);
/// assert_eq!(*boxed_num, 1);
/// ```
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsMut<T: ?Sized> {
    /// ልወጣውን ያከናውናል።
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_mut(&mut self) -> &mut T;
}

/// የግቤት እሴት እንዳሟጠጠው አንድ እሴት-ወደ-ዋጋ ልወጣ.የ [`From`] ተቃራኒ።
///
/// አንድ ሰው [`Into`] ን ከመተግበር መቆጠብ እና በምትኩ [`From`] ን መተግበር አለበት።
/// በመደበኛ ቤተ-መጽሐፍት ውስጥ ለብርድ ልብስ አተገባበር [`From`] ን መተግበር በራስ-ሰር የ [`Into`] ትግበራ በራስ-ሰር ይሰጣል ፡፡
///
/// ብቻ [`Into`] ለመተግበር ዘንድ ዓይነቶች እንዲሁም ጥቅም ላይ ሊውል የሚችል መሆኑን ለማረጋገጥ አንድ ሁሉን አቀፍ ተግባር ላይ trait bounds ሲያወጡ [`From`] ላይ [`Into`] መጠቀም እመርጣለሁ.
///
/// **Note: ይህ trait ** እንዳይጠፋ የለበትም.ልወጣው ካልተሳካ [`TryInto`] ን ይጠቀሙ።
///
/// # አጠቃላይ አተገባበር
///
/// - [`From`]`<T>ለ U` `Into<U> for T` ን ያመለክታል
/// - [`Into`] አንጸባራቂ ነው ፣ ይህም ማለት `Into<T> for T` ተተግብሯል ማለት ነው
///
/// # በቀድሞው የ Rust ስሪቶች ውስጥ ለውጫዊ ዓይነቶች ልወጣዎች [`Into`] ን በመተግበር ላይ
///
/// መድረሻ አይነት የአሁኑ crate ክፍል አልነበረም ከሆነ Rust 1.41 በፊት, ከዚያም በቀጥታ [`From`] ተግባራዊ አልቻለም.
/// ለምሳሌ ፣ ይህንን ኮድ ይውሰዱ:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> From<Wrapper<T>> for Vec<T> {
///     fn from(w: Wrapper<T>) -> Vec<T> {
///         w.0
///     }
/// }
/// ```
/// Rust ያለው orphaning ደንቦች ትንሽ ይበልጥ ጥብቅ መሆን ጥቅም ምክንያቱም ይህ ቋንቋ የቆዩ ስሪቶች ውስጥ ለማጠናቀር አይሳካም.
/// ይህን ማለፊያ ወደ እናንተ [`Into`] በቀጥታ መተግበር ይችላሉ:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> Into<Vec<T>> for Wrapper<T> {
///     fn into(self) -> Vec<T> {
///         self.0
///     }
/// }
/// ```
///
/// እሱም ([`From`] [`Into`] ጋር የሚያደርገውን ያሉ) [`Into`] አንድ [`From`] አፈፃፀም አይሰጥም መሆኑን መረዳት አስፈላጊ ነው.
/// ስለሆነም ፣ [`From`] ን ለመተግበር ሁል ጊዜ መሞከር አለብዎ እና ከዚያ [`From`] ሊተገበር ካልቻለ ወደ [`Into`] ተመልሰው ይወድቃሉ ፡፡
///
/// # Examples
///
/// [`String`] መሳሪያዎች [`Into`]`<`[`Vec`] `<` [`u8`]`>>`:
///
/// ወደ ተጠቀሰው ዓይነት `T` ሊለወጡ የሚችሉትን ሁሉንም ክርክሮች ለመውሰድ አጠቃላይ ተግባር እንደምንፈልግ ለመግለጽ ፣ የ [`Into`]` ን trait bound ን መጠቀም እንችላለን ፡፡<T>እ.ኤ.አ.
///
/// ለምሳሌ `is_hello` የሚለው ተግባር ወደ [`Vec`]`<`[`u8`]`>> ሊለወጡ የሚችሉትን ሁሉንም ክርክሮች ይወስዳል ፡፡
///
/// ```
/// fn is_hello<T: Into<Vec<u8>>>(s: T) {
///    let bytes = b"hello".to_vec();
///    assert_eq!(bytes, s.into());
/// }
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`Vec`]: ../../std/vec/struct.Vec.html
///
///
///
///
///
///
#[rustc_diagnostic_item = "into_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Into<T>: Sized {
    /// ልወጣውን ያከናውናል።
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into(self) -> T;
}

/// የግብዓት እሴቱን በሚወስዱበት ጊዜ ዋጋ-ወደ-እሴት ልወጣዎችን ለማድረግ ያገለግል ነበር።ይህ [`Into`] ያለውን ወንፈል ነው.
///
/// `From` ን በመተግበር በመደበኛ ቤተ-መጽሐፍት ውስጥ ባለው ብርድ ልብስ ትግበራ ምስጋና ይግባውና `From` ን መተግበር በራስ-ሰር የ [`Into`] ን ተግባራዊነት አንድ ሰው ሁልጊዜ `From` ን ከ [`Into`] መተግበርን መምረጥ አለበት።
///
///
/// ከ Rust 1.41 በፊት ያለውን ስሪት በማነጣጠር እና አሁን ካለው የ crate ውጭ ወደ አንድ ዓይነት ሲቀይሩ [`Into`] ን ብቻ ይተግብሩ።
/// `From` በ Rust ወላጅ አልባ ሕጎች ምክንያት ቀደም ሲል በነበሩት ስሪቶች ውስጥ እነዚህን ዓይነቶች ልወጣዎች ማድረግ አልቻለም ፡፡
/// ለተጨማሪ ዝርዝሮች [`Into`] ን ይመልከቱ።
///
/// በአጠቃላይ ተግባር ላይ trait bounds ን ሲገልጽ `From` ን ከመጠቀም ይልቅ [`Into`] ን መጠቀም ይመርጡ።
/// በቀጥታ [`Into`] ለመተግበር በዚህ መንገድ, አይነቶች እንዲሁም ጭቅጭቅ ሆነው ሊያገለግሉ ይችላሉ.
///
/// የስህተት አያያዝን ሲያከናውን `From` እንዲሁ በጣም ጠቃሚ ነው ፡፡የመውደቅ ችሎታ ያለው ተግባር ሲገነቡ የመመለሻ ዓይነት በአጠቃላይ `Result<T, E>` ቅጽ ይሆናል ፡፡
/// በርካታ የስህተት አይነቶች encapsulate አንድ ነጠላ ስህተት አይነት ለመመለስ አንድ ተግባር በመፍቀድ አያያዝ የ `From` trait ሳንጨነቅ ስህተት.ለተጨማሪ ዝርዝሮች የ "Examples" ክፍልን እና [the book][book] ን ይመልከቱ።
///
/// **Note: ይህ trait ** እንዳይጠፋ የለበትም.ልወጣ ላይሳኩ ይችላሉ ከሆነ, [`TryFrom`] ይጠቀሙ.
///
/// # አጠቃላይ አተገባበር
///
/// - `From<T> for U` [`Into`]`<U>T` ለ</u> አንድምታ
/// - `From` `From<T> for T` አልተተገበረም ነው, ይህም ማለት አገናዛቢ ነው
///
/// # Examples
///
/// [`String`] መሳሪያዎች `From<&str>`:
///
/// እንደሚከተለው አንድ ሕብረቁምፊ ወደ አንድ `&str` ከ ግልጽ የሆነ ልወጣ እንዳደረገ ነው:
///
/// ```
/// let string = "hello".to_string();
/// let other_string = String::from("hello");
///
/// assert_eq!(string, other_string);
/// ```
///
/// አያያዝ ስህተት በማከናወን ላይ ሳለ ብዙውን የራስህን ስህተት አይነት `From` ተግባራዊ ለማድረግ ጠቃሚ ነው.
/// ያለውን መሰረታዊ ስህተት አይነት አጽዕሮቱን መሆኑን የራሳችን ብጁ የስህተት አይነት መሰረታዊ ስህተት አይነቶች በመቀየር, እኛ መሠረታዊ ምክንያት ላይ መረጃ ማጣት ያለ አንድ ስህተት አይነት መመለስ ይችላሉ.
/// የ '?' ከዋኝ በራስ `From` ተግባራዊ ጊዜ ሰር የቀረበ ነው `Into<CliError>::into` በመደወል የእኛን ብጁ የስህተት አይነት ጋር ያለውን መሰረታዊ ስህተት አይነት ትለውጣለች.
/// `Into` ትግበራ ላይ መዋል አለበት ይህም አጠናቃሪ ከዚያም infers.
///
/// ```
/// use std::fs;
/// use std::io;
/// use std::num;
///
/// enum CliError {
///     IoError(io::Error),
///     ParseError(num::ParseIntError),
/// }
///
/// impl From<io::Error> for CliError {
///     fn from(error: io::Error) -> Self {
///         CliError::IoError(error)
///     }
/// }
///
/// impl From<num::ParseIntError> for CliError {
///     fn from(error: num::ParseIntError) -> Self {
///         CliError::ParseError(error)
///     }
/// }
///
/// fn open_and_parse_file(file_name: &str) -> Result<i32, CliError> {
///     let mut contents = fs::read_to_string(&file_name)?;
///     let num: i32 = contents.trim().parse()?;
///     Ok(num)
/// }
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`from`]: From::from
/// [book]: ../../book/ch09-00-error-handling.html
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "from_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(on(
    all(_Self = "&str", T = "std::string::String"),
    note = "to coerce a `{T}` into a `{Self}`, use `&*` as a prefix",
))]
pub trait From<T>: Sized {
    /// ልወጣውን ያከናውናል።
    #[lang = "from"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from(_: T) -> Self;
}

/// ውድ ወይም ውድ ሊሆን የሚችል `self` ን የሚወስድ ሙከራ ልወጣ።
///
/// መጽሐፍት ደራሲዎች አብዛኛውን ጊዜ በቀጥታ ይህን trait መተግበር የለባቸውም, ነገር ግን መደበኛ ቤተ-መጽሐፍት ውስጥ ያለ ብርድ ልብስ አፈፃፀም ጋር, ምስጋና በሚቀያየረው ያቀርባል እና በነጻ የሆነ ተመጣጣኝ `TryInto` አፈፃፀም ይሰጣል ይህም [`TryFrom`] trait, ተግባራዊ ይመርጣሉ ይገባል.
/// በዚህ ላይ የበለጠ መረጃ ለማግኘት ለ‹[`Into`] X›ሰነዶችን ይመልከቱ ፡፡
///
/// # በስራ ላይ ማዋል `TryInto`
///
/// ይህ [`Into`] ን ከመተግበሩ ጋር ተመሳሳይ ገደቦችን እና ምክንያቶችን ይሰማል ፣ ለዝርዝሮች እዚያ ይመልከቱ።
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_into_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryInto<T>: Sized {
    /// የልወጣ ስህተት በሚኖርበት ጊዜ የተመለሰው ዓይነት ፡፡
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// ልወጣውን ያከናውናል።
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_into(self) -> Result<T, Self::Error>;
}

/// በአንዳንድ ሁኔታዎች ቁጥጥር በሆነ መንገድ ሊከሽፉ የሚችሉ ቀላል እና ደህንነቱ የተጠበቀ ዓይነት ልወጣዎች ፡፡የ [`TryInto`] ተቀባዮች ነው።
///
/// እናንተ ቢስ ስኬታማ ይሆናል ሳይሆን ልዩ አያያዝ ሊያስፈልጋቸው ይችላል አንድ አይነት ልወጣ እያደረጉ ጊዜ ይህ ጠቃሚ ነው.
/// ለምሳሌ ፣ [`From`] trait ን በመጠቀም [`i64`] ን ወደ [`i32`] ለመቀየር ምንም መንገድ የለም ፣ ምክንያቱም [`i64`] [`i32`] ሊወክለው የማይችለውን እሴት ሊይዝ ስለሚችል ልወጣው መረጃውን ያጣል ፡፡
///
/// ይህ [`i64`] ን ወደ [`i32`] በመቁረጥ (በመሠረቱ የ `i64`` እሴት ሞዱሎ [`i32::MAX`] በመስጠት) ወይም በቀላሉ [`i32::MAX`] ን በመመለስ ወይም በሌላ ዘዴ ሊከናወን ይችላል።
/// የ `TryFrom` trait አንድ አይነት ልወጣ መጥፎ ሄደህ እነርሱ ይህን እንዴት መፍታት እንደሚቻል መወሰን ያስችልዎታል ይችል ጊዜ በፕሮግራም ያሳውቃል ስለዚህ [`From`] trait, ፍጹም ልወጣዎች የታሰበ ነው.
///
/// # አጠቃላይ አተገባበር
///
/// - `TryFrom<T> for U` የሚያመለክተው [`TryInto`]` <U>ለቲ</u>
/// - [`try_from`] Reflexive ነው ፣ ይህም ማለት `TryFrom<T> for T` ተተግብሯል እና ሊሳካ አይችልም-`T::try_from()` ን ለመደወል የተዛመደው የ `Error` ዓይነት በ `T` ዓይነት እሴት [`Infallible`] ነው ፡፡
/// የ [`!`] አይነት የሚደረግልዎት ጊዜ [`Infallible`] እና [`!`] ተመጣጣኝ ይሆናል.
///
/// `TryFrom<T>` እንደሚከተለው ሊተገበር ይችላል
///
/// ```
/// use std::convert::TryFrom;
///
/// struct GreaterThanZero(i32);
///
/// impl TryFrom<i32> for GreaterThanZero {
///     type Error = &'static str;
///
///     fn try_from(value: i32) -> Result<Self, Self::Error> {
///         if value <= 0 {
///             Err("GreaterThanZero only accepts value superior than zero!")
///         } else {
///             Ok(GreaterThanZero(value))
///         }
///     }
/// }
/// ```
///
/// # Examples
///
/// እንደተገለጸው, [`i32`] መሳሪያዎች `TryFrom <` [`i64`]`>`:
///
/// ```
/// use std::convert::TryFrom;
///
/// let big_number = 1_000_000_000_000i64;
/// // በፀጥታ `big_number` ን ይቆርጣል ፣ ከእውነታው በኋላ መቆራረጥን መፈለግ እና ማስተናገድን ይጠይቃል።
/////
/// let smaller_number = big_number as i32;
/// assert_eq!(smaller_number, -727379968);
///
/// // `big_number` በ `i32` ውስጥ ለመግባት በጣም ትልቅ ስለሆነ ስህተት ይመልሳል።
/////
/// let try_smaller_number = i32::try_from(big_number);
/// assert!(try_smaller_number.is_err());
///
/// // `Ok(3)` ን ይመልሳል።
/// let try_successful_smaller_number = i32::try_from(3);
/// assert!(try_successful_smaller_number.is_ok());
/// ```
///
/// [`try_from`]: TryFrom::try_from
///
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_from_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryFrom<T>: Sized {
    /// የልወጣ ስህተት በሚኖርበት ጊዜ የተመለሰው ዓይነት ፡፡
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// ልወጣውን ያከናውናል።
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_from(value: T) -> Result<Self, Self::Error>;
}

////////////////////////////////////////////////////////////////////////////////
// አጠቃላይ ምልክቶች
////////////////////////////////////////////////////////////////////////////////

// ሲነሳ
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// ከ &mut በላይ እንደሚነሳ
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &mut T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// FIXME (#45742): ለ&/&mut ከላይ የተጠቀሱትን ምልክቶች በሚከተለው አጠቃላይ አጠቃላይ ይተኩ:
// // በደረፍ ላይ እንደሚነሳ
// እንድምታ <D: ?Sized + Deref<Target: AsRef<U>>, ዩ:? Sized> AsRef <U>D ለ {as_ref(&self) fn-> &U {</u>
//
//         self.deref().as_ref()
//     }
// }

// &mut ላይ AsMut ጀልባዎችን
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsMut<U> for &mut T
where
    T: AsMut<U>,
{
    fn as_mut(&mut self) -> &mut U {
        (*self).as_mut()
    }
}

// FIXME (#45742): ከሚከተሉት ይበልጥ አጠቃላይ ሰው ጋር &mut ለ ከላይ impl ለመተካት:
// // አስሙት በደረፍ ሙት ላይ ይነሳል
// እንድምታ <D: ?Sized + Deref<Target: AsMut<U>>, U:? መጠን> AsMut <U>ለ D {fn as_mut(&mut self)-> &mut U {</u>
//
//         self.deref_mut().as_mut()
//     }
// }

// ከተዘረዘረው ወደ
#[stable(feature = "rust1", since = "1.0.0")]
impl<T, U> Into<U> for T
where
    U: From<T>,
{
    fn into(self) -> U {
        U::from(self)
    }
}

// ከ (እና ስለዚህ ወደ ውስጥ) አንጸባራቂ ነው
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> From<T> for T {
    fn from(t: T) -> T {
        t
    }
}

/// **የማረጋገያ ማስታወሻ:** ይህ impl እስካሁን የለም, ነገር ግን እኛ "reserving space" በ future ላይ ለማከል ናቸው.
/// ለዝርዝሮች [rust-lang/rust#64715][#64715] ን ይመልከቱ ፡፡
///
/// [#64715]: https://github.com/rust-lang/rust/issues/64715
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[allow(unused_attributes)] // FIXME(#58633): በምትኩ በመርህ ላይ የተመሠረተ ማስተካከያ ያድርጉ።
#[rustc_reservation_impl = "permitting this impl would forbid us from adding \
                            `impl<T> From<!> for T` later; see rust-lang/rust#64715 for details"]
impl<T> From<!> for T {
    fn from(t: !) -> T {
        t
    }
}

// TryFrom ከ‹IriInto›ን ያሳያል
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryInto<U> for T
where
    U: TryFrom<T>,
{
    type Error = U::Error;

    fn try_into(self) -> Result<U, U::Error> {
        U::try_from(self)
    }
}

// የማይሳሳቱ ልወጣዎች ነዋሪ ባልሆኑ የስህተት ዓይነቶች ከሚወዳደሩ ልወጣዎች ጋር በቅደም ተከተል ተመሳሳይ ናቸው።
//
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryFrom<U> for T
where
    U: Into<T>,
{
    type Error = Infallible;

    fn try_from(value: U) -> Result<Self, Self::Error> {
        Ok(U::into(value))
    }
}

////////////////////////////////////////////////////////////////////////////////
// ተጨባጭ IMPLS
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsRef<[T]> for [T] {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsMut<[T]> for [T] {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for str {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "as_mut_str_for_str", since = "1.51.0")]
impl AsMut<str> for str {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

////////////////////////////////////////////////////////////////////////////////
// የ NO-ስህተት የስህተት አይነት
////////////////////////////////////////////////////////////////////////////////

/// ፈጽሞ የሚችሉ ስህተቶች ስህተት አይነት.
///
/// ይህ enum ልዩነት ስለሌለው የዚህ ዓይነቱ እሴት በእውነቱ ሊኖር አይችልም።
/// ውጤቱ ሁል ጊዜ [`Ok`] መሆኑን ለማመልከት ይህ [`Result`] ን ለሚጠቀሙ እና የስህተት ዓይነቱን መለኪያ ለሆኑ አጠቃላይ ኤፒአይዎች ይህ ጠቃሚ ሊሆን ይችላል ፡፡
///
/// ለምሳሌ ፣ [`TryFrom`] trait ([`Result`] ን የሚመልስ ልወጣ) የተገላቢጦሽ የ [`Into`] ትግበራ ባለበት ለሁሉም ዓይነቶች ብርድልብስ ትግበራ አለው ፡፡
///
/// ```ignore (illustrates std code, duplicating the impl in a doctest would be an error)
/// impl<T, U> TryFrom<U> for T where U: Into<T> {
///     type Error = Infallible;
///
///     fn try_from(value: U) -> Result<Self, Infallible> {
///         Ok(U::into(value))  // Never returns `Err`
///     }
/// }
/// ```
///
/// # የ Future ተኳኋኝነት
///
/// ይህ enum Rust በዚህ ስሪት ውስጥ ያልተረጋጋ ነው [the `!`“never”type][never], ተመሳሳይ ሚና አለው.
/// `!` ሲረጋጋ `Infallible` ን ለእሱ ዓይነት ቅጽል ለማድረግ አቅደናል
///
/// ```ignore (illustrates future std change)
/// pub type Infallible = !;
/// ```
///
/// …እና በመጨረሻም `Infallible` ን ይሽሩ።
///
/// ሆኖም `!` እንደ ሙሉ ዓይነት ከመረጋጋት በፊት የ `!` አገባብ ጥቅም ላይ ሊውል የሚችልበት አንድ ሁኔታ አለ-በተግባሪ መመለሻ ዓይነት አቀማመጥ ፡፡
/// በተለይም ለሁለት የተለያዩ የአመልካች አመላካች ዓይነቶች ማስፈጸሚያዎች ሊሆኑ ይችላሉ-
///
/// ```
/// trait MyTrait {}
/// impl MyTrait for fn() -> ! {}
/// impl MyTrait for fn() -> std::convert::Infallible {}
/// ```
///
/// ኤክስኤክስኤክስ ኤን ኤም ሆኖ ይህ ኮድ ትክክለኛ ነው ፡፡
/// ሆኖም `Infallible` ለ never type መጠሪያ በሚሆንበት ጊዜ ሁለቱ `impl`s መደራረብ ስለሚጀምሩ በቋንቋው trait የቅንጅት ህጎች ይከለከላሉ።
///
///
///
///
///
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[derive(Copy)]
pub enum Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Clone for Infallible {
    fn clone(&self) -> Infallible {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Debug for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Display for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialEq for Infallible {
    fn eq(&self, _: &Infallible) -> bool {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Eq for Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialOrd for Infallible {
    fn partial_cmp(&self, _other: &Self) -> Option<crate::cmp::Ordering> {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Ord for Infallible {
    fn cmp(&self, _other: &Self) -> crate::cmp::Ordering {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl From<!> for Infallible {
    fn from(x: !) -> Self {
        x
    }
}

#[stable(feature = "convert_infallible_hash", since = "1.44.0")]
impl Hash for Infallible {
    fn hash<H: Hasher>(&self, _: &mut H) {
        match *self {}
    }
}