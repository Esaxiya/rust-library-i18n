/// በአጥፊው ውስጥ ብጁ ኮድ።
///
/// እሴት ከአሁን በኋላ በማይፈለግበት ጊዜ Rust በዛ እሴት ላይ "destructor" ን ያካሂዳል።
/// አንድ እሴት ከአሁን በኋላ የማይፈለግበት በጣም የተለመደው መንገድ ከአቅሙ ሲወጣ ነው ፡፡አጥፊዎች አሁንም በሌሎች ሁኔታዎች ውስጥ ሊሮጡ ይችላሉ ፣ ግን እዚህ ለአብነት ምሳሌዎች ወሰን ላይ እናተኩራለን ፡፡
/// ስለ አንዳንድ ሌሎች ጉዳዮች ለማወቅ እባክዎ በአጥፊዎች ላይ የ [the reference] ክፍልን ይመልከቱ ፡፡
///
/// [the reference]: https://doc.rust-lang.org/reference/destructors.html
///
/// ይህ አጥፊ ሁለት ክፍሎችን ያቀፈ ነው
/// - ለዚያ እሴት ወደ `Drop::drop` ጥሪ ፣ ይህ ልዩ `Drop` trait ለእሱ ዓይነት ከተተገበረ።
/// - የዚህን እሴት ሁሉንም መስኮች አጥፊዎችን እንደገና የሚጠራው በራስ-ሰር የተፈጠረው "drop glue"።
///
/// Rust ሁሉንም የተያዙ መስኮች አጥፊዎችን በራስ-ሰር እንደሚጠራው ፣ በአብዛኛዎቹ ሁኔታዎች `Drop` ን መተግበር አያስፈልግዎትም።
/// ግን አንዳንድ ጊዜ ጠቃሚ ነው ፣ ለምሳሌ በቀጥታ ሀብትን ለሚያስተዳድሩ አይነቶች ፡፡
/// ያ ሀብቱ ማህደረ ትውስታ ሊሆን ይችላል ፣ ምናልባት የፋይል ገላጭ ሊሆን ይችላል ፣ የአውታረ መረብ ሶኬት ሊሆን ይችላል።
/// የዚህ ዓይነቱ እሴት ከአሁን በኋላ ጥቅም ላይ የማይውል ከሆነ ማህደረ ትውስታውን በማስለቀቅ ወይም ፋይሉን ወይም ሶኬቱን በመዝጋት "clean up" ን ሀብቱን ማግኘት አለበት ፡፡
/// ይህ የጥፋት ሥራ ነው ፣ ስለሆነም የ `Drop::drop` ሥራ።
///
/// ## Examples
///
/// በተግባር ላይ ያሉ አጥፊዎችን ለማየት የሚከተሉትን መርሃግብሮች እንመልከት ፡፡
///
/// ```rust
/// struct HasDrop;
///
/// impl Drop for HasDrop {
///     fn drop(&mut self) {
///         println!("Dropping HasDrop!");
///     }
/// }
///
/// struct HasTwoDrops {
///     one: HasDrop,
///     two: HasDrop,
/// }
///
/// impl Drop for HasTwoDrops {
///     fn drop(&mut self) {
///         println!("Dropping HasTwoDrops!");
///     }
/// }
///
/// fn main() {
///     let _x = HasTwoDrops { one: HasDrop, two: HasDrop };
///     println!("Running!");
/// }
/// ```
///
/// Rust በመጀመሪያ `Drop::drop` ን ለ `_x` ከዚያም ለሁለቱም `_x.one` እና `_x.two` ይደውላል ፣ ይህ ማለት ይህንን ማሄድ ያትማል ማለት ነው ፡፡
///
/// ```text
/// Running!
/// Dropping HasTwoDrops!
/// Dropping HasDrop!
/// Dropping HasDrop!
/// ```
///
/// የ `Drop` አተገባበርን ለ `HasTwoDrop` ብናስወግድም እንኳ የእርሻዎ አጥፊዎች አሁንም ተጠርተዋል ፡፡
/// ይህ ያስከትላል
///
/// ```test
/// Running!
/// Dropping HasDrop!
/// Dropping HasDrop!
/// ```
///
/// ## `Drop::drop` ን እራስዎ መጥራት አይችሉም
///
/// `Drop::drop` ዋጋን ለማፅዳት የሚያገለግል ስለሆነ ፣ ዘዴው ከተጠራ በኋላ ይህንን እሴት መጠቀሙ አደገኛ ሊሆን ይችላል።
/// `Drop::drop` የግቤውን ባለቤትነት ስለማይወስድ ፣ Rust በቀጥታ `Drop::drop` ን እንዲደውሉ ባለመፍቀድ አላግባብ መጠቀምን ይከላከላል ፡፡
///
/// በሌላ አገላለጽ ከዚህ በላይ ባለው ምሳሌ ውስጥ `Drop::drop` ን በግልፅ ለመጥራት ከሞከሩ አጠናቃሪ ስህተት ይደርስብዎታል።
///
/// የአንድ እሴት አጥፊን በግልፅ መጥራት ከፈለጉ በምትኩ [`mem::drop`] ን መጠቀም ይቻላል።
///
/// [`mem::drop`]: drop
///
/// ## ትዕዛዝ ጣል ያድርጉ
///
/// ምንም እንኳን ከሁለቱ `HasDrop` ማን ነው መጀመሪያ የሚጥል?ለግንባታዎች ፣ እነሱ የታወቁት ተመሳሳይ ቅደም ተከተል ነው-መጀመሪያ `one` ፣ ከዚያ `two`።
/// ይህንን እራስዎ መሞከር ከፈለጉ እንደ ኢንቲጀር ያለ አንዳንድ መረጃዎችን ለመያዝ ከላይ ያለውን `HasDrop` ን ማሻሻል እና ከዚያ በ `Drop` ውስጥ ባለው `println!` ውስጥ መጠቀም ይችላሉ ፡፡
/// ይህ ባህሪ በቋንቋው የተረጋገጠ ነው ፡፡
///
/// እንደ ደንቦች ሳይሆን የአከባቢ ተለዋዋጮች በተቃራኒው ቅደም ተከተል ይጣላሉ
///
/// ```rust
/// struct Foo;
///
/// impl Drop for Foo {
///     fn drop(&mut self) {
///         println!("Dropping Foo!")
///     }
/// }
///
/// struct Bar;
///
/// impl Drop for Bar {
///     fn drop(&mut self) {
///         println!("Dropping Bar!")
///     }
/// }
///
/// fn main() {
///     let _foo = Foo;
///     let _bar = Bar;
/// }
/// ```
///
/// ይህ ያትማል
///
/// ```text
/// Dropping Bar!
/// Dropping Foo!
/// ```
///
/// ለሙሉ ህጎች እባክዎን [the reference] ን ይመልከቱ ፡፡
///
/// [the reference]: https://doc.rust-lang.org/reference/destructors.html
///
/// ## `Copy` እና `Drop` ብቸኛ ናቸው
///
/// ሁለቱንም [`Copy`] እና `Drop` በአንድ ዓይነት ላይ መተግበር አይችሉም።`Copy` የሆኑ ዓይነቶች በተዘዋዋሪ በአቀራባሪው ይባዛሉ ፣ መቼ እና መቼ አጥፊዎች እንደሚገደሉ ለመተንበይ በጣም ከባድ ያደርገዋል ፡፡
///
/// እንደነዚህ ዓይነቶቹ ዓይነቶች አጥፊዎች ሊኖራቸው አይችልም ፡፡
///
///
///
///
///
///
///
///
///
///
#[lang = "drop"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Drop {
    /// ለዚህ ዓይነቱ አጥፊ ያስፈጽማል ፡፡
    ///
    /// እሴቱ ከአቅሙ በላይ በሆነበት ጊዜ ይህ ዘዴ በተዘዋዋሪ ይጠራል ፣ እና በግልፅ ሊጠራ አይችልም (ይህ አጠናቃሪ ስህተት [E0040] ነው)።
    /// ሆኖም ፣ በ‹prelude›ውስጥ ያለው የ‹XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXTXT: ት/ት ለመደወል ሊያገለግል ይችላል ፡፡
    ///
    /// ይህ ዘዴ በተጠራበት ጊዜ `self` ገና አልተዛወረም ፡፡
    /// ያ የሚሆነው ዘዴው ካለቀ በኋላ ብቻ ነው።
    /// ይህ ባይሆን ኖሮ `self` ተንጠልጣይ ማጣቀሻ ይሆናል።
    ///
    /// # Panics
    ///
    /// አንድ [`panic!`] እንደሚፈታ `drop` ብሎ እንደሚጠራው ፣ በ‹`drop`›አተገባበር ውስጥ ያለ ማንኛውም [`panic!`] ፅንስ ማስወረድ ይችላል ፡፡
    ///
    /// ልብ ይበሉ ይህ panics እንኳን ፣ እሴቱ እንደወረደ ይቆጠራል ፣
    /// `drop` ን እንደገና እንዲጠራ ማድረግ የለብዎትም።
    /// ይህ በመደበኛነት በአቀራባዩ በራስ-ሰር ይከናወናል ፣ ግን ደህንነቱ ያልተጠበቀ ኮድ ሲጠቀሙ አንዳንድ ጊዜ ባለማወቅ በተለይም [`ptr::drop_in_place`] ን ሲጠቀሙ ይከሰታል።
    ///
    ///
    /// [E0040]: ../../error-index.html#E0040 [`panic!`]: crate::panic!
    /// [`mem::drop`]: drop
    /// [`ptr::drop_in_place`]: crate::ptr::drop_in_place
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn drop(&mut self);
}