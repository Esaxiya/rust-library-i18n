/// የ `?` ኦፕሬተርን ባህሪ ለማበጀት trait ፡፡
///
/// `Try` ን የሚተገበር አንድ ዓይነት ከ‹success/failure dichotomy›አንፃር ለማየት ቀኖናዊ መንገድ ያለው ነው ፡፡
/// ይህ trait እነዛን የስኬት ወይም የውድቀት እሴቶችን ከአንድ ነባር ምሳሌ ለማውጣት እና ከስኬት ወይም ውድቀት እሴት አዲስ ምሳሌን ለመፍጠር ያስችለዋል ፡፡
///
///
#[unstable(feature = "try_trait", issue = "42327")]
#[rustc_on_unimplemented(
    on(
        all(
            any(from_method = "from_error", from_method = "from_ok"),
            from_desugaring = "QuestionMark"
        ),
        message = "the `?` operator can only be used in {ItemContext} \
                    that returns `Result` or `Option` \
                    (or another type that implements `{Try}`)",
        label = "cannot use the `?` operator in {ItemContext} that returns `{Self}`",
        enclosing_scope = "this function should return `Result` or `Option` to accept `?`"
    ),
    on(
        all(from_method = "into_result", from_desugaring = "QuestionMark"),
        message = "the `?` operator can only be applied to values \
                    that implement `{Try}`",
        label = "the `?` operator cannot be applied to type `{Self}`"
    )
)]
#[doc(alias = "?")]
#[lang = "try"]
pub trait Try {
    /// እንደ ስኬታማ ሲታዩ የዚህ ዋጋ ዓይነት።
    #[unstable(feature = "try_trait", issue = "42327")]
    type Ok;
    /// እንደ አልተሳካም ሲታዩ የዚህ እሴት ዓይነት።
    #[unstable(feature = "try_trait", issue = "42327")]
    type Error;

    /// የ "?" ኦፕሬተርን ይተገበራል።የ `Ok(t)` መመለስ ማለት አፈፃፀሙ በመደበኛነት መቀጠል አለበት ማለት ነው ፣ እና የ `?` ውጤት `t` እሴት ነው።
    /// የ `Err(e)` መመለስ ማለት አፈፃፀም branch ን ወደ ውስጠኛው ውስጠኛው ክፍል `catch` ማድረግ አለበት ፣ ወይም ከተግባሩ መመለስ አለበት ማለት ነው ፡፡
    ///
    /// የ‹XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX HXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXS ISEXXXXXXXXXXXXEXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXSODE ያቀርባል
    ///
    /// በተለይም `X::from_error(From::from(e))` እሴቱ ተመልሷል ፣ `X` የመከለል ተግባር የመመለሻ ዓይነት ነው ፡፡
    ///
    ///
    ///
    #[lang = "into_result"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn into_result(self) -> Result<Self::Ok, Self::Error>;

    /// የተደባለቀውን ውጤት ለመገንባት የስህተት ዋጋን ጠቅልሉ።
    /// ለምሳሌ ፣ `Result::Err(x)` እና `Result::from_error(x)` እኩል ናቸው።
    #[lang = "from_error"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_error(v: Self::Error) -> Self;

    /// የተቀናበረውን ውጤት ለመገንባት አንድ እሺ እሴት ጠቅልሉ።
    /// ለምሳሌ ፣ `Result::Ok(x)` እና `Result::from_ok(x)` እኩል ናቸው።
    #[lang = "from_ok"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_ok(v: Self::Ok) -> Self;
}