//! ከመጠን በላይ ሊጫኑ የሚችሉ ኦፕሬተሮች።
//!
//! እነዚህን traits ተግባራዊ ማድረግ የተወሰኑ ኦፕሬተሮችን ከመጠን በላይ እንዲጫኑ ያስችልዎታል ፡፡
//!
//! ከነዚህ traits መካከል የተወሰኑት በ prelude ከውጭ ስለገቡ በእያንዳንዱ የ‹Rust›ፕሮግራም ውስጥ ይገኛሉ ፡፡በ traits የተደገፉ ኦፕሬተሮች ብቻ ከመጠን በላይ መጫን ይችላሉ።
//! ለምሳሌ ፣ የመደመር ኦፕሬተር (`+`) በ [`Add`] trait በኩል ከመጠን በላይ መጫን ይችላል ፣ ነገር ግን የምደባው ኦፕሬተር (`=`) ለ trait ድጋፍ ስለሌለው ፣ ትርጉሙን ከመጠን በላይ የመጫን መንገድ የለም።
//! በተጨማሪም ይህ ሞጁል አዳዲስ ኦፕሬተሮችን ለመፍጠር ምንም ዓይነት ዘዴ አይሰጥም ፡፡
//! ያለበቂ ጭነት ወይም ብጁ ኦፕሬተሮች የሚያስፈልጉ ከሆነ የ Rust ን አገባብ ለማራዘም ወደ ማክሮዎች ወይም አጠናቃሪ ተሰኪዎች መመልከት አለብዎት።
//!
//! የኦፕሬተር traits ትግበራዎች የተለመዱ ትርጉሞቻቸውን እና [operator precedence] ን ከግምት ውስጥ በማስገባት በየአውደ-ጽሑፎቻቸው አስገራሚ ሊሆኑ ይገባል ፡፡
//! ለምሳሌ ፣ [`Mul`] ን ሲተገብሩ ክዋኔው ከማባዛት ጋር ተመሳሳይነት ሊኖረው ይገባል (እና እንደ ተባባሪነት ያሉ የተጠበቁ ንብረቶችን ያጋሩ) ፡፡
//!
//! የ `&&` እና `||` ኦፕሬተሮች አጫጭር ዑደት ማለትም ሁለተኛውን ኦፔራቸውን የሚገመግሙት ለውጤቱ አስተዋፅዖ ካበረከተ ብቻ መሆኑን ልብ ይበሉ ፡፡ይህ ባህሪ በ traits ተፈጻሚነት ስለሌለው ፣ `&&` እና `||` እንደ ከመጠን በላይ እንደጫኑ ኦፕሬተሮች አይደገፉም ፡፡
//!
//! ብዙዎቹ ኦፕሬተሮች ኦፔራኖቻቸውን በእሴት ይይዛሉ ፡፡አብሮገነብ ዓይነቶችን በሚያካትቱ አጠቃላይ ያልሆኑ አውዶች ውስጥ ይህ ብዙውን ጊዜ ችግር አይደለም ፡፡
//! ሆኖም እነዚህን አንቀሳቃሾች በጥቅሉ ኮድ በመጠቀም እሴቶቹ ኦፕሬተሮቹን እንዲጠቀሙባቸው ከመተው በተቃራኒው እንደገና ጥቅም ላይ መዋል ካለባቸው የተወሰነ ትኩረት ይፈልጋል ፡፡አንዱ አማራጭ አልፎ አልፎ [`clone`] ን መጠቀም ነው።
//! ሌላው አማራጭ ለማጣቀሻዎች ተጨማሪ ኦፕሬተር አተገባበርን በሚሰጡ ዓይነቶች ላይ መተማመን ነው ፡፡
//! ለምሳሌ መደመርን ይደግፋል ተብሎ ለተጠቃሚ ለተገለጸው ዓይነት `T` ምናልባት አጠቃላይ ኮድ ያለ አላስፈላጊ ክሎንግ እንዲፃፍ `T` እና `&T` ን traits [`Add<T>`][`Add`] እና [`Add<&T>`][`Add`] ን እንዲተገብሩ ማድረግ ጥሩ ሀሳብ ነው ፡፡
//!
//!
//! # Examples
//!
//! ይህ ምሳሌ [`Add`] እና [`Sub`] ን የሚተገበር የ‹`Point`›መዋቅርን ይፈጥራል ፣ ከዚያ ሁለት‹ፖይንት›ን መጨመር እና መቀነስን ያሳያል።
//!
//! ```rust
//! use std::ops::{Add, Sub};
//!
//! #[derive(Debug, Copy, Clone, PartialEq)]
//! struct Point {
//!     x: i32,
//!     y: i32,
//! }
//!
//! impl Add for Point {
//!     type Output = Self;
//!
//!     fn add(self, other: Self) -> Self {
//!         Self {x: self.x + other.x, y: self.y + other.y}
//!     }
//! }
//!
//! impl Sub for Point {
//!     type Output = Self;
//!
//!     fn sub(self, other: Self) -> Self {
//!         Self {x: self.x - other.x, y: self.y - other.y}
//!     }
//! }
//!
//! assert_eq!(Point {x: 3, y: 3}, Point {x: 1, y: 0} + Point {x: 2, y: 3});
//! assert_eq!(Point {x: -1, y: -3}, Point {x: 1, y: 0} - Point {x: 2, y: 3});
//! ```
//!
//! ለምሣሌ ትግበራ ለእያንዳንዱ የ trait ሰነድ ይመልከቱ ፡፡
//!
//! [`Fn`] ፣ [`FnMut`] እና [`FnOnce`] traits እንደ ተግባራት ሊጠየቁ በሚችሉ ዓይነቶች ይተገበራሉ ፡፡ልብ ይበሉ [`Fn`] `&self` ፣ [`FnMut`] `&mut self` ይወስዳል እና [`FnOnce`] `self` ይወስዳል።
//! እነዚህ በአንድ ምሳሌ ሊጠሩ ከሚችሉት ሶስት ዓይነቶች ዘዴዎች ጋር ይዛመዳሉ-ጥሪ-በማጣቀሻ ፣ በመደወያ-ተለዋዋጭ-ማጣቀሻ እና-በ-እሴት ፡፡
//! የእነዚህ traits በጣም የተለመዱት አጠቃቀሞች ተግባሮችን ወይም መዝጊያዎችን እንደ ክርክሮች የሚወስዱ የከፍተኛ ደረጃ ተግባሮችን እንደ ወሰን ማድረግ ነው ፡፡
//!
//! [`Fn`] ን እንደ መለኪያ መውሰድ
//!
//! ```rust
//! fn call_with_one<F>(func: F) -> usize
//!     where F: Fn(usize) -> usize
//! {
//!     func(1)
//! }
//!
//! let double = |x| x * 2;
//! assert_eq!(call_with_one(double), 2);
//! ```
//!
//! [`FnMut`] ን እንደ መለኪያ መውሰድ
//!
//! ```rust
//! fn do_twice<F>(mut func: F)
//!     where F: FnMut()
//! {
//!     func();
//!     func();
//! }
//!
//! let mut x: usize = 1;
//! {
//!     let add_two_to_x = || x += 2;
//!     do_twice(add_two_to_x);
//! }
//!
//! assert_eq!(x, 5);
//! ```
//!
//! [`FnOnce`] ን እንደ መለኪያ መውሰድ
//!
//! ```rust
//! fn consume_with_relish<F>(func: F)
//!     where F: FnOnce() -> String
//! {
//!     // `func` የተያዙትን ተለዋዋጮች ይወስዳል ፣ ስለሆነም ከአንድ ጊዜ በላይ ሊሠራ አይችልም
//!     //
//!     println!("Consumed: {}", func());
//!
//!     println!("Delicious!");
//!
//!     // እንደገና `func()` ን ለመጥራት መሞከር ለ `func` የ `use of moved value` ስህተት ይጥላል
//!     //
//! }
//!
//! let x = String::from("x");
//! let consume_and_return_x = move || x;
//! consume_with_relish(consume_and_return_x);
//!
//! // `consume_and_return_x` በዚህ ጊዜ ከአሁን በኋላ መጠራት አይቻልም
//! ```
//!
//! [`clone`]: Clone::clone
//! [operator precedence]: ../../reference/expressions.html#expression-precedence
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

mod arith;
mod bit;
mod control_flow;
mod deref;
mod drop;
mod function;
mod generator;
mod index;
mod range;
mod r#try;
mod unsize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::arith::{Add, Div, Mul, Neg, Rem, Sub};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::arith::{AddAssign, DivAssign, MulAssign, RemAssign, SubAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::bit::{BitAnd, BitOr, BitXor, Not, Shl, Shr};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::bit::{BitAndAssign, BitOrAssign, BitXorAssign, ShlAssign, ShrAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::deref::{Deref, DerefMut};

#[unstable(feature = "receiver_trait", issue = "none")]
pub use self::deref::Receiver;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::drop::Drop;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::function::{Fn, FnMut, FnOnce};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::index::{Index, IndexMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::range::{Range, RangeFrom, RangeFull, RangeTo};

#[stable(feature = "inclusive_range", since = "1.26.0")]
pub use self::range::{Bound, RangeBounds, RangeInclusive, RangeToInclusive};

#[unstable(feature = "try_trait", issue = "42327")]
pub use self::r#try::Try;

#[unstable(feature = "generator_trait", issue = "43122")]
pub use self::generator::{Generator, GeneratorState};

#[unstable(feature = "coerce_unsized", issue = "27732")]
pub use self::unsize::CoerceUnsized;

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
pub use self::unsize::DispatchFromDyn;

#[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
pub use self::control_flow::ControlFlow;