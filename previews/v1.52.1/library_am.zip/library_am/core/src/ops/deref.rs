/// እንደ `*v` ላሉ የማይለዋወጥ የማዘመን ስራዎች ጥቅም ላይ ይውላል ፡፡
///
/// `Deref` በማይለዋወጥ አውዶች ውስጥ ከ‹(unary) `*` ኦፕሬተር›ጋር ግልጽ የማጣሪያ ሥራ ላይ ከመዋሉ በተጨማሪ በብዙ ሁኔታዎች ውስጥ በአቀራባዩ በግልፅ ጥቅም ላይ ይውላል ፡፡
/// ይህ ዘዴ ['`Deref` coercion'][more] ይባላል ፡፡
/// በሚለወጡ አውዶች ውስጥ [`DerefMut`] ጥቅም ላይ ይውላል ፡፡
///
/// `Deref` ን ለስማርት ጠቋሚዎች መተግበር ከበስተጀርባቸው ያሉትን መረጃዎች መድረስ ምቹ ያደርገዋል ፣ ለዚህም ነው `Deref` ን የሚተገብሩት ፡፡
/// በሌላ በኩል ፣ `Deref` እና [`DerefMut`] ን በተመለከተ ደንቦቹ በተለይ ስማርት ጠቋሚዎችን ለማስተናገድ የተቀየሱ ናቸው ፡፡
/// በዚህ ምክንያት **‹ዴሬፍ›ግራ መጋባትን ለማስወገድ ለስማርት ጠቋሚዎች ብቻ መተግበር አለበት**፡፡
///
/// በተመሳሳዩ ምክንያቶች **ይህ trait በጭራሽ መውደቅ የለበትም**።`Deref` ን በተዘዋዋሪ በተጠራበት ጊዜ በመሰረዝ ላይ አለመሳካቱ በጣም ግራ የሚያጋባ ሊሆን ይችላል።
///
/// # ተጨማሪ በ `Deref` ማስገደድ ላይ
///
/// `T` `Deref<Target = U>` ን የሚተገበር ከሆነ እና `x` የ `T` ዓይነት እሴት ከሆነ ከዚያ
///
/// * በማይለዋወጥ አውዶች ውስጥ `*x` (`T` የማጣቀሻም ሆነ ጥሬ ጠቋሚ ያልሆነበት) ከ `* Deref::deref(&x)` ጋር እኩል ነው።
/// * የ `&T` ዓይነት እሴቶች ከ‹XXXX›ዓይነት እሴቶች ጋር ተጭነዋል
/// * `T` ሁሉንም የ X0XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXSXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXIMAN AMAN Ọ ỌR ỌD
///
/// ለተጨማሪ ዝርዝሮች [the chapter in *The Rust Programming Language*][book] ን እንዲሁም በ [the dereference operator][ref-deref-op] ፣ [method resolution] እና [type coercions] ላይ ያሉትን የማጣቀሻ ክፍሎች ይጎብኙ።
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// መዋቅሩን በማዛወር ተደራሽ የሆነ ነጠላ መስክ ያለው መዋቅር።
///
/// ```
/// use std::ops::Deref;
///
/// struct DerefExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// let x = DerefExample { value: 'a' };
/// assert_eq!('a', *x);
/// ```
///
///
///
///
///
///
///
#[lang = "deref"]
#[doc(alias = "*")]
#[doc(alias = "&*")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Deref"]
pub trait Deref {
    /// ከተዘረዘረ በኋላ የተፈጠረው ዓይነት ፡፡
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_target"]
    #[cfg_attr(not(bootstrap), lang = "deref_target")]
    type Target: ?Sized;

    /// ዋጋውን ያጣቅሳሉ ፡፡
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_method"]
    fn deref(&self) -> &Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &T {
    type Target = T;

    #[rustc_diagnostic_item = "noop_method_deref"]
    fn deref(&self) -> &T {
        *self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !DerefMut for &T {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &mut T {
    type Target = T;

    fn deref(&self) -> &T {
        *self
    }
}

/// ልክ እንደ `*v = 1;` ውስጥ ለሚለወጡ የማዘመን ስራዎች ጥቅም ላይ ይውላል።
///
/// ከ‹(unary) `*`›ኦፕሬተር ጋር በሚቀያየር አውዶች ውስጥ ግልፅ የማጥፋት ሥራዎችን ከመጠቀም በተጨማሪ ፣ `DerefMut` በብዙ ሁኔታዎች ውስጥ በአቀራባዩ በግልፅ ጥቅም ላይ ይውላል ፡፡
/// ይህ ዘዴ ['`Deref` coercion'][more] ይባላል ፡፡
/// በማይለዋወጥ አውዶች ውስጥ ፣ [`Deref`] ጥቅም ላይ ይውላል።
///
/// `DerefMut` ን ለስማርት ጠቋሚዎች መተግበር ከበስተጀርባ ያለውን ውሂብ መለወጥ ተስማሚ ያደርገዋል ፣ ለዚህም ነው `DerefMut` ን የሚተገብሩት።
/// በሌላ በኩል ፣ [`Deref`] እና `DerefMut` ን በተመለከተ ደንቦቹ በተለይ ስማርት ጠቋሚዎችን ለማስተናገድ የተቀየሱ ናቸው ፡፡
/// በዚህ ምክንያት ፣ ** `DerefMut` ግራ መጋባትን ለማስወገድ ለስማርት ጠቋሚዎች ብቻ መተግበር አለበት ፡፡
///
/// በተመሳሳዩ ምክንያቶች **ይህ trait በጭራሽ መውደቅ የለበትም**።`DerefMut` ን በተዘዋዋሪ በተጠራበት ጊዜ በመሰረዝ ላይ አለመሳካቱ በጣም ግራ የሚያጋባ ሊሆን ይችላል።
///
/// # ተጨማሪ በ `Deref` ማስገደድ ላይ
///
/// `T` `DerefMut<Target = U>` ን የሚተገበር ከሆነ እና `x` የ `T` ዓይነት እሴት ከሆነ ከዚያ
///
/// * በሚለወጡ አውዶች ውስጥ `*x` (`T` የማጣቀሻም ሆነ ጥሬ ጠቋሚ ያልሆነበት) ከ `* DerefMut::deref_mut(&mut x)` ጋር እኩል ነው ፡፡
/// * የ `&mut T` ዓይነት እሴቶች ከ‹XXXX›ዓይነት እሴቶች ጋር ተጭነዋል
/// * `T` ሁሉንም የ X0XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXANXXXXXXSXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXsXANXXXAN NAANTAN ỌNI ፣ XXX
///
/// ለተጨማሪ ዝርዝሮች [the chapter in *The Rust Programming Language*][book] ን እንዲሁም በ [the dereference operator][ref-deref-op] ፣ [method resolution] እና [type coercions] ላይ ያሉትን የማጣቀሻ ክፍሎች ይጎብኙ።
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// አወቃቀሩን በመጥቀስ የሚቀየር ነጠላ መስክ ያለው።
///
/// ```
/// use std::ops::{Deref, DerefMut};
///
/// struct DerefMutExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefMutExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// impl<T> DerefMut for DerefMutExample<T> {
///     fn deref_mut(&mut self) -> &mut Self::Target {
///         &mut self.value
///     }
/// }
///
/// let mut x = DerefMutExample { value: 'a' };
/// *x = 'b';
/// assert_eq!('b', *x);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "deref_mut"]
#[doc(alias = "*")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DerefMut: Deref {
    /// ዋጋውን ተለዋዋጭ በሆነ መልኩ ያጠፋዋል።
    #[stable(feature = "rust1", since = "1.0.0")]
    fn deref_mut(&mut self) -> &mut Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for &mut T {
    fn deref_mut(&mut self) -> &mut T {
        *self
    }
}

/// ያለ `arbitrary_self_types` ባህሪ አንድ አወቃቀር እንደ ዘዴ መቀበያ ሆኖ ሊያገለግል እንደሚችል ያመለክታል።
///
/// ይህ `Box<T>`, `Rc<T>`, `&T`, እና `Pin<P>` እንደ stdlib ጠቋሚ አይነቶች የሚተገበር ነው.
#[lang = "receiver"]
#[unstable(feature = "receiver_trait", issue = "none")]
#[doc(hidden)]
pub trait Receiver {
    // Empty.
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &T {}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &mut T {}