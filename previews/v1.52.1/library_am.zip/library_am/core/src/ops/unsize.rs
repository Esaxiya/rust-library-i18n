use crate::marker::Unsize;

/// ይህ ጠቋሚ ወይም ጠቋሚ ላይ መዘግየት ሊከናወን የሚችልበት ለአንድ ጠቋሚ ወይም መጠቅለያ መሆኑን የሚያመለክት Trait
///
/// ለተጨማሪ ዝርዝሮች [DST coercion RFC][dst-coerce] እና [the nomicon entry on coercion][nomicon-coerce] ን ይመልከቱ ፡፡
///
/// ለተገነቡ የጠቋሚ ዓይነቶች ፣ `T` ጠቋሚዎች ከቀጭን ጠቋሚ ወደ ወፍራም ጠቋሚ በመለወጥ `T: Unsize<U>` ከሆነ ወደ `U` ጠቋሚዎችን ያስገድዳሉ ፡፡
///
/// ለብጁ ዓይነቶች ፣ እዚህ ማስገደድ የሚሠራው የ `CoerceUnsized<Foo<U>> for Foo<T>` ግኝት ካለ ከ `Foo<T>` እስከ `Foo<U>` በማስገደድ ነው ፡፡
/// እንዲህ ዓይነቱ አሻራ ሊጻፍ የሚችለው `Foo<T>` `T` ን የሚያካትት አንድ ነጠላ-ፎንቶማዳታ ያልሆነ መስክ ብቻ ካለው ብቻ ነው።
/// የዚያ መስክ ዓይነት `Bar<T>` ከሆነ የ `CoerceUnsized<Bar<U>> for Bar<T>` ትግበራ መኖር አለበት።
/// ማስገደድ የ `Bar<T>` መስክን ወደ `Bar<U>` በማስገደድ እና `Foo<U>` ን ለመፍጠር የተቀሩትን እርሻዎች ከ `Foo<T>` በመሙላት ይሠራል ፡፡
/// ይህ እስከ ጠቋሚ መስክ ድረስ በጥሩ ሁኔታ ይቆፍራል እና ያንን ያስገድዳል ፡፡
///
/// በአጠቃላይ ፣ ለዘመናዊ ጠቋሚዎች `CoerceUnsized<Ptr<U>> for Ptr<T> where T: Unsize<U>, U: ?Sized` ን ይተገብራሉ ፣ በአማራጭ `?Sized` በራሱ በ `T` ላይ ተጣብቋል ፡፡
/// እንደ `Cell<T>` እና `RefCell<T>` ያሉ `T` ን በቀጥታ ለሚጨምሩ የጥቅል ዓይነቶች ፣ በቀጥታ `CoerceUnsized<Wrap<U>> for Wrap<T> where T: CoerceUnsized<U>` ን መተግበር ይችላሉ ፡፡
///
/// ይህ እንደ `Cell<Box<T>>` ያሉ አይነቶችን ማስገደድ እንዲሠራ ያስችላቸዋል።
///
/// [`Unsize`][unsize] ከጠቋሚዎች በስተጀርባ ከሆነ ወደ DST ሊገደዱ የሚችሉትን ዓይነቶች ለማመልከት ያገለግላል።በራስ-ሰር በአቀነባባሪው ይተገበራል።
///
/// [dst-coerce]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [unsize]: crate::marker::Unsize
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
///
///
///
///
///
///
#[unstable(feature = "coerce_unsized", issue = "27732")]
#[lang = "coerce_unsized"]
pub trait CoerceUnsized<T: ?Sized> {
    // Empty.
}

// &mut ቲ-> &mut ዩ
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a mut U> for &'a mut T {}
// &mut ቲ-> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b mut T {}
// &mut ቲ-> * mut ዩ
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for &'a mut T {}
// &mut T-> * const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a mut T {}

// &T -> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b T {}
// &T -> * const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a T {}

// *mut T->* mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for *mut T {}
// *mut T->* const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *mut T {}

// *const T->* const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *const T {}

/// ይህ የነገር ደህንነት ፣ የአንድ ዘዴ ተቀባዩ ዓይነት መላክ መቻሉን ለማጣራት ነው።
///
/// የ trait ምሳሌ ትግበራ
///
/// ```
/// # #![feature(dispatch_from_dyn, unsize)]
/// # use std::{ops::DispatchFromDyn, marker::Unsize};
/// # struct Rc<T: ?Sized>(std::rc::Rc<T>);
/// impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T>
/// where
///     T: Unsize<U>,
/// {}
/// ```
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
#[lang = "dispatch_from_dyn"]
pub trait DispatchFromDyn<T> {
    // Empty.
}

// &T -> &U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a U> for &'a T {}
// &mut ቲ-> &mut ዩ
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a mut U> for &'a mut T {}
// *const T->* const U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*const U> for *const T {}
// *mut T->* mut U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*mut U> for *mut T {}