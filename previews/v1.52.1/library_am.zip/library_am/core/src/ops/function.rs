/// የማይለወጥ ተቀባይን የሚወስድ የጥሪ ኦፕሬተር ስሪት።
///
/// የ `Fn` አጋጣሚዎች ሁኔታ ሳይለወጡ በተደጋጋሚ ሊጠሩ ይችላሉ።
///
/// *ይህ trait (`Fn`) ከ [function pointers] (`fn`) ጋር መደባለቅ የለበትም።*
///
/// `Fn` በተያዙ ተለዋዋጮች የማይለዋወጥ ማመሳከሪያዎችን ብቻ የሚወስድ ወይም በጭራሽ ምንም ነገር የማይይዝ በመዝጋት በራስ-ሰር ይተገበራል ፣ እንዲሁም (safe) [function pointers] (ከአንዳንድ ማስጠንቀቂያዎች ጋር ፣ ለተጨማሪ ዝርዝሮች ሰነዳቸውን ይመልከቱ) ፡፡
///
/// በተጨማሪም `Fn` ን ለሚተገብር ለማንኛውም `F` ፣ `&F` `Fn` ን ይተገበራል ፡፡
///
/// ሁለቱም [`FnMut`] እና [`FnOnce`] የ `Fn` ልዕለ-ልዕለ-ሃሳቦች በመሆናቸው ማንኛውም የ `Fn` ምሳሌ [`FnMut`] ወይም [`FnOnce`] የሚጠበቅበት እንደ መለኪያ ሆኖ ሊያገለግል ይችላል ፡፡
///
/// እንደ ተግባር ዓይነት የመለኪያ ልኬትን ለመቀበል ሲፈልጉ `Fn` ን እንደአስፈላጊነቱ ይጠቀሙበት እና ያለ ሁኔታ መለወጥ (ለምሳሌ ፣ በአንድ ጊዜ ሲደውሉ) መደወል ያስፈልግዎታል።
/// እንደዚህ አይነት ጥብቅ መስፈርቶች የማይፈልጉ ከሆነ [`FnMut`] ወይም [`FnOnce`] ን እንደ ወሰን ይጠቀሙ ፡፡
///
/// በዚህ ርዕስ ላይ ለተጨማሪ መረጃ [chapter on closures in *The Rust Programming Language*][book] ን ይመልከቱ።
///
/// በተጨማሪም ማስታወሻ ለ `Fn` traits ልዩ አገባብ ነው (ለምሳሌ
/// `Fn(usize, bool) -> ተጠቀም›)።ለዚህ ቴክኒካዊ ዝርዝሮች ፍላጎት ያላቸው [the relevant section in the *Rustonomicon*][nomicon] ን ሊያመለክቱ ይችላሉ ፡፡
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## አንድ መዘጋት በመጥራት ላይ
///
/// ```
/// let square = |x| x * x;
/// assert_eq!(square(5), 25);
/// ```
///
/// ## የ `Fn` መለኪያ በመጠቀም
///
/// ```
/// fn call_with_one<F>(func: F) -> usize
///     where F: Fn(usize) -> usize {
///     func(1)
/// }
///
/// let double = |x| x * 2;
/// assert_eq!(call_with_one(double), 2);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{Fn}<{Args}>` closure, found `{Self}`",
    label = "expected an `Fn<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // ስለዚህ regex በዛ `&str: !FnMut` ላይ መተማመን ይችላል
#[must_use = "closures are lazy and do nothing unless called"]
pub trait Fn<Args>: FnMut<Args> {
    /// የጥሪ ሥራውን ያከናውናል።
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call(&self, args: Args) -> Self::Output;
}

/// ሊለዋወጥ የሚችል ተቀባይን የሚወስድ የጥሪ ኦፕሬተር ሥሪት።
///
/// የ `FnMut` አጋጣሚዎች በተደጋጋሚ ሊጠሩ እና ሁኔታውን ሊለውጡ ይችላሉ።
///
/// `FnMut` ወደ ተያዙ ተለዋዋጮች ሊለዋወጥ የሚችል ማጣቀሻዎችን የሚወስዱ መዝጊያዎች እንዲሁም [`Fn`] ን ፣ ለምሳሌ (safe) [function pointers] ን የሚተገብሩ ሁሉም ዓይነቶች (`FnMut` የ [`Fn`] ልዕለ-ልዕለ-ደረጃ ስለሆነ) በራስ-ሰር ይተገበራል።
/// በተጨማሪም `FnMut` ን ለሚተገብር ለማንኛውም `F` ፣ `&mut F` `FnMut` ን ይተገበራል ፡፡
///
/// [`FnOnce`] የ‹XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX) ይጠበቃል
///
/// እንደ ተግባር ዓይነት የመሣሪያ ግቤትን ለመቀበል ሲፈልጉ እና ሁኔታውን እንዲቀይር በሚፈቅድበት ጊዜ ደጋግመው መደወል ሲፈልጉ `FnMut` ን እንደ ወሰን ይጠቀሙ።
/// መለኪያው ሁኔታውን እንዲለውጥ የማይፈልጉ ከሆነ [`Fn`] ን እንደ ወሰን ይጠቀሙ;ደጋግመው መደወል የማያስፈልግዎ ከሆነ [`FnOnce`] ይጠቀሙ።
///
/// በዚህ ርዕስ ላይ ለተጨማሪ መረጃ [chapter on closures in *The Rust Programming Language*][book] ን ይመልከቱ።
///
/// በተጨማሪም ማስታወሻ ለ `Fn` traits ልዩ አገባብ ነው (ለምሳሌ
/// `Fn(usize, bool) -> ተጠቀም›)።ለዚህ ቴክኒካዊ ዝርዝሮች ፍላጎት ያላቸው [the relevant section in the *Rustonomicon*][nomicon] ን ሊያመለክቱ ይችላሉ ፡፡
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## በሚስጥር የሚይዝ መዝጊያ በመጥራት ላይ
///
/// ```
/// let mut x = 5;
/// {
///     let mut square_x = || x *= x;
///     square_x();
/// }
/// assert_eq!(x, 25);
/// ```
///
/// ## የ `FnMut` መለኪያ በመጠቀም
///
/// ```
/// fn do_twice<F>(mut func: F)
///     where F: FnMut()
/// {
///     func();
///     func();
/// }
///
/// let mut x: usize = 1;
/// {
///     let add_two_to_x = || x += 2;
///     do_twice(add_two_to_x);
/// }
///
/// assert_eq!(x, 5);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn_mut"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnMut}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnMut<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // ስለዚህ regex በዛ `&str: !FnMut` ላይ መተማመን ይችላል
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnMut<Args>: FnOnce<Args> {
    /// የጥሪ ሥራውን ያከናውናል።
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_mut(&mut self, args: Args) -> Self::Output;
}

/// የእሴት ተቀባይን የሚወስድ የጥሪ ኦፕሬተር ስሪት።
///
/// የ `FnOnce` አጋጣሚዎች ሊጠሩ ይችላሉ ፣ ግን ብዙ ጊዜ ሊከሱ አይችሉም ፡፡በዚህ ምክንያት ፣ ስለ አንድ ዓይነት የሚታወቅ ነገር `FnOnce` ን ተግባራዊ ማድረጉ ብቻ ከሆነ አንድ ጊዜ ብቻ ሊጠራ ይችላል።
///
/// `FnOnce` የተያዙ ተለዋዋጮችን በሚወስዱ መዝጊያዎች እንዲሁም [`FnMut`] ን ፣ ለምሳሌ (safe) [function pointers] ን በሚተገብሩ መዝጊያዎች በራስ-ሰር ይተገበራል (`FnOnce` የ [`FnMut`] ልዕለ-ልዕልት ስለሆነ)።
///
///
/// ሁለቱም [`Fn`] እና [`FnMut`] የ `FnOnce` ንዑስ ክፍሎች በመሆናቸው ማንኛውም የ [`Fn`] ወይም [`FnMut`] ምሳሌ `FnOnce` በሚጠበቅበት ቦታ ጥቅም ላይ ሊውል ይችላል ፡፡
///
/// የተግባር መሰል ዓይነት ግቤትን ለመቀበል ሲፈልጉ እና አንድ ጊዜ ብቻ መደወል ሲፈልጉ `FnOnce` ን እንደ ወሰን ይጠቀሙ።
/// መለኪያውን ደጋግመው ለመጥራት ከፈለጉ [`FnMut`] ን እንደ ወሰን ይጠቀሙ;እርስዎ ሁኔታውን ላለመቀየር ከፈለጉ ደግሞ [`Fn`] ን ይጠቀሙ።
///
/// በዚህ ርዕስ ላይ ለተጨማሪ መረጃ [chapter on closures in *The Rust Programming Language*][book] ን ይመልከቱ።
///
/// በተጨማሪም ማስታወሻ ለ `Fn` traits ልዩ አገባብ ነው (ለምሳሌ
/// `Fn(usize, bool) -> ተጠቀም›)።ለዚህ ቴክኒካዊ ዝርዝሮች ፍላጎት ያላቸው [the relevant section in the *Rustonomicon*][nomicon] ን ሊያመለክቱ ይችላሉ ፡፡
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## የ `FnOnce` መለኪያ በመጠቀም
///
/// ```
/// fn consume_with_relish<F>(func: F)
///     where F: FnOnce() -> String
/// {
///     // `func` የተያዙትን ተለዋዋጮች ይወስዳል ፣ ስለሆነም ከአንድ ጊዜ በላይ ሊሠራ አይችልም።
/////
///     println!("Consumed: {}", func());
///
///     println!("Delicious!");
///
///     // እንደገና `func()` ን ለመጥራት መሞከር ለ `func` የ `use of moved value` ስህተት ይጥላል ፡፡
/////
/// }
///
/// let x = String::from("x");
/// let consume_and_return_x = move || x;
/// consume_with_relish(consume_and_return_x);
///
/// // `consume_and_return_x` በዚህ ጊዜ ከአሁን በኋላ መጠራት አይቻልም
/// ```
///
///
///
///
///
///
///
///
#[lang = "fn_once"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnOnce}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnOnce<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // ስለዚህ regex በዛ `&str: !FnMut` ላይ መተማመን ይችላል
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnOnce<Args> {
    /// የጥሪው ኦፕሬተር ጥቅም ላይ ከዋለ በኋላ የተመለሰው ዓይነት ፡፡
    #[lang = "fn_once_output"]
    #[stable(feature = "fn_once_output", since = "1.12.0")]
    type Output;

    /// የጥሪ ሥራውን ያከናውናል።
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_once(self, args: Args) -> Self::Output;
}

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> Fn<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call(&self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &F
    where
        F: Fn<A>,
    {
        type Output = F::Output;

        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &mut F
    where
        F: FnMut<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &mut F
    where
        F: FnMut<A>,
    {
        type Output = F::Output;
        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }
}