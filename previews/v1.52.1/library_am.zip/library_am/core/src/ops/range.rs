use crate::fmt;
use crate::hash::Hash;

/// ያልተገደበ ክልል (`..`)።
///
/// `RangeFull` በዋናነት እንደ [slicing index] ጥቅም ላይ ይውላል ፣ አጭሩ‹`..`›ነው ፡፡
/// የመነሻ ቦታ ስለሌለው እንደ [`Iterator`] ሆኖ ሊያገለግል አይችልም።
///
/// # Examples
///
/// የ `..` አገባብ `RangeFull` ነው
///
/// ```
/// assert_eq!((..), std::ops::RangeFull);
/// ```
///
/// የ [`IntoIterator`] ትግበራ የለውም ፣ ስለሆነም በቀጥታ በ‹`for` loop›ውስጥ መጠቀም አይችሉም ፡፡
/// ይህ አያጠናቅቅም
///
/// ```compile_fail,E0277
/// for i in .. {
///     // ...
/// }
/// ```
///
/// እንደ [slicing index] ጥቅም ላይ የዋለ ፣ `RangeFull` ሙሉ ድርድርን እንደ ቁርጥራጭ ያወጣል።
///
/// ```
/// let arr = [0, 1, 2, 3, 4];
/// assert_eq!(arr[ ..  ], [0, 1, 2, 3, 4]); // ይህ `RangeFull` ነው
/// assert_eq!(arr[ .. 3], [0, 1, 2      ]);
/// assert_eq!(arr[ ..=3], [0, 1, 2, 3   ]);
/// assert_eq!(arr[1..  ], [   1, 2, 3, 4]);
/// assert_eq!(arr[1.. 3], [   1, 2      ]);
/// assert_eq!(arr[1..=3], [   1, 2, 3   ]);
/// ```
///
/// [slicing index]: crate::slice::SliceIndex
#[lang = "RangeFull"]
#[doc(alias = "..")]
#[derive(Copy, Clone, Default, PartialEq, Eq, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RangeFull;

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for RangeFull {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(fmt, "..")
    }
}

/// አንድ የ (half-open) ክልል ከ (`start..end`) በታች ብቻ እና ሙሉ በሙሉ የታሰረ ነበር።
///
///
/// የ `start..end` ክልል ከ `start <= x < end` ጋር ሁሉንም እሴቶች ይ containsል።
/// `start >= end` ከሆነ ባዶ ነው።
///
/// # Examples
///
/// የ `start..end` አገባብ `Range` ነው
///
/// ```
/// assert_eq!((3..5), std::ops::Range { start: 3, end: 5 });
/// assert_eq!(3 + 4 + 5, (3..6).sum());
/// ```
///
/// ```
/// let arr = [0, 1, 2, 3, 4];
/// assert_eq!(arr[ ..  ], [0, 1, 2, 3, 4]);
/// assert_eq!(arr[ .. 3], [0, 1, 2      ]);
/// assert_eq!(arr[ ..=3], [0, 1, 2, 3   ]);
/// assert_eq!(arr[1..  ], [   1, 2, 3, 4]);
/// assert_eq!(arr[1.. 3], [   1, 2      ]); // ይህ `Range` ነው
/// assert_eq!(arr[1..=3], [   1, 2, 3   ]);
/// ```
#[lang = "Range"]
#[doc(alias = "..")]
#[derive(Clone, Default, PartialEq, Eq, Hash)] // አይደለም ቅዳ-#27186 ን ይመልከቱ
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Range<Idx> {
    /// የ (inclusive) ክልል ዝቅተኛ ወሰን።
    #[stable(feature = "rust1", since = "1.0.0")]
    pub start: Idx,
    /// የ (exclusive) ክልል የላይኛው ወሰን።
    #[stable(feature = "rust1", since = "1.0.0")]
    pub end: Idx,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<Idx: fmt::Debug> fmt::Debug for Range<Idx> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.start.fmt(fmt)?;
        write!(fmt, "..")?;
        self.end.fmt(fmt)?;
        Ok(())
    }
}

impl<Idx: PartialOrd<Idx>> Range<Idx> {
    /// `item` በክልሉ ውስጥ ከያዘ `true` ን ይመልሳል።
    ///
    /// # Examples
    ///
    /// ```
    /// assert!(!(3..5).contains(&2));
    /// assert!( (3..5).contains(&3));
    /// assert!( (3..5).contains(&4));
    /// assert!(!(3..5).contains(&5));
    ///
    /// assert!(!(3..3).contains(&3));
    /// assert!(!(3..2).contains(&3));
    ///
    /// assert!( (0.0..1.0).contains(&0.5));
    /// assert!(!(0.0..1.0).contains(&f32::NAN));
    /// assert!(!(0.0..f32::NAN).contains(&0.5));
    /// assert!(!(f32::NAN..1.0).contains(&0.5));
    /// ```
    #[stable(feature = "range_contains", since = "1.35.0")]
    pub fn contains<U>(&self, item: &U) -> bool
    where
        Idx: PartialOrd<U>,
        U: ?Sized + PartialOrd<Idx>,
    {
        <Self as RangeBounds<Idx>>::contains(self, item)
    }

    /// ክልሉ ምንም እቃዎችን ከሌለው `true` ን ይመልሳል።
    ///
    /// # Examples
    ///
    /// ```
    /// assert!(!(3..5).is_empty());
    /// assert!( (3..3).is_empty());
    /// assert!( (3..2).is_empty());
    /// ```
    ///
    /// የትኛውም ወገን ተወዳዳሪ ከሌለው ክልሉ ባዶ ነው
    ///
    /// ```
    /// assert!(!(3.0..5.0).is_empty());
    /// assert!( (3.0..f32::NAN).is_empty());
    /// assert!( (f32::NAN..5.0).is_empty());
    /// ```
    #[stable(feature = "range_is_empty", since = "1.47.0")]
    pub fn is_empty(&self) -> bool {
        !(self.start < self.end)
    }
}

/// አንድ ክልል ከ (`start..`) በታች ብቻ የሚገደብ ነው።
///
/// `RangeFrom` `start..` ከ `x >= start` ጋር ሁሉንም እሴቶች ይ containsል።
///
/// *ማስታወሻ*:-በ [`Iterator`] ትግበራ ውስጥ ያለው ፍሰት (የተያዘው የውሂብ አይነት የቁጥር ገደቡ ላይ ሲደርስ) ለ panic ፣ መጠቅለያ ወይም ማርካት ይፈቀዳል።
/// ይህ ባህሪ በ [`Step`] trait ትግበራ ይገለጻል።
/// ለጥንታዊ ቁጥሮች ፣ ይህ መደበኛውን ህጎች ይከተላል ፣ እና የትርፍ ፍሰት ፍተሻዎችን መገለጫ ያከብራል (panic በማረም ላይ ፣ የተለቀቀ መጠቅለል)።
/// እንዲሁም ከሚገምቱት ቀደም ብሎ የተትረፈረፈ ፍሰት እንደሚከሰት ልብ ይበሉ-የሚቀጥለው እሴት ለማቅረብ ክልሉ ወደ ክልል መዘጋጀት ስላለበት የተትረፈረፈ ፍሰት ከፍተኛውን እሴት በሚያስገኝ `next` ጥሪ ውስጥ ይከሰታል ፡፡
///
///
/// [`Step`]: crate::iter::Step
///
/// # Examples
///
/// የ `start..` አገባብ `RangeFrom` ነው
///
/// ```
/// assert_eq!((2..), std::ops::RangeFrom { start: 2 });
/// assert_eq!(2 + 3 + 4, (2..).take(3).sum());
/// ```
///
/// ```
/// let arr = [0, 1, 2, 3, 4];
/// assert_eq!(arr[ ..  ], [0, 1, 2, 3, 4]);
/// assert_eq!(arr[ .. 3], [0, 1, 2      ]);
/// assert_eq!(arr[ ..=3], [0, 1, 2, 3   ]);
/// assert_eq!(arr[1..  ], [   1, 2, 3, 4]); // ይህ `RangeFrom` ነው
/// assert_eq!(arr[1.. 3], [   1, 2      ]);
/// assert_eq!(arr[1..=3], [   1, 2, 3   ]);
/// ```
///
///
///
#[lang = "RangeFrom"]
#[doc(alias = "..")]
#[derive(Clone, PartialEq, Eq, Hash)] // አይደለም ቅዳ-#27186 ን ይመልከቱ
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RangeFrom<Idx> {
    /// የ (inclusive) ክልል ዝቅተኛ ወሰን።
    #[stable(feature = "rust1", since = "1.0.0")]
    pub start: Idx,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<Idx: fmt::Debug> fmt::Debug for RangeFrom<Idx> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.start.fmt(fmt)?;
        write!(fmt, "..")?;
        Ok(())
    }
}

impl<Idx: PartialOrd<Idx>> RangeFrom<Idx> {
    /// `item` በክልሉ ውስጥ ከያዘ `true` ን ይመልሳል።
    ///
    /// # Examples
    ///
    /// ```
    /// assert!(!(3..).contains(&2));
    /// assert!( (3..).contains(&3));
    /// assert!( (3..).contains(&1_000_000_000));
    ///
    /// assert!( (0.0..).contains(&0.5));
    /// assert!(!(0.0..).contains(&f32::NAN));
    /// assert!(!(f32::NAN..).contains(&0.5));
    /// ```
    #[stable(feature = "range_contains", since = "1.35.0")]
    pub fn contains<U>(&self, item: &U) -> bool
    where
        Idx: PartialOrd<U>,
        U: ?Sized + PartialOrd<Idx>,
    {
        <Self as RangeBounds<Idx>>::contains(self, item)
    }
}

/// አንድ ክልል ከ (`..end`) በላይ ብቻ የተገደበ ነው።
///
/// `RangeTo` `..end` ሁሉንም እሴቶች ከ `x < end` ጋር ይ containsል።
/// የመነሻ ቦታ ስለሌለው እንደ [`Iterator`] ሆኖ ሊያገለግል አይችልም።
///
/// # Examples
///
/// የ `..end` አገባብ `RangeTo` ነው
///
/// ```
/// assert_eq!((..5), std::ops::RangeTo { end: 5 });
/// ```
///
/// የ [`IntoIterator`] ትግበራ የለውም ፣ ስለሆነም በቀጥታ በ‹`for` loop›ውስጥ መጠቀም አይችሉም ፡፡
/// ይህ አያጠናቅቅም
///
/// ```compile_fail,E0277
/// // error[E0277]: the trait bound `std::ops::RangeTo<{integer}>:
/// // std::iter::Iterator` is not satisfied
/// for i in ..5 {
///     // ...
/// }
/// ```
///
/// እንደ [slicing index] ጥቅም ላይ ሲውል ፣ `RangeTo` በ `end` ከተጠቀሰው መረጃ ጠቋሚ በፊት የሁሉም ድርድር አባሎችን አንድ ቁራጭ ያስገኛል።
///
///
/// ```
/// let arr = [0, 1, 2, 3, 4];
/// assert_eq!(arr[ ..  ], [0, 1, 2, 3, 4]);
/// assert_eq!(arr[ .. 3], [0, 1, 2      ]); // ይህ `RangeTo` ነው
/// assert_eq!(arr[ ..=3], [0, 1, 2, 3   ]);
/// assert_eq!(arr[1..  ], [   1, 2, 3, 4]);
/// assert_eq!(arr[1.. 3], [   1, 2      ]);
/// assert_eq!(arr[1..=3], [   1, 2, 3   ]);
/// ```
///
/// [slicing index]: crate::slice::SliceIndex
#[lang = "RangeTo"]
#[doc(alias = "..")]
#[derive(Copy, Clone, PartialEq, Eq, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RangeTo<Idx> {
    /// የ (exclusive) ክልል የላይኛው ወሰን።
    #[stable(feature = "rust1", since = "1.0.0")]
    pub end: Idx,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<Idx: fmt::Debug> fmt::Debug for RangeTo<Idx> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(fmt, "..")?;
        self.end.fmt(fmt)?;
        Ok(())
    }
}

impl<Idx: PartialOrd<Idx>> RangeTo<Idx> {
    /// `item` በክልሉ ውስጥ ከያዘ `true` ን ይመልሳል።
    ///
    /// # Examples
    ///
    /// ```
    /// assert!( (..5).contains(&-1_000_000_000));
    /// assert!( (..5).contains(&4));
    /// assert!(!(..5).contains(&5));
    ///
    /// assert!( (..1.0).contains(&0.5));
    /// assert!(!(..1.0).contains(&f32::NAN));
    /// assert!(!(..f32::NAN).contains(&0.5));
    /// ```
    #[stable(feature = "range_contains", since = "1.35.0")]
    pub fn contains<U>(&self, item: &U) -> bool
    where
        Idx: PartialOrd<U>,
        U: ?Sized + PartialOrd<Idx>,
    {
        <Self as RangeBounds<Idx>>::contains(self, item)
    }
}

/// አንድ ክልል ከ (`start..=end`) በታች እና ከዚያ በላይ በሆነ ወሰን ተሞልቷል።
///
/// `RangeInclusive` `start..=end` ሁሉንም እሴቶች ከ `x >= start` እና `x <= end` ጋር ይ containsል።`start <= end` ካልሆነ በስተቀር ባዶ ነው።
///
/// ይህ ተሟጋች [fused] ነው ፣ ግን ድግምግሞሽ ከጨረሰ በኋላ የ `start` እና `end` የተወሰኑ እሴቶች **ያልተገለፁ ናቸው** ከዚያ [`.is_empty()`] ሌላ እሴቶች ካልተመረቱ `true` ን ይመልሳሉ።
///
///
/// [fused]: crate::iter::FusedIterator
/// [`.is_empty()`]: RangeInclusive::is_empty
///
/// # Examples
///
/// የ `start..=end` አገባብ `RangeInclusive` ነው
///
/// ```
/// assert_eq!((3..=5), std::ops::RangeInclusive::new(3, 5));
/// assert_eq!(3 + 4 + 5, (3..=5).sum());
/// ```
///
/// ```
/// let arr = [0, 1, 2, 3, 4];
/// assert_eq!(arr[ ..  ], [0, 1, 2, 3, 4]);
/// assert_eq!(arr[ .. 3], [0, 1, 2      ]);
/// assert_eq!(arr[ ..=3], [0, 1, 2, 3   ]);
/// assert_eq!(arr[1..  ], [   1, 2, 3, 4]);
/// assert_eq!(arr[1.. 3], [   1, 2      ]);
/// assert_eq!(arr[1..=3], [   1, 2, 3   ]); // ይህ `RangeInclusive` ነው
/// ```
///
///
#[lang = "RangeInclusive"]
#[doc(alias = "..=")]
#[derive(Clone, PartialEq, Eq, Hash)] // አይደለም ቅዳ-#27186 ን ይመልከቱ
#[stable(feature = "inclusive_range", since = "1.26.0")]
pub struct RangeInclusive<Idx> {
    // በ future ውስጥ ውክልናን ለመለወጥ እዚህ ያሉት መስኮች ይፋዊ እንዳልሆኑ ልብ ይበሉ;በተለይም start/end ን በአሳማኝ ሁኔታ ማጋለጥ የምንችል ቢሆንም (future/current) የግል መስኮችን ሳይቀይሩ እነሱን ማሻሻል ወደ የተሳሳተ ባህሪ ይመራናል ፣ ስለሆነም ያንን ሞድ መደገፍ አንፈልግም ፡፡
    //
    //
    //
    //
    pub(crate) start: Idx,
    pub(crate) end: Idx,

    // ይህ መስክ
    //  - `false` በግንባታ ላይ
    //  - `false` ድግግሞሽ አንድ ንጥረ ነገር ሲሰጥ እና ተደጋጋሚው ሳይደክም
    //  - `true` ድጋሜው ተሟጋቹን ለማዳከም ጥቅም ላይ ሲውል
    //
    // ያለ `PartialOrd` ወሰን ወይም የልዩነት ሙያ ያለ `PartialEq` እና `Hash` ን ለመደገፍ ይህ ያስፈልጋል።
    pub(crate) exhausted: bool,
}

impl<Idx> RangeInclusive<Idx> {
    /// አዲስ የሚያካትት ክልል ይፈጥራል።`start..=end` ን ለመፃፍ እኩል ነው።
    ///
    /// # Examples
    ///
    /// ```
    /// use std::ops::RangeInclusive;
    ///
    /// assert_eq!(3..=5, RangeInclusive::new(3, 5));
    /// ```
    #[lang = "range_inclusive_new"]
    #[stable(feature = "inclusive_range_methods", since = "1.27.0")]
    #[inline]
    #[rustc_promotable]
    #[rustc_const_stable(feature = "const_range_new", since = "1.32.0")]
    pub const fn new(start: Idx, end: Idx) -> Self {
        Self { start, end, exhausted: false }
    }

    /// የክልሉን (inclusive) ዝቅተኛ ወሰን ይመልሳል።
    ///
    /// ለመድገም ሁለገብ ክልል ሲጠቀሙ የ `start()` እና [`end()`] እሴቶች ድጋፉ ከተጠናቀቀ በኋላ አልተገለፁም ፡፡
    /// አካታችው ክልል ባዶ መሆኑን ለመለየት `start() > end()` ን ከማነፃፀር ይልቅ የ [`is_empty()`] ዘዴን ይጠቀሙ ፡፡
    ///
    /// Note: ክልሉ ለድካሙ ከተሰራ በኋላ በዚህ ዘዴ የተመለሰው ዋጋ አልተገለጸም ፡፡
    ///
    /// [`end()`]: RangeInclusive::end
    /// [`is_empty()`]: RangeInclusive::is_empty
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!((3..=5).start(), &3);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "inclusive_range_methods", since = "1.27.0")]
    #[rustc_const_stable(feature = "const_inclusive_range_methods", since = "1.32.0")]
    #[inline]
    pub const fn start(&self) -> &Idx {
        &self.start
    }

    /// የክልሉን (inclusive) የላይኛው ወሰን ይመልሳል።
    ///
    /// ለመድገም ሁለገብ ክልል ሲጠቀሙ የ [`start()`] እና `end()` እሴቶች ድጋፉ ከተጠናቀቀ በኋላ አልተገለፁም ፡፡
    /// አካታችው ክልል ባዶ መሆኑን ለመለየት `start() > end()` ን ከማነፃፀር ይልቅ የ [`is_empty()`] ዘዴን ይጠቀሙ ፡፡
    ///
    /// Note: ክልሉ ለድካሙ ከተሰራ በኋላ በዚህ ዘዴ የተመለሰው ዋጋ አልተገለጸም ፡፡
    ///
    /// [`start()`]: RangeInclusive::start
    /// [`is_empty()`]: RangeInclusive::is_empty
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!((3..=5).end(), &5);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "inclusive_range_methods", since = "1.27.0")]
    #[rustc_const_stable(feature = "const_inclusive_range_methods", since = "1.32.0")]
    #[inline]
    pub const fn end(&self) -> &Idx {
        &self.end
    }

    /// `RangeInclusive` ን ወደ (ዝቅተኛ ማሰሪያ ፣ የላይኛው (inclusive) ማሰሪያ) ያጠፋል።
    ///
    /// Note: ክልሉ ለድካሙ ከተሰራ በኋላ በዚህ ዘዴ የተመለሰው ዋጋ አልተገለጸም ፡፡
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!((3..=5).into_inner(), (3, 5));
    /// ```
    #[stable(feature = "inclusive_range_methods", since = "1.27.0")]
    #[inline]
    pub fn into_inner(self) -> (Idx, Idx) {
        (self.start, self.end)
    }
}

impl RangeInclusive<usize> {
    /// ለ `SliceIndex` ትግበራዎች ወደ ብቸኛ `Range` ይቀይራል።
    /// ደዋዩ `end == usize::MAX` ን ለማስተናገድ ሃላፊነት አለበት።
    #[inline]
    pub(crate) fn into_slice_range(self) -> Range<usize> {
        // ደክሞ ካልሆንን በቀላሉ `start..end + 1` ን መቁረጥ እንፈልጋለን።
        // ደክሞን ከሆነ በ‹XXXX›ጋር መቀንጠዝ ለዚያ የመጨረሻ ነጥብ አሁንም ቢሆን የድንበር-ቼኮች ተገዢ የሆነ ባዶ ክልል ይሰጠናል።
        //
        let exclusive_end = self.end + 1;
        let start = if self.exhausted { exclusive_end } else { self.start };
        start..exclusive_end
    }
}

#[stable(feature = "inclusive_range", since = "1.26.0")]
impl<Idx: fmt::Debug> fmt::Debug for RangeInclusive<Idx> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.start.fmt(fmt)?;
        write!(fmt, "..=")?;
        self.end.fmt(fmt)?;
        if self.exhausted {
            write!(fmt, " (exhausted)")?;
        }
        Ok(())
    }
}

impl<Idx: PartialOrd<Idx>> RangeInclusive<Idx> {
    /// `item` በክልሉ ውስጥ ከያዘ `true` ን ይመልሳል።
    ///
    /// # Examples
    ///
    /// ```
    /// assert!(!(3..=5).contains(&2));
    /// assert!( (3..=5).contains(&3));
    /// assert!( (3..=5).contains(&4));
    /// assert!( (3..=5).contains(&5));
    /// assert!(!(3..=5).contains(&6));
    ///
    /// assert!( (3..=3).contains(&3));
    /// assert!(!(3..=2).contains(&3));
    ///
    /// assert!( (0.0..=1.0).contains(&1.0));
    /// assert!(!(0.0..=1.0).contains(&f32::NAN));
    /// assert!(!(0.0..=f32::NAN).contains(&0.0));
    /// assert!(!(f32::NAN..=1.0).contains(&1.0));
    /// ```
    ///
    /// ይህ ዘዴ ሁልጊዜ ድግግሞሽ ከጨረሰ በኋላ `false` ን ይመልሳል-
    ///
    /// ```
    /// let mut r = 3..=5;
    /// assert!(r.contains(&3) && r.contains(&5));
    /// for _ in r.by_ref() {}
    /// // ትክክለኛ የመስክ እሴቶች እዚህ አልተገለፁም
    /// assert!(!r.contains(&3) && !r.contains(&5));
    /// ```
    #[stable(feature = "range_contains", since = "1.35.0")]
    pub fn contains<U>(&self, item: &U) -> bool
    where
        Idx: PartialOrd<U>,
        U: ?Sized + PartialOrd<Idx>,
    {
        <Self as RangeBounds<Idx>>::contains(self, item)
    }

    /// ክልሉ ምንም እቃዎችን ከሌለው `true` ን ይመልሳል።
    ///
    /// # Examples
    ///
    /// ```
    /// assert!(!(3..=5).is_empty());
    /// assert!(!(3..=3).is_empty());
    /// assert!( (3..=2).is_empty());
    /// ```
    ///
    /// የትኛውም ወገን ተወዳዳሪ ከሌለው ክልሉ ባዶ ነው
    ///
    /// ```
    /// assert!(!(3.0..=5.0).is_empty());
    /// assert!( (3.0..=f32::NAN).is_empty());
    /// assert!( (f32::NAN..=5.0).is_empty());
    /// ```
    ///
    /// ይህ ዘዴ ድግግሞሽ ከጨረሰ በኋላ `true` ን ይመልሳል
    ///
    /// ```
    /// let mut r = 3..=5;
    /// for _ in r.by_ref() {}
    /// // ትክክለኛ የመስክ እሴቶች እዚህ አልተገለፁም
    /// assert!(r.is_empty());
    /// ```
    #[stable(feature = "range_is_empty", since = "1.47.0")]
    #[inline]
    pub fn is_empty(&self) -> bool {
        self.exhausted || !(self.start <= self.end)
    }
}

/// አንድ ክልል ከ (`..=end`) በላይ ብቻ የተገደበ ነው።
///
/// `RangeToInclusive` `..=end` ሁሉንም እሴቶች ከ `x <= end` ጋር ይ containsል።
/// የመነሻ ቦታ ስለሌለው እንደ [`Iterator`] ሆኖ ሊያገለግል አይችልም።
///
/// # Examples
///
/// የ `..=end` አገባብ `RangeToInclusive` ነው
///
/// ```
/// assert_eq!((..=5), std::ops::RangeToInclusive{ end: 5 });
/// ```
///
/// የ [`IntoIterator`] ትግበራ የለውም ፣ ስለሆነም በቀጥታ በ‹`for` loop›ውስጥ መጠቀም አይችሉም ፡፡ይህ አያጠናቅቅም
///
/// ```compile_fail,E0277
/// // error[E0277]: the trait bound `std::ops::RangeToInclusive<{integer}>:
/// // std::iter::Iterator` is not satisfied
/// for i in ..=5 {
///     // ...
/// }
/// ```
///
/// እንደ [slicing index] ጥቅም ላይ ሲውል ፣ `RangeToInclusive` እስከ `end` የተጠቆመውን መረጃ ጠቋሚ ጨምሮ ሁሉንም የድርድር አካላት አንድ ቁራጭ ያስገኛል።
///
///
/// ```
/// let arr = [0, 1, 2, 3, 4];
/// assert_eq!(arr[ ..  ], [0, 1, 2, 3, 4]);
/// assert_eq!(arr[ .. 3], [0, 1, 2      ]);
/// assert_eq!(arr[ ..=3], [0, 1, 2, 3   ]); // ይህ `RangeToInclusive` ነው
/// assert_eq!(arr[1..  ], [   1, 2, 3, 4]);
/// assert_eq!(arr[1.. 3], [   1, 2      ]);
/// assert_eq!(arr[1..=3], [   1, 2, 3   ]);
/// ```
///
/// [slicing index]: crate::slice::SliceIndex
///
#[lang = "RangeToInclusive"]
#[doc(alias = "..=")]
#[derive(Copy, Clone, PartialEq, Eq, Hash)]
#[stable(feature = "inclusive_range", since = "1.26.0")]
pub struct RangeToInclusive<Idx> {
    /// የ (inclusive) ክልል የላይኛው ወሰን
    #[stable(feature = "inclusive_range", since = "1.26.0")]
    pub end: Idx,
}

#[stable(feature = "inclusive_range", since = "1.26.0")]
impl<Idx: fmt::Debug> fmt::Debug for RangeToInclusive<Idx> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(fmt, "..=")?;
        self.end.fmt(fmt)?;
        Ok(())
    }
}

impl<Idx: PartialOrd<Idx>> RangeToInclusive<Idx> {
    /// `item` በክልሉ ውስጥ ከያዘ `true` ን ይመልሳል።
    ///
    /// # Examples
    ///
    /// ```
    /// assert!( (..=5).contains(&-1_000_000_000));
    /// assert!( (..=5).contains(&5));
    /// assert!(!(..=5).contains(&6));
    ///
    /// assert!( (..=1.0).contains(&1.0));
    /// assert!(!(..=1.0).contains(&f32::NAN));
    /// assert!(!(..=f32::NAN).contains(&0.5));
    /// ```
    #[stable(feature = "range_contains", since = "1.35.0")]
    pub fn contains<U>(&self, item: &U) -> bool
    where
        Idx: PartialOrd<U>,
        U: ?Sized + PartialOrd<Idx>,
    {
        <Self as RangeBounds<Idx>>::contains(self, item)
    }
}

// ብቸኛ<Idx>ከ <RangeTo<Idx>ምክንያቱም በ‹XXXXXX›የውሃ ፍሰት ፍሰት የሚቻል ይሆናል
//

/// የበርካታ ቁልፎች የመጨረሻ ነጥብ።
///
/// # Examples
///
/// የ Bound` ዎች የክልል የመጨረሻ ነጥቦች ናቸው
///
/// ```
/// use std::ops::Bound::*;
/// use std::ops::RangeBounds;
///
/// assert_eq!((..100).start_bound(), Unbounded);
/// assert_eq!((1..12).start_bound(), Included(&1));
/// assert_eq!((1..12).end_bound(), Excluded(&12));
/// ```
///
/// [`BTreeMap::range`] ወደ ክርክር እንደ Bound`s`አንድ tuple መጠቀም.
/// በአብዛኛዎቹ ሁኔታዎች በምትኩ የክልል አገባብ (`1..5`) ን መጠቀሙ የተሻለ መሆኑን ልብ ይበሉ ፡፡
///
/// ```
/// use std::collections::BTreeMap;
/// use std::ops::Bound::{Excluded, Included, Unbounded};
///
/// let mut map = BTreeMap::new();
/// map.insert(3, "a");
/// map.insert(5, "b");
/// map.insert(8, "c");
///
/// for (key, value) in map.range((Excluded(3), Included(8))) {
///     println!("{}: {}", key, value);
/// }
///
/// assert_eq!(Some((&3, &"a")), map.range((Unbounded, Included(5))).next());
/// ```
///
/// [`BTreeMap::range`]: ../../std/collections/btree_map/struct.BTreeMap.html#method.range
#[stable(feature = "collections_bound", since = "1.17.0")]
#[derive(Clone, Copy, Debug, Hash, PartialEq, Eq)]
pub enum Bound<T> {
    /// ሁሉንም የሚያካትት።
    #[stable(feature = "collections_bound", since = "1.17.0")]
    Included(#[stable(feature = "collections_bound", since = "1.17.0")] T),
    /// ብቸኛ ማሰሪያ።
    #[stable(feature = "collections_bound", since = "1.17.0")]
    Excluded(#[stable(feature = "collections_bound", since = "1.17.0")] T),
    /// ማለቂያ የሌለው የመጨረሻ ነጥብ።በዚህ አቅጣጫ ውስጥ ወሰን እንደሌለ ያመለክታል ፡፡
    #[stable(feature = "collections_bound", since = "1.17.0")]
    Unbounded,
}

#[unstable(feature = "bound_as_ref", issue = "80996")]
impl<T> Bound<T> {
    /// ከ `&Bound<T>` ወደ `Bound<&T>` ይቀይራል።
    #[inline]
    pub fn as_ref(&self) -> Bound<&T> {
        match *self {
            Included(ref x) => Included(x),
            Excluded(ref x) => Excluded(x),
            Unbounded => Unbounded,
        }
    }

    /// ከ `&mut Bound<T>` ወደ `Bound<&T>` ይቀይራል።
    #[inline]
    pub fn as_mut(&mut self) -> Bound<&mut T> {
        match *self {
            Included(ref mut x) => Included(x),
            Excluded(ref mut x) => Excluded(x),
            Unbounded => Unbounded,
        }
    }
}

impl<T: Clone> Bound<&T> {
    /// የታሰረውን ይዘት በማጣመር ከ `Bound<&T>` ወደ `Bound<T>` ይሳሉ ፡፡
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(bound_cloned)]
    /// use std::ops::Bound::*;
    /// use std::ops::RangeBounds;
    ///
    /// assert_eq!((1..12).start_bound(), Included(&1));
    /// assert_eq!((1..12).start_bound().cloned(), Included(1));
    /// ```
    #[unstable(feature = "bound_cloned", issue = "61356")]
    pub fn cloned(self) -> Bound<T> {
        match self {
            Bound::Unbounded => Bound::Unbounded,
            Bound::Included(x) => Bound::Included(x.clone()),
            Bound::Excluded(x) => Bound::Excluded(x.clone()),
        }
    }
}

/// `RangeBounds` እንደ `..` ፣ `a..` ፣ `..b` ፣ `..=c` ፣ `d..e` ወይም `f..=g` ባሉ የክልል አገባብ በተመረቱ የ Rust ውስጠ-ግንቡ የክልል ዓይነቶች ይተገበራል ፡፡
///
#[stable(feature = "collections_range", since = "1.28.0")]
pub trait RangeBounds<T: ?Sized> {
    /// መረጃ ጠቋሚ ተጀምሯል ፡፡
    ///
    /// የመነሻ ዋጋውን እንደ `Bound` ይመልሳል።
    ///
    /// # Examples
    ///
    /// ```
    /// # fn main() {
    /// use std::ops::Bound::*;
    /// use std::ops::RangeBounds;
    ///
    /// assert_eq!((..10).start_bound(), Unbounded);
    /// assert_eq!((3..10).start_bound(), Included(&3));
    /// # }
    /// ```
    #[stable(feature = "collections_range", since = "1.28.0")]
    fn start_bound(&self) -> Bound<&T>;

    /// የመረጃ ጠቋሚ መጨረሻ
    ///
    /// የመጨረሻውን እሴት እንደ `Bound` ይመልሳል።
    ///
    /// # Examples
    ///
    /// ```
    /// # fn main() {
    /// use std::ops::Bound::*;
    /// use std::ops::RangeBounds;
    ///
    /// assert_eq!((3..).end_bound(), Unbounded);
    /// assert_eq!((3..10).end_bound(), Excluded(&10));
    /// # }
    /// ```
    #[stable(feature = "collections_range", since = "1.28.0")]
    fn end_bound(&self) -> Bound<&T>;

    /// `item` በክልሉ ውስጥ ከያዘ `true` ን ይመልሳል።
    ///
    /// # Examples
    ///
    /// ```
    /// ((3..5).contains(&4));
    /// assert!(!(3..5).contains(&2));
    ///
    /// ((0.0..1.0).contains(&0.5));
    /// assert!(!(0.0..1.0).contains(&f32::NAN));
    /// assert!(!(0.0..f32::NAN).contains(&0.5));
    /// assert!(!(f32::NAN..1.0).contains(&0.5));
    #[stable(feature = "range_contains", since = "1.35.0")]
    fn contains<U>(&self, item: &U) -> bool
    where
        T: PartialOrd<U>,
        U: ?Sized + PartialOrd<T>,
    {
        (match self.start_bound() {
            Included(ref start) => *start <= item,
            Excluded(ref start) => *start < item,
            Unbounded => true,
        }) && (match self.end_bound() {
            Included(ref end) => item <= *end,
            Excluded(ref end) => item < *end,
            Unbounded => true,
        })
    }
}

use self::Bound::{Excluded, Included, Unbounded};

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T: ?Sized> RangeBounds<T> for RangeFull {
    fn start_bound(&self) -> Bound<&T> {
        Unbounded
    }
    fn end_bound(&self) -> Bound<&T> {
        Unbounded
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for RangeFrom<T> {
    fn start_bound(&self) -> Bound<&T> {
        Included(&self.start)
    }
    fn end_bound(&self) -> Bound<&T> {
        Unbounded
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for RangeTo<T> {
    fn start_bound(&self) -> Bound<&T> {
        Unbounded
    }
    fn end_bound(&self) -> Bound<&T> {
        Excluded(&self.end)
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for Range<T> {
    fn start_bound(&self) -> Bound<&T> {
        Included(&self.start)
    }
    fn end_bound(&self) -> Bound<&T> {
        Excluded(&self.end)
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for RangeInclusive<T> {
    fn start_bound(&self) -> Bound<&T> {
        Included(&self.start)
    }
    fn end_bound(&self) -> Bound<&T> {
        if self.exhausted {
            // ተደጋጋሚው ሲደክም ብዙውን ጊዜ ጅምር==መጨረሻ አለን ፣ ግን ክልሉ ምንም ሳይይዝ ባዶ ሆኖ እንዲታይ እንፈልጋለን።
            //
            Excluded(&self.end)
        } else {
            Included(&self.end)
        }
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for RangeToInclusive<T> {
    fn start_bound(&self) -> Bound<&T> {
        Unbounded
    }
    fn end_bound(&self) -> Bound<&T> {
        Included(&self.end)
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for (Bound<T>, Bound<T>) {
    fn start_bound(&self) -> Bound<&T> {
        match *self {
            (Included(ref start), _) => Included(start),
            (Excluded(ref start), _) => Excluded(start),
            (Unbounded, _) => Unbounded,
        }
    }

    fn end_bound(&self) -> Bound<&T> {
        match *self {
            (_, Included(ref end)) => Included(end),
            (_, Excluded(ref end)) => Excluded(end),
            (_, Unbounded) => Unbounded,
        }
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<'a, T: ?Sized + 'a> RangeBounds<T> for (Bound<&'a T>, Bound<&'a T>) {
    fn start_bound(&self) -> Bound<&T> {
        self.0
    }

    fn end_bound(&self) -> Bound<&T> {
        self.1
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for RangeFrom<&T> {
    fn start_bound(&self) -> Bound<&T> {
        Included(self.start)
    }
    fn end_bound(&self) -> Bound<&T> {
        Unbounded
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for RangeTo<&T> {
    fn start_bound(&self) -> Bound<&T> {
        Unbounded
    }
    fn end_bound(&self) -> Bound<&T> {
        Excluded(self.end)
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for Range<&T> {
    fn start_bound(&self) -> Bound<&T> {
        Included(self.start)
    }
    fn end_bound(&self) -> Bound<&T> {
        Excluded(self.end)
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for RangeInclusive<&T> {
    fn start_bound(&self) -> Bound<&T> {
        Included(self.start)
    }
    fn end_bound(&self) -> Bound<&T> {
        Included(self.end)
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for RangeToInclusive<&T> {
    fn start_bound(&self) -> Bound<&T> {
        Unbounded
    }
    fn end_bound(&self) -> Bound<&T> {
        Included(self.end)
    }
}