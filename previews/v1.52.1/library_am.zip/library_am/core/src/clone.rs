//! `Clone` trait‹በተዘዋዋሪ ሊገለበጡ›ለማይችሉ ዓይነቶች ፡፡
//!
//! Rust ውስጥ, አንዳንድ ቀላል ዓይነቶች "implicitly copyable" ናቸው; እናንተም ለነርሱ ለመመደብ ወይም የመከራከሪያ አድርጎ ማለፍ ጊዜ ተቀባዩ ስፍራ ውስጥ የመጀመሪያው እሴት ትቶ, አንድ ቅጂ ማግኘት ይሆናል.
//! እነዚህ ዓይነቶች አጠናቃሪ ለመቅዳት ርካሽ እና ደህንነት ከእነርሱ ይቆጥረዋል ስለዚህ: (እነርሱ ባለቤትነት ሳጥኖች መያዝ ወይም [`Drop`] ለመተግበር አይደለም, ማለትም) ለመቅዳት ምደባ አንጠይቅም እና finalizers የለንም.
//!
//! ሌሎች አይነቶች ቅጂዎች በ [`Clone`] trait ተግባራዊ እና [`clone`] ዘዴ በመደወል የአውራጃ ስብሰባ በማድረግ, በግልጽ መደረግ አለበት.
//!
//! [`clone`]: Clone::clone
//!
//! መሰረታዊ የአጠቃቀም ምሳሌ
//!
//! ```
//! let s = String::new(); // ገመድ ዓይነት ክሎንን ይተገበራል
//! let copy = s.clone(); // ስለዚህ እኛ ችግኖ እንችላለን
//! ```
//!
//! Clone trait ን በቀላሉ ለመተግበር እንዲሁም `#[derive(Clone)]` ን መጠቀም ይችላሉ።ለምሳሌ:
//!
//! ```
//! #[derive(Clone)] // Clone trait ን ወደ ሞርፊየስ ግንባታ እንጨምረዋለን
//! struct Morpheus {
//!    blue_pill: f32,
//!    red_pill: i64,
//! }
//!
//! fn main() {
//!    let f = Morpheus { blue_pill: 0.0, red_pill: 0 };
//!    let copy = f.clone(); // እና አሁን ልናጣምረው እንችላለን!
//! }
//! ```
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

/// አንድን ነገር በግልፅ ለማባዛት የሚያስችል የተለመደ trait
///
/// በዚያ [`Copy`] ውስጥ ከ [`Copy`] የተለዩ ግልጽ እና እጅግ ርካሽ ናቸው ፣ `Clone` ግን ሁል ጊዜ ግልፅ እና ውድ ሊሆንም ላይሆን ይችላል።
/// እነዚህ ባህርያት ለማስፈፀም እንዲቻል, Rust እናንተ [`Copy`] reimplement አይፈቅድም, ነገር ግን `Clone` reimplement እና የዘፈቀደ ኮድ ማስኬድ ይችላሉ.
///
/// `Clone` ከ [`Copy`] የበለጠ አጠቃላይ ስለሆነ በራስ-ሰር ማንኛውንም ነገር [`Copy`] `Clone` እንዲሆኑ ማድረግ ይችላሉ ፡፡
///
/// ## Derivable
///
/// ሁሉም መስኮች `Clone` ከሆነ ይህ trait `#[derive]` ጋር መጠቀም ይቻላል.የ‹XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX.
///
/// [`clone`]: Clone::clone
///
/// ለጠቅላላው መዋቅር ፣ `#[derive]` በአጠቃላይ ልኬቶች ላይ የታሰረ `Clone` ን በመጨመር `Clone` ን በሁኔታዎች ይተገበራል።
///
/// ```
/// // `derive` ለንባብ ክሎንን ይተገበራል<T>ቲ ብቸኛ ሲሆን ፡፡
/// #[derive(Clone)]
/// struct Reading<T> {
///     frequency: T,
/// }
/// ```
///
/// ## እንዴት ብዬ `Clone` መተግበር እንችላለን?
///
/// [`Copy`] የሆኑ ዓይነቶች የ `Clone` ጥቃቅን ትግበራ ሊኖራቸው ይገባል።በይፋ-
/// `T: Copy` ፣ `x: T` እና `y: &T` ከሆነ `let x = y.clone();` ከ `let x = *y;` ጋር እኩል ነው።
/// በእጅ ማስፈጸሚያዎች ይህን invariant መደገፍ በጥንቃቄ መሆን አለበት;ይሁን እንጂ, አደገኛ ኮድ ትውስታ ደህንነት ለማረጋገጥ በላዩ ላይ መተማመን የለበትም.
///
/// አንድ ምሳሌ አንድ ተግባር ጠቋሚ የያዘች ሁሉን አቀፍ struct ነው.በዚህ ሁኔታ ውስጥ, `Clone` ትግበራ `derive`d ሊሆን አይችልም, ሆኖም ግን እንደ ሊተገበሩ ይችላሉ:
///
/// ```
/// struct Generate<T>(fn() -> T);
///
/// impl<T> Copy for Generate<T> {}
///
/// impl<T> Clone for Generate<T> {
///     fn clone(&self) -> Self {
///         *self
///     }
/// }
/// ```
///
/// ## ተጨማሪ ፈፃሚዎች
///
/// ወደ [implementors listed below][impls] በተጨማሪ, የሚከተለው ዓይነቶች ደግሞ `Clone` ተግባራዊ:
///
/// * የተግባር ንጥል ዓይነቶች (ማለትም ፣ ለእያንዳንዱ ዓይነቶች የተገለጹት ልዩ ዓይነቶች)
/// * የተግባር ጠቋሚ ዓይነቶች (ለምሳሌ ፣ `fn() -> i32`)
/// * ድርድር አይነቶች, ሁሉም መጠኖች, ወደ ንጥል ዓይነት ደግሞ `Clone` የሚያስፈጽም ከሆነ (ለምሳሌ, `[i32; 123456]`)
/// * የቱፕል ዓይነቶች ፣ እያንዳንዱ አካል `Clone` ን ተግባራዊ የሚያደርግ ከሆነ (ለምሳሌ ፣ `()` ፣ `(i32, bool)`)
/// * መዘጋት አይነቶች, እነሱ አካባቢ ምንም ዋጋ ለመያዝ ከሆነ ወይም ሁሉንም እንደ የተያዙ እሴቶች `Clone` ራሳቸውን ተግባራዊ ከሆነ.
///   በጋራ ማጣቀሻ የተያዙ ተለዋዋጮች ሁል ጊዜ `Clone` ን ይተገብራሉ (ምንም እንኳን ጠቋሚው ባይሆንም) ፣ በሚለዋወጥ ማጣቀሻ የተያዙ ተለዋዋጮች ግን `Clone` ን በጭራሽ አይተገበሩም ፡፡
///
///
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "clone"]
#[rustc_diagnostic_item = "Clone"]
pub trait Clone: Sized {
    /// የእሴቱን ቅጅ ይመልሳል።
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(noop_method_call)]
    /// let hello = "Hello"; // &str መሳሪያዎች አባዛ
    ///
    /// assert_eq!("Hello", hello.clone());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "cloning is often expensive and is not expected to have side effects"]
    fn clone(&self) -> Self;

    /// ከ `source` የቅጅ-ምደባን ያከናውናል።
    ///
    /// `a.clone_from(&b)` በተግባራዊነት ከ `a = b.clone()` ጋር እኩል ነው ፣ ግን አላስፈላጊ ምደባዎችን ለማስወገድ የ `a` ሀብቶችን እንደገና ጥቅም ላይ ለማዋል ሊታለፍ ይችላል።
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn clone_from(&mut self, source: &Self) {
        *self = source.clone()
    }
}

/// የ trait `Clone` አንድ impl በማመንጨት ሊሆኗቸው ማክሮ.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Clone($item:item) {
    /* compiler built-in */
}

// FIXME(aburka): በእነዚህ structs#በማድረግ ብቻ ጥቅም ላይ ይውላሉ [ማግኘት] ስለመሆንዎ አንድ አይነት መሳሪያዎች አባዛ ወይም ቅዳ እያንዳንዱን ክፍል.
//
//
// እነዚህ ህጎች በተጠቃሚ ኮድ ውስጥ በጭራሽ መታየት የለባቸውም።
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsClone<T: Clone + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsCopy<T: Copy + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// ኋላቀር አይነቶች `Clone` ውስጥ ማስፈጸሚያዎች.
///
/// በ Rust ውስጥ ሊገለጹ የማይችሉ ትግበራዎች በ X0 `rustc_trait_selection` ውስጥ በ `traits::SelectionContext::copy_clone_conditions()` ውስጥ ይተገበራሉ።
///
///
mod impls {

    use super::Clone;

    macro_rules! impl_clone {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Clone for $t {
                    #[inline]
                    fn clone(&self) -> Self {
                        *self
                    }
                }
            )*
        }
    }

    impl_clone! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Clone for ! {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *const T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *mut T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// የተጋሩ ማጣቀሻ ተጋባን ማለት ሊሆን ይችላል, ነገር ግን ሊቀየሩ የሚችሉ ማጣቀሻዎችን *አይችሉም*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for &T {
        #[inline]
        #[rustc_diagnostic_item = "noop_method_clone"]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// የተጋሩ ማጣቀሻ ተጋባን ማለት ሊሆን ይችላል, ነገር ግን ሊቀየሩ የሚችሉ ማጣቀሻዎችን *አይችሉም*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> !Clone for &mut T {}
}