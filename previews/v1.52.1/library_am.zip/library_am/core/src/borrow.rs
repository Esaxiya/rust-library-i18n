//! ከተበዳሪ ውሂብ ጋር ለመስራት ሞዱል ፡፡

#![stable(feature = "rust1", since = "1.0.0")]

/// መረጃን ለመበደር trait
///
/// በ Rust ውስጥ ለተለያዩ የአጠቃቀም ጉዳዮች የአንድ ዓይነት የተለያዩ ውክልናዎችን መስጠት የተለመደ ነው ፡፡
/// ለምሳሌ ያህል, አንድ እሴት ማከማቻ ሥፍራ እና አስተዳደር በተለይ እንደ [`Box<T>`] ወይም [`Rc<T>`] እንደ ጠቋሚ አይነቶች በኩል የተወሰነ ጥቅም ተገቢ ሆኖ መመረጥ ይችላል.
/// ከማንኛውም ዓይነት ጋር ጥቅም ላይ ሊውሉ ከሚችሉት ከእነዚህ አጠቃላይ መጠቅለያዎች ባሻገር አንዳንድ ዓይነቶች ከፍተኛ ወጪ የሚጠይቁ ተግባራትን የሚሰጡ አማራጭ ገጽታዎችን ይሰጣሉ ፡፡
/// እንዲህ ዓይነት ምሳሌ መሠረታዊ [`str`] ወደ ሕብረቁምፊ ለማራዘም ችሎታ የሚያክላቸው [`String`] ነው.
/// ይህ ለቀላል የማይቀየር ገመድ ተጨማሪ መረጃ አላስፈላጊ ሆኖ እንዲቆይ ይጠይቃል።
///
/// እነዚህ ዓይነቶች ለዚያ ውሂብ ዓይነት በማጣቀሻዎች አማካይነት ለዋናው መረጃ መዳረሻ ይሰጣሉ ፡፡ያንን አይነት »እንደ በውሰት 'መሆን አለ ናቸው.
/// አንድ [`String`] `str` እንደ በውሰት ይችላል ሳለ ለምሳሌ ያህል, አንድ [`Box<T>`] `T` እንደ በውሰት ይቻላል.
///
/// ዓይነቶች እነርሱም, `Borrow<T>` ተግባራዊ በ trait ዎቹ [`borrow`] ዘዴ ውስጥ `T` ማጣቀሻ በማቅረብ አንዳንድ አይነት `T` እንደ በውሰት ሊሆን እንደሚችል ይገልጻሉ.አንድ ዓይነት እንደ ብዙ የተለያዩ ዓይነቶች ለመበደር ነፃ ነው።
/// ይህም mutably ዓይነት ሆኖ ለመበደር የሚወድ ቢኖር-ያለውን መሰረታዊ ውሂብ ሊቀየሩ በመፍቀድ, ይህም በተጨማሪ [`BorrowMut<T>`] ተግባራዊ ይችላሉ.
///
/// በተጨማሪም ፣ ለተጨማሪ traits አፈፃፀም በሚሰጥበት ጊዜ ፣ የዚያኛው ዓይነት ተወካይ ሆነው በመውሰዳቸው ምክንያት ከዋናው ዓይነት ጋር ተመሳሳይ መሆን እንዳለባቸው ግምት ውስጥ ማስገባት ያስፈልጋል ፡፡
/// አጠቃላይ ኮድ በእነዚህ ተጨማሪ የ trait አተገባበሮች ተመሳሳይ ባህሪ ላይ በሚመሰረትበት ጊዜ በተለምዶ `Borrow<T>` ን ይጠቀማል።
/// እነዚህ traits አይቀርም ተጨማሪ trait bounds ሆኖ ይታያል.
///
/// በተለይ `Eq` ውስጥ, `Ord` እና `Hash` በውሰት እና በባለቤትነት እሴቶች እኩል መሆን አለበት: `x.borrow() == y.borrow()` `x == y` ተመሳሳይ ውጤት መስጠት አለበት.
///
/// አጠቃላይ ኮድ ለተዛማጅ ዓይነት `T` ማጣቀሻ ሊያቀርብ ለሚችል ለሁሉም ዓይነቶች መሥራት ብቻ የሚያስፈልግ ከሆነ ብዙ ዓይነቶች በደህና ሊተገብሩት ስለሚችሉ [`AsRef<T>`] ን መጠቀሙ ብዙ ጊዜ የተሻለ ነው።
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
/// [`Mutex<T>`]: ../../std/sync/struct.Mutex.html
/// [`Rc<T>`]: ../../std/rc/struct.Rc.html
/// [`String`]: ../../std/string/struct.String.html
/// [`borrow`]: Borrow::borrow
///
/// # Examples
///
/// የውሂብ ስብስብ እንደመሆኑ መጠን, [`HashMap<K, V>`] ቁልፎች እና እሴቶች ሁለቱንም ባለቤት ነው.የቁልፉ ትክክለኛ መረጃ በአንድ ዓይነት ማስተዳደር ዓይነት ውስጥ ከተጠቀለለ የቁልፍ መረጃን ማጣቀሻ በመጠቀም ዋጋ መፈለግ አሁንም መቻል አለበት ፡፡
/// ቁልፉ ሕብረቁምፊ ነው ከሆነ አንድ [`&str`][`str`] በመጠቀም መፈለግ ይቻላል መሆን ይኖርበታል ሳለ ለምሳሌ ያህል, ከዚያም ይህ ሳይሆን አይቀርም, አንድ [`String`] እንደ ሃሽ ካርታ ጋር ይከማቻል.
/// ስለሆነም `insert` በ `String` ላይ መሥራት አለበት ፣ `get` ደግሞ `&str` ን መጠቀም መቻል አለበት ፡፡
///
/// በትንሹ የቀለለ ፣ የ `HashMap<K, V>` አግባብነት ያላቸው ክፍሎች ይህን ይመስላሉ
///
/// ```
/// use std::borrow::Borrow;
/// use std::hash::Hash;
///
/// pub struct HashMap<K, V> {
///     # marker: ::std::marker::PhantomData<(K, V)>,
///     // መስኮች ተወተዋል
/// }
///
/// impl<K, V> HashMap<K, V> {
///     pub fn insert(&self, key: K, value: V) -> Option<V>
///     where K: Hash + Eq
///     {
///         # unimplemented!()
///         // ...
///     }
///
///     pub fn get<Q>(&self, k: &Q) -> Option<&V>
///     where
///         K: Borrow<Q>,
///         Q: Hash + Eq + ?Sized
///     {
///         # unimplemented!()
///         // ...
///     }
/// }
/// ```
///
/// መላው ሃሽ ካርታ በቁልፍ ዓይነት `K` ላይ አጠቃላይ ነው።እነዚህ ቁልፎች ከሃሽ ካርታ ጋር ስለሚከማቹ ይህ አይነት የቁልፍ መረጃው የራሱ መሆን አለበት ፡፡
/// ቁልፍ-እሴት ጥንድ በማስገባት ጊዜ, ካርታው ትክክለኛውን ሃሽ ባልዲ ማግኘት እና ቁልፉ በዚያ `K` ላይ ተመስርቶ አስቀድሞ በአሁኑ ከሆነ ማረጋገጥ እንዲህ `K` እና ፍላጎት የተሰጠ ነው.ስለዚህ `K: Hash + Eq` ይፈልጋል።
///
/// በካርታው ውስጥ እሴት በሚፈልጉበት ጊዜ ግን ለመፈለግ ቁልፉ ሁልጊዜ እንደዚህ ያለ የባለቤትነት እሴት መፍጠርን ስለሚፈልግ ለ `K` ማጣቀሻ ማቅረብ ያስፈልጋል።
/// ለህብረቁምፊ ቁልፎች ይህ ማለት X0 `str` ብቻ የሚገኝባቸው ጉዳዮችን ለመፈለግ ብቻ የ `String` እሴት መፍጠር ያስፈልጋል ማለት ነው።
///
/// ከዚህ ይልቅ `get` ዘዴ ከላይ ያለውን ዘዴ ፊርማ ውስጥ `Q` ተብሎ ከስር ቁልፍ የውሂብ አይነት: ላይ አጠቃላይ ነው.ይህ `K` በዚያ `K: Borrow<Q>` እንዲጠይቅ በማድረግ `Q` እንደ ይበደራል ይናገራል.
/// በተጨማሪም `Q: Hash + Eq` እንዲጠይቅ በማድረግ, ይህ `K` እና `Q` ተመሳሳይ ውጤት መሆኑን `Hash` እና `Eq` traits መካከል ማስፈጸሚያዎች እንዳላቸው መስፈርት ምልክት ይሰጠዋል.
///
/// የ `get` ትግበራ በተለይም ከ `K` እሴት ጋር በተቆጠረው የሃሽ እሴት ላይ በመመርኮዝ ቁልፉን ያስገባ ቢሆንም የቁልፍን ሃሽ ባልዲ በ `Q` እሴት በመደወል የቁልፍ ሃሽ ባልዲውን በመለየት በተለይም በ `Hash` ተመሳሳይ አተገባበር ላይ የተመሠረተ ነው ፡፡
///
///
/// በዚህም እንደ ሃሽ ካርታ እረፍት አንድ `Q` እሴት ላይ ይጠቀልላል አንድ `K` `Q` ይልቅ የተለየ ሃሽ የሚያፈራ ከሆነ.ለምሳሌ ያህል, አንድ ሕብረቁምፊ ይጠቀለላል ግን ጉዳያቸው ችላ ASCII ፊደላት ጋር ያመሳስለዋል አንድ አይነት አለህ እንበል:
///
/// ```
/// pub struct CaseInsensitiveString(String);
///
/// impl PartialEq for CaseInsensitiveString {
///     fn eq(&self, other: &Self) -> bool {
///         self.0.eq_ignore_ascii_case(&other.0)
///     }
/// }
///
/// impl Eq for CaseInsensitiveString { }
/// ```
///
/// ሁለት እኩል እሴቶች አንድ ተመሳሳይ የሃሽ እሴት ማምረት ስለሚያስፈልጋቸው ፣ የ `Hash` ትግበራ የ ASCII ጉዳይን እንዲሁ ችላ ማለት ያስፈልጋል ፡፡
///
/// ```
/// # use std::hash::{Hash, Hasher};
/// # pub struct CaseInsensitiveString(String);
/// impl Hash for CaseInsensitiveString {
///     fn hash<H: Hasher>(&self, state: &mut H) {
///         for c in self.0.as_bytes() {
///             c.to_ascii_lowercase().hash(state)
///         }
///     }
/// }
/// ```
///
/// `CaseInsensitiveString` `Borrow<str>` ን መተግበር ይችላል?በያዘው በባለቤትነት ባለው ገመድ በኩል ስለ ሕብረቁምፊ ቁርጥራጭ ማጣቀሻ በእርግጠኝነት ሊያቀርብ ይችላል።
/// ግን የ‹`Hash`›አተገባበሩ ስለሚለያይ ከ‹`str`›የተለየ ባህሪ አለው ስለሆነም በእውነቱ `Borrow<str>` ን መተግበር የለበትም ፡፡
/// ሌሎች መሠረታዊ የሆነውን `str` እንዲደርሱ መፍቀድ ከፈለገ ያንን ማንኛውንም ተጨማሪ መስፈርቶችን በማይሸከም በ `AsRef<str>` በኩል ማድረግ ይችላል።
///
/// [`Hash`]: crate::hash::Hash
/// [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
/// [`String`]: ../../std/string/struct.String.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Borrow"]
pub trait Borrow<Borrowed: ?Sized> {
    /// ላይለዋወጥ አንድ በባለቤትነት ዋጋ ከ ይበደራል.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::borrow::Borrow;
    ///
    /// fn check<T: Borrow<str>>(s: T) {
    ///     assert_eq!("Hello", s.borrow());
    /// }
    ///
    /// let s = "Hello".to_string();
    ///
    /// check(s);
    ///
    /// let s = "Hello";
    ///
    /// check(s);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn borrow(&self) -> &Borrowed;
}

/// መረጃን በብቃት ለመበደር trait
///
/// ለ‹XXXXXXXXXXXXXXXXXXXXXXXX ጓደኛ/ጓደኛ ጋር በመሆን አንድ ተለዋዋጭ ባህሪን በማጣቀሻነት እንደ አንድ መሰረታዊ አይነት እንዲበደር ይፈቅድለታል ፡፡
/// እንደ ሌላ ዓይነት ስለ ብድር ተጨማሪ መረጃ ለማግኘት [`Borrow<T>`] ን ይመልከቱ ፡፡
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait BorrowMut<Borrowed: ?Sized>: Borrow<Borrowed> {
    /// Mutably አንድ በባለቤትነት ዋጋ ከ ይበደራል.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::borrow::BorrowMut;
    ///
    /// fn check<T: BorrowMut<[i32]>>(mut v: T) {
    ///     assert_eq!(&mut [1, 2, 3], v.borrow_mut());
    /// }
    ///
    /// let v = vec![1, 2, 3];
    ///
    /// check(v);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn borrow_mut(&mut self) -> &mut Borrowed;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for T {
    #[rustc_diagnostic_item = "noop_method_borrow"]
    fn borrow(&self) -> &T {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> BorrowMut<T> for T {
    fn borrow_mut(&mut self) -> &mut T {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for &T {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for &mut T {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> BorrowMut<T> for &mut T {
    fn borrow_mut(&mut self) -> &mut T {
        &mut **self
    }
}