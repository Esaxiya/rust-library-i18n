//! ከባይት ቁራጭ `str` ን ለመፍጠር መንገዶች።

use crate::mem;

use super::validations::run_utf8_validation;
use super::Utf8Error;

/// አንድ ባይት አንድ ቁራጭ ወደ ሕብረቁምፊ ቁራጭ ይቀይረዋል።
///
/// የሕብረቁምፊ ቁራጭ ([`&str`]) የተሠራው በባይቶች ([`u8`]) ነው ፣ እና ባይት ቁራጭ ([`&[u8]`][byteslice]) ከ ባይት የተሠራ ነው ፣ ስለሆነም ይህ ተግባር በሁለቱ መካከል ይለወጣል።
/// ሁሉም የባይት ቁርጥራጮች ትክክለኛ የሕብረቁምፊ ቁርጥራጮች አይደሉም ፣ ሆኖም ግን [`&str`] ትክክለኛ UTF-8 መሆኑን ይጠይቃል።
/// `from_utf8()` ባይት ትክክለኛ UTF-8 መሆኑን ለማረጋገጥ ይፈትሻል ፣ ከዚያ መለወጥ ይጀምራል።
///
/// [`&str`]: str
/// [byteslice]: slice
///
/// የባይት ቁራጭ ትክክለኛ UTF-8 መሆኑን እርግጠኛ ከሆኑ እና የትክክለኝነት ፍተሻውን የላይኛው ክፍል ማስነሳት የማይፈልጉ ከሆነ ፣ ተመሳሳይ ባህሪ ያለው ግን ቼኩን የሚዘለል የዚህ ተግባር ደህንነቱ ያልተጠበቀ ስሪት አለ [`from_utf8_unchecked`]።
///
///
/// ከ `&str` ይልቅ `String` የሚፈልጉ ከሆነ [`String::from_utf8`][string] ን ያስቡ ፡፡
///
/// [string]: ../../std/string/struct.String.html#method.from_utf8
///
/// ምክንያቱም `[u8; N]` ን መደርደር ይችላሉ ፣ እና [`&[u8]`][byteslice] ን መውሰድ ይችላሉ ፣ ይህ ተግባር በተደራራቢ የተመደበ ገመድ እንዲኖርዎት አንዱ መንገድ ነው።ከዚህ በታች በምሳሌዎች ክፍል ውስጥ የዚህ ምሳሌ አለ ፡፡
///
/// [byteslice]: slice
///
/// # Errors
///
/// የተሰጠው ቁራጭ UTF-8 ያልሆነ ለምን እንደሆነ በመግለጫው ቁራጭ UTF-8 ካልሆነ `Err` ን ይመልሳል።
///
/// # Examples
///
/// መሠረታዊ አጠቃቀም
///
/// ```
/// use std::str;
///
/// // አንድ vector ውስጥ አንዳንድ ባይቶች,
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // እነዚህ ባይት ትክክለኛ መሆናቸውን እናውቃለን ፣ ስለሆነም `unwrap()` ን ይጠቀሙ።
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// የተሳሳተ ባይቶች
///
/// ```
/// use std::str;
///
/// // አንዳንድ ልክ ያልሆኑ ባይቶች ፣ በ vector ውስጥ
/// let sparkle_heart = vec![0, 159, 146, 150];
///
/// assert!(str::from_utf8(&sparkle_heart).is_err());
/// ```
///
/// ሊመለሱ ስለሚችሉ የስህተት ዓይነቶች ተጨማሪ ዝርዝሮችን ለማግኘት ለ [`Utf8Error`] ሰነዶችን ይመልከቱ ፡፡
///
/// ኤ "stack allocated string"
///
/// ```
/// use std::str;
///
/// // በተከታታይ በተመደበ ድርድር ውስጥ አንዳንድ ባይቶች
/// let sparkle_heart = [240, 159, 146, 150];
///
/// // እነዚህ ባይት ትክክለኛ መሆናቸውን እናውቃለን ፣ ስለሆነም `unwrap()` ን ይጠቀሙ።
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_utf8(v: &[u8]) -> Result<&str, Utf8Error> {
    run_utf8_validation(v)?;
    // ደህንነት: ልክ ማረጋገጫ አሂድ.
    Ok(unsafe { from_utf8_unchecked(v) })
}

/// ሊለዋወጥ የሚችል የባይት ቁርጥራጭ ወደ ሚቀየር የሕብረቁምፊ ቁራጭ ይለውጣል።
///
/// # Examples
///
/// መሠረታዊ አጠቃቀም
///
/// ```
/// use std::str;
///
/// // "Hello, Rust!" እንደ ተለዋጭ vector
/// let mut hellorust = vec![72, 101, 108, 108, 111, 44, 32, 82, 117, 115, 116, 33];
///
/// // እነዚህ ባይት ትክክለኛ መሆናቸውን ስለምናውቅ `unwrap()` ን መጠቀም እንችላለን
/// let outstr = str::from_utf8_mut(&mut hellorust).unwrap();
///
/// assert_eq!("Hello, Rust!", outstr);
/// ```
///
/// የተሳሳተ ባይቶች
///
/// ```
/// use std::str;
///
/// // በሚለዋወጥ vector ውስጥ አንዳንድ ልክ ያልሆኑ ባይት
/// let mut invalid = vec![128, 223];
///
/// assert!(str::from_utf8_mut(&mut invalid).is_err());
/// ```
/// ሊመለሱ ስለሚችሉ የስህተት ዓይነቶች ተጨማሪ ዝርዝሮችን ለማግኘት ለ [`Utf8Error`] ሰነዶችን ይመልከቱ ፡፡
///
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub fn from_utf8_mut(v: &mut [u8]) -> Result<&mut str, Utf8Error> {
    run_utf8_validation(v)?;
    // ደህንነት: ልክ ማረጋገጫ አሂድ.
    Ok(unsafe { from_utf8_unchecked_mut(v) })
}

/// አንድ የ‹ባይት›ቁርጥራጭ ወደ‹XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX/XXX//መያዙን ሳይፈተሽ ወደ አንድ ክር ቁራጭ ይለውጣል ፡፡
///
/// ለበለጠ መረጃ ደህንነቱ የተጠበቀ ስሪቱን [`from_utf8`] ይመልከቱ።
///
/// # Safety
///
/// ወደ እሱ የተላለፉት ባይት ትክክለኛ UTF-8 መሆናቸውን ስለማያረጋግጥ ይህ ተግባር ደህንነቱ የተጠበቀ አይደለም።
/// የተቀረው Rust [`&str`] ልክ UTF-8 ናቸው` ብሎ ስለሚያስብ ይህ ገደብ ከተጣሰ ያልተገለጸ የባህሪ ውጤት ያስከትላል።
///
///
/// [`&str`]: str
///
/// # Examples
///
/// መሠረታዊ አጠቃቀም
///
/// ```
/// use std::str;
///
/// // አንድ vector ውስጥ አንዳንድ ባይቶች,
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// let sparkle_heart = unsafe {
///     str::from_utf8_unchecked(&sparkle_heart)
/// };
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_str_from_utf8_unchecked", issue = "75196")]
#[rustc_allow_const_fn_unstable(const_fn_transmute)]
pub const unsafe fn from_utf8_unchecked(v: &[u8]) -> &str {
    // ደህንነት-ደዋዩ ባይት `v` ትክክለኛ UTF-8 መሆኑን ማረጋገጥ አለበት ፡፡
    // እንዲሁም ተመሳሳይ አቀማመጥ ባላቸው `&str` እና `&[u8]` ላይም ይተማመናል።
    unsafe { mem::transmute(v) }
}

/// አንድ የባይዝ ቁራጭ ሕብረቁምፊ ትክክለኛ UTF-8 ን መያዙን ሳያረጋግጥ ወደ ሕብረቁምፊ ቁራጭ ይለውጣል ፤የሚለዋወጥ ስሪት.
///
///
/// ለበለጠ መረጃ የማይለዋወጥ ሥሪት ፣ [`from_utf8_unchecked()`] ይመልከቱ።
///
/// # Examples
///
/// መሠረታዊ አጠቃቀም
///
/// ```
/// use std::str;
///
/// let mut heart = vec![240, 159, 146, 150];
/// let heart = unsafe { str::from_utf8_unchecked_mut(&mut heart) };
///
/// assert_eq!("💖", heart);
/// ```
#[inline]
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub unsafe fn from_utf8_unchecked_mut(v: &mut [u8]) -> &mut str {
    // ደህንነት-ደዋዩ ለባይት `v` ዋስትና መስጠት አለበት
    // ትክክለኛ UTF-8 ናቸው ፣ ስለሆነም ወደ `*mut str` የሚደረገው ተዋንያን ደህና ናቸው።
    // እንዲሁም የጠቋሚው መዛግብት ደህንነቱ የተጠበቀ ነው ምክንያቱም ያ ጠቋሚ የመጣው ለጽሑፍ ትክክለኛ ሆኖ ከተረጋገጠ ማጣቀሻ ነው ፡፡
    //
    unsafe { &mut *(v as *mut [u8] as *mut str) }
}