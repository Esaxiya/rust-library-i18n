//! ሕብረቁምፊ ንድፍ ኤ.ፒ.አይ.
//!
//! ስርዓተ ጥለት ኤ.ፒ.አይ. በሕብረቁምፊ ውስጥ ሲፈተሹ የተለያዩ የንድፍ አይነቶችን ለመጠቀም አጠቃላይ ዘዴን ይሰጣል ፡፡
//!
//! ለተጨማሪ ዝርዝሮች traits [`Pattern`] ፣ [`Searcher`] ፣ [`ReverseSearcher`] እና [`DoubleEndedSearcher`] ን ይመልከቱ ፡፡
//!
//! ምንም እንኳን ይህ ኤ.ፒ.አይ ያልተረጋጋ ቢሆንም በ [`str`] ዓይነት ላይ በተረጋጋ ኤፒአይዎች በኩል ተጋላጭ ነው ፡፡
//!
//! # Examples
//!
//! [`Pattern`] በተረጋጋ ኤፒአይ ውስጥ [`&str`][`str`] ፣ [`char`] ፣ የ [`char`] ቁርጥራጭ እና `FnMut(char) -> bool` ን የሚተገብሩ ተግባራት እና ዝግጅቶች [implemented][pattern-impls] ነው ፡፡
//!
//!
//! ```
//! let s = "Can you find a needle in a haystack?";
//!
//! // &str pattern
//! assert_eq!(s.find("you"), Some(4));
//! // የቻር ንድፍ
//! assert_eq!(s.find('n'), Some(2));
//! // የቁራጭ ቁርጥራጭ ንድፍ
//! assert_eq!(s.find(&['a', 'e', 'i', 'o', 'u'][..]), Some(1));
//! // የመዘጋት ንድፍ
//! assert_eq!(s.find(|c: char| c.is_ascii_punctuation()), Some(35));
//! ```
//!
//! [pattern-impls]: Pattern#implementors
//!
//!
//!
//!

#![unstable(
    feature = "pattern",
    reason = "API not fully fleshed out and ready to be stabilized",
    issue = "27721"
)]

use crate::cmp;
use crate::fmt;
use crate::slice::memchr;

// Pattern

/// የሕብረቁምፊ ንድፍ.
///
/// `Pattern<'a>` የሚተገበረው ዓይነት በ [`&'a str`][str] ውስጥ ለመፈለግ እንደ ሕብረቁምፊ ንድፍ ሆኖ ሊያገለግል እንደሚችል ይገልጻል።
///
/// ለምሳሌ ያህል, `'a'` እና `"aa"` ሁለቱም ሕብረቁምፊ `"baaaab"` ውስጥ ጠቋሚ `1` ላይ መዛመድ ነበር ዘንድ ቅጦች ናቸው.
///
/// trait እራሱ ለተዛማጅ የ [`Searcher`] ዓይነት እንደ ገንቢ ሆኖ ይሠራል ፣ ይህም በሕብረቁምፊ ውስጥ የንድፍ ምስሎችን መከሰት ትክክለኛውን ሥራ ይሠራል።
///
///
/// እንደ ስርዓተ-ጥለት ዓይነት ፣ እንደ [`str::find`] እና [`str::contains`] ያሉ ዘዴዎች ባህሪ ሊለወጥ ይችላል።
/// ከዚህ በታች ያለው ሰንጠረዥ አንዳንድ ባህሪዎችን ይገልጻል።
///
/// | Pattern type             | Match condition                           |
/// |--------------------------|-------------------------------------------|
/// | `&str`                   | is substring                              |
/// | `char`                   | is contained in string                    |
/// | `&[char]`                | any char in slice is contained in string  |
/// | `F: FnMut(char) -> bool` | `F` returns `true` for a char in string   |
/// | `&&str`                  | is substring                              |
/// | `&String`                | is substring                              |
///
/// # Examples
///
/// ```
/// // &str
/// assert_eq!("abaaa".find("ba"), Some(1));
/// assert_eq!("abaaa".find("bac"), None);
///
/// // char
/// assert_eq!("abaaa".find('a'), Some(0));
/// assert_eq!("abaaa".find('b'), Some(1));
/// assert_eq!("abaaa".find('c'), None);
///
/// // &[char]
/// assert_eq!("ab".find(&['b', 'a'][..]), Some(0));
/// assert_eq!("abaaa".find(&['a', 'z'][..]), Some(0));
/// assert_eq!("abaaa".find(&['c', 'd'][..]), None);
///
/// // FnMut(char) -> bool
/// assert_eq!("abcdef_z".find(|ch| ch > 'd' && ch < 'y'), Some(4));
/// assert_eq!("abcddd_z".find(|ch| ch > 'd' && ch < 'y'), None);
/// ```
///
///
///
///
pub trait Pattern<'a>: Sized {
    /// ለዚህ ንድፍ ተጓዳኝ ፈላጊ
    type Searcher: Searcher<'a>;

    /// ለመፈለግ ከ `self` እና ከ `haystack` ጋር ተዛማጅ ፍለጋውን ይገነባል።
    ///
    fn into_searcher(self, haystack: &'a str) -> Self::Searcher;

    /// ንድፉ በአሸዋው ውስጥ ከየትኛውም ቦታ ጋር ይጣጣም እንደሆነ ይፈትሻል
    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        self.into_searcher(haystack).next_match().is_some()
    }

    /// ንድፉ በሣር ክዳን ፊት ለፊት የሚዛመድ መሆኑን ይፈትሻል
    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        matches!(self.into_searcher(haystack).next(), SearchStep::Match(0, _))
    }

    /// ንድፉ በሣር ክዳን ጀርባ ላይ የሚዛመድ መሆኑን ይፈትሻል
    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        matches!(self.into_searcher(haystack).next_back(), SearchStep::Match(_, j) if haystack.len() == j)
    }

    /// ንድፉን ከሣር ክምር ፊት ላይ ያስወግዳል ፣ የሚዛመድ ከሆነ።
    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        if let SearchStep::Match(start, len) = self.into_searcher(haystack).next() {
            debug_assert_eq!(
                start, 0,
                "The first search step from Searcher \
                 must include the first character"
            );
            // ደህንነት `Searcher` ትክክለኛ መረጃ ጠቋሚዎችን በመመለስ ይታወቃል ፡፡
            unsafe { Some(haystack.get_unchecked(len..)) }
        } else {
            None
        }
    }

    /// ንድፉን ከሣር ክዳን በስተጀርባ ያስወግዳል ፣ ከተመሳሰለ።
    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        if let SearchStep::Match(start, end) = self.into_searcher(haystack).next_back() {
            debug_assert_eq!(
                end,
                haystack.len(),
                "The first search step from ReverseSearcher \
                 must include the last character"
            );
            // ደህንነት `Searcher` ትክክለኛ መረጃ ጠቋሚዎችን በመመለስ ይታወቃል ፡፡
            unsafe { Some(haystack.get_unchecked(..start)) }
        } else {
            None
        }
    }
}

// Searcher

/// [`Searcher::next()`] ወይም [`ReverseSearcher::next_back()`] የመደወል ውጤት።
#[derive(Copy, Clone, Eq, PartialEq, Debug)]
pub enum SearchStep {
    /// የስርዓተ-ጥለት ግጥሚያ በ `haystack[a..b]` እንደተገኘ ይገልጻል።
    ///
    Match(usize, usize),
    /// የ‹XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXD
    ///
    /// በሁለት `Match`es` መካከል ከአንድ በላይ `Reject` ሊኖር እንደሚችል ልብ ይበሉ ፣ ወደ አንድ እንዲደመሩ ምንም መስፈርት የለም ፡፡
    ///
    ///
    Reject(usize, usize),
    /// እያንዳንዱ የባር ባች ባይት እንደተጎበኘ ይገልጻል ፣ ይህም ተደጋጋሚነቱን ያበቃል።
    ///
    Done,
}

/// የሕብረቁምፊ ንድፍ ፈላጊ።
///
/// ይህ trait ከ‹XXXXXXXXXXXXXXXX›ጀምሮ ንድፍ የማይዛመዱ ተዛማጆችን ለመፈለግ ዘዴዎችን ይሰጣል ፡፡
///
/// ይህ [`Pattern`] trait መካከል የተያያዙ `Searcher` አይነቶች አማካኝነት ተግባራዊ ይሆናል.
///
/// በ [`next()`][Searcher::next] ዘዴዎች የተመለሱት ኢንዴክሶች በሣር ክዳን ውስጥ ባሉ ትክክለኛ የ utf8 ድንበሮች ላይ መዋሸት ስለሚያስፈልጋቸው‹trait›ደህንነቱ የተጠበቀ ነው ፡፡
/// ይህ የዚህ trait ሸማቾች ያለ ተጨማሪ የአጭር ጊዜ ፍተሻዎች የሣር ክምር እንዲቆርጡ ያስችላቸዋል።
///
///
///
///
pub unsafe trait Searcher<'a> {
    /// Getter እንዲፈለግ ለታችኛው ገመድ
    ///
    /// ተመሳሳዩን [`&str`][str] ሁልጊዜ ይመልሳል።
    fn haystack(&self) -> &'a str;

    /// ከፊት ጀምሮ የሚቀጥለውን የፍለጋ እርምጃ ያከናውናል።
    ///
    /// - `haystack[a..b]` ከስርዓተ-ጥለት ጋር የሚዛመድ ከሆነ [`Match(a, b)`][SearchStep::Match] ን ይመልሳል።
    /// - `haystack[a..b]` በከፊል እንኳን ከቅርጸቱ ጋር መዛመድ ካልቻለ [`Reject(a, b)`][SearchStep::Reject] ን ይመልሳል።
    /// - እያንዳንዱ የሣር ክምችት ባይት ከተጎበኘ [`Done`][SearchStep::Done] ን ይመልሳል።
    ///
    /// የ [`Match`][SearchStep::Match] እና [`Reject`][SearchStep::Reject] ዥረት እስከ አንድ [`Done`][SearchStep::Done] እሴቶች ድረስ በአጎራባች ፣ ተደራራቢ ያልሆኑ ፣ ሙሉውን እሽግ የሚሸፍን እና በ utf8 ወሰኖች ላይ የሚጣሉ የመረጃ ጠቋሚ ክልሎችን ይይዛል ፡፡
    ///
    ///
    /// የ [`Match`][SearchStep::Match] ውጤት ሙሉውን የተጣጣመ ንድፍ መያዝ አለበት ፣ ሆኖም የ [`Reject`][SearchStep::Reject] ውጤቶች በዘፈቀደ ወደ ብዙ ተጎራባች ቁርጥራጮች ሊከፋፈሉ ይችላሉ ፡፡ሁለቱም ክልሎች ዜሮ ርዝመት ሊኖራቸው ይችላል ፡፡
    ///
    /// እንደ ምሳሌ ፣ `"aaa"` እና የሣር ክምር `"cbaaaaab"` ንድፍ ዥረቱን ሊያመርቱ ይችላሉ
    /// `[Reject(0, 1), Reject(1, 2), Match(2, 5), Reject(5, 8)]`
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn next(&mut self) -> SearchStep;

    /// የሚቀጥለውን የ [`Match`][SearchStep::Match] ውጤት ያገኛል።[`next()`][Searcher::next] ን ይመልከቱ።
    ///
    /// ከኤክስኤክስኤክስክስክስክስክስክስክስክስክስክስክስክስክስክስ ([`next()`][Searcher::next]) በተለየ መልኩ የዚህ እና የ [`next_reject`][Searcher::next_reject] የተመለሱት ክልሎች መደራረባቸው ምንም ዋስትና የለም ፡፡
    /// ይህ `(start_match, end_match)` ን ይመልሳል ፣ የት ጅምር_ምጥጫው ግጥሚያው የሚጀመርበት ጠቋሚ ነው ፣ እና የ‹መጨረሻ_ማች›ደግሞ ከጨዋታው መጨረሻ በኋላ መረጃ ጠቋሚ ነው ፡፡
    ///
    ///
    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next() {
                SearchStep::Match(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }

    /// የሚቀጥለውን የ [`Reject`][SearchStep::Reject] ውጤት ያገኛል።[`next()`][Searcher::next] እና [`next_match()`][Searcher::next_match] ን ይመልከቱ።
    ///
    /// ከኤክስኤክስኤክስክስክስክስክስክስክስክስክስክስክስክስክስክስ ([`next()`][Searcher::next]) በተለየ መልኩ የዚህ እና የ [`next_match`][Searcher::next_match] የተመለሱት ክልሎች መደራረባቸው ምንም ዋስትና የለም ፡፡
    ///
    ///
    #[inline]
    fn next_reject(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next() {
                SearchStep::Reject(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }
}

/// ለህብረቁምፊ ንድፍ የተገላቢጦሽ ፈላጊ።
///
/// ይህ trait ከ‹XXXXXXXXXXXXXXXXXX›ጀምሮ ጥለት ተደራራቢ ያልሆኑ ተዛማጆችን ለመፈለግ ዘዴዎችን ይሰጣል ፡፡
///
/// ንድፍ ከጀርባ መፈለግን የሚደግፍ ከሆነ በተዛመዱ የ [`Pattern`] trait የ [`Searcher`] አይነቶች ይተገበራል።
///
///
/// በዚህ trait የተመለሱት የመረጃ ጠቋሚ ክልሎች በተቃራኒው ከሚቀጥለው ፍለጋ ጋር በትክክል እንዲዛመዱ አይጠየቁም።
///
/// ይህ trait ደህንነቱ ያልተጠበቀ ምልክት ለተደረገበት ምክንያት ወላጅ trait [`Searcher`] ን ይመልከቱ።
///
///
///
///
pub unsafe trait ReverseSearcher<'a>: Searcher<'a> {
    /// እንደሚሰራ ከኋላ ጀምሮ ለሚቀጥሉት የፍለጋ ደረጃ.
    ///
    /// - `haystack[a..b]` ከስርዓተ-ጥለት ጋር የሚዛመድ ከሆነ [`Match(a, b)`][SearchStep::Match] ን ይመልሳል።
    /// - `haystack[a..b]` በከፊል እንኳን ከቅርጸቱ ጋር መዛመድ ካልቻለ [`Reject(a, b)`][SearchStep::Reject] ን ይመልሳል።
    /// - እያንዳንዱ የሣር ክምችት ባይት ከተጎበኘ [`Done`][SearchStep::Done] ን ይመልሳል
    ///
    /// የ [`Match`][SearchStep::Match] እና [`Reject`][SearchStep::Reject] ዥረት እስከ አንድ [`Done`][SearchStep::Done] እሴቶች ድረስ በአጎራባች ፣ ተደራራቢ ያልሆኑ ፣ ሙሉውን እሽግ የሚሸፍን እና በ utf8 ወሰኖች ላይ የሚጣሉ የመረጃ ጠቋሚ ክልሎችን ይይዛል ፡፡
    ///
    ///
    /// የ [`Match`][SearchStep::Match] ውጤት ሙሉውን የተጣጣመ ንድፍ መያዝ አለበት ፣ ሆኖም የ [`Reject`][SearchStep::Reject] ውጤቶች በዘፈቀደ ወደ ብዙ ተጎራባች ቁርጥራጮች ሊከፋፈሉ ይችላሉ ፡፡ሁለቱም ክልሎች ዜሮ ርዝመት ሊኖራቸው ይችላል ፡፡
    ///
    /// እንደ ምሳሌ ፣ `"aaa"` ንድፍ እና የሣር ክምር `"cbaaaaab"` ጅረት `[Reject(7, 8) ፣ Match(4, 7) ፣ Reject(1, 4) ፣ Reject(0, 1)]`.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn next_back(&mut self) -> SearchStep;

    /// የሚቀጥለውን የ [`Match`][SearchStep::Match] ውጤት ያገኛል።
    /// [`next_back()`][ReverseSearcher::next_back] ን ይመልከቱ።
    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next_back() {
                SearchStep::Match(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }

    /// የሚቀጥለውን የ [`Reject`][SearchStep::Reject] ውጤት ያገኛል።
    /// [`next_back()`][ReverseSearcher::next_back] ን ይመልከቱ።
    #[inline]
    fn next_reject_back(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next_back() {
                SearchStep::Reject(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }
}

/// [`ReverseSearcher`] ለ [`DoubleEndedIterator`] ትግበራ ሊያገለግል እንደሚችል ለመግለጽ ጠቋሚ trait።
///
/// ለዚህም የ [`Searcher`] እና [`ReverseSearcher`] ግኝት እነዚህን ሁኔታዎች መከተል ያስፈልጋል
///
/// - ሁሉም የ `next()` ውጤቶች በተቃራኒው ቅደም ተከተል ከ `next_back()` ውጤቶች ጋር ተመሳሳይ መሆን አለባቸው።
/// - `next()` እና `next_back()` አስፈላጊ እሴቶች የአንድ ክልል ሁለት ጫፎች አድርገው እንዲያስቡ, በዚያ እነርሱ "walk past each other" አይችልም ነው.
///
/// # Examples
///
/// `char::Searcher` አንድ [`char`] በመፈለግ ብቻ በሁለቱም ጫፎች ከ ተመሳሳይ የሚሰራበት የሆነ ጊዜ ላይ አንድ ሲመለከቱ ይጠይቃል ምክንያቱም `DoubleEndedSearcher` ነው.
///
/// `(&str)::Searcher` በአሳማው `"aaa"` ውስጥ ያለው `"aa"` ንድፍ ከየትኛው ወገን እንደሚፈለግ በመመርኮዝ እንደ `"[aa]a"` ወይም `"a[aa]"` ተመሳሳይ ስለሆነ `DoubleEndedSearcher` አይደለም።
///
///
///
///
///
///
///
///
///
pub trait DoubleEndedSearcher<'a>: ReverseSearcher<'a> {}

/////////////////////////////////////////////////////////////////////////////
// ለ char. Impl
/////////////////////////////////////////////////////////////////////////////

/// ለ `<char as Pattern<'a>>::Searcher` የተጎዳኘ ዓይነት።
#[derive(Clone, Debug)]
pub struct CharSearcher<'a> {
    haystack: &'a str,
    // ደህንነት የማይለዋወጥ: `finger`/`finger_back` የ `haystack` ትክክለኛ የ utf8 ባይት መረጃ ጠቋሚ መሆን አለበት ይህ የማይለዋወጥ *በ* next_match እና next_match_back ውስጥ ሊሰበር ይችላል ፣ ሆኖም ግን በትክክለኛው የኮድ ነጥብ ወሰን ላይ በጣቶች መውጣት አለባቸው።
    //
    //
    /// `finger` የወደፊቱ ፍለጋ የአሁኑ ባይት መረጃ ጠቋሚ ነው።
    /// ይህ ማለትም በራሱ ጠቋሚ, በ ባይት ፊት መኖሩን እንበል
    /// `haystack[finger]` ወደፊት ፍለጋ በሚደረግበት ወቅት መመርመር ያለብን የመጀመሪያው የተቆራረጠ ባይት ነው
    ///
    finger: usize,
    /// `finger_back` የተገላቢጦሽ ፍለጋ የአሁኑ ባይት መረጃ ጠቋሚ ነው።
    /// በመረጃ ጠቋሚው ከ‹ባይት›በኋላ እንደሚኖር ያስቡ ፣ ማለትም ፣ ማለትም
    /// ወደፊት በፍለጋ ወቅት መመርመር ያለብን የቁርጭምጭሚት [ጣት_ ጀርባ ፣ 1] የመጨረሻው ባይት ነው (ስለሆነም next_back()) ን ሲደወል የሚመረመር የመጀመሪያው ባይት ነው) ፡፡
    ///
    finger_back: usize,
    /// እየተፈለገ ያለው ገጸ-ባህሪ
    needle: char,

    // ደህንነት የማይለዋወጥ: `utf8_size` ከ 5 በታች መሆን አለበት
    /// የባይትስ ቁጥር `needle` በ utf8 ውስጥ ሲመሰጠር ይወስዳል።
    utf8_size: usize,
    /// አንድ utf8 የተቀየረ የ `needle` ቅጅ
    utf8_encoded: [u8; 4],
}

unsafe impl<'a> Searcher<'a> for CharSearcher<'a> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }
    #[inline]
    fn next(&mut self) -> SearchStep {
        let old_finger = self.finger;
        // ደህንነት: `get_unchecked` 1-4 ዋስትና ደህንነት
        // 1. `self.finger` እና `self.finger_back` በዩኒኮድ ወሰኖች ላይ ይቀመጣሉ (ይህ የማይለዋወጥ ነው)
        // 2. `self.finger >= 0` ጀምሮ ከ 0 ጀምሮ ብቻ ይጨምራል
        // 3. `self.finger < self.finger_back` ምክንያቱም አለበለዚያ ቻርጁ `iter` `SearchStep::Done` ን ይመልሳል
        // 4.
        // `self.finger` `self.finger_back` መጨረሻ ይጀምርና ብቻ ይቀንሳል ምክንያቱም የድርቆሽ ክምር መጨረሻ በፊት ይመጣል
        //
        //
        let slice = unsafe { self.haystack.get_unchecked(old_finger..self.finger_back) };
        let mut iter = slice.chars();
        let old_len = iter.iter.len();
        if let Some(ch) = iter.next() {
            // የ utf-8 ን እንደገና ሳይቀይር የአሁኑን ቁምፊ ባይት ማካካሻ ያክሉ
            //
            self.finger += old_len - iter.iter.len();
            if ch == self.needle {
                SearchStep::Match(old_finger, self.finger)
            } else {
                SearchStep::Reject(old_finger, self.finger)
            }
        } else {
            SearchStep::Done
        }
    }
    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        loop {
            // የመጨረሻውን ቁምፊ አገኘ በኋላ የድርቆሽ ክምር ያግኙ
            let bytes = self.haystack.as_bytes().get(self.finger..self.finger_back)?;
            // የ utf8 ኢንኮድ መርፌ የመጨረሻ ባይት SAFETY: እኛ የማይለዋወጥ `utf8_size < 5` አለን
            //
            let last_byte = unsafe { *self.utf8_encoded.get_unchecked(self.utf8_size - 1) };
            if let Some(index) = memchr::memchr(last_byte, bytes) {
                // ለመጨረሻው የባህርይ ባይት memchr'd ስለሆንን አዲሱ ጣት ያገኘነው ባይት መረጃ ጠቋሚ ሲሆን አንድ ሲደመር ነው ፡፡
                //
                // ይህ ሁልጊዜ UTF8 ወሰን ላይ እኛን አንድ ጣት መስጠት እንዳልሆነ ልብ በል.
                // የእኛን ባህሪ * ካላገኘን የመጨረሻውን ባይት ባለ 3 ባይት ወይም ባለ 4 ባይት ጠቋሚ አመልክተን ይሆናል ፡፡
                // እንደ ꁁ (U + A041 YI SYLLABLE PA) ፣ utf-8 `EA 81 81` ያለ ገጸ-ባህሪ ሦስተኛውን ስንፈልግ ሁሌም ሁለተኛውን ባይት እንድናገኝ ያደርገናል ምክንያቱም ወደ ቀጣዩ ትክክለኛ የመነሻ ባይት መዝለል አንችልም ፡፡
                //
                //
                // ሆኖም ፣ ይህ ሙሉ በሙሉ ደህና ነው።
                // self.finger በ UTF8 ድንበር ላይ እንዳለ የማይለዋወጥ ባለን ጊዜ ፣ ይህ የማይለዋወጥ ሰው በዚህ ዘዴ አይታመንም (በ CharSearcher::next()) ውስጥ ይተማመናል) ፡፡
                //
                // እኛም አንድ ነገር ለማግኘት ከሆነ ብቻ ነው እኛ ሕብረቁምፊ መጨረሻ ላይ መድረስ ጊዜ ይህ ዘዴ ለመውጣት, ወይም.አንድ ነገር ስናገኝ `finger` ወደ UTF8 ወሰን ይቀናበራል።
                //
                //
                //
                //
                //
                //
                self.finger += index + 1;
                if self.finger >= self.utf8_size {
                    let found_char = self.finger - self.utf8_size;
                    if let Some(slice) = self.haystack.as_bytes().get(found_char..self.finger) {
                        if slice == &self.utf8_encoded[0..self.utf8_size] {
                            return Some((found_char, self.finger));
                        }
                    }
                }
            } else {
                // ምንም አላገኘም ፣ ውጣ
                self.finger = self.finger_back;
                return None;
            }
        }
    }

    // ነባሪውን አተገባበር ከ Searcher trait የሚቀጥለው_ምረጥ እንጠቀም
}

unsafe impl<'a> ReverseSearcher<'a> for CharSearcher<'a> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        let old_finger = self.finger_back;
        // ደህንነት: next() ለ አስተያየት ከላይ ይመልከቱ
        let slice = unsafe { self.haystack.get_unchecked(self.finger..old_finger) };
        let mut iter = slice.chars();
        let old_len = iter.iter.len();
        if let Some(ch) = iter.next_back() {
            // እንደ utf-8 እንደገና ሳይቀይር የአሁኑን ቁምፊ ባይት ማካካሻ ይቀንሱ
            //
            self.finger_back -= old_len - iter.iter.len();
            if ch == self.needle {
                SearchStep::Match(self.finger_back, old_finger)
            } else {
                SearchStep::Reject(self.finger_back, old_finger)
            }
        } else {
            SearchStep::Done
        }
    }
    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        let haystack = self.haystack.as_bytes();
        loop {
            // ወደ የድርቆሽ ክምር እንድንነሳ ግን የመጨረሻው ቁምፊ ጨምሮ አይደለም ፈልገዋል
            let bytes = haystack.get(self.finger..self.finger_back)?;
            // የ utf8 ኢንኮድ መርፌ የመጨረሻ ባይት SAFETY: እኛ የማይለዋወጥ `utf8_size < 5` አለን
            //
            let last_byte = unsafe { *self.utf8_encoded.get_unchecked(self.utf8_size - 1) };
            if let Some(index) = memchr::memrchr(last_byte, bytes) {
                // በ self.finger የተስተካከለ ቁራጭ ፈልገን ነበር ፣ የመጀመሪያውን መረጃ ጠቋሚ ለማስመለስ self.finger ን ይጨምሩ
                //
                let index = self.finger + index;
                // memrchr እኛ ለማግኘት የሚፈልጉ ወደ ባይት ያለውን ጠቋሚ ይመለሳል.
                // አስኪ ቁምፊ ሁኔታ, ይህ በእርግጥ እኛ አዲሱን ጣት (በግልባጭ ተደጋጋሚነት እንደሚመስል ውስጥ "after" ወደ አገኘ ቁምፊ) መሆን የሚፈልጉ ነበሩ ነው.
                //
                // multibyte ካርስ ስለ እኛ እነርሱ አስኪ በላይ ያላቸው ባይት በላይ ቁጥር አማካኝነት ወደ ታች መዝለል አለብዎት
                //
                //
                let shift = self.utf8_size - 1;
                if index >= shift {
                    let found_char = index - shift;
                    if let Some(slice) = haystack.get(found_char..(found_char + self.utf8_size)) {
                        if slice == &self.utf8_encoded[0..self.utf8_size] {
                            // ወደ ቁምፊ አገኘ በፊት ወደ ጣት ማንቀሳቀስ (ማለትም, በራሱ የመጀመሪያ ጠቋሚ ላይ)
                            self.finger_back = found_char;
                            return Some((self.finger_back, self.finger_back + self.utf8_size));
                        }
                    }
                }
                // እዚህ የጣት_ኋላ=ማውጫ ፣ መጠን + 1 መጠቀም አንችልም።
                // የተለያየ መጠን ያለው ገጸ-ባህሪ የመጨረሻውን ቻርትን (ወይም የተለየ ቁምፊ መካከለኛ ባይት) ካገኘን የጣት_ኋላውን ወደ `index` ዝቅ ማድረግ አለብን ፡፡
                // ይህ በተመሳሳይ `finger_back` ወሰን ላይ መሆን ከአሁን በኋላ ምንም ማድረግ የሚችሉ ያደርጋል, ነገር ግን እኛ ብቻ ወሰን ወይም የድርቆሽ ክምር ቆይቷል ጊዜ ሙሉ በሙሉ ፍለጋ ላይ ይህንን ተግባር መውጣት ጀምሮ ይህ እሺ ነው.
                //
                //
                // ከመጪው_ምችት በተለየ ይህ በ‹utf-8 X›ውስጥ የተደጋገሙ ባይቶች ችግር የለውም ምክንያቱም የመጨረሻውን ባይት እየፈለግን ስለሆነ የመጨረሻውን ባይት ማግኘት የምንችለው በተቃራኒው ስንፈልግ ብቻ ነው ፡፡
                //
                //
                //
                //
                //
                self.finger_back = index;
            } else {
                self.finger_back = self.finger;
                // ምንም አላገኘም ፣ ውጣ
                return None;
            }
        }
    }

    // ቀጣዩን_ምላሽ_ባሪው ነባሪውን አተገባበር ከ Searcher trait እንዲጠቀም ያድርጉ
}

impl<'a> DoubleEndedSearcher<'a> for CharSearcher<'a> {}

/// ከተሰጠ [`char`] ጋር እኩል የሆኑ የቼርች ፍለጋዎች።
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find('o'), Some(4));
/// ```
impl<'a> Pattern<'a> for char {
    type Searcher = CharSearcher<'a>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> Self::Searcher {
        let mut utf8_encoded = [0; 4];
        let utf8_size = self.encode_utf8(&mut utf8_encoded).len();
        CharSearcher {
            haystack,
            finger: 0,
            finger_back: haystack.len(),
            needle: self,
            utf8_size,
            utf8_encoded,
        }
    }

    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        if (self as u32) < 128 {
            haystack.as_bytes().contains(&(self as u8))
        } else {
            let mut buffer = [0u8; 4];
            self.encode_utf8(&mut buffer).is_contained_in(haystack)
        }
    }

    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        self.encode_utf8(&mut [0u8; 4]).is_prefix_of(haystack)
    }

    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        self.encode_utf8(&mut [0u8; 4]).strip_prefix_of(haystack)
    }

    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        self.encode_utf8(&mut [0u8; 4]).is_suffix_of(haystack)
    }

    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        self.encode_utf8(&mut [0u8; 4]).strip_suffix_of(haystack)
    }
}

/////////////////////////////////////////////////////////////////////////////
// ለ‹MultiCharEq›መጠቅለያ ኢምፕል
/////////////////////////////////////////////////////////////////////////////

#[doc(hidden)]
trait MultiCharEq {
    fn matches(&mut self, c: char) -> bool;
}

impl<F> MultiCharEq for F
where
    F: FnMut(char) -> bool,
{
    #[inline]
    fn matches(&mut self, c: char) -> bool {
        (*self)(c)
    }
}

impl MultiCharEq for &[char] {
    #[inline]
    fn matches(&mut self, c: char) -> bool {
        self.iter().any(|&m| m == c)
    }
}

struct MultiCharEqPattern<C: MultiCharEq>(C);

#[derive(Clone, Debug)]
struct MultiCharEqSearcher<'a, C: MultiCharEq> {
    char_eq: C,
    haystack: &'a str,
    char_indices: super::CharIndices<'a>,
}

impl<'a, C: MultiCharEq> Pattern<'a> for MultiCharEqPattern<C> {
    type Searcher = MultiCharEqSearcher<'a, C>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> MultiCharEqSearcher<'a, C> {
        MultiCharEqSearcher { haystack, char_eq: self.0, char_indices: haystack.char_indices() }
    }
}

unsafe impl<'a, C: MultiCharEq> Searcher<'a> for MultiCharEqSearcher<'a, C> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }

    #[inline]
    fn next(&mut self) -> SearchStep {
        let s = &mut self.char_indices;
        // የአሁኑን ቻርተር ርዝመት ለማግኘት የውስጥ ባይት ቁርጥራጭ ድግግሞሽ ያነፃፅሩ
        //
        let pre_len = s.iter.iter.len();
        if let Some((i, c)) = s.next() {
            let len = s.iter.iter.len();
            let char_len = pre_len - len;
            if self.char_eq.matches(c) {
                return SearchStep::Match(i, i + char_len);
            } else {
                return SearchStep::Reject(i, i + char_len);
            }
        }
        SearchStep::Done
    }
}

unsafe impl<'a, C: MultiCharEq> ReverseSearcher<'a> for MultiCharEqSearcher<'a, C> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        let s = &mut self.char_indices;
        // የአሁኑን ቻርተር ርዝመት ለማግኘት የውስጥ ባይት ቁርጥራጭ ድግግሞሽ ያነፃፅሩ
        //
        let pre_len = s.iter.iter.len();
        if let Some((i, c)) = s.next_back() {
            let len = s.iter.iter.len();
            let char_len = pre_len - len;
            if self.char_eq.matches(c) {
                return SearchStep::Match(i, i + char_len);
            } else {
                return SearchStep::Reject(i, i + char_len);
            }
        }
        SearchStep::Done
    }
}

impl<'a, C: MultiCharEq> DoubleEndedSearcher<'a> for MultiCharEqSearcher<'a, C> {}

/////////////////////////////////////////////////////////////////////////////

macro_rules! pattern_methods {
    ($t:ty, $pmap:expr, $smap:expr) => {
        type Searcher = $t;

        #[inline]
        fn into_searcher(self, haystack: &'a str) -> $t {
            ($smap)(($pmap)(self).into_searcher(haystack))
        }

        #[inline]
        fn is_contained_in(self, haystack: &'a str) -> bool {
            ($pmap)(self).is_contained_in(haystack)
        }

        #[inline]
        fn is_prefix_of(self, haystack: &'a str) -> bool {
            ($pmap)(self).is_prefix_of(haystack)
        }

        #[inline]
        fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
            ($pmap)(self).strip_prefix_of(haystack)
        }

        #[inline]
        fn is_suffix_of(self, haystack: &'a str) -> bool
        where
            $t: ReverseSearcher<'a>,
        {
            ($pmap)(self).is_suffix_of(haystack)
        }

        #[inline]
        fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
        where
            $t: ReverseSearcher<'a>,
        {
            ($pmap)(self).strip_suffix_of(haystack)
        }
    };
}

macro_rules! searcher_methods {
    (forward) => {
        #[inline]
        fn haystack(&self) -> &'a str {
            self.0.haystack()
        }
        #[inline]
        fn next(&mut self) -> SearchStep {
            self.0.next()
        }
        #[inline]
        fn next_match(&mut self) -> Option<(usize, usize)> {
            self.0.next_match()
        }
        #[inline]
        fn next_reject(&mut self) -> Option<(usize, usize)> {
            self.0.next_reject()
        }
    };
    (reverse) => {
        #[inline]
        fn next_back(&mut self) -> SearchStep {
            self.0.next_back()
        }
        #[inline]
        fn next_match_back(&mut self) -> Option<(usize, usize)> {
            self.0.next_match_back()
        }
        #[inline]
        fn next_reject_back(&mut self) -> Option<(usize, usize)> {
            self.0.next_reject_back()
        }
    };
}

/////////////////////////////////////////////////////////////////////////////
// Impl ለ&[ቻር]
/////////////////////////////////////////////////////////////////////////////

// Todo: በትርጉሙ አሻሚነት ምክንያት ለውጥ/ማስወገድ ፡፡

/// ለ `<&[char] as Pattern<'a>>::Searcher` የተጎዳኘ ዓይነት።
#[derive(Clone, Debug)]
pub struct CharSliceSearcher<'a, 'b>(<MultiCharEqPattern<&'b [char]> as Pattern<'a>>::Searcher);

unsafe impl<'a, 'b> Searcher<'a> for CharSliceSearcher<'a, 'b> {
    searcher_methods!(forward);
}

unsafe impl<'a, 'b> ReverseSearcher<'a> for CharSliceSearcher<'a, 'b> {
    searcher_methods!(reverse);
}

impl<'a, 'b> DoubleEndedSearcher<'a> for CharSliceSearcher<'a, 'b> {}

/// በ ቁራጭ ውስጥ [`char`] ን ማንኛውም ጋር እኩል የሆኑ ቁምፊዎች ለ ፍለጋዎች.
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find(&['l', 'l'] as &[_]), Some(2));
/// assert_eq!("Hello world".find(&['l', 'l'][..]), Some(2));
/// ```
impl<'a, 'b> Pattern<'a> for &'b [char] {
    pattern_methods!(CharSliceSearcher<'a, 'b>, MultiCharEqPattern, CharSliceSearcher);
}

/////////////////////////////////////////////////////////////////////////////
// Impl ለ F: FnMut(char)-> bool
/////////////////////////////////////////////////////////////////////////////

/// `<F as Pattern<'a>>::Searcher` ለ አይነት የተጎዳኙ.
#[derive(Clone)]
pub struct CharPredicateSearcher<'a, F>(<MultiCharEqPattern<F> as Pattern<'a>>::Searcher)
where
    F: FnMut(char) -> bool;

impl<F> fmt::Debug for CharPredicateSearcher<'_, F>
where
    F: FnMut(char) -> bool,
{
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("CharPredicateSearcher")
            .field("haystack", &self.0.haystack)
            .field("char_indices", &self.0.char_indices)
            .finish()
    }
}
unsafe impl<'a, F> Searcher<'a> for CharPredicateSearcher<'a, F>
where
    F: FnMut(char) -> bool,
{
    searcher_methods!(forward);
}

unsafe impl<'a, F> ReverseSearcher<'a> for CharPredicateSearcher<'a, F>
where
    F: FnMut(char) -> bool,
{
    searcher_methods!(reverse);
}

impl<'a, F> DoubleEndedSearcher<'a> for CharPredicateSearcher<'a, F> where F: FnMut(char) -> bool {}

/// ከተሰጠው ቅድመ-ግምት ጋር የሚዛመዱ የ [`ቻር`] ፍለጋዎች።
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find(char::is_uppercase), Some(0));
/// assert_eq!("Hello world".find(|c| "aeiou".contains(c)), Some(1));
/// ```
impl<'a, F> Pattern<'a> for F
where
    F: FnMut(char) -> bool,
{
    pattern_methods!(CharPredicateSearcher<'a, F>, MultiCharEqPattern, CharPredicateSearcher);
}

/////////////////////////////////////////////////////////////////////////////
// &&STR ለ impl
/////////////////////////////////////////////////////////////////////////////

/// ወደ `&str` impl ልዑካን.
impl<'a, 'b, 'c> Pattern<'a> for &'c &'b str {
    pattern_methods!(StrSearcher<'a, 'b>, |&s| s, |s| s);
}

/////////////////////////////////////////////////////////////////////////////
// Impl ለ &str
/////////////////////////////////////////////////////////////////////////////

/// ያልተመደበ የስሪብሪንግ ፍለጋ።
///
/// በእያንዳንዱ ቁምፊ ድንበር ላይ ባዶ ግጥሚያዎችን እንደሚመልስ ንድፍ `""` ን ያስተናግዳል።
///
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find("world"), Some(6));
/// ```
impl<'a, 'b> Pattern<'a> for &'b str {
    type Searcher = StrSearcher<'a, 'b>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> StrSearcher<'a, 'b> {
        StrSearcher::new(haystack, self)
    }

    /// ንድፉ በሣር ክዳን ፊት ለፊት የሚዛመድ መሆኑን ይፈትሻል።
    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        haystack.as_bytes().starts_with(self.as_bytes())
    }

    /// ንድፉን ከሣር ክምር ፊት ላይ ያስወግዳል ፣ የሚዛመድ ከሆነ።
    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        if self.is_prefix_of(haystack) {
            // ደህንነት-ቅድመ ቅጥያ ለመኖሩ አሁን ተረጋግጧል ፡፡
            unsafe { Some(haystack.get_unchecked(self.as_bytes().len()..)) }
        } else {
            None
        }
    }

    /// ንድፉ በሣር ክዳን ጀርባ ላይ የሚዛመድ መሆኑን ይፈትሻል።
    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool {
        haystack.as_bytes().ends_with(self.as_bytes())
    }

    /// ንድፉን ከሣር ክዳን በስተጀርባ ያስወግዳል ፣ ከተመሳሰለ።
    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str> {
        if self.is_suffix_of(haystack) {
            let i = haystack.len() - self.as_bytes().len();
            // ደህንነት: ቅጥያ ብቻ ሕልውና ተረጋግጧል.
            unsafe { Some(haystack.get_unchecked(..i)) }
        } else {
            None
        }
    }
}

/////////////////////////////////////////////////////////////////////////////
// ባለሁለት ዌይ ንዑስ ቁልፍ መርማሪ
/////////////////////////////////////////////////////////////////////////////

#[derive(Clone, Debug)]
/// ለ `<&str as Pattern<'a>>::Searcher` የተጎዳኘ ዓይነት።
pub struct StrSearcher<'a, 'b> {
    haystack: &'a str,
    needle: &'b str,

    searcher: StrSearcherImpl,
}

#[derive(Clone, Debug)]
enum StrSearcherImpl {
    Empty(EmptyNeedle),
    TwoWay(TwoWaySearcher),
}

#[derive(Clone, Debug)]
struct EmptyNeedle {
    position: usize,
    end: usize,
    is_match_fw: bool,
    is_match_bw: bool,
}

impl<'a, 'b> StrSearcher<'a, 'b> {
    fn new(haystack: &'a str, needle: &'b str) -> StrSearcher<'a, 'b> {
        if needle.is_empty() {
            StrSearcher {
                haystack,
                needle,
                searcher: StrSearcherImpl::Empty(EmptyNeedle {
                    position: 0,
                    end: haystack.len(),
                    is_match_fw: true,
                    is_match_bw: true,
                }),
            }
        } else {
            StrSearcher {
                haystack,
                needle,
                searcher: StrSearcherImpl::TwoWay(TwoWaySearcher::new(
                    needle.as_bytes(),
                    haystack.len(),
                )),
            }
        }
    }
}

unsafe impl<'a, 'b> Searcher<'a> for StrSearcher<'a, 'b> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }

    #[inline]
    fn next(&mut self) -> SearchStep {
        match self.searcher {
            StrSearcherImpl::Empty(ref mut searcher) => {
                // ባዶ መርፌ እያንዳንዱን ቻርጅ ውድቅ ያደርገዋል እና በመካከላቸው ካለው ባዶ ገመድ ሁሉ ጋር ይዛመዳል
                let is_match = searcher.is_match_fw;
                searcher.is_match_fw = !searcher.is_match_fw;
                let pos = searcher.position;
                match self.haystack[pos..].chars().next() {
                    _ if is_match => SearchStep::Match(pos, pos),
                    None => SearchStep::Done,
                    Some(ch) => {
                        searcher.position += ch.len_utf8();
                        SearchStep::Reject(pos, searcher.position)
                    }
                }
            }
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                // TwoWaySearcher ልክ *ግጥሚያ* የይዘቶቹ የሚያፈራው ለረጅም ትክክል ተዛማጅ የሚያደርግ እና የድርቆሽ ክምር እና መርፌ *ወደ ስልተ ማንኛውም የይዘቶቹ ላይ ይወድቃሉ ይችላሉ, ነገር ግን ወደ ቀጣዩ ቁምፊ ወሰን ወደ በእጅ እነሱን እንሄዳለን ልክ UTF-8* የተባረሩ ናቸው እንደ ቁምፊ ድንበሮች ላይ መከፋፈል ፣ እነሱ utf-8 ደህንነታቸው የተጠበቀ ናቸው።
                //
                //
                //
                //
                if searcher.position == self.haystack.len() {
                    return SearchStep::Done;
                }
                let is_long = searcher.memory == usize::MAX;
                match searcher.next::<RejectAndMatch>(
                    self.haystack.as_bytes(),
                    self.needle.as_bytes(),
                    is_long,
                ) {
                    SearchStep::Reject(a, mut b) => {
                        // ወደ ቀጣዩ የቻር ወሰን ዝለል
                        while !self.haystack.is_char_boundary(b) {
                            b += 1;
                        }
                        searcher.position = cmp::max(b, searcher.position);
                        SearchStep::Reject(a, b)
                    }
                    otherwise => otherwise,
                }
            }
        }
    }

    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        match self.searcher {
            StrSearcherImpl::Empty(..) => loop {
                match self.next() {
                    SearchStep::Match(a, b) => return Some((a, b)),
                    SearchStep::Done => return None,
                    SearchStep::Reject(..) => {}
                }
            },
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                let is_long = searcher.memory == usize::MAX;
                // አዘጋጁን ሁለቱን ጉዳዮች በተናጠል በልዩ ሁኔታ እንዲያከናውን ለማበረታታት የ `true` እና `false` ጉዳዮችን ይጻፉ ፡፡
                //
                if is_long {
                    searcher.next::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        true,
                    )
                } else {
                    searcher.next::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        false,
                    )
                }
            }
        }
    }
}

unsafe impl<'a, 'b> ReverseSearcher<'a> for StrSearcher<'a, 'b> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        match self.searcher {
            StrSearcherImpl::Empty(ref mut searcher) => {
                let is_match = searcher.is_match_bw;
                searcher.is_match_bw = !searcher.is_match_bw;
                let end = searcher.end;
                match self.haystack[..end].chars().next_back() {
                    _ if is_match => SearchStep::Match(end, end),
                    None => SearchStep::Done,
                    Some(ch) => {
                        searcher.end -= ch.len_utf8();
                        SearchStep::Reject(searcher.end, end)
                    }
                }
            }
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                if searcher.end == 0 {
                    return SearchStep::Done;
                }
                let is_long = searcher.memory == usize::MAX;
                match searcher.next_back::<RejectAndMatch>(
                    self.haystack.as_bytes(),
                    self.needle.as_bytes(),
                    is_long,
                ) {
                    SearchStep::Reject(mut a, b) => {
                        // ወደ ቀጣዩ የቻር ወሰን ዝለል
                        while !self.haystack.is_char_boundary(a) {
                            a -= 1;
                        }
                        searcher.end = cmp::min(a, searcher.end);
                        SearchStep::Reject(a, b)
                    }
                    otherwise => otherwise,
                }
            }
        }
    }

    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        match self.searcher {
            StrSearcherImpl::Empty(..) => loop {
                match self.next_back() {
                    SearchStep::Match(a, b) => return Some((a, b)),
                    SearchStep::Done => return None,
                    SearchStep::Reject(..) => {}
                }
            },
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                let is_long = searcher.memory == usize::MAX;
                // እንደ `next_match` ያሉ `true` እና `false` ን ይፃፉ
                if is_long {
                    searcher.next_back::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        true,
                    )
                } else {
                    searcher.next_back::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        false,
                    )
                }
            }
        }
    }
}

/// የሁለት-መንገድ የመለዋወጫ ፍለጋ አልጎሪዝም ውስጣዊ ሁኔታ።
#[derive(Clone, Debug)]
struct TwoWaySearcher {
    // constants
    /// ወሳኝ አመላካች አመላካች
    crit_pos: usize,
    /// ለተገለበጠ መርፌ ወሳኝ አመላካች አመላካች
    crit_pos_back: usize,
    period: usize,
    /// `byteset` ቅጥያ ነው (የሁለቱ መንገድ አልጎሪዝም አካል አይደለም);
    /// እያንዳንዱ ስብስብ ቢት `j` በመርፌ ውስጥ ከሚገኝ (ባይት&63)==j ጋር የሚዛመድ 64 ቢት "fingerprint" ነው ፡፡
    ///
    byteset: u64,

    // variables
    position: usize,
    end: usize,
    /// ከዚህ በፊት ከተዛመድነው በፊት ወደ መርፌ ማውጫ
    memory: usize,
    /// ቀደም ሊዛመድ በኋላ መርፌ ወደ መረጃ ጠቋሚ
    memory_back: usize,
}

/*
    This is the Two-Way search algorithm, which was introduced in the paper:
    Crochemore, M., Perrin, D., 1991, Two-way string-matching, Journal of the ACM 38(3):651-675.

    Here's some background information.

    A *word* is a string of symbols. The *length* of a word should be a familiar
    notion, and here we denote it for any word x by |x|.
    (We also allow for the possibility of the *empty word*, a word of length zero).

    If x is any non-empty word, then an integer p with 0 < p <= |x| is said to be a
    *period* for x iff for all i with 0 <= i <= |x| - p - 1, we have x[i] == x[i+p].
    For example, both 1 and 2 are periods for the string "aa". As another example,
    the only period of the string "abcd" is 4.

    We denote by period(x) the *smallest* period of x (provided that x is non-empty).
    This is always well-defined since every non-empty word x has at least one period,
    |x|. We sometimes call this *the period* of x.

    If u, v and x are words such that x = uv, where uv is the concatenation of u and
    v, then we say that (u, v) is a *factorization* of x.

    Let (u, v) be a factorization for a word x. Then if w is a non-empty word such
    that both of the following hold

      - either w is a suffix of u or u is a suffix of w
      - either w is a prefix of v or v is a prefix of w

    then w is said to be a *repetition* for the factorization (u, v).

    Just to unpack this, there are four possibilities here. Let w = "abc". Then we
    might have:

      - w is a suffix of u and w is a prefix of v. ex: ("lolabc", "abcde")
      - w is a suffix of u and v is a prefix of w. ex: ("lolabc", "ab")
      - u is a suffix of w and w is a prefix of v. ex: ("bc", "abchi")
      - u is a suffix of w and v is a prefix of w. ex: ("bc", "a")

    Note that the word vu is a repetition for any factorization (u,v) of x = uv,
    so every factorization has at least one repetition.

    If x is a string and (u, v) is a factorization for x, then a *local period* for
    (u, v) is an integer r such that there is some word w such that |w| = r and w is
    a repetition for (u, v).

    We denote by local_period(u, v) the smallest local period of (u, v). We sometimes
    call this *the local period* of (u, v). Provided that x = uv is non-empty, this
    is well-defined (because each non-empty word has at least one factorization, as
    noted above).

    It can be proven that the following is an equivalent definition of a local period
    for a factorization (u, v): any positive integer r such that x[i] == x[i+r] for
    all i such that |u| - r <= i <= |u| - 1 and such that both x[i] and x[i+r] are
    defined. (i.e., i > 0 and i + r < |x|).

    Using the above reformulation, it is easy to prove that

        1 <= local_period(u, v) <= period(uv)

    A factorization (u, v) of x such that local_period(u,v) = period(x) is called a
    *critical factorization*.

    The algorithm hinges on the following theorem, which is stated without proof:

    **Critical Factorization Theorem** Any word x has at least one critical
    factorization (u, v) such that |u| < period(x).

    The purpose of maximal_suffix is to find such a critical factorization.

    If the period is short, compute another factorization x = u' v' to use
    for reverse search, chosen instead so that |v'| < period(x).

*/
impl TwoWaySearcher {
    fn new(needle: &[u8], end: usize) -> TwoWaySearcher {
        let (crit_pos_false, period_false) = TwoWaySearcher::maximal_suffix(needle, false);
        let (crit_pos_true, period_true) = TwoWaySearcher::maximal_suffix(needle, true);

        let (crit_pos, period) = if crit_pos_false > crit_pos_true {
            (crit_pos_false, period_false)
        } else {
            (crit_pos_true, period_true)
        };

        // በተለይ እዚህ ምን እየተከናወነ እንዳለ ሊነበብ የሚችል ማብራሪያ በ Crochemore እና Rytter መጽሐፍ "Text Algorithms" ፣ ch 13 ውስጥ ይገኛል ፡፡
        // በተለይም የ "Algorithm CP" ን ኮድ በ p.
        // 323.
        //
        // ምን እየተከናወነ እንዳለ ነው የመርፌው ወሳኝ አመላካችነት (u ፣ v) አለን ፣ እና እርስዎ የ&v [.. period] ቅጥያ/አለመሆኑን መወሰን እንፈልጋለን ፡፡
        // ከሆነ ፣ እኛ "Algorithm CP1" ን እንጠቀማለን።
        // አለበለዚያ የመርፌው ጊዜ ትልቅ በሚሆንበት ጊዜ የተመቻቸውን "Algorithm CP2" ን እንጠቀማለን ፡፡
        //
        //
        if needle[..crit_pos] == needle[period..period + crit_pos] {
            // የአጭር ጊዜ ጉዳይ-ጊዜው በትክክል ለተለወጠው መርፌ የተለየ ወሳኝ አመላካች ማስላት x=u 'v' where | v '|<period(x).
            //
            // ይህ ቀድሞውኑ በሚታወቀው ጊዜ የተፋጠነ ነው።
            // እንደ x= "acba" የመሰለ ጉዳይ በትክክል ወደ ፊት (crit_pos=1, period=3) በትክክል ሊገመት እንደሚችል ልብ ይበሉ (በግምታዊ ጊዜ) በተቃራኒው (crit_pos=2, period=2) ፡፡
            // እኛ የተሰጠው በግልባጭ factorization መጠቀም ግን ትክክለኛ ጊዜ ጠብቅ.
            //
            //
            //
            //
            let crit_pos_back = needle.len()
                - cmp::max(
                    TwoWaySearcher::reverse_maximal_suffix(needle, period, false),
                    TwoWaySearcher::reverse_maximal_suffix(needle, period, true),
                );

            TwoWaySearcher {
                crit_pos,
                crit_pos_back,
                period,
                byteset: Self::byteset_create(&needle[..period]),

                position: 0,
                end,
                memory: 0,
                memory_back: needle.len(),
            }
        } else {
            // ለረጅም ጊዜ ጉዳይ-እኛ ትክክለኛ ጊዜ አንድ approximation አለን, እና ማጥናት አይጠቀሙ.
            //
            //
            // ጊዜውን በዝቅተኛ ማሰሪያ max(|u|, |v|) + 1 ይገምቱ።
            // ወሳኙ አመላካችነት ለወደፊቱ እና ለተገላቢጦሽ ፍለጋ ለመጠቀም ቀልጣፋ ነው።
            //

            TwoWaySearcher {
                crit_pos,
                crit_pos_back: crit_pos,
                period: cmp::max(crit_pos, needle.len() - crit_pos) + 1,
                byteset: Self::byteset_create(needle),

                position: 0,
                end,
                memory: usize::MAX, // ጊዜው ረጅም መሆኑን ለማሳየት የደነዘዘ እሴት
                memory_back: usize::MAX,
            }
        }
    }

    #[inline]
    fn byteset_create(bytes: &[u8]) -> u64 {
        bytes.iter().fold(0, |a, &b| (1 << (b & 0x3f)) | a)
    }

    #[inline]
    fn byteset_contains(&self, byte: u8) -> bool {
        (self.byteset >> ((byte & 0x3f) as usize)) & 1 != 0
    }

    // የሁለት-መንገድ ዋና ሀሳቦች አንዱ መርፌውን ወደ ሁለት ግማሽ ፣ (u, v) ለይተን እና ከግራ ወደ ቀኝ በመቃኘት በሣር ክምር ውስጥ ቁ መፈለግን እንጀምራለን ፡፡
    // ቁ የሚዛመድ ከሆነ ከቀኝ ወደ ግራ በመቃኘት u ለማመሳሰል እንሞክራለን ፡፡
    // አለመዛመድ ሲያጋጥመን ምን ያህል መዝለል እንደምንችል (u, v) በመርፌ ወሳኝ አመላካችነት ባለው እውነታ ላይ የተመሠረተ ነው።
    //
    //
    #[inline]
    fn next<S>(&mut self, haystack: &[u8], needle: &[u8], long_period: bool) -> S::Output
    where
        S: TwoWayStrategy,
    {
        // `next()` `self.position` ን እንደ ጠቋሚው ይጠቀማል
        let old_pos = self.position;
        let needle_last = needle.len() - 1;
        'search: loop {
            // ቁርጥራጭ በአይዞአደሩ ክልል የታሰረ ነው ብለን ካሰብን በአቀማመጥ + በመርፌ_ላጥ ውስጥ ለመፈለግ ቦታ እንዳለን ያረጋግጡ።
            //
            //
            let tail_byte = match haystack.get(self.position + needle_last) {
                Some(&b) => b,
                None => {
                    self.position = haystack.len();
                    return S::rejecting(old_pos, self.position);
                }
            };

            if S::use_early_reject() && old_pos != self.position {
                return S::rejecting(old_pos, self.position);
            }

            // ከማጣቀሻችን ጋር በማይዛመዱ ትላልቅ ክፍሎች በፍጥነት ይዝለሉ
            if !self.byteset_contains(tail_byte) {
                self.position += needle.len();
                if !long_period {
                    self.memory = 0;
                }
                continue 'search;
            }

            // የመርፌው የቀኝ ክፍል የሚዛመድ መሆኑን ይመልከቱ
            let start =
                if long_period { self.crit_pos } else { cmp::max(self.crit_pos, self.memory) };
            for i in start..needle.len() {
                if needle[i] != haystack[self.position + i] {
                    self.position += i - self.crit_pos + 1;
                    if !long_period {
                        self.memory = 0;
                    }
                    continue 'search;
                }
            }

            // የመርፌው ግራ ክፍል የሚዛመድ መሆኑን ይመልከቱ
            let start = if long_period { 0 } else { self.memory };
            for i in (start..self.crit_pos).rev() {
                if needle[i] != haystack[self.position + i] {
                    self.position += self.period;
                    if !long_period {
                        self.memory = needle.len() - self.period;
                    }
                    continue 'search;
                }
            }

            // እኛ አንድ ግጥሚያ አግኝቻለሁ!
            let match_pos = self.position;

            // Note: ተደራራቢ ተዛማጆች እንዲኖሯቸው ከ needle.len() ይልቅ self.period ን ያክሉ
            self.position += needle.len();
            if !long_period {
                self.memory = 0; // ለተደራራቢ ግጥሚያዎች ወደ needle.len() ፣ self.period ተቀናብሯል
            }

            return S::matching(match_pos, match_pos + needle.len());
        }
    }

    // በ `next()` ውስጥ ያሉትን ሀሳቦች ይከተላል።
    //
    // ትርጓሜዎቹ ሚዛናዊ ናቸው ፣ ከ period(x) = period(reverse(x)) እና local_period(u, v) = local_period(reverse(v) ፣ reverse(u)) ጋር ፣ ስለሆነም (u ፣ v) ወሳኝ አመላካች ከሆነ ፣ (reverse(v) እንዲሁ ፣ reverse(u)).
    //
    //
    // ለተገላቢጦሽ ጉዳይ ወሳኝ አመላካችነት x=u 'v' (መስክ `crit_pos_back`) ብለን አስልተናል ፡፡ያስፈልገናል | u |ለተላለፈው ጉዳይ <period(x) እና በዚህም | v '|የ ጀርባና ለ <period(x).
    //
    // በሣር ክዳን በኩል በግልፅ ለመፈለግ በመጀመሪያ u 'እና ከዚያ በ v' ጋር በማዛመድ በተገለበጠ የሣር ሣር ወደ ፊት እንሻለን ፡፡
    //
    //
    //
    //
    #[inline]
    fn next_back<S>(&mut self, haystack: &[u8], needle: &[u8], long_period: bool) -> S::Output
    where
        S: TwoWayStrategy,
    {
        // `next_back()` `self.end` ን እንደ ጠቋሚው ይጠቀማል-`next()` እና `next_back()` ገለልተኛ እንዲሆኑ።
        //
        let old_end = self.end;
        'search: loop {
            // በመጨረሻ ለመፈለግ ቦታ እንዳለን ይፈትሹ ፣ needle.len() ተጨማሪ ቦታ በማይኖርበት ጊዜ ይጠመጠማል ፣ ነገር ግን በተቆራረጡ የርዝመት ገደቦች ምክንያት እስከ መጨረሻው እስከ መጨረሻው እሽክርክሪት ድረስ መጠቅለል አይችልም።
            //
            //
            //
            let front_byte = match haystack.get(self.end.wrapping_sub(needle.len())) {
                Some(&b) => b,
                None => {
                    self.end = 0;
                    return S::rejecting(0, old_end);
                }
            };

            if S::use_early_reject() && old_end != self.end {
                return S::rejecting(self.end, old_end);
            }

            // ከማጣቀሻችን ጋር በማይዛመዱ ትላልቅ ክፍሎች በፍጥነት ይዝለሉ
            if !self.byteset_contains(front_byte) {
                self.end -= needle.len();
                if !long_period {
                    self.memory_back = needle.len();
                }
                continue 'search;
            }

            // የመርፌው ግራ ክፍል የሚዛመድ መሆኑን ይመልከቱ
            let crit = if long_period {
                self.crit_pos_back
            } else {
                cmp::min(self.crit_pos_back, self.memory_back)
            };
            for i in (0..crit).rev() {
                if needle[i] != haystack[self.end - needle.len() + i] {
                    self.end -= self.crit_pos_back - i;
                    if !long_period {
                        self.memory_back = needle.len();
                    }
                    continue 'search;
                }
            }

            // የመርፌው የቀኝ ክፍል የሚዛመድ መሆኑን ይመልከቱ
            let needle_end = if long_period { needle.len() } else { self.memory_back };
            for i in self.crit_pos_back..needle_end {
                if needle[i] != haystack[self.end - needle.len() + i] {
                    self.end -= self.period;
                    if !long_period {
                        self.memory_back = self.period;
                    }
                    continue 'search;
                }
            }

            // እኛ አንድ ግጥሚያ አግኝቻለሁ!
            let match_pos = self.end - needle.len();
            // Note: ተደራራቢ ተዛማጆች እንዲኖሩት ከ needle.len() ይልቅ ንዑስ self.period
            self.end -= needle.len();
            if !long_period {
                self.memory_back = needle.len();
            }

            return S::matching(match_pos, match_pos + needle.len());
        }
    }

    // `arr` መካከል የሚደረጉ የግንኙነቶች ተቀጣይ ለማስላት.
    //
    // ከፍተኛው ቅጥያ የ `arr` ሊሆን የሚችል ወሳኝ አመላካች (u, v) ነው።
    //
    // ተመላሾች (`i` ፣ `p`) `i` የ v መነሻ መረጃ ጠቋሚ ሲሆን `p` ደግሞ ቁ.
    //
    // `order_greater` የቃላት ቅደም ተከተል `<` ወይም `>` ከሆነ ይወስናል።
    // ሁለቱም ትዕዛዞች ማስላት አለባቸው-በትልቁ `i` ያለው ቅደም ተከተል ወሳኝ ወሳኝ ሁኔታን ይሰጣል።
    //
    //
    // ለረዥም ጊዜ ጉዳዮች ፣ የተገኘው ጊዜ ትክክለኛ አይደለም (በጣም አጭር ነው) ፡፡
    //
    #[inline]
    fn maximal_suffix(arr: &[u8], order_greater: bool) -> (usize, usize) {
        let mut left = 0; // በወረቀቱ ውስጥ ከእኔ ጋር ይዛመዳል
        let mut right = 1; // በወረቀቱ ውስጥ ከ j ጋር ይዛመዳል
        let mut offset = 0; // በወረቀቱ ውስጥ ከ k ጋር ይዛመዳል ፣ ግን ከ 0 ይጀምራል
        // በ 0 ላይ የተመሠረተ መረጃ ጠቋሚዎችን ለማዛመድ.
        let mut period = 1; // በወረቀቱ ውስጥ ከፒ ጋር ይዛመዳል

        while let Some(&a) = arr.get(right + offset) {
            // `left` `right` በሚሆንበት ጊዜ ወደ ውስጥ ይገባል።
            let b = arr[left + offset];
            if (a < b && !order_greater) || (a > b && order_greater) {
                // ቅጥያ ትንሽ ነው ፣ እስከዚህ ጊዜ ድረስ ሙሉው ቅድመ ቅጥያ ነው።
                right += offset + 1;
                offset = 0;
                period = right - left;
            } else if a == b {
                // የአሁኑን ጊዜ በመድገም በኩል ወደፊት።
                if offset + 1 == period {
                    right += offset + 1;
                    offset = 0;
                } else {
                    offset += 1;
                }
            } else {
                // ቅጥያ ትልቅ ነው ፣ ከአሁኑ ቦታ ይጀምሩ።
                left = right;
                right += 1;
                offset = 0;
                period = 1;
            }
        }
        (left, period)
    }

    // የ `arr` ተቃራኒውን ከፍተኛውን ቅጥያ ያስሉ።
    //
    // ከፍተኛው ቅጥያ የ `arr` ሊሆን የሚችል ወሳኝ አመላካች (u ', v') ነው።
    //
    // `i` የ v 'መነሻ መረጃ ጠቋሚ በሆነበት `i` ይመልሳል ፣ ከኋላ;
    // የ `known_period` ጊዜ ሲደርስ ወዲያውኑ ይመለሳል።
    //
    // `order_greater` የቃላት ቅደም ተከተል `<` ወይም `>` ከሆነ ይወስናል።
    // ሁለቱም ትዕዛዞች ማስላት አለባቸው-በትልቁ `i` ያለው ቅደም ተከተል ወሳኝ ወሳኝ ሁኔታን ይሰጣል።
    //
    //
    // ለረዥም ጊዜ ጉዳዮች ፣ የተገኘው ጊዜ ትክክለኛ አይደለም (በጣም አጭር ነው) ፡፡
    fn reverse_maximal_suffix(arr: &[u8], known_period: usize, order_greater: bool) -> usize {
        let mut left = 0; // በወረቀቱ ውስጥ ከእኔ ጋር ይዛመዳል
        let mut right = 1; // በወረቀቱ ውስጥ ከ j ጋር ይዛመዳል
        let mut offset = 0; // በወረቀቱ ውስጥ ከ k ጋር ይዛመዳል ፣ ግን ከ 0 ይጀምራል
        // በ 0 ላይ የተመሠረተ መረጃ ጠቋሚዎችን ለማዛመድ.
        let mut period = 1; // በወረቀቱ ውስጥ ከፒ ጋር ይዛመዳል
        let n = arr.len();

        while right + offset < n {
            let a = arr[n - (1 + right + offset)];
            let b = arr[n - (1 + left + offset)];
            if (a < b && !order_greater) || (a > b && order_greater) {
                // ቅጥያ ትንሽ ነው ፣ እስከዚህ ጊዜ ድረስ ሙሉው ቅድመ ቅጥያ ነው።
                right += offset + 1;
                offset = 0;
                period = right - left;
            } else if a == b {
                // የአሁኑን ጊዜ በመድገም በኩል ወደፊት።
                if offset + 1 == period {
                    right += offset + 1;
                    offset = 0;
                } else {
                    offset += 1;
                }
            } else {
                // ቅጥያ ትልቅ ነው ፣ ከአሁኑ ቦታ ይጀምሩ።
                left = right;
                right += 1;
                offset = 0;
                period = 1;
            }
            if period == known_period {
                break;
            }
        }
        debug_assert!(period <= known_period);
        left
    }
}

// ባለሁለት ስትራቴጂ ስልተ-ቀመር ግጥሚያ ያልሆኑ ግጥሚያዎችን በተቻለ ፍጥነት ለመዝለል ወይም በአንጻራዊነት በፍጥነት ውድቅ በሚያደርግበት ሁኔታ እንዲሠራ ያስችለዋል ፡፡
//
trait TwoWayStrategy {
    type Output;
    fn use_early_reject() -> bool;
    fn rejecting(a: usize, b: usize) -> Self::Output;
    fn matching(a: usize, b: usize) -> Self::Output;
}

/// ክፍተቶችን በተቻለ ፍጥነት ለማዛመድ ዝለል
enum MatchOnly {}

impl TwoWayStrategy for MatchOnly {
    type Output = Option<(usize, usize)>;

    #[inline]
    fn use_early_reject() -> bool {
        false
    }
    #[inline]
    fn rejecting(_a: usize, _b: usize) -> Self::Output {
        None
    }
    #[inline]
    fn matching(a: usize, b: usize) -> Self::Output {
        Some((a, b))
    }
}

/// ኢሚት በየጊዜው ውድቅ ያደርጋል
enum RejectAndMatch {}

impl TwoWayStrategy for RejectAndMatch {
    type Output = SearchStep;

    #[inline]
    fn use_early_reject() -> bool {
        true
    }
    #[inline]
    fn rejecting(a: usize, b: usize) -> Self::Output {
        SearchStep::Reject(a, b)
    }
    #[inline]
    fn matching(a: usize, b: usize) -> Self::Output {
        SearchStep::Match(a, b)
    }
}