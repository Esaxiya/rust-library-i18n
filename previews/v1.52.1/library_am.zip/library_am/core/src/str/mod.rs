//! ገመድ ማጭበርበር.
//!
//! ለተጨማሪ ዝርዝሮች የ [`std::str`] ሞጁሉን ይመልከቱ ፡፡
//!
//! [`std::str`]: ../../std/str/index.html

#![stable(feature = "rust1", since = "1.0.0")]

mod converts;
mod error;
mod iter;
mod traits;
mod validations;

use self::pattern::Pattern;
use self::pattern::{DoubleEndedSearcher, ReverseSearcher, Searcher};

use crate::char;
use crate::mem;
use crate::slice::{self, SliceIndex};

pub mod pattern;

#[unstable(feature = "str_internals", issue = "none")]
#[allow(missing_docs)]
pub mod lossy;

#[stable(feature = "rust1", since = "1.0.0")]
pub use converts::{from_utf8, from_utf8_unchecked};

#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub use converts::{from_utf8_mut, from_utf8_unchecked_mut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use error::{ParseBoolError, Utf8Error};

#[stable(feature = "rust1", since = "1.0.0")]
pub use traits::FromStr;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Bytes, CharIndices, Chars, Lines, SplitWhitespace};

#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated)]
pub use iter::LinesAny;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplit, RSplitTerminator, Split, SplitTerminator};

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplitN, SplitN};

#[stable(feature = "str_matches", since = "1.2.0")]
pub use iter::{Matches, RMatches};

#[stable(feature = "str_match_indices", since = "1.5.0")]
pub use iter::{MatchIndices, RMatchIndices};

#[stable(feature = "encode_utf16", since = "1.8.0")]
pub use iter::EncodeUtf16;

#[stable(feature = "str_escape", since = "1.34.0")]
pub use iter::{EscapeDebug, EscapeDefault, EscapeUnicode};

#[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
pub use iter::SplitAsciiWhitespace;

#[stable(feature = "split_inclusive", since = "1.51.0")]
pub use iter::SplitInclusive;

#[unstable(feature = "str_internals", issue = "none")]
pub use validations::next_code_point;

use iter::MatchIndicesInternal;
use iter::SplitInternal;
use iter::{MatchesInternal, SplitNInternal};

use validations::truncate_to_char_boundary;

#[inline(never)]
#[cold]
#[track_caller]
fn slice_error_fail(s: &str, begin: usize, end: usize) -> ! {
    const MAX_DISPLAY_LENGTH: usize = 256;
    let (truncated, s_trunc) = truncate_to_char_boundary(s, MAX_DISPLAY_LENGTH);
    let ellipsis = if truncated { "[...]" } else { "" };

    // 1. ከክልሎች ውጭ
    if begin > s.len() || end > s.len() {
        let oob_index = if begin > s.len() { begin } else { end };
        panic!("byte index {} is out of bounds of `{}`{}", oob_index, s_trunc, ellipsis);
    }

    // 2. ጀምር <=end
    assert!(
        begin <= end,
        "begin <= end ({} <= {}) when slicing `{}`{}",
        begin,
        end,
        s_trunc,
        ellipsis
    );

    // 3. የባህርይ ወሰን
    let index = if !s.is_char_boundary(begin) { begin } else { end };
    // ቁምፊውን ያግኙ
    let mut char_start = index;
    while !s.is_char_boundary(char_start) {
        char_start -= 1;
    }
    // `char_start` ከብድር እና ከቻር ወሰን ያነሰ መሆን አለበት
    let ch = s[char_start..].chars().next().unwrap();
    let char_range = char_start..char_start + ch.len_utf8();
    panic!(
        "byte index {} is not a char boundary; it is inside {:?} (bytes {:?}) of `{}`{}",
        index, ch, char_range, s_trunc, ellipsis
    );
}

#[lang = "str"]
#[cfg(not(test))]
impl str {
    /// የ `self` ርዝመት ይመልሳል።
    ///
    /// ይህ ርዝመት በ [`ቻር`] ወይም በግራፊክ ቃላት ሳይሆን በባይቶች ነው።
    /// በሌላ አገላለጽ የሰው ልጅ የሕብረቁምፊውን ርዝመት የሚመለከተው ላይሆን ይችላል ፡፡
    ///
    /// [`char`]: prim@char
    ///
    /// # Examples
    ///
    /// መሠረታዊ አጠቃቀም
    ///
    /// ```
    /// let len = "foo".len();
    /// assert_eq!(3, len);
    ///
    /// assert_eq!("ƒoo".len(), 4); // የጌጥ f!
    /// assert_eq!("ƒoo".chars().count(), 3);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_str_len", since = "1.32.0")]
    #[inline]
    pub const fn len(&self) -> usize {
        self.as_bytes().len()
    }

    /// `self` የዜሮ ባይት ርዝመት ካለው `true` ን ይመልሳል።
    ///
    /// # Examples
    ///
    /// መሠረታዊ አጠቃቀም
    ///
    /// ```
    /// let s = "";
    /// assert!(s.is_empty());
    ///
    /// let s = "not empty";
    /// assert!(!s.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_str_is_empty", since = "1.32.0")]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// የ‹ኢንዴክስ›ኛ ባይት በ‹XXXX›ኮድ ቅደም ተከተል ወይም የሕብረቁምፊው መጨረሻ የመጀመሪያው ባይት ነው ፡፡
    ///
    ///
    /// የሕብረቁምፊው መጀመሪያ እና መጨረሻ (መቼ `ማውጫ== self.len()`) እንደ ወሰኖች ተቆጥረዋል)።
    ///
    /// `index` ከ `self.len()` የበለጠ ከሆነ `false` ን ይመልሳል።
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// assert!(s.is_char_boundary(0));
    /// // የ `老` መጀመሪያ
    /// assert!(s.is_char_boundary(6));
    /// assert!(s.is_char_boundary(s.len()));
    ///
    /// // የ `ö` ሁለተኛ ባይት
    /// assert!(!s.is_char_boundary(2));
    ///
    /// // ሦስተኛው የ `老` ባይት
    /// assert!(!s.is_char_boundary(8));
    /// ```
    ///
    #[stable(feature = "is_char_boundary", since = "1.9.0")]
    #[inline]
    pub fn is_char_boundary(&self, index: usize) -> bool {
        // 0 እና ብድር ሁልጊዜ ጥሩ ናቸው።
        // ቼኩን በቀላሉ ለማመቻቸት እና ለዚያ ጉዳይ የንባብ ውሂብን ለመዝለል እንዲችል በግልፅ ለ 0 ይሞክሩት ፡፡
        //
        if index == 0 || index == self.len() {
            return true;
        }
        match self.as_bytes().get(index) {
            None => false,
            // ይህ ቢት አስማት ነው ከ: b <128 ||ለ>=192
            Some(&b) => (b as i8) >= -0x40,
        }
    }

    /// የሕብረቁምፊ ቁራጭ ወደ ባይት ቁርጥራጭ ይቀይረዋል።
    /// የባይት ቁራጭን እንደገና ወደ ህብረቁምፊ ቁራጭ ለመለወጥ የ [`from_utf8`] ተግባርን ይጠቀሙ።
    ///
    /// # Examples
    ///
    /// መሠረታዊ አጠቃቀም
    ///
    /// ```
    /// let bytes = "bors".as_bytes();
    /// assert_eq!(b"bors", bytes);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "str_as_bytes", since = "1.32.0")]
    #[inline(always)]
    #[allow(unused_attributes)]
    #[rustc_allow_const_fn_unstable(const_fn_transmute)]
    pub const fn as_bytes(&self) -> &[u8] {
        // ደህንነት ሁለት ዓይነቶችን በአንድ ዓይነት አቀማመጥ ስለምንለውጥ ድምፃችን ይሰማ ነው
        unsafe { mem::transmute(self) }
    }

    /// የሚለዋወጥ የሕብረቁምፊን ቁርጥራጭ ወደ ሚቀየረው የባይት ቁርጥራጭ ይቀይረዋል።
    ///
    /// # Safety
    ///
    /// ተበዳሪው የብድሩ መጠን ከማለቁ እና መሠረታዊው `str` ጥቅም ላይ ከመዋሉ በፊት የተከፋፈለው ይዘት UTF-8 ትክክለኛ መሆኑን ማረጋገጥ አለበት ፡፡
    ///
    ///
    /// ይዘቱ ልክ ያልሆነ UTF-8 ያልሆነ የ `str` አጠቃቀም ያልተገለጸ ባህሪ ነው።
    ///
    /// # Examples
    ///
    /// መሠረታዊ አጠቃቀም
    ///
    /// ```
    /// let mut s = String::from("Hello");
    /// let bytes = unsafe { s.as_bytes_mut() };
    ///
    /// assert_eq!(b"Hello", bytes);
    /// ```
    ///
    /// Mutability:
    ///
    /// ```
    /// let mut s = String::from("🗻∈🌏");
    ///
    /// unsafe {
    ///     let bytes = s.as_bytes_mut();
    ///
    ///     bytes[0] = 0xF0;
    ///     bytes[1] = 0x9F;
    ///     bytes[2] = 0x8D;
    ///     bytes[3] = 0x94;
    /// }
    ///
    /// assert_eq!("🍔∈🌏", s);
    /// ```
    #[stable(feature = "str_mut_extras", since = "1.20.0")]
    #[inline(always)]
    pub unsafe fn as_bytes_mut(&mut self) -> &mut [u8] {
        // ደህንነት-ከ `&str` እስከ `&[u8]` ያለው ተዋንያን ከ `str` ጀምሮ ደህንነቱ የተጠበቀ ነው
        // እንደ `&[u8]` ተመሳሳይ አቀማመጥ አለው (ይህንን ዋስትና ሊሰጥ የሚችለው ሊብስተድ ብቻ ነው)።
        // የጠቋሚው መዛግብት የሚመጣው ከሚለዋወጥ ማጣቀሻ የመጣ ስለሆነ ለጽሑፍ ትክክለኛ መሆኑ የተረጋገጠ ነው ፡፡
        //
        unsafe { &mut *(self as *mut str as *mut [u8]) }
    }

    /// የሕብረቁምፊን ቁራጭ ወደ ጥሬ ጠቋሚ ይለውጣል።
    ///
    /// የሕብረቁምፊ ቁርጥራጭ ቁርጥራጭ ባይት እንደመሆናቸው ጥሬው ጠቋሚው ወደ [`u8`] ይጠቁማል ፡፡
    /// ይህ ጠቋሚ ወደ መጀመሪያው የሕብረቁምፊ ቁራጭ ይጠቁማል።
    ///
    /// ደዋዩ የተመለሰው ጠቋሚ በጭራሽ እንዳልተጻፈ ማረጋገጥ አለበት ፡፡
    /// የሕብረቁምፊውን ቁርጥራጭ ይዘት መለወጥ ከፈለጉ ፣ [`as_mut_ptr`] ን ይጠቀሙ።
    ///
    ///
    /// [`as_mut_ptr`]: str::as_mut_ptr
    ///
    /// # Examples
    ///
    /// መሠረታዊ አጠቃቀም
    ///
    /// ```
    /// let s = "Hello";
    /// let ptr = s.as_ptr();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "rustc_str_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(&self) -> *const u8 {
        self as *const str as *const u8
    }

    /// የሚለዋወጥ ሕብረቁምፊን ወደ ጥሬ ጠቋሚ ይቀይራል።
    ///
    /// የሕብረቁምፊ ቁርጥራጭ ቁርጥራጭ ባይት እንደመሆናቸው ጥሬው ጠቋሚው ወደ [`u8`] ይጠቁማል ፡፡
    /// ይህ ጠቋሚ ወደ መጀመሪያው የሕብረቁምፊ ቁራጭ ይጠቁማል።
    ///
    /// የሕብረቁምፊው ቁርጥራጭ ልክ UTF-8 ሆኖ በሚቆይበት መንገድ ብቻ እንዲሻሻል መደረጉ የእርስዎ ኃላፊነት ነው።
    ///
    ///
    #[stable(feature = "str_as_mut_ptr", since = "1.36.0")]
    #[inline]
    pub fn as_mut_ptr(&mut self) -> *mut u8 {
        self as *mut str as *mut u8
    }

    /// የ `str` ንዑስ ክፍልን ይመልሳል።
    ///
    /// ይህ `str` ን ለመጥቀስ የማይደነግጥ አማራጭ ነው ፡፡
    /// ተመጣጣኝ የማውጫ ሥራ panic በሚሆንበት ጊዜ [`None`] ን ይመልሳል።
    ///
    /// # Examples
    ///
    /// ```
    /// let v = String::from("🗻∈🌏");
    ///
    /// assert_eq!(Some("🗻"), v.get(0..4));
    ///
    /// // በ UTF-8 ቅደም ተከተል ወሰኖች ላይ ያልሆኑ ማውጫዎች
    /// assert!(v.get(1..).is_none());
    /// assert!(v.get(..8).is_none());
    ///
    /// // ከክልሎች ውጭ
    /// assert!(v.get(..42).is_none());
    /// ```
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub fn get<I: SliceIndex<str>>(&self, i: I) -> Option<&I::Output> {
        i.get(self)
    }

    /// የሚለዋወጥ የ `str` ንዑስ ክፍልን ይመልሳል።
    ///
    /// ይህ `str` ን ለመጥቀስ የማይደነግጥ አማራጭ ነው ፡፡
    /// ተመጣጣኝ የማውጫ ሥራ panic በሚሆንበት ጊዜ [`None`] ን ይመልሳል።
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = String::from("hello");
    /// // ትክክለኛ ርዝመት
    /// assert!(v.get_mut(0..5).is_some());
    /// // ከክልሎች ውጭ
    /// assert!(v.get_mut(..42).is_none());
    /// assert_eq!(Some("he"), v.get_mut(0..2).map(|v| &*v));
    ///
    /// assert_eq!("hello", v);
    /// {
    ///     let s = v.get_mut(0..2);
    ///     let s = s.map(|s| {
    ///         s.make_ascii_uppercase();
    ///         &*s
    ///     });
    ///     assert_eq!(Some("HE"), s);
    /// }
    /// assert_eq!("HEllo", v);
    /// ```
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub fn get_mut<I: SliceIndex<str>>(&mut self, i: I) -> Option<&mut I::Output> {
        i.get_mut(self)
    }

    /// ያልተፈተሸ የ `str` ንዑስ ክፍል ይመልሳል።
    ///
    /// የ `str` ን መረጃ ጠቋሚ ለማድረግ ይህ ያልተመረመረ አማራጭ ነው ፡፡
    ///
    /// # Safety
    ///
    /// የዚህ ተግባር ጠሪዎች እነዚህ ቅድመ-ሁኔታዎች እርካታ የማግኘት ኃላፊነት አለባቸው-
    ///
    /// * የመነሻ ኢንዴክስ ከማብቂያ ኢንዴክስ መብለጥ የለበትም;
    /// * ማውጫዎች ከመጀመሪያው ቁርጥራጭ ወሰን ውስጥ መሆን አለባቸው ፣
    /// * ማውጫዎች በ UTF-8 ቅደም ተከተል ወሰኖች ላይ መዋሸት አለባቸው።
    ///
    /// ይህ ካልሆነ ግን የተመለሰው የሕብረቁምፊ ቁራጭ ልክ ያልሆነ ማህደረ ትውስታን ሊያመለክት ወይም በ `str` ዓይነት የተላለፉትን የማይለወጡትን ሊጥስ ይችላል።
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let v = "🗻∈🌏";
    /// unsafe {
    ///     assert_eq!("🗻", v.get_unchecked(0..4));
    ///     assert_eq!("∈", v.get_unchecked(4..7));
    ///     assert_eq!("🌏", v.get_unchecked(7..11));
    /// }
    /// ```
    ///
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub unsafe fn get_unchecked<I: SliceIndex<str>>(&self, i: I) -> &I::Output {
        // ደህንነት: ደዋዩ ለ `get_unchecked` የደህንነትን ውል ማክበር አለበት;
        // ኤክስኤክስኤክስ ደህንነቱ የተጠበቀ ማጣቀሻ ስለሆነ ቁራጩ ሊተላለፍ ይችላል ፡፡
        // የተመለሰው ጠቋሚ ደህንነቱ የተጠበቀ ነው ምክንያቱም የ `SliceIndex` ግኝቶች እሱ መሆኑን ማረጋገጥ አለባቸው።
        unsafe { &*i.get_unchecked(self) }
    }

    /// የሚለዋወጥ ፣ ያልተመረመረ የ `str` ንዑስ ክፍልን ይመልሳል።
    ///
    /// የ `str` ን መረጃ ጠቋሚ ለማድረግ ይህ ያልተመረመረ አማራጭ ነው ፡፡
    ///
    /// # Safety
    ///
    /// የዚህ ተግባር ጠሪዎች እነዚህ ቅድመ-ሁኔታዎች እርካታ የማግኘት ኃላፊነት አለባቸው-
    ///
    /// * የመነሻ ኢንዴክስ ከማብቂያ ኢንዴክስ መብለጥ የለበትም;
    /// * ማውጫዎች ከመጀመሪያው ቁርጥራጭ ወሰን ውስጥ መሆን አለባቸው ፣
    /// * ማውጫዎች በ UTF-8 ቅደም ተከተል ወሰኖች ላይ መዋሸት አለባቸው።
    ///
    /// ይህ ካልሆነ ግን የተመለሰው የሕብረቁምፊ ቁራጭ ልክ ያልሆነ ማህደረ ትውስታን ሊያመለክት ወይም በ `str` ዓይነት የተላለፉትን የማይለወጡትን ሊጥስ ይችላል።
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = String::from("🗻∈🌏");
    /// unsafe {
    ///     assert_eq!("🗻", v.get_unchecked_mut(0..4));
    ///     assert_eq!("∈", v.get_unchecked_mut(4..7));
    ///     assert_eq!("🌏", v.get_unchecked_mut(7..11));
    /// }
    /// ```
    ///
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I: SliceIndex<str>>(&mut self, i: I) -> &mut I::Output {
        // ደህንነት: ደዋዩ ለ `get_unchecked_mut` የደህንነትን ውል ማክበር አለበት;
        // ኤክስኤክስኤክስ ደህንነቱ የተጠበቀ ማጣቀሻ ስለሆነ ቁራጩ ሊተላለፍ ይችላል ፡፡
        // የተመለሰው ጠቋሚ ደህንነቱ የተጠበቀ ነው ምክንያቱም የ `SliceIndex` ግኝቶች እሱ መሆኑን ማረጋገጥ አለባቸው።
        unsafe { &mut *i.get_unchecked_mut(self) }
    }

    /// የደህንነት ፍተሻዎችን በማለፍ ከሌላ የሕብረቁምፊ ቁራጭ የሕብረቁምፊ ቁርጥራጭ ይፈጥራል።
    ///
    /// ይህ በአጠቃላይ አይመከርም ፣ በጥንቃቄ ይጠቀሙ!ለደህንነት አማራጭ [`str`] እና [`Index`] ን ይመልከቱ ፡፡
    ///
    ///
    /// [`Index`]: crate::ops::Index
    ///
    /// ይህ አዲስ ቁራጭ `begin` ን ጨምሮ `end` ን ሳይጨምር ከ `begin` ወደ `end` ይሄዳል ፡፡
    ///
    /// በምትኩ የሚለዋወጥ የሕብረቁምፊ ቁራጭ ለማግኘት የ [`slice_mut_unchecked`] ዘዴን ይመልከቱ።
    ///
    /// [`slice_mut_unchecked`]: str::slice_mut_unchecked
    ///
    /// # Safety
    ///
    /// የዚህ ተግባር ጠሪዎች ሶስት ቅድመ-ሁኔታዎች እንዲሟሉ ተጠያቂ ናቸው-
    ///
    /// * `begin` ከ `end` መብለጥ የለበትም።
    /// * `begin` እና `end` በሕብረቁምፊው ክፍል ውስጥ ባይት ቦታዎች መሆን አለባቸው።
    /// * `begin` እና `end` በ UTF-8 ቅደም ተከተል ወሰኖች ላይ መዋሸት አለበት።
    ///
    /// # Examples
    ///
    /// መሠረታዊ አጠቃቀም
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// unsafe {
    ///     assert_eq!("Löwe 老虎 Léopard", s.slice_unchecked(0, 21));
    /// }
    ///
    /// let s = "Hello, world!";
    ///
    /// unsafe {
    ///     assert_eq!("world", s.slice_unchecked(7, 12));
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.29.0", reason = "use `get_unchecked(begin..end)` instead")]
    #[inline]
    pub unsafe fn slice_unchecked(&self, begin: usize, end: usize) -> &str {
        // ደህንነት: ደዋዩ ለ `get_unchecked` የደህንነትን ውል ማክበር አለበት;
        // ኤክስኤክስኤክስ ደህንነቱ የተጠበቀ ማጣቀሻ ስለሆነ ቁራጩ ሊተላለፍ ይችላል ፡፡
        // የተመለሰው ጠቋሚ ደህንነቱ የተጠበቀ ነው ምክንያቱም የ `SliceIndex` ግኝቶች እሱ መሆኑን ማረጋገጥ አለባቸው።
        unsafe { &*(begin..end).get_unchecked(self) }
    }

    /// የደህንነት ፍተሻዎችን በማለፍ ከሌላ የሕብረቁምፊ ቁራጭ የሕብረቁምፊ ቁርጥራጭ ይፈጥራል።
    /// ይህ በአጠቃላይ አይመከርም ፣ በጥንቃቄ ይጠቀሙ!ለደህንነት አማራጭ [`str`] እና [`IndexMut`] ን ይመልከቱ ፡፡
    ///
    ///
    /// [`IndexMut`]: crate::ops::IndexMut
    ///
    /// ይህ አዲስ ቁራጭ `begin` ን ጨምሮ `end` ን ሳይጨምር ከ `begin` ወደ `end` ይሄዳል ፡፡
    ///
    /// በምትኩ የማይለወጥ የሕብረቁምፊ ቁራጭ ለማግኘት የ [`slice_unchecked`] ዘዴን ይመልከቱ።
    ///
    /// [`slice_unchecked`]: str::slice_unchecked
    ///
    /// # Safety
    ///
    /// የዚህ ተግባር ጠሪዎች ሶስት ቅድመ-ሁኔታዎች እንዲሟሉ ተጠያቂ ናቸው-
    ///
    /// * `begin` ከ `end` መብለጥ የለበትም።
    /// * `begin` እና `end` በሕብረቁምፊው ክፍል ውስጥ ባይት ቦታዎች መሆን አለባቸው።
    /// * `begin` እና `end` በ UTF-8 ቅደም ተከተል ወሰኖች ላይ መዋሸት አለበት።
    ///
    ///
    ///
    ///
    #[stable(feature = "str_slice_mut", since = "1.5.0")]
    #[rustc_deprecated(since = "1.29.0", reason = "use `get_unchecked_mut(begin..end)` instead")]
    #[inline]
    pub unsafe fn slice_mut_unchecked(&mut self, begin: usize, end: usize) -> &mut str {
        // ደህንነት: ደዋዩ ለ `get_unchecked_mut` የደህንነትን ውል ማክበር አለበት;
        // ኤክስኤክስኤክስ ደህንነቱ የተጠበቀ ማጣቀሻ ስለሆነ ቁራጩ ሊተላለፍ ይችላል ፡፡
        // የተመለሰው ጠቋሚ ደህንነቱ የተጠበቀ ነው ምክንያቱም የ `SliceIndex` ግኝቶች እሱ መሆኑን ማረጋገጥ አለባቸው።
        unsafe { &mut *(begin..end).get_unchecked_mut(self) }
    }

    /// በመረጃ ጠቋሚ አንድ የክርን ቁራጭ ለሁለት ይከፍሉ ፡፡
    ///
    /// ክርክሩ ፣ `mid` ፣ ከህብረቁምፊው ጅምር አንድ ባይት ማካካሻ መሆን አለበት።
    /// እንዲሁም በ UTF-8 ኮድ ነጥብ ወሰን ላይ መሆን አለበት።
    ///
    /// የተመለሱት ሁለቱ ቁርጥራጮች ከህብረቁምፊው ጅምር ጅምር ወደ `mid` እና ከ `mid` እስከ ህብረቁምፊው መጨረሻ ድረስ ይሄዳሉ ፡፡
    ///
    /// በምትኩ የሚለዋወጥ የሕብረቁምፊ ቁርጥራጮችን ለማግኘት የ [`split_at_mut`] ዘዴን ይመልከቱ።
    ///
    /// [`split_at_mut`]: str::split_at_mut
    ///
    /// # Panics
    ///
    /// 0Panics `mid` በ UTF-8 ኮድ ነጥብ ወሰን ላይ ካልሆነ ወይም የሕብረቁምፊውን የመጨረሻውን የኮድ ነጥብ መጨረሻ ካለፈ።
    ///
    ///
    /// # Examples
    ///
    /// መሠረታዊ አጠቃቀም
    ///
    /// ```
    /// let s = "Per Martin-Löf";
    ///
    /// let (first, last) = s.split_at(3);
    ///
    /// assert_eq!("Per", first);
    /// assert_eq!(" Martin-Löf", last);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "str_split_at", since = "1.4.0")]
    pub fn split_at(&self, mid: usize) -> (&str, &str) {
        // መረጃ ጠቋሚው በ [0 ፣ .len()]
        if self.is_char_boundary(mid) {
            // ደህንነት:-`mid` በቻር ወሰን ላይ መሆኑን አሁን አረጋግጧል።
            unsafe { (self.get_unchecked(0..mid), self.get_unchecked(mid..self.len())) }
        } else {
            slice_error_fail(self, 0, mid)
        }
    }

    /// በመረጃ ጠቋሚ አንድ የሚለዋወጥ የሕብረቁምፊ ቁራጭ ለሁለት ይከፍሉ ፡፡
    ///
    /// ክርክሩ ፣ `mid` ፣ ከህብረቁምፊው ጅምር አንድ ባይት ማካካሻ መሆን አለበት።
    /// እንዲሁም በ UTF-8 ኮድ ነጥብ ወሰን ላይ መሆን አለበት።
    ///
    /// የተመለሱት ሁለቱ ቁርጥራጮች ከህብረቁምፊው ጅምር ጅምር ወደ `mid` እና ከ `mid` እስከ ህብረቁምፊው መጨረሻ ድረስ ይሄዳሉ ፡፡
    ///
    /// በምትኩ የማይለዋወጥ የሕብረቁምፊ ቁርጥራጮችን ለማግኘት የ [`split_at`] ዘዴን ይመልከቱ።
    ///
    /// [`split_at`]: str::split_at
    ///
    /// # Panics
    ///
    /// 0Panics `mid` በ UTF-8 ኮድ ነጥብ ወሰን ላይ ካልሆነ ወይም የሕብረቁምፊውን የመጨረሻውን የኮድ ነጥብ መጨረሻ ካለፈ።
    ///
    ///
    /// # Examples
    ///
    /// መሠረታዊ አጠቃቀም
    ///
    /// ```
    /// let mut s = "Per Martin-Löf".to_string();
    /// {
    ///     let (first, last) = s.split_at_mut(3);
    ///     first.make_ascii_uppercase();
    ///     assert_eq!("PER", first);
    ///     assert_eq!(" Martin-Löf", last);
    /// }
    /// assert_eq!("PER Martin-Löf", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "str_split_at", since = "1.4.0")]
    pub fn split_at_mut(&mut self, mid: usize) -> (&mut str, &mut str) {
        // መረጃ ጠቋሚው በ [0 ፣ .len()]
        if self.is_char_boundary(mid) {
            let len = self.len();
            let ptr = self.as_mut_ptr();
            // ደህንነት:-`mid` በቻር ወሰን ላይ መሆኑን አሁን አረጋግጧል።
            unsafe {
                (
                    from_utf8_unchecked_mut(slice::from_raw_parts_mut(ptr, mid)),
                    from_utf8_unchecked_mut(slice::from_raw_parts_mut(ptr.add(mid), len - mid)),
                )
            }
        } else {
            slice_error_fail(self, 0, mid)
        }
    }

    /// በሕብረቁምፊ ቁራጭ [`ቻር`] s ላይ አንድ ተደጋጋሚ ይመልሳል።
    ///
    /// የሕብረቁምፊ ቁራጭ ትክክለኛ UTF-8 ን እንደያዘ ፣ በ [`char`] በኩል ባለው የሕብረቁምፊ ቁርጥራጭ አማካይነት ማመዛዘን እንችላለን።
    /// ይህ ዘዴ እንዲህ ዓይነቱን ተደጋጋሚ መልስ ይሰጣል ፡፡
    ///
    /// [`char`] የዩኒኮድ ስካላር ዋጋን እንደሚወክል ማስታወሱ በጣም አስፈላጊ ነው ፣ እና 'character' ምን እንደሆነ ከሚለው ሀሳብዎ ጋር ላይጣጣም ይችላል ፡፡
    ///
    /// በግራፊም ስብስቦች ላይ ብስጭት በእውነቱ የሚፈልጉት ሊሆን ይችላል ፡፡
    /// ይህ ተግባር በ Rust መደበኛ ቤተ-መጽሐፍት አልተሰጠም ፣ ይልቁንስ crates.io ን ይፈትሹ።
    ///
    /// # Examples
    ///
    /// መሠረታዊ አጠቃቀም
    ///
    /// ```
    /// let word = "goodbye";
    ///
    /// let count = word.chars().count();
    /// assert_eq!(7, count);
    ///
    /// let mut chars = word.chars();
    ///
    /// assert_eq!(Some('g'), chars.next());
    /// assert_eq!(Some('o'), chars.next());
    /// assert_eq!(Some('o'), chars.next());
    /// assert_eq!(Some('d'), chars.next());
    /// assert_eq!(Some('b'), chars.next());
    /// assert_eq!(Some('y'), chars.next());
    /// assert_eq!(Some('e'), chars.next());
    ///
    /// assert_eq!(None, chars.next());
    /// ```
    ///
    /// ያስታውሱ ፣ [`ቻር`] ስለ ገጸ-ባህሪያት ካለው ግንዛቤ ጋር ላይመሳሰል ይችላል-
    ///
    /// [`char`]: prim@char
    ///
    /// ```
    /// let y = "y̆";
    ///
    /// let mut chars = y.chars();
    ///
    /// assert_eq!(Some('y'), chars.next()); // 'y̆' አይደለም
    /// assert_eq!(Some('\u{0306}'), chars.next());
    ///
    /// assert_eq!(None, chars.next());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chars(&self) -> Chars<'_> {
        Chars { iter: self.as_bytes().iter() }
    }

    /// በሕብረቁምፊ ቁራጭ [`ቻር` ላይ አንድ ተደጋጋሚ እና ቦታቸውን ይመልሳል።
    ///
    /// የሕብረቁምፊ ቁራጭ ትክክለኛ UTF-8 ን እንደያዘ ፣ በ [`char`] በኩል ባለው የሕብረቁምፊ ቁርጥራጭ አማካይነት ማመዛዘን እንችላለን።
    /// ይህ ዘዴ የሁለቱም [`ቻር`] ደጋፊዎች እንዲሁም የባይቶቻቸው አቀማመጥ ይመልሳል።
    ///
    /// ተደጋጋሚው ጣውላዎችን ይሰጣል ፡፡ቦታው መጀመሪያ ነው ፣ [`char`] ሁለተኛ ነው።
    ///
    /// # Examples
    ///
    /// መሠረታዊ አጠቃቀም
    ///
    /// ```
    /// let word = "goodbye";
    ///
    /// let count = word.char_indices().count();
    /// assert_eq!(7, count);
    ///
    /// let mut char_indices = word.char_indices();
    ///
    /// assert_eq!(Some((0, 'g')), char_indices.next());
    /// assert_eq!(Some((1, 'o')), char_indices.next());
    /// assert_eq!(Some((2, 'o')), char_indices.next());
    /// assert_eq!(Some((3, 'd')), char_indices.next());
    /// assert_eq!(Some((4, 'b')), char_indices.next());
    /// assert_eq!(Some((5, 'y')), char_indices.next());
    /// assert_eq!(Some((6, 'e')), char_indices.next());
    ///
    /// assert_eq!(None, char_indices.next());
    /// ```
    ///
    /// ያስታውሱ ፣ [`ቻር`] ስለ ገጸ-ባህሪያት ካለው ግንዛቤ ጋር ላይመሳሰል ይችላል-
    ///
    /// [`char`]: prim@char
    ///
    /// ```
    /// let yes = "y̆es";
    ///
    /// let mut char_indices = yes.char_indices();
    ///
    /// assert_eq!(Some((0, 'y')), char_indices.next()); // አይደለም (0 ፣ 'y̆')
    /// assert_eq!(Some((1, '\u{0306}')), char_indices.next());
    ///
    /// // እዚህ 3 ቱን ልብ ይበሉ ፣ የመጨረሻው ቁምፊ ሁለት ባይት ወሰደ
    /// assert_eq!(Some((3, 'e')), char_indices.next());
    /// assert_eq!(Some((4, 's')), char_indices.next());
    ///
    /// assert_eq!(None, char_indices.next());
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn char_indices(&self) -> CharIndices<'_> {
        CharIndices { front_offset: 0, iter: self.chars() }
    }

    /// በሕብረቁምፊ ቁራጭ ባይት ላይ አንድ ተደጋጋሚ።
    ///
    /// የሕብረቁምፊ ቁራጭ ቅደም-ተከተል ባይት ያካተተ እንደመሆኑ መጠን ፣ በ‹ባይት›በኩል በ‹ባይት›አማካይነት ማመጣጠን እንችላለን ፡፡
    /// ይህ ዘዴ እንዲህ ዓይነቱን ተደጋጋሚ መልስ ይሰጣል ፡፡
    ///
    /// # Examples
    ///
    /// መሠረታዊ አጠቃቀም
    ///
    /// ```
    /// let mut bytes = "bors".bytes();
    ///
    /// assert_eq!(Some(b'b'), bytes.next());
    /// assert_eq!(Some(b'o'), bytes.next());
    /// assert_eq!(Some(b'r'), bytes.next());
    /// assert_eq!(Some(b's'), bytes.next());
    ///
    /// assert_eq!(None, bytes.next());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn bytes(&self) -> Bytes<'_> {
        Bytes(self.as_bytes().iter().copied())
    }

    /// በነጭ ቦታ አንድ የሕብረቁምፊ ቁርጥራጭ ይከፍላል።
    ///
    /// የተመለሰው ተንታኝ በማንኛውም የነጭ ቦታ መጠን የተለዩትን የመጀመሪያውን የሕብረቁምፊ ቁርጥራጭ ንዑስ-ቁራጭ የሆኑትን የሕብረ-ቁራጮችን ይመልሳል።
    ///
    ///
    /// 'Whitespace' በዩኒኮድ በተገኘው መሠረታዊ ንብረት `White_Space` ውሎች መሠረት ይገለጻል ፡፡
    /// በምትኩ በ ASCII በነጮች ላይ ብቻ ለመከፋፈል ከፈለጉ [`split_ascii_whitespace`] ን ይጠቀሙ።
    ///
    /// [`split_ascii_whitespace`]: str::split_ascii_whitespace
    ///
    /// # Examples
    ///
    /// መሠረታዊ አጠቃቀም
    ///
    /// ```
    /// let mut iter = "A few words".split_whitespace();
    ///
    /// assert_eq!(Some("A"), iter.next());
    /// assert_eq!(Some("few"), iter.next());
    /// assert_eq!(Some("words"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    /// ሁሉም ዓይነት የነጭ ክልል ይታሰባል
    ///
    /// ```
    /// let mut iter = " Mary   had\ta\u{2009}little  \n\t lamb".split_whitespace();
    /// assert_eq!(Some("Mary"), iter.next());
    /// assert_eq!(Some("had"), iter.next());
    /// assert_eq!(Some("a"), iter.next());
    /// assert_eq!(Some("little"), iter.next());
    /// assert_eq!(Some("lamb"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[stable(feature = "split_whitespace", since = "1.1.0")]
    #[inline]
    pub fn split_whitespace(&self) -> SplitWhitespace<'_> {
        SplitWhitespace { inner: self.split(IsWhitespace).filter(IsNotEmpty) }
    }

    /// በ ASCII የነጭ ቦታ አንድ የሕብረቁምፊ ቁርጥራጭ ይከፍላል።
    ///
    /// የተመለሰው ተንታኝ በማንኛውም የ ASCII የነፃ ቦታ መጠን የተለዩትን የመጀመሪያውን የሕብረቁምፊ ቁርጥራጭ ንዑስ-ቁራጭ የሆኑትን የሕብረ-ቁስ ቁርጥራጮችን ይመልሳል።
    ///
    ///
    /// በምትኩ በዩኒኮድ `Whitespace` ለመከፋፈል [`split_whitespace`] ን ይጠቀሙ።
    ///
    /// [`split_whitespace`]: str::split_whitespace
    ///
    /// # Examples
    ///
    /// መሠረታዊ አጠቃቀም
    ///
    /// ```
    /// let mut iter = "A few words".split_ascii_whitespace();
    ///
    /// assert_eq!(Some("A"), iter.next());
    /// assert_eq!(Some("few"), iter.next());
    /// assert_eq!(Some("words"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    /// ሁሉም ዓይነቶች ASCII የነፃነት ቦታ እንደታሰበው-
    ///
    /// ```
    /// let mut iter = " Mary   had\ta little  \n\t lamb".split_ascii_whitespace();
    /// assert_eq!(Some("Mary"), iter.next());
    /// assert_eq!(Some("had"), iter.next());
    /// assert_eq!(Some("a"), iter.next());
    /// assert_eq!(Some("little"), iter.next());
    /// assert_eq!(Some("lamb"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    #[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
    #[inline]
    pub fn split_ascii_whitespace(&self) -> SplitAsciiWhitespace<'_> {
        let inner =
            self.as_bytes().split(IsAsciiWhitespace).filter(BytesIsNotEmpty).map(UnsafeBytesToStr);
        SplitAsciiWhitespace { inner }
    }

    /// እንደ ክር ሲቆርጡ በሕብረቁምፊ መስመሮች ላይ አንድ ተደጋጋሚ።
    ///
    /// መስመሮች በአዲሱ መስመር (`\n`) ወይም በሠረገላ ተመላሽ መስመር በ‹XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX ጋር በሠረገላ ተመላሽ ይጨርሳሉ ፡፡
    ///
    /// የመጨረሻው መስመር ማለቂያ አማራጭ ነው።
    /// ከመጨረሻው መስመር ማብቂያ ጋር የሚያልቅ አንድ ክር ያለ የመጨረሻ መስመር ማብቂያ ከሌላ ተመሳሳይ ተመሳሳይ ሕብረቁምፊ ጋር ተመሳሳይ መስመሮችን ይመልሳል።
    ///
    ///
    /// # Examples
    ///
    /// መሠረታዊ አጠቃቀም
    ///
    /// ```
    /// let text = "foo\r\nbar\n\nbaz\n";
    /// let mut lines = text.lines();
    ///
    /// assert_eq!(Some("foo"), lines.next());
    /// assert_eq!(Some("bar"), lines.next());
    /// assert_eq!(Some(""), lines.next());
    /// assert_eq!(Some("baz"), lines.next());
    ///
    /// assert_eq!(None, lines.next());
    /// ```
    ///
    /// የመጨረሻው መስመር ማለቂያ አያስፈልግም
    ///
    /// ```
    /// let text = "foo\nbar\n\r\nbaz";
    /// let mut lines = text.lines();
    ///
    /// assert_eq!(Some("foo"), lines.next());
    /// assert_eq!(Some("bar"), lines.next());
    /// assert_eq!(Some(""), lines.next());
    /// assert_eq!(Some("baz"), lines.next());
    ///
    /// assert_eq!(None, lines.next());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn lines(&self) -> Lines<'_> {
        Lines(self.split_terminator('\n').map(LinesAnyMap))
    }

    /// በሕብረቁምፊ መስመሮች ላይ አንድ ተደጋጋሚ።
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.4.0", reason = "use lines() instead now")]
    #[inline]
    #[allow(deprecated)]
    pub fn lines_any(&self) -> LinesAny<'_> {
        LinesAny(self.lines())
    }

    /// እንደ UTF-16 ከተቀየረው ገመድ ላይ የ `u16` ን ተደጋጋሚ ይመልሳል።
    ///
    /// # Examples
    ///
    /// መሠረታዊ አጠቃቀም
    ///
    /// ```
    /// let text = "Zażółć gęślą jaźń";
    ///
    /// let utf8_len = text.len();
    /// let utf16_len = text.encode_utf16().count();
    ///
    /// assert!(utf16_len <= utf8_len);
    /// ```
    #[stable(feature = "encode_utf16", since = "1.8.0")]
    pub fn encode_utf16(&self) -> EncodeUtf16<'_> {
        EncodeUtf16 { chars: self.chars(), extra: 0 }
    }

    /// የተሰጠው ንድፍ ከዚህ ሕብረቁምፊ ቁራጭ ንዑስ-ቁራጭ ጋር የሚዛመድ ከሆነ `true` ን ይመልሳል።
    ///
    /// ካልመለስ `false` ን ይመልሳል።
    ///
    /// [pattern] `&str` ፣ [`char`] ፣ የ ``ቻር`ን ቁራጭ ወይም አንድ ገጸ-ባህሪ የሚዛመድ መሆኑን የሚወስን ተግባር ወይም መዘጋት ሊሆን ይችላል።
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// መሠረታዊ አጠቃቀም
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.contains("nana"));
    /// assert!(!bananas.contains("apples"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn contains<'a, P: Pattern<'a>>(&'a self, pat: P) -> bool {
        pat.is_contained_in(self)
    }

    /// የተሰጠው ንድፍ ከዚህ ሕብረቁምፊ ቁራጭ ቅድመ ቅጥያ ጋር የሚዛመድ ከሆነ `true` ን ይመልሳል።
    ///
    /// ካልመለስ `false` ን ይመልሳል።
    ///
    /// [pattern] `&str` ፣ [`char`] ፣ የ ``ቻር`ን ቁራጭ ወይም አንድ ገጸ-ባህሪ የሚዛመድ መሆኑን የሚወስን ተግባር ወይም መዘጋት ሊሆን ይችላል።
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// መሠረታዊ አጠቃቀም
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.starts_with("bana"));
    /// assert!(!bananas.starts_with("nana"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn starts_with<'a, P: Pattern<'a>>(&'a self, pat: P) -> bool {
        pat.is_prefix_of(self)
    }

    /// የተሰጠው ንድፍ ከዚህ ሕብረቁምፊ ቁራጭ ቅጥያ ጋር የሚዛመድ ከሆነ `true` ን ይመልሳል።
    ///
    /// ካልመለስ `false` ን ይመልሳል።
    ///
    /// [pattern] `&str` ፣ [`char`] ፣ የ ``ቻር`ን ቁራጭ ወይም አንድ ገጸ-ባህሪ የሚዛመድ መሆኑን የሚወስን ተግባር ወይም መዘጋት ሊሆን ይችላል።
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// መሠረታዊ አጠቃቀም
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.ends_with("anas"));
    /// assert!(!bananas.ends_with("nana"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ends_with<'a, P>(&'a self, pat: P) -> bool
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        pat.is_suffix_of(self)
    }

    /// ከስርዓተ-ጥለት ጋር የሚዛመድ የዚህ ሕብረቁምፊ ቁራጭ የመጀመሪያ ቁምፊ ባይት መረጃ ጠቋሚ ይመልሳል።
    ///
    /// ስርዓተ-ጥለት የማይዛመድ ከሆነ [`None`] ን ይመልሳል።
    ///
    /// [pattern] `&str` ፣ [`char`] ፣ የ ``ቻር`ን ቁራጭ ወይም አንድ ገጸ-ባህሪ የሚዛመድ መሆኑን የሚወስን ተግባር ወይም መዘጋት ሊሆን ይችላል።
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ቀላል ቅጦች
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard Gepardi";
    ///
    /// assert_eq!(s.find('L'), Some(0));
    /// assert_eq!(s.find('é'), Some(14));
    /// assert_eq!(s.find("pard"), Some(17));
    /// ```
    ///
    /// ከነጥብ ነፃ ዘይቤን እና መዘጋቶችን በመጠቀም የበለጠ ውስብስብ ቅጦች
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// assert_eq!(s.find(char::is_whitespace), Some(5));
    /// assert_eq!(s.find(char::is_lowercase), Some(1));
    /// assert_eq!(s.find(|c: char| c.is_whitespace() || c.is_lowercase()), Some(1));
    /// assert_eq!(s.find(|c: char| (c < 'o') && (c > 'a')), Some(4));
    /// ```
    ///
    /// ንድፉን አለማግኘት:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// let x: &[_] = &['1', '2'];
    ///
    /// assert_eq!(s.find(x), None);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn find<'a, P: Pattern<'a>>(&'a self, pat: P) -> Option<usize> {
        pat.into_searcher(self).next_match().map(|(i, _)| i)
    }

    /// በዚህ የሕብረቁምፊ ቁራጭ ውስጥ ካለው የንድፍ ትክክለኛው ትክክለኛ ግጥሚያ የመጀመሪያ ቁምፊ የባይት መረጃ ጠቋሚውን ይመልሳል።
    ///
    /// ስርዓተ-ጥለት የማይዛመድ ከሆነ [`None`] ን ይመልሳል።
    ///
    /// [pattern] `&str` ፣ [`char`] ፣ የ ``ቻር`ን ቁራጭ ወይም አንድ ገጸ-ባህሪ የሚዛመድ መሆኑን የሚወስን ተግባር ወይም መዘጋት ሊሆን ይችላል።
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ቀላል ቅጦች
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard Gepardi";
    ///
    /// assert_eq!(s.rfind('L'), Some(13));
    /// assert_eq!(s.rfind('é'), Some(14));
    /// assert_eq!(s.rfind("pard"), Some(24));
    /// ```
    ///
    /// ከመዘጋቶች ጋር የበለጠ ውስብስብ ቅጦች
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// assert_eq!(s.rfind(char::is_whitespace), Some(12));
    /// assert_eq!(s.rfind(char::is_lowercase), Some(20));
    /// ```
    ///
    /// ንድፉን አለማግኘት:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// let x: &[_] = &['1', '2'];
    ///
    /// assert_eq!(s.rfind(x), None);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rfind<'a, P>(&'a self, pat: P) -> Option<usize>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        pat.into_searcher(self).next_match_back().map(|(i, _)| i)
    }

    /// በስርዓተ-ጥለት በተዛመዱ ገጸ-ባህሪዎች የተለዩ የዚህ ሕብረቁምፊ ቁራጭ ንጣፎች ላይ አንድ ተደጋጋሚ።
    ///
    /// [pattern] `&str` ፣ [`char`] ፣ የ ``ቻር`ን ቁራጭ ወይም አንድ ገጸ-ባህሪ የሚዛመድ መሆኑን የሚወስን ተግባር ወይም መዘጋት ሊሆን ይችላል።
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # የኢተራክተር ባህሪ
    ///
    /// ንድፉ የተገላቢጦሽ ፍለጋን የሚፈቅድ እና የ forward/reverse ፍለጋ ተመሳሳይ አባሎችን የሚያመጣ ከሆነ የተመለሰው ተደጋጋሚ [`DoubleEndedIterator`] ይሆናል።
    /// ይህ ለ‹[`char`]›እውነት ነው ፣ ግን ለ‹`&str` X›አይደለም ፡፡
    ///
    /// ንድፉ የተገላቢጦሽ ፍለጋን የሚፈቅድ ከሆነ ግን ውጤቶቹ ከቀጣይ ፍለጋ ሊለዩ ይችላሉ ፣ የ [`rsplit`] ዘዴን መጠቀም ይቻላል።
    ///
    /// [`rsplit`]: str::rsplit
    ///
    /// # Examples
    ///
    /// ቀላል ቅጦች
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".split(' ').collect();
    /// assert_eq!(v, ["Mary", "had", "a", "little", "lamb"]);
    ///
    /// let v: Vec<&str> = "".split('X').collect();
    /// assert_eq!(v, [""]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".split('X').collect();
    /// assert_eq!(v, ["lion", "", "tiger", "leopard"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".split("::").collect();
    /// assert_eq!(v, ["lion", "tiger", "leopard"]);
    ///
    /// let v: Vec<&str> = "abc1def2ghi".split(char::is_numeric).collect();
    /// assert_eq!(v, ["abc", "def", "ghi"]);
    ///
    /// let v: Vec<&str> = "lionXtigerXleopard".split(char::is_uppercase).collect();
    /// assert_eq!(v, ["lion", "tiger", "leopard"]);
    /// ```
    ///
    /// ንድፉ የቁንጮዎች ቁርጥራጭ ከሆነ ፣ በማንኛውም ገጸ-ባህሪ በእያንዳንዱ ክስተት ላይ ይከፋፈሉ-
    ///
    /// ```
    /// let v: Vec<&str> = "2020-11-03 23:59".split(&['-', ' ', ':', '@'][..]).collect();
    /// assert_eq!(v, ["2020", "11", "03", "23", "59"]);
    /// ```
    ///
    /// መዘጋትን በመጠቀም የበለጠ ውስብስብ ንድፍ
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".split(|c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["abc", "def", "ghi"]);
    /// ```
    ///
    /// አንድ ሕብረቁምፊ ብዙ ተጓዳኝ መለያዎችን ከያዘ በውጤቱ ውስጥ ባዶ ማሰሪያዎችን ያገኛሉ
    ///
    /// ```
    /// let x = "||||a||b|c".to_string();
    /// let d: Vec<_> = x.split('|').collect();
    ///
    /// assert_eq!(d, &["", "", "", "", "a", "", "b", "c"]);
    /// ```
    ///
    /// ተጣማጅ መለያዎች በባዶው ገመድ ተለያይተዋል ፡፡
    ///
    /// ```
    /// let x = "(///)".to_string();
    /// let d: Vec<_> = x.split('/').collect();
    ///
    /// assert_eq!(d, &["(", "", "", ")"]);
    /// ```
    ///
    /// በሕብረቁምፊ መጀመሪያ ወይም መጨረሻ ላይ መለያየቶች በባዶ ክሮች ጎረቤት ናቸው ፡፡
    ///
    /// ```
    /// let d: Vec<_> = "010".split("0").collect();
    /// assert_eq!(d, &["", "1", ""]);
    /// ```
    ///
    /// ባዶው ሕብረቁምፊ እንደ መለያየት በሚሠራበት ጊዜ ፣ በሕብረቁምፊው ውስጥ ያሉትን እያንዳንዱን ቁምፊ ይለያያል ፣ ከህብረቁምቡ መጀመሪያ እና መጨረሻ ጋር።
    ///
    /// ```
    /// let f: Vec<_> = "rust".split("").collect();
    /// assert_eq!(f, &["", "r", "u", "s", "t", ""]);
    /// ```
    ///
    /// የነጭ ቦታ እንደ መለያየት ጥቅም ላይ በሚውልበት ጊዜ ተጣማጅ መለያዎች ወደ አስገራሚ ባህሪ ሊመሩ ይችላሉ ፡፡ይህ ኮድ ትክክል ነው
    ///
    /// ```
    /// let x = "    a  b c".to_string();
    /// let d: Vec<_> = x.split(' ').collect();
    ///
    /// assert_eq!(d, &["", "", "", "", "a", "", "b", "c"]);
    /// ```
    ///
    /// _not_ ይሰጥዎታል:
    ///
    /// ```,ignore
    /// assert_eq!(d, &["a", "b", "c"]);
    /// ```
    ///
    /// ለዚህ ባህሪ [`split_whitespace`] ን ይጠቀሙ።
    ///
    /// [`split_whitespace`]: str::split_whitespace
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split<'a, P: Pattern<'a>>(&'a self, pat: P) -> Split<'a, P> {
        Split(SplitInternal {
            start: 0,
            end: self.len(),
            matcher: pat.into_searcher(self),
            allow_trailing_empty: true,
            finished: false,
        })
    }

    /// በስርዓተ-ጥለት በተዛመዱ ገጸ-ባህሪዎች የተለዩ የዚህ ሕብረቁምፊ ቁራጭ ንጣፎች ላይ አንድ ተደጋጋሚ።
    /// በዚያ `split_inclusive` ውስጥ በ `split` ከተሰራው ተደጋጋሚ ጠቋሚዎች ልዩነቶች የተጣጣመውን ክፍል እንደ ንጣፍ ማቋረጫ ይተዋል።
    ///
    ///
    /// [pattern] `&str` ፣ [`char`] ፣ የ ``ቻር`ን ቁራጭ ወይም አንድ ገጸ-ባህሪ የሚዛመድ መሆኑን የሚወስን ተግባር ወይም መዘጋት ሊሆን ይችላል።
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb\nlittle lamb\nlittle lamb."
    ///     .split_inclusive('\n').collect();
    /// assert_eq!(v, ["Mary had a little lamb\n", "little lamb\n", "little lamb."]);
    /// ```
    ///
    /// የሕብረቁምፊው የመጨረሻው አካል ከተመሳሰለ ያ አካል የቀደመውን ገመድ ማቋረጫ ይቆጠራል።
    /// ያ ንጣፍ በእንደገና የተመለሰ የመጨረሻው ንጥል ይሆናል።
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb\nlittle lamb\nlittle lamb.\n"
    ///     .split_inclusive('\n').collect();
    /// assert_eq!(v, ["Mary had a little lamb\n", "little lamb\n", "little lamb.\n"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive<'a, P: Pattern<'a>>(&'a self, pat: P) -> SplitInclusive<'a, P> {
        SplitInclusive(SplitInternal {
            start: 0,
            end: self.len(),
            matcher: pat.into_searcher(self),
            allow_trailing_empty: false,
            finished: false,
        })
    }

    /// በተሰጠው የሕብረቁምፊ ቁራጭ ንጣፎች ላይ አንድ ተደጋጋሚ የሆነ ፣ ከንድፍ ጋር በተመሳሰሉ ገጸ-ባህሪዎች የተለዩ እና በተቃራኒው ቅደም ተከተል የተሰጡ ፡፡
    ///
    /// [pattern] `&str` ፣ [`char`] ፣ የ ``ቻር`ን ቁራጭ ወይም አንድ ገጸ-ባህሪ የሚዛመድ መሆኑን የሚወስን ተግባር ወይም መዘጋት ሊሆን ይችላል።
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # የኢተራክተር ባህሪ
    ///
    /// የተመለሰው ተደጋጋሚ ንድፍ ንድፉ የተገላቢጦሽ ፍለጋን እንደሚደግፍ ይጠይቃል ፣ እና አንድ forward/reverse ፍለጋ ተመሳሳይ አባሎችን ካገኘ [`DoubleEndedIterator`] ይሆናል።
    ///
    ///
    /// ከፊት ለፊቱ ለማጣራት የ [`split`] ዘዴን መጠቀም ይቻላል።
    ///
    /// [`split`]: str::split
    ///
    /// # Examples
    ///
    /// ቀላል ቅጦች
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".rsplit(' ').collect();
    /// assert_eq!(v, ["lamb", "little", "a", "had", "Mary"]);
    ///
    /// let v: Vec<&str> = "".rsplit('X').collect();
    /// assert_eq!(v, [""]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".rsplit('X').collect();
    /// assert_eq!(v, ["leopard", "tiger", "", "lion"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".rsplit("::").collect();
    /// assert_eq!(v, ["leopard", "tiger", "lion"]);
    /// ```
    ///
    /// መዘጋትን በመጠቀም የበለጠ ውስብስብ ንድፍ
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".rsplit(|c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["ghi", "def", "abc"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplit<'a, P>(&'a self, pat: P) -> RSplit<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplit(self.split(pat).0)
    }

    /// በስርዓተ-ጥለት በተዛመዱ ገጸ-ባህሪዎች በመለየት በተሰጠው የሕብረቁምፊ ቁራጭ ንጣፎች ላይ አንድ ተደጋጋሚ።
    ///
    /// [pattern] `&str` ፣ [`char`] ፣ የ ``ቻር`ን ቁራጭ ወይም አንድ ገጸ-ባህሪ የሚዛመድ መሆኑን የሚወስን ተግባር ወይም መዘጋት ሊሆን ይችላል።
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// ከ‹000000›ጋር የሚመጣጠን ፣ የሚጎተተው ገመድ ባዶ ከሆነ ከተዘለለ በስተቀር።
    ///
    /// [`split`]: str::split
    ///
    /// ይህ ዘዴ በንድፍ ከ _separated_ ይልቅ _terminated_ ለሆነው የሕብረቁምፊ ውሂብ ሊያገለግል ይችላል ፡፡
    ///
    /// # የኢተራክተር ባህሪ
    ///
    /// ንድፉ የተገላቢጦሽ ፍለጋን የሚፈቅድ እና የ forward/reverse ፍለጋ ተመሳሳይ አባሎችን የሚያመጣ ከሆነ የተመለሰው ተደጋጋሚ [`DoubleEndedIterator`] ይሆናል።
    /// ይህ ለ‹[`char`]›እውነት ነው ፣ ግን ለ‹`&str` X›አይደለም ፡፡
    ///
    /// ንድፉ የተገላቢጦሽ ፍለጋን የሚፈቅድ ከሆነ ግን ውጤቶቹ ከቀጣይ ፍለጋ ሊለዩ ይችላሉ ፣ የ [`rsplit_terminator`] ዘዴን መጠቀም ይቻላል።
    ///
    /// [`rsplit_terminator`]: str::rsplit_terminator
    ///
    /// # Examples
    ///
    /// መሠረታዊ አጠቃቀም
    ///
    /// ```
    /// let v: Vec<&str> = "A.B.".split_terminator('.').collect();
    /// assert_eq!(v, ["A", "B"]);
    ///
    /// let v: Vec<&str> = "A..B..".split_terminator(".").collect();
    /// assert_eq!(v, ["A", "", "B", ""]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_terminator<'a, P: Pattern<'a>>(&'a self, pat: P) -> SplitTerminator<'a, P> {
        SplitTerminator(SplitInternal { allow_trailing_empty: false, ..self.split(pat).0 })
    }

    /// በ‹XXXX›ንዑስ ክፍልፋዮች ላይ አንድ ተንታኝ ፣ በንድፍ በተመሳሰሉ ገጸ-ባህሪዎች የተለዩ እና በተቃራኒው ቅደም ተከተል የተሰጡ ፡፡
    ///
    /// [pattern] `&str` ፣ [`char`] ፣ የ ``ቻር`ን ቁራጭ ወይም አንድ ገጸ-ባህሪ የሚዛመድ መሆኑን የሚወስን ተግባር ወይም መዘጋት ሊሆን ይችላል።
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// ከ‹000000›ጋር የሚመጣጠን ፣ የሚጎተተው ገመድ ባዶ ከሆነ ከተዘለለ በስተቀር።
    ///
    /// [`split`]: str::split
    ///
    /// ይህ ዘዴ በንድፍ ከ _separated_ ይልቅ _terminated_ ለሆነው የሕብረቁምፊ ውሂብ ሊያገለግል ይችላል ፡፡
    ///
    /// # የኢተራክተር ባህሪ
    ///
    /// የተመለሰው ተደጋጋሚ ንድፍ ንድፉ የተገላቢጦሽ ፍለጋን እንደሚደግፍ ይጠይቃል ፣ እና የ forward/reverse ፍለጋ ተመሳሳይ ንጥረ ነገሮችን ካገኘ በእጥፍ ይጠናቀቃል።
    ///
    ///
    /// ከፊት ለፊቱ ለማጣራት የ [`split_terminator`] ዘዴን መጠቀም ይቻላል።
    ///
    /// [`split_terminator`]: str::split_terminator
    ///
    /// # Examples
    ///
    /// ```
    /// let v: Vec<&str> = "A.B.".rsplit_terminator('.').collect();
    /// assert_eq!(v, ["B", "A"]);
    ///
    /// let v: Vec<&str> = "A..B..".rsplit_terminator(".").collect();
    /// assert_eq!(v, ["", "B", "", "A"]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplit_terminator<'a, P>(&'a self, pat: P) -> RSplitTerminator<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplitTerminator(self.split_terminator(pat).0)
    }

    /// በተሰጠው የሕብረቁምፊ ቁራጭ ንዑስ ክፍል ላይ አንድ ተንታኝ ፣ በንድፍ የተከፋፈለ ፣ ቢበዛ የ `n` ንጥሎችን ለመመለስ የተከለከለ።
    ///
    /// የ `n` ንጣፎች ከተመለሱ ፣ የመጨረሻው ማገናኛ (`n`th substring`) ቀሪውን ሕብረቁምፊ ይይዛል።
    ///
    /// [pattern] `&str` ፣ [`char`] ፣ የ ``ቻር`ን ቁራጭ ወይም አንድ ገጸ-ባህሪ የሚዛመድ መሆኑን የሚወስን ተግባር ወይም መዘጋት ሊሆን ይችላል።
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # የኢተራክተር ባህሪ
    ///
    /// የተመለሰው ተሟጋች በእጥፍ አይጠናቀቅም ፣ ምክንያቱም ለመደገፍ ቀልጣፋ ስላልሆነ።
    ///
    /// ንድፉ የተገላቢጦሽ ፍለጋን የሚፈቅድ ከሆነ የ [`rsplitn`] ዘዴን መጠቀም ይቻላል።
    ///
    /// [`rsplitn`]: str::rsplitn
    ///
    /// # Examples
    ///
    /// ቀላል ቅጦች
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lambda".splitn(3, ' ').collect();
    /// assert_eq!(v, ["Mary", "had", "a little lambda"]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".splitn(3, "X").collect();
    /// assert_eq!(v, ["lion", "", "tigerXleopard"]);
    ///
    /// let v: Vec<&str> = "abcXdef".splitn(1, 'X').collect();
    /// assert_eq!(v, ["abcXdef"]);
    ///
    /// let v: Vec<&str> = "".splitn(1, 'X').collect();
    /// assert_eq!(v, [""]);
    /// ```
    ///
    /// መዘጋትን በመጠቀም የበለጠ ውስብስብ ንድፍ
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".splitn(2, |c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["abc", "defXghi"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn<'a, P: Pattern<'a>>(&'a self, n: usize, pat: P) -> SplitN<'a, P> {
        SplitN(SplitNInternal { iter: self.split(pat).0, count: n })
    }

    /// በዚህ የ‹XXXXXXXXXXXXXXXX›እቃዎች መመለስን የተመለከተው በዚህ ሕብረቁምፊ ቁራጭ ንዑስ ክፍል ላይ አንድ ተንታኝ ፣ በንድፍ ተለይቷል ፡፡
    ///
    ///
    /// የ `n` ንጣፎች ከተመለሱ ፣ የመጨረሻው ማገናኛ (`n`th substring`) ቀሪውን ሕብረቁምፊ ይይዛል።
    ///
    /// [pattern] `&str` ፣ [`char`] ፣ የ ``ቻር`ን ቁራጭ ወይም አንድ ገጸ-ባህሪ የሚዛመድ መሆኑን የሚወስን ተግባር ወይም መዘጋት ሊሆን ይችላል።
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # የኢተራክተር ባህሪ
    ///
    /// የተመለሰው ተሟጋች በእጥፍ አይጠናቀቅም ፣ ምክንያቱም ለመደገፍ ቀልጣፋ ስላልሆነ።
    ///
    /// ከፊት ለመከፋፈል የ [`splitn`] ዘዴን መጠቀም ይቻላል።
    ///
    /// [`splitn`]: str::splitn
    ///
    /// # Examples
    ///
    /// ቀላል ቅጦች
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".rsplitn(3, ' ').collect();
    /// assert_eq!(v, ["lamb", "little", "Mary had a"]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".rsplitn(3, 'X').collect();
    /// assert_eq!(v, ["leopard", "tiger", "lionX"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".rsplitn(2, "::").collect();
    /// assert_eq!(v, ["leopard", "lion::tiger"]);
    /// ```
    ///
    /// መዘጋትን በመጠቀም የበለጠ ውስብስብ ንድፍ
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".rsplitn(2, |c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["ghi", "abc1def"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn<'a, P>(&'a self, n: usize, pat: P) -> RSplitN<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplitN(self.splitn(n, pat).0)
    }

    /// በተጠቀሰው ወሰን የመጀመሪያ ክስተት ላይ ያለውን ክር ይከፍላል እና ከገደብ በፊት እና ቅድመ ወሰን በፊት ቅድመ ቅጥያ ይመልሳል።
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("cfg".split_once('='), None);
    /// assert_eq!("cfg=foo".split_once('='), Some(("cfg", "foo")));
    /// assert_eq!("cfg=foo=bar".split_once('='), Some(("cfg", "foo=bar")));
    /// ```
    #[stable(feature = "str_split_once", since = "1.52.0")]
    #[inline]
    pub fn split_once<'a, P: Pattern<'a>>(&'a self, delimiter: P) -> Option<(&'a str, &'a str)> {
        let (start, end) = delimiter.into_searcher(self).next_match()?;
        Some((&self[..start], &self[end..]))
    }

    /// በተጠቀሰው ወሰን የመጨረሻ ክስተት ላይ ያለውን ክር ይከፍላል እና ከገደብ በፊት እና ቅድመ ወሰን በፊት ድህረ ገፁን ይመልሳል።
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("cfg".rsplit_once('='), None);
    /// assert_eq!("cfg=foo".rsplit_once('='), Some(("cfg", "foo")));
    /// assert_eq!("cfg=foo=bar".rsplit_once('='), Some(("cfg=foo", "bar")));
    /// ```
    #[stable(feature = "str_split_once", since = "1.52.0")]
    #[inline]
    pub fn rsplit_once<'a, P>(&'a self, delimiter: P) -> Option<(&'a str, &'a str)>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        let (start, end) = delimiter.into_searcher(self).next_match_back()?;
        Some((&self[..start], &self[end..]))
    }

    /// በተሰጠው የሕብረቁምፊ ቁርጥራጭ ውስጥ ካለው ንድፍ ጋር በተዛመደ ተዛማጅነት ላይ አንድ ተንታኝ።
    ///
    /// [pattern] `&str` ፣ [`char`] ፣ የ ``ቻር`ን ቁራጭ ወይም አንድ ገጸ-ባህሪ የሚዛመድ መሆኑን የሚወስን ተግባር ወይም መዘጋት ሊሆን ይችላል።
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # የኢተራክተር ባህሪ
    ///
    /// ንድፉ የተገላቢጦሽ ፍለጋን የሚፈቅድ እና የ forward/reverse ፍለጋ ተመሳሳይ አባሎችን የሚያመጣ ከሆነ የተመለሰው ተደጋጋሚ [`DoubleEndedIterator`] ይሆናል።
    /// ይህ ለ‹[`char`]›እውነት ነው ፣ ግን ለ‹`&str` X›አይደለም ፡፡
    ///
    /// ንድፉ የተገላቢጦሽ ፍለጋን የሚፈቅድ ከሆነ ግን ውጤቶቹ ከቀጣይ ፍለጋ ሊለዩ ይችላሉ ፣ የ [`rmatches`] ዘዴን መጠቀም ይቻላል።
    ///
    /// [`rmatches`]: str::matches
    ///
    /// # Examples
    ///
    /// መሠረታዊ አጠቃቀም
    ///
    /// ```
    /// let v: Vec<&str> = "abcXXXabcYYYabc".matches("abc").collect();
    /// assert_eq!(v, ["abc", "abc", "abc"]);
    ///
    /// let v: Vec<&str> = "1abc2abc3".matches(char::is_numeric).collect();
    /// assert_eq!(v, ["1", "2", "3"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "str_matches", since = "1.2.0")]
    #[inline]
    pub fn matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> Matches<'a, P> {
        Matches(MatchesInternal(pat.into_searcher(self)))
    }

    /// በተገላቢጦሽ ቅደም ተከተል የተሰጠው በዚህ ሕብረቁምፊ ቁራጭ ውስጥ ካለው ንድፍ ጋር ተያያዥነት ባላቸው ግጥሚያዎች ላይ አንድ ተደጋጋሚ።
    ///
    /// [pattern] `&str` ፣ [`char`] ፣ የ ``ቻር`ን ቁራጭ ወይም አንድ ገጸ-ባህሪ የሚዛመድ መሆኑን የሚወስን ተግባር ወይም መዘጋት ሊሆን ይችላል።
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # የኢተራክተር ባህሪ
    ///
    /// የተመለሰው ተደጋጋሚ ንድፍ ንድፉ የተገላቢጦሽ ፍለጋን እንደሚደግፍ ይጠይቃል ፣ እና አንድ forward/reverse ፍለጋ ተመሳሳይ አባሎችን ካገኘ [`DoubleEndedIterator`] ይሆናል።
    ///
    ///
    /// ከፊት ለፊቱ ለማጣራት የ [`matches`] ዘዴን መጠቀም ይቻላል።
    ///
    /// [`matches`]: str::matches
    ///
    /// # Examples
    ///
    /// መሠረታዊ አጠቃቀም
    ///
    /// ```
    /// let v: Vec<&str> = "abcXXXabcYYYabc".rmatches("abc").collect();
    /// assert_eq!(v, ["abc", "abc", "abc"]);
    ///
    /// let v: Vec<&str> = "1abc2abc3".rmatches(char::is_numeric).collect();
    /// assert_eq!(v, ["3", "2", "1"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "str_matches", since = "1.2.0")]
    #[inline]
    pub fn rmatches<'a, P>(&'a self, pat: P) -> RMatches<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RMatches(self.matches(pat).0)
    }

    /// በዚህ ሕብረቁምፊ ቁራጭ ውስጥ ካለው የንድፍ ልዩነት ግጥሚያዎች እንዲሁም ግጥሚያው የሚጀምርበት ማውጫ ላይ አንድ ተንታኝ።
    ///
    /// ለተደራራቢ በ `self` ውስጥ ለ‹`pat` X›ግጥሚያዎች ፣ ከመጀመሪያው ግጥሚያ ጋር የሚዛመዱ ማውጫዎች ብቻ ይመለሳሉ።
    ///
    /// [pattern] `&str` ፣ [`char`] ፣ የ ``ቻር`ን ቁራጭ ወይም አንድ ገጸ-ባህሪ የሚዛመድ መሆኑን የሚወስን ተግባር ወይም መዘጋት ሊሆን ይችላል።
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # የኢተራክተር ባህሪ
    ///
    /// ንድፉ የተገላቢጦሽ ፍለጋን የሚፈቅድ እና የ forward/reverse ፍለጋ ተመሳሳይ አባሎችን የሚያመጣ ከሆነ የተመለሰው ተደጋጋሚ [`DoubleEndedIterator`] ይሆናል።
    /// ይህ ለ‹[`char`]›እውነት ነው ፣ ግን ለ‹`&str` X›አይደለም ፡፡
    ///
    /// ንድፉ የተገላቢጦሽ ፍለጋን የሚፈቅድ ከሆነ ግን ውጤቶቹ ከቀጣይ ፍለጋ ሊለዩ ይችላሉ ፣ የ [`rmatch_indices`] ዘዴን መጠቀም ይቻላል።
    ///
    /// [`rmatch_indices`]: str::match_indices
    ///
    /// # Examples
    ///
    /// መሠረታዊ አጠቃቀም
    ///
    /// ```
    /// let v: Vec<_> = "abcXXXabcYYYabc".match_indices("abc").collect();
    /// assert_eq!(v, [(0, "abc"), (6, "abc"), (12, "abc")]);
    ///
    /// let v: Vec<_> = "1abcabc2".match_indices("abc").collect();
    /// assert_eq!(v, [(1, "abc"), (4, "abc")]);
    ///
    /// let v: Vec<_> = "ababa".match_indices("aba").collect();
    /// assert_eq!(v, [(0, "aba")]); // የመጀመሪያው `aba` ብቻ
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "str_match_indices", since = "1.5.0")]
    #[inline]
    pub fn match_indices<'a, P: Pattern<'a>>(&'a self, pat: P) -> MatchIndices<'a, P> {
        MatchIndices(MatchIndicesInternal(pat.into_searcher(self)))
    }

    /// በ `self` ውስጥ ካለው ንድፍ ጋር ተያያዥነት ባላቸው ተዛማጆች ላይ አንድ ተንታኝ ፣ ከግጥሚያው ጠቋሚ ጋር በተቃራኒው ቅደም ተከተል ይሰጣል።
    ///
    /// ለተደራራቢ በ `self` ውስጥ ለ‹`pat` X›ግጥሚያዎች ፣ ካለፈው ግጥሚያ ጋር የሚዛመዱ ማውጫዎች ብቻ ይመለሳሉ።
    ///
    /// [pattern] `&str` ፣ [`char`] ፣ የ ``ቻር`ን ቁራጭ ወይም አንድ ገጸ-ባህሪ የሚዛመድ መሆኑን የሚወስን ተግባር ወይም መዘጋት ሊሆን ይችላል።
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # የኢተራክተር ባህሪ
    ///
    /// የተመለሰው ተደጋጋሚ ንድፍ ንድፉ የተገላቢጦሽ ፍለጋን እንደሚደግፍ ይጠይቃል ፣ እና አንድ forward/reverse ፍለጋ ተመሳሳይ አባሎችን ካገኘ [`DoubleEndedIterator`] ይሆናል።
    ///
    ///
    /// ከፊት ለፊቱ ለማጣራት የ [`match_indices`] ዘዴን መጠቀም ይቻላል።
    ///
    /// [`match_indices`]: str::match_indices
    ///
    /// # Examples
    ///
    /// መሠረታዊ አጠቃቀም
    ///
    /// ```
    /// let v: Vec<_> = "abcXXXabcYYYabc".rmatch_indices("abc").collect();
    /// assert_eq!(v, [(12, "abc"), (6, "abc"), (0, "abc")]);
    ///
    /// let v: Vec<_> = "1abcabc2".rmatch_indices("abc").collect();
    /// assert_eq!(v, [(4, "abc"), (1, "abc")]);
    ///
    /// let v: Vec<_> = "ababa".rmatch_indices("aba").collect();
    /// assert_eq!(v, [(2, "aba")]); // የመጨረሻው `aba` ብቻ
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "str_match_indices", since = "1.5.0")]
    #[inline]
    pub fn rmatch_indices<'a, P>(&'a self, pat: P) -> RMatchIndices<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RMatchIndices(self.match_indices(pat).0)
    }

    /// በሚመራው እና በሚከተለው የኋይትስ ክፍተት የተወገደ የህብረቁምፊ ቁርጥራጭ ይመልሳል።
    ///
    /// 'Whitespace' በዩኒኮድ በተገኘው መሠረታዊ ንብረት `White_Space` ውሎች መሠረት ይገለጻል ፡፡
    ///
    ///
    /// # Examples
    ///
    /// መሠረታዊ አጠቃቀም
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!("Hello\tworld", s.trim());
    /// ```
    #[inline]
    #[must_use = "this returns the trimmed string as a slice, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn trim(&self) -> &str {
        self.trim_matches(|c: char| c.is_whitespace())
    }

    /// መሪ የነጭ ቦታ ተወግዶ የሕብረቁምፊ ቁራጭ ይመልሳል።
    ///
    /// 'Whitespace' በዩኒኮድ በተገኘው መሠረታዊ ንብረት `White_Space` ውሎች መሠረት ይገለጻል ፡፡
    ///
    /// # የጽሑፍ አቅጣጫ
    ///
    /// አንድ ሕብረቁምፊ የባይቶች ቅደም ተከተል ነው።
    /// `start` በዚህ ዐውደ-ጽሑፍ ውስጥ የዚያ ባይት ገመድ የመጀመሪያ አቀማመጥ ማለት ነው።ለግራ-ወደ-ቀኝ ቋንቋ እንግሊዝኛ ወይም ሩሲያኛ ፣ ይህ ግራ ጎን ይሆናል ፣ እንዲሁም ከቀኝ ወደ ግራ ቋንቋዎች እንደ አረብኛ ወይም ዕብራይስጥ ይህ የቀኝ ወገን ይሆናል።
    ///
    ///
    /// # Examples
    ///
    /// መሠረታዊ አጠቃቀም
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    /// assert_eq!("Hello\tworld\t", s.trim_start());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English  ";
    /// assert!(Some('E') == s.trim_start().chars().next());
    ///
    /// let s = "  עברית  ";
    /// assert!(Some('ע') == s.trim_start().chars().next());
    /// ```
    ///
    ///
    #[inline]
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_start(&self) -> &str {
        self.trim_start_matches(|c: char| c.is_whitespace())
    }

    /// ከሚከተለው የኋይት ክፍተት ጋር የሕብረቁምፊ ቁራጭ ይመልሳል።
    ///
    /// 'Whitespace' በዩኒኮድ በተገኘው መሠረታዊ ንብረት `White_Space` ውሎች መሠረት ይገለጻል ፡፡
    ///
    /// # የጽሑፍ አቅጣጫ
    ///
    /// አንድ ሕብረቁምፊ የባይቶች ቅደም ተከተል ነው።
    /// `end` በዚህ ዐውደ-ጽሑፍ ውስጥ የዚያ ባይት ገመድ የመጨረሻ ቦታ ማለት ነው።እንደ ግራ-ወደ-ቀኝ ቋንቋ እንግሊዝኛ ወይም ሩሲያኛ ፣ ይህ ከቀኝ በኩል ይሆናል ፣ እንዲሁም ከቀኝ ወደ ግራ ቋንቋዎች እንደ አረብኛ ወይም ዕብራይስጥ ፣ ይህ የግራ ጎን ይሆናል።
    ///
    ///
    /// # Examples
    ///
    /// መሠረታዊ አጠቃቀም
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    /// assert_eq!(" Hello\tworld", s.trim_end());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English  ";
    /// assert!(Some('h') == s.trim_end().chars().rev().next());
    ///
    /// let s = "  עברית  ";
    /// assert!(Some('ת') == s.trim_end().chars().rev().next());
    /// ```
    ///
    ///
    #[inline]
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_end(&self) -> &str {
        self.trim_end_matches(|c: char| c.is_whitespace())
    }

    /// መሪ የነጭ ቦታ ተወግዶ የሕብረቁምፊ ቁራጭ ይመልሳል።
    ///
    /// 'Whitespace' በዩኒኮድ በተገኘው መሠረታዊ ንብረት `White_Space` ውሎች መሠረት ይገለጻል ፡፡
    ///
    /// # የጽሑፍ አቅጣጫ
    ///
    /// አንድ ሕብረቁምፊ የባይቶች ቅደም ተከተል ነው።
    /// 'Left' በዚህ ዐውደ-ጽሑፍ ውስጥ የዚያ ባይት ገመድ የመጀመሪያ አቀማመጥ ማለት ነው።ከ‹ግራ ወደ ቀኝ›ሳይሆን እንደ አረብኛ ወይም እንደ ዕብራይስጥ ያሉ‹ከቀኝ ወደ ግራ›ለሚለው ቋንቋ ይህ የ _right_ ጎን ይሆናል ፣ ግራ አይሆንም ፡፡
    ///
    ///
    /// # Examples
    ///
    /// መሠረታዊ አጠቃቀም
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!("Hello\tworld\t", s.trim_left());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English";
    /// assert!(Some('E') == s.trim_left().chars().next());
    ///
    /// let s = "  עברית";
    /// assert!(Some('ע') == s.trim_left().chars().next());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_start`",
        suggestion = "trim_start"
    )]
    pub fn trim_left(&self) -> &str {
        self.trim_start()
    }

    /// ከሚከተለው የኋይት ክፍተት ጋር የሕብረቁምፊ ቁራጭ ይመልሳል።
    ///
    /// 'Whitespace' በዩኒኮድ በተገኘው መሠረታዊ ንብረት `White_Space` ውሎች መሠረት ይገለጻል ፡፡
    ///
    /// # የጽሑፍ አቅጣጫ
    ///
    /// አንድ ሕብረቁምፊ የባይቶች ቅደም ተከተል ነው።
    /// 'Right' በዚህ ዐውደ-ጽሑፍ ውስጥ የዚያ ባይት ገመድ የመጨረሻ ቦታ ማለት ነው።ከ‹ግራ ወደ ቀኝ›ይልቅ እንደ አረብኛ ወይም እንደ ዕብራይስጥ ያሉ‹ከቀኝ ወደ ግራ›ለሚለው ቋንቋ ይህ የ _left_ ጎን ይሆናል ፣ የቀኝ አይደለም ፡፡
    ///
    ///
    /// # Examples
    ///
    /// መሠረታዊ አጠቃቀም
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!(" Hello\tworld", s.trim_right());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "English  ";
    /// assert!(Some('h') == s.trim_right().chars().rev().next());
    ///
    /// let s = "עברית  ";
    /// assert!(Some('ת') == s.trim_right().chars().rev().next());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_end`",
        suggestion = "trim_end"
    )]
    pub fn trim_right(&self) -> &str {
        self.trim_end()
    }

    /// በተደጋጋሚ ከተወገደው ስርዓተ-ጥለት ጋር በሚዛመዱ በሁሉም ቅድመ-ቅጥያዎች እና ቅጥያዎች የሕብረቁምፊ ቁርጥራጭ ይመልሳል።
    ///
    /// [pattern] [`char`] ፣ የ `ቻር` ን ቁራጭ ወይም አንድ ገጸ-ባህሪ የሚዛመድ መሆኑን የሚወስን ተግባር ወይም መዘጋት ሊሆን ይችላል።
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ቀላል ቅጦች
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_matches('1'), "foo1bar");
    /// assert_eq!("123foo1bar123".trim_matches(char::is_numeric), "foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_matches(x), "foo1bar");
    /// ```
    ///
    /// መዘጋትን በመጠቀም የበለጠ ውስብስብ ንድፍ
    ///
    /// ```
    /// assert_eq!("1foo1barXX".trim_matches(|c| c == '1' || c == 'X'), "foo1bar");
    /// ```
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn trim_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: DoubleEndedSearcher<'a>>,
    {
        let mut i = 0;
        let mut j = 0;
        let mut matcher = pat.into_searcher(self);
        if let Some((a, b)) = matcher.next_reject() {
            i = a;
            j = b; // በጣም የታወቀውን ግጥሚያ ያስታውሱ ፣ ከሆነ ከዚህ በታች ያስተካክሉት
            // የመጨረሻው ግጥሚያ የተለየ ነው
        }
        if let Some((_, b)) = matcher.next_reject_back() {
            j = b;
        }
        // ደህንነት `Searcher` ትክክለኛ መረጃ ጠቋሚዎችን በመመለስ ይታወቃል ፡፡
        unsafe { self.get_unchecked(i..j) }
    }

    /// በተደጋጋሚ ከተወገደ ስርዓተ-ጥለት ጋር በሚዛመዱ ከሁሉም ቅድመ-ቅጥያዎች ጋር የሕብረ-ቁራጭ ቁርጥራጭ ይመልሳል።
    ///
    /// [pattern] `&str` ፣ [`char`] ፣ የ ``ቻር`ን ቁራጭ ወይም አንድ ገጸ-ባህሪ የሚዛመድ መሆኑን የሚወስን ተግባር ወይም መዘጋት ሊሆን ይችላል።
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # የጽሑፍ አቅጣጫ
    ///
    /// አንድ ሕብረቁምፊ የባይቶች ቅደም ተከተል ነው።
    /// `start` በዚህ ዐውደ-ጽሑፍ ውስጥ የዚያ ባይት ገመድ የመጀመሪያ አቀማመጥ ማለት ነው።ለግራ-ወደ-ቀኝ ቋንቋ እንግሊዝኛ ወይም ሩሲያኛ ፣ ይህ ግራ ጎን ይሆናል ፣ እንዲሁም ከቀኝ ወደ ግራ ቋንቋዎች እንደ አረብኛ ወይም ዕብራይስጥ ይህ የቀኝ ወገን ይሆናል።
    ///
    ///
    /// # Examples
    ///
    /// መሠረታዊ አጠቃቀም
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_start_matches('1'), "foo1bar11");
    /// assert_eq!("123foo1bar123".trim_start_matches(char::is_numeric), "foo1bar123");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_start_matches(x), "foo1bar12");
    /// ```
    ///
    ///
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_start_matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> &'a str {
        let mut i = self.len();
        let mut matcher = pat.into_searcher(self);
        if let Some((a, _)) = matcher.next_reject() {
            i = a;
        }
        // ደህንነት `Searcher` ትክክለኛ መረጃ ጠቋሚዎችን በመመለስ ይታወቃል ፡፡
        unsafe { self.get_unchecked(i..self.len()) }
    }

    /// ቅድመ ቅጥያውን ተወግዶ የሕብረቁምፊ ቁራጭ ይመልሳል።
    ///
    /// ሕብረቁምፊው በ‹`prefix`›ንድፍ ከተጀመረ በ‹`Some` X›ተጠቅልሎ ከቅድመ ቅጥያው በኋላ ንዑስ መስመሩን ይመልሳል ፡፡
    /// ከ `trim_start_matches` በተለየ መልኩ ይህ ዘዴ ቅድመ-ቅጥያውን በትክክል አንድ ጊዜ ያስወግዳል።
    ///
    /// ሕብረቁምፊው በ `prefix` የማይጀምር ከሆነ `None` ን ይመልሳል።
    ///
    /// [pattern] `&str` ፣ [`char`] ፣ የ ``ቻር`ን ቁራጭ ወይም አንድ ገጸ-ባህሪ የሚዛመድ መሆኑን የሚወስን ተግባር ወይም መዘጋት ሊሆን ይችላል።
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("foo:bar".strip_prefix("foo:"), Some("bar"));
    /// assert_eq!("foo:bar".strip_prefix("bar"), None);
    /// assert_eq!("foofoo".strip_prefix("foo"), Some("foo"));
    /// ```
    #[must_use = "this returns the remaining substring as a new slice, \
                  without modifying the original"]
    #[stable(feature = "str_strip", since = "1.45.0")]
    pub fn strip_prefix<'a, P: Pattern<'a>>(&'a self, prefix: P) -> Option<&'a str> {
        prefix.strip_prefix_of(self)
    }

    /// በቅጥያ ቅጥያው ተወግዶ የሕብረቁምፊ ቁራጭ ይመልሳል።
    ///
    /// ሕብረቁምፊው በ‹`suffix`›ንድፍ ከተጠናቀቀ ፣ `Some` ን ተጠቅልሎ ከ‹ቅጥያ›በፊት ተጣማሪውን ይመልሳል ፡፡
    /// ከ `trim_end_matches` በተለየ ይህ ዘዴ አንዴን ቅጥያውን በትክክል ያስወግዳል።
    ///
    /// ሕብረቁምፊው በ `suffix` የማያልቅ ከሆነ `None` ን ይመልሳል።
    ///
    /// [pattern] `&str` ፣ [`char`] ፣ የ ``ቻር`ን ቁራጭ ወይም አንድ ገጸ-ባህሪ የሚዛመድ መሆኑን የሚወስን ተግባር ወይም መዘጋት ሊሆን ይችላል።
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("bar:foo".strip_suffix(":foo"), Some("bar"));
    /// assert_eq!("bar:foo".strip_suffix("bar"), None);
    /// assert_eq!("foofoo".strip_suffix("foo"), Some("foo"));
    /// ```
    #[must_use = "this returns the remaining substring as a new slice, \
                  without modifying the original"]
    #[stable(feature = "str_strip", since = "1.45.0")]
    pub fn strip_suffix<'a, P>(&'a self, suffix: P) -> Option<&'a str>
    where
        P: Pattern<'a>,
        <P as Pattern<'a>>::Searcher: ReverseSearcher<'a>,
    {
        suffix.strip_suffix_of(self)
    }

    /// በተደጋጋሚ ከተወገደ ስርዓተ-ጥለት ጋር በሚዛመዱ ሁሉንም ቅጥያዎች የሕብረቁምፊ ቁርጥራጭ ይመልሳል።
    ///
    /// [pattern] `&str` ፣ [`char`] ፣ የ ``ቻር`ን ቁራጭ ወይም አንድ ገጸ-ባህሪ የሚዛመድ መሆኑን የሚወስን ተግባር ወይም መዘጋት ሊሆን ይችላል።
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # የጽሑፍ አቅጣጫ
    ///
    /// አንድ ሕብረቁምፊ የባይቶች ቅደም ተከተል ነው።
    /// `end` በዚህ ዐውደ-ጽሑፍ ውስጥ የዚያ ባይት ገመድ የመጨረሻ ቦታ ማለት ነው።እንደ ግራ-ወደ-ቀኝ ቋንቋ እንግሊዝኛ ወይም ሩሲያኛ ፣ ይህ ከቀኝ በኩል ይሆናል ፣ እንዲሁም ከቀኝ ወደ ግራ ቋንቋዎች እንደ አረብኛ ወይም ዕብራይስጥ ፣ ይህ የግራ ጎን ይሆናል።
    ///
    ///
    /// # Examples
    ///
    /// ቀላል ቅጦች
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_end_matches('1'), "11foo1bar");
    /// assert_eq!("123foo1bar123".trim_end_matches(char::is_numeric), "123foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_end_matches(x), "12foo1bar");
    /// ```
    ///
    /// መዘጋትን በመጠቀም የበለጠ ውስብስብ ንድፍ
    ///
    /// ```
    /// assert_eq!("1fooX".trim_end_matches(|c| c == '1' || c == 'X'), "1foo");
    /// ```
    ///
    ///
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_end_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        let mut j = 0;
        let mut matcher = pat.into_searcher(self);
        if let Some((_, b)) = matcher.next_reject_back() {
            j = b;
        }
        // ደህንነት `Searcher` ትክክለኛ መረጃ ጠቋሚዎችን በመመለስ ይታወቃል ፡፡
        unsafe { self.get_unchecked(0..j) }
    }

    /// በተደጋጋሚ ከተወገደ ስርዓተ-ጥለት ጋር በሚዛመዱ ከሁሉም ቅድመ-ቅጥያዎች ጋር የሕብረ-ቁራጭ ቁርጥራጭ ይመልሳል።
    ///
    /// [pattern] `&str` ፣ [`char`] ፣ የ ``ቻር`ን ቁራጭ ወይም አንድ ገጸ-ባህሪ የሚዛመድ መሆኑን የሚወስን ተግባር ወይም መዘጋት ሊሆን ይችላል።
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # የጽሑፍ አቅጣጫ
    ///
    /// አንድ ሕብረቁምፊ የባይቶች ቅደም ተከተል ነው።
    /// 'Left' በዚህ ዐውደ-ጽሑፍ ውስጥ የዚያ ባይት ገመድ የመጀመሪያ አቀማመጥ ማለት ነው።ከ‹ግራ ወደ ቀኝ›ሳይሆን እንደ አረብኛ ወይም እንደ ዕብራይስጥ ያሉ‹ከቀኝ ወደ ግራ›ለሚለው ቋንቋ ይህ የ _right_ ጎን ይሆናል ፣ ግራ አይሆንም ፡፡
    ///
    ///
    /// # Examples
    ///
    /// መሠረታዊ አጠቃቀም
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_left_matches('1'), "foo1bar11");
    /// assert_eq!("123foo1bar123".trim_left_matches(char::is_numeric), "foo1bar123");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_left_matches(x), "foo1bar12");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_start_matches`",
        suggestion = "trim_start_matches"
    )]
    pub fn trim_left_matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> &'a str {
        self.trim_start_matches(pat)
    }

    /// በተደጋጋሚ ከተወገደ ስርዓተ-ጥለት ጋር በሚዛመዱ ሁሉንም ቅጥያዎች የሕብረቁምፊ ቁርጥራጭ ይመልሳል።
    ///
    /// [pattern] `&str` ፣ [`char`] ፣ የ ``ቻር`ን ቁራጭ ወይም አንድ ገጸ-ባህሪ የሚዛመድ መሆኑን የሚወስን ተግባር ወይም መዘጋት ሊሆን ይችላል።
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # የጽሑፍ አቅጣጫ
    ///
    /// አንድ ሕብረቁምፊ የባይቶች ቅደም ተከተል ነው።
    /// 'Right' በዚህ ዐውደ-ጽሑፍ ውስጥ የዚያ ባይት ገመድ የመጨረሻ ቦታ ማለት ነው።ከ‹ግራ ወደ ቀኝ›ይልቅ እንደ አረብኛ ወይም እንደ ዕብራይስጥ ያሉ‹ከቀኝ ወደ ግራ›ለሚለው ቋንቋ ይህ የ _left_ ጎን ይሆናል ፣ የቀኝ አይደለም ፡፡
    ///
    ///
    /// # Examples
    ///
    /// ቀላል ቅጦች
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_right_matches('1'), "11foo1bar");
    /// assert_eq!("123foo1bar123".trim_right_matches(char::is_numeric), "123foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_right_matches(x), "12foo1bar");
    /// ```
    ///
    /// መዘጋትን በመጠቀም የበለጠ ውስብስብ ንድፍ
    ///
    /// ```
    /// assert_eq!("1fooX".trim_right_matches(|c| c == '1' || c == 'X'), "1foo");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_end_matches`",
        suggestion = "trim_end_matches"
    )]
    pub fn trim_right_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        self.trim_end_matches(pat)
    }

    /// ይህን ሕብረቁምፊ ወደ ሌላ ዓይነት ይከፍታል።
    ///
    /// `parse` በጣም አጠቃላይ ስለሆነ በአይነት ግንዛቤ ላይ ችግር ሊፈጥር ይችላል ፡፡
    /// እንደዚሁም X0 'turbofish' ተብሎ የሚጠራውን አገባብ በፍቅር ከሚመለከቱ ጥቂት ጊዜያት ውስጥ `parse` ነው- `::<>`.
    ///
    /// ይህ የመተንተን ስልተ ቀመር በየትኛው ዓይነት ሊተነተኑ እንደሚሞክሩ ለመረዳት ይረዳል ፡፡
    ///
    /// `parse` [`FromStr`] trait ን ወደ ሚተገብር ማንኛውም ዓይነት መተንተን ይችላል ፡፡
    ///

    /// # Errors
    ///
    /// ይህንን የሕብረቁምፊ ቁርጥራጭ ወደ ተፈለገው ዓይነት ለመተንተን የማይቻል ከሆነ [`Err`] ን ይመልሳል።
    ///
    ///
    /// [`Err`]: FromStr::Err
    ///
    /// # Examples
    ///
    /// መሠረታዊ አጠቃቀም
    ///
    /// ```
    /// let four: u32 = "4".parse().unwrap();
    ///
    /// assert_eq!(4, four);
    /// ```
    ///
    /// `four` ን ከማብራራት ይልቅ 'turbofish' ን በመጠቀም-
    ///
    /// ```
    /// let four = "4".parse::<u32>();
    ///
    /// assert_eq!(Ok(4), four);
    /// ```
    ///
    /// መተንተን አልተሳካም
    ///
    /// ```
    /// let nope = "j".parse::<u32>();
    ///
    /// assert!(nope.is_err());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn parse<F: FromStr>(&self) -> Result<F, F::Err> {
        FromStr::from_str(self)
    }

    /// በዚህ ሕብረቁምፊ ውስጥ ያሉት ሁሉም ቁምፊዎች በ ASCII ክልል ውስጥ ካሉ ይፈትሻል።
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = "hello!\n";
    /// let non_ascii = "Grüße, Jürgen ❤";
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        // እያንዳንዱን ባይት እዚህ እንደ ገጸ-ባህሪ ልንይዘው እንችላለን-ሁሉም ባለብዙ ባይት ቁምፊዎች የሚጀምሩት በ‹አስኪ›ክልል ውስጥ በማይገኝ ባይት ነው ፣ ስለሆነም ቀድመን እዚያ እናቆማለን ፡፡
        //
        //
        self.as_bytes().is_ascii()
    }

    /// ሁለት ሕብረቁምፊዎች የ ASCII ጉዳይ-የማይነካ ግጥሚያ መሆናቸውን ያረጋግጣል።
    ///
    /// `to_ascii_lowercase(a) == to_ascii_lowercase(b)` ጋር ተመሳሳይ ፣ ግን ጊዜያዊዎችን ሳይመድቡ እና ሳይገለብጡ።
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert!("Ferris".eq_ignore_ascii_case("FERRIS"));
    /// assert!("Ferrös".eq_ignore_ascii_case("FERRöS"));
    /// assert!(!"Ferrös".eq_ignore_ascii_case("FERRÖS"));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &str) -> bool {
        self.as_bytes().eq_ignore_ascii_case(other.as_bytes())
    }

    /// ይህንን ክር ወደ ቦታው ወደ ASCII የላይኛው ፊደል አቻው ይለውጠዋል።
    ///
    /// የ ASCII ፊደሎች ከ 'a' እስከ 'z' ወደ 'A' እስከ 'Z' ካርታ ይደረጋሉ ፣ ግን የ ASCII ያልሆኑ ፊደላት አልተለወጡም ፡፡
    ///
    /// ነባሩን መቀየር ያለ አዲስ uppercased እሴት ለመመለስ, [`to_ascii_uppercase()`] ይጠቀሙ.
    ///
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("Grüße, Jürgen ❤");
    ///
    /// s.make_ascii_uppercase();
    ///
    /// assert_eq!("GRüßE, JüRGEN ❤", s);
    /// ```
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        // ደህንነት ሁለት አይነቶችን በተመሳሳይ አቀማመጥ ስለምንለውጥ ደህና ነው ፡፡
        let me = unsafe { self.as_bytes_mut() };
        me.make_ascii_uppercase()
    }

    /// ይህንን ሕብረቁምፊ በቦታው ወደ ASCII ንዑስ ፊደል አቻው ይለውጠዋል።
    ///
    /// የ ASCII ፊደሎች ከ 'A' እስከ 'Z' ወደ 'a' እስከ 'z' ካርታ ይደረጋሉ ፣ ግን የ ASCII ያልሆኑ ፊደላት አልተለወጡም ፡፡
    ///
    /// ነባሩን ሳይቀይር አዲስ ዝቅተኛ ዋጋ ያለው እሴት ለመመለስ [`to_ascii_lowercase()`] ን ይጠቀሙ።
    ///
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("GRÜßE, JÜRGEN ❤");
    ///
    /// s.make_ascii_lowercase();
    ///
    /// assert_eq!("grÜße, jÜrgen ❤", s);
    /// ```
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        // ደህንነት ሁለት አይነቶችን በተመሳሳይ አቀማመጥ ስለምንለውጥ ደህና ነው ፡፡
        let me = unsafe { self.as_bytes_mut() };
        me.make_ascii_lowercase()
    }

    /// በ `self` ውስጥ ከእያንዳንዱ ቻርተር የሚያመልጥ ተደጋጋሚ መልስ ከ‹XXXX›ጋር ይመልሱ ፡፡
    ///
    ///
    /// Note: ሕብረቁምፊውን የሚጀምሩ የተራዘሙ የግራፊም ኮዴፖፖች ብቻ ያመልጣሉ ፡፡
    ///
    /// # Examples
    ///
    /// አንድ ለተደጋጋሚ እንደ:
    ///
    /// ```
    /// for c in "❤\n!".escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// `println!` ን በቀጥታ በመጠቀም
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_debug());
    /// ```
    ///
    /// ሁለቱም ከዚህ ጋር እኩል ናቸው
    ///
    /// ```
    /// println!("❤\\n!");
    /// ```
    ///
    /// `to_string` ን በመጠቀም
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_debug().to_string(), "❤\\n!");
    /// ```
    ///
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_debug(&self) -> EscapeDebug<'_> {
        let mut chars = self.chars();
        EscapeDebug {
            inner: chars
                .next()
                .map(|first| first.escape_debug_ext(true))
                .into_iter()
                .flatten()
                .chain(chars.flat_map(CharEscapeDebugContinue)),
        }
    }

    /// በ `self` ውስጥ ከእያንዳንዱ ቻርተር የሚያመልጥ ተደጋጋሚ መልስ ከ‹XXXX›ጋር ይመልሱ ፡፡
    ///
    ///
    /// # Examples
    ///
    /// አንድ ለተደጋጋሚ እንደ:
    ///
    /// ```
    /// for c in "❤\n!".escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// `println!` ን በቀጥታ በመጠቀም
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_default());
    /// ```
    ///
    /// ሁለቱም ከዚህ ጋር እኩል ናቸው
    ///
    /// ```
    /// println!("\\u{{2764}}\\n!");
    /// ```
    ///
    /// `to_string` ን በመጠቀም
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_default().to_string(), "\\u{2764}\\n!");
    /// ```
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_default(&self) -> EscapeDefault<'_> {
        EscapeDefault { inner: self.chars().flat_map(CharEscapeDefault) }
    }

    /// በ `self` ውስጥ ከእያንዳንዱ ቻርተር የሚያመልጥ ተደጋጋሚ መልስ ከ‹XXXX›ጋር ይመልሱ ፡፡
    ///
    ///
    /// # Examples
    ///
    /// አንድ ለተደጋጋሚ እንደ:
    ///
    /// ```
    /// for c in "❤\n!".escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// `println!` ን በቀጥታ በመጠቀም
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_unicode());
    /// ```
    ///
    /// ሁለቱም ከዚህ ጋር እኩል ናቸው
    ///
    /// ```
    /// println!("\\u{{2764}}\\u{{a}}\\u{{21}}");
    /// ```
    ///
    /// `to_string` ን በመጠቀም
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_unicode().to_string(), "\\u{2764}\\u{a}\\u{21}");
    /// ```
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_unicode(&self) -> EscapeUnicode<'_> {
        EscapeUnicode { inner: self.chars().flat_map(CharEscapeUnicode) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<[u8]> for str {
    #[inline]
    fn as_ref(&self) -> &[u8] {
        self.as_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Default for &str {
    /// ባዶ str ይፈጥራል
    #[inline]
    fn default() -> Self {
        ""
    }
}

#[stable(feature = "default_mut_str", since = "1.28.0")]
impl Default for &mut str {
    /// ባዶ የሚለዋወጥ ስተርን ይፈጥራል
    #[inline]
    fn default() -> Self {
        // ደህንነት: ባዶው ገመድ ትክክለኛ UTF-8 ነው።
        unsafe { from_utf8_unchecked_mut(&mut []) }
    }
}

impl_fn_for_zst! {
    /// ስም ያለው ፣ ብቸኛ የሆነ የ fn ዓይነት
    #[derive(Clone)]
    struct LinesAnyMap impl<'a> Fn = |line: &'a str| -> &'a str {
        let l = line.len();
        if l > 0 && line.as_bytes()[l - 1] == b'\r' { &line[0 .. l - 1] }
        else { line }
    };

    #[derive(Clone)]
    struct CharEscapeDebugContinue impl Fn = |c: char| -> char::EscapeDebug {
        c.escape_debug_ext(false)
    };

    #[derive(Clone)]
    struct CharEscapeUnicode impl Fn = |c: char| -> char::EscapeUnicode {
        c.escape_unicode()
    };
    #[derive(Clone)]
    struct CharEscapeDefault impl Fn = |c: char| -> char::EscapeDefault {
        c.escape_default()
    };

    #[derive(Clone)]
    struct IsWhitespace impl Fn = |c: char| -> bool {
        c.is_whitespace()
    };

    #[derive(Clone)]
    struct IsAsciiWhitespace impl Fn = |byte: &u8| -> bool {
        byte.is_ascii_whitespace()
    };

    #[derive(Clone)]
    struct IsNotEmpty impl<'a, 'b> Fn = |s: &'a &'b str| -> bool {
        !s.is_empty()
    };

    #[derive(Clone)]
    struct BytesIsNotEmpty impl<'a, 'b> Fn = |s: &'a &'b [u8]| -> bool {
        !s.is_empty()
    };

    #[derive(Clone)]
    struct UnsafeBytesToStr impl<'a> Fn = |bytes: &'a [u8]| -> &'a str {
        // ደህንነት-ደህና አይደለም
        unsafe { from_utf8_unchecked(bytes) }
    };
}