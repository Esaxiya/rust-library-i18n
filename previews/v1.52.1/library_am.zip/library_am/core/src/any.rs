//! ይህ ሞዱል መሳሪያዎች የሚፈጀውን ነጸብራቅ በኩል ማንኛውም `'static` አይነት ተለዋዋጭ መተየብ ያስችላል ያለውን `Any` trait,.
//!
//! `Any` እሱ `TypeId` ን ለማግኘት ሊያገለግል ይችላል ፣ እና እንደ trait ነገር ሲጠቀሙ ተጨማሪ ባህሪዎች አሉት።
//! እንደ `&dyn Any` (የተዋሰው trait ነገር) ፣ የ `is` እና `downcast_ref` ዘዴዎች አሉት ፣ በውስጡ ያለው እሴት የተሰጠው ዓይነት መሆኑን ለመፈተሽ እና እንደ ውስጡ ውስጣዊ እሴት ማጣቀሻ ለማግኘት ፡፡
//! ወደ‹XXXXXXXXXXXXXXXXXXXX›››››››››››››››››››››››››››››››››››››››››››››››››››››››››››››››››››››››››››››››››››››››››››››››››››››››››››››››››››››››››››››››››››››››››››››››››››››››››››››››››››››››››››››››››››››››››››››››››››››››››ም
//! `Box<dyn Any>` ወደ `Box<T>` ለመቀየር የሚሞክር የ `downcast` ዘዴን ያክላል።
//! ለሙሉ ዝርዝሮች የ [`Box`] ሰነድን ይመልከቱ ፡፡
//!
//! `&dyn Any` አንድ እሴት ከተጠቀሰው የኮንክሪት ዓይነት መሆኑን ለመፈተሽ የተወሰነ መሆኑን ልብ ይበሉ ፣ እና አንድ ዓይነት‹trait›ን ተግባራዊ ለማድረግ ለመሞከር ሊያገለግል አይችልም ፡፡
//!
//! [`Box`]: ../../std/boxed/struct.Box.html
//!
//! # ስማርት ጠቋሚዎች እና `dyn Any`
//!
//! `Any` ን እንደ trait ነገር ሲጠቀሙ ልብ ሊሉት የሚገባ አንድ ባህሪ ፣ በተለይም እንደ `Box<dyn Any>` ወይም `Arc<dyn Any>` ካሉ አይነቶች ጋር ፣ `.type_id()` ን በእሴቱ ላይ መደወል በቀላሉ የ trait ነገርን ሳይሆን የ‹ኮንቴይነር›`TypeId` ን ያስገኛል ፡፡
//!
//! ይልቁንም ብልጥ ጠቋሚውን ወደ `&dyn Any` በመለወጥ ሊወገድ ይችላል ፣ ይህም የነገሩን `TypeId` ይመልሳል።
//! ለምሳሌ:
//!
//! ```
//! use std::any::{Any, TypeId};
//!
//! let boxed: Box<dyn Any> = Box::new(3_i32);
//!
//! // ይህን ይፈልጋሉ ዕድላቸው ነዎት:
//! let actual_id = (&*boxed).type_id();
//! // ከዚህ ይልቅ
//! let boxed_id = boxed.type_id();
//!
//! assert_eq!(actual_id, TypeId::of::<i32>());
//! assert_eq!(boxed_id, TypeId::of::<Box<dyn Any>>());
//! ```
//!
//! # Examples
//!
//! ወደ ተግባር የተላለፈውን እሴት ማውጣት የምንፈልግበትን ሁኔታ እንመልከት ፡፡
//! Debug ን በመተግበር ላይ የምንሰራውን ዋጋ እናውቃለን ፣ ግን ተጨባጭ የሆነውን አናውቅም ፡፡እኛ የተወሰኑ አይነት ልዩ ህክምና መስጠት ይፈልጋሉ; በዚህ ጉዳይ ላይ ሕብረቁምፊ ርዝመት ውጭ ማተም ያላቸውን ዋጋ በፊት ይመለከተዋል.
//! በምናጠናቅቅበት ጊዜ የእሴታችንን ተጨባጭ ዓይነት አናውቅም ፣ ስለሆነም በምትኩ የአሂድ ነፀብራቅን መጠቀም አለብን ፡፡
//!
//! ```rust
//! use std::fmt::Debug;
//! use std::any::Any;
//!
//! // ማረምን ለሚፈጽም ማንኛውም ዓይነት ሎግገር ተግባር።
//! fn log<T: Any + Debug>(value: &T) {
//!     let value_any = value as &dyn Any;
//!
//!     // የእኛን እሴት ወደ `String` ለመቀየር ይሞክሩ።
//!     // ከተሳካ የ String` ን ርዝመት እንዲሁም ዋጋውን ማመንጨት እንፈልጋለን።
//!     // ካልሆነ ግን የተለየ ዓይነት ነው-ያለ ጌጥ ያትሙት ፡፡
//!     match value_any.downcast_ref::<String>() {
//!         Some(as_string) => {
//!             println!("String ({}): {}", as_string.len(), as_string);
//!         }
//!         None => {
//!             println!("{:?}", value);
//!         }
//!     }
//! }
//!
//! // ይህ ተግባር ከእሱ ጋር ሥራ ከመሥራቱ በፊት ልኬቱን ለማስወጣት ይፈልጋል።
//! fn do_work<T: Any + Debug>(value: &T) {
//!     log(value);
//!     // ... ሌላ ሥራ መሥራት
//! }
//!
//! fn main() {
//!     let my_string = "Hello World".to_string();
//!     do_work(&my_string);
//!
//!     let my_i8: i8 = 100;
//!     do_work(&my_i8);
//! }
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::intrinsics;

///////////////////////////////////////////////////////////////////////////////
// ማንኛውም trait
///////////////////////////////////////////////////////////////////////////////

/// ተለዋዋጭ ትየባን ለመምሰል አንድ trait
///
/// አብዛኛዎቹ ዓይነቶች `Any` ን ይተገብራሉ።ይሁን እንጂ, አንድ ያልሆኑ `'static` ማጣቀሻ የያዘ ማንኛውም አይነት አያደርግም.
/// ተጨማሪ ዝርዝሮችን ለማግኘት [module-level documentation][mod] ይመልከቱ.
///
/// [mod]: crate::any
// ደህንነቱ ባልተጠበቀ ኮድ (ለምሳሌ `downcast`) በሆነው ብቸኛ ኢምፕል `type_id` ተግባር ላይ ብቻ የምንመካ ቢሆንም ይህ trait ደህንነቱ የተጠበቀ አይደለም ፡፡በተለምዶ, አንድ ችግር ነበር, ነገር ግን `Any` ብቸኛው impl ብርድ ልብስ ትግበራ ስለሆነ, ሌላ ኮድ `Any` ተግባራዊ ይችላሉ.
//
// ይህንን trait ደህንነቱ በተጠበቀ ሁኔታ ደህንነቱ የተጠበቀ ማድረግ እንችል ነበር-መሰባበርን አያስከትልም ፣ ምክንያቱም ሁሉንም አተገባበር ስለምንቆጣጠር-ግን መምረጥ የለብንም ፣ ምክንያቱም ይህ በጣም አስፈላጊ ስላልሆነ እና ደህንነቱ ያልተጠበቀ traits እና ደህንነቱ ያልተጠበቀ ዘዴዎች ልዩነት ተጠቃሚዎችን ግራ ሊያጋባ ይችላል ፡፡ `type_id` ለመደወል አሁንም ደህንነቱ የተጠበቀ ነበር ፣ ግን በሰነዶች ውስጥ እንደዛ ለማመልከት እንፈልግ ይሆናል)
//
//
//
//
//
//
//
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Any: 'static {
    /// የ `self` `TypeId` ን ያገኛል።
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string(s: &dyn Any) -> bool {
    ///     TypeId::of::<String>() == s.type_id()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "get_type_id", since = "1.34.0")]
    fn type_id(&self) -> TypeId;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: 'static + ?Sized> Any for T {
    fn type_id(&self) -> TypeId {
        TypeId::of::<T>()
    }
}

///////////////////////////////////////////////////////////////////////////////
// ማንኛውም trait ነገሮችን የቅጥያ ዘዴዎች.
///////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

// ለምሳሌ ፣ ክር መቀላቀል ውጤቱ ታትሞ ከ `unwrap` ጋር ጥቅም ላይ መዋል እንደሚችል ያረጋግጡ።
// መላኪያ ከተራቀቀ ጋር የሚሰራ ከሆነ በመጨረሻ ከእንግዲህ አያስፈልግ ይሆናል ፡፡
//
#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any + Send {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

#[stable(feature = "any_send_sync_methods", since = "1.28.0")]
impl fmt::Debug for dyn Any + Send + Sync {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

impl dyn Any {
    /// የቦክስ ዓይነት ከ `T` ጋር ተመሳሳይ ከሆነ `true` ን ይመልሳል።
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &dyn Any) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        // ይህ ተግባር ከተሰራበት ዓይነት `TypeId` ን ያግኙ።
        let t = TypeId::of::<T>();

        // በ trait ነገር (`self`) ውስጥ ያለውን ዓይነት `TypeId` ያግኙ።
        let concrete = self.type_id();

        // በእኩልነት ላይ ሁለቱንም‹TypeId›ን ያነፃፅሩ ፡፡
        t == concrete
    }

    /// አይደለም ከሆነ አይነት `T`, ወይም `None` ነው ከሆነ በሳጥን እሴት አንዳንድ ማጣቀሻ ይመልሳል.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &dyn Any) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        if self.is::<T>() {
            // ደህንነት-እኛ ወደ ትክክለኛው ዓይነት እየጠቆምን እንደሆነ ብቻ አረጋግጠናል እናም በእሱ ላይ መተማመን እንችላለን
            // ትውስታ ደህንነት ለ ቼክ እኛ ሁሉም ዓይነቶች ማንኛውም በተግባር ምክንያት መሆኑን;እነሱ የእኛን impl ጋር የሚጋጭ ነበር እንደ ሌላ ምንም impls ሊኖር ይችላል.
            //
            unsafe { Some(&*(self as *const dyn Any as *const T)) }
        } else {
            None
        }
    }

    /// አይደለም ከሆነ አይነት `T`, ወይም `None` ነው ከሆነ በሳጥን እሴት አንዳንድ ሊቀየሩ ማጣቀሻ ይመልሳል.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut dyn Any) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        if self.is::<T>() {
            // ደህንነት-እኛ ወደ ትክክለኛው ዓይነት እየጠቆምን እንደሆነ ብቻ አረጋግጠናል እናም በእሱ ላይ መተማመን እንችላለን
            // ትውስታ ደህንነት ለ ቼክ እኛ ሁሉም ዓይነቶች ማንኛውም በተግባር ምክንያት መሆኑን;እነሱ የእኛን impl ጋር የሚጋጭ ነበር እንደ ሌላ ምንም impls ሊኖር ይችላል.
            //
            unsafe { Some(&mut *(self as *mut dyn Any as *mut T)) }
        } else {
            None
        }
    }
}

impl dyn Any + Send {
    /// በ `Any` ዓይነት ላይ ለተገለጸው ዘዴ ወደፊት።
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// በ `Any` ዓይነት ላይ ለተገለጸው ዘዴ ወደፊት።
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// በ `Any` ዓይነት ላይ ለተገለጸው ዘዴ ወደፊት።
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

impl dyn Any + Send + Sync {
    /// በ `Any` ዓይነት ላይ ለተገለጸው ዘዴ ወደፊት።
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send + Sync)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// በ `Any` ዓይነት ላይ ለተገለጸው ዘዴ ወደፊት።
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send + Sync)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// በ `Any` ዓይነት ላይ ለተገለጸው ዘዴ ወደፊት።
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send + Sync)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

///////////////////////////////////////////////////////////////////////////////
// ታይፕአይዲ እና ዘዴዎቹ
///////////////////////////////////////////////////////////////////////////////

/// ኤክስኤክስኤክስ ለአንድ ዓይነት በዓለም አቀፍ ደረጃ ልዩ መለያዎችን ይወክላል ፡፡
///
/// እያንዳንዱ `TypeId` ውስጥ ነው ምን ፍተሻ አይፈቅድም ነገር ግን እንዲህ, በክሎኒንግ ንጽጽር, ማተም, እና በማሳየት እንደ መሠረታዊ ቀዶ የሚፈቅደው ይህም የኦፔክ ነገር ነው.
///
///
/// `TypeId` በአሁኑ ጊዜ ለ `'static` ለሚሰጡ ዓይነቶች ብቻ ይገኛል ፣ ግን ይህ ውስንነት በ future ውስጥ ሊወገድ ይችላል።
///
/// `TypeId` `Hash` ፣ `PartialOrd` እና `Ord` ን ሲተገብር ፣ ሃሽዎች እና ቅደም ተከተሎች በ Rust ልቀቶች መካከል እንደሚለያዩ ልብ ማለት ይገባል ፡፡
/// በኮድዎ ውስጥ በውስጣቸው ከመታመን ይጠንቀቁ!
///
///
///
#[derive(Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Debug, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct TypeId {
    t: u64,
}

impl TypeId {
    /// ይህ አጠቃላይ ተግባር በቅጽበት የተሠራበትን `TypeId` ን ይመልሳል።
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string<T: ?Sized + Any>(_s: &T) -> bool {
    ///     TypeId::of::<String>() == TypeId::of::<T>()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub const fn of<T: ?Sized + 'static>() -> TypeId {
        TypeId { t: intrinsics::type_id::<T>() }
    }
}

/// የአንድ አይነት ስም እንደ ሕብረቁምፊ ቁራጭ ይመልሳል።
///
/// # Note
///
/// ይህ ለምርመራ አገልግሎት የታሰበ ነው ፡፡
/// ትክክለኛ ይዘቶችን እና የተመለሱ ሕብረቁምፊ ቅርጸት አይነት የሆነ ምርጥ-ጥረት መግለጫ ከመሆን ይልቅ ሌላ, አልተገለጸም ነው.
/// ለምሳሌ ፣ `type_name::<Option<String>>()` ሊመልሳቸው ከሚችላቸው ሕብረቁምፊዎች መካከል `"Option<String>"` እና `"std::option::Option<std::string::String>"` ናቸው ፡፡
///
///
/// ብዙ ዓይነቶች ወደ አንድ ዓይነት ስም ካርታ ሊያደርጉ ስለሚችሉ የተመለሰው ሕብረቁምፊ የአንድ ዓይነት ልዩ መለያ ነው ተብሎ መታሰብ የለበትም ፡፡
/// በተመሳሳይ ሁኔታ ፣ ሁሉም የአንድ ዓይነት ክፍሎች በተመለሰው ሕብረቁምፊ ውስጥ እንደሚታዩ ምንም ማረጋገጫ የለም ፣ ለምሳሌ ፣ የሕይወት ዘመን አመልካቾች በአሁኑ ጊዜ አልተካተቱም።
/// በተጨማሪም ፣ ውጤቱ በአቀራባዩ ስሪቶች መካከል ሊለወጥ ይችላል።
///
/// አሁን ያለው ትግበራ እንደ አጠናቃሪ ዲያግኖስቲክስ እና ዲጊንፎን ተመሳሳይ መሠረተ ልማት ይጠቀማል ፣ ግን ይህ ዋስትና የለውም።
///
/// # Examples
///
/// ```rust
/// assert_eq!(
///     std::any::type_name::<Option<String>>(),
///     "core::option::Option<alloc::string::String>",
/// );
/// ```
///
///
///
///
#[stable(feature = "type_name", since = "1.38.0")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name<T: ?Sized>() -> &'static str {
    intrinsics::type_name::<T>()
}

/// ሕብረቁምፊ ቁራጭ እንደ ጫፍ-ወደ ዋጋ ዓይነት ስም ያወጣል.
/// ይህ `type_name::<T>()` ጋር ተመሳሳይ ነው, ነገር ግን አንድ ተለዋዋጭ ዓይነት በቀላሉ አይገኝም ቦታ ጥቅም ላይ ሊውል ይችላል.
///
/// # Note
///
/// ይህ ለምርመራ አገልግሎት የታሰበ ነው ፡፡የዓይነቱ ምርጥ-ጥረት መግለጫ ከመሆን ውጭ የሕብረቁምፊው ትክክለኛ ይዘት እና ቅርጸት አልተገለጸም ፡፡
/// ለምሳሌ ፣ `type_name_of_val::<Option<String>>(None)` `"Option<String>"` ወይም `"std::option::Option<std::string::String>"` ን መመለስ ይችላል ፣ ግን `"foobar"` አይደለም ፡፡
///
/// በተጨማሪም ፣ ውጤቱ በአቀራባዩ ስሪቶች መካከል ሊለወጥ ይችላል።
///
/// ይህ ተግባር የ trait ነገሮችን አይፈታውም ፣ ማለትም `type_name_of_val(&7u32 as &dyn Debug)` `"dyn Debug"` ን ሊመልስ ይችላል ፣ ግን `"u32"` አይደለም ፡፡
///
/// የዓይነቱ ስም የአንድ ዓይነት ልዩ መለያ ተደርጎ መታየት የለበትም ፡፡
/// በርካታ ዓይነቶች ተመሳሳይ ዓይነት ስም ልናጋራ እንችላለን.
///
/// አሁን ያለው ትግበራ እንደ አጠናቃሪ ዲያግኖስቲክስ እና ዲጊንፎን ተመሳሳይ መሠረተ ልማት ይጠቀማል ፣ ግን ይህ ዋስትና የለውም።
///
/// # Examples
///
/// ነባሪው የቁጥር እና ተንሳፋፊ ዓይነቶችን ያትማል።
///
/// ```rust
/// #![feature(type_name_of_val)]
/// use std::any::type_name_of_val;
///
/// let x = 1;
/// println!("{}", type_name_of_val(&x));
/// let y = 1.0;
/// println!("{}", type_name_of_val(&y));
/// ```
///
///
///
///
///
///
#[unstable(feature = "type_name_of_val", issue = "66359")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name_of_val<T: ?Sized>(_val: &T) -> &'static str {
    type_name::<T>()
}