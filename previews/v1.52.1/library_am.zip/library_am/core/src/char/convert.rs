//! ቁምፊ ልወጣዎች.

use crate::convert::TryFrom;
use crate::fmt;
use crate::mem::transmute;
use crate::str::FromStr;

use super::MAX;

/// `u32` ን ወደ `char` ይቀይረዋል።
///
/// ሁሉም [`ቻር`] ልክ [`u32`] ዎች መሆናቸውን እና ወደ አንዱ መጣል እንደሚችሉ ልብ ይበሉ
/// `as`:
///
/// ```
/// let c = '💯';
/// let i = c as u32;
///
/// assert_eq!(128175, i);
/// ```
///
/// ይሁን እንጂ በተገላቢጦሽ እውነት አይደለም; ሁሉም ትክክለኛ [`u32`] ን ናቸው ልክ [`char`] ዎች.
/// `from_u32()` ግብዓቱ ለ [`char`] ትክክለኛ እሴት ካልሆነ `None` ን ይመልሳል።
///
/// እነዚህን ቼኮች ችላ ለሚለው ደህንነቱ ያልተጠበቀ የዚህ ተግባር ስሪት ፣ [`from_u32_unchecked`] ን ይመልከቱ ፡፡
///
///
/// # Examples
///
/// መሠረታዊ አጠቃቀም
///
/// ```
/// use std::char;
///
/// let c = char::from_u32(0x2764);
///
/// assert_eq!(Some('❤'), c);
/// ```
///
/// የግቤት የሚሰራ [`char`] አይደለም ጊዜ `None` በመመለስ:
///
/// ```
/// use std::char;
///
/// let c = char::from_u32(0x110000);
///
/// assert_eq!(None, c);
/// ```
///
#[doc(alias = "chr")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_u32(i: u32) -> Option<char> {
    char::try_from(i).ok()
}

/// ፀንቶ ችላ አንድ `char` አንድ `u32`, ይለውጣል.
///
/// ሁሉም [`ቻር`] ልክ [`u32`] ዎች መሆናቸውን እና ወደ አንዱ መጣል እንደሚችሉ ልብ ይበሉ
/// `as`:
///
/// ```
/// let c = '💯';
/// let i = c as u32;
///
/// assert_eq!(128175, i);
/// ```
///
/// ይሁን እንጂ በተገላቢጦሽ እውነት አይደለም; ሁሉም ትክክለኛ [`u32`] ን ናቸው ልክ [`char`] ዎች.
/// `from_u32_unchecked()` ይህን ችላ, እና በጭፍን ምናልባትም ልክ ያልሆነ ሰው በመፍጠር, [`char`] ወደ ይጣላል ይሆናል.
///
///
/// # Safety
///
/// ይህ ልክ `char` እሴቶች መገንባት ይችላል ይህ ተግባር, ደህንነቱ ያልተጠበቀ ነው.
///
/// ደህንነቱ የተጠበቀ የዚህ ተግባር ስሪት ለማግኘት የ [`from_u32`] ተግባርን ይመልከቱ።
///
/// # Examples
///
/// መሠረታዊ አጠቃቀም
///
/// ```
/// use std::char;
///
/// let c = unsafe { char::from_u32_unchecked(0x2764) };
///
/// assert_eq!('❤', c);
/// ```
#[inline]
#[stable(feature = "char_from_unchecked", since = "1.5.0")]
pub unsafe fn from_u32_unchecked(i: u32) -> char {
    // ደህንነት-ደዋዩ `i` ትክክለኛ የቻር ዋጋ መሆኑን ማረጋገጥ አለበት ፡፡
    if cfg!(debug_assertions) { char::from_u32(i).unwrap() } else { unsafe { transmute(i) } }
}

#[stable(feature = "char_convert", since = "1.13.0")]
impl From<char> for u32 {
    /// አንድ [`u32`] ወደ አንድ [`char`] ይቀይራል.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = 'c';
    /// let u = u32::from(c);
    /// assert!(4 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        c as u32
    }
}

#[stable(feature = "more_char_conversions", since = "1.51.0")]
impl From<char> for u64 {
    /// [`char`] ን ወደ [`u64`] ይቀይረዋል።
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = '👤';
    /// let u = u64::from(c);
    /// assert!(8 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        // ወደ ቁምፊ ኮድ ነጥብ ዋጋ ወደ ያልሰጠው ነው, ከዚያም 64 ቢት ወደ ዜሮ-ይዘልቃል.
        // [https://doc.rust-lang.org/reference/expressions/operator-expr.html#semantics] ን ይመልከቱ
        c as u64
    }
}

#[stable(feature = "more_char_conversions", since = "1.51.0")]
impl From<char> for u128 {
    /// [`char`] ን ወደ [`u128`] ይቀይረዋል።
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = '⚙';
    /// let u = u128::from(c);
    /// assert!(16 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        // ቻርዱ ወደ ኮዱ ነጥብ ዋጋ ይጣላል ፣ ከዚያ በዜሮ ወደ 128 ቢት ይረዝማል።
        // [https://doc.rust-lang.org/reference/expressions/operator-expr.html#semantics] ን ይመልከቱ
        c as u128
    }
}

/// የማን ኮድ ነጥብ ተመሳሳይ እሴት አለው, U + 0000 ..=U + 00FF ውስጥ `char` ወደ 0x00 ውስጥ ካርታዎች አንድ ባይት ..=0xFF.
///
/// ዩኒኮድ ይህን ውጤታማ በሆነ IANA ISO-8859-1 የሚጠራውን ገጸ በኮድ ጋር ባይት decodes እንደዚህ የተዘጋጀ ነው.
/// ይህ ኢንኮዲንግ ከ ASCII ጋር ተኳሃኝ ነው።
///
/// ይህ ከ ISO/IEC 8859-1 aka የተለየ መሆኑን ልብ ይበሉ
/// አይ ኤስ 8859-1 (ከአንድ ያነሰ ሰረዝ ጋር) ፣ እሱም የተወሰኑ "blanks" ን የሚተው ፣ ለማንኛውም ባህሪ የማይመደቡ የባይት እሴቶች።
/// አይኤስኦኦ-8859-1 (አይኤንአን አንድ) ለ C0 እና C1 ቁጥጥር ኮዶች ይሰጣቸዋል ፡፡
///
/// ይህ ከዊንዶውስ-1252 አካ የተለየ *እንዲሁ* የተለየ መሆኑን ልብ ይበሉ
/// ኮድ ገጽ 1252 ፣ እሱም ስርዓተ-ነጥብ እና የተለያዩ የላቲን ገጸ-ባህሪያትን አንዳንድ (ሁሉንም አይደለም!) ባዶዎችን የሚመድብ ልዕለ-ልዕለ-ISO/IEC 8859-1 ነው።
///
/// ተጨማሪ ነገሮች ግራ ለማጋባት, [on the Web](https://encoding.spec.whatwg.org/) `ascii`, `iso-8859-1` እና `windows-1252` C0 እና C1 ቁጥጥር ኮዶች ተጓዳኝ ጋር ቀሪ ቦታዎቹን የሚያስተጋባው የ Windows-1252 አንድ superset ሁሉ ቅጽሎች ናቸው.
///
///
///
///
///
#[stable(feature = "char_convert", since = "1.13.0")]
impl From<u8> for char {
    /// አንድ [`char`] ወደ አንድ [`u8`] ይቀይራል.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let u = 32 as u8;
    /// let c = char::from(u);
    /// assert!(4 == mem::size_of_val(&c))
    /// ```
    #[inline]
    fn from(i: u8) -> Self {
        i as char
    }
}

/// ቻርጅ በሚተነተንበት ጊዜ ሊመለስ የሚችል ስህተት።
#[stable(feature = "char_from_str", since = "1.20.0")]
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct ParseCharError {
    kind: CharErrorKind,
}

impl ParseCharError {
    #[unstable(
        feature = "char_error_internals",
        reason = "this method should not be available publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            CharErrorKind::EmptyString => "cannot parse char from empty string",
            CharErrorKind::TooManyChars => "too many characters in string",
        }
    }
}

#[derive(Copy, Clone, Debug, PartialEq, Eq)]
enum CharErrorKind {
    EmptyString,
    TooManyChars,
}

#[stable(feature = "char_from_str", since = "1.20.0")]
impl fmt::Display for ParseCharError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}

#[stable(feature = "char_from_str", since = "1.20.0")]
impl FromStr for char {
    type Err = ParseCharError;

    #[inline]
    fn from_str(s: &str) -> Result<Self, Self::Err> {
        let mut chars = s.chars();
        match (chars.next(), chars.next()) {
            (None, _) => Err(ParseCharError { kind: CharErrorKind::EmptyString }),
            (Some(c), None) => Ok(c),
            _ => Err(ParseCharError { kind: CharErrorKind::TooManyChars }),
        }
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl TryFrom<u32> for char {
    type Error = CharTryFromError;

    #[inline]
    fn try_from(i: u32) -> Result<Self, Self::Error> {
        if (i > MAX as u32) || (i >= 0xD800 && i <= 0xDFFF) {
            Err(CharTryFromError(()))
        } else {
            // ደህንነት-የህጋዊ የዩኒኮድ እሴት መሆኑን አረጋግጧል
            Ok(unsafe { transmute(i) })
        }
    }
}

/// ከ u32 ወደ ቻር መለወጥ መለወጥ ሳይሳካ ሲቀር የስህተት ዓይነቱ ተመልሷል ፡፡
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct CharTryFromError(());

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for CharTryFromError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        "converted integer out of range for `char`".fmt(f)
    }
}

/// በተሰጠው ራዲክስ ውስጥ አንድ አሃዝ ወደ `char` ይቀይረዋል።
///
/// እዚህ ላይ አንድ 'radix' አንዳንድ ጊዜ ደግሞ አንድ 'base' ይባላል.
/// ሁለት አንድ ራዲክስ አንዳንድ የጋራ እሴቶችን ለመስጠት የሁለትዮሽ ቁጥርን ፣ የአስር ራዲክስ እና የአስራ ስድስት ራዲክስን ያመለክታል ፣ ስድስት ሄክሳዴሲማል።
///
/// የዘፈቀደ radices ይደገፋሉ.
///
/// `from_digit()` የግቤት የተሰጠው radix ውስጥ አኃዝ አይደለም ከሆነ `None` ይመለሳሉ.
///
/// # Panics
///
/// የተሰጠ ከሆነ Panics ትልቅ ከ 36 radix.
///
/// # Examples
///
/// መሠረታዊ አጠቃቀም
///
/// ```
/// use std::char;
///
/// let c = char::from_digit(4, 10);
///
/// assert_eq!(Some('4'), c);
///
/// // አስርዮሽ 11 በመሠረቱ 16 ውስጥ አንድ አሃዝ ነው
/// let c = char::from_digit(11, 16);
///
/// assert_eq!(Some('b'), c);
/// ```
///
/// ግብዓቱ አሃዝ በማይሆንበት ጊዜ `None` ን መመለስ:
///
/// ```
/// use std::char;
///
/// let c = char::from_digit(20, 10);
///
/// assert_eq!(None, c);
/// ```
///
/// አንድ panic መንስኤ, አንድ ትልቅ radix ማለፊያ:
///
/// ```should_panic
/// use std::char;
///
/// // this panics
/// let c = char::from_digit(1, 37);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_digit(num: u32, radix: u32) -> Option<char> {
    if radix > 36 {
        panic!("from_digit: radix is too high (maximum 36)");
    }
    if num < radix {
        let num = num as u8;
        if num < 10 { Some((b'0' + num) as char) } else { Some((b'a' + num - 10) as char) }
    } else {
        None
    }
}