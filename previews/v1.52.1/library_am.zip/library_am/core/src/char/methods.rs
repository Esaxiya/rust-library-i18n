//! impl char {}

use crate::intrinsics::likely;
use crate::slice;
use crate::str::from_utf8_unchecked_mut;
use crate::unicode::printable::is_printable;
use crate::unicode::{self, conversions};

use super::*;

#[lang = "char"]
impl char {
    /// አንድ `char` ሊኖረው የሚችለው ከፍተኛው የሚሰራ ኮድ ነጥብ.
    ///
    /// `char` [Unicode Scalar Value] ነው ፣ ይህ ማለት እሱ [Code Point] ነው ፣ ግን በተወሰነ ክልል ውስጥ ያሉ ብቻ ነው።
    /// `MAX` ትክክለኛ [Unicode Scalar Value] የሆነ ከፍተኛው ትክክለኛ ኮድ ነጥብ ነው።
    ///
    /// [Unicode Scalar Value]: http://www.unicode.org/glossary/#unicode_scalar_value
    /// [Code Point]: http://www.unicode.org/glossary/#code_point
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const MAX: char = '\u{10ffff}';

    /// `U+FFFD REPLACEMENT CHARACTER` () አንድ መግለጥን ስህተት የሚወክል ዩኒኮድ ውስጥ ጥቅም ላይ ነው.
    ///
    /// ይህ ሊከሰት ለምሳሌ ያህል, ጊዜ UTF-8 [`String::from_utf8_lossy`](string/struct.String.html#method.from_utf8_lossy) ወደ ባይት ታሞ-ተቋቋመ መስጠት ይችላሉ.
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const REPLACEMENT_CHARACTER: char = '\u{FFFD}';

    /// [Unicode](http://www.unicode.org/) ያለው ስሪት `char` እና `str` ዘዴዎች የዩኒኮድ ክፍሎች ላይ የተመሠረቱ ናቸው.
    ///
    /// አዳዲስ የዩኒኮድ ስሪቶች በመደበኛነት የተለቀቁ ሲሆን ከዚያ በኋላ በመደበኛ ቤተመፃህፍት ውስጥ ያሉት ሁሉም ዘዴዎች በዩኒኮድ ላይ ተመስርተዋል ፡፡
    /// ስለዚህ አንዳንድ `char` እና `str` ዘዴዎች ባህሪ በዚህ የማያቋርጥ ዋጋ ከጊዜ ወደ ጊዜ ይለወጣል.
    /// ይህ * እንደ ሰበር ለውጥ ተደርጎ አይቆጠርም።
    ///
    /// የ ስሪት ቁጥር መርሐግብር [Unicode 11.0 or later, Section 3.1 Versions of the Unicode Standard](https://www.unicode.org/versions/Unicode11.0.0/ch03.pdf#page=4) ውስጥ ተብራርቷል.
    ///
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const UNICODE_VERSION: (u8, u8, u8) = crate::unicode::UNICODE_VERSION;

    /// በ‹XXXX›ውስጥ ባለው የ UTF-16 encoded ኮድ ነጥቦች ላይ ተደጋጋሚ ሠራተኛን ይፈጥራል ፣ ያልደረሱ ተተኪዎችን እንደ‹Err`s ይመልሳል ፡፡
    ///
    ///
    /// # Examples
    ///
    /// መሠረታዊ አጠቃቀም
    ///
    /// ```
    /// use std::char::decode_utf16;
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///         .map(|r| r.map_err(|e| e.unpaired_surrogate()))
    ///         .collect::<Vec<_>>(),
    ///     vec![
    ///         Ok('𝄞'),
    ///         Ok('m'), Ok('u'), Ok('s'),
    ///         Err(0xDD1E),
    ///         Ok('i'), Ok('c'),
    ///         Err(0xD834)
    ///     ]
    /// );
    /// ```
    ///
    /// የ‹XXXX›ውጤቶችን በተተኪው ባህሪ በመተካት ኪሳራ ዲኮደር ማግኘት ይቻላል-
    ///
    /// ```
    /// use std::char::{decode_utf16, REPLACEMENT_CHARACTER};
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///        .map(|r| r.unwrap_or(REPLACEMENT_CHARACTER))
    ///        .collect::<String>(),
    ///     "𝄞mus�ic�"
    /// );
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn decode_utf16<I: IntoIterator<Item = u16>>(iter: I) -> DecodeUtf16<I::IntoIter> {
        super::decode::decode_utf16(iter)
    }

    /// `u32` ን ወደ `char` ይቀይረዋል።
    ///
    /// ሁሉም `ቻርቶች` ልክ [`u32`] ዎች መሆናቸውን እና ወደ አንዱ መጣል እንደሚችሉ ልብ ይበሉ
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// ሆኖም ፣ የተገላቢጦሹ እውነት አይደለም-ሁሉም ትክክለኛ [`u32`] ዎች ትክክለኛ` ቻርዶች አይደሉም ፡፡
    /// `from_u32()` የግቤት አንድ `char` ትክክለኛ ዋጋ አይደለም ከሆነ `None` ይመለሳሉ.
    ///
    /// እነዚህን ቼኮች ችላ ለሚለው ደህንነቱ ያልተጠበቀ የዚህ ተግባር ስሪት ፣ [`from_u32_unchecked`] ን ይመልከቱ ፡፡
    ///
    ///
    /// [`from_u32_unchecked`]: #method.from_u32_unchecked
    ///
    /// # Examples
    ///
    /// መሠረታዊ አጠቃቀም
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x2764);
    ///
    /// assert_eq!(Some('❤'), c);
    /// ```
    ///
    /// የግቤት የሚሰራ `char` አይደለም ጊዜ `None` በመመለስ:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x110000);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_u32(i: u32) -> Option<char> {
        super::convert::from_u32(i)
    }

    /// ፀንቶ ችላ አንድ `char` አንድ `u32`, ይለውጣል.
    ///
    /// ሁሉም `ቻርቶች` ልክ [`u32`] ዎች መሆናቸውን እና ወደ አንዱ መጣል እንደሚችሉ ልብ ይበሉ
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// ሆኖም ፣ የተገላቢጦሹ እውነት አይደለም-ሁሉም ትክክለኛ [`u32`] ዎች ትክክለኛ` ቻርዶች አይደሉም ፡፡
    /// `from_u32_unchecked()` ይህንን ችላ ማለት እና ልክ ያልሆነን በመፍጠር በጭፍን ወደ `char` ይጣላል ፡፡
    ///
    ///
    /// # Safety
    ///
    /// ይህ ልክ `char` እሴቶች መገንባት ይችላል ይህ ተግባር, ደህንነቱ ያልተጠበቀ ነው.
    ///
    /// ደህንነቱ የተጠበቀ የዚህ ተግባር ስሪት ለማግኘት የ [`from_u32`] ተግባርን ይመልከቱ።
    ///
    /// [`from_u32`]: #method.from_u32
    ///
    /// # Examples
    ///
    /// መሠረታዊ አጠቃቀም
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = unsafe { char::from_u32_unchecked(0x2764) };
    ///
    /// assert_eq!('❤', c);
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub unsafe fn from_u32_unchecked(i: u32) -> char {
        // ደህንነት-የደህንነቱ ውል በደዋዩ መከበር አለበት ፡፡
        unsafe { super::convert::from_u32_unchecked(i) }
    }

    /// በተሰጠው ራዲክስ ውስጥ አንድ አሃዝ ወደ `char` ይቀይረዋል።
    ///
    /// እዚህ ላይ አንድ 'radix' አንዳንድ ጊዜ ደግሞ አንድ 'base' ይባላል.
    /// ሁለት አንድ ራዲክስ አንዳንድ የጋራ እሴቶችን ለመስጠት የሁለትዮሽ ቁጥርን ፣ የአስር ራዲክስ እና የአስራ ስድስት ራዲክስን ያመለክታል ፣ ስድስት ሄክሳዴሲማል።
    ///
    /// የዘፈቀደ radices ይደገፋሉ.
    ///
    /// `from_digit()` የግቤት የተሰጠው radix ውስጥ አኃዝ አይደለም ከሆነ `None` ይመለሳሉ.
    ///
    /// # Panics
    ///
    /// የተሰጠ ከሆነ Panics ትልቅ ከ 36 radix.
    ///
    /// # Examples
    ///
    /// መሠረታዊ አጠቃቀም
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(4, 10);
    ///
    /// assert_eq!(Some('4'), c);
    ///
    /// // አስርዮሽ 11 በመሠረቱ 16 ውስጥ አንድ አሃዝ ነው
    /// let c = char::from_digit(11, 16);
    ///
    /// assert_eq!(Some('b'), c);
    /// ```
    ///
    /// ግብዓቱ አሃዝ በማይሆንበት ጊዜ `None` ን መመለስ:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(20, 10);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    /// አንድ panic መንስኤ, አንድ ትልቅ radix ማለፊያ:
    ///
    /// ```should_panic
    /// use std::char;
    ///
    /// // this panics
    /// char::from_digit(1, 37);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_digit(num: u32, radix: u32) -> Option<char> {
        super::convert::from_digit(num, radix)
    }

    /// ቼኮች አንድ `char` የተሰጠውን radix ውስጥ አኃዝ ከሆነ.
    ///
    /// እዚህ ላይ አንድ 'radix' አንዳንድ ጊዜ ደግሞ አንድ 'base' ይባላል.
    /// ሁለት አንድ ራዲክስ አንዳንድ የጋራ እሴቶችን ለመስጠት የሁለትዮሽ ቁጥርን ፣ የአስር ራዲክስ እና የአስራ ስድስት ራዲክስን ያመለክታል ፣ ስድስት ሄክሳዴሲማል።
    ///
    /// የዘፈቀደ radices ይደገፋሉ.
    ///
    /// ከ [`is_numeric()`] ጋር ሲነፃፀር ይህ ተግባር የ `0-9` ፣ `a-z` እና `A-Z` ቁምፊዎችን ብቻ ያውቃል ፡፡
    ///
    /// 'Digit' ብቻ የሚከተሉት ቁምፊዎች መሆን ማለት ነው:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// 'digit' ይበልጥ አጠቃላይ ግንዛቤ ለማግኘት, [`is_numeric()`] ተመልከት.
    ///
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Panics
    ///
    /// የተሰጠ ከሆነ Panics ትልቅ ከ 36 radix.
    ///
    /// # Examples
    ///
    /// መሠረታዊ አጠቃቀም
    ///
    /// ```
    /// assert!('1'.is_digit(10));
    /// assert!('f'.is_digit(16));
    /// assert!(!'f'.is_digit(10));
    /// ```
    ///
    /// አንድ panic መንስኤ, አንድ ትልቅ radix ማለፊያ:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.is_digit(37);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_digit(self, radix: u32) -> bool {
        self.to_digit(radix).is_some()
    }

    /// የተሰጠው radix ውስጥ አንድ አሃዝ ወደ አንድ `char` ይለውጣል.
    ///
    /// እዚህ ላይ አንድ 'radix' አንዳንድ ጊዜ ደግሞ አንድ 'base' ይባላል.
    /// ሁለት አንድ ራዲክስ አንዳንድ የጋራ እሴቶችን ለመስጠት የሁለትዮሽ ቁጥርን ፣ የአስር ራዲክስ እና የአስራ ስድስት ራዲክስን ያመለክታል ፣ ስድስት ሄክሳዴሲማል።
    ///
    /// የዘፈቀደ radices ይደገፋሉ.
    ///
    /// 'Digit' ብቻ የሚከተሉት ቁምፊዎች መሆን ማለት ነው:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// # Errors
    ///
    /// `char` በተሰጠው ራዲክስ ውስጥ ወደ አሃዝ የማይጠቅስ ከሆነ `None` ን ይመልሳል።
    ///
    /// # Panics
    ///
    /// የተሰጠ ከሆነ Panics ትልቅ ከ 36 radix.
    ///
    /// # Examples
    ///
    /// መሠረታዊ አጠቃቀም
    ///
    /// ```
    /// assert_eq!('1'.to_digit(10), Some(1));
    /// assert_eq!('f'.to_digit(16), Some(15));
    /// ```
    ///
    /// ውድቀት ውስጥ ያልሆነ-አሃዝ ውጤቶች ማለፍ:
    ///
    /// ```
    /// assert_eq!('f'.to_digit(10), None);
    /// assert_eq!('z'.to_digit(16), None);
    /// ```
    ///
    /// አንድ panic መንስኤ, አንድ ትልቅ radix ማለፊያ:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.to_digit(37);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_digit(self, radix: u32) -> Option<u32> {
        assert!(radix <= 36, "to_digit: radix is too high (maximum 36)");
        // `radix` ቋሚ እና 10 ወይም ከዚያ በታች ለሆኑ ጉዳዮች የማስፈፀሚያ ፍጥነትን ለማሻሻል ኮዱ እዚህ ተከፍሏል
        //
        let val = if likely(radix <= 10) {
            // አሃዝ ካልሆነ ከራዲክስ የበለጠ ቁጥር ይፈጠራል ፡፡
            (self as u32).wrapping_sub('0' as u32)
        } else {
            match self {
                '0'..='9' => self as u32 - '0' as u32,
                'a'..='z' => self as u32 - 'a' as u32 + 10,
                'A'..='Z' => self as u32 - 'A' as u32 + 10,
                _ => return None,
            }
        };

        if val < radix { Some(val) } else { None }
    }

    /// እንደ `ቻር` ቶች ባለ ስድስት ሄድሲሲማል ዩኒኮድ ማምለጥ አንድ ተደጋጋሚ ይመልሳል።
    ///
    /// ይህ `NNNNNN` ባለ ስድስት-ልኬት ውክልና ባለበት `\u{NNNNNN}` ቅጽ የ Rust አገባብ ቁምፊዎችን ያመልጣል።
    ///
    ///
    /// # Examples
    ///
    /// አንድ ለተደጋጋሚ እንደ:
    ///
    /// ```
    /// for c in '❤'.escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// `println!` ን በቀጥታ በመጠቀም
    ///
    /// ```
    /// println!("{}", '❤'.escape_unicode());
    /// ```
    ///
    /// ሁለቱም ከዚህ ጋር እኩል ናቸው
    ///
    /// ```
    /// println!("\\u{{2764}}");
    /// ```
    ///
    /// `to_string` ን በመጠቀም
    ///
    /// ```
    /// assert_eq!('❤'.escape_unicode().to_string(), "\\u{2764}");
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_unicode(self) -> EscapeUnicode {
        let c = self as u32;

        // or-ing 1 ለ c==0 ኮዱ አንድ አሃዝ መታተም እንዳለበት ያሰላል እና (ተመሳሳይ ነው) የ (31, 32) የውሃ ፍሰትን ያስወግዳል
        //
        //
        let msb = 31 - (c | 1).leading_zeros();

        // በጣም ጉልህ የሆነ የሄክስ አኃዝ መረጃ ጠቋሚ
        let ms_hex_digit = msb / 4;
        EscapeUnicode {
            c: self,
            state: EscapeUnicodeState::Backslash,
            hex_digit_idx: ms_hex_digit as usize,
        }
    }

    /// የተራዘመ የግራፍ ኮድ ነጥቦችን ለማምለጥ በአማራጭ የሚፈቅድ የተራዘመ የ `escape_debug` ስሪት።
    /// ይህ ለእኛ እነርሱ ሕብረቁምፊ መጀመሪያ ላይ በምትሆንበት ጊዜ በተሻለ ምልክቶች ክፍተት እንደ ቁምፊዎች ለመቅረጽ ይፈቅዳል.
    ///
    #[inline]
    pub(crate) fn escape_debug_ext(self, escape_grapheme_extended: bool) -> EscapeDebug {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            _ if escape_grapheme_extended && self.is_grapheme_extended() => {
                EscapeDefaultState::Unicode(self.escape_unicode())
            }
            _ if is_printable(self) => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDebug(EscapeDefault { state: init_state })
    }

    /// ያወጣል `char`s እንደ አንድ ቁምፊ ቃል በቃል የማምለጫ ኮድ ያፈራላቸዋል አንድ ለተደጋጋሚ.
    ///
    /// ይህ ከ `str` ወይም `char` የ `Debug` አፈፃፀም ጋር ተመሳሳይ ገጸ-ባህሪያትን ያመልጣል ፡፡
    ///
    ///
    /// # Examples
    ///
    /// አንድ ለተደጋጋሚ እንደ:
    ///
    /// ```
    /// for c in '\n'.escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// `println!` ን በቀጥታ በመጠቀም
    ///
    /// ```
    /// println!("{}", '\n'.escape_debug());
    /// ```
    ///
    /// ሁለቱም ከዚህ ጋር እኩል ናቸው
    ///
    /// ```
    /// println!("\\n");
    /// ```
    ///
    /// `to_string` ን በመጠቀም
    ///
    /// ```
    /// assert_eq!('\n'.escape_debug().to_string(), "\\n");
    /// ```
    ///
    #[stable(feature = "char_escape_debug", since = "1.20.0")]
    #[inline]
    pub fn escape_debug(self) -> EscapeDebug {
        self.escape_debug_ext(true)
    }

    /// ያወጣል `char`s እንደ አንድ ቁምፊ ቃል በቃል የማምለጫ ኮድ ያፈራላቸዋል አንድ ለተደጋጋሚ.
    ///
    /// ነባሪ C++ 11 እና ተመሳሳይ ሲ-የቤተሰብ ቋንቋዎች ጨምሮ ቋንቋዎች የተለያዩ ውስጥ ህጋዊ የሆኑ literals ማምረት አቅጣጫ አንድ በመድሎ ጋር የተመረጠ ነው.
    /// ትክክለኛዎቹ ህጎች-
    ///
    /// * ትር እንደ `\t` አምልጧል።
    /// * ሰረገላ መመለስ `\r` እንደ አመለጠ ነው.
    /// * የመስመር ምግብ እንደ `\n` አምልጧል።
    /// * ነጠላ ዋጋ እንደ `\'` አምልጧል።
    /// * ድርብ ዋጋ እንደ `\"` አምልጧል።
    /// * Backslash እንደ `\\` አምልጧል።
    /// * የ «ለህትመት ASCII 'ክልል `0x20` .. `0x7e` አካታች ውስጥ ማንኛውም ቁምፊ ያመለጡ አይደለም.
    /// * ሁሉም ሌሎች ቁምፊዎች የአስራስድስትዮሽ ዩኒኮድ እንዳመለጡ የተሰጠው ነው;[`escape_unicode`] ን ይመልከቱ።
    ///
    /// [`escape_unicode`]: #method.escape_unicode
    ///
    /// # Examples
    ///
    /// አንድ ለተደጋጋሚ እንደ:
    ///
    /// ```
    /// for c in '"'.escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// `println!` ን በቀጥታ በመጠቀም
    ///
    /// ```
    /// println!("{}", '"'.escape_default());
    /// ```
    ///
    /// ሁለቱም ከዚህ ጋር እኩል ናቸው
    ///
    /// ```
    /// println!("\\\"");
    /// ```
    ///
    /// `to_string` ን በመጠቀም
    ///
    /// ```
    /// assert_eq!('"'.escape_default().to_string(), "\\\"");
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_default(self) -> EscapeDefault {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            '\x20'..='\x7e' => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDefault { state: init_state }
    }

    /// UTF-8 ውስጥ encoded ከሆነ ይህ `char` ያስፈልጋቸዋል ነበር ባይቶች ብዛት ይመልሳል.
    ///
    /// ያ ባይቶች ብዛት ሁል ጊዜ በ 1 እና በ 4 መካከል ፣ አካታች ነው።
    ///
    /// # Examples
    ///
    /// መሠረታዊ አጠቃቀም
    ///
    /// ```
    /// let len = 'A'.len_utf8();
    /// assert_eq!(len, 1);
    ///
    /// let len = 'ß'.len_utf8();
    /// assert_eq!(len, 2);
    ///
    /// let len = 'ℝ'.len_utf8();
    /// assert_eq!(len, 3);
    ///
    /// let len = '💣'.len_utf8();
    /// assert_eq!(len, 4);
    /// ```
    ///
    /// የ `&str` ዓይነት ይዘቱ UTF-8 መሆኑን ያረጋግጣል ፣ ስለሆነም እያንዳንዱ የኮድ ነጥብ በ `&str` እና በእኛ `char` ሆኖ ቢወከል የሚወስደውን ርዝመት ማወዳደር እንችላለን-
    ///
    ///
    /// ```
    /// // ካርስ እንደ
    /// let eastern = '東';
    /// let capital = '京';
    ///
    /// // ሁለቱም ሦስት ባይት እንደ ሊቀመጡ ይችላሉ
    /// assert_eq!(3, eastern.len_utf8());
    /// assert_eq!(3, capital.len_utf8());
    ///
    /// // እንደ &str ፣ እነዚህ ሁለቱ በ‹XXXX›ውስጥ የተቀየሩ ናቸው
    /// let tokyo = "東京";
    ///
    /// let len = eastern.len_utf8() + capital.len_utf8();
    ///
    /// // በአጠቃላይ ስድስት ባይት እንደሚወስዱ ማየት እንችላለን ፡፡...
    /// assert_eq!(6, tokyo.len());
    ///
    /// // ... ልክ &str እንደ
    /// assert_eq!(len, tokyo.len());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf8(self) -> usize {
        len_utf8(self as u32)
    }

    /// በ UTF-16 ውስጥ ከተቀየረ ይህ `char` የሚያስፈልገውን የ 16 ቢት ኮድ አሃዶች ይመልሳል።
    ///
    ///
    /// ስለዚህ ፅንሰ-ሀሳብ የበለጠ ማብራሪያ ለ [`len_utf8()`] ሰነዶችን ይመልከቱ ፡፡
    /// ይህ ተግባር መስታወት ነው ፣ ግን ከ UTF-8 ይልቅ ለ UTF-16።
    ///
    /// [`len_utf8()`]: #method.len_utf8
    ///
    /// # Examples
    ///
    /// መሠረታዊ አጠቃቀም
    ///
    /// ```
    /// let n = 'ß'.len_utf16();
    /// assert_eq!(n, 1);
    ///
    /// let len = '💣'.len_utf16();
    /// assert_eq!(len, 2);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf16(self) -> usize {
        let ch = self as u32;
        if (ch & 0xFFFF) == ch { 1 } else { 2 }
    }

    /// ይህንን ቁምፊ እንደ UTF-8 በተጠቀሰው ባይት ቋት ውስጥ ያስገባቸዋል ፣ ከዚያ ኢንኮዲንግ ፊደልን የያዘውን የመጠባበቂያ ክምችት ንዑስ ክፍል ይመልሳል።
    ///
    ///
    /// # Panics
    ///
    /// ማስቀመጫው በቂ ካልሆነ Panics።
    /// የአራት ርዝመት ቋት ማናቸውንም `char` ለመግለጽ በቂ ነው።
    ///
    /// # Examples
    ///
    /// ከእነዚህ ምሳሌዎች መካከል በሁለቱም ውስጥ, 'ß' እንዲረዱት ሁለት ባይት ይወስዳል.
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = 'ß'.encode_utf8(&mut b);
    ///
    /// assert_eq!(result, "ß");
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// በጣም ትንሽ የሆነ ቋት
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// 'ß'.encode_utf8(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf8(self, dst: &mut [u8]) -> &mut str {
        // ደህንነት: ይህ ትክክለኛ UTF-8 ነው, ስለዚህ `char`, ገረዷን አይደለም.
        unsafe { from_utf8_unchecked_mut(encode_utf8_raw(self as u32, dst)) }
    }

    /// ይህንን ቁምፊ እንደ UTF-16 ወደ ቀረበው የ `u16` ቋት (ኢንክሪፕት) ያሰፍራል ፣ እና ከዚያ የመቀየሪያውን ቁምፊ የያዘውን የመጠባበቂያ ክምችት ንዑስ ክፍል ይመልሳል።
    ///
    ///
    /// # Panics
    ///
    /// ማስቀመጫው በቂ ካልሆነ Panics።
    /// የ 2 ርዝመት ቋት ማንኛቸውም `char` ን ለመግለጽ በቂ ነው።
    ///
    /// # Examples
    ///
    /// በእነዚህ ሁለቱም ምሳሌዎች ውስጥ '𝕊' ለመቀየር ሁለት ``u16`s ይወስዳል ፡፡
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = '𝕊'.encode_utf16(&mut b);
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// በጣም ትንሽ የሆነ ቋት
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// '𝕊'.encode_utf16(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf16(self, dst: &mut [u16]) -> &mut [u16] {
        encode_utf16_raw(self as u32, dst)
    }

    /// ይህ `char` የ `Alphabetic` ንብረት እንዳለው ከሆነ ይመልሳል `true`.
    ///
    /// `Alphabetic` በ [Unicode Standard] በምዕራፍ 4 (የባህሪይ ባህሪዎች) ውስጥ ተገልጻል በ [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`] ውስጥ ተገል specifiedል ፡፡
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// መሠረታዊ አጠቃቀም
    ///
    /// ```
    /// assert!('a'.is_alphabetic());
    /// assert!('京'.is_alphabetic());
    ///
    /// let c = '💝';
    /// // ፍቅር ብዙ ነገር ነው ግን ፊደል አይደለም
    /// assert!(!c.is_alphabetic());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphabetic(self) -> bool {
        match self {
            'a'..='z' | 'A'..='Z' => true,
            c => c > '\x7f' && unicode::Alphabetic(c),
        }
    }

    /// ይህ `char` የ `Lowercase` ንብረት እንዳለው ከሆነ ይመልሳል `true`.
    ///
    /// `Lowercase` በ [Unicode Standard] በምዕራፍ 4 (የባህሪይ ባህሪዎች) ውስጥ ተገልጻል በ [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`] ውስጥ ተገል specifiedል ፡፡
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// መሠረታዊ አጠቃቀም
    ///
    /// ```
    /// assert!('a'.is_lowercase());
    /// assert!('δ'.is_lowercase());
    /// assert!(!'A'.is_lowercase());
    /// assert!(!'Δ'.is_lowercase());
    ///
    /// // የተለያዩ የቻይና ስክሪፕቶች እና ሥርዓተ-ጉዳይ አላቸው, እና እንዲህ አይደለም:
    /// assert!(!'中'.is_lowercase());
    /// assert!(!' '.is_lowercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_lowercase(self) -> bool {
        match self {
            'a'..='z' => true,
            c => c > '\x7f' && unicode::Lowercase(c),
        }
    }

    /// ይህ `char` የ `Uppercase` ንብረት ካለው `true` ን ይመልሳል።
    ///
    /// `Uppercase` በ [Unicode Standard] በምዕራፍ 4 (የባህሪይ ባህሪዎች) ውስጥ ተገልጻል በ [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`] ውስጥ ተገል specifiedል ፡፡
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// መሠረታዊ አጠቃቀም
    ///
    /// ```
    /// assert!(!'a'.is_uppercase());
    /// assert!(!'δ'.is_uppercase());
    /// assert!('A'.is_uppercase());
    /// assert!('Δ'.is_uppercase());
    ///
    /// // የተለያዩ የቻይና ስክሪፕቶች እና ሥርዓተ-ጉዳይ አላቸው, እና እንዲህ አይደለም:
    /// assert!(!'中'.is_uppercase());
    /// assert!(!' '.is_uppercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_uppercase(self) -> bool {
        match self {
            'A'..='Z' => true,
            c => c > '\x7f' && unicode::Uppercase(c),
        }
    }

    /// ይህ `char` የ `White_Space` ንብረት ካለው `true` ን ይመልሳል።
    ///
    /// `White_Space` በ [Unicode Character Database][ucd] [`PropList.txt`] ውስጥ ተገልጧል።
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`PropList.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/PropList.txt
    ///
    /// # Examples
    ///
    /// መሠረታዊ አጠቃቀም
    ///
    /// ```
    /// assert!(' '.is_whitespace());
    ///
    /// // የማይበጠስ ቦታ
    /// assert!('\u{A0}'.is_whitespace());
    ///
    /// assert!(!'越'.is_whitespace());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_whitespace(self) -> bool {
        match self {
            ' ' | '\x09'..='\x0d' => true,
            c => c > '\x7f' && unicode::White_Space(c),
        }
    }

    /// ይህ `char` ወይ [`is_alphabetic()`] ወይም [`is_numeric()`] ን የሚያሟላ ከሆነ `true` ን ይመልሳል።
    ///
    /// [`is_alphabetic()`]: #method.is_alphabetic
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Examples
    ///
    /// መሠረታዊ አጠቃቀም
    ///
    /// ```
    /// assert!('٣'.is_alphanumeric());
    /// assert!('7'.is_alphanumeric());
    /// assert!('৬'.is_alphanumeric());
    /// assert!('¾'.is_alphanumeric());
    /// assert!('①'.is_alphanumeric());
    /// assert!('K'.is_alphanumeric());
    /// assert!('و'.is_alphanumeric());
    /// assert!('藏'.is_alphanumeric());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphanumeric(self) -> bool {
        self.is_alphabetic() || self.is_numeric()
    }

    /// ይህ `char` የመቆጣጠሪያ ኮዶች አጠቃላይ ምድብ ካለው `true` ን ይመልሳል።
    ///
    /// ቁጥጥር ኮዶች (`Cc` አጠቃላይ ምድብ ጋር ኮድ ነጥቦች) በ [Unicode Character Database][ucd] [`UnicodeData.txt`] ውስጥ [Unicode Standard] ምዕራፍ 4 (ካራክተር Properties) በተገለጸው እና የተገለጹ ናቸው.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// መሠረታዊ አጠቃቀም
    ///
    /// ```
    /// // U + 009C, STRING ማብቂያ
    /// assert!(''.is_control());
    /// assert!(!'q'.is_control());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_control(self) -> bool {
        unicode::Cc(self)
    }

    /// ይህ `char` የ `Grapheme_Extend` ንብረት ካለው `true` ን ይመልሳል።
    ///
    /// `Grapheme_Extend` በ [Unicode Standard Annex #29 (Unicode Text Segmentation)][uax29] ውስጥ ተገል describedል እና በ [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`] ውስጥ ተገል specifiedል።
    ///
    ///
    /// [uax29]: https://www.unicode.org/reports/tr29/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    #[inline]
    pub(crate) fn is_grapheme_extended(self) -> bool {
        unicode::Grapheme_Extend(self)
    }

    /// ይህ `char` ከቁጥሮች አጠቃላይ ምድቦች ውስጥ አንዱ ካለው `true` ን ይመልሳል።
    ///
    /// ቁጥሮች አጠቃላይ ምድቦች (ለ አስርዮሽ አሀዝ ለ `Nd`, `Nl` ፊደል-እንደ ሌሎች የቁጥር ቁምፊዎች የቁጥር ቁምፊዎች, እና `No`) በ [Unicode Character Database][ucd] [`UnicodeData.txt`] ውስጥ የተገለጹ ናቸው.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// መሠረታዊ አጠቃቀም
    ///
    /// ```
    /// assert!('٣'.is_numeric());
    /// assert!('7'.is_numeric());
    /// assert!('৬'.is_numeric());
    /// assert!('¾'.is_numeric());
    /// assert!('①'.is_numeric());
    /// assert!(!'K'.is_numeric());
    /// assert!(!'و'.is_numeric());
    /// assert!(!'藏'.is_numeric());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_numeric(self) -> bool {
        match self {
            '0'..='9' => true,
            c => c > '\x7f' && unicode::N(c),
        }
    }

    /// ይመለሳል አንድ ወይም ከዚያ በላይ ይህ `char` ያለውን ፊደሎች የካርታ ያፈራላቸዋል አንድ ለተደጋጋሚ
    /// `char`s.
    ///
    /// ይህ `char` ንዑስ ፊደል ካርታ ከሌለው ተደጋጋሚው ተመሳሳይ `char` ይሰጣል ፡፡
    ///
    /// ይህ `char` በ [Unicode Character Database][ucd] [`UnicodeData.txt`] የሰጠውን አንድ-አንድ ፊደሎች የካርታ ስራ, `char` መሆኑን ለተደጋጋሚ ምርት ያለው ከሆነ.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// ይህ `char` ልዩ ግምት (ለምሳሌ በርካታ `char`s) የሚጠይቅ ከሆነ ለተደጋጋሚ [`SpecialCasing.txt`] የሰጠውን`char` (ዎች) ያፈራላቸዋል.
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// ይህ ክወና በሚመጥን ያለ አንድ ላይ ያልተመሰረተ የካርታ ስራ ያከናውናል.ያም ማለት ልወጣው ከአውድ እና ቋንቋ ነፃ ነው።
    ///
    /// በ [Unicode Standard] ውስጥ ምዕራፍ 4 (የባህሪይ ባህሪዎች) በአጠቃላይ የጉዳይ ካርታ አሰተያየትን ያነሳል እና ምዕራፍ 3 (Conformance) ለጉዳዩ ልወጣ ነባሪ ስልተ-ቀመርን ያብራራል ፡፡
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// አንድ ለተደጋጋሚ እንደ:
    ///
    /// ```
    /// for c in 'İ'.to_lowercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// `println!` ን በቀጥታ በመጠቀም
    ///
    /// ```
    /// println!("{}", 'İ'.to_lowercase());
    /// ```
    ///
    /// ሁለቱም ከዚህ ጋር እኩል ናቸው
    ///
    /// ```
    /// println!("i\u{307}");
    /// ```
    ///
    /// `to_string` ን በመጠቀም
    ///
    /// ```
    /// assert_eq!('C'.to_lowercase().to_string(), "c");
    ///
    /// // አንዳንድ ጊዜ ውጤቱ ከአንድ በላይ ገጸ-ባህሪያት ነው
    /// assert_eq!('İ'.to_lowercase().to_string(), "i\u{307}");
    ///
    /// // ራሳቸውን ወደ ትልቅ እና ትንሽ ልወጣ ሁለቱም የሌላቸው ቁምፊዎች.
    /////
    /// assert_eq!('山'.to_lowercase().to_string(), "山");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_lowercase(self) -> ToLowercase {
        ToLowercase(CaseMappingIter::new(conversions::to_lower(self)))
    }

    /// የዚህ `char` ን አቢይ ሆሄ ካርታ እንደ አንድ ወይም ከዚያ በላይ የሚያመጣ ተደጋጋሚ ይመልሳል
    /// `char`s.
    ///
    /// ይህ `char` አንድ አቢይ የካርታ የሌለው ከሆነ, ለተደጋጋሚ ተመሳሳይ `char` ያፈራላቸዋል.
    ///
    /// ይህ `char` በ [Unicode Character Database][ucd] [`UnicodeData.txt`] የተሰጠው የአንድ-ለአንድ አቢይ ሆሄ ካርታ ካለው ተደጋጋሚው ያ `char` X ያወጣል ፡፡
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// ይህ `char` ልዩ ግምት (ለምሳሌ በርካታ `char`s) የሚጠይቅ ከሆነ ለተደጋጋሚ [`SpecialCasing.txt`] የሰጠውን`char` (ዎች) ያፈራላቸዋል.
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// ይህ ክወና በሚመጥን ያለ አንድ ላይ ያልተመሰረተ የካርታ ስራ ያከናውናል.ያም ማለት ልወጣው ከአውድ እና ቋንቋ ነፃ ነው።
    ///
    /// በ [Unicode Standard] ውስጥ ምዕራፍ 4 (የባህሪይ ባህሪዎች) በአጠቃላይ የጉዳይ ካርታ አሰተያየትን ያነሳል እና ምዕራፍ 3 (Conformance) ለጉዳዩ ልወጣ ነባሪ ስልተ-ቀመርን ያብራራል ፡፡
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// አንድ ለተደጋጋሚ እንደ:
    ///
    /// ```
    /// for c in 'ß'.to_uppercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// `println!` ን በቀጥታ በመጠቀም
    ///
    /// ```
    /// println!("{}", 'ß'.to_uppercase());
    /// ```
    ///
    /// ሁለቱም ከዚህ ጋር እኩል ናቸው
    ///
    /// ```
    /// println!("SS");
    /// ```
    ///
    /// `to_string` ን በመጠቀም
    ///
    /// ```
    /// assert_eq!('c'.to_uppercase().to_string(), "C");
    ///
    /// // አንዳንድ ጊዜ ውጤቱ ከአንድ በላይ ገጸ-ባህሪያት ነው
    /// assert_eq!('ß'.to_uppercase().to_string(), "SS");
    ///
    /// // ራሳቸውን ወደ ትልቅ እና ትንሽ ልወጣ ሁለቱም የሌላቸው ቁምፊዎች.
    /////
    /// assert_eq!('山'.to_uppercase().to_string(), "山");
    /// ```
    ///
    /// # በአካባቢያዊ ሁኔታ ላይ ማስታወሻ
    ///
    /// ቱርክኛ ውስጥ, የላቲን ውስጥ 'i' ያለውን ተመጣጣኝ አምስት ቅጾች ይልቅ ሁለት አሉት:
    ///
    /// * 'Dotless': እኔ/i, አንዳንድ ጊዜ በጽሑፍ i
    /// * 'Dotted': İ/i
    ///
    /// አነስተኛ ቁጥር ያለው 'i' ን ከላቲን ጋር ተመሳሳይ መሆኑን ልብ ይበሉ።ስለዚህ:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    /// ```
    ///
    /// `upper_i` እሴት እዚህ ላይ ጽሑፍ ቋንቋ ላይ ይተማመናል; እኛ `en-US` ውስጥ ካልቻልን, `"I"` መሆን አለበት, ነገር ግን እኛ `tr_TR` ውስጥ ካልቻልን, `"İ"` መሆን አለበት.
    /// `to_uppercase()` ይህንን ከግምት ውስጥ አያስገባም ፣ እና ስለዚህ
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    ///
    /// assert_eq!(upper_i, "I");
    /// ```
    ///
    /// በቋንቋዎች ሁሉ ይይዛል
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_uppercase(self) -> ToUppercase {
        ToUppercase(CaseMappingIter::new(conversions::to_upper(self)))
    }

    /// ቼኮች ዋጋ በ ASCII ክልል ውስጥ ከሆነ.
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.32.0")]
    #[inline]
    pub const fn is_ascii(&self) -> bool {
        *self as u32 <= 0x7F
    }

    /// በእሱ ASCII የላይኛው ፊደል ውስጥ የእሴቱን ቅጅ አቻ ያደርገዋል።
    ///
    /// የ ASCII ፊደሎች ከ 'a' እስከ 'z' ወደ 'A' እስከ 'Z' ካርታ ይደረጋሉ ፣ ግን የ ASCII ያልሆኑ ፊደላት አልተለወጡም ፡፡
    ///
    /// በቦታው ላይ እሴቱን በጅምላ ለማሳደግ [`make_ascii_uppercase()`] ን ይጠቀሙ።
    ///
    /// ከ ASCII ያልሆኑ ቁምፊዎች በተጨማሪ ወደ አቢይ ሆሄያት (ASCII) ቁምፊዎች [`to_uppercase()`] ን ይጠቀሙ ፡፡
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('A', ascii.to_ascii_uppercase());
    /// assert_eq!('❤', non_ascii.to_ascii_uppercase());
    /// ```
    ///
    /// [`make_ascii_uppercase()`]: #method.make_ascii_uppercase
    /// [`to_uppercase()`]: #method.to_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_uppercase(&self) -> char {
        if self.is_ascii_lowercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// በእሱ ASCII አነስተኛ ፊደል ውስጥ የእሴቱን ቅጅ ያደርገዋል።
    ///
    /// የ ASCII ፊደሎች ከ 'A' እስከ 'Z' ወደ 'a' እስከ 'z' ካርታ ይደረጋሉ ፣ ግን የ ASCII ያልሆኑ ፊደላት አልተለወጡም ፡፡
    ///
    /// በቦታው ላይ እሴትን ለማሳነስ [`make_ascii_lowercase()`] ን ይጠቀሙ።
    ///
    /// ያልሆኑ ASCII ቁምፊዎች በተጨማሪ የ ASCII ቁምፊዎች ፊደል ለማድረግ, [`to_lowercase()`] ይጠቀሙ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'A';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('a', ascii.to_ascii_lowercase());
    /// assert_eq!('❤', non_ascii.to_ascii_lowercase());
    /// ```
    ///
    /// [`make_ascii_lowercase()`]: #method.make_ascii_lowercase
    /// [`to_lowercase()`]: #method.to_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_lowercase(&self) -> char {
        if self.is_ascii_uppercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// ሁለት እሴቶች አስኪ ኬዝ-ደንድኖ ተዛማጅ የሆኑ ያረጋግጣል.
    ///
    /// `to_ascii_lowercase(a) == to_ascii_lowercase(b)` ጋር እኩል ነው.
    ///
    /// # Examples
    ///
    /// ```
    /// let upper_a = 'A';
    /// let lower_a = 'a';
    /// let lower_z = 'z';
    ///
    /// assert!(upper_a.eq_ignore_ascii_case(&lower_a));
    /// assert!(upper_a.eq_ignore_ascii_case(&upper_a));
    /// assert!(!upper_a.eq_ignore_ascii_case(&lower_z));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn eq_ignore_ascii_case(&self, other: &char) -> bool {
        self.to_ascii_lowercase() == other.to_ascii_lowercase()
    }

    /// ይህንን አይነት ወደ ASCII የላይኛው ፊደል አቻው በቦታው ይለውጣል።
    ///
    /// የ ASCII ፊደሎች ከ 'a' እስከ 'z' ወደ 'A' እስከ 'Z' ካርታ ይደረጋሉ ፣ ግን የ ASCII ያልሆኑ ፊደላት አልተለወጡም ፡፡
    ///
    /// ነባሩን መቀየር ያለ አዲስ uppercased እሴት ለመመለስ, [`to_ascii_uppercase()`] ይጠቀሙ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'a';
    ///
    /// ascii.make_ascii_uppercase();
    ///
    /// assert_eq!('A', ascii);
    /// ```
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        *self = self.to_ascii_uppercase();
    }

    /// ይህንን አይነት ወደ ASCII ዝቅተኛ ፊደል አቻ በቦታው ይለውጠዋል።
    ///
    /// የ ASCII ፊደሎች ከ 'A' እስከ 'Z' ወደ 'a' እስከ 'z' ካርታ ይደረጋሉ ፣ ግን የ ASCII ያልሆኑ ፊደላት አልተለወጡም ፡፡
    ///
    /// ነባሩን ሳይቀይር አዲስ ዝቅተኛ ዋጋ ያለው እሴት ለመመለስ [`to_ascii_lowercase()`] ን ይጠቀሙ።
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'A';
    ///
    /// ascii.make_ascii_lowercase();
    ///
    /// assert_eq!('a', ascii);
    /// ```
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        *self = self.to_ascii_lowercase();
    }

    /// ቼኮች ዋጋ አስኪ በፊደላት ቁምፊ ከሆነ:
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z', ወይም
    /// - ዩ + 0061 'a' ..=U + 007A 'z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphabetic());
    /// assert!(uppercase_g.is_ascii_alphabetic());
    /// assert!(a.is_ascii_alphabetic());
    /// assert!(g.is_ascii_alphabetic());
    /// assert!(!zero.is_ascii_alphabetic());
    /// assert!(!percent.is_ascii_alphabetic());
    /// assert!(!space.is_ascii_alphabetic());
    /// assert!(!lf.is_ascii_alphabetic());
    /// assert!(!esc.is_ascii_alphabetic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphabetic(&self) -> bool {
        matches!(*self, 'A'..='Z' | 'a'..='z')
    }

    /// እሴቱ የ ASCII አቢይ ሆሄ ቁምፊ ከሆነ ይፈትሻል
    /// ዩ + 0041 'A' ..=U + 005A 'Z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_uppercase());
    /// assert!(uppercase_g.is_ascii_uppercase());
    /// assert!(!a.is_ascii_uppercase());
    /// assert!(!g.is_ascii_uppercase());
    /// assert!(!zero.is_ascii_uppercase());
    /// assert!(!percent.is_ascii_uppercase());
    /// assert!(!space.is_ascii_uppercase());
    /// assert!(!lf.is_ascii_uppercase());
    /// assert!(!esc.is_ascii_uppercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_uppercase(&self) -> bool {
        matches!(*self, 'A'..='Z')
    }

    /// ቼኮች ዋጋ አስኪ ፊደል ቁምፊ ከሆነ:
    /// ዩ + 0061 'a' ..=U + 007A 'z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_lowercase());
    /// assert!(!uppercase_g.is_ascii_lowercase());
    /// assert!(a.is_ascii_lowercase());
    /// assert!(g.is_ascii_lowercase());
    /// assert!(!zero.is_ascii_lowercase());
    /// assert!(!percent.is_ascii_lowercase());
    /// assert!(!space.is_ascii_lowercase());
    /// assert!(!lf.is_ascii_lowercase());
    /// assert!(!esc.is_ascii_lowercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_lowercase(&self) -> bool {
        matches!(*self, 'a'..='z')
    }

    /// እሴቱ የ ASCII የቁጥር ፊደል ቁምፊ መሆኑን ይፈትሻል
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z', ወይም
    /// - U + 0061 'a' ..=U + 007A 'z', ወይም
    /// - U + 0030 '0' ..=U + 0039 '9'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphanumeric());
    /// assert!(uppercase_g.is_ascii_alphanumeric());
    /// assert!(a.is_ascii_alphanumeric());
    /// assert!(g.is_ascii_alphanumeric());
    /// assert!(zero.is_ascii_alphanumeric());
    /// assert!(!percent.is_ascii_alphanumeric());
    /// assert!(!space.is_ascii_alphanumeric());
    /// assert!(!lf.is_ascii_alphanumeric());
    /// assert!(!esc.is_ascii_alphanumeric());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphanumeric(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='Z' | 'a'..='z')
    }

    /// እሴቱ የ ASCII የአስርዮሽ አሃዝ ከሆነ ይፈትሻል
    /// U + 0030 '0' ..=U + 0039 '9'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_digit());
    /// assert!(!uppercase_g.is_ascii_digit());
    /// assert!(!a.is_ascii_digit());
    /// assert!(!g.is_ascii_digit());
    /// assert!(zero.is_ascii_digit());
    /// assert!(!percent.is_ascii_digit());
    /// assert!(!space.is_ascii_digit());
    /// assert!(!lf.is_ascii_digit());
    /// assert!(!esc.is_ascii_digit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_digit(&self) -> bool {
        matches!(*self, '0'..='9')
    }

    /// ቼኮች ዋጋ አስኪ አስራስድስትዮሽ አኃዝ ከሆነ:
    ///
    /// - U + 0030 '0' ..=U + 0039 '9', ወይም
    /// - U + 0041 'A' ..=U + 0046 'F', ወይም
    /// - U + 0061 'a' ..=U + 0066 'f'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_hexdigit());
    /// assert!(!uppercase_g.is_ascii_hexdigit());
    /// assert!(a.is_ascii_hexdigit());
    /// assert!(!g.is_ascii_hexdigit());
    /// assert!(zero.is_ascii_hexdigit());
    /// assert!(!percent.is_ascii_hexdigit());
    /// assert!(!space.is_ascii_hexdigit());
    /// assert!(!lf.is_ascii_hexdigit());
    /// assert!(!esc.is_ascii_hexdigit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_hexdigit(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='F' | 'a'..='f')
    }

    /// ቼኮች ዋጋ አስኪ የስርዓተ ነጥብ ቁምፊ ከሆነ:
    ///
    /// - U + 0021 ..=U + 002F `! " # $ % & ' ( ) * + , - . /` ፣ ወይም
    /// - U + 003A ..=U + 0040 `: ; < = > ? @`, ወይም
    /// - U + 005B ..=U + 0060 "[\] ^ _" `` ፣ ወይም
    /// - ዩ + 007B ..=U + 007E `{ | } ~`
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_punctuation());
    /// assert!(!uppercase_g.is_ascii_punctuation());
    /// assert!(!a.is_ascii_punctuation());
    /// assert!(!g.is_ascii_punctuation());
    /// assert!(!zero.is_ascii_punctuation());
    /// assert!(percent.is_ascii_punctuation());
    /// assert!(!space.is_ascii_punctuation());
    /// assert!(!lf.is_ascii_punctuation());
    /// assert!(!esc.is_ascii_punctuation());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_punctuation(&self) -> bool {
        matches!(*self, '!'..='/' | ':'..='@' | '['..='`' | '{'..='~')
    }

    /// ቼኮች ዋጋ አስኪ ግራፊክ ቁምፊ ከሆነ:
    /// U + 0021 '!' ..=U + 007E '~'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_graphic());
    /// assert!(uppercase_g.is_ascii_graphic());
    /// assert!(a.is_ascii_graphic());
    /// assert!(g.is_ascii_graphic());
    /// assert!(zero.is_ascii_graphic());
    /// assert!(percent.is_ascii_graphic());
    /// assert!(!space.is_ascii_graphic());
    /// assert!(!lf.is_ascii_graphic());
    /// assert!(!esc.is_ascii_graphic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_graphic(&self) -> bool {
        matches!(*self, '!'..='~')
    }

    /// እሴቱ የ ASCII የነፃ-ቦታ ቁምፊ ከሆነ ይፈትሻል
    /// U + 0020 የክፍተት U + 0009 HORIZONTAL TAB, U + 000A መስመር አሰማራ U + 000C ቅጽ አበላንህስ? ወይስ U + 000D ሰረገላ ይመለሳሉ.
    ///
    /// Rust የ WhatWG Infra መደበኛ ዎቹ [definition of ASCII whitespace][infra-aw] ይጠቀማል.በሰፊው ጥቅም ላይ የሚውሉ ሌሎች በርካታ ትርጓሜዎች አሉ ፡፡
    /// ለምሳሌ ያህል, [the POSIX locale][pct] በሚገባ ሁሉ ከላይ ገጸ እንደ U + 000B VERTICAL TAB ያካትታል, ነገር ግን-ከ በጣም ተመሳሳይ specification-[በ Bourne shell ውስጥ "field splitting" ነባሪ ደንብ][bfs] ይቆጥረዋል *ብቻ* የክፍተት HORIZONTAL TAB, እና አርጌ እንደ የመስመር አሰማራ.
    ///
    ///
    /// አንድ ነባር የፋይል ቅርጸት የሚያስኬድ ፕሮግራም እየፃፉ ከሆነ ይህንን ተግባር ከመጠቀምዎ በፊት ያኛው የነፃ ቦታ ቅርጸት ትርጓሜው ምን እንደሆነ ያረጋግጡ።
    ///
    /// [infra-aw]: https://infra.spec.whatwg.org/#ascii-whitespace
    /// [pct]: http://pubs.opengroup.org/onlinepubs/9699919799/basedefs/V1_chap07.html#tag_07_03_01
    /// [bfs]: http://pubs.opengroup.org/onlinepubs/9699919799/utilities/V3_chap02.html#tag_18_06_05
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_whitespace());
    /// assert!(!uppercase_g.is_ascii_whitespace());
    /// assert!(!a.is_ascii_whitespace());
    /// assert!(!g.is_ascii_whitespace());
    /// assert!(!zero.is_ascii_whitespace());
    /// assert!(!percent.is_ascii_whitespace());
    /// assert!(space.is_ascii_whitespace());
    /// assert!(lf.is_ascii_whitespace());
    /// assert!(!esc.is_ascii_whitespace());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_whitespace(&self) -> bool {
        matches!(*self, '\t' | '\n' | '\x0C' | '\r' | ' ')
    }

    /// እሴቱ የ ASCII መቆጣጠሪያ ቁምፊ መሆኑን ይፈትሻል
    /// U + 0000 NUL ..=U + 001F UNIT SEPARATOR ፣ ወይም U + 007F መሰረዝ።
    /// አብዛኞቹ ASCII አርጌ ቁምፊዎች ቁጥጥር ቁምፊዎች ናቸው, ነገር ግን SPACE እንዳልሆነ ልብ በል.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_control());
    /// assert!(!uppercase_g.is_ascii_control());
    /// assert!(!a.is_ascii_control());
    /// assert!(!g.is_ascii_control());
    /// assert!(!zero.is_ascii_control());
    /// assert!(!percent.is_ascii_control());
    /// assert!(!space.is_ascii_control());
    /// assert!(lf.is_ascii_control());
    /// assert!(esc.is_ascii_control());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_control(&self) -> bool {
        matches!(*self, '\0'..='\x1F' | '\x7F')
    }
}

#[inline]
const fn len_utf8(code: u32) -> usize {
    if code < MAX_ONE_B {
        1
    } else if code < MAX_TWO_B {
        2
    } else if code < MAX_THREE_B {
        3
    } else {
        4
    }
}

/// ጥሬ XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX as as value value value value value value valueX value value value value value value0 value value value value value value value value a X value XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX as as as value as value value value value value value value value value value value value value value value value value value value value value ዋጋን እንደ UTF-8 በተጠቀሰው ባይት ቋት ውስጥ ያስገባል ፣ ከዚያ የተቀየረውን ቁምፊ የያዘውን የመጠባበቂያ ክምችት ንዑስ ክፍልን ይመልሳል ፡፡
///
///
/// `char::encode_utf8` በተቃራኒ ይህ ዘዴ ደግሞ ገረዷን ክልል ውስጥ codepoints ያስተናግዳል.
/// (በ ገረዷን ክልል ውስጥ `char` መፍጠር ub ነው.) ውጤቱ ልክ [generalized UTF-8] ግን ልክ አይደለም UTF-8 ነው.
///
/// [generalized UTF-8]: https://simonsapin.github.io/wtf-8/#generalized-utf8
///
/// # Panics
///
/// ማስቀመጫው በቂ ካልሆነ Panics።
/// የአራት ርዝመት ቋት ማናቸውንም `char` ለመግለጽ በቂ ነው።
///
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf8_raw(code: u32, dst: &mut [u8]) -> &mut [u8] {
    let len = len_utf8(code);
    match (len, &mut dst[..]) {
        (1, [a, ..]) => {
            *a = code as u8;
        }
        (2, [a, b, ..]) => {
            *a = (code >> 6 & 0x1F) as u8 | TAG_TWO_B;
            *b = (code & 0x3F) as u8 | TAG_CONT;
        }
        (3, [a, b, c, ..]) => {
            *a = (code >> 12 & 0x0F) as u8 | TAG_THREE_B;
            *b = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *c = (code & 0x3F) as u8 | TAG_CONT;
        }
        (4, [a, b, c, d, ..]) => {
            *a = (code >> 18 & 0x07) as u8 | TAG_FOUR_B;
            *b = (code >> 12 & 0x3F) as u8 | TAG_CONT;
            *c = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *d = (code & 0x3F) as u8 | TAG_CONT;
        }
        _ => panic!(
            "encode_utf8: need {} bytes to encode U+{:X}, but the buffer has {}",
            len,
            code,
            dst.len(),
        ),
    };
    &mut dst[..len]
}

/// ጥሬ XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX KAXXX (XXXXXXXXXXXXXXXXXXXXXXXXXXXXAXS) አካል አድርጎ ጥሬ የ u32 ዋጋን እንደ UTF-16 በተጠቀሰው የ `u16` ቋት ውስጥ ይለጥፋቸዋል እና ከዚያ የተቀበለውን ቁምፊ የያዘውን የመጠባበቂያ ክምችት ንዑስ ክፍልን ይመልሳል ፡፡
///
///
/// `char::encode_utf16` በተቃራኒ ይህ ዘዴ ደግሞ ገረዷን ክልል ውስጥ codepoints ያስተናግዳል.
/// (በተተኪው ክልል ውስጥ `char` መፍጠር UB ነው)
///
/// # Panics
///
/// ማስቀመጫው በቂ ካልሆነ Panics።
/// የ 2 ርዝመት ቋት ማንኛቸውም `char` ን ለመግለጽ በቂ ነው።
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf16_raw(mut code: u32, dst: &mut [u16]) -> &mut [u16] {
    // ደህንነት-እያንዳንዱ ክንድ ለመጻፍ በቂ ቢቶች መኖራቸውን ይፈትሻል
    unsafe {
        if (code & 0xFFFF) == code && !dst.is_empty() {
            // የ BMP በኩል ቢወድቅ
            *dst.get_unchecked_mut(0) = code as u16;
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 1)
        } else if dst.len() >= 2 {
            // ተጨማሪ አውሮፕላኖች በሚተኩ ውስጥ ሰብረው.
            code -= 0x1_0000;
            *dst.get_unchecked_mut(0) = 0xD800 | ((code >> 10) as u16);
            *dst.get_unchecked_mut(1) = 0xDC00 | ((code as u16) & 0x3FF);
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 2)
        } else {
            panic!(
                "encode_utf16: need {} units to encode U+{:X}, but the buffer has {}",
                from_u32_unchecked(code).len_utf16(),
                code,
                dst.len(),
            )
        }
    }
}