#![stable(feature = "futures_api", since = "1.36.0")]

use crate::fmt;
use crate::marker::{PhantomData, Unpin};

/// ኤክስኤክስኤክስ የተግባር ማስፈጸሚያ አሠሪ ብጁ የሆነ የንቃት ባህሪን የሚያቀርብ [`Waker`] እንዲፈጥር ያስችለዋል ፡፡
///
/// [vtable]: https://en.wikipedia.org/wiki/Virtual_method_table
///
/// የ `RawWaker` ን ባህሪን የሚያስተካክል የመረጃ ጠቋሚ እና [virtual function pointer table (vtable)][vtable] ን ያካትታል።
///
///
#[derive(PartialEq, Debug)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct RawWaker {
    /// በአፈፃሚው እንደ አስፈላጊነቱ የዘፈቀደ መረጃን ለማከማቸት የሚያገለግል የመረጃ ጠቋሚ።
    /// ይህ ለምሳሌ ሊሆን ይችላል
    /// ከሥራው ጋር ተያይዞ ወደ‹`Arc`›ዓይነት-የተሰረዘ ጠቋሚ ፡፡
    /// የዚህ መስክ ዋጋ እንደ መጀመሪያው መለኪያው የቫልዩው አካል ለሆኑ ሁሉም ተግባራት ይተላለፋል።
    ///
    data: *const (),
    /// የዚህን የነቃ ባህሪ የሚያበጅ ምናባዊ ተግባር ጠቋሚ ሰንጠረዥ።
    vtable: &'static RawWakerVTable,
}

impl RawWaker {
    /// ከቀረበው የ `data` ጠቋሚ እና `vtable` አዲስ `RawWaker` ን ይፈጥራል።
    ///
    /// የ `data` ጠቋሚው አስፈፃሚው በሚጠይቀው መሠረት የዘፈቀደ መረጃን ለማከማቸት ሊያገለግል ይችላል።ይህ ለምሳሌ ሊሆን ይችላል
    /// ከሥራው ጋር ተያይዞ ወደ‹`Arc`›ዓይነት-የተሰረዘ ጠቋሚ ፡፡
    /// የዚህ አመላካች ዋጋ እንደ መጀመሪያው የ‹`vtable` X›አካል ለሆኑ ሁሉም ተግባራት ይተላለፋል ፡፡
    ///
    /// `vtable` ከ `RawWaker` የተፈጠረ የ `Waker` ባህሪን ያበጃል።
    /// በ `Waker` ላይ ለእያንዳንዱ ክዋኔ ፣ ከስር `RawWaker` ውስጥ በ `vtable` ውስጥ ያለው ተጓዳኝ ተግባር ይጠራል።
    ///
    ///
    ///
    #[inline]
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    pub const fn new(data: *const (), vtable: &'static RawWakerVTable) -> RawWaker {
        RawWaker { data, vtable }
    }
}

/// የ [`RawWaker`] ባህሪን የሚገልጽ ምናባዊ ተግባር ጠቋሚ ሰንጠረዥ (vtable)።
///
/// በተጠቂው ውስጥ ወደ ሁሉም ተግባራት የተላለፈው ጠቋሚ የ `data` ጠቋሚውን ከከበበው የ [`RawWaker`] ነገር ነው።
///
/// በዚህ መዋቅር ውስጥ ያሉት ተግባራት በትክክል የተገነባው የ [`RawWaker`] ነገር ከ [`RawWaker`] አተገባበር በ `data` ጠቋሚ ላይ እንዲጠሩ ብቻ የታሰቡ ናቸው።
/// ማንኛውንም የ `data` ጠቋሚ በመጠቀም ከተያዙት ተግባራት ውስጥ አንዱን መጥራት ያልተገለጸ ባህሪ ያስከትላል ፡፡
///
///
///
///
#[stable(feature = "futures_api", since = "1.36.0")]
#[derive(PartialEq, Copy, Clone, Debug)]
pub struct RawWakerVTable {
    /// ይህ ተግባር [`RawWaker`] ን ሲደወል ይጠራል ፣ ለምሳሌ [`RawWaker`] የተከማቸበት [`Waker`] ሲደመር ይባላል ፡፡
    ///
    /// የዚህ ተግባር አተገባበር ለዚህ ተጨማሪ የ‹[`RawWaker`] X›እና ለተዛማጅ ተግባር አስፈላጊ የሆኑትን ሁሉንም ሀብቶች ማቆየት አለበት ፡፡
    /// በተገኘው [`RawWaker`] ላይ `wake` ን መጥራት በመጀመሪያው [`RawWaker`] ከእንቅልፉ ሲነቃ የነበረውን ተመሳሳይ ተግባር መቀስቀስን ያስከትላል ፡፡
    ///
    ///
    ///
    clone: unsafe fn(*const ()) -> RawWaker,

    /// `wake` በ [`Waker`] ላይ ሲጠራ ይህ ተግባር ይጠራል ፡፡
    /// ከዚህ [`RawWaker`] ጋር የተጎዳኘውን ተግባር መንቃት አለበት።
    ///
    /// የዚህ ተግባር አተገባበር ከዚህ የ‹XXXXXXXXXXXXXXXXXXXXXXX እና‹ጋር›ጋር ተያያዥነት ያላቸውን ማንኛውንም ሀብቶች ለመልቀቅ ማረጋገጥ አለበት ፡፡
    ///
    ///
    wake: unsafe fn(*const ()),

    /// `wake_by_ref` በ [`Waker`] ላይ ሲጠራ ይህ ተግባር ይጠራል ፡፡
    /// ከዚህ [`RawWaker`] ጋር የተጎዳኘውን ተግባር መንቃት አለበት።
    ///
    /// ይህ ተግባር ከ `wake` ጋር ተመሳሳይ ነው ፣ ግን የቀረበውን የመረጃ ጠቋሚ መብላት የለበትም።
    ///
    wake_by_ref: unsafe fn(*const ()),

    /// አንድ [`RawWaker`] ሲወድቅ ይህ ተግባር ይጠራል ፡፡
    ///
    /// የዚህ ተግባር አተገባበር ከዚህ የ‹XXXXXXXXXXXXXXXXXXXXXXX እና‹ጋር›ጋር ተያያዥነት ያላቸውን ማንኛውንም ሀብቶች ለመልቀቅ ማረጋገጥ አለበት ፡፡
    ///
    ///
    drop: unsafe fn(*const ()),
}

impl RawWakerVTable {
    /// ከቀረቡት `clone` ፣ `wake` ፣ `wake_by_ref` እና `drop` ተግባራት አዲስ `RawWakerVTable` ን ይፈጥራል።
    ///
    /// # `clone`
    ///
    /// ይህ ተግባር [`RawWaker`] ን ሲደወል ይጠራል ፣ ለምሳሌ [`RawWaker`] የተከማቸበት [`Waker`] ሲደመር ይባላል ፡፡
    ///
    /// የዚህ ተግባር አተገባበር ለዚህ ተጨማሪ የ‹[`RawWaker`] X›እና ለተዛማጅ ተግባር አስፈላጊ የሆኑትን ሁሉንም ሀብቶች ማቆየት አለበት ፡፡
    /// በተገኘው [`RawWaker`] ላይ `wake` ን መጥራት በመጀመሪያው [`RawWaker`] ከእንቅልፉ ሲነቃ የነበረውን ተመሳሳይ ተግባር መቀስቀስን ያስከትላል ፡፡
    ///
    /// # `wake`
    ///
    /// `wake` በ [`Waker`] ላይ ሲጠራ ይህ ተግባር ይጠራል ፡፡
    /// ከዚህ [`RawWaker`] ጋር የተጎዳኘውን ተግባር መንቃት አለበት።
    ///
    /// የዚህ ተግባር አተገባበር ከዚህ የ‹XXXXXXXXXXXXXXXXXXXXXXX እና‹ጋር›ጋር ተያያዥነት ያላቸውን ማንኛውንም ሀብቶች ለመልቀቅ ማረጋገጥ አለበት ፡፡
    ///
    ///
    /// # `wake_by_ref`
    ///
    /// `wake_by_ref` በ [`Waker`] ላይ ሲጠራ ይህ ተግባር ይጠራል ፡፡
    /// ከዚህ [`RawWaker`] ጋር የተጎዳኘውን ተግባር መንቃት አለበት።
    ///
    /// ይህ ተግባር ከ `wake` ጋር ተመሳሳይ ነው ፣ ግን የቀረበውን የመረጃ ጠቋሚ መብላት የለበትም።
    ///
    /// # `drop`
    ///
    /// አንድ [`RawWaker`] ሲወድቅ ይህ ተግባር ይጠራል ፡፡
    ///
    /// የዚህ ተግባር አተገባበር ከዚህ የ‹XXXXXXXXXXXXXXXXXXXXXXX እና‹ጋር›ጋር ተያያዥነት ያላቸውን ማንኛውንም ሀብቶች ለመልቀቅ ማረጋገጥ አለበት ፡፡
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_allow_const_fn_unstable(const_fn_fn_ptr_basics)]
    pub const fn new(
        clone: unsafe fn(*const ()) -> RawWaker,
        wake: unsafe fn(*const ()),
        wake_by_ref: unsafe fn(*const ()),
        drop: unsafe fn(*const ()),
    ) -> Self {
        Self { clone, wake, wake_by_ref, drop }
    }
}

/// ያልተመሳሰለ ተግባር `Context`።
///
/// በአሁኑ ጊዜ `Context` የአሁኑን ተግባር ለመቀስቀስ የሚያገለግል የ‹`&Waker`›መዳረሻ ለማቅረብ ብቻ ያገለግላል ፡፡
///
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Context<'a> {
    waker: &'a Waker,
    // የሕይወት ዘመኑን የማይለዋወጥ እንዲሆኑ በማስገደድ በልዩነት ለውጦች ላይ future-ማስረጃችንን ማረጋገጥ (የክርክር-አቀማመጥ ሕይወት ተቃራኒዎች ሲሆኑ የመመለሻ-አኗኗር ዕድሜዎች ደግሞ ተለዋዋጭ ናቸው) ፡፡
    //
    //
    //
    _marker: PhantomData<fn(&'a ()) -> &'a ()>,
}

impl<'a> Context<'a> {
    /// ከ `&Waker` አዲስ `Context` ይፍጠሩ።
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn from_waker(waker: &'a Waker) -> Self {
        Context { waker, _marker: PhantomData }
    }

    /// ለአሁኑ ተግባር ወደ `Waker` ማጣቀሻ ይመልሳል።
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn waker(&self) -> &'a Waker {
        &self.waker
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Context<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Context").field("waker", &self.waker).finish()
    }
}

/// ኤክስኤክስኤክስ ለሥራ አስፈፃሚው ለማስኬድ ዝግጁ መሆኑን በማስታወቅ ሥራን ከእንቅልፉ ለማንቃት መያዣ ነው ፡፡
///
/// ይህ እጀታ የአስፈፃሚ-ተኮር የንቃት ባህሪን የሚወስን የ [`RawWaker`] ምሳሌን ያጠቃልላል።
///
///
/// [`Clone`] ፣ [`Send`] እና [`Sync`] ን ይተገበራል።
///
#[repr(transparent)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Waker {
    waker: RawWaker,
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Unpin for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Send for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Sync for Waker {}

impl Waker {
    /// ከዚህ `Waker` ጋር የተጎዳኘውን ተግባር ይንቃ።
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake(self) {
        // ትክክለኛው የንቃት ጥሪ በአፈፃሚው ለተገለጸው አፈፃፀም በምናባዊ ተግባር ጥሪ በኩል ተልዕኮ ተሰጥቷል ፡፡
        //
        let wake = self.waker.vtable.wake;
        let data = self.waker.data;

        // `drop` ን አይጥሩ-ነቃዩ በ `wake` ይበላል።
        crate::mem::forget(self);

        // ደህንነት `Waker::from_raw` ብቸኛው መንገድ ስለሆነ ይህ ደህንነቱ የተጠበቀ ነው
        // `wake` እና `data` ን ለማስጀመር ተጠቃሚው የ `RawWaker` ኮንትራት የተረጋገጠ መሆኑን እንዲገነዘብ የሚጠይቅ ነው ፡፡
        //
        unsafe { (wake)(data) };
    }

    /// `Waker` ን ሳይጠቀሙ ከዚህ `Waker` ጋር የተዛመደውን ተግባር ይንቃ ፡፡
    ///
    /// ይህ ከ‹XXXX›ጋር ተመሳሳይ ነው ፣ ነገር ግን በባለቤትነት የተያዘ `Waker` በሚገኝበት ሁኔታ ትንሽ ቀልጣፋ ሊሆን ይችላል።
    /// `waker.clone().wake()` ን ለመጥራት ይህ ዘዴ ተመራጭ መሆን አለበት ፡፡
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake_by_ref(&self) {
        // ትክክለኛው የንቃት ጥሪ በአፈፃሚው ለተገለጸው አፈፃፀም በምናባዊ ተግባር ጥሪ በኩል ተልዕኮ ተሰጥቷል ፡፡
        //

        // ደህንነት `wake` ን ይመልከቱ
        unsafe { (self.waker.vtable.wake_by_ref)(self.waker.data) }
    }

    /// ይህ `Waker` እና ሌላ `Waker` ተመሳሳይ ተግባር ከቀሰቀሱ `true` ን ይመልሳል።
    ///
    /// ይህ ተግባር በተሻለ ጥረት ላይ የተመሠረተ ነው ፣ እናም የ‹ዋከር›ተመሳሳይ ሥራን ሲቀሰቅስ እንኳን ሐሰት ሊመለስ ይችላል ፡፡
    /// ሆኖም ፣ ይህ ተግባር `true` ን ከመለሰ ፣ `Waker`s ተመሳሳይ ተግባር እንደሚያነቃው የተረጋገጠ ነው።
    ///
    /// ይህ ተግባር በዋናነት ለማመቻቸት ዓላማዎች ጥቅም ላይ ይውላል ፡፡
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn will_wake(&self, other: &Waker) -> bool {
        self.waker == other.waker
    }

    /// ከ [`RawWaker`] አዲስ `Waker` ን ይፈጥራል።
    ///
    /// የተመለሰው `Waker` ባህሪ በ `RawWaker`] እና በ`RawWakerVTable`] ሰነዶች ውስጥ ካልተገለጸ የማይታወቅ ነው።
    ///
    /// ስለዚህ ይህ ዘዴ ደህንነቱ የተጠበቀ አይደለም ፡፡
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub unsafe fn from_raw(waker: RawWaker) -> Waker {
        Waker { waker }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Clone for Waker {
    #[inline]
    fn clone(&self) -> Self {
        Waker {
            // ደህንነት `Waker::from_raw` ብቸኛው መንገድ ስለሆነ ይህ ደህንነቱ የተጠበቀ ነው
            // `clone` እና `data` ን ለማስጀመር ተጠቃሚው የ [`RawWaker`] ኮንትራት የተረጋገጠ መሆኑን እንዲገነዘብ የሚጠይቅ ነው ፡፡
            //
            waker: unsafe { (self.waker.vtable.clone)(self.waker.data) },
        }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Drop for Waker {
    #[inline]
    fn drop(&mut self) {
        // ደህንነት `Waker::from_raw` ብቸኛው መንገድ ስለሆነ ይህ ደህንነቱ የተጠበቀ ነው
        // `drop` እና `data` ን ለማስጀመር ተጠቃሚው የ `RawWaker` ኮንትራት የተረጋገጠ መሆኑን እንዲገነዘብ የሚጠይቅ ነው ፡፡
        //
        unsafe { (self.waker.vtable.drop)(self.waker.data) }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Waker {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let vtable_ptr = self.waker.vtable as *const RawWakerVTable;
        f.debug_struct("Waker")
            .field("data", &self.waker.data)
            .field("vtable", &vtable_ptr)
            .finish()
    }
}