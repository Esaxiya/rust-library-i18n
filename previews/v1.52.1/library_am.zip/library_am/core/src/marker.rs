//! ጥንታዊ traits እና ዓይነቶች ዓይነቶችን መሠረታዊ ባህሪያትን የሚወክሉ ዓይነቶች።
//!
//! የ Rust ዓይነቶች እንደ ውስጣዊ ባህሪያቸው በተለያዩ ጠቃሚ መንገዶች ሊመደቡ ይችላሉ ፡፡
//! እነዚህ ምደባዎች traits እንደ ይወከላሉ.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cell::UnsafeCell;
use crate::cmp;
use crate::fmt::Debug;
use crate::hash::Hash;
use crate::hash::Hasher;

/// በክር ድንበሮች ላይ ሊተላለፉ የሚችሉ ዓይነቶች።
///
/// የ አጠናቃሪ ተገቢ ነው ይወስናል ጊዜ ይህ trait ሰር አልተተገበረም ነው.
///
/// ያልሆነ `Send` አይነት አንድ ምሳሌ ማጣቀሻ-በመቁጠር ጠቋሚ [`rc::Rc`][`Rc`] ነው.
/// ሁለት ክሮች ለቅጂ መሞከር ከሆነ [`Rc`] ተመሳሳይ ማጣቀሻ-ይቆጠራል ዋጋ በዚያ ነጥብ s, እነርሱ [`Rc`] አቶሚክ ክወናዎች መጠቀም አይደለም ምክንያቱም [undefined behavior][ub] ነው በተመሳሳይ ጊዜ ላይ ማጣቀሻ ቆጠራ ለማዘመን ይሞክሩ ይሆናል.
///
/// የአክስቱ ልጅ [`sync::Arc`][arc] የአቶሚክ ሥራዎችን ይጠቀማል (አንዳንድ ጊዜ ከላይ የሚከሰት) እና ስለሆነም `Send` ነው።
///
/// ተጨማሪ ዝርዝሮችን ለማግኘት [the Nomicon](../../nomicon/send-and-sync.html) ይመልከቱ.
///
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "send_trait")]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be sent between threads safely",
    label = "`{Self}` cannot be sent between threads safely"
)]
pub unsafe auto trait Send {
    // empty.
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *mut T {}

/// ማጠናቀር ጊዜ የሚታወቅ በቋሚ መጠን ጋር አይነቶች.
///
/// ሁሉም ዓይነት መለኪያዎች ግልጽ የሆነ የ `Sized` ገደብ አላቸው።ልዩ አገባብ `?Sized` አግባብ ካልሆነ ይህንን ወሰን ለማስወገድ ሊያገለግል ይችላል።
///
/// ```
/// # #![allow(dead_code)]
/// struct Foo<T>(T);
/// struct Bar<T: ?Sized>(T);
///
/// // መዋቅራዊ FooUse(Foo<[i32]>);//ስህተት: Sized [i32] ለ አልተተገበረም
/// struct BarUse(Bar<[i32]>); // OK
/// ```
///
/// የ አንድ ለየት ያለ trait ያለውን ስውር `Self` አይነት ነው.
/// አንድ trait ከዚህ ጋር ተኳሃኝ ነው እንደ አንድ ስውር `Sized` ይታሰር የለውም, ትርጉም በማድረግ, በ trait ማንኛውም መጠን ሊሆን ይችላል እንደዚሁም ሁሉ በተቻለ implementors ጋር ሥራ ያስፈልገዋል, እና የት [trait ነገር] s.
///
///
/// ምንም እንኳን Rust `Sized` ን ከ trait ጋር እንዲያያይዙ ቢፈቅድልዎትም በኋላ ላይ የ trait ነገርን ለመመስረት እሱን መጠቀም አይችሉም ፡፡
///
/// ```
/// # #![allow(unused_variables)]
/// trait Foo { }
/// trait Bar: Sized { }
///
/// struct Impl;
/// impl Foo for Impl { }
/// impl Bar for Impl { }
///
/// let x: &dyn Foo = &Impl;    // OK
/// // ዳ ይሁን: &dyn አሞሌ &Impl =;//ስህተት: trait `Bar` ወደ አንድ ነገር ሊሠራ አይችልም
/////
/// ```
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "sized"]
#[rustc_on_unimplemented(
    message = "the size for values of type `{Self}` cannot be known at compilation time",
    label = "doesn't have a size known at compile-time"
)]
#[fundamental] // ለነባሪ ፣ ለምሳሌ ፣ `[T]: !Default` እንዲገመገም ይጠይቃል
#[rustc_specialization_trait]
pub trait Sized {
    // Empty.
}

/// አንድ ዳይናሚክ መጠን አይነት "unsized" ሊሆን እንደሚችል አይነቶች.
///
/// ለምሳሌ ያህል, መጠን ያላቸው የድርድር አይነት `[i8; 2]` `Unsize<[i8]>` እና `Unsize<dyn fmt::Debug>` ተግባራዊ ያደርጋል.
///
/// `Unsize` ሁሉም ማስፈጸሚያዎች በ አጠናቃሪ በ ሰር የቀረቡ ናቸው.
///
/// `Unsize` ተተግብሯል
///
/// - `[T; N]` `Unsize<[T]>` ነው
/// - `T` `Unsize<dyn Trait>` ጊዜ `T: Trait` ነው
/// - `Foo<..., T, ...>` `Unsize<Foo<..., U, ...>>` ከሆነ ነው:
///   - `T: Unsize<U>`
///   - ፉ መዋቅራዊ ነው
///   - ብቻ `Foo` የመጨረሻ መስክ `T` በተያያዘ አንድ አይነት አለው
///   - `T` ሌላ መስኮች ዓይነት አካል አይደለም
///   - `Bar<T>: Unsize<Bar<U>>`, የ `Foo` የመጨረሻው መስክ `Bar<T>` ዓይነት ካለው
///
/// `Unsize` እንደ [`Rc`] እንደ "user-defined" መያዣዎች ልውጥውጥ-መጠን ያላቸው አይነቶች የያዘ ለመፍቀድ [`ops::CoerceUnsized`] ጋር አብሮ ጥቅም ላይ ይውላል.
/// ተጨማሪ ዝርዝሮችን ለማግኘት [DST coercion RFC][RFC982] እና [the nomicon entry on coercion][nomicon-coerce] ይመልከቱ.
///
/// [`ops::CoerceUnsized`]: crate::ops::CoerceUnsized
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [RFC982]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
#[unstable(feature = "unsize", issue = "27732")]
#[lang = "unsize"]
pub trait Unsize<T: ?Sized> {
    // Empty.
}

/// ጥለት ግጥሚያዎች ውስጥ ጥቅም ላይ constants ለ trait ያስፈልጋል.
///
/// ማንኛውም አይነት የሚያገኝ `PartialEq` በራስ-ሰር በዚህ trait የሚያስፈጽም,*ምንም ይሁን* በውስጡ አይነት-ግቤቶች `Eq` ተግባራዊ እንደሆነ ነው.
///
/// አንድ `const` ንጥል በዚህ trait ለመተግበር አይደለም አንዳንድ ዓይነት የያዘ ከሆነ, ከዚያ አይነት አንድም (1.) (ኮድ ትውልድ ይገኛል ያስባል ያለውን ንጽጽር ስልት, አይሰጥም የማያቋርጥ ማለት ነው) `PartialEq`, ወይም (2.) ይህ መሳሪያዎች መተግበር *የራሱ እንዳልሆነ* የ `PartialEq` ስሪት (እኛ ከመዋቅር-እኩልነት ንፅፅር ጋር አይጣጣምም ብለን የምንገምተው)።
///
///
/// ከላይ ሁለት ሁኔታዎችን በሁለቱም ውስጥ, ጥለት ግጥሚያ ላይ እንዲህ ያለ የማያቋርጥ አጠቃቀም ውድቅ.
///
/// እንዲሁም በባህሪያት ላይ የተመሠረተ ንድፍ ወደዚህ trait ለመሰደድ ያነሳሱትን [structural match RFC][RFC1445] እና [issue 63438] ን ይመልከቱ ፡፡
///
/// [RFC1445]: https://github.com/rust-lang/rfcs/blob/master/text/1445-restrict-constants-in-patterns.md
/// [issue 63438]: https://github.com/rust-lang/rust/issues/63438
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(PartialEq)]`")]
#[lang = "structural_peq"]
pub trait StructuralPartialEq {
    // Empty.
}

/// ጥለት ግጥሚያዎች ውስጥ ጥቅም ላይ constants ለ trait ያስፈልጋል.
///
/// ማንኛውም አይነት የሚያገኝ `Eq` በራስ-ሰር በዚህ trait የሚያስፈጽም,*ምንም ይሁን* በውስጡ አይነት ግቤቶች `Eq` ተግባራዊ እንደሆነ ነው.
///
/// በእኛ ዓይነት ስርዓት ውስጥ ባለው ውስንነት ዙሪያ ለመስራት ጠለፋ ነው።
///
/// # Background
///
/// በስርዓተ-ጥለት ግጥሚያዎች ውስጥ ጥቅም ላይ የሚውሉ የኮንስ ዓይነቶች `#[derive(PartialEq, Eq)]` አይነታ እንዲኖራቸው እንፈልጋለን ፡፡
///
/// ይበልጥ ተስማሚ በሆነ ዓለም ውስጥ የተሰጠው ዓይነት `StructuralPartialEq` trait *እና*`Eq` trait ን እንደሚተገብር በመመርመር ብቻ ያንን መስፈርት ማረጋገጥ እንችላለን ፡፡
/// ሆኖም ፣*`derive(PartialEq, Eq)` ን* የሚያደርጉ ADT ሊኖርዎት ይችላል ፣ እና አጠናቃሪው እንዲቀበል የምንፈልግበት ጉዳይ ሆኖ ግን የቋሚው አይነት `Eq` ን ተግባራዊ ማድረግ አልተሳካም።
///
/// ማለትም, እንዲህ ያለ ሁኔታ:
///
/// ```rust
/// #[derive(PartialEq, Eq)]
/// struct Wrap<X>(X);
///
/// fn higher_order(_: &()) { }
///
/// const CFN: Wrap<fn(&())> = Wrap(higher_order);
///
/// fn main() {
///     match CFN {
///         CFN => {}
///         _ => {}
///     }
/// }
/// ```
///
/// (ከላይ ኮድ ውስጥ ያለው ችግር, `Wrap<fn(&())>` `PartialEq` ወይም `Eq` ለመተግበር አይደለም መሆኑን ነው < 'አንድ> fn(&'a _)` does not implement those traits.) `ምክንያቱም
///
/// ስለዚህ እኛ `StructuralPartialEq` እና ብቻ `Eq` የሚሆን ምንም የማያውቅ ቼክ ላይ መተማመን አይችሉም.
///
/// በዚህ ዙሪያ ሥራ አንድ ኡሁ እንደመሆናችን ሁለት የተለያዩ traits ሁለቱም መዋቅራዊ-ተዛማጅ ምልከታ አካል ሆኖ በአሁኑ መሆናቸውን ሁለቱን አጣምሮ (`#[derive(PartialEq)]` እና `#[derive(Eq)]`) እና በቼክ በእያንዳንዱ በማድረግ በክትባቶች ይጠቀማሉ.
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(Eq)]`")]
#[lang = "structural_teq"]
pub trait StructuralEq {
    // Empty.
}

/// የማን እሴቶች ቢት በመገልበጥ በቀላሉ የተባዙ ይችላል አይነቶች.
///
/// በነባሪ, ተለዋዋጭ ማሰሪያዎች 'እንቅስቃሴ ትርጉሞቹ.' አላቸውበሌላ ቃል:
///
/// ```
/// #[derive(Debug)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `x` `y` ወደ ተወስዷል; ስለዚህ ጥቅም ላይ ሊውል አይችልም
///
/// // println («{: ?}», x)!;//ስህተት: የተንቀሳቀስ እሴት አጠቃቀም
/// ```
///
/// አንድ አይነት መሳሪያዎች `Copy`, ፋንታ ያለው ከሆነ ይሁን 'ትርጉሞቹ መገልበጥ »:
///
/// ```
/// // እኛ አንድ `Copy` ትግበራ ሊሆኗቸው ይችላሉ.
/// // `Clone` ይህ `Copy` አንድ supertrait ነው ሆኖ ነው ደግሞ ያስፈልጋል.
/// #[derive(Debug, Copy, Clone)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `y` `x` ቅጂ ነው
///
/// println!("{:?}", x); // A-OK!
/// ```
///
/// እነዚህ ሁለት ምሳሌዎች ውስጥ, ብቸኛው ልዩነት እርስዎ ምደባውን በኋላ መዳረሻ `x` ይፈቀድላቸው እንደሆነ መሆኑን መገንዘብ አስፈላጊ ነው.
/// በመከለያው ስር ፣ ቅጅ እና ማንቀሳቀስ ቢት በማስታወሻ ውስጥ መቅዳት ሊያስከትል ይችላል ፣ ምንም እንኳን ይህ አንዳንድ ጊዜ ቢመችም።
///
/// ## እንዴት ብዬ `Copy` መተግበር እንችላለን?
///
/// በእርስዎ አይነት ላይ `Copy` ለመተግበር ሁለት መንገዶች አሉ.ቀላሉ ለመጠቀም `derive` ነው:
///
/// ```
/// #[derive(Copy, Clone)]
/// struct MyStruct;
/// ```
///
/// እንዲሁም እራስዎ `Copy` እና `Clone` ተግባራዊ ይችላሉ:
///
/// ```
/// struct MyStruct;
///
/// impl Copy for MyStruct { }
///
/// impl Clone for MyStruct {
///     fn clone(&self) -> MyStruct {
///         *self
///     }
/// }
/// ```
///
/// በሁለቱ መካከል ትንሽ ልዩነት አለ; ደግሞ አንድ `Copy` ያስቀምጣል በ `derive` ስትራቴጂ ሁልጊዜ የማይፈለግ ሲሆን ብቻ ነው ይህም ዓይነት መለኪያዎች ላይ አሰረው.
///
/// ## `Copy` እና `Clone` መካከል ያለው ልዩነት ምንድን ነው?
///
/// ቅጂዎች አንድ ኃላፊነት `y = x` አካል ሆኖ ለምሳሌ ያህል, በተዘዋዋሪ መንገድ ሊከሰት.የ `Copy` ባህሪ ከመጠን በላይ መጫን አይቻልም።ይህ ሁልጊዜ ቀላል ትንሽ-ጥበብ ቅጂ ነው.
///
/// ክሎኒንግ ግልጽ እርምጃ ነው ፣ `x.clone()`።[`Clone`] ትግበራ በደህና እሴቶች የተባዙ አስፈላጊ ማንኛውም አይነት-ተኮር ባህሪ ማቅረብ ይችላሉ.
/// ለምሳሌ ያህል, [`String`] ለ [`Clone`] ትግበራ ክምር ውስጥ ጫፍ-ወደ ሕብረቁምፊ ቋት ለመቅዳት ይፈልጋል.
/// [`String`] እሴቶች አንድ ቀላል bitwise ቅጂ ብቻ መስመር ታች ድርብ ነጻ ለማድረግ እየመራ ወደ ጠቋሚ ኮፒ ነበር.
/// በዚህ ምክንያት, [`String`] [`Clone`] ግን `Copy` ነው.
///
/// [`Clone`] `Copy` አንድ supertrait ነው, ስለዚህ `Copy` ደግሞ [`Clone`] መተግበር አለበት ነው ሁሉም ነገር.
/// አንድ ዓይነት `Copy` ከሆነ የእሱ የ [`Clone`] አተገባበር `*self` ን ብቻ መመለስ አለበት (ከላይ ያለውን ምሳሌ ይመልከቱ)።
///
/// ## መቼ ነው የእኔ አይነት `Copy` ሊሆን ይችላል?
///
/// ክፍሎቹ ሁሉም `Copy` ተግባራዊ ከሆነ አንድ አይነት `Copy` ተግባራዊ ይችላሉ.ለምሳሌ ፣ ይህ አወቃቀር `Copy` ሊሆን ይችላል-
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Copy, Clone)]
/// struct Point {
///    x: i32,
///    y: i32,
/// }
/// ```
///
/// አንድ አወቃቀር `Copy` ሊሆን ይችላል ፣ እና [`i32`] `Copy` ነው ፣ ስለሆነም `Point` `Copy` ለመሆን ብቁ ነው።
/// በአንፃሩ ደግሞ አስቡበት
///
/// ```
/// # #![allow(dead_code)]
/// # struct Point;
/// struct PointList {
///     points: Vec<Point>,
/// }
/// ```
///
/// [`Vec<T>`] `Copy` አይደለም, ምክንያቱም struct `PointList`, `Copy` ተግባራዊ አይችልም.እኛ `Copy` አፈፃፀም ማግኘት መሞከር ከሆነ, እኛ ስህተት ያገኛሉ:
///
/// ```text
/// the trait `Copy` may not be implemented for this type; field `points` does not implement `Copy`
/// ```
///
/// አንድ አይነት `Copy` መሆን እንዲችሉ የተጋሩ ማጣቀሻዎች (`&T`) ይህ *`Copy`* ያልሆኑ ዓይነቶች ማጣቀሻዎች `T` የተጋሩ የያዘው እንኳ ጊዜ: ደግሞ `Copy` ናቸው.
/// `Copy` ን ተግባራዊ ሊያደርግ የሚችል የሚከተለውን መዋቅር ያስቡ ፣ ምክንያቱም የእኛን `ኮፒ` ዓይነት `PointList` ያልሆነ *የተጋራ ማጣቀሻ* ብቻ ስለሚይዝ-
///
/// ```
/// # #![allow(dead_code)]
/// # struct PointList;
/// #[derive(Copy, Clone)]
/// struct PointListWrapper<'a> {
///     point_list_ref: &'a PointList,
/// }
/// ```
///
/// ## መቼ * * የእኔን አይነት `Copy` መሆን ይችላሉ?
///
/// አንዳንድ ዓይነቶች በደህና ሊገለበጡ አይችሉም።ለምሳሌ ያህል, `&mut T` በመገልበጥ ዕውቅ የሆነ ሊቀየሩ ማጣቀሻ መፍጠር ነበር.
/// [`String`] ን መገልበጥ የ [`String`] ን ቋት የማስተዳደር ሃላፊነትን ያባዛል ፣ ይህም ወደ እጥፍ ነፃ ይመራል።
///
/// የመጨረሻውን ጉዳይ ጠቅለል አድርጎ ሲገልጽ ፣ [`Drop`] ን የሚተገበር ማንኛውም ዓይነት `Copy` ሊሆን አይችልም ፣ ምክንያቱም ከራሱ [`size_of::<T>`] ባይት በተጨማሪ የተወሰነ ሀብትን እያስተዳደረ ስለሆነ ፡፡
///
/// እናንተ ያልሆኑ `Copy` ውሂብ የያዘ struct ወይም enum ላይ `Copy` ተግባራዊ ለማድረግ ይሞክሩ ከሆነ ስህተት [E0204] ያገኛሉ.
///
/// [E0204]: ../../error-index.html#E0204
///
/// ## መቼ * * የእኔን አይነት `Copy` መሆን አለበት?
///
/// በአጠቃላይ የእርስዎ አይነት _can_ `Copy` ተግባራዊ ከሆነ, ይህ ይገባል መናገር.
/// ምንም እንኳን `Copy` ን መተግበር የእርስዎ ዓይነት የህዝብ ኤ.ፒ.አይ. አካል መሆኑን ያስታውሱ ፡፡
/// አይነቱ future ውስጥ ያልሆኑ `Copy` እንሆን ከሆነ አንድ ሰበር ኤ ለውጥ ለማስቀረት, አሁን `Copy` አፈፃፀም ከመዘገብ አስተዋይነት ሊሆን ይችላል.
///
/// ## ተጨማሪ ፈፃሚዎች
///
/// ከ [implementors listed below][impls] በተጨማሪ የሚከተሉት ዓይነቶች `Copy` ን ይተገብራሉ-
///
/// * የተግባር ንጥል ዓይነቶች (ማለትም ፣ ለእያንዳንዱ ዓይነቶች የተገለጹት ልዩ ዓይነቶች)
/// * የተግባር ጠቋሚ ዓይነቶች (ለምሳሌ ፣ `fn() -> i32`)
/// * ድርድር አይነቶች, ሁሉም መጠኖች, ወደ ንጥል ዓይነት ደግሞ `Copy` የሚያስፈጽም ከሆነ (ለምሳሌ, `[i32; 123456]`)
/// * Tuple አይነቶች, እያንዳንዱ አካል ደግሞ `Copy` የሚያስፈጽም ከሆነ (ለምሳሌ, `()`, `(i32, bool)`)
/// * መዘጋት አይነቶች, እነሱ አካባቢ ምንም ዋጋ ለመያዝ ከሆነ ወይም ሁሉንም እንደ የተያዙ እሴቶች `Copy` ራሳቸውን ተግባራዊ ከሆነ.
///   በጋራ ማጣቀሻ የተያዙ ተለዋዋጮች ሁል ጊዜ `Copy` ን ይተገብራሉ (ምንም እንኳን ጠቋሚው ባይሆንም) ፣ በሚለዋወጥ ማጣቀሻ የተያዙ ተለዋዋጮች ግን `Copy` ን በጭራሽ አይተገበሩም ፡፡
///
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
/// [`String`]: ../../std/string/struct.String.html
/// [`size_of::<T>`]: crate::mem::size_of
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "copy"]
// FIXME(matthewjasper) ይህ ምክንያቱም ሳይሟላ የህይወት የድርድሮች `Copy` ተግባራዊ እንዳልሆነ አንድ አይነት በመገልበጥ ያስችላል (`A<'_>` በመቅዳት ጊዜ ብቻ `A<'static>: Copy` እና `A<'_>: Clone`).
// እኛ አሁን እዚህ ጋር ያለንን ባሕርይ በ‹XXXX›ላይ በመደበኛነት ባለው ቤተ-መጽሐፍት ውስጥ ቀድሞውኑ ያሉ ጥቂት ልዩ ባለሙያዎች ስላሉ ብቻ እና አሁን ይህንን ባህሪ በደህና ለማግኝት ምንም መንገድ የለም ፡፡
//
//
//
//
#[rustc_unsafe_specialization_marker]
pub trait Copy: Clone {
    // Empty.
}

/// የ `trait `Copy` ን ውጤት የሚያመነጭ ማክሮን ያግኙ ፡፡
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Copy($item:item) {
    /* compiler built-in */
}

/// በክርዎች መካከል ማጣቀሻዎችን ማጋራት ለደህንነታቸው ዓይነቶች።
///
/// የ አጠናቃሪ ተገቢ ነው ይወስናል ጊዜ ይህ trait ሰር አልተተገበረም ነው.
///
/// ትክክለኛ ትርጉም ነው: አንድ አይነት `T` [`Sync`] ከሆነ ብቻ `&T` [`Send`] ከሆነ ነው.
/// በሌላ አነጋገር ፣ በክሮች መካከል የ `&T` ማመሳከሪያዎችን ሲያስተላልፉ የ [undefined behavior][ub] (የመረጃ ውድድሮችን ጨምሮ) ምንም ዕድል ከሌለ ፡፡
///
/// አንድ ሰው የምትጠብቀውን እንደ [`u8`] እና [`f64`] እንደ ኋላቀር አይነቶች ሁሉ [`Sync`] ናቸው, ስለዚህ tuples, structs እና enums እንደ የያዙ ቀላል ድምር አይነቶች ናቸው.
/// መሠረታዊ [`Sync`] አይነቶች ተጨማሪ ምሳሌዎች "immutable" `&T` እንደ አይነቶች, እና እንደ [`Box<T>`][box], [`Vec<T>`][vec] እና አብዛኞቹ ሌሎች ስብስብ አይነቶች እንደ ቀላል በውርስ mutability ጋር ሰዎች, ያካትታሉ.
///
/// (ወጥ መለኪያዎች [`Sync`] እንዲሆኑ ያላቸውን መያዣ ለ [`Sync`] መሆን ያስፈልገናል.)
///
/// ስለ ትርጉም አንድ ነገር የሚያስደንቅ ውጤት `&mut T` በዚያ unsynchronized የሚውቴሽን ማቅረብ ይችላል እንደ ይመስላል እንኳ (`T` `Sync` ከሆነ) `Sync` መሆኑን ነው.
/// የ ብልሃት አንድ `& &T` ከሆነ እንደ አንድ የተጋራ ማጣቀሻ ጀርባ አንድ ሊቀየሩ ማጣቀሻ (ማለትም, `& &mut T` ነው),-ብቻ ማንበብ በጣም የሚወድ መሆኑ ነው.
/// ስለሆነም የመረጃ ውድድር አደጋ የለውም ፡፡
///
/// `Sync` ያልሆኑ አይነቶች እንደ [`Cell`][cell] እና [`RefCell`][refcell] እንደ ያልሆነ ክር-ደህና መልክ "interior mutability" ያላቸው ሰዎች ናቸው.
/// እነዚህ ዓይነቶች በማይለዋወጥ ፣ በጋራ ማጣቀሻ በኩል እንኳን ይዘታቸውን ለመለወጥ ያስችሉታል ፡፡
/// ብቻ አንድ የተጋራ ማጣቀሻ [`&Cell<T>`][cell] ይጠይቃል ስለዚህ ለምሳሌ ያህል [`Cell<T>`][cell] ላይ `set` ዘዴ, `&self` ይወስዳል.
/// ዘዴው ምንም ማመሳሰልን አያከናውንም ፣ ስለሆነም [`Cell`][cell] `Sync` ሊሆን አይችልም።
///
/// የ `ሲንክ` ያልሆነ ሌላ ምሳሌ የማጣቀሻ ቆጠራ ጠቋሚ [`Rc`][rc] ነው።
/// ማንኛውም ማጣቀሻ [`&Rc<T>`][rc] የተሰጠ, እናንተ ያልሆነ-አቶሚክ መንገድ ማጣቀሻ ቆጠራዎች መቀየር, አዲስ [`Rc<T>`][rc] ችግኖ ይችላሉ.
///
/// አንድ ሰው በክር ደህንነቱ የተጠበቀ ውስጣዊ ለውጥን በሚፈልግበት ጊዜ Rust [atomic data types] ን ያቀርባል ፣ እንዲሁም በ [`sync::Mutex`][mutex] እና [`sync::RwLock`][rwlock] በኩል ግልጽ መቆለፊያ ይሰጣል።
/// እነዚህ ዓይነቶች ማንኛውም ሚውቴሽን የውሂብ ውድድሮችን ሊያስከትል እንደማይችል ያረጋግጣሉ ፣ ስለሆነም አይነቶች `Sync` ናቸው።
/// እንደዚሁም [`sync::Arc`][arc] በ‹XXXX›ክር ደህንነቱ የተጠበቀ አናሎግ ይሰጣል ፡፡
///
/// በውስጣዊ ተለዋዋጭነት ያላቸው ማናቸውም ዓይነቶች እንዲሁ በ‹value(s)›ዙሪያ ያለውን የ‹XXXX›መጠቅለያውን በጋራ መጠቀሻ በኩል ሊለወጡ ይገባል ፡፡
/// ይህን ማድረግ አለማድረግ [undefined behavior][ub] ነው.
/// ለምሳሌ ፣ ከ `&T` ወደ `&mut T` [transmute`][transmute]-ing ልክ ያልሆነ ነው።
///
/// `Sync` ተጨማሪ ዝርዝሮችን ለማግኘት [the Nomicon][nomicon-send-and-sync] ይመልከቱ.
///
/// [box]: ../../std/boxed/struct.Box.html
/// [vec]: ../../std/vec/struct.Vec.html
/// [cell]: crate::cell::Cell
/// [refcell]: crate::cell::RefCell
/// [rc]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [atomic data types]: crate::sync::atomic
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [unsafecell]: crate::cell::UnsafeCell
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [transmute]: crate::mem::transmute
/// [nomicon-send-and-sync]: ../../nomicon/send-and-sync.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "sync_trait")]
#[lang = "sync"]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be shared between threads safely",
    label = "`{Self}` cannot be shared between threads safely"
)]
pub unsafe auto trait Sync {
    // FIXME(estebank): `rustc_on_unimplemented` ይሁንታ ላይ እንደወደቀና, እና አንድ መዘጋት መመዘኛ ሰንሰለት ውስጥ በማንኛውም ቦታ ነው አለመሆኑን ለማረጋገጥ ተራዝሟል ድጋፍ ማስታወሻዎችን ለማከል አንድ ጊዜ, እንደ (#48534) እንደ ማራዘም;
    //
    //
    // ```
    // on(
    //     closure,
    //     note="`{Self}` cannot be shared safely, consider marking the closure `move`"
    // ),
    // ```

    // Empty
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *mut T {}

macro_rules! impls {
    ($t: ident) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Hash for $t<T> {
            #[inline]
            fn hash<H: Hasher>(&self, _: &mut H) {}
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialEq for $t<T> {
            fn eq(&self, _other: &$t<T>) -> bool {
                true
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Eq for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialOrd for $t<T> {
            fn partial_cmp(&self, _other: &$t<T>) -> Option<cmp::Ordering> {
                Option::Some(cmp::Ordering::Equal)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Ord for $t<T> {
            fn cmp(&self, _other: &$t<T>) -> cmp::Ordering {
                cmp::Ordering::Equal
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Copy for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Clone for $t<T> {
            fn clone(&self) -> Self {
                Self
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Default for $t<T> {
            fn default() -> Self {
                Self
            }
        }

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralPartialEq for $t<T> {}

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralEq for $t<T> {}
    };
}

/// "act like" እነርሱ `T` ባለቤት ነገሮች ምልክት ጥቅም ላይ ዜሮ-መጠን ያላቸው ዓይነት.
///
/// የእርስዎ አይነት አንድ `PhantomData<T>` መስክ ማከል በእርግጥ ባይሆንም እንኳ ቢሆንም, አይነት `T` አንድ እሴት የሚያከማች ቢሆንም እንደ ዓይነት እርምጃ መሆኑን አጠናቃሪ ይነግረናል.
/// አንዳንድ የደህንነት ባህሪያት ማስላት ጊዜ ይህ መረጃ ጥቅም ላይ ይውላል.
///
/// `PhantomData<T>` እንዴት መጠቀም እንደሚቻል የበለጠ ጥልቀት ያለው ማብራሪያ ለማግኘት, [the Nomicon](../../nomicon/phantom-data.html) ይመልከቱ.
///
/// # አንድ በሚነዱ ማስታወሻ 👻👻👻
///
/// ሁለቱም አስፈሪ ስሞች ያላቸው ቢሆንም, `PhantomData` እና 'የውሸት አይነቶች' የተያያዙ, ነገር ግን ተመሳሳይ አይደሉም.የውሸት ዓይነት መለኪያ በቀላሉ የማይጠቅም ዓይነት ግቤት ነው።
/// በ Rust ውስጥ ይህ ብዙውን ጊዜ አጠናቃሪውን እንዲያማርር ያደርገዋል ፣ መፍትሄውም በ `PhantomData` በኩል የ "dummy" አጠቃቀምን ማከል ነው ፡፡
///
/// # Examples
///
/// ## ጥቅም ላይ ያልዋሉ የዕድሜ መለኪያዎች
///
/// ምናልባት ለ‹`PhantomData` X›በጣም የተለመደው የመጠቀም ጉዳይ ጥቅም ላይ ያልዋለ የዕድሜ ልክ መለኪያ ያለው መዋቅር ነው ፣ በተለይም እንደ አንዳንድ ደህንነቱ ያልተጠበቀ ኮድ አካል ነው ፡፡
/// ለምሳሌ ያህል, እዚህ አይነት `*const T`, የበደልን ድርድር ቦታ ወደ በመጠቆም ሁለት ዘዴውን ያለው struct `Slice` ነው:
///
/// ```compile_fail,E0392
/// struct Slice<'a, T> {
///     start: *const T,
///     end: *const T,
/// }
/// ```
///
/// ዓላማቸው, የተነሳበትን ውሂብ ወደ ዕድሜ ልክ `'a` ብቻ የሚሰራ መሆኑን ነው `Slice` ይገባል የበለጠ ዕድሜ አይደለም `'a` እንዲሁ.
/// ሆኖም ግን ፣ ይህ ዓላማ በሕጉ ውስጥ አልተገለጸም ፣ ምክንያቱም የህይወት ዘመን `'a` ምንም ጥቅም ስለሌለ እና ስለዚህ ምን ውሂብ እንደሚመለከት ግልፅ አይደለም።
/// የ `Slice` አወቃቀሩ `&'a T` ን እንደያዘ *አዘጋጁ እንዲሰራ* በመናገር ይህንን ማስተካከል እንችላለን-
///
/// ```
/// use std::marker::PhantomData;
///
/// # #[allow(dead_code)]
/// struct Slice<'a, T: 'a> {
///     start: *const T,
///     end: *const T,
///     phantom: PhantomData<&'a T>,
/// }
/// ```
///
/// ደግሞ በተራቸው በዚህ `T` ማንኛውም ማጣቀሻዎች የዕድሜ ልክ `'a` ላይ ልክ እንደሆኑ የሚጠቁሙ ወደ ማብራሪያው `T: 'a` ይጠይቃል.
///
/// `Slice` ን ሲጀምሩ ለእርሻ `phantom` በቀላሉ `PhantomData` ዋጋን ይሰጣሉ
///
/// ```
/// # #![allow(dead_code)]
/// # use std::marker::PhantomData;
/// # struct Slice<'a, T: 'a> {
/// #     start: *const T,
/// #     end: *const T,
/// #     phantom: PhantomData<&'a T>,
/// # }
/// fn borrow_vec<T>(vec: &Vec<T>) -> Slice<'_, T> {
///     let ptr = vec.as_ptr();
///     Slice {
///         start: ptr,
///         end: unsafe { ptr.add(vec.len()) },
///         phantom: PhantomData,
///     }
/// }
/// ```
///
/// ## ጥቅም ላይ ያልዋሉ ዓይነት መለኪያዎች
///
/// አንዳንድ ጊዜ አንድ struct ውሂብ በትክክል struct በራሱ ውስጥ አልተገኘም እንኳ ወደ "tied" ምን የውሂብ አይነት የሚጠቁም ይህም ያልዋለ አይነት ግቤቶች እንዳላቸው ይከሰታል.
/// ይህ ከ [FFI] ጋር የሚነሳበት ምሳሌ ይኸውልዎት።
/// አይነት `*mut ()` ያለው የውጭ በይነገጽ አጠቃቀሞች እጀታ የተለያዩ ዓይነቶች Rust እሴቶች ለማመልከት ነው.
/// እኛ አንድ እጀታ ይጠቀለላል ይህም struct `ExternalResource` ላይ የውሸት ዓይነት መለኪያ በመጠቀም Rust አይነት ይከታተሉ.
///
/// [FFI]: ../../book/ch19-01-unsafe-rust.html#using-extern-functions-to-call-external-code
///
/// ```
/// # #![allow(dead_code)]
/// # trait ResType { }
/// # struct ParamType;
/// # mod foreign_lib {
/// #     pub fn new(_: usize) -> *mut () { 42 as *mut () }
/// #     pub fn do_stuff(_: *mut (), _: usize) {}
/// # }
/// # fn convert_params(_: ParamType) -> usize { 42 }
/// use std::marker::PhantomData;
/// use std::mem;
///
/// struct ExternalResource<R> {
///    resource_handle: *mut (),
///    resource_type: PhantomData<R>,
/// }
///
/// impl<R: ResType> ExternalResource<R> {
///     fn new() -> Self {
///         let size_of_res = mem::size_of::<R>();
///         Self {
///             resource_handle: foreign_lib::new(size_of_res),
///             resource_type: PhantomData,
///         }
///     }
///
///     fn do_stuff(&self, param: ParamType) {
///         let foreign_params = convert_params(param);
///         foreign_lib::do_stuff(self.resource_handle, foreign_params);
///     }
/// }
/// ```
///
/// ## የባለቤትነት እና የመጣል ቼክ
///
/// አይነት መስክ ማከል `PhantomData<T>` የእርስዎን አይነት አይነት `T` የውሂብ በባለቤትነት መሆኑን ይጠቁማል.ይህ በተራው ውስጥ አይነት ጣለች ጊዜ, ይህ አይነት `T` አንድ ወይም ተጨማሪ አብነቶችን መጣል እንደሚችል ያመለክታል.
/// ይህ በ Rust አጠናቃሪ የ [drop check] ትንታኔ ላይ ተጽዕኖ አለው።
///
/// በእርስዎ struct እንዲያውም ከሌለው *የገዛ* አይነት `T` ውሂብ, በጣም እንደ ባለቤትነት ለማመላከት አይደለም, `PhantomData<&'a T>` (ideally) ወይም (ምንም የህይወት ተግባራዊ ከሆነ) `PhantomData<*const T>` እንደ ማጣቀሻ አይነት መጠቀም የተሻለ ነው.
///
///
/// [drop check]: ../../nomicon/dropck.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "phantom_data"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct PhantomData<T: ?Sized>;

impls! { PhantomData }

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Sync + ?Sized> Send for &T {}
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Send + ?Sized> Send for &mut T {}
}

/// የማቀናበሪያ-ውስጣዊ trait enum discriminants ዓይነት የሚጠቁም ነበር.
///
/// ይህ trait በራስ እያንዳንዱ አይነት ተግባራዊ ሲሆን [`mem::Discriminant`] ምንም ዋስትና ማከል አይደለም.
/// ይህ **ያልተገለጸ ባህሪ**`DiscriminantKind::Discriminant` እና `mem::Discriminant` መካከል transmute ነው.
///
/// [`mem::Discriminant`]: crate::mem::Discriminant
///
#[unstable(
    feature = "discriminant_kind",
    issue = "none",
    reason = "this trait is unlikely to ever be stabilized, use `mem::discriminant` instead"
)]
#[lang = "discriminant_kind"]
pub trait DiscriminantKind {
    /// በ `mem::Discriminant` የሚፈለገውን የ trait bounds ን ማሟላት ያለበት የአድልዎ ዓይነት።
    ///
    #[lang = "discriminant_type"]
    type Discriminant: Clone + Copy + Debug + Eq + PartialEq + Hash + Send + Sync + Unpin;
}

/// የማቀናበሪያ-ውስጣዊ trait እንጂ አንድ indirection በኩል, አንድ ዓይነት በውስጥ ማንኛውም `UnsafeCell` ይዟል አለመሆኑን ለመወሰን ያገለግላል.
///
/// ይህ ለምሳሌ አንድ የ `static` አይነት ሊነበብ በሚችል የማይንቀሳቀስ ማህደረ ትውስታ ወይም በሚፃፍ የማይንቀሳቀስ ማህደረ ትውስታ ውስጥ ይቀመጣል ፡፡
///
#[lang = "freeze"]
pub(crate) unsafe auto trait Freeze {}

impl<T: ?Sized> !Freeze for UnsafeCell<T> {}
unsafe impl<T: ?Sized> Freeze for PhantomData<T> {}
unsafe impl<T: ?Sized> Freeze for *const T {}
unsafe impl<T: ?Sized> Freeze for *mut T {}
unsafe impl<T: ?Sized> Freeze for &T {}
unsafe impl<T: ?Sized> Freeze for &mut T {}

/// በደህና እየተሰካ በኋላ ተንቀሳቅሷል የሚችሉ አይነቶች.
///
/// Rust ራሱ የማይነቃነቁ አይነቶች ግንዛቤ የለውም ፣ እናም እንቅስቃሴዎችን (ለምሳሌ በምደባ ወይም በ [`mem::replace`] በኩል) ሁል ጊዜም ደህና እንደሆነ ያስባል።
///
/// የ [`Pin`][Pin] አይነት ዓይነት ሥርዓት በኩል ይንቀሳቀሳል ለመከላከል ፋንታ ጥቅም ላይ ይውላል.የጠቋሚዎች `P<T>` ውጭ ሊንቀሳቀስ አይችልም መጠቅለያ በ [`Pin<P<T>>`][Pin] ላይ ተጠመጠመ.
/// መሰካት ላይ ተጨማሪ መረጃ ለማግኘት [`pin` module] ሰነድ ይመልከቱ.
///
/// `T` ለ `Unpin` trait ተግባራዊ ከዚያም እንደ [`mem::replace`] እንደ ተግባሮች ጋር [`Pin<P<T>>`][Pin] ውጪ `T` መንቀሳቀስ ያስችላል ያለውን አይነት ጠፍቷል, መሰካት ላይ ያለውን ገደቦች ያነሳቸዋል.
///
///
/// `Unpin` ያልሆኑ የተሰኩ ውሂብ ሁሉ ላይ ምንም ውጤት የለውም.
/// በተለይም, [`mem::replace`] በደስታ (ይህም, ማንኛውም `&mut T` ይሰራል ብቻ ሳይሆን ጊዜ `T: Unpin`) `!Unpin` ውሂብ ያነሳሳቸዋል.
/// ሆኖም ፣ በ‹[`Pin<P<T>>`][Pin]›ውስጥ በተጠቀለለው መረጃ ላይ [`mem::replace`] ን መጠቀም አይችሉም ምክንያቱም ለዚያ የሚፈልጉትን `&mut T` ማግኘት አይችሉም ፣ እና *ያ* ይህ ስርዓት እንዲሠራ የሚያደርገው ነው።
///
/// ስለዚህ ይህ ለምሳሌ ሊከናወን የሚችለው `Unpin` ን በሚተገብሩ ዓይነቶች ላይ ብቻ ነው
///
/// ```rust
/// # #![allow(unused_must_use)]
/// use std::mem;
/// use std::pin::Pin;
///
/// let mut string = "this".to_string();
/// let mut pinned_string = Pin::new(&mut string);
///
/// // እኛ `mem::replace` ለመደወል አንድ ሊቀየሩ ማጣቀሻ ያስፈልጋቸዋል.
/// // `Pin::deref_mut` ን በመጥራት እንዲህ ዓይነቱን ማጣቀሻ በ (implicitly) ማግኘት እንችላለን ፣ ግን ያ ሊሆን የሚችለው `String` `Unpin` ን ስለሚተገብር ብቻ ነው።
/////
/// mem::replace(&mut *pinned_string, "other".to_string());
/// ```
///
/// ይህ trait ለሁሉም ዓይነት ማለት ይቻላል በራስ-ሰር ይተገበራል ፡፡
///
/// [`mem::replace`]: crate::mem::replace
/// [Pin]: crate::pin::Pin
/// [`pin` module]: crate::pin
///
///
///
///
///
///
#[stable(feature = "pin", since = "1.33.0")]
#[rustc_on_unimplemented(
    on(_Self = "std::future::Future", note = "consider using `Box::pin`",),
    message = "`{Self}` cannot be unpinned"
)]
#[lang = "unpin"]
pub auto trait Unpin {}

/// `Unpin` ለመተግበር አይደለም ይህም አንድ ማድረጊያ አይነት.
///
/// አንድ አይነት የሆነ `PhantomPinned` የያዘ ከሆነ, በነባሪነት `Unpin` ተግባራዊ አይሆንም.
#[stable(feature = "pin", since = "1.33.0")]
#[derive(Debug, Default, Copy, Clone, Eq, PartialEq, Ord, PartialOrd, Hash)]
pub struct PhantomPinned;

#[stable(feature = "pin", since = "1.33.0")]
impl !Unpin for PhantomPinned {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a T {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a mut T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *const T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *mut T {}

/// ኋላቀር አይነቶች `Copy` ውስጥ ማስፈጸሚያዎች.
///
/// በ Rust ውስጥ ሊገለጹ የማይችሉ ትግበራዎች በ X0 `rustc_trait_selection` ውስጥ በ `traits::SelectionContext::copy_clone_conditions()` ውስጥ ይተገበራሉ።
///
///
mod copy_impls {

    use super::Copy;

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Copy for ! {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *const T {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *mut T {}

    /// የተጋሩ ማጣቀሻ ሊቀዳ ይችላል, ነገር ግን ሊቀየሩ የሚችሉ ማጣቀሻዎችን *አይችሉም*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for &T {}
}