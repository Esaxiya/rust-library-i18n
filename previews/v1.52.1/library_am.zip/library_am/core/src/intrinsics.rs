//! የማጠናከሪያ ውስጣዊ.
//!
//! ተጓዳኝ ትርጓሜዎች በ `compiler/rustc_codegen_llvm/src/intrinsic.rs` ውስጥ ናቸው።
//! ተጓዳኝ የኮንስትራክሽን ትግበራዎች በ `compiler/rustc_mir/src/interpret/intrinsics.rs` ውስጥ ናቸው
//!
//! # ኮንስ ውስጣዊ
//!
//! Note: intrinsics መካከል constness ማንኛውም ለውጦች ቋንቋ ቡድን ጋር ውይይት አለበት.
//! ይህ constness ያለውን መረጋጋት ላይ ለውጥ ያካትታል.
//!
//! ያጠናቅራል-ጊዜ ላይ የሚያስገርም ላይሰሩ ለማድረግ እንዲቻል, አንድ ፍላጎት `compiler/rustc_mir/src/interpret/intrinsics.rs` ወደ <https://github.com/rust-lang/miri/blob/master/src/shims/intrinsics.rs> እስከ አፈፃፀም መገልበጥ እና ነጥሎ አንድ `#[rustc_const_unstable(feature = "foo", issue = "01234")]` ያክሉ.
//!
//!
//! አንድ ውስጣዊ ከ `const fn` ከ `rustc_const_stable` አይነታ ጋር ጥቅም ላይ መዋል ያለበት ከሆነ ፣ የውስጠ-ባህሪው `rustc_const_stable` መሆን አለበት ፡፡
//! ይህ አጠናቃሪ ድጋፍ ያለ የተጠቃሚ ኮድ ውስጥ ሊደገም የማይችል ቋንቋ ወደ አንድ ባህሪ ይጋግርበታል; ምክንያቱም እንዲህ ዓይነቱ ለውጥ, ቲ-lang በመመካከር ያለ መደረግ የለበትም.
//!
//! # Volatiles
//!
//! ተለዋዋጭ የሆኑት ውስጣዊ ነገሮች በ I/O ማህደረ ትውስታ ላይ እርምጃ ለመውሰድ የታቀዱ ሥራዎችን ይሰጣሉ ፣ እነዚህም በሌሎች ተለዋዋጭ ውስጣዊ ውስጣዊ ይዘቶች በአቀራባሪው እንደገና እንዳይመለሱ ዋስትና ተሰጥቷቸዋል።[[volatile]] ላይ LLVM ሰነድ ይመልከቱ.
//!
//! [volatile]: http://llvm.org/docs/LangRef.html#volatile-memory-accesses
//!
//! # Atomics
//!
//! የአቶሚክ ውስጠ-ህዋሳት በርካታ የአቶሚክ አሠራሮችን በማሽኑ ቃላት ላይ የተለመዱ የአቶሚክ አሠራሮችን ይሰጣሉ ፡፡እነዚህ C++ 11 ተመሳሳይ የቃላት ትርጉም ታዘዙ.በኤክስኤክስክስክስ ላይ የኤልኤልቪኤም ሰነድን ይመልከቱ ፡፡
//!
//! [atomics]: http://llvm.org/docs/Atomics.html
//!
//! ትውስታ አደራደር ላይ ፈጣን አዳሽ:
//!
//! * መቆለፊያ ለማግኘት እንቅፋት ያግኙ።ቀጣይ ንባብ እና መጻፍ ከእንቅፋቱ በኋላ ይከናወናሉ ፡፡
//! * መልቀቅ ፣ መቆለፊያ ለመልቀቅ እንቅፋት ፡፡እንቅፋቱ ከመደረጉ በፊት ንባቦችን እና ጽሑፎችን መቅደም ይከናወናል ፡፡
//! * በቅደም ተከተል ወጥነት, በቅደም ተከተል ወጥ ተግባር ቅደም ተከተል ላይ እንዲደርሱ ዋስትና ነው.ይህ ከአቶሚክ ዓይነቶች ጋር ለመስራት መደበኛ ሁነታ ሲሆን ከ Java`s `volatile` ጋር እኩል ነው።
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![unstable(
    feature = "core_intrinsics",
    reason = "intrinsics are unlikely to ever be stabilized, instead \
                      they should be used through stabilized interfaces \
                      in the rest of the standard library",
    issue = "none"
)]
#![allow(missing_docs)]

use crate::marker::DiscriminantKind;
use crate::mem;

// እነዚህ ከውጭ አሰራር መምጣት ሰነድ አገናኞች ቀላል የሚውሉት
#[allow(unused_imports)]
#[cfg(all(target_has_atomic = "8", target_has_atomic = "32", target_has_atomic = "ptr"))]
use crate::sync::atomic::{self, AtomicBool, AtomicI32, AtomicIsize, AtomicU32, Ordering};

#[stable(feature = "drop_in_place", since = "1.8.0")]
#[rustc_deprecated(
    reason = "no longer an intrinsic - use `ptr::drop_in_place` directly",
    since = "1.52.0"
)]
#[inline]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // ደህንነት `ptr::drop_in_place` ን ይመልከቱ
    unsafe { crate::ptr::drop_in_place(to_drop) }
}

extern "rust-intrinsic" {
    // እነርሱ `&` ወይም `&mut` ወይ ትክክል አይደለም ይህም ዕውቅ ትውስታ, ትጀምሩ ምክንያቱም ማስታወሻ: እነዚህን intrinsics ጥሬ ዘዴውን ይወስዳሉ.
    //

    /// የአሁኑ ዋጋ ከ `old` እሴት ጋር ተመሳሳይ ከሆነ አንድ እሴት ያከማቻል።
    ///
    /// በዚህ ነጥሎ ያለው የሚደረግልዎት ስሪት በሁለቱም `success` እና `failure` ግቤቶች እንደ [`Ordering::SeqCst`] በማለፍ በ `compare_exchange` ዘዴ በኩል [`atomic`] አይነቶች ላይ ይገኛል.
    ///
    /// ለምሳሌ, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// የአሁኑ ዋጋ ከ `old` እሴት ጋር ተመሳሳይ ከሆነ አንድ እሴት ያከማቻል።
    ///
    /// የተስተካከለ የዚህ ውስጣዊ ስሪት በ [`atomic`] አይነቶች ላይ በ `compare_exchange` ዘዴ በኩል [`Ordering::Acquire`] ን እንደ `success` እና `failure` መለኪያዎች በማለፍ ይገኛል ፡፡
    ///
    /// ለምሳሌ, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// የአሁኑ ዋጋ ከ `old` እሴት ጋር ተመሳሳይ ከሆነ አንድ እሴት ያከማቻል።
    ///
    /// የተስተካከለ የዚህ ውስጣዊ ስሪት በ [`atomic`] አይነቶች ላይ በ `compare_exchange` ዘዴ በኩል [`Ordering::Release`] ን እንደ `success` እና [`Ordering::Relaxed`] እንደ `failure` መለኪያዎች በማለፍ ይገኛል ፡፡
    /// ለምሳሌ, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// የአሁኑ ዋጋ ከ `old` እሴት ጋር ተመሳሳይ ከሆነ አንድ እሴት ያከማቻል።
    ///
    /// የተስተካከለ የዚህ ውስጣዊ ስሪት በ [`atomic`] አይነቶች ላይ በ `compare_exchange` ዘዴ በኩል [`Ordering::AcqRel`] ን እንደ `success` እና [`Ordering::Acquire`] እንደ `failure` መለኪያዎች በማለፍ ይገኛል ፡፡
    /// ለምሳሌ, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// የአሁኑ ዋጋ ከ `old` እሴት ጋር ተመሳሳይ ከሆነ አንድ እሴት ያከማቻል።
    ///
    /// የተስተካከለ የዚህ ውስጣዊ ስሪት በ [`atomic`] አይነቶች ላይ በ `compare_exchange` ዘዴ በኩል [`Ordering::Relaxed`] ን እንደ `success` እና `failure` መለኪያዎች በማለፍ ይገኛል ፡፡
    ///
    /// ለምሳሌ, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// የአሁኑ ዋጋ ከ `old` እሴት ጋር ተመሳሳይ ከሆነ አንድ እሴት ያከማቻል።
    ///
    /// በዚህ ነጥሎ ያለው የሚደረግልዎት ስሪት `failure` መለኪያዎች እንደ `success` እና [`Ordering::Relaxed`] እንደ [`Ordering::SeqCst`] በማለፍ በ `compare_exchange` ዘዴ በኩል [`atomic`] አይነቶች ላይ ይገኛል.
    /// ለምሳሌ, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// የአሁኑ ዋጋ ከ `old` እሴት ጋር ተመሳሳይ ከሆነ አንድ እሴት ያከማቻል።
    ///
    /// የተስተካከለ የዚህ ውስጣዊ ስሪት በ [`atomic`] አይነቶች ላይ በ `compare_exchange` ዘዴ በኩል [`Ordering::SeqCst`] ን እንደ `success` እና [`Ordering::Acquire`] እንደ `failure` መለኪያዎች በማለፍ ይገኛል ፡፡
    /// ለምሳሌ, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// የአሁኑ ዋጋ ከ `old` እሴት ጋር ተመሳሳይ ከሆነ አንድ እሴት ያከማቻል።
    ///
    /// በዚህ ነጥሎ ያለው የሚደረግልዎት ስሪት `failure` መለኪያዎች እንደ `success` እና [`Ordering::Relaxed`] እንደ [`Ordering::Acquire`] በማለፍ በ `compare_exchange` ዘዴ በኩል [`atomic`] አይነቶች ላይ ይገኛል.
    /// ለምሳሌ, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// የአሁኑ ዋጋ ከ `old` እሴት ጋር ተመሳሳይ ከሆነ አንድ እሴት ያከማቻል።
    ///
    /// በዚህ ነጥሎ ያለው የሚደረግልዎት ስሪት `failure` መለኪያዎች እንደ `success` እና [`Ordering::Relaxed`] እንደ [`Ordering::AcqRel`] በማለፍ በ `compare_exchange` ዘዴ በኩል [`atomic`] አይነቶች ላይ ይገኛል.
    /// ለምሳሌ, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// የአሁኑ ዋጋ ከ `old` እሴት ጋር ተመሳሳይ ከሆነ አንድ እሴት ያከማቻል።
    ///
    /// የተረጋጋ የዚህ ውስጣዊ ስሪት በ [`atomic`] አይነቶች ላይ በ `compare_exchange_weak` ዘዴ በኩል [`Ordering::SeqCst`] ን እንደ `success` እና `failure` መለኪያዎች በማለፍ ይገኛል ፡፡
    ///
    /// ለምሳሌ, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// የአሁኑ ዋጋ ከ `old` እሴት ጋር ተመሳሳይ ከሆነ አንድ እሴት ያከማቻል።
    ///
    /// የተስተካከለ የዚህ ውስጣዊ ስሪት በ [`atomic`] አይነቶች ላይ በ `compare_exchange_weak` ዘዴ በኩል [`Ordering::Acquire`] ን እንደ `success` እና `failure` መለኪያዎች በማለፍ ይገኛል ፡፡
    ///
    /// ለምሳሌ, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// የአሁኑ ዋጋ ከ `old` እሴት ጋር ተመሳሳይ ከሆነ አንድ እሴት ያከማቻል።
    ///
    /// በዚህ ነጥሎ ያለው የሚደረግልዎት ስሪት `failure` መለኪያዎች እንደ `success` እና [`Ordering::Relaxed`] እንደ [`Ordering::Release`] በማለፍ በ `compare_exchange_weak` ዘዴ በኩል [`atomic`] አይነቶች ላይ ይገኛል.
    /// ለምሳሌ, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// የአሁኑ ዋጋ ከ `old` እሴት ጋር ተመሳሳይ ከሆነ አንድ እሴት ያከማቻል።
    ///
    /// የተስተካከለ የዚህ ውስጣዊ ስሪት በ [`atomic`] አይነቶች ላይ በ `compare_exchange_weak` ዘዴ በኩል [`Ordering::AcqRel`] ን እንደ `success` እና [`Ordering::Acquire`] እንደ `failure` መለኪያዎች በማለፍ ይገኛል ፡፡
    /// ለምሳሌ, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// የአሁኑ ዋጋ ከ `old` እሴት ጋር ተመሳሳይ ከሆነ አንድ እሴት ያከማቻል።
    ///
    /// በዚህ ነጥሎ ያለው የሚደረግልዎት ስሪት በሁለቱም `success` እና `failure` ግቤቶች እንደ [`Ordering::Relaxed`] በማለፍ በ `compare_exchange_weak` ዘዴ በኩል [`atomic`] አይነቶች ላይ ይገኛል.
    ///
    /// ለምሳሌ, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// የአሁኑ ዋጋ ከ `old` እሴት ጋር ተመሳሳይ ከሆነ አንድ እሴት ያከማቻል።
    ///
    /// በዚህ ነጥሎ ያለው የሚደረግልዎት ስሪት `failure` መለኪያዎች እንደ `success` እና [`Ordering::Relaxed`] እንደ [`Ordering::SeqCst`] በማለፍ በ `compare_exchange_weak` ዘዴ በኩል [`atomic`] አይነቶች ላይ ይገኛል.
    /// ለምሳሌ, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// የአሁኑ ዋጋ ከ `old` እሴት ጋር ተመሳሳይ ከሆነ አንድ እሴት ያከማቻል።
    ///
    /// በዚህ ነጥሎ ያለው የሚደረግልዎት ስሪት `failure` መለኪያዎች እንደ `success` እና [`Ordering::Acquire`] እንደ [`Ordering::SeqCst`] በማለፍ በ `compare_exchange_weak` ዘዴ በኩል [`atomic`] አይነቶች ላይ ይገኛል.
    /// ለምሳሌ, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// የአሁኑ ዋጋ ከ `old` እሴት ጋር ተመሳሳይ ከሆነ አንድ እሴት ያከማቻል።
    ///
    /// በዚህ ነጥሎ ያለው የሚደረግልዎት ስሪት `failure` መለኪያዎች እንደ `success` እና [`Ordering::Relaxed`] እንደ [`Ordering::Acquire`] በማለፍ በ `compare_exchange_weak` ዘዴ በኩል [`atomic`] አይነቶች ላይ ይገኛል.
    /// ለምሳሌ, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// የአሁኑ ዋጋ ከ `old` እሴት ጋር ተመሳሳይ ከሆነ አንድ እሴት ያከማቻል።
    ///
    /// የተስተካከለ የዚህ ውስጣዊ ስሪት በ [`atomic`] አይነቶች ላይ በ `compare_exchange_weak` ዘዴ በኩል [`Ordering::AcqRel`] ን እንደ `success` እና [`Ordering::Relaxed`] እንደ `failure` መለኪያዎች በማለፍ ይገኛል ፡፡
    /// ለምሳሌ, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// የ ጠቋሚ ያለውን የአሁኑ ዋጋ ይጭናል.
    ///
    /// በዚህ ነጥሎ ያለው የሚደረግልዎት ስሪት `order` እንደ [`Ordering::SeqCst`] በማለፍ በ `load` ዘዴ በኩል [`atomic`] አይነቶች ላይ ይገኛል.
    /// ለምሳሌ, [`AtomicBool::load`].
    ///
    pub fn atomic_load<T: Copy>(src: *const T) -> T;
    /// የ ጠቋሚ ያለውን የአሁኑ ዋጋ ይጭናል.
    ///
    /// የተረጋጋው የዚህ ውስጣዊ ስሪት [`Ordering::Acquire`] ን እንደ `order` በማለፍ በ `load` ዘዴ በኩል በ [`atomic`] አይነቶች ላይ ይገኛል ፡፡
    /// ለምሳሌ, [`AtomicBool::load`].
    ///
    pub fn atomic_load_acq<T: Copy>(src: *const T) -> T;
    /// የ ጠቋሚ ያለውን የአሁኑ ዋጋ ይጭናል.
    ///
    /// በዚህ ነጥሎ ያለው የሚደረግልዎት ስሪት `order` እንደ [`Ordering::Relaxed`] በማለፍ በ `load` ዘዴ በኩል [`atomic`] አይነቶች ላይ ይገኛል.
    /// ለምሳሌ, [`AtomicBool::load`].
    ///
    pub fn atomic_load_relaxed<T: Copy>(src: *const T) -> T;
    pub fn atomic_load_unordered<T: Copy>(src: *const T) -> T;

    /// በተጠቀሰው የማስታወሻ ቦታ ላይ እሴቱን ያከማቻል።
    ///
    /// የተረጋጋ የዚህ ውስጣዊ ስሪት [`Ordering::SeqCst`] ን እንደ `order` በማለፍ በ `store` ዘዴ በኩል በ [`atomic`] አይነቶች ላይ ይገኛል ፡፡
    /// ለምሳሌ, [`AtomicBool::store`].
    ///
    pub fn atomic_store<T: Copy>(dst: *mut T, val: T);
    /// በተጠቀሰው የማስታወሻ ቦታ ላይ እሴቱን ያከማቻል።
    ///
    /// የተረጋጋ የዚህ ውስጣዊ ስሪት [`Ordering::Release`] ን እንደ `order` በማለፍ በ `store` ዘዴ በኩል በ [`atomic`] አይነቶች ላይ ይገኛል ፡፡
    /// ለምሳሌ, [`AtomicBool::store`].
    ///
    pub fn atomic_store_rel<T: Copy>(dst: *mut T, val: T);
    /// በተጠቀሰው የማስታወሻ ቦታ ላይ እሴቱን ያከማቻል።
    ///
    /// የተረጋጋ የዚህ ውስጣዊ ስሪት [`Ordering::Relaxed`] ን እንደ `order` በማለፍ በ `store` ዘዴ በኩል በ [`atomic`] አይነቶች ላይ ይገኛል ፡፡
    /// ለምሳሌ, [`AtomicBool::store`].
    ///
    pub fn atomic_store_relaxed<T: Copy>(dst: *mut T, val: T);
    pub fn atomic_store_unordered<T: Copy>(dst: *mut T, val: T);

    /// እሴቱን በተጠቀሰው ማህደረ ትውስታ ቦታ ላይ ያከማቻል ፣ የድሮውን እሴት ይመልሳል።
    ///
    /// በዚህ ነጥሎ ያለው የሚደረግልዎት ስሪት `order` እንደ [`Ordering::SeqCst`] በማለፍ በ `swap` ዘዴ በኩል [`atomic`] አይነቶች ላይ ይገኛል.
    /// ለምሳሌ, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg<T: Copy>(dst: *mut T, src: T) -> T;
    /// እሴቱን በተጠቀሰው ማህደረ ትውስታ ቦታ ላይ ያከማቻል ፣ የድሮውን እሴት ይመልሳል።
    ///
    /// በዚህ ነጥሎ ያለው የሚደረግልዎት ስሪት `order` እንደ [`Ordering::Acquire`] በማለፍ በ `swap` ዘዴ በኩል [`atomic`] አይነቶች ላይ ይገኛል.
    /// ለምሳሌ, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// እሴቱን በተጠቀሰው ማህደረ ትውስታ ቦታ ላይ ያከማቻል ፣ የድሮውን እሴት ይመልሳል።
    ///
    /// በዚህ ነጥሎ ያለው የሚደረግልዎት ስሪት `order` እንደ [`Ordering::Release`] በማለፍ በ `swap` ዘዴ በኩል [`atomic`] አይነቶች ላይ ይገኛል.
    /// ለምሳሌ, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// እሴቱን በተጠቀሰው ማህደረ ትውስታ ቦታ ላይ ያከማቻል ፣ የድሮውን እሴት ይመልሳል።
    ///
    /// የተረጋጋ የዚህ ውስጣዊ ስሪት [`Ordering::AcqRel`] ን እንደ `order` በማለፍ በ `swap` ዘዴ በኩል በ [`atomic`] አይነቶች ላይ ይገኛል ፡፡
    /// ለምሳሌ, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// እሴቱን በተጠቀሰው ማህደረ ትውስታ ቦታ ላይ ያከማቻል ፣ የድሮውን እሴት ይመልሳል።
    ///
    /// የተረጋጋው የዚህ ውስጣዊ ስሪት [`Ordering::Relaxed`] ን እንደ `order` በማለፍ በ `swap` ዘዴ በኩል በ [`atomic`] አይነቶች ላይ ይገኛል ፡፡
    /// ለምሳሌ, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// የቀደመውን እሴት በመመለስ አሁን ባለው እሴት ላይ ይጨምራል።
    ///
    /// የተረጋጋ የዚህ ውስጣዊ ስሪት [`Ordering::SeqCst`] ን እንደ `order` በማለፍ በ `fetch_add` ዘዴ በኩል በ [`atomic`] አይነቶች ላይ ይገኛል ፡፡
    /// ለምሳሌ, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd<T: Copy>(dst: *mut T, src: T) -> T;
    /// የቀደመውን እሴት በመመለስ አሁን ባለው እሴት ላይ ይጨምራል።
    ///
    /// የተረጋጋ የዚህ ውስጣዊ ስሪት [`Ordering::Acquire`] ን እንደ `order` በማለፍ በ `fetch_add` ዘዴ በኩል በ [`atomic`] አይነቶች ላይ ይገኛል ፡፡
    /// ለምሳሌ, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// የቀደመውን እሴት በመመለስ አሁን ባለው እሴት ላይ ይጨምራል።
    ///
    /// በዚህ ነጥሎ ያለው የሚደረግልዎት ስሪት `order` እንደ [`Ordering::Release`] በማለፍ በ `fetch_add` ዘዴ በኩል [`atomic`] አይነቶች ላይ ይገኛል.
    /// ለምሳሌ, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// የቀደመውን እሴት በመመለስ አሁን ባለው እሴት ላይ ይጨምራል።
    ///
    /// በዚህ ነጥሎ ያለው የሚደረግልዎት ስሪት `order` እንደ [`Ordering::AcqRel`] በማለፍ በ `fetch_add` ዘዴ በኩል [`atomic`] አይነቶች ላይ ይገኛል.
    /// ለምሳሌ, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// የቀደመውን እሴት በመመለስ አሁን ባለው እሴት ላይ ይጨምራል።
    ///
    /// በዚህ ነጥሎ ያለው የሚደረግልዎት ስሪት `order` እንደ [`Ordering::Relaxed`] በማለፍ በ `fetch_add` ዘዴ በኩል [`atomic`] አይነቶች ላይ ይገኛል.
    /// ለምሳሌ, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// የቀደመውን እሴት በመመለስ ከአሁኑ ዋጋ መቀነስ።
    ///
    /// የተረጋጋ የዚህ ውስጣዊ ስሪት [`Ordering::SeqCst`] ን እንደ `order` በማለፍ በ `fetch_sub` ዘዴ በኩል በ [`atomic`] አይነቶች ላይ ይገኛል ፡፡
    /// ለምሳሌ, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub<T: Copy>(dst: *mut T, src: T) -> T;
    /// የቀደመውን እሴት በመመለስ ከአሁኑ ዋጋ መቀነስ።
    ///
    /// የተረጋጋ የዚህ ውስጣዊ ስሪት [`Ordering::Acquire`] ን እንደ `order` በማለፍ በ `fetch_sub` ዘዴ በኩል በ [`atomic`] አይነቶች ላይ ይገኛል ፡፡
    /// ለምሳሌ, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// የቀደመውን እሴት በመመለስ ከአሁኑ ዋጋ መቀነስ።
    ///
    /// የተረጋጋ የዚህ ውስጣዊ ስሪት [`Ordering::Release`] ን እንደ `order` በማለፍ በ `fetch_sub` ዘዴ በኩል በ [`atomic`] አይነቶች ላይ ይገኛል ፡፡
    /// ለምሳሌ, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// የቀደመውን እሴት በመመለስ ከአሁኑ ዋጋ መቀነስ።
    ///
    /// የተረጋጋ የዚህ ውስጣዊ ስሪት [`Ordering::AcqRel`] ን እንደ `order` በማለፍ በ `fetch_sub` ዘዴ በኩል በ [`atomic`] አይነቶች ላይ ይገኛል ፡፡
    /// ለምሳሌ, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// የቀደመውን እሴት በመመለስ ከአሁኑ ዋጋ መቀነስ።
    ///
    /// በዚህ ነጥሎ ያለው የሚደረግልዎት ስሪት `order` እንደ [`Ordering::Relaxed`] በማለፍ በ `fetch_sub` ዘዴ በኩል [`atomic`] አይነቶች ላይ ይገኛል.
    /// ለምሳሌ, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// የቀደመውን እሴት በመመለስ በጥቂቱ እና ከአሁኑ እሴት ጋር።
    ///
    /// የተረጋጋው የዚህ ውስጣዊ ስሪት [`Ordering::SeqCst`] ን እንደ `order` በማለፍ በ `fetch_and` ዘዴ በኩል በ [`atomic`] አይነቶች ላይ ይገኛል ፡፡
    /// ለምሳሌ, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and<T: Copy>(dst: *mut T, src: T) -> T;
    /// የቀደመውን እሴት በመመለስ በጥቂቱ እና ከአሁኑ እሴት ጋር።
    ///
    /// የተረጋጋ የዚህ ውስጣዊ ስሪት [`Ordering::Acquire`] ን እንደ `order` በማለፍ በ `fetch_and` ዘዴ በኩል በ [`atomic`] አይነቶች ላይ ይገኛል ፡፡
    /// ለምሳሌ, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// የቀደመውን እሴት በመመለስ በጥቂቱ እና ከአሁኑ እሴት ጋር።
    ///
    /// የተረጋጋ የዚህ ውስጣዊ ስሪት [`Ordering::Release`] ን እንደ `order` በማለፍ በ `fetch_and` ዘዴ በኩል በ [`atomic`] አይነቶች ላይ ይገኛል ፡፡
    /// ለምሳሌ, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// የቀደመውን እሴት በመመለስ በጥቂቱ እና ከአሁኑ እሴት ጋር።
    ///
    /// በዚህ ነጥሎ ያለው የሚደረግልዎት ስሪት `order` እንደ [`Ordering::AcqRel`] በማለፍ በ `fetch_and` ዘዴ በኩል [`atomic`] አይነቶች ላይ ይገኛል.
    /// ለምሳሌ, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// የቀደመውን እሴት በመመለስ በጥቂቱ እና ከአሁኑ እሴት ጋር።
    ///
    /// በዚህ ነጥሎ ያለው የሚደረግልዎት ስሪት `order` እንደ [`Ordering::Relaxed`] በማለፍ በ `fetch_and` ዘዴ በኩል [`atomic`] አይነቶች ላይ ይገኛል.
    /// ለምሳሌ, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// የቀደመውን እሴት በመመለስ Bitwise nand ከአሁኑ እሴት ጋር።
    ///
    /// በዚህ ነጥሎ ያለው የሚደረግልዎት ስሪት `order` እንደ [`Ordering::SeqCst`] በማለፍ በ `fetch_nand` ዘዴ በኩል [`AtomicBool`] አይነት ላይ ይገኛል.
    /// ለምሳሌ, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand<T: Copy>(dst: *mut T, src: T) -> T;
    /// የቀደመውን እሴት በመመለስ Bitwise nand ከአሁኑ እሴት ጋር።
    ///
    /// የተረጋጋ የዚህ ውስጣዊ ስሪት [`Ordering::Acquire`] ን እንደ `order` በማለፍ በ `fetch_nand` ዘዴ በኩል በ [`AtomicBool`] ዓይነት በ‹[`AtomicBool`]›አይነት ላይ ይገኛል ፡፡
    /// ለምሳሌ, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// የቀደመውን እሴት በመመለስ Bitwise nand ከአሁኑ እሴት ጋር።
    ///
    /// የተረጋጋ የዚህ ውስጣዊ ስሪት [`Ordering::Release`] ን እንደ `order` በማለፍ በ `fetch_nand` ዘዴ በኩል በ [`AtomicBool`] ዓይነት በ‹[`AtomicBool`]›አይነት ላይ ይገኛል ፡፡
    /// ለምሳሌ, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// የቀደመውን እሴት በመመለስ Bitwise nand ከአሁኑ እሴት ጋር።
    ///
    /// የተረጋጋ የዚህ ውስጣዊ ስሪት [`Ordering::AcqRel`] ን እንደ `order` በማለፍ በ `fetch_nand` ዘዴ በኩል በ [`AtomicBool`] ዓይነት በ‹[`AtomicBool`]›አይነት ላይ ይገኛል ፡፡
    /// ለምሳሌ, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// የቀደመውን እሴት በመመለስ Bitwise nand ከአሁኑ እሴት ጋር።
    ///
    /// በዚህ ነጥሎ ያለው የሚደረግልዎት ስሪት `order` እንደ [`Ordering::Relaxed`] በማለፍ በ `fetch_nand` ዘዴ በኩል [`AtomicBool`] አይነት ላይ ይገኛል.
    /// ለምሳሌ, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// የቀደመውን እሴት በመመለስ በትንሹ ወይም ከአሁኑ እሴት ጋር።
    ///
    /// የተረጋጋው የዚህ ውስጣዊ ስሪት [`Ordering::SeqCst`] ን እንደ `order` በማለፍ በ `fetch_or` ዘዴ በኩል በ [`atomic`] አይነቶች ላይ ይገኛል ፡፡
    /// ለምሳሌ, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or<T: Copy>(dst: *mut T, src: T) -> T;
    /// የቀደመውን እሴት በመመለስ በትንሹ ወይም ከአሁኑ እሴት ጋር።
    ///
    /// የተረጋጋ የዚህ ውስጣዊ ስሪት [`Ordering::Acquire`] ን እንደ `order` በማለፍ በ `fetch_or` ዘዴ በኩል በ [`atomic`] አይነቶች ላይ ይገኛል ፡፡
    /// ለምሳሌ, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// የቀደመውን እሴት በመመለስ በትንሹ ወይም ከአሁኑ እሴት ጋር።
    ///
    /// የተረጋጋ የዚህ ውስጣዊ ስሪት [`Ordering::Release`] ን እንደ `order` በማለፍ በ `fetch_or` ዘዴ በኩል በ [`atomic`] አይነቶች ላይ ይገኛል ፡፡
    /// ለምሳሌ, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// የቀደመውን እሴት በመመለስ በትንሹ ወይም ከአሁኑ እሴት ጋር።
    ///
    /// በዚህ ነጥሎ ያለው የሚደረግልዎት ስሪት `order` እንደ [`Ordering::AcqRel`] በማለፍ በ `fetch_or` ዘዴ በኩል [`atomic`] አይነቶች ላይ ይገኛል.
    /// ለምሳሌ, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// የቀደመውን እሴት በመመለስ በትንሹ ወይም ከአሁኑ እሴት ጋር።
    ///
    /// በዚህ ነጥሎ ያለው የሚደረግልዎት ስሪት `order` እንደ [`Ordering::Relaxed`] በማለፍ በ `fetch_or` ዘዴ በኩል [`atomic`] አይነቶች ላይ ይገኛል.
    /// ለምሳሌ, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// የቀደመውን እሴት በመመለስ ከአሁኑ እሴት ጋር ቢትዋርዝ xor።
    ///
    /// የተረጋጋ የዚህ ውስጣዊ ስሪት [`Ordering::SeqCst`] ን እንደ `order` በማለፍ በ `fetch_xor` ዘዴ በኩል በ [`atomic`] አይነቶች ላይ ይገኛል ፡፡
    /// ለምሳሌ, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor<T: Copy>(dst: *mut T, src: T) -> T;
    /// የቀደመውን እሴት በመመለስ ከአሁኑ እሴት ጋር ቢትዋርዝ xor።
    ///
    /// በዚህ ነጥሎ ያለው የሚደረግልዎት ስሪት `order` እንደ [`Ordering::Acquire`] በማለፍ በ `fetch_xor` ዘዴ በኩል [`atomic`] አይነቶች ላይ ይገኛል.
    /// ለምሳሌ, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// የቀደመውን እሴት በመመለስ ከአሁኑ እሴት ጋር ቢትዋርዝ xor።
    ///
    /// የተረጋጋ የዚህ ውስጣዊ ስሪት [`Ordering::Release`] ን እንደ `order` በማለፍ በ `fetch_xor` ዘዴ በኩል በ [`atomic`] አይነቶች ላይ ይገኛል ፡፡
    /// ለምሳሌ, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// የቀደመውን እሴት በመመለስ ከአሁኑ እሴት ጋር ቢትዋርዝ xor።
    ///
    /// በዚህ ነጥሎ ያለው የሚደረግልዎት ስሪት `order` እንደ [`Ordering::AcqRel`] በማለፍ በ `fetch_xor` ዘዴ በኩል [`atomic`] አይነቶች ላይ ይገኛል.
    /// ለምሳሌ, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// የቀደመውን እሴት በመመለስ ከአሁኑ እሴት ጋር ቢትዋርዝ xor።
    ///
    /// የተረጋጋ የዚህ ውስጣዊ ስሪት [`Ordering::Relaxed`] ን እንደ `order` በማለፍ በ `fetch_xor` ዘዴ በኩል በ [`atomic`] አይነቶች ላይ ይገኛል ፡፡
    /// ለምሳሌ, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// የተፈረመ ንፅፅርን በመጠቀም ከአሁኑ ዋጋ ጋር ከፍተኛው ፡፡
    ///
    /// በዚህ ነጥሎ ያለው የሚደረግልዎት ስሪት [`atomic`] ወደ `order` እንደ [`Ordering::SeqCst`] በማለፍ በ `fetch_max` ስልት በኩል አይነቶች ኢንቲጀር የተፈረመ ላይ ይገኛል.
    /// ለምሳሌ, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max<T: Copy>(dst: *mut T, src: T) -> T;
    /// የተፈረመ ንፅፅርን በመጠቀም ከአሁኑ ዋጋ ጋር ከፍተኛው ፡፡
    ///
    /// በዚህ ነጥሎ ያለው የሚደረግልዎት ስሪት [`atomic`] ወደ `order` እንደ [`Ordering::Acquire`] በማለፍ በ `fetch_max` ስልት በኩል አይነቶች ኢንቲጀር የተፈረመ ላይ ይገኛል.
    /// ለምሳሌ, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// የተፈረመ ንፅፅርን በመጠቀም ከአሁኑ ዋጋ ጋር ከፍተኛው ፡፡
    ///
    /// በዚህ ነጥሎ ያለው የሚደረግልዎት ስሪት [`atomic`] ወደ `order` እንደ [`Ordering::Release`] በማለፍ በ `fetch_max` ስልት በኩል አይነቶች ኢንቲጀር የተፈረመ ላይ ይገኛል.
    /// ለምሳሌ, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// የተፈረመ ንፅፅርን በመጠቀም ከአሁኑ ዋጋ ጋር ከፍተኛው ፡፡
    ///
    /// የተረጋጋው የዚህ ውስጣዊ ስሪት [`Ordering::AcqRel`] ን እንደ `order` በማለፍ በ `fetch_max` ዘዴ በኩል በ [`atomic`] የተፈረሙ ቁጥር ቁጥሮች ላይ ይገኛል ፡፡
    /// ለምሳሌ, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// ከአሁኑ እሴት ጋር ከፍተኛው ፡፡
    ///
    /// በዚህ ነጥሎ ያለው የሚደረግልዎት ስሪት [`atomic`] ወደ `order` እንደ [`Ordering::Relaxed`] በማለፍ በ `fetch_max` ስልት በኩል አይነቶች ኢንቲጀር የተፈረመ ላይ ይገኛል.
    /// ለምሳሌ, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// የተፈረመበትን ንጽጽር በመጠቀም የአሁኑ ዋጋ ጋር ዝቅተኛው.
    ///
    /// የተረጋጋው የዚህ ውስጣዊ ስሪት [`Ordering::SeqCst`] ን እንደ `order` በማለፍ በ `fetch_min` ዘዴ በኩል በ [`atomic`] የተፈረሙ ቁጥር ቁጥሮች ላይ ይገኛል ፡፡
    /// ለምሳሌ, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min<T: Copy>(dst: *mut T, src: T) -> T;
    /// የተፈረመበትን ንጽጽር በመጠቀም የአሁኑ ዋጋ ጋር ዝቅተኛው.
    ///
    /// የተረጋጋው የዚህ ውስጣዊ ስሪት [`Ordering::Acquire`] ን እንደ `order` በማለፍ በ `fetch_min` ዘዴ በኩል በ [`atomic`] የተፈረሙ ቁጥር ቁጥሮች ላይ ይገኛል ፡፡
    /// ለምሳሌ, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// የተፈረመበትን ንጽጽር በመጠቀም የአሁኑ ዋጋ ጋር ዝቅተኛው.
    ///
    /// የተረጋጋው የዚህ ውስጣዊ ስሪት [`Ordering::Release`] ን እንደ `order` በማለፍ በ `fetch_min` ዘዴ በኩል በ [`atomic`] የተፈረሙ ቁጥር ቁጥሮች ላይ ይገኛል ፡፡
    /// ለምሳሌ, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// የተፈረመበትን ንጽጽር በመጠቀም የአሁኑ ዋጋ ጋር ዝቅተኛው.
    ///
    /// የተረጋጋው የዚህ ውስጣዊ ስሪት [`Ordering::AcqRel`] ን እንደ `order` በማለፍ በ `fetch_min` ዘዴ በኩል በ [`atomic`] የተፈረሙ ቁጥር ቁጥሮች ላይ ይገኛል ፡፡
    /// ለምሳሌ, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// የተፈረመበትን ንጽጽር በመጠቀም የአሁኑ ዋጋ ጋር ዝቅተኛው.
    ///
    /// በዚህ ነጥሎ ያለው የሚደረግልዎት ስሪት [`atomic`] ወደ `order` እንደ [`Ordering::Relaxed`] በማለፍ በ `fetch_min` ስልት በኩል አይነቶች ኢንቲጀር የተፈረመ ላይ ይገኛል.
    /// ለምሳሌ, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// ያልተፈረመበት ንጽጽር በመጠቀም የአሁኑ ዋጋ ጋር ዝቅተኛው.
    ///
    /// በዚህ ነጥሎ ያለው የሚደረግልዎት ስሪት `order` እንደ [`Ordering::SeqCst`] በማለፍ በ `fetch_min` ዘዴ በኩል [`atomic`] ያልፈረመ ኢንቲጀር አይነቶች ላይ ይገኛል.
    /// ለምሳሌ, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin<T: Copy>(dst: *mut T, src: T) -> T;
    /// ያልተፈረመበት ንጽጽር በመጠቀም የአሁኑ ዋጋ ጋር ዝቅተኛው.
    ///
    /// የተረጋጋው የዚህ ውስጣዊ ስሪት [`Ordering::Acquire`] ን እንደ `order` በማለፍ በ `fetch_min` ዘዴ በኩል በ [`atomic`] ባልተመዘገቡ የኢቲጀር ዓይነቶች ላይ ይገኛል ፡፡
    /// ለምሳሌ, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// ያልተፈረመበት ንጽጽር በመጠቀም የአሁኑ ዋጋ ጋር ዝቅተኛው.
    ///
    /// የተረጋጋው የዚህ ውስጣዊ ስሪት [`Ordering::Release`] ን እንደ `order` በማለፍ በ `fetch_min` ዘዴ በኩል በ [`atomic`] ባልተመዘገቡ የኢቲጀር ዓይነቶች ላይ ይገኛል ፡፡
    /// ለምሳሌ, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// ያልተፈረመበት ንጽጽር በመጠቀም የአሁኑ ዋጋ ጋር ዝቅተኛው.
    ///
    /// የተረጋጋው የዚህ ውስጣዊ ስሪት [`Ordering::AcqRel`] ን እንደ `order` በማለፍ በ `fetch_min` ዘዴ በኩል በ [`atomic`] ባልተመዘገቡ የኢቲጀር ዓይነቶች ላይ ይገኛል ፡፡
    /// ለምሳሌ, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// ያልተፈረመበት ንጽጽር በመጠቀም የአሁኑ ዋጋ ጋር ዝቅተኛው.
    ///
    /// የተረጋጋው የዚህ ውስጣዊ ስሪት [`Ordering::Relaxed`] ን እንደ `order` በማለፍ በ `fetch_min` ዘዴ በኩል በ [`atomic`] ባልተመዘገቡ የኢቲጀር ዓይነቶች ላይ ይገኛል ፡፡
    /// ለምሳሌ, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// ያልተፈረመ ንፅፅርን በመጠቀም ከአሁኑ ዋጋ ጋር ከፍተኛው ፡፡
    ///
    /// የተረጋጋው የዚህ ውስጣዊ ስሪት [`Ordering::SeqCst`] ን እንደ `order` በማለፍ በ `fetch_max` ዘዴ በኩል በ [`atomic`] ባልተመዘገቡ የኢቲጀር ዓይነቶች ላይ ይገኛል ፡፡
    /// ለምሳሌ, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax<T: Copy>(dst: *mut T, src: T) -> T;
    /// ያልተፈረመ ንፅፅርን በመጠቀም ከአሁኑ ዋጋ ጋር ከፍተኛው ፡፡
    ///
    /// የተረጋጋው የዚህ ውስጣዊ ስሪት [`Ordering::Acquire`] ን እንደ `order` በማለፍ በ `fetch_max` ዘዴ በኩል በ [`atomic`] ባልተመዘገቡ የኢቲጀር ዓይነቶች ላይ ይገኛል ፡፡
    /// ለምሳሌ, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// ያልተፈረመ ንፅፅርን በመጠቀም ከአሁኑ ዋጋ ጋር ከፍተኛው ፡፡
    ///
    /// የተረጋጋው የዚህ ውስጣዊ ስሪት [`Ordering::Release`] ን እንደ `order` በማለፍ በ `fetch_max` ዘዴ በኩል በ [`atomic`] ባልተፈረመባቸው የኢቲጀር ዓይነቶች ላይ ይገኛል ፡፡
    /// ለምሳሌ, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// ያልተፈረመ ንፅፅርን በመጠቀም ከአሁኑ ዋጋ ጋር ከፍተኛው ፡፡
    ///
    /// በዚህ ነጥሎ ያለው የሚደረግልዎት ስሪት `order` እንደ [`Ordering::AcqRel`] በማለፍ በ `fetch_max` ዘዴ በኩል [`atomic`] ያልፈረመ ኢንቲጀር አይነቶች ላይ ይገኛል.
    /// ለምሳሌ, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// ያልተፈረመ ንፅፅርን በመጠቀም ከአሁኑ ዋጋ ጋር ከፍተኛው ፡፡
    ///
    /// የተረጋጋው የዚህ ውስጣዊ ስሪት [`Ordering::Relaxed`] ን እንደ `order` በማለፍ በ `fetch_max` ዘዴ በኩል በ [`atomic`] ባልተመዘገቡ የኢቲጀር ዓይነቶች ላይ ይገኛል ፡፡
    /// ለምሳሌ, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// የ `prefetch` ውስጣዊ ይዘት ከተደገፈ የቅድመ ዝግጅት መመሪያን ለማስገባት ለኮድ አመንጪው ፍንጭ ነው ፤አለበለዚያ, no-op ነው.
    /// ቅድመ-ቅጦች በፕሮግራሙ ባህሪ ላይ ምንም ተጽዕኖ የላቸውም ነገር ግን የአፈፃፀም ባህሪያቱን መለወጥ ይችላሉ ፡፡
    ///
    /// የ `locality` ክርክር የማያቋርጥ ኢንቲጀር መሆን አለበት እና ከ (0) ፣ ምንም አከባቢ ፣ እስከ (3) ፣ እጅግ በጣም አካባቢያዊ በመሸጎጫ ውስጥ የሚገኝ ጊዜያዊ የአካባቢ መለያ ነው።
    ///
    ///
    /// ይህ ነጥሎ የተረጋጋ አቻ የለውም.
    ///
    ///
    pub fn prefetch_read_data<T>(data: *const T, locality: i32);
    /// የ `prefetch` ውስጣዊ ይዘት ከተደገፈ የቅድመ ዝግጅት መመሪያን ለማስገባት ለኮድ አመንጪው ፍንጭ ነው ፤አለበለዚያ, no-op ነው.
    /// ቅድመ-ቅጦች በፕሮግራሙ ባህሪ ላይ ምንም ተጽዕኖ የላቸውም ነገር ግን የአፈፃፀም ባህሪያቱን መለወጥ ይችላሉ ፡፡
    ///
    /// የ `locality` ክርክር የማያቋርጥ ኢንቲጀር መሆን አለበት እና ከ (0) ፣ ምንም አከባቢ ፣ እስከ (3) ፣ እጅግ በጣም አካባቢያዊ በመሸጎጫ ውስጥ የሚገኝ ጊዜያዊ የአካባቢ መለያ ነው።
    ///
    ///
    /// ይህ ነጥሎ የተረጋጋ አቻ የለውም.
    ///
    ///
    pub fn prefetch_write_data<T>(data: *const T, locality: i32);
    /// የ `prefetch` ውስጣዊ ይዘት ከተደገፈ የቅድመ ዝግጅት መመሪያን ለማስገባት ለኮድ አመንጪው ፍንጭ ነው ፤አለበለዚያ, no-op ነው.
    /// ቅድመ-ቅጦች በፕሮግራሙ ባህሪ ላይ ምንም ተጽዕኖ የላቸውም ነገር ግን የአፈፃፀም ባህሪያቱን መለወጥ ይችላሉ ፡፡
    ///
    /// የ `locality` ክርክር የማያቋርጥ ኢንቲጀር መሆን አለበት እና ከ (0) ፣ ምንም አከባቢ ፣ እስከ (3) ፣ እጅግ በጣም አካባቢያዊ በመሸጎጫ ውስጥ የሚገኝ ጊዜያዊ የአካባቢ መለያ ነው።
    ///
    ///
    /// ይህ ነጥሎ የተረጋጋ አቻ የለውም.
    ///
    ///
    pub fn prefetch_read_instruction<T>(data: *const T, locality: i32);
    /// የ `prefetch` ውስጣዊ ይዘት ከተደገፈ የቅድመ ዝግጅት መመሪያን ለማስገባት ለኮድ አመንጪው ፍንጭ ነው ፤አለበለዚያ, no-op ነው.
    /// ቅድመ-ቅጦች በፕሮግራሙ ባህሪ ላይ ምንም ተጽዕኖ የላቸውም ነገር ግን የአፈፃፀም ባህሪያቱን መለወጥ ይችላሉ ፡፡
    ///
    /// የ `locality` ክርክር የማያቋርጥ ኢንቲጀር መሆን አለበት እና ከ (0) ፣ ምንም አከባቢ ፣ እስከ (3) ፣ እጅግ በጣም አካባቢያዊ በመሸጎጫ ውስጥ የሚገኝ ጊዜያዊ የአካባቢ መለያ ነው።
    ///
    ///
    /// ይህ ነጥሎ የተረጋጋ አቻ የለውም.
    ///
    ///
    pub fn prefetch_write_instruction<T>(data: *const T, locality: i32);
}

extern "rust-intrinsic" {
    /// አቶሚክ አጥር ፡፡
    ///
    /// በዚህ ነጥሎ ያለው የሚደረግልዎት ስሪት `order` እንደ [`Ordering::SeqCst`] በማለፍ በማድረግ [`atomic::fence`] ውስጥ ይገኛል.
    ///
    ///
    pub fn atomic_fence();
    /// አቶሚክ አጥር ፡፡
    ///
    /// በዚህ ነጥሎ ያለው የሚደረግልዎት ስሪት `order` እንደ [`Ordering::Acquire`] በማለፍ በማድረግ [`atomic::fence`] ውስጥ ይገኛል.
    ///
    ///
    pub fn atomic_fence_acq();
    /// አቶሚክ አጥር ፡፡
    ///
    /// በዚህ ነጥሎ ያለው የሚደረግልዎት ስሪት `order` እንደ [`Ordering::Release`] በማለፍ በማድረግ [`atomic::fence`] ውስጥ ይገኛል.
    ///
    ///
    pub fn atomic_fence_rel();
    /// አቶሚክ አጥር ፡፡
    ///
    /// በዚህ ነጥሎ ያለው የሚደረግልዎት ስሪት `order` እንደ [`Ordering::AcqRel`] በማለፍ በማድረግ [`atomic::fence`] ውስጥ ይገኛል.
    ///
    ///
    pub fn atomic_fence_acqrel();

    /// አንድ አጠናቃሪ-ብቻ የማስታወሻ መሰናክል።
    ///
    /// ትውስታ የመጠቀሚያ ጊዜ በ አጠናቃሪ ይህን አጥር በመላ reordered ፈጽሞ, ነገር ግን ምንም መመሪያዎች ይህን ያህል ከመነጋገሩ ይሆናል.
    /// ይህም እንደ ምልክት ተቆጣጣሪዎች ጋር መስተጋብር ጊዜ እንደ ያዘ ይችላል ተመሳሳይ ክር ላይ ቀዶ ተገቢ ነው.
    ///
    /// የተረጋጋው የዚህ ውስጣዊ ስሪት [`Ordering::SeqCst`] ን እንደ `order` በማለፍ በ [`atomic::compiler_fence`] ውስጥ ይገኛል።
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence();
    /// አንድ አጠናቃሪ-ብቻ የማስታወሻ መሰናክል።
    ///
    /// ትውስታ የመጠቀሚያ ጊዜ በ አጠናቃሪ ይህን አጥር በመላ reordered ፈጽሞ, ነገር ግን ምንም መመሪያዎች ይህን ያህል ከመነጋገሩ ይሆናል.
    /// ይህም እንደ ምልክት ተቆጣጣሪዎች ጋር መስተጋብር ጊዜ እንደ ያዘ ይችላል ተመሳሳይ ክር ላይ ቀዶ ተገቢ ነው.
    ///
    /// በዚህ ነጥሎ ያለው የሚደረግልዎት ስሪት `order` እንደ [`Ordering::Acquire`] በማለፍ በማድረግ [`atomic::compiler_fence`] ውስጥ ይገኛል.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acq();
    /// አንድ አጠናቃሪ-ብቻ የማስታወሻ መሰናክል።
    ///
    /// ትውስታ የመጠቀሚያ ጊዜ በ አጠናቃሪ ይህን አጥር በመላ reordered ፈጽሞ, ነገር ግን ምንም መመሪያዎች ይህን ያህል ከመነጋገሩ ይሆናል.
    /// ይህም እንደ ምልክት ተቆጣጣሪዎች ጋር መስተጋብር ጊዜ እንደ ያዘ ይችላል ተመሳሳይ ክር ላይ ቀዶ ተገቢ ነው.
    ///
    /// የተረጋጋው የዚህ ውስጣዊ ስሪት [`Ordering::Release`] ን እንደ `order` በማለፍ በ [`atomic::compiler_fence`] ውስጥ ይገኛል።
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_rel();
    /// አንድ አጠናቃሪ-ብቻ የማስታወሻ መሰናክል።
    ///
    /// ትውስታ የመጠቀሚያ ጊዜ በ አጠናቃሪ ይህን አጥር በመላ reordered ፈጽሞ, ነገር ግን ምንም መመሪያዎች ይህን ያህል ከመነጋገሩ ይሆናል.
    /// ይህም እንደ ምልክት ተቆጣጣሪዎች ጋር መስተጋብር ጊዜ እንደ ያዘ ይችላል ተመሳሳይ ክር ላይ ቀዶ ተገቢ ነው.
    ///
    /// በዚህ ነጥሎ ያለው የሚደረግልዎት ስሪት `order` እንደ [`Ordering::AcqRel`] በማለፍ በማድረግ [`atomic::compiler_fence`] ውስጥ ይገኛል.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acqrel();

    /// ወደ ተግባር ጋር የተያያዙ ባህርያት ከ ትርጉም የሚያገኝ መሆኑን ድግምት መግለጫም.
    ///
    /// ለምሳሌ ያህል, dataflow አጠቃቀሞች ይህ `rustc_peek(potentially_uninitialized)` በትክክል ድርብ-ቼክ dataflow በእርግጥ ይህ ቁጥጥር ፍሰት ውስጥ በዚያ ነጥብ ላይ uninitialized መሆኑን ለማስላት ነበር ነበር ዘንድ እንደሆነ የማይንቀሳቀሱ ከተናገሯቸው በመርፌ ነው.
    ///
    ///
    /// ይህ ውስጣዊ ይዘት ከአቀራባዩ ውጭ ጥቅም ላይ መዋል የለበትም ፡፡
    ///
    ///
    ///
    pub fn rustc_peek<T>(_: T) -> T;

    /// ሂደቱ እንደተገደለ ቢያስወርዱ.
    ///
    /// ይህ ክወና አንድ ተጨማሪ ለተጠቃሚ ምቹ እና የተረጋጋ ስሪት [`std::process::abort`](../../std/process/fn.abort.html) ነው.
    ///
    pub fn abort() -> !;

    /// ኮዱን ውስጥ ይህን ነጥብ ተጨማሪ ማሳደጊያዎች በማንቃት, ሊደረስበት አይችልም መሆኑን አመቻች ያሳውቃል.
    ///
    /// ማሳሰቢያ: ይህ `unreachable!()` ማክሮ በጣም የተለየ ነው; panics ሲፈጸም ያለውን ማክሮ, በተለየ መልኩ *ይህን ተግባር ጋር ምልክት ኮድ ለማድረስ* ያልተገለጸ ባህሪ ነው.
    ///
    ///
    /// የዚህ ውስጣዊ ይዘት የተረጋጋ ስሪት [`core::hint::unreachable_unchecked`](crate::hint::unreachable_unchecked) ነው።
    ///
    ///
    #[rustc_const_unstable(feature = "const_unreachable_unchecked", issue = "53188")]
    pub fn unreachable() -> !;

    /// ሁኔታ ምንጊዜም እውነት መሆኑን አመቻች ያሳውቃል.
    /// ሁኔታው ሐሰት ከሆነ ባህሪው አልተገለጸም ፡፡
    ///
    /// ምንም ኮድ ለዚህ ነጥሎ ለ የመነጨ ነው, ነገር ግን አመቻች ኮድ ዙሪያ መካከል ማመቻቸት ጣልቃ እና አፈጻጸም ሊቀንስ ይችላል passes መካከል ነው (እና ሁኔታ) ጠብቆ ይሞክራል.
    /// የማይለዋወጥ በራሱ በአመቻቹ ሊገኝ ከቻለ ወይም ምንም ጉልህ ማበረታቻዎችን ካላነቃ ጥቅም ላይ መዋል የለበትም ፡፡
    ///
    /// ይህ ነጥሎ የተረጋጋ አቻ የለውም.
    ///
    ///
    ///
    #[rustc_const_unstable(feature = "const_assume", issue = "76972")]
    pub fn assume(b: bool);

    /// የ branch ሁኔታ እውነት ሊሆን እንደሚችል ለአቀናባሪው ጥቆማዎች ፡፡
    /// ይህም ወደ አለፈ እሴት ያወጣል.
    ///
    /// `if` መግለጫዎችን ጋር ሌላ ማንኛውም አጠቃቀም ምናልባት ተጽዕኖ አይኖረውም.
    ///
    /// ይህ ነጥሎ የተረጋጋ አቻ የለውም.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn likely(b: bool) -> bool;

    /// branch ሁኔታ ሐሰት መሆን አይቀርም መሆኑን አጠናቃሪ ወደ ፍንጮች.
    /// ይህም ወደ አለፈ እሴት ያወጣል.
    ///
    /// `if` መግለጫዎችን ጋር ሌላ ማንኛውም አጠቃቀም ምናልባት ተጽዕኖ አይኖረውም.
    ///
    /// ይህ ነጥሎ የተረጋጋ አቻ የለውም.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn unlikely(b: bool) -> bool;

    /// በአረም ማረሚያ ፍተሻ የእረፍት ነጥብ ወጥመድ ያስፈጽማል።
    ///
    /// ይህ ነጥሎ የተረጋጋ አቻ የለውም.
    pub fn breakpoint();

    /// በባይት ውስጥ የአንድ ዓይነት መጠን።
    ///
    /// ይበልጥ ግልጽ በሆነ ሁኔታ ፣ ይህ የማመሳሰል ንጣፎችን ጨምሮ ፣ በተመሳሳይ ተመሳሳይ ዓይነቶች መካከል ባይት ውስጥ ማካካሻ ነው።
    ///
    ///
    /// በዚህ ነጥሎ ያለው የሚደረግልዎት ስሪት [`core::mem::size_of`](crate::mem::size_of) ነው.
    #[rustc_const_stable(feature = "const_size_of", since = "1.40.0")]
    pub fn size_of<T>() -> usize;

    /// አንድ አይነት ዝቅተኛ አሰላለፍ.
    ///
    /// በዚህ ነጥሎ ያለው የሚደረግልዎት ስሪት [`core::mem::align_of`](crate::mem::align_of) ነው.
    #[rustc_const_stable(feature = "const_min_align_of", since = "1.40.0")]
    pub fn min_align_of<T>() -> usize;
    /// አንድ አይነት ተመራጭ አሰላለፍ.
    ///
    /// ይህ ነጥሎ የተረጋጋ አቻ የለውም.
    #[rustc_const_unstable(feature = "const_pref_align_of", issue = "none")]
    pub fn pref_align_of<T>() -> usize;

    /// ባይት ውስጥ የተጠቀሰው ዋጋ መጠን.
    ///
    /// የዚህ ውስጣዊ ይዘት የተረጋጋ ስሪት [`mem::size_of_val`] ነው።
    #[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
    pub fn size_of_val<T: ?Sized>(_: *const T) -> usize;
    /// የተጠቀሰው እሴት የሚፈለገው አሰላለፍ.
    ///
    /// የዚህ ውስጣዊ ይዘት የተረጋጋ ስሪት [`core::mem::align_of_val`](crate::mem::align_of_val) ነው።
    #[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
    pub fn min_align_of_val<T: ?Sized>(_: *const T) -> usize;

    /// የአንድ ዓይነት ስም የያዘ የማይንቀሳቀስ ገመድ ቁርጥራጭ ያገኛል።
    ///
    /// የዚህ ውስጣዊ ይዘት የተረጋጋ ስሪት [`core::any::type_name`](crate::any::type_name) ነው።
    #[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
    pub fn type_name<T: ?Sized>() -> &'static str;

    /// ለተጠቀሰው ዓይነት በዓለም አቀፍ ደረጃ ልዩ የሆነ መታወቂያ ያገኛል።
    /// ይህ ተግባር በየትኛውም crate በውስጡ የምታሰበው ነው የትኛውም አንድ አይነት ተመሳሳይ እሴት ይመለሳል.
    ///
    ///
    /// በዚህ ነጥሎ ያለው የሚደረግልዎት ስሪት [`core::any::TypeId::of`](crate::any::TypeId::of) ነው.
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub fn type_id<T: ?Sized + 'static>() -> u64;

    /// `T` የማይኖርበት ከሆነ በጭራሽ ሊገደሉ የማይችሉ ደህንነታቸው ለተጠበቁ ተግባራት ጠባቂ።
    /// ይህ በማይለወጥ ወይም panic ፈቃድ, ወይም ምንም ነገር ማድረግ.
    ///
    /// ይህ ነጥሎ የተረጋጋ አቻ የለውም.
    #[rustc_const_unstable(feature = "const_assert_type", issue = "none")]
    pub fn assert_inhabited<T>();

    /// `T` ዜሮ-ማስጀመር አይፈቅድም ከሆነ ከመቼውም አይፈጸሙም የሚችሉ አደገኛ ተግባራት አንድ ዘበኛ: ይህ ፈቃድ በማይለወጥ ወይ panic, ወይም ምንም ነገር ማድረግ.
    ///
    ///
    /// ይህ ነጥሎ የተረጋጋ አቻ የለውም.
    pub fn assert_zero_valid<T>();

    /// `T` ልክ ያልሆኑ ቢት ቅጦች ካሉት በጭራሽ ሊከናወኑ የማይችሉ ደህንነታቸው ለተጠበቁ ተግባራት ጠባቂ/ዘጋቢ-ይህ በቁጥር panic ይሆናል ፣ ወይም ምንም አያደርግም።
    ///
    ///
    /// ይህ ነጥሎ የተረጋጋ አቻ የለውም.
    pub fn assert_uninit_valid<T>();

    /// ይህ ተብሎ ነበር የት የሚያመለክት የማይንቀሳቀስ `Location` ማጣቀሻ ያገኛል.
    ///
    /// ይልቁንስ [`core::panic::Location::caller`](crate::panic::Location::caller) በመጠቀም ያስቡበት.
    #[rustc_const_unstable(feature = "const_caller_location", issue = "76156")]
    pub fn caller_location() -> &'static crate::panic::Location<'static>;

    /// ጠብታ ሙጫ ሳያስኬድ ከወደፊቱ እሴት ያወጣል።
    ///
    /// ይህ [`mem::forget_unsized`] በብቸኝነት አለ;መደበኛ `forget` በምትኩ `ManuallyDrop` ን ይጠቀማል።
    ///
    #[rustc_const_unstable(feature = "const_intrinsic_forget", issue = "none")]
    pub fn forget<T: ?Sized>(_: T);

    /// የአንድ ዓይነት ዋጋ ያላቸውን ቁርጥራጮች እንደ ሌላ ዓይነት ይተረጎማል ፡፡
    ///
    /// ሁለቱም ዓይነቶች ተመሳሳይ መጠን ሊኖራቸው ይገባል ፡፡
    /// ሴሰኞች የመጀመሪያው, ወይም ውጤት, አንድ [invalid value](../../nomicon/what-unsafe-does.html) ሊሆን ይችላል.
    ///
    /// `transmute` ወደ ሌላ አንድ አይነት bitwise ውሰድ አቀነባበርና አቻ ነው.ይህም ቅጂዎች የመድረሻ ዋጋ ወደ ምንጭ ዋጋ ከ ቢት, ከዚያም የመጀመሪያውን አይረሳም.
    /// ልክ እንደ `transmute_copy` በመከለያው ስር ከ C's `memcpy` ጋር እኩል ነው።
    ///
    /// `transmute` አንድ በ-እሴት ክወና እንደመሆኑ,*transmuted እሴቶች አሰላለፍ ራሳቸውን* አሳሳቢ አይደለም.
    /// ማንኛውም ተግባር ጋር እንደ አጠናቃሪ አስቀድሞ `T` እና `U` ሁለቱም በአግባቡ ተቀናጅተዋል ያረጋግጣል.
    /// (እንደ ዘዴውን, ማጣቀሻዎች, ሳጥኖች እንደ ...) መሆኑን *ነጥብ በሌሎች* እሴቶች transmuting ጊዜ ይሁን, የደዋዩን ወደ ጫፍ-ወደ እሴቶች በአግባቡ አሰላለፍ ማረጋገጥ አለበት.
    ///
    /// `transmute` **በማይታመን ሁኔታ** ደህንነቱ የተጠበቀ ነው።በዚህ ተግባር [undefined behavior][ub] ን የሚያስከትሉ በጣም ብዙ መንገዶች አሉ ፡፡`transmute` ፍጹም የመጨረሻ አማራጭ መሆን አለበት ፡፡
    ///
    /// የ [nomicon](../../nomicon/transmutes.html) ተጨማሪ ሰነዶችን አለው.
    ///
    /// [ub]: ../../reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// `transmute` ለማግኘት በጣም ጠቃሚ ነው ጥቂት ነገሮች አሉ.
    ///
    /// አንድ ተግባር ጠቋሚ ወደ አንድ ጠቋሚ በማጥፋት.የተግባር ጠቋሚዎች እና የመረጃ ጠቋሚዎች የተለያዩ መጠኖች ላሏቸው ማሽኖች ይህ *ተንቀሳቃሽ* አይደለም።
    ///
    /// ```
    /// fn foo() -> i32 {
    ///     0
    /// }
    /// let pointer = foo as *const ();
    /// let function = unsafe {
    ///     std::mem::transmute::<*const (), fn() -> i32>(pointer)
    /// };
    /// assert_eq!(function(), 0);
    /// ```
    ///
    /// ዕድሜ ልክ በማስቀጠል, ወይም invariant የህይወት ዘመን በአጭሩ.ይህ የላቀ ፣ በጣም ደህንነቱ ያልተጠበቀ Rust ነው!
    ///
    /// ```
    /// struct R<'a>(&'a i32);
    /// unsafe fn extend_lifetime<'b>(r: R<'b>) -> R<'static> {
    ///     std::mem::transmute::<R<'b>, R<'static>>(r)
    /// }
    ///
    /// unsafe fn shorten_invariant_lifetime<'b, 'c>(r: &'b mut R<'static>)
    ///                                              -> &'b mut R<'c> {
    ///     std::mem::transmute::<&'b mut R<'static>, &'b mut R<'c>>(r)
    /// }
    /// ```
    ///
    /// # Alternatives
    ///
    /// ማድረግ ተስፋ አትቁረጥ; `transmute` በርካታ ጥቅሞች በሌላ መንገድ በኩል ማሳካት ይቻላል.
    /// ከዚህ በታች ደህንነቱ የተጠበቀ constructs ሊተካ ይችላል ይህም `transmute` የተለመዱ መተግበሪያዎች ናቸው.
    ///
    /// ጥሬ bytes(`&[u8]`) ን ወደ `u32` ፣ `f64` ፣ ወዘተ በማዞር ላይ
    ///
    /// ```
    /// let raw_bytes = [0x78, 0x56, 0x34, 0x12];
    ///
    /// let num = unsafe {
    ///     std::mem::transmute::<[u8; 4], u32>(raw_bytes)
    /// };
    ///
    /// // አጠቃቀም `u32::from_ne_bytes` በምትኩ
    /// let num = u32::from_ne_bytes(raw_bytes);
    /// // መጠኑን ለመለየት `u32::from_le_bytes` ወይም `u32::from_be_bytes` ን ይጠቀሙ
    /// let num = u32::from_le_bytes(raw_bytes);
    /// assert_eq!(num, 0x12345678);
    /// let num = u32::from_be_bytes(raw_bytes);
    /// assert_eq!(num, 0x78563412);
    /// ```
    ///
    /// አንድ `usize` ወደ አንድ ጠቋሚ በማጥፋት:
    ///
    /// ```
    /// let ptr = &0;
    /// let ptr_num_transmute = unsafe {
    ///     std::mem::transmute::<&i32, usize>(ptr)
    /// };
    ///
    /// // በምትኩ `as` Cast ይጠቀሙ
    /// let ptr_num_cast = ptr as *const i32 as usize;
    /// ```
    ///
    /// አንድ `&mut T` ወደ አንድ `*mut T` በማብራት:
    ///
    /// ```
    /// let ptr: *mut i32 = &mut 0;
    /// let ref_transmuted = unsafe {
    ///     std::mem::transmute::<*mut i32, &mut i32>(ptr)
    /// };
    ///
    /// // በምትኩ እንደገና መተላለፊያ ይጠቀሙ
    /// let ref_casted = unsafe { &mut *ptr };
    /// ```
    ///
    /// `&mut T` ን ወደ `&mut U` መለወጥ
    ///
    /// ```
    /// let ptr = &mut 0;
    /// let val_transmuted = unsafe {
    ///     std::mem::transmute::<&mut i32, &mut u32>(ptr)
    /// };
    ///
    /// // አሁን ፣ `as` ን እንደገና ማሰባሰብ እና እንደገና ማዋቀር ፣ የ `as` `as` ሰንሰለት ተሻጋሪ አለመሆኑን ልብ ይበሉ
    /////
    /// let val_casts = unsafe { &mut *(ptr as *mut i32 as *mut u32) };
    /// ```
    ///
    /// አንድ `&[u8]` ወደ አንድ `&str` በማብራት:
    ///
    /// ```
    /// // ይህን ይህን ለማድረግ ጥሩ መንገድ አይደለም.
    /// let slice = unsafe { std::mem::transmute::<&str, &[u8]>("Rust") };
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // `str::as_bytes` ን መጠቀም ይችላሉ
    /// let slice = "Rust".as_bytes();
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // ቃል በቃል የሕብረቁምፊ ላይ ቁጥጥር ካለዎት ባይት ሕብረቁምፊ ይጠቀሙ
    /////
    /// assert_eq!(b"Rust", &[82, 117, 115, 116]);
    /// ```
    ///
    /// አንድ `Vec<Option<&T>>` ወደ አንድ `Vec<&T>` በማጥፋት.
    ///
    /// አንድ መያዣ ይዘቶች ወደ ውስጠኛው አይነት transmute ዘንድ, እርግጠኛ መያዣ ያለው invariants ማንኛውንም የሚጥስ አይደለም ማድረግ አለበት.
    /// `Vec` ያህል መጠን *እንዲሁም ውስጣዊ አይነቶች አሰላለፍ* ሁለቱም እንዳላቸው ይህ ማለት ለማዛመድ.
    /// ሌሎች ኮንቴይነሮች በአይነቱ ፣ በአሰላለፉ ወይም በ `TypeId` መጠኑ ላይ ሊተማመኑ ይችላሉ ፣ በዚህ ጊዜ የመያዣ መለዋወጫዎችን ሳይጥሱ መተላለፍ በጭራሽ አይቻልም ፡፡
    ///
    ///
    /// ```
    /// let store = [0, 1, 2, 3];
    /// let v_orig = store.iter().collect::<Vec<&i32>>();
    ///
    /// // በኋላ ላይ እንደገና እንደምንጠቀምባቸው vector ን ያጣምሩ
    /// let v_clone = v_orig.clone();
    ///
    /// // ትራንስሚትን በመጠቀም-ይህ ባልተገለጸው የ `Vec` የውሂብ አቀማመጥ ላይ ይመሰረታል ፣ ይህ መጥፎ ሀሳብ እና ያልተገለጸ ባህሪን ሊያስከትል ይችላል።
    /////
    /// // ሆኖም ፣ እሱ-ቅጅ አይደለም።
    /// let v_transmuted = unsafe {
    ///     std::mem::transmute::<Vec<&i32>, Vec<Option<&i32>>>(v_clone)
    /// };
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // ይህ የሚመከረው, አስተማማኝ መንገድ ነው.
    /// // ምንም እንኳን ወደ አዲሱ ድርድር መላውን vector ን ይገለብጣል።
    /// let v_collected = v_clone.into_iter()
    ///                          .map(Some)
    ///                          .collect::<Vec<Option<&i32>>>();
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // በመረጃው አቀማመጥ ላይ በመመርኮዝ ይህ የ‹"transmuting" a `Vec`›ትክክለኛ ቅጅ-አልባ ፣ አስተማማኝ ያልሆነ መንገድ ነው ፡፡
    /// // ቃል በቃል `transmute` ን ከመጥራት ይልቅ ጠቋሚ ተዋንያንን እናከናውናለን ፣ ግን የመጀመሪያውን ውስጣዊ ዓይነት (`&i32`) ን ወደ አዲሱ (`Option<&i32>`) ከመቀየር አንፃር ፣ ይህ ሁሉም ተመሳሳይ ማስጠንቀቂያዎች አሉት ፡፡
    /////
    /// // መረጃው ከላይ በቀረበው ባሻገር ደግሞ [`from_raw_parts`] ሰነዶችን ያማክሩ.
    /////
    /// let v_from_raw = unsafe {
    ///     // FIXME vec_into_raw_parts ሲረጋጋ ይህንን ያዘምኑ።
    ///     // vector አንጠበጠቡ አይደለም የመጀመሪያውን ያረጋግጡ.
    ///     let mut v_clone = std::mem::ManuallyDrop::new(v_clone);
    ///     Vec::from_raw_parts(v_clone.as_mut_ptr() as *mut Option<&i32>,
    ///                         v_clone.len(),
    ///                         v_clone.capacity())
    /// };
    /// ```
    ///
    /// [`from_raw_parts`]: ../../std/vec/struct.Vec.html#method.from_raw_parts
    ///
    /// `split_at_mut` ን በመተግበር ላይ
    ///
    /// ```
    /// use std::{slice, mem};
    ///
    /// // ይህን ለማድረግ በርካታ መንገዶች አሉ, እና በሚከተለው (transmute) መንገድ ጋር በርካታ ችግሮች አሉ.
    /////
    /// fn split_at_mut_transmute<T>(slice: &mut [T], mid: usize)
    ///                              -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = mem::transmute::<&mut [T], &mut [T]>(slice);
    ///         // መጀመሪያ transmute ደህንነቱ የተጠበቀ አይደለም ፡፡ሁሉም ቼኮች ነው T እና
    ///         // ዩ ተመሳሳይ መጠን ያላቸው ናቸው ፡፡
    ///         // በሁለተኛ ደረጃ ፣ እዚህ ጋር ፣ ወደ አንድ ተመሳሳይ ማህደረ ትውስታ የሚያመለክቱ ሁለት የሚለወጡ ማጣቀሻዎች አሉዎት።
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // ይህ ዓይነቱ የደህንነት ችግሮችን ያስወግዳል;`&mut *` ከ*`&mut T` ወይም `*mut T` `&mut T` ብቻ* ይሰጥዎታል።
    /////
    /// fn split_at_mut_casts<T>(slice: &mut [T], mid: usize)
    ///                          -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = &mut *(slice as *mut [T]);
    ///         // ሆኖም ፣ አሁንም ወደ ተመሳሳይ ማህደረ ትውስታ የሚያመለክቱ ሁለት የሚለወጡ ማጣቀሻዎች አሉዎት።
    /////
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // ይህ መደበኛ ቤተ መጻሕፍት ይህን የሚያደርገው እንዴት ነው.
    /// // አንተ እንዲህ ያለ ነገር ማድረግ ይኖርብናል ከሆነ ይህ የተሻለው ዘዴ ነው
    /// fn split_at_stdlib<T>(slice: &mut [T], mid: usize)
    ///                       -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let ptr = slice.as_mut_ptr();
    ///         // ይህ አሁን ተመሳሳይ ትውስታ ላይ በመጠቆም ሦስት ሊቀየሩ የሚችሉ ማጣቀሻዎችን አሉት.`slice`, የ rvalue ret.0, እና rvalue ret.1.
    ///         // `slice` `let ptr = ...` በኋላ በጭራሽ ስራ ላይ አይውሉም, እና እንዲሁ አንድ "dead" እንደ መያዝ ይችላሉ, እና ስለዚህ, አንተ ብቻ ሁለት እውነተኛ ሊቀየሩ ገባዎች አላቸው.
    /////
    /////
    /////
    ///         (slice::from_raw_parts_mut(ptr, mid),
    ///          slice::from_raw_parts_mut(ptr.add(mid), len - mid))
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    // NOTE: ይህ ነጥሎ const የተረጋጋ የሚያደርገው ቢሆንም, እኛ const fn ውስጥ አንዳንድ ብጁ ኮድ አላቸው
    // በ `const fn` ውስጥ እንዳይጠቀም የሚከላከሉ ቼኮች።
    #[rustc_const_stable(feature = "const_transmute", since = "1.46.0")]
    #[rustc_diagnostic_item = "transmute"]
    pub fn transmute<T, U>(e: T) -> U;

    /// `T` እንደ የተሰጠ ትክክለኛ አይነት ጠብታ ሙጫ የሚጠይቅ ከሆነ `true` ይመልሳል;ለ `T` የቀረበው ትክክለኛ ዓይነት `Copy` ን ተግባራዊ የሚያደርግ ከሆነ `false` ን ይመልሳል።
    ///
    ///
    /// ትክክለኛ አይነት ቢሆን ጠብታ ሙጫ ወይም መሳሪያዎች `Copy` የሚጠይቅ ከሆነ, ከዚያ ይህን ተግባር መመለስ ዋጋ ያልተገለፀ ነው.
    ///
    /// በዚህ ነጥሎ ያለው የሚደረግልዎት ስሪት [`mem::needs_drop`](crate::mem::needs_drop) ነው.
    ///
    ///
    #[rustc_const_stable(feature = "const_needs_drop", since = "1.40.0")]
    pub fn needs_drop<T>() -> bool;

    /// ያሰላል አንድ ጠቋሚ ከ ማካካሻ.
    ///
    /// ልወጣ መረጃ aliasing ወዲያውኑ መጣል ነበር ጀምሮ ይህ ወደ ኢንቲጀር ከ የሚቀየር ለማስወገድ የሚያስገርም ሆኖ ነው የሚተገበረው.
    ///
    /// # Safety
    ///
    /// ሁለቱም ጀምሮ እና ምክንያት ጠቋሚ ሕግጋት ወይም የተመደበ ነገር መጨረሻ ባለፉት በአንድ ባይት ውስጥ ወይ መሆን አለበት.
    /// በሁለቱም ጠቋሚ ከውል ውጭ ነው ወይም በስነ-ፍሰት ቢከሰት ከዚያም ተመልሶ ዋጋ ተጨማሪ አጠቃቀም ያልተገለጸ ባህሪ ያስከትላል.
    ///
    ///
    /// የዚህ ውስጣዊ ይዘት የተረጋጋ ስሪት [`pointer::offset`] ነው።
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn offset<T>(dst: *const T, offset: isize) -> *const T;

    /// ማካካሻውን ከጠቋሚው ያሰላል ፣ መጠቅለል ይችላል ፡፡
    ///
    /// ልወጣው የተወሰኑ ማበረታቻዎችን ስለሚከለክል ይህ ወደ ኢንቲጀር እንዳይቀየር እና እንዳያካትት እንደ አንድ ውስጣዊ ይተገበራል።
    ///
    /// # Safety
    ///
    /// የ `offset` ነጥሎ በተቃራኒ ይህ ነጥሎ ወደ ምክንያት ወደ ነጥብ ጠቋሚ ወይም የተመደበ ነገር መጨረሻ ባለፉት አንድ ባይት ለመገደብ አይደለም; እንዲሁም ሁለት ዎቹ ማሟያ በስነ ጋር ይጠቀለላል.
    /// በ ምክንያት እሴት የግድ በትክክል መዳረሻ ትውስታ ጥቅም ላይ የሚሰራ አይደለም.
    ///
    /// በዚህ ነጥሎ ያለው የሚደረግልዎት ስሪት [`pointer::wrapping_offset`] ነው.
    ///
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn arith_offset<T>(dst: *const T, offset: isize) -> *const T;

    /// `count`*`size_of::<T>()` አንድ መጠን እና አንድ አሰላለፍ ጋር, አግባብ `llvm.memcpy.p0i8.0i8.*` ነጥሎ ጋር እኩል ነው
    ///
    /// `min_align_of::<T>()`
    ///
    /// መጠን ወደ ዜሮ እኩል ነው በስተቀር ውጭ የተመቻቹ መሆን አይችልም ስለዚህ ሳይበረታ ግቤት, `true` ተዘጋጅቷል.
    ///
    /// ይህ ነጥሎ የተረጋጋ አቻ የለውም.
    ///
    pub fn volatile_copy_nonoverlapping_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// ከተገቢው የ `llvm.memmove.p0i8.0i8.*` ውስጣዊ ጋር እኩል የሆነ ፣ በ `count* size_of::<T>()` መጠን እና ከ‹ቅንጅት›ጋር
    ///
    /// `min_align_of::<T>()`
    ///
    /// መጠን ወደ ዜሮ እኩል ነው በስተቀር ውጭ የተመቻቹ መሆን አይችልም ስለዚህ ሳይበረታ ግቤት, `true` ተዘጋጅቷል.
    ///
    /// ይህ ነጥሎ የተረጋጋ አቻ የለውም.
    ///
    pub fn volatile_copy_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// `count *size_of::<T>()` አንድ መጠንና `min_align_of::<T>()` አንድ አሰላለፍ ጋር አግባብ `llvm.memset.p0i8.*` ነጥሎ, ጋር እኩል ነው.
    ///
    ///
    /// መጠን ወደ ዜሮ እኩል ነው በስተቀር ውጭ የተመቻቹ መሆን አይችልም ስለዚህ ሳይበረታ ግቤት, `true` ተዘጋጅቷል.
    ///
    /// ይህ ነጥሎ የተረጋጋ አቻ የለውም.
    ///
    ///
    pub fn volatile_set_memory<T>(dst: *mut T, val: u8, count: usize);

    /// ከ `src` ጠቋሚ ተለዋዋጭ ተለዋዋጭ ጭነት ያካሂዳል።
    ///
    /// የዚህ ውስጣዊ ይዘት የተረጋጋ ስሪት [`core::ptr::read_volatile`](crate::ptr::read_volatile) ነው።
    pub fn volatile_load<T>(src: *const T) -> T;
    /// ለ `dst` ጠቋሚ ተለዋዋጭ መደብርን ያካሂዳል።
    ///
    /// በዚህ ነጥሎ ያለው የሚደረግልዎት ስሪት [`core::ptr::write_volatile`](crate::ptr::write_volatile) ነው.
    pub fn volatile_store<T>(dst: *mut T, val: T);

    /// በሚያከናውነው `src` ጠቋሚ ከ ያልተረጋጋ ጭነት የ ጠቋሚ የሚጣጣም መሆን አያስፈልግም.
    ///
    ///
    /// ይህ ነጥሎ የተረጋጋ አቻ የለውም.
    pub fn unaligned_volatile_load<T>(src: *const T) -> T;
    /// ለ `dst` ጠቋሚ ተለዋዋጭ መደብርን ያካሂዳል።
    /// ጠቋሚው እንዲሰለፍ አይጠየቅም።
    ///
    /// ይህ ነጥሎ የተረጋጋ አቻ የለውም.
    pub fn unaligned_volatile_store<T>(dst: *mut T, val: T);

    /// የ `f32` ስኩዌር ሥሩን ይመልሳል
    ///
    /// የዚህ ውስጣዊ ይዘት የተረጋጋ ስሪት ነው
    /// [`f32::sqrt`](../../std/primitive.f32.html#method.sqrt)
    pub fn sqrtf32(x: f32) -> f32;
    /// አንድ `f64` ያለውን ዳግም ዘር ይመልሳል
    ///
    /// የዚህ ውስጣዊ ይዘት የተረጋጋ ስሪት ነው
    /// [`f64::sqrt`](../../std/primitive.f64.html#method.sqrt)
    pub fn sqrtf64(x: f64) -> f64;

    /// ኢንቲጀር ኃይል ወደ አንድ `f32` ያስነሳል.
    ///
    /// የዚህ ውስጣዊ ይዘት የተረጋጋ ስሪት ነው
    /// [`f32::powi`](../../std/primitive.f32.html#method.powi)
    pub fn powif32(a: f32, x: i32) -> f32;
    /// `f64` ን ወደ ኢንቲጀር ኃይል ያሳድጋል።
    ///
    /// የዚህ ውስጣዊ ይዘት የተረጋጋ ስሪት ነው
    /// [`f64::powi`](../../std/primitive.f64.html#method.powi)
    pub fn powif64(a: f64, x: i32) -> f64;

    /// የ `f32` ን ሳይን ይመልሳል።
    ///
    /// የዚህ ውስጣዊ ይዘት የተረጋጋ ስሪት ነው
    /// [`f32::sin`](../../std/primitive.f32.html#method.sin)
    pub fn sinf32(x: f32) -> f32;
    /// አንድ `f64` ሳይን ያወጣል.
    ///
    /// የዚህ ውስጣዊ ይዘት የተረጋጋ ስሪት ነው
    /// [`f64::sin`](../../std/primitive.f64.html#method.sin)
    pub fn sinf64(x: f64) -> f64;

    /// የ `f32` ን ኮሳይን ይመልሳል።
    ///
    /// የዚህ ውስጣዊ ይዘት የተረጋጋ ስሪት ነው
    /// [`f32::cos`](../../std/primitive.f32.html#method.cos)
    pub fn cosf32(x: f32) -> f32;
    /// አንድ `f64` ኮሳይን ያወጣል.
    ///
    /// የዚህ ውስጣዊ ይዘት የተረጋጋ ስሪት ነው
    /// [`f64::cos`](../../std/primitive.f64.html#method.cos)
    pub fn cosf64(x: f64) -> f64;

    /// `f32` ን ወደ `f32` ኃይል ያሳድጋል።
    ///
    /// የዚህ ውስጣዊ ይዘት የተረጋጋ ስሪት ነው
    /// [`f32::powf`](../../std/primitive.f32.html#method.powf)
    pub fn powf32(a: f32, x: f32) -> f32;
    /// አንድ `f64` ኃይል ወደ አንድ `f64` ያስነሳል.
    ///
    /// የዚህ ውስጣዊ ይዘት የተረጋጋ ስሪት ነው
    /// [`f64::powf`](../../std/primitive.f64.html#method.powf)
    pub fn powf64(a: f64, x: f64) -> f64;

    /// የ‹`f32` X›ብዛት ይመልሳል።
    ///
    /// የዚህ ውስጣዊ ይዘት የተረጋጋ ስሪት ነው
    /// [`f32::exp`](../../std/primitive.f32.html#method.exp)
    pub fn expf32(x: f32) -> f32;
    /// የ‹`f64` X›ብዛት ይመልሳል።
    ///
    /// የዚህ ውስጣዊ ይዘት የተረጋጋ ስሪት ነው
    /// [`f64::exp`](../../std/primitive.f64.html#method.exp)
    pub fn expf64(x: f64) -> f64;

    /// ይመለሳል 2 አንድ `f32` ኃይል አስነሣው.
    ///
    /// የዚህ ውስጣዊ ይዘት የተረጋጋ ስሪት ነው
    /// [`f32::exp2`](../../std/primitive.f32.html#method.exp2)
    pub fn exp2f32(x: f32) -> f32;
    /// ወደ `f64` ኃይል የተነሱ ተመላሾች 2።
    ///
    /// የዚህ ውስጣዊ ይዘት የተረጋጋ ስሪት ነው
    /// [`f64::exp2`](../../std/primitive.f64.html#method.exp2)
    pub fn exp2f64(x: f64) -> f64;

    /// አንድ `f32` ተፈጥሯዊ ሎጋሪዝም ይመልሳል.
    ///
    /// የዚህ ውስጣዊ ይዘት የተረጋጋ ስሪት ነው
    /// [`f32::ln`](../../std/primitive.f32.html#method.ln)
    pub fn logf32(x: f32) -> f32;
    /// የ `f64` ን የተፈጥሮ ሎጋሪዝም ይመልሳል።
    ///
    /// የዚህ ውስጣዊ ይዘት የተረጋጋ ስሪት ነው
    /// [`f64::ln`](../../std/primitive.f64.html#method.ln)
    pub fn logf64(x: f64) -> f64;

    /// የ `f32` ን መሠረት 10 ሎጋሪዝም ይመልሳል።
    ///
    /// የዚህ ውስጣዊ ይዘት የተረጋጋ ስሪት ነው
    /// [`f32::log10`](../../std/primitive.f32.html#method.log10)
    pub fn log10f32(x: f32) -> f32;
    /// አንድ `f64` ግርጌ 10 ሎጋሪዝም ይመልሳል.
    ///
    /// የዚህ ውስጣዊ ይዘት የተረጋጋ ስሪት ነው
    /// [`f64::log10`](../../std/primitive.f64.html#method.log10)
    pub fn log10f64(x: f64) -> f64;

    /// የ `f32` ን መሠረት 2 ሎጋሪዝም ይመልሳል።
    ///
    /// የዚህ ውስጣዊ ይዘት የተረጋጋ ስሪት ነው
    /// [`f32::log2`](../../std/primitive.f32.html#method.log2)
    pub fn log2f32(x: f32) -> f32;
    /// አንድ `f64` ግርጌ 2 ሎጋሪዝም ይመልሳል.
    ///
    /// የዚህ ውስጣዊ ይዘት የተረጋጋ ስሪት ነው
    /// [`f64::log2`](../../std/primitive.f64.html#method.log2)
    pub fn log2f64(x: f64) -> f64;

    /// `f32` እሴቶች ለ `a * b + c` ያወጣል.
    ///
    /// የዚህ ውስጣዊ ይዘት የተረጋጋ ስሪት ነው
    /// [`f32::mul_add`](../../std/primitive.f32.html#method.mul_add)
    pub fn fmaf32(a: f32, b: f32, c: f32) -> f32;
    /// `f64` እሴቶች ለ `a * b + c` ያወጣል.
    ///
    /// የዚህ ውስጣዊ ይዘት የተረጋጋ ስሪት ነው
    /// [`f64::mul_add`](../../std/primitive.f64.html#method.mul_add)
    pub fn fmaf64(a: f64, b: f64, c: f64) -> f64;

    /// የ `f32` ን ፍጹም ዋጋ ይመልሳል።
    ///
    /// የዚህ ውስጣዊ ይዘት የተረጋጋ ስሪት ነው
    /// [`f32::abs`](../../std/primitive.f32.html#method.abs)
    pub fn fabsf32(x: f32) -> f32;
    /// አንድ `f64` ፍጹም እሴት ይመልሳል.
    ///
    /// የዚህ ውስጣዊ ይዘት የተረጋጋ ስሪት ነው
    /// [`f64::abs`](../../std/primitive.f64.html#method.abs)
    pub fn fabsf64(x: f64) -> f64;

    /// ሁለት `f32` እሴቶች መካከል በትንሹ ያወጣል.
    ///
    /// የዚህ ውስጣዊ ይዘት የተረጋጋ ስሪት ነው
    /// [`f32::min`]
    pub fn minnumf32(x: f32, y: f32) -> f32;
    /// ሁለት `f64` እሴቶች መካከል በትንሹ ያወጣል.
    ///
    /// የዚህ ውስጣዊ ይዘት የተረጋጋ ስሪት ነው
    /// [`f64::min`]
    pub fn minnumf64(x: f64, y: f64) -> f64;
    /// ከፍተኛውን የሁለት `f32` እሴቶችን ይመልሳል።
    ///
    /// የዚህ ውስጣዊ ይዘት የተረጋጋ ስሪት ነው
    /// [`f32::max`]
    pub fn maxnumf32(x: f32, y: f32) -> f32;
    /// ከፍተኛውን የሁለት `f64` እሴቶችን ይመልሳል።
    ///
    /// የዚህ ውስጣዊ ይዘት የተረጋጋ ስሪት ነው
    /// [`f64::max`]
    pub fn maxnumf64(x: f64, y: f64) -> f64;

    /// ቅጂዎች `f32` እሴቶች ለ `x` ወደ `y` ከ ምልክት.
    ///
    /// የዚህ ውስጣዊ ይዘት የተረጋጋ ስሪት ነው
    /// [`f32::copysign`](../../std/primitive.f32.html#method.copysign)
    pub fn copysignf32(x: f32, y: f32) -> f32;
    /// ምልክቱን ከ `y` እስከ `x` ለ `f64` እሴቶች ይገለብጠዋል።
    ///
    /// የዚህ ውስጣዊ ይዘት የተረጋጋ ስሪት ነው
    /// [`f64::copysign`](../../std/primitive.f64.html#method.copysign)
    pub fn copysignf64(x: f64, y: f64) -> f64;

    /// ያነሰ ወይም ይመልሳል ትልቁ ኢንቲጀር አንድ `f32` ጋር እኩል.
    ///
    /// የዚህ ውስጣዊ ይዘት የተረጋጋ ስሪት ነው
    /// [`f32::floor`](../../std/primitive.f32.html#method.floor)
    pub fn floorf32(x: f32) -> f32;
    /// ከ `f64` በታች ወይም እኩል የሆነውን ትልቁን ኢንቲጀር ይመልሳል።
    ///
    /// የዚህ ውስጣዊ ይዘት የተረጋጋ ስሪት ነው
    /// [`f64::floor`](../../std/primitive.f64.html#method.floor)
    pub fn floorf64(x: f64) -> f64;

    /// ወይም `f32` እኩል ይልቅ ትንሹ ኢንቲጀር የሚበልጥ ያወጣል.
    ///
    /// የዚህ ውስጣዊ ይዘት የተረጋጋ ስሪት ነው
    /// [`f32::ceil`](../../std/primitive.f32.html#method.ceil)
    pub fn ceilf32(x: f32) -> f32;
    /// ከ `f64` የበለጠ ወይም እኩል የሆነውን ትንሹ ኢንቲጀር ይመልሳል።
    ///
    /// የዚህ ውስጣዊ ይዘት የተረጋጋ ስሪት ነው
    /// [`f64::ceil`](../../std/primitive.f64.html#method.ceil)
    pub fn ceilf64(x: f64) -> f64;

    /// የ‹`f32` X›ኢንቲጀር ክፍል ይመልሳል።
    ///
    /// የዚህ ውስጣዊ ይዘት የተረጋጋ ስሪት ነው
    /// [`f32::trunc`](../../std/primitive.f32.html#method.trunc)
    pub fn truncf32(x: f32) -> f32;
    /// የ‹`f64` X›ኢንቲጀር ክፍል ይመልሳል።
    ///
    /// የዚህ ውስጣዊ ይዘት የተረጋጋ ስሪት ነው
    /// [`f64::trunc`](../../std/primitive.f64.html#method.trunc)
    pub fn truncf64(x: f64) -> f64;

    /// በአቅራቢያው ያለውን ኢንቲጀር ወደ `f32` ይመልሳል።
    /// ክርክሩ ኢንቲጀር ካልሆነ የማይሆን ተንሳፋፊ-ነጥብ ልዩነትን ሊያነሳ ይችላል።
    pub fn rintf32(x: f32) -> f32;
    /// በአቅራቢያው ያለውን ኢንቲጀር ወደ `f64` ይመልሳል።
    /// ክርክሩ ኢንቲጀር ካልሆነ የማይሆን ተንሳፋፊ-ነጥብ ልዩነትን ሊያነሳ ይችላል።
    pub fn rintf64(x: f64) -> f64;

    /// በአቅራቢያው ያለውን ኢንቲጀር ወደ `f32` ይመልሳል።
    ///
    /// ይህ ነጥሎ የተረጋጋ አቻ የለውም.
    pub fn nearbyintf32(x: f32) -> f32;
    /// በአቅራቢያው ያለውን ኢንቲጀር ወደ `f64` ይመልሳል።
    ///
    /// ይህ ነጥሎ የተረጋጋ አቻ የለውም.
    pub fn nearbyintf64(x: f64) -> f64;

    /// አንድ `f32` ወደ ወደሚቀርበው ኢንቲጀር ያወጣል.ከዜሮ ርቆ በግማሽ መንገድ ጉዳዮችን ያጠጋጋል ፡፡
    ///
    /// የዚህ ውስጣዊ ይዘት የተረጋጋ ስሪት ነው
    /// [`f32::round`](../../std/primitive.f32.html#method.round)
    pub fn roundf32(x: f32) -> f32;
    /// አንድ `f64` ወደ ወደሚቀርበው ኢንቲጀር ያወጣል.ከዜሮ ርቆ በግማሽ መንገድ ጉዳዮችን ያጠጋጋል ፡፡
    ///
    /// የዚህ ውስጣዊ ይዘት የተረጋጋ ስሪት ነው
    /// [`f64::round`](../../std/primitive.f64.html#method.round)
    pub fn roundf64(x: f64) -> f64;

    /// በአልጀብራ ህጎች ላይ ተመስርተው ማትባቶችን የሚፈቅድ ተንሳፋፊ መደመር።
    /// ግብዓቶችን የተገደብን ነን ማሰብ ይችላል.
    ///
    /// ይህ ነጥሎ የተረጋጋ አቻ የለውም.
    pub fn fadd_fast<T: Copy>(a: T, b: T) -> T;

    /// በአልጄብራ ህጎች ላይ ተመስርተው ማትባቶችን የሚፈቅድ ተንሳፋፊ መቀነስ።
    /// ግብዓቶችን የተገደብን ነን ማሰብ ይችላል.
    ///
    /// ይህ ነጥሎ የተረጋጋ አቻ የለውም.
    pub fn fsub_fast<T: Copy>(a: T, b: T) -> T;

    /// በአልጀብራ ህጎች ላይ ተመስርተው ማትባቶችን የሚፈቅድ ተንሳፋፊ ማባዛት ፡፡
    /// ግብዓቶችን የተገደብን ነን ማሰብ ይችላል.
    ///
    /// ይህ ነጥሎ የተረጋጋ አቻ የለውም.
    pub fn fmul_fast<T: Copy>(a: T, b: T) -> T;

    /// በአልጀብራዊ ደንቦች ላይ የተመሠረቱ ማሳደጊያዎች የሚፈቅድ መለያየት መንሳፈፍ.
    /// ግብዓቶችን የተገደብን ነን ማሰብ ይችላል.
    ///
    /// ይህ ነጥሎ የተረጋጋ አቻ የለውም.
    pub fn fdiv_fast<T: Copy>(a: T, b: T) -> T;

    /// በአልጀብራ ህጎች ላይ ተመስርተው ማትባቶችን የሚፈቅድ ተንሳፋፊ ቀሪ።
    /// ግብዓቶችን የተገደብን ነን ማሰብ ይችላል.
    ///
    /// ይህ ነጥሎ የተረጋጋ አቻ የለውም.
    pub fn frem_fast<T: Copy>(a: T, b: T) -> T;

    /// ከክልል ውጭ ላሉት እሴቶች ያልተስተካከለ መመለስ በሚችል በ LLVM's fptoui/fptosi ይቀይሩ
    /// (<https://github.com/rust-lang/rust/issues/10184>)
    ///
    /// እንደ [`f32::to_int_unchecked`] እና [`f64::to_int_unchecked`] ተረጋግቷል።
    pub fn float_to_int_unchecked<Float: Copy, Int: Copy>(value: Float) -> Int;

    /// በአንድ ኢንቲጀር ዓይነት `T` ውስጥ የተቀመጡትን የቢቶች ብዛት ይመልሳል
    ///
    /// በዚህ ነጥሎ ያለው የሚደረግልዎት ስሪቶች በ `count_ones` ዘዴ በኩል ወደ ኢንቲጀር primitives ላይ ይገኛሉ.
    /// ለምሳሌ,
    /// [`u32::count_ones`]
    #[rustc_const_stable(feature = "const_ctpop", since = "1.40.0")]
    pub fn ctpop<T: Copy>(x: T) -> T;

    /// በ‹`T`›ኢንቲጀር ዓይነት የሚመሩ ያልተዋቀሩ ቢት ቁጥር (zeroes) ን ይመልሳል ፡፡
    ///
    /// የዚህ ውስጣዊ የተረጋጉ ስሪቶች በ‹XXXXX›ዘዴ በኩል ባለው ኢንቲጀር ጥንታዊ ነገሮች ላይ ይገኛሉ ፡፡
    /// ለምሳሌ,
    /// [`u32::leading_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 3);
    /// ```
    ///
    /// ዋጋ `0` ጋር አንድ `x` `T` ያለውን ትንሽ ስፋት ይመለሳል.
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0u16;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 16);
    /// ```
    #[rustc_const_stable(feature = "const_ctlz", since = "1.40.0")]
    pub fn ctlz<T: Copy>(x: T) -> T;

    /// እንደ `ctlz` ፣ ግን X0 `x` ን ከእሴት `0` ጋር ሲሰጥ `undef` ን ስለሚመልስ ተጨማሪ ደህንነቱ የተጠበቀ ነው ፡፡
    ///
    ///
    /// ይህ ነጥሎ የተረጋጋ አቻ የለውም.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz_nonzero;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = unsafe { ctlz_nonzero(x) };
    /// assert_eq!(num_leading, 3);
    /// ```
    #[rustc_const_stable(feature = "constctlz", since = "1.50.0")]
    pub fn ctlz_nonzero<T: Copy>(x: T) -> T;

    /// በ‹XXXX›ኢንቲጀር ዓይነት ውስጥ የመከታተያ unset bits (zeroes) ቁጥርን ይመልሳል።
    ///
    /// የዚህ ውስጣዊ የተረጋጉ ስሪቶች በ‹XXXXX›ዘዴ በኩል ባለው ኢንቲጀር ጥንታዊ ነገሮች ላይ ይገኛሉ ፡፡
    /// ለምሳሌ,
    /// [`u32::trailing_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 3);
    /// ```
    ///
    /// `0` ካለው እሴት `0` ጋር የ `T` ን ትንሽ ስፋት ይመልሳል
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0u16;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 16);
    /// ```
    #[rustc_const_stable(feature = "const_cttz", since = "1.40.0")]
    pub fn cttz<T: Copy>(x: T) -> T;

    /// ልክ እንደ `cttz`, ነገር ግን ዋጋ `0` ጋር `x` የተሰጠው ጊዜ `undef` ይመልሳል እንደ ተጨማሪ-ያልተጠበቀ.
    ///
    ///
    /// ይህ ነጥሎ የተረጋጋ አቻ የለውም.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz_nonzero;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = unsafe { cttz_nonzero(x) };
    /// assert_eq!(num_trailing, 3);
    /// ```
    #[rustc_const_unstable(feature = "const_cttz", issue = "none")]
    pub fn cttz_nonzero<T: Copy>(x: T) -> T;

    /// ባይት ኢንቲጀር ዓይነት `T` ውስጥ ይሽራል።
    ///
    /// በዚህ ነጥሎ ያለው የሚደረግልዎት ስሪቶች በ `swap_bytes` ዘዴ በኩል ወደ ኢንቲጀር primitives ላይ ይገኛሉ.
    /// ለምሳሌ,
    /// [`u32::swap_bytes`]
    #[rustc_const_stable(feature = "const_bswap", since = "1.40.0")]
    pub fn bswap<T: Copy>(x: T) -> T;

    /// ኢንቲጀር አይነት `T` ውስጥ እናገባለን አቅጣጫ ለውጦታል.
    ///
    /// በዚህ ነጥሎ ያለው የሚደረግልዎት ስሪቶች በ `reverse_bits` ዘዴ በኩል ወደ ኢንቲጀር primitives ላይ ይገኛሉ.
    /// ለምሳሌ,
    /// [`u32::reverse_bits`]
    #[rustc_const_stable(feature = "const_bitreverse", since = "1.40.0")]
    pub fn bitreverse<T: Copy>(x: T) -> T;

    /// የተረጋገጠ የቁጥር መጨመርን ያካሂዳል።
    ///
    /// በዚህ ነጥሎ ያለው የሚደረግልዎት ስሪቶች በ `overflowing_add` ዘዴ በኩል ወደ ኢንቲጀር primitives ላይ ይገኛሉ.
    /// ለምሳሌ,
    /// [`u32::overflowing_add`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn add_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// እንደሚሰራ መቀነስ ኢንቲጀር የተደረገባቸው
    ///
    /// በዚህ ነጥሎ ያለው የሚደረግልዎት ስሪቶች በ `overflowing_sub` ዘዴ በኩል ወደ ኢንቲጀር primitives ላይ ይገኛሉ.
    /// ለምሳሌ,
    /// [`u32::overflowing_sub`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn sub_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// እንደሚሰራ የማባዛት ኢንቲጀር የተደረገባቸው
    ///
    /// በዚህ ነጥሎ ያለው የሚደረግልዎት ስሪቶች በ `overflowing_mul` ዘዴ በኩል ወደ ኢንቲጀር primitives ላይ ይገኛሉ.
    /// ለምሳሌ,
    /// [`u32::overflowing_mul`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn mul_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// ትክክለኛ ክፍፍል ያካሂዳል ፣ በዚህም ያልተገለጸ ባህሪን ያስከትላል `x % y != 0` ወይም `y == 0` ወይም `x == T::MIN && y == -1`
    ///
    ///
    /// ይህ ነጥሎ የተረጋጋ አቻ የለውም.
    pub fn exact_div<T: Copy>(x: T, y: T) -> T;

    /// ያልተገለጸ ባህሪ የት `y == 0` ወይም `x == T::MIN && y == -1` ምክንያት, አንድ ካልተደረገበት ክፍፍል ያከናውናል
    ///
    ///
    /// በዚህ ነጥሎ አስተማማኝ wrappers በ `checked_div` ዘዴ በኩል ወደ ኢንቲጀር primitives ላይ ይገኛሉ.
    /// ለምሳሌ,
    /// [`u32::checked_div`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_div<T: Copy>(x: T, y: T) -> T;
    /// ያልተገለጸ ባህሪ ጊዜ `y == 0` ወይም `x == T::MIN && y == -1` ምክንያት, አንድ ካልተደረገበት ክፍፍል ቀሪውን ይመልሳል
    ///
    ///
    /// ለዚህ ውስጣዊ ውስጣዊ አስተማማኝ መጠቅለያዎች በ‹`checked_rem` X›ዘዴ በኩል ባለው የቁጥር የመጀመሪያ ላይ ይገኛሉ ፡፡
    /// ለምሳሌ,
    /// [`u32::checked_rem`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_rem<T: Copy>(x: T, y: T) -> T;

    /// N በቢቲዎች ውስጥ የቲ ስፋት ስፋቱ `y < 0` ወይም `y >= N` በሚሆንበት ጊዜ ያልተፈተሸ የግራ ለውጥን ያካሂዳል።
    ///
    ///
    /// በዚህ ነጥሎ አስተማማኝ wrappers በ `checked_shl` ዘዴ በኩል ወደ ኢንቲጀር primitives ላይ ይገኛሉ.
    /// ለምሳሌ,
    /// [`u32::checked_shl`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shl<T: Copy>(x: T, y: T) -> T;
    /// N በቢቲዎች ውስጥ የቲ ስፋት ስፋቱ `y < 0` ወይም `y >= N` በሚሆንበት ጊዜ ያልተፈተሸ የቀኝ ለውጥን ያካሂዳል።
    ///
    ///
    /// ለዚህ ውስጣዊ ውስጣዊ አስተማማኝ መጠቅለያዎች በ‹`checked_shr` X›ዘዴ በኩል ባለው የቁጥር የመጀመሪያ ላይ ይገኛሉ ፡፡
    /// ለምሳሌ,
    /// [`u32::checked_shr`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shr<T: Copy>(x: T, y: T) -> T;

    /// `x + y > T::MAX` ወይም `x + y < T::MIN` በሚሆንበት ጊዜ ያልተመረመረ የባህሪ ውጤት ያስከትላል ያልተመረመረ የመደመር ውጤትን ይመልሳል።
    ///
    ///
    /// ይህ ነጥሎ የተረጋጋ አቻ የለውም.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_add<T: Copy>(x: T, y: T) -> T;

    /// `x - y > T::MAX` ወይም `x - y < T::MIN` በሚሆንበት ጊዜ ያልተመረጠ የመቀነስ ውጤትን ይመልሳል።
    ///
    ///
    /// ይህ ነጥሎ የተረጋጋ አቻ የለውም.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_sub<T: Copy>(x: T, y: T) -> T;

    /// ያልተገለጸ ባህሪ ጊዜ `x *y > T::MAX` ወይም `x* y < T::MIN` ምክንያት, አንድ ካልተደረገበት የማባዛት ውጤት ያወጣል.
    ///
    ///
    /// ይህ ነጥሎ የተረጋጋ አቻ የለውም.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_mul<T: Copy>(x: T, y: T) -> T;

    /// ያከናውናል ወደ ግራ አሽከርክር.
    ///
    /// በዚህ ነጥሎ ያለው የሚደረግልዎት ስሪቶች በ `rotate_left` ዘዴ በኩል ወደ ኢንቲጀር primitives ላይ ይገኛሉ.
    /// ለምሳሌ,
    /// [`u32::rotate_left`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_left<T: Copy>(x: T, y: T) -> T;

    /// ያከናውናል ቀኝ ያሽከርክሩ.
    ///
    /// የዚህ ውስጣዊ የተረጋጉ ስሪቶች በ‹XXXXX›ዘዴ በኩል ባለው ኢንቲጀር ጥንታዊ ነገሮች ላይ ይገኛሉ ፡፡
    /// ለምሳሌ,
    /// [`u32::rotate_right`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_right<T: Copy>(x: T, y: T) -> T;

    /// ተመላሾች (ሀ + ለ) ሞዱል 2 <sup>N</sup> ፣ የት N ቢ በቢቶች ውስጥ ነው።
    ///
    /// በዚህ ነጥሎ ያለው የሚደረግልዎት ስሪቶች በ `wrapping_add` ዘዴ በኩል ወደ ኢንቲጀር primitives ላይ ይገኛሉ.
    /// ለምሳሌ,
    /// [`u32::wrapping_add`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_add<T: Copy>(a: T, b: T) -> T;
    /// ይመለሳል N ቢት ውስጥ T ወርድ የት (ሀ, ለ) Mod 2 <sup>ኤን,.</sup>
    ///
    /// በዚህ ነጥሎ ያለው የሚደረግልዎት ስሪቶች በ `wrapping_sub` ዘዴ በኩል ወደ ኢንቲጀር primitives ላይ ይገኛሉ.
    /// ለምሳሌ,
    /// [`u32::wrapping_sub`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_sub<T: Copy>(a: T, b: T) -> T;
    /// ይመለሳል (ሀ * ለ) N ቢት ውስጥ T ወርድ የት 2 <sup>ኤን,</sup> Mod.
    ///
    /// በዚህ ነጥሎ ያለው የሚደረግልዎት ስሪቶች በ `wrapping_mul` ዘዴ በኩል ወደ ኢንቲጀር primitives ላይ ይገኛሉ.
    /// ለምሳሌ,
    /// [`u32::wrapping_mul`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_mul<T: Copy>(a: T, b: T) -> T;

    /// በቁጥር ወሰን በማርካት `a + b` ን ያሰላል።
    ///
    /// በዚህ ነጥሎ ያለው የሚደረግልዎት ስሪቶች በ `saturating_add` ዘዴ በኩል ወደ ኢንቲጀር primitives ላይ ይገኛሉ.
    /// ለምሳሌ,
    /// [`u32::saturating_add`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_add<T: Copy>(a: T, b: T) -> T;
    /// ያሰላል `a - b`, ቁጥራዊ ወሰን ላይ saturating.
    ///
    /// በዚህ ነጥሎ ያለው የሚደረግልዎት ስሪቶች በ `saturating_sub` ዘዴ በኩል ወደ ኢንቲጀር primitives ላይ ይገኛሉ.
    /// ለምሳሌ,
    /// [`u32::saturating_sub`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_sub<T: Copy>(a: T, b: T) -> T;

    /// 'v' ውስጥ ተለዋጭ discriminant ያለውን እሴት ይመልሳል;
    /// `T` አድልዎ ከሌለው `0` ን ይመልሳል።
    ///
    /// በዚህ ነጥሎ ያለው የሚደረግልዎት ስሪት [`core::mem::discriminant`](crate::mem::discriminant) ነው.
    #[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
    pub fn discriminant_value<T>(v: &T) -> <T as DiscriminantKind>::Discriminant;

    /// ይመለሳል `T` አንድ `usize` ወደ ይጣላል አይነት ተለዋጮች ብዛት;
    /// `T` ምንም ተለዋጮች ከሌለው `0` ን ይመልሳል።የማይኖሩ ተለዋጮች ይቆጠራሉ ፡፡
    ///
    /// በዚህ ነጥሎ ያለው ወደ-ጸንተን ይሆናል ስሪት [`mem::variant_count`] ነው.
    #[rustc_const_unstable(feature = "variant_count", issue = "73662")]
    pub fn variant_count<T>() -> usize;

    /// ውሂብ ጠቋሚ `data` ጋር ተግባር ጠቋሚ `try_fn` invokes ይህም Rust ዎቹ "try catch" CONSTRUCT.
    ///
    /// ሦስተኛው ክርክር panic ከተከሰተ የሚጠራ ተግባር ነው ፡፡
    /// ይህ ተግባር የመረጃ ጠቋሚውን እና ጠቋሚውን ወደ ተያዘው ዒላማ ልዩ ልዩ ነገር ይወስዳል ፡፡
    ///
    /// ተጨማሪ መረጃ ለማግኘት አጠናቃሪ ምንጭ እንዲሁም std ዎቹ መያዝ አፈፃፀም ይመልከቱ.
    ///
    pub fn r#try(try_fn: fn(*mut u8), data: *mut u8, catch_fn: fn(*mut u8, *mut u8)) -> i32;

    /// በኤልኤልቪኤም መሠረት የ `!nontemporal` መደብር ይለቃል (ሰነዶቻቸውን ይመልከቱ)።
    /// ምናልባት የተረጋጋ መሆን ፈጽሞ.
    pub fn nontemporal_store<T>(ptr: *mut T, val: T);

    /// ለዝርዝሮች የ `<*const T>::offset_from` ሰነድን ይመልከቱ ፡፡
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    pub fn ptr_offset_from<T>(ptr: *const T, base: *const T) -> isize;

    /// ዝርዝሮችን ለማግኘት `<*const T>::guaranteed_eq` ሰነዶችን ይመልከቱ.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_eq<T>(ptr: *const T, other: *const T) -> bool;

    /// ለዝርዝሮች የ `<*const T>::guaranteed_ne` ሰነድን ይመልከቱ ፡፡
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_ne<T>(ptr: *const T, other: *const T) -> bool;

    /// በማጠናቀር ጊዜ ይመድቡ።የሚፈጀውን ጊዜ ላይ ተብሎ መሆን የለበትም.
    #[rustc_const_unstable(feature = "const_heap", issue = "79597")]
    pub fn const_allocate(size: usize, align: usize) -> *mut u8;
}

// አንዳንድ ተግባራት እዚህ ይገለፃሉ ምክንያቱም በአጋጣሚ በዚህ ሞጁል ውስጥ በተረጋጋ ሁኔታ እንዲገኙ ተደርጓል ፡፡
// <https://github.com/rust-lang/rust/issues/15702> ን ይመልከቱ።
// (`transmute` ደግሞ በዚህ ምድብ ውስጥ ቢወድቅ ግን `T` እና `U` ተመሳሳይ መጠን ያላቸው ቼክ ምክንያት ተጠቅልሎ ሊሆን አይችልም.)
//

/// `ptr` ን ከ `align_of::<T>()` ጋር በትክክል መጣጣሙን ያረጋግጣል።
///
pub(crate) fn is_aligned_and_not_null<T>(ptr: *const T) -> bool {
    !ptr.is_null() && ptr as usize % mem::align_of::<T>() == 0
}

/// ቅጂዎች `count *size_of::<T>()` ባይት ከ `src` እስከ `dst`።ምንጩ እና መድረሻው* መደራረብ * የለበትም።
///
/// መደራረብ ይችላል ይህም ትውስታ ክልሎች, ይልቁንስ [`copy`] ይጠቀሙ.
///
/// `copy_nonoverlapping` C ዎቹ [`memcpy`], ነገር ግን የተገላበጠ መከራከሪያ ትእዛዝ ጋር አቀነባበርና አቻ ነው.
///
/// [`memcpy`]: https://en.cppreference.com/w/c/string/byte/memcpy
///
/// # Safety
///
/// ከሚከተሉት ሁኔታዎች ውስጥ አንዳቸውም ቢጣሱ ባህሪይ አልተገለጸም-
///
/// * `src` ለ `count * size_of::<T>()` ባይት ንባብ [valid] መሆን አለበት።
///
/// * `dst` `count * size_of::<T>()` የባይት ጽፈዋል ለ [valid] መሆን አለበት.
///
/// * `src` እና `dst` ሁለቱም በአግባቡ የሚጣጣም መሆን አለበት.
///
/// * በ‹XXXX›የሚጀምር የማስታወሻ ክልል በ‹ቆጠራ መጠን› *
///   size_of: :<T>() `ባይት በተመሳሳይ መጠን ከ `dst` ጀምሮ ባለው የማስታወሻ ክልል * * መደራረብ * የለበትም።
///
/// [`read`] ልክ እንደ `copy_nonoverlapping` ምንም ይሁን `T` [`Copy`] ነው አልሆነ, `T` አንድ bitwise ቅጂ ይፈጥራል.
/// `T` [`Copy`] ካልሆነ በ `*src` እና በ `* dst` የሚጀምረው ክልል ውስጥ * **እሴቶችን በመጠቀም* ሁለቱንም * በመጠቀም [violate memory safety][read-ownership] ይችላል ፡፡
///
///
/// ምንም እንኳን በውጤታማነቱ የተገለበጠው መጠን (`ቆጠራ * መጠን_ፋ: :<T>()`0` ነው ፣ ጠቋሚዎቹ NULL ያልሆኑ እና በትክክል የተጣጣሙ መሆን አለባቸው።
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// [`Vec::append`] ን በእጅ ይተግብሩ:
///
/// ```
/// use std::ptr;
///
/// /// የ `src` ን ሁሉንም ነገሮች ወደ `dst` ያዛውራል ፣ `src` ን ባዶ ያደርገዋል።
/// fn append<T>(dst: &mut Vec<T>, src: &mut Vec<T>) {
///     let src_len = src.len();
///     let dst_len = dst.len();
///
///     // `dst` `src` ሁሉንም ለመያዝ በቂ አቅም ያለው መሆኑን ያረጋግጡ.
///     dst.reserve(src_len);
///
///     unsafe {
///         // `Vec` `isize::MAX` ባይት በላይ ለመመደብ ፈጽሞ ምክንያቱም የሚካካሱ ጥሪ ሁልጊዜ ደህንነቱ የተጠበቀ ነው.
/////
///         let dst_ptr = dst.as_mut_ptr().offset(dst_len as isize);
///         let src_ptr = src.as_ptr();
///
///         // ይዘቱን ሳይጥሉ `src` ይከርክሙ።
///         // እኛ panics ወደታች ተጨማሪ ጉዳይ ነገር ውስጥ መጠንቀቅ ችግር, በመጀመሪያ ይህን አድርግ.
///         src.set_len(0);
///
///         // ሁለቱ ክልሎች መደጋገፍ አይችሉም ፣ ምክንያቱም የሚለወጡ ማጣቀሻዎች ቅጽል ስሞች ስላልሆኑ ፣ እና ሁለት የተለያዩ vectors ተመሳሳይ የማስታወስ ችሎታ ሊኖራቸው አይችልም።
/////
/////
///         ptr::copy_nonoverlapping(src_ptr, dst_ptr, src_len);
///
///         // የ `src` ይዘቶችን እንደያዘ ለ `dst` ያሳውቁ።
///         dst.set_len(dst_len + src_len);
///     }
/// }
///
/// let mut a = vec!['r'];
/// let mut b = vec!['u', 's', 't'];
///
/// append(&mut a, &mut b);
///
/// assert_eq!(a, &['r', 'u', 's', 't']);
/// assert!(b.is_empty());
/// ```
///
/// [`Vec::append`]: ../../std/vec/struct.Vec.html#method.append
///
///
///
///
///
#[doc(alias = "memcpy")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: እነዚህን ቼኮች በሩጫ ሰዓት ብቻ ያከናውኑ
    /*if cfg!(debug_assertions)
        && !(is_aligned_and_not_null(src)
            && is_aligned_and_not_null(dst)
            && is_nonoverlapping(src, dst, count))
    {
        // የኮዴጌን ተፅእኖ አነስተኛ እንዲሆን ላለመደናገጥ ፡፡
        abort();
    }*/

    // ደህንነት: `copy_nonoverlapping` ለ የደህንነት ውል መሆን አለበት
    // በተጠሪው ደገፈ ፡፡
    unsafe { copy_nonoverlapping(src, dst, count) }
}

/// `count * size_of::<T>()` `dst` ወደ `src` ከ BYTES እናስታውቃለን.የምንጭ እና መድረሻ መደራረብ ይችላል.
///
/// ምንጭ እና መድረሻ * * መደራረብ, [`copy_nonoverlapping`] ፋንታ ጥቅም ላይ ሊውል ይችላል ፈጽሞ ከሆነ.
///
/// `copy` ከሲኤክስኤክስኤክስኤክስ ጋር ተመሳሳይ ነው ፣ ግን በክርክሩ ትዕዛዝ ተቀይሯል።
/// በመቅዳት ላይ ወደ ባይት ጊዜያዊ ድርድር ወደ `src` ከ ተገልብጧል ከዚያም `dst` ወደ ድርድር ተቀድተው ነበር ከሆነ እንደ ቦታ ይወስዳል.
///
/// [`memmove`]: https://en.cppreference.com/w/c/string/byte/memmove
///
/// # Safety
///
/// ከሚከተሉት ሁኔታዎች ውስጥ አንዳቸውም ቢጣሱ ባህሪይ አልተገለጸም-
///
/// * `src` ለ `count * size_of::<T>()` ባይት ንባብ [valid] መሆን አለበት።
///
/// * `dst` `count * size_of::<T>()` የባይት ጽፈዋል ለ [valid] መሆን አለበት.
///
/// * `src` እና `dst` ሁለቱም በአግባቡ የሚጣጣም መሆን አለበት.
///
/// እንደ [`read`] ፣ `copy` `T` [`Copy`] ቢሆንም የ `T` ን ትንሽ ቅጅ ይፈጥራል።
/// `T` [`Copy`] ካልሆነ በ `*src` እና በ `* dst` የሚጀምር ክልልን ሁለቱንም እሴቶች በመጠቀም [violate memory safety][read-ownership] ይችላል ፡፡
///
///
/// ምንም እንኳን በውጤታማነቱ የተገለበጠው መጠን (`ቆጠራ * መጠን_ፋ: :<T>()`0` ነው ፣ ጠቋሚዎቹ NULL ያልሆኑ እና በትክክል የተጣጣሙ መሆን አለባቸው።
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// በብቃት ያልተጠበቀ ቋት ከ Rust vector ይፍጠሩ:
///
/// ```
/// use std::ptr;
///
/// /// # Safety
//////
/// /// * `ptr` ለዓይነቱ እና ዜሮ-ያልሆነው በትክክል መመሳሰል አለበት።
/// /// * `ptr` ለ‹X0 `elts`›ተመሳሳይ የ `T` ተያያዥ ንጥረ ነገሮች ንባቦች ትክክለኛ መሆን አለባቸው ፡፡
/// /// * እነዚህ ንጥረ ነገሮች `T: Copy` በስተቀር ይህን ተግባር በመጥራት በኋላ ጥቅም ላይ መዋል የለበትም.
/// # #[allow(dead_code)]
/// unsafe fn from_buf_raw<T>(ptr: *const T, elts: usize) -> Vec<T> {
///     let mut dst = Vec::with_capacity(elts);
///
///     // ደህንነት-ቅድመ ሁኔታችን ምንጩ የተስተካከለ እና ትክክለኛ መሆኑን ያረጋግጣል ፣
///     // እና `Vec::with_capacity` እኛም እነሱን ለመጻፍ ላይ ሊውል የሚችል ቦታ እንዳላቸው ያረጋግጣል.
///     ptr::copy(ptr, dst.as_mut_ptr(), elts);
///
///     // ደህንነት: እኛ ይህን ያህል አቅም ቀደም ጋር የተፈጠረ
///     // ወደ ቀዳሚው `copy` ከእነዚህ አባሎች አልተነሳም አድርጓል.
///     dst.set_len(elts);
///     dst
/// }
/// ```
///
///
///
///
///
#[doc(alias = "memmove")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: እነዚህን ቼኮች በሩጫ ሰዓት ብቻ ያከናውኑ
    /*if cfg!(debug_assertions) && !(is_aligned_and_not_null(src) && is_aligned_and_not_null(dst)) {
        // የኮዴጌን ተፅእኖ አነስተኛ እንዲሆን ላለመደናገጥ ፡፡
        abort();
    }*/

    // ደህንነት: `copy` ለ የደህንነት ውል ወደ ጠሪው በ አጽንቶታል መሆን አለበት.
    unsafe { copy(src, dst, count) }
}

/// ስብስቦች `count * size_of::<T>()` `val` ወደ `dst` ጀምሮ ትውስታ ባይቶች ነው.
///
/// `write_bytes` C ዎቹ [`memset`] ጋር ተመሳሳይ ነው, ነገር ግን `count * size_of::<T>()` `val` ወደ ባይት ያዘጋጃል.
///
/// [`memset`]: https://en.cppreference.com/w/c/string/byte/memset
///
/// # Safety
///
/// ከሚከተሉት ሁኔታዎች ውስጥ አንዳቸውም ቢጣሱ ባህሪይ አልተገለጸም-
///
/// * `dst` `count * size_of::<T>()` የባይት ጽፈዋል ለ [valid] መሆን አለበት.
///
/// * `dst` በትክክል መመሳሰል አለበት።
///
/// በተጨማሪም, ጠሪው `count * size_of::<T>()` መጻፍ `T` ልክ የሆነ እሴት ውስጥ ማህደረ ትውስታ ውጤት በተሰጠው ክልል ባይቶች መሆኑን ማረጋገጥ አለባቸው.
/// `T` ልክ ያልሆነ ዋጋ የያዘ `T` እንደ የተተየቡ ትውስታ ክልል መጠቀም ያልተገለጸ ባህሪ ነው.
///
/// እንኳን ውጤታማ ተገልብጧል መጠን ከሆነ (`* size_of መቁጠር መሆኑን ልብ በል: :<T>()`) `0` የ ጠቋሚ ያልሆኑ አልቦ እና በአግባቡ የሚጣጣም መሆን አለበት ነው.
///
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// መሠረታዊ አጠቃቀም
///
/// ```
/// use std::ptr;
///
/// let mut vec = vec![0u32; 4];
/// unsafe {
///     let vec_ptr = vec.as_mut_ptr();
///     ptr::write_bytes(vec_ptr, 0xfe, 2);
/// }
/// assert_eq!(vec, [0xfefefefe, 0xfefefefe, 0, 0]);
/// ```
///
/// ልክ ያልሆነ እሴት መፍጠር:
///
/// ```
/// use std::ptr;
///
/// let mut v = Box::new(0i32);
///
/// unsafe {
///     // ዜሮ ጠቋሚ ጋር `Box<T>` ደርቦ በማድረግ ቀደም ሲል በተያዘው ዋጋ የሚያንጠባጥብ.
/////
///     ptr::write_bytes(&mut v as *mut Box<i32>, 0, 1);
/// }
///
/// // በዚህ ነጥብ ላይ, በመጠቀም ወይም ያልተገለጸ ባህሪ ውስጥ `v` ውጤቶች ሲከቱ.
/// // drop(v); // ERROR
///
/// // እንኳን `v` "uses" ይህን የሚያፈስ, እና በመሆኑም ያልተገለጸ ባህሪ ነው.
/// // mem::forget(v); // ERROR
///
/// // እንደ እውነቱ ከሆነ `v` በመሰረታዊ አይነት አቀማመጥ የማይለዋወጥ ነው ፣ ስለሆነም *እሱን የሚነካ ማንኛውም* ተግባር ያልተገለጸ ባህሪ ነው።
/////
/// // v2 v=ይሁን;//ስህተት
///
/// unsafe {
///     // ከእኛ ይልቅ የሚሰራ እሴት ውስጥ እንልበስ
///     ptr::write(&mut v as *mut Box<i32>, Box::new(42i32));
/// }
///
/// // አሁን ሳጥኑ ደህና ነው
/// assert_eq!(*v, 42);
/// ```
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[inline]
pub unsafe fn write_bytes<T>(dst: *mut T, val: u8, count: usize) {
    extern "rust-intrinsic" {
        fn write_bytes<T>(dst: *mut T, val: u8, count: usize);
    }

    debug_assert!(is_aligned_and_not_null(dst), "attempt to write to unaligned or null pointer");

    // ደህንነት: `write_bytes` ለ የደህንነት ውል ወደ ጠሪው በ አጽንቶታል መሆን አለበት.
    unsafe { write_bytes(dst, val, count) }
}