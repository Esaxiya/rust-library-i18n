use crate::ops::DerefMut;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// ያልተመሳሰሉ ተጓeraችን ለማስተናገድ በይነገጽ ፡፡
///
/// ይህ trait ዋና ዥረት ነው።
/// በአጠቃላይ ስለ ጅረቶች ፅንሰ-ሀሳብ የበለጠ እባክዎን [module-level documentation] ን ይመልከቱ ፡፡
/// በተለይም እንዴት [implement `Stream`][impl] ን ማወቅ ይፈልጉ ይሆናል ፡፡
///
/// [module-level documentation]: index.html
/// [impl]: index.html#implementing-stream
#[unstable(feature = "async_stream", issue = "79024")]
#[must_use = "streams do nothing unless polled"]
pub trait Stream {
    /// በጅረቱ የተሰጡ ዕቃዎች ዓይነት።
    type Item;

    /// የዚህን ዥረት ቀጣዩ እሴት ለማውጣት መሞከር ፣ እሴቱ ገና ካልተገኘ ለመቀስቀስ የአሁኑን ተግባር በመመዝገብ እና ጅረቱ ከተሟጠጠ `None` ን ይመልሱ።
    ///
    /// # ተመለስ እሴት
    ///
    /// የተለያዩ ሊሆኑ የሚችሉ የመመለስ እሴቶች አሉ ፣ እያንዳንዱ የተለየ የዥረት ሁኔታን ያሳያል ፡፡
    ///
    /// - `Poll::Pending` ይህ ዥረት ቀጣዩ እሴት ገና አልተዘጋጀም ማለት ነው።ትግበራዎች የሚቀጥለው እሴት ዝግጁ በሚሆንበት ጊዜ የአሁኑ ሥራ ማሳወቁን ያረጋግጣሉ ፡፡
    ///
    /// - `Poll::Ready(Some(val))` ዥረቱ አንድ እሴት `val` ን በተሳካ ሁኔታ አፍርቷል እና በቀጣይ የ `poll_next` ጥሪዎች ላይ ተጨማሪ እሴቶችን ሊያመጣ ይችላል ማለት ነው።
    ///
    /// - `Poll::Ready(None)` ዥረቱ ተቋርጧል ማለት ነው ፣ እና `poll_next` እንደገና መጠራት የለበትም።
    ///
    /// # Panics
    ///
    /// አንዴ ዥረት እንደጨረሰ (`Ready(None)` from `poll_next`) ን ተመልሷል ፣ የ‹`poll_next`›ዘዴውን እንደገና በመጥራት panic ን ለዘለዓለም ያግዳል ፣ ወይም ሌሎች ችግሮችን ያስከትላል) `Stream` trait በእንደዚህ ዓይነት ጥሪ ውጤቶች ላይ ምንም ዓይነት መስፈርት አያስቀምጥም ፡፡
    ///
    /// ሆኖም የ `poll_next` ዘዴ `unsafe` ተብሎ ስላልተለጠፈ የ Rust የተለመዱ ህጎች ይተገበራሉ-ጥሪዎች የዥረቱ ሁኔታ ምንም ይሁን ምን ያልተገለጸ ባህሪን (የማስታወስ ብልሹነትን ፣ የ `unsafe` ተግባሮችን ትክክለኛ ያልሆነ አጠቃቀም ወይም የመሳሰሉትን) በጭራሽ ሊያስከትሉ አይገባም ፡፡
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>>;

    /// በቀሪው ጅረት ርዝመት ላይ ገደቦችን ይመልሳል።
    ///
    /// በተለይም, `size_hint()` የመጀመሪያው ንጥረ ነገር ያለው የታችኛው ገደብ በሌለበት አንድ tuple ይመልሳል, እና ሁለተኛው አባል በላይኛው የታሰረች ናት.
    ///
    /// ተመልሶ እንደሆነ tuple ሁለተኛ ግማሽ ነው አንድ [`Option`]`<`[`usize`] `>`.
    /// አንድ እዚህ [`None`] ምንም የለም የሚታወቅ ነው ወይ ማለት የላይኛው ገደብ, ወይም በላይኛው ታስሮ ወደ [`usize`] በላይ ነው.
    ///
    /// # የትግበራ ማስታወሻዎች
    ///
    /// የዥረት ትግበራ የታወጁትን ንጥረ ነገሮች ብዛት ያስገኛል ተብሎ አልተተገበረም ፡፡አንድ ተጎታች ጅረት ከዝቅተኛ ወሰን በታች ወይም ከከፍተኛው ንጥረ ነገሮች በላይ ሊወስድ ይችላል።
    ///
    /// `size_hint()` በዋናነት ለጅረቱ ንጥረ ነገሮች የሚሆን ቦታ ማስያዝን ለማመቻቸት ጥቅም ላይ እንዲውል የታቀደ ነው ፣ ነገር ግን በአስተማማኝ ኮድ ውስጥ የድንበር ፍተሻዎችን ለማስቀረት መታመን የለበትም ፡፡
    /// `size_hint()` ትክክል ያልሆነ አፈጻጸም ትውስታ ደህንነት ጥሰት ሊያስከትል አይገባም.
    ///
    /// ያ ማለት ፣ አተገባበሩ ትክክለኛ ግምትን መስጠት አለበት ፣ ምክንያቱም ይህ ካልሆነ የ trait ፕሮቶኮልን መጣስ ይሆናል።
    ///
    /// ነባሪው ትግበራ ይመለሳል `(0,` [`None`]`])`ይህም ለማንኛውም ዥረት ትክክል ነው።
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<S: ?Sized + Stream + Unpin> Stream for &mut S {
    type Item = S::Item;

    fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        S::poll_next(Pin::new(&mut **self), cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<P> Stream for Pin<P>
where
    P: DerefMut + Unpin,
    P::Target: Stream,
{
    type Item = <P::Target as Stream>::Item;

    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        self.get_mut().as_mut().poll_next(cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}