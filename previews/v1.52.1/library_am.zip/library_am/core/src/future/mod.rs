#![stable(feature = "futures_api", since = "1.36.0")]

//! ያልተመሳሰሉ እሴቶች።

use crate::{
    ops::{Generator, GeneratorState},
    pin::Pin,
    ptr::NonNull,
    task::{Context, Poll},
};

mod future;
mod into_future;
mod pending;
mod poll_fn;
mod ready;

#[stable(feature = "futures_api", since = "1.36.0")]
pub use self::future::Future;

#[unstable(feature = "into_future", issue = "67644")]
pub use into_future::IntoFuture;

#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use pending::{pending, Pending};
#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use ready::{ready, Ready};

#[unstable(feature = "future_poll_fn", issue = "72302")]
pub use poll_fn::{poll_fn, PollFn};

/// ይህ አይነት ምክንያቱም ያስፈልጋል:
///
/// እኛ (<https://github.com/rust-lang/rust/issues/68923> ይመልከቱ) አንድ ጥሬ ጠቋሚ ማለፍ ያስፈልግዎታል ስለዚህ ሀ) ጄነሬተሮች, `for<'a, 'b> Generator<&'a mut Context<'b>>` ተግባራዊ አይችልም.
///
/// ለ) ጥሬ ጠቋሚዎች እና `NonNull` `Send` ወይም `Sync` አይደሉም ፣ ስለሆነም እያንዳንዱን future non-Send/Sync እንዲሁ ያደርገዋል ፣ እና እኛ አንፈልግም።
///
/// በተጨማሪም `.await` ባንዲራውን በ HIR ሳንጨነቅ.
///
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[derive(Debug, Copy, Clone)]
pub struct ResumeTy(NonNull<Context<'static>>);

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Send for ResumeTy {}

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Sync for ResumeTy {}

/// ጄኔሬተርን በ future ውስጥ ይጠቅልቁ ፡፡
///
/// ይህ ተግባር `GenFuture` ን ከታች ይመልሳል ፣ ግን የተሻሉ የስህተት መልዕክቶችን (`impl Future` ከ `GenFuture<[closure.....]>` ይልቅ) ለመስጠት በ `impl Trait` ውስጥ ይደብቀዋል።
///
// ይህ እኛ `const async fn` ለማገገም በኋላ ተጨማሪ ስህተቶችን ለማስወገድ `const` ነው
#[lang = "from_generator"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[rustc_const_unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub const fn from_generator<T>(gen: T) -> impl Future<Output = T::Return>
where
    T: Generator<ResumeTy, Yield = ()>,
{
    #[rustc_diagnostic_item = "gen_future"]
    struct GenFuture<T: Generator<ResumeTy, Yield = ()>>(T);

    // በመሠረቱ ጄኔሬተር ውስጥ የራስ-አመላካች ብድሮችን ለመፍጠር async/await futures የማይነቃነቅ በመሆናቸው ላይ እንመካለን ፡፡
    //
    impl<T: Generator<ResumeTy, Yield = ()>> !Unpin for GenFuture<T> {}

    impl<T: Generator<ResumeTy, Yield = ()>> Future for GenFuture<T> {
        type Output = T::Return;
        fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
            // ደህንነት እኛ ደህና ነን ምክንያቱም እኛ !Unpin + !Drop ስለሆንን ይህ የመስክ ትንበያ ብቻ ነው ፡፡
            let gen = unsafe { Pin::map_unchecked_mut(self, |s| &mut s.0) };

            // አንድ `NonNull` ጥሬ ጠቋሚ ወደ `&mut Context` ዘወር ማመንጫው ከቆመበት ቀጥል.
            // የ `.await` በደህንነት አንድ `&mut Context` በዚያ ኋላ እጥላለሁ ይዘንባል.
            match gen.resume(ResumeTy(NonNull::from(cx).cast::<Context<'static>>())) {
                GeneratorState::Yielded(()) => Poll::Pending,
                GeneratorState::Complete(x) => Poll::Ready(x),
            }
        }
    }

    GenFuture(gen)
}

#[lang = "get_context"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub unsafe fn get_context<'a, 'b>(cx: ResumeTy) -> &'a mut Context<'b> {
    // ደህንነት-ደዋዩ `cx.0` ትክክለኛ ጠቋሚ መሆኑን ማረጋገጥ አለበት
    // ለሚለዋወጥ ማጣቀሻ ሁሉንም መስፈርቶች የሚያሟላ።
    unsafe { &mut *cx.0.as_ptr().cast() }
}