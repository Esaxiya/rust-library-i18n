#![stable(feature = "futures_api", since = "1.36.0")]

use crate::marker::Unpin;
use crate::ops;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// አንድ future አንድ አልተመሳሰል ስሌት ይወክላል.
///
/// future ገና ስሌቱን ያልጨረሰ እሴት ነው።
/// የዚህ ዓይነቱ "asynchronous value" እሴቱ እስኪገኝ በሚጠብቅበት ጊዜ አንድ ክር ጠቃሚ ሥራ መሥራቱን እንዲቀጥል ያደርገዋል ፡፡
///
///
/// # የ `poll` ዘዴ
///
/// የ future ፣ `poll` ፣*ሙከራዎች* future ን ወደ መጨረሻ እሴት ለመፍታት።
/// ዋጋ ዝግጁ አይደለም ከሆነ ይህ ዘዴ ማገድ አይደለም.
/// ይልቅ, የአሁኑ ተግባር እንደገና poll`ing`ተጨማሪ እድገት ማድረግ ይቻላል ጊዜ እስከ woken ዘንድ ተይዞለታል.
/// ወደ `poll` ዘዴ የተላለፈው `context` የአሁኑን ሥራ ከእንቅልፍ ለመነሳት እጀታ ያለው [`Waker`] ሊያቀርብ ይችላል።
///
/// አንድ future በመጠቀም ጊዜ, በአጠቃላይ በቀጥታ `poll` መደወል አይችልም, ነገር ግን በምትኩ `.await` ዋጋ.
///
/// [`Waker`]: crate::task::Waker
///
///
///
#[doc(spotlight)]
#[must_use = "futures do nothing unless you `.await` or poll them"]
#[stable(feature = "futures_api", since = "1.36.0")]
#[lang = "future_trait"]
#[rustc_on_unimplemented(label = "`{Self}` is not a future", message = "`{Self}` is not a future")]
pub trait Future {
    /// በማጠናቀቅ ላይ የሚመረተው ዋጋ ዓይነት።
    #[stable(feature = "futures_api", since = "1.36.0")]
    type Output;

    /// ዋጋ ገና አይገኝም ከሆነ ማስነሻ ለማግኘት የአሁኑ ተግባር በመመዝገብ, የመጨረሻ እሴት ወደ future ለመፍታት መሞከር.
    ///
    /// # ተመለስ እሴት
    ///
    /// ይህ ተግባር ይመለሳል
    ///
    /// - [`Poll::Pending`] የ future ገና ዝግጁ አይደለም ከሆነ
    /// - [`Poll::Ready(val)`] ውጤት ጋር ይህን future ውስጥ `val` ይህም በተሳካ ሁኔታ ተጠናቅቋል ከሆነ.
    ///
    /// አንዴ future ከጨረሰ በኋላ ደንበኞች እንደገና `poll` ማድረግ የለባቸውም።
    ///
    /// አንድ future ገና ዝግጁ ባልሆነ ጊዜ `poll` `Poll::Pending` ን ይመልሳል እና ከአሁኑ [`Context`] የተቀዳ የ [`Waker`] አንድ ክሎንን ያከማቻል።
    /// future መሻሻል ማድረግ ከቻለ ይህ [`Waker`] ከዚያ ከእንቅልፉ ይነሳል።
    /// ለምሳሌ ፣ አንድ ሶኬት የሚነበብ እስኪሆን ድረስ የሚጠብቅ future በ [`Waker`] ላይ `.clone()` ን ይደውልና ያከማቻል ፡፡
    /// ምልክት በሌላ ሶኬት የሚነበብ መሆኑን የሚያመላክት ሲደርስ, [`Waker::wake`] ይባላል እና መሰኪያዎችም future ተግባር awoken ነው.
    /// አንዴ ሥራ ከእንቅልፉ ከተነሳ በኋላ የመጨረሻ ዋጋን ሊያመጣ ወይም ላያመጣ የሚችል እንደገና 0X the Z0future ን መሞከር አለበት ፡፡
    ///
    /// `poll` ወደ በርካታ ጥሪዎች ላይ ብቻ [`Context`] ጀምሮ [`Waker`] በጣም የቅርብ ጊዜ ጥሪ አለፈ መሆኑን ማስታወሻ አንድ ማስነሻ ለመቀበል ቀጠሮ መሆን አለበት.
    ///
    /// # የአሂድ ጊዜ ባህሪዎች
    ///
    /// Futures ብቻ *ሲያፈርስና ናቸው*;መሻሻል ለማድረግ *በንቃት* መሆን አለባቸው ፣ ይህም ማለት አሁን ያለው ተግባር ከእንቅልፉ በተነሳ ቁጥር አሁንም ፍላጎት ያለው futures ን በመጠባበቅ እንደገና `መበከል አለበት` ፡፡
    ///
    /// የ `poll` ተግባር በአንድ በጠባብ ምልልስ ውስጥ በተደጋጋሚ ተብሎ አይደለም-ይልቁንስ ብቻ ተብሎ ያለበት የ future ይህ `wake()`) በመደወል (እድገት ለማድረግ ዝግጁ መሆኑን ይጠቁማል ጊዜ.
    /// በ Unix ላይ የ `poll(2)` ወይም `select(2)` ሲሳይሎችን በደንብ የሚያውቁ ከሆነ futures በተለምዶ የ "all wakeups must poll all events" ተመሳሳይ ችግሮች *አያጋጥማቸውም* የሚለውን ልብ ማለት ይገባል ፡፡እነርሱ `epoll(4)` እንደ ተጨማሪ ናቸው.
    ///
    /// የ `poll` ትግበራ በፍጥነት ለመመለስ መጣር አለበት ፣ እና ማገድ የለበትም።በፍጥነት መመለስ አላስፈላጊ ክሮች ወይም የዝግጅት ቀለበቶችን ከመዝጋት ይከላከላል ፡፡
    /// ይህም ወደፊት `poll` አንድ ጥሪ ትንሽ በመውሰድ እስከ መጨረሻው እንደሚችል ጊዜ የሚታወቅ ከሆነ, ሥራ `poll` በፍጥነት መመለስ እንደሚችሉ ለማረጋገጥ አንድ ክር ገንዳ (ወይም ተመሳሳይ የሆነ ነገር) ወደ offloaded አለበት.
    ///
    /// # Panics
    ///
    /// አንድ future እንደተጠናቀቀ በመጥራት, (`poll` ከ `Ready` ተመልሶ) በውስጡ `poll` ዘዴ እንደገና ይሆናል panic, ያግዳል ለዘላለም, ወይም ችግሮች ሌላ ዓይነት ምክንያት;`Future` trait በእንደዚህ ዓይነት ጥሪ ውጤቶች ላይ ምንም መስፈርቶች አያስቀምጡም ፡፡
    /// የ `poll` ስልት `unsafe` ምልክት አይደለም እንደ ይሁን እንጂ, Rust ዎቹ እንደተለመደው ደንቦች ተግባራዊ: ጥሪዎች ምንም future ያለውን ሁኔታ, ያልተገለጸ ባህሪ (ትውስታ ሙስና, `unsafe` ተግባራት መካከል ትክክል ያልሆነ አጠቃቀም, ወይም እንደ) ሊያስከትል ፈጽሞ አለባቸው.
    ///
    ///
    /// [`Poll::Ready(val)`]: Poll::Ready
    /// [`Waker`]: crate::task::Waker
    /// [`Waker::wake`]: crate::task::Waker::wake
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[lang = "poll"]
    #[stable(feature = "futures_api", since = "1.36.0")]
    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output>;
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<F: ?Sized + Future + Unpin> Future for &mut F {
    type Output = F::Output;

    fn poll(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        F::poll(Pin::new(&mut **self), cx)
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<P> Future for Pin<P>
where
    P: Unpin + ops::DerefMut<Target: Future>,
{
    type Output = <<P as ops::Deref>::Target as Future>::Output;

    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        Pin::get_mut(self).as_mut().poll(cx)
    }
}