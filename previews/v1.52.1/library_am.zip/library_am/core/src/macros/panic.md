Panics የአሁኑን ክር።

ይህ ፕሮግራም ወዲያውኑ ለማቋረጥ እና የፕሮግራሙ ደዋዩ ግብረመልስ እንዲያቀርቡ ያስችልዎታል.
`panic!` አንድ ፕሮግራም የማይተረም ሁኔታ ሲደርስ ላይ መዋል አለበት.

ይህ ማክሮ በምሳሌ ኮድ እና በሙከራዎች ውስጥ ሁኔታዎችን ለማረጋገጥ ፍጹም መንገድ ነው ፡፡
`panic!` በቅርብ ሁለቱም [`Option`][ounwrap] እና [`Result`][runwrap] enums መካከል `unwrap` ዘዴ ጋር የተሳሰረ ነው.
እነርሱ [`None`] ወይም [`Err`] የምርጫዎች ከተዋቀረ ጊዜ ሁለቱም ማስፈጸሚያዎች `panic!` ይደውሉ.

`panic!()` በመጠቀም ጊዜ የ [`format!`] አገባብ በመጠቀም ነው የተገነባው ሕብረቁምፊ የክፍያ, መጥቀስ ይችላሉ.
ወደ ጥሪ Rust ክር ወደ panic መርፌ ሙሉ በሙሉ panic ወደ ክር እንዲፈጠር ጊዜ ይህ የክፍያ የዋለበት ነው.

የነባሪው `std` hook ባህሪ ፣ ማለትም
የ panic ሲጠራ ነው በቀጥታ በኋላ ይሰራል ኮድ, የ `panic!()` ጥሪ file/line/column መረጃ ጋር `stderr` መልእክቱን ወደ የክፍያ ለማተም ነው.

የ [`std::panic::set_hook()`] በመጠቀም panic hook መሻር ይችላሉ.
የ hook ከውስጥ አንድ panic መደበኛ `panic!()` ካልደጋገሙ ለ ወይ አንድ `&str` ወይም `String` የያዘ አንድ `&dyn Any + Send`, እንደ ሊደረስባቸው ይችላል.
ሌላ ሌላ አይነት ዋጋ ጋር panic ወደ [`panic_any`] ጥቅም ላይ ሊውል ይችላል.

[`Result`] enum ብዙውን ጊዜ `panic!` ማክሮ ከመጠቀም ይልቅ ስህተቶች በማገገም የተሻለ መፍትሔ ነው.
ይህ ማክሮ እንደ ውጫዊ ምንጮች ያሉ የተሳሳቱ እሴቶችን በመጠቀም ላለመቀጠል ጥቅም ላይ መዋል አለበት።
የስህተት አያያዝ በተመለከተ ዝርዝር መረጃ [book] ውስጥ ይገኛል.

በማጠናቀር ጊዜ ስህተቶችን ለማሳደግ ማክሮ [`compile_error!`] ን ይመልከቱ ፡፡

[ounwrap]: Option::unwrap
[runwrap]: Result::unwrap
[`std::panic::set_hook()`]: ../std/panic/fn.set_hook.html
[`panic_any`]: ../std/panic/fn.panic_any.html
[`Box`]: ../std/boxed/struct.Box.html
[`Any`]: crate::any::Any
[`format!`]: ../std/macro.format.html
[book]: ../book/ch09-00-error-handling.html

# የአሁኑ ትግበራ

ዋናው ክር ከሆነ panics, ሁሉም ክሮች ለማቋረጥ እና ኮድ `101` ጋር የእርስዎን ፕሮግራም ያበቃል.

# Examples

```should_panic
# #![allow(unreachable_code)]
panic!();
panic!("this is a terrible mistake!");
panic!("this is a {} {message}", "fancy", message = "message");
std::panic::panic_any(4); // panic with the value of 4 to be collected elsewhere
```





