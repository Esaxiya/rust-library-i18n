#[doc = include_str!("panic.md")]
#[macro_export]
#[rustc_builtin_macro = "core_panic"]
#[allow_internal_unstable(edition_panic)]
#[stable(feature = "core", since = "1.6.0")]
#[rustc_diagnostic_item = "core_panic_macro"]
macro_rules! panic {
    // የደዋዩን እትም ላይ የሚወሰን `$crate::panic::panic_2015` ወይም `$crate::panic::panic_2021` ወይ ወደ እያደገ ሄደ.
    //
    ($($arg:tt)*) => {
        /* compiler built-in */
    };
}

/// ሁለት መግለጫዎች ([`PartialEq`] በመጠቀም) እርስ በርስ እኩል መሆናቸውን ያስረግጣል.
///
/// በ panic ላይ ይህ ማክሮ የመግለጫዎቹን እሴቶች ከድካሞቻቸው ውክልናዎች ጋር ያትማል።
///
///
/// ልክ እንደ [`assert!`] ፣ ይህ ማክሮ ብጁ የ panic መልእክት ሊቀርብ የሚችልበት ሁለተኛ ቅጽ አለው ፡፡
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// assert_eq!(a, b);
///
/// assert_eq!(a, b, "we are testing addition with {} and {}", a, b);
/// ```
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_eq {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // ከዚህ በታች ያለው reborrows ሆን ናቸው.
                    // እነሱ ባይኖሩ ቢዋስ ለማግኘት የቁልል ማስገቢያ አንድ የሚታይ የዘገየ ታች ወደ እየመራ, እሴቶች ጋር ሲነጻጸር እንኳ በፊት አልተነሳም ነው.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // ከዚህ በታች ያለው reborrows ሆን ናቸው.
                    // እነሱ ባይኖሩ ቢዋስ ለማግኘት የቁልል ማስገቢያ አንድ የሚታይ የዘገየ ታች ወደ እየመራ, እሴቶች ጋር ሲነጻጸር እንኳ በፊት አልተነሳም ነው.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// ሁለት መግለጫዎች ([`PartialEq`] በመጠቀም) እርስ በርስ እኩል አይደሉም መሆኑን ያስረግጣል.
///
/// በ panic ላይ ይህ ማክሮ የመግለጫዎቹን እሴቶች ከድካሞቻቸው ውክልናዎች ጋር ያትማል።
///
///
/// ልክ እንደ [`assert!`] ፣ ይህ ማክሮ ብጁ የ panic መልእክት ሊቀርብ የሚችልበት ሁለተኛ ቅጽ አለው ፡፡
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// assert_ne!(a, b);
///
/// assert_ne!(a, b, "we are testing that the values are not equal");
/// ```
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_ne {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // ከዚህ በታች ያለው reborrows ሆን ናቸው.
                    // እነሱ ባይኖሩ ቢዋስ ለማግኘት የቁልል ማስገቢያ አንድ የሚታይ የዘገየ ታች ወደ እየመራ, እሴቶች ጋር ሲነጻጸር እንኳ በፊት አልተነሳም ነው.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&($left), &($right)) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // ከዚህ በታች ያለው reborrows ሆን ናቸው.
                    // እነሱ ባይኖሩ ቢዋስ ለማግኘት የቁልል ማስገቢያ አንድ የሚታይ የዘገየ ታች ወደ እየመራ, እሴቶች ጋር ሲነጻጸር እንኳ በፊት አልተነሳም ነው.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// የቡሊያን አገላለጽ በወቅቱ በሚሆንበት ጊዜ `true` መሆኑን ያረጋግጣል።
///
/// የቀረበው መግለጫ የሚፈጀውን ላይ `true` ተገምግመዋል አይችልም ከሆነ ይህ [`panic!`] ማክሮ ይጥሩ ይሆናል.
///
/// [`assert!`] ልክ እንደ ይህ ማክሮ ደግሞ አንድ ብጁ panic መልእክት ሊቀርብ በሚችልበት ሁለተኛ ስሪት አለው.
///
/// # Uses
///
/// [`assert!`] በተለየ `debug_assert!` መግለጫዎች ብቻ ነው የተመቻቸው ያልሆኑ በነባሪነት ይገነባል ነቅተዋል.
/// `-C debug-assertions` ወደ አጠናቀሪው ካልተላለፈ በስተቀር የተመቻቸ ግንባታ የ `debug_assert!` መግለጫዎችን አያስፈጽምም።
/// ይህ ከእስር ግንባታን ውስጥ መገኘት በጣም ውድ ናቸው እንጂ ልማት ወቅት ጠቃሚ ሊሆን ይችላል ቼኮች ለ `debug_assert!` ጠቃሚ ያደርገዋል.
/// `debug_assert!` በማስፋፋት ውጤት ሁልጊዜ ምልክት የተደረገባቸው ዓይነት ነው.
///
/// አንድ ካልተደረገበት አቋምዎን ያልተጠበቀ ውጤት ሊኖራቸው ይችላል ነገር ግን እንደ ረጅም ይህ ብቻ አስተማማኝ ኮድ ውስጥ እንደተከሰተ unsafety ለማስተዋወቅ አይደለም; ይህም እየሮጠ ለመቀጠል ወጥ በሆነ ሁኔታ ውስጥ ያለ ፕሮግራም ይፈቅዳል.
///
/// የማረጋገጫ አፈፃፀም ዋጋ ግን በአጠቃላይ ሊለካ የሚችል አይደለም ፡፡
/// [`assert!`] ን በ `debug_assert!` መተካት የተሟላ ጥናት ከተደረገ በኋላ ብቻ ይበረታታል ፣ እና ከሁሉም በላይ ደግሞ በደህንነት ኮድ ውስጥ ብቻ ነው!
///
/// # Examples
///
/// ```
/// // እነዚህ ከተናገሯቸው ለ panic መልእክት የተሰጠው መግለጫ ያለውን stringified ዋጋ ነው.
/////
/// debug_assert!(true);
///
/// fn some_expensive_computation() -> bool { true } // በጣም ቀላል ተግባር
/// debug_assert!(some_expensive_computation());
///
/// // ብጁ መልዕክት ጋር ስለመሆንዎ
/// let x = true;
/// debug_assert!(x, "x wasn't true!");
///
/// let a = 3; let b = 27;
/// debug_assert!(a + b == 30, "a = {}, b = {}", a, b);
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "debug_assert_macro"]
macro_rules! debug_assert {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert!($($arg)*); })
}

/// ሁለት መግለጫዎች እርስ በርስ እኩል መሆናቸውን ያስረግጣል.
///
/// በ panic ላይ ይህ ማክሮ የመግለጫዎቹን እሴቶች ከድካሞቻቸው ውክልናዎች ጋር ያትማል።
///
/// [`assert_eq!`] በተለየ `debug_assert_eq!` መግለጫዎች ብቻ ነው የተመቻቸው ያልሆኑ በነባሪነት ይገነባል ነቅተዋል.
/// `-C debug-assertions` ወደ አጠናቃሪ በሚተላለፍ በስተቀር አንድ የተመቻቹ ግንባታ `debug_assert_eq!` መግለጫዎች ያስፈጽማል አይደለም.
/// ይህ ከእስር ግንባታን ውስጥ መገኘት በጣም ውድ ናቸው እንጂ ልማት ወቅት ጠቃሚ ሊሆን ይችላል ቼኮች ለ `debug_assert_eq!` ጠቃሚ ያደርገዋል.
///
/// `debug_assert_eq!` በማስፋፋት ውጤት ሁልጊዜ ምልክት የተደረገባቸው ዓይነት ነው.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// debug_assert_eq!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! debug_assert_eq {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_eq!($($arg)*); })
}

/// ሁለት መግለጫዎች እርስ በርስ እኩል አይደሉም መሆኑን ያስረግጣል.
///
/// በ panic ላይ ይህ ማክሮ የመግለጫዎቹን እሴቶች ከድካሞቻቸው ውክልናዎች ጋር ያትማል።
///
/// ከኤክስኤክስኤክስክስክስክስክስክስክስክስክስክስክስክስክስክስክስክስክስክስክስክስክስክስክስክስክስኤክስኤክስኤክስክስክስክስክስክስክስክስክስክስክስክስክስክስክስክስክስክስክስክስክስክስክስክስክስክስክስክስክስክስክስክስክስክስክስክስክስክስክስክስክስኤክስኤክስኤክስኤክስክስክስክስክስክስክስክስክስክስ) በተለየ መልኩ በነባሪ በተመቻቹ ግንባታዎች ውስጥ ብቻ ነቅቷል ፡፡
/// `-C debug-assertions` ወደ አጠናቀሪው ካልተላለፈ በስተቀር የተመቻቸ ግንባታ የ `debug_assert_ne!` መግለጫዎችን አያስፈጽምም።
/// ይህ በመለቀቂያ ግንባታ ውስጥ ለመገኘታቸው በጣም ውድ ለሆኑ ቼኮች `debug_assert_ne!` ጠቃሚ ያደርገዋል ፣ ግን በእድገቱ ወቅት ጠቃሚ ሊሆን ይችላል ፡፡
///
/// `debug_assert_ne!` በማስፋፋት ውጤት ሁልጊዜ ምልክት የተደረገባቸው ዓይነት ነው.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// debug_assert_ne!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
macro_rules! debug_assert_ne {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_ne!($($arg)*); })
}

/// የተሰጠው መግለጫ የተሰጠውን ስርዓተ ማንኛውም ጋር የሚዛመድ እንደሆነ ይመልሳል.
///
/// አንድ `match` አገላለጽ ውስጥ እንደ ምሳሌ አማራጭ `if` እና ንድፍ ለመገዛት ስሞች መዳረሻ ያለው ጠባቂ አገላለጽ ሊከተል ይችላል.
///
///
/// # Examples
///
/// ```
/// let foo = 'f';
/// assert!(matches!(foo, 'A'..='Z' | 'a'..='z'));
///
/// let bar = Some(4);
/// assert!(matches!(bar, Some(x) if x > 2));
/// ```
#[macro_export]
#[stable(feature = "matches_macro", since = "1.42.0")]
macro_rules! matches {
    ($expression:expr, $( $pattern:pat )|+ $( if $guard: expr )? $(,)?) => {
        match $expression {
            $( $pattern )|+ $( if $guard )? => true,
            _ => false
        }
    }
}

/// ውጤቱን ይከፍታል ወይም ስህተቱን ያስፋፋል።
///
/// የ `?` ከዋኝ `try!` ለመተካት ታክሏል በምትኩ ላይ መዋል አለበት.
/// እርስዎ ሊጠቀሙበት ይገባል ከሆነ, የ [raw-identifier syntax][ris] መጠቀም ያስፈልግዎታል ስለዚህ ከዚህም `try` Rust በ 2018 የተያዘ ቃል ነው: `r#try`.
///
///
/// [ris]: https://doc.rust-lang.org/nightly/rust-by-example/compatibility/raw_identifiers.html
///
/// `try!` የተሰጠው [`Result`] ጋር ይዛመዳል.የ `Ok` ልዩነት ቢኖር ፣ አገላለጹ የተጠቀለለው እሴት ዋጋ አለው።
///
/// የ `Err` ልዩነት ቢኖር ውስጣዊ ስህተቱን ያወጣል።`try!` ከዚያም `From` በመጠቀም ልወጣ ያከናውናል.
/// ይህ በልዩ ስህተቶች እና በበለጠ አጠቃላይ ስህተቶች መካከል በራስ-ሰር መለወጥን ይሰጣል።
/// በ ምክንያት ስህተት ከዚያም ወዲያውኑ ተመልሶ ነው.
///
/// ቀደም ሲል በመመለሱ ምክንያት `try!` ጥቅም ላይ ሊውል የሚችለው [`Result`] ን ለሚመልሱ ተግባራት ብቻ ነው።
///
/// # Examples
///
/// ```
/// use std::io;
/// use std::fs::File;
/// use std::io::prelude::*;
///
/// enum MyError {
///     FileWriteError
/// }
///
/// impl From<io::Error> for MyError {
///     fn from(e: io::Error) -> MyError {
///         MyError::FileWriteError
///     }
/// }
///
/// // ፈጣን መመለስ ስህተቶች ያለው ተመራጭ ዘዴ
/// fn write_to_file_question() -> Result<(), MyError> {
///     let mut file = File::create("my_best_friends.txt")?;
///     file.write_all(b"This is a list of my best friends.")?;
///     Ok(())
/// }
///
/// // ፈጣን መመለስ ስህተቶች መካከል ቀዳሚውን ስልት
/// fn write_to_file_using_try() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     r#try!(file.write_all(b"This is a list of my best friends."));
///     Ok(())
/// }
///
/// // ይህ ጋር አቻ ነው:
/// fn write_to_file_using_match() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     match file.write_all(b"This is a list of my best friends.") {
///         Ok(v) => v,
///         Err(e) => return Err(From::from(e)),
///     }
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "1.39.0", reason = "use the `?` operator instead")]
#[doc(alias = "?")]
macro_rules! r#try {
    ($expr:expr $(,)?) => {
        match $expr {
            $crate::result::Result::Ok(val) => val,
            $crate::result::Result::Err(err) => {
                return $crate::result::Result::Err($crate::convert::From::from(err));
            }
        }
    };
}

/// አንድ ቋጥ ወደ ቅርጸት ውሂብ ይጽፋል.
///
/// ይህ ማክሮ አንድ 'writer' ፣ የቅርጸት ሕብረቁምፊ እና የክርክር ዝርዝርን ይቀበላል።
/// ክርክሮች በተጠቀሰው የቅርጸት ገመድ መሠረት ይቀረፃሉ ውጤቱም ወደ ጸሐፊው ይተላለፋል ፡፡
/// ጸሐፊው በ `write_fmt` ዘዴ ማንኛውም እሴት ሊሆን ይችላል;በአጠቃላይ ይህ [`fmt::Write`] ወይም [`io::Write`] trait አንድም የሆነ አፈፃፀም የሚመጣው.
/// ማክሮው የ `write_fmt` ዘዴ የሚመልሰውን ሁሉ ይመልሳል ፤በተለምዶ አንድ [`fmt::Result`], ወይም [`io::Result`].
///
/// ቅርጸት ሕብረቁምፊ አገባብ ላይ ተጨማሪ መረጃ ለማግኘት [`std::fmt`] ይመልከቱ.
///
/// [`std::fmt`]: ../std/fmt/index.html
/// [`fmt::Write`]: crate::fmt::Write
/// [`io::Write`]: ../std/io/trait.Write.html
/// [`fmt::Result`]: crate::fmt::Result
/// [`io::Result`]: ../std/io/type.Result.html
///
/// # Examples
///
/// ```
/// use std::io::Write;
///
/// fn main() -> std::io::Result<()> {
///     let mut w = Vec::new();
///     write!(&mut w, "test")?;
///     write!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(w, b"testformatted arguments");
///     Ok(())
/// }
/// ```
///
/// ነገሮች በተለምዶ ሁለቱም መተግበር እንጂ እንደ አንድ ሞዱል, ወይ ተግባራዊ ነገሮች ላይ `std::fmt::Write` እና `std::io::Write` እና ጥሪ `write!` ሁለቱም ማስመጣት ይችላሉ.
///
/// ይሁን እንጂ, በ traits ማስመጣት አለበት ሞዱል ስማቸውን ግጭት አይደለም ማድረግ እንዲሁ ብቃት:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     write!(&mut s, "{} {}", "abc", 123)?; // fmt::Write::write_fmt ን ይጠቀማል
///     write!(&mut v, "s = {:?}", s)?; // io::Write::write_fmt ይጠቀማል
///     assert_eq!(v, b"s = \"abc 123\"");
///     Ok(())
/// }
/// ```
///
/// Note: ይህ ማክሮ በ `no_std` ማዋቀሮች ውስጥም ሊያገለግል ይችላል ፡፡
/// አንድ `no_std` ማዋቀር ውስጥ የ ክፍሎች ትግበራ ዝርዝሮች ተጠያቂ ናቸው.
///
/// ```no_run
/// # extern crate core;
/// use core::fmt::Write;
///
/// struct Example;
///
/// impl Write for Example {
///     fn write_str(&mut self, _s: &str) -> core::fmt::Result {
///          unimplemented!();
///     }
/// }
///
/// let mut m = Example{};
/// write!(&mut m, "Hello World").expect("Not written");
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! write {
    ($dst:expr, $($arg:tt)*) => ($dst.write_fmt($crate::format_args!($($arg)*)))
}

/// በአዲሱ መስመር ተጨምረው ቅርጸት የተሰራውን መረጃ ወደ ቋት ይጻፉ።
///
/// በሁሉም መድረኮች ላይ, NEWLINE ብቻ መስመር FEED ገጸ (`\n`/`U+000A`) (ምንም ተጨማሪ ሰረገላ ይመለስ (`\r`/`U+000D`) ነው.
///
/// ተጨማሪ መረጃ ለማግኘት, [`write!`] ተመልከት.ቅርጸት ሕብረቁምፊ አገባብ ላይ መረጃ ለማግኘት, [`std::fmt`] ተመልከት.
///
/// [`std::fmt`]: ../std/fmt/index.html
///
/// # Examples
///
/// ```
/// use std::io::{Write, Result};
///
/// fn main() -> Result<()> {
///     let mut w = Vec::new();
///     writeln!(&mut w)?;
///     writeln!(&mut w, "test")?;
///     writeln!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(&w[..], "\ntest\nformatted arguments\n".as_bytes());
///     Ok(())
/// }
/// ```
///
/// ነገሮች በተለምዶ ሁለቱም መተግበር እንጂ እንደ አንድ ሞዱል, ወይ ተግባራዊ ነገሮች ላይ `std::fmt::Write` እና `std::io::Write` እና ጥሪ `write!` ሁለቱም ማስመጣት ይችላሉ.
/// ይሁን እንጂ, በ traits ማስመጣት አለበት ሞዱል ስማቸውን ግጭት አይደለም ማድረግ እንዲሁ ብቃት:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     writeln!(&mut s, "{} {}", "abc", 123)?; // fmt::Write::write_fmt ን ይጠቀማል
///     writeln!(&mut v, "s = {:?}", s)?; // io::Write::write_fmt ይጠቀማል
///     assert_eq!(v, b"s = \"abc 123\\n\"\n");
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(format_args_nl)]
macro_rules! writeln {
    ($dst:expr $(,)?) => (
        $crate::write!($dst, "\n")
    );
    ($dst:expr, $($arg:tt)*) => (
        $dst.write_fmt($crate::format_args_nl!($($arg)*))
    );
}

/// አይደረስበትም ኮድ ያመለክታል.
///
/// ይህ አጠናቃሪ አንዳንድ ኮድ ሳይደረስበት መሆኑን ለመወሰን አይችልም በማንኛውም ጊዜ ጠቃሚ ነው.ለምሳሌ:
///
/// * ጠባቂ ሁኔታዎች ጋር የጦር አዛምድ.
/// * ቀለበቶች ይህ ዳይናሚክ እናቋርጣለን.
/// * ተለዋዋጭ የሚያቋርጡ ተቃዋሚዎች።
///
/// ኮዱ ሊደረስበት የማይቻልበት ውሳኔ የተሳሳተ ሆኖ ከተገኘ ፕሮግራሙ ወዲያውኑ በ [`panic!`] ይቋረጣል።
///
/// የዚህ ማክሮ ያለው ያልተጠበቀ አቻ ኮድ ደርሷል ከሆነ ያልተገለጸ ባህሪ ያስከትላል ይህም [`unreachable_unchecked`] ተግባር ነው.
///
///
/// [`unreachable_unchecked`]: crate::hint::unreachable_unchecked
///
/// # Panics
///
/// ይህ ሁልጊዜ [`panic!`] ይሆናል።
///
/// # Examples
///
/// የጦር አዛምድ:
///
/// ```
/// # #[allow(dead_code)]
/// fn foo(x: Option<i32>) {
///     match x {
///         Some(n) if n >= 0 => println!("Some(Non-negative)"),
///         Some(n) if n <  0 => println!("Some(Negative)"),
///         Some(_)           => unreachable!(), // አስተያየት ከተሰጠ ስህተትን ያጠናቅሩ
///         None              => println!("None")
///     }
/// }
/// ```
///
/// Iterators:
///
/// ```
/// # #[allow(dead_code)]
/// fn divide_by_three(x: u32) -> u32 { // ከ‹x/3 X›በጣም ትግበራዎች አንዱ
///     for i in 0.. {
///         if 3*i < i { panic!("u32 overflow"); }
///         if x < 3*i { return i-1; }
///     }
///     unreachable!();
/// }
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unreachable {
    () => ({
        $crate::panic!("internal error: entered unreachable code")
    });
    ($msg:expr $(,)?) => ({
        $crate::unreachable!("{}", $msg)
    });
    ($fmt:expr, $($arg:tt)*) => ({
        $crate::panic!($crate::concat!("internal error: entered unreachable code: ", $fmt), $($arg)*)
    });
}

/// "not implemented" አንድ መልእክት ጋር ሳልገባ በማድረግ unimplemented ኮድ ያመለክታል.
///
/// ይህ ኮድዎን ለመተየብ ይፈቅድለታል ፣ ይህም ሁሉንም ለመጠቀም የማይፈልጉትን በርካታ ዘዴዎችን የሚፈልግ trait ን እየወሰዱ ከሆነ ወይም ተግባራዊ ካደረጉ ጠቃሚ ነው።
///
/// `unimplemented!` እና [`todo!`] መካከል ያለው ልዩነት `todo!` በኋላ ተግባራዊነት ተግባራዊ የሆነ ሐሳብ ያስተላልፋል እና መልእክት "not yet implemented" ነው ሳለ, `unimplemented!` እንዲህ ያለ የይገባኛል የሚያደርገው ነው.
/// የእሱ መልእክት "not implemented" ነው።
/// እንዲሁም አንዳንድ IDEs `todo!` S ምልክት ያደርጉባቸዋል
///
/// # Panics
///
/// ይህ ፈቃድ ሁልጊዜ [`panic!`] `unimplemented!` አንድ ቋሚ, የተወሰነ መልእክት ጋር `panic!` ለ ብቻ በሚጽፉ ስለሆነ.
///
/// እንደ `panic!` ሁሉ ይህ ማክሮ ብጁ እሴቶችን ለማሳየት ሁለተኛ ቅጽ አለው ፡፡
///
/// # Examples
///
/// እኛ trait `Foo` አለን ይላሉ:
///
/// ```
/// trait Foo {
///     fn bar(&self) -> u8;
///     fn baz(&self);
///     fn qux(&self) -> Result<u64, ()>;
/// }
/// ```
///
/// እኛ 'MyStruct' ለ `Foo` ተግባራዊ ለማድረግ ይፈልጋሉ, ነገር ግን በሆነ ምክንያት ብቻ `bar()` ተግባር መተግበር ትርጉም ይሰጣል.
/// `baz()` እና `qux()` አሁንም `Foo` የእኛን አፈጻጸም ውስጥ ሊገለጹ ያስፈልግዎታል, ነገር ግን እኛ ኮድ ለማጠናቀር ለመፍቀድ ያላቸውን ትርጓሜዎች ውስጥ `unimplemented!` መጠቀም ይችላሉ.
///
/// እኛ አሁንም unimplemented ዘዴዎች ደርሰዋል ከሆነ የእኛን ፕሮግራም ማቆሚያ ሩጫ እንዲኖራቸው ይፈልጋሉ.
///
/// ```
/// # trait Foo {
/// #     fn bar(&self) -> u8;
/// #     fn baz(&self);
/// #     fn qux(&self) -> Result<u64, ()>;
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) -> u8 {
///         1 + 1
///     }
///
///     fn baz(&self) {
///         // ለ `baz` a `MyStruct` ምንም ትርጉም የለውም ፣ ስለሆነም እዚህ በጭራሽ ምንም አመክንዮ የለንም ፡፡
/////
///         // ይህ "thread 'main' panicked at 'not implemented'" ያሳያል።
///         unimplemented!();
///     }
///
///     fn qux(&self) -> Result<u64, ()> {
///         // እኛ እኛ unimplemented አንድ መልዕክት ማከል ይችላሉ, እዚህ ላይ አንዳንድ ሎጂክ አለን!ግድፈታችንን ለማሳየት ፡፡
///         // ይህ ያሳያል: "thread 'main' panicked at 'not implemented: MyStruct isn't quxable'".
/////
/////
///         unimplemented!("MyStruct isn't quxable");
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
/// }
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unimplemented {
    () => ($crate::panic!("not implemented"));
    ($($arg:tt)+) => ($crate::panic!("not implemented: {}", $crate::format_args!($($arg)+)));
}

/// ያልተጠናቀቀ ኮድ ያሳያል።
///
/// አንተ በፕሮቶታይፕ እና ብቻ ኮድ typecheck እንዲኖራቸው እየፈለጉ ከሆነ ይህ ጠቃሚ ሊሆን ይችላል.
///
/// [`unimplemented!`] እና `todo!` መካከል ያለው ልዩነት `todo!` በኋላ ተግባራዊነት ተግባራዊ የሆነ ሐሳብ ያስተላልፋል እና መልእክት "not yet implemented" ነው ሳለ, `unimplemented!` እንዲህ ያለ የይገባኛል የሚያደርገው ነው.
/// የእሱ መልእክት "not implemented" ነው።
/// እንዲሁም አንዳንድ IDEs `todo!` S ምልክት ያደርጉባቸዋል
///
/// # Panics
///
/// ይህ ሁልጊዜ [`panic!`] ይሆናል።
///
/// # Examples
///
/// እዚህ አንዳንድ ውስጥ-እድገት ኮድ የሚያሳይ ምሳሌ ነው.እኛ አንድ trait `Foo` አለን:
///
/// ```
/// trait Foo {
///     fn bar(&self);
///     fn baz(&self);
/// }
/// ```
///
/// እኛ አይነቶች በአንዱ ላይ `Foo` ለመተግበር እንፈልጋለን, ነገር ግን እኛ ደግሞ በመጀመሪያ ብቻ `bar()` ላይ ሥራ እፈልጋለሁ.ኮዳችን ለማጠናቀር `baz()` ን መተግበር ያስፈልገናል ፣ ስለሆነም `todo!` ን መጠቀም እንችላለን
///
/// ```
/// # trait Foo {
/// #     fn bar(&self);
/// #     fn baz(&self);
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) {
///         // ትግበራ ወደዚህ ይሄዳል
///     }
///
///     fn baz(&self) {
///         // አሁን ለ baz() ተግባራዊ አትጨነቅ እናድርግ
///         todo!();
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
///
///     // እኛ እንኳ baz() እየተጠቀሙ አይደለም, ስለዚህ ይህ ጥሩ ነው.
/// }
/// ```
///
///
///
///
#[macro_export]
#[stable(feature = "todo_macro", since = "1.40.0")]
macro_rules! todo {
    () => ($crate::panic!("not yet implemented"));
    ($($arg:tt)+) => ($crate::panic!("not yet implemented: {}", $crate::format_args!($($arg)+)));
}

/// ማክሮዎች ውስጥ አብሮ-ትርጓሜዎች.
///
/// በ ማክሮ ንብረቶች (መረጋጋት, ታይነት, ወዘተ) መካከል አብዛኞቹ ውጽዓቶች ወደ ማክሮ ግብዓቶችን የመለወጥ የማስፋፊያ ተግባራት መካከል በስተቀር, እነዚህን ተግባራት አጠናቃሪ የቀረቡ ናቸው ጋር, እዚህ ምንጭ ኮድ የተወሰዱ ናቸው.
///
///
pub(crate) mod builtin {

    /// መንስኤዎች አጋጥሞታል ጊዜ የተሰጠው የስህተት መልእክት ጋር እንዳይሳካ ማጠናቀር.
    ///
    /// አንድ crate የተሳሳተ ሁኔታዎች የተሻለ የስህተት መልዕክቶች ለማቅረብ ሁኔታዊ ማጠናቀር ስትራቴጂ ይጠቀማል ጊዜ ይህ ማክሮ ላይ መዋል አለበት.
    ///
    /// ይህ [`panic!`] ያለውን አጠናቃሪ-ደረጃ መልክ ነው, ነገር ግን አንድ *ማጠናቀር ጊዜ ስህተት* ይልቅ *የሚፈጀውን ላይ ታመነጫለች*.
    ///
    /// # Examples
    ///
    /// ሁለት እንዲህ ምሳሌዎች ማክሮዎች እና `#[cfg]` አካባቢ ናቸው.
    ///
    /// ማክሮ ልክ ያልሆኑ እሴቶችን ካስተላለፈ የተሻለ የአቀራረብ ስህተት ይተዉ።
    /// የመጨረሻውን branch ያለ አጠናቃሪ አሁንም ስህተት ያሰማሉ ነበር, ነገር ግን የስህተት መልእክት ሁለት ትክክለኛ እሴቶች መጥቀስ ነበር.
    ///
    /// ```compile_fail
    /// macro_rules! give_me_foo_or_bar {
    ///     (foo) => {};
    ///     (bar) => {};
    ///     ($x:ident) => {
    ///         compile_error!("This macro only accepts `foo` or `bar`");
    ///     }
    /// }
    ///
    /// give_me_foo_or_bar!(neither);
    /// // ^ will fail at compile time with message "This macro only accepts `foo` or `bar`"
    /// ```
    ///
    /// ከበርካታ ባህሪዎች ውስጥ አንዱ ከሌለ የአቀናባሪ ስህተትን ያስቀሩ።
    ///
    /// ```compile_fail
    /// #[cfg(not(any(feature = "foo", feature = "bar")))]
    /// compile_error!("Either feature \"foo\" or \"bar\" must be enabled for this crate.");
    /// ```
    ///
    #[stable(feature = "compile_error_macro", since = "1.20.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! compile_error {
        ($msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// በሌላ ሕብረቁምፊ-ቅርጸት ማክሮዎች ለ ግቤቶች Constructs.
    ///
    /// ይህ ማክሮ ለተላለፈው ለእያንዳንዱ ተጨማሪ ክርክር `{}` ን የያዘ የቅርጸት ሕብረቁምፊ ቃል በቃል በመያዝ ይሠራል ፡፡
    /// `format_args!` ተጨማሪውን መለኪያዎች ያዘጋጃል ውጤቱ እንደ ህብረቁምፊ ሊተረጎም ይችላል እና ክርክሮቹን ወደ አንድ ዓይነት ይፃፋል ፡፡
    /// የ [`Display`] trait `format_args!` ሊተላለፍ ይችላል መሳሪያዎች, እንደ ማንኛውም [`Debug`] ትግበራ ቅርጸት ሕብረቁምፊ ውስጥ `{:?}` ሊተላለፍ ይችላል ማንኛውም እሴት.
    ///
    ///
    /// ይህ ማክሮ የ [`fmt::Arguments`] ዓይነት እሴት ያስገኛል።ይህ ዋጋ ጠቃሚ ማዘዋወር በማከናወን ለ [`std::fmt`] ውስጥ ማደራጀት ሊተላለፍ ይችላል.
    /// ሁሉም ሌሎች ቅርጸት ያላቸው ማክሮዎች ([`ቅርጸት!`] ፣ [`write!`] ፣ [`println!`] ፣ ወዘተ) በዚህ በኩል ይተላለፋሉ ፡፡
    /// `format_args!`, ከተገኘው ማክሮዎች በተለየ ፣ ክምር ምደባን ያስወግዳል ፡፡
    ///
    /// ከዚህ በታች እንደሚታየው `format_args!` በ `Debug` እና `Display` አውዶች ውስጥ የሚመለሰውን የ [`fmt::Arguments`] ዋጋን መጠቀም ይችላሉ።
    /// የ ምሳሌ ደግሞ ያሳያል `Debug` እና ተመሳሳይ ነገር ወደ `Display` ቅርጸት: `format_args!` ውስጥ interpolated ቅርጸት ሕብረቁምፊ.
    ///
    /// ```rust
    /// let debug = format!("{:?}", format_args!("{} foo {:?}", 1, 2));
    /// let display = format!("{}", format_args!("{} foo {:?}", 1, 2));
    /// assert_eq!("1 foo 2", display);
    /// assert_eq!(display, debug);
    /// ```
    ///
    /// ተጨማሪ መረጃ ለማግኘት, [`std::fmt`] ውስጥ ያለውን ሰነድ ይመልከቱ.
    ///
    /// [`Display`]: crate::fmt::Display
    /// [`Debug`]: crate::fmt::Debug
    /// [`fmt::Arguments`]: crate::fmt::Arguments
    /// [`std::fmt`]: ../std/fmt/index.html
    /// [`format!`]: ../std/macro.format.html
    /// [`println!`]: ../std/macro.println.html
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// let s = fmt::format(format_args!("hello {}", "world"));
    /// assert_eq!(s, format!("hello {}", "world"));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// `format_args` ተመሳሳይ, ነገር ግን መጨረሻ ላይ አዲስ መስመር ያክላል.
    #[unstable(
        feature = "format_args_nl",
        issue = "none",
        reason = "`format_args_nl` is only for internal \
                  language use and is subject to change"
    )]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args_nl {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// የአከባቢን ተለዋዋጭ በሚቀናጅ ጊዜ ይመረምራል።
    ///
    /// ይህ ማክሮ በተጠቀሰው ጊዜ ለተጠቀሰው የአካባቢ ተለዋዋጭ እሴት ይሰፋል ፣ ይህም የ `&'static str` ዓይነት መግለጫ ይሰጣል።
    ///
    ///
    /// የአከባቢው ተለዋዋጭ ካልተገለጸ ታዲያ የማጠናቀር ስህተት ይወጣል።
    /// አንድ ማጠናቀር ስህተት ያሰማሉ አይደለም ዘንድ, በምትኩ [`option_env!`] ማክሮ ይጠቀሙ.
    ///
    /// # Examples
    ///
    /// ```
    /// let path: &'static str = env!("PATH");
    /// println!("the $PATH variable at the time of compiling was: {}", path);
    /// ```
    ///
    /// የ ሁለተኛው ግቤት እንደ ሕብረቁምፊ በማለፍ በማድረግ የስህተት መልዕክት ማበጀት ይችላሉ:
    ///
    /// ```compile_fail
    /// let doc: &'static str = env!("documentation", "what's that?!");
    /// ```
    ///
    /// የ `documentation` አከባቢ ተለዋዋጭ ካልተገለጸ የሚከተለውን ስህተት ያገኛሉ
    ///
    /// ```text
    /// error: what's that?!
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
        ($name:expr, $error_msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// በአማራጭነት, ይተነትናል ጊዜ አንድ አካባቢ ተለዋዋጭ ተመለከተ.
    ///
    /// የተሰየመው የአከባቢ ተለዋዋጭ በሚጠናቀረው ጊዜ የሚገኝ ከሆነ ፣ ይህ ከአከባቢው ተለዋዋጭ እሴት `Some` የሆነ የ‹XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX`X0XX ውስጥ ወደ አንድ አገላለጽ ይሰፋል ፡፡
    /// በአካባቢ ተለዋዋጭ አሁን ካልሆነ, ከዚያ ይህን `None` ያሰፋል.
    /// በዚህ ዓይነት ላይ ተጨማሪ መረጃ ለማግኘት [`Option<T>`][Option] ን ይመልከቱ ፡፡
    ///
    /// በየትኛውም አካባቢ ተለዋዋጭ በአሁኑ ወይም አይደለም አይደለም ይሁን ይህን ማክሮ ሲጠቀሙ አንድ ማጠናቀር ጊዜ ስህተት እንደሚያንጸባርቅ ፈጽሞ ነው.
    ///
    /// # Examples
    ///
    /// ```
    /// let key: Option<&'static str> = option_env!("SECRET_KEY");
    /// println!("the secret key might be: {:?}", key);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! option_env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// መለያዎችን ወደ አንድ መለያ ያጣምራል ፡፡
    ///
    /// ይህ ማክሮ አዲስ መለያ የሆነውን አንድ አገላለጽ ባዮች, ሁሉም በአንድ ወደ ማንኛውም በኮማ የተለዩ መለያዎችን ብዛት, እና ያጣምራል እነሱን ይወስዳል.
    /// ይህ ማክሮ የአከባቢን ተለዋዋጮች መያዝ እንደማይችል ንፅህና እንደሚያደርገው ልብ ይበሉ ፡፡
    /// በተጨማሪም አጠቃላይ ደንብ ሆኖ, ማክሮዎች ብቻ ንጥል, መግለጫ ወይም አገላለጽ ቦታ ውስጥ ይፈቀዳሉ.
    /// ያ ማለት ነባር ተለዋዋጮችን ፣ ተግባራትን ወይም ሞጁሎችን ወዘተ ለመጥቀስ ይህንን ማክሮ ቢጠቀሙም በእሱ አዲስ መለየት አይችሉም ፡፡
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(concat_idents)]
    ///
    /// # fn main() {
    /// fn foobar() -> u32 { 23 }
    ///
    /// let f = concat_idents!(foo, bar);
    /// println!("{}", f());
    ///
    /// // fn concat_idents! (አዲስ, አዝናኝ, ስም) በዚህ መንገድ { }//ሊሰራበት የሚችል አይደለም!
    /// # }
    /// ```
    ///
    ///
    ///
    #[unstable(
        feature = "concat_idents",
        issue = "29599",
        reason = "`concat_idents` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat_idents {
        ($($e:ident),+ $(,)?) => {{ /* compiler built-in */ }};
    }

    /// የማይንቀሳቀስ ሕብረቁምፊ ቁራጭ ወደ literals ያጣምራል.
    ///
    /// ይህ ማክሮ የ literals ሁሉንም የሚወክል የትኛው አይነት `&'static str` መግለጫ ባዮች, በኮማ የተለዩ literals ማንኛውም ቁጥር ይወስዳል concatenated ከግራ-ወደ-ቀኝ.
    ///
    ///
    /// ኢንቲጀር እና ተንሳፋፊ ነጥብ literals ቅደም stringified ናቸው concatenated ይሆናል.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = concat!("test", 10, 'b', true);
    /// assert_eq!(s, "test10btrue");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat {
        ($($e:expr),* $(,)?) => {{ /* compiler built-in */ }};
    }

    /// ይህ ሲጠራ የነበረው ላይ መስመር ቁጥር ይስፋፋል.
    ///
    /// በ [`column!`] እና [`file!`] እነዚህ ማክሮዎች በመነሻው ውስጥ ስላለው ስፍራ ለገንቢዎች ማረም መረጃን ይሰጣሉ ፡፡
    ///
    /// የተስፋፋው አገላለጽ `u32` ዓይነት አለው እና 1 ላይ የተመሠረተ ነው ፣ ስለሆነም በእያንዳንዱ ፋይል ውስጥ ያለው የመጀመሪያው መስመር እስከ 1 ፣ ከሁለተኛ እስከ 2 ፣ ወዘተ ይገመግማል ፡፡
    /// ይህ የጋራ compilers ወይም ታዋቂ አርታኢዎች በ የስህተት መልዕክቶች ጋር የሚስማማ ነው.
    /// የ ተመልሶ መስመር ነው *ሳይሆን የግድ* ያለውን የ `line!` መጠየቅን በራሱ መስመር, ነገር ግን ይልቅ `line!` ማክሮ መካከል አማላጅ ድረስ እየመራ የመጀመሪያው ማክሮ መጠየቅን.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_line = line!();
    /// println!("defined on line: {}", current_line);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! line {
        () => {
            /* compiler built-in */
        };
    }

    /// ይህ ሲጠራ ነበር ይህም በ አምድ ቁጥር ይስፋፋል.
    ///
    /// [`line!`] እና [`file!`] ጋር, እነዚህ ማክሮዎች ምንጭ ውስጥ አካባቢ ስለ ገንቢዎች ማረም መረጃ ይሰጣሉ.
    ///
    /// የ ተዘርግቷል አገላለጽ አይነት `u32` ያለው ሲሆን ነው 1-ተኮር, ወዘተ 1 በእያንዳንዱ መስመር ይሰላል ውስጥ የመጀመሪያው ዓምድ: 2 ወደ ሁለተኛው, ስለዚህ
    /// ይህ የጋራ compilers ወይም ታዋቂ አርታኢዎች በ የስህተት መልዕክቶች ጋር የሚስማማ ነው.
    /// የ ተመልሶ አምድ ነው *ሳይሆን የግድ* ያለውን የ `column!` መጠየቅን በራሱ መስመር, ነገር ግን ይልቅ `column!` ማክሮ መካከል አማላጅ ድረስ እየመራ የመጀመሪያው ማክሮ መጠየቅን.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_col = column!();
    /// println!("defined on column: {}", current_col);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! column {
        () => {
            /* compiler built-in */
        };
    }

    /// ለተጠራበት የፋይል ስም ያስፋፋል
    ///
    /// [`line!`] እና [`column!`] ጋር, እነዚህ ማክሮዎች ምንጭ ውስጥ አካባቢ ስለ ገንቢዎች ማረም መረጃ ይሰጣሉ.
    ///
    /// የተስፋፋው አገላለጽ `&'static str` ዓይነት አለው ፣ እና የተመለሰው ፋይል የ `file!` ማክሮ ራሱ ጥሪ አይደለም ፣ ግን ወደ `file!` ማክሮ ጥሪ የሚመራ የመጀመሪያው የማክሮ ጥሪ ነው።
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let this_file = file!();
    /// println!("defined in file: {}", this_file);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! file {
        () => {
            /* compiler built-in */
        };
    }

    /// እሴቶቹን Stringifies.
    ///
    /// ይህ ማክሮ ሁሉ tokens ያለውን stringification ወደ ማክሮ በሚተላለፍ ነው አይነት `&'static str` መግለጫ ታፈራለች.
    /// ምንም ገደቦች ማክሮ መጠየቅን ራሱ ያለውን አገባብ ላይ የሚቀመጡ ናቸው.
    ///
    /// በግቤት tokens የተስፋፋ ውጤቶች በ future ውስጥ መለወጥ እንደሚችል ልብ ይበሉ.በውጤቱ የሚታመኑ ከሆነ ጥንቃቄ ማድረግ አለብዎት ፡፡
    ///
    /// # Examples
    ///
    /// ```
    /// let one_plus_one = stringify!(1 + 1);
    /// assert_eq!(one_plus_one, "1 + 1");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! stringify {
        ($($t:tt)*) => {
            /* compiler built-in */
        };
    }

    /// እንደ ሕብረቁምፊ አንድ UTF-8 ኮድ ፋይል ያካትታል.
    ///
    /// ፋይሉ (በተመሳሳይ ሞጁሎች ይገኛሉ እንዴት) አሁን ያለውን ፋይል አንጻራዊ ይገኛል.
    /// የቀረበው ዱካ በማጠናቀር ጊዜ በመድረክ-ተኮር መንገድ ይተረጎማል ፡፡
    /// ስለዚህ, ለምሳሌ, ህዝባሮች የያዘ አንድ Windows መንገድ ጋር አንድ መጠየቅን `\` Unix ላይ በትክክል ለማጠናቀር ነበር.
    ///
    ///
    /// ይህ ማክሮ ፋይል ይዘቶች የሆነውን አይነት `&'static str` መግለጫ ታፈራለች.
    ///
    /// # Examples
    ///
    /// በተመሳሳይ ማውጫ ውስጥ ከሚከተሉት ይዘቶች ጋር ሁለት ፋይሎች አሉ እንበል ፡፡
    ///
    /// 'spanish.in' ፋይል
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// 'main.rs' የፋይል:
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_str = include_str!("spanish.in");
    ///     assert_eq!(my_str, "adiós\n");
    ///     print!("{}", my_str);
    /// }
    /// ```
    ///
    /// 'main.rs' ን ማጠናቀር እና የተገኘውን ሁለትዮሽ ማሄድ "adiós" ን ያትማል።
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_str {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// አንድ ባይት ድርድር ማጣቀሻ እንደ አንድ ፋይል ያካትታል.
    ///
    /// ፋይሉ (በተመሳሳይ ሞጁሎች ይገኛሉ እንዴት) አሁን ያለውን ፋይል አንጻራዊ ይገኛል.
    /// የቀረበው ዱካ በማጠናቀር ጊዜ በመድረክ-ተኮር መንገድ ይተረጎማል ፡፡
    /// ስለዚህ, ለምሳሌ, ህዝባሮች የያዘ አንድ Windows መንገድ ጋር አንድ መጠየቅን `\` Unix ላይ በትክክል ለማጠናቀር ነበር.
    ///
    ///
    /// ይህ ማክሮ ፋይል ይዘቶች የሆነውን አይነት `&'static [u8; N]` መግለጫ ታፈራለች.
    ///
    /// # Examples
    ///
    /// በተመሳሳይ ማውጫ ውስጥ ከሚከተሉት ይዘቶች ጋር ሁለት ፋይሎች አሉ እንበል ፡፡
    ///
    /// 'spanish.in' ፋይል
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// 'main.rs' የፋይል:
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let bytes = include_bytes!("spanish.in");
    ///     assert_eq!(bytes, b"adi\xc3\xb3s\n");
    ///     print!("{}", String::from_utf8_lossy(bytes));
    /// }
    /// ```
    ///
    /// 'main.rs' ን ማጠናቀር እና የተገኘውን ሁለትዮሽ ማሄድ "adiós" ን ያትማል።
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_bytes {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// የአሁኑ ሞዱል መንገድ የሚወክል አንድ ሕብረቁምፊ ወደ ይስፋፋል.
    ///
    /// የአሁኑ ሞዱል መንገድ ተመልሶ እስከ crate root የሚያደርሱ ሞዱሎች መካከል ተዋረድ ተደርጎ ሊታሰብ ይችላል.
    /// የተመለሱ መንገድ የመጀመሪያው አካል በአሁኑ ጊዜ የተጠናከረ እየተደረገ ያለውን crate ስም ነው.
    ///
    /// # Examples
    ///
    /// ```
    /// mod test {
    ///     pub fn foo() {
    ///         assert!(module_path!().ends_with("test"));
    ///     }
    /// }
    ///
    /// test::foo();
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! module_path {
        () => {
            /* compiler built-in */
        };
    }

    /// በማጠናቀር-ጊዜ የቦሌን የውቅር ባንዲራዎች ጥምረት ይገመግማል።
    ///
    /// ወደ `#[cfg]` አይነታ በተጨማሪ ይህ ማክሮ ውቅር ባንዲራዎች መካከል ቡሊያን መግለጫ ግምገማ ለመፍቀድ የቀረበ ነው.
    /// ያነሰ የተባዙ ኮድ ይህ ብዙ ጊዜ ይመራል.
    ///
    /// ለዚህ ማክሮ የተሰጠው አገባብ ከ [`cfg`] አይነታ ተመሳሳይ አገባብ ነው ፡፡
    ///
    /// `cfg!`, `#[cfg]` በተለየ ማንኛውም ኮድ ማስወገድ አይደለም ብቻ እውነት ወይም ሐሰት ይሰላል.
    /// ለምሳሌ ፣ `cfg!` የሚገመግመው ምንም ይሁን ምን `cfg!` ለጉዳዩ ጥቅም ላይ ሲውል በ if/else አገላለጽ ውስጥ ያሉት ሁሉም ብሎኮች ትክክለኛ መሆን አለባቸው ፡፡
    ///
    ///
    /// [`cfg`]: ../reference/conditional-compilation.html#the-cfg-attribute
    ///
    /// # Examples
    ///
    /// ```
    /// let my_directory = if cfg!(windows) {
    ///     "windows-specific-directory"
    /// } else {
    ///     "unix-directory"
    /// };
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! cfg {
        ($($cfg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// አንድ መግለጫ ወይም አውድ መሠረት አንድ ንጥል እንደ አንድ ፋይል Parses.
    ///
    /// ፋይሉ (በተመሳሳይ ሞጁሎች ይገኛሉ እንዴት) አሁን ያለውን ፋይል አንጻራዊ ይገኛል.በቀረበው መንገድ ለማጠናቀር ጊዜ መድረክ-ተኮር መንገድ መተርጎም ነው.
    /// ስለዚህ, ለምሳሌ, ህዝባሮች የያዘ አንድ Windows መንገድ ጋር አንድ መጠየቅን `\` Unix ላይ በትክክል ለማጠናቀር ነበር.
    ///
    /// ፋይሉን መግለጫ እንደሆነ ይተነተናሉ ከሆነ, ይህ unhygienically በዙሪያው ኮድ ውስጥ መቀመጥ የሚሄድ ነው ምክንያቱም ይህ ማክሮ በመጠቀም, ብዙውን ጊዜ መጥፎ ሐሳብ ነው.
    /// በአሁኑ ፋይል ውስጥ ተመሳሳይ ስም ያላቸው ተለዋዋጮች ወይም ተግባራት ካሉ ይህ ተለዋዋጮች ወይም ተግባሩ ፋይሉ ከሚጠብቀው የተለየ እንዲሆኑ ሊያደርግ ይችላል።
    ///
    ///
    /// # Examples
    ///
    /// በተመሳሳይ ማውጫ ውስጥ ከሚከተሉት ይዘቶች ጋር ሁለት ፋይሎች አሉ እንበል ፡፡
    ///
    /// 'monkeys.in' ፋይል
    ///
    /// ```ignore (only-for-syntax-highlight)
    /// ['🙈', '🙊', '🙉']
    ///     .iter()
    ///     .cycle()
    ///     .take(6)
    ///     .collect::<String>()
    /// ```
    ///
    /// 'main.rs' የፋይል:
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_string = include!("monkeys.in");
    ///     assert_eq!("🙈🙊🙉🙈🙊🙉", my_string);
    ///     println!("{}", my_string);
    /// }
    /// ```
    ///
    /// 'main.rs' ማጠናቀር እና "🙈🙊🙉🙈🙊🙉" ማተም ይሆናል ምክንያት ሁለትዮሽ እየሄደ.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// የቡሊያን አገላለጽ በወቅቱ በሚሆንበት ጊዜ `true` መሆኑን ያረጋግጣል።
    ///
    /// የቀረበው መግለጫ የሚፈጀውን ላይ `true` ተገምግመዋል አይችልም ከሆነ ይህ [`panic!`] ማክሮ ይጥሩ ይሆናል.
    ///
    /// # Uses
    ///
    /// ከተናገሯቸው ሁልጊዜ ለማረም እና ከእስር ሁለቱም ካልሠራ ውስጥ ምልክት የተደረገባቸው ናቸው, እና ተሰናክሏል አይችልም.
    /// መለቀቅ ውስጥ አልነቃም ናቸው ከተናገሯቸው ለማግኘት [`debug_assert!`] በነባሪ ይገነባል.
    ///
    /// ደህንነቱ ያልተጠበቀ ኮድ በ‹XXXX›ላይ ሊመካ ይችላል የአሂድ ጊዜ የማይለዋወጥን ለማስፈፀም ፣ ከተጣሰ ደህንነትን ሊያስከትል ይችላል ፡፡
    ///
    /// `assert!` ሌሎች አጠቃቀም-ጉዳዮች ሙከራ እና (የማን በመጣስ unsafety ሊያስከትል አይችልም) አስተማማኝ ኮድ ውስጥ አሂድ-ጊዜ invariants ማስፈጸምን ይጨምራል.
    ///
    ///
    /// # ብጁ መልዕክቶች
    ///
    /// ይህ ማክሮ ብጁ panic መልእክት ጋር ወይም ቅርጸት ክርክር ያለ ሊቀርብ በሚችልበት ሁለተኛ መልክ አለው.
    /// ለዚህ ቅጽ አገባብ ለ [`std::fmt`] ይመልከቱ.
    /// ሐሳብስ ካልተሳካ ቅርጸት እሴቶች ሆነው ጥቅም ላይ አገላለጾች ብቻ መገምገም ይሆናል.
    ///
    /// [`std::fmt`]: ../std/fmt/index.html
    ///
    /// # Examples
    ///
    /// ```
    /// // እነዚህ ከተናገሯቸው ለ panic መልእክት የተሰጠው መግለጫ ያለውን stringified ዋጋ ነው.
    /////
    /// assert!(true);
    ///
    /// fn some_computation() -> bool { true } // በጣም ቀላል ተግባር
    ///
    /// assert!(some_computation());
    ///
    /// // ብጁ መልዕክት ጋር ስለመሆንዎ
    /// let x = true;
    /// assert!(x, "x wasn't true!");
    ///
    /// let a = 3; let b = 27;
    /// assert!(a + b == 30, "a = {}, b = {}", a, b);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    #[rustc_diagnostic_item = "assert_macro"]
    #[allow_internal_unstable(core_panic, edition_panic)]
    macro_rules! assert {
        ($cond:expr $(,)?) => {{ /* compiler built-in */ }};
        ($cond:expr, $($arg:tt)+) => {{ /* compiler built-in */ }};
    }

    /// ቤተ ክርስቲያን አይጣጣምም.
    ///
    /// አጠቃቀም ለ [unstable book] አንብብ.
    ///
    /// [unstable book]: ../unstable-book/library-features/asm.html
    #[unstable(
        feature = "asm",
        issue = "72016",
        reason = "inline assembly is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! asm {
        ("assembly template",
            $(operands,)*
            $(options($(option),*))?
        ) => {
            /* compiler built-in */
        };
    }

    /// LLVM-ቅጥ መስመር ውስጥ ስብሰባ.
    ///
    /// አጠቃቀም ለ [unstable book] አንብብ.
    ///
    /// [unstable book]: ../unstable-book/library-features/llvm-asm.html
    #[unstable(
        feature = "llvm_asm",
        issue = "70173",
        reason = "prefer using the new asm! syntax instead"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! llvm_asm {
        ("assembly template"
                        : $("output"(operand),)*
                        : $("input"(operand),)*
                        : $("clobbers",)*
                        : $("options",)*) => {
            /* compiler built-in */
        };
    }

    /// ሞጁል-ደረጃ መስመር ውስጥ ስብሰባ.
    #[unstable(
        feature = "global_asm",
        issue = "35119",
        reason = "`global_asm!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! global_asm {
        ("assembly") => {
            /* compiler built-in */
        };
    }

    /// አትም መደበኛ ውፅዓት ወደ tokens አልፈዋል.
    #[unstable(
        feature = "log_syntax",
        issue = "29598",
        reason = "`log_syntax!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! log_syntax {
        ($($arg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// ያነቃል ወይም ተግባር ለመንገዱም ያሰናክላል ሌሎች ማክሮዎች ለማረም ተጠቅሟል.
    #[unstable(
        feature = "trace_macros",
        issue = "29598",
        reason = "`trace_macros` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! trace_macros {
        (true) => {{ /* compiler built-in */ }};
        (false) => {{ /* compiler built-in */ }};
    }

    /// አይነታ ማክሮ ማግኘት ማክሮዎች ተግባራዊ ለማድረግ ተጠቅሞበታል.
    #[cfg(not(bootstrap))]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    pub macro derive($item:item) {
        /* compiler built-in */
    }

    /// አይነታ ማክሮ አንድ ዩኒት ፈተና ወደ ለማብራት አንድ ተግባር ላይ ተተግብሯል.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test($item:item) {
        /* compiler built-in */
    }

    /// አይነታ ማክሮ አንድ መነሻ ፈተና ወደ ለማብራት አንድ ተግባር ላይ ተተግብሯል.
    #[unstable(
        feature = "test",
        issue = "50297",
        soft,
        reason = "`bench` is a part of custom test frameworks which are unstable"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro bench($item:item) {
        /* compiler built-in */
    }

    /// የ `#[test]` እና `#[bench]` የማክሮዎች አንድ አፈጻጸም ዝርዝር.
    #[unstable(
        feature = "custom_test_frameworks",
        issue = "50297",
        reason = "custom test frameworks are an unstable feature"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test_case($item:item) {
        /* compiler built-in */
    }

    /// እንደ ዓለም አቀፋዊ ለመመዝገብ በስታቲክ ላይ የተተገበረ ማክሮ አይነታ ፡፡
    ///
    /// በተጨማሪም [`std::alloc::GlobalAlloc`](../std/alloc/trait.GlobalAlloc.html) ተመልከት.
    #[stable(feature = "global_allocator", since = "1.28.0")]
    #[allow_internal_unstable(rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro global_allocator($item:item) {
        /* compiler built-in */
    }

    /// የተላለፈው መንገድ ተደራሽ ከሆነ የተተገበረውን ንጥል ያቆያል ፣ እና ካልሆነ ያስወግደዋል።
    #[unstable(
        feature = "cfg_accessible",
        issue = "64797",
        reason = "`cfg_accessible` is not fully implemented"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_accessible($item:item) {
        /* compiler built-in */
    }

    /// ሁሉም `#[cfg]` እና `#[cfg_attr]` ይህን ተግባራዊ ነው ኮድ ቁራጭ ውስጥ ባህርያት ይስፋፋል.
    #[cfg(not(bootstrap))]
    #[unstable(
        feature = "cfg_eval",
        issue = "82679",
        reason = "`cfg_eval` is a recently implemented feature"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_eval($($tt:tt)*) {
        /* compiler built-in */
    }

    /// የ `rustc` አጠናቃሪ ያልተረጋጋ የትግበራ ዝርዝር ፣ አይጠቀሙ ፡፡
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics, libstd_sys_internals)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcDecodable($item:item) {
        /* compiler built-in */
    }

    /// የ `rustc` አጠናቃሪ ያልተረጋጋ የትግበራ ዝርዝር ፣ አይጠቀሙ ፡፡
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcEncodable($item:item) {
        /* compiler built-in */
    }
}