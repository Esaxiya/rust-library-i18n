//! Rust የ Grisu3 ስልተ ቀመርን ማመቻቸት `ተንሳፋፊ የነጥብ ቁጥሮች በፍጥነት እና በትክክል ከኢንቴነሮች ጋር በማተም` [^ 1].
//! እሱ ከ 1 ኪባ በፊት የተሰራ ጠረጴዛን ይጠቀማል ፣ እና በተራው ፣ ለአብዛኞቹ ግብዓቶች በጣም ፈጣን ነው ፡፡
//!
//! [^1]: Florian ሎይትሽ2010. ተንሳፋፊ-ነጥብ ቁጥሮች በፍጥነት ማተም እና
//!   በትክክል ከቁጥር ቁጥሮች ጋር።ፊርማ አይደለም45 ፣ 6 (ሰኔ 2010) ፣ 233-243 ፡፡
//!

use crate::mem::MaybeUninit;
use crate::num::diy_float::Fp;
use crate::num::flt2dec::{round_up, Decoded, MAX_SIG_DIGITS};

// ለአስተያየቱ በ `format_shortest_opt` ውስጥ አስተያየቶችን ይመልከቱ ፡፡
#[doc(hidden)]
pub const ALPHA: i16 = -60;
#[doc(hidden)]
pub const GAMMA: i16 = -32;

/*
# the following Python code generates this table:
for i in xrange(-308, 333, 8):
    if i >= 0: f = 10**i; e = 0
    else: f = 2**(80-4*i) // 10 **-እኔ;ሠ=4* እኔ ፣ 80
    l = f.bit_length()
    f = ((f << 64 >> (l-1)) + 1) >> 1; e += l - 64
    print '    (%#018x, %5d, %4d),' % (f, e, i)
*/

#[doc(hidden)]
pub static CACHED_POW10: [(u64, i16, i16); 81] = [
    // (ረ ፣ ኢ ፣ ኬ)
    (0xe61acf033d1a45df, -1087, -308),
    (0xab70fe17c79ac6ca, -1060, -300),
    (0xff77b1fcbebcdc4f, -1034, -292),
    (0xbe5691ef416bd60c, -1007, -284),
    (0x8dd01fad907ffc3c, -980, -276),
    (0xd3515c2831559a83, -954, -268),
    (0x9d71ac8fada6c9b5, -927, -260),
    (0xea9c227723ee8bcb, -901, -252),
    (0xaecc49914078536d, -874, -244),
    (0x823c12795db6ce57, -847, -236),
    (0xc21094364dfb5637, -821, -228),
    (0x9096ea6f3848984f, -794, -220),
    (0xd77485cb25823ac7, -768, -212),
    (0xa086cfcd97bf97f4, -741, -204),
    (0xef340a98172aace5, -715, -196),
    (0xb23867fb2a35b28e, -688, -188),
    (0x84c8d4dfd2c63f3b, -661, -180),
    (0xc5dd44271ad3cdba, -635, -172),
    (0x936b9fcebb25c996, -608, -164),
    (0xdbac6c247d62a584, -582, -156),
    (0xa3ab66580d5fdaf6, -555, -148),
    (0xf3e2f893dec3f126, -529, -140),
    (0xb5b5ada8aaff80b8, -502, -132),
    (0x87625f056c7c4a8b, -475, -124),
    (0xc9bcff6034c13053, -449, -116),
    (0x964e858c91ba2655, -422, -108),
    (0xdff9772470297ebd, -396, -100),
    (0xa6dfbd9fb8e5b88f, -369, -92),
    (0xf8a95fcf88747d94, -343, -84),
    (0xb94470938fa89bcf, -316, -76),
    (0x8a08f0f8bf0f156b, -289, -68),
    (0xcdb02555653131b6, -263, -60),
    (0x993fe2c6d07b7fac, -236, -52),
    (0xe45c10c42a2b3b06, -210, -44),
    (0xaa242499697392d3, -183, -36),
    (0xfd87b5f28300ca0e, -157, -28),
    (0xbce5086492111aeb, -130, -20),
    (0x8cbccc096f5088cc, -103, -12),
    (0xd1b71758e219652c, -77, -4),
    (0x9c40000000000000, -50, 4),
    (0xe8d4a51000000000, -24, 12),
    (0xad78ebc5ac620000, 3, 20),
    (0x813f3978f8940984, 30, 28),
    (0xc097ce7bc90715b3, 56, 36),
    (0x8f7e32ce7bea5c70, 83, 44),
    (0xd5d238a4abe98068, 109, 52),
    (0x9f4f2726179a2245, 136, 60),
    (0xed63a231d4c4fb27, 162, 68),
    (0xb0de65388cc8ada8, 189, 76),
    (0x83c7088e1aab65db, 216, 84),
    (0xc45d1df942711d9a, 242, 92),
    (0x924d692ca61be758, 269, 100),
    (0xda01ee641a708dea, 295, 108),
    (0xa26da3999aef774a, 322, 116),
    (0xf209787bb47d6b85, 348, 124),
    (0xb454e4a179dd1877, 375, 132),
    (0x865b86925b9bc5c2, 402, 140),
    (0xc83553c5c8965d3d, 428, 148),
    (0x952ab45cfa97a0b3, 455, 156),
    (0xde469fbd99a05fe3, 481, 164),
    (0xa59bc234db398c25, 508, 172),
    (0xf6c69a72a3989f5c, 534, 180),
    (0xb7dcbf5354e9bece, 561, 188),
    (0x88fcf317f22241e2, 588, 196),
    (0xcc20ce9bd35c78a5, 614, 204),
    (0x98165af37b2153df, 641, 212),
    (0xe2a0b5dc971f303a, 667, 220),
    (0xa8d9d1535ce3b396, 694, 228),
    (0xfb9b7cd9a4a7443c, 720, 236),
    (0xbb764c4ca7a44410, 747, 244),
    (0x8bab8eefb6409c1a, 774, 252),
    (0xd01fef10a657842c, 800, 260),
    (0x9b10a4e5e9913129, 827, 268),
    (0xe7109bfba19c0c9d, 853, 276),
    (0xac2820d9623bf429, 880, 284),
    (0x80444b5e7aa7cf85, 907, 292),
    (0xbf21e44003acdd2d, 933, 300),
    (0x8e679c2f5e44ff8f, 960, 308),
    (0xd433179d9c8cb841, 986, 316),
    (0x9e19db92b4e31ba9, 1013, 324),
    (0xeb96bf6ebadf77d9, 1039, 332),
];

#[doc(hidden)]
pub const CACHED_POW10_FIRST_E: i16 = -1087;
#[doc(hidden)]
pub const CACHED_POW10_LAST_E: i16 = 1039;

#[doc(hidden)]
pub fn cached_power(alpha: i16, gamma: i16) -> (i16, Fp) {
    let offset = CACHED_POW10_FIRST_E as i32;
    let range = (CACHED_POW10.len() as i32) - 1;
    let domain = (CACHED_POW10_LAST_E - CACHED_POW10_FIRST_E) as i32;
    let idx = ((gamma as i32) - offset) * range / domain;
    let (f, e, k) = CACHED_POW10[idx as usize];
    debug_assert!(alpha <= e && e <= gamma);
    (k, Fp { f, e })
}

/// `x > 0` ከተሰጠ `(k, 10^k)` ን ያንን `10^k <= x < 10^(k+1)` ይመልሳል።
#[doc(hidden)]
pub fn max_pow10_no_more_than(x: u32) -> (u8, u32) {
    debug_assert!(x > 0);

    const X9: u32 = 10_0000_0000;
    const X8: u32 = 1_0000_0000;
    const X7: u32 = 1000_0000;
    const X6: u32 = 100_0000;
    const X5: u32 = 10_0000;
    const X4: u32 = 1_0000;
    const X3: u32 = 1000;
    const X2: u32 = 100;
    const X1: u32 = 10;

    if x < X4 {
        if x < X2 {
            if x < X1 { (0, 1) } else { (1, X1) }
        } else {
            if x < X3 { (2, X2) } else { (3, X3) }
        }
    } else {
        if x < X6 {
            if x < X5 { (4, X4) } else { (5, X5) }
        } else if x < X8 {
            if x < X7 { (6, X6) } else { (7, X7) }
        } else {
            if x < X9 { (8, X8) } else { (9, X9) }
        }
    }
}

/// ለግሪሱ በጣም አጭር የአተገባበር አተገባበር ፡፡
///
/// በሌላ መንገድ ያልነበረ ውክልና ሲመልስ `None` ን ይመልሳል።
pub fn format_shortest_opt<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> Option<(/*digits*/ &'a [u8], /*exp*/ i16)> {
    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());
    assert!(buf.len() >= MAX_SIG_DIGITS);
    assert!(d.mant + d.plus < (1 << 61)); // ተጨማሪ ትክክለኛነት ቢያንስ ሦስት ቢቶች ያስፈልጉናል

    // ከተጋሩ ኤክስፐርት ጋር በመደበኛ እሴቶች ይጀምሩ
    let plus = Fp { f: d.mant + d.plus, e: d.exp }.normalize();
    let minus = Fp { f: d.mant - d.minus, e: d.exp }.normalize_to(plus.e);
    let v = Fp { f: d.mant, e: d.exp }.normalize_to(plus.e);

    // ማንኛውንም `cached = 10^minusk` ን ያንን `ALPHA <= minusk + plus.e + 64 <= GAMMA` ያግኙ።
    // `plus` መደበኛ ስለሆነ ይህ `2^(62 + ALPHA) <= plus * cached < 2^(64 + GAMMA)` ማለት ነው።
    // የ `ALPHA` እና `GAMMA` ምርጫዎቻችን ከተሰጠን ፣ ይህ `plus * cached` ን ወደ `[4, 2^32)` ያደርገዋል ፡፡
    //
    // `GAMMA - ALPHA` ን ለማሳደግ በግልፅ የሚፈለግ ነው ፣ ስለሆነም ብዙ የ 10 የተሸጎጡ ኃይሎችን አንፈልግም ፣ ግን አንዳንድ አስተያየቶች አሉ
    //
    //
    // 1. ውድ ክፍፍል ስለሚያስፈልገው `floor(plus * cached)` ን በ `u32` ውስጥ ማቆየት እንፈልጋለን።
    //    (ይህ በእውነቱ ሊወገድ የሚችል አይደለም ፣ ለትክክለኛው ግምት ቀሪው ያስፈልጋል።)
    // 2.
    // የተቀረው የ `floor(plus * cached)` በተደጋጋሚ በ 10 ይባዛል ፣ እና መብለጥ የለበትም።
    //
    // የመጀመሪያው `64 + GAMMA <= 32` ን ይሰጣል ፣ ሁለተኛው ደግሞ `10 * 2^-ALPHA <= 2^64` ይሰጣል ፡፡
    // -60 እና -32 ከዚህ ገደብ ጋር ከፍተኛው ክልል ነው ፣ እና V8 ደግሞ እነሱን ይጠቀማል።
    let (minusk, cached) = cached_power(ALPHA - plus.e - 64, GAMMA - plus.e - 64);

    // ልኬት fps.ይህ ከፍተኛውን የ 1 ulp ስህተት ይሰጣል (ከቲዎረም 5.1 የተረጋገጠ)።
    let plus = plus.mul(&cached);
    let minus = minus.mul(&cached);
    let v = v.mul(&cached);
    debug_assert_eq!(plus.e, minus.e);
    debug_assert_eq!(plus.e, v.e);

    // +-የመቀነስ ትክክለኛ ክልል
    //   | <---|---------------------- unsafe region --------------------------> |
    //   |     |                                                                 |
    //   |  |<--->|  | <--------------- safe region ---------------> |           |
    //   |  |     |  |                                               |           |
    //   | 1 pል | 1 pል || 1 pል | 1 pል || 1 pል | 1 pል |
    //   |<--->|<--->|                 |<--->|<--->|                 |<--->|<--->|
    //   |-----|-----|-------...-------|-----|-----|-------...-------|-----|-----|
    //   |   minus   |                 |     v     |                 |   plus    | minus1     minus0           v - 1 ulp   v + 1 ulp           plus0       plus1
    //
    //
    // ከ `minus` ፣ `v` እና `plus` በላይ *በቁጥር የተቀመጡ* ግምቶች ናቸው (ስህተት <1 ulp)።
    // ስህተቱ አዎንታዊ ወይም አሉታዊ መሆኑን ስለማናውቅ በእኩል ርቀት የተያዙ ሁለት ግምቶችን እንጠቀማለን እና ከፍተኛው የ 2 ቁስሎች ስህተት አለብን ፡፡
    //
    // "unsafe region" መጀመሪያ የምናመነጨው የሊበራል ክፍተት ነው ፡፡
    // "safe region" እኛ የምንቀበለው ወግ አጥባቂ ክፍተት ነው።
    // እኛ ደህንነቱ ባልተጠበቀ ክልል ውስጥ በትክክለኛው repr እንጀምራለን ፣ እና በአስተማማኝ ክልል ውስጥም ወደ‹`v`›በጣም የቅርብ ሪከርን ለማግኘት እንሞክራለን ፡፡
    // ካልቻልን ተስፋ እንቆርጣለን ፡፡
    //
    let plus1 = plus.f + 1;
    // plus0 = plus.f, 1 ይሁን//ለማብራሪያ ብቻ minus0 = minus.f + 1;//ለማብራሪያ ብቻ
    //
    let minus1 = minus.f - 1;
    let e = -plus.e as usize; // የተጋራ ገላጭ

    // `plus1` ን ወደ ወሳኝ እና ክፍልፋይ ክፍሎች ይከፋፍሉ።
    // የተሸጎጡ የኃይል አቅርቦቶች `plus < 2^32` እና መደበኛ `plus.f` በትክክለኛው መስፈርት ምክንያት ሁል ጊዜ ከ `2^64 - 2^4` በታች ስለሆነ የማይነጣጠሉ ክፍሎች በ u32 ውስጥ እንዲገቡ የተረጋገጠ ነው ፡፡
    //
    let plus1int = (plus1 >> e) as u32;
    let plus1frac = plus1 & ((1 << e) - 1);

    // ትልቁን `10^max_kappa` ከ `plus1` ያልበለጠ ያስሉ (ስለሆነም `plus1 < 10^(max_kappa+1)`)።
    // ይህ ከታች የ `kappa` የላይኛው ወሰን ነው።
    let (max_kappa, max_ten_kappa) = max_pow10_no_more_than(plus1int);

    let mut i = 0;
    let exp = max_kappa as i16 - minusk + 1;

    // ቲዎረም 6.2: `k` ትልቁ ኢንቲጀር ሴንት ከሆነ
    // `0 <= y mod 10^k <= y - x`,              ከዚያ `V = floor(y / 10^k) * 10^k` በ `[x, y]` ውስጥ ይገኛል እና በዚያ ክልል ውስጥ በጣም አጭር ከሆኑ ውክልናዎች አንዱ (አነስተኛ ቁጥር ያላቸው ቁጥሮች)።
    //
    //
    // እንደ Theorem 6.2 መሠረት በ `(minus1, plus1)` መካከል የዲጂት ርዝመት `kappa` ን ያግኙ።
    // በምትኩ `y mod 10^k < y - x` ን በመጠየቅ `x` ን ለማስቀረት ቲዎሪ 6.2 ሊቀበል ይችላል ፡፡
    // (ለምሳሌ ፣ `x` =32000 ፣ `y` =32777 ፣ `kappa` =2 ከ‹y mod 10 ^ 3=777 <y, x=777` ጀምሮ።) ስልተ ቀመሩ `y` ን ለማስቀረት በሚቀጥለው የማረጋገጫ ደረጃ ላይ የተመሠረተ ነው።
    //
    let delta1 = plus1 - minus1;
    // delta1int=(delta1>> e) እንደ መጠቀሚያ ይሁን;//ለማብራሪያ ብቻ
    let delta1frac = delta1 & ((1 << e) - 1);

    // በእያንዳንዱ ደረጃ ትክክለኛነቱን በሚፈትሹበት ጊዜ ወሳኝ ክፍሎችን ያቅርቡ ፡፡
    let mut kappa = max_kappa as i16;
    let mut ten_kappa = max_ten_kappa; // 10^kappa
    let mut remainder = plus1int; // አኃዞች ገና ሊሰጡ
    loop {
        // እንደ `plus1 >= 10^kappa` የማይለዋወጥ ሁልጊዜ ለማቅረብ ቢያንስ አንድ አሃዝ አለን
        // - `delta1int <= remainder < 10^(kappa+1)`
        // - `plus1int = d[0..n-1] * 10^(kappa+1) + remainder`   (ያንን `remainder = plus1int % 10^(kappa+1)` ይከተላል)
        //
        //

        // `remainder` ን በ `10^kappa` ይከፋፍሉ።ሁለቱም በ `2^-e` ተመዝነዋል።
        let q = remainder / ten_kappa;
        let r = remainder % ten_kappa;
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        let plus1rem = ((r as u64) << e) + plus1frac; // ==(plus1% 10 ^ ካፓ) * 2 ^ e
        if plus1rem < delta1 {
            // `plus1 % 10^kappa < delta1 = plus1 - minus1`; ትክክለኛውን `kappa` አግኝተናል ፡፡
            let ten_kappa = (ten_kappa as u64) << e; // ልኬት 10 ^ ካፓ ወደ የተጋራው አክሲዮን ተመልሷል
            return round_and_weed(
                // ደህንነት-ያንን ትውስታ ከላይ አስነሳነው ፡፡
                unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) },
                exp,
                plus1rem,
                delta1,
                plus1 - v.f,
                ten_kappa,
                1,
            );
        }

        // ሁሉንም አስፈላጊ አሃዞች በሠጠነው ጊዜ ቀለበቱን ይሰብሩ ፡፡
        // የአሃዞች ትክክለኛ ቁጥር `max_kappa + 1` እንደ `plus1 < 10^(max_kappa+1)` ነው።
        if i > max_kappa as usize {
            debug_assert_eq!(ten_kappa, 1);
            debug_assert_eq!(kappa, 0);
            break;
        }

        // የማይለወጡትን ይመልሱ
        kappa -= 1;
        ten_kappa /= 10;
        remainder = r;
    }

    // በእያንዳንዱ ደረጃ ላይ ትክክለኝነትን በሚፈትሹበት ጊዜ ክፍልፋዮችን ያቅርቡ ፡፡
    // መከፋፈል ትክክለኛነቱን ስለሚያጣ በዚህ ጊዜ በተደጋጋሚ ብዜቶች ላይ እንመካለን ፡፡
    let mut remainder = plus1frac;
    let mut threshold = delta1frac;
    let mut ulp = 1;
    loop {
        // `m = max_kappa + 1` (በቁጥር አካል ውስጥ#ቁጥሮች) ባሉበት ቦታ የማይለዋወጡትን ከመውጣታችን በፊት ያንን አረጋግጠናል ቀጣዩ አሃዝ ጠቃሚ መሆን አለበት ፡፡
        //
        // - `remainder < 2^e`
        // - `plus1frac * 10^(n-m) = d[m..n-1] * 2^e + remainder`

        remainder *= 10; // አይፈስም ፣ `2^e * 10 < 2^64`
        threshold *= 10;
        ulp *= 10;

        // `remainder` ን በ `10^kappa` ይከፋፍሉ።
        // ሁለቱም በ `2^e / 10^kappa` የተመዘኑ ናቸው ፣ ስለሆነም የመጨረሻው እዚህ ላይ ተካትቷል።
        let q = remainder >> e;
        let r = remainder & ((1 << e) - 1);
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        if r < threshold {
            let ten_kappa = 1 << e; // ግልጽ ያልሆነ ከፋይ
            return round_and_weed(
                // ደህንነት-ያንን ትውስታ ከላይ አስነሳነው ፡፡
                unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) },
                exp,
                r,
                threshold,
                (plus1 - v.f) * ulp,
                ten_kappa,
                ulp,
            );
        }

        // የማይለወጡትን ይመልሱ
        kappa -= 1;
        remainder = r;
    }

    // ሁሉንም የ `plus1` አሃዞች አመንጭተናል ፣ ግን የተመቻቸ መሆኑን እርግጠኛ አይደለንም ፡፡
    // ለምሳሌ ፣ `minus1` 3.14153 ... እና `plus1` 3.14158 ከሆነ ... ከ 3.14154 እስከ 3.14158 ድረስ 5 የተለያዩ አጫጭር ውክልናዎች አሉ ግን እኛ ትልቁን ብቻ አለን ፡፡
    // የመጨረሻውን አሃዝ በተከታታይ መቀነስ እና ይህ ጥሩው ሪፓር መሆኑን ማረጋገጥ አለብን።
    // ቢበዛ 9 እጩዎች አሉ (..1 እስከ ..9) ፣ ስለሆነም ይህ በፍጥነት ፈጣን ነው ፡፡("rounding" phase)
    //
    // ይህ የ "optimal" repr በእውነቱ በሆስፒታሎች ክልል ውስጥ ከሆነ ተግባሩ ይፈትሻል ፣ እና ደግሞ ፣ "second-to-optimal" repr በተጠጋጋው ስህተት ምክንያት በጣም ጥሩ ሊሆን ይችላል።
    // በሁለቱም ሁኔታዎች ይህ `None` ን ይመልሳል።
    // ("weeding" phase)
    //
    // እዚህ ያሉት ሁሉም ክርክሮች በተለመደው (ግን ግልጽ በሆነ) እሴት `k` የተመዘኑ ናቸው ፣ ስለሆነም
    // - `remainder = (plus1 % 10^kappa) * k`
    // - `threshold = (plus1 - minus1) * k` (እና ደግሞ ፣ `remainder < threshold`)
    // - `plus1v = (plus1 - v) * k` (እና በተጨማሪ ፣ ከቀድሞ የማይለወጡ `threshold > plus1v`)
    // - `ten_kappa = 10^kappa * k`
    // - `ulp = 2^-e * k`
    //
    fn round_and_weed(
        buf: &mut [u8],
        exp: i16,
        remainder: u64,
        threshold: u64,
        plus1v: u64,
        ten_kappa: u64,
        ulp: u64,
    ) -> Option<(&[u8], i16)> {
        assert!(!buf.is_empty());

        // በ 1.5 ቁስሎች ውስጥ ወደ `v` (በትክክል `plus1 - v`) ሁለት ግምቶችን ያመርቱ ፡፡
        // የተገኘው ውክልና ለሁለቱም በጣም የቅርብ ተወካይ መሆን አለበት ፡፡
        //
        // overflow/underflow ን ለማስቀረት ስሌቶች ከ `plus1` አንጻር ስለሚከናወኑ እዚህ `plus1 - v` ጥቅም ላይ ይውላል (ስለሆነም የተለወጡት የሚመስሉ ስሞች) ፡፡
        //
        let plus1v_down = plus1v + ulp; // plus1 - (v, 1 ulp)
        let plus1v_up = plus1v - ulp; // plus1 - (v + 1 ulp)

        // የመጨረሻውን አሃዝ በመቀነስ ወደ `v + 1 ulp` ቅርበት ባለው ውክልና ላይ ያቁሙ።
        let mut plus1w = remainder; // plus1w(n) = plus1, w(n)
        {
            let last = buf.last_mut().unwrap();

            // እኛ ከ `plus1 - plus1 % 10^kappa` ጋር እኩል በሆነው በግምታዊ ቁጥሮች `w(n)` እንሰራለን።የሉቱን አካል `n` ጊዜ ከሠራ በኋላ ፣ `w(n) = plus1 - plus1 % 10^kappa - n * 10^kappa`.
            // እኛ `plus1w(n) = plus1 - w(n) = plus1 % 10^kappa + n * 10^kappa` ን (ቼኮችን ለማቃለል `ቀሪ= plus1w(0)`) ን አዘጋጅተናል) ፡፡
            // `plus1w(n)` ሁልጊዜ እየጨመረ መሆኑን ልብ ይበሉ።
            //
            // ለማቋረጥ ሦስት ቅድመ ሁኔታዎች አሉን ፡፡አንዳቸውም ቢሆኑ መቀጠሉን ለመቀጠል ያቅታቸዋል ፣ ግን ለማንኛውም ቢያንስ ለ `v + 1 ulp` ቅርበት ያለው ቢያንስ አንድ ትክክለኛ ውክልና አለን ፡፡
            // ለእነሱ አጭርነት ከ TC1 እስከ TC3 ብለን እንጠራቸዋለን ፡፡
            //
            // TC1: `w(n) <= v + 1 ulp` ፣ ማለትም ፣ ይህ በጣም የቅርብ ሊሆን የሚችል የመጨረሻው repr ነው።
            // ይህ ከ `plus1 - w(n) = plus1w(n) >= plus1 - (v + 1 ulp) = plus1v_up` ጋር እኩል ነው።
            // ከ TC2 ጋር ተደባልቆ (`w(n+1)` is valid) ን ይፈትሻል ፣ ይህ በ `plus1w(n)` ስሌት ላይ ሊኖር ከሚችለው ፍሰት ይከላከላል) ፡፡
            //
            // TC2: `w(n+1) < minus1` ፣ ማለትም ፣ ቀጣዩ repr በእርግጠኝነት ወደ `v` አይዞርም።
            // ይህ ከ `plus1 - w(n) + 10^kappa = plus1w(n) + 10^kappa > plus1 - minus1 = threshold` ጋር እኩል ነው።
            // የግራ እጅ ጎርፍ ሊፈስ ይችላል ፣ ግን እኛ `threshold > plus1v` ን እናውቃለን ፣ ስለሆነም TC1 ውሸት ከሆነ ፣ `threshold - plus1w(n) > threshold - (plus1v - 1 ulp) > 1 ulp` እና በምትኩ `threshold - plus1w(n) < 10^kappa` ከሆነ ደህንነቱ በተጠበቀ ሁኔታ መሞከር እንችላለን።
            //
            //
            // TC3: `abs(w(n) - (v + 1 ulp)) <= abs(w(n+1) - (v + 1 ulp))` ፣ ማለትም ፣ ቀጣዩ repr ነው
            // ከአሁኑ repr ወደ `v + 1 ulp` ቅርበት የለውም።
            // የተሰጠው `z(n) = plus1v_up - plus1w(n)` ፣ ይህ `abs(z(n)) <= abs(z(n+1))` ይሆናል።እንደገና TC1 ውሸት ነው ብለን ካሰብን ፣ `z(n) > 0` አለን ፡፡ከግምት ውስጥ መግባት ያለብን ሁለት ጉዳዮች አሉን
            //
            // - `z(n+1) >= 0` መቼ TC3 `z(n) <= z(n+1)` ይሆናል።
            // `plus1w(n)` እየጨመረ እንደመጣ ፣ `z(n)` እየቀነሰ መሆን አለበት እና ይህ በግልጽ ሐሰት ነው።
            // - `z(n+1) < 0` መቼ
            //   - TC3a: ቅድመ ሁኔታው `plus1v_up < plus1w(n) + 10^kappa` ነው።TC2 ውሸት ነው ብሎ ካሰበ `threshold >= plus1w(n) + 10^kappa` ስለሆነም ሊፈስ አይችልም።
            //   - TC3b: TC3 `z(n) <= -z(n+1)` ይሆናል ፣ ማለትም ፣ `plus1v_up - plus1w(n) >=     plus1w(n+1) - plus1v_up = plus1w(n) + 10^kappa - plus1v_up`.
            //   የተሳነው TC1 `plus1v_up > plus1w(n)` ን ይሰጣል ፣ ስለሆነም ከ TC3a ጋር ሲደመር ሊፈስ ወይም ሊጥለቀለቅ አይችልም።
            //
            // ስለሆነም `TC1 || TC2 || (TC3a && TC3b)` ን ማቆም አለብን ፡፡የሚከተለው ከተቃራኒው ጋር እኩል ነው ፣ `!TC1 && !TC2 && (!TC3a || !TC3b)`.
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            while plus1w < plus1v_up
                && threshold - plus1w >= ten_kappa
                && (plus1w + ten_kappa < plus1v_up
                    || plus1v_up - plus1w >= plus1w + ten_kappa - plus1v_up)
            {
                *last -= 1;
                debug_assert!(*last > b'0'); // በጣም አጭር repr በ `0` ሊጨርስ አይችልም
                plus1w += ten_kappa;
            }
        }

        // ይህ ውክልና ከ `v - 1 ulp` ጋር በጣም የቀረበ ውክልና መሆኑን ያረጋግጡ ፡፡
        //
        // ይህ በቀላሉ ለ `v + 1 ulp` የማቆሚያ ሁኔታዎች ተመሳሳይ ነው ፣ ሁሉም `plus1v_up` በምትኩ በ `plus1v_down` ተተክቷል።
        // የተትረፈረፈ ትንተና እኩል ይይዛል ፡፡
        if plus1w < plus1v_down
            && threshold - plus1w >= ten_kappa
            && (plus1w + ten_kappa < plus1v_down
                || plus1v_down - plus1w >= plus1w + ten_kappa - plus1v_down)
        {
            return None;
        }

        // አሁን በ `plus1` እና `minus1` መካከል ወደ `v` የቀረበ ውክልና አለን ፡፡
        // ምንም እንኳን ይህ በጣም ሊበራል ነው ፣ ስለሆነም በ `plus0` እና `minus0` ፣ ማለትም በ `plus1 - plus1w(n) <= minus0` ወይም `plus1 - plus1w(n) >= plus0` መካከል ያልሆነን ማንኛውንም `w(n)` እንቀበላለን።
        // እኛ `threshold = plus1 - minus1` እና `plus1 - plus0 = minus0 - minus1 = 2 ulp` ያሏቸውን እውነታዎች እንጠቀማለን ፡፡
        //
        if 2 * ulp <= plus1w && plus1w <= threshold - 4 * ulp { Some((buf, exp)) } else { None }
    }
}

/// እጅግ በጣም አጭር የአተገባበር አተገባበር ለግሪሱ ከድራጎን ውድቀት ጋር ፡፡
///
/// ይህ ለአብዛኛዎቹ ጉዳዮች ጥቅም ላይ መዋል አለበት ፡፡
pub fn format_shortest<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    use crate::num::flt2dec::strategy::dragon::format_shortest as fallback;
    // ደህንነት: የብድር መመርመሪያው `buf` ን እንድንጠቀምበት ብልህ አይደለም
    // በሁለተኛው branch ውስጥ ፣ ስለዚህ የሕይወት ዘመናችንን እዚህ እናጠፋለን ፡፡
    // ግን `format_shortest_opt` `None` ን ከተመለሰ `buf` ን ብቻ እንደገና እንጠቀማለን ስለዚህ ይህ ጥሩ ነው ፡፡
    match format_shortest_opt(d, unsafe { &mut *(buf as *mut _) }) {
        Some(ret) => ret,
        None => fallback(d, buf),
    }
}

/// ለግሪሱ ትክክለኛ እና ቋሚ ሁነታ አተገባበር።
///
/// በሌላ መንገድ ያልነበረ ውክልና ሲመልስ `None` ን ይመልሳል።
pub fn format_exact_opt<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> Option<(/*digits*/ &'a [u8], /*exp*/ i16)> {
    assert!(d.mant > 0);
    assert!(d.mant < (1 << 61)); // ተጨማሪ ትክክለኛነት ቢያንስ ሦስት ቢቶች ያስፈልጉናል
    assert!(!buf.is_empty());

    // `v` ን መደበኛ እና ሚዛን ያድርጉ።
    let v = Fp { f: d.mant, e: d.exp }.normalize();
    let (minusk, cached) = cached_power(ALPHA - v.e - 64, GAMMA - v.e - 64);
    let v = v.mul(&cached);

    // `v` ን ወደ ወሳኝ እና ክፍልፋይ ክፍሎች ይከፋፍሉ።
    let e = -v.e as usize;
    let vint = (v.f >> e) as u32;
    let vfrac = v.f & ((1 << e) - 1);

    // ሁለቱም አሮጌ `v` እና አዲሱ `v` (በ `10^-k` ተመን) የ <1 ulp (Theorem 5.1) ስህተት አላቸው።
    // ስህተቱ አዎንታዊ ወይም አሉታዊ መሆኑን ስለማናውቅ በእኩል ርቀት የተቀመጡ ሁለት ግምቶችን እንጠቀማለን እና ከፍተኛው የ 2 ቁስሎች ስህተት (ከአጭሩ ጉዳይ ጋር ተመሳሳይ ነው) ፡፡
    //
    //
    // ዓላማው ለሁለቱም በ `v - 1 ulp` እና `v + 1 ulp` የተለመዱትን በትክክል የተጠጋጋ ተከታታይ አሃዞችን መፈለግ ነው ፣ ስለሆነም በከፍተኛ ደረጃ እንተማመናለን ፡፡
    // ይህ የማይቻል ከሆነ ፣ ለ‹`v` X›ትክክለኛ ውጤት የትኛው እንደሆነ አናውቅም ፣ ስለዚህ ተስፋ ቆርጠን ወደ ኋላ እንመለሳለን ፡፡
    //
    // `err` እዚህ `1 ulp * 2^e` ተብሎ ይገለጻል (በ `vfrac` ውስጥ ካለው ተመሳሳይ ጋር ተመሳሳይ ነው) ፣ እና `v` በሚለካበት ጊዜ ሁሉ እንለካለን።
    //
    //
    //
    let mut err = 1;

    // ትልቁን `10^max_kappa` ከ `v` ያልበለጠ ያስሉ (ስለሆነም `v < 10^(max_kappa+1)`)።
    // ይህ ከታች የ `kappa` የላይኛው ወሰን ነው።
    let (max_kappa, max_ten_kappa) = max_pow10_no_more_than(vint);

    let mut i = 0;
    let exp = max_kappa as i16 - minusk + 1;

    // ከመጨረሻው አሃዝ ውስንነት ጋር የምንሰራ ከሆነ ድርብ ማዞሪያን ለማስቀረት ቋቱን ከእውነተኛው አተገባበር ማሳጠር አለብን ፡፡
    //
    // ማጠናከሪያ በሚከሰትበት ጊዜ እንደገና መያዣውን እንደገና ማስፋት እንዳለብን ልብ ይበሉ!
    let len = if exp <= limit {
        // ውይ ፣*አንድ* አሃዝ እንኳን ማምረት አንችልም።
        // ይህ እንደ 9.5 ያለ አንድ ነገር አግኝተን ወደ 10 እየተጠጋ ነው ማለት ይቻላል ፡፡
        //
        // በመርህ ደረጃ ወዲያውኑ `possibly_round` ን በባዶ ቋት መደወል እንችላለን ፣ ግን `max_ten_kappa << e` ን በ 10 ማጠንጠን ከመጠን በላይ ሊያስከትል ይችላል ፡፡
        //
        // ስለሆነም እዚህ ደደብ ነን እና የስህተት ወሰን በ 10 እጥፍ ከፍ እናደርጋለን።
        // ይህ የውሸት አሉታዊ ምጣኔን ይጨምራል ፣ ግን በጣም ፣*በጣም* ትንሽ ብቻ ነው።
        // ማንነቱሳ ከ 60 ቢት ሲበልጥ ብቻ ሊታይ ይችላል ፡፡
        //
        // ደህንነት: `len=0` ፣ ስለዚህ ይህንን ማህደረ ትውስታ የማስጀመር ግዴታ ቀላል አይደለም።
        return unsafe {
            possibly_round(buf, 0, exp, limit, v.f / 10, (max_ten_kappa as u64) << e, err << e)
        };
    } else if ((exp as i32 - limit as i32) as usize) < buf.len() {
        (exp - limit) as usize
    } else {
        buf.len()
    };
    debug_assert!(len > 0);

    // ወሳኝ ክፍሎችን ያቅርቡ ፡፡
    // ስህተቱ ሙሉ በሙሉ የተከፋፈለ ነው ፣ ስለሆነም በዚህ ክፍል ውስጥ መፈተሽ አያስፈልገንም ፡፡
    let mut kappa = max_kappa as i16;
    let mut ten_kappa = max_ten_kappa; // 10^kappa
    let mut remainder = vint; // አኃዞች ገና ሊሰጡ
    loop {
        // የማይለወጡ ሰዎችን ለማቅረብ ቢያንስ አንድ አሃዝ አለን
        // - `remainder < 10^(kappa+1)`
        // - `vint = d[0..n-1] * 10^(kappa+1) + remainder`   (ያንን `remainder = vint % 10^(kappa+1)` ይከተላል)
        //
        //

        // `remainder` ን በ `10^kappa` ይከፋፍሉ።ሁለቱም በ `2^-e` ተመዝነዋል።
        let q = remainder / ten_kappa;
        let r = remainder % ten_kappa;
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        // ቋቱ ሞልቷል?ከቀሪው ጋር የማዞሪያውን መተላለፊያ ያሂዱ ፡፡
        if i == len {
            let vrem = ((r as u64) << e) + vfrac; // ==(v% 10 ^ ካፓ) * 2 ^ e
            // ደህንነት-እኛ `len` ብዙ ባይት አስጀምረናል ፡፡
            return unsafe {
                possibly_round(buf, len, exp, limit, vrem, (ten_kappa as u64) << e, err << e)
            };
        }

        // ሁሉንም አስፈላጊ አሃዞች በሠጠነው ጊዜ ቀለበቱን ይሰብሩ ፡፡
        // የአሃዞች ትክክለኛ ቁጥር `max_kappa + 1` እንደ `plus1 < 10^(max_kappa+1)` ነው።
        if i > max_kappa as usize {
            debug_assert_eq!(ten_kappa, 1);
            debug_assert_eq!(kappa, 0);
            break;
        }

        // የማይለወጡትን ይመልሱ
        kappa -= 1;
        ten_kappa /= 10;
        remainder = r;
    }

    // ክፍልፋዮችን ይስጡ
    //
    // በመርህ ደረጃ እስከ መጨረሻው ባለው አሃዝ መቀጠል እና ትክክለኛነቱን ማረጋገጥ እንችላለን ፡፡
    // በሚያሳዝን ሁኔታ እኛ ውስን ከሆኑ መጠኖች ጋር እየሰራን ነው ፣ ስለሆነም የተትረፈረፈውን ፍሰት ለመለየት አንዳንድ መመዘኛዎች ያስፈልጉናል ፡፡
    // V8 የ `v - 1 ulp` እና `v` የመጀመሪያዎቹ `i` ጉልህ ቁጥሮች ሲለያዩ ሐሰት የሚሆነው `remainder > err` ን ይጠቀማል።
    // ሆኖም ይህ በጣም ብዙ ካልሆነ ተቀባይነት ያለው ግቤትን አይቀበልም።
    //
    // የኋለኛው ክፍል ትክክለኛ የትርፍ ፍሰት ማወቂያ ስላለው በምትኩ ጠንከር ያለ መስፈርት እንጠቀማለን
    // በ `v - 1 ulp` እና `v + 1 ulp` መካከል ያለው ክልል በእርግጠኝነት ሁለት ወይም ከዚያ በላይ የተጠጋጋ ውክልናዎችን የያዘ በመሆኑ `err` ከ `10^kappa / 2` እስከሚበልጥ ድረስ እንቀጥላለን።
    //
    // ለማጣቀሻ ይህ ከ `possibly_round` የመጀመሪያዎቹ ሁለት ንፅፅሮች ጋር ተመሳሳይ ነው ፡፡
    //
    let mut remainder = vfrac;
    let maxerr = 1 << (e - 1);
    while err < maxerr {
        // የማይለዋወጥ, የት `m = max_kappa + 1` (በቁጥር አካል ውስጥ#ቁጥሮች):
        // - `remainder < 2^e`
        // - `vfrac * 10^(n-m) = d[m..n-1] * 2^e + remainder`
        // - `err = 10^(n-m)`

        remainder *= 10; // አይፈስም ፣ `2^e * 10 < 2^64`
        err *= 10; // አይፈስም ፣ `err * 10 < 2^e * 5 < 2^64`

        // `remainder` ን በ `10^kappa` ይከፋፍሉ።
        // ሁለቱም በ `2^e / 10^kappa` የተመዘኑ ናቸው ፣ ስለሆነም የመጨረሻው እዚህ ላይ ተካትቷል።
        let q = remainder >> e;
        let r = remainder & ((1 << e) - 1);
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        // ቋቱ ሞልቷል?ከቀሪው ጋር የማዞሪያውን መተላለፊያ ያሂዱ ፡፡
        if i == len {
            // ደህንነት-እኛ `len` ብዙ ባይት አስጀምረናል ፡፡
            return unsafe { possibly_round(buf, len, exp, limit, r, 1 << e, err) };
        }

        // የማይለወጡትን ይመልሱ
        remainder = r;
    }

    // ተጨማሪ ስሌት ዋጋ የለውም (`possibly_round` በእርግጠኝነት አልተሳካም) ፣ ስለሆነም ተስፋ እንቆርጣለን።
    return None;

    // ሁሉንም የተጠየቁ የ `v` ቁጥሮች አመንጭተናል ፣ ይህ ደግሞ ከ‹XXXX›አሃዞች ጋር ተመሳሳይ መሆን አለበት ፡፡
    // አሁን በ `v - 1 ulp` እና `v + 1 ulp` የተጋራ ልዩ ውክልና ካለ እናረጋግጣለን ፡፡ይህ ለተፈጠሩ አሃዞች ወይም ለእነዚያ ቁጥሮች በተጠጋጋ ስሪት ተመሳሳይ ሊሆን ይችላል ፡፡
    //
    // ክልሉ ተመሳሳይ ርዝመት ያላቸውን በርካታ ውክልናዎችን የያዘ ከሆነ እርግጠኛ መሆን አንችልም እናም በምትኩ `None` ን መመለስ አለብን።
    //
    // እዚህ ያሉት ሁሉም ክርክሮች በተለመደው (ግን ግልጽ በሆነ) እሴት `k` የተመዘኑ ናቸው ፣ ስለሆነም
    // - `remainder = (v % 10^kappa) * k`
    // - `ten_kappa = 10^kappa * k`
    // - `ulp = 2^-e * k`
    //
    // ደህንነት-የ `buf` የመጀመሪያ `len` ባይት መጀመር አለበት ፡፡
    //
    unsafe fn possibly_round(
        buf: &mut [MaybeUninit<u8>],
        mut len: usize,
        mut exp: i16,
        limit: i16,
        remainder: u64,
        ten_kappa: u64,
        ulp: u64,
    ) -> Option<(&[u8], i16)> {
        debug_assert!(remainder < ten_kappa);

        // 10^kappa
        //    :   :   :<->:   :
        //    :   :   :   :   :
        //    : | 1 ulp | 1 ulp |:
        //    :|<--->|<--->|  :
        // ----|-----|-----|----
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // (ለማጣቀሻው የነጥብ መስመሩ በተሰጠው አኃዝ ቁጥር ውስጥ ለሚኖሩ ውክልናዎች ትክክለኛውን ዋጋ ያሳያል ፡፡)
        //
        //
        // ስህተቱ በጣም ትልቅ ስለሆነ በ `v - 1 ulp` እና `v + 1 ulp` መካከል ቢያንስ ሦስት ሊሆኑ የሚችሉ ውክልናዎች አሉ ፡፡
        // የትኛው ትክክል እንደሆነ መወሰን አንችልም ፡፡
        //
        if ulp >= ten_kappa {
            return None;
        }

        // 10^kappa
        //   :<------->:
        //   :         :
        //   : | 1 ulp | 1 ulp |
        //   : |<--->|<--->|
        // ----|-----|-----|----
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // በእውነቱ ፣ 1/2 ulp ሁለት ሊሆኑ የሚችሉ ተወካዮችን ለማስተዋወቅ በቂ ነው ፡፡
        // (ለሁለቱም `v - 1 ulp` እና ለ `v + 1 ulp` ልዩ ውክልና እንደሚያስፈልገን ያስታውሱ ፡፡) ይህ ከመጀመሪያው ቼክ `ulp < ten_kappa` እንደመሆኑ መጠን ይህ አይፈስም ፡፡
        //
        //
        if ten_kappa - ulp <= ulp {
            return None;
        }

        // remainder
        //       :<->|                           :
        //       :   |                           :
        //       :----10 ^ ካፓ---------->
        //     | :   |                           :
        //     | 1 pል | 1 pል |:
        //     |<--->|<--->|                     :
        // ----|-----|-----|------------------------
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // `v + 1 ulp` ወደ የተጠጋጋ ወደታች ውክልና ቅርብ ከሆነ (ቀድሞውኑ በ `buf` ውስጥ ካለ) ከዚያ በደህና መመለስ እንችላለን።
        // ልብ ይበሉ `v - 1 ulp` * ከአሁኑ ውክልና ያነሰ ሊሆን ይችላል ፣ ግን እንደ `1 ulp < 10^kappa / 2` ፣ ይህ ሁኔታ በቂ ነው
        // በ `v - 1 ulp` እና አሁን ባለው ውክልና መካከል ያለው ርቀት ከ `10^kappa / 2` መብለጥ አይችልም።
        //
        // ሁኔታው ከ `remainder + ulp < 10^kappa / 2` ጋር እኩል ነው።
        // ይህ በቀላሉ ሊፈስ ስለሚችል በመጀመሪያ `remainder < 10^kappa / 2` ን ያረጋግጡ ፡፡
        // `ulp < 10^kappa / 2` ን ቀድሞውኑ አረጋግጠናል ፣ ስለሆነም `10^kappa` ከሁሉም በላይ እስካልተፈሰሰ ድረስ ሁለተኛው ቼክ ጥሩ ነው ፡፡
        //
        //
        //
        //
        if ten_kappa - remainder > remainder && ten_kappa - 2 * remainder >= 2 * ulp {
            // ደህንነት ደዋችን ያንን ትውስታ አስነሳ ፡፡
            return Some((unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, exp));
        }

        // :---ቀሪ------> |:
        //   :                          |   :
        //   :----10 ^ ካፓ--------->
        //   :                    |     |   : |
        //   : | 1 ulp | 1 ulp |
        //   :                    |<--->|<--->|
        // -----------------------|-----|-----|-----
        //                        |     v     |                    v - 1 ulp   v + 1 ulp
        //
        // በሌላ በኩል ፣ `v - 1 ulp` ወደ የተጠጋጋው ውክልና ቅርብ ከሆነ ፣ መሰብሰብ እና መመለስ አለብን።
        // በተመሳሳይ ምክንያት `v + 1 ulp` ን ማረጋገጥ አያስፈልገንም ፡፡
        //
        // ሁኔታው ከ `remainder - ulp >= 10^kappa / 2` ጋር እኩል ነው።
        // እንደገና በመጀመሪያ `remainder > ulp` ን እንፈትሻለን (`10^kappa` በጭራሽ ዜሮ ስለማይሆን ይህ `remainder >= ulp` አለመሆኑን ልብ ይበሉ) ፡፡
        //
        // በተጨማሪም `remainder - ulp <= 10^kappa` ን ያስተውሉ ፣ ስለዚህ ሁለተኛው ቼክ ሞልቶ አይፈስበትም።
        //
        if remainder > ulp && ten_kappa - (remainder - ulp) <= remainder - ulp {
            if let Some(c) =
                // ደህንነት ደዋችን ያንን የማስታወስ ችሎታ የጀመረው መሆን አለበት ፡፡
                round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..len]) })
            {
                // የተስተካከለ ትክክለኛነት ሲጠየቀን ብቻ ተጨማሪ አሃዝ ይጨምሩ።
                // እኛ ደግሞ ማረጋገጥ አለብን ፣ የመጀመሪያው ቋት ባዶ ከሆነ ፣ ተጨማሪ አሃዙ ሊታከል የሚችለው `exp == limit` (edge ጉዳይ) ሲኖር ብቻ ነው።
                //
                exp += 1;
                if exp > limit && len < buf.len() {
                    buf[len] = MaybeUninit::new(c);
                    len += 1;
                }
            }
            // ደህንነት: እኛ እና የእኛ ደዋይ ያንን ትውስታ ጀመርን ፡፡
            return Some((unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, exp));
        }

        // አለበለዚያ እኛ ተፈርደናል (ማለትም ፣ በ `v - 1 ulp` እና `v + 1 ulp` መካከል ያሉ አንዳንድ እሴቶች እየከበዱ ሌሎች ደግሞ እየተጠናከሩ ናቸው) እናም ተስፋ እንቆርጣለን።
        //
        None
    }
}

/// ትክክለኛው እና የቋሚ ሁነታ አተገባበር ለግሪሱ ከድራጎን ውድቀት ጋር።
///
/// ይህ ለአብዛኛዎቹ ጉዳዮች ጥቅም ላይ መዋል አለበት ፡፡
pub fn format_exact<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    use crate::num::flt2dec::strategy::dragon::format_exact as fallback;
    // ደህንነት: የብድር መመርመሪያው `buf` ን እንድንጠቀምበት ብልህ አይደለም
    // በሁለተኛው branch ውስጥ ፣ ስለዚህ የሕይወት ዘመናችንን እዚህ እናጠፋለን ፡፡
    // ግን `format_exact_opt` `None` ን ከተመለሰ `buf` ን ብቻ እንደገና እንጠቀማለን ስለዚህ ይህ ጥሩ ነው ፡፡
    match format_exact_opt(d, unsafe { &mut *(buf as *mut _) }, limit) {
        Some(ret) => ret,
        None => fallback(d, buf, limit),
    }
}