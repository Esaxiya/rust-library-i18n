/*!

Floating-point number to decimal conversion routines.

# Problem statement

We are given the floating-point number `v = f * 2^e` with an integer `f`,
and its bounds `minus` and `plus` such that any number between `v - minus` and
`v + plus` will be rounded to `v`. For the simplicity we assume that
this range is exclusive. Then we would like to get the unique decimal
representation `V = 0.d[0..n-1] * 10^k` such that:

- `d[0]` is non-zero.

- It's correctly rounded when parsed back: `v - minus < V < v + plus`.
  Furthermore it is shortest such one, i.e., there is no representation
  with less than `n` digits that is correctly rounded.

- It's closest to the original value: `abs(V - v) <= 10^(k-n) / 2`. Note that
  there might be two representations satisfying this uniqueness requirement,
  in which case some tie-breaking mechanism is used.

We will call this mode of operation as to the *shortest* mode. This mode is used
when there is no additional constraint, and can be thought as a "natural" mode
as it matches the ordinary intuition (it at least prints `0.1f32` as "0.1").

We have two more modes of operation closely related to each other. In these modes
we are given either the number of significant digits `n` or the last-digit
limitation `limit` (which determines the actual `n`), and we would like to get
the representation `V = 0.d[0..n-1] * 10^k` such that:

- `d[0]` is non-zero, unless `n` was zero in which case only `k` is returned.

- It's closest to the original value: `abs(V - v) <= 10^(k-n) / 2`. Again,
  there might be some tie-breaking mechanism.

When `limit` is given but not `n`, we set `n` such that `k - n = limit`
so that the last digit `d[n-1]` is scaled by `10^(k-n) = 10^limit`.
If such `n` is negative, we clip it to zero so that we will only get `k`.
We are also limited by the supplied buffer. This limitation is used to print
the number up to given number of fractional digits without knowing
the correct `k` beforehand.

We will call the mode of operation requiring `n` as to the *exact* mode,
and one requiring `limit` as to the *fixed* mode. The exact mode is a subset of
the fixed mode: the sufficiently large last-digit limitation will eventually fill
the supplied buffer and let the algorithm to return.

# Implementation overview

It is easy to get the floating point printing correct but slow (Russ Cox has
[demonstrated](http://research.swtch.com/ftoa) how it's easy), or incorrect but
fast (naïve division and modulo). But it is surprisingly hard to print
floating point numbers correctly *and* efficiently.

There are two classes of algorithms widely known to be correct.

- The "Dragon" family of algorithm is first described by Guy L. Steele Jr. and
  Jon L. White. They rely on the fixed-size big integer for their correctness.
  A slight improvement was found later, which is posthumously described by
  Robert G. Burger and R. Kent Dybvig. David Gay's `dtoa.c` routine is
  a popular implementation of this strategy.

- The "Grisu" family of algorithm is first described by Florian Loitsch.
  They use very cheap integer-only procedure to determine the close-to-correct
  representation which is at least guaranteed to be shortest. The variant,
  Grisu3, actively detects if the resulting representation is incorrect.

We implement both algorithms with necessary tweaks to suit our requirements.
In particular, published literatures are short of the actual implementation
difficulties like how to avoid arithmetic overflows. Each implementation,
available in `strategy::dragon` and `strategy::grisu` respectively,
extensively describes all necessary justifications and many proofs for them.
(It is still difficult to follow though. You have been warned.)

Both implementations expose two public functions:

- `format_shortest(decoded, buf)`, which always needs at least
  `MAX_SIG_DIGITS` digits of buffer. Implements the shortest mode.

- `format_exact(decoded, buf, limit)`, which accepts as small as
  one digit of buffer. Implements exact and fixed modes.

They try to fill the `u8` buffer with digits and returns the number of digits
written and the exponent `k`. They are total for all finite `f32` and `f64`
inputs (Grisu internally falls back to Dragon if necessary).

The rendered digits are formatted into the actual string form with
four functions:

- `to_shortest_str` prints the shortest representation, which can be padded by
  zeroes to make *at least* given number of fractional digits.

- `to_shortest_exp_str` prints the shortest representation, which can be
  padded by zeroes when its exponent is in the specified ranges,
  or can be printed in the exponential form such as `1.23e45`.

- `to_exact_exp_str` prints the exact representation with given number of
  digits in the exponential form.

- `to_exact_fixed_str` prints the fixed representation with *exactly*
  given number of fractional digits.

They all return a slice of preallocated `Part` array, which corresponds to
the individual part of strings: a fixed string, a part of rendered digits,
a number of zeroes or a small (`u16`) number. The caller is expected to
provide a large enough buffer and `Part` array, and to assemble the final
string from resulting `Part`s itself.

All algorithms and formatting functions are accompanied by extensive tests
in `coretests::num::flt2dec` module. It also shows how to use individual
functions.

*/

// ይህ በሰነድ የተዘገበ ቢሆንም ይህ በመርህ ደረጃ የግል ነው ይህም ለሙከራ ብቻ ይፋ ይደረጋል ፡፡
// አታጋልጠን ፡፡
#![doc(hidden)]
#![unstable(
    feature = "flt2dec",
    reason = "internal routines only exposed for testing",
    issue = "none"
)]

pub use self::decoder::{decode, DecodableFloat, Decoded, FullDecoded};

use crate::mem::MaybeUninit;

pub mod decoder;
pub mod estimator;

/// ዲጂት-ትውልድ ስልተ ቀመሮች።
pub mod strategy {
    pub mod dragon;
    pub mod grisu;
}

/// ለአጭሩ ሁነታ አስፈላጊው የመጠባበቂያ ቋት መጠን።
///
/// ለማውጣቱ ትንሽ ቀላል አይደለም ፣ ግን ይህ እጅግ በጣም አነስተኛ በሆነ ውጤት ስልተ ቀመሮችን ከቅርጸት ቅርጸቶች ከፍተኛ እና ከፍተኛ የአስርዮሽ ቁጥሮች ነው ፡፡
///
/// ትክክለኛው ቀመር `ceil(# bits in mantissa * log_10 2 + 1)` ነው።
pub const MAX_SIG_DIGITS: usize = 17;

/// `d` የአስርዮሽ አሃዞችን ሲይዝ የመጨረሻውን አሃዝ ይጨምሩ እና ተሸካሚውን ያስፋፉ።
/// ርዝመቱ እንዲለወጥ ሲያደርግ የሚቀጥለውን አሃዝ ይመልሳል።
#[doc(hidden)]
pub fn round_up(d: &mut [u8]) -> Option<u8> {
    match d.iter().rposition(|&c| c != b'9') {
        Some(i) => {
            // d [i + 1..n] ሁሉም ዘጠኝ ነው
            d[i] += 1;
            for j in i + 1..d.len() {
                d[j] = b'0';
            }
            None
        }
        None if d.len() > 0 => {
            // 999..999 ዙሮች ወደ 1000..000 ከተጨመረ ኤክስፖርት ጋር
            d[0] = b'1';
            for j in 1..d.len() {
                d[j] = b'0';
            }
            Some(b'0')
        }
        None => {
            // ባዶ ቋት (ትንሽ እንግዳ ነገር ግን ምክንያታዊ)
            Some(b'1')
        }
    }
}

/// የተቀረጹ ክፍሎች.
#[derive(Copy, Clone, PartialEq, Eq, Debug)]
pub enum Part<'a> {
    /// የተሰጠው የዜሮ ቁጥሮች።
    Zero(usize),
    /// ቃል በቃል እስከ 5 አሃዞች።
    Num(u16),
    /// የተሰጡ ባይት የቃል ቃል ቅጅ
    Copy(&'a [u8]),
}

impl<'a> Part<'a> {
    /// የተሰጠውን ክፍል ትክክለኛውን ባይት ርዝመት ይመልሳል።
    pub fn len(&self) -> usize {
        match *self {
            Part::Zero(nzeroes) => nzeroes,
            Part::Num(v) => {
                if v < 1_000 {
                    if v < 10 {
                        1
                    } else if v < 100 {
                        2
                    } else {
                        3
                    }
                } else {
                    if v < 10_000 { 4 } else { 5 }
                }
            }
            Part::Copy(buf) => buf.len(),
        }
    }

    /// በቀረበው ቋት ውስጥ አንድ ክፍል ይጽፋል ፡፡
    /// የጽሑፍ ባይት ብዛት ወይም `None` መያዣው በቂ ካልሆነ ይመልሳል።
    /// (አሁንም በመጠባበቂያው ውስጥ በከፊል የተፃፉ ባይት ሊተው ይችላል ፣ በዚያ ላይ አይመኑ ፡፡)
    pub fn write(&self, out: &mut [u8]) -> Option<usize> {
        let len = self.len();
        if out.len() >= len {
            match *self {
                Part::Zero(nzeroes) => {
                    for c in &mut out[..nzeroes] {
                        *c = b'0';
                    }
                }
                Part::Num(mut v) => {
                    for c in out[..len].iter_mut().rev() {
                        *c = b'0' + (v % 10) as u8;
                        v /= 10;
                    }
                }
                Part::Copy(buf) => {
                    out[..buf.len()].copy_from_slice(buf);
                }
            }
            Some(len)
        } else {
            None
        }
    }
}

/// አንድ ወይም ከዚያ በላይ ክፍሎችን የያዘ የቅርጽ ውጤት።
/// ይህ ወደ ባይት ቋት ሊፃፍ ወይም ወደተመደበው ገመድ ሊቀየር ይችላል።
#[allow(missing_debug_implementations)]
#[derive(Clone)]
pub struct Formatted<'a> {
    /// ምልክትን የሚወክል ባይት ቁራጭ ፣ `""` ፣ `"-"` ወይም `"+"` ፡፡
    pub sign: &'static str,
    /// የተቀረጹ ክፍሎች ከምልክት እና ከአማራጭ ዜሮ መቅዘፊያ በኋላ እንዲሰጡ ይደረጋል።
    pub parts: &'a [Part<'a>],
}

impl<'a> Formatted<'a> {
    /// የተዋሃደ የተቀረጸ ውጤት ትክክለኛውን ባይት ርዝመት ይመልሳል።
    pub fn len(&self) -> usize {
        let mut len = self.sign.len();
        for part in self.parts {
            len += part.len();
        }
        len
    }

    /// ሁሉንም የተቀረጹ ክፍሎች በተጠቀሰው ቋት ውስጥ ይጽፋል።
    /// የጽሑፍ ባይት ብዛት ወይም `None` መያዣው በቂ ካልሆነ ይመልሳል።
    /// (አሁንም በመጠባበቂያው ውስጥ በከፊል የተፃፉ ባይት ሊተው ይችላል ፣ በዚያ ላይ አይመኑ ፡፡)
    pub fn write(&self, out: &mut [u8]) -> Option<usize> {
        if out.len() < self.sign.len() {
            return None;
        }
        out[..self.sign.len()].copy_from_slice(self.sign.as_bytes());

        let mut written = self.sign.len();
        for part in self.parts {
            let len = part.write(&mut out[written..])?;
            written += len;
        }
        Some(written)
    }
}

/// ቅርጾች በአስርዮሽ አኃዝ `0.<...buf...> * 10^exp` ን ወደ አስርዮሽ ቅፅ የተሰጡት ቢያንስ ከተሰጡት ክፍልፋዮች አሃዞች ጋር ነው ፡፡
///
/// ውጤቱ በቀረቡት ክፍሎች ድርድር ላይ ተከማችቶ የጽሑፍ ክፍሎች አንድ ቁራጭ ተመልሷል ፡፡
///
/// `frac_digits` በ `buf` ውስጥ ከእውነተኛ ክፍልፋይ አኃዞች ቁጥር ያነሰ ሊሆን ይችላል;
/// ችላ ይባላል እና ሙሉ አሃዞች ይታተማሉ።ከተሰጡት አኃዞች በኋላ ተጨማሪ ዜሮዎችን ለማተም ብቻ ጥቅም ላይ ይውላል።
/// ስለዚህ `frac_digits` of 0 ማለት የተሰጡ አሃዞችን ብቻ እና ሌላ ምንም ነገር ብቻ ያትማል ማለት ነው።
///
fn digits_to_dec_str<'a>(
    buf: &'a [u8],
    exp: i16,
    frac_digits: usize,
    parts: &'a mut [MaybeUninit<Part<'a>>],
) -> &'a [Part<'a>] {
    assert!(!buf.is_empty());
    assert!(buf[0] > b'0');
    assert!(parts.len() >= 4);

    // በመጨረሻው አኃዝ አቀማመጥ ላይ ገደቡ ካለ ፣ `buf` በምናባዊ ዜሮዎች ግራ-እንደታጠረ ይታሰባል።
    // የመጨረሻው አሃዝ `exp - buf.len() - nzeroes` አቀማመጥ ከ `-frac_digits` ያልበለጠ በመሆኑ ፣ ምናባዊ ዜሮዎች ቁጥር ፣ `nzeroes` ፣ ከ `max(0, exp + frac_digits - buf.len())` ጋር እኩል ነው።
    //
    //
    //                       |<-virtual->|
    //       | <----buf----> |ዜሮዎች |exp
    //    0. 1 2 3 4 5 6 7 8 9 _ _ _ _ _ _ x 10
    //    |                  |           |
    // 10 ^ exp 10^(exp-buf.len()) 10^(exp-buf.len()-nzeroes)
    //
    // `nzeroes` ከመጠን በላይ እንዳይከሰት ለመከላከል ለእያንዳንዱ ጉዳይ በተናጠል ይሰላል ፡፡
    //

    if exp <= 0 {
        // የአስርዮሽ ነጥቡ ከመተላለፉ ቁጥሮች በፊት ነው [0.][000...000][1234][____]
        let minus_exp = -(exp as i32) as usize;
        parts[0] = MaybeUninit::new(Part::Copy(b"0."));
        parts[1] = MaybeUninit::new(Part::Zero(minus_exp));
        parts[2] = MaybeUninit::new(Part::Copy(buf));
        if frac_digits > buf.len() && frac_digits - buf.len() > minus_exp {
            parts[3] = MaybeUninit::new(Part::Zero((frac_digits - buf.len()) - minus_exp));
            // ደህንነት-እኛ `..4` ን አካላት አሁን አስጀምረናል ፡፡
            unsafe { MaybeUninit::slice_assume_init_ref(&parts[..4]) }
        } else {
            // ደህንነት-እኛ `..3` ን አካላት አሁን አስጀምረናል ፡፡
            unsafe { MaybeUninit::slice_assume_init_ref(&parts[..3]) }
        }
    } else {
        let exp = exp as usize;
        if exp < buf.len() {
            // የአስርዮሽ ነጥቡ በተሰጡት ቁጥሮች ውስጥ ነው [12][.][34][____]
            parts[0] = MaybeUninit::new(Part::Copy(&buf[..exp]));
            parts[1] = MaybeUninit::new(Part::Copy(b"."));
            parts[2] = MaybeUninit::new(Part::Copy(&buf[exp..]));
            if frac_digits > buf.len() - exp {
                parts[3] = MaybeUninit::new(Part::Zero(frac_digits - (buf.len() - exp)));
                // ደህንነት-እኛ `..4` ን አካላት አሁን አስጀምረናል ፡፡
                unsafe { MaybeUninit::slice_assume_init_ref(&parts[..4]) }
            } else {
                // ደህንነት-እኛ `..3` ን አካላት አሁን አስጀምረናል ፡፡
                unsafe { MaybeUninit::slice_assume_init_ref(&parts[..3]) }
            }
        } else {
            // የአስርዮሽ ነጥብ ከተሰጡት አኃዞች በኋላ ነው [1234][____0000] ወይም [1234][__][.][__].
            parts[0] = MaybeUninit::new(Part::Copy(buf));
            parts[1] = MaybeUninit::new(Part::Zero(exp - buf.len()));
            if frac_digits > 0 {
                parts[2] = MaybeUninit::new(Part::Copy(b"."));
                parts[3] = MaybeUninit::new(Part::Zero(frac_digits));
                // ደህንነት-እኛ `..4` ን አካላት አሁን አስጀምረናል ፡፡
                unsafe { MaybeUninit::slice_assume_init_ref(&parts[..4]) }
            } else {
                // ደህንነት-እኛ `..2` ን አካላት አሁን አስጀምረናል ፡፡
                unsafe { MaybeUninit::slice_assume_init_ref(&parts[..2]) }
            }
        }
    }
}

/// የተሰጡትን የአስርዮሽ ቁጥሮች `0.<...buf...> * 10^exp` ን ቢያንስ ቢያንስ በተሰጡት ጉልህ አሃዞች ወደ ኤክስፕሎናንስ ቅፅ ቅርጸት ይሰጣል።
///
/// `upper` `true` ሲሆን ፣ ኤክስፖርቱ በ `E` ቅድመ-ቅጥያ ይደረጋል።አለበለዚያ ይህ `e` ነው።
/// ውጤቱ በቀረቡት ክፍሎች ድርድር ላይ ተከማችቶ የጽሑፍ ክፍሎች አንድ ቁራጭ ተመልሷል ፡፡
///
/// `min_digits` በ `buf` ውስጥ ከእውነተኛ ጉልህ ቁጥሮች ቁጥር ያነሰ ሊሆን ይችላል;
/// ችላ ይባላል እና ሙሉ አሃዞች ይታተማሉ።ከተሰጡት አኃዞች በኋላ ተጨማሪ ዜሮዎችን ለማተም ብቻ ጥቅም ላይ ይውላል።
/// ስለሆነም `min_digits == 0` ማለት የተሰጠውን አሃዞች እና ሌላ ምንም ነገር ብቻ ያትማል ማለት ነው።
///
fn digits_to_exp_str<'a>(
    buf: &'a [u8],
    exp: i16,
    min_ndigits: usize,
    upper: bool,
    parts: &'a mut [MaybeUninit<Part<'a>>],
) -> &'a [Part<'a>] {
    assert!(!buf.is_empty());
    assert!(buf[0] > b'0');
    assert!(parts.len() >= 6);

    let mut n = 0;

    parts[n] = MaybeUninit::new(Part::Copy(&buf[..1]));
    n += 1;

    if buf.len() > 1 || min_ndigits > 1 {
        parts[n] = MaybeUninit::new(Part::Copy(b"."));
        parts[n + 1] = MaybeUninit::new(Part::Copy(&buf[1..]));
        n += 2;
        if min_ndigits > buf.len() {
            parts[n] = MaybeUninit::new(Part::Zero(min_ndigits - buf.len()));
            n += 1;
        }
    }

    // 0.1234 x 10 ^ exp= 1.234 x 10 ^ (exp-1)
    let exp = exp as i32 - 1; // ኤክስኤክስኤክስኤክስ XXXXXXXXXXXXX/መቼ ነው
    if exp < 0 {
        parts[n] = MaybeUninit::new(Part::Copy(if upper { b"E-" } else { b"e-" }));
        parts[n + 1] = MaybeUninit::new(Part::Num(-exp as u16));
    } else {
        parts[n] = MaybeUninit::new(Part::Copy(if upper { b"E" } else { b"e" }));
        parts[n + 1] = MaybeUninit::new(Part::Num(exp as u16));
    }
    // ደህንነት-እኛ `..n + 2` ን አካላት አሁን አስጀምረናል ፡፡
    unsafe { MaybeUninit::slice_assume_init_ref(&parts[..n + 2]) }
}

/// የቅርጸት አማራጮች ይፈርሙ።
#[derive(Copy, Clone, PartialEq, Eq, Debug)]
pub enum Sign {
    /// `-` ን ለህት-ዜሮ ያልሆኑ እሴቶች ብቻ ያትማል።
    Minus, // -inf -1 0 0 1 inf ናን
    /// `-` ን ለማንኛውም አሉታዊ እሴቶች ብቻ ያትማል (አሉታዊውን ዜሮ ጨምሮ)።
    MinusRaw, // -inf -1 -0 0 1 inf nan
    /// `-` ን ለአሉታዊ ዜሮ ያልሆኑ እሴቶች ያትማል ፣ ወይም ደግሞ `+`።
    MinusPlus, // -inf -1 +0 +0 +1 + inf nan
    /// `-` ን ለማንኛውም አሉታዊ እሴቶች ያትማል (አሉታዊውን ዜሮ ጨምሮ) ፣ ወይም ደግሞ `+` ፡፡
    MinusPlusRaw, // -inf -1 -0 +0 +1 + inf nan
}

/// ከሚቀርበው ምልክት ጋር የሚስማማ የማይንቀሳቀስ ባይት ሕብረቁምፊን ይመልሳል።
/// ወይ `""` ፣ `"+"` ወይም `"-"` ሊሆን ይችላል ፡፡
fn determine_sign(sign: Sign, decoded: &FullDecoded, negative: bool) -> &'static str {
    match (*decoded, sign) {
        (FullDecoded::Nan, _) => "",
        (FullDecoded::Zero, Sign::Minus) => "",
        (FullDecoded::Zero, Sign::MinusRaw) => {
            if negative {
                "-"
            } else {
                ""
            }
        }
        (FullDecoded::Zero, Sign::MinusPlus) => "+",
        (FullDecoded::Zero, Sign::MinusPlusRaw) => {
            if negative {
                "-"
            } else {
                "+"
            }
        }
        (_, Sign::Minus | Sign::MinusRaw) => {
            if negative {
                "-"
            } else {
                ""
            }
        }
        (_, Sign::MinusPlus | Sign::MinusPlusRaw) => {
            if negative {
                "-"
            } else {
                "+"
            }
        }
    }
}

/// የተሰጠውን ተንሳፋፊ ነጥብ ቁጥር ቢያንስ በአስርዮሽ ቅፅ በአስርዮሽ ቅፅ ቅርጸት ይሰጣል ፡፡
/// የተሰጠው ባይት ቋት እንደ ጭረት ሲጠቀም ውጤቱ ለተሰጡት ክፍሎች ድርድር ይቀመጣል ፡፡
/// `upper` ውስን ያልሆኑ እሴቶችን ማለትም `inf` እና `nan` ን ለመቀየር በአሁኑ ጊዜ ጥቅም ላይ ያልዋለ ግን ለ future ውሳኔ ቀርቷል ፡፡
///
/// የሚቀርበው የመጀመሪያው ክፍል ሁል ጊዜ `Part::Sign` ነው (ምልክት ካልተሰጠ ባዶ ገመድ ሊሆን ይችላል)።
///
/// `format_shortest` መሰረታዊ አሃዝ-ትውልድ ተግባር መሆን አለበት ፡፡
/// የጀመረውን የመጠባበቂያ ክፍል መመለስ አለበት ፡፡
/// ለዚህ ምናልባት `strategy::grisu::format_shortest` ን ይፈልጉ ይሆናል ፡፡
///
/// `frac_digits` በ `v` ውስጥ ከእውነተኛ ክፍልፋይ አኃዞች ቁጥር ያነሰ ሊሆን ይችላል;
/// ችላ ይባላል እና ሙሉ አሃዞች ይታተማሉ።ከተሰጡት አኃዞች በኋላ ተጨማሪ ዜሮዎችን ለማተም ብቻ ጥቅም ላይ ይውላል።
/// ስለዚህ `frac_digits` of 0 ማለት የተሰጡ አሃዞችን ብቻ እና ሌላ ምንም ነገር ብቻ ያትማል ማለት ነው።
///
/// ባይት ቋት ቢያንስ የ `MAX_SIG_DIGITS` ባይት ርዝመት ሊኖረው ይገባል።
/// ከ `frac_digits = 10` ጋር እንደ `[+][0.][0000][2][0000]` ባለው በጣም የከፋ ችግር ምክንያት ቢያንስ 4 ክፍሎች ሊገኙ ይገባል ፡፡
///
///
///
pub fn to_shortest_str<'a, T, F>(
    mut format_shortest: F,
    v: T,
    sign: Sign,
    frac_digits: usize,
    buf: &'a mut [MaybeUninit<u8>],
    parts: &'a mut [MaybeUninit<Part<'a>>],
) -> Formatted<'a>
where
    T: DecodableFloat,
    F: FnMut(&Decoded, &'a mut [MaybeUninit<u8>]) -> (&'a [u8], i16),
{
    assert!(parts.len() >= 4);
    assert!(buf.len() >= MAX_SIG_DIGITS);

    let (negative, full_decoded) = decode(v);
    let sign = determine_sign(sign, &full_decoded, negative);
    match full_decoded {
        FullDecoded::Nan => {
            parts[0] = MaybeUninit::new(Part::Copy(b"NaN"));
            // ደህንነት-እኛ `..1` ን አካላት አሁን አስጀምረናል ፡፡
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Infinite => {
            parts[0] = MaybeUninit::new(Part::Copy(b"inf"));
            // ደህንነት-እኛ `..1` ን አካላት አሁን አስጀምረናል ፡፡
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Zero => {
            if frac_digits > 0 {
                // [0.][0000]
                parts[0] = MaybeUninit::new(Part::Copy(b"0."));
                parts[1] = MaybeUninit::new(Part::Zero(frac_digits));
                Formatted {
                    sign,
                    // ደህንነት-እኛ `..2` ን አካላት አሁን አስጀምረናል ፡፡
                    parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..2]) },
                }
            } else {
                parts[0] = MaybeUninit::new(Part::Copy(b"0"));
                Formatted {
                    sign,
                    // ደህንነት-እኛ `..1` ን አካላት አሁን አስጀምረናል ፡፡
                    parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) },
                }
            }
        }
        FullDecoded::Finite(ref decoded) => {
            let (buf, exp) = format_shortest(decoded, buf);
            Formatted { sign, parts: digits_to_dec_str(buf, exp, frac_digits, parts) }
        }
    }
}

/// በተገኘው ውጤት ላይ በመመርኮዝ የተሰጠው ተንሳፋፊ ነጥብ ቁጥር በአስርዮሽ ቅፅ ወይም በአብነት ቅጽ ላይ ቅርጸት ይሰጣል ፡፡
/// የተሰጠው ባይት ቋት እንደ ጭረት ሲጠቀም ውጤቱ ለተሰጡት ክፍሎች ድርድር ይቀመጣል ፡፡
/// `upper` ውስን ያልሆኑ እሴቶችን (`inf` እና `nan`) ወይም የአክስዮን ቅድመ-ቅጥያ (`e` ወይም `E`) ጉዳይ ለመወሰን ጥቅም ላይ ይውላል ፡፡
/// የሚቀርበው የመጀመሪያው ክፍል ሁል ጊዜ `Part::Sign` ነው (ምልክት ካልተሰጠ ባዶ ገመድ ሊሆን ይችላል)።
///
/// `format_shortest` መሰረታዊ አሃዝ-ትውልድ ተግባር መሆን አለበት ፡፡
/// የጀመረውን የመጠባበቂያ ክፍል መመለስ አለበት ፡፡
/// ለዚህ ምናልባት `strategy::grisu::format_shortest` ን ይፈልጉ ይሆናል ፡፡
///
/// `dec_bounds` ባለ ሁለት `(lo, hi)` ነው ፣ ስለሆነም ቁጥሩ በአስርዮሽ የተቀረፀው `10^lo <= V < 10^hi` በሚሆንበት ጊዜ ብቻ ነው።
/// ከእውነተኛው `v` ይልቅ ይህ *ግልጽ*`V` መሆኑን ልብ ይበሉ!ስለሆነም ማንኛውንም ዓይነት ግራ መጋባት በማስቀረት በአክሲዮን ቅጽ ውስጥ ያለ ማንኛውም የታተመ ኤክስፐርት በዚህ ክልል ውስጥ መሆን አይችልም ፡፡
///
///
/// ባይት ቋት ቢያንስ የ `MAX_SIG_DIGITS` ባይት ርዝመት ሊኖረው ይገባል።
/// እንደ `[+][1][.][2345][e][-][6]` ባሉ በጣም የከፋ ችግር ምክንያት ቢያንስ 6 ክፍሎች ሊገኙ ይገባል።
///
///
///
///
///
pub fn to_shortest_exp_str<'a, T, F>(
    mut format_shortest: F,
    v: T,
    sign: Sign,
    dec_bounds: (i16, i16),
    upper: bool,
    buf: &'a mut [MaybeUninit<u8>],
    parts: &'a mut [MaybeUninit<Part<'a>>],
) -> Formatted<'a>
where
    T: DecodableFloat,
    F: FnMut(&Decoded, &'a mut [MaybeUninit<u8>]) -> (&'a [u8], i16),
{
    assert!(parts.len() >= 6);
    assert!(buf.len() >= MAX_SIG_DIGITS);
    assert!(dec_bounds.0 <= dec_bounds.1);

    let (negative, full_decoded) = decode(v);
    let sign = determine_sign(sign, &full_decoded, negative);
    match full_decoded {
        FullDecoded::Nan => {
            parts[0] = MaybeUninit::new(Part::Copy(b"NaN"));
            // ደህንነት-እኛ `..1` ን አካላት አሁን አስጀምረናል ፡፡
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Infinite => {
            parts[0] = MaybeUninit::new(Part::Copy(b"inf"));
            // ደህንነት-እኛ `..1` ን አካላት አሁን አስጀምረናል ፡፡
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Zero => {
            parts[0] = if dec_bounds.0 <= 0 && 0 < dec_bounds.1 {
                MaybeUninit::new(Part::Copy(b"0"))
            } else {
                MaybeUninit::new(Part::Copy(if upper { b"0E0" } else { b"0e0" }))
            };
            // ደህንነት-እኛ `..1` ን አካላት አሁን አስጀምረናል ፡፡
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Finite(ref decoded) => {
            let (buf, exp) = format_shortest(decoded, buf);
            let vis_exp = exp as i32 - 1;
            let parts = if dec_bounds.0 as i32 <= vis_exp && vis_exp < dec_bounds.1 as i32 {
                digits_to_dec_str(buf, exp, 0, parts)
            } else {
                digits_to_exp_str(buf, exp, 0, upper, parts)
            };
            Formatted { sign, parts }
        }
    }
}

/// ከተሰጠ ዲኮድ ኤክስፖርተር ለተሰላ ከፍተኛው የመጠባበቂያ መጠን እጅግ በጣም ደካማ የሆነ ግምታዊ (የላይኛው ወሰን) ይመልሳል።
///
/// ትክክለኛው ገደብ-
///
/// - `exp < 0` በሚሆንበት ጊዜ ከፍተኛው ርዝመት `ceil(log_10 (5^-exp * (2^64 - 1)))` ነው።
/// - `exp >= 0` በሚሆንበት ጊዜ ከፍተኛው ርዝመት `ceil(log_10 (2^exp * (2^64 - 1)))` ነው።
///
/// `ceil(log_10 (x^exp * (2^64 - 1)))` ከ `ceil(log_10 (2^64 - 1)) + ceil(exp *log_10 x)` በታች ነው ፣ ይህም በተራው ከ `20 + (1 + exp* log_10 x)` በታች ነው።
/// እኛ ለእኛ ዓላማዎች በቂ የሆነውን `log_10 2 < 5/16` እና `log_10 5 < 12/16` እውነታዎችን እንጠቀማለን ፡፡
///
/// ለምን ይሄ ያስፈልገናል?በመጨረሻው አሃዝ ገደብ ካልተገደቡ በስተቀር የ `format_exact` ተግባራት ሙሉውን ቋት ይሞላሉ ፣ ነገር ግን የተጠየቁት አሃዞች ቁጥር በአስቂኝ ሁኔታ ትልቅ ነው (ለምሳሌ ፣ 30,000 ቁጥሮች)።
///
/// በጣም ብዙው ቋት በዜሮዎች ይሞላል ፣ ስለሆነም ሁሉንም ቋት አስቀድሞ ለመመደብ አንፈልግም።
/// ስለሆነም ፣ ለማንኛውም ክርክር ፣
/// ለ‹XXXX›ቋት 826 ባይት በቂ መሆን አለበት ፡፡ለከፋው ሁኔታ ይህንን ከእውነተኛው ቁጥር ጋር ያነፃፅሩ 770 ባይት (መቼ `exp = -1074`)።
///
///
///
///
///
fn estimate_max_buf_len(exp: i16) -> usize {
    21 + ((if exp < 0 { -12 } else { 5 } * exp as i32) as usize >> 4)
}

/// በትክክል ከተሰጡት ጉልህ ቁጥሮች ጋር ተንሳፋፊ ነጥብ ቁጥርን ወደ ኤክስፖንሽኑ ቅጽ የተሰጡ ፎርማቶች።
/// የተሰጠው ባይት ቋት እንደ ጭረት ሲጠቀም ውጤቱ ለተሰጡት ክፍሎች ድርድር ይቀመጣል ፡፡
/// `upper` የባለ አክሲዮን ቅድመ ቅጥያ (`e` ወይም `E`) ጉዳይን ለመወሰን ጥቅም ላይ ይውላል ፡፡
/// የሚቀርበው የመጀመሪያው ክፍል ሁል ጊዜ `Part::Sign` ነው (ምልክት ካልተሰጠ ባዶ ገመድ ሊሆን ይችላል)።
///
/// `format_exact` መሰረታዊ አሃዝ-ትውልድ ተግባር መሆን አለበት ፡፡
/// የጀመረውን የመጠባበቂያ ክፍል መመለስ አለበት ፡፡
/// ለዚህ ምናልባት `strategy::grisu::format_exact` ይፈልጉ ይሆናል ፡፡
///
/// `ndigits` በጣም ትልቅ ከመሆኑ የተነሳ ቋሚ ቁጥሮች ብቻ የሚፃፉ ካልሆነ በስተቀር ባይት ቋት ቢያንስ `ndigits` ባይት ርዝመት ሊኖረው ይገባል።
/// (ለ‹`f64`›ጥቆማ ነጥብ 800 ያህል ነው ፣ ስለሆነም 1000 ባይት በቂ መሆን አለበት ፡፡) እንደ `[+][1][.][2345][e][-][6]` በመሰለው የከፋ ችግር ምክንያት ቢያንስ 6 ክፍሎች ሊገኙ ይገባል ፡፡
///
///
///
///
///
pub fn to_exact_exp_str<'a, T, F>(
    mut format_exact: F,
    v: T,
    sign: Sign,
    ndigits: usize,
    upper: bool,
    buf: &'a mut [MaybeUninit<u8>],
    parts: &'a mut [MaybeUninit<Part<'a>>],
) -> Formatted<'a>
where
    T: DecodableFloat,
    F: FnMut(&Decoded, &'a mut [MaybeUninit<u8>], i16) -> (&'a [u8], i16),
{
    assert!(parts.len() >= 6);
    assert!(ndigits > 0);

    let (negative, full_decoded) = decode(v);
    let sign = determine_sign(sign, &full_decoded, negative);
    match full_decoded {
        FullDecoded::Nan => {
            parts[0] = MaybeUninit::new(Part::Copy(b"NaN"));
            // ደህንነት-እኛ `..1` ን አካላት አሁን አስጀምረናል ፡፡
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Infinite => {
            parts[0] = MaybeUninit::new(Part::Copy(b"inf"));
            // ደህንነት-እኛ `..1` ን አካላት አሁን አስጀምረናል ፡፡
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Zero => {
            if ndigits > 1 {
                // [0.][0000][e0]
                parts[0] = MaybeUninit::new(Part::Copy(b"0."));
                parts[1] = MaybeUninit::new(Part::Zero(ndigits - 1));
                parts[2] = MaybeUninit::new(Part::Copy(if upper { b"E0" } else { b"e0" }));
                Formatted {
                    sign,
                    // ደህንነት-እኛ `..3` ን አካላት አሁን አስጀምረናል ፡፡
                    parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..3]) },
                }
            } else {
                parts[0] = MaybeUninit::new(Part::Copy(if upper { b"0E0" } else { b"0e0" }));
                Formatted {
                    sign,
                    // ደህንነት-እኛ `..1` ን አካላት አሁን አስጀምረናል ፡፡
                    parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) },
                }
            }
        }
        FullDecoded::Finite(ref decoded) => {
            let maxlen = estimate_max_buf_len(decoded.exp);
            assert!(buf.len() >= ndigits || buf.len() >= maxlen);

            let trunc = if ndigits < maxlen { ndigits } else { maxlen };
            let (buf, exp) = format_exact(decoded, &mut buf[..trunc], i16::MIN);
            Formatted { sign, parts: digits_to_exp_str(buf, exp, ndigits, upper, parts) }
        }
    }
}

/// በትክክል ከተሰጡት የክፍልፋይ ቁጥሮች ጋር ተንሳፋፊ ነጥብ ቁጥር ወደ አስርዮሽ ቅፅ የተሰጡ ፎርማቶች።
/// የተሰጠው ባይት ቋት እንደ ጭረት ሲጠቀም ውጤቱ ለተሰጡት ክፍሎች ድርድር ይቀመጣል ፡፡
/// `upper` ውስን ያልሆኑ እሴቶችን ማለትም `inf` እና `nan` ን ለመቀየር በአሁኑ ጊዜ ጥቅም ላይ ያልዋለ ግን ለ future ውሳኔ ቀርቷል ፡፡
/// የሚቀርበው የመጀመሪያው ክፍል ሁል ጊዜ `Part::Sign` ነው (ምልክት ካልተሰጠ ባዶ ገመድ ሊሆን ይችላል)።
///
/// `format_exact` መሰረታዊ አሃዝ-ትውልድ ተግባር መሆን አለበት ፡፡
/// የጀመረውን የመጠባበቂያ ክፍል መመለስ አለበት ፡፡
/// ለዚህ ምናልባት `strategy::grisu::format_exact` ይፈልጉ ይሆናል ፡፡
///
/// `frac_digits` በጣም ትልቅ ከመሆኑ የተነሳ ቋሚ ቁጥሮች ብቻ የሚፃፉ ካልሆነ በስተቀር ባይት ቋት ለውጤቱ በቂ መሆን አለበት።
/// (ለ‹`f64`›ጥቆማ ነጥብ 800 ያህል ነው ፣ እና 1000 ባይት በቂ መሆን አለበት ፡፡) እንደ `[+][0.][0000][2][0000]` ከ `frac_digits = 10` ጋር በጣም የከፋ ችግር በመኖሩ ቢያንስ 4 ክፍሎች ሊኖሩ ይገባል ፡፡
///
///
///
///
///
pub fn to_exact_fixed_str<'a, T, F>(
    mut format_exact: F,
    v: T,
    sign: Sign,
    frac_digits: usize,
    buf: &'a mut [MaybeUninit<u8>],
    parts: &'a mut [MaybeUninit<Part<'a>>],
) -> Formatted<'a>
where
    T: DecodableFloat,
    F: FnMut(&Decoded, &'a mut [MaybeUninit<u8>], i16) -> (&'a [u8], i16),
{
    assert!(parts.len() >= 4);

    let (negative, full_decoded) = decode(v);
    let sign = determine_sign(sign, &full_decoded, negative);
    match full_decoded {
        FullDecoded::Nan => {
            parts[0] = MaybeUninit::new(Part::Copy(b"NaN"));
            // ደህንነት-እኛ `..1` ን አካላት አሁን አስጀምረናል ፡፡
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Infinite => {
            parts[0] = MaybeUninit::new(Part::Copy(b"inf"));
            // ደህንነት-እኛ `..1` ን አካላት አሁን አስጀምረናል ፡፡
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Zero => {
            if frac_digits > 0 {
                // [0.][0000]
                parts[0] = MaybeUninit::new(Part::Copy(b"0."));
                parts[1] = MaybeUninit::new(Part::Zero(frac_digits));
                Formatted {
                    sign,
                    // ደህንነት-እኛ `..2` ን አካላት አሁን አስጀምረናል ፡፡
                    parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..2]) },
                }
            } else {
                parts[0] = MaybeUninit::new(Part::Copy(b"0"));
                Formatted {
                    sign,
                    // ደህንነት-እኛ `..1` ን አካላት አሁን አስጀምረናል ፡፡
                    parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) },
                }
            }
        }
        FullDecoded::Finite(ref decoded) => {
            let maxlen = estimate_max_buf_len(decoded.exp);
            assert!(buf.len() >= maxlen);

            // እሱ * ሊሆን ይችላል `frac_digits` በአስቂኝ ሁኔታ ትልቅ ነው።
            // `format_exact` በዚህ ጉዳይ ላይ በጣም ቀደም ብሎ የአተረጓጎም አሃዞችን ያጠናቅቃል ፣ ምክንያቱም እኛ በ `maxlen` በጥብቅ የተገደብን ስለሆነ።
            //
            let limit = if frac_digits < 0x8000 { -(frac_digits as i16) } else { i16::MIN };
            let (buf, exp) = format_exact(decoded, &mut buf[..maxlen], limit);
            if exp <= limit {
                // ገደቡ ሊሟላ አልቻለም ፣ ስለሆነም `exp` ምንም ቢሆን ይህ እንደ ዜሮ መስጠት አለበት።
                // ይህ ገደቡ የተጠናቀቀው ከመጨረሻው ማጠናቀሪያ በኋላ ብቻ መሆኑን አያካትትም ፡፡ከ `exp = limit + 1` ጋር መደበኛ ጉዳይ ነው ፡፡
                //
                debug_assert_eq!(buf.len(), 0);
                if frac_digits > 0 {
                    // [0.][0000]
                    parts[0] = MaybeUninit::new(Part::Copy(b"0."));
                    parts[1] = MaybeUninit::new(Part::Zero(frac_digits));
                    Formatted {
                        sign,
                        // ደህንነት-እኛ `..2` ን አካላት አሁን አስጀምረናል ፡፡
                        parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..2]) },
                    }
                } else {
                    parts[0] = MaybeUninit::new(Part::Copy(b"0"));
                    Formatted {
                        sign,
                        // ደህንነት-እኛ `..1` ን አካላት አሁን አስጀምረናል ፡፡
                        parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) },
                    }
                }
            } else {
                Formatted { sign, parts: digits_to_dec_str(buf, exp, frac_digits, parts) }
            }
        }
    }
}