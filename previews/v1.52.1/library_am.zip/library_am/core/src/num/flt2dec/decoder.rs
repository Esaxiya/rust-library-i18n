//! የግለሰቦችን እና የስህተት ክልሎችን ተንሳፋፊ-ነጥብ ዋጋን ዲኖዎችን ይሰጣል።

use crate::num::dec2flt::rawfp::RawFloat;
use crate::num::FpCategory;

/// የተፈረመ ያልተፈረመ ውሱን እሴት ፣
///
/// - የመጀመሪያው እሴት ከ `mant * 2^exp` ጋር እኩል ነው።
///
/// - ከ `(mant - minus)*2^exp` እስከ `(mant + plus)* 2^exp` ያለው ማንኛውም ቁጥር ወደ ዋናው እሴት ይሽከረከራል።
/// ክልሉ የሚያካትተው `inclusive` `true` ሲሆን ብቻ ነው።
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct Decoded {
    /// የተስተካከለ ማንቲሳ ፡፡
    pub mant: u64,
    /// ዝቅተኛው የስህተት ክልል።
    pub minus: u64,
    /// የላይኛው የስህተት ክልል።
    pub plus: u64,
    /// የተጋራው አክሲዮን በመሠረቱ 2 ውስጥ።
    pub exp: i16,
    /// የስህተት ክልል ሁሉንም ሲያካትት እውነት ነው።
    ///
    /// በ IEEE 754 ውስጥ የመጀመሪያው ማንቲሳ እንኳ ቢሆን ይህ እውነት ነው።
    pub inclusive: bool,
}

/// ያልተፈረመ ያልተፈረመ እሴት።
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub enum FullDecoded {
    /// Not-a-number.
    Nan,
    /// Infinities, አዎንታዊ ወይም አሉታዊ.
    Infinite,
    /// ዜሮ ፣ አዎንታዊም ይሁን አሉታዊ።
    Zero,
    /// የተጠናቀቁ ቁጥሮች ከተለዩ ዲኮድ መስኮች ጋር።
    Finite(Decoded),
}

/// `Decode`d` ሊሆን የሚችል ተንሳፋፊ ነጥብ ዓይነት።
pub trait DecodableFloat: RawFloat + Copy {
    /// ዝቅተኛው አዎንታዊ መደበኛ እሴት።
    fn min_pos_norm_value() -> Self;
}

impl DecodableFloat for f32 {
    fn min_pos_norm_value() -> Self {
        f32::MIN_POSITIVE
    }
}

impl DecodableFloat for f64 {
    fn min_pos_norm_value() -> Self {
        f64::MIN_POSITIVE
    }
}

/// ከተሰጠው ተንሳፋፊ የነጥብ ቁጥር አንድ ምልክት (አሉታዊ በሚሆንበት ጊዜ እውነት) እና የ `FullDecoded` እሴት ይመልሳል።
///
pub fn decode<T: DecodableFloat>(v: T) -> (/*negative?*/ bool, FullDecoded) {
    let (mant, exp, sign) = v.integer_decode();
    let even = (mant & 1) == 0;
    let decoded = match v.classify() {
        FpCategory::Nan => FullDecoded::Nan,
        FpCategory::Infinite => FullDecoded::Infinite,
        FpCategory::Zero => FullDecoded::Zero,
        FpCategory::Subnormal => {
            // ጎረቤቶች: (mant, 2, exp)-(mant, exp)-(mant + 2, exp)
            // Float::integer_decode ሁልጊዜ ገላጭውን ጠብቆ ያቆየዋል ፣ ስለሆነም ማንቲሳ ለንዑስ ንዑስ ክፍሎች ተመዝኗል ፡፡
            //
            FullDecoded::Finite(Decoded { mant, minus: 1, plus: 1, exp, inclusive: even })
        }
        FpCategory::Normal => {
            let minnorm = <T as DecodableFloat>::min_pos_norm_value().integer_decode();
            if mant == minnorm.0 {
                // ጎረቤቶች: (maxmant, exp, 1)-(minnormmant, exp)-(minnormmant + 1, exp)
                // የት maxmant=አነስተኛ መደበኛ * 2, 1
                FullDecoded::Finite(Decoded {
                    mant: mant << 2,
                    minus: 1,
                    plus: 2,
                    exp: exp - 2,
                    inclusive: even,
                })
            } else {
                // ጎረቤቶች: (mant, 1, exp)-(mant, exp)-(mant + 1, exp)
                FullDecoded::Finite(Decoded {
                    mant: mant << 1,
                    minus: 1,
                    plus: 1,
                    exp: exp - 1,
                    inclusive: even,
                })
            }
        }
    };
    (sign < 0, decoded)
}