//! ለ 16 ቢት የተፈረመ የኢቲጀር ዓይነት ቋሚዎች።
//!
//! *[See also the `i16` primitive type][i16].*
//!
//! አዲስ ኮድ ተጓዳኝ ቋሚዎችን በቀጥታ በጥንታዊው ዓይነት ላይ መጠቀም አለበት ፡፡

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `i16`"
)]

int_module! { i16 }