//! የተለያዩ ስልተ ቀመሮች ከወረቀቱ።

use crate::cmp::min;
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::rawfp::{self, fp_to_float, next_float, prev_float, RawFloat, Unpacked};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;

/// በ Fp ውስጥ አስፈላጊ እና ጥቃቅን ብዛት
const P: u32 = 64;

// እኛ ለሁሉም * ተወካዮች በጣም ጥሩውን ግምታዊነት በቀላሉ እናከማቻለን ፣ ስለሆነም ተለዋዋጭ "h" እና ተጓዳኝ ሁኔታዎች ሊተዉ ይችላሉ።
// ይህ ለሁለት ኪሎባይት ቦታ አፈፃፀም ያሳያል ፡፡

fn power_of_ten(e: i16) -> Fp {
    assert!(e >= table::MIN_E);
    let i = e - table::MIN_E;
    let sig = table::POWERS.0[i as usize];
    let exp = table::POWERS.1[i as usize];
    Fp { f: sig, e: exp }
}

// በአብዛኛዎቹ ሥነ-ሕንጻዎች ውስጥ ተንሳፋፊ ነጥብ ክዋኔዎች ግልጽ የሆነ ትንሽ መጠን አላቸው ፣ ስለሆነም የሂሳብ አተገባበሩ ትክክለኛነት በአሠራር መሠረት ነው።
//
#[cfg(any(not(target_arch = "x86"), target_feature = "sse2"))]
mod fpu_precision {
    pub fn set_precision<T>() {}
}

// በ x86 ላይ x87 FPU የ SSE/SSE2 ማራዘሚያዎች ከሌሉ ለመንሳፈፍ ስራዎች ጥቅም ላይ ይውላል ፡፡
// x87 FPU በነባሪነት በ 80 ቢት ትክክለኛነት ይሠራል ፣ ይህ ማለት እሴቶቹ በመጨረሻ ሲወከሉ ድርብ ማዞር እንዲከሰት የሚያደርጉ ክዋኔዎች ወደ 80 ቢት ክብ ይሆናሉ ፡፡
//
// 32/64 ቢት ተንሳፋፊ እሴቶች።ይህንን ለማሸነፍ የ FPU መቆጣጠሪያ ቃል ሊዘጋጅ ይችላል ስለሆነም ስሌቶቹ በሚፈለገው ትክክለኛነት እንዲከናወኑ ፡፡
//
#[cfg(all(target_arch = "x86", not(target_feature = "sse2")))]
mod fpu_precision {
    use crate::mem::size_of;

    /// የ FPU መቆጣጠሪያ ቃል ዋናውን እሴት ለማቆየት የሚያገለግል መዋቅር ፣ መዋቅሩ ሲወድቅ እንዲመለስ ፡፡
    ///
    ///
    /// x87 FPU መስኮች እንደሚከተለው የ 16 ቢት ምዝገባ ነው
    ///
    /// | 12-15 | 10-11 | 8-9 | 6-7 |  5 |  4 |  3 |  2 |  1 |  0 |
    /// |------:|------:|----:|----:|---:|---:|---:|---:|---:|---:|
    /// |       | RC    | PC  |     | PM | UM | OM | ZM | DM | IM |
    ///
    /// የሁሉም መስኮች ሰነድ በ IA-32 አርክቴክቸሮች የሶፍትዌር ገንቢ መመሪያ (ጥራዝ 1) ውስጥ ይገኛል።
    ///
    /// ለሚከተለው ኮድ ተስማሚ የሆነው ብቸኛው መስክ ፒሲ ፣ ትክክለኛነት ቁጥጥር ነው ፡፡
    /// ይህ መስክ በ FPU የተከናወኑትን ስራዎች ትክክለኛነት ይወስናል ፡፡
    /// ሊቀናጅ ይችላል
    ///  - 0b00 ፣ ነጠላ ትክክለኛነት ማለትም ፣ 32 ቢት
    ///  - 0b10 ፣ ድርብ ትክክለኛነት ማለትም 64 ቢት
    ///  - 0b11 ፣ ባለ ሁለት የተራዘመ ትክክለኛነት ማለትም ፣ 80 ቢት (ነባሪ ሁኔታ) የ 0b01 እሴቱ ተጠብቆ ጥቅም ላይ መዋል የለበትም።
    ///
    pub struct FPUControlWord(u16);

    fn set_cw(cw: u16) {
        // ደህንነት-የ `fldcw` መመሪያ በትክክል ለመስራት መቻል ኦዲት ተደርጓል
        // ማንኛውም `u16`
        unsafe {
            asm!(
                "fldcw ({})",
                in(reg) &cw,
                // FIXME: LLVM 8 እና LLVM 9 ን ለመደገፍ ATT አገባብ እየተጠቀምን ነው ፡፡
                options(att_syntax, nostack),
            )
        }
    }

    /// የ FPU ትክክለኛነት መስክን ወደ `T` ያወጣል እና `FPUControlWord` ን ይመልሳል።
    pub fn set_precision<T>() -> FPUControlWord {
        let mut cw = 0_u16;

        // ለ `T` ተስማሚ የሆነውን ለትክክለኝነት መቆጣጠሪያ መስክ ዋጋ ያስሉ።
        let cw_precision = match size_of::<T>() {
            4 => 0x0000, // 32 ቢት
            8 => 0x0200, // 64 ቢት
            _ => 0x0300, // ነባሪ ፣ 80 ቢት
        };

        // የ `FPUControlWord` መዋቅር ሲወድቅ በኋላ ላይ ወደነበረበት ለመመለስ የቁጥጥር ቃል ዋናውን ዋጋ ያግኙ ከዚያ ደህንነቱ-የ `fnstcw` መመሪያ ከማንኛውም `u16` ጋር በትክክል ለመስራት መቻል ኦዲት ተደርጓል ፡፡
        //
        //
        //
        unsafe {
            asm!(
                "fnstcw ({})",
                in(reg) &mut cw,
                // FIXME: LLVM 8 እና LLVM 9 ን ለመደገፍ ATT አገባብ እየተጠቀምን ነው ፡፡
                options(att_syntax, nostack),
            )
        }

        // የመቆጣጠሪያ ቃሉን ወደሚፈለገው ትክክለኛነት ያዘጋጁ።
        // ይህ የሚከናወነው የድሮውን ትክክለኛነት (ቢት 8 እና 9 ፣ 0x300) በማሸብለል እና ከላይ በተጠቀሰው ትክክለኛ ባንዲራ በመተካት ነው ፡፡
        set_cw((cw & 0xFCFF) | cw_precision);

        FPUControlWord(cw)
    }

    impl Drop for FPUControlWord {
        fn drop(&mut self) {
            set_cw(self.0)
        }
    }
}

/// የቤሌሮፎን ፈጣን መንገድ በማሽን መጠን ያላቸውን ቁጥሮች እና ተንሳፋፊዎችን በመጠቀም።
///
/// ይህ ድንገተኛ ከመገንባቱ በፊት እንዲሞከር ይህ ወደ ተለየ ተግባር ይወጣል።
///
pub fn fast_path<T: RawFloat>(integral: &[u8], fractional: &[u8], e: i64) -> Option<T> {
    let num_digits = integral.len() + fractional.len();
    // log_10(f64::MAX_SIG) ~ 15.95።
    // ትክክለኛውን እሴት በመጨረሻው አቅራቢያ ከ MAX_SIG ጋር እናነፃፅራለን ፣ ይህ ፈጣን ፣ ርካሽ ውድቅነት ብቻ ነው (እንዲሁም የቀረውን ኮድ ስለ ፍሰት ፍሰት ከመጨነቅ ነፃ ያወጣል)።
    //
    if num_digits > 16 {
        return None;
    }
    if e.abs() >= T::CEIL_LOG5_OF_MAX_SIG as i64 {
        return None;
    }
    let f = num::from_str_unchecked(integral.iter().chain(fractional.iter()));
    if f > T::MAX_SIG {
        return None;
    }

    // ፈጣን መንገዱ ወሳኙን የሚወስነው ምንም ዓይነት መካከለኛ ሽክርክሪት ሳይኖር በትክክለኛው የቁጥር ብዛት በተጠጋ የሂሳብ ስሌት ላይ ነው ፡፡
    // በ x86 (ያለ SSE ወይም SSE2) ይህ የ x87 FPU ቁልል ትክክለኛነት በቀጥታ ወደ 64/32 ቢት እንዲዞር እንዲለወጥ ይፈልጋል ፡፡
    // የ `set_precision` ተግባር ዓለም አቀፋዊ ሁኔታን በመለወጥ (እንደ x87 FPU የመቆጣጠሪያ ቃል) ማስተካከልን በሚጠይቁ የህንፃ ሕንፃዎች ላይ ትክክለኛነትን ለማቀናበር ይንከባከባል ፡፡
    //
    //
    let _cw = fpu_precision::set_precision::<T>();

    // ጉዳዩ e <0 ወደ ሌላ branch ሊታጠፍ አይችልም።
    // በመጨረሻው ውጤት እውነተኛ (እና አልፎ አልፎም በጣም አስፈላጊ!) ስህተቶችን የሚያስከትሉ የተጠጋጋ ባለ ሁለትዮሽ ውስጥ ተደጋጋሚ ክፍልፋይ ክፍልፋዮች ያስከትላሉ ፡፡
    //
    if e >= 0 {
        Some(T::from_int(f) * T::short_fast_pow10(e as usize))
    } else {
        Some(T::from_int(f) / T::short_fast_pow10(e.abs() as usize))
    }
}

/// አልጎሪዝም ቤለሮፎን ቀላል ባልሆኑ የቁጥር ትንተናዎች የተረጋገጠ ተራ ኮድ ነው ፡፡
///
/// በ 64 ቢት ትርጉም ባለው ተንሳፋፊ `f` ን ይንከባለል እና በ‹XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX ላይ ከፍ ያደርጉታልትክክለኛውን ውጤት ለማግኘት ይህ ብዙውን ጊዜ በቂ ነው ፡፡
/// ሆኖም ፣ ውጤቱ በሁለት በአጠገብ ባሉ የ (ordinary) ተንሳፋፊዎች መካከል ወደ ግማሽ ሲጠጋ ፣ ሁለት ግምቶችን ከማባዛት የግቢው ክብ ስህተት ውጤቱ በጥቂት ቢቶች ሊጠፋ ይችላል ማለት ነው።
/// ይህ በሚሆንበት ጊዜ ተለዋዋጭ አልጎሪዝም አር ነገሮችን ያስተካክላል ፡፡
///
/// የእጅ ሞገድ "close to halfway" በትክክል በወረቀቱ ውስጥ ባለው የቁጥር ትንተና የተሰራ ነው።
/// በክሊንገር ቃላት ውስጥ
///
/// > ስፕሎፕ ፣ በትንሹ ጉልህ በሆነ አሃዶች ውስጥ ተገልጧል ፣ ለስህተቱ ሁሉን ያካተተ ነው
/// > ወደ f * 10 ^ e ቅርበት ባለው ተንሳፋፊ ነጥብ ስሌት ወቅት ተከማችቷል።(ስሎፕ ነው)
/// > ለእውነተኛው ስህተት አይገደብም ፣ ግን በአቀራረብ z እና መካከል ያለውን ልዩነት ይገድባል
/// > በጣም አስፈላጊ የሆኑ ነጥቦችን የሚጠቀመው በጣም ጥሩ ግምታዊ።)
///
///
pub fn bellerophon<T: RawFloat>(f: &Big, e: i16) -> T {
    let slop = if f <= &Big::from_u64(T::MAX_SIG) {
        // ጉዳዮቹ abs(e) <log5(2^N) በ fast_path() ውስጥ ናቸው
        if e >= 0 { 0 } else { 3 }
    } else {
        if e >= 0 { 1 } else { 4 }
    };
    let z = rawfp::big_to_fp(f).mul(&power_of_ten(e)).normalize();
    let exp_p_n = 1 << (P - T::SIG_BITS as u32);
    let lowbits: i64 = (z.f % exp_p_n) as i64;
    // ወደ n ቢት በሚዞሩበት ጊዜ ልዩነቱን ለማሳደግ ቁልቁለቱ ትልቅ ነውን?
    //
    if (lowbits - exp_p_n as i64 / 2).abs() <= slop {
        algorithm_r(f, e, fp_to_float(z))
    } else {
        fp_to_float(z)
    }
}

/// የ‹`f * 10^e` X›ተንሳፋፊ ነጥብ ግምትን የሚያሻሽል ተጓዳኝ ስልተ ቀመር።
///
/// እያንዳንዱ ድግግሞሽ በመጨረሻው ቦታ አንድ ክፍልን ይበልጥ ይቀራረባል ፣ በእርግጥ `z0` በመጠኑም ቢሆን ከጠፋ ለመሰብሰብ በጣም ረጅም ጊዜ ይወስዳል።
/// እንደ እድል ሆኖ ፣ ለቤሌሮፎን እንደ ውድቀት ጥቅም ላይ ሲውል ፣ የመነሻ ግምቱ ቢበዛ በአንድ ULP ጠፍቷል ፡፡
///
fn algorithm_r<T: RawFloat>(f: &Big, e: i16, z0: T) -> T {
    let mut z = z0;
    loop {
        let raw = z.unpack();
        let (m, k) = (raw.sig, raw.k);
        let mut x = f.clone();
        let mut y = Big::from_u64(m);

        // `x` ን በትክክል `(f *10^e) / (m* 2^k)` እንደሆነ `x` ፣ `y` ን አዎንታዊ ቁጥሮች ያግኙ።
        // ይህ ከ `e` እና `k` ምልክቶች ጋር መገናኘትን ከማስወገድ በተጨማሪ ቁጥሮችን አናሳ ለማድረግ የ `10^e` እና `2^k` ሁለት የጋራ ሀይልን እናጠፋለን ፡፡
        //
        make_ratio(&mut x, &mut y, e, k);

        let m_digits = [(m & 0xFF_FF_FF_FF) as u32, (m >> 32) as u32];
        // የእኛ ቢግኖሞች አሉታዊ ቁጥሮችን ስለማይደግፉ ይህ ትንሽ በማይመች ሁኔታ ተጽ writtenል ፣ ስለሆነም እኛ ፍጹም እሴት + የምልክት መረጃን እንጠቀማለን።
        // ከ m_digits ጋር ያለው ብዜት ሊፈስ አይችልም።
        // ከመጠን በላይ መጨነቅ የሚያስፈልገን `x` ወይም `y` ሰፋ ያሉ ከሆነ `make_ratio` ን ደግሞ በ 2 ^ 64 ወይም ከዚያ በላይ በሆነ መጠን እንዲቀንስ ማድረጉ በቂ ነው።
        //
        //
        let (d2, d_negative) = if x >= y {
            // ከእንግዲህ x አያስፈልግዎትም ፣ clone() ን ያስቀምጡ።
            x.sub(&y).mul_pow2(1).mul_digits(&m_digits);
            (x, false)
        } else {
            // አሁንም y ን ይፈልጉ ፣ ቅጅ ያድርጉ።
            let mut y = y.clone();
            y.sub(&x).mul_pow2(1).mul_digits(&m_digits);
            (y, true)
        };

        if d2 < y {
            let mut d2_double = d2;
            d2_double.mul_pow2(1);
            if m == T::MIN_SIG && d_negative && d2_double > y {
                z = prev_float(z);
            } else {
                return z;
            }
        } else if d2 == y {
            if m % 2 == 0 {
                if m == T::MIN_SIG && d_negative {
                    z = prev_float(z);
                } else {
                    return z;
                }
            } else if d_negative {
                z = prev_float(z);
            } else {
                z = next_float(z);
            }
        } else if d_negative {
            z = prev_float(z);
        } else {
            z = next_float(z);
        }
    }
}

/// `x = f` እና `y = m` ን ሲሰጥ `f` እንደ ተለመደው የግቤት አስርዮሽ አሃዞችን ይወክላል እና `m` የተንሳፋፊ ነጥብ ግምታዊ ትርጉም ነው ፣ ሬሾው `x / y` ከ `(f *10^e) / (m* 2^k)` ጋር እኩል እንዲሆን ያድርጉ ፣ ምናልባትም በሁለቱም ኃይል አንድ ላይ ተቀንሶ ሊሆን ይችላል ፡፡
///
///
fn make_ratio(x: &mut Big, y: &mut Big, e: i16, k: i16) {
    let (e_abs, k_abs) = (e.abs() as usize, k.abs() as usize);
    if e >= 0 {
        if k >= 0 {
            // x=f *10 ^ e, y=m* 2 ^ k, እኛ ክፍልፋዮችን በተወሰነ ኃይል በሁለት ከመቀነስ በስተቀር ፡፡
            let common = min(e_abs, k_abs);
            x.mul_pow5(e_abs).mul_pow2(e_abs - common);
            y.mul_pow2(k_abs - common);
        } else {
            // x=f *10 ^ e* 2^abs(k), y=m ይህ ሊፈስ አይችልም ምክንያቱም አዎንታዊ `e` እና አሉታዊ `k` ን ይፈልጋል ፣ ይህም ለ 1 በጣም ለሚጠጉ እሴቶች ብቻ ሊሆን ይችላል ፣ ይህም ማለት `e` እና `k` በንፅፅር ጥቃቅን ይሆናሉ ማለት ነው ፡፡
            //
            //
            //
            x.mul_pow5(e_abs).mul_pow2(e_abs + k_abs);
        }
    } else {
        if k >= 0 {
            // x=f, y=m *10^abs(e)* 2 ^ k ይህ እንዲሁ ሊፈስ አይችልም ፣ ከላይ ይመልከቱ ፡፡
            //
            y.mul_pow5(e_abs).mul_pow2(k_abs + e_abs);
        } else {
            // x=f *2^abs(k), y=m* 10^abs(e), እንደገና በሁለት በጋራ ኃይል በመቀነስ.
            let common = min(e_abs, k_abs);
            x.mul_pow2(k_abs - common);
            y.mul_pow5(e_abs).mul_pow2(e_abs - common);
        }
    }
}

/// በአስተያየት ፣ አልጎሪዝም ኤም አስርዮሽን ወደ ተንሳፋፊ ለመቀየር ቀላሉ መንገድ ነው ፡፡
///
/// እኛ ከ‹XXXX›ጋር እኩል የሆነ ሬሾን እንፈጥራለን ፣ ከዚያ ትክክለኛ የሆነ ተንሳፋፊ ጠቀሜታ እስከሚሰጥ ድረስ በሁለት ኃይሎች እንጥላለን ፡፡
/// የሁለትዮሽ አክሲዮን `k` ቁጥር ወይም ቁጥርን በሁለት ያባዛነው ቁጥር ነው ፣ ማለትም ፣ በማንኛውም ጊዜ `f *10^e` እኩል `(u / v)* 2^k` ነው።
/// ጠቃሚነትን ካወቅን በኋላ ከዚህ በታች ባለው ረዳት ተግባራት ውስጥ የሚከናወነውን ቀሪውን ክፍል በመመርመር ብቻ ማዞር ያስፈልገናል ፡፡
///
///
/// ይህ ስልተ-ቀመር በ `quick_start()` ውስጥ በተገለጸው ማመቻቸት እንኳን እጅግ በጣም ቀርፋፋ ነው።
/// ሆኖም ፣ ከመጠን በላይ ፍሰት ፣ የውሃ ፍሰት እና ያልተለመዱ ውጤቶችን ለማስማማት ቀላሉ ስልተ ቀመሮች ናቸው ፡፡
/// ይህ አተገባበር ቤለሮፎን እና አልጎሪዝም አር ሲበዛ ጊዜውን ይወስዳል ፡፡
/// የውሃ ፍሰትን እና የተትረፈረፈ ፍሰትን መፈለግ ቀላል ነው-ሬሾው አሁንም ቢሆን የክልል ትርጉም የለውም ፣ ሆኖም የ minimum/maximum ኤክስፖርቱ ደርሷል።
/// ከመጠን በላይ በሆነ ሁኔታ ፣ በቀላሉ ወደ ወሰን እንመለሳለን።
///
/// የውሃ ፍሰትን እና ንዑስ ንዑሳን ነገሮችን ማስተናገድ የበለጠ አስቸጋሪ ነው።
/// አንድ ትልቅ ችግር ፣ በአነስተኛ ኤክስፖርቱ አማካይነት ፣ ጥምርታው አሁንም ቢሆን በጣም አስፈላጊ ሊሆን ይችላል ፡፡
/// ለዝርዝሮች underflow() ን ይመልከቱ ፡፡
///
pub fn algorithm_m<T: RawFloat>(f: &Big, e: i16) -> T {
    let mut u;
    let mut v;
    let e_abs = e.abs() as usize;
    let mut k = 0;
    if e < 0 {
        u = f.clone();
        v = Big::from_small(1);
        v.mul_pow5(e_abs).mul_pow2(e_abs);
    } else {
        // FIXME ሊኖር የሚችል ማመቻቸት-የ‹fp_to_float(big_to_fp(u)) X›አቻን እዚህ እንድናከናውን big_to_fp ን ጠቅለል ያድርጉ ፣ ያለ ድርብ ክብ ብቻ ፡፡
        //
        u = f.clone();
        u.mul_pow5(e_abs).mul_pow2(e_abs);
        v = Big::from_small(1);
    }
    quick_start::<T>(&mut u, &mut v, &mut k);
    let mut rem = Big::from_small(0);
    let mut x = Big::from_small(0);
    let min_sig = Big::from_u64(T::MIN_SIG);
    let max_sig = Big::from_u64(T::MAX_SIG);
    loop {
        u.div_rem(&v, &mut x, &mut rem);
        if k == T::MIN_EXP_INT {
            // እስከ ቢያንስ `k < T::MIN_EXP_INT` ድረስ የምንጠብቅ ከሆነ በትንሹ ኤክስፖርተር ላይ ማቆም አለብን ፣ ከዚያ በሁለት እጥፍ ያህል እንቀራለን።
            // እንደ አለመታደል ሆኖ ይህ ማለት መደበኛ ቁጥሮችን ከዝቅተኛው አውራጅ ጋር ልዩ ማድረግ አለብን ማለት ነው ፡፡
            // FIXME ይበልጥ የሚያምር ቀመር ያገኛል ፣ ግን በትክክል ትክክል መሆኑን ለማረጋገጥ የ‹`tiny-pow10` X›ሙከራን ያሂዱ!
            //
            //
            if x >= min_sig && x <= max_sig {
                break;
            }
            return underflow(x, v, rem);
        }
        if k > T::MAX_EXP_INT {
            return T::INFINITY;
        }
        if x < min_sig {
            u.mul_pow2(1);
            k -= 1;
        } else if x > max_sig {
            v.mul_pow2(1);
            k += 1;
        } else {
            break;
        }
    }
    let q = num::to_u64(&x);
    let z = rawfp::encode_normal(Unpacked::new(q, k));
    round_by_remainder(v, rem, q, z)
}

/// የትንሽ ርዝመቱን በመፈተሽ በአብዛኛዎቹ የአልጎሪዝም ኤም ድግግሞሾች ላይ ይዘላል።
fn quick_start<T: RawFloat>(u: &mut Big, v: &mut Big, k: &mut i16) {
    // ቢት ርዝመት የመሠረቱ ሁለት ሎጋሪዝም እና log(u / v) = log(u) ፣ log(v) ግምት ነው።
    // ግምቱ ቢበዛ በ 1 ጠፍቷል ፣ ግን ሁልጊዜ ግምታዊ ያልሆነ ነው ፣ ስለሆነም በ log(u) እና log(v) ላይ ያለው ስህተት ተመሳሳይ ምልክት ነው እና ይሰረዛሉ (ሁለቱም ትልቅ ከሆኑ)።
    // ስለዚህ የ‹XXXX›ስህተት ቢበዛ አንድ ነው ፡፡
    // የዒላማው ጥምርታ u/v በክልል ትርጉም ውስጥ የሚገኝበት አንድ ነው።ስለዚህ የማብቃታችን ሁኔታ log2(u / v) አስፈላጊ እና ጥቃቅን ፣ plus/minus አንድ ነው ፡፡
    // FIXME ሁለተኛውን ቢት ማየቱ ግምቱን ሊያሻሽል እና አንዳንድ ተጨማሪ ክፍሎችን ለማስወገድ ይችላል።
    //
    //
    let target_ratio = T::SIG_BITS as i16;
    let log2_u = u.bit_length() as i16;
    let log2_v = v.bit_length() as i16;
    let mut u_shift: i16 = 0;
    let mut v_shift: i16 = 0;
    assert!(*k == 0);
    loop {
        if *k == T::MIN_EXP_INT {
            // የውሃ ፍሰት ወይም ያልተለመደ።ለዋናው ተግባር ይተዉት ፡፡
            break;
        }
        if *k == T::MAX_EXP_INT {
            // የተትረፈረፈ ፡፡ለዋናው ተግባር ይተዉት ፡፡
            break;
        }
        let log2_ratio = (log2_u + u_shift) - (log2_v + v_shift);
        if log2_ratio < target_ratio - 1 {
            u_shift += 1;
            *k -= 1;
        } else if log2_ratio > target_ratio + 1 {
            v_shift += 1;
            *k += 1;
        } else {
            break;
        }
    }
    u.mul_pow2(u_shift as usize);
    v.mul_pow2(v_shift as usize);
}

fn underflow<T: RawFloat>(x: Big, v: Big, rem: Big) -> T {
    if x < Big::from_u64(T::MIN_SIG) {
        let q = num::to_u64(&x);
        let z = rawfp::encode_subnormal(q);
        return round_by_remainder(v, rem, q, z);
    }
    // ምጣኔ ከዝቅተኛው አውራጅ ጋር ያለው የክልል ትርጉም አይደለም ፣ ስለሆነም ከመጠን በላይ ጥቃቅን ነገሮችን ማጠፍ እና አውራሪውን በዚህ መሠረት ማስተካከል ያስፈልገናል።
    // እውነተኛው እሴት አሁን ይህን ይመስላል
    //
    //        x lsb
    // /--------------\/
    // 1010101010101010.10101010101010 * 2^k
    // \-----/\-------/ \------------/
    //    q trunc.(በ rem የተወከለው)
    //
    // ስለዚህ ፣ የተጠጋጋ ቢቶች ሲሆኑ!= 0.5 ULP ፣ ክብ ማዞሩን በራሳቸው ይወስናሉ።
    // እነሱ እኩል ሲሆኑ ቀሪው ደግሞ ዜሮ ካልሆነ አሁንም እሴቱን ማጠናቀር ያስፈልጋል።
    // የተጠጋጋ ቁርጥራጮች 1/2 ሲሆኑ ቀሪው ዜሮ ሲሆን ብቻ የግማሽ እስከ እኩል ሁኔታ አለብን ፡፡
    //
    let bits = x.bit_length();
    let lsb = bits - T::SIG_BITS as usize;
    let q = num::get_bits(&x, lsb, bits);
    let k = T::MIN_EXP_INT + lsb as i16;
    let z = rawfp::encode_normal(Unpacked::new(q, k));
    let q_even = q % 2 == 0;
    match num::compare_with_half_ulp(&x, lsb) {
        Greater => next_float(z),
        Less => z,
        Equal if rem.is_zero() && q_even => z,
        Equal => next_float(z),
    }
}

/// በቀሪው ክፍፍል ላይ በመመርኮዝ ተራው ክብ-እስከ-እንኳን ፣ ተመሳስሏል ፡፡
fn round_by_remainder<T: RawFloat>(v: Big, r: Big, q: u64, z: T) -> T {
    let mut v_minus_r = v;
    v_minus_r.sub(&r);
    if r < v_minus_r {
        z
    } else if r > v_minus_r {
        next_float(z)
    } else if q % 2 == 0 {
        z
    } else {
        next_float(z)
    }
}