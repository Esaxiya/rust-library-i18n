//! የቅጹን የአስርዮሽ ገመድ ማጽደቅ እና መበስበስ-
//!
//! `(digits | digits? '.'? digits?) (('e' | 'E') ('+' | '-')? digits)?`
//!
//! በሌላ አነጋገር መደበኛ ተንሳፋፊ-ነጥብ አገባብ ፣ ከሁለቱ በስተቀር-ምንም ምልክት የለም ፣ እና የ "inf" እና "NaN" አያያዝ የለም ፡፡እነዚህ በሾፌሩ ተግባር (super::dec2flt) ይያዛሉ።
//!
//! ምንም እንኳን ትክክለኛ ግብዓቶችን መገንዘብ በአንፃራዊነት ቀላል ቢሆንም ፣ ይህ ሞጁል እንዲሁ ስፍር ቁጥር የሌላቸውን ልዩነቶችን በጭራሽ panic ን ውድቅ ማድረግ እና ሌሎች ሞጁሎች በተራቸው በ panic (ወይም ከመጠን በላይ ፍሰት) ላይ የሚመኩባቸውን በርካታ ቼኮች ማከናወን ይኖርበታል ፡፡
//!
//! ሁኔታውን ለማባባስ ፣ በአንድ ጊዜ በግብአት ላይ በአንድ ጊዜ የሚከሰት ሁሉ ፡፡
//! ስለዚህ ማንኛውንም ነገር ሲቀይሩ ይጠንቀቁ እና ከሌሎቹ ሞጁሎች ጋር ሁለቴ ያረጋግጡ ፡፡
//!
//!
use self::ParseResult::{Invalid, ShortcutToInf, ShortcutToZero, Valid};
use super::num;

#[derive(Debug)]
pub enum Sign {
    Positive,
    Negative,
}

#[derive(Debug, PartialEq, Eq)]
/// የአስርዮሽ ገመድ አስደሳች ክፍሎች።
pub struct Decimal<'a> {
    pub integral: &'a [u8],
    pub fractional: &'a [u8],
    /// የአስርዮሽ ኤክስፖርቱ ከ 18 የአስርዮሽ አኃዝ ያነሰ እንዲኖር የተረጋገጠ ነው ፡፡
    pub exp: i64,
}

impl<'a> Decimal<'a> {
    pub fn new(integral: &'a [u8], fractional: &'a [u8], exp: i64) -> Decimal<'a> {
        Decimal { integral, fractional, exp }
    }
}

#[derive(Debug, PartialEq, Eq)]
pub enum ParseResult<'a> {
    Valid(Decimal<'a>),
    ShortcutToInf,
    ShortcutToZero,
    Invalid,
}

/// የግብዓት ህብረቁምፊ ትክክለኛ ተንሳፋፊ ነጥብ ቁጥር ከሆነ ይፈትሻል እና እንደዚያ ከሆነ ዋናውን ክፍል ፣ የክፋዩን ክፍል እና በውስጡ ያለውን ተጓዳኝ ያግኙ።
/// ምልክቶችን አያስተናግድም ፡፡
pub fn parse_decimal(s: &str) -> ParseResult<'_> {
    if s.is_empty() {
        return Invalid;
    }

    let s = s.as_bytes();
    let (integral, s) = eat_digits(s);

    match s.first() {
        None => Valid(Decimal::new(integral, b"", 0)),
        Some(&b'e' | &b'E') => {
            if integral.is_empty() {
                return Invalid; // ከ 'e' በፊት አሃዞች የሉም
            }

            parse_exp(integral, b"", &s[1..])
        }
        Some(&b'.') => {
            let (fractional, s) = eat_digits(&s[1..]);
            if integral.is_empty() && fractional.is_empty() {
                // ከነጥቡ በፊት ወይም በኋላ ቢያንስ አንድ አሃዝ እንፈልጋለን ፡፡
                return Invalid;
            }

            match s.first() {
                None => Valid(Decimal::new(integral, fractional, 0)),
                Some(&b'e' | &b'E') => parse_exp(integral, fractional, &s[1..]),
                _ => Invalid, // ከተከፋፈለው ክፍል በኋላ ቆሻሻን መከታተል
            }
        }
        _ => Invalid, // ከመጀመሪያው አሃዝ ሕብረቁምፊ በኋላ ቆሻሻን መከታተል
    }
}

/// እስከ መጀመሪያው አሃዝ ያልሆነ አኃዝ የአስርዮሽ አሃዝ ይቀርጻል።
fn eat_digits(s: &[u8]) -> (&[u8], &[u8]) {
    let pos = s.iter().position(|c| !c.is_ascii_digit()).unwrap_or(s.len());
    s.split_at(pos)
}

/// የኤክስቴንሽን ማውጣት እና የስህተት ምርመራ ፡፡
fn parse_exp<'a>(integral: &'a [u8], fractional: &'a [u8], rest: &'a [u8]) -> ParseResult<'a> {
    let (sign, rest) = match rest.first() {
        Some(&b'-') => (Sign::Negative, &rest[1..]),
        Some(&b'+') => (Sign::Positive, &rest[1..]),
        _ => (Sign::Positive, rest),
    };
    let (mut number, trailing) = eat_digits(rest);
    if !trailing.is_empty() {
        return Invalid; // ከአቅራቢው በኋላ አላስፈላጊ ነገሮችን መከታተል
    }
    if number.is_empty() {
        return Invalid; // ባዶ ገላጭ
    }
    // በዚህ ጊዜ እኛ ትክክለኛ አሃዞች አለን ፡፡ወደ `i64` ለማስገባት በጣም ረጅም ሊሆን ይችላል ፣ ግን ያን ያህል ግዙፍ ከሆነ ግብዓቱ በእርግጥ ዜሮ ወይም ማለቂያ የለውም።
    // በአስርዮሽ አሃዞች ውስጥ ያለው እያንዳንዱ ዜሮ ተከራካሪውን በ +/-1 ብቻ የሚያስተካክለው ስለሆነ ፣ በሰዓት=10 ^ 18 ግብዓቱ ውስን ለመሆን እንኳን በርቀት ለመቅረብ የ 17 exabyte (!) ዜሮ መሆን አለበት።
    //
    // ይህ በትክክል ልንጠቀመው የሚገባ የአጠቃቀም ጉዳይ አይደለም ፡፡
    //
    while number.first() == Some(&b'0') {
        number = &number[1..];
    }
    if number.len() >= 18 {
        return match sign {
            Sign::Positive => ShortcutToInf,
            Sign::Negative => ShortcutToZero,
        };
    }
    let abs_exp = num::from_str_unchecked(number);
    let e = match sign {
        Sign::Positive => abs_exp as i64,
        Sign::Negative => -(abs_exp as i64),
    };
    Valid(Decimal::new(integral, fractional, e))
}