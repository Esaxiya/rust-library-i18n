//! የአስርዮሽ ሕብረቁምፊዎችን ወደ IEEE 754 ባለ ሁለትዮሽ ተንሳፋፊ ነጥብ ቁጥሮች መለወጥ።
//!
//! # የችግር መግለጫ
//!
//! እንደ `12.34e56` ያሉ የአስርዮሽ ገመድ ተሰጠን ፡፡
//! ይህ ሕብረቁምፊ ዋና (`12`) ፣ ክፍልፋይ (`34`) እና ኤክስፐርት (`56`) ክፍሎችን ያቀፈ ነው።ሁሉም ክፍሎች እንደአማራጭ እና ሲጎድሉ እንደ ዜሮ ይተረጎማሉ ፡፡
//!
//! ለአስርዮሽ ገመድ ትክክለኛ እሴት በጣም ቅርብ የሆነውን የ IEEE 754 ተንሳፋፊ ነጥብ ቁጥር እንፈልጋለን።
//! ብዙ የአስርዮሽ ሕብረቁምፊዎች በመሠረቱ ሁለት ላይ የሚያበቃ ውክልና እንደሌላቸው የታወቀ ነው ፣ ስለሆነም በመጨረሻው ቦታ (በሌላ አነጋገር እና በተቻለ መጠን) ወደ 0.5 ክፍሎች እንዞራለን ፡፡
//! ግንኙነቶች ፣ የአስርዮሽ እሴቶች በትክክል በተከታታይ በሁለት ተከታታይ ተንሳፋፊዎች መካከል በግማሽ እስከ እኩል ስትራቴጂ መፍትሄ አግኝተዋል ፣ የባንክ ማዞሪያ ተብሎም ይጠራል ፡፡
//!
//! በአተገባበር ውስብስብነትም ሆነ በተወሰዱ የሲፒዩ ዑደቶች ይህ በጣም ከባድ ነው ፡፡
//!
//! # Implementation
//!
//! በመጀመሪያ ምልክቶችን ችላ እንላለን ፡፡ወይም ይልቁንም በለውጡ ሂደት መጀመሪያ ላይ እናስወግደዋለን እና በመጨረሻው ላይ እንደገና ተግባራዊ እናደርጋለን።
//! የ IEEE ተንሳፋፊዎች በዜሮ ዙሪያ የተመጣጠኑ በመሆናቸው አንድ ሰው የመጀመሪያውን የመጀመሪያውን ቢገለብጠው በሁሉም የ edge ጉዳዮች ላይ ይህ ትክክል ነው ፡፡
//!
//! ከዚያ ገላጭውን በማስተካከል የአስርዮሽ ነጥቡን እናስወግደዋለን-በፅንሰ-ሀሳብ ፣ `12.34e56` ወደ `1234e54` ይለወጣል ፣ ይህም በአዎንታዊ ኢንቲጀር `f = 1234` እና ኢንቲጀር `e = 54` እንገልፃለን ፡፡
//! የ `(f, e)` ውክልና የመተንተን ደረጃውን ባለፈ በሁሉም ኮድ ማለት ይቻላል ጥቅም ላይ ይውላል።
//!
//! በመቀጠልም በማሽን መጠን ያላቸውን ቁጥሮች እና አነስተኛ መጠን ያላቸው ተንሳፋፊ ነጥብ ቁጥሮች በመጠቀም በሂደት የበለጠ አጠቃላይ እና ውድ የሆኑ ልዩ ጉዳዮችን ረጅም ሰንሰለትን እንሞክራለን (የመጀመሪያ `f32`/`f64` ፣ ከዚያ አንድ ዓይነት 64 ቢት ትርጉም ያለው ፣ `Fp`)።
//!
//! እነዚህ ሁሉ ሲሳኩ ጥይቱን ነክሰን `f * 10^e` ን ሙሉ በሙሉ ማስላት እና ለተሻለ ግምታዊነት ፍለጋ ፍለጋን ወደ ሚያካትት ቀላል ግን በጣም ዘገምተኛ ስልተ-ቀመር እንጠቀማለን ፡፡
//!
//! በዋናነት ፣ ይህ ሞጁል እና ልጆቹ በሚከተሉት ውስጥ የተገለጹትን ስልተ ቀመሮች ይተገብራሉ
//! "How to Read Floating Point Numbers Accurately" በዊሊያም ዲ
//! Clinger, በመስመር ላይ ይገኛል: <http://citeseerx.ist.psu.edu/viewdoc/summary?doi=10.1.1.45.4152>
//!
//! በተጨማሪም ፣ በወረቀቱ ውስጥ ጥቅም ላይ የሚውሉ ግን በ Rust (ወይም ቢያንስ ቢያንስ) ውስጥ የማይገኙ በርካታ ረዳት ተግባራት አሉ ፡፡
//! የእኛ ስሪት በተጨማሪ ፍሰት እና የውሃ ፍሰት ማስተናገድ እና ያልተለመዱ ቁጥሮችን ለማስተናገድ ባለው ፍላጎት በተጨማሪ የተወሳሰበ ነው።
//! ቤለሮፎን እና አልጎሪዝም አር ከመጠን በላይ ፍሰት ፣ ንዑስ ንዑስ ክፍሎች እና የውሃ ፍሰት ችግር አለባቸው ፡፡
//! ግብዓቶች ወደ ወሳኝ ክልል ከመግባታቸው በፊት ወግ አጥባቂ በሆነ መልኩ ወደ አልጎሪዝም ኤም (በወረቀቱ ክፍል 8 ላይ በተገለጹት ማሻሻያዎች) እንሸጋገራለን ፡፡
//!
//! ሌላ ትኩረት የሚፈልግ `RawFloat` `trait` በሚባል መልኩ ሁሉም ተግባራት በሚመረጡበት ሁኔታ ነው ፡፡አንድ ሰው ወደ `f64` መተንተን እና ውጤቱን ወደ `f32` መጣል በቂ ነው ብሎ ያስብ ይሆናል።
//! እንደ አለመታደል ሆኖ ይህ የምንኖርበት ዓለም አይደለም ፣ እና ይህ ከመሠረታዊ ሁለት ወይም እስከ ግማሽ-እስከ ዙር ድረስ ከመጠቀም ጋር ምንም ግንኙነት የለውም።
//!
//! ለምሳሌ ሁለት አይነቶች `d2` እና `d4` ን የአስርዮሽ አይነትን የሚወክሉ ሁለት የአስርዮሽ አሃዞች እና እያንዳንዳቸው አራት የአስርዮሽ አሃዞች ያስቡ እና "0.01499" ን እንደ ግብዓት ይውሰዱ ፡፡ግማሹን ወደላይ ማዞር እንጠቀም ፡፡
//! በቀጥታ ወደ ሁለት የአስርዮሽ አሃዞች መሄድ `0.01` ን ይሰጠናል ፣ ግን በመጀመሪያ ወደ አራት አሃዞች ካዞርን `0.0150` ን እናገኛለን ፣ ከዚያ እስከ `0.02` ድረስ ይጠናቀቃል።
//! ይኸው መርህ ለሌሎች ኦፕሬሽኖችም ይሠራል ፣ የ 0.5 ULP ትክክለኝነት ከፈለጉ ሁሉንም ሁሉንም በአንድ ጊዜ በትክክል እና በክብ *በትክክል አንድ ጊዜ ፣ በመጨረሻው* ላይ ማድረግ ያስፈልግዎታል ፣ ሁሉንም በአንድ ጊዜ የተቆረጡ ቁርጥራጮችን ከግምት ውስጥ በማስገባት ፡፡
//!
//! FIXME: ምንም እንኳን አንዳንድ የኮድ ማባዛቱ አስፈላጊ ቢሆንም ምናልባት ምናልባት የኮዱ ክፍሎች አነስተኛ ኮድ እንዲባዛ ሊደረጉ ይችላሉ ፡፡
//! ብዙ የአልጎሪዝም ክፍሎች ለማውጣት ከተንሳፋፊው ዓይነት ገለልተኛ ናቸው ፣ ወይም ጥቂት መለኪያዎች ብቻ መዳረሻ ያስፈልጋቸዋል ፣ ይህም እንደ ልኬቶች ሊተላለፍ ይችላል።
//!
//! # Other
//!
//! ልወጣው *በጭራሽ* panic የለበትም።
//! በኮዱ ውስጥ ማረጋገጫዎች እና ግልፅ panics አሉ ፣ ግን በጭራሽ መነቃቃት የለባቸውም እና እንደ ውስጣዊ የንጽህና ቼኮች ብቻ ያገለግላሉ ፡፡ማንኛውም panics እንደ ሳንካ ተደርጎ መታየት አለበት።
//!
//! የአሃድ ሙከራዎች አሉ ነገር ግን እነሱ ትክክለኛነታቸውን ለማረጋገጥ በጭካኔ በቂ አይደሉም ፣ ሊከሰቱ ከሚችሉ ስህተቶች ውስጥ አነስተኛውን መቶኛ ብቻ ይሸፍናሉ ፡፡
//! በጣም ሰፋ ያሉ ሙከራዎች በማውጫ `src/etc/test-float-parse` ውስጥ እንደ Python ስክሪፕት ይገኛሉ።
//!
//! በኢንቲጀር ፍሰት ብዛት ላይ ማስታወሻ-የዚህ ፋይል ብዙ ክፍሎች ከአስርዮሽ አክሲዮን `e` ጋር ሂሳብ ያካሂዳሉ።
//! በዋናነት ፣ የአስርዮሽ ነጥቡን ዙሪያውን እናዞራለን-ከመጀመሪያው የአስርዮሽ አሃዝ በፊት ፣ ከመጨረሻው የአስርዮሽ አሃዝ በኋላ እና የመሳሰሉት ፡፡በግዴለሽነት ከተከናወነ ይህ ሊፈስ ይችላል።
//! "sufficient" ማለት "such that the exponent +/- the number of decimal digits fits into a 64 bit integer" በሚለው በቂ ጥቃቅን ተጓዳኞችን ብቻ ለመስጠት በመተንተን ንዑስ ሞጁል ላይ እንተማመናለን ፡፡
//! ትላልቅ ኤክስፐርቶች ተቀባይነት አላቸው ፣ ግን እኛ ከእነሱ ጋር ሂሳብ አናደርግም ፣ ወዲያውኑ ወደ {positive,negative} {zero,infinity} ተለውጠዋል።
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![doc(hidden)]
#![unstable(
    feature = "dec2flt",
    reason = "internal routines only exposed for testing",
    issue = "none"
)]

use crate::fmt;
use crate::str::FromStr;

use self::num::digits_to_big;
use self::parse::{parse_decimal, Decimal, ParseResult, Sign};
use self::rawfp::RawFloat;

mod algorithm;
mod num;
mod table;
// እነዚህ ሁለቱ የራሳቸው ፈተናዎች አሏቸው ፡፡
pub mod parse;
pub mod rawfp;

macro_rules! from_str_float_impl {
    ($t:ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl FromStr for $t {
            type Err = ParseFloatError;

            /// በመሠረቱ 10 ውስጥ አንድ ክር ወደ ተንሳፋፊ ይቀይረዋል።
            /// አማራጭ የአስርዮሽ ኤክስፖርትን ይቀበላል ፡፡
            ///
            /// ይህ ተግባር እንደ
            ///
            /// * '3.14'
            /// * '-3.14'
            /// * '2.5E10', ወይም በእኩል '2.5e10'
            /// * '2.5E-10'
            /// * '5.'
            /// * '.5', ወይም በእኩል '0.5'
            /// * 'inf', '-inf', 'NaN'
            ///
            /// የነፃ ቦታን መምራት እና መከተሉ ስህተትን ይወክላሉ።
            ///
            /// # Grammar
            ///
            /// የሚከተሉትን የ [EBNF] ሰዋስው የሚያከብሩ ሁሉም ሕብረቁምፊዎች የ [`Ok`] ን ተመላሽ ያደርጋቸዋል
            ///
            ///
            /// ```txt
            /// Float  ::= Sign? ( 'inf' | 'NaN' | Number )
            /// Number ::= ( Digit+ |
            ///              Digit+ '.' Digit* |
            ///              Digit* '.' Digit+ ) Exp?
            /// Exp    ::= [eE] Sign? Digit+
            /// Sign   ::= [+-]
            /// Digit  ::= [0-9]
            /// ```
            ///
            /// [EBNF]: https://www.w3.org/TR/REC-xml/#sec-notation
            ///
            /// # የታወቁ ሳንካዎች
            ///
            /// በአንዳንድ ሁኔታዎች ፣ ትክክለኛ ተንሳፋፊ መፍጠር ያለባቸው አንዳንድ ሕብረቁምፊዎች በምትኩ ስህተትን ይመልሳሉ።
            /// ለዝርዝሮች [issue #31407] ን ይመልከቱ ፡፡
            ///
            /// [issue #31407]: https://github.com/rust-lang/rust/issues/31407
            ///
            /// # Arguments
            ///
            /// * src ፣ አንድ ገመድ
            ///
            /// # ተመለስ እሴት
            ///
            /// `Err(ParseFloatError)` ሕብረቁምፊው ትክክለኛ ቁጥር የማይወክል ከሆነ።
            /// አለበለዚያ `n` በ `src` የተወከለው ተንሳፋፊ-ነጥብ ቁጥር ባለበት `Ok(n)`።
            ///
            #[inline]
            fn from_str(src: &str) -> Result<Self, ParseFloatError> {
                dec2flt(src)
            }
        }
    };
}
from_str_float_impl!(f32);
from_str_float_impl!(f64);

/// ተንሳፋፊን በሚተነተንበት ጊዜ ሊመለስ የሚችል ስህተት።
///
/// ይህ ስህተት ለ [`f32`] እና [`f64`] ለ [`FromStr`] ትግበራ እንደ የስህተት ዓይነት ጥቅም ላይ ይውላል ፡፡
///
///
/// # Example
///
/// ```
/// use std::str::FromStr;
///
/// if let Err(e) = f64::from_str("a.12") {
///     println!("Failed conversion to f64: {}", e);
/// }
/// ```
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseFloatError {
    kind: FloatErrorKind,
}

#[derive(Debug, Clone, PartialEq, Eq)]
enum FloatErrorKind {
    Empty,
    Invalid,
}

impl ParseFloatError {
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            FloatErrorKind::Empty => "cannot parse float from empty string",
            FloatErrorKind::Invalid => "invalid float literal",
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseFloatError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}

fn pfe_empty() -> ParseFloatError {
    ParseFloatError { kind: FloatErrorKind::Empty }
}

fn pfe_invalid() -> ParseFloatError {
    ParseFloatError { kind: FloatErrorKind::Invalid }
}

/// የቀረውን ሳይመረምር ወይም ሳያረጋግጥ የአስርዮሽ ሕብረቁምፊን ወደ ምልክት እና ቀሪው ይከፍላል።
fn extract_sign(s: &str) -> (Sign, &str) {
    match s.as_bytes()[0] {
        b'+' => (Sign::Positive, &s[1..]),
        b'-' => (Sign::Negative, &s[1..]),
        // ሕብረቁምፊው ልክ ያልሆነ ከሆነ ምልክቱን በጭራሽ አንጠቀምም ፣ ስለሆነም እዚህ ማረጋገጥ አያስፈልገንም።
        _ => (Sign::Positive, s),
    }
}

/// የአስርዮሽ ሕብረቁምፊን ወደ ተንሳፋፊ ነጥብ ቁጥር ይለውጣል።
fn dec2flt<T: RawFloat>(s: &str) -> Result<T, ParseFloatError> {
    if s.is_empty() {
        return Err(pfe_empty());
    }
    let (sign, s) = extract_sign(s);
    let flt = match parse_decimal(s) {
        ParseResult::Valid(decimal) => convert(decimal)?,
        ParseResult::ShortcutToInf => T::INFINITY,
        ParseResult::ShortcutToZero => T::ZERO,
        ParseResult::Invalid => match s {
            "inf" => T::INFINITY,
            "NaN" => T::NAN,
            _ => {
                return Err(pfe_invalid());
            }
        },
    };

    match sign {
        Sign::Positive => Ok(flt),
        Sign::Negative => Ok(-flt),
    }
}

/// ከአስርዮሽ-ወደ-ተንሳፋፊ ለመለወጥ ዋናው የሥራ መስክ ሁሉንም ቅድመ-ቅደም-ተከተሎችን ማቀናጀት እና የትኛው ስልተ-ቀመር ትክክለኛውን ልወጣ ማድረግ እንዳለበት ይረዱ ፡፡
///
fn convert<T: RawFloat>(mut decimal: Decimal<'_>) -> Result<T, ParseFloatError> {
    simplify(&mut decimal);
    if let Some(x) = trivial_cases(&decimal) {
        return Ok(x);
    }
    // Remove/shift የአስርዮሽ ነጥብ ውጭ።
    let e = decimal.exp - decimal.fractional.len() as i64;
    if let Some(x) = algorithm::fast_path(decimal.integral, decimal.fractional, e) {
        return Ok(x);
    }
    // ቢግ 32x40 በ 1280 ቢቶች የተወሰነ ሲሆን ይህም ወደ 385 የአስርዮሽ አሃዝ ይተረጉማል ፡፡
    // ከዚህ በላይ ከጨረስን እንወድቃለን ፣ ስለዚህ ከመጠጋታችን በፊት ስህተት እንሠራለን (በ 10 ^ 10 ውስጥ)።
    let upper_bound = bound_intermediate_digits(&decimal, e);
    if upper_bound > 375 {
        return Err(pfe_invalid());
    }
    let f = digits_to_big(decimal.integral, decimal.fractional);

    // አሁን አውራሪው በትክክል በዋናው ስልተ ቀመሮች ውስጥ ጥቅም ላይ በሚውለው በ 16 ቢት ውስጥ ይጣጣማል ፡፡
    let e = e as i16;
    // FIXME እነዚህ ወሰኖች ወግ አጥባቂ ናቸው።
    // የቤልሮፎን ውድቀት ሁነታዎች የበለጠ ጠንቃቃ ትንታኔ ለብዙ ጉዳዮች በከፍተኛ ፍጥነት እንዲጠቀሙበት ሊፈቅድ ይችላል ፡፡
    let exponent_in_range = table::MIN_E <= e && e <= table::MAX_E;
    let value_in_range = upper_bound <= T::MAX_NORMAL_DIGITS as u64;
    if exponent_in_range && value_in_range {
        Ok(algorithm::bellerophon(&f, e))
    } else {
        Ok(algorithm::algorithm_m(&f, e))
    }
}

// እንደተፃፈው ይህ በጥሩ ሁኔታ ያመቻቻል (#27130 ን ይመልከቱ ፣ ምንም እንኳን የድሮውን የኮዱን ስሪት የሚያመለክት ቢሆንም)።
// `inline(always)` ለዚያ የሥራ መልመጃ ነው ፡፡
// በአጠቃላይ ሁለት የጥሪ ጣቢያዎች ብቻ ናቸው እና የኮዱን መጠን ያባብሰዋል ፡፡

/// በሚቻልበት ቦታ ዜሮዎችን ያርቁ ፣ ይህ እንኳን ኤክስፖርቱን መለወጥ ቢያስፈልግም
#[inline(always)]
fn simplify(decimal: &mut Decimal<'_>) {
    let is_zero = &|&&d: &&u8| -> bool { d == b'0' };
    // እነዚህን ዜሮዎች መከርከም ምንም ነገር አይለውጥም ነገር ግን ፈጣን መንገዱን (<15 ቁጥሮች) ሊያነቃ ይችላል።
    let leading_zeros = decimal.integral.iter().take_while(is_zero).count();
    decimal.integral = &decimal.integral[leading_zeros..];
    let trailing_zeros = decimal.fractional.iter().rev().take_while(is_zero).count();
    let end = decimal.fractional.len() - trailing_zeros;
    decimal.fractional = &decimal.fractional[..end];
    // የቅጹን ቁጥሮች ቀለል ያድርጉ 0.0 ... x እና x ... 0.0 ፣ አክሲዮኑን በትክክል በማስተካከል ፡፡
    // ይህ ሁልጊዜ ድል ላይሆን ይችላል (ምናልባትም የተወሰኑ ቁጥሮች ከፈጣን መንገድ ያስወጣቸዋል) ፣ ግን ሌሎች ክፍሎችን በከፍተኛ ሁኔታ ያቃልላል (በተለይም የእሴቱን መጠን በግምት)።
    //
    if decimal.integral.is_empty() {
        let leading_zeros = decimal.fractional.iter().take_while(is_zero).count();
        decimal.fractional = &decimal.fractional[leading_zeros..];
        decimal.exp -= leading_zeros as i64;
    } else if decimal.fractional.is_empty() {
        let trailing_zeros = decimal.integral.iter().rev().take_while(is_zero).count();
        let end = decimal.integral.len() - trailing_zeros;
        decimal.integral = &decimal.integral[..end];
        decimal.exp += trailing_zeros as i64;
    }
}

/// በተሰጠው አስርዮሽ ላይ በሚሠራበት ጊዜ አልጎሪዝም አር እና አልጎሪዝም ኤም ከሚሰሉት ትልቁ ዋጋ (log10) መጠን ላይ ፈጣን-የቆሸሸ የላይኛው ማሰሪያን ይመልሳል።
///
fn bound_intermediate_digits(decimal: &Decimal<'_>, e: i64) -> u64 {
    // ለእኛ እጅግ በጣም ከባድ የሆኑ ግቤቶችን በማጣራት ለ trivial_cases() እና ለጠቋሚው አመሰግናለሁ እዚህ ከመጠን በላይ መጨነቅ አያስፈልገንም።
    //
    let f_len: u64 = decimal.integral.len() as u64 + decimal.fractional.len() as u64;
    if e >= 0 {
        // በጉዳይ e>=0 ፣ ሁለቱም ስልተ ቀመሮች ስለ `f * 10^e` ይሰላሉ።
        // አልጎሪዝም R በዚህ አንዳንድ ውስብስብ ስሌቶችን ያካሂዳል ነገር ግን ለላይኛው ድንበር ችላ ማለት እንችላለን ምክንያቱም ቀደም ሲል ደግሞ ክፋዩን ይቀንሰዋል ፣ ስለሆነም እዚያ ብዙ ማቆሚያዎች አሉን።
        //
        f_len + (e as u64)
    } else {
        // E <0 ከሆነ ፣ አልጎሪዝም R ተመሳሳይ ተመሳሳይ ነገር ያደርጋል ፣ ግን አልጎሪዝም M ይለያል
        // `f << k / 10^e` የክልል ትርጉም ያለው ስለሆነ አዎንታዊ ቁጥር k ለማግኘት ይሞክራል።
        // ይህ ወደ `2^53 *f* 10^e` <`10^17 *f* 10^e` ያስከትላል።
        // ይህንን የሚያነቃቃ አንድ ግቤት 0.33 ... 33 (375 x 3) ነው ፡፡
        f_len + e.unsigned_abs() + 17
    }
}

/// የአስርዮሽ አሃዞችን እንኳን ሳይመለከቱ ግልጽ የሆኑ ፍሰቶችን እና የውሃ ፍሰቶችን ያገኛል ፡፡
fn trivial_cases<T: RawFloat>(decimal: &Decimal<'_>) -> Option<T> {
    // ዜሮዎች ነበሩ ግን በ simplify() ተዘርፈዋል
    if decimal.integral.is_empty() && decimal.fractional.is_empty() {
        return Some(T::ZERO);
    }
    // ይህ የ‹ceil(log10(the real value)) X›ጥሬ ግምታዊ አቀራረብ ነው ፡፡
    // እዚህ የግብዓት ርዝመት በጣም ትንሽ ስለሆነ (ቢያንስ ከ 2 ^ 64 ጋር ሲነፃፀር) ስለሆነ እዚህ ከመጠን በላይ መጨነቅ አያስፈልገንም እናም ጠቋሚው ቀድሞውኑ ፍፁም እሴቱ ከ 10 greater 18 ከፍ ያለ ሰፋፊዎችን ያስተናግዳል (አሁንም ቢሆን 10 ^ 19 አጭር ነው) ከ 2 ^ 64)።
    //
    //
    let max_place = decimal.exp + decimal.integral.len() as i64;
    if max_place > T::INF_CUTOFF {
        return Some(T::INFINITY);
    } else if max_place < T::ZERO_CUTOFF {
        return Some(T::ZERO);
    }
    None
}