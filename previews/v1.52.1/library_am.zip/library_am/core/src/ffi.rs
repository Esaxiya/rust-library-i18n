#![stable(feature = "", since = "1.30.0")]
#![allow(non_camel_case_types)]

//! (FFI) ማሰሪያዎች በይነገፅ የውጭ ተግባር ጋር የተያያዙ መገልገያዎች.

use crate::fmt;
use crate::marker::PhantomData;
use crate::ops::{Deref, DerefMut};

/// C ዎቹ `void` አይነት ተመጣጣኝ የሆነ [pointer] ሆኖ ያገለግላል ጊዜ.
///
/// በመሠረቱ ፣ `*const c_void` ከ C`s `const void*` ጋር እኩል ሲሆን `*mut c_void` ከ C`s `void*` ጋር እኩል ነው ፡፡
/// ይህ በዚህ *Rust ያለው `()` አይነት ነው ሐ ዎቹ `void` መመለስ ዓይነት, እንደ* ተመሳሳይ አይደለም አለ.
///
/// በኤክስኤፍአይ ውስጥ ግልጽ ያልሆኑ ዓይነቶች ጠቋሚዎችን ለማሳየት ፣ `extern type` እስኪረጋጋ ድረስ ፣ በባዶ ባይት ድርድር ዙሪያ የ newtype መጠቅለያ እንዲጠቀሙ ይመከራል።
///
/// ለዝርዝሮች [Nomicon] ን ይመልከቱ ፡፡
///
/// እነርሱ 1.1.0 ወደ የድሮ Rust አጠናቃሪ ታች ድጋፍ የሚፈልጉ ከሆነ አንድ `std::os::raw::c_void` መጠቀም ይችላል.
/// ከ Rust 1.30.0 በኋላ በዚህ ፍቺ እንደገና ወደ ውጭ ተላከ።
/// ተጨማሪ መረጃ ለማግኘት, [RFC 2521] ያንብቡ.
///
/// [Nomicon]: https://doc.rust-lang.org/nomicon/ffi.html#representing-opaque-structs
/// [RFC 2521]: https://github.com/rust-lang/rfcs/blob/master/text/2521-c_void-reunification.md
///
// ማሳሰቢያ, LLVM ወደ ከንቱ የጠቋሚ አይነት እውቅና ለማግኘት እና malloc() እንደ ቅጥያ ተግባራት አማካኝነት, እኛ i8 LLVM bitcode ውስጥ * እንደ የተወከለው ሊኖራቸው ይገባል.
// እዚህ ጥቅም ላይ የዋለው enum ይህን ያረጋግጣል እና የሚያግድ ብቻ የግል መሰሎች በማድረግ ወደ "raw" አይነት አላግባብ.
// የ አጠናቃሪ ስለ repr አይነታ ስለ አለበለዚያ ቅሬታውን ስለሆነ እኛ ሁለት ተለዋጮች ያስፈልገናል እናም እኛ አለበለዚያ enum ሳታስፈቅዱ ነበር እና ቢያንስ እንዲህ ዘዴውን dereferencing ይሆናል ub እንደ ቢያንስ አንድ ተለዋጭ ያስፈልገናል.
//
//
//
//
//
#[repr(u8)]
#[stable(feature = "core_c_void", since = "1.30.0")]
pub enum c_void {
    #[unstable(
        feature = "c_void_variant",
        reason = "temporary implementation detail",
        issue = "none"
    )]
    #[doc(hidden)]
    __variant1,
    #[unstable(
        feature = "c_void_variant",
        reason = "temporary implementation detail",
        issue = "none"
    )]
    #[doc(hidden)]
    __variant2,
}

#[stable(feature = "std_debug", since = "1.16.0")]
impl fmt::Debug for c_void {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("c_void")
    }
}

/// የ `va_list` መሰረታዊ አተገባበር።
// ለአሁን `VaListImpl` ን በመጠቀም ስሙ WIP ነው።
#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[repr(transparent)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    ptr: *mut c_void,

    // ከ `'f` በላይ የማይለዋወጥ ፣ ስለሆነም እያንዳንዱ የ `VaListImpl<'f>` ነገር ከተገለጸው ተግባር ክልል ጋር የተቆራኘ ነው
    //
    _marker: PhantomData<&'f mut &'f c_void>,
}

#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> fmt::Debug for VaListImpl<'f> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "va_list* {:p}", self.ptr)
    }
}

/// AArch64 የ‹`va_list` X›ኤቢአይ አተገባበር ፡፡
/// ተጨማሪ ዝርዝሮችን ለማግኘት [AArch64 Procedure Call Standard] ይመልከቱ.
///
/// [AArch64 Procedure Call Standard]:
/// http://infocenter.arm.com/help/topic/com.arm.doc.ihi0055b/IHI0055B_aapcs64.pdf
#[cfg(all(
    target_arch = "aarch64",
    not(any(target_os = "macos", target_os = "ios")),
    not(windows)
))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    stack: *mut c_void,
    gr_top: *mut c_void,
    vr_top: *mut c_void,
    gr_offs: i32,
    vr_offs: i32,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// PowerPC የ‹`va_list` X›ኤቢአይ አተገባበር ፡፡
#[cfg(all(target_arch = "powerpc", not(windows)))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    gpr: u8,
    fpr: u8,
    reserved: u16,
    overflow_arg_area: *mut c_void,
    reg_save_area: *mut c_void,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// x86_64 የ‹`va_list` X›ኤቢአይ አተገባበር ፡፡
#[cfg(all(target_arch = "x86_64", not(windows)))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    gp_offset: i32,
    fp_offset: i32,
    overflow_arg_area: *mut c_void,
    reg_save_area: *mut c_void,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// ለ `va_list` መጠቅለያ
#[repr(transparent)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
pub struct VaList<'a, 'f: 'a> {
    #[cfg(any(
        all(
            not(target_arch = "aarch64"),
            not(target_arch = "powerpc"),
            not(target_arch = "x86_64")
        ),
        all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
        target_arch = "wasm32",
        target_arch = "asmjs",
        windows
    ))]
    inner: VaListImpl<'f>,

    #[cfg(all(
        any(target_arch = "aarch64", target_arch = "powerpc", target_arch = "x86_64"),
        any(not(target_arch = "aarch64"), not(any(target_os = "macos", target_os = "ios"))),
        not(target_arch = "wasm32"),
        not(target_arch = "asmjs"),
        not(windows)
    ))]
    inner: &'a mut VaListImpl<'f>,

    _marker: PhantomData<&'a mut VaListImpl<'f>>,
}

#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// ከ C's `va_list` ጋር ሁለትዮሽ ተኳሃኝ የሆነ `VaListImpl` ን ወደ `VaList` ይለውጡ ፡፡
    #[inline]
    pub fn as_va_list<'a>(&'a mut self) -> VaList<'a, 'f> {
        VaList { inner: VaListImpl { ..*self }, _marker: PhantomData }
    }
}

#[cfg(all(
    any(target_arch = "aarch64", target_arch = "powerpc", target_arch = "x86_64"),
    any(not(target_arch = "aarch64"), not(any(target_os = "macos", target_os = "ios"))),
    not(target_arch = "wasm32"),
    not(target_arch = "asmjs"),
    not(windows)
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// ከ C's `va_list` ጋር ሁለትዮሽ ተኳሃኝ የሆነ `VaListImpl` ን ወደ `VaList` ይለውጡ ፡፡
    #[inline]
    pub fn as_va_list<'a>(&'a mut self) -> VaList<'a, 'f> {
        VaList { inner: self, _marker: PhantomData }
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'a, 'f: 'a> Deref for VaList<'a, 'f> {
    type Target = VaListImpl<'f>;

    #[inline]
    fn deref(&self) -> &VaListImpl<'f> {
        &self.inner
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'a, 'f: 'a> DerefMut for VaList<'a, 'f> {
    #[inline]
    fn deref_mut(&mut self) -> &mut VaListImpl<'f> {
        &mut self.inner
    }
}

// VaArgSafe trait በሕዝብ መገናኛዎች ውስጥ ጥቅም ላይ መዋል አለበት ፣ ሆኖም ፣ trait ራሱ ከዚህ ሞጁል ውጭ እንዲጠቀም መፈቀድ የለበትም ፡፡
// ተጠቃሚዎች (ስለተባለ va_arg ነጥሎ አዲስ አይነት ላይ ጥቅም ላይ እንዲውል ፈቅደዋል) አዲስ አይነት ለ trait ለመተግበር በመፍቀድ አይቀርም ያልተገለጸ ባህሪ ምክንያት ነው.
//
// FIXME(dlrobertson): የህዝብ በይነገጽ ውስጥ VaArgSafe trait መጠቀም ሳይሆን ሌላ ቦታ ላይ ሊውል አይችልም ለማረጋገጥ እንዲቻል, የ trait የግል ሞጁል ውስጥ ይፋዊ መሆን አለበት.
// RFC 2145 አንዴ ይህን ለማሻሻል ወደ መልክ ተግባራዊ ተደርጓል.
//
//
//
//
mod sealed_trait {
    /// የተፈቀዱ አይነቶችን ከ [super::VaListImpl::arg] ጋር እንዲጠቀሙ የሚፈቅድ Trait
    #[unstable(
        feature = "c_variadic",
        reason = "the `c_variadic` feature has not been properly tested on \
                  all supported platforms",
        issue = "44930"
    )]
    pub trait VaArgSafe {}
}

macro_rules! impl_va_arg_safe {
    ($($t:ty),+) => {
        $(
            #[unstable(feature = "c_variadic",
                       reason = "the `c_variadic` feature has not been properly tested on \
                                 all supported platforms",
                       issue = "44930")]
            impl sealed_trait::VaArgSafe for $t {}
        )+
    }
}

impl_va_arg_safe! {i8, i16, i32, i64, usize}
impl_va_arg_safe! {u8, u16, u32, u64, isize}
impl_va_arg_safe! {f64}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<T> sealed_trait::VaArgSafe for *mut T {}
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<T> sealed_trait::VaArgSafe for *const T {}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// ወደ ቀጣዩ አርጋ ይቅረቡ ፡፡
    #[inline]
    pub unsafe fn arg<T: sealed_trait::VaArgSafe>(&mut self) -> T {
        // ደህንነት: የደዋዩን `va_arg` ለ የደህንነት ውል መደገፍ አለበት.
        unsafe { va_arg(self) }
    }

    /// በአሁኑ አካባቢ ላይ ቅጂዎች `va_list`.
    pub unsafe fn with_copy<F, R>(&self, f: F) -> R
    where
        F: for<'copy> FnOnce(VaList<'copy, 'f>) -> R,
    {
        let mut ap = self.clone();
        let ret = f(ap.as_va_list());
        // ደህንነት-ደዋዩ ለ `va_end` የደህንነትን ውል ማክበር አለበት ፡፡
        unsafe {
            va_end(&mut ap);
        }
        ret
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> Clone for VaListImpl<'f> {
    #[inline]
    fn clone(&self) -> Self {
        let mut dest = crate::mem::MaybeUninit::uninit();
        // ደህንነት-ወደ `MaybeUninit` እንጽፋለን ፣ ስለሆነም ተጀምሯል እና `assume_init` ህጋዊ ነው
        unsafe {
            va_copy(dest.as_mut_ptr(), self);
            dest.assume_init()
        }
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> Drop for VaListImpl<'f> {
    fn drop(&mut self) {
        // FIXME: ይህ `va_end` ን መጥራት አለበት ፣ ግን ወደዚህ ለመሄድ ምንም ንጹህ መንገድ የለም
        // የ `va_end` በቀጥታ ተጓዳኝ `va_copy` ተመሳሳይ ተግባር ከ ተብሎ ማግኘት ነበር, ስለዚህ `drop` ሁልጊዜ, በውስጡ ደዋይ ወደ inlined የማያገኘው ዋስትና.
        // `man va_end` ሲ ይህንን እንደሚፈልግ ይናገራል ፣ እና LLVM በመሠረቱ የ C ን ትርጓሜውን ይከተላል ፣ ስለሆነም `va_end` ሁልጊዜ ከ `va_copy` ተመሳሳይ ተግባር የሚጠራ መሆኑን ማረጋገጥ አለብን ፡፡
        //
        // ለተጨማሪ ዝርዝሮች see https://github.com/rust-lang/rust/pull/59625andhttps://llvm.org/docs/LangRef.html#llvm-va-end-intrinsic.
        //
        // `va_end` በሁሉም የወቅቱ የኤልኤልቪኤም ዒላማዎች ላይ ምርጫ-አልባ ስለሆነ ይህ ለአሁኑ ይሠራል።
        //
        //
        //
    }
}

extern "rust-intrinsic" {
    /// `va_start` ወይም `va_copy` ጋር ማስጀመር በኋላ arglist `ap` ለማጥፋት.
    ///
    fn va_end(ap: &mut VaListImpl<'_>);

    /// ቅጂዎች ወደ arglist `dst` ወደ arglist `src` የአሁኑ አካባቢ.
    fn va_copy<'f>(dest: *mut VaListImpl<'f>, src: &VaListImpl<'f>);

    /// ጭነቶች አንድ የ `va_list` `ap` ከ አይነት `T` መካከል ክርክር እና ወደ ክርክር `ap` ነጥቦች አልጨመረም.
    ///
    fn va_arg<T: sealed_trait::VaArgSafe>(ap: &mut VaListImpl<'_>) -> T;
}