use crate::iter::FromIterator;

/// ሁሉንም የንጥል ነገሮች ከአንድ ተደጋጋሚ ወደ አንድ ይሰብስባቸዋል።
///
/// አንተ ብቻ ስህተቶች ግድ ቦታ `Result<(), E>` ጋር በመሰብሰብ ያሉ, ከፍተኛ-ደረጃ abstractions ጋር ተዳምሮ ጊዜ ይህ ይበልጥ ጠቃሚ ነው:
///
///
/// ```
/// use std::io::*;
/// let data = vec![1, 2, 3, 4, 5];
/// let res: Result<()> = data.iter()
///     .map(|x| writeln!(stdout(), "{}", x))
///     .collect();
/// assert!(res.is_ok());
/// ```
#[stable(feature = "unit_from_iter", since = "1.23.0")]
impl FromIterator<()> for () {
    fn from_iter<I: IntoIterator<Item = ()>>(iter: I) -> Self {
        iter.into_iter().for_each(|()| {})
    }
}