use crate::cmp::Ordering;
use crate::convert::From;
use crate::fmt;
use crate::hash;
use crate::marker::Unsize;
use crate::mem::{self, MaybeUninit};
use crate::ops::{CoerceUnsized, DispatchFromDyn};
use crate::ptr::Unique;
use crate::slice::{self, SliceIndex};

/// `*mut T` ግን ዜሮ ያልሆነ እና ተለዋዋጭ.
///
/// ጥሬ ጠቋሚዎችን በመጠቀም የውሂብ መዋቅሮችን በሚገነቡበት ጊዜ ይህ ብዙውን ጊዜ የሚጠቀሙበት ትክክለኛ ነገር ነው ፣ ግን በመጨረሻዎቹ ተጨማሪ ባህሪዎች ምክንያት ለመጠቀም በጣም አደገኛ ነው።`NonNull<T>` ን መጠቀም አለብዎት እርግጠኛ ካልሆኑ `*mut T` ን ብቻ ይጠቀሙ!
///
/// ከ `*mut T` በተለየ ጠቋሚው በጭራሽ ባይመዘገብም ጠቋሚው ሁልጊዜ ዋጋ ቢስ መሆን አለበት ፡፡ይህ የሆነው ኤንሞች ይህንን የተከለከለውን እሴት እንደ አድልዎ እንዲጠቀሙበት ነው-`Option<NonNull<T>>` ከ `* mut T` ጋር ተመሳሳይ መጠን አለው ፡፡
/// ሆኖም ጠቋሚው ካልተመዘገበ አሁንም ይንጠለጠል ይሆናል ፡፡
///
/// `*mut T` በተለየ `NonNull<T>` `T` ላይ covariant እንዲሆን ተመረጠ.ይህ ተጓዳኝ ዓይነቶችን በሚገነቡበት ጊዜ `NonNull<T>` ን እንዲጠቀም ያደርገዋል ፣ ነገር ግን በእውነቱ ተለዋዋጭ መሆን በማይኖርበት ዓይነት ጥቅም ላይ የሚውል ከሆነ የመመርመሪያ አደጋን ያስተዋውቃል።
/// (ተቃራኒው ምርጫ ለ‹XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX.X.XXXX.
///
/// እንደ `Box` ፣ `Rc` ፣ `Arc` ፣ `Vec` እና `LinkedList` ያሉ በጣም ደህንነቱ የተጠበቀ ረቂቅ ህዋሳት መለዋወጥ ትክክል ነው ፡፡ይህ የሆነበት ምክንያት መደበኛ የ‹X0Rust0Z›የተለመዱ የተጋሩ የ XOR ተለዋዋጭ ባህሪያትን የሚከተል ይፋዊ ኤፒአይ ስለሚያቀርቡ ነው ፡፡
///
/// የእርስዎ ዓይነት በደህና ሁኔታ ተለዋዋጭ መሆን ካልቻለ የማይለዋወጥ ሁኔታን ለማቅረብ አንዳንድ ተጨማሪ መስክ መያዙን ማረጋገጥ አለብዎት።ብዙውን ጊዜ ይህ መስክ እንደ `PhantomData<Cell<T>>` ወይም `PhantomData<&'a mut T>` ያለ [`PhantomData`] ዓይነት ይሆናል።
///
/// `NonNull<T>` ለ `&T` የ `From` ምሳሌ እንዳለው ልብ ይበሉ ፡፡ሆኖም ፣ ይህ በ‹X11X›ውስጥ ሚውቴሽኑ ካልተከሰተ በቀር (ጠቋሚ ከ) በተገኘው የጋራ ማጣቀሻ በኩል መለዋወጥ ያልተገለጸ ባህሪ መሆኑን አይለውጠውም ፡፡ከተጋራ ማጣቀሻ የሚለዋወጥ ማጣቀሻ ለመፍጠር ተመሳሳይ ነው።
///
/// ያለ `UnsafeCell<T>` ይህንን የ `From` ምሳሌ ሲጠቀሙ `as_mut` በጭራሽ አለመጠራቱን እና `as_ptr` በጭራሽ ለ ሚውቴሽን ጥቅም ላይ እንደማይውል ማረጋገጥ የእርስዎ ኃላፊነት ነው ፡፡
///
/// [`PhantomData`]: crate::marker::PhantomData
/// [`UnsafeCell<T>`]: crate::cell::UnsafeCell
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "nonnull", since = "1.25.0")]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
#[rustc_nonnull_optimization_guaranteed]
pub struct NonNull<T: ?Sized> {
    pointer: *const T,
}

/// `NonNull` እነሱ የሚጠቁሙት ውሂብ ተለዋጭ ሊሆን ስለሚችል ጠቋሚዎች `Send` አይደሉም።
// NB ፣ ይህ ማመላለሻ አላስፈላጊ ነው ፣ ግን የተሻሉ የስህተት መልዕክቶችን ማቅረብ አለበት።
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Send for NonNull<T> {}

/// `NonNull` እነሱ የሚጠቁሙት ውሂብ ተለዋጭ ሊሆን ስለሚችል ጠቋሚዎች `Sync` አይደሉም።
// NB ፣ ይህ ማመላለሻ አላስፈላጊ ነው ፣ ግን የተሻሉ የስህተት መልዕክቶችን ማቅረብ አለበት።
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Sync for NonNull<T> {}

impl<T: Sized> NonNull<T> {
    /// የተንጠለጠለ ፣ ግን በጥሩ ሁኔታ የተስተካከለ አዲስ `NonNull` ን ይፈጥራል።
    ///
    /// እንደ `Vec::new` እንደሚያደርጋት ሰነፍ የሚመደቡትን ዓይነቶች ለመጀመር ይህ ጠቃሚ ነው ፡፡
    ///
    /// የጠቋሚ እሴቱ ትክክለኛ ጠቋሚ ወደ `T` ሊወክል እንደሚችል ልብ ይበሉ ፣ ይህ ማለት ይህ እንደ "not yet initialized" የኋላ እሴት ጥቅም ላይ መዋል የለበትም።
    /// ታካቾች ለመመደብ ዘንድ አይነቶች በሌላ መንገድ ማስጀመር መከታተል አለባቸው.
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_dangling", since = "1.32.0")]
    #[inline]
    pub const fn dangling() -> Self {
        // ደህንነት mem::align_of() ዜሮ ያልሆነ አጠቃቀሙን ይመልሳል ፣ ከዚያ በኋላ ይጣላል
        // ወደ አንድ * mut T.
        // ስለዚህ ፣ `ptr` ባዶ አይደለም እና new_unchecked() ን ለመጥራት የሚያስፈልጉ ሁኔታዎች ይከበራሉ።
        unsafe {
            let ptr = mem::align_of::<T>() as *mut T;
            NonNull::new_unchecked(ptr)
        }
    }

    /// ወደ እሴቱ የተጋራ ማጣቀሻዎችን ይመልሳል።ከ [`as_ref`] በተቃራኒው ይህ እሴቱ እንዲጀመር አይፈልግም።
    ///
    /// ለሚለዋወጥ አቻ [`as_uninit_mut`] ን ይመልከቱ ፡፡
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    ///
    /// # Safety
    ///
    /// ይህንን ዘዴ ሲደውሉ የሚከተሉት ሁሉ እውነት መሆናቸውን ማረጋገጥ አለብዎት-
    ///
    /// * ጠቋሚው በትክክል መስተካከል አለበት።
    ///
    /// * በ [the module documentation] በተገለጸው ስሜት ውስጥ "dereferencable" መሆን አለበት።
    ///
    /// * የተመለሰው የሕይወት ዘመን `'a` በዘፈቀደ የተመረጠ ስለሆነ እና የውሂቡን ትክክለኛ የሕይወት ዘመን የሚያንፀባርቅ ባለመሆኑ የ Rust ተለዋጭ ስም ደንቦችን ማስከበር አለብዎት።
    ///
    ///   በተለይም እስከዚህ የሕይወት ዘመን ድረስ ጠቋሚው የሚያመለክተው ማህደረ ትውስታ መለወጥ የለበትም (ከ `UnsafeCell` ውስጥ በስተቀር) ፡፡
    ///
    /// የዚህ ዘዴ ውጤት ጥቅም ላይ ያልዋለ ቢሆንም ይህ ተግባራዊ ይሆናል!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref(&self) -> &MaybeUninit<T> {
        // ደህንነት-ደዋዩ `self` ሁሉንም እንደሚያሟላ ዋስትና መስጠት አለበት
        // ለማጣቀሻ መስፈርቶች
        unsafe { &*self.cast().as_ptr() }
    }

    /// ወደ እሴቱ ልዩ ማጣቀሻዎችን ይመልሳል።ከ [`as_mut`] በተቃራኒው ይህ እሴቱ እንዲጀመር አይፈልግም።
    ///
    /// ለተጋራው አቻ [`as_uninit_ref`] ን ይመልከቱ ፡፡
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    ///
    /// # Safety
    ///
    /// ይህንን ዘዴ ሲደውሉ የሚከተሉት ሁሉ እውነት መሆናቸውን ማረጋገጥ አለብዎት-
    ///
    /// * ጠቋሚው በትክክል መስተካከል አለበት።
    ///
    /// * በ [the module documentation] በተገለጸው ስሜት ውስጥ "dereferencable" መሆን አለበት።
    ///
    /// * የተመለሰው የሕይወት ዘመን `'a` በዘፈቀደ የተመረጠ ስለሆነ እና የውሂቡን ትክክለኛ የሕይወት ዘመን የሚያንፀባርቅ ባለመሆኑ የ Rust ተለዋጭ ስም ደንቦችን ማስከበር አለብዎት።
    ///
    ///   በተለይም በዚህ የሕይወት ዘመን ሁሉ ጠቋሚው የሚያመለክተው ማህደረ ትውስታ በሌላ ጠቋሚ በኩል ማግኘት (ማንበብ ወይም መጻፍ) የለበትም ፡፡
    ///
    /// የዚህ ዘዴ ውጤት ጥቅም ላይ ያልዋለ ቢሆንም ይህ ተግባራዊ ይሆናል!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_mut(&mut self) -> &mut MaybeUninit<T> {
        // ደህንነት-ደዋዩ `self` ሁሉንም እንደሚያሟላ ዋስትና መስጠት አለበት
        // ለማጣቀሻ መስፈርቶች
        unsafe { &mut *self.cast().as_ptr() }
    }
}

impl<T: ?Sized> NonNull<T> {
    /// አዲስ `NonNull` ይፈጥራል።
    ///
    /// # Safety
    ///
    /// `ptr` ከንቱ መሆን አለበት
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_new_unchecked", since = "1.32.0")]
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // ደህንነት-ደዋዩ `ptr` ዋጋ እንደሌለው ዋስትና መስጠት አለበት ፡፡
        unsafe { NonNull { pointer: ptr as _ } }
    }

    /// `ptr` ዋጋ ቢስ ከሆነ አዲስ `NonNull` ን ይፈጥራል።
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // ደህንነት: ጠቋሚው ቀድሞውኑ ተረጋግጧል እና ምንም አይደለም
            Some(unsafe { Self::new_unchecked(ptr) })
        } else {
            None
        }
    }

    /// ከጥሬ የ `*const` ጠቋሚ በተቃራኒው የ `NonNull` ጠቋሚ ከተመለሰ በስተቀር እንደ [`std::ptr::from_raw_parts`] ተመሳሳይ ተግባር ያከናውናል።
    ///
    ///
    /// ለተጨማሪ ዝርዝሮች የ [`std::ptr::from_raw_parts`] ሰነድን ይመልከቱ ፡፡
    ///
    /// [`std::ptr::from_raw_parts`]: crate::ptr::from_raw_parts
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn from_raw_parts(
        data_address: NonNull<()>,
        metadata: <T as super::Pointee>::Metadata,
    ) -> NonNull<T> {
        // ደህንነት: X0 `data_address` ውጤት ስለሆነ የ `ptr::from::raw_parts_mut` ውጤት ዋጋ የለውም።
        unsafe {
            NonNull::new_unchecked(super::from_raw_parts_mut(data_address.as_ptr(), metadata))
        }
    }

    /// የአድራሻ እና ሜታዳታ አካላት (ሰፋ ያለ ሊሆን ይችላል) ጠቋሚ ወደ መበስበስ ፡፡
    ///
    /// ጠቋሚው በኋላ በ‹[`NonNull::from_raw_parts`] X›እንደገና ሊገነባ ይችላል ፡፡
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (NonNull<()>, <T as super::Pointee>::Metadata) {
        (self.cast(), super::metadata(self.as_ptr()))
    }

    /// መሠረታዊውን የ `*mut` ጠቋሚ ያገኛል።
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// ወደ እሴቱ የተጋራ ማጣቀሻ ይመልሳል።እሴቱ የማይታወቅ ከሆነ በምትኩ [`as_uninit_ref`] ጥቅም ላይ መዋል አለበት።
    ///
    /// ለሚለዋወጥ አቻ [`as_mut`] ን ይመልከቱ ፡፡
    ///
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    /// [`as_mut`]: NonNull::as_mut
    ///
    /// # Safety
    ///
    /// ይህንን ዘዴ ሲደውሉ የሚከተሉት ሁሉ እውነት መሆናቸውን ማረጋገጥ አለብዎት-
    ///
    /// * ጠቋሚው በትክክል መስተካከል አለበት።
    ///
    /// * በ [the module documentation] በተገለጸው ስሜት ውስጥ "dereferencable" መሆን አለበት።
    ///
    /// * ጠቋሚው ለተነሳው የ `T` ምሳሌ መጠቆም አለበት።
    ///
    /// * የተመለሰው የሕይወት ዘመን `'a` በዘፈቀደ የተመረጠ ስለሆነ እና የውሂቡን ትክክለኛ የሕይወት ዘመን የሚያንፀባርቅ ባለመሆኑ የ Rust ተለዋጭ ስም ደንቦችን ማስከበር አለብዎት።
    ///
    ///   በተለይም እስከዚህ የሕይወት ዘመን ድረስ ጠቋሚው የሚያመለክተው ማህደረ ትውስታ መለወጥ የለበትም (ከ `UnsafeCell` ውስጥ በስተቀር) ፡፡
    ///
    /// የዚህ ዘዴ ውጤት ጥቅም ላይ ያልዋለ ቢሆንም ይህ ተግባራዊ ይሆናል!
    /// (አልተነሳም መሆን በተመለከተ ያለው ክፍል ገና ሙሉ በሙሉ ወስነዋል አይደለም, ነገር ግን ድረስ, ብቸኛው አስተማማኝ አቀራረብ እነርሱ በእርግጥ አልተነሳም መሆናቸውን ለማረጋገጥ ነው.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // ደህንነት-ደዋዩ `self` ሁሉንም እንደሚያሟላ ዋስትና መስጠት አለበት
        // ለማጣቀሻ መስፈርቶች
        unsafe { &*self.as_ptr() }
    }

    /// ወደ እሴቱ ልዩ ማጣቀሻ ይመልሳል።እሴቱ የማይታወቅ ከሆነ በምትኩ [`as_uninit_mut`] ጥቅም ላይ መዋል አለበት።
    ///
    /// ለተጋራው አቻ [`as_ref`] ን ይመልከቱ ፡፡
    ///
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    /// [`as_ref`]: NonNull::as_ref
    ///
    /// # Safety
    ///
    /// ይህንን ዘዴ ሲደውሉ የሚከተሉት ሁሉ እውነት መሆናቸውን ማረጋገጥ አለብዎት-
    ///
    /// * ጠቋሚው በትክክል መስተካከል አለበት።
    ///
    /// * በ [the module documentation] በተገለጸው ስሜት ውስጥ "dereferencable" መሆን አለበት።
    ///
    /// * ጠቋሚው ለተነሳው የ `T` ምሳሌ መጠቆም አለበት።
    ///
    /// * የተመለሰው የሕይወት ዘመን `'a` በዘፈቀደ የተመረጠ ስለሆነ እና የውሂቡን ትክክለኛ የሕይወት ዘመን የሚያንፀባርቅ ባለመሆኑ የ Rust ተለዋጭ ስም ደንቦችን ማስከበር አለብዎት።
    ///
    ///   በተለይም በዚህ የሕይወት ዘመን ሁሉ ጠቋሚው የሚያመለክተው ማህደረ ትውስታ በሌላ ጠቋሚ በኩል ማግኘት (ማንበብ ወይም መጻፍ) የለበትም ፡፡
    ///
    /// የዚህ ዘዴ ውጤት ጥቅም ላይ ያልዋለ ቢሆንም ይህ ተግባራዊ ይሆናል!
    /// (አልተነሳም መሆን በተመለከተ ያለው ክፍል ገና ሙሉ በሙሉ ወስነዋል አይደለም, ነገር ግን ድረስ, ብቸኛው አስተማማኝ አቀራረብ እነርሱ በእርግጥ አልተነሳም መሆናቸውን ለማረጋገጥ ነው.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // ደህንነት-ደዋዩ `self` ሁሉንም እንደሚያሟላ ዋስትና መስጠት አለበት
        // ለለውጥ ማጣቀሻ የሚያስፈልጉ መስፈርቶች።
        unsafe { &mut *self.as_ptr() }
    }

    /// ለሌላ ዓይነት ጠቋሚ ይጣጣል ፡፡
    #[stable(feature = "nonnull_cast", since = "1.27.0")]
    #[rustc_const_stable(feature = "const_nonnull_cast", since = "1.32.0")]
    #[inline]
    pub const fn cast<U>(self) -> NonNull<U> {
        // ደህንነት: `self` የ `NonNull` ጠቋሚ ነው ፣ እሱም የግድ ዋጋ የለውም
        unsafe { NonNull::new_unchecked(self.as_ptr() as *mut U) }
    }
}

impl<T> NonNull<[T]> {
    /// ከቀጭን ጠቋሚ እና ርዝመት የማይረባ ጥሬ ቁርጥራጭ ይፈጥራል።
    ///
    /// የ‹XXXX›ክርክር የ **አባሎች ብዛት ነው**፣ ባይቶች ቁጥር አይደለም።
    ///
    /// ይህ ተግባር ደህንነቱ የተጠበቀ ነው ፣ ነገር ግን የመመለሻውን ዋጋ ማዛወር ደህንነቱ የተጠበቀ አይደለም።
    /// ለተቆራረጠ የደኅንነት መስፈርቶች የ [`slice::from_raw_parts`] ሰነድን ይመልከቱ ፡፡
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(nonnull_slice_from_raw_parts)]
    ///
    /// use std::ptr::NonNull;
    ///
    /// // ወደ መጀመሪያው አካል ከጠቋሚ ሲጀምሩ የተቆራረጠ ጠቋሚ ይፍጠሩ
    /// let mut x = [5, 6, 7];
    /// let nonnull_pointer = NonNull::new(x.as_mut_ptr()).unwrap();
    /// let slice = NonNull::slice_from_raw_parts(nonnull_pointer, 3);
    /// assert_eq!(unsafe { slice.as_ref()[2] }, 7);
    /// ```
    ///
    /// (ይህ ምሳሌ ሰው ሰራሽ በሆነ መንገድ የዚህ ዘዴ አጠቃቀምን እንደሚያሳይ ልብ ይበሉ ፣ ግን `ቁረጥ= NonNull::from(&x[..]);` would be a better way to write code like this.)) ይሁን
    ///
    #[unstable(feature = "nonnull_slice_from_raw_parts", issue = "71941")]
    #[rustc_const_unstable(feature = "const_nonnull_slice_from_raw_parts", issue = "71941")]
    #[inline]
    pub const fn slice_from_raw_parts(data: NonNull<T>, len: usize) -> Self {
        // ደህንነት: `data` የ `NonNull` ጠቋሚ ነው ፣ እሱም የግድ ዋጋ የለውም
        unsafe { Self::new_unchecked(super::slice_from_raw_parts_mut(data.as_ptr(), len)) }
    }

    /// የማይረባ ጥሬ ቁርጥራጭ ርዝመት ይመልሳል።
    ///
    /// የተመለሰው እሴት የ **አባሎች ቁጥር ነው**፣ የባይቶች ብዛት አይደለም።
    ///
    /// ጠቋሚው ትክክለኛ አድራሻ ስለሌለው ባዶ ያልሆነ ጥሬ ቁርጥራጭ ወደ ቁራጭ ሊሰጥ በማይችልበት ጊዜም እንኳ ይህ ተግባር ደህንነቱ የተጠበቀ ነው ፡፡
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    #[inline]
    pub const fn len(self) -> usize {
        self.as_ptr().len()
    }

    /// የቁርጭምጭሚቱን ቋት (ባዶ) ጠቋሚ ይመልሳል።
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_non_null_ptr(), NonNull::new(1 as *mut i8).unwrap());
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_non_null_ptr(self) -> NonNull<T> {
        // ደህንነት: `self` ዋጋ ቢስ እንደሆነ እናውቃለን።
        unsafe { NonNull::new_unchecked(self.as_ptr().as_mut_ptr()) }
    }

    /// ለተቆራረጠው ቋት ጥሬ አመላካች ይመልሳል።
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_mut_ptr(), 1 as *mut i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_mut_ptr(self) -> *mut T {
        self.as_non_null_ptr().as_ptr()
    }

    /// ምናልባት ባልታወቁ እሴቶች ቁርጥራጭ ላይ የተጋራ ማጣቀሻ ይመልሳል።ከ [`as_ref`] በተቃራኒው ይህ እሴቱ እንዲጀመር አይፈልግም።
    ///
    /// ለሚለዋወጥ አቻ [`as_uninit_slice_mut`] ን ይመልከቱ ፡፡
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_slice_mut`]: NonNull::as_uninit_slice_mut
    ///
    /// # Safety
    ///
    /// ይህንን ዘዴ ሲደውሉ የሚከተሉት ሁሉ እውነት መሆናቸውን ማረጋገጥ አለብዎት-
    ///
    /// * ጠቋሚ ለ `ptr.len() * mem::size_of::<T>()` ብዙ ባይቶች ለማንበብ [valid] መሆን አለበት እና በትክክል መመሳሰል አለበት።ይህ ማለት በተለይ
    ///
    ///     * የዚህ ቁራጭ አጠቃላይ የማስታወሻ ክልል በአንድ በተመደበ ነገር ውስጥ መያዝ አለበት!
    ///       ቁርጥራጮች በብዙ በተመደቡ ነገሮች ላይ በጭራሽ መዘርጋት አይችሉም።
    ///
    ///     * ጠቋሚው ለዜሮ-ርዝመት ቁርጥራጮች እንኳን መስተካከል አለበት።
    ///     ለዚህ አንደኛው ምክንያት የ‹Enum›አቀማመጥ ማመቻቸት በማጣቀሻዎች ላይ ሊመረኮዝ ስለሚችል ነው (ማንኛውንም ርዝመት ያላቸውን ቁርጥራጮችን ጨምሮ) ከሌሎች መረጃዎች ለመለየት በሚመሳሰሉ እና ዋጋ ቢስ ይሆናሉ ፡፡
    ///
    ///     [`NonNull::dangling()`] ን በመጠቀም ለዜሮ-ርዝመት ቁርጥራጮች እንደ `data` የሚያገለግል ጠቋሚ ማግኘት ይችላሉ ፡፡
    ///
    /// * የተቆራረጠ አጠቃላይ መጠን `ptr.len() * mem::size_of::<T>()` ከ `isize::MAX` ያልበለጠ መሆን አለበት።
    ///   የ [`pointer::offset`] የደህንነት ሰነድን ይመልከቱ ፡፡
    ///
    /// * የተመለሰው የሕይወት ዘመን `'a` በዘፈቀደ የተመረጠ ስለሆነ እና የውሂቡን ትክክለኛ የሕይወት ዘመን የሚያንፀባርቅ ባለመሆኑ የ Rust ተለዋጭ ስም ደንቦችን ማስከበር አለብዎት።
    ///   በተለይም እስከዚህ የሕይወት ዘመን ድረስ ጠቋሚው የሚያመለክተው ማህደረ ትውስታ መለወጥ የለበትም (ከ `UnsafeCell` ውስጥ በስተቀር) ፡፡
    ///
    /// የዚህ ዘዴ ውጤት ጥቅም ላይ ያልዋለ ቢሆንም ይህ ተግባራዊ ይሆናል!
    ///
    /// በተጨማሪም [`slice::from_raw_parts`] ን ይመልከቱ።
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice(&self) -> &[MaybeUninit<T>] {
        // ደህንነት-ደዋዩ ለ `as_uninit_slice` የደህንነትን ውል ማክበር አለበት ፡፡
        unsafe { slice::from_raw_parts(self.cast().as_ptr(), self.len()) }
    }

    /// ምናልባት ባልታወቁ እሴቶች ቁርጥራጭ ልዩ ማጣቀሻ ይመልሳል።ከ [`as_mut`] በተቃራኒው ይህ እሴቱ እንዲጀመር አይፈልግም።
    ///
    /// ለተጋራው አቻ [`as_uninit_slice`] ን ይመልከቱ ፡፡
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_slice`]: NonNull::as_uninit_slice
    ///
    /// # Safety
    ///
    /// ይህንን ዘዴ ሲደውሉ የሚከተሉት ሁሉ እውነት መሆናቸውን ማረጋገጥ አለብዎት-
    ///
    /// * ጠቋሚው ለ `ptr.len() * mem::size_of::<T>()` ብዙ ባይቶች ለማንበብ እና ለመፃፍ [valid] መሆን አለበት ፣ እና በትክክል መጣጣም አለበት።ይህ ማለት በተለይ
    ///
    ///     * የዚህ ቁራጭ አጠቃላይ የማስታወሻ ክልል በአንድ በተመደበ ነገር ውስጥ መያዝ አለበት!
    ///       ቁርጥራጮች በብዙ በተመደቡ ነገሮች ላይ በጭራሽ መዘርጋት አይችሉም።
    ///
    ///     * ጠቋሚው ለዜሮ-ርዝመት ቁርጥራጮች እንኳን መስተካከል አለበት።
    ///     ለዚህ አንደኛው ምክንያት የ‹Enum›አቀማመጥ ማመቻቸት በማጣቀሻዎች ላይ ሊመረኮዝ ስለሚችል ነው (ማንኛውንም ርዝመት ያላቸውን ቁርጥራጮችን ጨምሮ) ከሌሎች መረጃዎች ለመለየት በሚመሳሰሉ እና ዋጋ ቢስ ይሆናሉ ፡፡
    ///
    ///     [`NonNull::dangling()`] ን በመጠቀም ለዜሮ-ርዝመት ቁርጥራጮች እንደ `data` የሚያገለግል ጠቋሚ ማግኘት ይችላሉ ፡፡
    ///
    /// * የተቆራረጠ አጠቃላይ መጠን `ptr.len() * mem::size_of::<T>()` ከ `isize::MAX` ያልበለጠ መሆን አለበት።
    ///   የ [`pointer::offset`] የደህንነት ሰነድን ይመልከቱ ፡፡
    ///
    /// * የተመለሰው የሕይወት ዘመን `'a` በዘፈቀደ የተመረጠ ስለሆነ እና የውሂቡን ትክክለኛ የሕይወት ዘመን የሚያንፀባርቅ ባለመሆኑ የ Rust ተለዋጭ ስም ደንቦችን ማስከበር አለብዎት።
    ///   በተለይም በዚህ የሕይወት ዘመን ሁሉ ጠቋሚው የሚያመለክተው ማህደረ ትውስታ በሌላ ጠቋሚ በኩል ማግኘት (ማንበብ ወይም መጻፍ) የለበትም ፡፡
    ///
    /// የዚህ ዘዴ ውጤት ጥቅም ላይ ያልዋለ ቢሆንም ይህ ተግባራዊ ይሆናል!
    ///
    /// በተጨማሪም [`slice::from_raw_parts_mut`] ን ይመልከቱ።
    ///
    /// [valid]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(allocator_api, ptr_as_uninit)]
    ///
    /// use std::alloc::{Allocator, Layout, Global};
    /// use std::mem::MaybeUninit;
    /// use std::ptr::NonNull;
    ///
    /// let memory: NonNull<[u8]> = Global.allocate(Layout::new::<[u8; 32]>())?;
    /// // `memory` ለንባብ የሚሰራ እና ለ `memory.len()` ብዙ ባይት ስለሚጽፍ ይህ ደህንነቱ የተጠበቀ ነው።
    /// // ይዘቱ የማይታወቅ ሊሆን ስለሚችል `memory.as_mut()` ን መጥራት እዚህ እንደማይፈቀድ ልብ ይበሉ።
    /// # #[allow(unused_variables)]
    /// let slice: &mut [MaybeUninit<u8>] = unsafe { memory.as_uninit_slice_mut() };
    /// # Ok::<_, std::alloc::AllocError>(())
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice_mut(&self) -> &mut [MaybeUninit<T>] {
        // ደህንነት-ደዋዩ ለ `as_uninit_slice_mut` የደህንነትን ውል ማክበር አለበት ፡፡
        unsafe { slice::from_raw_parts_mut(self.cast().as_ptr(), self.len()) }
    }

    /// የድንበር ምርመራ ሳያደርግ ጥሬ ጠቋሚውን ወደ አንድ ንጥረ ነገር ወይም ንዑስ ክፍል ይመልሳል።
    ///
    /// ይህንን ዘዴ ከክልሎች ውጭ በሆነ መረጃ ጠቋሚ ወይም `self` በማይሰረዝበት ጊዜ መደወል *[ያልተገለጸ ባህሪ] ነው* ምንም እንኳን በውጤቱ ጠቋሚው ባይጠቅምም።
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let x = &mut [1, 2, 4];
    /// let x = NonNull::slice_from_raw_parts(NonNull::new(x.as_mut_ptr()).unwrap(), x.len());
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked_mut(1).as_ptr(), x.as_non_null_ptr().as_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(self, index: I) -> NonNull<I::Output>
    where
        I: SliceIndex<[T]>,
    {
        // ደህንነት-ደዋዩ `self` የማይነበብ እና የ `index` ውስን መሆንን ያረጋግጣል ፡፡
        // በዚህ ምክንያት ፣ የተገኘው ጠቋሚ NULL ሊሆን አይችልም።
        unsafe { NonNull::new_unchecked(self.as_ptr().get_unchecked_mut(index)) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Clone for NonNull<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Copy for NonNull<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Debug for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Pointer for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Eq for NonNull<T> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialEq for NonNull<T> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        self.as_ptr() == other.as_ptr()
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Ord for NonNull<T> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        self.as_ptr().cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialOrd for NonNull<T> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.as_ptr().partial_cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> hash::Hash for NonNull<T> {
    #[inline]
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.as_ptr().hash(state)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<Unique<T>> for NonNull<T> {
    #[inline]
    fn from(unique: Unique<T>) -> Self {
        // ደህንነት-ልዩ ጠቋሚ ዋጋ ቢስ ሊሆን አይችልም ፣ ስለሆነም ለ
        // new_unchecked() የሚከበሩ ናቸው ፡፡
        unsafe { NonNull::new_unchecked(unique.as_ptr()) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&mut T> for NonNull<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // ደህንነት-የሚለዋወጥ ማጣቀሻ ዋጋ ቢስ ሊሆን አይችልም ፡፡
        unsafe { NonNull { pointer: reference as *mut T } }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&T> for NonNull<T> {
    #[inline]
    fn from(reference: &T) -> Self {
        // ደህንነት: አንድ ማጣቀሻ ዋጋ ቢስ ሊሆን አይችልም ፣ ስለሆነም ለ
        // new_unchecked() የሚከበሩ ናቸው ፡፡
        unsafe { NonNull { pointer: reference as *const T } }
    }
}