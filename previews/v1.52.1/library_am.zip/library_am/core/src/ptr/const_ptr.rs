use super::*;
use crate::cmp::Ordering::{self, Equal, Greater, Less};
use crate::intrinsics;
use crate::mem;
use crate::slice::{self, SliceIndex};

#[lang = "const_ptr"]
impl<T: ?Sized> *const T {
    /// ጠቋሚው ዋጋ ቢስ ከሆነ `true` ን ይመልሳል።
    ///
    /// ያልተመዘገቡ ዓይነቶች ጥሬው የመረጃ ጠቋሚ ብቻ ነው የሚመረጠው ፣ ርዝመታቸው ፣ ክብራቸው ፣ ወ.ዘ.ተ ስላልሆኑ ብዙ ሊሆኑ የሚችሉ የኑሮ ጠቋሚዎች እንዳሉ ልብ ይበሉ ፡፡
    /// ስለዚህ ፣ ዋጋ ቢስ የሆኑ ሁለት ጠቋሚዎች አሁንም ድረስ አንዳቸው ከሌላው ጋር ሊወዳደሩ አይችሉም ፡፡
    ///
    /// ## በሆድ ምዘና ወቅት ባህሪ
    ///
    /// ይህ ተግባር በከባድ ግምገማ ወቅት ጥቅም ላይ ሲውል በጨረፍታ ጊዜ ዋጋ ቢስ ለሆኑት አመልካቾች `false` ን ሊመልስ ይችላል ፡፡
    /// በተለይም ፣ ለተወሰኑ ማህደረ ትውስታ ጠቋሚ ውጤቱ ጠቋሚው ዋጋ ቢስ በሆነ መጠን ከራሱ ገደብ ጋር ሲካካ ፣ ተግባሩ አሁንም `false` ን ይመልሳል።
    ///
    /// CTFE የዚያን ትውስታን ፍጹም አቋም ለማወቅ የሚያስችል ምንም መንገድ የለም ፣ ስለሆነም ጠቋሚው ዋጋ ቢስ መሆን አለመሆኑን ማወቅ አንችልም።
    ///
    /// # Examples
    ///
    /// መሠረታዊ አጠቃቀም
    ///
    /// ```
    /// let s: &str = "Follow the rabbit";
    /// let ptr: *const u8 = s.as_ptr();
    /// assert!(!ptr.is_null());
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_ptr_is_null", issue = "74939")]
    #[inline]
    pub const fn is_null(self) -> bool {
        // በ cast በኩል ከቀጭን ጠቋሚ ጋር ያነፃፅሩ ፣ ስለሆነም የስብ ጠቋሚዎች የ‹"data"›ክፍላቸውን ለኑል-ነስ ብቻ እያሰሉ ነው ፡፡
        //
        (self as *const u8).guaranteed_eq(null())
    }

    /// ለሌላ ዓይነት ጠቋሚ ይጣጣል ፡፡
    #[stable(feature = "ptr_cast", since = "1.38.0")]
    #[rustc_const_stable(feature = "const_ptr_cast", since = "1.38.0")]
    #[inline]
    pub const fn cast<U>(self) -> *const U {
        self as _
    }

    /// የአድራሻ እና ሜታዳታ አካላት (ሰፋ ያለ ሊሆን ይችላል) ጠቋሚ ወደ መበስበስ ፡፡
    ///
    /// ጠቋሚው በኋላ በ‹[`from_raw_parts`] X›እንደገና ሊገነባ ይችላል ፡፡
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (*const (), <T as super::Pointee>::Metadata) {
        (self.cast(), metadata(self))
    }

    /// ጠቋሚው ዋጋ ቢስ ከሆነ `None` ን ይመልሳል ፣ ወይም ደግሞ በ `Some` ውስጥ ለተጠቀሰው እሴት የተጋራ ማጣቀሻ ይመልሳል።እሴቱ የማይታወቅ ከሆነ በምትኩ [`as_uninit_ref`] ጥቅም ላይ መዋል አለበት።
    ///
    /// [`as_uninit_ref`]: #method.as_uninit_ref
    ///
    /// # Safety
    ///
    /// ይህንን ዘዴ በሚደውሉበት ጊዜ *ጠቋሚው NULL ነው* ወይም * የሚከተሉት ሁሉ እውነት መሆናቸውን ማረጋገጥ አለብዎት:
    ///
    /// * ጠቋሚው በትክክል መስተካከል አለበት።
    ///
    /// * በ [the module documentation] በተገለጸው ስሜት ውስጥ "dereferencable" መሆን አለበት።
    ///
    /// * ጠቋሚው ለተነሳው የ `T` ምሳሌ መጠቆም አለበት።
    ///
    /// * የተመለሰው የሕይወት ዘመን `'a` በዘፈቀደ የተመረጠ ስለሆነ እና የውሂቡን ትክክለኛ የሕይወት ዘመን የሚያንፀባርቅ ባለመሆኑ የ Rust ተለዋጭ ስም ደንቦችን ማስከበር አለብዎት።
    ///   በተለይም እስከዚህ የሕይወት ዘመን ድረስ ጠቋሚው የሚያመለክተው ማህደረ ትውስታ መለወጥ የለበትም (ከ `UnsafeCell` ውስጥ በስተቀር) ፡፡
    ///
    /// የዚህ ዘዴ ውጤት ጥቅም ላይ ያልዋለ ቢሆንም ይህ ተግባራዊ ይሆናል!
    /// (አልተነሳም መሆን በተመለከተ ያለው ክፍል ገና ሙሉ በሙሉ ወስነዋል አይደለም, ነገር ግን ድረስ, ብቸኛው አስተማማኝ አቀራረብ እነርሱ በእርግጥ አልተነሳም መሆናቸውን ለማረጋገጥ ነው.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// መሠረታዊ አጠቃቀም
    ///
    /// ```
    /// let ptr: *const u8 = &10u8 as *const u8;
    ///
    /// unsafe {
    ///     if let Some(val_back) = ptr.as_ref() {
    ///         println!("We got back the value: {}!", val_back);
    ///     }
    /// }
    /// ```
    ///
    /// # የኑሮ ምልክት ያልተደረገበት ስሪት
    ///
    /// እርስዎ ከሆኑ ያረጋግጡ የጠቋሚ ባዶ ሊሆን ፈጽሞ አይችልም እና በቀጥታ ጠቋሚ dereference እንደሚችሉ እናውቃለን, ፋንታ `Option<&T>` ያለውን `&T` ይመልሳል መሆኑን `as_ref_unchecked` አንዳንድ ዓይነት እየፈለጉ ነው.
    ///
    ///
    /// ```
    /// let ptr: *const u8 = &10u8 as *const u8;
    ///
    /// unsafe {
    ///     let val_back = &*ptr;
    ///     println!("We got back the value: {}!", val_back);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_as_ref", since = "1.9.0")]
    #[inline]
    pub unsafe fn as_ref<'a>(self) -> Option<&'a T> {
        // ደህንነት-ደዋዩ `self` ትክክለኛ መሆኑን ማረጋገጥ አለበት
        // ከንቱ ካልሆነ ለማጣቀሻ።
        if self.is_null() { None } else { unsafe { Some(&*self) } }
    }

    /// ጠቋሚው ዋጋ ቢስ ከሆነ `None` ን ይመልሳል ፣ ወይም ደግሞ በ `Some` ውስጥ ለተጠቀሰው እሴት የተጋራ ማጣቀሻ ይመልሳል።
    /// ከ [`as_ref`] በተቃራኒው ይህ እሴቱ እንዲጀመር አይፈልግም።
    ///
    /// [`as_ref`]: #method.as_ref
    ///
    /// # Safety
    ///
    /// ይህንን ዘዴ በሚደውሉበት ጊዜ *ጠቋሚው NULL ነው* ወይም * የሚከተሉት ሁሉ እውነት መሆናቸውን ማረጋገጥ አለብዎት:
    ///
    /// * ጠቋሚው በትክክል መስተካከል አለበት።
    ///
    /// * በ [the module documentation] በተገለጸው ስሜት ውስጥ "dereferencable" መሆን አለበት።
    ///
    /// * የተመለሰው የሕይወት ዘመን `'a` በዘፈቀደ የተመረጠ ስለሆነ እና የውሂቡን ትክክለኛ የሕይወት ዘመን የሚያንፀባርቅ ባለመሆኑ የ Rust ተለዋጭ ስም ደንቦችን ማስከበር አለብዎት።
    ///
    ///   በተለይም እስከዚህ የሕይወት ዘመን ድረስ ጠቋሚው የሚያመለክተው ማህደረ ትውስታ መለወጥ የለበትም (ከ `UnsafeCell` ውስጥ በስተቀር) ፡፡
    ///
    /// የዚህ ዘዴ ውጤት ጥቅም ላይ ያልዋለ ቢሆንም ይህ ተግባራዊ ይሆናል!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// መሠረታዊ አጠቃቀም
    ///
    /// ```
    /// #![feature(ptr_as_uninit)]
    ///
    /// let ptr: *const u8 = &10u8 as *const u8;
    ///
    /// unsafe {
    ///     if let Some(val_back) = ptr.as_uninit_ref() {
    ///         println!("We got back the value: {}!", val_back.assume_init());
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref<'a>(self) -> Option<&'a MaybeUninit<T>>
    where
        T: Sized,
    {
        // ደህንነት-ደዋዩ `self` ሁሉንም እንደሚያሟላ ዋስትና መስጠት አለበት
        // ለማጣቀሻ መስፈርቶች
        if self.is_null() { None } else { Some(unsafe { &*(self as *const MaybeUninit<T>) }) }
    }

    /// ያሰላል አንድ ጠቋሚ ከ ማካካሻ.
    ///
    /// `count` በ T ክፍሎች ውስጥ ነው;ለምሳሌ ፣ የ 3 `count` የ `3 * size_of::<T>()` ባይት ጠቋሚ ማካካሻ ይወክላል።
    ///
    /// # Safety
    ///
    /// ከሚከተሉት ሁኔታዎች ውስጥ አንዳቸውም ቢጣሱ ውጤቱ ያልተገለጸ ባህሪ ነው
    ///
    /// * ሁለቱም የመነሻ እና የውጤት ጠቋሚው በተመሳሳይ በተመደበው ነገር መጨረሻ ላይ ወሰን ወይም አንድ ባይት መሆን አለባቸው ፡፡
    /// በ Rust ውስጥ እያንዳንዱ የ (stack-allocated) ተለዋዋጭ እንደ የተለየ የተመደበ ነገር ተደርጎ ይወሰዳል ፡፡
    ///
    /// * የሂሳብ ማካካሻ ፣**በባይቶች** ውስጥ ፣ `isize` ን ሊሞላ አይችልም።
    ///
    /// * ወሰን ውስጥ ያለው ማካካሻ በ "wrapping around" በአድራሻው ቦታ ላይ መተማመን አይችልም።ማለትም ፣ ማለቂያ የሌለው ትክክለኛነት ድምር ፣**በባይቶች** በአጠቃቀም ሁኔታ ሊገጣጠም ይገባል።
    ///
    /// አጠናቃሪው እና መደበኛ ቤተ-መጽሐፍት በአጠቃላይ ማካካሻ አሳሳቢ ወደሆነ ምደባዎች በጭራሽ እንደማይደርሱ ለማረጋገጥ ይሞክራል ፡፡
    /// ለምሳሌ ፣ `Vec` እና `Box` ከ `isize::MAX` ባይት በላይ እንደማይመደቡ ያረጋግጣሉ ፣ ስለሆነም `vec.as_ptr().add(vec.len())` ሁል ጊዜም ደህና ነው ፡፡
    ///
    /// አብዛኛዎቹ መድረኮች በመሠረቱ እንዲህ ዓይነቱን ምደባ እንኳን መገንባት አይችሉም ፡፡
    /// ለምሳሌ ፣ በገጽ-ሰንጠረዥ ውስንነቶች ወይም የአድራሻ ቦታውን በመክፈል ምክንያት ምንም የታወቀ 64-ቢት መድረክ በጭራሽ ለ 2 <sup>63</sup> ባይት ጥያቄ ማቅረብ አይችልም ፡
    /// ሆኖም ፣ አንዳንድ 32-ቢት እና 16-ቢት መድረኮች እንደ አካላዊ አድራሻ ማራዘሚያ ካሉ ነገሮች ጋር ከ `isize::MAX` ባይት በላይ ጥያቄን በተሳካ ሁኔታ ሊያቀርቡ ይችላሉ።
    ///
    /// ስለሆነም ፣ በቀጥታ ከአከፋፋዮች ወይም ከማህደረ ትውስታ ካርታ ካላቸው ፋይሎች * የተገኘው ማህደረ ትውስታ ይህንን ተግባር ለመቋቋም በጣም ትልቅ ሊሆን ይችላል።
    ///
    /// እነዚህ ገደቦች ለማርካት አስቸጋሪ ከሆኑ በምትኩ [`wrapping_offset`] ን ለመጠቀም ያስቡ ፡፡
    /// የዚህ ዘዴ ብቸኛው ጠቀሜታ የበለጠ ጠበኛ የሆኑ የማጠናከሪያ ማመቻቻዎችን ማነቃቃቱ ነው ፡፡
    ///
    /// [`wrapping_offset`]: #method.wrapping_offset
    ///
    /// # Examples
    ///
    /// መሠረታዊ አጠቃቀም
    ///
    /// ```
    /// let s: &str = "123";
    /// let ptr: *const u8 = s.as_ptr();
    ///
    /// unsafe {
    ///     println!("{}", *ptr.offset(1) as char);
    ///     println!("{}", *ptr.offset(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn offset(self, count: isize) -> *const T
    where
        T: Sized,
    {
        // ደህንነት-ደዋዩ ለ `offset` የደህንነትን ውል ማክበር አለበት ፡፡
        unsafe { intrinsics::offset(self, count) }
    }

    /// መጠቅለያ ሂሳብ በመጠቀም መጠኑን ከጠቋሚው ያሰላል።
    ///
    /// `count` በ T ክፍሎች ውስጥ ነው;ለምሳሌ ፣ የ 3 `count` የ `3 * size_of::<T>()` ባይት ጠቋሚ ማካካሻ ይወክላል።
    ///
    /// # Safety
    ///
    /// ይህ ክዋኔ ራሱ ሁል ጊዜም ደህንነቱ የተጠበቀ ነው ፣ ግን የተገኘውን ጠቋሚ መጠቀሙ ጥሩ አይደለም ፡፡
    ///
    /// የተገኘው ጠቋሚ `self` ከሚጠቆመው ተመሳሳይ የተመደበ ነገር ጋር ተያይዞ ይቀራል።
    /// የተለየ የተመደበ ነገርን ለመድረስ * ላይጠቀምበት ይችላል ፡፡በ Rust ውስጥ እያንዳንዱ የ (stack-allocated) ተለዋዋጭ እንደ የተለየ የተመደበ ነገር ተደርጎ ይወሰዳል ፡፡
    ///
    /// በሌላ አገላለጽ X0XX `1` መጠን አለው እና ምንም እንኳን ምንም ፍሰት ከሌለ የ X0XX `z` ን ከ `y` ጋር ተመሳሳይ ያደርገዋል *እና* ምንም አያደርግም ፡፡ `y` ነጥብ ወደ ተመደበው ተመሳሳይ ነገር ፡፡
    ///
    /// ከ‹XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX ጋር ሲነፃፀሩ በተመሳሳዩ በተመሣሣይ ነገር ውስጥ የመቆየትን አስፈላጊነት ያዘገየዋል ፡፡`wrapping_offset` ጠቋሚ ያመርታል ነገር ግን ጠቋሚው ከተያያዘው ነገር ድንበር ውጭ ሲሆን የተመዘገበ ከሆነ አሁንም ወደማይገለፅ ባህሪ ይመራል ፡፡
    /// [`offset`] በተሻለ ሁኔታ ሊመች ይችላል እና ስለሆነም በአፈፃፀም-ተኮር ኮድ ውስጥ ተመራጭ ነው።
    ///
    /// የዘገየው ቼክ የመጨረሻ ውጤቱን በማስላት ወቅት ጥቅም ላይ የዋሉ መካከለኛ እሴቶችን ሳይሆን የተመዘገበውን የጠቋሚውን እሴት ብቻ ይመለከታል።
    /// ለምሳሌ ፣ `x.wrapping_offset(o).wrapping_offset(o.wrapping_neg())` ሁልጊዜ ከ `x` ጋር አንድ ነው።በሌላ አገላለጽ የተመደበውን ነገር መተው እና ከዚያ በኋላ እንደገና ማስገባት ይፈቀዳል ፡፡
    ///
    /// የነገሮችን ድንበር ማቋረጥ ከፈለጉ ጠቋሚውን ወደ ቁጥር (ኢንቲጀር) ይጣሉት እና የሂሳብ ስራውን እዚያ ያካሂዱ ፡፡
    ///
    /// [`offset`]: #method.offset
    ///
    /// # Examples
    ///
    /// መሠረታዊ አጠቃቀም
    ///
    /// ```
    /// // በሁለት ንጥረ ነገሮች ጭማሪ ውስጥ ጥሬ ጠቋሚውን በመጠቀም ይቅጠሩ
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let step = 2;
    /// let end_rounded_up = ptr.wrapping_offset(6);
    ///
    /// // ይህ ሉፕ "1, 3, 5, " ን ያትማል
    /// while ptr != end_rounded_up {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_offset(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_wrapping_offset", since = "1.16.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_offset(self, count: isize) -> *const T
    where
        T: Sized,
    {
        // ደህንነት:-`arith_offset` ውስጣዊ ለመደወል የሚያስፈልጉ ቅድመ ሁኔታዎች የሉትም።
        unsafe { intrinsics::arith_offset(self, count) }
    }

    /// በሁለት ጠቋሚዎች መካከል ያለውን ርቀት ያሰላል።የተመለሰው እሴት በ T አሃዶች ውስጥ ነው ባይት ውስጥ ያለው ርቀት በ `mem::size_of::<T>()` ተከፍሏል።
    ///
    /// ይህ ተግባር የ [`offset`] ተቃራኒ ነው።
    ///
    /// [`offset`]: #method.offset
    ///
    /// # Safety
    ///
    /// ከሚከተሉት ሁኔታዎች ውስጥ አንዳቸውም ቢጣሱ ውጤቱ ያልተገለጸ ባህሪ ነው
    ///
    /// * መነሻውም ሆነ ሌላ ጠቋሚው በተመሳሳይ በተመደበው ነገር መጨረሻ ላይ ወሰን ወይም አንድ ባይት መሆን አለበት ፡፡
    /// በ Rust ውስጥ እያንዳንዱ የ (stack-allocated) ተለዋዋጭ እንደ የተለየ የተመደበ ነገር ተደርጎ ይወሰዳል ፡፡
    ///
    /// * ሁለቱም ጠቋሚዎች * ከጠቋሚ ወደ አንድ ተመሳሳይ ነገር የሚመጡ መሆን አለባቸው ፡፡
    ///   (ለአብነት ከዚህ በታች ይመልከቱ)
    ///
    /// * በጠቋሚዎች መካከል ያለው ርቀት ፣ በባይቶች ፣ የ `T` መጠን ትክክለኛ ብዛት ያለው መሆን አለበት።
    ///
    /// * በጠቋሚዎች መካከል ያለው ርቀት ፣**በባይቶች**፣ `isize` ን ሊያጥለቅ አይችልም።
    ///
    /// * ወሰን ውስጥ ያለው ርቀት በ "wrapping around" በአድራሻው ቦታ ላይ መተማመን አይችልም።
    ///
    /// የ Rust አይነቶች በጭራሽ ከ `isize::MAX` አይበልጡም እናም የ Rust ምደባዎች በአድራሻው ቦታ ዙሪያ በጭራሽ አይታጠቁም ፣ ስለሆነም በማንኛውም የ Rust ዓይነት `T` ዋጋ ውስጥ ያሉ ሁለት ጠቋሚዎች ሁል ጊዜ የመጨረሻዎቹን ሁለት ሁኔታዎች ያረካሉ ፡፡
    ///
    /// ደረጃውን የጠበቀ ቤተ-መጽሐፍት በአጠቃላይ ማመጣጠን አንድ አሳሳቢ በሆነበት መጠን በጭራሽ እንደማይደርስ ያረጋግጣል ፡፡
    /// ለምሳሌ ፣ `Vec` እና `Box` ከ `isize::MAX` ባይቶች በላይ በጭራሽ እንደማይመደቡ ያረጋግጣሉ ፣ ስለሆነም `ptr_into_vec.offset_from(vec.as_ptr())` የመጨረሻዎቹን ሁለቱን ሁኔታዎች ያሟላል ፡፡
    ///
    /// አብዛኛዎቹ መድረኮች በመሠረቱ እንዲህ ዓይነቱን ትልቅ ምደባ እንኳን መገንባት አይችሉም ፡፡
    /// ለምሳሌ ፣ በገጽ-ሰንጠረዥ ውስንነቶች ወይም የአድራሻ ቦታውን በመክፈል ምክንያት ምንም የታወቀ 64-ቢት መድረክ በጭራሽ ለ 2 <sup>63</sup> ባይት ጥያቄ ማቅረብ አይችልም ፡
    /// ሆኖም ፣ አንዳንድ 32-ቢት እና 16-ቢት መድረኮች እንደ አካላዊ አድራሻ ማራዘሚያ ካሉ ነገሮች ጋር ከ `isize::MAX` ባይት በላይ ጥያቄን በተሳካ ሁኔታ ሊያቀርቡ ይችላሉ።
    /// ስለሆነም ፣ በቀጥታ ከአከፋፋዮች ወይም ከማህደረ ትውስታ ካርታ ካላቸው ፋይሎች * የተገኘው ማህደረ ትውስታ ይህንን ተግባር ለመቋቋም በጣም ትልቅ ሊሆን ይችላል።
    /// ([`offset`] እና [`add`] እንዲሁ ተመሳሳይ ውስንነት እንዳላቸው ልብ ይበሉ እና ስለሆነም በእንደዚህ ዓይነቶቹ ትላልቅ ምደባዎች ላይም ጥቅም ላይ መዋል አይችሉም ፡፡)
    ///
    /// [`add`]: #method.add
    ///
    /// # Panics
    ///
    /// `T` ዜሮ-መጠን ያለው ዓይነት ("ZST") ከሆነ ይህ ተግባር panics
    ///
    /// # Examples
    ///
    /// መሠረታዊ አጠቃቀም
    ///
    /// ```
    /// let a = [0; 5];
    /// let ptr1: *const i32 = &a[1];
    /// let ptr2: *const i32 = &a[3];
    /// unsafe {
    ///     assert_eq!(ptr2.offset_from(ptr1), 2);
    ///     assert_eq!(ptr1.offset_from(ptr2), -2);
    ///     assert_eq!(ptr1.offset(2), ptr2);
    ///     assert_eq!(ptr2.offset(-2), ptr1);
    /// }
    /// ```
    ///
    /// *ትክክል ያልሆነ* አጠቃቀም
    ///
    /// ```rust,no_run
    /// let ptr1 = Box::into_raw(Box::new(0u8)) as *const u8;
    /// let ptr2 = Box::into_raw(Box::new(1u8)) as *const u8;
    /// let diff = (ptr2 as isize).wrapping_sub(ptr1 as isize);
    /// // Ptr2_other የ ptr2 "alias" ያድርጉ ፣ ግን ከ ptr1 የመጣ።
    /// let ptr2_other = (ptr1 as *const u8).wrapping_offset(diff);
    /// assert_eq!(ptr2 as usize, ptr2_other as usize);
    /// // Ptr2_other እና ptr2 ከጠቋሚዎች ወደ ተለያዩ ነገሮች የተገኙ በመሆናቸው አንድ ዓይነት አድራሻ ቢጠቁሙም ማካካሻቸውን ማስላት ያልተገለጸ ባህሪ ነው!
    /////
    /////
    /// unsafe {
    ///     let zero = ptr2_other.offset_from(ptr2); // ያልተገለጸ ባህሪ
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_offset_from", since = "1.47.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    #[inline]
    pub const unsafe fn offset_from(self, origin: *const T) -> isize
    where
        T: Sized,
    {
        let pointee_size = mem::size_of::<T>();
        assert!(0 < pointee_size && pointee_size <= isize::MAX as usize);
        // ደህንነት-ደዋዩ ለ `ptr_offset_from` የደህንነትን ውል ማክበር አለበት ፡፡
        unsafe { intrinsics::ptr_offset_from(self, origin) }
    }

    /// ሁለት ጠቋሚዎች እኩል መሆናቸውን ያረጋግጣሉ ፡፡
    ///
    /// በስራ ሰዓት ይህ ተግባር እንደ `self == other` ነው ፡፡
    /// ሆኖም ፣ በአንዳንድ አውዶች (ለምሳሌ ፣ የጊዜ-ጊዜ ግምገማ) የሁለት ጠቋሚዎችን እኩልነት መወሰን ሁልጊዜ አይቻልም ፣ ስለሆነም ይህ ተግባር ከጊዜ በኋላ በትክክል እኩል ወደሆኑት ጠቋሚዎች `false` ን በድብቅ ይመልሳል።
    ///
    /// ግን `true` ን ሲመልስ ጠቋሚዎቹ እኩል መሆናቸውን ያረጋግጣሉ ፡፡
    ///
    /// ይህ ተግባር የ [`guaranteed_ne`] መስታወት ነው ፣ ግን ተቃራኒው አይደለም።ሁለቱም ተግባራት `false` ን የሚመልሱ የጠቋሚ ንፅፅሮች አሉ ፡፡
    ///
    /// [`guaranteed_ne`]: #method.guaranteed_ne
    ///
    /// የመመለሻ እሴቱ በአቀራባሪው ስሪት ላይ በመመርኮዝ ሊለወጥ ይችላል እና ደህንነቱ ያልተጠበቀ ኮድ በዚህ ተግባር ውጤት ላይ ለጤናማነት አይመካም ፡፡
    /// በዚህ ተግባር ላይ የተንሰራፋው የ `false` ተመላሽ እሴቶች ውጤቱን ብቻ ሳይሆን አፈፃፀሙን የማይነኩበት ለአፈፃፀም ማመቻቸት ይህንን ተግባር ብቻ እንዲጠቀሙ የተጠቆመ ነው ፡፡
    /// የአሠራር ጊዜ እና የማጠናቀር-ጊዜ ኮድ ልዩ ባህሪ እንዲኖራቸው ለማድረግ ይህንን ዘዴ መጠቀሙ የሚያስከትለው ውጤት አልተመረመረም ፡፡
    /// ይህ ዘዴ እንደነዚህ ያሉትን ልዩነቶች ለማስተዋወቅ ጥቅም ላይ መዋል የለበትም ፣ እንዲሁም ስለዚህ ጉዳይ የተሻለ ግንዛቤ ከመኖራችን በፊት መረጋጋት የለበትም ፡፡
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[inline]
    pub const fn guaranteed_eq(self, other: *const T) -> bool
    where
        T: Sized,
    {
        intrinsics::ptr_guaranteed_eq(self, other)
    }

    /// ሁለት ጠቋሚዎች እኩል አለመሆናቸውን ያረጋግጣሉ ፡፡
    ///
    /// በስራ ሰዓት ይህ ተግባር እንደ `self != other` ነው ፡፡
    /// ሆኖም ፣ በአንዳንድ አውዶች (ለምሳሌ ፣ የጊዜ-ጊዜ ግምገማ) ፣ የሁለት ጠቋሚዎችን እኩልነት ለመለየት ሁልጊዜ አይቻልም ፣ ስለሆነም ይህ ተግባር ከጊዜ በኋላ በትክክል እኩል ወደሆኑት ጠቋሚዎች `false` ን በቅልጥፍና ሊመልስ ይችላል ፡፡
    ///
    /// ግን `true` ን ሲመልስ ጠቋሚዎቹ እኩል አለመሆናቸውን ያረጋግጣሉ ፡፡
    ///
    /// ይህ ተግባር የ [`guaranteed_eq`] መስታወት ነው ፣ ግን ተቃራኒው አይደለም።ሁለቱም ተግባራት `false` ን የሚመልሱ የጠቋሚ ንፅፅሮች አሉ ፡፡
    ///
    /// [`guaranteed_eq`]: #method.guaranteed_eq
    ///
    /// የመመለሻ እሴቱ በአቀራባሪው ስሪት ላይ በመመርኮዝ ሊለወጥ ይችላል እና ደህንነቱ ያልተጠበቀ ኮድ በዚህ ተግባር ውጤት ላይ ለጤናማነት አይመካም ፡፡
    /// በዚህ ተግባር ላይ የተንሰራፋው የ `false` ተመላሽ እሴቶች ውጤቱን ብቻ ሳይሆን አፈፃፀሙን የማይነኩበት ለአፈፃፀም ማመቻቸት ይህንን ተግባር ብቻ እንዲጠቀሙ የተጠቆመ ነው ፡፡
    /// የአሠራር ጊዜ እና የማጠናቀር-ጊዜ ኮድ ልዩ ባህሪ እንዲኖራቸው ለማድረግ ይህንን ዘዴ መጠቀሙ የሚያስከትለው ውጤት አልተመረመረም ፡፡
    /// ይህ ዘዴ እንደነዚህ ያሉትን ልዩነቶች ለማስተዋወቅ ጥቅም ላይ መዋል የለበትም ፣ እንዲሁም ስለዚህ ጉዳይ የተሻለ ግንዛቤ ከመኖራችን በፊት መረጋጋት የለበትም ፡፡
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[inline]
    pub const fn guaranteed_ne(self, other: *const T) -> bool
    where
        T: Sized,
    {
        intrinsics::ptr_guaranteed_ne(self, other)
    }

    /// ማካካሻውን ከጠቋሚ (ለ `.offset(count as isize)`) ምቾት) ያሰላል።
    ///
    /// `count` በ T ክፍሎች ውስጥ ነው;ለምሳሌ ፣ የ 3 `count` የ `3 * size_of::<T>()` ባይት ጠቋሚ ማካካሻ ይወክላል።
    ///
    /// # Safety
    ///
    /// ከሚከተሉት ሁኔታዎች ውስጥ አንዳቸውም ቢጣሱ ውጤቱ ያልተገለጸ ባህሪ ነው
    ///
    /// * ሁለቱም የመነሻ እና የውጤት ጠቋሚው በተመሳሳይ በተመደበው ነገር መጨረሻ ላይ ወሰን ወይም አንድ ባይት መሆን አለባቸው ፡፡
    /// በ Rust ውስጥ እያንዳንዱ የ (stack-allocated) ተለዋዋጭ እንደ የተለየ የተመደበ ነገር ተደርጎ ይወሰዳል ፡፡
    ///
    /// * የሂሳብ ማካካሻ ፣**በባይቶች** ውስጥ ፣ `isize` ን ሊሞላ አይችልም።
    ///
    /// * ወሰን ውስጥ ያለው ማካካሻ በአድራሻ ቦታው "wrapping around" ላይ መተማመን አይችልም።ማለትም ፣ ማለቂያ የሌለው ትክክለኛነት ድምር በ `usize` ውስጥ መመጣጠን አለበት።
    ///
    /// አጠናቃሪው እና መደበኛ ቤተ-መጽሐፍት በአጠቃላይ ማካካሻ አሳሳቢ ወደሆነ ምደባዎች በጭራሽ እንደማይደርሱ ለማረጋገጥ ይሞክራል ፡፡
    /// ለምሳሌ ፣ `Vec` እና `Box` ከ `isize::MAX` ባይት በላይ እንደማይመደቡ ያረጋግጣሉ ፣ ስለሆነም `vec.as_ptr().add(vec.len())` ሁል ጊዜም ደህና ነው ፡፡
    ///
    /// አብዛኛዎቹ መድረኮች በመሠረቱ እንዲህ ዓይነቱን ምደባ እንኳን መገንባት አይችሉም ፡፡
    /// ለምሳሌ ፣ በገጽ-ሰንጠረዥ ውስንነቶች ወይም የአድራሻ ቦታውን በመክፈል ምክንያት ምንም የታወቀ 64-ቢት መድረክ በጭራሽ ለ 2 <sup>63</sup> ባይት ጥያቄ ማቅረብ አይችልም ፡
    /// ሆኖም ፣ አንዳንድ 32-ቢት እና 16-ቢት መድረኮች እንደ አካላዊ አድራሻ ማራዘሚያ ካሉ ነገሮች ጋር ከ `isize::MAX` ባይት በላይ ጥያቄን በተሳካ ሁኔታ ሊያቀርቡ ይችላሉ።
    ///
    /// ስለሆነም ፣ በቀጥታ ከአከፋፋዮች ወይም ከማህደረ ትውስታ ካርታ ካላቸው ፋይሎች * የተገኘው ማህደረ ትውስታ ይህንን ተግባር ለመቋቋም በጣም ትልቅ ሊሆን ይችላል።
    ///
    /// እነዚህ ገደቦች ለማርካት አስቸጋሪ ከሆኑ በምትኩ [`wrapping_add`] ን ለመጠቀም ያስቡ ፡፡
    /// የዚህ ዘዴ ብቸኛው ጠቀሜታ የበለጠ ጠበኛ የሆኑ የማጠናከሪያ ማመቻቻዎችን ማነቃቃቱ ነው ፡፡
    ///
    /// [`wrapping_add`]: #method.wrapping_add
    ///
    /// # Examples
    ///
    /// መሠረታዊ አጠቃቀም
    ///
    /// ```
    /// let s: &str = "123";
    /// let ptr: *const u8 = s.as_ptr();
    ///
    /// unsafe {
    ///     println!("{}", *ptr.add(1) as char);
    ///     println!("{}", *ptr.add(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn add(self, count: usize) -> Self
    where
        T: Sized,
    {
        // ደህንነት-ደዋዩ ለ `offset` የደህንነትን ውል ማክበር አለበት ፡፡
        unsafe { self.offset(count as isize) }
    }

    /// ማካካሻውን ከጠቋሚ (ለ‹ኦፍሴት›ይሰላል ((እንደ isize).wrapping_neg())`) ይቆጥሩ)) ያሰላል።
    ///
    /// `count` በ T ክፍሎች ውስጥ ነው;ለምሳሌ ፣ የ 3 `count` የ `3 * size_of::<T>()` ባይት ጠቋሚ ማካካሻ ይወክላል።
    ///
    /// # Safety
    ///
    /// ከሚከተሉት ሁኔታዎች ውስጥ አንዳቸውም ቢጣሱ ውጤቱ ያልተገለጸ ባህሪ ነው
    ///
    /// * ሁለቱም የመነሻ እና የውጤት ጠቋሚው በተመሳሳይ በተመደበው ነገር መጨረሻ ላይ ወሰን ወይም አንድ ባይት መሆን አለባቸው ፡፡
    /// በ Rust ውስጥ እያንዳንዱ የ (stack-allocated) ተለዋዋጭ እንደ የተለየ የተመደበ ነገር ተደርጎ ይወሰዳል ፡፡
    ///
    /// * የሂሳብ ማካካሻ ከ `isize::MAX`**ባይቶች** መብለጥ አይችልም።
    ///
    /// * ወሰን ውስጥ ያለው ማካካሻ በ "wrapping around" በአድራሻው ቦታ ላይ መተማመን አይችልም።ማለትም ፣ ማለቂያ የሌለው ትክክለኛነት ድምር በአጠቃቀም ሁኔታ ውስጥ መመጣጠን አለበት።
    ///
    /// አጠናቃሪው እና መደበኛ ቤተ-መጽሐፍት በአጠቃላይ ማካካሻ አሳሳቢ ወደሆነ ምደባዎች በጭራሽ እንደማይደርሱ ለማረጋገጥ ይሞክራል ፡፡
    /// ለምሳሌ ፣ `Vec` እና `Box` ከ `isize::MAX` ባይት በላይ እንደማይመደቡ ያረጋግጣሉ ፣ ስለሆነም `vec.as_ptr().add(vec.len()).sub(vec.len())` ሁል ጊዜም ደህና ነው ፡፡
    ///
    /// አብዛኛዎቹ መድረኮች በመሠረቱ እንዲህ ዓይነቱን ምደባ እንኳን መገንባት አይችሉም ፡፡
    /// ለምሳሌ ፣ በገጽ-ሰንጠረዥ ውስንነቶች ወይም የአድራሻ ቦታውን በመክፈል ምክንያት ምንም የታወቀ 64-ቢት መድረክ በጭራሽ ለ 2 <sup>63</sup> ባይት ጥያቄ ማቅረብ አይችልም ፡
    /// ሆኖም ፣ አንዳንድ 32-ቢት እና 16-ቢት መድረኮች እንደ አካላዊ አድራሻ ማራዘሚያ ካሉ ነገሮች ጋር ከ `isize::MAX` ባይት በላይ ጥያቄን በተሳካ ሁኔታ ሊያቀርቡ ይችላሉ።
    ///
    /// ስለሆነም ፣ በቀጥታ ከአከፋፋዮች ወይም ከማህደረ ትውስታ ካርታ ካላቸው ፋይሎች * የተገኘው ማህደረ ትውስታ ይህንን ተግባር ለመቋቋም በጣም ትልቅ ሊሆን ይችላል።
    ///
    /// እነዚህ ገደቦች ለማርካት አስቸጋሪ ከሆኑ በምትኩ [`wrapping_sub`] ን ለመጠቀም ያስቡ ፡፡
    /// የዚህ ዘዴ ብቸኛው ጠቀሜታ የበለጠ ጠበኛ የሆኑ የማጠናከሪያ ማመቻቻዎችን ማነቃቃቱ ነው ፡፡
    ///
    /// [`wrapping_sub`]: #method.wrapping_sub
    ///
    /// # Examples
    ///
    /// መሠረታዊ አጠቃቀም
    ///
    /// ```
    /// let s: &str = "123";
    ///
    /// unsafe {
    ///     let end: *const u8 = s.as_ptr().add(3);
    ///     println!("{}", *end.sub(1) as char);
    ///     println!("{}", *end.sub(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn sub(self, count: usize) -> Self
    where
        T: Sized,
    {
        // ደህንነት-ደዋዩ ለ `offset` የደህንነትን ውል ማክበር አለበት ፡፡
        unsafe { self.offset((count as isize).wrapping_neg()) }
    }

    /// መጠቅለያ ሂሳብ በመጠቀም መጠኑን ከጠቋሚው ያሰላል።
    /// (ለ `.wrapping_offset(count as isize)`) ምቾት)
    ///
    /// `count` በ T ክፍሎች ውስጥ ነው;ለምሳሌ ፣ የ 3 `count` የ `3 * size_of::<T>()` ባይት ጠቋሚ ማካካሻ ይወክላል።
    ///
    /// # Safety
    ///
    /// ይህ ክዋኔ ራሱ ሁል ጊዜም ደህንነቱ የተጠበቀ ነው ፣ ግን የተገኘውን ጠቋሚ መጠቀሙ ጥሩ አይደለም ፡፡
    ///
    /// የተገኘው ጠቋሚ `self` ከሚጠቆመው ተመሳሳይ የተመደበ ነገር ጋር ተያይዞ ይቀራል።
    /// የተለየ የተመደበ ነገርን ለመድረስ * ላይጠቀምበት ይችላል ፡፡በ Rust ውስጥ እያንዳንዱ የ (stack-allocated) ተለዋዋጭ እንደ የተለየ የተመደበ ነገር ተደርጎ ይወሰዳል ፡፡
    ///
    /// በሌላ አገላለጽ X0XX `1` መጠን አለው `1` አለው እና ምንም እንኳን ምንም ፍሰት ከሌለ የ X0XX ን ከ `y` ጋር ተመሳሳይ ያደርገዋል ፡፡ * `z` ን አያደርግም ፡፡ `y` ነጥብ ወደ ተመደበው ተመሳሳይ ነገር ፡፡
    ///
    /// ከ‹XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX ጋር ሲነፃፀሩ በተመሳሳይ በተመደበው ነገር ውስጥ የመቆየትን አስፈላጊነት ያዘገየዋል ፡፡`wrapping_add` ጠቋሚ ያመርታል ነገር ግን ጠቋሚው ከተያያዘው ነገር ድንበር ውጭ ሲሆን የተመዘገበ ከሆነ አሁንም ወደማይገለፅ ባህሪ ይመራል ፡፡
    /// [`add`] በተሻለ ሁኔታ ሊመች ይችላል እና ስለሆነም በአፈፃፀም-ተኮር ኮድ ውስጥ ተመራጭ ነው።
    ///
    /// የዘገየው ቼክ የመጨረሻ ውጤቱን በማስላት ወቅት ጥቅም ላይ የዋሉ መካከለኛ እሴቶችን ሳይሆን የተመዘገበውን የጠቋሚውን እሴት ብቻ ይመለከታል።
    /// ለምሳሌ ፣ `x.wrapping_add(o).wrapping_sub(o)` ሁልጊዜ ከ `x` ጋር አንድ ነው።በሌላ አገላለጽ የተመደበውን ነገር መተው እና ከዚያ በኋላ እንደገና ማስገባት ይፈቀዳል ፡፡
    ///
    /// የነገሮችን ድንበር ማቋረጥ ከፈለጉ ጠቋሚውን ወደ ቁጥር (ኢንቲጀር) ይጣሉት እና የሂሳብ ስራውን እዚያ ያካሂዱ ፡፡
    ///
    /// [`add`]: #method.add
    ///
    /// # Examples
    ///
    /// መሠረታዊ አጠቃቀም
    ///
    /// ```
    /// // በሁለት ንጥረ ነገሮች ጭማሪ ውስጥ ጥሬ ጠቋሚውን በመጠቀም ይቅጠሩ
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let step = 2;
    /// let end_rounded_up = ptr.wrapping_add(6);
    ///
    /// // ይህ ሉፕ "1, 3, 5, " ን ያትማል
    /// while ptr != end_rounded_up {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_add(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_add(self, count: usize) -> Self
    where
        T: Sized,
    {
        self.wrapping_offset(count as isize)
    }

    /// መጠቅለያ ሂሳብ በመጠቀም መጠኑን ከጠቋሚው ያሰላል።
    /// (ለ‹Wrapping_offset›ምቾት ((እንደ isize).wrapping_neg())`) ይቆጥሩ)
    ///
    /// `count` በ T ክፍሎች ውስጥ ነው;ለምሳሌ ፣ የ 3 `count` የ `3 * size_of::<T>()` ባይት ጠቋሚ ማካካሻ ይወክላል።
    ///
    /// # Safety
    ///
    /// ይህ ክዋኔ ራሱ ሁል ጊዜም ደህንነቱ የተጠበቀ ነው ፣ ግን የተገኘውን ጠቋሚ መጠቀሙ ጥሩ አይደለም ፡፡
    ///
    /// የተገኘው ጠቋሚ `self` ከሚጠቆመው ተመሳሳይ የተመደበ ነገር ጋር ተያይዞ ይቀራል።
    /// የተለየ የተመደበ ነገርን ለመድረስ * ላይጠቀምበት ይችላል ፡፡በ Rust ውስጥ እያንዳንዱ የ (stack-allocated) ተለዋዋጭ እንደ የተለየ የተመደበ ነገር ተደርጎ ይወሰዳል ፡፡
    ///
    /// በሌላ አገላለጽ X0XX `1` መጠን አለው `1` አለው እና ምንም እንኳን ምንም ፍሰት ከሌለ የ X0XX ን ከ `y` ጋር ተመሳሳይ ያደርገዋል ፡፡ * `z` ን አያደርግም ፡፡ `y` ነጥብ ወደ ተመደበው ተመሳሳይ ነገር ፡፡
    ///
    /// ከ‹XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX ጋር ሲነፃፀሩ በተመሳሳዩ በተመሣሣይ ነገር ውስጥ የመቆየትን አስፈላጊነት ያዘገየዋል ፡፡`wrapping_sub` ጠቋሚ ያመርታል ነገር ግን ጠቋሚው ከተያያዘው ነገር ድንበር ውጭ ሲሆን የተመዘገበ ከሆነ አሁንም ወደማይገለፅ ባህሪ ይመራል ፡፡
    /// [`sub`] በተሻለ ሁኔታ ሊመች ይችላል እና ስለሆነም በአፈፃፀም-ተኮር ኮድ ውስጥ ተመራጭ ነው።
    ///
    /// የዘገየው ቼክ የመጨረሻ ውጤቱን በማስላት ወቅት ጥቅም ላይ የዋሉ መካከለኛ እሴቶችን ሳይሆን የተመዘገበውን የጠቋሚውን እሴት ብቻ ይመለከታል።
    /// ለምሳሌ ፣ `x.wrapping_add(o).wrapping_sub(o)` ሁልጊዜ ከ `x` ጋር አንድ ነው።በሌላ አገላለጽ የተመደበውን ነገር መተው እና ከዚያ በኋላ እንደገና ማስገባት ይፈቀዳል ፡፡
    ///
    /// የነገሮችን ድንበር ማቋረጥ ከፈለጉ ጠቋሚውን ወደ ቁጥር (ኢንቲጀር) ይጣሉት እና የሂሳብ ስራውን እዚያ ያካሂዱ ፡፡
    ///
    /// [`sub`]: #method.sub
    ///
    /// # Examples
    ///
    /// መሠረታዊ አጠቃቀም
    ///
    /// ```
    /// // በሁለት ንጥረ ነገሮች (backwards) ጭማሪዎች ውስጥ ጥሬ ጠቋሚውን በመጠቀም ይቅጠሩ
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let start_rounded_down = ptr.wrapping_sub(2);
    /// ptr = ptr.wrapping_add(4);
    /// let step = 2;
    /// // ይህ ሉፕ "5, 3, 1, " ን ያትማል
    /// while ptr != start_rounded_down {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_sub(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_sub(self, count: usize) -> Self
    where
        T: Sized,
    {
        self.wrapping_offset((count as isize).wrapping_neg())
    }

    /// የጠቋሚውን እሴት ወደ `ptr` ያስቀምጣል።
    ///
    /// `self` ላልተመዘገበው ዓይነት የ (fat) ጠቋሚ ከሆነ ይህ ክዋኔ የጠቋሚውን ክፍል ብቻ ይነካል ፣ ለ (thin) ጠቋሚዎች መጠነኛ ዓይነቶች ግን ይህ ከቀላል ምደባ ጋር ተመሳሳይ ውጤት አለው ፡፡
    ///
    /// የተገኘው ጠቋሚ የ‹`val`›ማረጋገጫ አለው ፣ ማለትም ፣ ለአንድ ወፍራም ጠቋሚ ይህ ክዋኔ ከ‹`val`›የውሂብ ጠቋሚ እሴት ጋር ግን አዲስ የ‹XXXX›ዲታዳታ ከመፍጠር ጋር ተመሳሳይ ነው ፡፡
    ///
    ///
    /// # Examples
    ///
    /// ይህ ተግባር በዋነኝነት በስብ ሊሆኑ በሚችሉ ጠቋሚዎች ላይ ባይ-ጠቢብ ጠቋሚ ሂሳብን ለመፈለግ ጠቃሚ ነው ፡፡
    ///
    /// ```
    /// #![feature(set_ptr_value)]
    /// # use core::fmt::Debug;
    /// let arr: [i32; 3] = [1, 2, 3];
    /// let mut ptr = &arr[0] as *const dyn Debug;
    /// let thin = ptr as *const u8;
    /// unsafe {
    ///     ptr = ptr.set_ptr_value(thin.add(8));
    ///     # assert_eq!(*(ptr as *const i32), 3);
    ///     println!("{:?}", &*ptr); // "3" ን ያትማል
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "set_ptr_value", issue = "75091")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[inline]
    pub fn set_ptr_value(mut self, val: *const u8) -> Self {
        let thin = &mut self as *mut *const T as *mut *const u8;
        // ደህንነት-ቀጭን ጠቋሚ ቢኖር ይህ ክዋኔዎች ተመሳሳይ ናቸው
        // ወደ ቀላል ምደባ
        // የስብ ጠቋሚ ከሆነ ፣ አሁን ባለው የስብ ጠቋሚ አቀማመጥ አተገባበር ፣ የዚህ ዓይነቱ ጠቋሚ የመጀመሪያው መስክ ሁል ጊዜም እንዲሁ የሚመደበው የመረጃ ጠቋሚ ነው ፡፡
        //
        unsafe { *thin = val };
        self
    }

    /// እሴቱን ሳይያንቀሳቅስ ከ `self` ያነባል።
    /// ይህ በ `self` ውስጥ ማህደረ ትውስታውን ሳይለወጥ ይቀረዋል።
    ///
    /// ለደህንነት ስጋቶች እና ምሳሌዎች [`ptr::read`] ን ይመልከቱ ፡፡
    ///
    /// [`ptr::read`]: crate::ptr::read()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
    #[inline]
    pub const unsafe fn read(self) -> T
    where
        T: Sized,
    {
        // ደህንነት-ደዋዩ ለ `read` የደህንነትን ውል ማክበር አለበት ፡፡
        unsafe { read(self) }
    }

    /// እሴቱን ሳይንቀሳቀስ ከ `self` ዋጋ ያለው ተለዋዋጭ ንባብ ያካሂዳል።ይህ በ `self` ውስጥ ማህደረ ትውስታውን ሳይለወጥ ይቀረዋል።
    ///
    /// ተለዋዋጭ ተግባራት በ I/O ማህደረ ትውስታ ላይ እንዲሠሩ የታሰቡ ናቸው ፣ እና በሌሎች ተለዋዋጭ ተግባራት ላይ በአቀራባሪው እንዳይጎበኙ ወይም እንደገና እንዳይመደቡ የተረጋገጠ ነው።
    ///
    ///
    /// ለደህንነት ስጋቶች እና ምሳሌዎች [`ptr::read_volatile`] ን ይመልከቱ ፡፡
    ///
    /// [`ptr::read_volatile`]: crate::ptr::read_volatile()
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn read_volatile(self) -> T
    where
        T: Sized,
    {
        // ደህንነት-ደዋዩ ለ `read_volatile` የደህንነትን ውል ማክበር አለበት ፡፡
        unsafe { read_volatile(self) }
    }

    /// እሴቱን ሳይያንቀሳቅስ ከ `self` ያነባል።
    /// ይህ በ `self` ውስጥ ማህደረ ትውስታውን ሳይለወጥ ይቀረዋል።
    ///
    /// እንደ `read` ሳይሆን ጠቋሚው ያልተስተካከለ ሊሆን ይችላል።
    ///
    /// ለደህንነት ስጋቶች እና ምሳሌዎች [`ptr::read_unaligned`] ን ይመልከቱ ፡፡
    ///
    /// [`ptr::read_unaligned`]: crate::ptr::read_unaligned()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
    #[inline]
    pub const unsafe fn read_unaligned(self) -> T
    where
        T: Sized,
    {
        // ደህንነት-ደዋዩ ለ `read_unaligned` የደህንነትን ውል ማክበር አለበት ፡፡
        unsafe { read_unaligned(self) }
    }

    /// ቅጂዎች `count * size_of<T>` ባይት ከ `self` እስከ `dest`።
    /// ምንጩ እና መድረሻው ሊደራረቡ ይችላሉ ፡፡
    ///
    /// NOTE: ይህ እንደ [`ptr::copy`]*ተመሳሳይ* የክርክር ቅደም ተከተል አለው።
    ///
    /// ለደህንነት ስጋቶች እና ምሳሌዎች [`ptr::copy`] ን ይመልከቱ ፡፡
    ///
    /// [`ptr::copy`]: crate::ptr::copy()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_to(self, dest: *mut T, count: usize)
    where
        T: Sized,
    {
        // ደህንነት-ደዋዩ ለ `copy` የደህንነትን ውል ማክበር አለበት ፡፡
        unsafe { copy(self, dest, count) }
    }

    /// ቅጂዎች `count * size_of<T>` ባይት ከ `self` እስከ `dest`።
    /// ምንጩ እና መድረሻው *ሊ** አይችል ይሆናል።
    ///
    /// NOTE: ይህ እንደ [`ptr::copy_nonoverlapping`]*ተመሳሳይ* የክርክር ቅደም ተከተል አለው።
    ///
    /// ለደህንነት ስጋቶች እና ምሳሌዎች [`ptr::copy_nonoverlapping`] ን ይመልከቱ ፡፡
    ///
    /// [`ptr::copy_nonoverlapping`]: crate::ptr::copy_nonoverlapping()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_to_nonoverlapping(self, dest: *mut T, count: usize)
    where
        T: Sized,
    {
        // ደህንነት-ደዋዩ ለ `copy_nonoverlapping` የደህንነትን ውል ማክበር አለበት ፡፡
        unsafe { copy_nonoverlapping(self, dest, count) }
    }

    /// ከ `align` ጋር እንዲስተካከል ለማድረግ በጠቋሚው ላይ ሊተገበር የሚገባውን ማካካሻ ያሰላል።
    ///
    /// ጠቋሚውን ለማስተካከል የማይቻል ከሆነ አተገባበሩ `usize::MAX` ን ይመልሳል።
    /// ለትግበራው `usize::MAX` ን *ሁልጊዜ* እንዲመለስ ይፈቀዳል።
    /// የእርስዎ የአልጎሪዝም አፈፃፀም ብቻ ሊመካ የሚችለው እዚህ ላይ ሊሠራ የሚችል ማካካሻ በማግኘት ላይ ነው ፣ እሱ ትክክለኛነቱ አይደለም።
    ///
    /// ማካካሻ የሚገለጸው በ‹XXXX›አካላት ነው ፣ እና ባይቶች አይደለም ፡፡የተመለሰው እሴት በ `wrapping_add` ዘዴ መጠቀም ይቻላል።
    ///
    /// ጠቋሚውን ማካካሻ ጠቋሚው ወደ ሚያመለክተው ምደባ የማይበዛ ወይም ምንም የሚያልፍ ምንም ዋስትና የለም ፡፡
    ///
    /// የተመለሰውን ማካካሻ ከማስተካከል በተጨማሪ በሁሉም ቃላት ትክክል መሆኑን ማረጋገጥ የደዋዩ ነው።
    ///
    /// # Panics
    ///
    /// `align` የኃይል-የሁለት ካልሆነ panics ተግባር።
    ///
    /// # Examples
    ///
    /// በአጠገብ ያለውን `u8` ን እንደ `u16` መድረስ
    ///
    /// ```
    /// # fn foo(n: usize) {
    /// # use std::mem::align_of;
    /// # unsafe {
    /// let x = [5u8, 6u8, 7u8, 8u8, 9u8];
    /// let ptr = x.as_ptr().add(n) as *const u8;
    /// let offset = ptr.align_offset(align_of::<u16>());
    /// if offset < x.len() - n - 1 {
    ///     let u16_ptr = ptr.add(offset) as *const u16;
    ///     assert_ne!(*u16_ptr, 500);
    /// } else {
    ///     // ጠቋሚው በ `offset` በኩል ሊሰለፍ በሚችልበት ጊዜ ከምደባው ውጭ ይጠቁማል
    /////
    /// }
    /// # } }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "align_offset", since = "1.36.0")]
    pub fn align_offset(self, align: usize) -> usize
    where
        T: Sized,
    {
        if !align.is_power_of_two() {
            panic!("align_offset: align is not a power-of-two");
        }
        // ደህንነት: `align` ከላይ የ 2 ኃይል ሆኖ ተረጋግጧል
        unsafe { align_offset(self, align) }
    }
}

#[lang = "const_slice_ptr"]
impl<T> *const [T] {
    /// የአንድ ጥሬ ቁርጥራጭ ርዝመት ይመልሳል።
    ///
    /// የተመለሰው እሴት የ **አባሎች ቁጥር ነው**፣ የባይቶች ብዛት አይደለም።
    ///
    /// ጠቋሚው ዋጋ ቢስ ወይም ያልተስተካከለ ስለሆነ ጥሬው ቁራጭ ወደ ቁርጥራጭ ማጣቀሻ መጣል ባይችልም እንኳ ይህ ተግባር ደህንነቱ የተጠበቀ ነው።
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len)]
    ///
    /// use std::ptr;
    ///
    /// let slice: *const [i8] = ptr::slice_from_raw_parts(ptr::null(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    pub const fn len(self) -> usize {
        #[cfg(bootstrap)]
        {
            // ደህንነት ይህ `*const [T]` እና `FatPtr<T>` ተመሳሳይ አቀማመጥ ስላላቸው ይህ ደህንነቱ የተጠበቀ ነው ፡፡
            // ይህንን ዋስትና ሊሰጥ የሚችለው `std` ብቻ ነው።
            unsafe { Repr { rust: self }.raw }.len
        }
        #[cfg(not(bootstrap))]
        metadata(self)
    }

    /// ለተቆራረጠው ቋት ጥሬ አመላካች ይመልሳል።
    ///
    /// ይህ `self` ን ወደ `*const T` ከመጣል ጋር እኩል ነው ፣ ግን የበለጠ ዓይነት-ደህንነቱ የተጠበቀ።
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get)]
    /// use std::ptr;
    ///
    /// let slice: *const [i8] = ptr::slice_from_raw_parts(ptr::null(), 3);
    /// assert_eq!(slice.as_ptr(), 0 as *const i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_ptr(self) -> *const T {
        self as *const T
    }

    /// የድንበር ምርመራ ሳያደርግ ጥሬ ጠቋሚውን ወደ አንድ ንጥረ ነገር ወይም ንዑስ ክፍል ይመልሳል።
    ///
    /// ይህንን ዘዴ ከክልሎች ውጭ በሆነ መረጃ ጠቋሚ ወይም `self` በማይሰረዝበት ጊዜ መደወል *[ያልተገለጸ ባህሪ] ነው* ምንም እንኳን በውጤቱ ጠቋሚው ባይጠቅምም።
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get)]
    ///
    /// let x = &[1, 2, 4] as *const [i32];
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked(1), x.as_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked<I>(self, index: I) -> *const I::Output
    where
        I: SliceIndex<[T]>,
    {
        // ደህንነት-ደዋዩ `self` የማይነበብ እና የ `index` ውስን መሆንን ያረጋግጣል ፡፡
        unsafe { index.get_unchecked(self) }
    }

    /// ጠቋሚው ዋጋ ቢስ ከሆነ `None` ን ይመልሳል ፣ ወይም ደግሞ በ‹XXXX›ተጠቅልሎ ወደተጠቀሰው እሴት የተጋራ ቁራጭ ይመልሳል።
    /// ከ [`as_ref`] በተቃራኒው ይህ እሴቱ እንዲጀመር አይፈልግም።
    ///
    /// [`as_ref`]: #method.as_ref
    ///
    /// # Safety
    ///
    /// ይህንን ዘዴ በሚደውሉበት ጊዜ *ጠቋሚው NULL ነው* ወይም * የሚከተሉት ሁሉ እውነት መሆናቸውን ማረጋገጥ አለብዎት:
    ///
    /// * ጠቋሚ ለ `ptr.len() * mem::size_of::<T>()` ብዙ ባይቶች ለማንበብ [valid] መሆን አለበት እና በትክክል መመሳሰል አለበት።ይህ ማለት በተለይ
    ///
    ///     * የዚህ ቁራጭ አጠቃላይ የማስታወሻ ክልል በአንድ በተመደበ ነገር ውስጥ መያዝ አለበት!
    ///       ቁርጥራጮች በብዙ በተመደቡ ነገሮች ላይ በጭራሽ መዘርጋት አይችሉም።
    ///
    ///     * ጠቋሚው ለዜሮ-ርዝመት ቁርጥራጮች እንኳን መስተካከል አለበት።
    ///     ለዚህ አንደኛው ምክንያት የ‹Enum›አቀማመጥ ማመቻቸት በማጣቀሻዎች ላይ ሊመረኮዝ ስለሚችል ነው (ማንኛውንም ርዝመት ያላቸውን ቁርጥራጮችን ጨምሮ) ከሌሎች መረጃዎች ለመለየት በሚመሳሰሉ እና ዋጋ ቢስ ይሆናሉ ፡፡
    ///
    ///     [`NonNull::dangling()`] ን በመጠቀም ለዜሮ-ርዝመት ቁርጥራጮች እንደ `data` የሚያገለግል ጠቋሚ ማግኘት ይችላሉ ፡፡
    ///
    /// * የተቆራረጠ አጠቃላይ መጠን `ptr.len() * mem::size_of::<T>()` ከ `isize::MAX` ያልበለጠ መሆን አለበት።
    ///   የ [`pointer::offset`] የደህንነት ሰነድን ይመልከቱ ፡፡
    ///
    /// * የተመለሰው የሕይወት ዘመን `'a` በዘፈቀደ የተመረጠ ስለሆነ እና የውሂቡን ትክክለኛ የሕይወት ዘመን የሚያንፀባርቅ ባለመሆኑ የ Rust ተለዋጭ ስም ደንቦችን ማስከበር አለብዎት።
    ///   በተለይም እስከዚህ የሕይወት ዘመን ድረስ ጠቋሚው የሚያመለክተው ማህደረ ትውስታ መለወጥ የለበትም (ከ `UnsafeCell` ውስጥ በስተቀር) ፡፡
    ///
    /// የዚህ ዘዴ ውጤት ጥቅም ላይ ያልዋለ ቢሆንም ይህ ተግባራዊ ይሆናል!
    ///
    /// በተጨማሪም [`slice::from_raw_parts`][] ን ይመልከቱ።
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice<'a>(self) -> Option<&'a [MaybeUninit<T>]> {
        if self.is_null() {
            None
        } else {
            // ደህንነት-ደዋዩ ለ `as_uninit_slice` የደህንነትን ውል ማክበር አለበት ፡፡
            Some(unsafe { slice::from_raw_parts(self as *const MaybeUninit<T>, self.len()) })
        }
    }
}

// ለጠቋሚዎች እኩልነት
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> PartialEq for *const T {
    #[inline]
    fn eq(&self, other: &*const T) -> bool {
        *self == *other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Eq for *const T {}

// ለጠቋሚዎች ንፅፅር
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Ord for *const T {
    #[inline]
    fn cmp(&self, other: &*const T) -> Ordering {
        if self < other {
            Less
        } else if self == other {
            Equal
        } else {
            Greater
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> PartialOrd for *const T {
    #[inline]
    fn partial_cmp(&self, other: &*const T) -> Option<Ordering> {
        Some(self.cmp(other))
    }

    #[inline]
    fn lt(&self, other: &*const T) -> bool {
        *self < *other
    }

    #[inline]
    fn le(&self, other: &*const T) -> bool {
        *self <= *other
    }

    #[inline]
    fn gt(&self, other: &*const T) -> bool {
        *self > *other
    }

    #[inline]
    fn ge(&self, other: &*const T) -> bool {
        *self >= *other
    }
}