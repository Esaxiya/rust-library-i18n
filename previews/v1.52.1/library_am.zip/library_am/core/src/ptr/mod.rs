//! ጥሬ ጠቋሚዎችን በመጠቀም ማህደረ ትውስታን በእጅ ያስተዳድሩ።
//!
//! *[See also the pointer primitive types](pointer).*
//!
//! # Safety
//!
//! በዚህ ሞጁል ውስጥ ብዙ ተግባራት ጥሬ ጠቋሚዎችን እንደ ክርክር ወስደው ከነሱ ያነባሉ ወይም ይጽፋሉ ፡፡ይህ ደህንነቱ የተጠበቀ እንዲሆን እነዚህ አመልካቾች *ትክክለኛ* መሆን አለባቸው ፡፡
//! ጠቋሚው ትክክለኛ መሆን አለመሆኑ ለሚያገለግለው (ለንባብ ወይም ለመፃፍ) ክዋኔ እና በተደረሰበት ማህደረ ትውስታ መጠን (ማለትም ስንት ባይት read/written ናቸው) ላይ የተመሠረተ ነው ፡፡
//! ብዙ ተግባራት አንድ እሴት ብቻ ለመድረስ `*mut T` እና `* const T` ን ይጠቀማሉ ፣ በዚህ ጊዜ ሰነዶቹ መጠኑን ትተው በተዘዋዋሪ የ `size_of::<T>()` ባይቶች እንደሆኑ አድርገው ይገምታሉ።
//!
//! ትክክለኛነት ትክክለኛ ህጎች ገና አልተወሰኑም ፡፡በዚህ ጊዜ የሚሰጡት ዋስትናዎች በጣም አናሳ ናቸው-
//!
//! * የ [null] አመልካች *በጭራሽ* ትክክለኛ ነው ፣ ለ [size zero][zst] መዳረሻ እንኳን አይደለም።
//! * ጠቋሚው ትክክለኛ እንዲሆን ጠቋሚው *ሊገለበጥ የሚችል* መሆን አስፈላጊ ነው ፣ ግን ሁልጊዜ በቂ አይደለም-ከጠቋሚው ጀምሮ የተሰጠው የመጠን መጠን ሁሉም በአንድ በተመደበ ነገር ወሰን ውስጥ መሆን አለበት።
//!
//! በ Rust ውስጥ እያንዳንዱ የ (stack-allocated) ተለዋዋጭ እንደ የተለየ የተመደበ ነገር ተደርጎ ይወሰዳል ፡፡
//! * ለ‹[size zero][zst] X›ክንዋኔዎች እንኳን ጠቋሚው ወደተከፋፈለው ማህደረ ትውስታ መጠቆም የለበትም ፣ ማለትም ፣ የስምሪት ማመላከቻ ጠቋሚዎችን ለዜሮ መጠነ ሰፊ ክንውኖች እንኳን ዋጋ ቢስ ያደርገዋል ፡፡
//! ሆኖም ማንኛውም ዜሮ ያልሆኑ ቁጥሮችን *ቃል በቃል* ወደ ጠቋሚው መወርወር ለዜሮ መጠን ያላቸው ተደራሾች ልክ ነው ፣ ምንም እንኳን አንዳንድ ማህደረ ትውስታዎች በዚያ አድራሻ ቢኖሩም እና ቢከፋፈሉም።
//! ይህ የራስዎን አከፋፋይ ከመፃፍ ጋር ይዛመዳል ዜሮ መጠን ያላቸውን ዕቃዎች መመደብ በጣም ከባድ አይደለም።
//! ለዜሮ መጠን ያላቸው ተደራሾች የሚሰራ ጠቋሚ ለማግኘት ቀኖናዊ መንገድ [`NonNull::dangling`] ነው ፡፡
//! * በዚህ ሞጁል ውስጥ በተከናወኑ ተግባራት የሚከናወኑ ሁሉም መድረኮች በ‹XXXXXXXXXXXXXXXXXXXX›አንጻር በክሮች መካከል ለማመሳሰል ያገለግላሉ ፡፡
//! ይህ ማለት ሁለቱም መድረሻዎች ከማስታወሻ ብቻ የሚነበብ ካልሆነ በስተቀር ከተለያዩ ክሮች ወደ አንድ ቦታ ሁለት ተመሳሳይ መድረሻዎችን ማከናወን ያልተገለጸ ባህሪ ነው ማለት ነው ፡፡
//! ይህ በግልፅ [`read_volatile`] እና [`write_volatile`] ን እንደሚያካትት ልብ ይበሉ: ተለዋዋጭ ተለዋዋጭዎች ለበይነ-ክር ማመሳሰል ሊያገለግሉ አይችሉም ፡፡
//! * ለጠቋሚው ማጣቀሻ ማድረጉ ውጤቱ ዋናው ነገር በቀጥታ እስከሆነ እና ተመሳሳይ ማህደረ ትውስታን ለመድረስ ምንም ማጣቀሻ (ጥሬ ጠቋሚዎች ብቻ) እስካለ ድረስ ትክክለኛ ነው።
//!
//! እነዚህ አክሲዮሞች [`offset`] ን ለጠቋሚ ሂሳብ በጥንቃቄ ከመጠቀም ጋር ፣ ደህንነታቸው ባልተጠበቀ ኮድ ውስጥ ብዙ ጠቃሚ ነገሮችን በትክክል ለመተግበር በቂ ናቸው ፡፡
//! የ [aliasing] ህጎች እየተወሰኑ ስለሆኑ የበለጠ ጠንካራ ዋስትናዎች በመጨረሻ ይሰጣሉ ፡፡
//! ለበለጠ መረጃ [book] ን እንዲሁም ለ [undefined behavior][ub] በተሰየመ ማጣቀሻ ውስጥ ያለውን ክፍል ይመልከቱ ፡፡
//!
//! ## Alignment
//!
//! ከላይ እንደተገለጸው ዋጋ ያላቸው ጥሬ ጠቋሚዎች የግድ በትክክል የተጣጣሙ አይደሉም (የ "proper" አሰላለፍ በጠቋሚው ዓይነት ይገለጻል ፣ ማለትም ፣ `*const T` ከ `mem::align_of::<T>()` ጋር መመሳሰል አለበት)።
//! ሆኖም ግን ፣ አብዛኛዎቹ ተግባራት ክርክሮቻቸው በትክክል እንዲጣጣሙ ይፈልጋሉ ፣ እናም ይህንን መስፈርት በሰነዶቻቸው ውስጥ በግልጽ ያሳያሉ ፡፡
//! ለዚህ የሚታወቁ ልዩነቶች [`read_unaligned`] እና [`write_unaligned`] ናቸው ፡፡
//!
//! አንድ ተግባር ትክክለኛውን አሰላለፍ በሚፈልግበት ጊዜ መድረሻው መጠኑ 0 ቢኖረውም ያደርገዋል ፣ ማለትም ፣ ማህደረ ትውስታ በእውነቱ ባይነካም እንኳ።በእንደዚህ ያሉ ጉዳዮች ላይ [`NonNull::dangling`] ን ለመጠቀም ያስቡ ፡፡
//!
//! [aliasing]: ../../nomicon/aliasing.html
//! [book]: ../../book/ch19-01-unsafe-rust.html#dereferencing-a-raw-pointer
//! [ub]: ../../reference/behavior-considered-undefined.html
//! [zst]: ../../nomicon/exotic-sizes.html#zero-sized-types-zsts
//! [atomic operations]: crate::sync::atomic
//! [`offset`]: pointer::offset
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering;
use crate::fmt;
use crate::hash;
use crate::intrinsics::{self, abort, is_aligned_and_not_null};
use crate::mem::{self, MaybeUninit};

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::copy_nonoverlapping;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::copy;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::write_bytes;

#[cfg(not(bootstrap))]
mod metadata;
#[cfg(not(bootstrap))]
pub(crate) use metadata::PtrRepr;
#[cfg(not(bootstrap))]
#[unstable(feature = "ptr_metadata", issue = "81513")]
pub use metadata::{from_raw_parts, from_raw_parts_mut, metadata, DynMetadata, Pointee, Thin};

mod non_null;
#[stable(feature = "nonnull", since = "1.25.0")]
pub use non_null::NonNull;

mod unique;
#[unstable(feature = "ptr_internals", issue = "none")]
pub use unique::Unique;

mod const_ptr;
mod mut_ptr;

/// የተጠቆመውን እሴት አጥፊ (ካለ) ያስፈጽማል።
///
/// ይህ [`ptr::read`] ን ከመጥራት እና ውጤቱን ከማስወገድ ጋር ተመሳሳይ ነው ፣ ግን የሚከተሉትን ጥቅሞች አሉት
///
/// * እንደ trait ዕቃዎች ያሉ ያልተመዘኑ አይነቶችን ለመጣል `drop_in_place` ን መጠቀም *ያስፈልጋል* ምክንያቱም በተደራረቡበት ላይ ሊነበቡ እና በተለምዶ መውደቅ ስለማይችሉ ነው ፡፡
///
/// * በእጅ የተሰየመ ማህደረ ትውስታን በሚጥሉበት ጊዜ (ለምሳሌ በ `Box`/`Rc`/`Vec` አፈፃፀም ውስጥ) በ [`ptr::read`] ላይ ይህን ለማድረግ አመቻቹ ይበልጥ ተስማሚ ነው ፣ ምክንያቱም አዘጋጁ አጻጻፉ ቅጅውን ለመገልበጥ ጥሩ መሆኑን ማረጋገጥ አያስፈልገውም ፡፡
///
///
/// * `T` `repr(packed)` በማይሆንበት ጊዜ የ [pinned] መረጃን ለመጣል ሊያገለግል ይችላል (የተሰካ ውሂብ ከመውደቁ በፊት መንቀሳቀስ የለበትም)።
///
/// ያልተስተካከሉ እሴቶች በቦታው መጣል አይችሉም ፣ በመጀመሪያ [`ptr::read_unaligned`] ን በመጠቀም ወደ ተስተካከለ ቦታ መገልበጥ አለባቸው።ለታሸጉ እርከኖች ይህ እንቅስቃሴ በራስ-ሰር በአቀማጩ ይከናወናል።
/// ይህ ማለት የታሸጉ እርከኖች እርሻዎች በቦታው አይጣሉም ማለት ነው ፡፡
///
/// [`ptr::read`]: self::read
/// [`ptr::read_unaligned`]: self::read_unaligned
/// [pinned]: crate::pin
///
/// # Safety
///
/// ከሚከተሉት ሁኔታዎች ውስጥ አንዳቸውም ቢጣሱ ባህሪይ አልተገለጸም-
///
/// * `to_drop` ለሁለቱም ለማንበብ እና ለመፃፍ [valid] መሆን አለበት።
///
/// * `to_drop` በትክክል መመሳሰል አለበት።
///
/// * `to_drop` የሚያመለክተው እሴት ለመውደቅ ልክ መሆን አለበት ፣ ይህም ማለት ተጨማሪ የማይለዋወጥ ሰዎችን መደገፍ አለበት ማለት ሊሆን ይችላል ፣ ይህ በአይነት ላይ የተመሠረተ ነው።
///
/// በተጨማሪም ፣ `T` [`Copy`] ካልሆነ `drop_in_place` ን ከጠራ በኋላ የተጠቆመውን እሴት በመጠቀም ያልተገለጸ ባህሪን ያስከትላል ፡፡`*to_drop = foo` እንደአጠቃቀም ይቆጥራል ምክንያቱም እሴቱ እንደገና እንዲወድቅ ስለሚያደርግ ነው።
/// [`write()`] ውሂብ እንዲወድቅ ሳያደርግ እንደገና ለመጻፍ ሊያገለግል ይችላል።
///
/// `T` መጠን `0` ያለው እንኳ ቢሆን, የ ጠቋሚ ያልሆኑ አልቦ እና በአግባቡ የሚጣጣም መሆን እንዳለበት ልብ በል.
///
/// [valid]: self#safety
///
/// # Examples
///
/// የመጨረሻውን ንጥል ከ vector በእጅ ያስወግዱ:
///
/// ```
/// use std::ptr;
/// use std::rc::Rc;
///
/// let last = Rc::new(1);
/// let weak = Rc::downgrade(&last);
///
/// let mut v = vec![Rc::new(0), last];
///
/// unsafe {
///     // በ `v` ውስጥ ወደ መጨረሻው ንጥረ ነገር ጥሬ አመላካች ያግኙ።
///     let ptr = &mut v[1] as *mut _;
///     // የመጨረሻው ንጥል እንዳይወድቅ ለመከላከል `v` ን ያሳጥሩ።
///     // ከ panics በታች ያለው `drop_in_place` ከሆነ ጉዳዮችን ለመከላከል በመጀመሪያ ያንን እናደርጋለን።
///     v.set_len(1);
///     // ያለ `drop_in_place` ጥሪ ፣ የመጨረሻው ንጥል በጭራሽ አይጣልም ፣ እና የሚያስተዳድረው ማህደረ ትውስታም ይነቃል።
/////
///     ptr::drop_in_place(ptr);
/// }
///
/// assert_eq!(v, &[0.into()]);
///
/// // የመጨረሻው ንጥል እንደተጣለ ያረጋግጡ።
/// assert!(weak.upgrade().is_none());
/// ```
///
/// የታሸጉ ደንቦችን በሚጥሉበት ጊዜ አጠናቃሪው ይህን ቅጂ በራስ-ሰር እንደሚያከናውን ልብ ይበሉ ፣ ማለትም ፣ `drop_in_place` ን በእጅ ካልደውሉ በስተቀር ብዙውን ጊዜ ስለእነዚህ ጉዳዮች መጨነቅ አያስፈልግዎትም።
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "drop_in_place", since = "1.8.0")]
#[lang = "drop_in_place"]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // እዚህ ኮድ ምንም አይደለም ፣ ይህ በእውነተኛው ጠብታ ሙጫ በአቀማሚው ተተክቷል።
    //

    // ደህንነት-ከላይ ያለውን አስተያየት ይመልከቱ
    unsafe { drop_in_place(to_drop) }
}

/// የኑሮ ጥሬ ጠቋሚ ይፈጥራል።
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let p: *const i32 = ptr::null();
/// assert!(p.is_null());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_ptr_null", since = "1.32.0")]
pub const fn null<T>() -> *const T {
    0 as *const T
}

/// ባዶ-ሊለውጥ የሚችል ጠቋሚ ጠቋሚ ይፈጥራል።
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let p: *mut i32 = ptr::null_mut();
/// assert!(p.is_null());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_ptr_null", since = "1.32.0")]
pub const fn null_mut<T>() -> *mut T {
    0 as *mut T
}

#[cfg(bootstrap)]
#[repr(C)]
pub(crate) union Repr<T> {
    pub(crate) rust: *const [T],
    rust_mut: *mut [T],
    pub(crate) raw: FatPtr<T>,
}

#[cfg(bootstrap)]
#[repr(C)]
pub(crate) struct FatPtr<T> {
    data: *const T,
    pub(crate) len: usize,
}

#[cfg(bootstrap)]
// ከ‹XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXEXEXDEK
impl<T> Clone for FatPtr<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[cfg(bootstrap)]
// ከ‹XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXEXEXDEK
impl<T> Copy for FatPtr<T> {}

/// ከጠቋሚ እና ርዝመት አንድ ጥሬ ቁርጥራጭ ይመሰርታል።
///
/// የ‹XXXX›ክርክር የ **አባሎች ብዛት ነው**፣ ባይቶች ቁጥር አይደለም።
///
/// ይህ ተግባር ደህንነቱ የተጠበቀ ነው ፣ ግን በእውነቱ የመመለሻውን እሴት መጠቀሙ ደህንነቱ የተጠበቀ ነው።
/// ለተቆራረጠ የደኅንነት መስፈርቶች የ [`slice::from_raw_parts`] ሰነድን ይመልከቱ ፡፡
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
///
/// # Examples
///
/// ```rust
/// use std::ptr;
///
/// // ወደ መጀመሪያው አካል ከጠቋሚ ሲጀምሩ የተቆራረጠ ጠቋሚ ይፍጠሩ
/// let x = [5, 6, 7];
/// let raw_pointer = x.as_ptr();
/// let slice = ptr::slice_from_raw_parts(raw_pointer, 3);
/// assert_eq!(unsafe { &*slice }[2], 7);
/// ```
#[inline]
#[stable(feature = "slice_from_raw_parts", since = "1.42.0")]
#[rustc_const_unstable(feature = "const_slice_from_raw_parts", issue = "67456")]
pub const fn slice_from_raw_parts<T>(data: *const T, len: usize) -> *const [T] {
    #[cfg(bootstrap)]
    {
        // ደህንነት-እሴቱን ከ `Repr` ህብረት ማግኘት ከ * const [T] ጀምሮ ደህንነቱ የተጠበቀ ነው
        //
        // እና FatPtr ተመሳሳይ የማስታወሻ አቀማመጦች አሏቸው።ይህንን ዋስትና ሊሰጥ የሚችለው std ብቻ ነው።
        unsafe { Repr { raw: FatPtr { data, len } }.rust }
    }
    #[cfg(not(bootstrap))]
    from_raw_parts(data.cast(), len)
}

/// ጥሬ የማይለዋወጥ ቁርጥራጭ በተቃራኒው ጥሬ ሊለዋወጥ የሚችል ቁርጥራጭ ከተመለሰ በስተቀር እንደ [`slice_from_raw_parts`] ተመሳሳይ ተግባር ያከናውናል።
///
///
/// ለተጨማሪ ዝርዝሮች የ [`slice_from_raw_parts`] ሰነድን ይመልከቱ ፡፡
///
/// ይህ ተግባር ደህንነቱ የተጠበቀ ነው ፣ ግን በእውነቱ የመመለሻውን እሴት መጠቀሙ ደህንነቱ የተጠበቀ ነው።
/// ለተቆራረጠ የደኅንነት መስፈርቶች የ [`slice::from_raw_parts_mut`] ሰነድን ይመልከቱ ፡፡
///
/// [`slice::from_raw_parts_mut`]: crate::slice::from_raw_parts_mut
///
/// # Examples
///
/// ```rust
/// use std::ptr;
///
/// let x = &mut [5, 6, 7];
/// let raw_pointer = x.as_mut_ptr();
/// let slice = ptr::slice_from_raw_parts_mut(raw_pointer, 3);
///
/// unsafe {
///     (*slice)[2] = 99; // በተቆራጩ ውስጥ ባለው መረጃ ጠቋሚ ላይ እሴት ይመድቡ
/// };
///
/// assert_eq!(unsafe { &*slice }[2], 99);
/// ```
#[inline]
#[stable(feature = "slice_from_raw_parts", since = "1.42.0")]
#[rustc_const_unstable(feature = "const_slice_from_raw_parts", issue = "67456")]
pub const fn slice_from_raw_parts_mut<T>(data: *mut T, len: usize) -> *mut [T] {
    #[cfg(bootstrap)]
    {
        // ደህንነት: ዋጋውን ከ `Repr` ህብረት መድረስ ከ * mut [T] ጀምሮ ደህንነቱ የተጠበቀ ነው
        // እና FatPtr ተመሳሳይ የማስታወሻ አቀማመጦች አሏቸው
        unsafe { Repr { raw: FatPtr { data, len } }.rust_mut }
    }
    #[cfg(not(bootstrap))]
    from_raw_parts_mut(data.cast(), len)
}

/// እሴቶቹን ሁለቱንም ሳይለዩ በአንድ ዓይነት ሁለት በሚለዋወጡ ቦታዎች ላይ ይተዋወቃል።
///
/// ግን ለሚቀጥሉት ሁለት ልዩነቶች ይህ ተግባር ከ [`mem::swap`] ጋር ተመሳሳይ ነው-
///
///
/// * ከማጣቀሻዎች ይልቅ በጥሬ ጠቋሚዎች ላይ ይሠራል ፡፡
/// ማጣቀሻዎች በሚኖሩበት ጊዜ [`mem::swap`] ተመራጭ መሆን አለበት ፡፡
///
/// * ወደ ሁለቱ የተጠቆሙ እሴቶች ሊጣመሩ ይችላሉ ፡፡
/// እሴቶቹ ተደራራቢ ከሆኑ ከዚያ ከ `x` የተደረደረው የማስታወሻ ክልል ጥቅም ላይ ይውላል።
/// ይህ ከታች በሁለተኛው ምሳሌ ውስጥ ይታያል ፡፡
///
/// # Safety
///
/// ከሚከተሉት ሁኔታዎች ውስጥ አንዳቸውም ቢጣሱ ባህሪይ አልተገለጸም-
///
/// * ሁለቱም `x` እና `y` ለሁለቱም ለንባብም ሆነ ለመጻፍ [valid] መሆን አለባቸው ፡፡
///
/// * ሁለቱም `x` እና `y` በትክክል መመሳሰል አለባቸው።
///
/// `T` መጠን `0` ቢኖረውም እንኳ ጠቋሚዎቹ NULL ያልሆኑ እና በትክክል የተጣጣሙ መሆን እንዳለባቸው ልብ ይበሉ።
///
/// [valid]: self#safety
///
/// # Examples
///
/// ሁለት ተደራራቢ ያልሆኑ ክልሎችን መለዋወጥ
///
/// ```
/// use std::ptr;
///
/// let mut array = [0, 1, 2, 3];
///
/// let x = array[0..].as_mut_ptr() as *mut [u32; 2]; // ይህ `array[0..2]` ነው
/// let y = array[2..].as_mut_ptr() as *mut [u32; 2]; // ይህ `array[2..4]` ነው
///
/// unsafe {
///     ptr::swap(x, y);
///     assert_eq!([2, 3, 0, 1], array);
/// }
/// ```
///
/// ሁለት ተደራራቢ ክልሎችን መለዋወጥ
///
/// ```
/// use std::ptr;
///
/// let mut array = [0, 1, 2, 3];
///
/// let x = array[0..].as_mut_ptr() as *mut [u32; 3]; // ይህ `array[0..3]` ነው
/// let y = array[1..].as_mut_ptr() as *mut [u32; 3]; // ይህ `array[1..4]` ነው
///
/// unsafe {
///     ptr::swap(x, y);
///     // የተቆራረጠው የ `1..3` ኢንዴክሶች በ `x` እና `y` መካከል ይደራረባሉ።
///     // ምክንያታዊ ውጤቶች ለእነሱ `[2, 3]` ይሆናል ፣ ስለሆነም ማውጫዎች `0..3` `[1, 2, 3]` ናቸው (ከ `swap` በፊት ከ `y` ጋር ይዛመዳል) ፣ወይም `1..4` ኢንዴክስ `[0, 1, 2]` (ከ `swap` በፊት `x` ጋር የሚዛመድ) እንዲሆኑ `[0, 1]` እንዲሆኑ ፡፡
/////
///     // የመጨረሻውን ምርጫ ለማድረግ ይህ ትግበራ ይገለጻል ፡፡
/////
///     assert_eq!([1, 0, 1, 2], array);
/// }
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
pub const unsafe fn swap<T>(x: *mut T, y: *mut T) {
    // አብረን የምንሠራበት የተወሰነ የጭረት ቦታ ለራሳችን ስጠን ፡፡
    // ስለ ጠብታዎች መጨነቅ የለብንም `MaybeUninit` ሲወድቅ ምንም አያደርግም ፡፡
    let mut tmp = MaybeUninit::<T>::uninit();

    // የ `ስዋፕ` ደህንነትን ያከናውኑ ደዋዩ `x` እና `y` ለጽሑፍ ትክክለኛ እና የተስተካከለ መሆኑን ማረጋገጥ አለበት ፡፡
    // `tmp` `tmp` ን እንደ የተለየ የተመደበ ነገር በቁጥሩ ላይ ብቻ ስለተመደበ `x` ወይም `y` ን መደራረብ አይቻልም።
    //
    //
    //
    unsafe {
        copy_nonoverlapping(x, tmp.as_mut_ptr(), 1);
        copy(y, x, 1); // `x` እና `y` ሊደራረብ ይችላል
        copy_nonoverlapping(tmp.as_ptr(), y, 1);
    }
}

/// ከ `x` እና `y` ጀምሮ በሁለቱ የማስታወስ ክልሎች መካከል ስዋፕስ `count * size_of::<T>()` ባይት ፡፡
/// ሁለቱ ክልሎች *መደራረብ* የለባቸውም ፡፡
///
/// # Safety
///
/// ከሚከተሉት ሁኔታዎች ውስጥ አንዳቸውም ቢጣሱ ባህሪይ አልተገለጸም-
///
/// * ሁለቱም `x` እና `y` ለሁለቱም ለንባብ እና ለመፃፍ [valid] መሆን አለባቸው *
///   መጠን: :<T>() ባይት
///
/// * ሁለቱም `x` እና `y` በትክክል መመሳሰል አለባቸው።
///
/// * በ‹XXXX›የሚጀምር የማስታወሻ ክልል በ‹ቆጠራ መጠን› *
///   መጠን: :<T>() `ባይት በተመሳሳይ መጠን ከ `y` ጀምሮ ባለው የማስታወሻ ክልል * * መደራረብ * የለበትም።
///
/// ምንም እንኳን በውጤታማነቱ የተገለበጠው መጠን (`ቆጠራ * መጠን_ፋ: :<T>()`0` ነው ፣ ጠቋሚዎቹ NULL ያልሆኑ እና በትክክል የተጣጣሙ መሆን አለባቸው።
///
///
/// [valid]: self#safety
///
/// # Examples
///
/// መሠረታዊ አጠቃቀም
///
/// ```
/// use std::ptr;
///
/// let mut x = [1, 2, 3, 4];
/// let mut y = [7, 8, 9];
///
/// unsafe {
///     ptr::swap_nonoverlapping(x.as_mut_ptr(), y.as_mut_ptr(), 2);
/// }
///
/// assert_eq!(x, [7, 8, 3, 4]);
/// assert_eq!(y, [1, 2, 9]);
/// ```
///
#[inline]
#[stable(feature = "swap_nonoverlapping", since = "1.27.0")]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
pub const unsafe fn swap_nonoverlapping<T>(x: *mut T, y: *mut T, count: usize) {
    let x = x as *mut u8;
    let y = y as *mut u8;
    let len = mem::size_of::<T>() * count;
    // ደህንነት-ደዋዩ `x` እና `y` መሆናቸውን ማረጋገጥ አለበት
    // ለጽሑፍ የሚሰራ እና በትክክል የተስተካከለ።
    unsafe { swap_nonoverlapping_bytes(x, y, len) }
}

#[inline]
pub(crate) unsafe fn swap_nonoverlapping_one<T>(x: *mut T, y: *mut T) {
    // ከዚህ በታች ካለው የማገጃ ማመቻቸት ያነሱ አይነቶች ኮዴገንን ተስፋ ከመቁረጥ ለመቆጠብ በቀጥታ ይለዋወጡ ፡፡
    //
    if mem::size_of::<T>() < 32 {
        // ደህንነት-ደዋዩ `x` እና `y` ትክክለኛ መሆናቸውን ማረጋገጥ አለበት
        // ለጽሑፍ ፣ በትክክል የተስተካከለ እና ተደራራቢ ያልሆነ።
        unsafe {
            let z = read(x);
            copy_nonoverlapping(y, x, 1);
            write(y, z);
        }
    } else {
        // ደህንነት-ደዋዩ ለ `swap_nonoverlapping` የደህንነትን ውል ማክበር አለበት ፡፡
        unsafe { swap_nonoverlapping(x, y, 1) };
    }
}

#[inline]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
const unsafe fn swap_nonoverlapping_bytes(x: *mut u8, y: *mut u8, len: usize) {
    // እዚህ ያለው አካሄድ x&y ን በብቃት ለመለዋወጥ ሲምድን መጠቀም ነው።
    // መሞከር 32 ኢንች ወይም 64 ባይት በአንድ ጊዜ መለዋወጥ ለኢንቴል ሃስዌል ኢ ፕሮሰሰሮች በጣም ውጤታማ መሆኑን ያሳያል ፡፡
    // ይህንን መዋቅር በቀጥታ ባንጠቀም እንኳን ኤልኤልቪኤም‹#[repr(simd)]›ን ከሰጠነው የበለጠ ማመቻቸት ይችላል ፡፡
    //
    //
    // FIXME repr(simd) በኤምስክሪፕት እና ሬዶክስ ላይ ተሰብሯል
    #[cfg_attr(not(any(target_os = "emscripten", target_os = "redox")), repr(simd))]
    struct Block(u64, u64, u64, u64);
    struct UnalignedBlock(u64, u64, u64, u64);

    let block_size = mem::size_of::<Block>();

    // በ x&y በኩል ይዙሩ ፣ እነሱን በአንድ ጊዜ `Block` ን ይገለብጡላቸው አመቻቹ ለአብዛኞቹ ዓይነቶች NB ቀለበቱን ሙሉ በሙሉ መዘርጋት አለበት
    // `range` impl በተደጋጋሚ `mem::swap` ን ስለሚጠራ ለሉፕ መጠቀም አንችልም
    //
    let mut i = 0;
    while i + block_size <= len {
        // `t` ን ማወጅ እዚህ ላይ ያልተስተካከለ ማህደረ ትውስታን ይፍጠሩ ይህ ዑደት ጥቅም ላይ ባልዋለበት ጊዜ ቁመቱን ከማስተካከል ያስቀራል ፡፡
        //
        let mut t = mem::MaybeUninit::<Block>::uninit();
        let t = t.as_mut_ptr() as *mut u8;

        // ደህንነት-እንደ `i < len` ፣ እና ደዋዩ `x` እና `y` ትክክለኛ መሆናቸውን ማረጋገጥ አለበት
        // ለ `len` ባይት ፣ `x + i` እና `y + i` ትክክለኛ አድራሻዎች መሆን አለባቸው ፣ ይህም ለ‹`add` X›የደህንነትን ውል ያሟላ ፡፡
        //
        // እንዲሁም ደዋዩ `x` እና `y` ለ `copy_nonoverlapping` የደህንነት ውል የሚያሟላ ለጽሑፍ ፣ በትክክል ለተስተካከለ እና ለተደራራቢ ትክክለኛ መሆኑን ማረጋገጥ አለበት ፡፡
        //
        //
        unsafe {
            let x = x.add(i);
            let y = y.add(i);

            // T ን እንደ ጊዜያዊ ቋት በመጠቀም የ x&y ባይት አንድ ብሎክ ይለዋወጡ ይህ በሚገኝበት ውጤታማ ወደ ሲምዲ ክወናዎች ማመቻቸት አለበት
            //
            copy_nonoverlapping(x, t, block_size);
            copy_nonoverlapping(y, x, block_size);
            copy_nonoverlapping(t, y, block_size);
        }
        i += block_size;
    }

    if i < len {
        // የቀሩትን ባይቶች በሙሉ ይቀያይሩ
        let mut t = mem::MaybeUninit::<UnalignedBlock>::uninit();
        let rem = len - i;

        let t = t.as_mut_ptr() as *mut u8;

        // ደህንነት-የቀደመውን የደህንነት አስተያየት ይመልከቱ ፡፡
        unsafe {
            let x = x.add(i);
            let y = y.add(i);

            copy_nonoverlapping(x, t, rem);
            copy_nonoverlapping(y, x, rem);
            copy_nonoverlapping(t, y, rem);
        }
    }
}

/// የቀደመውን `dst` እሴት በመመለስ `src` ን ወደ ጠቆመው `dst` ይዛወራል።
///
/// ሁለቱም እሴት አልተቀነሰም ፡፡
///
/// ይህ ተግባር ከማጣቀሻዎች ይልቅ በጥሬ ጠቋሚዎች ላይ የሚሰራ ካልሆነ በስተቀር ይህ ተግባር ከ [`mem::replace`] ጋር እኩል ነው ፡፡
/// ማጣቀሻዎች በሚኖሩበት ጊዜ [`mem::replace`] ተመራጭ መሆን አለበት ፡፡
///
/// # Safety
///
/// ከሚከተሉት ሁኔታዎች ውስጥ አንዳቸውም ቢጣሱ ባህሪይ አልተገለጸም-
///
/// * `dst` ለሁለቱም ለማንበብ እና ለመፃፍ [valid] መሆን አለበት።
///
/// * `dst` በትክክል መመሳሰል አለበት።
///
/// * `dst` በትክክል ለተጀመረው የ `T` ዓይነት መጠቆም አለበት።
///
/// `T` መጠን `0` ያለው እንኳ ቢሆን, የ ጠቋሚ ያልሆኑ አልቦ እና በአግባቡ የሚጣጣም መሆን እንዳለበት ልብ በል.
///
/// [valid]: self#safety
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let mut rust = vec!['b', 'u', 's', 't'];
///
/// // `mem::replace` ደህንነቱ ያልተጠበቀ ማገጃ ሳያስፈልግ ተመሳሳይ ውጤት ይኖረዋል ፡፡
/////
/// let b = unsafe {
///     ptr::replace(&mut rust[0], 'r')
/// };
///
/// assert_eq!(b, 'b');
/// assert_eq!(rust, &['r', 'u', 's', 't']);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn replace<T>(dst: *mut T, mut src: T) -> T {
    // ደህንነት-ደዋዩ `dst` ለመሆኑ ትክክለኛ መሆኑን ማረጋገጥ አለበት
    // `dst` ወደተለየ የተመደበ ነገር መጠቆም ስላለበት ወደ ሚቀየረው ማጣቀሻ ይጣላል (ለጽሑፍ የሚሰራ ፣ የተስተካከለ ፣ የተጀመረ) እና `src` ን መደራረብ አይችልም።
    //
    //
    unsafe {
        mem::swap(&mut *dst, &mut src); // መደራረብ አይቻልም
    }
    src
}

/// እሴቱን ሳይያንቀሳቅስ ከ `src` ያነባል።ይህ በ `src` ውስጥ ማህደረ ትውስታውን ሳይለወጥ ይቀረዋል።
///
/// # Safety
///
/// ከሚከተሉት ሁኔታዎች ውስጥ አንዳቸውም ቢጣሱ ባህሪይ አልተገለጸም-
///
/// * `src` ለማንበብ [valid] መሆን አለበት።
///
/// * `src` በትክክል መመሳሰል አለበት።ጉዳዩ ይህ ካልሆነ [`read_unaligned`] ን ይጠቀሙ።
///
/// * `src` በትክክል ለተጀመረው የ `T` ዓይነት መጠቆም አለበት።
///
/// `T` መጠን `0` ያለው እንኳ ቢሆን, የ ጠቋሚ ያልሆኑ አልቦ እና በአግባቡ የሚጣጣም መሆን እንዳለበት ልብ በል.
///
/// # Examples
///
/// መሠረታዊ አጠቃቀም
///
/// ```
/// let x = 12;
/// let y = &x as *const i32;
///
/// unsafe {
///     assert_eq!(std::ptr::read(y), 12);
/// }
/// ```
///
/// [`mem::swap`] ን በእጅ ይተግብሩ:
///
/// ```
/// use std::ptr;
///
/// fn swap<T>(a: &mut T, b: &mut T) {
///     unsafe {
///         // በ `tmp` ውስጥ በ `a` ላይ እሴቱን ትንሽ አቅጣጫዊ ቅጅ ይፍጠሩ።
///         let tmp = ptr::read(a);
///
///         // ከዚህ ቦታ መውጣት (በግልፅ በመመለስ ወይም የ panics ተግባርን በመጥራት) በ `tmp` ውስጥ ያለው እሴት እንዲወድቅ ያደርገዋል ፣ አሁንም ተመሳሳይ እሴት በ `a` እየተጣቀሰ።
///         // `T` `Copy` ካልሆነ ይህ ያልተገለጸ ባህሪን ሊያስነሳ ይችላል።
/////
/////
///
///         // በ `a` ውስጥ በ `b` ላይ እሴቱን ትንሽ አቅጣጫዊ ቅጅ ይፍጠሩ።
///         // የሚለዋወጥ ማጣቀሻዎች ቅጽል ሊሆኑ ስለማይችሉ ይህ ደህንነቱ የተጠበቀ ነው።
///         ptr::copy_nonoverlapping(b, a, 1);
///
///         // ከላይ እንደተጠቀሰው ፣ እዚህ መውጣቱ ያልታወቀ ባህሪን ሊያስነሳ ይችላል ምክንያቱም ተመሳሳይ እሴት በ `a` እና `b` ስለሚጠቀስ ነው ፡፡
/////
///
///         // `tmp` ን ወደ `b` ውሰድ።
///         ptr::write(b, tmp);
///
///         // `tmp` ተንቀሳቅሷል (`write` የሁለተኛውን ክርክር ባለቤትነቱን ይወስዳል) ፣ ስለሆነም በተዘዋዋሪ እዚህ ምንም ነገር አልተጣለም።
/////
///     }
/// }
///
/// let mut foo = "foo".to_owned();
/// let mut bar = "bar".to_owned();
///
/// swap(&mut foo, &mut bar);
///
/// assert_eq!(foo, "bar");
/// assert_eq!(bar, "foo");
/// ```
///
/// ## የተመለሰው እሴት ባለቤትነት
///
/// `read` `T` [`Copy`] ቢሆንም የ `T` ን ትንሽ ቅጅ ይፈጥራል።
/// `T` [`Copy`] ካልሆነ የተመለሰውን እሴት እና በ `*src` ላይ ያለውን እሴት በመጠቀም የማህደረ ትውስታን ደህንነት ሊጥስ ይችላል።
/// በ `*src` ላይ ዋጋውን ለመጣል ስለሚሞክር ለ `* src` መመደብ እንደአጠቃቀም ይቆጥራል ፡፡
///
/// [`write()`] ውሂብ እንዲወድቅ ሳያደርግ እንደገና ለመጻፍ ሊያገለግል ይችላል።
///
/// ```
/// use std::ptr;
///
/// let mut s = String::from("foo");
/// unsafe {
///     // `s2` አሁን እንደ `s` ተመሳሳይ መሰረታዊ ማህደረ ትውስታን ያመለክታል።
///     let mut s2: String = ptr::read(&s);
///
///     assert_eq!(s2, "foo");
///
///     // ወደ `s2` መመደብ የመጀመሪያ እሴቱ እንዲወድቅ ያደርገዋል።
///     // ከዚህ በታች ያለው ነጥብ `s` ከአሁን በኋላ ጥቅም ላይ መዋል የለበትም ፣ ምክንያቱም መሠረታዊው ማህደረ ትውስታ ተለቋል።
/////
///     s2 = String::default();
///     assert_eq!(s2, "");
///
///     // ወደ `s` መመደብ አሮጌው እሴት እንደገና እንዲወድቅ ያደርገዋል ፣ ይህም ያልተገለጸ ባህሪ ያስከትላል።
/////
///     // ሰ= String::from("bar");//ስህተት
///
///     // `ptr::write` እሴቱን ሳይጥሉ እንደገና ለመጻፍ ሊያገለግል ይችላል።
///     ptr::write(&mut s, String::from("bar"));
/// }
///
/// assert_eq!(s, "bar");
/// ```
///
/// [valid]: self#safety
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
pub const unsafe fn read<T>(src: *const T) -> T {
    let mut tmp = MaybeUninit::<T>::uninit();
    // ደህንነት-ደዋዩ `src` ለንባብ የሚሰራ መሆኑን ዋስትና መስጠት አለበት ፡፡
    // `src` X0 `tmp` ን መደራረብ አይችልም ምክንያቱም `tmp` ልክ እንደ የተለየ የተመደበ ነገር በቁጥሩ ላይ ተመድቧል።
    //
    //
    // እንዲሁም ልክ ዋጋን ወደ `tmp` ስለፃፍነው በትክክል ለመነሳቱ ዋስትና ይሰጣል ፡፡
    //
    unsafe {
        copy_nonoverlapping(src, tmp.as_mut_ptr(), 1);
        tmp.assume_init()
    }
}

/// እሴቱን ሳይያንቀሳቅስ ከ `src` ያነባል።ይህ በ `src` ውስጥ ማህደረ ትውስታውን ሳይለወጥ ይቀረዋል።
///
/// ከ [`read`] በተለየ መልኩ `read_unaligned` ባልተመሳሰሉ ጠቋሚዎች ይሠራል ፡፡
///
/// # Safety
///
/// ከሚከተሉት ሁኔታዎች ውስጥ አንዳቸውም ቢጣሱ ባህሪይ አልተገለጸም-
///
/// * `src` ለማንበብ [valid] መሆን አለበት።
///
/// * `src` በትክክል ለተጀመረው የ `T` ዓይነት መጠቆም አለበት።
///
/// እንደ [`read`] ፣ `read_unaligned` `T` [`Copy`] ቢሆንም የ `T` ን ትንሽ ቅጅ ይፈጥራል።
/// `T` [`Copy`] ካልሆነ የተመለሰውን እሴት እና እሴቱን በ `*src` በመጠቀም [violate memory safety][read-ownership] ይችላል።
///
/// `T` መጠን `0` ያለው እንኳ ቢሆን, የ ጠቋሚ ያልሆኑ አልቦ መሆን እንዳለበት ልብ በል.
///
/// [read-ownership]: read#ownership-of-the-returned-value
/// [valid]: self#safety
///
/// ## በ `packed` structs ላይ
///
/// የታሸጉ መዋቅሮች ላልተመሳሰሉ መስኮች ጥሬ ጠቋሚዎችን ለመፍጠር በአሁኑ ጊዜ የማይቻል ነው ፡፡
///
/// እንደ `&packed.unaligned as *const FieldType` ያለ አገላለጽ ጥሬ ጠቋሚ ወደ `unaligned` መዋቅራዊ መስክ ለመፍጠር መሞከር ያንን ወደ ጥሬ ጠቋሚው ከመቀየርዎ በፊት መካከለኛ ያልተመሳሰለ ማጣቀሻ ይፈጥራል።
///
/// አሰባሳቢው ሁልጊዜ ማጣቀሻዎች በትክክል እንዲጣጣሙ ስለሚጠብቅ ይህ ማጣቀሻ ጊዜያዊ እና ወዲያውኑ ይጣላል የማይጠቅም ነው ፡፡
/// በዚህ ምክንያት `&packed.unaligned as *const FieldType` ን በመጠቀም በፕሮግራምዎ ውስጥ ወዲያውኑ* ያልተገለጸ ባህሪ * ያስከትላል።
///
/// ምን ማድረግ እንደሌለብዎት እና ይህ ከ `read_unaligned` ጋር እንዴት እንደሚዛመድ ምሳሌ ነው:
///
/// ```no_run
/// #[repr(packed, C)]
/// struct Packed {
///     _padding: u8,
///     unaligned: u32,
/// }
///
/// let packed = Packed {
///     _padding: 0x00,
///     unaligned: 0x01020304,
/// };
///
/// let v = unsafe {
///     // እዚህ ያልተስተካከለ የ 32 ቢት ኢንቲጀር አድራሻ ለመውሰድ እንሞክራለን ፡፡
///     let unaligned =
///         // ማጣቀሻ ቢጠቀምም ባይጠቀምም ጊዜያዊ ያልተስተካከለ ማጣቀሻ እዚህ ተፈጥሯል ፡፡
/////
///         &packed.unaligned
///         // ወደ ጥሬ ጠቋሚ መወርወር አያዋጣም;ስህተቱ ቀድሞውኑ ተከስቷል ፡፡
///         as *const u32;
///
///     let v = std::ptr::read_unaligned(unaligned);
///
///     v
/// };
/// ```
///
/// ያልተመደቡ መስኮችን ለምሳሌ ከ `packed.unaligned` ጋር በቀጥታ መድረስ ደህንነቱ የተጠበቀ ነው ፡፡
///
///
///
///
///
///
// FIXME: በ RFC #2582 እና በጓደኞች ውጤት ላይ በመመርኮዝ ሰነዶች ያዘምኑ።
/// # Examples
///
/// ከአንድ የባይት ቋት ጥቅም ላይ የዋለ ዋጋን ያንብቡ
///
/// ```
/// use std::mem;
///
/// fn read_usize(x: &[u8]) -> usize {
///     assert!(x.len() >= mem::size_of::<usize>());
///
///     let ptr = x.as_ptr() as *const usize;
///
///     unsafe { ptr.read_unaligned() }
/// }
/// ```
#[inline]
#[stable(feature = "ptr_unaligned", since = "1.17.0")]
#[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
pub const unsafe fn read_unaligned<T>(src: *const T) -> T {
    let mut tmp = MaybeUninit::<T>::uninit();
    // ደህንነት-ደዋዩ `src` ለንባብ የሚሰራ መሆኑን ዋስትና መስጠት አለበት ፡፡
    // `src` X0 `tmp` ን መደራረብ አይችልም ምክንያቱም `tmp` ልክ እንደ የተለየ የተመደበ ነገር በቁጥሩ ላይ ተመድቧል።
    //
    //
    // እንዲሁም ልክ ዋጋን ወደ `tmp` ስለፃፍነው በትክክል ለመነሳቱ ዋስትና ይሰጣል ፡፡
    //
    unsafe {
        copy_nonoverlapping(src as *const u8, tmp.as_mut_ptr() as *mut u8, mem::size_of::<T>());
        tmp.assume_init()
    }
}

/// የድሮውን እሴት ሳያነቡ ወይም ሳይጥሉ በተሰጠው እሴት የመታሰቢያ ቦታን ይሽራል።
///
/// `write` የ `dst` ይዘቶችን አይጥልም።
/// ይህ ደህንነቱ የተጠበቀ ነው ፣ ነገር ግን ምደባዎችን ወይም ሀብቶችን ሊያፈስ ይችላል ፣ ስለሆነም መጣል ያለበት ነገር እንዳይጽፍ ጥንቃቄ መደረግ አለበት።
///
///
/// በተጨማሪም ፣ `src` ን አይጥልም።በቅደም ተከተል ፣ `src` በ `dst` በተጠቆመው ቦታ ተወስዷል።
///
/// ይህ ያልታወቀ ማህደረ ትውስታን ለማስጀመር ወይም ቀደም ሲል [`read`] ከነበረ ማህደረ ትውስታን እንደገና ለመጻፍ ተገቢ ነው።
///
/// # Safety
///
/// ከሚከተሉት ሁኔታዎች ውስጥ አንዳቸውም ቢጣሱ ባህሪይ አልተገለጸም-
///
/// * `dst` ለመፃፍ [valid] መሆን አለበት።
///
/// * `dst` በትክክል መመሳሰል አለበት።ጉዳዩ ይህ ካልሆነ [`write_unaligned`] ን ይጠቀሙ።
///
/// `T` መጠን `0` ያለው እንኳ ቢሆን, የ ጠቋሚ ያልሆኑ አልቦ እና በአግባቡ የሚጣጣም መሆን እንዳለበት ልብ በል.
///
/// [valid]: self#safety
///
/// # Examples
///
/// መሠረታዊ አጠቃቀም
///
/// ```
/// let mut x = 0;
/// let y = &mut x as *mut i32;
/// let z = 12;
///
/// unsafe {
///     std::ptr::write(y, z);
///     assert_eq!(std::ptr::read(y), 12);
/// }
/// ```
///
/// [`mem::swap`] ን በእጅ ይተግብሩ:
///
/// ```
/// use std::ptr;
///
/// fn swap<T>(a: &mut T, b: &mut T) {
///     unsafe {
///         // በ `tmp` ውስጥ በ `a` ላይ እሴቱን ትንሽ አቅጣጫዊ ቅጅ ይፍጠሩ።
///         let tmp = ptr::read(a);
///
///         // ከዚህ ቦታ መውጣት (በግልፅ በመመለስ ወይም የ panics ተግባርን በመጥራት) በ `tmp` ውስጥ ያለው እሴት እንዲወድቅ ያደርገዋል ፣ አሁንም ተመሳሳይ እሴት በ `a` እየተጣቀሰ።
///         // `T` `Copy` ካልሆነ ይህ ያልተገለጸ ባህሪን ሊያስነሳ ይችላል።
/////
/////
///
///         // በ `a` ውስጥ በ `b` ላይ እሴቱን ትንሽ አቅጣጫዊ ቅጅ ይፍጠሩ።
///         // የሚለዋወጥ ማጣቀሻዎች ቅጽል ሊሆኑ ስለማይችሉ ይህ ደህንነቱ የተጠበቀ ነው።
///         ptr::copy_nonoverlapping(b, a, 1);
///
///         // ከላይ እንደተጠቀሰው ፣ እዚህ መውጣቱ ያልታወቀ ባህሪን ሊያስነሳ ይችላል ምክንያቱም ተመሳሳይ እሴት በ `a` እና `b` ስለሚጠቀስ ነው ፡፡
/////
///
///         // `tmp` ን ወደ `b` ውሰድ።
///         ptr::write(b, tmp);
///
///         // `tmp` ተንቀሳቅሷል (`write` የሁለተኛውን ክርክር ባለቤትነቱን ይወስዳል) ፣ ስለሆነም በተዘዋዋሪ እዚህ ምንም ነገር አልተጣለም።
/////
///     }
/// }
///
/// let mut foo = "foo".to_owned();
/// let mut bar = "bar".to_owned();
///
/// swap(&mut foo, &mut bar);
///
/// assert_eq!(foo, "bar");
/// assert_eq!(bar, "foo");
/// ```
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn write<T>(dst: *mut T, src: T) {
    // `intrinsics::copy_nonoverlapping` መጠቅለያ ተግባር በመሆኑ በተፈጠረው ኮድ ውስጥ የተግባር ጥሪዎችን ለማስወገድ በቀጥታ ዋናዎቹን እንጠራቸዋለን ፡፡
    //
    extern "rust-intrinsic" {
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // ደህንነት-ደዋዩ `dst` ለመፃፍ ልክ መሆኑን ማረጋገጥ አለበት ፡፡
    // `dst` `src` ን መደራረብ አይችልም ምክንያቱም ደዋዩ ወደ `dst` የሚለዋወጥ ተደራሽነት አለው ፣ `src` ደግሞ የዚህ ተግባር ባለቤት ነው።
    //
    unsafe {
        copy_nonoverlapping(&src as *const T, dst, 1);
        intrinsics::forget(src);
    }
}

/// የድሮውን እሴት ሳያነቡ ወይም ሳይጥሉ በተሰጠው እሴት የመታሰቢያ ቦታን ይሽራል።
///
/// እንደ [`write()`] ሳይሆን ጠቋሚው ያልተስተካከለ ሊሆን ይችላል።
///
/// `write_unaligned` የ `dst` ይዘቶችን አይጥልም።ይህ ደህንነቱ የተጠበቀ ነው ፣ ነገር ግን ምደባዎችን ወይም ሀብቶችን ሊያፈስ ይችላል ፣ ስለሆነም መጣል ያለበት ነገር እንዳይጽፍ ጥንቃቄ መደረግ አለበት።
///
/// በተጨማሪም ፣ `src` ን አይጥልም።በቅደም ተከተል ፣ `src` በ `dst` በተጠቆመው ቦታ ተወስዷል።
///
/// ይህ ያልታወቀ ማህደረ ትውስታን ለማስጀመር ወይም ቀደም ሲል ከ [`read_unaligned`] ጋር የተነበበ ማህደረ ትውስታን ለመጻፍ ተገቢ ነው።
///
/// # Safety
///
/// ከሚከተሉት ሁኔታዎች ውስጥ አንዳቸውም ቢጣሱ ባህሪይ አልተገለጸም-
///
/// * `dst` ለመፃፍ [valid] መሆን አለበት።
///
/// `T` መጠን `0` ያለው እንኳ ቢሆን, የ ጠቋሚ ያልሆኑ አልቦ መሆን እንዳለበት ልብ በል.
///
/// [valid]: self#safety
///
/// ## በ `packed` structs ላይ
///
/// የታሸጉ መዋቅሮች ላልተመሳሰሉ መስኮች ጥሬ ጠቋሚዎችን ለመፍጠር በአሁኑ ጊዜ የማይቻል ነው ፡፡
///
/// እንደ `&packed.unaligned as *const FieldType` ያለ አገላለጽ ጥሬ ጠቋሚ ወደ `unaligned` መዋቅራዊ መስክ ለመፍጠር መሞከር ያንን ወደ ጥሬ ጠቋሚው ከመቀየርዎ በፊት መካከለኛ ያልተመሳሰለ ማጣቀሻ ይፈጥራል።
///
/// አሰባሳቢው ሁልጊዜ ማጣቀሻዎች በትክክል እንዲጣጣሙ ስለሚጠብቅ ይህ ማጣቀሻ ጊዜያዊ እና ወዲያውኑ ይጣላል የማይጠቅም ነው ፡፡
/// በዚህ ምክንያት `&packed.unaligned as *const FieldType` ን በመጠቀም በፕሮግራምዎ ውስጥ ወዲያውኑ* ያልተገለጸ ባህሪ * ያስከትላል።
///
/// ምን ማድረግ እንደሌለብዎት እና ይህ ከ `write_unaligned` ጋር እንዴት እንደሚዛመድ ምሳሌ ነው:
///
/// ```no_run
/// #[repr(packed, C)]
/// struct Packed {
///     _padding: u8,
///     unaligned: u32,
/// }
///
/// let v = 0x01020304;
/// let mut packed: Packed = unsafe { std::mem::zeroed() };
///
/// let v = unsafe {
///     // እዚህ ያልተስተካከለ የ 32 ቢት ኢንቲጀር አድራሻ ለመውሰድ እንሞክራለን ፡፡
///     let unaligned =
///         // ማጣቀሻ ቢጠቀምም ባይጠቀምም ጊዜያዊ ያልተስተካከለ ማጣቀሻ እዚህ ተፈጥሯል ፡፡
/////
///         &mut packed.unaligned
///         // ወደ ጥሬ ጠቋሚ መወርወር አያዋጣም;ስህተቱ ቀድሞውኑ ተከስቷል ፡፡
///         as *mut u32;
///
///     std::ptr::write_unaligned(unaligned, v);
///
///     v
/// };
/// ```
///
/// ያልተመደቡ መስኮችን ለምሳሌ ከ `packed.unaligned` ጋር በቀጥታ መድረስ ደህንነቱ የተጠበቀ ነው ፡፡
///
///
///
///
///
///
///
///
///
// FIXME: በ RFC #2582 እና በጓደኞች ውጤት ላይ በመመርኮዝ ሰነዶች ያዘምኑ።
/// # Examples
///
/// ወደ ባይት ቋት (usize) እሴት ይፃፉ
///
/// ```
/// use std::mem;
///
/// fn write_usize(x: &mut [u8], val: usize) {
///     assert!(x.len() >= mem::size_of::<usize>());
///
///     let ptr = x.as_mut_ptr() as *mut usize;
///
///     unsafe { ptr.write_unaligned(val) }
/// }
/// ```
#[inline]
#[stable(feature = "ptr_unaligned", since = "1.17.0")]
#[rustc_const_unstable(feature = "const_ptr_write", issue = "none")]
pub const unsafe fn write_unaligned<T>(dst: *mut T, src: T) {
    // ደህንነት-ደዋዩ `dst` ለመፃፍ ልክ መሆኑን ማረጋገጥ አለበት ፡፡
    // `dst` `src` ን መደራረብ አይችልም ምክንያቱም ደዋዩ ወደ `dst` የሚለዋወጥ ተደራሽነት አለው ፣ `src` ደግሞ የዚህ ተግባር ባለቤት ነው።
    //
    unsafe {
        copy_nonoverlapping(&src as *const T as *const u8, dst as *mut u8, mem::size_of::<T>());
        // በተፈጠረው ኮድ ውስጥ የተግባር ጥሪዎችን ለማስቀረት በቀጥታ ውስጣዊውን እየጠራን ነው ፡፡
        intrinsics::forget(src);
    }
}

/// እሴቱን ሳይንቀሳቀስ ከ `src` ዋጋ ያለው ተለዋዋጭ ንባብ ያካሂዳል።ይህ በ `src` ውስጥ ማህደረ ትውስታውን ሳይለወጥ ይቀረዋል።
///
/// ተለዋዋጭ ተግባራት በ I/O ማህደረ ትውስታ ላይ እንዲሠሩ የታሰቡ ናቸው ፣ እና በሌሎች ተለዋዋጭ ተግባራት ላይ በአቀራባሪው እንዳይጎበኙ ወይም እንደገና እንዳይመደቡ የተረጋገጠ ነው።
///
/// # Notes
///
/// Rust በአሁኑ ጊዜ በጥብቅ እና በመደበኛነት የተቀመጠ የማስታወሻ ሞዴል የለውም ፣ ስለሆነም "volatile" እዚህ ምን ማለት እንደሆነ ትክክለኛ ፍቺዎች በጊዜ ሂደት ሊለወጡ ይችላሉ።
/// ይህ እንዳለ ሆኖ ፣ ሥነ-ፍቺው ሁልጊዜ ማለት ይቻላል ከ‹XXXX›ጋር ተመሳሳይ ይሆናል።
///
/// አጠናቃሪው አንጻራዊ ቅደም ተከተል ወይም ተለዋዋጭ ተለዋዋጭ የማስታወሻ ሥራዎችን ቁጥር መለወጥ የለበትም ፡፡
/// ሆኖም ፣ በዜሮ መጠን ዓይነቶች ላይ ተለዋዋጭ ተለዋዋጭ የማስታወስ ሥራዎች (ለምሳሌ ፣ ዜሮ መጠን ወደ `read_volatile` ከተላለፈ) ድንገተኛዎች ናቸው እና ችላ ሊባሉ ይችላሉ ፡፡
///
/// [c11]: http://www.open-std.org/jtc1/sc22/wg14/www/docs/n1570.pdf
///
/// # Safety
///
/// ከሚከተሉት ሁኔታዎች ውስጥ አንዳቸውም ቢጣሱ ባህሪይ አልተገለጸም-
///
/// * `src` ለማንበብ [valid] መሆን አለበት።
///
/// * `src` በትክክል መመሳሰል አለበት።
///
/// * `src` በትክክል ለተጀመረው የ `T` ዓይነት መጠቆም አለበት።
///
/// እንደ [`read`] ፣ `read_volatile` `T` [`Copy`] ቢሆንም የ `T` ን ትንሽ ቅጅ ይፈጥራል።
/// `T` [`Copy`] ካልሆነ የተመለሰውን እሴት እና እሴቱን በ `*src` በመጠቀም [violate memory safety][read-ownership] ይችላል።
/// ሆኖም በሚለዋወጥ ማህደረ ትውስታ ውስጥ [`Copy`] ያልሆኑትን ዓይነቶች ማከማቸት በእርግጥ ትክክል አይደለም ፡፡
///
/// `T` መጠን `0` ያለው እንኳ ቢሆን, የ ጠቋሚ ያልሆኑ አልቦ እና በአግባቡ የሚጣጣም መሆን እንዳለበት ልብ በል.
///
/// [valid]: self#safety
/// [read-ownership]: read#ownership-of-the-returned-value
///
/// ልክ በ‹C›ውስጥ ፣ አንድ ክዋኔ ተለዋዋጭ ቢሆንም ከበርካታ ክሮች በተመሳሳይ ተደራሽነት ላይ ለሚነሱ ጥያቄዎች ምንም ፋይዳ የለውም ፡፡ተለዋዋጭ ፈላጊዎች በዚያ ረገድ አቶሚክ ያልሆኑ መዳረሻዎችን ልክ ያደርጋሉ ፡፡
///
/// በተለይም በ‹XXXX›እና በማንኛውም የጽሑፍ ሥራ መካከል ወደ ተመሳሳይ ሥፍራ የሚደረግ ውድድር ያልተገለጸ ባህሪ ነው ፡፡
///
/// # Examples
///
/// መሠረታዊ አጠቃቀም
///
/// ```
/// let x = 12;
/// let y = &x as *const i32;
///
/// unsafe {
///     assert_eq!(std::ptr::read_volatile(y), 12);
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "volatile", since = "1.9.0")]
pub unsafe fn read_volatile<T>(src: *const T) -> T {
    if cfg!(debug_assertions) && !is_aligned_and_not_null(src) {
        // የኮዴጌን ተፅእኖ አነስተኛ እንዲሆን ላለመደናገጥ ፡፡
        abort();
    }
    // ደህንነት-ደዋዩ ለ `volatile_load` የደህንነትን ውል ማክበር አለበት ፡፡
    unsafe { intrinsics::volatile_load(src) }
}

/// የድሮውን እሴት ሳያነቡ ወይም ሳይጥሉ ከተሰጠው እሴት ጋር የመታሰቢያ ቦታን ተለዋዋጭ ተለዋዋጭ ጽሑፍን ያካሂዳል።
///
/// ተለዋዋጭ ተግባራት በ I/O ማህደረ ትውስታ ላይ እንዲሠሩ የታሰቡ ናቸው ፣ እና በሌሎች ተለዋዋጭ ተግባራት ላይ በአቀራባሪው እንዳይጎበኙ ወይም እንደገና እንዳይመደቡ የተረጋገጠ ነው።
///
/// `write_volatile` የ `dst` ይዘቶችን አይጥልም።ይህ ደህንነቱ የተጠበቀ ነው ፣ ነገር ግን ምደባዎችን ወይም ሀብቶችን ሊያፈስ ይችላል ፣ ስለሆነም መጣል ያለበት ነገር እንዳይጽፍ ጥንቃቄ መደረግ አለበት።
///
/// በተጨማሪም ፣ `src` ን አይጥልም።በቅደም ተከተል ፣ `src` በ `dst` በተጠቆመው ቦታ ተወስዷል።
///
/// # Notes
///
/// Rust በአሁኑ ጊዜ በጥብቅ እና በመደበኛነት የተቀመጠ የማስታወሻ ሞዴል የለውም ፣ ስለሆነም "volatile" እዚህ ምን ማለት እንደሆነ ትክክለኛ ፍቺዎች በጊዜ ሂደት ሊለወጡ ይችላሉ።
/// ይህ እንዳለ ሆኖ ፣ ሥነ-ፍቺው ሁልጊዜ ማለት ይቻላል ከ‹XXXX›ጋር ተመሳሳይ ይሆናል።
///
/// አጠናቃሪው አንጻራዊ ቅደም ተከተል ወይም ተለዋዋጭ ተለዋዋጭ የማስታወሻ ሥራዎችን ቁጥር መለወጥ የለበትም ፡፡
/// ሆኖም ፣ በዜሮ መጠን ዓይነቶች ላይ ተለዋዋጭ ተለዋዋጭ የማስታወስ ሥራዎች (ለምሳሌ ፣ ዜሮ መጠን ወደ `write_volatile` ከተላለፈ) ድንገተኛዎች ናቸው እና ችላ ሊባሉ ይችላሉ ፡፡
///
/// [c11]: http://www.open-std.org/jtc1/sc22/wg14/www/docs/n1570.pdf
///
/// # Safety
///
/// ከሚከተሉት ሁኔታዎች ውስጥ አንዳቸውም ቢጣሱ ባህሪይ አልተገለጸም-
///
/// * `dst` ለመፃፍ [valid] መሆን አለበት።
///
/// * `dst` በትክክል መመሳሰል አለበት።
///
/// `T` መጠን `0` ያለው እንኳ ቢሆን, የ ጠቋሚ ያልሆኑ አልቦ እና በአግባቡ የሚጣጣም መሆን እንዳለበት ልብ በል.
///
/// [valid]: self#safety
///
/// ልክ በ‹C›ውስጥ ፣ አንድ ክዋኔ ተለዋዋጭ ቢሆንም ከበርካታ ክሮች በተመሳሳይ ተደራሽነት ላይ ለሚነሱ ጥያቄዎች ምንም ፋይዳ የለውም ፡፡ተለዋዋጭ ፈላጊዎች በዚያ ረገድ አቶሚክ ያልሆኑ መዳረሻዎችን ልክ ያደርጋሉ ፡፡
///
/// በተለይም በተመሳሳይ ቦታ ላይ በ `write_volatile` እና በሌላ በማንኛውም ክወና (ንባብ ወይም ጽሑፍ) መካከል የሚደረግ ውድድር ያልተገለጸ ባህሪ ነው ፡፡
///
/// # Examples
///
/// መሠረታዊ አጠቃቀም
///
/// ```
/// let mut x = 0;
/// let y = &mut x as *mut i32;
/// let z = 12;
///
/// unsafe {
///     std::ptr::write_volatile(y, z);
///     assert_eq!(std::ptr::read_volatile(y), 12);
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "volatile", since = "1.9.0")]
pub unsafe fn write_volatile<T>(dst: *mut T, src: T) {
    if cfg!(debug_assertions) && !is_aligned_and_not_null(dst) {
        // የኮዴጌን ተፅእኖ አነስተኛ እንዲሆን ላለመደናገጥ ፡፡
        abort();
    }
    // ደህንነት-ደዋዩ ለ `volatile_store` የደህንነትን ውል ማክበር አለበት ፡፡
    unsafe {
        intrinsics::volatile_store(dst, src);
    }
}

/// ጠቋሚ `p` ን ያስተካክሉ።
///
/// አመላካች `p` ከ `a` ጋር እንዲመሳሰል በጠቋሚ `p` ላይ መተግበር ያለበት ማካካሻ (የ `stride` እርምጃ አካላት አንፃር) ያስሉ።
///
/// Note: ይህ ትግበራ ከ panic ላለመሆን በጥንቃቄ ተስተካክሏል ፡፡ለዚህ ለ panic ዩቢ ነው ፡፡
/// እዚህ ሊደረግ የሚችለው ብቸኛው እውነተኛ ለውጥ የ `INV_TABLE_MOD_16` እና ተጓዳኝ ቋሚዎች ለውጥ ነው።
///
/// የሁለት-ኃይል ያልሆነውን XXXXXXXXXXXXXXXXXXXXXXX ለመጥራት ከቻልን ፣ ያንን ለውጥ ለማመቻቸት ይህንን ለማስተካከል ከመሞከር ይልቅ ወደ የዋህ አተገባበር ብቻ መለወጥ የበለጠ አስተዋይ ሊሆን ይችላል ፡፡
///
///
/// ማንኛውም ጥያቄ ወደ@ናጊሳ ይሄዳል ፡፡
///
///
///
#[lang = "align_offset"]
pub(crate) unsafe fn align_offset<T: Sized>(p: *const T, a: usize) -> usize {
    // FIXME(#75598): የእነዚህ ውስጣዊ ነገሮች ቀጥተኛ አጠቃቀም በኮዴጌን በ‹opt-level›በከፍተኛ ደረጃ ያሻሽላል
    // 1, የእነዚህ ክዋኔዎች ዘዴ ስሪቶች ያልተዘረዘሩበት ፡፡
    use intrinsics::{
        unchecked_shl, unchecked_shr, unchecked_sub, wrapping_add, wrapping_mul, wrapping_sub,
    };

    /// የ `x` ሞዱሎ `m` የተባዛ ሞዱል የተገላቢጦሽ አስላ።
    ///
    /// ይህ ትግበራ ለ‹`align_offset` X›የተስተካከለ እና የሚከተሉትን ቅድመ-ሁኔታዎች አሉት ፡፡
    ///
    /// * `m` የሁለት-ኃይል ነው;
    /// * `x < m`; (`x ≥ m` ከሆነ በምትኩ በ `x % m` ውስጥ ይለፉ)
    ///
    /// የዚህ ተግባር አተገባበር panic አይሆንም።መቼም።
    #[inline]
    unsafe fn mod_inv(x: usize, m: usize) -> usize {
        /// ሁለገብ ሞዱል የተገላቢጦሽ ሰንጠረዥ ሞዱሎ 2⁴=16።
        ///
        /// ማስታወሻ ፣ ይህ ሰንጠረዥ ተገላቢጦሽ የሌላቸውን እሴቶች የለውም (ማለትም ፣ ለ `0⁻¹ mod 16` ፣ `2⁻¹ mod 16` ፣ ወዘተ)
        ///
        const INV_TABLE_MOD_16: [u8; 8] = [1, 11, 13, 7, 9, 3, 5, 15];
        /// `INV_TABLE_MOD_16` የታሰበበት ሞዱሎ።
        const INV_TABLE_MOD: usize = 16;
        /// INV_TABLE_MOD²
        const INV_TABLE_MOD_SQUARED: usize = INV_TABLE_MOD * INV_TABLE_MOD;

        let table_inverse = INV_TABLE_MOD_16[(x & (INV_TABLE_MOD - 1)) >> 1] as usize;
        // ደህንነት-`m` የሁለት-ኃይል መሆን ይጠበቅበታል ፣ ስለሆነም ዜሮ ያልሆነ።
        let m_minus_one = unsafe { unchecked_sub(m, 1) };
        if m <= INV_TABLE_MOD {
            table_inverse & m_minus_one
        } else {
            // የሚከተለውን ቀመር በመጠቀም "up" ን እናስተካክላለን
            //
            // $$ xy ≡ 1 (ሞድ 2ⁿ) → xy (2 ፣ xy) ≡ 1 (ሞድ 2²ⁿ) $$
            //
            // እስከ 2²ⁿ ≥ ሜትር.ውጤቱን `mod m` ን በመውሰድ ወደ ተፈለገው `m` መቀነስ እንችላለን ፡፡
            let mut inverse = table_inverse;
            let mut going_mod = INV_TABLE_MOD_SQUARED;
            loop {
                // y=y * (2, xy) ሞድ n
                //
                // ልብ ይበሉ ፣ እዚህ ሆን ብለን የመጠቅለያ ሥራዎችን እንጠቀማለን-የመጀመሪያው ቀመር ለምሳሌ ፣ መቀነስ `mod n` ይጠቀማል።
                // በምትኩ እነሱን `mod usize::MAX` ማድረጉ ሙሉ በሙሉ ጥሩ ነው ፣ ምክንያቱም ውጤቱን ለማንኛውም መጨረሻ `mod n` እንወስዳለን ፡፡
                //
                //
                inverse = wrapping_mul(inverse, wrapping_sub(2usize, wrapping_mul(x, inverse)));
                if going_mod >= m {
                    return inverse & m_minus_one;
                }
                going_mod = wrapping_mul(going_mod, going_mod);
            }
        }
    }

    let stride = mem::size_of::<T>();
    // ደህንነት `a` የሁለት-ኃይል ነው ፣ ስለሆነም ዜሮ ያልሆነ።
    let a_minus_one = unsafe { unchecked_sub(a, 1) };
    if stride == 1 {
        // `stride == 1` ኬዝ በ `-p (mod a)` በኩል በቀላሉ በቀላሉ ሊቆጠር ይችላል ፣ ግን ይህን ማድረጉ የ LLVM ን እንደ `lea` ያሉ መመሪያዎችን የመምረጥ ችሎታን ይከለክላል።በምትኩ እኛ እናሰላለን
        //
        //    round_up_to_next_alignment(p, a) - p
        //
        // ጭነት በሚሸከምበት ዙሪያ ስራዎችን የሚያሰራጭ ፣ ግን LLVM ን የሚያውቅባቸውን የተለያዩ ማበረታቻዎችን ለመጠቀም እንዲችል `and` ን በበቂ ሁኔታ መገመት ይችላል ፡፡
        //
        //
        return wrapping_sub(
            wrapping_add(p as usize, a_minus_one) & wrapping_sub(0, a),
            p as usize,
        );
    }

    let pmoda = p as usize & a_minus_one;
    if pmoda == 0 {
        // ቀድሞውኑ ተሰል .ልአዎ!
        return 0;
    } else if stride == 0 {
        // ጠቋሚው ካልተሰለፈ እና ንጥረ ነገሩ ዜሮ-መጠን ካለው ፣ ከዚያ ምንም ጠቋሚዎች ጠቋሚውን በጭራሽ አያሰምሩትም።
        //
        return usize::MAX;
    }

    let smoda = stride & a_minus_one;
    // ደህንነት-ሀ-የሁለት ነው ስለሆነም ዜሮ ያልሆነ ፡፡እርምጃ==0 ጉዳይ ከላይ ተስተናግዷል ፡፡
    let gcdpow = unsafe { intrinsics::cttz_nonzero(stride).min(intrinsics::cttz_nonzero(a)) };
    // ደህንነት gcdpow በአሜሪካን ቢዝነስ ውስጥ ቢት ቢቶች ቢበዛ የላይኛው ድንበር አለው ፡፡
    let gcd = unsafe { unchecked_shl(1usize, gcdpow) };

    // ደህንነት ሁል ጊዜ ሲሲዲ ይበልጣል ወይም ከ 1 ጋር እኩል ነው ፡፡
    if p as usize & unsafe { unchecked_sub(gcd, 1) } == 0 {
        // ይህ branch ለሚከተለው መስመራዊ የመገጣጠም እኩልታን ይፈታል-
        //
        // ` p + so = 0 mod a `
        //
        // `p` የጠቋሚው እሴት ፣ `s` ፣ የ‹`T` X›ፍጥነት ፣ በ‹T›ውስጥ የ `o` ማካካሻ እና የተጠየቀው አሰላለፍ `a` ነው ፡፡
        //
        // `g = gcd(a, s)`, እና `p` ደግሞ `g` በ divisible መሆኑን በክሱ ከላይ ሁኔታ ጋር, እኛ `a' = a/g`, `s' = s/g`, `p' = p/g`, ከዚያም ከዚህ ጋር እኩል ይሆናል ሊያመለክት ይችላል:
        //
        // ` p' + s'o = 0 mod a' `
        // ` o = (a' - (p' mod a')) * (s'^-1 mod a') `
        //
        // የመጀመሪያው ቃል "the relative alignment of `p` to `a`" ነው (በ `g` ተከፍሏል) ፣ ሁለተኛው ቃል "how does incrementing `p` by `s` bytes change the relative alignment of `p`" ነው (እንደገና በ `g` ተከፍሏል)።
        //
        // `a` እና `s` ተባባሪ ካልሆኑ የተገላቢጦሹን በጥሩ ሁኔታ ለመፍጠር በ `g` መከፋፈል አስፈላጊ ነው ፡፡
        //
        // በተጨማሪም በዚህ መፍትሔ የተፈጠረው ውጤት "minimal" ስላልሆነ ውጤቱን `o mod lcm(s, a)` መውሰድ ያስፈልጋል ፡፡`lcm(s, a)` ን በ `a'` ብቻ መተካት እንችላለን።
        //
        //
        //
        //
        //

        // ደህንነት `gcdpow` በ `a` ውስጥ ከሚከተሉት የ 0 ቢቶች ቁጥር ብዛት የማይበልጥ የላይኛው ወሰን አለው።
        //
        let a2 = unsafe { unchecked_shr(a, gcdpow) };
        // ደህንነት `a2` ዜሮ አይደለም።`a` ን በ `gcdpow` ማዛወር ማናቸውንም ከተዘጋጁት ቢቶች መለወጥ አይችልም
        // በ `a` (በትክክል አንድ አለው) ፡፡
        let a2minus1 = unsafe { unchecked_sub(a2, 1) };
        // ደህንነት `gcdpow` በ `a` ውስጥ ከሚከተሉት የ 0 ቢቶች ቁጥር ብዛት የማይበልጥ የላይኛው ወሰን አለው።
        //
        let s2 = unsafe { unchecked_shr(smoda, gcdpow) };
        // ደህንነት `gcdpow` በ 0 ቢት ከሚከተሉት ከሚከተሉት ቁጥር የማይበልጥ የላይኛው ወሰን አለው
        // `a`.
        // በተጨማሪም ፣ ቅነሳው ከመጠን በላይ መብለጥ አይችልም ፣ ምክንያቱም `a2 = a >> gcdpow` ሁልጊዜ ከ `(p % a) >> gcdpow` በጥብቅ ይበልጣል።
        let minusp2 = unsafe { unchecked_sub(a2, unchecked_shr(pmoda, gcdpow)) };
        // ደህንነት-`a2` ከላይ እንደተረጋገጠው የሁለት-ኃይል ነው ፡፡`s2` በጥብቅ ከ `a2` በታች ነው
        // ምክንያቱም `(s % a) >> gcdpow` በጥብቅ ከ `a >> gcdpow` በታች ነው።
        return wrapping_mul(minusp2, unsafe { mod_inv(s2, a2) }) & a2minus1;
    }

    // በጭራሽ ሊመጣጠን አልተቻለም።
    usize::MAX
}

/// ለእኩልነት ጥሬ ጠቋሚዎችን ያነፃፅራል ፡፡
///
/// ይህ የ `==` ኦፕሬተርን ከመጠቀም ጋር ተመሳሳይ ነው ፣ ግን ያነሰ አጠቃላይ-
/// ክርክሮቹ X0 `PartialEq` ን ተግባራዊ የሚያደርግ ነገር ሳይሆን `*const T` ጥሬ አመልካቾች መሆን አለባቸው።
///
/// ይህ የሚያመለክቱትን እሴቶች ከማወዳደር ይልቅ የ `&T` ዋቢዎችን (በተዘዋዋሪ ወደ `*const T` ያስገድዳል) በአድራሻቸው ለማነፃፀር ሊያገለግል ይችላል (ይህም የ `PartialEq for &T` አተገባበር የሚያደርገውን ነው) ፡፡
///
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let five = 5;
/// let other_five = 5;
/// let five_ref = &five;
/// let same_five_ref = &five;
/// let other_five_ref = &other_five;
///
/// assert!(five_ref == same_five_ref);
/// assert!(ptr::eq(five_ref, same_five_ref));
///
/// assert!(five_ref == other_five_ref);
/// assert!(!ptr::eq(five_ref, other_five_ref));
/// ```
///
/// ቁርጥራጮች እንዲሁ ከርዝመታቸው (ከስብ ጠቋሚዎች) ጋር ይነፃፀራሉ-
///
/// ```
/// let a = [1, 2, 3];
/// assert!(std::ptr::eq(&a[..3], &a[..3]));
/// assert!(!std::ptr::eq(&a[..2], &a[..3]));
/// assert!(!std::ptr::eq(&a[0..2], &a[1..3]));
/// ```
///
/// Traits እንዲሁ በመተግበሪያቸው ይነፃፀራሉ-
///
/// ```
/// #[repr(transparent)]
/// struct Wrapper { member: i32 }
///
/// trait Trait {}
/// impl Trait for Wrapper {}
/// impl Trait for i32 {}
///
/// let wrapper = Wrapper { member: 10 };
///
/// // ጠቋሚዎች እኩል አድራሻዎች አሏቸው ፡፡
/// assert!(std::ptr::eq(
///     &wrapper as *const Wrapper as *const u8,
///     &wrapper.member as *const i32 as *const u8
/// ));
///
/// // ነገሮች እኩል አድራሻዎች አሏቸው ፣ ግን `Trait` የተለያዩ አተገባበር አለው።
/// assert!(!std::ptr::eq(
///     &wrapper as &dyn Trait,
///     &wrapper.member as &dyn Trait,
/// ));
/// assert!(!std::ptr::eq(
///     &wrapper as &dyn Trait as *const dyn Trait,
///     &wrapper.member as &dyn Trait as *const dyn Trait,
/// ));
///
/// // ማጣቀሻውን ወደ `*const u8` መለወጥ በአድራሻ ይነፃፀራል።
/// assert!(std::ptr::eq(
///     &wrapper as &dyn Trait as *const dyn Trait as *const u8,
///     &wrapper.member as &dyn Trait as *const dyn Trait as *const u8,
/// ));
/// ```
///
///
#[stable(feature = "ptr_eq", since = "1.17.0")]
#[inline]
pub fn eq<T: ?Sized>(a: *const T, b: *const T) -> bool {
    a == b
}

/// ጥሬ ጠቋሚ ጠቋሚ ያድርጉ ፡፡
///
/// ይህ ከሚጠቆመው እሴት ይልቅ የ `&T` ማጣቀሻ (በተዘዋዋሪ ወደ `*const T` ያስገድዳል) በአድራሻው ለመሰብሰብ ሊያገለግል ይችላል (ይህ የ `Hash for &T` አተገባበር የሚያደርገው ነው) ፡፡
///
///
/// # Examples
///
/// ```
/// use std::collections::hash_map::DefaultHasher;
/// use std::hash::{Hash, Hasher};
/// use std::ptr;
///
/// let five = 5;
/// let five_ref = &five;
///
/// let mut hasher = DefaultHasher::new();
/// ptr::hash(five_ref, &mut hasher);
/// let actual = hasher.finish();
///
/// let mut hasher = DefaultHasher::new();
/// (five_ref as *const i32).hash(&mut hasher);
/// let expected = hasher.finish();
///
/// assert_eq!(actual, expected);
/// ```
///
#[stable(feature = "ptr_hash", since = "1.35.0")]
pub fn hash<T: ?Sized, S: hash::Hasher>(hashee: *const T, into: &mut S) {
    use crate::hash::Hash;
    hashee.hash(into);
}

// ለተግባሮች ጠቋሚዎች
macro_rules! fnptr_impls_safety_abi {
    ($FnTy: ty, $($Arg: ident),*) => {
        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> PartialEq for $FnTy {
            #[inline]
            fn eq(&self, other: &Self) -> bool {
                *self as usize == *other as usize
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> Eq for $FnTy {}

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> PartialOrd for $FnTy {
            #[inline]
            fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
                (*self as usize).partial_cmp(&(*other as usize))
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> Ord for $FnTy {
            #[inline]
            fn cmp(&self, other: &Self) -> Ordering {
                (*self as usize).cmp(&(*other as usize))
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> hash::Hash for $FnTy {
            fn hash<HH: hash::Hasher>(&self, state: &mut HH) {
                state.write_usize(*self as usize)
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> fmt::Pointer for $FnTy {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                // HACK: መካከለኛ አጠቃቀም እንደ አጠቃቀሙ ለአቪአር ያስፈልጋል
                // የመነሻ ተግባር ጠቋሚው የአድራሻ ቦታ በመጨረሻው የአመልካች ጠቋሚ ውስጥ ተጠብቆ እንዲቆይ ፡፡
                //
                //
                // https://github.com/avr-rust/rust/issues/143
                fmt::Pointer::fmt(&(*self as usize as *const ()), f)
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> fmt::Debug for $FnTy {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                // HACK: መካከለኛ አጠቃቀም እንደ አጠቃቀሙ ለአቪአር ያስፈልጋል
                // የመነሻ ተግባር ጠቋሚው የአድራሻ ቦታ በመጨረሻው የአመልካች ጠቋሚ ውስጥ ተጠብቆ እንዲቆይ ፡፡
                //
                //
                // https://github.com/avr-rust/rust/issues/143
                fmt::Pointer::fmt(&(*self as usize as *const ()), f)
            }
        }
    }
}

macro_rules! fnptr_impls_args {
    ($($Arg: ident),+) => {
        fnptr_impls_safety_abi! { extern "Rust" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { extern "C" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { extern "C" fn($($Arg),+ , ...) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "Rust" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "C" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "C" fn($($Arg),+ , ...) -> Ret, $($Arg),+ }
    };
    () => {
        // ከ 0 መለኪያዎች ጋር ልዩ ልዩ ተግባራት የሉም
        fnptr_impls_safety_abi! { extern "Rust" fn() -> Ret, }
        fnptr_impls_safety_abi! { extern "C" fn() -> Ret, }
        fnptr_impls_safety_abi! { unsafe extern "Rust" fn() -> Ret, }
        fnptr_impls_safety_abi! { unsafe extern "C" fn() -> Ret, }
    };
}

fnptr_impls_args! {}
fnptr_impls_args! { A }
fnptr_impls_args! { A, B }
fnptr_impls_args! { A, B, C }
fnptr_impls_args! { A, B, C, D }
fnptr_impls_args! { A, B, C, D, E }
fnptr_impls_args! { A, B, C, D, E, F }
fnptr_impls_args! { A, B, C, D, E, F, G }
fnptr_impls_args! { A, B, C, D, E, F, G, H }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J, K }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J, K, L }

/// መካከለኛ ማጣቀሻ ሳይፈጥሩ የ `const` ጥሬ ጠቋሚውን ወደ አንድ ቦታ ይፍጠሩ።
///
/// ከ `&`/`&mut` ጋር ማጣቀሻን መፍጠር የሚፈቀደው ጠቋሚው በትክክል ከተስተካከለ እና ወደ ተነሳሽነት መረጃ ካመለከተ ብቻ ነው።
/// እነዚያ መስፈርቶች ለማይይዙባቸው ጉዳዮች ፣ ጥሬ ጠቋሚዎች በምትኩ ጥቅም ላይ መዋል አለባቸው ፡፡
/// ሆኖም ፣ `&expr as *const _` ወደ ጥሬ ጠቋሚ ከመጣሉ በፊት ማጣቀሻ ይፈጥራል ፣ እና ያ ማጣቀሻ ልክ እንደሌሎቹ ማጣቀሻዎች ሁሉ ተመሳሳይ ህጎች ተገዢ ነው።
///
/// ይህ ማክሮ መጀመሪያ ማጣቀሻ ሳይፈጥር ጥሬ ጠቋሚ * ሊፈጥር ይችላል ፡፡
///
/// # Example
///
/// ```
/// use std::ptr;
///
/// #[repr(packed)]
/// struct Packed {
///     f1: u8,
///     f2: u16,
/// }
///
/// let packed = Packed { f1: 1, f2: 2 };
/// // `&packed.f2` ያልተመዘገበ ማጣቀሻ ይፈጥራል እናም በዚህም ያልታወቀ ባህሪ ይሆናል!
/// let raw_f2 = ptr::addr_of!(packed.f2);
/// assert_eq!(unsafe { raw_f2.read_unaligned() }, 2);
/// ```
///
#[stable(feature = "raw_ref_macros", since = "1.51.0")]
#[rustc_macro_transparency = "semitransparent"]
#[allow_internal_unstable(raw_ref_op)]
pub macro addr_of($place:expr) {
    &raw const $place
}

/// መካከለኛ ማጣቀሻ ሳይፈጥሩ የ `mut` ጥሬ ጠቋሚውን ወደ አንድ ቦታ ይፍጠሩ።
///
/// ከ `&`/`&mut` ጋር ማጣቀሻን መፍጠር የሚፈቀደው ጠቋሚው በትክክል ከተስተካከለ እና ወደ ተነሳሽነት መረጃ ካመለከተ ብቻ ነው።
/// እነዚያ መስፈርቶች ለማይይዙባቸው ጉዳዮች ፣ ጥሬ ጠቋሚዎች በምትኩ ጥቅም ላይ መዋል አለባቸው ፡፡
/// ሆኖም `&mut expr as *mut _` ወደ ጥሬ ጠቋሚ ከመጣሉ በፊት ማጣቀሻውን ይፈጥራል ፣ እና ያ ማጣቀሻ ልክ እንደሌሎቹ ማጣቀሻዎች ሁሉ ተመሳሳይ ህጎች ተገዢ ነው።
///
/// ይህ ማክሮ መጀመሪያ ማጣቀሻ ሳይፈጥር ጥሬ ጠቋሚ * ሊፈጥር ይችላል ፡፡
///
/// # Example
///
/// ```
/// use std::ptr;
///
/// #[repr(packed)]
/// struct Packed {
///     f1: u8,
///     f2: u16,
/// }
///
/// let mut packed = Packed { f1: 1, f2: 2 };
/// // `&mut packed.f2` ያልተመዘገበ ማጣቀሻ ይፈጥራል እናም በዚህም ያልታወቀ ባህሪ ይሆናል!
/// let raw_f2 = ptr::addr_of_mut!(packed.f2);
/// unsafe { raw_f2.write_unaligned(42); }
/// assert_eq!({packed.f2}, 42); // `{...}` ማጣቀሻ ከመፍጠር ይልቅ እርሻውን መኮረጅ ያስገድዳል ፡፡
/// ```
///
#[stable(feature = "raw_ref_macros", since = "1.51.0")]
#[rustc_macro_transparency = "semitransparent"]
#[allow_internal_unstable(raw_ref_op)]
pub macro addr_of_mut($place:expr) {
    &raw mut $place
}