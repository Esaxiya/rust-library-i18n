use crate::convert::From;
use crate::fmt;
use crate::marker::{PhantomData, Unsize};
use crate::mem;
use crate::ops::{CoerceUnsized, DispatchFromDyn};

/// የዚህ ጥቅል ባለቤት የመጥቀሻ ባለቤት መሆኑን የሚያመለክት ጥሬ-አልባ ያልሆነ `*mut T` ዙሪያ መጠቅለያ ፡፡
/// እንደ `Box<T>` ፣ `Vec<T>` ፣ `String` እና `HashMap<K, V>` ያሉ ረቂቅ ነገሮችን ለመገንባት ጠቃሚ ነው ፡፡
///
/// ከ `*mut T` በተለየ ፣ `Unique<T>` የ `T` ምሳሌ ነበር ፡፡
/// `T` `Send`/`Sync` ከሆነ `Send`/`Sync` ን ይተገበራል።
/// በተጨማሪም የ‹XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXTXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXAXXXAXXXXXXSII AAGA-
/// የጠቋሚው ጠቋሚ ልዩ ወደሚሆንበት ልዩ መንገድ ሳይለወጥ ሊሻሻል አይገባም ፡፡
///
/// `Unique` ን ለእርስዎ ዓላማ መጠቀሙ ትክክል አለመሆኑን እርግጠኛ ካልሆኑ ደካማ ፍቺ ያለው `NonNull` ን ለመጠቀም ያስቡ ፡፡
///
///
/// ከኤክስኤክስኤክስክስክስክስክስክስክስክስክስክስክስክስክስክስክስክስክስክስክስ (XXXX) በተለየ መልኩ ጠቋሚው በጭራሽ ባይመዘገብም ጠቋሚው ሁልጊዜ ዋጋ ቢስ መሆን አለበት ፡፡
/// ይህ የሆነው ኤንሞች ይህንን የተከለከለውን እሴት እንደ አድልዎ እንዲጠቀሙበት ነው-`Option<Unique<T>>` ከ `Unique<T>` ጋር ተመሳሳይ መጠን አለው።
/// ሆኖም ጠቋሚው ካልተመዘገበ አሁንም ይንጠለጠል ይሆናል ፡፡
///
/// ከ `*mut T` በተለየ ፣ `Unique<T>` ከ `T` በላይ ነው ፡፡
/// ይህ ልዩ እና ልዩ የመጥፎ መስፈርቶችን ለሚደግፍ ማንኛውም ዓይነት ይህ ሁልጊዜ ትክክለኛ መሆን አለበት።
///
///
///
#[unstable(
    feature = "ptr_internals",
    issue = "none",
    reason = "use `NonNull` instead and consider `PhantomData<T>` \
              (if you also use `#[may_dangle]`), `Send`, and/or `Sync`"
)]
#[doc(hidden)]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
pub struct Unique<T: ?Sized> {
    pointer: *const T,
    // NOTE: ይህ ጠቋሚ ለልዩነት ምንም ውጤት የለውም ፣ ግን አስፈላጊ ነው
    // የ‹XXXX›ባለቤት እንደሆንን ለመረዳት ለድብቅ ቁልፍ ፡፡
    //
    // ለዝርዝሩ የሚከተሉትን ይመልከቱ
    // https://github.com/rust-lang/rfcs/blob/master/text/0769-sound-generic-drop.md#phantom-data
    _marker: PhantomData<T>,
}

/// `Unique` የሚጠቁሙት መረጃ ያልተቀየረ ስለሆነ ጠቋሚዎች `T` `Send` ከሆነ `Send` ነው ፡፡
/// ይህ ተለዋጭ የማይለዋወጥ በአይነት ስርዓት የማይተገበር መሆኑን ልብ ይበሉ;`Unique` ን በመጠቀም ረቂቁ ተግባራዊ ማድረግ አለበት።
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Send + ?Sized> Send for Unique<T> {}

/// `Unique` የሚጠቁሙት መረጃ ያልተቀየረ ስለሆነ ጠቋሚዎች `T` `Sync` ከሆነ `Sync` ነው ፡፡
/// ይህ ተለዋጭ የማይለዋወጥ በአይነት ስርዓት የማይተገበር መሆኑን ልብ ይበሉ;`Unique` ን በመጠቀም ረቂቁ ተግባራዊ ማድረግ አለበት።
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Sync + ?Sized> Sync for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: Sized> Unique<T> {
    /// የተንጠለጠለ ፣ ግን በጥሩ ሁኔታ የተስተካከለ አዲስ `Unique` ን ይፈጥራል።
    ///
    /// እንደ `Vec::new` እንደሚያደርጋት ሰነፍ የሚመደቡትን ዓይነቶች ለመጀመር ይህ ጠቃሚ ነው ፡፡
    ///
    /// የጠቋሚ እሴቱ ትክክለኛ ጠቋሚ ወደ `T` ሊወክል እንደሚችል ልብ ይበሉ ፣ ይህ ማለት ይህ እንደ "not yet initialized" የኋላ እሴት ጥቅም ላይ መዋል የለበትም።
    /// ታካቾች ለመመደብ ዘንድ አይነቶች በሌላ መንገድ ማስጀመር መከታተል አለባቸው.
    ///
    ///
    ///
    #[inline]
    pub const fn dangling() -> Self {
        // ደህንነት: mem::align_of() ልክ ያልሆነ እና የማይጠቅም ጠቋሚ ይመልሳል።ዘ
        // new_unchecked() ን ለመጥራት ሁኔታዎች እንዲሁ ይከበራሉ ፡፡
        unsafe { Unique::new_unchecked(mem::align_of::<T>() as *mut T) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Unique<T> {
    /// አዲስ `Unique` ይፈጥራል።
    ///
    /// # Safety
    ///
    /// `ptr` ከንቱ መሆን አለበት
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // ደህንነት-ደዋዩ `ptr` ዋጋ እንደሌለው ዋስትና መስጠት አለበት ፡፡
        unsafe { Unique { pointer: ptr as _, _marker: PhantomData } }
    }

    /// `ptr` ዋጋ ቢስ ከሆነ አዲስ `Unique` ን ይፈጥራል።
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // ደህንነት: ጠቋሚው ቀድሞውኑ ተረጋግጧል እና ምንም አይደለም.
            Some(unsafe { Unique { pointer: ptr as _, _marker: PhantomData } })
        } else {
            None
        }
    }

    /// መሠረታዊውን የ `*mut` ጠቋሚ ያገኛል።
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// ይዘቱን ያዛባል ፡፡
    ///
    /// የሚወጣው የሕይወት ዘመን ከራስ ጋር የተቆራኘ ነው ፣ ስለሆነም ይህ "as if" ን ያሳያል ፣ እሱ በእውነቱ ተበዳሪው የቲ ምሳሌ ነው።
    /// ረዘም ያለ የ (unbound) ዕድሜ አስፈላጊ ከሆነ `&*my_ptr.as_ptr()` ን ይጠቀሙ።
    ///
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // ደህንነት-ደዋዩ `self` ሁሉንም እንደሚያሟላ ዋስትና መስጠት አለበት
        // ለማጣቀሻ መስፈርቶች
        unsafe { &*self.as_ptr() }
    }

    /// ይዘቱን በግልፅ ያጠፋሉ።
    ///
    /// የሚወጣው የሕይወት ዘመን ከራስ ጋር የተቆራኘ ነው ፣ ስለሆነም ይህ "as if" ን ያሳያል ፣ እሱ በእውነቱ ተበዳሪው የቲ ምሳሌ ነው።
    /// ረዘም ያለ የ (unbound) ዕድሜ አስፈላጊ ከሆነ `&mut *my_ptr.as_ptr()` ን ይጠቀሙ።
    ///
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // ደህንነት-ደዋዩ `self` ሁሉንም እንደሚያሟላ ዋስትና መስጠት አለበት
        // ለለውጥ ማጣቀሻ የሚያስፈልጉ መስፈርቶች።
        unsafe { &mut *self.as_ptr() }
    }

    /// ለሌላ ዓይነት ጠቋሚ ይጣጣል ፡፡
    #[inline]
    pub const fn cast<U>(self) -> Unique<U> {
        // ደህንነት-Unique::new_unchecked() አዲስ ልዩ እና ፍላጎቶችን ይፈጥራል
        // የተሰጠው ጠቋሚ ዋጋ የለውም ፡፡
        // እኛ እንደ ጠቋሚ እራሳችንን ስለምናልፍ ከንቱ ሊሆን አይችልም ፡፡
        unsafe { Unique::new_unchecked(self.as_ptr() as *mut U) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Clone for Unique<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Copy for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Debug for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Pointer for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<&mut T> for Unique<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // ደህንነት-የሚለዋወጥ ማጣቀሻ ዋጋ ቢስ ሊሆን አይችልም
        unsafe { Unique { pointer: reference as *mut T, _marker: PhantomData } }
    }
}