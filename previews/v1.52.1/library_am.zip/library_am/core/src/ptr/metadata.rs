#![unstable(feature = "ptr_metadata", issue = "81513")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

/// የማንኛውም የጠቆመ-ዓይነት ጠቋሚ ሜታዳታ አይነት ይሰጣል።
///
/// # ጠቋሚ ሜታዳታ
///
/// በ Rust ውስጥ ጥሬ ጠቋሚ ዓይነቶች እና የማጣቀሻ ዓይነቶች በሁለት ክፍሎች የተሠሩ እንደሆኑ ሊታሰብ ይችላል-
/// የእሴቱን የማስታወሻ አድራሻ እና የተወሰኑ ሜታዳታ የያዘ የውሂብ ጠቋሚ።
///
/// ለስታቲስቲክስ መጠነ-ሰፊ ዓይነቶች (`Sized` traits ን የሚተገብሩ) እንዲሁም ለ‹`extern`›ዓይነቶች ጠቋሚዎች`ስስ`እንደሆኑ ይነገራል-ሜታዳታ ዜሮ-መጠን ያለው እና የእሱ ዓይነት `()` ነው ፡፡
///
///
/// የ‹XXXX›ጠቋሚዎች `ሰፊ` ወይም `ስብ` ናቸው ተብሏል ፣ ዜሮ ያልሆኑ መጠን ያላቸው ሜታዳታ አላቸው-
///
/// * የመጨረሻው መስክ ዲ.ኤስ.ቲ ለሆኑት ፣ ሜታዳታ ለመጨረሻው መስክ ሜታዳታ ነው
/// * ለ `str` ዓይነት ፣ ሜታዳታ እንደ `usize` ባይት ውስጥ ርዝመት ነው
/// * እንደ `[T]` ላሉት ለተቆራረጡ አይነቶች ሜታዳታ በእቃዎች ውስጥ እንደ `usize` ርዝመት ነው
/// * እንደ `dyn SomeTrait` ላሉ trait ነገሮች ሜታዳታ [`DynMetadata<Self>`][DynMetadata] ነው (ለምሳሌ `DynMetadata<dyn SomeTrait>`)
///
/// በ future ውስጥ የ Rust ቋንቋ የተለያዩ ጠቋሚ ሜታዳታ ያላቸውን አዲስ ዓይነቶችን ሊያገኝ ይችላል።
///
/// [dst]: https://doc.rust-lang.org/nomicon/exotic-sizes.html#dynamically-sized-types-dsts
///
/// # `Pointee` trait
///
/// የዚህ trait ነጥቡ የ `Metadata` ተጓዳኝ ዓይነት ነው ፣ እሱም ከላይ እንደተገለፀው `()` ወይም `usize` ወይም `DynMetadata<_>` ነው ፡፡
/// ለእያንዳንዱ ዓይነት በራስ-ሰር ይተገበራል ፡፡
/// ተጓዳኝ ሳይኖር እንኳን በአጠቃላይ ሁኔታ ውስጥ እንዲተገበር ሊወሰድ ይችላል ፡፡
///
/// # Usage
///
/// ጥሬ ጠቋሚዎች በ [`to_raw_parts`] ዘዴቸው ወደ የውሂብ አድራሻ እና ሜታዳታ አካላት መበስበስ ይችላሉ።
///
/// እንደ አማራጭ ሜታዳታ ብቻውን በ [`metadata`] ተግባር ሊወጣ ይችላል።
/// አንድ ማጣቀሻ ወደ [`metadata`] ሊተላለፍ እና በተዘዋዋሪ በግዳጅ ሊገደድ ይችላል።
///
/// የ (possibly-wide) ጠቋሚ ከአድራሻው እና ከሜታዳታ በ [`from_raw_parts`] ወይም [`from_raw_parts_mut`] መልሰው በአንድ ላይ ማስቀመጥ ይቻላል።
///
/// [`to_raw_parts`]: *const::to_raw_parts
///
///
///
///
///
///
///
///
///
#[lang = "pointee_trait"]
pub trait Pointee {
    /// በ `Self` ጠቋሚዎች እና ማጣቀሻዎች ውስጥ ለሜታዳታ አይነት።
    #[lang = "metadata_type"]
    // NOTE: trait bounds ን በ `static_assert_expected_bounds_for_metadata` X ያቆዩ
    //
    // እዚህ ካሉ ጋር በማመሳሰል በ `library/core/src/ptr/metadata.rs` ውስጥ
    type Metadata: Copy + Send + Sync + Ord + Hash + Unpin;
}

/// ይህንን የ trait ቅጽል ስም የሚተገብሩ ዓይነቶች ጠቋሚዎች `ስስ` ናቸው ፡፡
///
/// ይህ በስታቲስቲክስ-‹Sized` አይነቶች እና `extern` አይነቶችን ያካትታል ፡፡
///
/// # Example
///
/// ```rust
/// #![feature(ptr_metadata)]
///
/// fn this_never_panics<T: std::ptr::Thin>() {
///     assert_eq!(std::mem::size_of::<&T>(), std::mem::size_of::<usize>())
/// }
/// ```
#[unstable(feature = "ptr_metadata", issue = "81513")]
// NOTE: የ trait ተለዋጭ ስሞች በቋንቋው ከመረጋጋታቸው በፊት ይህንን አያረጋጉ?
pub trait Thin = Pointee<Metadata = ()>;

/// የአንድ ጠቋሚ ሜታዳታ አካል ያውጡ።
///
/// የ `*mut T` ፣ `&T` ወይም `&mut T` ዓይነት እሴቶች በተዘዋዋሪ ወደ `* const T` ስለሚገደዱ ወደዚህ ተግባር ሊተላለፉ ይችላሉ ፡፡
///
///
/// # Example
///
/// ```
/// #![feature(ptr_metadata)]
///
/// assert_eq!(std::ptr::metadata("foo"), 3_usize);
/// ```
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn metadata<T: ?Sized>(ptr: *const T) -> <T as Pointee>::Metadata {
    // ደህንነት: ዋጋውን ከ `PtrRepr` ህብረት መድረስ ከ * const T ጀምሮ ደህንነቱ የተጠበቀ ነው
    // እና PtrComponents<T>ተመሳሳይ የማስታወሻ አቀማመጦች አሏቸው።
    // ይህንን ዋስትና ሊሰጥ የሚችለው std ብቻ ነው።
    unsafe { PtrRepr { const_ptr: ptr }.components.metadata }
}

/// ከመረጃ አድራሻ እና ሜታዳታ የ (possibly-wide) ጥሬ ጠቋሚ ይሠራል።
///
/// ይህ ተግባር ደህንነቱ የተጠበቀ ነው ግን የተመለሰው ጠቋሚ ለመገልበጡ የግድ ደህና አይደለም ፡፡
/// ለተቆራረጡ ፣ ለደህንነት መስፈርቶች የ [`slice::from_raw_parts`] ሰነድን ይመልከቱ ፡፡
/// ለ trait ነገሮች ሜታዳታ ከጠቋሚው ወደ ተመሳሳዩ መሰረታዊ የ ere ዓይነት መምጣት አለበት ፡፡
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts<T: ?Sized>(
    data_address: *const (),
    metadata: <T as Pointee>::Metadata,
) -> *const T {
    // ደህንነት: ዋጋውን ከ `PtrRepr` ህብረት መድረስ ከ * const T ጀምሮ ደህንነቱ የተጠበቀ ነው
    // እና PtrComponents<T>ተመሳሳይ የማስታወሻ አቀማመጦች አሏቸው።
    // ይህንን ዋስትና ሊሰጥ የሚችለው std ብቻ ነው።
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.const_ptr }
}

/// ከጥሬ የ `*const` ጠቋሚ በተቃራኒው ጥሬ የ `* mut` ጠቋሚ ከተመለሰ በስተቀር እንደ [`from_raw_parts`] ተመሳሳይ ተግባር ያከናውናል።
///
///
/// ለተጨማሪ ዝርዝሮች የ [`from_raw_parts`] ሰነድን ይመልከቱ ፡፡
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts_mut<T: ?Sized>(
    data_address: *mut (),
    metadata: <T as Pointee>::Metadata,
) -> *mut T {
    // ደህንነት: ዋጋውን ከ `PtrRepr` ህብረት መድረስ ከ * const T ጀምሮ ደህንነቱ የተጠበቀ ነው
    // እና PtrComponents<T>ተመሳሳይ የማስታወሻ አቀማመጦች አሏቸው።
    // ይህንን ዋስትና ሊሰጥ የሚችለው std ብቻ ነው።
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.mut_ptr }
}

#[repr(C)]
pub(crate) union PtrRepr<T: ?Sized> {
    pub(crate) const_ptr: *const T,
    pub(crate) mut_ptr: *mut T,
    pub(crate) components: PtrComponents<T>,
}

#[repr(C)]
pub(crate) struct PtrComponents<T: ?Sized> {
    pub(crate) data_address: *const (),
    pub(crate) metadata: <T as Pointee>::Metadata,
}

// ከ‹XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXEXEXDEK
impl<T: ?Sized> Copy for PtrComponents<T> {}

// ከ‹XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXEXEXDEK
impl<T: ?Sized> Clone for PtrComponents<T> {
    fn clone(&self) -> Self {
        *self
    }
}

/// ለ `Dyn = dyn SomeTrait` trait ዕቃ ዓይነት ሜታዳታ።
///
/// በ trait ነገር ውስጥ የተከማቸን የኮንክሪት አይነት ለማዛባት ሁሉንም አስፈላጊ መረጃዎችን የሚወክል የአንድ ጠቋሚ (ምናባዊ የጥሪ ሰንጠረዥ) ጠቋሚ ነው።
/// በተለይ በውስጡ የያዘው
///
/// * ዓይነት መጠን
/// * ዓይነት አሰላለፍ
/// * ለዓይነቱ የ `drop_in_place` impl ጠቋሚ (ለተራቀቀ-ጥንታዊ መረጃ መሻት ሊሆን ይችላል)
/// * ለ trait አተገባበር ለሁሉም ዘዴዎች ጠቋሚዎች
///
/// የመጀመሪያዎቹ ሶስቱ ልዩ መሆናቸውን ልብ ይበሉ ምክንያቱም ማንኛውንም የ trait ነገር ለመመደብ ፣ ለመጣል እና ለማካፈል አስፈላጊ ስለሆኑ ፡፡
///
/// ይህንን አወቃቀር `dyn` trait ያልሆነ (ለምሳሌ `DynMetadata<u64>`) ባልሆነ የአይነት መለኪያ መሰየም ይቻላል ነገር ግን የዚያ መዋቅር ትርጉም ያለው እሴት ለማግኘት አይደለም ፡፡
///
///
///
///
#[lang = "dyn_metadata"]
pub struct DynMetadata<Dyn: ?Sized> {
    vtable_ptr: &'static VTable,
    phantom: crate::marker::PhantomData<Dyn>,
}

/// የሁሉም vtables የጋራ ቅድመ ቅጥያ።ለ trait ዘዴዎች የተግባር ጠቋሚዎች ይከተላል።
///
/// የ `DynMetadata::size_of` ወዘተ የግል አተገባበር ዝርዝር
#[repr(C)]
struct VTable {
    drop_in_place: fn(*mut ()),
    size_of: usize,
    align_of: usize,
}

impl<Dyn: ?Sized> DynMetadata<Dyn> {
    /// ከዚህ vtable ጋር የተዛመደውን ዓይነት መጠን ይመልሳል።
    #[inline]
    pub fn size_of(self) -> usize {
        self.vtable_ptr.size_of
    }

    /// ከዚህ vtable ጋር የተዛመደውን ዓይነት አሰላለፍ ይመልሳል።
    #[inline]
    pub fn align_of(self) -> usize {
        self.vtable_ptr.align_of
    }

    /// እንደ `Layout` መጠን እና አሰላለፍ በአንድነት ይመልሳል
    #[inline]
    pub fn layout(self) -> crate::alloc::Layout {
        // ደህንነት-አጠናቃጁ ይህንን ተጨባጭ ለኮንክሪት Rust ዓይነት ለቋል
        // ትክክለኛ አቀማመጥ እንዳለው ይታወቃል ፡፡በ `Layout::for_value` ውስጥ ያለው ተመሳሳይ አስተሳሰብ።
        unsafe { crate::alloc::Layout::from_size_align_unchecked(self.size_of(), self.align_of()) }
    }
}

unsafe impl<Dyn: ?Sized> Send for DynMetadata<Dyn> {}
unsafe impl<Dyn: ?Sized> Sync for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> fmt::Debug for DynMetadata<Dyn> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("DynMetadata").field(&(self.vtable_ptr as *const VTable)).finish()
    }
}

// የ `Dyn: $Trait` ድንበሮችን ለማስወገድ በእጅ ማበረታቻዎች ያስፈልጋሉ

impl<Dyn: ?Sized> Unpin for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Copy for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Clone for DynMetadata<Dyn> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

impl<Dyn: ?Sized> Eq for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> PartialEq for DynMetadata<Dyn> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        crate::ptr::eq::<VTable>(self.vtable_ptr, other.vtable_ptr)
    }
}

impl<Dyn: ?Sized> Ord for DynMetadata<Dyn> {
    #[inline]
    fn cmp(&self, other: &Self) -> crate::cmp::Ordering {
        (self.vtable_ptr as *const VTable).cmp(&(other.vtable_ptr as *const VTable))
    }
}

impl<Dyn: ?Sized> PartialOrd for DynMetadata<Dyn> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<crate::cmp::Ordering> {
        Some(self.cmp(other))
    }
}

impl<Dyn: ?Sized> Hash for DynMetadata<Dyn> {
    #[inline]
    fn hash<H: Hasher>(&self, hasher: &mut H) {
        crate::ptr::hash::<VTable, _>(self.vtable_ptr, hasher)
    }
}