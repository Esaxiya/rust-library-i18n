#![allow(missing_docs)]
#![unstable(feature = "raw", issue = "27751")]

//! አብሮገነብ ዓይነቶች ዓይነቶችን ለማቀናበር የመዋቅር ትርጓሜዎችን ይል።
//!
//! ጥሬ ተወካዮቹን በቀጥታ ለማዛባት ደህንነቱ ባልተጠበቀ ኮድ ውስጥ የመተላለፊያ ዒላማዎች ሆነው ሊያገለግሉ ይችላሉ ፡፡
//!
//!
//! የእነሱ ፍች በ `rustc_middle::ty::layout` ከተገለጸው ABI ጋር ሁልጊዜ መመሳሰል አለበት።
//!

/// እንደ `&dyn SomeTrait` ያለ የ trait ነገር ውክልና።
///
/// ይህ አወቃቀር እንደ `&dyn SomeTrait` እና `Box<dyn AnotherTrait>` ካሉ ዓይነቶች ጋር ተመሳሳይ አቀማመጥ አለው ፡፡
///
/// `TraitObject` አቀማመጦችን ለማዛመድ የተረጋገጠ ነው ፣ ግን የ trait ዕቃዎች ዓይነት አይደለም (ለምሳሌ ፣ መስኮቹ በቀጥታ በ `&dyn SomeTrait` ላይ ተደራሽ አይደሉም) ወይም ያንን አቀማመጥ አይቆጣጠርም (ትርጉሙን መቀየር የ `&dyn SomeTrait` ን አቀማመጥ አይለውጠውም)።
///
/// የዝቅተኛ ደረጃ ዝርዝሮችን ማረም በሚያስፈልገው ደህንነቱ ባልተጠበቀ ኮድ እንዲጠቀም ብቻ ነው የተቀየሰው ፡፡
///
/// ሁሉንም የ trait እቃዎችን በአጠቃላይ ለመጥቀስ ምንም መንገድ የለም ፣ ስለሆነም የዚህ አይነት እሴቶችን ለመፍጠር ብቸኛው መንገድ እንደ [`std::mem::transmute`][transmute] ካሉ ተግባራት ጋር ነው ፡፡
/// በተመሳሳይ ፣ ከ‹`TraitObject` እሴት›እውነተኛ የ trait ነገር ለመፍጠር ብቸኛው መንገድ ከ `transmute` ጋር ነው።
///
/// [transmute]: crate::intrinsics::transmute
///
/// የ trait ነገርን ባልተመሳሰሉ አይነቶችን ማመሳሰል-ይህም የውሂብ ጠቋሚው ከሚጠቆመው እሴት ዓይነት ጋር የማይመሳሰልበት-ወደ ያልተገለጸ ባህሪ የመያዝ ዕድሉ ከፍተኛ ነው።
///
/// # Examples
///
/// ```
/// #![feature(raw)]
///
/// use std::{mem, raw};
///
/// // ምሳሌ trait
/// trait Foo {
///     fn bar(&self) -> i32;
/// }
///
/// impl Foo for i32 {
///     fn bar(&self) -> i32 {
///          *self + 1
///     }
/// }
///
/// let value: i32 = 123;
///
/// // አጠናቃሪው የ trait ነገር እንዲሠራ ያድርጉ
/// let object: &dyn Foo = &value;
///
/// // ጥሬ ውክልናውን ይመልከቱ
/// let raw_object: raw::TraitObject = unsafe { mem::transmute(object) };
///
/// // የመረጃ ጠቋሚው የ `value` አድራሻ ነው
/// assert_eq!(raw_object.data as *const i32, &value as *const _);
///
/// let other_value: i32 = 456;
///
/// // የ `i32` ን ከ `object` ለመጠቀም ጠንቃቃ በመሆን ለተለየ የ `i32` ን በማመልከት አዲስ ነገር ይገንቡ ፡፡
/////
/// let synthesized: &dyn Foo = unsafe {
///      mem::transmute(raw::TraitObject {
///          data: &other_value as *const _ as *mut (),
///          vtable: raw_object.vtable,
///      })
/// };
///
/// // በቀጥታ ከ `other_value` ውስጥ የ trait ነገር እንደገነባን ሁሉ ሊሠራ ይገባል
/////
/// assert_eq!(synthesized.bar(), 457);
/// ```
///
///
///
///
///
///
///
///
///
#[repr(C)]
#[derive(Copy, Clone)]
#[allow(missing_debug_implementations)]
pub struct TraitObject {
    pub data: *mut (),
    pub vtable: *mut (),
}