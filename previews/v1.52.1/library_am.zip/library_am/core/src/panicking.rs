//! Panic ለሊብኮር ድጋፍ
//!
//! ዋናው ቤተ-መጽሐፍት ድንጋጤን መግለጽ አይችልም ፣ ግን ድንጋጤን * ያስታውቃል።
//! ይህ ማለት በሊብኮር ውስጥ ያሉት ተግባራት ለ panic ይፈቀዳሉ ፣ ግን ጠቃሚ ለመሆን ወደ ላይ ያለው የ‹crate›ሊብኮር ለመጠቀም የሚያስችለውን ድንጋጤ መግለፅ አለበት ፡፡
//! ለመደናገጥ አሁን ያለው በይነገጽ-
//!
//! ```
//! fn panic_impl(pi: &core::panic::PanicInfo<'_>) -> !
//! # { loop {} }
//! ```
//!
//! ይህ ፍቺ በማንኛውም አጠቃላይ መልእክት ለመደናገጥ ይፈቅዳል ፣ ግን በ‹`Box<Any>` X›እሴት ውድቀት አይፈቅድም ፡፡
//! (`PanicInfo` ልክ `&(dyn Any + Send)` ን ይ containsል ፣ ለዚህም‹PanicInfo: : ውስጣዊ_ ኮንስትራክተር›ውስጥ የደመወዝ እሴት እንሞላለን ፡፡) ለዚህ ምክንያቱ ሊብኮር እንዲመደብ ስለማይፈቀድ ነው ፡፡
//!
//!
//! ይህ ሞጁል ሌሎች ጥቂት የሚያስደነግጡ ተግባራትን ይ containsል ፣ ግን እነዚህ ለአቀናባሪው አስፈላጊ የሆኑ የላን ነገሮች ብቻ ናቸው።ሁሉም panics በዚህ አንድ ተግባር ይተላለፋሉ።
//! ትክክለኛው ምልክት በ `#[panic_handler]` አይነታ በኩል ታወጀ።
//!
//!
//!

#![allow(dead_code, missing_docs)]
#![unstable(
    feature = "core_panic",
    reason = "internal details of the implementation of the `panic!` and related macros",
    issue = "none"
)]

use crate::fmt;
use crate::panic::{Location, PanicInfo};

/// ቅርጸት በማይሠራበት ጊዜ የሊብኮር XXXX ማክሮ መሠረታዊ አተገባበር ፡፡
#[cold]
// በተቻለ መጠን በጥሪ ጣቢያዎች የኮድ እብጠትን ለማስወገድ panic_immediate_abort ካልሆነ በቀር በጭራሽ በመስመር ላይ አይስመሩ
//
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic"] // ከመጠን በላይ እና በሌሎች የ `Assert` MIR ተርሚኖች ላይ በኮድገን ለ panic ያስፈልጋል
pub fn panic(expr: &'static str) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // ከመጠን በላይ መጠንን ለመቀነስ ከ format_args ይልቅ Arguments::new_v1 ን ይጠቀሙ! ("{}", Expr)
    // ቅርጸቱ_አረጀ!ማክሮ‹XXXX›ን የሚጠራውን ኤክስፐር ለመጻፍ የ‹str›ማሳያ trait ን ይጠቀማል ፣ ይህም የሕብረቁምፊን መቆራረጥ እና መቅዘፊያ ማስተናገድ አለበት (ምንም እንኳን እዚህ ምንም ጥቅም ላይ ባይውልም) ፡፡
    //
    // Arguments::new_v1 ን በመጠቀም አጠናካሪው እስከ ጥቂት ኪሎባይት ድረስ በመቆጠብ ከውጤት ሁለትዮሽ Formatter::pad ን እንዲተው ያስችለዋል።
    //
    //
    panic_fmt(fmt::Arguments::new_v1(&[expr], &[]));
}

#[inline]
#[track_caller]
#[lang = "panic_str"] // ለግምገማ ለተገመገመ panics ያስፈልጋል
pub fn panic_str(expr: &str) -> ! {
    panic_fmt(format_args!("{}", expr));
}

#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic_bounds_check"] // በ OOB array/slice መዳረሻ በኮድገን ለ panic ያስፈልጋል
fn panic_bounds_check(index: usize, len: usize) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    panic!("index out of bounds: the len is {} but the index is {}", len, index)
}

/// ቅርጸት ስራ ላይ ሲውል የሊብኮር XXXX ማክሮ መሰረታዊ ትግበራ ፡፡
#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[cfg_attr(feature = "panic_immediate_abort", inline)]
#[track_caller]
pub fn panic_fmt(fmt: fmt::Arguments<'_>) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // ማስታወሻ ይህ ተግባር የ FFI ን ድንበር አያልፍም;ወደ `#[panic_handler]` ተግባር መፍትሄ የሚያገኝ የ Rust-to-Rust ጥሪ ነው።
    //
    extern "Rust" {
        #[lang = "panic_impl"]
        fn panic_impl(pi: &PanicInfo<'_>) -> !;
    }

    let pi = PanicInfo::internal_constructor(Some(&fmt), Location::caller());

    // ደህንነት: `panic_impl` በደህንነት የ Rust ኮድ ውስጥ ይገለጻል እናም ለመደወል ደህና ነው።
    unsafe { panic_impl(&pi) }
}

#[derive(Debug)]
#[doc(hidden)]
pub enum AssertKind {
    Eq,
    Ne,
}

/// ለ `assert_eq!` እና ለ `assert_ne!` ማክሮዎች ውስጣዊ ተግባር
#[cold]
#[track_caller]
#[doc(hidden)]
pub fn assert_failed<T, U>(
    kind: AssertKind,
    left: &T,
    right: &U,
    args: Option<fmt::Arguments<'_>>,
) -> !
where
    T: fmt::Debug + ?Sized,
    U: fmt::Debug + ?Sized,
{
    #[track_caller]
    fn inner(
        kind: AssertKind,
        left: &dyn fmt::Debug,
        right: &dyn fmt::Debug,
        args: Option<fmt::Arguments<'_>>,
    ) -> ! {
        let op = match kind {
            AssertKind::Eq => "==",
            AssertKind::Ne => "!=",
        };

        match args {
            Some(args) => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`: {}"#,
                op, left, right, args
            ),
            None => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`"#,
                op, left, right,
            ),
        }
    }
    inner(kind, &left, &right, args)
}