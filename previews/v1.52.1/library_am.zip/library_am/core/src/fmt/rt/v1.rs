//! ይህ Ifmt ያገለገለ ውስጣዊ ሞዱል ነው!አሂድ ጊዜእነዚህ መዋቅሮች የቅርጸት ሕብረቁምፊዎችን ቀድመው ለማጠናቀር ወደ የማይለዋወጥ ዝግጅቶች ይለቃሉ።
//!
//! እነዚህ ትርጓሜዎች ያላቸውን `ct` ተመጣጣኝ ጋር ተመሳሳይ ነው, ነገር ግን እነዚህ በማይለወጥ የተመደበ እንደሚችሉ ውስጥ ይለያያል እና በትንሹ የሚፈጀውን የተመቻቹ ናቸው
//!
//!
#![allow(missing_debug_implementations)]

#[derive(Copy, Clone)]
pub struct Argument {
    pub position: usize,
    pub format: FormatSpec,
}

#[derive(Copy, Clone)]
pub struct FormatSpec {
    pub fill: char,
    pub align: Alignment,
    pub flags: u32,
    pub precision: Count,
    pub width: Count,
}

/// እንደ ቅርጸት መመሪያ አካል ሆነው ሊጠየቁ የሚችሉ አሰላለፍ
#[derive(Copy, Clone, PartialEq, Eq)]
pub enum Alignment {
    /// ይዘቶች ግራ-ተሰልፈው መሆን እንዳለባቸው የሚጠቁም።
    Left,
    /// ይዘቶች በቀኝ-የተዛመዱ መሆን እንዳለባቸው የሚጠቁም።
    Right,
    /// ይዘቶቹ ከመሃል ጋር የተጣጣሙ መሆን እንዳለባቸው የሚጠቁም።
    Center,
    /// አሰላለፍ አልተጠየቀም ፡፡
    Unknown,
}

/// በ [width](https://doc.rust-lang.org/std/fmt/#width) እና [precision](https://doc.rust-lang.org/std/fmt/#precision) አመልካቾች ጥቅም ላይ የዋለ።
#[derive(Copy, Clone)]
pub enum Count {
    /// ቃል በቃል ቁጥር ጋር በተጠቀሰው, እሴት ያከማቻል
    Is(usize),
    /// `$` እና `*` syntaxes በመጠቀም የተገለጸውን, `args` ወደ ጠቋሚ ያከማቻል
    Param(usize),
    /// አልተገለጸም
    Implied,
}