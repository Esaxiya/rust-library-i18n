#![stable(feature = "core_hint", since = "1.27.0")]

//! ኮዱን እንዴት ማውጣት ወይም ማሻሻል እንዳለበት ላይ ተጽዕኖ የሚያሳድረው አጠናቃሪ ፍንጭ
//! ፍንጮች ማጠናቀር ጊዜ ወይም የሚፈጀውን ጊዜ ሊሆን ይችላል.

use crate::intrinsics;

/// ተጨማሪ ማበረታቻዎችን በማንቃት በኮዱ ውስጥ ያለው ይህ ነጥብ ሊደረስበት እንደማይችል ለአቀናባሪው ያሳውቃል።
///
/// # Safety
///
/// ይህንን ተግባር መድረስ *ያልተገለጸ ባህሪ*(UB) ሙሉ ነው.በተለይም አሰባሳቢው ሁሉም UB በጭራሽ መሆን እንደሌለባቸው ይገምታል ፣ ስለሆነም ወደ `unreachable_unchecked()` ጥሪ የሚደርሱትን ሁሉንም ቅርንጫፎች ያስወግዳል ፡፡
///
/// ልክ እንደ ሁሉም የ UB አጋጣሚዎች ፣ ይህ አስተሳሰብ የተሳሳተ ሆኖ ከተገኘ ፣ ማለትም ፣ የ `unreachable_unchecked()` ጥሪ በእውነቱ በሁሉም የቁጥጥር ፍሰት ሊደርስ የሚችል ነው ፣ አሰባሳቢው የተሳሳተ የማመቻቸት ስትራቴጂን ይተገብራል ፣ እና አንዳንዴም የማይዛመዱ በሚመስሉ ኮድ እንኳን ሊበላሽ ይችላል ፣ ወደ-የማረም ችግር.
///
///
/// አንተ ኮድ እንጠራዋለን ፈጽሞ መሆኑን ማረጋገጥ ይችላሉ ጊዜ ብቻ ነው ይህንን ተግባር ይጠቀሙ.
/// አለበለዚያ, ማሳደጊያዎች አይፈቅድም ያለውን [`unreachable!`] ማክሮ, መጠቀሙን ግምት ግን panic ከተገደለ ጊዜ.
///
/// # Example
///
/// ```
/// fn div_1(a: u32, b: u32) -> u32 {
///     use std::hint::unreachable_unchecked;
///
///     // `b.saturating_add(1)` ሁልጊዜ አዎንታዊ ነው (ዜሮ አይደለም) ፣ ስለሆነም `checked_div` በጭራሽ `None` ን አይመልስም።
/////
///     // ስለዚህ, ወደ ሌላ branch አይገኝም.
///     a.checked_div(b.saturating_add(1))
///         .unwrap_or_else(|| unsafe { unreachable_unchecked() })
/// }
///
/// assert_eq!(div_1(7, 0), 7);
/// assert_eq!(div_1(9, 1), 4);
/// assert_eq!(div_1(11, u32::MAX), 0);
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "unreachable", since = "1.27.0")]
#[rustc_const_unstable(feature = "const_unreachable_unchecked", issue = "53188")]
pub const unsafe fn unreachable_unchecked() -> ! {
    // ደህንነት-ለ‹`intrinsics::unreachable` X›ደህንነት ውል ግዴታ አለበት
    // ወደ ጠሪው በ አጽንቶታል ይሆናል.
    unsafe { intrinsics::unreachable() }
}

/// ሥራ በሚበዛበት የጥበቃ ማዞሪያ (`ስፒን መቆለፊያ`) ውስጥ እየሰራ መሆኑን ለማስገንዘብ የማሽን መመሪያ ያወጣል።
///
/// ለምሳሌ ያህል, የ አይፈትሉምም ከድግግሞሽ ምልክት በማድረግ የራሱን ባህሪ ለማመቻቸት ይችላሉ አንጎለ መቀበል ኃይል ማስቀመጥ ወይም hyper-ክሮች በመቀየር ላይ.
///
/// ይህ ተግባር `spin_loop` የክወና ስርዓት ጋር መስተጋብር አያደርግም; በአንጻሩ ግን በቀጥታ, የስርዓቱን መርሐግብር ያቀረቡለትን ይህም [`thread::yield_now`] የተለየ ነው.
///
/// ለ `spin_loop` አንድ የተለመደ አጠቃቀም ጉዳይ በማመሳሰል የመጀመሪያ ደረጃዎች ውስጥ በ CAS ዑደት ውስጥ የታሰረ ብሩህ ተስፋን ማዞር ይተገበራል ፡፡
/// እንደ ቀዳሚ ተገላቢጦሽ ያሉ ችግሮችን ለማስወገድ የማሽከርከሪያ ቀለበቱ ውስን ድግግሞሾች ከተጠናቀቁ በኋላ ተገቢ የማገጃ አጥር (ሲሳይል) ከተደረገ በጥብቅ ይመከራል ፡፡
///
///
/// **ማስታወሻ**: በዚህ ተግባር ሁሉ ላይ ምንም ነገር አያደርግም አይፈትሉምም ከድግግሞሽ ፍንጮች መቀበል አንደግፍም መሆኑን መሣሪያ ስርዓቶች ላይ.
///
/// # Examples
///
/// ```
/// use std::sync::atomic::{AtomicBool, Ordering};
/// use std::sync::Arc;
/// use std::{hint, thread};
///
/// // ክሮች ለማስተባበር የሚጠቀሙበት የተጋራ የአቶሚክ እሴት
/// let live = Arc::new(AtomicBool::new(false));
///
/// // በጀርባ ክር ውስጥ በመጨረሻ ዋጋውን እናዘጋጃለን
/// let bg_work = {
///     let live = live.clone();
///     thread::spawn(move || {
///         // የተወሰነ ስራ ይስሩ ፣ ከዚያ እሴቱን በቀጥታ ያድርጉት
///         do_some_work();
///         live.store(true, Ordering::Release);
///     })
/// };
///
/// // ዋጋ ስብስብ መሆን ተመለስ በእኛ በአሁኑ ክር ላይ, እኛ ይጠብቁ
/// while !live.load(Ordering::Acquire) {
///     // የ አይፈትሉምም ምልልስ እኛ በመጠበቅ, ነገር ግን ምናልባት ሳይሆን በጣም ለረጅም መሆንዎን መሆኑን ሲፒዩ አንድ ፍንጭ ነው
/////
///     hint::spin_loop();
/// }
///
/// // ዋጋ አሁን ተዘጋጅቷል
/// # fn do_some_work() {}
/// do_some_work();
/// bg_work.join()?;
/// # Ok::<(), Box<dyn core::any::Any + Send + 'static>>(())
/// ```
///
/// [`thread::yield_now`]: ../../std/thread/fn.yield_now.html
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "renamed_spin_loop", since = "1.49.0")]
pub fn spin_loop() {
    #[cfg(all(any(target_arch = "x86", target_arch = "x86_64"), target_feature = "sse2"))]
    {
        #[cfg(target_arch = "x86")]
        {
            // ደህንነት: እኛ ብቻ x86 ዒላማዎች ላይ ይህን ለማስፈጸም እንደሆነ `cfg` attr ያረጋግጣል.
            unsafe { crate::arch::x86::_mm_pause() };
        }

        #[cfg(target_arch = "x86_64")]
        {
            // ደህንነት: `cfg` attr ይህንን በ x86_64 ዒላማዎች ላይ ብቻ እንደምንፈጽም ያረጋግጣል ፡፡
            unsafe { crate::arch::x86_64::_mm_pause() };
        }
    }

    #[cfg(any(target_arch = "aarch64", all(target_arch = "arm", target_feature = "v6")))]
    {
        #[cfg(target_arch = "aarch64")]
        {
            // ደህንነት: እኛ ብቻ aarch64 ዒላማዎች ላይ ይህን ለማስፈጸም እንደሆነ `cfg` attr ያረጋግጣል.
            unsafe { crate::arch::aarch64::__yield() };
        }
        #[cfg(target_arch = "arm")]
        {
            // ደህንነት: `cfg` attr ይህንን በክንድ ዒላማዎች ላይ ብቻ እንደፈፀምን ያረጋግጣል
            // ለ v6 ባህሪ ድጋፍ።
            unsafe { crate::arch::arm::__yield() };
        }
    }
}

/// አንድ ማንነት ተግባር መሆኑን *__ ፍንጮች __* ወደ አጠናቃሪ ወደ `black_box` ማድረግ ይችላል ነገር ቢበዛ ቢበዛ አፍራሽ መሆን.
///
/// ከ [`std::convert::identity`] በተለየ የ Rust አቀናባሪ `black_box` በመደወያው ኮድ ውስጥ ያልተገለጸ ባህሪን ሳያስተዋውቅ Rust ኮድ በሚፈቀደው በማንኛውም መንገድ `dummy` ን ሊጠቀም ይችላል ብሎ እንዲገምት ይበረታታል ፡፡
///
/// ይህ ንብረት `black_box` ን እንደ መመዘኛዎች ያሉ የተወሰኑ ማበረታቻዎች የማይፈለጉበትን ኮድ ለመፃፍ ጠቃሚ ያደርገዋል ፡፡
///
/// ሆኖም ልብ ይበሉ ፣ `black_box` በ "best-effort" መሠረት ብቻ (እና ብቻ ሊሆን ይችላል) የቀረበ ነው።ይህም መድረክ እና ኮድ-ዘፍ ላይ ሊለያይ ይችላል optimisations ማገድ ይችላሉ ይህም የሚደረገው መጠን ጥቅም ላይ የደጀን.
/// ፕሮግራሞች በማንኛውም መንገድ *ትክክለኛነት* ለ `black_box` ላይ መተማመን አይችሉም.
///
/// [`std::convert::identity`]: crate::convert::identity
///
///
///
#[cfg_attr(not(miri), inline)]
#[cfg_attr(miri, inline(never))]
#[unstable(feature = "test", issue = "50297")]
#[cfg_attr(miri, allow(unused_mut))]
pub fn black_box<T>(mut dummy: T) -> T {
    // ክርክሩን በተወሰነ መንገድ LLVM ማስተዋወቅ በማይችልበት ሁኔታ "use" ማድረግ ያስፈልገናል ፣ እናም በሚደግፉት ዒላማዎች ላይ ይህንን ለማድረግ በተለምዶ የውስጠ-ጉባ assemblyን መጠቀሚያ ማድረግ እንችላለን ፡፡
    // የመስመር ውስጥ LLVM የሰጠው ትርጓሜ ክርስቲያን ነው, በደንብ, አንድ ጥቁር ሳጥን መሆኑ ነው.
    // ምናልባት ይበልጥ እኛ እንፈልጋለን በላይ deoptimizes ጀምሮ ይህ ታላቅ ትግበራ አይደለም, ነገር ግን እስካሁን ጥሩ በቂ ነው.
    //
    //

    #[cfg(not(miri))] // ይህ Miri ውስጥ መዝለል ጥሩ ነው, ስለዚህ ይህ ብቻ አንድ ፍንጭ ነው.
    // ደህንነት: የውስጥ መስመር ክርስቲያን no-op ነው.
    unsafe {
        // FIXME: X0 MIPS ን እና ሌሎች ሕንፃዎችን ስለማይደግፍ `asm!` ን መጠቀም አይቻልም።
        llvm_asm!("" : : "r"(&mut dummy) : "memory" : "volatile");
    }

    dummy
}