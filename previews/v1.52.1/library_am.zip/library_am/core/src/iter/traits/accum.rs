use crate::iter;
use crate::num::Wrapping;

/// አንድ ተደጋጋሚ ጠቅለል አድርጎ በመደመር ሊፈጥሩ የሚችሉ አይነቶችን ለመወከል Trait
///
/// ይህ trait የ [`sum()`] ዘዴን በመተላለፊያዎች ላይ ለመተግበር ያገለግላል።
/// trait ን የሚተገብሩ ዓይነቶች በ [`sum()`] ዘዴ ሊመነጩ ይችላሉ።
/// [`FromIterator`] ልክ በዚህ trait አልፎ በቀጥታ ተብሎ ይገባል ይልቅ [`Iterator::sum()`] አማካይነት ጋር ሃሳብ ተለዋውጦ ነበር.
///
///
/// [`sum()`]: Sum::sum
/// [`FromIterator`]: iter::FromIterator
#[stable(feature = "iter_arith_traits", since = "1.12.0")]
pub trait Sum<A = Self>: Sized {
    /// አንድ ለተደጋጋሚ ይወስዳል እና "summing up" ንጥሎች በ ንጥረ ነገሮች ከ `Self` ያመነጫል ይህም ዘዴ.
    ///
    #[stable(feature = "iter_arith_traits", since = "1.12.0")]
    fn sum<I: Iterator<Item = A>>(iter: I) -> Self;
}

/// Trait አንድ ለተደጋጋሚ ክፍሎችን በማባዛት ሊፈጠሩ የሚችሉ አይነቶች የሚወክሉ.
///
/// ይህ trait የ [`product()`] ዘዴን በአተላላፊዎች ላይ ለመተግበር ያገለግላል።
/// የ trait ለመተግበር ይህም አይነቶች [`product()`] ስልት የመነጨ ሊሆን ይችላል.
/// [`FromIterator`] ልክ በዚህ trait አልፎ በቀጥታ ተብሎ ይገባል ይልቅ [`Iterator::product()`] አማካይነት ጋር ሃሳብ ተለዋውጦ ነበር.
///
///
/// [`product()`]: Product::product
/// [`FromIterator`]: iter::FromIterator
///
#[stable(feature = "iter_arith_traits", since = "1.12.0")]
pub trait Product<A = Self>: Sized {
    /// አንድ ለተደጋጋሚ ይወስዳል እና ንጥሎች በማባዛት ንጥረ ነገሮች ከ `Self` ያመነጫል ይህም ዘዴ.
    ///
    #[stable(feature = "iter_arith_traits", since = "1.12.0")]
    fn product<I: Iterator<Item = A>>(iter: I) -> Self;
}

macro_rules! integer_sum_product {
    (@impls $zero:expr, $one:expr, #[$attr:meta], $($a:ty)*) => ($(
        #[$attr]
        impl Sum for $a {
            fn sum<I: Iterator<Item=Self>>(iter: I) -> Self {
                iter.fold(
                    $zero,
                    #[rustc_inherit_overflow_checks]
                    |a, b| a + b,
                )
            }
        }

        #[$attr]
        impl Product for $a {
            fn product<I: Iterator<Item=Self>>(iter: I) -> Self {
                iter.fold(
                    $one,
                    #[rustc_inherit_overflow_checks]
                    |a, b| a * b,
                )
            }
        }

        #[$attr]
        impl<'a> Sum<&'a $a> for $a {
            fn sum<I: Iterator<Item=&'a Self>>(iter: I) -> Self {
                iter.fold(
                    $zero,
                    #[rustc_inherit_overflow_checks]
                    |a, b| a + b,
                )
            }
        }

        #[$attr]
        impl<'a> Product<&'a $a> for $a {
            fn product<I: Iterator<Item=&'a Self>>(iter: I) -> Self {
                iter.fold(
                    $one,
                    #[rustc_inherit_overflow_checks]
                    |a, b| a * b,
                )
            }
        }
    )*);
    ($($a:ty)*) => (
        integer_sum_product!(@impls 0, 1,
                #[stable(feature = "iter_arith_traits", since = "1.12.0")],
                $($a)*);
        integer_sum_product!(@impls Wrapping(0), Wrapping(1),
                #[stable(feature = "wrapping_iter_arith", since = "1.14.0")],
                $(Wrapping<$a>)*);
    );
}

macro_rules! float_sum_product {
    ($($a:ident)*) => ($(
        #[stable(feature = "iter_arith_traits", since = "1.12.0")]
        impl Sum for $a {
            fn sum<I: Iterator<Item=Self>>(iter: I) -> Self {
                iter.fold(
                    0.0,
                    #[rustc_inherit_overflow_checks]
                    |a, b| a + b,
                )
            }
        }

        #[stable(feature = "iter_arith_traits", since = "1.12.0")]
        impl Product for $a {
            fn product<I: Iterator<Item=Self>>(iter: I) -> Self {
                iter.fold(
                    1.0,
                    #[rustc_inherit_overflow_checks]
                    |a, b| a * b,
                )
            }
        }

        #[stable(feature = "iter_arith_traits", since = "1.12.0")]
        impl<'a> Sum<&'a $a> for $a {
            fn sum<I: Iterator<Item=&'a Self>>(iter: I) -> Self {
                iter.fold(
                    0.0,
                    #[rustc_inherit_overflow_checks]
                    |a, b| a + b,
                )
            }
        }

        #[stable(feature = "iter_arith_traits", since = "1.12.0")]
        impl<'a> Product<&'a $a> for $a {
            fn product<I: Iterator<Item=&'a Self>>(iter: I) -> Self {
                iter.fold(
                    1.0,
                    #[rustc_inherit_overflow_checks]
                    |a, b| a * b,
                )
            }
        }
    )*)
}

integer_sum_product! { i8 i16 i32 i64 i128 isize u8 u16 u32 u64 u128 usize }
float_sum_product! { f32 f64 }

#[stable(feature = "iter_arith_traits_result", since = "1.16.0")]
impl<T, U, E> Sum<Result<U, E>> for Result<T, E>
where
    T: Sum<U>,
{
    /// በ [`Iterator`] ውስጥ እያንዳንዱ አባል ይጠይቃል; ይህም አንድ [`Err`] ከሆነ, ምንም ተጨማሪ ክፍሎችን የተወሰዱ ናቸው, እና [`Err`] ተመልሶ ነው.
    /// ምንም [`Err`] መከሰት የለበትም ፣ የሁሉም አካላት ድምር ተመልሷል።
    ///
    /// # Examples
    ///
    /// አንድ አሉታዊ አባል አጋጥሞታል ከሆነ ድምር ባለመቀበሉ አንድ vector ውስጥ እያንዳንዱ ኢንቲጀር እስከ ይህ ድምሮች:
    ///
    /// ```
    /// let v = vec![1, 2];
    /// let res: Result<i32, &'static str> = v.iter().map(|&x: &i32|
    ///     if x < 0 { Err("Negative element found") }
    ///     else { Ok(x) }
    /// ).sum();
    /// assert_eq!(res, Ok(3));
    /// ```
    ///
    ///
    fn sum<I>(iter: I) -> Result<T, E>
    where
        I: Iterator<Item = Result<U, E>>,
    {
        iter::process_results(iter, |i| i.sum())
    }
}

#[stable(feature = "iter_arith_traits_result", since = "1.16.0")]
impl<T, U, E> Product<Result<U, E>> for Result<T, E>
where
    T: Product<U>,
{
    /// በ [`Iterator`] ውስጥ እያንዳንዱ አባል ይጠይቃል; ይህም አንድ [`Err`] ከሆነ, ምንም ተጨማሪ ክፍሎችን የተወሰዱ ናቸው, እና [`Err`] ተመልሶ ነው.
    /// ምንም [`Err`] ሊከሰት ይገባል, ሁሉንም ነገሮች መካከል ያለውን ምርት ተመልሶ ነው.
    ///
    fn product<I>(iter: I) -> Result<T, E>
    where
        I: Iterator<Item = Result<U, E>>,
    {
        iter::process_results(iter, |i| i.product())
    }
}

#[stable(feature = "iter_arith_traits_option", since = "1.37.0")]
impl<T, U> Sum<Option<U>> for Option<T>
where
    T: Sum<U>,
{
    /// እያንዳንዱን ንጥረ ነገር በ [`Iterator`] ውስጥ ይወስዳል-[`None`] ከሆነ ተጨማሪ ንጥረ ነገሮች አይወሰዱም እና [`None`] ተመልሷል።
    /// ምንም [`None`] ሊከሰት ይገባል, ሁሉንም ነገሮች ድምር ተመልሶ ነው.
    ///
    /// # Examples
    ///
    /// ጥገናው `None` ይመልሳል አንድ ቃል ቁምፊ 'a' የላቸውም ነበር ኖሮ ሕብረ አንድ vector ውስጥ ቁምፊ 'a' ያለውን ቦታ, እስከ ይህ ድምሮች:
    ///
    ///
    /// ```
    /// let words = vec!["have", "a", "great", "day"];
    /// let total: Option<usize> = words.iter().map(|w| w.find('a')).sum();
    /// assert_eq!(total, Some(5));
    /// ```
    ///
    fn sum<I>(iter: I) -> Option<T>
    where
        I: Iterator<Item = Option<U>>,
    {
        iter.map(|x| x.ok_or(())).sum::<Result<_, _>>().ok()
    }
}

#[stable(feature = "iter_arith_traits_option", since = "1.37.0")]
impl<T, U> Product<Option<U>> for Option<T>
where
    T: Product<U>,
{
    /// እያንዳንዱን ንጥረ ነገር በ [`Iterator`] ውስጥ ይወስዳል-[`None`] ከሆነ ተጨማሪ ንጥረ ነገሮች አይወሰዱም እና [`None`] ተመልሷል።
    /// ምንም [`None`] ሊከሰት ይገባል, ሁሉንም ነገሮች መካከል ያለውን ምርት ተመልሶ ነው.
    ///
    fn product<I>(iter: I) -> Option<T>
    where
        I: Iterator<Item = Option<U>>,
    {
        iter.map(|x| x.ok_or(())).product::<Result<_, _>>().ok()
    }
}