// ችላ-ንጹህ-filelength ይህ ፋይል ማለት ይቻላል ብቻ `Iterator` ፍቺ ያቀፈ ነው.
// እኛም በርካታ ፋይሎችን ወደ እንደሆነ ለሁለት አይችልም.
//

use crate::cmp::{self, Ordering};
use crate::ops::{ControlFlow, Try};

use super::super::TrustedRandomAccess;
use super::super::{Chain, Cloned, Copied, Cycle, Enumerate, Filter, FilterMap, Fuse};
use super::super::{FlatMap, Flatten};
use super::super::{FromIterator, Intersperse, IntersperseWith, Product, Sum, Zip};
use super::super::{
    Inspect, Map, MapWhile, Peekable, Rev, Scan, Skip, SkipWhile, StepBy, Take, TakeWhile,
};

fn _assert_is_object_safe(_: &dyn Iterator<Item = ()>) {}

/// iterators ጋር በተያያዘ ምክንያት አንድ በይነገጽ.
///
/// ይህ ዋናው ለተደጋጋሚ trait ነው.
/// በአጠቃላይ ስለ ተጓtorsች ፅንሰ-ሀሳብ የበለጠ እባክዎን [module-level documentation] ን ይመልከቱ ፡፡
/// በተለይም, እናንተ እንዴት [implement `Iterator`][impl] ማወቅ ትፈልግ ይሆናል.
///
/// [module-level documentation]: crate::iter
/// [impl]: crate::iter#implementing-iterator
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    on(
        _Self = "[std::ops::Range<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..end]` is an array of one `Range`; you might have meant to have a `Range` \
                without the brackets: `start..end`"
    ),
    on(
        _Self = "[std::ops::RangeFrom<Idx>; 1]",
        label = "if you meant to iterate from a value onwards, remove the square brackets",
        note = "`[start..]` is an array of one `RangeFrom`; you might have meant to have a \
              `RangeFrom` without the brackets: `start..`, keeping in mind that iterating over an \
              unbounded iterator will run forever unless you `break` or `return` from within the \
              loop"
    ),
    on(
        _Self = "[std::ops::RangeTo<Idx>; 1]",
        label = "if you meant to iterate until a value, remove the square brackets and add a \
                 starting value",
        note = "`[..end]` is an array of one `RangeTo`; you might have meant to have a bounded \
                `Range` without the brackets: `0..end`"
    ),
    on(
        _Self = "[std::ops::RangeInclusive<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..=end]` is an array of one `RangeInclusive`; you might have meant to have a \
              `RangeInclusive` without the brackets: `start..=end`"
    ),
    on(
        _Self = "[std::ops::RangeToInclusive<Idx>; 1]",
        label = "if you meant to iterate until a value (including it), remove the square brackets \
                 and add a starting value",
        note = "`[..=end]` is an array of one `RangeToInclusive`; you might have meant to have a \
                bounded `RangeInclusive` without the brackets: `0..=end`"
    ),
    on(
        _Self = "std::ops::RangeTo<Idx>",
        label = "if you meant to iterate until a value, add a starting value",
        note = "`..end` is a `RangeTo`, which cannot be iterated on; you might have meant to have a \
              bounded `Range`: `0..end`"
    ),
    on(
        _Self = "std::ops::RangeToInclusive<Idx>",
        label = "if you meant to iterate until a value (including it), add a starting value",
        note = "`..=end` is a `RangeToInclusive`, which cannot be iterated on; you might have meant \
              to have a bounded `RangeInclusive`: `0..=end`"
    ),
    on(
        _Self = "&str",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "std::string::String",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "[]",
        label = "borrow the array with `&` or call `.iter()` on it to iterate over it",
        note = "arrays are not iterators, but slices like the following are: `&[1, 2, 3]`"
    ),
    on(
        _Self = "{integral}",
        note = "if you want to iterate between `start` until a value `end`, use the exclusive range \
              syntax `start..end` or the inclusive range syntax `start..=end`"
    ),
    label = "`{Self}` is not an iterator",
    message = "`{Self}` is not an iterator"
)]
#[doc(spotlight)]
#[rustc_diagnostic_item = "Iterator"]
#[must_use = "iterators are lazy and do nothing unless consumed"]
pub trait Iterator {
    /// ንጥረ ነገሮች አይነት ላይ iterated እየተደረገ.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// የ ለተደጋጋሚ እድገቶች እና በሚቀጥለው እሴት ይመልሳል.
    ///
    /// ተደጋጋሚነት ሲጠናቀቅ [`None`] ያወጣል.
    /// የግለሰብ ተደጋጋሚ አመልካቾች አተገባበር ድግግሞሽን እንደገና ለመቀጠል ሊመርጡ ይችላሉ ፣ ስለሆነም `next()` ን እንደገና መጥራት በተወሰነ ጊዜ ላይ እንደገና [`Some(Item)`] ን መመለስ ሊጀምር ወይም ላይጀምር ይችላል።
    ///
    ///
    /// [`Some(Item)`]: Some
    ///
    /// # Examples
    ///
    /// መሠረታዊ አጠቃቀም
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // next() ወደ አንድ ጥሪ በሚቀጥለው እሴት ይመልሳል ...
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    ///
    /// // ... ከዚያም የለም አንድ ጊዜ ላይ ነው.
    /// assert_eq!(None, iter.next());
    ///
    /// // ተጨማሪ ጥሪዎች ወይም `None` መመለስ ይችላሉ ይችላል አይደለም.እነሆ, እነሱ ሁልጊዜ ያደርጋል.
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[lang = "next"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next(&mut self) -> Option<Self::Item>;

    /// ወደ ለተደጋጋሚ የቀሩትን ርዝመት ላይ መደበላቸው ይመልሳል.
    ///
    /// በተለይም, `size_hint()` የመጀመሪያው ንጥረ ነገር ያለው የታችኛው ገደብ በሌለበት አንድ tuple ይመልሳል, እና ሁለተኛው አባል በላይኛው የታሰረች ናት.
    ///
    /// ተመልሶ እንደሆነ tuple ሁለተኛ ግማሽ ነው አንድ [`Option`]`<`[`usize`] `>`.
    /// አንድ እዚህ [`None`] ምንም የለም የሚታወቅ ነው ወይ ማለት የላይኛው ገደብ, ወይም በላይኛው ታስሮ ወደ [`usize`] በላይ ነው.
    ///
    /// # የትግበራ ማስታወሻዎች
    ///
    /// አንድ ለተደጋጋሚ አፈፃፀም ኃይሎች አወጀ ቁጥር ያፈራላቸዋል መሆኑን ተፈጻሚ አይሆንም.ተጓዥ ተደጋጋፊ ከዝቅተኛ ወሰን በታች ወይም ከከፍተኛው ንጥረ ነገሮች በላይ ሊያወጣ ይችላል።
    ///
    /// `size_hint()` በዋናነት ለተመልካቹ ንጥረ ነገሮች ቦታ ማስያዝን ለማመቻቸት ጥቅም ላይ እንዲውል የታቀደ ነው ፣ ነገር ግን ለምሳሌ ደህንነቱ ባልተጠበቀ ኮድ ውስጥ ቼኮችን ይተው ፡፡
    /// `size_hint()` ትክክል ያልሆነ አፈጻጸም ትውስታ ደህንነት ጥሰት ሊያስከትል አይገባም.
    ///
    /// ያ ማለት ፣ አተገባበሩ ትክክለኛ ግምትን መስጠት አለበት ፣ ምክንያቱም ይህ ካልሆነ የ trait ፕሮቶኮልን መጣስ ይሆናል።
    ///
    /// ነባሪ አፈፃፀም ይመለሳል `(0,` [`None`]`)`ማንኛውም ለተደጋጋሚ ትክክል ነው.
    ///
    /// [`usize`]: type@usize
    ///
    /// # Examples
    ///
    /// መሠረታዊ አጠቃቀም
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let iter = a.iter();
    ///
    /// assert_eq!((3, Some(3)), iter.size_hint());
    /// ```
    ///
    /// የበለጠ ውስብስብ ምሳሌ
    ///
    /// ```
    /// // ከዜሮ እስከ አሥር ወደ እንኳ ቁጥሮች.
    /// let iter = (0..10).filter(|x| x % 2 == 0);
    ///
    /// // ከዜሮ ወደ አሥር ጊዜ ልንመዝነው እንችላለን ፡፡
    /// // አምስት ከሆነ በትክክል ማወቅ filter() ን ሳይፈጽም አይቻልም ፡፡
    /// assert_eq!((0, Some(10)), iter.size_hint());
    ///
    /// // ዎቹ chain() ጋር አምስት ተጨማሪ ቁጥሮች ለማከል እንመልከት
    /// let iter = (0..10).filter(|x| x % 2 == 0).chain(15..20);
    ///
    /// // አሁን ሁለቱም ወሰንን አምስት ጨምረዋል ነው
    /// assert_eq!((5, Some(15)), iter.size_hint());
    /// ```
    ///
    /// በደርብ ታሰረ ለ `None` በመመለስ:
    ///
    /// ```
    /// // ማለቂያ የሌለው ተደጋጋሚ የከፍተኛ ወሰን እና የሚቻለው ዝቅተኛ ወሰን የለውም
    /////
    /// let iter = 0..;
    ///
    /// assert_eq!((usize::MAX, None), iter.size_hint());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }

    /// ድግግሞሾች ቁጥር በመቁጠር እና መመለስ, ወደ ለተደጋጋሚ ተቆጣጥሮታል.
    ///
    /// [`None`] አጋጥሞታል ድረስ ይህ ዘዴ ነው [`Some`] አየሁ ጊዜ ቁጥር ሲመለሱ, በተደጋጋሚ [`next`] እጠራለሁ.
    /// የ ለተደጋጋሚ ማንኛውም ንጥረ ነገሮች የሉትም እንኳ [`next`] በአንድ ቢያንስ ተብሎ መሆኑን ልብ በል.
    ///
    /// [`next`]: Iterator::next
    ///
    /// # የትርፍ ፍሰት ባህሪ
    ///
    /// ያለው ዘዴ በጣም የበለጠ [`usize::MAX`] በላይ አባሎች ጋር ለተደጋጋሚ ክፍሎችን በመቁጠር ወይ የተሳሳተ ውጤት ወይም panics ያፈራል, ያጥለቀልቁታል ላይ ምንም የሚወድዱትን ነው.
    ///
    /// የስህተት ማረጋገጫዎች ከነቁ አንድ panic ዋስትና ተሰጥቶታል።
    ///
    /// # Panics
    ///
    /// ተደጋጋሚው ከ [`usize::MAX`] አካላት በላይ ካለው ይህ ተግባር panic ን ሊያደርገው ይችላል።
    ///
    /// # Examples
    ///
    /// መሠረታዊ አጠቃቀም
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().count(), 3);
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().count(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn count(self) -> usize
    where
        Self: Sized,
    {
        self.fold(
            0,
            #[rustc_inherit_overflow_checks]
            |count, _| count + 1,
        )
    }

    /// የመጨረሻው አባል ሲመለሱ, የ ለተደጋጋሚ ተቆጣጥሮታል.
    ///
    /// ይህ [`None`] እስኪመለስ ድረስ ይህ ዘዴ ለተደጋጋሚ እንገመግማለን.
    /// ይህን በማድረግ ቢሆንም, የአሁኑ አባል ለመከታተል ይጠብቃል.
    /// [`None`] ከተመለሰ በኋላ `last()` ያየውን የመጨረሻውን ንጥረ ነገር ይመልሳል።
    ///
    /// # Examples
    ///
    /// መሠረታዊ አጠቃቀም
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().last(), Some(&3));
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().last(), Some(&5));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn last(self) -> Option<Self::Item>
    where
        Self: Sized,
    {
        #[inline]
        fn some<T>(_: Option<T>, x: T) -> Option<T> {
            Some(x)
        }

        self.fold(None, some)
    }

    /// `n` አባሎች በማድረግ ለተደጋጋሚ ያስፋፋል.
    ///
    /// ይህ ዘዴ [`None`] እስከሚደርስ ድረስ [`next`] ን እስከ `n` ጊዜ ድረስ በመደወል የ `n` አባላትን በጉጉት ይተዋል ፡፡
    ///
    /// `advance_by(n)` የ ለተደጋጋሚ በተሳካ [`None`] `k` ወደ ለተደጋጋሚ ከፍተኛ ነው ንጥረ ቁጥር ባለበት አጋጥሞታል ከሆነ `n` ንጥረ ነገሮች በማድረግ የሚያራምድ, ወይም [`Err(k)`][Err] ከሆነ በ አባሎችን እያለቀ በፊት [`Ok(())`][Ok] ይመለሳሉ (ማለትም
    /// ወደ ለተደጋጋሚ ርዝመት).
    /// `k` ሁልጊዜ ያነሰ `n` በላይ መሆኑን ልብ ይበሉ.
    ///
    /// በመደወል `advance_by(0)` ማንኛውንም ንጥረ ነገሮች ነው የሚጠቀሙት, እና ሁልጊዜ [`Ok(())`][Ok] ይመልሳል አይደለም.
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// መሠረታዊ አጠቃቀም
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_by(2), Ok(()));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.advance_by(0), Ok(()));
    /// assert_eq!(iter.advance_by(100), Err(1)); // ብቻ `&4` ተዘልሏል ነበር
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next().ok_or(i)?;
        }
        Ok(())
    }

    /// ይመልሳል ለተደጋጋሚ ያለውን `n`th አባል.
    ///
    /// እንደ አብዛኛው ማውጫ ሥራዎች ፣ ቆጠራው ከዜሮ ይጀምራል ፣ ስለሆነም `nth(0)` የመጀመሪያውን እሴት ፣ `nth(1)` ሁለተኛውን እና የመሳሰሉትን ይመልሳል።
    ///
    /// ሁሉንም ባለፈው ክፍሎች, እንዲሁም ተመልሶ አባል, የ ለተደጋጋሚ ከ ፍጆታ ይደረጋል መሆኑን ልብ በል.
    /// ያ ማለት የቀደሙት አካላት ይጣላሉ ፣ እንዲሁም በተመሳሳይ ድግግሞሽ ላይ `nth(0)` ን ብዙ ጊዜ መጥራት የተለያዩ አባላትን ይመልሳል።
    ///
    ///
    /// `nth()` `n` የሚበልጥ ወይም ለተደጋጋሚ ርዝመት ጋር እኩል ከሆነ [`None`] ይመለሳሉ.
    ///
    /// # Examples
    ///
    /// መሠረታዊ አጠቃቀም
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(1), Some(&2));
    /// ```
    ///
    /// `nth()` በርካታ ጊዜ በመደወል የ ለተደጋጋሚ እንሚሆን አይደለም:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth(1), Some(&2));
    /// assert_eq!(iter.nth(1), None);
    /// ```
    ///
    /// `n + 1` ክፍሎች በታች ካሉ `None` በመመለስ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(10), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_by(n).ok()?;
        self.next()
    }

    /// አንድ ለተደጋጋሚ ተመሳሳይ ነጥብ ላይ ጀምሮ, ነገር ግን እያንዳንዱ ተደጋጋሚነት ላይ የተሰጠውን መጠን እየተጋፋ ይፈጥራል.
    ///
    /// ማስታወሻ 1: ለተደጋጋሚ የመጀመሪያ አባል ሁልጊዜ ሳያስገባ ከተሰጠው እርምጃ የተነሳ, ይመለሳል.
    ///
    /// ማስታወሻ 2: ችላ ንጥረ የተወሰነ አይደለም አፈረሰ ናቸው ላይ ያለው ሰዓት.
    /// `StepBy` በ ቅደም ተከተል `next(), nth(step-1), nth(step-1),…` እንደ የሚሰራበት, ነገር ግን ደግሞ ነጻ ነው ተከተል እኩዮቹን ደግሞ እንደ
    ///
    /// `advance_n_and_return_first(step), advance_n_and_return_first(step), …`
    /// በአፈፃፀም ምክንያቶች የትኛውን መንገድ ጥቅም ላይ እንደሚውል ለአንዳንድ ተጓeraች ሊለወጥ ይችላል ፡፡
    /// ሁለተኛው መንገድ ቀደም ሲል ወደ ለተደጋጋሚ ለማራመድ እና ተጨማሪ ንጥሎች ሊፈጁ ይችላሉ.
    ///
    /// `advance_n_and_return_first` እኩል ነው:
    ///
    /// ```
    /// fn advance_n_and_return_first<I>(iter: &mut I, total_step: usize) -> Option<I::Item>
    /// where
    ///     I: Iterator,
    /// {
    ///     let next = iter.next();
    ///     if total_step > 1 {
    ///         iter.nth(total_step-2);
    ///     }
    ///     next
    /// }
    /// ```
    ///
    /// # Panics
    ///
    /// የተሰጠው እርምጃ `0` ከሆነ ዘዴው panic ን ያደርገዋል።
    ///
    /// # Examples
    ///
    /// መሠረታዊ አጠቃቀም
    ///
    /// ```
    /// let a = [0, 1, 2, 3, 4, 5];
    /// let mut iter = a.iter().step_by(2);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_step_by", since = "1.28.0")]
    fn step_by(self, step: usize) -> StepBy<Self>
    where
        Self: Sized,
    {
        StepBy::new(self, step)
    }

    /// ሁለት ተጓeraችን ይወስዳል እና በሁለቱም ላይ በቅደም ተከተል አዲስ ተደጋጋሚ ይፈጥራል።
    ///
    /// `chain()` በመጀመሪያ የመጀመሪያው ለተደጋጋሚ ጀምሮ ከዚያም ሁለተኛ ለተደጋጋሚ የእሴቶች በላይ እሴቶች ላይ ለመድገም, ይህም አዲስ ለተደጋጋሚ ይመለሳል.
    ///
    /// በሌላ አገላለጽ ሁለት ተጓዥዎችን በአንድ ላይ በሰንሰለት ያገናኛል ፡፡🔗
    ///
    /// [`once`] በተለምዶ ተደጋጋሚነት ሌሎች ዓይነት አንድ ሰንሰለት ወደ አንድ ነጠላ ዋጋ መላመድ ላይ ይውላል.
    ///
    /// # Examples
    ///
    /// መሠረታዊ አጠቃቀም
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().chain(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// ወደ‹`chain()`›ክርክር [`IntoIterator`] ን ስለሚጠቀም ፣ እሱ ራሱ [`Iterator`] ብቻ ሳይሆን ወደ [`Iterator`] ሊቀየር የሚችል ማንኛውንም ነገር ማለፍ እንችላለን ፡፡
    /// ለምሳሌ ያህል, (`&[T]`) [`IntoIterator`] ለመተግበር, እና በቀጥታ `chain()` ሊተላለፍ ይችላል ከውስጡም:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().chain(s2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// እርስዎ Windows ኤ ጋር ለመስራት ከሆነ, `Vec<u16>` ወደ [`OsStr`] ለመቀየር ከፈለጉ ይችላሉ:
    ///
    /// ```
    /// #[cfg(windows)]
    /// fn os_str_to_utf16(s: &std::ffi::OsStr) -> Vec<u16> {
    ///     use std::os::windows::ffi::OsStrExt;
    ///     s.encode_wide().chain(std::iter::once(0)).collect()
    /// }
    /// ```
    ///
    /// [`once`]: crate::iter::once
    /// [`OsStr`]: ../../std/ffi/struct.OsStr.html
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn chain<U>(self, other: U) -> Chain<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator<Item = Self::Item>,
    {
        Chain::new(self, other.into_iter())
    }

    /// ሁለት ተጓeraችን `ዚፕስ አፕ` ወደ አንድ ነጠላ ጥንድ ተደጋጋፊ ፡፡
    ///
    /// `zip()` ከመጀመሪያው ንጥረ-ነገር የመጀመሪያው ንጥረ-ነገር የሚመጣበትን እና ሁለተኛው ንጥረ-ነገር ደግሞ ከሁለተኛው ተስተካካይ የሚመጣበትን ሁለት ተጓ itችን የሚመልስ አዲስ ተደጋጋሚ ይመልሳል ፡፡
    ///
    ///
    /// በሌላ አነጋገር, አንድ ነጠላ ሰው ወደ በአንድነት ሁለት iterators ቧጨራዎችን.
    ///
    /// ወይ ለተደጋጋሚ ወደ ዚፕ ጀምሮ [`None`], [`next`] በሚመለስበት ከሆነ ለተደጋጋሚ [`None`] ይመለሳሉ.
    /// የመጀመሪያው ተንታኝ [`None`] ን ከተመለሰ ፣ `zip` አጭር ዙር እና `next` በሁለተኛው ተደጋጋሚ ላይ አይጠራም።
    ///
    /// # Examples
    ///
    /// መሠረታዊ አጠቃቀም
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().zip(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// ወደ‹`zip()`›ክርክር [`IntoIterator`] ን ስለሚጠቀም ፣ እሱ ራሱ [`Iterator`] ብቻ ሳይሆን ወደ [`Iterator`] ሊቀየር የሚችል ማንኛውንም ነገር ማለፍ እንችላለን ፡፡
    /// ለምሳሌ ፣ (`&[T]`) ቁርጥራጭ [`IntoIterator`] ን ይተገበራል ፣ እና ስለዚህ በቀጥታ ወደ `zip()` ሊተላለፍ ይችላል
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().zip(s2);
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `zip()` ብዙውን ጊዜ ጋዝም ሰው አንድ የሌለው ለተደጋጋሚ ዚፕ ጥቅም ላይ ይውላል.
    /// የ ጋዝም ለተደጋጋሚ ከጊዜ በኋላ ዚፔር ለማጥፋት, [`None`] ይመለሳሉ ምክንያቱም ይሰራል.`(0..)` ጋር በማጨቅ [`enumerate`] የሚመስል ብዙ ነገር መመልከት ይችላሉ:
    ///
    /// ```
    /// let enumerate: Vec<_> = "foo".chars().enumerate().collect();
    ///
    /// let zipper: Vec<_> = (0..).zip("foo".chars()).collect();
    ///
    /// assert_eq!((0, 'f'), enumerate[0]);
    /// assert_eq!((0, 'f'), zipper[0]);
    ///
    /// assert_eq!((1, 'o'), enumerate[1]);
    /// assert_eq!((1, 'o'), zipper[1]);
    ///
    /// assert_eq!((2, 'o'), enumerate[2]);
    /// assert_eq!((2, 'o'), zipper[2]);
    /// ```
    ///
    /// [`enumerate`]: Iterator::enumerate
    /// [`next`]: Iterator::next
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn zip<U>(self, other: U) -> Zip<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator,
    {
        Zip::new(self, other.into_iter())
    }

    /// የመጀመሪያውን ለተደጋጋሚ መካከል ከጎን ዕቃዎች መካከል `separator` ቅጂ ቦታዎች ይህም አዲስ ለተደጋጋሚ ይፈጥራል.
    ///
    /// ሁኔታ `separator` [`Clone`] ወይም ፍላጎቶች ሁሉ ጊዜ ሊሰላ ወደ ተግባራዊ አይደለም, [`intersperse_with`] ይጠቀሙ.
    ///
    ///
    /// # Examples
    ///
    /// መሠረታዊ አጠቃቀም
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let mut a = [0, 1, 2].iter().intersperse(&100);
    /// assert_eq!(a.next(), Some(&0));   // የመጀመሪያው ንጥረ ነገር ከ `a`።
    /// assert_eq!(a.next(), Some(&100)); // በ SEPARATOR.
    /// assert_eq!(a.next(), Some(&1));   // `a` ከ ቀጣዩ አባል.
    /// assert_eq!(a.next(), Some(&100)); // በ SEPARATOR.
    /// assert_eq!(a.next(), Some(&2));   // `a` ከ የመጨረሻው አባል.
    /// assert_eq!(a.next(), None);       // የ ለተደጋጋሚ ተጠናቅቋል ነው.
    /// ```
    ///
    /// `intersperse` አንድ የጋራ አባል በመጠቀም አንድ ለተደጋጋሚ ንጥሎች ለመቀላቀል በጣም ጠቃሚ ሊሆን ይችላል:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let hello = ["Hello", "World", "!"].iter().copied().intersperse(" ").collect::<String>();
    /// assert_eq!(hello, "Hello World !");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse_with`]: Iterator::intersperse_with
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse(self, separator: Self::Item) -> Intersperse<Self>
    where
        Self: Sized,
        Self::Item: Clone,
    {
        Intersperse::new(self, separator)
    }

    /// ከመጀመሪያው ተደጋጋሚ አቅራቢያ ባሉ ንጥሎች መካከል በ `separator` የተፈጠረ ንጥል የሚያኖር አዲስ ተደጋጋሚ ይፈጥራል።
    ///
    /// የ መዘጋት በትክክል ይባላል አንድ ንጥል ከስር ለተደጋጋሚ የመጡ ሁለት ከጎን ያሉት ንጥሎች መካከል መቀመጡን በእያንዳንዱ ጊዜ አንድ ጊዜ;
    /// በተለይም ከስር ያለው ተደጋጋሚ ጠቋሚ ከሁለት እቃዎች በታች ከሆነ እና የመጨረሻው እቃ ከተሰጠ በኋላ መዘጋቱ አይጠራም ፡፡
    ///
    ///
    /// የተደጋጋሚው ነገር [`Clone`] ን ከተተገበረ [`intersperse`] ን መጠቀም ቀላል ሊሆን ይችላል።
    ///
    /// # Examples
    ///
    /// መሠረታዊ አጠቃቀም
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// #[derive(PartialEq, Debug)]
    /// struct NotClone(usize);
    ///
    /// let v = vec![NotClone(0), NotClone(1), NotClone(2)];
    /// let mut it = v.into_iter().intersperse_with(|| NotClone(99));
    ///
    /// assert_eq!(it.next(), Some(NotClone(0)));  // `v` ከ የመጀመሪያው አባል.
    /// assert_eq!(it.next(), Some(NotClone(99))); // በ SEPARATOR.
    /// assert_eq!(it.next(), Some(NotClone(1)));  // የሚቀጥለው ንጥረ ነገር ከ `v`።
    /// assert_eq!(it.next(), Some(NotClone(99))); // በ SEPARATOR.
    /// assert_eq!(it.next(), Some(NotClone(2)));  // `v` ጀምሮ እስከ የመጨረሻው አባል.
    /// assert_eq!(it.next(), None);               // የ ለተደጋጋሚ ተጠናቅቋል ነው.
    /// ```
    ///
    /// `intersperse_with` በ SEPARATOR ሊሰላ አለበት የት ሁኔታዎች ላይ ጥቅም ላይ ሊውል ይችላል:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let src = ["Hello", "to", "all", "people", "!!"].iter().copied();
    ///
    /// // የ መዘጋት mutably አንድ ንጥል ለማመንጨት በጥቅሱ ይበደራል.
    /// let mut happy_emojis = [" ❤️ ", " 😀 "].iter().copied();
    /// let separator = || happy_emojis.next().unwrap_or(" 🦀 ");
    ///
    /// let result = src.intersperse_with(separator).collect::<String>();
    /// assert_eq!(result, "Hello ❤️ to 😀 all 🦀 people 🦀 !!");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse`]: Iterator::intersperse
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse_with<G>(self, separator: G) -> IntersperseWith<Self, G>
    where
        Self: Sized,
        G: FnMut() -> Self::Item,
    {
        IntersperseWith::new(self, separator)
    }

    /// አንድ መዘጋት የሚወስደው እና በእያንዳንዱ አባል ላይ እንደሆነ መዘጋት የሚጠራው ይህም አንድ ለተደጋጋሚ ይፈጥራል.
    ///
    /// `map()` በውስጡ ክርክር አማካኝነት, ወደ ሌላ አንድ ለተደጋጋሚ ይቀይራቸዋል:
    /// [`FnMut`] የሚያስፈጽም ነገር.ይህም የመጀመሪያውን ለተደጋጋሚ በእያንዳንዱ ኤለመንት ላይ ይህን መዘጋት የሚጠራው ይህም አዲስ ለተደጋጋሚ ያፈራል.
    ///
    /// እናንተ አይነቶች ላይ ማሰብ ጥሩ ነው ከሆነ, ይህን እንደ `map()` ማሰብ ይችላሉ:
    /// እርስዎ አንዳንድ ዓይነት `A` ክፍሎችን የሚሰጥ አንድ ለተደጋጋሚ አለን, እና ሌሎች ዓይነት `B` አንድ ለተደጋጋሚ ከፈለጉ, አንድ `A` የሚወስድ እና `B` ይመልሳል የሆነ መዘጋት በማለፍ, `map()` መጠቀም ይችላሉ.
    ///
    ///
    /// `map()` ከ‹XXXX loop›ጋር በሐሳብ ደረጃ ተመሳሳይ ነው ፡፡`map()` ሰነፍ ነው እንደ አስቀድመው ሌሎች iterators ጋር እየሰራን ጊዜ ይሁን, የተሻለ ጥቅም ነው.
    /// አንድ ጎን ውጤት ለማግኘት ተወርዋሪ አንዳንድ ዓይነት እየሰሩ ከሆነ `map()` ይልቅ [`for`] ለመጠቀም የበለጠ የአነጋገር ዘይቤ ተደርጎ ነው.
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    /// [`FnMut`]: crate::ops::FnMut
    ///
    /// # Examples
    ///
    /// መሠረታዊ አጠቃቀም
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().map(|x| 2 * x);
    ///
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), Some(6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// አንድ ዓይነት የጎንዮሽ ጉዳት እያደረጉ ከሆነ [`for`] ን ከ `map()` ይመርጡ
    ///
    /// ```
    /// # #![allow(unused_must_use)]
    /// // ይህንን አታድርግ
    /// (0..5).map(|x| println!("{}", x));
    ///
    /// // ይህ ሰነፍ ነው እንደ እንኳ, ያስፈጽማል አይደለም.Rust ይህን በተመለከተ አሳያችኋለሁ.
    ///
    /// // ይልቁንስ የሚከተሉትን ይጠቀሙ
    /// for x in 0..5 {
    ///     println!("{}", x);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn map<B, F>(self, f: F) -> Map<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> B,
    {
        Map::new(self, f)
    }

    /// አንድ ለተደጋጋሚ በእያንዳንዱ አባል ላይ አንድ መዘጋት ይጠራዋል.
    ///
    /// `break` እና `continue` አንድ መዘጋት የሚቻል አይደለም ናቸው ቢሆንም ይህም ለተደጋጋሚ ላይ [`for`] ሉፕ መጠቀም ጋር እኩል ነው.
    /// የ `for` loop ን መጠቀሙ በአጠቃላይ የበለጠ ፈሊጥ ነው ፣ ግን ረዘም ያለ የእንደገና ሰንሰለቶች መጨረሻ ላይ እቃዎችን ሲሰሩ `for_each` የበለጠ ሊነበብ ይችላል።
    ///
    /// በአንዳንድ አጋጣሚዎች `for_each` እንዲሁ ከአንድ ዑደት የበለጠ ፈጣን ሊሆን ይችላል ፣ ምክንያቱም እንደ `Chain` ባሉ አስማሚዎች ላይ ውስጣዊ ድግግሞሽን ይጠቀማል ፡፡
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// # Examples
    ///
    /// መሠረታዊ አጠቃቀም
    ///
    /// ```
    /// use std::sync::mpsc::channel;
    ///
    /// let (tx, rx) = channel();
    /// (0..5).map(|x| x * 2 + 1)
    ///       .for_each(move |x| tx.send(x).unwrap());
    ///
    /// let v: Vec<_> =  rx.iter().collect();
    /// assert_eq!(v, vec![1, 3, 5, 7, 9]);
    /// ```
    ///
    /// እንደዚህ ያለ ትንሽ ለምሳሌ ያህል, አንድ `for` ቅየራ ምልልስ ንጹሕ ሊሆን ይችላል, ነገር ግን `for_each` ረዘም iterators ጋር አንድ ተግባራዊ ቅጥ ለመጠበቅ ይመረጣል ሊሆን ይችላል:
    ///
    /// ```
    /// (0..5).flat_map(|x| x * 100 .. x * 110)
    ///       .enumerate()
    ///       .filter(|&(i, x)| (i + x) % 3 == 0)
    ///       .for_each(|(i, x)| println!("{}:{}", i, x));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_for_each", since = "1.21.0")]
    fn for_each<F>(self, f: F)
    where
        Self: Sized,
        F: FnMut(Self::Item),
    {
        #[inline]
        fn call<T>(mut f: impl FnMut(T)) -> impl FnMut((), T) {
            move |(), item| f(item)
        }

        self.fold((), call(f));
    }

    /// አንድ አባል አፈራ እንዳለበት ለመወሰን አንድ መዘጋት የሚጠቀም አንድ ለተደጋጋሚ ይፈጥራል.
    ///
    /// የ መዘጋት `true` ወይም `false` መመለስ አለበት አንድ አባል ይሰጠዋል.የ ለተደጋጋሚ ብቻ መዘጋት እውነተኛ ይመልሳል ይህም ለ ክፍሎች ታፈራለች ተመለሱ.
    ///
    /// # Examples
    ///
    /// መሠረታዊ አጠቃቀም
    ///
    /// ```
    /// let a = [0i32, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| x.is_positive());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `filter()` ወደ አለፈ መዘጋት ማጣቀሻ ይወስዳል, ብዙ iterators ማጣቀሻዎች ላይ ለመድገም ምክንያት, መዘጋት ዓይነት ድርብ ማጣቀሻ ቦታ ሊሆን ግራ ሁኔታ, ይህን ይመራል:
    ///
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| **x > 1); // ሁለት * ቶች ያስፈልጉ!
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// በክርክሩ ላይ አንዱን ለማራገፍ በምትኩ ማበላሸት መጠቀሙ የተለመደ ነው-
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&x| *x > 1); // ሁለቱም እና *
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// ወይም ሁለቱም
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&&x| x > 1); // ሁለት &s
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// እነዚህ በማነባበር.
    ///
    /// `iter.filter(f).next()` `iter.find(f)` ጋር ተመጣጣኝ መሆኑን ልብ ይበሉ.
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter<P>(self, predicate: P) -> Filter<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        Filter::new(self, predicate)
    }

    /// ሁለቱም ማጣሪያዎች እና ካርታዎች አንድ ለተደጋጋሚ ይፈጥራል.
    ///
    /// የ ለተደጋጋሚ ብቻ የሚቀርቡ መዘጋት `Some(value)` ይመልሳል ይህም ለ `value`s ያፈራላቸዋል ተመለሱ.
    ///
    /// `filter_map` የ [`filter`] እና [`map`] ሰንሰለቶችን የበለጠ አጭር ለማድረግ ሰንሰለቶችን ለመስራት ሊያገለግል ይችላል።
    /// አንድ `map().filter().map()` `filter_map` አንድ ነጠላ ጥሪ ያጥራሉ እንደሚችሉ ከዚህ በታች ያለው ምሳሌ.
    ///
    ///
    /// [`filter`]: Iterator::filter
    /// [`map`]: Iterator::map
    ///
    /// # Examples
    ///
    /// መሠረታዊ አጠቃቀም
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    ///
    /// let mut iter = a.iter().filter_map(|s| s.parse().ok());
    ///
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// ተመሳሳይ ምሳሌ ይኸውልዎት ፣ ግን በ [`filter`] እና [`map`]
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    /// let mut iter = a.iter().map(|s| s.parse()).filter(|s| s.is_ok()).map(|s| s.unwrap());
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter_map<B, F>(self, f: F) -> FilterMap<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        FilterMap::new(self, f)
    }

    /// የአሁኑ ተደጋጋሚነት ብዛት እንዲሁም ቀጣዩ ዋጋ የሚሰጥ አንድ ለተደጋጋሚ ይፈጥራል.
    ///
    /// የ ለተደጋጋሚ ተመልሶ ምርት ጥንዶች `i` ተደጋጋሚነት የአሁኑ ጠቋሚ ነው የት `(i, val)` እና `val` ወደ ለተደጋጋሚ የተመለሱ እሴት ነው.
    ///
    ///
    /// `enumerate()` እንደ [`usize`] ቆጠራውን ያቆያል።
    /// የተለየ መጠን ያላቸው ኢንቲጀር በ መቁጠር የሚፈልጉ ከሆነ, [`zip`] ተግባር ተመሳሳይ ተግባር ይሰጣል.
    ///
    /// # የትርፍ ፍሰት ባህሪ
    ///
    /// የ ዘዴ የበለጠ [`usize::MAX`] አባሎች ይልቅ ከዘረዘረ ስለዚህ ምንም, ያጥለቀልቁታል ላይ ጠባቂ ነው ወይ የተሳሳተ ውጤት ወይም panics ያፈራል.
    /// የስህተት ማረጋገጫዎች ከነቁ አንድ panic ዋስትና ተሰጥቶታል።
    ///
    /// # Panics
    ///
    /// የ ለተደጋጋሚ panic ወደ ወደ-መመለስ ማውጫ አንድ [`usize`] ሞልቶ ነበር ይችላል ከሆነ ተመለሱ.
    ///
    /// [`usize`]: type@usize
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ['a', 'b', 'c'];
    ///
    /// let mut iter = a.iter().enumerate();
    ///
    /// assert_eq!(iter.next(), Some((0, &'a')));
    /// assert_eq!(iter.next(), Some((1, &'b')));
    /// assert_eq!(iter.next(), Some((2, &'c')));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn enumerate(self) -> Enumerate<Self>
    where
        Self: Sized,
    {
        Enumerate::new(self)
    }

    /// [`peek`] ን ሳይጠቀም የተሟሚውን ቀጣይ ንጥረ ነገር ለመመልከት [`peek`] ን ሊጠቀም የሚችል ተደጋጋሚ ይፈጥራል።
    ///
    /// የ [`peek`] ዘዴን ለተደጋጋሚነት ያክላል።ለበለጠ መረጃ ሰነዶቹን ይመልከቱ ፡፡
    ///
    /// [`peek`] ን ለመጀመሪያ ጊዜ ሲጠራ መሠረታዊው ተደጋጋሚ ጠቋሚ አሁንም የላቀ መሆኑን ልብ ይበሉ ፣ የሚቀጥለውን ንጥረ ነገር ለማግኘት [`next`] ን በስረኛው ተደጋጋሚ ላይ ይጠራል ፣ ስለሆነም ማንኛውም የጎንዮሽ ጉዳቶች (ማለትም
    ///
    /// የ [`next`] ዘዴ የሚቀጥለውን እሴት ከማምጣት ውጭ ሌላ ማንኛውም ነገር ይከሰታል።
    ///
    /// [`peek`]: Peekable::peek
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// መሠረታዊ አጠቃቀም
    ///
    /// ```
    /// let xs = [1, 2, 3];
    ///
    /// let mut iter = xs.iter().peekable();
    ///
    /// // peek() ወደ future እንድንመለከት ያደርገናል
    /// assert_eq!(iter.peek(), Some(&&1));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), Some(&2));
    ///
    /// // peek() ን ብዙ ጊዜ እንችላለን ፣ ተደጋጋሚው አይራመድም
    /// assert_eq!(iter.peek(), Some(&&3));
    /// assert_eq!(iter.peek(), Some(&&3));
    ///
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // የ ለተደጋጋሚ ከጨረሰ በኋላ, እንዲሁ peek() ነው
    /// assert_eq!(iter.peek(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn peekable(self) -> Peekable<Self>
    where
        Self: Sized,
    {
        Peekable::new(self)
    }

    /// [`Skip`] ን ንጥረ ተሳቢ ላይ የተመሠረተ መሆኑን አንድ ለተደጋጋሚ ይፈጥራል.
    ///
    /// [`skip`]: Iterator::skip
    ///
    /// `skip_while()` ክርክር እንደ መዘጋት ይወስዳል.እሱ በተዘጋው እያንዳንዱ ንጥረ ነገር ላይ ይህን መዘጋት ይጠራዋል ፣ እና `false` ን እስኪመለስ ድረስ አባሎችን ችላ ይላቸዋል።
    ///
    /// `false` ተመልሶ በኋላ, `skip_while()`'s ሥራ ላይ ነው, እና ንጥረ የቀሩት አፈራ ናቸው.
    ///
    /// # Examples
    ///
    /// መሠረታዊ አጠቃቀም
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// ምክንያቱም ወደ `skip_while()` የተላለፈው መዘጋት ማጣቀሻ ስለሚወስድ እና ብዙ ተጓtorsች በማጣቀሻዎች ላይ ስለሚጨምሩ ይህ ወደ ግራ መጋባት ሁኔታ ይመራል ፣ ይህም የመዝጊያው ክርክር ዓይነት ድርብ ማጣቀሻ ነው-
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0); // ሁለት * ቶች ያስፈልጉ!
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// ከመጀመሪያው `false` በኋላ ማቆም:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// // ቀደም ሲል አንድ ሐሰተኛ አግኝቷል ጀምሮ ይህ የሐሰት ባልነበረ ኖሮ ሳለ, skip_while() ጥቅም አይደለም ማንኛውም ተጨማሪ
    /////
    /// assert_eq!(iter.next(), Some(&-2));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip_while<P>(self, predicate: P) -> SkipWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        SkipWhile::new(self, predicate)
    }

    /// ምርት ክፍሎች ተሳቢ ላይ የተመሠረተ መሆኑን አንድ ለተደጋጋሚ ይፈጥራል.
    ///
    /// `take_while()` እንደ ክርክር መዘጋት ይወስዳል ፡፡ይህም ለተደጋጋሚ በእያንዳንዱ ኤለመንት ላይ ይህን መዘጋት ይደውሉ, እና `true` በሚመለስበት ጊዜ ንጥረ ታፈራለች.
    ///
    /// `false` ከተመለሰ በኋላ የ `take_while()`'s ሥራ ተጠናቅቋል ፣ እና የተቀሩት አካላት ችላ ተብለዋል።
    ///
    /// # Examples
    ///
    /// መሠረታዊ አጠቃቀም
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `take_while()` ወደ አለፈ መዘጋት ማጣቀሻ ይወስዳል, ብዙ iterators ማጣቀሻዎች ላይ ለመድገም ምክንያት, መዘጋት ዓይነት ድርብ ማጣቀሻ ቦታ ሊሆን ግራ ሁኔታ, ይህን ይመራል:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0); // ሁለት * ቶች ያስፈልጉ!
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// ከመጀመሪያው `false` በኋላ ማቆም:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    ///
    /// // እኛም ያነሰ ከዜሮ በላይ የሆኑ ተጨማሪ ክፍሎች, ነገር ግን አስቀድሞ የሐሰት አግኝቷል ጀምሮ, take_while() ማንኛውም ተጨማሪ ጥቅም አይደለም
    /////
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `take_while()` የሚጨመር ወይም ያለበት ከሆነ iterators መወገድ መሆኑን ያያሉ የሚፈጅ, ለማየት ሲሉ ዋጋ መመልከት ያስፈልገዋል ምክንያቱም:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<i32> = iter.by_ref()
    ///                            .take_while(|n| **n != 3)
    ///                            .cloned()
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// `3` ከእንግዲህ የለም ፣ ምክንያቱም መደጋገሙ መቆም እንዳለበት ለመብላት ስለተጠቀመ ፣ ነገር ግን ተመልሶ ወደ ተጠቀሰው ሰው አልተቀመጠም።
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take_while<P>(self, predicate: P) -> TakeWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        TakeWhile::new(self, predicate)
    }

    /// በፕሮቴክተሮች እና በካርታዎች ላይ በመመርኮዝ ሁለቱም ንጥረ ነገሮችን የሚያመነጭ ተደጋጋሚ ይፈጥራል።
    ///
    /// `map_while()` እንደ ክርክር መዘጋት ይወስዳል ፡፡
    /// ይህም ለተደጋጋሚ በእያንዳንዱ ኤለመንት ላይ ይህን መዘጋት ይደውሉ, እና [`Some(_)`][`Some`] በሚመለስበት ጊዜ ንጥረ ታፈራለች.
    ///
    /// # Examples
    ///
    /// መሠረታዊ አጠቃቀም
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter().map_while(|x| 16i32.checked_div(*x));
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// እዚህ ግን [`take_while`] እና [`map`] ጋር ተመሳሳይ ምሳሌ ነው:
    ///
    /// [`take_while`]: Iterator::take_while
    /// [`map`]: Iterator::map
    ///
    /// ```
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter()
    ///                 .map(|x| 16i32.checked_div(*x))
    ///                 .take_while(|x| x.is_some())
    ///                 .map(|x| x.unwrap());
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// የመጀመሪያ [`None`] በኋላ በማቆም:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [0, 1, 2, -3, 4, 5, -6];
    ///
    /// let iter = a.iter().map_while(|x| u32::try_from(*x).ok());
    /// let vec = iter.collect::<Vec<_>>();
    ///
    /// // እኛ u32 (4, 5) ውስጥ መመደብ የሚችሉ ተጨማሪ ክፍሎች አሉን, ነገር ግን (የ `predicate` `None` ሲመለስ) `map_while` `-3` ለ `None` ተመልሶ `collect` የመጀመሪያው `None` አጋጥሞታል ላይ ማቆሚያዎች.
    /////
    /// assert_eq!(vec, vec![0, 1, 2]);
    /// ```
    ///
    /// `map_while()` የሚጨመር ወይም ያለበት ከሆነ iterators መወገድ መሆኑን ያያሉ የሚፈጅ, ለማየት ሲሉ ዋጋ መመልከት ያስፈልገዋል ምክንያቱም:
    ///
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [1, 2, -3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<u32> = iter.by_ref()
    ///                            .map_while(|n| u32::try_from(*n).ok())
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// ይህም ቃል ተደጋጋሚነት ማቆም አለበት ከሆነ ለማየት ሲሉ ፍጆታ ነበር, ነገር ግን ለተደጋጋሚ ወደ ኋላ ይመደባሉ አልነበረም ምክንያቱም `-3`, ከአሁን በኋላ የለም.
    ///
    /// ማስታወሻ [`take_while`] በተለየ መልኩ ይህንን ለተደጋጋሚ ** ** እንደሚዋሃድ አይደለም.
    /// የመጀመሪያው [`None`] ከተመለሰ በኋላ ይህ ተደጋጋሚ ምን እንደሚመለስም አልተገለጸም።
    /// የተዋሃደ ተደጋጋሚነት ከፈለጉ [`fuse`] ይጠቀሙ።
    ///
    /// [`fuse`]: Iterator::fuse
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
    fn map_while<B, P>(self, predicate: P) -> MapWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> Option<B>,
    {
        MapWhile::new(self, predicate)
    }

    /// የመጀመሪያዎቹን የ `n` አባሎች የሚዘል ተደጋጋሚ ይፈጥራል።
    ///
    /// ያልቃሉ ተደርጓል በኋላ, ንጥረ የቀሩት አፈራ ናቸው.
    /// ይህንን ዘዴ በቀጥታ ከማስወገድ ይልቅ በምትኩ የ `nth` ዘዴን ይሽሩ።
    ///
    /// # Examples
    ///
    /// መሠረታዊ አጠቃቀም
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().skip(2);
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip(self, n: usize) -> Skip<Self>
    where
        Self: Sized,
    {
        Skip::new(self, n)
    }

    /// በመጀመሪያዎቹ `n` ክፍሎች ያፈራላቸዋል አንድ ለተደጋጋሚ ይፈጥራል.
    ///
    /// # Examples
    ///
    /// መሠረታዊ አጠቃቀም
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().take(2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `take()` ብዙውን ጊዜ አንድ የሌለው ለተደጋጋሚ ጋር ጥቅም ላይ ውሏል, ይህ አላቂ ለማድረግ:
    ///
    /// ```
    /// let mut iter = (0..).take(3);
    ///
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `n` አባሎች ያነሰ የሚገኙ ከሆነ, `take` የተነሳበትን ለተደጋጋሚ መጠን እራሱን ሊገድብ ይሆናል:
    ///
    ///
    /// ```
    /// let v = vec![1, 2];
    /// let mut iter = v.into_iter().take(5);
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take(self, n: usize) -> Take<Self>
    where
        Self: Sized,
    {
        Take::new(self, n)
    }

    /// የውስጥ ሁኔታን የያዘው አዲስ ለተደጋጋሚ የሚያፈራ [`fold`] ጋር የሚመሳሰል አንድ ለተደጋጋሚ አስማሚ.
    ///
    /// [`fold`]: Iterator::fold
    ///
    /// `scan()` ሁለት ክርክሮችን ይወስዳል-የመነሻ እሴት ውስጣዊ ሁኔታን የሚዘራ እና በሁለት ክርክሮች መዘጋት ፣ የመጀመሪያው ወደ ውስጣዊ ሁኔታ የሚለዋወጥ ማጣቀሻ እና ሁለተኛው ደግሞ ተደጋጋሚ ንጥረ ነገር ነው ፡፡
    ///
    /// የ መዘጋት ድግግሞሾች መካከል ድርሻ ሁኔታ ውስጣዊ ሁኔታ መመደብ ይችላሉ.
    ///
    /// በመድገም ላይ ፣ መዝጊያው በእያንዳንዱ ንጥረ ነገር ላይ ይተገበራል እናም ከመዝጊያው የመመለሻ እሴት‹[`Option`]›በተደጋጋሚው ይሰጣል።
    ///
    /// # Examples
    ///
    /// መሠረታዊ አጠቃቀም
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().scan(1, |state, &x| {
    ///     // እያንዳንዱን ድግግሞሽ ፣ ግዛቱን በንጥል እናባዛለን
    ///     *state = *state * x;
    ///
    ///     // ታዲያ, እኛ ግዛት ያለውን አፍራሽ ቅድሚያ ያገኛሉ
    ///     Some(-*state)
    /// });
    ///
    /// assert_eq!(iter.next(), Some(-1));
    /// assert_eq!(iter.next(), Some(-2));
    /// assert_eq!(iter.next(), Some(-6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn scan<St, B, F>(self, initial_state: St, f: F) -> Scan<Self, St, F>
    where
        Self: Sized,
        F: FnMut(&mut St, Self::Item) -> Option<B>,
    {
        Scan::new(self, initial_state, f)
    }

    /// እንደ ካርታ የሚሠራ ተደጋጋሚ ይፈጥራል ፣ ነገር ግን የጎጆ ጎጆን ጠፍጣፋ ያደርገዋል ፡፡
    ///
    /// የ [`map`] አስማሚው በጣም ጠቃሚ ነው ፣ ግን የመዝጊያ ክርክር እሴቶችን ሲያመጣ ብቻ ነው።
    /// በምትኩ አንድ ተደጋጋሚ የሚያመነጭ ከሆነ ፣ ተጨማሪ የመለዋወጥ ንብርብር አለ።
    /// `flat_map()` በራሱ ላይ ይህን ተጨማሪ ንብርብር ያስወግዳል.
    ///
    /// አንተ `map(f).flatten()` እንደ ቆይታ [`flatten`] ከዚያም [`map`] ፒንግ ያለውን የፍቺ አቻ እንደ `flat_map(f)` ማሰብ, እና ይችላሉ.
    ///
    /// ሌላው `flat_map()` ስለ ማሰብ መንገድ: እያንዳንዱ ኤለመንት ለ [`map`] ን መዘጋት ሲመለስ አንድ ንጥል እና `flat_map()`'s መዘጋት ይመለሳል ለእያንዳንዱ ኤለመንት አንድ ለተደጋጋሚ.
    ///
    ///
    /// [`map`]: Iterator::map
    /// [`flatten`]: Iterator::flatten
    ///
    /// # Examples
    ///
    /// መሠረታዊ አጠቃቀም
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() አንድ ለተደጋጋሚ ይመልሳል
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn flat_map<U, F>(self, f: F) -> FlatMap<Self, U, F>
    where
        Self: Sized,
        U: IntoIterator,
        F: FnMut(Self::Item) -> U,
    {
        FlatMap::new(self, f)
    }

    /// ድርብርብ አወቃቀር መባረርም አንድ ለተደጋጋሚ ይፈጥራል.
    ///
    /// እናንተ iterators አንድ ለተደጋጋሚ ወይም iterators ይለወጣል የሚችሉ ነገሮች አንድ ለተደጋጋሚ አለን እና indirection አንድ ደረጃ ለማስወገድ ይፈልጋሉ ጊዜ ይህ ጠቃሚ ነው.
    ///
    ///
    /// # Examples
    ///
    /// መሠረታዊ አጠቃቀም
    ///
    /// ```
    /// let data = vec![vec![1, 2, 3, 4], vec![5, 6]];
    /// let flattened = data.into_iter().flatten().collect::<Vec<u8>>();
    /// assert_eq!(flattened, &[1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    /// ካርታ ማውጣት እና ከዚያ ጠፍጣፋ ማድረግ
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() አንድ ለተደጋጋሚ ይመልሳል
    /// let merged: String = words.iter()
    ///                           .map(|s| s.chars())
    ///                           .flatten()
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// በተጨማሪም ይህ ሐሳብ ይበልጥ ግልጽ ያስተላለፈው በመሆኑ በዚህ ሁኔታ ውስጥ ይመረጣል ይህም [`flat_map()`], አንጻር ይህን መጻፍ ይችላሉ:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() አንድ ለተደጋጋሚ ይመልሳል
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// ዝርግ በአንድ ጊዜ አንድ የጎጆ ጎጆን ብቻ ያስወግዳል-
    ///
    /// ```
    /// let d3 = [[[1, 2], [3, 4]], [[5, 6], [7, 8]]];
    ///
    /// let d2 = d3.iter().flatten().collect::<Vec<_>>();
    /// assert_eq!(d2, [&[1, 2], &[3, 4], &[5, 6], &[7, 8]]);
    ///
    /// let d1 = d3.iter().flatten().flatten().collect::<Vec<_>>();
    /// assert_eq!(d1, [&1, &2, &3, &4, &5, &6, &7, &8]);
    /// ```
    ///
    /// እዚህ `flatten()` የ "deep" ጠፍጣፋ እንደማያከናውን እናያለን ፡፡
    /// ይልቅ, የማጠራቀም ብቻ አንድ ደረጃ ተወግዷል ነው.አንድ ሶስት-ልኬት ድርድር `flatten()` ከሆነ ነው, ውጤቱ ሁለት-ልኬት እና አንድ-ልኬት አይደለም ይሆናል.
    /// የአንድ-ልኬት መዋቅር ለማግኘት, እንደገና `flatten()` አለብን.
    ///
    /// [`flat_map()`]: Iterator::flat_map
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_flatten", since = "1.29.0")]
    fn flatten(self) -> Flatten<Self>
    where
        Self: Sized,
        Self::Item: IntoIterator,
    {
        Flatten::new(self)
    }

    /// ከመጀመሪያው [`None`] በኋላ የሚጨርስ ተደጋጋሚ ይፈጥራል።
    ///
    /// አንድ ለተደጋጋሚ [`None`] ይመልሳል በኋላ, future ጥሪዎች ወይም እንደገና [`Some(T)`] ልናገኝ እንችላለን ይችላሉ አይደለም.
    /// `fuse()` አንድ [`None`] ተሰጥቷል በኋላ, ምንጊዜም ለዘላለም [`None`] ይመለሳል መሆኑን በማረጋገጥ, አንድ ለተደጋጋሚ ያመቻቻል.
    ///
    ///
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// መሠረታዊ አጠቃቀም
    ///
    /// ```
    /// // በአንዳንዶቹ እና በሌላው መካከል የሚቀያየር ተደጋጋሚ ቃል
    /// struct Alternate {
    ///     state: i32,
    /// }
    ///
    /// impl Iterator for Alternate {
    ///     type Item = i32;
    ///
    ///     fn next(&mut self) -> Option<i32> {
    ///         let val = self.state;
    ///         self.state = self.state + 1;
    ///
    ///         // እንኳ, Some(i32), ሌላ ምንም ከሆነ
    ///         if val % 2 == 0 {
    ///             Some(val)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    ///
    /// let mut iter = Alternate { state: 0 };
    ///
    /// // እኛ ለተደጋጋሚ በመሄድ ወዲያና ማየት ይችላሉ
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    ///
    /// // ይሁን እንጂ, አንዴ እኛ ያዋህዳሉ ...
    /// let mut iter = iter.fuse();
    ///
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    ///
    /// // ሁልጊዜ ለመጀመሪያ ጊዜ በኋላ `None` ይመለሳሉ.
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fuse(self) -> Fuse<Self>
    where
        Self: Sized,
    {
        Fuse::new(self)
    }

    /// ላይ ያለውን እሴት ሲያልፍ, አንድ ለተደጋጋሚ እያንዳንዱ ኤለመንት ጋር አንድ ነገር ያደርጋል.
    ///
    /// ተጓtorsችን በሚጠቀሙበት ጊዜ ብዙውን ጊዜ ብዙዎቹን በአንድ ላይ ይሰሩዎታል ፡፡
    /// እንዲህ ኮድ ላይ እየሰራን ሳለ ቦንድና የተለያዩ ክፍሎች ላይ ምን እየተከሰተ እንዳለ ማወቅ ይፈልጉ ይሆናል.ይህን ለማድረግ, `inspect()` አንድ ጥሪ ያስገቡ.
    ///
    /// ይህ `inspect()` የመጨረሻ ኮድ ውስጥ ሕልውና ይልቅ የማረሚያ መሣሪያ ሆነው ሊያገለግሉ እንዲችሉ ተጨማሪ የተለመደ ነው, ነገር ግን ስህተቶች ተጥለዋል በፊት መግባት ያስፈልግዎታል ጊዜ መተግበሪያዎች በተወሰኑ ሁኔታዎች ውስጥ ጠቃሚ ሆኖ ሊያገኙት ይችላሉ.
    ///
    ///
    /// # Examples
    ///
    /// መሠረታዊ አጠቃቀም
    ///
    /// ```
    /// let a = [1, 4, 2, 3];
    ///
    /// // ይህ ለተደጋጋሚ ቅደም ተከተል ውስብስብ ነው.
    /// let sum = a.iter()
    ///     .cloned()
    ///     .filter(|x| x % 2 == 0)
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    ///
    /// // ይሁን ዎቹ እየተፈጸመ ነገር ለመመርመር አንዳንድ inspect() ጥሪዎች ማከል
    /// let sum = a.iter()
    ///     .cloned()
    ///     .inspect(|x| println!("about to filter: {}", x))
    ///     .filter(|x| x % 2 == 0)
    ///     .inspect(|x| println!("made it through filter: {}", x))
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    /// ```
    ///
    /// ይህ ማተም ይሆናል:
    ///
    /// ```text
    /// 6
    /// about to filter: 1
    /// about to filter: 4
    /// made it through filter: 4
    /// about to filter: 2
    /// made it through filter: 2
    /// about to filter: 3
    /// 6
    /// ```
    ///
    /// ከእነሱ ከመጣላችን በፊት ስህተቶች በመግባት ላይ:
    ///
    /// ```
    /// let lines = ["1", "2", "a"];
    ///
    /// let sum: i32 = lines
    ///     .iter()
    ///     .map(|line| line.parse::<i32>())
    ///     .inspect(|num| {
    ///         if let Err(ref e) = *num {
    ///             println!("Parsing error: {}", e);
    ///         }
    ///     })
    ///     .filter_map(Result::ok)
    ///     .sum();
    ///
    /// println!("Sum: {}", sum);
    /// ```
    ///
    /// ይህ ማተም ይሆናል:
    ///
    /// ```text
    /// Parsing error: invalid digit found in string
    /// Sum: 3
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn inspect<F>(self, f: F) -> Inspect<Self, F>
    where
        Self: Sized,
        F: FnMut(&Self::Item),
    {
        Inspect::new(self, f)
    }

    /// አንድ ለተደጋጋሚ ይበደራል, ይልቅ ይህን የሚያጠፋ.
    ///
    /// ይህ አሁንም ከዋናው ለተደጋጋሚ ባለቤትነት በማስቀረት ላይ ሳለ ለተደጋጋሚ አስማሚዎች ተግባራዊ ለመፍቀድ ጠቃሚ ነው.
    ///
    ///
    /// # Examples
    ///
    /// መሠረታዊ አጠቃቀም
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let iter = a.iter();
    ///
    /// let sum: i32 = iter.take(5).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 6);
    ///
    /// // እንደገና ተጠቅመን ለመጠቀም ከሞከርን አይሰራም ፡፡
    /// // ተንቀሳቅሷል ዋጋ አጠቃቀም የሚከተሉት መስመር "ስህተት ይሰጣል: `iter`
    /// // assert_eq!(iter.next(), None);
    ///
    /// // ያንን እንደገና ይሁን
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // ይልቅ, እኛ .by_ref() ላይ ለማከል
    /// let sum: i32 = iter.by_ref().take(2).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 3);
    ///
    /// // አሁን ይህ ጥሩ ነው
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn by_ref(&mut self) -> &mut Self
    where
        Self: Sized,
    {
        self
    }

    /// አንድ ተደጋጋሚ ወደ ስብስብ ይቀይረዋል።
    ///
    /// `collect()` ሊነካ የሚችል ማንኛውንም ነገር መውሰድ እና ወደ አግባብነት ስብስብ ሊለውጠው ይችላል ፡፡
    /// ይህ በተለያዩ አገባቦች ላይ ጥቅም ላይ መደበኛ ቤተ መጻሕፍት ውስጥ ይበልጥ ኃያል ዘዴዎች, አንዱ ነው.
    ///
    /// `collect()` የሚውለው ውስጥ እጅግ መሠረታዊ ጥለት ሌላ ወደ አንድ ስብስብ ማብራት ነው.
    /// እርስዎ መጨረሻ ከዚያም `collect()`, በላዩ ላይ [`iter`] ይደውሉ ለውጥ በማድረግ ስብስብ ማድረግ, እና አንድ ስብስብ ይወስዳሉ.
    ///
    /// `collect()` በተጨማሪም ዓይነተኛ ስብስቦች አለመሆናቸውን አይነቶች አጋጣሚዎች መፍጠር ይችላሉ.
    /// ለምሳሌ ያህል, አንድ [`String`] [`char`] ን ከ የተገነባው ይችላሉ, እና [`Result<T, E>`][`Result`] ንጥሎች አንድ ለተደጋጋሚ `Result<Collection<T>, E>` ወደ ሊሰበሰብ ይችላል.
    ///
    /// ተጨማሪ ለማግኘት ከታች ያለውን ምሳሌ ተመልከት.
    ///
    /// `collect()` በጣም አጠቃላይ ስለሆነ በአይነት ግንዛቤ ላይ ችግር ሊፈጥር ይችላል ፡፡
    /// እንዲህ እንደ `collect()` እናንተ የፍቅር በ 'turbofish' በመባል የሚታወቀው ያለውን አገባብ ያያሉ ጥቂት ጊዜያት አንዱ ነው: `::<>`.
    /// ይህ የአመለካከት ስልተ ቀመር በየትኛው ስብስብ ውስጥ ለመሰብሰብ እየሞከሩ እንደሆነ ለመረዳት ይረዳል ፡፡
    ///
    /// # Examples
    ///
    /// መሠረታዊ አጠቃቀም
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled: Vec<i32> = a.iter()
    ///                          .map(|&x| x * 2)
    ///                          .collect();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// በግራ-ግራ በኩል `: Vec<i32>` እንደፈለግን ልብ ይበሉ ፡፡ይህ የሆነበት ምክንያት በምትኩ [`VecDeque<T>`] መሰብሰብ ስለምንችል ነው-
    ///
    /// [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let a = [1, 2, 3];
    ///
    /// let doubled: VecDeque<i32> = a.iter().map(|&x| x * 2).collect();
    ///
    /// assert_eq!(2, doubled[0]);
    /// assert_eq!(4, doubled[1]);
    /// assert_eq!(6, doubled[2]);
    /// ```
    ///
    /// ይልቅ `doubled` annotating ያለውን 'turbofish' መጠቀም:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<i32>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// `collect()` ብቻ ከእናንተ ወደ ለመሰብሰብ ስለሚፈልጉት ነገር ያስባል; ምክንያቱም, አሁንም turbofish ጋር ከፊል አይነት ፍንጭ, `_`, መጠቀም ይችላሉ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<_>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// አንድ [`String`] ለማድረግ `collect()` መጠቀም:
    ///
    /// ```
    /// let chars = ['g', 'd', 'k', 'k', 'n'];
    ///
    /// let hello: String = chars.iter()
    ///     .map(|&x| x as u8)
    ///     .map(|x| (x + 1) as char)
    ///     .collect();
    ///
    /// assert_eq!("hello", hello);
    /// ```
    ///
    /// ከእናንተ ዝርዝር ካለህ [`ውጤት<T, E>`][`Result`] ን, እናንተ ከእነርሱ ማንኛውም አልተሳካም ለማየት `collect()` መጠቀም ይችላሉ:
    ///
    /// ```
    /// let results = [Ok(1), Err("nope"), Ok(3), Err("bad")];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // የመጀመሪያውን ስህተት ይሰጠናል
    /// assert_eq!(Err("nope"), result);
    ///
    /// let results = [Ok(1), Ok(3)];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // እኛን መልስ ዝርዝር ይሰጣል
    /// assert_eq!(Ok(vec![1, 3]), result);
    /// ```
    ///
    /// [`iter`]: Iterator::next
    /// [`String`]: ../../std/string/struct.String.html
    /// [`char`]: type@char
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "if you really need to exhaust the iterator, consider `.for_each(drop)` instead"]
    fn collect<B: FromIterator<Self::Item>>(self) -> B
    where
        Self: Sized,
    {
        FromIterator::from_iter(self)
    }

    /// ይህም እስከ ሁለት ስብስቦች በመፍጠር, አንድ ለተደጋጋሚ ተቆጣጥሮታል.
    ///
    /// `partition()` ወደ አለፈ ተሳቢ `true`, ወይም `false` መመለስ ይችላሉ.
    /// `partition()` ጥንድ ያወጣል, ያሉትን ክፍሎች ሁሉ ለዚህም ነው `true` ተመልሶ ሲሆን `false` ተመለሱ ይህም ለ ያሉትን ክፍሎች ሁሉ.
    ///
    ///
    /// በተጨማሪም [`is_partitioned()`] እና [`partition_in_place()`] ይመልከቱ.
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// መሠረታዊ አጠቃቀም
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let (even, odd): (Vec<i32>, Vec<i32>) = a
    ///     .iter()
    ///     .partition(|&n| n % 2 == 0);
    ///
    /// assert_eq!(even, vec![2]);
    /// assert_eq!(odd, vec![1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn partition<B, F>(self, f: F) -> (B, B)
    where
        Self: Sized,
        B: Default + Extend<Self::Item>,
        F: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn extend<'a, T, B: Extend<T>>(
            mut f: impl FnMut(&T) -> bool + 'a,
            left: &'a mut B,
            right: &'a mut B,
        ) -> impl FnMut((), T) + 'a {
            move |(), x| {
                if f(&x) {
                    left.extend_one(x);
                } else {
                    right.extend_one(x);
                }
            }
        }

        let mut left: B = Default::default();
        let mut right: B = Default::default();

        self.fold((), extend(f, &mut left, &mut right));

        (left, right)
    }

    /// የዚህን ተደጋጋሚ ንጥረ ነገር *በቦታው* በተጠቀሰው ቅድመ-ይሁንታ መሠረት ይደግማል ፣ ይህም `true` ን የሚመለሱ ሁሉ `false` ን ከሚመለሱት ሁሉ ይቀድማል።
    ///
    /// ይመለሳል `true` ንጥረ ቁጥር አገኘ.
    ///
    /// የተከፋፈሉ ዕቃዎች አንፃራዊ ቅደም ተከተል አልተያዘም ፡፡
    ///
    /// እንዲሁም [`is_partitioned()`] እና [`partition()`] ን ይመልከቱ።
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition()`]: Iterator::partition
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_partition_in_place)]
    ///
    /// let mut a = [1, 2, 3, 4, 5, 6, 7];
    ///
    /// // ውስጥ-ቦታ evens እና አሸናፊውን መካከል ክፍልፍል
    /// let i = a.iter_mut().partition_in_place(|&n| n % 2 == 0);
    ///
    /// assert_eq!(i, 3);
    /// assert!(a[..i].iter().all(|&n| n % 2 == 0)); // evens
    /// assert!(a[i..].iter().all(|&n| n % 2 == 1)); // odds
    /// ```
    #[unstable(feature = "iter_partition_in_place", reason = "new API", issue = "62543")]
    fn partition_in_place<'a, T: 'a, P>(mut self, ref mut predicate: P) -> usize
    where
        Self: Sized + DoubleEndedIterator<Item = &'a mut T>,
        P: FnMut(&T) -> bool,
    {
        // FIXME: እኛ የመቁጠር የሚትረፈረፍ መጨነቅ ያለብን?ብቸኛው መንገድ ከ እንዲኖረው ለማድረግ
        // `usize::MAX` ሊቀየሩ የሚችሉ ዋቢዎችን ክፍልፍል ጠቃሚ አይደሉም ይህም ZSTs ጋር ነው ...

        // እነዚህ መዘጋት "factory" ተግባራት `Self` ውስጥ genericity ለማስወገድ የለም.

        #[inline]
        fn is_false<'a, T>(
            predicate: &'a mut impl FnMut(&T) -> bool,
            true_count: &'a mut usize,
        ) -> impl FnMut(&&mut T) -> bool + 'a {
            move |x| {
                let p = predicate(&**x);
                *true_count += p as usize;
                !p
            }
        }

        #[inline]
        fn is_true<T>(predicate: &mut impl FnMut(&T) -> bool) -> impl FnMut(&&mut T) -> bool + '_ {
            move |x| predicate(&**x)
        }

        // የመጀመሪያውን `false` ደጋግመው ይፈልጉ እና ካለፈው `true` ጋር ይቀያይሩት።
        let mut true_count = 0;
        while let Some(head) = self.find(is_false(predicate, &mut true_count)) {
            if let Some(tail) = self.rfind(is_true(predicate)) {
                crate::mem::swap(head, tail);
                true_count += 1;
            } else {
                break;
            }
        }
        true_count
    }

    /// የዚህ ተደጋጋሚ ንጥረ ነገሮች በተጠቀሰው ቅድመ-ሁኔታ መሠረት ከተከፋፈሉ ፣ `true` ን የሚመልሱ ሁሉ `false` ን ከሚመለሱት ሁሉ ይቀድማሉ ፡፡
    ///
    ///
    /// በተጨማሪም [`partition()`] እና [`partition_in_place()`] ይመልከቱ.
    ///
    /// [`partition()`]: Iterator::partition
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_is_partitioned)]
    ///
    /// assert!("Iterator".chars().is_partitioned(char::is_uppercase));
    /// assert!(!"IntoIterator".chars().is_partitioned(char::is_uppercase));
    /// ```
    #[unstable(feature = "iter_is_partitioned", reason = "new API", issue = "62544")]
    fn is_partitioned<P>(mut self, mut predicate: P) -> bool
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        // ሁሉም ንጥሎች `true` ን ይፈትኑ ወይም የመጀመሪያው አንቀፅ በ `false` ላይ ይቆማል እና ከዚያ በኋላ የ `true` ንጥሎች እንደሌሉ እናረጋግጣለን።
        //
        self.all(&mut predicate) || !self.any(predicate)
    }

    /// አንድን ነጠላ የመጨረሻ ዋጋን በተሳካ ሁኔታ እስኪያመለክት ድረስ አንድን ተግባር በተሳካ ሁኔታ እስከተመለሰ ድረስ የሚተገበር ተደጋጋሚ ዘዴ።
    ///
    /// `try_fold()` የመጀመሪያ ዋጋ, እና ሁለት ነጋሪ እሴቶች ጋር መዘጋት: አንድ 'accumulator', እና አንድ አባል ሁለት ነጋሪ እሴቶች ይወስዳል.
    /// እሴት ጋር ያለው መዘጋት ወይም በተሳካ ሲመለስ, accumulator በሚቀጥለው ተደጋጋሚነት ለማግኘት ሊኖረው እንደሚገባ, ወይም የደዋይ ወዲያውኑ (short-circuiting) ተመልሰው ፕሮፓጋንዳዎች ነው ስህተት እሴት ጋር, ውድቀት ይመልሳል.
    ///
    ///
    /// የመነሻ እሴቱ በመጀመሪያ ጥሪ ላይ አከማቹ የሚኖረው እሴት ነው ፡፡ወደ መዘጋት ተግባራዊ ስለ ለተደጋጋሚ ሁሉ ኤለመንት ላይ ተሳክቷል ከሆነ, `try_fold()` ስኬት እንደ የመጨረሻ accumulator ይመልሳል.
    ///
    /// ነገር ስብስብ አለን, እና አንድ ነጠላ ዋጋ ለማምረት በፈለጉበት ጊዜ ታጥፋለህ ጠቃሚ ነው.
    ///
    /// # Implementors ወደ ማስታወሻ
    ///
    /// በሌላ (forward) ዘዴዎች በርካታ እንዲሁ ነባሪ `for` ሉፕ አፈፃፀም የተሻለ ነገር ማድረግ ይችላል ከሆነ በግልጽ ይህንን ተግባራዊ ለማድረግ ሞክር: ይህ ሰው አኳያ ነባሪ ማስፈጸሚያዎች አላቸው.
    ///
    /// በተለይም ይህ ተደጋጋሚ ቃል በተዋቀረባቸው ውስጣዊ ክፍሎች ላይ ይህ ጥሪ `try_fold()` እንዲኖርዎት ይሞክሩ ፡፡
    /// ብዙ ጥሪዎች የሚያስፈልጉ ከሆነ የ `?` ኦፕሬተር የመሰብሰብያ እሴቱን በአንድ ላይ ለማጣመር ምቹ ሊሆን ይችላል ፣ ግን እነዚያ ቀደምት ከመመለሳቸው በፊት መረጋገጥ የሚያስፈልጋቸውን የማይለወጡትን ሁሉ ይጠንቀቁ ፡፡
    /// ይህ የ `&mut self` ዘዴ ነው ፣ ስለሆነም እዚህ ላይ አንድ ስህተት ከመምታቱ በኋላ ድግግሞሽ እንደገና ሊታይ የሚችል ነው።
    ///
    /// # Examples
    ///
    /// መሠረታዊ አጠቃቀም
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // በድርድሩ ውስጥ ያሉትን ክፍሎች ሁሉ በተደረገባቸው ድምር
    /// let sum = a.iter().try_fold(0i8, |acc, &x| acc.checked_add(x));
    ///
    /// assert_eq!(sum, Some(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = [10, 20, 30, 100, 40, 50];
    /// let mut it = a.iter();
    ///
    /// // የ 100 አባል በማከል ጊዜ ይህ ድምር ይሞላል
    /// let sum = it.try_fold(0i8, |acc, &x| acc.checked_add(x));
    /// assert_eq!(sum, None);
    ///
    /// // በአጭሩ ሰርቪድ ስላለው ቀሪዎቹ ንጥረ ነገሮች በእንደገና ሰጪው በኩል ይገኛሉ ፡፡
    /////
    /// assert_eq!(it.len(), 2);
    /// assert_eq!(it.next(), Some(&40));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// የመጀመሪያው ስህተት ላይ በማቆም እና ስህተት ሲመለሱ, በ ለተደጋጋሚ እያንዳንዱ ንጥል ወደ አንድ ሊሳሳቱ ተግባር ተግባራዊ አንድ ለተደጋጋሚ ዘዴ.
    ///
    ///
    /// ይህ ደግሞ [`for_each()`] መካከል ሊሳሳቱ መልክ እንደ ወይም [`try_fold()`] ያለውን ከመቆየታችን ስሪት ተደርጎ ሊታሰብ ይችላል.
    ///
    /// [`for_each()`]: Iterator::for_each
    /// [`try_fold()`]: Iterator::try_fold
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fs::rename;
    /// use std::io::{stdout, Write};
    /// use std::path::Path;
    ///
    /// let data = ["no_tea.txt", "stale_bread.json", "torrential_rain.png"];
    ///
    /// let res = data.iter().try_for_each(|x| writeln!(stdout(), "{}", x));
    /// assert!(res.is_ok());
    ///
    /// let mut it = data.iter().cloned();
    /// let res = it.try_for_each(|x| rename(x, Path::new(x).with_extension("old")));
    /// assert!(res.is_err());
    /// // የቀሩት ንጥሎች ለተደጋጋሚ ውስጥ አሁንም ናቸው, ስለዚህ ይህ አጭር-circuited:
    /// assert_eq!(it.next(), Some("stale_bread.json"));
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_for_each<F, R>(&mut self, f: F) -> R
    where
        Self: Sized,
        F: FnMut(Self::Item) -> R,
        R: Try<Ok = ()>,
    {
        #[inline]
        fn call<T, R>(mut f: impl FnMut(T) -> R) -> impl FnMut((), T) -> R {
            move |(), x| f(x)
        }

        self.try_fold((), call(f))
    }

    /// የመጨረሻ ውጤት ሲመለሱ, ቀዶ ተግባራዊ በማድረግ አንድ accumulator ወደ እያንዳንዱ አባል ይታጠፋል.
    ///
    /// `fold()` የመጀመሪያ ዋጋ, እና ሁለት ነጋሪ እሴቶች ጋር መዘጋት: አንድ 'accumulator', እና አንድ አባል ሁለት ነጋሪ እሴቶች ይወስዳል.
    /// ወደ መዘጋት ወደ accumulator በሚቀጥለው ተደጋጋሚነት ለማግኘት ሊኖረው እንደሚገባ እሴት ይመልሳል.
    ///
    /// የመጀመሪያው እሴት accumulator በመጀመሪያው ጥሪ ላይ ይኖረዋል ዋጋ ነው.
    ///
    /// የ ለተደጋጋሚ እያንዳንዱ አባል ይህን መዘጋት ተግባራዊ በኋላ, `fold()` ወደ accumulator ይመልሳል.
    ///
    /// ይህ ክወና አንዳንድ 'reduce' ወይም 'inject' ይባላል.
    ///
    /// ነገር ስብስብ አለን, እና አንድ ነጠላ ዋጋ ለማምረት በፈለጉበት ጊዜ ታጥፋለህ ጠቃሚ ነው.
    ///
    /// Note: መላው ለተደጋጋሚ ይሻገራሉ መሆኑን `fold()`, እና ተመሳሳይ ዘዴዎች, በዚህም ጋዝም ጊዜ ውስጥ determinable ነው እንኳን traits ላይ, የሌለው iterators ለ ሊያቋርጠው ይችላል.
    ///
    /// Note: የ accumulator አይነት እና ንጥል አይነት ተመሳሳይ ከሆነ [`reduce()`], የመጀመሪያ እሴት እንደ የመጀመሪያው አባል ለመጠቀም ጥቅም ላይ ሊውል ይችላል.
    ///
    /// # Implementors ወደ ማስታወሻ
    ///
    /// በሌላ (forward) ዘዴዎች በርካታ እንዲሁ ነባሪ `for` ሉፕ አፈፃፀም የተሻለ ነገር ማድረግ ይችላል ከሆነ በግልጽ ይህንን ተግባራዊ ለማድረግ ሞክር: ይህ ሰው አኳያ ነባሪ ማስፈጸሚያዎች አላቸው.
    ///
    ///
    /// በተለይ, ይህ ለተደጋጋሚ ያቀፈ ነው ይህም ከ የውስጥ ክፍሎች ላይ ይህን ጥሪ `fold()` እንዲኖረው ለማድረግ ሞክር.
    ///
    /// # Examples
    ///
    /// መሠረታዊ አጠቃቀም
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // በድርድሩ ውስጥ ያሉትን ክፍሎች ሁሉ ድምር
    /// let sum = a.iter().fold(0, |acc, x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// እዚህ ተደጋጋሚነት እያንዳንዱ እርምጃ በኩል እስቲ ይሄዳሉ:
    ///
    /// | element | acc | x | result |
    /// |---------|-----|---|--------|
    /// |         | 0   |   |        |
    /// | 1       | 0   | 1 | 1      |
    /// | 2       | 1   | 2 | 3      |
    /// | 3       | 3   | 3 | 6      |
    ///
    /// ስለዚህ የእኛ የመጨረሻ ውጤት, `6`.
    ///
    /// በዚህም ለመገንባት ነገሮች ዝርዝር ጋር `for` ሉፕ መጠቀም iterators ብዙ ነገር ተጠቅመው የማያውቁ ሰዎች ይህ የጋራ.እነዚያ `fold()`s ይለወጣል ይችላሉ:
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let mut result = 0;
    ///
    /// // ምልልስ ለ:
    /// for i in &numbers {
    ///     result = result + i;
    /// }
    ///
    /// // fold:
    /// let result2 = numbers.iter().fold(0, |acc, &x| acc + x);
    ///
    /// // እነዚህ ተመሳሳይ ከሆኑ
    /// assert_eq!(result, result2);
    /// ```
    ///
    /// [`reduce()`]: Iterator::reduce
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[doc(alias = "reduce")]
    #[doc(alias = "inject")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x);
        }
        accum
    }

    /// በተደጋጋሚ አንድ በመቀነስ ክወና ተግባራዊ በማድረግ, አንድ ሰው ወደ ንጥረ ይቀንሳል.
    ///
    /// የ ለተደጋጋሚ ባዶ ከሆነ, [`None`] ይመልሳል;አለበለዚያ የቅነሳውን ውጤት ይመልሳል።
    ///
    /// ቢያንስ አንድ ኤለመንት ጋር iterators, ይሄ ወደ እርስዋ ሁሉ በቀጣይ አባል በማጠፍ የመጀመሪያ እሴት እንደ ለተደጋጋሚ የመጀመሪያ ኤለመንት ጋር [`fold()`] እንደ ተመሳሳይ ነው.
    ///
    ///
    /// [`fold()`]: Iterator::fold
    ///
    /// # Example
    ///
    /// ከፍተኛውን እሴት ያግኙ
    ///
    /// ```
    /// fn find_max<I>(iter: I) -> Option<I::Item>
    ///     where I: Iterator,
    ///           I::Item: Ord,
    /// {
    ///     iter.reduce(|a, b| {
    ///         if a >= b { a } else { b }
    ///     })
    /// }
    /// let a = [10, 20, 5, -23, 0];
    /// let b: [u32; 0] = [];
    ///
    /// assert_eq!(find_max(a.iter()), Some(&20));
    /// assert_eq!(find_max(b.iter()), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_fold_self", since = "1.51.0")]
    fn reduce<F>(mut self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(Self::Item, Self::Item) -> Self::Item,
    {
        let first = self.next()?;
        Some(self.fold(first, f))
    }

    /// እያንዳንዱ የአመልካች ንጥረ ነገር ከአንድ ተንታኝ ጋር የሚዛመድ ከሆነ ሙከራዎች።
    ///
    /// `all()` `true` ወይም `false` ን የሚመልስ መዘጋት ይወስዳል።ይህንን መዘጋት ለእያንዳንዱ ለተመልካች አካል ይተገበራል ፣ እና ሁሉም `true` ን ከመለሱ `all()` እንዲሁ ነው።
    /// ከእነሱ ማንኛውም `false` መመለስ ከሆነ `false` ይመልሳል.
    ///
    /// `all()` አጭር ማዞሪያ ነው;ይህ ሌላ ምን ምንም ይሁን, ውጤቱ ደግሞ `false` እንደሚሆን የተሰጠ አንድ `false` ካገኘው እንደ በሌላ አባባል, ይህ እንደ በቅርቡ በማስኬድ ያቆማሉ.
    ///
    ///
    /// አንድ ባዶ ለተደጋጋሚ `true` ይመልሳል.
    ///
    /// # Examples
    ///
    /// መሠረታዊ አጠቃቀም
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().all(|&x| x > 0));
    ///
    /// assert!(!a.iter().all(|&x| x > 2));
    /// ```
    ///
    /// በመጀመሪያው `false` ላይ ማቆም:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(!iter.all(|&x| x != 2));
    ///
    /// // ተጨማሪ ክፍሎች አሉ እንደ እኛ አሁንም, `iter` መጠቀም ይችላሉ.
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    ///
    ///
    #[doc(alias = "every")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn all<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::CONTINUE } else { ControlFlow::BREAK }
            }
        }
        self.try_fold((), check(f)) == ControlFlow::CONTINUE
    }

    /// የተደጋጋሚው ማንኛውም ንጥረ ነገር ከተነባቢው ጋር የሚዛመድ ከሆነ ሙከራዎች።
    ///
    /// `any()` `true` ወይም `false` ን የሚመልስ መዘጋት ይወስዳል።ይህንን መዘጋት በእያንዳንዱ ተደጋጋሚ ንጥረ-ነገር ላይ ይተገበራል ፣ እና ማንኛቸውም `true` ን ከተመለሱ `any()` ን ይመለሳል።
    /// ሁሉም `false` መመለስ ከሆነ `false` ይመልሳል.
    ///
    /// `any()` አጭር-circuiting ነው;ይህ ሌላ ምን ምንም ይሁን, ውጤቱ ደግሞ `true` እንደሚሆን የተሰጠ አንድ `true` ካገኘው እንደ በሌላ አባባል, ይህ እንደ በቅርቡ በማስኬድ ያቆማሉ.
    ///
    ///
    /// አንድ ባዶ ለተደጋጋሚ `false` ይመልሳል.
    ///
    /// # Examples
    ///
    /// መሠረታዊ አጠቃቀም
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().any(|&x| x > 0));
    ///
    /// assert!(!a.iter().any(|&x| x > 5));
    /// ```
    ///
    /// የመጀመሪያው `true` ላይ በማቆም:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(iter.any(|&x| x != 2));
    ///
    /// // ተጨማሪ ክፍሎች አሉ እንደ እኛ አሁንም, `iter` መጠቀም ይችላሉ.
    /// assert_eq!(iter.next(), Some(&2));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn any<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::BREAK } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(f)) == ControlFlow::BREAK
    }

    /// የሚያጠግብ ተሳቢ አንድ ለተደጋጋሚ አንድ ኤለመንት ፍለጋዎች.
    ///
    /// `find()` `true` ወይም `false` ይመልሳል አንድ መዘጋት ይወስዳል.
    /// ይህም ለተደጋጋሚ እያንዳንዱ አባል ይህን መዘጋት የሚመለከተው, እና እነሱን በማንኛውም `true` ለመመለስ ከሆነ, ከዚያም `find()` [`Some(element)`] ይመልሳል.
    /// ሁሉም `false` ን ከመለሱ [`None`] ን ይመልሳል።
    ///
    /// `find()` አጭር-circuiting ነው;በሌላ አባባል, ይህ ወዲያውኑ ወደ መዘጋት `true` ይመልሳል እንደ በማስኬድ ያቆማሉ.
    ///
    /// `find()` ማጣቀሻ ስለሚወስድ እና ብዙ ተጓeraች በማጣቀሻዎች ላይ ስለሚጨምሩ ፣ ይህ ምናልባት ክርክሩ ድርብ ማጣቀሻ ወደሆነ ግራ የሚያጋባ ሁኔታ ያስከትላል ፡፡
    ///
    /// ይህንን ውጤት ከዚህ በታች ባሉት ምሳሌዎች ከ `&&x` ጋር ማየት ይችላሉ ፡፡
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// መሠረታዊ አጠቃቀም
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 5), None);
    /// ```
    ///
    /// የመጀመሪያው `true` ላይ በማቆም:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.find(|&&x| x == 2), Some(&2));
    ///
    /// // ተጨማሪ ክፍሎች አሉ እንደ እኛ አሁንም, `iter` መጠቀም ይችላሉ.
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    /// `iter.find(f)` `iter.filter(f).next()` ጋር ተመጣጣኝ መሆኑን ልብ ይበሉ.
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn find<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(predicate)).break_value()
    }

    /// ለተደጋጋሚ ንጥረ ነገሮች ተግባርን ይተገብራል እናም የመጀመሪያውን ያልሆነ ውጤት ያስገኛል ፡፡
    ///
    ///
    /// `iter.find_map(f)` `iter.filter_map(f).next()` ጋር ተመጣጣኝ ነው.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ["lol", "NaN", "2", "5"];
    ///
    /// let first_number = a.iter().find_map(|s| s.parse().ok());
    ///
    /// assert_eq!(first_number, Some(2));
    /// ```
    #[inline]
    #[stable(feature = "iterator_find_map", since = "1.30.0")]
    fn find_map<B, F>(&mut self, f: F) -> Option<B>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        #[inline]
        fn check<T, B>(mut f: impl FnMut(T) -> Option<B>) -> impl FnMut((), T) -> ControlFlow<B> {
            move |(), x| match f(x) {
                Some(x) => ControlFlow::Break(x),
                None => ControlFlow::CONTINUE,
            }
        }

        self.try_fold((), check(f)).break_value()
    }

    /// ለተደጋጋሚ ንጥረ ነገሮች ተግባርን ይተገብራል እናም የመጀመሪያውን እውነተኛ ውጤት ወይም የመጀመሪያውን ስህተት ይመልሳል።
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_find)]
    ///
    /// let a = ["1", "2", "lol", "NaN", "5"];
    ///
    /// let is_my_num = |s: &str, search: i32| -> Result<bool, std::num::ParseIntError> {
    ///     Ok(s.parse::<i32>()?  == search)
    /// };
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 2));
    /// assert_eq!(result, Ok(Some(&"2")));
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 5));
    /// assert!(result.is_err());
    /// ```
    #[inline]
    #[unstable(feature = "try_find", reason = "new API", issue = "63178")]
    fn try_find<F, R>(&mut self, f: F) -> Result<Option<Self::Item>, R::Error>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> R,
        R: Try<Ok = bool>,
    {
        #[inline]
        fn check<F, T, R>(mut f: F) -> impl FnMut((), T) -> ControlFlow<Result<T, R::Error>>
        where
            F: FnMut(&T) -> R,
            R: Try<Ok = bool>,
        {
            move |(), x| match f(&x).into_result() {
                Ok(false) => ControlFlow::CONTINUE,
                Ok(true) => ControlFlow::Break(Ok(x)),
                Err(x) => ControlFlow::Break(Err(x)),
            }
        }

        self.try_fold((), check(f)).break_value().transpose()
    }

    /// አንድ ለተደጋጋሚ ውስጥ አንድ ኤለመንት ፍለጋዎች, በውስጡ ጠቋሚ በመመለስ.
    ///
    /// `position()` `true` ወይም `false` ይመልሳል አንድ መዘጋት ይወስዳል.
    /// ይህንን መዘጋት በእያንዳንዱ ተደጋጋሚ ንጥረ ነገር ላይ ይተገበራል ፣ እና አንዳቸው `true` ን ከተመለሰ ከዚያ `position()` [`Some(index)`] ን ይመልሳል።
    /// ሁሉም `false` መመለስ ከሆነ [`None`] ይመልሳል.
    ///
    /// `position()` አጭር ማዞሪያ ነው;አንድ `true` ካገኘው እንደ በሌላ አባባል, ይህ እንደ በቅርቡ በማስኬድ ያቆማሉ.
    ///
    /// # የትርፍ ፍሰት ባህሪ
    ///
    /// ተጨማሪ [`usize::MAX`] ያልሆኑ ተዛማጅ ንጥረ ይልቅ አሉ እንዲህ ከሆነ ዘዴ ነው ወይ የተሳሳተ ውጤት ወይም panics ያፈራል, ያጥለቀልቁታል ላይ ምንም የሚወድዱትን ነው.
    ///
    /// የስህተት ማረጋገጫዎች ከነቁ አንድ panic ዋስትና ተሰጥቶታል።
    ///
    /// # Panics
    ///
    /// ተደጋጋሚው ከ `usize::MAX` የማይዛመዱ አባሎች ካለው ይህ ተግባር panic ን ሊያሳይ ይችላል።
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// መሠረታዊ አጠቃቀም
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().position(|&x| x == 2), Some(1));
    ///
    /// assert_eq!(a.iter().position(|&x| x == 5), None);
    /// ```
    ///
    /// የመጀመሪያው `true` ላይ በማቆም:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.position(|&x| x >= 2), Some(1));
    ///
    /// // ተጨማሪ ክፍሎች አሉ እንደ እኛ አሁንም, `iter` መጠቀም ይችላሉ.
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // የ ተመልሶ ኢንዴክስ ለተደጋጋሚ ሁኔታ ላይ የሚወሰን
    /// assert_eq!(iter.position(|&x| x == 4), Some(0));
    ///
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn position<P>(&mut self, predicate: P) -> Option<usize>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            #[rustc_inherit_overflow_checks]
            move |i, x| {
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i + 1) }
            }
        }

        self.try_fold(0, check(predicate)).break_value()
    }

    /// በቀኝ አንድ ለተደጋጋሚ ውስጥ አንድ ኤለመንት ፍለጋዎች, በውስጡ ጠቋሚ በመመለስ.
    ///
    /// `rposition()` `true` ወይም `false` ይመልሳል አንድ መዘጋት ይወስዳል.
    /// ይህንን መዘጋት በእያንዳንዱ ተደጋጋሚ ንጥረ ነገር ላይ ይሠራል ፣ ከመጀመሪያው ጀምሮ ፣ እና አንዳቸው `true` ን ከተመለሱ `rposition()` [`Some(index)`] ን ይመልሳል።
    ///
    /// ሁሉም `false` መመለስ ከሆነ [`None`] ይመልሳል.
    ///
    /// `rposition()` አጭር ማዞሪያ ነው;አንድ `true` ካገኘው እንደ በሌላ አባባል, ይህ እንደ በቅርቡ በማስኬድ ያቆማሉ.
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// መሠረታዊ አጠቃቀም
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 3), Some(2));
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 5), None);
    /// ```
    ///
    /// የመጀመሪያው `true` ላይ በማቆም:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rposition(|&x| x == 2), Some(1));
    ///
    /// // ተጨማሪ ክፍሎች አሉ እንደ እኛ አሁንም, `iter` መጠቀም ይችላሉ.
    /// assert_eq!(iter.next(), Some(&1));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rposition<P>(&mut self, predicate: P) -> Option<usize>
    where
        P: FnMut(Self::Item) -> bool,
        Self: Sized + ExactSizeIterator + DoubleEndedIterator,
    {
        // `ExactSizeIterator` አንድ `usize` ወደ ንጥረ የሚጣጣመውን ብዛት ያመለክታል ምክንያቱም አንድ ፍሰት ለ አያስፈልግም, እዚህ ላይ ምልክት ያድርጉ.
        //
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            move |i, x| {
                let i = i - 1;
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i) }
            }
        }

        let n = self.len();
        self.try_rfold(n, check(predicate)).break_value()
    }

    /// አንድ ለተደጋጋሚ ከፍተኛውን አባል ይመልሳል.
    ///
    /// በርካታ ንጥረ እኩል ከፍተኛ ከሆነ, የመጨረሻው አባል ተመልሶ ነው.
    /// የ ለተደጋጋሚ ባዶ ከሆነ, [`None`] ተመልሶ ነው.
    ///
    /// # Examples
    ///
    /// መሠረታዊ አጠቃቀም
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().max(), Some(&3));
    /// assert_eq!(b.iter().max(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn max(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.max_by(Ord::cmp)
    }

    /// አንድ ለተደጋጋሚ አነስተኛውን አባል ይመልሳል.
    ///
    /// ብዙ አካላት በእኩል ዝቅተኛ ከሆኑ የመጀመሪያው ንጥረ ነገር ተመልሷል።
    /// የ ለተደጋጋሚ ባዶ ከሆነ, [`None`] ተመልሶ ነው.
    ///
    /// # Examples
    ///
    /// መሠረታዊ አጠቃቀም
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().min(), Some(&1));
    /// assert_eq!(b.iter().min(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn min(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.min_by(Ord::cmp)
    }

    /// ይመልሳል በተጠቀሰው ተግባር ጀምሮ ከፍተኛ ዋጋ የሚሰጠው መሆኑን አባል.
    ///
    ///
    /// በርካታ ንጥረ እኩል ከፍተኛ ከሆነ, የመጨረሻው አባል ተመልሶ ነው.
    /// የ ለተደጋጋሚ ባዶ ከሆነ, [`None`] ተመልሶ ነው.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by_key(|x| x.abs()).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn max_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).max_by(compare)?;
        Some(x)
    }

    /// ይመልሳል በተወሰነ ንጽጽር ተግባር ጋር በተያያዘ ከፍተኛ ዋጋ የሚሰጠው መሆኑን አባል.
    ///
    ///
    /// በርካታ ንጥረ እኩል ከፍተኛ ከሆነ, የመጨረሻው አባል ተመልሶ ነው.
    /// የ ለተደጋጋሚ ባዶ ከሆነ, [`None`] ተመልሶ ነው.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by(|x, y| x.cmp(y)).unwrap(), 5);
    /// ```
    #[inline]
    #[stable(feature = "iter_max_by", since = "1.15.0")]
    fn max_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::max_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// ይመልሳል በተጠቀሰው ተግባር ከ ዝቅተኛ ዋጋ የሚሰጠው መሆኑን አባል.
    ///
    ///
    /// ብዙ አካላት በእኩል ዝቅተኛ ከሆኑ የመጀመሪያው ንጥረ ነገር ተመልሷል።
    /// የ ለተደጋጋሚ ባዶ ከሆነ, [`None`] ተመልሶ ነው.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by_key(|x| x.abs()).unwrap(), 0);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn min_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).min_by(compare)?;
        Some(x)
    }

    /// ይመልሳል በተወሰነ ንጽጽር ተግባር ጋር በተያያዘ ዝቅተኛ ዋጋ የሚሰጠው መሆኑን አባል.
    ///
    ///
    /// ብዙ አካላት በእኩል ዝቅተኛ ከሆኑ የመጀመሪያው ንጥረ ነገር ተመልሷል።
    /// የ ለተደጋጋሚ ባዶ ከሆነ, [`None`] ተመልሶ ነው.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by(|x, y| x.cmp(y)).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_min_by", since = "1.15.0")]
    fn min_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::min_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// አንድ ለተደጋጋሚ አመራር አቅጣጫ ለውጦታል.
    ///
    /// አብዛኛውን ጊዜ, iterators ከግራ ወደ ቀኝ ለመድገም.
    /// `rev()`, በመጠቀም በኋላ አንድ ለተደጋጋሚ ግራ ይልቅ ለመድገም ቀኝ ከ ጋር ያደርጋል.
    ///
    /// ይህ የሚቻለው ተደጋጋሚው መጨረሻ ካለው ብቻ ነው ፣ ስለሆነም `rev()` በ [`DoubleEndedIterator`] ላይ ብቻ ነው የሚሰራው።
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().rev();
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[doc(alias = "reverse")]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rev(self) -> Rev<Self>
    where
        Self: Sized + DoubleEndedIterator,
    {
        Rev::new(self)
    }

    /// መያዣዎች ጥንድ ወደ ጥንዶች አንድ ለተደጋጋሚ ይለውጣል.
    ///
    /// `unzip()` ሁለት ስብስቦችን በማምረት አንድ ጥንድ ተሟጋች አንድን ይወስዳል ፣ አንደኛው ከግራ ጥንዶቹ ግራ እና አንዱ ከቀኝ አካላት።
    ///
    ///
    /// ይህ ተግባር በአንዳንድ ስሜት, [`zip`] ተቃራኒ ውስጥ ነው.
    ///
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// መሠረታዊ አጠቃቀም
    ///
    /// ```
    /// let a = [(1, 2), (3, 4)];
    ///
    /// let (left, right): (Vec<_>, Vec<_>) = a.iter().cloned().unzip();
    ///
    /// assert_eq!(left, [1, 3]);
    /// assert_eq!(right, [2, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn unzip<A, B, FromA, FromB>(self) -> (FromA, FromB)
    where
        FromA: Default + Extend<A>,
        FromB: Default + Extend<B>,
        Self: Sized + Iterator<Item = (A, B)>,
    {
        fn extend<'a, A, B>(
            ts: &'a mut impl Extend<A>,
            us: &'a mut impl Extend<B>,
        ) -> impl FnMut((), (A, B)) + 'a {
            move |(), (t, u)| {
                ts.extend_one(t);
                us.extend_one(u);
            }
        }

        let mut ts: FromA = Default::default();
        let mut us: FromB = Default::default();

        let (lower_bound, _) = self.size_hint();
        if lower_bound > 0 {
            ts.extend_reserve(lower_bound);
            us.extend_reserve(lower_bound);
        }

        self.fold((), extend(&mut ts, &mut us));

        (ts, us)
    }

    /// ሁሉንም ንጥረ ነገሮቹን የሚቀዳ አንድ ተደጋጋሚ ይፈጥራል።
    ///
    /// አንተ `&T` ላይ አንድ ለተደጋጋሚ አለን ጊዜ ይህ ጠቃሚ ነው, ነገር ግን `T` ላይ አንድ ለተደጋጋሚ ያስፈልጋቸዋል.
    ///
    ///
    /// # Examples
    ///
    /// መሠረታዊ አጠቃቀም
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_copied: Vec<_> = a.iter().copied().collect();
    ///
    /// // የተቀዳ .map(|&x| x) ጋር ተመሳሳይ ነው
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_copied, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "iter_copied", since = "1.36.0")]
    fn copied<'a, T: 'a>(self) -> Copied<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Copy,
    {
        Copied::new(self)
    }

    /// ሁሉንም ንጥረ ነገሮቹን [`clone`] የሆነ ተደጋጋሚነት ይፈጥራል።
    ///
    /// አንተ `&T` ላይ አንድ ለተደጋጋሚ አለን ጊዜ ይህ ጠቃሚ ነው, ነገር ግን `T` ላይ አንድ ለተደጋጋሚ ያስፈልጋቸዋል.
    ///
    ///
    /// [`clone`]: Clone::clone
    ///
    /// # Examples
    ///
    /// መሠረታዊ አጠቃቀም
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_cloned: Vec<_> = a.iter().cloned().collect();
    ///
    /// // በክሎኒንግ የመቁጠሪያ ለ, .map(|&x| x) እንደ ተመሳሳይ ነው
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_cloned, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn cloned<'a, T: 'a>(self) -> Cloned<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Clone,
    {
        Cloned::new(self)
    }

    /// ማለቂያ አንድ ለተደጋጋሚ ይደግማል.
    ///
    /// [`None`] ን ከማቆም ይልቅ ተደጋጋሚው ከመጀመሪያው ጀምሮ እንደገና ይጀምራል።እንደገና iterating በኋላ, እንደገና መጀመሪያ ላይ ይጀምራል.ደግሞም.
    /// ደግሞም.
    /// Forever.
    ///
    /// # Examples
    ///
    /// መሠረታዊ አጠቃቀም
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut it = a.iter().cycle();
    ///
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    fn cycle(self) -> Cycle<Self>
    where
        Self: Sized + Clone,
    {
        Cycle::new(self)
    }

    /// የአንድ ተደጋጋሚ ንጥረ ነገሮችን ያጠቃልላል።
    ///
    /// እያንዳንዱን ንጥረ ነገር ይወስዳል ፣ በአንድ ላይ ያክላል እና ውጤቱን ይመልሳል።
    ///
    /// አንድ ባዶ ለተደጋጋሚ ዓይነት ያለውን ዜሮ እሴት ይመልሳል.
    ///
    /// # Panics
    ///
    /// `sum()` በመደወል እና ኋላቀር የኢንቲጀር አይነት ተመልሶ ነው ጊዜ, ይህ ዘዴ panic ወደ ስሌት ያጥለቀልቁታል እና የማረም ከተናገሯቸው የነቁ ናቸው ከሆነ.
    ///
    ///
    /// # Examples
    ///
    /// መሠረታዊ አጠቃቀም
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let sum: i32 = a.iter().sum();
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn sum<S>(self) -> S
    where
        Self: Sized,
        S: Sum<Self::Item>,
    {
        Sum::sum(self)
    }

    /// ሁሉም ንጥረ ነገሮች እየበዙ መላውን ለተደጋጋሚ ላይ Iterates,
    ///
    /// አንድ ባዶ ለተደጋጋሚ ዓይነት አንድ እሴት ይመልሳል.
    ///
    /// # Panics
    ///
    /// `product()` በመደወል እና ኋላቀር የኢንቲጀር አይነት ተመልሶ እየተደረገ ጊዜ ዘዴ panic ወደ ስሌት ያጥለቀልቁታል እና የማረም ከተናገሯቸው የነቁ ናቸው ከሆነ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// fn factorial(n: u32) -> u32 {
    ///     (1..=n).product()
    /// }
    /// assert_eq!(factorial(0), 1);
    /// assert_eq!(factorial(1), 1);
    /// assert_eq!(factorial(5), 120);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn product<P>(self) -> P
    where
        Self: Sized,
        P: Product<Self::Item>,
    {
        Product::product(self)
    }

    /// [Lexicographically](Ord#lexicographical-comparison) ከሌላ ሰዎች ጋር በዚህ [`Iterator`] ያለውን ንጥረ ነገሮች ጋር ያመሳስለዋል.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1].iter().cmp([1].iter()), Ordering::Equal);
    /// assert_eq!([1].iter().cmp([1, 2].iter()), Ordering::Less);
    /// assert_eq!([1, 2].iter().cmp([1].iter()), Ordering::Greater);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn cmp<I>(self, other: I) -> Ordering
    where
        I: IntoIterator<Item = Self::Item>,
        Self::Item: Ord,
        Self: Sized,
    {
        self.cmp_by(other, |x, y| x.cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) ከተጠቀሰው የንፅፅር ተግባር አንጻር የዚህ [`Iterator`] ን ንጥረ ነገሮችን ከሌላው ጋር ያወዳድራል።
    ///
    ///
    /// # Examples
    ///
    /// መሠረታዊ አጠቃቀም
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| x.cmp(&y)), Ordering::Less);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (x * x).cmp(&y)), Ordering::Equal);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (2 * x).cmp(&y)), Ordering::Greater);
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn cmp_by<I, F>(mut self, other: I, mut cmp: F) -> Ordering
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Ordering,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Ordering::Equal;
                    } else {
                        return Ordering::Less;
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Ordering::Greater,
                Some(val) => val,
            };

            match cmp(x, y) {
                Ordering::Equal => (),
                non_eq => return non_eq,
            }
        }
    }

    /// [Lexicographically](Ord#lexicographical-comparison) ከሌላ ሰዎች ጋር በዚህ [`Iterator`] ያለውን ንጥረ ነገሮች ጋር ያመሳስለዋል.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1.].iter().partial_cmp([1.].iter()), Some(Ordering::Equal));
    /// assert_eq!([1.].iter().partial_cmp([1., 2.].iter()), Some(Ordering::Less));
    /// assert_eq!([1., 2.].iter().partial_cmp([1.].iter()), Some(Ordering::Greater));
    ///
    /// assert_eq!([f64::NAN].iter().partial_cmp([1.].iter()), None);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn partial_cmp<I>(self, other: I) -> Option<Ordering>
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp_by(other, |x, y| x.partial_cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) ከተጠቀሰው የንፅፅር ተግባር አንጻር የዚህ [`Iterator`] ን ንጥረ ነገሮችን ከሌላው ጋር ያወዳድራል።
    ///
    ///
    /// # Examples
    ///
    /// መሠረታዊ አጠቃቀም
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1.0, 2.0, 3.0, 4.0];
    /// let ys = [1.0, 4.0, 9.0, 16.0];
    ///
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| x.partial_cmp(&y)),
    ///     Some(Ordering::Less)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (x * x).partial_cmp(&y)),
    ///     Some(Ordering::Equal)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (2.0 * x).partial_cmp(&y)),
    ///     Some(Ordering::Greater)
    /// );
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn partial_cmp_by<I, F>(mut self, other: I, mut partial_cmp: F) -> Option<Ordering>
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Option<Ordering>,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Some(Ordering::Equal);
                    } else {
                        return Some(Ordering::Less);
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Some(Ordering::Greater),
                Some(val) => val,
            };

            match partial_cmp(x, y) {
                Some(Ordering::Equal) => (),
                non_eq => return non_eq,
            }
        }
    }

    /// ይህ [`Iterator`] ስለ ንጥረ ነገሮች ሌላ ሰዎች ጋር እኩል ናቸው ከሆነ ይወስናል.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().eq([1].iter()), true);
    /// assert_eq!([1].iter().eq([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn eq<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        self.eq_by(other, |x, y| x == y)
    }

    /// ይህ [`Iterator`] ውስጥ ንጥረ በተጠቀሱት እኩልነት ተግባር ጋር በተያያዘ ሌላ ሰዎች ጋር እኩል ናቸው ከሆነ ይወስናል.
    ///
    ///
    /// # Examples
    ///
    /// መሠረታዊ አጠቃቀም
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert!(xs.iter().eq_by(&ys, |&x, &y| x * x == y));
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn eq_by<I, F>(mut self, other: I, mut eq: F) -> bool
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> bool,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => return other.next().is_none(),
                Some(val) => val,
            };

            let y = match other.next() {
                None => return false,
                Some(val) => val,
            };

            if !eq(x, y) {
                return false;
            }
        }
    }

    /// ይህ [`Iterator`] ስለ ንጥረ ነገሮች ሌላ ሰዎች ጋር እኩል ናቸው ከሆነ ይወስናል.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ne([1].iter()), false);
    /// assert_eq!([1].iter().ne([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ne<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        !self.eq(other)
    }

    /// የዚህ [`Iterator`] ንጥረ ነገሮች ከሌላው ከሌሎቹ [lexicographically](Ord#lexicographical-comparison) ያነሱ እንደሆኑ ይወስናል።
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().lt([1].iter()), false);
    /// assert_eq!([1].iter().lt([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().lt([1].iter()), false);
    /// assert_eq!([1, 2].iter().lt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn lt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Less)
    }

    /// ይህ [`Iterator`] ውስጥ ያሉትን ክፍሎች ናቸው [lexicographically](Ord#lexicographical-comparison) ያነሰ ወይም ሌላ ሰዎች ጋር እኩል ከሆነ የሚወስነው.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().le([1].iter()), true);
    /// assert_eq!([1].iter().le([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().le([1].iter()), false);
    /// assert_eq!([1, 2].iter().le([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn le<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Less | Ordering::Equal))
    }

    /// የዚህ [`Iterator`] ንጥረ ነገሮች ከሌላው ከሌሎቹ [lexicographically](Ord#lexicographical-comparison) የሚበልጡ እንደሆኑ ይወስናል።
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().gt([1].iter()), false);
    /// assert_eq!([1].iter().gt([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().gt([1].iter()), true);
    /// assert_eq!([1, 2].iter().gt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn gt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Greater)
    }

    /// የዚህ [`Iterator`] አካላት ከሌላው ከሌሎቹ የበለጠ ወይም እኩል ከሆኑ [lexicographically](Ord#lexicographical-comparison) እንደሆኑ ይወስናል።
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ge([1].iter()), true);
    /// assert_eq!([1].iter().ge([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().ge([1].iter()), true);
    /// assert_eq!([1, 2].iter().ge([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ge<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Greater | Ordering::Equal))
    }

    /// ቼኮች በዚህ ለተደጋጋሚ ያለውን ንጥረ ተደርድረዋል ከሆነ.
    ///
    /// ነው, እያንዳንዱ አባል `a` እና የሚከተለውን ኤለመንት `b` ለ, `a <= b` መያዝ አለበት.ተደጋጋሚው በትክክል ዜሮ ወይም አንድ አካል ካመነጨ ፣ `true` ተመልሷል።
    ///
    /// `Self::Item` ብቻ `PartialOrd` እንጂ `Ord` ከሆነ ማስታወሻ: ከላይ ትርጉም ማንኛውም ሁለት ተከታታይ ንጥሎች ተመጣጣኝ አይደሉም ከሆነ ይህ ተግባር `false` ይመልሳል እንደሆነ በሚያስመስል.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted());
    /// assert!(![1, 3, 2, 4].iter().is_sorted());
    /// assert!([0].iter().is_sorted());
    /// assert!(std::iter::empty::<i32>().is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted(self) -> bool
    where
        Self: Sized,
        Self::Item: PartialOrd,
    {
        self.is_sorted_by(PartialOrd::partial_cmp)
    }

    /// በዚህ ለተደጋጋሚ ያለውን ንጥረ የተሰጠውን comparator ተግባር በመጠቀም ተደርድረዋል ከሆነ ያረጋግጣል.
    ///
    /// `PartialOrd::partial_cmp` ን ከመጠቀም ይልቅ ይህ ተግባር የሁለት አካላት ቅደም ተከተል ለመወሰን የተሰጠውን የ `compare` ተግባር ይጠቀማል።
    /// ባሻገር በዚያ ጀምሮ, ይህም [`is_sorted`] ጋር እኩል ነው;ተጨማሪ መረጃ ለማግኘት ያለውን ሰነድ ይመልከቱ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![1, 3, 2, 4].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!([0].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(std::iter::empty::<i32>().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// ```
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by<F>(mut self, compare: F) -> bool
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Option<Ordering>,
    {
        #[inline]
        fn check<'a, T>(
            last: &'a mut T,
            mut compare: impl FnMut(&T, &T) -> Option<Ordering> + 'a,
        ) -> impl FnMut(T) -> bool + 'a {
            move |curr| {
                if let Some(Ordering::Greater) | None = compare(&last, &curr) {
                    return false;
                }
                *last = curr;
                true
            }
        }

        let mut last = match self.next() {
            Some(e) => e,
            None => return true,
        };

        self.all(check(&mut last, compare))
    }

    /// በዚህ ለተደጋጋሚ ያለውን ንጥረ የተሰጠውን ቁልፍ ተፈብርኮ ተግባር በመጠቀም ተደርድረዋል ከሆነ ያረጋግጣል.
    ///
    /// ይልቅ በቀጥታ ለተደጋጋሚ ያለው ንጥረ በማወዳደር, ይህ ተግባር `f` ውሳኔ መሠረት, ንጥረ መክፈቻዎች ጋር ያመሳስለዋል.
    /// ባሻገር በዚያ ጀምሮ, ይህም [`is_sorted`] ጋር እኩል ነው;ተጨማሪ መረጃ ለማግኘት ያለውን ሰነድ ይመልከቱ.
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].iter().is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].iter().is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by_key<F, K>(self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> K,
        K: PartialOrd,
    {
        self.map(f).is_sorted()
    }

    /// ይመልከቱ [TrustedRandomAccess]
    // የ ያልተለመደ ስም #76479 ተመልከት ዘዴ ጥራት ስም, ግጭት ማስወገድ ነው.
    //
    #[inline]
    #[doc(hidden)]
    #[unstable(feature = "trusted_random_access", issue = "none")]
    unsafe fn __iterator_get_unchecked(&mut self, _idx: usize) -> Self::Item
    where
        Self: TrustedRandomAccess,
    {
        unreachable!("Always specialized");
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator + ?Sized> Iterator for &mut I {
    type Item = I::Item;
    fn next(&mut self) -> Option<I::Item> {
        (**self).next()
    }
    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_by(n)
    }
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        (**self).nth(n)
    }
}