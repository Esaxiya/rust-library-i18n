/// በውስጡ ትክክለኛ ርዝመት የሚያውቅ እንደሆነ አንድ ለተደጋጋሚ.
///
/// ብዙዎቹ [`Iterator`] ን ስንት ጊዜ እነሱ ለመድገም ፈቃድ አላውቅም, ነገር ግን አንዳንዶች ማድረግ.
/// አንድ ለተደጋጋሚ ይህን ለመድገም እንችላለን ስንት ጊዜ የሚያውቅ ከሆነ, ይህን መረጃ መዳረሻ መስጠት ጠቃሚ ሊሆን ይችላል.
/// እርስዎ ኋላ ለመድገም ከፈለጉ ለምሳሌ ያህል, አንድ ጥሩ ጅምር መጨረሻው የት ማወቅ ነው.
///
/// `ExactSizeIterator` ን ሲተገብሩ እርስዎም [`Iterator`] ን መተግበር አለብዎት።
/// እንዲህ ማድረግ ጊዜ, [`Iterator::size_hint`] ትግበራ * * ስለ ለተደጋጋሚ ትክክለኛ መጠን መመለስ አለበት.
///
/// አብዛኛውን ጊዜ እሱን ለመተግበር አይገባም እንዲችሉ [`len`] ዘዴ, ነባሪ አፈፃፀም አለው.
/// ሆኖም ግን, በዚህ ሁኔታ ውስጥ ነየእስራኤላውያንን ትርጉም ይሰጣል, ነባሪ የበለጠ performant አፈፃፀም ማቅረብ ይችሉ ይሆናል.
///
///
/// ይህ trait ደህንነቱ የተጠበቀ trait መሆኑን ልብ ይበሉ እና እንደዚያም *የተመለሰው ርዝመት ትክክል አለመሆኑን* አያደርግም *እና* አይችልም ፡፡
/// `unsafe` ኮድ ** **[`Iterator::size_hint`] ያለውን ትክክለኛነት ላይ መተማመን የለበትም ይህ ማለት.
/// ያልተረጋጋ እና ደህንነቱ ያልተጠበቀ [`TrustedLen`](super::marker::TrustedLen) trait ለዚህ ተጨማሪ ዋስትና ይሰጣል።
///
/// [`len`]: ExactSizeIterator::len
///
/// # Examples
///
/// መሠረታዊ አጠቃቀም
///
/// ```
/// // ጋዝም ክልል ይህን ለመድገም እንዴት ብዙ ጊዜ በትክክል ያውቃል
/// let five = 0..5;
///
/// assert_eq!(5, five.len());
/// ```
///
/// በ [module-level docs] ውስጥ, እኛ, አንድ [`Iterator`] አልተተገበረም `Counter`.
/// `ExactSizeIterator` ን ለእሱም ተግባራዊ እናድርግ
///
/// [module-level docs]: crate::iter
///
/// ```
/// # struct Counter {
/// #     count: usize,
/// # }
/// # impl Counter {
/// #     fn new() -> Counter {
/// #         Counter { count: 0 }
/// #     }
/// # }
/// # impl Iterator for Counter {
/// #     type Item = usize;
/// #     fn next(&mut self) -> Option<Self::Item> {
/// #         self.count += 1;
/// #         if self.count < 6 {
/// #             Some(self.count)
/// #         } else {
/// #             None
/// #         }
/// #     }
/// # }
/// impl ExactSizeIterator for Counter {
///     // የቀሩትን ድግግሞሾች ብዛት በቀላሉ ማስላት እንችላለን።
///     fn len(&self) -> usize {
///         5 - self.count
///     }
/// }
///
/// // እና አሁን ሊጠቀሙበት ይችላሉ!
///
/// let counter = Counter::new();
///
/// assert_eq!(5, counter.len());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ExactSizeIterator: Iterator {
    /// የተደጋጋሚውን ትክክለኛ ርዝመት ይመልሳል።
    ///
    /// የ ለተደጋጋሚ [`None`] ከመመለሳቸው በፊት, በትክክል `len()` ተጨማሪ ጊዜ አንድ [`Some(T)`] እሴት ይመለሳል የሚለው አፈፃፀም ያረጋግጣል.
    ///
    /// ይህ ዘዴ ነባሪ አፈፃፀም አለው, ስለዚህ አብዛኛውን ጊዜ በቀጥታ ተግባራዊ አይገባም.
    /// አንድ ይበልጥ ውጤታማ አፈፃፀም ማቅረብ ይችላል ይሁን እንጂ, እርስዎ ማድረግ ይችላሉ.
    /// ምሳሌ ለማግኘት [trait-level] ሰነዶች ይመልከቱ.
    ///
    /// ይህ ተግባር [`Iterator::size_hint`] ተግባር ጋር ተመሳሳይ የደህንነት ዋስትና አለው.
    ///
    /// [trait-level]: ExactSizeIterator
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// መሠረታዊ አጠቃቀም
    ///
    /// ```
    /// // ጋዝም ክልል ይህን ለመድገም እንዴት ብዙ ጊዜ በትክክል ያውቃል
    /// let five = 0..5;
    ///
    /// assert_eq!(5, five.len());
    /// ```
    ///
    ///
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn len(&self) -> usize {
        let (lower, upper) = self.size_hint();
        // Note: ይህ የተጨመረ ከልክ የመከላከያ ነው, ነገር ግን invariant የሚገልጿቸው
        // በ trait በ ዋስትና.
        // ይህ trait rust-ውስጣዊ ነበር ከሆነ debug_assert መጠቀም ይችላል !;assert_eq!በጣም ሁሉ Rust ተጠቃሚ አፈጻጸም ማረጋገጥ ይሆናል.
        //
        assert_eq!(upper, Some(lower));
        lower
    }

    /// ይመለሳል `true` ወደ ለተደጋጋሚ ባዶ ከሆነ.
    ///
    /// አንተ ራስህ ለመተግበር አያስፈልጋቸውም, ስለዚህ ይህ ዘዴ, [`ExactSizeIterator::len()`] በመጠቀም ነባሪ አፈፃፀም አለው.
    ///
    ///
    /// # Examples
    ///
    /// መሠረታዊ አጠቃቀም
    ///
    /// ```
    /// #![feature(exact_size_is_empty)]
    ///
    /// let mut one_element = std::iter::once(0);
    /// assert!(!one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), Some(0));
    /// assert!(one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), None);
    /// ```
    #[inline]
    #[unstable(feature = "exact_size_is_empty", issue = "35428")]
    fn is_empty(&self) -> bool {
        self.len() == 0
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator + ?Sized> ExactSizeIterator for &mut I {
    fn len(&self) -> usize {
        (**self).len()
    }
    fn is_empty(&self) -> bool {
        (**self).is_empty()
    }
}