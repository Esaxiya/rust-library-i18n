use crate::ops::{ControlFlow, Try};

/// በሁለቱም ጫፎች ከ አይወጣም አባሎችን የሚችል አንድ ለተደጋጋሚ.
///
/// የሆነ ነገር መሳሪያዎች `DoubleEndedIterator` መሳሪያዎች [`Iterator`] ነገር ላይ አንድ ተጨማሪ ችሎታ እንዳለው: ደግሞ ችሎታ `ከኋላ Item`s, እንዲሁም ከፊት ውሰድ.
///
///
/// ወደፊትም ሆነ ወደፊት በአንድ ክልል ላይ እንደሚሠሩ መገንዘቡ አስፈላጊ ነው ፣ እና አይሻገሩ-በመሃል ላይ ሲገናኙ ድግግሞሽ አብቅቷል ፡፡
///
/// ወደ [`Iterator`] ፕሮቶኮል ጋር ተመሳሳይ ፋሽን, አንዴ አንድ `DoubleEndedIterator` እንደገና በመደወል ወይም ዳግም [`Some`] መመለስ አይችሉም ይችላል, አንድ [`next_back()`] ከ [`None`] ይመልሳል.
/// [`next()`] እና [`next_back()`] ለዚህ ዓላማ የሚለዋወጥ ነው.
///
/// [`next_back()`]: DoubleEndedIterator::next_back
/// [`next()`]: Iterator::next
///
/// # Examples
///
/// መሠረታዊ አጠቃቀም
///
/// ```
/// let numbers = vec![1, 2, 3, 4, 5, 6];
///
/// let mut iter = numbers.iter();
///
/// assert_eq!(Some(&1), iter.next());
/// assert_eq!(Some(&6), iter.next_back());
/// assert_eq!(Some(&5), iter.next_back());
/// assert_eq!(Some(&2), iter.next());
/// assert_eq!(Some(&3), iter.next());
/// assert_eq!(Some(&4), iter.next());
/// assert_eq!(None, iter.next());
/// assert_eq!(None, iter.next_back());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DoubleEndedIterator: Iterator {
    /// ከተደጋጋሚው መጨረሻ አንድ ንጥረ ነገር ያስወግዳል እና ይመልሳል።
    ///
    /// ምንም ተጨማሪ ነገሮች አሉ ጊዜ `None` ያወጣል.
    ///
    /// የ [trait-level] ሰነዶች ተጨማሪ ዝርዝሮችን ይዘዋል።
    ///
    /// [trait-level]: DoubleEndedIterator
    ///
    /// # Examples
    ///
    /// መሠረታዊ አጠቃቀም
    ///
    /// ```
    /// let numbers = vec![1, 2, 3, 4, 5, 6];
    ///
    /// let mut iter = numbers.iter();
    ///
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&6), iter.next_back());
    /// assert_eq!(Some(&5), iter.next_back());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    /// assert_eq!(Some(&4), iter.next());
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next_back());
    /// ```
    ///
    /// # Remarks
    ///
    /// ሰዎች የተለየ ይሆናል DoubleEndedIterator`ዘዴ`በ ተከትለዋል ንጥረ ነገሮች [`Iterator`] ን ዘዴዎች በ ተወ:
    ///
    ///
    /// ```
    /// let vec = vec![(1, 'a'), (1, 'b'), (1, 'c'), (2, 'a'), (2, 'b')];
    /// let uniq_by_fst_comp = || {
    ///     let mut seen = std::collections::HashSet::new();
    ///     vec.iter().copied().filter(move |x| seen.insert(x.0))
    /// };
    ///
    /// assert_eq!(uniq_by_fst_comp().last(), Some((2, 'a')));
    /// assert_eq!(uniq_by_fst_comp().next_back(), Some((2, 'b')));
    ///
    /// assert_eq!(
    ///     uniq_by_fst_comp().fold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(1, 'a'), (2, 'a')]
    /// );
    /// assert_eq!(
    ///     uniq_by_fst_comp().rfold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(2, 'b'), (1, 'c')]
    /// );
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next_back(&mut self) -> Option<Self::Item>;

    /// ተደጋጋሚውን በ `n` አባሎች ከጀርባ ያራምዳል።
    ///
    /// `advance_back_by` [`advance_by`] ያለውን በግልባጭ ስሪት ነው.ይህ ዘዴ በጉጉት [`None`] አጋጥሞታል ድረስ `n` ጊዜ [`next_back`] እስከ በመደወል ጀርባ ጀምሮ `n` ንጥረ ይዘሉታል.
    ///
    /// `advance_back_by(n)` የ ለተደጋጋሚ በተሳካ [`None`] `k` ወደ ለተደጋጋሚ ከፍተኛ ነው ንጥረ ቁጥር ባለበት አጋጥሞታል ከሆነ `n` ንጥረ ነገሮች በማድረግ የሚያራምድ, ወይም [`Err(k)`] ከሆነ በ አባሎችን እያለቀ በፊት [`Ok(())`] ይመለሳሉ (ማለትም
    /// ወደ ለተደጋጋሚ ርዝመት).
    /// `k` ሁልጊዜ ያነሰ `n` በላይ መሆኑን ልብ ይበሉ.
    ///
    /// በመደወል `advance_back_by(0)` ማንኛውንም ንጥረ ነገሮች ነው የሚጠቀሙት, እና ሁልጊዜ [`Ok(())`] ይመልሳል አይደለም.
    ///
    /// [`advance_by`]: Iterator::advance_by
    /// [`next_back`]: DoubleEndedIterator::next_back
    ///
    /// # Examples
    ///
    /// መሠረታዊ አጠቃቀም
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [3, 4, 5, 6];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_back_by(2), Ok(()));
    /// assert_eq!(iter.next_back(), Some(&4));
    /// assert_eq!(iter.advance_back_by(0), Ok(()));
    /// assert_eq!(iter.advance_back_by(100), Err(1)); // ብቻ `&3` ተዘልሏል ነበር
    /// ```
    ///
    /// [`Ok(())`]: Ok
    /// [`Err(k)`]: Err
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next_back().ok_or(i)?;
        }
        Ok(())
    }

    /// ይመልሳል ለተደጋጋሚ መጨረሻ ጀምሮ `n`th አባል.
    ///
    /// ይህ በመሠረቱ [`Iterator::nth()`] ያለውን ሊቀለበስ ስሪት ነው.
    /// `nth_back(0)`, `nth_back(1)` ሁለተኛው እና በጣም ላይ መጨረሻ ጀምሮ የመጀመሪያው እሴት ይመልሳል ስለዚህ አብዛኞቹ በመዳሰስና ክወናዎችን እንደ ቢሆንም, የመቁጠር, ዜሮ ከ ይጀምራል.
    ///
    ///
    /// መጨረሻ እና ተመልሶ አባል መካከል ሁሉንም ነገሮች ወደ ተመልሶ አባል ጨምሮ, ፍጆታ ይሆናል መሆኑን ልብ ይበሉ.
    /// በተጨማሪም ይህ መንገድ ተመሳሳይ ለተደጋጋሚ ላይ `nth_back(0)` በርካታ ጊዜያት መጥራት የተለያዩ ንጥረ ነገሮች እንደሚመለሱ.
    ///
    /// `nth_back()` `n` የሚበልጥ ወይም ለተደጋጋሚ ርዝመት ጋር እኩል ከሆነ [`None`] ይመለሳሉ.
    ///
    /// # Examples
    ///
    /// መሠረታዊ አጠቃቀም
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(2), Some(&1));
    /// ```
    ///
    /// `nth_back()` በርካታ ጊዜ በመደወል የ ለተደጋጋሚ እንሚሆን አይደለም:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth_back(1), Some(&2));
    /// assert_eq!(iter.nth_back(1), None);
    /// ```
    ///
    /// `n + 1` ክፍሎች በታች ካሉ `None` በመመለስ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(10), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_nth_back", since = "1.37.0")]
    fn nth_back(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_back_by(n).ok()?;
        self.next_back()
    }

    /// ይህ [`Iterator::try_fold()`] ያለውን በግልባጭ ስሪት ነው; ይህም ለተደጋጋሚ ጀርባ ጀምሮ ክፍሎች ይወስዳል.
    ///
    ///
    /// # Examples
    ///
    /// መሠረታዊ አጠቃቀም
    ///
    /// ```
    /// let a = ["1", "2", "3"];
    /// let sum = a.iter()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert_eq!(sum, Ok(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = ["1", "rust", "3"];
    /// let mut it = a.iter();
    /// let sum = it
    ///     .by_ref()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert!(sum.is_err());
    ///
    /// // በአጭሩ ሰርቪድ ስላለው ቀሪዎቹ ንጥረ ነገሮች በእንደገና ሰጪው በኩል ይገኛሉ ፡፡
    /////
    /// assert_eq!(it.next_back(), Some(&"1"));
    /// ```
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// ወደ ኋላ ጀምሮ, ነጠላ, የመጨረሻ ዋጋ ወደ ለተደጋጋሚ ያለው ንጥረ ይቀንሳል አንድ ለተደጋጋሚ ዘዴ.
    ///
    /// ይህ [`Iterator::fold()`] ያለውን በግልባጭ ስሪት ነው; ይህም ለተደጋጋሚ ጀርባ ጀምሮ ክፍሎች ይወስዳል.
    ///
    /// `rfold()` የመጀመሪያ ዋጋ, እና ሁለት ነጋሪ እሴቶች ጋር መዘጋት: አንድ 'accumulator', እና አንድ አባል ሁለት ነጋሪ እሴቶች ይወስዳል.
    /// ወደ መዘጋት ወደ accumulator በሚቀጥለው ተደጋጋሚነት ለማግኘት ሊኖረው እንደሚገባ እሴት ይመልሳል.
    ///
    /// የመጀመሪያው እሴት accumulator በመጀመሪያው ጥሪ ላይ ይኖረዋል ዋጋ ነው.
    ///
    /// የ ለተደጋጋሚ እያንዳንዱ አባል ይህን መዘጋት ተግባራዊ በኋላ, `rfold()` ወደ accumulator ይመልሳል.
    ///
    /// ይህ ክወና አንዳንድ 'reduce' ወይም 'inject' ይባላል.
    ///
    /// ነገር ስብስብ አለን, እና አንድ ነጠላ ዋጋ ለማምረት በፈለጉበት ጊዜ ታጥፋለህ ጠቃሚ ነው.
    ///
    /// # Examples
    ///
    /// መሠረታዊ አጠቃቀም
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // የሁሉም ንጥረ ነገሮች ድምር
    /// let sum = a.iter()
    ///            .rfold(0, |acc, &x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// ይህ ምሳሌ የመጀመሪያ እሴት ጀምሮ እና ከፊት እስከ ጀርባ ጀምሮ እያንዳንዱን ኤለመንት ጋር በመቀጠል, ሕብረቁምፊ ይገነባል;
    ///
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let zero = "0".to_string();
    ///
    /// let result = numbers.iter().rfold(zero, |acc, &x| {
    ///     format!("({} + {})", x, acc)
    /// });
    ///
    /// assert_eq!(result, "(1 + (2 + (3 + (4 + (5 + 0)))))");
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfold", since = "1.27.0")]
    fn rfold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x);
        }
        accum
    }

    /// የሚያጠግብ ይህን ጀርባ ተሳቢ አንድ ለተደጋጋሚ አንድ ኤለመንት ፍለጋዎች.
    ///
    /// `rfind()` `true` ወይም `false` ይመልሳል አንድ መዘጋት ይወስዳል.
    /// ይህ መጨረሻ ላይ ጀምሮ, የ ለተደጋጋሚ እያንዳንዱ አባል ይህን መዘጋት የሚመለከተው, እና እነሱን በማንኛውም `true` ለመመለስ ከሆነ, ከዚያም `rfind()` [`Some(element)`] ይመልሳል.
    /// ሁሉም `false` ን ከመለሱ [`None`] ን ይመልሳል።
    ///
    /// `rfind()` አጭር-circuiting ነው;በሌላ አባባል, ይህ ወዲያውኑ ወደ መዘጋት `true` ይመልሳል እንደ በማስኬድ ያቆማሉ.
    ///
    /// ምክንያቱም `rfind()` ማጣቀሻ ስለሚወስድ እና ብዙ ተጓeraች በማጣቀሻዎች ላይ ስለሚጨምሩ ፣ ይህ ምናልባት ክርክሩ ሁለት ማመሳከሪያ ወደሆነ ግራ የሚያጋባ ሁኔታ ያስከትላል ፡፡
    ///
    /// ይህንን ውጤት ከዚህ በታች ባሉት ምሳሌዎች ከ `&&x` ጋር ማየት ይችላሉ ፡፡
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// መሠረታዊ አጠቃቀም
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 5), None);
    /// ```
    ///
    /// የመጀመሪያው `true` ላይ በማቆም:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rfind(|&&x| x == 2), Some(&2));
    ///
    /// // ተጨማሪ ክፍሎች አሉ እንደ እኛ አሁንም, `iter` መጠቀም ይችላሉ.
    /// assert_eq!(iter.next_back(), Some(&1));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfind", since = "1.27.0")]
    fn rfind<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_rfold((), check(predicate)).break_value()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, I: DoubleEndedIterator + ?Sized> DoubleEndedIterator for &'a mut I {
    fn next_back(&mut self) -> Option<I::Item> {
        (**self).next_back()
    }
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_back_by(n)
    }
    fn nth_back(&mut self, n: usize) -> Option<I::Item> {
        (**self).nth_back(n)
    }
}