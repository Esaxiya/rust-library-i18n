/// አንድ [`Iterator`] ከ ልወጣ.
///
/// አንድ አይነት `FromIterator` ተግባራዊ በማድረግ, እርስዎ አንድ ለተደጋጋሚ የተፈጠረ ይደረጋል እንዴት መግለጽ.
/// ይሄ የተወሰነ ዓይነት ስብስብ የሚገልጹ ይህም አይነቶች የተለመደ ነው.
///
/// [`FromIterator::from_iter()`] ነው እምብዛም በግልጽ ይባላል, እና በምትኩ [`Iterator::collect()`] ዘዴ አማካይነት ይውላል.
///
/// ለተጨማሪ ምሳሌዎች የ [`Iterator::collect()`]'s ሰነድን ይመልከቱ ፡፡
///
/// ተመልከት: [`IntoIterator`].
///
/// # Examples
///
/// መሠረታዊ አጠቃቀም
///
/// ```
/// use std::iter::FromIterator;
///
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v = Vec::from_iter(five_fives);
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// `FromIterator` ን በተዘዋዋሪ ለመጠቀም [`Iterator::collect()`] ን በመጠቀም-
///
/// ```
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v: Vec<i32> = five_fives.collect();
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// የእርስዎ አይነት `FromIterator` ተግባራዊ:
///
/// ```
/// use std::iter::FromIterator;
///
/// // የናሙና ክምችት ፣ ያ በቪኬ ላይ መጠቅለያ ብቻ ነው<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // አንድን መፍጠር እና ነገሮችን በእሱ ላይ ማከል እንድንችል አንዳንድ ዘዴዎችን እንስጠው ፡፡
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // እኛም FromIterator በስራ ያገኛሉ
/// impl FromIterator<i32> for MyCollection {
///     fn from_iter<I: IntoIterator<Item=i32>>(iter: I) -> Self {
///         let mut c = MyCollection::new();
///
///         for i in iter {
///             c.add(i);
///         }
///
///         c
///     }
/// }
///
/// // አሁን አዲስ ለተደጋጋሚ ማድረግ ይችላሉ ...
/// let iter = (0..5).into_iter();
///
/// // ... እና አንድ MyCollection ውጭ ማድረግ
/// let c = MyCollection::from_iter(iter);
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
///
/// // በጣም Collect ሥራ!
///
/// let iter = (0..5).into_iter();
/// let c: MyCollection = iter.collect();
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "a value of type `{Self}` cannot be built from an iterator \
               over elements of type `{A}`",
    label = "value of type `{Self}` cannot be built from `std::iter::Iterator<Item={A}>`"
)]
pub trait FromIterator<A>: Sized {
    /// አንድ ለተደጋጋሚ አንድ እሴት ይፈጥራል.
    ///
    /// ለተጨማሪ [module-level documentation] ን ይመልከቱ።
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// መሠረታዊ አጠቃቀም
    ///
    /// ```
    /// use std::iter::FromIterator;
    ///
    /// let five_fives = std::iter::repeat(5).take(5);
    ///
    /// let v = Vec::from_iter(five_fives);
    ///
    /// assert_eq!(v, vec![5, 5, 5, 5, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_iter<T: IntoIterator<Item = A>>(iter: T) -> Self;
}

/// አንድ [`Iterator`] ወደ ልወጣ.
///
/// አንድ አይነት `IntoIterator` ተግባራዊ በማድረግ, እርስዎ አንድ ለተደጋጋሚ ሊቀየር እንዴት መግለጽ.
/// ይሄ የተወሰነ ዓይነት ስብስብ የሚገልጹ ይህም አይነቶች የተለመደ ነው.
///
/// `IntoIterator` ተግባራዊ አንዱ ጥቅም የእርስዎ አይነት [work with Rust's `for` loop syntax](crate::iter#for-loops-and-intoiterator) ፈቃድ ይህ ነው.
///
///
/// ተመልከት: [`FromIterator`].
///
/// # Examples
///
/// መሠረታዊ አጠቃቀም
///
/// ```
/// let v = vec![1, 2, 3];
/// let mut iter = v.into_iter();
///
/// assert_eq!(Some(1), iter.next());
/// assert_eq!(Some(2), iter.next());
/// assert_eq!(Some(3), iter.next());
/// assert_eq!(None, iter.next());
/// ```
/// የእርስዎ አይነት `IntoIterator` ተግባራዊ:
///
/// ```
/// // የናሙና ክምችት ፣ ያ በቪኬ ላይ መጠቅለያ ብቻ ነው<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // አንድን መፍጠር እና ነገሮችን በእሱ ላይ ማከል እንድንችል አንዳንድ ዘዴዎችን እንስጠው ፡፡
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // እኛም IntoIterator በስራ ያገኛሉ
/// impl IntoIterator for MyCollection {
///     type Item = i32;
///     type IntoIter = std::vec::IntoIter<Self::Item>;
///
///     fn into_iter(self) -> Self::IntoIter {
///         self.0.into_iter()
///     }
/// }
///
/// // አሁን አዲስ ስብስብ ማድረግ ይችላሉ ...
/// let mut c = MyCollection::new();
///
/// // ... ይህም ወደ አንዳንድ ነገሮችን ማከል ...
/// c.add(0);
/// c.add(1);
/// c.add(2);
///
/// // ... ከዚያም አንድ ለተደጋጋሚ ወደ ለማብራት:
/// for (i, n) in c.into_iter().enumerate() {
///     assert_eq!(i as i32, n);
/// }
/// ```
///
/// `IntoIterator` ን እንደ trait bound መጠቀሙ የተለመደ ነው ፡፡ይህም በጣም ረጅም አሁንም አንድ ለተደጋጋሚ ነው እንደ ለውጥ የግቤት ስብስብ አይነት ይፈቅዳል.
/// ተጨማሪ ገደቦችን በ ላይ በመገደብ ሊገለጹ ይችላሉ
/// `Item`:
///
/// ```rust
/// fn collect_as_strings<T>(collection: T) -> Vec<String>
/// where
///     T: IntoIterator,
///     T::Item: std::fmt::Debug,
/// {
///     collection
///         .into_iter()
///         .map(|item| format!("{:?}", item))
///         .collect()
/// }
/// ```
///
///
#[rustc_diagnostic_item = "IntoIterator"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait IntoIterator {
    /// ንጥረ ነገሮች አይነት ላይ iterated እየተደረገ.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// ዓይነት ለተደጋጋሚ የትኛውን እኛ ወደ ይህን ዘወር ነው?
    #[stable(feature = "rust1", since = "1.0.0")]
    type IntoIter: Iterator<Item = Self::Item>;

    /// አንድ እሴት ከ አንድ ለተደጋጋሚ ይፈጥራል.
    ///
    /// ለተጨማሪ [module-level documentation] ን ይመልከቱ።
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// መሠረታዊ አጠቃቀም
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    /// let mut iter = v.into_iter();
    ///
    /// assert_eq!(Some(1), iter.next());
    /// assert_eq!(Some(2), iter.next());
    /// assert_eq!(Some(3), iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    #[lang = "into_iter"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into_iter(self) -> Self::IntoIter;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator> IntoIterator for I {
    type Item = I::Item;
    type IntoIter = I;

    fn into_iter(self) -> I {
        self
    }
}

/// አንድ ለተደጋጋሚ ይዘቶች ጋር አንድ ስብስብ ያራዝሙ.
///
/// አንቀሳቃሾች ተከታታይ እሴቶችን ያመርታሉ ፣ ስብስቦችም እንደ ተከታታይ እሴቶች ሊታሰቡ ይችላሉ ፡፡
/// የ `Extend` trait ያንን ለተደጋጋሚ ይዘቶችን ጨምሮ በ ስብስብ ለማራዘም በመፍቀድ, ይህንን ክፍተት ድልድይ.
/// ቀድሞውኑ ካለው ቁልፍ ጋር ክምችት ሲዘረጋ ያ ግቤት ዘምኗል ወይም በእኩል ቁልፎች በርካታ ግቤቶችን በሚፈቅዱ ስብስቦች ውስጥ ያ ግቤት ገብቷል።
///
///
/// # Examples
///
/// መሠረታዊ አጠቃቀም
///
/// ```
/// // አንዳንድ ቁምፊዎች ጋር አንድ ሕብረቁምፊ ለማራዘም ይችላሉ:
/// let mut message = String::from("The first three letters are: ");
///
/// message.extend(&['a', 'b', 'c']);
///
/// assert_eq!("abc", &message[29..32]);
/// ```
///
/// በስራ ላይ ማዋል `Extend`:
///
/// ```
/// // የናሙና ክምችት ፣ ያ በቪኬ ላይ መጠቅለያ ብቻ ነው<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // አንድን መፍጠር እና ነገሮችን በእሱ ላይ ማከል እንድንችል አንዳንድ ዘዴዎችን እንስጠው ፡፡
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // MyCollection i32s ዝርዝር ያለው በመሆኑ, እኛ i32 ለማስቀጠል መተግበር
/// impl Extend<i32> for MyCollection {
///
///     // ይህ ተጨባጭ አይነት ፊርማ ጋር ትንሽ ቀላል ነው; እኛ እኛን i32s የሚሰጥ አንድ ለተደጋጋሚ ይለወጣል የሚችል ነገር ላይ መዘርጋት መደወል ይችላሉ.
///     // እኛ MyCollection ወደ ማስቀመጥ i32s ያስፈልገናል; ምክንያቱም.
/////
///     fn extend<T: IntoIterator<Item=i32>>(&mut self, iter: T) {
///
///         // የ ለተደጋጋሚ በኩል ሉፕ እና add() ራሳችንን እያንዳንዱ አባል: አፈፃፀም በጣም ቀጥተኛ ነው.
/////
///         for elem in iter {
///             self.add(elem);
///         }
///     }
/// }
///
/// let mut c = MyCollection::new();
///
/// c.add(5);
/// c.add(6);
/// c.add(7);
///
/// // ሦስት ተጨማሪ ቁጥሮች ጋር ያለንን ስብስብ ማራዘም እናድርግ
/// c.extend(vec![1, 2, 3]);
///
/// // እኛም መጨረሻ ላይ እነዚህ ክፍሎች አክለዋል
/// assert_eq!("MyCollection([5, 6, 7, 1, 2, 3])", format!("{:?}", c));
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Extend<A> {
    /// አንድ ለተደጋጋሚ ይዘቶች ጋር አንድ ስብስብ የተዘረጋ ነው.
    ///
    /// ለዚህ trait ብቸኛው ተፈላጊ ዘዴ ይህ በመሆኑ የ [trait-level] ሰነዶች ተጨማሪ ዝርዝሮችን ይዘዋል ፡፡
    ///
    ///
    /// [trait-level]: Extend
    ///
    /// # Examples
    ///
    /// መሠረታዊ አጠቃቀም
    ///
    /// ```
    /// // አንዳንድ ቁምፊዎች ጋር አንድ ሕብረቁምፊ ለማራዘም ይችላሉ:
    /// let mut message = String::from("abc");
    ///
    /// message.extend(['d', 'e', 'f'].iter());
    ///
    /// assert_eq!("abcdef", &message);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn extend<T: IntoIterator<Item = A>>(&mut self, iter: T);

    /// በትክክል ከአንድ አካል ጋር ስብስብን ያራዝማል።
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_one(&mut self, item: A) {
        self.extend(Some(item));
    }

    /// ተጨማሪ ክፍሎች በተሰጠው ቁጥር ስብስብ ውስጥ ክምችት አቅም.
    ///
    /// ነባሪ ትግበራ ምንም ነገር አያደርግም.
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_reserve(&mut self, additional: usize) {
        let _ = additional;
    }
}

#[stable(feature = "extend_for_unit", since = "1.28.0")]
impl Extend<()> for () {
    fn extend<T: IntoIterator<Item = ()>>(&mut self, iter: T) {
        iter.into_iter().for_each(drop)
    }
    fn extend_one(&mut self, _item: ()) {}
}