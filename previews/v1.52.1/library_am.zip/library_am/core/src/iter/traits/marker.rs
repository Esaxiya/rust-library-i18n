/// ሲደክም ሁልጊዜ `None` ን መስጠቱን የሚቀጥል ተደጋጋሚ።
///
/// አንድ አንድ ጊዜ `None` ተመልሶ አድርጓል እንደገና [`None`] ለመመለስ ዋስትና ነው ለተደጋጋሚ የተዋሃዱ ላይ ቀጥሎ በመደወል.
/// ይህ trait ይህ [`Iterator::fuse()`] ሲያመቻቹ የሚፈቅድ ምክንያቱም በዚህ መንገድ የራሱንም ሁሉ iterators የሚያውለው ይገባል.
///
///
/// Note: በአጠቃላይ ፣ የተዋሃደ ተደጋጋሚነት ከፈለጉ `FusedIterator` ን በጥቅሉ ወሰን ውስጥ መጠቀም የለብዎትም።
/// በምትኩ ፣ በቃለ-መጠይቁ ላይ ብቻ [`Iterator::fuse()`] ን መጥራት አለብዎት።
/// ተደጋጋሚው ቀድሞውኑ የተዋሃደ ከሆነ ፣ ተጨማሪው የ [`Fuse`] መጠቅለያ ምንም የአፈፃፀም ቅጣት የሌለበት ቅስቀሳ ይሆናል።
///
/// [`Fuse`]: crate::iter::Fuse
///
#[stable(feature = "fused", since = "1.26.0")]
#[rustc_unsafe_specialization_marker]
pub trait FusedIterator: Iterator {}

#[stable(feature = "fused", since = "1.26.0")]
impl<I: FusedIterator + ?Sized> FusedIterator for &mut I {}

/// Size_hint ን በመጠቀም ትክክለኛውን ርዝመት ሪፖርት የሚያደርግ ተደጋጋሚ።
///
/// ተደጋጋሚው ትክክለኛ (ዝቅተኛ ወሰን ከከፍተኛው ወሰን ጋር እኩል ነው) ፣ ወይም የላይኛው ወሰን [`None`] ነው የሚል መጠነኛ ፍንጭ ሪፖርት ያደርጋል።
///
/// ትክክለኛ ለተደጋጋሚ ርዝመት [`usize::MAX`] የሚበልጥ ከሆነ በላይኛው ገደብ የግድ ብቻ [`None`] ይሁን.
/// በዚህ ሁኔታ ውስጥ, በታችኛው ታስሮ `(usize::MAX, None)` አንድ [`Iterator::size_hint()`] ምክንያት, [`usize::MAX`] መሆን አለበት.
///
/// የ ለተደጋጋሚ መጨረሻው ከመድረሱ በፊት በትክክል ሪፖርት ንጥረ ወይም ይሰየማል ቁጥር ማፍራት አለበት.
///
/// # Safety
///
/// ይህ trait ኮንትራቱ ሲፀና ብቻ መተግበር አለበት ፡፡
/// ይህ trait ውስጥ ሸማቾች የላይኛው ታሰረ [`Iterator::size_hint()`]’s መመርመር አለበት.
///
///
///
#[unstable(feature = "trusted_len", issue = "37572")]
#[rustc_unsafe_specialization_marker]
pub unsafe trait TrustedLen: Iterator {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<I: TrustedLen + ?Sized> TrustedLen for &mut I {}

/// አንድ ንጥል በሚሰጥበት ጊዜ አንድ መሠረታዊ ንጥረ ነገር ከዋናው [`SourceIter`] ወስዷል።
///
/// ለምሳሌ ለተደጋጋሚ የሚያራምድ ማንኛውንም ዘዴ, በመደወል ላይ
/// [`next()`] ወይም [`try_fold()`], በእያንዳንዱ ደረጃ ለ ለተደጋጋሚ ያለውን መሰረታዊ ምንጭ መካከል ቢያንስ አንድ እሴት ወደ ውጭ ተወስዷል እና ለተደጋጋሚ ሰንሰለት ውጤት ምንጭ መካከል መዋቅራዊ ዕጥረት ከወሰድን, የራሱ ቦታ ውስጥ ሊገባ እንደሚችል ዋስትና እንደዚህ ያለ ማስገባት ያስችላቸዋል.
///
/// በሌላ አነጋገር ይህ trait የሚያመላክት የቧንቧ መስመር በቦታው መሰብሰብ መቻሉን ያሳያል።
///
/// [`SourceIter`]: crate::iter::SourceIter
/// [`next()`]: Iterator::next
/// [`try_fold()`]: Iterator::try_fold
///
///
#[unstable(issue = "none", feature = "inplace_iteration")]
pub unsafe trait InPlaceIterable: Iterator {}