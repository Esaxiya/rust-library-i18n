use crate::iter::{FusedIterator, TrustedLen};

/// በትክክል አንድ ጊዜ አንድ ንጥረ ነገር የሚያመነጭ ተደጋጋሚ ይፈጥራል።
///
/// ይህ አንድ ነጠላ እሴትን ወደ ሌሎች ዓይነቶች ድግግሞሽ ወደ [`chain()`] ለማስገባት በተለምዶ ጥቅም ላይ ይውላል።
/// ምናልባት ሁሉንም ማለት ይቻላል የሚሸፍን ተደጋጋሚ ተደጋግሞ ሊኖርዎት ይችላል ፣ ግን ተጨማሪ ልዩ ጉዳይ ያስፈልግዎታል።
/// ምናልባት iterators ላይ ይሰራል ይህም ተግባር አለኝ, ነገር ግን አንዱ ብቻ ዋጋ ማስኬድ ይኖርብናል.
///
/// [`chain()`]: Iterator::chain
///
/// # Examples
///
/// መሠረታዊ አጠቃቀም
///
/// ```
/// use std::iter;
///
/// // አንዱ ብቸኛ ብቸኛ ቁጥር ነው
/// let mut one = iter::once(1);
///
/// assert_eq!(Some(1), one.next());
///
/// // አንድ ብቻ, እኛ ለማግኘት ሁሉ ነው
/// assert_eq!(None, one.next());
/// ```
///
/// ሌላ ለተደጋጋሚ ጋር አብረው Chaining.
/// , ዎቹ እኛ `.foo` ማውጫ እያንዳንዱ ፋይል, ግን ደግሞ አንድ ውቅረት ፋይል ላይ ለመድገም እንደሚፈልጉ ይናገራሉ እንመልከት
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // እኛ ከድሪንትሪ-ሰጭ ተንታኝ ወደ ዱካ ቡፍስ ተደጋጋሚ መለወጥ ያስፈልገናል ፣ ስለሆነም ካርታ እንጠቀማለን
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // አሁን የእኛ ለተደጋጋሚ ብቻ ያለንን ማዋቀር ፋይል
/// let config = iter::once(PathBuf::from(".foorc"));
///
/// // አንድ ትልቅ ለተደጋጋሚ ወደ አብረው ሁለቱ iterators ያስሩኛል
/// let files = dirs.chain(config);
///
/// // ይህ በ .foo እና በ .foorc ውስጥ ያሉትን ሁሉንም ፋይሎች ይሰጠናል
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
#[stable(feature = "iter_once", since = "1.2.0")]
pub fn once<T>(value: T) -> Once<T> {
    Once { inner: Some(value).into_iter() }
}

/// በትክክል አንድ ጊዜ አንድ አባል ያፈራላቸዋል አንድ ለተደጋጋሚ.
///
/// ይህ `struct` በ [`once()`] ተግባር የተፈጠረ ነው.ለተጨማሪ ሰነዶቹን ይመልከቱ ፡፡
#[derive(Clone, Debug)]
#[stable(feature = "iter_once", since = "1.2.0")]
pub struct Once<T> {
    inner: crate::option::IntoIter<T>,
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> Iterator for Once<T> {
    type Item = T;

    fn next(&mut self) -> Option<T> {
        self.inner.next()
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> DoubleEndedIterator for Once<T> {
    fn next_back(&mut self) -> Option<T> {
        self.inner.next_back()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> ExactSizeIterator for Once<T> {
    fn len(&self) -> usize {
        self.inner.len()
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T> TrustedLen for Once<T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Once<T> {}