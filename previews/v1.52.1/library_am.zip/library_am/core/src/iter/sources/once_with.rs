use crate::iter::{FusedIterator, TrustedLen};

/// የቀረበው መዘጋትን በመጥራት በስንፍና በትክክል አንድ ጊዜ ዋጋን የሚያመነጭ ተደጋጋሚ ይፈጥራል።
///
/// ይህ በተለምዶ ተደጋጋሚነት ሌላ ዓይነት የሆነ [`chain()`] ወደ አንድ ነጠላ እሴት ጄኔሬተር መላመድ ላይ ይውላል.
/// ምናልባት ሁሉንም ማለት ይቻላል የሚሸፍን ተደጋጋሚ ተደጋግሞ ሊኖርዎት ይችላል ፣ ግን ተጨማሪ ልዩ ጉዳይ ያስፈልግዎታል።
/// ምናልባት iterators ላይ ይሰራል ይህም ተግባር አለኝ, ነገር ግን አንዱ ብቻ ዋጋ ማስኬድ ይኖርብናል.
///
/// [`once()`] በተለየ መልኩ, ይህ ተግባር ታካቾች ጥያቄ ላይ እሴት ያመነጫል.
///
/// [`chain()`]: Iterator::chain
/// [`once()`]: crate::iter::once
///
/// # Examples
///
/// መሠረታዊ አጠቃቀም
///
/// ```
/// use std::iter;
///
/// // አንዱ ብቸኛ ብቸኛ ቁጥር ነው
/// let mut one = iter::once_with(|| 1);
///
/// assert_eq!(Some(1), one.next());
///
/// // አንድ ብቻ, እኛ ለማግኘት ሁሉ ነው
/// assert_eq!(None, one.next());
/// ```
///
/// ሌላ ለተደጋጋሚ ጋር አብረው Chaining.
/// , ዎቹ እኛ `.foo` ማውጫ እያንዳንዱ ፋይል, ግን ደግሞ አንድ ውቅረት ፋይል ላይ ለመድገም እንደሚፈልጉ ይናገራሉ እንመልከት
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // እኛ ከድሪንትሪ-ሰጭ ተንታኝ ወደ ዱካ ቡፍስ ተደጋጋሚ መለወጥ ያስፈልገናል ፣ ስለሆነም ካርታ እንጠቀማለን
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // አሁን የእኛ ለተደጋጋሚ ብቻ ያለንን ማዋቀር ፋይል
/// let config = iter::once_with(|| PathBuf::from(".foorc"));
///
/// // አንድ ትልቅ ለተደጋጋሚ ወደ አብረው ሁለቱ iterators ያስሩኛል
/// let files = dirs.chain(config);
///
/// // ይህ በ .foo እና በ .foorc ውስጥ ያሉትን ሁሉንም ፋይሎች ይሰጠናል
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
///
#[inline]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub fn once_with<A, F: FnOnce() -> A>(gen: F) -> OnceWith<F> {
    OnceWith { gen: Some(gen) }
}

/// የቀረበው መዘጋት `F: FnOnce() -> A` ተግባራዊ በማድረግ አይነት `A` አንድ ነጠላ ንጥረ ያፈራላቸዋል አንድ ለተደጋጋሚ.
///
///
/// ይህ `struct` በ [`once_with()`] ተግባር የተፈጠረ ነው።
/// ለተጨማሪ ሰነዶቹን ይመልከቱ ፡፡
#[derive(Clone, Debug)]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub struct OnceWith<F> {
    gen: Option<F>,
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> Iterator for OnceWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        let f = self.gen.take()?;
        Some(f())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.gen.iter().size_hint()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> DoubleEndedIterator for OnceWith<F> {
    fn next_back(&mut self) -> Option<A> {
        self.next()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> ExactSizeIterator for OnceWith<F> {
    fn len(&self) -> usize {
        self.gen.iter().len()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> FusedIterator for OnceWith<F> {}

#[stable(feature = "iter_once_with", since = "1.43.0")]
unsafe impl<A, F: FnOnce() -> A> TrustedLen for OnceWith<F> {}