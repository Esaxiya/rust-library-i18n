use crate::iter::{FusedIterator, TrustedLen};

/// አንድን ንጥረ-ነገር ያለማቋረጥ የሚደግም አዲስ ተደጋጋሚ ይፈጥራል።
///
/// የ `repeat()` ተግባር አንድ ነጠላ እሴት ደጋግሞ ይደግማል።
///
/// `repeat()` እንደ የትየሌለ iterators ብዙውን ጊዜ እነሱን አላቂ ለማድረግ, [`Iterator::take()`] እንደ አስማሚዎች ጋር ጥቅም ላይ ይውላሉ.
///
/// እናንተ `Clone` ለመተግበር አይደለም ይኖርብናል, ወይም ትውስታ ውስጥ በተደጋጋሚ አባል መጠበቅ የማይፈልጉ ከሆነ, በምትኩ [`repeat_with()`] ተግባር መጠቀም ይችላል ለተደጋጋሚ ያለውን አባል አይነት ከሆነ.
///
///
/// [`repeat_with()`]: crate::iter::repeat_with
///
/// # Examples
///
/// መሠረታዊ አጠቃቀም
///
/// ```
/// use std::iter;
///
/// // ቁጥር አራት 4ever:
/// let mut fours = iter::repeat(4);
///
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
///
/// // yup ፣ አሁንም አራት
/// assert_eq!(Some(4), fours.next());
/// ```
///
/// በ [`Iterator::take()`] መጨረሻ ላይ
///
/// ```
/// use std::iter;
///
/// // ይህ የመጨረሻው ምሳሌ በጣም ብዙ የሚሄድን ነበር.ዎቹ ብቻ አራት የሚሄድን አላቸው እንመልከት.
/// let mut four_fours = iter::repeat(4).take(4);
///
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
///
/// // ... እና አሁን ከጨረሱ
/// assert_eq!(None, four_fours.next());
/// ```
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn repeat<T: Clone>(elt: T) -> Repeat<T> {
    Repeat { element: elt }
}

/// አንድን ንጥረ ነገር ማለቂያ የሌለው የሚደግም ተደጋጋሚ።
///
/// ይህ `struct` በ [`repeat()`] ተግባር የተፈጠረ ነው.ተጨማሪ ያለውን ሰነድ ይመልከቱ.
#[derive(Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Repeat<A> {
    element: A,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> Iterator for Repeat<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> DoubleEndedIterator for Repeat<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Clone> FusedIterator for Repeat<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Clone> TrustedLen for Repeat<A> {}