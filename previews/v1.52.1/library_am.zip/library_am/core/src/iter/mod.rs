//! Composable ውጫዊ ተደጋጋሚነት.
//!
//! አንዳንድ ዓይነት ስብስብ ጋር ራስህን አግኝቶ እንዲህ አለ ስብስብ ውስጥ ያሉትን ክፍሎች ላይ አንድ ክወና ለማከናወን የሚያስፈልገው ከሆነ, በፍጥነት 'iterators' ወደ ማስኬድ ያገኛሉ.
//! Iterators በከፍተኛ ይህን ያለው ዋጋ ከእነርሱ ጋር በደንብ በመሆን ስለዚህ የአነጋገር Rust ኮድ ውስጥ ጥቅም ላይ ይውላሉ.
//!
//! የበለጠ ከማብራራትዎ በፊት ፣ ይህ ሞጁል እንዴት እንደተዋቀረ እንነጋገር ፡፡
//!
//! # Organization
//!
//! ይህ ሞዱል በአብዛኛው አይነት የተደራጁ ነው:
//!
//! * [Traits] ዋናው ክፍል እነዚህ ናቸው traits ምን ዓይነት ተጓeraች እንዳሉ እና ከእነሱ ጋር ምን ማድረግ እንደሚችሉ ይወስናሉ ፡፡የእነዚህ traits ዘዴዎች የተወሰኑ ተጨማሪ የጥናት ጊዜዎችን ለማስቀመጥ ዋጋ አላቸው ፡፡
//! * [Functions] አንዳንድ መሠረታዊ ተጓeraችን ለመፍጠር አንዳንድ ጠቃሚ መንገዶችን ያቅርቡ።
//! * [Structs] ይህ ሞዱል ያለው traits ላይ የተለያዩ ዘዴዎች መመለስ ዓይነቶች ብዙውን ናቸው.ከ `struct` ራሱ ይልቅ ብዙውን ጊዜ `struct` ን የሚፈጥር ዘዴን ማየት ይፈልጋሉ።
//! '[በስራ ላይ ማዋል ለተደጋጋሚ](#ተግባራዊ-ለተደጋጋሚ)' ለማየት ለምን በተመለከተ ተጨማሪ ዝርዝር ለማግኘት.
//!
//! [Traits]: #traits
//! [Functions]: #functions
//! [Structs]: #structs
//!
//! ይሀው ነው!እስረኞች ውስጥ ቆፍረን እንግባ ፡፡
//!
//! # Iterator
//!
//! የዚህ ሞጁል ልብ እና ነፍስ [`Iterator`] trait ነው።[`Iterator`] ያለው ዋና ይህን ይመስላል:
//!
//! ```
//! trait Iterator {
//!     type Item;
//!     fn next(&mut self) -> Option<Self::Item>;
//! }
//! ```
//!
//! አንድ ለተደጋጋሚ `አንድ [` Option`], ይባላል ጊዜ አንድ ዘዴ, [`next`], አለው ይመልሳል<Item>`.
//! [`next`] ክፍሎች አሉ እስከሆነ [`Some(Item)`] ይመለሳሉ, እና ሁሉም ተሞክረው ከገዙ በኋላ ተደጋጋሚነት ሲጨርስ መሆኑን ለማመላከት `None` ይመለሳሉ.
//! የግለሰብ ተጓeraች ድጋሜውን ለመቀጠል ሊመርጡ ይችላሉ ፣ ስለሆነም [`next`] ን እንደገና መጥራት በተወሰነ ጊዜ እንደገና [`Some(Item)`] ን እንደገና መመለስ ሊጀምር ወይም ላይጀምር ይችላል (ለምሳሌ [`TryIter`] ን ይመልከቱ)።
//!
//!
//! የ `ኢተራክተር` ሙሉ ፍቺ ሌሎች በርካታ ዘዴዎችን ያካተተ ነው ፣ ግን እነሱ ነባሪ ዘዴዎች ናቸው ፣ በ [`next`] ላይ የተገነቡ ናቸው ፣ ስለሆነም በነፃ ያገ youቸዋል።
//!
//! አንቀሳቃሾችም እንዲሁ ተቀናቃኝ ናቸው ፣ እና የበለጠ የተወሳሰቡ የማቀነባበሪያ ዓይነቶችን ለመስራት አንድ ላይ ማሰር የተለመደ ነው።ተጨማሪ ዝርዝሮችን ለማግኘት ከታች ያለውን [Adapters](#adapters) ክፍል ይመልከቱ.
//!
//! [`Some(Item)`]: Some
//! [`next`]: Iterator::next
//! [`TryIter`]: ../../std/sync/mpsc/struct.TryIter.html
//!
//! # ተደጋጋሚነት ያለው ሦስት ቅጾች
//!
//! ስብስብ ከ iterators መፍጠር ይችላሉ ይህም ሦስት የተለመዱ ዘዴዎች አሉ:
//!
//! * `iter()`, ይህም `&T` በላይ iterates.
//! * `iter_mut()`, ከ `&mut T` በላይ የሚደግም።
//! * `into_iter()`, ይህም `T` በላይ iterates.
//!
//! መደበኛ ቤተ መጻሕፍት ውስጥ የተለያዩ ነገሮች አንድ ወይም ተገቢ የት ሦስት, ተጨማሪ መተግበር ይችላሉ.
//!
//! # ኢተሬተርን መተግበር
//!
//! በ ለተደጋጋሚ ያለውን ሁኔታ ለመያዝ አንድ `struct` በመፍጠር, እና ከዚያ `struct` ለ [`Iterator`] ተግባራዊ: የራስዎ የሆነ ለተደጋጋሚ መፍጠር ሁለት ደረጃዎች ያካትታል.
//! ለዚህም ነው በዚህ ሞጁል ውስጥ ብዙ‹መዋቅሮች›ያሉበት ለእያንዳንዱ ተደጋጋሚ እና ተደጋጋሚ አስማሚ አንድ አለ ፡፡
//!
//! ከ `1` እስከ `5` የሚቆጠር `Counter` የተባለ ተደጋጋሚ እናድርግ-
//!
//! ```
//! // በመጀመሪያ, የ struct:
//!
//! /// ከአንድ እስከ አምስት ወደ አንድ ለተደጋጋሚ ይህም ቆጠራዎች
//! struct Counter {
//!     count: usize,
//! }
//!
//! // ቆጠራችን በአንዱ እንዲጀመር እንፈልጋለን ፣ ስለሆነም ለማገዝ የ new() ዘዴን እንጨምር ፡፡
//! // ይህ በጥብቅ አስፈላጊ አይደለም, ነገር ግን አመቺ ነው.
//! // `count` ን በዜሮ እንደጀመርን ልብ ይበሉ ፣ ለምን በ `next()`'s ትግበራ ከዚህ በታች እናያለን ፡፡
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // ከዚያ `Iterator` ን ለ `Counter` ተግባራዊ እናደርጋለን
//!
//! impl Iterator for Counter {
//!     // እኛ በአጠቃቀም እንቆጠራለን
//!     type Item = usize;
//!
//!     // next() ብቸኛው የሚፈለግ ዘዴ ነው
//!     fn next(&mut self) -> Option<Self::Item> {
//!         // ቁጥራችን ይጨምሩ።ለዚህም ነው በዜሮ የጀመርነው ፡፡
//!         self.count += 1;
//!
//!         // እኛ የተጠናቀቁ ቆጠራ አድርገናል ወይም አይደለም ከሆነ ያረጋግጡ.
//!         if self.count < 6 {
//!             Some(self.count)
//!         } else {
//!             None
//!         }
//!     }
//! }
//!
//! // እና አሁን ሊጠቀሙበት ይችላሉ!
//!
//! let mut counter = Counter::new();
//!
//! assert_eq!(counter.next(), Some(1));
//! assert_eq!(counter.next(), Some(2));
//! assert_eq!(counter.next(), Some(3));
//! assert_eq!(counter.next(), Some(4));
//! assert_eq!(counter.next(), Some(5));
//! assert_eq!(counter.next(), None);
//! ```
//!
//! [`next`] ን በዚህ መንገድ መደወል ተደጋጋሚ ይሆናል።Rust ይህ `None` እስኪደርስ ድረስ, በእርስዎ ለተደጋጋሚ ላይ [`next`] መደወል ይችላሉ ይህም CONSTRUCT አለው.በሚቀጥለው ላይ እንሂድ ፡፡
//!
//! በተጨማሪም `Iterator` በውስጥ `next` ይደውሉ ይህም እንደ `nth` እና `fold` እንደ ዘዴዎችን ነባሪ አፈጻጸም ይሰጣል መሆኑን ልብ ይበሉ.
//! ሆኖም አንድ ተደጋጋሚ ጠቋሚ `next` ን ሳይጠራ የበለጠ በብቃት ሊቆጥራቸው ከቻለ እንደ `nth` እና `fold` ያሉ ዘዴዎችን በብጁ ትግበራ መፃፍም ይቻላል ፡፡
//!
//! # `for` loops እና `IntoIterator`
//!
//! Rust ዎቹ `for` ሉፕ አገባብ በእርግጥ iterators የሚሆን ስኳር ነው.የ `for` መሠረታዊ ምሳሌ ይኸውልዎት-
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! ይህ በራሳቸው መስመር ላይ, አምስት በኩል ለእያንዳንዱ ቁጥር አንድ ማተም ይሆናል.ነገር ግን እዚህ ላይ አንድ ነገር ልብ ያገኛሉ: እኛ አንድ ለተደጋጋሚ ለማምረት የእኛን vector ላይ ምንም ተብሎ አያውቅም.ምን ይሰጣል?
//!
//! አንድን ነገር ወደ ተደጋጋሚነት ለመለወጥ በመደበኛ ቤተ-መጽሐፍት ውስጥ trait አለ [`IntoIterator`].
//! ይህ trait አንድ ለተደጋጋሚ ወደ [`IntoIterator`] ተግባራዊ ነገር ይቀይራል ይህም አንድ ዘዴ, [`into_iter`], አለው.
//! እስቲ ያንን የ `for` ሉፕን እንደገና እንመልከተው ፣ እና አጠናቃዩ ወደ ምን እንደሚለውጠው-
//!
//! [`into_iter`]: IntoIterator::into_iter
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Rust de-sugars ይህንን ወደ
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//! {
//!     let result = match IntoIterator::into_iter(values) {
//!         mut iter => loop {
//!             let next;
//!             match iter.next() {
//!                 Some(val) => next = val,
//!                 None => break,
//!             };
//!             let x = next;
//!             let () = { println!("{}", x); };
//!         },
//!     };
//!     result
//! }
//! ```
//!
//! በመጀመሪያ, ዋጋ ላይ `into_iter()` ይደውሉ.ከዚያም እኛ በሚመለስበት, በላይ እና በላይ ድረስ [`next`] በመደወል እኛ `None` የሚያዩት ለተደጋጋሚ ላይ አይዛመድም.
//! በዚያን ጊዜ እኛ `break` ን ከጉዞው አውጥተን ወራጅ ማድረጉን ጨርሰናል ፡፡
//!
//! አንድ ተጨማሪ ረቂቅ እዚህ አለ መደበኛ ቤተ-መጽሐፍት የ [`IntoIterator`] አስደሳች አተገባበርን ይ containsል-
//!
//! ```ignore (only-for-syntax-highlight)
//! impl<I: Iterator> IntoIterator for I
//! ```
//!
//! በሌላ አነጋገር ሁሉም [`አስተባባሪ`] እራሳቸውን በመመለስ [`IntoIterator`] ን ይተገብራሉ።ይህ ሁለት ነገሮችን ማለት ነው:
//!
//! 1. [`Iterator`] ን እየፃፉ ከሆነ በ `for` loop ሊጠቀሙበት ይችላሉ።
//! 2. እርስዎ, አንድ ስብስብ መፍጠር የእርስዎን ስብስብ በ `for` ሉፕ መጠቀም ያስችላቸዋል ለ [`IntoIterator`] ተግባራዊ ከሆኑ.
//!
//! # ማጣቀሻ በ Iterating
//!
//! [`into_iter()`] አንድ ስብስብ እንዳሟጠጠው ስብስብ ላይ ለመድገም አንድ `for` ቅየራ ምልልስ በመጠቀም, ዋጋ `self` ይወስዳል በመሆኑ.ብዙውን ጊዜ ፣ ሳይበሉት በስብስብ ላይ ማመጣጠን ይፈልጉ ይሆናል።
//! ብዙ ስብስቦችን ማጣቀሻዎች ላይ iterators የሚያቀርቡ ዘዴዎች ያቀርባሉ, በእንግሊዝኛ `iter()` እና `iter_mut()` በቅደም ጠራ:
//!
//! ```
//! let mut values = vec![41];
//! for x in values.iter_mut() {
//!     *x += 1;
//! }
//! for x in values.iter() {
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1); // `values` አሁንም በዚህ ተግባር ባለቤትነት የተያዘ ነው.
//! ```
//!
//! አንድ ስብስብ አይነት `C` `iter()` የሚሰጥ ከሆነ, አብዛኛው ጊዜ ደግሞ ልክ `iter()` የሚጠራውን አንድ አፈፃፀም ጋር, `&C` ለ `IntoIterator` የሚያስፈጽም.
//! በተመሳሳይ, `iter_mut()` የሚሰጥ ስብስብ `C` በአጠቃላይ `iter_mut()` ወደ በመስጠት `&mut C` ለ `IntoIterator` የሚያስፈጽም.ይህ ምቹ በሚጽፉ ያስችለናል:
//!
//! ```
//! let mut values = vec![41];
//! for x in &mut values { // `values.iter_mut()` እንደ ተመሳሳይ
//!     *x += 1;
//! }
//! for x in &values { // ከ `values.iter()` ጋር ተመሳሳይ
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1);
//! ```
//!
//! ብዙ ስብስቦችን `iter()`, የሚያቀርቡ ቢሆንም ሁሉንም `iter_mut()` ማቅረብ አይደለም.
//! ቁልፉ ለውጥ መሰላሎች ከሆነ እነዚህ ስብስቦች ብቻ ነው `iter()` ያቀርባሉ ስለዚህ ለምሳሌ ያህል, አንድ [`HashSet<T>`] ወይም [`HashMap<K, V>`] መክፈቻ mutating, ያልተረጋጋ ሁኔታ ወደ ክምችት ማስቀመጥ አልቻለም.
//!
//! [`into_iter()`]: IntoIterator::into_iter
//! [`HashSet<T>`]: ../../std/collections/struct.HashSet.html
//! [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
//!
//! # Adapters
//!
//! እነሱ 'አስማሚ መልክ ከሆኑ እንደ አንድ [`Iterator`] ወስደው ሌላ [`Iterator`] መመለስ ይህም ተግባራት ብዙውን ጊዜ,' ለተደጋጋሚ አስማሚዎች 'ተብለው ነው
//! pattern'.
//!
//! የተለመዱ የኢታስተር አስማሚዎች [`map`] ፣ [`take`] እና [`filter`] ን ያካትታሉ።
//! ለተጨማሪ ፣ ሰነዶቻቸውን ይመልከቱ ፡፡
//!
//! የተስተካከለ አስማሚ panics ከሆነ ተደጋጋሚው ባልተገለጸ (ግን ለማስታወስ ደህና) ሁኔታ ውስጥ ይሆናል።
//! ይህ ሁኔታ በ Rust ስሪቶች ላይ ተመሳሳይ ሆኖ እንዲቆይ ዋስትና የለውም ፣ ስለሆነም በፍርሃት በተሸጋገረ ሰው በተመለሱት ትክክለኛ ዋጋዎች ላይ ከመተማመን መቆጠብ አለብዎት።
//!
//! [`map`]: Iterator::map
//! [`take`]: Iterator::take
//! [`filter`]: Iterator::filter
//!
//! # Laziness
//!
//! Iterators (እና ለተደጋጋሚ [adapters](#adapters))*ታካች* ናቸው. ብቻ አንተ [`next`] መደወል ድረስ ለተደጋጋሚ _do_ አንድ ሙሉ ብዙ. ምንም በእርግጥ ይከሰታል አይደለም አንድ መፍጠር እንደሆነ ይህ ማለት.
//! የራሱ የጎንዮሽ ጉዳት በብቸኝነት አንድ ለተደጋጋሚ ለመፍጠር ጊዜ ይህ አንዳንድ ጊዜ ግራ መጋባት ምንጭ ነው.
//! ለምሳሌ ፣ የ‹XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX ዘዴ ዘዴ ዘዴው ላይ ዘወር ብሎ ይጠራል
//!
//! ```
//! # #![allow(unused_must_use)]
//! let v = vec![1, 2, 3, 4, 5];
//! v.iter().map(|x| println!("{}", x));
//! ```
//!
//! ይህ ከመጠቀም ይልቅ ተደጋጋፊ ብቻ ስለፈጠርን ይህ ምንም እሴቶችን አያተምም።የ አጠናቃሪ ባህሪ ይህ ዓይነት እኛን አሳያችኋለሁ;
//!
//! ```text
//! warning: unused result that must be used: iterators are lazy and
//! do nothing unless consumed
//! ```
//!
//! ለጎንዮሽ ጉዳቱ ኤክስኤክስኤክስን ለመፃፍ ፈሊጣዊ መንገድ የ `for` loop ን መጠቀም ወይም የ [`for_each`] ዘዴን መደወል ነው ፡፡
//!
//! ```
//! let v = vec![1, 2, 3, 4, 5];
//!
//! v.iter().for_each(|x| println!("{}", x));
//! // or
//! for x in &v {
//!     println!("{}", x);
//! }
//! ```
//!
//! [`map`]: Iterator::map
//! [`for_each`]: Iterator::for_each
//!
//! ተደጋጋሚን የሚገመግምበት ሌላው የተለመደ መንገድ አዲስ ክምችት ለማምረት የ [`collect`] ዘዴን መጠቀም ነው ፡፡
//!
//! [`collect`]: Iterator::collect
//!
//! # Infinity
//!
//! ተቃዋሚዎች ውስን መሆን የለባቸውም።እንደ ምሳሌ ፣ የተጠናቀቀ ክልል ማለቂያ የሌለው ተደጋጋሚ ነው ፡፡
//!
//! ```
//! let numbers = 0..;
//! ```
//!
//! ማለቂያ የሌለው ተደጋጋሚ ወደ ውስንነት ለመቀየር የ [`take`] ተስተካካይ አስማሚን መጠቀም የተለመደ ነው-
//!
//! ```
//! let numbers = 0..;
//! let five_numbers = numbers.take(5);
//!
//! for number in five_numbers {
//!     println!("{}", number);
//! }
//! ```
//!
//! ይህ ቁጥር `0` እስከ `4` ድረስ እያንዳንዳቸው በራሳቸው መስመር ያትማሉ።
//!
//! አእምሮ ውስጥ የድብ በዚህም ጋዝም ጊዜ ውስጥ ለስሌት ሊታወቅ ይችላል እንኳ እነዚያ ይህም የማይቆጠር iterators,, ላይ ዘዴዎች ለማቋረጥ ላይሆን እንደሚችል.
//! በተለይም, እንደ አጠቃላይ ሁኔታ ውስጥ ለተደጋጋሚ ውስጥ እያንዳንዱ አባል እያቋረጥክ የሚያስፈልጋቸው [`min`], እንደ ዘዴዎች, አይቀርም ናቸው ማንኛውም የሌለው iterators ለ በተሳካ ሁኔታ ለመመለስ አይደለም.
//!
//! ```no_run
//! let ones = std::iter::repeat(1);
//! let least = ones.min().unwrap(); // በፍፁም!አንድ የሌለው ምልልስ!
//! // `ones.min()` ማለቂያ የሌለው ዑደት ያስከትላል ፣ ስለዚህ እዚህ ደረጃ ላይ አንደርስም!
//! println!("The smallest number one is {}.", least);
//! ```
//!
//! [`take`]: Iterator::take
//! [`min`]: Iterator::min
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::Iterator;

#[unstable(
    feature = "step_trait",
    reason = "likely to be replaced by finer-grained traits",
    issue = "42168"
)]
pub use self::range::Step;

#[stable(feature = "iter_empty", since = "1.2.0")]
pub use self::sources::{empty, Empty};
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub use self::sources::{from_fn, FromFn};
#[stable(feature = "iter_once", since = "1.2.0")]
pub use self::sources::{once, Once};
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub use self::sources::{once_with, OnceWith};
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::sources::{repeat, Repeat};
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub use self::sources::{repeat_with, RepeatWith};
#[stable(feature = "iter_successors", since = "1.34.0")]
pub use self::sources::{successors, Successors};

#[stable(feature = "fused", since = "1.26.0")]
pub use self::traits::FusedIterator;
#[unstable(issue = "none", feature = "inplace_iteration")]
pub use self::traits::InPlaceIterable;
#[unstable(feature = "trusted_len", issue = "37572")]
pub use self::traits::TrustedLen;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::{
    DoubleEndedIterator, ExactSizeIterator, Extend, FromIterator, IntoIterator, Product, Sum,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::adapters::Cloned;
#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::adapters::Copied;
#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::adapters::Flatten;
#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::adapters::MapWhile;
#[unstable(feature = "inplace_iteration", issue = "none")]
pub use self::adapters::SourceIter;
#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::adapters::StepBy;
#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::adapters::TrustedRandomAccess;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::adapters::{
    Chain, Cycle, Enumerate, Filter, FilterMap, FlatMap, Fuse, Inspect, Map, Peekable, Rev, Scan,
    Skip, SkipWhile, Take, TakeWhile, Zip,
};
#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::adapters::{Intersperse, IntersperseWith};

pub(crate) use self::adapters::process_results;

mod adapters;
mod range;
mod sources;
mod traits;