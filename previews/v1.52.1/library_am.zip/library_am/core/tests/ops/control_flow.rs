use core::intrinsics::discriminant_value;
use core::ops::ControlFlow;

#[test]
fn control_flow_discriminants_match_result() {
    // ይህ የተረጋጋ የወለል ንጣፍ አይደለም ፣ ግን LLVM ሁል ጊዜም አሁን ሊጠቀምበት ባይችልም እንኳ `?` ን በመካከላቸው ርካሽ እንዲሆን ይረዳል።
    //
    // (በሚያሳዝን ሁኔታ ውጤት እና አማራጭ የማይጣጣሙ ናቸው ፣ ስለሆነም ControlFlow ከሁለቱም ጋር ሊመሳሰል አይችልም)

    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Break(3)),
        discriminant_value(&Result::<i32, i32>::Err(3)),
    );
    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Continue(3)),
        discriminant_value(&Result::<i32, i32>::Ok(3)),
    );
}