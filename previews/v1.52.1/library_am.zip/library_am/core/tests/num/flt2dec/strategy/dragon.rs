use super::super::*;
use core::num::bignum::Big32x40 as Big;
use core::num::flt2dec::strategy::dragon::*;

#[test]
fn test_mul_pow10() {
    let mut prevpow10 = Big::from_small(1);
    for i in 1..340 {
        let mut curpow10 = Big::from_small(1);
        mul_pow10(&mut curpow10, i);
        assert_eq!(curpow10, *prevpow10.clone().mul_small(10));
        prevpow10 = curpow10;
    }
}

#[test]
fn shortest_sanity_test() {
    f64_shortest_sanity_test(format_shortest);
    f32_shortest_sanity_test(format_shortest);
    more_shortest_sanity_test(format_shortest);
}

#[test]
#[cfg_attr(miri, ignore)] // ሚሪ በጣም ቀርፋፋ ነው
fn exact_sanity_test() {
    // ምን ብዬ መገመት ብቻ ይችላሉ `exp2` ላይብረሪ ተግባር አንዳንድ ጥግ-ኢሽ ጉዳይ ነው እየሮጠ እስከ ይህ ፈተና ጫፎች, ሐ የሚፈጀውን ጊዜ እኛ እየተጠቀሙ ሁሉ ላይ በተገለጸው.
    // በ‹ቪኤስ›2013 ይህ ተግባር ሲገናኝ እንደከሸፈ ይህ ተግባር ሳንካ ነበረው ፣ ነገር ግን ከቪኤስ 2015 ጋር ሙከራው በጥሩ ሁኔታ እየሄደ ባለበት ሳንካ ተስተካክሏል ፡፡
    //
    // ሳንካው የ‹`exp2(-1057)`›የመመለሻ ዋጋ ልዩነት ያለው ይመስላል ፣ በ‹ቪኤስ›2013 ውስጥ‹ቢት ንድፍ›0x2 ን በእጥፍ ይመልሳል እና በቪኤስ 2015 ደግሞ 0x20000 ን ይመልሳል ፡፡
    //
    //
    // በአሁኑ ጊዜ ይህንን ሙከራ ሙሉ በሙሉ በ MSVC ላይ በማንኛውም ቦታ በየትኛውም ቦታ ስለሚፈተነው ችላ ይበሉ እና የእያንዳንዱን መድረክ የ exp2 አተገባበር ለመሞከር ከፍተኛ ፍላጎት የለንም ፡፡
    //
    //
    //
    //
    //
    //
    if !cfg!(target_env = "msvc") {
        f64_exact_sanity_test(format_exact);
    }
    f32_exact_sanity_test(format_exact);
}

#[test]
fn test_to_shortest_str() {
    to_shortest_str_test(format_shortest);
}

#[test]
fn test_to_shortest_exp_str() {
    to_shortest_exp_str_test(format_shortest);
}

#[test]
fn test_to_exact_exp_str() {
    to_exact_exp_str_test(format_exact);
}

#[test]
fn test_to_exact_fixed_str() {
    to_exact_fixed_str_test(format_exact);
}