# የ `rustc-std-workspace-std` crate

የ `rustc-std-workspace-core` crate ሰነድ ይመልከቱ.