use super::*;
use std::cell::Cell;

#[test]
fn allocator_param() {
    use crate::alloc::AllocError;

    // በሶስተኛ ወገን አከፋፋዮች እና በ‹XXXX›መካከል ያለውን የውህደት ሙከራ መፃፍ `RawVec` ኤ.ፒ.አይ. የሚወዳደሩ የምደባ ዘዴዎችን የማያጋልጥ ስለሆነ ትንሽ አስቸጋሪ ነው ፣ ስለሆነም አከፋፋይ ሲደክም ምን እንደ ሆነ ማረጋገጥ አንችልም (panic ን ከመለየት ባሻገር) ፡፡
    //
    //
    // በምትኩ ፣ ይህ የ `RawVec` ዘዴዎች ማከማቻ ሲያስቀምጥ ቢያንስ በ Allocator ኤፒአይ ውስጥ ያልፋሉ የሚለውን ያረጋግጣል።
    //
    //
    //
    //
    //

    // የምደባ ሙከራዎች መበላሸት ከመጀመራቸው በፊት የተወሰነ ነዳጅ የሚወስድ ደደብ አመዳደብ ፡፡
    //
    struct BoundedAlloc {
        fuel: Cell<usize>,
    }
    unsafe impl Allocator for BoundedAlloc {
        fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
            let size = layout.size();
            if size > self.fuel.get() {
                return Err(AllocError);
            }
            match Global.allocate(layout) {
                ok @ Ok(_) => {
                    self.fuel.set(self.fuel.get() - size);
                    ok
                }
                err @ Err(_) => err,
            }
        }
        unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
            unsafe { Global.deallocate(ptr, layout) }
        }
    }

    let a = BoundedAlloc { fuel: Cell::new(500) };
    let mut v: RawVec<u8, _> = RawVec::with_capacity_in(50, a);
    assert_eq!(v.alloc.fuel.get(), 450);
    v.reserve(50, 150); // (እውነተኛውን ቦታ ያስከትላል ፣ ስለሆነም 50 + 150=200 አሃዶችን በመጠቀም)
    assert_eq!(v.alloc.fuel.get(), 250);
}

#[test]
fn reserve_does_not_overallocate() {
    {
        let mut v: RawVec<u32> = RawVec::new();
        // በመጀመሪያ ፣ `reserve` እንደ `reserve_exact` ይመድባል።
        v.reserve(0, 9);
        assert_eq!(9, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 7);
        assert_eq!(7, v.capacity());
        // 97 ከ 7 እጥፍ በላይ ነው ፣ ስለሆነም `reserve` እንደ `reserve_exact` መሥራት አለበት።
        //
        v.reserve(7, 90);
        assert_eq!(97, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 12);
        assert_eq!(12, v.capacity());
        v.reserve(12, 3);
        // 3 ከ 12 ግማሽ በታች ነው ፣ ስለሆነም `reserve` በከፍተኛ ሁኔታ ማደግ አለበት።
        // ይህ የሙከራ ዕድገት መጠን በሚጻፍበት ጊዜ 2 ነው ፣ ስለሆነም አዲስ አቅም 24 ነው ፣ ሆኖም የ 1.5 ዕድገት መጠን እንዲሁ እሺ ነው።
        //
        // ስለሆነም `>= 18` ን በማስረገጥ ላይ።
        assert!(v.capacity() >= 12 + 12 / 2);
    }
}