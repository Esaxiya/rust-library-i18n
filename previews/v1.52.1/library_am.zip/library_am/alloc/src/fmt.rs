//! ‹String`s ን ለመቅረጽ እና ለማተም መገልገያዎች ፡፡
//!
//! ይህ ሞጁል ለ [`format!`] አገባብ ቅጥያ የእረፍት ጊዜ ድጋፍን ይ containsል።
//! ክርክርን ወደ ህብረቁምፊ ለመቀየር ይህ ማክሮ በአቅራቢው ውስጥ ጥሪዎችን ወደዚህ ሞጁል ለመልቀቅ ይተገበራል ፡፡
//!
//! # Usage
//!
//! [`format!`] macro ከ C's `printf`/`fprintf` ተግባራት ወይም ከ Python's `str.format` ተግባር ለሚመጡት በደንብ እንዲታወቅ የታሰበ ነው ፡፡
//!
//! የ [`format!`] ቅጥያ አንዳንድ ምሳሌዎች
//!
//! ```
//! format!("Hello");                 // => "Hello"
//! format!("Hello, {}!", "world");   // => "Hello, world!"
//! format!("The number is {}", 1);   // => "The number is 1"
//! format!("{:?}", (3, 4));          // => "(3, 4)"
//! format!("{value}", value=4);      // => "4"
//! format!("{} {}", 1, 2);           // => "1 2"
//! format!("{:04}", 42);             // => "0042" ከዜሮዎች መሪ ጋር
//! ```
//!
//! ከእነዚህ ውስጥ የመጀመሪያው ክርክር የቅርጸት ሕብረቁምፊ መሆኑን ማየት ይችላሉ ፡፡ይህ ቃል በቃል የሕብረቁምፊ እንዲሆን በአቀማሚው ይፈለጋል።(ትክክለኛነትን ለማጣራት) የተላለፈ ተለዋዋጭ ሊሆን አይችልም።
//! አሰባሳቢው የቅርጸት ሕብረቁምፊውን በመተንተን የቀረበው የክርክር ዝርዝር ወደዚህ ቅርጸት ሕብረቁምፊ ለማለፍ ተስማሚ መሆኑን ይወስናል።
//!
//! አንድ ነጠላ እሴት ወደ ሕብረቁምፊ ለመለወጥ የ [`to_string`] ዘዴን ይጠቀሙ።ይህ [`Display`] ቅርጸት trait ይጠቀማል.
//!
//! ## የአቀማመጥ መለኪያዎች
//!
//! እያንዳንዱ የቅርጸት ክርክር የትኛውን የእሴት ክርክር እያጣቀሰ እንደሆነ ለመለየት ይፈቀዳል ፣ እና ከተተወ "the next argument" ነው ተብሎ ይገመታል ፡፡
//! ለምሳሌ ፣ የ‹XXXX›ቅርጸት ሕብረቁምፊ ሶስት መለኪያዎች ይወስዳል ፣ እና እነሱ በሚሰጡት ቅደም ተከተል ይቀረፃሉ።
//! የቅርጸት ሕብረቁምፊ `{2} {1} {0}` ግን ክርክሮችን በተቃራኒው ቅደም ተከተል ይቀይረዋል።
//!
//! ሁለቱን የአቀማመጥ አመላካቾች ማደባለቅ ከጀመሩ ነገሮች ትንሽ አስቸጋሪ ሊሆኑ ይችላሉ ፡፡የ "next argument" ገላጭ ወደ ክርክር ላይ አንድ ለተደጋጋሚ ተደርጎ ሊታሰብ ይችላል.
//! የ "next argument" ገላጭ በሚታይበት እያንዳንዱ ጊዜ ተደጋጋሚው ይራመዳል።ይህ ወደ እንደዚህ አይነት ባህሪ ይመራል
//!
//! ```
//! format!("{1} {} {0} {}", 1, 2); // => "2 1 1 2"
//! ```
//!
//! ወደ ክርክር ላይ ያለው የውስጥ ለተደጋጋሚ ስለዚህ የመጀመሪያው ሙግት አሻራ, የመጀመሪያው `{}` ይታያል ጊዜ በ አርጅተው አልተደረገም.ከዚያ ወደ ሁለተኛው `{}` ሲደርስ ተደጋጋሚው ወደ ሁለተኛው ክርክር ወደፊት ገሰገሰ ፡፡
//! በመሠረቱ ፣ ክርክራቸውን በግልፅ የሰየሙ መለኪያዎች በአቀማመጥ ጠቋሚዎች ላይ ክርክርን የማይጠቅሱ ግቤቶችን አይነኩም ፡፡
//!
//! ሁሉንም ክርክሮቹን ለመጠቀም የቅርጸት ሕብረቁምፊ ያስፈልጋል ፣ አለበለዚያ እሱ የማጠናቀር-ጊዜ ስህተት ነው።በተመሳሳዩ ክርክር ውስጥ ከአንድ ጊዜ በላይ ተመሳሳይ ክርክርን ሊያመለክቱ ይችላሉ።
//!
//! ## የተሰየሙ መለኪያዎች
//!
//! Rust እራሱ ለ‹ተግባር›የተሰየሙ መለኪያዎች የ Python የመሰለ አቻ የለውም ፣ ግን [`format!`] ማክሮ የተሰየሙትን መለኪያዎች እንዲጠቀምበት የሚያስችል የአገባብ ቅጥያ ነው ፡፡
//! የተሰየሙ መለኪያዎች በክርክሩ ዝርዝር መጨረሻ ላይ ተዘርዝረዋል እና አገባብ አላቸው:
//!
//! ```text
//! identifier '=' expression
//! ```
//!
//! ለምሳሌ ያህል, የሚከተሉትን [`format!`] ሁሉ ጥቅም የሚባል እሴት የምንገልጽባቸው:
//!
//! ```
//! format!("{argument}", argument = "test");   // => "test"
//! format!("{name} {}", 1, name = 2);          // => "2 1"
//! format!("{a} {c} {b}", a="a", b='b', c=3);  // => "a 3 b"
//! ```
//!
//! ስሞች ካሏቸው ክርክሮች በኋላ የአቀማመጥ መለኪያዎች (ስሞች የሌላቸውን) ማስቀመጥ ትክክል አይደለም ፡፡ልክ ከአቀማመጥ መለኪያዎች ጋር ፣ በቅርጸት ህብረቁምፊው ጥቅም ላይ ያልዋሉ የተሰየሙ መለኪያዎች ማቅረብ ትክክል አይደለም።
//!
//! # የቅርጸት መለኪያዎች
//!
//! የሚቀርጸው እያንዳንዱ ክርክር በበርካታ የቅርጸት መለኪያዎች ሊለወጥ ይችላል (በ [the syntax](#syntax)) ውስጥ ካለው `format_spec` ጋር ይዛመዳል። እነዚህ መለኪያዎች በሚቀርጸው ነገር ላይ ባለው የሕብረቁምፊ ውክልና ላይ ተጽዕኖ ያሳድራሉ)።
//!
//! ## Width
//!
//! ```
//! // እነዚህ ሁሉ "Hello x !" ን ያትማሉ
//! println!("Hello {:5}!", "x");
//! println!("Hello {:1$}!", "x", 5);
//! println!("Hello {1:0$}!", 5, "x");
//! println!("Hello {:width$}!", "x", width = 5);
//! ```
//!
//! ቅርጸቱ መውሰድ ያለበት ይህ ለ "minimum width" መለኪያ ነው።
//! የእሴሉ ሕብረቁምፊ እነዚህን ብዙ ቁምፊዎች የማይሞላ ከሆነ ታዲያ በ fill/alignment የተጠቀሰው ንጣፍ የሚፈለገውን ቦታ ለመውሰድ ይጠቅማል (ከዚህ በታች ይመልከቱ)።
//!
//! የሁለተኛው ክርክር ደግሞ ስፋቱን የሚገልጽ [`usize`] መሆኑን የሚያመለክተው የስፋቱ እሴት እንዲሁ በመለኪያዎች ዝርዝር ውስጥ እንደ‹[`usize`]›ልጥፍ `$` በመደመር ሊቀርብ ይችላል ፡፡
//!
//! ብዙውን ቦታ በ ጭቅጭቅ ሊያመለክት, ወይም የተባለ የመከራከሪያ መጠቀም ጥሩ ሀሳብ ነው ስለዚህ ዶላር አገባብ ጋር ጭቅጭቅ አስመልክቶ, የ "next argument" ቆጣሪ ላይ ተጽዕኖ የለውም.
//!
//! ## Fill/Alignment
//!
//! ```
//! assert_eq!(format!("Hello {:<5}!", "x"),  "Hello x    !");
//! assert_eq!(format!("Hello {:-<5}!", "x"), "Hello x----!");
//! assert_eq!(format!("Hello {:^5}!", "x"),  "Hello   x  !");
//! assert_eq!(format!("Hello {:>5}!", "x"),  "Hello     x!");
//! ```
//!
//! የአማራጭ መሙላት ቁምፊ እና አሰላለፍ ከ‹[`width`](#width)›ልኬት ጋር በመደበኛነት ይሰጣል ፡፡እሱም ቀኝ `:` በኋላ, `width` በፊት የተገለጸ መሆን አለበት.
//! ይህ የሚያመለክተው የሚቀረፀው እሴት ከ `width` ያነሰ ከሆነ አንዳንድ ተጨማሪ ቁምፊዎች በዙሪያው ይታተማሉ።
//! ለተለያዩ ማስተካከያዎች መሙላት በሚከተሉት ዓይነቶች ይመጣል ፡፡
//!
//! * `[fill]<` - ክርክሩ በ `width` አምዶች ውስጥ በግራ-ተስተካክሏል
//! * `[fill]^` - ክርክሩ በ `width` አምዶች ውስጥ በመሃል የተስተካከለ ነው
//! * `[fill]>` - ክርክሩ በ `width` አምዶች ውስጥ በቀኝ-ተስተካክሏል
//!
//! ለቁጥር ቁጥሮች ነባሪው [fill/alignment](#fillalignment) ቦታ እና በግራ የተሰለፈ ነው።ለቁጥር ፎርማተሮች ነባሪው እንዲሁ የቦታ ቁምፊ ነው ነገር ግን በቀኝ-አሰላለፍ።
//! የ `0` ባንዲራ (ከዚህ በታች ይመልከቱ) ለቁጥሮች ከተገለጸ ከዚያ ግልጽ ያልሆነ የመሙላት ቁምፊ `0` ነው።
//!
//! አሰላለፍ በአንዳንድ ዓይነቶች ሊተገበር እንደማይችል ልብ ይበሉ ፡፡በተለይም, ይህም በአጠቃላይ `Debug` trait ለ አልተተገበረም.
//! መከለያ መተግበሩን የሚያረጋግጥ ጥሩ መንገድ ግብዓትዎን መቅረፅ ነው ፣ ከዚያ ምርትዎን ለማግኘት ይህንን ውጤት ያስገኛል ፡፡
//!
//! ```
//! println!("Hello {:^15}!", format!("{:?}", Some("hi"))); // => "ሰላም Some("hi")!"
//! ```
//!
//! ## Sign/`#`/`0`
//!
//! ```
//! assert_eq!(format!("Hello {:+}!", 5), "Hello +5!");
//! assert_eq!(format!("{:#x}!", 27), "0x1b!");
//! assert_eq!(format!("Hello {:05}!", 5),  "Hello 00005!");
//! assert_eq!(format!("Hello {:05}!", -5), "Hello -0005!");
//! assert_eq!(format!("{:#010x}!", 27), "0x0000001b!");
//! ```
//!
//! እነዚህ ሁሉ የቅርጸ-ሰሪውን ባህሪ የሚቀይሩ ባንዲራዎች ናቸው።
//!
//! * `+` - ይህ ለቁጥር ዓይነቶች የታሰበ ሲሆን ምልክቱ ሁል ጊዜ መታተም እንዳለበት ያመላክታል።አዎንታዊ ምልክቶች በነባሪ በጭራሽ አይታተሙም ፣ እና አሉታዊ ምልክቱ በነባሪ ለ `Signed` trait ብቻ ይታተማል።
//! ይህ ባንዲራ የሚያመለክተው ትክክለኛው ምልክት (`+` ወይም `-`) ሁል ጊዜ መታተም አለበት።
//! * `-` - በአሁኑ ጊዜ ጥቅም ላይ አልዋለም
//! * `#` - ይህ ባንዲራ የ "alternate" ማተሚያ ቅፅ ጥቅም ላይ መዋል እንዳለበት ያመላክታል።ተለዋጭ ቅጾች
//!     * `#?` - የ [`Debug`] ቅርጸት ቆንጆ-ያትሙ
//!     * `#x` - ከ `0x` ጋር ክርክሩን ይቀድማል
//!     * `#X` - ከ `0x` ጋር ክርክሩን ይቀድማል
//!     * `#b` - ከ `0b` ጋር ክርክሩን ይቀድማል
//!     * `#o` - ከ `0o` ጋር ክርክሩን ይቀድማል
//! * `0` - ይህ ለ‹XXXX›ን መቅዳት ሁለቱም በ‹`0`›ገጸ-ባህሪይ እንዲሁም በምልክት-ንቁ መሆን እንዳለባቸው ለኢቲጀር ቅርፀቶች ለማመልከት ይጠቅማል ፡፡
//! ተመሳሳይ ቅርጸት ኢንቲጀር `-1` ለ `-0000001` የማለፉን ነበር ሳለ `{:08}` እንደ አንድ ቅርጸት, የ ኢንቲጀር `1` ለ `00000001` ማፍራት ነበር.
//! አሉታዊው ስሪት ከአዎንታዊው ስሪት አንድ ያነሰ ዜሮ እንዳለው ልብ ይበሉ ፡፡
//!         የማጣበቂያ ዜሮዎች ሁል ጊዜ ከምልክቱ በኋላ (ካለ) እና ከቁጥሮች በፊት እንደሚቀመጡ ልብ ይበሉ ፡፡ከኤክስኤክስኤክስኤክስ ባንዲራ ጋር አንድ ላይ ሲሠራ ተመሳሳይ ሕግ ይተገበራል-ቀዘፋ ዜሮዎች ከቅድመ ቅጥያው በኋላ ግን ከቁጥሮች በፊት ገብተዋል ፡፡
//!         ቅድመ-ቅጥያው በጠቅላላው ስፋት ውስጥ ተካትቷል ፡፡
//!
//! ## Precision
//!
//! ቁጥራዊ ያልሆኑ ቁጥሮች ይህ እንደ "maximum width" ሊቆጠር ይችላል።
//! የሚወጣው ሕብረቁምፊ ከዚህ ስፋት የበለጠ ከሆነ ከዚያ ወደዚህ ብዙ ቁምፊዎች ተደምስሷል እና ያ የተስተካከለ እሴት እነዚያ መለኪያዎች ከተዘጋጁ በተገቢው `fill` ፣ `alignment` እና `width` ይወጣል።
//!
//! ለዋና ዓይነቶች ፣ ይህ ችላ ተብሏል።
//!
//! ለመንሳፈፍ-የነጥብ ዓይነቶች ይህ ከአስርዮሽ ነጥብ በኋላ ምን ያህል አሃዞች መታተም እንዳለባቸው ያሳያል።
//!
//! የተፈለገውን `precision` ለመለየት ሦስት ሊሆኑ የሚችሉ መንገዶች አሉ-
//!
//! 1. አንድ ቁጥር `.N`
//!
//!    ኢንቲጀር `N` ራሱ ትክክለኛ ነው።
//!
//! 2. አንድ ቁጥር ወይም ስም በዶላር ምልክት `.N$` ተከትሎ
//!
//!    ቅርጸት *ክርክር*`N` (እሱም `usize` መሆን አለበት) እንደ ትክክለኛነቱ ይጠቀሙ።
//!
//! 3. የኮከብ ምልክት `.*`
//!
//!    `.*` ይህ `{...}`*ሁለት* ቅርጸት ግብዓቶች ይልቅ በአንድ ጋር የተያያዘ ነው ማለት ነው; የመጀመሪያው ግቤት የ `usize` ዝንፍ የያዘው ሲሆን ሁለተኛው ማተም ዋጋ ይዟል.
//!    ልብ ይበሉ ፣ በዚህ ውስጥ ፣ አንድ ሰው የቅርጸት ገመድ `{<arg>:<spec>.*}` ን ከተጠቀመ የ `<arg>` ክፍል ለማተም* እሴት * የሚያመለክት ሲሆን `precision` ከ `<arg>` በፊት ባለው ግብዓት መምጣት አለበት።
//!
//! ለምሳሌ ፣ የሚከተሉት ጥሪዎች ሁሉም ተመሳሳይ ነገር ያትማሉ `Hello x is 0.01000`:
//!
//! ```
//! // ጤና ይስጥልኝ {arg 0 ("x")} {arg 1 (0.01) with precision specified inline (5)} ነው
//! println!("Hello {0} is {1:.5}", "x", 0.01);
//!
//! // ጤና ይስጥልኝ {arg 1 ("x")} {arg 2 (0.01) with precision specified in arg 0 (5)} ነው
//! println!("Hello {1} is {2:.0$}", 5, "x", 0.01);
//!
//! // ጤና ይስጥልኝ {arg 0 ("x")} {arg 2 (0.01) with precision specified in arg 1 (5)} ነው
//! println!("Hello {0} is {2:.1$}", "x", 5, 0.01);
//!
//! // ጤና ይስጥልኝ {next arg ("x")} {second of next two args (0.01) with precision specified in first of next two args (5)} ነው
//! //
//! println!("Hello {} is {:.*}",    "x", 5, 0.01);
//!
//! // ጤና ይስጥልኝ {next arg ("x")} {arg 2 (0.01) with precision specified in its predecessor (5)} ነው
//! //
//! println!("Hello {} is {2:.*}",   "x", 5, 0.01);
//!
//! // ጤና ይስጥልኝ {next arg ("x")} {arg "number" (0.01) with precision specified in arg "prec" (5)} ነው
//! //
//! println!("Hello {} is {number:.prec$}", "x", prec = 5, number = 0.01);
//! ```
//!
//! እነዚህ
//!
//! ```
//! println!("{}, `{name:.*}` has 3 fractional digits", "Hello", 3, name=1234.56);
//! println!("{}, `{name:.*}` has 3 characters", "Hello", 3, name="1234.56");
//! println!("{}, `{name:>8.*}` has 3 right-aligned characters", "Hello", 3, name="1234.56");
//! ```
//!
//! ሶስት ልዩ ልዩ ነገሮችን ያትሙ
//!
//! ```text
//! Hello, `1234.560` has 3 fractional digits
//! Hello, `123` has 3 characters
//! Hello, `     123` has 3 right-aligned characters
//! ```
//!
//! ## Localization
//!
//! በአንዳንድ የፕሮግራም ቋንቋዎች የሕብረቁምፊ ቅርጸት ተግባራት ባህሪ በስርዓተ ክወናው አካባቢያዊ አቀማመጥ ላይ የተመሠረተ ነው ፡፡
//! በ Rust መደበኛ ቤተ-መጽሐፍት የቀረቡት የቅርጸት ተግባራት ምንም ዓይነት የአከባቢ ፅንሰ-ሀሳብ የላቸውም እናም የተጠቃሚ ውቅር ምንም ይሁን ምን በሁሉም ስርዓቶች ላይ ተመሳሳይ ውጤት ያስገኛል ፡፡
//!
//! የስርዓቱ አካባቢ አንድ ነጥብ ሌላ አስርዮሽ SEPARATOR ይጠቀማል እንኳ ለምሳሌ ያህል, የሚከተሉትን ኮድ ሁልጊዜ `1.5` ማተም ይሆናል.
//!
//! ```
//! println!("The value is {}", 1.5);
//! ```
//!
//! # Escaping
//!
//! የቃል ቁምፊዎች `{` እና `}` ከተመሳሳዩ ገጸ-ባህሪ ጋር ቀድመው በማስቀመጥ በአንድ ሕብረቁምፊ ውስጥ ሊካተቱ ይችላሉ።ለምሳሌ ፣ የ `{` ቁምፊ ከ `{{` ጋር አምልጧል እና የ `}` ቁምፊ ከ `}}` ጋር አምልጧል ፡፡
//!
//! ```
//! assert_eq!(format!("Hello {{}}"), "Hello {}");
//! assert_eq!(format!("{{ Hello"), "{ Hello");
//! ```
//!
//! # Syntax
//!
//! ለማጠቃለል እዚህ የቅርጸት ሕብረቁምፊዎች ሙሉ ሰዋሰው ማግኘት ይችላሉ ፡፡
//! ጥቅም ላይ የዋለው የቅርጸት ቋንቋ አገባብ ከሌሎች ቋንቋዎች የተወሰደ ነው ፣ ስለሆነም በጣም እንግዳ መሆን የለበትም።ክርክሮች በ Python-like አገባብ የተቀረፁ ናቸው ፣ ማለትም ክርክሮች ከ‹ሲ›`%` ይልቅ በ `{}` የተከበቡ ናቸው ማለት ነው ፡፡
//! የቅርጸት አገባብ ለማግኘት ትክክለኛ ሰዋሰው ነው:
//!
//! ```text
//! format_string := text [ maybe_format text ] *
//! maybe_format := '{' '{' | '}' '}' | format
//! format := '{' [ argument ] [ ':' format_spec ] '}'
//! argument := integer | identifier
//!
//! format_spec := [[fill]align][sign]['#']['0'][width]['.' precision]type
//! fill := character
//! align := '<' | '^' | '>'
//! sign := '+' | '-'
//! width := count
//! precision := count | '*'
//! type := '' | '?' | 'x?' | 'X?' | identifier
//! count := parameter | integer
//! parameter := argument '$'
//! ```
//! ከላይ ባለው ሰዋሰው ውስጥ `text` ማንኛውንም `'{'` ወይም `'}'` ቁምፊዎች ሊኖረው አይችልም ፡፡
//!
//! # traits ን መቅረጽ
//!
//! አንድ ክርክር ከአንድ ዓይነት ጋር እንዲቀርጽ በሚጠይቁበት ጊዜ በእርግጥ ክርክር ለተለየ trait እንዲሰጥ ይጠይቃሉ ፡፡
//! ይህ በርካታ ትክክለኛ ዓይነቶችን በ `{:x}` በኩል ለመቅረጽ ያስችላቸዋል (እንደ [`i8`] እና እንዲሁም [`isize`]) ፡፡የ traits የአሁኑ አይነቶች ካርታ-
//!
//! * *ምንም* ⇒ [`Display`]
//! * `?` ⇒ [`Debug`]
//! * `x?` ⇒ [`Debug`] ከዝቅተኛ-ፊደል ሄክሳዴሲማል ቁጥሮች ጋር
//! * `X?` ⇒ [`Debug`] ከከፍተኛ-ፊደል ሄክሳዴሲማል ቁጥሮች ጋር
//! * `o` ⇒ [`Octal`]
//! * `x` ⇒ [`LowerHex`]
//! * `X` ⇒ [`UpperHex`]
//! * `p` ⇒ [`Pointer`]
//! * `b` ⇒ [`Binary`]
//! * `e` ⇒ [`LowerExp`]
//! * `E` ⇒ [`UpperExp`]
//!
//! ይህ ምን ማለት [`fmt::Binary`][`Binary`] trait ን ተግባራዊ የሚያደርግ ማንኛውም ዓይነት ክርክር ከዚያ በ `{:b}` ሊቀረጽ ይችላል ፡፡ትግበራዎች ለእነዚህ traits ለብዙ ጥንታዊ ዓይነቶች በመደበኛ ቤተ-መጽሐፍት እንዲሁ ቀርበዋል ፡፡
//!
//! ምንም ቅርጸት (`{}` ወይም `{:6}` ውስጥ ያሉ) ከተገለጸ, ከዚያም trait የዋለውን ቅርጸት [`Display`] trait ነው.
//!
//! ቅርጸት trait ን ለራስዎ ዓይነት ሲተገበሩ የፊርማውን ዘዴ መተግበር ይኖርብዎታል-
//!
//! ```
//! # #![allow(dead_code)]
//! # use std::fmt;
//! # struct Foo; // የእኛ ብጁ ዓይነት
//! # impl fmt::Display for Foo {
//! fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//! # write!(f, "testing, testing")
//! # } }
//! ```
//!
//! የእርስዎ ዓይነት እንደ `self` በ-ማጣቀሻ ይተላለፋል ፣ ከዚያ ተግባሩ በ `f.buf` ዥረት ውስጥ ምርቱን ማውጣት አለበት።በትክክል የተጠየቀውን ቅርጸት መለኪያዎች በጥብቅ እያንዳንዱ ቅርጸት trait ትግበራ ድረስ ነው.
//! እነዚህ መለኪያዎች ውስጥ እሴቶቹ [`Formatter`] struct መስኮች ውስጥ የተዘረዘሩትን ይሆናል.ለዚህም ለማገዝ የ [`Formatter`] መዋቅሩ እንዲሁ አንዳንድ ረዳት ዘዴዎችን ይሰጣል ፡፡
//!
//! በተጨማሪም የዚህ ተግባር መመለሻ ዋጋ [`fmt::Result`] ነው የ ``ውጤት`]`<() ፣`[`std: : fmt::Error`] `>> የሚል ቅጽል ስም ነው።
//! ትግበራዎችን መቅረፅ ስህተቶችን ከ [`Formatter`] (ለምሳሌ [`write!`] ሲደውሉ) እንደሚያሰራጩ ማረጋገጥ አለባቸው ፡፡
//! ሆኖም ፣ በጭራሽ በስህተት ስህተቶችን መመለስ የለባቸውም።
//! ይኸውም ፣ የቅርጸት አተገባበር የግድ እና ስህተቱን ሊመልስ የሚችለው ያለፈውን [`Formatter`] ስህተት ከመለሰ ብቻ ነው።
//! ይህ የሆነበት ምክንያት ከተግባሩ ፊርማው ከሚጠቆመው በተቃራኒ የሕብረቁምፊ ቅርፀት የማይሳሳት ሥራ ነው።
//! ይህ ተግባር ውጤቱን ብቻ ይመልሳል ምክንያቱም ለዋናው ጅረት መፃፍ ሊከሽፍ ስለሚችል የተከማቸን ምትኬ አንድ ስህተት ተከስቷል የሚለውን ለማሰራጨት የሚያስችል መንገድ ማቅረብ አለበት ፡፡
//!
//! የ traits ቅርጸትን የማስፈፀም ምሳሌ የሚከተለውን ይመስላል:
//!
//! ```
//! use std::fmt;
//!
//! #[derive(Debug)]
//! struct Vector2D {
//!     x: isize,
//!     y: isize,
//! }
//!
//! impl fmt::Display for Vector2D {
//!     fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//!         // የ `f` እሴት የ `Write` trait ን ይተገበራል ፣ ይህም የሚጽፈው ነው!ማክሮ እየጠበቀ ነው ፡፡
//!         // ልብ ይበሉ ይህ ቅርጸት ሕብረቁምፊዎችን ለመቅረፅ የተሰጡትን የተለያዩ ባንዲራዎች ችላ ይላል ፡፡
//!         //
//!         write!(f, "({}, {})", self.x, self.y)
//!     }
//! }
//!
//! // የተለያዩ traits የአንድ ዓይነት የተለያዩ የውጤት ዓይነቶች እንዲፈቅዱ ያስችላቸዋል።
//! // የዚህ ቅርጸት ትርጉም የ vector ን መጠን ማተም ነው።
//! impl fmt::Binary for Vector2D {
//!     fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//!         let magnitude = (self.x * self.x + self.y * self.y) as f64;
//!         let magnitude = magnitude.sqrt();
//!
//!         // በ Formatter ነገር ላይ ረዳት ስልት `pad_integral` በመጠቀም ቅርጸት ባንዲራዎች እናከብራለን.
//!         // ለዝርዝሮች ዘዴ ሰነዱን ይመልከቱ ፣ እና `pad` ተግባር ሕብረቁምፊዎችን ለማንጠፍ ሊያገለግል ይችላል።
//!         //
//!         //
//!         let decimals = f.precision().unwrap_or(3);
//!         let string = format!("{:.*}", decimals, magnitude);
//!         f.pad_integral(true, "", &string)
//!     }
//! }
//!
//! fn main() {
//!     let myvector = Vector2D { x: 3, y: 4 };
//!
//!     println!("{}", myvector);       // => "(3, 4)"
//!     println!("{:?}", myvector);     // => "Vector2D {x: 3, y:4}"
//!     println!("{:10.3b}", myvector); // => "     5.000"
//! }
//! ```
//!
//! ### `fmt::Display` ከ `fmt::Debug` ጋር
//!
//! እነዚህ ሁለት ቅርጸት traits የተለያዩ ዓላማዎች አሏቸው-
//!
//! - [`fmt::Display`][`Display`] አተገባበርዎች እንደሚያሳዩት ዓይነት በማንኛውም ጊዜ እንደ UTF-8 ሕብረቁምፊ በታማኝነት ሊወከል ይችላል ፡፡ሁሉም ዓይነቶች [`Display`] trait ን ይተገብራሉ ተብሎ **አይጠበቅም**።
//! - [`fmt::Debug`][`Debug`] አፈፃፀም ለ **ሁሉ** ሕዝባዊ ዓይነቶች መተግበር አለበት ፡፡
//!   ውጤት በተለምዶ የውስጥ ሁኔታን በተቻለ መጠን በታማኝነት ይወክላል ፡፡
//!   የ [`Debug`] trait ዓላማ የ Rust ኮድ ማረም ማመቻቸት ነው።በአብዛኛዎቹ ሁኔታዎች `#[derive(Debug)]` ን መጠቀም በቂ እና የሚመከር ነው ፡፡
//!
//! ከሁለቱም የ traits የምርት ውጤቶች ምሳሌዎች-
//!
//! ```
//! assert_eq!(format!("{} {:?}", 3, 4), "3 4");
//! assert_eq!(format!("{} {:?}", 'a', 'b'), "a 'b'");
//! assert_eq!(format!("{} {:?}", "foo\n", "bar\n"), "foo\n \"bar\\n\"");
//! ```
//!
//! # ተዛማጅ ማክሮዎች
//!
//! በ [`format!`] ቤተሰብ ውስጥ በርካታ ተዛማጅ ማክሮዎች አሉ ፡፡በአሁኑ ጊዜ የሚተገበሩት የሚከተሉት ናቸው ፡፡
//!
//! ```ignore (only-for-syntax-highlight)
//! format!      // described above
//! write!       // first argument is a &mut io::Write, the destination
//! writeln!     // same as write but appends a newline
//! print!       // the format string is printed to the standard output
//! println!     // same as print but appends a newline
//! eprint!      // the format string is printed to the standard error
//! eprintln!    // same as eprint but appends a newline
//! format_args! // described below.
//! ```
//!
//! ### `write!`
//!
//! ይህን እና [`writeln!`] በተወሰነ ዥረት ወደ ቅርጸት ሕብረቁምፊ ያሰማሉ ላይ የትኛዎቹ መተግበሪያዎች ጥቅም ላይ ሁለት ማክሮዎችን ናቸው.ይህ የቅርጸት ሕብረቁምፊዎችን መካከለኛ ምደባ ለመከላከል እና በቀጥታ ውጤቱን በቀጥታ ይጽፋል።
//! በመከለያው ስር ይህ ተግባር በእውነቱ በ [`std::io::Write`] trait ላይ የተገለጸውን የ [`write_fmt`] ተግባርን እየጠራ ነው።
//! የምሳሌ አጠቃቀም
//!
//! ```
//! # #![allow(unused_must_use)]
//! use std::io::Write;
//! let mut w = Vec::new();
//! write!(&mut w, "Hello {}!", "world");
//! ```
//!
//! ### `print!`
//!
//! ይህን እና [`println!`] stdout ያላቸውን ውፅዓት ያሰማሉ.በተመሳሳይ ሁኔታ ከ‹[`write!`]›ማክሮ ፣ የእነዚህ ማክሮዎች ግብ ውጤትን በሚታተምበት ጊዜ መካከለኛ ድልድሎችን ማስቀረት ነው ፡፡የምሳሌ አጠቃቀም
//!
//! ```
//! print!("Hello {}!", "world");
//! println!("I have a newline {}", "character at the end");
//! ```
//!
//! ### `eprint!`
//!
//! ውጤታቸውን ወደ stderr ከመልቀቃቸው በስተቀር [`eprint!`] እና [`eprintln!`] ማክሮዎች ከ [`print!`] እና [`println!`] ጋር ተመሳሳይ ናቸው ፡፡
//!
//! ### `format_args!`
//!
//! ይህ የቅርጸት ሕብረቁምፊን በሚገልጽ ግልጽ ባልሆነ ነገር ውስጥ በደህና ለማለፍ የሚያገለግል የማወቅ ጉጉት ያለው ማክሮ ነው።ይህ ነገር ለመፍጠር ማንኛውንም ክምር ምደባ አያስፈልገውም ፣ እና እሱ በቁጥሩ ላይ ያለውን መረጃ ብቻ ነው የሚያመለክተው።
//! በመከለያ ስር, የተዛመዱ የማክሮዎች ሁሉ ከዚህ አንፃር ተግባራዊ ናቸው.
//! መጀመሪያ ፣ ለምሳሌ ምሳሌ አጠቃቀም ነው
//!
//! ```
//! # #![allow(unused_must_use)]
//! use std::fmt;
//! use std::io::{self, Write};
//!
//! let mut some_writer = io::stdout();
//! write!(&mut some_writer, "{}", format_args!("print with a {}", "macro"));
//!
//! fn my_fmt_fn(args: fmt::Arguments) {
//!     write!(&mut io::stdout(), "{}", args);
//! }
//! my_fmt_fn(format_args!(", or a {} too", "function"));
//! ```
//!
//! የ [`format_args!`] ማክሮ ውጤት የ‹[`fmt::Arguments`]›አይነት እሴት ነው ፡፡
//! የቅርጸት ሕብረቁምፊን ለማስኬድ ይህ መዋቅር በዚህ ሞጁል ውስጥ ወደ‹[`write`]›እና‹[`format`]›ተግባራት ሊተላለፍ ይችላል ፡፡
//! የዚህ ማክሮ ግብ ከቅርጸት ሕብረቁምፊዎች ጋር በሚገናኝበት ጊዜ መካከለኛ ድልድሎችን የበለጠ ለመከላከል ነው ፡፡
//!
//! ለምሳሌ ፣ የምዝግብ ማስታወሻ ቤተ-መጽሐፍት መደበኛውን ቅርጸት አገባብ ሊጠቀም ይችላል ፣ ነገር ግን ምርቱ ወዴት መሄድ እንዳለበት እስኪያረጋግጥ ድረስ በዚህ መዋቅር ውስጥ ያልፋል ፡፡
//!
//! [`fmt::Result`]: Result
//! [`Result`]: core::result::Result
//! [`std::fmt::Error`]: Error
//! [`write!`]: core::write
//! [`write`]: core::write
//! [`format!`]: crate::format
//! [`to_string`]: crate::string::ToString
//! [`writeln!`]: core::writeln
//! [`write_fmt`]: ../../std/io/trait.Write.html#method.write_fmt
//! [`std::io::Write`]: ../../std/io/trait.Write.html
//! [`print!`]: ../../std/macro.print.html
//! [`println!`]: ../../std/macro.println.html
//! [`eprint!`]: ../../std/macro.eprint.html
//! [`eprintln!`]: ../../std/macro.eprintln.html
//! [`format_args!`]: core::format_args
//! [`fmt::Arguments`]: Arguments
//! [`format`]: crate::format
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[unstable(feature = "fmt_internals", issue = "none")]
pub use core::fmt::rt;
#[stable(feature = "fmt_flags_align", since = "1.28.0")]
pub use core::fmt::Alignment;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::Error;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{write, ArgumentV1, Arguments};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Binary, Octal};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Debug, Display};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{DebugList, DebugMap, DebugSet, DebugStruct, DebugTuple};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Formatter, Result, Write};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{LowerExp, UpperExp};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{LowerHex, Pointer, UpperHex};

use crate::string;

/// የ `format` ተግባር የ [`Arguments`] መዋቅርን ይወስዳል እና የተገኘውን የቅርጽ ገመድ ይመልሳል።
///
///
/// የ [`Arguments`] ምሳሌ በ [`format_args!`] ማክሮ ሊፈጠር ይችላል።
///
/// # Examples
///
/// መሠረታዊ አጠቃቀም
///
/// ```
/// use std::fmt;
///
/// let s = fmt::format(format_args!("Hello, {}!", "world"));
/// assert_eq!(s, "Hello, world!");
/// ```
///
/// እባክዎ [`format!`] ን መጠቀም ተመራጭ ሊሆን እንደሚችል እባክዎ ልብ ይበሉ።
/// Example:
///
/// ```
/// let s = format!("Hello, {}!", "world");
/// assert_eq!(s, "Hello, world!");
/// ```
///
/// [`format_args!`]: core::format_args
/// [`format!`]: crate::format
#[stable(feature = "rust1", since = "1.0.0")]
pub fn format(args: Arguments<'_>) -> string::String {
    let capacity = args.estimated_capacity();
    let mut output = string::String::with_capacity(capacity);
    output.write_fmt(args).expect("a formatting trait implementation returned an error");
    output
}