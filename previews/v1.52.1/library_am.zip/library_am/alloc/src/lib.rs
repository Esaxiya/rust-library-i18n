//! # የ Rust ዋና ምደባ እና ስብስቦች ቤተ-መጽሐፍት
//!
//! ይህ ቤተ-መጽሐፍት በክብ የተመደቡ እሴቶችን ለማስተዳደር ዘመናዊ ጠቋሚዎችን እና ስብስቦችን ይሰጣል ፡፡
//!
//! ይህ ቤተ-መጽሐፍት ልክ እንደ ሊብኮር ሁሉ ይዘቶቹ በ [`std` crate](../std/index.html) ውስጥ እንደገና ስለተላኩ በመደበኛነት በቀጥታ ጥቅም ላይ መዋል አያስፈልገውም ፡፡
//! የ `#![no_std]` ባህሪን የሚጠቀሙ Crates ግን በተለምዶ በ `std` ላይ የተመረኮዘ አይሆንም ፣ ስለሆነም ይልቁን ይህንን crate ይጠቀማሉ።
//!
//! ## የታሰሩ እሴቶች
//!
//! የ [`Box`] ዓይነት ብልህ ጠቋሚ ዓይነት ነው።የ [`Box`] አንድ ባለቤት ብቻ ሊኖር ይችላል ፣ እና ባለቤቱ ክምር ላይ የሚኖረውን ይዘቱን ለመለወጥ መወሰን ይችላል።
//!
//! የ `Box` እሴት መጠን ከጠቋሚው ጋር ተመሳሳይ ስለሆነ ይህ አይነት በክሮች መካከል በብቃት ሊላክ ይችላል።
//! የዛፍ መሰል የውሂብ መዋቅሮች ብዙውን ጊዜ በሳጥኖች የተገነቡ ናቸው ምክንያቱም እያንዳንዱ መስቀለኛ መንገድ ብዙ ጊዜ አንድ ባለቤት ብቻ አለው ፣ ወላጁ ፡፡
//!
//! ## ማጣቀሻ የተቆጠሩ ጠቋሚዎች
//!
//! የ [`Rc`] አይነት ያልሆነ threadsafe ማጣቀሻ-ይቆጠራል የጠቋሚ አይነት ክር ውስጥ ትውስታ ማጋራት የታሰበ ነው.
//! የ [`Rc`] ጠቋሚ አንድ ዓይነት `T` ን ጠቅልሎ ለ‹`&T`›መዳረሻ ብቻ ይፈቅዳል ፣ የተጋራ ማጣቀሻ ፡፡
//!
//! ይህ አይነት በዘር የሚተላለፍ ተለዋዋጭነት (እንደ [`Box`] ን መጠቀም) ለትግበራ በጣም አስቸጋሪ በሚሆንበት ጊዜ ይህ አይነት ጠቃሚ ነው ፣ እና ብዙውን ጊዜ ሚውቴሽንን ለመፍቀድ ከ [`Cell`] ወይም [`RefCell`] ዓይነቶች ጋር ይጣመራል።
//!
//!
//! ## Atomically ማጣቀሻ የተቆጠሩ አመልካቾች
//!
//! የ [`Arc`] ዓይነት [`Rc`] አይነት ያለውን threadsafe እኩያ ነው.በውስጡ የያዘው ዓይነት `T` ሊጋራ የሚችል ካልሆነ በስተቀር ሁሉንም የ [`Rc`] ተመሳሳይ ተግባራትን ይሰጣል።
//! በተጨማሪም ፣ [`Arc<T>`][`Arc`] ራሱ ሊላክ የሚችል ሲሆን [`Rc<T>`][`Rc`] ግን የማይላክ ነው ፡፡
//!
//! ይህ አይነት ለተያዘው ውሂብ የጋራ መዳረሻን ይፈቅድለታል ፣ እናም ብዙውን ጊዜ የተጋራ ሀብቶችን ሚውቴሽን ለመፍቀድ እንደ mutexes ካሉ ከማመሳሰል የመጀመሪያዎች ጋር ይጣመራል።
//!
//! ## Collections
//!
//! በጣም የተለመዱ የአጠቃላይ ዓላማ መረጃ መዋቅሮች ትግበራዎች በዚህ ቤተ-መጽሐፍት ውስጥ ተገልፀዋል ፡፡በ [standard collections library](../std/collections/index.html) በኩል እንደገና ወደ ውጭ ይላካሉ።
//!
//! ## ክምር በይነገጾች
//!
//! የ [`alloc`](alloc/index.html) ሞዱል ዝቅተኛ-ደረጃ በይነገጽን ወደ ነባሪው ዓለም አቀፋዊ አካል ይገልጻል።ከሊብክ አከፋፋይ ኤፒአይ ጋር ተኳሃኝ አይደለም።
//!
//! [`Arc`]: sync
//! [`Box`]: boxed
//! [`Cell`]: core::cell
//! [`Rc`]: rc
//! [`RefCell`]: core::cell
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(unused_attributes)]
#![stable(feature = "alloc", since = "1.36.0")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    html_playground_url = "https://play.rust-lang.org/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/",
    test(no_crate_inject, attr(allow(unused_variables), deny(warnings)))
)]
#![no_std]
#![needs_allocator]
#![warn(deprecated_in_future)]
#![warn(missing_docs)]
#![warn(missing_debug_implementations)]
#![allow(explicit_outlives_requirements)]
#![deny(unsafe_op_in_unsafe_fn)]
#![feature(rustc_allow_const_fn_unstable)]
#![cfg_attr(not(test), feature(generator_trait))]
#![cfg_attr(test, feature(test))]
#![cfg_attr(test, feature(new_uninit))]
#![feature(allocator_api)]
#![feature(vec_extend_from_within)]
#![feature(array_chunks)]
#![feature(array_methods)]
#![feature(array_windows)]
#![feature(allow_internal_unstable)]
#![feature(arbitrary_self_types)]
#![feature(async_stream)]
#![feature(box_patterns)]
#![feature(box_syntax)]
#![feature(cfg_sanitize)]
#![feature(cfg_target_has_atomic)]
#![feature(coerce_unsized)]
#![feature(const_btree_new)]
#![feature(const_fn)]
#![feature(cow_is_borrowed)]
#![feature(const_cow_is_borrowed)]
#![feature(destructuring_assignment)]
#![feature(dispatch_from_dyn)]
#![feature(core_intrinsics)]
#![feature(dropck_eyepatch)]
#![feature(exact_size_is_empty)]
#![feature(exclusive_range_pattern)]
#![feature(extend_one)]
#![feature(fmt_internals)]
#![feature(fn_traits)]
#![feature(fundamental)]
#![feature(inplace_iteration)]
#![feature(int_bits_const)]
// በቴክኒካዊ, በዚህ rustdoc ውስጥ አንድ ሳንካ ነው: rustdoc ደግሞ `core` ውስጥ ይህን ባህሪ በመጠቀም ሰነድ ያለው `&[T]`, ነው `#[lang = slice_alloc]` ብሎኮች ላይ ያለውን ሰነድ ይመለከታል, እና ባህሪ-በር አልነቃም መሆኑን እብድ ያገኛል.
// በሐሳብ ደረጃ ፣ ከሌላ crates ለሚመጡ ሰነዶች የባህሪይ በርን አይፈትሽም ፣ ግን ይህ ለሎንግ ዕቃዎች ብቻ ሊታይ ስለሚችል ፣ እሱን ማስተካከል ዋጋ ያለው አይመስልም።
//
//
#![feature(intra_doc_pointers)]
#![feature(lang_items)]
#![feature(layout_for_ptr)]
#![feature(maybe_uninit_ref)]
#![feature(negative_impls)]
#![feature(never_type)]
#![feature(nll)]
#![feature(nonnull_slice_from_raw_parts)]
#![feature(auto_traits)]
#![feature(option_result_unwrap_unchecked)]
#![feature(or_patterns)]
#![feature(pattern)]
#![feature(ptr_internals)]
#![feature(rustc_attrs)]
#![feature(receiver_trait)]
#![feature(min_specialization)]
#![feature(set_ptr_value)]
#![feature(slice_ptr_get)]
#![feature(slice_ptr_len)]
#![feature(slice_range)]
#![feature(staged_api)]
#![feature(str_internals)]
#![feature(trusted_len)]
#![feature(unboxed_closures)]
#![feature(unicode_internals)]
#![cfg_attr(bootstrap, feature(unsafe_block_in_unsafe_fn))]
#![feature(unsize)]
#![feature(unsized_fn_params)]
#![feature(allocator_internals)]
#![feature(slice_partition_dedup)]
#![feature(maybe_uninit_extra, maybe_uninit_slice, maybe_uninit_uninit_array)]
#![feature(alloc_layout_extra)]
#![feature(trusted_random_access)]
#![feature(try_trait)]
#![cfg_attr(bootstrap, feature(type_alias_impl_trait))]
#![cfg_attr(not(bootstrap), feature(min_type_alias_impl_trait))]
#![feature(associated_type_bounds)]
#![feature(slice_group_by)]
#![feature(decl_macro)]
// ይህንን ቤተ-መጽሐፍት ለመሞከር ፍቀድ

#[cfg(test)]
#[macro_use]
extern crate std;
#[cfg(test)]
extern crate test;

// ሌሎች ሞጁሎች ከሚጠቀሙባቸው ውስጣዊ ማክሮዎች ጋር ሞጁል (ከሌሎች ሞጁሎች በፊት መካተት ያስፈልጋል) ፡፡
#[macro_use]
mod macros;

// ለአነስተኛ ደረጃ ምደባ ስልቶች የተሰጡ ክምርዎች

pub mod alloc;

// ከላይ ያሉትን ክምርዎች በመጠቀም ጥንታዊ ዓይነቶች

// በሙከራ cfg ውስጥ ሲገነቡ የሎንግ ንጥሎችን ማባዛትን ለማስቀረት ሞዱን ከ `boxed.rs` ሁኔታዊ በሆነ ሁኔታ መግለፅ ያስፈልግዎታል;ነገር ግን ኮድ `use boxed::Box;` መግለጫዎች እንዲኖሩት መፍቀድ ያስፈልጋል ፡፡
//
//
#[cfg(not(test))]
pub mod boxed;
#[cfg(test)]
mod boxed {
    pub use std::boxed::Box;
}
pub mod borrow;
pub mod collections;
pub mod fmt;
pub mod prelude;
pub mod raw_vec;
pub mod rc;
pub mod slice;
pub mod str;
pub mod string;
#[cfg(target_has_atomic = "ptr")]
pub mod sync;
#[cfg(target_has_atomic = "ptr")]
pub mod task;
#[cfg(test)]
mod tests;
pub mod vec;

#[doc(hidden)]
#[unstable(feature = "liballoc_internals", issue = "none", reason = "implementation detail")]
pub mod __export {
    pub use core::format_args;
}