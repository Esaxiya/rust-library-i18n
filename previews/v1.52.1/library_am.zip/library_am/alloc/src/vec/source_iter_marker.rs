use core::iter::{InPlaceIterable, SourceIter};
use core::mem::{self, ManuallyDrop};
use core::ptr::{self};

use super::{AsIntoIter, InPlaceDrop, SpecFromIter, SpecFromIterNested, Vec};

/// ምንጭ ድልድል ዳግም ሳለ ማለትም, አንድ Vec ወደ አንድ ለተደጋጋሚ መተላለፊያ ለመሰብሰብ Specialization ምልክት ማድረጊያ
/// የቧንቧ መስመርን በቦታው ማከናወን።
///
/// እንደገና ጥቅም ላይ የሚውለውን ድልድል ለመድረስ SourceIter ወላጅ trait አስፈላጊ ነው ፡፡
/// ግን ልዩነቱ ትክክለኛ መሆን በቂ አይደለም ፡፡
/// በ impl ላይ ተጨማሪ ወሰን ይመልከቱ.
#[rustc_unsafe_specialization_marker]
pub(super) trait SourceIterMarker: SourceIter<Source: AsIntoIter> {}

// የ std-ውስጣዊ SourceIter/InPlaceIterable traits የሚተገበረው በአዳፕተር ሰንሰለቶች ብቻ ነው <Adapter<Adapter<IntoIter>>> (ሁሉም core/std ባለቤትነት).
// በአዳፕተሩ አተገባበር ላይ ተጨማሪ ገደቦች (ከ `impl<I: Trait> Trait for Adapter<I>` በላይ) ቀድሞውኑ እንደ ልዩ traits ምልክት በተደረገባቸው ሌሎች traits ላይ ብቻ የተመካ ነው (ቅጅ ፣ የታመነRandomAccess ፣ የተቀናጀ አስተላላፊ)።
//
// I.e. ምልክት ማድረጊያውን በተጠቃሚ-የቀረበው አይነቶች ዕድሜ ላይ የተመካ አይደለም.ሌሎች በርካታ ልዩ ሙያተኞች ቀድሞውኑ የሚመረኮዙበትን የቅጅ ቀዳዳውን ሞዱሎ ያድርጉ ፡፡
//
//
impl<T> SourceIterMarker for T where T: SourceIter<Source: AsIntoIter> + InPlaceIterable {}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T> + SourceIterMarker,
{
    default fn from_iter(mut iterator: I) -> Self {
        // በ trait bounds በኩል ሊገለጹ የማይችሉ ተጨማሪ መስፈርቶች።በምትኩ በኮሌ ኢቫል ላይ እንመካለን
        // ሀ) ምንም ZSTs እንደገና ጥቅም ላይ ለማዋል እና ጠቋሚ ሂሳብ ስለሌለ panic ለ) የመጠን ግጥሚያ በአሎሎ ኮንትራት ሐ) በአሎሎ ኮንትራት በሚፈለገው መሠረት ማመጣጠን
        //
        //
        //
        if mem::size_of::<T>() == 0
            || mem::size_of::<T>()
                != mem::size_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
            || mem::align_of::<T>()
                != mem::align_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
        {
            // ወደ አጠቃላይ አጠቃላይ አፈፃፀም መመለስ
            return SpecFromIterNested::from_iter(iterator);
        }

        let (src_buf, src_ptr, dst_buf, dst_end, cap) = unsafe {
            let inner = iterator.as_inner().as_into_iter();
            (
                inner.buf.as_ptr(),
                inner.ptr,
                inner.buf.as_ptr() as *mut T,
                inner.end as *const T,
                inner.cap,
            )
        };

        // ከዚያን ጊዜ ጀምሮ ይሞክሩ-እጥፍ ይጠቀሙ
        // - ለአንዳንድ ተስተካካይ አስማሚዎች በተሻለ ሁኔታ ቬክተሮችን ይሰጣል
        // - ከአብዛኛዎቹ የውስጥ ድግግሞሽ ዘዴዎች በተለየ የ &mut ራስን ብቻ ይወስዳል
        // - የጽሑፍ ጠቋሚውን በውስጠኛው በኩል እንድናስረው እና በመጨረሻው እንድመለስ ያደርገናል
        let sink = InPlaceDrop { inner: dst_buf, dst: dst_buf };
        let sink = iterator
            .try_fold::<_, _, Result<_, !>>(sink, write_in_place_with_drop(dst_end))
            .unwrap();
        // ድግግሞሽ ተሳክቷል ፣ ራስዎን አይጣሉ
        let dst = ManuallyDrop::new(sink).dst;

        let src = unsafe { iterator.as_inner().as_into_iter() };
        // SourceIter ኮንትራቱ የተደገፈ መሆኑን ያረጋግጡ ፤ ባይሆኑ ኖሮ እስከዚህ ደረጃ ላይደርስ አንችልም
        //
        debug_assert_eq!(src_buf, src.buf.as_ptr());
        // ያረጋግጡ InPlaceIterable ውል.የ ለተደጋጋሚ ሁሉንም ምንጭ ጠቋሚ የላቁ ከሆነ ይህ ብቻ ሊሆን ነው.
        // በ TrustedRandomAccess በኩል ያልተመረመረ መዳረሻን የሚጠቀም ከሆነ የምንጭ ጠቋሚው በመነሻ ቦታው ውስጥ ይቆየና እንደ ማጣቀሻ ልንጠቀምበት አንችልም ፡፡
        //
        if src.ptr != src_ptr {
            debug_assert!(
                dst as *const _ <= src.ptr,
                "InPlaceIterable contract violation, write pointer advanced beyond read pointer"
            );
        }

        // ምንጭ ያለውን ጭራ ላይ ማንኛውም ቀሪ እሴቶች መጣል ግን IntoIter ወሰን ውጭ ይሄዳል አንዴ ጠብታ panics ከዚያም እኛ ደግሞ dst_buf ወደ የተሰበሰበ ማንኛውም ንጥረ አያሳልፍም ከሆነ ድልድል በራሱ ጠብታ ለመከላከል
        //
        //
        src.forget_allocation_drop_remaining();

        let vec = unsafe {
            let len = dst.offset_from(dst_buf) as usize;
            Vec::from_raw_parts(dst_buf, len, cap)
        };

        vec
    }
}

fn write_in_place_with_drop<T>(
    src_end: *const T,
) -> impl FnMut(InPlaceDrop<T>, T) -> Result<InPlaceDrop<T>, !> {
    move |mut sink, item| {
        unsafe {
            // የ‹InPlaceIterable›ውል እዚህ በትክክል በትክክል ሊረጋገጥ አይችልም ፣ ምክንያቱም try_fold የምንጭ ጠቋሚውን ብቸኛ ማጣቀሻ ስላለው እኛ ማድረግ የምንችለው አሁንም ቢሆን በክልል ውስጥ መሆኑን ማረጋገጥ ነው ፡፡
            //
            //
            debug_assert!(sink.dst as *const _ <= src_end, "InPlaceIterable contract violation");
            ptr::write(sink.dst, item);
            sink.dst = sink.dst.add(1);
        }
        Ok(sink)
    }
}