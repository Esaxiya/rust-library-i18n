//! `Vec<T>` በጽሑፍ ክምር-የተመደበ ይዘቶችን ጋር አንድ contiguous growable የድርድር አይነት,.
//!
//! Vectors የ `O(1)` መረጃ ጠቋሚ ፣ በአሞራ የተቀናበረ የ `O(1)` ግፊት (እስከ መጨረሻ) እና የ `O(1)` ፖፕ (ከመጨረሻው) አላቸው ፡፡
//!
//!
//! Vectors እነርሱ ይበልጥ `isize::MAX` ባይቶች በላይ ለመመደብ ፈጽሞ ያረጋግጡ.
//!
//! # Examples
//!
//! በ [`Vec::new`] በግልፅ [`Vec`] ን መፍጠር ይችላሉ-
//!
//! ```
//! let v: Vec<i32> = Vec::new();
//! ```
//!
//! ... ወይም የ [`vec!`] ማክሮን በመጠቀም
//!
//! ```
//! let v: Vec<i32> = vec![];
//!
//! let v = vec![1, 2, 3, 4, 5];
//!
//! let v = vec![0; 10]; // አስር ዜሮዎች
//! ```
//!
//! [`push`] እሴቶችን በ vector መጨረሻ ላይ (እንደ አስፈላጊነቱ vector ን ያሳድጋል) ፡፡
//!
//! ```
//! let mut v = vec![1, 2];
//!
//! v.push(3);
//! ```
//!
//! ብቅ ያሉ እሴቶች በተመሳሳይ መንገድ በተመሳሳይ መንገድ ይሰራሉ
//!
//! ```
//! let mut v = vec![1, 2];
//!
//! let two = v.pop();
//! ```
//!
//! Vectors እንዲሁ ማውጫውን ይደግፋል (በ [`Index`] እና [`IndexMut`] traits በኩል)
//!
//! ```
//! let mut v = vec![1, 2, 3];
//! let three = v[2];
//! v[1] = v[1] + 5;
//! ```
//!
//! [`push`]: Vec::push
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::cmp::{self, Ordering};
use core::convert::TryFrom;
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::{arith_offset, assume};
use core::iter::FromIterator;
use core::marker::PhantomData;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::{self, Index, IndexMut, Range, RangeBounds};
use core::ptr::{self, NonNull};
use core::slice::{self, SliceIndex};

use crate::alloc::{Allocator, Global};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::collections::TryReserveError;
use crate::raw_vec::RawVec;

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
pub use self::drain_filter::DrainFilter;

mod drain_filter;

#[stable(feature = "vec_splice", since = "1.21.0")]
pub use self::splice::Splice;

mod splice;

#[stable(feature = "drain", since = "1.6.0")]
pub use self::drain::Drain;

mod drain;

mod cow;

pub(crate) use self::into_iter::AsIntoIter;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::into_iter::IntoIter;

mod into_iter;

use self::is_zero::IsZero;

mod is_zero;

mod source_iter_marker;

mod partial_eq;

use self::spec_from_elem::SpecFromElem;

mod spec_from_elem;

use self::set_len_on_drop::SetLenOnDrop;

mod set_len_on_drop;

use self::in_place_drop::InPlaceDrop;

mod in_place_drop;

use self::spec_from_iter_nested::SpecFromIterNested;

mod spec_from_iter_nested;

use self::spec_from_iter::SpecFromIter;

mod spec_from_iter;

use self::spec_extend::SpecExtend;

mod spec_extend;

/// እንደ `Vec<T>` ተብሎ የተጻፈ እና 'vector' ተብሎ የሚጠራ ተዛማጅ የሚያድግ ድርድር ዓይነት።
///
/// # Examples
///
/// ```
/// let mut vec = Vec::new();
/// vec.push(1);
/// vec.push(2);
///
/// assert_eq!(vec.len(), 2);
/// assert_eq!(vec[0], 1);
///
/// assert_eq!(vec.pop(), Some(2));
/// assert_eq!(vec.len(), 1);
///
/// vec[0] = 7;
/// assert_eq!(vec[0], 7);
///
/// vec.extend([1, 2, 3].iter().copied());
///
/// for x in &vec {
///     println!("{}", x);
/// }
/// assert_eq!(vec, [7, 1, 2, 3]);
/// ```
///
/// ጅምርን የበለጠ አመቺ ለማድረግ የ [`vec!`] ማክሮ ቀርቧል
///
/// ```
/// let mut vec = vec![1, 2, 3];
/// vec.push(4);
/// assert_eq!(vec, [1, 2, 3, 4]);
/// ```
///
/// እንዲሁም የ `Vec<T>` ን እያንዳንዱን ንጥረ ነገር ከተሰጠው እሴት ጋር ማስጀመር ይችላል።
/// ይህ በተለየ ደረጃዎች ምደባን እና ጅምርን ከማከናወን የበለጠ ውጤታማ ሊሆን ይችላል ፣ በተለይም ዜሮዎችን vector ሲጀምሩ-
///
/// ```
/// let vec = vec![0; 5];
/// assert_eq!(vec, [0, 0, 0, 0, 0]);
///
/// // የሚከተለው እኩል ነው ፣ ግን ቀርፋፋ ሊሆን ይችላል
/// let mut vec = Vec::with_capacity(5);
/// vec.resize(5, 0);
/// assert_eq!(vec, [0, 0, 0, 0, 0]);
/// ```
///
/// ለተጨማሪ መረጃ [Capacity and Reallocation](#capacity-and-reallocation) ን ይመልከቱ ፡፡
///
/// እንደ ውጤታማ ቁልል `Vec<T>` ይጠቀሙ
///
/// ```
/// let mut stack = Vec::new();
///
/// stack.push(1);
/// stack.push(2);
/// stack.push(3);
///
/// while let Some(top) = stack.pop() {
///     // ህትመቶች 3, 2, 1
///     println!("{}", top);
/// }
/// ```
///
/// # Indexing
///
/// የ `Vec` አይነት በመረጃ ጠቋሚ እሴቶችን ለመድረስ ያስችለዋል ፣ ምክንያቱም [`Index`] trait ን ይተገብራል።አንድ ምሳሌ የበለጠ ግልጽ ይሆናል-
///
/// ```
/// let v = vec![0, 2, 4, 6];
/// println!("{}", v[1]); // '2' ን ያሳያል
/// ```
///
/// ሆኖም ይጠንቀቁ በ `Vec` ውስጥ የሌለውን መረጃ ጠቋሚ ለመድረስ ከሞከሩ የእርስዎ ሶፍትዌር panic ን ያደርገዋል!ይህንን ማድረግ አይችሉም
///
/// ```should_panic
/// let v = vec![0, 2, 4, 6];
/// println!("{}", v[6]); // it will panic!
/// ```
///
/// መረጃ ጠቋሚው በ `Vec` ውስጥ መሆኑን ለመመርመር ከፈለጉ [`get`] እና [`get_mut`] ን ይጠቀሙ።
///
/// # Slicing
///
/// አንድ `Vec` ሊቀየሩ ሊሆን ይችላል.በሌላ በኩል ደግሞ ቁርጥራጭ ንባብ-ብቻ የሆኑ ነገሮች ናቸው ፡፡
/// አንድ [slice][prim@slice] ለማግኘት, [`&`] ይጠቀሙ.ለምሳሌ:
///
/// ```
/// fn read_slice(slice: &[usize]) {
///     // ...
/// }
///
/// let v = vec![0, 1];
/// read_slice(&v);
///
/// // ... እና ያ ብቻ ነው!
/// // እንዲሁም እንደዚህ ማድረግ ይችላሉ-
/// let u: &[usize] = &v;
/// // ወይም እንደዚህ
/// let u: &[_] = &v;
/// ```
///
/// በ Rust ውስጥ የንባብ ተደራሽነት ለማቅረብ ሲፈልጉ ከ vectors ይልቅ ቁርጥራጮችን እንደ ክርክር ማለፍ በጣም የተለመደ ነው ፡፡ለ [`String`] እና [`&str`] ተመሳሳይ ነው።
///
/// # አቅም እና ሪልላይዜሽን
///
/// የ vector አቅም በ vector ላይ የሚጨመሩ ለማንኛውም የ future አካላት የሚመደበው የቦታ መጠን ነው።ይህ በ vector ውስጥ የእውነተኛ ንጥረ ነገሮችን ብዛት ከሚገልጽ የ vector *ርዝመት* ጋር ግራ መጋባት የለበትም።
/// የ vector ርዝመት ከአቅሙ በላይ ከሆነ አቅሙ በራስ-ሰር ይጨምራል ፣ ነገር ግን ንጥረ ነገሮቹን እንደገና መመደብ አለባቸው።
///
/// ለምሳሌ ፣ አቅም 10 እና ርዝመት 0 ያለው vector ለ 10 ተጨማሪ አካላት ቦታ ባዶ vector ይሆናል።10 ወይም ያነሱ አባሎችን በ vector ላይ መግፋት አቅሙን አይለውጠውም ወይም ዳግም ምደባ እንዲከሰት አያደርግም ፡፡
/// ሆኖም ፣ የ vector ርዝመት ወደ 11 ከፍ ከተደረገ ፣ ዘገምተኛ ሊሆን የሚችል እንደገና መመደብ ይኖርበታል።በዚህ ምክንያት ፣ vector ምን ያህል መጠን እንደሚጠበቅ ለመጥቀስ በሚቻልበት ጊዜ ሁሉ [`Vec::with_capacity`] ን እንዲጠቀሙ ይመከራል ፡፡
///
/// # Guarantees
///
/// በሚያስደንቅ መሠረታዊ ተፈጥሮው ምክንያት `Vec` ስለ ዲዛይኑ ብዙ ዋስትናዎችን ይሰጣል ፡፡ይህ በአጠቃላይ ሁኔታ ውስጥ በተቻለ መጠን ዝቅተኛ-የላይኛው ክፍል መሆኑን ያረጋግጣል ፣ እና በጥንታዊ መንገዶች ደህንነቱ ባልተጠበቀ ኮድ በትክክል ሊሠራ ይችላል ፡፡እነዚህ ዋስትና የአውራዎቹ `Vec<T>` የሚያመለክት መሆኑን ልብ ይበሉ.
/// ተጨማሪ የአይነት መለኪያዎች ከተጨመሩ (ለምሳሌ ፣ ብጁ ሰጭዎችን ለመደገፍ) ፣ ነባሮቻቸውን መተላለፍ ባህሪያቱን ሊለውጠው ይችላል።
///
/// በመሰረታዊነት ፣ `Vec` (ጠቋሚ ፣ አቅም ፣ ርዝመት) ሶስት እጥፍ ነው እና ሁል ጊዜም ይሆናል።አይበልጥም ፣ አይያንስም ፡፡የእነዚህ መስኮች ቅደም ተከተል ሙሉ በሙሉ አልተገለጸም ፣ እና እነዚህን ለማሻሻል ተገቢውን ዘዴዎችን መጠቀም አለብዎት።
/// ጠቋሚው በጭራሽ ዋጋ ቢስ አይሆንም ፣ ስለዚህ ይህ ዓይነቱ ባዶ-ጠቋሚ-የተመቻቸ ነው።
///
/// ሆኖም ጠቋሚው በእውነቱ ለተመደበ ማህደረ ትውስታ ላይጠቆም ይችላል ፡፡
/// በተለይም [`Vec::new`] ፣ [`vec![]`][`vec!`] ፣ [`Vec::with_capacity(0)`][`Vec::with_capacity`] ፣ ወይም [`shrink_to_fit`] ን ባዶ Vec ላይ በመደወል አቅም 0 ያለው `Vec` ን ከገነቡ ማህደረ ትውስታን አይመድበውም ፡፡በተመሳሳይ ፣ በ‹`Vec`›ውስጥ ዜሮ-መጠን ዓይነቶችን ካከማቹ ለእነሱ ቦታ አይመድባቸውም ፡፡
/// *ልብ ይበሉ በዚህ ጉዳይ ላይ `Vec` የ [`capacity`] ን ከ 0* ሪፖርት ሊያደርግ አይችልም ፡፡
/// `Vec` ከሆነ ብቻ ነው [`ሜም: : size_of::ከሆነ ለመመደብ ይሆናል<T>"]() * capacity()> 0`.
/// በአጠቃላይ, `Vec` ዎቹ ምደባ ዝርዝሮች በጣም ስውር ናቸው-የ `Vec` በመጠቀም ትውስታ ለመመደብ ያሰብከው እና ሌላ ነገር መጠቀም ከሆነ (ወይ ያልተጠበቀ ኮድ ወደ ማለፍ, ወይም የራስዎን የማስታወስ በተደገፈ ስብስብ ለመገንባት), እርግጠኞች መሆን `Vec` ን መልሶ ለማግኘት እና ከዚያ በመጣል ይህንን ትውስታ በ `from_raw_parts` በመጠቀም ለማካፈል ፡፡
///
/// አንድ `Vec`* * የተመደበ ማህደረ ትውስታ ካለው ፣ ከዚያ የሚያመለክተው ማህደረ ትውስታ ክምር ላይ ነው (በአከፋፋዩ Rust እንደተገለጸው በነባሪ እንዲጠቀም ተዋቅሯል) ፣ እና ጠቋሚው ወደ [`len`] ነጥቦቹ ተጀምረዋል ፣ ተያያዥ ንጥረ ነገሮች በቅደም ተከተል (ምን እንደሚፈልጉ ወደ አንድ ቁራጭ ያስገደዱት እንደሆነ ይመልከቱ) ፣ በመቀጠል በ ``አቅም`] ፣`[`ሌን`] ሎጂካዊ ባልሆነ መንገድ ፣ ተያያዥ ንጥረ ነገሮች ፡፡
///
///
/// አቅም 4 ጋር ንጥረ `'a'` እና `'b'` የያዘ vector በታች እንደ ይቀመጥና ይችላል.የላይኛው ክፍል የ `Vec` መዋቅር ነው ፣ በክምችቱ ፣ በከፍታው እና በአቅሙ ውስጥ ወደ ምደባው ራስ ጠቋሚ ይ containsል።
/// የታችኛው ክፍል ክምር ላይ ምደባ ነው ፣ ተዛማጅ የማስታወሻ ማገጃ።
///
/// ```text
///             ptr      len  capacity
///        +--------+--------+--------+
///        | 0x0123 |      2 |      4 |
///        +--------+--------+--------+
///             |
///             v
/// Heap   +--------+--------+--------+--------+
///        |    'a' |    'b' | uninit | uninit |
///        +--------+--------+--------+--------+
/// ```
///
/// - **ማራገፍ** ያልተጀመረ ማህደረ ትውስታን ይወክላል ፣ [`MaybeUninit`] ን ይመልከቱ።
/// - Note: ኤቢአይ የተረጋጋ እና `Vec` ስለ ማህደረ ትውስታ አቀማመጥ (የመስኮችን ቅደም ተከተል ጨምሮ) ምንም ዋስትና አይሰጥም።
///
/// `Vec` ንጥረ ነገሮች በእውነቱ በሁለት ምክንያቶች ላይ በተከማቹበት ቦታ ላይ "small optimization" ን በጭራሽ አያከናውንም-
///
/// * `Vec` ን በትክክል ለማዛባት ደህንነቱ ያልተጠበቀ ኮድ የበለጠ አስቸጋሪ ያደርገዋል።የ `Vec` ይዘቶች ከተንቀሳቀሱ ብቻ የተረጋጋ አድራሻ አይኖራቸውም ፣ እናም `Vec` በእውነቱ ማህደረ ትውስታን መመደቡን ለመለየት የበለጠ ከባድ ነው።
///
/// * በእያንዳንዱ መዳረሻ ላይ ተጨማሪ branch ን በመክፈል አጠቃላይ ጉዳዩን ያስቀጣል።
///
/// `Vec` ሙሉ በሙሉ ባዶ ቢሆንም እንኳ በራሱ በራሱ በጭራሽ አይቀንስም።ይህ አላስፈላጊ ምደባዎች ወይም የዝውውር ክፍፍሎች እንዳይከሰቱ ያረጋግጣል።`Vec` ን ባዶ ማድረግ እና ከዚያ እስከዚያው [`len`] ድረስ መልሶ መሙላት ለአከፋፋዩ ምንም ጥሪ አያስከትልም።ጥቅም ላይ ያልዋለ ማህደረ ትውስታን ለማስለቀቅ ከፈለጉ [`shrink_to_fit`] ወይም [`shrink_to`] ን ይጠቀሙ።
///
/// [`push`] የተዘገበው አቅም በቂ ከሆነ እና [`insert`] በጭራሽ (ዳግመኛ) አይመደብም ፡፡[`push`] እና [`insert`]*[`len`]`==`[`አቅም`] ከሆነ*(ድጋሜ) ይመድባል ፡፡ማለትም ፣ የተዘገበው አቅም ሙሉ በሙሉ ትክክል ነው ፣ ሊታመንም ይችላል።ከተፈለገ በ `Vec` የተመደበውን ማህደረ ትውስታ በእጅ ለማስለቀቅ እንኳን ሊያገለግል ይችላል።
/// የጅምላ ማስገቢያ ዘዴዎች *አስፈላጊ ባይሆንም እንኳ* በትክክል ሊለዩ ይችላሉ።
///
/// `Vec` ሲሞላ እንደገና ሲለዋወጥ ወይም [`reserve`] ሲጠራ የተለየ የዕድገት ስትራቴጂን አያረጋግጥም ፡፡የወቅቱ ስትራቴጂ መሰረታዊ ነው እናም የማያቋርጥ የእድገት ሁኔታን ለመጠቀም ተመራጭ ሊሆን ይችላል።የትኛውም ስትራቴጂ ጥቅም ላይ እንደዋለ በእርግጥ *O*(1) የተቀናበረ [`push`] ዋስትና ይሰጣል ፡፡
///
/// `vec![x; n]`, `vec![a, b, c, d]` እና [`Vec::with_capacity(n)`][`Vec::with_capacity`] ሁሉም በትክክል በተጠየቀው አቅም `Vec` ን ያመርታሉ ፡፡
/// ከሆነ [`len`]`==`[`አቅም`]] ፣ (ለ [`vec!`] ማክሮ ሁኔታው ከሆነ) ፣ ከዚያ ኤክስ 01X ን ንጥረ ነገሮችን ሳይለዋወጥ ወይም ሳይያንቀሳቅስ ወደ እና ወደ [`Box<[T]>`][owned slice] ሊቀየር ይችላል።
///
/// `Vec` በተለይ በተለይም ጠብቆ አይችልም ደግሞ ይወገዳሉ, ነገር ግን ማንኛውም ውሂብ ተክቶ አይችልም.ያልታሰበበት ማህደረ ትውስታ የፈለገውን ሊጠቀምበት የሚችል የጭረት ቦታ ነው ፡፡ይህም በአጠቃላይ ብቻ በጣም ቀልጣፋ ወይም በሌላ ቀላል ለመተግበር ነው ሁሉ አደርጋለሁ.ለደህንነት ሲባል እንዲሰረዝ በተወገደው መረጃ ላይ አይመኑ ፡፡
/// ምንም እንኳን `Vec` ን ቢጥሉም እንኳ የእሱ ቋት በሌላ `Vec` እንደገና ጥቅም ላይ ሊውል ይችላል።
/// ምንም እንኳን በመጀመሪያ የ‹ቬክ›ማህደረ ትውስታን በዜሮ ቢያስቀምጡም ይህ በእውነቱ ላይሆን ይችላል ምክንያቱም አመቻቹ ይህን መጠበቅ አለበት የጎንዮሽ ጉዳትን አይመለከትም ፡፡
/// ሆኖም እኛ የማናፈርስበት አንድ ጉዳይ አለ-የ `unsafe` ኮድ በመጠቀም ከመጠን በላይ አቅም ለመፃፍ እና ከዚያ ለማዛመድ ርዝመቱን መጨመር ሁልጊዜ ትክክለኛ ነው ፡፡
///
/// በአሁኑ ጊዜ ኤክስኤክስኤክስ አባሎች የወደቁበትን ቅደም ተከተል ዋስትና አይሰጥም ፡፡
/// ትዕዛዙ ቀደም ሲል ተለውጧል እና እንደገና ሊለወጥ ይችላል።
///
/// [`get`]: ../../std/vec/struct.Vec.html#method.get
/// [`get_mut`]: ../../std/vec/struct.Vec.html#method.get_mut
/// [`String`]: crate::string::String
/// [`&str`]: type@str
/// [`shrink_to_fit`]: Vec::shrink_to_fit
/// [`shrink_to`]: Vec::shrink_to
/// [`capacity`]: Vec::capacity
/// [`mem::size_of::<T>`]: core::mem::size_of
/// [`len`]: Vec::len
/// [`push`]: Vec::push
/// [`insert`]: Vec::insert
/// [`reserve`]: Vec::reserve
/// [`MaybeUninit`]: core::mem::MaybeUninit
/// [owned slice]: Box
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "vec_type")]
pub struct Vec<T, #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global> {
    buf: RawVec<T, A>,
    len: usize,
}

////////////////////////////////////////////////////////////////////////////////
// ተፈጥሮአዊ ዘዴዎች
////////////////////////////////////////////////////////////////////////////////

impl<T> Vec<T> {
    /// አዲስ ፣ ባዶ `Vec<T>` ን ይገነባል።
    ///
    /// ንጥረ ነገሮች በእሱ ላይ እስኪገፉ ድረስ vector አይመደብም ፡፡
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(unused_mut)]
    /// let mut vec: Vec<i32> = Vec::new();
    /// ```
    #[inline]
    #[rustc_const_stable(feature = "const_vec_new", since = "1.39.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> Self {
        Vec { buf: RawVec::NEW, len: 0 }
    }

    /// ከተጠቀሰው አቅም ጋር አዲስ ፣ ባዶ `Vec<T>` ን ይገነባል።
    ///
    /// የ vector reallocating ያለ በትክክል `capacity` አባሎችን መያዝ አይችሉም.
    /// `capacity` 0 ከሆነ vector አይመደብም።
    ///
    /// የተመለሰው vector የተገለጸው *አቅም* ቢኖረውም ፣ vector ዜሮ *ርዝመት* እንደሚኖረው መገንዘብ አስፈላጊ ነው ፡፡
    ///
    /// በርዝመት እና በአቅም መካከል ስላለው ልዩነት ማብራሪያ ፣*[አቅም እና መልሶ ማቋቋም]* ን ይመልከቱ።
    ///
    /// [Capacity and reallocation]: #capacity-and-reallocation
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    ///
    /// // ምንም እንኳን ለተጨማሪ አቅም ቢኖረውም vector ምንም እቃዎችን አልያዘም
    /// assert_eq!(vec.len(), 0);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // እነዚህ ሁሉ ሳይለወጡ ይከናወናሉ ...
    /// for i in 0..10 {
    ///     vec.push(i);
    /// }
    /// assert_eq!(vec.len(), 10);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // ... ግን ይህ vector ን እንደገና እንዲለዋወጥ ሊያደርግ ይችላል
    /// vec.push(11);
    /// assert_eq!(vec.len(), 11);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    #[inline]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// ሌላ vector ያለውን ጥሬ ክፍሎች በቀጥታ `Vec<T>` ይፈጥራል.
    ///
    /// # Safety
    ///
    /// በዚህ ምክንያት የተደረገባቸው አይደሉም invariants ብዛት, በከፍተኛ አደገኛ ነው:
    ///
    /// * `ptr` ከዚህ በፊት በ [`String`]/`Vec`በኩል መመደብ ያስፈልጋል<T>(ቢያንስ ካልሆነ በጣም የተሳሳተ የመሆን እድሉ ሰፊ ነው) ፡፡
    /// * `T` `ptr` ከተመደበው ጋር ተመሳሳይ መጠን እና አሰላለፍ ሊኖረው ይገባል።
    ///   (`T` ያነሰ ጥብቅ አሰላለፍ ያለው መሆኑ በቂ አይደለም ፣ ማህደሩ ከተመሳሳዩ አቀማመጥ ጋር መመደብ እና መመደብ አለበት የሚለውን የ [`dealloc`] መስፈርት ለማሟላት አሰላለፍ በእውነቱ እኩል መሆን አለበት።)
    ///
    /// * `length` ከ `capacity` በታች ወይም እኩል መሆን አለበት።
    /// * `capacity` ጠቋሚው የተመደበለት አቅም መሆን አለበት ፡፡
    ///
    /// እነዚህን መጣስ የአከፋፋዩን ውስጣዊ የመረጃ አወቃቀሮችን እንደ ማበላሸት ያሉ ችግሮችን ሊያስከትል ይችላል ፡፡ለምሳሌ `Vec<u8>` ን ከጠቋሚ ወደ ሲ `char` ድርድር ከ `size_t` ጋር ለመገንባት **ደህንነቱ የተጠበቀ** አይደለም ፡፡
    /// እንዲሁም አንድ ከ‹XXXX›እና ከርዝመቱ መገንባት ደህና አይደለም ፣ ምክንያቱም አከፋፋዩ ስለ አሰላለፍ ግድ ስለሚል እና እነዚህ ሁለት ዓይነቶች የተለያዩ አሰላለፎች አሏቸው ፡፡
    /// ቋት 2 (ለ `u16`) አሰላለፍ ተመድቧል ፣ ግን ወደ‹`Vec<u8>` X›ከተቀየረ በኋላ በአቀማመጥ 1 ይመደባል ፡፡
    ///
    /// የ‹`ptr` X›ባለቤትነት በብቃት ወደ `Vec<T>` ይተላለፋል ፣ ከዚያ ጠቋሚው በፈለገው የጠቆመውን የማህደረ ትውስታ ይዘቶች ሊያዛውር ፣ መልሶ ሊለዋወጥ ወይም ሊቀይር ይችላል።
    /// ይህንን ተግባር ከጠራ በኋላ ጠቋሚውን ሌላ ምንም ነገር እንደማይጠቀም ያረጋግጡ ፡፡
    ///
    /// [`String`]: crate::string::String
    /// [`dealloc`]: crate::alloc::GlobalAlloc::dealloc
    ///
    /// # Examples
    ///
    /// ```
    /// use std::ptr;
    /// use std::mem;
    ///
    /// let v = vec![1, 2, 3];
    ///
    ///     // FIXME vec_into_raw_parts ሲረጋጋ ይህንን ያዘምኑ።
    ///     // የ `v` አጥፊን ማስኬድን ይከላከሉ ስለዚህ እኛ የምደባውን ሙሉ በሙሉ እየተቆጣጠርን ነን ፡፡
    /////
    /// let mut v = mem::ManuallyDrop::new(v);
    ///
    /// // ስለ `v` የተለያዩ አስፈላጊ መረጃዎችን ይሳቡ
    /// let p = v.as_mut_ptr();
    /// let len = v.len();
    /// let cap = v.capacity();
    ///
    /// unsafe {
    ///     // ማህደረ ትውስታን በ 4, 5, 6 ላይ ይፃፉ
    ///     for i in 0..len as isize {
    ///         ptr::write(p.offset(i), 4 + i);
    ///     }
    ///
    ///     // ሁሉንም ነገር በአንድ ላይ ወደ ቬክ ያኑሩ
    ///     let rebuilt = Vec::from_raw_parts(p, len, cap);
    ///     assert_eq!(rebuilt, [4, 5, 6]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_raw_parts(ptr: *mut T, length: usize, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, length, capacity, Global) }
    }
}

impl<T, A: Allocator> Vec<T, A> {
    /// አዲስ Constructs, `Vec<T, A>` ባዶ.
    ///
    /// ንጥረ ነገሮች በእሱ ላይ እስኪገፉ ድረስ vector አይመደብም ፡፡
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// # #[allow(unused_mut)]
    /// let mut vec: Vec<i32, _> = Vec::new_in(System);
    /// ```
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub const fn new_in(alloc: A) -> Self {
        Vec { buf: RawVec::new_in(alloc), len: 0 }
    }

    /// ከቀረበው አከፋፋይ ጋር በተጠቀሰው አቅም አዲስ ፣ ባዶ `Vec<T, A>` ን ይገነባል።
    ///
    /// የ vector reallocating ያለ በትክክል `capacity` አባሎችን መያዝ አይችሉም.
    /// `capacity` 0 ከሆነ vector አይመደብም።
    ///
    /// የተመለሰው vector የተገለጸው *አቅም* ቢኖረውም ፣ vector ዜሮ *ርዝመት* እንደሚኖረው መገንዘብ አስፈላጊ ነው ፡፡
    ///
    /// በርዝመት እና በአቅም መካከል ስላለው ልዩነት ማብራሪያ ፣*[አቅም እና መልሶ ማቋቋም]* ን ይመልከቱ።
    ///
    /// [Capacity and reallocation]: #capacity-and-reallocation
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut vec = Vec::with_capacity_in(10, System);
    ///
    /// // ምንም እንኳን ለተጨማሪ አቅም ቢኖረውም vector ምንም እቃዎችን አልያዘም
    /// assert_eq!(vec.len(), 0);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // እነዚህ ሁሉ ሳይለወጡ ይከናወናሉ ...
    /// for i in 0..10 {
    ///     vec.push(i);
    /// }
    /// assert_eq!(vec.len(), 10);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // ... ግን ይህ vector ን እንደገና እንዲለዋወጥ ሊያደርግ ይችላል
    /// vec.push(11);
    /// assert_eq!(vec.len(), 11);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Vec { buf: RawVec::with_capacity_in(capacity, alloc), len: 0 }
    }

    /// ከሌላ vector ጥሬ ዕቃዎች በቀጥታ `Vec<T, A>` ን ይፈጥራል።
    ///
    /// # Safety
    ///
    /// በዚህ ምክንያት የተደረገባቸው አይደሉም invariants ብዛት, በከፍተኛ አደገኛ ነው:
    ///
    /// * `ptr` ከዚህ በፊት በ [`String`]/`Vec`በኩል መመደብ ያስፈልጋል<T>(ቢያንስ ካልሆነ በጣም የተሳሳተ የመሆን እድሉ ሰፊ ነው) ፡፡
    /// * `T` `ptr` ከተመደበው ጋር ተመሳሳይ መጠን እና አሰላለፍ ሊኖረው ይገባል።
    ///   (`T` ያነሰ ጥብቅ አሰላለፍ ያለው መሆኑ በቂ አይደለም ፣ ማህደሩ ከተመሳሳዩ አቀማመጥ ጋር መመደብ እና መመደብ አለበት የሚለውን የ [`dealloc`] መስፈርት ለማሟላት አሰላለፍ በእውነቱ እኩል መሆን አለበት።)
    ///
    /// * `length` ከ `capacity` በታች ወይም እኩል መሆን አለበት።
    /// * `capacity` ጠቋሚው የተመደበለት አቅም መሆን አለበት ፡፡
    ///
    /// እነዚህን መጣስ የአከፋፋዩን ውስጣዊ የመረጃ አወቃቀሮችን እንደ ማበላሸት ያሉ ችግሮችን ሊያስከትል ይችላል ፡፡ለምሳሌ `Vec<u8>` ን ከጠቋሚ ወደ ሲ `char` ድርድር ከ `size_t` ጋር ለመገንባት **ደህንነቱ የተጠበቀ** አይደለም ፡፡
    /// እንዲሁም አንድ ከ‹XXXX›እና ከርዝመቱ መገንባት ደህና አይደለም ፣ ምክንያቱም አከፋፋዩ ስለ አሰላለፍ ግድ ስለሚል እና እነዚህ ሁለት ዓይነቶች የተለያዩ አሰላለፎች አሏቸው ፡፡
    /// ቋት 2 (ለ `u16`) አሰላለፍ ተመድቧል ፣ ግን ወደ‹`Vec<u8>` X›ከተቀየረ በኋላ በአቀማመጥ 1 ይመደባል ፡፡
    ///
    /// የ‹`ptr` X›ባለቤትነት በብቃት ወደ `Vec<T>` ይተላለፋል ፣ ከዚያ ጠቋሚው በፈለገው የጠቆመውን የማህደረ ትውስታ ይዘቶች ሊያዛውር ፣ መልሶ ሊለዋወጥ ወይም ሊቀይር ይችላል።
    /// ይህንን ተግባር ከጠራ በኋላ ጠቋሚውን ሌላ ምንም ነገር እንደማይጠቀም ያረጋግጡ ፡፡
    ///
    /// [`String`]: crate::string::String
    /// [`dealloc`]: crate::alloc::GlobalAlloc::dealloc
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// use std::ptr;
    /// use std::mem;
    ///
    /// let mut v = Vec::with_capacity_in(3, System);
    /// v.push(1);
    /// v.push(2);
    /// v.push(3);
    ///
    ///     // FIXME vec_into_raw_parts ሲረጋጋ ይህንን ያዘምኑ።
    ///     // የ `v` አጥፊን ማስኬድን ይከላከሉ ስለዚህ እኛ የምደባውን ሙሉ በሙሉ እየተቆጣጠርን ነን ፡፡
    /////
    /// let mut v = mem::ManuallyDrop::new(v);
    ///
    /// // ስለ `v` የተለያዩ አስፈላጊ መረጃዎችን ይሳቡ
    /// let p = v.as_mut_ptr();
    /// let len = v.len();
    /// let cap = v.capacity();
    /// let alloc = v.allocator();
    ///
    /// unsafe {
    ///     // ማህደረ ትውስታን በ 4, 5, 6 ላይ ይፃፉ
    ///     for i in 0..len as isize {
    ///         ptr::write(p.offset(i), 4 + i);
    ///     }
    ///
    ///     // ሁሉንም ነገር በአንድ ላይ ወደ ቬክ ያኑሩ
    ///     let rebuilt = Vec::from_raw_parts_in(p, len, cap, alloc.clone());
    ///     assert_eq!(rebuilt, [4, 5, 6]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, length: usize, capacity: usize, alloc: A) -> Self {
        unsafe { Vec { buf: RawVec::from_raw_parts_in(ptr, capacity, alloc), len: length } }
    }

    /// `Vec<T>` ን ወደ ጥሬ ዕቃዎቹ ያበላሽዋል።
    ///
    /// ጥሬ አመላካችውን ወደ መሰረታዊ መረጃ ፣ የ vector ርዝመት (በንጥሎች) እና የመረጃውን (በንጥሎች) የተመደበውን ይመልሳል።
    /// እነዚህ ከ [`from_raw_parts`] ጋር እንደ ክርክሮች በተመሳሳይ ቅደም ተከተል ተመሳሳይ ክርክሮች ናቸው ፡፡
    ///
    /// ደዋዩ ይህንን ተግባር ከጠራ በኋላ ቀደም ሲል በ `Vec` ለሚተዳደር ማህደረ ትውስታ ኃላፊነት አለበት ፡፡
    /// ይህንን ማድረግ የሚቻልበት ብቸኛው መንገድ ጥሬ ጠቋሚውን ፣ ርዝመቱን እና አቅሙን ወደ `Vec` በ [`from_raw_parts`] ተግባር መለወጥ ሲሆን አጥፊው ጽዳት እንዲያከናውን ያስችለዋል ፡፡
    ///
    ///
    /// [`from_raw_parts`]: Vec::from_raw_parts
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_into_raw_parts)]
    /// let v: Vec<i32> = vec![-1, 0, 1];
    ///
    /// let (ptr, len, cap) = v.into_raw_parts();
    ///
    /// let rebuilt = unsafe {
    ///     // ጥሬ ጠቋሚውን ወደ ተጓዳኝ ዓይነት ማስተላለፍን በመሳሰሉ አካላት ላይ አሁን ለውጦችን ማድረግ እንችላለን ፡፡
    /////
    ///     let ptr = ptr as *mut u32;
    ///
    ///     Vec::from_raw_parts(ptr, len, cap)
    /// };
    /// assert_eq!(rebuilt, [4294967295, 0, 1]);
    /// ```
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts(self) -> (*mut T, usize, usize) {
        let mut me = ManuallyDrop::new(self);
        (me.as_mut_ptr(), me.len(), me.capacity())
    }

    /// `Vec<T>` ን ወደ ጥሬ ዕቃዎቹ ያበላሽዋል።
    ///
    /// ጥሬ ጠቋሚውን ወደ መሰረታዊ መረጃ ፣ የ vector ርዝመት (በንጥሎች) ፣ የመረጃው የመመደብ አቅም (ንጥረ ነገሮች ውስጥ) እና አመድ ይመልሳል።
    /// እነዚህ [`from_raw_parts_in`] ወደ እሴቶች ተመሳሳይ ቅደም ተከተል ተመሳሳይ ነጋሪ እሴቶች ናቸው.
    ///
    /// ደዋዩ ይህንን ተግባር ከጠራ በኋላ ቀደም ሲል በ `Vec` ለሚተዳደር ማህደረ ትውስታ ኃላፊነት አለበት ፡፡
    /// ይህንን ማድረግ የሚቻልበት ብቸኛው መንገድ ጥሬ ጠቋሚውን ፣ ርዝመቱን እና አቅሙን ወደ `Vec` በ [`from_raw_parts_in`] ተግባር መለወጥ ሲሆን አጥፊው ጽዳት እንዲያከናውን ያስችለዋል ፡፡
    ///
    ///
    /// [`from_raw_parts_in`]: Vec::from_raw_parts_in
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, vec_into_raw_parts)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut v: Vec<i32, System> = Vec::new_in(System);
    /// v.push(-1);
    /// v.push(0);
    /// v.push(1);
    ///
    /// let (ptr, len, cap, alloc) = v.into_raw_parts_with_alloc();
    ///
    /// let rebuilt = unsafe {
    ///     // ጥሬ ጠቋሚውን ወደ ተጓዳኝ ዓይነት ማስተላለፍን በመሳሰሉ አካላት ላይ አሁን ለውጦችን ማድረግ እንችላለን ፡፡
    /////
    ///     let ptr = ptr as *mut u32;
    ///
    ///     Vec::from_raw_parts_in(ptr, len, cap, alloc)
    /// };
    /// assert_eq!(rebuilt, [4294967295, 0, 1]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts_with_alloc(self) -> (*mut T, usize, usize, A) {
        let mut me = ManuallyDrop::new(self);
        let len = me.len();
        let capacity = me.capacity();
        let ptr = me.as_mut_ptr();
        let alloc = unsafe { ptr::read(me.allocator()) };
        (ptr, len, capacity, alloc)
    }

    /// የ vector reallocating ያለ መያዝ ይችላል ንጥረ ብዛት ይመልሳል.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let vec: Vec<i32> = Vec::with_capacity(10);
    /// assert_eq!(vec.capacity(), 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.buf.capacity()
    }

    /// በተጠቀሰው `Vec<T>` ውስጥ ለማስገባት ቢያንስ ለ `additional` ተጨማሪ አካላት አቅም ይይዛል።
    /// ስብስቡ ተደጋጋሚ ሪከሎችን ለማስቀረት ተጨማሪ ቦታ ሊይዝ ይችላል።
    /// `reserve` ን ከጠራ በኋላ አቅም ከ `self.len() + additional` ይበልጣል ወይም እኩል ይሆናል።
    /// አቅም ቀድሞውኑ በቂ ከሆነ ምንም አያደርግም።
    ///
    /// # Panics
    ///
    /// አዲሱ አቅም ከ `isize::MAX` ባይት የሚበልጥ ከሆነ Panics።
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.reserve(10);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.buf.reserve(self.len, additional);
    }

    /// በትክክል `additional` ተጨማሪ ክፍሎች ክምችት ዝቅተኛ አቅም የተሰጠው `Vec<T>` ውስጥ የገባው ዘንድ.
    ///
    /// `reserve_exact` ን ከጠራ በኋላ አቅም ከ `self.len() + additional` ይበልጣል ወይም እኩል ይሆናል።
    /// አቅሙ ቀድሞውኑ በቂ ከሆነ ምንም አያደርግም።
    ///
    /// አከፋፋዩ ስብስቡ ከሚጠይቀው የበለጠ ቦታ ሊሰጥ እንደሚችል ልብ ይበሉ ፡፡
    /// ስለሆነም አቅም በትክክል አነስተኛ ሆኖ መታመን አይቻልም።
    /// የ future ማስገባቶች የሚጠበቁ ከሆኑ `reserve` ን ይምረጡ።
    ///
    /// # Panics
    ///
    /// አዲሱ አቅም `usize` ን ካፈሰሰ Panics።
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.reserve_exact(10);
    /// assert!(vec.capacity() >= 11);
    /// ```
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.buf.reserve_exact(self.len, additional);
    }

    /// በተሰጠው `Vec<T>` ውስጥ ለማስገባት ቢያንስ ለ `additional` ተጨማሪ አካላት አቅም ለመያዝ ይሞክራል።
    /// ስብስቡ ተደጋጋሚ ሪከሎችን ለማስቀረት ተጨማሪ ቦታ ሊይዝ ይችላል።
    /// `try_reserve` ን ከጠራ በኋላ አቅም ከ `self.len() + additional` ይበልጣል ወይም እኩል ይሆናል።
    /// አቅም ቀድሞውኑ በቂ ከሆነ ምንም አያደርግም።
    ///
    /// # Errors
    ///
    /// አቅሙ ሞልቶ ከሆነ ወይም አከፋፋዩ አለመሳካቱን ሪፖርት ካደረገ ከዚያ ስህተት ተመልሷል።
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &[u32]) -> Result<Vec<u32>, TryReserveError> {
    ///     let mut output = Vec::new();
    ///
    ///     // ካልቻልን በመውጣት ማህደረ ትውስታውን ቀድመው ይያዙ
    ///     output.try_reserve(data.len())?;
    ///
    ///     // አሁን እኛ ውስብስብ በሆነው ሥራችን መካከል ይህ ኦኤም እንደማይችል አውቀናል
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // በጣም የተወሳሰበ
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[doc(alias = "realloc")]
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.buf.try_reserve(self.len, additional)
    }

    /// በተሰጠው `Vec<T>` ውስጥ ለማስገባት በትክክል ለ‹`additional`›አካላት አነስተኛውን አቅም ለመያዝ ይሞክራል ፡፡
    /// `try_reserve_exact` ጥሪ በኋላ, አቅም የሚበልጥ ይሆናል ወይም `Ok(())` ይመልሳል ከሆነ `self.len() + additional` ጋር እኩል.
    ///
    /// አቅሙ ቀድሞውኑ በቂ ከሆነ ምንም አያደርግም።
    ///
    /// አከፋፋዩ ስብስቡ ከሚጠይቀው የበለጠ ቦታ ሊሰጥ እንደሚችል ልብ ይበሉ ፡፡
    /// ስለሆነም አቅም በትክክል አነስተኛ ሆኖ መታመን አይቻልም።
    /// የ future ማስገባቶች የሚጠበቁ ከሆኑ `reserve` ን ይምረጡ።
    ///
    /// # Errors
    ///
    /// አቅሙ ሞልቶ ከሆነ ወይም አከፋፋዩ አለመሳካቱን ሪፖርት ካደረገ ከዚያ ስህተት ተመልሷል።
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &[u32]) -> Result<Vec<u32>, TryReserveError> {
    ///     let mut output = Vec::new();
    ///
    ///     // ካልቻልን በመውጣት ማህደረ ትውስታውን ቀድመው ይያዙ
    ///     output.try_reserve_exact(data.len())?;
    ///
    ///     // አሁን እኛ ውስብስብ በሆነው ሥራችን መካከል ይህ ኦኤም እንደማይችል አውቀናል
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // በጣም የተወሳሰበ
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[doc(alias = "realloc")]
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.buf.try_reserve_exact(self.len, additional)
    }

    /// የ vector ን አቅም በተቻለ መጠን ይቀንሰዋል።
    ///
    /// በተቻለ መጠን እስከ ርዝመቱ ድረስ ይወርዳል ነገር ግን አከፋፋዩ ለጥቂት ተጨማሪ አካላት ቦታ እንዳለ አሁንም ለ vector ያሳውቅ ይሆናል ፡፡
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    /// assert_eq!(vec.capacity(), 10);
    /// vec.shrink_to_fit();
    /// assert!(vec.capacity() >= 3);
    /// ```
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        // አቅሙ ከርዝመቱ ፈጽሞ አይተናነስም ፣ እና ሲመሳሰሉ ምንም የሚያደርግ ነገር ስለሌለ ፣ በ‹XXXX›ውስጥ ያለውን የ panic ጉዳይ በከፍተኛ አቅም ብቻ በመጥራት ማስወገድ እንችላለን ፡፡
        //
        //
        if self.capacity() > self.len {
            self.buf.shrink_to_fit(self.len);
        }
    }

    /// የ vector አቅሙን በዝቅተኛ ማሰሪያ ይቀንሰዋል።
    ///
    /// አቅሙ እንደ ርዝመቱ እና ከቀረበው እሴት ቢያንስ እንደ ትልቅ ይቆያል።
    ///
    ///
    /// አሁን ያለው አቅም ከዝቅተኛው ወሰን በታች ከሆነ ፣ ይህ ምንም ምርጫ የለውም።
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    /// assert_eq!(vec.capacity(), 10);
    /// vec.shrink_to(4);
    /// assert!(vec.capacity() >= 4);
    /// vec.shrink_to(0);
    /// assert!(vec.capacity() >= 3);
    /// ```
    #[doc(alias = "realloc")]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        if self.capacity() > min_capacity {
            self.buf.shrink_to_fit(cmp::max(self.len, min_capacity));
        }
    }

    /// vector ን ወደ [`Box<[T]>`][owned slice] ይቀይረዋል።
    ///
    /// ይህ ማንኛውንም ከመጠን በላይ አቅም እንደሚጥል ልብ ይበሉ ፡፡
    ///
    /// [owned slice]: Box
    ///
    /// # Examples
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    ///
    /// let slice = v.into_boxed_slice();
    /// ```
    ///
    /// ከመጠን በላይ የሆነ አቅም ተወግዷል
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    ///
    /// assert_eq!(vec.capacity(), 10);
    /// let slice = vec.into_boxed_slice();
    /// assert_eq!(slice.into_vec().capacity(), 3);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_boxed_slice(mut self) -> Box<[T], A> {
        unsafe {
            self.shrink_to_fit();
            let me = ManuallyDrop::new(self);
            let buf = ptr::read(&me.buf);
            let len = me.len();
            buf.into_box(len).assume_init()
        }
    }

    /// የመጀመሪያዎቹን የ `len` አባሎችን በመጠበቅ እና የቀረውን በመጣል vector ን ያሳጥራል።
    ///
    /// `len` ከ vector የአሁኑ ርዝመት የበለጠ ከሆነ ይህ ምንም ውጤት የለውም።
    ///
    /// የ [`drain`] ዘዴ `truncate` ን መኮረጅ ይችላል ፣ ግን ከመጠን በላይ ንጥረ ነገሮች ከመውደቅ ይልቅ እንዲመለሱ ያደርጋቸዋል።
    ///
    ///
    /// ይህ ዘዴ በ vector በተመደበ አቅም ላይ ምንም ተጽዕኖ እንደሌለው ልብ ይበሉ ፡፡
    ///
    /// # Examples
    ///
    /// ሁለት አባሎች ወደ አምስት አባል vector Truncating:
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4, 5];
    /// vec.truncate(2);
    /// assert_eq!(vec, [1, 2]);
    /// ```
    ///
    /// `len` ከ vector የአሁኑ ርዝመት ሲበልጥ ምንም አይነት መቆራረጥ አይከሰትም-
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.truncate(8);
    /// assert_eq!(vec, [1, 2, 3]);
    /// ```
    ///
    /// `len == 0` በሚሆንበት ጊዜ መከርከም የ [`clear`] ዘዴን ከመጥራት ጋር እኩል ነው ፡፡
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.truncate(0);
    /// assert_eq!(vec, []);
    /// ```
    ///
    /// [`clear`]: Vec::clear
    /// [`drain`]: Vec::drain
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn truncate(&mut self, len: usize) {
        // ይህ ደህንነቱ የተጠበቀ ነው ምክንያቱም
        //
        // * ወደ `drop_in_place` የተላለፈው ቁርጥራጭ ልክ ነው;የ `len > self.len` ጉዳይ ልክ ያልሆነ ቁራጭ ከመፍጠር ይቆጠባል ፣ እና
        // * X0 `drop_in_place` ን ከመጥራትዎ በፊት የ vector `len` ቀንሷል ፣ ምክንያቱም `drop_in_place` አንዴ ለ panic አንድ ጊዜ ቢሆን ምንም ዋጋ አይጣልም (ሁለት ጊዜ panics ከሆነ ፕሮግራሙ ይቋረጣል) ፡፡
        //
        //
        //
        unsafe {
            // Note: ይህ `>` እና `>=` አለመሆኑ ሆን ተብሎ ነው ፡፡
            //       ወደ `>=` መለወጥ በአንዳንድ ሁኔታዎች አሉታዊ የአፈፃፀም እንድምታዎች አሉት ፡፡
            //       ተጨማሪ #78884 ይመልከቱ.
            if len > self.len {
                return;
            }
            let remaining_len = self.len - len;
            let s = ptr::slice_from_raw_parts_mut(self.as_mut_ptr().add(len), remaining_len);
            self.len = len;
            ptr::drop_in_place(s);
        }
    }

    /// መላውን vector የያዘ ቁራጭ ያወጣል።
    ///
    /// ከ `&s[..]` ጋር እኩል ነው።
    ///
    /// # Examples
    ///
    /// ```
    /// use std::io::{self, Write};
    /// let buffer = vec![1, 2, 3, 5, 8];
    /// io::sink().write(buffer.as_slice()).unwrap();
    /// ```
    #[inline]
    #[stable(feature = "vec_as_slice", since = "1.7.0")]
    pub fn as_slice(&self) -> &[T] {
        self
    }

    /// የጠቅላላው vector ን የሚለዋወጥ ቁራጭ ያወጣል።
    ///
    /// ከ `&mut s[..]` ጋር እኩል ነው።
    ///
    /// # Examples
    ///
    /// ```
    /// use std::io::{self, Read};
    /// let mut buffer = vec![0; 3];
    /// io::repeat(0b101).read_exact(buffer.as_mut_slice()).unwrap();
    /// ```
    #[inline]
    #[stable(feature = "vec_as_slice", since = "1.7.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        self
    }

    /// አንድ ጥሬ ጠቋሚ ወደ የ vector ቋት ይመልሳል።
    ///
    /// ደዋዩ vector ይህ ተግባር ከጠቋሚው የበለጠ እንደሚበልጥ ማረጋገጥ አለበት ፣ አለበለዚያ ወደ ቆሻሻ መጣያ ይጠቁማል።
    /// ልክ ደግሞ ማንኛውንም ዘዴውን ማድረግ ነበር ይህም ወደ vector በውስጡ ቋት reallocated እንዲታዩ ሊያደርግ ይችላል በመቀየር ላይ.
    ///
    /// ደዋዩ ጠቋሚ (non-transitively) የሚጠቁምበት ማህደረ ትውስታ ይህንን ጠቋሚ ወይም ከእሱ የተገኘውን ማንኛውንም ጠቋሚ በመጠቀም (ከ `UnsafeCell` ውስጡ በስተቀር) መቼም እንደተፃፈ ማረጋገጥ አለበት ፡፡
    /// በተቆራረጡ ይዘቶች ላይ መለወጥ ከፈለጉ ፣ [`as_mut_ptr`] ን ይጠቀሙ።
    ///
    /// # Examples
    ///
    /// ```
    /// let x = vec![1, 2, 4];
    /// let x_ptr = x.as_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         assert_eq!(*x_ptr.add(i), 1 << i);
    ///     }
    /// }
    /// ```
    ///
    /// [`as_mut_ptr`]: Vec::as_mut_ptr
    ///
    ///
    ///
    #[stable(feature = "vec_as_ptr", since = "1.37.0")]
    #[inline]
    pub fn as_ptr(&self) -> *const T {
        // መካከለኛ ማጣቀሻን በሚፈጥረው በ `deref` ውስጥ ላለመሄድ ተመሳሳይ ስም የመቁረጥ ዘዴን እናጥላለን ፡፡
        //
        let ptr = self.buf.ptr();
        unsafe {
            assume(!ptr.is_null());
        }
        ptr
    }

    /// ደህንነቱ ያልተጠበቀ የሚለዋወጥ ጠቋሚ ወደ የ vector ቋት ይመልሳል።
    ///
    /// ደዋዩ vector ይህ ተግባር ከጠቋሚው የበለጠ እንደሚበልጥ ማረጋገጥ አለበት ፣ አለበለዚያ ወደ ቆሻሻ መጣያ ይጠቁማል።
    ///
    /// ልክ ደግሞ ማንኛውንም ዘዴውን ማድረግ ነበር ይህም ወደ vector በውስጡ ቋት reallocated እንዲታዩ ሊያደርግ ይችላል በመቀየር ላይ.
    ///
    /// # Examples
    ///
    /// ```
    /// // ለ 4 አባሎች vector ትልቅ ይመድቡ።
    /// let size = 4;
    /// let mut x: Vec<i32> = Vec::with_capacity(size);
    /// let x_ptr = x.as_mut_ptr();
    ///
    /// // ጥሬ ጠቋሚ በሚጽፍበት ጊዜ አባሎችን ያስጀምሩ ፣ ከዚያ ያዘጋጁ ርዝመት
    /// unsafe {
    ///     for i in 0..size {
    ///         *x_ptr.add(i) = i as i32;
    ///     }
    ///     x.set_len(size);
    /// }
    /// assert_eq!(&*x, &[0, 1, 2, 3]);
    /// ```
    ///
    #[stable(feature = "vec_as_ptr", since = "1.37.0")]
    #[inline]
    pub fn as_mut_ptr(&mut self) -> *mut T {
        // መካከለኛ ማጣቀሻን በሚፈጥረው በ `deref_mut` ውስጥ ላለመሄድ ተመሳሳይ ስም የመቁረጥ ዘዴን እናጥላለን ፡፡
        //
        let ptr = self.buf.ptr();
        unsafe {
            assume(!ptr.is_null());
        }
        ptr
    }

    /// ለታችኛው አመዳደብ ማጣቀሻ ይመልሳል።
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn allocator(&self) -> &A {
        self.buf.allocator()
    }

    /// የ vector ርዝመት እስከ `new_len` ያስገድዳል።
    ///
    /// ይህ የዝቅተኛውን መደበኛ የማይለዋወጥን የማይጠብቅ ዝቅተኛ ደረጃ ያለው ክዋኔ ነው ፡፡
    /// በመደበኛነት የ vector ን ርዝመት መለወጥ የሚከናወነው በምትኩ እንደ [`truncate`] ፣ [`resize`] ፣ [`extend`] ወይም [`clear`] ካሉ ደህንነቱ የተጠበቀ ክንውኖችን በመጠቀም ነው ፡፡
    ///
    ///
    /// [`truncate`]: Vec::truncate
    /// [`resize`]: Vec::resize
    /// [`extend`]: Extend::extend
    /// [`clear`]: Vec::clear
    ///
    /// # Safety
    ///
    /// - `new_len` ከ [`capacity()`] በታች ወይም እኩል መሆን አለበት።
    /// - በ `old_len..new_len` ላይ ያሉት ንጥረ ነገሮች መነሳት አለባቸው።
    ///
    /// [`capacity()`]: Vec::capacity
    ///
    /// # Examples
    ///
    /// ይህ ዘዴ vector ለሌላ ኮድ ፣ በተለይም ከ FFI በላይ እንደ ቋት ሆኖ ለሚያገለግልባቸው ሁኔታዎች ጠቃሚ ሊሆን ይችላል-
    ///
    /// ```no_run
    /// # #![allow(dead_code)]
    /// # // ይህ ለዶክ ምሳሌ አነስተኛ አፅም ነው;
    /// # // ለእውነተኛ ቤተ-መጽሐፍት ይህንን እንደ መነሻ አይጠቀሙ ፡፡
    /// # pub struct StreamWrapper { strm: *mut std::ffi::c_void }
    /// # const Z_OK: i32 = 0;
    /// # extern "C" {
    /// #     fn deflateGetDictionary(
    /// #         strm: *mut std::ffi::c_void,
    /// #         dictionary: *mut u8,
    /// #         dictLength: *mut usize,
    /// #     ) -> i32;
    /// # }
    /// # impl StreamWrapper {
    /// pub fn get_dictionary(&self) -> Option<Vec<u8>> {
    ///     // በ FFI ስልትዎ ሰነዶች በቀን, "32768 bytes is always enough".
    ///     let mut dict = Vec::with_capacity(32_768);
    ///     let mut dict_length = 0;
    ///     // ደህንነት: `deflateGetDictionary` `Z_OK` በሚመለስበት ጊዜ, በዚያ ተካሄደ;
    ///     // 1. `dict_length` ንጥረ ነገሮች ተጀምረዋል።
    ///     // 2.
    ///     // `dict_length` <= `set_len` ን ለመደወል ደህንነትን የሚያደርግ አቅም (32_768)።
    ///     unsafe {
    ///         // የ FFI ጥሪ ያድርጉ ...
    ///         let r = deflateGetDictionary(self.strm, dict.as_mut_ptr(), &mut dict_length);
    ///         if r == Z_OK {
    ///             // ... እና ርዝመቱን ወደ ተጀመረው ነገር ያዘምኑ።
    ///             dict.set_len(dict_length);
    ///             Some(dict)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    /// # }
    /// ```
    ///
    /// የሚከተለው ምሳሌ ጥሩ ቢሆንም ፣ የ‹XXXX›ጥሪ በፊት ውስጡ vectors ስላልተለቀቀ የማስታወሻ ፍሰት አለ ፡፡
    ///
    /// ```
    /// let mut vec = vec![vec![1, 0, 0],
    ///                    vec![0, 1, 0],
    ///                    vec![0, 0, 1]];
    /// // SAFETY:
    /// // 1. `old_len..0` ባዶ ስለሆነ ስለዚህ ምንም አካላት መነሳሳት አያስፈልጋቸውም።
    /// // 2. `0 <= capacity` `capacity` የሆነውን ሁሉ ሁልጊዜ ይይዛል።
    /// unsafe {
    ///     vec.set_len(0);
    /// }
    /// ```
    ///
    /// በመደበኛነት ፣ እዚህ ፣ አንድ ሰው ይዘቱን በትክክል ለመጣል እና በማስታወስ እንዳያፈሰው በምትኩ [`clear`] ን ይጠቀማል።
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn set_len(&mut self, new_len: usize) {
        debug_assert!(new_len <= self.capacity());

        self.len = new_len;
    }

    /// አንድን ንጥረ ነገር ከ vector ያስወግዳል እና ይመልሰዋል።
    ///
    /// በተወገደው ንጥረ ነገር ወደ vector የመጨረሻ አባል ተተክቷል.
    ///
    /// ይህ ማዘዣን አይጠብቅም ፣ ግን O(1) ነው።
    ///
    /// # Panics
    ///
    /// `index` ከገደብ ውጭ ከሆነ Panics
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec!["foo", "bar", "baz", "qux"];
    ///
    /// assert_eq!(v.swap_remove(1), "bar");
    /// assert_eq!(v, ["foo", "qux", "baz"]);
    ///
    /// assert_eq!(v.swap_remove(0), "foo");
    /// assert_eq!(v, ["baz", "qux"]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn swap_remove(&mut self, index: usize) -> T {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("swap_remove index (is {}) should be < len (is {})", index, len);
        }

        let len = self.len();
        if index >= len {
            assert_failed(index, len);
        }
        unsafe {
            // በመጨረሻው አካል ላይ የራስን [ማውጫ] እንተካለን።
            // ልብ ይበሉ ከዚህ በላይ ያለው የድንበር ፍተሻ ከተሳካ የመጨረሻው አካል መኖር አለበት (ራሱ ራሱ [መረጃ ጠቋሚ] ሊሆን ይችላል)።
            //
            let last = ptr::read(self.as_ptr().add(len - 1));
            let hole = self.as_mut_ptr().add(index);
            self.set_len(len - 1);
            ptr::replace(hole, last)
        }
    }

    /// አንድ ንጥረ ነገር በ vector ውስጥ ባለው ቦታ `index` ላይ ያስገባል ፣ ሁሉንም ንጥረ ነገሮች ከእሱ በኋላ ወደ ቀኝ ያዛውረዋል።
    ///
    ///
    /// # Panics
    ///
    /// `index > len` ከሆነ Panics።
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.insert(1, 4);
    /// assert_eq!(vec, [1, 4, 2, 3]);
    /// vec.insert(4, 5);
    /// assert_eq!(vec, [1, 4, 2, 3, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn insert(&mut self, index: usize, element: T) {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("insertion index (is {}) should be <= len (is {})", index, len);
        }

        let len = self.len();
        if index > len {
            assert_failed(index, len);
        }

        // ለአዲሱ ንጥረ ነገር ቦታ
        if len == self.buf.capacity() {
            self.reserve(1);
        }

        unsafe {
            // የማይሳሳት አዲሱን እሴት ለማስቀመጥ ቦታው
            //
            {
                let p = self.as_mut_ptr().add(index);
                // ቦታ ለመስራት ሁሉንም ነገር ያዛውሩ ፡፡
                // (የ `ማውጫውን` ንጥረ ነገር ወደ ሁለት ተከታታይ ቦታዎች በማባዛት)
                ptr::copy(p, p.offset(1), len - index);
                // የ `index`th ንጥረ የመጀመሪያ ቅጂ ደርቦ, በውስጡ ጻፍ.
                //
                ptr::write(p, element);
            }
            self.set_len(len + 1);
        }
    }

    /// በ vector ውስጥ ባለው ቦታ `index` ላይ ያለውን ኤለመንት ያስወግዳል እና ይመልሰዋል ፣ ሁሉንም ንጥረ ነገሮች ከእሱ በኋላ ወደ ግራ ያዛውረዋል።
    ///
    ///
    /// # Panics
    ///
    /// `index` ከገደብ ውጭ ከሆነ Panics
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// assert_eq!(v.remove(1), 2);
    /// assert_eq!(v, [1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, index: usize) -> T {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("removal index (is {}) should be < len (is {})", index, len);
        }

        let len = self.len();
        if index >= len {
            assert_failed(index, len);
        }
        unsafe {
            // infallible
            let ret;
            {
                // የምንወስድበት ቦታ ፡፡
                let ptr = self.as_mut_ptr().add(index);
                // በመደርደሪያው ላይ እና በተመሳሳይ ጊዜ በ vector ውስጥ የእሴቱን ዋጋ ቅጂ ደህንነቱ በተጠበቀ ሁኔታ ይቅዱት።
                //
                ret = ptr::read(ptr);

                // ያንን ቦታ ለመሙላት ሁሉንም ነገር ወደ ታች ያዛውሩ።
                ptr::copy(ptr.offset(1), ptr, len - index - 1);
            }
            self.set_len(len - 1);
            ret
        }
    }

    /// አስቀድሞ በተጠቀሰው አካል የተገለጹትን ንጥረ ነገሮች ብቻ ይይዛል።
    ///
    /// በሌላ አገላለጽ `f(&e)` ን `false` ን ይመልሳል ፣ ስለሆነም ሁሉንም አባሎች `e` ን ያስወግዱ።
    /// ይህ ዘዴ በቦታው የሚሠራ ሲሆን እያንዳንዱን ንጥረ ነገር በትክክል አንድ ጊዜ በመነሻው ቅደም ተከተል በመጎብኘት የቀሩትን ንጥረ ነገሮች ቅደም ተከተል ይጠብቃል ፡፡
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4];
    /// vec.retain(|&x| x % 2 == 0);
    /// assert_eq!(vec, [2, 4]);
    /// ```
    ///
    /// ንጥረ ከዋናው ቅደም ተከተል በትክክል አንድ ጊዜ የተጎበኙ ናቸው, ምክንያቱም ውጫዊ ሁኔታ ለመጠበቅ የትኛው ክፍሎች ለመወሰን ጥቅም ላይ ሊውል ይችላል.
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4, 5];
    /// let keep = [false, true, true, false, true];
    /// let mut iter = keep.iter();
    /// vec.retain(|_| *iter.next().unwrap());
    /// assert_eq!(vec, [2, 3, 5]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> bool,
    {
        let original_len = self.len();
        // በሂደቱ ወቅት አንዳንድ ቀዳዳዎችን ልናደርግ ስለምንችል ጠብታ ዘበኛው ካልተገደለ ድርብ ጠብታ ያስወግዱ ፡፡
        //
        unsafe { self.set_len(0) };

        // Vec: [Kept, Kept, Hole, Hole, Hole, Hole, Unchecked, Unchecked]
        //      | <-የተሰራ ሌን-> |check-ለማጣራት ቀጥሎ
        //                  | <-ተሰር cል cnt-> |
        //      | <-original_len-> |ተጠብቆ-የሚተነብይ ንጥረ ነገሮች በትክክል ይመለሳሉ ፡፡
        //
        // ቀዳዳ: አንቀሳቅሷል ወይም ወደቀ ኤለመንት ማስገቢያ።
        // ቁጥጥር ያልተደረገበት:-ትክክለኛ ቁጥጥር ያልተደረገባቸው አካላት።
        //
        // ይህ ጠብታ ጠባቂ አስቀድሞ ሲተነተን ወይም `drop` ን ሲደነግጥ ይጠየቃል።
        // ቀዳዳዎችን እና `set_len` ን ወደ ትክክለኛው ርዝመት ለመሸፈን ቁጥጥር ያልተደረገባቸውን አካላት ይለውጣል።
        // ሊተነብይ እና `drop` በጭራሽ የማይደናገጡ ሁኔታዎች ውስጥ ፣ ተመቻችቶ ይወጣል።
        struct BackshiftOnDrop<'a, T, A: Allocator> {
            v: &'a mut Vec<T, A>,
            processed_len: usize,
            deleted_cnt: usize,
            original_len: usize,
        }

        impl<T, A: Allocator> Drop for BackshiftOnDrop<'_, T, A> {
            fn drop(&mut self) {
                if self.deleted_cnt > 0 {
                    // ደህንነት-ቁጥጥር ያልተደረገባቸውን ዕቃዎች መከታተል በጭራሽ ስለማንነካቸው ልክ መሆን አለበት ፡፡
                    unsafe {
                        ptr::copy(
                            self.v.as_ptr().add(self.processed_len),
                            self.v.as_mut_ptr().add(self.processed_len - self.deleted_cnt),
                            self.original_len - self.processed_len,
                        );
                    }
                }
                // ደህንነት:-ቀዳዳዎችን ከሞሉ በኋላ ሁሉም ዕቃዎች ተያያዥ ትውስታ ውስጥ ናቸው።
                unsafe {
                    self.v.set_len(self.original_len - self.deleted_cnt);
                }
            }
        }

        let mut g = BackshiftOnDrop { v: self, processed_len: 0, deleted_cnt: 0, original_len };

        while g.processed_len < original_len {
            // ደህንነት-ቁጥጥር ያልተደረገበት አካል ትክክለኛ መሆን አለበት ፡፡
            let cur = unsafe { &mut *g.v.as_mut_ptr().add(g.processed_len) };
            if !f(cur) {
                // `drop_in_place` ተደናገጠች ከሆነ ሁለቴ ጠብታ ለማስቀረት ቀደም ይቀጥሉ.
                g.processed_len += 1;
                g.deleted_cnt += 1;
                // ደህንነት-ከወደቅን በኋላ ይህንን ንጥረ ነገር በጭራሽ አንነካውም ፡፡
                unsafe { ptr::drop_in_place(cur) };
                // ቆጣሪውን ቀድመናል ፡፡
                continue;
            }
            if g.deleted_cnt > 0 {
                // ደህንነት: `deleted_cnt`> 0, ስለዚህ ቀዳዳ ማስገቢያ አይደለም መደራረብ በአሁኑ አባል ጋር አለብዎት.
                // እኛ ለመውሰድ ቅጂ መጠቀም, እንደገና ይህን አባል ይንኩ አያውቅም.
                unsafe {
                    let hole_slot = g.v.as_mut_ptr().add(g.processed_len - g.deleted_cnt);
                    ptr::copy_nonoverlapping(cur, hole_slot, 1);
                }
            }
            g.processed_len += 1;
        }

        // ሁሉም ንጥል ተስተካክሏል።ይህ በ‹XXXX›በ LLVM ሊመች ይችላል ፡፡
        drop(g);
    }

    /// ያስወግደዋል ሁሉም ግን ተመሳሳይ ቁልፍ ላይ ቁርጥ መሆኑን vector ውስጥ ተከታታይ ክፍሎች የመጀመሪያ.
    ///
    ///
    /// vector ከተደረደረ ይህ ሁሉንም ብዜቶች ያስወግዳል።
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![10, 20, 21, 30, 20];
    ///
    /// vec.dedup_by_key(|i| *i / 10);
    ///
    /// assert_eq!(vec, [10, 20, 30, 20]);
    /// ```
    #[stable(feature = "dedup_by", since = "1.16.0")]
    #[inline]
    pub fn dedup_by_key<F, K>(&mut self, mut key: F)
    where
        F: FnMut(&mut T) -> K,
        K: PartialEq,
    {
        self.dedup_by(|a, b| key(a) == key(b))
    }

    /// የተሰጠ የእኩልነት ግንኙነትን የሚያረካ በ vector ውስጥ ከተከታታይ የመጀመሪያ አካላት በስተቀር ሁሉንም ያስወግዳል ፡፡
    ///
    /// የ `same_bucket` ተግባር ከ vector ወደ ሁለት አካላት ማጣቀሻዎች ተላል andል እና አባላቱ እኩል መሆናቸውን የሚያረጋግጥ መሆን አለበት።
    /// ንጥረ `same_bucket(a, b)` ሲመለስ `true`, `a` ከተወገደ እንዲህ ከሆነ ቁራጭ ውስጥ ያላቸውን ትእዛዝ ከ ተቃራኒ ቅደም አልፈዋል ናቸው.
    ///
    ///
    /// vector ከተደረደረ ይህ ሁሉንም ብዜቶች ያስወግዳል።
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec!["foo", "bar", "Bar", "baz", "bar"];
    ///
    /// vec.dedup_by(|a, b| a.eq_ignore_ascii_case(b));
    ///
    /// assert_eq!(vec, ["foo", "bar", "baz", "bar"]);
    /// ```
    ///
    #[stable(feature = "dedup_by", since = "1.16.0")]
    pub fn dedup_by<F>(&mut self, mut same_bucket: F)
    where
        F: FnMut(&mut T, &mut T) -> bool,
    {
        let len = self.len();
        if len <= 1 {
            return;
        }

        /* INVARIANT: vec.len() > read >= write > write-1 >= 0 */
        struct FillGapOnDrop<'a, T, A: core::alloc::Allocator> {
            /* Offset of the element we want to check if it is duplicate */
            read: usize,

            /* Offset of the place where we want to place the non-duplicate
             * when we find it. */
            write: usize,

            /* The Vec that would need correction if `same_bucket` panicked */
            vec: &'a mut Vec<T, A>,
        }

        impl<'a, T, A: core::alloc::Allocator> Drop for FillGapOnDrop<'a, T, A> {
            fn drop(&mut self) {
                /* This code gets executed when `same_bucket` panics */

                /* SAFETY: invariant guarantees that `read - write`
                 * and `len - read` never overflow and that the copy is always
                 * in-bounds. */
                unsafe {
                    let ptr = self.vec.as_mut_ptr();
                    let len = self.vec.len();

                    /* How many items were left when `same_bucket` paniced.
                     * Basically vec[read..].len() */
                    let items_left = len.wrapping_sub(self.read);

                    /* Pointer to first item in vec[write..write+items_left] slice */
                    let dropped_ptr = ptr.add(self.write);
                    /* Pointer to first item in vec[read..] slice */
                    let valid_ptr = ptr.add(self.read);

                    /* Copy `vec[read..]` to `vec[write..write+items_left]`.
                     * The slices can overlap, so `copy_nonoverlapping` cannot be used */
                    ptr::copy(valid_ptr, dropped_ptr, items_left);

                    /* How many items have been already dropped
                     * Basically vec[read..write].len() */
                    let dropped = self.read.wrapping_sub(self.write);

                    self.vec.set_len(len - dropped);
                }
            }
        }

        let mut gap = FillGapOnDrop { read: 1, write: 1, vec: self };
        let ptr = gap.vec.as_mut_ptr();

        /* Drop items while going through Vec, it should be more efficient than
         * doing slice partition_dedup + truncate */

        /* SAFETY: Because of the invariant, read_ptr, prev_ptr and write_ptr
         * are always in-bounds and read_ptr never aliases prev_ptr */
        unsafe {
            while gap.read < len {
                let read_ptr = ptr.add(gap.read);
                let prev_ptr = ptr.add(gap.write.wrapping_sub(1));

                if same_bucket(&mut *read_ptr, &mut *prev_ptr) {
                    /* We have found duplicate, drop it in-place */
                    ptr::drop_in_place(read_ptr);
                } else {
                    let write_ptr = ptr.add(gap.write);

                    /* Because `read_ptr` can be equal to `write_ptr`, we either
                     * have to use `copy` or conditional `copy_nonoverlapping`.
                     * Looks like the first option is faster. */
                    ptr::copy(read_ptr, write_ptr, 1);

                    /* We have filled that place, so go further */
                    gap.write += 1;
                }

                gap.read += 1;
            }

            /* Technically we could let `gap` clean up with its Drop, but
             * when `same_bucket` is guaranteed to not panic, this bloats a little
             * the codegen, so we just do it manually */
            gap.vec.set_len(gap.write);
            mem::forget(gap);
        }
    }

    /// ከስብስቡ ጀርባ አንድ አካል ይተገበራል።
    ///
    /// # Panics
    ///
    /// አዲሱ አቅም ከ `isize::MAX` ባይት የሚበልጥ ከሆነ Panics።
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2];
    /// vec.push(3);
    /// assert_eq!(vec, [1, 2, 3]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, value: T) {
        // ይህ ያደርጋል panic ወይም እኛ ለመመደብ ከሆነ> isize::MAX ባይቶች ወይም አጨንግፍ ርዝመት ጭማሪ ወደ ዜሮ መጠን አይነቶች ሞልቶ ነበር ከሆነ.
        //
        if self.len == self.buf.capacity() {
            self.reserve(1);
        }
        unsafe {
            let end = self.as_mut_ptr().add(self.len);
            ptr::write(end, value);
            self.len += 1;
        }
    }

    /// ይህም ባዶ ከሆነ አንድ vector እና ተመላሾች ነው, ወይም [`None`] ከ የመጨረሻ ክፍል ያስወግደዋል.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// assert_eq!(vec.pop(), Some(3));
    /// assert_eq!(vec, [1, 2]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<T> {
        if self.len == 0 {
            None
        } else {
            unsafe {
                self.len -= 1;
                Some(ptr::read(self.as_ptr().add(self.len())))
            }
        }
    }

    /// `Self` ወደ ይንቀሳቀሳል `other` ሁሉ ክፍሎች, ባዶ `other` ትቶ.
    ///
    /// # Panics
    ///
    /// በ vector ውስጥ ያሉት ንጥረ ነገሮች ብዛት `usize` ን የሚያጥለቀልቅ ከሆነ Panics።
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// let mut vec2 = vec![4, 5, 6];
    /// vec.append(&mut vec2);
    /// assert_eq!(vec, [1, 2, 3, 4, 5, 6]);
    /// assert_eq!(vec2, []);
    /// ```
    #[inline]
    #[stable(feature = "append", since = "1.4.0")]
    pub fn append(&mut self, other: &mut Self) {
        unsafe {
            self.append_elements(other.as_slice() as _);
            other.set_len(0);
        }
    }

    /// አባላትን ከሌላ ቋት (ኤክስኤክስኤክስክስ) ላይ ይተግብራል
    #[inline]
    unsafe fn append_elements(&mut self, other: *const [T]) {
        let count = unsafe { (*other).len() };
        self.reserve(count);
        let len = self.len();
        unsafe { ptr::copy_nonoverlapping(other as *const T, self.as_mut_ptr().add(len), count) };
        self.len += count;
    }

    /// በ vector ውስጥ የተገለጸውን ክልል የሚያስወግድ እና የተወገዱትን ዕቃዎች የሚያወጣ የፍሳሽ ማስወገጃ ተደጋጋሚ ይፈጥራል።
    ///
    /// ተደጋጋሚው **ሲወድቅ** ሲወድቅ ፣ በክልሉ ውስጥ ያሉት ሁሉም ንጥረ ነገሮች ምንም እንኳን ተሟጋቹ ሙሉ በሙሉ ባይጠጡም ከ vector ይወገዳሉ።
    /// ተደጋጋሚው ** ካልተጣለ (ለምሳሌ ከ [`mem::forget`] ጋር) ፣ ስንት አካላት እንደሚወገዱ አልተገለጸም።
    ///
    /// # Panics
    ///
    /// Panics የመነሻው ነጥብ ከመጨረሻው ነጥብ የበለጠ ከሆነ ወይም የመጨረሻው ነጥብ ከ vector ርዝመት የበለጠ ከሆነ።
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// let u: Vec<_> = v.drain(1..).collect();
    /// assert_eq!(v, &[1]);
    /// assert_eq!(u, &[2, 3]);
    ///
    /// // አንድ ሙሉ ክልል vector ን ያጸዳል
    /// v.drain(..);
    /// assert_eq!(v, &[]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_, T, A>
    where
        R: RangeBounds<usize>,
    {
        // የማስታወስ ደህንነት
        //
        // Drain መጀመሪያ ሲፈጠር የ Drain አጥፊ በጭራሽ መሮጥ ካልቻለ ምንም ያልታወቁ ወይም የተንቀሳቀሱ አካላት በጭራሽ ተደራሽ መሆናቸውን ለማረጋገጥ የ vector ምንጩን ርዝመት ያሳጥረዋል።
        //
        //
        // Drain ለማስወገድ እሴቶቹን ptr::read ያደርጋቸዋል።
        // ስትጨርስ, ወደ vec የቀሩት ጅራቱም ቀዳዳ ለመሸፈን ተመልሶ ተገልብጧል ነው, እና vector ርዝመት ወደ አዲሱ ርዝመት ተመልሰዋል ነው.
        //
        //
        //
        let len = self.len();
        let Range { start, end } = slice::range(range, ..len);

        unsafe {
            // ስብስብ self.vec ርዝመት Drain ድርስ ነው ሁኔታ ውስጥ ደህንነቱ የተጠበቀ እንዲሆን ለማድረግ, መጀመር ነው
            self.set_len(start);
            // የመላው የ Drain ተደጋጋሚ (እንደ &mut T) የብድር ባህሪን ለማሳየት በ IterMut ውስጥ ያለውን ብድር ይጠቀሙ።
            //
            let range_slice = slice::from_raw_parts_mut(self.as_mut_ptr().add(start), end - start);
            Drain {
                tail_start: end,
                tail_len: len - end,
                iter: range_slice.iter(),
                vec: NonNull::from(self),
            }
        }
    }

    /// ሁሉንም እሴቶች በማስወገድ vector ን ያጸዳል።
    ///
    /// ይህ ዘዴ በ vector በተመደበ አቅም ላይ ምንም ተጽዕኖ እንደሌለው ልብ ይበሉ ፡፡
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    ///
    /// v.clear();
    ///
    /// assert!(v.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.truncate(0)
    }

    /// ይመልሳል vector ውስጥ ንጥረ ቁጥር ደግሞ የራሱ 'length' ተብሎ ይጠራል.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = vec![1, 2, 3];
    /// assert_eq!(a.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.len
    }

    /// vector ምንም ንጥረ ነገሮችን ካልያዘ `true` ን ይመልሳል።
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = Vec::new();
    /// assert!(v.is_empty());
    ///
    /// v.push(1);
    /// assert!(!v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// በተጠቀሰው ማውጫ ላይ ስብስቡን ለሁለት ይከፍላል።
    ///
    /// በ `[at, len)` ክልል ውስጥ ያሉትን ንጥረ ነገሮች የያዘ አዲስ የተመደበ vector ን ይመልሳል።
    /// ከጥሪው በኋላ የመጀመሪያው vector የቀድሞው አቅም ሳይለወጥ `[0, at)` ን ንጥረ ነገሮችን የያዘ ይቀራል።
    ///
    ///
    /// # Panics
    ///
    /// `at > len` ከሆነ Panics።
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// let vec2 = vec.split_off(1);
    /// assert_eq!(vec, [1]);
    /// assert_eq!(vec2, [2, 3]);
    /// ```
    #[inline]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    #[stable(feature = "split_off", since = "1.4.0")]
    pub fn split_off(&mut self, at: usize) -> Self
    where
        A: Clone,
    {
        #[cold]
        #[inline(never)]
        fn assert_failed(at: usize, len: usize) -> ! {
            panic!("`at` split index (is {}) should be <= len (is {})", at, len);
        }

        if at > self.len() {
            assert_failed(at, self.len());
        }

        if at == 0 {
            // አዲሱ vector ዋናውን ቋት ተቆጣጥሮ ቅጅውን ማስቀረት ይችላል
            return mem::replace(
                self,
                Vec::with_capacity_in(self.capacity(), self.allocator().clone()),
            );
        }

        let other_len = self.len - at;
        let mut other = Vec::with_capacity_in(other_len, self.allocator().clone());

        // Unsafely `set_len` እና `other` ንጥሎችን መገልበጥ.
        unsafe {
            self.set_len(at);
            other.set_len(other_len);

            ptr::copy_nonoverlapping(self.as_ptr().add(at), other.as_mut_ptr(), other.len());
        }
        other
    }

    /// `len` ከ `new_len` ጋር እኩል እንዲሆን የ `Vec` ን በቦታው መጠን ይቀይረዋል።
    ///
    /// `new_len` `len` የሚበልጥ ከሆነ, የ `Vec` ወደ መዘጋት `f` በመደወል ውጤት ጋር የተሞላ ለእያንዳንዱ ተጨማሪ ማስገቢያ ጋር ያለውን ልዩነት እንዲራዘም ነው.
    ///
    /// `f` ከ መመለስ እሴቶችን እንደሚመነጩ ተደርጓል ቅደም ተከተል ውስጥ `Vec` ውስጥ ያበቃል.
    ///
    /// `new_len` `len` ያነሰ ከሆነ, የ `Vec` በቀላሉ ተጎርደዋል.
    ///
    /// ይህ ዘዴ እያንዳንዱ የግፋ ላይ አዲስ እሴቶችን ለመፍጠር አንድ መዘጋት ይጠቀማል.የተሰጠ እሴት [`Clone`] ን የሚመርጡ ከሆነ [`Vec::resize`] ይጠቀሙ።
    /// እሴቶችን ለማመንጨት [`Default`] trait ን ለመጠቀም ከፈለጉ [`Default::default`] ን እንደ ሁለተኛው ክርክር ማለፍ ይችላሉ ፡፡
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.resize_with(5, Default::default);
    /// assert_eq!(vec, [1, 2, 3, 0, 0]);
    ///
    /// let mut vec = vec![];
    /// let mut p = 1;
    /// vec.resize_with(4, || { p *= 2; p });
    /// assert_eq!(vec, [2, 4, 8, 16]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "vec_resize_with", since = "1.33.0")]
    pub fn resize_with<F>(&mut self, new_len: usize, f: F)
    where
        F: FnMut() -> T,
    {
        let len = self.len();
        if new_len > len {
            self.extend_with(new_len - len, ExtendFunc(f));
        } else {
            self.truncate(new_len);
        }
    }

    /// ይዘቱን የሚለዋወጥ ማጣቀሻ በመመለስ `Vec` ን ይወስዳል እና ያፈሳል ፣ `&'a mut [T]`.
    /// `T` ዓይነት ከተመረጠው የህይወት ዘመን `'a` በላይ መሆን እንዳለበት ልብ ይበሉ ፡፡
    /// ዓይነቱ የማይንቀሳቀስ ማጣቀሻዎች ብቻ ካለው ወይም በጭራሽ ከሌለው ይህ `'static` ሆኖ ሊመረጥ ይችላል።
    ///
    /// ይህ ተግባር ድርስ ትውስታ መልሶ ለማግኘት የሚችሉበት ምንም መንገድ የለም መሆኑን በቀር [`Box`] ላይ [`leak`][Box::leak] ተግባር ጋር ተመሳሳይ ነው.
    ///
    ///
    /// ይህ ተግባር በዋናነት ለፕሮግራሙ ሕይወት ቀሪ ለሆነ መረጃ ጠቃሚ ነው ፡፡
    /// የተመለሰውን ማጣቀሻ መተው የማስታወስ ችሎታ ያስከትላል።
    ///
    /// # Examples
    ///
    /// ቀላል አጠቃቀም
    ///
    /// ```
    /// let x = vec![1, 2, 3];
    /// let static_ref: &'static mut [usize] = x.leak();
    /// static_ref[0] += 1;
    /// assert_eq!(static_ref, &[2, 2, 3]);
    /// ```
    ///
    ///
    #[stable(feature = "vec_leak", since = "1.47.0")]
    #[inline]
    pub fn leak<'a>(self) -> &'a mut [T]
    where
        A: 'a,
    {
        Box::leak(self.into_boxed_slice())
    }

    /// ቀሪውን የ vector የመለዋወጥ አቅም እንደ `MaybeUninit<T>` ቁርጥራጭ ይመልሳል።
    ///
    /// የተመለሰው ቁራጭ vector ን በውሂብ ለመሙላት ሊያገለግል ይችላል (ለምሳሌ
    /// የ [`set_len`] ዘዴን በመጠቀም የተጀመረውን መረጃ ከማመልከትዎ በፊት ከፋይል በማንበብ) ፡፡
    ///
    ///
    /// [`set_len`]: Vec::set_len
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_spare_capacity, maybe_uninit_extra)]
    ///
    /// // vector ን ለ 10 አካላት በቂ ይመድቡ።
    /// let mut v = Vec::with_capacity(10);
    ///
    /// // የመጀመሪያዎቹን 3 አካላት ይሙሉ።
    /// let uninit = v.spare_capacity_mut();
    /// uninit[0].write(0);
    /// uninit[1].write(1);
    /// uninit[2].write(2);
    ///
    /// // የ vector የመጀመሪያዎቹን 3 አካላት እንደተነሳ ምልክት ያድርጉባቸው።
    /// unsafe {
    ///     v.set_len(3);
    /// }
    ///
    /// assert_eq!(&v, &[0, 1, 2]);
    /// ```
    ///
    #[unstable(feature = "vec_spare_capacity", issue = "75017")]
    #[inline]
    pub fn spare_capacity_mut(&mut self) -> &mut [MaybeUninit<T>] {
        // Note:
        // ይህ ዘዴ ከ‹XXXX›አንፃር አልተተገበረም ፣ ጠቋሚዎች ወደ መጠባበቂያው ዋጋ ቢስ እንዳይሆኑ ለመከላከል ፡፡
        //
        unsafe {
            slice::from_raw_parts_mut(
                self.as_mut_ptr().add(self.len) as *mut MaybeUninit<T>,
                self.buf.capacity() - self.len,
            )
        }
    }

    /// `MaybeUninit<T>` አንድ ቁራጭ እንደ vector የቀሩትን ትርፍ አቅም ጋር ተዳምሮ, `T` አንድ ቁራጭ እንደ vector ይዘት ያወጣል.
    ///
    /// የ ተመልሶ ትርፍ አቅም ቁራጭ የ [`set_len`] ስልት በመጠቀም አልተነሳም እንደ ውሂብ ምልክት በፊት (ለምሳሌ አንድ ፋይል በማንበብ) ውሂብ ጋር vector ለመሙላት ጥቅም ላይ ሊውል ይችላል.
    ///
    /// [`set_len`]: Vec::set_len
    ///
    /// ይህ ዝቅተኛ ደረጃ ኤ.ፒ.አይ. መሆኑን ልብ ይበሉ ፣ ለማመቻቸት ዓላማዎች በጥንቃቄ ጥቅም ላይ መዋል አለበት ፡፡
    /// የ `Vec` ላይ ለማያያዝ ውሂብ ከፈለጉ እርስዎ ትክክለኛ ፍላጎቶች ላይ በመመርኮዝ, [`push`], [`extend`], [`extend_from_slice`], [`extend_from_within`], [`insert`], [`append`], [`resize`] ወይም [`resize_with`] መጠቀም ይችላሉ.
    ///
    ///
    /// [`push`]: Vec::push
    /// [`extend`]: Vec::extend
    /// [`extend_from_slice`]: Vec::extend_from_slice
    /// [`extend_from_within`]: Vec::extend_from_within
    /// [`insert`]: Vec::insert
    /// [`append`]: Vec::append
    /// [`resize`]: Vec::resize
    /// [`resize_with`]: Vec::resize_with
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_split_at_spare, maybe_uninit_extra)]
    ///
    /// let mut v = vec![1, 1, 2];
    ///
    /// // ለ 10 አካላት በቂ የሆነ ተጨማሪ ቦታ ይያዙ ፡፡
    /// v.reserve(10);
    ///
    /// let (init, uninit) = v.split_at_spare_mut();
    /// let sum = init.iter().copied().sum::<u32>();
    ///
    /// // የሚቀጥሉትን 4 አካላት ይሙሉ።
    /// uninit[0].write(sum);
    /// uninit[1].write(sum * 2);
    /// uninit[2].write(sum * 3);
    /// uninit[3].write(sum * 4);
    ///
    /// // የ vector 4 ን አካላት እንደተጀመሩ ምልክት ያድርጉባቸው።
    /// unsafe {
    ///     let len = v.len();
    ///     v.set_len(len + 4);
    /// }
    ///
    /// assert_eq!(&v, &[1, 1, 2, 4, 8, 12, 16]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_split_at_spare", issue = "81944")]
    #[inline]
    pub fn split_at_spare_mut(&mut self) -> (&mut [T], &mut [MaybeUninit<T>]) {
        // SAFETY:
        // - ሌን ችላ ተብሏል እናም ስለዚህ በጭራሽ አልተለወጠም
        let (init, spare, _) = unsafe { self.split_at_spare_mut_with_len() };
        (init, spare)
    }

    /// ደህንነት-የተመለሰ .2 (&mut usize) መለወጥ `.set_len(_)` ን ከመጥራት ጋር ተመሳሳይ ነው ፡፡
    ///
    /// ይህ ዘዴ በ‹XXXX›ውስጥ በአንድ ጊዜ ለሁሉም የቪክቶሪያ ክፍሎች ልዩ መዳረሻ ለማግኘት ጥቅም ላይ ይውላል ፡፡
    unsafe fn split_at_spare_mut_with_len(
        &mut self,
    ) -> (&mut [T], &mut [MaybeUninit<T>], &mut usize) {
        let Range { start: ptr, end: spare_ptr } = self.as_mut_ptr_range();
        let spare_ptr = spare_ptr.cast::<MaybeUninit<T>>();
        let spare_len = self.buf.capacity() - self.len;

        // SAFETY:
        // - `ptr` ለኤክስኤክስኤክስኤክስ አባሎች ትክክለኛ መሆኑ የተረጋገጠ ነው
        // - `spare_ptr` ከጠባቂው አንድ አንድ ንጥረ ነገር እየጠቆመ ነው ፣ ስለሆነም በ `initialized` አይተላለፍም
        unsafe {
            let initialized = slice::from_raw_parts_mut(ptr, self.len);
            let spare = slice::from_raw_parts_mut(spare_ptr, spare_len);

            (initialized, spare, &mut self.len)
        }
    }
}

impl<T: Clone, A: Allocator> Vec<T, A> {
    /// `len` ከ `new_len` ጋር እኩል እንዲሆን የ `Vec` ን በቦታው መጠን ይቀይረዋል።
    ///
    /// `new_len` ከ `len` የበለጠ ከሆነ `Vec` በልዩነቱ ይራዘማል ፣ እያንዳንዱ ተጨማሪ ማስገቢያ በ `value` ተሞልቷል።
    ///
    /// `new_len` `len` ያነሰ ከሆነ, የ `Vec` በቀላሉ ተጎርደዋል.
    ///
    /// የተላለፈውን እሴት በአንድ ላይ ለማጣመር እንዲቻል ይህ ዘዴ [`Clone`] ን ለመተግበር `T` ን ይፈልጋል።
    /// የበለጠ ተለዋዋጭነት ከፈለጉ (ወይም ከ [`Clone`] ይልቅ በ [`Default`] ላይ መተማመን ከፈለጉ) [`Vec::resize_with`] ን ይጠቀሙ።
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec!["hello"];
    /// vec.resize(3, "world");
    /// assert_eq!(vec, ["hello", "world", "world"]);
    ///
    /// let mut vec = vec![1, 2, 3, 4];
    /// vec.resize(2, 0);
    /// assert_eq!(vec, [1, 2]);
    /// ```
    ///
    ///
    #[stable(feature = "vec_resize", since = "1.5.0")]
    pub fn resize(&mut self, new_len: usize, value: T) {
        let len = self.len();

        if new_len > len {
            self.extend_with(new_len - len, ExtendElement(value))
        } else {
            self.truncate(new_len);
        }
    }

    /// በተቆራረጠ የ `Vec` ውስጥ ሁሉንም ንጥረ ነገሮች ክሎኖች እና አባሪዎች ያያይዛቸዋል።
    ///
    /// በተቆራረጠ `other` ላይ ኢይትሬትስ ፣ እያንዳንዱን ንጥረ ነገር ክሎኖችን እና ከዚያ ወደዚህ `Vec` ያክላል ፡፡
    /// `other` vector በቅደም ተከተል ተላል isል።
    ///
    /// ይህም ይልቅ ገባዎች ጋር ሥራ ላይ ልዩ ነው በስተቀር ይህን ተግባር [`extend`] እንደ አንድ አይነት መሆኑን ልብ ይበሉ.
    ///
    /// ከሆነ እና Rust specialization ያገኛል ጊዜ ይህንን ተግባር አይቀርም የተቋረጠ ይሆናል (ነገር ግን አሁንም ይገኛል) ይሆናል.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.extend_from_slice(&[2, 3, 4]);
    /// assert_eq!(vec, [1, 2, 3, 4]);
    /// ```
    ///
    /// [`extend`]: Vec::extend
    ///
    #[stable(feature = "vec_extend_from_slice", since = "1.6.0")]
    pub fn extend_from_slice(&mut self, other: &[T]) {
        self.spec_extend(other.iter())
    }

    /// `src` ከ ቅጂዎች ክፍሎች vector መጨረሻ ድረስ ይደርሳሉ.
    ///
    /// ## Examples
    ///
    /// ```
    /// #![feature(vec_extend_from_within)]
    ///
    /// let mut vec = vec![0, 1, 2, 3, 4];
    ///
    /// vec.extend_from_within(2..);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4]);
    ///
    /// vec.extend_from_within(..2);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4, 0, 1]);
    ///
    /// vec.extend_from_within(4..8);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4, 0, 1, 4, 2, 3, 4]);
    /// ```
    #[unstable(feature = "vec_extend_from_within", issue = "81656")]
    pub fn extend_from_within<R>(&mut self, src: R)
    where
        R: RangeBounds<usize>,
    {
        let range = slice::range(src, ..self.len());
        self.reserve(range.len());

        // SAFETY:
        // - `slice::range` የተሰጠው ክልል ለራስ መረጃ ጠቋሚ ትክክለኛ መሆኑን ያረጋግጣል
        unsafe {
            self.spec_extend_from_within(range);
        }
    }
}

// ይህ ኮድ `extend_with_{element,default}` generalizes.
trait ExtendWith<T> {
    fn next(&mut self) -> T;
    fn last(self) -> T;
}

struct ExtendElement<T>(T);
impl<T: Clone> ExtendWith<T> for ExtendElement<T> {
    fn next(&mut self) -> T {
        self.0.clone()
    }
    fn last(self) -> T {
        self.0
    }
}

struct ExtendDefault;
impl<T: Default> ExtendWith<T> for ExtendDefault {
    fn next(&mut self) -> T {
        Default::default()
    }
    fn last(self) -> T {
        Default::default()
    }
}

struct ExtendFunc<F>(F);
impl<T, F: FnMut() -> T> ExtendWith<T> for ExtendFunc<F> {
    fn next(&mut self) -> T {
        (self.0)()
    }
    fn last(mut self) -> T {
        (self.0)()
    }
}

impl<T, A: Allocator> Vec<T, A> {
    /// የተሰጠው ጄኔሬተር በመጠቀም, `n` እሴቶች በ vector ማራዘም.
    fn extend_with<E: ExtendWith<T>>(&mut self, n: usize, mut value: E) {
        self.reserve(n);

        unsafe {
            let mut ptr = self.as_mut_ptr().add(self.len());
            // አሰባሳቢው በ `ptr` እስከ self.set_len() በኩል ያለውን መደብር የማይገነዘበው ሳንካ ዙሪያ ለመስራት SetLenOnDrop ን ይጠቀሙ ስያሜ አይስጡ ፡፡
            //
            //
            let mut local_len = SetLenOnDrop::new(&mut self.len);

            // ከመጨረሻው በስተቀር ሁሉንም አካላት ይጻፉ
            for _ in 1..n {
                ptr::write(ptr, value.next());
                ptr = ptr.offset(1);
                // next() panics ከሆነ በእያንዳንዱ እርምጃ ውስጥ ርዝመቱን ይጨምሩ
                local_len.increment_len(1);
            }

            if n > 0 {
                // እኛ ሳያስፈልግ በክሎኒንግ ያለ በቀጥታ የመጨረሻ አባል መጻፍ ይችላል
                ptr::write(ptr, value.last());
                local_len.increment_len(1);
            }

            // ወሰን ጠባቂ በ ሌን ስብስብ
        }
    }
}

impl<T: PartialEq, A: Allocator> Vec<T, A> {
    /// በ [`PartialEq`] trait ትግበራ መሠረት በ vector ውስጥ ተከታታይ ተደጋጋሚ ንጥረ ነገሮችን ያስወግዳል።
    ///
    ///
    /// vector ከተደረደረ ይህ ሁሉንም ብዜቶች ያስወግዳል።
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 2, 3, 2];
    ///
    /// vec.dedup();
    ///
    /// assert_eq!(vec, [1, 2, 3, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn dedup(&mut self) {
        self.dedup_by(|a, b| a == b)
    }
}

////////////////////////////////////////////////////////////////////////////////
// የውስጥ ዘዴዎች እና ተግባራት
////////////////////////////////////////////////////////////////////////////////

#[doc(hidden)]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_elem<T: Clone>(elem: T, n: usize) -> Vec<T> {
    <T as SpecFromElem>::from_elem(elem, n, Global)
}

#[doc(hidden)]
#[unstable(feature = "allocator_api", issue = "32838")]
pub fn from_elem_in<T: Clone, A: Allocator>(elem: T, n: usize, alloc: A) -> Vec<T, A> {
    <T as SpecFromElem>::from_elem(elem, n, alloc)
}

trait ExtendFromWithinSpec {
    /// # Safety
    ///
    /// - `src` ትክክለኛ መረጃ ጠቋሚ መሆን አለበት
    /// - `self.capacity() - self.len()` `>= src.len()` መሆን አለበት
    unsafe fn spec_extend_from_within(&mut self, src: Range<usize>);
}

impl<T: Clone, A: Allocator> ExtendFromWithinSpec for Vec<T, A> {
    default unsafe fn spec_extend_from_within(&mut self, src: Range<usize>) {
        // SAFETY:
        // - ሌን የሚጨምረው ንጥረ ነገሮችን ከጀመሩ በኋላ ብቻ ነው
        let (this, spare, len) = unsafe { self.split_at_spare_mut_with_len() };

        // SAFETY:
        // - የደዋይ ጉባ Zዎች‹src›ትክክለኛ መረጃ ጠቋሚ ነው
        let to_clone = unsafe { this.get_unchecked(src) };

        to_clone
            .iter()
            .cloned()
            .zip(spare.iter_mut())
            .map(|(src, dst)| dst.write(src))
            // Note:
            // - ኤለመንት በ `MaybeUninit::write` ተጀምሯል ፣ ስለሆነም ብድርን መጨመር ችግር የለውም
            // - ፍሳሾችን ለመከላከል ከእያንዳንዱ ንጥረ ነገር በኋላ ሌን ጨምሯል (እትም #82533 ን ይመልከቱ)
            .for_each(|_| *len += 1);
    }
}

impl<T: Copy, A: Allocator> ExtendFromWithinSpec for Vec<T, A> {
    unsafe fn spec_extend_from_within(&mut self, src: Range<usize>) {
        let count = src.len();
        {
            let (init, spare) = self.split_at_spare_mut();

            // SAFETY:
            // - `src` ትክክለኛ መረጃ ጠቋሚ ነው መሆኑን ደዋይ guaratees
            let source = unsafe { init.get_unchecked(src) };

            // SAFETY:
            // - ሁለቱም ጠቋሚዎች የተፈጠሩት በልዩ ቁርጥራጭ ማጣቀሻዎች (`&mut [_]`) ስለሆነ ትክክለኛ እና መደራረብ የለባቸውም ፡፡
            //
            // - ንጥረ ነገሮች ናቸው: ቅዳ ጋር ያለው እሺ የመጀመሪያ እሴቶች ጋር ምንም ነገር ሳናደርግ, እነሱን ለመቅዳት ስለዚህ
            // - `count` ከ‹XXXX›ብድር ጋር እኩል ነው ፣ ስለሆነም ምንጭ ለ‹`count`›ንባቦች ልክ ነው
            // - `.reserve(count)` XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX ላይ ይከፍላል
            //
            //
            //
            unsafe { ptr::copy_nonoverlapping(source.as_ptr(), spare.as_mut_ptr() as _, count) };
        }

        // SAFETY:
        // - ንጥረ ነገሮቹ በ `copy_nonoverlapping` ተጀምረዋል
        self.len += count;
    }
}

////////////////////////////////////////////////////////////////////////////////
// ለ Zec የተለመዱ የ trait ትግበራዎች
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> ops::Deref for Vec<T, A> {
    type Target = [T];

    fn deref(&self) -> &[T] {
        unsafe { slice::from_raw_parts(self.as_ptr(), self.len) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> ops::DerefMut for Vec<T, A> {
    fn deref_mut(&mut self) -> &mut [T] {
        unsafe { slice::from_raw_parts_mut(self.as_mut_ptr(), self.len) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone, A: Allocator + Clone> Clone for Vec<T, A> {
    #[cfg(not(test))]
    fn clone(&self) -> Self {
        let alloc = self.allocator().clone();
        <[T]>::to_vec_in(&**self, alloc)
    }

    // HACK(japaric): ከ cfg(test) ጋር ለዚህ ዘዴ ትርጉም የሚያስፈልገው ተፈጥሯዊ የ `[T]::to_vec` ዘዴ አይገኝም ፡፡
    // ይልቅ cfg(test) ማሳሰቢያ ተጨማሪ መረጃ ለማግኘት slice.rs ውስጥ slice::hack ሞዱል ለማየት ጋር ብቻ ነው የሚገኘው ያለውን `slice::to_vec` ተግባር ይጠቀሙ
    //
    //
    #[cfg(test)]
    fn clone(&self) -> Self {
        let alloc = self.allocator().clone();
        crate::slice::to_vec(&**self, alloc)
    }

    fn clone_from(&mut self, other: &Self) {
        // እንዲጻፍበት አይሆንም ማንኛውንም ነገር መጣል
        self.truncate(other.len());

        // self.len <= other.len ከላይ ባለው መጥረጊያ ምክንያት ፣ ስለሆነም እዚህ ያሉት ቁርጥራጮች ሁል ጊዜ ወሰን አላቸው።
        //
        let (init, tail) = other.split_at(self.len());

        // ያሉትን እሴቶች allocations/resources ን እንደገና ይጠቀሙ።
        self.clone_from_slice(init);
        self.extend_from_slice(tail);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Hash, A: Allocator> Hash for Vec<T, A> {
    #[inline]
    fn hash<H: Hasher>(&self, state: &mut H) {
        Hash::hash(&**self, state)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "vector indices are of type `usize` or ranges of `usize`",
    label = "vector indices are of type `usize` or ranges of `usize`"
)]
impl<T, I: SliceIndex<[T]>, A: Allocator> Index<I> for Vec<T, A> {
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &Self::Output {
        Index::index(&**self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "vector indices are of type `usize` or ranges of `usize`",
    label = "vector indices are of type `usize` or ranges of `usize`"
)]
impl<T, I: SliceIndex<[T]>, A: Allocator> IndexMut<I> for Vec<T, A> {
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut Self::Output {
        IndexMut::index_mut(&mut **self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> FromIterator<T> for Vec<T> {
    #[inline]
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> Vec<T> {
        <Self as SpecFromIter<T, I::IntoIter>>::from_iter(iter.into_iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> IntoIterator for Vec<T, A> {
    type Item = T;
    type IntoIter = IntoIter<T, A>;

    /// የሚበላ ድግግሞሽ ይፈጥራል ፣ ማለትም እያንዳንዱን እሴት ከ vector (ከመጀመሪያ እስከ መጨረሻ) የሚያንቀሳቅሰው።
    /// ይህንን ከጠራ በኋላ vector መጠቀም አይቻልም ፡፡
    ///
    /// # Examples
    ///
    /// ```
    /// let v = vec!["a".to_string(), "b".to_string()];
    /// for s in v.into_iter() {
    ///     // s የ &String ሳይሆን አይነት String አለው
    ///     println!("{}", s);
    /// }
    /// ```
    ///
    #[inline]
    fn into_iter(self) -> IntoIter<T, A> {
        unsafe {
            let mut me = ManuallyDrop::new(self);
            let alloc = ptr::read(me.allocator());
            let begin = me.as_mut_ptr();
            let end = if mem::size_of::<T>() == 0 {
                arith_offset(begin as *const i8, me.len() as isize) as *const T
            } else {
                begin.add(me.len()) as *const T
            };
            let cap = me.buf.capacity();
            IntoIter {
                buf: NonNull::new_unchecked(begin),
                phantom: PhantomData,
                cap,
                alloc,
                ptr: begin,
                end,
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, A: Allocator> IntoIterator for &'a Vec<T, A> {
    type Item = &'a T;
    type IntoIter = slice::Iter<'a, T>;

    fn into_iter(self) -> slice::Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, A: Allocator> IntoIterator for &'a mut Vec<T, A> {
    type Item = &'a mut T;
    type IntoIter = slice::IterMut<'a, T>;

    fn into_iter(self) -> slice::IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> Extend<T> for Vec<T, A> {
    #[inline]
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        <Self as SpecExtend<T, I::IntoIter>>::spec_extend(self, iter.into_iter())
    }

    #[inline]
    fn extend_one(&mut self, item: T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

impl<T, A: Allocator> Vec<T, A> {
    // ለማመልከት ተጨማሪ ማመቻቸት ከሌላቸው የተለያዩ የ SpecFrom/SpecExtend ትግበራዎች ውክልና የሚሰጡበት የቅጠል ዘዴ
    //
    fn extend_desugared<I: Iterator<Item = T>>(&mut self, mut iterator: I) {
        // ይህ አጠቃላይ ለተደጋጋሚ ሁኔታ ነው.
        //
        // ይህ ተግባር የሞራል አቻ መሆን አለበት-
        //
        //      ለንጥል በአመልካች ውስጥ {
        //          self.push(item);
        //      }
        while let Some(element) = iterator.next() {
            let len = self.len();
            if len == self.capacity() {
                let (lower, _) = iterator.size_hint();
                self.reserve(lower.saturating_add(1));
            }
            unsafe {
                ptr::write(self.as_mut_ptr().add(len), element);
                // የአድራሻ ቦታውን መመደብ ስለምንችል NB ሊፈስ አይችልም
                self.set_len(len + 1);
            }
        }
    }

    /// በተጠቀሰው የ `replace_with` ድግግሞሽ በ vector ውስጥ የተገለጸውን ክልል የሚተካ እና የተወገዱትን ዕቃዎች የሚያመነጭ የስፕሊንግ ድግግሞሽ ይፈጥራል ፡፡
    ///
    /// `replace_with` እንደ `range` ተመሳሳይ ርዝመት መሆን አያስፈልገውም።
    ///
    /// `range` እስከ መጨረሻው ተደጋጋሚው ባይጠጣም ይወገዳል ፡፡
    ///
    /// የ `Splice` እሴት ከፈሰሰ ከ vector ምን ያህል ንጥረ ነገሮች እንደሚወገዱ አልተገለጸም።
    ///
    /// የግብዓት ጠቋሚ `replace_with` የሚበላው የ `Splice` እሴት ሲወድቅ ብቻ ነው።
    ///
    /// ይህ በጣም ጥሩ ነው
    ///
    /// * ጅራት (`range` በኋላ vector ውስጥ ንጥረ), ባዶ ነው
    /// * ወይም `replace_with` `ክልል` ርዝመት ያነሰ ወይም እኩል ክፍሎችን ያፈራላቸዋል
    /// * ወይም የእሱ `size_hint()` ዝቅተኛ ወርድ ትክክለኛ ነው።
    ///
    /// አለበለዚያ ጊዜያዊ vector ይመደባል እና ጅራቱ ሁለት ጊዜ ይንቀሳቀሳል።
    ///
    /// # Panics
    ///
    /// Panics የመነሻው ነጥብ ከመጨረሻው ነጥብ የበለጠ ከሆነ ወይም የመጨረሻው ነጥብ ከ vector ርዝመት የበለጠ ከሆነ።
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// let new = [7, 8];
    /// let u: Vec<_> = v.splice(..2, new.iter().cloned()).collect();
    /// assert_eq!(v, &[7, 8, 3]);
    /// assert_eq!(u, &[1, 2]);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "vec_splice", since = "1.21.0")]
    pub fn splice<R, I>(&mut self, range: R, replace_with: I) -> Splice<'_, I::IntoIter, A>
    where
        R: RangeBounds<usize>,
        I: IntoIterator<Item = T>,
    {
        Splice { drain: self.drain(range), replace_with: replace_with.into_iter() }
    }

    /// አንድ ንጥረ ነገር መወገድ እንዳለበት ለመለየት መዘጋትን የሚጠቀም ተደጋጋሚ ተደጋጋሚ ይፈጥራል።
    ///
    /// መዝጊያው ወደ እውነት ከተመለሰ ፣ ንጥረ ነገሩ ይወገዳል እና ይሰጣል ፡፡
    /// የ መዘጋት ሐሰት ይመልሳል ከሆነ ንጥረ ነገር ወደ vector ውስጥ ይቆያል እና ለተደጋጋሚ በ ተወ አይደረግም.
    ///
    /// ይህንን ዘዴ መጠቀም ከሚከተለው ኮድ ጋር እኩል ነው-
    ///
    /// ```
    /// # let some_predicate = |x: &mut i32| { *x == 2 || *x == 3 || *x == 6 };
    /// # let mut vec = vec![1, 2, 3, 4, 5, 6];
    /// let mut i = 0;
    /// while i != vec.len() {
    ///     if some_predicate(&mut vec[i]) {
    ///         let val = vec.remove(i);
    ///         // የእርስዎ ኮድ እዚህ
    ///     } else {
    ///         i += 1;
    ///     }
    /// }
    ///
    /// # assert_eq!(vec, vec![1, 4, 5]);
    /// ```
    ///
    /// ግን `drain_filter` ለመጠቀም ቀላል ነው።
    /// `drain_filter` እንዲሁም ይበልጥ ውጤታማ ነው ፣ ምክንያቱም የብዙዎችን ብዛት በጅምላ ወደኋላ መለወጥ ይችላል።
    ///
    /// `drain_filter` እርስዎ ለማቆየትም ሆነ ለመረጡት ቢመርጡም በማጣሪያው መዘጋት ውስጥ ያሉትን እያንዳንዱን ንጥረ ነገሮች እንዲለውጡ ያስችልዎታል።
    ///
    ///
    /// # Examples
    ///
    /// የመጀመሪያው ድልድል ዳግም, evens እና አሸናፊውን ወደ ድርድር ስንጠቃ:
    ///
    /// ```
    /// #![feature(drain_filter)]
    /// let mut numbers = vec![1, 2, 3, 4, 5, 6, 8, 9, 11, 13, 14, 15];
    ///
    /// let evens = numbers.drain_filter(|x| *x % 2 == 0).collect::<Vec<_>>();
    /// let odds = numbers;
    ///
    /// assert_eq!(evens, vec![2, 4, 6, 8, 14]);
    /// assert_eq!(odds, vec![1, 3, 5, 9, 11, 13, 15]);
    /// ```
    ///
    #[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
    pub fn drain_filter<F>(&mut self, filter: F) -> DrainFilter<'_, T, F, A>
    where
        F: FnMut(&mut T) -> bool,
    {
        let old_len = self.len();

        // በእኛ ላይ ዘብ ድርስ መሞላታችሁን (በሚያወጣበት እንጥልጥሎች)
        unsafe {
            self.set_len(0);
        }

        DrainFilter { vec: self, idx: 0, del: 0, old_len, pred: filter, panic_flag: false }
    }
}

/// ትግበራ ያራዝሙ መሆኑን Vec ላይ ከእነርሱ እንዲተገበር በፊት ማጣቀሻዎች ውጭ ቅጂዎች ክፍሎች.
///
/// ይህ አተገባበር በአንድ ጊዜ መላውን ቁራጭ ለማያያዝ [`copy_from_slice`] ይጠቀማል የት ቁራጭ iterators, ለ ልዩ ነው.
///
///
/// [`copy_from_slice`]: slice::copy_from_slice
#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: Copy + 'a, A: Allocator + 'a> Extend<&'a T> for Vec<T, A> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.spec_extend(iter.into_iter())
    }

    #[inline]
    fn extend_one(&mut self, &item: &'a T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

/// የ vectors ንፅፅር ይተገበራል ፣ [lexicographically](core::cmp::Ord#lexicographical-comparison).
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialOrd, A: Allocator> PartialOrd for Vec<T, A> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        PartialOrd::partial_cmp(&**self, &**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Eq, A: Allocator> Eq for Vec<T, A> {}

/// vectors ልጅ ማዘዝ እንደሚተገብር, [lexicographically](core::cmp::Ord#lexicographical-comparison).
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord, A: Allocator> Ord for Vec<T, A> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        Ord::cmp(&**self, &**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T, A: Allocator> Drop for Vec<T, A> {
    fn drop(&mut self) {
        unsafe {
            // [T] ለ አጠቃቀም ጠብታ ደካማው አስፈላጊ አይነት እንደ vector ውስጥ ያሉትን ክፍሎች የሚያመለክት አንድ ጥሬ ቁራጭ መጠቀም;
            //
            // በተወሰኑ ሁኔታዎች ውስጥ ፀንቶ ጥያቄዎችን ማስወገድ ይችላል
            ptr::drop_in_place(ptr::slice_from_raw_parts_mut(self.as_mut_ptr(), self.len))
        }
        // RawVec የስምምነት ቦታን ያስተናግዳል
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for Vec<T> {
    /// አንድ ባዶ `Vec<T>` ይፈጥራል.
    fn default() -> Vec<T> {
        Vec::new()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug, A: Allocator> fmt::Debug for Vec<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> AsRef<Vec<T, A>> for Vec<T, A> {
    fn as_ref(&self) -> &Vec<T, A> {
        self
    }
}

#[stable(feature = "vec_as_mut", since = "1.5.0")]
impl<T, A: Allocator> AsMut<Vec<T, A>> for Vec<T, A> {
    fn as_mut(&mut self) -> &mut Vec<T, A> {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> AsRef<[T]> for Vec<T, A> {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "vec_as_mut", since = "1.5.0")]
impl<T, A: Allocator> AsMut<[T]> for Vec<T, A> {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> From<&[T]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: &[T]) -> Vec<T> {
        s.to_vec()
    }
    #[cfg(test)]
    fn from(s: &[T]) -> Vec<T> {
        crate::slice::to_vec(s, Global)
    }
}

#[stable(feature = "vec_from_mut", since = "1.19.0")]
impl<T: Clone> From<&mut [T]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: &mut [T]) -> Vec<T> {
        s.to_vec()
    }
    #[cfg(test)]
    fn from(s: &mut [T]) -> Vec<T> {
        crate::slice::to_vec(s, Global)
    }
}

#[stable(feature = "vec_from_array", since = "1.44.0")]
impl<T, const N: usize> From<[T; N]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: [T; N]) -> Vec<T> {
        <[T]>::into_vec(box s)
    }
    #[cfg(test)]
    fn from(s: [T; N]) -> Vec<T> {
        crate::slice::into_vec(box s)
    }
}

#[stable(feature = "vec_from_cow_slice", since = "1.14.0")]
impl<'a, T> From<Cow<'a, [T]>> for Vec<T>
where
    [T]: ToOwned<Owned = Vec<T>>,
{
    fn from(s: Cow<'a, [T]>) -> Vec<T> {
        s.into_owned()
    }
}

// note: ሙከራ እዚህ ስህተቶችን የሚያመጣውን በ libstd ውስጥ ይጎትታል
#[cfg(not(test))]
#[stable(feature = "vec_from_box", since = "1.18.0")]
impl<T, A: Allocator> From<Box<[T], A>> for Vec<T, A> {
    fn from(s: Box<[T], A>) -> Self {
        let len = s.len();
        Self { buf: RawVec::from_box(s), len }
    }
}

// note: ሙከራ እዚህ ስህተቶችን የሚያመጣውን በ libstd ውስጥ ይጎትታል
#[cfg(not(test))]
#[stable(feature = "box_from_vec", since = "1.20.0")]
impl<T, A: Allocator> From<Vec<T, A>> for Box<[T], A> {
    fn from(v: Vec<T, A>) -> Self {
        v.into_boxed_slice()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl From<&str> for Vec<u8> {
    fn from(s: &str) -> Vec<u8> {
        From::from(s.as_bytes())
    }
}

#[stable(feature = "array_try_from_vec", since = "1.48.0")]
impl<T, A: Allocator, const N: usize> TryFrom<Vec<T, A>> for [T; N] {
    type Error = Vec<T, A>;

    /// መጠኑን በትክክል የተጠየቀውን ድርድር ይህ የሚዛመድ ከሆነ, ድርድር እንደ `Vec<T>` በሙሉ ይዘቶች ያገኛል.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::convert::TryInto;
    /// assert_eq!(vec![1, 2, 3].try_into(), Ok([1, 2, 3]));
    /// assert_eq!(<Vec<i32>>::new().try_into(), Ok([]));
    /// ```
    ///
    /// ርዝመቱ የማይዛመድ ከሆነ ግብዓቱ በ `Err` ተመልሶ ይመጣል:
    ///
    /// ```
    /// use std::convert::TryInto;
    /// let r: Result<[i32; 4], _> = (0..10).collect::<Vec<_>>().try_into();
    /// assert_eq!(r, Err(vec![0, 1, 2, 3, 4, 5, 6, 7, 8, 9]));
    /// ```
    ///
    /// እርስዎ ልክ `Vec<T>` አንድ ቅጥያ በማግኘት ጋር ጥሩ ከሆንክ, በመጀመሪያ [`.truncate(N)`](Vec::truncate) መደወል ይችላሉ.
    ///
    /// ```
    /// use std::convert::TryInto;
    /// let mut v = String::from("hello world").into_bytes();
    /// v.sort();
    /// v.truncate(2);
    /// let [a, b]: [_; 2] = v.try_into().unwrap();
    /// assert_eq!(a, b' ');
    /// assert_eq!(b, b'd');
    /// ```
    fn try_from(mut vec: Vec<T, A>) -> Result<[T; N], Vec<T, A>> {
        if vec.len() != N {
            return Err(vec);
        }

        // ደህንነት: `.set_len(0)` ሁልጊዜ ድምፅ ነው.
        unsafe { vec.set_len(0) };

        // ደህንነት:-አንድ `የቪኬ` ጠቋሚ ሁልጊዜ በትክክል ተስተካክሏል ፣ እና
        // ድርድሩ የሚያስፈልገውን አሰላለፍ ከእቃዎቹ ጋር አንድ ነው።
        // በቂ ዕቃዎች እንዳሉን ቀደም ብለን ፈትሸናል ፡፡
        // እቃዎቹ `set_len` ለ `Vec` እንዲሁ እንዳይጥሉ ስለሚነግራቸው እቃዎቹ በእጥፍ አይወርዱም ፡፡
        //
        let array = unsafe { ptr::read(vec.as_ptr() as *const [T; N]) };
        Ok(array)
    }
}