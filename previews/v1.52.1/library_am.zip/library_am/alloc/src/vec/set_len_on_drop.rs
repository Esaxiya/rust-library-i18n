// የ `SetLenOnDrop` እሴቱ ከአቅሙ በላይ በሚሆንበት ጊዜ የቬክሱን ርዝመት ያዘጋጁ።
//
// ሀሳቡ-በ SetLenOnDrop ውስጥ ያለው የርዝመት መስክ አመቻቹ በቪክ የመረጃ ጠቋሚ በኩል ከማንኛውም መደብሮች ጋር መጠሪያ የማይሆንበት አካባቢያዊ ተለዋዋጭ ነው ፡፡
// ይህ በቅፅል ስም ትንታኔ ጉዳይ #32155 መፍትሄ ነው
//
pub(super) struct SetLenOnDrop<'a> {
    len: &'a mut usize,
    local_len: usize,
}

impl<'a> SetLenOnDrop<'a> {
    #[inline]
    pub(super) fn new(len: &'a mut usize) -> Self {
        SetLenOnDrop { local_len: *len, len }
    }

    #[inline]
    pub(super) fn increment_len(&mut self, increment: usize) {
        self.local_len += increment;
    }
}

impl Drop for SetLenOnDrop<'_> {
    #[inline]
    fn drop(&mut self) {
        *self.len = self.local_len;
    }
}