//! የማህደረ ትውስታ ምደባ ኤ.ፒ.አይ.ዎች

#![stable(feature = "alloc_module", since = "1.28.0")]

#[cfg(not(test))]
use core::intrinsics;
use core::intrinsics::{min_align_of_val, size_of_val};

use core::ptr::Unique;
#[cfg(not(test))]
use core::ptr::{self, NonNull};

#[stable(feature = "alloc_module", since = "1.28.0")]
#[doc(inline)]
pub use core::alloc::*;

#[cfg(test)]
mod tests;

extern "Rust" {
    // ዓለም አቀፋዊን ለመደወል እነዚህ የአስማት ምልክቶች ናቸው ፡፡rustc `__rg_alloc` ወዘተ ብለው ለመጥራት ያመነጫቸዋል ፡፡
    // የ `#[global_allocator]` ባህርይ ካለ (ማክሮን የሚይዘው ኮድ የሚያስፋፋው ኮድ እነዚህን ተግባራት ያመነጫል) ፣ ወይም በ libstd ውስጥ ያሉትን ነባር ትግበራዎች ለመደወል (`__rdl_alloc` ወዘተ) ፡፡
    //
    // በ `library/std/src/alloc.rs` ውስጥ) አለበለዚያ።
    // የኤልኤልኤምኤም‹rustc fork›እንደዚሁም እንደ `malloc` ፣ `realloc` እና `free` ያሉ እነሱን ማሻሻል እንዲችሉ እነዚህን የተግባር ስሞች ልዩ ጉዳዮች ያደርጋሉ ፡፡
    //
    //
    #[rustc_allocator]
    #[rustc_allocator_nounwind]
    fn __rust_alloc(size: usize, align: usize) -> *mut u8;
    #[rustc_allocator_nounwind]
    fn __rust_dealloc(ptr: *mut u8, size: usize, align: usize);
    #[rustc_allocator_nounwind]
    fn __rust_realloc(ptr: *mut u8, old_size: usize, align: usize, new_size: usize) -> *mut u8;
    #[rustc_allocator_nounwind]
    fn __rust_alloc_zeroed(size: usize, align: usize) -> *mut u8;
}

/// ዓለም አቀፍ የማስታወሻ አከፋፋይ.
///
/// ይህ ዓይነቱ ካለ ካለ በ `#[global_allocator]` አይነታ ለተመዘገበው ገንዘብ አቅራቢ ጥሪዎችን በማስተላለፍ የ [`Allocator`] trait ን ይተገበራል ፣ ወይም የ‹`std` crate›ነባሪ ፡፡
///
///
/// Note: ይህ ዓይነቱ ያልተረጋጋ ቢሆንም ፣ የሚሰጠው ተግባራዊነት በ [free functions in `alloc`](self#functions) በኩል ሊደረስበት ይችላል።
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[derive(Copy, Clone, Default, Debug)]
#[cfg(not(test))]
pub struct Global;

#[cfg(test)]
pub use std::alloc::Global;

/// ማህደረ ትውስታን ከአለም አቀፉ አከፋፋይ ጋር ይመድቡ።
///
/// ይህ ተግባር ካለ ካለ በ `#[global_allocator]` አይነታ በተመዘገበው የአከፋፋይ [`GlobalAlloc::alloc`] ዘዴ ወይም በ‹`std` crate›ነባሪ ይጠራል ፡፡
///
///
/// እሱ እና የ [`Allocator`] trait ሲረጋጉ ይህ ተግባር የ [`Global`] ዓይነት የ `alloc` ዘዴን እንደሚደግፍ ይጠበቃል ፡፡
///
/// # Safety
///
/// [`GlobalAlloc::alloc`] ን ይመልከቱ።
///
/// # Examples
///
/// ```
/// use std::alloc::{alloc, dealloc, Layout};
///
/// unsafe {
///     let layout = Layout::new::<u16>();
///     let ptr = alloc(layout);
///
///     *(ptr as *mut u16) = 42;
///     assert_eq!(*(ptr as *mut u16), 42);
///
///     dealloc(ptr, layout);
/// }
/// ```
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn alloc(layout: Layout) -> *mut u8 {
    unsafe { __rust_alloc(layout.size(), layout.align()) }
}

/// ማህደረ ትውስታን ከዓለም አቀፉ አከፋፋይ ያቅርቡ።
///
/// ይህ ተግባር ካለ ካለ በ `#[global_allocator]` አይነታ በተመዘገበው የአከፋፋይ [`GlobalAlloc::dealloc`] ዘዴ ወይም በ‹`std` crate›ነባሪ ይጠራል ፡፡
///
///
/// እሱ እና የ [`Allocator`] trait ሲረጋጉ ይህ ተግባር የ [`Global`] ዓይነት የ `dealloc` ዘዴን እንደሚደግፍ ይጠበቃል ፡፡
///
/// # Safety
///
/// [`GlobalAlloc::dealloc`] ን ይመልከቱ።
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn dealloc(ptr: *mut u8, layout: Layout) {
    unsafe { __rust_dealloc(ptr, layout.size(), layout.align()) }
}

/// ማህደረ ትውስታን ከዓለም አቀፉ አከፋፋይ ጋር እንደገና ማካፈል።
///
/// ይህ ተግባር ካለ ካለ በ `#[global_allocator]` አይነታ በተመዘገበው የአከፋፋይ [`GlobalAlloc::realloc`] ዘዴ ወይም በ‹`std` crate›ነባሪ ይጠራል ፡፡
///
///
/// እሱ እና የ [`Allocator`] trait ሲረጋጉ ይህ ተግባር የ [`Global`] ዓይነት የ `realloc` ዘዴን እንደሚደግፍ ይጠበቃል ፡፡
///
/// # Safety
///
/// [`GlobalAlloc::realloc`] ን ይመልከቱ።
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn realloc(ptr: *mut u8, layout: Layout, new_size: usize) -> *mut u8 {
    unsafe { __rust_realloc(ptr, layout.size(), layout.align(), new_size) }
}

/// ዜሮ-ተኮር ማህደረ ትውስታን ከዓለም አቀፉ አከፋፋይ ይመድቡ።
///
/// ይህ ተግባር ካለ ካለ በ `#[global_allocator]` አይነታ በተመዘገበው የአከፋፋይ [`GlobalAlloc::alloc_zeroed`] ዘዴ ወይም በ‹`std` crate›ነባሪ ይጠራል ፡፡
///
///
/// እሱ እና የ [`Allocator`] trait ሲረጋጉ ይህ ተግባር የ [`Global`] ዓይነት የ `alloc_zeroed` ዘዴን እንደሚደግፍ ይጠበቃል ፡፡
///
/// # Safety
///
/// [`GlobalAlloc::alloc_zeroed`] ን ይመልከቱ።
///
/// # Examples
///
/// ```
/// use std::alloc::{alloc_zeroed, dealloc, Layout};
///
/// unsafe {
///     let layout = Layout::new::<u16>();
///     let ptr = alloc_zeroed(layout);
///
///     assert_eq!(*(ptr as *mut u16), 0);
///
///     dealloc(ptr, layout);
/// }
/// ```
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn alloc_zeroed(layout: Layout) -> *mut u8 {
    unsafe { __rust_alloc_zeroed(layout.size(), layout.align()) }
}

#[cfg(not(test))]
impl Global {
    #[inline]
    fn alloc_impl(&self, layout: Layout, zeroed: bool) -> Result<NonNull<[u8]>, AllocError> {
        match layout.size() {
            0 => Ok(NonNull::slice_from_raw_parts(layout.dangling(), 0)),
            // ደህንነት `layout` በመጠን ዜሮ ያልሆነ ነው ፣
            size => unsafe {
                let raw_ptr = if zeroed { alloc_zeroed(layout) } else { alloc(layout) };
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                Ok(NonNull::slice_from_raw_parts(ptr, size))
            },
        }
    }

    // ደህንነት-እንደ `Allocator::grow` ተመሳሳይ
    #[inline]
    unsafe fn grow_impl(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
        zeroed: bool,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        match old_layout.size() {
            0 => self.alloc_impl(new_layout, zeroed),

            // ደህንነት `old_size` ከ `new_size` ይበልጣል ወይም እኩል ስለሆነ `new_size` ዜሮ አይደለም
            // በደህንነት ሁኔታዎች እንደ አስፈላጊነቱ ፡፡ሌሎች ሁኔታዎች በተጠሪው ሊፀኑላቸው ይገባል
            old_size if old_layout.align() == new_layout.align() => unsafe {
                let new_size = new_layout.size();

                // `realloc` ምናልባት ለ‹XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX ወይም XIIXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX›ወይም ከ‹XXXXX›››››››››››››››››››››››››››››››››››››››››››››››››››››››ን ምርመራ ወይም ቼኮች
                intrinsics::assume(new_size >= old_layout.size());

                let raw_ptr = realloc(ptr.as_ptr(), old_layout, new_size);
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                if zeroed {
                    raw_ptr.add(old_size).write_bytes(0, new_size - old_size);
                }
                Ok(NonNull::slice_from_raw_parts(ptr, new_size))
            },

            // ደህንነት: `new_layout.size()` የበለጠ መሆን አለበት; ምክንያቱም ወይም `old_size` ጋር እኩል በላይ
            // የድሮው እና አዲሱ የማስታወሻ ምደባ ለንባብ እና ለ `old_size` ባይት ይጽፋል ፡፡
            // እንዲሁም ፣ የድሮው ምደባ ገና አልተከፋፈለም ፣ `new_ptr` ን መደራረብ አይችልም።
            // ስለዚህ ወደ `copy_nonoverlapping` የሚደረገው ጥሪ ደህንነቱ የተጠበቀ ነው።
            // ለ‹`dealloc` X›የደኅንነት ውል በተጠሪው መደገፍ አለበት ፡፡
            old_size => unsafe {
                let new_ptr = self.alloc_impl(new_layout, zeroed)?;
                ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_size);
                self.deallocate(ptr, old_layout);
                Ok(new_ptr)
            },
        }
    }
}

#[unstable(feature = "allocator_api", issue = "32838")]
#[cfg(not(test))]
unsafe impl Allocator for Global {
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        self.alloc_impl(layout, false)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        self.alloc_impl(layout, true)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        if layout.size() != 0 {
            // ደህንነት `layout` በመጠን ዜሮ ያልሆነ ነው ፣
            // ሌሎች ሁኔታዎች በደዋዩ መረጋገጥ አለባቸው
            unsafe { dealloc(ptr.as_ptr(), layout) }
        }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // ደህንነት-ሁሉም ሁኔታዎች በደዋዩ መከበር አለባቸው
        unsafe { self.grow_impl(ptr, old_layout, new_layout, false) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // ደህንነት-ሁሉም ሁኔታዎች በደዋዩ መከበር አለባቸው
        unsafe { self.grow_impl(ptr, old_layout, new_layout, true) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() <= old_layout.size(),
            "`new_layout.size()` must be smaller than or equal to `old_layout.size()`"
        );

        match new_layout.size() {
            // ደህንነት-ሁኔታዎች በደዋዩ መከበር አለባቸው
            0 => unsafe {
                self.deallocate(ptr, old_layout);
                Ok(NonNull::slice_from_raw_parts(new_layout.dangling(), 0))
            },

            // ደህንነት `new_size` ዜሮ አይደለም።ሌሎች ሁኔታዎች በተጠሪው ሊፀኑላቸው ይገባል
            new_size if old_layout.align() == new_layout.align() => unsafe {
                // `realloc` ምናልባት ለ‹XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX ወይም XIIXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX›ወይም ከ‹XXXXX›››››››››››››››››››››››››››››››››››››››››››››››››››››››ን ምርመራ ወይም ቼክ.
                intrinsics::assume(new_size <= old_layout.size());

                let raw_ptr = realloc(ptr.as_ptr(), old_layout, new_size);
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                Ok(NonNull::slice_from_raw_parts(ptr, new_size))
            },

            // ደህንነት-ምክንያቱም `new_size` ከ `old_layout.size()` ያነሰ ወይም እኩል መሆን አለበት ፣
            // የድሮው እና አዲሱ የማስታወሻ ምደባ ለንባብ እና ለ `new_size` ባይት ይጽፋል ፡፡
            // እንዲሁም ፣ የድሮው ምደባ ገና አልተከፋፈለም ፣ `new_ptr` ን መደራረብ አይችልም።
            // ስለዚህ ወደ `copy_nonoverlapping` የሚደረገው ጥሪ ደህንነቱ የተጠበቀ ነው።
            // ለ‹`dealloc` X›የደኅንነት ውል በተጠሪው መደገፍ አለበት ፡፡
            new_size => unsafe {
                let new_ptr = self.allocate(new_layout)?;
                ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), new_size);
                self.deallocate(ptr, old_layout);
                Ok(new_ptr)
            },
        }
    }
}

/// ለልዩ አመልካቾች አመዳደብ ፡፡
// ይህ ተግባር ማራገፍ የለበትም።ከሆነ ፣ MIR codegen አይሳካም።
#[cfg(not(test))]
#[lang = "exchange_malloc"]
#[inline]
unsafe fn exchange_malloc(size: usize, align: usize) -> *mut u8 {
    let layout = unsafe { Layout::from_size_align_unchecked(size, align) };
    match Global.allocate(layout) {
        Ok(ptr) => ptr.as_mut_ptr(),
        Err(_) => handle_alloc_error(layout),
    }
}

#[cfg_attr(not(test), lang = "box_free")]
#[inline]
// ይህ ፊርማ ከ `Box` ጋር ተመሳሳይ መሆን አለበት ፣ አለበለዚያ አይ አይ አይ ይከሰታል።
// ለ `Box` ተጨማሪ ግቤት ሲታከል (እንደ `A: Allocator` ያሉ) ፣ ይህ እንዲሁ እዚህ መታከል አለበት።
// ለምሳሌ `Box` ወደ `struct Box<T: ?Sized, A: Allocator>(Unique<T>, A)` ከተቀየረ ይህ ተግባር ወደ `fn box_free<T: ?Sized, A: Allocator>(Unique<T>, A)` እንዲሁ መለወጥ አለበት።
//
//
pub(crate) unsafe fn box_free<T: ?Sized, A: Allocator>(ptr: Unique<T>, alloc: A) {
    unsafe {
        let size = size_of_val(ptr.as_ref());
        let align = min_align_of_val(ptr.as_ref());
        let layout = Layout::from_size_align_unchecked(size, align);
        alloc.deallocate(ptr.cast().into(), layout)
    }
}

// # የምደባ ስህተት ተቆጣጣሪ

extern "Rust" {
    // ይህ የአለም አቀፋዊ የስህተት መቆጣጠሪያን ለመጥራት ይህ የአስማት ምልክት ነው ፡፡
    // rustc `#[alloc_error_handler]` ካለ ወደ `__rg_oom` ለመደወል ወይም ደግሞ ነባሪውን አተገባበር ከ (`__rdl_oom`) በታች ለመጥራት ያመነጫል ፡፡
    //
    #[rustc_allocator_nounwind]
    fn __rust_alloc_error_handler(size: usize, align: usize) -> !;
}

/// በማስታወሻ ምደባ ስህተት ወይም ውድቀት ላይ ፅንስ ማስወረድ ፡፡
///
/// ከምደባ ስህተት ጋር ተያይዞ ስሌትን ለማስቀረት የሚፈልጉ የማስታወሻ ምደባ ኤፒአይዎች ደዋዮች በቀጥታ `panic!` ን ወይም ተመሳሳይን ከመጠየቅ ይልቅ ይህንን ተግባር እንዲጠሩ ይበረታታሉ ፡፡
///
///
/// የዚህ ተግባር ነባሪ ባህሪ መልእክት ወደ መደበኛ ስህተት ማተም እና ሂደቱን ማቋረጥ ነው።
/// በ [`set_alloc_error_hook`] እና [`take_alloc_error_hook`] ሊተካ ይችላል።
///
/// [`set_alloc_error_hook`]: ../../std/alloc/fn.set_alloc_error_hook.html
/// [`take_alloc_error_hook`]: ../../std/alloc/fn.take_alloc_error_hook.html
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[cfg(not(test))]
#[rustc_allocator_nounwind]
#[cold]
pub fn handle_alloc_error(layout: Layout) -> ! {
    unsafe {
        __rust_alloc_error_handler(layout.size(), layout.align());
    }
}

// ለመመደብ ሙከራ `std::alloc::handle_alloc_error` በቀጥታ ጥቅም ላይ ሊውል ይችላል።
#[cfg(test)]
pub use std::alloc::handle_alloc_error;

#[cfg(not(any(target_os = "hermit", test)))]
#[doc(hidden)]
#[allow(unused_attributes)]
#[unstable(feature = "alloc_internals", issue = "none")]
pub mod __alloc_error_handler {
    use crate::alloc::Layout;

    // በተፈጠረው `__rust_alloc_error_handler` በኩል ተጠርቷል

    // `#[alloc_error_handler]` ከሌለ
    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn __rdl_oom(size: usize, _align: usize) -> ! {
        panic!("memory allocation of {} bytes failed", size)
    }

    // `#[alloc_error_handler]` ካለ
    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn __rg_oom(size: usize, align: usize) -> ! {
        let layout = unsafe { Layout::from_size_align_unchecked(size, align) };
        extern "Rust" {
            #[lang = "oom"]
            fn oom_impl(layout: Layout) -> !;
        }
        unsafe { oom_impl(layout) }
    }
}

/// ክሎኖችን ወደ ቅድመ-መመደብ ፣ ያልታሰበ ማህደረ ትውስታ ልዩ ያድርጉ ፡፡
/// በ `Box::clone` እና `Rc`/`Arc::make_mut` ጥቅም ላይ የዋለ።
pub(crate) trait WriteCloneIntoRaw: Sized {
    unsafe fn write_clone_into_raw(&self, target: *mut Self);
}

impl<T: Clone> WriteCloneIntoRaw for T {
    #[inline]
    default unsafe fn write_clone_into_raw(&self, target: *mut Self) {
        // *መጀመሪያ* ከተመደበ በኋላ አመቻቹ የአከባቢውን እየዘለለ እና እንዲንቀሳቀስ በቦታው የተቀመጠውን እሴት እንዲፈጥር ያስችለዋል ፡፡
        //
        unsafe { target.write(self.clone()) };
    }
}

impl<T: Copy> WriteCloneIntoRaw for T {
    #[inline]
    unsafe fn write_clone_into_raw(&self, target: *mut Self) {
        // መቼም የአካባቢያዊ እሴት ሳናካትት ሁል ጊዜ በቦታው መገልበጥ እንችላለን ፡፡
        unsafe { target.copy_from_nonoverlapping(self, 1) };
    }
}