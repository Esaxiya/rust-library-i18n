//! በሁለትዮሽ ክምር ተተግብሮ ቅድሚያ የሚሰጠው ወረፋ ፡፡
//!
//! ትልቁን ንጥረ ነገር ማስገባት እና ብቅ ማለት የ *O*(log(*n*)) ጊዜ ውስብስብነት አለው።
//! ትልቁን ንጥረ ነገር መፈተሽ *O*(1) ነው።vector ን ወደ ባለ ሁለትዮሽ ክምር መለወጥ በቦታው ሊከናወን ይችላል ፣ እና *O*(*n*) ውስብስብነት አለው።
//! የሁለትዮሽ ክምር እንዲሁ ወደ *O*(*n*\*log(* n*)) በቦታ ክምችት) እንዲያገለግል በመፍቀድ በቦታው ወደ ተስተካከለ vector ሊቀየር ይችላል።
//!
//! # Examples
//!
//! በ [directed graph][dir_graph] ላይ [shortest path problem][sssp] ን ለመፍታት [Dijkstra's algorithm][dijkstra] ን የሚተገብር ይህ ትልቅ ምሳሌ ነው ፡፡
//!
//! [`BinaryHeap`] ን በብጁ ዓይነቶች እንዴት እንደሚጠቀሙ ያሳያል።
//!
//! [dijkstra]: https://en.wikipedia.org/wiki/Dijkstra%27s_algorithm
//! [sssp]: https://en.wikipedia.org/wiki/Shortest_path_problem
//! [dir_graph]: https://en.wikipedia.org/wiki/Directed_graph
//!
//! ```
//! use std::cmp::Ordering;
//! use std::collections::BinaryHeap;
//!
//! #[derive(Copy, Clone, Eq, PartialEq)]
//! struct State {
//!     cost: usize,
//!     position: usize,
//! }
//!
//! // ቅድሚያ የሚሰጠው ወረፋ በ `Ord` ላይ የተመሠረተ ነው።
//! // trait ን በግልጽ ይተግብሩ ስለዚህ ወረፋው ከከፍተኛው ቁልል ይልቅ የማዕድን ቁልል ይሆናል።
//! //
//! impl Ord for State {
//!     fn cmp(&self, other: &Self) -> Ordering {
//!         // እኛ ትዕዛዙን በወጪዎች ላይ እናውጣለን ፡፡
//!         // በእኩል ሁኔታ ቦታዎችን እናወዳድራለን ፣ የ `PartialEq` እና `Ord` አተገባበርን ወጥ ለማድረግ ይህ እርምጃ አስፈላጊ ነው ፡፡
//!         //
//!         other.cost.cmp(&self.cost)
//!             .then_with(|| self.position.cmp(&other.position))
//!     }
//! }
//!
//! // `PartialOrd` እንዲሁም መተግበር ያስፈልጋል ፡፡
//! impl PartialOrd for State {
//!     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
//!         Some(self.cmp(other))
//!     }
//! }
//!
//! // እያንዳንዱ መስቀለኛ መንገድ ለአጭር አተገባበር እንደ `usize` ነው የተወከለው።
//! struct Edge {
//!     node: usize,
//!     cost: usize,
//! }
//!
//! // የዲጅክስትራ አጭር መንገድ አልጎሪዝም።
//!
//! // ወደ እያንዳንዱ መስቀለኛ መንገድ የአሁኑን በጣም አጭር ርቀት ለመከታተል በ `start` ይጀምሩ እና `dist` ን ይጠቀሙ ፡፡ይህ ትግበራ በወረፋው ውስጥ የተባዙ አንጓዎችን ሊተው ስለሚችል ለማስታወስ ብቃት የለውም።
//! //
//! // እንዲሁም ለቀላል አተገባበር `usize::MAX` ን እንደ የኋላ እሴት ይጠቀማል።
//! //
//! fn shortest_path(adj_list: &Vec<Vec<Edge>>, start: usize, goal: usize) -> Option<usize> {
//!     // dist [node]=የአሁኑ አጭር ርቀት ከ `start` እስከ `node`
//!     let mut dist: Vec<_> = (0..adj_list.len()).map(|_| usize::MAX).collect();
//!
//!     let mut heap = BinaryHeap::new();
//!
//!     // እኛ ዜሮ ወጪ ጋር `start` ላይ ነን
//!     dist[start] = 0;
//!     heap.push(State { cost: 0, position: start });
//!
//!     // ድንበሩን በአነስተኛ ወጪ አንጓዎች በመጀመሪያ (min-heap) ይመርምሩ
//!     while let Some(State { cost, position }) = heap.pop() {
//!         // በአማራጭ ሁሉንም አጫጭር ዱካዎችን ማግኘታችንን መቀጠል እንችል ነበር
//!         if position == goal { return Some(cost); }
//!
//!         // ቀደም ብለን የተሻለ መንገድ ስላገኘን አስፈላጊ ነው
//!         if cost > dist[position] { continue; }
//!
//!         // ልንደርስባቸው የምንችለው እያንዳንዱ መስቀለኛ መንገድ በዚህ መስቀለኛ መንገድ ውስጥ የሚያልፍ አነስተኛ ዋጋ ያለው መንገድ መፈለግ እንደምንችል ይመልከቱ
//!         //
//!         for edge in &adj_list[position] {
//!             let next = State { cost: cost + edge.cost, position: edge.node };
//!
//!             // እንደዚያ ከሆነ ወደ ድንበሩ ላይ ያክሉት እና ይቀጥሉ
//!             if next.cost < dist[next.position] {
//!                 heap.push(next);
//!                 // ዘና ማለት አሁን የተሻለ መንገድ አግኝተናል
//!                 dist[next.position] = next.cost;
//!             }
//!         }
//!     }
//!
//!     // ግብ ሊደረስበት አይችልም
//!     None
//! }
//!
//! fn main() {
//!     // ይህ የምንጠቀምበት ቀጥተኛ ግራፍ ነው ፡፡
//!     // የመስቀለኛ ክፍል ቁጥሮች ከተለያዩ ግዛቶች ጋር ይዛመዳሉ ፣ እና የ edge ክብደቶች ከአንድ መስቀለኛ መንገድ ወደ ሌላው ለመንቀሳቀስ የሚያስችለውን ዋጋ ያመለክታሉ።
//!     //
//!     // ጠርዞቹ አንድ-መንገድ መሆናቸውን ልብ ይበሉ ፡፡
//!     //
//!     //                  7
//!     //          +-----------------+
//!     //          |                 |
//!     //          ቁ 1 2 |2018-01-02 እልልልልልልልልልልል 121 2
//!     //          0-----> 1-- ---> 3-- -> 4
//!     //          |        ^        ^      ^
//!     //          |        | 1      |      |
//!     //          |        |        | 3    | 1          +------> 2 -------+      |
//!     //           10 ||
//!     //                   +---------------+
//!     //
//!     // ግራፉ እያንዳንዱ የመስቀለኛ ክፍል እሴት ካለው ጋር የሚዛመድ እያንዳንዱ ማውጫ የወጪ ጠርዞችን ዝርዝር የያዘበት እንደ የአጎራባችነት ዝርዝር ነው የተወከለው።
//!     // ለብቃቱ የተመረጠ ፡፡
//!     //
//!     //
//!     //
//!     let graph = vec![
//!         // መስቀለኛ መንገድ 0
//!         vec![Edge { node: 2, cost: 10 },
//!              Edge { node: 1, cost: 1 }],
//!         // መስቀለኛ መንገድ 1
//!         vec![Edge { node: 3, cost: 2 }],
//!         // መስቀለኛ መንገድ 2
//!         vec![Edge { node: 1, cost: 1 },
//!              Edge { node: 3, cost: 3 },
//!              Edge { node: 4, cost: 1 }],
//!         // መስቀለኛ መንገድ 3
//!         vec![Edge { node: 0, cost: 7 },
//!              Edge { node: 4, cost: 2 }],
//!         // መስቀለኛ መንገድ 4
//!         vec![]];
//!
//!     assert_eq!(shortest_path(&graph, 0, 1), Some(1));
//!     assert_eq!(shortest_path(&graph, 0, 3), Some(3));
//!     assert_eq!(shortest_path(&graph, 3, 0), Some(7));
//!     assert_eq!(shortest_path(&graph, 0, 4), Some(5));
//!     assert_eq!(shortest_path(&graph, 4, 0), None);
//! }
//! ```
//!
//!

#![allow(missing_docs)]
#![stable(feature = "rust1", since = "1.0.0")]

use core::fmt;
use core::iter::{FromIterator, FusedIterator, InPlaceIterable, SourceIter, TrustedLen};
use core::mem::{self, swap, ManuallyDrop};
use core::ops::{Deref, DerefMut};
use core::ptr;

use crate::slice;
use crate::vec::{self, AsIntoIter, Vec};

use super::SpecExtend;

/// በሁለትዮሽ ክምር ተተግብሮ ቅድሚያ የሚሰጠው ወረፋ ፡፡
///
/// ይህ ከፍተኛ ቁልል ይሆናል።
///
/// አንድ ዕቃ በ `Ord` trait በተወሰነው መሠረት ከማንኛውም ሌላ ነገር ጋር አንፃራዊ ማዘዣው በሚቀየርበት ጊዜ እንዲለወጥ መደረጉ ምክንያታዊ ስህተት ነው።
///
/// ይህ በመደበኛነት የሚቻለው በ `Cell` ፣ `RefCell` ፣ በአለም አቀፍ ሁኔታ ፣ በ I/O ወይም በአስተማማኝ ኮድ በኩል ብቻ ነው ፡፡
/// ከእንደዚህ ዓይነቱ አመክንዮ ስህተት የሚመነጭ ባህሪ አልተገለጸም ፣ ግን ያልተገለፀ ባህሪን አያስገኝም ፡፡
/// ይህ panics ፣ የተሳሳተ ውጤት ፣ ፅንስ ማስወረድ ፣ የማስታወስ ፍሰቶች እና ያለማቋረጥ ሊያካትት ይችላል ፡፡
///
/// # Examples
///
/// ```
/// use std::collections::BinaryHeap;
///
/// // የአይነት ግንዛቤ ግልጽ የሆነ የአይነት ፊርማ እንድንተው ያደርገናል (በዚህ ምሳሌ ውስጥ `BinaryHeap<i32>` ይሆናል) ፡፡
/////
/// let mut heap = BinaryHeap::new();
///
/// // በቆለሉ ውስጥ የሚቀጥለውን ንጥል ለመመልከት ቅጥን በመጠቀም ልንጠቀምበት እንችላለን ፡፡
/// // በዚህ ሁኔታ ውስጥ እዚያ ውስጥ ምንም እቃዎች የሉም ስለዚህ አናገኝም ፡፡
/// assert_eq!(heap.peek(), None);
///
/// // የተወሰኑ ነጥቦችን እንጨምር ...
/// heap.push(1);
/// heap.push(5);
/// heap.push(2);
///
/// // አሁን ጮክ ብሎ መቆለሉ ውስጥ በጣም አስፈላጊ የሆነውን ንጥል ያሳያል ፡፡
/// assert_eq!(heap.peek(), Some(&5));
///
/// // የአንድ ክምር ርዝመት ማረጋገጥ እንችላለን ፡፡
/// assert_eq!(heap.len(), 3);
///
/// // ምንም እንኳን በዘፈቀደ ቅደም ተከተል ቢመለሱም በቁጥሩ ውስጥ ያሉትን ዕቃዎች ማመጣጠን እንችላለን ፡፡
/////
/// for x in &heap {
///     println!("{}", x);
/// }
///
/// // በምትኩ እነዚህን ውጤቶች የምናወጣ ከሆነ በቅደም ተከተል ተመልሰው መምጣት አለባቸው ፡፡
/// assert_eq!(heap.pop(), Some(5));
/// assert_eq!(heap.pop(), Some(2));
/// assert_eq!(heap.pop(), Some(1));
/// assert_eq!(heap.pop(), None);
///
/// // ከማንኛውም የቀሩትን ዕቃዎች ክምር ማጽዳት እንችላለን ፡፡
/// heap.clear();
///
/// // ክምር አሁን ባዶ መሆን አለበት ፡፡
/// assert!(heap.is_empty())
/// ```
///
/// ## Min-heap
///
/// X0 `std::cmp::Reverse` ወይም ብጁ የ `Ord` ትግበራ `BinaryHeap` ን ደቂቃ-ክምር ለማድረግ ሊያገለግል ይችላል ፡፡
/// ይህ ከታላቁ ይልቅ `heap.pop()` አነስተኛውን እሴት እንዲመልስ ያደርገዋል።
///
/// ```
/// use std::collections::BinaryHeap;
/// use std::cmp::Reverse;
///
/// let mut heap = BinaryHeap::new();
///
/// // እሴቶችን በ `Reverse` መጠቅለል
/// heap.push(Reverse(1));
/// heap.push(Reverse(5));
/// heap.push(Reverse(2));
///
/// // እነዚህን ውጤቶች አሁን ካወጣናቸው በተቃራኒው ቅደም ተከተል ተመልሰው መምጣት አለባቸው ፡፡
/// assert_eq!(heap.pop(), Some(Reverse(1)));
/// assert_eq!(heap.pop(), Some(Reverse(2)));
/// assert_eq!(heap.pop(), Some(Reverse(5)));
/// assert_eq!(heap.pop(), None);
/// ```
///
/// # የጊዜ ውስብስብነት
///
/// | [push] | [pop]     | [peek]/[peek\_mut] |
/// |--------|-----------|--------------------|
/// | O(1)~  | *O*(log(*n*)) | *O*(1)               |
///
/// የ `push` ዋጋ የሚጠበቀው ዋጋ ነው;ዘዴው የበለጠ ዝርዝር ትንታኔ ይሰጣል ፡፡
///
/// [push]: BinaryHeap::push
/// [pop]: BinaryHeap::pop
/// [peek]: BinaryHeap::peek
/// [peek\_mut]: BinaryHeap::peek_mut
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "BinaryHeap")]
pub struct BinaryHeap<T> {
    data: Vec<T>,
}

/// በ‹XXXX›ላይ ወደ ትልቁ ንጥል የሚለዋወጥ ማጣቀሻ የሚጠቅል መዋቅር።
///
///
/// ይህ `struct` በ [`BinaryHeap`] ላይ በ [`peek_mut`] ዘዴ የተፈጠረ ነው ፡፡
/// ለተጨማሪ ሰነዶቹን ይመልከቱ ፡፡
///
/// [`peek_mut`]: BinaryHeap::peek_mut
#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
pub struct PeekMut<'a, T: 'a + Ord> {
    heap: &'a mut BinaryHeap<T>,
    sift: bool,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: Ord + fmt::Debug> fmt::Debug for PeekMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("PeekMut").field(&self.heap.data[0]).finish()
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> Drop for PeekMut<'_, T> {
    fn drop(&mut self) {
        if self.sift {
            // ደህንነት ፒክ ሙት ባዶ ላልሆኑ ክምርዎች ብቻ ነው የተቀየሰው ፡፡
            unsafe { self.heap.sift_down(0) };
        }
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> Deref for PeekMut<'_, T> {
    type Target = T;
    fn deref(&self) -> &T {
        debug_assert!(!self.heap.is_empty());
        // ደህንነት:-ፒክ ሙት ባዶ ላልሆኑ ክምርዎች ብቻ የተቀናበረ ነው
        unsafe { self.heap.data.get_unchecked(0) }
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> DerefMut for PeekMut<'_, T> {
    fn deref_mut(&mut self) -> &mut T {
        debug_assert!(!self.heap.is_empty());
        self.sift = true;
        // ደህንነት:-ፒክ ሙት ባዶ ላልሆኑ ክምርዎች ብቻ የተቀናበረ ነው
        unsafe { self.heap.data.get_unchecked_mut(0) }
    }
}

impl<'a, T: Ord> PeekMut<'a, T> {
    /// የተኮሳተረውን እሴት ከከሞሉ ውስጥ አስወግዶ ይመልሰዋል ፡፡
    #[stable(feature = "binary_heap_peek_mut_pop", since = "1.18.0")]
    pub fn pop(mut this: PeekMut<'a, T>) -> T {
        let value = this.heap.pop().unwrap();
        this.sift = false;
        value
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for BinaryHeap<T> {
    fn clone(&self) -> Self {
        BinaryHeap { data: self.data.clone() }
    }

    fn clone_from(&mut self, source: &Self) {
        self.data.clone_from(&source.data);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Default for BinaryHeap<T> {
    /// ባዶ `BinaryHeap<T>` ን ይፈጥራል።
    #[inline]
    fn default() -> BinaryHeap<T> {
        BinaryHeap::new()
    }
}

#[stable(feature = "binaryheap_debug", since = "1.4.0")]
impl<T: fmt::Debug> fmt::Debug for BinaryHeap<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self.iter()).finish()
    }
}

impl<T: Ord> BinaryHeap<T> {
    /// ባዶ `BinaryHeap` ን እንደ ከፍተኛ-ክምር ይፈጥራል።
    ///
    /// # Examples
    ///
    /// መሠረታዊ አጠቃቀም
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new() -> BinaryHeap<T> {
        BinaryHeap { data: vec![] }
    }

    /// በተወሰነ አቅም ባዶ `BinaryHeap` ን ይፈጥራል።
    /// ይህ ለ‹XXXX›አካላት በቂ ማህደረ ትውስታን አስቀድሞ ይከፍላል ፣ ስለሆነም `BinaryHeap` ቢያንስ ያን ያህል እሴቶችን እስከሚይዝ ድረስ እንደገና መመደብ የለበትም።
    ///
    ///
    /// # Examples
    ///
    /// መሠረታዊ አጠቃቀም
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::with_capacity(10);
    /// heap.push(4);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> BinaryHeap<T> {
        BinaryHeap { data: Vec::with_capacity(capacity) }
    }

    /// በሁለትዮሽ ክምር ውስጥ ወደ ትልቁ ነገር የሚለዋወጥ ማጣቀሻ ወይም ባዶ ከሆነ `None` ይመልሳል።
    ///
    /// Note: የ `PeekMut` እሴት ከፈሰሰ ክምርው ወጥነት በሌለው ሁኔታ ውስጥ ሊሆን ይችላል።
    ///
    /// # Examples
    ///
    /// መሠረታዊ አጠቃቀም
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// assert!(heap.peek_mut().is_none());
    ///
    /// heap.push(1);
    /// heap.push(5);
    /// heap.push(2);
    /// {
    ///     let mut val = heap.peek_mut().unwrap();
    ///     *val = 0;
    /// }
    /// assert_eq!(heap.peek(), Some(&2));
    /// ```
    ///
    /// # የጊዜ ውስብስብነት
    ///
    /// እቃው ከተቀየረ በጣም መጥፎው የጊዜ ውስብስብነት *O*(log(*n*)) ነው ፣ ካልሆነ ግን *O*(1) ነው።
    ///
    ///
    ///
    #[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
    pub fn peek_mut(&mut self) -> Option<PeekMut<'_, T>> {
        if self.is_empty() { None } else { Some(PeekMut { heap: self, sift: false }) }
    }

    /// ትልቁን እቃ ከሁለትዮሽ ክምር ውስጥ ያስወግዳል እና ይመልሰዋል ፣ ወይም `None` ባዶ ከሆነ።
    ///
    ///
    /// # Examples
    ///
    /// መሠረታዊ አጠቃቀም
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert_eq!(heap.pop(), Some(3));
    /// assert_eq!(heap.pop(), Some(1));
    /// assert_eq!(heap.pop(), None);
    /// ```
    ///
    /// # የጊዜ ውስብስብነት
    ///
    /// *N* ንጥረ ነገሮችን በያዘ ክምር ላይ የ `pop` በጣም የከፋ ጉዳይ ዋጋ *O*(log(*n*)) ነው።
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<T> {
        self.data.pop().map(|mut item| {
            if !self.is_empty() {
                swap(&mut item, &mut self.data[0]);
                // ደህንነት !self.is_empty() ማለት self.len()> 0 ማለት ነው
                unsafe { self.sift_down_to_bottom(0) };
            }
            item
        })
    }

    /// አንድ ንጥል በሁለትዮሽ ክምር ላይ ይገፋል ፡፡
    ///
    /// # Examples
    ///
    /// መሠረታዊ አጠቃቀም
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.push(3);
    /// heap.push(5);
    /// heap.push(1);
    ///
    /// assert_eq!(heap.len(), 3);
    /// assert_eq!(heap.peek(), Some(&5));
    /// ```
    ///
    /// # የጊዜ ውስብስብነት
    ///
    /// ንጥረ ነገሮች ሁሉ ይቻላል አደራደር ላይ አማካይ `push` የሚጠበቀው ዋጋ, ይገፋሉ, እና ስለ ራሳችንና ስለ አንድ በበቂ ትልቅ ቁጥር ላይ እየተካሄደ ነው *ሆይ*(1).
    ///
    /// በማንኛውም የተስተካከለ ንድፍ ውስጥ *ያልሆኑ* አባሎችን ሲገፉ ይህ በጣም ትርጉም ያለው የወጪ መለኪያ ነው።
    ///
    /// አባሎች በብዛት ወደ ላይ በሚወጡበት ቅደም ተከተል ከተገፉ የጊዜ ውስብስብነቱ ይከስማል።
    /// በጣም በከፋ ሁኔታ ውስጥ ንጥረ ነገሮች በተራቀቀ ቅደም ተከተል እንዲገፉ ይደረጋሉ እና በአንድ ግፊት የተስተካከለ ዋጋ *n* አባሎችን ከያዘ ክምር ጋር *O*(log(*n*)) ነው ፡፡
    ///
    /// የ‹ነጠላ›ጥሪ ለ `push` በጣም የከፋው ዋጋ *O*(*n*) ነው ፡፡በጣም የከፋው ሁኔታ የሚከሰተው አቅም ሲደክም እና መጠኑን በሚፈልግበት ጊዜ ነው ፡፡
    /// ከዚህ በፊት ባሉት አኃዞች ላይ መጠነ-ልኬት ዋጋ ተስተካክሏል ፡፡
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, item: T) {
        let old_len = self.len();
        self.data.push(item);
        // ደህንነት-አዲስ ንጥል ስለገፋን ያ ማለት ነው
        //  old_len= self.len(), 1 <self.len()
        unsafe { self.sift_up(0, old_len) };
    }

    /// `BinaryHeap` ን ይወስዳል እና vector ን በተስተካከለ (ascending) ቅደም ተከተል ይመልሳል።
    ///
    ///
    /// # Examples
    ///
    /// መሠረታዊ አጠቃቀም
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![1, 2, 4, 5, 7]);
    /// heap.push(6);
    /// heap.push(3);
    ///
    /// let vec = heap.into_sorted_vec();
    /// assert_eq!(vec, [1, 2, 3, 4, 5, 6, 7]);
    /// ```
    #[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
    pub fn into_sorted_vec(mut self) -> Vec<T> {
        let mut end = self.len();
        while end > 1 {
            end -= 1;
            // ደህንነት `end` ከ `self.len() - 1` ወደ 1 ይሄዳል (ሁለቱም ተካትተዋል) ፣
            //  ስለዚህ ለመድረስ ሁልጊዜ ትክክለኛ መረጃ ጠቋሚ ነው።
            //  መረጃ ጠቋሚ 0 (ማለትም `ptr`) መድረስ ደህንነቱ የተጠበቀ ነው ፣ ምክንያቱም
            //  1 <=መጨረሻ <self.len(), ማለትም self.len()>=2 ማለት ነው።
            unsafe {
                let ptr = self.data.as_mut_ptr();
                ptr::swap(ptr, ptr.add(end));
            }
            // ደህንነት `end` ከ `self.len() - 1` ወደ 1 ይሄዳል (ሁለቱም ተካትተዋል) ስለዚህ:
            //  0 <1 <=end <= self.len(), 1 <self.len() ይህም ማለት 0 <መጨረሻ እና መጨረሻ <self.len().
            //
            unsafe { self.sift_down_range(0, end) };
        }
        self.into_vec()
    }

    // የ `Sift_up` እና `sift_down` አተገባበር አንድን ንጥረ ነገር ከ vector (ከጉድጓድ በስተጀርባ ትቶ) ለማስወጣት ደህንነቱ ያልተጠበቀ ብሎኮችን ይጠቀማል ፣ ከሌሎቹ ጋር ይቀያይሩ እና የተወገደውን ንጥረ ነገር ወደ ቀዳዳው የመጨረሻ ቦታ እንደገና ወደ vector ይመልሱ ፡፡
    //
    // የ `Hole` አይነት ይህን ይወክላሉ, እና እንዲያውም panic ላይ ወሰን መጨረሻ ላይ ያረጋግጡ ቀዳዳ የተሞላ ነው ጀርባ, ለማድረግ ያገለግላል.
    // ቀዳዳን በመጠቀም ስዋፕስን ከመጠቀም ጋር ሲነፃፀር የማይለዋወጥ ሁኔታን ይቀንሰዋል ፣ ይህም ሁለት እጥፍ እርምጃዎችን ይወስዳል ፡፡
    //
    //
    //
    //

    /// # Safety
    ///
    /// ደዋዩ ለዚያ `pos < self.len()` ዋስትና መስጠት አለበት ፡፡
    unsafe fn sift_up(&mut self, start: usize, pos: usize) -> usize {
        // እሴቱን በ `pos` ያውጡ እና ቀዳዳ ይፍጠሩ።
        // ደህንነት ደዋዩ pos <self.len() ን ያረጋግጣል
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };

        while hole.pos() > start {
            let parent = (hole.pos() - 1) / 2;

            // ደህንነት: hole.pos()> ጅምር>=0 ፣ ማለትም hole.pos()> 0 ማለት ነው
            //  እና ስለዚህ hole.pos() ፣ 1 ወደ ውስጥ መፍሰስ አይችልም።
            //  ይህ ለዚያ ወላጅ ዋስትና ይሰጣል <hole.pos() ስለዚህ ትክክለኛ መረጃ ጠቋሚ ነው እና ደግሞ!= hole.pos()።
            //
            if hole.element() <= unsafe { hole.get(parent) } {
                break;
            }

            // ደህንነት-ከላይ ካለው ጋር ተመሳሳይ
            unsafe { hole.move_to(parent) };
        }

        hole.pos()
    }

    /// ልጆቹ የበለጠ ሲሆኑ `pos` ላይ አንድ ኤለመንት ይውሰዱ እና ክምርውን ወደ ታች ያንቀሳቅሱት።
    ///
    ///
    /// # Safety
    ///
    /// ደዋዩ ለዚያ `pos < end <= self.len()` ዋስትና መስጠት አለበት ፡፡
    unsafe fn sift_down_range(&mut self, pos: usize, end: usize) {
        // ደህንነት ደዋዩ pos <end <= self.len() ን ያረጋግጣል ፡፡
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };
        let mut child = 2 * hole.pos() + 1;

        // ሉፕ የማይለዋወጥ: ልጅ==2 * hole.pos() + 1.
        while child <= end.saturating_sub(2) {
            // ከሁለቱ ልጆች ትልቁን ያነፃፅሩ ደህንነት-ልጅ <መጨረሻ ፣ 1 <self.len() እና ልጅ + 1 <መጨረሻ <= self.len() ፣ ስለሆነም ትክክለኛ ኢንዴክሶች ናቸው ፡፡
            //
            //  ልጅ==2 *hole.pos() + 1!= hole.pos() እና ልጅ + 1==2* hole.pos() + 2!= hole.pos()።
            // FIXME: ቲ ZST ከሆነ 2 *hole.pos() + 1 ወይም 2* hole.pos() + 2 ሊፈስ ይችላል
            //
            //
            //
            child += unsafe { hole.get(child) <= hole.get(child + 1) } as usize;

            // እኛ ቅደም ተከተል ካለን ቆም ይበሉ ፡፡
            // ደህንነት-ልጅ አሁን አሮጌ ልጅ ወይም አሮጌው ልጅ + 1 ነው
            //  ሁለቱም <self.len() እና!= hole.pos() መሆናቸውን ቀድመን አረጋግጠናል
            if hole.element() >= unsafe { hole.get(child) } {
                return;
            }

            // ደህንነት-ከላይ ካለው ጋር ተመሳሳይ ፡፡
            unsafe { hole.move_to(child) };
            child = 2 * hole.pos() + 1;
        }

        // ደህንነት: &&አጭር ማዞሪያ ፣ ይህም ማለት በ ውስጥ ማለት ነው
        //  ሁለተኛ ሁኔታ ያ ልጅ ቀድሞውኑ እውነት ነው==መጨረሻ ፣ 1 <self.len()።
        if child == end - 1 && hole.element() < unsafe { hole.get(child) } {
            // ደህንነት-ልጅ ቀድሞውኑ ትክክለኛ መረጃ ጠቋሚ መሆኑ ተረጋግጧል እና
            //  ልጅ==2 * hole.pos() + 1!= hole.pos().
            unsafe { hole.move_to(child) };
        }
    }

    /// # Safety
    ///
    /// ደዋዩ ለዚያ `pos < self.len()` ዋስትና መስጠት አለበት ፡፡
    unsafe fn sift_down(&mut self, pos: usize) {
        let len = self.len();
        // ደህንነት:-pos <len በተጠሪው እና
        //  በግልጽ ሌን= self.len() <= self.len().
        unsafe { self.sift_down_range(pos, len) };
    }

    /// አንድ ኤለመንት በ `pos` ውሰድ እና እስከ ክምርው ድረስ በሙሉ ያንቀሳቅሱት ፣ ከዚያ ወደ ቦታው ያፍጡት።
    ///
    ///
    /// Note: ንጥረ ነገሩ ትልቅ መሆኑ ሲታወቅ ይህ ፈጣን ነው/ወደ ታች መቅረብ አለበት ፡፡
    ///
    /// # Safety
    ///
    /// ደዋዩ ለዚያ `pos < self.len()` ዋስትና መስጠት አለበት ፡፡
    ///
    unsafe fn sift_down_to_bottom(&mut self, mut pos: usize) {
        let end = self.len();
        let start = pos;

        // ደህንነት ደዋዩ pos <self.len() ን ያረጋግጣል ፡፡
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };
        let mut child = 2 * hole.pos() + 1;

        // ሉፕ የማይለዋወጥ: ልጅ==2 * hole.pos() + 1.
        while child <= end.saturating_sub(2) {
            // ደህንነት: ልጅ <መጨረሻ, 1 <self.len() እና
            //  ልጅ + 1 <መጨረሻ <= self.len() ፣ ስለሆነም ትክክለኛ ኢንዴክሶች ናቸው።
            //  ልጅ==2 *hole.pos() + 1!= hole.pos() እና ልጅ + 1==2* hole.pos() + 2!= hole.pos()።
            //
            // FIXME: ቲ ZST ከሆነ 2 *hole.pos() + 1 ወይም 2* hole.pos() + 2 ሊፈስ ይችላል
            //
            child += unsafe { hole.get(child) <= hole.get(child + 1) } as usize;

            // ደህንነት-ከላይ ካለው ጋር ተመሳሳይ
            unsafe { hole.move_to(child) };
            child = 2 * hole.pos() + 1;
        }

        if child == end - 1 {
            // ደህንነት: ልጅ==መጨረሻ ፣ 1 <self.len() ፣ ስለሆነም ትክክለኛ መረጃ ጠቋሚ ነው
            //  እና ልጅ==2 * hole.pos() + 1!= hole.pos().
            unsafe { hole.move_to(child) };
        }
        pos = hole.pos();
        drop(hole);

        // ደህንነት-ፖስ ቀዳዳው ውስጥ ያለው ቦታ ሲሆን ቀደም ሲል የተረጋገጠ ነበር
        //  ትክክለኛ መረጃ ጠቋሚ መሆን።
        unsafe { self.sift_up(start, pos) };
    }

    fn rebuild(&mut self) {
        let mut n = self.len() / 2;
        while n > 0 {
            n -= 1;
            // ደህንነት: n ከ self.len()/2 ጀምሮ ወደ 0 ይወርዳል።
            //  ብቸኛው ጉዳይ መቼ! (N <self.len()) ከሆነ self.len() ==0 ከሆነ ግን በሉፕ ሁኔታው የተከለከለ ነው) ፡፡
            //
            unsafe { self.sift_down(n) };
        }
    }

    /// የ `other` ን ሁሉንም ነገሮች ወደ `self` ያዛውራል ፣ `other` ን ባዶ ያደርገዋል።
    ///
    /// # Examples
    ///
    /// መሠረታዊ አጠቃቀም
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    ///
    /// let v = vec![-10, 1, 2, 3, 3];
    /// let mut a = BinaryHeap::from(v);
    ///
    /// let v = vec![-20, 5, 43];
    /// let mut b = BinaryHeap::from(v);
    ///
    /// a.append(&mut b);
    ///
    /// assert_eq!(a.into_sorted_vec(), [-20, -10, 1, 2, 3, 3, 5, 43]);
    /// assert!(b.is_empty());
    /// ```
    #[stable(feature = "binary_heap_append", since = "1.11.0")]
    pub fn append(&mut self, other: &mut Self) {
        if self.len() < other.len() {
            swap(self, other);
        }

        if other.is_empty() {
            return;
        }

        #[inline(always)]
        fn log2_fast(x: usize) -> usize {
            (usize::BITS - x.leading_zeros() - 1) as usize
        }

        // `rebuild` በጣም መጥፎ በሆነ ሁኔታ የ O(len1 + len2) ክዋኔዎችን እና የ 2 *(len1 + len2) ንፅፅሮችን ይወስዳል እና `extend` የ O(len2* log(len1)) ኦፕሬሽኖችን ይወስዳል እና በጣም የከፋ የ 1 *len2* log_2(len1) ንፅፅሮችን ይወስዳል ፣ len1>= len2 ን ከግምት ውስጥ በማስገባት ፡፡
        // ለትላልቅ ክምርዎች ፣ ተሻጋሪው ነጥብ ከአሁን በኋላ ይህንን ምክንያት አይከተልም እናም በእውነቱ ተወስኗል ፡፡
        //
        //
        //
        //
        #[inline]
        fn better_to_rebuild(len1: usize, len2: usize) -> bool {
            let tot_len = len1 + len2;
            if tot_len <= 2048 {
                2 * tot_len < len2 * log2_fast(len1)
            } else {
                2 * tot_len < len2 * 11
            }
        }

        if better_to_rebuild(self.len(), other.len()) {
            self.data.append(&mut other.data);
            self.rebuild();
        } else {
            self.extend(other.drain());
        }
    }

    /// በክምችት ቅደም ተከተል ንጥረ ነገሮችን ሰርስሮ የሚመልስ ተደጋጋሚ ይመልሳል።
    /// የተገኙት ንጥረ ነገሮች ከመጀመሪያው ክምር ይወገዳሉ ፡፡
    /// የተቀሩት ንጥረ ነገሮች በቅልጥፍና ቅደም ተከተል ጠብታ ላይ ይወገዳሉ።
    ///
    /// Note:
    /// * `.drain_sorted()` *O*(*n*\*log(* n*))) ነው ፣ ከ `.drain()` በጣም ቀርፋፋ ነው።
    ///   ለአብዛኛዎቹ ጉዳዮች የመጨረሻውን መጠቀም አለብዎት ፡፡
    ///
    /// # Examples
    ///
    /// መሠረታዊ አጠቃቀም
    ///
    /// ```
    /// #![feature(binary_heap_drain_sorted)]
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![1, 2, 3, 4, 5]);
    /// assert_eq!(heap.len(), 5);
    ///
    /// drop(heap.drain_sorted()); // ሁሉንም ንጥረ ነገሮች በቅደም ተከተል ያስወግዳቸዋል
    /// assert_eq!(heap.len(), 0);
    /// ```
    #[inline]
    #[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
    pub fn drain_sorted(&mut self) -> DrainSorted<'_, T> {
        DrainSorted { inner: self }
    }

    /// አስቀድሞ በተጠቀሰው አካል የተገለጹትን ንጥረ ነገሮች ብቻ ይይዛል።
    ///
    /// በሌላ አገላለጽ `f(&e)` ን `false` ን ይመልሳል ፣ ስለሆነም ሁሉንም አባሎች `e` ን ያስወግዱ።
    /// ንጥረ ነገሮቹ ባልተለየ (እና ባልተገለጸ) ቅደም ተከተል ተጎብኝተዋል።
    ///
    /// # Examples
    ///
    /// መሠረታዊ አጠቃቀም
    ///
    /// ```
    /// #![feature(binary_heap_retain)]
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![-10, -5, 1, 2, 4, 13]);
    ///
    /// heap.retain(|x| x % 2 == 0); // ቁጥሮችን ብቻ ብቻ ይያዙ
    ///
    /// assert_eq!(heap.into_sorted_vec(), [-10, 2, 4])
    /// ```
    #[unstable(feature = "binary_heap_retain", issue = "71503")]
    pub fn retain<F>(&mut self, f: F)
    where
        F: FnMut(&T) -> bool,
    {
        self.data.retain(f);
        self.rebuild();
    }
}

impl<T> BinaryHeap<T> {
    /// በዘፈቀደ ቅደም ተከተል መሠረት በታችኛው vector ውስጥ ሁሉንም እሴቶች የሚጎበኝ ተደጋጋሚ ይመልሳል።
    ///
    ///
    /// # Examples
    ///
    /// መሠረታዊ አጠቃቀም
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4]);
    ///
    /// // 1, 2, 3, 4 ን በዘፈቀደ ቅደም ተከተል ያትሙ
    /// for x in heap.iter() {
    ///     println!("{}", x);
    /// }
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter { iter: self.data.iter() }
    }

    /// በክምችት ቅደም ተከተል ንጥረ ነገሮችን ሰርስሮ የሚመልስ ተደጋጋሚ ይመልሳል።
    /// ይህ ዘዴ የመጀመሪያውን ክምር ይበላዋል ፡፡
    ///
    /// # Examples
    ///
    /// መሠረታዊ አጠቃቀም
    ///
    /// ```
    /// #![feature(binary_heap_into_iter_sorted)]
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4, 5]);
    ///
    /// assert_eq!(heap.into_iter_sorted().take(2).collect::<Vec<_>>(), vec![5, 4]);
    /// ```
    #[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
    pub fn into_iter_sorted(self) -> IntoIterSorted<T> {
        IntoIterSorted { inner: self }
    }

    /// በሁለትዮሽ ክምር ውስጥ ትልቁን እቃ ወይም ባዶ ከሆነ `None` ን ይመልሳል።
    ///
    /// # Examples
    ///
    /// መሠረታዊ አጠቃቀም
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// assert_eq!(heap.peek(), None);
    ///
    /// heap.push(1);
    /// heap.push(5);
    /// heap.push(2);
    /// assert_eq!(heap.peek(), Some(&5));
    ///
    /// ```
    ///
    /// # የጊዜ ውስብስብነት
    ///
    /// በጣም መጥፎ በሆነ ሁኔታ ዋጋ *O*(1) ነው።
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn peek(&self) -> Option<&T> {
        self.data.get(0)
    }

    /// የሁለትዮሽ ክምር ሳይለዋወጥ ሊይዛቸው የሚችላቸውን ንጥረ ነገሮች ብዛት ይመልሳል።
    ///
    /// # Examples
    ///
    /// መሠረታዊ አጠቃቀም
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::with_capacity(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.data.capacity()
    }

    /// በተሰጠው `BinaryHeap` ውስጥ ለማስገባት በትክክል ለ‹`additional`›ተጨማሪ አካላት አነስተኛውን አቅም ይጠብቃል።
    /// አቅሙ ቀድሞውኑ በቂ ከሆነ ምንም አያደርግም።
    ///
    /// አከፋፋዩ ስብስቡ ከሚጠይቀው የበለጠ ቦታ ሊሰጥ እንደሚችል ልብ ይበሉ ፡፡
    /// ስለዚህ አቅም በትክክል አነስተኛ ሆኖ ሊታመን አይችልም።
    /// የ future ማስገባቶች የሚጠበቁ ከሆኑ [`reserve`] ን ይምረጡ።
    ///
    /// # Panics
    ///
    /// አዲሱ አቅም `usize` ን ካፈሰሰ Panics።
    ///
    /// # Examples
    ///
    /// መሠረታዊ አጠቃቀም
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.reserve_exact(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    ///
    /// [`reserve`]: BinaryHeap::reserve
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.data.reserve_exact(additional);
    }

    /// በ `BinaryHeap` ውስጥ ለማስገባት ቢያንስ ለ `additional` ተጨማሪ አካላት አቅም ይይዛል።
    /// ስብስቡ ተደጋጋሚ ሪከሎችን ለማስቀረት ተጨማሪ ቦታ ሊይዝ ይችላል።
    ///
    /// # Panics
    ///
    /// አዲሱ አቅም `usize` ን ካፈሰሰ Panics።
    ///
    /// # Examples
    ///
    /// መሠረታዊ አጠቃቀም
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.reserve(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.data.reserve(additional);
    }

    /// በተቻለ መጠን ብዙ ተጨማሪ አቅም ይጥላል።
    ///
    /// # Examples
    ///
    /// መሠረታዊ አጠቃቀም
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap: BinaryHeap<i32> = BinaryHeap::with_capacity(100);
    ///
    /// assert!(heap.capacity() >= 100);
    /// heap.shrink_to_fit();
    /// assert!(heap.capacity() == 0);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        self.data.shrink_to_fit();
    }

    /// አቅም ከዝቅተኛ ማሰሪያ ጋር ይጥላል።
    ///
    /// አቅሙ እንደ ርዝመቱ እና ከቀረበው እሴት ቢያንስ እንደ ትልቅ ይቆያል።
    ///
    ///
    /// አሁን ያለው አቅም ከዝቅተኛው ወሰን በታች ከሆነ ፣ ይህ ምንም ምርጫ የለውም።
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// use std::collections::BinaryHeap;
    /// let mut heap: BinaryHeap<i32> = BinaryHeap::with_capacity(100);
    ///
    /// assert!(heap.capacity() >= 100);
    /// heap.shrink_to(10);
    /// assert!(heap.capacity() >= 10);
    /// ```
    #[inline]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        self.data.shrink_to(min_capacity)
    }

    /// `BinaryHeap` ን ይወስዳል እና መሰረታዊውን vector በዘፈቀደ ቅደም ተከተል ይመልሳል።
    ///
    ///
    /// # Examples
    ///
    /// መሠረታዊ አጠቃቀም
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4, 5, 6, 7]);
    /// let vec = heap.into_vec();
    ///
    /// // በተወሰነ ቅደም ተከተል ይታተም
    /// for x in vec {
    ///     println!("{}", x);
    /// }
    /// ```
    #[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
    pub fn into_vec(self) -> Vec<T> {
        self.into()
    }

    /// የሁለትዮሽ ክምር ርዝመት ይመልሳል።
    ///
    /// # Examples
    ///
    /// መሠረታዊ አጠቃቀም
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert_eq!(heap.len(), 2);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.data.len()
    }

    /// የሁለትዮሽ ክምር ባዶ ከሆነ ይፈትሻል።
    ///
    /// # Examples
    ///
    /// መሠረታዊ አጠቃቀም
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    ///
    /// assert!(heap.is_empty());
    ///
    /// heap.push(3);
    /// heap.push(5);
    /// heap.push(1);
    ///
    /// assert!(!heap.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// በተወገዱት ንጥረ ነገሮች ላይ አንድ ተደጋጋሚ መልስ በመስጠት የሁለትዮሽ ክምርን ያጸዳል።
    ///
    /// ንጥረ ነገሮቹ በዘፈቀደ ቅደም ተከተል ይወገዳሉ።
    ///
    /// # Examples
    ///
    /// መሠረታዊ አጠቃቀም
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert!(!heap.is_empty());
    ///
    /// for x in heap.drain() {
    ///     println!("{}", x);
    /// }
    ///
    /// assert!(heap.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain(&mut self) -> Drain<'_, T> {
        Drain { iter: self.data.drain(..) }
    }

    /// ሁሉንም ዕቃዎች ከሁለትዮሽ ክምር ላይ ይጥላል።
    ///
    /// # Examples
    ///
    /// መሠረታዊ አጠቃቀም
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert!(!heap.is_empty());
    ///
    /// heap.clear();
    ///
    /// assert!(heap.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.drain();
    }
}

/// ቀዳዳ በአንድ ቁራጭ ውስጥ ቀዳዳን ይወክላል ማለትም ፣ ትክክለኛ ዋጋ ያለው መረጃ ጠቋሚ (እሱ ስለተዛወረ ወይም የተባዛ ስለሆነ)።
///
/// በመጣል ላይ ፣ `Hole` መጀመሪያ በተወገደው እሴት የጉድጓዱን ቦታ በመሙላት ቁርጥራጮቹን ይመልሳል።
///
struct Hole<'a, T: 'a> {
    data: &'a mut [T],
    elt: ManuallyDrop<T>,
    pos: usize,
}

impl<'a, T> Hole<'a, T> {
    /// በመረጃ ጠቋሚ `pos` ላይ አዲስ `Hole` ን ይፍጠሩ።
    ///
    /// ደህንነቱ የተጠበቀ አይደለም ምክንያቱም ፖሱ በመረጃው ክፍል ውስጥ መሆን አለበት።
    #[inline]
    unsafe fn new(data: &'a mut [T], pos: usize) -> Self {
        debug_assert!(pos < data.len());
        // SAFE: POS በተቆራረጡ ውስጥ መሆን አለበት
        let elt = unsafe { ptr::read(data.get_unchecked(pos)) };
        Hole { data, elt: ManuallyDrop::new(elt), pos }
    }

    #[inline]
    fn pos(&self) -> usize {
        self.pos
    }

    /// ለተወገደው ንጥረ ነገር ማጣቀሻ ይመልሳል።
    #[inline]
    fn element(&self) -> &T {
        &self.elt
    }

    /// በ‹XXXX›ላይ ያለው ንጥረ ነገር ማጣቀሻ ይመልሳል።
    ///
    /// ደህንነቱ ያልተጠበቀ ስለሆነ መረጃ ጠቋሚው በመረጃ ቁራጭ ውስጥ መሆን እና ከፖዝ ጋር እኩል መሆን የለበትም ፡፡
    #[inline]
    unsafe fn get(&self, index: usize) -> &T {
        debug_assert!(index != self.pos);
        debug_assert!(index < self.data.len());
        unsafe { self.data.get_unchecked(index) }
    }

    /// ቀዳዳውን ወደ አዲስ ቦታ ያዛውሩ
    ///
    /// ደህንነቱ ያልተጠበቀ ስለሆነ መረጃ ጠቋሚው በመረጃ ቁራጭ ውስጥ መሆን እና ከፖዝ ጋር እኩል መሆን የለበትም ፡፡
    #[inline]
    unsafe fn move_to(&mut self, index: usize) {
        debug_assert!(index != self.pos);
        debug_assert!(index < self.data.len());
        unsafe {
            let ptr = self.data.as_mut_ptr();
            let index_ptr: *const _ = ptr.add(index);
            let hole_ptr = ptr.add(self.pos);
            ptr::copy_nonoverlapping(index_ptr, hole_ptr, 1);
        }
        self.pos = index;
    }
}

impl<T> Drop for Hole<'_, T> {
    #[inline]
    fn drop(&mut self) {
        // እንደገና ቀዳዳውን ይሙሉ
        unsafe {
            let pos = self.pos;
            ptr::copy_nonoverlapping(&*self.elt, self.data.get_unchecked_mut(pos), 1);
        }
    }
}

/// በ `BinaryHeap` ንጥረ ነገሮች ላይ አንድ ተደጋጋሚ።
///
/// ይህ `struct` በ [`BinaryHeap::iter()`] የተፈጠረ ነው።
/// ለተጨማሪ ሰነዶቹን ይመልከቱ ፡፡
///
/// [`iter`]: BinaryHeap::iter
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Iter<'a, T: 'a> {
    iter: slice::Iter<'a, T>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for Iter<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Iter").field(&self.iter.as_slice()).finish()
    }
}

// FIXME(#26925) ለ `#[derive(Clone)]` ሞገስን ያስወግዱ
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Clone for Iter<'_, T> {
    fn clone(&self) -> Self {
        Iter { iter: self.iter.clone() }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for Iter<'a, T> {
    type Item = &'a T;

    #[inline]
    fn next(&mut self) -> Option<&'a T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }

    #[inline]
    fn last(self) -> Option<&'a T> {
        self.iter.last()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for Iter<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a T> {
        self.iter.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for Iter<'_, T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Iter<'_, T> {}

/// በ `BinaryHeap` ንጥረ ነገሮች ላይ የራሱ የሆነ ተደጋጋሚ።
///
/// ይህ `struct` በ [`BinaryHeap::into_iter()`] የተፈጠረ (በ `IntoIterator` trait የቀረበ)።
/// ለተጨማሪ ሰነዶቹን ይመልከቱ ፡፡
///
/// [`into_iter`]: BinaryHeap::into_iter
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Clone)]
pub struct IntoIter<T> {
    iter: vec::IntoIter<T>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for IntoIter<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("IntoIter").field(&self.iter.as_slice()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Iterator for IntoIter<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> DoubleEndedIterator for IntoIter<T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.iter.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for IntoIter<T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for IntoIter<T> {}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<T> SourceIter for IntoIter<T> {
    type Source = IntoIter<T>;

    #[inline]
    unsafe fn as_inner(&mut self) -> &mut Self::Source {
        self
    }
}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<I> InPlaceIterable for IntoIter<I> {}

impl<I> AsIntoIter for IntoIter<I> {
    type Item = I;

    fn as_into_iter(&mut self) -> &mut vec::IntoIter<Self::Item> {
        &mut self.iter
    }
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
#[derive(Clone, Debug)]
pub struct IntoIterSorted<T> {
    inner: BinaryHeap<T>,
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> Iterator for IntoIterSorted<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.inner.pop()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let exact = self.inner.len();
        (exact, Some(exact))
    }
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> ExactSizeIterator for IntoIterSorted<T> {}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> FusedIterator for IntoIterSorted<T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T: Ord> TrustedLen for IntoIterSorted<T> {}

/// በ `BinaryHeap` ንጥረ ነገሮች ላይ የፍሳሽ ማስወገጃ ተደጋጋሚ።
///
/// ይህ `struct` በ [`BinaryHeap::drain()`] የተፈጠረ ነው።
/// ለተጨማሪ ሰነዶቹን ይመልከቱ ፡፡
///
/// [`drain`]: BinaryHeap::drain
#[stable(feature = "drain", since = "1.6.0")]
#[derive(Debug)]
pub struct Drain<'a, T: 'a> {
    iter: vec::Drain<'a, T>,
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> Iterator for Drain<'_, T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> DoubleEndedIterator for Drain<'_, T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.iter.next_back()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> ExactSizeIterator for Drain<'_, T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Drain<'_, T> {}

/// በ `BinaryHeap` ንጥረ ነገሮች ላይ የፍሳሽ ማስወገጃ ተደጋጋሚ።
///
/// ይህ `struct` በ [`BinaryHeap::drain_sorted()`] የተፈጠረ ነው።
/// ለተጨማሪ ሰነዶቹን ይመልከቱ ፡፡
///
/// [`drain_sorted`]: BinaryHeap::drain_sorted
#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
#[derive(Debug)]
pub struct DrainSorted<'a, T: Ord> {
    inner: &'a mut BinaryHeap<T>,
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<'a, T: Ord> Drop for DrainSorted<'a, T> {
    /// ክምር አባላትን በቅል ቅደም ተከተል ያስወግዳል ፡፡
    fn drop(&mut self) {
        struct DropGuard<'r, 'a, T: Ord>(&'r mut DrainSorted<'a, T>);

        impl<'r, 'a, T: Ord> Drop for DropGuard<'r, 'a, T> {
            fn drop(&mut self) {
                while self.0.inner.pop().is_some() {}
            }
        }

        while let Some(item) = self.inner.pop() {
            let guard = DropGuard(self);
            drop(item);
            mem::forget(guard);
        }
    }
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> Iterator for DrainSorted<'_, T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.inner.pop()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let exact = self.inner.len();
        (exact, Some(exact))
    }
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> ExactSizeIterator for DrainSorted<'_, T> {}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> FusedIterator for DrainSorted<'_, T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T: Ord> TrustedLen for DrainSorted<'_, T> {}

#[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
impl<T: Ord> From<Vec<T>> for BinaryHeap<T> {
    /// `Vec<T>` ን ወደ `BinaryHeap<T>` ይቀይረዋል።
    ///
    /// ይህ ልወጣ በቦታው የሚከሰት ሲሆን *O*(*n*) የጊዜ ውስብስብነት አለው።
    fn from(vec: Vec<T>) -> BinaryHeap<T> {
        let mut heap = BinaryHeap { data: vec };
        heap.rebuild();
        heap
    }
}

#[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
impl<T> From<BinaryHeap<T>> for Vec<T> {
    /// `BinaryHeap<T>` ን ወደ `Vec<T>` ይቀይረዋል።
    ///
    /// ይህ ልወጣ ምንም የውሂብ እንቅስቃሴ ወይም ምደባ አያስፈልገውም ፣ እና የዘወትር ውስብስብነት አለው።
    ///
    fn from(heap: BinaryHeap<T>) -> Vec<T> {
        heap.data
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> FromIterator<T> for BinaryHeap<T> {
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> BinaryHeap<T> {
        BinaryHeap::from(iter.into_iter().collect::<Vec<_>>())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> IntoIterator for BinaryHeap<T> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// የሚበላ ተደጋጋሚ ይፈጥራል ፣ ማለትም ፣ እያንዳንዱን እሴት በዘፈቀደ ቅደም ተከተል ከባለ ሁለትዮሽ ክምር የሚያወጣ።
    /// ባለ ሁለትዮሽ ክምር ይህንን ከጠራ በኋላ መጠቀም አይቻልም ፡፡
    ///
    /// # Examples
    ///
    /// መሠረታዊ አጠቃቀም
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4]);
    ///
    /// // 1, 2, 3, 4 ን በዘፈቀደ ቅደም ተከተል ያትሙ
    /// for x in heap.into_iter() {
    ///     // x &i32 ሳይሆን i32 ዓይነት አለው
    ///     println!("{}", x);
    /// }
    /// ```
    ///
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { iter: self.data.into_iter() }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a BinaryHeap<T> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Extend<T> for BinaryHeap<T> {
    #[inline]
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        <Self as SpecExtend<I>>::spec_extend(self, iter);
    }

    #[inline]
    fn extend_one(&mut self, item: T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

impl<T: Ord, I: IntoIterator<Item = T>> SpecExtend<I> for BinaryHeap<T> {
    default fn spec_extend(&mut self, iter: I) {
        self.extend_desugared(iter.into_iter());
    }
}

impl<T: Ord> SpecExtend<BinaryHeap<T>> for BinaryHeap<T> {
    fn spec_extend(&mut self, ref mut other: BinaryHeap<T>) {
        self.append(other);
    }
}

impl<T: Ord> BinaryHeap<T> {
    fn extend_desugared<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        let iterator = iter.into_iter();
        let (lower, _) = iterator.size_hint();

        self.reserve(lower);

        iterator.for_each(move |elem| self.push(elem));
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: 'a + Ord + Copy> Extend<&'a T> for BinaryHeap<T> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &item: &'a T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}