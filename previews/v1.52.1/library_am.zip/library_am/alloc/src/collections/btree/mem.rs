use core::intrinsics;
use core::mem;
use core::ptr;

/// ይህ አግባብ የሆነውን ተግባር በመጥራት ከ `v` ልዩ ማጣቀሻ በስተጀርባ ያለውን እሴት ይተካል።
///
///
/// በ `change` መዘጋት ውስጥ አንድ panic ከተከሰተ አጠቃላይ ሂደቱ ይቋረጣል።
#[allow(dead_code)] // እንደ ምሳሌ ይያዙ እና ለ future አጠቃቀም
#[inline]
pub fn take_mut<T>(v: &mut T, change: impl FnOnce(T) -> T) {
    replace(v, |value| (change(value), ()))
}

/// ይህ አግባብ የሆነውን ተግባር በመጥራት ከ `v` ልዩ ማጣቀሻ በስተጀርባ ያለውን እሴት ይተካዋል እና በመንገድ ላይ የተገኘውን ውጤት ይመልሳል።
///
///
/// በ `change` መዘጋት ውስጥ አንድ panic ከተከሰተ አጠቃላይ ሂደቱ ይቋረጣል።
#[inline]
pub fn replace<T, R>(v: &mut T, change: impl FnOnce(T) -> (T, R)) -> R {
    struct PanicGuard;
    impl Drop for PanicGuard {
        fn drop(&mut self) {
            intrinsics::abort()
        }
    }
    let guard = PanicGuard;
    let value = unsafe { ptr::read(v) };
    let (new_value, ret) = change(value);
    unsafe {
        ptr::write(v, new_value);
    }
    mem::forget(guard);
    ret
}