use super::merge_iter::MergeIterInner;
use super::node::{self, Root};
use core::iter::FusedIterator;

impl<K, V> Root<K, V> {
    /// በመንገድ ላይ የ `length` ተለዋዋጭን በመጨመር ከሁለቱ ወደ ላይ ከሚወጡ ተጓeraች ህብረት ሁሉንም የቁልፍ እሴት ጥንድዎችን ይተገበራል።የኋላው ጠብታ ተቆጣጣሪ በሚደናገጥበት ጊዜ ደዋዩ ፍሳሽን ለማስወገድ ቀላል ያደርገዋል ፡፡
    ///
    /// ሁለቱም ተጓeraች አንድ ዓይነት ቁልፍ ካፈሩ ይህ ዘዴ ጥንድውን ከግራ ተደጋጋሚው ላይ ይጥላል እና ጥንድውን ከቀኝ ተደጋጋሚው ጋር ያያይዘዋል ፡፡
    ///
    /// እንደ `BTreeMap` ሁሉ ዛፉ በጥብቅ ወደ ላይ በሚወጣው ቅደም ተከተል እንዲጨርስ ከፈለጉ ሁለቱም ተጓ strictlyች በጥብቅ በሚወጣው ቅደም ተከተል ቁልፎችን ማምረት አለባቸው ፣ እያንዳንዳቸው በዛፉ ውስጥ ካሉ ሁሉም ቁልፎች ይበልጣሉ ፣ ሲገቡም በዛፉ ውስጥ ያሉትን ቁልፎች ሁሉ ይጨምራሉ ፡፡
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn append_from_sorted_iters<I>(&mut self, left: I, right: I, length: &mut usize)
    where
        K: Ord,
        I: Iterator<Item = (K, V)> + FusedIterator,
    {
        // `left` እና `right` ን በቅደም ተከተል በተስተካከለ ቅደም ተከተል ለማዋሃድ እንዘጋጃለን።
        let iter = MergeIter(MergeIterInner::new(left, right));

        // ይህ በእንዲህ እንዳለ ፣ በተደረደሩ ቅደም ተከተሎች ውስጥ አንድ ዛፍ እንሠራለን።
        self.bulk_push(iter, length)
    }

    /// በመንገድ ላይ የ `length` ተለዋዋጭን በመጨመር ሁሉንም የቁልፍ ዋጋ ጥንድዎችን ወደ ዛፉ መጨረሻ ይገፋፋቸዋል።
    /// የኋላው ተሟጋች በሚደናገጥበት ጊዜ ደዋዩ ፍሳሽን ለማስወገድ ለደዋዩ ቀላል ያደርገዋል ፡፡
    ///
    pub fn bulk_push<I>(&mut self, iter: I, length: &mut usize)
    where
        I: Iterator<Item = (K, V)>,
    {
        let mut cur_node = self.borrow_mut().last_leaf_edge().into_node();
        // በትክክለኛው ደረጃ ላይ ወደ አንጓዎች በመገፋፋት በሁሉም የቁልፍ እሴት ጥንዶች ውስጥ ይቅጠሩ ፡፡
        for (key, value) in iter {
            // የቁልፍ እሴት ጥንድ አሁን ባለው የቅጠል መስቀለኛ ክፍል ውስጥ ለመግፋት ይሞክሩ።
            if cur_node.len() < node::CAPACITY {
                cur_node.push(key, value);
            } else {
                // ቦታ አይቀረውም ፣ ወደላይ ይሂዱ እና እዚያ ይግፉ ፡፡
                let mut open_node;
                let mut test_node = cur_node.forget_type();
                loop {
                    match test_node.ascend() {
                        Ok(parent) => {
                            let parent = parent.into_node();
                            if parent.len() < node::CAPACITY {
                                // ክፍት ቦታ ያለው መስቀለኛ መንገድ ተገኝቷል ፣ እዚህ ይግፉ።
                                open_node = parent;
                                break;
                            } else {
                                // እንደገና ወደ ላይ ውጣ ፡፡
                                test_node = parent.forget_type();
                            }
                        }
                        Err(_) => {
                            // እኛ አናት ላይ ነን ፣ አዲስ የስር መስቀለኛ ክፍል ይፍጠሩ እና እዚያ ይግፉ ፡፡
                            open_node = self.push_internal_level();
                            break;
                        }
                    }
                }

                // የቁልፍ እሴት ጥንድ እና አዲስ የቀኝ ንዑስ ዛፍ ይግፉ።
                let tree_height = open_node.height() - 1;
                let mut right_tree = Root::new();
                for _ in 0..tree_height {
                    right_tree.push_internal_level();
                }
                open_node.push(key, value, right_tree);

                // እንደገና ወደ ቀኝ-በጣም ቅጠል ይሂዱ።
                cur_node = open_node.forget_type().last_leaf_edge().into_node();
            }

            // የካርታው ተጓዳኝ ንጥረ ነገሮችን ቢያራምድም እንኳ የተካተቱትን አካላት እንደጣለ ለማረጋገጥ የእያንዳንዱን ድግግሞሽ መጠን ይጨምሩ።
            //
            *length += 1;
        }
        self.fix_right_border_of_plentiful();
    }
}

// ሁለት የተደረደሩ ቅደም ተከተሎችን ወደ አንድ ለማቀላቀል አንድ ተደጋጋሚ
struct MergeIter<K, V, I: Iterator<Item = (K, V)>>(MergeIterInner<I>);

impl<K: Ord, V, I> Iterator for MergeIter<K, V, I>
where
    I: Iterator<Item = (K, V)> + FusedIterator,
{
    type Item = (K, V);

    /// ሁለት ቁልፎች እኩል ከሆኑ የቁልፍ እሴት ጥንድን ከትክክለኛው ምንጭ ይመልሳል።
    fn next(&mut self) -> Option<(K, V)> {
        let (a_next, b_next) = self.0.nexts(|a: &(K, V), b: &(K, V)| K::cmp(&a.0, &b.0));
        b_next.or(a_next)
    }
}