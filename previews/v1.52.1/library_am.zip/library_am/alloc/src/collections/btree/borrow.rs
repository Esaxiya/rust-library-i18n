use core::marker::PhantomData;
use core::ptr::NonNull;

/// ሞዴሎቹ አንዳንድ ልዩ የማጣቀሻ ቦታዎችን ያዘጋጃሉ ፣ ሪቦሮው እና ሁሉም ዘሮቹ (ማለትም ፣ ሁሉም ጠቋሚዎች እና ከእሱ የተገኙ ማጣቀሻዎች) በተወሰነ ጊዜ ከእንግዲህ ወዲህ ጥቅም ላይ የማይውሉ ሲሆን ከዚያ በኋላ የመጀመሪያውን ልዩ ማጣቀሻ እንደገና መጠቀም ይፈልጋሉ .
///
///
/// ተበዳሪው ቼክ ብዙውን ጊዜ ይህንን የብድር መደራረብ ለእርስዎ ያስተናግዳል ፣ ነገር ግን ይህንን ቁልል የሚያሟሉ አንዳንድ የቁጥጥር ፍሰቶች አጠናቃዩ እንዲከተለው በጣም የተወሳሰበ ነው።
/// ኤክስኤክስኤክስ (`DormantMutRef`) እራስዎን መበደርን ለመፈተሽ ያስችልዎታል ፣ አሁንም የተደራረበ ተፈጥሮን እየገለፀ እና ይህን ያለተገለጸ ባህሪ ይህን ለማድረግ የሚያስፈልገውን ጥሬ አመላካች ኮድ ያጠቃልላል ፡፡
///
///
///
///
///
pub struct DormantMutRef<'a, T> {
    ptr: NonNull<T>,
    _marker: PhantomData<&'a mut T>,
}

unsafe impl<'a, T> Sync for DormantMutRef<'a, T> where &'a mut T: Sync {}
unsafe impl<'a, T> Send for DormantMutRef<'a, T> where &'a mut T: Send {}

impl<'a, T> DormantMutRef<'a, T> {
    /// አንድ ልዩ ብድር ይያዙ ፣ እና ወዲያውኑ እንደገና ያስገቡት።
    /// ለአቀናባሪው ፣ የአዲሱ ማጣቀሻ ዕድሜ ልክ ከዋናው ማጣቀሻ የሕይወት ዘመን ጋር ተመሳሳይ ነው ፣ ግን እርስዎ promise ለአጭር ጊዜ እንዲጠቀሙበት።
    ///
    pub fn new(t: &'a mut T) -> (&'a mut T, Self) {
        let ptr = NonNull::from(t);
        // ደህንነት-እኛ በ‹XXXX›በኩል ብድሩን በሙሉ እንይዛለን ፣ እናጋልጣለን
        // ይህ ማጣቀሻ ብቻ ነው ፣ ስለሆነም ልዩ ነው።
        let new_ref = unsafe { &mut *ptr.as_ptr() };
        (new_ref, Self { ptr, _marker: PhantomData })
    }

    /// መጀመሪያ ወደ ተያዘው ልዩ ብድር ይመለሱ።
    ///
    /// # Safety
    ///
    /// ሪቦሮው ማለቅ አለበት ፣ ማለትም ፣ በ `new` የተመለሰው ማጣቀሻ እና ሁሉም ጠቋሚዎች እና ከእሱ የተገኙ ማጣቀሻዎች ከእንግዲህ ጥቅም ላይ መዋል የለባቸውም።
    ///
    pub unsafe fn awaken(self) -> &'a mut T {
        // ደህንነት-የራሳችን የደህንነት ሁኔታዎች ይህ ማጣቀሻ እንደገና ልዩ ነው ማለት ነው ፡፡
        unsafe { &mut *self.ptr.as_ptr() }
    }
}

#[cfg(test)]
mod tests;