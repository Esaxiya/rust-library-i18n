use crate::fmt::Debug;
use std::cmp::Ordering;
use std::sync::atomic::{AtomicUsize, Ordering::SeqCst};

/// በተለይ ክስተቶች መከታተል መሆኑን የብልሽት ፈተና ፍጡርም አጋጣሚዎች የሚሆን ንድፍ.
/// አንዳንድ አጋጣሚዎች በተወሰነ ጊዜ ወደ panic ሊዋቀሩ ይችላሉ ፡፡
/// ክስተቶች `clone` ፣ `drop` ወይም አንዳንድ የማይታወቁ `query` ናቸው።
///
/// የብልሽትና የሙከራ ዱሚዎች በመታወቂያ መታወቂያ ተለይተው ታዝዘዋል ፣ ስለሆነም በ BTreeMap ውስጥ እንደ ቁልፍ ያገለግላሉ።
/// ትግበራ ሆን ተብሎ የሚጠቀመው ከ `Debug` trait በስተቀር በ crate ውስጥ በተገለጸው ነገር ላይ አይመካም ፡፡
///
#[derive(Debug)]
pub struct CrashTestDummy {
    id: usize,
    cloned: AtomicUsize,
    dropped: AtomicUsize,
    queried: AtomicUsize,
}

impl CrashTestDummy {
    /// የብልሽት ሙከራ dummy ዲዛይን ይፈጥራል።`id` የትርጓሜዎችን ቅደም ተከተል እና እኩልነት ይወስናል ፡፡
    pub fn new(id: usize) -> CrashTestDummy {
        CrashTestDummy {
            id,
            cloned: AtomicUsize::new(0),
            dropped: AtomicUsize::new(0),
            queried: AtomicUsize::new(0),
        }
    }

    /// የትኞቹን ክስተቶች እንደሚመዘግብ እና በአማራጭ panics ን የሚመዘግብ የብልሽት ሙከራ dummy ምሳሌን ይፈጥራል።
    ///
    pub fn spawn(&self, panic: Panic) -> Instance<'_> {
        Instance { origin: self, panic }
    }

    /// የእምቢተኞቹ ጊዜያት ስንት ጊዜ በአንድ ጊዜ እንደነበሩ ይመልሳል።
    pub fn cloned(&self) -> usize {
        self.cloned.load(SeqCst)
    }

    /// የእምቢተኞቹ ጊዜያት ስንት ጊዜ እንደተጣሉ ይመልሳል።
    pub fn dropped(&self) -> usize {
        self.dropped.load(SeqCst)
    }

    /// የ‹XXXX›አባል ምን ያህል ጊዜያት የእንደሚሉ አጋጣሚዎች እንደተጠሩ ይመልሳል ፡፡
    pub fn queried(&self) -> usize {
        self.queried.load(SeqCst)
    }
}

#[derive(Debug)]
pub struct Instance<'a> {
    origin: &'a CrashTestDummy,
    panic: Panic,
}

#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub enum Panic {
    Never,
    InClone,
    InDrop,
    InQuery,
}

impl Instance<'_> {
    pub fn id(&self) -> usize {
        self.origin.id
    }

    /// አንዳንድ ያልታወቁ መጠይቆች ፣ ውጤቱ ቀድሞውኑ ተሰጥቷል።
    pub fn query<R>(&self, result: R) -> R {
        self.origin.queried.fetch_add(1, SeqCst);
        if self.panic == Panic::InQuery {
            panic!("panic in `query`");
        }
        result
    }
}

impl Clone for Instance<'_> {
    fn clone(&self) -> Self {
        self.origin.cloned.fetch_add(1, SeqCst);
        if self.panic == Panic::InClone {
            panic!("panic in `clone`");
        }
        Self { origin: self.origin, panic: Panic::Never }
    }
}

impl Drop for Instance<'_> {
    fn drop(&mut self) {
        self.origin.dropped.fetch_add(1, SeqCst);
        if self.panic == Panic::InDrop {
            panic!("panic in `drop`");
        }
    }
}

impl PartialOrd for Instance<'_> {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.id().partial_cmp(&other.id())
    }
}

impl Ord for Instance<'_> {
    fn cmp(&self, other: &Self) -> Ordering {
        self.id().cmp(&other.id())
    }
}

impl PartialEq for Instance<'_> {
    fn eq(&self, other: &Self) -> bool {
        self.id().eq(&other.id())
    }
}

impl Eq for Instance<'_> {}