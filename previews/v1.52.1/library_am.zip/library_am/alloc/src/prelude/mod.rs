//! ምደባው Prelude
//!
//! የዚህ ሞጁል ዓላማ በተለምዶ የሚጠቀሙባቸውን የ `alloc` crate ዕቃዎች ወደ ሞጁሎቹ አናት ላይ በመጨመር ከውጭ የሚገቡትን ለማስታገስ ነው ፡፡
//!
//!
//! ```
//! # #![allow(unused_imports)]
//! #![feature(alloc_prelude)]
//! extern crate alloc;
//! use alloc::prelude::v1::*;
//! ```

#![unstable(feature = "alloc_prelude", issue = "58935")]

pub mod v1;