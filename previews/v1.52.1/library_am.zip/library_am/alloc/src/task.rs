#![stable(feature = "wake_trait", since = "1.51.0")]
//! ከማይመሳሰል ተግባራት ጋር ለመስራት ዓይነቶች እና Traits
use core::mem::ManuallyDrop;
use core::task::{RawWaker, RawWakerVTable, Waker};

use crate::sync::Arc;

/// በአፈፃፀም ላይ አንድ ሥራን የማንቃት አተገባበር።
///
/// ይህ trait [`Waker`] ን ለመፍጠር ሊያገለግል ይችላል።
/// አንድ አስፈፃሚ የዚህን የ trait ትግበራ መግለፅ ይችላል ፣ እናም በዚያ ፈፃሚ ላይ ወደተከናወኑ ተግባራት ለማለፍ ዋከርን ይጠቀማል ፡፡
///
/// ይህ trait [`RawWaker`] ን ለመገንባት ከማስታወስ ደህንነቱ የተጠበቀ እና ergonomic አማራጭ ነው።
/// አንድ ተግባርን ለማንቃት ያገለገሉ መረጃዎች በ [`Arc`] ውስጥ የተከማቹበትን የጋራ አስፈፃሚ ንድፍን ይደግፋል።
/// አንዳንድ ፈጻሚዎች (በተለይም ለተካተቱት ስርዓቶች) ይህንን ኤፒአይ መጠቀም አይችሉም ፣ ለዚህም ነው [`RawWaker`] ለእነዚያ ስርዓቶች እንደ አማራጭ የሚኖረው ፡፡
///
/// [arc]: ../../std/sync/struct.Arc.html
///
/// # Examples
///
/// future ን የሚወስድ እና አሁን ባለው ክር ላይ እስከሚጠናቀቅ ድረስ የሚያሄድ መሰረታዊ የ‹XXXX›ተግባር።
///
/// **Note:** ይህ ምሳሌ ቀለል ያህል ትክክለኛነት ላይ ተሠማርተው ነበር.
/// የጊዜ ገደቦችን ለመከላከል የምርት ደረጃ ትግበራዎች እንዲሁ መካከለኛ ጥሪዎችን ወደ `thread::unpark` እንዲሁም የጎጆ ጥሪዎች ማስተናገድ ያስፈልጋቸዋል ፡፡
///
///
/// ```rust
/// use std::future::Future;
/// use std::sync::Arc;
/// use std::task::{Context, Poll, Wake};
/// use std::thread::{self, Thread};
///
/// /// ተብሎ ጊዜ በአሁኑ ክር ከእንቅልፏ መሆኑን አንድ waker.
/// struct ThreadWaker(Thread);
///
/// impl Wake for ThreadWaker {
///     fn wake(self: Arc<Self>) {
///         self.0.unpark();
///     }
/// }
///
/// /// አሁን ባለው ክር ላይ ለማጠናቀቅ የ future ን ያሂዱ።
/// fn block_on<T>(fut: impl Future<Output = T>) -> T {
///     // እንዲጣራ የ future ን ይሰኩ ፡፡
///     let mut fut = Box::pin(fut);
///
///     // ወደ future እንዲተላለፍ አዲስ አውድ ይፍጠሩ።
///     let t = thread::current();
///     let waker = Arc::new(ThreadWaker(t)).into();
///     let mut cx = Context::from_waker(&waker);
///
///     // future ን ለማጠናቀቅ ያሂዱ።
///     loop {
///         match fut.as_mut().poll(&mut cx) {
///             Poll::Ready(res) => return res,
///             Poll::Pending => thread::park(),
///         }
///     }
/// }
///
/// block_on(async {
///     println!("Hi from inside a future!");
/// });
/// ```
///
///
///
///
#[stable(feature = "wake_trait", since = "1.51.0")]
pub trait Wake {
    /// ይህንን ተግባር ይንቁ ፡፡
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake(self: Arc<Self>);

    /// ነቃውን ሳይበላው ይህንን ተግባር ይንቁ ፡፡
    ///
    /// አንድ አስፈፃሚ ነቃሹን ሳይወስድ ከእንቅልፍ ለመነሳት በርካሽ መንገድ የሚደግፍ ከሆነ ይህን ዘዴ መሻር አለበት ፡፡
    /// በነባሪነት [`Arc`] ን ይሸፍናል እና በክሎኑ ላይ [`wake`] ን ይጠራል ፡፡
    ///
    /// [`wake`]: Wake::wake
    ///
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake_by_ref(self: &Arc<Self>) {
        self.clone().wake();
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for Waker {
    fn from(waker: Arc<W>) -> Waker {
        // ደህንነት-ጥሬ_ዋኪን ደህንነቱ በተጠበቀ ሁኔታ ስለሚገነባ ይህ ደህንነቱ የተጠበቀ ነው
        // አንድ RawWaker ከ አርክ<W>.
        unsafe { Waker::from_raw(raw_waker(waker)) }
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for RawWaker {
    fn from(waker: Arc<W>) -> RawWaker {
        raw_waker(waker)
    }
}

// NB: አንድ RawWaker በመገንባት ይህ የግል ተግባር ይልቅ, ጥቅም ላይ ነው
// የ `From<Arc<W>> for Waker` ደህንነት በትክክለኛው የ trait መላኪያ ላይ የተመረኮዘ አለመሆኑን ለማረጋገጥ ይህንን ወደ `From<Arc<W>> for RawWaker` impl በማሳየት ይልቁንስ ሁለቱም ይህንን ተግባር በቀጥታ እና በግልፅ ይጠሩታል ፡፡
//
//
//
#[inline(always)]
fn raw_waker<W: Wake + Send + Sync + 'static>(waker: Arc<W>) -> RawWaker {
    // እሱን ለማጣመር የአርኪው የማጣቀሻ ብዛት ይጨምሩ።
    unsafe fn clone_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) -> RawWaker {
        unsafe { Arc::increment_strong_count(waker as *const W) };
        RawWaker::new(
            waker as *const (),
            &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
        )
    }

    // አርክን ወደ Wake::wake ተግባር በማዛወር በእሴት ይንቁ
    unsafe fn wake<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { Arc::from_raw(waker as *const W) };
        <W as Wake>::wake(waker);
    }

    // በማጣቀሻ ይንቁ ፣ ንቃቱን ላለማጣት በማኒውድሮፕ ያጠቃልሉት
    unsafe fn wake_by_ref<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { ManuallyDrop::new(Arc::from_raw(waker as *const W)) };
        <W as Wake>::wake_by_ref(&waker);
    }

    // ጠብታ ላይ ቅስት ያለውን ማጣቀሻ ቆጠራ ቀንስ
    unsafe fn drop_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        unsafe { Arc::decrement_strong_count(waker as *const W) };
    }

    RawWaker::new(
        Arc::into_raw(waker) as *const (),
        &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
    )
}