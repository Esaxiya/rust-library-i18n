#![stable(feature = "rust1", since = "1.0.0")]

//! ክር-አስተማማኝ የማጣቀሻ-ቆጠራ ጠቋሚዎች ፡፡
//!
//! ለተጨማሪ ዝርዝሮች የ [`Arc<T>`][Arc] ሰነድን ይመልከቱ ፡፡

use core::any::Any;
use core::borrow;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::hint;
use core::intrinsics::abort;
use core::iter;
use core::marker::{PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;
use core::sync::atomic;
use core::sync::atomic::Ordering::{Acquire, Relaxed, Release, SeqCst};

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::rc::is_dangling;
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

/// ወደ `Arc` ሊደረግ በሚችል የማጣቀሻዎች መጠን ላይ ለስላሳ ገደብ።
///
/// ከዚህ ወሰን በላይ መሄድ ፕሮግራምዎን ያስወገዳል (ምንም እንኳን የግድ ባይሆንም) በ _exactly_ `MAX_REFCOUNT + 1` ማጣቀሻዎች ፡፡
///
const MAX_REFCOUNT: usize = (isize::MAX) as usize;

#[cfg(not(sanitize = "thread"))]
macro_rules! acquire {
    ($x:expr) => {
        atomic::fence(Acquire)
    };
}

// ThreadSanitizer የማህደረ ትውስታ አጥሮችን አይደግፍም ፡፡
// በአርክ/ደካማ አተገባበር ውስጥ የተሳሳቱ አዎንታዊ ሪፖርቶችን ለማስወገድ በምትኩ ለማመሳሰል የአቶሚክ ጭነቶችን ይጠቀሙ ፡፡
//
#[cfg(sanitize = "thread")]
macro_rules! acquire {
    ($x:expr) => {
        $x.load(Acquire)
    };
}

/// ክር-አስተማማኝ የማጣቀሻ-ቆጠራ ጠቋሚ።'Arc' ማለት `አቶሚካዊ ማጣቀሻ ተቆጠረ` ማለት ነው ፡፡
///
/// `Arc<T>` ዓይነት በኪሳራው ውስጥ የተመደበ የ `T` ዓይነት እሴት የጋራ ባለቤትነት ይሰጣል።`Arc` ን በ `Arc` ላይ መጠየቁ አዲስ `Arc` ምሳሌን ያስገኛል ፣ ይህም ከምንጩ `Arc` ጋር ተመሳሳይ ክምር ላይ የሚያመላክት ሲሆን የማጣቀሻ ቆጠራን ይጨምራል ፡፡
/// ለተጠቀሰው ምደባ የመጨረሻው የ `Arc` ጠቋሚ ሲደመሰስ በዚያ ምደባ ውስጥ የተከማቸው እሴት (ብዙውን ጊዜ "inner value" ተብሎ ይጠራል) እንዲሁ ይወርዳል።
///
/// በ Rust ውስጥ የተጋሩ ማጣቀሻዎች በነባሪነት ሚውቴሽን አይፈቅድም ፣ እና `Arc` እንዲሁ የተለየ አይደለም-በአጠቃላይ በ‹XXXX›ውስጥ የሆነ ነገር የሚለዋወጥ ማጣቀሻ ማግኘት አይችሉም ፡፡በ `Arc` በኩል መለወጥ ከፈለጉ ፣ [`Mutex`][mutex] ፣ [`RwLock`][rwlock] ን ወይም ከ‹[`Atomic`][atomic]›አይነቶችን ይጠቀሙ ፡፡
///
/// ## ክር ደህንነት
///
/// [`Rc<T>`] በተለየ `Arc<T>` በውስጡ ማጣቀሻ ቆጠራ ለ አቶሚክ ክወናዎችን ይጠቀማል.ይህ ማለት በክር የተጠበቀ ነው ማለት ነው ፡፡ጉዳቱ የአቶሚክ አሠራሮች ከተራ የማስታወስ ተደራሽነት የበለጠ ውድ ናቸው ፡፡በክሮች መካከል በማጣቀሻ የተቆጠሩ ክፍፍሎችን የማያካፍሉ ከሆነ ለዝቅተኛ የላይኛው ክፍል [`Rc<T>`] ን ለመጠቀም ያስቡ ፡፡
/// [`Rc<T>`] ደህንነቱ የተጠበቀ ነባሪ ነው ፣ ምክንያቱም አጻጻፉ በክርዎች መካከል [`Rc<T>`] ለመላክ ማንኛውንም ሙከራ ይይዛል።
/// ሆኖም የቤተ-መጽሐፍት ሸማቾች የበለጠ ተጣጣፊነትን ለመስጠት አንድ ቤተ-መጽሐፍት `Arc<T>` ን ሊመርጥ ይችላል።
///
/// `Arc<T>` `T` [`Send`] እና [`Sync`] ን ተግባራዊ እስካደረገ ድረስ [`Send`] እና [`Sync`] ን ይተገበራል።
/// ክር-ደህና ያልሆነ ዓይነት `T` ን በ‹`Arc<T>`›ውስጥ ክር-ደህንነቱ የተጠበቀ ለማድረግ ለምን አይችሉም?ይህ መጀመሪያ ላይ ትንሽ ተቃራኒ ሊሆን ይችላል-ከሁሉም በኋላ የ `Arc<T>` ክር ደህንነት አይደለም?ቁልፉ ይህ ነው `Arc<T>` ተመሳሳይ ውሂብ ብዙ የባለቤትነት መብት እንዲኖረው ደህንነቱ የተጠበቀ ክር ያደርገዋል ፣ ነገር ግን በመረጃው ላይ የክርን ደህንነት አይጨምርም ፡፡
///
/// አስብ `አርክ <` [`RefCell<T>"]">
/// [`RefCell<T>`] [`Sync`] አይደለም ፣ እና `Arc<T>` ሁልጊዜ [`Send`] ከሆነ ፣ `አርክ <` [`RefCell<T>`>>> እንዲሁ ይሆናል
/// ግን ከዚያ ችግር አለብን
/// [`RefCell<T>`] ደህንነቱ የተጠበቀ ክር አይደለም;አቶሚክ ያልሆኑ አሠራሮችን በመጠቀም የብድር ቆጠራውን ይከታተላል ፡፡
///
/// በመጨረሻ ፣ ይህ ማለት `Arc<T>` ን ከአንድ ዓይነት የ [`std::sync`] ዓይነት ፣ ብዙውን ጊዜ [`Mutex<T>`][mutex] ጋር ማጣመር ያስፈልግዎት ይሆናል ማለት ነው ፡፡
///
/// ## ከ `Weak` ጋር ዑደቶችን ማፍረስ
///
/// የ [`downgrade`][downgrade] ዘዴ ባለቤት ያልሆነ [`Weak`] ጠቋሚ ለመፍጠር ሊያገለግል ይችላል።የ [`Weak`] ጠቋሚ d ወደ `Arc` [`upgrade`][upgrade] d ሊሆን ይችላል ፣ ነገር ግን በምድቡ ውስጥ የተከማቸው እሴት ቀድሞውኑ ከወደቀ ይህ [`None`] ን ይመልሳል።
/// በሌላ አገላለጽ የ `Weak` አመልካቾች በምደባው ውስጥ ያለውን እሴት በሕይወት እንዲቆዩ አያደርጉም ፤ሆኖም ምደባውን (የዋጋውን መደብር) በሕይወት እንዲኖሩ * ያደርጋሉ።
///
/// በ `Arc` ጠቋሚዎች መካከል አንድ ዑደት በጭራሽ አይተላለፍም።
/// በዚህ ምክንያት [`Weak`] ዑደቶችን ለማፍረስ ጥቅም ላይ ይውላል።ለምሳሌ ፣ አንድ ዛፍ ከወላጅ አንጓዎች እስከ ልጆች ጠንካራ የ `Arc` ጠቋሚዎች እና የ [`Weak`] ጠቋሚዎች ከልጆች ወደ ወላጆቻቸው ሊኖረው ይችላል ፡፡
///
/// # የክሎንግ ማጣቀሻዎች
///
/// አንድ ነባር ማጣቀሻ-ይቆጠራል ጠቋሚ ከ አዲስ ማጣቀሻ መፍጠር በመጠቀም የሚደረገው የ `Clone` trait [`Arc<T>`][Arc] እና [`Weak<T>`][Weak] ለ በተግባር ላይ.
///
/// ```
/// use std::sync::Arc;
/// let foo = Arc::new(vec![1.0, 2.0, 3.0]);
/// // ከዚህ በታች ያሉት ሁለት አገባብ አቻዎች እኩል ናቸው ፡፡
/// let a = foo.clone();
/// let b = Arc::clone(&foo);
/// // a, b እና foo ሁሉም ወደ ተመሳሳይ ማህደረ ትውስታ ቦታ የሚጠቁሙ አርኮች ናቸው
/// ```
///
/// ## `Deref` behavior
///
/// `Arc<T>` በራስ-ሰር ወደ `T` (በ [`Deref`][deref] trait በኩል) መሰረዝ ፣ ስለሆነም በ‹`Arc<T>`›ዓይነት ዋጋ ላይ የ `T` ዘዴዎችን መጥራት ይችላሉ ፡፡የስም ቅራኔዎችን ከ‹T›ዘዴዎች ለማስቀረት የ `Arc<T>` ዘዴዎች ራሱ [fully qualified syntax] ን በመጠቀም የሚጠሩ ተጓዳኝ ተግባራት ናቸው-
///
/// ```
/// use std::sync::Arc;
///
/// let my_arc = Arc::new(());
/// Arc::downgrade(&my_arc);
/// ```
///
/// አርክ<T>እንደ `Clone` ያሉ የ traits ትግበራዎች እንዲሁ ሙሉ ብቃት ያለው አገባብ በመጠቀም ሊጠሩ ይችላሉ ፡፡
/// አንዳንድ ሰዎች ሙሉ ብቃት ያለው አገባብ መጠቀምን ይመርጣሉ ፣ ሌሎች ደግሞ ዘዴ-ጥሪ አገባብ መጠቀምን ይመርጣሉ ፡፡
///
/// ```
/// use std::sync::Arc;
///
/// let arc = Arc::new(());
/// // ዘዴ-ጥሪ አገባብ
/// let arc2 = arc.clone();
/// // ሙሉ ብቃት ያለው አገባብ
/// let arc3 = Arc::clone(&arc);
/// ```
///
/// [`Weak<T>`][Weak] የውስጣዊው እሴቱ ቀድሞውኑ ወርዶ ሊሆን ስለሚችል ወደ `T` በራስ-ሰር ምዝገባ አያደርግም።
///
/// [`Rc<T>`]: crate::rc::Rc
/// [clone]: Clone::clone
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [atomic]: core::sync::atomic
/// [`Send`]: core::marker::Send
/// [`Sync`]: core::marker::Sync
/// [deref]: core::ops::Deref
/// [downgrade]: Arc::downgrade
/// [upgrade]: Weak::upgrade
/// [`RefCell<T>`]: core::cell::RefCell
/// [`std::sync`]: ../../std/sync/index.html
/// [`Arc::clone(&from)`]: Arc::clone
/// [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
///
/// # Examples
///
/// በክሮች መካከል የማይለዋወጥ መረጃን ማጋራት
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
// እኛ **እነዚህን ሙከራዎች እዚህ እንደማናከናውን** ልብ ይበሉ ፡፡
// የ windows ግንበኞች አንድ ክር ከዋናው ክር በላይ ሆኖ ከዚያ በተመሳሳይ ጊዜ ከወጣ (የሞት መዝጊያ የሆነ ነገር) ቢወጣ በጣም ደስተኛ አይደሉም ፣ ስለሆነም እነዚህን ሙከራዎች ባለማካሄድ ይህንን ሙሉ በሙሉ እንከላከላለን ፡፡
//
//
/// ```no_run
/// use std::sync::Arc;
/// use std::thread;
///
/// let five = Arc::new(5);
///
/// for _ in 0..10 {
///     let five = Arc::clone(&five);
///
///     thread::spawn(move || {
///         println!("{:?}", five);
///     });
/// }
/// ```
///
/// የሚለዋወጥ [`AtomicUsize`] ን መጋራት
///
/// [`AtomicUsize`]: core::sync::atomic::AtomicUsize
///
/// ```no_run
/// use std::sync::Arc;
/// use std::sync::atomic::{AtomicUsize, Ordering};
/// use std::thread;
///
/// let val = Arc::new(AtomicUsize::new(5));
///
/// for _ in 0..10 {
///     let val = Arc::clone(&val);
///
///     thread::spawn(move || {
///         let v = val.fetch_add(1, Ordering::SeqCst);
///         println!("{:?}", v);
///     });
/// }
/// ```
///
/// በአጠቃላይ ለማጣቀሻ ቆጠራ ተጨማሪ ምሳሌዎች [`rc` documentation][rc_examples] ን ይመልከቱ ፡፡
///
///
/// [rc_examples]: crate::rc#examples
#[cfg_attr(not(test), rustc_diagnostic_item = "Arc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Arc<T: ?Sized> {
    ptr: NonNull<ArcInner<T>>,
    phantom: PhantomData<ArcInner<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Arc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Arc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Arc<U>> for Arc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Arc<U>> for Arc<T> {}

impl<T: ?Sized> Arc<T> {
    fn from_inner(ptr: NonNull<ArcInner<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut ArcInner<T>) -> Self {
        unsafe { Self::from_inner(NonNull::new_unchecked(ptr)) }
    }
}

/// `Weak` የሚተዳደር ምደባን ያለመያዝ ማጣቀሻ የያዘ የ [`Arc`] ስሪት ነው።
/// ምደባው በ `Weak` ጠቋሚ ላይ [`upgrade`] ን በመደወል ተደራሽ ነው ፣ ይህም `[አማራጭ]]` <`[` Arc `]` ን ይመልሳል<T>>
///
/// የ `Weak` ማጣቀሻ በባለቤትነት አይቆጠርም ስለሆነም በምደባው ውስጥ የተከማቸውን እሴት ከመውደቅ አያግደውም ፣ እና `Weak` ራሱ እራሱ ስለአሁኑ ዋጋ ምንም ዋስትና አይሰጥም።
///
/// እንደዚሁ ጊዜ [`None`] [`upgrade`] መ መመለስ ይችላሉ.
/// ይሁን እንጂ ማስታወሻ አንድ `Weak` ማጣቀሻ መሆኑን *የሚያደርግ* deallocated እየተደረገ ከ ምደባ ራሱ (ድጋፍ ሱቅ) ይከላከላል.
///
/// የ‹XXXX›ጠቋሚ ውስጣዊ እሴቱ እንዳይወድቅ በመከልከል በ [`Arc`] ለሚተዳደር ምደባ ጊዜያዊ ማጣቀሻ ለማቆየት ጠቃሚ ነው ፡፡
/// የጋራ ባለቤትነት ማጣቀሻዎች [`Arc`] ን እንዲጣሉ በጭራሽ ስለማይፈቅድ በ [`Arc`] ጠቋሚዎች መካከል የክብ ማጣቀሻዎችን ለመከላከልም ጥቅም ላይ ይውላል ፡፡
/// ለምሳሌ ፣ አንድ ዛፍ ከወላጅ አንጓዎች እስከ ልጆች ጠንካራ የ [`Arc`] ጠቋሚዎች እና የ `Weak` ጠቋሚዎች ከልጆች ወደ ወላጆቻቸው ሊኖረው ይችላል ፡፡
///
/// የ `Weak` ጠቋሚ ለማግኘት የተለመደው መንገድ [`Arc::downgrade`] ን መደወል ነው ፡፡
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
#[stable(feature = "arc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // ይህ በኤሌክትሮኖች ውስጥ የዚህ ዓይነቱን መጠን ማመቻቸት ለማስቻል `NonNull` ነው ፣ ግን እሱ ትክክለኛ ጠቋሚ አይደለም።
    //
    // `Weak::new` ክምር ላይ ቦታ ለመመደብ እንዳይፈልግ ይህንን ወደ `usize::MAX` ያስቀምጠዋል ፡፡
    // RcBox ቢያንስ 2 አሰላለፍ ስላለው እውነተኛ ጠቋሚ በጭራሽ ሊኖረው የሚችል እሴት አይደለም።
    // ይህ ሊገኝ የሚችለው `T: Sized` በሚሆንበት ጊዜ ብቻ ነው;unsized `T` ፈጽሞ dangle.
    //
    ptr: NonNull<ArcInner<T>>,
}

#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Weak<T> {}
#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

// ይህ ሊተላለፍ ከሚችለው የውስጥ አይነቶች ጋር ደህንነቱ በተጠበቀ የ [into|from]_raw() ን ውስጥ ጣልቃ የሚገባውን የመስክ መልሶ ማዛወርን በተመለከተ ከ repr(C) እስከ future-ማረጋገጫ ነው።
//
//
#[repr(C)]
struct ArcInner<T: ?Sized> {
    strong: atomic::AtomicUsize,

    // usize::MAX እሴት ለጊዜው "locking" ደካማ ጠቋሚዎችን የማሻሻል ወይም ጠንካራዎችን ዝቅ የማድረግ ችሎታ እንደ ጊዜያዊ አገልግሎት ይሰጣል ፡፡ይህ በ `make_mut` እና `get_mut` ውስጥ ውድድሮችን ለማስወገድ ይጠቅማል።
    //
    //
    weak: atomic::AtomicUsize,

    data: T,
}

unsafe impl<T: ?Sized + Sync + Send> Send for ArcInner<T> {}
unsafe impl<T: ?Sized + Sync + Send> Sync for ArcInner<T> {}

impl<T> Arc<T> {
    /// አዲስ `Arc<T>` ን ይገነባል።
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(data: T) -> Arc<T> {
        // ደካማ ጠቋሚውን ቁጥር እንደ 1 ይጀምሩ ይህም በሁሉም ጠቋሚዎች (kinda) የተያዘው ደካማ ጠቋሚ ነው ፣ ለተጨማሪ መረጃ std/rc.rs ን ይመልከቱ
        //
        let x: Box<_> = box ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        };
        Self::from_inner(Box::leak(x).into())
    }

    /// ለራሱ ደካማ ማጣቀሻ በመጠቀም አዲስ `Arc<T>` ይገነባል።
    /// ይህ ተግባር ከመመለሱ በፊት ደካማውን ማጣቀሻ ለማሻሻል መሞከር የ `None` እሴት ያስከትላል።
    /// ሆኖም ደካማው ማመሳከሪያ በነፃነት የታሸገ እና በኋላ ላይ ጥቅም ላይ እንዲውል ሊከማች ይችላል ፡፡
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    ///
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo {
    ///     me: Weak<Foo>,
    /// }
    ///
    /// let foo = Arc::new_cyclic(|me| Foo {
    ///     me: me.clone(),
    /// });
    /// ```
    #[inline]
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Arc<T> {
        // ውስጡን በ‹XXXXXXXXX›ሁኔታ ውስጥ በአንድ ደካማ ማጣቀሻ ይገንቡ ፡፡
        //
        let uninit_ptr: NonNull<_> = Box::leak(box ArcInner {
            strong: atomic::AtomicUsize::new(0),
            weak: atomic::AtomicUsize::new(1),
            data: mem::MaybeUninit::<T>::uninit(),
        })
        .into();
        let init_ptr: NonNull<ArcInner<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // የደካሹን ጠቋሚ ባለቤትነት አለመተው አስፈላጊ ነው ፣ አለበለዚያ `data_fn` በሚመለስበት ጊዜ ማህደረ ትውስታው ነፃ ሊሆን ይችላል።
        // ባለቤትነትን በእውነቱ ማለፍ ከፈለግን ለራሳችን ተጨማሪ ደካማ ጠቋሚ መፍጠር እንችል ነበር ፣ ግን ይህ ምናልባት ደካማ የማጣቀሻ ቆጠራ ላይ ተጨማሪ ዝመናዎችን ያስከትላል ፣ ይህም ምናልባት አስፈላጊ ላይሆን ይችላል።
        //
        //
        //
        //
        let data = data_fn(&weak);

        // አሁን ውስጣዊውን እሴት በትክክል ማስጀመር እና ደካማ ማጣቀሻችንን ወደ ጠንካራ ማጣቀሻ መለወጥ እንችላለን ፡፡
        //
        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).data), data);

            // ከላይ ያለው ለመረጃ መስክ ይጻፉ ዜሮ ያልሆነ ጠንካራ ቆጠራን ለሚመለከቱ ማናቸውም ክሮች መታየት አለበት።
            // ስለዚህ በ `Weak::upgrade` ውስጥ ከ `compare_exchange_weak` ጋር ለማመሳሰል ቢያንስ "Release" ቅደም ተከተል ያስፈልገናል።
            //
            // "Acquire" ማዘዝ አያስፈልግም
            // የ `data_fn` ሊሆኑ የሚችሉ ባህሪያትን ስንመረምር ወደ የማይሻሻል `Weak` በማጣቀሻ ምን ማድረግ እንደሚችል ብቻ ማየት ያስፈልገናል-
            //
            // - ደካማውን የማጣቀሻ ቆጠራ በመጨመር `Weak` ን * + በአንድ ላይ ማድረግ ይችላል።
            // - ደካማዎቹን የማጣቀሻ ብዛት (ግን በጭራሽ ወደ ዜሮ) በመቀነስ እነዚያን ክሎኖች ሊጥል ይችላል።
            //
            // እነዚህ የጎንዮሽ ጉዳቶች በምንም መንገድ እኛን አይነኩም ፣ እና በደህና ኮድ ብቻ ሌሎች የጎንዮሽ ጉዳቶች ሊኖሩ አይችሉም ፡፡
            //
            //
            let prev_value = (*inner).strong.fetch_add(1, Release);
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
        }

        let strong = Arc::from_inner(init_ptr);

        // ጠንካራ ማጣቀሻዎች በጋራ የተጋራ ደካማ ማጣቀሻ በጋራ ሊኖራቸው ይገባል ፣ ስለሆነም ለድሮው ደካማ ማጣቀሻችን አጥፊውን አያሂዱ ፡፡
        //
        mem::forget(weak);
        strong
    }

    /// ባልታወቁ ይዘቶች አዲስ `Arc` ን ይገነባል።
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // የዘገየ ጅምር
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// ማህደረ ትውስታ በ `0` ባይት በሚሞላ በማያውቁት ይዘቶች አዲስ `Arc` ን ይገነባል።
    ///
    ///
    /// የዚህ ዘዴ ትክክለኛ እና የተሳሳተ አጠቃቀም ምሳሌዎች [`MaybeUninit::zeroed`][zeroed] ን ይመልከቱ።
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// አዲስ `Pin<Arc<T>>` ን ይገነባል።
    /// `T` `Unpin` ን ካልተተገበረ `data` በማስታወሻ ውስጥ ይሰካና መንቀሳቀስ አይችልም።
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(data: T) -> Pin<Arc<T>> {
        unsafe { Pin::new_unchecked(Arc::new(data)) }
    }

    /// መመደብ ካልተሳካ ስህተት በመመለስ አዲስ `Arc<T>` ን ይገነባል።
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::sync::Arc;
    ///
    /// let five = Arc::try_new(5)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new(data: T) -> Result<Arc<T>, AllocError> {
        // ደካማ ጠቋሚውን ቁጥር እንደ 1 ይጀምሩ ይህም በሁሉም ጠቋሚዎች (kinda) የተያዘው ደካማ ጠቋሚ ነው ፣ ለተጨማሪ መረጃ std/rc.rs ን ይመልከቱ
        //
        let x: Box<_> = Box::try_new(ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        })?;
        Ok(Self::from_inner(Box::leak(x).into()))
    }

    /// ምደባው ካልተሳካ ስህተት በመመለስ ባልታወቁ ይዘቶች አዲስ `Arc` ን ይገነባል።
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // የዘገየ ጅምር
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// አዲስ `Arc` ን ባልታወቁ ይዘቶች ይገነባል ፣ ማህደረ ትውስታ በ `0` ባይት ይሞላል ፣ ምደባው ካልተሳካ ስህተትን ይመልሳል።
    ///
    ///
    /// የዚህ ዘዴ ትክክለኛ እና የተሳሳተ አጠቃቀም ምሳሌዎች [`MaybeUninit::zeroed`][zeroed] ን ይመልከቱ።
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// `Arc` በትክክል አንድ ጠንካራ ማጣቀሻ ካለው ውስጣዊውን እሴት ይመልሳል።
    ///
    /// አለበለዚያ አንድ [`Err`] ከተላለፈው ተመሳሳይ `Arc` ጋር ተመልሷል።
    ///
    ///
    /// እጅግ በጣም ደካማ ማጣቀሻዎች ቢኖሩም ይህ ይሳካል።
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new(3);
    /// assert_eq!(Arc::try_unwrap(x), Ok(3));
    ///
    /// let x = Arc::new(4);
    /// let _y = Arc::clone(&x);
    /// assert_eq!(*Arc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if this.inner().strong.compare_exchange(1, 0, Relaxed, Relaxed).is_err() {
            return Err(this);
        }

        acquire!(this.inner().strong);

        unsafe {
            let elem = ptr::read(&this.ptr.as_ref().data);

            // በተዘዋዋሪ ጠንካራ-ደካማ ማጣቀሻውን ለማፅዳት ደካማ ጠቋሚ ያድርጉ
            let _weak = Weak { ptr: this.ptr };
            mem::forget(this);

            Ok(elem)
        }
    }
}

impl<T> Arc<[T]> {
    /// አዲስ በአቶሚክ በማጣቀሻ የተቆጠረ ቁርጥራጭ ባልታወቁ ይዘቶች ይገነባል ፡፡
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // የዘገየ ጅምር
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe { Arc::from_ptr(Arc::allocate_for_slice(len)) }
    }

    /// የማስታወሻ ማህደረ ትውስታ በ `0` ባይት በሚሞላ አዲስ በአቶሚክ በማጣቀሻ የተቆጠረ ቁርጥራጭ ባልታወቁ ይዘቶች ይገነባል።
    ///
    ///
    /// የዚህ ዘዴ ትክክለኛ እና የተሳሳተ አጠቃቀም ምሳሌዎች [`MaybeUninit::zeroed`][zeroed] ን ይመልከቱ።
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let values = Arc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut ArcInner<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Arc<mem::MaybeUninit<T>> {
    /// ወደ `Arc<T>` ይቀይራል።
    ///
    /// # Safety
    ///
    /// እንደ [`MaybeUninit::assume_init`] ሁሉ ፣ የውስጣዊ እሴቱ በእውነቱ በተጀመረው ሁኔታ ውስጥ መሆኑን ማረጋገጥ የደዋዩ ነው።
    ///
    /// ይዘቱ ገና ሙሉ በሙሉ ባልተጀመረበት ጊዜ ይህንን መጥራት ወዲያውኑ ያልተገለጸ ባህሪ ያስከትላል ፡፡
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // የዘገየ ጅምር
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<T> {
        Arc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Arc<[mem::MaybeUninit<T>]> {
    /// ወደ `Arc<[T]>` ይቀይራል።
    ///
    /// # Safety
    ///
    /// እንደ [`MaybeUninit::assume_init`] ሁሉ ፣ የውስጣዊ እሴቱ በእውነቱ በተጀመረው ሁኔታ ውስጥ መሆኑን ማረጋገጥ የደዋዩ ነው።
    ///
    /// ይዘቱ ገና ሙሉ በሙሉ ባልተጀመረበት ጊዜ ይህንን መጥራት ወዲያውኑ ያልተገለጸ ባህሪ ያስከትላል ፡፡
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // የዘገየ ጅምር
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<[T]> {
        unsafe { Arc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// የታሸገውን ጠቋሚ በመመለስ `Arc` ን ይወስዳል።
    ///
    /// ከማስታወሻ እንዳያመልጥ ጠቋሚው [`Arc::from_raw`] ን በመጠቀም ወደ `Arc` መመለስ አለበት።
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// ለመረጃው ጠቋሚ ጠቋሚ ያቀርባል።
    ///
    /// ቆጠራዎቹ በምንም መንገድ አይነኩም እና `Arc` አልተበላም።
    /// በ `Arc` ውስጥ ጠንካራ ቆጠራዎች እስካሉ ድረስ ጠቋሚው ልክ ነው።
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let y = Arc::clone(&x);
    /// let x_ptr = Arc::as_ptr(&x);
    /// assert_eq!(x_ptr, Arc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(this.ptr);

        // ደህንነት ይህ በ Deref::deref ወይም RcBoxPtr::inner ውስጥ ማለፍ አይችልም ምክንያቱም
        // ይህ የ‹XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXONXTI AH AH AH AH/ለማቆየት ይህ ያስፈልጋል
        // `get_mut` አርሲው በ `from_raw` በኩል ከተመለሰ በኋላ በአመልካቹ በኩል መጻፍ ይችላል።
        unsafe { ptr::addr_of_mut!((*ptr).data) }
    }

    /// ከጥሬ ጠቋሚ `Arc<T>` ን ይገነባል።
    ///
    /// ጥሬው ጠቋሚው ቀደም ሲል ወደ [`Arc<U>::into_raw`][into_raw] በመደወል መመለስ አለበት ፣ `U` ከ `T` ጋር ተመሳሳይ መጠን እና አሰላለፍ ሊኖረው ይገባል ፡፡
    /// `U` `T` ከሆነ ይህ ቀላል የማይባል እውነት ነው።
    /// `U` `T` አይደለም ነገር ግን ተመሳሳይ መጠን እና አሰላለፍ እንዳለው ከሆነ, ይህ የተለየ ዓይነት ማጣቀሻዎችን transmuting እንደ በመሠረቱ መሆኑን ልብ ይበሉ.
    /// በዚህ ጉዳይ ላይ ምን ገደቦች እንደሚተገበሩ ተጨማሪ መረጃ ለማግኘት [`mem::transmute`][transmute] ን ይመልከቱ ፡፡
    ///
    /// የ `from_raw` ተጠቃሚ አንድ የተወሰነ የ `T` እሴት አንዴ ብቻ እንደጣለ ማረጋገጥ አለበት።
    ///
    /// የተመለሰው `Arc<T>` በጭራሽ ባይገኝም ተገቢ ያልሆነ አጠቃቀም ወደ ማህደረ ትውስታ ደህንነት ሊያመራ ስለሚችል ይህ ተግባር ደህንነቱ የተጠበቀ ነው።
    ///
    /// [into_raw]: Arc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    ///
    /// unsafe {
    ///     // ፍሳሽን ለመከላከል ወደ `Arc` ተመልሰው ይለውጡ ፡፡
    ///     let x = Arc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // ወደ `Arc::from_raw(x_ptr)` የሚደረጉ ተጨማሪ ጥሪዎች በማስታወስ ላይ ደህንነቱ ያልተጠበቀ ይሆናሉ ፡፡
    /// }
    ///
    /// // `x` ከላይ ካለው ወሰን ሲወጣ ማህደረ ትውስታው ተለቅቋል ፣ ስለሆነም `x_ptr` አሁን ተንጠልጥሏል!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        unsafe {
            let offset = data_offset(ptr);

            // የመጀመሪያውን ArcInner ን ለማግኘት ማካካሻውን ይሽሩ።
            let arc_ptr = (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset));

            Self::from_ptr(arc_ptr)
        }
    }

    /// ለዚህ ምደባ አዲስ የ [`Weak`] ጠቋሚ ይፈጥራል።
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        // ከዚህ በታች ባለው CAS ውስጥ ያለውን እሴት ስለምንፈትሽ ይህ ዘና ማለት ጥሩ ነው።
        //
        let mut cur = this.inner().weak.load(Relaxed);

        loop {
            // ደካማው ቆጣሪ በአሁኑ ጊዜ "locked" መሆኑን ያረጋግጡ;ከሆነ ፣ ይሽከረክሩ
            if cur == usize::MAX {
                hint::spin_loop();
                cur = this.inner().weak.load(Relaxed);
                continue;
            }

            // NOTE: ይህ ኮድ በአሁኑ ጊዜ የመጥለቅለቅ እድልን ችላ ብሏል
            // ወደ usize::MAX;በአጠቃላይ አርሲ እና አርክ ከመጠን በላይ ፍሰትን ለመቋቋም መስተካከል አለባቸው ፡፡
            //

            // ከ Clone() በተለየ ፣ ከ `is_unique` ከሚመጣው ጽሑፍ ጋር ለማመሳሰል ይህ Acquire ንባብ መሆን ያስፈልገናል ፣ ስለዚህ ከዚያ ጽሑፍ በፊት ያሉ ክስተቶች ከዚህ ንባብ በፊት ይፈጸማሉ ፡፡
            //
            //
            match this.inner().weak.compare_exchange_weak(cur, cur + 1, Acquire, Relaxed) {
                Ok(_) => {
                    // የሚያንዣብብ ደካማ አለመፈጠራችንን ያረጋግጡ
                    debug_assert!(!is_dangling(this.ptr.as_ptr()));
                    return Weak { ptr: this.ptr };
                }
                Err(old) => cur = old,
            }
        }
    }

    /// ለዚህ ምደባ የ [`Weak`] አመልካቾችን ቁጥር ያገኛል።
    ///
    /// # Safety
    ///
    /// ይህ ዘዴ በራሱ ደህና ነው ፣ ግን በትክክል መጠቀሙ ተጨማሪ ጥንቃቄ ይጠይቃል።
    /// ሌላ ክር ይህን ዘዴ በመጥራት እና በውጤቱ ላይ እርምጃ በመውሰድ መካከል ያለውን ጨምሮ የደካማውን ቁጥር በማንኛውም ጊዜ ሊለውጠው ይችላል።
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _weak_five = Arc::downgrade(&five);
    ///
    /// // በክር መካከል `Arc` ወይም `Weak` ስላላካፈልን ይህ ማረጋገጫ ቆራጥ ነው ፡፡
    /////
    /// assert_eq!(1, Arc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        let cnt = this.inner().weak.load(SeqCst);
        // ደካማው ቆጠራ በአሁኑ ጊዜ ከተቆለፈ መቆለፊያውን ከመውሰዱ በፊት የቆጠራው ዋጋ 0 ነበር።
        //
        if cnt == usize::MAX { 0 } else { cnt - 1 }
    }

    /// ለዚህ ምደባ ጠንካራ የ (`Arc`) ጠቋሚዎችን ቁጥር ያገኛል።
    ///
    /// # Safety
    ///
    /// ይህ ዘዴ በራሱ ደህና ነው ፣ ግን በትክክል መጠቀሙ ተጨማሪ ጥንቃቄ ይጠይቃል።
    /// ሌላው ክር ይህንን ዘዴ በመደወል እና ውጤት ላይ እርምጃ መካከል የሚችል ጨምሮ, በማንኛውም ጊዜ ወደ ጠንካራ ቆጠራ መቀየር ይችላሉ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _also_five = Arc::clone(&five);
    ///
    /// // `Arc` ን በክሮች መካከል ስላላካፈልን ይህ ማረጋገጫ ቆራጥ ነው።
    /////
    /// assert_eq!(2, Arc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong.load(SeqCst)
    }

    /// ከቀረበው ጠቋሚ ጋር በተዛመደ በ `Arc<T>` ላይ ጠንካራ የማጣቀሻ ቆጠራን በአንድ ይጨምራል።
    ///
    /// # Safety
    ///
    /// ጠቋሚው በ `Arc::into_raw` በኩል የተገኘ መሆን አለበት ፣ እና ተጓዳኝ የ `Arc` ምሳሌ ትክክለኛ መሆን አለበት (ማለትም
    /// ለዚህ ዘዴ ቆይታ ጠንካራው ቁጥር ቢያንስ 1 መሆን አለበት ፡፡
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // `Arc` ን በክሮች መካከል ስላላካፈልን ይህ ማረጋገጫ ቆራጥ ነው።
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn increment_strong_count(ptr: *const T) {
        // አርክን ያቆዩ ፣ ነገር ግን በማኒውድሮፕ በመጠቅለል መልሶ ማግኘትን አይንኩ
        let arc = unsafe { mem::ManuallyDrop::new(Arc::<T>::from_raw(ptr)) };
        // አሁን እንደገና መጨመርን ይጨምሩ ፣ ግን አዲስ ሂሳብን አይጣሉ
        let _arc_clone: mem::ManuallyDrop<_> = arc.clone();
    }

    /// ከቀረበው ጠቋሚ ጋር በተዛመደ በ `Arc<T>` ላይ ጠንካራ የማጣቀሻ ቆጠራው ይቀንሳል።
    ///
    /// # Safety
    ///
    /// ጠቋሚው በ `Arc::into_raw` በኩል የተገኘ መሆን አለበት ፣ እና ተጓዳኝ የ `Arc` ምሳሌ ትክክለኛ መሆን አለበት (ማለትም
    /// ይህንን ዘዴ ሲጠሩ ጠንካራው ቁጥር ቢያንስ 1 መሆን አለበት ፡፡
    /// ይህ ዘዴ የመጨረሻውን `Arc` እና የመጠባበቂያ ክምችት ለመልቀቅ ሊያገለግል ይችላል ፣ ግን **የመጨረሻው `Arc` ከተለቀቀ በኋላ** መጠራት የለበትም።
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // `Arc` ን በክሮች መካከል ባለማካፈል እነዚያ ማረጋገጫዎች ቆራጥ ናቸው።
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    ///     Arc::decrement_strong_count(ptr);
    ///     assert_eq!(1, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn decrement_strong_count(ptr: *const T) {
        unsafe { mem::drop(Arc::from_raw(ptr)) };
    }

    #[inline]
    fn inner(&self) -> &ArcInner<T> {
        // ይህ ቅስት በህይወት እያለ እኛ ውስጣዊ ጠቋሚ ትክክለኛ መሆኑን ዋስትና ምክንያቱም ይህ unsafety እሺ ነው.
        // በተጨማሪም ፣ የ‹XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX2 በላይ መሆኑን እናውቃለን ምክንያቱም እኛ ለእነዚህ ይዘቶች የማይለዋወጥ ጠቋሚ ብድር ብንሰጥ ፡፡
        //
        //
        //
        unsafe { self.ptr.as_ref() }
    }

    // የ `drop` ያልተመዘገበ ክፍል።
    #[inline(never)]
    unsafe fn drop_slow(&mut self) {
        // ምንም እንኳን እኛ የሳጥን አመዳደብ እራሱ ላይለቀቅ ባንችልም ፣ በዚህ ጊዜ ውሂቡን ያጥፉ (አሁንም ቢሆን ጠቋሚ ጠቋሚዎች ሊኖሩ ይችላሉ) ፡፡
        //
        unsafe { ptr::drop_in_place(Self::get_mut_unchecked(self)) };

        // በሁሉም ጠንካራ ማመሳከሪያዎች በጋራ የተያዘውን ደካማ ማጣሪያን ጣል ያድርጉ
        drop(Weak { ptr: self.ptr });
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// ይመለሳል `true` ከሆነ ([`ptr::eq`] አንድ ጅማት ተመሳሳይ ውስጥ) ተመሳሳይ ምደባ ወደ ሁለት `Arc`s ነጥብ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let same_five = Arc::clone(&five);
    /// let other_five = Arc::new(5);
    ///
    /// assert!(Arc::ptr_eq(&five, &same_five));
    /// assert!(!Arc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: ?Sized> Arc<T> {
    /// እሴቱ የቀረበበትን አቀማመጥ ላለው ምናልባት ለማይለካ ውስጣዊ እሴት በቂ `ArcInner<T>` ን ይመድባል።
    ///
    /// `mem_to_arcinner` ተግባር ከመረጃ ጠቋሚው ጋር ተጠርቶ ለ‹XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX አንድ ሙሉ አንድ የስብ መጠን ሊኖረው ይችላል ፡፡
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> *mut ArcInner<T> {
        // የተሰጠውን የእሴት አቀማመጥ በመጠቀም አቀማመጥን ያስሉ።
        // ከዚህ በፊት አቀማመጥ `&*(ptr as* const ArcInner<T>)` በሚለው አገላለጽ ላይ ይሰላል ፣ ግን ይህ የተሳሳተ የማጣቀሻ (#54908 ን ይመልከቱ) ፈጠረ።
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Arc::try_allocate_for_layout(value_layout, allocate, mem_to_arcinner)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// ምጣኔው ካልተስተካከለ ስህተትን በመመለስ እሴቱ የቀረበው አቀማመጥ ላለው ምናልባትም ለማይለካ ውስጣዊ እሴት `ArcInner<T>` ን በበቂ ቦታ ይመድባል።
    ///
    ///
    /// `mem_to_arcinner` ተግባር ከመረጃ ጠቋሚው ጋር ተጠርቶ ለ‹XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX አንድ ሙሉ አንድ የስብ መጠን ሊኖረው ይችላል ፡፡
    ///
    ///
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> Result<*mut ArcInner<T>, AllocError> {
        // የተሰጠውን የእሴት አቀማመጥ በመጠቀም አቀማመጥን ያስሉ።
        // ከዚህ በፊት አቀማመጥ `&*(ptr as* const ArcInner<T>)` በሚለው አገላለጽ ላይ ይሰላል ፣ ግን ይህ የተሳሳተ የማጣቀሻ (#54908 ን ይመልከቱ) ፈጠረ።
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();

        let ptr = allocate(layout)?;

        // የ ArcInner ን ያስጀምሩ
        let inner = mem_to_arcinner(ptr.as_non_null_ptr().as_ptr());
        debug_assert_eq!(unsafe { Layout::for_value(&*inner) }, layout);

        unsafe {
            ptr::write(&mut (*inner).strong, atomic::AtomicUsize::new(1));
            ptr::write(&mut (*inner).weak, atomic::AtomicUsize::new(1));
        }

        Ok(inner)
    }

    /// የሚያከፋፍለውን አንድ unsized ውስጣዊ እሴት የሚሆን በቂ ቦታ ጋር አንድ `ArcInner<T>`.
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut ArcInner<T> {
        // የተሰጠው ዋጋ በመጠቀም `ArcInner<T>` ለ ለመመደብ.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut ArcInner<T>).set_ptr_value(mem) as *mut ArcInner<T>,
            )
        }
    }

    fn from_box(v: Box<T>) -> Arc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // ዋጋን እንደ ባይት ይቅዱ
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).data as *mut _ as *mut u8,
                value_size,
            );

            // ይዘቱን ሳይጥሉ ምደባውን ነፃ ያድርጉት
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Arc<[T]> {
    /// ከተሰጠው ርዝመት ጋር `ArcInner<[T]>` ን ይመድባል።
    unsafe fn allocate_for_slice(len: usize) -> *mut ArcInner<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut ArcInner<[T]>,
            )
        }
    }

    /// ገልብጥ አዲስ የተመደበ ቅስት ወደ ቁራጭ አባሎችን <\[T\]>
    ///
    /// ደህንነቱ ያልተጠበቀ ስለሆነ ደዋዩ ወይ ባለቤትነቱን መውሰድ ወይም `T: Copy` ን ማሰር አለበት።
    unsafe fn copy_from_slice(v: &[T]) -> Arc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());

            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).data as *mut [T] as *mut T, v.len());

            Self::from_ptr(ptr)
        }
    }

    /// በተወሰነ መጠን ከሚታወቅ ተደጋጋሚ አንድ `Arc<[T]>` ን ይገነባል።
    ///
    /// መጠኑ የተሳሳተ መሆን ያለበት ባህሪ አልተገለጸም።
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Arc<[T]> {
        // የቲ ኤለመንቶችን በሚደጉበት ጊዜ የ Panic ጥበቃ ፡፡
        // panic በሚሆንበት ጊዜ በአዲሱ ArcInner ውስጥ የተፃፉ አካላት ይጣላሉ ፣ ከዚያ ማህደረ ትውስታ ይለቀቃል።
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // ጠቋሚ ወደ መጀመሪያ አካል
            let elems = &mut (*ptr).data as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // ሁሉም ግልፅ ነው ፡፡አዲሱን ArcInner ን ነፃ እንዳያደርግ ጥበቃውን ይርሱ ፡፡
            mem::forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// ስፔሻላይዜሽን trait ለ `From<&[T]>` ያገለገለ ፡፡
trait ArcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Arc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Arc<T> {
    /// የ `Arc` ጠቋሚ አንድ ክምር ያደርገዋል።
    ///
    /// ይህ ጠንካራ ማጣቀሻ ቆጠራ እየጨመረ, ተመሳሳይ ድልድል ወደ ሌላ ጠቋሚ ይፈጥራል.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let _ = Arc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Arc<T> {
        // የመጀመሪያውን ማጣቀሻ ማወቅ ሌሎች ክሮች በስህተት እቃውን ከመሰረዝ የሚያግድ ስለሆነ ዘና ያለ ቅደም ተከተልን መጠቀም እዚህ ጥሩ ነው።
        //
        // በ‹XXXX›እንደተብራራው ፣ የማጣቀሻ ቆጣሪውን መጨመር ሁል ጊዜ በማስታወስ_ድርድር_ተስተካከለ ሊከናወን ይችላል-ወደ አንድ ነገር አዲስ ማጣቀሻዎች ሊኖሩ የሚችሉት አሁን ካለው ማጣቀሻ ብቻ ነው ፣ እናም አንድን ነባር ማጣቀሻ ከአንድ ክር ወደ ሌላው ማስተላለፍ ቀድሞውኑ የሚያስፈልገውን ማመሳሰል ማቅረብ አለበት ፡፡
        //
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        //
        //
        //
        //
        //
        let old_size = self.inner().strong.fetch_add(1, Relaxed);

        // ሆኖም አንድ ሰው‹ሜም: : አርሴክስን›የሚረሳ ከሆነ ግዙፍ መልሶ ማግኛዎችን መጠበቅ አለብን ፡፡
        // ይህንን ካላደረግነው ቆጠራው ሊፈስ ይችላል እና ተጠቃሚዎች-በኋላ ነፃ ይጠቀማሉ።
        // በአንድ ጊዜ የማጣቀሻ ቆጠራን የሚጨምሩ የ ~2 ቢሊዮን ክሮች የሉም ብለን በማሰብ ወደ `isize::MAX` በዘረኝነት እንጠግባለን ፡፡
        //
        // ይህ branch በማንኛውም ተጨባጭ ፕሮግራም ውስጥ በጭራሽ አይወሰድም ፡፡
        //
        // እኛ እንወርዳለን ምክንያቱም እንዲህ ያለው ፕሮግራም እጅግ በሚያስደንቅ ሁኔታ ብልሹ ነው ፣ እና እሱን መደገፍ ግድ የለንም።
        //
        //
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Arc<T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        &self.inner().data
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Arc<T> {}

impl<T: Clone> Arc<T> {
    /// ወደ ተሰጠው `Arc` ውስጥ የሚለዋወጥ ማጣቀሻ ያደርገዋል።
    ///
    /// ለተመሳሳይ ምደባ ሌሎች የ `Arc` ወይም [`Weak`] አመልካቾች ካሉ ከዚያ `make_mut` አዲስ ምደባን ይፈጥራል እና ልዩ ባለቤትነትን ለማረጋገጥ በውስጣዊው እሴት ላይ [`clone`][clone] ን ይጠራል ፡፡
    /// ይህ ደግሞ ለቅጂ-ላይ-ጻፍ በመባል ይታወቃል.
    ///
    /// ይህ ማንኛውም የቀሩትን የ `Weak` ጠቋሚዎችን ከሚያለያይ የ [`Rc::make_mut`] ባህሪ እንደሚለይ ልብ ይበሉ ፡፡
    ///
    /// በተጨማሪም ክሎንግ ከማድረግ ይልቅ የሚሳነው [`get_mut`][get_mut] ን ይመልከቱ።
    ///
    /// [clone]: Clone::clone
    /// [get_mut]: Arc::get_mut
    /// [`Rc::make_mut`]: super::rc::Rc::make_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut data = Arc::new(5);
    ///
    /// *Arc::make_mut(&mut data) += 1;         // ማንኛውንም ነገር በአንድ ላይ አያደርግም
    /// let mut other_data = Arc::clone(&data); // ውስጣዊ ውሂብን በአንድ ላይ አያጣምርም
    /// *Arc::make_mut(&mut data) += 1;         // Clones ውስጣዊ ውሂብ
    /// *Arc::make_mut(&mut data) += 1;         // ማንኛውንም ነገር በአንድ ላይ አያደርግም
    /// *Arc::make_mut(&mut other_data) *= 2;   // ማንኛውንም ነገር በአንድ ላይ አያደርግም
    ///
    /// // አሁን `data` እና `other_data` ወደ ተለያዩ ምደባዎች ይጠቁማሉ ፡፡
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        // ሁለቱንም ጠንካራ ማጣቀሻ እና ደካማ ማጣቀሻ እንደያዝን ልብ ይበሉ ፡፡
        // ስለሆነም ጠንካራ ማመሳከሪያችንን መልቀቅ በራሱ የማስታወስ ችሎታውን እንዲከፋፈሉ አያደርግም።
        //
        // ከመልቀቁ በፊት (ማለትም ፣ ቅነሳዎች) ወደ `strong` ከመፃፉ በፊት የሚከሰቱ ማንኛውንም የ `weak` ጽሁፎችን ማየታችንን ለማረጋገጥ Acquire ን ይጠቀሙ ፡፡
        // እኛ ደካማ ቆጠራ ስለምንይዝ ፣ አርክ ኢንነር ራሱ ሊተላለፍ የሚችልበት ዕድል አይኖርም።
        //
        //
        //
        if this.inner().strong.compare_exchange(1, 0, Acquire, Relaxed).is_err() {
            // ሌላ ጠንካራ ጠቋሚ አለ ፣ ስለሆነም አንድ ላይ መሆን አለብን።
            // የታሸገ እሴቱን በቀጥታ ለመጻፍ ለማስታወስ ማህደረ ትውስታን ቀድመው ይመድቡ።
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = arc.assume_init();
            }
        } else if this.inner().weak.load(Relaxed) != 1 {
            // ዘና ለማለት ከላይ በተጠቀሰው ውስጥ በቂ ነው ምክንያቱም ይህ በመሠረቱ ማመቻቸት ነው-እኛ ሁልጊዜ ደካማ ጠቋሚዎችን በመጣል ውድድሮችን እናደርጋለን ፡፡
            // በጣም የከፋ ጉዳይ ፣ ሳያስፈልግ አዲስ አርክ ተመድበናል ፡፡
            //

            // የመጨረሻውን ጠንካራ ሪፈርስ አስወግደናል ፣ ግን ቀሪዎቹ ተጨማሪ ደካማ መመለሻዎች አሉ።
            // ይዘቱን ወደ አዲስ አርክ እንሸጋገራለን ፣ እና ሌሎች ደካማ ሪፈሮችን ዋጋ እናጣለን ፡፡
            //

            // የደካማ ቁጥሩ በጠንካራ ማጣቀሻ በክር ብቻ ሊቆለፍ ስለሚችል የ `weak` ን ንባብ usize::MAX (ማለትም ተቆል)ል) መስጠት የማይቻል መሆኑን ልብ ይበሉ።
            //
            //

            // አስፈላጊ የሆነውን የ ArcInner ን ለማፅዳት እንዲችል የራሳችንን ደካማ ጠቋሚ ጠቋሚ ሰው ያድርጉ ፡፡
            //
            let _weak = Weak { ptr: this.ptr };

            // ውሂቡን ብቻ መስረቅ ይችላል ፣ የቀረው Weaks ብቻ ነው
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);
                ptr::write(this, arc.assume_init());
            }
        } else {
            // እኛ የየትኛውም ዓይነት ብቸኛ ማጣቀሻ ነበርን;ጠንካራ ጥንካሬን እንደገና ለመቁጠር ይደግፉ።
            //
            this.inner().strong.store(1, Release);
        }

        // እንደ `get_mut()` ሁሉ ደህንነቱ የተጠበቀ ነው ምክንያቱም ማጣቀሻችን ለመጀመር ልዩ ስለ ሆነ ወይም ይዘቱን ከከሸፈ በኋላ አንድ ስለሆነ ነው ፡፡
        //
        unsafe { Self::get_mut_unchecked(this) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// ለተመሳሳይ ምደባ ሌሎች የ `Arc` ወይም [`Weak`] አመልካቾች ከሌሉ የሚለዋወጥ ማጣቀሻውን ወደ ተሰጠው `Arc` ይመልሳል።
    ///
    ///
    /// በሌላ መንገድ [`None`] ን ይመልሳል ፣ ምክንያቱም የተጋራ እሴት መለወጥ ጥሩ ስላልሆነ።
    ///
    /// ሌሎች ዘዴውን አሉ ጊዜ ውስጣዊ ዋጋ [`clone`][clone], ይህም ደግሞ [`make_mut`][make_mut] ተመልከት.
    ///
    /// [make_mut]: Arc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(3);
    /// *Arc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Arc::clone(&x);
    /// assert!(Arc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if this.is_unique() {
            // ይህ ደህንነቱ የተጠበቀ ነው ምክንያቱም ጠቋሚው የተመለሰው *ብቻ* ጠቋሚው ወደ ቲ.
            // የእኛ ማጣቀሻ ቆጠራ በዚህ ነጥብ ላይ 1 እንዲሆኑ ዋስትና, እና እኛ ውስጣዊ ውሂብ ወደ ብቻ በተቻለ ማጣቀሻ በመመለስ ላይ ነን ስለዚህ የ ቅስት ራሱ `mut` መሆን ያስፈልጋል.
            //
            //
            //
            unsafe { Some(Arc::get_mut_unchecked(this)) }
        } else {
            None
        }
    }

    /// ያለ ምንም ፍተሻ የሚለዋወጥ ማጣቀሻውን ወደ ተሰጠው `Arc` ይመልሳል።
    ///
    /// እንዲሁም ደህንነቱ የተጠበቀ እና ተገቢ ቼኮችን የሚያደርግ [`get_mut`] ን ይመልከቱ።
    ///
    /// [`get_mut`]: Arc::get_mut
    ///
    /// # Safety
    ///
    /// ለተመደበው ተመሳሳይ ማናቸውም ሌላ የ `Arc` ወይም [`Weak`] ጠቋሚዎች ለተመለሰው ብድር ጊዜ መሰረዝ የለባቸውም ፡፡
    ///
    /// እንደዚህ ዓይነቶቹ ጠቋሚዎች ከሌሉ ይህ ሁኔታ ቀላል ነው ፣ ለምሳሌ ወዲያውኑ ከ‹XXXXX›በኋላ ፡፡
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(String::new());
    /// unsafe {
    ///     Arc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // የ "count" መስኮችን የሚሸፍን ማጣቀሻ *ላለመፍጠር* እንጠነቀቃለን ፣ ምክንያቱም ይህ የማጣቀሻ ቆጠራዎችን በአንድ ጊዜ ማግኘት (ለምሳሌ ፣)
        // በ `Weak`).
        unsafe { &mut (*this.ptr.as_ptr()).data }
    }

    /// ለታችኛው መረጃ ይህ ልዩ ማጣቀሻ (ደካማ ሪፍዎችን ጨምሮ) እንደሆነ ይወስኑ።
    ///
    ///
    /// ይህ ደካማውን የመጥሪያ ቆጠራ መቆለፍን እንደሚፈልግ ልብ ይበሉ።
    fn is_unique(&mut self) -> bool {
        // ብቸኛው ደካማ ጠቋሚ ባለቤት ከሆንን ደካማውን የጠቋሚ ቆጠራን ይቆልፉ።
        //
        // የ `weak` ቆጠራ ከመቀነሱ በፊት ከማንኛውም ከማንኛውም ወደ `strong` (በተለይም በ `Weak::upgrade`) ከመፃፉ በፊት የግንኙነት መለያ ከዚህ በፊት ያለውን ግንኙነት ያረጋግጣል (ልቀትን ከሚጠቀም `Weak::drop` በኩል) ፡፡
        // የተሻሻለው ደካማ ሪፍ በጭራሽ ካልተወገደ ፣ እዚህ ያለው CAS ይከሽፋል ፣ ስለሆነም ማመሳሰልን አንመለከትም ፡፡
        //
        //
        //
        if self.inner().weak.compare_exchange(1, usize::MAX, Acquire, Relaxed).is_ok() {
            // ይህ በ `drop` ውስጥ ካለው የ `strong` ቆጣሪ መቀነስ ጋር ለማመሳሰል ይህ `Acquire` መሆን አለበት-ማንኛውም ካለፈው ማጣቀሻ ውጭ ሲወድቅ የሚከሰት ብቸኛ መዳረሻ።
            //
            //
            let unique = self.inner().strong.load(Acquire) == 1;

            // እዚህ የተለቀቀው ልቀት በ `downgrade` ውስጥ ካለው ንባብ ጋር ይመሳሰላል ፣ ከዚህ በላይ ያለው የ `strong` ንባብ ከጽሑፉ በኋላ እንዳይከሰት ውጤታማ ያደርገዋል ፡፡
            //
            //
            self.inner().weak.store(1, Release); // መቆለፊያውን መልቀቅ
            unique
        } else {
            false
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Arc<T> {
    /// `Arc` ን ይጥላል።
    ///
    /// ይህ ጠንካራ የማጣቀሻ ቆጠራውን ይቀንሰዋል።
    /// ጠንካራ የማጣቀሻ ቆጠራ ዜሮ ከደረሰ ሌሎች ብቸኛ ማጣቀሻዎች (ካለ) [`Weak`] ናቸው ፣ ስለሆነም እኛ ውስጣዊ እሴቱን `drop` እናደርጋለን።
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Arc::new(Foo);
    /// let foo2 = Arc::clone(&foo);
    ///
    /// drop(foo);    // ምንም ነገር አያተምም
    /// drop(foo2);   // "dropped!" ን ያትማል
    /// ```
    #[inline]
    fn drop(&mut self) {
        // `fetch_sub` ቀድሞውኑ አቶሚክ ስለሆነ ፣ ነገሩን ካልሰረዝን በስተቀር ከሌሎች ክሮች ጋር ማመሳሰል አያስፈልገንም።
        // ይህ ተመሳሳይ ሎጂክ ወደ `weak` ቆጠራ ወደ `fetch_sub` ከታች ያለውን ይመለከታል.
        //
        if self.inner().strong.fetch_sub(1, Release) != 1 {
            return;
        }

        // የመረጃ አጠቃቀሙን እንደገና እንዳያስስተላልፉ እና የመረጃውን መሰረዝ ለመከላከል ይህ አጥር ያስፈልጋል ፡፡
        // `Release` የሚል ምልክት ስላለው የማጣቀሻ ቁጥሩ መቀነስ ከዚህ የ `Acquire` አጥር ጋር ይመሳሰላል ፡፡
        // ይህ ማለት መረጃው ከመጥፋቱ በፊት የሚከሰት ከዚህ አጥር በፊት የሚሆነውን የማጣቀሻ ቆጠራ ከመቀነሱ በፊት ነው ማለት ነው ፡፡
        //
        // በ [Boost documentation][1] እንደተገለጸው ፣
        //
        // > የነገሩን ማንኛውንም ተደራሽነት በአንዱ ማስፈፀም አስፈላጊ ነው
        // > ከመሰረዝዎ በፊት * እንዲከሰት ክር (በነባር ማጣቀሻ በኩል)
        // > እቃውን በሌላ ክር ውስጥ።ይህ በ "release" ተገኝቷል
        // > ማመሳከሪያን ከጣለ በኋላ ክዋኔው (ለእቃው ማንኛውም መዳረሻ)
        // > በዚህ ማጣቀሻ ከዚህ በፊት በግልጽ መከሰት አለበት) ፣ እና አንድ
        // > "acquire" ዕቃውን ከመሰረዝዎ በፊት ክዋኔ።
        //
        // በተለይም ፣ የአንድ አርክ ይዘቶች ብዙውን ጊዜ የማይለወጡ ቢሆኑም ፣ እንደ‹ሙተክስ›ላሉት ነገሮች ውስጣዊ ጽሁፎችን ማግኘት ይቻላል ፡፡<T>.
        // Mutex በሚሰረዝበት ጊዜ የተገኘ ባለመሆኑ በክሩ ቢ ውስጥ ለሚሮጥ አጥፊ የሚታየውን በክር ውስጥ እንዲጽፉ ለማድረግ በማመሳሰል አመክንዮው ላይ መተማመን አንችልም ፡፡
        //
        //
        // በተጨማሪም እዚህ ማግኘት አጥር ምናልባት በከፍተኛ-ተከራከሩ ሁኔታዎች ውስጥ አፈጻጸምን ለማሻሻል የሚችል አንድ ለማግኘት ሸክም, ይተካል እንደሚችል ልብ ይበሉ.[2] ን ይመልከቱ።
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        // [2]: (https://github.com/rust-lang/rust/pull/41714)
        //
        //
        //
        //
        //
        //
        //
        acquire!(self.inner().strong);

        unsafe {
            self.drop_slow();
        }
    }
}

impl Arc<dyn Any + Send + Sync> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// `Arc<dyn Any + Send + Sync>` ን ወደ ኮንክሪት ዓይነት ዝቅ ለማድረግ መሞከር።
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::sync::Arc;
    ///
    /// fn print_if_string(value: Arc<dyn Any + Send + Sync>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Arc::new(my_string));
    /// print_if_string(Arc::new(0i8));
    /// ```
    pub fn downcast<T>(self) -> Result<Arc<T>, Self>
    where
        T: Any + Send + Sync + 'static,
    {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<ArcInner<T>>();
            mem::forget(self);
            Ok(Arc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T> Weak<T> {
    /// ምንም ማህደረ ትውስታ ሳይመድብ አዲስ `Weak<T>` ን ይገነባል።
    /// በመመለሻ እሴት ላይ [`upgrade`] ን መደወል ሁልጊዜ [`None`] ን ይሰጣል።
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut ArcInner<T>).expect("MAX is not 0") }
    }
}

/// አጋዥ የውሂብ መስክ በተመለከተ ማንኛውም ከተናገሯቸው ሳያደርጉ ማጣቀሻ ቆጠራዎች መድረስ ለመፍቀድ ይተይቡ.
///
struct WeakInner<'a> {
    weak: &'a atomic::AtomicUsize,
    strong: &'a atomic::AtomicUsize,
}

impl<T: ?Sized> Weak<T> {
    /// በዚህ ጠቋሚ XXXXXXXXXXXXXXXXXXXXXXXX ላይ ወደ አንድ ነገር ጠቋሚ ጠቋሚ ይመልሳል.
    ///
    /// ጠቋሚው የሚሰራው አንዳንድ ጠንካራ ማጣቀሻዎች ካሉ ብቻ ነው ፡፡
    /// ጠቋሚው ተንጠልጥሎ ፣ ያልተስተካከለ ወይም ሌላው ቀርቶ [`null`] ሊሆን ይችላል።
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::ptr;
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// // ሁለቱም ወደ አንድ ነገር ይጠቁማሉ
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // እዚህ ያለው ጠንካራ ሕያው ያደርገዋል ፣ ስለዚህ አሁንም እቃውን መድረስ እንችላለን።
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // ግን ከዚያ በኋላ አይሆንም ፡፡
    /// // weak.as_ptr() ን ማድረግ እንችላለን ፣ ግን ጠቋሚውን መድረስ ወደ ያልተገለጸ ባህሪ ይመራናል።
    /// // assert_eq! ("ሰላም", ደህንነቱ ያልተጠበቀ {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // የ ጠቋሚ ተንጠልጥለው ከሆነ, እኛ በቀጥታ ዘብ መመለስ.
            // የደመወዝ ጭነት ቢያንስ እንደ ArcInner (usize) የተስተካከለ ስለሆነ ይህ ትክክለኛ የክፍያ ጭነት አድራሻ ሊሆን አይችልም።
            ptr as *const T
        } else {
            // ደህንነት-አደገኛ ነገር ሐሰተኛ ከሆነ ፣ ከዚያ ጠቋሚው ሊቀለበስ ይችላል።
            // ያለው የክፍያ በዚህ ነጥብ ላይ ሊያልፍ ይችላል, እና provenance ለመጠበቅ; ስለዚህ ጥሬ የጠቋሚ መጠቀሚያ ይጠቀማሉ.
            //
            unsafe { ptr::addr_of_mut!((*ptr).data) }
        }
    }

    /// የ `Weak<T>` እና ጥሬ ጠቋሚ ወደ በየተራ ይህን ተቆጣጥሮታል.
    ///
    /// አሁንም (ደካማ ቆጠራ በዚህ ክወና የሚቀየሩ አይደለም) አንድ ደካማ ማጣቀሻ ባለቤትነት ጠብቆ ሳለ ይህ, አንድ ጥሬ ጠቋሚ ወደ ደካማ ጠቋሚ ትለውጣለች.
    /// ይህ [`from_raw`] ጋር `Weak<T>` ወደ ኋላ ተመለሱ ይቻላል.
    ///
    /// [`as_ptr`] ጋር እንደ ጠቋሚ ያለውን ግብ መድረስ ተመሳሳይ ገደቦች ተፈጻሚ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Arc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Arc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// ቀደም `Weak<T>` ወደ [`into_raw`] ጀርባ የተፈጠረ አንድ ጥሬ ጠቋሚ ይለውጣል.
    ///
    /// ይህ በተጠበቀ (ከጊዜ በኋላ [`upgrade`] በመደወል) ጠንካራ ማጣቀሻ ለማግኘት ወይም `Weak<T>` በመጣል በማድረግ ደካማ ቆጠራ deallocate ጥቅም ላይ ሊውል ይችላል.
    ///
    /// (እነዚህ ሳይሆን የራሱን ነገር ማድረግ እንደ [`new`] የተፈጠሩ ዘዴውን በስተቀር ጋር; ዘዴ አሁንም በእነርሱ ላይ ይሰራል) አንድ ደካማ ማጣቀሻ ባለቤትነት ይወስዳል.
    ///
    /// # Safety
    ///
    /// የ ጠቋሚ [`into_raw`] የመነጨው መሆን አለበት አሁንም በውስጡ እምቅ ደካማ ማጣቀሻ ባለቤት መሆን አለበት.
    ///
    /// ይህንን በሚጠራበት ጊዜ ለጠንካራ ቆጠራ 0 እንዲሆን ይፈቀዳል ፡፡
    /// ሆኖም ፣ ይህ በአሁኑ ጊዜ እንደ ጥሬ ጠቋሚ የተወከለውን አንድ ደካማ ማጣቀሻ በባለቤትነት ይወስዳል (የደካማው ቆጠራ በዚህ ክዋኔ አልተሻሻለም) ስለሆነም ከቀደመው ጥሪ ጋር ወደ [`into_raw`] መጣመር አለበት ፡፡
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    ///
    /// let raw_1 = Arc::downgrade(&strong).into_raw();
    /// let raw_2 = Arc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Arc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Arc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // የመጨረሻው ደካማ ቆጠራ ማሽቆልቆል።
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`new`]: Weak::new
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`forget`]: std::mem::forget
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // የግብዓት ጠቋሚው እንዴት እንደተገኘ አውድ ለማግኘት Weak::as_ptr ን ይመልከቱ ፡፡

        let ptr = if is_dangling(ptr as *mut T) {
            // ይህ ተንጠልጥለው ደካማ ነው.
            ptr as *mut ArcInner<T>
        } else {
            // ያለበለዚያ ጠቋሚው ከማይደክመው ደካማ የመጣው ዋስትና አለን ፡፡
            // ደህንነት ptr ማጣቀሻዎች እውነተኛ (ሊወድቅ የሚችል) ቲ.
            let offset = unsafe { data_offset(ptr) };
            // ስለሆነም መላውን RcBox ለማግኘት ማካካሻውን እናስተካክላለን ፡፡
            // ደህንነት: ይህ ደህንነቱ የተጠበቀ ነው የማካካሻ እንዲሁ ጠቋሚ, ደካማ የመነጨው.
            unsafe { (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // ደህንነት: እኛ አሁን እንዲሁ ደካማ መፍጠር ይችላሉ, የመጀመሪያው ደካማ ጠቋሚ አስመለሰ አድርገዋል.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }
}

impl<T: ?Sized> Weak<T> {
    /// የ `Weak` ጠቋሚውን ወደ [`Arc`] ለማሻሻል የተደረገው ሙከራ ፣ ከተሳካ የውስጣዊ እሴቱን መቀነስ ያዘገያል።
    ///
    ///
    /// ከዚያ በኋላ የውስጣዊ እሴቱ ከወረደ [`None`] ን ይመልሳል።
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    ///
    /// let strong_five: Option<Arc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // ሁሉንም ጠንካራ ጠቋሚዎችን ያጥፉ ፡፡
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Arc<T>> {
        // ይህ ተግባር የማጣቀሻውን ቁጥር ከዜሮ ወደ አንድ መውሰድ ስለሌለበት ከ fetch_add ይልቅ ጠንካራውን ቁጥር ለመጨመር የ CAS loop እንጠቀማለን ፡፡
        //
        //
        let inner = self.inner()?;

        // ዘና ያለ ጭነት ምክንያቱም የምንመለከተው ማንኛውም የ 0 ጽሑፍ በቋሚ ዜሮ ሁኔታ ውስጥ ይወጣል (ስለዚህ የ "stale" ንባብ ጥሩ ነው) ፣ እና ማንኛውም ሌላ እሴት ከዚህ በታች ባለው CAS በኩል ይረጋገጣል።
        //
        //
        //
        let mut n = inner.strong.load(Relaxed);

        loop {
            if n == 0 {
                return None;
            }

            // እኛ (`mem::forget` ለ) ይህንን ማድረግ ለምን ለ `Arc::clone` ውስጥ አስተያየቶችን ይመልከቱ.
            if n > MAX_REFCOUNT {
                abort();
            }

            // ዘና ያለ ሁኔታ ስለ ውድቀት ጉዳይ ጥሩ ነው ምክንያቱም ስለ አዲሱ ሁኔታ ምንም ዓይነት ግምት የለንም ፡፡
            // የ `Weak` ማጣቀሻዎች ቀድሞውኑ ከተፈጠሩ በኋላ ውስጣዊ እሴቱ ሊጀመር በሚችልበት ጊዜ ለስኬት ጉዳይ ከ `Arc::new_cyclic` ጋር ለማመሳሰል ማግኛ አስፈላጊ ነው ፡፡
            // በዚያ ሁኔታ ሙሉ በሙሉ የተጀመረውን እሴት እናከብራለን ብለን እንጠብቃለን ፡፡
            //
            match inner.strong.compare_exchange_weak(n, n + 1, Acquire, Relaxed) {
                Ok(_) => return Some(Arc::from_inner(self.ptr)), // ከንቱ ከላይ ምልክት ተደርጎበታል
                Err(old) => n = old,
            }
        }
    }

    /// ወደዚህ ምደባ የሚያመለክቱ ጠንካራ የ (`Arc`) ጠቋሚዎችን ቁጥር ያገኛል።
    ///
    /// X0 `self` ን [`Weak::new`] ን በመጠቀም የተፈጠረ ከሆነ ይህ 0 ይመለሳል።
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong.load(SeqCst) } else { 0 }
    }

    /// ወደዚህ ምደባ የሚጠቁሙ የ `Weak` ጠቋሚዎች ቁጥር ግምትን ያገኛል።
    ///
    /// `self` [`Weak::new`] ን በመጠቀም ከተፈጠረ ወይም ቀሪ ጠንካራ ጠቋሚዎች ከሌሉ ይህ 0 ይመለሳል።
    ///
    /// # Accuracy
    ///
    /// በአተገባበር ዝርዝሮች ምክንያት ሌሎች ክሮች ወደ ተመሳሳይ ምደባ የሚጠቁሙ የትኛውም የ `Arc` ወይም `ደካማ` ምልክቶችን በሚጠቀሙበት ጊዜ የተመለሰው እሴት በሁለቱም አቅጣጫ በ 1 ሊጠፋ ይችላል ፡፡
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                let weak = inner.weak.load(SeqCst);
                let strong = inner.strong.load(SeqCst);
                if strong == 0 {
                    0
                } else {
                    // ደካማውን ቁጥር ካነበብን በኋላ ቢያንስ አንድ ጠቋሚ ጠቋሚ እንደነበረ ስለተመለከትነው ፣ ደካማውን ቆጠራ በተመለከትንበት ጊዜ በግልጽ ደካማ ማጣቀሻ (በማንኛውም ጠንካራ ማመሳከሪያዎች በሕይወት ባሉ ጊዜ ሁሉ ይገኛል) እናውቃለን እናም ስለሆነም በደህና መቀነስ እንችላለን።
                    //
                    //
                    //
                    //
                    weak - 1
                }
            })
            .unwrap_or(0)
    }

    /// ጠቋሚው ሲያንዣብብ እና የተመደበ `ArcInner` ባለመኖሩ `None` ን ይመልሳል ፣ (ማለትም ፣ ይህ `Weak` በ `Weak::new` ሲፈጠር)።
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // የ "data" መስክን የሚሸፍን ማጣቀሻ *ላለመፍጠር* እንጠነቀቃለን ፣ ምክንያቱም መስኩ በተመሳሳይ ጊዜ ሊለወጥ ስለሚችል (ለምሳሌ ፣ የመጨረሻው `Arc` ከወደቀ ፣ የመረጃው መስክ በቦታው ይጣላል)።
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// ይመለሳል `true` ከሆነ ([`ptr::eq`] ጋር ተመሳሳይ) ተመሳሳይ ምደባ ወደ ሁለት `Weak`s ነጥብ, ወይም እነርሱ `Weak::new()`) ጋር የተፈጠሩ ነበር; ምክንያቱም ሁለቱም (ማንኛውንም ምደባ ማመልከት አይደለም ከሆነ.
    ///
    ///
    /// # Notes
    ///
    /// ይህን ዘዴውን ያመሳስለዋል በመሆኑ እነርሱም ማንኛውም ምደባ ማመልከት አይደለም እንኳ `Weak::new()`, እርስ በርሳቸው እኩል ይሆናል ማለት ነው.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let first_rc = Arc::new(5);
    /// let first = Arc::downgrade(&first_rc);
    /// let second = Arc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(5);
    /// let third = Arc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// `Weak::new` በማወዳደር.
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(());
    /// let third = Arc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// ወደ ተመሳሳይ ምደባ የሚጠቁም የ `Weak` ጠቋሚ አንድ ክምር ይሠራል።
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let weak_five = Arc::downgrade(&Arc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        let inner = if let Some(inner) = self.inner() {
            inner
        } else {
            return Weak { ptr: self.ptr };
        };
        // ይህ ለምን ዘና እንደሚል በ Arc::clone() ውስጥ አስተያየቶችን ይመልከቱ።
        // ደካማው ቆጠራ በሕልው ውስጥ *ሌሎች* ደካማ ጠቋሚዎች በሌሉበት ብቻ የተቆለፈ ስለሆነ ይህ fetch_add (መቆለፊያውን ችላ ማለት) ሊጠቀም ይችላል።
        //
        // (ስለዚህ እኛ በዚህ ጊዜ ይህንን ኮድ ማስኬድ አንችልም) ፡፡
        let old_size = inner.weak.fetch_add(1, Relaxed);

        // ለምን እንደምናደርግ በ Arc::clone() ውስጥ አስተያየቶችን ይመልከቱ (ለ mem::forget) ፡፡
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// አዲስ `Weak<T>` ትውስታ በመመደብ ያለ Constructs.
    /// በመመለሻ እሴት ላይ [`upgrade`] ን መደወል ሁልጊዜ [`None`] ን ይሰጣል።
    ///
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// የ `Weak` ጠቋሚ ዝቅ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Arc::new(Foo);
    /// let weak_foo = Arc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // ምንም ነገር አያተምም
    /// drop(foo);        // "dropped!" ን ያትማል
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        // እኛ የመጨረሻው ደካማ ጠቋሚ እንደሆንን ካወቅን መረጃውን ሙሉ በሙሉ ለማካፈል ጊዜው አሁን ነው ፡፡ትውስታ orderings ስለ Arc::drop() ውስጥ ውይይት ይመልከቱ
        //
        // የተቆለፈበትን ሁኔታ እዚህ መፈተሽ አስፈላጊ አይደለም ፣ ምክንያቱም ደካማው ቁጥር ሊቆለፍ የሚችለው በትክክል አንድ ደካማ ሪፈራል ሲኖር ብቻ ነው ፣ ማለትም ጠብታው ከዚያ በኋላ በሚቀረው ደካማ ማጣሪያ ላይ ብቻ ሊሠራ ይችላል ፣ ይህም መቆለፊያው ከተለቀቀ በኋላ ብቻ ነው።
        //
        //
        //
        //
        //
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        if inner.weak.fetch_sub(1, Release) == 1 {
            acquire!(inner.weak);
            unsafe { Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr())) }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait ArcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Arc<T>) -> bool;
    fn ne(&self, other: &Arc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    default fn eq(&self, other: &Arc<T>) -> bool {
        **self == **other
    }
    #[inline]
    default fn ne(&self, other: &Arc<T>) -> bool {
        **self != **other
    }
}

/// ይህንን ልዩ ሙያ እዚህ እያደረግን ነው ፣ እና በ `&T` ላይ እንደ አጠቃላይ አጠቃላይ ማመቻቸት አይደለም ፣ ምክንያቱም በምላሽዎች ላይ ለሁሉም የእኩልነት ፍተሻዎች ወጪን ስለሚጨምር።
/// እኛ `Arc`s ትላልቅ እሴቶችን ለማከማቸት የሚያገለግሉ ናቸው ፣ ይህም ወደ ክሎንግ የሚዘገዩ ፣ ግን እኩልነትን ለመፈተሽም ከባድ ነው ፣ ይህ ወጭ በቀላሉ እንዲከፍል ያደርጋል ፡፡
///
/// ከሁለት&&T`s ይልቅ ወደ ተመሳሳይ እሴት የሚያመለክቱ ሁለት የ `Arc` ክሎኖች የመሆን ዕድሉ ሰፊ ነው ፡፡
///
/// ይህንን ማድረግ የምንችለው `T: Eq` እንደ `PartialEq` ሆን ተብሎ የማይለወጥ ሊሆን በሚችልበት ጊዜ ብቻ ነው ፡፡
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + crate::rc::MarkerEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        Arc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        !Arc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Arc<T> {
    /// ለሁለት `አርክ` እኩልነት ፡፡
    ///
    /// ያላቸውን ውስጣዊ እሴቶች እኩል ከሆኑ ሁለት `Arc`s የተለያዩ ምደባ ውስጥ ይከማቻሉ እንኳ ቢሆን, እኩል ናቸው.
    ///
    /// `T` ደግሞ `Eq` (እኩልነት reflexivity አይተረጎሙም), ሁለት `Arc`s የሚያስፈጽም ከሆነ ተመሳሳይ ምደባ ጋር ነጥብ ምንጊዜም እኩል ናቸው.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five == Arc::new(5));
    /// ```
    ///
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::eq(self, other)
    }

    /// ለሁለት `አርክ` አለመመጣጠን ፡፡
    ///
    /// ውስጣዊ እሴቶቻቸው እኩል ካልሆኑ ሁለት `አርክ` እኩል አይደሉም ፡፡
    ///
    /// `T` ደግሞ `Eq` ን ተግባራዊ የሚያደርግ ከሆነ (የእኩልነትን አንፀባራቂነት የሚያመለክት) ከሆነ ፣ ወደ አንድ ተመሳሳይ እሴት የሚጠቁሙ ሁለት `አርክ` በጭራሽ እኩል አይደሉም ፡፡
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five != Arc::new(6));
    /// ```
    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Arc<T> {
    /// ለሁለት ንፅፅር ከፊል ንፅፅር ፡፡
    ///
    /// ሁለቱ በውስጣዊ እሴቶቻቸው ላይ `partial_cmp()` ን በመጥራት ይነፃፀራሉ ፡፡
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Arc::new(6)));
    /// ```
    fn partial_cmp(&self, other: &Arc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// ለሁለት‹አርክ›ንፅፅር ያነሰ ፡፡
    ///
    /// ሁለቱ በውስጣዊ እሴቶቻቸው ላይ `<` ን በመጥራት ይነፃፀራሉ ፡፡
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five < Arc::new(6));
    /// ```
    fn lt(&self, other: &Arc<T>) -> bool {
        *(*self) < *(*other)
    }

    /// ሁለት `Arc`s ለ ንጽጽር 'ጋር እኩል ያነሰ ወይም'.
    ///
    /// ሁለቱ ያላቸውን ውስጣዊ እሴቶች ላይ `<=` በመደወል ሲነፃፀር ነው.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five <= Arc::new(5));
    /// ```
    fn le(&self, other: &Arc<T>) -> bool {
        *(*self) <= *(*other)
    }

    /// ለሁለት‹አርክ›እጅግ የላቀ ንፅፅር ፡፡
    ///
    /// ሁለቱ በውስጣዊ እሴቶቻቸው ላይ `>` ን በመጥራት ይነፃፀራሉ ፡፡
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five > Arc::new(4));
    /// ```
    fn gt(&self, other: &Arc<T>) -> bool {
        *(*self) > *(*other)
    }

    /// ለሁለት `አርከስ`‹የበለጠ ወይም እኩል›ንፅፅር ፡፡
    ///
    /// ሁለቱ በውስጣዊ እሴቶቻቸው ላይ `>=` ን በመጥራት ይነፃፀራሉ ፡፡
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five >= Arc::new(5));
    /// ```
    fn ge(&self, other: &Arc<T>) -> bool {
        *(*self) >= *(*other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Arc<T> {
    /// ለሁለት `አርክ` ንፅፅር ፡፡
    ///
    /// ሁለቱ በውስጣዊ እሴቶቻቸው ላይ `cmp()` ን በመጥራት ይነፃፀራሉ ፡፡
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Arc::new(6)));
    /// ```
    fn cmp(&self, other: &Arc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Arc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Arc<T> {
    /// አዲስ `Arc<T>` `T` ለ `Default` ዋጋ ጋር, ይፈጥራል.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x: Arc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    fn default() -> Arc<T> {
        Arc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Arc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Arc<T> {
    fn from(t: T) -> Self {
        Arc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Arc<[T]> {
    /// በማጣቀሻ የተቆጠረ ቁርጥራጭ ይመድቡ እና የ `v` ን እቃዎችን በክሎንግ ይሙሉት ፡፡
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Arc<[T]> {
        <Self as ArcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Arc<str> {
    /// አንድ የማመሳከሪያ-ይቆጠራል `str` ለመመደብ እና ወደ `v` ኮፒ.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let shared: Arc<str> = Arc::from("eggplant");
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Arc<str> {
        let arc = Arc::<[u8]>::from(v.as_bytes());
        unsafe { Arc::from_raw(Arc::into_raw(arc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Arc<str> {
    /// አንድ የማመሳከሪያ-ይቆጠራል `str` ለመመደብ እና ወደ `v` ኮፒ.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: String = "eggplant".to_owned();
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Arc<str> {
        Arc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Arc<T> {
    /// የታሸገ ነገርን ወደ አዲስ ፣ በማጣቀሻ-ተቆጥሮ ወደ ሚመደብ ውሰድ።
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Box<str> = Box::from("eggplant");
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Arc<T> {
        Arc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Arc<[T]> {
    /// በማጣቀሻ የተቆጠረ ቁራጭ ይመድቡ እና የ `v` ን እቃዎችን ወደ ውስጥ ያንቀሳቅሱ።
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Vec<i32> = vec![1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(unique);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Arc<[T]> {
        unsafe {
            let arc = Arc::copy_from_slice(&v);

            // Vec ማህደረ ትውስታውን ነፃ እንዲያደርግ ይፍቀዱ ፣ ግን ይዘቱን አያጠፉም
            v.set_len(0);

            arc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Arc<B>
where
    B: ToOwned + ?Sized,
    Arc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Arc<B> {
        match cow {
            Cow::Borrowed(s) => Arc::from(s),
            Cow::Owned(s) => Arc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Arc<[T]>> for Arc<[T; N]> {
    type Error = Arc<[T]>;

    fn try_from(boxed_slice: Arc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Arc::from_raw(Arc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Arc<[T]> {
    /// እያንዳንዱን ንጥረ ነገር በ `Iterator` ውስጥ ይወስዳል እና ወደ `Arc<[T]>` ይሰበስባል።
    ///
    /// # የአፈፃፀም ባህሪዎች
    ///
    /// ## አጠቃላይ ጉዳዩ
    ///
    /// በአጠቃላይ ሁኔታ ወደ `Arc<[T]>` መሰብሰብ በመጀመሪያ ወደ `Vec<T>` በመሰብሰብ ይከናወናል ፡፡ማለትም የሚከተሉትን በሚጽፉበት ጊዜ-
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// ይህ እንደጻፍነው ነው
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // የመጀመሪያው የምደባዎች ስብስብ እዚህ ይከሰታል።
    ///     .into(); // ለ `Arc<[T]>` ሁለተኛ ምደባ እዚህ ይከሰታል።
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// ይህ `Vec<T>` ን ለመገንባት እንደ አስፈላጊነቱ ብዙ ጊዜ ይመድባል ከዚያም `Vec<T>` ን ወደ `Arc<[T]>` ለመቀየር አንድ ጊዜ ይመድባል ፡፡
    ///
    ///
    /// ## የሚታወቅ ርዝመት ኢተራተሮች
    ///
    /// የእርስዎ `Iterator` `TrustedLen` ን ሲተገብር እና ትክክለኛ መጠን ሲኖረው ለ‹`Arc<[T]>` X›አንድ ነጠላ ምደባ ይደረጋል ፡፡ለምሳሌ:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).collect(); // አንድ ነጠላ ምደባ ብቻ እዚህ ይከሰታል።
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToArcSlice::to_arc_slice(iter.into_iter())
    }
}

/// ስፔሻላይዜሽን trait ወደ `Arc<[T]>` ለመሰብሰብ ያገለግል ነበር ፡፡
trait ToArcSlice<T>: Iterator<Item = T> + Sized {
    fn to_arc_slice(self) -> Arc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToArcSlice<T> for I {
    default fn to_arc_slice(self) -> Arc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToArcSlice<T> for I {
    fn to_arc_slice(self) -> Arc<[T]> {
        // ለ `TrustedLen` ተደጋጋሚ ሁኔታ ይህ ነው።
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // ደህንነት-ተደጋጋሚው ትክክለኛ ርዝመት እንዳለው እና እኛ እንዳለን ማረጋገጥ አለብን ፡፡
                Arc::from_iter_exact(self, low)
            }
        } else {
            // ወደ ተለመደው አተገባበር ይመለሱ።
            self.collect::<Vec<T>>().into()
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Arc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Arc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Arc<T> {}

/// ከጠቋሚ ጀርባ ካለው የክፍያ ጭነት በ `ArcInner` ውስጥ ማካካሻውን ያግኙ።
///
/// # Safety
///
/// ጠቋሚው ከዚህ በፊት ተቀባይነት ያለው የ T ምሳሌን (እና ትክክለኛ ሜታዳታ ሊኖረው ይገባል) ማመልከት አለበት ፣ ግን ቲ እንዲወርድ ተፈቅዷል።
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // ያልተመዘገበውን እሴት ከ ArcInner መጨረሻ ጋር ያስተካክሉ።
    // RcBox repr(C) ስለሆነ ሁል ጊዜም በማስታወስ ውስጥ የመጨረሻው መስክ ይሆናል።
    // ደህንነት-ብቸኛ ያልተመጠኑ ዓይነቶች ቁርጥራጭ ፣ trait ነገሮች ፣
    // እና የውጭ ዓይነቶች ፣ የግብዓት ደህንነት መስፈርት በአሁኑ ጊዜ የ align_of_val_raw መስፈርቶችን ለማርካት በቂ ነው ፣ይህ ከ std ውጭ ሊታመን የማይችል የቋንቋ አተገባበር ዝርዝር ነው።
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<ArcInner<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}