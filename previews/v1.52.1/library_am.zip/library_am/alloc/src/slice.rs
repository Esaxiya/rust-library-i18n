//! ወደ ተለዋዋጭ ቅደም ተከተል ተለዋዋጭ መጠን ያለው እይታ ፣ `[T]`.
//!
//! *[See also the slice primitive type](slice).*
//!
//! ገባዎች አንድ ጠቋሚ እና ርዝመት የተመሰለውን ትውስታ አንድ የማገጃ ወደ አንድ አመለካከት ናቸው.
//!
//! ```
//! // አንድ Vec ይቆራርጠው
//! let vec = vec![1, 2, 3];
//! let int_slice = &vec[..];
//! // ድርድርን ወደ አንድ ቁራጭ ማስገደድ
//! let str_slice: &[&str] = &["one", "two", "three"];
//! ```
//!
//! ቁርጥራጮች ወይ ሊለወጡ ወይም ሊጋሩ ይችላሉ።
//! የ ሊቀየሩ ቁራጭ አይነት `T` ወደ ኤለመንት አይነት ይወክላል የት `&mut [T]`, ሳለ የተጋራው ቁራጭ አይነት, `&[T]` ነው.
//! ለምሳሌ ፣ የሚለዋወጥ ቁራጭ የሚያመለክተው የማስታወሻውን ማገጃ መለወጥ ይችላሉ-
//!
//! ```
//! let x = &mut [1, 2, 3];
//! x[1] = 7;
//! assert_eq!(x, &[1, 7, 3]);
//! ```
//!
//! እነሆ በዚህ ሞጁል ይዟል ነገሮች መካከል አንዳንዶቹ የሚከተሉት ናቸው:
//!
//! ## Structs
//!
//! በተቆራረጠ ቦታ ላይ መደጋገምን የሚወክል እንደ‹[`Iter`]›ለመቁረጫ ጠቃሚ የሆኑ በርካታ ረድፎች አሉ ፡፡
//!
//! ## የ Trait ትግበራዎች
//!
//! ገባዎች ለ የተለመደ traits በርካታ ማስፈጸሚያዎች አሉ.አንዳንድ ምሳሌዎች የሚከተሉትን ያካትታሉ:
//!
//! * [`Clone`]
//! * [`Eq`], [`Ord`] ፣ የእነሱ ንጥረ ነገር [`Eq`] ወይም [`Ord`] ለሆኑ ቁርጥራጮች።
//! * [`Hash`] - የንጥረታቸው ዓይነት [`Hash`] ለሆኑ ቁርጥራጮች።
//!
//! ## Iteration
//!
//! የ ገባዎች `IntoIterator` ተግባራዊ ያደርጋል.የ ለተደጋጋሚ ወደ ቁራጭ ንጥረ ነገሮች ማጣቀሻ ያፈራላቸዋል.
//!
//! ```
//! let numbers = &[0, 1, 2];
//! for n in numbers {
//!     println!("{} is a number!", n);
//! }
//! ```
//!
//! የ ሊቀየሩ ቁራጭ ክፍሎች ሊቀየሩ ማጣቀሻ ያፈራላቸዋል:
//!
//! ```
//! let mut scores = [7, 8, 9];
//! for score in &mut scores[..] {
//!     *score += 1;
//! }
//! ```
//!
//! ይህ ለተደጋጋሚ ወደ ቁራጭ ያለውን ኤለመንት አይነት `i32`, ለተደጋጋሚ `&mut i32` ነው መካከል ኤለመንት አይነት ነው, ስለዚህ ሳለ, ወደ ቁራጭ ኃይሎች ጋር ሊቀየሩ የሚችሉ ማጣቀሻዎችን ያፈራላቸዋል.
//!
//!
//! * [`.iter`] እና [`.iter_mut`] ነባሪ iterators ለመመለስ ልቅ ዘዴዎች ናቸው.
//! * iterators መመለስ እንደሆነ ተጨማሪ ዘዴዎች [`.split`], [`.splitn`], [`.chunks`], [`.windows`] እና ተጨማሪ ናቸው.
//!
//! [`Hash`]: core::hash::Hash
//! [`.iter`]: slice::iter
//! [`.iter_mut`]: slice::iter_mut
//! [`.split`]: slice::split
//! [`.splitn`]: slice::splitn
//! [`.chunks`]: slice::chunks
//! [`.windows`]: slice::windows
//!
//!
//!
//!
//!
//!
//!
//!
#![stable(feature = "rust1", since = "1.0.0")]
// በዚህ ሞጁል ውስጥ ያሉት ብዙ አጠቃቀሞች በሙከራ ውቅር ውስጥ ብቻ ያገለግላሉ።
// ይህም የአምላክ የጸዳ ብቻ እነሱን ለማስተካከል ይልቅ ማስጠንቀቂያ ወደ unused_imports ለማጥፋት.
#![cfg_attr(test, allow(unused_imports, dead_code))]

use core::borrow::{Borrow, BorrowMut};
use core::cmp::Ordering::{self, Less};
use core::mem::{self, size_of};
use core::ptr;

use crate::alloc::{Allocator, Global};
use crate::borrow::ToOwned;
use crate::boxed::Box;
use crate::vec::Vec;

#[unstable(feature = "slice_range", issue = "76393")]
pub use core::slice::range;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunks;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunksMut;
#[unstable(feature = "array_windows", issue = "75027")]
pub use core::slice::ArrayWindows;
#[stable(feature = "slice_get_slice", since = "1.28.0")]
pub use core::slice::SliceIndex;
#[stable(feature = "from_ref", since = "1.28.0")]
pub use core::slice::{from_mut, from_ref};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{from_raw_parts, from_raw_parts_mut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Chunks, Windows};
#[stable(feature = "chunks_exact", since = "1.31.0")]
pub use core::slice::{ChunksExact, ChunksExactMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{ChunksMut, Split, SplitMut};
#[unstable(feature = "slice_group_by", issue = "80552")]
pub use core::slice::{GroupBy, GroupByMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Iter, IterMut};
#[stable(feature = "rchunks", since = "1.31.0")]
pub use core::slice::{RChunks, RChunksExact, RChunksExactMut, RChunksMut};
#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub use core::slice::{RSplit, RSplitMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{RSplitN, RSplitNMut, SplitN, SplitNMut};

////////////////////////////////////////////////////////////////////////////////
// መሰረታዊ የተቆራረጠ ማራዘሚያ ዘዴዎች
////////////////////////////////////////////////////////////////////////////////

// HACK(japaric) ኤን.ቢ. በሚመረምርበት ጊዜ ለ‹XXXX›ማክሮ ተግባራዊነት ያስፈልጋል ፣ ለበለጠ ዝርዝር በዚህ ፋይል ውስጥ ያለውን የ‹`hack`›ሞዱል ይመልከቱ ፡፡
//
#[cfg(test)]
pub use hack::into_vec;

// HACK(japaric) ኤን.ቢ. በሚመረምርበት ጊዜ ለ‹`Vec::clone` X›ትግበራ ያስፈልጋል ፣ ለበለጠ ዝርዝር በዚህ ፋይል ውስጥ ያለውን የ‹`hack`›ሞዱል ይመልከቱ ፡፡
//
#[cfg(test)]
pub use hack::to_vec;

// HACK(japaric): በ cfg(test) `impl [T]` አይገኝም ፣ እነዚህ ሶስት ተግባራት በእውነቱ በ `impl [T]` ውስጥ ያሉ ግን በ `core::slice::SliceExt` ውስጥ የማይገኙ ዘዴዎች ናቸው ፣ እነዚህን ተግባራት ለ `test_permutations` ሙከራ ማቅረብ አለብን
//
//
//
mod hack {
    use core::alloc::Allocator;

    use crate::boxed::Box;
    use crate::vec::Vec;

    // ይህ በ‹XXXXXX›ማክሮ ውስጥ በአብዛኛው ጥቅም ላይ የሚውል እና የሽቶ መመለሻን የሚያስከትል በመሆኑ የውስጠ-ባህርይ ባህሪን ማከል የለብንም ፡፡
    // ለውይይት እና ለሽቶ ውጤቶች #71204 ን ይመልከቱ ፡፡
    //
    pub fn into_vec<T, A: Allocator>(b: Box<[T], A>) -> Vec<T, A> {
        unsafe {
            let len = b.len();
            let (b, alloc) = Box::into_raw_with_allocator(b);
            Vec::from_raw_parts_in(b as *mut T, len, len, alloc)
        }
    }

    #[inline]
    pub fn to_vec<T: ConvertVec, A: Allocator>(s: &[T], alloc: A) -> Vec<T, A> {
        T::to_vec(s, alloc)
    }

    pub trait ConvertVec {
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A>
        where
            Self: Sized;
    }

    impl<T: Clone> ConvertVec for T {
        #[inline]
        default fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            struct DropGuard<'a, T, A: Allocator> {
                vec: &'a mut Vec<T, A>,
                num_init: usize,
            }
            impl<'a, T, A: Allocator> Drop for DropGuard<'a, T, A> {
                #[inline]
                fn drop(&mut self) {
                    // SAFETY:
                    // ንጥሎች ከዚህ በታች ባለው ዑደት ውስጥ እንደተጀመሩ ምልክት ተደርጎባቸዋል
                    unsafe {
                        self.vec.set_len(self.num_init);
                    }
                }
            }
            let mut vec = Vec::with_capacity_in(s.len(), alloc);
            let mut guard = DropGuard { vec: &mut vec, num_init: 0 };
            let slots = guard.vec.spare_capacity_mut();
            // .take(slots.len()) LLVM ሕግጋት ቼኮችን ለማስወገድ እና የተሻለ ዚፕ ይልቅ codegen አድርጓል አስፈላጊ ነው.
            //
            for (i, b) in s.iter().enumerate().take(slots.len()) {
                guard.num_init = i;
                slots[i].write(b.clone());
            }
            core::mem::forget(guard);
            // SAFETY:
            // vec ቢያንስ ለዚህ ርዝመት ተመድቦ ተጀምሯል ፡፡
            unsafe {
                vec.set_len(s.len());
            }
            vec
        }
    }

    impl<T: Copy> ConvertVec for T {
        #[inline]
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            let mut v = Vec::with_capacity_in(s.len(), alloc);
            // SAFETY:
            // ከዚህ በላይ በ `s` አቅም የተመደበ እና ከዚህ በታች ptr::copy_to_non_overlapping ውስጥ ወደ `s.len()` ይጀምሩ።
            //
            unsafe {
                s.as_ptr().copy_to_nonoverlapping(v.as_mut_ptr(), s.len());
                v.set_len(s.len());
            }
            v
        }
    }
}

#[lang = "slice_alloc"]
#[cfg_attr(not(test), rustc_diagnostic_item = "slice")]
#[cfg(not(test))]
impl<T> [T] {
    /// የ ቁራጭ ይደረድራቸዋል.
    ///
    /// ይህ ዓይነቱ የተረጋጋ ነው (ማለትም ፣ እኩል አካላትን እንደገና አያስተላልፍም) እና *O*(*n*\*log(* n*)) የከፋ ሁኔታ።
    ///
    /// በሚተገበርበት ጊዜ ፣ የተረጋጋ አደረጃጀት ተመራጭ ነው ፣ ምክንያቱም በአጠቃላይ ከተረጋጋ አደረጃጀት የበለጠ ፈጣን ስለሆነ እና ረዳት ማህደረ ትውስታን አይመድበውም።
    /// [`sort_unstable`](slice::sort_unstable) ን ይመልከቱ።
    ///
    /// # የአሁኑ ትግበራ
    ///
    /// የአሁኑ ስልተ-ቀመር በ‹XXXX›ተመስጦ ተስማሚ ፣ ተመጣጣኝ ያልሆነ ውህደት ዓይነት ነው ፡፡
    /// ይህ ቁራጭ የሚጠጉ ተደርድሯል የት ጉዳዮች ላይ በጣም ፈጣን እንዲሆን የተቀየሰ ነው, ወይም በሁለት ያቀፈ ወይም ከዚያ በላይ የተደረደሩ ተከታታይ እርስ በኋላ አንድ concatenated ነው.
    ///
    ///
    /// እንዲሁም ፣ እሱ የ `self` ን ግማሽ ጊዜያዊ ማከማቻን ይመድባል ፣ ግን ለአጭር ቁርጥራጭ በምትኩ የማይመደብ የማስገቢያ ዓይነት ጥቅም ላይ ይውላል።
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5, 4, 1, -3, 2];
    ///
    /// v.sort();
    /// assert!(v == [-5, -3, 1, 2, 4]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort(&mut self)
    where
        T: Ord,
    {
        merge_sort(self, |a, b| a.lt(b));
    }

    /// ቁርጥራጩን ከማነፃፀሪያ ተግባር ጋር ይለያል።
    ///
    /// ይህ ዓይነቱ የተረጋጋ ነው (ማለትም ፣ እኩል አካላትን እንደገና አያስተላልፍም) እና *O*(*n*\*log(* n*)) የከፋ ሁኔታ።
    ///
    /// በንፅፅሩ ውስጥ ላሉት ንጥረ ነገሮች የንፅፅር ተግባሩ አጠቃላይ ቅደም ተከተል መወሰን አለበት ፡፡ትዕዛዙ አጠቃላይ ካልሆነ የአባላቱ ቅደም ተከተል አልተገለጸም ፡፡
    /// አንድ ትዕዛዝ (ሁሉም `a`, `b` እና `c` ለ) ይህ ከሆነ አንድ ጠቅላላ ቅደም ተከተል ነው:
    ///
    /// * ጠቅላላ እና antisymmetric: `a < b`, `a == b` ወይም `a > b` መካከል ልክ አንድ እውነተኛ ነው;
    /// * ተሻጋሪ, `a < b` እና `b < c` `a < c` ያመለክታል.`==` እና `>` ለሁለቱም ተመሳሳይ የግድ መያዝ.
    ///
    /// ለምሳሌ ፣ [`f64`] `NaN != NaN` ን [`Ord`] ን ባያስተገብርም ፣ XT `NaN` ን እንደሌለው ስናውቅ `partial_cmp` ን እንደየእኛ ተግባራችን ልንጠቀምበት እንችላለን ፡፡
    ///
    ///
    /// ```
    /// let mut floats = [5f64, 4.0, 1.0, 3.0, 2.0];
    /// floats.sort_by(|a, b| a.partial_cmp(b).unwrap());
    /// assert_eq!(floats, [1.0, 2.0, 3.0, 4.0, 5.0]);
    /// ```
    ///
    /// በሚተገበርበት ጊዜ ፣ የተረጋጋ አደረጃጀት ተመራጭ ነው ፣ ምክንያቱም በአጠቃላይ ከተረጋጋ አደረጃጀት የበለጠ ፈጣን ስለሆነ እና ረዳት ማህደረ ትውስታን አይመድበውም።
    /// [`sort_unstable_by`](slice::sort_unstable_by) ን ይመልከቱ።
    ///
    /// # የአሁኑ ትግበራ
    ///
    /// የአሁኑ ስልተ-ቀመር በ‹XXXX›ተመስጦ ተስማሚ ፣ ተመጣጣኝ ያልሆነ ውህደት ዓይነት ነው ፡፡
    /// ይህ ቁራጭ የሚጠጉ ተደርድሯል የት ጉዳዮች ላይ በጣም ፈጣን እንዲሆን የተቀየሰ ነው, ወይም በሁለት ያቀፈ ወይም ከዚያ በላይ የተደረደሩ ተከታታይ እርስ በኋላ አንድ concatenated ነው.
    ///
    /// እንዲሁም ፣ እሱ የ `self` ን ግማሽ ጊዜያዊ ማከማቻን ይመድባል ፣ ግን ለአጭር ቁርጥራጭ በምትኩ የማይመደብ የማስገቢያ ዓይነት ጥቅም ላይ ይውላል።
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [5, 4, 1, 3, 2];
    /// v.sort_by(|a, b| a.cmp(b));
    /// assert!(v == [1, 2, 3, 4, 5]);
    ///
    /// // የተገላቢጦሽ ድርድር
    /// v.sort_by(|a, b| b.cmp(a));
    /// assert!(v == [5, 4, 3, 2, 1]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort_by<F>(&mut self, mut compare: F)
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        merge_sort(self, |a, b| compare(a, b) == Less);
    }

    /// ቁልፍ Extraction ተግባር ጋር ቁራጭ ይደረድራቸዋል.
    ///
    /// ይህ ዓይነቱ የተረጋጋ ነው (ማለትም ፣ እኩል አካላትን እንደገና አያስተላልፍም) እና *O*(*m*\* * n *\* log(*n*)) የከፋ ሁኔታ ፣ የቁልፍ ተግባሩ *O*(*m*) ነው።
    ///
    /// ውድ ቁልፍ ተግባራት (ለምሳሌ
    /// አይደለም ቀላል ንብረት የመጠቀሚያ ጊዜ ወይም መሠረታዊ ኦፕሬሽን እንደሆኑ ነው ተግባራት), [`sort_by_cached_key`](slice::sort_by_cached_key) አይደለም recompute ንጥረ ቁልፎች የሚያደርግ ሆኖ አይቀርም, በፍጥነት ጉልህ መሆን ነው.
    ///
    ///
    /// በሚተገበርበት ጊዜ ፣ የተረጋጋ አደረጃጀት ተመራጭ ነው ፣ ምክንያቱም በአጠቃላይ ከተረጋጋ አደረጃጀት የበለጠ ፈጣን ስለሆነ እና ረዳት ማህደረ ትውስታን አይመድበውም።
    /// [`sort_unstable_by_key`](slice::sort_unstable_by_key) ይመልከቱ.
    ///
    /// # የአሁኑ ትግበራ
    ///
    /// የአሁኑ ስልተ-ቀመር በ‹XXXX›ተመስጦ ተስማሚ ፣ ተመጣጣኝ ያልሆነ ውህደት ዓይነት ነው ፡፡
    /// ይህ ቁራጭ የሚጠጉ ተደርድሯል የት ጉዳዮች ላይ በጣም ፈጣን እንዲሆን የተቀየሰ ነው, ወይም በሁለት ያቀፈ ወይም ከዚያ በላይ የተደረደሩ ተከታታይ እርስ በኋላ አንድ concatenated ነው.
    ///
    /// እንዲሁም ፣ እሱ የ `self` ን ግማሽ ጊዜያዊ ማከማቻን ይመድባል ፣ ግን ለአጭር ቁርጥራጭ በምትኩ የማይመደብ የማስገቢያ ዓይነት ጥቅም ላይ ይውላል።
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// v.sort_by_key(|k| k.abs());
    /// assert!(v == [1, 2, -3, 4, -5]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_key", since = "1.7.0")]
    #[inline]
    pub fn sort_by_key<K, F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        merge_sort(self, |a, b| f(a).lt(&f(b)));
    }

    /// ቁልፍ Extraction ተግባር ጋር ቁራጭ ይደረድራቸዋል.
    ///
    /// ድርደራ ወቅት ቁልፍ ተግባር ብቻ ኤለመንት አንድ ጊዜ ይባላል.
    ///
    /// ይህ ዓይነት የተረጋጋ ነው (ማለትም, አይደለም ዳግምስርዓትአስይዝ እኩል ክፍሎች የሚያደርግ) እና *ሆይ*(*ሜትር*\* * n *+* n *\* ቁልፍ ተግባር *ሆይ*(*ሜትር ቦታ የከፋ ሁኔታ log(* n *)),*) .
    ///
    /// ለቀላል ቁልፍ ተግባራት (ለምሳሌ ፣ የንብረት ተደራሽነት ወይም መሠረታዊ ክዋኔዎች ለሆኑ ተግባራት) [`sort_by_key`](slice::sort_by_key) ፈጣን ሊሆን ይችላል ፡፡
    ///
    /// # የአሁኑ ትግበራ
    ///
    /// የአሁኑ ስልተ አንዳንድ የተወሰኑ ቅጦች ጋር ገባዎች ላይ መስመራዊ ጊዜ ለማሳካት ሳለ, heapsort በፍጥነት አስከፊ ሁኔታ ጋር በሚካሄዱ quicksort በፍጥነት አማካይ ጉዳይ አጣምሮ Orson ፒተርስ, በ [pattern-defeating quicksort][pdqsort] ላይ የተመሠረተ ነው.
    /// ይህ የተበላሸ ሁኔታዎች ለማስቀረት አንዳንድ randomization ይጠቀማል, ነገር ግን ቋሚ seed ጋር ሁልጊዜ deterministic ባህሪ ማቅረብ.
    ///
    /// በጣም በከፋ ሁኔታ ፣ አልጎሪዝም በተቆራረጠ ርዝመት `Vec<(K, usize)>` ውስጥ ጊዜያዊ ማከማቻ ይመድባል።
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 32, -3, 2];
    ///
    /// v.sort_by_cached_key(|k| k.to_string());
    /// assert!(v == [-3, -5, 2, 32, 4]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_cached_key", since = "1.34.0")]
    #[inline]
    pub fn sort_by_cached_key<K, F>(&mut self, f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        // ምደባ ለመቀነስ, ትንሹ በተቻለ አይነት በማድረግ ያለንን vector ጠቋሚ ለማግኘት አጋዥ ማክሮ.
        macro_rules! sort_by_key {
            ($t:ty, $slice:ident, $f:ident) => {{
                let mut indices: Vec<_> =
                    $slice.iter().map($f).enumerate().map(|(i, k)| (k, i as $t)).collect();
                // ማንኛውም ዓይነት የመጀመሪያው ቁራጭ ጋር በተያያዘ የተረጋጋ ይሆናል ስለዚህ እነርሱ, የመረጃ ጠቋሚ ናቸው እንደ `indices` ያለው ንጥረ ነገሮች, ልዩ ናቸው.
                // `sort_unstable` ን እዚህ እንጠቀማለን ምክንያቱም አነስተኛ የማስታወሻ ምደባ ይፈልጋል ፡፡
                //
                indices.sort_unstable();
                for i in 0..$slice.len() {
                    let mut index = indices[i].1;
                    while (index as usize) < i {
                        index = indices[index as usize].1;
                    }
                    indices[i].1 = index;
                    $slice.swap(i, index as usize);
                }
            }};
        }

        let sz_u8 = mem::size_of::<(K, u8)>();
        let sz_u16 = mem::size_of::<(K, u16)>();
        let sz_u32 = mem::size_of::<(K, u32)>();
        let sz_usize = mem::size_of::<(K, usize)>();

        let len = self.len();
        if len < 2 {
            return;
        }
        if sz_u8 < sz_u16 && len <= (u8::MAX as usize) {
            return sort_by_key!(u8, self, f);
        }
        if sz_u16 < sz_u32 && len <= (u16::MAX as usize) {
            return sort_by_key!(u16, self, f);
        }
        if sz_u32 < sz_usize && len <= (u32::MAX as usize) {
            return sort_by_key!(u32, self, f);
        }
        sort_by_key!(usize, self, f)
    }

    /// ቅጂዎች አዲስ `Vec` ወደ `self`.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = [10, 40, 30];
    /// let x = s.to_vec();
    /// // እነሆ, `s` እና `x` በተናጥል ሊሻሻል ይችላል.
    /// ```
    #[rustc_conversion_suggestion]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_vec(&self) -> Vec<T>
    where
        T: Clone,
    {
        self.to_vec_in(Global)
    }

    /// ቅጂዎች አንድ allocator ጋር አዲስ `Vec` ወደ `self`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let s = [10, 40, 30];
    /// let x = s.to_vec_in(System);
    /// // እነሆ, `s` እና `x` በተናጥል ሊሻሻል ይችላል.
    /// ```
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn to_vec_in<A: Allocator>(&self, alloc: A) -> Vec<T, A>
    where
        T: Clone,
    {
        // NB ፣ ለተጨማሪ ዝርዝሮች በዚህ ፋይል ውስጥ ያለውን የ `hack` ሞጁሉን ይመልከቱ ፡፡
        hack::to_vec(self, alloc)
    }

    /// ሸቀጦችን ወይም ምደባ ያለ vector ወደ ይቀይራል `self`.
    ///
    /// የተገኘው vector በ Vec በኩል እንደገና ወደ ሳጥን ሊቀየር ይችላል<T>` `into_boxed_slice` ዘዴ s.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let s: Box<[i32]> = Box::new([10, 40, 30]);
    /// let x = s.into_vec();
    /// // `s` ይህ `x` ወደ የተቀየሩ ቆይቷል ምክንያቱም ከእንግዲህ ላይ ሊውል አይችልም.
    ///
    /// assert_eq!(x, vec![10, 40, 30]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn into_vec<A: Allocator>(self: Box<Self, A>) -> Vec<T, A> {
        // NB ፣ ለተጨማሪ ዝርዝሮች በዚህ ፋይል ውስጥ ያለውን የ `hack` ሞጁሉን ይመልከቱ ፡፡
        hack::into_vec(self)
    }

    /// የተቆራረጠ `n` ጊዜዎችን በመድገም vector ን ይፈጥራል።
    ///
    /// # Panics
    ///
    /// ይህ ተግባር panic አቅም ሞልቶ ነበር ከሆነ.
    ///
    /// # Examples
    ///
    /// መሠረታዊ አጠቃቀም
    ///
    /// ```
    /// assert_eq!([1, 2].repeat(3), vec![1, 2, 1, 2, 1, 2]);
    /// ```
    ///
    /// ፍሰት ላይ አንድ panic:
    ///
    /// ```should_panic
    /// // this will panic at runtime
    /// b"0123456789abcdef".repeat(usize::MAX);
    /// ```
    #[stable(feature = "repeat_generic_slice", since = "1.40.0")]
    pub fn repeat(&self, n: usize) -> Vec<T>
    where
        T: Copy,
    {
        if n == 0 {
            return Vec::new();
        }

        // `n` ከዜሮ በላይ ትልቅ ከሆነ, `n = 2^expn + rem (2^expn > rem, expn >= 0, rem >= 0)` እንደ ሊከፋፈሉ ይችላሉ.
        // `2^expn` በግራ '1' ቢት `n` የተወከለው ቁጥር ሲሆን `rem` ደግሞ የ `n` ቀሪ ክፍል ነው።
        //
        //

        // `set_len()` ን ለመድረስ `Vec` ን በመጠቀም ፡፡
        let capacity = self.len().checked_mul(n).expect("capacity overflow");
        let mut buf = Vec::with_capacity(capacity);

        // `2^expn` መደጋገም የሚከናወነው በ `buf` `expn`-times እጥፍ በመደመር ነው።
        buf.extend(self);
        {
            let mut m = n >> 1;
            // `m > 0` ከሆነ እስከ ግራ ቀኝ '1' ድረስ የሚቀሩ ቢቶች አሉ።
            while m > 0 {
                // `buf.extend(buf)`:
                unsafe {
                    ptr::copy_nonoverlapping(
                        buf.as_ptr(),
                        (buf.as_mut_ptr() as *mut T).add(buf.len()),
                        buf.len(),
                    );
                    // `buf` የ `self.len() * n` አቅም አለው።
                    let buf_len = buf.len();
                    buf.set_len(buf_len * 2);
                }

                m >>= 1;
            }
        }

        // `rem` (`=n, 2 ^ expn`) ድግግሞሽ የሚከናወነው የመጀመሪያዎቹን የ `rem` ድግግሞሾችን ከ `buf` በመገልበጥ ነው ፡፡
        //
        let rem_len = capacity - buf.len(); // `self.len() * rem`
        if rem_len > 0 {
            // `buf.extend(buf[0 .. rem_len])`:
            unsafe {
                // ይህ ከ `2^expn > rem` ጀምሮ ተደራራቢ አይደለም።
                ptr::copy_nonoverlapping(
                    buf.as_ptr(),
                    (buf.as_mut_ptr() as *mut T).add(buf.len()),
                    rem_len,
                );
                // `buf.len() + rem_len` ከ `buf.capacity()` ጋር እኩል ይሆናል (`= self.len() * n`))።
                buf.set_len(capacity);
            }
        }
        buf
    }

    /// የ `T` ቁራጭ ወደ አንድ ነጠላ እሴት `Self::Output` ያስገባል ፡፡
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].concat(), "helloworld");
    /// assert_eq!([[1, 2], [3, 4]].concat(), [1, 2, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn concat<Item: ?Sized>(&self) -> <Self as Concat<Item>>::Output
    where
        Self: Concat<Item>,
    {
        Concat::concat(self)
    }

    /// በእያንዲንደ በእያንዲንደ መካከሌ የተሇያዩ መለያዎችን በማስቀመጥ የ `T` ቁራጭ ወደ አንድ ነጠላ እሴት `Self::Output` ያስገባሌ ፡፡
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].join(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].join(&0), [1, 2, 0, 3, 4]);
    /// assert_eq!([[1, 2], [3, 4]].join(&[0, 0][..]), [1, 2, 0, 0, 3, 4]);
    /// ```
    #[stable(feature = "rename_connect_to_join", since = "1.3.0")]
    pub fn join<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }

    /// በእያንዲንደ በእያንዲንደ መካከሌ የተሇያዩ መለያዎችን በማስቀመጥ የ `T` ቁራጭ ወደ አንድ ነጠላ እሴት `Self::Output` ያስገባሌ ፡፡
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(deprecated)]
    /// assert_eq!(["hello", "world"].connect(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].connect(&0), [1, 2, 0, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.3.0", reason = "renamed to join")]
    pub fn connect<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }
}

#[lang = "slice_u8_alloc"]
#[cfg(not(test))]
impl [u8] {
    /// እያንዳንዱ ባይት በካርታው ላይ ወደ ASCII የላይኛው ጉዳይ ተመሳሳይ በሆነበት የዚህ ቁራጭ ቅጅ የያዘ vector ን ይመልሳል።
    ///
    ///
    /// የ ASCII ፊደሎች ከ 'a' እስከ 'z' ወደ 'A' እስከ 'Z' ካርታ ይደረጋሉ ፣ ግን የ ASCII ያልሆኑ ፊደላት አልተለወጡም ፡፡
    ///
    /// በቦታው ላይ እሴቱን በጅምላ ለማሳደግ [`make_ascii_uppercase`] ን ይጠቀሙ።
    ///
    /// [`make_ascii_uppercase`]: u8::make_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_uppercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_uppercase();
        me
    }

    /// እያንዳንዱ ባይት በካርታው ላይ ወደ ASCII ዝቅተኛ ፊደል አቻው የሚመሳሰልበትን የዚህ ቁራጭ ቅጅ የያዘ vector ን ይመልሳል።
    ///
    ///
    /// የ ASCII ፊደሎች ከ 'A' እስከ 'Z' ወደ 'a' እስከ 'z' ካርታ ይደረጋሉ ፣ ግን የ ASCII ያልሆኑ ፊደላት አልተለወጡም ፡፡
    ///
    /// በቦታው ላይ እሴትን ለማሳነስ [`make_ascii_lowercase`] ን ይጠቀሙ።
    ///
    /// [`make_ascii_lowercase`]: u8::make_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_lowercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_lowercase();
        me
    }
}

////////////////////////////////////////////////////////////////////////////////
// በተወሰኑ የውሂብ ዓይነቶች ላይ ለሚቆርጡ ቁርጥራጮች ቅጥያ traits
////////////////////////////////////////////////////////////////////////////////

/// ረዳት trait ለ [`[T]: : concat`]](ቁራጭ::ኮንሰርት)።
///
/// Note: የ‹XXXXXXXXXXX›አይነት መስፈርት በዚህ trait ውስጥ ጥቅም ላይ አይውልም ፣ ግን ግኝቶች የበለጠ አጠቃላይ እንዲሆኑ ያስችላቸዋል።
/// ያለሱ እኛ ይህንን ስህተት እናገኛለን
///
/// ```error
/// error[E0207]: the type parameter `T` is not constrained by the impl trait, self type, or predica
///    --> src/liballoc/slice.rs:608:6
///     |
/// 608 | impl<T: Clone, V: Borrow<[T]>> Concat for [V] {
///     |      ^ unconstrained type parameter
/// ```
///
/// ምክንያቱም የ `V` አይነቶች ከበርካታ `Borrow<[_]>` impls ጋር ሊኖር ይችላል ፣ ምክንያቱም በርካታ የ `T` ዓይነቶች ይተገበራሉ።
///
///
/// ```
/// # #[allow(dead_code)]
/// pub struct Foo(Vec<u32>, Vec<String>);
///
/// impl std::borrow::Borrow<[u32]> for Foo {
///     fn borrow(&self) -> &[u32] { &self.0 }
/// }
///
/// impl std::borrow::Borrow<[String]> for Foo {
///     fn borrow(&self) -> &[String] { &self.1 }
/// }
/// ```
///
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Concat<Item: ?Sized> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// ከተጣመረ በኋላ የተገኘው ዓይነት
    type Output;

    /// የ ``[T]: : concat`] ትግበራ (ቁርጥራጭ ቁርጥራጭ)
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn concat(slice: &Self) -> Self::Output;
}

/// ረዳት trait ለ [`[T]: : join`](ቁርጥራጭ::ተቀላቀል)
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Join<Separator> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// ከተጣመረ በኋላ የተገኘው ዓይነት
    type Output;

    /// የ ``[T]: : join`] ትግበራ (ቁራጭ::ተቀላቀል)
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn join(slice: &Self, sep: Separator) -> Self::Output;
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Concat<T> for [V] {
    type Output = Vec<T>;

    fn concat(slice: &Self) -> Vec<T> {
        let size = slice.iter().map(|slice| slice.borrow().len()).sum();
        let mut result = Vec::with_capacity(size);
        for v in slice {
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&T> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &T) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size = slice.iter().map(|v| v.borrow().len()).sum::<usize>() + slice.len() - 1;
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.push(sep.clone());
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&[T]> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &[T]) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size =
            slice.iter().map(|v| v.borrow().len()).sum::<usize>() + sep.len() * (slice.len() - 1);
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.extend_from_slice(sep);
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

////////////////////////////////////////////////////////////////////////////////
// ለመቁረጫዎች መደበኛ የ trait ትግበራዎች
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Borrow<[T]> for Vec<T> {
    fn borrow(&self) -> &[T] {
        &self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> BorrowMut<[T]> for Vec<T> {
    fn borrow_mut(&mut self) -> &mut [T] {
        &mut self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> ToOwned for [T] {
    type Owned = Vec<T>;
    #[cfg(not(test))]
    fn to_owned(&self) -> Vec<T> {
        self.to_vec()
    }

    #[cfg(test)]
    fn to_owned(&self) -> Vec<T> {
        hack::to_vec(self, Global)
    }

    fn clone_into(&self, target: &mut Vec<T>) {
        // እንደገና የማይፃፍ ማንኛውንም ዒላማ ውስጥ ጣል ያድርጉ
        target.truncate(self.len());

        // target.len <= self.len ከላይ ባለው መጥረጊያ ምክንያት ፣ ስለሆነም እዚህ ያሉት ቁርጥራጮች ሁል ጊዜ ወሰን አላቸው።
        //
        let (init, tail) = self.split_at(target.len());

        // ያሉትን እሴቶች allocations/resources ን እንደገና ይጠቀሙ።
        target.clone_from_slice(init);
        target.extend_from_slice(tail);
    }
}

////////////////////////////////////////////////////////////////////////////////
// Sorting
////////////////////////////////////////////////////////////////////////////////

/// ሙሉ `v[..]` እንዲደረደር `v[0]` ን በቅድመ-ቅደም ተከተል ቅደም ተከተል `v[1..]` ውስጥ ያስገባል።
///
/// ይህ የማስገባት አይነት መሠረታዊ ንዑስ አካል ነው።
fn insert_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    if v.len() >= 2 && is_less(&v[1], &v[0]) {
        unsafe {
            // ማስገባትን እዚህ ለመተግበር ሦስት መንገዶች አሉ-
            //
            // 1. የመጀመሪያው ወደ መጨረሻው መድረሻ እስኪደርስ ድረስ ተጓዳኝ አባላትን ይቀያይሩ ፡፡
            //    ይሁን እንጂ, በዚህ መንገድ እኛ ዙሪያ ይበልጥ አስፈላጊ ነው በላይ ውሂብ ለመገልበጥ.
            //    አካላት ትልቅ መዋቅሮች ከሆኑ (ለመቅዳት ውድ) ፣ ይህ ዘዴ ቀርፋፋ ይሆናል።
            //
            // 2. ለመጀመሪያው ንጥረ ነገር ትክክለኛ ቦታ እስኪገኝ ድረስ ይቅጠሩ ፡፡
            // ከዚያ ለእሱ ክፍት ቦታ እንዲሆኑ የተከተሉትን ንጥረ ነገሮች ይቀያይሩ እና በመጨረሻም ወደ ቀሪው ቀዳዳ ውስጥ ያስገቡ ፡፡
            // ይህ ጥሩ ዘዴ ነው ፡፡
            //
            // 3. የመጀመሪያውን ንጥረ ነገር ወደ ጊዜያዊ ተለዋዋጭ ይቅዱ።ለእሱ ትክክለኛ ቦታ እስኪገኝ ድረስ ኢትሬት ያድርጉ ፡፡
            // በምንሄድበት ጊዜ እያንዳንዱን የተሻገረ ንጥረ ነገር ከዚህ በፊት ባለው ቀዳዳ ውስጥ ይቅዱ።
            // በመጨረሻም ከጊዚያዊ ተለዋዋጭ መረጃ ወደ ቀሪው ቀዳዳ ይቅዱ።
            // ይህ ዘዴ በጣም ጥሩ ነው ፡፡
            // ቤንችማርኮች ከ 2 ኛው ዘዴ ጋር ሲነፃፀር በመጠኑ የተሻለ አፈፃፀም አሳይተዋል ፡፡
            //
            // ሁሉም ዘዴዎች በንድፍ ደረጃ የተቀመጡ ሲሆን ሦስተኛው ደግሞ ጥሩ ውጤቶችን አሳይቷል ፡፡ስለዚህ ያንን መርጠናል ፡፡
            let mut tmp = mem::ManuallyDrop::new(ptr::read(&v[0]));

            // የማስገባት ሂደት መካከለኛ ሁኔታ ሁል ጊዜ ሁለት ዓላማዎችን በሚያከናውን በ `hole` ይከታተላል-
            // 1. `is_less` ውስጥ panics ከ `v` ቅንነት ይጠብቃል.
            // 2. በመጨረሻው በ `v` ውስጥ የቀረውን ቀዳዳ ይሞላል።
            //
            // የ Panic ደህንነት
            //
            // በሂደቱ ወቅት በማንኛውም ቦታ `is_less` panics ከሆነ `hole` ይወርዳል እና ቀዳዳውን በ `v` ውስጥ በ `tmp` ይሞላል ፣ ስለሆነም `v` መጀመሪያ ላይ የያዛቸውን እቃዎች በሙሉ በትክክል አንዴ እንደያዘ ያረጋግጣል ፡፡
            //
            //
            //
            let mut hole = InsertionHole { src: &mut *tmp, dest: &mut v[1] };
            ptr::copy_nonoverlapping(&v[1], &mut v[0], 1);

            for i in 2..v.len() {
                if !is_less(&v[i], &*tmp) {
                    break;
                }
                ptr::copy_nonoverlapping(&v[i], &mut v[i - 1], 1);
                hole.dest = &mut v[i];
            }
            // `hole` ይወድቃል እናም `tmp` ን ወደ ቀሪው ቀዳዳ በ `v` ውስጥ ይገለብጣል ፡፡
        }
    }

    // ሲጣሉ ፣ ከ `src` ወደ `dest` ቅጂዎች ፡፡
    struct InsertionHole<T> {
        src: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for InsertionHole<T> {
        fn drop(&mut self) {
            unsafe {
                ptr::copy_nonoverlapping(self.src, self.dest, 1);
            }
        }
    }
}

/// ውህደት የማይቀንስ `v[..mid]` ን እና `v[mid..]` ን እንደ `buf` በመጠቀም እንደ ጊዜያዊ ማከማቻ ያካሂዳል እና ውጤቱን ወደ `v[..]` ያከማቻል።
///
/// # Safety
///
/// ሁለቱ ቁርጥራጮች ባዶ ያልሆኑ እና `mid` ወሰን ውስጥ መሆን አለባቸው።
/// የአጫጭር ቁርጥራጭ ቅጅ ለመያዝ ቋት `buf` ረጅም መሆን አለበት።
/// እንዲሁም ፣ `T` የዜሮ መጠን ዓይነት መሆን የለበትም።
unsafe fn merge<T, F>(v: &mut [T], mid: usize, buf: *mut T, is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    let v = v.as_mut_ptr();
    let (v_mid, v_end) = unsafe { (v.add(mid), v.add(len)) };

    // የመዋሃድ ሂደት መጀመሪያ አጭር የሆነውን ወደ `buf` ይገለብጣል።
    // ከዚያ አዲስ የተቀዳውን ሩጫ እና ረዘም ያለ ሩጫውን ወደ ፊት (ወይም ወደኋላ) ይመረምራል ፣ ቀጣዮቹን ያልታሰቡ አካሎቻቸውን በማነፃፀር እና አነስተኛውን (ወይም ትልቁን) ወደ `v` ይገለብጣል ፡፡
    //
    // አጭሩ ሩጫ ሙሉ በሙሉ እንደጨረሰ ሂደቱ ይከናወናል።ረጅሙ መጀመሪያ የሚበላ ከሆነ ፣ ከዚያ አጭር ሩጫ የተረፈውን በ `v` ውስጥ ወደ ቀሪው ቀዳዳ መገልበጥ አለብን።
    //
    // የሂደቱ መካከለኛ ሁኔታ ሁሌም ሁለት ዓላማዎችን በሚያከናውን በ `hole` ይከታተላል-
    // 1. `is_less` ውስጥ panics ከ `v` ቅንነት ይጠብቃል.
    // 2. ረዥሙ ሩጫ መጀመሪያ ከወሰደ ቀሪውን ቀዳዳ በ `v` ውስጥ ይሞላል።
    //
    // የ Panic ደህንነት
    //
    // በሂደቱ ወቅት በማንኛውም ቦታ ላይ `is_less` panics ከሆነ `hole` ይወርዳል እና በ X0 `buf` ውስጥ ያልታሰበውን ክልል በ `v` ውስጥ ቀዳዳውን ይሞላል ፣ ስለሆነም `v` መጀመሪያ ላይ የያዛቸውን እቃዎች በሙሉ በትክክል አንዴ እንደያዘ ያረጋግጣል ፡፡
    //
    //
    //
    //
    //
    let mut hole;

    if mid <= len - mid {
        // የግራ ሩጫ አጭር ነው።
        unsafe {
            ptr::copy_nonoverlapping(v, buf, mid);
            hole = MergeHole { start: buf, end: buf.add(mid), dest: v };
        }

        // በመጀመሪያ እነዚህ ጠቋሚዎች የዝግጅቶቻቸውን ጅምር ያመለክታሉ ፡፡
        let left = &mut hole.start;
        let mut right = v_mid;
        let out = &mut hole.dest;

        while *left < hole.end && right < v_end {
            // አናሳውን ጎን ይበሉ።
            // እኩል ከሆነ መረጋጋትን ለመጠበቅ የግራውን ሩጫ ይመርጡ።
            unsafe {
                let to_copy = if is_less(&*right, &**left) {
                    get_and_increment(&mut right)
                } else {
                    get_and_increment(left)
                };
                ptr::copy_nonoverlapping(to_copy, get_and_increment(out), 1);
            }
        }
    } else {
        // ትክክለኛው ሩጫ አጭር ነው ፡፡
        unsafe {
            ptr::copy_nonoverlapping(v_mid, buf, len - mid);
            hole = MergeHole { start: buf, end: buf.add(len - mid), dest: v_mid };
        }

        // በመጀመሪያ እነዚህ ጠቋሚዎች የዝግጅቶቻቸውን ጫፎች ያልፋሉ ፡፡
        let left = &mut hole.dest;
        let right = &mut hole.end;
        let mut out = v_end;

        while v < *left && buf < *right {
            // ትልቁን ጎን ይበሉ ፡፡
            // እኩል ከሆነ መረጋጋትን ለማስጠበቅ ትክክለኛውን ሩጫ ይምረጡ።
            unsafe {
                let to_copy = if is_less(&*right.offset(-1), &*left.offset(-1)) {
                    decrement_and_get(left)
                } else {
                    decrement_and_get(right)
                };
                ptr::copy_nonoverlapping(to_copy, decrement_and_get(&mut out), 1);
            }
        }
    }
    // በመጨረሻም ፣ `hole` ይወርዳል።
    // አጭሩ ሩጫ ሙሉ በሙሉ ካልተጠቀመ ፣ የሚቀረው ማንኛውም ነገር አሁን በ `v` ውስጥ ወደ ቀዳዳው ይገለበጣል።

    unsafe fn get_and_increment<T>(ptr: &mut *mut T) -> *mut T {
        let old = *ptr;
        *ptr = unsafe { ptr.offset(1) };
        old
    }

    unsafe fn decrement_and_get<T>(ptr: &mut *mut T) -> *mut T {
        *ptr = unsafe { ptr.offset(-1) };
        *ptr
    }

    // ሲጣሉ ክልሉን `start..end` ን ወደ `dest..` ይቅዱ።
    struct MergeHole<T> {
        start: *mut T,
        end: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for MergeHole<T> {
        fn drop(&mut self) {
            // `T` ዜሮ-መጠን ዓይነት አይደለም ፣ ስለሆነም በመጠን መጠቀሙ ጥሩ ነው።
            let len = (self.end as usize - self.start as usize) / mem::size_of::<T>();
            unsafe {
                ptr::copy_nonoverlapping(self.start, self.dest, len);
            }
        }
    }
}

/// ይህ የውህደት ድርድር [here](http://svn.python.org/projects/python/trunk/Objects/listsort.txt) ን በዝርዝር ከተገለጸው የቲምሶርት አንዳንድ (ግን ሁሉንም አይደለም) ሀሳቦችን ያበድራል።
///
///
/// አልጎሪዝም በተፈጥሮ የሚወዳደሩ ተብለው የሚጠሩትን በጥብቅ የሚወርዱ እና የማይወረዱ ተከታይዎችን ይለያል ፡፡ገና ይዋሃዳሉ ወደ በመጠባበቅ ላይ ሩጫዎች ቁልል አለ.
/// እያንዳንዱ አዲስ የተገኘው ሩጫ በደረጃው ላይ ይጫናል ፣ ከዚያ የተወሰኑ ተጓዳኝ ሩጫዎች እነዚህ ሁለት የማይለወጡ እስኪረኩ ድረስ ተዋህደዋል-
///
/// 1. ለእያንዳንዱ `i` በ `1..runs.len()` ውስጥ `runs[i - 1].len > runs[i].len`
/// 2. ለእያንዳንዱ `i` በ `2..runs.len()` ውስጥ: `runs[i - 2].len > runs[i - 1].len + runs[i].len`
///
/// የማይለዋወጥ ሰዎች አጠቃላይ የሩጫ ጊዜ *O*(*n*\*log(* n*)) የከፋ ሁኔታ) መሆኑን ያረጋግጣሉ።
///
///
fn merge_sort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // እስከዚህ ርዝመት ድረስ ያሉት ቁርጥራጮች የማስገቢያ ዓይነትን በመጠቀም ይደረደራሉ ፡፡
    const MAX_INSERTION: usize = 20;
    // በጣም አጭር ሩጫዎች ቢያንስ ይህንን ብዙ አባሎችን ለመዘርጋት የማስገቢያ ዓይነትን በመጠቀም ይረዝማሉ ፡፡
    const MIN_RUN: usize = 10;

    // መደርደር በዜሮ መጠን ዓይነቶች ላይ ትርጉም ያለው ባህሪ የለውም ፡፡
    if size_of::<T>() == 0 {
        return;
    }

    let len = v.len();

    // አመዳደብን ለማስቀረት አጭር ድርድሮች በማስገባቱ ዓይነት በቦታው ይደረደራሉ ፡፡
    if len <= MAX_INSERTION {
        if len >= 2 {
            for i in (0..len - 1).rev() {
                insert_head(&mut v[i..], &mut is_less);
            }
        }
        return;
    }

    // እንደ ጭረት ማህደረ ትውስታ ለመጠቀም ቋት ይመድቡ።`is_less` panics ከሆነ በቅጂዎች ላይ የሚሰሩ ድራጎችን አደጋ ላይ ሳንጥል የ `v` ይዘቶች ጥልቀት የሌላቸው ቅጂዎችን በውስጣቸው ማቆየት እንድንችል ርዝመቱን 0 እንጠብቃለን ፡፡
    //
    // ሁለት የተደረደሩ ሩጫዎችን ሲያዋህዱ ይህ ቋት የአጫጭር ሩጫ ቅጅ ይይዛል ፣ ይህም ሁልጊዜ ቢበዛ `len / 2` ርዝመት ይኖረዋል።
    //
    let mut buf = Vec::with_capacity(len / 2);

    // በ `v` ውስጥ የተፈጥሮ ሩጫዎችን ለመለየት ፣ ወደ ኋላ እናልፋለን።
    // ያ እንደ እንግዳ ውሳኔ ሊመስል ይችላል ፣ ግን ብዙውን ጊዜ የሚቀላቀል እውነታ ወደ ተቃራኒው አቅጣጫ (forwards) የሚሄድ መሆኑን ያስቡ።
    // እንደ መመዘኛዎች ከሆነ ወደፊት ወደፊት መቀላቀል ወደኋላ ከመቀላቀል ትንሽ ፈጣን ነው ፡፡
    // ለማጠቃለል ፣ ወደኋላ በማቋረጥ ሩጫዎችን መለየት አፈፃፀሙን ያሻሽላል ፡፡
    let mut runs = vec![];
    let mut end = len;
    while end > 0 {
        // በሚቀጥለው የተፈጥሮ ሩጫ ያግኙ, እና በጥብቅ ሲወርድበትና ነው ከሆነ መቀልበስ.
        let mut start = end - 1;
        if start > 0 {
            start -= 1;
            unsafe {
                if is_less(v.get_unchecked(start + 1), v.get_unchecked(start)) {
                    while start > 0 && is_less(v.get_unchecked(start), v.get_unchecked(start - 1)) {
                        start -= 1;
                    }
                    v[start..end].reverse();
                } else {
                    while start > 0 && !is_less(v.get_unchecked(start), v.get_unchecked(start - 1))
                    {
                        start -= 1;
                    }
                }
            }
        }

        // በጣም አጭር ነው ከሆነ አሂድ ወደ አንዳንድ ተጨማሪ ክፍሎችን ያስገቡ.
        // በአጫጭር ቅደም ተከተሎች ላይ የመግቢያ ዓይነት ከመዋሃድ ይልቅ ፈጣን ነው ፣ ስለሆነም ይህ አፈፃፀምን በእጅጉ ያሻሽላል።
        while start > 0 && end - start < MIN_RUN {
            start -= 1;
            insert_head(&mut v[start..end], &mut is_less);
        }

        // ይህንን ሩጫ ወደ ቁልል ላይ ይግፉት ፡፡
        runs.push(Run { start, len: end - start });
        end = start;

        // የማይለዋወጡትን ለማርካት የተወሰኑ ተጓዳኝ ሩጫዎችን ያጣምሩ ፡፡
        while let Some(r) = collapse(&runs) {
            let left = runs[r + 1];
            let right = runs[r];
            unsafe {
                merge(
                    &mut v[left.start..right.start + right.len],
                    left.len,
                    buf.as_mut_ptr(),
                    &mut is_less,
                );
            }
            runs[r] = Run { start: left.start, len: left.len + right.len };
            runs.remove(r + 1);
        }
    }

    // በመጨረሻም በትክክል አንድ ሩጫ በቁጥቋጦው ውስጥ መቆየት አለበት።
    debug_assert!(runs.len() == 1 && runs[0].start == 0 && runs[0].len == len);

    // የሩጫዎችን ቁልል ይመረምራል እና ለመቀላቀል ቀጣዮቹን ሩጫዎች ይለያል።
    // ይበልጥ ግልጽ በሆነ ሁኔታ ፣ `Some(r)` ከተመለሰ ያ ማለት `runs[r]` እና `runs[r + 1]` ቀጥሎ መዋሃድ አለባቸው ማለት ነው።
    // የ ስልተ በምትኩ አዲስ አሂድ መገንባት መቀጠል አለበት ከሆነ, `None` ተመልሶ ነው.
    //
    // እዚህ እንደተገለጸው ቲምሶርት ለተጫጫቂ አተገባበሩ ዝነኛ ነው ፡፡
    // http://envisage-project.eu/timsort-specification-and-verification/
    //
    // የታሪኩ ፍሬ ነገር-በተደራራቢው ላይ ባሉት አራቱ ሩጫዎች ላይ የማይለወጡትን ማስገደድ አለብን ፡፡
    // በሦስቱ ላይ ብቻ እነሱን ማስገደድ የማይለዋወጥ ሰዎች አሁንም በክምችቱ ውስጥ *ለሁሉም* ሩጫ መያዛቸውን ለማረጋገጥ በቂ አይደለም።
    //
    // ይህ ተግባር ለአራቱ አራት ሩጫዎች የማይለዋወጡትን በትክክል ይፈትሻል ፡፡
    // በተጨማሪም ፣ ከፍተኛው ሩጫ በመረጃ ጠቋሚ 0 ላይ ከጀመረ ፣ ድርድሩ ሙሉ በሙሉ እስኪወድቅ ድረስ የውድድሩን ሥራ ሁልጊዜ ይጠይቃል ፣ ድርድሩን ለማጠናቀቅ ፡፡
    //
    //
    #[inline]
    fn collapse(runs: &[Run]) -> Option<usize> {
        let n = runs.len();
        if n >= 2
            && (runs[n - 1].start == 0
                || runs[n - 2].len <= runs[n - 1].len
                || (n >= 3 && runs[n - 3].len <= runs[n - 2].len + runs[n - 1].len)
                || (n >= 4 && runs[n - 4].len <= runs[n - 3].len + runs[n - 2].len))
        {
            if n >= 3 && runs[n - 3].len < runs[n - 1].len { Some(n - 3) } else { Some(n - 2) }
        } else {
            None
        }
    }

    #[derive(Clone, Copy)]
    struct Run {
        start: usize,
        len: usize,
    }
}