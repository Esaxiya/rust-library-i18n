//! Реалізація panics за допомогою розмотування стека
//!
//! Цей crate є реалізацією panics у Rust з використанням механізму розмотування стеку "most native" платформи, для якої він компілюється.
//! На даний момент це класифікується на три сегменти:
//!
//! 1. Цілі MSVC використовують SEH у файлі `seh.rs`.
//! 2. Emscripten використовує винятки C++ у файлі `emcc.rs`.
//! 3. Усі інші цілі використовують libunwind/libgcc у файлі `gcc.rs`.
//!
//! Більше документації про кожну реалізацію можна знайти у відповідному модулі.
//!
//!

#![no_std]
#![unstable(feature = "panic_unwind", issue = "32837")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/"
)]
#![feature(core_intrinsics)]
#![feature(int_bits_const)]
#![feature(lang_items)]
#![feature(nll)]
#![feature(panic_unwind)]
#![feature(staged_api)]
#![feature(std_internals)]
#![feature(unwind_attributes)]
#![feature(abi_thiscall)]
#![feature(rustc_attrs)]
#![feature(raw)]
#![panic_runtime]
#![feature(panic_runtime)]
// `real_imp` не використовується з Мірі, тому попередження про мовчання.
#![cfg_attr(miri, allow(dead_code))]

use alloc::boxed::Box;
use core::any::Any;
use core::panic::BoxMeUp;

cfg_if::cfg_if! {
    if #[cfg(target_os = "emscripten")] {
        #[path = "emcc.rs"]
        mod real_imp;
    } else if #[cfg(target_os = "hermit")] {
        #[path = "hermit.rs"]
        mod real_imp;
    } else if #[cfg(target_env = "msvc")] {
        #[path = "seh.rs"]
        mod real_imp;
    } else if #[cfg(any(
        all(target_family = "windows", target_env = "gnu"),
        target_os = "psp",
        target_family = "unix",
        all(target_vendor = "fortanix", target_env = "sgx"),
    ))] {
        // Об'єкти запуску середовища виконання Rust залежать від цих символів, тому зробіть їх загальнодоступними.
        #[cfg(all(target_os="windows", target_arch = "x86", target_env="gnu"))]
        pub use real_imp::eh_frame_registry::*;
        #[path = "gcc.rs"]
        mod real_imp;
    } else {
        // Цілі, які не підтримують розмотування.
        // - arch=wasm32
        // - os=немає (цілі "bare metal")
        // - os=uefi
        // - nvptx64-nvidia-cuda
        // - arch=avr
        #[path = "dummy.rs"]
        mod real_imp;
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        // Використовуйте середовище виконання Miri.
        // Нам все ще потрібно завантажити звичайний час виконання вище, оскільки rustc очікує, що звідти будуть визначені певні елементи lang.
        //
        #[path = "miri.rs"]
        mod imp;
    } else {
        // Використовуйте реальний час роботи.
        use real_imp as imp;
    }
}

extern "C" {
    /// Обробник у libstd викликається, коли об'єкт panic випадає за межі `catch_unwind`.
    ///
    fn __rust_drop_panic() -> !;

    /// Обробник у libstd викликається, коли виявляється іноземне виняток.
    fn __rust_foreign_exception() -> !;
}

mod dwarf;

#[rustc_std_internal_symbol]
#[allow(improper_ctypes_definitions)]
pub unsafe extern "C" fn __rust_panic_cleanup(payload: *mut u8) -> *mut (dyn Any + Send + 'static) {
    Box::into_raw(imp::cleanup(payload))
}

// Точка входу для створення винятку, лише делегує реалізацію для певної платформи.
//
#[rustc_std_internal_symbol]
#[unwind(allowed)]
pub unsafe extern "C" fn __rust_start_panic(payload: *mut &mut dyn BoxMeUp) -> u32 {
    let payload = Box::from_raw((*payload).take_box());

    imp::panic(payload)
}