//! Windows SEH
//!
//! На Windows (наразі лише на MSVC) механізмом обробки винятків за замовчуванням є Structured Exception Handling (SEH).
//! Це зовсім інше, ніж обробка винятків на основі Гномів (наприклад, те, що використовують інші платформи unix) з точки зору внутрішніх компонувальників, тому LLVM повинен мати значну кількість додаткової підтримки для SEH.
//!
//! У двох словах, що тут відбувається:
//!
//! 1. Функція `panic` викликає стандартну функцію Windows `_CxxThrowException` для створення винятку, подібного до C++ , що запускає процес розмотування.
//! 2.
//! Усі посадочні майданчики, створені компілятором, використовують функцію особистості `__CxxFrameHandler3`, функцію в ЕЛТ, а код розмотування в Windows буде використовувати цю функцію особистості для виконання всього коду очищення в стеку.
//!
//! 3. Усі згенеровані компілятором виклики до `invoke` мають посадочну площадку, встановлену як інструкцію L01V L01 XL, яка вказує на початок процедури очищення.
//! Особистість (на кроці 2, визначеному в ЕПТ) відповідає за виконання процедур очищення.
//! 4. Зрештою виконується код "catch" у внутрішній характеристиці `try` (генерований компілятором) і вказує на те, що керування повинно повернутися до Rust.
//! Це робиться за допомогою інструкції `catchswitch` плюс інструкції `catchpad` в термінах ІЧ LLVM, нарешті, повертаючи нормальний контроль програмі за допомогою інструкції `catchret`.
//!
//! Деякі конкретні відмінності від обробки винятків на основі gcc:
//!
//! * Rust не має власної функції особистості, замість цього *завжди*`__CxxFrameHandler3`.Крім того, додаткова фільтрація не виконується, тому ми в кінцевому підсумку вловлюємо будь-які винятки на C++ , які виглядають як ті, які ми кидаємо.
//! Зауважте, що додавання винятку до Rust у будь-якому випадку є невизначеною поведінкою, тому це повинно бути нормально.
//! * У нас є деякі дані для передачі через межу розмотування, зокрема `Box<dyn Any + Send>`.Як і у випадку з винятками Гномів, ці два покажчики зберігаються як корисне навантаження в самому винятку.
//! Однак у MSVC немає необхідності в додатковому розподілі купи, оскільки стек викликів зберігається під час виконання функцій фільтра.
//! Це означає, що покажчики передаються безпосередньо в `_CxxThrowException`, які потім відновлюються у функції фільтра, щоб записати їх у фрейм стека власного `try`.
//!
//! [win64]: https://docs.microsoft.com/en-us/cpp/build/exception-handling-x64
//! [llvm]: http://llvm.org/docs/ExceptionHandling.html#background-on-windows-exceptions
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(nonstandard_style)]

use alloc::boxed::Box;
use core::any::Any;
use core::mem::{self, ManuallyDrop};
use libc::{c_int, c_uint, c_void};

struct Exception {
    // Це має бути Опцією, оскільки ми вловлюємо виняток за посиланням, а його деструктор виконується середовищем виконання C++ .
    // Коли ми виймаємо Box з винятку, нам потрібно залишити виняток у допустимому стані, щоб його деструктор працював без подвійного скидання Box.
    //
    //
    data: Option<Box<dyn Any + Send>>,
}

// По-перше, ціла купа визначень типів.Тут є кілька дивовижностей для певної платформи, і багато, що просто відверто скопійовано з LLVM.Завданням усього цього є реалізація функції `panic` нижче через виклик до `_CxxThrowException`.
//
// Ця функція приймає два аргументи.Перший-це вказівник на дані, які ми передаємо, а в даному випадку це наш об`єкт Portrait.Досить легко знайти!Наступне, однак, складніше.
// Це вказівник на структуру `_ThrowInfo`, і він, як правило, призначений просто для опису викиду, що виникає.
//
// В даний час визначення цього типу [1] трохи волохате, і головна дивина (і відмінність від Інтернет-статті) полягає в тому, що на 32-бітних покажчики є покажчиками, а на 64-бітних покажчики виражаються як 32-бітні зміщення від `__ImageBase` символ.
//
// Для вираження цього використовуються макроси `ptr_t` та `ptr!` у наведених нижче модулях.
//
// Лабіринт визначень типів також уважно стежить за тим, що LLVM випромінює для такого роду операцій.Наприклад, якщо ви скомпілюєте цей код C++ на MSVC і випустите LLVM IR:
//
//      #include <stdint.h>
//
//      struct rust_panic {
//          rust_panic(const rust_panic&);
//          ~rust_panic();
//
//          uint64_t x[2];};
//
//      порожнеча foo() { rust_panic a = {0, 1};
//          кинути a;}
//
// По суті, це те, що ми намагаємось наслідувати.Більшість значень констант нижче були просто скопійовані з LLVM,
//
// У будь-якому випадку, всі ці структури побудовані однаково, і для нас це просто дещо багатослівно.
//
// [1]: http://www.geoffchappell.com/studies/msvc/language/predefined/
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

#[cfg(target_arch = "x86")]
#[macro_use]
mod imp {
    pub type ptr_t = *mut u8;

    macro_rules! ptr {
        (0) => {
            core::ptr::null_mut()
        };
        ($e:expr) => {
            $e as *mut u8
        };
    }
}

#[cfg(not(target_arch = "x86"))]
#[macro_use]
mod imp {
    pub type ptr_t = u32;

    extern "C" {
        pub static __ImageBase: u8;
    }

    macro_rules! ptr {
        (0) => (0);
        ($e:expr) => {
            (($e as usize) - (&imp::__ImageBase as *const _ as usize)) as u32
        }
    }
}

#[repr(C)]
pub struct _ThrowInfo {
    pub attributes: c_uint,
    pub pmfnUnwind: imp::ptr_t,
    pub pForwardCompat: imp::ptr_t,
    pub pCatchableTypeArray: imp::ptr_t,
}

#[repr(C)]
pub struct _CatchableTypeArray {
    pub nCatchableTypes: c_int,
    pub arrayOfCatchableTypes: [imp::ptr_t; 1],
}

#[repr(C)]
pub struct _CatchableType {
    pub properties: c_uint,
    pub pType: imp::ptr_t,
    pub thisDisplacement: _PMD,
    pub sizeOrOffset: c_int,
    pub copyFunction: imp::ptr_t,
}

#[repr(C)]
pub struct _PMD {
    pub mdisp: c_int,
    pub pdisp: c_int,
    pub vdisp: c_int,
}

#[repr(C)]
pub struct _TypeDescriptor {
    pub pVFTable: *const u8,
    pub spare: *mut u8,
    pub name: [u8; 11],
}

// Зауважте, що ми навмисно ігноруємо правила керування іменами тут: ми не хочемо, щоб C++ міг ловити Rust panics, просто оголосивши `struct rust_panic`.
//
//
// Під час модифікації переконайтесь, що рядок імені типу точно відповідає тому, що використовується в `compiler/rustc_codegen_llvm/src/intrinsic.rs`.
//
const TYPE_NAME: [u8; 11] = *b"rust_panic\0";

static mut THROW_INFO: _ThrowInfo = _ThrowInfo {
    attributes: 0,
    pmfnUnwind: ptr!(0),
    pForwardCompat: ptr!(0),
    pCatchableTypeArray: ptr!(0),
};

static mut CATCHABLE_TYPE_ARRAY: _CatchableTypeArray =
    _CatchableTypeArray { nCatchableTypes: 1, arrayOfCatchableTypes: [ptr!(0)] };

static mut CATCHABLE_TYPE: _CatchableType = _CatchableType {
    properties: 0,
    pType: ptr!(0),
    thisDisplacement: _PMD { mdisp: 0, pdisp: -1, vdisp: 0 },
    sizeOrOffset: mem::size_of::<Exception>() as c_int,
    copyFunction: ptr!(0),
};

extern "C" {
    // Провідний байт `\x01` тут насправді є магічним сигналом до LLVM, щоб *не* застосовувати будь-які інші маніпуляції, такі як префікс із символом `_`.
    //
    //
    // Цей символ є vtable, що використовується `std::type_info` C++ .
    // Об'єкти типу `std::type_info`, дескриптори типу, мають вказівник на цю таблицю.
    // На дескриптори типів посилаються структури C++ EH, визначені вище, і які ми будуємо нижче.
    //
    #[link_name = "\x01??_7type_info@@6B@"]
    static TYPE_INFO_VTABLE: *const u8;
}

// Цей дескриптор типу використовується лише під час створення винятку.
// Частина лову обробляється внутрішньою функцією try, яка генерує власний TypeDescriptor.
//
// Це нормально, оскільки час виконання MSVC використовує порівняння рядків назви типу, щоб відповідати TypeDescriptors, а не рівності вказівника.
//
static mut TYPE_DESCRIPTOR: _TypeDescriptor = _TypeDescriptor {
    pVFTable: unsafe { &TYPE_INFO_VTABLE } as *const _ as *const _,
    spare: core::ptr::null_mut(),
    name: TYPE_NAME,
};

// Деструктор, який використовується, якщо код C++ вирішує захопити виняток і видалити його, не поширюючи.
// Частина catch елемента try intrinsic встановить для першого слова об`єкта виключення значення 0 так, щоб його пропустив деструктор.
//
// Зверніть увагу, що x86 Windows використовує конвенцію про виклики "thiscall" для функцій члена C++ замість конвенції про виклики "C" за замовчуванням.
//
// Функція exception_copy тут трохи особлива: вона викликається середовищем виконання MSVC під блоком try/catch, і panic, який ми генеруємо тут, буде використаний як результат копіювання винятків.
//
// Це використовується середовищем виконання C++ для підтримки захоплення винятків з std::exception_ptr, які ми не можемо підтримати, оскільки Box<dyn Any>не можна клонувати.
//
//
//
//
//
macro_rules! define_cleanup {
    ($abi:tt) => {
        unsafe extern $abi fn exception_cleanup(e: *mut Exception) {
            if let Exception { data: Some(b) } = e.read() {
                drop(b);
                super::__rust_drop_panic();
            }
        }
        #[unwind(allowed)]
        unsafe extern $abi fn exception_copy(_dest: *mut Exception,
                                             _src: *mut Exception)
                                             -> *mut Exception {
            panic!("Rust panics cannot be copied");
        }
    }
}
cfg_if::cfg_if! {
   if #[cfg(target_arch = "x86")] {
       define_cleanup!("thiscall");
   } else {
       define_cleanup!("C");
   }
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    use core::intrinsics::atomic_store;

    // _CxxThrowException повністю виконується на цьому фреймі стека, тому немає необхідності переносити `data` у купу.
    // Ми просто передаємо покажчик стека на цю функцію.
    //
    // Тут потрібен ManuallyDrop, оскільки ми не хочемо, щоб виняток скидався під час розмотування.
    // Натомість він буде скинутий з izuzetka_cleanup, який викликається середовищем виконання C++ .
    //
    //
    let mut exception = ManuallyDrop::new(Exception { data: Some(data) });
    let throw_ptr = &mut exception as *mut _ as *mut _;

    // Це ... може здатися дивним, і це цілком виправдано.На 32-розрядному MSVC покажчики між цією структурою є саме такими, покажчиками.
    // Однак на 64-розрядному MSVC покажчики між структурами швидше виражаються як 32-розрядні зсуви від `__ImageBase`.
    //
    // Отже, на 32-розрядному MSVC ми можемо оголосити всі ці вказівники в `static` вище.
    // На 64-розрядному MSVC нам довелося б виразити віднімання покажчиків у статиці, що Rust наразі не дозволяє, тому насправді ми не можемо цього зробити.
    //
    // Тоді наступне найкраще-це заповнення цих структур під час виконання (і без того паніка вже є "slow path").
    // Отже, тут ми переосмислюємо всі ці поля покажчиків як 32-розрядні цілі числа, а потім зберігаємо в них відповідне значення (атомарно, як це може відбуватися одночасно panics).
    //
    // Технічно час виконання, ймовірно, буде робити неатомне зчитування цих полів, але теоретично вони ніколи не читають значення *неправильно*, тому це не повинно бути дуже погано ...
    //
    // У будь-якому випадку, нам в основному потрібно робити щось подібне, поки ми не зможемо висловити більше операцій у статиці (і ми можемо ніколи не змогти).
    //
    //
    //
    //
    //
    //
    //
    //
    atomic_store(&mut THROW_INFO.pmfnUnwind as *mut _ as *mut u32, ptr!(exception_cleanup) as u32);
    atomic_store(
        &mut THROW_INFO.pCatchableTypeArray as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE_ARRAY as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE_ARRAY.arrayOfCatchableTypes[0] as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.pType as *mut _ as *mut u32,
        ptr!(&TYPE_DESCRIPTOR as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.copyFunction as *mut _ as *mut u32,
        ptr!(exception_copy) as u32,
    );

    extern "system" {
        #[unwind(allowed)]
        fn _CxxThrowException(pExceptionObject: *mut c_void, pThrowInfo: *mut u8) -> !;
    }

    _CxxThrowException(throw_ptr, &mut THROW_INFO as *mut _ as *mut _);
}

pub unsafe fn cleanup(payload: *mut u8) -> Box<dyn Any + Send> {
    // НУЛЕВО корисне навантаження тут означає, що ми потрапили сюди з улову (...) __rust_try.
    // Це трапляється, коли вловлюється виняток, який не є Rust.
    if payload.is_null() {
        super::__rust_foreign_exception();
    } else {
        let exception = &mut *(payload as *mut Exception);
        exception.data.take().unwrap()
    }
}

// Це вимагає компілятор для існування (наприклад, це елемент lang), але насправді він ніколи не викликається компілятором, оскільки __C_specific_handler або _except_handler3-це функція особистості, яка використовується завжди.
//
// Отже, це лише невдалий заглушка.
//
#[lang = "eh_personality"]
#[cfg(not(test))]
fn rust_eh_personality() {
    core::intrinsics::abort()
}