//! Розмотування panics для Мірі.
use alloc::boxed::Box;
use core::any::Any;

// Тип корисного навантаження, яке двигун Miri поширює, розмотуючи для нас.
// Має бути розміром вказівника.
type Payload = Box<Box<dyn Any + Send>>;

extern "Rust" {
    /// Надана Мірі зовнішня функція для початку розмотування.
    fn miri_start_panic(payload: *mut u8) -> !;
}

pub unsafe fn panic(payload: Box<dyn Any + Send>) -> u32 {
    // Корисне навантаження, яке ми передаємо `miri_start_panic`, буде саме тим аргументом, який ми отримуємо в `cleanup` нижче.
    // Отже, ми просто вкладаємо його один раз, щоб отримати щось розміром із покажчик.
    let payload_box: Payload = Box::new(payload);
    miri_start_panic(Box::into_raw(payload_box) as *mut u8)
}

pub unsafe fn cleanup(payload_box: *mut u8) -> Box<dyn Any + Send> {
    // Відновіть базовий `Box`.
    let payload_box: Payload = Box::from_raw(payload_box as *mut _);
    *payload_box
}