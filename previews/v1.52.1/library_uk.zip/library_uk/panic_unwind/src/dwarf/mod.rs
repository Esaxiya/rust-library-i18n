//! Службові програми для аналізу потоків даних, кодованих DWARF.
//! Див. Стандарт <http://www.dwarfstd.org>, DWARF-4, розділ 7, "Data Representation"
//!

// Цей модуль наразі використовується лише x86_64-pc-windows-gnu, але ми збираємо його всюди, щоб уникнути регресій.
//
#![allow(unused)]

#[cfg(test)]
mod tests;

pub mod eh;

use core::mem;

pub struct DwarfReader {
    pub ptr: *const u8,
}

#[repr(C, packed)]
struct Unaligned<T>(T);

impl DwarfReader {
    pub fn new(ptr: *const u8) -> DwarfReader {
        DwarfReader { ptr }
    }

    // Потоки DWARF упаковані, тому, наприклад, u32 не обов'язково буде вирівняний на 4-байтовій межі.
    // Це може спричинити проблеми на платформах із суворими вимогами до вирівнювання.
    // Обертаючи дані у структуру "packed", ми просимо серверну систему створити код "misalignment-safe".
    //
    pub unsafe fn read<T: Copy>(&mut self) -> T {
        let Unaligned(result) = *(self.ptr as *const Unaligned<T>);
        self.ptr = self.ptr.add(mem::size_of::<T>());
        result
    }

    // Кодування ULEB128 та SLEB128 визначено в Розділі 7.6, "Variable Length Data".
    //
    pub unsafe fn read_uleb128(&mut self) -> u64 {
        let mut shift: usize = 0;
        let mut result: u64 = 0;
        let mut byte: u8;
        loop {
            byte = self.read::<u8>();
            result |= ((byte & 0x7F) as u64) << shift;
            shift += 7;
            if byte & 0x80 == 0 {
                break;
            }
        }
        result
    }

    pub unsafe fn read_sleb128(&mut self) -> i64 {
        let mut shift: u32 = 0;
        let mut result: u64 = 0;
        let mut byte: u8;
        loop {
            byte = self.read::<u8>();
            result |= ((byte & 0x7F) as u64) << shift;
            shift += 7;
            if byte & 0x80 == 0 {
                break;
            }
        }
        // sign-extend
        if shift < u64::BITS && (byte & 0x40) != 0 {
            result |= (!0 as u64) << shift;
        }
        result as i64
    }
}