# `rustc-std-workspace-core` crate

Цей crate-це простий і порожній crate, який просто залежить від `libcore` і реекспортує весь його вміст.
crate-суть розширення можливостей стандартної бібліотеки залежати від crates від crates.io

Crates на crates.io, від якого залежить стандартна бібліотека, повинен залежати від `rustc-std-workspace-core` crate від crates.io, який порожній.

Ми використовуємо `[patch]`, щоб замінити його на цей crate у цьому сховищі.
Як результат, crates на crates.io створить залежність edge до `libcore`, версію, визначену в цьому сховищі.
Це повинно намалювати всі краї залежностей, щоб Cargo успішно будував crates!

Зверніть увагу, що crates на crates.io повинен залежати від цього crate з назвою `core`, щоб все працювало коректно.Для цього вони можуть використовувати:

```toml
core = { version = "1.0.0", optional = true, package = 'rustc-std-workspace-core' }
```

Завдяки використанню клавіші `package` crate перейменовано на `core`, тобто це буде виглядати як

```
--extern core=.../librustc_std_workspace_core-XXXXXXX.rlib
```

коли Cargo викликає компілятор, задовольняючи неявну директиву `extern crate core`, введену компілятором.




