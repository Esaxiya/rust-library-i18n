use core::intrinsics::discriminant_value;
use core::ops::ControlFlow;

#[test]
fn control_flow_discriminants_match_result() {
    // Це не стабільна площа поверхні, але допомагає утримати `?` дешевим між ними, навіть якщо LLVM не завжди може цим скористатися.
    //
    // (На жаль, результат та параметри несумісні, тому ControlFlow не може збігатися з обома.)

    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Break(3)),
        discriminant_value(&Result::<i32, i32>::Err(3)),
    );
    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Continue(3)),
        discriminant_value(&Result::<i32, i32>::Ok(3)),
    );
}