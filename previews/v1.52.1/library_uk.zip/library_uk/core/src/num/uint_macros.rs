macro_rules! uint_impl {
    ($SelfT:ty, $ActualT:ty, $BITS:expr, $MaxV:expr,
        $rot:expr, $rot_op:expr, $rot_result:expr, $swap_op:expr, $swapped:expr,
        $reversed:expr, $le_bytes:expr, $be_bytes:expr,
        $to_xe_bytes_doc:expr, $from_xe_bytes_doc:expr) => {
        /// Найменше значення, яке може бути представлене цим цілим числом.
        ///
        /// # Examples
        ///
        /// Основне використання:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN, 0);")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MIN: Self = 0;

        /// Найбільше значення, яке може бути представлене цим цілим числом.
        ///
        /// # Examples
        ///
        /// Основне використання:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX, ", stringify!($MaxV), ");")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MAX: Self = !0;

        /// Розмір цього цілого числа у бітах.
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(int_bits_const)]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::BITS, ", stringify!($BITS), ");")]
        /// ```
        #[unstable(feature = "int_bits_const", issue = "76904")]
        pub const BITS: u32 = $BITS;

        /// Перетворює фрагмент рядка в заданій основі в ціле число.
        ///
        /// Очікується, що рядок є необов`язковим знаком `+`, за яким слід цифри.
        ///
        /// Пробіли, що ведуть і відстають, являють собою помилку.
        /// Залежно від `radix` цифри є підмножиною цих символів:
        ///
        /// * `0-9`
        /// * `a-z`
        /// * `A-Z`
        ///
        /// # Panics
        ///
        /// Ця функція panics, якщо `radix` не знаходиться в діапазоні від 2 до 36.
        ///
        /// # Examples
        ///
        /// Основне використання:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::from_str_radix(\"A\", 16), Ok(10));")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        pub fn from_str_radix(src: &str, radix: u32) -> Result<Self, ParseIntError> {
            from_str_radix(src, radix)
        }

        /// Повертає кількість одиниць у двійковому поданні `self`.
        ///
        /// # Examples
        ///
        /// Основне використання:
        ///
        /// ```
        #[doc = concat!("let n = 0b01001100", stringify!($SelfT), ";")]
        /// assert_eq!(n.count_ones(), 3);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[doc(alias = "popcount")]
        #[doc(alias = "popcnt")]
        #[inline]
        pub const fn count_ones(self) -> u32 {
            intrinsics::ctpop(self as $ActualT) as u32
        }

        /// Повертає кількість нулів у двійковому поданні `self`.
        ///
        /// # Examples
        ///
        /// Основне використання:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.count_zeros(), 0);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn count_zeros(self) -> u32 {
            (!self).count_ones()
        }

        /// Повертає кількість провідних нулів у двійковому поданні `self`.
        ///
        /// # Examples
        ///
        /// Основне використання:
        ///
        /// ```
        #[doc = concat!("let n = ", stringify!($SelfT), "::MAX >> 2;")]
        /// assert_eq!(n.leading_zeros(), 2);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn leading_zeros(self) -> u32 {
            intrinsics::ctlz(self as $ActualT) as u32
        }

        /// Повертає кількість кінцевих нулів у двійковому поданні `self`.
        ///
        ///
        /// # Examples
        ///
        /// Основне використання:
        ///
        /// ```
        #[doc = concat!("let n = 0b0101000", stringify!($SelfT), ";")]
        /// assert_eq!(n.trailing_zeros(), 3);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn trailing_zeros(self) -> u32 {
            intrinsics::cttz(self) as u32
        }

        /// Повертає кількість провідних у двійковому поданні `self`.
        ///
        /// # Examples
        ///
        /// Основне використання:
        ///
        /// ```
        #[doc = concat!("let n = !(", stringify!($SelfT), "::MAX >> 2);")]
        /// assert_eq!(n.leading_ones(), 2);
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[inline]
        pub const fn leading_ones(self) -> u32 {
            (!self).leading_zeros()
        }

        /// Повертає кількість кінцевих у двійковому поданні `self`.
        ///
        ///
        /// # Examples
        ///
        /// Основне використання:
        ///
        /// ```
        #[doc = concat!("let n = 0b1010111", stringify!($SelfT), ";")]
        /// assert_eq!(n.trailing_ones(), 3);
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[inline]
        pub const fn trailing_ones(self) -> u32 {
            (!self).trailing_zeros()
        }

        /// Зміщує біти вліво на вказану величину, `n`, обертаючи усічені біти до кінця цілого числа, що утворюється.
        ///
        ///
        /// Зверніть увагу, це не та сама операція, що і оператор перемикання `<<`!
        ///
        /// # Examples
        ///
        /// Основне використання:
        ///
        /// ```
        #[doc = concat!("let n = ", $rot_op, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_result, ";")]

        #[doc = concat!("assert_eq!(n.rotate_left(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn rotate_left(self, n: u32) -> Self {
            intrinsics::rotate_left(self, n as $SelfT)
        }

        /// Зміщує біти вправо на вказану величину, `n`, переносячи усічені біти на початок результуючого цілого числа.
        ///
        ///
        /// Зверніть увагу, це не та сама операція, що і оператор перемикання `>>`!
        ///
        /// # Examples
        ///
        /// Основне використання:
        ///
        /// ```
        ///
        #[doc = concat!("let n = ", $rot_result, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_op, ";")]

        #[doc = concat!("assert_eq!(n.rotate_right(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn rotate_right(self, n: u32) -> Self {
            intrinsics::rotate_right(self, n as $SelfT)
        }

        /// Змінює порядок байтів цілого числа.
        ///
        /// # Examples
        ///
        /// Основне використання:
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// нехай m= n.swap_bytes();
        ///
        #[doc = concat!("assert_eq!(m, ", $swapped, ");")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn swap_bytes(self) -> Self {
            intrinsics::bswap(self as $ActualT) as Self
        }

        /// Змінює порядок бітів у цілому числу.
        /// Найменш значущий біт стає найбільш значущим бітом, другий найменш значущий біт стає другим найбільш значущим бітом тощо.
        ///
        /// # Examples
        ///
        /// Основне використання:
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// нехай m= n.reverse_bits();
        ///
        #[doc = concat!("assert_eq!(m, ", $reversed, ");")]
        #[doc = concat!("assert_eq!(0, 0", stringify!($SelfT), ".reverse_bits());")]
        /// ```
        #[stable(feature = "reverse_bits", since = "1.37.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        #[must_use]
        pub const fn reverse_bits(self) -> Self {
            intrinsics::bitreverse(self as $ActualT) as Self
        }

        /// Перетворює ціле число з великого ендіана в ендіанс цілі.
        ///
        /// На великому ендіані це не-операція.
        /// На маленькому ендіані байти поміняні місцями.
        ///
        /// # Examples
        ///
        /// Основне використання:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// якщо cfg! (target_endian= "big"){
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n)")]
        /// } ще {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn from_be(x: Self) -> Self {
            #[cfg(target_endian = "big")]
            {
                x
            }
            #[cfg(not(target_endian = "big"))]
            {
                x.swap_bytes()
            }
        }

        /// Перетворює ціле число з малого ендіана в ендіанс цілі.
        ///
        /// Щодо маленького ендіана, це не-операція.
        /// На великому ендіані байти поміняні місцями.
        ///
        /// # Examples
        ///
        /// Основне використання:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// якщо cfg! (target_endian= "little"){
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n)")]
        /// } ще {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn from_le(x: Self) -> Self {
            #[cfg(target_endian = "little")]
            {
                x
            }
            #[cfg(not(target_endian = "little"))]
            {
                x.swap_bytes()
            }
        }

        /// Перетворює `self` на великий ендіан з ендіансу цілі.
        ///
        /// На великому ендіані це не-операція.
        /// На маленькому ендіані байти поміняні місцями.
        ///
        /// # Examples
        ///
        /// Основне використання:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// якщо cfg! (target_endian= "big"){
        ///     assert_eq!(n.to_be(), n)
        /// } ще { assert_eq!(n.to_be(), n.swap_bytes()) }
        ///
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn to_be(self) -> Self { // чи не бути?
            #[cfg(target_endian = "big")]
            {
                self
            }
            #[cfg(not(target_endian = "big"))]
            {
                self.swap_bytes()
            }
        }

        /// Перетворює `self` на малий ендіан з ендіансу цілі.
        ///
        /// Щодо маленького ендіана, це не-операція.
        /// На великому ендіані байти поміняні місцями.
        ///
        /// # Examples
        ///
        /// Основне використання:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// якщо cfg! (target_endian= "little"){
        ///     assert_eq!(n.to_le(), n)
        /// } ще { assert_eq!(n.to_le(), n.swap_bytes()) }
        ///
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn to_le(self) -> Self {
            #[cfg(target_endian = "little")]
            {
                self
            }
            #[cfg(not(target_endian = "little"))]
            {
                self.swap_bytes()
            }
        }

        /// Перевірено додавання цілих чисел.
        /// Обчислює `self + rhs`, повертаючи `None`, якщо сталося переповнення.
        ///
        /// # Examples
        ///
        /// Основне використання:
        ///
        /// ```
        #[doc = concat!(
            "assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(1), ",
            "Some(", stringify!($SelfT), "::MAX - 1));"
        )]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(3), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_add(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_add(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Незмічене додавання цілих чисел.Обчислює `self + rhs`, припускаючи, що переповнення не може відбутися.
        /// Це призводить до невизначеної поведінки, коли
        #[doc = concat!("`self + rhs > ", stringify!($SelfT), "::MAX` or `self + rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_add(self, rhs: Self) -> Self {
            // БЕЗПЕКА: абонент повинен виконувати контракт про безпеку для `unchecked_add`.
            //
            unsafe { intrinsics::unchecked_add(self, rhs) }
        }

        /// Перевірено ціле віднімання.
        /// Обчислює `self - rhs`, повертаючи `None`, якщо сталося переповнення.
        ///
        /// # Examples
        ///
        /// Основне використання:
        ///
        /// ```
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_sub(1), Some(0));")]
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".checked_sub(1), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_sub(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_sub(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Невизначене ціле віднімання.Обчислює `self - rhs`, припускаючи, що переповнення не може відбутися.
        /// Це призводить до невизначеної поведінки, коли
        #[doc = concat!("`self - rhs > ", stringify!($SelfT), "::MAX` or `self - rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_sub(self, rhs: Self) -> Self {
            // БЕЗПЕКА: абонент повинен виконувати контракт про безпеку для `unchecked_sub`.
            //
            unsafe { intrinsics::unchecked_sub(self, rhs) }
        }

        /// Перевірене ціле множення.
        /// Обчислює `self * rhs`, повертаючи `None`, якщо сталося переповнення.
        ///
        /// # Examples
        ///
        /// Основне використання:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_mul(1), Some(5));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_mul(2), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_mul(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_mul(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Неперевірене ціле множення.Обчислює `self * rhs`, припускаючи, що переповнення не може відбутися.
        /// Це призводить до невизначеної поведінки, коли
        #[doc = concat!("`self * rhs > ", stringify!($SelfT), "::MAX` or `self * rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_mul(self, rhs: Self) -> Self {
            // БЕЗПЕКА: абонент повинен виконувати контракт про безпеку для `unchecked_mul`.
            //
            unsafe { intrinsics::unchecked_mul(self, rhs) }
        }

        /// Перевірено цілочисельне ділення.
        /// Обчислює `self / rhs`, повертаючи `None`, якщо `rhs == 0`.
        ///
        /// # Examples
        ///
        /// Основне використання:
        ///
        /// ```
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".checked_div(2), Some(64));")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_div(0), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                // БЕЗПЕКА: div за нулем перевірено вище, а типи без підпису не мають інших
                // режими відмов для поділу
                Some(unsafe { intrinsics::unchecked_div(self, rhs) })
            }
        }

        /// Перевірено евклідове ділення.
        /// Обчислює `self.div_euclid(rhs)`, повертаючи `None`, якщо `rhs == 0`.
        ///
        /// # Examples
        ///
        /// Основне використання:
        ///
        /// ```
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".checked_div_euclid(2), Some(64));")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_div_euclid(0), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                Some(self.div_euclid(rhs))
            }
        }


        /// Перевірено цілочисельний залишок.
        /// Обчислює `self % rhs`, повертаючи `None`, якщо `rhs == 0`.
        ///
        /// # Examples
        ///
        /// Основне використання:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(0), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                // БЕЗПЕКА: div за нулем перевірено вище, а типи без підпису не мають інших
                // режими відмов для поділу
                Some(unsafe { intrinsics::unchecked_rem(self, rhs) })
            }
        }

        /// Перевірено за евклідовим модулем.
        /// Обчислює `self.rem_euclid(rhs)`, повертаючи `None`, якщо `rhs == 0`.
        ///
        /// # Examples
        ///
        /// Основне використання:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(0), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                Some(self.rem_euclid(rhs))
            }
        }

        /// Перевірене заперечення.Обчислює `-self`, повертаючи `None`, якщо `self==
        /// 0`.
        ///
        /// Зауважте, що заперечення будь-якого натурального числа переповнюється.
        ///
        /// # Examples
        ///
        /// Основне використання:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".checked_neg(), Some(0));")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_neg(), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn checked_neg(self) -> Option<Self> {
            let (a, b) = self.overflowing_neg();
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Перевірено зміну ліворуч.
        /// Обчислює `self << rhs`, повертаючи `None`, якщо `rhs` більше або дорівнює кількості бітів у `self`.
        ///
        /// # Examples
        ///
        /// Основне використання:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".checked_shl(4), Some(0x10));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shl(129), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shl(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shl(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Перевірено зміну праворуч.
        /// Обчислює `self >> rhs`, повертаючи `None`, якщо `rhs` більше або дорівнює кількості бітів у `self`.
        ///
        /// # Examples
        ///
        /// Основне використання:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(4), Some(0x1));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(129), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shr(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shr(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Перевірена степеня.
        /// Обчислює `self.pow(exp)`, повертаючи `None`, якщо сталося переповнення.
        ///
        /// # Examples
        ///
        /// Основне використання:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".checked_pow(5), Some(32));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_pow(2), None);")]
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_pow(self, mut exp: u32) -> Option<Self> {
            if exp == 0 {
                return Some(1);
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = try_opt!(acc.checked_mul(base));
                }
                exp /= 2;
                base = try_opt!(base.checked_mul(base));
            }

            // оскільки exp!=0, нарешті exp повинен бути 1.
            // Опрацьовуйте остаточний біт експоненти окремо, оскільки квадратування основи після цього не є необхідним і може спричинити непотрібне переповнення.
            //
            //

            Some(try_opt!(acc.checked_mul(base)))
        }

        /// Насичуюче ціле додавання.
        /// Обчислює `self + rhs`, насичуючи числові межі замість переповнення.
        ///
        /// # Examples
        ///
        /// Основне використання:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_add(1), 101);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_add(127), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn saturating_add(self, rhs: Self) -> Self {
            intrinsics::saturating_add(self, rhs)
        }

        /// Насичуюче ціле віднімання.
        /// Обчислює `self - rhs`, насичуючи числові межі замість переповнення.
        ///
        /// # Examples
        ///
        /// Основне використання:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_sub(27), 73);")]
        #[doc = concat!("assert_eq!(13", stringify!($SelfT), ".saturating_sub(127), 0);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn saturating_sub(self, rhs: Self) -> Self {
            intrinsics::saturating_sub(self, rhs)
        }

        /// Насичуюче ціле множення.
        /// Обчислює `self * rhs`, насичуючи числові межі замість переповнення.
        ///
        /// # Examples
        ///
        /// Основне використання:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".saturating_mul(10), 20);")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX).saturating_mul(10), ", stringify!($SelfT),"::MAX);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_mul(self, rhs: Self) -> Self {
            match self.checked_mul(rhs) {
                Some(x) => x,
                None => Self::MAX,
            }
        }

        /// Насичувальне цілочисельне піднесення до ступеня.
        /// Обчислює `self.pow(exp)`, насичуючи числові межі замість переповнення.
        ///
        /// # Examples
        ///
        /// Основне використання:
        ///
        /// ```
        #[doc = concat!("assert_eq!(4", stringify!($SelfT), ".saturating_pow(3), 64);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_pow(2), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_pow(self, exp: u32) -> Self {
            match self.checked_pow(exp) {
                Some(x) => x,
                None => Self::MAX,
            }
        }

        /// Обгортання (modular) доповнення.
        /// Обчислює `self + rhs`, обертаючись на межі типу.
        ///
        /// # Examples
        ///
        /// Основне використання:
        ///
        /// ```
        #[doc = concat!("assert_eq!(200", stringify!($SelfT), ".wrapping_add(55), 255);")]
        #[doc = concat!("assert_eq!(200", stringify!($SelfT), ".wrapping_add(", stringify!($SelfT), "::MAX), 199);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_add(self, rhs: Self) -> Self {
            intrinsics::wrapping_add(self, rhs)
        }

        /// Обернення віднімання (modular).
        /// Обчислює `self - rhs`, обертаючись на межі типу.
        ///
        /// # Examples
        ///
        /// Основне використання:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_sub(100), 0);")]
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_sub(", stringify!($SelfT), "::MAX), 101);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_sub(self, rhs: Self) -> Self {
            intrinsics::wrapping_sub(self, rhs)
        }

        /// Обгортання множення (modular).
        /// Обчислює `self * rhs`, обертаючись на межі типу.
        ///
        /// # Examples
        ///
        /// Основне використання:
        ///
        /// Зверніть увагу, що цей приклад ділиться між цілими типами.
        /// Що пояснює, чому тут використовується `u8`.
        ///
        /// ```
        /// assert_eq!(10u8.wrapping_mul(12), 120);
        /// assert_eq!(25u8.wrapping_mul(12), 44);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
        #[inline]
        pub const fn wrapping_mul(self, rhs: Self) -> Self {
            intrinsics::wrapping_mul(self, rhs)
        }

        /// Обгортання поділу (modular).Обчислює `self / rhs`.
        /// Обернене ділення на непідписані типи-це звичайне ділення.
        /// Немає жодного способу обгортання.
        /// Ця функція існує, так що всі операції враховуються в операціях загортання.
        ///
        ///
        /// # Examples
        ///
        /// Основне використання:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div(10), 10);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div(self, rhs: Self) -> Self {
            self / rhs
        }

        /// Обгортання евклідового поділу.Обчислює `self.div_euclid(rhs)`.
        /// Обернене ділення на непідписані типи-це звичайне ділення.
        /// Немає жодного способу обгортання.
        /// Ця функція існує, так що всі операції враховуються в операціях загортання.
        /// Оскільки для позитивних цілих чисел усі загальні визначення поділу рівні, це точно дорівнює `self.wrapping_div(rhs)`.
        ///
        ///
        /// # Examples
        ///
        /// Основне використання:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div_euclid(10), 10);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div_euclid(self, rhs: Self) -> Self {
            self / rhs
        }

        /// Обгортання решти (modular).Обчислює `self % rhs`.
        /// Обчислення залишків, що обертаються, для типів без підпису-це лише звичайне обчислення залишку.
        ///
        /// Немає жодного способу обгортання.
        /// Ця функція існує, так що всі операції враховуються в операціях загортання.
        ///
        /// # Examples
        ///
        /// Основне використання:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem(10), 0);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem(self, rhs: Self) -> Self {
            self % rhs
        }

        /// Обгортання за евклідовим модулем.Обчислює `self.rem_euclid(rhs)`.
        /// Обгорнуте обчислення за модулем для беззнакових типів-це лише звичайне обчислення залишку.
        /// Немає жодного способу обгортання.
        /// Ця функція існує, так що всі операції враховуються в операціях загортання.
        /// Оскільки для позитивних цілих чисел усі загальні визначення поділу рівні, це точно дорівнює `self.wrapping_rem(rhs)`.
        ///
        ///
        /// # Examples
        ///
        /// Основне використання:
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem_euclid(10), 0);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem_euclid(self, rhs: Self) -> Self {
            self % rhs
        }

        /// Обгортання заперечення (modular).
        /// Обчислює `-self`, обертаючись на межі типу.
        ///
        /// Оскільки непідписані типи не мають негативних еквівалентів, усі програми цієї функції обертаються (крім `-0`).
        /// Для значень, менших за максимум відповідного підписаного типу, результат такий самий, як і приведення відповідного підписаного значення.
        ///
        /// Будь-які більші значення еквівалентні `MAX + 1 - (val - MAX - 1)`, де `MAX`-максимум відповідного підписаного типу.
        ///
        /// # Examples
        ///
        /// Основне використання:
        ///
        /// Зверніть увагу, що цей приклад ділиться між цілими типами.
        /// Що пояснює, чому тут використовується `i8`.
        ///
        /// ```
        /// assert_eq!(100i8.wrapping_neg(), -100);
        /// assert_eq!((-128i8).wrapping_neg(), -128);
        /// ```
        ///
        ///
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[inline]
        pub const fn wrapping_neg(self) -> Self {
            self.overflowing_neg().0
        }

        /// Panic-побітове зсув ліворуч;
        /// дає `self << mask(rhs)`, де `mask` видаляє будь-які біти `rhs` високого порядку, які могли б призвести до перевищення зсуву бітової ширини типу.
        ///
        /// Зверніть увагу, що це *не* те саме, що і обертання вліво;RHS обертального зсуву вліво обмежується діапазоном типу, а не бітами, зсунутими з LHS, повертаються на інший кінець.
        /// Усі примітивні цілі типи реалізують функцію [`rotate_left`](Self::rotate_left), яка замість цього може бути саме тим, що вам потрібно.
        ///
        /// # Examples
        ///
        /// Основне використання:
        ///
        /// ```
        ///
        ///
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".wrapping_shl(7), 128);")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".wrapping_shl(128), 1);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_shl(self, rhs: u32) -> Self {
            // БЕЗПЕКА: маскування бітовим розміром типу гарантує, що ми не рухаємося
            // поза меж
            unsafe {
                intrinsics::unchecked_shl(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// Panic-вільний побітовий зсув вправо;
        /// дає `self >> mask(rhs)`, де `mask` видаляє будь-які біти `rhs` високого порядку, які могли б призвести до перевищення зсуву бітової ширини типу.
        ///
        /// Зверніть увагу, що це *не* те саме, що обертати вправо;RHS зсуву обертання вправо обмежується діапазоном типу, а не бітами, зміщеними поза LHS, повертаються на інший кінець.
        /// Усі примітивні цілі типи реалізують функцію [`rotate_right`](Self::rotate_right), яка замість цього може бути саме тим, що вам потрібно.
        ///
        /// # Examples
        ///
        /// Основне використання:
        ///
        /// ```
        ///
        ///
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".wrapping_shr(7), 1);")]
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".wrapping_shr(128), 128);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_shr(self, rhs: u32) -> Self {
            // БЕЗПЕКА: маскування бітовим розміром типу гарантує, що ми не рухаємося
            // поза меж
            unsafe {
                intrinsics::unchecked_shr(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// Обгортання підсилення (modular).
        /// Обчислює `self.pow(exp)`, обертаючись на межі типу.
        ///
        /// # Examples
        ///
        /// Основне використання:
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".wrapping_pow(5), 243);")]
        /// assert_eq!(3u8.wrapping_pow(6), 217);
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc.wrapping_mul(base);
                }
                exp /= 2;
                base = base.wrapping_mul(base);
            }

            // оскільки exp!=0, нарешті exp повинен бути 1.
            // Опрацьовуйте остаточний біт експоненти окремо, оскільки квадратування основи після цього не є необхідним і може спричинити непотрібне переповнення.
            //
            //
            acc.wrapping_mul(base)
        }

        /// Обчислює `self` + `rhs`
        ///
        /// Повертає кортеж додавання разом із булевим значенням, що вказує, чи відбудеться арифметичне переповнення.
        /// Якщо сталося б переповнення, тоді повертається значення.
        ///
        /// # Examples
        ///
        /// Основне використання
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_add(2), (7, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.overflowing_add(1), (0, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_add(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::add_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// Обчислює `self`, `rhs`
        ///
        /// Повертає кортеж віднімання разом із булевим значенням, що вказує, чи відбудеться арифметичне переповнення.
        /// Якщо сталося б переповнення, тоді повертається значення.
        ///
        /// # Examples
        ///
        /// Основне використання
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_sub(2), (3, false));")]
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".overflowing_sub(1), (", stringify!($SelfT), "::MAX, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_sub(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::sub_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// Обчислює множення `self` і `rhs`.
        ///
        /// Повертає кортеж множення разом із булевим значенням, що вказує, чи відбудеться арифметичне переповнення.
        /// Якщо сталося б переповнення, тоді повертається значення.
        ///
        /// # Examples
        ///
        /// Основне використання:
        ///
        /// Зверніть увагу, що цей приклад ділиться між цілими типами.
        /// Що пояснює, чому тут використовується `u32`.
        ///
        /// ```
        /// assert_eq!(5u32.overflowing_mul(2), (10, false));
        /// assert_eq!(1_000_000_000u32.overflowing_mul(10), (1410065408, true));
        /// ```
        ///
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
        #[inline]
        pub const fn overflowing_mul(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::mul_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// Обчислює дільник, коли `self` ділиться на `rhs`.
        ///
        /// Повертає кортеж дільника разом із логічним значенням, що вказує, чи відбудеться арифметичне переповнення.
        /// Зауважте, що для безцільних цілих чисел переповнення ніколи не відбувається, тому другим значенням завжди є `false`.
        ///
        /// # Panics
        ///
        /// Ця функція буде panic, якщо `rhs` дорівнює 0.
        ///
        /// # Examples
        ///
        /// Основне використання
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div(2), (2, false));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div(self, rhs: Self) -> (Self, bool) {
            (self / rhs, false)
        }

        /// Обчислює коефіцієнт евклідового поділу `self.div_euclid(rhs)`.
        ///
        /// Повертає кортеж дільника разом із логічним значенням, що вказує, чи відбудеться арифметичне переповнення.
        /// Зауважте, що для безцільних цілих чисел переповнення ніколи не відбувається, тому другим значенням завжди є `false`.
        /// Оскільки для позитивних цілих чисел усі загальні визначення поділу рівні, це точно дорівнює `self.overflowing_div(rhs)`.
        ///
        ///
        /// # Panics
        ///
        /// Ця функція буде panic, якщо `rhs` дорівнює 0.
        ///
        /// # Examples
        ///
        /// Основне використання
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div_euclid(2), (2, false));")]
        /// ```
        #[inline]
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div_euclid(self, rhs: Self) -> (Self, bool) {
            (self / rhs, false)
        }

        /// Обчислює залишок, коли `self` ділиться на `rhs`.
        ///
        /// Повертає кортеж залишку після ділення разом із логічним значенням, що вказує, чи відбудеться арифметичне переповнення.
        /// Зауважте, що для безцільних цілих чисел переповнення ніколи не відбувається, тому другим значенням завжди є `false`.
        ///
        /// # Panics
        ///
        /// Ця функція буде panic, якщо `rhs` дорівнює 0.
        ///
        /// # Examples
        ///
        /// Основне використання
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem(2), (1, false));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_rem(self, rhs: Self) -> (Self, bool) {
            (self % rhs, false)
        }

        /// Обчислює залишок `self.rem_euclid(rhs)` як би за евклідовим діленням.
        ///
        /// Повертає кортеж модуля після ділення разом із логічним значенням, що вказує, чи відбудеться арифметичне переповнення.
        /// Зауважте, що для безцільних цілих чисел переповнення ніколи не відбувається, тому другим значенням завжди є `false`.
        /// Оскільки для цілих додатних чисел усі загальні визначення поділу рівні, ця операція точно дорівнює `self.overflowing_rem(rhs)`.
        ///
        ///
        /// # Panics
        ///
        /// Ця функція буде panic, якщо `rhs` дорівнює 0.
        ///
        /// # Examples
        ///
        /// Основне використання
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem_euclid(2), (1, false));")]
        /// ```
        #[inline]
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_rem_euclid(self, rhs: Self) -> (Self, bool) {
            (self % rhs, false)
        }

        /// Негатує себе в повному обсязі.
        ///
        /// Повертає `!self + 1` за допомогою операцій обтікання, щоб повернути значення, яке представляє заперечення цього непідписаного значення.
        /// Зверніть увагу, що для позитивних беззнакових значень переповнення відбувається завжди, але заперечення 0 не переповнює.
        ///
        /// # Examples
        ///
        /// Основне використання
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".overflowing_neg(), (0, false));")]
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".overflowing_neg(), (-2i32 as ", stringify!($SelfT), ", true));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        pub const fn overflowing_neg(self) -> (Self, bool) {
            ((!self).wrapping_add(1), self != 0)
        }

        /// Змінює себе вліво бітами `rhs`.
        ///
        /// Повертає кортеж зсунутої версії self разом із логічним значенням, яке вказує, чи було значення зсуву більшим чи рівним числу бітів.
        /// Якщо значення зсуву занадто велике, тоді значення маскується (N-1), де N-кількість бітів, і це значення потім використовується для виконання зсуву.
        ///
        /// # Examples
        ///
        /// Основне використання
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".overflowing_shl(4), (0x10, false));")]
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".overflowing_shl(132), (0x10, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shl(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shl(rhs), (rhs > ($BITS - 1)))
        }

        /// Зміщує себе вправо на біти `rhs`.
        ///
        /// Повертає кортеж зсунутої версії self разом із логічним значенням, яке вказує, чи було значення зсуву більшим чи рівним числу бітів.
        /// Якщо значення зсуву занадто велике, тоді значення маскується (N-1), де N-кількість бітів, і це значення потім використовується для виконання зсуву.
        ///
        /// # Examples
        ///
        /// Основне використання
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".overflowing_shr(4), (0x1, false));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".overflowing_shr(132), (0x1, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shr(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shr(rhs), (rhs > ($BITS - 1)))
        }

        /// Піднімає себе до потужності `exp`, використовуючи піднесення до степеня за допомогою квадратури.
        ///
        /// Повертає кортеж степенів поряд із bool, вказуючи, чи сталося переповнення.
        ///
        ///
        /// # Examples
        ///
        /// Основне використання:
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".overflowing_pow(5), (243, false));")]
        /// assert_eq!(3u8.overflowing_pow(6), (217, правда));
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_pow(self, mut exp: u32) -> (Self, bool) {
            if exp == 0{
                return (1,false);
            }
            let mut base = self;
            let mut acc: Self = 1;
            let mut overflown = false;
            // Подряпин простір для зберігання результатів overflowing_mul.
            let mut r;

            while exp > 1 {
                if (exp & 1) == 1 {
                    r = acc.overflowing_mul(base);
                    acc = r.0;
                    overflown |= r.1;
                }
                exp /= 2;
                r = base.overflowing_mul(base);
                base = r.0;
                overflown |= r.1;
            }

            // оскільки exp!=0, нарешті exp повинен бути 1.
            // Опрацьовуйте остаточний біт експоненти окремо, оскільки квадратування основи після цього не є необхідним і може спричинити непотрібне переповнення.
            //
            //
            r = acc.overflowing_mul(base);
            r.1 |= overflown;

            r
        }

        /// Піднімає себе до потужності `exp`, використовуючи піднесення до степеня за допомогою квадратури.
        ///
        /// # Examples
        ///
        /// Основне використання:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".pow(5), 32);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc * base;
                }
                exp /= 2;
                base = base * base;
            }

            // оскільки exp!=0, нарешті exp повинен бути 1.
            // Опрацьовуйте остаточний біт експоненти окремо, оскільки квадратування основи після цього не є необхідним і може спричинити непотрібне переповнення.
            //
            //
            acc * base
        }

        /// Виконує евклідове ділення.
        ///
        /// Оскільки для позитивних цілих чисел усі загальні визначення поділу рівні, це точно дорівнює `self / rhs`.
        ///
        ///
        /// # Panics
        ///
        /// Ця функція буде panic, якщо `rhs` дорівнює 0.
        ///
        /// # Examples
        ///
        /// Основне використання:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(7", stringify!($SelfT), ".div_euclid(4), 1); // or any other integer type")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn div_euclid(self, rhs: Self) -> Self {
            self / rhs
        }


        /// Обчислює найменший залишок `self (mod rhs)`.
        ///
        /// Оскільки для позитивних цілих чисел усі загальні визначення поділу рівні, це точно дорівнює `self % rhs`.
        ///
        ///
        /// # Panics
        ///
        /// Ця функція буде panic, якщо `rhs` дорівнює 0.
        ///
        /// # Examples
        ///
        /// Основне використання:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(7", stringify!($SelfT), ".rem_euclid(4), 3); // or any other integer type")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn rem_euclid(self, rhs: Self) -> Self {
            self % rhs
        }

        /// Повертає `true` тоді і лише тоді, коли `self == 2^k` для деяких `k`.
        ///
        /// # Examples
        ///
        /// Основне використання:
        ///
        /// ```
        #[doc = concat!("assert!(16", stringify!($SelfT), ".is_power_of_two());")]
        #[doc = concat!("assert!(!10", stringify!($SelfT), ".is_power_of_two());")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_is_power_of_two", since = "1.32.0")]
        #[inline]
        pub const fn is_power_of_two(self) -> bool {
            self.count_ones() == 1
        }

        // Повертає на одиницю менше, ніж наступна потужність із двох.
        // (Для 8u8 наступна потужність двох дорівнює 8u8, а для 6u8-8u8)
        //
        // 8u8.one_less_than_next_power_of_two() ==7
        // 6u8.one_less_than_next_power_of_two() ==7
        //
        // Цей метод не може переповнюватися, оскільки у випадках переповнення `next_power_of_two` він замість цього повертає максимальне значення типу і може повернути 0 для 0.
        //
        //
        #[inline]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        const fn one_less_than_next_power_of_two(self) -> Self {
            if self <= 1 { return 0; }

            let p = self - 1;
            // БЕЗПЕКА: Оскільки `p > 0`, він не може повністю складатися з провідних нулів.
            // Це означає, що зсув завжди є внутрішнім, і деякі процесори (наприклад, Intel pre-haswell) мають більш ефективні властивості ctlz, коли аргумент не дорівнює нулю.
            //
            //
            let z = unsafe { intrinsics::ctlz_nonzero(p) };
            <$SelfT>::MAX >> z
        }

        /// Повертає найменшу потужність із двох, більшу або рівну `self`.
        ///
        /// Коли повертається значення переповнюється (тобто `self > (1 << (N-1))` для типу `uN`), воно panics у режимі налагодження, а повертане значення обертається до 0 у режимі звільнення (єдина ситуація, коли метод може повернути 0).
        ///
        ///
        /// # Examples
        ///
        /// Основне використання:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".next_power_of_two(), 2);")]
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".next_power_of_two(), 4);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn next_power_of_two(self) -> Self {
            self.one_less_than_next_power_of_two() + 1
        }

        /// Повертає найменшу потужність із двох, більшу або рівну `n`.
        /// Якщо наступна потужність двох перевищує максимальне значення типу, повертається `None`, інакше потужність двох обертається `Some`.
        ///
        ///
        /// # Examples
        ///
        /// Основне використання:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".checked_next_power_of_two(), Some(2));")]
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".checked_next_power_of_two(), Some(4));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_next_power_of_two(), None);")]
        /// ```
        #[inline]
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        pub const fn checked_next_power_of_two(self) -> Option<Self> {
            self.one_less_than_next_power_of_two().checked_add(1)
        }

        /// Повертає найменшу потужність із двох, більшу або рівну `n`.
        /// Якщо наступна потужність із двох перевищує максимальне значення типу, повернене значення переноситься на `0`.
        ///
        ///
        /// # Examples
        ///
        /// Основне використання:
        ///
        /// ```
        /// #![feature(wrapping_next_power_of_two)]
        ///
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".wrapping_next_power_of_two(), 2);")]
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".wrapping_next_power_of_two(), 4);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.wrapping_next_power_of_two(), 0);")]
        /// ```
        #[unstable(feature = "wrapping_next_power_of_two", issue = "32463",
                   reason = "needs decision on wrapping behaviour")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        pub const fn wrapping_next_power_of_two(self) -> Self {
            self.one_less_than_next_power_of_two().wrapping_add(1)
        }

        /// Повернути представлення пам'яті цього цілого числа як байтовий масив у великому порядку байтів (network).
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_be_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $be_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn to_be_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_be().to_ne_bytes()
        }

        /// Повернути представлення пам'яті цього цілого числа у вигляді байтового масиву в байтовому порядку малої величини.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_le_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $le_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn to_le_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_le().to_ne_bytes()
        }

        /// Повернути представлення пам'яті цього цілого числа як байтовий масив у власному порядку байтів.
        ///
        /// Оскільки використовується рідна спрямованість цільової платформи, переносний код повинен замість цього використовувати [`to_be_bytes`] або [`to_le_bytes`], як підходить.
        ///
        ///
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// [`to_be_bytes`]: Self::to_be_bytes
        /// [`to_le_bytes`]: Self::to_le_bytes
        ///
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_ne_bytes();")]
        /// assert_eq!(
        ///     байт, якщо cfg! (target_endian= "big"){
        ///
        #[doc = concat!("        ", $be_bytes)]
        /// } ще {
        #[doc = concat!("        ", $le_bytes)]
        /// }
        /// );
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // БЕЗПЕКА: звук const, оскільки цілі числа-це звичайні старі типи даних, тому ми можемо завжди
        // перетворити їх на масиви байтів
        #[rustc_allow_const_fn_unstable(const_fn_transmute)]
        #[inline]
        pub const fn to_ne_bytes(self) -> [u8; mem::size_of::<Self>()] {
            // БЕЗПЕКА: цілі числа-це звичайні старі типи даних, тому ми завжди можемо їх трансмутувати
            // масиви байтів
            unsafe { mem::transmute(self) }
        }

        /// Повернути представлення пам'яті цього цілого числа як байтовий масив у власному порядку байтів.
        ///
        ///
        /// [`to_ne_bytes`] слід віддавати перевагу цьому, коли це можливо.
        ///
        /// [`to_ne_bytes`]: Self::to_ne_bytes
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(num_as_ne_bytes)]
        #[doc = concat!("let num = ", $swap_op, stringify!($SelfT), ";")]
        /// нехай байти= num.as_ne_bytes();
        /// assert_eq!(
        ///     байт, якщо cfg! (target_endian= "big"){
        ///
        #[doc = concat!("        &", $be_bytes)]
        /// } ще {
        #[doc = concat!("        &", $le_bytes)]
        /// }
        /// );
        /// ```
        #[unstable(feature = "num_as_ne_bytes", issue = "76976")]
        #[inline]
        pub fn as_ne_bytes(&self) -> &[u8; mem::size_of::<Self>()] {
            // БЕЗПЕКА: цілі числа-це звичайні старі типи даних, тому ми завжди можемо їх трансмутувати
            // масиви байтів
            unsafe { &*(self as *const Self as *const _) }
        }

        /// Створіть рідне ціле значення ендіана з його подання як байтовий масив у великому ендіані.
        ///
        ///
        #[doc = $from_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_be_bytes(", $be_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// використовувати std::convert::TryInto;
        #[doc = concat!("fn read_be_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * вхід=відпочинок;
        #[doc = concat!("    ", stringify!($SelfT), "::from_be_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn from_be_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_be(Self::from_ne_bytes(bytes))
        }

        /// Створіть власне ціле значення ендіана з його подання як байтовий масив у маленькому ендіані.
        ///
        ///
        #[doc = $from_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_le_bytes(", $le_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// використовувати std::convert::TryInto;
        #[doc = concat!("fn read_le_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * вхід=відпочинок;
        #[doc = concat!("    ", stringify!($SelfT), "::from_le_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn from_le_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_le(Self::from_ne_bytes(bytes))
        }

        /// Створіть рідне ціле значення ендіана з представлення його пам'яті як байтовий масив у рідному ендіанстві.
        ///
        /// Оскільки використовується рідна притаманність цільової платформи, портативний код, швидше за все, хоче використовувати [`from_be_bytes`] або [`from_le_bytes`], як слід, замість цього.
        ///
        ///
        /// [`from_be_bytes`]: Self::from_be_bytes
        /// [`from_le_bytes`]: Self::from_le_bytes
        ///
        ///
        ///
        #[doc = $from_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_ne_bytes(if cfg!(target_endian = \"big\") {")]
        #[doc = concat!("    ", $be_bytes, "")]
        /// } ще {
        #[doc = concat!("    ", $le_bytes, "")]
        /// });
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// використовувати std::convert::TryInto;
        #[doc = concat!("fn read_ne_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * вхід=відпочинок;
        #[doc = concat!("    ", stringify!($SelfT), "::from_ne_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // БЕЗПЕКА: звук const, оскільки цілі числа-це звичайні старі типи даних, тому ми можемо завжди
        // трансмутувати їм
        #[rustc_allow_const_fn_unstable(const_fn_transmute)]
        #[inline]
        pub const fn from_ne_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            // БЕЗПЕКА: цілі числа-це звичайні старі типи даних, тому ми завжди можемо їх трансмутувати
            unsafe { mem::transmute(bytes) }
        }

        /// Новий код слід віддавати перевагу використанню
        #[doc = concat!("[`", stringify!($SelfT), "::MIN", "`] instead.")]
        /// Повертає найменше значення, яке може бути представлене цим цілим числом.
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_promotable]
        #[inline(always)]
        #[rustc_const_stable(feature = "const_max_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MIN` associated constant on this type")]
        pub const fn min_value() -> Self { Self::MIN }

        /// Новий код слід віддавати перевагу використанню
        #[doc = concat!("[`", stringify!($SelfT), "::MAX", "`] instead.")]
        /// Повертає найбільше значення, яке може бути представлено цим цілим числом.
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_promotable]
        #[inline(always)]
        #[rustc_const_stable(feature = "const_max_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MAX` associated constant on this type")]
        pub const fn max_value() -> Self { Self::MAX }
    }
}