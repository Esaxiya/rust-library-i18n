//! Константи, характерні для одноточного типу з плаваючою комою `f32`.
//!
//! *[See also the `f32` primitive type][f32].*
//!
//! Математично значущі цифри подані в підмодулі `consts`.
//!
//! Для констант, визначених безпосередньо в цьому модулі (на відміну від визначених у підмодулі `consts`), новий код повинен замість цього використовувати пов'язані константи, визначені безпосередньо для типу `f32`.
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::convert::FloatToInt;
#[cfg(not(test))]
use crate::intrinsics;
use crate::mem;
use crate::num::FpCategory;

/// Радікс або основа внутрішнього подання `f32`.
/// Замість цього використовуйте [`f32::RADIX`].
///
/// # Examples
///
/// ```rust
/// // застарілий спосіб
/// # #[allow(deprecated, deprecated_in_future)]
/// let r = std::f32::RADIX;
///
/// // передбачуваний спосіб
/// let r = f32::RADIX;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `RADIX` associated constant on `f32`")]
pub const RADIX: u32 = f32::RADIX;

/// Кількість значущих цифр в основі 2.
/// Замість цього використовуйте [`f32::MANTISSA_DIGITS`].
///
/// # Examples
///
/// ```rust
/// // застарілий спосіб
/// # #[allow(deprecated, deprecated_in_future)]
/// let d = std::f32::MANTISSA_DIGITS;
///
/// // передбачуваний спосіб
/// let d = f32::MANTISSA_DIGITS;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MANTISSA_DIGITS` associated constant on `f32`"
)]
pub const MANTISSA_DIGITS: u32 = f32::MANTISSA_DIGITS;

/// Приблизна кількість значущих цифр в основі 10.
/// Замість цього використовуйте [`f32::DIGITS`].
///
/// # Examples
///
/// ```rust
/// // застарілий спосіб
/// # #[allow(deprecated, deprecated_in_future)]
/// let d = std::f32::DIGITS;
///
/// // передбачуваний спосіб
/// let d = f32::DIGITS;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `DIGITS` associated constant on `f32`")]
pub const DIGITS: u32 = f32::DIGITS;

/// [Machine epsilon] значення для `f32`.
/// Замість цього використовуйте [`f32::EPSILON`].
///
/// Це різниця між `1.0` і наступним більшим представленим числом.
///
/// [Machine epsilon]: https://en.wikipedia.org/wiki/Machine_epsilon
///
/// # Examples
///
/// ```rust
/// // застарілий спосіб
/// # #[allow(deprecated, deprecated_in_future)]
/// let e = std::f32::EPSILON;
///
/// // передбачуваний спосіб
/// let e = f32::EPSILON;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `EPSILON` associated constant on `f32`"
)]
pub const EPSILON: f32 = f32::EPSILON;

/// Найменше кінцеве значення `f32`.
/// Замість цього використовуйте [`f32::MIN`].
///
/// # Examples
///
/// ```rust
/// // застарілий спосіб
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN;
///
/// // передбачуваний спосіб
/// let min = f32::MIN;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `MIN` associated constant on `f32`")]
pub const MIN: f32 = f32::MIN;

/// Найменше позитивне нормальне значення `f32`.
/// Замість цього використовуйте [`f32::MIN_POSITIVE`].
///
/// # Examples
///
/// ```rust
/// // застарілий спосіб
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN_POSITIVE;
///
/// // передбачуваний спосіб
/// let min = f32::MIN_POSITIVE;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_POSITIVE` associated constant on `f32`"
)]
pub const MIN_POSITIVE: f32 = f32::MIN_POSITIVE;

/// Найбільше кінцеве значення `f32`.
/// Замість цього використовуйте [`f32::MAX`].
///
/// # Examples
///
/// ```rust
/// // застарілий спосіб
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f32::MAX;
///
/// // передбачуваний спосіб
/// let max = f32::MAX;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `MAX` associated constant on `f32`")]
pub const MAX: f32 = f32::MAX;

/// Одне, що перевищує мінімально можливу нормальну потужність 2 показника.
/// Замість цього використовуйте [`f32::MIN_EXP`].
///
/// # Examples
///
/// ```rust
/// // застарілий спосіб
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN_EXP;
///
/// // передбачуваний спосіб
/// let min = f32::MIN_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_EXP` associated constant on `f32`"
)]
pub const MIN_EXP: i32 = f32::MIN_EXP;

/// Максимально можлива потужність 2 показника.
/// Замість цього використовуйте [`f32::MAX_EXP`].
///
/// # Examples
///
/// ```rust
/// // застарілий спосіб
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f32::MAX_EXP;
///
/// // передбачуваний спосіб
/// let max = f32::MAX_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MAX_EXP` associated constant on `f32`"
)]
pub const MAX_EXP: i32 = f32::MAX_EXP;

/// Мінімально можлива нормальна потужність 10 показників.
/// Замість цього використовуйте [`f32::MIN_10_EXP`].
///
/// # Examples
///
/// ```rust
/// // застарілий спосіб
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN_10_EXP;
///
/// // передбачуваний спосіб
/// let min = f32::MIN_10_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_10_EXP` associated constant on `f32`"
)]
pub const MIN_10_EXP: i32 = f32::MIN_10_EXP;

/// Максимально можлива потужність 10 показників.
/// Замість цього використовуйте [`f32::MAX_10_EXP`].
///
/// # Examples
///
/// ```rust
/// // застарілий спосіб
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f32::MAX_10_EXP;
///
/// // передбачуваний спосіб
/// let max = f32::MAX_10_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MAX_10_EXP` associated constant on `f32`"
)]
pub const MAX_10_EXP: i32 = f32::MAX_10_EXP;

/// Не номер (NaN).
/// Замість цього використовуйте [`f32::NAN`].
///
/// # Examples
///
/// ```rust
/// // застарілий спосіб
/// # #[allow(deprecated, deprecated_in_future)]
/// let nan = std::f32::NAN;
///
/// // передбачуваний спосіб
/// let nan = f32::NAN;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `NAN` associated constant on `f32`")]
pub const NAN: f32 = f32::NAN;

/// Нескінченність (∞).
/// Замість цього використовуйте [`f32::INFINITY`].
///
/// # Examples
///
/// ```rust
/// // застарілий спосіб
/// # #[allow(deprecated, deprecated_in_future)]
/// let inf = std::f32::INFINITY;
///
/// // передбачуваний спосіб
/// let inf = f32::INFINITY;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `INFINITY` associated constant on `f32`"
)]
pub const INFINITY: f32 = f32::INFINITY;

/// Негативна нескінченність (−∞).
/// Замість цього використовуйте [`f32::NEG_INFINITY`].
///
/// # Examples
///
/// ```rust
/// // застарілий спосіб
/// # #[allow(deprecated, deprecated_in_future)]
/// let ninf = std::f32::NEG_INFINITY;
///
/// // передбачуваний спосіб
/// let ninf = f32::NEG_INFINITY;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `NEG_INFINITY` associated constant on `f32`"
)]
pub const NEG_INFINITY: f32 = f32::NEG_INFINITY;

/// Основні математичні константи.
#[stable(feature = "rust1", since = "1.0.0")]
pub mod consts {
    // FIXME: замінити математичними константами з cmath.

    /// Константа Архімеда (π)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const PI: f32 = 3.14159265358979323846264338327950288_f32;

    /// Постійна повного кола (τ)
    ///
    /// Дорівнює 2π.
    #[stable(feature = "tau_constant", since = "1.47.0")]
    pub const TAU: f32 = 6.28318530717958647692528676655900577_f32;

    /// π/2
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_2: f32 = 1.57079632679489661923132169163975144_f32;

    /// π/3
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_3: f32 = 1.04719755119659774615421446109316763_f32;

    /// π/4
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_4: f32 = 0.785398163397448309615660845819875721_f32;

    /// π/6
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_6: f32 = 0.52359877559829887307710723054658381_f32;

    /// π/8
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_8: f32 = 0.39269908169872415480783042290993786_f32;

    /// 1/π
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_1_PI: f32 = 0.318309886183790671537767526745028724_f32;

    /// 2/π
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_2_PI: f32 = 0.636619772367581343075535053490057448_f32;

    /// 2/sqrt(π)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_2_SQRT_PI: f32 = 1.12837916709551257389615890312154517_f32;

    /// sqrt(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const SQRT_2: f32 = 1.41421356237309504880168872420969808_f32;

    /// 1/sqrt(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_1_SQRT_2: f32 = 0.707106781186547524400844362104849039_f32;

    /// Номер Ейлера (e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const E: f32 = 2.71828182845904523536028747135266250_f32;

    /// log<sub>2</sub>(e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LOG2_E: f32 = 1.44269504088896340735992468100189214_f32;

    /// log<sub>2</sub>(10)
    #[stable(feature = "extra_log_consts", since = "1.43.0")]
    pub const LOG2_10: f32 = 3.32192809488736234787031942948939018_f32;

    /// log<sub>10</sub>(e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LOG10_E: f32 = 0.434294481903251827651128918916605082_f32;

    /// log<sub>10</sub>(2)
    #[stable(feature = "extra_log_consts", since = "1.43.0")]
    pub const LOG10_2: f32 = 0.301029995663981195213738894724493027_f32;

    /// ln(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LN_2: f32 = 0.693147180559945309417232121458176568_f32;

    /// ln(10)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LN_10: f32 = 2.30258509299404568401799145468436421_f32;
}

#[lang = "f32"]
#[cfg(not(test))]
impl f32 {
    /// Радікс або основа внутрішнього подання `f32`.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const RADIX: u32 = 2;

    /// Кількість значущих цифр в основі 2.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MANTISSA_DIGITS: u32 = 24;

    /// Приблизна кількість значущих цифр в основі 10.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const DIGITS: u32 = 6;

    /// [Machine epsilon] значення для `f32`.
    ///
    /// Це різниця між `1.0` і наступним більшим представленим числом.
    ///
    /// [Machine epsilon]: https://en.wikipedia.org/wiki/Machine_epsilon
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const EPSILON: f32 = 1.19209290e-07_f32;

    /// Найменше кінцеве значення `f32`.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN: f32 = -3.40282347e+38_f32;
    /// Найменше позитивне нормальне значення `f32`.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_POSITIVE: f32 = 1.17549435e-38_f32;
    /// Найбільше кінцеве значення `f32`.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX: f32 = 3.40282347e+38_f32;

    /// Одне, що перевищує мінімально можливу нормальну потужність 2 показника.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_EXP: i32 = -125;
    /// Максимально можлива потужність 2 показника.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX_EXP: i32 = 128;

    /// Мінімально можлива нормальна потужність 10 показників.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_10_EXP: i32 = -37;
    /// Максимально можлива потужність 10 показників.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX_10_EXP: i32 = 38;

    /// Не номер (NaN).
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const NAN: f32 = 0.0_f32 / 0.0_f32;
    /// Нескінченність (∞).
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const INFINITY: f32 = 1.0_f32 / 0.0_f32;
    /// Негативна нескінченність (−∞).
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const NEG_INFINITY: f32 = -1.0_f32 / 0.0_f32;

    /// Повертає `true`, якщо це значення `NaN`.
    ///
    /// ```
    /// let nan = f32::NAN;
    /// let f = 7.0_f32;
    ///
    /// assert!(nan.is_nan());
    /// assert!(!f.is_nan());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_nan(self) -> bool {
        self != self
    }

    // FIXME(#50145): `abs` є загальнодоступним у libcore через занепокоєння щодо переносимості, тому ця реалізація призначена для приватного внутрішнього використання.
    //
    //
    #[inline]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    const fn abs_private(self) -> f32 {
        f32::from_bits(self.to_bits() & 0x7fff_ffff)
    }

    /// Повертає `true`, якщо це значення є позитивною нескінченністю або негативною, а `false`-інакше.
    ///
    ///
    /// ```
    /// let f = 7.0f32;
    /// let inf = f32::INFINITY;
    /// let neg_inf = f32::NEG_INFINITY;
    /// let nan = f32::NAN;
    ///
    /// assert!(!f.is_infinite());
    /// assert!(!nan.is_infinite());
    ///
    /// assert!(inf.is_infinite());
    /// assert!(neg_inf.is_infinite());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_infinite(self) -> bool {
        self.abs_private() == Self::INFINITY
    }

    /// Повертає `true`, якщо це число не є нескінченним і не `NaN`.
    ///
    /// ```
    /// let f = 7.0f32;
    /// let inf = f32::INFINITY;
    /// let neg_inf = f32::NEG_INFINITY;
    /// let nan = f32::NAN;
    ///
    /// assert!(f.is_finite());
    ///
    /// assert!(!nan.is_finite());
    /// assert!(!inf.is_finite());
    /// assert!(!neg_inf.is_finite());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_finite(self) -> bool {
        // Немає необхідності обробляти NaN окремо: якщо self є NaN, порівняння не відповідає дійсності, саме так, як бажано.
        //
        self.abs_private() < Self::INFINITY
    }

    /// Повертає `true`, якщо число [subnormal].
    ///
    /// ```
    /// #![feature(is_subnormal)]
    /// let min = f32::MIN_POSITIVE; // 1.17549435e-38f32
    /// let max = f32::MAX;
    /// let lower_than_min = 1.0e-40_f32;
    /// let zero = 0.0_f32;
    ///
    /// assert!(!min.is_subnormal());
    /// assert!(!max.is_subnormal());
    ///
    /// assert!(!zero.is_subnormal());
    /// assert!(!f32::NAN.is_subnormal());
    /// assert!(!f32::INFINITY.is_subnormal());
    /// // Значення між `0` та `min` є субнормальними.
    /// assert!(lower_than_min.is_subnormal());
    /// ```
    /// [subnormal]: https://en.wikipedia.org/wiki/Denormal_number
    #[unstable(feature = "is_subnormal", issue = "79288")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_subnormal(self) -> bool {
        matches!(self.classify(), FpCategory::Subnormal)
    }

    /// Повертає `true`, якщо число не є нульовим, нескінченним, [subnormal] або `NaN`.
    ///
    ///
    /// ```
    /// let min = f32::MIN_POSITIVE; // 1.17549435e-38f32
    /// let max = f32::MAX;
    /// let lower_than_min = 1.0e-40_f32;
    /// let zero = 0.0_f32;
    ///
    /// assert!(min.is_normal());
    /// assert!(max.is_normal());
    ///
    /// assert!(!zero.is_normal());
    /// assert!(!f32::NAN.is_normal());
    /// assert!(!f32::INFINITY.is_normal());
    /// // Значення між `0` та `min` є субнормальними.
    /// assert!(!lower_than_min.is_normal());
    /// ```
    /// [subnormal]: https://en.wikipedia.org/wiki/Denormal_number
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_normal(self) -> bool {
        matches!(self.classify(), FpCategory::Normal)
    }

    /// Повертає категорію числа з плаваючою комою числа.
    /// Якщо буде протестовано лише одне властивість, як правило, швидше використовувати конкретний предикат.
    ///
    ///
    /// ```
    /// use std::num::FpCategory;
    ///
    /// let num = 12.4_f32;
    /// let inf = f32::INFINITY;
    ///
    /// assert_eq!(num.classify(), FpCategory::Normal);
    /// assert_eq!(inf.classify(), FpCategory::Infinite);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    pub const fn classify(self) -> FpCategory {
        const EXP_MASK: u32 = 0x7f800000;
        const MAN_MASK: u32 = 0x007fffff;

        let bits = self.to_bits();
        match (bits & MAN_MASK, bits & EXP_MASK) {
            (0, 0) => FpCategory::Zero,
            (_, 0) => FpCategory::Subnormal,
            (0, EXP_MASK) => FpCategory::Infinite,
            (_, EXP_MASK) => FpCategory::Nan,
            _ => FpCategory::Normal,
        }
    }

    /// Повертає `true`, якщо `self` має позитивний знак, включаючи `+0.0`, `NaN` з позитивним знаковим бітом і позитивною нескінченністю.
    ///
    ///
    /// ```
    /// let f = 7.0_f32;
    /// let g = -7.0_f32;
    ///
    /// assert!(f.is_sign_positive());
    /// assert!(!g.is_sign_positive());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_sign_positive(self) -> bool {
        !self.is_sign_negative()
    }

    /// Повертає `true`, якщо `self` має від'ємний знак, включаючи `-0.0`, `NaN`s з від'ємним знаковим бітом та від'ємною нескінченністю.
    ///
    ///
    /// ```
    /// let f = 7.0f32;
    /// let g = -7.0f32;
    ///
    /// assert!(!f.is_sign_negative());
    /// assert!(g.is_sign_negative());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_sign_negative(self) -> bool {
        // IEEE754 говорить: isSignMinus(x) є істинним тоді і лише тоді, коли x має негативний знак.
        // isSignMinus застосовується також до нулів та NaN.
        self.to_bits() & 0x8000_0000 != 0
    }

    /// Бере зворотний (inverse) числа, `1/x`.
    ///
    /// ```
    /// let x = 2.0_f32;
    /// let abs_difference = (x.recip() - (1.0 / x)).abs();
    ///
    /// assert!(abs_difference <= f32::EPSILON);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn recip(self) -> f32 {
        1.0 / self
    }

    /// Перетворює радіани в градуси.
    ///
    /// ```
    /// let angle = std::f32::consts::PI;
    ///
    /// let abs_difference = (angle.to_degrees() - 180.0).abs();
    ///
    /// assert!(abs_difference <= f32::EPSILON);
    /// ```
    #[stable(feature = "f32_deg_rad_conversions", since = "1.7.0")]
    #[inline]
    pub fn to_degrees(self) -> f32 {
        // Використовуйте константу для кращої точності.
        const PIS_IN_180: f32 = 57.2957795130823208767981548141051703_f32;
        self * PIS_IN_180
    }

    /// Перетворює градуси в радіани.
    ///
    /// ```
    /// let angle = 180.0f32;
    ///
    /// let abs_difference = (angle.to_radians() - std::f32::consts::PI).abs();
    ///
    /// assert!(abs_difference <= f32::EPSILON);
    /// ```
    #[stable(feature = "f32_deg_rad_conversions", since = "1.7.0")]
    #[inline]
    pub fn to_radians(self) -> f32 {
        let value: f32 = consts::PI;
        self * (value / 180.0f32)
    }

    /// Повертає максимум з двох чисел.
    ///
    /// ```
    /// let x = 1.0f32;
    /// let y = 2.0f32;
    ///
    /// assert_eq!(x.max(y), y);
    /// ```
    ///
    /// Якщо одним із аргументів є NaN, тоді повертається інший аргумент.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn max(self, other: f32) -> f32 {
        intrinsics::maxnumf32(self, other)
    }

    /// Повертає мінімум із двох чисел.
    ///
    /// ```
    /// let x = 1.0f32;
    /// let y = 2.0f32;
    ///
    /// assert_eq!(x.min(y), x);
    /// ```
    ///
    /// Якщо одним із аргументів є NaN, тоді повертається інший аргумент.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn min(self, other: f32) -> f32 {
        intrinsics::minnumf32(self, other)
    }

    /// Округлюється до нуля і перетворюється на будь-який примітивний цілий тип, припускаючи, що значення є кінцевим і відповідає цьому типу.
    ///
    ///
    /// ```
    /// let value = 4.6_f32;
    /// let rounded = unsafe { value.to_int_unchecked::<u16>() };
    /// assert_eq!(rounded, 4);
    ///
    /// let value = -128.9_f32;
    /// let rounded = unsafe { value.to_int_unchecked::<i8>() };
    /// assert_eq!(rounded, i8::MIN);
    /// ```
    ///
    /// # Safety
    ///
    /// Значення повинно:
    ///
    /// * Не бути `NaN`
    /// * Не бути нескінченним
    /// * Бути репрезентабельним у типі повернення `Int`, після усічення його дробової частини
    #[stable(feature = "float_approx_unchecked_to", since = "1.44.0")]
    #[inline]
    pub unsafe fn to_int_unchecked<Int>(self) -> Int
    where
        Self: FloatToInt<Int>,
    {
        // БЕЗПЕКА: абонент повинен виконувати контракт про безпеку для `FloatToInt::to_int_unchecked`.
        //
        unsafe { FloatToInt::<Int>::to_int_unchecked(self) }
    }

    /// Сировинна трансмутація до `u32`.
    ///
    /// В даний час це ідентично `transmute::<f32, u32>(self)` на всіх платформах.
    ///
    /// Див. `from_bits`, де можна обговорити питання переносимості цієї операції (проблем майже немає).
    ///
    /// Зверніть увагу, що ця функція відрізняється від кастингу `as`, який намагається зберегти *числове* значення, а не побітове значення.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_ne!((1f32).to_bits(), 1f32 as u32); // to_bits() не кастинг!
    /// assert_eq!((12.5f32).to_bits(), 0x41480000);
    ///
    /// ```
    ///
    #[stable(feature = "float_bits_conv", since = "1.20.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_bits(self) -> u32 {
        // БЕЗПЕКА: `u32`-це звичайний старий тип даних, тому ми завжди можемо трансмутувати його
        unsafe { mem::transmute(self) }
    }

    /// Сировинна трансмутація з `u32`.
    ///
    /// В даний час це ідентично `transmute::<u32, f32>(v)` на всіх платформах.
    /// Виявляється, це неймовірно портативно з двох причин:
    ///
    /// * Floats та Ints мають однакові характеристики на всіх підтримуваних платформах.
    /// * IEEE-754 дуже точно визначає бітове розташування поплавців.
    ///
    /// Однак є одне застереження: до версії IEEE-754 2008 року, як інтерпретувати біт сигналізації NaN, насправді не було вказано.
    /// Більшість платформ (зокрема x86 та ARM) вибрали інтерпретацію, яка була остаточно стандартизована в 2008 році, але деякі не (особливо MIPS).
    /// Як результат, усі сигнальні NaN на MIPS є тихими NaN на x86, і навпаки.
    ///
    /// Замість того, щоб намагатись зберегти крос-платформність сигналізації, ця реалізація сприяє збереженню точних бітів.
    /// Це означає, що будь-які корисні навантаження, закодовані в NaN, будуть збережені, навіть якщо результат цього методу буде переданий по мережі з машини x86 на MIPS.
    ///
    ///
    /// Якщо результатами цього методу маніпулює лише та сама архітектура, яка їх виробляла, тоді не існує занепокоєння щодо переносимості.
    ///
    /// Якщо вхід не NaN, то це не стосується переносимості.
    ///
    /// Якщо ви не дбаєте про сигналізацію (дуже ймовірно), тоді немає ніяких проблем з портативністю.
    ///
    /// Зверніть увагу, що ця функція відрізняється від кастингу `as`, який намагається зберегти *числове* значення, а не побітове значення.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = f32::from_bits(0x41480000);
    /// assert_eq!(v, 12.5);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "float_bits_conv", since = "1.20.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_bits(v: u32) -> Self {
        // БЕЗПЕКА: `u32`-це звичайний старий тип даних, тому ми завжди можемо трансмутувати його
        // Виявляється, проблеми безпеки з sNaN були перенасичені!Ура!
        unsafe { mem::transmute(v) }
    }

    /// Поверніть представлення пам'яті цього числа з плаваючою комою як байтовий масив у великому порядку байтів (network).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f32.to_be_bytes();
    /// assert_eq!(bytes, [0x41, 0x48, 0x00, 0x00]);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_be_bytes(self) -> [u8; 4] {
        self.to_bits().to_be_bytes()
    }

    /// Повернути представлення пам'яті цього числа з плаваючою комою у вигляді байтового масиву в байтовому порядку з малим значенням.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f32.to_le_bytes();
    /// assert_eq!(bytes, [0x00, 0x00, 0x48, 0x41]);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_le_bytes(self) -> [u8; 4] {
        self.to_bits().to_le_bytes()
    }

    /// Повернути представлення пам'яті цього числа з плаваючою комою як байтовий масив у власному порядку байтів.
    ///
    /// Оскільки використовується рідна спрямованість цільової платформи, переносний код повинен замість цього використовувати [`to_be_bytes`] або [`to_le_bytes`], як підходить.
    ///
    ///
    /// [`to_be_bytes`]: f32::to_be_bytes
    /// [`to_le_bytes`]: f32::to_le_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f32.to_ne_bytes();
    /// assert_eq!(
    ///     bytes,
    ///     if cfg!(target_endian = "big") {
    ///         [0x41, 0x48, 0x00, 0x00]
    ///     } else {
    ///         [0x00, 0x00, 0x48, 0x41]
    ///     }
    /// );
    /// ```
    ///
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_ne_bytes(self) -> [u8; 4] {
        self.to_bits().to_ne_bytes()
    }

    /// Повернути представлення пам'яті цього числа з плаваючою комою як байтовий масив у власному порядку байтів.
    ///
    ///
    /// [`to_ne_bytes`] слід віддавати перевагу цьому, коли це можливо.
    ///
    /// [`to_ne_bytes`]: f32::to_ne_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(num_as_ne_bytes)]
    /// let num = 12.5f32;
    /// let bytes = num.as_ne_bytes();
    /// assert_eq!(
    ///     bytes,
    ///     if cfg!(target_endian = "big") {
    ///         &[0x41, 0x48, 0x00, 0x00]
    ///     } else {
    ///         &[0x00, 0x00, 0x48, 0x41]
    ///     }
    /// );
    /// ```
    #[unstable(feature = "num_as_ne_bytes", issue = "76976")]
    #[inline]
    pub fn as_ne_bytes(&self) -> &[u8; 4] {
        // БЕЗПЕКА: `f32`-це звичайний старий тип даних, тому ми завжди можемо трансмутувати його
        unsafe { &*(self as *const Self as *const _) }
    }

    /// Створіть значення з плаваючою точкою з його подання у вигляді байтового масиву у великому ендіані.
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f32::from_be_bytes([0x41, 0x48, 0x00, 0x00]);
    /// assert_eq!(value, 12.5);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_be_bytes(bytes: [u8; 4]) -> Self {
        Self::from_bits(u32::from_be_bytes(bytes))
    }

    /// Створіть значення з плаваючою точкою з його подання у вигляді байтового масиву в маленькому ендіані.
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f32::from_le_bytes([0x00, 0x00, 0x48, 0x41]);
    /// assert_eq!(value, 12.5);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_le_bytes(bytes: [u8; 4]) -> Self {
        Self::from_bits(u32::from_le_bytes(bytes))
    }

    /// Створіть значення з плаваючою комою з його подання у вигляді байтового масиву в рідному ендіані.
    ///
    /// Оскільки використовується рідна притаманність цільової платформи, портативний код, швидше за все, хоче використовувати [`from_be_bytes`] або [`from_le_bytes`], як слід, замість цього.
    ///
    ///
    /// [`from_be_bytes`]: f32::from_be_bytes
    /// [`from_le_bytes`]: f32::from_le_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f32::from_ne_bytes(if cfg!(target_endian = "big") {
    ///     [0x41, 0x48, 0x00, 0x00]
    /// } else {
    ///     [0x00, 0x00, 0x48, 0x41]
    /// });
    /// assert_eq!(value, 12.5);
    /// ```
    ///
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_ne_bytes(bytes: [u8; 4]) -> Self {
        Self::from_bits(u32::from_ne_bytes(bytes))
    }

    /// Повертає впорядкування між собою та іншими цінностями.
    /// На відміну від стандартного часткового порівняння між числами з плаваючою точкою, це порівняння завжди створює впорядкування відповідно до предиката totalOrder, як визначено у стандарті з плаваючою точкою IEEE 754 (версія 2008).
    /// Значення упорядковані в такому порядку:
    /// - Негативний тихий NaN
    /// - Негативна сигналізація NaN
    /// - Негативна нескінченність
    /// - Негативні числа
    /// - Негативні субнормальні числа
    /// - Від`ємний нуль
    /// - Позитивний нуль
    /// - Позитивні субнормальні числа
    /// - Позитивні числа
    /// - Позитивна нескінченність
    /// - Позитивна сигналізація NaN
    /// - Позитивний тихий NaN
    ///
    /// Зверніть увагу, що ця функція не завжди узгоджується з реалізаціями `f32` та [`PartialEq`].Зокрема, вони вважають негативний та позитивний нуль рівними, тоді як `total_cmp`-ні.
    ///
    /// # Example
    ///
    /// ```
    /// #![feature(total_cmp)]
    /// struct GoodBoy {
    ///     name: String,
    ///     weight: f32,
    /// }
    ///
    /// let mut bois = vec![
    ///     GoodBoy { name: "Pucci".to_owned(), weight: 0.1 },
    ///     GoodBoy { name: "Woofer".to_owned(), weight: 99.0 },
    ///     GoodBoy { name: "Yapper".to_owned(), weight: 10.0 },
    ///     GoodBoy { name: "Chonk".to_owned(), weight: f32::INFINITY },
    ///     GoodBoy { name: "Abs. Unit".to_owned(), weight: f32::NAN },
    ///     GoodBoy { name: "Floaty".to_owned(), weight: -5.0 },
    /// ];
    ///
    /// bois.sort_by(|a, b| a.weight.total_cmp(&b.weight));
    /// # assert!(bois.into_iter().map(|b| b.weight)
    /// #     .zip([-5.0, 0.1, 10.0, 99.0, f32::INFINITY, f32::NAN].iter())
    /// #     .all(|(a, b)| a.to_bits() == b.to_bits()))
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "total_cmp", issue = "72599")]
    #[inline]
    pub fn total_cmp(&self, other: &Self) -> crate::cmp::Ordering {
        let mut left = self.to_bits() as i32;
        let mut right = other.to_bits() as i32;

        // У разі негативів переверніть усі біти, крім знака, щоб досягти подібного розміщення, як цілі числа доповнення двох
        //
        // Чому це працює?Поплавці IEEE 754 складаються з трьох полів:
        // Біт знака, показник степеня та мантиса.Сукупність полів експоненти та мантиси в цілому має властивість, що їх побітовий порядок дорівнює числовій величині, де визначена величина.
        // Величина зазвичай не визначається для значень NaN, але IEEE 754 totalOrder визначає значення NaN також для дотримання бітового порядку.Це призводить до порядку, поясненого в коментарі до документа.
        // Однак подання величини однакове для негативних і позитивних чисел-відрізняється лише знаковий біт.
        // Щоб легко порівняти плаваючі числа як підписані цілі числа, нам потрібно перевернути експоненту та біти мантиси у випадку від`ємних чисел.
        // Ми ефективно перетворюємо числа у форму "two's complement".
        //
        // Для перегортання ми створюємо маску та XOR проти неї.
        // Ми розгалужуємо маску "all-ones except for the sign bit" на основі значень із негативними знаками: зсув праворуч розширює ціле число, тому ми "fill" маску знаковими бітами, а потім перетворюємо на unsigned, щоб натиснути ще один нульовий біт.
        //
        // При позитивних значеннях маска має нульові значення, тож це ні.
        //
        //
        //
        //
        //
        //
        //
        //
        //
        left ^= (((left >> 31) as u32) >> 1) as i32;
        right ^= (((right >> 31) as u32) >> 1) as i32;

        left.cmp(&right)
    }

    /// Обмежте значення певним інтервалом, якщо це не NaN.
    ///
    /// Повертає `max`, якщо `self` більше, ніж `max`, і `min`, якщо `self` менше, ніж `min`.
    /// В іншому випадку це повертає `self`.
    ///
    /// Зверніть увагу, що ця функція повертає NaN, якщо початковим значенням було NaN.
    ///
    /// # Panics
    ///
    /// Panics, якщо `min > max`, `min`-NaN, або `max`-NaN.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!((-3.0f32).clamp(-2.0, 1.0) == -2.0);
    /// assert!((0.0f32).clamp(-2.0, 1.0) == 0.0);
    /// assert!((2.0f32).clamp(-2.0, 1.0) == 1.0);
    /// assert!((f32::NAN).clamp(-2.0, 1.0).is_nan());
    /// ```
    ///
    #[must_use = "method returns a new number and does not mutate the original value"]
    #[stable(feature = "clamp", since = "1.50.0")]
    #[inline]
    pub fn clamp(self, min: f32, max: f32) -> f32 {
        assert!(min <= max);
        let mut x = self;
        if x < min {
            x = min;
        }
        if x > max {
            x = max;
        }
        x
    }
}