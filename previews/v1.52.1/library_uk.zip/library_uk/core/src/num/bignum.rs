//! Спеціальна реалізація числа (bignum) з довільною точністю.
//!
//! Це призначено для уникнення розподілу купи за рахунок пам'яті стека.
//! Найбільш використовуваний тип bignum, `Big32x40`, обмежений 32 × 40=1280 біт і займе максимум 160 байт пам`яті стека.
//! Цього більш ніж достатньо для обертання всіх можливих кінцевих значень `f64`.
//!
//! В принципі, можна мати кілька типів bignum для різних входів, але ми не робимо цього, щоб уникнути здуття коду.
//!
//! Кожна bignum все ще відстежується за фактичними звичками, тому зазвичай це не має значення.
//!

// Цей модуль призначений лише для dec2flt і flt2dec, і лише загальнодоступний через основні тести.
// Він не призначений ніколи для стабілізації.
#![doc(hidden)]
#![unstable(
    feature = "core_private_bignum",
    reason = "internal routines only exposed for testing",
    issue = "none"
)]
#![macro_use]

use crate::intrinsics;

/// Арифметичні дії, які вимагають бігнуми.
pub trait FullOps: Sized {
    /// Повертає `(carry', v')` так, що `carry' * 2^W + v' = self + other + carry`, де `W`-це кількість бітів у `Self`.
    ///
    fn full_add(self, other: Self, carry: bool) -> (bool /* carry */, Self);

    /// Повертає `(carry', v')` так, що `carry'*2^W + v' = self* other + carry`, де `W`-це кількість бітів у `Self`.
    ///
    fn full_mul(self, other: Self, carry: Self) -> (Self /* carry */, Self);

    /// Повертає `(carry', v')` так, що `carry'*2^W + v' = self* other + other2 + carry`, де `W`-це кількість бітів у `Self`.
    ///
    fn full_mul_add(self, other: Self, other2: Self, carry: Self) -> (Self /* carry */, Self);

    /// Повертає `(quo, rem)` так, що `borrow *2^W + self = quo* other + rem` і `0 <= rem < other`, де `W`-це кількість бітів у `Self`.
    ///
    fn full_div_rem(self, other: Self, borrow: Self)
    -> (Self /* quotient */, Self /* remainder */);
}

macro_rules! impl_full_ops {
    ($($ty:ty: add($addfn:path), mul/div($bigty:ident);)*) => (
        $(
            impl FullOps for $ty {
                fn full_add(self, other: $ty, carry: bool) -> (bool, $ty) {
                    // Це не може переповнюватися;вихід знаходиться між `0` і `2 * 2^nbits - 1`.
                    // FIXME: LLVM оптимізує це в АЦП або подібне?
                    let (v, carry1) = intrinsics::add_with_overflow(self, other);
                    let (v, carry2) = intrinsics::add_with_overflow(v, if carry {1} else {0});
                    (carry1 || carry2, v)
                }

                fn full_mul(self, other: $ty, carry: $ty) -> ($ty, $ty) {
                    // Це не може переповнюватися;
                    // вихід знаходиться між `0` і `2^nbits * (2^nbits - 1)`.
                    // FIXME: LLVM оптимізує це в АЦП або подібне?
                    let v = (self as $bigty) * (other as $bigty) + (carry as $bigty);
                    ((v >> <$ty>::BITS) as $ty, v as $ty)
                }

                fn full_mul_add(self, other: $ty, other2: $ty, carry: $ty) -> ($ty, $ty) {
                    // Це не може переповнюватися;
                    // вихід знаходиться між `0` і `2^nbits * (2^nbits - 1)`.
                    let v = (self as $bigty) * (other as $bigty) + (other2 as $bigty) +
                            (carry as $bigty);
                    ((v >> <$ty>::BITS) as $ty, v as $ty)
                }

                fn full_div_rem(self, other: $ty, borrow: $ty) -> ($ty, $ty) {
                    debug_assert!(borrow < other);
                    // Це не може переповнюватися;вихід знаходиться між `0` і `other * (2^nbits - 1)`.
                    let lhs = ((borrow as $bigty) << <$ty>::BITS) | (self as $bigty);
                    let rhs = other as $bigty;
                    ((lhs / rhs) as $ty, (lhs % rhs) as $ty)
                }
            }
        )*
    )
}

impl_full_ops! {
    u8:  add(intrinsics::u8_add_with_overflow),  mul/div(u16);
    u16: add(intrinsics::u16_add_with_overflow), mul/div(u32);
    u32: add(intrinsics::u32_add_with_overflow), mul/div(u64);
    // Дивіться RFC #521, щоб увімкнути це.
    // u64: add(intrinsics::u64_add_with_overflow), mul/div(u128);
}

/// Таблиця ступенів 5, що представляються цифрами.Зокрема, найбільше значення {u8, u16, u32}, яке має ступінь п`яти, плюс відповідний показник.
/// Використовується в `mul_pow5`.
const SMALL_POW5: [(u64, usize); 3] = [(125, 3), (15625, 6), (1_220_703_125, 13)];

macro_rules! define_bignum {
    ($name:ident: type=$ty:ty, n=$n:expr) => {
        /// Ціле число довільної точності (до певної межі), виділене стеком.
        ///
        /// Це підтверджено масивом фіксованого розміру заданого типу ("digit").
        /// Незважаючи на те, що масив не дуже великий (зазвичай кілька сотень байт), необдумане його копіювання може призвести до досягнення продуктивності.
        ///
        /// Таким чином, це навмисно не `Copy`.
        ///
        /// Всі операції, доступні bignums panic у разі переливу.
        /// Той, хто телефонує, відповідає за використання досить великих типів bignum.
        pub struct $name {
            /// Один плюс зміщення до максимального використовуваного "digit".
            /// Це не зменшується, тому майте на увазі порядок обчислень.
            /// `base[size..]` має бути нульовим.
            size: usize,
            /// Digits.
            /// `[a, b, c, ...]` являє собою `a + b *2^W + c* 2^(2W) + ...`, де `W`-це кількість бітів у розрядному типі.
            base: [$ty; $n],
        }

        impl $name {
            /// Складає bignum з однієї цифри.
            pub fn from_small(v: $ty) -> $name {
                let mut base = [0; $n];
                base[0] = v;
                $name { size: 1, base: base }
            }

            /// Робить bignum зі значення `u64`.
            pub fn from_u64(mut v: u64) -> $name {
                let mut base = [0; $n];
                let mut sz = 0;
                while v > 0 {
                    base[sz] = v as $ty;
                    v >>= <$ty>::BITS;
                    sz += 1;
                }
                $name { size: sz, base: base }
            }

            /// Повертає внутрішні цифри у вигляді зрізу `[a, b, c, ...]` таким чином, що числовим значенням є `a + b *2^W + c* 2^(2W) + ...`, де `W`-це кількість бітів у типі цифр.
            ///
            ///
            pub fn digits(&self) -> &[$ty] {
                &self.base[..self.size]
            }

            /// Повертає `i`-й біт, де біт 0 є найменш значущим.
            /// Іншими словами, біт вагою `2^i`.
            pub fn get_bit(&self, i: usize) -> u8 {
                let digitbits = <$ty>::BITS as usize;
                let d = i / digitbits;
                let b = i % digitbits;
                ((self.base[d] >> b) & 1) as u8
            }

            /// Повертає `true`, якщо bignum дорівнює нулю.
            pub fn is_zero(&self) -> bool {
                self.digits().iter().all(|&v| v == 0)
            }

            /// Повертає кількість бітів, необхідну для представлення цього значення.
            /// Зверніть увагу, що вважається, що нулю потрібно 0 біт.
            pub fn bit_length(&self) -> usize {
                // Пропустіть найбільш значущі цифри, які дорівнюють нулю.
                let digits = self.digits();
                let zeros = digits.iter().rev().take_while(|&&x| x == 0).count();
                let end = digits.len() - zeros;
                let nonzero = &digits[..end];

                if nonzero.is_empty() {
                    // Не буває ненульових цифр, тобто число дорівнює нулю.
                    return 0;
                }
                // Це можна оптимізувати за допомогою leading_zeros() і бітових зрушень, але це, мабуть, не варто клопоту.
                //
                let digitbits = <$ty>::BITS as usize;
                let mut i = nonzero.len() * digitbits - 1;
                while self.get_bit(i) == 0 {
                    i -= 1;
                }
                i + 1
            }

            /// Додає `other` до себе і повертає власну змінну посилання.
            pub fn add<'a>(&'a mut self, other: &$name) -> &'a mut $name {
                use crate::cmp;
                use crate::num::bignum::FullOps;

                let mut sz = cmp::max(self.size, other.size);
                let mut carry = false;
                for (a, b) in self.base[..sz].iter_mut().zip(&other.base[..sz]) {
                    let (c, v) = (*a).full_add(*b, carry);
                    *a = v;
                    carry = c;
                }
                if carry {
                    self.base[sz] = 1;
                    sz += 1;
                }
                self.size = sz;
                self
            }

            pub fn add_small(&mut self, other: $ty) -> &mut $name {
                use crate::num::bignum::FullOps;

                let (mut carry, v) = self.base[0].full_add(other, false);
                self.base[0] = v;
                let mut i = 1;
                while carry {
                    let (c, v) = self.base[i].full_add(0, carry);
                    self.base[i] = v;
                    carry = c;
                    i += 1;
                }
                if i > self.size {
                    self.size = i;
                }
                self
            }

            /// Віднімає `other` від себе і повертає власну змінну посилання.
            pub fn sub<'a>(&'a mut self, other: &$name) -> &'a mut $name {
                use crate::cmp;
                use crate::num::bignum::FullOps;

                let sz = cmp::max(self.size, other.size);
                let mut noborrow = true;
                for (a, b) in self.base[..sz].iter_mut().zip(&other.base[..sz]) {
                    let (c, v) = (*a).full_add(!*b, noborrow);
                    *a = v;
                    noborrow = c;
                }
                assert!(noborrow);
                self.size = sz;
                self
            }

            /// Множить себе на `other` із цифровим розміром і повертає власне змінне посилання.
            ///
            pub fn mul_small(&mut self, other: $ty) -> &mut $name {
                use crate::num::bignum::FullOps;

                let mut sz = self.size;
                let mut carry = 0;
                for a in &mut self.base[..sz] {
                    let (c, v) = (*a).full_mul(other, carry);
                    *a = v;
                    carry = c;
                }
                if carry > 0 {
                    self.base[sz] = carry;
                    sz += 1;
                }
                self.size = sz;
                self
            }

            /// Множить себе на `2^bits` і повертає власне змінне посилання.
            pub fn mul_pow2(&mut self, bits: usize) -> &mut $name {
                let digitbits = <$ty>::BITS as usize;
                let digits = bits / digitbits;
                let bits = bits % digitbits;

                assert!(digits < $n);
                debug_assert!(self.base[$n - digits..].iter().all(|&v| v == 0));
                debug_assert!(bits == 0 || (self.base[$n - digits - 1] >> (digitbits - bits)) == 0);

                // зсув на біти `digits * digitbits`
                for i in (0..self.size).rev() {
                    self.base[i + digits] = self.base[i];
                }
                for i in 0..digits {
                    self.base[i] = 0;
                }

                // зсув на біти `bits`
                let mut sz = self.size + digits;
                if bits > 0 {
                    let last = sz;
                    let overflow = self.base[last - 1] >> (digitbits - bits);
                    if overflow > 0 {
                        self.base[last] = overflow;
                        sz += 1;
                    }
                    for i in (digits + 1..last).rev() {
                        self.base[i] =
                            (self.base[i] << bits) | (self.base[i - 1] >> (digitbits - bits));
                    }
                    self.base[digits] <<= bits;
                    // self.base [.. цифри] дорівнює нулю, не потрібно зміщувати
                }

                self.size = sz;
                self
            }

            /// Множить себе на `5^e` і повертає власне змінне посилання.
            pub fn mul_pow5(&mut self, mut e: usize) -> &mut $name {
                use crate::mem;
                use crate::num::bignum::SMALL_POW5;

                // На 2 ^ n є рівно n кінцевих нулів, і єдиними відповідними розмірами цифр є послідовні степені двох, тому це дуже підходить індекс для таблиці.
                //
                let table_index = mem::size_of::<$ty>().trailing_zeros() as usize;
                let (small_power, small_e) = SMALL_POW5[table_index];
                let small_power = small_power as $ty;

                // Помножте на найбільшу однозначну потужність якомога довше ...
                while e >= small_e {
                    self.mul_small(small_power);
                    e -= small_e;
                }

                // ... потім допишіть решту.
                let mut rest_power = 1;
                for _ in 0..e {
                    rest_power *= 5;
                }
                self.mul_small(rest_power);

                self
            }

            /// Множить себе на число, описане `other[0] + other[1]*2^W + other[2]* 2^(2W) + ...` (де `W`-це кількість бітів у розрядному типі), і повертає власне змінне посилання.
            ///
            ///
            pub fn mul_digits<'a>(&'a mut self, other: &[$ty]) -> &'a mut $name {
                // внутрішній розпорядок дня.найкраще працює, коли aa.len() <= bb.len().
                fn mul_inner(ret: &mut [$ty; $n], aa: &[$ty], bb: &[$ty]) -> usize {
                    use crate::num::bignum::FullOps;

                    let mut retsz = 0;
                    for (i, &a) in aa.iter().enumerate() {
                        if a == 0 {
                            continue;
                        }
                        let mut sz = bb.len();
                        let mut carry = 0;
                        for (j, &b) in bb.iter().enumerate() {
                            let (c, v) = a.full_mul_add(b, ret[i + j], carry);
                            ret[i + j] = v;
                            carry = c;
                        }
                        if carry > 0 {
                            ret[i + sz] = carry;
                            sz += 1;
                        }
                        if retsz < i + sz {
                            retsz = i + sz;
                        }
                    }
                    retsz
                }

                let mut ret = [0; $n];
                let retsz = if self.size < other.len() {
                    mul_inner(&mut ret, &self.digits(), other)
                } else {
                    mul_inner(&mut ret, other, &self.digits())
                };
                self.base = ret;
                self.size = retsz;
                self
            }

            /// Ділиться на `other` цифровим розміром і повертає власні змінні посилання *та* залишок.
            ///
            pub fn div_rem_small(&mut self, other: $ty) -> (&mut $name, $ty) {
                use crate::num::bignum::FullOps;

                assert!(other > 0);

                let sz = self.size;
                let mut borrow = 0;
                for a in self.base[..sz].iter_mut().rev() {
                    let (q, r) = (*a).full_div_rem(other, borrow);
                    *a = q;
                    borrow = r;
                }
                (self, borrow)
            }

            /// Поділіть self на інший bignum, замінивши `q` на частку та `r` на залишок.
            ///
            pub fn div_rem(&self, d: &$name, q: &mut $name, r: &mut $name) {
                // Дурний повільний довгий поділ base-2 взято з
                // https://en.wikipedia.org/wiki/Division_algorithm
                // FIXME використовує більшу базу ($ty) для довгого поділу.
                assert!(!d.is_zero());
                let digitbits = <$ty>::BITS as usize;
                for digit in &mut q.base[..] {
                    *digit = 0;
                }
                for digit in &mut r.base[..] {
                    *digit = 0;
                }
                r.size = d.size;
                q.size = 1;
                let mut q_is_zero = true;
                let end = self.bit_length();
                for i in (0..end).rev() {
                    r.mul_pow2(1);
                    r.base[0] |= self.get_bit(i) as $ty;
                    if &*r >= d {
                        r.sub(d);
                        // Встановіть біт `i` q на 1.
                        let digit_idx = i / digitbits;
                        let bit_idx = i % digitbits;
                        if q_is_zero {
                            q.size = digit_idx + 1;
                            q_is_zero = false;
                        }
                        q.base[digit_idx] |= 1 << bit_idx;
                    }
                }
                debug_assert!(q.base[q.size..].iter().all(|&d| d == 0));
                debug_assert!(r.base[r.size..].iter().all(|&d| d == 0));
            }
        }

        impl crate::cmp::PartialEq for $name {
            fn eq(&self, other: &$name) -> bool {
                self.base[..] == other.base[..]
            }
        }

        impl crate::cmp::Eq for $name {}

        impl crate::cmp::PartialOrd for $name {
            fn partial_cmp(&self, other: &$name) -> crate::option::Option<crate::cmp::Ordering> {
                crate::option::Option::Some(self.cmp(other))
            }
        }

        impl crate::cmp::Ord for $name {
            fn cmp(&self, other: &$name) -> crate::cmp::Ordering {
                use crate::cmp::max;
                let sz = max(self.size, other.size);
                let lhs = self.base[..sz].iter().cloned().rev();
                let rhs = other.base[..sz].iter().cloned().rev();
                lhs.cmp(rhs)
            }
        }

        impl crate::clone::Clone for $name {
            fn clone(&self) -> Self {
                Self { size: self.size, base: self.base }
            }
        }

        impl crate::fmt::Debug for $name {
            fn fmt(&self, f: &mut crate::fmt::Formatter<'_>) -> crate::fmt::Result {
                let sz = if self.size < 1 { 1 } else { self.size };
                let digitlen = <$ty>::BITS as usize / 4;

                write!(f, "{:#x}", self.base[sz - 1])?;
                for &v in self.base[..sz - 1].iter().rev() {
                    write!(f, "_{:01$x}", v, digitlen)?;
                }
                crate::result::Result::Ok(())
            }
        }
    };
}

/// Тип цифри для `Big32x40`.
pub type Digit32 = u32;

define_bignum!(Big32x40: type=Digit32, n=40);

// цей використовується лише для тестування.
#[doc(hidden)]
pub mod tests {
    define_bignum!(Big8x3: type=u8, n=3);
}