//! Типи помилок для перетворення на цілісні типи.

use crate::convert::Infallible;
use crate::fmt;

/// Тип помилки повертається, коли перевірений інтегральний тип перетворення не вдається.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Debug, Copy, Clone, PartialEq, Eq)]
pub struct TryFromIntError(pub(crate) ());

impl TryFromIntError {
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        "out of range integral type conversion attempted"
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for TryFromIntError {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(fmt)
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl From<Infallible> for TryFromIntError {
    fn from(x: Infallible) -> TryFromIntError {
        match x {}
    }
}

#[unstable(feature = "never_type", issue = "35121")]
impl From<!> for TryFromIntError {
    fn from(never: !) -> TryFromIntError {
        // Підбирайте, а не примушуйте, щоб переконатися, що код, як `From<Infallible> for TryFromIntError` вище, буде продовжувати працювати, коли `Infallible` стане псевдонімом `!`.
        //
        //
        match never {}
    }
}

/// Помилка, яку можна повернути при розборі цілого числа.
///
/// Ця помилка використовується як тип помилки для функцій `from_str_radix()` на примітивних цілих типах, таких як [`i8::from_str_radix`].
///
/// # Потенційні причини
///
/// Серед інших причин `ParseIntError` може бути викинуто через пробіли, що ведуть або відстають у рядку, наприклад, коли він отриманий із стандартного вводу.
///
/// Використання методу [`str::trim()`] гарантує, що перед розбором не залишається пробілів.
///
/// # Example
///
/// ```
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {}", e);
/// }
/// ```
///
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseIntError {
    pub(super) kind: IntErrorKind,
}

/// Enum для зберігання різних типів помилок, які можуть спричинити помилку аналізу цілого числа.
///
/// # Example
///
/// ```
/// #![feature(int_error_matching)]
///
/// # fn main() {
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {:?}", e.kind());
/// }
/// # }
/// ```
#[unstable(
    feature = "int_error_matching",
    reason = "it can be useful to match errors when making error messages \
              for integer parsing",
    issue = "22639"
)]
#[derive(Debug, Clone, PartialEq, Eq)]
#[non_exhaustive]
pub enum IntErrorKind {
    /// Значення, яке аналізується, порожнє.
    ///
    /// Серед інших причин цей варіант буде побудований при синтаксичному аналізі порожнього рядка.
    Empty,
    /// Містить неприпустиму цифру у своєму контексті.
    ///
    /// Серед інших причин, цей варіант буде побудований при синтаксичному аналізі рядка, що містить символ, що не є ASCII.
    ///
    /// Цей варіант також створюється, коли `+` або `-` неправильно розміщується в рядку як самостійно, так і в середині числа.
    ///
    ///
    InvalidDigit,
    /// Ціле число завелике для зберігання у цільовому цілочисельному типі.
    PosOverflow,
    /// Ціле число є замалим для зберігання у цільовому цілочисельному типі.
    NegOverflow,
    /// Значення було нульовим
    ///
    /// Цей варіант буде випущений, коли рядок синтаксичного аналізу має значення нуль, що буде незаконним для ненульових типів.
    ///
    Zero,
}

impl ParseIntError {
    /// Виводить детальну причину синтаксичного розбору цілого числа.
    #[unstable(
        feature = "int_error_matching",
        reason = "it can be useful to match errors when making error messages \
              for integer parsing",
        issue = "22639"
    )]
    pub fn kind(&self) -> &IntErrorKind {
        &self.kind
    }
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            IntErrorKind::Empty => "cannot parse integer from empty string",
            IntErrorKind::InvalidDigit => "invalid digit found in string",
            IntErrorKind::PosOverflow => "number too large to fit in target type",
            IntErrorKind::NegOverflow => "number too small to fit in target type",
            IntErrorKind::Zero => "number would be zero for non-zero type",
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseIntError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}