//! Декодує значення з плаваючою комою на окремі частини та діапазони помилок.

use crate::num::dec2flt::rawfp::RawFloat;
use crate::num::FpCategory;

/// Розшифроване беззнакове кінцеве значення, таке що:
///
/// - Вихідне значення дорівнює `mant * 2^exp`.
///
/// - Будь-яке число від `(mant - minus)*2^exp` до `(mant + plus)* 2^exp` округляється до початкового значення.
/// Діапазон включений лише тоді, коли `inclusive` є `true`.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct Decoded {
    /// Масштабована мантиса.
    pub mant: u64,
    /// Нижній діапазон помилок.
    pub minus: u64,
    /// Верхній діапазон помилок.
    pub plus: u64,
    /// Спільний показник в основі 2.
    pub exp: i16,
    /// Істинно, якщо діапазон помилок включений.
    ///
    /// У IEEE 754 це вірно, коли початкова мантиса була парною.
    pub inclusive: bool,
}

/// Розкодоване беззнакове значення.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub enum FullDecoded {
    /// Not-a-number.
    Nan,
    /// Нескінченності, позитивні чи негативні.
    Infinite,
    /// Нуль, позитивний чи негативний.
    Zero,
    /// Кінцеві числа з подальшими декодованими полями.
    Finite(Decoded),
}

/// Тип з плаваючою комою, який можна `декодувати`d.
pub trait DecodableFloat: RawFloat + Copy {
    /// Мінімальне додатне нормоване значення.
    fn min_pos_norm_value() -> Self;
}

impl DecodableFloat for f32 {
    fn min_pos_norm_value() -> Self {
        f32::MIN_POSITIVE
    }
}

impl DecodableFloat for f64 {
    fn min_pos_norm_value() -> Self {
        f64::MIN_POSITIVE
    }
}

/// Повертає знак (істина при негативному значенні) і значення `FullDecoded` із заданого числа з плаваючою комою.
///
pub fn decode<T: DecodableFloat>(v: T) -> (/*negative?*/ bool, FullDecoded) {
    let (mant, exp, sign) = v.integer_decode();
    let even = (mant & 1) == 0;
    let decoded = match v.classify() {
        FpCategory::Nan => FullDecoded::Nan,
        FpCategory::Infinite => FullDecoded::Infinite,
        FpCategory::Zero => FullDecoded::Zero,
        FpCategory::Subnormal => {
            // сусіди: (mant, 2, exp)-(mant, exp)-(mant + 2, exp)
            // Float::integer_decode завжди зберігає показник експоненти, тому мантиса масштабується для субнормальних.
            //
            FullDecoded::Finite(Decoded { mant, minus: 1, plus: 1, exp, inclusive: even })
        }
        FpCategory::Normal => {
            let minnorm = <T as DecodableFloat>::min_pos_norm_value().integer_decode();
            if mant == minnorm.0 {
                // сусіди: (maxmant, exp, 1)-(minnormmant, exp)-(minnormmant + 1, exp)
                // де maxmant=minnormmant * 2, 1
                FullDecoded::Finite(Decoded {
                    mant: mant << 2,
                    minus: 1,
                    plus: 2,
                    exp: exp - 2,
                    inclusive: even,
                })
            } else {
                // сусіди: (mant, 1, exp)-(mant, exp)-(mant + 1, exp)
                FullDecoded::Finite(Decoded {
                    mant: mant << 1,
                    minus: 1,
                    plus: 1,
                    exp: exp - 1,
                    inclusive: even,
                })
            }
        }
    };
    (sign < 0, decoded)
}