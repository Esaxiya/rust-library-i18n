//! Перевірка та розкладання десяткового рядка форми:
//!
//! `(digits | digits? '.'? digits?) (('e' | 'E') ('+' | '-')? digits)?`
//!
//! Іншими словами, стандартний синтаксис із плаваючою комою, за двома винятками: відсутність знаку та відсутність обробки "inf" та "NaN".Вони обробляються функцією драйвера (super::dec2flt).
//!
//! Незважаючи на те, що розпізнавання дійсних входів є відносно простим, цей модуль також повинен відкидати незліченні недійсні варіації, ніколи не panic, та виконувати численні перевірки, на які інші модулі покладаються, а не panic (або переповнення).
//!
//! Що ще гірше, все, що відбувається за один прохід над введеними даними.
//! Тож будьте обережні, змінюючи щось, і перевірте з іншими модулями.
//!
//!
use self::ParseResult::{Invalid, ShortcutToInf, ShortcutToZero, Valid};
use super::num;

#[derive(Debug)]
pub enum Sign {
    Positive,
    Negative,
}

#[derive(Debug, PartialEq, Eq)]
/// Цікаві частини десяткового рядка.
pub struct Decimal<'a> {
    pub integral: &'a [u8],
    pub fractional: &'a [u8],
    /// Десятковий показник, гарантовано мати менше 18 десяткових цифр.
    pub exp: i64,
}

impl<'a> Decimal<'a> {
    pub fn new(integral: &'a [u8], fractional: &'a [u8], exp: i64) -> Decimal<'a> {
        Decimal { integral, fractional, exp }
    }
}

#[derive(Debug, PartialEq, Eq)]
pub enum ParseResult<'a> {
    Valid(Decimal<'a>),
    ShortcutToInf,
    ShortcutToZero,
    Invalid,
}

/// Перевіряє, чи є вхідний рядок дійсним числом із плаваючою комою, і якщо так, знайдіть у ньому інтегральну частину, дробову частину та показник ступеня.
/// Не обробляє знаки.
pub fn parse_decimal(s: &str) -> ParseResult<'_> {
    if s.is_empty() {
        return Invalid;
    }

    let s = s.as_bytes();
    let (integral, s) = eat_digits(s);

    match s.first() {
        None => Valid(Decimal::new(integral, b"", 0)),
        Some(&b'e' | &b'E') => {
            if integral.is_empty() {
                return Invalid; // Немає цифр до 'e'
            }

            parse_exp(integral, b"", &s[1..])
        }
        Some(&b'.') => {
            let (fractional, s) = eat_digits(&s[1..]);
            if integral.is_empty() && fractional.is_empty() {
                // Нам потрібна принаймні одна цифра до або після точки.
                return Invalid;
            }

            match s.first() {
                None => Valid(Decimal::new(integral, fractional, 0)),
                Some(&b'e' | &b'E') => parse_exp(integral, fractional, &s[1..]),
                _ => Invalid, // Закінчується сміття після дробової частини
            }
        }
        _ => Invalid, // Закінчується сміття після першої цифри
    }
}

/// Висікає десяткові цифри до першого нецифрового символу.
fn eat_digits(s: &[u8]) -> (&[u8], &[u8]) {
    let pos = s.iter().position(|c| !c.is_ascii_digit()).unwrap_or(s.len());
    s.split_at(pos)
}

/// Витяг експоненти та перевірка помилок.
fn parse_exp<'a>(integral: &'a [u8], fractional: &'a [u8], rest: &'a [u8]) -> ParseResult<'a> {
    let (sign, rest) = match rest.first() {
        Some(&b'-') => (Sign::Negative, &rest[1..]),
        Some(&b'+') => (Sign::Positive, &rest[1..]),
        _ => (Sign::Positive, rest),
    };
    let (mut number, trailing) = eat_digits(rest);
    if !trailing.is_empty() {
        return Invalid; // Закінчується сміття за показником
    }
    if number.is_empty() {
        return Invalid; // Порожній показник степеня
    }
    // На даний момент ми, безперечно, маємо дійсний рядок цифр.Можливо, це занадто довго, щоб помістити в `i64`, але якщо він такий величезний, вхідні дані, безумовно, дорівнюють нулю або нескінченності.
    // Оскільки кожен нуль у десяткових цифрах регулює показник ступеня лише на +/-1, при exp=10 ^ 18 вхідні дані повинні становити 17 екзабайт (!) нулів, щоб навіть віддалено наблизитись до скінченності.
    //
    // Це не зовсім той випадок використання, який нам потрібно задовольнити.
    //
    while number.first() == Some(&b'0') {
        number = &number[1..];
    }
    if number.len() >= 18 {
        return match sign {
            Sign::Positive => ShortcutToInf,
            Sign::Negative => ShortcutToZero,
        };
    }
    let abs_exp = num::from_str_unchecked(number);
    let e = match sign {
        Sign::Positive => abs_exp as i64,
        Sign::Negative => -(abs_exp as i64),
    };
    Valid(Decimal::new(integral, fractional, e))
}