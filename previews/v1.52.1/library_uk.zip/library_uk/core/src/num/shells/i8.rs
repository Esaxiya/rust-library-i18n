//! Константи для 8-розрядного цілочисельного типу зі знаком.
//!
//! *[See also the `i8` primitive type][i8].*
//!
//! Новий код повинен використовувати пов'язані константи безпосередньо для примітивного типу.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `i8`"
)]

int_module! { i8 }