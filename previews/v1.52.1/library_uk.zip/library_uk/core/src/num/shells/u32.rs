//! Константи для 32-розрядного цілочисельного типу без знака.
//!
//! *[See also the `u32` primitive type][u32].*
//!
//! Новий код повинен використовувати пов'язані константи безпосередньо для примітивного типу.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `u32`"
)]

int_module! { u32 }