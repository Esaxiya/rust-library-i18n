//! Константи для 128-розрядного цілочисельного типу зі знаком.
//!
//! *[See also the `i128` primitive type][i128].*
//!
//! Новий код повинен використовувати пов'язані константи безпосередньо для примітивного типу.

#![stable(feature = "i128", since = "1.26.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `i128`"
)]

int_module! { i128, #[stable(feature = "i128", since="1.26.0")] }