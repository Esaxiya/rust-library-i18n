//! Константи для 16-розрядного цілочисельного типу зі знаком.
//!
//! *[See also the `i16` primitive type][i16].*
//!
//! Новий код повинен використовувати пов'язані константи безпосередньо для примітивного типу.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `i16`"
)]

int_module! { i16 }