//! Визначає ітератор для масивів, що належить `IntoIter`.

use crate::{
    fmt,
    iter::{ExactSizeIterator, FusedIterator, TrustedLen},
    mem::{self, MaybeUninit},
    ops::Range,
    ptr,
};

/// Ітератор [array] за значенням.
#[stable(feature = "array_value_iter", since = "1.51.0")]
pub struct IntoIter<T, const N: usize> {
    /// Це масив, для якого ми робимо ітерацію.
    ///
    /// Елементи з індексом `i`, де `alive.start <= i < alive.end` ще не отримані, і є дійсними записами масиву.
    /// Елементи з індексами `i < alive.start` або `i >= alive.end` вже отримані і більше не повинні отримувати доступ до них!Ці мертві елементи можуть бути навіть у зовсім неініціалізованому стані!
    ///
    ///
    /// Отже, інваріантами є:
    /// - `data[alive]` є живим (тобто містить допустимі елементи)
    /// - `data[..alive.start]` і `data[alive.end..]` мертві (тобто елементи вже прочитані, і їх більше не можна торкатися!)
    ///
    ///
    ///
    data: [MaybeUninit<T>; N],

    /// Елементи в `data`, які ще не отримані.
    ///
    /// Invariants:
    /// - `alive.start <= alive.end`
    /// - `alive.end <= N`
    alive: Range<usize>,
}

impl<T, const N: usize> IntoIter<T, N> {
    /// Створює новий ітератор над заданим `array`.
    ///
    /// *Примітка*: цей метод може бути застарілим у future після [`IntoIterator` is implemented for arrays][array-into-iter].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::array;
    ///
    /// for value in array::IntoIter::new([1, 2, 3, 4, 5]) {
    ///     // Тип `value` тут `i32`, замість `&i32`
    ///     let _: i32 = value;
    /// }
    /// ```
    /// [array-into-iter]: https://github.com/rust-lang/rust/pull/65819
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn new(array: [T; N]) -> Self {
        // БЕЗПЕКА: Трансмутація тут насправді безпечна.Документи `MaybeUninit`
        // promise:
        //
        // > `MaybeUninit<T>` гарантовано мати однакові розміри та вирівнювання
        // > як `T`.
        //
        // У документах навіть показано перетворення з масиву `MaybeUninit<T>` на масив `T`.
        //
        //
        // При цьому ця ініціалізація задовольняє інваріанти.

        // FIXME(LukasKalbertodt): насправді використовуйте `mem::transmute` тут, як тільки він працює з const generics:
        //     `mem::transmute::<[T; N], [MaybeUninit<T>; N]>(array)`
        //
        // До цього часу ми можемо використовувати `mem::transmute_copy` для створення побітової копії як іншого типу, а потім забути `array`, щоб його не скинули.
        //
        //
        unsafe {
            let iter = Self { data: mem::transmute_copy(&array), alive: 0..N };
            mem::forget(array);
            iter
        }
    }

    /// Повертає незмінний фрагмент усіх елементів, які ще не отримані.
    ///
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_slice(&self) -> &[T] {
        // БЕЗПЕКА: Ми знаємо, що всі елементи в `alive` правильно ініціалізовані.
        unsafe {
            let slice = self.data.get_unchecked(self.alive.clone());
            MaybeUninit::slice_assume_init_ref(slice)
        }
    }

    /// Повертає змінний фрагмент усіх елементів, які ще не отримані.
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        // БЕЗПЕКА: Ми знаємо, що всі елементи в `alive` правильно ініціалізовані.
        unsafe {
            let slice = self.data.get_unchecked_mut(self.alive.clone());
            MaybeUninit::slice_assume_init_mut(slice)
        }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Iterator for IntoIter<T, N> {
    type Item = T;
    fn next(&mut self) -> Option<Self::Item> {
        // Отримайте наступний покажчик спереду.
        //
        // Збільшення `alive.start` на 1 зберігає інваріант щодо `alive`.
        // Однак, завдяки цій зміні, на короткий час зона живих вже не `data[alive]`, а `data[idx..alive.end]`.
        //
        self.alive.next().map(|idx| {
            // Зчитування елемента з масиву.
            // БЕЗПЕКА: `idx`-це показник колишньої області "alive" регіону
            // масив.Читання цього елемента означає, що `data[idx]` зараз вважається мертвим (тобто не чіпати).
            // Оскільки `idx` був початком живої зони, тепер жива зона знову є `data[alive]`, відновлюючи всі інваріанти.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        let len = self.len();
        (len, Some(len))
    }

    fn count(self) -> usize {
        self.len()
    }

    fn last(mut self) -> Option<Self::Item> {
        self.next_back()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> DoubleEndedIterator for IntoIter<T, N> {
    fn next_back(&mut self) -> Option<Self::Item> {
        // Отримайте наступний індекс із зворотного боку.
        //
        // Зменшення `alive.end` на 1 зберігає інваріант щодо `alive`.
        // Однак, завдяки цій зміні, на короткий час зона живих вже не `data[alive]`, а `data[alive.start..=idx]`.
        //
        self.alive.next_back().map(|idx| {
            // Зчитування елемента з масиву.
            // БЕЗПЕКА: `idx`-це показник колишньої області "alive" регіону
            // масив.Читання цього елемента означає, що `data[idx]` зараз вважається мертвим (тобто не чіпати).
            // Оскільки `idx` був кінцем зони живих, зона живих тепер знову є `data[alive]`, відновлюючи всі інваріанти.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Drop for IntoIter<T, N> {
    fn drop(&mut self) {
        // БЕЗПЕКА: Це безпечно: `as_mut_slice` повертає саме суб-фрагмент
        // елементів, які ще не переміщені і які залишаються для видалення.
        //
        unsafe { ptr::drop_in_place(self.as_mut_slice()) }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> ExactSizeIterator for IntoIter<T, N> {
    fn len(&self) -> usize {
        // Ніколи не завадить через інваріант `live.start <=
        // alive.end`.
        self.alive.end - self.alive.start
    }
    fn is_empty(&self) -> bool {
        self.alive.is_empty()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> FusedIterator for IntoIter<T, N> {}

// Ітератор справді повідомляє правильну довжину.
// Кількість елементів "alive" (які все одно будуть видані)-це довжина діапазону `alive`.
// Цей діапазон зменшується в довжину або в `next`, або в `next_back`.
// У цих методах воно завжди зменшується на 1, але лише у випадку повернення `Some(_)`.
#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
unsafe impl<T, const N: usize> TrustedLen for IntoIter<T, N> {}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: Clone, const N: usize> Clone for IntoIter<T, N> {
    fn clone(&self) -> Self {
        // Зауважте, нам насправді не потрібно збігатись з тим самим діапазоном живого, тому ми можемо просто клонувати в зміщення 0 незалежно від того, де знаходиться `self`.
        //
        let mut new = Self { data: MaybeUninit::uninit_array(), alive: 0..0 };

        // Клонуйте всі живі елементи.
        for (src, dst) in self.as_slice().iter().zip(&mut new.data) {
            // Впишіть клон у новий масив, а потім оновіть його діапазон.
            // Якщо клонувати panics, ми правильно скинемо попередні елементи.
            dst.write(src.clone());
            new.alive.end += 1;
        }

        new
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: fmt::Debug, const N: usize> fmt::Debug for IntoIter<T, N> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Друкуйте лише ті елементи, які ще не були отримані: ми більше не можемо отримати доступ до отриманих елементів.
        //
        f.debug_tuple("IntoIter").field(&self.as_slice()).finish()
    }
}