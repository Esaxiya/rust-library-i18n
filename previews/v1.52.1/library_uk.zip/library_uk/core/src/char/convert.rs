//! Перетворення символів.

use crate::convert::TryFrom;
use crate::fmt;
use crate::mem::transmute;
use crate::str::FromStr;

use super::MAX;

/// Перетворює `u32` на `char`.
///
/// Зверніть увагу, що всі [`char`] s є дійсними [`u32`] s, і їх можна відтворити на один з
/// `as`:
///
/// ```
/// let c = '💯';
/// let i = c as u32;
///
/// assert_eq!(128175, i);
/// ```
///
/// Однак зворотне не відповідає дійсності: не всі дійсні [`u32`] s є дійсними [`char`] s.
/// `from_u32()` поверне `None`, якщо введення не є дійсним значенням для [`char`].
///
/// Небезпечну версію цієї функції, яка ігнорує ці перевірки, див. У розділі [`from_u32_unchecked`].
///
///
/// # Examples
///
/// Основне використання:
///
/// ```
/// use std::char;
///
/// let c = char::from_u32(0x2764);
///
/// assert_eq!(Some('❤'), c);
/// ```
///
/// Повернення `None`, коли введення не є дійсним [`char`]:
///
/// ```
/// use std::char;
///
/// let c = char::from_u32(0x110000);
///
/// assert_eq!(None, c);
/// ```
///
#[doc(alias = "chr")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_u32(i: u32) -> Option<char> {
    char::try_from(i).ok()
}

/// Перетворює `u32` на `char`, ігноруючи дійсність.
///
/// Зверніть увагу, що всі [`char`] s є дійсними [`u32`] s, і їх можна відтворити на один з
/// `as`:
///
/// ```
/// let c = '💯';
/// let i = c as u32;
///
/// assert_eq!(128175, i);
/// ```
///
/// Однак зворотне не відповідає дійсності: не всі дійсні [`u32`] s є дійсними [`char`] s.
/// `from_u32_unchecked()` буде ігнорувати це і сліпо перекидати на [`char`], можливо створивши недійсний.
///
///
/// # Safety
///
/// Ця функція небезпечна, оскільки може створювати недійсні значення `char`.
///
/// Безпечну версію цієї функції див. У функції [`from_u32`].
///
/// # Examples
///
/// Основне використання:
///
/// ```
/// use std::char;
///
/// let c = unsafe { char::from_u32_unchecked(0x2764) };
///
/// assert_eq!('❤', c);
/// ```
#[inline]
#[stable(feature = "char_from_unchecked", since = "1.5.0")]
pub unsafe fn from_u32_unchecked(i: u32) -> char {
    // БЕЗПЕКА: абонент повинен гарантувати, що `i` є дійсним значенням символу.
    if cfg!(debug_assertions) { char::from_u32(i).unwrap() } else { unsafe { transmute(i) } }
}

#[stable(feature = "char_convert", since = "1.13.0")]
impl From<char> for u32 {
    /// Перетворює [`char`] у [`u32`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = 'c';
    /// let u = u32::from(c);
    /// assert!(4 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        c as u32
    }
}

#[stable(feature = "more_char_conversions", since = "1.51.0")]
impl From<char> for u64 {
    /// Перетворює [`char`] у [`u64`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = '👤';
    /// let u = u64::from(c);
    /// assert!(8 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        // Значок char відливається до значення кодової точки, а потім розширюється до нуля до 64 біта.
        // Див. [https://doc.rust-lang.org/reference/expressions/operator-expr.html#semantics]
        c as u64
    }
}

#[stable(feature = "more_char_conversions", since = "1.51.0")]
impl From<char> for u128 {
    /// Перетворює [`char`] у [`u128`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = '⚙';
    /// let u = u128::from(c);
    /// assert!(16 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        // Значок char відливається до значення кодової точки, а потім розширюється до нуля до 128 біт.
        // Див. [https://doc.rust-lang.org/reference/expressions/operator-expr.html#semantics]
        c as u128
    }
}

/// Позначає байт в 0x00 ..=0xFF в `char`, кодова точка якого має однакове значення, в U + 0000 ..=U + 00FF.
///
/// Unicode розроблений таким чином, що він ефективно декодує байти за допомогою кодування символів, яке IANA називає ISO-8859-1.
/// Це кодування сумісне з ASCII.
///
/// Зауважте, що це відрізняється від ISO/IEC 8859-1 aka
/// ISO 8859-1 (з одним дефісом менше), який залишає деякі байтові значення "blanks", не присвоєні жодному символу.
/// ISO-8859-1 (IANA) присвоює їх контрольним кодам C0 та C1.
///
/// Зверніть увагу, що це *також* відрізняється від Windows-1252 aka
/// кодова сторінка 1252, яка є надмножиною ISO/IEC 8859-1, яка присвоює деякі (не всі!) порожні місця пунктуації та різні латинські символи.
///
/// Щоб ще більше заплутати речі, [on the Web](https://encoding.spec.whatwg.org/) `ascii`, `iso-8859-1` та `windows-1252`-це псевдоніми для надмножини Windows-1252, яка заповнює решту порожніх місць відповідними кодами керування C0 та C1.
///
///
///
///
///
#[stable(feature = "char_convert", since = "1.13.0")]
impl From<u8> for char {
    /// Перетворює [`u8`] у [`char`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let u = 32 as u8;
    /// let c = char::from(u);
    /// assert!(4 == mem::size_of_val(&c))
    /// ```
    #[inline]
    fn from(i: u8) -> Self {
        i as char
    }
}

/// Помилка, яку можна повернути при розборі символу.
#[stable(feature = "char_from_str", since = "1.20.0")]
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct ParseCharError {
    kind: CharErrorKind,
}

impl ParseCharError {
    #[unstable(
        feature = "char_error_internals",
        reason = "this method should not be available publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            CharErrorKind::EmptyString => "cannot parse char from empty string",
            CharErrorKind::TooManyChars => "too many characters in string",
        }
    }
}

#[derive(Copy, Clone, Debug, PartialEq, Eq)]
enum CharErrorKind {
    EmptyString,
    TooManyChars,
}

#[stable(feature = "char_from_str", since = "1.20.0")]
impl fmt::Display for ParseCharError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}

#[stable(feature = "char_from_str", since = "1.20.0")]
impl FromStr for char {
    type Err = ParseCharError;

    #[inline]
    fn from_str(s: &str) -> Result<Self, Self::Err> {
        let mut chars = s.chars();
        match (chars.next(), chars.next()) {
            (None, _) => Err(ParseCharError { kind: CharErrorKind::EmptyString }),
            (Some(c), None) => Ok(c),
            _ => Err(ParseCharError { kind: CharErrorKind::TooManyChars }),
        }
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl TryFrom<u32> for char {
    type Error = CharTryFromError;

    #[inline]
    fn try_from(i: u32) -> Result<Self, Self::Error> {
        if (i > MAX as u32) || (i >= 0xD800 && i <= 0xDFFF) {
            Err(CharTryFromError(()))
        } else {
            // БЕЗПЕКА: перевірено, що це юридичне значення Unicode
            Ok(unsafe { transmute(i) })
        }
    }
}

/// Тип помилки, що повертається, коли перетворення з u32 на char не вдається.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct CharTryFromError(());

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for CharTryFromError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        "converted integer out of range for `char`".fmt(f)
    }
}

/// Перетворює цифру в заданому радіусі в `char`.
///
/// 'radix' тут іноді також називають 'base'.
/// Радікс два вказує двійкове число, радіус десять, десятковий і радіус шістнадцять, шістнадцяткове, щоб дати деякі загальні значення.
///
/// Підтримуються довільні радики.
///
/// `from_digit()` поверне `None`, якщо введене значення не є цифрою в заданому радіусі.
///
/// # Panics
///
/// Panics, якщо задано радіус, більший за 36.
///
/// # Examples
///
/// Основне використання:
///
/// ```
/// use std::char;
///
/// let c = char::from_digit(4, 10);
///
/// assert_eq!(Some('4'), c);
///
/// // Десяткове число 11-це одна цифра в основі 16
/// let c = char::from_digit(11, 16);
///
/// assert_eq!(Some('b'), c);
/// ```
///
/// Повернення `None`, коли введення не є цифрою:
///
/// ```
/// use std::char;
///
/// let c = char::from_digit(20, 10);
///
/// assert_eq!(None, c);
/// ```
///
/// Пропускаючи великий радіус, викликаючи panic:
///
/// ```should_panic
/// use std::char;
///
/// // this panics
/// let c = char::from_digit(1, 37);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_digit(num: u32, radix: u32) -> Option<char> {
    if radix > 36 {
        panic!("from_digit: radix is too high (maximum 36)");
    }
    if num < radix {
        let num = num as u8;
        if num < 10 { Some((b'0' + num) as char) } else { Some((b'a' + num - 10) as char) }
    } else {
        None
    }
}