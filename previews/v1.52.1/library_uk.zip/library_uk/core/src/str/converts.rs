//! Способи створення `str` із зрізу байтів.

use crate::mem;

use super::validations::run_utf8_validation;
use super::Utf8Error;

/// Перетворює фрагмент байтів у фрагмент рядка.
///
/// Зріз рядка ([`&str`]) складається з байтів ([`u8`]), а зріз байтів ([`&[u8]`][byteslice])-з байтів, тому ця функція перетворює між ними.
/// Не всі фрагменти байтів є дійсними фрагментами рядків, однак: [`&str`] вимагає, щоб це було дійсним UTF-8.
/// `from_utf8()` перевіряє, щоб байти були дійсними UTF-8, а потім виконує перетворення.
///
/// [`&str`]: str
/// [byteslice]: slice
///
/// Якщо ви впевнені, що фрагмент байту є дійсним UTF-8, і ви не хочете, щоб накладні витрати на перевірку дійсності існували, небезпечна версія цієї функції, [`from_utf8_unchecked`], яка має таку ж поведінку, але пропускає перевірку.
///
///
/// Якщо вам потрібен `String` замість `&str`, розгляньте [`String::from_utf8`][string].
///
/// [string]: ../../std/string/struct.String.html#method.from_utf8
///
/// Оскільки ви можете виділити стек `[u8; N]` і можете взяти [`&[u8]`][byteslice], ця функція є одним із способів мати рядок, виділений стеком.Приклад цього є в розділі прикладів нижче.
///
/// [byteslice]: slice
///
/// # Errors
///
/// Повертає `Err`, якщо фрагмент не є UTF-8, з описом того, чому наданий фрагмент не є UTF-8.
///
/// # Examples
///
/// Основне використання:
///
/// ```
/// use std::str;
///
/// // кілька байтів, у vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // Ми знаємо, що ці байти є дійсними, тому просто використовуйте `unwrap()`.
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// Неправильні байти:
///
/// ```
/// use std::str;
///
/// // деякі недійсні байти в vector
/// let sparkle_heart = vec![0, 159, 146, 150];
///
/// assert!(str::from_utf8(&sparkle_heart).is_err());
/// ```
///
/// Докладніше про види помилок, які можна повернути, див. У документації до [`Utf8Error`].
///
/// A "stack allocated string":
///
/// ```
/// use std::str;
///
/// // кілька байтів у виділеному стеку масиві
/// let sparkle_heart = [240, 159, 146, 150];
///
/// // Ми знаємо, що ці байти є дійсними, тому просто використовуйте `unwrap()`.
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_utf8(v: &[u8]) -> Result<&str, Utf8Error> {
    run_utf8_validation(v)?;
    // БЕЗПЕКА: Щойно проведена перевірка.
    Ok(unsafe { from_utf8_unchecked(v) })
}

/// Перетворює змінний фрагмент байтів у змінний фрагмент рядка.
///
/// # Examples
///
/// Основне використання:
///
/// ```
/// use std::str;
///
/// // "Hello, Rust!" як змінний vector
/// let mut hellorust = vec![72, 101, 108, 108, 111, 44, 32, 82, 117, 115, 116, 33];
///
/// // Оскільки ми знаємо, що ці байти є дійсними, ми можемо використовувати `unwrap()`
/// let outstr = str::from_utf8_mut(&mut hellorust).unwrap();
///
/// assert_eq!("Hello, Rust!", outstr);
/// ```
///
/// Неправильні байти:
///
/// ```
/// use std::str;
///
/// // Деякі недійсні байти у змінному vector
/// let mut invalid = vec![128, 223];
///
/// assert!(str::from_utf8_mut(&mut invalid).is_err());
/// ```
/// Докладніше про види помилок, які можна повернути, див. У документації до [`Utf8Error`].
///
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub fn from_utf8_mut(v: &mut [u8]) -> Result<&mut str, Utf8Error> {
    run_utf8_validation(v)?;
    // БЕЗПЕКА: Щойно проведена перевірка.
    Ok(unsafe { from_utf8_unchecked_mut(v) })
}

/// Перетворює фрагмент байтів у фрагмент рядка, не перевіряючи, чи рядок містить дійсний UTF-8.
///
/// Для отримання додаткової інформації див. Безпечну версію [`from_utf8`].
///
/// # Safety
///
/// Ця функція небезпечна, оскільки не перевіряє, чи передані їй байти є дійсними UTF-8.
/// Якщо це обмеження порушено, виникає невизначена поведінка, оскільки решта Rust припускає, що [`&str`] s є дійсними UTF-8.
///
///
/// [`&str`]: str
///
/// # Examples
///
/// Основне використання:
///
/// ```
/// use std::str;
///
/// // кілька байтів, у vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// let sparkle_heart = unsafe {
///     str::from_utf8_unchecked(&sparkle_heart)
/// };
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_str_from_utf8_unchecked", issue = "75196")]
#[rustc_allow_const_fn_unstable(const_fn_transmute)]
pub const unsafe fn from_utf8_unchecked(v: &[u8]) -> &str {
    // БЕЗПЕКА: абонент повинен гарантувати, що байти `v` є дійсними UTF-8.
    // Також покладається на `&str` та `&[u8]`, що мають однаковий макет.
    unsafe { mem::transmute(v) }
}

/// Перетворює фрагмент байтів у фрагмент рядка, не перевіряючи, чи рядок містить дійсний UTF-8;змінна версія.
///
///
/// Докладнішу інформацію див. У незмінній версії [`from_utf8_unchecked()`].
///
/// # Examples
///
/// Основне використання:
///
/// ```
/// use std::str;
///
/// let mut heart = vec![240, 159, 146, 150];
/// let heart = unsafe { str::from_utf8_unchecked_mut(&mut heart) };
///
/// assert_eq!("💖", heart);
/// ```
#[inline]
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub unsafe fn from_utf8_unchecked_mut(v: &mut [u8]) -> &mut str {
    // БЕЗПЕКА: абонент повинен гарантувати, що байти `v`
    // є дійсними UTF-8, отже, переведення на `*mut str` є безпечним.
    // Крім того, призначення посилання на покажчик є безпечним, оскільки цей покажчик походить від посилання, яке гарантовано буде дійсним для записів.
    //
    unsafe { &mut *(v as *mut [u8] as *mut str) }
}