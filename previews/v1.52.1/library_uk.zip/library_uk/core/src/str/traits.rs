//! Реалізації Trait для `str`.

use crate::cmp::Ordering;
use crate::ops;
use crate::ptr;
use crate::slice::SliceIndex;

use super::ParseBoolError;

/// Реалізує впорядкування рядків.
///
/// Рядки упорядковані [lexicographically](Ord#lexicographical-comparison) за їх байтовими значеннями.
/// Це впорядковує кодові коди Юнікод на основі їхніх позицій у діаграмах коду.
/// Це не обов'язково те саме, що замовлення "alphabetical", яке залежить від мови та мови.
/// Для сортування рядків відповідно до прийнятих у культурі стандартів потрібні специфічні для локалі дані, що виходять за рамки типу `str`.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Ord for str {
    #[inline]
    fn cmp(&self, other: &str) -> Ordering {
        self.as_bytes().cmp(other.as_bytes())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for str {
    #[inline]
    fn eq(&self, other: &str) -> bool {
        self.as_bytes() == other.as_bytes()
    }
    #[inline]
    fn ne(&self, other: &str) -> bool {
        !(*self).eq(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Eq for str {}

/// Реалізує операції порівняння рядків.
///
/// Рядки порівнюються [lexicographically](Ord#lexicographical-comparison) за їхніми байтовими значеннями.
/// Це порівнює точки коду Unicode на основі їхніх позицій у діаграмах кодів.
/// Це не обов'язково те саме, що замовлення "alphabetical", яке залежить від мови та мови.
/// Порівняння рядків відповідно до прийнятих у культурі стандартів вимагає специфічних для локалі даних даних, що виходять за рамки типу `str`.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl PartialOrd for str {
    #[inline]
    fn partial_cmp(&self, other: &str) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::Index<I> for str
where
    I: SliceIndex<str>,
{
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &I::Output {
        index.index(self)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::IndexMut<I> for str
where
    I: SliceIndex<str>,
{
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut I::Output {
        index.index_mut(self)
    }
}

#[inline(never)]
#[cold]
#[track_caller]
fn str_index_overflow_fail() -> ! {
    panic!("attempted to index str up to maximum usize");
}

/// Реалізує нарізування підрядків із синтаксисом `&self[..]` або `&mut self[..]`.
///
/// Повертає фрагмент цілого рядка, тобто повертає `&self` або `&mut self`.Еквівалентно `&self [0 ..
/// len] `або`&mut self [0 ..
/// len]`.
/// На відміну від інших операцій індексування, це ніколи не може panic.
///
/// Ця операція *O*(1).
///
/// До 1.20.0 ці операції індексації все ще підтримувалися безпосередньою реалізацією `Index` та `IndexMut`.
///
/// Еквівалентно `&self[0 .. len]` або `&mut self[0 .. len]`.
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFull {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        Some(slice)
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        Some(slice)
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        slice
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        slice
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        slice
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        slice
    }
}

/// Реалізує нарізування підрядків із синтаксисом `&self[begin .. end]` або `&mut self[begin .. end]`.
///
/// Повертає фрагмент заданого рядка з діапазону байтів [`begin`, `end`).
///
/// Ця операція *O*(1).
///
/// До 1.20.0 ці операції індексації все ще підтримувалися безпосередньою реалізацією `Index` та `IndexMut`.
///
/// # Panics
///
/// Panics, якщо `begin` або `end` не вказує на зміщення початкового байта символу (як визначено `is_char_boundary`), якщо `begin > end` або якщо `end > len`.
///
///
/// # Examples
///
/// ```
/// let s = "Löwe 老虎 Léopard";
/// assert_eq!(&s[0 .. 1], "L");
///
/// assert_eq!(&s[1 .. 9], "öwe 老");
///
/// // це буде panic:
/// // байт 2 лежить в межах `ö`:
/// // &s [2 ..3];
///
/// // байт 8 лежить в межах `老`&s [1 ..
/// // 8];
///
/// // байт 100 знаходиться поза рядком&s [3 ..
/// // 100];
/// ```
///
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::Range<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // БЕЗПЕКА: щойно перевірили, що `start` та `end` знаходяться на межі знаків,
            // і ми передаємо безпечне посилання, тому повернене значення також буде одиницею.
            // Ми також перевірили межі знаків, тому це дійсний UTF-8.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // БЕЗПЕКА: просто перевірили, що `start` та `end` знаходяться на межі знаків.
            // Ми знаємо, що вказівник унікальний, оскільки ми отримали його від `slice`.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // БЕЗПЕКА: абонент гарантує, що `self` знаходиться в межах `slice`
        // який задовольняє всім умовам для `add`.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // БЕЗПЕКА: див. Коментарі до `get_unchecked`.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, self.end);
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        // is_char_boundary перевіряє наявність індексу в [0, .len()] не може повторно використовувати `get`, як зазначено вище, через проблему NLL
        //
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // БЕЗПЕКА: щойно перевірили, що `start` та `end` знаходяться на межі знаків,
            // і ми передаємо безпечне посилання, тому повернене значення також буде одиницею.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, self.end)
        }
    }
}

/// Реалізує нарізування підрядків із синтаксисом `&self[.. end]` або `&mut self[.. end]`.
///
/// Повертає фрагмент заданого рядка з діапазону байтів [`0`, `end`).
/// Еквівалентно `&self[0 .. end]` або `&mut self[0 .. end]`.
///
/// Ця операція *O*(1).
///
/// До 1.20.0 ці операції індексації все ще підтримувалися безпосередньою реалізацією `Index` та `IndexMut`.
///
/// # Panics
///
/// Panics, якщо `end` не вказує на зміщення початкового байта символу (як визначено `is_char_boundary`), або якщо `end > len`.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeTo<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.end) {
            // БЕЗПЕКА: просто перевірив, що `end` знаходиться на межі знаків,
            // і ми передаємо безпечне посилання, тому повернене значення також буде одиницею.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.end) {
            // БЕЗПЕКА: просто перевірив, що `end` знаходиться на межі знаків,
            // і ми передаємо безпечне посилання, тому повернене значення також буде одиницею.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        let ptr = slice.as_ptr();
        ptr::slice_from_raw_parts(ptr, self.end) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        let ptr = slice.as_mut_ptr();
        ptr::slice_from_raw_parts_mut(ptr, self.end) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let end = self.end;
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, 0, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.end) {
            // БЕЗПЕКА: просто перевірив, що `end` знаходиться на межі знаків,
            // і ми передаємо безпечне посилання, тому повернене значення також буде одиницею.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, 0, self.end)
        }
    }
}

/// Реалізує нарізування підрядків із синтаксисом `&self[begin ..]` або `&mut self[begin ..]`.
///
/// Повертає фрагмент заданого рядка з діапазону байтів [`begin`, `len`).Еквівалентно `&self [почати ..
/// len] `або`&mut self [почати ..
/// len]`.
///
/// Ця операція *O*(1).
///
/// До 1.20.0 ці операції індексації все ще підтримувалися безпосередньою реалізацією `Index` та `IndexMut`.
///
/// # Panics
///
/// Panics, якщо `begin` не вказує на зміщення початкового байта символу (як визначено `is_char_boundary`), або якщо `begin > len`.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFrom<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.start) {
            // БЕЗПЕКА: просто перевірив, що `start` знаходиться на межі знаків,
            // і ми передаємо безпечне посилання, тому повернене значення також буде одиницею.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.start) {
            // БЕЗПЕКА: просто перевірив, що `start` знаходиться на межі знаків,
            // і ми передаємо безпечне посилання, тому повернене значення також буде одиницею.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // БЕЗПЕКА: абонент гарантує, що `self` знаходиться в межах `slice`
        // який задовольняє всім умовам для `add`.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // БЕЗПЕКА: ідентична `get_unchecked`.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, slice.len());
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.start) {
            // БЕЗПЕКА: просто перевірив, що `start` знаходиться на межі знаків,
            // і ми передаємо безпечне посилання, тому повернене значення також буде одиницею.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, slice.len())
        }
    }
}

/// Реалізує нарізування підрядків із синтаксисом `&self[begin ..= end]` або `&mut self[begin ..= end]`.
///
/// Повертає фрагмент заданого рядка з діапазону байт [`begin`, `end`].Еквівалентно `&self [begin .. end + 1]` або `&mut self[begin .. end + 1]`, за винятком випадків, коли `end` має максимальне значення для `usize`.
///
/// Ця операція *O*(1).
///
/// # Panics
///
/// Panics, якщо `begin` не вказує на зміщення початкового байта символу (як визначено `is_char_boundary`), якщо `end` не вказує на зміщення кінцевого байта символу (`end + 1`-або зміщення початкового байта, або рівне `len`), якщо `begin > end`, або якщо `end >= len`.
///
///
///
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // БЕЗПЕКА: абонент повинен виконувати контракт про безпеку для `get_unchecked`.
        unsafe { self.into_slice_range().get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // БЕЗПЕКА: абонент повинен виконувати контракт про безпеку для `get_unchecked_mut`.
        unsafe { self.into_slice_range().get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index_mut(slice)
    }
}

/// Реалізує нарізування підрядків із синтаксисом `&self[..= end]` або `&mut self[..= end]`.
///
/// Повертає фрагмент заданого рядка з діапазону байтів [0, `end`].
/// Еквівалентно `&self [0 .. end + 1]`, за винятком випадків, коли `end` має максимальне значення для `usize`.
///
/// Ця операція *O*(1).
///
/// # Panics
///
/// Panics, якщо `end` не вказує на кінцеве зміщення байтів символу (`end + 1`-це або початкове зміщення байтів, як визначено `is_char_boundary`, або дорівнює `len`), або якщо `end >= len`.
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeToInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // БЕЗПЕКА: абонент повинен виконувати контракт про безпеку для `get_unchecked`.
        unsafe { (..self.end + 1).get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // БЕЗПЕКА: абонент повинен виконувати контракт про безпеку для `get_unchecked_mut`.
        unsafe { (..self.end + 1).get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index_mut(slice)
    }
}

/// Проаналізуйте значення з рядка
///
/// Метод [`from_str`] `FromStr` часто використовується неявно через метод [`parse`] [`str`].
/// Приклади див. У документації [`parse`].
///
/// [`from_str`]: FromStr::from_str
/// [`parse`]: str::parse
///
/// `FromStr` не має параметра життя, і тому ви можете аналізувати лише ті типи, які самі не містять параметру життя.
///
/// Іншими словами, ви можете проаналізувати `i32` з `FromStr`, але не `&i32`.
/// Ви можете проаналізувати структуру, яка містить `i32`, але не таку, яка містить `&i32`.
///
/// # Examples
///
/// Базова реалізація `FromStr` на прикладі типу `Point`:
///
/// ```
/// use std::str::FromStr;
/// use std::num::ParseIntError;
///
/// #[derive(Debug, PartialEq)]
/// struct Point {
///     x: i32,
///     y: i32
/// }
///
/// impl FromStr for Point {
///     type Err = ParseIntError;
///
///     fn from_str(s: &str) -> Result<Self, Self::Err> {
///         let coords: Vec<&str> = s.trim_matches(|p| p == '(' || p == ')' )
///                                  .split(',')
///                                  .collect();
///
///         let x_fromstr = coords[0].parse::<i32>()?;
///         let y_fromstr = coords[1].parse::<i32>()?;
///
///         Ok(Point { x: x_fromstr, y: y_fromstr })
///     }
/// }
///
/// let p = Point::from_str("(1,2)");
/// assert_eq!(p.unwrap(), Point{ x: 1, y: 2} )
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait FromStr: Sized {
    /// Пов'язана помилка, яку можна повернути при розборі.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Err;

    /// Аналізує рядок `s`, щоб повернути значення цього типу.
    ///
    /// Якщо аналіз вдався, поверніть значення всередині [`Ok`], інакше, коли рядок неправильно відформатований, поверніть помилку, специфічну для внутрішньої [`Err`].
    /// Тип помилки специфічний для реалізації Portrait.
    ///
    /// # Examples
    ///
    /// Основне використання [`i32`], типу, що реалізує `FromStr`:
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// let s = "5";
    /// let x = i32::from_str(s).unwrap();
    ///
    /// assert_eq!(5, x);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_str(s: &str) -> Result<Self, Self::Err>;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for bool {
    type Err = ParseBoolError;

    /// Проаналізуйте `bool` із рядка.
    ///
    /// Утворює `Result<bool, ParseBoolError>`, оскільки `s` може або не може бути розбірним.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// assert_eq!(FromStr::from_str("true"), Ok(true));
    /// assert_eq!(FromStr::from_str("false"), Ok(false));
    /// assert!(<bool as FromStr>::from_str("not even a boolean").is_err());
    /// ```
    ///
    /// Зверніть увагу, що у багатьох випадках метод `.parse()` на `str` є більш правильним.
    ///
    /// ```
    /// assert_eq!("true".parse(), Ok(true));
    /// assert_eq!("false".parse(), Ok(false));
    /// assert!("not even a boolean".parse::<bool>().is_err());
    /// ```
    #[inline]
    fn from_str(s: &str) -> Result<bool, ParseBoolError> {
        match s {
            "true" => Ok(true),
            "false" => Ok(false),
            _ => Err(ParseBoolError { _priv: () }),
        }
    }
}