//! Визначає тип помилки utf8.

use crate::fmt;

/// Помилки, які можуть виникнути при спробі інтерпретувати послідовність [`u8`] як рядок.
///
/// Таким чином, сімейство функцій і методів `from_utf8` для [`String`] і [`&str`] використовує, наприклад, цю помилку.
///
/// [`String`]: ../../std/string/struct.String.html#method.from_utf8
/// [`&str`]: super::from_utf8
///
/// # Examples
///
/// Методи цього типу помилок можна використовувати для створення функціональних можливостей, подібних до `String::from_utf8_lossy`, без виділення купи пам'яті:
///
///
/// ```
/// fn from_utf8_lossy<F>(mut input: &[u8], mut push: F) where F: FnMut(&str) {
///     loop {
///         match std::str::from_utf8(input) {
///             Ok(valid) => {
///                 push(valid);
///                 break
///             }
///             Err(error) => {
///                 let (valid, after_valid) = input.split_at(error.valid_up_to());
///                 unsafe {
///                     push(std::str::from_utf8_unchecked(valid))
///                 }
///                 push("\u{FFFD}");
///
///                 if let Some(invalid_sequence_length) = error.error_len() {
///                     input = &after_valid[invalid_sequence_length..]
///                 } else {
///                     break
///                 }
///             }
///         }
///     }
/// }
/// ```
///
///
#[derive(Copy, Eq, PartialEq, Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Utf8Error {
    pub(super) valid_up_to: usize,
    pub(super) error_len: Option<u8>,
}

impl Utf8Error {
    /// Повертає індекс у даному рядку, до якого перевірено дійсний UTF-8.
    ///
    /// Це максимальний індекс, такий що `from_utf8(&input[..index])` повертає `Ok(_)`.
    ///
    ///
    /// # Examples
    ///
    /// Основне використання:
    ///
    /// ```
    /// use std::str;
    ///
    /// // деякі недійсні байти в vector
    /// let sparkle_heart = vec![0, 159, 146, 150];
    ///
    /// // std::str::from_utf8 повертає Utf8Error
    /// let error = str::from_utf8(&sparkle_heart).unwrap_err();
    ///
    /// // другий байт тут недійсний
    /// assert_eq!(1, error.valid_up_to());
    /// ```
    ///
    #[stable(feature = "utf8_error", since = "1.5.0")]
    #[inline]
    pub fn valid_up_to(&self) -> usize {
        self.valid_up_to
    }

    /// Надає додаткову інформацію про несправність:
    ///
    /// * `None`: кінець введення досягнуто несподівано.
    ///   `self.valid_up_to()` від 1 до 3 байт від кінця введення.
    ///   Якщо байтовий потік (наприклад, файл або мережевий сокет) декодується поступово, це може бути дійсний `char`, послідовність байтів якого UTF-8 охоплює кілька фрагментів.
    ///
    ///
    /// * `Some(len)`: був виявлений несподіваний байт.
    ///   Надана довжина-недійсної послідовності байтів, яка починається з індексу, заданого `valid_up_to()`.
    ///   Декодування слід відновити після цієї послідовності (після вставки [`U+FFFD REPLACEMENT CHARACTER`][U+FFFD]) у разі декодування з втратою.
    ///
    /// [U+FFFD]: ../../std/char/constant.REPLACEMENT_CHARACTER.html
    ///
    ///
    ///
    #[stable(feature = "utf8_error_error_len", since = "1.20.0")]
    #[inline]
    pub fn error_len(&self) -> Option<usize> {
        self.error_len.map(|len| len as usize)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for Utf8Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        if let Some(error_len) = self.error_len {
            write!(
                f,
                "invalid utf-8 sequence of {} bytes from index {}",
                error_len, self.valid_up_to
            )
        } else {
            write!(f, "incomplete utf-8 byte sequence from index {}", self.valid_up_to)
        }
    }
}

/// Помилка, повернута під час аналізу `bool` за допомогою [`from_str`], не вдається
///
/// [`from_str`]: super::FromStr::from_str
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseBoolError {
    pub(super) _priv: (),
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseBoolError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        "provided string was not `true` or `false`".fmt(f)
    }
}