//! Цей модуль реалізує `Any` Portrait, що дозволяє динамічно вводити текст будь-якого типу `'static` за допомогою відображення часу роботи.
//!
//! `Any` сам по собі може бути використаний для отримання `TypeId` і має більше можливостей, коли використовується як об'єкт Portrait.
//! Як `&dyn Any` (запозичений об'єкт Portrait), він має методи `is` та `downcast_ref`, щоб перевірити, чи містить значення вказаний тип, і отримати посилання на внутрішнє значення як тип.
//! Як і `&mut dyn Any`, існує також метод `downcast_mut` для отримання змінного посилання на внутрішнє значення.
//! `Box<dyn Any>` додає метод `downcast`, який намагається перетворити на `Box<T>`.
//! Повні відомості див. У документації [`Box`].
//!
//! Зауважте, що `&dyn Any` обмежується тестуванням того, чи має значення значення конкретного типу бетону, і не може використовуватися для перевірки того, чи тип реалізує Portrait.
//!
//! [`Box`]: ../../std/boxed/struct.Box.html
//!
//! # Розумні вказівники та `dyn Any`
//!
//! Варто пам`ятати, використовуючи `Any` як об`єкт Portrait, особливо з такими типами, як `Box<dyn Any>` або `Arc<dyn Any>`,-це те, що при простому виклику `.type_id()` за значенням створюється `TypeId` контейнера *, а не основний об`єкт Portrait.
//!
//! Цього можна уникнути, перетворивши натомість розумний вказівник у `&dyn Any`, який поверне об'єкт `TypeId`.
//! Наприклад:
//!
//! ```
//! use std::any::{Any, TypeId};
//!
//! let boxed: Box<dyn Any> = Box::new(3_i32);
//!
//! // Ви, швидше за все, захочете цього:
//! let actual_id = (&*boxed).type_id();
//! // ... ніж це:
//! let boxed_id = boxed.type_id();
//!
//! assert_eq!(actual_id, TypeId::of::<i32>());
//! assert_eq!(boxed_id, TypeId::of::<Box<dyn Any>>());
//! ```
//!
//! # Examples
//!
//! Розглянемо ситуацію, коли ми хочемо вийти зі значення, переданого функції.
//! Ми знаємо, над чим працюємо, реалізує Debug, але не знаємо його конкретного типу.Ми хочемо приділити особливу увагу певним типам: у цьому випадку роздруковуємо довжину рядкових значень до їх значення.
//! Ми не знаємо конкретного типу нашого значення під час компіляції, тому нам потрібно замість цього використовувати відображення часу виконання.
//!
//! ```rust
//! use std::fmt::Debug;
//! use std::any::Any;
//!
//! // Функція реєстратора для будь-якого типу, що реалізує налагодження.
//! fn log<T: Any + Debug>(value: &T) {
//!     let value_any = value as &dyn Any;
//!
//!     // Спробуйте перетворити наше значення на `String`.
//!     // У разі успіху ми хочемо вивести довжину рядка, а також його значення.
//!     // Якщо ні, то це інший тип: просто роздрукуйте його без прикрас.
//!     match value_any.downcast_ref::<String>() {
//!         Some(as_string) => {
//!             println!("String ({}): {}", as_string.len(), as_string);
//!         }
//!         None => {
//!             println!("{:?}", value);
//!         }
//!     }
//! }
//!
//! // Ця функція хоче вийти зі свого параметра, перш ніж працювати з нею.
//! fn do_work<T: Any + Debug>(value: &T) {
//!     log(value);
//!     // ... робити якусь іншу роботу
//! }
//!
//! fn main() {
//!     let my_string = "Hello World".to_string();
//!     do_work(&my_string);
//!
//!     let my_i8: i8 = 100;
//!     do_work(&my_i8);
//! }
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::intrinsics;

///////////////////////////////////////////////////////////////////////////////
// Будь-який Portrait
///////////////////////////////////////////////////////////////////////////////

/// A Portrait для емуляції динамічного набору тексту.
///
/// Більшість типів реалізують `Any`.Однак будь-який тип, який містить не `` статичне '' посилання, цього не робить.
/// Докладніше див. У [module-level documentation][mod].
///
/// [mod]: crate::any
// Цей Portrait не є небезпечним, хоча ми покладаємось на особливості функції `type_id` його єдиного імпульсу в небезпечному коді (наприклад, `downcast`).Зазвичай це було б проблемою, але оскільки єдиним імпульсом `Any` є загальна реалізація, жоден інший код не може реалізувати `Any`.
//
// Ми могли б зробити цей Portrait небезпечним-це не призвело б до поломки, оскільки ми контролюємо всі реалізації,-але ми вирішили не робити цього, оскільки це одночасно не є необхідним, і може заплутати користувачів щодо розрізнення небезпечних traits та небезпечних методів (тобто, `type_id` все одно буде безпечно зателефонувати, але ми, мабуть, хочемо вказати як такий у документації).
//
//
//
//
//
//
//
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Any: 'static {
    /// Отримує `TypeId` з `self`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string(s: &dyn Any) -> bool {
    ///     TypeId::of::<String>() == s.type_id()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "get_type_id", since = "1.34.0")]
    fn type_id(&self) -> TypeId;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: 'static + ?Sized> Any for T {
    fn type_id(&self) -> TypeId {
        TypeId::of::<T>()
    }
}

///////////////////////////////////////////////////////////////////////////////
// Методи розширення для будь-яких об'єктів Portrait.
///////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

// Переконайтеся, що результат, наприклад, приєднання нитки можна надрукувати і, отже, використовувати з `unwrap`.
// Зрештою, може більше не знадобитися, якщо відправка працює з оновленням.
//
#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any + Send {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

#[stable(feature = "any_send_sync_methods", since = "1.28.0")]
impl fmt::Debug for dyn Any + Send + Sync {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

impl dyn Any {
    /// Повертає `true`, якщо тип коробки такий самий, як `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &dyn Any) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        // Отримайте `TypeId` типу, з яким створена ця функція.
        let t = TypeId::of::<T>();

        // Отримайте `TypeId` типу в об'єкті Portrait (`self`).
        let concrete = self.type_id();

        // Порівняйте обидва `TypeId` щодо рівності.
        t == concrete
    }

    /// Повертає деяке посилання на вказане в полі значення, якщо воно типу `T`, або `None`, якщо воно не є.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &dyn Any) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        if self.is::<T>() {
            // БЕЗПЕКА: просто перевірили, чи ми вказуємо на правильний тип, і ми можемо на нього покластися
            // що перевіряють безпеку пам`яті, оскільки ми застосували будь-який для всіх типів;жоден інший імпульс не може існувати, оскільки він би суперечив нашому імпульсу
            //
            unsafe { Some(&*(self as *const dyn Any as *const T)) }
        } else {
            None
        }
    }

    /// Повертає деяке змінне посилання на позначене в коробці значення, якщо воно має тип `T`, або `None`, якщо воно не є.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut dyn Any) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        if self.is::<T>() {
            // БЕЗПЕКА: просто перевірили, чи ми вказуємо на правильний тип, і ми можемо на нього покластися
            // що перевіряють безпеку пам`яті, оскільки ми застосували будь-який для всіх типів;жоден інший імпульс не може існувати, оскільки він би суперечив нашому імпульсу
            //
            unsafe { Some(&mut *(self as *mut dyn Any as *mut T)) }
        } else {
            None
        }
    }
}

impl dyn Any + Send {
    /// Переходить до методу, визначеного для типу `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// Переходить до методу, визначеного для типу `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// Переходить до методу, визначеного для типу `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

impl dyn Any + Send + Sync {
    /// Переходить до методу, визначеного для типу `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send + Sync)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// Переходить до методу, визначеного для типу `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send + Sync)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// Переходить до методу, визначеного для типу `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send + Sync)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

///////////////////////////////////////////////////////////////////////////////
// TypeID та його методи
///////////////////////////////////////////////////////////////////////////////

/// `TypeId` являє собою глобально унікальний ідентифікатор типу.
///
/// Кожен `TypeId`-це непрозорий об'єкт, який не дозволяє перевіряти те, що знаходиться всередині, але дозволяє основні операції, такі як клонування, порівняння, друк та показ.
///
///
/// На даний момент `TypeId` доступний лише для типів, які відносяться до `'static`, але це обмеження може бути скасовано в future.
///
/// Хоча `TypeId` реалізує `Hash`, `PartialOrd` та `Ord`, варто зазначити, що хеші та впорядкування будуть різнитися між випусками Rust.
/// Остерігайтеся покладатися на них усередині свого коду!
///
///
///
#[derive(Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Debug, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct TypeId {
    t: u64,
}

impl TypeId {
    /// Повертає `TypeId` типу, з яким створена інстанція цієї загальної функції.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string<T: ?Sized + Any>(_s: &T) -> bool {
    ///     TypeId::of::<String>() == TypeId::of::<T>()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub const fn of<T: ?Sized + 'static>() -> TypeId {
        TypeId { t: intrinsics::type_id::<T>() }
    }
}

/// Повертає ім'я типу як фрагмент рядка.
///
/// # Note
///
/// Це призначено для діагностичного використання.
/// Точний вміст та формат повернутого рядка не вказані, крім як найкращий опис типу.
/// Наприклад, серед рядків, які може повернути `type_name::<Option<String>>()`, є `"Option<String>"` та `"std::option::Option<std::string::String>"`.
///
///
/// Повернутий рядок не повинен розглядатися як унікальний ідентифікатор типу, оскільки кілька типів можуть зіставлятись з однаковим іменем типу.
/// Подібним чином, немає гарантії, що всі частини типу з`являться у повернутому рядку: наприклад, специфікатори часу життя в даний час не включені.
/// Крім того, результати можуть змінюватися між версіями компілятора.
///
/// Поточна реалізація використовує ту ж інфраструктуру, що і діагностика компілятора та debuginfo, але це не гарантується.
///
/// # Examples
///
/// ```rust
/// assert_eq!(
///     std::any::type_name::<Option<String>>(),
///     "core::option::Option<alloc::string::String>",
/// );
/// ```
///
///
///
///
#[stable(feature = "type_name", since = "1.38.0")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name<T: ?Sized>() -> &'static str {
    intrinsics::type_name::<T>()
}

/// Повертає ім'я типу вказаного значення як фрагмент рядка.
/// Це те саме, що і `type_name::<T>()`, але може використовуватися там, де тип змінної є непросто доступним.
///
/// # Note
///
/// Це призначено для діагностичного використання.Точний вміст і формат рядка не вказані, окрім як найкращого опису типу.
/// Наприклад, `type_name_of_val::<Option<String>>(None)` може повернути `"Option<String>"` або `"std::option::Option<std::string::String>"`, але не `"foobar"`.
///
/// Крім того, результати можуть змінюватися між версіями компілятора.
///
/// Ця функція не вирішує об'єкти Portrait, тобто `type_name_of_val(&7u32 as &dyn Debug)` може повертати `"dyn Debug"`, але не `"u32"`.
///
/// Ім'я типу не слід розглядати як унікальний ідентифікатор типу;
/// кілька типів можуть мати одне і те ж ім'я типу.
///
/// Поточна реалізація використовує ту ж інфраструктуру, що і діагностика компілятора та debuginfo, але це не гарантується.
///
/// # Examples
///
/// Друкує цілі цілі та плаваючі типи за замовчуванням.
///
/// ```rust
/// #![feature(type_name_of_val)]
/// use std::any::type_name_of_val;
///
/// let x = 1;
/// println!("{}", type_name_of_val(&x));
/// let y = 1.0;
/// println!("{}", type_name_of_val(&y));
/// ```
///
///
///
///
///
///
#[unstable(feature = "type_name_of_val", issue = "66359")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name_of_val<T: ?Sized>(_val: &T) -> &'static str {
    type_name::<T>()
}