#![stable(feature = "futures_api", since = "1.36.0")]

//! Асинхронні значення.

use crate::{
    ops::{Generator, GeneratorState},
    pin::Pin,
    ptr::NonNull,
    task::{Context, Poll},
};

mod future;
mod into_future;
mod pending;
mod poll_fn;
mod ready;

#[stable(feature = "futures_api", since = "1.36.0")]
pub use self::future::Future;

#[unstable(feature = "into_future", issue = "67644")]
pub use into_future::IntoFuture;

#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use pending::{pending, Pending};
#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use ready::{ready, Ready};

#[unstable(feature = "future_poll_fn", issue = "72302")]
pub use poll_fn::{poll_fn, PollFn};

/// Цей тип необхідний, оскільки:
///
/// а) Генератори не можуть реалізувати `for<'a, 'b> Generator<&'a mut Context<'b>>`, тому нам потрібно передати необроблений покажчик (див. <https://github.com/rust-lang/rust/issues/68923>).
///
/// б) Сировинні вказівники та `NonNull` не є `Send` чи `Sync`, тому це також робило б кожен future non-Send/Sync, і ми цього не хочемо.
///
/// Це також спрощує зниження HIR рівня `.await`.
///
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[derive(Debug, Copy, Clone)]
pub struct ResumeTy(NonNull<Context<'static>>);

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Send for ResumeTy {}

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Sync for ResumeTy {}

/// Оберніть генератор у future.
///
/// Ця функція повертає `GenFuture` знизу, але приховує його в `impl Trait`, щоб отримати кращі повідомлення про помилки (`impl Future`, а не `GenFuture<[closure.....]>`).
///
// Це `const`, щоб уникнути зайвих помилок після відновлення після `const async fn`
#[lang = "from_generator"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[rustc_const_unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub const fn from_generator<T>(gen: T) -> impl Future<Output = T::Return>
where
    T: Generator<ResumeTy, Yield = ()>,
{
    #[rustc_diagnostic_item = "gen_future"]
    struct GenFuture<T: Generator<ResumeTy, Yield = ()>>(T);

    // Ми покладаємось на той факт, що async/await futures є нерухомими, щоб створити самореференційні запозичення в базовому генераторі.
    //
    impl<T: Generator<ResumeTy, Yield = ()>> !Unpin for GenFuture<T> {}

    impl<T: Generator<ResumeTy, Yield = ()>> Future for GenFuture<T> {
        type Output = T::Return;
        fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
            // БЕЗПЕКА: безпечно, тому що ми !Unpin + !Drop, а це лише проекція поля.
            let gen = unsafe { Pin::map_unchecked_mut(self, |s| &mut s.0) };

            // Відновіть генератор, перетворивши `&mut Context` на необроблений вказівник `NonNull`.
            // Опускання `.await` безпечно поверне його до `&mut Context`.
            match gen.resume(ResumeTy(NonNull::from(cx).cast::<Context<'static>>())) {
                GeneratorState::Yielded(()) => Poll::Pending,
                GeneratorState::Complete(x) => Poll::Ready(x),
            }
        }
    }

    GenFuture(gen)
}

#[lang = "get_context"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub unsafe fn get_context<'a, 'b>(cx: ResumeTy) -> &'a mut Context<'b> {
    // БЕЗПЕКА: абонент повинен гарантувати, що `cx.0` є дійсним покажчиком
    // що відповідає всім вимогам до змінних посилань.
    unsafe { &mut *cx.0.as_ptr().cast() }
}