use crate::future::Future;

/// Перетворення на `Future`.
#[unstable(feature = "into_future", issue = "67644")]
pub trait IntoFuture {
    /// Результат, який future видасть після завершення.
    #[unstable(feature = "into_future", issue = "67644")]
    type Output;

    /// У який тип future ми перетворюємо це?
    #[unstable(feature = "into_future", issue = "67644")]
    type Future: Future<Output = Self::Output>;

    /// Створює future зі значення.
    #[unstable(feature = "into_future", issue = "67644")]
    fn into_future(self) -> Self::Future;
}

#[unstable(feature = "into_future", issue = "67644")]
impl<F: Future> IntoFuture for F {
    type Output = F::Output;
    type Future = F;

    fn into_future(self) -> Self::Future {
        self
    }
}