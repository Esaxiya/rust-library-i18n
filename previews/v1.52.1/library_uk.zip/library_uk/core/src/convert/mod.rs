//! Traits для перетворення між типами.
//!
//! traits у цьому модулі забезпечує спосіб перетворення з одного типу на інший тип.
//! Кожен Portrait має різну мету:
//!
//! - Впроваджуйте [`AsRef`] Portrait для дешевих перетворень посилання на посилання
//! - Впроваджуйте [`AsMut`] Portrait для дешевих перетворень, що змінюються в змінні
//! - Впроваджуйте [`From`] Portrait для споживання перетворень значення у вартість
//! - Реалізуйте [`Into`] Portrait для споживання перетворень вартості в значення до типів, що не входять до поточного crate
//! - [`TryFrom`] та [`TryInto`] traits поводяться як [`From`] та [`Into`], але їх слід застосовувати, коли перетворення може не вдатися.
//!
//! traits у цьому модулі часто використовуються як Portrait bounds для загальних функцій, таких, що підтримуються аргументи декількох типів.Див. Документацію кожного Portrait для прикладів.
//!
//! Як автор бібліотеки, ви завжди повинні віддавати перевагу впровадженню [`From<T>`][`From`] або [`TryFrom<T>`][`TryFrom`], а не [`Into<U>`][`Into`] або [`TryInto<U>`][`TryInto`], оскільки [`From`] і [`TryFrom`] забезпечують більшу гнучкість і пропонують еквівалентні реалізації [`Into`] або [`TryInto`] безкоштовно, завдяки загальній реалізації в стандартній бібліотеці.
//! При націлюванні на версію до Rust 1.41, можливо, буде потрібно застосувати [`Into`] або [`TryInto`] безпосередньо при перетворенні на тип поза поточним crate.
//!
//! # Загальні реалізації
//!
//! - [`AsRef`] та автоматичне розпізнавання [`AsMut`], якщо внутрішній тип є еталоном
//! - [`From`]`<U>для T` означає [`Into`]`</u><T><U>для U`</u>
//! - [`TryFrom`]`<U>для T 'означає [`TryInto`]`</u><T><U>для U`</u>
//! - [`From`] і [`Into`] є рефлексивними, що означає, що всі типи можуть `into` самі і `from` самі
//!
//! Див. Кожен Portrait для прикладів використання.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

mod num;

#[unstable(feature = "convert_float_to_int", issue = "67057")]
pub use num::FloatToInt;

/// Функція ідентичності.
///
/// Про цю функцію важливо відзначити дві речі:
///
/// - Це не завжди еквівалентно закриттю, як `|x| x`, оскільки закриття може примусити `x` до іншого типу.
///
/// - Він переміщує вхід `x`, переданий функції.
///
/// Хоча може здатися дивним наявність функції, яка просто повертає введені дані, є кілька цікавих застосувань.
///
///
/// # Examples
///
/// Використання `identity`, щоб нічого не робити в послідовності інших, цікавих функцій:
///
/// ```rust
/// use std::convert::identity;
///
/// fn manipulation(x: u32) -> u32 {
///     // Давайте зробимо вигляд, що додавання-це цікава функція.
///     x + 1
/// }
///
/// let _arr = &[identity, manipulation];
/// ```
///
/// Використання `identity` як базового випадку "do nothing" в умовному:
///
/// ```rust
/// use std::convert::identity;
///
/// # let condition = true;
/// #
/// # fn manipulation(x: u32) -> u32 { x + 1 }
/// #
/// let do_stuff = if condition { manipulation } else { identity };
///
/// // Робіть ще цікаві речі ...
///
/// let _results = do_stuff(42);
/// ```
///
/// Використання `identity` для збереження варіантів `Some` ітератора `Option<T>`:
///
/// ```rust
/// use std::convert::identity;
///
/// let iter = vec![Some(1), None, Some(3)].into_iter();
/// let filtered = iter.filter_map(identity).collect::<Vec<_>>();
/// assert_eq!(vec![1, 3], filtered);
/// ```
///
///
#[stable(feature = "convert_id", since = "1.33.0")]
#[rustc_const_stable(feature = "const_identity", since = "1.33.0")]
#[inline]
pub const fn identity<T>(x: T) -> T {
    x
}

/// Використовується для дешевого перетворення посилання на посилання.
///
/// Цей Portrait схожий на [`AsMut`], який використовується для перетворення між змінними посиланнями.
/// Якщо вам потрібно зробити дороге перетворення, краще застосувати [`From`] з типом `&T` або написати власну функцію.
///
/// `AsRef` має такий самий підпис, як [`Borrow`], але [`Borrow`] відрізняється в кількох аспектах:
///
/// - На відміну від `AsRef`, [`Borrow`] має загальний імпульс для будь-якого `T` і може бути використаний для прийняття посилання або значення.
/// - [`Borrow`] також вимагає, щоб [`Hash`], [`Eq`] та [`Ord`] для позикової вартості були еквівалентні вартості власності.
/// З цієї причини, якщо ви хочете запозичити лише одне поле структури, ви можете застосувати `AsRef`, але не [`Borrow`].
///
/// **Note: Цей Portrait не повинен виходити з ладу **.Якщо перетворення не вдається, використовуйте спеціальний метод, який повертає [`Option<T>`] або [`Result<T, E>`].
///
/// # Загальні реалізації
///
/// - `AsRef` автоматичне призначення посилань, якщо внутрішній тип є посиланням або змінним посиланням (наприклад: `foo.as_ref()` will work the same if `foo` has type   `&mut Foo` or `&&mut Foo`)
///
///
/// # Examples
///
/// Використовуючи Portrait bounds, ми можемо приймати аргументи різних типів, якщо їх можна перетворити на вказаний тип `T`.
///
/// Наприклад: Створюючи загальну функцію, яка приймає `AsRef<str>`, ми виражаємо, що хочемо прийняти всі посилання, які можуть бути перетворені в [`&str`], як аргумент.
/// Оскільки і [`String`], і [`&str`] реалізують `AsRef<str>`, ми можемо прийняти обидва як вхідний аргумент.
///
/// [`&str`]: primitive@str
/// [`Borrow`]: crate::borrow::Borrow
/// [`Eq`]: crate::cmp::Eq
/// [`Ord`]: crate::cmp::Ord
/// [`String`]: ../../std/string/struct.String.html
///
/// ```
/// fn is_hello<T: AsRef<str>>(s: T) {
///    assert_eq!("hello", s.as_ref());
/// }
///
/// let s = "hello";
/// is_hello(s);
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsRef<T: ?Sized> {
    /// Виконує перетворення.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_ref(&self) -> &T;
}

/// Використовується для здійснення дешевого перетворюваного еталонного перетворення.
///
/// Цей Portrait схожий на [`AsRef`], але використовується для перетворення між змінними посиланнями.
/// Якщо вам потрібно зробити дороге перетворення, краще застосувати [`From`] з типом `&mut T` або написати власну функцію.
///
/// **Note: Цей Portrait не повинен виходити з ладу **.Якщо перетворення не вдається, використовуйте спеціальний метод, який повертає [`Option<T>`] або [`Result<T, E>`].
///
/// # Загальні реалізації
///
/// - `AsMut` автоматичні посилання, якщо внутрішній тип є змінним посиланням (наприклад: `foo.as_mut()` will work the same if `foo` has type `&mut Foo`   or `&mut &mut Foo`)
///
///
/// # Examples
///
/// Використовуючи `AsMut` як Portrait bound для загальної функції, ми можемо прийняти всі змінні посилання, які можна перетворити на тип `&mut T`.
/// Оскільки [`Box<T>`] реалізує `AsMut<T>`, ми можемо написати функцію `add_one`, яка приймає всі аргументи, які можуть бути перетворені в `&mut u64`.
/// Оскільки [`Box<T>`] реалізує `AsMut<T>`, `add_one` також приймає аргументи типу `&mut Box<u64>`:
///
/// ```
/// fn add_one<T: AsMut<u64>>(num: &mut T) {
///     *num.as_mut() += 1;
/// }
///
/// let mut boxed_num = Box::new(0);
/// add_one(&mut boxed_num);
/// assert_eq!(*boxed_num, 1);
/// ```
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsMut<T: ?Sized> {
    /// Виконує перетворення.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_mut(&mut self) -> &mut T;
}

/// Перетворення значення у вартість, яке споживає введене значення.Протилежність [`From`].
///
/// Слід уникати впровадження [`Into`] і замість цього впроваджувати [`From`].
/// Реалізація [`From`] автоматично забезпечує реалізацію [`Into`] завдяки загальній реалізації в стандартній бібліотеці.
///
/// Віддайте перевагу використанню [`Into`] перед [`From`], коли вказуєте Portrait bounds у загальній функції, щоб гарантувати, що типи, які реалізують лише [`Into`], також можуть бути використані.
///
/// **Note: Цей Portrait не повинен виходити з ладу **.Якщо перетворення не вдається, використовуйте [`TryInto`].
///
/// # Загальні реалізації
///
/// - [`Від`]`<T>для U` мається на увазі `Into<U> for T`
/// - [`Into`] є рефлексивним, що означає, що впроваджено `Into<T> for T`
///
/// # Впровадження [`Into`] для перетворення на зовнішні типи у старих версіях Rust
///
/// До Rust 1.41, якщо тип призначення не був частиною поточного crate, тоді ви не могли безпосередньо реалізувати [`From`].
/// Наприклад, візьмемо цей код:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> From<Wrapper<T>> for Vec<T> {
///     fn from(w: Wrapper<T>) -> Vec<T> {
///         w.0
///     }
/// }
/// ```
/// Це не вдасться скомпілювати у старих версіях мови, оскільки правила осиротіння Rust раніше були трохи суворішими.
/// Щоб обійти це, ви можете застосувати [`Into`] безпосередньо:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> Into<Vec<T>> for Wrapper<T> {
///     fn into(self) -> Vec<T> {
///         self.0
///     }
/// }
/// ```
///
/// Важливо розуміти, що [`Into`] не забезпечує реалізації [`From`] (як це робить [`From`] з [`Into`]).
/// Тому вам завжди слід намагатися впровадити [`From`], а потім повернутися до [`Into`], якщо [`From`] не вдається реалізувати.
///
/// # Examples
///
/// [`String`] реалізує [`Into`]`<`[`Vec`] `<` [`u8`]`>>`:
///
/// Для того, щоб висловити, що ми хочемо, щоб загальна функція приймала всі аргументи, які можуть бути перетворені у вказаний тип `T`, ми можемо використовувати Portrait bound з [`Into`]`<T>`.
///
/// Наприклад: Функція `is_hello` бере всі аргументи, які можуть бути перетворені у [`Vec`]`<`[`u8`] `>`.
///
/// ```
/// fn is_hello<T: Into<Vec<u8>>>(s: T) {
///    let bytes = b"hello".to_vec();
///    assert_eq!(bytes, s.into());
/// }
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`Vec`]: ../../std/vec/struct.Vec.html
///
///
///
///
///
///
#[rustc_diagnostic_item = "into_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Into<T>: Sized {
    /// Виконує перетворення.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into(self) -> T;
}

/// Використовується для перетворення значення в значення під час споживання вхідного значення.Це взаємність [`Into`].
///
/// Завжди слід віддавати перевагу впровадженню `From` перед [`Into`], оскільки впровадження `From` автоматично забезпечує реалізацію [`Into`] завдяки загальній реалізації в стандартній бібліотеці.
///
///
/// Застосовуйте [`Into`] лише при націлюванні на версію до Rust 1.41 та перетворенні на тип, що не входить до поточного crate.
/// `From` не зміг виконати такі типи перетворень у попередніх версіях через правила осиротіння Rust.
/// Докладніше див. У розділі [`Into`].
///
/// Надайте перевагу використанню [`Into`] перед використанням `From`, коли вказуєте Portrait bounds для загальної функції.
/// Таким чином, типи, які безпосередньо реалізують [`Into`], також можуть бути використані як аргументи.
///
/// `From` також дуже корисний при обробці помилок.При побудові функції, яка здатна вийти з ладу, тип повернення, як правило, має форму `Result<T, E>`.
/// `From` Portrait спрощує обробку помилок, дозволяючи функції повертати один тип помилки, який інкапсулює кілька типів помилок.Детальніше див. У розділі "Examples" та [the book][book].
///
/// **Note: Цей Portrait не повинен виходити з ладу **.Якщо перетворення не вдається, використовуйте [`TryFrom`].
///
/// # Загальні реалізації
///
/// - `From<T> for U` має на увазі [`Into`]`<U>для T`</u>
/// - `From` є рефлексивним, що означає, що впроваджено `From<T> for T`
///
/// # Examples
///
/// [`String`] реалізує `From<&str>`:
///
/// Явне перетворення з `&str` у рядок виконується наступним чином:
///
/// ```
/// let string = "hello".to_string();
/// let other_string = String::from("hello");
///
/// assert_eq!(string, other_string);
/// ```
///
/// Під час обробки помилок часто корисно застосовувати `From` для власного типу помилок.
/// Перетворюючи базові типи помилок у власний власний тип помилок, який інкапсулює базовий тип помилок, ми можемо повернути один тип помилки, не втрачаючи інформацію про основну причину.
/// Оператор '?' автоматично перетворює основний тип помилки на наш власний тип помилки, викликаючи `Into<CliError>::into`, який автоматично надається при впровадженні `From`.
/// Потім компілятор визначає, яку реалізацію `Into` слід використовувати.
///
/// ```
/// use std::fs;
/// use std::io;
/// use std::num;
///
/// enum CliError {
///     IoError(io::Error),
///     ParseError(num::ParseIntError),
/// }
///
/// impl From<io::Error> for CliError {
///     fn from(error: io::Error) -> Self {
///         CliError::IoError(error)
///     }
/// }
///
/// impl From<num::ParseIntError> for CliError {
///     fn from(error: num::ParseIntError) -> Self {
///         CliError::ParseError(error)
///     }
/// }
///
/// fn open_and_parse_file(file_name: &str) -> Result<i32, CliError> {
///     let mut contents = fs::read_to_string(&file_name)?;
///     let num: i32 = contents.trim().parse()?;
///     Ok(num)
/// }
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`from`]: From::from
/// [book]: ../../book/ch09-00-error-handling.html
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "from_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(on(
    all(_Self = "&str", T = "std::string::String"),
    note = "to coerce a `{T}` into a `{Self}`, use `&*` as a prefix",
))]
pub trait From<T>: Sized {
    /// Виконує перетворення.
    #[lang = "from"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from(_: T) -> Self;
}

/// Спроба перетворення, що споживає `self`, що може коштувати або не бути дорогим.
///
/// Автори бібліотек, як правило, не повинні безпосередньо реалізовувати цей Portrait, а віддавати перевагу впровадженню [`TryFrom`] Portrait, який пропонує більшу гнучкість і забезпечує еквівалентну реалізацію `TryInto` безкоштовно, завдяки загальній реалізації в стандартній бібліотеці.
/// Для отримання додаткової інформації про це дивіться документацію до [`Into`].
///
/// # Впровадження `TryInto`
///
/// Це зазнає тих самих обмежень та міркувань, що і впровадження [`Into`], докладніше див. Там.
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_into_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryInto<T>: Sized {
    /// Тип, що повертається у разі помилки перетворення.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// Виконує перетворення.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_into(self) -> Result<T, Self::Error>;
}

/// Прості та безпечні перетворення типів, які за певних обставин можуть контрольовано провалитися.Це взаємність [`TryInto`].
///
/// Це корисно, коли ви виконуєте перетворення типу, яке може бути тривіально успішним, але також може потребувати спеціальної обробки.
/// Наприклад, неможливо перетворити [`i64`] в [`i32`] за допомогою [`From`] Portrait, оскільки [`i64`] може містити значення, яке [`i32`] не може представляти, і тому перетворення втратить дані.
///
/// Це може бути вирішено шляхом обрізання [`i64`] до [`i32`] (по суті, надання значення [`i64`] за модулем [`i32::MAX`]) або шляхом простого повернення [`i32::MAX`] або іншим способом.
/// [`From`] Portrait призначений для ідеальних перетворень, тому `TryFrom` Portrait інформує програміста, коли перетворення типу може зіпсуватися, і дозволяє їм вирішити, як це зробити.
///
/// # Загальні реалізації
///
/// - `TryFrom<T> for U` передбачає [`TryInto`]`<U>для T`</u>
/// - [`try_from`] є рефлексивним, що означає, що `TryFrom<T> for T` реалізований і не може вийти з ладу-пов'язаний тип `Error` для виклику `T::try_from()` для значення типу `T` є [`Infallible`].
/// Коли стабілізується тип [`!`], [`Infallible`] і [`!`] будуть еквівалентними.
///
/// `TryFrom<T>` може бути реалізований наступним чином:
///
/// ```
/// use std::convert::TryFrom;
///
/// struct GreaterThanZero(i32);
///
/// impl TryFrom<i32> for GreaterThanZero {
///     type Error = &'static str;
///
///     fn try_from(value: i32) -> Result<Self, Self::Error> {
///         if value <= 0 {
///             Err("GreaterThanZero only accepts value superior than zero!")
///         } else {
///             Ok(GreaterThanZero(value))
///         }
///     }
/// }
/// ```
///
/// # Examples
///
/// Як описано, [`i32`] реалізує `TryFrom <` [`i64`]`>`:
///
/// ```
/// use std::convert::TryFrom;
///
/// let big_number = 1_000_000_000_000i64;
/// // Тихо скорочує `big_number`, вимагає виявлення та обробки усічення після факту.
/////
/// let smaller_number = big_number as i32;
/// assert_eq!(smaller_number, -727379968);
///
/// // Повертає помилку, оскільки `big_number` завеликий, щоб поміститися в `i32`.
/////
/// let try_smaller_number = i32::try_from(big_number);
/// assert!(try_smaller_number.is_err());
///
/// // Повертає `Ok(3)`.
/// let try_successful_smaller_number = i32::try_from(3);
/// assert!(try_successful_smaller_number.is_ok());
/// ```
///
/// [`try_from`]: TryFrom::try_from
///
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_from_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryFrom<T>: Sized {
    /// Тип, що повертається у разі помилки перетворення.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// Виконує перетворення.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_from(value: T) -> Result<Self, Self::Error>;
}

////////////////////////////////////////////////////////////////////////////////
// ЗАГАЛЬНІ ВПЛИВИ
////////////////////////////////////////////////////////////////////////////////

// Як піднімає над&
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// Як підйомники над &mut
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &mut T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// FIXME (#45742): замініть наведені вище імпульси для&/&mut наступними більш загальними:
// // Як підйомники над Дерефом
// імпл <D: ?Sized + Deref<Target: AsRef<U>>, U:? Розмір> AsRef <U>для D {fn as_ref(&self)-> &U {</u>
//
//         self.deref().as_ref()
//     }
// }

// AsMut піднімається над &mut
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsMut<U> for &mut T
where
    T: AsMut<U>,
{
    fn as_mut(&mut self) -> &mut U {
        (*self).as_mut()
    }
}

// FIXME (#45742): замініть наведений вище імпульс для &mut на наступний більш загальний:
// // AsMut піднімається над DerefMut
// імпл <D: ?Sized + Deref<Target: AsMut<U>>, U:? Розмір> AsMut <U>для D {fn as_mut(&mut self)-> &mut U {</u>
//
//         self.deref_mut().as_mut()
//     }
// }

// З натякає на
#[stable(feature = "rust1", since = "1.0.0")]
impl<T, U> Into<U> for T
where
    U: From<T>,
{
    fn into(self) -> U {
        U::from(self)
    }
}

// Від (і, отже, до Into) є рефлексивним
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> From<T> for T {
    fn from(t: T) -> T {
        t
    }
}

/// **Примітка про стабільність:** Цей імпульс ще не існує, але ми "reserving space", щоб додати його до future.
/// Детальніше див. У розділі [rust-lang/rust#64715][#64715].
///
/// [#64715]: https://github.com/rust-lang/rust/issues/64715
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[allow(unused_attributes)] // FIXME(#58633): замість цього виконайте принципове виправлення.
#[rustc_reservation_impl = "permitting this impl would forbid us from adding \
                            `impl<T> From<!> for T` later; see rust-lang/rust#64715 for details"]
impl<T> From<!> for T {
    fn from(t: !) -> T {
        t
    }
}

// TryFrom передбачає TryInto
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryInto<U> for T
where
    U: TryFrom<T>,
{
    type Error = U::Error;

    fn try_into(self) -> Result<U, U::Error> {
        U::try_from(self)
    }
}

// Непомильні перетворення семантично еквівалентні помилковим перетворенням з нежилим типом помилок.
//
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryFrom<U> for T
where
    U: Into<T>,
{
    type Error = Infallible;

    fn try_from(value: U) -> Result<Self, Self::Error> {
        Ok(U::into(value))
    }
}

////////////////////////////////////////////////////////////////////////////////
// БЕТОННІ ІМПЛ
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsRef<[T]> for [T] {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsMut<[T]> for [T] {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for str {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "as_mut_str_for_str", since = "1.51.0")]
impl AsMut<str> for str {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

////////////////////////////////////////////////////////////////////////////////
// ТИП ПОМИЛКИ БЕЗ ПОМИЛОК
////////////////////////////////////////////////////////////////////////////////

/// Тип помилки для помилок, які ніколи не можуть статися.
///
/// Оскільки цей перелік не має варіанту, значення цього типу насправді ніколи не може існувати.
/// Це може бути корисно для загальних API, які використовують [`Result`] і параметризують тип помилки, щоб вказати, що результат завжди [`Ok`].
///
/// Наприклад, [`TryFrom`] Portrait (перетворення, яке повертає [`Result`]) має загальну реалізацію для всіх типів, де існує зворотна реалізація [`Into`].
///
/// ```ignore (illustrates std code, duplicating the impl in a doctest would be an error)
/// impl<T, U> TryFrom<U> for T where U: Into<T> {
///     type Error = Infallible;
///
///     fn try_from(value: U) -> Result<Self, Infallible> {
///         Ok(U::into(value))  // Never returns `Err`
///     }
/// }
/// ```
///
/// # Сумісність Future
///
/// Цей перелік виконує ту саму роль, що і [the `!`“never”type][never], яка нестабільна у цій версії Rust.
/// Коли `!` стабілізується, ми плануємо зробити `Infallible` типовим псевдонімом:
///
/// ```ignore (illustrates future std change)
/// pub type Infallible = !;
/// ```
///
/// ... і врешті-решт припинить `Infallible`.
///
/// Однак є один випадок, коли синтаксис `!` можна використовувати до того, як `!` стабілізується як повноцінний тип: у позиції типу функції повернення.
/// Зокрема, можливі реалізації для двох різних типів покажчиків функцій:
///
/// ```
/// trait MyTrait {}
/// impl MyTrait for fn() -> ! {}
/// impl MyTrait for fn() -> std::convert::Infallible {}
/// ```
///
/// Оскільки `Infallible` є переліком, цей код є дійсним.
/// Однак, коли `Infallible` стає псевдонімом для never type, два `impl` починають перекриватися, і тому будуть заборонені правилами злагодженості Portrait мови.
///
///
///
///
///
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[derive(Copy)]
pub enum Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Clone for Infallible {
    fn clone(&self) -> Infallible {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Debug for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Display for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialEq for Infallible {
    fn eq(&self, _: &Infallible) -> bool {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Eq for Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialOrd for Infallible {
    fn partial_cmp(&self, _other: &Self) -> Option<crate::cmp::Ordering> {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Ord for Infallible {
    fn cmp(&self, _other: &Self) -> crate::cmp::Ordering {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl From<!> for Infallible {
    fn from(x: !) -> Self {
        x
    }
}

#[stable(feature = "convert_infallible_hash", since = "1.44.0")]
impl Hash for Infallible {
    fn hash<H: Hasher>(&self, _: &mut H) {
        match *self {}
    }
}