//! Примітивні traits та типи, що представляють основні властивості типів.
//!
//! Типи Rust можна класифікувати різними корисними способами відповідно до їх власних властивостей.
//! Ці класифікації представлені як traits.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cell::UnsafeCell;
use crate::cmp;
use crate::fmt::Debug;
use crate::hash::Hash;
use crate::hash::Hasher;

/// Типи, які можна переносити через межі потоків.
///
/// Цей Portrait автоматично реалізується, коли компілятор визначить, що це доречно.
///
/// Прикладом типу, який не є "Send", є покажчик підрахунку посилань [`rc::Rc`][`Rc`].
/// Якщо два потоки намагаються клонувати [`Rc`], що вказують на одне і те ж значення, враховане за посиланнями, вони можуть спробувати оновити кількість посилань одночасно, тобто [undefined behavior][ub], оскільки [`Rc`] не використовує атомні операції.
///
/// Його двоюрідний брат [`sync::Arc`][arc] використовує атомні операції (що спричиняє певні накладні витрати) і, отже, `Send`.
///
/// Докладніше див. У розділі [the Nomicon](../../nomicon/send-and-sync.html).
///
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "send_trait")]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be sent between threads safely",
    label = "`{Self}` cannot be sent between threads safely"
)]
pub unsafe auto trait Send {
    // empty.
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *mut T {}

/// Типи з постійним розміром, відомі під час компіляції.
///
/// Усі параметри типу мають неявний зв`язок `Sized`.Спеціальний синтаксис `?Sized` може бути використаний для видалення цього обмеження, якщо це не доречно.
///
/// ```
/// # #![allow(dead_code)]
/// struct Foo<T>(T);
/// struct Bar<T: ?Sized>(T);
///
/// // структура FooUse(Foo<[i32]>);//помилка: розмір не реалізований для [i32]
/// struct BarUse(Bar<[i32]>); // OK
/// ```
///
/// Єдиним винятком є неявний тип `Self` для Portrait.
/// Portrait не має неявного зв`язку `Sized`, оскільки це несумісно з [об`єктом Portrait], де, за визначенням, Portrait має працювати з усіма можливими реалізаторами, і, отже, може бути будь-якого розміру.
///
///
/// Хоча Rust дозволить вам прив'язати `Sized` до Portrait, ви не зможете використовувати його для формування об'єкта Portrait пізніше:
///
/// ```
/// # #![allow(unused_variables)]
/// trait Foo { }
/// trait Bar: Sized { }
///
/// struct Impl;
/// impl Foo for Impl { }
/// impl Bar for Impl { }
///
/// let x: &dyn Foo = &Impl;    // OK
/// // нехай y: &dyn Bar= &Impl;//помилка: Portrait `Bar` не можна перетворити на об'єкт
/////
/// ```
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "sized"]
#[rustc_on_unimplemented(
    message = "the size for values of type `{Self}` cannot be known at compilation time",
    label = "doesn't have a size known at compile-time"
)]
#[fundamental] // наприклад, за замовчуванням, що вимагає оцінки `[T]: !Default`
#[rustc_specialization_trait]
pub trait Sized {
    // Empty.
}

/// Типи, які можуть бути "unsized" для динамічного типу.
///
/// Наприклад, розмірний масив типу `[i8; 2]` реалізує `Unsize<[i8]>` і `Unsize<dyn fmt::Debug>`.
///
/// Всі реалізації `Unsize` надаються компілятором автоматично.
///
/// `Unsize` реалізовано для:
///
/// - `[T; N]` є `Unsize<[T]>`
/// - `T` є `Unsize<dyn Trait>`, коли `T: Trait`
/// - `Foo<..., T, ...>` є `Unsize<Foo<..., U, ...>>`, якщо:
///   - `T: Unsize<U>`
///   - Foo-це структура
///   - Лише останнє поле `Foo` має тип із залученням `T`
///   - `T` не входить до типу будь-яких інших полів
///   - `Bar<T>: Unsize<Bar<U>>`, якщо останнє поле `Foo` має тип `Bar<T>`
///
/// `Unsize` використовується разом із [`ops::CoerceUnsized`], щоб контейнери "user-defined", такі як [`Rc`], містили типи динамічного розміру.
/// Докладніше див. У [DST coercion RFC][RFC982] та [the nomicon entry on coercion][nomicon-coerce].
///
/// [`ops::CoerceUnsized`]: crate::ops::CoerceUnsized
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [RFC982]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
#[unstable(feature = "unsize", issue = "27732")]
#[lang = "unsize"]
pub trait Unsize<T: ?Sized> {
    // Empty.
}

/// Обов`язковий Portrait для констант, що використовуються у збігах шаблонів.
///
/// Будь-який тип, що походить від `PartialEq`, автоматично реалізує цей Portrait, * незалежно від того, чи його параметри типу реалізують `Eq`.
///
/// Якщо елемент `const` містить якийсь тип, який не реалізує цей Portrait, то цей тип або (1.) не реалізує `PartialEq` (що означає, що константа не надаватиме того методу порівняння, який передбачається генерацією коду), або (2.) він реалізує *власний* версія `PartialEq` (яка, як ми вважаємо, не відповідає порівнянню структурної рівності).
///
///
/// У будь-якому з двох вищезазначених сценаріїв ми відкидаємо використання такої константи у збігу шаблонів.
///
/// Дивіться також [structural match RFC][RFC1445] та [issue 63438], які спонукали перейти від дизайну на основі атрибутів до цього Portrait.
///
/// [RFC1445]: https://github.com/rust-lang/rfcs/blob/master/text/1445-restrict-constants-in-patterns.md
/// [issue 63438]: https://github.com/rust-lang/rust/issues/63438
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(PartialEq)]`")]
#[lang = "structural_peq"]
pub trait StructuralPartialEq {
    // Empty.
}

/// Обов`язковий Portrait для констант, що використовуються у збігах шаблонів.
///
/// Будь-який тип, що походить з `Eq`, автоматично реалізує цей Portrait, * незалежно від того, чи реалізують параметри його типу `Eq`.
///
/// Це хак, щоб обійти обмеження в нашій системі типів.
///
/// # Background
///
/// Ми хочемо вимагати, щоб типи consts, що використовуються у збігах шаблонів, мали атрибут `#[derive(PartialEq, Eq)]`.
///
/// У більш ідеальному світі ми могли б перевірити цю вимогу, просто перевіривши, що даний тип реалізує як `StructuralPartialEq` Portrait *, так і*`Eq` Portrait.
/// Однак ви можете мати ADT, які *роблять*`derive(PartialEq, Eq)`, і бути випадком, який ми хочемо, щоб компілятор прийняв, і все ж тип константи не може реалізувати `Eq`.
///
/// А саме такий випадок:
///
/// ```rust
/// #[derive(PartialEq, Eq)]
/// struct Wrap<X>(X);
///
/// fn higher_order(_: &()) { }
///
/// const CFN: Wrap<fn(&())> = Wrap(higher_order);
///
/// fn main() {
///     match CFN {
///         CFN => {}
///         _ => {}
///     }
/// }
/// ```
///
/// (Проблема у наведеному вище коді полягає в тому, що `Wrap<fn(&())>` не реалізує ні `PartialEq`, ні `Eq`, оскільки `для <'a> fn(&'a _)` does not implement those traits.)
///
/// Тому ми не можемо покладатися на наївну перевірку на наявність `StructuralPartialEq` та просто `Eq`.
///
/// Як хакер, щоб обійти це, ми використовуємо два окремі traits, введені кожним з двох похідних (`#[derive(PartialEq)]` і `#[derive(Eq)]`), і перевіряємо, чи є вони обоє присутніми в рамках перевірки структурних збігів.
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(Eq)]`")]
#[lang = "structural_teq"]
pub trait StructuralEq {
    // Empty.
}

/// Типи, значення яких можна дублювати, просто копіюючи біти.
///
/// За замовчуванням прив'язки змінних мають "семантику переміщення".Іншими словами:
///
/// ```
/// #[derive(Debug)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `x` перейшов у `y`, тому не може бути використаний
///
/// // println! ("{: ?}", x);//помилка: використання переміщеного значення
/// ```
///
/// Однак, якщо тип реалізує `Copy`, він замість цього має "семантику копіювання":
///
/// ```
/// // Ми можемо отримати реалізацію `Copy`.
/// // `Clone` також необхідний, оскільки це супертрейт `Copy`.
/// #[derive(Debug, Copy, Clone)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `y` є копією `x`
///
/// println!("{:?}", x); // A-OK!
/// ```
///
/// Важливо зазначити, що в цих двох прикладах єдина різниця полягає в тому, чи дозволено вам отримати доступ до `x` після призначення.
/// Під капотом як копія, так і переміщення можуть призвести до копіювання бітів у пам`ять, хоча це іноді оптимізується.
///
/// ## Як я можу застосувати `Copy`?
///
/// Існує два способи впровадження `Copy` для вашого типу.Найпростішим є використання `derive`:
///
/// ```
/// #[derive(Copy, Clone)]
/// struct MyStruct;
/// ```
///
/// Ви також можете застосувати `Copy` та `Clone` вручну:
///
/// ```
/// struct MyStruct;
///
/// impl Copy for MyStruct { }
///
/// impl Clone for MyStruct {
///     fn clone(&self) -> MyStruct {
///         *self
///     }
/// }
/// ```
///
/// Існує невелика різниця між ними: стратегія `derive` також буде встановлювати `Copy` на параметри типу, що не завжди бажано.
///
/// ## Яка різниця між `Copy` та `Clone`?
///
/// Копіювання відбувається неявно, наприклад, як частина завдання `y = x`.Поведінка `Copy` не можна завантажити;це завжди проста розрядна копія.
///
/// Клонування-це явна дія, `x.clone()`.Реалізація [`Clone`] може забезпечити будь-яку специфічну поведінку, необхідну для безпечного продублювання значень.
/// Наприклад, для реалізації [`Clone`] для [`String`] потрібно скопіювати вказаний на буфер рядків у купі.
/// Проста побітова копія значень [`String`] просто копіювала би покажчик, приводячи до подвійного вільного руху по рядку.
/// З цієї причини [`String`] є [`Clone`], але не `Copy`.
///
/// [`Clone`] є супертрейтом `Copy`, тому все, що є `Copy`, також має реалізовувати [`Clone`].
/// Якщо типом є `Copy`, тоді його реалізація [`Clone`] повинна повертати лише `*self` (див. Приклад вище).
///
/// ## Коли моїм типом може бути `Copy`?
///
/// Тип може реалізувати `Copy`, якщо всі його компоненти реалізують `Copy`.Наприклад, цією структурою може бути `Copy`:
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Copy, Clone)]
/// struct Point {
///    x: i32,
///    y: i32,
/// }
/// ```
///
/// Структура може бути `Copy`, а [`i32`]-`Copy`, тому `Point` може бути `Copy`.
/// Навпаки, розглянемо
///
/// ```
/// # #![allow(dead_code)]
/// # struct Point;
/// struct PointList {
///     points: Vec<Point>,
/// }
/// ```
///
/// Структура `PointList` не може реалізувати `Copy`, оскільки [`Vec<T>`] не є `Copy`.Якщо ми спробуємо отримати реалізацію `Copy`, ми отримаємо помилку:
///
/// ```text
/// the trait `Copy` may not be implemented for this type; field `points` does not implement `Copy`
/// ```
///
/// Спільні посилання (`&T`) також є `Copy`, тому типом може бути `Copy`, навіть коли він містить спільні посилання типів `T`, які *не*`Copy`.
/// Розглянемо наступну структуру, яка може реалізувати `Copy`, оскільки вона містить лише *загальне посилання* на наш не `Копіюючий` тип `PointList` зверху:
///
/// ```
/// # #![allow(dead_code)]
/// # struct PointList;
/// #[derive(Copy, Clone)]
/// struct PointListWrapper<'a> {
///     point_list_ref: &'a PointList,
/// }
/// ```
///
/// ## Коли *не може* мій тип бути `Copy`?
///
/// Деякі типи неможливо безпечно скопіювати.Наприклад, копіювання `&mut T` створило б псевдонімне змінне посилання.
/// Копіювання [`String`] призведе до повторення відповідальності за управління буфером [`String`], що призведе до подвійного безкоштовного.
///
/// Узагальнюючи останній випадок, будь-який тип, що реалізує [`Drop`], не може бути `Copy`, оскільки він управляє деяким ресурсом, крім власних байтів [`size_of::<T>`].
///
/// Якщо ви спробуєте реалізувати `Copy` на структурі або переліку, що містять дані, що не є `` Копією '', ви отримаєте помилку [E0204].
///
/// [E0204]: ../../error-index.html#E0204
///
/// ## Коли *повинен* мій тип бути `Copy`?
///
/// Загалом кажучи, якщо ваш тип _can_ реалізує `Copy`, він повинен.
/// Однак пам`ятайте, що впровадження `Copy` є частиною загальнодоступного API вашого типу.
/// Якщо в future тип може стати не `` Копіювати '', може бути розумно опустити реалізацію `Copy` зараз, щоб уникнути порушення API-змін.
///
/// ## Додаткові реалізатори
///
/// На додаток до [implementors listed below][impls], наступні типи також реалізують `Copy`:
///
/// * Типи елементів функцій (тобто різні типи, визначені для кожної функції)
/// * Типи покажчиків функцій (наприклад, `fn() -> i32`)
/// * Типи масивів для всіх розмірів, якщо тип елемента також реалізує `Copy` (наприклад, `[i32; 123456]`)
/// * Набори типів, якщо кожен компонент також реалізує `Copy` (наприклад, `()`, `(i32, bool)`)
/// * Типи закриття, якщо вони не захоплюють жодної цінності з навколишнього середовища або якщо всі такі захоплені значення реалізують `Copy` самі.
///   Зверніть увагу, що змінні, захоплені загальним посиланням, завжди реалізовують `Copy` (навіть якщо референт цього не робить), тоді як змінні, захоплені змінним посиланням, ніколи не реалізують `Copy`.
///
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
/// [`String`]: ../../std/string/struct.String.html
/// [`size_of::<T>`]: crate::mem::size_of
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "copy"]
// FIXME(matthewjasper) Це дозволяє копіювати тип, який не реалізує `Copy` через незадоволені строки експлуатації (копіювання `A<'_>`, коли лише `A<'static>: Copy` та `A<'_>: Clone`).
// На даний момент ми маємо цей атрибут лише тому, що на `Copy` існує досить багато спеціалізацій, які вже існують у стандартній бібліотеці, і зараз немає можливості безпечно мати таку поведінку.
//
//
//
//
#[rustc_unsafe_specialization_marker]
pub trait Copy: Clone {
    // Empty.
}

/// Виведіть макрос, що генерує імпульс Portrait `Copy`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Copy($item:item) {
    /* compiler built-in */
}

/// Типи, для яких безпечно ділитися посиланнями між потоками.
///
/// Цей Portrait автоматично реалізується, коли компілятор визначить, що це доречно.
///
/// Точне визначення: тип `T` є [`Sync`] тоді і тільки тоді, коли `&T` є [`Send`].
/// Іншими словами, якщо немає можливості [undefined behavior][ub] (включаючи раси даних) при передачі посилань `&T` між потоками.
///
/// Як і слід було очікувати, примітивні типи, такі як [`u8`] та [`f64`], є всіма [`Sync`], а також прості агреговані типи, що містять їх, такі як кортежі, структури та переліки.
/// Інші приклади базових типів [`Sync`] включають типи "immutable", такі як `&T`, і типи з простою успадкованою мінливістю, такі як [`Box<T>`][box], [`Vec<T>`][vec] та більшість інших типів колекцій.
///
/// (Загальні параметри повинні мати [`Sync`], щоб їх контейнер був [`Sync`].)
///
/// Дещо дивовижним наслідком визначення є те, що `&mut T`-це `Sync` (якщо `T`-`Sync`), хоча, здається, це може забезпечити несинхронізовану мутацію.
/// Фокус у тому, що змінна посилання, що стоїть за спільним посиланням (тобто `& &mut T`), стає лише для читання, ніби це `& &T`.
/// Отже, немає ризику гонки даних.
///
/// Типи, які не є `Sync`-це ті, що мають "interior mutability" у не безпечній для потоку формі, наприклад [`Cell`][cell] та [`RefCell`][refcell].
/// Ці типи дозволяють мутувати їх вміст навіть через незмінні спільні посилання.
/// Наприклад, метод `set` на [`Cell<T>`][cell] приймає `&self`, тому він вимагає лише спільного посилання [`&Cell<T>`][cell].
/// Метод не виконує синхронізацію, тому [`Cell`][cell] не може бути `Sync`.
///
/// Іншим прикладом несинхронного типу є покажчик підрахунку посилань [`Rc`][rc].
/// Враховуючи будь-яке посилання [`&Rc<T>`][rc], ви можете клонувати новий [`Rc<T>`][rc], змінюючи відлік посилань неатомним способом.
///
/// Для випадків, коли потрібна безпечна для різьблення зміна салону, Rust забезпечує [atomic data types], а також явне блокування через [`sync::Mutex`][mutex] та [`sync::RwLock`][rwlock].
/// Ці типи гарантують, що будь-яка мутація не може спричинити раси даних, отже типи є `Sync`.
/// Аналогічно, [`sync::Arc`][arc] забезпечує безпечний для потоків аналог [`Rc`][rc].
///
/// Будь-які типи із внутрішньою мінливістю також повинні використовувати обгортку [`cell::UnsafeCell`][unsafecell] навколо value(s), яка може бути змінена за допомогою спільного посилання.
/// Якщо цього не зробити, це [undefined behavior][ub].
/// Наприклад, ['трансмутувати'][трансмутувати]-інг із `&T` на `&mut T` недійсний.
///
/// Детальніше про `Sync` див. У [the Nomicon][nomicon-send-and-sync].
///
/// [box]: ../../std/boxed/struct.Box.html
/// [vec]: ../../std/vec/struct.Vec.html
/// [cell]: crate::cell::Cell
/// [refcell]: crate::cell::RefCell
/// [rc]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [atomic data types]: crate::sync::atomic
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [unsafecell]: crate::cell::UnsafeCell
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [transmute]: crate::mem::transmute
/// [nomicon-send-and-sync]: ../../nomicon/send-and-sync.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "sync_trait")]
#[lang = "sync"]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be shared between threads safely",
    label = "`{Self}` cannot be shared between threads safely"
)]
pub unsafe auto trait Sync {
    // FIXME(estebank): як тільки підтримка для додавання приміток у `rustc_on_unimplemented` переходить у бета-версію, і вона була розширена, щоб перевірити, чи є закриття де-небудь у ланцюжку вимог, розширте його як такий (#48534):
    //
    //
    // ```
    // on(
    //     closure,
    //     note="`{Self}` cannot be shared safely, consider marking the closure `move`"
    // ),
    // ```

    // Empty
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *mut T {}

macro_rules! impls {
    ($t: ident) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Hash for $t<T> {
            #[inline]
            fn hash<H: Hasher>(&self, _: &mut H) {}
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialEq for $t<T> {
            fn eq(&self, _other: &$t<T>) -> bool {
                true
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Eq for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialOrd for $t<T> {
            fn partial_cmp(&self, _other: &$t<T>) -> Option<cmp::Ordering> {
                Option::Some(cmp::Ordering::Equal)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Ord for $t<T> {
            fn cmp(&self, _other: &$t<T>) -> cmp::Ordering {
                cmp::Ordering::Equal
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Copy for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Clone for $t<T> {
            fn clone(&self) -> Self {
                Self
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Default for $t<T> {
            fn default() -> Self {
                Self
            }
        }

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralPartialEq for $t<T> {}

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralEq for $t<T> {}
    };
}

/// Нульовий розмір, що використовується для позначення речей, які "act like" належать їм `T`.
///
/// Додавання поля `PhantomData<T>` до вашого типу повідомляє компілятору, що ваш тип діє так, ніби він зберігає значення типу `T`, хоча насправді це не так.
/// Ця інформація використовується при обчисленні певних властивостей безпеки.
///
/// Детальніше пояснення щодо використання `PhantomData<T>` див. У розділі [the Nomicon](../../nomicon/phantom-data.html).
///
/// # Жахлива примітка 👻👻👻
///
/// Хоча вони обидва мають страшні назви, `PhantomData` і "фантомні типи" пов'язані, але не однакові.Параметр фантомного типу-це просто параметр типу, який ніколи не використовується.
/// У Rust це часто викликає скаргу компілятора, і рішення полягає в додаванні використання "dummy" через `PhantomData`.
///
/// # Examples
///
/// ## Невикористані параметри життя
///
/// Мабуть, найпоширенішим варіантом використання `PhantomData` є структура, яка має невикористаний параметр терміну служби, як правило, як частина якогось небезпечного коду.
/// Наприклад, ось структура `Slice`, яка має два вказівники типу `*const T`, імовірно, що вказують десь на масив:
///
/// ```compile_fail,E0392
/// struct Slice<'a, T> {
///     start: *const T,
///     end: *const T,
/// }
/// ```
///
/// Намір полягає в тому, що базові дані дійсні лише протягом усього життя `'a`, тому `Slice` не повинен пережити `'a`.
/// Однак цей намір не виражений у коді, оскільки використання `'a` протягом усього життя не застосовується, а отже, незрозуміло, до яких даних воно застосовується.
/// Ми можемо це виправити, сказавши компілятору діяти *так, ніби* структура `Slice` містила посилання `&'a T`:
///
/// ```
/// use std::marker::PhantomData;
///
/// # #[allow(dead_code)]
/// struct Slice<'a, T: 'a> {
///     start: *const T,
///     end: *const T,
///     phantom: PhantomData<&'a T>,
/// }
/// ```
///
/// Для цього також потрібна анотація `T: 'a`, яка вказує, що будь-які посилання в `T` є дійсними протягом усього життя `'a`.
///
/// При ініціалізації `Slice` ви просто вводите значення `PhantomData` для поля `phantom`:
///
/// ```
/// # #![allow(dead_code)]
/// # use std::marker::PhantomData;
/// # struct Slice<'a, T: 'a> {
/// #     start: *const T,
/// #     end: *const T,
/// #     phantom: PhantomData<&'a T>,
/// # }
/// fn borrow_vec<T>(vec: &Vec<T>) -> Slice<'_, T> {
///     let ptr = vec.as_ptr();
///     Slice {
///         start: ptr,
///         end: unsafe { ptr.add(vec.len()) },
///         phantom: PhantomData,
///     }
/// }
/// ```
///
/// ## Параметри невикористаного типу
///
/// Іноді трапляється, що у вас є невикористані параметри типу, які вказують, до якого типу даних відноситься структура "tied", хоча ці дані насправді не знаходяться в самій структурі.
/// Ось приклад, коли це виникає з [FFI].
/// Зовнішній інтерфейс використовує дескриптори типу `*mut ()` для посилання на значення Rust різних типів.
/// Ми відстежуємо тип Rust, використовуючи параметр фантомного типу на структурі `ExternalResource`, яка обгортає ручку.
///
/// [FFI]: ../../book/ch19-01-unsafe-rust.html#using-extern-functions-to-call-external-code
///
/// ```
/// # #![allow(dead_code)]
/// # trait ResType { }
/// # struct ParamType;
/// # mod foreign_lib {
/// #     pub fn new(_: usize) -> *mut () { 42 as *mut () }
/// #     pub fn do_stuff(_: *mut (), _: usize) {}
/// # }
/// # fn convert_params(_: ParamType) -> usize { 42 }
/// use std::marker::PhantomData;
/// use std::mem;
///
/// struct ExternalResource<R> {
///    resource_handle: *mut (),
///    resource_type: PhantomData<R>,
/// }
///
/// impl<R: ResType> ExternalResource<R> {
///     fn new() -> Self {
///         let size_of_res = mem::size_of::<R>();
///         Self {
///             resource_handle: foreign_lib::new(size_of_res),
///             resource_type: PhantomData,
///         }
///     }
///
///     fn do_stuff(&self, param: ParamType) {
///         let foreign_params = convert_params(param);
///         foreign_lib::do_stuff(self.resource_handle, foreign_params);
///     }
/// }
/// ```
///
/// ## Право власності та перевірка падіння
///
/// Додавання поля типу `PhantomData<T>` означає, що ваш тип володіє даними типу `T`.Це, в свою чергу, означає, що коли ваш тип відкидається, він може скинути один або кілька екземплярів типу `T`.
/// Це впливає на аналіз [drop check] компілятора Rust.
///
/// Якщо ваша структура насправді не *володіє* даними типу `T`, краще використовувати контрольний тип, наприклад `PhantomData<&'a T>` (ideally) або `PhantomData<*const T>` (якщо не застосовується термін служби), щоб не вказувати право власності.
///
///
/// [drop check]: ../../nomicon/dropck.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "phantom_data"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct PhantomData<T: ?Sized>;

impls! { PhantomData }

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Sync + ?Sized> Send for &T {}
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Send + ?Sized> Send for &mut T {}
}

/// Внутрішній компілятор Portrait використовується для позначення типу дискримінантів переліку.
///
/// Цей Portrait автоматично реалізується для будь-якого типу і не додає жодних гарантій до [`mem::Discriminant`].
/// Це **невизначена поведінка** для перетворення між `DiscriminantKind::Discriminant` та `mem::Discriminant`.
///
/// [`mem::Discriminant`]: crate::mem::Discriminant
///
#[unstable(
    feature = "discriminant_kind",
    issue = "none",
    reason = "this trait is unlikely to ever be stabilized, use `mem::discriminant` instead"
)]
#[lang = "discriminant_kind"]
pub trait DiscriminantKind {
    /// Тип дискримінанта, який повинен відповідати Portrait bounds, який вимагає `mem::Discriminant`.
    ///
    #[lang = "discriminant_type"]
    type Discriminant: Clone + Copy + Debug + Eq + PartialEq + Hash + Send + Sync + Unpin;
}

/// Внутрішній компілятор Portrait, який використовується для визначення, чи містить тип якийсь `UnsafeCell` всередині, але не за допомогою опосередкованого випромінювання.
///
/// Це впливає, наприклад, на те, чи `static` такого типу буде розміщено в статичній пам`яті, призначеній лише для читання, або статичній пам`яті, що може бути записана.
///
#[lang = "freeze"]
pub(crate) unsafe auto trait Freeze {}

impl<T: ?Sized> !Freeze for UnsafeCell<T> {}
unsafe impl<T: ?Sized> Freeze for PhantomData<T> {}
unsafe impl<T: ?Sized> Freeze for *const T {}
unsafe impl<T: ?Sized> Freeze for *mut T {}
unsafe impl<T: ?Sized> Freeze for &T {}
unsafe impl<T: ?Sized> Freeze for &mut T {}

/// Типи, які можна безпечно переміщати після закріплення.
///
/// Сам Rust не має поняття нерухомих типів і вважає ходи (наприклад, шляхом призначення або [`mem::replace`]) завжди безпечними.
///
/// Замість цього використовується тип [`Pin`][Pin] для запобігання переміщенням по системі типів.Покажчики `P<T>`, загорнуті в обгортку [`Pin<P<T>>`][Pin], не можна висувати.
/// Докладнішу інформацію про закріплення див. У документації [`pin` module].
///
/// Реалізація `Unpin` Portrait для `T` знімає обмеження відкріплення типу, що дозволяє переміщувати `T` з [`Pin<P<T>>`][Pin] за допомогою таких функцій, як [`mem::replace`].
///
///
/// `Unpin` не має жодних наслідків для незакріплених даних.
/// Зокрема, [`mem::replace`] із задоволенням переміщує дані `!Unpin` (він працює для будь-якого `&mut T`, а не лише для `T: Unpin`).
/// Однак ви не можете використовувати [`mem::replace`] для даних, загорнутих у [`Pin<P<T>>`][Pin], оскільки ви не можете отримати потрібний для цього `&mut T`, і саме *це* робить цю систему роботою.
///
/// Так, наприклад, це можна зробити лише на типах, що реалізують `Unpin`:
///
/// ```rust
/// # #![allow(unused_must_use)]
/// use std::mem;
/// use std::pin::Pin;
///
/// let mut string = "this".to_string();
/// let mut pinned_string = Pin::new(&mut string);
///
/// // Нам потрібна змінна посилання для виклику `mem::replace`.
/// // Ми можемо отримати таке посилання, якщо (implicitly) викликає `Pin::deref_mut`, але це можливо лише тому, що `String` реалізує `Unpin`.
/////
/// mem::replace(&mut *pinned_string, "other".to_string());
/// ```
///
/// Цей Portrait автоматично реалізується майже для кожного типу.
///
/// [`mem::replace`]: crate::mem::replace
/// [Pin]: crate::pin::Pin
/// [`pin` module]: crate::pin
///
///
///
///
///
///
#[stable(feature = "pin", since = "1.33.0")]
#[rustc_on_unimplemented(
    on(_Self = "std::future::Future", note = "consider using `Box::pin`",),
    message = "`{Self}` cannot be unpinned"
)]
#[lang = "unpin"]
pub auto trait Unpin {}

/// Тип маркера, який не реалізує `Unpin`.
///
/// Якщо тип містить `PhantomPinned`, він не реалізує `Unpin` за замовчуванням.
#[stable(feature = "pin", since = "1.33.0")]
#[derive(Debug, Default, Copy, Clone, Eq, PartialEq, Ord, PartialOrd, Hash)]
pub struct PhantomPinned;

#[stable(feature = "pin", since = "1.33.0")]
impl !Unpin for PhantomPinned {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a T {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a mut T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *const T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *mut T {}

/// Реалізації `Copy` для примітивних типів.
///
/// Реалізації, які неможливо описати в Rust, реалізовані в `traits::SelectionContext::copy_clone_conditions()` у `rustc_trait_selection`.
///
///
mod copy_impls {

    use super::Copy;

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Copy for ! {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *const T {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *mut T {}

    /// Спільні посилання можна скопіювати, але змінні посилання *не можуть*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for &T {}
}