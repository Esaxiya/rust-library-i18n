//! Оператори, що завантажуються.
//!
//! Реалізація цих traits дозволяє перевантажити певних операторів.
//!
//! Деякі з цих traits імпортуються prelude, тому вони доступні в кожній програмі Rust.Перевантажувати можна лише оператори, які підтримуються traits.
//! Наприклад, оператор додавання (`+`) може бути перевантажений через [`Add`] Portrait, але оскільки оператор присвоєння (`=`) не має підтримки Portrait, немає можливості перевантажити його семантику.
//! Крім того, цей модуль не забезпечує жодного механізму для створення нових операторів.
//! Якщо потрібне беззаперечне перевантаження або користувацькі оператори, слід звернути увагу на макроси або плагіни компілятора, щоб розширити синтаксис Rust.
//!
//! Реалізації оператора traits не повинні дивувати у відповідних контекстах, маючи на увазі їх звичайні значення та [operator precedence].
//! Наприклад, при впровадженні [`Mul`], операція повинна мати певну схожість з множенням (і поділяти очікувані властивості, такі як асоціативність).
//!
//! Зауважте, що оператори `&&` та `||` мають коротке замикання, тобто вони оцінюють свій другий операнд лише у тому випадку, якщо це сприяє результату.Оскільки така поведінка не може бути застосована traits, `&&` та `||` не підтримуються як завантажувані оператори.
//!
//! Багато операторів беруть свої операнди за значенням.У загальних контекстах, що стосуються вбудованих типів, це, як правило, не є проблемою.
//! Однак використання цих операторів у загальному коді вимагає певної уваги, якщо значення потрібно використовувати повторно, а не дозволяти операторам їх споживати.Один із варіантів-це час від часу використовувати [`clone`].
//! Інший варіант-покладатися на задіяні типи, забезпечуючи додаткові реалізації операторів для посилань.
//! Наприклад, для визначеного користувачем типу `T`, який повинен підтримувати додавання, напевно, є гарною ідеєю мати як `T`, так і `&T`, що реалізують traits [`Add<T>`][`Add`] і [`Add<&T>`][`Add`], щоб загальний код можна було писати без зайвого клонування.
//!
//!
//! # Examples
//!
//! Цей приклад створює структуру `Point`, яка реалізує [`Add`] і [`Sub`], а потім демонструє додавання і віднімання двох `Point`s.
//!
//! ```rust
//! use std::ops::{Add, Sub};
//!
//! #[derive(Debug, Copy, Clone, PartialEq)]
//! struct Point {
//!     x: i32,
//!     y: i32,
//! }
//!
//! impl Add for Point {
//!     type Output = Self;
//!
//!     fn add(self, other: Self) -> Self {
//!         Self {x: self.x + other.x, y: self.y + other.y}
//!     }
//! }
//!
//! impl Sub for Point {
//!     type Output = Self;
//!
//!     fn sub(self, other: Self) -> Self {
//!         Self {x: self.x - other.x, y: self.y - other.y}
//!     }
//! }
//!
//! assert_eq!(Point {x: 3, y: 3}, Point {x: 1, y: 0} + Point {x: 2, y: 3});
//! assert_eq!(Point {x: -1, y: -3}, Point {x: 1, y: 0} - Point {x: 2, y: 3});
//! ```
//!
//! Див. Документацію до кожного Portrait для прикладу реалізації.
//!
//! [`Fn`], [`FnMut`] та [`FnOnce`] traits реалізовані за типами, які можна викликати як функції.Зверніть увагу, що [`Fn`] приймає `&self`, [`FnMut`]-`&mut self`, а [`FnOnce`]-`self`.
//! Вони відповідають трьом типам методів, які можна викликати в екземплярі: виклик за посиланням, виклик за змінним посиланням та виклик за значенням.
//! Найбільш поширене використання цих traits-це діяти як межі функцій вищого рівня, які приймають функції або закриття як аргументи.
//!
//! Беручи [`Fn`] як параметр:
//!
//! ```rust
//! fn call_with_one<F>(func: F) -> usize
//!     where F: Fn(usize) -> usize
//! {
//!     func(1)
//! }
//!
//! let double = |x| x * 2;
//! assert_eq!(call_with_one(double), 2);
//! ```
//!
//! Беручи [`FnMut`] як параметр:
//!
//! ```rust
//! fn do_twice<F>(mut func: F)
//!     where F: FnMut()
//! {
//!     func();
//!     func();
//! }
//!
//! let mut x: usize = 1;
//! {
//!     let add_two_to_x = || x += 2;
//!     do_twice(add_two_to_x);
//! }
//!
//! assert_eq!(x, 5);
//! ```
//!
//! Беручи [`FnOnce`] як параметр:
//!
//! ```rust
//! fn consume_with_relish<F>(func: F)
//!     where F: FnOnce() -> String
//! {
//!     // `func` споживає свої захоплені змінні, тому його неможливо запустити більше одного разу
//!     //
//!     println!("Consumed: {}", func());
//!
//!     println!("Delicious!");
//!
//!     // Спроба знову викликати `func()` призведе до помилки `use of moved value` для `func`
//!     //
//! }
//!
//! let x = String::from("x");
//! let consume_and_return_x = move || x;
//! consume_with_relish(consume_and_return_x);
//!
//! // `consume_and_return_x` на даний момент більше не можна викликати
//! ```
//!
//! [`clone`]: Clone::clone
//! [operator precedence]: ../../reference/expressions.html#expression-precedence
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

mod arith;
mod bit;
mod control_flow;
mod deref;
mod drop;
mod function;
mod generator;
mod index;
mod range;
mod r#try;
mod unsize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::arith::{Add, Div, Mul, Neg, Rem, Sub};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::arith::{AddAssign, DivAssign, MulAssign, RemAssign, SubAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::bit::{BitAnd, BitOr, BitXor, Not, Shl, Shr};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::bit::{BitAndAssign, BitOrAssign, BitXorAssign, ShlAssign, ShrAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::deref::{Deref, DerefMut};

#[unstable(feature = "receiver_trait", issue = "none")]
pub use self::deref::Receiver;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::drop::Drop;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::function::{Fn, FnMut, FnOnce};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::index::{Index, IndexMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::range::{Range, RangeFrom, RangeFull, RangeTo};

#[stable(feature = "inclusive_range", since = "1.26.0")]
pub use self::range::{Bound, RangeBounds, RangeInclusive, RangeToInclusive};

#[unstable(feature = "try_trait", issue = "42327")]
pub use self::r#try::Try;

#[unstable(feature = "generator_trait", issue = "43122")]
pub use self::generator::{Generator, GeneratorState};

#[unstable(feature = "coerce_unsized", issue = "27732")]
pub use self::unsize::CoerceUnsized;

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
pub use self::unsize::DispatchFromDyn;

#[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
pub use self::control_flow::ControlFlow;