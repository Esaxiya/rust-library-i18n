use crate::marker::Unsize;

/// Trait, який вказує на те, що це покажчик або обгортка для одного, де може бути виконано зменшення розміру для покажчика.
///
/// Докладніше див. У [DST coercion RFC][dst-coerce] та [the nomicon entry on coercion][nomicon-coerce].
///
/// Для вбудованих типів покажчиків покажчики на `T` примушуватимуться до покажчиків на `U`, якщо `T: Unsize<U>`, перетворюючи з тонкого покажчика на жирний покажчик.
///
/// Для користувальницьких типів примус тут працює, примушуючи `Foo<T>` до `Foo<U>` за умови існування impl `CoerceUnsized<Foo<U>> for Foo<T>`.
/// Такий імпл може бути записаний лише в тому випадку, якщо `Foo<T>` має лише одне поле нефантомних даних із залученням `T`.
/// Якщо типом цього поля є `Bar<T>`, має існувати реалізація `CoerceUnsized<Bar<U>> for Bar<T>`.
/// Примус спрацює шляхом примушування поля `Bar<T>` до `Bar<U>` та заповнення решти полів з `Foo<T>` для створення `Foo<U>`.
/// Це ефективно перенесе до поля покажчика і примусить це.
///
/// Як правило, для розумних покажчиків ви впровадите `CoerceUnsized<Ptr<U>> for Ptr<T> where T: Unsize<U>, U: ?Sized`, а додатковий `?Sized`, прив'язаний до самого `T`.
/// Для типів обгортки, які безпосередньо вбудовують `T`, таких як `Cell<T>` та `RefCell<T>`, ви можете безпосередньо застосувати `CoerceUnsized<Wrap<U>> for Wrap<T> where T: CoerceUnsized<U>`.
///
/// Це дозволить працювати примусу таких типів, як `Cell<Box<T>>`.
///
/// [`Unsize`][unsize] використовується для позначення типів, які можуть бути примусові до літнього часу, якщо є поза покажчиками.Він реалізується автоматично компілятором.
///
/// [dst-coerce]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [unsize]: crate::marker::Unsize
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
///
///
///
///
///
///
#[unstable(feature = "coerce_unsized", issue = "27732")]
#[lang = "coerce_unsized"]
pub trait CoerceUnsized<T: ?Sized> {
    // Empty.
}

// &mut T-> &mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a mut U> for &'a mut T {}
// &mut T-> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b mut T {}
// &mut T-> * mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for &'a mut T {}
// &mut T-> * const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a mut T {}

// &T -> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b T {}
// &T -> * const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a T {}

// *mut T->* mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for *mut T {}
// *mut T->* const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *mut T {}

// *const T->* const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *const T {}

/// Це використовується для захисту об'єкта, щоб перевірити, чи можна надсилати тип приймача методу.
///
/// Приклад реалізації Portrait:
///
/// ```
/// # #![feature(dispatch_from_dyn, unsize)]
/// # use std::{ops::DispatchFromDyn, marker::Unsize};
/// # struct Rc<T: ?Sized>(std::rc::Rc<T>);
/// impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T>
/// where
///     T: Unsize<U>,
/// {}
/// ```
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
#[lang = "dispatch_from_dyn"]
pub trait DispatchFromDyn<T> {
    // Empty.
}

// &T -> &U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a U> for &'a T {}
// &mut T-> &mut U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a mut U> for &'a mut T {}
// *const T->* const U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*const U> for *const T {}
// *mut T->* mut U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*mut U> for *mut T {}