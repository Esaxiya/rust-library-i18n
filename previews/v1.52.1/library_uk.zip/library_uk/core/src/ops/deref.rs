/// Використовується для незмінних операцій перенаправлення, наприклад `*v`.
///
/// На додаток до того, що `Deref` використовується для явних операцій з розмежування посилань з оператором (unary) `*` у незмінних контекстах, компілятор також використовує неявно в багатьох обставинах.
/// Цей механізм називається ['`Deref` coercion'][more].
/// У змінних контекстах використовується [`DerefMut`].
///
/// Впровадження `Deref` для розумних покажчиків робить доступ до даних за ними зручним, саме тому вони реалізують `Deref`.
/// З іншого боку, правила щодо `Deref` та [`DerefMut`] були розроблені спеціально для розміщення розумних покажчиків.
/// Через це **`Deref` слід застосовувати лише для розумних покажчиків**, щоб уникнути плутанини.
///
/// З подібних причин **цей Portrait ніколи не повинен виходити з ладу**.Помилка під час перенаправлення посилань може викликати надзвичайну заплутаність, коли `Deref` викликається неявно.
///
/// # Детальніше про примус `Deref`
///
/// Якщо `T` реалізує `Deref<Target = U>`, а `x`-це значення типу `T`, то:
///
/// * У незмінних контекстах `*x` (де `T` не є ні посиланням, ні необробленим покажчиком) еквівалентний `* Deref::deref(&x)`.
/// * Значення типу `&T` приводяться до значень типу `&U`
/// * `T` неявно реалізує всі методи (immutable) типу `U`.
///
/// Щоб отримати докладнішу інформацію, відвідайте [the chapter in *The Rust Programming Language*][book], а також довідкові розділи на [the dereference operator][ref-deref-op], [method resolution] та [type coercions].
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// Структура з єдиним полем, до якої можна отримати розмежування структури.
///
/// ```
/// use std::ops::Deref;
///
/// struct DerefExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// let x = DerefExample { value: 'a' };
/// assert_eq!('a', *x);
/// ```
///
///
///
///
///
///
///
#[lang = "deref"]
#[doc(alias = "*")]
#[doc(alias = "&*")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Deref"]
pub trait Deref {
    /// Отриманий тип після розмежування посилань.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_target"]
    #[cfg_attr(not(bootstrap), lang = "deref_target")]
    type Target: ?Sized;

    /// Дереференціює значення.
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_method"]
    fn deref(&self) -> &Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &T {
    type Target = T;

    #[rustc_diagnostic_item = "noop_method_deref"]
    fn deref(&self) -> &T {
        *self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !DerefMut for &T {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &mut T {
    type Target = T;

    fn deref(&self) -> &T {
        *self
    }
}

/// Використовується для змінних операцій перенаправлення, як у `*v = 1;`.
///
/// На додаток до того, що `DerefMut` використовується для явних операцій з розмежування посилань за допомогою оператора (unary) `*` у змінних контекстах, компілятор також використовує неявно в багатьох обставинах.
/// Цей механізм називається ['`Deref` coercion'][more].
/// У незмінному контексті використовується [`Deref`].
///
/// Впровадження `DerefMut` для розумних вказівників робить мутацію даних за ними зручною, саме тому вони реалізують `DerefMut`.
/// З іншого боку, правила щодо [`Deref`] та `DerefMut` були розроблені спеціально для розміщення розумних покажчиків.
/// Через це **`DerefMut` слід застосовувати лише для розумних покажчиків**, щоб уникнути плутанини.
///
/// З подібних причин **цей Portrait ніколи не повинен виходити з ладу**.Помилка під час перенаправлення посилань може викликати надзвичайну заплутаність, коли `DerefMut` викликається неявно.
///
/// # Детальніше про примус `Deref`
///
/// Якщо `T` реалізує `DerefMut<Target = U>`, а `x`-це значення типу `T`, то:
///
/// * У змінних контекстах `*x` (де `T` не є ні посиланням, ні необробленим покажчиком) еквівалентний `* DerefMut::deref_mut(&mut x)`.
/// * Значення типу `&mut T` приводяться до значень типу `&mut U`
/// * `T` неявно реалізує всі методи (mutable) типу `U`.
///
/// Щоб отримати докладнішу інформацію, відвідайте [the chapter in *The Rust Programming Language*][book], а також довідкові розділи на [the dereference operator][ref-deref-op], [method resolution] та [type coercions].
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// Структура з єдиним полем, яку можна змінити шляхом розмежування структури.
///
/// ```
/// use std::ops::{Deref, DerefMut};
///
/// struct DerefMutExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefMutExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// impl<T> DerefMut for DerefMutExample<T> {
///     fn deref_mut(&mut self) -> &mut Self::Target {
///         &mut self.value
///     }
/// }
///
/// let mut x = DerefMutExample { value: 'a' };
/// *x = 'b';
/// assert_eq!('b', *x);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "deref_mut"]
#[doc(alias = "*")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DerefMut: Deref {
    /// Значення дереференціюється зі змінами.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn deref_mut(&mut self) -> &mut Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for &mut T {
    fn deref_mut(&mut self) -> &mut T {
        *self
    }
}

/// Вказує на те, що структуру можна використовувати як приймач методів без функції `arbitrary_self_types`.
///
/// Це реалізовано типами покажчиків stdlib, такими як `Box<T>`, `Rc<T>`, `&T` та `Pin<P>`.
#[lang = "receiver"]
#[unstable(feature = "receiver_trait", issue = "none")]
#[doc(hidden)]
pub trait Receiver {
    // Empty.
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &T {}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &mut T {}