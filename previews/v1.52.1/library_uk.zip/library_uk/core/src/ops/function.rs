/// Версія оператора дзвінка, яка приймає незмінний приймач.
///
/// Екземпляри `Fn` можна викликати неодноразово, не змінюючи стан.
///
/// *Цей Portrait (`Fn`) не слід плутати з [function pointers] (`fn`).*
///
/// `Fn` впроваджується автоматично шляхом закриття, яке бере лише незмінні посилання на захоплені змінні або взагалі нічого не фіксує, а також (safe) [function pointers] (з деякими застереженнями, докладнішу інформацію див. у їх документації).
///
/// Крім того, для будь-якого типу `F`, який реалізує `Fn`, `&F` також реалізує `Fn`.
///
/// Оскільки і [`FnMut`], і [`FnOnce`] є суперзнаками `Fn`, будь-який примірник `Fn` може бути використаний як параметр, де очікується [`FnMut`] або [`FnOnce`].
///
/// Використовуйте `Fn` як прив'язку, коли ви хочете прийняти параметр функціонального типу і потрібно викликати його неодноразово і без мутуючого стану (наприклад, при одночасному виклику).
/// Якщо вам не потрібні такі суворі вимоги, використовуйте [`FnMut`] або [`FnOnce`] як обмеження.
///
/// Дивіться [chapter on closures in *The Rust Programming Language*][book] для отримання додаткової інформації з цієї теми.
///
/// Також слід зазначити спеціальний синтаксис для `Fn` traits (наприклад,
/// `Fn(usize, bool) -> usize`).Ті, хто цікавиться технічними деталями цього, можуть звернутися до [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Виклик закриття
///
/// ```
/// let square = |x| x * x;
/// assert_eq!(square(5), 25);
/// ```
///
/// ## Використання параметра `Fn`
///
/// ```
/// fn call_with_one<F>(func: F) -> usize
///     where F: Fn(usize) -> usize {
///     func(1)
/// }
///
/// let double = |x| x * 2;
/// assert_eq!(call_with_one(double), 2);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{Fn}<{Args}>` closure, found `{Self}`",
    label = "expected an `Fn<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // так що regex може покладатися на цей `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait Fn<Args>: FnMut<Args> {
    /// Виконує операцію виклику.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call(&self, args: Args) -> Self::Output;
}

/// Версія оператора дзвінка, яка приймає змінний приймач.
///
/// Екземпляри `FnMut` можна викликати неодноразово і можуть змінювати стан.
///
/// `FnMut` реалізується автоматично шляхом закриття, яке приймає змінні посилання на захоплені змінні, а також усіх типів, що реалізують [`Fn`], наприклад, (safe) [function pointers] (оскільки `FnMut` є супертрейт [`Fn`]).
/// Крім того, для будь-якого типу `F`, який реалізує `FnMut`, `&mut F` також реалізує `FnMut`.
///
/// Оскільки [`FnOnce`] є супертрейтом `FnMut`, будь-який екземпляр `FnMut` може бути використаний там, де очікується [`FnOnce`], а оскільки [`Fn`] є субпортретом `FnMut`, будь-який екземпляр [`Fn`] можна використовувати там, де очікується `FnMut`.
///
/// Використовуйте `FnMut` як прив'язку, коли ви хочете прийняти параметр функціонального типу і потрібно його викликати неодноразово, дозволяючи йому змінювати стан.
/// Якщо ви не хочете, щоб параметр мутував стан, використовуйте [`Fn`] як прив'язаний;якщо вам не потрібно телефонувати повторно, використовуйте [`FnOnce`].
///
/// Дивіться [chapter on closures in *The Rust Programming Language*][book] для отримання додаткової інформації з цієї теми.
///
/// Також слід зазначити спеціальний синтаксис для `Fn` traits (наприклад,
/// `Fn(usize, bool) -> usize`).Ті, хто цікавиться технічними деталями цього, можуть звернутися до [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Виклик мутаційно захоплюючого закриття
///
/// ```
/// let mut x = 5;
/// {
///     let mut square_x = || x *= x;
///     square_x();
/// }
/// assert_eq!(x, 25);
/// ```
///
/// ## Використання параметра `FnMut`
///
/// ```
/// fn do_twice<F>(mut func: F)
///     where F: FnMut()
/// {
///     func();
///     func();
/// }
///
/// let mut x: usize = 1;
/// {
///     let add_two_to_x = || x += 2;
///     do_twice(add_two_to_x);
/// }
///
/// assert_eq!(x, 5);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn_mut"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnMut}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnMut<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // так що regex може покладатися на цей `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnMut<Args>: FnOnce<Args> {
    /// Виконує операцію виклику.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_mut(&mut self, args: Args) -> Self::Output;
}

/// Версія оператора виклику, яка приймає приймач, що має значення.
///
/// Можна викликати екземпляри `FnOnce`, але їх не можна викликати кілька разів.Через це, якщо про тип відомо лише те, що він реалізує `FnOnce`, його можна викликати лише один раз.
///
/// `FnOnce` впроваджується автоматично шляхом закриття, яке може споживати захоплені змінні, а також усіх типів, що реалізують [`FnMut`], наприклад, (safe) [function pointers] (оскільки `FnOnce`-супертрейт [`FnMut`]).
///
///
/// Оскільки і [`Fn`], і [`FnMut`] є підмірами `FnOnce`, будь-який екземпляр [`Fn`] або [`FnMut`] можна використовувати там, де очікується `FnOnce`.
///
/// Використовуйте `FnOnce` як прив'язку, коли ви хочете прийняти параметр функціонального типу і потрібно викликати його лише один раз.
/// Якщо вам потрібно повторно викликати параметр, використовуйте [`FnMut`] як прив'язаний;якщо він вам також потрібен, щоб не мутувати стан, використовуйте [`Fn`].
///
/// Дивіться [chapter on closures in *The Rust Programming Language*][book] для отримання додаткової інформації з цієї теми.
///
/// Також слід зазначити спеціальний синтаксис для `Fn` traits (наприклад,
/// `Fn(usize, bool) -> usize`).Ті, хто цікавиться технічними деталями цього, можуть звернутися до [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Використання параметра `FnOnce`
///
/// ```
/// fn consume_with_relish<F>(func: F)
///     where F: FnOnce() -> String
/// {
///     // `func` споживає свої захоплені змінні, тому його неможливо запустити більше одного разу.
/////
///     println!("Consumed: {}", func());
///
///     println!("Delicious!");
///
///     // Спроба знову викликати `func()` призведе до помилки `use of moved value` для `func`.
/////
/// }
///
/// let x = String::from("x");
/// let consume_and_return_x = move || x;
/// consume_with_relish(consume_and_return_x);
///
/// // `consume_and_return_x` на даний момент більше не можна викликати
/// ```
///
///
///
///
///
///
///
///
#[lang = "fn_once"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnOnce}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnOnce<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // так що regex може покладатися на цей `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnOnce<Args> {
    /// Повернений тип після використання оператора виклику.
    #[lang = "fn_once_output"]
    #[stable(feature = "fn_once_output", since = "1.12.0")]
    type Output;

    /// Виконує операцію виклику.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_once(self, args: Args) -> Self::Output;
}

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> Fn<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call(&self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &F
    where
        F: Fn<A>,
    {
        type Output = F::Output;

        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &mut F
    where
        F: FnMut<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &mut F
    where
        F: FnMut<A>,
    {
        type Output = F::Output;
        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }
}