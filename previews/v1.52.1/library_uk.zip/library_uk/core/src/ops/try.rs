/// Portrait для налаштування поведінки оператора `?`.
///
/// Тип, що реалізує `Try`-це той, який має канонічний спосіб розглянути його з точки зору дихотомії success/failure.
/// Цей Portrait дозволяє як витягувати ці значення успіху чи відмови з існуючого екземпляра, так і створювати новий екземпляр із значення успіху чи відмови.
///
///
#[unstable(feature = "try_trait", issue = "42327")]
#[rustc_on_unimplemented(
    on(
        all(
            any(from_method = "from_error", from_method = "from_ok"),
            from_desugaring = "QuestionMark"
        ),
        message = "the `?` operator can only be used in {ItemContext} \
                    that returns `Result` or `Option` \
                    (or another type that implements `{Try}`)",
        label = "cannot use the `?` operator in {ItemContext} that returns `{Self}`",
        enclosing_scope = "this function should return `Result` or `Option` to accept `?`"
    ),
    on(
        all(from_method = "into_result", from_desugaring = "QuestionMark"),
        message = "the `?` operator can only be applied to values \
                    that implement `{Try}`",
        label = "the `?` operator cannot be applied to type `{Self}`"
    )
)]
#[doc(alias = "?")]
#[lang = "try"]
pub trait Try {
    /// Тип цього значення, коли розглядається як успішне.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Ok;
    /// Тип цього значення при розгляді як помилковий.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Error;

    /// Застосовує оператор "?".Повернення `Ok(t)` означає, що виконання має тривати нормально, а результатом `?` є значення `t`.
    /// Повернення `Err(e)` означає, що виконання має виконуватися branch до самого внутрішнього, що обгороджує `catch`, або повернення із функції.
    ///
    /// Якщо повертається результат `Err(e)`, значенням `e` буде "wrapped" у типі повернення охоплюючої області (яка сама повинна реалізовувати `Try`).
    ///
    /// Зокрема, повертається значення `X::from_error(From::from(e))`, де `X`-це тип повернення функції, що включає.
    ///
    ///
    ///
    #[lang = "into_result"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn into_result(self) -> Result<Self::Ok, Self::Error>;

    /// Оберніть значення помилки для побудови складеного результату.
    /// Наприклад, `Result::Err(x)` та `Result::from_error(x)` еквівалентні.
    #[lang = "from_error"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_error(v: Self::Error) -> Self;

    /// Оберніть значення ОК, щоб побудувати складений результат.
    /// Наприклад, `Result::Ok(x)` та `Result::from_ok(x)` еквівалентні.
    #[lang = "from_ok"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_ok(v: Self::Ok) -> Self;
}