use crate::char;
use crate::convert::TryFrom;
use crate::mem;
use crate::ops::{self, Try};

use super::{FusedIterator, TrustedLen};

/// Об'єкти, що мають поняття *операції наступника* та *попередника*.
///
/// Операція *наступник* рухається до значень, які порівнюються більшими.
/// Операція *попередник* рухається до значень, які порівнюють менші.
///
/// # Safety
///
/// Цей Portrait є `unsafe`, оскільки його реалізація повинна бути правильною для безпеки реалізацій `unsafe trait TrustedLen`, а результати використання цього Portrait можуть бути довірені кодом `unsafe` як правильні та виконувати перелічені зобов`язання.
///
///
///
#[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
pub unsafe trait Step: Clone + PartialOrd + Sized {
    /// Повертає кількість кроків *наступника*, необхідних для переходу від `start` до `end`.
    ///
    /// Повертає `None`, якщо кількість кроків переповнює `usize` (або нескінченна, або якщо `end` ніколи не буде досягнуто).
    ///
    ///
    /// # Invariants
    ///
    /// Для будь-яких `a`, `b` та `n`:
    ///
    /// * `steps_between(&a, &b) == Some(n)` тоді і тільки тоді, коли `Step::forward_checked(&a, n) == Some(b)`
    /// * `steps_between(&a, &b) == Some(n)` тоді і тільки тоді, коли `Step::backward_checked(&a, n) == Some(a)`
    /// * `steps_between(&a, &b) == Some(n)` лише якщо `a <= b`
    ///   * Висновок: `steps_between(&a, &b) == Some(0)` тоді і тільки тоді, коли `a == b`
    ///   * Зверніть увагу, що `a <= b` означає, що _not_ означає `steps_between(&a, &b) != None`;
    ///     це той випадок, коли для переходу до `b` потрібно більше кроків `usize::MAX`
    /// * `steps_between(&a, &b) == None` якщо `a > b`
    fn steps_between(start: &Self, end: &Self) -> Option<usize>;

    /// Повертає значення, яке було б отримано, взявши *наступника*`self` `count` разів.
    ///
    /// Якщо це переповнює діапазон значень, підтримуваних `Self`, повертає `None`.
    ///
    /// # Invariants
    ///
    /// Для будь-яких `a`, `n` та `m`:
    ///
    /// * `Step::forward_checked(a, n).and_then(|x| Step::forward_checked(x, m)) == Step::forward_checked(a, m).and_then(|x| Step::forward_checked(x, n))`
    ///
    ///
    /// Для будь-яких `a`, `n` та `m`, де `n + m` не переповнюється:
    ///
    /// * `Step::forward_checked(a, n).and_then(|x| Step::forward_checked(x, m)) == Step::forward_checked(a, n + m)`
    ///
    /// Для будь-яких `a` та `n`:
    ///
    /// * `Step::forward_checked(a, n) == (0..n).try_fold(a, |x, _| Step::forward_checked(&x, 1))`
    ///   * Corollary: `Step::forward_checked(&a, 0) == Some(a)`
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn forward_checked(start: Self, count: usize) -> Option<Self>;

    /// Повертає значення, яке було б отримано, взявши *наступника*`self` `count` разів.
    ///
    /// Якщо це перевищить діапазон значень, що підтримуються `Self`, ця функція дозволена для panic, обтікання або насичення.
    ///
    /// Запропонована поведінка стосується panic, коли ввімкнено твердження про налагодження, а також обертати або насичувати інакше.
    ///
    /// Небезпечний код не повинен покладатися на правильність поведінки після переповнення.
    ///
    /// # Invariants
    ///
    /// Для будь-яких `a`, `n` та `m`, де не відбувається переповнення:
    ///
    /// * `Step::forward(Step::forward(a, n), m) == Step::forward(a, n + m)`
    ///
    /// Для будь-яких `a` та `n`, де не відбувається переповнення:
    ///
    /// * `Step::forward_checked(a, n) == Some(Step::forward(a, n))`
    /// * `Step::forward(a, n) == (0..n).fold(a, |x, _| Step::forward(x, 1))`
    ///   * Corollary: `Step::forward(a, 0) == a`
    /// * `Step::forward(a, n) >= a`
    /// * `Step::backward(Step::forward(a, n), n) == a`
    ///
    ///
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn forward(start: Self, count: usize) -> Self {
        Step::forward_checked(start, count).expect("overflow in `Step::forward`")
    }

    /// Повертає значення, яке було б отримано, взявши *наступника*`self` `count` разів.
    ///
    /// # Safety
    ///
    /// Це невизначена поведінка для цієї операції для переповнення діапазону значень, підтримуваних `Self`.
    /// Якщо ви не можете гарантувати, що це не переллється, використовуйте замість цього `forward` або `forward_checked`.
    ///
    /// # Invariants
    ///
    /// Для будь-якого `a`:
    ///
    /// * якщо існує `b`, такий як `b > a`, можна сміливо дзвонити на `Step::forward_unchecked(a, 1)`
    /// * якщо існує `b`, `n`, такий як `steps_between(&a, &b) == Some(n)`, безпечно викликати `Step::forward_unchecked(a, m)` для будь-якого `m <= n`.
    ///
    ///
    /// Для будь-яких `a` та `n`, де не відбувається переповнення:
    ///
    /// * `Step::forward_unchecked(a, n)` еквівалентно `Step::forward(a, n)`
    ///
    ///
    #[unstable(feature = "unchecked_math", reason = "niche optimization path", issue = "none")]
    unsafe fn forward_unchecked(start: Self, count: usize) -> Self {
        Step::forward(start, count)
    }

    /// Повертає значення, яке було б отримано, взявши *попередник*`self` `count` разів.
    ///
    /// Якщо це переповнює діапазон значень, підтримуваних `Self`, повертає `None`.
    ///
    /// # Invariants
    ///
    /// Для будь-яких `a`, `n` та `m`:
    ///
    /// * `Step::backward_checked(a, n).and_then(|x| Step::backward_checked(x, m)) == n.checked_add(m).and_then(|x| Step::backward_checked(a, x))`
    ///
    /// * `Step::backward_checked(a, n).and_then(|x| Step::backward_checked(x, m)) == try { Step::backward_checked(a, n.checked_add(m)?) }`
    ///
    /// Для будь-яких `a` та `n`:
    ///
    /// * `Step::backward_checked(a, n) == (0..n).try_fold(a, |x, _| Step::backward_checked(&x, 1))`
    ///   * Corollary: `Step::backward_checked(&a, 0) == Some(a)`
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn backward_checked(start: Self, count: usize) -> Option<Self>;

    /// Повертає значення, яке було б отримано, взявши *попередник*`self` `count` разів.
    ///
    /// Якщо це перевищить діапазон значень, що підтримуються `Self`, ця функція дозволена для panic, обтікання або насичення.
    ///
    /// Запропонована поведінка стосується panic, коли ввімкнено твердження про налагодження, а також обертати або насичувати інакше.
    ///
    /// Небезпечний код не повинен покладатися на правильність поведінки після переповнення.
    ///
    /// # Invariants
    ///
    /// Для будь-яких `a`, `n` та `m`, де не відбувається переповнення:
    ///
    /// * `Step::backward(Step::backward(a, n), m) == Step::backward(a, n + m)`
    ///
    /// Для будь-яких `a` та `n`, де не відбувається переповнення:
    ///
    /// * `Step::backward_checked(a, n) == Some(Step::backward(a, n))`
    /// * `Step::backward(a, n) == (0..n).fold(a, |x, _| Step::backward(x, 1))`
    ///   * Corollary: `Step::backward(a, 0) == a`
    /// * `Step::backward(a, n) <= a`
    /// * `Step::forward(Step::backward(a, n), n) == a`
    ///
    ///
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn backward(start: Self, count: usize) -> Self {
        Step::backward_checked(start, count).expect("overflow in `Step::backward`")
    }

    /// Повертає значення, яке було б отримано, взявши *попередник*`self` `count` разів.
    ///
    /// # Safety
    ///
    /// Це невизначена поведінка для цієї операції для переповнення діапазону значень, підтримуваних `Self`.
    /// Якщо ви не можете гарантувати, що це не переллється, використовуйте замість цього `backward` або `backward_checked`.
    ///
    /// # Invariants
    ///
    /// Для будь-якого `a`:
    ///
    /// * якщо існує `b`, такий як `b < a`, можна сміливо дзвонити на `Step::backward_unchecked(a, 1)`
    /// * якщо існує `b`, `n`, такий як `steps_between(&b, &a) == Some(n)`, безпечно викликати `Step::backward_unchecked(a, m)` для будь-якого `m <= n`.
    ///
    ///
    /// Для будь-яких `a` та `n`, де не відбувається переповнення:
    ///
    /// * `Step::backward_unchecked(a, n)` еквівалентно `Step::backward(a, n)`
    ///
    ///
    #[unstable(feature = "unchecked_math", reason = "niche optimization path", issue = "none")]
    unsafe fn backward_unchecked(start: Self, count: usize) -> Self {
        Step::backward(start, count)
    }
}

// Вони все ще генеруються за допомогою макросів, оскільки цілочисельні літерали вирішують різні типи.
macro_rules! step_identical_methods {
    () => {
        #[inline]
        unsafe fn forward_unchecked(start: Self, n: usize) -> Self {
            // БЕЗПЕКА: абонент повинен гарантувати, що `start + n` не переповнюється.
            unsafe { start.unchecked_add(n as Self) }
        }

        #[inline]
        unsafe fn backward_unchecked(start: Self, n: usize) -> Self {
            // БЕЗПЕКА: абонент повинен гарантувати, що `start - n` не переповнюється.
            unsafe { start.unchecked_sub(n as Self) }
        }

        #[inline]
        #[allow(arithmetic_overflow)]
        #[rustc_inherit_overflow_checks]
        fn forward(start: Self, n: usize) -> Self {
            // У збірках налагодження запускайте panic при переповненні.
            // Це має повністю оптимізувати збірки випусків.
            if Self::forward_checked(start, n).is_none() {
                let _ = Self::MAX + 1;
            }
            // Виконайте математичну обгортку, щоб дозволити, наприклад `Step::forward(-128i8, 255)`.
            start.wrapping_add(n as Self)
        }

        #[inline]
        #[allow(arithmetic_overflow)]
        #[rustc_inherit_overflow_checks]
        fn backward(start: Self, n: usize) -> Self {
            // У збірках налагодження запускайте panic при переповненні.
            // Це має повністю оптимізувати збірки випусків.
            if Self::backward_checked(start, n).is_none() {
                let _ = Self::MIN - 1;
            }
            // Виконайте математичну обгортку, щоб дозволити, наприклад `Step::backward(127i8, 255)`.
            start.wrapping_sub(n as Self)
        }
    };
}

macro_rules! step_integer_impls {
    {
        narrower than or same width as usize:
            $( [ $u_narrower:ident $i_narrower:ident ] ),+;
        wider than usize:
            $( [ $u_wider:ident $i_wider:ident ] ),+;
    } => {
        $(
            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $u_narrower {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        // Це залежить від $u_narrower <=usize
                        Some((*end - *start) as usize)
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    match Self::try_from(n) {
                        Ok(n) => start.checked_add(n),
                        Err(_) => None, // якщо n виходить за межі діапазону, `unsigned_start + n` теж
                    }
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    match Self::try_from(n) {
                        Ok(n) => start.checked_sub(n),
                        Err(_) => None, // якщо n виходить за межі діапазону, `unsigned_start - n` теж
                    }
                }
            }

            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $i_narrower {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        // Це залежить від $i_narrower <=usize
                        //
                        // Відливання в isize збільшує ширину, але зберігає знак.
                        // Використовуйте wrapping_sub у просторі isize і приводьте для використання, щоб обчислити різницю, яка може не входити в діапазон isize.
                        //
                        Some((*end as isize).wrapping_sub(*start as isize) as usize)
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    match $u_narrower::try_from(n) {
                        Ok(n) => {
                            // Обгортання обробляє такі випадки, як `Step::forward(-120_i8, 200) == Some(80_i8)`, навіть незважаючи на те, що 200 є поза діапазоном для i8.
                            //
                            //
                            let wrapped = start.wrapping_add(n as Self);
                            if wrapped >= start {
                                Some(wrapped)
                            } else {
                                None // Додавання переповнене
                            }
                        }
                        // Якщо n виходить за межі діапазону, наприклад
                        // u8, тоді він більший, ніж весь діапазон для i8, тому `any_i8 + n` обов'язково переповнює i8.
                        //
                        Err(_) => None,
                    }
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    match $u_narrower::try_from(n) {
                        Ok(n) => {
                            // Обгортання обробляє такі випадки, як `Step::forward(-120_i8, 200) == Some(80_i8)`, навіть незважаючи на те, що 200 є поза діапазоном для i8.
                            //
                            //
                            let wrapped = start.wrapping_sub(n as Self);
                            if wrapped <= start {
                                Some(wrapped)
                            } else {
                                None // Віднімання переповнене
                            }
                        }
                        // Якщо n виходить за межі діапазону, наприклад
                        // u8, тоді він більший, ніж весь діапазон для i8, тому `any_i8 - n` обов'язково переповнює i8.
                        //
                        Err(_) => None,
                    }
                }
            }
        )+

        $(
            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $u_wider {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        usize::try_from(*end - *start).ok()
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_add(n as Self)
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_sub(n as Self)
                }
            }

            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $i_wider {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        match end.checked_sub(*start) {
                            Some(result) => usize::try_from(result).ok(),
                            // Якщо різниця занадто велика, наприклад
                            // i128, він також буде занадто великим для використання з меншою кількістю бітів.
                            None => None,
                        }
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_add(n as Self)
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_sub(n as Self)
                }
            }
        )+
    };
}

#[cfg(target_pointer_width = "64")]
step_integer_impls! {
    narrower than or same width as usize: [u8 i8], [u16 i16], [u32 i32], [u64 i64], [usize isize];
    wider than usize: [u128 i128];
}

#[cfg(target_pointer_width = "32")]
step_integer_impls! {
    narrower than or same width as usize: [u8 i8], [u16 i16], [u32 i32], [usize isize];
    wider than usize: [u64 i64], [u128 i128];
}

#[cfg(target_pointer_width = "16")]
step_integer_impls! {
    narrower than or same width as usize: [u8 i8], [u16 i16], [usize isize];
    wider than usize: [u32 i32], [u64 i64], [u128 i128];
}

#[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
unsafe impl Step for char {
    #[inline]
    fn steps_between(&start: &char, &end: &char) -> Option<usize> {
        let start = start as u32;
        let end = end as u32;
        if start <= end {
            let count = end - start;
            if start < 0xD800 && 0xE000 <= end {
                usize::try_from(count - 0x800).ok()
            } else {
                usize::try_from(count).ok()
            }
        } else {
            None
        }
    }

    #[inline]
    fn forward_checked(start: char, count: usize) -> Option<char> {
        let start = start as u32;
        let mut res = Step::forward_checked(start, count)?;
        if start < 0xD800 && 0xD800 <= res {
            res = Step::forward_checked(res, 0x800)?;
        }
        if res <= char::MAX as u32 {
            // БЕЗПЕКА: res-це дійсний скаляр Unicode
            // (нижче 0x110000, а не в 0xD800..0xE000)
            Some(unsafe { char::from_u32_unchecked(res) })
        } else {
            None
        }
    }

    #[inline]
    fn backward_checked(start: char, count: usize) -> Option<char> {
        let start = start as u32;
        let mut res = Step::backward_checked(start, count)?;
        if start >= 0xE000 && 0xE000 > res {
            res = Step::backward_checked(res, 0x800)?;
        }
        // БЕЗПЕКА: res-це дійсний скаляр Unicode
        // (нижче 0x110000, а не в 0xD800..0xE000)
        Some(unsafe { char::from_u32_unchecked(res) })
    }

    #[inline]
    unsafe fn forward_unchecked(start: char, count: usize) -> char {
        let start = start as u32;
        // БЕЗПЕКА: абонент повинен гарантувати, що це не переповнюється
        // діапазон значень для символу.
        let mut res = unsafe { Step::forward_unchecked(start, count) };
        if start < 0xD800 && 0xD800 <= res {
            // БЕЗПЕКА: абонент повинен гарантувати, що це не переповнюється
            // діапазон значень для символу.
            res = unsafe { Step::forward_unchecked(res, 0x800) };
        }
        // БЕЗПЕКА: через попередній контракт це гарантовано
        // абонентом бути дійсним символом.
        unsafe { char::from_u32_unchecked(res) }
    }

    #[inline]
    unsafe fn backward_unchecked(start: char, count: usize) -> char {
        let start = start as u32;
        // БЕЗПЕКА: абонент повинен гарантувати, що це не переповнюється
        // діапазон значень для символу.
        let mut res = unsafe { Step::backward_unchecked(start, count) };
        if start >= 0xE000 && 0xE000 > res {
            // БЕЗПЕКА: абонент повинен гарантувати, що це не переповнюється
            // діапазон значень для символу.
            res = unsafe { Step::backward_unchecked(res, 0x800) };
        }
        // БЕЗПЕКА: через попередній контракт це гарантовано
        // абонентом бути дійсним символом.
        unsafe { char::from_u32_unchecked(res) }
    }
}

macro_rules! range_exact_iter_impl {
    ($($t:ty)*) => ($(
        #[stable(feature = "rust1", since = "1.0.0")]
        impl ExactSizeIterator for ops::Range<$t> { }
    )*)
}

macro_rules! range_incl_exact_iter_impl {
    ($($t:ty)*) => ($(
        #[stable(feature = "inclusive_range", since = "1.26.0")]
        impl ExactSizeIterator for ops::RangeInclusive<$t> { }
    )*)
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Step> Iterator for ops::Range<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        if self.start < self.end {
            // БЕЗПЕКА: щойно перевірена передумова
            let n = unsafe { Step::forward_unchecked(self.start.clone(), 1) };
            Some(mem::replace(&mut self.start, n))
        } else {
            None
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.start < self.end {
            let hint = Step::steps_between(&self.start, &self.end);
            (hint.unwrap_or(usize::MAX), hint)
        } else {
            (0, Some(0))
        }
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<A> {
        if let Some(plus_n) = Step::forward_checked(self.start.clone(), n) {
            if plus_n < self.end {
                // БЕЗПЕКА: щойно перевірена передумова
                self.start = unsafe { Step::forward_unchecked(plus_n.clone(), 1) };
                return Some(plus_n);
            }
        }

        self.start = self.end.clone();
        None
    }

    #[inline]
    fn last(mut self) -> Option<A> {
        self.next_back()
    }

    #[inline]
    fn min(mut self) -> Option<A> {
        self.next()
    }

    #[inline]
    fn max(mut self) -> Option<A> {
        self.next_back()
    }
}

// Ці макроси генерують імпульси `ExactSizeIterator` для різних типів діапазону.
//
// * `ExactSizeIterator::len` потрібно завжди повертати точний `usize`, тому жоден діапазон не може бути довшим за `usize::MAX`.
//
// * Для цілочисельних типів у `Range<_>` це стосується типів, вужчих або ширших за `usize`.
//   Для цілочисельних типів у `RangeInclusive<_>` це стосується типів *строго вужчих*, ніж `usize`, оскільки, наприклад
//   `(0..=u64::MAX).len()` буде `u64::MAX + 1`.
//
range_exact_iter_impl! {
    usize u8 u16
    isize i8 i16

    // Вони є недоречними відповідно до наведених вище міркувань, але їх видалення було б надзвичайною зміною, оскільки вони були стабілізовані в Rust 1.0.0.
    // Так наприклад
    // `(0..66_000_u32).len()` наприклад, компілюватиметься без помилок та попереджень на 16-розрядних платформах, але продовжуватиме давати неправильний результат.
    //
    u32
    i32
}
range_incl_exact_iter_impl! {
    u8
    i8

    // Вони є недоречними відповідно до наведених вище міркувань, але їх видалення було б надзвичайною зміною, оскільки вони були стабілізовані в Rust 1.26.0.
    // Так наприклад
    // `(0..=u16::MAX).len()` наприклад, компілюватиметься без помилок та попереджень на 16-розрядних платформах, але продовжуватиме давати неправильний результат.
    //
    u16
    i16
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Step> DoubleEndedIterator for ops::Range<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        if self.start < self.end {
            // БЕЗПЕКА: щойно перевірена передумова
            self.end = unsafe { Step::backward_unchecked(self.end.clone(), 1) };
            Some(self.end.clone())
        } else {
            None
        }
    }

    #[inline]
    fn nth_back(&mut self, n: usize) -> Option<A> {
        if let Some(minus_n) = Step::backward_checked(self.end.clone(), n) {
            if minus_n > self.start {
                // БЕЗПЕКА: щойно перевірена передумова
                self.end = unsafe { Step::backward_unchecked(minus_n, 1) };
                return Some(self.end.clone());
            }
        }

        self.end = self.start.clone();
        None
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Step> TrustedLen for ops::Range<A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Step> FusedIterator for ops::Range<A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Step> Iterator for ops::RangeFrom<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        let n = Step::forward(self.start.clone(), 1);
        Some(mem::replace(&mut self.start, n))
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<A> {
        let plus_n = Step::forward(self.start.clone(), n);
        self.start = Step::forward(plus_n.clone(), 1);
        Some(plus_n)
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Step> FusedIterator for ops::RangeFrom<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Step> TrustedLen for ops::RangeFrom<A> {}

#[stable(feature = "inclusive_range", since = "1.26.0")]
impl<A: Step> Iterator for ops::RangeInclusive<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        if self.is_empty() {
            return None;
        }
        let is_iterating = self.start < self.end;
        Some(if is_iterating {
            // БЕЗПЕКА: щойно перевірена передумова
            let n = unsafe { Step::forward_unchecked(self.start.clone(), 1) };
            mem::replace(&mut self.start, n)
        } else {
            self.exhausted = true;
            self.start.clone()
        })
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.is_empty() {
            return (0, Some(0));
        }

        match Step::steps_between(&self.start, &self.end) {
            Some(hint) => (hint.saturating_add(1), hint.checked_add(1)),
            None => (usize::MAX, None),
        }
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<A> {
        if self.is_empty() {
            return None;
        }

        if let Some(plus_n) = Step::forward_checked(self.start.clone(), n) {
            use crate::cmp::Ordering::*;

            match plus_n.partial_cmp(&self.end) {
                Some(Less) => {
                    self.start = Step::forward(plus_n.clone(), 1);
                    return Some(plus_n);
                }
                Some(Equal) => {
                    self.start = plus_n.clone();
                    self.exhausted = true;
                    return Some(plus_n);
                }
                _ => {}
            }
        }

        self.start = self.end.clone();
        self.exhausted = true;
        None
    }

    #[inline]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        if self.is_empty() {
            return try { init };
        }

        let mut accum = init;

        while self.start < self.end {
            // БЕЗПЕКА: щойно перевірена передумова
            let n = unsafe { Step::forward_unchecked(self.start.clone(), 1) };
            let n = mem::replace(&mut self.start, n);
            accum = f(accum, n)?;
        }

        self.exhausted = true;

        if self.start == self.end {
            accum = f(accum, self.start.clone())?;
        }

        try { accum }
    }

    #[inline]
    fn fold<B, F>(mut self, init: B, f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_fold(init, ok(f)).unwrap()
    }

    #[inline]
    fn last(mut self) -> Option<A> {
        self.next_back()
    }

    #[inline]
    fn min(mut self) -> Option<A> {
        self.next()
    }

    #[inline]
    fn max(mut self) -> Option<A> {
        self.next_back()
    }
}

#[stable(feature = "inclusive_range", since = "1.26.0")]
impl<A: Step> DoubleEndedIterator for ops::RangeInclusive<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        if self.is_empty() {
            return None;
        }
        let is_iterating = self.start < self.end;
        Some(if is_iterating {
            // БЕЗПЕКА: щойно перевірена передумова
            let n = unsafe { Step::backward_unchecked(self.end.clone(), 1) };
            mem::replace(&mut self.end, n)
        } else {
            self.exhausted = true;
            self.end.clone()
        })
    }

    #[inline]
    fn nth_back(&mut self, n: usize) -> Option<A> {
        if self.is_empty() {
            return None;
        }

        if let Some(minus_n) = Step::backward_checked(self.end.clone(), n) {
            use crate::cmp::Ordering::*;

            match minus_n.partial_cmp(&self.start) {
                Some(Greater) => {
                    self.end = Step::backward(minus_n.clone(), 1);
                    return Some(minus_n);
                }
                Some(Equal) => {
                    self.end = minus_n.clone();
                    self.exhausted = true;
                    return Some(minus_n);
                }
                _ => {}
            }
        }

        self.end = self.start.clone();
        self.exhausted = true;
        None
    }

    #[inline]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        if self.is_empty() {
            return try { init };
        }

        let mut accum = init;

        while self.start < self.end {
            // БЕЗПЕКА: щойно перевірена передумова
            let n = unsafe { Step::backward_unchecked(self.end.clone(), 1) };
            let n = mem::replace(&mut self.end, n);
            accum = f(accum, n)?;
        }

        self.exhausted = true;

        if self.start == self.end {
            accum = f(accum, self.start.clone())?;
        }

        try { accum }
    }

    #[inline]
    fn rfold<B, F>(mut self, init: B, f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_rfold(init, ok(f)).unwrap()
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Step> TrustedLen for ops::RangeInclusive<A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Step> FusedIterator for ops::RangeInclusive<A> {}