use crate::iter::{FusedIterator, TrustedLen};

/// Створює ітератор, який ліниво генерує значення рівно один раз, викликаючи надане закриття.
///
/// Це зазвичай використовується для адаптації генератора одного значення до [`chain()`] інших видів ітерацій.
/// Можливо, у вас є ітератор, який охоплює майже все, але вам потрібен додатковий особливий випадок.
/// Можливо, у вас є функція, яка працює на ітераторах, але вам потрібно обробити лише одне значення.
///
/// На відміну від [`once()`], ця функція буде ліниво генерувати значення за запитом.
///
/// [`chain()`]: Iterator::chain
/// [`once()`]: crate::iter::once
///
/// # Examples
///
/// Основне використання:
///
/// ```
/// use std::iter;
///
/// // один-це самотнє число
/// let mut one = iter::once_with(|| 1);
///
/// assert_eq!(Some(1), one.next());
///
/// // лише один, це все, що ми отримуємо
/// assert_eq!(None, one.next());
/// ```
///
/// Прив`язка разом з іншим ітератором.
/// Скажімо, ми хочемо виконати ітерацію кожного файлу каталогу `.foo`, а також файлу конфігурації,
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // нам потрібно перетворити з ітератора DirEntry-s на ітератор PathBufs, тому ми використовуємо map
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // тепер наш ітератор саме для нашого конфігураційного файлу
/// let config = iter::once_with(|| PathBuf::from(".foorc"));
///
/// // з`єднайте два ітератори в один великий ітератор
/// let files = dirs.chain(config);
///
/// // це дасть нам усі файли в .foo, а також .foorc
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
///
#[inline]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub fn once_with<A, F: FnOnce() -> A>(gen: F) -> OnceWith<F> {
    OnceWith { gen: Some(gen) }
}

/// Ітератор, який дає один елемент типу `A`, застосовуючи надане закриття `F: FnOnce() -> A`.
///
///
/// Цей `struct` створений функцією [`once_with()`].
/// Докладніше див. У його документації.
#[derive(Clone, Debug)]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub struct OnceWith<F> {
    gen: Option<F>,
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> Iterator for OnceWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        let f = self.gen.take()?;
        Some(f())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.gen.iter().size_hint()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> DoubleEndedIterator for OnceWith<F> {
    fn next_back(&mut self) -> Option<A> {
        self.next()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> ExactSizeIterator for OnceWith<F> {
    fn len(&self) -> usize {
        self.gen.iter().len()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> FusedIterator for OnceWith<F> {}

#[stable(feature = "iter_once_with", since = "1.43.0")]
unsafe impl<A, F: FnOnce() -> A> TrustedLen for OnceWith<F> {}