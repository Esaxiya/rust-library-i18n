use crate::iter::{FusedIterator, TrustedLen};

/// Створює новий ітератор, який нескінченно повторює елементи типу `A`, застосовуючи надане закриття, ретранслятор, `F: FnMut() -> A`.
///
/// Функція `repeat_with()` знову і знову викликає повторювач.
///
/// Нескінченні ітератори, такі як `repeat_with()`, часто використовуються з такими адаптерами, як [`Iterator::take()`], щоб зробити їх кінцевими.
///
/// Якщо тип елемента потрібного вам ітератора реалізує [`Clone`], і зберігати вихідний елемент у пам'яті нормально, замість цього слід використовувати функцію [`repeat()`].
///
///
/// Ітератор, вироблений `repeat_with()`, не є [`DoubleEndedIterator`].
/// Якщо вам потрібно `repeat_with()`, щоб повернути [`DoubleEndedIterator`], відкрийте проблему GitHub із поясненням вашого випадку використання.
///
/// [`repeat()`]: crate::iter::repeat
/// [`DoubleEndedIterator`]: crate::iter::DoubleEndedIterator
///
/// # Examples
///
/// Основне використання:
///
/// ```
/// use std::iter;
///
/// // припустимо, у нас є якесь значення типу, який не є `Clone` або який не хоче мати в пам'яті лише тому, що він дорогий:
/////
/// #[derive(PartialEq, Debug)]
/// struct Expensive;
///
/// // певне значення назавжди:
/// let mut things = iter::repeat_with(|| Expensive);
///
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// ```
///
/// Використання мутації та скінчення:
///
/// ```rust
/// use std::iter;
///
/// // Від нульового до третього ступеня двох:
/// let mut curr = 1;
/// let mut pow2 = iter::repeat_with(|| { let tmp = curr; curr *= 2; tmp })
///                     .take(4);
///
/// assert_eq!(Some(1), pow2.next());
/// assert_eq!(Some(2), pow2.next());
/// assert_eq!(Some(4), pow2.next());
/// assert_eq!(Some(8), pow2.next());
///
/// // ... і тепер ми закінчили
/// assert_eq!(None, pow2.next());
/// ```
///
///
///
///
#[inline]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub fn repeat_with<A, F: FnMut() -> A>(repeater: F) -> RepeatWith<F> {
    RepeatWith { repeater }
}

/// Ітератор, який нескінченно повторює елементи типу `A`, застосовуючи надане закриття `F: FnMut() -> A`.
///
///
/// Цей `struct` створений функцією [`repeat_with()`].
/// Докладніше див. У його документації.
#[derive(Copy, Clone, Debug)]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub struct RepeatWith<F> {
    repeater: F,
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> Iterator for RepeatWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some((self.repeater)())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> FusedIterator for RepeatWith<F> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A, F: FnMut() -> A> TrustedLen for RepeatWith<F> {}