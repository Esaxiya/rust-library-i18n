use crate::iter::{FusedIterator, TrustedLen};

/// Створює новий ітератор, який нескінченно повторює один елемент.
///
/// Функція `repeat()` повторює одне значення знову і знову.
///
/// Нескінченні ітератори, такі як `repeat()`, часто використовуються з такими адаптерами, як [`Iterator::take()`], щоб зробити їх кінцевими.
///
/// Якщо тип елемента потрібного вам ітератора не реалізує `Clone`, або якщо ви не хочете зберігати повторюваний елемент у пам'яті, ви можете замість цього використовувати функцію [`repeat_with()`].
///
///
/// [`repeat_with()`]: crate::iter::repeat_with
///
/// # Examples
///
/// Основне використання:
///
/// ```
/// use std::iter;
///
/// // число чотири 4евер:
/// let mut fours = iter::repeat(4);
///
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
///
/// // так, ще чотири
/// assert_eq!(Some(4), fours.next());
/// ```
///
/// Станете кінцевим з [`Iterator::take()`]:
///
/// ```
/// use std::iter;
///
/// // останній приклад-занадто багато четвірок.Давайте матимемо лише чотири четвірки.
/// let mut four_fours = iter::repeat(4).take(4);
///
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
///
/// // ... і тепер ми закінчили
/// assert_eq!(None, four_fours.next());
/// ```
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn repeat<T: Clone>(elt: T) -> Repeat<T> {
    Repeat { element: elt }
}

/// Ітератор, який нескінченно повторює елемент.
///
/// Цей `struct` створений функцією [`repeat()`].Докладніше див. У його документації.
#[derive(Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Repeat<A> {
    element: A,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> Iterator for Repeat<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> DoubleEndedIterator for Repeat<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Clone> FusedIterator for Repeat<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Clone> TrustedLen for Repeat<A> {}