use crate::iter::{FusedIterator, TrustedLen};

/// Створює ітератор, який дає елемент рівно один раз.
///
/// Це зазвичай використовується для адаптації одного значення до [`chain()`] інших видів ітерацій.
/// Можливо, у вас є ітератор, який охоплює майже все, але вам потрібен додатковий особливий випадок.
/// Можливо, у вас є функція, яка працює на ітераторах, але вам потрібно обробити лише одне значення.
///
/// [`chain()`]: Iterator::chain
///
/// # Examples
///
/// Основне використання:
///
/// ```
/// use std::iter;
///
/// // один-це самотнє число
/// let mut one = iter::once(1);
///
/// assert_eq!(Some(1), one.next());
///
/// // лише один, це все, що ми отримуємо
/// assert_eq!(None, one.next());
/// ```
///
/// Прив`язка разом з іншим ітератором.
/// Скажімо, ми хочемо виконати ітерацію кожного файлу каталогу `.foo`, а також файлу конфігурації,
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // нам потрібно перетворити з ітератора DirEntry-s на ітератор PathBufs, тому ми використовуємо map
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // тепер наш ітератор саме для нашого конфігураційного файлу
/// let config = iter::once(PathBuf::from(".foorc"));
///
/// // з`єднайте два ітератори в один великий ітератор
/// let files = dirs.chain(config);
///
/// // це дасть нам усі файли в .foo, а також .foorc
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
#[stable(feature = "iter_once", since = "1.2.0")]
pub fn once<T>(value: T) -> Once<T> {
    Once { inner: Some(value).into_iter() }
}

/// Ітератор, який дає елемент рівно один раз.
///
/// Цей `struct` створений функцією [`once()`].Докладніше див. У його документації.
#[derive(Clone, Debug)]
#[stable(feature = "iter_once", since = "1.2.0")]
pub struct Once<T> {
    inner: crate::option::IntoIter<T>,
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> Iterator for Once<T> {
    type Item = T;

    fn next(&mut self) -> Option<T> {
        self.inner.next()
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> DoubleEndedIterator for Once<T> {
    fn next_back(&mut self) -> Option<T> {
        self.inner.next_back()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> ExactSizeIterator for Once<T> {
    fn len(&self) -> usize {
        self.inner.len()
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T> TrustedLen for Once<T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Once<T> {}