use crate::ops::{ControlFlow, Try};

/// Ітератор, здатний видавати елементи з обох кінців.
///
/// Щось, що реалізує `DoubleEndedIterator`, має одну додаткову здатність порівняно з реалізацією [`Iterator`]: можливість також брати `Предмети` ззаду, а також спереду.
///
///
/// Важливо зазначити, що і вперед, і вперед працюють на одному діапазоні, і не перетинаються: ітерація закінчується, коли вони зустрічаються посередині.
///
/// Подібно до протоколу [`Iterator`], як тільки `DoubleEndedIterator` повертає [`None`] з [`next_back()`], повторний виклик може повернути або не повернути [`Some`] знову.
/// [`next()`] і [`next_back()`] є взаємозамінними для цієї мети.
///
/// [`next_back()`]: DoubleEndedIterator::next_back
/// [`next()`]: Iterator::next
///
/// # Examples
///
/// Основне використання:
///
/// ```
/// let numbers = vec![1, 2, 3, 4, 5, 6];
///
/// let mut iter = numbers.iter();
///
/// assert_eq!(Some(&1), iter.next());
/// assert_eq!(Some(&6), iter.next_back());
/// assert_eq!(Some(&5), iter.next_back());
/// assert_eq!(Some(&2), iter.next());
/// assert_eq!(Some(&3), iter.next());
/// assert_eq!(Some(&4), iter.next());
/// assert_eq!(None, iter.next());
/// assert_eq!(None, iter.next_back());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DoubleEndedIterator: Iterator {
    /// Видаляє та повертає елемент з кінця ітератора.
    ///
    /// Повертає `None`, коли більше немає елементів.
    ///
    /// Документи [trait-level] містять більше деталей.
    ///
    /// [trait-level]: DoubleEndedIterator
    ///
    /// # Examples
    ///
    /// Основне використання:
    ///
    /// ```
    /// let numbers = vec![1, 2, 3, 4, 5, 6];
    ///
    /// let mut iter = numbers.iter();
    ///
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&6), iter.next_back());
    /// assert_eq!(Some(&5), iter.next_back());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    /// assert_eq!(Some(&4), iter.next());
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next_back());
    /// ```
    ///
    /// # Remarks
    ///
    /// Елементи, отримані методами `DoubleEndedIterator`, можуть відрізнятися від елементів, отриманих методами [`Iterator`]:
    ///
    ///
    /// ```
    /// let vec = vec![(1, 'a'), (1, 'b'), (1, 'c'), (2, 'a'), (2, 'b')];
    /// let uniq_by_fst_comp = || {
    ///     let mut seen = std::collections::HashSet::new();
    ///     vec.iter().copied().filter(move |x| seen.insert(x.0))
    /// };
    ///
    /// assert_eq!(uniq_by_fst_comp().last(), Some((2, 'a')));
    /// assert_eq!(uniq_by_fst_comp().next_back(), Some((2, 'b')));
    ///
    /// assert_eq!(
    ///     uniq_by_fst_comp().fold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(1, 'a'), (2, 'a')]
    /// );
    /// assert_eq!(
    ///     uniq_by_fst_comp().rfold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(2, 'b'), (1, 'c')]
    /// );
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next_back(&mut self) -> Option<Self::Item>;

    /// Просуває ітератор ззаду елементами `n`.
    ///
    /// `advance_back_by` - це зворотна версія [`advance_by`].Цей метод охоче пропускає елементи `n`, починаючи із зворотного боку, викликаючи [`next_back`] до `n` разів, поки не зустрінеться [`None`].
    ///
    /// `advance_back_by(n)` поверне [`Ok(())`], якщо ітератор успішно просувається за елементами `n`, або [`Err(k)`], якщо зустрічається [`None`], де `k`-це кількість елементів, за допомогою яких ітератор просувається до закінчення елементів (тобто
    /// довжина ітератора).
    /// Зверніть увагу, що `k` завжди менше, ніж `n`.
    ///
    /// Виклик `advance_back_by(0)` не споживає жодних елементів і завжди повертає [`Ok(())`].
    ///
    /// [`advance_by`]: Iterator::advance_by
    /// [`next_back`]: DoubleEndedIterator::next_back
    ///
    /// # Examples
    ///
    /// Основне використання:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [3, 4, 5, 6];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_back_by(2), Ok(()));
    /// assert_eq!(iter.next_back(), Some(&4));
    /// assert_eq!(iter.advance_back_by(0), Ok(()));
    /// assert_eq!(iter.advance_back_by(100), Err(1)); // було пропущено лише `&3`
    /// ```
    ///
    /// [`Ok(())`]: Ok
    /// [`Err(k)`]: Err
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next_back().ok_or(i)?;
        }
        Ok(())
    }

    /// Повертає `n`-й елемент з кінця ітератора.
    ///
    /// Це, по суті, зворотна версія [`Iterator::nth()`].
    /// Хоча, як і більшість операцій індексування, відлік починається з нуля, тому `nth_back(0)` повертає перше значення з кінця, `nth_back(1)`-друге тощо.
    ///
    ///
    /// Зверніть увагу, що всі елементи між кінцем та повернутим елементом будуть спожиті, включаючи повернутий елемент.
    /// Це також означає, що виклик `nth_back(0)` кілька разів на одному ітераторі поверне різні елементи.
    ///
    /// `nth_back()` поверне [`None`], якщо `n` більше або дорівнює довжині ітератора.
    ///
    /// # Examples
    ///
    /// Основне використання:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(2), Some(&1));
    /// ```
    ///
    /// Виклик `nth_back()` кілька разів не перемотує ітератор:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth_back(1), Some(&2));
    /// assert_eq!(iter.nth_back(1), None);
    /// ```
    ///
    /// Повернення `None`, якщо елементів менше `n + 1`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(10), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_nth_back", since = "1.37.0")]
    fn nth_back(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_back_by(n).ok()?;
        self.next_back()
    }

    /// Це зворотна версія [`Iterator::try_fold()`]: вона бере елементи, починаючи з задньої частини ітератора.
    ///
    ///
    /// # Examples
    ///
    /// Основне використання:
    ///
    /// ```
    /// let a = ["1", "2", "3"];
    /// let sum = a.iter()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert_eq!(sum, Ok(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = ["1", "rust", "3"];
    /// let mut it = a.iter();
    /// let sum = it
    ///     .by_ref()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert!(sum.is_err());
    ///
    /// // Через коротке замикання, інші елементи все ще доступні через ітератор.
    /////
    /// assert_eq!(it.next_back(), Some(&"1"));
    /// ```
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// Метод ітератора, який зменшує елементи ітератора до одного остаточного значення, починаючи із зворотного боку.
    ///
    /// Це зворотна версія [`Iterator::fold()`]: вона бере елементи, починаючи з задньої частини ітератора.
    ///
    /// `rfold()` приймає два аргументи: початкове значення та закриття двома аргументами: 'accumulator' та елементом.
    /// Закриття повертає значення, яке має мати накопичувач для наступної ітерації.
    ///
    /// Початкове значення-це значення, яке акумулятор матиме під час першого виклику.
    ///
    /// Після застосування цього замикання до кожного елемента ітератора `rfold()` повертає акумулятор.
    ///
    /// Цю операцію іноді називають 'reduce' або 'inject'.
    ///
    /// Складання корисне, коли у вас є колекція чогось, і ви хочете отримати з цього єдине значення.
    ///
    /// # Examples
    ///
    /// Основне використання:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // сума всіх елементів a
    /// let sum = a.iter()
    ///            .rfold(0, |acc, &x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// Цей приклад будує рядок, починаючи з початкового значення і продовжуючи з кожним елементом ззаду до фронту:
    ///
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let zero = "0".to_string();
    ///
    /// let result = numbers.iter().rfold(zero, |acc, &x| {
    ///     format!("({} + {})", x, acc)
    /// });
    ///
    /// assert_eq!(result, "(1 + (2 + (3 + (4 + (5 + 0)))))");
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfold", since = "1.27.0")]
    fn rfold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x);
        }
        accum
    }

    /// Шукає елемент ітератора з тильної сторони, який задовольняє предикату.
    ///
    /// `rfind()` приймає закриття, яке повертає `true` або `false`.
    /// Він застосовує це закриття до кожного елемента ітератора, починаючи з кінця, і якщо будь-який з них повертає `true`, тоді `rfind()` повертає [`Some(element)`].
    /// Якщо всі вони повертають `false`, він повертає [`None`].
    ///
    /// `rfind()` має коротке замикання;іншими словами, він припинить обробку, як тільки закриття поверне `true`.
    ///
    /// Оскільки `rfind()` бере посилання, і багато ітератори перебирають посилання, це призводить до можливо заплутаної ситуації, коли аргумент є подвійним посиланням.
    ///
    /// Ви можете побачити цей ефект у прикладах нижче з `&&x`.
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// Основне використання:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 5), None);
    /// ```
    ///
    /// Зупинка на першому `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rfind(|&&x| x == 2), Some(&2));
    ///
    /// // ми все ще можемо використовувати `iter`, оскільки елементів більше.
    /// assert_eq!(iter.next_back(), Some(&1));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfind", since = "1.27.0")]
    fn rfind<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_rfold((), check(predicate)).break_value()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, I: DoubleEndedIterator + ?Sized> DoubleEndedIterator for &'a mut I {
    fn next_back(&mut self) -> Option<I::Item> {
        (**self).next_back()
    }
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_back_by(n)
    }
    fn nth_back(&mut self, n: usize) -> Option<I::Item> {
        (**self).nth_back(n)
    }
}