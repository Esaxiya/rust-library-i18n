/// Ітератор, який знає його точну довжину.
///
/// Багато [`Iterator`] не знають, скільки разів будуть повторювати, але деякі знають.
/// Якщо ітератор знає, скільки разів він може повторюватись, надання доступу до цієї інформації може бути корисним.
/// Наприклад, якщо ви хочете повторити рух назад, хорошим початком є знання, де кінець.
///
/// Під час впровадження `ExactSizeIterator`, ви також повинні впровадити [`Iterator`].
/// При цьому реалізація [`Iterator::size_hint`]*повинна* повертати точний розмір ітератора.
///
/// Метод [`len`] має реалізацію за замовчуванням, тому зазвичай не слід його реалізовувати.
/// Однак ви можете забезпечити більш ефективну реалізацію, ніж за замовчуванням, тому перевизначення її в цьому випадку має сенс.
///
///
/// Зверніть увагу, що цей Portrait є безпечним Portrait і як такий *не* і *не може* гарантувати правильність повернутої довжини.
/// Це означає, що код `unsafe`**не повинен** покладатися на правильність [`Iterator::size_hint`].
/// Нестабільний і небезпечний [`TrustedLen`](super::marker::TrustedLen) Portrait дає цю додаткову гарантію.
///
/// [`len`]: ExactSizeIterator::len
///
/// # Examples
///
/// Основне використання:
///
/// ```
/// // кінцевий діапазон точно знає, скільки разів він буде повторюватися
/// let five = 0..5;
///
/// assert_eq!(5, five.len());
/// ```
///
/// У [module-level docs] ми впровадили [`Iterator`], `Counter`.
/// Давайте впровадимо `ExactSizeIterator` і для нього:
///
/// [module-level docs]: crate::iter
///
/// ```
/// # struct Counter {
/// #     count: usize,
/// # }
/// # impl Counter {
/// #     fn new() -> Counter {
/// #         Counter { count: 0 }
/// #     }
/// # }
/// # impl Iterator for Counter {
/// #     type Item = usize;
/// #     fn next(&mut self) -> Option<Self::Item> {
/// #         self.count += 1;
/// #         if self.count < 6 {
/// #             Some(self.count)
/// #         } else {
/// #             None
/// #         }
/// #     }
/// # }
/// impl ExactSizeIterator for Counter {
///     // Ми можемо легко розрахувати залишкову кількість ітерацій.
///     fn len(&self) -> usize {
///         5 - self.count
///     }
/// }
///
/// // І тепер ми можемо цим скористатися!
///
/// let counter = Counter::new();
///
/// assert_eq!(5, counter.len());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ExactSizeIterator: Iterator {
    /// Повертає точну довжину ітератора.
    ///
    /// Реалізація гарантує, що ітератор поверне саме `len()` більше разів значення [`Some(T)`], перш ніж повертати [`None`].
    ///
    /// Цей метод має реалізацію за замовчуванням, тому зазвичай не слід реалізовувати його безпосередньо.
    /// Однак, якщо ви можете забезпечити більш ефективне впровадження, ви можете це зробити.
    /// Для прикладу див. Документи [trait-level].
    ///
    /// Ця функція має ті самі гарантії безпеки, що і функція [`Iterator::size_hint`].
    ///
    /// [trait-level]: ExactSizeIterator
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// Основне використання:
    ///
    /// ```
    /// // кінцевий діапазон точно знає, скільки разів він буде повторюватися
    /// let five = 0..5;
    ///
    /// assert_eq!(5, five.len());
    /// ```
    ///
    ///
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn len(&self) -> usize {
        let (lower, upper) = self.size_hint();
        // Note: Це твердження є надто захисним, але воно перевіряє інваріант
        // гарантується Portrait.
        // Якби цей Portrait був rust-внутрішнім, ми могли б використати debug_assert !;assert_eq!також перевірить усі реалізації користувачів Rust.
        //
        assert_eq!(upper, Some(lower));
        lower
    }

    /// Повертає `true`, якщо ітератор порожній.
    ///
    /// Цей метод має реалізацію за замовчуванням із використанням [`ExactSizeIterator::len()`], тому вам не потрібно реалізовувати його самостійно.
    ///
    ///
    /// # Examples
    ///
    /// Основне використання:
    ///
    /// ```
    /// #![feature(exact_size_is_empty)]
    ///
    /// let mut one_element = std::iter::once(0);
    /// assert!(!one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), Some(0));
    /// assert!(one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), None);
    /// ```
    #[inline]
    #[unstable(feature = "exact_size_is_empty", issue = "35428")]
    fn is_empty(&self) -> bool {
        self.len() == 0
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator + ?Sized> ExactSizeIterator for &mut I {
    fn len(&self) -> usize {
        (**self).len()
    }
    fn is_empty(&self) -> bool {
        (**self).is_empty()
    }
}