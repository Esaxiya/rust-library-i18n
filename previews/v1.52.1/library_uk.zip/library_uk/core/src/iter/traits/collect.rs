/// Перетворення з [`Iterator`].
///
/// Реалізуючи `FromIterator` для типу, ви визначаєте, як він буде створений з ітератора.
/// Це характерно для типів, які описують якусь колекцію.
///
/// [`FromIterator::from_iter()`] рідко називається явно, і замість цього використовується за допомогою методу [`Iterator::collect()`].
///
/// Докладніші приклади див. У документації [`Iterator::collect()`]'s.
///
/// Дивитися також: [`IntoIterator`].
///
/// # Examples
///
/// Основне використання:
///
/// ```
/// use std::iter::FromIterator;
///
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v = Vec::from_iter(five_fives);
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// Використання [`Iterator::collect()`] для неявного використання `FromIterator`:
///
/// ```
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v: Vec<i32> = five_fives.collect();
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// Впровадження `FromIterator` для вашого типу:
///
/// ```
/// use std::iter::FromIterator;
///
/// // Колекція зразків, це просто обгортка над Vec<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Давайте дамо йому кілька методів, щоб ми могли створити один і додати до нього речі.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // і ми реалізуємо FromIterator
/// impl FromIterator<i32> for MyCollection {
///     fn from_iter<I: IntoIterator<Item=i32>>(iter: I) -> Self {
///         let mut c = MyCollection::new();
///
///         for i in iter {
///             c.add(i);
///         }
///
///         c
///     }
/// }
///
/// // Тепер ми можемо зробити новий ітератор ...
/// let iter = (0..5).into_iter();
///
/// // ... і зробіть із цього MyCollection
/// let c = MyCollection::from_iter(iter);
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
///
/// // збирати твори теж!
///
/// let iter = (0..5).into_iter();
/// let c: MyCollection = iter.collect();
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "a value of type `{Self}` cannot be built from an iterator \
               over elements of type `{A}`",
    label = "value of type `{Self}` cannot be built from `std::iter::Iterator<Item={A}>`"
)]
pub trait FromIterator<A>: Sized {
    /// Створює значення з ітератора.
    ///
    /// Докладніше див. У [module-level documentation].
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// Основне використання:
    ///
    /// ```
    /// use std::iter::FromIterator;
    ///
    /// let five_fives = std::iter::repeat(5).take(5);
    ///
    /// let v = Vec::from_iter(five_fives);
    ///
    /// assert_eq!(v, vec![5, 5, 5, 5, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_iter<T: IntoIterator<Item = A>>(iter: T) -> Self;
}

/// Перетворення на [`Iterator`].
///
/// Реалізуючи `IntoIterator` для типу, ви визначаєте, як він буде перетворений в ітератор.
/// Це характерно для типів, які описують якусь колекцію.
///
/// Однією з переваг впровадження `IntoIterator` є те, що ваш тип буде [work with Rust's `for` loop syntax](crate::iter#for-loops-and-intoiterator).
///
///
/// Дивитися також: [`FromIterator`].
///
/// # Examples
///
/// Основне використання:
///
/// ```
/// let v = vec![1, 2, 3];
/// let mut iter = v.into_iter();
///
/// assert_eq!(Some(1), iter.next());
/// assert_eq!(Some(2), iter.next());
/// assert_eq!(Some(3), iter.next());
/// assert_eq!(None, iter.next());
/// ```
/// Впровадження `IntoIterator` для вашого типу:
///
/// ```
/// // Колекція зразків, це просто обгортка над Vec<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Давайте дамо йому кілька методів, щоб ми могли створити один і додати до нього речі.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // і ми реалізуємо IntoIterator
/// impl IntoIterator for MyCollection {
///     type Item = i32;
///     type IntoIter = std::vec::IntoIter<Self::Item>;
///
///     fn into_iter(self) -> Self::IntoIter {
///         self.0.into_iter()
///     }
/// }
///
/// // Тепер ми можемо зробити нову колекцію ...
/// let mut c = MyCollection::new();
///
/// // ... додайте до нього трохи речей ...
/// c.add(0);
/// c.add(1);
/// c.add(2);
///
/// // ... а потім перетворіть його на ітератор:
/// for (i, n) in c.into_iter().enumerate() {
///     assert_eq!(i as i32, n);
/// }
/// ```
///
/// Загальноприйнятим є використання `IntoIterator` як Portrait bound.Це дозволяє змінювати тип колекції вводу, якщо він все ще є ітератором.
/// Додаткові межі можна вказати, обмеживши на
/// `Item`:
///
/// ```rust
/// fn collect_as_strings<T>(collection: T) -> Vec<String>
/// where
///     T: IntoIterator,
///     T::Item: std::fmt::Debug,
/// {
///     collection
///         .into_iter()
///         .map(|item| format!("{:?}", item))
///         .collect()
/// }
/// ```
///
///
#[rustc_diagnostic_item = "IntoIterator"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait IntoIterator {
    /// Тип елементів, що повторюються.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// В який ітератор ми перетворюємо це?
    #[stable(feature = "rust1", since = "1.0.0")]
    type IntoIter: Iterator<Item = Self::Item>;

    /// Створює ітератор зі значення.
    ///
    /// Докладніше див. У [module-level documentation].
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// Основне використання:
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    /// let mut iter = v.into_iter();
    ///
    /// assert_eq!(Some(1), iter.next());
    /// assert_eq!(Some(2), iter.next());
    /// assert_eq!(Some(3), iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    #[lang = "into_iter"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into_iter(self) -> Self::IntoIter;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator> IntoIterator for I {
    type Item = I::Item;
    type IntoIter = I;

    fn into_iter(self) -> I {
        self
    }
}

/// Розширити колекцію вмістом ітератора.
///
/// Ітератори створюють ряд значень, а колекції також можна розглядати як низку значень.
/// `Extend` Portrait заповнює цю прогалину, дозволяючи розширити колекцію, включивши вміст цього ітератора.
/// При розширенні колекції за вже існуючим ключем цей запис оновлюється, або, якщо колекції дозволяють кілька записів з однаковими ключами, цей запис вставляється.
///
///
/// # Examples
///
/// Основне використання:
///
/// ```
/// // Ви можете розширити рядок деякими символами:
/// let mut message = String::from("The first three letters are: ");
///
/// message.extend(&['a', 'b', 'c']);
///
/// assert_eq!("abc", &message[29..32]);
/// ```
///
/// Впровадження `Extend`:
///
/// ```
/// // Колекція зразків, це просто обгортка над Vec<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Давайте дамо йому кілька методів, щоб ми могли створити один і додати до нього речі.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // оскільки MyCollection має список i32, ми впроваджуємо Extend для i32
/// impl Extend<i32> for MyCollection {
///
///     // Це трохи простіше з конкретним підписом типу: ми можемо викликати розширення на все, що можна перетворити на ітератор, який дає нам i32.
///     // Тому що нам потрібні i32, щоб помістити їх у MyCollection.
/////
///     fn extend<T: IntoIterator<Item=i32>>(&mut self, iter: T) {
///
///         // Реалізація дуже проста: цикл через ітератор і add() кожен елемент для нас самих.
/////
///         for elem in iter {
///             self.add(elem);
///         }
///     }
/// }
///
/// let mut c = MyCollection::new();
///
/// c.add(5);
/// c.add(6);
/// c.add(7);
///
/// // давайте розширимо нашу колекцію ще трьома номерами
/// c.extend(vec![1, 2, 3]);
///
/// // ми додали ці елементи в кінці
/// assert_eq!("MyCollection([5, 6, 7, 1, 2, 3])", format!("{:?}", c));
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Extend<A> {
    /// Розширює колекцію вмістом ітератора.
    ///
    /// Оскільки це єдиний необхідний метод для цього Portrait, документи [trait-level] містять більше деталей.
    ///
    ///
    /// [trait-level]: Extend
    ///
    /// # Examples
    ///
    /// Основне використання:
    ///
    /// ```
    /// // Ви можете розширити рядок деякими символами:
    /// let mut message = String::from("abc");
    ///
    /// message.extend(['d', 'e', 'f'].iter());
    ///
    /// assert_eq!("abcdef", &message);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn extend<T: IntoIterator<Item = A>>(&mut self, iter: T);

    /// Розширює колекцію лише одним елементом.
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_one(&mut self, item: A) {
        self.extend(Some(item));
    }

    /// Резерв ємності в колекції для заданої кількості додаткових елементів.
    ///
    /// Реалізація за замовчуванням нічого не робить.
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_reserve(&mut self, additional: usize) {
        let _ = additional;
    }
}

#[stable(feature = "extend_for_unit", since = "1.28.0")]
impl Extend<()> for () {
    fn extend<T: IntoIterator<Item = ()>>(&mut self, iter: T) {
        iter.into_iter().for_each(drop)
    }
    fn extend_one(&mut self, _item: ()) {}
}