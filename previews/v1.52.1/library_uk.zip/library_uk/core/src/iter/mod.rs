//! Компонуюча зовнішня ітерація.
//!
//! Якщо ви виявили якусь колекцію і вам потрібно виконати операцію над елементами цієї колекції, ви швидко натрапите на 'iterators'.
//! Ітератори широко використовуються в ідіоматичному коді Rust, тому варто ознайомитися з ними.
//!
//! Перш ніж пояснювати більше, давайте поговоримо про те, як побудований цей модуль:
//!
//! # Organization
//!
//! Цей модуль в основному організований за типом:
//!
//! * [Traits] є основною частиною: ці traits визначають, які ітератори існують і що з ними можна робити.Методи цих traits варто витратити додатковий час на вивчення.
//! * [Functions] надати корисні способи створення базових ітераторів.
//! * [Structs] часто є типами повернення різних методів на traits цього модуля.Зазвичай ви хочете подивитися на метод, який створює `struct`, а не на сам `struct`.
//! Детальніше про те, чому, див. У розділі [[Впровадження ітератора](#реализации-итератор) '.
//!
//! [Traits]: #traits
//! [Functions]: #functions
//! [Structs]: #structs
//!
//! Це воно!Давайте копатимемося в ітераторах.
//!
//! # Iterator
//!
//! Серцем і душею цього модуля є [`Iterator`] Portrait.Ядро [`Iterator`] виглядає так:
//!
//! ```
//! trait Iterator {
//!     type Item;
//!     fn next(&mut self) -> Option<Self::Item>;
//! }
//! ```
//!
//! Ітератор має метод [`next`], який при виклику повертає [`Option`]`<Item>`.
//! [`next`] поверне [`Some(Item)`] до тих пір, поки є елементи, і як тільки вони будуть вичерпані, поверне `None`, щоб вказати, що ітерація закінчена.
//! Окремі ітератори можуть вибрати відновити ітерацію, і тому повторний виклик [`next`] може, а може і не почати повертати [`Some(Item)`] знову в якийсь момент (наприклад, див. [`TryIter`]).
//!
//!
//! Повне визначення [`Iterator`] включає також ряд інших методів, але це методи за замовчуванням, побудовані на вершині [`next`], і тому ви отримуєте їх безкоштовно.
//!
//! Ітератори також можна скласти, і зазвичай їх об`єднують, щоб виконувати більш складні форми обробки.Детальніше див. У розділі [Adapters](#adapters) нижче.
//!
//! [`Some(Item)`]: Some
//! [`next`]: Iterator::next
//! [`TryIter`]: ../../std/sync/mpsc/struct.TryIter.html
//!
//! # Три форми ітерації
//!
//! Існує три загальних методи, які можуть створювати ітератори з колекції:
//!
//! * `iter()`, який повторюється через `&T`.
//! * `iter_mut()`, який повторюється через `&mut T`.
//! * `into_iter()`, який повторюється через `T`.
//!
//! Різні речі в стандартній бібліотеці можуть реалізовувати одну або більше з трьох, де це доречно.
//!
//! # Впровадження ітератора
//!
//! Створення власного ітератора включає два етапи: створення `struct` для збереження стану ітератора, а потім реалізація [`Iterator`] для цього `struct`.
//! Ось чому в цьому модулі так багато `структур`: по одному для кожного ітератора та адаптера ітератора.
//!
//! Давайте зробимо ітератор на ім`я `Counter`, який вважатиме від `1` до `5`:
//!
//! ```
//! // По-перше, структура:
//!
//! /// Ітератор, який рахує від одного до п`яти
//! struct Counter {
//!     count: usize,
//! }
//!
//! // ми хочемо, щоб наш підрахунок починався з одиниці, тому давайте додамо метод new() на допомогу.
//! // Це не є суворо необхідним, але зручним.
//! // Зверніть увагу, що ми починаємо `count` з нуля, ми побачимо, чому в реалізації `next()`'s нижче.
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // Потім ми впроваджуємо `Iterator` для нашого `Counter`:
//!
//! impl Iterator for Counter {
//!     // ми будемо рахувати з використанням
//!     type Item = usize;
//!
//!     // next() є єдиним необхідним методом
//!     fn next(&mut self) -> Option<Self::Item> {
//!         // Збільште наш рахунок.Ось чому ми почали з нуля.
//!         self.count += 1;
//!
//!         // Перевірте, закінчили ми підрахунок чи ні.
//!         if self.count < 6 {
//!             Some(self.count)
//!         } else {
//!             None
//!         }
//!     }
//! }
//!
//! // І тепер ми можемо цим скористатися!
//!
//! let mut counter = Counter::new();
//!
//! assert_eq!(counter.next(), Some(1));
//! assert_eq!(counter.next(), Some(2));
//! assert_eq!(counter.next(), Some(3));
//! assert_eq!(counter.next(), Some(4));
//! assert_eq!(counter.next(), Some(5));
//! assert_eq!(counter.next(), None);
//! ```
//!
//! Виклик [`next`] таким чином стає повторюваним.Rust має конструкцію, яка може викликати [`next`] на вашому ітераторі, доки він не досягне `None`.Давайте перейдемо до цього далі.
//!
//! Також зауважте, що `Iterator` забезпечує реалізацію за замовчуванням таких методів, як `nth` та `fold`, які внутрішньо викликають `next`.
//! Однак також можна написати власну реалізацію методів, таких як `nth` та `fold`, якщо ітератор може обчислити їх ефективніше, не викликаючи `next`.
//!
//! # `for` петлі та `IntoIterator`
//!
//! Синтаксис циклу `for` Rust насправді є цукром для ітераторів.Ось базовий приклад `for`:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Буде надруковано цифри від одного до п`яти, кожен у своєму рядку.Але тут ви щось помітите: ми ніколи не викликали нічого на нашому vector для створення ітератора.Що дає?
//!
//! У стандартній бібліотеці є Portrait для перетворення чогось в ітератор: [`IntoIterator`].
//! Цей Portrait має один метод, [`into_iter`], який перетворює річ, що реалізує [`IntoIterator`], в ітератор.
//! Давайте ще раз подивимось на цей цикл `for` і в що перетворює його компілятор:
//!
//! [`into_iter`]: IntoIterator::into_iter
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Rust знецірює це у:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//! {
//!     let result = match IntoIterator::into_iter(values) {
//!         mut iter => loop {
//!             let next;
//!             match iter.next() {
//!                 Some(val) => next = val,
//!                 None => break,
//!             };
//!             let x = next;
//!             let () = { println!("{}", x); };
//!         },
//!     };
//!     result
//! }
//! ```
//!
//! Спочатку ми називаємо `into_iter()` значенням.Потім ми співпадаємо з ітератором, який повертається, знову і знову викликаючи [`next`], поки не побачимо `None`.
//! У цей момент ми вийшли з циклу `break` і закінчили ітерацію.
//!
//! Тут є ще один тонкий біт: стандартна бібліотека містить цікаву реалізацію [`IntoIterator`]:
//!
//! ```ignore (only-for-syntax-highlight)
//! impl<I: Iterator> IntoIterator for I
//! ```
//!
//! Іншими словами, всі [`Iterator`] реалізують [`IntoIterator`], просто повернувшись.Це означає дві речі:
//!
//! 1. Якщо ви пишете [`Iterator`], ви можете використовувати його з циклом `for`.
//! 2. Якщо ви створюєте колекцію, впровадження [`IntoIterator`] для неї дозволить використовувати вашу колекцію з циклом `for`.
//!
//! # Ітерація за посиланням
//!
//! Оскільки [`into_iter()`] приймає `self` за значенням, використання циклу `for` для ітерації над колекцією споживає цю колекцію.Часто вам може знадобитися переглядати колекцію, не споживаючи її.
//! Багато колекцій пропонують методи, що забезпечують ітератори над посиланнями, які зазвичай називають `iter()` та `iter_mut()` відповідно:
//!
//! ```
//! let mut values = vec![41];
//! for x in values.iter_mut() {
//!     *x += 1;
//! }
//! for x in values.iter() {
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1); // `values` все ще належить цій функції.
//! ```
//!
//! Якщо тип колекції `C` забезпечує `iter()`, він зазвичай також реалізує `IntoIterator` для `&C`, з реалізацією, яка просто викликає `iter()`.
//! Подібним чином колекція `C`, яка забезпечує `iter_mut()`, як правило, реалізує `IntoIterator` для `&mut C` шляхом делегування на `iter_mut()`.Це дає можливість зручної стенографії:
//!
//! ```
//! let mut values = vec![41];
//! for x in &mut values { // те саме, що `values.iter_mut()`
//!     *x += 1;
//! }
//! for x in &values { // те саме, що `values.iter()`
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1);
//! ```
//!
//! Хоча багато колекцій пропонують `iter()`, не всі пропонують `iter_mut()`.
//! Наприклад, мутація ключів [`HashSet<T>`] або [`HashMap<K, V>`] може перевести колекцію в невідповідний стан, якщо змінюються хеші ключів, тому ці колекції пропонують лише `iter()`.
//!
//! [`into_iter()`]: IntoIterator::into_iter
//! [`HashSet<T>`]: ../../std/collections/struct.HashSet.html
//! [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
//!
//! # Adapters
//!
//! Функції, які приймають [`Iterator`] і повертають інший [`Iterator`], часто називають "адаптерами ітераторів", оскільки вони є формою "адаптера"
//! pattern'.
//!
//! Поширені адаптери-ітератори включають [`map`], [`take`] та [`filter`].
//! Докладніше див. У їхній документації.
//!
//! Якщо адаптер ітератора panics, ітератор буде у невизначеному (але безпечному для пам'яті) стані.
//! Цей стан також не гарантовано залишатиметься незмінним у всіх версіях Rust, тому вам слід уникати покладатися на точні значення, повернуті ітератором, який викликав паніку.
//!
//! [`map`]: Iterator::map
//! [`take`]: Iterator::take
//! [`filter`]: Iterator::filter
//!
//! # Laziness
//!
//! Ітератори (а ітератор [adapters](#adapters))*ледачий*. Це означає, що просто створення ітератора не означає _do_. Насправді нічого не відбувається, поки ви не зателефонуєте [`next`].
//! Іноді це викликає плутанину при створенні ітератора виключно для його побічних ефектів.
//! Наприклад, метод [`map`] викликає закриття кожного елемента, який він переглядає:
//!
//! ```
//! # #![allow(unused_must_use)]
//! let v = vec![1, 2, 3, 4, 5];
//! v.iter().map(|x| println!("{}", x));
//! ```
//!
//! Це не буде друкувати жодних значень, оскільки ми лише створили ітератор, а не використовуємо його.Компілятор попередить нас про таку поведінку:
//!
//! ```text
//! warning: unused result that must be used: iterators are lazy and
//! do nothing unless consumed
//! ```
//!
//! Ідіоматичним способом написати [`map`] для його побічних ефектів є використання циклу `for` або виклик методу [`for_each`]:
//!
//! ```
//! let v = vec![1, 2, 3, 4, 5];
//!
//! v.iter().for_each(|x| println!("{}", x));
//! // or
//! for x in &v {
//!     println!("{}", x);
//! }
//! ```
//!
//! [`map`]: Iterator::map
//! [`for_each`]: Iterator::for_each
//!
//! Іншим поширеним способом оцінки ітератора є використання методу [`collect`] для створення нової колекції.
//!
//! [`collect`]: Iterator::collect
//!
//! # Infinity
//!
//! Ітератори не повинні бути обмеженими.Як приклад, відкритий діапазон-це нескінченний ітератор:
//!
//! ```
//! let numbers = 0..;
//! ```
//!
//! Зазвичай використовується перехідник ітератора [`take`] для перетворення нескінченного ітератора в кінцевий:
//!
//! ```
//! let numbers = 0..;
//! let five_numbers = numbers.take(5);
//!
//! for number in five_numbers {
//!     println!("{}", number);
//! }
//! ```
//!
//! Буде надруковано номери від `0` до `4`, кожен на своєму рядку.
//!
//! Майте на увазі, що методи на нескінченних ітераторах, навіть ті, для яких результат можна математично визначити за скінченний час, можуть не закінчитися.
//! Зокрема, такі методи, як [`min`], які в загальному випадку вимагають обходу кожного елемента в ітераторі, швидше за все, не повертаються успішно для будь-яких нескінченних ітераторів.
//!
//! ```no_run
//! let ones = std::iter::repeat(1);
//! let least = ones.min().unwrap(); // О ні!Нескінченна петля!
//! // `ones.min()` спричиняє нескінченний цикл, тому ми не дійдемо до цієї точки!
//! println!("The smallest number one is {}.", least);
//! ```
//!
//! [`take`]: Iterator::take
//! [`min`]: Iterator::min
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::Iterator;

#[unstable(
    feature = "step_trait",
    reason = "likely to be replaced by finer-grained traits",
    issue = "42168"
)]
pub use self::range::Step;

#[stable(feature = "iter_empty", since = "1.2.0")]
pub use self::sources::{empty, Empty};
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub use self::sources::{from_fn, FromFn};
#[stable(feature = "iter_once", since = "1.2.0")]
pub use self::sources::{once, Once};
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub use self::sources::{once_with, OnceWith};
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::sources::{repeat, Repeat};
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub use self::sources::{repeat_with, RepeatWith};
#[stable(feature = "iter_successors", since = "1.34.0")]
pub use self::sources::{successors, Successors};

#[stable(feature = "fused", since = "1.26.0")]
pub use self::traits::FusedIterator;
#[unstable(issue = "none", feature = "inplace_iteration")]
pub use self::traits::InPlaceIterable;
#[unstable(feature = "trusted_len", issue = "37572")]
pub use self::traits::TrustedLen;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::{
    DoubleEndedIterator, ExactSizeIterator, Extend, FromIterator, IntoIterator, Product, Sum,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::adapters::Cloned;
#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::adapters::Copied;
#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::adapters::Flatten;
#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::adapters::MapWhile;
#[unstable(feature = "inplace_iteration", issue = "none")]
pub use self::adapters::SourceIter;
#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::adapters::StepBy;
#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::adapters::TrustedRandomAccess;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::adapters::{
    Chain, Cycle, Enumerate, Filter, FilterMap, FlatMap, Fuse, Inspect, Map, Peekable, Rev, Scan,
    Skip, SkipWhile, Take, TakeWhile, Zip,
};
#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::adapters::{Intersperse, IntersperseWith};

pub(crate) use self::adapters::process_results;

mod adapters;
mod range;
mod sources;
mod traits;