use crate::convert::From;
use crate::fmt;
use crate::marker::{PhantomData, Unsize};
use crate::mem;
use crate::ops::{CoerceUnsized, DispatchFromDyn};

/// Обгортка навколо сирого ненульового `*mut T`, що вказує на те, що власник цієї обгортки є власником референта.
/// Корисно для побудови абстракцій, таких як `Box<T>`, `Vec<T>`, `String` та `HashMap<K, V>`.
///
/// На відміну від `*mut T`, `Unique<T>` поводиться "as if", це був екземпляр `T`.
/// Він реалізує `Send`/`Sync`, якщо `T` є `Send`/`Sync`.
/// Це також передбачає тип сильних псевдонімів, які може очікувати екземпляр `T`:
/// референт вказівника не повинен бути змінений без унікального шляху до його власного Unique.
///
/// Якщо ви не впевнені, чи правильно використовувати `Unique` для своїх цілей, подумайте про використання `NonNull`, що має слабшу семантику.
///
///
/// На відміну від `*mut T`, вказівник завжди повинен бути ненульовим, навіть якщо вказівник ніколи не розменовується.
/// Це зроблено для того, щоб перелічувачі могли використовувати це заборонене значення як дискримінант-`Option<Unique<T>>` має такий самий розмір, як `Unique<T>`.
/// Однак покажчик може все ще бовтатися, якщо він не розменований.
///
/// На відміну від `*mut T`, `Unique<T>` є коваріантною щодо `T`.
/// Це завжди має бути правильним для будь-якого типу, який відповідає псевдонімним вимогам Unique.
///
///
///
#[unstable(
    feature = "ptr_internals",
    issue = "none",
    reason = "use `NonNull` instead and consider `PhantomData<T>` \
              (if you also use `#[may_dangle]`), `Send`, and/or `Sync`"
)]
#[doc(hidden)]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
pub struct Unique<T: ?Sized> {
    pointer: *const T,
    // NOTE: цей маркер не має наслідків для дисперсії, але необхідний
    // щоб dropck зрозумів, що ми логічно володіємо `T`.
    //
    // Детальніше див .:
    // https://github.com/rust-lang/rfcs/blob/master/text/0769-sound-generic-drop.md#phantom-data
    _marker: PhantomData<T>,
}

/// `Unique` покажчики-`Send`, якщо `T`-`Send`, оскільки дані, на які вони посилаються, є недоступними.
/// Зверніть увагу, що цей інваріант згладжування не застосовується системою типів;абстракція, що використовує `Unique`, повинна це забезпечити.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Send + ?Sized> Send for Unique<T> {}

/// `Unique` покажчики-`Sync`, якщо `T`-`Sync`, оскільки дані, на які вони посилаються, є недоступними.
/// Зверніть увагу, що цей інваріант згладжування не застосовується системою типів;абстракція, що використовує `Unique`, повинна це забезпечити.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Sync + ?Sized> Sync for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: Sized> Unique<T> {
    /// Створює новий `Unique`, який звисає, але добре вирівняний.
    ///
    /// Це корисно для ініціалізації типів, які ліниво розподіляють, як це робить `Vec::new`.
    ///
    /// Зверніть увагу, що значення вказівника може потенційно представляти дійсний вказівник на `T`, що означає, що це не повинно використовуватися як значення сторожового "not yet initialized".
    /// Типи, які ліниво розподіляють, повинні відстежувати ініціалізацію якимось іншим способом.
    ///
    ///
    ///
    #[inline]
    pub const fn dangling() -> Self {
        // БЕЗПЕКА: mem::align_of() повертає дійсний ненульовий покажчик.
        // таким чином дотримуються умови виклику new_unchecked().
        unsafe { Unique::new_unchecked(mem::align_of::<T>() as *mut T) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Unique<T> {
    /// Створює новий `Unique`.
    ///
    /// # Safety
    ///
    /// `ptr` має бути ненульовим.
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // БЕЗПЕКА: абонент повинен гарантувати, що `ptr` не є нульовим.
        unsafe { Unique { pointer: ptr as _, _marker: PhantomData } }
    }

    /// Створює новий `Unique`, якщо `ptr` не є нульовим.
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // БЕЗПЕКА: Вказівник вже перевірено і не є нульовим.
            Some(unsafe { Unique { pointer: ptr as _, _marker: PhantomData } })
        } else {
            None
        }
    }

    /// Отримує базовий покажчик `*mut`.
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// Розмежування вмісту.
    ///
    /// Отриманий термін служби прив'язаний до себе, тому це поводиться "as if", це насправді екземпляр T, який отримує запозичення.
    /// Якщо потрібно довший термін служби (unbound), використовуйте `&*my_ptr.as_ptr()`.
    ///
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // БЕЗПЕКА: абонент повинен гарантувати, що `self` відповідає усім
        // вимоги до довідки.
        unsafe { &*self.as_ptr() }
    }

    /// Змінено розмежовує вміст.
    ///
    /// Отриманий термін служби прив'язаний до себе, тому це поводиться "as if", це насправді екземпляр T, який отримує запозичення.
    /// Якщо потрібно довший термін служби (unbound), використовуйте `&mut *my_ptr.as_ptr()`.
    ///
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // БЕЗПЕКА: абонент повинен гарантувати, що `self` відповідає усім
        // вимоги до змінних посилань.
        unsafe { &mut *self.as_ptr() }
    }

    /// Перетворює на вказівник іншого типу.
    #[inline]
    pub const fn cast<U>(self) -> Unique<U> {
        // БЕЗПЕКА: Unique::new_unchecked() створює нову унікальність та потреби
        // заданий покажчик не повинен бути нульовим.
        // Оскільки ми передаємо self як вказівник, він не може бути нульовим.
        unsafe { Unique::new_unchecked(self.as_ptr() as *mut U) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Clone for Unique<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Copy for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Debug for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Pointer for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<&mut T> for Unique<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // БЕЗПЕКА: змінне посилання не може бути нульовим
        unsafe { Unique { pointer: reference as *mut T, _marker: PhantomData } }
    }
}