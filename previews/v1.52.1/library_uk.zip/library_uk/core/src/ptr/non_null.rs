use crate::cmp::Ordering;
use crate::convert::From;
use crate::fmt;
use crate::hash;
use crate::marker::Unsize;
use crate::mem::{self, MaybeUninit};
use crate::ops::{CoerceUnsized, DispatchFromDyn};
use crate::ptr::Unique;
use crate::slice::{self, SliceIndex};

/// `*mut T` але ненульовий і коваріантний.
///
/// Це часто правильно використовувати при побудові структур даних із використанням необроблених покажчиків, але в кінцевому рахунку більш небезпечно використовувати через додаткові властивості.Якщо ви не впевнені, чи варто використовувати `NonNull<T>`, просто використовуйте `*mut T`!
///
/// На відміну від `*mut T`, покажчик завжди повинен бути ненульовим, навіть якщо вказівник ніколи не розмежовується.Це для того, щоб перелічувачі могли використовувати це заборонене значення як дискримінант-`Option<NonNull<T>>` має такий самий розмір, як `* mut T`.
/// Однак покажчик може все ще бовтатися, якщо він не розменований.
///
/// На відміну від `*mut T`, `NonNull<T>` було обрано коваріантним щодо `T`.Це дає можливість використовувати `NonNull<T>` під час побудови коваріантних типів, але створює ризик незрозумілості, якщо він використовується у типі, який насправді не повинен бути коваріантним.
/// (Для `*mut T` був зроблений протилежний вибір, хоча технічно незрозумілість могла бути викликана лише викликом небезпечних функцій.)
///
/// Коваріація є правильною для більшості безпечних абстракцій, таких як `Box`, `Rc`, `Arc`, `Vec` та `LinkedList`.Це так, оскільки вони надають загальнодоступний API, який відповідає звичайним загальним правилам, що змінюються XOR, Rust.
///
/// Якщо ваш тип не може бути безпечно коваріантним, ви повинні переконатися, що він містить якесь додаткове поле для забезпечення незмінності.Часто це поле має тип [`PhantomData`], такий як `PhantomData<Cell<T>>` або `PhantomData<&'a mut T>`.
///
/// Зверніть увагу, що `NonNull<T>` має екземпляр `From` для `&T`.Однак це не змінює той факт, що мутація через (вказівник, похідний від a) спільного посилання є невизначеною поведінкою, якщо мутація не відбувається всередині [`UnsafeCell<T>`].Те саме стосується створення змінного посилання із спільного посилання.
///
/// Якщо ви використовуєте цей екземпляр `From` без `UnsafeCell<T>`, ви несете відповідальність за те, щоб `as_mut` ніколи не викликався, а `as_ptr` ніколи не використовувався для мутації.
///
/// [`PhantomData`]: crate::marker::PhantomData
/// [`UnsafeCell<T>`]: crate::cell::UnsafeCell
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "nonnull", since = "1.25.0")]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
#[rustc_nonnull_optimization_guaranteed]
pub struct NonNull<T: ?Sized> {
    pointer: *const T,
}

/// `NonNull` покажчики не є `Send`, оскільки дані, на які вони посилаються, можуть бути псевдонімами.
// Примітка. Цей імпульс непотрібний, але повинен надавати кращі повідомлення про помилки.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Send for NonNull<T> {}

/// `NonNull` покажчики не є `Sync`, оскільки дані, на які вони посилаються, можуть бути псевдонімами.
// Примітка. Цей імпульс непотрібний, але повинен надавати кращі повідомлення про помилки.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Sync for NonNull<T> {}

impl<T: Sized> NonNull<T> {
    /// Створює новий `NonNull`, який звисає, але добре вирівняний.
    ///
    /// Це корисно для ініціалізації типів, які ліниво розподіляють, як це робить `Vec::new`.
    ///
    /// Зверніть увагу, що значення вказівника може потенційно представляти дійсний вказівник на `T`, що означає, що це не повинно використовуватися як значення сторожового "not yet initialized".
    /// Типи, які ліниво розподіляють, повинні відстежувати ініціалізацію якимось іншим способом.
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_dangling", since = "1.32.0")]
    #[inline]
    pub const fn dangling() -> Self {
        // БЕЗПЕКА: mem::align_of() повертає ненульовий розмір, який потім відливається
        // до * мута Т.
        // Таким чином, `ptr` не є нульовим, і умови для виклику new_unchecked() дотримуються.
        unsafe {
            let ptr = mem::align_of::<T>() as *mut T;
            NonNull::new_unchecked(ptr)
        }
    }

    /// Повертає спільні посилання на значення.На відміну від [`as_ref`], це не вимагає ініціалізації значення.
    ///
    /// Змінні аналоги див. У [`as_uninit_mut`].
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    ///
    /// # Safety
    ///
    /// Викликаючи цей метод, ви повинні переконатися, що все наступне відповідає дійсності:
    ///
    /// * Покажчик повинен бути правильно вирівняний.
    ///
    /// * Це має бути "dereferencable" у значенні, визначеному в [the module documentation].
    ///
    /// * Ви повинні застосувати правила псевдонімів Rust, оскільки повернутий час життя `'a` вибраний довільно і не обов'язково відображає фактичний час життя даних.
    ///
    ///   Зокрема, протягом усього цього життя пам`ять, на яку вказує вказівник, не повинна мутувати (крім усередині `UnsafeCell`).
    ///
    /// Це застосовується, навіть якщо результат цього методу не використовується!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref(&self) -> &MaybeUninit<T> {
        // БЕЗПЕКА: абонент повинен гарантувати, що `self` відповідає усім
        // вимоги до довідки.
        unsafe { &*self.cast().as_ptr() }
    }

    /// Повертає унікальні посилання на значення.На відміну від [`as_mut`], це не вимагає ініціалізації значення.
    ///
    /// Щодо спільного аналогу, див. [`as_uninit_ref`].
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    ///
    /// # Safety
    ///
    /// Викликаючи цей метод, ви повинні переконатися, що все наступне відповідає дійсності:
    ///
    /// * Покажчик повинен бути правильно вирівняний.
    ///
    /// * Це має бути "dereferencable" у значенні, визначеному в [the module documentation].
    ///
    /// * Ви повинні застосувати правила псевдонімів Rust, оскільки повернутий час життя `'a` вибраний довільно і не обов'язково відображає фактичний час життя даних.
    ///
    ///   Зокрема, протягом усього цього життя пам`ять, на яку вказує вказівник, не повинна отримувати доступ (читати чи писати) через будь-який інший вказівник.
    ///
    /// Це застосовується, навіть якщо результат цього методу не використовується!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_mut(&mut self) -> &mut MaybeUninit<T> {
        // БЕЗПЕКА: абонент повинен гарантувати, що `self` відповідає усім
        // вимоги до довідки.
        unsafe { &mut *self.cast().as_ptr() }
    }
}

impl<T: ?Sized> NonNull<T> {
    /// Створює новий `NonNull`.
    ///
    /// # Safety
    ///
    /// `ptr` має бути ненульовим.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_new_unchecked", since = "1.32.0")]
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // БЕЗПЕКА: абонент повинен гарантувати, що `ptr` не є нульовим.
        unsafe { NonNull { pointer: ptr as _ } }
    }

    /// Створює новий `NonNull`, якщо `ptr` не є нульовим.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // БЕЗПЕКА: Вказівник уже перевірено і не є нульовим
            Some(unsafe { Self::new_unchecked(ptr) })
        } else {
            None
        }
    }

    /// Виконує ту саму функціональність, що і [`std::ptr::from_raw_parts`], за винятком того, що повертається вказівник `NonNull`, на відміну від необробленого вказівника `*const`.
    ///
    ///
    /// Детальніше див. У документації [`std::ptr::from_raw_parts`].
    ///
    /// [`std::ptr::from_raw_parts`]: crate::ptr::from_raw_parts
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn from_raw_parts(
        data_address: NonNull<()>,
        metadata: <T as super::Pointee>::Metadata,
    ) -> NonNull<T> {
        // БЕЗПЕКА: Результат `ptr::from::raw_parts_mut` є ненульовим, оскільки `data_address` є.
        unsafe {
            NonNull::new_unchecked(super::from_raw_parts_mut(data_address.as_ptr(), metadata))
        }
    }

    /// Розкладіть (можливо, широкий) вказівник на адресу та компоненти метаданих.
    ///
    /// Пізніше вказівник можна відновити за допомогою [`NonNull::from_raw_parts`].
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (NonNull<()>, <T as super::Pointee>::Metadata) {
        (self.cast(), super::metadata(self.as_ptr()))
    }

    /// Отримує базовий покажчик `*mut`.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// Повертає спільне посилання на значення.Якщо значення може бути неініціалізоване, замість нього слід використовувати [`as_uninit_ref`].
    ///
    /// Змінні аналоги див. У [`as_mut`].
    ///
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    /// [`as_mut`]: NonNull::as_mut
    ///
    /// # Safety
    ///
    /// Викликаючи цей метод, ви повинні переконатися, що все наступне відповідає дійсності:
    ///
    /// * Покажчик повинен бути правильно вирівняний.
    ///
    /// * Це має бути "dereferencable" у значенні, визначеному в [the module documentation].
    ///
    /// * Покажчик повинен вказувати на ініціалізований екземпляр `T`.
    ///
    /// * Ви повинні застосувати правила псевдонімів Rust, оскільки повернутий час життя `'a` вибраний довільно і не обов'язково відображає фактичний час життя даних.
    ///
    ///   Зокрема, протягом усього цього життя пам`ять, на яку вказує вказівник, не повинна мутувати (крім усередині `UnsafeCell`).
    ///
    /// Це застосовується, навіть якщо результат цього методу не використовується!
    /// (Частина щодо ініціалізації ще не вирішена повністю, але поки вона не буде, єдиним безпечним підходом є забезпечення їх дійсної ініціалізації.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // БЕЗПЕКА: абонент повинен гарантувати, що `self` відповідає усім
        // вимоги до довідки.
        unsafe { &*self.as_ptr() }
    }

    /// Повертає унікальне посилання на значення.Якщо значення може бути неініціалізоване, замість нього слід використовувати [`as_uninit_mut`].
    ///
    /// Щодо спільного аналогу, див. [`as_ref`].
    ///
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    /// [`as_ref`]: NonNull::as_ref
    ///
    /// # Safety
    ///
    /// Викликаючи цей метод, ви повинні переконатися, що все наступне відповідає дійсності:
    ///
    /// * Покажчик повинен бути правильно вирівняний.
    ///
    /// * Це має бути "dereferencable" у значенні, визначеному в [the module documentation].
    ///
    /// * Покажчик повинен вказувати на ініціалізований екземпляр `T`.
    ///
    /// * Ви повинні застосувати правила псевдонімів Rust, оскільки повернутий час життя `'a` вибраний довільно і не обов'язково відображає фактичний час життя даних.
    ///
    ///   Зокрема, протягом усього цього життя пам`ять, на яку вказує вказівник, не повинна отримувати доступ (читати чи писати) через будь-який інший вказівник.
    ///
    /// Це застосовується, навіть якщо результат цього методу не використовується!
    /// (Частина щодо ініціалізації ще не вирішена повністю, але поки вона не буде, єдиним безпечним підходом є забезпечення їх дійсної ініціалізації.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // БЕЗПЕКА: абонент повинен гарантувати, що `self` відповідає усім
        // вимоги до змінних посилань.
        unsafe { &mut *self.as_ptr() }
    }

    /// Перетворює на вказівник іншого типу.
    #[stable(feature = "nonnull_cast", since = "1.27.0")]
    #[rustc_const_stable(feature = "const_nonnull_cast", since = "1.32.0")]
    #[inline]
    pub const fn cast<U>(self) -> NonNull<U> {
        // БЕЗПЕКА: `self`-це покажчик `NonNull`, який обов`язково не має нульового значення
        unsafe { NonNull::new_unchecked(self.as_ptr() as *mut U) }
    }
}

impl<T> NonNull<[T]> {
    /// Створює ненульовий необроблений фрагмент з тонкого вказівника та довжини.
    ///
    /// Аргументом `len` є кількість **елементів**, а не кількість байтів.
    ///
    /// Ця функція безпечна, але відмінювання посилання на значення, що повертається, небезпечне.
    /// Див. Документацію до [`slice::from_raw_parts`] щодо вимог безпеки зрізів.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(nonnull_slice_from_raw_parts)]
    ///
    /// use std::ptr::NonNull;
    ///
    /// // створити вказівник на зріз, починаючи з вказівника на перший елемент
    /// let mut x = [5, 6, 7];
    /// let nonnull_pointer = NonNull::new(x.as_mut_ptr()).unwrap();
    /// let slice = NonNull::slice_from_raw_parts(nonnull_pointer, 3);
    /// assert_eq!(unsafe { slice.as_ref()[2] }, 7);
    /// ```
    ///
    /// (Зверніть увагу, що цей приклад штучно демонструє використання цього методу, але `let slice= NonNull::from(&x[..]);` would be a better way to write code like this.)
    ///
    #[unstable(feature = "nonnull_slice_from_raw_parts", issue = "71941")]
    #[rustc_const_unstable(feature = "const_nonnull_slice_from_raw_parts", issue = "71941")]
    #[inline]
    pub const fn slice_from_raw_parts(data: NonNull<T>, len: usize) -> Self {
        // БЕЗПЕКА: `data`-це покажчик `NonNull`, який обов`язково не є нульовим
        unsafe { Self::new_unchecked(super::slice_from_raw_parts_mut(data.as_ptr(), len)) }
    }

    /// Повертає довжину ненульового необробленого фрагмента.
    ///
    /// Повернене значення-це кількість **елементів**, а не кількість байтів.
    ///
    /// Ця функція безпечна, навіть коли ненульовий необроблений зріз не може бути перенаправлений на зріз, оскільки вказівник не має дійсної адреси.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    #[inline]
    pub const fn len(self) -> usize {
        self.as_ptr().len()
    }

    /// Повертає ненульовий покажчик на буфер зрізу.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_non_null_ptr(), NonNull::new(1 as *mut i8).unwrap());
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_non_null_ptr(self) -> NonNull<T> {
        // БЕЗПЕКА: Ми знаємо, що `self` не є нульовим.
        unsafe { NonNull::new_unchecked(self.as_ptr().as_mut_ptr()) }
    }

    /// Повертає необроблений вказівник на буфер зрізу.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_mut_ptr(), 1 as *mut i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_mut_ptr(self) -> *mut T {
        self.as_non_null_ptr().as_ptr()
    }

    /// Повертає спільне посилання на фрагмент можливо неініціалізованих значень.На відміну від [`as_ref`], це не вимагає ініціалізації значення.
    ///
    /// Змінні аналоги див. У [`as_uninit_slice_mut`].
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_slice_mut`]: NonNull::as_uninit_slice_mut
    ///
    /// # Safety
    ///
    /// Викликаючи цей метод, ви повинні переконатися, що все наступне відповідає дійсності:
    ///
    /// * Вказівник повинен бути [valid] для читання багатобайт `ptr.len() * mem::size_of::<T>()`, і він повинен бути правильно вирівняний.Це зокрема означає:
    ///
    ///     * Весь діапазон пам'яті цього фрагмента повинен міститися в одному виділеному об'єкті!
    ///       Зрізи ніколи не можуть охоплювати кілька виділених об`єктів.
    ///
    ///     * Вказівник повинен бути вирівняний навіть для зрізів нульової довжини.
    ///     Однією з причин цього є те, що оптимізація макета перерахування може покладатися на вирівняні та не нульові посилання (включаючи зрізи будь-якої довжини), щоб відрізнити їх від інших даних.
    ///
    ///     Ви можете отримати покажчик, який можна використовувати як `data` для зрізів нульової довжини, використовуючи [`NonNull::dangling()`].
    ///
    /// * Загальний розмір зрізу `ptr.len() * mem::size_of::<T>()` не повинен перевищувати `isize::MAX`.
    ///   Див. Документацію з безпеки [`pointer::offset`].
    ///
    /// * Ви повинні застосувати правила псевдонімів Rust, оскільки повернутий час життя `'a` вибраний довільно і не обов'язково відображає фактичний час життя даних.
    ///   Зокрема, протягом усього цього життя пам`ять, на яку вказує вказівник, не повинна мутувати (крім усередині `UnsafeCell`).
    ///
    /// Це застосовується, навіть якщо результат цього методу не використовується!
    ///
    /// Див. Також [`slice::from_raw_parts`].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice(&self) -> &[MaybeUninit<T>] {
        // БЕЗПЕКА: абонент повинен виконувати контракт про безпеку для `as_uninit_slice`.
        unsafe { slice::from_raw_parts(self.cast().as_ptr(), self.len()) }
    }

    /// Повертає унікальне посилання на фрагмент можливо неініціалізованих значень.На відміну від [`as_mut`], це не вимагає ініціалізації значення.
    ///
    /// Щодо спільного аналогу, див. [`as_uninit_slice`].
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_slice`]: NonNull::as_uninit_slice
    ///
    /// # Safety
    ///
    /// Викликаючи цей метод, ви повинні переконатися, що все наступне відповідає дійсності:
    ///
    /// * Вказівник повинен бути [valid] для читання та запису для багатьох байтів `ptr.len() * mem::size_of::<T>()`, і він повинен бути правильно вирівняний.Це зокрема означає:
    ///
    ///     * Весь діапазон пам'яті цього фрагмента повинен міститися в одному виділеному об'єкті!
    ///       Зрізи ніколи не можуть охоплювати кілька виділених об`єктів.
    ///
    ///     * Вказівник повинен бути вирівняний навіть для зрізів нульової довжини.
    ///     Однією з причин цього є те, що оптимізація макета перерахування може покладатися на вирівняні та не нульові посилання (включаючи зрізи будь-якої довжини), щоб відрізнити їх від інших даних.
    ///
    ///     Ви можете отримати покажчик, який можна використовувати як `data` для зрізів нульової довжини, використовуючи [`NonNull::dangling()`].
    ///
    /// * Загальний розмір зрізу `ptr.len() * mem::size_of::<T>()` не повинен перевищувати `isize::MAX`.
    ///   Див. Документацію з безпеки [`pointer::offset`].
    ///
    /// * Ви повинні застосувати правила псевдонімів Rust, оскільки повернутий час життя `'a` вибраний довільно і не обов'язково відображає фактичний час життя даних.
    ///   Зокрема, протягом усього цього життя пам`ять, на яку вказує вказівник, не повинна отримувати доступ (читати чи писати) через будь-який інший вказівник.
    ///
    /// Це застосовується, навіть якщо результат цього методу не використовується!
    ///
    /// Див. Також [`slice::from_raw_parts_mut`].
    ///
    /// [valid]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(allocator_api, ptr_as_uninit)]
    ///
    /// use std::alloc::{Allocator, Layout, Global};
    /// use std::mem::MaybeUninit;
    /// use std::ptr::NonNull;
    ///
    /// let memory: NonNull<[u8]> = Global.allocate(Layout::new::<[u8; 32]>())?;
    /// // Це безпечно, оскільки `memory` діє для читання та запису для багатьох байтів `memory.len()`.
    /// // Зверніть увагу, що виклик `memory.as_mut()` тут заборонений, оскільки вміст може бути неініціалізований.
    /// # #[allow(unused_variables)]
    /// let slice: &mut [MaybeUninit<u8>] = unsafe { memory.as_uninit_slice_mut() };
    /// # Ok::<_, std::alloc::AllocError>(())
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice_mut(&self) -> &mut [MaybeUninit<T>] {
        // БЕЗПЕКА: абонент повинен виконувати контракт про безпеку для `as_uninit_slice_mut`.
        unsafe { slice::from_raw_parts_mut(self.cast().as_ptr(), self.len()) }
    }

    /// Повертає необроблений вказівник на елемент або підрізок без перевірки меж.
    ///
    /// Виклик цього методу з індексом, що виходить за межі, або коли `self` неможливо розблокувати, є *[невизначена поведінка]*, навіть якщо отриманий вказівник не використовується.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let x = &mut [1, 2, 4];
    /// let x = NonNull::slice_from_raw_parts(NonNull::new(x.as_mut_ptr()).unwrap(), x.len());
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked_mut(1).as_ptr(), x.as_non_null_ptr().as_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(self, index: I) -> NonNull<I::Output>
    where
        I: SliceIndex<[T]>,
    {
        // БЕЗПЕКА: абонент гарантує, що `self` не піддається переспрямуванню та `index` знаходиться в межах.
        // Як наслідок, результуючий покажчик не може мати значення NULL.
        unsafe { NonNull::new_unchecked(self.as_ptr().get_unchecked_mut(index)) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Clone for NonNull<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Copy for NonNull<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Debug for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Pointer for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Eq for NonNull<T> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialEq for NonNull<T> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        self.as_ptr() == other.as_ptr()
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Ord for NonNull<T> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        self.as_ptr().cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialOrd for NonNull<T> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.as_ptr().partial_cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> hash::Hash for NonNull<T> {
    #[inline]
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.as_ptr().hash(state)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<Unique<T>> for NonNull<T> {
    #[inline]
    fn from(unique: Unique<T>) -> Self {
        // БЕЗПЕКА: Унікальний покажчик не може бути нульовим, тому умови для
        // new_unchecked() шануються.
        unsafe { NonNull::new_unchecked(unique.as_ptr()) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&mut T> for NonNull<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // БЕЗПЕКА: змінне посилання не може бути нульовим.
        unsafe { NonNull { pointer: reference as *mut T } }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&T> for NonNull<T> {
    #[inline]
    fn from(reference: &T) -> Self {
        // БЕЗПЕКА: посилання не може бути нульовим, тому умови для
        // new_unchecked() шануються.
        unsafe { NonNull { pointer: reference as *const T } }
    }
}