#![unstable(feature = "ptr_metadata", issue = "81513")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

/// Забезпечує тип метаданих покажчика будь-якого типу, що вказує.
///
/// # Метадані вказівника
///
/// Типи необроблених покажчиків та посилальні типи в Rust можна розглядати як складені з двох частин:
/// покажчик даних, що містить адресу пам'яті значення та деякі метадані.
///
/// Для типів із статичним розміром (які реалізують `Sized` traits), а також для типів `extern`, вказівники називаються «тонкими»: метадані мають нульовий розмір, а їх тип-`()`.
///
///
/// Вказівники на [dynamically-sized types][dst] називають "широкими" або "жирними", вони мають ненульові метадані:
///
/// * Для структур, останнє поле яких-літній час, метадані-це метадані останнього поля
/// * Для типу `str` метаданими є довжина в байтах як `usize`
/// * Для типів зрізів, таких як `[T]`, метаданими є довжина в елементах як `usize`
/// * Для об'єктів Portrait, таких як `dyn SomeTrait`, метаданими є [`DynMetadata<Self>`][DynMetadata] (наприклад, `DynMetadata<dyn SomeTrait>`)
///
/// У future мова Rust може отримати нові типи типів, які мають різні метадані вказівника.
///
/// [dst]: https://doc.rust-lang.org/nomicon/exotic-sizes.html#dynamically-sized-types-dsts
///
/// # `Pointee` Portrait
///
/// Суть цього Portrait-це пов`язаний із ним тип `Metadata`, який є `()` або `usize` або `DynMetadata<_>`, як описано вище.
/// Він автоматично реалізується для кожного типу.
/// Можна припустити, що це реалізується в загальному контексті, навіть без відповідного обмеження.
///
/// # Usage
///
/// Сировинні вказівники можна розкласти на адресу даних та компоненти метаданих за допомогою методу [`to_raw_parts`].
///
/// Крім того, лише метадані можна витягти за допомогою функції [`metadata`].
/// Посилання може бути передане на [`metadata`] і неявно примусово.
///
/// Покажчик (possibly-wide) можна скласти разом із його адреси та метаданих за допомогою [`from_raw_parts`] або [`from_raw_parts_mut`].
///
/// [`to_raw_parts`]: *const::to_raw_parts
///
///
///
///
///
///
///
///
///
#[lang = "pointee_trait"]
pub trait Pointee {
    /// Тип метаданих у покажчиках та посилання на `Self`.
    #[lang = "metadata_type"]
    // NOTE: Зберігайте Portrait bounds у `static_assert_expected_bounds_for_metadata`
    //
    // в `library/core/src/ptr/metadata.rs` синхронно з тими, що тут:
    type Metadata: Copy + Send + Sync + Ord + Hash + Unpin;
}

/// Вказівники на типи, що реалізують цей псевдонім Portrait, є «тонкими».
///
/// Сюди входять статично-розмірні типи та типи `extern`.
///
/// # Example
///
/// ```rust
/// #![feature(ptr_metadata)]
///
/// fn this_never_panics<T: std::ptr::Thin>() {
///     assert_eq!(std::mem::size_of::<&T>(), std::mem::size_of::<usize>())
/// }
/// ```
#[unstable(feature = "ptr_metadata", issue = "81513")]
// NOTE: не стабілізуйте це, поки псевдоніми Portrait не стануть стабільними в мові?
pub trait Thin = Pointee<Metadata = ()>;

/// Витягніть компонент метаданих покажчика.
///
/// Значення типу `*mut T`, `&T` або `&mut T` можуть передаватися безпосередньо цій функції, оскільки вони неявно примушують до `* const T`.
///
///
/// # Example
///
/// ```
/// #![feature(ptr_metadata)]
///
/// assert_eq!(std::ptr::metadata("foo"), 3_usize);
/// ```
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn metadata<T: ?Sized>(ptr: *const T) -> <T as Pointee>::Metadata {
    // БЕЗПЕКА: Доступ до значення з об'єднання `PtrRepr` є безпечним, оскільки * const T
    // та PtrComponents<T>мають однакові макети пам`яті.
    // Цю гарантію може дати лише std.
    unsafe { PtrRepr { const_ptr: ptr }.components.metadata }
}

/// Формує необроблений вказівник (possibly-wide) з адреси даних та метаданих.
///
/// Ця функція є безпечною, але повернутий покажчик не обов'язково безпечний для розмену.
/// Щодо фрагментів, див. Документацію [`slice::from_raw_parts`] щодо вимог безпеки.
/// Для об'єктів Portrait метадані повинні надходити від вказівника до того самого основного стираного типу.
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts<T: ?Sized>(
    data_address: *const (),
    metadata: <T as Pointee>::Metadata,
) -> *const T {
    // БЕЗПЕКА: Доступ до значення з об'єднання `PtrRepr` є безпечним, оскільки * const T
    // та PtrComponents<T>мають однакові макети пам`яті.
    // Цю гарантію може дати лише std.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.const_ptr }
}

/// Виконує ту саму функціональність, що і [`from_raw_parts`], за винятком того, що повертається необроблений вказівник `*mut`, на відміну від необробленого вказівника `* const`.
///
///
/// Детальніше див. У документації [`from_raw_parts`].
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts_mut<T: ?Sized>(
    data_address: *mut (),
    metadata: <T as Pointee>::Metadata,
) -> *mut T {
    // БЕЗПЕКА: Доступ до значення з об'єднання `PtrRepr` є безпечним, оскільки * const T
    // та PtrComponents<T>мають однакові макети пам`яті.
    // Цю гарантію може дати лише std.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.mut_ptr }
}

#[repr(C)]
pub(crate) union PtrRepr<T: ?Sized> {
    pub(crate) const_ptr: *const T,
    pub(crate) mut_ptr: *mut T,
    pub(crate) components: PtrComponents<T>,
}

#[repr(C)]
pub(crate) struct PtrComponents<T: ?Sized> {
    pub(crate) data_address: *const (),
    pub(crate) metadata: <T as Pointee>::Metadata,
}

// Необхідний імпульс вручну, щоб уникнути прив`язки до `T: Copy`.
impl<T: ?Sized> Copy for PtrComponents<T> {}

// Необхідний імпульс вручну, щоб уникнути прив'язки `T: Clone`.
impl<T: ?Sized> Clone for PtrComponents<T> {
    fn clone(&self) -> Self {
        *self
    }
}

/// Метадані для типу об`єкта `Dyn = dyn SomeTrait` Portrait.
///
/// Це вказівник на vtable (віртуальна таблиця викликів), яка представляє всю необхідну інформацію для маніпулювання конкретним типом, що зберігається всередині об'єкта Portrait.
/// Vtable, зокрема, він містить:
///
/// * розмір типу
/// * вирівнювання типу
/// * вказівник на імпульс `drop_in_place` типу (може бути забороною для простих-старих даних)
/// * вказівники на всі методи реалізації типу Portrait
///
/// Зауважте, що перші три є особливими, оскільки вони необхідні для розподілу, скидання та вивільнення будь-якого об`єкта Portrait.
///
/// Цю структуру можна назвати параметром типу, який не є об`єктом `dyn` Portrait (наприклад, `DynMetadata<u64>`), але не отримати значущого значення цієї структури.
///
///
///
///
#[lang = "dyn_metadata"]
pub struct DynMetadata<Dyn: ?Sized> {
    vtable_ptr: &'static VTable,
    phantom: crate::marker::PhantomData<Dyn>,
}

/// Загальний префікс усіх vtables.За ним слідують покажчики функцій для методів Portrait.
///
/// Приватна деталь реалізації `DynMetadata::size_of` тощо.
#[repr(C)]
struct VTable {
    drop_in_place: fn(*mut ()),
    size_of: usize,
    align_of: usize,
}

impl<Dyn: ?Sized> DynMetadata<Dyn> {
    /// Повертає розмір типу, пов'язаного з цією vtable.
    #[inline]
    pub fn size_of(self) -> usize {
        self.vtable_ptr.size_of
    }

    /// Повертає вирівнювання типу, пов'язаного з цією vtable.
    #[inline]
    pub fn align_of(self) -> usize {
        self.vtable_ptr.align_of
    }

    /// Повертає розмір та вирівнювання разом як `Layout`
    #[inline]
    pub fn layout(self) -> crate::alloc::Layout {
        // БЕЗПЕКА: компілятор видав цю таблицю для конкретного типу Rust, який
        // відомо, що він має дійсний макет.Те саме обґрунтування, що і в `Layout::for_value`.
        unsafe { crate::alloc::Layout::from_size_align_unchecked(self.size_of(), self.align_of()) }
    }
}

unsafe impl<Dyn: ?Sized> Send for DynMetadata<Dyn> {}
unsafe impl<Dyn: ?Sized> Sync for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> fmt::Debug for DynMetadata<Dyn> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("DynMetadata").field(&(self.vtable_ptr as *const VTable)).finish()
    }
}

// Імпульси вручну, необхідні, щоб уникнути меж `Dyn: $Trait`.

impl<Dyn: ?Sized> Unpin for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Copy for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Clone for DynMetadata<Dyn> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

impl<Dyn: ?Sized> Eq for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> PartialEq for DynMetadata<Dyn> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        crate::ptr::eq::<VTable>(self.vtable_ptr, other.vtable_ptr)
    }
}

impl<Dyn: ?Sized> Ord for DynMetadata<Dyn> {
    #[inline]
    fn cmp(&self, other: &Self) -> crate::cmp::Ordering {
        (self.vtable_ptr as *const VTable).cmp(&(other.vtable_ptr as *const VTable))
    }
}

impl<Dyn: ?Sized> PartialOrd for DynMetadata<Dyn> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<crate::cmp::Ordering> {
        Some(self.cmp(other))
    }
}

impl<Dyn: ?Sized> Hash for DynMetadata<Dyn> {
    #[inline]
    fn hash<H: Hasher>(&self, hasher: &mut H) {
        crate::ptr::hash::<VTable, _>(self.vtable_ptr, hasher)
    }
}