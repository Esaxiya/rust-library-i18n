//! Основні функції роботи з пам'яттю.
//!
//! Цей модуль містить функції для запиту розміру та вирівнювання типів, ініціалізації та обробки пам'яті.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::clone;
use crate::cmp;
use crate::fmt;
use crate::hash;
use crate::intrinsics;
use crate::marker::{Copy, DiscriminantKind, Sized};
use crate::ptr;

mod manually_drop;
#[stable(feature = "manually_drop", since = "1.20.0")]
pub use manually_drop::ManuallyDrop;

mod maybe_uninit;
#[stable(feature = "maybe_uninit", since = "1.36.0")]
pub use maybe_uninit::MaybeUninit;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::transmute;

/// Бере право власності та "forgets" про значення **без запуску його деструктора**.
///
/// Будь-які ресурси, якими керує значення, такі як пам`ять купи або дескриптор файлу, назавжди залишатимуться у недосяжному стані.Однак це не гарантує, що вказівники на цю пам'ять залишатимуться дійсними.
///
/// * Якщо ви хочете витік пам'яті, див. [`Box::leak`].
/// * Якщо ви хочете отримати необроблений вказівник на пам'ять, див. [`Box::into_raw`].
/// * Якщо ви хочете правильно розпорядитися значенням, запустивши його деструктор, див. [`mem::drop`].
///
/// # Safety
///
/// `forget` не позначено як `unsafe`, оскільки гарантії безпеки Rust не містять гарантії того, що деструктори завжди працюватимуть.
/// Наприклад, програма може створити еталонний цикл за допомогою [`Rc`][rc] або викликати [`process::exit`][exit] для виходу без запуску деструкторів.
/// Таким чином, випуск `mem::forget` із безпечного коду принципово не змінює гарантій безпеки Rust.
///
/// Тим не менш, витік ресурсів, таких як пам`ять або об`єкти I/O, зазвичай небажаний.
/// Потреба виникає у деяких спеціалізованих випадках використання FFI або небезпечного коду, але навіть тоді [`ManuallyDrop`] зазвичай є кращим.
///
/// Оскільки забуття значення дозволено, будь-який код `unsafe`, який ви пишете, повинен передбачати цю можливість.Ви не можете повернути значення і очікувати, що абонент обов'язково запустить деструктор значення.
///
/// [rc]: ../../std/rc/struct.Rc.html
/// [exit]: ../../std/process/fn.exit.html
///
/// # Examples
///
/// Канонічне безпечне використання `mem::forget` полягає в тому, щоб обійти деструктор значення, реалізований `Drop` Portrait.Наприклад, це призведе до витоку `File`, тобто
/// повернути простір, зайнятий змінною, але ніколи не закривати базовий системний ресурс:
///
/// ```no_run
/// use std::mem;
/// use std::fs::File;
///
/// let file = File::open("foo.txt").unwrap();
/// mem::forget(file);
/// ```
///
/// Це корисно, коли право власності на базовий ресурс раніше передавалось коду поза Rust, наприклад, передаючи дескриптор необробленого файлу до коду C.
///
/// # Взаємозв'язок з `ManuallyDrop`
///
/// Хоча `mem::forget` можна також використовувати для передачі права власності на *пам'ять*, це робить схильним до помилок.
/// [`ManuallyDrop`] слід використовувати замість цього.Розглянемо, наприклад, цей код:
///
/// ```
/// use std::mem;
///
/// let mut v = vec![65, 122];
/// // Створіть `String`, використовуючи вміст `v`
/// let s = unsafe { String::from_raw_parts(v.as_mut_ptr(), v.len(), v.capacity()) };
/// // витік `v`, оскільки його пам'ять тепер управляється `s`
/// mem::forget(v);  // ПОМИЛКА, v недійсний і не повинен передаватися функції
/// assert_eq!(s, "Az");
/// // `s` неявно скидається, а пам`ять звільняється.
/// ```
///
/// У наведеному вище прикладі є дві проблеми:
///
/// * Якби між конструкцією `String` і викликом `mem::forget()` було додано більше коду, panic всередині нього призвів би до подвійного звільнення, оскільки однакова пам'ять обробляється як `v`, так і `s`.
/// * Після виклику `v.as_mut_ptr()` і передачі права власності на дані `s` значення `v` недійсне.
/// Навіть коли значення просто переміщується до `mem::forget` (який не перевірятиме його), деякі типи мають жорсткі вимоги до своїх значень, що робить їх недійсними, коли вони бовтаються або більше не належать.
/// Будь-яке використання недійсних значень, включаючи передачу їх або повернення з функцій, є невизначеною поведінкою та може порушити припущення, зроблені компілятором.
///
/// Перехід на `ManuallyDrop` дозволяє уникнути обох проблем:
///
/// ```
/// use std::mem::ManuallyDrop;
///
/// let v = vec![65, 122];
/// // Перш ніж розбирати `v` на його необроблені частини, переконайтеся, що він не потрапляє!
/////
/// let mut v = ManuallyDrop::new(v);
/// // Тепер розберіть `v`.Ці операції не можуть panic, тому не може бути витоку.
/// let (ptr, len, cap) = (v.as_mut_ptr(), v.len(), v.capacity());
/// // Нарешті, побудуйте `String`.
/// let s = unsafe { String::from_raw_parts(ptr, len, cap) };
/// assert_eq!(s, "Az");
/// // `s` неявно скидається, а пам`ять звільняється.
/// ```
///
/// `ManuallyDrop` надійно запобігає подвійному вільному, оскільки ми вимикаємо деструктор `v`, перш ніж робити щось інше.
/// `mem::forget()` не дозволяє цього, оскільки він споживає свій аргумент, змушуючи нас викликати його лише після вилучення з `v` всього, що нам потрібно.
/// Навіть якби panic був введений між побудовою `ManuallyDrop` і побудовою рядка (що не може відбутися в коді, як показано), це призведе до витоку, а не подвійного звільнення.
/// Іншими словами, `ManuallyDrop` помиляється на стороні витоку, замість того, щоб помилитися на стороні (подвійного) скидання.
///
/// Крім того, `ManuallyDrop` заважає нам мати "touch" `v` після передачі права власності на `s`-остаточний крок взаємодії з `v` для його утилізації без запуску деструктора повністю уникається.
///
///
/// [`Box`]: ../../std/boxed/struct.Box.html
/// [`Box::leak`]: ../../std/boxed/struct.Box.html#method.leak
/// [`Box::into_raw`]: ../../std/boxed/struct.Box.html#method.into_raw
/// [`mem::drop`]: drop
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[rustc_const_stable(feature = "const_forget", since = "1.46.0")]
#[stable(feature = "rust1", since = "1.0.0")]
pub const fn forget<T>(t: T) {
    let _ = ManuallyDrop::new(t);
}

/// Як і [`forget`], але також приймає величини величини.
///
/// Ця функція-це просто прокладка, призначена для видалення, коли функція `unsized_locals` стабілізується.
///
#[inline]
#[unstable(feature = "forget_unsized", issue = "none")]
pub fn forget_unsized<T: ?Sized>(t: T) {
    intrinsics::forget(t)
}

/// Повертає розмір типу в байтах.
///
/// Більш конкретно, це зміщення в байтах між послідовними елементами масиву з таким типом елемента, включаючи відступ вирівнювання.
///
/// Таким чином, для будь-якого типу `T` та довжини `n` `[T; n]` має розмір `n * size_of::<T>()`.
///
/// Взагалі, розмір типу не є стабільним для компіляцій, але конкретні типи, такі як примітиви, є.
///
/// У наступній таблиці наведено розмір для примітивів.
///
/// Тип |розмір: :<Type>()
/// ---- | ---------------
/// () |0 bool |1 u8 |1 u16 |2 u32 |4 u64 |8 u128 |16 i8 |1 i16 |2 i32 |4 i64 |8 i128 |16 f32 |4 f64 |8 символів |4
///
/// Крім того, `usize` і `isize` мають однакові розміри.
///
/// Типи `*const T`, `&T`, `Box<T>`, `Option<&T>` та `Option<Box<T>>` мають однакові розміри.
/// Якщо розмір `T` розмірний, усі ці типи мають той самий розмір, що і `usize`.
///
/// Змінюваність покажчика не змінює його розмір.Таким чином, `&T` та `&mut T` мають однакові розміри.
/// Так само для `*const T` та `* mut T`.
///
/// # Розмір елементів `#[repr(C)]`
///
/// Представлення `C` для елементів має визначений макет.
/// При такому розміщенні розмір елементів також стабільний, якщо всі поля мають стабільний розмір.
///
/// ## Розмір конструкцій
///
/// Для `structs` розмір визначається за наступним алгоритмом.
///
/// Для кожного поля в структурі, упорядкованої за порядком декларації:
///
/// 1. Додайте розмір поля.
/// 2. Округліть поточний розмір до найближчого кратного до наступного поля [alignment].
///
/// Нарешті, округніть розмір структури до найближчого кратного її [alignment].
/// Вирівнювання структури, як правило, є найбільшим вирівнюванням усіх її полів;це можна змінити за допомогою `repr(align(N))`.
///
/// На відміну від `C`, структури нульового розміру не округлюються до одного байта.
///
/// ## Розмір переліків
///
/// Перелічення, які не містять інших даних, крім дискримінанта, мають такий самий розмір, як переліки C на платформі, для якої вони скомпільовані.
///
/// ## Розмір профспілок
///
/// Розмір об`єднання-це розмір його найбільшого поля.
///
/// На відміну від `C`, об'єднання нульового розміру не округлюються до одного байта.
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// // Деякі примітиви
/// assert_eq!(4, mem::size_of::<i32>());
/// assert_eq!(8, mem::size_of::<f64>());
/// assert_eq!(0, mem::size_of::<()>());
///
/// // Деякі масиви
/// assert_eq!(8, mem::size_of::<[i32; 2]>());
/// assert_eq!(12, mem::size_of::<[i32; 3]>());
/// assert_eq!(0, mem::size_of::<[i32; 0]>());
///
///
/// // Рівність розміру вказівника
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<*const i32>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Box<i32>>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Option<&i32>>());
/// assert_eq!(mem::size_of::<Box<i32>>(), mem::size_of::<Option<Box<i32>>>());
/// ```
///
/// Використання `#[repr(C)]`.
///
/// ```
/// use std::mem;
///
/// #[repr(C)]
/// struct FieldStruct {
///     first: u8,
///     second: u16,
///     third: u8
/// }
///
/// // Розмір першого поля дорівнює 1, тому додайте 1 до розміру.Розмір-1.
/// // Вирівнювання другого поля дорівнює 2, тому додайте 1 до розміру для заповнення.Розмір 2.
/// // Розмір другого поля дорівнює 2, тому додайте до розміру 2.Розмір 4.
/// // Вирівнювання третього поля дорівнює 1, тому додайте 0 до розміру для заповнення.Розмір 4.
/// // Розмір третього поля дорівнює 1, тому додайте 1 до розміру.Розмір 5.
/// // Нарешті, вирівнювання структури дорівнює 2 (оскільки найбільше вирівнювання серед її полів-2), тому додайте 1 до розміру для заповнення.
/// // Розмір 6.
/// assert_eq!(6, mem::size_of::<FieldStruct>());
///
/// #[repr(C)]
/// struct TupleStruct(u8, u16, u8);
///
/// // Корпусні структури дотримуються тих самих правил.
/// assert_eq!(6, mem::size_of::<TupleStruct>());
///
/// // Зверніть увагу, що переупорядкування полів може зменшити розмір.
/// // Ми можемо видалити обидва байти доповнення, поставивши `third` перед `second`.
/// #[repr(C)]
/// struct FieldStructOptimized {
///     first: u8,
///     third: u8,
///     second: u16
/// }
///
/// assert_eq!(4, mem::size_of::<FieldStructOptimized>());
///
/// // Розмір об`єднання-це розмір найбільшого поля.
/// #[repr(C)]
/// union ExampleUnion {
///     smaller: u8,
///     larger: u16
/// }
///
/// assert_eq!(2, mem::size_of::<ExampleUnion>());
/// ```
///
/// [alignment]: align_of
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_size_of", since = "1.32.0")]
pub const fn size_of<T>() -> usize {
    intrinsics::size_of::<T>()
}

/// Повертає розмір вказаного значення в байтах.
///
/// Зазвичай це те саме, що і `size_of::<T>()`.
/// Однак, коли `T`*не має* статистично відомого розміру, наприклад, зріз [`[T]`][slice] або [trait object], тоді `size_of_val` може бути використаний для отримання динамічно відомого розміру.
///
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, mem::size_of_val(y));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
pub const fn size_of_val<T: ?Sized>(val: &T) -> usize {
    // БЕЗПЕКА: `val`-це посилання, тому це дійсний необроблений вказівник
    unsafe { intrinsics::size_of_val(val) }
}

/// Повертає розмір вказаного значення в байтах.
///
/// Зазвичай це те саме, що і `size_of::<T>()`.Однак, коли `T`*не має* статистично відомого розміру, наприклад, зріз [`[T]`][slice] або [trait object], тоді `size_of_val_raw` може бути використаний для отримання динамічно відомого розміру.
///
/// # Safety
///
/// Цю функцію безпечно викликати, лише якщо виконуються такі умови:
///
/// - Якщо `T` є `Sized`, цю функцію завжди безпечно викликати.
/// - Якщо величина хвоста `T`:
///     - [slice], тоді довжина зрізу хвоста повинна бути ініціалізованим цілим числом, а розмір *цілого значення*(динамічна довжина хвоста + статичний розмір префікса) повинен відповідати `isize`.
///     - [trait object], тоді vtable частина покажчика повинна вказувати на дійсну vtable, отриману примусом без розміру, а розмір *всього значення*(динамічна довжина хвоста + статичний розмір префікса) повинен відповідати `isize`.
///
///     - (unstable) [extern type], тоді цю функцію завжди безпечно викликати, але panic може повернути неправильне значення, оскільки макет зовнішнього типу невідомий.
///     Це така сама поведінка, як [`size_of_val`] при посиланні на тип із зовнішнім хвостом.
///     - в іншому випадку консервативно не дозволяється викликати цю функцію.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, unsafe { mem::size_of_val_raw(y) });
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_size_of_val_raw", issue = "46571")]
pub const unsafe fn size_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // БЕЗПЕКА: абонент повинен надати дійсний вихідний вказівник
    unsafe { intrinsics::size_of_val(val) }
}

/// Повертає мінімальне вирівнювання типу, необхідне для [ABI].
///
/// Кожне посилання на значення типу `T` повинно бути кратним цьому числу.
///
/// Це вирівнювання, яке використовується для полів struct.Він може бути меншим за бажане вирівнювання.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of::<i32>());
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of` instead", since = "1.2.0")]
pub fn min_align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// Повертає мінімальне вирівнювання, необхідне для [ABI], типу значення, на яке вказує `val`.
///
/// Кожне посилання на значення типу `T` повинно бути кратним цьому числу.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of_val` instead", since = "1.2.0")]
pub fn min_align_of_val<T: ?Sized>(val: &T) -> usize {
    // БЕЗПЕКА: val-це посилання, тому це дійсний необроблений вказівник
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Повертає мінімальне вирівнювання типу, необхідне для [ABI].
///
/// Кожне посилання на значення типу `T` повинно бути кратним цьому числу.
///
/// Це вирівнювання, яке використовується для полів struct.Він може бути меншим за бажане вирівнювання.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of::<i32>());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_align_of", since = "1.32.0")]
pub const fn align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// Повертає мінімальне вирівнювання, необхідне для [ABI], типу значення, на яке вказує `val`.
///
/// Кожне посилання на значення типу `T` повинно бути кратним цьому числу.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
#[allow(deprecated)]
pub const fn align_of_val<T: ?Sized>(val: &T) -> usize {
    // БЕЗПЕКА: val-це посилання, тому це дійсний необроблений вказівник
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Повертає мінімальне вирівнювання, необхідне для [ABI], типу значення, на яке вказує `val`.
///
/// Кожне посилання на значення типу `T` повинно бути кратним цьому числу.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Safety
///
/// Цю функцію безпечно викликати, лише якщо виконуються такі умови:
///
/// - Якщо `T` є `Sized`, цю функцію завжди безпечно викликати.
/// - Якщо величина хвоста `T`:
///     - [slice], тоді довжина зрізу хвоста повинна бути ініціалізованим цілим числом, а розмір *цілого значення*(динамічна довжина хвоста + статичний розмір префікса) повинен відповідати `isize`.
///     - [trait object], тоді vtable частина покажчика повинна вказувати на дійсну vtable, отриману примусом без розміру, а розмір *всього значення*(динамічна довжина хвоста + статичний розмір префікса) повинен відповідати `isize`.
///
///     - (unstable) [extern type], тоді цю функцію завжди безпечно викликати, але panic може повернути неправильне значення, оскільки макет зовнішнього типу невідомий.
///     Це така сама поведінка, як [`align_of_val`] при посиланні на тип із зовнішнім хвостом.
///     - в іншому випадку консервативно не дозволяється викликати цю функцію.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, unsafe { mem::align_of_val_raw(&5i32) });
/// ```
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_align_of_val_raw", issue = "46571")]
pub const unsafe fn align_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // БЕЗПЕКА: абонент повинен надати дійсний вихідний вказівник
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Повертає `true`, якщо зниження значень типу `T` має значення.
///
/// Це суто підказка щодо оптимізації, і вона може бути реалізована консервативно:
/// він може повернути `true` для типів, які насправді не потрібно скидати.
/// Таким чином, завжди повернення `true` було б допустимою реалізацією цієї функції.Однак якщо ця функція насправді повертає `false`, то ви можете бути впевнені, що відмова від `T` не має побічних ефектів.
///
/// Низькорівневі реалізації таких речей, як колекції, яким потрібно вручну скинути свої дані, повинні використовувати цю функцію, щоб уникнути зайвої спроби скинути весь їх вміст, коли вони будуть знищені.
///
/// Це може не мати різниці у збірках випусків (де цикл, що не має побічних ефектів, легко виявляється та усувається), але часто є великим виграшем для налагоджувальних збірок.
///
/// Зауважте, що [`drop_in_place`] вже виконує цю перевірку, тому, якщо ваше навантаження може бути зменшено до деякої невеликої кількості дзвінків [`drop_in_place`], використання цього зайве.
/// Зокрема, зауважте, що ви можете [`drop_in_place`] зрізати, і це зробить єдину перевірку needs_drop для всіх значень.
///
/// Типи типу Vec, отже, просто `drop_in_place(&mut self[..])` без явного використання `needs_drop`.
/// З іншого боку, такі типи, як [`HashMap`], повинні скидати значення по черзі і повинні використовувати цей API.
///
/// [`drop_in_place`]: crate::ptr::drop_in_place
/// [`HashMap`]: ../../std/collections/struct.HashMap.html
///
/// # Examples
///
/// Ось приклад того, як колекція може використовувати `needs_drop`:
///
/// ```
/// use std::{mem, ptr};
///
/// pub struct MyCollection<T> {
/// #   data: [T; 1],
///     /* ... */
/// }
/// # impl<T> MyCollection<T> {
/// #   fn iter_mut(&mut self) -> &mut [T] { &mut self.data }
/// #   fn free_buffer(&mut self) {}
/// # }
///
/// impl<T> Drop for MyCollection<T> {
///     fn drop(&mut self) {
///         unsafe {
///             // скиньте дані
///             if mem::needs_drop::<T>() {
///                 for x in self.iter_mut() {
///                     ptr::drop_in_place(x);
///                 }
///             }
///             self.free_buffer();
///         }
///     }
/// }
/// ```
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "needs_drop", since = "1.21.0")]
#[rustc_const_stable(feature = "const_needs_drop", since = "1.36.0")]
#[rustc_diagnostic_item = "needs_drop"]
pub const fn needs_drop<T>() -> bool {
    intrinsics::needs_drop::<T>()
}

/// Повертає значення типу `T`, представлене абсолютно нульовим шаблоном байтів.
///
/// Це означає, що, наприклад, байт заповнення в `(u8, u16)` не обов'язково дорівнює нулю.
///
/// Немає гарантії, що абсолютно нульовий шаблон байта представляє дійсне значення певного типу `T`.
/// Наприклад, абсолютно нульовий шаблон байта не є дійсним значенням для посилальних типів (`&T`, `&mut T`) та покажчиків функцій.
/// Використання `zeroed` для таких типів спричиняє негайне виникнення [undefined behavior][ub], оскільки [the Rust compiler assumes][inv] про те, що в змінній, яку вона вважає ініціалізованою, завжди є дійсне значення.
///
///
/// Це має такий самий ефект, як [`MaybeUninit::zeroed().assume_init()`][zeroed].
/// Це іноді корисно для ІФР, але, як правило, його слід уникати.
///
/// [zeroed]: MaybeUninit::zeroed
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [inv]: MaybeUninit#initialization-invariant
///
/// # Examples
///
/// Правильне використання цієї функції: ініціалізація цілого числа нулем.
///
/// ```
/// use std::mem;
///
/// let x: i32 = unsafe { mem::zeroed() };
/// assert_eq!(0, x);
/// ```
///
/// *Неправильне* використання цієї функції: ініціалізація посилання нулем.
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem;
///
/// let _x: &i32 = unsafe { mem::zeroed() }; // Невизначена поведінка!
/// let _y: fn() = unsafe { mem::zeroed() }; // І знову!
/// ```
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_zeroed"]
pub unsafe fn zeroed<T>() -> T {
    // БЕЗПЕКА: абонент повинен гарантувати, що для `T` дійсне абсолютно нульове значення.
    unsafe {
        intrinsics::assert_zero_valid::<T>();
        MaybeUninit::zeroed().assume_init()
    }
}

/// Оминає звичайні перевірки ініціалізації пам'яті Rust, роблячи вигляд, що видає значення типу `T`, не роблячи при цьому нічого.
///
/// **Ця функція застаріла.** Натомість використовуйте [`MaybeUninit<T>`].
///
/// Причина застарілості полягає в тому, що функція в основному не може бути використана правильно: вона має такий самий ефект, як [`MaybeUninit::uninit().assume_init()`][uninit].
///
/// Як пояснює [`assume_init` documentation][assume_init], [the Rust compiler assumes][inv] ці значення належним чином ініціалізуються.
/// Як наслідок, виклик напр
/// `mem::uninitialized::<bool>()` спричиняє негайну невизначену поведінку для повернення `bool`, який однозначно не є `true` або `false`.
/// Гірше, справді неініціалізована пам'ять, наприклад те, що повертається сюди, особлива тим, що компілятор знає, що вона не має фіксованого значення.
/// Це робить невизначеною поведінку наявність неініціалізованих даних у змінній, навіть якщо ця змінна має цілочисельний тип.
/// (Зверніть увагу, що правила щодо неініціалізованих цілих чисел ще не доопрацьовані, але поки вони не є, бажано уникати їх.)
///
/// [uninit]: MaybeUninit::uninit
/// [assume_init]: MaybeUninit::assume_init
/// [inv]: MaybeUninit#initialization-invariant
///
///
///
///
///
#[inline(always)]
#[rustc_deprecated(since = "1.39.0", reason = "use `mem::MaybeUninit` instead")]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_uninitialized"]
pub unsafe fn uninitialized<T>() -> T {
    // БЕЗПЕКА: абонент повинен гарантувати, що неініціалізоване значення є дійсним для `T`.
    unsafe {
        intrinsics::assert_uninit_valid::<T>();
        MaybeUninit::uninit().assume_init()
    }
}

/// Змінює значення в двох місцях, що змінюються, не деініціалізуючи жодне.
///
/// * Якщо ви бажаєте поміняти місцями значення за замовчуванням або фіктивне значення, див. [`take`].
/// * Якщо ви хочете поміняти місцями передане значення, повернувши старе значення, див. [`replace`].
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// let mut x = 5;
/// let mut y = 42;
///
/// mem::swap(&mut x, &mut y);
///
/// assert_eq!(42, x);
/// assert_eq!(5, y);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn swap<T>(x: &mut T, y: &mut T) {
    // БЕЗПЕКА: необроблені вказівники створені з безпечних змінних посилань, що задовольняють всім
    // обмеження на `ptr::swap_nonoverlapping_one`
    unsafe {
        ptr::swap_nonoverlapping_one(x, y);
    }
}

/// Замінює `dest` типовим значенням `T`, повертаючи попереднє значення `dest`.
///
/// * Якщо ви хочете замінити значення двох змінних, див. [`swap`].
/// * Якщо ви хочете замінити переданим значенням замість значення за замовчуванням, див. [`replace`].
///
/// # Examples
///
/// Простий приклад:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::take(&mut v);
/// assert_eq!(vec![1, 2], old_v);
/// assert!(v.is_empty());
/// ```
///
/// `take` дозволяє отримати право власності на поле структури, замінивши його значенням "empty".
/// Без `take` ви можете зіткнутися з такими проблемами:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let buf = self.buf;
///         self.buf = Vec::new();
///         buf
///     }
/// }
/// ```
///
/// Зверніть увагу, що `T` не обов'язково реалізує [`Clone`], тому він навіть не може клонувати та скидати `self.buf`.
/// Але `take` можна використовувати для відмежування вихідного значення `self.buf` від `self`, дозволяючи повернути його:
///
///
/// ```
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         mem::take(&mut self.buf)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf.len(), 2);
///
/// assert_eq!(buffer.get_and_reset(), vec![0, 1]);
/// assert_eq!(buffer.buf.len(), 0);
/// ```
#[inline]
#[stable(feature = "mem_take", since = "1.40.0")]
pub fn take<T: Default>(dest: &mut T) -> T {
    replace(dest, T::default())
}

/// Переміщує `src` у вказаний `dest`, повертаючи попереднє значення `dest`.
///
/// Жодне значення не випадає.
///
/// * Якщо ви хочете замінити значення двох змінних, див. [`swap`].
/// * Якщо ви хочете замінити значення за замовчуванням, див. [`take`].
///
/// # Examples
///
/// Простий приклад:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::replace(&mut v, vec![3, 4, 5]);
/// assert_eq!(vec![1, 2], old_v);
/// assert_eq!(vec![3, 4, 5], v);
/// ```
///
/// `replace` дозволяє споживання поля структури, замінюючи його іншим значенням.
/// Без `replace` ви можете зіткнутися з такими проблемами:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let t = self.buf[i];
///         self.buf[i] = v;
///         t
///     }
/// }
/// ```
///
/// Зверніть увагу, що `T` не обов'язково реалізує [`Clone`], тому ми навіть не можемо клонувати `self.buf[i]`, щоб уникнути переміщення.
/// Але `replace` можна використовувати для відключення вихідного значення за цим індексом від `self`, дозволяючи повернути його:
///
///
/// ```
/// # #![allow(dead_code)]
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         mem::replace(&mut self.buf[i], v)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf[0], 0);
///
/// assert_eq!(buffer.replace_index(0, 2), 0);
/// assert_eq!(buffer.buf[0], 2);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[must_use = "if you don't need the old value, you can just assign the new value directly"]
pub fn replace<T>(dest: &mut T, src: T) -> T {
    // БЕЗПЕКА: Ми читаємо з `dest`, але згодом безпосередньо записуємо в нього `src`,
    // такі, що старе значення не дублюється.
    // Нічого не скидається, і нічого тут не може panic.
    unsafe {
        let result = ptr::read(dest);
        ptr::write(dest, src);
        result
    }
}

/// Розпоряджається цінністю.
///
/// Це робиться за допомогою виклику реалізації аргументу [`Drop`][drop].
///
/// Це фактично нічого не робить для типів, які реалізують `Copy`, наприклад
/// integers.
/// Такі значення копіюються та _then_ переміщується у функцію, тому значення зберігається і після виклику цієї функції.
///
///
/// Ця функція не є магією;це буквально визначається як
///
/// ```
/// pub fn drop<T>(_x: T) { }
/// ```
///
/// Оскільки `_x` переміщується у функцію, вона автоматично скидається, перш ніж функція повернеться.
///
/// [drop]: Drop
///
/// # Examples
///
/// Основне використання:
///
/// ```
/// let v = vec![1, 2, 3];
///
/// drop(v); // явно скиньте vector
/// ```
///
/// Оскільки [`RefCell`] застосовує правила запозичення під час виконання, `drop` може випустити запозичення [`RefCell`]:
///
/// ```
/// use std::cell::RefCell;
///
/// let x = RefCell::new(1);
///
/// let mut mutable_borrow = x.borrow_mut();
/// *mutable_borrow = 1;
///
/// drop(mutable_borrow); // відмовитися від змінної позики на цьому слоті
///
/// let borrow = x.borrow();
/// println!("{}", *borrow);
/// ```
///
/// Цілі числа та інші типи, що реалізують [`Copy`], не впливають на `drop`.
///
/// ```
/// #[derive(Copy, Clone)]
/// struct Foo(u8);
///
/// let x = 1;
/// let y = Foo(2);
/// drop(x); // копія `x` переміщується та видаляється
/// drop(y); // копія `y` переміщується та видаляється
///
/// println!("x: {}, y: {}", x, y.0); // все ще доступний
/// ```
///
/// [`RefCell`]: crate::cell::RefCell
///
#[doc(alias = "delete")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn drop<T>(_x: T) {}

/// Інтерпретує `src` як тип `&U`, а потім зчитує `src` без переміщення вміщеного значення.
///
/// Ця функція буде небезпечно вважати покажчик `src` дійсним для байтів [`size_of::<U>`][size_of], перетворюючи `&T` на `&U`, а потім зчитуючи `&U` (за винятком того, що це робиться правильно, навіть коли `&U` робить більш жорсткі вимоги до вирівнювання, ніж `&T`).
/// Він також небезпечно створить копію вміщеного значення, замість того, щоб переїхати з `src`.
///
/// Це не помилка під час компіляції, якщо `T` та `U` мають різні розміри, але настійно рекомендується викликати цю функцію лише там, де `T` та `U` мають однакові розміри.Ця функція запускає [undefined behavior][ub], якщо `U` більше, ніж `T`.
///
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// #[repr(packed)]
/// struct Foo {
///     bar: u8,
/// }
///
/// let foo_array = [10u8];
///
/// unsafe {
///     // Скопіюйте дані з 'foo_array' і розглядайте їх як 'Foo'
///     let mut foo_struct: Foo = mem::transmute_copy(&foo_array);
///     assert_eq!(foo_struct.bar, 10);
///
///     // Змініть скопійовані дані
///     foo_struct.bar = 20;
///     assert_eq!(foo_struct.bar, 20);
/// }
///
/// // Вміст 'foo_array' не повинен змінюватися
/// assert_eq!(foo_array, [10]);
/// ```
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_transmute_copy", issue = "83165")]
pub const unsafe fn transmute_copy<T, U>(src: &T) -> U {
    // Якщо U має вищу вимогу до вирівнювання, src може бути не вирівняний належним чином.
    if align_of::<U>() > align_of::<T>() {
        // БЕЗПЕКА: `src`-це посилання, яке гарантовано буде дійсним для читання.
        // Абонент повинен гарантувати, що фактична трансмутація є безпечною.
        unsafe { ptr::read_unaligned(src as *const T as *const U) }
    } else {
        // БЕЗПЕКА: `src`-це посилання, яке гарантовано буде дійсним для читання.
        // Ми просто перевірили, чи правильно вирівняно `src as *const U`.
        // Абонент повинен гарантувати, що фактична трансмутація є безпечною.
        unsafe { ptr::read(src as *const T as *const U) }
    }
}

/// Непрозорий тип, що представляє дискримінант переліку.
///
/// Для отримання додаткової інформації див. Функцію [`discriminant`] у цьому модулі.
#[stable(feature = "discriminant_value", since = "1.21.0")]
pub struct Discriminant<T>(<T as DiscriminantKind>::Discriminant);

// N.B. Ці реалізації Portrait неможливо отримати, оскільки ми не хочемо обмежувати T.

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> Copy for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> clone::Clone for Discriminant<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::PartialEq for Discriminant<T> {
    fn eq(&self, rhs: &Self) -> bool {
        self.0 == rhs.0
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::Eq for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> hash::Hash for Discriminant<T> {
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.0.hash(state);
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> fmt::Debug for Discriminant<T> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_tuple("Discriminant").field(&self.0).finish()
    }
}

/// Повертає значення, яке однозначно ідентифікує варіант перерахування в `v`.
///
/// Якщо `T` не є переліченням, виклик цієї функції не призведе до невизначеної поведінки, але повернене значення не вказано.
///
///
/// # Stability
///
/// Дискримінант варіанту перерахування може змінитися, якщо зміна визначення переліку.
/// Дискримінант якогось варіанту не зміниться між компіляціями з тим самим компілятором.
///
/// # Examples
///
/// Це можна використовувати для порівняння переліків, що несуть дані, не враховуючи фактичні дані:
///
/// ```
/// use std::mem;
///
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::discriminant(&Foo::A("bar")), mem::discriminant(&Foo::A("baz")));
/// assert_eq!(mem::discriminant(&Foo::B(1)), mem::discriminant(&Foo::B(2)));
/// assert_ne!(mem::discriminant(&Foo::B(3)), mem::discriminant(&Foo::C(3)));
/// ```
///
#[stable(feature = "discriminant_value", since = "1.21.0")]
#[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
pub const fn discriminant<T>(v: &T) -> Discriminant<T> {
    Discriminant(intrinsics::discriminant_value(v))
}

/// Повертає кількість варіантів у типі перечислення `T`.
///
/// Якщо `T` не є переліченням, виклик цієї функції не призведе до невизначеної поведінки, але повернене значення не вказано.
/// Так само, якщо `T` є переліком із більшою кількістю варіантів, ніж `usize::MAX`, повертане значення не вказано.
/// Незаселені варіанти будуть враховані.
///
/// # Examples
///
/// ```
/// # #![feature(never_type)]
/// # #![feature(variant_count)]
///
/// use std::mem;
///
/// enum Void {}
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::variant_count::<Void>(), 0);
/// assert_eq!(mem::variant_count::<Foo>(), 3);
///
/// assert_eq!(mem::variant_count::<Option<!>>(), 2);
/// assert_eq!(mem::variant_count::<Result<!, !>>(), 2);
/// ```
#[inline(always)]
#[unstable(feature = "variant_count", issue = "73662")]
#[rustc_const_unstable(feature = "variant_count", issue = "73662")]
pub const fn variant_count<T>() -> usize {
    intrinsics::variant_count::<T>()
}