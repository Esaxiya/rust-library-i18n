use crate::any::type_name;
use crate::fmt;
use crate::intrinsics;
use crate::mem::ManuallyDrop;
use crate::ptr;

/// Тип обгортки для побудови неініціалізованих екземплярів `T`.
///
/// # Інваріант ініціалізації
///
/// Загалом компілятор припускає, що змінна правильно ініціалізована відповідно до вимог типу змінної.Наприклад, змінна посилального типу повинна бути вирівняною та не дорівнювати NULL.
/// Це інваріант, який потрібно *завжди* підтримувати, навіть у небезпечному коді.
/// Як наслідок, нульова ініціалізація змінної посилального типу спричиняє миттєвий [undefined behavior][ub], незалежно від того, чи використовується це посилання коли-небудь для доступу до пам'яті:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: &i32 = unsafe { mem::zeroed() }; // невизначена поведінка!⚠️
/// // Еквівалентний код із `MaybeUninit<&i32>`:
/// let x: &i32 = unsafe { MaybeUninit::zeroed().assume_init() }; // невизначена поведінка!⚠️
/// ```
///
/// Це використовується компілятором для різних оптимізацій, таких як видалення перевірок часу виконання та оптимізація макета `enum`.
///
/// Подібним чином, повністю неініціалізована пам'ять може мати будь-який вміст, тоді як `bool` завжди повинен бути `true` або `false`.Отже, створення неініціалізованого `bool` є невизначеною поведінкою:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let b: bool = unsafe { mem::uninitialized() }; // невизначена поведінка!⚠️
/// // Еквівалентний код із `MaybeUninit<bool>`:
/// let b: bool = unsafe { MaybeUninit::uninit().assume_init() }; // невизначена поведінка!⚠️
/// ```
///
/// Більше того, неініціалізована пам'ять особлива тим, що не має фіксованого значення ("fixed", що означає "it won't change without being written to").Читання одного і того ж неініціалізованого байта кілька разів може дати різні результати.
/// Це робить невизначеною поведінку використання неініціалізованих даних у змінній, навіть якщо ця змінна має цілочисельний тип, який в іншому випадку може містити будь-який *фіксований* бітовий шаблон:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: i32 = unsafe { mem::uninitialized() }; // невизначена поведінка!⚠️
/// // Еквівалентний код із `MaybeUninit<i32>`:
/// let x: i32 = unsafe { MaybeUninit::uninit().assume_init() }; // невизначена поведінка!⚠️
/// ```
/// (Зверніть увагу, що правила щодо неініціалізованих цілих чисел ще не доопрацьовані, але поки вони не є, бажано уникати їх.)
///
/// Крім того, пам`ятайте, що більшість типів мають додаткові інваріанти, крім того, що вони просто вважаються ініціалізованими на рівні типу.
/// Наприклад, [`Vec<T>`], ініціалізований `1`, вважається ініціалізованим (за поточної реалізації; це не є стабільною гарантією), оскільки єдиною вимогою, яку компілятор знає про нього, є те, що вказівник даних повинен бути ненульовим.
/// Створення такого `Vec<T>` не спричиняє *негайної* невизначеної поведінки, але спричинить невизначену поведінку при більшості безпечних операцій (включаючи її відмову).
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
///
/// # Examples
///
/// `MaybeUninit<T>` служить для забезпечення небезпечного коду для обробки неініціалізованих даних.
/// Це сигнал для компілятора, який вказує, що дані тут можуть *не* ініціалізуватися:
///
/// ```rust
/// use std::mem::MaybeUninit;
///
/// // Створіть явно неініціалізовану посилання.
/// // Компілятор знає, що дані всередині `MaybeUninit<T>` можуть бути недійсними, а отже це не UB:
/// let mut x = MaybeUninit::<&i32>::uninit();
/// // Встановіть для нього дійсне значення.
/// unsafe { x.as_mut_ptr().write(&0); }
/// // Витяг ініціалізованих даних-це дозволено *лише після* належної ініціалізації `x`!
/////
/// let x = unsafe { x.assume_init() };
/// ```
///
/// Тоді компілятор знає, що не робить неправильних припущень або оптимізацій щодо цього коду.
///
/// Ви можете вважати `MaybeUninit<T>` схожим на `Option<T>`, але без будь-якого відстеження часу роботи та жодної перевірки безпеки.
///
/// ## out-pointers
///
/// Ви можете використовувати `MaybeUninit<T>` для реалізації "out-pointers": замість повернення даних із функції передайте вказівник на якусь пам`ять (uninitialized), щоб помістити результат.
/// Це може бути корисно, коли для абонента важливо контролювати, як виділяється пам'ять, в якій зберігається результат, і ви хочете уникнути непотрібних ходів.
///
/// ```
/// use std::mem::MaybeUninit;
///
/// unsafe fn make_vec(out: *mut Vec<i32>) {
///     // `write` не скидає старий вміст, що важливо.
///     out.write(vec![1, 2, 3]);
/// }
///
/// let mut v = MaybeUninit::uninit();
/// unsafe { make_vec(v.as_mut_ptr()); }
/// // Тепер ми знаємо, що `v` ініціалізований!Це також гарантує належне скидання vector.
/////
/// let v = unsafe { v.assume_init() };
/// assert_eq!(&v, &[1, 2, 3]);
/// ```
///
/// ## Ініціалізація масиву поелементно
///
/// `MaybeUninit<T>` може використовуватися для ініціалізації великого масиву поелементно:
///
/// ```
/// use std::mem::{self, MaybeUninit};
///
/// let data = {
///     // Створіть неініціалізований масив `MaybeUninit`.
///     // `assume_init` безпечний, оскільки тип, який, як ми стверджуємо, ініціалізували тут,-це купа `MaybeUninit`, які не вимагають ініціалізації.
/////
///     let mut data: [MaybeUninit<Vec<u32>>; 1000] = unsafe {
///         MaybeUninit::uninit().assume_init()
///     };
///
///     // Кидання `MaybeUninit` нічого не робить.
///     // Таким чином, використання сирого присвоєння покажчика замість `ptr::write` не призводить до скидання старого неініціалізованого значення.
/////
///     // Крім того, якщо під час цього циклу є panic, ми маємо витік пам'яті, але проблем із безпекою пам'яті немає.
/////
///     for elem in &mut data[..] {
///         *elem = MaybeUninit::new(vec![42]);
///     }
///
///     // Все ініціалізовано.
///     // Перетворити масив на ініціалізований тип.
///     unsafe { mem::transmute::<_, [Vec<u32>; 1000]>(data) }
/// };
///
/// assert_eq!(&data[0], &[42]);
/// ```
///
/// Ви також можете працювати з частково ініціалізованими масивами, які можна знайти в структурах даних низького рівня.
///
/// ```
/// use std::mem::MaybeUninit;
/// use std::ptr;
///
/// // Створіть неініціалізований масив `MaybeUninit`.
/// // `assume_init` безпечний, оскільки тип, який, як ми стверджуємо, ініціалізували тут,-це купа `MaybeUninit`, які не вимагають ініціалізації.
/////
/// let mut data: [MaybeUninit<String>; 1000] = unsafe { MaybeUninit::uninit().assume_init() };
/// // Підрахуйте кількість призначених нами елементів.
/// let mut data_len: usize = 0;
///
/// for elem in &mut data[0..500] {
///     *elem = MaybeUninit::new(String::from("hello"));
///     data_len += 1;
/// }
///
/// // Для кожного елемента масиву відпустіть, якщо ми його виділили.
/// for elem in &mut data[0..data_len] {
///     unsafe { ptr::drop_in_place(elem.as_mut_ptr()); }
/// }
/// ```
///
/// ## Ініціалізація структури поле за полем
///
/// Ви можете використовувати `MaybeUninit<T>` та макрос [`std::ptr::addr_of_mut`], щоб ініціалізувати структури по полях:
///
/// ```rust
/// use std::mem::MaybeUninit;
/// use std::ptr::addr_of_mut;
///
/// #[derive(Debug, PartialEq)]
/// pub struct Foo {
///     name: String,
///     list: Vec<u8>,
/// }
///
/// let foo = {
///     let mut uninit: MaybeUninit<Foo> = MaybeUninit::uninit();
///     let ptr = uninit.as_mut_ptr();
///
///     // Ініціалізація поля `name`
///     unsafe { addr_of_mut!((*ptr).name).write("Bob".to_string()); }
///
///     // Ініціалізація поля `list` Якщо тут є panic, тоді `String` у полі `name` витікає.
/////
///     unsafe { addr_of_mut!((*ptr).list).write(vec![0, 1, 2]); }
///
///     // Всі поля ініціалізовані, тому ми викликаємо `assume_init`, щоб отримати ініціалізований Foo.
///     unsafe { uninit.assume_init() }
/// };
///
/// assert_eq!(
///     foo,
///     Foo {
///         name: "Bob".to_string(),
///         list: vec![0, 1, 2]
///     }
/// );
/// ```
/// [`std::ptr::addr_of_mut`]: crate::ptr::addr_of_mut
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Layout
///
/// `MaybeUninit<T>` гарантовано мати такі ж розміри, вирівнювання та ABI, що і `T`:
///
/// ```rust
/// use std::mem::{MaybeUninit, size_of, align_of};
/// assert_eq!(size_of::<MaybeUninit<u64>>(), size_of::<u64>());
/// assert_eq!(align_of::<MaybeUninit<u64>>(), align_of::<u64>());
/// ```
///
/// Однак пам'ятайте, що тип *, що містить*`MaybeUninit<T>`, не обов'язково однаковий макет;Rust загалом не гарантує, що поля `Foo<T>` мають однаковий порядок, як `Foo<U>`, навіть якщо `T` і `U` мають однакові розміри та вирівнювання.
///
/// Крім того, оскільки будь-яке значення біта є дійсним для `MaybeUninit<T>`, компілятор не може застосовувати оптимізації non-zero/niche-filling, що потенційно може призвести до збільшення розміру:
///
/// ```rust
/// # use std::mem::{MaybeUninit, size_of};
/// assert_eq!(size_of::<Option<bool>>(), 1);
/// assert_eq!(size_of::<Option<MaybeUninit<bool>>>(), 2);
/// ```
///
/// Якщо `T` є безпечним для FFI, то це також і `MaybeUninit<T>`.
///
/// Хоча `MaybeUninit` є `#[repr(transparent)]` (це означає, що він гарантує такий самий розмір, вирівнювання та ABI, як `T`), це *не* змінює жодного з попередніх застережень.
/// `Option<T>` і `Option<MaybeUninit<T>>` все ще можуть мати різні розміри, а типи, що містять поле типу `T`, можуть бути викладені (і розміром) інакше, ніж якби це поле було `MaybeUninit<T>`.
/// `MaybeUninit` є типом об'єднання, а `#[repr(transparent)]` на об'єднаннях нестабільний (див. [the tracking issue](https://github.com/rust-lang/rust/issues/60405)).
/// З часом точні гарантії `#[repr(transparent)]` для профспілок можуть розвиватися, а `MaybeUninit` може залишатися `#[repr(transparent)]`, а може і не залишатися.
/// Тим не менш, `MaybeUninit<T>`*завжди* гарантуватиме, що він має такий самий розмір, вирівнювання та ABI, як `T`;просто спосіб реалізації цієї гарантії `MaybeUninit` може еволюціонувати.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "maybe_uninit", since = "1.36.0")]
// Язиковий предмет, щоб ми могли загортати в нього інші типи.Це корисно для генераторів.
#[lang = "maybe_uninit"]
#[derive(Copy)]
#[repr(transparent)]
pub union MaybeUninit<T> {
    uninit: (),
    value: ManuallyDrop<T>,
}

#[stable(feature = "maybe_uninit", since = "1.36.0")]
impl<T: Copy> Clone for MaybeUninit<T> {
    #[inline(always)]
    fn clone(&self) -> Self {
        // Не викликаючи `T::clone()`, ми не можемо знати, чи достатньо для цього нас ініціалізовано.
        *self
    }
}

#[stable(feature = "maybe_uninit_debug", since = "1.41.0")]
impl<T> fmt::Debug for MaybeUninit<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad(type_name::<Self>())
    }
}

impl<T> MaybeUninit<T> {
    /// Створює новий `MaybeUninit<T>`, ініціалізований із заданим значенням.
    /// Безпечно зателефонувати до [`assume_init`] щодо поверненого значення цієї функції.
    ///
    /// Зверніть увагу, що скидання `MaybeUninit<T>` ніколи не викликає код зниження `T`.
    /// Ви несете відповідальність за те, щоб `T` випав, якщо він був ініціалізований.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<Vec<u8>> = MaybeUninit::new(vec![42]);
    /// ```
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(val: T) -> MaybeUninit<T> {
        MaybeUninit { value: ManuallyDrop::new(val) }
    }

    /// Створює новий `MaybeUninit<T>` у неініціалізованому стані.
    ///
    /// Зверніть увагу, що скидання `MaybeUninit<T>` ніколи не викликає код зниження `T`.
    /// Ви несете відповідальність за те, щоб `T` випав, якщо він був ініціалізований.
    ///
    /// Деякі приклади див. У [type-level documentation][MaybeUninit].
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<String> = MaybeUninit::uninit();
    /// ```
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    #[rustc_diagnostic_item = "maybe_uninit_uninit"]
    pub const fn uninit() -> MaybeUninit<T> {
        MaybeUninit { uninit: () }
    }

    /// Створіть новий масив елементів `MaybeUninit<T>` у неініціалізованому стані.
    ///
    /// Note: у версії future Rust цей метод може стати непотрібним, коли синтаксис літералу масиву дозволяє [repeating const expressions](https://github.com/rust-lang/rust/issues/49147).
    ///
    /// У наведеному нижче прикладі можна використовувати `let mut buf = [MaybeUninit::<u8>::uninit(); 32];`.
    ///
    /// # Examples
    ///
    /// ```no_run
    /// #![feature(maybe_uninit_uninit_array, maybe_uninit_extra, maybe_uninit_slice)]
    ///
    /// use std::mem::MaybeUninit;
    ///
    /// extern "C" {
    ///     fn read_into_buffer(ptr: *mut u8, max_len: usize) -> usize;
    /// }
    ///
    /// /// Повертає (можливо менший) фрагмент даних, який був фактично прочитаний
    /// fn read(buf: &mut [MaybeUninit<u8>]) -> &[u8] {
    ///     unsafe {
    ///         let len = read_into_buffer(buf.as_mut_ptr() as *mut u8, buf.len());
    ///         MaybeUninit::slice_assume_init_ref(&buf[..len])
    ///     }
    /// }
    ///
    /// let mut buf: [MaybeUninit<u8>; 32] = MaybeUninit::uninit_array();
    /// let data = read(&mut buf);
    /// ```
    ///
    #[unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[rustc_const_unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[inline(always)]
    pub const fn uninit_array<const LEN: usize>() -> [Self; LEN] {
        // БЕЗПЕКА: діє неініціалізований `[MaybeUninit<_>; LEN]`.
        unsafe { MaybeUninit::<[MaybeUninit<T>; LEN]>::uninit().assume_init() }
    }

    /// Створює новий `MaybeUninit<T>` у неініціалізованому стані, при цьому пам`ять заповнюється байтами `0`.Від `T` залежить, чи це вже робить належну ініціалізацію.
    ///
    /// Наприклад, `MaybeUninit<usize>::zeroed()` ініціалізовано, але `MaybeUninit<&'static i32>::zeroed()`-не тому, що посилання не повинні бути нульовими.
    ///
    /// Зверніть увагу, що скидання `MaybeUninit<T>` ніколи не викликає код зниження `T`.
    /// Ви несете відповідальність за те, щоб `T` випав, якщо він був ініціалізований.
    ///
    /// # Example
    ///
    /// Правильне використання цієї функції: ініціалізація структури нулем, де всі поля структури можуть містити бітовий шаблон 0 як дійсне значення.
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<(u8, bool)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// assert_eq!(x, (0, false));
    /// ```
    ///
    /// *Неправильне* використання цієї функції: виклик `x.zeroed().assume_init()`, коли `0` не є дійсним бітовим шаблоном для типу:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// enum NotZero { One = 1, Two = 2 }
    ///
    /// let x = MaybeUninit::<(u8, NotZero)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// // Усередині пари ми створюємо `NotZero`, який не має дійсного дискримінанта.
    /// // Це невизначена поведінка.⚠️
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[inline]
    #[rustc_diagnostic_item = "maybe_uninit_zeroed"]
    pub fn zeroed() -> MaybeUninit<T> {
        let mut u = MaybeUninit::<T>::uninit();
        // БЕЗПЕКА: `u.as_mut_ptr()` вказує на виділену пам`ять.
        unsafe {
            u.as_mut_ptr().write_bytes(0u8, 1);
        }
        u
    }

    /// Встановлює значення `MaybeUninit<T>`.
    /// Це замінює будь-яке попереднє значення, не відкидаючи його, тому будьте обережні, щоб не використовувати це двічі, якщо ви не хочете пропустити запуск деструктора.
    ///
    /// Для вашої зручності це також повертає змінне посилання на (тепер безпечно ініціалізований) вміст `self`.
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const fn write(&mut self, val: T) -> &mut T {
        *self = MaybeUninit::new(val);
        // БЕЗПЕКА: Ми щойно ініціалізували це значення.
        unsafe { self.assume_init_mut() }
    }

    /// Отримує вказівник на міститься значення.
    /// Читання з цього вказівника або перетворення його на посилання є невизначеною поведінкою, якщо `MaybeUninit<T>` не ініціалізовано.
    /// Запис у пам`ять, на яку вказує цей вказівник (non-transitively), є невизначеною поведінкою (за винятком усередині `UnsafeCell<T>`).
    ///
    /// # Examples
    ///
    /// Правильне використання цього методу:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // Створіть посилання на `MaybeUninit<T>`.Це нормально, тому що ми це ініціалізували.
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// assert_eq!(x_vec.len(), 3);
    /// ```
    ///
    /// *Неправильне* використання цього методу:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// // Ми створили посилання на неініціалізований vector!Це невизначена поведінка.⚠️
    /// ```
    ///
    /// (Зверніть увагу, що правила щодо посилань на неініціалізовані дані ще не доопрацьовані, але поки вони не є, бажано їх уникати.)
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_ptr(&self) -> *const T {
        // `MaybeUninit` і `ManuallyDrop` є обома `repr(transparent)`, тому ми можемо привести вказівник.
        self as *const _ as *const T
    }

    /// Отримує змінний вказівник на міститься значення.
    /// Читання з цього вказівника або перетворення його на посилання є невизначеною поведінкою, якщо `MaybeUninit<T>` не ініціалізовано.
    ///
    /// # Examples
    ///
    /// Правильне використання цього методу:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // Створіть посилання на `MaybeUninit<Vec<u32>>`.
    /// // Це нормально, оскільки ми це ініціалізували.
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// x_vec.push(3);
    /// assert_eq!(x_vec.len(), 4);
    /// ```
    ///
    /// *Неправильне* використання цього методу:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// // Ми створили посилання на неініціалізований vector!Це невизначена поведінка.⚠️
    /// ```
    ///
    /// (Зверніть увагу, що правила щодо посилань на неініціалізовані дані ще не доопрацьовані, але поки вони не є, бажано їх уникати.)
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        // `MaybeUninit` і `ManuallyDrop` є обома `repr(transparent)`, тому ми можемо привести вказівник.
        self as *mut _ as *mut T
    }

    /// Витягує значення з контейнера `MaybeUninit<T>`.Це чудовий спосіб гарантувати, що дані будуть скинуті, оскільки отриманий `T` підлягає звичайному обробленню.
    ///
    /// # Safety
    ///
    /// Абонент повинен гарантувати, що `MaybeUninit<T>` дійсно перебуває в стані ініціалізації.Виклик цього, коли вміст ще не повністю ініціалізований, спричиняє негайну невизначену поведінку.
    /// [type-level documentation][inv] містить більше інформації про цей інваріант ініціалізації.
    ///
    /// [inv]: #initialization-invariant
    ///
    /// Крім того, пам`ятайте, що більшість типів мають додаткові інваріанти, крім того, що вони просто вважаються ініціалізованими на рівні типу.
    /// Наприклад, [`Vec<T>`], ініціалізований `1`, вважається ініціалізованим (за поточної реалізації; це не є стабільною гарантією), оскільки єдиною вимогою, яку компілятор знає про нього, є те, що вказівник даних повинен бути ненульовим.
    ///
    /// Створення такого `Vec<T>` не спричиняє *негайної* невизначеної поведінки, але спричинить невизначену поведінку при більшості безпечних операцій (включаючи її відмову).
    ///
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    /// # Examples
    ///
    /// Правильне використання цього методу:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<bool>::uninit();
    /// unsafe { x.as_mut_ptr().write(true); }
    /// let x_init = unsafe { x.assume_init() };
    /// assert_eq!(x_init, true);
    /// ```
    ///
    /// *Неправильне* використання цього методу:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_init = unsafe { x.assume_init() };
    /// // `x` ще не було ініціалізовано, тому цей останній рядок спричинив невизначену поведінку.⚠️
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    #[rustc_diagnostic_item = "assume_init"]
    pub const unsafe fn assume_init(self) -> T {
        // БЕЗПЕКА: абонент повинен гарантувати ініціалізацію `self`.
        // Це також означає, що `self` має бути варіантом `value`.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            ManuallyDrop::into_inner(self.value)
        }
    }

    /// Зчитує значення з контейнера `MaybeUninit<T>`.Отриманий `T` підлягає звичайному обробленню.
    ///
    /// По можливості, переважно використовувати [`assume_init`] замість цього, що запобігає дублюванню вмісту `MaybeUninit<T>`.
    ///
    /// # Safety
    ///
    /// Абонент повинен гарантувати, що `MaybeUninit<T>` дійсно перебуває в стані ініціалізації.Виклик цього, коли вміст ще не повністю ініціалізований, спричиняє невизначену поведінку.
    /// [type-level documentation][inv] містить більше інформації про цей інваріант ініціалізації.
    ///
    /// Більше того, це залишає копію тих самих даних позаду в `MaybeUninit<T>`.
    /// При використанні кількох копій даних (багаторазовим викликом `assume_init_read` або спочатку викликом `assume_init_read`, а потім [`assume_init`]), ви несете відповідальність за те, щоб ці дані дійсно дублювалися.
    ///
    ///
    /// [inv]: #initialization-invariant
    /// [`assume_init`]: MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// Правильне використання цього методу:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<u32>::uninit();
    /// x.write(13);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // `u32` є `Copy`, тому ми можемо читати кілька разів.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(None);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // Дублювання значення `None`-це нормально, тому ми можемо читати кілька разів.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    /// ```
    ///
    /// *Неправильне* використання цього методу:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(Some(vec![0, 1, 2]));
    /// let x1 = unsafe { x.assume_init_read() };
    /// let x2 = unsafe { x.assume_init_read() };
    /// // Тепер ми створили дві копії одного і того ж vector, що призведе до подвійного безкоштовного ⚠️, коли вони обидва випадуть!
    /////
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const unsafe fn assume_init_read(&self) -> T {
        // БЕЗПЕКА: абонент повинен гарантувати ініціалізацію `self`.
        // Читання з `self.as_ptr()` є безпечним, оскільки `self` слід ініціалізувати.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            self.as_ptr().read()
        }
    }

    /// Відкидає вміщене значення на місце.
    ///
    /// Якщо у вас є право власності на `MaybeUninit`, ви можете замість цього використовувати [`assume_init`].
    ///
    /// # Safety
    ///
    /// Абонент повинен гарантувати, що `MaybeUninit<T>` дійсно перебуває в стані ініціалізації.Виклик цього, коли вміст ще не повністю ініціалізований, спричиняє невизначену поведінку.
    ///
    /// Крім того, повинні бути задоволені всі додаткові інваріанти типу `T`, оскільки реалізація `Drop` `T` (або його члени) може покладатися на це.
    /// Наприклад, [`Vec<T>`], ініціалізований `1`, вважається ініціалізованим (за поточної реалізації; це не є стабільною гарантією), оскільки єдиною вимогою, яку компілятор знає про нього, є те, що вказівник даних повинен бути ненульовим.
    ///
    /// Однак кидання такого `Vec<T>` призведе до невизначеної поведінки.
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    pub unsafe fn assume_init_drop(&mut self) {
        // БЕЗПЕКА: абонент повинен гарантувати, що `self` ініціалізовано та
        // задовольняє всі інваріанти `T`.
        // Викидання значення на місце є безпечним, якщо це так.
        unsafe { ptr::drop_in_place(self.as_mut_ptr()) }
    }

    /// Отримує спільне посилання на міститься значення.
    ///
    /// Це може бути корисно, коли ми хочемо отримати доступ до `MaybeUninit`, який був ініціалізований, але не має права власності на `MaybeUninit` (що перешкоджає використанню `.assume_init()`).
    ///
    /// # Safety
    ///
    /// Виклик цього, коли вміст ще не повністю ініціалізований, спричиняє невизначену поведінку: абонент повинен гарантувати, що `MaybeUninit<T>` дійсно перебуває в стані ініціалізації.
    ///
    ///
    /// # Examples
    ///
    /// ### Правильне використання цього методу:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// // Ініціалізуйте `x`:
    /// unsafe { x.as_mut_ptr().write(vec![1, 2, 3]); }
    /// // Тепер, коли відомо, що наш `MaybeUninit<_>` ініціалізований, можна створити спільне посилання на нього:
    /////
    /// let x: &Vec<u32> = unsafe {
    ///     // БЕЗПЕКА: `x` ініціалізовано.
    ///     x.assume_init_ref()
    /// };
    /// assert_eq!(x, &vec![1, 2, 3]);
    /// ```
    ///
    /// ### *Неправильне* використання цього методу:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec: &Vec<u32> = unsafe { x.assume_init_ref() };
    /// // Ми створили посилання на неініціалізований vector!Це невизначена поведінка.⚠️
    /// ```
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{cell::Cell, mem::MaybeUninit};
    ///
    /// let b = MaybeUninit::<Cell<bool>>::uninit();
    /// // Ініціалізуйте `MaybeUninit` за допомогою `Cell::set`:
    /// unsafe {
    ///     b.assume_init_ref().set(true);
    ///    // ^^^^^^^^^^^^^^^
    ///    // Посилання на неініціалізований `Cell<bool>`: UB!
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_ref(&self) -> &T {
        // БЕЗПЕКА: абонент повинен гарантувати ініціалізацію `self`.
        // Це також означає, що `self` має бути варіантом `value`.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &*self.as_ptr()
        }
    }

    /// Отримує змінне посилання (unique) на міститься значення.
    ///
    /// Це може бути корисно, коли ми хочемо отримати доступ до `MaybeUninit`, який був ініціалізований, але не має права власності на `MaybeUninit` (що перешкоджає використанню `.assume_init()`).
    ///
    /// # Safety
    ///
    /// Виклик цього, коли вміст ще не повністю ініціалізований, спричиняє невизначену поведінку: абонент повинен гарантувати, що `MaybeUninit<T>` дійсно перебуває в стані ініціалізації.
    /// Наприклад, `.assume_init_mut()` не можна використовувати для ініціалізації `MaybeUninit`.
    ///
    /// # Examples
    ///
    /// ### Правильне використання цього методу:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// # unsafe extern "C" fn initialize_buffer(buf: *mut [u8; 2048]) { *buf = [0; 2048] }
    /// # #[cfg(FALSE)]
    /// extern "C" {
    ///     /// Ініціалізує *всі* байти вхідного буфера.
    ///     fn initialize_buffer(buf: *mut [u8; 2048]);
    /// }
    ///
    /// let mut buf = MaybeUninit::<[u8; 2048]>::uninit();
    ///
    /// // Ініціалізуйте `buf`:
    /// unsafe { initialize_buffer(buf.as_mut_ptr()); }
    /// // Тепер ми знаємо, що `buf` ініціалізовано, тому ми могли б його `.assume_init()`.
    /// // Однак використання `.assume_init()` може викликати `memcpy` із 2048 байт.
    /// // Щоб стверджувати, що наш буфер було ініціалізовано без його копіювання, ми оновлюємо `&mut MaybeUninit<[u8; 2048]>` до `&mut [u8; 2048]`:
    /////
    /// let buf: &mut [u8; 2048] = unsafe {
    ///     // БЕЗПЕКА: `buf` ініціалізовано.
    ///     buf.assume_init_mut()
    /// };
    ///
    /// // Тепер ми можемо використовувати `buf` як звичайний зріз:
    /// buf.sort_unstable();
    /// assert!(
    ///     buf.windows(2).all(|pair| pair[0] <= pair[1]),
    ///     "buffer is sorted",
    /// );
    /// ```
    ///
    /// ### *Неправильне* використання цього методу:
    ///
    /// Ви не можете використовувати `.assume_init_mut()` для ініціалізації значення:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut b = MaybeUninit::<bool>::uninit();
    /// unsafe {
    ///     *b.assume_init_mut() = true;
    ///     // Ми створили посилання (mutable) на неініціалізований `bool`!
    ///     // Це невизначена поведінка.⚠️
    /// }
    /// ```
    ///
    /// Наприклад, ви не можете [`Read`] перейти в неініціалізований буфер:
    ///
    /// [`Read`]: https://doc.rust-lang.org/std/io/trait.Read.html
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{io, mem::MaybeUninit};
    ///
    /// fn read_chunk (reader: &'_ mut dyn io::Read) -> io::Result<[u8; 64]>
    /// {
    ///     let mut buffer = MaybeUninit::<[u8; 64]>::uninit();
    ///     reader.read_exact(unsafe { buffer.assume_init_mut() })?;
    ///                             // ^^^^^^^^^^^^^^^^^^^^^^^^
    ///                             // (mutable) посилання на неініціалізовану пам'ять!
    ///                             // Це невизначена поведінка.
    ///     Ok(unsafe { buffer.assume_init() })
    /// }
    /// ```
    ///
    /// Також ви не можете використовувати прямий доступ до полів для покрокової поступової ініціалізації:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{mem::MaybeUninit, ptr};
    ///
    /// struct Foo {
    ///     a: u32,
    ///     b: u8,
    /// }
    ///
    /// let foo: Foo = unsafe {
    ///     let mut foo = MaybeUninit::<Foo>::uninit();
    ///     ptr::write(&mut foo.assume_init_mut().a as *mut u32, 1337);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) посилання на неініціалізовану пам'ять!
    ///                  // Це невизначена поведінка.
    ///     ptr::write(&mut foo.assume_init_mut().b as *mut u8, 42);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) посилання на неініціалізовану пам'ять!
    ///                  // Це невизначена поведінка.
    ///     foo.assume_init()
    /// };
    /// ```
    ///
    ///
    ///
    ///
    // FIXME(#76092): В даний час ми покладаємося на те, що вищезазначене є неправильним, тобто ми маємо посилання на неініціалізовані дані (наприклад, у `libcore/fmt/float.rs`).
    // Ми повинні прийняти остаточне рішення щодо правил до стабілізації.
    //
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_mut(&mut self) -> &mut T {
        // БЕЗПЕКА: абонент повинен гарантувати ініціалізацію `self`.
        // Це також означає, що `self` має бути варіантом `value`.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &mut *self.as_mut_ptr()
        }
    }

    /// Витягує значення з масиву контейнерів `MaybeUninit`.
    ///
    /// # Safety
    ///
    /// Абонент повинен гарантувати, що всі елементи масиву знаходяться в ініціалізованому стані.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_uninit_array)]
    /// #![feature(maybe_uninit_array_assume_init)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut array: [MaybeUninit<i32>; 3] = MaybeUninit::uninit_array();
    /// array[0] = MaybeUninit::new(0);
    /// array[1] = MaybeUninit::new(1);
    /// array[2] = MaybeUninit::new(2);
    ///
    /// // БЕЗПЕКА: Тепер безпечно, оскільки ми ініціалізували всі елементи
    /// let array = unsafe {
    ///     MaybeUninit::array_assume_init(array)
    /// };
    ///
    /// assert_eq!(array, [0, 1, 2]);
    /// ```
    #[unstable(feature = "maybe_uninit_array_assume_init", issue = "80908")]
    #[inline(always)]
    pub unsafe fn array_assume_init<const N: usize>(array: [Self; N]) -> [T; N] {
        // SAFETY:
        // * Абонент гарантує, що всі елементи масиву ініціалізовані
        // * `MaybeUninit<T>` і T гарантовано мати однаковий макет
        // * MaybeUnint не падає, тому немає подвійних фрі, і тому перетворення безпечне
        //
        unsafe {
            intrinsics::assert_inhabited::<[T; N]>();
            (&array as *const _ as *const [T; N]).read()
        }
    }

    /// Припускаючи, що всі елементи ініціалізовані, отримайте до них фрагмент.
    ///
    /// # Safety
    ///
    /// Абонент повинен гарантувати, що елементи `MaybeUninit<T>` дійсно перебувають у стані ініціалізації.
    ///
    /// Виклик цього, коли вміст ще не повністю ініціалізований, спричиняє невизначену поведінку.
    ///
    /// Докладніше та приклади див. У розділі [`assume_init_ref`].
    ///
    /// [`assume_init_ref`]: MaybeUninit::assume_init_ref
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_ref(slice: &[Self]) -> &[T] {
        // БЕЗПЕКА: передача фрагмента на `*const [T]` є безпечною, оскільки абонент гарантує це
        // `slice` ініціалізується, і `MaybeUninit` гарантовано матиме той самий макет, що і `T`.
        // Отриманий покажчик є дійсним, оскільки він відноситься до пам'яті, що належить `slice`, яка є посиланням і, отже, гарантовано буде дійсною для читання.
        //
        unsafe { &*(slice as *const [Self] as *const [T]) }
    }

    /// Припускаючи, що всі елементи ініціалізовані, отримайте до них змінний фрагмент.
    ///
    /// # Safety
    ///
    /// Абонент повинен гарантувати, що елементи `MaybeUninit<T>` дійсно перебувають у стані ініціалізації.
    ///
    /// Виклик цього, коли вміст ще не повністю ініціалізований, спричиняє невизначену поведінку.
    ///
    /// Докладніше та приклади див. У розділі [`assume_init_mut`].
    ///
    /// [`assume_init_mut`]: MaybeUninit::assume_init_mut
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_mut(slice: &mut [Self]) -> &mut [T] {
        // БЕЗПЕКА: подібно до інструкцій з техніки безпеки для `slice_get_ref`, але у нас є
        // змінне посилання, яке також гарантовано буде дійсним для записів.
        unsafe { &mut *(slice as *mut [Self] as *mut [T]) }
    }

    /// Отримує вказівник на перший елемент масиву.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_ptr(this: &[MaybeUninit<T>]) -> *const T {
        this.as_ptr() as *const T
    }

    /// Отримує змінний покажчик на перший елемент масиву.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_mut_ptr(this: &mut [MaybeUninit<T>]) -> *mut T {
        this.as_mut_ptr() as *mut T
    }

    /// Копіює елементи з `src` на `this`, повертаючи змінне посилання на тепер ініціалізований вміст `this`.
    ///
    /// Якщо `T` не реалізує `Copy`, використовуйте [`write_slice_cloned`]
    ///
    /// Це схоже на [`slice::copy_from_slice`].
    ///
    /// # Panics
    ///
    /// Ця функція буде panic, якщо два фрагменти мають різну довжину.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(); 32];
    /// let src = [0; 32];
    ///
    /// let init = MaybeUninit::write_slice(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = [0; 16];
    ///
    /// MaybeUninit::write_slice(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // БЕЗПЕКА: ми щойно скопіювали всі елементи len у вільну ємність
    /// // перші елементи vec src.len() діють зараз.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice_cloned`]: MaybeUninit::write_slice_cloned
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Copy,
    {
        // БЕЗПЕКА: &[T] та&[MaybeUninit<T>] мають однаковий макет
        let uninit_src: &[MaybeUninit<T>] = unsafe { super::transmute(src) };

        this.copy_from_slice(uninit_src);

        // БЕЗПЕКА: Дійсні елементи щойно скопійовані в `this`, тому він ініціалізований
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }

    /// Клонує елементи з `src` в `this`, повертаючи змінне посилання на тепер ініціалізований вміст `this`.
    /// Будь-які вже ініціалізовані елементи не будуть скинуті.
    ///
    /// Якщо `T` реалізує `Copy`, використовуйте [`write_slice`]
    ///
    /// Це схоже на [`slice::clone_from_slice`], але не втрачає існуючі елементи.
    ///
    /// # Panics
    ///
    /// Ця функція буде panic, якщо два зрізи мають різну довжину, або якщо реалізація `Clone` panics.
    ///
    /// Якщо є panic, вже клоновані елементи будуть видалені.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit()];
    /// let src = ["wibbly".to_string(), "wobbly".to_string(), "timey".to_string(), "wimey".to_string(), "stuff".to_string()];
    ///
    /// let init = MaybeUninit::write_slice_cloned(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = ["rust", "is", "a", "pretty", "cool", "language"];
    ///
    /// MaybeUninit::write_slice_cloned(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // БЕЗПЕКА: ми щойно клонували всі елементи лін у вільну ємність
    /// // перші елементи vec src.len() діють зараз.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice`]: MaybeUninit::write_slice
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice_cloned<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Clone,
    {
        // на відміну від copy_from_slice, це не викликає clone_from_slice на зрізі, це тому, що `MaybeUninit<T: Clone>` не реалізує Clone.
        //

        struct Guard<'a, T> {
            slice: &'a mut [MaybeUninit<T>],
            initialized: usize,
        }

        impl<'a, T> Drop for Guard<'a, T> {
            fn drop(&mut self) {
                let initialized_part = &mut self.slice[..self.initialized];
                // БЕЗПЕКА: цей необроблений фрагмент міститиме лише ініціалізовані об`єкти
                // ось чому, дозволено його кинути.
                unsafe {
                    crate::ptr::drop_in_place(MaybeUninit::slice_assume_init_mut(initialized_part));
                }
            }
        }

        assert_eq!(this.len(), src.len(), "destination and source slices have different lengths");
        // NOTE: Нам потрібно явно нарізати їх однаковою довжиною
        // для перевірки меж, які потрібно вилучити, і оптимізатор генерує memcpy для простих випадків (наприклад, T= u8).
        //
        let len = this.len();
        let src = &src[..len];

        // потрібен охоронець b/c panic може трапитися під час клонування
        let mut guard = Guard { slice: this, initialized: 0 };

        for i in 0..len {
            guard.slice[i].write(src[i].clone());
            guard.initialized += 1;
        }

        super::forget(guard);

        // БЕЗПЕКА: Дійсні елементи щойно записані в `this`, тому він ініціалізований
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }
}