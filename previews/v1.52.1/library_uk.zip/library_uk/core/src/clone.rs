//! `Clone` Portrait для типів, які не можуть бути «неявно скопійовані».
//!
//! У Rust деякими простими типами є "implicitly copyable", і коли ви їх призначаєте або передаєте як аргументи, одержувач отримає копію, залишаючи оригінальне значення на місці.
//! Ці типи не вимагають виділення для копіювання та не мають фіналізаторів (тобто вони не містять власні поля або реалізують [`Drop`]), тому компілятор вважає їх дешевими та безпечними для копіювання.
//!
//! Для інших типів копії повинні бути зроблені явно, за домовленістю, що реалізує [`Clone`] Portrait і викликає метод [`clone`].
//!
//! [`clone`]: Clone::clone
//!
//! Основний приклад використання:
//!
//! ```
//! let s = String::new(); // Рядковий тип реалізує Clone
//! let copy = s.clone(); // щоб ми могли його клонувати
//! ```
//!
//! Щоб легко застосувати Клон Portrait, ви також можете використовувати `#[derive(Clone)]`.Приклад:
//!
//! ```
//! #[derive(Clone)] // ми додаємо Клон Portrait до структури Морфея
//! struct Morpheus {
//!    blue_pill: f32,
//!    red_pill: i64,
//! }
//!
//! fn main() {
//!    let f = Morpheus { blue_pill: 0.0, red_pill: 0 };
//!    let copy = f.clone(); // і тепер ми можемо його клонувати!
//! }
//! ```
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

/// Поширений Portrait для можливості явного дублювання об'єкта.
///
/// Відрізняється від [`Copy`] тим, що [`Copy`] є неявним і надзвичайно недорогим, тоді як `Clone` завжди явний і може бути, а може і не бути дорогим.
/// Для того, щоб забезпечити ці характеристики, Rust не дозволяє перевстановити [`Copy`], але ви можете перепрофілювати `Clone` і запустити довільний код.
///
/// Оскільки `Clone` є більш загальним, ніж [`Copy`], ви можете автоматично зробити що завгодно [`Copy`] як `Clone`.
///
/// ## Derivable
///
/// Цей Portrait можна використовувати з `#[derive]`, якщо всі поля `Clone`.Реалізація `derive`d [`Clone`] викликає [`clone`] у кожному полі.
///
/// [`clone`]: Clone::clone
///
/// Для загальної структури `#[derive]` реалізує `Clone` умовно, додаючи прив'язаний `Clone` до загальних параметрів.
///
/// ```
/// // `derive` реалізує Клон для читання<T>коли Т-Клон.
/// #[derive(Clone)]
/// struct Reading<T> {
///     frequency: T,
/// }
/// ```
///
/// ## Як я можу застосувати `Clone`?
///
/// Типи, які є [`Copy`], повинні мати тривіальну реалізацію `Clone`.Більш формально:
/// якщо `T: Copy`, `x: T` та `y: &T`, то `let x = y.clone();` еквівалентно `let x = *y;`.
/// Ручні реалізації повинні бути обережними, щоб підтримувати цей інваріант;проте небезпечний код не повинен покладатися на нього для забезпечення безпеки пам'яті.
///
/// Прикладом є загальна структура, що містить покажчик функції.У цьому випадку реалізацію `Clone` не можна `вивести`, але можна реалізувати як:
///
/// ```
/// struct Generate<T>(fn() -> T);
///
/// impl<T> Copy for Generate<T> {}
///
/// impl<T> Clone for Generate<T> {
///     fn clone(&self) -> Self {
///         *self
///     }
/// }
/// ```
///
/// ## Додаткові реалізатори
///
/// На додаток до [implementors listed below][impls], наступні типи також реалізують `Clone`:
///
/// * Типи елементів функцій (тобто різні типи, визначені для кожної функції)
/// * Типи покажчиків функцій (наприклад, `fn() -> i32`)
/// * Типи масивів для всіх розмірів, якщо тип елемента також реалізує `Clone` (наприклад, `[i32; 123456]`)
/// * Набори типів, якщо кожен компонент також реалізує `Clone` (наприклад, `()`, `(i32, bool)`)
/// * Типи закриття, якщо вони не захоплюють жодної цінності із середовища або якщо всі такі захоплені значення реалізують `Clone` самі.
///   Зверніть увагу, що змінні, захоплені загальним посиланням, завжди реалізовують `Clone` (навіть якщо референт цього не робить), тоді як змінні, захоплені змінним посиланням, ніколи не реалізують `Clone`.
///
///
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "clone"]
#[rustc_diagnostic_item = "Clone"]
pub trait Clone: Sized {
    /// Повертає копію значення.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(noop_method_call)]
    /// let hello = "Hello"; // &str реалізує Клон
    ///
    /// assert_eq!("Hello", hello.clone());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "cloning is often expensive and is not expected to have side effects"]
    fn clone(&self) -> Self;

    /// Виконує копіювання з `source`.
    ///
    /// `a.clone_from(&b)` еквівалентно `a = b.clone()` за функціональністю, але може бути замінено для повторного використання ресурсів `a`, щоб уникнути непотрібних розподілів.
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn clone_from(&mut self, source: &Self) {
        *self = source.clone()
    }
}

/// Виведіть макрос, що генерує імпульс Portrait `Clone`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Clone($item:item) {
    /* compiler built-in */
}

// FIXME(aburka): ці структури використовуються виключно#[derive], щоб стверджувати, що кожен компонент типу реалізує Clone або Copy.
//
//
// Ці структури ніколи не повинні відображатися в коді користувача.
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsClone<T: Clone + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsCopy<T: Copy + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// Реалізації `Clone` для примітивних типів.
///
/// Реалізації, які неможливо описати в Rust, реалізовані в `traits::SelectionContext::copy_clone_conditions()` у `rustc_trait_selection`.
///
///
mod impls {

    use super::Clone;

    macro_rules! impl_clone {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Clone for $t {
                    #[inline]
                    fn clone(&self) -> Self {
                        *self
                    }
                }
            )*
        }
    }

    impl_clone! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Clone for ! {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *const T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *mut T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// Спільні посилання можна клонувати, але змінні посилання *не можуть*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for &T {
        #[inline]
        #[rustc_diagnostic_item = "noop_method_clone"]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// Спільні посилання можна клонувати, але змінні посилання *не можуть*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> !Clone for &mut T {}
}