use crate::cmp;
use crate::fmt;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ptr::NonNull;

// Хоча ця функція використовується в одному місці, і її реалізацію можна було б окреслити, попередні спроби зробити це rustc повільніше:
//
//
// * https://github.com/rust-lang/rust/pull/72189
// * https://github.com/rust-lang/rust/pull/79827
//
const fn size_align<T>() -> (usize, usize) {
    (mem::size_of::<T>(), mem::align_of::<T>())
}

/// Макет блоку пам'яті.
///
/// Екземпляр `Layout` описує певний макет пам'яті.
/// Ви створюєте `Layout` як вхідні дані для розподілу.
///
/// Усі макети мають відповідний розмір і вирівнювання потужності двох.
///
/// (Зверніть увагу, що макети *не* повинні мати ненульовий розмір, хоча `GlobalAlloc` вимагає, щоб усі запити пам'яті мали ненульовий розмір.
/// Абонент повинен або переконатися, що такі умови виконуються, або використовувати спеціальні розподільники з більш слабкими вимогами, або використовувати більш м'який інтерфейс `Allocator`.)
///
///
///
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[lang = "alloc_layout"]
pub struct Layout {
    // розмір запитуваного блоку пам'яті, вимірюється в байтах.
    size_: usize,

    // вирівнювання запитуваного блоку пам'яті, вимірюване в байтах.
    // ми гарантуємо, що це завжди є силою двох, оскільки API, як `posix_memalign`, цього вимагає, і це розумне обмеження, яке потрібно накласти на конструктори Layout.
    //
    //
    // (Однак ми аналогічно не вимагаємо `align>= sizeof(void *)`, even though that is* also* a requirement of `posix_memalign`.)
    //
    //
    align_: NonZeroUsize,
}

impl Layout {
    /// Конструює `Layout` із заданих `size` та `align` або повертає `LayoutError`, якщо не виконуються будь-які з наступних умов:
    ///
    /// * `align` не повинен бути нулем,
    ///
    /// * `align` має бути ступінь двох,
    ///
    /// * `size`, коли округлено до найближчого кратного `align`, не повинно переповнюватися (тобто округлене значення має бути менше або дорівнює `usize::MAX`).
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn from_size_align(size: usize, align: usize) -> Result<Self, LayoutError> {
        if !align.is_power_of_two() {
            return Err(LayoutError { private: () });
        }

        // (power-of-two передбачає вирівнювання!=0.)

        // Закруглений розмір:
        //   size_rounded_up=(розмір + вирівнювання, 1)&! (вирівнювання, 1);
        //
        // Зверху ми знаємо, що вирівнюємо!=0.
        // Якщо додавання (вирівнювання, 1) не переповнюється, округлення вгору буде чудовим.
        //
        // І навпаки,&-маскування за допомогою! (Align, 1) відніме лише біти нижчого порядку.
        // Таким чином, якщо переповнення відбувається із сумою,&-mask не може відняти достатньо, щоб скасувати це переповнення.
        //
        //
        // Вищезазначене означає, що перевірка переповнення підсумовування є необхідною та достатньою.
        //
        if size > usize::MAX - (align - 1) {
            return Err(LayoutError { private: () });
        }

        // БЕЗПЕКА: умови для `from_size_align_unchecked` були
        // перевірено вище.
        unsafe { Ok(Layout::from_size_align_unchecked(size, align)) }
    }

    /// Створює макет, минаючи всі перевірки.
    ///
    /// # Safety
    ///
    /// Ця функція небезпечна, оскільки не перевіряє передумови [`Layout::from_size_align`].
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub const unsafe fn from_size_align_unchecked(size: usize, align: usize) -> Self {
        // БЕЗПЕКА: абонент повинен переконатися, що `align` більше нуля.
        Layout { size_: size, align_: unsafe { NonZeroUsize::new_unchecked(align) } }
    }

    /// Мінімальний розмір у байтах для блоку пам'яті цього макета.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn size(&self) -> usize {
        self.size_
    }

    /// Мінімальне вирівнювання байтів для блоку пам'яті цього макета.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn align(&self) -> usize {
        self.align_.get()
    }

    /// Конструює `Layout`, придатний для зберігання значення типу `T`.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout_const_new", since = "1.42.0")]
    #[inline]
    pub const fn new<T>() -> Self {
        let (size, align) = size_align::<T>();
        // БЕЗПЕКА: вирівнювання гарантоване Rust як потужність двох і
        // комбіноване розмір + вирівнювання гарантовано впишеться в наш адресний простір.
        // Як результат, використовуйте тут неперевірений конструктор, щоб уникнути вставки коду, що panics, якщо він недостатньо оптимізований.
        //
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Виробляє макет, що описує запис, який можна використовувати для розподілу структури резервної копії для `T` (яка може бути Portrait або іншого розміру, такого як зріз).
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub fn for_value<T: ?Sized>(t: &T) -> Self {
        let (size, align) = (mem::size_of_val(t), mem::align_of_val(t));
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // БЕЗПЕКА: див. Обґрунтування `new` щодо того, чому використовується небезпечний варіант
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Виробляє макет, що описує запис, який можна використовувати для розподілу структури резервної копії для `T` (яка може бути Portrait або іншого розміру, такого як зріз).
    ///
    /// # Safety
    ///
    /// Цю функцію безпечно викликати, лише якщо виконуються такі умови:
    ///
    /// - Якщо `T` є `Sized`, цю функцію завжди безпечно викликати.
    /// - Якщо величина хвоста `T`:
    ///     - [slice], тоді довжина зрізу хвоста повинна бути ініціалізоване ціле число, а розмір *цілого значення*(динамічна довжина хвоста + статичний розмір префікса) повинен відповідати `isize`.
    ///     - [trait object], тоді vtable частина вказівника повинна вказувати на дійсну vtable для типу `T`, набутого примусовим зменшенням розміру, а розмір *цілого значення*(динамічна довжина хвоста + префікс зі статичним розміром) повинен відповідати `isize`.
    ///
    ///     - (unstable) [extern type], тоді цю функцію завжди безпечно викликати, але panic може повернути неправильне значення, оскільки макет зовнішнього типу невідомий.
    ///     Це така сама поведінка, як і [`Layout::for_value`] при посиланні на зовнішній хвіст типу.
    ///     - в іншому випадку консервативно не дозволяється викликати цю функцію.
    ///
    /// [trait object]: ../../book/ch17-02-trait-objects.html
    /// [extern type]: ../../unstable-book/language-features/extern-types.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "layout_for_ptr", issue = "69835")]
    pub unsafe fn for_value_raw<T: ?Sized>(t: *const T) -> Self {
        // БЕЗПЕКА: ми передаємо передумови цих функцій абоненту
        let (size, align) = unsafe { (mem::size_of_val_raw(t), mem::align_of_val_raw(t)) };
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // БЕЗПЕКА: див. Обґрунтування `new` щодо того, чому використовується небезпечний варіант
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Створює `NonNull`, який звисає, але добре вирівняний для цього макета.
    ///
    /// Зверніть увагу, що значення покажчика може потенційно представляти дійсний покажчик, а це означає, що воно не повинно використовуватися як значення сторожового "not yet initialized".
    /// Типи, які ліниво розподіляють, повинні відстежувати ініціалізацію якимось іншим способом.
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub const fn dangling(&self) -> NonNull<u8> {
        // БЕЗПЕКА: вирівнювання гарантовано буде ненульовим
        unsafe { NonNull::new_unchecked(self.align() as *mut u8) }
    }

    /// Створює макет, що описує запис, який може містити значення того самого макета, що і `self`, але який також вирівнюється до вирівнювання `align` (вимірюється в байтах).
    ///
    ///
    /// Якщо `self` вже відповідає встановленому вирівнюванню, тоді повертається `self`.
    ///
    /// Зверніть увагу, що цей метод не додає ніяких відступів до загального розміру, незалежно від того, чи повертається макет має інше вирівнювання.
    /// Іншими словами, якщо `K` має розмір 16, `K.align_to(32)` все ще * матиме розмір 16.
    ///
    /// Повертає помилку, якщо комбінація `self.size()` і заданого `align` порушує умови, перелічені в [`Layout::from_size_align`].
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn align_to(&self, align: usize) -> Result<Self, LayoutError> {
        Layout::from_size_align(self.size(), cmp::max(self.align(), align))
    }

    /// Повертає суму заповнення, яку ми повинні вставити після `self`, щоб переконатися, що наступна адреса задовольняє `align` (вимірюється в байтах).
    ///
    /// наприклад, якщо `self.size()` дорівнює 9, тоді `self.padding_needed_for(4)` повертає 3, оскільки це мінімальна кількість байтів заповнення, необхідна для отримання адреси з вирівнюванням 4 (припускаючи, що відповідний блок пам'яті починається з адреси з вирівнюванням 4).
    ///
    ///
    /// Повернене значення цієї функції не має значення, якщо `align` не є силою двох.
    ///
    /// Зверніть увагу, що утиліта поверненого значення вимагає, щоб `align` був меншим або рівним вирівнюванню початкової адреси для всього виділеного блоку пам'яті.Одним із способів задовольнити це обмеження є забезпечення `align <= self.align()`.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "const_alloc_layout", issue = "67521")]
    #[inline]
    pub const fn padding_needed_for(&self, align: usize) -> usize {
        let len = self.size();

        // Округлене значення:
        //   len_rounded_up=(len + вирівнювання, 1)&! (вирівнювання, 1);
        // а потім повертаємо різницю в заповнення: `len_rounded_up - len`.
        //
        // Ми використовуємо модульну арифметику:
        //
        // 1. вирівнювання гарантовано буде> 0, тому вирівнювання, 1 завжди є дійсним.
        //
        // 2.
        // `len + align - 1` може переповнюватися щонайбільше `align - 1`, тому&-маска з `!(align - 1)` забезпечить, що у випадку переповнення `len_rounded_up` сам по собі буде 0.
        //
        //    Таким чином, повернутий відступ при додаванні до `len` дає 0, що тривіально задовольняє вирівнюванню `align`.
        //
        // (Звичайно, спроби виділити блоки пам`яті, чий розмір і заповнення заповнюються вищезазначеним способом, все одно повинні призвести до того, що розподільник видасть помилку.)
        //
        //
        //
        //

        let len_rounded_up = len.wrapping_add(align).wrapping_sub(1) & !align.wrapping_sub(1);
        len_rounded_up.wrapping_sub(len)
    }

    /// Створює макет, округлюючи розмір цього макета до кратного вирівнюванню макета.
    ///
    ///
    /// Це еквівалентно додаванню результату `padding_needed_for` до поточного розміру макета.
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn pad_to_align(&self) -> Layout {
        let pad = self.padding_needed_for(self.align());
        // Це не може переповнюватися.Цитата з інваріанта Layout:
        // > `size`, коли округлюється до найближчого кратного `align`,
        // > не повинен переповнюватися (тобто округлене значення має бути менше
        // > `usize::MAX`)
        let new_size = self.size() + pad;

        Layout::from_size_align(new_size, self.align()).unwrap()
    }

    /// Створює макет, що описує запис для екземплярів `self` `self`, із відповідною кількістю відступів між кожною, щоб переконатися, що кожному екземпляру надається необхідний розмір та вирівнювання.
    /// У разі успіху повертає `(k, offs)`, де `k`-це макет масиву, а `offs`-відстань між початком кожного елемента масиву.
    ///
    /// При арифметичному переповненні повертає `LayoutError`.
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat(&self, n: usize) -> Result<(Self, usize), LayoutError> {
        // Це не може переповнюватися.Цитата з інваріанта Layout:
        // > `size`, коли округлюється до найближчого кратного `align`,
        // > не повинен переповнюватися (тобто округлене значення має бути менше
        // > `usize::MAX`)
        let padded_size = self.size() + self.padding_needed_for(self.align());
        let alloc_size = padded_size.checked_mul(n).ok_or(LayoutError { private: () })?;

        // БЕЗПЕКА: self.align вже відомий як дійсний, а alloc_size вже
        // прокладений вже.
        unsafe { Ok((Layout::from_size_align_unchecked(alloc_size, self.align()), padded_size)) }
    }

    /// Створює макет, що описує запис для `self`, за яким слідує `next`, включаючи будь-яке необхідне заповнення, щоб переконатись, що `next` буде правильно вирівняно, але *відсутні кінцеві відступи*.
    ///
    /// Для того, щоб відповідати макету представлення C `repr(C)`, вам слід зателефонувати до `pad_to_align` після розширення макета за допомогою всіх полів.
    /// (Немає способу збігатися із типовим макетом подання Rust `repr(Rust)`, as it is unspecified.)
    ///
    /// Зверніть увагу, що вирівнювання результуючого макета буде максимальним, ніж вирівнювання `self` та `next`, щоб забезпечити вирівнювання обох частин.
    ///
    /// Повертає `Ok((k, offset))`, де `k`-це макет конкатенованого запису, а `offset`-відносне розташування в байтах початку `next`, вбудованого в конкатенований запис (припускаючи, що сам запис починається зі зміщення 0).
    ///
    ///
    /// При арифметичному переповненні повертає `LayoutError`.
    ///
    /// # Examples
    ///
    /// Щоб розрахувати макет структури `#[repr(C)]` та зміщення полів від макетів її полів:
    ///
    /// ```rust
    /// # use std::alloc::{Layout, LayoutError};
    /// pub fn repr_c(fields: &[Layout]) -> Result<(Layout, Vec<usize>), LayoutError> {
    ///     let mut offsets = Vec::new();
    ///     let mut layout = Layout::from_size_align(0, 1)?;
    ///     for &field in fields {
    ///         let (new_layout, offset) = layout.extend(field)?;
    ///         layout = new_layout;
    ///         offsets.push(offset);
    ///     }
    ///     // Не забудьте завершити з `pad_to_align`!
    ///     Ok((layout.pad_to_align(), offsets))
    /// }
    /// # // перевірити, що це працює
    /// # #[repr(C)] struct S { a: u64, b: u32, c: u16, d: u32 }
    /// # let s = Layout::new::<S>();
    /// # let u16 = Layout::new::<u16>();
    /// # let u32 = Layout::new::<u32>();
    /// # let u64 = Layout::new::<u64>();
    /// # assert_eq!(repr_c(&[u64, u32, u16, u32]), Ok((s, vec![0, 8, 12, 16])));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn extend(&self, next: Self) -> Result<(Self, usize), LayoutError> {
        let new_align = cmp::max(self.align(), next.align());
        let pad = self.padding_needed_for(next.align());

        let offset = self.size().checked_add(pad).ok_or(LayoutError { private: () })?;
        let new_size = offset.checked_add(next.size()).ok_or(LayoutError { private: () })?;

        let layout = Layout::from_size_align(new_size, new_align)?;
        Ok((layout, offset))
    }

    /// Створює макет, що описує запис для екземплярів `self` `self`, без заповнення між кожним екземпляром.
    ///
    /// Зверніть увагу, що на відміну від `repeat`, `repeat_packed` не гарантує, що повторні екземпляри `self` будуть правильно вирівняні, навіть якщо даний екземпляр `self` правильно вирівняний.
    /// Іншими словами, якщо макет, повернутий `repeat_packed`, використовується для виділення масиву, не гарантується, що всі елементи масиву будуть правильно вирівняні.
    ///
    /// При арифметичному переповненні повертає `LayoutError`.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat_packed(&self, n: usize) -> Result<Self, LayoutError> {
        let size = self.size().checked_mul(n).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(size, self.align())
    }

    /// Створює макет, що описує запис для `self`, за яким слідує `next`, без додаткових відступів між ними.
    /// Оскільки жодне заповнення не вставлено, вирівнювання `next` не має значення і взагалі *не включено* в отриманий макет.
    ///
    ///
    /// При арифметичному переповненні повертає `LayoutError`.
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn extend_packed(&self, next: Self) -> Result<Self, LayoutError> {
        let new_size = self.size().checked_add(next.size()).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(new_size, self.align())
    }

    /// Створює макет, що описує запис для `[T; n]`.
    ///
    /// При арифметичному переповненні повертає `LayoutError`.
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn array<T>(n: usize) -> Result<Self, LayoutError> {
        let (layout, offset) = Layout::new::<T>().repeat(n)?;
        debug_assert_eq!(offset, mem::size_of::<T>());
        Ok(layout.pad_to_align())
    }
}

#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
pub type LayoutErr = LayoutError;

/// Параметри, надані `Layout::from_size_align` або іншому конструктору `Layout`, не задовольняють його задокументованим обмеженням.
///
///
#[stable(feature = "alloc_layout_error", since = "1.50.0")]
#[derive(Clone, PartialEq, Eq, Debug)]
pub struct LayoutError {
    private: (),
}

// (це нам потрібно для подальшого імпульсу помилки Portrait)
#[stable(feature = "alloc_layout", since = "1.28.0")]
impl fmt::Display for LayoutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("invalid parameters to Layout::from_size_align")
    }
}