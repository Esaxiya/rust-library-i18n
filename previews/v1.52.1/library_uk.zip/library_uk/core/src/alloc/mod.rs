//! API розподілу пам'яті

#![stable(feature = "alloc_module", since = "1.28.0")]

mod global;
mod layout;

#[stable(feature = "global_alloc", since = "1.28.0")]
pub use self::global::GlobalAlloc;
#[stable(feature = "alloc_layout", since = "1.28.0")]
pub use self::layout::Layout;
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
#[allow(deprecated, deprecated_in_future)]
pub use self::layout::LayoutErr;

#[stable(feature = "alloc_layout_error", since = "1.50.0")]
pub use self::layout::LayoutError;

use crate::fmt;
use crate::ptr::{self, NonNull};

/// Помилка `AllocError` вказує на помилку розподілу, яка може бути пов`язана з вичерпанням ресурсів або чимось неправильним при об`єднанні заданих вхідних аргументів із цим розподільником.
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[derive(Copy, Clone, PartialEq, Eq, Debug)]
pub struct AllocError;

// (це нам потрібно для подальшого імпульсу помилки Portrait)
#[unstable(feature = "allocator_api", issue = "32838")]
impl fmt::Display for AllocError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("memory allocation failed")
    }
}

/// Реалізація `Allocator` може розподіляти, вирощувати, зменшувати та звільняти довільні блоки даних, описані через [`Layout`][].
///
/// `Allocator` призначений для реалізації на ZST, посиланнях або розумних вказівниках, оскільки такий розподільник, як `MyAlloc([u8; N])`, не може бути переміщений без оновлення покажчиків до виділеної пам'яті.
///
/// На відміну від [`GlobalAlloc`][], у `Allocator` дозволено розміщення нульового розміру.
/// Якщо базовий розподільник не підтримує цього (наприклад, jemalloc) або повертає нульовий покажчик (наприклад, `libc::malloc`), це має бути зафіксовано реалізацією.
///
/// ### В даний час виділена пам'ять
///
/// Деякі з методів вимагають, щоб блок пам'яті *наразі виділявся* через розподільник.Це означає що:
///
/// * початкова адреса для цього блоку пам'яті раніше була повернута [`allocate`], [`grow`] або [`shrink`] та
///
/// * блок пам'яті не був згодом вивільнений, де блоки або вивільнені безпосередньо шляхом передачі в [`deallocate`], або змінені шляхом передачі в [`grow`] або [`shrink`], що повертає `Ok`.
///
/// Якщо `grow` або `shrink` повернули `Err`, переданий покажчик залишається дійсним.
///
/// [`allocate`]: Allocator::allocate
/// [`grow`]: Allocator::grow
/// [`shrink`]: Allocator::shrink
/// [`deallocate`]: Allocator::deallocate
///
/// ### Пристосування пам`яті
///
/// Деякі з методів вимагають, щоб макет *містив* блок пам'яті.
/// Що означає для макета до "fit" блок пам'яті означає (або, що еквівалентно, для блоку пам'яті до "fit" макет), це те, що повинні виконуватися такі умови:
///
/// * Блок повинен бути виділений з тим самим вирівнюванням, що і [`layout.align()`], і
///
/// * Наданий [`layout.size()`] повинен потрапляти в діапазон `min ..= max`, де:
///   - `min` - розмір макета, який нещодавно використовувався для розподілу блоку, та
///   - `max` це останній фактичний розмір, повернутий із [`allocate`], [`grow`] або [`shrink`].
///
/// [`layout.align()`]: Layout::align
/// [`layout.size()`]: Layout::size
///
/// # Safety
///
/// * Блоки пам'яті, повернуті з розподільника, повинні вказувати на дійсну пам'ять і зберігати свою дійсність, доки екземпляр та всі його клони не будуть скинуті,
///
/// * клонування або переміщення розподільника не повинно призвести до недійсності блоків пам'яті, повернутих з цього розподільника.Клонований розподільник повинен поводитися як той самий розподільник, і
///
/// * будь-який вказівник на блок пам'яті, який є [*currently allocated*], може бути переданий до будь-якого іншого методу розподілу.
///
/// [*currently allocated*]: #currently-allocated-memory
///
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
pub unsafe trait Allocator {
    /// Спроби виділити блок пам'яті.
    ///
    /// У разі успіху повертає [`NonNull<[u8]>`][NonNull], що відповідає розмірам та гарантіям вирівнювання `layout`.
    ///
    /// Повернутий блок може мати більший розмір, ніж вказано `layout.size()`, і може ініціювати або не ініціалізувати його вміст.
    ///
    /// # Errors
    ///
    /// Повернення `Err` означає, що або пам'ять вичерпана, або `layout` не відповідає розміру розподільника або обмеженням вирівнювання.
    ///
    /// Реалізаціям рекомендується повертати `Err` до вичерпання пам`яті, а не до паніки чи переривання, але це не є суворою вимогою.
    /// (Зокрема: це *законно* впроваджувати цей Portrait поверх базової бібліотеки власного розподілу, яка перериває вичерпання пам'яті.)
    ///
    /// Клієнтам, які хочуть перервати обчислення у відповідь на помилку розподілу, рекомендується викликати функцію [`handle_alloc_error`], а не безпосередньо викликати `panic!` або подібну.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError>;

    /// Поводиться як `allocate`, але також гарантує, що повернута пам'ять нульово ініціалізована.
    ///
    /// # Errors
    ///
    /// Повернення `Err` означає, що або пам'ять вичерпана, або `layout` не відповідає розміру розподільника або обмеженням вирівнювання.
    ///
    /// Реалізаціям рекомендується повертати `Err` до вичерпання пам`яті, а не до паніки чи переривання, але це не є суворою вимогою.
    /// (Зокрема: це *законно* впроваджувати цей Portrait поверх базової бібліотеки власного розподілу, яка перериває вичерпання пам'яті.)
    ///
    /// Клієнтам, які хочуть перервати обчислення у відповідь на помилку розподілу, рекомендується викликати функцію [`handle_alloc_error`], а не безпосередньо викликати `panic!` або подібну.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        let ptr = self.allocate(layout)?;
        // БЕЗПЕКА: `alloc` повертає дійсний блок пам'яті
        unsafe { ptr.as_non_null_ptr().as_ptr().write_bytes(0, ptr.len()) }
        Ok(ptr)
    }

    /// Виділяє пам`ять, на яку посилається `ptr`.
    ///
    /// # Safety
    ///
    /// * `ptr` повинен позначати блок пам'яті [*currently allocated*] через цей розподільник, і
    /// * `layout` повинен [*fit*], що блок пам'яті.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout);

    /// Спроби розширити блок пам'яті.
    ///
    /// Повертає новий [`NonNull<[u8]>`][NonNull], що містить вказівник та фактичний розмір виділеної пам'яті.Покажчик підходить для зберігання даних, описаних у `new_layout`.
    /// Для цього розподільник може розширити розподіл, на який посилається `ptr`, відповідно до нового макета.
    ///
    /// Якщо це повертає `Ok`, тоді право власності на блок пам'яті, на який посилається `ptr`, було передано цьому розподільнику.
    /// Пам'ять може бути звільнена, а може і не звільнятись, і її слід вважати непридатною, якщо вона не була знову передана абоненту через повернене значення цього методу.
    ///
    /// Якщо цей метод повертає `Err`, тоді право власності на блок пам'яті не передано в цей розподільник, і вміст блоку пам'яті не змінюється.
    ///
    /// # Safety
    ///
    /// * `ptr` повинен позначати блок пам'яті [*currently allocated*] через цей розподільник.
    /// * `old_layout` повинен [*fit*], що блоку пам'яті (аргумент `new_layout` не повинен відповідати йому.).
    /// * `new_layout.size()` має бути більшим або рівним `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Повертає `Err`, якщо новий макет не відповідає розмірам розподільника та обмеженням вирівнювання розподільника, або якщо зростання не вдається іншим чином.
    ///
    /// Реалізаціям рекомендується повертати `Err` до вичерпання пам`яті, а не до паніки чи переривання, але це не є суворою вимогою.
    /// (Зокрема: це *законно* впроваджувати цей Portrait поверх базової бібліотеки власного розподілу, яка перериває вичерпання пам'яті.)
    ///
    /// Клієнтам, які хочуть перервати обчислення у відповідь на помилку розподілу, рекомендується викликати функцію [`handle_alloc_error`], а не безпосередньо викликати `panic!` або подібну.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // БЕЗПЕКА: оскільки `new_layout.size()` має бути більшим або рівним
        // `old_layout.size()`, як старе, так і нове виділення пам'яті дійсні для читання та запису для байтів `old_layout.size()`.
        // Крім того, оскільки старе виділення ще не було звільнено, воно не може перекривати `new_ptr`.
        // Таким чином, дзвінок на `copy_nonoverlapping` безпечний.
        // Договір безпеки для `dealloc` повинен підтримувати абонент, що телефонує.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Поводиться як `grow`, але також гарантує, що новий вміст встановлюється на нуль перед поверненням.
    ///
    /// Блок пам'яті буде містити наступний вміст після успішного виклику
    /// `grow_zeroed`:
    ///   * Байти `0..old_layout.size()` збережені з вихідного розподілу.
    ///   * Байти `old_layout.size()..old_size` будуть або збережені, або обнулені, залежно від реалізації розподільника.
    ///   `old_size` відноситься до розміру блоку пам'яті до виклику `grow_zeroed`, який може бути більшим за розмір, який був спочатку запитаний при його виділенні.
    ///   * Байти `old_size..new_size` обнулені.`new_size` відноситься до розміру блоку пам'яті, поверненого викликом `grow_zeroed`.
    ///
    /// # Safety
    ///
    /// * `ptr` повинен позначати блок пам'яті [*currently allocated*] через цей розподільник.
    /// * `old_layout` повинен [*fit*], що блоку пам'яті (аргумент `new_layout` не повинен відповідати йому.).
    /// * `new_layout.size()` має бути більшим або рівним `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Повертає `Err`, якщо новий макет не відповідає розмірам розподільника та обмеженням вирівнювання розподільника, або якщо зростання не вдається іншим чином.
    ///
    /// Реалізаціям рекомендується повертати `Err` до вичерпання пам`яті, а не до паніки чи переривання, але це не є суворою вимогою.
    /// (Зокрема: це *законно* впроваджувати цей Portrait поверх базової бібліотеки власного розподілу, яка перериває вичерпання пам'яті.)
    ///
    /// Клієнтам, які хочуть перервати обчислення у відповідь на помилку розподілу, рекомендується викликати функцію [`handle_alloc_error`], а не безпосередньо викликати `panic!` або подібну.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate_zeroed(new_layout)?;

        // БЕЗПЕКА: оскільки `new_layout.size()` має бути більшим або рівним
        // `old_layout.size()`, як старе, так і нове виділення пам'яті дійсні для читання та запису для байтів `old_layout.size()`.
        // Крім того, оскільки старе виділення ще не було звільнено, воно не може перекривати `new_ptr`.
        // Таким чином, дзвінок на `copy_nonoverlapping` безпечний.
        // Договір безпеки для `dealloc` повинен підтримувати абонент, що телефонує.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Спроби зменшити блок пам'яті.
    ///
    /// Повертає новий [`NonNull<[u8]>`][NonNull], що містить вказівник та фактичний розмір виділеної пам'яті.Покажчик підходить для зберігання даних, описаних у `new_layout`.
    /// Для цього розподільник може зменшити розподіл, на який посилається `ptr`, щоб відповідати новому плануванню.
    ///
    /// Якщо це повертає `Ok`, тоді право власності на блок пам'яті, на який посилається `ptr`, було передано цьому розподільнику.
    /// Пам'ять може бути звільнена, а може і не звільнятись, і її слід вважати непридатною, якщо вона не була знову передана абоненту через повернене значення цього методу.
    ///
    /// Якщо цей метод повертає `Err`, тоді право власності на блок пам'яті не передано в цей розподільник, і вміст блоку пам'яті не змінюється.
    ///
    /// # Safety
    ///
    /// * `ptr` повинен позначати блок пам'яті [*currently allocated*] через цей розподільник.
    /// * `old_layout` повинен [*fit*], що блоку пам'яті (аргумент `new_layout` не повинен відповідати йому.).
    /// * `new_layout.size()` має бути меншим або рівним `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Повертає `Err`, якщо новий макет не відповідає розміру розподільника та обмеженням вирівнювання розподільника або якщо зменшення не вдається в іншому випадку.
    ///
    /// Реалізаціям рекомендується повертати `Err` до вичерпання пам`яті, а не до паніки чи переривання, але це не є суворою вимогою.
    /// (Зокрема: це *законно* впроваджувати цей Portrait поверх базової бібліотеки власного розподілу, яка перериває вичерпання пам'яті.)
    ///
    /// Клієнтам, які хочуть перервати обчислення у відповідь на помилку розподілу, рекомендується викликати функцію [`handle_alloc_error`], а не безпосередньо викликати `panic!` або подібну.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() <= old_layout.size(),
            "`new_layout.size()` must be smaller than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // БЕЗПЕКА: оскільки `new_layout.size()` має бути меншим або рівним
        // `old_layout.size()`, як старе, так і нове виділення пам'яті дійсні для читання та запису для байтів `new_layout.size()`.
        // Крім того, оскільки старе виділення ще не було звільнено, воно не може перекривати `new_ptr`.
        // Таким чином, дзвінок на `copy_nonoverlapping` безпечний.
        // Договір безпеки для `dealloc` повинен підтримувати абонент, що телефонує.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), new_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Створює адаптер "by reference" для цього екземпляра `Allocator`.
    ///
    /// Повернений адаптер також реалізує `Allocator` і просто запозичить його.
    #[inline(always)]
    fn by_ref(&self) -> &Self
    where
        Self: Sized,
    {
        self
    }
}

#[unstable(feature = "allocator_api", issue = "32838")]
unsafe impl<A> Allocator for &A
where
    A: Allocator + ?Sized,
{
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate(layout)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate_zeroed(layout)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        // БЕЗПЕКА: абонент, який телефонує, повинен дотримуватись договору безпеки
        unsafe { (**self).deallocate(ptr, layout) }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // БЕЗПЕКА: абонент, який телефонує, повинен дотримуватись договору безпеки
        unsafe { (**self).grow(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // БЕЗПЕКА: абонент, який телефонує, повинен дотримуватись договору безпеки
        unsafe { (**self).grow_zeroed(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // БЕЗПЕКА: абонент, який телефонує, повинен дотримуватись договору безпеки
        unsafe { (**self).shrink(ptr, old_layout, new_layout) }
    }
}