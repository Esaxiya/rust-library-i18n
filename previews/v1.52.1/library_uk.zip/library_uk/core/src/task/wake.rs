#![stable(feature = "futures_api", since = "1.36.0")]

use crate::fmt;
use crate::marker::{PhantomData, Unpin};

/// `RawWaker` дозволяє реалізатору виконавця завдання створити [`Waker`], який забезпечує індивідуальну поведінку пробудження.
///
/// [vtable]: https://en.wikipedia.org/wiki/Virtual_method_table
///
/// Він складається з вказівника даних та [virtual function pointer table (vtable)][vtable], який налаштовує поведінку `RawWaker`.
///
///
#[derive(PartialEq, Debug)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct RawWaker {
    /// Вказівник даних, який може використовуватися для зберігання довільних даних відповідно до вимог виконавця.
    /// Це може бути напр
    /// стираний вказівник на `Arc`, пов`язаний із завданням.
    /// Значення цього поля передається всім функціям, які є частиною vtable як першим параметром.
    ///
    data: *const (),
    /// Віртуальна таблиця покажчиків функцій, яка налаштовує поведінку цього waker.
    vtable: &'static RawWakerVTable,
}

impl RawWaker {
    /// Створює новий `RawWaker` із наданих покажчика `data` та `vtable`.
    ///
    /// Вказівник `data` може використовуватися для зберігання довільних даних відповідно до вимог виконавця.Це може бути напр
    /// стираний вказівник на `Arc`, пов`язаний із завданням.
    /// Значення цього вказівника буде передано всім функціям, які є частиною `vtable` як перший параметр.
    ///
    /// `vtable` налаштовує поведінку `Waker`, який створюється з `RawWaker`.
    /// Для кожної операції на `Waker` буде викликатися відповідна функція в `vtable` базового `RawWaker`.
    ///
    ///
    ///
    #[inline]
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    pub const fn new(data: *const (), vtable: &'static RawWakerVTable) -> RawWaker {
        RawWaker { data, vtable }
    }
}

/// Таблиця вказівників на віртуальну функцію (vtable), яка визначає поведінку [`RawWaker`].
///
/// Вказівник, що передається всім функціям всередині vtable, є покажчиком `data` від об'єкта [`RawWaker`], що вмикає.
///
/// Функції всередині цієї структури призначені лише для виклику вказівника `data` правильно побудованого об'єкта [`RawWaker`] зсередини реалізації [`RawWaker`].
/// Виклик однієї із функцій, що містяться, за допомогою будь-якого іншого вказівника `data` спричинить невизначену поведінку.
///
///
///
///
#[stable(feature = "futures_api", since = "1.36.0")]
#[derive(PartialEq, Copy, Clone, Debug)]
pub struct RawWakerVTable {
    /// Ця функція буде викликана, коли [`RawWaker`] буде клоновано, наприклад, коли [`Waker`], в якому зберігається [`RawWaker`], буде клоновано.
    ///
    /// Реалізація цієї функції повинна зберігати всі ресурси, необхідні для цього додаткового екземпляра [`RawWaker`] та відповідного завдання.
    /// Виклик `wake` на отриманому [`RawWaker`] повинен призвести до пробудження того самого завдання, яке було б пробуджене оригінальним [`RawWaker`].
    ///
    ///
    ///
    clone: unsafe fn(*const ()) -> RawWaker,

    /// Ця функція буде викликана, коли на [`Waker`] буде викликано `wake`.
    /// Він повинен пробудити завдання, пов'язане з цим [`RawWaker`].
    ///
    /// Реалізація цієї функції повинна забезпечити звільнення будь-яких ресурсів, пов`язаних із цим екземпляром [`RawWaker`] та відповідним завданням.
    ///
    ///
    wake: unsafe fn(*const ()),

    /// Ця функція буде викликана, коли на [`Waker`] буде викликано `wake_by_ref`.
    /// Він повинен пробудити завдання, пов'язане з цим [`RawWaker`].
    ///
    /// Ця функція подібна до `wake`, але не повинна використовувати вказаний вказівник даних.
    ///
    wake_by_ref: unsafe fn(*const ()),

    /// Ця функція викликається, коли [`RawWaker`] випадає.
    ///
    /// Реалізація цієї функції повинна забезпечити звільнення будь-яких ресурсів, пов`язаних із цим екземпляром [`RawWaker`] та відповідним завданням.
    ///
    ///
    drop: unsafe fn(*const ()),
}

impl RawWakerVTable {
    /// Створює новий `RawWakerVTable` із наданих функцій `clone`, `wake`, `wake_by_ref` та `drop`.
    ///
    /// # `clone`
    ///
    /// Ця функція буде викликана, коли [`RawWaker`] буде клоновано, наприклад, коли [`Waker`], в якому зберігається [`RawWaker`], буде клоновано.
    ///
    /// Реалізація цієї функції повинна зберігати всі ресурси, необхідні для цього додаткового екземпляра [`RawWaker`] та відповідного завдання.
    /// Виклик `wake` на отриманому [`RawWaker`] повинен призвести до пробудження того самого завдання, яке було б пробуджене оригінальним [`RawWaker`].
    ///
    /// # `wake`
    ///
    /// Ця функція буде викликана, коли на [`Waker`] буде викликано `wake`.
    /// Він повинен пробудити завдання, пов'язане з цим [`RawWaker`].
    ///
    /// Реалізація цієї функції повинна забезпечити звільнення будь-яких ресурсів, пов`язаних із цим екземпляром [`RawWaker`] та відповідним завданням.
    ///
    ///
    /// # `wake_by_ref`
    ///
    /// Ця функція буде викликана, коли на [`Waker`] буде викликано `wake_by_ref`.
    /// Він повинен пробудити завдання, пов'язане з цим [`RawWaker`].
    ///
    /// Ця функція подібна до `wake`, але не повинна використовувати вказаний вказівник даних.
    ///
    /// # `drop`
    ///
    /// Ця функція викликається, коли [`RawWaker`] випадає.
    ///
    /// Реалізація цієї функції повинна забезпечити звільнення будь-яких ресурсів, пов`язаних із цим екземпляром [`RawWaker`] та відповідним завданням.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_allow_const_fn_unstable(const_fn_fn_ptr_basics)]
    pub const fn new(
        clone: unsafe fn(*const ()) -> RawWaker,
        wake: unsafe fn(*const ()),
        wake_by_ref: unsafe fn(*const ()),
        drop: unsafe fn(*const ()),
    ) -> Self {
        Self { clone, wake, wake_by_ref, drop }
    }
}

/// `Context` асинхронного завдання.
///
/// В даний час `Context` служить лише для забезпечення доступу до `&Waker`, який можна використовувати для активації поточного завдання.
///
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Context<'a> {
    waker: &'a Waker,
    // Переконайтеся, що ми захищені від future проти змін дисперсії, примушуючи час життя бути інваріантним (тривалість життя аргументу-позиції є противаріантною, тоді як час життя повернутої позиції є коваріантним).
    //
    //
    //
    _marker: PhantomData<fn(&'a ()) -> &'a ()>,
}

impl<'a> Context<'a> {
    /// Створіть новий `Context` із `&Waker`.
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn from_waker(waker: &'a Waker) -> Self {
        Context { waker, _marker: PhantomData }
    }

    /// Повертає посилання на `Waker` для поточного завдання.
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn waker(&self) -> &'a Waker {
        &self.waker
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Context<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Context").field("waker", &self.waker).finish()
    }
}

/// `Waker`-це ручка для пробудження завдання, повідомляючи його виконавцю про готовність до запуску.
///
/// Цей дескриптор інкапсулює екземпляр [`RawWaker`], який визначає поведінку пробудження для конкретного виконавця.
///
///
/// Реалізує [`Clone`], [`Send`] та [`Sync`].
///
#[repr(transparent)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Waker {
    waker: RawWaker,
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Unpin for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Send for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Sync for Waker {}

impl Waker {
    /// Пробудіть завдання, пов'язане з цим `Waker`.
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake(self) {
        // Фактичний виклик пробудження делегується через виклик віртуальної функції до реалізації, яку визначає виконавець.
        //
        let wake = self.waker.vtable.wake;
        let data = self.waker.data;

        // Не дзвоніть на `drop`-waker споживає `wake`.
        crate::mem::forget(self);

        // БЕЗПЕКА: Це безпечно, оскільки `Waker::from_raw`-єдиний спосіб
        // ініціалізувати `wake` та `data`, вимагаючи від користувача визнати, що контракт `RawWaker` виконується.
        //
        unsafe { (wake)(data) };
    }

    /// Пробудіть завдання, пов'язане з цим `Waker`, не витрачаючи `Waker`.
    ///
    /// Це схоже на `wake`, але може бути дещо менш ефективним у тому випадку, коли є власник `Waker`.
    /// Цей метод слід віддавати перевагу виклику `waker.clone().wake()`.
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake_by_ref(&self) {
        // Фактичний виклик пробудження делегується через виклик віртуальної функції до реалізації, яку визначає виконавець.
        //

        // БЕЗПЕКА: див. `wake`
        unsafe { (self.waker.vtable.wake_by_ref)(self.waker.data) }
    }

    /// Повертає `true`, якщо цей `Waker` та інший `Waker` пробудили те саме завдання.
    ///
    /// Ця функція працює з найкращими зусиллями і може повернути значення false навіть тоді, коли `Waker` пробудить те саме завдання.
    /// Однак, якщо ця функція повертає `true`, гарантовано, що `Waker`s пробудить те саме завдання.
    ///
    /// Ця функція в основному використовується для цілей оптимізації.
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn will_wake(&self, other: &Waker) -> bool {
        self.waker == other.waker
    }

    /// Створює новий `Waker` із [`RawWaker`].
    ///
    /// Поведінка поверненого `Waker` не визначено, якщо контракт, визначений у документації ['RawWaker`] та [' RawWakerVTable`], не підтримується.
    ///
    /// Тому цей метод небезпечний.
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub unsafe fn from_raw(waker: RawWaker) -> Waker {
        Waker { waker }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Clone for Waker {
    #[inline]
    fn clone(&self) -> Self {
        Waker {
            // БЕЗПЕКА: Це безпечно, оскільки `Waker::from_raw`-єдиний спосіб
            // ініціалізувати `clone` та `data`, вимагаючи від користувача визнати, що контракт [`RawWaker`] виконується.
            //
            waker: unsafe { (self.waker.vtable.clone)(self.waker.data) },
        }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Drop for Waker {
    #[inline]
    fn drop(&mut self) {
        // БЕЗПЕКА: Це безпечно, оскільки `Waker::from_raw`-єдиний спосіб
        // ініціалізувати `drop` та `data`, вимагаючи від користувача визнати, що контракт `RawWaker` виконується.
        //
        unsafe { (self.waker.vtable.drop)(self.waker.data) }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Waker {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let vtable_ptr = self.waker.vtable as *const RawWakerVTable;
        f.debug_struct("Waker")
            .field("data", &self.waker.data)
            .field("vtable", &vtable_ptr)
            .finish()
    }
}