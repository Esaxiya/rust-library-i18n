//! Підтримка Panic для libcore
//!
//! Основна бібліотека не може визначити паніку, але вона *оголошує* паніку.
//! Це означає, що функції всередині libcore дозволено panic, але, щоб бути корисним crate вище за течією, необхідно визначити паніку для використання libcore.
//! Поточний інтерфейс для паніки:
//!
//! ```
//! fn panic_impl(pi: &core::panic::PanicInfo<'_>) -> !
//! # { loop {} }
//! ```
//!
//! Це визначення допускає паніку з будь-яким загальним повідомленням, але не допускає помилки зі значенням `Box<Any>`.
//! (`PanicInfo` просто містить `&(dyn Any + Send)`, для якого ми заповнюємо фіктивне значення в `PanicInfo: : internal_constructor`.) Причиною цього є те, що libcore заборонено виділяти.
//!
//!
//! Цей модуль містить кілька інших функцій, що викликають паніку, але це лише необхідні елементи lang для компілятора.Всі panics передаються через цю одну функцію.
//! Фактичний символ оголошується через атрибут `#[panic_handler]`.
//!
//!
//!

#![allow(dead_code, missing_docs)]
#![unstable(
    feature = "core_panic",
    reason = "internal details of the implementation of the `panic!` and related macros",
    issue = "none"
)]

use crate::fmt;
use crate::panic::{Location, PanicInfo};

/// Основна реалізація макросу `panic!` libcore, коли не використовується форматування.
#[cold]
// ніколи не вбудований, якщо panic_immediate_abort, щоб уникнути роздуття коду на сайтах викликів, наскільки це можливо
//
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic"] // необхідний кодегену для panic на переповненні та інших термінаторах MIR `Assert`
pub fn panic(expr: &'static str) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // Використовуйте Arguments::new_v1 замість format_args! ("{}", Expr), щоб потенційно зменшити накладні витрати.
    // Аргументи_формату!макрос використовує str's Display Portrait для написання expr, який викликає Formatter::pad, який повинен враховувати усічення рядків та відступ (хоча жоден тут не використовується).
    //
    // Використання Arguments::new_v1 може дозволити компілятору пропустити Formatter::pad із вихідного двійкового файлу, заощадивши до декількох кілобайт.
    //
    //
    panic_fmt(fmt::Arguments::new_v1(&[expr], &[]));
}

#[inline]
#[track_caller]
#[lang = "panic_str"] // необхідний для оціненого за константами panics
pub fn panic_str(expr: &str) -> ! {
    panic_fmt(format_args!("{}", expr));
}

#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic_bounds_check"] // необхідний кодегену для panic при доступі OOB array/slice
fn panic_bounds_check(index: usize, len: usize) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    panic!("index out of bounds: the len is {} but the index is {}", len, index)
}

/// Під час форматування використовується основна реалізація макросу `panic!` libcore.
#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[cfg_attr(feature = "panic_immediate_abort", inline)]
#[track_caller]
pub fn panic_fmt(fmt: fmt::Arguments<'_>) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // ПРИМІТКА Ця функція ніколи не переходить межу FFI;це виклик Rust-to-Rust, який отримує перехід до функції `#[panic_handler]`.
    //
    extern "Rust" {
        #[lang = "panic_impl"]
        fn panic_impl(pi: &PanicInfo<'_>) -> !;
    }

    let pi = PanicInfo::internal_constructor(Some(&fmt), Location::caller());

    // БЕЗПЕКА: `panic_impl` визначено в безпечному коді Rust і, отже, безпечно телефонувати.
    unsafe { panic_impl(&pi) }
}

#[derive(Debug)]
#[doc(hidden)]
pub enum AssertKind {
    Eq,
    Ne,
}

/// Внутрішня функція для макросів `assert_eq!` та `assert_ne!`
#[cold]
#[track_caller]
#[doc(hidden)]
pub fn assert_failed<T, U>(
    kind: AssertKind,
    left: &T,
    right: &U,
    args: Option<fmt::Arguments<'_>>,
) -> !
where
    T: fmt::Debug + ?Sized,
    U: fmt::Debug + ?Sized,
{
    #[track_caller]
    fn inner(
        kind: AssertKind,
        left: &dyn fmt::Debug,
        right: &dyn fmt::Debug,
        args: Option<fmt::Arguments<'_>>,
    ) -> ! {
        let op = match kind {
            AssertKind::Eq => "==",
            AssertKind::Ne => "!=",
        };

        match args {
            Some(args) => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`: {}"#,
                op, left, right, args
            ),
            None => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`"#,
                op, left, right,
            ),
        }
    }
    inner(kind, &left, &right, args)
}