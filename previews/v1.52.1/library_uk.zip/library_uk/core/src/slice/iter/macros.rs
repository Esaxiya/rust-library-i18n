//! Макроси, що використовуються ітераторами фрагмента.

// Вбудовування is_empty і len робить величезну різницю в продуктивності
macro_rules! is_empty {
    // Як ми кодуємо довжину ітератора ZST, це працює як для ZST, так і для не ZST.
    //
    ($self: ident) => {
        $self.ptr.as_ptr() as *const T == $self.end
    };
}

// Щоб позбутися деяких обмежень (див. `position`), ми обчислюємо довжину дещо несподівано.
// (Перевірено `codegen/slice-position-bounds-check`.)
macro_rules! len {
    ($self: ident) => {{
        #![allow(unused_unsafe)] // нас іноді використовують у небезпечному блоці

        let start = $self.ptr;
        let size = size_from_ptr(start.as_ptr());
        if size == 0 {
            // Цей _cannot_ використовує `unchecked_sub`, оскільки ми залежать від обтікання, щоб представити довжину довгих ітераторів зрізу ZST.
            //
            ($self.end as usize).wrapping_sub(start.as_ptr() as usize)
        } else {
            // Ми знаємо, що `start <= end`, тому може працювати краще, ніж `offset_from`, який повинен мати справу підписаним.
            // Встановивши тут відповідні прапори, ми можемо сказати LLVM про це, що допомагає йому видаляти обмеження.
            // БЕЗПЕКА: За типом інваріант, `start <= end`
            //
            let diff = unsafe { unchecked_sub($self.end as usize, start.as_ptr() as usize) };
            // Також повідомляючи LLVM, що покажчики розділені точно кратним розміру типу, він може оптимізувати `len() == 0` до `start == end` замість `(end - start) < size`.
            //
            // БЕЗПЕКА: За типом інваріант, покажчики вирівняні так, щоб
            //         відстань між ними повинна бути кратною розміру пуанти
            //
            unsafe { exact_div(diff, size) }
        }
    }};
}

// Спільне визначення ітераторів `Iter` та `IterMut`
macro_rules! iterator {
    (
        struct $name:ident -> $ptr:ty,
        $elem:ty,
        $raw_mut:tt,
        {$( $mut_:tt )?},
        {$($extra:tt)*}
    ) => {
        // Повертає перший елемент і переміщує початок ітератора вперед на 1.
        // Значно покращує продуктивність у порівнянні з вбудованою функцією.
        // Ітератор не повинен бути порожнім.
        macro_rules! next_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.post_inc_start(1)}
        }

        // Повертає останній елемент і переміщує кінець ітератора назад на 1.
        // Значно покращує продуктивність у порівнянні з вбудованою функцією.
        // Ітератор не повинен бути порожнім.
        macro_rules! next_back_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.pre_dec_end(1)}
        }

        // Зменшує ітератор, коли T-ZST, переміщуючи кінець ітератора назад на `n`.
        // `n` не повинен перевищувати `self.len()`.
        macro_rules! zst_shrink {
            ($self: ident, $n: ident) => {
                $self.end = ($self.end as * $raw_mut u8).wrapping_offset(-$n) as * $raw_mut T;
            }
        }

        impl<'a, T> $name<'a, T> {
            // Допоміжна функція для створення фрагмента з ітератора.
            #[inline(always)]
            fn make_slice(&self) -> &'a [T] {
                // БЕЗПЕКА: ітератор був створений із зрізу з покажчиком
                // `self.ptr` і довжина `len!(self)`.
                // Це гарантує, що всі передумови для `from_raw_parts` виконані.
                unsafe { from_raw_parts(self.ptr.as_ptr(), len!(self)) }
            }

            // Допоміжна функція для переміщення початку ітератора вперед елементами `offset`, повертаючи старий початок.
            //
            // Небезпечно, оскільки зсув не повинен перевищувати `self.len()`.
            #[inline(always)]
            unsafe fn post_inc_start(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    let old = self.ptr.as_ptr();
                    // БЕЗПЕКА: абонент гарантує, що `offset` не перевищує `self.len()`,
                    // отже, цей новий покажчик знаходиться всередині `self` і, отже, гарантовано не буде нульовим.
                    self.ptr = unsafe { NonNull::new_unchecked(self.ptr.as_ptr().offset(offset)) };
                    old
                }
            }

            // Допоміжна функція для переміщення кінця ітератора назад елементами `offset`, повертаючи новий кінець.
            //
            // Небезпечно, оскільки зсув не повинен перевищувати `self.len()`.
            #[inline(always)]
            unsafe fn pre_dec_end(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    // БЕЗПЕКА: абонент гарантує, що `offset` не перевищує `self.len()`,
                    // який гарантовано не переповнює `isize`.
                    // Крім того, отриманий вказівник знаходиться в межах `slice`, який відповідає іншим вимогам до `offset`.
                    self.end = unsafe { self.end.offset(-offset) };
                    self.end
                }
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T> ExactSizeIterator for $name<'_, T> {
            #[inline(always)]
            fn len(&self) -> usize {
                len!(self)
            }

            #[inline(always)]
            fn is_empty(&self) -> bool {
                is_empty!(self)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> Iterator for $name<'a, T> {
            type Item = $elem;

            #[inline]
            fn next(&mut self) -> Option<$elem> {
                // може бути реалізований за допомогою фрагментів, але це дозволяє уникнути обмежень

                // БЕЗПЕКА: дзвінки `assume` безпечні, оскільки вказівник початку зрізу
                // повинен бути ненульовим, а зрізи над не ZST також повинні мати ненульовий кінцевий вказівник.
                // Виклик `next_unchecked!` безпечний, оскільки ми перевіряємо, чи спочатку ітератор порожній.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                let exact = len!(self);
                (exact, Some(exact))
            }

            #[inline]
            fn count(self) -> usize {
                len!(self)
            }

            #[inline]
            fn nth(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // Цей ітератор порожній.
                    if mem::size_of::<T>() == 0 {
                        // Ми повинні зробити це таким чином, оскільки `ptr` ніколи не може бути 0, але `end` може бути (через обтікання).
                        //
                        self.end = self.ptr.as_ptr();
                    } else {
                        // БЕЗПЕКА: end не може бути 0, якщо T не ZST, оскільки ptr не 0, а end>=ptr
                        unsafe {
                            self.ptr = NonNull::new_unchecked(self.end as *mut T);
                        }
                    }
                    return None;
                }
                // БЕЗПЕКА: Ми знаходимося в обмеженнях.`post_inc_start` робить правильно, навіть для ZST.
                unsafe {
                    self.post_inc_start(n as isize);
                    Some(next_unchecked!(self))
                }
            }

            #[inline]
            fn last(mut self) -> Option<$elem> {
                self.next_back()
            }

            // Ми замінюємо реалізацію за замовчуванням, яка використовує `try_fold`, оскільки ця проста реалізація генерує менше IR LLVM і швидше компілюється.
            //
            //
            #[inline]
            fn for_each<F>(mut self, mut f: F)
            where
                Self: Sized,
                F: FnMut(Self::Item),
            {
                while let Some(x) = self.next() {
                    f(x);
                }
            }

            // Ми замінюємо реалізацію за замовчуванням, яка використовує `try_fold`, оскільки ця проста реалізація генерує менше IR LLVM і швидше компілюється.
            //
            //
            #[inline]
            fn all<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if !f(x) {
                        return false;
                    }
                }
                true
            }

            // Ми замінюємо реалізацію за замовчуванням, яка використовує `try_fold`, оскільки ця проста реалізація генерує менше IR LLVM і швидше компілюється.
            //
            //
            #[inline]
            fn any<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if f(x) {
                        return true;
                    }
                }
                false
            }

            // Ми замінюємо реалізацію за замовчуванням, яка використовує `try_fold`, оскільки ця проста реалізація генерує менше IR LLVM і швидше компілюється.
            //
            //
            #[inline]
            fn find<P>(&mut self, mut predicate: P) -> Option<Self::Item>
            where
                Self: Sized,
                P: FnMut(&Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if predicate(&x) {
                        return Some(x);
                    }
                }
                None
            }

            // Ми замінюємо реалізацію за замовчуванням, яка використовує `try_fold`, оскільки ця проста реалізація генерує менше IR LLVM і швидше компілюється.
            //
            //
            #[inline]
            fn find_map<B, F>(&mut self, mut f: F) -> Option<B>
            where
                Self: Sized,
                F: FnMut(Self::Item) -> Option<B>,
            {
                while let Some(x) = self.next() {
                    if let Some(y) = f(x) {
                        return Some(y);
                    }
                }
                None
            }

            // Ми замінюємо реалізацію за замовчуванням, яка використовує `try_fold`, оскільки ця проста реалізація генерує менше IR LLVM і швидше компілюється.
            // Крім того, `assume` уникає перевірки меж.
            //
            #[inline]
            #[rustc_inherit_overflow_checks]
            fn position<P>(&mut self, mut predicate: P) -> Option<usize> where
                Self: Sized,
                P: FnMut(Self::Item) -> bool,
            {
                let n = len!(self);
                let mut i = 0;
                while let Some(x) = self.next() {
                    if predicate(x) {
                        // БЕЗПЕКА: ми гарантовано знаходимося в межах інваріанта циклу:
                        // коли `i >= n`, `self.next()` повертає `None` і цикл обривається.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                    i += 1;
                }
                None
            }

            // Ми замінюємо реалізацію за замовчуванням, яка використовує `try_fold`, оскільки ця проста реалізація генерує менше IR LLVM і швидше компілюється.
            // Крім того, `assume` уникає перевірки меж.
            //
            #[inline]
            fn rposition<P>(&mut self, mut predicate: P) -> Option<usize> where
                P: FnMut(Self::Item) -> bool,
                Self: Sized + ExactSizeIterator + DoubleEndedIterator
            {
                let n = len!(self);
                let mut i = n;
                while let Some(x) = self.next_back() {
                    i -= 1;
                    if predicate(x) {
                        // БЕЗПЕКА: `i` повинен бути нижчим за `n`, оскільки він починається з `n`
                        // і лише зменшується.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                }
                None
            }

            #[doc(hidden)]
            unsafe fn __iterator_get_unchecked(&mut self, idx: usize) -> Self::Item {
                // БЕЗПЕКА: абонент повинен гарантувати, що `i` знаходиться в межах
                // базовий зріз, тому `i` не може переповнювати `isize`, а повернуті посилання гарантовано посилаються на елемент зрізу і, таким чином, гарантовано дійсні.
                //
                // Також зауважте, що абонент також гарантує, що нас більше ніколи не викликатимуть з тим самим індексом, і що ніякі інші методи, які отримуватимуть доступ до цього підскладу, не викликаються, тому дійсно, щоб повернуте посилання було змінним у випадку
                //
                // `IterMut`
                //
                //
                //
                //
                unsafe { & $( $mut_ )? * self.ptr.as_ptr().add(idx) }
            }

            $($extra)*
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> DoubleEndedIterator for $name<'a, T> {
            #[inline]
            fn next_back(&mut self) -> Option<$elem> {
                // може бути реалізований за допомогою фрагментів, але це дозволяє уникнути обмежень

                // БЕЗПЕКА: дзвінки `assume` безпечні, оскільки вказівник початку зрізу повинен бути ненульовим,
                // а зрізи над не ZST також повинні мати ненульовий вказівник кінця.
                // Виклик `next_back_unchecked!` безпечний, оскільки ми перевіряємо, чи спочатку ітератор порожній.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_back_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn nth_back(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // Цей ітератор порожній.
                    self.end = self.ptr.as_ptr();
                    return None;
                }
                // БЕЗПЕКА: Ми знаходимося в обмеженнях.`pre_dec_end` робить правильно, навіть для ZST.
                unsafe {
                    self.pre_dec_end(n as isize);
                    Some(next_back_unchecked!(self))
                }
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<T> FusedIterator for $name<'_, T> {}

        #[unstable(feature = "trusted_len", issue = "37572")]
        unsafe impl<T> TrustedLen for $name<'_, T> {}
    }
}

macro_rules! forward_iterator {
    ($name:ident: $elem:ident, $iter_of:ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, $elem, P> Iterator for $name<'a, $elem, P>
        where
            P: FnMut(&T) -> bool,
        {
            type Item = $iter_of;

            #[inline]
            fn next(&mut self) -> Option<$iter_of> {
                self.inner.next()
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                self.inner.size_hint()
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<'a, $elem, P> FusedIterator for $name<'a, $elem, P> where P: FnMut(&T) -> bool {}
    };
}