// Оригінальна реалізація взята з rust-memchr.
// Авторське право 2015 Ендрю Галлант, Блюс і Ніколас Кох

use crate::cmp;
use crate::mem;

const LO_U64: u64 = 0x0101010101010101;
const HI_U64: u64 = 0x8080808080808080;

// Використовуйте усічення.
const LO_USIZE: usize = LO_U64 as usize;
const HI_USIZE: usize = HI_U64 as usize;
const USIZE_BYTES: usize = mem::size_of::<usize>();

/// Повертає `true`, якщо `x` містить будь-який нульовий байт.
///
/// З *Matters Computational*, Дж. Арндт:
///
/// "Ідея полягає в тому, щоб відняти по одному з кожного байта, а потім шукати байти, де запозичення розповсюджується аж до найбільш значущих
///
/// bit."
#[inline]
fn contains_zero_byte(x: usize) -> bool {
    x.wrapping_sub(LO_USIZE) & !x & HI_USIZE != 0
}

#[cfg(target_pointer_width = "16")]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) << 8 | b as usize
}

#[cfg(not(target_pointer_width = "16"))]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) * (usize::MAX / 255)
}

/// Повертає перший індекс, що відповідає байту `x` у `text`.
#[inline]
pub fn memchr(x: u8, text: &[u8]) -> Option<usize> {
    // Швидкий шлях для невеликих скибочок
    if text.len() < 2 * USIZE_BYTES {
        return text.iter().position(|elt| *elt == x);
    }

    memchr_general_case(x, text)
}

fn memchr_general_case(x: u8, text: &[u8]) -> Option<usize> {
    // Скануйте одне байтове значення, читаючи одночасно два слова `usize`.
    //
    // Розділити `text` на три частини
    // - незрівнянна початкова частина перед першою адресою, вирівняною за текстом
    // - тіло, сканувати по 2 слова одночасно
    // - остання частина, що не перевищує 2 слова

    // пошук до вирівняної межі
    let len = text.len();
    let ptr = text.as_ptr();
    let mut offset = ptr.align_offset(USIZE_BYTES);

    if offset > 0 {
        offset = cmp::min(offset, len);
        if let Some(index) = text[..offset].iter().position(|elt| *elt == x) {
            return Some(index);
        }
    }

    // шукати текст тексту
    let repeated_x = repeat_byte(x);
    while offset <= len - 2 * USIZE_BYTES {
        // БЕЗПЕКА: предикат while гарантує відстань щонайменше 2 * usize_bytes
        // між зміщенням і кінцем зрізу.
        unsafe {
            let u = *(ptr.add(offset) as *const usize);
            let v = *(ptr.add(offset + USIZE_BYTES) as *const usize);

            // break, якщо є відповідний байт
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset += USIZE_BYTES * 2;
    }

    // Знайдіть байт після точки, коли цикл тіла зупинився.
    text[offset..].iter().position(|elt| *elt == x).map(|i| offset + i)
}

/// Повертає останній індекс, що відповідає байту `x` у `text`.
pub fn memrchr(x: u8, text: &[u8]) -> Option<usize> {
    // Скануйте одне байтове значення, читаючи одночасно два слова `usize`.
    //
    // Розділити `text` на три частини:
    // - незрівняний хвіст після адреси, вирівняної за останнім словом у тексті,
    // - тіло, відскановане по 2 слова за раз,
    // - перші залишені байти, розмір <2 слова.
    let len = text.len();
    let ptr = text.as_ptr();
    type Chunk = usize;

    let (min_aligned_offset, max_aligned_offset) = {
        // Ми називаємо це лише для того, щоб отримати довжину префікса та суфікса.
        // В середині ми завжди обробляємо відразу два шматки.
        // БЕЗПЕКА: перетворення `[u8]` на `[usize]` є безпечним, за винятком різниці розмірів, які обробляються `align_to`.
        //
        let (prefix, _, suffix) = unsafe { text.align_to::<(Chunk, Chunk)>() };
        (prefix.len(), len - suffix.len())
    };

    let mut offset = max_aligned_offset;
    if let Some(index) = text[offset..].iter().rposition(|elt| *elt == x) {
        return Some(offset + index);
    }

    // Шукайте тіло тексту, переконайтесь, що ми не перетинаємо min_aligned_offset.
    // зміщення завжди вирівнюється, тому достатньо лише тестування `>` і дозволяє уникнути можливого переповнення.
    //
    let repeated_x = repeat_byte(x);
    let chunk_bytes = mem::size_of::<Chunk>();

    while offset > min_aligned_offset {
        // БЕЗПЕКА: зміщення починається з len, suffix.len(), якщо воно більше ніж
        // min_aligned_offset (prefix.len()) залишкова відстань становить щонайменше 2 * chunk_bytes.
        unsafe {
            let u = *(ptr.offset(offset as isize - 2 * chunk_bytes as isize) as *const Chunk);
            let v = *(ptr.offset(offset as isize - chunk_bytes as isize) as *const Chunk);

            // Перерва, якщо є відповідний байт.
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset -= 2 * chunk_bytes;
    }

    // Знайдіть байт до точки, в якій цикл тіла зупинився.
    text[..offset].iter().rposition(|elt| *elt == x)
}