//! Операції на ASCII `[u8]`.

use crate::mem;

#[lang = "slice_u8"]
#[cfg(not(test))]
impl [u8] {
    /// Перевіряє, чи всі байти в цьому фрагменті знаходяться в діапазоні ASCII.
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        is_ascii(self)
    }

    /// Перевіряє, що два зрізи не відповідають регістру ASCII.
    ///
    /// Те саме, що і `to_ascii_lowercase(a) == to_ascii_lowercase(b)`, але без виділення та копіювання тимчасових даних.
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &[u8]) -> bool {
        self.len() == other.len() && self.iter().zip(other).all(|(a, b)| a.eq_ignore_ascii_case(b))
    }

    /// Перетворює цей зріз у його верхній регістр ASCII, еквівалентний на місці.
    ///
    /// Букви ASCII 'a'-'z' відображаються на 'A'-'Z', але листи, що не належать до ASCII, залишаються незмінними.
    ///
    /// Щоб повернути нове велике значення без зміни існуючого, використовуйте [`to_ascii_uppercase`].
    ///
    ///
    /// [`to_ascii_uppercase`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        for byte in self {
            byte.make_ascii_uppercase();
        }
    }

    /// Перетворює цей фрагмент на місце, еквівалентний ASCII, нижній регістр.
    ///
    /// Букви ASCII 'A'-'Z' відображаються на 'a'-'z', але листи, що не належать до ASCII, залишаються незмінними.
    ///
    /// Щоб повернути нове нижнє регістрове значення без зміни існуючого, використовуйте [`to_ascii_lowercase`].
    ///
    ///
    /// [`to_ascii_lowercase`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        for byte in self {
            byte.make_ascii_lowercase();
        }
    }
}

/// Повертає `true`, якщо будь-який байт у слові `v` не має значення (>=128).
/// Snarfed від `../str/mod.rs`, який робить щось подібне для перевірки utf8.
#[inline]
fn contains_nonascii(v: usize) -> bool {
    const NONASCII_MASK: usize = 0x80808080_80808080u64 as usize;
    (NONASCII_MASK & v) != 0
}

/// Оптимізований тест ASCII, який використовуватиме операції usize-at-a-time замість операцій byte-in-a-time (коли це можливо).
///
/// Алгоритм, який ми використовуємо тут, досить простий.Якщо `s` занадто короткий, ми просто перевіряємо кожен байт і закінчуємо з ним.В іншому випадку:
///
/// - Прочитайте перше слово з незрівнянним навантаженням.
/// - Вирівняйте вказівник, читайте наступні слова до кінця з вирівняними навантаженнями.
/// - Прочитайте останню версію `usize` з `s` з ненаправленим навантаженням.
///
/// Якщо будь-яке з цих навантажень дає щось, для чого `contains_nonascii` (above) повертає істину, тоді ми знаємо, що відповідь хибна.
///
///
///
#[inline]
fn is_ascii(s: &[u8]) -> bool {
    const USIZE_SIZE: usize = mem::size_of::<usize>();

    let len = s.len();
    let align_offset = s.as_ptr().align_offset(USIZE_SIZE);

    // Якщо ми нічого не отримаємо від реалізації "за раз", поверніться до скалярної петлі.
    //
    // Ми також робимо це для архітектур, де `size_of::<usize>()` недостатньо суміщений для `usize`, оскільки це дивний випадок edge.
    //
    //
    if len < USIZE_SIZE || len < align_offset || USIZE_SIZE < mem::align_of::<usize>() {
        return s.iter().all(|b| b.is_ascii());
    }

    // Ми завжди читаємо перше слово незрівнянним, що означає, що `align_offset` є
    // 0, ми знову прочитали б те саме значення для вирівняного читання.
    let offset_to_aligned = if align_offset == 0 { USIZE_SIZE } else { align_offset };

    let start = s.as_ptr();
    // БЕЗПЕКА: Ми перевіряємо `len < USIZE_SIZE` вище.
    let first_word = unsafe { (start as *const usize).read_unaligned() };

    if contains_nonascii(first_word) {
        return false;
    }
    // Ми перевірили це вище, дещо неявно.
    // Зверніть увагу, що `offset_to_aligned`-це або `align_offset`, або `USIZE_SIZE`, обидва явно зазначені вище.
    //
    debug_assert!(offset_to_aligned <= len);

    // БЕЗПЕКА: word_ptr-це (правильно вирівняний) розмір ptr, який ми використовуємо для читання
    // середній шматок скибочки.
    let mut word_ptr = unsafe { start.add(offset_to_aligned) as *const usize };

    // `byte_pos` - індекс байтів `word_ptr`, який використовується для перевірки кінця циклу.
    let mut byte_pos = offset_to_aligned;

    // Перевірка параної на вирівнювання, оскільки ми збираємося зробити купу незрівняних навантажень.
    // На практиці це може бути неможливим, якщо заборонити помилку в `align_offset`.
    //
    debug_assert_eq!((word_ptr as usize) % mem::align_of::<usize>(), 0);

    // Читайте наступні слова до останнього вирівняного слова, за винятком останнього вирівняного слова, яке само собою буде зроблено при перевірці хвоста пізніше, щоб переконатися, що хвіст завжди є не більше `usize` до додаткового branch `byte_pos == len`.
    //
    //
    while byte_pos < len - USIZE_SIZE {
        debug_assert!(
            // Перевіряйте розумність, щоб прочитане було в межах
            (word_ptr as usize + USIZE_SIZE) <= (start.wrapping_add(len) as usize) &&
            // І що наші припущення щодо `byte_pos` справедливі.
            (word_ptr as usize) - (start as usize) == byte_pos
        );

        // БЕЗПЕКА: Ми знаємо, що `word_ptr` правильно вирівняний (через
        // `align_offset`), і ми знаємо, що у нас достатньо байтів між `word_ptr` і кінцем
        let word = unsafe { word_ptr.read() };
        if contains_nonascii(word) {
            return false;
        }

        byte_pos += USIZE_SIZE;
        // БЕЗПЕКА: Ми знаємо, що `byte_pos <= len - USIZE_SIZE`, що означає, що
        // після цього `add`, `word_ptr` буде щонайбільше одним минулим.
        word_ptr = unsafe { word_ptr.add(1) };
    }

    // Перевірка обґрунтованості, щоб переконатися, що насправді залишився лише один `usize`.
    // Це має бути гарантоване нашими умовами циклу.
    debug_assert!(byte_pos <= len && len - byte_pos <= USIZE_SIZE);

    // БЕЗПЕКА: Це залежить від `len >= USIZE_SIZE`, який ми перевіряємо на початку.
    let last_word = unsafe { (start.add(len - USIZE_SIZE) as *const usize).read_unaligned() };

    !contains_nonascii(last_word)
}