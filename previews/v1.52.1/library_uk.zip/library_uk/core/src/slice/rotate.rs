// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// Обертає діапазон `[mid-left, mid+right)` таким чином, що елемент у `mid` стає першим елементом.Еквівалентно, обертає елементи діапазону `left` ліворуч або елементи `right` праворуч.
///
/// # Safety
///
/// Вказаний діапазон повинен бути дійсним для читання та письма.
///
/// # Algorithm
///
/// Алгоритм 1 використовується для малих значень `left + right` або для великих `T`.
/// Елементи переміщуються у свої кінцеві позиції по черзі, починаючи з `mid - left` і просуваючись за кроками `right` за модулем `left + right`, так що потрібен лише один тимчасовий.
/// Зрештою, ми повертаємось до `mid - left`.
/// Однак, якщо `gcd(left + right, right)` не 1, наведені вище кроки пропускають елементи.
/// Наприклад:
///
/// ```text
/// left = 10, right = 6
/// the `^` indicates an element in its final place
/// 6 7 8 9 10 11 12 13 14 15 . 0 1 2 3 4 5
/// after using one step of the above algorithm (The X will be overwritten at the end of the round,
/// and 12 is stored in a temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 2 3 4 5
///               ^
/// after using another step (now 2 is in the temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///               ^                 ^
/// after the third step (the steps wrap around, and 8 is in the temporary):
/// X 7 2 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///     ^         ^                 ^
/// after 7 more steps, the round ends with the temporary 0 getting put in the X:
/// 0 7 2 9 4 11 6 13 8 15 . 10 1 12 3 14 5
/// ^   ^   ^    ^    ^       ^    ^    ^
/// ```
///
/// На щастя, кількість пропущених елементів між завершеними елементами завжди дорівнює, тому ми можемо просто компенсувати нашу вихідну позицію і зробити більше раундів (загальна кількість раундів-`gcd(left + right, right)` value).
///
/// Кінцевим результатом є те, що всі елементи доопрацьовуються один раз і лише один раз.
///
/// Алгоритм 2 використовується, якщо `left + right` великий, але `min(left, right)` досить малий, щоб поміститися в буфер стека.
/// Елементи `min(left, right)` копіюються в буфер, `memmove` застосовується до інших, а елементи, що знаходяться в буфері, переміщуються назад у отвір на протилежній стороні, звідки вони виникли.
///
/// Алгоритми, які можна векторизувати, перевершують вищезазначені, коли `left + right` стає досить великим.
/// Алгоритм 1 можна векторизувати, розбиваючи і виконуючи багато раундів одночасно, але в середньому буває замало раундів, поки `left + right` не стане величезним, і найгірший випадок одного раунду завжди є.
/// Натомість алгоритм 3 використовує багаторазовий обмін елементами `min(left, right)`, поки не залишиться менша проблема обертання.
///
/// ```text
/// left = 11, right = 4
/// [4 5 6 7 8 9 10 11 12 13 14 . 0 1 2 3]
///                  ^  ^  ^  ^   ^ ^ ^ ^ swapping the right most elements with elements to the left
/// [4 5 6 7 8 9 10 . 0 1 2 3] 11 12 13 14
///        ^ ^ ^  ^   ^ ^ ^ ^ swapping these
/// [4 5 6 . 0 1 2 3] 7 8 9 10 11 12 13 14
/// we cannot swap any more, but a smaller rotation problem is left to solve
/// ```
/// коли `left < right` підміна відбувається замість цього зліва.
///
///
///
///
///
pub unsafe fn ptr_rotate<T>(mut left: usize, mut mid: *mut T, mut right: usize) {
    type BufType = [usize; 32];
    if mem::size_of::<T>() == 0 {
        return;
    }
    loop {
        // N.B. наведені нижче алгоритми можуть вийти з ладу, якщо ці випадки не перевірити
        if (right == 0) || (left == 0) {
            return;
        }
        if (left + right < 24) || (mem::size_of::<T>() > mem::size_of::<[usize; 4]>()) {
            // Алгоритм 1 Мікровимірювальні показники вказують на те, що середня продуктивність для випадкових зрушень є кращою аж до приблизно `left + right == 32`, але найгірший показник навіть не перевищує 16.
            // 24 було обрано середнім кроком.
            // Якщо розмір `T` перевищує 4 `usize`s, цей алгоритм також перевершує інші алгоритми.
            //
            //
            let x = unsafe { mid.sub(left) };
            // початок першого туру
            let mut tmp: T = unsafe { x.read() };
            let mut i = right;
            // `gcd` можна знайти заздалегідь, обчисливши `gcd(left + right, right)`, але швидше зробити один цикл, який обчислює gcd як побічний ефект, а потім виконувати решту частини
            //
            //
            let mut gcd = right;
            // тести показують, що швидше поміняти місцями тимчасові замість того, щоб прочитати один тимчасовий раз, скопіювати назад і потім написати цей тимчасовий в самому кінці.
            // Можливо, це пов`язано з тим, що обмін або заміна тимчасових пристроїв використовує лише одну адресу пам`яті в циклі, замість того, щоб керувати двома.
            //
            //
            loop {
                tmp = unsafe { x.add(i).replace(tmp) };
                // замість збільшення `i`, а потім перевірки, чи не виходить воно за межі, ми перевіряємо, чи не вийде `i` за межі наступного приросту.
                // Це запобігає будь-якому загортанню покажчиків або `usize`.
                //
                if i >= left {
                    i -= left;
                    if i == 0 {
                        // кінець першого туру
                        unsafe { x.write(tmp) };
                        break;
                    }
                    // ця умовна умова повинна бути тут, якщо `left + right >= 15`
                    if i < gcd {
                        gcd = i;
                    }
                } else {
                    i += right;
                }
            }
            // закінчити шматок ще кількома раундами
            for start in 1..gcd {
                tmp = unsafe { x.add(start).read() };
                i = start + right;
                loop {
                    tmp = unsafe { x.add(i).replace(tmp) };
                    if i >= left {
                        i -= left;
                        if i == start {
                            unsafe { x.add(start).write(tmp) };
                            break;
                        }
                    } else {
                        i += right;
                    }
                }
            }
            return;
        // `T` не є типом нульового розміру, тому його можна ділити на його розмір.
        } else if cmp::min(left, right) <= mem::size_of::<BufType>() / mem::size_of::<T>() {
            // Алгоритм 2 `[T; 0]` тут має забезпечити відповідне вирівнювання для T
            //
            let mut rawarray = MaybeUninit::<(BufType, [T; 0])>::uninit();
            let buf = rawarray.as_mut_ptr() as *mut T;
            let dim = unsafe { mid.sub(left).add(right) };
            if left <= right {
                unsafe {
                    ptr::copy_nonoverlapping(mid.sub(left), buf, left);
                    ptr::copy(mid, mid.sub(left), right);
                    ptr::copy_nonoverlapping(buf, dim, left);
                }
            } else {
                unsafe {
                    ptr::copy_nonoverlapping(mid, buf, right);
                    ptr::copy(mid.sub(left), dim, left);
                    ptr::copy_nonoverlapping(buf, mid.sub(left), right);
                }
            }
            return;
        } else if left >= right {
            // Алгоритм 3 Існує альтернативний спосіб підкачки, який передбачає пошук місця останнього підкачки цього алгоритму, а також обмін за допомогою цього останнього шматка замість заміни сусідніх шматок, як це робить цей алгоритм, але цей спосіб все-таки швидший.
            //
            //
            //
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(right), mid, right);
                    mid = mid.sub(right);
                }
                left -= right;
                if left < right {
                    break;
                }
            }
        } else {
            // Алгоритм 3, `left < right`
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(left), mid, left);
                    mid = mid.add(left);
                }
                right -= left;
                if right < left {
                    break;
                }
            }
        }
    }
}