//! Сортування зрізів
//!
//! Цей модуль містить алгоритм сортування, заснований на швидкому сортуванні Орсона Пітерса, опублікованому за адресою: <https://github.com/orlp/pdqsort>
//!
//!
//! Нестабільне сортування сумісне з libcore, оскільки воно не виділяє пам'ять, на відміну від нашої стабільної реалізації сортування.
//!

// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// При скиданні копіює з `src` у `dest`.
struct CopyOnDrop<T> {
    src: *mut T,
    dest: *mut T,
}

impl<T> Drop for CopyOnDrop<T> {
    fn drop(&mut self) {
        // БЕЗПЕКА: Це допоміжний клас.
        //          Будь ласка, зверніться до його використання для коректності.
        //          А саме, треба бути впевненим, що `src` та `dst` не перекриваються, як вимагає `ptr::copy_nonoverlapping`.
        unsafe {
            ptr::copy_nonoverlapping(self.src, self.dest, 1);
        }
    }
}

/// Зміщує перший елемент праворуч, поки він не зустріне більший або рівний елемент.
fn shift_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // БЕЗПЕКА: Небезпечні операції, наведені нижче, передбачають індексацію без обмеженої перевірки (`get_unchecked` та `get_unchecked_mut`)
    // та копіювання пам'яті (`ptr::copy_nonoverlapping`).
    //
    // а.Індексація:
    //  1. Ми перевірили розмір масиву>> 2.
    //  2. Вся індексація, яку ми будемо робити, завжди складає не більше {0 <= index < len}.
    //
    // b.Копіювання пам'яті
    //  1. Ми отримуємо вказівки на посилання, які гарантовано дійсні.
    //  2. Вони не можуть перекриватися, оскільки ми отримуємо вказівники на індекси різниці зрізу.
    //     А саме `i` та `i-1`.
    //  3. Якщо зріз правильно вирівняний, елементи правильно вирівняні.
    //     Абонент несе відповідальність за те, щоб зріз був правильно вирівняний.
    //
    // Дивіться коментарі нижче для отримання додаткової інформації.
    unsafe {
        // Якщо перші два елементи не працюють ...
        if len >= 2 && is_less(v.get_unchecked(1), v.get_unchecked(0)) {
            // Прочитайте перший елемент у змінну, виділену стеком.
            // Якщо наступна операція порівняння panics, `hole` буде скинуто і автоматично запише елемент назад у зріз.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(0)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(1) };
            ptr::copy_nonoverlapping(v.get_unchecked(1), v.get_unchecked_mut(0), 1);

            for i in 2..len {
                if !is_less(v.get_unchecked(i), &*tmp) {
                    break;
                }

                // Перемістіть `i`-й елемент на одне місце вліво, змістивши таким чином отвір вправо.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i - 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` потрапляє і таким чином копіює `tmp` у залишок отвору в `v`.
        }
    }
}

/// Зміщує останній елемент вліво, поки він не зустріне менший або рівний елемент.
fn shift_tail<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // БЕЗПЕКА: Небезпечні операції, наведені нижче, передбачають індексацію без обмеженої перевірки (`get_unchecked` та `get_unchecked_mut`)
    // та копіювання пам'яті (`ptr::copy_nonoverlapping`).
    //
    // а.Індексація:
    //  1. Ми перевірили розмір масиву>> 2.
    //  2. Вся індексація, яку ми будемо робити, завжди складає не більше `0 <= index < len-1`.
    //
    // b.Копіювання пам'яті
    //  1. Ми отримуємо вказівки на посилання, які гарантовано дійсні.
    //  2. Вони не можуть перекриватися, оскільки ми отримуємо вказівники на індекси різниці зрізу.
    //     А саме `i` та `i+1`.
    //  3. Якщо зріз правильно вирівняний, елементи правильно вирівняні.
    //     Абонент несе відповідальність за те, щоб зріз був правильно вирівняний.
    //
    // Дивіться коментарі нижче для отримання додаткової інформації.
    unsafe {
        // Якщо два останні елементи не працюють ...
        if len >= 2 && is_less(v.get_unchecked(len - 1), v.get_unchecked(len - 2)) {
            // Зчитайте останній елемент у змінну, виділену стеком.
            // Якщо наступна операція порівняння panics, `hole` буде скинуто і автоматично запише елемент назад у зріз.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(len - 1)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(len - 2) };
            ptr::copy_nonoverlapping(v.get_unchecked(len - 2), v.get_unchecked_mut(len - 1), 1);

            for i in (0..len - 2).rev() {
                if !is_less(&*tmp, v.get_unchecked(i)) {
                    break;
                }

                // Перемістіть `i`-й елемент на одне місце вправо, змістивши таким чином отвір вліво.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i + 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` потрапляє і таким чином копіює `tmp` у залишок отвору в `v`.
        }
    }
}

/// Частково сортує фрагмент, переміщуючи кілька невпорядкованих елементів.
///
/// Повертає `true`, якщо фрагмент відсортовано в кінці.Ця функція є *O*(*n*) у гіршому випадку.
#[cold]
fn partial_insertion_sort<T, F>(v: &mut [T], is_less: &mut F) -> bool
where
    F: FnMut(&T, &T) -> bool,
{
    // Максимальна кількість сусідніх непрацюючих пар, які будуть зміщені.
    const MAX_STEPS: usize = 5;
    // Якщо зріз коротший за цей, не зміщуйте жодних елементів.
    const SHORTEST_SHIFTING: usize = 50;

    let len = v.len();
    let mut i = 1;

    for _ in 0..MAX_STEPS {
        // БЕЗПЕКА: Ми вже явно проводили прив'язку перевірки з `i < len`.
        // Вся наша подальша індексація знаходиться лише в діапазоні `0 <= index < len`
        unsafe {
            // Знайдіть наступну пару сусідніх невпорядкованих елементів.
            while i < len && !is_less(v.get_unchecked(i), v.get_unchecked(i - 1)) {
                i += 1;
            }
        }

        // Ми закінчили?
        if i == len {
            return true;
        }

        // Не зміщуйте елементи на коротких масивах, що має витрати на продуктивність.
        if len < SHORTEST_SHIFTING {
            return false;
        }

        // Поміняйте місцями знайдену пару елементів.Це приводить їх у правильний порядок.
        v.swap(i - 1, i);

        // Зсуньте менший елемент вліво.
        shift_tail(&mut v[..i], is_less);
        // Зсуньте більший елемент вправо.
        shift_head(&mut v[i..], is_less);
    }

    // Не вдалося відсортувати фрагмент за обмежену кількість кроків.
    false
}

/// Сортує зріз за допомогою вставки, яка є *O*(*n*^ 2) у гіршому випадку.
fn insertion_sort<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    for i in 1..v.len() {
        shift_tail(&mut v[..i + 1], is_less);
    }
}

/// Сортує `v`, використовуючи купірування, що гарантує *O*(*n*\*log(* n*)) у гіршому випадку.
#[cold]
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub fn heapsort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Ця двійкова купа поважає інваріант `parent >= child`.
    let mut sift_down = |v: &mut [T], mut node| {
        loop {
            // Діти `node`:
            let left = 2 * node + 1;
            let right = 2 * node + 2;

            // Виберіть більшу дитину.
            let greater =
                if right < v.len() && is_less(&v[left], &v[right]) { right } else { left };

            // Зупиніть, якщо інваріант виконується при `node`.
            if greater >= v.len() || !is_less(&v[node], &v[greater]) {
                break;
            }

            // Поміняйте `node` старшою дитиною, перейдіть на одну сходинку вниз і продовжуйте просівати.
            v.swap(node, greater);
            node = greater;
        }
    };

    // Побудуйте купу за лінійний час.
    for i in (0..v.len() / 2).rev() {
        sift_down(v, i);
    }

    // Виведіть максимальні елементи з купи.
    for i in (1..v.len()).rev() {
        v.swap(0, i);
        sift_down(&mut v[..i], 0);
    }
}

/// Розбиває `v` на елементи, менші за `pivot`, за якими слідують елементи, більші або рівні `pivot`.
///
///
/// Повертає кількість елементів, менших за `pivot`.
///
/// Розбиття виконується блок за блоком з метою мінімізації витрат на операції розгалуження.
/// Ця ідея представлена в роботі [BlockQuicksort][pdf].
///
/// [pdf]: http://drops.dagstuhl.de/opus/volltexte/2016/6389/pdf/LIPIcs-ESA-2016-38.pdf
fn partition_in_blocks<T, F>(v: &mut [T], pivot: &T, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // Кількість елементів у типовому блоці.
    const BLOCK: usize = 128;

    // Алгоритм розділення повторює наступні кроки до завершення:
    //
    // 1. Проведіть блок з лівого боку, щоб ідентифікувати елементи, більші або рівні до стержня.
    // 2. Проведіть блок з правого боку, щоб визначити елементи, менші за опору.
    // 3. Обміняйтесь ідентифікованими елементами між лівою та правою сторонами.
    //
    // Для блоку елементів ми зберігаємо такі змінні:
    //
    // 1. `block` - Кількість елементів у блоці.
    // 2. `start` - Почніть вказівник на масив `offsets`.
    // 3. `end` - Кінцевий вказівник на масив `offsets`.
    // 4. `offset, Індекси невпорядкованих елементів всередині блоку.

    // Поточний блок з лівого боку (від `l` до `l.add(block_l)`).
    let mut l = v.as_mut_ptr();
    let mut block_l = BLOCK;
    let mut start_l = ptr::null_mut();
    let mut end_l = ptr::null_mut();
    let mut offsets_l = [MaybeUninit::<u8>::uninit(); BLOCK];

    // Поточний блок з правого боку (від `r.sub(block_r)` to `r`).
    // БЕЗПЕКА: У документації до .add() конкретно зазначено, що `vec.as_ptr().add(vec.len())` завжди в безпеці`
    let mut r = unsafe { l.add(v.len()) };
    let mut block_r = BLOCK;
    let mut start_r = ptr::null_mut();
    let mut end_r = ptr::null_mut();
    let mut offsets_r = [MaybeUninit::<u8>::uninit(); BLOCK];

    // FIXME: Коли ми отримаємо VLA, спробуйте скоріше створити один масив довжиною `min(v.len(), 2 * BLOCK) `
    // ніж два масиви фіксованого розміру довжиною `BLOCK`.VLA можуть бути більш ефективними в кеші.

    // Повертає кількість елементів між покажчиками `l` (inclusive) та `r` (exclusive).
    fn width<T>(l: *mut T, r: *mut T) -> usize {
        assert!(mem::size_of::<T>() > 0);
        (r as usize - l as usize) / mem::size_of::<T>()
    }

    loop {
        // Ми закінчили з секціонуванням блок-за-блоком, коли `l` і `r` наближаються дуже близько.
        // Потім ми виконуємо деякі виправлення, щоб розділити інші елементи між ними.
        let is_done = width(l, r) <= 2 * BLOCK;

        if is_done {
            // Кількість елементів, що залишилися (все ще не порівняно зі стержнем).
            let mut rem = width(l, r);
            if start_l < end_l || start_r < end_r {
                rem -= BLOCK;
            }

            // Відрегулюйте розміри блоків так, щоб лівий і правий блок не перекривались, але були ідеально вирівняні, щоб покрити весь залишок, що залишився.
            //
            if start_l < end_l {
                block_r = rem;
            } else if start_r < end_r {
                block_l = rem;
            } else {
                block_l = rem / 2;
                block_r = rem - block_l;
            }
            debug_assert!(block_l <= BLOCK && block_r <= BLOCK);
            debug_assert!(width(l, r) == block_l + block_r);
        }

        if start_l == end_l {
            // Простежте елементи `block_l` з лівого боку.
            start_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            end_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            let mut elem = l;

            for i in 0..block_l {
                // БЕЗПЕКА: Наведені нижче дії щодо небезпеки стосуються використання `offset`.
                //         Відповідно до умов, які вимагає функція, ми їх задовольняємо, оскільки:
                //         1. `offsets_l` виділяється стеком, і, таким чином, вважається окремим виділеним об`єктом.
                //         2. Функція `is_less` повертає `bool`.
                //            Трансляція `bool` ніколи не перевершить `isize`.
                //         3. Ми гарантували, що `block_l` буде `<= BLOCK`.
                //            Крім того, `end_l` спочатку встановлювався як початковий покажчик `offsets_`, який був оголошений у стеку.
                //            Таким чином, ми знаємо, що навіть у найгіршому випадку (усі виклики `is_less` повертають значення false) ми будемо мати щонайбільше 1 байт, що пройде кінець.
                //        Ще одна небезпечна операція тут-перенаправлення на `elem`.
                //        Однак спочатку `elem` був початковим вказівником на зріз, який завжди є дійсним.
                unsafe {
                    // Безгалузеве порівняння.
                    *end_l = i as u8;
                    end_l = end_l.offset(!is_less(&*elem, pivot) as isize);
                    elem = elem.offset(1);
                }
            }
        }

        if start_r == end_r {
            // Проведіть елементи `block_r` з правого боку.
            start_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            end_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            let mut elem = r;

            for i in 0..block_r {
                // БЕЗПЕКА: Наведені нижче дії щодо небезпеки стосуються використання `offset`.
                //         Відповідно до умов, які вимагає функція, ми їх задовольняємо, оскільки:
                //         1. `offsets_r` виділяється стеком, і, таким чином, вважається окремим виділеним об`єктом.
                //         2. Функція `is_less` повертає `bool`.
                //            Трансляція `bool` ніколи не перевершить `isize`.
                //         3. Ми гарантували, що `block_r` буде `<= BLOCK`.
                //            Плюс, `end_r` спочатку встановлювався як початковий покажчик `offsets_`, який був оголошений у стеку.
                //            Таким чином, ми знаємо, що навіть у найгіршому випадку (усі виклики `is_less` повертають істину) ми будемо мати щонайбільше 1 байт, що пройде кінець.
                //        Ще одна небезпечна операція тут-перенаправлення на `elem`.
                //        Однак `elem` спочатку був `1 *sizeof(T)` після кінця, і ми зменшуємо його на `1* sizeof(T)` перед тим, як отримати до нього доступ.
                //        Крім того, було встановлено, що `block_r` менше `BLOCK`, і, отже, `elem` буде вказувати щонайбільше на початок фрагмента.
                unsafe {
                    // Безгалузеве порівняння.
                    elem = elem.offset(-1);
                    *end_r = i as u8;
                    end_r = end_r.offset(is_less(&*elem, pivot) as isize);
                }
            }
        }

        // Кількість невпорядкованих елементів для обміну між лівою та правою сторонами.
        let count = cmp::min(width(start_l, end_l), width(start_r, end_r));

        if count > 0 {
            macro_rules! left {
                () => {
                    l.offset(*start_l as isize)
                };
            }
            macro_rules! right {
                () => {
                    r.offset(-(*start_r as isize) - 1)
                };
            }

            // Замість того, щоб міняти місцями одну пару, ефективніше виконувати циклічну перестановку.
            // Це не є суто еквівалентом обміну, але дає подібний результат, використовуючи менше операцій пам'яті.
            //
            unsafe {
                let tmp = ptr::read(left!());
                ptr::copy_nonoverlapping(right!(), left!(), 1);

                for _ in 1..count {
                    start_l = start_l.offset(1);
                    ptr::copy_nonoverlapping(left!(), right!(), 1);
                    start_r = start_r.offset(1);
                    ptr::copy_nonoverlapping(right!(), left!(), 1);
                }

                ptr::copy_nonoverlapping(&tmp, right!(), 1);
                mem::forget(tmp);
                start_l = start_l.offset(1);
                start_r = start_r.offset(1);
            }
        }

        if start_l == end_l {
            // Усі непрацюючі елементи в лівому блоці були переміщені.Перехід до наступного блоку.
            l = unsafe { l.offset(block_l as isize) };
        }

        if start_r == end_r {
            // Усі неправильні елементи в правому блоці були переміщені.Перехід до попереднього блоку.
            r = unsafe { r.offset(-(block_r as isize)) };
        }

        if is_done {
            break;
        }
    }

    // Зараз залишається щонайбільше один блок (лівий чи правий) з невпорядкованими елементами, які потрібно перемістити.
    // Такі елементи, що залишились, можна просто перемістити до кінця в межах їх блоку.
    //

    if start_l < end_l {
        // Залишається лівий блок.
        // Перемістіть його інші непрацюючі елементи в крайній правий кут.
        debug_assert_eq!(width(l, r), block_l);
        while start_l < end_l {
            unsafe {
                end_l = end_l.offset(-1);
                ptr::swap(l.offset(*end_l as isize), r.offset(-1));
                r = r.offset(-1);
            }
        }
        width(v.as_mut_ptr(), r)
    } else if start_r < end_r {
        // Правий блок залишається.
        // Перемістіть його залишені в порядку елементи в крайній лівий кут.
        debug_assert_eq!(width(l, r), block_r);
        while start_r < end_r {
            unsafe {
                end_r = end_r.offset(-1);
                ptr::swap(l, r.offset(-(*end_r as isize) - 1));
                l = l.offset(1);
            }
        }
        width(v.as_mut_ptr(), l)
    } else {
        // Більше нічого робити, ми закінчили.
        width(v.as_mut_ptr(), l)
    }
}

/// Розбиває `v` на елементи, менші за `v[pivot]`, за якими слідують елементи, більші або рівні `v[pivot]`.
///
///
/// Повертає кортеж із:
///
/// 1. Кількість елементів менше `v[pivot]`.
/// 2. Правда, якщо `v` вже був розділений.
fn partition<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    let (mid, was_partitioned) = {
        // Помістіть шарнір на початку зрізу.
        v.swap(0, pivot);
        let (pivot, v) = v.split_at_mut(1);
        let pivot = &mut pivot[0];

        // Зчитуйте півот у змінну, виділену стеком, для підвищення ефективності.
        // Якщо буде виконана наступна операція порівняння panics, опорна точка буде автоматично записана назад у зріз.
        let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
        let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
        let pivot = &*tmp;

        // Знайдіть першу пару невпорядкованих елементів.
        let mut l = 0;
        let mut r = v.len();

        // БЕЗПЕКА: Наведена нижче небезпека передбачає індексацію масиву.
        // Перший: ми вже проводимо перевірку меж тут із `l < r`.
        // Для другого: спочатку у нас є `l == 0` та `r == v.len()`, і ми перевіряли `l < r` під час кожної операції індексації.
        //                     Звідси ми знаємо, що `r` повинен бути принаймні `r == l`, який був визнаний дійсним з першого.
        unsafe {
            // Знайдіть перший елемент, більший або дорівнює шарніру.
            while l < r && is_less(v.get_unchecked(l), pivot) {
                l += 1;
            }

            // Знайдіть останній елемент, менший за шарнір.
            while l < r && !is_less(v.get_unchecked(r - 1), pivot) {
                r -= 1;
            }
        }

        (l + partition_in_blocks(&mut v[l..r], pivot, is_less), l >= r)

        // `_pivot_guard` виходить за межі області дії і записує півот (який є змінною, виділеною стеком) назад у зріз, де він був спочатку.
        // Цей крок є критично важливим для забезпечення безпеки!
        //
    };

    // Помістіть шарнір між двома перегородками.
    v.swap(0, mid);

    (mid, was_partitioned)
}

/// Розбиває `v` на елементи, рівні `v[pivot]`, за якими слідують елементи, більші за `v[pivot]`.
///
/// Повертає кількість елементів, що дорівнює опорі.
/// Передбачається, що `v` не містить елементів, менших за опору.
fn partition_equal<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // Помістіть шарнір на початку зрізу.
    v.swap(0, pivot);
    let (pivot, v) = v.split_at_mut(1);
    let pivot = &mut pivot[0];

    // Зчитуйте півот у змінну, виділену стеком, для підвищення ефективності.
    // Якщо буде виконана наступна операція порівняння panics, опорна точка буде автоматично записана назад у зріз.
    // БЕЗПЕКА: Вказівник тут дійсний, оскільки він отриманий із посилання на фрагмент.
    let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
    let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
    let pivot = &*tmp;

    // Тепер розділіть фрагмент.
    let mut l = 0;
    let mut r = v.len();
    loop {
        // БЕЗПЕКА: Наведена нижче небезпека передбачає індексацію масиву.
        // Перший: ми вже проводимо перевірку меж тут із `l < r`.
        // Для другого: спочатку у нас є `l == 0` та `r == v.len()`, і ми перевіряли `l < r` під час кожної операції індексації.
        //                     Звідси ми знаємо, що `r` повинен бути принаймні `r == l`, який був визнаний дійсним з першого.
        unsafe {
            // Знайдіть перший елемент, більший за опору.
            while l < r && !is_less(pivot, v.get_unchecked(l)) {
                l += 1;
            }

            // Знайдіть останній елемент, що дорівнює опорі.
            while l < r && is_less(pivot, v.get_unchecked(r - 1)) {
                r -= 1;
            }

            // Ми закінчили?
            if l >= r {
                break;
            }

            // Поміняйте місцями знайдену пару непрацюючих елементів.
            r -= 1;
            ptr::swap(v.get_unchecked_mut(l), v.get_unchecked_mut(r));
            l += 1;
        }
    }

    // Ми знайшли елементи `l`, що дорівнюють опорі.Додайте 1 до обліку самого стрижня.
    l + 1

    // `_pivot_guard` виходить за межі області дії і записує півот (який є змінною, виділеною стеком) назад у зріз, де він був спочатку.
    // Цей крок є критично важливим для забезпечення безпеки!
}

/// Розсіює деякі елементи навколо, намагаючись розбити шаблони, які можуть спричинити незбалансовані розділи у швидкій сортуванні.
///
#[cold]
fn break_patterns<T>(v: &mut [T]) {
    let len = v.len();
    if len >= 8 {
        // Генератор псевдовипадкових чисел із статті "Xorshift RNGs" Джорджа Марсальї.
        let mut random = len as u32;
        let mut gen_u32 = || {
            random ^= random << 13;
            random ^= random >> 17;
            random ^= random << 5;
            random
        };
        let mut gen_usize = || {
            if usize::BITS <= 32 {
                gen_u32() as usize
            } else {
                (((gen_u32() as u64) << 32) | (gen_u32() as u64)) as usize
            }
        };

        // Візьміть випадкові числа за модулем цього числа.
        // Це число відповідає `usize`, оскільки `len` не перевищує `isize::MAX`.
        let modulus = len.next_power_of_two();

        // Деякі опорні кандидати будуть знаходитися поблизу цього індексу.Давайте їх рандомізувати.
        let pos = len / 4 * 2;

        for i in 0..3 {
            // Сформувати випадкове число за модулем `len`.
            // Однак, щоб уникнути дорогих операцій, спочатку ми приймаємо його за модулем в два рази, а потім зменшуємо на `len`, поки він не входить в діапазон `[0, len - 1]`.
            //
            let mut other = gen_usize() & (modulus - 1);

            // `other` гарантовано менше ніж `2 * len`.
            if other >= len {
                other -= len;
            }

            v.swap(pos - 1 + i, other);
        }
    }
}

/// Вибирає шарнір в `v` і повертає індекс і `true`, якщо зріз, ймовірно, вже відсортований.
///
/// Елементи `v` можуть бути впорядковані в процесі.
fn choose_pivot<T, F>(v: &mut [T], is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    // Мінімальна довжина для вибору методу медіани медіан.
    // Коротші зрізи використовують простий метод середнього з трьох.
    const SHORTEST_MEDIAN_OF_MEDIANS: usize = 50;
    // Максимальна кількість свопів, які можна виконати за цією функцією.
    const MAX_SWAPS: usize = 4 * 3;

    let len = v.len();

    // Три індекси, поблизу яких ми збираємось вибрати опору.
    let mut a = len / 4 * 1;
    let mut b = len / 4 * 2;
    let mut c = len / 4 * 3;

    // Підраховує загальну кількість свопів, які ми збираємось виконати під час сортування індексів.
    let mut swaps = 0;

    if len >= 8 {
        // Змінює індекси так, що `v[a] <= v[b]`.
        let mut sort2 = |a: &mut usize, b: &mut usize| unsafe {
            if is_less(v.get_unchecked(*b), v.get_unchecked(*a)) {
                ptr::swap(a, b);
                swaps += 1;
            }
        };

        // Змінює індекси так, що `v[a] <= v[b] <= v[c]`.
        let mut sort3 = |a: &mut usize, b: &mut usize, c: &mut usize| {
            sort2(a, b);
            sort2(b, c);
            sort2(a, b);
        };

        if len >= SHORTEST_MEDIAN_OF_MEDIANS {
            // Знаходить медіану `v[a - 1], v[a], v[a + 1]` і зберігає індекс у `a`.
            let mut sort_adjacent = |a: &mut usize| {
                let tmp = *a;
                sort3(&mut (tmp - 1), a, &mut (tmp + 1));
            };

            // Знайдіть медіани в околицях `a`, `b` та `c`.
            sort_adjacent(&mut a);
            sort_adjacent(&mut b);
            sort_adjacent(&mut c);
        }

        // Знайдіть медіану серед `a`, `b` та `c`.
        sort3(&mut a, &mut b, &mut c);
    }

    if swaps < MAX_SWAPS {
        (b, swaps == 0)
    } else {
        // Виконано максимальну кількість обмінів.
        // Швидше за все, зріз спадає або здебільшого спадає, тому реверс допоможе швидше сортувати його.
        v.reverse();
        (len - 1 - b, true)
    }
}

/// Сортує `v` рекурсивно.
///
/// Якщо зріз мав попередника в вихідному масиві, він вказується як `pred`.
///
/// `limit` - це кількість дозволених незбалансованих розділів перед переходом на `heapsort`.
/// Якщо дорівнює нулю, ця функція негайно переключиться на сортовий режим.
fn recurse<'a, T, F>(mut v: &'a mut [T], is_less: &mut F, mut pred: Option<&'a T>, mut limit: u32)
where
    F: FnMut(&T, &T) -> bool,
{
    // Зрізи до цієї довжини сортуються за допомогою вставки.
    const MAX_INSERTION: usize = 20;

    // Вірно, якщо останнє розділення було достатньо збалансованим.
    let mut was_balanced = true;
    // Істинно, якщо останнє розділення не перетасовувало елементи (зріз вже був розділений).
    let mut was_partitioned = true;

    loop {
        let len = v.len();

        // Дуже короткі фрагменти сортуються за допомогою вставки сортування.
        if len <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // Якщо було зроблено занадто багато неправильних варіантів розвороту, просто поверніться до великої сорту, щоб гарантувати найгірший випадок `O(n * log(n))`.
        //
        if limit == 0 {
            heapsort(v, is_less);
            return;
        }

        // Якщо останнє розділення було незбалансованим, спробуйте розбити шаблони на зрізі, перемішавши деякі елементи навколо.
        // Сподіваємось, цього разу ми оберемо кращу опору.
        if !was_balanced {
            break_patterns(v);
            limit -= 1;
        }

        // Виберіть стержень і спробуйте здогадатися, чи зріз вже відсортований.
        let (pivot, likely_sorted) = choose_pivot(v, is_less);

        // Якщо останнє розділення було пристойно збалансованим і не перетасовувало елементи, і якщо виділення повороту передбачає, що зріз, швидше за все, вже відсортований ...
        //
        if was_balanced && was_partitioned && likely_sorted {
            // Спробуйте визначити кілька невпорядкованих елементів і перенести їх у правильні позиції.
            // Якщо зріз закінчиться повністю відсортованим, ми закінчили.
            if partial_insertion_sort(v, is_less) {
                return;
            }
        }

        // Якщо вибраний шарнір дорівнює попереднику, то це найменший елемент у зрізі.
        // Розділіть зріз на елементи, що дорівнюють елементам, і елементи, більші за опору.
        // Цей випадок зазвичай вдається, коли зріз містить багато повторюваних елементів.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // Продовжуйте сортувати елементи, більші за опору.
                v = &mut { v }[mid..];
                continue;
            }
        }

        // Розділіть фрагмент.
        let (mid, was_p) = partition(v, pivot, is_less);
        was_balanced = cmp::min(mid, len - mid) >= len / 8;
        was_partitioned = was_p;

        // Розділіть зріз на `left`, `pivot` та `right`.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        // Зверніться до коротшої сторони лише для того, щоб мінімізувати загальну кількість рекурсивних викликів і витратити менше місця в стеку.
        // Потім просто продовжуйте довшою стороною (це схоже на рекурсію хвоста).
        //
        if left.len() < right.len() {
            recurse(left, is_less, pred, limit);
            v = right;
            pred = Some(pivot);
        } else {
            recurse(right, is_less, Some(pivot), limit);
            v = left;
        }
    }
}

/// Сортує `v`, використовуючи швидку сортування, що перемагає шаблон, що є *O*(*n*\*log(* n*)) найгірший випадок.
pub fn quicksort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Сортування не має значущої поведінки для типів нульового розміру.
    if mem::size_of::<T>() == 0 {
        return;
    }

    // Обмежте кількість незбалансованих розділів до `floor(log2(len)) + 1`.
    let limit = usize::BITS - v.len().leading_zeros();

    recurse(v, &mut is_less, None, limit);
}

fn partition_at_index_loop<'a, T, F>(
    mut v: &'a mut [T],
    mut index: usize,
    is_less: &mut F,
    mut pred: Option<&'a T>,
) where
    F: FnMut(&T, &T) -> bool,
{
    loop {
        // Для фрагментів до цієї довжини швидше за все швидше просто сортувати їх.
        const MAX_INSERTION: usize = 10;
        if v.len() <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // Виберіть опору
        let (pivot, _) = choose_pivot(v, is_less);

        // Якщо вибраний шарнір дорівнює попереднику, то це найменший елемент у зрізі.
        // Розділіть зріз на елементи, що дорівнюють елементам, і елементи, більші за опору.
        // Цей випадок зазвичай вдається, коли зріз містить багато повторюваних елементів.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // Якщо ми здали наш індекс, то ми добре.
                if mid > index {
                    return;
                }

                // В іншому випадку продовжуйте сортувати елементи, більші за опорні.
                v = &mut v[mid..];
                index = index - mid;
                pred = None;
                continue;
            }
        }

        let (mid, _) = partition(v, pivot, is_less);

        // Розділіть зріз на `left`, `pivot` та `right`.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        if mid < index {
            v = right;
            index = index - mid - 1;
            pred = Some(pivot);
        } else if mid > index {
            v = left;
        } else {
            // Якщо mid==index, то ми закінчили, оскільки partition() гарантував, що всі елементи після mid більше або дорівнюють mid.
            //
            return;
        }
    }
}

pub fn partition_at_index<T, F>(
    v: &mut [T],
    index: usize,
    mut is_less: F,
) -> (&mut [T], &mut T, &mut [T])
where
    F: FnMut(&T, &T) -> bool,
{
    use cmp::Ordering::Greater;
    use cmp::Ordering::Less;

    if index >= v.len() {
        panic!("partition_at_index index {} greater than length of slice {}", index, v.len());
    }

    if mem::size_of::<T>() == 0 {
        // Сортування не має значущої поведінки для типів нульового розміру.Нічого не робити.
    } else if index == v.len() - 1 {
        // Знайдіть елемент max та розмістіть його в останньому положенні масиву.
        // Ми можемо використовувати `unwrap()` тут, оскільки ми знаємо, що v не повинен бути порожнім.
        let (max_index, _) = v
            .iter()
            .enumerate()
            .max_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(max_index, index);
    } else if index == 0 {
        // Знайдіть елемент min і розмістіть його в першій позиції масиву.
        // Ми можемо використовувати `unwrap()` тут, оскільки ми знаємо, що v не повинен бути порожнім.
        let (min_index, _) = v
            .iter()
            .enumerate()
            .min_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(min_index, index);
    } else {
        partition_at_index_loop(v, index, &mut is_less, None);
    }

    let (left, right) = v.split_at_mut(index);
    let (pivot, right) = right.split_at_mut(1);
    let pivot = &mut pivot[0];
    (left, pivot, right)
}