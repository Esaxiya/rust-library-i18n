#[doc = include_str!("panic.md")]
#[macro_export]
#[rustc_builtin_macro = "core_panic"]
#[allow_internal_unstable(edition_panic)]
#[stable(feature = "core", since = "1.6.0")]
#[rustc_diagnostic_item = "core_panic_macro"]
macro_rules! panic {
    // Розширюється до `$crate::panic::panic_2015` або `$crate::panic::panic_2021` залежно від редакції того, хто телефонує.
    //
    ($($arg:tt)*) => {
        /* compiler built-in */
    };
}

/// Стверджує, що два вирази рівні між собою (за допомогою [`PartialEq`]).
///
/// На panic цей макрос надрукує значення виразів з їх налагодженнями.
///
///
/// Як і [`assert!`], цей макрос має другу форму, де може бути надано власне повідомлення panic.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// assert_eq!(a, b);
///
/// assert_eq!(a, b, "we are testing addition with {} and {}", a, b);
/// ```
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_eq {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // Повторні вправи нижче є навмисними.
                    // Без них слот стека для запозичення ініціалізується ще до порівняння значень, що призводить до помітного уповільнення.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // Повторні вправи нижче є навмисними.
                    // Без них слот стека для запозичення ініціалізується ще до порівняння значень, що призводить до помітного уповільнення.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// Стверджує, що два вирази не рівні між собою (за допомогою [`PartialEq`]).
///
/// На panic цей макрос надрукує значення виразів з їх налагодженнями.
///
///
/// Як і [`assert!`], цей макрос має другу форму, де може бути надано власне повідомлення panic.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// assert_ne!(a, b);
///
/// assert_ne!(a, b, "we are testing that the values are not equal");
/// ```
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_ne {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // Повторні вправи нижче є навмисними.
                    // Без них слот стека для запозичення ініціалізується ще до порівняння значень, що призводить до помітного уповільнення.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&($left), &($right)) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // Повторні вправи нижче є навмисними.
                    // Без них слот стека для запозичення ініціалізується ще до порівняння значень, що призводить до помітного уповільнення.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// Стверджує, що булевим виразом є `true` під час виконання.
///
/// Це викличе макрос [`panic!`], якщо наданий вираз не може бути оцінений як `true` під час виконання.
///
/// Як і [`assert!`], цей макрос також має другу версію, де може бути надано власне повідомлення panic.
///
/// # Uses
///
/// На відміну від [`assert!`], оператори `debug_assert!` увімкнені лише в неоптимізованих збірках за замовчуванням.
/// Оптимізована збірка не буде виконувати оператори `debug_assert!`, якщо `-C debug-assertions` не передано компілятору.
/// Це робить `debug_assert!` корисним для перевірок, які занадто дорогі, щоб бути присутніми у складі випуску, але можуть бути корисними під час розробки.
/// Результатом розширення `debug_assert!` завжди є перевірка типу.
///
/// Неперевірене твердження дозволяє програмі в непослідовному стані продовжувати працювати, що може мати несподівані наслідки, але не створює небезпеки, якщо це відбувається лише в безпечному коді.
///
/// Однак ефективність тверджень, як правило, не піддається вимірюванню.
/// Таким чином, заміна [`assert!`] на `debug_assert!` заохочується лише після ретельного профілювання, і що більш важливо, лише в безпечному коді!
///
/// # Examples
///
/// ```
/// // повідомлення panic для цих тверджень є строгованим значенням поданого виразу.
/////
/// debug_assert!(true);
///
/// fn some_expensive_computation() -> bool { true } // дуже проста функція
/// debug_assert!(some_expensive_computation());
///
/// // стверджувати за допомогою власного повідомлення
/// let x = true;
/// debug_assert!(x, "x wasn't true!");
///
/// let a = 3; let b = 27;
/// debug_assert!(a + b == 30, "a = {}, b = {}", a, b);
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "debug_assert_macro"]
macro_rules! debug_assert {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert!($($arg)*); })
}

/// Стверджує, що два вирази рівні між собою.
///
/// На panic цей макрос надрукує значення виразів з їх налагодженнями.
///
/// На відміну від [`assert_eq!`], оператори `debug_assert_eq!` увімкнені лише в неоптимізованих збірках за замовчуванням.
/// Оптимізована збірка не буде виконувати оператори `debug_assert_eq!`, якщо `-C debug-assertions` не передано компілятору.
/// Це робить `debug_assert_eq!` корисним для перевірок, які занадто дорогі, щоб бути присутніми у складі випуску, але можуть бути корисними під час розробки.
///
/// Результатом розширення `debug_assert_eq!` завжди є перевірка типу.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// debug_assert_eq!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! debug_assert_eq {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_eq!($($arg)*); })
}

/// Стверджує, що два вирази не рівні між собою.
///
/// На panic цей макрос надрукує значення виразів з їх налагодженнями.
///
/// На відміну від [`assert_ne!`], оператори `debug_assert_ne!` увімкнені лише в неоптимізованих збірках за замовчуванням.
/// Оптимізована збірка не буде виконувати оператори `debug_assert_ne!`, якщо `-C debug-assertions` не передано компілятору.
/// Це робить `debug_assert_ne!` корисним для перевірок, які занадто дорогі, щоб бути присутніми у складі випуску, але можуть бути корисними під час розробки.
///
/// Результатом розширення `debug_assert_ne!` завжди є перевірка типу.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// debug_assert_ne!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
macro_rules! debug_assert_ne {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_ne!($($arg)*); })
}

/// Повертає, чи відповідає даний вираз будь-якому із поданих шаблонів.
///
/// Як і у виразі `match`, за шаблоном може необов'язково слідувати `if` і вираз захисту, який має доступ до імен, пов'язаних з цим шаблоном.
///
///
/// # Examples
///
/// ```
/// let foo = 'f';
/// assert!(matches!(foo, 'A'..='Z' | 'a'..='z'));
///
/// let bar = Some(4);
/// assert!(matches!(bar, Some(x) if x > 2));
/// ```
#[macro_export]
#[stable(feature = "matches_macro", since = "1.42.0")]
macro_rules! matches {
    ($expression:expr, $( $pattern:pat )|+ $( if $guard: expr )? $(,)?) => {
        match $expression {
            $( $pattern )|+ $( if $guard )? => true,
            _ => false
        }
    }
}

/// Розгортає результат або поширює його помилку.
///
/// Оператор `?` був доданий на заміну `try!`, і його слід використовувати замість цього.
/// Крім того, `try`-це зарезервоване слово в Rust 2018, тому, якщо вам потрібно його використовувати, вам потрібно буде використовувати [raw-identifier syntax][ris]: `r#try`.
///
///
/// [ris]: https://doc.rust-lang.org/nightly/rust-by-example/compatibility/raw_identifiers.html
///
/// `try!` відповідає заданому [`Result`].У випадку з варіантом `Ok` вираз має значення загорнутого значення.
///
/// У випадку з варіантом `Err` він отримує внутрішню помилку.Потім `try!` виконує перетворення за допомогою `From`.
/// Це забезпечує автоматичне перетворення між спеціалізованими помилками та більш загальними.
/// Потім помилка негайно повертається.
///
/// Через раннє повернення `try!` можна використовувати лише у функціях, які повертають [`Result`].
///
/// # Examples
///
/// ```
/// use std::io;
/// use std::fs::File;
/// use std::io::prelude::*;
///
/// enum MyError {
///     FileWriteError
/// }
///
/// impl From<io::Error> for MyError {
///     fn from(e: io::Error) -> MyError {
///         MyError::FileWriteError
///     }
/// }
///
/// // Кращий метод швидкого повернення помилок
/// fn write_to_file_question() -> Result<(), MyError> {
///     let mut file = File::create("my_best_friends.txt")?;
///     file.write_all(b"This is a list of my best friends.")?;
///     Ok(())
/// }
///
/// // Попередній метод швидкого повернення помилок
/// fn write_to_file_using_try() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     r#try!(file.write_all(b"This is a list of my best friends."));
///     Ok(())
/// }
///
/// // Це еквівалентно:
/// fn write_to_file_using_match() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     match file.write_all(b"This is a list of my best friends.") {
///         Ok(v) => v,
///         Err(e) => return Err(From::from(e)),
///     }
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "1.39.0", reason = "use the `?` operator instead")]
#[doc(alias = "?")]
macro_rules! r#try {
    ($expr:expr $(,)?) => {
        match $expr {
            $crate::result::Result::Ok(val) => val,
            $crate::result::Result::Err(err) => {
                return $crate::result::Result::Err($crate::convert::From::from(err));
            }
        }
    };
}

/// Записує відформатовані дані в буфер.
///
/// Цей макрос приймає 'writer', рядок формату та список аргументів.
/// Аргументи будуть відформатовані відповідно до вказаного рядка формату, а результат буде передано автору.
/// Записник може мати будь-яке значення за методом `write_fmt`;загалом це походить від реалізації або [`fmt::Write`], або [`io::Write`] Portrait.
/// Макрос повертає те, що повертає метод `write_fmt`;зазвичай [`fmt::Result`] або [`io::Result`].
///
/// Див. [`std::fmt`] для отримання додаткової інформації про синтаксис рядка формату.
///
/// [`std::fmt`]: ../std/fmt/index.html
/// [`fmt::Write`]: crate::fmt::Write
/// [`io::Write`]: ../std/io/trait.Write.html
/// [`fmt::Result`]: crate::fmt::Result
/// [`io::Result`]: ../std/io/type.Result.html
///
/// # Examples
///
/// ```
/// use std::io::Write;
///
/// fn main() -> std::io::Result<()> {
///     let mut w = Vec::new();
///     write!(&mut w, "test")?;
///     write!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(w, b"testformatted arguments");
///     Ok(())
/// }
/// ```
///
/// Модуль може імпортувати як `std::fmt::Write`, так і `std::io::Write` і викликати `write!` для об'єктів, що реалізують обидва, оскільки об'єкти зазвичай не реалізують обидва.
///
/// Однак модуль повинен імпортувати кваліфікований traits, щоб їх імена не суперечили:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     write!(&mut s, "{} {}", "abc", 123)?; // використовує fmt::Write::write_fmt
///     write!(&mut v, "s = {:?}", s)?; // використовує io::Write::write_fmt
///     assert_eq!(v, b"s = \"abc 123\"");
///     Ok(())
/// }
/// ```
///
/// Note: Цей макрос можна використовувати і в налаштуваннях `no_std`.
/// У налаштуваннях `no_std` ви несете відповідальність за деталі реалізації компонентів.
///
/// ```no_run
/// # extern crate core;
/// use core::fmt::Write;
///
/// struct Example;
///
/// impl Write for Example {
///     fn write_str(&mut self, _s: &str) -> core::fmt::Result {
///          unimplemented!();
///     }
/// }
///
/// let mut m = Example{};
/// write!(&mut m, "Hello World").expect("Not written");
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! write {
    ($dst:expr, $($arg:tt)*) => ($dst.write_fmt($crate::format_args!($($arg)*)))
}

/// Запишіть відформатовані дані в буфер із доданим новим рядком.
///
/// На всіх платформах новий рядок-це символ LINE FEED (`\n`/`U+000A`) (без додаткового ПОВЕРНЕННЯ КАРІЇ (`\r`/`U+000D`).
///
/// Для отримання додаткової інформації див. [`write!`].Інформацію про синтаксис рядка формату див. У розділі [`std::fmt`].
///
/// [`std::fmt`]: ../std/fmt/index.html
///
/// # Examples
///
/// ```
/// use std::io::{Write, Result};
///
/// fn main() -> Result<()> {
///     let mut w = Vec::new();
///     writeln!(&mut w)?;
///     writeln!(&mut w, "test")?;
///     writeln!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(&w[..], "\ntest\nformatted arguments\n".as_bytes());
///     Ok(())
/// }
/// ```
///
/// Модуль може імпортувати як `std::fmt::Write`, так і `std::io::Write` і викликати `write!` для об'єктів, що реалізують обидва, оскільки об'єкти зазвичай не реалізують обидва.
/// Однак модуль повинен імпортувати кваліфікований traits, щоб їх імена не суперечили:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     writeln!(&mut s, "{} {}", "abc", 123)?; // використовує fmt::Write::write_fmt
///     writeln!(&mut v, "s = {:?}", s)?; // використовує io::Write::write_fmt
///     assert_eq!(v, b"s = \"abc 123\\n\"\n");
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(format_args_nl)]
macro_rules! writeln {
    ($dst:expr $(,)?) => (
        $crate::write!($dst, "\n")
    );
    ($dst:expr, $($arg:tt)*) => (
        $dst.write_fmt($crate::format_args_nl!($($arg)*))
    );
}

/// Позначає недосяжний код.
///
/// Це корисно в будь-який час, коли компілятор не може визначити, що якийсь код недосяжний.Наприклад:
///
/// * Поєднуйте зброю з умовами охорони.
/// * Цикли, що динамічно закінчуються.
/// * Ітератори, які динамічно завершуються.
///
/// Якщо визначення того, що код недоступний, виявляється неправильним, програма негайно припиняє роботу з [`panic!`].
///
/// Небезпечним аналогом цього макросу є функція [`unreachable_unchecked`], яка спричинить невизначену поведінку, якщо буде досягнуто код.
///
///
/// [`unreachable_unchecked`]: crate::hint::unreachable_unchecked
///
/// # Panics
///
/// Це завжди буде [`panic!`].
///
/// # Examples
///
/// Матч зброї:
///
/// ```
/// # #[allow(dead_code)]
/// fn foo(x: Option<i32>) {
///     match x {
///         Some(n) if n >= 0 => println!("Some(Non-negative)"),
///         Some(n) if n <  0 => println!("Some(Negative)"),
///         Some(_)           => unreachable!(), // помилка компіляції, якщо коментується
///         None              => println!("None")
///     }
/// }
/// ```
///
/// Iterators:
///
/// ```
/// # #[allow(dead_code)]
/// fn divide_by_three(x: u32) -> u32 { // одна з найбідніших реалізацій x/3
///     for i in 0.. {
///         if 3*i < i { panic!("u32 overflow"); }
///         if x < 3*i { return i-1; }
///     }
///     unreachable!();
/// }
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unreachable {
    () => ({
        $crate::panic!("internal error: entered unreachable code")
    });
    ($msg:expr $(,)?) => ({
        $crate::unreachable!("{}", $msg)
    });
    ($fmt:expr, $($arg:tt)*) => ({
        $crate::panic!($crate::concat!("internal error: entered unreachable code: ", $fmt), $($arg)*)
    });
}

/// Позначає нереалізований код, викликаючи паніку з повідомленням "not implemented".
///
/// Це дозволяє коду перевіряти тип, що корисно, якщо ви створюєте прототип або реалізовуєте Portrait, який вимагає декількох методів, які ви не плануєте використовувати всі.
///
/// Різниця між `unimplemented!` та [`todo!`] полягає в тому, що, хоча `todo!` передає намір реалізувати функціонал пізніше, а повідомлення "not yet implemented", `unimplemented!` не заявляє таких претензій.
/// Його повідомлення-"not implemented".
/// Також деякі IDE будуть позначати `todo!` S.
///
/// # Panics
///
/// Це завжди буде [`panic!`], оскільки `unimplemented!`-це просто скорочення для `panic!` з фіксованим, конкретним повідомленням.
///
/// Як і `panic!`, цей макрос має другу форму для відображення нестандартних значень.
///
/// # Examples
///
/// Скажімо, у нас є Portrait `Foo`:
///
/// ```
/// trait Foo {
///     fn bar(&self) -> u8;
///     fn baz(&self);
///     fn qux(&self) -> Result<u64, ()>;
/// }
/// ```
///
/// Ми хочемо впровадити `Foo` для 'MyStruct', але чомусь має сенс лише реалізувати функцію `bar()`.
/// `baz()` і `qux()` все одно потрібно буде визначити в нашій реалізації `Foo`, але ми можемо використовувати `unimplemented!` у їхніх визначеннях, щоб дозволити компілювати наш код.
///
/// Ми все ще хочемо, щоб наша програма припинила роботу, якщо досягнуто нереалізованих методів.
///
/// ```
/// # trait Foo {
/// #     fn bar(&self) -> u8;
/// #     fn baz(&self);
/// #     fn qux(&self) -> Result<u64, ()>;
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) -> u8 {
///         1 + 1
///     }
///
///     fn baz(&self) {
///         // Немає сенсу `baz` і `MyStruct`, тому у нас тут взагалі немає логіки.
/////
///         // На цьому екрані відобразиться "thread 'main' panicked at 'not implemented'".
///         unimplemented!();
///     }
///
///     fn qux(&self) -> Result<u64, ()> {
///         // У нас тут є логіка, ми можемо додати повідомлення до нереалізованого!для відображення нашого упущення.
///         // Відобразиться: "thread 'main' panicked at 'not implemented: MyStruct isn't quxable'".
/////
/////
///         unimplemented!("MyStruct isn't quxable");
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
/// }
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unimplemented {
    () => ($crate::panic!("not implemented"));
    ($($arg:tt)+) => ($crate::panic!("not implemented: {}", $crate::format_args!($($arg)+)));
}

/// Позначає незавершений код.
///
/// Це може бути корисно, якщо ви робите прототип і просто хочете перевірити тип коду.
///
/// Різниця між [`unimplemented!`] та `todo!` полягає в тому, що, хоча `todo!` передає намір реалізувати функціонал пізніше, а повідомлення "not yet implemented", `unimplemented!` не заявляє таких претензій.
/// Його повідомлення-"not implemented".
/// Також деякі IDE будуть позначати `todo!` S.
///
/// # Panics
///
/// Це завжди буде [`panic!`].
///
/// # Examples
///
/// Ось приклад деякого незавершеного коду.У нас є Portrait `Foo`:
///
/// ```
/// trait Foo {
///     fn bar(&self);
///     fn baz(&self);
/// }
/// ```
///
/// Ми хочемо реалізувати `Foo` на одному з наших типів, але ми також хочемо спочатку працювати лише на `bar()`.Для того, щоб наш код скомпілювався, нам потрібно реалізувати `baz()`, тому ми можемо використовувати `todo!`:
///
/// ```
/// # trait Foo {
/// #     fn bar(&self);
/// #     fn baz(&self);
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) {
///         // реалізація йде тут
///     }
///
///     fn baz(&self) {
///         // давайте не будемо турбуватися про впровадження baz() поки
///         todo!();
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
///
///     // ми навіть не використовуємо baz(), тому це нормально.
/// }
/// ```
///
///
///
///
#[macro_export]
#[stable(feature = "todo_macro", since = "1.40.0")]
macro_rules! todo {
    () => ($crate::panic!("not yet implemented"));
    ($($arg:tt)+) => ($crate::panic!("not yet implemented: {}", $crate::format_args!($($arg)+)));
}

/// Визначення вбудованих макросів.
///
/// Більшість властивостей макросів (стабільність, видимість тощо) беруться з вихідного коду тут, за винятком функцій розширення, що перетворюють входи макросів у виходи, ці функції надаються компілятором.
///
///
pub(crate) mod builtin {

    /// Призводить до помилки компіляції з даним повідомленням про помилку при виникненні.
    ///
    /// Цей макрос слід використовувати, коли crate використовує умовну стратегію компіляції для надання кращих повідомлень про помилки при помилкових умовах.
    ///
    /// Це форма [`panic!`] на рівні компілятора, але видає помилку під час *компіляції*, а не під час *виконання*.
    ///
    /// # Examples
    ///
    /// Два таких приклади-макроси та середовища `#[cfg]`.
    ///
    /// Видавати помилку компілятора краще, якщо макросу передаються недійсні значення.
    /// Без остаточного branch компілятор все одно видасть помилку, але в повідомленні про помилку не буде зазначено двох дійсних значень.
    ///
    /// ```compile_fail
    /// macro_rules! give_me_foo_or_bar {
    ///     (foo) => {};
    ///     (bar) => {};
    ///     ($x:ident) => {
    ///         compile_error!("This macro only accepts `foo` or `bar`");
    ///     }
    /// }
    ///
    /// give_me_foo_or_bar!(neither);
    /// // ^ will fail at compile time with message "This macro only accepts `foo` or `bar`"
    /// ```
    ///
    /// Виділити помилку компілятора, якщо одна з ряду функцій недоступна.
    ///
    /// ```compile_fail
    /// #[cfg(not(any(feature = "foo", feature = "bar")))]
    /// compile_error!("Either feature \"foo\" or \"bar\" must be enabled for this crate.");
    /// ```
    ///
    #[stable(feature = "compile_error_macro", since = "1.20.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! compile_error {
        ($msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Побудовує параметри для інших макросів форматування рядків.
    ///
    /// Цей макрос функціонує, беручи літеральний рядок форматування, що містить `{}` для кожного додаткового переданого аргументу.
    /// `format_args!` готує додаткові параметри, щоб забезпечити вихідний результат, який можна інтерпретувати як рядок, і канонізує аргументи в один тип.
    /// Будь-яке значення, яке реалізує [`Display`] Portrait, може бути передане в `format_args!`, як і будь-яка реалізація [`Debug`] у `{:?}` у рядку форматування.
    ///
    ///
    /// Цей макрос створює значення типу [`fmt::Arguments`].Це значення можна передати макрокомандам у межах [`std::fmt`] для здійснення корисного перенаправлення.
    /// Усі інші макроси форматування ([`формат! '], [`write!`], [`println!`] тощо) через цей проксі-сервер.
    /// `format_args!`, на відміну від похідних макросів, уникає розподілу купи.
    ///
    /// Ви можете використовувати значення [`fmt::Arguments`], яке `format_args!` повертає в контекстах `Debug` та `Display`, як показано нижче.
    /// Приклад також показує, що `Debug` і `Display` форматують одне і те ж: інтерпольований рядок формату в `format_args!`.
    ///
    /// ```rust
    /// let debug = format!("{:?}", format_args!("{} foo {:?}", 1, 2));
    /// let display = format!("{}", format_args!("{} foo {:?}", 1, 2));
    /// assert_eq!("1 foo 2", display);
    /// assert_eq!(display, debug);
    /// ```
    ///
    /// Для отримання додаткової інформації див. Документацію до [`std::fmt`].
    ///
    /// [`Display`]: crate::fmt::Display
    /// [`Debug`]: crate::fmt::Debug
    /// [`fmt::Arguments`]: crate::fmt::Arguments
    /// [`std::fmt`]: ../std/fmt/index.html
    /// [`format!`]: ../std/macro.format.html
    /// [`println!`]: ../std/macro.println.html
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// let s = fmt::format(format_args!("hello {}", "world"));
    /// assert_eq!(s, format!("hello {}", "world"));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// Те саме, що і `format_args`, але в кінці додає новий рядок.
    #[unstable(
        feature = "format_args_nl",
        issue = "none",
        reason = "`format_args_nl` is only for internal \
                  language use and is subject to change"
    )]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args_nl {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// Перевіряє змінну середовища під час компіляції.
    ///
    /// Цей макрос розшириться до значення зазначеної змінної середовища під час компіляції, даючи вираз типу `&'static str`.
    ///
    ///
    /// Якщо змінна середовища не визначена, буде видано помилку компіляції.
    /// Щоб не видавати помилку компіляції, використовуйте натомість макрос [`option_env!`].
    ///
    /// # Examples
    ///
    /// ```
    /// let path: &'static str = env!("PATH");
    /// println!("the $PATH variable at the time of compiling was: {}", path);
    /// ```
    ///
    /// Ви можете налаштувати повідомлення про помилку, передавши рядок як другий параметр:
    ///
    /// ```compile_fail
    /// let doc: &'static str = env!("documentation", "what's that?!");
    /// ```
    ///
    /// Якщо змінна середовища `documentation` не визначена, ви отримаєте таку помилку:
    ///
    /// ```text
    /// error: what's that?!
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
        ($name:expr, $error_msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Необов`язково перевіряє змінну середовища під час компіляції.
    ///
    /// Якщо названа змінна середовища присутня під час компіляції, це розшириться у вираз типу `Option<&'static str>`, значення якого `Some` значення змінної середовища.
    /// Якщо змінної середовища немає, це збільшиться до `None`.
    /// Докладніше про цей тип див. У розділі [`Option<T>`][Option].
    ///
    /// Помилка часу компіляції ніколи не видається при використанні цього макросу, незалежно від того, присутня змінна середовища чи ні.
    ///
    /// # Examples
    ///
    /// ```
    /// let key: Option<&'static str> = option_env!("SECRET_KEY");
    /// println!("the secret key might be: {:?}", key);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! option_env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Об`єднує ідентифікатори в один ідентифікатор.
    ///
    /// Цей макрос приймає будь-яку кількість ідентифікаторів, розділених комами, і об'єднує їх усі в один, отримуючи вираз, який є новим ідентифікатором.
    /// Зверніть увагу, що гігієна робить так, що цей макрос не може фіксувати місцеві змінні.
    /// Крім того, як загальне правило, макроси допускаються лише в позиції елемента, висловлення або виразу.
    /// Це означає, що, хоча ви можете використовувати цей макрос для посилання на існуючі змінні, функції або модулі тощо, ви не можете визначити новий за допомогою нього.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(concat_idents)]
    ///
    /// # fn main() {
    /// fn foobar() -> u32 { 23 }
    ///
    /// let f = concat_idents!(foo, bar);
    /// println!("{}", f());
    ///
    /// // fn concat_idents! (нове, веселе, ім'я) { }//не можна використовувати таким чином!
    /// # }
    /// ```
    ///
    ///
    ///
    #[unstable(
        feature = "concat_idents",
        issue = "29599",
        reason = "`concat_idents` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat_idents {
        ($($e:ident),+ $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Об`єднує літерали у статичний фрагмент рядка.
    ///
    /// Цей макрос приймає будь-яку кількість літералів, розділених комами, даючи вираз типу `&'static str`, який представляє всі літерали, об'єднані зліва направо.
    ///
    ///
    /// Цілі і літерали з плаваючою комою роздрібнюються для об'єднання.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = concat!("test", 10, 'b', true);
    /// assert_eq!(s, "test10btrue");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat {
        ($($e:expr),* $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Розгортається до номера рядка, на якому його було викликано.
    ///
    /// У [`column!`] та [`file!`] ці макроси надають розробникам інформацію про налагодження щодо розташування у джерелі.
    ///
    /// Розширений вираз має тип `u32` і базується на 1, тому перший рядок у кожному файлі має значення 1, другий-2 і т.д.
    /// Це узгоджується з повідомленнями про помилки загальних компіляторів або популярних редакторів.
    /// Повернений рядок *не обов'язково* рядок самого виклику `line!`, а швидше перший виклик макросу, що приводить до виклику макроса `line!`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_line = line!();
    /// println!("defined on line: {}", current_line);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! line {
        () => {
            /* compiler built-in */
        };
    }

    /// Розгортається до номера стовпця, за яким його було викликано.
    ///
    /// У [`line!`] та [`file!`] ці макроси надають розробникам інформацію про налагодження щодо розташування у джерелі.
    ///
    /// Розширений вираз має тип `u32` і базується на 1, тому перший стовпець у кожному рядку має значення 1, другий-2 тощо.
    /// Це узгоджується з повідомленнями про помилки загальних компіляторів або популярних редакторів.
    /// Повернений стовпець *не обов'язково* рядок самого виклику `column!`, а швидше перший виклик макросу, що веде до виклику макроса `column!`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_col = column!();
    /// println!("defined on column: {}", current_col);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! column {
        () => {
            /* compiler built-in */
        };
    }

    /// Розгортається до імені файлу, у якому його було викликано.
    ///
    /// У [`line!`] та [`column!`] ці макроси надають розробникам інформацію про налагодження щодо розташування у джерелі.
    ///
    /// Розширений вираз має тип `&'static str`, і повернутий файл є не викликом самого макросу `file!`, а першим викликом макросу, що приводить до виклику макросу `file!`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let this_file = file!();
    /// println!("defined in file: {}", this_file);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! file {
        () => {
            /* compiler built-in */
        };
    }

    /// Натягує свої аргументи.
    ///
    /// Цей макрос дасть вираз типу `&'static str`, який є стритрифікацією всіх tokens, переданих макросу.
    /// Синтаксис самого виклику макросу не обмежується.
    ///
    /// Зверніть увагу, що розширені результати вхідних даних tokens можуть змінитися в future.Будьте обережні, якщо покладаєтесь на результат.
    ///
    /// # Examples
    ///
    /// ```
    /// let one_plus_one = stringify!(1 + 1);
    /// assert_eq!(one_plus_one, "1 + 1");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! stringify {
        ($($t:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Включає кодований файл UTF-8 як рядок.
    ///
    /// Файл знаходиться відносно поточного файлу (подібно до того, як знаходять модулі).
    /// Наданий шлях інтерпретується в залежності від платформи під час компіляції.
    /// Так, наприклад, виклик із шляхом Windows, що містить зворотні скісні риски `\`, не буде правильно скомпільований на Unix.
    ///
    ///
    /// Цей макрос дасть вираз типу `&'static str`, який є вмістом файлу.
    ///
    /// # Examples
    ///
    /// Припустимо, що в одному каталозі є два файли із таким вмістом:
    ///
    /// Файл 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// Файл 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_str = include_str!("spanish.in");
    ///     assert_eq!(my_str, "adiós\n");
    ///     print!("{}", my_str);
    /// }
    /// ```
    ///
    /// Компілюючи 'main.rs' та запускаючи отриманий двійковий файл, друкується "adiós".
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_str {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Включає файл як посилання на байтовий масив.
    ///
    /// Файл знаходиться відносно поточного файлу (подібно до того, як знаходять модулі).
    /// Наданий шлях інтерпретується в залежності від платформи під час компіляції.
    /// Так, наприклад, виклик із шляхом Windows, що містить зворотні скісні риски `\`, не буде правильно скомпільований на Unix.
    ///
    ///
    /// Цей макрос дасть вираз типу `&'static [u8; N]`, який є вмістом файлу.
    ///
    /// # Examples
    ///
    /// Припустимо, що в одному каталозі є два файли із таким вмістом:
    ///
    /// Файл 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// Файл 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let bytes = include_bytes!("spanish.in");
    ///     assert_eq!(bytes, b"adi\xc3\xb3s\n");
    ///     print!("{}", String::from_utf8_lossy(bytes));
    /// }
    /// ```
    ///
    /// Компілюючи 'main.rs' та запускаючи отриманий двійковий файл, друкується "adiós".
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_bytes {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Розгортається до рядка, який представляє поточний шлях до модуля.
    ///
    /// Поточний шлях до модуля можна сприймати як ієрархію модулів, що ведуть назад до crate root.
    /// Першим компонентом повернутого шляху є ім'я crate, яке зараз компілюється.
    ///
    /// # Examples
    ///
    /// ```
    /// mod test {
    ///     pub fn foo() {
    ///         assert!(module_path!().ends_with("test"));
    ///     }
    /// }
    ///
    /// test::foo();
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! module_path {
        () => {
            /* compiler built-in */
        };
    }

    /// Обчислює логічні комбінації прапорців конфігурації під час компіляції.
    ///
    /// На додаток до атрибута `#[cfg]`, цей макрос надається для забезпечення логічного виразу оцінки прапорів конфігурації.
    /// Це часто призводить до менш продубльованого коду.
    ///
    /// Синтаксис, наданий цьому макросу, є таким самим, як і атрибут [`cfg`].
    ///
    /// `cfg!`, на відміну від `#[cfg]`, не видаляє жодного коду, а оцінює лише значення true або false.
    /// Наприклад, усі блоки у виразі if/else мають бути дійсними, коли для умови використовується `cfg!`, незалежно від того, що обчислює `cfg!`.
    ///
    ///
    /// [`cfg`]: ../reference/conditional-compilation.html#the-cfg-attribute
    ///
    /// # Examples
    ///
    /// ```
    /// let my_directory = if cfg!(windows) {
    ///     "windows-specific-directory"
    /// } else {
    ///     "unix-directory"
    /// };
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! cfg {
        ($($cfg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Розбирає файл як вираз або елемент відповідно до контексту.
    ///
    /// Файл знаходиться відносно поточного файлу (подібно до того, як знаходять модулі).Наданий шлях інтерпретується в залежності від платформи під час компіляції.
    /// Так, наприклад, виклик із шляхом Windows, що містить зворотні скісні риски `\`, не буде правильно скомпільований на Unix.
    ///
    /// Використання цього макросу часто є поганою ідеєю, оскільки якщо файл буде проаналізований як вираз, він буде розміщений в оточуючому коді негігієнічно.
    /// Це може призвести до того, що змінні або функції відрізнятимуться від того, що очікував файл, якщо у поточному файлі є змінні або функції, що мають однакові назви.
    ///
    ///
    /// # Examples
    ///
    /// Припустимо, що в одному каталозі є два файли із таким вмістом:
    ///
    /// Файл 'monkeys.in':
    ///
    /// ```ignore (only-for-syntax-highlight)
    /// ['🙈', '🙊', '🙉']
    ///     .iter()
    ///     .cycle()
    ///     .take(6)
    ///     .collect::<String>()
    /// ```
    ///
    /// Файл 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_string = include!("monkeys.in");
    ///     assert_eq!("🙈🙊🙉🙈🙊🙉", my_string);
    ///     println!("{}", my_string);
    /// }
    /// ```
    ///
    /// Компілюючи 'main.rs' та запускаючи отриманий двійковий файл, друкується "🙈🙊🙉🙈🙊🙉".
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Стверджує, що булевим виразом є `true` під час виконання.
    ///
    /// Це викличе макрос [`panic!`], якщо наданий вираз не може бути оцінений як `true` під час виконання.
    ///
    /// # Uses
    ///
    /// Твердження завжди перевіряються як у збірках налагодження, так і у випуску, і їх не можна відключити.
    /// Див. [`debug_assert!`] щодо тверджень, які за замовчуванням не ввімкнено у збірках випусків.
    ///
    /// Небезпечний код може покладатися на `assert!` для застосування інваріантів часу роботи, які в разі порушення можуть призвести до небезпеки.
    ///
    /// Інші випадки використання `assert!` включають тестування та застосування інваріантів часу виконання в безпечному коді (порушення яких не може призвести до небезпеки).
    ///
    ///
    /// # Спеціальні повідомлення
    ///
    /// Цей макрос має другу форму, де користувацьке повідомлення panic може надаватися з аргументами для форматування або без них.
    /// Синтаксис цієї форми див. У [`std::fmt`].
    /// Вирази, що використовуються як аргументи формату, будуть обчислюватися, лише якщо твердження не вдається.
    ///
    /// [`std::fmt`]: ../std/fmt/index.html
    ///
    /// # Examples
    ///
    /// ```
    /// // повідомлення panic для цих тверджень є строгованим значенням поданого виразу.
    /////
    /// assert!(true);
    ///
    /// fn some_computation() -> bool { true } // дуже проста функція
    ///
    /// assert!(some_computation());
    ///
    /// // стверджувати за допомогою власного повідомлення
    /// let x = true;
    /// assert!(x, "x wasn't true!");
    ///
    /// let a = 3; let b = 27;
    /// assert!(a + b == 30, "a = {}, b = {}", a, b);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    #[rustc_diagnostic_item = "assert_macro"]
    #[allow_internal_unstable(core_panic, edition_panic)]
    macro_rules! assert {
        ($cond:expr $(,)?) => {{ /* compiler built-in */ }};
        ($cond:expr, $($arg:tt)+) => {{ /* compiler built-in */ }};
    }

    /// Вбудована збірка.
    ///
    /// Прочитайте [unstable book] щодо використання.
    ///
    /// [unstable book]: ../unstable-book/library-features/asm.html
    #[unstable(
        feature = "asm",
        issue = "72016",
        reason = "inline assembly is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! asm {
        ("assembly template",
            $(operands,)*
            $(options($(option),*))?
        ) => {
            /* compiler built-in */
        };
    }

    /// Вбудована збірка у стилі LLVM.
    ///
    /// Прочитайте [unstable book] щодо використання.
    ///
    /// [unstable book]: ../unstable-book/library-features/llvm-asm.html
    #[unstable(
        feature = "llvm_asm",
        issue = "70173",
        reason = "prefer using the new asm! syntax instead"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! llvm_asm {
        ("assembly template"
                        : $("output"(operand),)*
                        : $("input"(operand),)*
                        : $("clobbers",)*
                        : $("options",)*) => {
            /* compiler built-in */
        };
    }

    /// Рядкова збірка на рівні модуля.
    #[unstable(
        feature = "global_asm",
        issue = "35119",
        reason = "`global_asm!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! global_asm {
        ("assembly") => {
            /* compiler built-in */
        };
    }

    /// Відбитки передавали tokens у стандартний вихід.
    #[unstable(
        feature = "log_syntax",
        issue = "29598",
        reason = "`log_syntax!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! log_syntax {
        ($($arg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Вмикає або вимикає функцію відстеження, що використовується для налагодження інших макросів.
    #[unstable(
        feature = "trace_macros",
        issue = "29598",
        reason = "`trace_macros` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! trace_macros {
        (true) => {{ /* compiler built-in */ }};
        (false) => {{ /* compiler built-in */ }};
    }

    /// Макрос атрибута, що використовується для застосування макросів виведення.
    #[cfg(not(bootstrap))]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    pub macro derive($item:item) {
        /* compiler built-in */
    }

    /// Макрос атрибута, застосований до функції, щоб перетворити її на одиничний тест.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test($item:item) {
        /* compiler built-in */
    }

    /// Макрос атрибута, застосований до функції, щоб перетворити її в тестовий тест.
    #[unstable(
        feature = "test",
        issue = "50297",
        soft,
        reason = "`bench` is a part of custom test frameworks which are unstable"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro bench($item:item) {
        /* compiler built-in */
    }

    /// Деталь реалізації макросів `#[test]` та `#[bench]`.
    #[unstable(
        feature = "custom_test_frameworks",
        issue = "50297",
        reason = "custom test frameworks are an unstable feature"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test_case($item:item) {
        /* compiler built-in */
    }

    /// Макрос атрибута, застосований до статики, щоб зареєструвати його як глобальний розподільник.
    ///
    /// Див. Також [`std::alloc::GlobalAlloc`](../std/alloc/trait.GlobalAlloc.html).
    #[stable(feature = "global_allocator", since = "1.28.0")]
    #[allow_internal_unstable(rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro global_allocator($item:item) {
        /* compiler built-in */
    }

    /// Зберігає елемент, до якого застосовано, якщо переданий шлях є доступним, і в іншому випадку видаляє його.
    #[unstable(
        feature = "cfg_accessible",
        issue = "64797",
        reason = "`cfg_accessible` is not fully implemented"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_accessible($item:item) {
        /* compiler built-in */
    }

    /// Розгортає всі атрибути `#[cfg]` та `#[cfg_attr]` у фрагменті коду, до якого він застосований.
    #[cfg(not(bootstrap))]
    #[unstable(
        feature = "cfg_eval",
        issue = "82679",
        reason = "`cfg_eval` is a recently implemented feature"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_eval($($tt:tt)*) {
        /* compiler built-in */
    }

    /// Нестабільні деталі реалізації компілятора `rustc`, не використовувати.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics, libstd_sys_internals)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcDecodable($item:item) {
        /* compiler built-in */
    }

    /// Нестабільні деталі реалізації компілятора `rustc`, не використовувати.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcEncodable($item:item) {
        /* compiler built-in */
    }
}