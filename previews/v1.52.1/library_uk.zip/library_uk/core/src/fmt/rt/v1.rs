//! Це внутрішній модуль, який використовується ifmt!час виконання.Ці структури передаються у статичні масиви для попереднього компіляції рядків форматування заздалегідь.
//!
//! Ці визначення подібні до їхніх еквівалентів `ct`, але відрізняються тим, що їх можна статично розподілити та дещо оптимізувати для виконання
//!
//!
#![allow(missing_debug_implementations)]

#[derive(Copy, Clone)]
pub struct Argument {
    pub position: usize,
    pub format: FormatSpec,
}

#[derive(Copy, Clone)]
pub struct FormatSpec {
    pub fill: char,
    pub align: Alignment,
    pub flags: u32,
    pub precision: Count,
    pub width: Count,
}

/// Можливі вирівнювання, які можна запросити як частину директиви форматування.
#[derive(Copy, Clone, PartialEq, Eq)]
pub enum Alignment {
    /// Вказівка на те, що вміст слід вирівнювати за лівим краєм.
    Left,
    /// Вказівка на те, що вміст повинен бути вирівняний по правому краю.
    Right,
    /// Вказівка на те, що вміст повинен бути вирівняний по центру.
    Center,
    /// Вирівнювання не вимагалось.
    Unknown,
}

/// Використовується специфікаторами [width](https://doc.rust-lang.org/std/fmt/#width) та [precision](https://doc.rust-lang.org/std/fmt/#precision).
#[derive(Copy, Clone)]
pub enum Count {
    /// Зазначений буквальним числом, зберігає значення
    Is(usize),
    /// Зазначений із використанням синтаксисів `$` та `*`, індекс зберігається у форматі `args`
    Param(usize),
    /// Не вказано
    Implied,
}