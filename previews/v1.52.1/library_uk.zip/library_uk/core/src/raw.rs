#![allow(missing_docs)]
#![unstable(feature = "raw", issue = "27751")]

//! Містить визначення структур для компонування вбудованих типів компілятора.
//!
//! Вони можуть використовуватися як цілі трансмутацій у небезпечному коді для безпосереднього маніпулювання необробленими поданнями.
//!
//!
//! Їх визначення завжди має відповідати ABI, визначеному в `rustc_middle::ty::layout`.
//!

/// Представлення об'єкта Portrait, такого як `&dyn SomeTrait`.
///
/// Ця структура має такий самий макет, як типи, такі як `&dyn SomeTrait` та `Box<dyn AnotherTrait>`.
///
/// `TraitObject` гарантовано відповідає макетам, але це не тип об`єктів Portrait (наприклад, поля не мають безпосереднього доступу на `&dyn SomeTrait`), а також не контролює цей макет (зміна визначення не змінить макет `&dyn SomeTrait`).
///
/// Він призначений лише для використання небезпечним кодом, який повинен маніпулювати деталями низького рівня.
///
/// Немає способу загального посилання на всі об`єкти Portrait, тому єдиний спосіб створити значення цього типу-це такі функції, як [`std::mem::transmute`][transmute].
/// Подібним чином єдиний спосіб створити справжній об'єкт Portrait зі значення `TraitObject`-це за допомогою `transmute`.
///
/// [transmute]: crate::intrinsics::transmute
///
/// Синтезування об`єкта Portrait з невідповідними типами-такого, де vtable не відповідає типу значення, на яке вказує вказівник даних-з великою ймовірністю може призвести до невизначеної поведінки.
///
/// # Examples
///
/// ```
/// #![feature(raw)]
///
/// use std::{mem, raw};
///
/// // приклад Portrait
/// trait Foo {
///     fn bar(&self) -> i32;
/// }
///
/// impl Foo for i32 {
///     fn bar(&self) -> i32 {
///          *self + 1
///     }
/// }
///
/// let value: i32 = 123;
///
/// // нехай компілятор створить об'єкт Portrait
/// let object: &dyn Foo = &value;
///
/// // подивіться на необроблене подання
/// let raw_object: raw::TraitObject = unsafe { mem::transmute(object) };
///
/// // покажчик даних-це адреса `value`
/// assert_eq!(raw_object.data as *const i32, &value as *const _);
///
/// let other_value: i32 = 456;
///
/// // побудувати новий об`єкт, вказуючи на інший `i32`, обережно використовуючи таблицю `i32` від `object`
/////
/// let synthesized: &dyn Foo = unsafe {
///      mem::transmute(raw::TraitObject {
///          data: &other_value as *const _ as *mut (),
///          vtable: raw_object.vtable,
///      })
/// };
///
/// // він повинен працювати так само, як ніби ми безпосередньо сконструювали об'єкт Portrait із `other_value`
/////
/// assert_eq!(synthesized.bar(), 457);
/// ```
///
///
///
///
///
///
///
///
///
#[repr(C)]
#[derive(Copy, Clone)]
#[allow(missing_debug_implementations)]
pub struct TraitObject {
    pub data: *mut (),
    pub vtable: *mut (),
}