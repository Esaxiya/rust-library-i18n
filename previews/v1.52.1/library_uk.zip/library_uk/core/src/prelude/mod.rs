//! Лібкор prelude
//!
//! Цей модуль призначений для користувачів libcore, які також не посилаються на libstd.
//! Цей модуль імпортується за замовчуванням, коли `#![no_std]` використовується так само, як стандартна бібліотека prelude.
//!

#![stable(feature = "core_prelude", since = "1.4.0")]

pub mod v1;

/// Версія ядра 2015 року prelude.
///
/// Докладніше див. У [module-level documentation](self).
#[unstable(feature = "prelude_2015", issue = "none")]
pub mod rust_2015 {
    #[unstable(feature = "prelude_2015", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// Версія ядра 2018 prelude.
///
/// Докладніше див. У [module-level documentation](self).
#[unstable(feature = "prelude_2018", issue = "none")]
pub mod rust_2018 {
    #[unstable(feature = "prelude_2018", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// Версія ядра 2021 року prelude.
///
/// Докладніше див. У [module-level documentation](self).
#[unstable(feature = "prelude_2021", issue = "none")]
pub mod rust_2021 {
    #[unstable(feature = "prelude_2021", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;

    // FIXME: Додайте більше речей.
}