//! Спільні змінні контейнери.
//!
//! Безпека пам'яті Rust базується на цьому правилі: Отримавши об`єкт `T`, можливо лише одне з наступного:
//!
//! - Маючи декілька незмінних посилань (`&T`) на об'єкт (також відомий як **псевдонім**).
//! - Маючи одне змінне посилання (`&mut T`) на об'єкт (також відоме як **мінливість**).
//!
//! Це забезпечується компілятором Rust.Однак бувають ситуації, коли це правило недостатньо гнучко.Іноді потрібно мати декілька посилань на об'єкт і все ж мутувати його.
//!
//! Спільні змінні контейнери існують, щоб забезпечити можливі зміни в контрольованому режимі, навіть за наявності згладжування.Як [`Cell<T>`], так і [`RefCell<T>`] дозволяють робити це однопоточним способом.
//! Однак ні `Cell<T>`, ні `RefCell<T>` не захищені від потоків (вони не реалізують [`Sync`]).
//! Якщо вам потрібно зробити псевдонім і мутацію між кількома потоками, можна використовувати типи [`Mutex<T>`], [`RwLock<T>`] або [`atomic`].
//!
//! Значення типів `Cell<T>` та `RefCell<T>` можуть мутувати через спільні посилання (тобто
//! загальний тип `&T`), тоді як більшість типів Rust можна мутувати лише за допомогою унікальних (`&mut T`) посилань.
//! Ми говоримо, що `Cell<T>` та `RefCell<T>` забезпечують " внутрішню мінливість`, на відміну від типових типів Rust, які демонструють " успадковану мінливість`.
//!
//! Типи клітин бувають двох видів: `Cell<T>` та `RefCell<T>`.`Cell<T>` реалізує зміну інтер`єру шляхом переміщення значень у і з `Cell<T>`.
//! Щоб використовувати посилання замість значень, потрібно використовувати тип `RefCell<T>`, отримуючи блокування запису перед мутацією.`Cell<T>` пропонує методи отримання та зміни поточного внутрішнього значення:
//!
//!  - Для типів, що реалізують [`Copy`], метод [`get`](Cell::get) отримує поточне внутрішнє значення.
//!  - Для типів, що реалізують [`Default`], метод [`take`](Cell::take) замінює поточне внутрішнє значення на [`Default::default()`] і повертає замінене значення.
//!  - Для всіх типів метод [`replace`](Cell::replace) замінює поточне внутрішнє значення і повертає замінене значення, а метод [`into_inner`](Cell::into_inner) споживає `Cell<T>` і повертає внутрішнє значення.
//!  Крім того, метод [`set`](Cell::set) замінює внутрішнє значення, знижуючи замінене значення.
//!
//! `RefCell<T>` використовує життя Rust для реалізації `` динамічного запозичення ''-процесу, за допомогою якого можна вимагати тимчасовий, ексклюзивний, змінний доступ до внутрішньої цінності.
//! Позики для `RefCell<T>`s відстежуються` `під час виконання '', на відміну від власних типів посилань Rust, які повністю відстежуються статично, під час компіляції.
//! Оскільки позики `RefCell<T>` є динамічними, можна спробувати запозичити вартість, яка вже є позитивно запозиченою;коли це трапляється, це призводить до потоку panic.
//!
//! # Коли вибирати зміну інтер`єру
//!
//! Найпоширеніша успадкована змінність, коли потрібно мати унікальний доступ для мутації значення, є одним з ключових елементів мови, що дозволяє Rust рішуче міркувати про псевдонім вказівника, статично запобігаючи помилкам збою.
//! Через це переважна спадкова мінливість, а внутрішня мінливість є крайнім заходом.
//! Оскільки типи клітин дозволяють мутацію там, де в іншому випадку це було б заборонено, бувають випадки, коли внутрішня змінність може бути доречною, або навіть *потрібно*, наприклад,
//!
//! * Представляємо мінливість 'inside' чогось незмінного
//! * Деталі реалізації логічно незмінних методів.
//! * Мутуючі реалізації [`Clone`].
//!
//! ## Представляємо мінливість 'inside' чогось незмінного
//!
//! Багато спільних типів розумних покажчиків, включаючи [`Rc<T>`] та [`Arc<T>`], забезпечують контейнери, які можна клонувати та спільно використовувати між різними сторонами.
//! Оскільки вміщені значення можуть бути множинними псевдонімами, їх можна запозичувати лише з `&`, а не `&mut`.
//! Без клітинок було б неможливо взагалі мутувати дані всередині цих розумних покажчиків.
//!
//! Тоді дуже часто ставлять `RefCell<T>` всередині спільних типів покажчиків, щоб відновити змінність:
//!
//! ```
//! use std::cell::{RefCell, RefMut};
//! use std::collections::HashMap;
//! use std::rc::Rc;
//!
//! fn main() {
//!     let shared_map: Rc<RefCell<_>> = Rc::new(RefCell::new(HashMap::new()));
//!     // Створіть новий блок, щоб обмежити обсяг динамічного запозичення
//!     {
//!         let mut map: RefMut<_> = shared_map.borrow_mut();
//!         map.insert("africa", 92388);
//!         map.insert("kyoto", 11837);
//!         map.insert("piccadilly", 11826);
//!         map.insert("marbles", 38);
//!     }
//!
//!     // Зауважте, що якби ми не дозволили попередньому запозиченню кеша вийти за межі обсягу, то наступне запозичення призведе до динамічного потоку panic.
//!     //
//!     // Це основна небезпека використання `RefCell`.
//!     let total: i32 = shared_map.borrow().values().sum();
//!     println!("{}", total);
//! }
//! ```
//!
//! Зверніть увагу, що в цьому прикладі використовується `Rc<T>`, а не `Arc<T>`.`RefCell<T>`s призначені для однопотокових сценаріїв.Подумайте про використання [`RwLock<T>`] або [`Mutex<T>`], якщо вам потрібна спільна змінність у багатопотоковій ситуації.
//!
//! ## Деталі реалізації логічно незмінних методів
//!
//! Іноді може виявитися бажаним не викривати в API, що відбувається мутація "under the hood".
//! Це може бути тому, що логічно операція є незмінною, але, наприклад, кешування змушує реалізацію виконувати мутацію;або тому, що ви повинні застосувати мутацію для реалізації методу Portrait, який спочатку було визначено для прийому `&self`.
//!
//!
//! ```
//! # #![allow(dead_code)]
//! use std::cell::RefCell;
//!
//! struct Graph {
//!     edges: Vec<(i32, i32)>,
//!     span_tree_cache: RefCell<Option<Vec<(i32, i32)>>>
//! }
//!
//! impl Graph {
//!     fn minimum_spanning_tree(&self) -> Vec<(i32, i32)> {
//!         self.span_tree_cache.borrow_mut()
//!             .get_or_insert_with(|| self.calc_span_tree())
//!             .clone()
//!     }
//!
//!     fn calc_span_tree(&self) -> Vec<(i32, i32)> {
//!         // Сюди йдуть дорогі обчислення
//!         vec![]
//!     }
//! }
//! ```
//!
//! ## Мутуючі реалізації `Clone`
//!
//! Це просто особливий, але загальний випадок попереднього: приховування змінності для операцій, які здаються незмінними.
//! Очікується, що метод [`clone`](Clone::clone) не змінить вихідне значення, і оголошено, що він приймає `&self`, а не `&mut self`.
//! Тому будь-яка мутація, яка трапляється у методі `clone`, повинна використовувати типи клітин.
//! Наприклад, [`Rc<T>`] підтримує свою кількість посилань у межах `Cell<T>`.
//!
//! ```
//! use std::cell::Cell;
//! use std::ptr::NonNull;
//! use std::process::abort;
//! use std::marker::PhantomData;
//!
//! struct Rc<T: ?Sized> {
//!     ptr: NonNull<RcBox<T>>,
//!     phantom: PhantomData<RcBox<T>>,
//! }
//!
//! struct RcBox<T: ?Sized> {
//!     strong: Cell<usize>,
//!     refcount: Cell<usize>,
//!     value: T,
//! }
//!
//! impl<T: ?Sized> Clone for Rc<T> {
//!     fn clone(&self) -> Rc<T> {
//!         self.inc_strong();
//!         Rc {
//!             ptr: self.ptr,
//!             phantom: PhantomData,
//!         }
//!     }
//! }
//!
//! trait RcBoxPtr<T: ?Sized> {
//!
//!     fn inner(&self) -> &RcBox<T>;
//!
//!     fn strong(&self) -> usize {
//!         self.inner().strong.get()
//!     }
//!
//!     fn inc_strong(&self) {
//!         self.inner()
//!             .strong
//!             .set(self.strong()
//!                      .checked_add(1)
//!                      .unwrap_or_else(|| abort() ));
//!     }
//! }
//!
//! impl<T: ?Sized> RcBoxPtr<T> for Rc<T> {
//!    fn inner(&self) -> &RcBox<T> {
//!        unsafe {
//!            self.ptr.as_ref()
//!        }
//!    }
//! }
//! ```
//!
//! [`Arc<T>`]: ../../std/sync/struct.Arc.html
//! [`Rc<T>`]: ../../std/rc/struct.Rc.html
//! [`RwLock<T>`]: ../../std/sync/struct.RwLock.html
//! [`Mutex<T>`]: ../../std/sync/struct.Mutex.html
//! [`atomic`]: ../../core/sync/atomic/index.html
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering;
use crate::fmt::{self, Debug, Display};
use crate::marker::Unsize;
use crate::mem;
use crate::ops::{CoerceUnsized, Deref, DerefMut};
use crate::ptr;

/// Змінюване місце пам'яті.
///
/// # Examples
///
/// У цьому прикладі ви можете бачити, що `Cell<T>` дозволяє мутувати всередині незмінної структури.
/// Іншими словами, це дозволяє "interior mutability".
///
/// ```
/// use std::cell::Cell;
///
/// struct SomeStruct {
///     regular_field: u8,
///     special_field: Cell<u8>,
/// }
///
/// let my_struct = SomeStruct {
///     regular_field: 0,
///     special_field: Cell::new(1),
/// };
///
/// let new_value = 100;
///
/// // ПОМИЛКА: `my_struct` незмінний
/// // my_struct.regular_field =нове_значення;
///
/// // РОБОТИ: хоча `my_struct` є незмінним, `special_field` є `Cell`,
/// // який завжди можна мутувати
/// my_struct.special_field.set(new_value);
/// assert_eq!(my_struct.special_field.get(), new_value);
/// ```
///
/// Докладніше див. У [module-level documentation](self).
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
pub struct Cell<T: ?Sized> {
    value: UnsafeCell<T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for Cell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for Cell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Copy> Clone for Cell<T> {
    #[inline]
    fn clone(&self) -> Cell<T> {
        Cell::new(self.get())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Cell<T> {
    /// Створює `Cell<T>` зі значенням `Default` для T.
    #[inline]
    fn default() -> Cell<T> {
        Cell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialEq + Copy> PartialEq for Cell<T> {
    #[inline]
    fn eq(&self, other: &Cell<T>) -> bool {
        self.get() == other.get()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: Eq + Copy> Eq for Cell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: PartialOrd + Copy> PartialOrd for Cell<T> {
    #[inline]
    fn partial_cmp(&self, other: &Cell<T>) -> Option<Ordering> {
        self.get().partial_cmp(&other.get())
    }

    #[inline]
    fn lt(&self, other: &Cell<T>) -> bool {
        self.get() < other.get()
    }

    #[inline]
    fn le(&self, other: &Cell<T>) -> bool {
        self.get() <= other.get()
    }

    #[inline]
    fn gt(&self, other: &Cell<T>) -> bool {
        self.get() > other.get()
    }

    #[inline]
    fn ge(&self, other: &Cell<T>) -> bool {
        self.get() >= other.get()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: Ord + Copy> Ord for Cell<T> {
    #[inline]
    fn cmp(&self, other: &Cell<T>) -> Ordering {
        self.get().cmp(&other.get())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for Cell<T> {
    fn from(t: T) -> Cell<T> {
        Cell::new(t)
    }
}

impl<T> Cell<T> {
    /// Створює новий `Cell`, що містить задане значення.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> Cell<T> {
        Cell { value: UnsafeCell::new(value) }
    }

    /// Встановлює вміщене значення.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// c.set(10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn set(&self, val: T) {
        let old = self.replace(val);
        drop(old);
    }

    /// Змінює значення двох клітинок.
    /// Відмінність від `std::mem::swap` полягає в тому, що ця функція не вимагає посилання на `&mut`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c1 = Cell::new(5i32);
    /// let c2 = Cell::new(10i32);
    /// c1.swap(&c2);
    /// assert_eq!(10, c1.get());
    /// assert_eq!(5, c2.get());
    /// ```
    #[inline]
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn swap(&self, other: &Self) {
        if ptr::eq(self, other) {
            return;
        }
        // БЕЗПЕКА: Це може бути ризиковано, якщо викликати з окремих потоків, але `Cell`
        // є `!Sync`, тож цього не станеться.
        // Це також не призведе до втрати жодних покажчиків, оскільки `Cell` гарантує, що ніщо інше не вказує на жоден із цих `комірок`.
        //
        unsafe {
            ptr::swap(self.value.get(), other.value.get());
        }
    }

    /// Замінює вміщене значення на `val` і повертає старе вміщене значення.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let cell = Cell::new(5);
    /// assert_eq!(cell.get(), 5);
    /// assert_eq!(cell.replace(10), 5);
    /// assert_eq!(cell.get(), 10);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn replace(&self, val: T) -> T {
        // БЕЗПЕКА: Це може спричинити гонки даних, якщо їх викликати з окремого потоку,
        // але `Cell`-це `!Sync`, тому цього не станеться.
        mem::replace(unsafe { &mut *self.value.get() }, val)
    }

    /// Розгортає значення.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.into_inner();
    ///
    /// assert_eq!(five, 5);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value.into_inner()
    }
}

impl<T: Copy> Cell<T> {
    /// Повертає копію вміщеного значення.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let five = c.get();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get(&self) -> T {
        // БЕЗПЕКА: Це може спричинити гонки даних, якщо їх викликати з окремого потоку,
        // але `Cell`-це `!Sync`, тому цього не станеться.
        unsafe { *self.value.get() }
    }

    /// Оновлює вміщене значення за допомогою функції і повертає нове значення.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_update)]
    ///
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let new = c.update(|x| x + 1);
    ///
    /// assert_eq!(new, 6);
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[unstable(feature = "cell_update", issue = "50186")]
    pub fn update<F>(&self, f: F) -> T
    where
        F: FnOnce(T) -> T,
    {
        let old = self.get();
        let new = f(old);
        self.set(new);
        new
    }
}

impl<T: ?Sized> Cell<T> {
    /// Повертає необроблений вказівник на базові дані в цій комірці.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    #[rustc_const_stable(feature = "const_cell_as_ptr", since = "1.32.0")]
    pub const fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// Повертає змінне посилання на базові дані.
    ///
    /// Цей дзвінок запозичує `Cell` мутативно (під час компіляції), що гарантує, що ми маємо єдине посилання.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let mut c = Cell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// Повертає `&Cell<T>` з `&mut T`
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[inline]
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn from_mut(t: &mut T) -> &Cell<T> {
        // БЕЗПЕКА: `&mut` забезпечує унікальний доступ.
        unsafe { &*(t as *mut T as *const Cell<T>) }
    }
}

impl<T: Default> Cell<T> {
    /// Приймає значення комірки, залишаючи `Default::default()` на своєму місці.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<Cell<U>> for Cell<T> {}

impl<T> Cell<[T]> {
    /// Повертає `&[Cell<T>]` з `&Cell<[T]>`
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn as_slice_of_cells(&self) -> &[Cell<T>] {
        // БЕЗПЕКА: `Cell<T>` має таку ж форму пам'яті, як і `T`.
        unsafe { &*(self as *const Cell<[T]> as *const [Cell<T>]) }
    }
}

/// Змінюване розташування пам'яті з динамічно перевіреними правилами запозичення
///
/// Докладніше див. У [module-level documentation](self).
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefCell<T: ?Sized> {
    borrow: Cell<BorrowFlag>,
    value: UnsafeCell<T>,
}

/// Помилка, повернута [`RefCell::try_borrow`].
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already mutably borrowed", f)
    }
}

/// Помилка, повернута [`RefCell::try_borrow_mut`].
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowMutError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowMutError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already borrowed", f)
    }
}

// Позитивні значення представляють кількість активних `Ref`.Негативні значення представляють кількість активних `RefMut`.
// Кілька `RefMut` можуть бути активними одночасно, лише якщо вони посилаються на окремі компоненти `RefCell`, що не перекриваються (наприклад, різні діапазони фрагмента).
//
// `Ref` і `RefMut`-це обидва слова за розміром, тому, мабуть, ніколи не буде достатньо `Ref`s або`RefMut`s, щоб переповнити половину діапазону `usize`.
// Таким чином, `BorrowFlag`, мабуть, ніколи не переллється і не переллється.
// Однак це не гарантія, оскільки патологічна програма може неодноразово створювати, а потім mem::forget `Ref`s або`RefMut`s.
// Таким чином, весь код повинен явно перевіряти наявність переповнення та недоливу, щоб уникнути небезпеки або, принаймні, правильно поводитись у випадку, якщо трапляється переповнення або недоповнення (наприклад, див. BorrowRef::new).
//
//
//
//
//
//
type BorrowFlag = isize;
const UNUSED: BorrowFlag = 0;

#[inline(always)]
fn is_writing(x: BorrowFlag) -> bool {
    x < UNUSED
}

#[inline(always)]
fn is_reading(x: BorrowFlag) -> bool {
    x > UNUSED
}

impl<T> RefCell<T> {
    /// Створює новий `RefCell`, що містить `value`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_refcell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> RefCell<T> {
        RefCell { value: UnsafeCell::new(value), borrow: Cell::new(UNUSED) }
    }

    /// Споживає `RefCell`, повертаючи загорнуте значення.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let five = c.into_inner();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    #[inline]
    pub const fn into_inner(self) -> T {
        // Оскільки ця функція приймає `self` (`RefCell`) за значенням, компілятор статично перевіряє, що вона наразі не запозичена.
        //
        self.value.into_inner()
    }

    /// Замінює загорнуте значення новим, повертаючи старе значення, не деініціалізуючи жодне.
    ///
    ///
    /// Ця функція відповідає [`std::mem::replace`](../mem/fn.replace.html).
    ///
    /// # Panics
    ///
    /// Panics, якщо вартість наразі запозичена.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace(6);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace", since = "1.24.0")]
    #[track_caller]
    pub fn replace(&self, t: T) -> T {
        mem::replace(&mut *self.borrow_mut(), t)
    }

    /// Замінює загорнуте значення новим, обчисленим з `f`, повертаючи старе значення, не деініціалізуючи жодне.
    ///
    ///
    /// # Panics
    ///
    /// Panics, якщо вартість наразі запозичена.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace_with(|&mut old| old + 1);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace_swap", since = "1.35.0")]
    #[track_caller]
    pub fn replace_with<F: FnOnce(&mut T) -> T>(&self, f: F) -> T {
        let mut_borrow = &mut *self.borrow_mut();
        let replacement = f(mut_borrow);
        mem::replace(mut_borrow, replacement)
    }

    /// Змінює обернене значення `self` із загорнутим значенням `other`, не деініціалізуючи жодне.
    ///
    ///
    /// Ця функція відповідає [`std::mem::swap`](../mem/fn.swap.html).
    ///
    /// # Panics
    ///
    /// Panics, якщо значення в будь-якому з `RefCell` наразі запозичене.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let c = RefCell::new(5);
    /// let d = RefCell::new(6);
    /// c.swap(&d);
    /// assert_eq!(c, RefCell::new(6));
    /// assert_eq!(d, RefCell::new(5));
    /// ```
    #[inline]
    #[stable(feature = "refcell_swap", since = "1.24.0")]
    pub fn swap(&self, other: &Self) {
        mem::swap(&mut *self.borrow_mut(), &mut *other.borrow_mut())
    }
}

impl<T: ?Sized> RefCell<T> {
    /// Незмінно запозичує загорнуте значення.
    ///
    /// Позика триває доти, доки повернутий `Ref` не вийде із зони дії.
    /// Одночасно можна взяти кілька незмінних запозичень.
    ///
    /// # Panics
    ///
    /// Panics, якщо вартість наразі є позитивно запозиченою.
    /// Для панічного варіанту використовуйте [`try_borrow`](#method.try_borrow).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let borrowed_five = c.borrow();
    /// let borrowed_five2 = c.borrow();
    /// ```
    ///
    /// Приклад panic:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let m = c.borrow_mut();
    /// let b = c.borrow(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow(&self) -> Ref<'_, T> {
        self.try_borrow().expect("already mutably borrowed")
    }

    /// Незмінно запозичує загорнуте значення, повертаючи помилку, якщо значення в даний час є запозиченим із можливістю змін.
    ///
    ///
    /// Позика триває доти, доки повернутий `Ref` не вийде із зони дії.
    /// Одночасно можна взяти кілька незмінних запозичень.
    ///
    /// Це не панічний варіант [`borrow`](#method.borrow).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(c.try_borrow().is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow().is_ok());
    /// }
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow(&self) -> Result<Ref<'_, T>, BorrowError> {
        match BorrowRef::new(&self.borrow) {
            // БЕЗПЕКА: `BorrowRef` гарантує лише незмінний доступ
            // до вартості під час позики.
            Some(b) => Ok(Ref { value: unsafe { &*self.value.get() }, borrow: b }),
            None => Err(BorrowError { _private: () }),
        }
    }

    /// Змінно запозичує загорнуте значення.
    ///
    /// Позика триває до повернення `RefMut` або всіх `RefMut`, отриманих з нього, з області виходу.
    ///
    /// Вартість не може бути позичена, поки ця позика активна.
    ///
    /// # Panics
    ///
    /// Panics, якщо вартість наразі запозичена.
    /// Для панічного варіанту використовуйте [`try_borrow_mut`](#method.try_borrow_mut).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new("hello".to_owned());
    ///
    /// *c.borrow_mut() = "bonjour".to_owned();
    ///
    /// assert_eq!(&*c.borrow(), "bonjour");
    /// ```
    ///
    /// Приклад panic:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let m = c.borrow();
    ///
    /// let b = c.borrow_mut(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow_mut(&self) -> RefMut<'_, T> {
        self.try_borrow_mut().expect("already borrowed")
    }

    /// Змінно запозичує загорнуте значення, повертаючи помилку, якщо значення в даний момент запозичене.
    ///
    ///
    /// Позика триває до повернення `RefMut` або всіх `RefMut`, отриманих з нього, з області виходу.
    /// Вартість не може бути позичена, поки ця позика активна.
    ///
    /// Це не панічний варіант [`borrow_mut`](#method.borrow_mut).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow_mut().is_err());
    /// }
    ///
    /// assert!(c.try_borrow_mut().is_ok());
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow_mut(&self) -> Result<RefMut<'_, T>, BorrowMutError> {
        match BorrowRefMut::new(&self.borrow) {
            // БЕЗПЕКА: `BorrowRef` гарантує унікальний доступ.
            Some(b) => Ok(RefMut { value: unsafe { &mut *self.value.get() }, borrow: b }),
            None => Err(BorrowMutError { _private: () }),
        }
    }

    /// Повертає необроблений вказівник на базові дані в цій комірці.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    pub fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// Повертає змінне посилання на базові дані.
    ///
    /// Цей виклик запозичує `RefCell` мутативно (під час компіляції), тому немає необхідності в динамічних перевірках.
    ///
    /// Однак будьте обережні: цей метод передбачає, що `self` може бути змінним, що, як правило, не буває при використанні `RefCell`.
    ///
    /// Погляньте натомість на метод [`borrow_mut`], якщо `self` не змінюється.
    ///
    /// Крім того, пам`ятайте, що цей метод призначений лише для особливих обставин і зазвичай не є тим, що ви хочете.
    /// У разі сумнівів використовуйте замість цього [`borrow_mut`].
    ///
    /// [`borrow_mut`]: RefCell::borrow_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c, RefCell::new(6));
    /// ```
    ///
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// Скасувати вплив витоку захисних пристроїв на стан позики `RefCell`.
    ///
    /// Цей дзвінок схожий на [`get_mut`], але більш спеціалізований.
    /// Він запозичує `RefCell` мутативно, щоб забезпечити відсутність запозичень, а потім скидає стан відстеження спільних запозичень.
    /// Це актуально, якщо деякі позики `Ref` або `RefMut` просочились.
    ///
    /// [`get_mut`]: RefCell::get_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(0);
    /// std::mem::forget(c.borrow_mut());
    ///
    /// assert!(c.try_borrow().is_err());
    /// c.undo_leak();
    /// assert!(c.try_borrow().is_ok());
    /// ```
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn undo_leak(&mut self) -> &mut T {
        *self.borrow.get_mut() = UNUSED;
        self.get_mut()
    }

    /// Незмінно запозичує загорнуте значення, повертаючи помилку, якщо значення в даний час є запозиченим із можливістю змін.
    ///
    /// # Safety
    ///
    /// На відміну від `RefCell::borrow`, цей метод небезпечний, оскільки не повертає `Ref`, залишаючи таким чином прапор позики недоторканим.
    /// Позичення `RefCell`, коли посилання, яке повертається цим методом, є змінним, є невизначеною поведінкою.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_ok());
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "borrow_state", since = "1.37.0")]
    #[inline]
    pub unsafe fn try_borrow_unguarded(&self) -> Result<&T, BorrowError> {
        if !is_writing(self.borrow.get()) {
            // БЕЗПЕКА: Ми перевіряємо, що зараз ніхто активно не пише, але це так
            // відповідальність абонента забезпечити, щоб ніхто не писав, поки повернуте посилання більше не використовується.
            // Крім того, `self.value.get()` посилається на вартість, якою володіє `self`, і, таким чином, гарантується, що вона дійсна протягом усього життя `self`.
            //
            //
            Ok(unsafe { &*self.value.get() })
        } else {
            Err(BorrowError { _private: () })
        }
    }
}

impl<T: Default> RefCell<T> {
    /// Бере обгорнуте значення, залишаючи `Default::default()` на своєму місці.
    ///
    /// # Panics
    ///
    /// Panics, якщо вартість наразі запозичена.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "refcell_take", since = "1.50.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for RefCell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for RefCell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for RefCell<T> {
    /// # Panics
    ///
    /// Panics, якщо вартість наразі є позитивно запозиченою.
    #[inline]
    #[track_caller]
    fn clone(&self) -> RefCell<T> {
        RefCell::new(self.borrow().clone())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for RefCell<T> {
    /// Створює `RefCell<T>` зі значенням `Default` для T.
    #[inline]
    fn default() -> RefCell<T> {
        RefCell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for RefCell<T> {
    /// # Panics
    ///
    /// Panics, якщо значення в будь-якому з `RefCell` наразі запозичене.
    #[inline]
    fn eq(&self, other: &RefCell<T>) -> bool {
        *self.borrow() == *other.borrow()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: ?Sized + Eq> Eq for RefCell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for RefCell<T> {
    /// # Panics
    ///
    /// Panics, якщо значення в будь-якому з `RefCell` наразі запозичене.
    #[inline]
    fn partial_cmp(&self, other: &RefCell<T>) -> Option<Ordering> {
        self.borrow().partial_cmp(&*other.borrow())
    }

    /// # Panics
    ///
    /// Panics, якщо значення в будь-якому з `RefCell` наразі запозичене.
    #[inline]
    fn lt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() < *other.borrow()
    }

    /// # Panics
    ///
    /// Panics, якщо значення в будь-якому з `RefCell` наразі запозичене.
    #[inline]
    fn le(&self, other: &RefCell<T>) -> bool {
        *self.borrow() <= *other.borrow()
    }

    /// # Panics
    ///
    /// Panics, якщо значення в будь-якому з `RefCell` наразі запозичене.
    #[inline]
    fn gt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() > *other.borrow()
    }

    /// # Panics
    ///
    /// Panics, якщо значення в будь-якому з `RefCell` наразі запозичене.
    #[inline]
    fn ge(&self, other: &RefCell<T>) -> bool {
        *self.borrow() >= *other.borrow()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + Ord> Ord for RefCell<T> {
    /// # Panics
    ///
    /// Panics, якщо значення в будь-якому з `RefCell` наразі запозичене.
    #[inline]
    fn cmp(&self, other: &RefCell<T>) -> Ordering {
        self.borrow().cmp(&*other.borrow())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for RefCell<T> {
    fn from(t: T) -> RefCell<T> {
        RefCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<RefCell<U>> for RefCell<T> {}

struct BorrowRef<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl<'b> BorrowRef<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRef<'b>> {
        let b = borrow.get().wrapping_add(1);
        if !is_reading(b) {
            // Збільшення запозичення може призвести до значення, яке не читається (<=0) у таких випадках:
            // 1. Це було <0, тобто є запозичення для написання, тому ми не можемо дозволити запозичення для читання через правила згладжування посилань Rust
            // 2.
            // Це був isize::MAX (максимальна кількість запозичень для читання), і він перелився у isize::MIN (максимальний обсяг запозичень для написання), тому ми не можемо дозволити додаткове запозичення для читання, оскільки isize не може представляти стільки прочитаних запозичень (це може статися, лише якщо ви mem::forget більше, ніж невелика постійна кількість `Ref`s, що не є доброю практикою)
            //
            //
            //
            //
            None
        } else {
            // Збільшення запозичення може призвести до значення зчитування (> 0) у таких випадках:
            // 1. Це було=0, тобто воно не було запозичене, і ми беремо перший прочитаний запозичення
            // 2. Було> 0 і <isize::MAX, тобто
            // були прочитані запозичення, а isize достатньо великий, щоб відображати наявність ще одного прочитаного запозичення
            borrow.set(b);
            Some(BorrowRef { borrow })
        }
    }
}

impl Drop for BorrowRef<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        self.borrow.set(borrow - 1);
    }
}

impl Clone for BorrowRef<'_> {
    #[inline]
    fn clone(&self) -> Self {
        // Оскільки цей посилання існує, ми знаємо, що прапор запозичення є запозиченням для читання.
        //
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        // Запобігайте переповненню лічильника запозичень у позику, що пишеться.
        //
        assert!(borrow != isize::MAX);
        self.borrow.set(borrow + 1);
        BorrowRef { borrow: self.borrow }
    }
}

/// Обертає запозичене посилання на значення у вікні `RefCell`.
/// Тип обгортки для незмінно запозиченого значення у `RefCell<T>`.
///
/// Докладніше див. У [module-level documentation](self).
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Ref<'b, T: ?Sized + 'b> {
    value: &'b T,
    borrow: BorrowRef<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Ref<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

impl<'b, T: ?Sized> Ref<'b, T> {
    /// Копіює `Ref`.
    ///
    /// `RefCell` вже незмінно запозичений, тому це не може провалитися.
    ///
    /// Це пов`язана функція, яку потрібно використовувати як `Ref::clone(...)`.
    /// Реалізація `Clone` або метод заважатимуть широкому використанню `r.borrow().clone()` для клонування вмісту `RefCell`.
    ///
    ///
    #[stable(feature = "cell_extras", since = "1.15.0")]
    #[inline]
    pub fn clone(orig: &Ref<'b, T>) -> Ref<'b, T> {
        Ref { value: orig.value, borrow: orig.borrow.clone() }
    }

    /// Робить новий `Ref` для компонента запозичених даних.
    ///
    /// `RefCell` вже незмінно запозичений, тому це не може провалитися.
    ///
    /// Це пов`язана функція, яку потрібно використовувати як `Ref::map(...)`.
    /// Метод може заважати однойменним методам вмісту `RefCell`, що використовується через `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// let b1: Ref<(u32, char)> = c.borrow();
    /// let b2: Ref<u32> = Ref::map(b1, |t| &t.0);
    /// assert_eq!(*b2, 5)
    /// ```
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Ref<'b, U>
    where
        F: FnOnce(&T) -> &U,
    {
        Ref { value: f(orig.value), borrow: orig.borrow }
    }

    /// Робить новий `Ref` для додаткового компонента запозичених даних.
    /// Оригінальний захист повертається як `Err(..)`, якщо закриття повертає `None`.
    ///
    /// `RefCell` вже незмінно запозичений, тому це не може провалитися.
    ///
    /// Це пов`язана функція, яку потрібно використовувати як `Ref::filter_map(...)`.
    /// Метод може заважати однойменним методам вмісту `RefCell`, що використовується через `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    /// let b1: Ref<Vec<u32>> = c.borrow();
    /// let b2: Result<Ref<u32>, _> = Ref::filter_map(b1, |v| v.get(1));
    /// assert_eq!(*b2.unwrap(), 2);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Result<Ref<'b, U>, Self>
    where
        F: FnOnce(&T) -> Option<&U>,
    {
        match f(orig.value) {
            Some(value) => Ok(Ref { value, borrow: orig.borrow }),
            None => Err(orig),
        }
    }

    /// Розбиває `Ref` на кілька `Ref` для різних компонентів запозичених даних.
    ///
    /// `RefCell` вже незмінно запозичений, тому це не може провалитися.
    ///
    /// Це пов`язана функція, яку потрібно використовувати як `Ref::map_split(...)`.
    /// Метод може заважати однойменним методам вмісту `RefCell`, що використовується через `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{Ref, RefCell};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow();
    /// let (begin, end) = Ref::map_split(borrow, |slice| slice.split_at(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// ```
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(orig: Ref<'b, T>, f: F) -> (Ref<'b, U>, Ref<'b, V>)
    where
        F: FnOnce(&T) -> (&U, &V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (Ref { value: a, borrow }, Ref { value: b, borrow: orig.borrow })
    }

    /// Перетворити на посилання на базові дані.
    ///
    /// Базовий `RefCell` ніколи не може бути запозичений із змінним запозиченням і завжди буде здаватися вже незмінно запозиченим.
    ///
    /// Це не гарна ідея витікати більше, ніж постійна кількість посилань.
    /// `RefCell` може бути незмінно запозичений ще раз, якщо загалом виникла лише менша кількість витоків.
    ///
    /// Це пов`язана функція, яку потрібно використовувати як `Ref::leak(...)`.
    /// Метод може заважати однойменним методам вмісту `RefCell`, що використовується через `Deref`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, Ref};
    /// let cell = RefCell::new(0);
    ///
    /// let value = Ref::leak(cell.borrow());
    /// assert_eq!(*value, 0);
    ///
    /// assert!(cell.try_borrow().is_ok());
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: Ref<'b, T>) -> &'b T {
        // Забувши це посилання, ми гарантуємо, що лічильник запозичень у RefCell не може повернутися до НЕВИКОРИСТОВАНО протягом усього життя `'b`.
        // Скидання стану відстеження посилань потребує унікального посилання на запозичену RefCell.
        // З оригінальної комірки неможливо створити подальших змінних посилань.
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Ref<'b, U>> for Ref<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Ref<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

impl<'b, T: ?Sized> RefMut<'b, T> {
    /// Робить новий `RefMut` для компонента запозичених даних, наприклад, варіанту перерахування.
    ///
    /// `RefCell` вже позитивно запозичений, тому це не може провалитися.
    ///
    /// Це пов`язана функція, яку потрібно використовувати як `RefMut::map(...)`.
    /// Метод може заважати однойменним методам вмісту `RefCell`, що використовується через `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// {
    ///     let b1: RefMut<(u32, char)> = c.borrow_mut();
    ///     let mut b2: RefMut<u32> = RefMut::map(b1, |t| &mut t.0);
    ///     assert_eq!(*b2, 5);
    ///     *b2 = 42;
    /// }
    /// assert_eq!(*c.borrow(), (42, 'b'));
    /// ```
    ///
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> RefMut<'b, U>
    where
        F: FnOnce(&mut T) -> &mut U,
    {
        // FIXME(nll-rfc#40): виправити запозичення-чек
        let RefMut { value, borrow } = orig;
        RefMut { value: f(value), borrow }
    }

    /// Робить новий `RefMut` для додаткового компонента запозичених даних.
    /// Оригінальний захист повертається як `Err(..)`, якщо закриття повертає `None`.
    ///
    /// `RefCell` вже позитивно запозичений, тому це не може провалитися.
    ///
    /// Це пов`язана функція, яку потрібно використовувати як `RefMut::filter_map(...)`.
    /// Метод може заважати однойменним методам вмісту `RefCell`, що використовується через `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    ///
    /// {
    ///     let b1: RefMut<Vec<u32>> = c.borrow_mut();
    ///     let mut b2: Result<RefMut<u32>, _> = RefMut::filter_map(b1, |v| v.get_mut(1));
    ///
    ///     if let Ok(mut b2) = b2 {
    ///         *b2 += 2;
    ///     }
    /// }
    ///
    /// assert_eq!(*c.borrow(), vec![1, 4, 3]);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> Result<RefMut<'b, U>, Self>
    where
        F: FnOnce(&mut T) -> Option<&mut U>,
    {
        // FIXME(nll-rfc#40): виправити запозичення-чек
        let RefMut { value, borrow } = orig;
        let value = value as *mut T;
        // БЕЗПЕКА: функція тримається на ексклюзивному еталоні протягом часу
        // свого виклику через `orig`, а покажчик не має посилання всередині виклику функції, ніколи не дозволяючи ексклюзивному посиланню вийти.
        //
        //
        match f(unsafe { &mut *value }) {
            Some(value) => Ok(RefMut { value, borrow }),
            None => {
                // БЕЗПЕКА: те саме, що і вище.
                Err(RefMut { value: unsafe { &mut *value }, borrow })
            }
        }
    }

    /// Розбиває `RefMut` на кілька `RefMut` для різних компонентів запозичених даних.
    ///
    /// Базовий `RefCell` залишатиметься позитивно запозиченим, поки обидва повернуті `RefMut` не вийдуть за межі обсягу.
    ///
    /// `RefCell` вже позитивно запозичений, тому це не може провалитися.
    ///
    /// Це пов`язана функція, яку потрібно використовувати як `RefMut::map_split(...)`.
    /// Метод може заважати однойменним методам вмісту `RefCell`, що використовується через `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow_mut();
    /// let (mut begin, mut end) = RefMut::map_split(borrow, |slice| slice.split_at_mut(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// begin.copy_from_slice(&[4, 3]);
    /// end.copy_from_slice(&[2, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(
        orig: RefMut<'b, T>,
        f: F,
    ) -> (RefMut<'b, U>, RefMut<'b, V>)
    where
        F: FnOnce(&mut T) -> (&mut U, &mut V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (RefMut { value: a, borrow }, RefMut { value: b, borrow: orig.borrow })
    }

    /// Перетворити на змінне посилання на базові дані.
    ///
    /// Базовий `RefCell` не можна знову запозичити, і він завжди буде виглядати вже запозиченим, що робить повернене посилання єдиним до інтер`єру.
    ///
    ///
    /// Це пов`язана функція, яку потрібно використовувати як `RefMut::leak(...)`.
    /// Метод може заважати однойменним методам вмісту `RefCell`, що використовується через `Deref`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, RefMut};
    /// let cell = RefCell::new(0);
    ///
    /// let value = RefMut::leak(cell.borrow_mut());
    /// assert_eq!(*value, 0);
    /// *value = 1;
    ///
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: RefMut<'b, T>) -> &'b mut T {
        // Забувши цей BorrowRefMut, ми гарантуємо, що лічильник запозичень у RefCell не може повернутися до НЕВИКОРИСТАНИХ протягом усього `'b`.
        // Скидання стану відстеження посилань потребує унікального посилання на запозичену RefCell.
        // Жодні подальші посилання не можуть бути створені з вихідної комірки протягом цього періоду життя, що робить поточне запозичення єдиним посиланням на решту життя.
        //
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

struct BorrowRefMut<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl Drop for BorrowRefMut<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        self.borrow.set(borrow + 1);
    }
}

impl<'b> BorrowRefMut<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRefMut<'b>> {
        // NOTE: На відміну від BorrowRefMut::clone, new створюється для створення початкового
        // змінне посилання, і тому наразі не повинно бути існуючих посилань.
        // Таким чином, хоча клон збільшує змінний підрахунок, тут ми явно дозволяємо лише перехід від НЕВИКОРИСТАНОГО до НЕВИКОРИСТАНОГО, 1.
        //
        match borrow.get() {
            UNUSED => {
                borrow.set(UNUSED - 1);
                Some(BorrowRefMut { borrow })
            }
            _ => None,
        }
    }

    // Клонує `BorrowRefMut`.
    //
    // Це дійсно лише в тому випадку, якщо кожен `BorrowRefMut` використовується для відстеження змінної посилання на окремий діапазон вихідного об'єкта, що не перекривається.
    //
    // Це не в імплементі Clone, тому код не називає це неявно.
    #[inline]
    fn clone(&self) -> BorrowRefMut<'b> {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        // Запобігання заповненню лічильника запозичень.
        assert!(borrow != isize::MIN);
        self.borrow.set(borrow - 1);
        BorrowRefMut { borrow: self.borrow }
    }
}

/// Тип обгортки для запозиченого значення із `RefCell<T>`.
///
/// Докладніше див. У [module-level documentation](self).
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefMut<'b, T: ?Sized + 'b> {
    value: &'b mut T,
    borrow: BorrowRefMut<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for RefMut<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for RefMut<'_, T> {
    #[inline]
    fn deref_mut(&mut self) -> &mut T {
        self.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<RefMut<'b, U>> for RefMut<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for RefMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

/// Основний примітив для змінності інтер`єру в Rust.
///
/// Якщо у вас є посилання `&T`, то зазвичай у Rust компілятор виконує оптимізацію на основі знань, що `&T` вказує на незмінні дані.Мутація цих даних, наприклад, через псевдонім або перетворення `&T` у `&mut T`, вважається невизначеною поведінкою.
/// `UnsafeCell<T>` відмова від гарантії незмінності для `&T`: спільне посилання `&UnsafeCell<T>` може вказувати на дані, які мутуються.Це називається "interior mutability".
///
/// Усі інші типи, що допускають внутрішню змінність, такі як `Cell<T>` та `RefCell<T>`, внутрішньо використовують `UnsafeCell` для обтікання своїх даних.
///
/// Зауважте, що `UnsafeCell` впливає лише на гарантію незмінності для спільних посилань.Гарантія унікальності для змінних посилань не змінюється.Не існує *жодного* легального способу отримання псевдонімів `&mut`, навіть у `UnsafeCell<T>`.
///
/// Сам по собі API `UnsafeCell` дуже простий: [`.get()`] дає вам вихідний вказівник `*mut T` на його вміст.Як дизайнер абстракції правильно використовувати цей вихідний вказівник залежить від _you_.
///
/// [`.get()`]: `UnsafeCell::get`
///
/// Точні правила псевдонімів Rust дещо змінюються, але основні моменти не суперечливі:
///
/// - Якщо ви створюєте безпечне посилання за весь час `'a` (або посилання `&T` або `&mut T`), яке доступне за безпечним кодом (наприклад, тому що ви його повернули), тоді ви не повинні отримувати доступ до даних будь-яким способом, що суперечить цьому посиланню для решти `'a`.
/// Наприклад, це означає, що якщо взяти `*mut T` із `UnsafeCell<T>` і передати його на `&T`, тоді дані в `T` повинні залишатися незмінними (звичайно, за даними `UnsafeCell`, знайденими в `T`), поки не закінчиться термін служби цього посилання.
/// Подібним чином, якщо ви створюєте посилання `&mut T`, яке випускається до безпечного коду, тоді ви не повинні отримувати доступ до даних у `UnsafeCell` до закінчення терміну дії цього посилання.
///
/// - У будь-який час потрібно уникати гонок даних.Якщо кілька потоків мають доступ до одного і того ж `UnsafeCell`, тоді будь-які записи повинні мати належне відношення до всіх інших звернень (або використовувати атомічні дані).
///
/// Для сприяння правильному проектуванню, наступні сценарії явно оголошені законними для однопотокового коду:
///
/// 1. Посилання на `&T` може бути випущено в безпечний код і там воно може існувати разом з іншими посиланнями на `&T`, але не з `&mut T`
///
/// 2. Посилання на `&mut T` може бути передано безпечному коду за умови, що з ним не співіснують ні інші `&mut T`, ні `&T`.`&mut T` завжди повинен бути унікальним.
///
/// Зверніть увагу, що, хоча мутація вмісту `&UnsafeCell<T>` (навіть тоді, коли інші `&UnsafeCell<T>` посилаються на псевдонім комірки) є нормальною (за умови, що ви застосовуєте вищезазначені інваріанти іншим чином), все ще не визначено поведінку, щоб мати кілька аліасів `&mut UnsafeCell<T>`.
/// Тобто, `UnsafeCell`-це обгортка, призначена для особливої взаємодії з _shared_ accesses (_i.e._ через посилання `&UnsafeCell<_>`);немає ніякої магії, коли йдеться про _exclusive_ accesses (_e.g._, через `&mut UnsafeCell<_>`): ні клітинка, ні загорнуте значення не можуть бути псевдонімами протягом часу запозичення `&mut`.
///
/// Це демонструє аксесуар [`.get_mut()`], який є _safe_ getter, що дає `&mut T`.
///
/// [`.get_mut()`]: `UnsafeCell::get_mut`
///
/// # Examples
///
/// Ось приклад, що демонструє, як звучно мутувати вміст `UnsafeCell<_>`, незважаючи на те, що кілька посилань псевдонімить клітинку:
///
/// ```
/// use std::cell::UnsafeCell;
///
/// let x: UnsafeCell<i32> = 42.into();
/// // Отримайте кілька/одночасних/спільних посилань на один і той же `x`.
/// let (p1, p2): (&UnsafeCell<i32>, &UnsafeCell<i32>) = (&x, &x);
///
/// unsafe {
///     // БЕЗПЕКА: в рамках цієї сфери немає жодних посилань на вміст `x`,
///     // тож наш фактично унікальний.
///     let p1_exclusive: &mut i32 = &mut *p1.get(); // -- позичити-+
///     *p1_exclusive += 27; // |
/// } // <---------- не може вийти за межі цієї точки -------------------+
///
/// unsafe {
///     // БЕЗПЕКА: в рамках цієї сфери ніхто не розраховує на ексклюзивний доступ до вмісту `x`,
///     // так що ми можемо мати одночасно кілька спільних доступів.
///     let p2_shared: &i32 = &*p2.get();
///     assert_eq!(*p2_shared, 42 + 27);
///     let p1_shared: &i32 = &*p1.get();
///     assert_eq!(*p1_shared, *p2_shared);
/// }
/// ```
///
/// Наступний приклад демонструє той факт, що ексклюзивний доступ до `UnsafeCell<T>` передбачає ексклюзивний доступ до його `T`:
///
/// ```rust
/// #![forbid(unsafe_code)] // з ексклюзивним доступом,
///                         // `UnsafeCell` є прозорою обгорткою, яка не працює, тому `unsafe` тут не потрібна.
/////
/// use std::cell::UnsafeCell;
///
/// let mut x: UnsafeCell<i32> = 42.into();
///
/// // Отримайте перевірене під час компіляції унікальне посилання на `x`.
/// let p_unique: &mut UnsafeCell<i32> = &mut x;
/// // З ексклюзивним посиланням ми можемо безкоштовно мутувати вміст.
/// *p_unique.get_mut() = 0;
/// // Або, еквівалентно:
/// x = UnsafeCell::new(0);
///
/// // Коли ми володіємо цінністю, ми можемо витягти вміст безкоштовно.
/// let contents: i32 = x.into_inner();
/// assert_eq!(contents, 0);
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "unsafe_cell"]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
#[repr(no_niche)] // rust-lang/rust#68303.
pub struct UnsafeCell<T: ?Sized> {
    value: T,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for UnsafeCell<T> {}

impl<T> UnsafeCell<T> {
    /// Створює новий екземпляр `UnsafeCell`, який оберне вказане значення.
    ///
    ///
    /// Весь доступ до внутрішнього значення через методи-`unsafe`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafe_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> UnsafeCell<T> {
        UnsafeCell { value }
    }

    /// Розгортає значення.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.into_inner();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value
    }
}

impl<T: ?Sized> UnsafeCell<T> {
    /// Отримує змінний вказівник на обгорнуте значення.
    ///
    /// Це може бути передано вказівник будь-якого виду.
    /// Переконайтесь, що доступ є унікальним (відсутність активних посилань, змінні чи ні) під час трансляції на `&mut T`, і переконайтеся, що при передачі на `&T` не відбувається ніяких мутацій або змінних псевдонімів
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.get();
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafecell_get", since = "1.32.0")]
    pub const fn get(&self) -> *mut T {
        // Ми можемо просто перекинути вказівник з `UnsafeCell<T>` на `T` через #[repr(transparent)].
        // Це використовує особливий статус libstd, немає гарантії для коду користувача, що це буде працювати у версіях компілятора future!
        //
        self as *const UnsafeCell<T> as *const T as *mut T
    }

    /// Повертає змінне посилання на базові дані.
    ///
    /// Цей дзвінок запозичує `UnsafeCell` мутативно (під час компіляції), що гарантує, що ми маємо єдине посилання.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let mut c = UnsafeCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(*c.get_mut(), 6);
    /// ```
    #[inline]
    #[stable(feature = "unsafe_cell_get_mut", since = "1.50.0")]
    pub fn get_mut(&mut self) -> &mut T {
        &mut self.value
    }

    /// Отримує змінний вказівник на обгорнуте значення.
    /// Відмінність від [`get`] полягає в тому, що ця функція приймає необроблений покажчик, що корисно, щоб уникнути створення тимчасових посилань.
    ///
    /// Результат може бути переданий у вказівник будь-якого виду.
    /// Переконайтесь, що доступ є унікальним (відсутність активних посилань, змінні чи ні) під час трансляції на `&mut T`, та переконайтеся, що під час трансляції на `&T` не відбувається ніяких мутацій або змінних псевдонімів.
    ///
    ///
    /// [`get`]: UnsafeCell::get()
    ///
    /// # Examples
    ///
    /// Поступова ініціалізація `UnsafeCell` вимагає `raw_get`, оскільки для виклику `get` потрібно створити посилання на неініціалізовані дані:
    ///
    /// ```
    /// #![feature(unsafe_cell_raw_get)]
    /// use std::cell::UnsafeCell;
    /// use std::mem::MaybeUninit;
    ///
    /// let m = MaybeUninit::<UnsafeCell<i32>>::uninit();
    /// unsafe { UnsafeCell::raw_get(m.as_ptr()).write(5); }
    /// let uc = unsafe { m.assume_init() };
    ///
    /// assert_eq!(uc.into_inner(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "unsafe_cell_raw_get", issue = "66358")]
    pub const fn raw_get(this: *const Self) -> *mut T {
        // Ми можемо просто перекинути вказівник з `UnsafeCell<T>` на `T` через #[repr(transparent)].
        // Це використовує особливий статус libstd, немає гарантії для коду користувача, що це буде працювати у версіях компілятора future!
        //
        this as *const T as *mut T
    }
}

#[stable(feature = "unsafe_cell_default", since = "1.10.0")]
impl<T: Default> Default for UnsafeCell<T> {
    /// Створює `UnsafeCell` зі значенням `Default` для T.
    fn default() -> UnsafeCell<T> {
        UnsafeCell::new(Default::default())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for UnsafeCell<T> {
    fn from(t: T) -> UnsafeCell<T> {
        UnsafeCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<UnsafeCell<U>> for UnsafeCell<T> {}

#[allow(unused)]
fn assert_coerce_unsized(a: UnsafeCell<&i32>, b: Cell<&i32>, c: RefCell<&i32>) {
    let _: UnsafeCell<&dyn Send> = a;
    let _: Cell<&dyn Send> = b;
    let _: RefCell<&dyn Send> = c;
}