# `rustc-std-workspace-std` crate

Див. Документацію до `rustc-std-workspace-core` crate.