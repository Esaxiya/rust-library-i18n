//! Однопоточні покажчики для підрахунку посилань.'Rc' означає «Довідка»
//! Counted'.
//!
//! Тип [`Rc<T>`][`Rc`] забезпечує спільне володіння значенням типу `T`, виділеним у купі.
//! Виклик [`clone`][clone] на [`Rc`] створює новий вказівник на той самий розподіл у купі.
//! Коли останній вказівник [`Rc`] на даний розподіл знищений, значення, що зберігається в цьому розподілі (часто називається "inner value"), також скидається.
//!
//! Спільні посилання в Rust забороняють мутацію за замовчуванням, і [`Rc`] не є винятком: ви загалом не можете отримати змінне посилання на щось всередині [`Rc`].
//! Якщо вам потрібна змінність, помістіть [`Cell`] або [`RefCell`] всередину [`Rc`];див. [an example of mutability inside an `Rc`][mutability].
//!
//! [`Rc`] використовує неатомний підрахунок посилань.
//! Це означає, що накладні витрати дуже низькі, але [`Rc`] не можна передавати між потоками, і, отже, [`Rc`] не реалізує [`Send`][send].
//! Як результат, компілятор Rust перевірить *під час компіляції*, що ви не надсилаєте [`Rc`] s між потоками.
//! Якщо вам потрібен багатопотоковий атомний підрахунок посилань, використовуйте [`sync::Arc`][arc].
//!
//! Метод [`downgrade`][downgrade] може бути використаний для створення невласницького покажчика [`Weak`].
//! Вказівник [`Weak`] може бути [`оновити`][оновити] d до [`Rc`], але це поверне [`None`], якщо значення, що зберігається у розподілі, вже скинуто.
//! Іншими словами, вказівники `Weak` не зберігають значення всередині розподілу живим;однак вони *роблять* підтримують виділення (резервне сховище внутрішньої вартості) в живому стані.
//!
//! Цикл між покажчиками [`Rc`] ніколи не буде звільнений.
//! З цієї причини [`Weak`] використовується для розриву циклів.
//! Наприклад, дерево може мати сильні вказівники [`Rc`] від батьківських вузлів до дітей, а [`Weak`]-від дітей до батьків.
//!
//! `Rc<T>` автоматично перенаправляє на `T` (через [`Deref`] Portrait), тож ви можете викликати методи T за значенням типу [`Rc<T>`][`Rc`].
//! Щоб уникнути зіткнень імен із методами `T`, методи [`Rc<T>`][`Rc`] самі по собі є пов'язаними функціями, що викликаються за допомогою [fully qualified syntax]:
//!
//! ```
//! use std::rc::Rc;
//!
//! let my_rc = Rc::new(());
//! Rc::downgrade(&my_rc);
//! ```
//!
//! `Rc<T>Реалізації traits, такі як `Clone`, також можуть бути викликані з використанням повноцінного синтаксису.
//! Деякі люди вважають за краще використовувати повноцінний синтаксис, тоді як інші воліють використовувати синтаксис виклику методів.
//!
//! ```
//! use std::rc::Rc;
//!
//! let rc = Rc::new(());
//! // Синтаксис виклику методу
//! let rc2 = rc.clone();
//! // Повністю кваліфікований синтаксис
//! let rc3 = Rc::clone(&rc);
//! ```
//!
//! [`Weak<T>`][`Weak`] не здійснює автоматичне перенаправлення на `T`, оскільки внутрішнє значення, можливо, вже відкинуто.
//!
//! # Посилання на клонування
//!
//! Створення нового посилання на той самий розподіл, що й наявний покажчик підрахунку посилань, здійснюється за допомогою `Clone` Portrait, реалізованої для [`Rc<T>`][`Rc`] та [`Weak<T>`][`Weak`].
//!
//!
//! ```
//! use std::rc::Rc;
//!
//! let foo = Rc::new(vec![1.0, 2.0, 3.0]);
//! // Наведені нижче два синтаксиси еквівалентні.
//! let a = foo.clone();
//! let b = Rc::clone(&foo);
//! // a і b обидва вказують на те саме місце пам'яті, що і foo.
//! ```
//!
//! Синтаксис `Rc::clone(&from)` є найбільш ідіоматичним, оскільки він більш чітко передає значення коду.
//! У наведеному вище прикладі цей синтаксис полегшує переконання, що цей код створює нове посилання, а не копіює весь вміст foo.
//!
//! # Examples
//!
//! Розглянемо сценарій, коли набір `` гаджетів '' належить певному `Owner`.
//! Ми хочемо, щоб наш пристрій вказував на їхній `Owner`.Ми не можемо зробити це з унікальним правом власності, оскільки більше одного гаджета може належати одному `Owner`.
//! [`Rc`] дозволяє нам ділитися `Owner` між кількома `` гаджетами '', і `Owner` залишатиметься розподіленим доти, доки на нього вказує будь-яка `Gadget`.
//!
//! ```
//! use std::rc::Rc;
//!
//! struct Owner {
//!     name: String,
//!     // ... інші поля
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... інші поля
//! }
//!
//! fn main() {
//!     // Створіть `Owner` з порахуванням посилань.
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!         }
//!     );
//!
//!     // Створіть `гаджет`, що належить `gadget_owner`.
//!     // Клонування `Rc<Owner>` дає нам новий вказівник на той самий розподіл `Owner`, збільшуючи кількість посилань у процесі.
//!     //
//!     let gadget1 = Gadget {
//!         id: 1,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!     let gadget2 = Gadget {
//!         id: 2,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!
//!     // Утилізуйте нашу локальну змінну `gadget_owner`.
//!     drop(gadget_owner);
//!
//!     // Незважаючи на відмову від `gadget_owner`, ми все ще можемо роздрукувати назву `Owner` у `` Гаджеті ''.
//!     // Це тому, що ми втратили лише один `Rc<Owner>`, а не `Owner`, на який він вказує.
//!     // Поки є інші `Rc<Owner>`, що вказують на той самий розподіл `Owner`, він залишатиметься активним.
//!     // Польова проекція `gadget1.owner.name` працює, оскільки `Rc<Owner>` автоматично перенаправляє на `Owner`.
//!     //
//!     //
//!     println!("Gadget {} owned by {}", gadget1.id, gadget1.owner.name);
//!     println!("Gadget {} owned by {}", gadget2.id, gadget2.owner.name);
//!
//!     // В кінці функції `gadget1` та `gadget2` знищуються, а разом із ними і останні підраховані посилання на наш `Owner`.
//!     // Gadget Man тепер також знищується.
//!     //
//! }
//! ```
//!
//! Якщо наші вимоги зміниться, і нам також потрібно мати можливість переходу від `Owner` до `Gadget`, ми зіткнемося з проблемами.
//! Покажчик [`Rc`] від `Owner` до `Gadget` вводить цикл.
//! Це означає, що їх кількість посилань ніколи не може досягати 0, і розподіл ніколи не буде знищений:
//! витік пам'яті.Для того, щоб обійти це, ми можемо використовувати покажчики [`Weak`].
//!
//! Rust насправді дещо ускладнює створення цього циклу.Щоб у результаті вийшло два значення, які вказують одне на одне, одне з них має бути змінним.
//! Це важко, оскільки [`Rc`] забезпечує безпеку пам`яті, видаючи лише загальні посилання на значення, яке вона обертає, і вони не дозволяють прямої мутації.
//! Нам потрібно обернути частину значення, яке ми хочемо мутувати, у [`RefCell`], який забезпечує *внутрішню змінність*: метод досягнення змінності за допомогою спільного посилання.
//! [`RefCell`] застосовує правила запозичення Rust під час виконання.
//!
//! ```
//! use std::rc::Rc;
//! use std::rc::Weak;
//! use std::cell::RefCell;
//!
//! struct Owner {
//!     name: String,
//!     gadgets: RefCell<Vec<Weak<Gadget>>>,
//!     // ... інші поля
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... інші поля
//! }
//!
//! fn main() {
//!     // Створіть `Owner` з порахуванням посилань.
//!     // Зверніть увагу, що ми помістили vector `Власників`` Гаджета` всередину `RefCell`, щоб ми могли його мутувати через спільне посилання.
//!     //
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!             gadgets: RefCell::new(vec![]),
//!         }
//!     );
//!
//!     // Створіть `гаджет`, що належить `gadget_owner`, як і раніше.
//!     let gadget1 = Rc::new(
//!         Gadget {
//!             id: 1,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!     let gadget2 = Rc::new(
//!         Gadget {
//!             id: 2,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!
//!     // Додайте `гаджет` до свого `Owner`.
//!     {
//!         let mut gadgets = gadget_owner.gadgets.borrow_mut();
//!         gadgets.push(Rc::downgrade(&gadget1));
//!         gadgets.push(Rc::downgrade(&gadget2));
//!
//!         // `RefCell` динамічний запозичення тут закінчується.
//!     }
//!
//!     // Переглядайте наші `` гаджети '', роздруковуючи їх деталі.
//!     for gadget_weak in gadget_owner.gadgets.borrow().iter() {
//!
//!         // `gadget_weak` є `Weak<Gadget>`.
//!         // Оскільки покажчики `Weak` не можуть гарантувати, що розподіл все ще існує, нам потрібно викликати `upgrade`, який повертає `Option<Rc<Gadget>>`.
//!         //
//!         //
//!         // У цьому випадку ми знаємо, що розподіл все ще існує, тому ми просто `unwrap`-`Option`.
//!         // У більш складній програмі вам може знадобитися витончена обробка помилок для результату `None`.
//!         //
//!
//!         let gadget = gadget_weak.upgrade().unwrap();
//!         println!("Gadget {} owned by {}", gadget.id, gadget.owner.name);
//!     }
//!
//!     // Після закінчення функції `gadget_owner`, `gadget1` та `gadget2` знищуються.
//!     // Зараз немає сильних покажчиків (`Rc`) на гаджети, тому вони знищуються.
//!     // Це обнуляє кількість посилань на Gadget Man, тому його також знищують.
//!     //
//! }
//! ```
//!
//! [clone]: Clone::clone
//! [`Cell`]: core::cell::Cell
//! [`RefCell`]: core::cell::RefCell
//! [send]: core::marker::Send
//! [arc]: crate::sync::Arc
//! [`Deref`]: core::ops::Deref
//! [downgrade]: Rc::downgrade
//! [upgrade]: Weak::upgrade
//! [mutability]: core::cell#introducing-mutability-inside-of-something-immutable
//! [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[cfg(not(test))]
use crate::boxed::Box;
#[cfg(test)]
use std::boxed::Box;

use core::any::Any;
use core::borrow;
use core::cell::Cell;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::abort;
use core::iter;
use core::marker::{self, PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, forget, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

// Це захист від repr(C) до future проти можливого переупорядкування полів, що заважає безпечному в іншому випадку [into|from]_raw() трансмутованих внутрішніх типів.
//
//
#[repr(C)]
struct RcBox<T: ?Sized> {
    strong: Cell<usize>,
    weak: Cell<usize>,
    value: T,
}

/// Однопоточний покажчик підрахунку посилань.'Rc' означає «Довідка»
/// Counted'.
///
/// Докладніше див. У [module-level documentation](./index.html).
///
/// Всі властиві методи `Rc`-це всі пов`язані функції, а це означає, що вам доведеться викликати їх як, наприклад, [`Rc::get_mut(&mut value)`][get_mut] замість `value.get_mut()`.
/// Це дозволяє уникнути конфліктів із методами внутрішнього типу `T`.
///
/// [get_mut]: Rc::get_mut
///
#[cfg_attr(not(test), rustc_diagnostic_item = "Rc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Rc<T: ?Sized> {
    ptr: NonNull<RcBox<T>>,
    phantom: PhantomData<RcBox<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Send for Rc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Sync for Rc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Rc<U>> for Rc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T> {}

impl<T: ?Sized> Rc<T> {
    #[inline(always)]
    fn inner(&self) -> &RcBox<T> {
        // Ця небезпека є нормальною, оскільки поки цей Rc живий, ми гарантуємо, що внутрішній вказівник є дійсним.
        //
        unsafe { self.ptr.as_ref() }
    }

    fn from_inner(ptr: NonNull<RcBox<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut RcBox<T>) -> Self {
        Self::from_inner(unsafe { NonNull::new_unchecked(ptr) })
    }
}

impl<T> Rc<T> {
    /// Конструює новий `Rc<T>`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(value: T) -> Rc<T> {
        // Існує неявний слабкий покажчик, яким володіють усі сильні покажчики, що гарантує, що слабкий деструктор ніколи не звільняє розподіл, поки працює сильний деструктор, навіть якщо слабкий покажчик зберігається всередині сильного покажчика.
        //
        //
        //
        Self::from_inner(
            Box::leak(box RcBox { strong: Cell::new(1), weak: Cell::new(1), value }).into(),
        )
    }

    /// Конструює новий `Rc<T>`, використовуючи слабке посилання на себе.
    /// Спроба оновити слабке посилання до повернення цієї функції призведе до значення `None`.
    ///
    /// Однак слабке посилання можна вільно клонувати та зберігати для подальшого використання.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Gadget {
    ///     self_weak: Weak<Self>,
    ///     // ... більше полів
    /// }
    /// impl Gadget {
    ///     pub fn new() -> Rc<Self> {
    ///         Rc::new_cyclic(|self_weak| {
    ///             Gadget { self_weak: self_weak.clone(), /* ... */ }
    ///         })
    ///     }
    /// }
    /// ```
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Rc<T> {
        // Побудуйте внутрішнє в стані "uninitialized" за допомогою одного слабкого еталону.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box RcBox {
            strong: Cell::new(0),
            weak: Cell::new(1),
            value: mem::MaybeUninit::<T>::uninit(),
        })
        .into();

        let init_ptr: NonNull<RcBox<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // Важливо, що ми не відмовляємося від володіння слабким покажчиком, інакше пам`ять може звільнитися до повернення `data_fn`.
        // Якби ми дійсно хотіли передати право власності, ми могли б створити для себе додатковий слабкий вказівник, але це призведе до додаткових оновлень слабкого підрахунку посилань, які інакше можуть бути не потрібні.
        //
        //
        //
        //
        let data = data_fn(&weak);

        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).value), data);

            let prev_value = (*inner).strong.get();
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
            (*inner).strong.set(1);
        }

        let strong = Rc::from_inner(init_ptr);

        // Сильні посилання повинні колективно мати спільне слабке посилання, тому не запускайте деструктор для нашого старого слабкого посилання.
        //
        mem::forget(weak);
        strong
    }

    /// Конструює новий `Rc` з неініціалізованим вмістом.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Відкладена ініціалізація:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Конструює новий `Rc` з неініціалізованим вмістом, при цьому пам'ять заповнюється байтами `0`.
    ///
    ///
    /// Див. [`MaybeUninit::zeroed`][zeroed] для прикладів правильного та неправильного використання цього методу.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Конструює новий `Rc<T>`, повертаючи помилку, якщо розподіл не вдається
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::rc::Rc;
    ///
    /// let five = Rc::try_new(5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn try_new(value: T) -> Result<Rc<T>, AllocError> {
        // Існує неявний слабкий покажчик, яким володіють усі сильні покажчики, що гарантує, що слабкий деструктор ніколи не звільняє розподіл, поки працює сильний деструктор, навіть якщо слабкий покажчик зберігається всередині сильного покажчика.
        //
        //
        //
        Ok(Self::from_inner(
            Box::leak(Box::try_new(RcBox { strong: Cell::new(1), weak: Cell::new(1), value })?)
                .into(),
        ))
    }

    /// Конструює новий `Rc` з неініціалізованим вмістом, повертаючи помилку, якщо розподіл не вдається
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // Відкладена ініціалізація:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// Конструює новий `Rc` з неініціалізованим вмістом, при цьому пам'ять заповнюється байтами `0`, повертаючи помилку, якщо розподіл не вдається
    ///
    ///
    /// Див. [`MaybeUninit::zeroed`][zeroed] для прикладів правильного та неправильного використання цього методу.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// Конструює новий `Pin<Rc<T>>`.
    /// Якщо `T` не реалізує `Unpin`, тоді `value` буде закріплено в пам'яті і не може бути переміщено.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(value: T) -> Pin<Rc<T>> {
        unsafe { Pin::new_unchecked(Rc::new(value)) }
    }

    /// Повертає внутрішнє значення, якщо `Rc` має рівно одне сильне посилання.
    ///
    /// В іншому випадку [`Err`] повертається з тим самим `Rc`, який був переданий.
    ///
    ///
    /// Це вдасться, навіть якщо є видатні слабкі посилання.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new(3);
    /// assert_eq!(Rc::try_unwrap(x), Ok(3));
    ///
    /// let x = Rc::new(4);
    /// let _y = Rc::clone(&x);
    /// assert_eq!(*Rc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if Rc::strong_count(&this) == 1 {
            unsafe {
                let val = ptr::read(&*this); // скопіюйте вміщений об'єкт

                // Вкажіть слабким, що їх неможливо підвищити, зменшуючи сильний рахунок, а потім видаліть неявний вказівник "strong weak", одночасно працюючи з логікою падіння, просто створивши підроблений слабкий.
                //
                //
                //
                this.inner().dec_strong();
                let _weak = Weak { ptr: this.ptr };
                forget(this);
                Ok(val)
            }
        } else {
            Err(this)
        }
    }
}

impl<T> Rc<[T]> {
    /// Конструює новий зріз з урахуванням посилань з неініціалізованим вмістом.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Відкладена ініціалізація:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe { Rc::from_ptr(Rc::allocate_for_slice(len)) }
    }

    /// Конструює новий зріз з урахуванням посилань з неініціалізованим вмістом, при цьому пам`ять заповнюється байтами `0`.
    ///
    ///
    /// Див. [`MaybeUninit::zeroed`][zeroed] для прикладів правильного та неправильного використання цього методу.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let values = Rc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut RcBox<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Rc<mem::MaybeUninit<T>> {
    /// Перетворює на `Rc<T>`.
    ///
    /// # Safety
    ///
    /// Як і у випадку з [`MaybeUninit::assume_init`], від абонента залежить гарантувати, що внутрішнє значення дійсно знаходиться в стані ініціалізації.
    ///
    /// Виклик цього, коли вміст ще не повністю ініціалізований, спричиняє негайну невизначену поведінку.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Відкладена ініціалізація:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<T> {
        Rc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Rc<[mem::MaybeUninit<T>]> {
    /// Перетворює на `Rc<[T]>`.
    ///
    /// # Safety
    ///
    /// Як і у випадку з [`MaybeUninit::assume_init`], від абонента залежить гарантувати, що внутрішнє значення дійсно знаходиться в стані ініціалізації.
    ///
    /// Виклик цього, коли вміст ще не повністю ініціалізований, спричиняє негайну невизначену поведінку.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Відкладена ініціалізація:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<[T]> {
        unsafe { Rc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Rc<T> {
    /// Споживає `Rc`, повертаючи загорнутий покажчик.
    ///
    /// Щоб уникнути витоку пам'яті, вказівник потрібно перетворити назад у `Rc` за допомогою [`Rc::from_raw`][from_raw].
    ///
    ///
    /// [from_raw]: Rc::from_raw
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// Надає необроблений вказівник на дані.
    ///
    /// На підрахунок це ніяк не впливає, і `Rc` не споживається.
    /// Покажчик дійсний до тих пір, поки в `Rc` є значний рахунок.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let y = Rc::clone(&x);
    /// let x_ptr = Rc::as_ptr(&x);
    /// assert_eq!(x_ptr, Rc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(this.ptr);

        // БЕЗПЕКА: Це не може пройти через Deref::deref або Rc::inner, оскільки
        // це потрібно для збереження походження raw/mut таким, що, наприклад
        // `get_mut` може писати через покажчик після відновлення Rc через `from_raw`.
        unsafe { ptr::addr_of_mut!((*ptr).value) }
    }

    /// Конструює `Rc<T>` з необробленого вказівника.
    ///
    /// Сировинний вказівник повинен бути раніше повернутий за допомогою виклику [`Rc<U>::into_raw`][into_raw], де `U` повинен мати такий самий розмір і вирівнювання, як `T`.
    /// Це тривіально вірно, якщо `U`-це `T`.
    /// Зауважте, що якщо `U` не є `T`, але має однакові розміри та вирівнювання, це в основному схоже на перетворення посилань різних типів.
    /// Дивіться [`mem::transmute`][transmute] для отримання додаткової інформації про те, які обмеження застосовуються в цьому випадку.
    ///
    /// Користувач `from_raw` повинен переконатися, що конкретне значення `T` скидається лише один раз.
    ///
    /// Ця функція небезпечна, оскільки неправильне використання може призвести до небезпеки пам'яті, навіть якщо повернутий `Rc<T>` ніколи не доступний.
    ///
    /// [into_raw]: Rc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    ///
    /// unsafe {
    ///     // Перетворіть назад на `Rc`, щоб запобігти витоку.
    ///     let x = Rc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // Подальші дзвінки на `Rc::from_raw(x_ptr)` були б небезпечними для пам'яті.
    /// }
    ///
    /// // Пам'ять звільнилася, коли `x` вийшов із сфери дії вище, тому `x_ptr` тепер бовтається!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        let offset = unsafe { data_offset(ptr) };

        // Змініть зміщення, щоб знайти оригінальний RcBox.
        let rc_ptr =
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) };

        unsafe { Self::from_ptr(rc_ptr) }
    }

    /// Створює новий вказівник [`Weak`] на це виділення.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        this.inner().inc_weak();
        // Переконайтеся, що ми не створюємо звисаючого Слабкого
        debug_assert!(!is_dangling(this.ptr.as_ptr()));
        Weak { ptr: this.ptr }
    }

    /// Отримує кількість покажчиків [`Weak`] на цей розподіл.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _weak_five = Rc::downgrade(&five);
    ///
    /// assert_eq!(1, Rc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        this.inner().weak() - 1
    }

    /// Отримує кількість сильних покажчиків (`Rc`) на цей розподіл.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _also_five = Rc::clone(&five);
    ///
    /// assert_eq!(2, Rc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong()
    }

    /// Повертає `true`, якщо до цього розподілу немає інших покажчиків `Rc` або [`Weak`].
    ///
    #[inline]
    fn is_unique(this: &Self) -> bool {
        Rc::weak_count(this) == 0 && Rc::strong_count(this) == 1
    }

    /// Повертає змінне посилання на даний `Rc`, якщо немає інших покажчиків `Rc` або [`Weak`] на те саме розподіл.
    ///
    ///
    /// Повертає [`None`] в іншому випадку, оскільки небезпечно мутувати спільне значення.
    ///
    /// Див. Також [`make_mut`][make_mut], який буде [`clone`][clone] внутрішнім значенням, якщо є інші вказівники.
    ///
    /// [make_mut]: Rc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(3);
    /// *Rc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Rc::clone(&x);
    /// assert!(Rc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if Rc::is_unique(this) { unsafe { Some(Rc::get_mut_unchecked(this)) } } else { None }
    }

    /// Повертає змінне посилання на даний `Rc` без жодної перевірки.
    ///
    /// Див. Також [`get_mut`], який є безпечним та робить відповідні перевірки.
    ///
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Safety
    ///
    /// Будь-які інші вказівники `Rc` або [`Weak`] на той самий розподіл не повинні бути розмежовувані протягом тривалості поверненої позики.
    ///
    /// Це тривіально, якщо таких покажчиків не існує, наприклад відразу після `Rc::new`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(String::new());
    /// unsafe {
    ///     Rc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // Ми обережно *не* створюємо посилання, що охоплює поля "count", оскільки це суперечить доступу до підрахунку посилань (наприклад,
        // від `Weak`).
        unsafe { &mut (*this.ptr.as_ptr()).value }
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// Повертає `true`, якщо два `Rc` вказують на однаковий розподіл (у вені, подібній до [`ptr::eq`]).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let same_five = Rc::clone(&five);
    /// let other_five = Rc::new(5);
    ///
    /// assert!(Rc::ptr_eq(&five, &same_five));
    /// assert!(!Rc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: Clone> Rc<T> {
    /// Змінює посилання на даний `Rc`.
    ///
    /// Якщо є інші вказівники `Rc` до того самого розподілу, тоді `make_mut` буде [`clone`] внутрішнє значення нового розподілу для забезпечення унікального володіння.
    /// Це також називають клоном на запис.
    ///
    /// Якщо до цього розподілу немає інших вказівників `Rc`, тоді вказівники [`Weak`] до цього розподілу будуть від'єднані.
    ///
    /// Див. Також [`get_mut`], який скоріше зазнає невдачі, ніж клонування.
    ///
    /// [`clone`]: Clone::clone
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(5);
    ///
    /// *Rc::make_mut(&mut data) += 1;        // Нічого не клонуватиме
    /// let mut other_data = Rc::clone(&data);    // Не буде клонувати внутрішні дані
    /// *Rc::make_mut(&mut data) += 1;        // Клонує внутрішні дані
    /// *Rc::make_mut(&mut data) += 1;        // Нічого не клонуватиме
    /// *Rc::make_mut(&mut other_data) *= 2;  // Нічого не клонуватиме
    ///
    /// // Тепер `data` та `other_data` вказують на різні розподіли.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    /// [`Weak`] вказівники будуть роз'єднані:
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(75);
    /// let weak = Rc::downgrade(&data);
    ///
    /// assert!(75 == *data);
    /// assert!(75 == *weak.upgrade().unwrap());
    ///
    /// *Rc::make_mut(&mut data) += 1;
    ///
    /// assert!(76 == *data);
    /// assert!(weak.upgrade().is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        if Rc::strong_count(this) != 1 {
            // Потрібно клонувати дані, є й інші ПК.
            // Попередньо виділіть пам'ять, щоб дозволити безпосередньо писати клоноване значення.
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = rc.assume_init();
            }
        } else if Rc::weak_count(this) != 0 {
            // Можна просто вкрасти дані, залишився лише Weaks
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);

                this.inner().dec_strong();
                // Видаліть неявний сильний і слабкий реф (немає необхідності створювати підробленого слабкого тут-ми знаємо, що інші слабкі можуть очистити нас)
                //
                this.inner().dec_weak();
                ptr::write(this, rc.assume_init());
            }
        }
        // Ця небезпека є нормальною, оскільки ми гарантуємо, що повернутий покажчик-це єдиний * покажчик, який коли-небудь буде повернено T.
        // На даний момент кількість наших посилань гарантовано дорівнює 1, і ми вимагали, щоб сам `Rc<T>` був `mut`, тому ми повертаємо єдине можливе посилання на розподіл.
        //
        //
        //
        unsafe { &mut this.ptr.as_mut().value }
    }
}

impl Rc<dyn Any> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// Спроба знизити `Rc<dyn Any>` до конкретного типу.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::rc::Rc;
    ///
    /// fn print_if_string(value: Rc<dyn Any>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Rc::new(my_string));
    /// print_if_string(Rc::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Rc<T>, Rc<dyn Any>> {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<RcBox<T>>();
            forget(self);
            Ok(Rc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T: ?Sized> Rc<T> {
    /// Виділяє `RcBox<T>` із достатньою площею для можливо великого внутрішнього значення там, де значення має макет.
    ///
    /// Функція `mem_to_rcbox` викликається за допомогою покажчика даних і повинна повернути (потенційно жирний) покажчик для `RcBox<T>`.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> *mut RcBox<T> {
        // Розрахуйте макет, використовуючи задане значення макета.
        // Раніше макет обчислювався за виразом `&*(ptr as* const RcBox<T>)`, але це створило неправильне вирівнювання (див. #54908).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Rc::try_allocate_for_layout(value_layout, allocate, mem_to_rcbox)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// Виділяє `RcBox<T>` із достатньою площею для можливо великого внутрішнього значення, де значення має макет, що повертає помилку, якщо розподіл не вдається.
    ///
    ///
    /// Функція `mem_to_rcbox` викликається за допомогою покажчика даних і повинна повернути (потенційно жирний) покажчик для `RcBox<T>`.
    ///
    ///
    #[inline]
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> Result<*mut RcBox<T>, AllocError> {
        // Розрахуйте макет, використовуючи задане значення макета.
        // Раніше макет обчислювався за виразом `&*(ptr as* const RcBox<T>)`, але це створило неправильне вирівнювання (див. #54908).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();

        // Виділити для макета.
        let ptr = allocate(layout)?;

        // Ініціалізуйте RcBox
        let inner = mem_to_rcbox(ptr.as_non_null_ptr().as_ptr());
        unsafe {
            debug_assert_eq!(Layout::for_value(&*inner), layout);

            ptr::write(&mut (*inner).strong, Cell::new(1));
            ptr::write(&mut (*inner).weak, Cell::new(1));
        }

        Ok(inner)
    }

    /// Виділяє `RcBox<T>` із достатньою площею для внутрішнього значення величини
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut RcBox<T> {
        // Виділіть для `RcBox<T>`, використовуючи задане значення.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut RcBox<T>).set_ptr_value(mem),
            )
        }
    }

    fn from_box(v: Box<T>) -> Rc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // Копіювати значення у байтах
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).value as *mut _ as *mut u8,
                value_size,
            );

            // Звільніть розподіл, не скидаючи його вміст
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Rc<[T]> {
    /// Виділяє `RcBox<[T]>` із заданою довжиною.
    unsafe fn allocate_for_slice(len: usize) -> *mut RcBox<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut RcBox<[T]>,
            )
        }
    }

    /// Скопіюйте елементи зі зрізу у щойно виділений Rc <\[T\]>
    ///
    /// Небезпечно, оскільки абонент повинен або отримати право власності, або прив'язати `T: Copy`
    unsafe fn copy_from_slice(v: &[T]) -> Rc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());
            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).value as *mut [T] as *mut T, v.len());
            Self::from_ptr(ptr)
        }
    }

    /// Конструює `Rc<[T]>` з ітератора, як відомо, певного розміру.
    ///
    /// Поведінка невизначена, якщо розмір неправильний.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Rc<[T]> {
        // Захист Panic під час клонування елементів Т.
        // У випадку panic елементи, записані в новий RcBox, будуть скинуті, а потім звільнена пам'ять.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // Покажчик на перший елемент
            let elems = &mut (*ptr).value as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // Все чисто.Забудьте про охоронця, щоб він не звільнив новий RcBox.
            forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// Спеціалізація Portrait, що використовується для `From<&[T]>`.
trait RcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Rc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Rc<T> {
    type Target = T;

    #[inline(always)]
    fn deref(&self) -> &T {
        &self.inner().value
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Rc<T> {
    /// Кидає `Rc`.
    ///
    /// Це зменшить потужну кількість посилань.
    /// Якщо кількість сильних посилань досягає нуля, тоді єдиними іншими посиланнями (якщо такі є) є [`Weak`], тому ми `drop`-внутрішнє значення.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Rc::new(Foo);
    /// let foo2 = Rc::clone(&foo);
    ///
    /// drop(foo);    // Нічого не друкує
    /// drop(foo2);   // Друкує "dropped!"
    /// ```
    fn drop(&mut self) {
        unsafe {
            self.inner().dec_strong();
            if self.inner().strong() == 0 {
                // знищити вміщений предмет
                ptr::drop_in_place(Self::get_mut_unchecked(self));

                // видаліть неявний покажчик "strong weak" тепер, коли ми знищили вміст.
                //
                self.inner().dec_weak();

                if self.inner().weak() == 0 {
                    Global.deallocate(self.ptr.cast(), Layout::for_value(self.ptr.as_ref()));
                }
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Rc<T> {
    /// Робить клон покажчика `Rc`.
    ///
    /// Це створює ще один вказівник на той самий розподіл, збільшуючи потужну кількість посилань.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let _ = Rc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Rc<T> {
        self.inner().inc_strong();
        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Rc<T> {
    /// Створює новий `Rc<T>` зі значенням `Default` для `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x: Rc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    #[inline]
    fn default() -> Rc<T> {
        Rc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait RcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Rc<T>) -> bool;
    fn ne(&self, other: &Rc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    default fn eq(&self, other: &Rc<T>) -> bool {
        **self == **other
    }

    #[inline]
    default fn ne(&self, other: &Rc<T>) -> bool {
        **self != **other
    }
}

// Рубати, щоб дозволити спеціалізуватися на `Eq`, навіть якщо `Eq` має метод.
#[rustc_unsafe_specialization_marker]
pub(crate) trait MarkerEq: PartialEq<Self> {}

impl<T: Eq> MarkerEq for T {}

/// Ми робимо цю спеціалізацію тут, а не як більш загальну оптимізацію на `&T`, оскільки в іншому випадку це додасть витрат на всі перевірки рівності посилань.
/// Ми припускаємо, що `Rc` використовуються для зберігання великих значень, які повільно клонуються, але також важкі для перевірки на рівність, завдяки чому ці витрати легше окупляться.
///
/// Також більше шансів мати два клони `Rc`, які вказують на одне і те ж значення, ніж два `` T ''.
///
/// Ми можемо зробити це лише тоді, коли `T: Eq` як `PartialEq` може бути навмисно нерефлексивним.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + MarkerEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        Rc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        !Rc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Rc<T> {
    /// Рівність для двох `Rc`.
    ///
    /// Два `Rc` рівні, якщо їх внутрішні значення рівні, навіть якщо вони зберігаються в різному розподілі.
    ///
    /// Якщо `T` також реалізує `Eq` (маючи на увазі рефлексивність рівності), два `Rc`, які вказують на однаковий розподіл, завжди рівні.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five == Rc::new(5));
    /// ```
    ///
    ///
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        RcEqIdent::eq(self, other)
    }

    /// Нерівність для двох `Rc`.
    ///
    /// Два `Rc` є нерівними, якщо їх внутрішні значення неоднакові.
    ///
    /// Якщо `T` також реалізує `Eq` (маючи на увазі рефлексивність рівності), два `Rc`, які вказують на однаковий розподіл, ніколи не бувають нерівними.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five != Rc::new(6));
    /// ```
    ///
    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        RcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Rc<T> {
    /// Часткове порівняння для двох `Rc`.
    ///
    /// Їх порівнюють, зателефонувавши до `partial_cmp()` за їхніми внутрішніми значеннями.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Rc::new(6)));
    /// ```
    #[inline(always)]
    fn partial_cmp(&self, other: &Rc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// Менше порівняння для двох `Rc`.
    ///
    /// Їх порівнюють, зателефонувавши `<` за їх внутрішніми значеннями.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five < Rc::new(6));
    /// ```
    #[inline(always)]
    fn lt(&self, other: &Rc<T>) -> bool {
        **self < **other
    }

    /// Порівняння "Менше або дорівнює" для двох "Rc".
    ///
    /// Їх порівнюють, зателефонувавши `<=` за їхніми внутрішніми значеннями.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five <= Rc::new(5));
    /// ```
    #[inline(always)]
    fn le(&self, other: &Rc<T>) -> bool {
        **self <= **other
    }

    /// Більше порівняння для двох `Rc`.
    ///
    /// Їх порівнюють, зателефонувавши `>` за їхніми внутрішніми значеннями.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five > Rc::new(4));
    /// ```
    #[inline(always)]
    fn gt(&self, other: &Rc<T>) -> bool {
        **self > **other
    }

    /// Порівняння "більше або дорівнює" для двох "Rc".
    ///
    /// Їх порівнюють, зателефонувавши до `>=` за їхніми внутрішніми значеннями.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five >= Rc::new(5));
    /// ```
    #[inline(always)]
    fn ge(&self, other: &Rc<T>) -> bool {
        **self >= **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Rc<T> {
    /// Порівняння для двох `Rc`.
    ///
    /// Їх порівнюють, зателефонувавши `cmp()` за їхніми внутрішніми значеннями.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Rc::new(6)));
    /// ```
    #[inline]
    fn cmp(&self, other: &Rc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Rc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Rc<T> {
    fn from(t: T) -> Self {
        Rc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Rc<[T]> {
    /// Виділіть підрахований фрагмент та заповніть його, клонуючи елементи `v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Rc<[i32]> = Rc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Rc<[T]> {
        <Self as RcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Rc<str> {
    /// Виділіть підрахований фрагмент рядка та скопіюйте в нього `v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let shared: Rc<str> = Rc::from("statue");
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Rc<str> {
        let rc = Rc::<[u8]>::from(v.as_bytes());
        unsafe { Rc::from_raw(Rc::into_raw(rc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Rc<str> {
    /// Виділіть підрахований фрагмент рядка та скопіюйте в нього `v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: String = "statue".to_owned();
    /// let shared: Rc<str> = Rc::from(original);
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Rc<str> {
        Rc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Rc<T> {
    /// Перемістіть об`єкт, розміщений у коробці, до нового розподілу, з урахуванням посилань.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<i32> = Box::new(1);
    /// let shared: Rc<i32> = Rc::from(original);
    /// assert_eq!(1, *shared);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Rc<T> {
        Rc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Rc<[T]> {
    /// Виділіть фрагмент з порахуванням посилань і перемістіть в нього елементи `v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<Vec<i32>> = Box::new(vec![1, 2, 3]);
    /// let shared: Rc<Vec<i32>> = Rc::from(original);
    /// assert_eq!(vec![1, 2, 3], *shared);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Rc<[T]> {
        unsafe {
            let rc = Rc::copy_from_slice(&v);

            // Дозвольте Vec звільнити свою пам`ять, але не знищувати її вміст
            v.set_len(0);

            rc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Rc<B>
where
    B: ToOwned + ?Sized,
    Rc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Rc<B> {
        match cow {
            Cow::Borrowed(s) => Rc::from(s),
            Cow::Owned(s) => Rc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Rc<[T]>> for Rc<[T; N]> {
    type Error = Rc<[T]>;

    fn try_from(boxed_slice: Rc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Rc::from_raw(Rc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Rc<[T]> {
    /// Бере кожен елемент у `Iterator` та збирає його у `Rc<[T]>`.
    ///
    /// # Експлуатаційні характеристики
    ///
    /// ## Загальний випадок
    ///
    /// У загальному випадку збирання в `Rc<[T]>` здійснюється шляхом першого збирання в `Vec<T>`.Тобто, коли пишеться таке:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// це поводиться так, ніби ми писали:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // Тут відбувається перший набір розподілів.
    ///     .into(); // Тут відбувається другий розподіл для `Rc<[T]>`.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// Це виділить стільки разів, скільки потрібно для побудови `Vec<T>`, а потім виділить один раз для перетворення `Vec<T>` в `Rc<[T]>`.
    ///
    ///
    /// ## Ітератори відомої довжини
    ///
    /// Коли ваш `Iterator` реалізує `TrustedLen` і має точний розмір, для `Rc<[T]>` буде зроблено один розподіл.Наприклад:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).collect(); // Тут відбувається лише одне виділення.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToRcSlice::to_rc_slice(iter.into_iter())
    }
}

/// Спеціалізація Portrait, що використовується для збору в `Rc<[T]>`.
trait ToRcSlice<T>: Iterator<Item = T> + Sized {
    fn to_rc_slice(self) -> Rc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToRcSlice<T> for I {
    default fn to_rc_slice(self) -> Rc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToRcSlice<T> for I {
    fn to_rc_slice(self) -> Rc<[T]> {
        // Це стосується ітератора `TrustedLen`.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // БЕЗПЕКА: нам потрібно переконатися, що ітератор має точну довжину, а ми маємо.
                Rc::from_iter_exact(self, low)
            }
        } else {
            // Поверніться до нормальної реалізації.
            self.collect::<Vec<T>>().into()
        }
    }
}

/// `Weak` - це версія [`Rc`], яка містить невласне посилання на керований розподіл.До розподілу здійснюється виклик [`upgrade`] на покажчику `Weak`, який повертає [`Option`]`<`[`Rc`] `<T>>`.
///
/// Оскільки посилання `Weak` не враховується у власність, це не завадить скинути значення, що зберігається у розподілі, і сам `Weak` не дає жодних гарантій щодо значення, яке все ще присутнє.
/// Таким чином, він може повернути [`None`], коли [`оновити`] d.
/// Однак зауважте, що посилання `Weak`*не* заважає звільненню самого розподілу (сховища).
///
/// Покажчик `Weak` корисний для збереження тимчасового посилання на розподіл, керований [`Rc`], не запобігаючи викиданню його внутрішнього значення.
/// Він також використовується для запобігання круговим посиланням між покажчиками [`Rc`], оскільки взаємні посилання-власники ніколи не дозволяли б відкинути жоден [`Rc`].
/// Наприклад, дерево може мати сильні вказівники [`Rc`] від батьківських вузлів до дітей, а `Weak`-від дітей до батьків.
///
/// Типовим способом отримання покажчика `Weak` є виклик [`Rc::downgrade`].
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
///
///
#[stable(feature = "rc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // Це `NonNull`, щоб дозволити оптимізувати розмір цього типу в переліченнях, але це не обов'язково дійсний вказівник.
    //
    // `Weak::new` встановлює для цього значення `usize::MAX`, так що йому не потрібно виділяти місце в купі.
    // Це не значення, яке справді матиме покажчик, оскільки RcBox має вирівнювання принаймні 2.
    // Це можливо лише тоді, коли `T: Sized`;розмір `T` ніколи не бовтається.
    //
    ptr: NonNull<RcBox<T>>,
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Send for Weak<T> {}
#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

impl<T> Weak<T> {
    /// Конструює новий `Weak<T>`, не виділяючи жодної пам'яті.
    /// Виклик [`upgrade`] на повернене значення завжди дає [`None`].
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut RcBox<T>).expect("MAX is not 0") }
    }
}

pub(crate) fn is_dangling<T: ?Sized>(ptr: *mut T) -> bool {
    let address = ptr as *mut () as usize;
    address == usize::MAX
}

/// Тип допоміжного, щоб дозволити доступ до лічильників посилань, не роблячи жодних тверджень щодо поля даних.
///
struct WeakInner<'a> {
    weak: &'a Cell<usize>,
    strong: &'a Cell<usize>,
}

impl<T: ?Sized> Weak<T> {
    /// Повертає необроблений вказівник на об'єкт `T`, на який вказує цей `Weak<T>`.
    ///
    /// Вказівник є дійсним лише за наявності сильних посилань.
    /// Покажчик може звисати, не вирівнюватися або навіть [`null`] в іншому випадку.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::ptr;
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// // Обидва вказують на один і той же об`єкт
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // Сильний тут підтримує його в живих, тому ми все ще можемо отримати доступ до об`єкта.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // Але вже не більше.
    /// // Ми можемо зробити weak.as_ptr(), але доступ до покажчика призведе до невизначеної поведінки.
    /// // assert_eq! ("привіт", небезпечно {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // Якщо покажчик звисає, ми повертаємо сторожового безпосередньо.
            // Це не може бути дійсною адресою корисного навантаження, оскільки корисне навантаження принаймні настільки ж вирівняне, як RcBox (usize).
            ptr as *const T
        } else {
            // БЕЗПЕКА: якщо is_dangling повертає значення false, тоді вказівник неможливо розпізнати.
            // На цьому етапі корисне навантаження може бути скинуто, і ми повинні підтримувати походження, тому використовуйте маніпуляції з необробленими вказівниками.
            //
            unsafe { ptr::addr_of_mut!((*ptr).value) }
        }
    }

    /// Споживає `Weak<T>` і перетворює його на сирий вказівник.
    ///
    /// Це перетворює слабкий покажчик у вихідний покажчик, зберігаючи при цьому право власності на одне слабке посилання (слабкий рахунок не змінюється цією операцією).
    /// Його можна перетворити назад у `Weak<T>` за допомогою [`from_raw`].
    ///
    /// Застосовуються ті самі обмеження доступу до цілі вказівника, що і для [`as_ptr`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Rc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Rc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// Перетворює необроблений вказівник, раніше створений [`into_raw`], назад у `Weak<T>`.
    ///
    /// Це можна використовувати для безпечного отримання надійного посилання (зателефонувавши [`upgrade`] пізніше) або для звільнення слабкого рахунку, скинувши `Weak<T>`.
    ///
    /// Він бере у власність одне слабке посилання (за винятком покажчиків, створених [`new`], оскільки вони нічого не мають; метод все ще працює на них).
    ///
    /// # Safety
    ///
    /// Вказівник повинен походити з [`into_raw`] і все ще повинен мати свою потенційну слабку посилання.
    ///
    /// Під час виклику дозволено, щоб сильний підрахунок становив 0.
    /// Тим не менше, це приймає у власність одне слабке посилання, представлене в даний час як вихідний вказівник (слабкий відлік не змінюється цією операцією), і тому він повинен бути з'єднаний з попереднім викликом до [`into_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    ///
    /// let raw_1 = Rc::downgrade(&strong).into_raw();
    /// let raw_2 = Rc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Rc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Rc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // Зменште останній слабкий рахунок.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`new`]: Weak::new
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // Див. Weak::as_ptr для контексту, як виводиться вказівник введення.

        let ptr = if is_dangling(ptr as *mut T) {
            // Це звисаючий Слабкий.
            ptr as *mut RcBox<T>
        } else {
            // В іншому випадку ми гарантуємо, що вказівник походить від незрозумілого Слабкого.
            // БЕЗПЕКА: data_offset безпечно викликати, оскільки ptr посилається на реальний (потенційно скинутий) T.
            let offset = unsafe { data_offset(ptr) };
            // Таким чином, ми змінюємо зміщення, щоб отримати весь RcBox.
            // БЕЗПЕКА: покажчик походить від слабкого, тому цей зсув безпечний.
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // БЕЗПЕКА: тепер ми відновили вихідний слабкий вказівник, тому можемо створити слабкий.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }

    /// Спроби оновити покажчик `Weak` до [`Rc`], затримуючи скидання внутрішнього значення у разі успіху.
    ///
    ///
    /// Повертає [`None`], якщо внутрішнє значення з тих пір було скинуто.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    ///
    /// let strong_five: Option<Rc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // Знищити всі сильні покажчики.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Rc<T>> {
        let inner = self.inner()?;
        if inner.strong() == 0 {
            None
        } else {
            inner.inc_strong();
            Some(Rc::from_inner(self.ptr))
        }
    }

    /// Отримує кількість сильних покажчиків (`Rc`), що вказують на цей розподіл.
    ///
    /// Якщо `self` було створено за допомогою [`Weak::new`], це поверне 0.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong() } else { 0 }
    }

    /// Отримує кількість покажчиків `Weak`, що вказують на цей розподіл.
    ///
    /// Якщо не залишиться сильних покажчиків, це поверне нуль.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                if inner.strong() > 0 {
                    inner.weak() - 1 // відняти неявний слабкий ptr
                } else {
                    0
                }
            })
            .unwrap_or(0)
    }

    /// Повертає `None`, коли покажчик звисає, і немає виділеного `RcBox`, (тобто, коли цей `Weak` був створений `Weak::new`).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // Ми обережні, щоб *не* створювати посилання, що охоплює поле "data", оскільки поле може одночасно мутувати (наприклад, якщо останній `Rc` буде відкинуто, поле даних буде видалено на місці).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// Повертає `true`, якщо два `Слабких` вказують на одне і те ж розподіл (подібне до [`ptr::eq`]), або якщо обидва не вказують на жодне розподіл (оскільки вони були створені за допомогою `Weak::new()`).
    ///
    ///
    /// # Notes
    ///
    /// Оскільки це порівнює покажчики, це означає, що `Weak::new()` зрівнятимуться між собою, навіть якщо вони не вказують на жодне розподіл.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let first_rc = Rc::new(5);
    /// let first = Rc::downgrade(&first_rc);
    /// let second = Rc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(5);
    /// let third = Rc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// Порівняння `Weak::new`.
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(());
    /// let third = Rc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// Відкидає покажчик `Weak`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Rc::new(Foo);
    /// let weak_foo = Rc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // Нічого не друкує
    /// drop(foo);        // Друкує "dropped!"
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        inner.dec_weak();
        // слабкий рахунок починається з 1 і буде нульовим лише тоді, коли всі сильні покажчики зникли.
        //
        if inner.weak() == 0 {
            unsafe {
                Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr()));
            }
        }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// Робить клон покажчика `Weak`, який вказує на той самий розподіл.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let weak_five = Rc::downgrade(&Rc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        if let Some(inner) = self.inner() {
            inner.inc_weak()
        }
        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// Конструює новий `Weak<T>`, виділяючи пам'ять для `T` без його ініціалізації.
    /// Виклик [`upgrade`] на повернене значення завжди дає [`None`].
    ///
    /// [`None`]: Option
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

// NOTE: Ми перевірили_додати тут, щоб безпечно мати справу з mem::forget.Зокрема
// якщо ви використовуєте mem::forget Rcs (або слабкі), підрахунок перерахунку може переповнюватися, і тоді ви можете звільнити розподіл, поки існують непогашені Rcs (або слабкі).
//
// Ми перериваємось, оскільки це такий вироджений сценарій, що нас не хвилює те, що відбувається-жодна реальна програма ніколи не повинна цього відчувати.
//
// Це має мати незначні накладні витрати, оскільки насправді вам не потрібно клонувати їх у Rust завдяки власності та семантиці переміщення.
//
//

#[doc(hidden)]
trait RcInnerPtr {
    fn weak_ref(&self) -> &Cell<usize>;
    fn strong_ref(&self) -> &Cell<usize>;

    #[inline]
    fn strong(&self) -> usize {
        self.strong_ref().get()
    }

    #[inline]
    fn inc_strong(&self) {
        let strong = self.strong();

        // Ми хочемо перервати переповнення замість того, щоб скидати значення.
        // Кількість посилань ніколи не буде нульовою, коли це буде викликано;
        // тим не менше, ми вставляємо переривання сюди, щоб натякнути LLVM на іншу пропущену оптимізацію.
        //
        if strong == 0 || strong == usize::MAX {
            abort();
        }
        self.strong_ref().set(strong + 1);
    }

    #[inline]
    fn dec_strong(&self) {
        self.strong_ref().set(self.strong() - 1);
    }

    #[inline]
    fn weak(&self) -> usize {
        self.weak_ref().get()
    }

    #[inline]
    fn inc_weak(&self) {
        let weak = self.weak();

        // Ми хочемо перервати переповнення замість того, щоб скидати значення.
        // Кількість посилань ніколи не буде нульовою, коли це буде викликано;
        // тим не менше, ми вставляємо переривання сюди, щоб натякнути LLVM на іншу пропущену оптимізацію.
        //
        if weak == 0 || weak == usize::MAX {
            abort();
        }
        self.weak_ref().set(weak + 1);
    }

    #[inline]
    fn dec_weak(&self) {
        self.weak_ref().set(self.weak() - 1);
    }
}

impl<T: ?Sized> RcInnerPtr for RcBox<T> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        &self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        &self.strong
    }
}

impl<'a> RcInnerPtr for WeakInner<'a> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        self.strong
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Rc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Rc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Rc<T> {}

/// Отримайте зсув в межах `RcBox` для корисного навантаження за вказівником.
///
/// # Safety
///
/// Покажчик повинен вказувати на (і мати діючі метадані для) раніше дійсного екземпляра T, але T дозволяється скидати.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // Вирівняйте величину без розміру до кінця RcBox.
    // Оскільки RcBox-це repr(C), він завжди буде останнім полем у пам'яті.
    // БЕЗПЕКА: оскільки єдиними можливими типорозмірами є фрагменти, об`єкти Portrait,
    // та зовнішніх типів, вимоги щодо безпеки введення в даний час достатньо для задоволення вимог align_of_val_raw;це деталь реалізації мови, на яку не можна покладатися поза std.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<RcBox<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}