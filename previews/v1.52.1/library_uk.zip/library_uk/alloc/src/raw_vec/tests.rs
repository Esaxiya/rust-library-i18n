use super::*;
use std::cell::Cell;

#[test]
fn allocator_param() {
    use crate::alloc::AllocError;

    // Написати тест інтеграції між сторонніми розподільниками та `RawVec` трохи складно, оскільки API `RawVec` не передбачає помилкових методів розподілу, тому ми не можемо перевірити, що відбувається, коли розподільник вичерпується (окрім виявлення panic).
    //
    //
    // Натомість це просто перевіряє, що методи `RawVec` принаймні проходять через API Allocator, коли він резервує пам`ять.
    //
    //
    //
    //
    //

    // Тупий розподільник, який споживає фіксовану кількість палива до того, як спроби розподілу почнуть давати збій.
    //
    struct BoundedAlloc {
        fuel: Cell<usize>,
    }
    unsafe impl Allocator for BoundedAlloc {
        fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
            let size = layout.size();
            if size > self.fuel.get() {
                return Err(AllocError);
            }
            match Global.allocate(layout) {
                ok @ Ok(_) => {
                    self.fuel.set(self.fuel.get() - size);
                    ok
                }
                err @ Err(_) => err,
            }
        }
        unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
            unsafe { Global.deallocate(ptr, layout) }
        }
    }

    let a = BoundedAlloc { fuel: Cell::new(500) };
    let mut v: RawVec<u8, _> = RawVec::with_capacity_in(50, a);
    assert_eq!(v.alloc.fuel.get(), 450);
    v.reserve(50, 150); // (спричиняє реальний викид, таким чином використовуючи 50 + 150=200 одиниць пального)
    assert_eq!(v.alloc.fuel.get(), 250);
}

#[test]
fn reserve_does_not_overallocate() {
    {
        let mut v: RawVec<u32> = RawVec::new();
        // По-перше, `reserve` виділяє, як `reserve_exact`.
        v.reserve(0, 9);
        assert_eq!(9, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 7);
        assert_eq!(7, v.capacity());
        // 97 більше, ніж удвічі, ніж 7, тому `reserve` повинен працювати як `reserve_exact`.
        //
        v.reserve(7, 90);
        assert_eq!(97, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 12);
        assert_eq!(12, v.capacity());
        v.reserve(12, 3);
        // 3 менше половини 12, тому `reserve` повинен рости в геометричній прогресії.
        // На момент написання цього тесту коефіцієнт приросту дорівнює 2, отже, нова потужність становить 24, однак, коефіцієнт зростання 1.5 теж нормальний.
        //
        // Звідси `>= 18` у твердженні.
        assert!(v.capacity() >= 12 + 12 / 2);
    }
}