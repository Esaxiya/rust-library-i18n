//! Двостороння черга, реалізована з кільцевим буфером, що збільшується.
//!
//! Ця черга має амортизовані вставки та виймання *O*(1) з обох кінців контейнера.
//! Він також має *O*(1) індексацію, як vector.
//! Вміщені елементи не повинні бути скопійованими, і черга може бути піддана переходу, якщо вміщений тип піддається перегляду.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::cmp::{self, Ordering};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::iter::{repeat_with, FromIterator};
use core::marker::PhantomData;
use core::mem::{self, ManuallyDrop};
use core::ops::{Index, IndexMut, Range, RangeBounds};
use core::ptr::{self, NonNull};
use core::slice;

use crate::collections::TryReserveError;
use crate::raw_vec::RawVec;
use crate::vec::Vec;

#[macro_use]
mod macros;

#[stable(feature = "drain", since = "1.6.0")]
pub use self::drain::Drain;

mod drain;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::iter_mut::IterMut;

mod iter_mut;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::into_iter::IntoIter;

mod into_iter;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::iter::Iter;

mod iter;

use self::pair_slices::PairSlices;

mod pair_slices;

use self::ring_slices::RingSlices;

mod ring_slices;

#[cfg(test)]
mod tests;

const INITIAL_CAPACITY: usize = 7; // 2 ^ 3, 1
const MINIMUM_CAPACITY: usize = 1; // 2, 1

const MAXIMUM_ZST_CAPACITY: usize = 1 << (core::mem::size_of::<usize>() * 8 - 1); // Максимально можлива потужність двох

/// Двостороння черга, реалізована з кільцевим буфером, що збільшується.
///
/// Використання "default" цього типу як черги полягає у використанні [`push_back`] для додавання до черги та [`pop_front`] для видалення з черги.
///
/// [`extend`] і [`append`] натискають на спину таким чином, і ітерація над `VecDeque` йде спереду назад.
///
/// Оскільки `VecDeque` є кільцевим буфером, його елементи не обов'язково є суміжними в пам'яті.
/// Якщо ви хочете отримати доступ до елементів як один фрагмент, наприклад для ефективного сортування, ви можете використовувати [`make_contiguous`].
/// Він обертає `VecDeque`, щоб його елементи не оберталися, і повертає змінний фрагмент до сучасної послідовності елементів.
///
/// [`push_back`]: VecDeque::push_back
/// [`pop_front`]: VecDeque::pop_front
/// [`extend`]: VecDeque::extend
/// [`append`]: VecDeque::append
/// [`make_contiguous`]: VecDeque::make_contiguous
///
///
///
#[cfg_attr(not(test), rustc_diagnostic_item = "vecdeque_type")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct VecDeque<T> {
    // хвіст і голова-вказівники на буфер.
    // Хвіст завжди вказує на перший елемент, який можна прочитати, Head завжди вказує на те, куди слід записувати дані.
    //
    // Якщо tail==head, буфер порожній.Довжина кільцевого буфера визначається як відстань між ними.
    //
    tail: usize,
    head: usize,
    buf: RawVec<T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for VecDeque<T> {
    fn clone(&self) -> VecDeque<T> {
        self.iter().cloned().collect()
    }

    fn clone_from(&mut self, other: &Self) {
        self.truncate(other.len());

        let mut iter = PairSlices::from(self, other);
        while let Some((dst, src)) = iter.next() {
            dst.clone_from_slice(&src);
        }

        if iter.has_remainder() {
            for remainder in iter.remainder() {
                self.extend(remainder.iter().cloned());
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T> Drop for VecDeque<T> {
    fn drop(&mut self) {
        /// Запускає деструктор для всіх предметів у зрізі, коли він падає (зазвичай або під час розмотування).
        ///
        struct Dropper<'a, T>(&'a mut [T]);

        impl<'a, T> Drop for Dropper<'a, T> {
            fn drop(&mut self) {
                unsafe {
                    ptr::drop_in_place(self.0);
                }
            }
        }

        let (front, back) = self.as_mut_slices();
        unsafe {
            let _back_dropper = Dropper(back);
            // використання краплі для [T]
            ptr::drop_in_place(front);
        }
        // RawVec обробляє вивільнення
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for VecDeque<T> {
    /// Створює порожній `VecDeque<T>`.
    #[inline]
    fn default() -> VecDeque<T> {
        VecDeque::new()
    }
}

impl<T> VecDeque<T> {
    /// Незначно зручніше
    #[inline]
    fn ptr(&self) -> *mut T {
        self.buf.ptr()
    }

    /// Незначно зручніше
    #[inline]
    fn cap(&self) -> usize {
        if mem::size_of::<T>() == 0 {
            // Для нульових типів ми завжди маємо максимальну потужність
            MAXIMUM_ZST_CAPACITY
        } else {
            self.buf.capacity()
        }
    }

    /// Перетворіть ptr у зріз
    #[inline]
    unsafe fn buffer_as_slice(&self) -> &[T] {
        unsafe { slice::from_raw_parts(self.ptr(), self.cap()) }
    }

    /// Перетворіть ptr у шматочок мута
    #[inline]
    unsafe fn buffer_as_mut_slice(&mut self) -> &mut [T] {
        unsafe { slice::from_raw_parts_mut(self.ptr(), self.cap()) }
    }

    /// Переміщує елемент із буфера
    #[inline]
    unsafe fn buffer_read(&mut self, off: usize) -> T {
        unsafe { ptr::read(self.ptr().add(off)) }
    }

    /// Записує елемент в буфер, переміщуючи його.
    #[inline]
    unsafe fn buffer_write(&mut self, off: usize, value: T) {
        unsafe {
            ptr::write(self.ptr().add(off), value);
        }
    }

    /// Повертає `true`, якщо буфер має повну ємність.
    #[inline]
    fn is_full(&self) -> bool {
        self.cap() - self.len() == 1
    }

    /// Повертає індекс у базовому буфері для даного індексу логічного елемента.
    ///
    #[inline]
    fn wrap_index(&self, idx: usize) -> usize {
        wrap_index(idx, self.cap())
    }

    /// Повертає індекс у базовому буфері для даного логічного елемента index + addend.
    ///
    #[inline]
    fn wrap_add(&self, idx: usize, addend: usize) -> usize {
        wrap_index(idx.wrapping_add(addend), self.cap())
    }

    /// Повертає індекс у базовому буфері для даного індексу логічного елемента, віднімання.
    ///
    #[inline]
    fn wrap_sub(&self, idx: usize, subtrahend: usize) -> usize {
        wrap_index(idx.wrapping_sub(subtrahend), self.cap())
    }

    /// Копіює суміжний блок пам'яті, довгий від src до dst
    #[inline]
    unsafe fn copy(&self, dst: usize, src: usize, len: usize) {
        debug_assert!(
            dst + len <= self.cap(),
            "cpy dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        debug_assert!(
            src + len <= self.cap(),
            "cpy dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        unsafe {
            ptr::copy(self.ptr().add(src), self.ptr().add(dst), len);
        }
    }

    /// Копіює суміжний блок пам'яті, довгий від src до dst
    #[inline]
    unsafe fn copy_nonoverlapping(&self, dst: usize, src: usize, len: usize) {
        debug_assert!(
            dst + len <= self.cap(),
            "cno dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        debug_assert!(
            src + len <= self.cap(),
            "cno dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        unsafe {
            ptr::copy_nonoverlapping(self.ptr().add(src), self.ptr().add(dst), len);
        }
    }

    /// Копіює потенційно обгортаючий блок пам'яті, довгий від src до призначення.
    /// (abs(dst - src) + len) не повинен перевищувати cap() (між src і dest має бути не більше як одна область безперервного перекриття).
    ///
    unsafe fn wrap_copy(&self, dst: usize, src: usize, len: usize) {
        #[allow(dead_code)]
        fn diff(a: usize, b: usize) -> usize {
            if a <= b { b - a } else { a - b }
        }
        debug_assert!(
            cmp::min(diff(dst, src), self.cap() - diff(dst, src)) + len <= self.cap(),
            "wrc dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );

        if src == dst || len == 0 {
            return;
        }

        let dst_after_src = self.wrap_sub(dst, src) < len;

        let src_pre_wrap_len = self.cap() - src;
        let dst_pre_wrap_len = self.cap() - dst;
        let src_wraps = src_pre_wrap_len < len;
        let dst_wraps = dst_pre_wrap_len < len;

        match (dst_after_src, src_wraps, dst_wraps) {
            (_, false, false) => {
                // src не обгортає, dst не обгортає
                //
                //        S...
                // 1 [_ _ A A B B C C _]
                // 2 [_ _ A A A A B B _] D.
                // .
                // .
                unsafe {
                    self.copy(dst, src, len);
                }
            }
            (false, false, true) => {
                // dst перед src, src не загортається, dst обгортає
                //
                //
                //    S...
                // 1 [A A B B _ _ _ C C]
                // 2 [A A B B _ _ _ A A]
                // 3 [B B B B _ _ _ A A] .. D.
                //
                unsafe {
                    self.copy(dst, src, dst_pre_wrap_len);
                    self.copy(0, src + dst_pre_wrap_len, len - dst_pre_wrap_len);
                }
            }
            (true, false, true) => {
                // src перед dst, src не загортає, dst обгортає
                //
                //
                //              S...
                // 1 [C C _ _ _ A A B B]
                // 2 [B B _ _ _ A A B B]
                // 3 [B B _ _ _ A A A A] .. D.
                //
                unsafe {
                    self.copy(0, src + dst_pre_wrap_len, len - dst_pre_wrap_len);
                    self.copy(dst, src, dst_pre_wrap_len);
                }
            }
            (false, true, false) => {
                // dst перед src, src обгортає, dst не обгортає
                //
                //
                //    .. S.
                // 1 [C C _ _ _ A A B B]
                // 2 [C C _ _ _ B B B B]
                // 3 [C C _ _ _ B B C C] D...
                //
                unsafe {
                    self.copy(dst, src, src_pre_wrap_len);
                    self.copy(dst + src_pre_wrap_len, 0, len - src_pre_wrap_len);
                }
            }
            (true, true, false) => {
                // src перед dst, src обгортає, dst не обгортає
                //
                //
                //    .. S.
                // 1 [A A B B _ _ _ C C]
                // 2 [A A A A _ _ _ C C]
                // 3 [C C A A _ _ _ C C] D...
                //
                unsafe {
                    self.copy(dst + src_pre_wrap_len, 0, len - src_pre_wrap_len);
                    self.copy(dst, src, src_pre_wrap_len);
                }
            }
            (false, true, true) => {
                // dst перед src, обгортаннями src, обгортаннями dst
                //
                //
                //    ... S.
                // 1 [A B C D _ E F G H]
                // 2 [A B C D _ E G H H]
                // 3 [A B C D _ E G H A]
                // 4 [B C C D _ E G H A] .. D..
                //
                debug_assert!(dst_pre_wrap_len > src_pre_wrap_len);
                let delta = dst_pre_wrap_len - src_pre_wrap_len;
                unsafe {
                    self.copy(dst, src, src_pre_wrap_len);
                    self.copy(dst + src_pre_wrap_len, 0, delta);
                    self.copy(0, delta, len - dst_pre_wrap_len);
                }
            }
            (true, true, true) => {
                // src перед dst, src обгортання, dst обгортання
                //
                //
                //    .. S..
                // 1 [A B C D _ E F G H]
                // 2 [A A B D _ E F G H]
                // 3 [H A B D _ E F G H]
                // 4 [H A B D _ E F F G]... Д.
                //
                debug_assert!(src_pre_wrap_len > dst_pre_wrap_len);
                let delta = src_pre_wrap_len - dst_pre_wrap_len;
                unsafe {
                    self.copy(delta, 0, len - src_pre_wrap_len);
                    self.copy(0, self.cap() - delta, delta);
                    self.copy(dst, src, dst_pre_wrap_len);
                }
            }
        }
    }

    /// Обволікає ділянки голови та хвоста навколо, щоб обробити той факт, що ми щойно перерозподілились.
    /// Небезпечно, оскільки довіряє old_capacity.
    #[inline]
    unsafe fn handle_capacity_increase(&mut self, old_capacity: usize) {
        let new_capacity = self.cap();

        // Перемістіть найкоротший суміжний ділянку кільцевого буфера TH
        //
        //   [o o o o o o o . ]
        //    THA [o o o o o o o . . . . . . . . . ] HT
        //   [o o . o o o o o ]
        //          THB [...ооооооо......
        //          ] HT
        //   [o o o o o . o o ]
        //              HTC [o o o o o . . . . . . . . . o o ]
        //
        //
        //
        //

        if self.tail <= self.head {
            // Nop
            //
        } else if self.head < old_capacity - self.tail {
            // B
            unsafe {
                self.copy_nonoverlapping(old_capacity, 0, self.head);
            }
            self.head += old_capacity;
            debug_assert!(self.head > self.tail);
        } else {
            // C
            let new_tail = new_capacity - (old_capacity - self.tail);
            unsafe {
                self.copy_nonoverlapping(new_tail, self.tail, old_capacity - self.tail);
            }
            self.tail = new_tail;
            debug_assert!(self.head < self.tail);
        }
        debug_assert!(self.head < self.cap());
        debug_assert!(self.tail < self.cap());
        debug_assert!(self.cap().count_ones() == 1);
    }
}

impl<T> VecDeque<T> {
    /// Створює порожній `VecDeque`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let vector: VecDeque<u32> = VecDeque::new();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new() -> VecDeque<T> {
        VecDeque::with_capacity(INITIAL_CAPACITY)
    }

    /// Створює порожній `VecDeque` з місцем принаймні для елементів `capacity`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let vector: VecDeque<u32> = VecDeque::with_capacity(10);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> VecDeque<T> {
        // +1, оскільки буфер обміну завжди залишає одне місце порожнім
        let cap = cmp::max(capacity + 1, MINIMUM_CAPACITY + 1).next_power_of_two();
        assert!(cap > capacity, "capacity overflow");

        VecDeque { tail: 0, head: 0, buf: RawVec::with_capacity(cap) }
    }

    /// Надає посилання на елемент за вказаним індексом.
    ///
    /// Елемент з індексом 0-це передня частина черги.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// buf.push_back(5);
    /// assert_eq!(buf.get(1), Some(&4));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get(&self, index: usize) -> Option<&T> {
        if index < self.len() {
            let idx = self.wrap_add(self.tail, index);
            unsafe { Some(&*self.ptr().add(idx)) }
        } else {
            None
        }
    }

    /// Забезпечує змінне посилання на елемент за вказаним індексом.
    ///
    /// Елемент з індексом 0-це передня частина черги.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// buf.push_back(5);
    /// if let Some(elem) = buf.get_mut(1) {
    ///     *elem = 7;
    /// }
    ///
    /// assert_eq!(buf[1], 7);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get_mut(&mut self, index: usize) -> Option<&mut T> {
        if index < self.len() {
            let idx = self.wrap_add(self.tail, index);
            unsafe { Some(&mut *self.ptr().add(idx)) }
        } else {
            None
        }
    }

    /// Змінює елементи за індексами `i` та `j`.
    ///
    /// `i` і `j` може бути рівним.
    ///
    /// Елемент з індексом 0-це передня частина черги.
    ///
    /// # Panics
    ///
    /// Panics, якщо будь-який індекс виходить за межі.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// buf.push_back(5);
    /// assert_eq!(buf, [3, 4, 5]);
    /// buf.swap(0, 2);
    /// assert_eq!(buf, [5, 4, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn swap(&mut self, i: usize, j: usize) {
        assert!(i < self.len());
        assert!(j < self.len());
        let ri = self.wrap_add(self.tail, i);
        let rj = self.wrap_add(self.tail, j);
        unsafe { ptr::swap(self.ptr().add(ri), self.ptr().add(rj)) }
    }

    /// Повертає кількість елементів, які `VecDeque` може вмістити без перерозподілу.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let buf: VecDeque<i32> = VecDeque::with_capacity(10);
    /// assert!(buf.capacity() >= 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.cap() - 1
    }

    /// Резервує мінімальну ємність для рівно `additional` більше елементів, які потрібно вставити в даний `VecDeque`.
    /// Нічого не робить, якщо потужності вже достатньо.
    ///
    /// Зверніть увагу, що розподільник може надати колекції більше місця, ніж вимагає.
    /// Тому на потужність не можна покладатися як мінімально.
    /// Віддайте перевагу [`reserve`], якщо очікується вставка future.
    ///
    /// # Panics
    ///
    /// Panics, якщо нова потужність перевищує `usize`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<i32> = vec![1].into_iter().collect();
    /// buf.reserve_exact(10);
    /// assert!(buf.capacity() >= 11);
    /// ```
    ///
    /// [`reserve`]: VecDeque::reserve
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.reserve(additional);
    }

    /// Резервує ємність щонайменше для `additional` більше елементів, які потрібно вставити в даний `VecDeque`.
    /// Колекція може зарезервувати більше місця, щоб уникнути частих перерозподілів.
    ///
    /// # Panics
    ///
    /// Panics, якщо нова потужність перевищує `usize`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<i32> = vec![1].into_iter().collect();
    /// buf.reserve(10);
    /// assert!(buf.capacity() >= 11);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        let old_cap = self.cap();
        let used_cap = self.len() + 1;
        let new_cap = used_cap
            .checked_add(additional)
            .and_then(|needed_cap| needed_cap.checked_next_power_of_two())
            .expect("capacity overflow");

        if new_cap > old_cap {
            self.buf.reserve_exact(used_cap, new_cap - used_cap);
            unsafe {
                self.handle_capacity_increase(old_cap);
            }
        }
    }

    /// Намагається зарезервувати мінімальну ємність для рівно `additional`, щоб більше елементів було вставлено в даний `VecDeque<T>`.
    ///
    /// Після виклику `try_reserve_exact` ємність буде більшою або дорівнює `self.len() + additional`.
    /// Нічого не робить, якщо потужності вже достатньо.
    ///
    /// Зверніть увагу, що розподільник може надати колекції більше місця, ніж вимагає.
    /// Тому на потужність не можна покладатися як мінімально.
    /// Віддайте перевагу `reserve`, якщо очікується вставка future.
    ///
    /// # Errors
    ///
    /// Якщо ємність переповнює `usize`, або розподільник повідомляє про несправність, тоді помилка повертається.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    /// use std::collections::VecDeque;
    ///
    /// fn process_data(data: &[u32]) -> Result<VecDeque<u32>, TryReserveError> {
    ///     let mut output = VecDeque::new();
    ///
    ///     // Попередньо зарезервуйте пам'ять, виходячи, якщо ми не можемо
    ///     output.try_reserve_exact(data.len())?;
    ///
    ///     // Тепер ми знаємо, що це не може OOM(Out-Of-Memory) в середині нашої складної роботи
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // дуже складно
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.try_reserve(additional)
    }

    /// Намагається зарезервувати ємність щонайменше для `additional`, щоб до даного `VecDeque<T>` було вставлено більше елементів.
    /// Колекція може зарезервувати більше місця, щоб уникнути частих перерозподілів.
    /// Після виклику `try_reserve` ємність буде більшою або дорівнює `self.len() + additional`.
    /// Нічого не робить, якщо потужності вже достатньо.
    ///
    /// # Errors
    ///
    /// Якщо ємність переповнює `usize`, або розподільник повідомляє про несправність, тоді помилка повертається.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    /// use std::collections::VecDeque;
    ///
    /// fn process_data(data: &[u32]) -> Result<VecDeque<u32>, TryReserveError> {
    ///     let mut output = VecDeque::new();
    ///
    ///     // Попередньо зарезервуйте пам'ять, виходячи, якщо ми не можемо
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Тепер ми знаємо, що це не може OOM в середині нашої складної роботи
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // дуже складно
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        let old_cap = self.cap();
        let used_cap = self.len() + 1;
        let new_cap = used_cap
            .checked_add(additional)
            .and_then(|needed_cap| needed_cap.checked_next_power_of_two())
            .ok_or(TryReserveError::CapacityOverflow)?;

        if new_cap > old_cap {
            self.buf.try_reserve_exact(used_cap, new_cap - used_cap)?;
            unsafe {
                self.handle_capacity_increase(old_cap);
            }
        }
        Ok(())
    }

    /// Максимально зменшує ємність `VecDeque`.
    ///
    /// Він знизиться якомога ближче до довжини, але розподільник все одно може повідомити `VecDeque`, що є місце для ще кількох елементів.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::with_capacity(15);
    /// buf.extend(0..4);
    /// assert_eq!(buf.capacity(), 15);
    /// buf.shrink_to_fit();
    /// assert!(buf.capacity() >= 4);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn shrink_to_fit(&mut self) {
        self.shrink_to(0);
    }

    /// Зменшує ємність `VecDeque` з нижньою межею.
    ///
    /// Ємність залишатиметься принаймні такою ж, як довжина, так і вартість, що постачається.
    ///
    ///
    /// Якщо поточна потужність менше нижньої межі, це заборона.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::with_capacity(15);
    /// buf.extend(0..4);
    /// assert_eq!(buf.capacity(), 15);
    /// buf.shrink_to(6);
    /// assert!(buf.capacity() >= 6);
    /// buf.shrink_to(0);
    /// assert!(buf.capacity() >= 4);
    /// ```
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        let min_capacity = cmp::min(min_capacity, self.capacity());
        // Нам не потрібно турбуватися про переповнення, оскільки ні `self.len()`, ні `self.capacity()` ніколи не можуть бути `usize::MAX`.
        // +1, оскільки буфер дзвінків завжди залишає одне місце порожнім.
        let target_cap = cmp::max(cmp::max(min_capacity, self.len()) + 1, MINIMUM_CAPACITY + 1)
            .next_power_of_two();

        if target_cap < self.cap() {
            // Є три випадки інтересу:
            //   Всі елементи виходять за межі бажаних Елементи суміжні, а голова виходить за межі бажаних Елементи несумісні, а хвіст виходить за межі бажаних
            //
            //
            // У будь-який інший час позиції елементів не змінюються.
            //
            // Вказує на те, що елементи на голові слід переміщати.
            //
            let head_outside = self.head == 0 || self.head >= target_cap;
            // Переміщення елементів за межі бажаних меж (позиції після target_cap)
            if self.tail >= target_cap && head_outside {
                // Ч.
                //   [. . . . . . . . o o o o o o o . ]
                //    Ч.
                //   [o o o o o o o . ]
                unsafe {
                    self.copy_nonoverlapping(0, self.tail, self.len());
                }
                self.head = self.len();
                self.tail = 0;
            } else if self.tail != 0 && self.tail < target_cap && head_outside {
                // Ч.
                //   [. . . o o o o o o o . . . . . . ]
                //        H T
                //   [o o . o o o o o ]
                let len = self.wrap_sub(self.head, target_cap);
                unsafe {
                    self.copy_nonoverlapping(0, target_cap, len);
                }
                self.head = len;
                debug_assert!(self.head < self.tail);
            } else if self.tail >= target_cap {
                // HT
                //   [o o o o o . . . . . . . . . o o ]
                //              H T
                //   [o o o o o . o o ]
                debug_assert!(self.wrap_sub(self.head, 1) < target_cap);
                let len = self.cap() - self.tail;
                let new_tail = target_cap - len;
                unsafe {
                    self.copy_nonoverlapping(new_tail, self.tail, len);
                }
                self.tail = new_tail;
                debug_assert!(self.head < self.tail);
            }

            self.buf.shrink_to_fit(target_cap);

            debug_assert!(self.head < self.cap());
            debug_assert!(self.tail < self.cap());
            debug_assert!(self.cap().count_ones() == 1);
        }
    }

    /// Укорочує `VecDeque`, зберігаючи перші елементи `len`, а решту скидає.
    ///
    ///
    /// Якщо `len` перевищує поточну довжину `VecDeque`, це не впливає.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(10);
    /// buf.push_back(15);
    /// assert_eq!(buf, [5, 10, 15]);
    /// buf.truncate(1);
    /// assert_eq!(buf, [5]);
    /// ```
    ///
    #[stable(feature = "deque_extras", since = "1.16.0")]
    pub fn truncate(&mut self, len: usize) {
        /// Запускає деструктор для всіх предметів у зрізі, коли він падає (зазвичай або під час розмотування).
        ///
        struct Dropper<'a, T>(&'a mut [T]);

        impl<'a, T> Drop for Dropper<'a, T> {
            fn drop(&mut self) {
                unsafe {
                    ptr::drop_in_place(self.0);
                }
            }
        }

        // Безпечний, оскільки:
        //
        // * Будь-який фрагмент, переданий `drop_in_place`, є дійсним;другий корпус має `len <= front.len()`, а повернення на `len > self.len()` забезпечує `begin <= back.len()` у першому випадку
        //
        // * Голова VecDeque переміщується перед викликом `drop_in_place`, тому жодне значення не скидається двічі, якщо `drop_in_place` panics
        //
        //
        unsafe {
            if len > self.len() {
                return;
            }
            let num_dropped = self.len() - len;
            let (front, back) = self.as_mut_slices();
            if len > front.len() {
                let begin = len - front.len();
                let drop_back = back.get_unchecked_mut(begin..) as *mut _;
                self.head = self.wrap_sub(self.head, num_dropped);
                ptr::drop_in_place(drop_back);
            } else {
                let drop_back = back as *mut _;
                let drop_front = front.get_unchecked_mut(len..) as *mut _;
                self.head = self.wrap_sub(self.head, num_dropped);

                // Переконайтеся, що друга половина відкинута, навіть якщо деструктор у першій panics.
                //
                let _back_dropper = Dropper(&mut *drop_back);
                ptr::drop_in_place(drop_front);
            }
        }
    }

    /// Повертає фронтальний ітератор.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// let b: &[_] = &[&5, &3, &4];
    /// let c: Vec<&i32> = buf.iter().collect();
    /// assert_eq!(&c[..], b);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter { tail: self.tail, head: self.head, ring: unsafe { self.buffer_as_slice() } }
    }

    /// Повертає фронтальний ітератор, який повертає змінні посилання.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// for num in buf.iter_mut() {
    ///     *num = *num - 2;
    /// }
    /// let b: &[_] = &[&mut 3, &mut 1, &mut 2];
    /// assert_eq!(&buf.iter_mut().collect::<Vec<&mut i32>>()[..], b);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        // БЕЗПЕКА: Внутрішній інваріант безпеки `IterMut` встановлений, оскільки
        // `ring` ми створюємо фрагмент, який неможливо розпізнати протягом усього життя '_.
        IterMut {
            tail: self.tail,
            head: self.head,
            ring: ptr::slice_from_raw_parts_mut(self.ptr(), self.cap()),
            phantom: PhantomData,
        }
    }

    /// Повертає пару фрагментів, які містять у порядку вміст `VecDeque`.
    ///
    /// Якщо раніше було викликано [`make_contiguous`], усі елементи `VecDeque` будуть у першому фрагменті, а другий фрагмент буде порожнім.
    ///
    ///
    /// [`make_contiguous`]: VecDeque::make_contiguous
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vector = VecDeque::new();
    ///
    /// vector.push_back(0);
    /// vector.push_back(1);
    /// vector.push_back(2);
    ///
    /// assert_eq!(vector.as_slices(), (&[0, 1, 2][..], &[][..]));
    ///
    /// vector.push_front(10);
    /// vector.push_front(9);
    ///
    /// assert_eq!(vector.as_slices(), (&[9, 10][..], &[0, 1, 2][..]));
    /// ```
    ///
    #[inline]
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn as_slices(&self) -> (&[T], &[T]) {
        unsafe {
            let buf = self.buffer_as_slice();
            RingSlices::ring_slices(buf, self.head, self.tail)
        }
    }

    /// Повертає пару фрагментів, які містять у порядку вміст `VecDeque`.
    ///
    /// Якщо раніше було викликано [`make_contiguous`], усі елементи `VecDeque` будуть у першому фрагменті, а другий фрагмент буде порожнім.
    ///
    ///
    /// [`make_contiguous`]: VecDeque::make_contiguous
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vector = VecDeque::new();
    ///
    /// vector.push_back(0);
    /// vector.push_back(1);
    ///
    /// vector.push_front(10);
    /// vector.push_front(9);
    ///
    /// vector.as_mut_slices().0[0] = 42;
    /// vector.as_mut_slices().1[0] = 24;
    /// assert_eq!(vector.as_slices(), (&[42, 10][..], &[24, 1][..]));
    /// ```
    ///
    #[inline]
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn as_mut_slices(&mut self) -> (&mut [T], &mut [T]) {
        unsafe {
            let head = self.head;
            let tail = self.tail;
            let buf = self.buffer_as_mut_slice();
            RingSlices::ring_slices(buf, head, tail)
        }
    }

    /// Повертає кількість елементів у `VecDeque`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v = VecDeque::new();
    /// assert_eq!(v.len(), 0);
    /// v.push_back(1);
    /// assert_eq!(v.len(), 1);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        count(self.tail, self.head, self.cap())
    }

    /// Повертає `true`, якщо `VecDeque` порожній.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v = VecDeque::new();
    /// assert!(v.is_empty());
    /// v.push_front(1);
    /// assert!(!v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.tail == self.head
    }

    fn range_tail_head<R>(&self, range: R) -> (usize, usize)
    where
        R: RangeBounds<usize>,
    {
        let Range { start, end } = slice::range(range, ..self.len());
        let tail = self.wrap_add(self.tail, start);
        let head = self.wrap_add(self.tail, end);
        (tail, head)
    }

    /// Створює ітератор, який охоплює вказаний діапазон у `VecDeque`.
    ///
    /// # Panics
    ///
    /// Panics, якщо початкова точка більша за кінцеву точку або якщо кінцева точка більша за довжину vector.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let v: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// let range = v.range(2..).copied().collect::<VecDeque<_>>();
    /// assert_eq!(range, [3]);
    ///
    /// // Повний асортимент охоплює весь вміст
    /// let all = v.range(..);
    /// assert_eq!(all.len(), 3);
    /// ```
    #[inline]
    #[stable(feature = "deque_range", since = "1.51.0")]
    pub fn range<R>(&self, range: R) -> Iter<'_, T>
    where
        R: RangeBounds<usize>,
    {
        let (tail, head) = self.range_tail_head(range);
        Iter {
            tail,
            head,
            // Спільне посилання, яке ми маємо в &self, зберігається в '_ Ітера.
            ring: unsafe { self.buffer_as_slice() },
        }
    }

    /// Створює ітератор, який охоплює вказаний змінний діапазон у `VecDeque`.
    ///
    /// # Panics
    ///
    /// Panics, якщо початкова точка більша за кінцеву точку або якщо кінцева точка більша за довжину vector.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// for v in v.range_mut(2..) {
    ///   *v *= 2;
    /// }
    /// assert_eq!(v, vec![1, 2, 6]);
    ///
    /// // Повний асортимент охоплює весь вміст
    /// for v in v.range_mut(..) {
    ///   *v *= 2;
    /// }
    /// assert_eq!(v, vec![2, 4, 12]);
    /// ```
    #[inline]
    #[stable(feature = "deque_range", since = "1.51.0")]
    pub fn range_mut<R>(&mut self, range: R) -> IterMut<'_, T>
    where
        R: RangeBounds<usize>,
    {
        let (tail, head) = self.range_tail_head(range);

        // БЕЗПЕКА: Внутрішній інваріант безпеки `IterMut` встановлений, оскільки
        // `ring` ми створюємо фрагмент, який неможливо розпізнати протягом усього життя '_.
        IterMut {
            tail,
            head,
            ring: ptr::slice_from_raw_parts_mut(self.ptr(), self.cap()),
            phantom: PhantomData,
        }
    }

    /// Створює дренажний ітератор, який видаляє вказаний діапазон в `VecDeque` і видає вилучені елементи.
    ///
    /// Примітка 1. Діапазон елементів видаляється, навіть якщо ітератор не використовується до кінця.
    ///
    /// Примітка 2: Не вказано, скільки елементів буде видалено з деке, якщо значення `Drain` не скидається, але термін дії позики, який він має, закінчується (наприклад, через `mem::forget`).
    ///
    ///
    /// # Panics
    ///
    /// Panics, якщо початкова точка більша за кінцеву точку або якщо кінцева точка більша за довжину vector.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// let drained = v.drain(2..).collect::<VecDeque<_>>();
    /// assert_eq!(drained, [3]);
    /// assert_eq!(v, [1, 2]);
    ///
    /// // Повний асортимент очищає весь вміст
    /// v.drain(..);
    /// assert!(v.is_empty());
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_, T>
    where
        R: RangeBounds<usize>,
    {
        // Безпека пам`яті
        //
        // Коли Drain створюється вперше, вихідний код скорочується, щоб переконатися, що неініціалізовані або переміщені елементи взагалі не доступні, якщо деструктор Drain ніколи не запускається.
        //
        //
        // Drain видасть ptr::read значення для видалення.
        // Після закінчення дані, що залишились, будуть скопійовані назад, щоб закрити дірку, і значення head/tail будуть відновлені правильно.
        //
        //
        //
        let (drain_tail, drain_head) = self.range_tail_head(range);

        // Елементи Деке розділені на три сегменти:
        // * self.tail  -> drain_tail
        // * drain_tail-> drain_head
        // * drain_head-> self.head
        //
        // Т=Х00Х;H= self.head;t=drain_tail;h=drain_head
        //
        // Ми зберігаємо drain_tail як self.head, а drain_head та self.head як after_tail та after_head відповідно на Drain.
        // Це також скорочує ефективний масив таким чином, що якщо Drain витікає, ми забули про потенційно переміщені значення після запуску drain.
        //
        //
        //        T-й H
        // [. . . o o x x o o . . .]
        //
        //
        //
        let head = self.head;

        // "forget" про значення після запуску drain до завершення роботи drain і запуску деструктора Drain.
        //
        self.head = drain_tail;

        Drain {
            deque: NonNull::from(&mut *self),
            after_tail: drain_head,
            after_head: head,
            iter: Iter {
                tail: drain_tail,
                head: drain_head,
                // Важливо те, що ми лише створюємо спільні посилання з `self` і читаємо з них.
                // Ми не пишемо на `self` і не переходимо до змінних посилань.
                // Отже, необроблений вказівник, який ми створили вище, для `deque`, залишається дійсним.
                ring: unsafe { self.buffer_as_slice() },
            },
        }
    }

    /// Очищає `VecDeque`, видаляючи всі значення.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v = VecDeque::new();
    /// v.push_back(1);
    /// v.clear();
    /// assert!(v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn clear(&mut self) {
        self.truncate(0);
    }

    /// Повертає `true`, якщо `VecDeque` містить елемент, що дорівнює заданому значенню.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vector: VecDeque<u32> = VecDeque::new();
    ///
    /// vector.push_back(0);
    /// vector.push_back(1);
    ///
    /// assert_eq!(vector.contains(&1), true);
    /// assert_eq!(vector.contains(&10), false);
    /// ```
    #[stable(feature = "vec_deque_contains", since = "1.12.0")]
    pub fn contains(&self, x: &T) -> bool
    where
        T: PartialEq<T>,
    {
        let (a, b) = self.as_slices();
        a.contains(x) || b.contains(x)
    }

    /// Надає посилання на передній елемент або `None`, якщо `VecDeque` порожній.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.front(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// assert_eq!(d.front(), Some(&1));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn front(&self) -> Option<&T> {
        self.get(0)
    }

    /// Надає змінне посилання на передній елемент або `None`, якщо `VecDeque` порожній.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.front_mut(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// match d.front_mut() {
    ///     Some(x) => *x = 9,
    ///     None => (),
    /// }
    /// assert_eq!(d.front(), Some(&9));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn front_mut(&mut self) -> Option<&mut T> {
        self.get_mut(0)
    }

    /// Надає посилання на задній елемент або `None`, якщо `VecDeque` порожній.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.back(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// assert_eq!(d.back(), Some(&2));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn back(&self) -> Option<&T> {
        self.get(self.len().wrapping_sub(1))
    }

    /// Надає змінне посилання на задній елемент або `None`, якщо `VecDeque` порожній.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.back(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// match d.back_mut() {
    ///     Some(x) => *x = 9,
    ///     None => (),
    /// }
    /// assert_eq!(d.back(), Some(&9));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn back_mut(&mut self) -> Option<&mut T> {
        self.get_mut(self.len().wrapping_sub(1))
    }

    /// Видаляє перший елемент і повертає його, або `None`, якщо `VecDeque` порожній.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// d.push_back(1);
    /// d.push_back(2);
    ///
    /// assert_eq!(d.pop_front(), Some(1));
    /// assert_eq!(d.pop_front(), Some(2));
    /// assert_eq!(d.pop_front(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop_front(&mut self) -> Option<T> {
        if self.is_empty() {
            None
        } else {
            let tail = self.tail;
            self.tail = self.wrap_add(self.tail, 1);
            unsafe { Some(self.buffer_read(tail)) }
        }
    }

    /// Видаляє останній елемент із `VecDeque` і повертає його, або `None`, якщо він порожній.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// assert_eq!(buf.pop_back(), None);
    /// buf.push_back(1);
    /// buf.push_back(3);
    /// assert_eq!(buf.pop_back(), Some(3));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop_back(&mut self) -> Option<T> {
        if self.is_empty() {
            None
        } else {
            self.head = self.wrap_sub(self.head, 1);
            let head = self.head;
            unsafe { Some(self.buffer_read(head)) }
        }
    }

    /// Додає елемент до `VecDeque`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// d.push_front(1);
    /// d.push_front(2);
    /// assert_eq!(d.front(), Some(&2));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_front(&mut self, value: T) {
        if self.is_full() {
            self.grow();
        }

        self.tail = self.wrap_sub(self.tail, 1);
        let tail = self.tail;
        unsafe {
            self.buffer_write(tail, value);
        }
    }

    /// Додає елемент до задньої частини `VecDeque`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(1);
    /// buf.push_back(3);
    /// assert_eq!(3, *buf.back().unwrap());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_back(&mut self, value: T) {
        if self.is_full() {
            self.grow();
        }

        let head = self.head;
        self.head = self.wrap_add(self.head, 1);
        unsafe { self.buffer_write(head, value) }
    }

    #[inline]
    fn is_contiguous(&self) -> bool {
        // FIXME: Чи слід вважати `head == 0` маючи на увазі
        // що `self` є суміжним?
        self.tail <= self.head
    }

    /// Видаляє елемент з будь-якого місця `VecDeque` і повертає його, замінюючи першим елементом.
    ///
    ///
    /// Це не зберігає впорядкування, але є *O*(1).
    ///
    /// Повертає `None`, якщо `index` поза межами.
    ///
    /// Елемент з індексом 0-це передня частина черги.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// assert_eq!(buf.swap_remove_front(0), None);
    /// buf.push_back(1);
    /// buf.push_back(2);
    /// buf.push_back(3);
    /// assert_eq!(buf, [1, 2, 3]);
    ///
    /// assert_eq!(buf.swap_remove_front(2), Some(3));
    /// assert_eq!(buf, [2, 1]);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn swap_remove_front(&mut self, index: usize) -> Option<T> {
        let length = self.len();
        if length > 0 && index < length && index != 0 {
            self.swap(index, 0);
        } else if index >= length {
            return None;
        }
        self.pop_front()
    }

    /// Видаляє елемент з будь-якої точки `VecDeque` і повертає його, замінюючи останнім елементом.
    ///
    ///
    /// Це не зберігає впорядкування, але є *O*(1).
    ///
    /// Повертає `None`, якщо `index` поза межами.
    ///
    /// Елемент з індексом 0-це передня частина черги.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// assert_eq!(buf.swap_remove_back(0), None);
    /// buf.push_back(1);
    /// buf.push_back(2);
    /// buf.push_back(3);
    /// assert_eq!(buf, [1, 2, 3]);
    ///
    /// assert_eq!(buf.swap_remove_back(0), Some(1));
    /// assert_eq!(buf, [3, 2]);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn swap_remove_back(&mut self, index: usize) -> Option<T> {
        let length = self.len();
        if length > 0 && index < length - 1 {
            self.swap(index, length - 1);
        } else if index >= length {
            return None;
        }
        self.pop_back()
    }

    /// Вставляє елемент в `index` всередині `VecDeque`, зсуваючи всі елементи з індексами, більшими або рівними `index`, у напрямку назад.
    ///
    ///
    /// Елемент з індексом 0-це передня частина черги.
    ///
    /// # Panics
    ///
    /// Panics, якщо `index` перевищує довжину `VecDeque`
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vec_deque = VecDeque::new();
    /// vec_deque.push_back('a');
    /// vec_deque.push_back('b');
    /// vec_deque.push_back('c');
    /// assert_eq!(vec_deque, &['a', 'b', 'c']);
    ///
    /// vec_deque.insert(1, 'd');
    /// assert_eq!(vec_deque, &['a', 'd', 'b', 'c']);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn insert(&mut self, index: usize, value: T) {
        assert!(index <= self.len(), "index out of bounds");
        if self.is_full() {
            self.grow();
        }

        // Перемістіть найменшу кількість елементів у кільцевий буфер та вставте даний об`єкт
        //
        // Найбільше len/2, 1 елемент буде переміщено. O(min(n, n-i))
        //
        // Є три основні випадки:
        //  Елементи суміжні
        //      - особливий випадок, коли хвіст 0 Елементи несумісні і вставка знаходиться в хвостовій частині Елементи несумісні і вставка знаходиться в головній секції
        //
        //
        // Для кожного з них є ще два випадки:
        //  Вставка ближче до хвоста Вставка ближче до голови
        //
        // Клавіша: H, self.head
        //      T, self.tail o, Дійсний елемент I, Елемент вставки A, Елемент, який повинен бути після точки вставки M, Вказує, що елемент переміщено
        //
        //
        //
        //
        //
        //
        //

        let idx = self.wrap_add(self.tail, index);

        let distance_to_tail = index;
        let distance_to_head = self.len() - index;

        let contiguous = self.is_contiguous();

        match (contiguous, distance_to_tail <= distance_to_head, idx >= self.tail) {
            (true, true, _) if index == 0 => {
                // push_front
                //
                //       TIH
                //      [Оооооо.......
                //      .
                //      .]
                //
                //                       HT
                //      [A o o o o o o o . . . . . I]

                self.tail = self.wrap_sub(self.tail, 1);
            }
            (true, true, _) => {
                unsafe {
                    // суміжні, вставте ближче до хвоста:
                    //
                    //             TIH
                    //      [. . . o o A o o o o . . . . . .]
                    //
                    //           Ч.
                    //      [. . o o I A o o o o . . . . . .]
                    //           M M
                    //
                    // суміжні, вставте ближче до хвоста і хвіст дорівнює 0:
                    //
                    //
                    //       TIH
                    //      [o o A o o o o . . . . . . . . .]
                    //
                    //                       HT
                    //      [o I A o o o o o . . . . . . . o]
                    //       ММ

                    let new_tail = self.wrap_sub(self.tail, 1);

                    self.copy(new_tail, self.tail, 1);
                    // Вже перемістили хвіст, тому ми копіюємо лише елементи `index - 1`.
                    self.copy(self.tail, self.tail + 1, index - 1);

                    self.tail = new_tail;
                }
            }
            (true, false, _) => {
                unsafe {
                    // суміжні, вставити ближче до голови:
                    //
                    //             TIH
                    //      [. . . o o o o A o o . . . . . .]
                    //
                    //             Ч.
                    //      [. . . o o o o I A o o . . . . .]
                    //                       МММ

                    self.copy(idx + 1, idx, self.head - idx);
                    self.head = self.wrap_add(self.head, 1);
                }
            }
            (false, true, true) => {
                unsafe {
                    // несумісний, вставити ближче до хвоста, хвіст:
                    //
                    //                   HTI
                    //      [o o o o o o . . . . . o o A o o]
                    //
                    //                   HT
                    //      [o o o o o o . . . . o o I A o o]
                    //                           M M

                    self.copy(self.tail - 1, self.tail, index);
                    self.tail -= 1;
                }
            }
            (false, false, true) => {
                unsafe {
                    // несумісний, вставити ближче до голови, хвіст:
                    //
                    //           HTI
                    //      [o o . . . . . . . o o o o o A o]
                    //
                    //             HT
                    //      [o o o . . . . . . o o o o o I A]
                    //       ММММ

                    // копіювати елементи до нової голови-
                    self.copy(1, 0, self.head);

                    // скопіювати останній елемент у порожнє місце внизу буфера
                    self.copy(0, self.cap() - 1, 1);

                    // перемістити елементи з idx в кінець вперед, не включаючи ^ елемент
                    self.copy(idx + 1, idx, self.cap() - 1 - idx);

                    self.head += 1;
                }
            }
            (false, true, false) if idx == 0 => {
                unsafe {
                    // несумісний, вставка знаходиться ближче до хвоста, головного відділу і має нульовий індекс у внутрішньому буфері:
                    //
                    //
                    //       IHT
                    //      [A o o o o o o o o o . . . o o o]
                    //
                    //                           HT
                    //      [A o o o o o o o o o . . o o o I]
                    //                               МММ

                    // копіювати елементи до нового хвоста--
                    self.copy(self.tail - 1, self.tail, self.cap() - self.tail);

                    // скопіювати останній елемент у порожнє місце внизу буфера
                    self.copy(self.cap() - 1, 0, 1);

                    self.tail -= 1;
                }
            }
            (false, true, false) => {
                unsafe {
                    // несумісний, вставити ближче до хвоста, відділ голови:
                    //
                    //             IHT
                    //      [o o o A o o o o o o . . . o o o]
                    //
                    //                           HT
                    //      [o o I A o o o o o o . . o o o o]
                    //       ММММММ

                    // копіювати елементи до нового хвоста--
                    self.copy(self.tail - 1, self.tail, self.cap() - self.tail);

                    // скопіювати останній елемент у порожнє місце внизу буфера
                    self.copy(self.cap() - 1, 0, 1);

                    // перемістити елементи з idx-1 в кінець вперед, не включаючи ^ елемент
                    self.copy(0, 1, idx - 1);

                    self.tail -= 1;
                }
            }
            (false, false, false) => {
                unsafe {
                    // несумісний, вставити ближче до голови, головний відділ:
                    //
                    //               IHT
                    //      [o o o o A o o . . . . . . o o o]
                    //
                    //                     HT
                    //      [o o o o I A o o . . . . . o o o]
                    //                 МММ

                    self.copy(idx + 1, idx, self.head - idx);
                    self.head += 1;
                }
            }
        }

        // хвіст міг бути змінений, тому нам потрібно перерахувати
        let new_idx = self.wrap_add(self.tail, index);
        unsafe {
            self.buffer_write(new_idx, value);
        }
    }

    /// Видаляє та повертає елемент у `index` із `VecDeque`.
    /// Будь-який кінець, який знаходиться ближче до точки видалення, буде переміщений, щоб звільнити місце, і всі уражені елементи будуть переміщені в нові позиції.
    ///
    /// Повертає `None`, якщо `index` поза межами.
    ///
    /// Елемент з індексом 0-це передня частина черги.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(1);
    /// buf.push_back(2);
    /// buf.push_back(3);
    /// assert_eq!(buf, [1, 2, 3]);
    ///
    /// assert_eq!(buf.remove(1), Some(2));
    /// assert_eq!(buf, [1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, index: usize) -> Option<T> {
        if self.is_empty() || self.len() <= index {
            return None;
        }

        // Є три основні випадки:
        //  Елементи сусідні Елементи несумісні і видалення відбувається в хвостовій частині Елементи несумісні і видалення відбувається в головній секції
        //
        //      - особливий випадок, коли елементи технічно суміжні, але self.head =0
        //
        // Для кожного з них є ще два випадки:
        //  Вставка ближче до хвоста Вставка ближче до голови
        //
        // Клавіша: H, self.head
        //      T, self.tail o, Дійсний елемент x, Елемент, позначений для видалення R, Вказує на елемент, що видаляється M, Вказує на те, що елемент переміщено
        //
        //
        //
        //
        //
        //
        //

        let idx = self.wrap_add(self.tail, index);

        let elem = unsafe { Some(self.buffer_read(idx)) };

        let distance_to_tail = index;
        let distance_to_head = self.len() - index;

        let contiguous = self.is_contiguous();

        match (contiguous, distance_to_tail <= distance_to_head, idx >= self.tail) {
            (true, true, _) => {
                unsafe {
                    // суміжні, витягніть ближче до хвоста:
                    //
                    //             TRH
                    //      [. . . o o x o o o o . . . . . .]
                    //
                    //               Ч.
                    //      [. . . . o o o o o o . . . . . .]
                    //               M M

                    self.copy(self.tail + 1, self.tail, index);
                    self.tail += 1;
                }
            }
            (true, false, _) => {
                unsafe {
                    // суміжні, приберіть ближче до голови:
                    //
                    //             TRH
                    //      [. . . o o o o x o o . . . . . .]
                    //
                    //             Ч.
                    //      [. . . o o o o o o . . . . . . .]
                    //                     M M

                    self.copy(idx, idx + 1, self.head - idx - 1);
                    self.head -= 1;
                }
            }
            (false, true, true) => {
                unsafe {
                    // несумісний, прибрати ближче до хвоста, хвіст:
                    //
                    //                   HTR
                    //      [o o o o o o . . . . . o o x o o]
                    //
                    //                   HT
                    //      [o o o o o o . . . . . . o o o o]
                    //                               M M

                    self.copy(self.tail + 1, self.tail, index);
                    self.tail = self.wrap_add(self.tail, 1);
                }
            }
            (false, false, false) => {
                unsafe {
                    // несумісний, приберіть ближче до голови, відділ голови:
                    //
                    //               RHT
                    //      [o o o o x o o . . . . . . o o o]
                    //
                    //                   HT
                    //      [o o o o o o . . . . . . . o o o]
                    //               M M

                    self.copy(idx, idx + 1, self.head - idx - 1);
                    self.head -= 1;
                }
            }
            (false, false, true) => {
                unsafe {
                    // несумісний, прибрати ближче до голови, хвостової частини:
                    //
                    //             HTR
                    //      [o o o . . . . . . o o o o o x o]
                    //
                    //           HT
                    //      [o o . . . . . . . o o o o o o o]
                    //       ММММ
                    //
                    // або майже суміжні, видаліть поруч з головою, хвостовою частиною:
                    //
                    //       HTR
                    //      [. . . . . . . . . o o o o o x o]
                    //
                    //                         Ч.
                    //      [. . . . . . . . . o o o o o o .]
                    //                                   M

                    // намалювати елементи в хвостовій частині
                    self.copy(idx, idx + 1, self.cap() - idx - 1);

                    // Запобігає затопленню.
                    if self.head != 0 {
                        // скопіювати перший елемент у порожнє місце
                        self.copy(self.cap() - 1, 0, 1);

                        // переміщати елементи в головному відділі назад
                        self.copy(0, 1, self.head - 1);
                    }

                    self.head = self.wrap_sub(self.head, 1);
                }
            }
            (false, true, false) => {
                unsafe {
                    // несумісний, прибрати ближче до хвоста, відділ голови:
                    //
                    //           RHT
                    //      [o o x o o o o o o o . . . o o o]
                    //
                    //                           HT
                    //      [o o o o o o o o o o . . . . o o]
                    //       МММММ

                    // намалювати елементи до idx
                    self.copy(1, 0, idx);

                    // скопіювати останній елемент у порожнє місце
                    self.copy(0, self.cap() - 1, 1);

                    // переміщати елементи від хвоста до кінця вперед, виключаючи останній
                    self.copy(self.tail + 1, self.tail, self.cap() - self.tail - 1);

                    self.tail = self.wrap_add(self.tail, 1);
                }
            }
        }

        elem
    }

    /// Розбиває `VecDeque` на дві частини за заданим індексом.
    ///
    /// Повертає нещодавно виділений `VecDeque`.
    /// `self` містить елементи `[0, at)`, а повернутий `VecDeque`-елементи `[at, len)`.
    ///
    /// Зверніть увагу, що ємність `self` не змінюється.
    ///
    /// Елемент з індексом 0-це передня частина черги.
    ///
    /// # Panics
    ///
    /// Panics, якщо `at > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// let buf2 = buf.split_off(1);
    /// assert_eq!(buf, [1]);
    /// assert_eq!(buf2, [2, 3]);
    /// ```
    #[inline]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    #[stable(feature = "split_off", since = "1.4.0")]
    pub fn split_off(&mut self, at: usize) -> Self {
        let len = self.len();
        assert!(at <= len, "`at` out of bounds");

        let other_len = len - at;
        let mut other = VecDeque::with_capacity(other_len);

        unsafe {
            let (first_half, second_half) = self.as_slices();

            let first_len = first_half.len();
            let second_len = second_half.len();
            if at < first_len {
                // `at` лежить у першій половині.
                let amount_in_first = first_len - at;

                ptr::copy_nonoverlapping(first_half.as_ptr().add(at), other.ptr(), amount_in_first);

                // просто візьміть всю другу половину.
                ptr::copy_nonoverlapping(
                    second_half.as_ptr(),
                    other.ptr().add(amount_in_first),
                    second_len,
                );
            } else {
                // `at` лежить у другій половині, потрібно врахувати елементи, які ми пропустили в першій половині.
                //
                let offset = at - first_len;
                let amount_in_second = second_len - offset;
                ptr::copy_nonoverlapping(
                    second_half.as_ptr().add(offset),
                    other.ptr(),
                    amount_in_second,
                );
            }
        }

        // Очищення там, де знаходяться кінці буферів
        self.head = self.wrap_sub(self.head, other_len);
        other.head = other.wrap_index(other_len);

        other
    }

    /// Переміщує всі елементи `other` у `self`, залишаючи `other` порожнім.
    ///
    /// # Panics
    ///
    /// Panics, якщо нова кількість елементів у себе переповнює `usize`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = vec![1, 2].into_iter().collect();
    /// let mut buf2: VecDeque<_> = vec![3, 4].into_iter().collect();
    /// buf.append(&mut buf2);
    /// assert_eq!(buf, [1, 2, 3, 4]);
    /// assert_eq!(buf2, []);
    /// ```
    #[inline]
    #[stable(feature = "append", since = "1.4.0")]
    pub fn append(&mut self, other: &mut Self) {
        // наївний імпл
        self.extend(other.drain(..));
    }

    /// Зберігає лише елементи, визначені предикатом.
    ///
    /// Іншими словами, видаліть усі елементи `e` так, щоб `f(&e)` повернув false.
    /// Цей метод діє на місці, відвідуючи кожен елемент рівно один раз у вихідному порядку, і зберігає порядок збережених елементів.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.extend(1..5);
    /// buf.retain(|&x| x % 2 == 0);
    /// assert_eq!(buf, [2, 4]);
    /// ```
    ///
    /// Точне замовлення може бути корисним для відстеження зовнішнього стану, наприклад індексу.
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.extend(1..6);
    ///
    /// let keep = [false, true, true, false, true];
    /// let mut i = 0;
    /// buf.retain(|_| (keep[i], i += 1).0);
    /// assert_eq!(buf, [2, 3, 5]);
    /// ```
    #[stable(feature = "vec_deque_retain", since = "1.4.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> bool,
    {
        let len = self.len();
        let mut del = 0;
        for i in 0..len {
            if !f(&self[i]) {
                del += 1;
            } else if del > 0 {
                self.swap(i - del, i);
            }
        }
        if del > 0 {
            self.truncate(len - del);
        }
    }

    // Це може panic або перервати
    #[inline(never)]
    fn grow(&mut self) {
        if self.is_full() {
            let old_cap = self.cap();
            // Подвойте розмір буфера.
            self.buf.reserve_exact(old_cap, old_cap);
            assert!(self.cap() == old_cap * 2);
            unsafe {
                self.handle_capacity_increase(old_cap);
            }
            debug_assert!(!self.is_full());
        }
    }

    /// Змінює `VecDeque` на місці таким чином, що `len()` дорівнює `new_len`, або шляхом видалення зайвих елементів ззаду, або шляхом додавання елементів, створених за допомогою виклику `generator` до тилу.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(10);
    /// buf.push_back(15);
    /// assert_eq!(buf, [5, 10, 15]);
    ///
    /// buf.resize_with(5, Default::default);
    /// assert_eq!(buf, [5, 10, 15, 0, 0]);
    ///
    /// buf.resize_with(2, || unreachable!());
    /// assert_eq!(buf, [5, 10]);
    ///
    /// let mut state = 100;
    /// buf.resize_with(5, || { state += 1; state });
    /// assert_eq!(buf, [5, 10, 101, 102, 103]);
    /// ```
    ///
    #[stable(feature = "vec_resize_with", since = "1.33.0")]
    pub fn resize_with(&mut self, new_len: usize, generator: impl FnMut() -> T) {
        let len = self.len();

        if new_len > len {
            self.extend(repeat_with(generator).take(new_len - len))
        } else {
            self.truncate(new_len);
        }
    }

    /// Переставляє внутрішнє сховище цього деке, таким чином, це один суміжний фрагмент, який потім повертається.
    ///
    /// Цей метод не виділяє і не змінює порядок вставлених елементів.Оскільки він повертає змінний фрагмент, це може бути використано для сортування деке.
    ///
    /// Як тільки внутрішнє сховище буде суміжним, методи [`as_slices`] і [`as_mut_slices`] повернуть весь вміст `VecDeque` в один фрагмент.
    ///
    ///
    /// [`as_slices`]: VecDeque::as_slices
    /// [`as_mut_slices`]: VecDeque::as_mut_slices
    ///
    /// # Examples
    ///
    /// Сортування вмісту деке.
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::with_capacity(15);
    ///
    /// buf.push_back(2);
    /// buf.push_back(1);
    /// buf.push_front(3);
    ///
    /// // сортування деке
    /// buf.make_contiguous().sort();
    /// assert_eq!(buf.as_slices(), (&[1, 2, 3] as &[_], &[] as &[_]));
    ///
    /// // сортуючи його в зворотному порядку
    /// buf.make_contiguous().sort_by(|a, b| b.cmp(a));
    /// assert_eq!(buf.as_slices(), (&[3, 2, 1] as &[_], &[] as &[_]));
    /// ```
    ///
    /// Отримання незмінного доступу до суміжного фрагмента.
    ///
    /// ```rust
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    ///
    /// buf.push_back(2);
    /// buf.push_back(1);
    /// buf.push_front(3);
    ///
    /// buf.make_contiguous();
    /// if let (slice, &[]) = buf.as_slices() {
    ///     // тепер ми можемо бути впевнені, що `slice` містить усі елементи модуля, зберігаючи при цьому незмінний доступ до `buf`.
    /////
    ///     assert_eq!(buf.len(), slice.len());
    ///     assert_eq!(slice, &[3, 2, 1] as &[_]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "deque_make_contiguous", since = "1.48.0")]
    pub fn make_contiguous(&mut self) -> &mut [T] {
        if self.is_contiguous() {
            let tail = self.tail;
            let head = self.head;
            return unsafe { RingSlices::ring_slices(self.buffer_as_mut_slice(), head, tail).0 };
        }

        let buf = self.buf.ptr();
        let cap = self.cap();
        let len = self.len();

        let free = self.tail - self.head;
        let tail_len = cap - self.tail;

        if free >= tail_len {
            // є достатньо вільного місця для копіювання хвоста за один раз, це означає, що ми спочатку зміщуємо голову назад, а потім копіюємо хвіст у правильне положення.
            //
            //
            // від: DEFGH .... ABC
            // до: ABCDEFGH ....
            //
            unsafe {
                ptr::copy(buf, buf.add(tail_len), self.head);
                // ...DEFGH.ABC
                ptr::copy_nonoverlapping(buf.add(self.tail), buf, tail_len);
                // ABCDEFGH....

                self.tail = 0;
                self.head = len;
            }
        } else if free > self.head {
            // FIXME: В даний час ми не розглядаємо .... ABCDEFGH
            // бути суміжними, оскільки `head` у цьому випадку буде `0`.
            // Хоча ми, мабуть, хочемо змінити це, воно не є тривіальним, оскільки в деяких місцях очікується, що `is_contiguous` означає, що ми можемо просто нарізати штрихи за допомогою `buf[tail..head]`.
            //
            //

            // є достатньо вільного місця для копіювання голови за один раз, це означає, що ми спочатку зміщуємо хвіст вперед, а потім копіюємо голову в правильне положення.
            //
            //
            // від: FGH .... ABCDE
            // до: ... ABCDEFGH.
            //
            unsafe {
                ptr::copy(buf.add(self.tail), buf.add(self.head), tail_len);
                // FGHABCDE....
                ptr::copy_nonoverlapping(buf, buf.add(self.head + tail_len), self.head);
                // ...ABCDEFGH.

                self.tail = self.head;
                self.head = self.wrap_add(self.tail, len);
            }
        } else {
            // вільний менше, ніж голова і хвіст, це означає, що ми повинні повільно "swap" хвіст і голову.
            //
            //
            // від: EFGHI ... ABCD або HIJK.ABCDEFG
            // до: ABCDEFGHI ... або ABCDEFGHIJK.
            let mut left_edge: usize = 0;
            let mut right_edge: usize = self.tail;
            unsafe {
                // Загальна проблема виглядає так: GHIJKLM ... ABCDEF, перед будь-якими свопами ABCDEFM ... GHIJKL, після 1 проходу свопів ABCDEFGHIJM ... KL, поміняйте місцями, поки лівий edge не дійде до тимчасового магазину
                //                  - потім перезапустіть алгоритм з новим сховищем (smaller) Іноді тимчасового сховища досягається, коли правильний edge знаходиться в кінці буфера, це означає, що ми досягли правильного порядку з меншою кількістю свопів!
                //
                // E.g
                // EF..ABCD ABCDEF .., після чотирьох лише обмінів ми закінчили
                //
                //
                //
                //
                //
                while left_edge < len && right_edge != cap {
                    let mut right_offset = 0;
                    for i in left_edge..right_edge {
                        right_offset = (i - left_edge) % (cap - right_edge);
                        let src: isize = (right_edge + right_offset) as isize;
                        ptr::swap(buf.add(i), buf.offset(src));
                    }
                    let n_ops = right_edge - left_edge;
                    left_edge += n_ops;
                    right_edge += right_offset + 1;
                }

                self.tail = 0;
                self.head = len;
            }
        }

        let tail = self.tail;
        let head = self.head;
        unsafe { RingSlices::ring_slices(self.buffer_as_mut_slice(), head, tail).0 }
    }

    /// Поворот двосторонньої черги `mid` наліво.
    ///
    /// Equivalently,
    /// - Повертає елемент `mid` на перше місце.
    /// - Вискакує перші предмети `mid` і штовхає їх до кінця.
    /// - Повертає місця `len() - mid` праворуч.
    ///
    /// # Panics
    ///
    /// Якщо `mid` більше, ніж `len()`.
    /// Зверніть увагу, що `mid == len()` виконує _not_ panic і не обертається.
    ///
    /// # Complexity
    ///
    /// Забирає час `*O*(min(mid, len() - mid))` і не потребує зайвого місця.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = (0..10).collect();
    ///
    /// buf.rotate_left(3);
    /// assert_eq!(buf, [3, 4, 5, 6, 7, 8, 9, 0, 1, 2]);
    ///
    /// for i in 1..10 {
    ///     assert_eq!(i * 3 % 10, buf[0]);
    ///     buf.rotate_left(3);
    /// }
    /// assert_eq!(buf, [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]);
    /// ```
    #[stable(feature = "vecdeque_rotate", since = "1.36.0")]
    pub fn rotate_left(&mut self, mid: usize) {
        assert!(mid <= self.len());
        let k = self.len() - mid;
        if mid <= k {
            unsafe { self.rotate_left_inner(mid) }
        } else {
            unsafe { self.rotate_right_inner(k) }
        }
    }

    /// Поворот двосторонньої черги `k` вправо.
    ///
    /// Equivalently,
    /// - Повертає перший елемент у положення `k`.
    /// - Вивантажує останні предмети `k` і висуває їх спереду.
    /// - Обертає місця `len() - k` ліворуч.
    ///
    /// # Panics
    ///
    /// Якщо `k` більше, ніж `len()`.
    /// Зверніть увагу, що `k == len()` виконує _not_ panic і не обертається.
    ///
    /// # Complexity
    ///
    /// Займає час `*O*(min(k, len() - k))` і не потребує зайвого місця.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = (0..10).collect();
    ///
    /// buf.rotate_right(3);
    /// assert_eq!(buf, [7, 8, 9, 0, 1, 2, 3, 4, 5, 6]);
    ///
    /// for i in 1..10 {
    ///     assert_eq!(0, buf[i * 3 % 10]);
    ///     buf.rotate_right(3);
    /// }
    /// assert_eq!(buf, [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]);
    /// ```
    #[stable(feature = "vecdeque_rotate", since = "1.36.0")]
    pub fn rotate_right(&mut self, k: usize) {
        assert!(k <= self.len());
        let mid = self.len() - k;
        if k <= mid {
            unsafe { self.rotate_right_inner(k) }
        } else {
            unsafe { self.rotate_left_inner(mid) }
        }
    }

    // БЕЗПЕКА: наступні два методи вимагають, щоб обертання становило величину
    // бути менше половини довжини дека.
    //
    // `wrap_copy` вимагає `min(x, cap() - x) + copy_len <= cap()`, але ніж `min` ніколи не перевищує половини ємності, незалежно від x, тому звучить дзвінок сюди, тому що ми дзвонимо з дещо менше половини довжини, яка ніколи не перевищує половини потужності.
    //
    //
    //

    unsafe fn rotate_left_inner(&mut self, mid: usize) {
        debug_assert!(mid * 2 <= self.len());
        unsafe {
            self.wrap_copy(self.head, self.tail, mid);
        }
        self.head = self.wrap_add(self.head, mid);
        self.tail = self.wrap_add(self.tail, mid);
    }

    unsafe fn rotate_right_inner(&mut self, k: usize) {
        debug_assert!(k * 2 <= self.len());
        self.head = self.wrap_sub(self.head, k);
        self.tail = self.wrap_sub(self.tail, k);
        unsafe {
            self.wrap_copy(self.tail, self.head, k);
        }
    }

    /// Двійковий пошук шукає цей відсортований `VecDeque` для заданого елемента.
    ///
    /// Якщо значення знайдено, тоді повертається [`Result::Ok`], що містить індекс відповідного елемента.
    /// Якщо збігів кілька, тоді будь-який із збігів можна повернути.
    /// Якщо значення не знайдено, повертається [`Result::Err`], що містить індекс, куди можна вставити відповідний елемент, зберігаючи відсортований порядок.
    ///
    ///
    /// # Examples
    ///
    /// Шукає серію з чотирьох елементів.
    /// Перший знайдений з однозначно визначеним положенням;другого та третього не знайдено;четвертий міг відповідати будь-якій позиції в `[1, 4]`.
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let deque: VecDeque<_> = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55].into();
    ///
    /// assert_eq!(deque.binary_search(&13),  Ok(9));
    /// assert_eq!(deque.binary_search(&4),   Err(7));
    /// assert_eq!(deque.binary_search(&100), Err(13));
    /// let r = deque.binary_search(&1);
    /// assert!(matches!(r, Ok(1..=4)));
    /// ```
    ///
    /// Якщо ви хочете вставити елемент у відсортований `VecDeque`, зберігаючи порядок сортування:
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let mut deque: VecDeque<_> = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55].into();
    /// let num = 42;
    /// let idx = deque.binary_search(&num).unwrap_or_else(|x| x);
    /// deque.insert(idx, num);
    /// assert_eq!(deque, &[0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 42, 55]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "vecdeque_binary_search", issue = "78021")]
    #[inline]
    pub fn binary_search(&self, x: &T) -> Result<usize, usize>
    where
        T: Ord,
    {
        self.binary_search_by(|e| e.cmp(x))
    }

    /// Двійковий пошук цього відсортованого `VecDeque` із функцією порівняння.
    ///
    /// Функція порівняння повинна реалізовувати замовлення, яке відповідає порядку сортування базового `VecDeque`, повертаючи код замовлення, який вказує, чи є його аргумент `Less`, `Equal` чи `Greater`, ніж бажана ціль.
    ///
    ///
    /// Якщо значення знайдено, тоді повертається [`Result::Ok`], що містить індекс відповідного елемента.Якщо збігів кілька, тоді будь-який із збігів можна повернути.
    /// Якщо значення не знайдено, повертається [`Result::Err`], що містить індекс, куди можна вставити відповідний елемент, зберігаючи відсортований порядок.
    ///
    /// # Examples
    ///
    /// Шукає серію з чотирьох елементів.Перший знайдений з однозначно визначеним положенням;другого та третього не знайдено;четвертий міг відповідати будь-якій позиції в `[1, 4]`.
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let deque: VecDeque<_> = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55].into();
    ///
    /// assert_eq!(deque.binary_search_by(|x| x.cmp(&13)),  Ok(9));
    /// assert_eq!(deque.binary_search_by(|x| x.cmp(&4)),   Err(7));
    /// assert_eq!(deque.binary_search_by(|x| x.cmp(&100)), Err(13));
    /// let r = deque.binary_search_by(|x| x.cmp(&1));
    /// assert!(matches!(r, Ok(1..=4)));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vecdeque_binary_search", issue = "78021")]
    pub fn binary_search_by<'a, F>(&'a self, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> Ordering,
    {
        let (front, back) = self.as_slices();

        if let Some(Ordering::Less | Ordering::Equal) = back.first().map(|elem| f(elem)) {
            back.binary_search_by(f).map(|idx| idx + front.len()).map_err(|idx| idx + front.len())
        } else {
            front.binary_search_by(f)
        }
    }

    /// Двійковий пошук виконує цей відсортований `VecDeque` із функцією вилучення ключів.
    ///
    /// Припускає, що `VecDeque` відсортовано за ключем, наприклад з [`make_contiguous().sort_by_key()`](#method.make_contiguous), використовуючи ту саму функцію вилучення ключа.
    ///
    ///
    /// Якщо значення знайдено, тоді повертається [`Result::Ok`], що містить індекс відповідного елемента.
    /// Якщо збігів кілька, тоді будь-який із збігів можна повернути.
    /// Якщо значення не знайдено, повертається [`Result::Err`], що містить індекс, куди можна вставити відповідний елемент, зберігаючи відсортований порядок.
    ///
    /// # Examples
    ///
    /// Шукає серію з чотирьох елементів у зрізі пар, відсортованих за їхніми іншими елементами.
    /// Перший знайдений з однозначно визначеним положенням;другого та третього не знайдено;четвертий міг відповідати будь-якій позиції в `[1, 4]`.
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let deque: VecDeque<_> = vec![(0, 0), (2, 1), (4, 1), (5, 1),
    ///          (3, 1), (1, 2), (2, 3), (4, 5), (5, 8), (3, 13),
    ///          (1, 21), (2, 34), (4, 55)].into();
    ///
    /// assert_eq!(deque.binary_search_by_key(&13, |&(a, b)| b),  Ok(9));
    /// assert_eq!(deque.binary_search_by_key(&4, |&(a, b)| b),   Err(7));
    /// assert_eq!(deque.binary_search_by_key(&100, |&(a, b)| b), Err(13));
    /// let r = deque.binary_search_by_key(&1, |&(a, b)| b);
    /// assert!(matches!(r, Ok(1..=4)));
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vecdeque_binary_search", issue = "78021")]
    #[inline]
    pub fn binary_search_by_key<'a, B, F>(&'a self, b: &B, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> B,
        B: Ord,
    {
        self.binary_search_by(|k| f(k).cmp(b))
    }
}

impl<T: Clone> VecDeque<T> {
    /// Змінює `VecDeque` на місці таким чином, що `len()` дорівнює new_len, або видаляючи зайві елементи ззаду, або додаючи клони `value` до тилу.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(10);
    /// buf.push_back(15);
    /// assert_eq!(buf, [5, 10, 15]);
    ///
    /// buf.resize(2, 0);
    /// assert_eq!(buf, [5, 10]);
    ///
    /// buf.resize(5, 20);
    /// assert_eq!(buf, [5, 10, 20, 20, 20]);
    /// ```
    ///
    #[stable(feature = "deque_extras", since = "1.16.0")]
    pub fn resize(&mut self, new_len: usize, value: T) {
        self.resize_with(new_len, || value.clone());
    }
}

/// Повертає індекс у базовому буфері для даного індексу логічного елемента.
#[inline]
fn wrap_index(index: usize, size: usize) -> usize {
    // розмір-це завжди ступінь 2
    debug_assert!(size.is_power_of_two());
    index & (size - 1)
}

/// Обчисліть кількість елементів, які залишилось прочитати в буфері
#[inline]
fn count(tail: usize, head: usize, size: usize) -> usize {
    // розмір-це завжди ступінь 2
    (head.wrapping_sub(tail)) & (size - 1)
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: PartialEq> PartialEq for VecDeque<A> {
    fn eq(&self, other: &VecDeque<A>) -> bool {
        if self.len() != other.len() {
            return false;
        }
        let (sa, sb) = self.as_slices();
        let (oa, ob) = other.as_slices();
        if sa.len() == oa.len() {
            sa == oa && sb == ob
        } else if sa.len() < oa.len() {
            // Завжди ділиться на три секції, наприклад: self: [a b c|d e f] other: [0 1 2 3|4 5] front=3, mid=1, [a b c] == [0 1 2]&&[d] == [3]&&[e f] == [4 5]
            //
            //
            //
            //
            let front = sa.len();
            let mid = oa.len() - front;

            let (oa_front, oa_mid) = oa.split_at(front);
            let (sb_mid, sb_back) = sb.split_at(mid);
            debug_assert_eq!(sa.len(), oa_front.len());
            debug_assert_eq!(sb_mid.len(), oa_mid.len());
            debug_assert_eq!(sb_back.len(), ob.len());
            sa == oa_front && sb_mid == oa_mid && sb_back == ob
        } else {
            let front = oa.len();
            let mid = sa.len() - front;

            let (sa_front, sa_mid) = sa.split_at(front);
            let (ob_mid, ob_back) = ob.split_at(mid);
            debug_assert_eq!(sa_front.len(), oa.len());
            debug_assert_eq!(sa_mid.len(), ob_mid.len());
            debug_assert_eq!(sb.len(), ob_back.len());
            sa_front == oa && sa_mid == ob_mid && sb == ob_back
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Eq> Eq for VecDeque<A> {}

__impl_slice_eq1! { [] VecDeque<A>, Vec<B>, }
__impl_slice_eq1! { [] VecDeque<A>, &[B], }
__impl_slice_eq1! { [] VecDeque<A>, &mut [B], }
__impl_slice_eq1! { [const N: usize] VecDeque<A>, [B; N], }
__impl_slice_eq1! { [const N: usize] VecDeque<A>, &[B; N], }
__impl_slice_eq1! { [const N: usize] VecDeque<A>, &mut [B; N], }

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: PartialOrd> PartialOrd for VecDeque<A> {
    fn partial_cmp(&self, other: &VecDeque<A>) -> Option<Ordering> {
        self.iter().partial_cmp(other.iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Ord> Ord for VecDeque<A> {
    #[inline]
    fn cmp(&self, other: &VecDeque<A>) -> Ordering {
        self.iter().cmp(other.iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Hash> Hash for VecDeque<A> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        self.len().hash(state);
        // Неможливо використовувати Hash::hash_slice на зрізах, повернутих методом as_slices, оскільки їх довжина може змінюватися в однакових ідентичних деках.
        //
        //
        // Hasher гарантує еквівалентність лише для того самого набору викликів своїх методів.
        //
        //
        self.iter().for_each(|elem| elem.hash(state));
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> Index<usize> for VecDeque<A> {
    type Output = A;

    #[inline]
    fn index(&self, index: usize) -> &A {
        self.get(index).expect("Out of bounds access")
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> IndexMut<usize> for VecDeque<A> {
    #[inline]
    fn index_mut(&mut self, index: usize) -> &mut A {
        self.get_mut(index).expect("Out of bounds access")
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> FromIterator<A> for VecDeque<A> {
    fn from_iter<T: IntoIterator<Item = A>>(iter: T) -> VecDeque<A> {
        let iterator = iter.into_iter();
        let (lower, _) = iterator.size_hint();
        let mut deq = VecDeque::with_capacity(lower);
        deq.extend(iterator);
        deq
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> IntoIterator for VecDeque<T> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// Споживає `VecDeque` у фронтальний ітератор, що дає елементи за значенням.
    ///
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { inner: self }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a VecDeque<T> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a mut VecDeque<T> {
    type Item = &'a mut T;
    type IntoIter = IterMut<'a, T>;

    fn into_iter(self) -> IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> Extend<A> for VecDeque<A> {
    fn extend<T: IntoIterator<Item = A>>(&mut self, iter: T) {
        // Ця функція повинна бути моральним еквівалентом:
        //
        //      для товару в iter.into_iter() {
        //          self.push_back(item);
        //      }
        let mut iter = iter.into_iter();
        while let Some(element) = iter.next() {
            if self.len() == self.capacity() {
                let (lower, _) = iter.size_hint();
                self.reserve(lower.saturating_add(1));
            }

            let head = self.head;
            self.head = self.wrap_add(self.head, 1);
            unsafe {
                self.buffer_write(head, element);
            }
        }
    }

    #[inline]
    fn extend_one(&mut self, elem: A) {
        self.push_back(elem);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: 'a + Copy> Extend<&'a T> for VecDeque<T> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &elem: &T) {
        self.push_back(elem);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug> fmt::Debug for VecDeque<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self).finish()
    }
}

#[stable(feature = "vecdeque_vec_conversions", since = "1.10.0")]
impl<T> From<Vec<T>> for VecDeque<T> {
    /// Перетворіть [`Vec<T>`] на [`VecDeque<T>`].
    ///
    /// [`Vec<T>`]: crate::vec::Vec
    /// [`VecDeque<T>`]: crate::collections::VecDeque
    ///
    /// Це дозволяє уникнути перерозподілу, де це можливо, але умови для цього суворі та можуть змінюватися, тому не слід покладатися на них, якщо `Vec<T>` не походить від `From<VecDeque<T>>` і не перерозподіляється.
    ///
    ///
    fn from(mut other: Vec<T>) -> Self {
        let len = other.len();
        if mem::size_of::<T>() == 0 {
            // Немає фактичного розподілу для ZST, щоб турбуватися про ємність, але `VecDeque` не може обробити стільки довжини, як `Vec`.
            //
            assert!(len < MAXIMUM_ZST_CAPACITY, "capacity overflow");
        } else {
            // Нам потрібно змінити розмір, якщо ємність не дорівнює двом, занадто мала або не має хоча б одного вільного місця.
            // Ми робимо це, поки він все ще в `Vec`, тому елементи потрапляють на panic.
            //
            let min_cap = cmp::max(MINIMUM_CAPACITY, len) + 1;
            let cap = cmp::max(min_cap, other.capacity()).next_power_of_two();
            if other.capacity() != cap {
                other.reserve_exact(cap - len);
            }
        }

        unsafe {
            let (other_buf, len, capacity) = other.into_raw_parts();
            let buf = RawVec::from_raw_parts(other_buf, capacity);
            VecDeque { tail: 0, head: len, buf }
        }
    }
}

#[stable(feature = "vecdeque_vec_conversions", since = "1.10.0")]
impl<T> From<VecDeque<T>> for Vec<T> {
    /// Перетворіть [`VecDeque<T>`] на [`Vec<T>`].
    ///
    /// [`Vec<T>`]: crate::vec::Vec
    /// [`VecDeque<T>`]: crate::collections::VecDeque
    ///
    /// Для цього ніколи не потрібно перерозподіляти, але потрібно робити *O*(*n*) переміщення даних, якщо круговий буфер не знаходиться на початку розподілу.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// // Цей-*O*(1).
    /// let deque: VecDeque<_> = (1..5).collect();
    /// let ptr = deque.as_slices().0.as_ptr();
    /// let vec = Vec::from(deque);
    /// assert_eq!(vec, [1, 2, 3, 4]);
    /// assert_eq!(vec.as_ptr(), ptr);
    ///
    /// // Цей потребує перестановки даних.
    /// let mut deque: VecDeque<_> = (1..5).collect();
    /// deque.push_front(9);
    /// deque.push_front(8);
    /// let ptr = deque.as_slices().1.as_ptr();
    /// let vec = Vec::from(deque);
    /// assert_eq!(vec, [8, 9, 1, 2, 3, 4]);
    /// assert_eq!(vec.as_ptr(), ptr);
    /// ```
    fn from(mut other: VecDeque<T>) -> Self {
        other.make_contiguous();

        unsafe {
            let other = ManuallyDrop::new(other);
            let buf = other.buf.ptr();
            let len = other.len();
            let cap = other.cap();

            if other.tail != 0 {
                ptr::copy(buf.add(other.tail), buf, len);
            }
            Vec::from_raw_parts(buf, len, cap)
        }
    }
}