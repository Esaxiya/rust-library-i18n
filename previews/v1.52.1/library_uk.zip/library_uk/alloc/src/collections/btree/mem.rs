use core::intrinsics;
use core::mem;
use core::ptr;

/// Це замінює значення за унікальним посиланням `v`, викликаючи відповідну функцію.
///
///
/// Якщо при закритті `change` трапляється panic, весь процес буде перервано.
#[allow(dead_code)] // зберігати як ілюстрацію та для використання future
#[inline]
pub fn take_mut<T>(v: &mut T, change: impl FnOnce(T) -> T) {
    replace(v, |value| (change(value), ()))
}

/// Це замінює значення за унікальним посиланням `v`, викликаючи відповідну функцію, і повертає отриманий результат.
///
///
/// Якщо при закритті `change` трапляється panic, весь процес буде перервано.
#[inline]
pub fn replace<T, R>(v: &mut T, change: impl FnOnce(T) -> (T, R)) -> R {
    struct PanicGuard;
    impl Drop for PanicGuard {
        fn drop(&mut self) {
            intrinsics::abort()
        }
    }
    let guard = PanicGuard;
    let value = unsafe { ptr::read(v) };
    let (new_value, ret) = change(value);
    unsafe {
        ptr::write(v, new_value);
    }
    mem::forget(guard);
    ret
}