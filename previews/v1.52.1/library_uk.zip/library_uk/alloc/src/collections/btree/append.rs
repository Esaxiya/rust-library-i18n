use super::merge_iter::MergeIterInner;
use super::node::{self, Root};
use core::iter::FusedIterator;

impl<K, V> Root<K, V> {
    /// Додає всі пари ключ-значення із об'єднання двох висхідних ітераторів, збільшуючи змінну `length` по ходу.Останнє дозволяє абоненту легше уникнути витоку, коли обробник падіння панікує.
    ///
    /// Якщо обидва ітератори видають один і той же ключ, цей метод скидає пару з лівого ітератора і додає пару з правого ітератора.
    ///
    /// Якщо ви хочете, щоб дерево опинилось у суто зростаючому порядку, як для `BTreeMap`, обидва ітератори повинні створювати ключі в строго зростаючому порядку, кожен більший за всі ключі у дереві, включаючи будь-які ключі, які вже є у дереві при вході.
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn append_from_sorted_iters<I>(&mut self, left: I, right: I, length: &mut usize)
    where
        K: Ord,
        I: Iterator<Item = (K, V)> + FusedIterator,
    {
        // Ми готуємось об`єднати `left` та `right` у відсортовану послідовність за лінійний час.
        let iter = MergeIter(MergeIterInner::new(left, right));

        // Тим часом ми будуємо дерево з відсортованої послідовності за лінійний час.
        self.bulk_push(iter, length)
    }

    /// Підштовхує всі пари ключ-значення до кінця дерева, збільшуючи змінну `length` по ходу.
    /// Останнє дозволяє абоненту легше уникнути витоку, коли ітератор панікує.
    ///
    pub fn bulk_push<I>(&mut self, iter: I, length: &mut usize)
    where
        I: Iterator<Item = (K, V)>,
    {
        let mut cur_node = self.borrow_mut().last_leaf_edge().into_node();
        // Повторіть всі пари ключ-значення, засовуючи їх у вузли на потрібному рівні.
        for (key, value) in iter {
            // Спробуйте вставити пару ключ-значення у поточний листовий вузол.
            if cur_node.len() < node::CAPACITY {
                cur_node.push(key, value);
            } else {
                // Не залишилося місця, підніміться вгору і натисніть там.
                let mut open_node;
                let mut test_node = cur_node.forget_type();
                loop {
                    match test_node.ascend() {
                        Ok(parent) => {
                            let parent = parent.into_node();
                            if parent.len() < node::CAPACITY {
                                // Знайшов вузол із вільним простором, натисніть сюди.
                                open_node = parent;
                                break;
                            } else {
                                // Підніміться знову.
                                test_node = parent.forget_type();
                            }
                        }
                        Err(_) => {
                            // Ми знаходимось на вершині, створюємо новий кореневий вузол і натискаємо туди.
                            open_node = self.push_internal_level();
                            break;
                        }
                    }
                }

                // Натисніть пару ключ-значення та нове праве піддерево.
                let tree_height = open_node.height() - 1;
                let mut right_tree = Root::new();
                for _ in 0..tree_height {
                    right_tree.push_internal_level();
                }
                open_node.push(key, value, right_tree);

                // Знову спуститесь до самого правого аркуша.
                cur_node = open_node.forget_type().last_leaf_edge().into_node();
            }

            // Збільшуйте довжину кожної ітерації, щоб переконатися, що карта скидає додані елементи, навіть якщо просування ітератора панікує.
            //
            *length += 1;
        }
        self.fix_right_border_of_plentiful();
    }
}

// Ітератор для об`єднання двох відсортованих послідовностей в одну
struct MergeIter<K, V, I: Iterator<Item = (K, V)>>(MergeIterInner<I>);

impl<K: Ord, V, I> Iterator for MergeIter<K, V, I>
where
    I: Iterator<Item = (K, V)> + FusedIterator,
{
    type Item = (K, V);

    /// Якщо два ключі рівні, повертає пару ключ-значення з правого джерела.
    fn next(&mut self) -> Option<(K, V)> {
        let (a_next, b_next) = self.0.nexts(|a: &(K, V), b: &(K, V)| K::cmp(&a.0, &b.0));
        b_next.or(a_next)
    }
}