// Це спроба реалізації, яка іде за ідеалом
//
// ```
// struct BTreeMap<K, V> {
//     height: usize,
//     root: Option<Box<Node<K, V, height>>>
// }
//
// struct Node<K, V, height: usize> {
//     keys: [K; 2 * B - 1],
//     vals: [V; 2 * B - 1],
//     edges: [if height > 0 { Box<Node<K, V, height - 1>> } else { () }; 2 * B],
//     parent: Option<(NonNull<Node<K, V, height + 1>>, u16)>,
//     len: u16,
// }
// ```
//
// Оскільки Rust насправді не має залежних типів та поліморфної рекурсії, ми впораємося з великою кількістю небезпеки.
//

// Головною метою цього модуля є уникнення складності, обробляючи дерево як загальний (якщо дивної форми) контейнер та уникаючи спілкування з більшістю інваріантів B-Tree.
//
// Таким чином, цьому модулю байдуже, чи сортуються записи, які вузли можуть бути недоповненими або навіть що означає underfull.Однак ми покладаємось на кілька інваріантів:
//
// - Дерева повинні мати рівномірний depth/height.Це означає, що кожен шлях до аркуша від даного вузла має рівно однакову довжину.
// - Вузол довжиною `n` має ключі `n`, значення `n` та ребра `n + 1`.
//   Це означає, що навіть порожній вузол має принаймні один edge.
//   Для ступінчастого вузла "having an edge" означає лише те, що ми можемо визначити позицію у вузлі, оскільки краї аркуша порожні і не потребують представлення даних.
// У внутрішньому вузлі edge і визначає позицію, і містить покажчик на дочірній вузол.
//
//
//

use core::marker::PhantomData;
use core::mem::{self, MaybeUninit};
use core::ptr::{self, NonNull};
use core::slice::SliceIndex;

use crate::alloc::{Allocator, Global, Layout};
use crate::boxed::Box;

const B: usize = 6;
pub const CAPACITY: usize = 2 * B - 1;
pub const MIN_LEN_AFTER_SPLIT: usize = B - 1;
const KV_IDX_CENTER: usize = B - 1;
const EDGE_IDX_LEFT_OF_CENTER: usize = B - 1;
const EDGE_IDX_RIGHT_OF_CENTER: usize = B;

/// Основне представлення листових вузлів та частина представлення внутрішніх вузлів.
struct LeafNode<K, V> {
    /// Ми хочемо бути коваріантними в `K` та `V`.
    parent: Option<NonNull<InternalNode<K, V>>>,

    /// Індекс цього вузла в масиві `edges` батьківського вузла.
    /// `*node.parent.edges[node.parent_idx]` має бути таким же, як `node`.
    /// Це гарантовано ініціалізується лише тоді, коли `parent` не є нульовим.
    parent_idx: MaybeUninit<u16>,

    /// Кількість ключів і значень, які зберігає цей вузол.
    len: u16,

    /// Масиви, що зберігають фактичні дані вузла.
    /// Ініціалізуються та діють лише перші елементи `len` кожного масиву.
    keys: [MaybeUninit<K>; CAPACITY],
    vals: [MaybeUninit<V>; CAPACITY],
}

impl<K, V> LeafNode<K, V> {
    /// Ініціалізує новий `LeafNode` на місці.
    unsafe fn init(this: *mut Self) {
        // Як загальну політику ми залишаємо поля неініціалізованими, якщо це можливо, оскільки це повинно бути і дещо швидшим, і легшим для відстеження в Valgrind.
        //
        unsafe {
            // parent_idx, ключі та vals-це все MaybeUninit
            ptr::addr_of_mut!((*this).parent).write(None);
            ptr::addr_of_mut!((*this).len).write(0);
        }
    }

    /// Створює новий `LeafNode` в коробці.
    fn new() -> Box<Self> {
        unsafe {
            let mut leaf = Box::new_uninit();
            LeafNode::init(leaf.as_mut_ptr());
            leaf.assume_init()
        }
    }
}

/// Основне представлення внутрішніх вузлів.Як і у випадку з `LeafNode`, їх слід приховувати за`BoxedNode`, щоб запобігти викиданню неініціалізованих ключів та значень.
/// Будь-який вказівник на `InternalNode` може бути безпосередньо приведений до вказівника на базову частину вузла `LeafNode`, що дозволяє коду діяти на листові та внутрішні вузли загалом, навіть не перевіряючи, на який з двох вказує вказівник.
///
/// Цю властивість увімкнено використанням `repr(C)`.
///
#[repr(C)]
// gdb_providers.py використовує це ім'я типу для самоаналізу.
struct InternalNode<K, V> {
    data: LeafNode<K, V>,

    /// Вказівники на дітей цього вузла.
    /// `len + 1` з них вважаються ініціалізованими та дійсними, за винятком того, що наприкінці, поки дерево утримується через позику типу `Dying`, деякі з цих покажчиків звисають.
    ///
    edges: [MaybeUninit<BoxedNode<K, V>>; 2 * B],
}

impl<K, V> InternalNode<K, V> {
    /// Створює новий `InternalNode` в коробці.
    ///
    /// # Safety
    /// Інваріант внутрішніх вузлів полягає в тому, що вони мають принаймні один ініціалізований і дійсний edge.
    /// Ця функція не встановлює такий edge.
    ///
    unsafe fn new() -> Box<Self> {
        unsafe {
            let mut node = Box::<Self>::new_uninit();
            // Нам потрібно лише ініціалізувати дані;краї-MaybeUninit.
            LeafNode::init(ptr::addr_of_mut!((*node.as_mut_ptr()).data));
            node.assume_init()
        }
    }
}

/// Керований ненульовий покажчик на вузол.Це або власник покажчика на `LeafNode<K, V>`, або власник покажчика на `InternalNode<K, V>`.
///
/// Однак `BoxedNode` не містить інформації щодо того, який із двох типів вузлів він насправді містить, і, частково через відсутність інформації, він не є окремим типом і не має деструктора.
///
///
///
type BoxedNode<K, V> = NonNull<LeafNode<K, V>>;

/// Кореневий вузол власного дерева.
///
/// Зверніть увагу, що в ньому немає деструктора, і його слід очищати вручну.
pub type Root<K, V> = NodeRef<marker::Owned, K, V, marker::LeafOrInternal>;

impl<K, V> Root<K, V> {
    /// Повертає нове дерево, що належить, із власним кореневим вузлом, який спочатку порожній.
    pub fn new() -> Self {
        NodeRef::new_leaf().forget_type()
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Leaf> {
    fn new_leaf() -> Self {
        Self::from_new_leaf(LeafNode::new())
    }

    fn from_new_leaf(leaf: Box<LeafNode<K, V>>) -> Self {
        NodeRef { height: 0, node: NonNull::from(Box::leak(leaf)), _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Internal> {
    fn new_internal(child: Root<K, V>) -> Self {
        let mut new_node = unsafe { InternalNode::new() };
        new_node.edges[0].write(child.node);
        unsafe { NodeRef::from_new_internal(new_node, child.height + 1) }
    }

    /// # Safety
    /// `height` не повинен бути нулем.
    unsafe fn from_new_internal(internal: Box<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        let node = NonNull::from(Box::leak(internal)).cast();
        let mut this = NodeRef { height, node, _marker: PhantomData };
        this.borrow_mut().correct_all_childrens_parent_links();
        this
    }
}

impl<K, V, Type> NodeRef<marker::Owned, K, V, Type> {
    /// Змінно запозичує власний кореневий вузол.
    /// На відміну від `reborrow_mut`, це безпечно, оскільки повернене значення не може бути використано для знищення кореня, а також не може бути інших посилань на дерево.
    ///
    pub fn borrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Трохи замінливо запозичує кореневий вузол, що належить.
    pub fn borrow_valmut(&mut self) -> NodeRef<marker::ValMut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Незворотно переходить до посилання, яке дозволяє обходити і пропонує деструктивні методи, і мало що інше.
    ///
    pub fn into_dying(self) -> NodeRef<marker::Dying, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// Додає новий внутрішній вузол з одним edge, що вказує на попередній кореневий вузол, робить цей новий вузол кореневим вузлом і повертає його.
    /// Це збільшує висоту на 1 і є протилежністю `pop_internal_level`.
    ///
    pub fn push_internal_level(&mut self) -> NodeRef<marker::Mut<'_>, K, V, marker::Internal> {
        super::mem::take_mut(self, |old_root| NodeRef::new_internal(old_root).forget_type());

        // `self.borrow_mut()`, за винятком того, що ми просто забули, що зараз є внутрішніми:
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Видаляє внутрішній кореневий вузол, використовуючи його перший дочірній елемент як новий кореневий вузол.
    /// Оскільки він призначений для виклику лише тоді, коли у кореневого вузла є лише одна дочірня особа, жодна клавіша, значення та інші дочірні елементи не виконують очищення.
    ///
    /// Це зменшує висоту на 1 і є протилежністю `push_internal_level`.
    ///
    /// Потрібен ексклюзивний доступ до об'єкта `Root`, але не до кореневого вузла;
    /// це не призведе до недійсності інших дескрипторів або посилань на кореневий вузол.
    ///
    /// Panics, якщо немає внутрішнього рівня, тобто якщо кореневий вузол-це лист.
    pub fn pop_internal_level(&mut self) {
        assert!(self.height > 0);

        let top = self.node;

        // БЕЗПЕКА: ми стверджували, що ми є внутрішніми.
        let internal_self = unsafe { self.borrow_mut().cast_to_internal_unchecked() };
        // БЕЗПЕКА: ми позичили виключно `self`, і його тип позики ексклюзивний.
        let internal_node = unsafe { &mut *NodeRef::as_internal_ptr(&internal_self) };
        // БЕЗПЕКА: перший edge завжди ініціалізується.
        self.node = unsafe { internal_node.edges[0].assume_init_read() };
        self.height -= 1;
        self.clear_parent_link();

        unsafe {
            Global.deallocate(top.cast(), Layout::new::<InternalNode<K, V>>());
        }
    }
}

// N.B. `NodeRef` завжди коваріантний у `K` та `V`, навіть коли `BorrowType` є `Mut`.
// Це технічно неправильно, але не може призвести до будь-якої небезпеки через внутрішнє використання `NodeRef`, оскільки ми залишаємось повністю загальними для `K` та `V`.
//
// Однак, коли публічний тип обгортає `NodeRef`, переконайтесь, що він має правильну дисперсію.
//
/// Посилання на вузол.
///
/// Цей тип має ряд параметрів, які контролюють, як він діє:
/// - `BorrowType`: Фіктивний тип, який описує вид запозичень і має все життя.
///    - Коли це `Immut<'a>`, `NodeRef` діє приблизно як `&'a Node`.
///    - Коли це `ValMut<'a>`, `NodeRef` діє приблизно як `&'a Node` щодо ключів та деревної структури, але також дозволяє співіснувати багатьом змінним посиланням на значення у всьому дереві.
///    - Коли це `Mut<'a>`, `NodeRef` діє приблизно як `&'a mut Node`, хоча методи вставки дозволяють співіснувати змінний вказівник на значення.
///    - Коли це `Owned`, `NodeRef` діє приблизно як `Box<Node>`, але не має деструктора, і його слід очищати вручну.
///    - Коли це `Dying`, `NodeRef` все ще діє приблизно як `Box<Node>`, але має методи потроху знищувати дерево, і звичайні методи, хоча і не позначені як небезпечні для виклику, можуть викликати UB, якщо їх неправильно викликати.
///
///   Оскільки будь-який `NodeRef` дозволяє здійснювати навігацію по дереву, `BorrowType` ефективно застосовується до всього дерева, а не лише до самого вузла.
/// - `K` та `V`: це типи ключів та значень, що зберігаються у вузлах.
/// - `Type`: Це може бути `Leaf`, `Internal` або `LeafOrInternal`.
/// Коли це `Leaf`, `NodeRef` вказує на листовий вузол, коли це `Internal`, `NodeRef` вказує на внутрішній вузол, а коли це `LeafOrInternal`, `NodeRef` може вказувати на будь-який тип вузла.
///   `Type` називається `NodeType` при використанні поза `NodeRef`.
///
/// Як `BorrowType`, так і `NodeType` обмежують, які методи ми застосовуємо, щоб використовувати безпеку статичного типу.У застосуванні таких обмежень є обмеження:
/// - Для кожного параметра типу ми можемо визначити метод лише загально, або для одного конкретного типу.
/// Наприклад, ми не можемо визначити метод, такий як `into_kv`, загалом для всіх `BorrowType` або один раз для всіх типів, що мають тривалість життя, оскільки ми хочемо, щоб він повертав посилання `&'a`.
///   Тому ми визначаємо його лише для найменш потужного типу `Immut<'a>`.
/// - Ми не можемо отримати неявного примусу від, скажімо, `Mut<'a>` до `Immut<'a>`.
///   Тому нам потрібно явно викликати `reborrow` на більш потужному `NodeRef`, щоб досягти такого методу, як `into_kv`.
///
/// Усі методи на `NodeRef`, які повертають певне посилання, або:
/// - Візьміть `self` за значенням і поверніть час життя `BorrowType`.
///   Іноді, щоб викликати такий метод, нам потрібно викликати `reborrow_mut`.
/// - Візьміть `self` за посиланням, а (implicitly) поверне час життя цього посилання, замість того, як триває `BorrowType`.
/// Таким чином, перевірка запозичення гарантує, що `NodeRef` залишається запозиченим до тих пір, поки використовується повернене посилання.
///   Методи, що підтримують вставку, згинають це правило, повертаючи необроблений покажчик, тобто посилання без будь-якого часу життя.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
pub struct NodeRef<BorrowType, K, V, Type> {
    /// Кількість рівнів, за якими вузол і рівень листків розділені, константа вузла, яку `Type` не може повністю описати, і яку сам вузол не зберігає.
    /// Нам потрібно лише зберегти висоту кореневого вузла та вивести з нього висоту кожного іншого вузла.
    /// Має бути нульовим, якщо `Type` дорівнює `Leaf`, і ненульовим, якщо `Type` дорівнює `Internal`.
    ///
    ///
    height: usize,
    /// Вказівник на листок або внутрішній вузол.
    /// Визначення `InternalNode` гарантує, що вказівник є дійсним в будь-якому випадку.
    node: NonNull<LeafNode<K, V>>,
    _marker: PhantomData<(BorrowType, Type)>,
}

impl<'a, K: 'a, V: 'a, Type> Copy for NodeRef<marker::Immut<'a>, K, V, Type> {}
impl<'a, K: 'a, V: 'a, Type> Clone for NodeRef<marker::Immut<'a>, K, V, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

unsafe impl<BorrowType, K: Sync, V: Sync, Type> Sync for NodeRef<BorrowType, K, V, Type> {}

unsafe impl<'a, K: Sync + 'a, V: Sync + 'a, Type> Send for NodeRef<marker::Immut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::Mut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::ValMut<'a>, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Owned, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Dying, K, V, Type> {}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Розпакуйте посилання на вузол, яке було упаковано як `NodeRef::parent`.
    fn from_internal(node: NonNull<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        NodeRef { height, node: node.cast(), _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Виставляє дані внутрішнього вузла.
    ///
    /// Повертає необроблений ptr, щоб уникнути скасування інших посилань на цей вузол.
    fn as_internal_ptr(this: &Self) -> *mut InternalNode<K, V> {
        // БЕЗПЕКА: тип статичного вузла-`Internal`.
        this.node.as_ptr() as *mut InternalNode<K, V>
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Позичає ексклюзивний доступ до даних внутрішнього вузла.
    fn as_internal_mut(&mut self) -> &mut InternalNode<K, V> {
        let ptr = Self::as_internal_ptr(self);
        unsafe { &mut *ptr }
    }
}

impl<BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// Знаходить довжину вузла.Це кількість ключів або значень.
    /// Кількість ребер `len() + 1`.
    /// Зауважте, що, незважаючи на безпеку, виклик цієї функції може мати побічний ефект від недійсності змінних посилань, створених небезпечним кодом.
    ///
    pub fn len(&self) -> usize {
        // Найважливіше, що ми тут отримуємо доступ лише до поля `len`.
        // Якщо BorrowType має значення marker::ValMut, можуть бути видатні змінні посилання на значення, які ми не повинні робити недійсними.
        unsafe { usize::from((*Self::as_leaf_ptr(self)).len) }
    }

    /// Повертає кількість рівнів, на яких вузол і листя розділені.
    /// Нульова висота означає, що вузол-це сам листок.
    /// Якщо ви зображаєте дерева з коренем зверху, число вказує, на якій висоті з`являється вузол.
    /// Якщо ви зображаєте дерева з листям зверху, число говорить про те, наскільки високо дерево простягається над вузлом.
    ///
    pub fn height(&self) -> usize {
        self.height
    }

    /// Тимчасово виймає інше, незмінне посилання на той самий вузол.
    pub fn reborrow(&self) -> NodeRef<marker::Immut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Оголює листкову частину будь-якого листка або внутрішнього вузла.
    ///
    /// Повертає необроблений ptr, щоб уникнути скасування інших посилань на цей вузол.
    fn as_leaf_ptr(this: &Self) -> *mut LeafNode<K, V> {
        // Вузол повинен бути дійсним принаймні для частини LeafNode.
        // Це не посилання у типі NodeRef, оскільки ми не знаємо, чи має воно бути унікальним чи спільним.
        //
        this.node.as_ptr()
    }
}

impl<BorrowType: marker::BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// Знаходить батьківський елемент поточного вузла.
    /// Повертає `Ok(handle)`, якщо поточний вузол насправді має батьківський елемент, де `handle` вказує на edge батьківського, який вказує на поточний вузол.
    ///
    /// Повертає `Err(self)`, якщо поточний вузол не має батьківського елемента, повертаючи оригінальний `NodeRef`.
    ///
    /// Назва методу передбачає, що ви зображаєте дерева з кореневим вузлом зверху.
    ///
    /// `edge.descend().ascend().unwrap()` і `node.ascend().unwrap().descend()` не повинні, нічого, після успіху нічого не робити.
    ///
    pub fn ascend(
        self,
    ) -> Result<Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>, Self> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // Нам потрібно використовувати необроблені вказівники на вузли, оскільки, якщо BorrowType є marker::ValMut, можуть бути видатні змінні посилання на значення, які ми не повинні робити недійсними.
        //
        let leaf_ptr: *const _ = Self::as_leaf_ptr(&self);
        unsafe { (*leaf_ptr).parent }
            .as_ref()
            .map(|parent| Handle {
                node: NodeRef::from_internal(*parent, self.height + 1),
                idx: unsafe { usize::from((*leaf_ptr).parent_idx.assume_init()) },
                _marker: PhantomData,
            })
            .ok_or(self)
    }

    pub fn first_edge(self) -> Handle<Self, marker::Edge> {
        unsafe { Handle::new_edge(self, 0) }
    }

    pub fn last_edge(self) -> Handle<Self, marker::Edge> {
        let len = self.len();
        unsafe { Handle::new_edge(self, len) }
    }

    /// Зверніть увагу, що `self` не повинен бути порожнім.
    pub fn first_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, 0) }
    }

    /// Зверніть увагу, що `self` не повинен бути порожнім.
    pub fn last_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, len - 1) }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Immut<'a>, K, V, Type> {
    /// Оголює листову частину будь-якого листка або внутрішнього вузла в незмінному дереві.
    fn into_leaf(self) -> &'a LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&self);
        // БЕЗПЕКА: у цьому дереві не може бути змінних посилань, запозичених як `Immut`.
        unsafe { &*ptr }
    }

    /// Позичає перегляд ключів, що зберігаються у вузлі.
    pub fn keys(&self) -> &[K] {
        let leaf = self.into_leaf();
        unsafe {
            MaybeUninit::slice_assume_init_ref(leaf.keys.get_unchecked(..usize::from(leaf.len)))
        }
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// Подібно до `ascend`, отримує посилання на батьківський вузол вузла, але також звільняє поточний вузол у процесі.
    /// Це небезпечно, оскільки поточний вузол все одно буде доступним, незважаючи на вивільнення.
    ///
    pub unsafe fn deallocate_and_ascend(
        self,
    ) -> Option<Handle<NodeRef<marker::Dying, K, V, marker::Internal>, marker::Edge>> {
        let height = self.height;
        let node = self.node;
        let ret = self.ascend().ok();
        unsafe {
            Global.deallocate(
                node.cast(),
                if height > 0 {
                    Layout::new::<InternalNode<K, V>>()
                } else {
                    Layout::new::<LeafNode<K, V>>()
                },
            );
        }
        ret
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Небезпечно стверджує компілятору статичну інформацію про те, що цей вузол є `Leaf`.
    unsafe fn cast_to_leaf_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
        debug_assert!(self.height == 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Небезпечно стверджує компілятору статичну інформацію про те, що цей вузол є `Internal`.
    unsafe fn cast_to_internal_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        debug_assert!(self.height > 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Тимчасово виймає інше, змінне посилання на той самий вузол.Остерігайтеся, оскільки цей метод дуже небезпечний, вдвічі, оскільки він може не відразу здатися небезпечним.
    ///
    /// Оскільки мінливі вказівники можуть блукати де завгодно навколо дерева, повернутий вказівник може бути легко використаний для того, щоб оригінальний вказівник звисав, виходив за межі або був недійсним згідно з накопиченими правилами запозичення.
    ///
    ///
    ///
    ///
    // FIXME(@gereeter) розгляньте можливість додати ще один параметр типу до `NodeRef`, який обмежує використання методів навігації на повторно запозичених покажчиках, запобігаючи цій небезпеці.
    //
    //
    unsafe fn reborrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Позичає ексклюзивний доступ до листової частини будь-якого листка або внутрішнього вузла.
    fn as_leaf_mut(&mut self) -> &mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(self);
        // БЕЗПЕКА: ми маємо ексклюзивний доступ до всього вузла.
        unsafe { &mut *ptr }
    }

    /// Пропонує ексклюзивний доступ до листової частини будь-якого листка або внутрішнього вузла.
    fn into_leaf_mut(mut self) -> &'a mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&mut self);
        // БЕЗПЕКА: ми маємо ексклюзивний доступ до всього вузла.
        unsafe { &mut *ptr }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Позичає ексклюзивний доступ до елемента зони зберігання ключів.
    ///
    /// # Safety
    /// `index` знаходиться в межах 0..МІСТОСТІ
    unsafe fn key_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<K>], Output = Output>,
    {
        // БЕЗПЕКА: абонент не зможе самостійно викликати інші методи
        // поки посилання на ключовий фрагмент не буде скинуто, оскільки ми маємо унікальний доступ протягом усього терміну позики.
        //
        unsafe { self.as_leaf_mut().keys.as_mut_slice().get_unchecked_mut(index) }
    }

    /// Позичає ексклюзивний доступ до елемента або фрагмента області зберігання значень вузла.
    ///
    /// # Safety
    /// `index` знаходиться в межах 0..МІСТОСТІ
    unsafe fn val_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<V>], Output = Output>,
    {
        // БЕЗПЕКА: абонент не зможе самостійно викликати інші методи
        // поки посилання на зріз значення не буде випущено, оскільки ми маємо унікальний доступ протягом усього періоду позики.
        //
        unsafe { self.as_leaf_mut().vals.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Позичає ексклюзивний доступ до елемента або фрагмента області зберігання вузла для вмісту edge.
    ///
    /// # Safety
    /// `index` знаходиться в межах 0..МІСЦІ + 1
    unsafe fn edge_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<BoxedNode<K, V>>], Output = Output>,
    {
        // БЕЗПЕКА: абонент не зможе самостійно викликати інші методи
        // поки посилання на зріз edge не буде відкинуто, оскільки ми маємо унікальний доступ протягом усього періоду позики.
        //
        unsafe { self.as_internal_mut().edges.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K, V, Type> NodeRef<marker::ValMut<'a>, K, V, Type> {
    /// # Safety
    /// - Вузол містить більше ініціалізованих елементів `idx`.
    unsafe fn into_key_val_mut_at(mut self, idx: usize) -> (&'a K, &'a mut V) {
        // Ми створюємо посилання лише на один елемент, який нас цікавить, щоб уникнути поєднання з видатними посиланнями на інші елементи, зокрема ті, що повертаються абоненту в попередніх ітераціях.
        //
        //
        let leaf = Self::as_leaf_ptr(&mut self);
        let keys = unsafe { ptr::addr_of!((*leaf).keys) };
        let vals = unsafe { ptr::addr_of_mut!((*leaf).vals) };
        // Ми повинні примусити вказівники на масив великого розміру через проблему Rust #74679.
        let keys: *const [_] = keys;
        let vals: *mut [_] = vals;
        let key = unsafe { (&*keys.get_unchecked(idx)).assume_init_ref() };
        let val = unsafe { (&mut *vals.get_unchecked_mut(idx)).assume_init_mut() };
        (key, val)
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Позичає ексклюзивний доступ до довжини вузла.
    pub fn len_mut(&mut self) -> &mut u16 {
        &mut self.as_leaf_mut().len
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Встановлює посилання вузла на його батьківський edge, не анулюючи інші посилання на вузол.
    ///
    fn set_parent_link(&mut self, parent: NonNull<InternalNode<K, V>>, parent_idx: usize) {
        let leaf = Self::as_leaf_ptr(self);
        unsafe { (*leaf).parent = Some(parent) };
        unsafe { (*leaf).parent_idx.write(parent_idx as u16) };
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// Очищає кореневе посилання на батьківський edge.
    fn clear_parent_link(&mut self) {
        let mut root_node = self.borrow_mut();
        let leaf = root_node.as_leaf_mut();
        leaf.parent = None;
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
    /// Додає пару ключ-значення в кінець вузла.
    pub fn push(&mut self, key: K, val: V) {
        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// # Safety
    /// Кожен елемент, повернутий `range`, є дійсним індексом edge для вузла.
    unsafe fn correct_childrens_parent_links<R: Iterator<Item = usize>>(&mut self, range: R) {
        for i in range {
            debug_assert!(i <= self.len());
            unsafe { Handle::new_edge(self.reborrow_mut(), i) }.correct_parent_link();
        }
    }

    fn correct_all_childrens_parent_links(&mut self) {
        let len = self.len();
        unsafe { self.correct_childrens_parent_links(0..=len) };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Додає пару ключ-значення та edge, щоб перейти праворуч від цієї пари, до кінця вузла.
    ///
    pub fn push(&mut self, key: K, val: V, edge: Root<K, V>) {
        assert!(edge.height == self.height - 1);

        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
            self.edge_area_mut(idx + 1).write(edge.node);
            Handle::new_edge(self.reborrow_mut(), idx + 1).correct_parent_link();
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Перевіряє, чи є вузол вузлом `Internal` чи вузлом `Leaf`.
    pub fn force(
        self,
    ) -> ForceResult<
        NodeRef<BorrowType, K, V, marker::Leaf>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        if self.height == 0 {
            ForceResult::Leaf(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        } else {
            ForceResult::Internal(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        }
    }
}

/// Посилання на конкретну пару ключ-значення або edge всередині вузла.
/// Параметр `Node` повинен бути `NodeRef`, тоді як `Type` може бути або `KV` (що означає дескриптор на парі ключ-значення), або `Edge` (що означає дескриптор на edge).
///
/// Зверніть увагу, що навіть вузли `Leaf` можуть мати дескриптори `Edge`.
/// Замість того, щоб представляти вказівник на дочірній вузол, вони представляють пробіли, куди дочірні вказівники будуть переходити між парами ключ-значення.
/// Наприклад, у вузлі довжиною 2 було б 3 можливих місця розташування edge, одне зліва від вузла, одне між двома парами і одне справа від вузла.
///
///
pub struct Handle<Node, Type> {
    node: Node,
    idx: usize,
    _marker: PhantomData<Type>,
}

impl<Node: Copy, Type> Copy for Handle<Node, Type> {}
// Нам не потрібна повна загальність `#[derive(Clone)]`, оскільки єдиний раз, коли `Node` буде `` клонувати '', це коли він є незмінним посиланням і, отже, `Copy`.
//
impl<Node: Copy, Type> Clone for Handle<Node, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

impl<Node, Type> Handle<Node, Type> {
    /// Отримує вузол, що містить пару edge або пару ключ-значення, на яку вказує цей дескриптор.
    pub fn into_node(self) -> Node {
        self.node
    }

    /// Повертає положення цього дескриптора у вузлі.
    pub fn idx(&self) -> usize {
        self.idx
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV> {
    /// Створює новий дескриптор пари ключ-значення в `node`.
    /// Небезпечно, оскільки абонент повинен переконатися, що `idx < node.len()`.
    pub unsafe fn new_kv(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx < node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx) }
    }

    pub fn right_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx + 1) }
    }
}

impl<BorrowType, K, V, NodeType> NodeRef<BorrowType, K, V, NodeType> {
    /// Може бути загальнодоступною реалізацією PartialEq, але використовується лише в цьому модулі.
    fn eq(&self, other: &Self) -> bool {
        let Self { node, height, _marker } = self;
        if node.eq(&other.node) {
            debug_assert_eq!(*height, other.height);
            true
        } else {
            false
        }
    }
}

impl<BorrowType, K, V, NodeType, HandleType> PartialEq
    for Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    fn eq(&self, other: &Self) -> bool {
        let Self { node, idx, _marker } = self;
        node.eq(&other.node) && *idx == other.idx
    }
}

impl<BorrowType, K, V, NodeType, HandleType>
    Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    /// Тимчасово виймає іншу, незмінну ручку в тому самому місці.
    pub fn reborrow(&self) -> Handle<NodeRef<marker::Immut<'_>, K, V, NodeType>, HandleType> {
        // Ми не можемо використовувати Handle::new_kv або Handle::new_edge, оскільки ми не знаємо наш тип
        Handle { node: self.node.reborrow(), idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, Type> {
    /// Небезпечно стверджує компілятору статичну інформацію про те, що вузлом дескриптора є `Leaf`.
    pub unsafe fn cast_to_leaf_unchecked(
        self,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, Type> {
        let node = unsafe { self.node.cast_to_leaf_unchecked() };
        Handle { node, idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, NodeType, HandleType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, HandleType> {
    /// Тимчасово виймає іншу рухому ручку з того самого місця.
    /// Остерігайтеся, оскільки цей метод дуже небезпечний, вдвічі, оскільки він може не відразу здатися небезпечним.
    ///
    ///
    /// Детальніше див. У розділі `NodeRef::reborrow_mut`.
    pub unsafe fn reborrow_mut(
        &mut self,
    ) -> Handle<NodeRef<marker::Mut<'_>, K, V, NodeType>, HandleType> {
        // Ми не можемо використовувати Handle::new_kv або Handle::new_edge, оскільки ми не знаємо наш тип
        Handle { node: unsafe { self.node.reborrow_mut() }, idx: self.idx, _marker: PhantomData }
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
    /// Створює новий дескриптор для edge в `node`.
    /// Небезпечно, оскільки абонент повинен переконатися, що `idx <= node.len()`.
    pub unsafe fn new_edge(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx <= node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx > 0 {
            Ok(unsafe { Handle::new_kv(self.node, self.idx - 1) })
        } else {
            Err(self)
        }
    }

    pub fn right_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx < self.node.len() {
            Ok(unsafe { Handle::new_kv(self.node, self.idx) })
        } else {
            Err(self)
        }
    }
}

pub enum LeftOrRight<T> {
    Left(T),
    Right(T),
}

/// Враховуючи індекс edge, куди ми хочемо вставити вузол, заповнений до ємності, обчислює розумний індекс KV точки розбиття і де виконати вставку.
///
/// Мета точки розділення полягає в тому, щоб її ключ і значення потрапили у батьківський вузол;
/// клавіші, значення та краї зліва від точки розбиття стають лівою дочірньою структурою;
/// ключі, значення та краї праворуч від точки розбиття стають правильним нащадком.
fn splitpoint(edge_idx: usize) -> (usize, LeftOrRight<usize>) {
    debug_assert!(edge_idx <= CAPACITY);
    // Випуск Rust #74834 намагається пояснити ці симетричні правила.
    match edge_idx {
        0..EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER - 1, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_RIGHT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Right(0)),
        _ => (KV_IDX_CENTER + 1, LeftOrRight::Right(edge_idx - (KV_IDX_CENTER + 1 + 1))),
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Вставляє нову пару ключ-значення між парами ключ-значення праворуч і ліворуч від цього edge.
    /// Цей метод передбачає, що у вузлі достатньо місця для розміщення нової пари.
    ///
    /// Повернутий покажчик вказує на вставлене значення.
    ///
    fn insert_fit(&mut self, key: K, val: V) -> *mut V {
        debug_assert!(self.node.len() < CAPACITY);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            *self.node.len_mut() = new_len as u16;

            self.node.val_area_mut(self.idx).assume_init_mut()
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Вставляє нову пару ключ-значення між парами ключ-значення праворуч і ліворуч від цього edge.
    /// Цей метод розділяє вузол, якщо місця недостатньо.
    ///
    /// Повернутий покажчик вказує на вставлене значення.
    fn insert(mut self, key: K, val: V) -> (InsertResult<'a, K, V, marker::Leaf>, *mut V) {
        if self.node.len() < CAPACITY {
            let val_ptr = self.insert_fit(key, val);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            (InsertResult::Fit(kv), val_ptr)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            let val_ptr = insertion_edge.insert_fit(key, val);
            (InsertResult::Split(result), val_ptr)
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// Виправлено батьківський покажчик та індекс у дочірньому вузлі, на який посилається цей edge.
    /// Це корисно, коли порядок ребер було змінено,
    fn correct_parent_link(self) {
        // Створіть зворотний покажчик без анулювання інших посилань на вузол.
        let ptr = unsafe { NonNull::new_unchecked(NodeRef::as_internal_ptr(&self.node)) };
        let idx = self.idx;
        let mut child = self.descend();
        child.set_parent_link(ptr, idx);
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// Вставляє нову пару ключ-значення та edge, яка буде рухатися праворуч від цієї нової пари між цим edge і парою ключ-значення праворуч від цього edge.
    /// Цей метод передбачає, що у вузлі достатньо місця для розміщення нової пари.
    ///
    fn insert_fit(&mut self, key: K, val: V, edge: Root<K, V>) {
        debug_assert!(self.node.len() < CAPACITY);
        debug_assert!(edge.height == self.node.height - 1);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            slice_insert(self.node.edge_area_mut(..new_len + 1), self.idx + 1, edge.node);
            *self.node.len_mut() = new_len as u16;

            self.node.correct_childrens_parent_links(self.idx + 1..new_len + 1);
        }
    }

    /// Вставляє нову пару ключ-значення та edge, яка буде рухатися праворуч від цієї нової пари між цим edge і парою ключ-значення праворуч від цього edge.
    /// Цей метод розділяє вузол, якщо місця недостатньо.
    ///
    fn insert(
        mut self,
        key: K,
        val: V,
        edge: Root<K, V>,
    ) -> InsertResult<'a, K, V, marker::Internal> {
        assert!(edge.height == self.node.height - 1);

        if self.node.len() < CAPACITY {
            self.insert_fit(key, val, edge);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            InsertResult::Fit(kv)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            insertion_edge.insert_fit(key, val, edge);
            InsertResult::Split(result)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Вставляє нову пару ключ-значення між парами ключ-значення праворуч і ліворуч від цього edge.
    /// Цей метод розбиває вузол, якщо місця недостатньо, і намагається рекурсивно вставити розділену частину в батьківський вузол, поки не буде досягнуто кореневе значення.
    ///
    ///
    /// Якщо результатом, що повертається, є `Fit`, вузлом його дескриптора може бути вузол цього edge або попередник.
    /// Якщо отриманий результат-`Split`, поле `left` буде кореневим вузлом.
    /// Повернутий покажчик вказує на вставлене значення.
    pub fn insert_recursing(
        self,
        key: K,
        value: V,
    ) -> (InsertResult<'a, K, V, marker::LeafOrInternal>, *mut V) {
        let (mut split, val_ptr) = match self.insert(key, value) {
            (InsertResult::Fit(handle), ptr) => {
                return (InsertResult::Fit(handle.forget_node_type()), ptr);
            }
            (InsertResult::Split(split), val_ptr) => (split.forget_node_type(), val_ptr),
        };

        loop {
            split = match split.left.ascend() {
                Ok(parent) => match parent.insert(split.kv.0, split.kv.1, split.right) {
                    InsertResult::Fit(handle) => {
                        return (InsertResult::Fit(handle.forget_node_type()), val_ptr);
                    }
                    InsertResult::Split(split) => split.forget_node_type(),
                },
                Err(root) => {
                    return (InsertResult::Split(SplitResult { left: root, ..split }), val_ptr);
                }
            };
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// Знаходить вузол, на який вказує цей edge.
    ///
    /// Назва методу передбачає, що ви зображаєте дерева з кореневим вузлом зверху.
    ///
    /// `edge.descend().ascend().unwrap()` і `node.ascend().unwrap().descend()` не повинні, нічого, після успіху нічого не робити.
    ///
    pub fn descend(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // Нам потрібно використовувати необроблені вказівники на вузли, оскільки, якщо BorrowType є marker::ValMut, можуть бути видатні змінні посилання на значення, які ми не повинні робити недійсними.
        // Немає турбот про доступ до поля висоти, оскільки це значення скопійовано.
        // Слід пам`ятати, що після того, як вказівник вузла буде розменований, ми отримуємо доступ до масиву країв із посиланням (Rust випуск #73987) і анулюємо будь-які інші посилання на масив або всередині масиву, якщо він повинен бути поруч.
        //
        //
        //
        //
        let parent_ptr = NodeRef::as_internal_ptr(&self.node);
        let node = unsafe { (*parent_ptr).edges.get_unchecked(self.idx).assume_init_read() };
        NodeRef { node, height: self.node.height - 1, _marker: PhantomData }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Immut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv(self) -> (&'a K, &'a V) {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf();
        let k = unsafe { leaf.keys.get_unchecked(self.idx).assume_init_ref() };
        let v = unsafe { leaf.vals.get_unchecked(self.idx).assume_init_ref() };
        (k, v)
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn key_mut(&mut self) -> &mut K {
        unsafe { self.node.key_area_mut(self.idx).assume_init_mut() }
    }

    pub fn into_val_mut(self) -> &'a mut V {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf_mut();
        unsafe { leaf.vals.get_unchecked_mut(self.idx).assume_init_mut() }
    }
}

impl<'a, K, V, NodeType> Handle<NodeRef<marker::ValMut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv_valmut(self) -> (&'a K, &'a mut V) {
        unsafe { self.node.into_key_val_mut_at(self.idx) }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn kv_mut(&mut self) -> (&mut K, &mut V) {
        debug_assert!(self.idx < self.node.len());
        // Ми не можемо викликати окремі методи ключа та значення, оскільки виклик другого робить недійсним посилання, повернене першим.
        //
        unsafe {
            let leaf = self.node.as_leaf_mut();
            let key = leaf.keys.get_unchecked_mut(self.idx).assume_init_mut();
            let val = leaf.vals.get_unchecked_mut(self.idx).assume_init_mut();
            (key, val)
        }
    }

    /// Замініть ключ і значення, на які посилається дескриптор KV.
    pub fn replace_kv(&mut self, k: K, v: V) -> (K, V) {
        let (key, val) = self.kv_mut();
        (mem::replace(key, k), mem::replace(val, v))
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    /// Допомагає реалізації `split` для конкретного `NodeType`, дбаючи про дані аркушів.
    ///
    fn split_leaf_data(&mut self, new_node: &mut LeafNode<K, V>) -> (K, V) {
        debug_assert!(self.idx < self.node.len());
        let old_len = self.node.len();
        let new_len = old_len - self.idx - 1;
        new_node.len = new_len as u16;
        unsafe {
            let k = self.node.key_area_mut(self.idx).assume_init_read();
            let v = self.node.val_area_mut(self.idx).assume_init_read();

            move_to_slice(
                self.node.key_area_mut(self.idx + 1..old_len),
                &mut new_node.keys[..new_len],
            );
            move_to_slice(
                self.node.val_area_mut(self.idx + 1..old_len),
                &mut new_node.vals[..new_len],
            );

            *self.node.len_mut() = self.idx as u16;
            (k, v)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::KV> {
    /// Розбиває базовий вузол на три частини:
    ///
    /// - Вузол усічений, щоб містити лише пари ключ-значення зліва від цього дескриптора.
    /// - Витягуються ключ і значення, на які вказує цей дескриптор.
    /// - Усі пари ключ-значення, розташовані праворуч від цього дескриптора, поміщаються в новий виділений вузол.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Leaf> {
        let mut new_node = LeafNode::new();

        let kv = self.split_leaf_data(&mut new_node);

        let right = NodeRef::from_new_leaf(new_node);
        SplitResult { left: self.node, kv, right }
    }

    /// Видаляє пару ключ-значення, на яку вказує цей дескриптор, і повертає її разом із edge, в який пара ключ-значення згорнулася.
    ///
    pub fn remove(
        mut self,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        let old_len = self.node.len();
        unsafe {
            let k = slice_remove(self.node.key_area_mut(..old_len), self.idx);
            let v = slice_remove(self.node.val_area_mut(..old_len), self.idx);
            *self.node.len_mut() = (old_len - 1) as u16;
            ((k, v), self.left_edge())
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    /// Розбиває базовий вузол на три частини:
    ///
    /// - Вузол усічений, щоб містити лише ребра та пари ключ-значення зліва від цього дескриптора.
    /// - Витягуються ключ і значення, на які вказує цей дескриптор.
    /// - Всі ребра та пари ключ-значення праворуч від цього дескриптора поміщаються у новий виділений вузол.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Internal> {
        let old_len = self.node.len();
        unsafe {
            let mut new_node = InternalNode::new();
            let kv = self.split_leaf_data(&mut new_node.data);
            let new_len = usize::from(new_node.data.len);
            move_to_slice(
                self.node.edge_area_mut(self.idx + 1..old_len + 1),
                &mut new_node.edges[..new_len + 1],
            );

            let height = self.node.height;
            let right = NodeRef::from_new_internal(new_node, height);

            SplitResult { left: self.node, kv, right }
        }
    }
}

/// Представляє сеанс для оцінки та виконання операції балансування навколо внутрішньої пари ключ-значення.
///
pub struct BalancingContext<'a, K, V> {
    parent: Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV>,
    left_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    right_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    pub fn consider_for_balancing(self) -> BalancingContext<'a, K, V> {
        let self1 = unsafe { ptr::read(&self) };
        let self2 = unsafe { ptr::read(&self) };
        BalancingContext {
            parent: self,
            left_child: self1.left_edge().descend(),
            right_child: self2.right_edge().descend(),
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Вибирає контекст балансування, що включає вузол як дочірній, таким чином між KV безпосередньо ліворуч або праворуч у батьківському вузлі.
    /// Повертає `Err`, якщо немає батьківського елемента.
    /// Panics, якщо батьківський елемент порожній.
    ///
    /// Віддає перевагу лівій стороні, щоб бути оптимальною, якщо даний вузол якимось чином неповний, маючи на увазі тут лише те, що він має менше елементів, ніж його лівий брат та правий брат, якщо вони існують.
    /// У цьому випадку злиття з лівим братом та сестрою відбувається швидше, оскільки нам потрібно лише перемістити N-елементи вузла, замість того, щоб зміщувати їх праворуч і переміщати більше, ніж N елементів попереду.
    /// Крадіжка з лівого брата також зазвичай швидша, оскільки нам потрібно лише перенести N елементів вузла вправо, замість того, щоб перенести принаймні N елементів брата або сестри вліво.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn choose_parent_kv(self) -> Result<LeftOrRight<BalancingContext<'a, K, V>>, Self> {
        match unsafe { ptr::read(&self) }.ascend() {
            Ok(parent_edge) => match parent_edge.left_kv() {
                Ok(left_parent_kv) => Ok(LeftOrRight::Left(BalancingContext {
                    parent: unsafe { ptr::read(&left_parent_kv) },
                    left_child: left_parent_kv.left_edge().descend(),
                    right_child: self,
                })),
                Err(parent_edge) => match parent_edge.right_kv() {
                    Ok(right_parent_kv) => Ok(LeftOrRight::Right(BalancingContext {
                        parent: unsafe { ptr::read(&right_parent_kv) },
                        left_child: self,
                        right_child: right_parent_kv.right_edge().descend(),
                    })),
                    Err(_) => unreachable!("empty internal node"),
                },
            },
            Err(root) => Err(root),
        }
    }
}

impl<'a, K, V> BalancingContext<'a, K, V> {
    pub fn left_child_len(&self) -> usize {
        self.left_child.len()
    }

    pub fn right_child_len(&self) -> usize {
        self.right_child.len()
    }

    pub fn into_left_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.left_child
    }

    pub fn into_right_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.right_child
    }

    /// Повертає, чи можливе злиття, тобто чи достатньо місця у вузлі для поєднання центрального КВ з обома сусідніми дочірніми вузлами.
    ///
    pub fn can_merge(&self) -> bool {
        self.left_child.len() + 1 + self.right_child.len() <= CAPACITY
    }
}

impl<'a, K: 'a, V: 'a> BalancingContext<'a, K, V> {
    /// Виконує злиття і дозволяє закриття вирішити, що повернути.
    fn do_merge<
        F: FnOnce(
            NodeRef<marker::Mut<'a>, K, V, marker::Internal>,
            NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
        ) -> R,
        R,
    >(
        self,
        result: F,
    ) -> R {
        let Handle { node: mut parent_node, idx: parent_idx, _marker } = self.parent;
        let old_parent_len = parent_node.len();
        let mut left_node = self.left_child;
        let old_left_len = left_node.len();
        let mut right_node = self.right_child;
        let right_len = right_node.len();
        let new_left_len = old_left_len + 1 + right_len;

        assert!(new_left_len <= CAPACITY);

        unsafe {
            *left_node.len_mut() = new_left_len as u16;

            let parent_key = slice_remove(parent_node.key_area_mut(..old_parent_len), parent_idx);
            left_node.key_area_mut(old_left_len).write(parent_key);
            move_to_slice(
                right_node.key_area_mut(..right_len),
                left_node.key_area_mut(old_left_len + 1..new_left_len),
            );

            let parent_val = slice_remove(parent_node.val_area_mut(..old_parent_len), parent_idx);
            left_node.val_area_mut(old_left_len).write(parent_val);
            move_to_slice(
                right_node.val_area_mut(..right_len),
                left_node.val_area_mut(old_left_len + 1..new_left_len),
            );

            slice_remove(&mut parent_node.edge_area_mut(..old_parent_len + 1), parent_idx + 1);
            parent_node.correct_childrens_parent_links(parent_idx + 1..old_parent_len);
            *parent_node.len_mut() -= 1;

            if parent_node.height > 1 {
                // БЕЗПЕКА: висота вузлів, що об`єднуються, одна з них
                // вузла цього edge, таким чином, вище нуля, тому вони є внутрішніми.
                let mut left_node = left_node.reborrow_mut().cast_to_internal_unchecked();
                let mut right_node = right_node.cast_to_internal_unchecked();
                move_to_slice(
                    right_node.edge_area_mut(..right_len + 1),
                    left_node.edge_area_mut(old_left_len + 1..new_left_len + 1),
                );

                left_node.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);

                Global.deallocate(right_node.node.cast(), Layout::new::<InternalNode<K, V>>());
            } else {
                Global.deallocate(right_node.node.cast(), Layout::new::<LeafNode<K, V>>());
            }
        }
        result(parent_node, left_node)
    }

    /// Об`єднує батьківську пару ключ-значення та обидва сусідні дочірні вузли у лівий дочірній вузол і повертає зморщений батьківський вузол.
    ///
    ///
    /// Panics, якщо ми не `.can_merge()`.
    pub fn merge_tracking_parent(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        self.do_merge(|parent, _child| parent)
    }

    /// Об`єднує батьківську пару ключ-значення та обидва сусідні дочірні вузли у лівий дочірній вузол і повертає цей дочірній вузол.
    ///
    ///
    /// Panics, якщо ми не `.can_merge()`.
    pub fn merge_tracking_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.do_merge(|_parent, child| child)
    }

    /// Об'єднує батьківську пару ключ-значення та обидва сусідні дочірні вузли у лівий дочірній вузол і повертає дескриптор edge у тому дочірньому вузлі, де закінчився дочірній дочірній edge,
    ///
    ///
    /// Panics, якщо ми не `.can_merge()`.
    ///
    pub fn merge_tracking_child_edge(
        self,
        track_edge_idx: LeftOrRight<usize>,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        let old_left_len = self.left_child.len();
        let right_len = self.right_child.len();
        assert!(match track_edge_idx {
            LeftOrRight::Left(idx) => idx <= old_left_len,
            LeftOrRight::Right(idx) => idx <= right_len,
        });
        let child = self.merge_tracking_child();
        let new_idx = match track_edge_idx {
            LeftOrRight::Left(idx) => idx,
            LeftOrRight::Right(idx) => old_left_len + 1 + idx,
        };
        unsafe { Handle::new_edge(child, new_idx) }
    }

    /// Видаляє пару ключ-значення з лівого дочірнього пристрою та розміщує її у сховищі ключ-значення батьківського елемента, одночасно підштовхуючи стару батьківську пару ключ-значення до правої дочірньої організації.
    ///
    /// Повертає дескриптор edge у правій дочірній матері, що відповідає тому, де закінчився вихідний edge, вказаний `track_right_edge_idx`.
    ///
    pub fn steal_left(
        mut self,
        track_right_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_left(1);
        unsafe { Handle::new_edge(self.right_child, 1 + track_right_edge_idx) }
    }

    /// Видаляє пару ключ-значення з правого дочірнього пристрою та розміщує її у сховищі ключ-значення батьківського елемента, одночасно підштовхуючи стару батьківську пару ключ-значення до лівого дочірнього об'єкта.
    ///
    /// Повертає дескриптор до edge у лівій дочірній організації, вказаній `track_left_edge_idx`, яка не рухалася.
    ///
    pub fn steal_right(
        mut self,
        track_left_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_right(1);
        unsafe { Handle::new_edge(self.left_child, track_left_edge_idx) }
    }

    /// Це робить крадіжку подібно до `steal_left`, але викрадає кілька елементів одночасно.
    pub fn bulk_steal_left(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // Переконайтеся, що ми можемо безпечно вкрасти.
            assert!(old_right_len + count <= CAPACITY);
            assert!(old_left_len >= count);

            let new_left_len = old_left_len - count;
            let new_right_len = old_right_len + count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // Переміщення даних листя.
            {
                // Зробіть місце для вкрадених елементів у правильної дитини.
                slice_shr(right_node.key_area_mut(..new_right_len), count);
                slice_shr(right_node.val_area_mut(..new_right_len), count);

                // Перемістіть елементи від лівої дитини до правої.
                move_to_slice(
                    left_node.key_area_mut(new_left_len + 1..old_left_len),
                    right_node.key_area_mut(..count - 1),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len + 1..old_left_len),
                    right_node.val_area_mut(..count - 1),
                );

                // Перемістіть саму вкрадену ліву пару до батьків.
                let k = left_node.key_area_mut(new_left_len).assume_init_read();
                let v = left_node.val_area_mut(new_left_len).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // Перемістіть пару ключ-значення батьків до потрібної дочірньої дитини.
                right_node.key_area_mut(count - 1).write(k);
                right_node.val_area_mut(count - 1).write(v);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // Зробіть місце для вкрадених країв.
                    slice_shr(right.edge_area_mut(..new_right_len + 1), count);

                    // Красти краї.
                    move_to_slice(
                        left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                        right.edge_area_mut(..count),
                    );

                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }

    /// Симетричний клон `bulk_steal_left`.
    pub fn bulk_steal_right(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // Переконайтеся, що ми можемо безпечно вкрасти.
            assert!(old_left_len + count <= CAPACITY);
            assert!(old_right_len >= count);

            let new_left_len = old_left_len + count;
            let new_right_len = old_right_len - count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // Переміщення даних листя.
            {
                // Перенесіть саму правокрадену пару до батьків.
                let k = right_node.key_area_mut(count - 1).assume_init_read();
                let v = right_node.val_area_mut(count - 1).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // Перемістіть пару ключ-значення батьків до лівої дочірньої дитини.
                left_node.key_area_mut(old_left_len).write(k);
                left_node.val_area_mut(old_left_len).write(v);

                // Перемістіть елементи від правої дитини до лівої.
                move_to_slice(
                    right_node.key_area_mut(..count - 1),
                    left_node.key_area_mut(old_left_len + 1..new_left_len),
                );
                move_to_slice(
                    right_node.val_area_mut(..count - 1),
                    left_node.val_area_mut(old_left_len + 1..new_left_len),
                );

                // Заповніть пробіл там, де раніше були вкрадені елементи.
                slice_shl(right_node.key_area_mut(..old_right_len), count);
                slice_shl(right_node.val_area_mut(..old_right_len), count);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // Красти краї.
                    move_to_slice(
                        right.edge_area_mut(..count),
                        left.edge_area_mut(old_left_len + 1..new_left_len + 1),
                    );

                    // Заповніть щілину там, де раніше були вкрадені краї.
                    slice_shl(right.edge_area_mut(..old_right_len + 1), count);

                    left.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);
                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Leaf> {
    /// Видаляє будь-яку статичну інформацію, яка стверджує, що цей вузол є вузлом `Leaf`.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Видаляє будь-яку статичну інформацію, яка стверджує, що цей вузол є вузлом `Internal`.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V, Type> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, Type> {
    /// Перевіряє, чи базовий вузол є вузлом `Internal` чи вузлом `Leaf`.
    pub fn force(
        self,
    ) -> ForceResult<
        Handle<NodeRef<BorrowType, K, V, marker::Leaf>, Type>,
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, Type>,
    > {
        match self.node.force() {
            ForceResult::Leaf(node) => {
                ForceResult::Leaf(Handle { node, idx: self.idx, _marker: PhantomData })
            }
            ForceResult::Internal(node) => {
                ForceResult::Internal(Handle { node, idx: self.idx, _marker: PhantomData })
            }
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
    /// Перемістіть суфікс після `self` з одного вузла на інший.`right` має бути порожнім.
    /// Перший edge `right` залишається незмінним.
    pub fn move_suffix(
        &mut self,
        right: &mut NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    ) {
        unsafe {
            let new_left_len = self.idx;
            let mut left_node = self.reborrow_mut().into_node();
            let old_left_len = left_node.len();

            let new_right_len = old_left_len - new_left_len;
            let mut right_node = right.reborrow_mut();

            assert!(right_node.len() == 0);
            assert!(left_node.height == right_node.height);

            if new_right_len > 0 {
                *left_node.len_mut() = new_left_len as u16;
                *right_node.len_mut() = new_right_len as u16;

                move_to_slice(
                    left_node.key_area_mut(new_left_len..old_left_len),
                    right_node.key_area_mut(..new_right_len),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len..old_left_len),
                    right_node.val_area_mut(..new_right_len),
                );
                match (left_node.force(), right_node.force()) {
                    (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                        move_to_slice(
                            left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                            right.edge_area_mut(1..new_right_len + 1),
                        );
                        right.correct_childrens_parent_links(1..new_right_len + 1);
                    }
                    (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                    _ => unreachable!(),
                }
            }
        }
    }
}

pub enum ForceResult<Leaf, Internal> {
    Leaf(Leaf),
    Internal(Internal),
}

/// Результат вставки, коли вузлу потрібно було розширити свою потужність.
pub struct SplitResult<'a, K, V, NodeType> {
    // Змінений вузол у існуючому дереві з елементами та ребрами, які належать ліворуч від `kv`.
    pub left: NodeRef<marker::Mut<'a>, K, V, NodeType>,
    // Деякі ключ і значення розділилися, щоб вставити їх деінде.
    pub kv: (K, V),
    // Власний, неприєднаний, новий вузол з елементами та ребрами, що належать праворуч від `kv`.
    pub right: NodeRef<marker::Owned, K, V, NodeType>,
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Leaf> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Internal> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

pub enum InsertResult<'a, K, V, NodeType> {
    Fit(Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV>),
    Split(SplitResult<'a, K, V, NodeType>),
}

pub mod marker {
    use core::marker::PhantomData;

    pub enum Leaf {}
    pub enum Internal {}
    pub enum LeafOrInternal {}

    pub enum Owned {}
    pub enum Dying {}
    pub struct Immut<'a>(PhantomData<&'a ()>);
    pub struct Mut<'a>(PhantomData<&'a mut ()>);
    pub struct ValMut<'a>(PhantomData<&'a mut ()>);

    pub trait BorrowType {
        // Чи дозволяють посилання на вузли цього типу запозичення переходити до інших вузлів у дереві.
        //
        const PERMITS_TRAVERSAL: bool = true;
    }
    impl BorrowType for Owned {
        // Обхід не потрібен, це відбувається за результатом `borrow_mut`.
        // Вимикаючи обхід і створюючи лише посилання на корені, ми знаємо, що кожне посилання типу `Owned` стосується кореневого вузла.
        //
        const PERMITS_TRAVERSAL: bool = false;
    }
    impl BorrowType for Dying {}
    impl<'a> BorrowType for Immut<'a> {}
    impl<'a> BorrowType for Mut<'a> {}
    impl<'a> BorrowType for ValMut<'a> {}

    pub enum KV {}
    pub enum Edge {}
}

/// Вставляє значення у зріз ініціалізованих елементів, за яким слідує один неініціалізований елемент.
///
/// # Safety
/// Фрагмент містить більше `idx` елементів.
unsafe fn slice_insert<T>(slice: &mut [MaybeUninit<T>], idx: usize, val: T) {
    unsafe {
        let len = slice.len();
        debug_assert!(len > idx);
        let slice_ptr = slice.as_mut_ptr();
        if len > idx + 1 {
            ptr::copy(slice_ptr.add(idx), slice_ptr.add(idx + 1), len - idx - 1);
        }
        (*slice_ptr.add(idx)).write(val);
    }
}

/// Видаляє та повертає значення зі зрізу всіх ініціалізованих елементів, залишаючи позаду один неініціалізований елемент.
///
///
/// # Safety
/// Фрагмент містить більше `idx` елементів.
unsafe fn slice_remove<T>(slice: &mut [MaybeUninit<T>], idx: usize) -> T {
    unsafe {
        let len = slice.len();
        debug_assert!(idx < len);
        let slice_ptr = slice.as_mut_ptr();
        let ret = (*slice_ptr.add(idx)).assume_init_read();
        ptr::copy(slice_ptr.add(idx + 1), slice_ptr.add(idx), len - idx - 1);
        ret
    }
}

/// Зміщує елементи в зрізаному положенні `distance` вліво.
///
/// # Safety
/// Фрагмент має принаймні елементи `distance`.
unsafe fn slice_shl<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr.add(distance), slice_ptr, slice.len() - distance);
    }
}

/// Зміщує елементи в фрагменті `distance` вправо.
///
/// # Safety
/// Фрагмент має принаймні елементи `distance`.
unsafe fn slice_shr<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr, slice_ptr.add(distance), slice.len() - distance);
    }
}

/// Переміщує всі значення зі зрізу ініціалізованих елементів у зріз неініціалізованих елементів, залишаючи позаду `src` як усі неініціалізовані.
///
/// Працює як `dst.copy_from_slice(src)`, але не вимагає, щоб `T` був `Copy`.
fn move_to_slice<T>(src: &mut [MaybeUninit<T>], dst: &mut [MaybeUninit<T>]) {
    assert!(src.len() == dst.len());
    unsafe {
        ptr::copy_nonoverlapping(src.as_ptr(), dst.as_mut_ptr(), src.len());
    }
}

#[cfg(test)]
mod tests;