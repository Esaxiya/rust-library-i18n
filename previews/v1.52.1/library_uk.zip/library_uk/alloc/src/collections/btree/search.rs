use core::borrow::Borrow;
use core::cmp::Ordering;
use core::ops::{Bound, RangeBounds};

use super::node::{marker, ForceResult::*, Handle, NodeRef};

use SearchBound::*;
use SearchResult::*;

pub enum SearchBound<T> {
    /// Інклюзив, який потрібно шукати, як і `Bound::Included(T)`.
    Included(T),
    /// Ексклюзив, який потрібно шукати, як і `Bound::Excluded(T)`.
    Excluded(T),
    /// Безумовний інклюзивний кордон, як і `Bound::Unbounded`.
    AllIncluded,
    /// Безумовна ексклюзивна межа.
    AllExcluded,
}

impl<T> SearchBound<T> {
    pub fn from_range(range_bound: Bound<T>) -> Self {
        match range_bound {
            Bound::Included(t) => Included(t),
            Bound::Excluded(t) => Excluded(t),
            Bound::Unbounded => AllIncluded,
        }
    }
}

pub enum SearchResult<BorrowType, K, V, FoundType, GoDownType> {
    Found(Handle<NodeRef<BorrowType, K, V, FoundType>, marker::KV>),
    GoDown(Handle<NodeRef<BorrowType, K, V, GoDownType>, marker::Edge>),
}

pub enum IndexResult {
    KV(usize),
    Edge(usize),
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Шукає заданий ключ у (під) дереві, очолюваному вузлом, рекурсивно.
    /// Повертає `Found` з ручкою відповідного КВ, якщо такий є.
    /// В іншому випадку повертає `GoDown` із ручкою аркуша edge, де належить ключ.
    ///
    /// Результат значущий лише в тому випадку, якщо дерево упорядковано за ключем, як дерево у `BTreeMap`.
    ///
    pub fn search_tree<Q: ?Sized>(
        mut self,
        key: &Q,
    ) -> SearchResult<BorrowType, K, V, marker::LeafOrInternal, marker::Leaf>
    where
        Q: Ord,
        K: Borrow<Q>,
    {
        loop {
            self = match self.search_node(key) {
                Found(handle) => return Found(handle),
                GoDown(handle) => match handle.force() {
                    Leaf(leaf) => return GoDown(leaf),
                    Internal(internal) => internal.descend(),
                },
            }
        }
    }

    /// Спускається до найближчого вузла, де edge, що відповідає нижній межі діапазону, відрізняється від edge, що відповідає верхній межі, тобто найближчий вузол, який має принаймні один ключ, що міститься в діапазоні.
    ///
    ///
    /// Якщо знайдено, повертає `Ok` з цим вузлом, пара індексів edge в ньому, що обмежують діапазон, і відповідна пара меж для продовження пошуку в дочірніх вузлах, якщо вузол є внутрішнім.
    ///
    /// Якщо не знайдено, повертає `Err` з аркушем edge, що відповідає всьому діапазону.
    ///
    /// Результат значущий лише в тому випадку, якщо дерево упорядковано за ключем.
    ///
    ///
    ///
    ///
    pub fn search_tree_for_bifurcation<'r, Q: ?Sized, R>(
        mut self,
        range: &'r R,
    ) -> Result<
        (
            NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
            usize,
            usize,
            SearchBound<&'r Q>,
            SearchBound<&'r Q>,
        ),
        Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>,
    >
    where
        Q: Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        // Слід уникати вбудовування цих змінних.
        // Ми вважаємо, що межі, про які повідомляє `range`, залишаються незмінними, але змагальна реалізація може змінюватися між викликами (#81138).
        let (start, end) = (range.start_bound(), range.end_bound());
        match (start, end) {
            (Bound::Excluded(s), Bound::Excluded(e)) if s == e => {
                panic!("range start and end are equal and excluded in BTreeMap")
            }
            (Bound::Included(s) | Bound::Excluded(s), Bound::Included(e) | Bound::Excluded(e))
                if s > e =>
            {
                panic!("range start is greater than range end in BTreeMap")
            }
            _ => {}
        }
        let mut lower_bound = SearchBound::from_range(start);
        let mut upper_bound = SearchBound::from_range(end);
        loop {
            let (lower_edge_idx, lower_child_bound) = self.find_lower_bound_index(lower_bound);
            let (upper_edge_idx, upper_child_bound) = self.find_upper_bound_index(upper_bound);
            if lower_edge_idx > upper_edge_idx {
                panic!("Ord is ill-defined in BTreeMap range")
            }
            if lower_edge_idx < upper_edge_idx {
                return Ok((
                    self,
                    lower_edge_idx,
                    upper_edge_idx,
                    lower_child_bound,
                    upper_child_bound,
                ));
            }
            let common_edge = unsafe { Handle::new_edge(self, lower_edge_idx) };
            match common_edge.force() {
                Leaf(common_edge) => return Err(common_edge),
                Internal(common_edge) => {
                    self = common_edge.descend();
                    lower_bound = lower_child_bound;
                    upper_bound = upper_child_bound;
                }
            }
        }
    }

    /// Знаходить edge у вузлі, що обмежує нижню межу діапазону.
    /// Також повертає нижню межу, яка буде використана для продовження пошуку у відповідному дочірньому вузлі, якщо `self` є внутрішнім вузлом.
    ///
    ///
    /// Результат значущий лише в тому випадку, якщо дерево упорядковано за ключем.
    pub fn find_lower_bound_edge<'r, Q>(
        self,
        bound: SearchBound<&'r Q>,
    ) -> (Handle<Self, marker::Edge>, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        let (edge_idx, bound) = self.find_lower_bound_index(bound);
        let edge = unsafe { Handle::new_edge(self, edge_idx) };
        (edge, bound)
    }

    /// Клон `find_lower_bound_edge` для верхньої межі.
    pub fn find_upper_bound_edge<'r, Q>(
        self,
        bound: SearchBound<&'r Q>,
    ) -> (Handle<Self, marker::Edge>, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        let (edge_idx, bound) = self.find_upper_bound_index(bound);
        let edge = unsafe { Handle::new_edge(self, edge_idx) };
        (edge, bound)
    }
}

impl<BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// Шукає заданий ключ у вузлі без рекурсії.
    /// Повертає `Found` з ручкою відповідного КВ, якщо такий є.
    /// В іншому випадку повертає `GoDown` з дескриптором edge, де може бути знайдений ключ (якщо вузол внутрішній) або куди можна вставити ключ.
    ///
    ///
    /// Результат значущий лише в тому випадку, якщо дерево упорядковано за ключем, як дерево у `BTreeMap`.
    ///
    pub fn search_node<Q: ?Sized>(self, key: &Q) -> SearchResult<BorrowType, K, V, Type, Type>
    where
        Q: Ord,
        K: Borrow<Q>,
    {
        match self.find_key_index(key) {
            IndexResult::KV(idx) => Found(unsafe { Handle::new_kv(self, idx) }),
            IndexResult::Edge(idx) => GoDown(unsafe { Handle::new_edge(self, idx) }),
        }
    }

    /// Повертає або індекс KV у вузлі, в якому існує ключ (або еквівалент), або індекс edge, де належить ключ.
    ///
    ///
    /// Результат значущий лише в тому випадку, якщо дерево упорядковано за ключем, як дерево у `BTreeMap`.
    ///
    fn find_key_index<Q: ?Sized>(&self, key: &Q) -> IndexResult
    where
        Q: Ord,
        K: Borrow<Q>,
    {
        let node = self.reborrow();
        let keys = node.keys();
        for (i, k) in keys.iter().enumerate() {
            match key.cmp(k.borrow()) {
                Ordering::Greater => {}
                Ordering::Equal => return IndexResult::KV(i),
                Ordering::Less => return IndexResult::Edge(i),
            }
        }
        IndexResult::Edge(keys.len())
    }

    /// Знаходить індекс edge у вузлі, що обмежує нижню межу діапазону.
    /// Також повертає нижню межу, яка буде використана для продовження пошуку у відповідному дочірньому вузлі, якщо `self` є внутрішнім вузлом.
    ///
    ///
    /// Результат значущий лише в тому випадку, якщо дерево упорядковано за ключем.
    fn find_lower_bound_index<'r, Q>(
        &self,
        bound: SearchBound<&'r Q>,
    ) -> (usize, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        match bound {
            Included(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx, AllExcluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            Excluded(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx + 1, AllIncluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            AllIncluded => (0, AllIncluded),
            AllExcluded => (self.len(), AllExcluded),
        }
    }

    /// Клон `find_lower_bound_index` для верхньої межі.
    fn find_upper_bound_index<'r, Q>(
        &self,
        bound: SearchBound<&'r Q>,
    ) -> (usize, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        match bound {
            Included(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx + 1, AllExcluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            Excluded(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx, AllIncluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            AllIncluded => (self.len(), AllIncluded),
            AllExcluded => (0, AllExcluded),
        }
    }
}