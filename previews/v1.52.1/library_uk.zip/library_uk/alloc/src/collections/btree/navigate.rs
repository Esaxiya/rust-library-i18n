use core::borrow::Borrow;
use core::ops::RangeBounds;
use core::ptr;

use super::node::{marker, ForceResult::*, Handle, NodeRef};

pub struct LeafRange<BorrowType, K, V> {
    pub front: Option<Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>>,
    pub back: Option<Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>>,
}

impl<BorrowType, K, V> LeafRange<BorrowType, K, V> {
    pub fn none() -> Self {
        LeafRange { front: None, back: None }
    }

    pub fn is_empty(&self) -> bool {
        self.front == self.back
    }

    /// Тимчасово виймає інший, незмінний еквівалент того ж діапазону.
    pub fn reborrow(&self) -> LeafRange<marker::Immut<'_>, K, V> {
        LeafRange {
            front: self.front.as_ref().map(|f| f.reborrow()),
            back: self.back.as_ref().map(|b| b.reborrow()),
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Знаходить чіткі краї листків, що обмежують вказаний діапазон у дереві.
    /// Повертає або пару різних ручок в одне дерево, або пару порожніх параметрів.
    ///
    /// # Safety
    ///
    /// Якщо `BorrowType` не є `Immut`, не використовуйте повторювані ручки для відвідування одного і того ж КВ двічі.
    unsafe fn find_leaf_edges_spanning_range<Q: ?Sized, R>(
        self,
        range: R,
    ) -> LeafRange<BorrowType, K, V>
    where
        Q: Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        match self.search_tree_for_bifurcation(&range) {
            Err(_) => LeafRange::none(),
            Ok((
                node,
                lower_edge_idx,
                upper_edge_idx,
                mut lower_child_bound,
                mut upper_child_bound,
            )) => {
                let mut lower_edge = unsafe { Handle::new_edge(ptr::read(&node), lower_edge_idx) };
                let mut upper_edge = unsafe { Handle::new_edge(node, upper_edge_idx) };
                loop {
                    match (lower_edge.force(), upper_edge.force()) {
                        (Leaf(f), Leaf(b)) => return LeafRange { front: Some(f), back: Some(b) },
                        (Internal(f), Internal(b)) => {
                            (lower_edge, lower_child_bound) =
                                f.descend().find_lower_bound_edge(lower_child_bound);
                            (upper_edge, upper_child_bound) =
                                b.descend().find_upper_bound_edge(upper_child_bound);
                        }
                        _ => unreachable!("BTreeMap has different depths"),
                    }
                }
            }
        }
    }
}

/// Еквівалентно `(root1.first_leaf_edge(), root2.last_leaf_edge())`, але ефективніше.
fn full_range<BorrowType: marker::BorrowType, K, V>(
    root1: NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    root2: NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
) -> LeafRange<BorrowType, K, V> {
    let mut min_node = root1;
    let mut max_node = root2;
    loop {
        let front = min_node.first_edge();
        let back = max_node.last_edge();
        match (front.force(), back.force()) {
            (Leaf(f), Leaf(b)) => {
                return LeafRange { front: Some(f), back: Some(b) };
            }
            (Internal(min_int), Internal(max_int)) => {
                min_node = min_int.descend();
                max_node = max_int.descend();
            }
            _ => unreachable!("BTreeMap has different depths"),
        };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Immut<'a>, K, V, marker::LeafOrInternal> {
    /// Знаходить пару країв листя, що обмежує певний діапазон у дереві.
    ///
    /// Результат значущий лише в тому випадку, якщо дерево упорядковано за ключем, як дерево у `BTreeMap`.
    ///
    pub fn range_search<Q, R>(self, range: R) -> LeafRange<marker::Immut<'a>, K, V>
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        // БЕЗПЕКА: наш тип позики є незмінним.
        unsafe { self.find_leaf_edges_spanning_range(range) }
    }

    /// Знаходить пару країв листя, що обмежує ціле дерево.
    pub fn full_range(self) -> LeafRange<marker::Immut<'a>, K, V> {
        full_range(self, self)
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::ValMut<'a>, K, V, marker::LeafOrInternal> {
    /// Розбиває унікальне посилання на пару країв листя, що обмежують заданий діапазон.
    /// Результатом є не унікальні посилання, що дозволяють мутувати (some), якими потрібно користуватися обережно.
    ///
    /// Результат значущий лише в тому випадку, якщо дерево упорядковано за ключем, як дерево у `BTreeMap`.
    ///
    ///
    /// # Safety
    /// Не використовуйте повторювані ручки, щоб двічі відвідувати один і той же КВ.
    ///
    pub fn range_search<Q, R>(self, range: R) -> LeafRange<marker::ValMut<'a>, K, V>
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        unsafe { self.find_leaf_edges_spanning_range(range) }
    }

    /// Розбиває унікальне посилання на пару країв листя, що обмежує весь діапазон дерева.
    /// Результати-це не унікальні посилання, що дозволяють мутувати (лише значень), тому їх слід використовувати обережно.
    ///
    pub fn full_range(self) -> LeafRange<marker::ValMut<'a>, K, V> {
        // Ми продублюємо тут кореневий NodeRef-ми ніколи не будемо відвідувати один і той же KV двічі і ніколи не матиме перекриваючих посилань на значення.
        //
        let self2 = unsafe { ptr::read(&self) };
        full_range(self, self2)
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// Розбиває унікальне посилання на пару країв листя, що обмежує весь діапазон дерева.
    /// Результати-не унікальні посилання, що дозволяють масово руйнівну мутацію, тому їх слід використовувати з максимальною обережністю.
    ///
    pub fn full_range(self) -> LeafRange<marker::Dying, K, V> {
        // Ми продублюємо кореневий NodeRef тут-ми ніколи не матимемо до нього доступу таким чином, що перекриває посилання, отримані з кореня.
        //
        let self2 = unsafe { ptr::read(&self) };
        full_range(self, self2)
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>
{
    /// Отримавши ручку edge стулки, повертає [`Result::Ok`] з ручкою до сусіднього КВ з правого боку, який знаходиться або в тому ж самому вузлі листа, або у вузлі предка.
    ///
    /// Якщо лист edge є останнім у дереві, повертає [`Result::Err`] з кореневим вузлом.
    pub fn next_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    > {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.right_kv() {
                Ok(kv) => return Ok(kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge.forget_node_type(),
                    Err(root) => return Err(root),
                },
            }
        }
    }

    /// Отримавши ручку edge стулки, повертає [`Result::Ok`] з ручкою до сусіднього КВ з лівого боку, який знаходиться або в тому ж самому вузлі листа, або у вузлі предка.
    ///
    /// Якщо лист edge є першим у дереві, повертає [`Result::Err`] з кореневим вузлом.
    pub fn next_back_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    > {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.left_kv() {
                Ok(kv) => return Ok(kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge.forget_node_type(),
                    Err(root) => return Err(root),
                },
            }
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// Враховуючи внутрішній дескриптор edge, повертає [`Result::Ok`] з дескриптором до сусіднього КВ з правого боку, який знаходиться або в тому самому внутрішньому вузлі, або у вузлі-предку.
    ///
    /// Якщо внутрішній edge є останнім у дереві, повертає [`Result::Err`] з кореневим вузлом.
    pub fn next_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        let mut edge = self;
        loop {
            edge = match edge.right_kv() {
                Ok(internal_kv) => return Ok(internal_kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge,
                    Err(root) => return Err(root),
                },
            }
        }
    }
}

impl<K, V> Handle<NodeRef<marker::Dying, K, V, marker::Leaf>, marker::Edge> {
    /// Отримавши маркер листа edge у вмираюче дерево, повертає наступний аркуш edge з правого боку та пару ключ-значення між ними, яка знаходиться або в тому самому вузлі листа, у вузлі предка, або не існує.
    ///
    ///
    /// Цей метод також звільняє будь-який node(s), який він досягнув до кінця.
    /// Це означає, що якщо більше не існує пари ключ-значення, вся залишок дерева буде звільнений, і повернути нічого не залишиться.
    ///
    /// # Safety
    /// Даний edge не повинен бути раніше повернутий аналогом `deallocating_next_back`.
    ///
    ///
    ///
    unsafe fn deallocating_next(self) -> Option<(Self, (K, V))> {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.right_kv() {
                Ok(kv) => {
                    let k = unsafe { ptr::read(kv.reborrow().into_kv().0) };
                    let v = unsafe { ptr::read(kv.reborrow().into_kv().1) };
                    return Some((kv.next_leaf_edge(), (k, v)));
                }
                Err(last_edge) => match unsafe { last_edge.into_node().deallocate_and_ascend() } {
                    Some(parent_edge) => parent_edge.forget_node_type(),
                    None => return None,
                },
            }
        }
    }

    /// Отримавши маркер листа edge у вмираюче дерево, повертає наступний аркуш edge з лівого боку та пару ключ-значення між ними, яка знаходиться або в тому самому вузлі листа, у вузлі предка, або не існує.
    ///
    ///
    /// Цей метод також звільняє будь-який node(s), який він досягнув до кінця.
    /// Це означає, що якщо більше не існує пари ключ-значення, вся залишок дерева буде звільнений, і повернути нічого не залишиться.
    ///
    /// # Safety
    /// Даний edge не повинен бути раніше повернутий аналогом `deallocating_next`.
    ///
    ///
    ///
    unsafe fn deallocating_next_back(self) -> Option<(Self, (K, V))> {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.left_kv() {
                Ok(kv) => {
                    let k = unsafe { ptr::read(kv.reborrow().into_kv().0) };
                    let v = unsafe { ptr::read(kv.reborrow().into_kv().1) };
                    return Some((kv.next_back_leaf_edge(), (k, v)));
                }
                Err(last_edge) => match unsafe { last_edge.into_node().deallocate_and_ascend() } {
                    Some(parent_edge) => parent_edge.forget_node_type(),
                    None => return None,
                },
            }
        }
    }

    /// Виділяє купу вузлів від листа до кореня.
    /// Це єдиний спосіб знешкодити залишок дерева після того, як `deallocating_next` і `deallocating_next_back` погризали по обидві сторони дерева і вдарили по тому самому edge.
    /// Оскільки він призначений для виклику лише тоді, коли всі ключі та значення повернуті, жодне з ключів чи значень не виконує очищення.
    ///
    ///
    ///
    pub fn deallocating_end(self) {
        let mut edge = self.forget_node_type();
        while let Some(parent_edge) = unsafe { edge.into_node().deallocate_and_ascend() } {
            edge = parent_edge.forget_node_type();
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Immut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Переміщує маркер листочка edge до наступного аркуша edge і повертає посилання на ключ і значення між ними.
    ///
    ///
    /// # Safety
    /// У пройденому напрямку повинен бути інший КВ.
    pub unsafe fn next_unchecked(&mut self) -> (&'a K, &'a V) {
        super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (kv.next_leaf_edge(), kv.into_kv())
        })
    }

    /// Переміщує листок edge до попереднього аркуша edge і повертає посилання на ключ і значення між ними.
    ///
    ///
    /// # Safety
    /// У пройденому напрямку повинен бути інший КВ.
    pub unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a V) {
        super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_back_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (kv.next_back_leaf_edge(), kv.into_kv())
        })
    }
}

impl<'a, K, V> Handle<NodeRef<marker::ValMut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Переміщує маркер листочка edge до наступного аркуша edge і повертає посилання на ключ і значення між ними.
    ///
    ///
    /// # Safety
    /// У пройденому напрямку повинен бути інший КВ.
    pub unsafe fn next_unchecked(&mut self) -> (&'a K, &'a mut V) {
        let kv = super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (unsafe { ptr::read(&kv) }.next_leaf_edge(), kv)
        });
        // Зробити це в останню чергу швидше, згідно з тестами.
        kv.into_kv_valmut()
    }

    /// Переміщує маркер листочка edge на попередній аркуш і повертає посилання на ключ і значення між ними.
    ///
    ///
    /// # Safety
    /// У пройденому напрямку повинен бути інший КВ.
    pub unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a mut V) {
        let kv = super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_back_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (unsafe { ptr::read(&kv) }.next_back_leaf_edge(), kv)
        });
        // Зробити це в останню чергу швидше, згідно з тестами.
        kv.into_kv_valmut()
    }
}

impl<K, V> Handle<NodeRef<marker::Dying, K, V, marker::Leaf>, marker::Edge> {
    /// Переміщує маркер листа edge до наступного аркуша edge і повертає ключ і значення між ними, звільняючи будь-який вузол, що залишився, залишаючи відповідний edge у своєму батьківському вузлі, що бовтається.
    ///
    /// # Safety
    /// - У пройденому напрямку повинен бути інший КВ.
    /// - Цей KV раніше не повернув аналог `next_back_unchecked` на жодній копії ручок, що використовуються для обходу дерева.
    ///
    /// Єдиний безпечний спосіб продовжити роботу з оновленим дескриптором-це порівняти його, випустити, повторно викликати цей метод з урахуванням його умов безпеки або зателефонувати до аналога `next_back_unchecked` відповідно до його умов безпеки.
    ///
    ///
    ///
    ///
    ///
    pub unsafe fn deallocating_next_unchecked(&mut self) -> (K, V) {
        super::mem::replace(self, |leaf_edge| unsafe {
            leaf_edge.deallocating_next().unwrap_unchecked()
        })
    }

    /// Переміщує маркер листа edge до попереднього аркуша edge і повертає ключ і значення між ними, звільняючи будь-який вузол, що залишився, залишаючи відповідний edge у своєму батьківському вузлі, що бовтається.
    ///
    /// # Safety
    /// - У пройденому напрямку повинен бути інший КВ.
    /// - Цей аркуш edge раніше не повернув аналог `next_unchecked` на жодній копії ручок, що використовуються для обходу дерева.
    ///
    /// Єдиний безпечний спосіб продовжити роботу з оновленим дескриптором-це порівняти його, випустити, повторно викликати цей метод з урахуванням його умов безпеки або зателефонувати до аналога `next_unchecked` відповідно до його умов безпеки.
    ///
    ///
    ///
    ///
    ///
    pub unsafe fn deallocating_next_back_unchecked(&mut self) -> (K, V) {
        super::mem::replace(self, |leaf_edge| unsafe {
            leaf_edge.deallocating_next_back().unwrap_unchecked()
        })
    }
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Повертає крайній лівий аркуш edge у або під вузлом, іншими словами, edge, який вам потрібен спочатку при навігації вперед (або останній при навігації назад).
    ///
    #[inline]
    pub fn first_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        let mut node = self;
        loop {
            match node.force() {
                Leaf(leaf) => return leaf.first_edge(),
                Internal(internal) => node = internal.first_edge().descend(),
            }
        }
    }

    /// Повертає крайній правий аркуш edge у або під вузлом, іншими словами, edge, який вам потрібен останнім при навігації вперед (або першим при навігації назад).
    ///
    #[inline]
    pub fn last_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        let mut node = self;
        loop {
            match node.force() {
                Leaf(leaf) => return leaf.last_edge(),
                Internal(internal) => node = internal.last_edge().descend(),
            }
        }
    }
}

pub enum Position<BorrowType, K, V> {
    Leaf(NodeRef<BorrowType, K, V, marker::Leaf>),
    Internal(NodeRef<BorrowType, K, V, marker::Internal>),
    InternalKV(Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV>),
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Immut<'a>, K, V, marker::LeafOrInternal> {
    /// Відвідує листові вузли та внутрішні KV в порядку зростання вищих ключів, а також відвідує внутрішні вузли в цілому в глибині першого порядку, тобто внутрішні вузли передують їх окремим KV та їх дочірнім вузлам.
    ///
    ///
    pub fn visit_nodes_in_order<F>(self, mut visit: F)
    where
        F: FnMut(Position<marker::Immut<'a>, K, V>),
    {
        match self.force() {
            Leaf(leaf) => visit(Position::Leaf(leaf)),
            Internal(internal) => {
                visit(Position::Internal(internal));
                let mut edge = internal.first_edge();
                loop {
                    edge = match edge.descend().force() {
                        Leaf(leaf) => {
                            visit(Position::Leaf(leaf));
                            match edge.next_kv() {
                                Ok(kv) => {
                                    visit(Position::InternalKV(kv));
                                    kv.right_edge()
                                }
                                Err(_) => return,
                            }
                        }
                        Internal(internal) => {
                            visit(Position::Internal(internal));
                            internal.first_edge()
                        }
                    }
                }
            }
        }
    }

    /// Обчислює кількість елементів у (під) дереві.
    pub fn calc_length(self) -> usize {
        let mut result = 0;
        self.visit_nodes_in_order(|pos| match pos {
            Position::Leaf(node) => result += node.len(),
            Position::Internal(node) => result += node.len(),
            Position::InternalKV(_) => (),
        });
        result
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>
{
    /// Повертає аркуш edge, найближчий до КВ для навігації вперед.
    pub fn next_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        match self.force() {
            Leaf(leaf_kv) => leaf_kv.right_edge(),
            Internal(internal_kv) => {
                let next_internal_edge = internal_kv.right_edge();
                next_internal_edge.descend().first_leaf_edge()
            }
        }
    }

    /// Повертає аркуш edge, найближчий до КВ, для зворотної навігації.
    pub fn next_back_leaf_edge(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        match self.force() {
            Leaf(leaf_kv) => leaf_kv.left_edge(),
            Internal(internal_kv) => {
                let next_internal_edge = internal_kv.left_edge();
                next_internal_edge.descend().last_leaf_edge()
            }
        }
    }
}