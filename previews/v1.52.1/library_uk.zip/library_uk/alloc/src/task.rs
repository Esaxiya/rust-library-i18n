#![stable(feature = "wake_trait", since = "1.51.0")]
//! Типи та Traits для роботи з асинхронними завданнями.
use core::mem::ManuallyDrop;
use core::task::{RawWaker, RawWakerVTable, Waker};

use crate::sync::Arc;

/// Здійснення пробудження завдання на виконавця.
///
/// Цей Portrait можна використовувати для створення [`Waker`].
/// Виконавець може визначити реалізацію цього Portrait і використовувати його для побудови Waker для переходу до завдань, які виконуються на цьому виконавці.
///
/// Цей Portrait є безпечною та ергономічною альтернативою конструкції [`RawWaker`].
/// Він підтримує загальний дизайн виконавця, в якому дані, що використовуються для пробудження завдання, зберігаються в [`Arc`].
/// Деякі виконавці (особливо для вбудованих систем) не можуть використовувати цей API, саме тому [`RawWaker`] існує як альтернатива цим системам.
///
/// [arc]: ../../std/sync/struct.Arc.html
///
/// # Examples
///
/// Базова функція `block_on`, яка приймає future і запускає його до завершення в поточному потоці.
///
/// **Note:** Цей приклад торгує коректністю для простоти.
/// Для запобігання тупикових ситуацій впровадженням виробничого рівня також потрібно буде обробляти проміжні виклики до `thread::unpark`, а також вкладені виклики.
///
///
/// ```rust
/// use std::future::Future;
/// use std::sync::Arc;
/// use std::task::{Context, Poll, Wake};
/// use std::thread::{self, Thread};
///
/// /// Waker, який пробуджує поточний потік при виклику.
/// struct ThreadWaker(Thread);
///
/// impl Wake for ThreadWaker {
///     fn wake(self: Arc<Self>) {
///         self.0.unpark();
///     }
/// }
///
/// /// Запустіть future до завершення на поточному потоці.
/// fn block_on<T>(fut: impl Future<Output = T>) -> T {
///     // Закріпіть future, щоб його можна було опитувати.
///     let mut fut = Box::pin(fut);
///
///     // Створіть новий контекст, який буде передано future.
///     let t = thread::current();
///     let waker = Arc::new(ThreadWaker(t)).into();
///     let mut cx = Context::from_waker(&waker);
///
///     // Запустіть future до кінця.
///     loop {
///         match fut.as_mut().poll(&mut cx) {
///             Poll::Ready(res) => return res,
///             Poll::Pending => thread::park(),
///         }
///     }
/// }
///
/// block_on(async {
///     println!("Hi from inside a future!");
/// });
/// ```
///
///
///
///
#[stable(feature = "wake_trait", since = "1.51.0")]
pub trait Wake {
    /// Розбудіть це завдання.
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake(self: Arc<Self>);

    /// Пробудіть це завдання, не поглинаючи бура.
    ///
    /// Якщо виконавець підтримує більш дешевий спосіб пробудження, не споживаючи бодрствовання, він повинен замінити цей метод.
    /// За замовчуванням він клонує [`Arc`] і викликає [`wake`] на клоні.
    ///
    /// [`wake`]: Wake::wake
    ///
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake_by_ref(self: &Arc<Self>) {
        self.clone().wake();
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for Waker {
    fn from(waker: Arc<W>) -> Waker {
        // БЕЗПЕКА: Це безпечно, оскільки raw_waker безпечно конструює
        // RawWaker від Arc<W>.
        unsafe { Waker::from_raw(raw_waker(waker)) }
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for RawWaker {
    fn from(waker: Arc<W>) -> RawWaker {
        raw_waker(waker)
    }
}

// NB: Ця приватна функція для побудови RawWaker використовується, а не
// вбудовуючи це в імпульс `From<Arc<W>> for RawWaker`, щоб гарантувати, що безпека `From<Arc<W>> for Waker` не залежить від правильної відправки Portrait, натомість обидва імпульси викликають цю функцію прямо та явно.
//
//
//
#[inline(always)]
fn raw_waker<W: Wake + Send + Sync + 'static>(waker: Arc<W>) -> RawWaker {
    // Збільште кількість посилань дуги, щоб її клонувати.
    unsafe fn clone_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) -> RawWaker {
        unsafe { Arc::increment_strong_count(waker as *const W) };
        RawWaker::new(
            waker as *const (),
            &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
        )
    }

    // Пробудження за значенням, переміщення дуги у функцію Wake::wake
    unsafe fn wake<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { Arc::from_raw(waker as *const W) };
        <W as Wake>::wake(waker);
    }

    // Прокиньтесь за посиланням, оберніть waker ManuallyDrop, щоб уникнути його
    unsafe fn wake_by_ref<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { ManuallyDrop::new(Arc::from_raw(waker as *const W)) };
        <W as Wake>::wake_by_ref(&waker);
    }

    // Зменшіть кількість посилань Дуги при падінні
    unsafe fn drop_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        unsafe { Arc::decrement_strong_count(waker as *const W) };
    }

    RawWaker::new(
        Arc::into_raw(waker) as *const (),
        &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
    )
}