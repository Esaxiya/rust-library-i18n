//! Суцільний тип масиву, що розмножується, із виділеним купою вмістом, написаний `Vec<T>`.
//!
//! Vectors мають індексацію `O(1)`, амортизований `O(1)` push (до кінця) та `O(1)` поп (з кінця).
//!
//!
//! Vectors гарантують, що вони ніколи не виділяють більше `isize::MAX` байт.
//!
//! # Examples
//!
//! Ви можете явно створити [`Vec`] з [`Vec::new`]:
//!
//! ```
//! let v: Vec<i32> = Vec::new();
//! ```
//!
//! ... або за допомогою макросу [`vec!`]:
//!
//! ```
//! let v: Vec<i32> = vec![];
//!
//! let v = vec![1, 2, 3, 4, 5];
//!
//! let v = vec![0; 10]; // десять нулів
//! ```
//!
//! Ви можете вказати значення [`push`] у кінці vector (який буде збільшувати vector за необхідності):
//!
//! ```
//! let mut v = vec![1, 2];
//!
//! v.push(3);
//! ```
//!
//! Вискакування значень працює приблизно так само:
//!
//! ```
//! let mut v = vec![1, 2];
//!
//! let two = v.pop();
//! ```
//!
//! Vectors також підтримує індексацію (через [`Index`] та [`IndexMut`] traits):
//!
//! ```
//! let mut v = vec![1, 2, 3];
//! let three = v[2];
//! v[1] = v[1] + 5;
//! ```
//!
//! [`push`]: Vec::push
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::cmp::{self, Ordering};
use core::convert::TryFrom;
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::{arith_offset, assume};
use core::iter::FromIterator;
use core::marker::PhantomData;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::{self, Index, IndexMut, Range, RangeBounds};
use core::ptr::{self, NonNull};
use core::slice::{self, SliceIndex};

use crate::alloc::{Allocator, Global};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::collections::TryReserveError;
use crate::raw_vec::RawVec;

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
pub use self::drain_filter::DrainFilter;

mod drain_filter;

#[stable(feature = "vec_splice", since = "1.21.0")]
pub use self::splice::Splice;

mod splice;

#[stable(feature = "drain", since = "1.6.0")]
pub use self::drain::Drain;

mod drain;

mod cow;

pub(crate) use self::into_iter::AsIntoIter;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::into_iter::IntoIter;

mod into_iter;

use self::is_zero::IsZero;

mod is_zero;

mod source_iter_marker;

mod partial_eq;

use self::spec_from_elem::SpecFromElem;

mod spec_from_elem;

use self::set_len_on_drop::SetLenOnDrop;

mod set_len_on_drop;

use self::in_place_drop::InPlaceDrop;

mod in_place_drop;

use self::spec_from_iter_nested::SpecFromIterNested;

mod spec_from_iter_nested;

use self::spec_from_iter::SpecFromIter;

mod spec_from_iter;

use self::spec_extend::SpecExtend;

mod spec_extend;

/// Суміжний тип масиву, що розмножується, пишеться як `Vec<T>` і вимовляється як 'vector'.
///
/// # Examples
///
/// ```
/// let mut vec = Vec::new();
/// vec.push(1);
/// vec.push(2);
///
/// assert_eq!(vec.len(), 2);
/// assert_eq!(vec[0], 1);
///
/// assert_eq!(vec.pop(), Some(2));
/// assert_eq!(vec.len(), 1);
///
/// vec[0] = 7;
/// assert_eq!(vec[0], 7);
///
/// vec.extend([1, 2, 3].iter().copied());
///
/// for x in &vec {
///     println!("{}", x);
/// }
/// assert_eq!(vec, [7, 1, 2, 3]);
/// ```
///
/// Макрос [`vec!`] надається для зручності ініціалізації:
///
/// ```
/// let mut vec = vec![1, 2, 3];
/// vec.push(4);
/// assert_eq!(vec, [1, 2, 3, 4]);
/// ```
///
/// Він також може ініціалізувати кожен елемент `Vec<T>` із заданим значенням.
/// Це може бути ефективнішим, ніж виконання розподілу та ініціалізації в окремих кроках, особливо при ініціалізації vector нулів:
///
/// ```
/// let vec = vec![0; 5];
/// assert_eq!(vec, [0, 0, 0, 0, 0]);
///
/// // Наведене нижче еквівалентно, але потенційно повільніше:
/// let mut vec = Vec::with_capacity(5);
/// vec.resize(5, 0);
/// assert_eq!(vec, [0, 0, 0, 0, 0]);
/// ```
///
/// Для отримання додаткової інформації див. [Capacity and Reallocation](#capacity-and-reallocation).
///
/// Використовуйте `Vec<T>` як ефективний стек:
///
/// ```
/// let mut stack = Vec::new();
///
/// stack.push(1);
/// stack.push(2);
/// stack.push(3);
///
/// while let Some(top) = stack.pop() {
///     // Відбитки 3, 2, 1
///     println!("{}", top);
/// }
/// ```
///
/// # Indexing
///
/// Тип `Vec` дозволяє отримувати доступ до значень за індексом, оскільки він реалізує [`Index`] Portrait.Приклад буде більш явним:
///
/// ```
/// let v = vec![0, 2, 4, 6];
/// println!("{}", v[1]); // він буде відображати '2'
/// ```
///
/// Однак будьте обережні: якщо ви спробуєте отримати доступ до індексу, якого немає в `Vec`, ваше програмне забезпечення буде panic!Ви не можете цього зробити:
///
/// ```should_panic
/// let v = vec![0, 2, 4, 6];
/// println!("{}", v[6]); // it will panic!
/// ```
///
/// Використовуйте [`get`] та [`get_mut`], якщо хочете перевірити, чи входить індекс в `Vec`.
///
/// # Slicing
///
/// `Vec` може бути змінним.З іншого боку, фрагменти-це об`єкти, доступні лише для читання.
/// Щоб отримати [slice][prim@slice], використовуйте [`&`].Приклад:
///
/// ```
/// fn read_slice(slice: &[usize]) {
///     // ...
/// }
///
/// let v = vec![0, 1];
/// read_slice(&v);
///
/// // ... і це все!
/// // Ви також можете зробити це так:
/// let u: &[usize] = &v;
/// // або ось так:
/// let u: &[_] = &v;
/// ```
///
/// У Rust частіше передавати фрагменти як аргументи, а не vectors, коли ви просто хочете надати доступ для читання.Те саме стосується [`String`] та [`&str`].
///
/// # Потужність та перерозподіл
///
/// Ємність vector-це кількість місця, виділеного для будь-яких елементів future, які будуть додані до vector.Цього не слід плутати з *довжиною* vector, яка визначає кількість фактичних елементів у vector.
/// Якщо довжина vector перевищує його ємність, її ємність буде автоматично збільшена, але її елементи доведеться перерозподілити.
///
/// Наприклад, vector ємністю 10 і довжиною 0 буде порожнім vector з місцем для ще 10 елементів.Натискання 10 або менше елементів на vector не призведе до зміни його ємності та не призведе до перерозподілу.
/// Однак, якщо довжину vector збільшити до 11, її доведеться перерозподілити, що може бути повільним.З цієї причини рекомендується використовувати [`Vec::with_capacity`] по можливості, щоб вказати, наскільки великим буде vector.
///
/// # Guarantees
///
/// Завдяки неймовірно фундаментальному характеру, `Vec` дає багато гарантій щодо свого дизайну.Це гарантує, що в загальному випадку це максимально низькі накладні витрати, і ним можна правильно керувати примітивними способами за допомогою небезпечного коду.Зверніть увагу, що ці гарантії стосуються некваліфікованого `Vec<T>`.
/// Якщо додаються додаткові параметри типу (наприклад, для підтримки користувацьких розподільників), перевизначення за замовчуванням може змінити поведінку.
///
/// Найголовніше, що `Vec` є і завжди буде триплетом (покажчик, ємність, довжина).Ні більше, ні менше.Порядок цих полів повністю не визначений, і ви повинні використовувати відповідні методи, щоб змінити їх.
/// Покажчик ніколи не буде нульовим, тому цей тип оптимізований для нульових покажчиків.
///
/// Однак вказівник може насправді не вказувати на виділену пам'ять.
/// Зокрема, якщо ви побудуєте `Vec` ємністю 0 через [`Vec::new`], [`vec![]`][`vec!`], [`Vec::with_capacity(0)`][`Vec::with_capacity`] або зателефонувавши [`shrink_to_fit`] на порожній Vec, він не виділить пам'ять.Подібним чином, якщо ви зберігаєте типи нульового розміру всередині `Vec`, він не виділить для них місця.
/// *Зверніть увагу, що в цьому випадку `Vec` може не повідомляти про [`capacity`] 0*.
/// `Vec` виділить тоді і тільки тоді, коли [`mem: : size_of::<T>`]`() * capacity()> 0`.
/// Загалом, деталі виділення `Vec` дуже тонкі-якщо ви маєте намір розподілити пам'ять за допомогою `Vec` і використовувати її для чогось іншого (або для переходу до небезпечного коду, або для створення власної колекції, підтримуваної пам'яттю), будьте впевнені звільнити цю пам'ять, використовуючи `from_raw_parts` для відновлення `Vec`, а потім скинувши його.
///
/// Якщо `Vec`*має* виділену пам'ять, тоді пам'ять, на яку він вказує, знаходиться в кучі (як визначено розподільником Rust налаштовано на використання за замовчуванням), а її вказівник вказує на ініціалізовані, суміжні елементи [`len`] (що ви подивіться, чи примусили ви його до фрагмента), за яким слідують [`ємність`]`,`[`len`] логічно неініціалізовані, суміжні елементи.
///
///
/// vector, що містить елементи `'a'` та `'b'` ємністю 4, можна візуалізувати, як показано нижче.Верхня частина-структура `Vec`, вона містить вказівник на головку розподілу в купі, довжину та місткість.
/// Нижня частина-це розподіл у купі, суміжний блок пам'яті.
///
/// ```text
///             ptr      len  capacity
///        +--------+--------+--------+
///        | 0x0123 |      2 |      4 |
///        +--------+--------+--------+
///             |
///             v
/// Heap   +--------+--------+--------+--------+
///        |    'a' |    'b' | uninit | uninit |
///        +--------+--------+--------+--------+
/// ```
///
/// - **uninit** представляє пам'ять, яка не ініціалізована, див. [`MaybeUninit`].
/// - Note: ABI не є стабільним, і `Vec` не дає жодних гарантій щодо розміщення своєї пам'яті (включаючи порядок полів).
///
/// `Vec` ніколи не буде виконувати "small optimization", де елементи насправді зберігаються в стеку з двох причин:
///
/// * Це би ускладнило небезпечний код правильного керування `Vec`.Вміст `Vec` не мав би стабільної адреси, якби його було лише переміщено, і було б складніше визначити, чи `Vec` насправді виділив пам'ять.
///
/// * Це покарає загальний випадок, спричиняючи додатковий branch при кожному доступі.
///
/// `Vec` ніколи не зменшиться автоматично, навіть якщо повністю порожній.Це гарантує відсутність зайвих розподілів чи звільнень.Спорожнення `Vec`, а потім заповнення його назад до того самого [`len`] не повинно викликати жодних викликів до розподільника.Якщо ви хочете звільнити невикористану пам`ять, використовуйте [`shrink_to_fit`] або [`shrink_to`].
///
/// [`push`] і [`insert`] ніколи (повторно) не розподілить, якщо повідомлена потужність є достатньою.[`push`] та [`insert`]* *(пере) розподілять, якщо [`len`]`==`[`ємність`].Тобто, звітна потужність є абсолютно точною, і на неї можна покластися.За бажанням його можна навіть звільнити пам`ять, виділену `Vec`, вручну.
/// Методи масової вставки *можуть* перерозподілити, навіть коли це не потрібно.
///
/// `Vec` не гарантує жодної конкретної стратегії зростання при перерозподілі, коли він повністю заповнений, а також коли не викликається [`reserve`].Поточна стратегія є базовою, і може виявитись бажаним використовувати не постійний фактор зростання.Яка б стратегія не використовувалася, звичайно, гарантуватиме *O*(1) амортизований [`push`].
///
/// `vec![x; n]`, `vec![a, b, c, d]` та [`Vec::with_capacity(n)`][`Vec::with_capacity`] вироблятимуть `Vec` із точно необхідною потужністю.
/// Якщо [`len`]`==`[`ємність`](як у випадку з макросом [`vec!`]), тоді `Vec<T>` можна перетворити в [`Box<[T]>`][owned slice] і з нього, не перерозподіляючи та не переміщуючи елементи.
///
/// `Vec` не буде спеціально перезаписувати будь-які дані, які з них видаляються, але також не буде спеціально їх зберігати.Його неініціалізована пам`ять-це подряпинний простір, який він може використовувати, як хоче.Як правило, він просто робить все, що є найбільш ефективним або іншим способом легким у реалізації.Не покладайтесь на видалені дані, які слід стерти в цілях безпеки.
/// Навіть якщо ви упустите `Vec`, його буфер може просто повторно використати інший `Vec`.
/// Навіть якщо спочатку ви обнулите пам'ять `Vec`, це насправді може не відбутися, оскільки оптимізатор не вважає це побічним ефектом, який потрібно зберегти.
/// Однак є один випадок, який ми не порушимо: використання коду `unsafe` для надмірної ємності, а потім збільшення довжини до відповідності завжди є дійсним.
///
/// В даний час `Vec` не гарантує порядок скидання елементів.
/// Порядок змінювався в минулому і може змінитися знову.
///
/// [`get`]: ../../std/vec/struct.Vec.html#method.get
/// [`get_mut`]: ../../std/vec/struct.Vec.html#method.get_mut
/// [`String`]: crate::string::String
/// [`&str`]: type@str
/// [`shrink_to_fit`]: Vec::shrink_to_fit
/// [`shrink_to`]: Vec::shrink_to
/// [`capacity`]: Vec::capacity
/// [`mem::size_of::<T>`]: core::mem::size_of
/// [`len`]: Vec::len
/// [`push`]: Vec::push
/// [`insert`]: Vec::insert
/// [`reserve`]: Vec::reserve
/// [`MaybeUninit`]: core::mem::MaybeUninit
/// [owned slice]: Box
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "vec_type")]
pub struct Vec<T, #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global> {
    buf: RawVec<T, A>,
    len: usize,
}

////////////////////////////////////////////////////////////////////////////////
// Притаманні методи
////////////////////////////////////////////////////////////////////////////////

impl<T> Vec<T> {
    /// Конструює новий, порожній `Vec<T>`.
    ///
    /// vector не буде розподіляти, поки на нього не будуть натиснуті елементи.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(unused_mut)]
    /// let mut vec: Vec<i32> = Vec::new();
    /// ```
    #[inline]
    #[rustc_const_stable(feature = "const_vec_new", since = "1.39.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> Self {
        Vec { buf: RawVec::NEW, len: 0 }
    }

    /// Конструює новий, порожній `Vec<T>` із заданою потужністю.
    ///
    /// vector зможе вмістити саме елементи `capacity` без перерозподілу.
    /// Якщо `capacity` дорівнює 0, vector не виділяє.
    ///
    /// Важливо зазначити, що хоча повернутий vector має вказану *місткість*, vector матиме нульову *довжину*.
    ///
    /// Пояснення щодо різниці між довжиною та місткістю див. У розділі *[Ємність та перерозподіл]*.
    ///
    /// [Capacity and reallocation]: #capacity-and-reallocation
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    ///
    /// // vector не містить предметів, навіть незважаючи на те, що він вміє більше
    /// assert_eq!(vec.len(), 0);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // Це все робиться без перерозподілу ...
    /// for i in 0..10 {
    ///     vec.push(i);
    /// }
    /// assert_eq!(vec.len(), 10);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // ... але це може зробити vector перерозподілом
    /// vec.push(11);
    /// assert_eq!(vec.len(), 11);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    #[inline]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// Створює `Vec<T>` безпосередньо з вихідних компонентів іншого vector.
    ///
    /// # Safety
    ///
    /// Це вкрай небезпечно через кількість інваріантів, які не перевіряються:
    ///
    /// * `ptr` потрібно було попередньо розподілити за допомогою [`String`]/`Vec<T>`(принаймні, з великою ймовірністю це буде неправильно, якщо не було).
    /// * `T` повинен мати такий самий розмір і вирівнювання, як і те, що було виділено для `ptr`.
    ///   (`T`, що має менш суворе вирівнювання, недостатньо, вирівнювання дійсно має бути рівним, щоб задовольнити вимогу [`dealloc`] про те, що пам'ять повинна виділятися і вивільнятися з однаковим розташуванням.)
    ///
    /// * `length` має бути меншим або рівним `capacity`.
    /// * `capacity` має бути місткістю, з якою був призначений вказівник.
    ///
    /// Порушення цих правил може спричинити такі проблеми, як пошкодження внутрішніх структур даних розподілювача.Наприклад,**не** безпечно будувати `Vec<u8>` із вказівника на масив C `char` довжиною `size_t`.
    /// Також не безпечно будувати такий із `Vec<u16>` та його довжини, оскільки розподільник дбає про вирівнювання, і ці два типи мають різне вирівнювання.
    /// Буфер був виділений з вирівнюванням 2 (для `u16`), але після перетворення його в `Vec<u8>` він буде звільнений з вирівнюванням 1.
    ///
    /// Право власності на `ptr` фактично передається `Vec<T>`, який може потім вивільнити, перерозподілити або змінити вміст пам'яті, на який вказує вказівник за бажанням.
    /// Переконайтеся, що ніщо інше не використовує вказівник після виклику цієї функції.
    ///
    /// [`String`]: crate::string::String
    /// [`dealloc`]: crate::alloc::GlobalAlloc::dealloc
    ///
    /// # Examples
    ///
    /// ```
    /// use std::ptr;
    /// use std::mem;
    ///
    /// let v = vec![1, 2, 3];
    ///
    ///     // FIXME Оновіть це, коли vec_into_raw_parts стабілізується.
    ///     // Запобігання запуску деструктора `v`, щоб ми повністю контролювали розподіл.
    /////
    /// let mut v = mem::ManuallyDrop::new(v);
    ///
    /// // Витягніть різні важливі відомості про `v`
    /// let p = v.as_mut_ptr();
    /// let len = v.len();
    /// let cap = v.capacity();
    ///
    /// unsafe {
    ///     // Перезапишіть пам`ять на 4, 5, 6
    ///     for i in 0..len as isize {
    ///         ptr::write(p.offset(i), 4 + i);
    ///     }
    ///
    ///     // Поєднайте все разом у Vec
    ///     let rebuilt = Vec::from_raw_parts(p, len, cap);
    ///     assert_eq!(rebuilt, [4, 5, 6]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_raw_parts(ptr: *mut T, length: usize, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, length, capacity, Global) }
    }
}

impl<T, A: Allocator> Vec<T, A> {
    /// Конструює новий, порожній `Vec<T, A>`.
    ///
    /// vector не буде розподіляти, поки на нього не будуть натиснуті елементи.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// # #[allow(unused_mut)]
    /// let mut vec: Vec<i32, _> = Vec::new_in(System);
    /// ```
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub const fn new_in(alloc: A) -> Self {
        Vec { buf: RawVec::new_in(alloc), len: 0 }
    }

    /// Конструює новий, порожній `Vec<T, A>` із заданою потужністю із наданим розподільником.
    ///
    /// vector зможе вмістити саме елементи `capacity` без перерозподілу.
    /// Якщо `capacity` дорівнює 0, vector не виділяє.
    ///
    /// Важливо зазначити, що хоча повернутий vector має вказану *місткість*, vector матиме нульову *довжину*.
    ///
    /// Пояснення щодо різниці між довжиною та місткістю див. У розділі *[Ємність та перерозподіл]*.
    ///
    /// [Capacity and reallocation]: #capacity-and-reallocation
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut vec = Vec::with_capacity_in(10, System);
    ///
    /// // vector не містить предметів, навіть незважаючи на те, що він вміє більше
    /// assert_eq!(vec.len(), 0);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // Це все робиться без перерозподілу ...
    /// for i in 0..10 {
    ///     vec.push(i);
    /// }
    /// assert_eq!(vec.len(), 10);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // ... але це може зробити vector перерозподілом
    /// vec.push(11);
    /// assert_eq!(vec.len(), 11);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Vec { buf: RawVec::with_capacity_in(capacity, alloc), len: 0 }
    }

    /// Створює `Vec<T, A>` безпосередньо з вихідних компонентів іншого vector.
    ///
    /// # Safety
    ///
    /// Це вкрай небезпечно через кількість інваріантів, які не перевіряються:
    ///
    /// * `ptr` потрібно було попередньо розподілити за допомогою [`String`]/`Vec<T>`(принаймні, з великою ймовірністю це буде неправильно, якщо не було).
    /// * `T` повинен мати такий самий розмір і вирівнювання, як і те, що було виділено для `ptr`.
    ///   (`T`, що має менш суворе вирівнювання, недостатньо, вирівнювання дійсно має бути рівним, щоб задовольнити вимогу [`dealloc`] про те, що пам'ять повинна виділятися і вивільнятися з однаковим розташуванням.)
    ///
    /// * `length` має бути меншим або рівним `capacity`.
    /// * `capacity` має бути місткістю, з якою був призначений вказівник.
    ///
    /// Порушення цих правил може спричинити такі проблеми, як пошкодження внутрішніх структур даних розподілювача.Наприклад,**не** безпечно будувати `Vec<u8>` із вказівника на масив C `char` довжиною `size_t`.
    /// Також не безпечно будувати такий із `Vec<u16>` та його довжини, оскільки розподільник дбає про вирівнювання, і ці два типи мають різне вирівнювання.
    /// Буфер був виділений з вирівнюванням 2 (для `u16`), але після перетворення його в `Vec<u8>` він буде звільнений з вирівнюванням 1.
    ///
    /// Право власності на `ptr` фактично передається `Vec<T>`, який може потім вивільнити, перерозподілити або змінити вміст пам'яті, на який вказує вказівник за бажанням.
    /// Переконайтеся, що ніщо інше не використовує вказівник після виклику цієї функції.
    ///
    /// [`String`]: crate::string::String
    /// [`dealloc`]: crate::alloc::GlobalAlloc::dealloc
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// use std::ptr;
    /// use std::mem;
    ///
    /// let mut v = Vec::with_capacity_in(3, System);
    /// v.push(1);
    /// v.push(2);
    /// v.push(3);
    ///
    ///     // FIXME Оновіть це, коли vec_into_raw_parts стабілізується.
    ///     // Запобігання запуску деструктора `v`, щоб ми повністю контролювали розподіл.
    /////
    /// let mut v = mem::ManuallyDrop::new(v);
    ///
    /// // Витягніть різні важливі відомості про `v`
    /// let p = v.as_mut_ptr();
    /// let len = v.len();
    /// let cap = v.capacity();
    /// let alloc = v.allocator();
    ///
    /// unsafe {
    ///     // Перезапишіть пам`ять на 4, 5, 6
    ///     for i in 0..len as isize {
    ///         ptr::write(p.offset(i), 4 + i);
    ///     }
    ///
    ///     // Поєднайте все разом у Vec
    ///     let rebuilt = Vec::from_raw_parts_in(p, len, cap, alloc.clone());
    ///     assert_eq!(rebuilt, [4, 5, 6]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, length: usize, capacity: usize, alloc: A) -> Self {
        unsafe { Vec { buf: RawVec::from_raw_parts_in(ptr, capacity, alloc), len: length } }
    }

    /// Розкладає `Vec<T>` на вихідні компоненти.
    ///
    /// Повертає вихідний вказівник на базові дані, довжину vector (у елементах) та виділену ємність даних (у елементах).
    /// Це ті самі аргументи в тому самому порядку, що і аргументи [`from_raw_parts`].
    ///
    /// Після виклику цієї функції абонент відповідає за пам'ять, якою раніше керував `Vec`.
    /// Єдиний спосіб зробити це-перетворити вихідний вказівник, довжину та ємність назад у `Vec` за допомогою функції [`from_raw_parts`], що дозволяє деструктору виконувати очищення.
    ///
    ///
    /// [`from_raw_parts`]: Vec::from_raw_parts
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_into_raw_parts)]
    /// let v: Vec<i32> = vec![-1, 0, 1];
    ///
    /// let (ptr, len, cap) = v.into_raw_parts();
    ///
    /// let rebuilt = unsafe {
    ///     // Тепер ми можемо вносити зміни до компонентів, наприклад, перетворювати вихідний вказівник на сумісний тип.
    /////
    ///     let ptr = ptr as *mut u32;
    ///
    ///     Vec::from_raw_parts(ptr, len, cap)
    /// };
    /// assert_eq!(rebuilt, [4294967295, 0, 1]);
    /// ```
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts(self) -> (*mut T, usize, usize) {
        let mut me = ManuallyDrop::new(self);
        (me.as_mut_ptr(), me.len(), me.capacity())
    }

    /// Розкладає `Vec<T>` на вихідні компоненти.
    ///
    /// Повертає вихідний вказівник на базові дані, довжину vector (у елементах), виділену ємність даних (у елементах) та розподільник.
    /// Це ті самі аргументи в тому самому порядку, що і аргументи [`from_raw_parts_in`].
    ///
    /// Після виклику цієї функції абонент відповідає за пам'ять, якою раніше керував `Vec`.
    /// Єдиний спосіб зробити це-перетворити вихідний вказівник, довжину та ємність назад у `Vec` за допомогою функції [`from_raw_parts_in`], що дозволяє деструктору виконувати очищення.
    ///
    ///
    /// [`from_raw_parts_in`]: Vec::from_raw_parts_in
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, vec_into_raw_parts)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut v: Vec<i32, System> = Vec::new_in(System);
    /// v.push(-1);
    /// v.push(0);
    /// v.push(1);
    ///
    /// let (ptr, len, cap, alloc) = v.into_raw_parts_with_alloc();
    ///
    /// let rebuilt = unsafe {
    ///     // Тепер ми можемо вносити зміни до компонентів, наприклад, перетворювати вихідний вказівник на сумісний тип.
    /////
    ///     let ptr = ptr as *mut u32;
    ///
    ///     Vec::from_raw_parts_in(ptr, len, cap, alloc)
    /// };
    /// assert_eq!(rebuilt, [4294967295, 0, 1]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts_with_alloc(self) -> (*mut T, usize, usize, A) {
        let mut me = ManuallyDrop::new(self);
        let len = me.len();
        let capacity = me.capacity();
        let ptr = me.as_mut_ptr();
        let alloc = unsafe { ptr::read(me.allocator()) };
        (ptr, len, capacity, alloc)
    }

    /// Повертає кількість елементів, яку може містити vector без перерозподілу.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let vec: Vec<i32> = Vec::with_capacity(10);
    /// assert_eq!(vec.capacity(), 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.buf.capacity()
    }

    /// Резервує ємність щонайменше для `additional` більше елементів, які потрібно вставити в даний `Vec<T>`.
    /// Колекція може зарезервувати більше місця, щоб уникнути частих перерозподілів.
    /// Після виклику `reserve` ємність буде більшою або дорівнює `self.len() + additional`.
    /// Нічого не робить, якщо потужності вже достатньо.
    ///
    /// # Panics
    ///
    /// Panics, якщо нова ємність перевищує `isize::MAX` байт.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.reserve(10);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.buf.reserve(self.len, additional);
    }

    /// Резервує мінімальну ємність для рівно `additional` більше елементів, які потрібно вставити в даний `Vec<T>`.
    ///
    /// Після виклику `reserve_exact` ємність буде більшою або дорівнює `self.len() + additional`.
    /// Нічого не робить, якщо потужності вже достатньо.
    ///
    /// Зверніть увагу, що розподільник може надати колекції більше місця, ніж вимагає.
    /// Тому на потужність не можна покладатися як мінімально.
    /// Віддайте перевагу `reserve`, якщо очікується вставка future.
    ///
    /// # Panics
    ///
    /// Panics, якщо нова потужність перевищує `usize`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.reserve_exact(10);
    /// assert!(vec.capacity() >= 11);
    /// ```
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.buf.reserve_exact(self.len, additional);
    }

    /// Намагається зарезервувати ємність щонайменше для `additional` більше елементів, які потрібно вставити в даний `Vec<T>`.
    /// Колекція може зарезервувати більше місця, щоб уникнути частих перерозподілів.
    /// Після виклику `try_reserve` ємність буде більшою або дорівнює `self.len() + additional`.
    /// Нічого не робить, якщо потужності вже достатньо.
    ///
    /// # Errors
    ///
    /// Якщо ємність переповнюється або розподілювач повідомляє про несправність, помилка повертається.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &[u32]) -> Result<Vec<u32>, TryReserveError> {
    ///     let mut output = Vec::new();
    ///
    ///     // Попередньо зарезервуйте пам'ять, виходячи, якщо ми не можемо
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Тепер ми знаємо, що це не може OOM в середині нашої складної роботи
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // дуже складно
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[doc(alias = "realloc")]
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.buf.try_reserve(self.len, additional)
    }

    /// Намагається зарезервувати мінімальну ємність саме для елементів `additional`, які потрібно вставити в даний `Vec<T>`.
    /// Після виклику `try_reserve_exact` ємність буде більшою або дорівнює `self.len() + additional`, якщо вона повертає `Ok(())`.
    ///
    /// Нічого не робить, якщо потужності вже достатньо.
    ///
    /// Зверніть увагу, що розподільник може надати колекції більше місця, ніж вимагає.
    /// Тому на потужність не можна покладатися як мінімально.
    /// Віддайте перевагу `reserve`, якщо очікується вставка future.
    ///
    /// # Errors
    ///
    /// Якщо ємність переповнюється або розподілювач повідомляє про несправність, помилка повертається.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &[u32]) -> Result<Vec<u32>, TryReserveError> {
    ///     let mut output = Vec::new();
    ///
    ///     // Попередньо зарезервуйте пам'ять, виходячи, якщо ми не можемо
    ///     output.try_reserve_exact(data.len())?;
    ///
    ///     // Тепер ми знаємо, що це не може OOM в середині нашої складної роботи
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // дуже складно
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[doc(alias = "realloc")]
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.buf.try_reserve_exact(self.len, additional)
    }

    /// Максимально зменшує ємність vector.
    ///
    /// Він знизиться якомога ближче до довжини, але розподільник все одно може повідомити vector, що є місце ще для кількох елементів.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    /// assert_eq!(vec.capacity(), 10);
    /// vec.shrink_to_fit();
    /// assert!(vec.capacity() >= 3);
    /// ```
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        // Ємність ніколи не менша за довжину, і нічого робити, коли вони рівні, тому ми можемо уникнути випадку panic у `RawVec::shrink_to_fit`, лише викликавши його з більшою ємністю.
        //
        //
        if self.capacity() > self.len {
            self.buf.shrink_to_fit(self.len);
        }
    }

    /// Зменшує ємність vector з нижньою межею.
    ///
    /// Ємність залишатиметься принаймні такою ж, як довжина, так і вартість, що постачається.
    ///
    ///
    /// Якщо поточна потужність менше нижньої межі, це заборона.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    /// assert_eq!(vec.capacity(), 10);
    /// vec.shrink_to(4);
    /// assert!(vec.capacity() >= 4);
    /// vec.shrink_to(0);
    /// assert!(vec.capacity() >= 3);
    /// ```
    #[doc(alias = "realloc")]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        if self.capacity() > min_capacity {
            self.buf.shrink_to_fit(cmp::max(self.len, min_capacity));
        }
    }

    /// Перетворює vector у [`Box<[T]>`][owned slice].
    ///
    /// Зверніть увагу, що це призведе до зниження надлишкової потужності.
    ///
    /// [owned slice]: Box
    ///
    /// # Examples
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    ///
    /// let slice = v.into_boxed_slice();
    /// ```
    ///
    /// Будь-яка надмірна потужність видаляється:
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    ///
    /// assert_eq!(vec.capacity(), 10);
    /// let slice = vec.into_boxed_slice();
    /// assert_eq!(slice.into_vec().capacity(), 3);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_boxed_slice(mut self) -> Box<[T], A> {
        unsafe {
            self.shrink_to_fit();
            let me = ManuallyDrop::new(self);
            let buf = ptr::read(&me.buf);
            let len = me.len();
            buf.into_box(len).assume_init()
        }
    }

    /// Скорочує vector, зберігаючи перші елементи `len`, а решту скидає.
    ///
    /// Якщо `len` більше поточної довжини vector, це не впливає.
    ///
    /// Метод [`drain`] може емулювати `truncate`, але призводить до повернення зайвих елементів замість скидання.
    ///
    ///
    /// Зверніть увагу, що цей метод не впливає на виділену ємність vector.
    ///
    /// # Examples
    ///
    /// Зрізання п'яти елемента vector до двох елементів:
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4, 5];
    /// vec.truncate(2);
    /// assert_eq!(vec, [1, 2]);
    /// ```
    ///
    /// Відсікання не відбувається, коли `len` перевищує поточну довжину vector:
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.truncate(8);
    /// assert_eq!(vec, [1, 2, 3]);
    /// ```
    ///
    /// Зрізання, коли `len == 0` еквівалентно виклику методу [`clear`].
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.truncate(0);
    /// assert_eq!(vec, []);
    /// ```
    ///
    /// [`clear`]: Vec::clear
    /// [`drain`]: Vec::drain
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn truncate(&mut self, len: usize) {
        // Це безпечно, оскільки:
        //
        // * зріз, переданий `drop_in_place`, є дійсним;справа `len > self.len` дозволяє уникнути створення недійсного фрагмента, а
        // * `len` vector стискається перед викликом `drop_in_place`, так що жодне значення не буде скидатися двічі, якщо `drop_in_place` один раз перейде до panic (якщо це panics двічі, програма переривається).
        //
        //
        //
        unsafe {
            // Note: Це навмисно, що це `>`, а не `>=`.
            //       Зміна його на `>=` у деяких випадках негативно впливає на продуктивність.
            //       Докладніше див. У розділі #78884.
            if len > self.len {
                return;
            }
            let remaining_len = self.len - len;
            let s = ptr::slice_from_raw_parts_mut(self.as_mut_ptr().add(len), remaining_len);
            self.len = len;
            ptr::drop_in_place(s);
        }
    }

    /// Витягує фрагмент, що містить весь vector.
    ///
    /// Еквівалентно `&s[..]`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::io::{self, Write};
    /// let buffer = vec![1, 2, 3, 5, 8];
    /// io::sink().write(buffer.as_slice()).unwrap();
    /// ```
    #[inline]
    #[stable(feature = "vec_as_slice", since = "1.7.0")]
    pub fn as_slice(&self) -> &[T] {
        self
    }

    /// Витягує змінний фрагмент цілого vector.
    ///
    /// Еквівалентно `&mut s[..]`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::io::{self, Read};
    /// let mut buffer = vec![0; 3];
    /// io::repeat(0b101).read_exact(buffer.as_mut_slice()).unwrap();
    /// ```
    #[inline]
    #[stable(feature = "vec_as_slice", since = "1.7.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        self
    }

    /// Повертає необроблений вказівник на буфер vector.
    ///
    /// Абонент повинен переконатися, що vector пережив покажчик, який ця функція повертає, інакше він в кінцевому підсумку вказуватиме на сміття.
    /// Модифікація vector може призвести до перерозподілу його буфера, що також зробить недійсними будь-які вказівники на нього.
    ///
    /// Абонент також повинен переконатися, що пам'ять, на яку вказує вказівник (non-transitively), ніколи не записується (за винятком усередині `UnsafeCell`) за допомогою цього вказівника або будь-якого вказівника, похідного від нього.
    /// Якщо вам потрібно змінити вміст фрагмента, використовуйте [`as_mut_ptr`].
    ///
    /// # Examples
    ///
    /// ```
    /// let x = vec![1, 2, 4];
    /// let x_ptr = x.as_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         assert_eq!(*x_ptr.add(i), 1 << i);
    ///     }
    /// }
    /// ```
    ///
    /// [`as_mut_ptr`]: Vec::as_mut_ptr
    ///
    ///
    ///
    #[stable(feature = "vec_as_ptr", since = "1.37.0")]
    #[inline]
    pub fn as_ptr(&self) -> *const T {
        // Ми затінюємо однойменний метод зрізу, щоб уникнути переходу через `deref`, що створює проміжне посилання.
        //
        let ptr = self.buf.ptr();
        unsafe {
            assume(!ptr.is_null());
        }
        ptr
    }

    /// Повертає небезпечний змінний покажчик на буфер vector.
    ///
    /// Абонент повинен переконатися, що vector пережив покажчик, який ця функція повертає, інакше він в кінцевому підсумку вказуватиме на сміття.
    ///
    /// Модифікація vector може призвести до перерозподілу його буфера, що також зробить недійсними будь-які вказівники на нього.
    ///
    /// # Examples
    ///
    /// ```
    /// // Виділіть vector досить великий для 4 елементів.
    /// let size = 4;
    /// let mut x: Vec<i32> = Vec::with_capacity(size);
    /// let x_ptr = x.as_mut_ptr();
    ///
    /// // Ініціалізуйте елементи за допомогою сирого запису вказівника, потім встановіть довжину.
    /// unsafe {
    ///     for i in 0..size {
    ///         *x_ptr.add(i) = i as i32;
    ///     }
    ///     x.set_len(size);
    /// }
    /// assert_eq!(&*x, &[0, 1, 2, 3]);
    /// ```
    ///
    #[stable(feature = "vec_as_ptr", since = "1.37.0")]
    #[inline]
    pub fn as_mut_ptr(&mut self) -> *mut T {
        // Ми затінюємо однойменний метод зрізу, щоб уникнути переходу через `deref_mut`, що створює проміжне посилання.
        //
        let ptr = self.buf.ptr();
        unsafe {
            assume(!ptr.is_null());
        }
        ptr
    }

    /// Повертає посилання на базовий розподільник.
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn allocator(&self) -> &A {
        self.buf.allocator()
    }

    /// Примушує довжину vector до `new_len`.
    ///
    /// Це операція низького рівня, яка не підтримує жодного нормального інваріанта типу.
    /// Зазвичай зміна довжини vector виконується за допомогою однієї із безпечних операцій, наприклад, [`truncate`], [`resize`], [`extend`] або [`clear`].
    ///
    ///
    /// [`truncate`]: Vec::truncate
    /// [`resize`]: Vec::resize
    /// [`extend`]: Extend::extend
    /// [`clear`]: Vec::clear
    ///
    /// # Safety
    ///
    /// - `new_len` має бути меншим або рівним [`capacity()`].
    /// - Елементи в `old_len..new_len` повинні бути ініціалізовані.
    ///
    /// [`capacity()`]: Vec::capacity
    ///
    /// # Examples
    ///
    /// Цей метод може бути корисним у ситуаціях, коли vector служить буфером для іншого коду, особливо через FFI:
    ///
    /// ```no_run
    /// # #![allow(dead_code)]
    /// # // Це лише мінімальний скелет для прикладу документа;
    /// # // не використовуйте це як вихідну точку для справжньої бібліотеки.
    /// # pub struct StreamWrapper { strm: *mut std::ffi::c_void }
    /// # const Z_OK: i32 = 0;
    /// # extern "C" {
    /// #     fn deflateGetDictionary(
    /// #         strm: *mut std::ffi::c_void,
    /// #         dictionary: *mut u8,
    /// #         dictLength: *mut usize,
    /// #     ) -> i32;
    /// # }
    /// # impl StreamWrapper {
    /// pub fn get_dictionary(&self) -> Option<Vec<u8>> {
    ///     // Відповідно до документів методу FFI, "32768 bytes is always enough".
    ///     let mut dict = Vec::with_capacity(32_768);
    ///     let mut dict_length = 0;
    ///     // БЕЗПЕКА: Коли `deflateGetDictionary` повертає `Z_OK`, це означає, що:
    ///     // 1. `dict_length` елементи були ініціалізовані.
    ///     // 2.
    ///     // `dict_length` <=ємність (32_768), що робить `set_len` безпечним для виклику.
    ///     unsafe {
    ///         // Зробіть виклик FFI ...
    ///         let r = deflateGetDictionary(self.strm, dict.as_mut_ptr(), &mut dict_length);
    ///         if r == Z_OK {
    ///             // ... і оновіть довжину до ініціалізованої.
    ///             dict.set_len(dict_length);
    ///             Some(dict)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    /// # }
    /// ```
    ///
    /// Незважаючи на те, що наступний приклад є звуковим, є витік пам'яті, оскільки внутрішні vectors не звільнялися до виклику `set_len`:
    ///
    /// ```
    /// let mut vec = vec![vec![1, 0, 0],
    ///                    vec![0, 1, 0],
    ///                    vec![0, 0, 1]];
    /// // SAFETY:
    /// // 1. `old_len..0` є порожнім, тому не потрібно ініціалізувати елементи.
    /// // 2. `0 <= capacity` завжди тримає все, що є `capacity`.
    /// unsafe {
    ///     vec.set_len(0);
    /// }
    /// ```
    ///
    /// Зазвичай тут замість цього слід використовувати [`clear`], щоб правильно скинути вміст і, таким чином, не втратити пам'ять.
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn set_len(&mut self, new_len: usize) {
        debug_assert!(new_len <= self.capacity());

        self.len = new_len;
    }

    /// Видаляє елемент із vector і повертає його.
    ///
    /// Видалений елемент замінюється останнім елементом vector.
    ///
    /// Це не зберігає замовлення, але є O(1).
    ///
    /// # Panics
    ///
    /// Panics, якщо `index` поза межами.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec!["foo", "bar", "baz", "qux"];
    ///
    /// assert_eq!(v.swap_remove(1), "bar");
    /// assert_eq!(v, ["foo", "qux", "baz"]);
    ///
    /// assert_eq!(v.swap_remove(0), "foo");
    /// assert_eq!(v, ["baz", "qux"]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn swap_remove(&mut self, index: usize) -> T {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("swap_remove index (is {}) should be < len (is {})", index, len);
        }

        let len = self.len();
        if index >= len {
            assert_failed(index, len);
        }
        unsafe {
            // Ми замінюємо self [index] останнім елементом.
            // Зверніть увагу, що якщо перевірка меж вище виконана, повинен бути останній елемент (який може бути власним [index]).
            //
            let last = ptr::read(self.as_ptr().add(len - 1));
            let hole = self.as_mut_ptr().add(index);
            self.set_len(len - 1);
            ptr::replace(hole, last)
        }
    }

    /// Вставляє елемент у позицію `index` усередині vector, зсуваючи всі елементи після нього вправо.
    ///
    ///
    /// # Panics
    ///
    /// Panics, якщо `index > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.insert(1, 4);
    /// assert_eq!(vec, [1, 4, 2, 3]);
    /// vec.insert(4, 5);
    /// assert_eq!(vec, [1, 4, 2, 3, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn insert(&mut self, index: usize, element: T) {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("insertion index (is {}) should be <= len (is {})", index, len);
        }

        let len = self.len();
        if index > len {
            assert_failed(index, len);
        }

        // місце для нового елемента
        if len == self.buf.capacity() {
            self.reserve(1);
        }

        unsafe {
            // безпомилкове Місце, щоб поставити нове значення
            //
            {
                let p = self.as_mut_ptr().add(index);
                // Перекладіть все, щоб звільнити місце.
                // (Дублювання елемента `index` на два місця поспіль.)
                ptr::copy(p, p.offset(1), len - index);
                // Запишіть це, переписавши першу копію елемента `index`.
                //
                ptr::write(p, element);
            }
            self.set_len(len + 1);
        }
    }

    /// Видаляє та повертає елемент у положенні `index` в межах vector, зсуваючи всі елементи після нього вліво.
    ///
    ///
    /// # Panics
    ///
    /// Panics, якщо `index` поза межами.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// assert_eq!(v.remove(1), 2);
    /// assert_eq!(v, [1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, index: usize) -> T {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("removal index (is {}) should be < len (is {})", index, len);
        }

        let len = self.len();
        if index >= len {
            assert_failed(index, len);
        }
        unsafe {
            // infallible
            let ret;
            {
                // місце, з якого ми беремо.
                let ptr = self.as_mut_ptr().add(index);
                // скопіюйте його, небезпечно маючи одночасно копію значення у стеку та в vector.
                //
                ret = ptr::read(ptr);

                // Змістіть все вниз, щоб заповнити це місце.
                ptr::copy(ptr.offset(1), ptr, len - index - 1);
            }
            self.set_len(len - 1);
            ret
        }
    }

    /// Зберігає лише елементи, визначені предикатом.
    ///
    /// Іншими словами, видаліть усі елементи `e` так, щоб `f(&e)` повертав `false`.
    /// Цей метод діє на місці, відвідуючи кожен елемент рівно один раз у вихідному порядку, і зберігає порядок збережених елементів.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4];
    /// vec.retain(|&x| x % 2 == 0);
    /// assert_eq!(vec, [2, 4]);
    /// ```
    ///
    /// Оскільки елементи відвідуються рівно один раз у вихідному порядку, зовнішній стан може бути використаний для вирішення, які елементи зберігати.
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4, 5];
    /// let keep = [false, true, true, false, true];
    /// let mut iter = keep.iter();
    /// vec.retain(|_| *iter.next().unwrap());
    /// assert_eq!(vec, [2, 3, 5]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> bool,
    {
        let original_len = self.len();
        // Уникайте подвійного падіння, якщо захисний кожух не виконаний, оскільки ми можемо зробити деякі отвори під час процесу.
        //
        unsafe { self.set_len(0) };

        // Vec: [Kept, Kept, Hole, Hole, Hole, Hole, Unchecked, Unchecked]
        //      | <-оброблений len-> |^-поруч із перевіркою
        //                  | <-видалено cnt-> |
        //      | <-оригінал_лен-> |Зберігається: Елементи, яким предикат повертає true.
        //
        // Отвір: Переміщений або скинутий отвір елемента.
        // Не позначено: Не перевірено дійсні елементи.
        //
        // Цей захист від падіння буде викликаний, коли предикат або `drop` елемента запанікують.
        // Він зміщує неперевірені елементи для покриття отворів та `set_len` на потрібну довжину.
        // У випадках, коли предикат і `drop` ніколи не панікують, це буде оптимізовано.
        struct BackshiftOnDrop<'a, T, A: Allocator> {
            v: &'a mut Vec<T, A>,
            processed_len: usize,
            deleted_cnt: usize,
            original_len: usize,
        }

        impl<T, A: Allocator> Drop for BackshiftOnDrop<'_, T, A> {
            fn drop(&mut self) {
                if self.deleted_cnt > 0 {
                    // БЕЗПЕКА: Відстежувані непозначені елементи повинні бути дійсними, оскільки ми ніколи не торкаємось їх.
                    unsafe {
                        ptr::copy(
                            self.v.as_ptr().add(self.processed_len),
                            self.v.as_mut_ptr().add(self.processed_len - self.deleted_cnt),
                            self.original_len - self.processed_len,
                        );
                    }
                }
                // БЕЗПЕКА: Після заповнення отворів усі предмети знаходяться в суміжній пам'яті.
                unsafe {
                    self.v.set_len(self.original_len - self.deleted_cnt);
                }
            }
        }

        let mut g = BackshiftOnDrop { v: self, processed_len: 0, deleted_cnt: 0, original_len };

        while g.processed_len < original_len {
            // БЕЗПЕКА: Не позначений елемент повинен бути дійсним.
            let cur = unsafe { &mut *g.v.as_mut_ptr().add(g.processed_len) };
            if !f(cur) {
                // Просувайтесь рано, щоб уникнути подвійного падіння, якщо `drop_in_place` запанікує.
                g.processed_len += 1;
                g.deleted_cnt += 1;
                // БЕЗПЕКА: Ми ніколи більше не торкаємось цього елемента після падіння.
                unsafe { ptr::drop_in_place(cur) };
                // Ми вже вдосконалили лічильник.
                continue;
            }
            if g.deleted_cnt > 0 {
                // БЕЗПЕКА: `deleted_cnt`> 0, тому отвір для отвору не повинен перекриватися поточним елементом.
                // Ми використовуємо копію для переміщення і більше ніколи не торкаємось цього елемента.
                unsafe {
                    let hole_slot = g.v.as_mut_ptr().add(g.processed_len - g.deleted_cnt);
                    ptr::copy_nonoverlapping(cur, hole_slot, 1);
                }
            }
            g.processed_len += 1;
        }

        // Всі деталі обробляються.Це може бути оптимізовано до рівня `set_len` за допомогою LLVM.
        drop(g);
    }

    /// Видаляє всі послідовні елементи, крім першого, у vector, які вирішують той самий ключ.
    ///
    ///
    /// Якщо vector відсортовано, це видаляє всі дублікати.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![10, 20, 21, 30, 20];
    ///
    /// vec.dedup_by_key(|i| *i / 10);
    ///
    /// assert_eq!(vec, [10, 20, 30, 20]);
    /// ```
    #[stable(feature = "dedup_by", since = "1.16.0")]
    #[inline]
    pub fn dedup_by_key<F, K>(&mut self, mut key: F)
    where
        F: FnMut(&mut T) -> K,
        K: PartialEq,
    {
        self.dedup_by(|a, b| key(a) == key(b))
    }

    /// Видаляє всі послідовні елементи, крім першого, у vector, що задовольняють заданому відношенню рівності.
    ///
    /// Функція `same_bucket` передає посилання на два елементи із vector і повинна визначити, чи порівнюються елементи рівними.
    /// Елементи передаються в порядку, протилежному порядку, указаному в зрізі, тому, якщо `same_bucket(a, b)` повертає `true`, `a` видаляється.
    ///
    ///
    /// Якщо vector відсортовано, це видаляє всі дублікати.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec!["foo", "bar", "Bar", "baz", "bar"];
    ///
    /// vec.dedup_by(|a, b| a.eq_ignore_ascii_case(b));
    ///
    /// assert_eq!(vec, ["foo", "bar", "baz", "bar"]);
    /// ```
    ///
    #[stable(feature = "dedup_by", since = "1.16.0")]
    pub fn dedup_by<F>(&mut self, mut same_bucket: F)
    where
        F: FnMut(&mut T, &mut T) -> bool,
    {
        let len = self.len();
        if len <= 1 {
            return;
        }

        /* INVARIANT: vec.len() > read >= write > write-1 >= 0 */
        struct FillGapOnDrop<'a, T, A: core::alloc::Allocator> {
            /* Offset of the element we want to check if it is duplicate */
            read: usize,

            /* Offset of the place where we want to place the non-duplicate
             * when we find it. */
            write: usize,

            /* The Vec that would need correction if `same_bucket` panicked */
            vec: &'a mut Vec<T, A>,
        }

        impl<'a, T, A: core::alloc::Allocator> Drop for FillGapOnDrop<'a, T, A> {
            fn drop(&mut self) {
                /* This code gets executed when `same_bucket` panics */

                /* SAFETY: invariant guarantees that `read - write`
                 * and `len - read` never overflow and that the copy is always
                 * in-bounds. */
                unsafe {
                    let ptr = self.vec.as_mut_ptr();
                    let len = self.vec.len();

                    /* How many items were left when `same_bucket` paniced.
                     * Basically vec[read..].len() */
                    let items_left = len.wrapping_sub(self.read);

                    /* Pointer to first item in vec[write..write+items_left] slice */
                    let dropped_ptr = ptr.add(self.write);
                    /* Pointer to first item in vec[read..] slice */
                    let valid_ptr = ptr.add(self.read);

                    /* Copy `vec[read..]` to `vec[write..write+items_left]`.
                     * The slices can overlap, so `copy_nonoverlapping` cannot be used */
                    ptr::copy(valid_ptr, dropped_ptr, items_left);

                    /* How many items have been already dropped
                     * Basically vec[read..write].len() */
                    let dropped = self.read.wrapping_sub(self.write);

                    self.vec.set_len(len - dropped);
                }
            }
        }

        let mut gap = FillGapOnDrop { read: 1, write: 1, vec: self };
        let ptr = gap.vec.as_mut_ptr();

        /* Drop items while going through Vec, it should be more efficient than
         * doing slice partition_dedup + truncate */

        /* SAFETY: Because of the invariant, read_ptr, prev_ptr and write_ptr
         * are always in-bounds and read_ptr never aliases prev_ptr */
        unsafe {
            while gap.read < len {
                let read_ptr = ptr.add(gap.read);
                let prev_ptr = ptr.add(gap.write.wrapping_sub(1));

                if same_bucket(&mut *read_ptr, &mut *prev_ptr) {
                    /* We have found duplicate, drop it in-place */
                    ptr::drop_in_place(read_ptr);
                } else {
                    let write_ptr = ptr.add(gap.write);

                    /* Because `read_ptr` can be equal to `write_ptr`, we either
                     * have to use `copy` or conditional `copy_nonoverlapping`.
                     * Looks like the first option is faster. */
                    ptr::copy(read_ptr, write_ptr, 1);

                    /* We have filled that place, so go further */
                    gap.write += 1;
                }

                gap.read += 1;
            }

            /* Technically we could let `gap` clean up with its Drop, but
             * when `same_bucket` is guaranteed to not panic, this bloats a little
             * the codegen, so we just do it manually */
            gap.vec.set_len(gap.write);
            mem::forget(gap);
        }
    }

    /// Додає елемент до задньої частини колекції.
    ///
    /// # Panics
    ///
    /// Panics, якщо нова ємність перевищує `isize::MAX` байт.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2];
    /// vec.push(3);
    /// assert_eq!(vec, [1, 2, 3]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, value: T) {
        // Це призведе до panic або скасування, якщо ми виділимо> isize::MAX байт або якщо збільшення довжини перевищить для нульових типів.
        //
        if self.len == self.buf.capacity() {
            self.reserve(1);
        }
        unsafe {
            let end = self.as_mut_ptr().add(self.len);
            ptr::write(end, value);
            self.len += 1;
        }
    }

    /// Видаляє останній елемент із vector і повертає його, або [`None`], якщо він порожній.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// assert_eq!(vec.pop(), Some(3));
    /// assert_eq!(vec, [1, 2]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<T> {
        if self.len == 0 {
            None
        } else {
            unsafe {
                self.len -= 1;
                Some(ptr::read(self.as_ptr().add(self.len())))
            }
        }
    }

    /// Переміщує всі елементи `other` у `Self`, залишаючи `other` порожнім.
    ///
    /// # Panics
    ///
    /// Panics, якщо кількість елементів у vector перевищує `usize`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// let mut vec2 = vec![4, 5, 6];
    /// vec.append(&mut vec2);
    /// assert_eq!(vec, [1, 2, 3, 4, 5, 6]);
    /// assert_eq!(vec2, []);
    /// ```
    #[inline]
    #[stable(feature = "append", since = "1.4.0")]
    pub fn append(&mut self, other: &mut Self) {
        unsafe {
            self.append_elements(other.as_slice() as _);
            other.set_len(0);
        }
    }

    /// Додає елементи до `Self` з іншого буфера.
    #[inline]
    unsafe fn append_elements(&mut self, other: *const [T]) {
        let count = unsafe { (*other).len() };
        self.reserve(count);
        let len = self.len();
        unsafe { ptr::copy_nonoverlapping(other as *const T, self.as_mut_ptr().add(len), count) };
        self.len += count;
    }

    /// Створює дренажний ітератор, який видаляє вказаний діапазон у vector і видає вилучені елементи.
    ///
    /// Коли ітератор **опускається**, усі елементи в діапазоні видаляються з vector, навіть якщо ітератор був використаний не повністю.
    /// Якщо ітератор **не скидається**(наприклад, з [`mem::forget`]), не вказано, скільки елементів буде видалено.
    ///
    /// # Panics
    ///
    /// Panics, якщо початкова точка більша за кінцеву точку або якщо кінцева точка більша за довжину vector.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// let u: Vec<_> = v.drain(1..).collect();
    /// assert_eq!(v, &[1]);
    /// assert_eq!(u, &[2, 3]);
    ///
    /// // Повний асортимент очищає vector
    /// v.drain(..);
    /// assert_eq!(v, &[]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_, T, A>
    where
        R: RangeBounds<usize>,
    {
        // Безпека пам`яті
        //
        // Коли Drain створюється вперше, це скорочує довжину вихідного vector, щоб переконатися, що відсутні неініціалізовані або переміщені елементи взагалі, якщо деструктор Drain ніколи не запускається.
        //
        //
        // Drain видасть ptr::read значення для видалення.
        // По закінченні залишковий хвіст века копіюється назад, щоб закрити отвір, і довжина vector відновлюється до нової довжини.
        //
        //
        //
        let len = self.len();
        let Range { start, end } = slice::range(range, ..len);

        unsafe {
            // встановіть довжину self.vec для початку, щоб бути безпечним у випадку витоку Drain
            self.set_len(start);
            // Використовуйте запозичення в IterMut, щоб вказати поведінку запозичення всього ітератора Drain (як &mut T).
            //
            let range_slice = slice::from_raw_parts_mut(self.as_mut_ptr().add(start), end - start);
            Drain {
                tail_start: end,
                tail_len: len - end,
                iter: range_slice.iter(),
                vec: NonNull::from(self),
            }
        }
    }

    /// Очищає vector, видаляючи всі значення.
    ///
    /// Зверніть увагу, що цей метод не впливає на виділену ємність vector.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    ///
    /// v.clear();
    ///
    /// assert!(v.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.truncate(0)
    }

    /// Повертає кількість елементів у vector, який також називають його 'length'.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = vec![1, 2, 3];
    /// assert_eq!(a.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.len
    }

    /// Повертає `true`, якщо vector не містить елементів.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = Vec::new();
    /// assert!(v.is_empty());
    ///
    /// v.push(1);
    /// assert!(!v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Розбиває колекцію на дві частини за вказаним індексом.
    ///
    /// Повертає нещодавно виділений vector, що містить елементи в діапазоні `[at, len)`.
    /// Після виклику залишиться оригінальний vector, що містить елементи `[0, at)` з попередньою ємністю без змін.
    ///
    ///
    /// # Panics
    ///
    /// Panics, якщо `at > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// let vec2 = vec.split_off(1);
    /// assert_eq!(vec, [1]);
    /// assert_eq!(vec2, [2, 3]);
    /// ```
    #[inline]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    #[stable(feature = "split_off", since = "1.4.0")]
    pub fn split_off(&mut self, at: usize) -> Self
    where
        A: Clone,
    {
        #[cold]
        #[inline(never)]
        fn assert_failed(at: usize, len: usize) -> ! {
            panic!("`at` split index (is {}) should be <= len (is {})", at, len);
        }

        if at > self.len() {
            assert_failed(at, self.len());
        }

        if at == 0 {
            // новий vector може взяти на себе оригінальний буфер і уникнути копіювання
            return mem::replace(
                self,
                Vec::with_capacity_in(self.capacity(), self.allocator().clone()),
            );
        }

        let other_len = self.len - at;
        let mut other = Vec::with_capacity_in(other_len, self.allocator().clone());

        // Небезпечно `set_len` і копіюйте елементи в `other`.
        unsafe {
            self.set_len(at);
            other.set_len(other_len);

            ptr::copy_nonoverlapping(self.as_ptr().add(at), other.as_mut_ptr(), other.len());
        }
        other
    }

    /// Змінює розмір `Vec` на місці, так що `len` дорівнює `new_len`.
    ///
    /// Якщо `new_len` більше, ніж `len`, `Vec` збільшується на різницю, при цьому кожен додатковий слот заповнюється результатом виклику закриття `f`.
    ///
    /// Повернені значення з `f` опиняться в `Vec` у тому порядку, в якому вони були створені.
    ///
    /// Якщо `new_len` менше `len`, `Vec` просто усікається.
    ///
    /// Цей метод використовує закриття для створення нових значень при кожному натисканні.Якщо ви віддаєте перевагу [`Clone`] із заданим значенням, використовуйте [`Vec::resize`].
    /// Якщо ви хочете використовувати [`Default`] Portrait для генерації значень, ви можете передати [`Default::default`] як другий аргумент.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.resize_with(5, Default::default);
    /// assert_eq!(vec, [1, 2, 3, 0, 0]);
    ///
    /// let mut vec = vec![];
    /// let mut p = 1;
    /// vec.resize_with(4, || { p *= 2; p });
    /// assert_eq!(vec, [2, 4, 8, 16]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "vec_resize_with", since = "1.33.0")]
    pub fn resize_with<F>(&mut self, new_len: usize, f: F)
    where
        F: FnMut() -> T,
    {
        let len = self.len();
        if new_len > len {
            self.extend_with(new_len - len, ExtendFunc(f));
        } else {
            self.truncate(new_len);
        }
    }

    /// Споживає та витікає `Vec`, повертаючи змінне посилання на вміст, `&'a mut [T]`.
    /// Зверніть увагу, що тип `T` повинен пережити вибраний термін служби `'a`.
    /// Якщо тип має лише статичні посилання або взагалі жодного, тоді це може бути обрано `'static`.
    ///
    /// Ця функція подібна до функції [`leak`][Box::leak] на [`Box`], за винятком того, що немає можливості відновити витік пам'яті.
    ///
    ///
    /// Ця функція в основному корисна для даних, які живуть до кінця життя програми.
    /// Видалення поверненого посилання призведе до витоку пам'яті.
    ///
    /// # Examples
    ///
    /// Просте використання:
    ///
    /// ```
    /// let x = vec![1, 2, 3];
    /// let static_ref: &'static mut [usize] = x.leak();
    /// static_ref[0] += 1;
    /// assert_eq!(static_ref, &[2, 2, 3]);
    /// ```
    ///
    ///
    #[stable(feature = "vec_leak", since = "1.47.0")]
    #[inline]
    pub fn leak<'a>(self) -> &'a mut [T]
    where
        A: 'a,
    {
        Box::leak(self.into_boxed_slice())
    }

    /// Повертає залишок вільної ємності vector як фрагмент `MaybeUninit<T>`.
    ///
    /// Повернутий зріз можна використовувати для заповнення vector даними (наприклад,
    /// читанням із файлу) перед позначенням даних як ініціалізованих методом [`set_len`].
    ///
    ///
    /// [`set_len`]: Vec::set_len
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_spare_capacity, maybe_uninit_extra)]
    ///
    /// // Виділіть vector досить великий для 10 елементів.
    /// let mut v = Vec::with_capacity(10);
    ///
    /// // Заповніть перші 3 елементи.
    /// let uninit = v.spare_capacity_mut();
    /// uninit[0].write(0);
    /// uninit[1].write(1);
    /// uninit[2].write(2);
    ///
    /// // Позначте перші 3 елементи vector як ініціалізовані.
    /// unsafe {
    ///     v.set_len(3);
    /// }
    ///
    /// assert_eq!(&v, &[0, 1, 2]);
    /// ```
    ///
    #[unstable(feature = "vec_spare_capacity", issue = "75017")]
    #[inline]
    pub fn spare_capacity_mut(&mut self) -> &mut [MaybeUninit<T>] {
        // Note:
        // Цей метод не реалізований з точки зору `split_at_spare_mut`, щоб запобігти недійсності покажчиків на буфер.
        //
        unsafe {
            slice::from_raw_parts_mut(
                self.as_mut_ptr().add(self.len) as *mut MaybeUninit<T>,
                self.buf.capacity() - self.len,
            )
        }
    }

    /// Повертає вміст vector як фрагмент `T`, а також решту вільної ємності vector як фрагмент `MaybeUninit<T>`.
    ///
    /// Повернутий зріз вільної ємності можна використовувати для заповнення vector даними (наприклад, читанням із файлу) перед тим, як позначити дані як ініціалізовані методом [`set_len`].
    ///
    /// [`set_len`]: Vec::set_len
    ///
    /// Зверніть увагу, що це API низького рівня, який слід обережно використовувати для оптимізації.
    /// Якщо вам потрібно додати дані до `Vec`, ви можете використовувати [`push`], [`extend`], [`extend_from_slice`], [`extend_from_within`], [`insert`], [`append`], [`resize`] або [`resize_with`], залежно від ваших точних потреб.
    ///
    ///
    /// [`push`]: Vec::push
    /// [`extend`]: Vec::extend
    /// [`extend_from_slice`]: Vec::extend_from_slice
    /// [`extend_from_within`]: Vec::extend_from_within
    /// [`insert`]: Vec::insert
    /// [`append`]: Vec::append
    /// [`resize`]: Vec::resize
    /// [`resize_with`]: Vec::resize_with
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_split_at_spare, maybe_uninit_extra)]
    ///
    /// let mut v = vec![1, 1, 2];
    ///
    /// // Зарезервуйте додатковий простір, достатній для 10 елементів.
    /// v.reserve(10);
    ///
    /// let (init, uninit) = v.split_at_spare_mut();
    /// let sum = init.iter().copied().sum::<u32>();
    ///
    /// // Заповніть наступні 4 елементи.
    /// uninit[0].write(sum);
    /// uninit[1].write(sum * 2);
    /// uninit[2].write(sum * 3);
    /// uninit[3].write(sum * 4);
    ///
    /// // Позначте 4 елементи vector як ініціалізовані.
    /// unsafe {
    ///     let len = v.len();
    ///     v.set_len(len + 4);
    /// }
    ///
    /// assert_eq!(&v, &[1, 1, 2, 4, 8, 12, 16]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_split_at_spare", issue = "81944")]
    #[inline]
    pub fn split_at_spare_mut(&mut self) -> (&mut [T], &mut [MaybeUninit<T>]) {
        // SAFETY:
        // - len ігнорується і тому ніколи не змінюється
        let (init, spare, _) = unsafe { self.split_at_spare_mut_with_len() };
        (init, spare)
    }

    /// Безпека: зміна поверненого .2 (&mut usize) вважається таким самим, як виклик `.set_len(_)`.
    ///
    /// Цей метод використовується для отримання унікального доступу до всіх частин vec одночасно в `extend_from_within`.
    unsafe fn split_at_spare_mut_with_len(
        &mut self,
    ) -> (&mut [T], &mut [MaybeUninit<T>], &mut usize) {
        let Range { start: ptr, end: spare_ptr } = self.as_mut_ptr_range();
        let spare_ptr = spare_ptr.cast::<MaybeUninit<T>>();
        let spare_len = self.buf.capacity() - self.len;

        // SAFETY:
        // - `ptr` гарантовано діє для елементів `len`
        // - `spare_ptr` спрямовує один елемент повз буфер, тому він не перекривається з `initialized`
        unsafe {
            let initialized = slice::from_raw_parts_mut(ptr, self.len);
            let spare = slice::from_raw_parts_mut(spare_ptr, spare_len);

            (initialized, spare, &mut self.len)
        }
    }
}

impl<T: Clone, A: Allocator> Vec<T, A> {
    /// Змінює розмір `Vec` на місці, так що `len` дорівнює `new_len`.
    ///
    /// Якщо `new_len` більше, ніж `len`, `Vec` збільшується на різницю, при цьому кожен додатковий слот заповнюється `value`.
    ///
    /// Якщо `new_len` менше `len`, `Vec` просто усікається.
    ///
    /// Цей метод вимагає `T` для реалізації [`Clone`], щоб мати можливість клонувати передане значення.
    /// Якщо вам потрібна більша гнучкість (або ви хочете покластися на [`Default`] замість [`Clone`]), використовуйте [`Vec::resize_with`].
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec!["hello"];
    /// vec.resize(3, "world");
    /// assert_eq!(vec, ["hello", "world", "world"]);
    ///
    /// let mut vec = vec![1, 2, 3, 4];
    /// vec.resize(2, 0);
    /// assert_eq!(vec, [1, 2]);
    /// ```
    ///
    ///
    #[stable(feature = "vec_resize", since = "1.5.0")]
    pub fn resize(&mut self, new_len: usize, value: T) {
        let len = self.len();

        if new_len > len {
            self.extend_with(new_len - len, ExtendElement(value))
        } else {
            self.truncate(new_len);
        }
    }

    /// Клонує та додає всі елементи фрагмента до `Vec`.
    ///
    /// Взаємодіє над зрізом `other`, клонує кожен елемент, а потім додає його до цього `Vec`.
    /// `other` vector проходить по порядку.
    ///
    /// Зверніть увагу, що ця функція така ж, як і [`extend`], за винятком того, що вона спеціалізована для роботи із фрагментами.
    ///
    /// Якщо і коли Rust отримає спеціалізацію, ця функція, швидше за все, буде застарілою (але все ще доступною).
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.extend_from_slice(&[2, 3, 4]);
    /// assert_eq!(vec, [1, 2, 3, 4]);
    /// ```
    ///
    /// [`extend`]: Vec::extend
    ///
    #[stable(feature = "vec_extend_from_slice", since = "1.6.0")]
    pub fn extend_from_slice(&mut self, other: &[T]) {
        self.spec_extend(other.iter())
    }

    /// Копіює елементи від діапазону `src` до кінця vector.
    ///
    /// ## Examples
    ///
    /// ```
    /// #![feature(vec_extend_from_within)]
    ///
    /// let mut vec = vec![0, 1, 2, 3, 4];
    ///
    /// vec.extend_from_within(2..);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4]);
    ///
    /// vec.extend_from_within(..2);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4, 0, 1]);
    ///
    /// vec.extend_from_within(4..8);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4, 0, 1, 4, 2, 3, 4]);
    /// ```
    #[unstable(feature = "vec_extend_from_within", issue = "81656")]
    pub fn extend_from_within<R>(&mut self, src: R)
    where
        R: RangeBounds<usize>,
    {
        let range = slice::range(src, ..self.len());
        self.reserve(range.len());

        // SAFETY:
        // - `slice::range` гарантує, що даний діапазон є дійсним для самоіндексації
        unsafe {
            self.spec_extend_from_within(range);
        }
    }
}

// Цей код узагальнює `extend_with_{element,default}`.
trait ExtendWith<T> {
    fn next(&mut self) -> T;
    fn last(self) -> T;
}

struct ExtendElement<T>(T);
impl<T: Clone> ExtendWith<T> for ExtendElement<T> {
    fn next(&mut self) -> T {
        self.0.clone()
    }
    fn last(self) -> T {
        self.0
    }
}

struct ExtendDefault;
impl<T: Default> ExtendWith<T> for ExtendDefault {
    fn next(&mut self) -> T {
        Default::default()
    }
    fn last(self) -> T {
        Default::default()
    }
}

struct ExtendFunc<F>(F);
impl<T, F: FnMut() -> T> ExtendWith<T> for ExtendFunc<F> {
    fn next(&mut self) -> T {
        (self.0)()
    }
    fn last(mut self) -> T {
        (self.0)()
    }
}

impl<T, A: Allocator> Vec<T, A> {
    /// Розширте vector на значення `n`, використовуючи заданий генератор.
    fn extend_with<E: ExtendWith<T>>(&mut self, n: usize, mut value: E) {
        self.reserve(n);

        unsafe {
            let mut ptr = self.as_mut_ptr().add(self.len());
            // Використовуйте SetLenOnDrop, щоб усунути помилку, де компілятор може не реалізувати сховище від `ptr` до self.set_len(), не псевдонім.
            //
            //
            let mut local_len = SetLenOnDrop::new(&mut self.len);

            // Запишіть усі елементи, крім останнього
            for _ in 1..n {
                ptr::write(ptr, value.next());
                ptr = ptr.offset(1);
                // Збільшуйте довжину на кожному кроці у випадку, якщо next() panics
                local_len.increment_len(1);
            }

            if n > 0 {
                // Ми можемо написати останній елемент безпосередньо, не клонуючи без потреби
                ptr::write(ptr, value.last());
                local_len.increment_len(1);
            }

            // len встановлений охоронцем розмаху
        }
    }
}

impl<T: PartialEq, A: Allocator> Vec<T, A> {
    /// Видаляє послідовні повторювані елементи в vector відповідно до реалізації [`PartialEq`] Portrait.
    ///
    ///
    /// Якщо vector відсортовано, це видаляє всі дублікати.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 2, 3, 2];
    ///
    /// vec.dedup();
    ///
    /// assert_eq!(vec, [1, 2, 3, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn dedup(&mut self) {
        self.dedup_by(|a, b| a == b)
    }
}

////////////////////////////////////////////////////////////////////////////////
// Внутрішні методи та функції
////////////////////////////////////////////////////////////////////////////////

#[doc(hidden)]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_elem<T: Clone>(elem: T, n: usize) -> Vec<T> {
    <T as SpecFromElem>::from_elem(elem, n, Global)
}

#[doc(hidden)]
#[unstable(feature = "allocator_api", issue = "32838")]
pub fn from_elem_in<T: Clone, A: Allocator>(elem: T, n: usize, alloc: A) -> Vec<T, A> {
    <T as SpecFromElem>::from_elem(elem, n, alloc)
}

trait ExtendFromWithinSpec {
    /// # Safety
    ///
    /// - `src` повинен мати дійсний індекс
    /// - `self.capacity() - self.len()` має бути `>= src.len()`
    unsafe fn spec_extend_from_within(&mut self, src: Range<usize>);
}

impl<T: Clone, A: Allocator> ExtendFromWithinSpec for Vec<T, A> {
    default unsafe fn spec_extend_from_within(&mut self, src: Range<usize>) {
        // SAFETY:
        // - len збільшується лише після ініціалізації елементів
        let (this, spare, len) = unsafe { self.split_at_spare_mut_with_len() };

        // SAFETY:
        // - абонент гарантує, що src є дійсним індексом
        let to_clone = unsafe { this.get_unchecked(src) };

        to_clone
            .iter()
            .cloned()
            .zip(spare.iter_mut())
            .map(|(src, dst)| dst.write(src))
            // Note:
            // - Елемент щойно було ініціалізовано за допомогою `MaybeUninit::write`, тому нормально збільшувати його
            // - len збільшується після кожного елемента, щоб запобігти витоку (див. випуск #82533)
            .for_each(|_| *len += 1);
    }
}

impl<T: Copy, A: Allocator> ExtendFromWithinSpec for Vec<T, A> {
    unsafe fn spec_extend_from_within(&mut self, src: Range<usize>) {
        let count = src.len();
        {
            let (init, spare) = self.split_at_spare_mut();

            // SAFETY:
            // - абонент гарантує, що `src` є дійсним індексом
            let source = unsafe { init.get_unchecked(src) };

            // SAFETY:
            // - Обидва покажчики створені з унікальних посилань на фрагменти (`&mut [_]`), тому вони є дійсними та не перекриваються.
            //
            // - Елементи: Копіювати, тому можна копіювати їх, не роблячи нічого з оригінальними значеннями
            // - `count` дорівнює об'єктиву `source`, тому джерело дійсне для читання `count`
            // - `.reserve(count)` гарантує, що `spare.len() >= count`, настільки запасний, діє для записів `count`
            //
            //
            //
            unsafe { ptr::copy_nonoverlapping(source.as_ptr(), spare.as_mut_ptr() as _, count) };
        }

        // SAFETY:
        // - Елементи щойно ініціалізовані `copy_nonoverlapping`
        self.len += count;
    }
}

////////////////////////////////////////////////////////////////////////////////
// Поширені реалізації Portrait для Vec
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> ops::Deref for Vec<T, A> {
    type Target = [T];

    fn deref(&self) -> &[T] {
        unsafe { slice::from_raw_parts(self.as_ptr(), self.len) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> ops::DerefMut for Vec<T, A> {
    fn deref_mut(&mut self) -> &mut [T] {
        unsafe { slice::from_raw_parts_mut(self.as_mut_ptr(), self.len) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone, A: Allocator + Clone> Clone for Vec<T, A> {
    #[cfg(not(test))]
    fn clone(&self) -> Self {
        let alloc = self.allocator().clone();
        <[T]>::to_vec_in(&**self, alloc)
    }

    // HACK(japaric): для cfg(test) властивий метод `[T]::to_vec`, необхідний для визначення цього методу, недоступний.
    // Натомість використовуйте функцію `slice::to_vec`, яка доступна лише з cfg(test) NB, див. Модуль slice::hack у slice.rs для отримання додаткової інформації
    //
    //
    #[cfg(test)]
    fn clone(&self) -> Self {
        let alloc = self.allocator().clone();
        crate::slice::to_vec(&**self, alloc)
    }

    fn clone_from(&mut self, other: &Self) {
        // скиньте все, що не буде перезаписано
        self.truncate(other.len());

        // self.len <= other.len через усікання вище, тому фрагменти тут завжди знаходяться в межах.
        //
        let (init, tail) = other.split_at(self.len());

        // повторно використати містяться значення allocations/resources.
        self.clone_from_slice(init);
        self.extend_from_slice(tail);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Hash, A: Allocator> Hash for Vec<T, A> {
    #[inline]
    fn hash<H: Hasher>(&self, state: &mut H) {
        Hash::hash(&**self, state)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "vector indices are of type `usize` or ranges of `usize`",
    label = "vector indices are of type `usize` or ranges of `usize`"
)]
impl<T, I: SliceIndex<[T]>, A: Allocator> Index<I> for Vec<T, A> {
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &Self::Output {
        Index::index(&**self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "vector indices are of type `usize` or ranges of `usize`",
    label = "vector indices are of type `usize` or ranges of `usize`"
)]
impl<T, I: SliceIndex<[T]>, A: Allocator> IndexMut<I> for Vec<T, A> {
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut Self::Output {
        IndexMut::index_mut(&mut **self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> FromIterator<T> for Vec<T> {
    #[inline]
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> Vec<T> {
        <Self as SpecFromIter<T, I::IntoIter>>::from_iter(iter.into_iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> IntoIterator for Vec<T, A> {
    type Item = T;
    type IntoIter = IntoIter<T, A>;

    /// Створює споживаючий ітератор, тобто такий, який переміщує кожне значення з vector (від початку до кінця).
    /// vector не можна використовувати після цього.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = vec!["a".to_string(), "b".to_string()];
    /// for s in v.into_iter() {
    ///     // s має тип String, а не &String
    ///     println!("{}", s);
    /// }
    /// ```
    ///
    #[inline]
    fn into_iter(self) -> IntoIter<T, A> {
        unsafe {
            let mut me = ManuallyDrop::new(self);
            let alloc = ptr::read(me.allocator());
            let begin = me.as_mut_ptr();
            let end = if mem::size_of::<T>() == 0 {
                arith_offset(begin as *const i8, me.len() as isize) as *const T
            } else {
                begin.add(me.len()) as *const T
            };
            let cap = me.buf.capacity();
            IntoIter {
                buf: NonNull::new_unchecked(begin),
                phantom: PhantomData,
                cap,
                alloc,
                ptr: begin,
                end,
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, A: Allocator> IntoIterator for &'a Vec<T, A> {
    type Item = &'a T;
    type IntoIter = slice::Iter<'a, T>;

    fn into_iter(self) -> slice::Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, A: Allocator> IntoIterator for &'a mut Vec<T, A> {
    type Item = &'a mut T;
    type IntoIter = slice::IterMut<'a, T>;

    fn into_iter(self) -> slice::IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> Extend<T> for Vec<T, A> {
    #[inline]
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        <Self as SpecExtend<T, I::IntoIter>>::spec_extend(self, iter.into_iter())
    }

    #[inline]
    fn extend_one(&mut self, item: T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

impl<T, A: Allocator> Vec<T, A> {
    // leaf метод, до якого різні впровадження SpecFrom/SpecExtend делегують, коли вони не потребують подальшої оптимізації
    //
    fn extend_desugared<I: Iterator<Item = T>>(&mut self, mut iterator: I) {
        // Це стосується загального ітератора.
        //
        // Ця функція повинна бути моральним еквівалентом:
        //
        //      для елемента в ітераторі {
        //          self.push(item);
        //      }
        while let Some(element) = iterator.next() {
            let len = self.len();
            if len == self.capacity() {
                let (lower, _) = iterator.size_hint();
                self.reserve(lower.saturating_add(1));
            }
            unsafe {
                ptr::write(self.as_mut_ptr().add(len), element);
                // NB не може переповнюватися, оскільки нам довелося б виділити адресний простір
                self.set_len(len + 1);
            }
        }
    }

    /// Створює ітератор зрощування, який замінює вказаний діапазон у vector даним ітератором `replace_with` і видає видалені елементи.
    ///
    /// `replace_with` не повинна бути такою ж довжиною, як `range`.
    ///
    /// `range` видаляється, навіть якщо ітератор не використовується до кінця.
    ///
    /// Не вказано, скільки елементів буде видалено з vector, якщо витікає значення `Splice`.
    ///
    /// Вхідний ітератор `replace_with` споживається лише тоді, коли значення `Splice` відкидається.
    ///
    /// Це оптимально, якщо:
    ///
    /// * Хвіст (елементи в vector після `range`) порожній,
    /// * або `replace_with` дає менше або рівних елементів, ніж довжина "діапазону"
    /// * або нижня межа його `size_hint()` є точною.
    ///
    /// В іншому випадку виділяється тимчасовий vector і хвіст переміщується двічі.
    ///
    /// # Panics
    ///
    /// Panics, якщо початкова точка більша за кінцеву точку або якщо кінцева точка більша за довжину vector.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// let new = [7, 8];
    /// let u: Vec<_> = v.splice(..2, new.iter().cloned()).collect();
    /// assert_eq!(v, &[7, 8, 3]);
    /// assert_eq!(u, &[1, 2]);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "vec_splice", since = "1.21.0")]
    pub fn splice<R, I>(&mut self, range: R, replace_with: I) -> Splice<'_, I::IntoIter, A>
    where
        R: RangeBounds<usize>,
        I: IntoIterator<Item = T>,
    {
        Splice { drain: self.drain(range), replace_with: replace_with.into_iter() }
    }

    /// Створює ітератор, який використовує закриття, щоб визначити, чи слід вилучати елемент.
    ///
    /// Якщо замикання повертає істину, тоді елемент видаляється і видається.
    /// Якщо закриття повертає значення false, елемент залишатиметься в vector і ітератор не видасть його.
    ///
    /// Використання цього методу еквівалентно наступному коду:
    ///
    /// ```
    /// # let some_predicate = |x: &mut i32| { *x == 2 || *x == 3 || *x == 6 };
    /// # let mut vec = vec![1, 2, 3, 4, 5, 6];
    /// let mut i = 0;
    /// while i != vec.len() {
    ///     if some_predicate(&mut vec[i]) {
    ///         let val = vec.remove(i);
    ///         // ваш код тут
    ///     } else {
    ///         i += 1;
    ///     }
    /// }
    ///
    /// # assert_eq!(vec, vec![1, 4, 5]);
    /// ```
    ///
    /// Але `drain_filter` простіший у використанні.
    /// `drain_filter` також є більш ефективним, оскільки він може здійснювати зворотний зсув елементів масиву навалом.
    ///
    /// Зауважте, що `drain_filter` також дозволяє мутувати кожен елемент у закритті фільтра, незалежно від того, ви вирішили його зберегти чи видалити.
    ///
    ///
    /// # Examples
    ///
    /// Розбиття масиву на рівні і шанси, повторне використання вихідного розподілу:
    ///
    /// ```
    /// #![feature(drain_filter)]
    /// let mut numbers = vec![1, 2, 3, 4, 5, 6, 8, 9, 11, 13, 14, 15];
    ///
    /// let evens = numbers.drain_filter(|x| *x % 2 == 0).collect::<Vec<_>>();
    /// let odds = numbers;
    ///
    /// assert_eq!(evens, vec![2, 4, 6, 8, 14]);
    /// assert_eq!(odds, vec![1, 3, 5, 9, 11, 13, 15]);
    /// ```
    ///
    #[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
    pub fn drain_filter<F>(&mut self, filter: F) -> DrainFilter<'_, T, F, A>
    where
        F: FnMut(&mut T) -> bool,
    {
        let old_len = self.len();

        // Захист від того, щоб ми не просочились (посилення витоку)
        unsafe {
            self.set_len(0);
        }

        DrainFilter { vec: self, idx: 0, del: 0, old_len, pred: filter, panic_flag: false }
    }
}

/// Розширте реалізацію, яка копіює елементи з посилань, перш ніж надсилати їх на Vec.
///
/// Ця реалізація спеціалізується на ітераторах зрізів, де вона використовує [`copy_from_slice`] для додавання всього зрізу одночасно.
///
///
/// [`copy_from_slice`]: slice::copy_from_slice
#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: Copy + 'a, A: Allocator + 'a> Extend<&'a T> for Vec<T, A> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.spec_extend(iter.into_iter())
    }

    #[inline]
    fn extend_one(&mut self, &item: &'a T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

/// Реалізує порівняння vectors, [lexicographically](core::cmp::Ord#lexicographical-comparison).
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialOrd, A: Allocator> PartialOrd for Vec<T, A> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        PartialOrd::partial_cmp(&**self, &**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Eq, A: Allocator> Eq for Vec<T, A> {}

/// Здійснює впорядкування vectors, [lexicographically](core::cmp::Ord#lexicographical-comparison).
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord, A: Allocator> Ord for Vec<T, A> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        Ord::cmp(&**self, &**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T, A: Allocator> Drop for Vec<T, A> {
    fn drop(&mut self) {
        unsafe {
            // використовувати падіння для [T] використовувати необроблений фрагмент для позначення елементів vector як найслабшого необхідного типу;
            //
            // може уникнути питань обґрунтованості в певних випадках
            ptr::drop_in_place(ptr::slice_from_raw_parts_mut(self.as_mut_ptr(), self.len))
        }
        // RawVec обробляє вивільнення
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for Vec<T> {
    /// Створює порожній `Vec<T>`.
    fn default() -> Vec<T> {
        Vec::new()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug, A: Allocator> fmt::Debug for Vec<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> AsRef<Vec<T, A>> for Vec<T, A> {
    fn as_ref(&self) -> &Vec<T, A> {
        self
    }
}

#[stable(feature = "vec_as_mut", since = "1.5.0")]
impl<T, A: Allocator> AsMut<Vec<T, A>> for Vec<T, A> {
    fn as_mut(&mut self) -> &mut Vec<T, A> {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> AsRef<[T]> for Vec<T, A> {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "vec_as_mut", since = "1.5.0")]
impl<T, A: Allocator> AsMut<[T]> for Vec<T, A> {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> From<&[T]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: &[T]) -> Vec<T> {
        s.to_vec()
    }
    #[cfg(test)]
    fn from(s: &[T]) -> Vec<T> {
        crate::slice::to_vec(s, Global)
    }
}

#[stable(feature = "vec_from_mut", since = "1.19.0")]
impl<T: Clone> From<&mut [T]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: &mut [T]) -> Vec<T> {
        s.to_vec()
    }
    #[cfg(test)]
    fn from(s: &mut [T]) -> Vec<T> {
        crate::slice::to_vec(s, Global)
    }
}

#[stable(feature = "vec_from_array", since = "1.44.0")]
impl<T, const N: usize> From<[T; N]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: [T; N]) -> Vec<T> {
        <[T]>::into_vec(box s)
    }
    #[cfg(test)]
    fn from(s: [T; N]) -> Vec<T> {
        crate::slice::into_vec(box s)
    }
}

#[stable(feature = "vec_from_cow_slice", since = "1.14.0")]
impl<'a, T> From<Cow<'a, [T]>> for Vec<T>
where
    [T]: ToOwned<Owned = Vec<T>>,
{
    fn from(s: Cow<'a, [T]>) -> Vec<T> {
        s.into_owned()
    }
}

// note: тест втягує libstd, що тут спричиняє помилки
#[cfg(not(test))]
#[stable(feature = "vec_from_box", since = "1.18.0")]
impl<T, A: Allocator> From<Box<[T], A>> for Vec<T, A> {
    fn from(s: Box<[T], A>) -> Self {
        let len = s.len();
        Self { buf: RawVec::from_box(s), len }
    }
}

// note: тест втягує libstd, що тут спричиняє помилки
#[cfg(not(test))]
#[stable(feature = "box_from_vec", since = "1.20.0")]
impl<T, A: Allocator> From<Vec<T, A>> for Box<[T], A> {
    fn from(v: Vec<T, A>) -> Self {
        v.into_boxed_slice()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl From<&str> for Vec<u8> {
    fn from(s: &str) -> Vec<u8> {
        From::from(s.as_bytes())
    }
}

#[stable(feature = "array_try_from_vec", since = "1.48.0")]
impl<T, A: Allocator, const N: usize> TryFrom<Vec<T, A>> for [T; N] {
    type Error = Vec<T, A>;

    /// Отримує весь вміст `Vec<T>` як масив, якщо його розмір точно відповідає розміру запитуваного масиву.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::convert::TryInto;
    /// assert_eq!(vec![1, 2, 3].try_into(), Ok([1, 2, 3]));
    /// assert_eq!(<Vec<i32>>::new().try_into(), Ok([]));
    /// ```
    ///
    /// Якщо довжина не збігається, вхід повертається в `Err`:
    ///
    /// ```
    /// use std::convert::TryInto;
    /// let r: Result<[i32; 4], _> = (0..10).collect::<Vec<_>>().try_into();
    /// assert_eq!(r, Err(vec![0, 1, 2, 3, 4, 5, 6, 7, 8, 9]));
    /// ```
    ///
    /// Якщо у вас все просто з отриманням префіксу `Vec<T>`, спочатку можна зателефонувати до [`.truncate(N)`](Vec::truncate).
    ///
    /// ```
    /// use std::convert::TryInto;
    /// let mut v = String::from("hello world").into_bytes();
    /// v.sort();
    /// v.truncate(2);
    /// let [a, b]: [_; 2] = v.try_into().unwrap();
    /// assert_eq!(a, b' ');
    /// assert_eq!(b, b'd');
    /// ```
    fn try_from(mut vec: Vec<T, A>) -> Result<[T; N], Vec<T, A>> {
        if vec.len() != N {
            return Err(vec);
        }

        // БЕЗПЕКА: `.set_len(0)`-це завжди звук.
        unsafe { vec.set_len(0) };

        // БЕЗПЕКА: вказівник `Vec` завжди правильно вирівняний, і
        // вирівнювання, необхідне масиву, таке саме, як і елементів.
        // Ми раніше перевіряли, чи маємо достатньо предметів.
        // Елементи не будуть падати подвійно, оскільки `set_len` говорить `Vec`, що їх також не слід скидати.
        //
        let array = unsafe { ptr::read(vec.as_ptr() as *const [T; N]) };
        Ok(array)
    }
}