// Встановіть довжину vec, коли значення `SetLenOnDrop` виходить за межі обсягу.
//
// Ідея полягає в тому, що: поле довжини в SetLenOnDrop-це локальна змінна, яку оптимізатор побачить, не псевдонім жодного сховища за допомогою вказівника даних Vec.
// Це вирішення проблеми аналізу псевдонімів #32155
//
pub(super) struct SetLenOnDrop<'a> {
    len: &'a mut usize,
    local_len: usize,
}

impl<'a> SetLenOnDrop<'a> {
    #[inline]
    pub(super) fn new(len: &'a mut usize) -> Self {
        SetLenOnDrop { local_len: *len, len }
    }

    #[inline]
    pub(super) fn increment_len(&mut self, increment: usize) {
        self.local_len += increment;
    }
}

impl Drop for SetLenOnDrop<'_> {
    #[inline]
    fn drop(&mut self) {
        *self.len = self.local_len;
    }
}