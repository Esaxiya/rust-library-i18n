use core::iter::TrustedLen;
use core::ptr::{self};

use super::{SpecExtend, Vec};

/// Інша спеціалізація Portrait для Vec::from_iter, необхідна для встановлення пріоритетів, що перекриваються, вручну, див. [`SpecFromIter`](super::SpecFromIter) для деталей.
///
///
pub(super) trait SpecFromIterNested<T, I> {
    fn from_iter(iter: I) -> Self;
}

impl<T, I> SpecFromIterNested<T, I> for Vec<T>
where
    I: Iterator<Item = T>,
{
    default fn from_iter(mut iterator: I) -> Self {
        // Розгорніть першу ітерацію, оскільки vector буде розширено на цій ітерації в кожному випадку, коли ітерація не є порожньою, але цикл у extend_desugared() не бачить, щоб vector був заповнений у кількох наступних ітераціях циклу.
        //
        // Тож ми отримуємо кращі прогнози branch.
        //
        //
        let mut vector = match iterator.next() {
            None => return Vec::new(),
            Some(element) => {
                let (lower, _) = iterator.size_hint();
                let mut vector = Vec::with_capacity(lower.saturating_add(1));
                unsafe {
                    ptr::write(vector.as_mut_ptr(), element);
                    vector.set_len(1);
                }
                vector
            }
        };
        // повинен делегувати spec_extend(), оскільки сам extend() делегує spec_from для порожнього Vecs
        //
        <Vec<T> as SpecExtend<T, I>>::spec_extend(&mut vector, iterator);
        vector
    }
}

impl<T, I> SpecFromIterNested<T, I> for Vec<T>
where
    I: TrustedLen<Item = T>,
{
    fn from_iter(iterator: I) -> Self {
        let mut vector = match iterator.size_hint() {
            (_, Some(upper)) => Vec::with_capacity(upper),
            _ => Vec::new(),
        };
        // повинен делегувати spec_extend(), оскільки сам extend() делегує spec_from для порожнього Vecs
        //
        vector.spec_extend(iterator);
        vector
    }
}