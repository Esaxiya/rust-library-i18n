use core::iter::{InPlaceIterable, SourceIter};
use core::mem::{self, ManuallyDrop};
use core::ptr::{self};

use super::{AsIntoIter, InPlaceDrop, SpecFromIter, SpecFromIterNested, Vec};

/// Маркер спеціалізації для збору конвеєра ітераторів у Vec при повторному використанні розподілу джерел, тобто
/// виконання трубопроводу на місці.
///
/// Батько SourceIter Portrait необхідний для спеціалізованої функції для доступу до розподілу, який слід використовувати повторно.
/// Але недостатньо, щоб спеціалізація була дійсною.
/// Див. Додаткові межі на імпл.
#[rustc_unsafe_specialization_marker]
pub(super) trait SourceIterMarker: SourceIter<Source: AsIntoIter> {}

// std-внутрішні SourceIter/InPlaceIterable traits реалізовані лише ланцюгами адаптера <Adapter<Adapter<IntoIter>>> (все належить core/std).
// Додаткові межі реалізації адаптера (за межами `impl<I: Trait> Trait for Adapter<I>`) залежать лише від інших traits, які вже позначені як спеціалізація traits (Copy, TrustedRandomAccess, FusedIterator).
//
// I.e. маркер не залежить від терміну служби типів, що надаються користувачем.Модуль діри для копіювання, від якої вже залежать кілька інших спеціалізацій.
//
//
impl<T> SourceIterMarker for T where T: SourceIter<Source: AsIntoIter> + InPlaceIterable {}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T> + SourceIterMarker,
{
    default fn from_iter(mut iterator: I) -> Self {
        // Додаткові вимоги, які неможливо виразити через Portrait bounds.Натомість ми покладаємося на const eval:
        // а) жодних ZST, оскільки не було б розподілу для повторного використання, а арифметика покажчика відповідала б panic b) збіг розміру відповідно до вимог контракту Alloc в) збіг вирівнювань відповідно до вимог контракту Alloc
        //
        //
        //
        if mem::size_of::<T>() == 0
            || mem::size_of::<T>()
                != mem::size_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
            || mem::align_of::<T>()
                != mem::align_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
        {
            // повернення до більш загальних реалізацій
            return SpecFromIterNested::from_iter(iterator);
        }

        let (src_buf, src_ptr, dst_buf, dst_end, cap) = unsafe {
            let inner = iterator.as_inner().as_into_iter();
            (
                inner.buf.as_ptr(),
                inner.ptr,
                inner.buf.as_ptr() as *mut T,
                inner.end as *const T,
                inner.cap,
            )
        };

        // використовувати спробу скласти з
        // - він векторизується краще для деяких адаптерів ітераторів
        // - на відміну від більшості методів внутрішньої ітерації, для цього потрібен лише &mut
        // - це дозволяє нам пропустити покажчик запису через його нутрощі і повернути його в кінці
        let sink = InPlaceDrop { inner: dst_buf, dst: dst_buf };
        let sink = iterator
            .try_fold::<_, _, Result<_, !>>(sink, write_in_place_with_drop(dst_end))
            .unwrap();
        // ітерація вдалася, не опускайте голову
        let dst = ManuallyDrop::new(sink).dst;

        let src = unsafe { iterator.as_inner().as_into_iter() };
        // перевірте, чи був підтриманий контракт SourceIter застереження: якщо вони не були, ми можемо навіть не дійти до цього моменту
        //
        debug_assert_eq!(src_buf, src.buf.as_ptr());
        // перевірити контракт InPlaceIterable.Це можливо лише в тому випадку, якщо ітератор взагалі розширив покажчик джерела.
        // Якщо він використовує неперевірений доступ через TrustedRandomAccess, тоді вказівник джерела залишатиметься у вихідному положенні, і ми не можемо використовувати його як посилання
        //
        if src.ptr != src_ptr {
            debug_assert!(
                dst as *const _ <= src.ptr,
                "InPlaceIterable contract violation, write pointer advanced beyond read pointer"
            );
        }

        // викинути будь-які залишилися значення в хвості джерела, але запобігти падінню самого розподілу, як тільки IntoIter вийде за межі області дії, якщо падіння panics, тоді ми також просочимо всі елементи, зібрані в dst_buf
        //
        //
        src.forget_allocation_drop_remaining();

        let vec = unsafe {
            let len = dst.offset_from(dst_buf) as usize;
            Vec::from_raw_parts(dst_buf, len, cap)
        };

        vec
    }
}

fn write_in_place_with_drop<T>(
    src_end: *const T,
) -> impl FnMut(InPlaceDrop<T>, T) -> Result<InPlaceDrop<T>, !> {
    move |mut sink, item| {
        unsafe {
            // контракт InPlaceIterable не може бути перевірений саме тут, оскільки try_fold має ексклюзивне посилання на вказівник джерела. Все, що ми можемо зробити, це перевірити, чи все ще він знаходиться в діапазоні
            //
            //
            debug_assert!(sink.dst as *const _ <= src_end, "InPlaceIterable contract violation");
            ptr::write(sink.dst, item);
            sink.dst = sink.dst.add(1);
        }
        Ok(sink)
    }
}