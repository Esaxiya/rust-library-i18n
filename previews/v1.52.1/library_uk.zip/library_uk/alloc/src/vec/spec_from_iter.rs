use core::mem::ManuallyDrop;
use core::ptr::{self};
use core::slice::{self};

use super::{IntoIter, SpecExtend, SpecFromIterNested, Vec};

/// Спеціалізація Portrait, що використовується для Vec::from_iter
///
/// ## Графік делегування:
///
/// ```text
/// +-------------+
/// |FromIterator |
/// +-+-----------+
///   |
///   v
/// +-+-------------------------------+  +---------------------+
/// |SpecFromIter                  +---->+SpecFromIterNested   |
/// |where I:                      |  |  |where I:             |
/// |  Iterator (default)----------+  |  |  Iterator (default) |
/// |  vec::IntoIter               |  |  |  TrustedLen         |
/// |  SourceIterMarker---fallback-+  |  |                     |
/// |  slice::Iter                    |  |                     |
/// |  Iterator<Item = &Clone>        |  +---------------------+
/// +---------------------------------+
/// ```
pub(super) trait SpecFromIter<T, I> {
    fn from_iter(iter: I) -> Self;
}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T>,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIterNested::from_iter(iterator)
    }
}

impl<T> SpecFromIter<T, IntoIter<T>> for Vec<T> {
    fn from_iter(iterator: IntoIter<T>) -> Self {
        // Поширеним випадком є передача vector у функцію, яка негайно повторно збирається у vector.
        // Ми можемо зробити коротке замикання, якщо IntoIter взагалі не вдосконалений.
        // Коли його вдосконалено, ми також можемо використовувати пам`ять повторно та переміщувати дані наперед.
        // Але ми робимо це лише тоді, коли отриманий Vec не матиме більше невикористаної ємності, ніж створення її за допомогою загальної реалізації FromIterator.
        //
        // Це обмеження не є суворо необхідним, оскільки поведінка розподілу Vec навмисно не визначена.
        // Але це консервативний вибір.
        //
        let has_advanced = iterator.buf.as_ptr() as *const _ != iterator.ptr;
        if !has_advanced || iterator.len() >= iterator.cap / 2 {
            unsafe {
                let it = ManuallyDrop::new(iterator);
                if has_advanced {
                    ptr::copy(it.ptr, it.buf.as_ptr(), it.len());
                }
                return Vec::from_raw_parts(it.buf.as_ptr(), it.len(), it.cap);
            }
        }

        let mut vec = Vec::new();
        // повинен делегувати spec_extend(), оскільки сам extend() делегує spec_from для порожнього Vecs
        //
        vec.spec_extend(iterator);
        vec
    }
}

impl<'a, T: 'a, I> SpecFromIter<&'a T, I> for Vec<T>
where
    I: Iterator<Item = &'a T>,
    T: Clone,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIter::from_iter(iterator.cloned())
    }
}

// Тут використовується `iterator.as_slice().to_vec()`, оскільки spec_extend повинен зробити більше кроків, щоб міркувати про остаточну ємність + довжину і, отже, зробити більше роботи.
// `to_vec()` безпосередньо розподіляє правильну суму та заповнює її точно.
//
//
impl<'a, T: 'a + Clone> SpecFromIter<&'a T, slice::Iter<'a, T>> for Vec<T> {
    #[cfg(not(test))]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        iterator.as_slice().to_vec()
    }

    // HACK(japaric): для cfg(test) властивий метод `[T]::to_vec`, необхідний для визначення цього методу, недоступний.
    // Натомість використовуйте функцію `slice::to_vec`, яка доступна лише з cfg(test) NB, див. Модуль slice::hack у slice.rs для отримання додаткової інформації
    //
    //
    #[cfg(test)]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        crate::slice::to_vec(iterator.as_slice(), crate::alloc::Global)
    }
}