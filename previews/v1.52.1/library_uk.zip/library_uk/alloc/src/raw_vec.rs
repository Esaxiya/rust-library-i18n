#![unstable(feature = "raw_vec_internals", reason = "implementation detail", issue = "none")]
#![doc(hidden)]

use core::alloc::LayoutError;
use core::cmp;
use core::intrinsics;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::Drop;
use core::ptr::{self, NonNull, Unique};
use core::slice;

use crate::alloc::{handle_alloc_error, Allocator, Global, Layout};
use crate::boxed::Box;
use crate::collections::TryReserveError::{self, *};

#[cfg(test)]
mod tests;

enum AllocInit {
    /// Вміст нової пам'яті неініціалізовано.
    Uninitialized,
    /// Нова пам`ять гарантовано буде обнулена.
    Zeroed,
}

/// Низькорівнева утиліта для більш ергономічного розподілу, перерозподілу та вивільнення буфера пам`яті в купі, не турбуючись про всі кутові випадки.
///
/// Цей тип чудово підходить для побудови власних структур даних, таких як Vec та VecDeque.
/// Зокрема:
///
/// * Випускає `Unique::dangling()` на нульових розмірах.
/// * Виробляє `Unique::dangling()` на розподілах нульової довжини.
/// * Уникає звільнення `Unique::dangling()`.
/// * Вловлює всі переповнення в обчисленнях ємності (підвищує їх до "capacity overflow" panics).
/// * Захист від 32-розрядних систем, що виділяють більше isize::MAX байт.
/// * Захищає від переповнення вашої довжини.
/// * Викликає `handle_alloc_error` для помилкових розподілів.
/// * Містить `ptr::Unique` і таким чином наділяє користувача всіма супутніми перевагами.
/// * Використовує надлишок, повернутий з розподільника, для використання найбільшої доступної потужності.
///
/// Цей тип у жодному разі не перевіряє пам'ять, якою він управляє.При падінні *звільнить* пам'ять, але *не* спробує скинути вміст.
/// Користувач `RawVec` повинен обробляти фактичні речі *, що зберігаються* всередині `RawVec`.
///
/// Зауважте, що надлишок типів нульового розміру завжди нескінченний, тому `capacity()` завжди повертає `usize::MAX`.
/// Це означає, що ви повинні бути обережними, коли обертаєте цей тип із `Box<[T]>`, оскільки `capacity()` не дасть довжини.
///
///
#[allow(missing_debug_implementations)]
pub struct RawVec<T, A: Allocator = Global> {
    ptr: Unique<T>,
    cap: usize,
    alloc: A,
}

impl<T> RawVec<T, Global> {
    /// HACK(Centril): Це існує, оскільки `#[unstable]` `const fn`s не повинні відповідати `min_const_fn`, тому їх також не можна викликати в`min_const_fn`s.
    ///
    /// Якщо ви змінюєте `RawVec<T>::new` або залежності, будьте обережні, щоб не вводити нічого, що справді порушує `min_const_fn`.
    ///
    /// NOTE: Ми могли б уникнути цього злому і перевірити відповідність з деяким атрибутом `#[rustc_force_min_const_fn]`, який вимагає відповідності з `min_const_fn`, але не обов'язково дозволяє викликати його в `stable(...) const fn`/код користувача, не включаючи `foo`, коли присутній `#[rustc_const_unstable(feature = "foo", issue = "01234")]`.
    ///
    ///
    ///
    ///
    ///
    ///
    pub const NEW: Self = Self::new();

    /// Створює найбільший можливий `RawVec` (у системній купі) без виділення.
    /// Якщо `T` має позитивний розмір, то це робить `RawVec` ємністю `0`.
    /// Якщо `T` нульового розміру, то це `RawVec` ємністю `usize::MAX`.
    /// Корисно для здійснення відкладеного розподілу.
    ///
    pub const fn new() -> Self {
        Self::new_in(Global)
    }

    /// Створює `RawVec` (у системній купі) з точно вимогами щодо місткості та вирівнювання для `[T; capacity]`.
    /// Це еквівалентно виклику `RawVec::new`, коли `capacity`-це `0` або `T`-нульового розміру.
    /// Зверніть увагу, що якщо `T` має нульовий розмір, це означає, що ви *не* отримаєте `RawVec` із необхідною ємністю.
    ///
    /// # Panics
    ///
    /// Panics, якщо запитувана ємність перевищує `isize::MAX` байт.
    ///
    /// # Aborts
    ///
    /// Аборти на OOM.
    ///
    ///
    #[inline]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// Як і `with_capacity`, але гарантує, що буфер обнулений.
    #[inline]
    pub fn with_capacity_zeroed(capacity: usize) -> Self {
        Self::with_capacity_zeroed_in(capacity, Global)
    }

    /// Відновлює `RawVec` з покажчика та ємності.
    ///
    /// # Safety
    ///
    /// `ptr` повинен бути виділений (у системній купі) та із заданим `capacity`.
    /// `capacity` не може перевищувати `isize::MAX` для великих типів.(це стосується лише 32-розрядних систем).
    /// ZST vectors може мати ємність до `usize::MAX`.
    /// Якщо `ptr` та `capacity` походять від `RawVec`, то це гарантовано.
    #[inline]
    pub unsafe fn from_raw_parts(ptr: *mut T, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, capacity, Global) }
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    // Крихітні Веки німі.Перейти до:
    // - 8, якщо розмір елемента дорівнює 1, оскільки будь-який розподілювач купи, швидше за все, округлює запит менше 8 байт щонайменше до 8 байт.
    //
    // - 4, якщо елементи мають помірний розмір (<=1 КіБ).
    // - 1 інакше, щоб уникнути втрати занадто багато місця для дуже коротких Vecs.
    const MIN_NON_ZERO_CAP: usize = if mem::size_of::<T>() == 1 {
        8
    } else if mem::size_of::<T>() <= 1024 {
        4
    } else {
        1
    };

    /// Як і `new`, але параметризований при виборі розподільника для повернутого `RawVec`.
    ///
    #[rustc_allow_const_fn_unstable(const_fn)]
    pub const fn new_in(alloc: A) -> Self {
        // `cap: 0` означає "unallocated".типи нульового розміру ігноруються.
        Self { ptr: Unique::dangling(), cap: 0, alloc }
    }

    /// Як і `with_capacity`, але параметризований при виборі розподільника для повернутого `RawVec`.
    ///
    #[inline]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Uninitialized, alloc)
    }

    /// Як і `with_capacity_zeroed`, але параметризований при виборі розподільника для повернутого `RawVec`.
    ///
    #[inline]
    pub fn with_capacity_zeroed_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Zeroed, alloc)
    }

    /// Перетворює `Box<[T]>` у `RawVec<T>`.
    pub fn from_box(slice: Box<[T], A>) -> Self {
        unsafe {
            let (slice, alloc) = Box::into_raw_with_allocator(slice);
            RawVec::from_raw_parts_in(slice.as_mut_ptr(), slice.len(), alloc)
        }
    }

    /// Перетворює весь буфер у `Box<[MaybeUninit<T>]>` із зазначеним `len`.
    ///
    /// Зверніть увагу, що це правильно відновить будь-які зміни `cap`, які могли бути виконані.(Детальніше див. Опис типу.)
    ///
    /// # Safety
    ///
    /// * `len` має бути більшим або рівним останнім запитаним потужностям, і
    /// * `len` має бути меншим або рівним `self.capacity()`.
    ///
    /// Зауважте, що запитувана ємність та `self.capacity()` можуть відрізнятися, оскільки розподільник може перерозподілити та повернути більший блок пам`яті, ніж запитувано.
    ///
    ///
    pub unsafe fn into_box(self, len: usize) -> Box<[MaybeUninit<T>], A> {
        // Перевірити розумність однієї половини вимог безпеки (другу половину ми не можемо перевірити).
        debug_assert!(
            len <= self.capacity(),
            "`len` must be smaller than or equal to `self.capacity()`"
        );

        let me = ManuallyDrop::new(self);
        unsafe {
            let slice = slice::from_raw_parts_mut(me.ptr() as *mut MaybeUninit<T>, len);
            Box::from_raw_in(slice, ptr::read(&me.alloc))
        }
    }

    fn allocate_in(capacity: usize, init: AllocInit, alloc: A) -> Self {
        if mem::size_of::<T>() == 0 {
            Self::new_in(alloc)
        } else {
            // Тут ми уникаємо `unwrap_or_else`, оскільки він зменшує кількість генерованого ІЧ LLVM.
            //
            let layout = match Layout::array::<T>(capacity) {
                Ok(layout) => layout,
                Err(_) => capacity_overflow(),
            };
            match alloc_guard(layout.size()) {
                Ok(_) => {}
                Err(_) => capacity_overflow(),
            }
            let result = match init {
                AllocInit::Uninitialized => alloc.allocate(layout),
                AllocInit::Zeroed => alloc.allocate_zeroed(layout),
            };
            let ptr = match result {
                Ok(ptr) => ptr,
                Err(_) => handle_alloc_error(layout),
            };

            Self {
                ptr: unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) },
                cap: Self::capacity_from_bytes(ptr.len()),
                alloc,
            }
        }
    }

    /// Відновлює `RawVec` з покажчика, ємності та розподільника.
    ///
    /// # Safety
    ///
    /// `ptr` повинен бути розподілений (через даний розподільник `alloc`) та із зазначеним `capacity`.
    /// `capacity` не може перевищувати `isize::MAX` для великих типів.
    /// (це стосується лише 32-розрядних систем).
    /// ZST vectors може мати ємність до `usize::MAX`.
    /// Якщо `ptr` і `capacity` походять від `RawVec`, створеного через `alloc`, то це гарантовано.
    ///
    #[inline]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, capacity: usize, alloc: A) -> Self {
        Self { ptr: unsafe { Unique::new_unchecked(ptr) }, cap: capacity, alloc }
    }

    /// Отримує необроблений вказівник на початок розподілу.
    /// Зверніть увагу, що це `Unique::dangling()`, якщо `capacity == 0` або `T` мають нульовий розмір.
    /// У першому випадку потрібно бути обережним.
    #[inline]
    pub fn ptr(&self) -> *mut T {
        self.ptr.as_ptr()
    }

    /// Отримує потужність виділення.
    ///
    /// Це завжди буде `usize::MAX`, якщо `T` нульового розміру.
    #[inline(always)]
    pub fn capacity(&self) -> usize {
        if mem::size_of::<T>() == 0 { usize::MAX } else { self.cap }
    }

    /// Повертає спільне посилання на розподільник, що підтримує цей `RawVec`.
    pub fn allocator(&self) -> &A {
        &self.alloc
    }

    fn current_memory(&self) -> Option<(NonNull<u8>, Layout)> {
        if mem::size_of::<T>() == 0 || self.cap == 0 {
            None
        } else {
            // У нас є виділений шматок пам'яті, тому ми можемо обійти перевірки виконання, щоб отримати наш поточний макет.
            //
            unsafe {
                let align = mem::align_of::<T>();
                let size = mem::size_of::<T>() * self.cap;
                let layout = Layout::from_size_align_unchecked(size, align);
                Some((self.ptr.cast().into(), layout))
            }
        }
    }

    /// Забезпечує, що буфер містить принаймні достатньо місця для утримання елементів `len + additional`.
    /// Якщо він ще не має достатньої потужності, перерозподілить достатньо місця плюс зручний вільний простір, щоб отримати амортизовану поведінку *O*(1).
    ///
    /// Обмежить цю поведінку, якщо це зайво призведе до panic.
    ///
    /// Якщо `len` перевищує `self.capacity()`, це може не дати реального розподілу запитуваного простору.
    /// Це насправді не є небезпечним, але небезпечний код *, який ви пишете, що покладається на поведінку цієї функції, може зламатися.
    ///
    /// Це ідеально підходить для здійснення операції масового натискання, як `extend`.
    ///
    /// # Panics
    ///
    /// Panics, якщо нова ємність перевищує `isize::MAX` байт.
    ///
    /// # Aborts
    ///
    /// Аборти на OOM.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![feature(raw_vec_internals)]
    /// # extern crate alloc;
    /// # use std::ptr;
    /// # use alloc::raw_vec::RawVec;
    /// struct MyVec<T> {
    ///     buf: RawVec<T>,
    ///     len: usize,
    /// }
    ///
    /// impl<T: Clone> MyVec<T> {
    ///     pub fn push_all(&mut self, elems: &[T]) {
    ///         self.buf.reserve(self.len, elems.len());
    ///         // резерв би перервався або впав у паніку, якщо б об'єктив перевищував `isize::MAX`, тому зараз це можна зробити непровіреним.
    /////
    ///         for x in elems {
    ///             unsafe {
    ///                 ptr::write(self.buf.ptr().add(self.len), x.clone());
    ///             }
    ///             self.len += 1;
    ///         }
    ///     }
    /// }
    /// # fn main() {
    /// #   let mut vector = MyVec { buf: RawVec::new(), len: 0 };
    /// #   vector.push_all(&[1, 3, 5, 7, 9]);
    /// # }
    /// ```
    ///
    ///
    pub fn reserve(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve(len, additional));
    }

    /// Те саме, що і `reserve`, але повертається до помилок замість того, щоб панікувати чи переривати.
    pub fn try_reserve(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) {
            self.grow_amortized(len, additional)
        } else {
            Ok(())
        }
    }

    /// Забезпечує, що буфер містить принаймні достатньо місця для утримання елементів `len + additional`.
    /// Якщо цього ще не сталося, перерозподілить мінімально можливий обсяг необхідної пам'яті.
    /// Як правило, це буде саме обсяг необхідної пам'яті, але в принципі розподільник може безкоштовно повернути більше, ніж ми просили.
    ///
    ///
    /// Якщо `len` перевищує `self.capacity()`, це може не дати реального розподілу запитуваного простору.
    /// Це насправді не є небезпечним, але небезпечний код *, який ви пишете, що покладається на поведінку цієї функції, може зламатися.
    ///
    /// # Panics
    ///
    /// Panics, якщо нова ємність перевищує `isize::MAX` байт.
    ///
    /// # Aborts
    ///
    /// Аборти на OOM.
    ///
    ///
    pub fn reserve_exact(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve_exact(len, additional));
    }

    /// Те саме, що і `reserve_exact`, але повертається до помилок замість того, щоб панікувати чи переривати.
    pub fn try_reserve_exact(
        &mut self,
        len: usize,
        additional: usize,
    ) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) { self.grow_exact(len, additional) } else { Ok(()) }
    }

    /// Зменшує розподіл до вказаної суми.
    /// Якщо дана сума дорівнює 0, насправді повністю звільняється.
    ///
    /// # Panics
    ///
    /// Panics, якщо дана сума *більша*, ніж поточна потужність.
    ///
    /// # Aborts
    ///
    /// Аборти на OOM.
    pub fn shrink_to_fit(&mut self, amount: usize) {
        handle_reserve(self.shrink(amount));
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    /// Повертає, якщо буферу потрібно збільшитись, щоб виконати необхідну додаткову ємність.
    /// В основному використовується для здійснення вбудованих резервних дзвінків без вбудовування `grow`.
    fn needs_to_grow(&self, len: usize, additional: usize) -> bool {
        additional > self.capacity().wrapping_sub(len)
    }

    fn capacity_from_bytes(excess: usize) -> usize {
        debug_assert_ne!(mem::size_of::<T>(), 0);
        excess / mem::size_of::<T>()
    }

    fn set_ptr(&mut self, ptr: NonNull<[u8]>) {
        self.ptr = unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) };
        self.cap = Self::capacity_from_bytes(ptr.len());
    }

    // Цей метод, як правило, застосовується багато разів.Тож ми хочемо, щоб це було якомога менше, щоб покращити час компіляції.
    // Але ми також хочемо, щоб якомога більше його вмісту було статично обчислюваним, щоб згенерований код працював швидше.
    // Тому цей метод ретельно написаний, щоб увесь код, який залежить від `T`, знаходився в ньому, тоді як якомога більша частина коду, який не залежить від `T`, була у функціях, що не є загальними для `T`.
    //
    //
    //
    //
    fn grow_amortized(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        // Це забезпечується контекстом виклику.
        debug_assert!(additional > 0);

        if mem::size_of::<T>() == 0 {
            // Оскільки ми повертаємо потужність `usize::MAX`, коли `elem_size` є
            // 0, потрапляння сюди обов`язково означає, що `RawVec` переповнений.
            return Err(CapacityOverflow);
        }

        // На жаль, ми нічого не можемо зробити щодо цих перевірок, на жаль.
        let required_cap = len.checked_add(additional).ok_or(CapacityOverflow)?;

        // Це гарантує експоненціальне зростання.
        // Подвоєння не може перелитися, оскільки `cap <= isize::MAX` і тип `cap`-`usize`.
        let cap = cmp::max(self.cap * 2, required_cap);
        let cap = cmp::max(Self::MIN_NON_ZERO_CAP, cap);

        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` не є загальним для `T`.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    // Обмеження щодо цього методу майже такі ж, як і для `grow_amortized`, але цей метод зазвичай застосовується рідше, тому він менш критичний.
    //
    //
    fn grow_exact(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if mem::size_of::<T>() == 0 {
            // Оскільки ми повертаємо ємність `usize::MAX`, коли розмір типу
            // 0, потрапляння сюди обов`язково означає, що `RawVec` переповнений.
            return Err(CapacityOverflow);
        }

        let cap = len.checked_add(additional).ok_or(CapacityOverflow)?;
        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` не є загальним для `T`.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    fn shrink(&mut self, amount: usize) -> Result<(), TryReserveError> {
        assert!(amount <= self.capacity(), "Tried to shrink to a larger capacity");

        let (ptr, layout) = if let Some(mem) = self.current_memory() { mem } else { return Ok(()) };
        let new_size = amount * mem::size_of::<T>();

        let ptr = unsafe {
            let new_layout = Layout::from_size_align_unchecked(new_size, layout.align());
            self.alloc.shrink(ptr, layout, new_layout).map_err(|_| TryReserveError::AllocError {
                layout: new_layout,
                non_exhaustive: (),
            })?
        };
        self.set_ptr(ptr);
        Ok(())
    }
}

// Ця функція знаходиться поза межами `RawVec`, щоб мінімізувати час компіляції.Детальніше див. Коментар вище `RawVec::grow_amortized`.
// (Параметр `A` не є суттєвим, оскільки кількість різних типів `A`, що спостерігаються на практиці, набагато менше, ніж кількість типів `T`.)
//
//
#[inline(never)]
fn finish_grow<A>(
    new_layout: Result<Layout, LayoutError>,
    current_memory: Option<(NonNull<u8>, Layout)>,
    alloc: &mut A,
) -> Result<NonNull<[u8]>, TryReserveError>
where
    A: Allocator,
{
    // Перевірте помилку тут, щоб мінімізувати розмір `RawVec::grow_*`.
    let new_layout = new_layout.map_err(|_| CapacityOverflow)?;

    alloc_guard(new_layout.size())?;

    let memory = if let Some((ptr, old_layout)) = current_memory {
        debug_assert_eq!(old_layout.align(), new_layout.align());
        unsafe {
            // Розподільник перевіряє рівність вирівнювання
            intrinsics::assume(old_layout.align() == new_layout.align());
            alloc.grow(ptr, old_layout, new_layout)
        }
    } else {
        alloc.allocate(new_layout)
    };

    memory.map_err(|_| AllocError { layout: new_layout, non_exhaustive: () })
}

unsafe impl<#[may_dangle] T, A: Allocator> Drop for RawVec<T, A> {
    /// Звільняє пам`ять, що належить `RawVec`*, не намагаючись* скинути її вміст.
    fn drop(&mut self) {
        if let Some((ptr, layout)) = self.current_memory() {
            unsafe { self.alloc.deallocate(ptr, layout) }
        }
    }
}

// Центральна функція для обробки резервних помилок.
#[inline]
fn handle_reserve(result: Result<(), TryReserveError>) {
    match result {
        Err(CapacityOverflow) => capacity_overflow(),
        Err(AllocError { layout, .. }) => handle_alloc_error(layout),
        Ok(()) => { /* yay */ }
    }
}

// Ми повинні гарантувати наступне:
// * Ми ніколи не виділяємо об`єкти байтового розміру `> isize::MAX`.
// * Ми не переповнюємо `usize::MAX` і фактично виділяємо занадто мало.
//
// На 64-біті нам просто потрібно перевірити переповнення, оскільки спроба розподілити байти `> isize::MAX`, безумовно, не вдасться.
// Для 32-розрядних та 16-розрядних версій нам потрібно додати додатковий захист для цього випадку, якщо ми працюємо на платформі, яка може використовувати всі 4 Гб в просторі користувача, наприклад, PAE або x32.
//
//

#[inline]
fn alloc_guard(alloc_size: usize) -> Result<(), TryReserveError> {
    if usize::BITS < 64 && alloc_size > isize::MAX as usize {
        Err(CapacityOverflow)
    } else {
        Ok(())
    }
}

// Одна центральна функція, відповідальна за перевищення потужності звітності.
// Це забезпечить мінімальне генерування коду, пов`язаного з цими panics, оскільки існує лише одне розташування, яке panics, а не група в модулі.
//
fn capacity_overflow() -> ! {
    panic!("capacity overflow");
}