//! Виділення Prelude
//!
//! Мета цього модуля-полегшити імпорт найпоширеніших елементів `alloc` crate, додавши імпорт глобусів у верхню частину модулів:
//!
//!
//! ```
//! # #![allow(unused_imports)]
//! #![feature(alloc_prelude)]
//! extern crate alloc;
//! use alloc::prelude::v1::*;
//! ```

#![unstable(feature = "alloc_prelude", issue = "58935")]

pub mod v1;