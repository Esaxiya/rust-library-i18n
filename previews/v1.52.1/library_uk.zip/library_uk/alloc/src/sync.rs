#![stable(feature = "rust1", since = "1.0.0")]

//! Вказівники для підрахунку посилань, безпечні для потоків.
//!
//! Детальніше див. У документації [`Arc<T>`][Arc].

use core::any::Any;
use core::borrow;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::hint;
use core::intrinsics::abort;
use core::iter;
use core::marker::{PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;
use core::sync::atomic;
use core::sync::atomic::Ordering::{Acquire, Relaxed, Release, SeqCst};

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::rc::is_dangling;
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

/// М'яке обмеження кількості посилань на `Arc`.
///
/// Перевищення цього обмеження призведе до переривання програми (хоча і не обов`язково) за посиланнями _exactly_ `MAX_REFCOUNT + 1`.
///
const MAX_REFCOUNT: usize = (isize::MAX) as usize;

#[cfg(not(sanitize = "thread"))]
macro_rules! acquire {
    ($x:expr) => {
        atomic::fence(Acquire)
    };
}

// ThreadSanitizer не підтримує огородження пам'яті.
// Щоб уникнути помилково позитивних звітів у реалізації Arc/Weak, використовуйте атомарні навантаження для синхронізації.
//
#[cfg(sanitize = "thread")]
macro_rules! acquire {
    ($x:expr) => {
        $x.load(Acquire)
    };
}

/// Потік-безпечний покажчик підрахунку посилань.'Arc' розшифровується як "Атомно-довідковий рахунок".
///
/// Тип `Arc<T>` забезпечує спільне володіння значенням типу `T`, виділеним у купі.Виклик [`clone`][clone] на `Arc` створює новий екземпляр `Arc`, який вказує на той самий розподіл у купі, що і джерело `Arc`, одночасно збільшуючи кількість посилань.
/// Коли останній вказівник `Arc` на даний розподіл знищений, значення, що зберігається в цьому розподілі (часто називається "inner value"), також скидається.
///
/// Спільні посилання в Rust забороняють мутацію за замовчуванням, і `Arc` не є винятком: загалом ви не можете отримати змінне посилання на щось всередині `Arc`.Якщо вам потрібно мутувати через `Arc`, використовуйте [`Mutex`][mutex], [`RwLock`][rwlock] або один із типів [`Atomic`][atomic].
///
/// ## Безпека ниток
///
/// На відміну від [`Rc<T>`], `Arc<T>` використовує атомні операції для підрахунку посилань.Це означає, що він захищений від потоків.Недоліком є те, що атомні операції дорожчі, ніж звичайні звернення до пам'яті.Якщо ви не розподіляєте розподілених підрахунками посилань між потоками, спробуйте використати [`Rc<T>`] для нижчих накладних витрат.
/// [`Rc<T>`] є безпечним за замовчуванням, оскільки компілятор вловлює будь-яку спробу надсилати [`Rc<T>`] між потоками.
/// Однак бібліотека може вибрати `Arc<T>`, щоб надати споживачам бібліотек більшу гнучкість.
///
/// `Arc<T>` буде впроваджувати [`Send`] та [`Sync`] до тих пір, поки `T` реалізує [`Send`] та [`Sync`].
/// Чому ви не можете помістити не потокобезпечний тип `T` у `Arc<T>`, щоб зробити його потокобезпечним?Спочатку це може бути трохи протилежним інтуїтивним: врешті-решт, не в чому суть безпеки потоків `Arc<T>`?Ключ у цьому: `Arc<T>` робить нитку безпечною для володіння кількома правами власності на одні й ті самі дані, але це не додає безпеки потоків до своїх даних.
///
/// Розглянемо `Arc <` [`RefCell<T>`]`>`.
/// [`RefCell<T>`] не є [`Sync`], і якщо `Arc<T>` завжди був [`Send`], `Arc <` [`RefCell<T>`]`>`також буде.
/// Але тоді у нас була б проблема:
/// [`RefCell<T>`] не захищений від ниток;він відстежує кількість запозичень за допомогою неатомних операцій.
///
/// Зрештою, це означає, що вам може знадобитися з'єднати `Arc<T>` з якимсь типом [`std::sync`], як правило, [`Mutex<T>`][mutex].
///
/// ## Розривні цикли з `Weak`
///
/// Метод [`downgrade`][downgrade] можна використовувати для створення невласницького вказівника [`Weak`].Вказівник [`Weak`] може бути [`оновити`][оновити] d до `Arc`, але це поверне [`None`], якщо значення, що зберігається у розподілі, вже скинуто.
/// Іншими словами, вказівники `Weak` не зберігають значення всередині розподілу живим;однак вони *роблять* підтримують виділення (резервне сховище для вартості) живим.
///
/// Цикл між покажчиками `Arc` ніколи не буде звільнений.
/// З цієї причини [`Weak`] використовується для розриву циклів.Наприклад, дерево може мати сильні вказівники `Arc` від батьківських вузлів до дітей, а [`Weak`]-від дітей до батьків.
///
/// # Посилання на клонування
///
/// Створення нового посилання з існуючого покажчика, підрахованого на посилання, виконується за допомогою `Clone` Portrait, реалізованої для [`Arc<T>`][Arc] та [`Weak<T>`][Weak].
///
/// ```
/// use std::sync::Arc;
/// let foo = Arc::new(vec![1.0, 2.0, 3.0]);
/// // Наведені нижче два синтаксиси еквівалентні.
/// let a = foo.clone();
/// let b = Arc::clone(&foo);
/// // a, b і foo-це всі дуги, які вказують на одне і те ж місце пам'яті
/// ```
///
/// ## `Deref` behavior
///
/// `Arc<T>` автоматично перенаправляє на `T` (через [`Deref`][deref] Portrait), так що ви можете викликати методи T за значенням типу `Arc<T>`.Щоб уникнути зіткнень імен із методами `T`, методи `Arc<T>` самі по собі пов'язані функції, що викликаються за допомогою [fully qualified syntax]:
///
/// ```
/// use std::sync::Arc;
///
/// let my_arc = Arc::new(());
/// Arc::downgrade(&my_arc);
/// ```
///
/// `Arc<T>Реалізації traits, такі як `Clone`, також можуть бути викликані з використанням повноцінного синтаксису.
/// Деякі люди вважають за краще використовувати повноцінний синтаксис, тоді як інші воліють використовувати синтаксис виклику методів.
///
/// ```
/// use std::sync::Arc;
///
/// let arc = Arc::new(());
/// // Синтаксис виклику методу
/// let arc2 = arc.clone();
/// // Повністю кваліфікований синтаксис
/// let arc3 = Arc::clone(&arc);
/// ```
///
/// [`Weak<T>`][Weak] не здійснює автоматичне перенаправлення на `T`, оскільки внутрішнє значення, можливо, вже відкинуто.
///
/// [`Rc<T>`]: crate::rc::Rc
/// [clone]: Clone::clone
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [atomic]: core::sync::atomic
/// [`Send`]: core::marker::Send
/// [`Sync`]: core::marker::Sync
/// [deref]: core::ops::Deref
/// [downgrade]: Arc::downgrade
/// [upgrade]: Weak::upgrade
/// [`RefCell<T>`]: core::cell::RefCell
/// [`std::sync`]: ../../std/sync/index.html
/// [`Arc::clone(&from)`]: Arc::clone
/// [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
///
/// # Examples
///
/// Обмін деякими незмінними даними між потоками:
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
// Зверніть увагу, що ми **не** проводимо ці тести тут.
// Конструктори windows стають надзвичайно нещасними, якщо потік переживає основний потік, а потім виходить одночасно (щось тупикове), тому ми просто уникаємо цього повністю, не проводячи цих тестів.
//
//
/// ```no_run
/// use std::sync::Arc;
/// use std::thread;
///
/// let five = Arc::new(5);
///
/// for _ in 0..10 {
///     let five = Arc::clone(&five);
///
///     thread::spawn(move || {
///         println!("{:?}", five);
///     });
/// }
/// ```
///
/// Спільний доступ до змінної [`AtomicUsize`]:
///
/// [`AtomicUsize`]: core::sync::atomic::AtomicUsize
///
/// ```no_run
/// use std::sync::Arc;
/// use std::sync::atomic::{AtomicUsize, Ordering};
/// use std::thread;
///
/// let val = Arc::new(AtomicUsize::new(5));
///
/// for _ in 0..10 {
///     let val = Arc::clone(&val);
///
///     thread::spawn(move || {
///         let v = val.fetch_add(1, Ordering::SeqCst);
///         println!("{:?}", v);
///     });
/// }
/// ```
///
/// Дивіться [`rc` documentation][rc_examples] для отримання додаткових прикладів підрахунку посилань загалом.
///
///
/// [rc_examples]: crate::rc#examples
#[cfg_attr(not(test), rustc_diagnostic_item = "Arc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Arc<T: ?Sized> {
    ptr: NonNull<ArcInner<T>>,
    phantom: PhantomData<ArcInner<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Arc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Arc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Arc<U>> for Arc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Arc<U>> for Arc<T> {}

impl<T: ?Sized> Arc<T> {
    fn from_inner(ptr: NonNull<ArcInner<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut ArcInner<T>) -> Self {
        unsafe { Self::from_inner(NonNull::new_unchecked(ptr)) }
    }
}

/// `Weak` - це версія [`Arc`], яка містить невласне посилання на керований розподіл.
/// До розподілу можна отримати виклик [`upgrade`] на покажчику `Weak`, який повертає [`Option`]`<`[`Arc`] `<T>>`.
///
/// Оскільки посилання `Weak` не враховується у власність, це не завадить скинути значення, що зберігається у розподілі, і сам `Weak` не дає жодних гарантій щодо значення, яке все ще присутнє.
///
/// Таким чином, він може повернути [`None`], коли [`оновити`] d.
/// Однак зауважте, що посилання `Weak`*не* заважає звільненню самого розподілу (сховища).
///
/// Покажчик `Weak` корисний для збереження тимчасового посилання на розподіл, керований [`Arc`], не запобігаючи викиданню його внутрішнього значення.
/// Він також використовується для запобігання круговим посиланням між покажчиками [`Arc`], оскільки взаємні посилання-власники ніколи не дозволяли б відкинути жоден [`Arc`].
/// Наприклад, дерево може мати сильні вказівники [`Arc`] від батьківських вузлів до дітей, а `Weak`-від дітей до батьків.
///
/// Типовим способом отримання покажчика `Weak` є виклик [`Arc::downgrade`].
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
#[stable(feature = "arc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // Це `NonNull`, щоб дозволити оптимізувати розмір цього типу в переліченнях, але це не обов'язково дійсний вказівник.
    //
    // `Weak::new` встановлює для цього значення `usize::MAX`, так що йому не потрібно виділяти місце в купі.
    // Це не значення, яке справді матиме покажчик, оскільки RcBox має вирівнювання принаймні 2.
    // Це можливо лише тоді, коли `T: Sized`;розмір `T` ніколи не бовтається.
    //
    ptr: NonNull<ArcInner<T>>,
}

#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Weak<T> {}
#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

// Це захист від repr(C) до future проти можливого переупорядкування полів, що заважає безпечному в іншому випадку [into|from]_raw() трансмутованих внутрішніх типів.
//
//
#[repr(C)]
struct ArcInner<T: ?Sized> {
    strong: atomic::AtomicUsize,

    // значення usize::MAX діє як сторожовий для тимчасово "locking" здатність модернізувати слабкі покажчики або знизити сильні;це використовується для уникнення перегонів у `make_mut` та `get_mut`.
    //
    //
    weak: atomic::AtomicUsize,

    data: T,
}

unsafe impl<T: ?Sized + Sync + Send> Send for ArcInner<T> {}
unsafe impl<T: ?Sized + Sync + Send> Sync for ArcInner<T> {}

impl<T> Arc<T> {
    /// Конструює новий `Arc<T>`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(data: T) -> Arc<T> {
        // Почніть підраховувати слабкий покажчик як 1, який є слабким покажчиком, який утримується усіма сильними вказівниками (kinda), див. std/rc.rs для отримання додаткової інформації
        //
        let x: Box<_> = box ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        };
        Self::from_inner(Box::leak(x).into())
    }

    /// Конструює новий `Arc<T>`, використовуючи слабке посилання на себе.
    /// Спроба оновити слабке посилання до повернення цієї функції призведе до значення `None`.
    /// Однак слабке посилання можна вільно клонувати та зберігати для подальшого використання.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    ///
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo {
    ///     me: Weak<Foo>,
    /// }
    ///
    /// let foo = Arc::new_cyclic(|me| Foo {
    ///     me: me.clone(),
    /// });
    /// ```
    #[inline]
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Arc<T> {
        // Побудуйте внутрішнє в стані "uninitialized" за допомогою одного слабкого еталону.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box ArcInner {
            strong: atomic::AtomicUsize::new(0),
            weak: atomic::AtomicUsize::new(1),
            data: mem::MaybeUninit::<T>::uninit(),
        })
        .into();
        let init_ptr: NonNull<ArcInner<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // Важливо, що ми не відмовляємося від володіння слабким покажчиком, інакше пам`ять може звільнитися до повернення `data_fn`.
        // Якби ми дійсно хотіли передати право власності, ми могли б створити для себе додатковий слабкий вказівник, але це призведе до додаткових оновлень слабкого підрахунку посилань, які інакше можуть бути не потрібні.
        //
        //
        //
        //
        let data = data_fn(&weak);

        // Тепер ми можемо правильно ініціалізувати внутрішнє значення і перетворити наше слабке посилання на сильне посилання.
        //
        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).data), data);

            // Вищезаписаний запис у поле даних повинен бути видимим для всіх потоків, які спостерігають ненульовий сильний рахунок.
            // Тому нам потрібне принаймні замовлення "Release" для синхронізації з `compare_exchange_weak` у `Weak::upgrade`.
            //
            // "Acquire" замовлення не потрібно.
            // Розглядаючи можливу поведінку `data_fn`, нам потрібно лише поглянути на те, що він міг би зробити із посиланням на `Weak`, який не можна оновити:
            //
            // - Він може *клонувати*`Weak`, збільшуючи кількість слабких посилань.
            // - Він може скинути ці клони, зменшуючи слабкий показник посилань (але ніколи до нуля).
            //
            // Ці побічні ефекти жодним чином не впливають на нас, і ніякі інші побічні ефекти неможливі лише за допомогою безпечного коду.
            //
            //
            let prev_value = (*inner).strong.fetch_add(1, Release);
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
        }

        let strong = Arc::from_inner(init_ptr);

        // Сильні посилання повинні колективно мати спільне слабке посилання, тому не запускайте деструктор для нашого старого слабкого посилання.
        //
        mem::forget(weak);
        strong
    }

    /// Конструює новий `Arc` з неініціалізованим вмістом.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Відкладена ініціалізація:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Конструює новий `Arc` з неініціалізованим вмістом, при цьому пам'ять заповнюється байтами `0`.
    ///
    ///
    /// Див. [`MaybeUninit::zeroed`][zeroed] для прикладів правильного та неправильного використання цього методу.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Конструює новий `Pin<Arc<T>>`.
    /// Якщо `T` не реалізує `Unpin`, тоді `data` буде закріплено в пам'яті і не може бути переміщено.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(data: T) -> Pin<Arc<T>> {
        unsafe { Pin::new_unchecked(Arc::new(data)) }
    }

    /// Конструює новий `Arc<T>`, повертаючи помилку, якщо розподіл не вдається.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::sync::Arc;
    ///
    /// let five = Arc::try_new(5)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new(data: T) -> Result<Arc<T>, AllocError> {
        // Почніть підраховувати слабкий покажчик як 1, який є слабким покажчиком, який утримується усіма сильними вказівниками (kinda), див. std/rc.rs для отримання додаткової інформації
        //
        let x: Box<_> = Box::try_new(ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        })?;
        Ok(Self::from_inner(Box::leak(x).into()))
    }

    /// Конструює новий `Arc` з неініціалізованим вмістом, повертаючи помилку, якщо розподіл не вдається.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // Відкладена ініціалізація:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// Конструює новий `Arc` з неініціалізованим вмістом, при цьому пам'ять заповнюється байтами `0`, повертаючи помилку, якщо розподіл не вдається.
    ///
    ///
    /// Див. [`MaybeUninit::zeroed`][zeroed] для прикладів правильного та неправильного використання цього методу.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// Повертає внутрішнє значення, якщо `Arc` має рівно одне сильне посилання.
    ///
    /// В іншому випадку [`Err`] повертається з тим самим `Arc`, який був переданий.
    ///
    ///
    /// Це вдасться, навіть якщо є видатні слабкі посилання.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new(3);
    /// assert_eq!(Arc::try_unwrap(x), Ok(3));
    ///
    /// let x = Arc::new(4);
    /// let _y = Arc::clone(&x);
    /// assert_eq!(*Arc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if this.inner().strong.compare_exchange(1, 0, Relaxed, Relaxed).is_err() {
            return Err(this);
        }

        acquire!(this.inner().strong);

        unsafe {
            let elem = ptr::read(&this.ptr.as_ref().data);

            // Створіть слабкий вказівник, щоб очистити неявне посилання сильно-слабке
            let _weak = Weak { ptr: this.ptr };
            mem::forget(this);

            Ok(elem)
        }
    }
}

impl<T> Arc<[T]> {
    /// Конструює новий фрагмент з атомарним підрахунком посилань з неініціалізованим вмістом.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Відкладена ініціалізація:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe { Arc::from_ptr(Arc::allocate_for_slice(len)) }
    }

    /// Конструює новий зріз із атомарним підрахунком посилань з неініціалізованим вмістом, при цьому пам`ять заповнюється байтами `0`.
    ///
    ///
    /// Див. [`MaybeUninit::zeroed`][zeroed] для прикладів правильного та неправильного використання цього методу.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let values = Arc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut ArcInner<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Arc<mem::MaybeUninit<T>> {
    /// Перетворює на `Arc<T>`.
    ///
    /// # Safety
    ///
    /// Як і у випадку з [`MaybeUninit::assume_init`], від абонента залежить гарантувати, що внутрішнє значення дійсно знаходиться в стані ініціалізації.
    ///
    /// Виклик цього, коли вміст ще не повністю ініціалізований, спричиняє негайну невизначену поведінку.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Відкладена ініціалізація:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<T> {
        Arc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Arc<[mem::MaybeUninit<T>]> {
    /// Перетворює на `Arc<[T]>`.
    ///
    /// # Safety
    ///
    /// Як і у випадку з [`MaybeUninit::assume_init`], від абонента залежить гарантувати, що внутрішнє значення дійсно знаходиться в стані ініціалізації.
    ///
    /// Виклик цього, коли вміст ще не повністю ініціалізований, спричиняє негайну невизначену поведінку.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Відкладена ініціалізація:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<[T]> {
        unsafe { Arc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// Споживає `Arc`, повертаючи загорнутий покажчик.
    ///
    /// Щоб уникнути витоку пам'яті, вказівник потрібно перетворити назад у `Arc` за допомогою [`Arc::from_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// Надає необроблений вказівник на дані.
    ///
    /// На підрахунок це ніяк не впливає, і `Arc` не споживається.
    /// Покажчик дійсний до тих пір, поки в `Arc` є значний рахунок.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let y = Arc::clone(&x);
    /// let x_ptr = Arc::as_ptr(&x);
    /// assert_eq!(x_ptr, Arc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(this.ptr);

        // БЕЗПЕКА: Це не може пройти через Deref::deref або RcBoxPtr::inner, оскільки
        // це потрібно для збереження походження raw/mut таким, що, наприклад
        // `get_mut` може писати через покажчик після відновлення Rc через `from_raw`.
        unsafe { ptr::addr_of_mut!((*ptr).data) }
    }

    /// Конструює `Arc<T>` з необробленого вказівника.
    ///
    /// Сировинний вказівник повинен бути раніше повернутий за допомогою виклику [`Arc<U>::into_raw`][into_raw], де `U` повинен мати такий самий розмір і вирівнювання, як `T`.
    /// Це тривіально вірно, якщо `U`-це `T`.
    /// Зауважте, що якщо `U` не є `T`, але має однакові розміри та вирівнювання, це в основному схоже на перетворення посилань різних типів.
    /// Дивіться [`mem::transmute`][transmute] для отримання додаткової інформації про те, які обмеження застосовуються в цьому випадку.
    ///
    /// Користувач `from_raw` повинен переконатися, що конкретне значення `T` скидається лише один раз.
    ///
    /// Ця функція небезпечна, оскільки неналежне використання може призвести до небезпеки пам'яті, навіть якщо доступ до повернутого `Arc<T>` ніколи не здійснюється.
    ///
    /// [into_raw]: Arc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    ///
    /// unsafe {
    ///     // Перетворіть назад на `Arc`, щоб запобігти витоку.
    ///     let x = Arc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // Подальші дзвінки на `Arc::from_raw(x_ptr)` були б небезпечними для пам'яті.
    /// }
    ///
    /// // Пам'ять звільнилася, коли `x` вийшов із сфери дії вище, тому `x_ptr` тепер бовтається!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        unsafe {
            let offset = data_offset(ptr);

            // Поверніть зміщення, щоб знайти оригінальний ArcInner.
            let arc_ptr = (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset));

            Self::from_ptr(arc_ptr)
        }
    }

    /// Створює новий вказівник [`Weak`] на це виділення.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        // Це Relaxed-це нормально, оскільки ми перевіряємо значення в CAS нижче.
        //
        let mut cur = this.inner().weak.load(Relaxed);

        loop {
            // перевірити, чи слабкий лічильник наразі "locked";якщо так, крути.
            if cur == usize::MAX {
                hint::spin_loop();
                cur = this.inner().weak.load(Relaxed);
                continue;
            }

            // NOTE: даний код ігнорує можливість переповнення
            // в usize::MAX;загалом як Rc, так і Arc потрібно регулювати для боротьби з переповненням.
            //

            // На відміну від Clone(), нам потрібно, щоб це було читання Acquire для синхронізації із записом, що надходить із `is_unique`, щоб події до цього запису відбувалися до цього читання.
            //
            //
            match this.inner().weak.compare_exchange_weak(cur, cur + 1, Acquire, Relaxed) {
                Ok(_) => {
                    // Переконайтеся, що ми не створюємо звисаючого Слабкого
                    debug_assert!(!is_dangling(this.ptr.as_ptr()));
                    return Weak { ptr: this.ptr };
                }
                Err(old) => cur = old,
            }
        }
    }

    /// Отримує кількість покажчиків [`Weak`] на цей розподіл.
    ///
    /// # Safety
    ///
    /// Цей метод сам по собі безпечний, але правильне його використання вимагає додаткової обережності.
    /// Інший потік може будь-коли змінити кількість слабких, включаючи потенційно між викликом цього методу та дією на результат.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _weak_five = Arc::downgrade(&five);
    ///
    /// // Це твердження є детермінованим, оскільки ми не поділяли `Arc` або `Weak` між потоками.
    /////
    /// assert_eq!(1, Arc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        let cnt = this.inner().weak.load(SeqCst);
        // Якщо слабкий підрахунок зараз заблокований, значення підрахунку становило 0 безпосередньо перед тим, як взяти блокування.
        //
        if cnt == usize::MAX { 0 } else { cnt - 1 }
    }

    /// Отримує кількість сильних покажчиків (`Arc`) на цей розподіл.
    ///
    /// # Safety
    ///
    /// Цей метод сам по собі безпечний, але правильне його використання вимагає додаткової обережності.
    /// Інший потік може будь-коли змінити сильний відлік, включаючи потенційно між викликом цього методу та дією на результат.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _also_five = Arc::clone(&five);
    ///
    /// // Це твердження є детермінованим, оскільки ми не поділяли `Arc` між потоками.
    /////
    /// assert_eq!(2, Arc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong.load(SeqCst)
    }

    /// Збільшує кількість сильних посилань на `Arc<T>`, пов'язану з наданим покажчиком, на одиницю.
    ///
    /// # Safety
    ///
    /// Вказівник повинен бути отриманий через `Arc::into_raw`, і пов'язаний з ним екземпляр `Arc` повинен бути дійсним (тобто
    /// сильний підрахунок повинен бути принаймні 1) на час дії цього методу.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // Це твердження є детермінованим, оскільки ми не поділяли `Arc` між потоками.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn increment_strong_count(ptr: *const T) {
        // Збережіть Arc, але не торкайтесь перерахунку, обернувши ManuallyDrop
        let arc = unsafe { mem::ManuallyDrop::new(Arc::<T>::from_raw(ptr)) };
        // Тепер збільште повторний підрахунок, але не скидайте і новий
        let _arc_clone: mem::ManuallyDrop<_> = arc.clone();
    }

    /// Кількість сильних посилань на `Arc<T>`, пов`язану з наданим покажчиком, зменшується на одиницю.
    ///
    /// # Safety
    ///
    /// Вказівник повинен бути отриманий через `Arc::into_raw`, і пов'язаний з ним екземпляр `Arc` повинен бути дійсним (тобто
    /// сильний підрахунок повинен бути принаймні 1) при використанні цього методу.
    /// Цей метод можна використовувати для звільнення остаточного `Arc` та резервного сховища, але **не слід** викликати його після випуску останнього `Arc`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // Ці твердження є детермінованими, оскільки ми не поділяли `Arc` між потоками.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    ///     Arc::decrement_strong_count(ptr);
    ///     assert_eq!(1, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn decrement_strong_count(ptr: *const T) {
        unsafe { mem::drop(Arc::from_raw(ptr)) };
    }

    #[inline]
    fn inner(&self) -> &ArcInner<T> {
        // Ця небезпека є нормальною, оскільки поки ця дуга жива, ми гарантуємо, що внутрішній вказівник є дійсним.
        // Крім того, ми знаємо, що сама структура `ArcInner` є `Sync`, оскільки внутрішні дані також є `Sync`, тому ми можемо вилучити незмінний вказівник на цей вміст.
        //
        //
        //
        unsafe { self.ptr.as_ref() }
    }

    // Невбудована частина `drop`.
    #[inline(never)]
    unsafe fn drop_slow(&mut self) {
        // Наразі знищити дані, хоча ми можемо не звільнити сам розподіл вікон (навколо все ще можуть лежати слабкі вказівники).
        //
        unsafe { ptr::drop_in_place(Self::get_mut_unchecked(self)) };

        // Відкиньте слабкий реф, колективно дотриманий усіма сильними посиланнями
        drop(Weak { ptr: self.ptr });
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// Повертає `true`, якщо дві `дуги вказують на одне і те ж розподіл (у вені, подібній до [`ptr::eq`]).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let same_five = Arc::clone(&five);
    /// let other_five = Arc::new(5);
    ///
    /// assert!(Arc::ptr_eq(&five, &same_five));
    /// assert!(!Arc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: ?Sized> Arc<T> {
    /// Виділяє `ArcInner<T>` із достатньою площею для можливо великого внутрішнього значення там, де значення має макет.
    ///
    /// Функція `mem_to_arcinner` викликається за допомогою покажчика даних і повинна повернути (потенційно жирний) покажчик для `ArcInner<T>`.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> *mut ArcInner<T> {
        // Розрахуйте макет, використовуючи задане значення макета.
        // Раніше макет обчислювався за виразом `&*(ptr as* const ArcInner<T>)`, але це створило неправильне вирівнювання (див. #54908).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Arc::try_allocate_for_layout(value_layout, allocate, mem_to_arcinner)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// Виділяє `ArcInner<T>` із достатньою площею для можливо великого внутрішнього значення, де значення має макет, що повертає помилку, якщо розподіл не вдається.
    ///
    ///
    /// Функція `mem_to_arcinner` викликається за допомогою покажчика даних і повинна повернути (потенційно жирний) покажчик для `ArcInner<T>`.
    ///
    ///
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> Result<*mut ArcInner<T>, AllocError> {
        // Розрахуйте макет, використовуючи задане значення макета.
        // Раніше макет обчислювався за виразом `&*(ptr as* const ArcInner<T>)`, але це створило неправильне вирівнювання (див. #54908).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();

        let ptr = allocate(layout)?;

        // Ініціалізуйте ArcInner
        let inner = mem_to_arcinner(ptr.as_non_null_ptr().as_ptr());
        debug_assert_eq!(unsafe { Layout::for_value(&*inner) }, layout);

        unsafe {
            ptr::write(&mut (*inner).strong, atomic::AtomicUsize::new(1));
            ptr::write(&mut (*inner).weak, atomic::AtomicUsize::new(1));
        }

        Ok(inner)
    }

    /// Виділяє `ArcInner<T>` із достатньою площею для внутрішнього значення величини.
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut ArcInner<T> {
        // Виділіть для `ArcInner<T>`, використовуючи задане значення.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut ArcInner<T>).set_ptr_value(mem) as *mut ArcInner<T>,
            )
        }
    }

    fn from_box(v: Box<T>) -> Arc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // Копіювати значення у байтах
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).data as *mut _ as *mut u8,
                value_size,
            );

            // Звільніть розподіл, не скидаючи його вміст
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Arc<[T]> {
    /// Виділяє `ArcInner<[T]>` із заданою довжиною.
    unsafe fn allocate_for_slice(len: usize) -> *mut ArcInner<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut ArcInner<[T]>,
            )
        }
    }

    /// Скопіюйте елементи зі зрізу у щойно виділену Дугу <\[T\]>
    ///
    /// Небезпечно, оскільки абонент повинен або отримати право власності, або прив'язати `T: Copy`.
    unsafe fn copy_from_slice(v: &[T]) -> Arc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());

            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).data as *mut [T] as *mut T, v.len());

            Self::from_ptr(ptr)
        }
    }

    /// Конструює `Arc<[T]>` з ітератора, як відомо, певного розміру.
    ///
    /// Поведінка невизначена, якщо розмір неправильний.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Arc<[T]> {
        // Захист Panic під час клонування елементів Т.
        // У разі panic елементи, які були записані в новий ArcInner, будуть скинуті, а потім звільнена пам'ять.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // Покажчик на перший елемент
            let elems = &mut (*ptr).data as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // Все чисто.Забудьте про охоронця, щоб він не звільнив новий ArcInner.
            mem::forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// Спеціалізація Portrait, що використовується для `From<&[T]>`.
trait ArcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Arc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Arc<T> {
    /// Робить клон покажчика `Arc`.
    ///
    /// Це створює ще один вказівник на той самий розподіл, збільшуючи потужну кількість посилань.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let _ = Arc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Arc<T> {
        // Використання розслабленого впорядкування-це нормально, оскільки знання оригінального посилання заважає іншим потокам помилково видаляти об`єкт.
        //
        // Як пояснюється в [Boost documentation][1], збільшення лічильника посилань завжди можна зробити за допомогою memory_order_relaxed: нові посилання на об'єкт можуть бути сформовані лише з існуючого посилання, а передача існуючого посилання з одного потоку в інший вже повинна забезпечувати необхідну синхронізацію.
        //
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        //
        //
        //
        //
        //
        let old_size = self.inner().strong.fetch_add(1, Relaxed);

        // Однак нам потрібно уберегтися від масових перерахунків на випадок, якщо хтось запам'ятає дуги.
        // Якщо ми цього не зробимо, кількість може переповнюватися, і користувачі будуть використовувати після цього безкоштовно.
        // Ми шалено насичуємо `isize::MAX`, припускаючи, що не існує ~2 мільярдів потоків, що одночасно збільшують кількість посилань.
        //
        // Цей branch ніколи не буде взятий у жодній реалістичній програмі.
        //
        // Ми перериваємо, оскільки така програма неймовірно вироджена, і ми не хочемо її підтримувати.
        //
        //
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Arc<T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        &self.inner().data
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Arc<T> {}

impl<T: Clone> Arc<T> {
    /// Змінює посилання на даний `Arc`.
    ///
    /// Якщо є інші вказівники `Arc` або [`Weak`] на той самий розподіл, тоді `make_mut` створить нове розподілення та викличе [`clone`][clone] на внутрішнє значення для забезпечення унікального володіння.
    /// Це також називають клоном на запис.
    ///
    /// Зауважте, що це відрізняється від поведінки [`Rc::make_mut`], яка роз'єднує будь-які залишилися покажчики `Weak`.
    ///
    /// Див. Також [`get_mut`][get_mut], який скоріше зазнає невдачі, ніж клонування.
    ///
    /// [clone]: Clone::clone
    /// [get_mut]: Arc::get_mut
    /// [`Rc::make_mut`]: super::rc::Rc::make_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut data = Arc::new(5);
    ///
    /// *Arc::make_mut(&mut data) += 1;         // Нічого не клонуватиме
    /// let mut other_data = Arc::clone(&data); // Не буде клонувати внутрішні дані
    /// *Arc::make_mut(&mut data) += 1;         // Клонує внутрішні дані
    /// *Arc::make_mut(&mut data) += 1;         // Нічого не клонуватиме
    /// *Arc::make_mut(&mut other_data) *= 2;   // Нічого не клонуватиме
    ///
    /// // Тепер `data` та `other_data` вказують на різні розподіли.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        // Зверніть увагу, що ми маємо як сильну, так і слабку посилання.
        // Таким чином, випуск лише нашого сильного посилання сам по собі не призведе до вивільнення пам'яті.
        //
        // Використовуйте Acquire, щоб переконатися, що ми бачимо будь-які записи в `weak`, які трапляються до записів випуску (тобто зменшення) в `strong`.
        // Оскільки ми проводимо слабкий підрахунок, немає шансів, що ArcInner може бути звільнений.
        //
        //
        //
        if this.inner().strong.compare_exchange(1, 0, Acquire, Relaxed).is_err() {
            // Існує ще один сильний покажчик, тому ми повинні клонувати.
            // Попередньо виділіть пам'ять, щоб дозволити безпосередньо писати клоноване значення.
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = arc.assume_init();
            }
        } else if this.inner().weak.load(Relaxed) != 1 {
            // Вище сказаного достатньо, бо це принципово оптимізація: ми завжди мчимося зі слабкими вказівниками, які відпадають.
            // Гірший випадок-ми в кінцевому підсумку виділили нову дугу без потреби.
            //

            // Ми видалили останню сильну позицію, але залишились додаткові слабкі рекомендації.
            // Ми перемістимо вміст до нової дуги, а інші слабкі посилання визнаємо недійсними.
            //

            // Зверніть увагу, що зчитування `weak` не може дати usize::MAX (тобто заблоковано), оскільки слабкий відлік може зафіксувати лише потік із сильним посиланням.
            //
            //

            // Матеріалізуйте наш власний неявний слабкий покажчик, щоб він міг очищати ArcInner за потреби.
            //
            let _weak = Weak { ptr: this.ptr };

            // Можна просто вкрасти дані, залишився лише Weaks
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);
                ptr::write(this, arc.assume_init());
            }
        } else {
            // Ми були єдиним посиланням будь-якого виду;підняти назад сильний підрахунок.
            //
            this.inner().strong.store(1, Release);
        }

        // Як і у випадку з `get_mut()`, небезпека є нормальною, оскільки наше посилання для початку було або унікальним, або стало таким при клонуванні вмісту.
        //
        unsafe { Self::get_mut_unchecked(this) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// Повертає змінне посилання на даний `Arc`, якщо немає інших покажчиків `Arc` або [`Weak`] на те саме розподіл.
    ///
    ///
    /// Повертає [`None`] в іншому випадку, оскільки небезпечно мутувати спільне значення.
    ///
    /// Див. Також [`make_mut`][make_mut], який буде [`clone`][clone] внутрішнім значенням, якщо є інші вказівники.
    ///
    /// [make_mut]: Arc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(3);
    /// *Arc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Arc::clone(&x);
    /// assert!(Arc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if this.is_unique() {
            // Ця небезпека є нормальною, оскільки ми гарантуємо, що повернутий покажчик-це єдиний * покажчик, який коли-небудь буде повернено T.
            // На даний момент кількість наших посилань гарантовано дорівнює 1, і ми вимагали, щоб сама дуга була `mut`, тому ми повертаємо єдине можливе посилання на внутрішні дані.
            //
            //
            //
            unsafe { Some(Arc::get_mut_unchecked(this)) }
        } else {
            None
        }
    }

    /// Повертає змінне посилання на даний `Arc` без жодної перевірки.
    ///
    /// Див. Також [`get_mut`], який є безпечним та робить відповідні перевірки.
    ///
    /// [`get_mut`]: Arc::get_mut
    ///
    /// # Safety
    ///
    /// Будь-які інші вказівники `Arc` або [`Weak`] на той самий розподіл не повинні бути розмежовувані протягом тривалості поверненої позики.
    ///
    /// Це тривіально, якщо таких покажчиків не існує, наприклад відразу після `Arc::new`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(String::new());
    /// unsafe {
    ///     Arc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // Ми обережні, щоб *не* створювати посилання, що охоплює поля "count", оскільки це могло б мати псевдонім із одночасним доступом до підрахунку посилань (наприклад,
        // від `Weak`).
        unsafe { &mut (*this.ptr.as_ptr()).data }
    }

    /// Визначте, чи це унікальне посилання (включаючи слабкі посилання) на базові дані.
    ///
    ///
    /// Зверніть увагу, що для цього потрібно зафіксувати слабкий відлік.
    fn is_unique(&mut self) -> bool {
        // зафіксуйте кількість слабких покажчиків, якщо ми здаємось єдиним власником слабкого покажчика.
        //
        // Тут мітка набуття забезпечує взаємозв'язок "до" з будь-якими записами в `strong` (зокрема, в `Weak::upgrade`) до зменшення кількості `weak` (через `Weak::drop`, що використовує випуск).
        // Якщо оновлене слабке посилання ніколи не було скинуто, CAS тут не вдасться, тому ми не хочемо синхронізувати.
        //
        //
        //
        if self.inner().weak.compare_exchange(1, usize::MAX, Acquire, Relaxed).is_ok() {
            // Це повинен бути `Acquire` для синхронізації із зменшенням лічильника `strong` у `drop`-єдиний доступ, який відбувається, коли будь-яке, крім останнього посилання, відпадає.
            //
            //
            let unique = self.inner().strong.load(Acquire) == 1;

            // Запис випуску тут синхронізується з читанням у `downgrade`, ефективно запобігаючи виникненню вищезазначеного читання `strong` після запису.
            //
            //
            self.inner().weak.store(1, Release); // відпустіть замок
            unique
        } else {
            false
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Arc<T> {
    /// Кидає `Arc`.
    ///
    /// Це зменшить потужну кількість посилань.
    /// Якщо кількість сильних посилань досягає нуля, тоді єдиними іншими посиланнями (якщо такі є) є [`Weak`], тому ми `drop`-внутрішнє значення.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Arc::new(Foo);
    /// let foo2 = Arc::clone(&foo);
    ///
    /// drop(foo);    // Нічого не друкує
    /// drop(foo2);   // Друкує "dropped!"
    /// ```
    #[inline]
    fn drop(&mut self) {
        // Оскільки `fetch_sub` вже є атомною, нам не потрібно синхронізувати з іншими потоками, якщо ми не збираємось видаляти об`єкт.
        // Ця сама логіка застосовується до наведеного нижче `fetch_sub` до підрахунку `weak`.
        //
        if self.inner().strong.fetch_sub(1, Release) != 1 {
            return;
        }

        // Ця огорожа потрібна для запобігання переупорядкуванню використання даних та видаленню даних.
        // Оскільки він позначений як `Release`, зменшення кількості посилань синхронізується з цим парканом `Acquire`.
        // Це означає, що використання даних відбувається перед зменшенням кількості посилань, що відбувається перед цим парканом, що відбувається перед видаленням даних.
        //
        // Як пояснюється в [Boost documentation][1],
        //
        // > Важливо забезпечити будь-який можливий доступ до об`єкта в одному
        // > потік (через існуюче посилання), щоб *відбулося до* видалення
        // > об'єкт в іншому потоці.Цього досягає "release"
        // > операція після скидання посилання (будь-який доступ до об'єкта
        // > через це посилання, очевидно, мало місце раніше), і
        // > "acquire" операція перед видаленням об'єкта.
        //
        // Зокрема, хоча вміст дуги, як правило, незмінний, можна мати внутрішні записи в щось на зразок Mutex<T>.
        // Оскільки Mutex не отримується при видаленні, ми не можемо покладатися на його логіку синхронізації, щоб зробити записи в потоці A видимими для деструктора, що працює в потоці B.
        //
        //
        // Також зауважте, що тут огорожа Acquire, можливо, може бути замінена навантаженням Acquire, що може покращити продуктивність у суперечливих ситуаціях.Див. [2].
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        // [2]: (https://github.com/rust-lang/rust/pull/41714)
        //
        //
        //
        //
        //
        //
        //
        acquire!(self.inner().strong);

        unsafe {
            self.drop_slow();
        }
    }
}

impl Arc<dyn Any + Send + Sync> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// Спроба знизити `Arc<dyn Any + Send + Sync>` до конкретного типу.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::sync::Arc;
    ///
    /// fn print_if_string(value: Arc<dyn Any + Send + Sync>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Arc::new(my_string));
    /// print_if_string(Arc::new(0i8));
    /// ```
    pub fn downcast<T>(self) -> Result<Arc<T>, Self>
    where
        T: Any + Send + Sync + 'static,
    {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<ArcInner<T>>();
            mem::forget(self);
            Ok(Arc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T> Weak<T> {
    /// Конструює новий `Weak<T>`, не виділяючи жодної пам'яті.
    /// Виклик [`upgrade`] на повернене значення завжди дає [`None`].
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut ArcInner<T>).expect("MAX is not 0") }
    }
}

/// Тип допоміжного, щоб дозволити доступ до лічильників посилань, не роблячи жодних тверджень щодо поля даних.
///
struct WeakInner<'a> {
    weak: &'a atomic::AtomicUsize,
    strong: &'a atomic::AtomicUsize,
}

impl<T: ?Sized> Weak<T> {
    /// Повертає необроблений вказівник на об'єкт `T`, на який вказує цей `Weak<T>`.
    ///
    /// Вказівник є дійсним лише за наявності сильних посилань.
    /// Покажчик може звисати, не вирівнюватися або навіть [`null`] в іншому випадку.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::ptr;
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// // Обидва вказують на один і той же об`єкт
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // Сильний тут підтримує його в живих, тому ми все ще можемо отримати доступ до об`єкта.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // Але вже не більше.
    /// // Ми можемо зробити weak.as_ptr(), але доступ до покажчика призведе до невизначеної поведінки.
    /// // assert_eq! ("привіт", небезпечно {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // Якщо покажчик звисає, ми повертаємо сторожового безпосередньо.
            // Це не може бути дійсною адресою корисного навантаження, оскільки корисне навантаження принаймні настільки ж вирівняне, як ArcInner (usize).
            ptr as *const T
        } else {
            // БЕЗПЕКА: якщо is_dangling повертає значення false, тоді вказівник неможливо розпізнати.
            // На цьому етапі корисне навантаження може бути скинуто, і ми повинні підтримувати походження, тому використовуйте маніпуляції з необробленими вказівниками.
            //
            unsafe { ptr::addr_of_mut!((*ptr).data) }
        }
    }

    /// Споживає `Weak<T>` і перетворює його на сирий вказівник.
    ///
    /// Це перетворює слабкий покажчик у вихідний покажчик, зберігаючи при цьому право власності на одне слабке посилання (слабкий рахунок не змінюється цією операцією).
    /// Його можна перетворити назад у `Weak<T>` за допомогою [`from_raw`].
    ///
    /// Застосовуються ті самі обмеження доступу до цілі вказівника, що і для [`as_ptr`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Arc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Arc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// Перетворює необроблений вказівник, раніше створений [`into_raw`], назад у `Weak<T>`.
    ///
    /// Це можна використовувати для безпечного отримання надійного посилання (зателефонувавши [`upgrade`] пізніше) або для звільнення слабкого рахунку, скинувши `Weak<T>`.
    ///
    /// Він бере у власність одне слабке посилання (за винятком покажчиків, створених [`new`], оскільки вони нічого не мають; метод все ще працює на них).
    ///
    /// # Safety
    ///
    /// Вказівник повинен походити з [`into_raw`] і все ще повинен мати свою потенційну слабку посилання.
    ///
    /// Під час виклику дозволено, щоб сильний підрахунок становив 0.
    /// Тим не менше, це приймає у власність одне слабке посилання, представлене в даний час як вихідний вказівник (слабкий відлік не змінюється цією операцією), і тому він повинен бути з'єднаний з попереднім викликом до [`into_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    ///
    /// let raw_1 = Arc::downgrade(&strong).into_raw();
    /// let raw_2 = Arc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Arc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Arc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // Зменште останній слабкий рахунок.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`new`]: Weak::new
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`forget`]: std::mem::forget
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // Див. Weak::as_ptr для контексту, як виводиться вказівник введення.

        let ptr = if is_dangling(ptr as *mut T) {
            // Це звисаючий Слабкий.
            ptr as *mut ArcInner<T>
        } else {
            // В іншому випадку ми гарантуємо, що вказівник походить від незрозумілого Слабкого.
            // БЕЗПЕКА: data_offset безпечно викликати, оскільки ptr посилається на реальний (потенційно скинутий) T.
            let offset = unsafe { data_offset(ptr) };
            // Таким чином, ми змінюємо зміщення, щоб отримати весь RcBox.
            // БЕЗПЕКА: покажчик походить від слабкого, тому цей зсув безпечний.
            unsafe { (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // БЕЗПЕКА: тепер ми відновили вихідний слабкий вказівник, тому можемо створити слабкий.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }
}

impl<T: ?Sized> Weak<T> {
    /// Спроби оновити покажчик `Weak` до [`Arc`], затримуючи скидання внутрішнього значення у разі успіху.
    ///
    ///
    /// Повертає [`None`], якщо внутрішнє значення з тих пір було скинуто.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    ///
    /// let strong_five: Option<Arc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // Знищити всі сильні покажчики.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Arc<T>> {
        // Ми використовуємо цикл CAS для збільшення сильного рахунку замість fetch_add, оскільки ця функція ніколи не повинна приймати кількість посилань з нуля до одиниці.
        //
        //
        let inner = self.inner()?;

        // Розслаблене навантаження, оскільки будь-який запис 0, який ми можемо спостерігати, залишає поле в постійно нульовому стані (тому зчитування "stale" 0-це нормально), а будь-яке інше значення підтверджується за допомогою CAS нижче.
        //
        //
        //
        let mut n = inner.strong.load(Relaxed);

        loop {
            if n == 0 {
                return None;
            }

            // Див. Коментарі в `Arc::clone` щодо того, чому ми це робимо (для `mem::forget`).
            if n > MAX_REFCOUNT {
                abort();
            }

            // Розслабленість-це нормально для справи про невдачу, оскільки ми не маємо жодних сподівань щодо нової держави.
            // Придбання необхідне для синхронізації випадку успіху з `Arc::new_cyclic`, коли внутрішнє значення може бути ініціалізоване після того, як вже створені посилання на `Weak`.
            // У цьому випадку ми сподіваємось спостерігати повністю ініціалізоване значення.
            //
            match inner.strong.compare_exchange_weak(n, n + 1, Acquire, Relaxed) {
                Ok(_) => return Some(Arc::from_inner(self.ptr)), // null перевірено вище
                Err(old) => n = old,
            }
        }
    }

    /// Отримує кількість сильних покажчиків (`Arc`), що вказують на цей розподіл.
    ///
    /// Якщо `self` було створено за допомогою [`Weak::new`], це поверне 0.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong.load(SeqCst) } else { 0 }
    }

    /// Отримує апроксимацію кількості покажчиків `Weak`, що вказують на цей розподіл.
    ///
    /// Якщо `self` було створено за допомогою [`Weak::new`], або якщо не залишилося сильних покажчиків, це поверне 0.
    ///
    /// # Accuracy
    ///
    /// Завдяки деталям реалізації, повернене значення може бути вимкнено на 1 в будь-якому напрямку, коли інші потоки обробляють будь-які `Arc`s або`Weak`s, що вказують на той самий розподіл.
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                let weak = inner.weak.load(SeqCst);
                let strong = inner.strong.load(SeqCst);
                if strong == 0 {
                    0
                } else {
                    // Оскільки ми зауважили, що після прочитання слабкого підрахунку існував щонайменше один сильний покажчик, ми знаємо, що неявне слабке посилання (присутнє, коли живі будь-які сильні посилання) все ще було поруч, коли ми спостерігали слабкий підрахунок, і тому можемо його сміливо віднімати.
                    //
                    //
                    //
                    //
                    weak - 1
                }
            })
            .unwrap_or(0)
    }

    /// Повертає `None`, коли покажчик звисає, і немає виділеного `ArcInner`, (тобто, коли цей `Weak` був створений `Weak::new`).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // Ми обережні, щоб *не* створювати посилання, що охоплює поле "data", оскільки поле може одночасно мутувати (наприклад, якщо останній `Arc` буде відкинуто, поле даних буде видалено на місці).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// Повертає `true`, якщо два `Слабких` вказують на одне і те ж розподіл (подібне до [`ptr::eq`]), або якщо обидва не вказують на жодне розподіл (оскільки вони були створені за допомогою `Weak::new()`).
    ///
    ///
    /// # Notes
    ///
    /// Оскільки це порівнює покажчики, це означає, що `Weak::new()` зрівнятимуться між собою, навіть якщо вони не вказують на жодне розподіл.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let first_rc = Arc::new(5);
    /// let first = Arc::downgrade(&first_rc);
    /// let second = Arc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(5);
    /// let third = Arc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// Порівняння `Weak::new`.
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(());
    /// let third = Arc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// Робить клон покажчика `Weak`, який вказує на той самий розподіл.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let weak_five = Arc::downgrade(&Arc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        let inner = if let Some(inner) = self.inner() {
            inner
        } else {
            return Weak { ptr: self.ptr };
        };
        // Див. Коментарі в Arc::clone() щодо того, чому це розслаблено.
        // Для цього можна використовувати fetch_add (ігноруючи блокування), оскільки слабкий рахунок блокується лише там, де *відсутні* інші слабкі вказівники.
        //
        // (Тож ми не можемо запускати цей код у такому випадку).
        let old_size = inner.weak.fetch_add(1, Relaxed);

        // Див. Коментарі в Arc::clone() щодо того, чому ми це робимо (для mem::forget).
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// Конструює новий `Weak<T>` без виділення пам'яті.
    /// Виклик [`upgrade`] на повернене значення завжди дає [`None`].
    ///
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// Відкидає покажчик `Weak`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Arc::new(Foo);
    /// let weak_foo = Arc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // Нічого не друкує
    /// drop(foo);        // Друкує "dropped!"
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        // Якщо ми виявимо, що ми були останнім слабким покажчиком, настав час повністю звільнити дані.Див. Обговорення в Arc::drop() щодо впорядкування пам`яті
        //
        // Тут не потрібно перевіряти заблокований стан, оскільки слабкий відлік можна заблокувати лише тоді, коли був точно один слабкий реф, це означає, що падіння могло лише згодом увімкнути той залишився слабкий реф, що може статися лише після звільнення блокування.
        //
        //
        //
        //
        //
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        if inner.weak.fetch_sub(1, Release) == 1 {
            acquire!(inner.weak);
            unsafe { Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr())) }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait ArcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Arc<T>) -> bool;
    fn ne(&self, other: &Arc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    default fn eq(&self, other: &Arc<T>) -> bool {
        **self == **other
    }
    #[inline]
    default fn ne(&self, other: &Arc<T>) -> bool {
        **self != **other
    }
}

/// Ми робимо цю спеціалізацію тут, а не як більш загальну оптимізацію на `&T`, оскільки в іншому випадку це додасть витрат на всі перевірки рівності посилань.
/// Ми припускаємо, що `Arc` використовуються для зберігання великих значень, які повільно клонуються, але також важкі для перевірки на рівність, завдяки чому ці витрати легше окупляться.
///
/// Також більше шансів мати два клони `Arc`, які вказують на одне і те ж значення, ніж два `` T ''.
///
/// Ми можемо зробити це лише тоді, коли `T: Eq` як `PartialEq` може бути навмисно нерефлексивним.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + crate::rc::MarkerEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        Arc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        !Arc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Arc<T> {
    /// Рівність для двох дуг.
    ///
    /// Дві `Arc` є рівними, якщо їх внутрішні значення рівні, навіть якщо вони зберігаються в різному розподілі.
    ///
    /// Якщо `T` також реалізує `Eq` (маючи на увазі рефлексивність рівності), дві `дуги, що вказують на однаковий розподіл, завжди рівні.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five == Arc::new(5));
    /// ```
    ///
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::eq(self, other)
    }

    /// Нерівність для двох дуг.
    ///
    /// Дві дуги нерівні, якщо їх внутрішні цінності неоднакові.
    ///
    /// Якщо `T` також реалізує `Eq` (маючи на увазі рефлексивність рівності), дві `дуги, що вказують на одне і те ж значення, ніколи не бувають нерівними.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five != Arc::new(6));
    /// ```
    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Arc<T> {
    /// Часткове порівняння для двох `Arc`.
    ///
    /// Їх порівнюють, зателефонувавши до `partial_cmp()` за їхніми внутрішніми значеннями.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Arc::new(6)));
    /// ```
    fn partial_cmp(&self, other: &Arc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// Менше порівняння для двох дуг.
    ///
    /// Їх порівнюють, зателефонувавши `<` за їх внутрішніми значеннями.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five < Arc::new(6));
    /// ```
    fn lt(&self, other: &Arc<T>) -> bool {
        *(*self) < *(*other)
    }

    /// Порівняння "менше або дорівнює" для двох "дуг".
    ///
    /// Їх порівнюють, зателефонувавши `<=` за їхніми внутрішніми значеннями.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five <= Arc::new(5));
    /// ```
    fn le(&self, other: &Arc<T>) -> bool {
        *(*self) <= *(*other)
    }

    /// Більше порівняння для двох `Arc`.
    ///
    /// Їх порівнюють, зателефонувавши `>` за їхніми внутрішніми значеннями.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five > Arc::new(4));
    /// ```
    fn gt(&self, other: &Arc<T>) -> bool {
        *(*self) > *(*other)
    }

    /// Порівняння "більше або дорівнює" для двох "дуг".
    ///
    /// Їх порівнюють, зателефонувавши до `>=` за їхніми внутрішніми значеннями.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five >= Arc::new(5));
    /// ```
    fn ge(&self, other: &Arc<T>) -> bool {
        *(*self) >= *(*other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Arc<T> {
    /// Порівняння двох дуг.
    ///
    /// Їх порівнюють, зателефонувавши `cmp()` за їхніми внутрішніми значеннями.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Arc::new(6)));
    /// ```
    fn cmp(&self, other: &Arc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Arc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Arc<T> {
    /// Створює новий `Arc<T>` зі значенням `Default` для `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x: Arc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    fn default() -> Arc<T> {
        Arc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Arc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Arc<T> {
    fn from(t: T) -> Self {
        Arc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Arc<[T]> {
    /// Виділіть підрахований фрагмент та заповніть його, клонуючи елементи `v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Arc<[T]> {
        <Self as ArcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Arc<str> {
    /// Виділіть підрахований `str` і скопіюйте в нього `v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let shared: Arc<str> = Arc::from("eggplant");
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Arc<str> {
        let arc = Arc::<[u8]>::from(v.as_bytes());
        unsafe { Arc::from_raw(Arc::into_raw(arc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Arc<str> {
    /// Виділіть підрахований `str` і скопіюйте в нього `v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: String = "eggplant".to_owned();
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Arc<str> {
        Arc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Arc<T> {
    /// Перемістіть об`єкт, розміщений у коробці, до нового розподілу, що враховується посиланнями.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Box<str> = Box::from("eggplant");
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Arc<T> {
        Arc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Arc<[T]> {
    /// Виділіть фрагмент з порахуванням посилань і перемістіть в нього елементи `v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Vec<i32> = vec![1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(unique);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Arc<[T]> {
        unsafe {
            let arc = Arc::copy_from_slice(&v);

            // Дозвольте Vec звільнити свою пам`ять, але не знищувати її вміст
            v.set_len(0);

            arc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Arc<B>
where
    B: ToOwned + ?Sized,
    Arc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Arc<B> {
        match cow {
            Cow::Borrowed(s) => Arc::from(s),
            Cow::Owned(s) => Arc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Arc<[T]>> for Arc<[T; N]> {
    type Error = Arc<[T]>;

    fn try_from(boxed_slice: Arc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Arc::from_raw(Arc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Arc<[T]> {
    /// Бере кожен елемент у `Iterator` та збирає його у `Arc<[T]>`.
    ///
    /// # Експлуатаційні характеристики
    ///
    /// ## Загальний випадок
    ///
    /// У загальному випадку збирання в `Arc<[T]>` здійснюється шляхом першого збирання в `Vec<T>`.Тобто, коли пишеться таке:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// це поводиться так, ніби ми писали:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // Тут відбувається перший набір розподілів.
    ///     .into(); // Тут відбувається другий розподіл для `Arc<[T]>`.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// Це виділить стільки разів, скільки потрібно для побудови `Vec<T>`, а потім виділить один раз для перетворення `Vec<T>` в `Arc<[T]>`.
    ///
    ///
    /// ## Ітератори відомої довжини
    ///
    /// Коли ваш `Iterator` реалізує `TrustedLen` і має точний розмір, для `Arc<[T]>` буде зроблено один розподіл.Наприклад:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).collect(); // Тут відбувається лише одне виділення.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToArcSlice::to_arc_slice(iter.into_iter())
    }
}

/// Спеціалізація Portrait, що використовується для збору в `Arc<[T]>`.
trait ToArcSlice<T>: Iterator<Item = T> + Sized {
    fn to_arc_slice(self) -> Arc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToArcSlice<T> for I {
    default fn to_arc_slice(self) -> Arc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToArcSlice<T> for I {
    fn to_arc_slice(self) -> Arc<[T]> {
        // Це стосується ітератора `TrustedLen`.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // БЕЗПЕКА: нам потрібно переконатися, що ітератор має точну довжину, а ми маємо.
                Arc::from_iter_exact(self, low)
            }
        } else {
            // Поверніться до нормальної реалізації.
            self.collect::<Vec<T>>().into()
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Arc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Arc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Arc<T> {}

/// Отримайте зсув в межах `ArcInner` для корисного навантаження за вказівником.
///
/// # Safety
///
/// Покажчик повинен вказувати на (і мати діючі метадані для) раніше дійсного екземпляра T, але T дозволяється скидати.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // Вирівняйте величину без розміру до кінця ArcInner.
    // Оскільки RcBox-це repr(C), він завжди буде останнім полем у пам'яті.
    // БЕЗПЕКА: оскільки єдиними можливими типорозмірами є фрагменти, об`єкти Portrait,
    // та зовнішніх типів, вимоги щодо безпеки введення в даний час достатньо для задоволення вимог align_of_val_raw;це деталь реалізації мови, на яку не можна покладатися поза std.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<ArcInner<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}