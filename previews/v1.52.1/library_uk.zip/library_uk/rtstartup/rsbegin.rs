// rsbegin.o і rsend.o-це так звані "compiler runtime startup objects".
// Вони містять код, необхідний для правильної ініціалізації роботи компілятора.
//
// Коли пов'язане виконуване зображення або зображення dylib, усі користувацькі коди та бібліотеки є "sandwiched" між цими двома об'єктними файлами, тому код або дані з rsbegin.o стають першими у відповідних розділах зображення, тоді як код і дані з rsend.o стають останніми.
// Цей ефект можна використовувати для розміщення символів на початку або в кінці розділу, а також для вставки необхідних колонтитулів.
//
// Зверніть увагу, що фактична точка входу модуля знаходиться в запусковому об'єкті C (зазвичай називається `crtX.o`), який потім викликає зворотні виклики ініціалізації інших компонентів середовища виконання (зареєстрованих через ще один спеціальний розділ зображення).
//
//
//
//
//
//

#![feature(no_core)]
#![feature(lang_items)]
#![feature(auto_traits)]
#![crate_type = "rlib"]
#![no_core]
#![allow(non_camel_case_types)]

#[lang = "sized"]
trait Sized {}
#[lang = "sync"]
auto trait Sync {}
#[lang = "copy"]
trait Copy {}
#[lang = "freeze"]
auto trait Freeze {}

#[lang = "drop_in_place"]
#[inline]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    drop_in_place(to_drop);
}

#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frames {
    #[no_mangle]
    #[link_section = ".eh_frame"]
    // Позначає початок розгортання інформаційного розділу кадру стека
    pub static __EH_FRAME_BEGIN__: [u8; 0] = [];

    // Скретч-місце для внутрішнього ведення бухгалтерії розмотувача.
    // Це визначається як `struct object` у $ GCC/wraind-dw2-fde.h.
    static mut OBJ: [isize; 6] = [0; 6];

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                impl ::Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    // Розслабтеся з інформаційними процедурами registration/deregistration.
    // Див. Документи libpanic_unwind.
    extern "C" {
        fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8);
        fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8);
    }

    unsafe extern "C" fn init() {
        // зареєструвати інформацію про розмотування при запуску модуля
        rust_eh_register_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    unsafe extern "C" fn uninit() {
        // скасувати реєстрацію при вимкненні
        rust_eh_unregister_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    // Реєстрація рутинної роботи init/uninit для MinGW
    pub mod mingw_init {
        // Об'єкти запуску MinGW (crt0.o/dllcrt0.o) будуть запускати глобальні конструктори в розділах .ctors та .dtors при запуску та виході.
        // У випадку DLL-файлів це робиться, коли DLL завантажується та вивантажується.
        //
        // Лінкер сортує розділи, що гарантує, що наші зворотні виклики знаходяться в кінці списку.
        // Оскільки конструктори запускаються в зворотному порядку, це гарантує, що наші зворотні виклики виконуються першим і останнім.
        //
        //

        #[link_section = ".ctors.65535"] // .ctors. *: Зворотні виклики ініціалізації C
        pub static P_INIT: unsafe extern "C" fn() = super::init;

        #[link_section = ".dtors.65535"] // .dtors. *: зворотні виклики завершення
        pub static P_UNINIT: unsafe extern "C" fn() = super::uninit;
    }
}