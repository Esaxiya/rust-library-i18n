//! Підтримка символізації за допомогою `gimli` crate на crates.io
//!
//! Це реалізація символів за замовчуванням для Rust.

use self::gimli::read::EndianSlice;
use self::gimli::NativeEndian as Endian;
use self::mmap::Mmap;
use self::stash::Stash;
use super::BytesOrWideString;
use super::ResolveWhat;
use super::SymbolName;
use addr2line::gimli;
use core::convert::TryInto;
use core::mem;
use core::u32;
use libc::c_void;
use mystd::ffi::OsString;
use mystd::fs::File;
use mystd::path::Path;
use mystd::prelude::v1::*;

#[cfg(backtrace_in_libstd)]
mod mystd {
    pub use crate::*;
}
#[cfg(not(backtrace_in_libstd))]
extern crate std as mystd;

cfg_if::cfg_if! {
    if #[cfg(windows)] {
        #[path = "gimli/mmap_windows.rs"]
        mod mmap;
    } else if #[cfg(any(
        target_os = "android",
        target_os = "freebsd",
        target_os = "fuchsia",
        target_os = "ios",
        target_os = "linux",
        target_os = "macos",
        target_os = "openbsd",
        target_os = "solaris",
    ))] {
        #[path = "gimli/mmap_unix.rs"]
        mod mmap;
    } else {
        #[path = "gimli/mmap_fake.rs"]
        mod mmap;
    }
}

mod stash;

const MAPPINGS_CACHE_SIZE: usize = 4;

struct Mapping {
    // `` статичне життя-це брехня, щоб зламати відсутність підтримки самореференційних структур.
    cx: Context<'static>,
    _map: Mmap,
    _stash: Stash,
}

impl Mapping {
    fn mk<F>(data: Mmap, mk: F) -> Option<Mapping>
    where
        F: for<'a> Fn(&'a [u8], &'a Stash) -> Option<Context<'a>>,
    {
        let stash = Stash::new();
        let cx = mk(&data, &stash)?;
        Some(Mapping {
            // Перетворити на 'статичний час життя, оскільки символи повинні запозичувати лише `map` та `stash`, і ми зберігаємо їх нижче.
            //
            cx: unsafe { core::mem::transmute::<Context<'_>, Context<'static>>(cx) },
            _map: data,
            _stash: stash,
        })
    }
}

struct Context<'a> {
    dwarf: addr2line::Context<EndianSlice<'a, Endian>>,
    object: Object<'a>,
}

impl<'data> Context<'data> {
    fn new(stash: &'data Stash, object: Object<'data>) -> Option<Context<'data>> {
        fn load_section<'data, S>(stash: &'data Stash, obj: &Object<'data>) -> S
        where
            S: gimli::Section<gimli::EndianSlice<'data, Endian>>,
        {
            let data = obj.section(stash, S::section_name()).unwrap_or(&[]);
            S::from(EndianSlice::new(data, Endian))
        }

        let dwarf = addr2line::Context::from_sections(
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            gimli::EndianSlice::new(&[], Endian),
        )
        .ok()?;
        Some(Context { dwarf, object })
    }
}

fn mmap(path: &Path) -> Option<Mmap> {
    let file = File::open(path).ok()?;
    let len = file.metadata().ok()?.len().try_into().ok()?;
    unsafe { Mmap::map(&file, len) }
}

cfg_if::cfg_if! {
    if #[cfg(windows)] {
        use core::mem::MaybeUninit;
        use super::super::windows::*;
        use mystd::os::windows::prelude::*;
        use alloc::vec;

        mod coff;
        use self::coff::Object;

        // Для завантаження власних бібліотек на Windows, див. Деякі обговорення щодо rust-lang/rust#71060 щодо різних стратегій тут.
        //
        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            unsafe { add_loaded_images(&mut ret); }
            return ret;
        }

        unsafe fn add_loaded_images(ret: &mut Vec<Library>) {
            let snap = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE, 0);
            if snap == INVALID_HANDLE_VALUE {
                return;
            }

            let mut me = MaybeUninit::<MODULEENTRY32W>::zeroed().assume_init();
            me.dwSize = mem::size_of_val(&me) as DWORD;
            if Module32FirstW(snap, &mut me) == TRUE {
                loop {
                    if let Some(lib) = load_library(&me) {
                        ret.push(lib);
                    }

                    if Module32NextW(snap, &mut me) != TRUE {
                        break;
                    }
                }

            }

            CloseHandle(snap);
        }

        unsafe fn load_library(me: &MODULEENTRY32W) -> Option<Library> {
            let pos = me
                .szExePath
                .iter()
                .position(|i| *i == 0)
                .unwrap_or(me.szExePath.len());
            let name = OsString::from_wide(&me.szExePath[..pos]);

            // Наразі бібліотеки MinGW не підтримують ASLR (rust-lang/rust#16514), але бібліотеки DLL все одно можна перемістити в адресний простір.
            // Здається, що адреси в інформації про налагодження такі, ніби ця бібліотека завантажена у своєму "image base", що є полем у заголовках файлів COFF.
            // Оскільки це те, що, здається, перелічує debuginfo, ми аналізуємо таблицю символів і зберігаємо адреси так, ніби бібліотека також завантажена в "image base".
            //
            // Однак бібліотека може не завантажуватися на "image base".
            // (імовірно, там може бути завантажено щось інше?) Тут вступає в поле поле `bias`, і нам потрібно з'ясувати значення `bias` тут.На жаль, хоча незрозуміло, як це отримати із завантаженого модуля.
            // Однак у нас є фактична адреса завантаження (`modBaseAddr`).
            //
            // На даний момент ми трохи копіюємо файл mmap, читаємо інформацію заголовка файлу, а потім скидаємо mmap.Це марнотратно, тому що ми, мабуть, знову відкриємо mmap пізніше, але наразі це має працювати досить добре.
            //
            // Отримавши `image_base` (бажане місце завантаження) та `base_addr` (фактичне місце завантаження), ми можемо заповнити `bias` (різниця між фактичним та бажаним), і тоді вказана адреса кожного сегмента є `image_base`, оскільки саме про це йдеться у файлі.
            //
            //
            // На даний момент здається, що на відміну від ELF/MachO ми можемо обійтися одним сегментом на бібліотеку, використовуючи `modBaseSize` як весь розмір.
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            let mmap = mmap(name.as_ref())?;
            let image_base = coff::get_image_base(&mmap)?;
            let base_addr = me.modBaseAddr as usize;
            Some(Library {
                name,
                bias: base_addr.wrapping_sub(image_base),
                segments: vec![LibrarySegment {
                    stated_virtual_memory_address: image_base,
                    len: me.modBaseSize as usize,
                }],
            })
        }
    } else if #[cfg(any(
        target_os = "macos",
        target_os = "ios",
        target_os = "tvos",
        target_os = "watchos",
    ))] {
        // macOS використовує формат файлу Mach-O та використовує API, специфічні для DYLD, для завантаження списку власних бібліотек, які є частиною програми.
        //

        use mystd::os::unix::prelude::*;
        use mystd::ffi::{OsStr, CStr};

        mod macho;
        use self::macho::Object;

        #[allow(deprecated)]
        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            let images = unsafe { libc::_dyld_image_count() };
            for i in 0..images {
                ret.extend(native_library(i));
            }
            return ret;
        }

        #[allow(deprecated)]
        fn native_library(i: u32) -> Option<Library> {
            use object::macho;
            use object::read::macho::{MachHeader, Segment};
            use object::{Bytes, NativeEndian};

            // Виберіть ім`я цієї бібліотеки, яке відповідає шляху, куди її також завантажити.
            //
            let name = unsafe {
                let name = libc::_dyld_get_image_name(i);
                if name.is_null() {
                    return None;
                }
                CStr::from_ptr(name)
            };

            // Завантажте заголовок зображення цієї бібліотеки та делегуйте до `object`, щоб проаналізувати всі команди завантаження, щоб ми могли з`ясувати всі сегменти, що беруть участь тут.
            //
            //
            let (mut load_commands, endian) = unsafe {
                let header = libc::_dyld_get_image_header(i);
                if header.is_null() {
                    return None;
                }
                match (*header).magic {
                    macho::MH_MAGIC => {
                        let endian = NativeEndian;
                        let header = &*(header as *const macho::MachHeader32<NativeEndian>);
                        let data = core::slice::from_raw_parts(
                            header as *const _ as *const u8,
                            mem::size_of_val(header) + header.sizeofcmds.get(endian) as usize
                        );
                        (header.load_commands(endian, Bytes(data)).ok()?, endian)
                    }
                    macho::MH_MAGIC_64 => {
                        let endian = NativeEndian;
                        let header = &*(header as *const macho::MachHeader64<NativeEndian>);
                        let data = core::slice::from_raw_parts(
                            header as *const _ as *const u8,
                            mem::size_of_val(header) + header.sizeofcmds.get(endian) as usize
                        );
                        (header.load_commands(endian, Bytes(data)).ok()?, endian)
                    }
                    _ => return None,
                }
            };

            // Переглядайте сегменти та реєструйте відомі області для сегментів, які ми знаходимо.
            // Додатково запишіть інформацію про текстові сегменти для подальшої обробки, див. Коментарі нижче.
            //
            let mut segments = Vec::new();
            let mut first_text = 0;
            let mut text_fileoff_zero = false;
            while let Some(cmd) = load_commands.next().ok()? {
                if let Some((seg, _)) = cmd.segment_32().ok()? {
                    if seg.name() == b"__TEXT" {
                        first_text = segments.len();
                        if seg.fileoff(endian) == 0 && seg.filesize(endian) > 0 {
                            text_fileoff_zero = true;
                        }
                    }
                    segments.push(LibrarySegment {
                        len: seg.vmsize(endian).try_into().ok()?,
                        stated_virtual_memory_address: seg.vmaddr(endian).try_into().ok()?,
                    });
                }
                if let Some((seg, _)) = cmd.segment_64().ok()? {
                    if seg.name() == b"__TEXT" {
                        first_text = segments.len();
                        if seg.fileoff(endian) == 0 && seg.filesize(endian) > 0 {
                            text_fileoff_zero = true;
                        }
                    }
                    segments.push(LibrarySegment {
                        len: seg.vmsize(endian).try_into().ok()?,
                        stated_virtual_memory_address: seg.vmaddr(endian).try_into().ok()?,
                    });
                }
            }

            // Визначте "slide" для цієї бібліотеки, що в кінцевому підсумку є упередженням, яке ми використовуємо для з`ясування місця завантаження об`єктів пам`яті.
            // Хоча це трохи дивне обчислення і є результатом спробувати кілька речей у дикій природі та побачити, що палички.
            //
            // Загальна ідея полягає в тому, що `bias` плюс сегмент `stated_virtual_memory_address` буде там, де у фактичному адресному просторі знаходиться сегмент.
            // Інше, на що ми покладаємося,-це те, що реальна адреса мінус `bias`-це індекс, який потрібно шукати в таблиці символів та debuginfo.
            //
            // Однак виявляється, що для завантажених системою бібліотек ці розрахунки є неправильними.Однак для власних виконуваних файлів він видається правильним.
            // Піднімаючи трохи логіки з джерела LLDB, він має певний корпус для першого розділу `__TEXT`, завантаженого із зміщення файлу 0 із ненульовим розміром.
            // З будь-якої причини, коли це присутнє, здається, це означає, що таблиця символів відносно просто слайда vmaddr для бібліотеки.
            // Якщо * * немає, тоді таблиця символів відносно слайда vmaddr плюс вказану адресу сегмента.
            //
            // Щоб вирішити цю ситуацію, якщо ми *не* знайдемо текстовий розділ із нульовим зміщенням файлу, тоді ми збільшуємо зміщення на вказану адресу перших текстових розділів і також зменшуємо всі вказані адреси на цю суму.
            //
            // Таким чином таблиця символів завжди відображається відносно суми упередженості бібліотеки.
            // Здається, це має правильні результати для символізації через таблицю символів.
            //
            // Чесно кажучи, я не зовсім впевнений, чи це правильно, чи є щось інше, що повинно вказати, як це зробити.
            // Поки що це, здається, працює досить добре (?), і ми завжди повинні мати змогу змінити це з часом, якщо це необхідно.
            //
            // Для отримання додаткової інформації див. #318
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            let mut slide = unsafe { libc::_dyld_get_image_vmaddr_slide(i) as usize };
            if !text_fileoff_zero {
                let adjust = segments[first_text].stated_virtual_memory_address;
                for segment in segments.iter_mut() {
                    segment.stated_virtual_memory_address -= adjust;
                }
                slide += adjust;
            }

            Some(Library {
                name: OsStr::from_bytes(name.to_bytes()).to_owned(),
                segments,
                bias: slide,
            })
        }
    } else if #[cfg(any(
        target_os = "linux",
        target_os = "fuchsia",
    ))] {
        // Інші Unix (наприклад,
        // Linux) використовують платформи ELF як формат об'єктного файлу і зазвичай реалізують API під назвою `dl_iterate_phdr` для завантаження власних бібліотек.
        //

        use mystd::os::unix::prelude::*;
        use mystd::ffi::{OsStr, CStr};

        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            unsafe {
                libc::dl_iterate_phdr(Some(callback), &mut ret as *mut Vec<_> as *mut _);
            }
            return ret;
        }

        // `info` повинні бути дійсними вказівниками.
        // `vec` має бути дійсним вказівником на `std::Vec`.
        unsafe extern "C" fn callback(
            info: *mut libc::dl_phdr_info,
            _size: libc::size_t,
            vec: *mut libc::c_void,
        ) -> libc::c_int {
            let info = &*info;
            let libs = &mut *(vec as *mut Vec<Library>);
            let is_main_prog = info.dlpi_name.is_null() || *info.dlpi_name == 0;
            let name = if is_main_prog {
                if libs.is_empty() {
                    mystd::env::current_exe().map(|e| e.into()).unwrap_or_default()
                } else {
                    OsString::new()
                }
            } else {
                let bytes = CStr::from_ptr(info.dlpi_name).to_bytes();
                OsStr::from_bytes(bytes).to_owned()
            };
            let headers = core::slice::from_raw_parts(info.dlpi_phdr, info.dlpi_phnum as usize);
            libs.push(Library {
                name,
                segments: headers
                    .iter()
                    .map(|header| LibrarySegment {
                        len: (*header).p_memsz as usize,
                        stated_virtual_memory_address: (*header).p_vaddr as usize,
                    })
                    .collect(),
                bias: info.dlpi_addr as usize,
            });
            0
        }
    } else if #[cfg(target_env = "libnx")] {
        // DevkitA64 не підтримує інформацію про налагодження, але система збірки розмістить інформацію про налагодження у шляху `romfs:/debug_info.elf`.
        //
        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            extern "C" {
                static __start__: u8;
            }

            let bias = unsafe { &__start__ } as *const u8 as usize;

            let mut ret = Vec::new();
            let mut segments = Vec::new();
            segments.push(LibrarySegment {
                stated_virtual_memory_address: 0,
                len: usize::max_value() - bias,
            });

            let path = "romfs:/debug_info.elf";
            ret.push(Library {
                name: path.into(),
                segments,
                bias,
            });

            ret
        }
    } else {
        // Для всього іншого слід використовувати ELF, але не знає, як завантажувати власні бібліотеки.
        //

        use mystd::os::unix::prelude::*;
        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            Vec::new()
        }
    }
}

#[derive(Default)]
struct Cache {
    /// Усі відомі спільні бібліотеки, які були завантажені.
    libraries: Vec<Library>,

    /// Кеш відображень, де ми зберігаємо проаналізовану карликову інформацію.
    ///
    /// Цей список має фіксовану потужність протягом усього часу його роботи, яка ніколи не збільшується.
    /// Елемент `usize` кожної пари є індексом `libraries` вище, де `usize::max_value()` представляє поточний виконуваний файл.
    ///
    /// `Mapping`-це відповідна аналізована інформація про карликів.
    ///
    /// Зверніть увагу, що це, в основному, кеш LRU, і ми будемо переносити речі сюди, оскільки ми символізуємо адреси.
    ///
    mappings: Vec<(usize, Mapping)>,
}

struct Library {
    name: OsString,
    /// Сегменти цієї бібліотеки завантажуються в пам`ять і де вони завантажуються.
    segments: Vec<LibrarySegment>,
    /// "bias" цієї бібліотеки, як правило, там, де вона завантажується в пам`ять.
    /// Це значення додається до вказаної адреси кожного сегмента, щоб отримати фактичну адресу віртуальної пам'яті, в яку завантажений сегмент.
    /// Крім того, це упередження віднімається з реальних адрес віртуальної пам'яті для індексації у debuginfo та таблицю символів.
    ///
    ///
    bias: usize,
}

struct LibrarySegment {
    /// Зазначена адреса цього сегмента у файлі об`єктів.
    /// Насправді тут не завантажується сегмент, а саме ця адреса плюс `bias`, що містить бібліотеку, де його можна знайти.
    ///
    stated_virtual_memory_address: usize,
    /// Розмір цього сегмента в пам'яті.
    len: usize,
}

// небезпечно, оскільки це потрібно для зовнішньої синхронізації
pub unsafe fn clear_symbol_cache() {
    Cache::with_global(|cache| cache.mappings.clear());
}

impl Cache {
    fn new() -> Cache {
        Cache {
            mappings: Vec::with_capacity(MAPPINGS_CACHE_SIZE),
            libraries: native_libraries(),
        }
    }

    // небезпечно, оскільки це потрібно для зовнішньої синхронізації
    unsafe fn with_global(f: impl FnOnce(&mut Self)) {
        // Дуже маленький, дуже простий кеш LRU для налагодження зіставлення інформації.
        //
        // Частота звернень повинна бути дуже високою, оскільки типовий стек не перетинає багато спільних бібліотек.
        //
        // Структури `addr2line::Context` досить дорогі у створенні.
        // Очікується, що його вартість буде амортизована наступними запитами `locate`, які використовують структури, побудовані при побудові `addr2line: : Context`s, щоб отримати приємні прискорення.
        //
        // Якби у нас не було цього кешу, ця амортизація ніколи б не відбулася, а символічні зворотні відстеження були б ssssllllooooowwww.
        //
        //
        static mut MAPPINGS_CACHE: Option<Cache> = None;

        f(MAPPINGS_CACHE.get_or_insert_with(|| Cache::new()))
    }

    fn avma_to_svma(&self, addr: *const u8) -> Option<(usize, *const u8)> {
        self.libraries
            .iter()
            .enumerate()
            .filter_map(|(i, lib)| {
                // Спочатку перевірте, чи є у цього `lib` який-небудь сегмент, що містить `addr` (обробка переміщення).Якщо ця перевірка пройде, ми можемо продовжити нижче і фактично перекласти адресу.
                //
                // Зверніть увагу, що ми використовуємо `wrapping_add` тут, щоб уникнути перевірки переповнення.В дикій природі було помічено, що обчислення упередження SVMA + переповнюється.
                // Це здається трохи дивним, що це могло б статися, але ми не можемо зробити з цим величезної кількості, крім, можливо, просто ігнорування цих сегментів, оскільки вони, швидше за все, спрямовуються в космос.
                //
                // Спочатку це було придумано в rust-lang/backtrace-rs#329.
                //
                //
                //
                //
                //
                if !lib.segments.iter().any(|s| {
                    let svma = s.stated_virtual_memory_address;
                    let start = svma.wrapping_add(lib.bias);
                    let end = start.wrapping_add(s.len);
                    let address = addr as usize;
                    start <= address && address < end
                }) {
                    return None;
                }

                // Тепер, коли ми знаємо, що `lib` містить `addr`, ми можемо компенсувати упередження, щоб знайти вказану адресу вірусальної пам'яті.
                //
                let svma = (addr as usize).wrapping_sub(lib.bias);
                Some((i, svma as *const u8))
            })
            .next()
    }

    fn mapping_for_lib<'a>(&'a mut self, lib: usize) -> Option<&'a mut Context<'a>> {
        let idx = self.mappings.iter().position(|(idx, _)| *idx == lib);

        // Інваріант: після цього умовне завершується без дострокового повернення
        // після помилки запис кешу для цього шляху має індекс 0.

        if let Some(idx) = idx {
            // Коли відображення вже є в кеші, перемістіть його вперед.
            if idx != 0 {
                let entry = self.mappings.remove(idx);
                self.mappings.insert(0, entry);
            }
        } else {
            // Коли відображення відсутнє в кеш-пам`яті, створіть нове відображення, вставте його у передню частину кешу та вилучіть найстаріший запис кешу, якщо це необхідно.
            //
            //
            let name = &self.libraries[lib].name;
            let mapping = Mapping::new(name.as_ref())?;

            if self.mappings.len() == MAPPINGS_CACHE_SIZE {
                self.mappings.pop();
            }

            self.mappings.insert(0, (lib, mapping));
        }

        let cx: &'a mut Context<'static> = &mut self.mappings[0].1.cx;
        // не витокуйте `'static` протягом усього життя, переконайтеся, що його масштаб стосується лише нас самих
        //
        Some(unsafe { mem::transmute::<&'a mut Context<'static>, &'a mut Context<'a>>(cx) })
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let addr = what.address_or_ip();
    let mut call = |sym: Symbol<'_>| {
        // Продовжте термін служби `sym` до `'static`, оскільки, на жаль, ми тут зобов`язані, але це завжди виходить як посилання, тому жодне посилання на нього не повинно зберігатися поза цим кадром.
        //
        //
        let sym = mem::transmute::<Symbol<'_>, Symbol<'static>>(sym);
        (cb)(&super::Symbol { inner: sym });
    };

    Cache::with_global(|cache| {
        let (lib, addr) = match cache.avma_to_svma(addr as *const u8) {
            Some(pair) => pair,
            None => return,
        };

        // Нарешті, отримайте кешоване зіставлення або створіть нове зіставлення для цього файлу та оцініть інформацію про DWARF, щоб знайти file/line/name для цієї адреси.
        //
        let cx = match cache.mapping_for_lib(lib) {
            Some(cx) => cx,
            None => return,
        };
        let mut any_frames = false;
        if let Ok(mut frames) = cx.dwarf.find_frames(addr as u64) {
            while let Ok(Some(frame)) = frames.next() {
                any_frames = true;
                call(Symbol::Frame {
                    addr: addr as *mut c_void,
                    location: frame.location,
                    name: frame.function.map(|f| f.name.slice()),
                });
            }
        }
        if !any_frames {
            if let Some((object_cx, object_addr)) = cx.object.search_object_map(addr as u64) {
                if let Ok(mut frames) = object_cx.dwarf.find_frames(object_addr) {
                    while let Ok(Some(frame)) = frames.next() {
                        any_frames = true;
                        call(Symbol::Frame {
                            addr: addr as *mut c_void,
                            location: frame.location,
                            name: frame.function.map(|f| f.name.slice()),
                        });
                    }
                }
            }
        }
        if !any_frames {
            if let Some(name) = cx.object.search_symtab(addr as u64) {
                call(Symbol::Symtab {
                    addr: addr as *mut c_void,
                    name,
                });
            }
        }
    });
}

pub enum Symbol<'a> {
    /// Нам вдалося знайти інформацію про кадр для цього символу, а кадр `addr2line` всередині містить усі дрібні деталі.
    ///
    Frame {
        addr: *mut c_void,
        location: Option<addr2line::Location<'a>>,
        name: Option<&'a [u8]>,
    },
    /// Не вдалося знайти інформацію про налагодження, але ми знайшли її в таблиці символів виконуваного файлу elf.
    ///
    Symtab { addr: *mut c_void, name: &'a [u8] },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        match self {
            Symbol::Frame { name, .. } => {
                let name = name.as_ref()?;
                Some(SymbolName::new(name))
            }
            Symbol::Symtab { name, .. } => Some(SymbolName::new(name)),
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        match self {
            Symbol::Frame { addr, .. } => Some(*addr),
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        match self {
            Symbol::Frame { location, .. } => {
                let file = location.as_ref()?.file?;
                Some(BytesOrWideString::Bytes(file.as_bytes()))
            }
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn filename(&self) -> Option<&Path> {
        match self {
            Symbol::Frame { location, .. } => {
                let file = location.as_ref()?.file?;
                Some(Path::new(file))
            }
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn lineno(&self) -> Option<u32> {
        match self {
            Symbol::Frame { location, .. } => location.as_ref()?.line,
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn colno(&self) -> Option<u32> {
        match self {
            Symbol::Frame { location, .. } => location.as_ref()?.column,
            Symbol::Symtab { .. } => None,
        }
    }
}