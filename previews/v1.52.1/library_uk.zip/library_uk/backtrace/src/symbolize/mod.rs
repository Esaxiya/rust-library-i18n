use core::{fmt, str};

cfg_if::cfg_if! {
    if #[cfg(feature = "std")] {
        use std::path::Path;
        use std::prelude::v1::*;
    }
}

use super::backtrace::Frame;
use super::types::BytesOrWideString;
use core::ffi::c_void;
use rustc_demangle::{try_demangle, Demangle};

/// Визначте адресу до символу, передаючи символ до вказаного закриття.
///
/// Ця функція буде шукати дану адресу в таких областях, як локальна таблиця символів, динамічна таблиця символів або інформація про налагодження DWARF (залежно від активованої реалізації), щоб знайти символи, які можна отримати.
///
///
/// Закриття не може бути викликане, якщо роздільна здатність не може бути виконана, а також воно може бути викликане більше одного разу у разі вбудованих функцій.
///
/// Видані символи представляють виконання на вказаному `addr`, повертаючи пари file/line для цієї адреси (якщо такі є).
///
/// Зверніть увагу, що якщо у вас `Frame`, то рекомендується використовувати функцію `resolve_frame` замість цієї.
///
/// # Необхідні функції
///
/// Ця функція вимагає ввімкнення функції `std` для `backtrace` crate, а функцію `std` увімкнено за замовчуванням.
///
/// # Panics
///
/// Ця функція прагне ніколи не використовувати panic, але якщо `cb` надає panics, то деякі платформи змусять подвійний panic припинити процес.
/// Деякі платформи використовують бібліотеку C, яка внутрішньо використовує зворотні виклики, які неможливо розмотати, тому паніка з `cb` може спричинити переривання процесу.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         let ip = frame.ip();
///
///         backtrace::resolve(ip, |symbol| {
///             // ...
///         });
///
///         false // дивіться лише на верхню рамку
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve<F: FnMut(&Symbol)>(addr: *mut c_void, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_unsynchronized(addr, cb) }
}

/// Вирішіть попередньо знятий кадр із символом, передаючи його до вказаного закриття.
///
/// Цей функціонал виконує ту саму функцію, що і `resolve`, за винятком того, що він приймає `Frame` як аргумент замість адреси.
/// Це може дозволити деяким реалізаціям зворотного відстеження на платформі надати більш точну інформацію про символи або інформацію про вбудовані кадри, наприклад.
///
/// Рекомендується використовувати це, якщо можете.
///
/// # Необхідні функції
///
/// Ця функція вимагає ввімкнення функції `std` для `backtrace` crate, а функцію `std` увімкнено за замовчуванням.
///
/// # Panics
///
/// Ця функція прагне ніколи не використовувати panic, але якщо `cb` надає panics, то деякі платформи змусять подвійний panic припинити процес.
/// Деякі платформи використовують бібліотеку C, яка внутрішньо використовує зворотні виклики, які неможливо розмотати, тому паніка з `cb` може спричинити переривання процесу.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         backtrace::resolve_frame(frame, |symbol| {
///             // ...
///         });
///
///         false // дивіться лише на верхню рамку
///     });
/// }
/// ```
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve_frame<F: FnMut(&Symbol)>(frame: &Frame, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_frame_unsynchronized(frame, cb) }
}

pub enum ResolveWhat<'a> {
    Address(*mut c_void),
    Frame(&'a Frame),
}

impl<'a> ResolveWhat<'a> {
    #[allow(dead_code)]
    fn address_or_ip(&self) -> *mut c_void {
        match self {
            ResolveWhat::Address(a) => adjust_ip(*a),
            ResolveWhat::Frame(f) => adjust_ip(f.ip()),
        }
    }
}

// Значення IP із кадрів стека, як правило, є (always?) інструкцією *після* дзвінка, що є фактичним трасуванням стека.
// Символізуючи це, призводить до того, що номер filename/line випереджає і, можливо, потрапляє у порожнечу, якщо він ближче до кінця функції.
//
// Здається, це в основному завжди має місце на всіх платформах, тому ми завжди віднімаємо один із вирішеного ip, щоб вирішити його до попередньої інструкції виклику, замість того, щоб інструкція поверталася.
//
//
// В ідеалі ми б цього не робили.
// В ідеалі ми вимагали б, щоб викликаючі тут API `resolve` вручну виконували -1 та враховували, що вони хочуть інформацію про місцезнаходження для попередньої *інструкції*, а не поточної.
// В ідеалі ми б також виставили на `Frame`, якщо ми дійсно є адресою наступної інструкції або поточної.
//
// Поки що це досить нішева проблема, тому ми просто внутрішньо завжди віднімаємо одну.
// Споживачі повинні продовжувати працювати і отримувати досить хороші результати, тому ми повинні бути достатньо хорошими.
//
//
//
//
//
//
fn adjust_ip(a: *mut c_void) -> *mut c_void {
    if a.is_null() {
        a
    } else {
        (a as usize - 1) as *mut c_void
    }
}

/// Так само, як `resolve`, тільки небезпечний, оскільки несинхронізований.
///
/// Ця функція не має гарантій синхронізації, але доступна, коли функція `std` цього crate не скомпільована.
/// Дивіться функцію `resolve` для отримання додаткової документації та прикладів.
///
/// # Panics
///
/// Див. Інформацію про `resolve` щодо застережень щодо паніки `cb`.
///
pub unsafe fn resolve_unsynchronized<F>(addr: *mut c_void, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Address(addr), &mut cb)
}

/// Так само, як `resolve_frame`, тільки небезпечний, оскільки несинхронізований.
///
/// Ця функція не має гарантій синхронізації, але доступна, коли функція `std` цього crate не скомпільована.
/// Дивіться функцію `resolve_frame` для отримання додаткової документації та прикладів.
///
/// # Panics
///
/// Див. Інформацію про `resolve_frame` щодо застережень щодо паніки `cb`.
///
pub unsafe fn resolve_frame_unsynchronized<F>(frame: &Frame, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Frame(frame), &mut cb)
}

/// Portrait, що представляє роздільну здатність символу у файлі.
///
/// Цей Portrait отримується як об'єкт Portrait до закриття, наданого функції `backtrace::resolve`, і він фактично відправляється, оскільки невідомо, яка реалізація стоїть за ним.
///
///
/// Символ може давати контекстну інформацію про функцію, наприклад ім'я, ім'я файлу, номер рядка, точна адреса тощо.
/// Однак не вся інформація завжди доступна в символі, тому всі методи повертають `Option`.
///
///
pub struct Symbol {
    // TODO: це обмеження на все життя потрібно з часом зберегти до `Symbol`,
    // але це в даний час кардинальна зміна.
    // Наразі це безпечно, оскільки `Symbol` передається лише за посиланням і не може бути клонованим.
    inner: imp::Symbol<'static>,
}

impl Symbol {
    /// Повертає ім'я цієї функції.
    ///
    /// Повернута структура може бути використана для запиту різних властивостей щодо імені символу:
    ///
    ///
    /// * Реалізація `Display` роздрукує демонтований символ.
    /// * Можна отримати вихідне значення `str` символу (якщо воно дійсне utf-8).
    /// * Можна отримати доступ до необроблених байт для імені символу.
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.inner.name()
    }

    /// Повертає початкову адресу цієї функції.
    pub fn addr(&self) -> Option<*mut c_void> {
        self.inner.addr().map(|p| p as *mut _)
    }

    /// Повертає необроблене ім'я файлу як фрагмент.
    /// Це переважно корисно для середовищ `no_std`.
    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.inner.filename_raw()
    }

    /// Повертає номер стовпця, де цей символ виконується в даний момент.
    ///
    /// Наразі лише gimli надає значення тут і навіть тоді, лише якщо `filename` повертає `Some`, і, отже, тоді воно підпадає під подібні застереження.
    ///
    pub fn colno(&self) -> Option<u32> {
        self.inner.colno()
    }

    /// Повертає номер рядка, де цей символ виконується в даний момент.
    ///
    /// Це повертане значення, як правило, `Some`, якщо `filename` повертає `Some`, і, отже, зазнає подібних застережень.
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.inner.lineno()
    }

    /// Повертає ім'я файлу, де була визначена ця функція.
    ///
    /// Наразі це доступно лише тоді, коли використовується libbacktrace або gimli (наприклад,
    /// unix платформи інші) та коли двійковий файл компілюється за допомогою debuginfo.
    /// Якщо жодна з цих умов не дотримана, це, швидше за все, поверне `None`.
    ///
    /// # Необхідні функції
    ///
    /// Ця функція вимагає ввімкнення функції `std` для `backtrace` crate, а функцію `std` увімкнено за замовчуванням.
    ///
    ///
    #[cfg(feature = "std")]
    #[allow(unreachable_code)]
    pub fn filename(&self) -> Option<&Path> {
        self.inner.filename()
    }
}

impl fmt::Debug for Symbol {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let mut d = f.debug_struct("Symbol");
        if let Some(name) = self.name() {
            d.field("name", &name);
        }
        if let Some(addr) = self.addr() {
            d.field("addr", &addr);
        }

        #[cfg(feature = "std")]
        {
            if let Some(filename) = self.filename() {
                d.field("filename", &filename);
            }
        }

        if let Some(lineno) = self.lineno() {
            d.field("lineno", &lineno);
        }
        d.finish()
    }
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        // Можливо, проаналізований символ C++ , якщо аналіз спотвореного символу як Rust не вдався.
        //
        struct OptionCppSymbol<'a>(Option<::cpp_demangle::BorrowedSymbol<'a>>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(input: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(::cpp_demangle::BorrowedSymbol::new(input).ok())
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(None)
            }
        }
    } else {
        use core::marker::PhantomData;

        // Обов`язково зберігайте цей нульовий розмір, щоб при відключенні функція `cpp_demangle` не мала витрат.
        //
        struct OptionCppSymbol<'a>(PhantomData<&'a ()>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(_: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }
        }
    }
}

/// Обгортка навколо імені символу для забезпечення ергономічних аксесуарів до виведеного імені, необроблених байтів, необробленого рядка тощо.
///
// Дозволити мертвий код, коли функція `cpp_demangle` не ввімкнена.
#[allow(dead_code)]
pub struct SymbolName<'a> {
    bytes: &'a [u8],
    demangled: Option<Demangle<'a>>,
    cpp_demangled: OptionCppSymbol<'a>,
}

impl<'a> SymbolName<'a> {
    /// Створює нову назву символу з необроблених базових байт.
    pub fn new(bytes: &'a [u8]) -> SymbolName<'a> {
        let str_bytes = str::from_utf8(bytes).ok();
        let demangled = str_bytes.and_then(|s| try_demangle(s).ok());

        let cpp = if demangled.is_none() {
            OptionCppSymbol::parse(bytes)
        } else {
            OptionCppSymbol::none()
        };

        SymbolName {
            bytes: bytes,
            demangled: demangled,
            cpp_demangled: cpp,
        }
    }

    /// Повертає необроблену назву символу (mangled) як `str`, якщо символ є дійсним utf-8.
    ///
    /// Використовуйте реалізацію `Display`, якщо ви хочете демонтувати версію.
    pub fn as_str(&self) -> Option<&'a str> {
        self.demangled
            .as_ref()
            .map(|s| s.as_str())
            .or_else(|| str::from_utf8(self.bytes).ok())
    }

    /// Повертає ім'я необробленого символу як список байтів
    pub fn as_bytes(&self) -> &'a [u8] {
        self.bytes
    }
}

fn format_symbol_name(
    fmt: fn(&str, &mut fmt::Formatter<'_>) -> fmt::Result,
    mut bytes: &[u8],
    f: &mut fmt::Formatter<'_>,
) -> fmt::Result {
    while bytes.len() > 0 {
        match str::from_utf8(bytes) {
            Ok(name) => {
                fmt(name, f)?;
                break;
            }
            Err(err) => {
                fmt("\u{FFFD}", f)?;

                match err.error_len() {
                    Some(len) => bytes = &bytes[err.valid_up_to() + len..],
                    None => break,
                }
            }
        }
    }
    Ok(())
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else if let Some(ref cpp) = self.cpp_demangled.0 {
                    cpp.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    } else {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    }
}

cfg_if::cfg_if! {
    if #[cfg(all(feature = "std", feature = "cpp_demangle"))] {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                use std::fmt::Write;

                if let Some(ref s) = self.demangled {
                    return s.fmt(f)
                }

                // Це може надрукувати, якщо демонтований символ насправді не є дійсним, тому обробляйте помилку тут витончено, не поширюючи її назовні.
                //
                //
                if let Some(ref cpp) = self.cpp_demangled.0 {
                    let mut s = String::new();
                    if write!(s, "{}", cpp).is_ok() {
                        return s.fmt(f)
                    }
                }

                format_symbol_name(fmt::Debug::fmt, self.bytes, f)
            }
        }
    } else {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Debug::fmt, self.bytes, f)
                }
            }
        }
    }
}

/// Спроба повернути ту кешовану пам`ять, яка використовувалася для символізації адрес.
///
/// Цей метод спробує звільнити будь-які глобальні структури даних, які інакше були кешовані глобально або в потоці, які зазвичай представляють аналізовану інформацію DWARF або подібну.
///
///
/// # Caveats
///
/// Хоча ця функція завжди доступна, вона насправді нічого не робить для більшості реалізацій.
/// Бібліотеки, такі як dbghelp або libbacktrace, не надають засобів для вивільнення стану та управління виділеною пам'яттю.
/// На даний момент функція `gimli-symbolize` цього crate є єдиною функцією, де ця функція має якийсь ефект.
///
///
///
#[cfg(feature = "std")]
pub fn clear_symbol_cache() {
    let _guard = crate::lock::lock();
    unsafe {
        imp::clear_symbol_cache();
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        mod miri;
        use miri as imp;
    } else if #[cfg(all(windows, target_env = "msvc", not(target_vendor = "uwp")))] {
        mod dbghelp;
        use dbghelp as imp;
    } else if #[cfg(all(
        feature = "libbacktrace",
        any(unix, all(windows, not(target_vendor = "uwp"), target_env = "gnu")),
        not(target_os = "fuchsia"),
        not(target_os = "emscripten"),
        not(target_env = "uclibc"),
        not(target_env = "libnx"),
    ))] {
        mod libbacktrace;
        use libbacktrace as imp;
    } else if #[cfg(all(
        feature = "gimli-symbolize",
        any(unix, windows),
        not(target_vendor = "uwp"),
        not(target_os = "emscripten"),
    ))] {
        mod gimli;
        use gimli as imp;
    } else {
        mod noop;
        use noop as imp;
    }
}