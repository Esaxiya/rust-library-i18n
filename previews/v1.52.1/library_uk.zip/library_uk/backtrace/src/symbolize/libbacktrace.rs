//! Стратегія символізації із використанням коду синтаксичного аналізу DWARF у libbacktrace.
//!
//! Бібліотека libbacktrace C, яка зазвичай поширюється разом із gcc, підтримує не тільки генерування зворотного трасування (яке ми насправді не використовуємо), але також символізує зворотне відстеження та обробку інформації про налагодження карликів про такі речі, як вбудовані кадри та ін.
//!
//!
//! Це порівняно складно через безліч різноманітних проблем, але основна ідея:
//!
//! * Спочатку ми називаємо `backtrace_syminfo`.Це отримує інформацію про символи з динамічної таблиці символів, якщо ми можемо.
//! * Далі ми називаємо `backtrace_pcinfo`.Це проаналізує таблиці debuginfo, якщо вони доступні, і дозволить нам відновити інформацію про вбудовані кадри, імена файлів, номери рядків тощо.
//!
//! Існує багато хитрощів щодо того, щоб перетворити таблиці карликів на libbacktrace, але, сподіваємось, це ще не кінець світу і це досить зрозуміло, коли читаєте нижче.
//!
//! Це стратегія символізації за замовчуванням для платформ, що не є MSVC та не OSX.У libstd це стратегія за замовчуванням для OSX.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(bad_style)]

extern crate backtrace_sys as bt;

use core::{marker, ptr, slice};
use libc::{self, c_char, c_int, c_void, uintptr_t};

use crate::symbolize::{ResolveWhat, SymbolName};
use crate::types::BytesOrWideString;

pub enum Symbol<'a> {
    Syminfo {
        pc: uintptr_t,
        symname: *const c_char,
        _marker: marker::PhantomData<&'a ()>,
    },
    Pcinfo {
        pc: uintptr_t,
        filename: *const c_char,
        lineno: c_int,
        function: *const c_char,
        symname: *const c_char,
    },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        let symbol = |ptr: *const c_char| unsafe {
            if ptr.is_null() {
                None
            } else {
                let len = libc::strlen(ptr);
                Some(SymbolName::new(slice::from_raw_parts(
                    ptr as *const u8,
                    len,
                )))
            }
        };
        match *self {
            Symbol::Syminfo { symname, .. } => symbol(symname),
            Symbol::Pcinfo {
                function, symname, ..
            } => {
                // Якщо можливо, віддайте перевагу імені `function`, яке походить від debuginfo, і, як правило, може бути більш точним для вбудованих кадрів, наприклад.
                // Якщо цього немає, поверніться до імені таблиці символів, зазначеного в `symname`.
                //
                // Зверніть увагу, що іноді `function` може відчувати себе дещо менш точним, наприклад, перерахований як `try<i32,closure>`-це замість `std::panicking::try::do_call`.
                //
                // Не зовсім зрозуміло чому, але загалом назва `function` видається більш точною.
                //
                //
                //
                if let Some(sym) = symbol(function) {
                    return Some(sym);
                }
                symbol(symname)
            }
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        let pc = match *self {
            Symbol::Syminfo { pc, .. } => pc,
            Symbol::Pcinfo { pc, .. } => pc,
        };
        if pc == 0 {
            None
        } else {
            Some(pc as *mut _)
        }
    }

    fn filename_bytes(&self) -> Option<&[u8]> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { filename, .. } => {
                let ptr = filename as *const u8;
                if ptr.is_null() {
                    return None;
                }
                unsafe {
                    let len = libc::strlen(filename);
                    Some(slice::from_raw_parts(ptr, len))
                }
            }
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.filename_bytes().map(BytesOrWideString::Bytes)
    }

    #[cfg(feature = "std")]
    pub fn filename(&self) -> Option<&::std::path::Path> {
        use std::path::Path;

        #[cfg(unix)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::ffi::OsStr;
            use std::os::unix::prelude::*;
            Some(Path::new(OsStr::from_bytes(bytes)))
        }

        #[cfg(windows)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::str;
            str::from_utf8(bytes).ok().map(Path::new)
        }

        self.filename_bytes().and_then(bytes2path)
    }

    pub fn lineno(&self) -> Option<u32> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { lineno, .. } => Some(lineno as u32),
        }
    }

    pub fn colno(&self) -> Option<u32> {
        None
    }
}

extern "C" fn error_cb(_data: *mut c_void, _msg: *const c_char, _errnum: c_int) {
    // поки що нічого не робити
}

/// Тип вказівника `data`, переданий у `syminfo_cb`
struct SyminfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    pc: usize,
}

extern "C" fn syminfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    symname: *const c_char,
    _symval: uintptr_t,
    _symsize: uintptr_t,
) {
    let mut bomb = crate::Bomb { enabled: true };

    // Як тільки цей зворотний виклик викликається з `backtrace_syminfo`, коли ми починаємо вирішувати, ми переходимо до виклику `backtrace_pcinfo`.
    // Функція `backtrace_pcinfo` перевірятиме інформацію про налагодження та намагатиметься виконувати такі дії, як відновлення інформації file/line, а також вбудовані кадри.
    // Зверніть увагу, що `backtrace_pcinfo` може вийти з ладу або не зробити багато, якщо немає інформації про налагодження, тому, якщо це трапиться, ми обов'язково зателефонуємо до зворотного виклику з принаймні одним символом від `syminfo_cb`.
    //
    //
    //
    //
    unsafe {
        let syminfo_state = &mut *(data as *mut SyminfoState<'_>);
        let mut pcinfo_state = PcinfoState {
            symname,
            called: false,
            cb: syminfo_state.cb,
        };
        bt::backtrace_pcinfo(
            init_state(),
            syminfo_state.pc as uintptr_t,
            pcinfo_cb,
            error_cb,
            &mut pcinfo_state as *mut _ as *mut _,
        );
        if !pcinfo_state.called {
            (pcinfo_state.cb)(&super::Symbol {
                inner: Symbol::Syminfo {
                    pc: pc,
                    symname: symname,
                    _marker: marker::PhantomData,
                },
            });
        }
    }

    bomb.enabled = false;
}

/// Тип вказівника `data`, переданий у `pcinfo_cb`
struct PcinfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    symname: *const c_char,
    called: bool,
}

extern "C" fn pcinfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    filename: *const c_char,
    lineno: c_int,
    function: *const c_char,
) -> c_int {
    let mut bomb = crate::Bomb { enabled: true };

    unsafe {
        let state = &mut *(data as *mut PcinfoState<'_>);
        state.called = true;
        (state.cb)(&super::Symbol {
            inner: Symbol::Pcinfo {
                pc: pc,
                filename: filename,
                lineno: lineno,
                symname: state.symname,
                function,
            },
        });
    }

    bomb.enabled = false;
    return 0;
}

// API libbacktrace підтримує створення стану, але не підтримує знищення стану.
// Я особисто вважаю, що це означає, що держава має бути створена, а потім жити вічно.
//
// Я хотів би зареєструвати обробник at_exit(), який очищає цей стан, але libbacktrace не дає можливості зробити це.
//
// За цих обмежень ця функція має статично кешований стан, який обчислюється при першому запиті.
//
// Пам'ятайте, що зворотне відстеження всього відбувається послідовно (один глобальний замок).
//
// Зауважте, що відсутність синхронізації тут пов`язана з вимогою, щоб `resolve` синхронізувався зовні.
//
//
//
unsafe fn init_state() -> *mut bt::backtrace_state {
    static mut STATE: *mut bt::backtrace_state = 0 as *mut _;

    if !STATE.is_null() {
        return STATE;
    }

    STATE = bt::backtrace_create_state(
        load_filename(),
        // Не використовуйте безпечні можливості libbacktrace, оскільки ми завжди називаємо його синхронізовано.
        //
        0,
        error_cb,
        ptr::null_mut(), // відсутність зайвих даних
    );

    return STATE;

    // Зауважте, що для того, щоб libbacktrace взагалі працював, йому потрібно знайти інформацію про налагодження DWARF для поточного виконуваного файлу.Зазвичай це робиться за допомогою ряду механізмів, включаючи, але не обмежуючись:
    //
    // * /proc/self/exe на підтримуваних платформах
    // * Ім'я файлу було передано явно під час створення стану
    //
    // Бібліотека libbacktrace-це велика пачка коду C.Це, природно, означає, що він має вразливі місця в галузі безпеки пам`яті, особливо під час роботи з деформованим debuginfo.
    // Libstd стикався з багатьма з них історично.
    //
    // Якщо використовується /proc/self/exe, тоді ми можемо їх ігнорувати, оскільки ми вважаємо, що libbacktrace-це "mostly correct", інакше не робить дивних речей з інформацією про налагодження карликів "attempted to be correct".
    //
    //
    // Однак, якщо ми передаємо ім'я файлу, це можливо на деяких платформах (наприклад, BSD), де шкідливий актор може спричинити розміщення довільного файлу в цьому місці.
    // Це означає, що якщо ми повідомляємо libbacktrace про ім'я файлу, він може використовувати довільний файл, можливо, спричиняючи сегментації.
    // Якщо ми нічого не скажемо libbacktrace, тоді він не буде робити нічого на платформах, які не підтримують шляхи, такі як /proc/self/exe!
    //
    // З огляду на все, що ми намагаємось якомога більше *не* передавати ім'я файлу, але ми повинні на платформах, які взагалі не підтримують /proc/self/exe.
    //
    //
    //
    //
    //
    //
    //
    //
    cfg_if::cfg_if! {
        if #[cfg(any(target_os = "macos", target_os = "ios"))] {
            // Зауважте, що в ідеалі ми б використовували `std::env::current_exe`, але тут не може бути потрібний `std`.
            //
            // Використовуйте `_NSGetExecutablePath` для завантаження поточного виконуваного шляху у статичну область (яку, якщо вона занадто мала, просто відмовтеся).
            //
            //
            // Зверніть увагу, що ми серйозно довіряємо libbacktrace тут, щоб не померти на корумпованих виконуваних файлах, але це, безумовно, робить ...
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                const N: usize = 256;
                static mut BUF: [u8; N] = [0; N];
                extern {
                    fn _NSGetExecutablePath(
                        buf: *mut libc::c_char,
                        bufsize: *mut u32,
                    ) -> libc::c_int;
                }
                let mut sz: u32 = BUF.len() as u32;
                let ptr = BUF.as_mut_ptr() as *mut libc::c_char;
                if _NSGetExecutablePath(ptr, &mut sz) == 0 {
                    ptr
                } else {
                    ptr::null()
                }
            }
        } else if #[cfg(windows)] {
            use crate::windows::*;

            // Windows має режим відкриття файлів, коли після відкриття його неможливо видалити.
            // Це загалом те, що ми хочемо тут, тому що хочемо переконатись, що наш виконуваний файл не змінюється з-під нас після того, як ми передамо його на libbacktrace, сподіваючись, пом'якшуючи можливість передачі довільних даних у libbacktrace (що може бути неправильно оброблено).
            //
            //
            // Враховуючи, що ми тут трохи танцюємо, щоб спробувати отримати якийсь замок на власному іміджі:
            //
            // * Отримайте дескриптор поточного процесу, завантажте його ім'я файлу.
            // * Відкрийте файл із цим ім'ям за допомогою правильних прапорів.
            // * Перезавантажте ім`я файлу поточного процесу, переконавшись, що воно однакове
            //
            // Якщо це все проходить, ми теоретично дійсно відкрили файл нашого процесу, і ми гарантовано це не змінимо.FWIW купу цього скопійовано з libstd історично, тому це моя найкраща інтерпретація того, що відбувалося.
            //
            //
            //
            //
            //
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                load_filename_opt().unwrap_or(ptr::null())
            }

            unsafe fn load_filename_opt() -> Result<*const libc::c_char, ()> {
                const N: usize = 256;
                // Це живе в статичній пам`яті, щоб ми могли його повернути ..
                static mut BUF: [i8; N] = [0; N];
                // ... і це живе на стосі, оскільки це тимчасово
                let mut stack_buf = [0; N];
                let name1 = query_full_name(&mut BUF)?;

                let handle = CreateFileA(
                    name1.as_ptr(),
                    GENERIC_READ,
                    FILE_SHARE_READ | FILE_SHARE_WRITE,
                    ptr::null_mut(),
                    OPEN_EXISTING,
                    0,
                    ptr::null_mut(),
                );
                if handle.is_null() {
                    return Err(());
                }

                let name2 = query_full_name(&mut stack_buf)?;
                if name1 != name2 {
                    CloseHandle(handle);
                    return Err(())
                }
                // навмисно просочити сюди `handle`, оскільки його відкриття повинно зберегти нашу блокування імені цього файлу.
                //
                Ok(name1.as_ptr())
            }

            unsafe fn query_full_name(buf: &mut [i8]) -> Result<&[i8], ()> {
                let dll = GetModuleHandleA(b"kernel32.dll\0".as_ptr() as *const i8);
                if dll.is_null() {
                    return Err(())
                }
                let ptrQueryFullProcessImageNameA =
                    GetProcAddress(dll, b"QueryFullProcessImageNameA\0".as_ptr() as *const _) as usize;
                if ptrQueryFullProcessImageNameA == 0
                {
                    return Err(());
                }
                use core::mem;
                let p1 = OpenProcess(PROCESS_QUERY_INFORMATION, FALSE, GetCurrentProcessId());
                let mut len = buf.len() as u32;
                let pfnQueryFullProcessImageNameA : extern "system" fn(
                    hProcess: HANDLE,
                    dwFlags: DWORD,
                    lpExeName: LPSTR,
                    lpdwSize: PDWORD,
                ) -> BOOL = mem::transmute(ptrQueryFullProcessImageNameA);

                let rc = pfnQueryFullProcessImageNameA(p1, 0, buf.as_mut_ptr(), &mut len);
                CloseHandle(p1);

                // Ми хочемо повернути фрагмент, який закінчується нулем, тому, якщо все було заповнене і воно дорівнює загальній довжині, тоді прирівняйте це до відмови.
                //
                //
                // В іншому випадку при поверненні успіху переконайтеся, що нульовий байт включений у зріз.
                //
                //
                if rc == 0 || len == buf.len() as u32 {
                    Err(())
                } else {
                    assert_eq!(buf[len as usize], 0);
                    Ok(&buf[..(len + 1) as usize])
                }
            }
        } else if #[cfg(target_os = "vxworks")] {
            unsafe fn load_filename() -> *const libc::c_char {
                use libc;
                use core::mem;

                const N: usize = libc::VX_RTP_NAME_LENGTH as usize + 1;
                static mut BUF: [libc::c_char; N] = [0; N];

                let mut rtp_desc : libc::RTP_DESC = mem::zeroed();
                if (libc::rtpInfoGet(0, &mut rtp_desc as *mut libc::RTP_DESC) == 0) {
                    BUF.copy_from_slice(&rtp_desc.pathName);
                    BUF.as_ptr()
                } else {
                    ptr::null()
                }
            }
        } else {
            unsafe fn load_filename() -> *const libc::c_char {
                ptr::null()
            }
        }
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let symaddr = what.address_or_ip() as usize;

    // Помилки зворотного відстеження в даний час помічені під килим
    let state = init_state();
    if state.is_null() {
        return;
    }

    // Зателефонуйте API `backtrace_syminfo`, який (після читання коду) повинен викликати `syminfo_cb` рівно один раз (або не вдасться з помилкою, імовірно).
    // Потім ми обробляємо більше в рамках `syminfo_cb`.
    //
    // Зауважте, що ми робимо це, оскільки `syminfo` звертається до таблиці символів, знаходячи імена символів, навіть якщо в двійковому файлі немає інформації про налагодження.
    //
    //
    let mut syminfo_state = SyminfoState { pc: symaddr, cb };
    bt::backtrace_syminfo(
        state,
        symaddr as uintptr_t,
        syminfo_cb,
        error_cb,
        &mut syminfo_state as *mut _ as *mut _,
    );
}

pub unsafe fn clear_symbol_cache() {}