// зараз використовується лише на Linux, тому дозволяйте мертвий код деінде
#![cfg_attr(not(target_os = "linux"), allow(dead_code))]

use alloc::vec;
use alloc::vec::Vec;
use core::cell::UnsafeCell;

/// Простий розподільник арен для байтових буферів.
pub struct Stash {
    buffers: UnsafeCell<Vec<Vec<u8>>>,
}

impl Stash {
    pub fn new() -> Stash {
        Stash {
            buffers: UnsafeCell::new(Vec::new()),
        }
    }

    /// Виділяє буфер зазначеного розміру і повертає до нього змінне посилання.
    ///
    pub fn allocate(&self, size: usize) -> &mut [u8] {
        // БЕЗПЕКА: це єдина функція, яка коли-небудь створює мутабель
        // посилання на `self.buffers`.
        let buffers = unsafe { &mut *self.buffers.get() };
        let i = buffers.len();
        buffers.push(vec![0; size]);
        // БЕЗПЕКА: ми ніколи не видаляємо елементи з `self.buffers`, тому посилання
        // дані всередині будь-якого буфера житимуть до тих пір, поки живе `self`.
        &mut buffers[i]
    }
}