use core::ffi::c_void;
use core::fmt;

/// Перевіряє поточний стек викликів, передаючи всі активні кадри в закриття, передбачене для обчислення трасування стека.
///
/// Ця функція є робочим конем цієї бібліотеки при обчисленні стеків стеків для програми.Дане закриття `cb`-це екземпляри `Frame`, які представляють інформацію про цей кадр викликів у стеку.
/// Закриття дається кадрами зверху вниз (спочатку нещодавно названими функціями).
///
/// Повернене значення закриття вказує на те, чи слід продовжувати зворотне відстеження.Повернене значення `false` припиняє зворотне відстеження і негайно повертається.
///
/// Після придбання `Frame` ви, швидше за все, захочете зателефонувати до `backtrace::resolve`, щоб перетворити `ip` (вказівник інструкції) або адресу символу в `Symbol`, через яку можна дізнатись ім'я та/або ім'я файлу/номер рядка.
///
///
/// Зверніть увагу, що це функція відносно низького рівня, і якщо ви хочете, наприклад, зафіксувати зворотну трасу, яка буде перевірена пізніше, тоді тип `Backtrace` може бути більш доречним.
///
/// # Необхідні функції
///
/// Ця функція вимагає ввімкнення функції `std` для `backtrace` crate, а функцію `std` увімкнено за замовчуванням.
///
/// # Panics
///
/// Ця функція прагне ніколи не використовувати panic, але якщо `cb` надає panics, то деякі платформи змусять подвійний panic припинити процес.
/// Деякі платформи використовують бібліотеку C, яка внутрішньо використовує зворотні виклики, які неможливо розмотати, тому паніка з `cb` може спричинити переривання процесу.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         // ...
///
///         true // продовжити зворотний шлях
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn trace<F: FnMut(&Frame) -> bool>(cb: F) {
    let _guard = crate::lock::lock();
    unsafe { trace_unsynchronized(cb) }
}

/// Так само, як `trace`, тільки небезпечний, оскільки несинхронізований.
///
/// Ця функція не має гарантій синхронізації, але доступна, коли функція `std` цього crate не скомпільована.
/// Дивіться функцію `trace` для отримання додаткової документації та прикладів.
///
/// # Panics
///
/// Див. Інформацію про `trace` щодо застережень щодо паніки `cb`.
///
pub unsafe fn trace_unsynchronized<F: FnMut(&Frame) -> bool>(mut cb: F) {
    trace_imp(&mut cb)
}

/// Portrait, що представляє один кадр зворотного трасування, поступається функції `trace` цього crate.
///
/// Закриття функції трасування буде видано кадрами, і кадр фактично відправляється, оскільки основна реалізація не завжди відома до часу виконання.
///
///
///
#[derive(Clone)]
pub struct Frame {
    pub(crate) inner: FrameImp,
}

impl Frame {
    /// Повертає поточний вказівник інструкції цього кадру.
    ///
    /// Зазвичай це наступна інструкція для виконання у фреймі, але не всі реалізації перелічують це зі 100% точністю (але, як правило, це досить близько).
    ///
    ///
    /// Рекомендується передати це значення `backtrace::resolve`, щоб перетворити його на ім'я символу.
    ///
    ///
    pub fn ip(&self) -> *mut c_void {
        self.inner.ip()
    }

    /// Повертає поточний покажчик стека цього кадру.
    ///
    /// У тому випадку, якщо серверний сервер не може відновити покажчик стека для цього кадру, повертається нульовий покажчик.
    ///
    pub fn sp(&self) -> *mut c_void {
        self.inner.sp()
    }

    /// Повертає адресу початкового символу кадру цієї функції.
    ///
    /// Це спробує перемотати покажчик команд, повернутий `ip`, на початок функції, повернувши це значення.
    ///
    /// Однак у деяких випадках бекенди просто повертають `ip` з цієї функції.
    ///
    /// Повернене значення іноді може бути використано, якщо `backtrace::resolve` не вдався на `ip`, наведеному вище.
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.inner.symbol_address()
    }

    /// Повертає базову адресу модуля, до якого належить кадр.
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.inner.module_base_address()
    }
}

impl fmt::Debug for Frame {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Frame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

cfg_if::cfg_if! {
    // Це має бути на першому місці, щоб забезпечити пріоритет Miri над головною платформою
    //
    if #[cfg(miri)] {
        pub(crate) mod miri;
        use self::miri::trace as trace_imp;
        pub(crate) use self::miri::Frame as FrameImp;
    } else if #[cfg(
        any(
            all(
                unix,
                not(target_os = "emscripten"),
                not(all(target_os = "ios", target_arch = "arm")),
            ),
            all(
                target_env = "sgx",
                target_vendor = "fortanix",
            ),
        )
    )] {
        mod libunwind;
        use self::libunwind::trace as trace_imp;
        pub(crate) use self::libunwind::Frame as FrameImp;
    } else if #[cfg(all(windows, not(target_vendor = "uwp")))] {
        mod dbghelp;
        use self::dbghelp::trace as trace_imp;
        pub(crate) use self::dbghelp::Frame as FrameImp;
        #[cfg(target_env = "msvc")] // використовується лише в dbghelp символізують
        pub(crate) use self::dbghelp::StackFrame;
    } else {
        mod noop;
        use self::noop::trace as trace_imp;
        pub(crate) use self::noop::Frame as FrameImp;
    }
}