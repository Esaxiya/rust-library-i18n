#[cfg(feature = "std")]
use super::{BacktraceFrame, BacktraceSymbol};
use super::{BytesOrWideString, Frame, SymbolName};
use core::ffi::c_void;
use core::fmt;

const HEX_WIDTH: usize = 2 + 2 * core::mem::size_of::<usize>();

#[cfg(target_os = "fuchsia")]
mod fuchsia;

/// Форматор для зворотних слідів.
///
/// Цей тип можна використовувати для друку зворотного сліду незалежно від того, звідки береться сам зворотний слід.
/// Якщо у вас тип `Backtrace`, тоді його реалізація `Debug` вже використовує цей формат друку.
///
pub struct BacktraceFmt<'a, 'b> {
    fmt: &'a mut fmt::Formatter<'b>,
    frame_index: usize,
    format: PrintFmt,
    print_path:
        &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result + 'b),
}

/// Стилі друку, які ми можемо надрукувати
#[derive(Copy, Clone, Eq, PartialEq)]
pub enum PrintFmt {
    /// Друкує меншу зворотну трасування, яка в ідеалі містить лише відповідну інформацію
    Short,
    /// Друкує зворотну трасування, що містить всю можливу інформацію
    Full,
    #[doc(hidden)]
    __Nonexhaustive,
}

impl<'a, 'b> BacktraceFmt<'a, 'b> {
    /// Створіть новий `BacktraceFmt`, який запише вихідні дані у наданий `fmt`.
    ///
    /// Аргумент `format` керуватиме стилем, в якому друкується зворотне відстеження, а аргумент `print_path` буде використовуватися для друку екземплярів імен файлів `BytesOrWideString`.
    /// Цей тип сам по собі не друкує імена файлів, але для цього потрібен цей зворотний дзвінок.
    ///
    ///
    ///
    pub fn new(
        fmt: &'a mut fmt::Formatter<'b>,
        format: PrintFmt,
        print_path: &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result
                     + 'b),
    ) -> Self {
        BacktraceFmt {
            fmt,
            frame_index: 0,
            format,
            print_path,
        }
    }

    /// Друкує преамбулу для зворотного сліду, який збирається надрукувати.
    ///
    /// Це потрібно на деяких платформах, щоб зворотні відстеження були повністю символізовані пізніше, інакше це повинен бути лише перший метод, який ви викликаєте після створення `BacktraceFmt`.
    ///
    ///
    pub fn add_context(&mut self) -> fmt::Result {
        #[cfg(target_os = "fuchsia")]
        fuchsia::print_dso_context(self.fmt)?;
        Ok(())
    }

    /// Додає кадр до виводу зворотного відстеження.
    ///
    /// Цей коміт повертає екземпляр RAII `BacktraceFrameFmt`, який можна використовувати для фактичного друку кадру, і при знищенні він збільшить лічильник кадрів.
    ///
    ///
    pub fn frame(&mut self) -> BacktraceFrameFmt<'_, 'a, 'b> {
        BacktraceFrameFmt {
            fmt: self,
            symbol_index: 0,
        }
    }

    /// Завершує вихід зворотного трасування.
    ///
    /// Наразі це заборонено, але додано для сумісності future із форматами зворотного відстеження.
    ///
    pub fn finish(&mut self) -> fmt::Result {
        // В даний час не застосовується-включаючи цей hook, щоб дозволити додавання future.
        Ok(())
    }
}

/// Форматор лише для одного кадру зворотного трасування.
///
/// Цей тип створений функцією `BacktraceFmt::frame`.
pub struct BacktraceFrameFmt<'fmt, 'a, 'b> {
    fmt: &'fmt mut BacktraceFmt<'a, 'b>,
    symbol_index: usize,
}

impl BacktraceFrameFmt<'_, '_, '_> {
    /// Друкує `BacktraceFrame` за допомогою цього форматування фреймів.
    ///
    /// Це буде рекурсивно друкувати всі екземпляри `BacktraceSymbol` у межах `BacktraceFrame`.
    ///
    /// # Необхідні функції
    ///
    /// Ця функція вимагає ввімкнення функції `std` для `backtrace` crate, а функцію `std` увімкнено за замовчуванням.
    ///
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_frame(&mut self, frame: &BacktraceFrame) -> fmt::Result {
        let symbols = frame.symbols();
        for symbol in symbols {
            self.backtrace_symbol(frame, symbol)?;
        }
        if symbols.is_empty() {
            self.print_raw(frame.ip(), None, None, None)?;
        }
        Ok(())
    }

    /// Друкує `BacktraceSymbol` у межах `BacktraceFrame`.
    ///
    /// # Необхідні функції
    ///
    /// Ця функція вимагає ввімкнення функції `std` для `backtrace` crate, а функцію `std` увімкнено за замовчуванням.
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_symbol(
        &mut self,
        frame: &BacktraceFrame,
        symbol: &BacktraceSymbol,
    ) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            // TODO: це не чудово, що ми в кінцевому підсумку нічого не друкуємо
            // з не-utf8 іменами файлів.
            // На щастя, майже все є utf8, тому це не повинно бути надто погано.
            symbol
                .filename()
                .and_then(|p| Some(BytesOrWideString::Bytes(p.to_str()?.as_bytes()))),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// Друкує необроблені трасовані `Frame` і `Symbol`, як правило, з необроблених зворотних викликів цього crate.
    ///
    pub fn symbol(&mut self, frame: &Frame, symbol: &super::Symbol) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            symbol.filename_raw(),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// Додає необроблений кадр до результату зворотного відстеження.
    ///
    /// Цей метод, на відміну від попереднього, бере необроблені аргументи на випадок, якщо вони надходять з різних місць.
    /// Зверніть увагу, що це може бути викликано кілька разів для одного кадру.
    ///
    pub fn print_raw(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
    ) -> fmt::Result {
        self.print_raw_with_column(frame_ip, symbol_name, filename, lineno, None)
    }

    /// Додає необроблений кадр до результату зворотного відстеження, включаючи інформацію про стовпець.
    ///
    /// Цей метод, як і попередній, бере необроблені аргументи на випадок, якщо вони надходять з різних місць.
    /// Зверніть увагу, що це може бути викликано кілька разів для одного кадру.
    ///
    pub fn print_raw_with_column(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Фуксія не здатна символізувати в процесі, тому вона має спеціальний формат, який можна використовувати для символізації пізніше.
        // Роздрукуйте це замість друку адрес у нашому власному форматі тут.
        //
        if cfg!(target_os = "fuchsia") {
            self.print_raw_fuchsia(frame_ip)?;
        } else {
            self.print_raw_generic(frame_ip, symbol_name, filename, lineno, colno)?;
        }
        self.symbol_index += 1;
        Ok(())
    }

    #[allow(unused_mut)]
    fn print_raw_generic(
        &mut self,
        mut frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Не потрібно друкувати кадри "null", це в основному просто означає, що зворотне відстеження системи було трохи прагнуче прослідкувати дуже далеко.
        //
        if let PrintFmt::Short = self.fmt.format {
            if frame_ip.is_null() {
                return Ok(());
            }
        }

        // Щоб зменшити розмір TCB в анклаві Sgx, ми не хочемо реалізовувати функцію роздільної здатності символів.
        // Швидше, ми можемо надрукувати тут зміщення адреси, яке згодом може бути відображено для корекції функції.
        //
        #[cfg(all(feature = "std", target_env = "sgx", target_vendor = "fortanix"))]
        {
            let image_base = std::os::fortanix_sgx::mem::image_base();
            frame_ip = usize::wrapping_sub(frame_ip as usize, image_base as _) as _;
        }

        // Роздрукуйте індекс кадру, а також додатковий вказівник інструкції кадру.
        // Якщо ми перевищуємо перший символ цього кадру, ми просто друкуємо відповідні пробіли.
        //
        if self.symbol_index == 0 {
            write!(self.fmt.fmt, "{:4}: ", self.fmt.frame_index)?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$?} - ", frame_ip, HEX_WIDTH)?;
            }
        } else {
            write!(self.fmt.fmt, "      ")?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH + 3)?;
            }
        }

        // Далі випишіть назву символу, використовуючи альтернативне форматування для отримання додаткової інформації, якщо ми маємо повну зворотну трасування.
        // Тут ми також обробляємо символи, які не мають імені,
        //
        match (symbol_name, &self.fmt.format) {
            (Some(name), PrintFmt::Short) => write!(self.fmt.fmt, "{:#}", name)?,
            (Some(name), PrintFmt::Full) => write!(self.fmt.fmt, "{}", name)?,
            (None, _) | (_, PrintFmt::__Nonexhaustive) => write!(self.fmt.fmt, "<unknown>")?,
        }
        self.fmt.fmt.write_str("\n")?;

        // І останнє, роздрукуйте номер filename/line, якщо вони є.
        if let (Some(file), Some(line)) = (filename, lineno) {
            self.print_fileline(file, line, colno)?;
        }

        Ok(())
    }

    fn print_fileline(
        &mut self,
        file: BytesOrWideString<'_>,
        line: u32,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Filename/line друкуються на рядках під назвою символу, тож надрукуйте відповідний пробіл, щоб вирівняти праворуч.
        //
        if let PrintFmt::Full = self.fmt.format {
            write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH)?;
        }
        write!(self.fmt.fmt, "             at ")?;

        // Делегуйте в наш внутрішній зворотний дзвінок, щоб надрукувати ім`я файлу, а потім роздрукувати номер рядка.
        //
        (self.fmt.print_path)(self.fmt.fmt, file)?;
        write!(self.fmt.fmt, ":{}", line)?;

        // Додайте номер стовпця, якщо такий є.
        if let Some(colno) = colno {
            write!(self.fmt.fmt, ":{}", colno)?;
        }

        write!(self.fmt.fmt, "\n")?;
        Ok(())
    }

    fn print_raw_fuchsia(&mut self, frame_ip: *mut c_void) -> fmt::Result {
        // Ми дбаємо лише про перший символ кадру
        if self.symbol_index == 0 {
            self.fmt.fmt.write_str("{{{bt:")?;
            write!(self.fmt.fmt, "{}:{:?}", self.fmt.frame_index, frame_ip)?;
            self.fmt.fmt.write_str("}}}\n")?;
        }
        Ok(())
    }
}

impl Drop for BacktraceFrameFmt<'_, '_, '_> {
    fn drop(&mut self) {
        self.fmt.frame_index += 1;
    }
}