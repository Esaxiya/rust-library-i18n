//! Модуль для допомоги у керуванні прив`язками dbghelp на Windows
//!
//! Зворотне відстеження на Windows (принаймні для MSVC) в основному забезпечується завдяки `dbghelp.dll` та різним функціям, які він містить.
//! Наразі ці функції завантажуються *динамічно*, а не пов'язують із `dbghelp.dll` статично.
//! В даний час це робиться стандартною бібліотекою (і теоретично там вимагається), але це намагання допомогти зменшити статичні DLL-залежності бібліотеки, оскільки зворотні відстеження зазвичай є необов`язковими.
//!
//! Тим не менш, `dbghelp.dll` майже завжди успішно завантажується на Windows.
//!
//! Зверніть увагу, однак, оскільки ми динамічно завантажуємо всю цю підтримку, ми фактично не можемо використовувати необроблені визначення в `winapi`, а нам, навпаки, потрібно самостійно визначати типи покажчиків функцій і використовувати це.
//! Ми насправді не хочемо займатися тиражуванням вінапі, тому у нас є функція Cargo `verify-winapi`, яка стверджує, що всі прив`язки відповідають тим, які є у вінапі, і ця функція ввімкнена на CI.
//!
//! Нарешті, ви зауважите тут, що dll для `dbghelp.dll` ніколи не завантажується, і це наразі навмисно.
//! Помилка полягає в тому, що ми можемо глобально кешувати його та використовувати між дзвінками до API, уникаючи дорогих loads/unloads.
//! Якщо це проблема для детекторів витоків або чогось подібного, ми можемо перетнути міст, коли дійдемо туди.
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(non_snake_case)]

use super::windows::*;
use core::mem;
use core::ptr;

// Робота навколо `SymGetOptions` та `SymSetOptions` відсутня у самому вінапі.
// В іншому випадку це використовується лише тоді, коли ми подвійно перевіряємо типи проти winapi.
//
#[cfg(feature = "verify-winapi")]
mod dbghelp {
    use crate::windows::*;
    pub use winapi::um::dbghelp::{
        StackWalk64, SymCleanup, SymFromAddrW, SymFunctionTableAccess64, SymGetLineFromAddrW64,
        SymGetModuleBase64, SymInitializeW,
    };

    extern "system" {
        // Ще не визначено у вінапі
        pub fn SymGetOptions() -> u32;
        pub fn SymSetOptions(_: u32);

        // Це визначено у winapi, але це неправильно (FIXME winapi-rs#768)
        pub fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD,
        ) -> BOOL;

        // Ще не визначено у вінапі
        pub fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW,
        ) -> BOOL;
        pub fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64,
        ) -> BOOL;
    }

    pub fn assert_equal_types<T>(a: T, _b: T) -> T {
        a
    }
}

// Цей макрос використовується для визначення структури `Dbghelp`, яка внутрішньо містить усі покажчики на функції, які ми можемо завантажити.
//
macro_rules! dbghelp {
    (extern "system" {
        $(fn $name:ident($($arg:ident: $argty:ty),*) -> $ret: ty;)*
    }) => (
        pub struct Dbghelp {
            /// Завантажена DLL для `dbghelp.dll`
            dll: HMODULE,

            // Кожен покажчик функції для кожної функції, яку ми могли б використовувати
            $($name: usize,)*
        }

        static mut DBGHELP: Dbghelp = Dbghelp {
            // Спочатку ми не завантажували DLL
            dll: 0 as *mut _,
            // Для всіх функцій встановлено нуль, щоб сказати, що їх потрібно динамічно завантажувати.
            //
            $($name: 0,)*
        };

        // Зручність typedef для кожного типу функції.
        $(pub type $name = unsafe extern "system" fn($($argty),*) -> $ret;)*

        impl Dbghelp {
            /// Спроби відкрити `dbghelp.dll`.
            /// Повертає успіх, якщо він працює, або помилку, якщо `LoadLibraryW` не працює.
            ///
            /// Panics, якщо бібліотека вже завантажена.
            fn ensure_open(&mut self) -> Result<(), ()> {
                if !self.dll.is_null() {
                    return Ok(())
                }
                let lib = b"dbghelp.dll\0";
                unsafe {
                    self.dll = LoadLibraryA(lib.as_ptr() as *const i8);
                    if self.dll.is_null() {
                        Err(())
                    }  else {
                        Ok(())
                    }
                }
            }

            // Функція для кожного методу, який ми хотіли б використовувати.
            // При його виклику він або прочитає кешований покажчик функції, або завантажить його і поверне завантажене значення.
            // Навантаження стверджується, що вони мають успіх.
            $(pub fn $name(&mut self) -> Option<$name> {
                unsafe {
                    if self.$name == 0 {
                        let name = concat!(stringify!($name), "\0");
                        self.$name = self.symbol(name.as_bytes())?;
                    }
                    let ret = mem::transmute::<usize, $name>(self.$name);
                    #[cfg(feature = "verify-winapi")]
                    dbghelp::assert_equal_types(ret, dbghelp::$name);
                    Some(ret)
                }
            })*

            fn symbol(&self, symbol: &[u8]) -> Option<usize> {
                unsafe {
                    match GetProcAddress(self.dll, symbol.as_ptr() as *const _) as usize {
                        0 => None,
                        n => Some(n),
                    }
                }
            }
        }

        // Зручний проксі-сервер для використання замків очищення для посилання на функції dbghelp.
        //
        #[allow(dead_code)]
        impl Init {
            $(pub fn $name(&self) -> $name {
                unsafe {
                    DBGHELP.$name().unwrap()
                }
            })*

            pub fn dbghelp(&self) -> *mut Dbghelp {
                unsafe {
                    &mut DBGHELP
                }
            }
        }
    )

}

const SYMOPT_DEFERRED_LOADS: DWORD = 0x00000004;

dbghelp! {
    extern "system" {
        fn SymGetOptions() -> DWORD;
        fn SymSetOptions(options: DWORD) -> ();
        fn SymInitializeW(
            handle: HANDLE,
            path: PCWSTR,
            invade: BOOL
        ) -> BOOL;
        fn SymCleanup(handle: HANDLE) -> BOOL;
        fn StackWalk64(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME64,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64
        ) -> BOOL;
        fn SymFunctionTableAccess64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> PVOID;
        fn SymGetModuleBase64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> DWORD64;
        fn SymFromAddrW(
            hProcess: HANDLE,
            Address: DWORD64,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromAddrW64(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
        fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD
        ) -> BOOL;
        fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
    }
}

pub struct Init {
    lock: HANDLE,
}

/// Ініціалізуйте всю підтримку, необхідну для доступу до функцій `dbghelp` API з цього crate.
///
///
/// Зверніть увагу, що ця функція **безпечна**, вона внутрішньо має власну синхронізацію.
/// Також зверніть увагу, що безпечно викликати цю функцію кілька разів рекурсивно.
///
pub fn init() -> Result<Init, ()> {
    use core::sync::atomic::{AtomicUsize, Ordering::SeqCst};

    unsafe {
        // Перше, що нам потрібно зробити, це синхронізувати цю функцію.Це можна викликати одночасно з інших потоків або рекурсивно в межах одного потоку.
        // Зауважте, що це складніше, ніж це, хоча, оскільки те, що ми використовуємо тут, `dbghelp`,*також* має синхронізуватися з усіма іншими викликами до `dbghelp` у цьому процесі.
        //
        // Зазвичай в рамках одного процесу насправді не так багато дзвінків на `dbghelp`, і ми, напевно, можемо впевнено вважати, що ми єдині, хто отримує до нього доступ.
        // Однак є один основний інший користувач, про якого ми маємо турбуватися, про що іронічно ми самі, але в стандартній бібліотеці.
        // Стандартна бібліотека Rust залежить від цього crate для підтримки зворотного відстеження, і ця crate також існує на crates.io.
        // Це означає, що якщо стандартна бібліотека друкує зворотне відстеження panic, вона може перебігати з цим crate, що надходить з crates.io, спричиняючи сегментаційні помилки.
        //
        // Щоб допомогти вирішити цю проблему синхронізації, ми використовуємо специфічний для Windows трюк (це, зрештою, обмеження щодо синхронізації для Windows).
        // Ми створюємо *локальний сеанс* з назвою mutex для захисту цього виклику.
        // Намір тут полягає в тому, що стандартна бібліотека та цей crate не повинні спільно використовувати API рівня Rust для синхронізації тут, а замість цього можуть працювати за кадром, щоб переконатися, що вони синхронізуються між собою.
        //
        // Таким чином, коли ця функція викликається через стандартну бібліотеку або через crates.io, ми можемо бути впевнені, що отримується той самий мьютекс.
        //
        // Отже, все це означає сказати, що перше, що ми робимо тут,-це атомне створення `HANDLE`, який є іменованим мьютексом на Windows.
        // Ми трохи синхронізуємо з іншими потоками, які спільно використовують цю функцію, і гарантуємо, що для кожного екземпляра цієї функції створено лише один дескриптор.
        // Зверніть увагу, що дескриптор ніколи не закривається, коли він зберігається в глобальному.
        //
        // Після того, як ми фактично перейдемо до замку, ми просто його придбаємо, і наша ручка `Init`, яку ми роздамо, буде відповідальною за її скидання.
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        static LOCK: AtomicUsize = AtomicUsize::new(0);
        let mut lock = LOCK.load(SeqCst);
        if lock == 0 {
            lock = CreateMutexA(
                ptr::null_mut(),
                0,
                "Local\\RustBacktraceMutex\0".as_ptr() as _,
            ) as usize;
            if lock == 0 {
                return Err(());
            }
            if let Err(other) = LOCK.compare_exchange(0, lock, SeqCst, SeqCst) {
                debug_assert!(other != 0);
                CloseHandle(lock as HANDLE);
                lock = other;
            }
        }
        debug_assert!(lock != 0);
        let lock = lock as HANDLE;
        let r = WaitForSingleObjectEx(lock, INFINITE, FALSE);
        debug_assert_eq!(r, 0);
        let ret = Init { lock };

        // Гаразд, Фу!Тепер, коли ми всі безпечно синхронізовані, давайте фактично почнемо обробляти все.
        // Спочатку нам потрібно переконатися, що `dbghelp.dll` фактично завантажується в цьому процесі.
        // Ми робимо це динамічно, щоб уникнути статичної залежності.
        // Історично це робилося для вирішення дивних проблем зв`язування і має на меті зробити бінарні файли трохи портативнішими, оскільки це в основному лише утиліта налагодження.
        //
        //
        // Після того, як ми відкрили `dbghelp.dll`, нам потрібно викликати в ньому деякі функції ініціалізації, і це детально описано нижче.
        // Однак ми робимо це лише один раз, тому у нас є глобальний логічний вказівник, який вказує, закінчили ми це чи ні.
        //
        //
        //
        //
        DBGHELP.ensure_open()?;

        static mut INITIALIZED: bool = false;
        if INITIALIZED {
            return Ok(ret);
        }

        let orig = DBGHELP.SymGetOptions().unwrap()();

        // Переконайтеся, що встановлений прапор `SYMOPT_DEFERRED_LOADS`, оскільки відповідно до власних документів MSVC про це: "This is the fastest, most efficient way to use the symbol handler.", тож давайте зробимо це!
        //
        //
        DBGHELP.SymSetOptions().unwrap()(orig | SYMOPT_DEFERRED_LOADS);

        // Фактично ініціалізуйте символи за допомогою MSVC.Зверніть увагу, що це може не вдатися, але ми ігноруємо це.
        // Попереднього рівня техніки як такої не існує, але, здається, LLVM внутрішньо ігнорує повернене значення, і одна з бібліотек дезінфікуючого засобу в LLVM друкує страшне попередження, якщо це не вдається, але в основному ігнорує його в довгостроковій перспективі.
        //
        //
        // Одним випадком, що цього багато випливає для Rust, є те, що як стандартна бібліотека, так і цей crate на crates.io хочуть конкурувати за `SymInitializeW`.
        // Стандартна бібліотека історично хотіла ініціалізувати потім очищення більшу частину часу, але тепер, коли вона використовує цей crate, це означає, що хтось перейде до ініціалізації першим, а інший підніме цю ініціалізацію.
        //
        //
        //
        //
        //
        //
        DBGHELP.SymInitializeW().unwrap()(GetCurrentProcess(), ptr::null_mut(), TRUE);
        INITIALIZED = true;
        Ok(ret)
    }
}

impl Drop for Init {
    fn drop(&mut self) {
        unsafe {
            let r = ReleaseMutex(self.lock);
            debug_assert!(r != 0);
        }
    }
}