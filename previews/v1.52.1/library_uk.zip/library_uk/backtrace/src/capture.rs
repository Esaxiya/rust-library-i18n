use crate::PrintFmt;
use crate::{resolve, resolve_frame, trace, BacktraceFmt, Symbol, SymbolName};
use std::ffi::c_void;
use std::fmt;
use std::path::{Path, PathBuf};
use std::prelude::v1::*;

#[cfg(feature = "serde")]
use serde::{Deserialize, Serialize};

/// Відображення власного та автономного зворотного відстеження.
///
/// Ця структура може бути використана для фіксації зворотного відстеження в різних точках програми, а пізніше для перевірки того, яким був зворотний трас на той час.
///
///
/// `Backtrace` підтримує симпатичний друк зворотних слідів завдяки реалізації `Debug`.
///
/// # Необхідні функції
///
/// Ця функція вимагає ввімкнення функції `std` для `backtrace` crate, а функцію `std` увімкнено за замовчуванням.
///
///
#[derive(Clone)]
#[cfg_attr(feature = "serialize-rustc", derive(RustcDecodable, RustcEncodable))]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
pub struct Backtrace {
    // Рамки тут перераховані зверху вниз у стосі
    frames: Vec<BacktraceFrame>,
    // Ми вважаємо, що індекс є фактичним початком зворотного відстеження, опускаючи кадри, такі як `Backtrace::new` та `backtrace::trace`.
    //
    actual_start_index: usize,
}

fn _assert_send_sync() {
    fn _assert<T: Send + Sync>() {}
    _assert::<Backtrace>();
}

/// Захоплена версія кадру у зворотній трасі.
///
/// Цей тип повертається як список із `Backtrace::frames` і представляє один кадр стека у захопленій зворотній трасі.
///
/// # Необхідні функції
///
/// Ця функція вимагає ввімкнення функції `std` для `backtrace` crate, а функцію `std` увімкнено за замовчуванням.
///
///
#[derive(Clone)]
pub struct BacktraceFrame {
    frame: Frame,
    symbols: Option<Vec<BacktraceSymbol>>,
}

#[derive(Clone)]
enum Frame {
    Raw(crate::Frame),
    #[allow(dead_code)]
    Deserialized {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
    },
}

impl Frame {
    fn ip(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ref f) => f.ip(),
            Frame::Deserialized { ip, .. } => ip as *mut c_void,
        }
    }

    fn symbol_address(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ref f) => f.symbol_address(),
            Frame::Deserialized { symbol_address, .. } => symbol_address as *mut c_void,
        }
    }

    fn module_base_address(&self) -> Option<*mut c_void> {
        match *self {
            Frame::Raw(ref f) => f.module_base_address(),
            Frame::Deserialized {
                module_base_address,
                ..
            } => module_base_address.map(|addr| addr as *mut c_void),
        }
    }
}

/// Захоплена версія символу у зворотній трасі.
///
/// Цей тип повертається як список із `BacktraceFrame::symbols` і представляє метадані символу у зворотній трасі.
///
/// # Необхідні функції
///
/// Ця функція вимагає ввімкнення функції `std` для `backtrace` crate, а функцію `std` увімкнено за замовчуванням.
///
///
#[derive(Clone)]
#[cfg_attr(feature = "serialize-rustc", derive(RustcDecodable, RustcEncodable))]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
pub struct BacktraceSymbol {
    name: Option<Vec<u8>>,
    addr: Option<usize>,
    filename: Option<PathBuf>,
    lineno: Option<u32>,
    colno: Option<u32>,
}

impl Backtrace {
    /// Фіксує зворотну трасування на місці виклику цієї функції, повертаючи власне представлення.
    ///
    /// Ця функція корисна для представлення зворотного сліду як об'єкта в Rust.Це повернуте значення можна пересилати через нитки та друкувати деінде, і ціль цього значення полягає у тому, щоб бути повністю самостійним.
    ///
    /// Зауважте, що на деяких платформах отримання повного зворотного відстеження та його вирішення може бути надзвичайно дорогим.
    /// Якщо витрати на програму занадто великі, рекомендується замість цього використовувати `Backtrace::new_unresolved()`, який уникає кроку роздільної здатності символів (який зазвичай займає найдовший час) і дозволяє відкласти його на пізніший термін.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use backtrace::Backtrace;
    ///
    /// let current_backtrace = Backtrace::new();
    /// ```
    ///
    /// # Необхідні функції
    ///
    /// Ця функція вимагає ввімкнення функції `std` для `backtrace` crate, а функцію `std` увімкнено за замовчуванням.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline(never)] // хочу переконатися, що тут є кадр для видалення
    pub fn new() -> Backtrace {
        let mut bt = Self::create(Self::new as usize);
        bt.resolve();
        bt
    }

    /// Подібно до `new`, за винятком того, що це не вирішує жодних символів, воно просто фіксує зворотне відстеження як список адрес.
    ///
    /// Пізніше можна буде викликати функцію `resolve`, щоб вирішити символи цього зворотного відстеження у читабельні імена.
    /// Ця функція існує, оскільки процес вирішення може іноді зайняти значну кількість часу, тоді як будь-яка зворотна трасування може друкуватися рідко.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use backtrace::Backtrace;
    ///
    /// let mut current_backtrace = Backtrace::new_unresolved();
    /// println!("{:?}", current_backtrace); // відсутні назви символів
    /// current_backtrace.resolve();
    /// println!("{:?}", current_backtrace); // імена символів, які зараз присутні
    /// ```
    ///
    /// # Необхідні функції
    ///
    /// Ця функція вимагає ввімкнення функції `std` для `backtrace` crate, а функцію `std` увімкнено за замовчуванням.
    ///
    ///
    ///
    #[inline(never)] // хочу переконатися, що тут є кадр для видалення
    pub fn new_unresolved() -> Backtrace {
        Self::create(Self::new_unresolved as usize)
    }

    fn create(ip: usize) -> Backtrace {
        let mut frames = Vec::new();
        let mut actual_start_index = None;
        trace(|frame| {
            frames.push(BacktraceFrame {
                frame: Frame::Raw(frame.clone()),
                symbols: None,
            });

            if frame.symbol_address() as usize == ip && actual_start_index.is_none() {
                actual_start_index = Some(frames.len());
            }
            true
        });

        Backtrace {
            frames,
            actual_start_index: actual_start_index.unwrap_or(0),
        }
    }

    /// Повертає кадри з моменту, коли було зроблено це зворотне відстеження.
    ///
    /// Перший запис цього фрагмента-це, швидше за все, функція `Backtrace::new`, а останній кадр, ймовірно, щось про те, як цей потік або основна функція запускалася.
    ///
    ///
    /// # Необхідні функції
    ///
    /// Ця функція вимагає ввімкнення функції `std` для `backtrace` crate, а функцію `std` увімкнено за замовчуванням.
    ///
    ///
    pub fn frames(&self) -> &[BacktraceFrame] {
        &self.frames[self.actual_start_index..]
    }

    /// Якщо цей зворотний трак був створений з `new_unresolved`, тоді ця функція дозволить всі адреси в зворотній траєкторії отримувати символічні імена.
    ///
    ///
    /// Якщо ця зворотна трасування була попередньо вирішена або створена через `new`, ця функція нічого не робить.
    ///
    /// # Необхідні функції
    ///
    /// Ця функція вимагає ввімкнення функції `std` для `backtrace` crate, а функцію `std` увімкнено за замовчуванням.
    ///
    ///
    pub fn resolve(&mut self) {
        for frame in self.frames.iter_mut().filter(|f| f.symbols.is_none()) {
            let mut symbols = Vec::new();
            {
                let sym = |symbol: &Symbol| {
                    symbols.push(BacktraceSymbol {
                        name: symbol.name().map(|m| m.as_bytes().to_vec()),
                        addr: symbol.addr().map(|a| a as usize),
                        filename: symbol.filename().map(|m| m.to_owned()),
                        lineno: symbol.lineno(),
                        colno: symbol.colno(),
                    });
                };
                match frame.frame {
                    Frame::Raw(ref f) => resolve_frame(f, sym),
                    Frame::Deserialized { ip, .. } => {
                        resolve(ip as *mut c_void, sym);
                    }
                }
            }
            frame.symbols = Some(symbols);
        }
    }
}

impl From<Vec<BacktraceFrame>> for Backtrace {
    fn from(frames: Vec<BacktraceFrame>) -> Self {
        Backtrace {
            frames,
            actual_start_index: 0,
        }
    }
}

impl Into<Vec<BacktraceFrame>> for Backtrace {
    fn into(self) -> Vec<BacktraceFrame> {
        self.frames
    }
}

impl BacktraceFrame {
    /// Те саме, що `Frame::ip`
    ///
    /// # Необхідні функції
    ///
    /// Ця функція вимагає ввімкнення функції `std` для `backtrace` crate, а функцію `std` увімкнено за замовчуванням.
    ///
    pub fn ip(&self) -> *mut c_void {
        self.frame.ip() as *mut c_void
    }

    /// Те саме, що `Frame::symbol_address`
    ///
    /// # Необхідні функції
    ///
    /// Ця функція вимагає ввімкнення функції `std` для `backtrace` crate, а функцію `std` увімкнено за замовчуванням.
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.frame.symbol_address() as *mut c_void
    }

    /// Те саме, що `Frame::module_base_address`
    ///
    /// # Необхідні функції
    ///
    /// Ця функція вимагає ввімкнення функції `std` для `backtrace` crate, а функцію `std` увімкнено за замовчуванням.
    ///
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.frame
            .module_base_address()
            .map(|addr| addr as *mut c_void)
    }

    /// Повертає список символів, яким відповідає цей кадр.
    ///
    /// Зазвичай в кадрі є лише один символ, але іноді, якщо кількість функцій вбудовано в один кадр, повертається кілька символів.
    /// Першим символом у списку є "innermost function", тоді як останнім символом є крайній (останній абонент).
    ///
    /// Зверніть увагу, що якщо цей кадр вийшов з невирішеного зворотного відслідковування, це поверне порожній список.
    ///
    /// # Необхідні функції
    ///
    /// Ця функція вимагає ввімкнення функції `std` для `backtrace` crate, а функцію `std` увімкнено за замовчуванням.
    ///
    ///
    ///
    ///
    pub fn symbols(&self) -> &[BacktraceSymbol] {
        self.symbols.as_ref().map(|s| &s[..]).unwrap_or(&[])
    }
}

impl BacktraceSymbol {
    /// Те саме, що `Symbol::name`
    ///
    /// # Необхідні функції
    ///
    /// Ця функція вимагає ввімкнення функції `std` для `backtrace` crate, а функцію `std` увімкнено за замовчуванням.
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.name.as_ref().map(|s| SymbolName::new(s))
    }

    /// Те саме, що `Symbol::addr`
    ///
    /// # Необхідні функції
    ///
    /// Ця функція вимагає ввімкнення функції `std` для `backtrace` crate, а функцію `std` увімкнено за замовчуванням.
    ///
    pub fn addr(&self) -> Option<*mut c_void> {
        self.addr.map(|s| s as *mut c_void)
    }

    /// Те саме, що `Symbol::filename`
    ///
    /// # Необхідні функції
    ///
    /// Ця функція вимагає ввімкнення функції `std` для `backtrace` crate, а функцію `std` увімкнено за замовчуванням.
    ///
    pub fn filename(&self) -> Option<&Path> {
        self.filename.as_ref().map(|p| &**p)
    }

    /// Те саме, що `Symbol::lineno`
    ///
    /// # Необхідні функції
    ///
    /// Ця функція вимагає ввімкнення функції `std` для `backtrace` crate, а функцію `std` увімкнено за замовчуванням.
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.lineno
    }

    /// Те саме, що `Symbol::colno`
    ///
    /// # Необхідні функції
    ///
    /// Ця функція вимагає ввімкнення функції `std` для `backtrace` crate, а функцію `std` увімкнено за замовчуванням.
    ///
    pub fn colno(&self) -> Option<u32> {
        self.colno
    }
}

impl fmt::Debug for Backtrace {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        let full = fmt.alternate();
        let (frames, style) = if full {
            (&self.frames[..], PrintFmt::Full)
        } else {
            (&self.frames[self.actual_start_index..], PrintFmt::Short)
        };

        // При друкуванні шляхів ми намагаємося вилучити cwd, якщо він існує, інакше ми просто друкуємо шлях як є.
        // Зверніть увагу, що ми також робимо це лише для короткого формату, тому що, якщо він заповнений, ми, мабуть, хочемо надрукувати все.
        //
        //
        let cwd = std::env::current_dir();
        let mut print_path =
            move |fmt: &mut fmt::Formatter<'_>, path: crate::BytesOrWideString<'_>| {
                let path = path.into_path_buf();
                if !full {
                    if let Ok(cwd) = &cwd {
                        if let Ok(suffix) = path.strip_prefix(cwd) {
                            return fmt::Display::fmt(&suffix.display(), fmt);
                        }
                    }
                }
                fmt::Display::fmt(&path.display(), fmt)
            };

        let mut f = BacktraceFmt::new(fmt, style, &mut print_path);
        f.add_context()?;
        for frame in frames {
            f.frame().backtrace_frame(frame)?;
        }
        f.finish()?;
        Ok(())
    }
}

impl Default for Backtrace {
    fn default() -> Backtrace {
        Backtrace::new()
    }
}

impl fmt::Debug for BacktraceFrame {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_struct("BacktraceFrame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

impl fmt::Debug for BacktraceSymbol {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_struct("BacktraceSymbol")
            .field("name", &self.name())
            .field("addr", &self.addr())
            .field("filename", &self.filename())
            .field("lineno", &self.lineno())
            .field("colno", &self.colno())
            .finish()
    }
}

#[cfg(feature = "serialize-rustc")]
mod rustc_serialize_impls {
    use super::*;
    use rustc_serialize::{Decodable, Decoder, Encodable, Encoder};

    #[derive(RustcEncodable, RustcDecodable)]
    struct SerializedFrame {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
        symbols: Option<Vec<BacktraceSymbol>>,
    }

    impl Decodable for BacktraceFrame {
        fn decode<D>(d: &mut D) -> Result<Self, D::Error>
        where
            D: Decoder,
        {
            let frame: SerializedFrame = SerializedFrame::decode(d)?;
            Ok(BacktraceFrame {
                frame: Frame::Deserialized {
                    ip: frame.ip,
                    symbol_address: frame.symbol_address,
                    module_base_address: frame.module_base_address,
                },
                symbols: frame.symbols,
            })
        }
    }

    impl Encodable for BacktraceFrame {
        fn encode<E>(&self, e: &mut E) -> Result<(), E::Error>
        where
            E: Encoder,
        {
            let BacktraceFrame { frame, symbols } = self;
            SerializedFrame {
                ip: frame.ip() as usize,
                symbol_address: frame.symbol_address() as usize,
                module_base_address: frame.module_base_address().map(|addr| addr as usize),
                symbols: symbols.clone(),
            }
            .encode(e)
        }
    }
}

#[cfg(feature = "serde")]
mod serde_impls {
    use super::*;
    use serde::de::Deserializer;
    use serde::ser::Serializer;
    use serde::{Deserialize, Serialize};

    #[derive(Serialize, Deserialize)]
    struct SerializedFrame {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
        symbols: Option<Vec<BacktraceSymbol>>,
    }

    impl Serialize for BacktraceFrame {
        fn serialize<S>(&self, s: S) -> Result<S::Ok, S::Error>
        where
            S: Serializer,
        {
            let BacktraceFrame { frame, symbols } = self;
            SerializedFrame {
                ip: frame.ip() as usize,
                symbol_address: frame.symbol_address() as usize,
                module_base_address: frame.module_base_address().map(|addr| addr as usize),
                symbols: symbols.clone(),
            }
            .serialize(s)
        }
    }

    impl<'a> Deserialize<'a> for BacktraceFrame {
        fn deserialize<D>(d: D) -> Result<Self, D::Error>
        where
            D: Deserializer<'a>,
        {
            let frame: SerializedFrame = SerializedFrame::deserialize(d)?;
            Ok(BacktraceFrame {
                frame: Frame::Deserialized {
                    ip: frame.ip,
                    symbol_address: frame.symbol_address,
                    module_base_address: frame.module_base_address,
                },
                symbols: frame.symbols,
            })
        }
    }
}