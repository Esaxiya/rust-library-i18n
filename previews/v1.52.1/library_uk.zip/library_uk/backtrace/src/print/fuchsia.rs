use core::fmt::{self, Write};
use core::mem::{size_of, transmute};
use core::slice::from_raw_parts;
use libc::c_char;

extern "C" {
    // dl_iterate_phdr приймає зворотний виклик, який отримуватиме вказівник dl_phdr_info для кожного DSO, який був пов'язаний з процесом.
    // dl_iterate_phdr також гарантує, що динамічний компонувальник заблокований від початку до кінця ітерації.
    // Якщо зворотний виклик повертає ненульове значення, ітерація припиняється достроково.
    // 'data' буде передано як третій аргумент зворотного виклику при кожному дзвінку.
    // 'size' дає розмір dl_phdr_info.
    //
    #[allow(improper_ctypes)]
    fn dl_iterate_phdr(
        f: extern "C" fn(info: &dl_phdr_info, size: usize, data: &mut DsoPrinter<'_, '_>) -> i32,
        data: &mut DsoPrinter<'_, '_>,
    ) -> i32;
}

// Нам потрібно проаналізувати ідентифікатор збірки та деякі основні дані заголовка програми, що означає, що нам також потрібно трохи матеріалів із специфікації ELF.
//

const PT_LOAD: u32 = 1;
const PT_NOTE: u32 = 4;

// Тепер ми повинні розмножувати, біт за бітом, структуру типу dl_phdr_info, використовуваного поточним динамічним лінкером fuchsia.
// Chromium також має цю межу ABI, а також padpad.
// Врешті-решт ми хотіли б перенести ці випадки на використання elf-пошуку, але нам потрібно буде вказати це в SDK, і цього ще не зроблено.
//
// Таким чином, ми (і вони) застрягли, маючи використовувати цей метод, який забезпечує щільне зчеплення з фуксією libc.
//

#[allow(non_camel_case_types)]
#[repr(C)]
struct dl_phdr_info {
    addr: *const u8,
    name: *const c_char,
    phdr: *const Elf_Phdr,
    phnum: u16,
    adds: u64,
    subs: u64,
    tls_modid: usize,
    tls_data: *const u8,
}

impl dl_phdr_info {
    fn program_headers(&self) -> PhdrIter<'_> {
        PhdrIter {
            phdrs: self.phdr_slice(),
            base: self.addr,
        }
    }
    // Ми не знаємо, як перевірити, чи є e_phoff та e_phnum дійсними.
    // libc повинен забезпечити це для нас, однак тому безпечно сформувати тут фрагмент.
    fn phdr_slice(&self) -> &[Elf_Phdr] {
        unsafe { from_raw_parts(self.phdr, self.phnum as usize) }
    }
}

struct PhdrIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: *const u8,
}

impl<'a> Iterator for PhdrIter<'a> {
    type Item = Phdr<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().map(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            Phdr {
                phdr,
                base: self.base,
            }
        })
    }
}

// Elf_Phdr представляє 64-розрядний заголовок програми ELF в межах цільової архітектури.
//
#[allow(non_camel_case_types)]
#[derive(Clone, Debug)]
#[repr(C)]
struct Elf_Phdr {
    p_type: u32,
    p_flags: u32,
    p_offset: u64,
    p_vaddr: u64,
    p_paddr: u64,
    p_filesz: u64,
    p_memsz: u64,
    p_align: u64,
}

// Phdr представляє дійсний заголовок програми ELF та її зміст.
struct Phdr<'a> {
    phdr: &'a Elf_Phdr,
    base: *const u8,
}

impl<'a> Phdr<'a> {
    // Ми не маємо можливості перевірити, чи правильні p_addr або p_memsz.
    // Libc Фуксії спочатку аналізує нотатки, однак, оскільки вони тут, ці заголовки повинні бути дійсними.
    //
    // NoteIter не вимагає, щоб базові дані були дійсними, але вимагає дійсності меж.
    // Ми віримо, що libc переконався, що це стосується і нас тут.
    fn notes(&self) -> NoteIter<'a> {
        unsafe {
            NoteIter::new(
                self.base.add(self.phdr.p_offset as usize),
                self.phdr.p_memsz as usize,
            )
        }
    }
}

// Тип примітки для ідентифікаторів збірки.
const NT_GNU_BUILD_ID: u32 = 3;

// Elf_Nhdr представляє заголовок ноти ELF у кінцевій цілі.
#[allow(non_camel_case_types)]
#[repr(C)]
struct Elf_Nhdr {
    n_namesz: u32,
    n_descsz: u32,
    n_type: u32,
}

// Примітка представляє нотатку ELF (заголовок + вміст).
// Ім'я залишається як зріз u8, оскільки воно не завжди закінчується нулем, а rust дозволяє досить легко перевірити, чи однаково відповідають байти.
//
struct Note<'a> {
    name: &'a [u8],
    desc: &'a [u8],
    tipe: u32,
}

// NoteIter дозволяє безпечно перебирати сегмент ноти.
// Він припиняється, як тільки виникає помилка або більше немає приміток.
// Якщо ви перебираєте недійсні дані, він буде функціонувати так, ніби приміток не знайдено.
struct NoteIter<'a> {
    base: &'a [u8],
    error: bool,
}

impl<'a> NoteIter<'a> {
    // Це інваріант функції, що вказаний покажчик та розмір позначають дійсний діапазон байтів, які всі можна прочитати.
    // Вміст цих байт може бути будь-яким, але діапазон повинен бути дійсним, щоб це було безпечно.
    //
    unsafe fn new(base: *const u8, size: usize) -> Self {
        NoteIter {
            base: from_raw_parts(base, size),
            error: false,
        }
    }
}

// align_to вирівнює 'x' з вирівнюванням байтів, якщо 'to' дорівнює рівню 2.
// Це слідує стандартному шаблону в коді синтаксичного аналізу EL/C ++, де використовується (x + до, 1)&-to.
// Rust не дозволяє вам заперечувати usize, тому я використовую
// Перетворення доповнення 2, щоб відтворити це.
fn align_to(x: usize, to: usize) -> usize {
    (x + to - 1) & (!to + 1)
}

// take_bytes_align4 споживає число байтів з фрагмента (якщо він присутній) і додатково гарантує, що кінцевий фрагмент правильно вирівняний.
// Якщо кількість запитаних байтів занадто велика або зріз не може бути вирівняний згодом через недостатню кількість залишилися байтів, повертається None та зріз не змінюється.
//
//
//
fn take_bytes_align4<'a>(num: usize, bytes: &mut &'a [u8]) -> Option<&'a [u8]> {
    if bytes.len() < align_to(num, 4) {
        return None;
    }
    let (out, bytes_new) = bytes.split_at(num);
    *bytes = &bytes_new[align_to(num, 4) - num..];
    Some(out)
}

// Ця функція не має справжніх інваріантів, які повинен підтримувати абонент, крім, можливо, того, що 'bytes' слід вирівняти за продуктивністю (і щодо правильності деяких архітектур).
// Значення в полях Elf_Nhdr можуть бути нісенітницею, але ця функція не забезпечує такого.
//
//
fn take_nhdr<'a>(bytes: &mut &'a [u8]) -> Option<&'a Elf_Nhdr> {
    if size_of::<Elf_Nhdr>() > bytes.len() {
        return None;
    }
    // Це безпечно, поки є достатньо місця, і ми щойно підтвердили, що у наведеному вище твердженні if це не повинно бути небезпечним.
    //
    let out = unsafe { transmute::<*const u8, &'a Elf_Nhdr>(bytes.as_ptr()) };
    // Зверніть увагу, що sice_of: :<Elf_Nhdr>() завжди вирівнюється за 4 байтами.
    *bytes = &bytes[size_of::<Elf_Nhdr>()..];
    Some(out)
}

impl<'a> Iterator for NoteIter<'a> {
    type Item = Note<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        // Перевірте, чи досягли ми кінця.
        if self.base.len() == 0 || self.error {
            return None;
        }
        // Ми трансмутуємо nhdr, але ретельно розглядаємо отриману структуру.
        // Ми не довіряємо namesz чи descsz і не приймаємо небезпечних рішень залежно від типу.
        //
        // Отже, навіть якщо ми винесли повне сміття, ми все одно повинні бути в безпеці.
        let nhdr = take_nhdr(&mut self.base)?;
        let name = take_bytes_align4(nhdr.n_namesz as usize, &mut self.base)?;
        let desc = take_bytes_align4(nhdr.n_descsz as usize, &mut self.base)?;
        Some(Note {
            name: name,
            desc: desc,
            tipe: nhdr.n_type,
        })
    }
}

struct Perm(u32);

/// Вказує на те, що сегмент є виконуваним.
const PERM_X: u32 = 0b00000001;
/// Позначає, що сегмент можна записати.
const PERM_W: u32 = 0b00000010;
/// Показує, що сегмент читається.
const PERM_R: u32 = 0b00000100;

impl core::fmt::Display for Perm {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let v = self.0;
        if v & PERM_R != 0 {
            f.write_char('r')?
        }
        if v & PERM_W != 0 {
            f.write_char('w')?
        }
        if v & PERM_X != 0 {
            f.write_char('x')?
        }
        Ok(())
    }
}

/// Представляє сегмент ELF під час виконання.
struct Segment {
    /// Вказує віртуальну адресу виконання вмісту цього сегмента.
    addr: usize,
    /// Дає обсяг пам`яті вмісту цього сегмента.
    size: usize,
    /// Дає модулю віртуальну адресу цього сегмента з файлом ELF.
    mod_rel_addr: usize,
    /// Дає дозволи, знайдені у файлі ELF.
    /// Однак ці дозволи не обов'язково є дозволами, наявними під час виконання.
    flags: Perm,
}

/// Дозволяє виконувати ітерацію сегментів від DSO.
struct SegmentIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: usize,
}

impl Iterator for SegmentIter<'_> {
    type Item = Segment;

    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().and_then(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            if phdr.p_type != PT_LOAD {
                self.next()
            } else {
                Some(Segment {
                    addr: phdr.p_vaddr as usize + self.base,
                    size: phdr.p_memsz as usize,
                    mod_rel_addr: phdr.p_vaddr as usize,
                    flags: Perm(phdr.p_flags),
                })
            }
        })
    }
}

/// Представляє ELF DSO (динамічний спільний об'єкт).
/// Цей тип посилається на дані, що зберігаються у фактичному DSO, а не робить власну копію.
struct Dso<'a> {
    /// Динамічний компонувальник завжди дає нам ім`я, навіть якщо ім`я порожнє.
    /// У випадку основного виконуваного файлу це ім'я буде порожнім.
    /// У випадку спільного об'єкта це буде ім'я soname (див. DT_SONAME).
    name: &'a str,
    /// На Fuchsia практично всі двійкові файли мають ідентифікатори збірки, але це не є суворим вимогою.
    /// Немає можливості зв`язати інформацію DSO з реальним ELF-файлом згодом, якщо немає build_id, тому ми вимагаємо, щоб кожен DSO мав його тут.
    ///
    /// DSO без build_id ігноруються.
    build_id: &'a [u8],

    base: usize,
    phdrs: &'a [Elf_Phdr],
}

impl Dso<'_> {
    /// Повертає ітератор над сегментами в цьому DSO.
    fn segments(&self) -> SegmentIter<'_> {
        SegmentIter {
            phdrs: self.phdrs.as_ref(),
            base: self.base,
        }
    }
}

struct HexSlice<'a> {
    bytes: &'a [u8],
}

impl fmt::Display for HexSlice<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        for byte in self.bytes {
            write!(f, "{:02x}", byte)?;
        }
        Ok(())
    }
}

fn get_build_id<'a>(info: &'a dl_phdr_info) -> Option<&'a [u8]> {
    for phdr in info.program_headers() {
        if phdr.phdr.p_type == PT_NOTE {
            for note in phdr.notes() {
                if note.tipe == NT_GNU_BUILD_ID && (note.name == b"GNU\0" || note.name == b"GNU") {
                    return Some(note.desc);
                }
            }
        }
    }
    None
}

/// Ці помилки кодують проблеми, які виникають під час аналізу інформації про кожну ОСРВ.
///
enum Error {
    /// NameError означає, що сталася помилка під час перетворення рядка стилю C у рядок rust.
    ///
    NameError(core::str::Utf8Error),
    /// BuildIDError означає, що ми не знайшли ідентифікатор збірки.
    /// Це може бути через те, що DSO не мав ідентифікатора збірки, або тому, що сегмент, що містить ідентифікатор збірки, був неправильно сформований.
    ///
    BuildIDError,
}

/// Викликає або 'dso', або 'error' для кожного DSO, зв`язаного в процесі динамічним лінкером.
///
///
/// # Arguments
///
/// * `visitor` - DsoPrinter, який матиме один із методів, що називається foreach DSO.
fn for_each_dso(mut visitor: &mut DsoPrinter<'_, '_>) {
    extern "C" fn callback(
        info: &dl_phdr_info,
        _size: usize,
        visitor: &mut DsoPrinter<'_, '_>,
    ) -> i32 {
        // dl_iterate_phdr гарантує, що info.name вказуватиме на дійсне місце.
        //
        let name_len = unsafe { libc::strlen(info.name) };
        let name_slice: &[u8] =
            unsafe { core::slice::from_raw_parts(info.name as *const u8, name_len) };
        let name = match core::str::from_utf8(name_slice) {
            Ok(name) => name,
            Err(err) => {
                return visitor.error(Error::NameError(err)) as i32;
            }
        };
        let build_id = match get_build_id(info) {
            Some(build_id) => build_id,
            None => {
                return visitor.error(Error::BuildIDError) as i32;
            }
        };
        visitor.dso(Dso {
            name: name,
            build_id: build_id,
            phdrs: info.phdr_slice(),
            base: info.addr as usize,
        }) as i32
    }
    unsafe { dl_iterate_phdr(callback, &mut visitor) };
}

struct DsoPrinter<'a, 'b> {
    writer: &'a mut core::fmt::Formatter<'b>,
    module_count: usize,
    error: core::fmt::Result,
}

impl DsoPrinter<'_, '_> {
    fn dso(&mut self, dso: Dso<'_>) -> bool {
        let mut write = || {
            write!(
                self.writer,
                "{{{{{{module:{:#x}:{}:elf:{}}}}}}}\n",
                self.module_count,
                dso.name,
                HexSlice {
                    bytes: dso.build_id.as_ref()
                }
            )?;
            for seg in dso.segments() {
                write!(
                    self.writer,
                    "{{{{{{mmap:{:#x}:{:#x}:load:{:#x}:{}:{:#x}}}}}}}\n",
                    seg.addr, seg.size, self.module_count, seg.flags, seg.mod_rel_addr
                )?;
            }
            self.module_count += 1;
            Ok(())
        };
        match write() {
            Ok(()) => false,
            Err(err) => {
                self.error = Err(err);
                true
            }
        }
    }
    fn error(&mut self, _error: Error) -> bool {
        false
    }
}

/// Ця функція друкує розмітку символізації Fuchsia для всієї інформації, що міститься в DSO.
pub fn print_dso_context(out: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
    out.write_str("{{{reset}}}\n")?;
    let mut visitor = DsoPrinter {
        writer: out,
        module_count: 0,
        error: Ok(()),
    };
    for_each_dso(&mut visitor);
    visitor.error
}