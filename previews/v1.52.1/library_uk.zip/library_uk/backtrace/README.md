# backtrace-rs

[Documentation](https://docs.rs/backtrace)

Бібліотека для отримання зворотних відстежень під час виконання для Rust.
Ця бібліотека має на меті покращити підтримку стандартної бібліотеки, надаючи програмний інтерфейс для роботи, але вона також підтримує простою друк поточного зворотного трасування, як panics libstd.

## Install

```toml
[dependencies]
backtrace = "0.3"
```

## Usage

Щоб просто зафіксувати зворотну трасування та відкласти справу з нею до пізнішого часу, ви можете використовувати тип `Backtrace` верхнього рівня.

```rust
use backtrace::Backtrace;

fn main() {
    let bt = Backtrace::new();

    // do_some_work();

    println!("{:?}", bt);
}
```

Якщо, однак, ви хочете отримати необроблений доступ до фактичної функціональності відстеження, ви можете використовувати функції `trace` та `resolve` безпосередньо.

```rust
fn main() {
    backtrace::trace(|frame| {
        let ip = frame.ip();
        let symbol_address = frame.symbol_address();

        // Вирішіть цей вказівник інструкції на ім'я символу
        backtrace::resolve_frame(frame, |symbol| {
            if let Some(name) = symbol.name() {
                // ...
            }
            if let Some(filename) = symbol.filename() {
                // ...
            }
        });

        true // продовжуйте переходити до наступного кадру
    });
}
```

# License

Цей проект ліцензовано під будь-яким із цих

 * Ліцензія Apache, версія 2.0, ([LICENSE-APACHE](LICENSE-APACHE) або http://www.apache.org/licenses/LICENSE-2.0)
 * Ліцензія MIT ([LICENSE-MIT](LICENSE-MIT) або http://opensource.org/licenses/MIT)

на ваш вибір.

### Contribution

Якщо ви прямо не вказали інше, будь-який внесок, навмисно поданий для включення вас до зворотних відслідковувань, як визначено в ліцензії Apache-2.0, повинен мати подвійну ліцензію, як зазначено вище, без будь-яких додаткових умов чи умов.







