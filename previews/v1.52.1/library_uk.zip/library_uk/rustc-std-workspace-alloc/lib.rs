#![feature(no_core)]
#![no_core]

// Див. rustc-std-workspace-core для того, чому потрібен цей crate.

// Перейменуйте crate, щоб уникнути конфлікту з модулем alloc у liballoc.
extern crate alloc as foo;

pub use foo::*;