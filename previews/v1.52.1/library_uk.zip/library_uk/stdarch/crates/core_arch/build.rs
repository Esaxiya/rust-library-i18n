use std::env;

fn main() {
    println!("cargo:rustc-cfg=core_arch_docs");

    // Використовується для того, щоб повідомляти нашим анотаціям `#[assert_instr]`, що всі внутрішні характеристики simd доступні для тестування їх кодегенів, оскільки деякі з них стоять за додатковим `-Ctarget-feature=+unimplemented-simd128`, який зараз не має еквівалента в `#[target_feature]`.
    //
    //
    //
    println!("cargo:rerun-if-env-changed=RUSTFLAGS");
    if env::var("RUSTFLAGS")
        .unwrap_or_default()
        .contains("unimplemented-simd128")
    {
        println!("cargo:rustc-cfg=all_simd");
    }
}