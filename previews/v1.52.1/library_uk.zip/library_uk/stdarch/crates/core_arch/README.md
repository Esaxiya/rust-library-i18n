`core::arch` - Основні особливості архітектури бібліотеки Rust
=======

[![core_arch_crate_badge]][core_arch_crate_link] [![core_arch_docs_badge]][core_arch_docs_link]

Модуль `core::arch` реалізує властиві архітектурі властивості (наприклад, SIMD).

# Usage 

`core::arch` доступний як частина `libcore` і реекспортується `libstd`.Краще використовувати його через `core::arch` або `std::arch`, ніж через crate.
Нестійкі функції часто доступні в нічному Rust через `feature(stdsimd)`.

Використання `core::arch` через цей crate вимагає нічного Rust, і він може (і робить) часто ламатися.Єдиними випадками, коли вам слід розглянути можливість використання його за допомогою цього crate, є:

* якщо вам потрібно перекомпілювати `core::arch` самостійно, наприклад, з увімкненими певними цільовими функціями, які не ввімкнені для `libcore`/`libstd`.
Note: якщо вам потрібно повторно скомпілювати його для нестандартної цілі, будь ласка, віддайте перевагу використанню `xargo` та перекомпіляції `libcore`/`libstd` за необхідністю замість використання цього crate.
  
* використання деяких функцій, які можуть бути недоступні навіть за нестабільними функціями Rust.Ми намагаємося їх звести до мінімуму.
Якщо вам потрібно скористатися деякими з цих функцій, відкрийте проблему, щоб ми могли виставити їх у нічному Rust, і ви зможете ними користуватися звідти.

# Documentation

* [Documentation - i686][i686]
* [Documentation - x86\_64][x86_64]
* [Documentation - arm][arm]
* [Documentation - aarch64][aarch64]
* [Documentation - powerpc][powerpc]
* [Documentation - powerpc64][powerpc64]
* [How to get started][contrib]
* [How to help implement intrinsics][help-implement]

[contrib]: https://github.com/rust-lang/stdarch/blob/master/CONTRIBUTING.md
[help-implement]: https://github.com/rust-lang/stdarch/issues/40
[i686]: https://rust-lang.github.io/stdarch/i686/core_arch/
[x86_64]: https://rust-lang.github.io/stdarch/x86_64/core_arch/
[arm]: https://rust-lang.github.io/stdarch/arm/core_arch/
[aarch64]: https://rust-lang.github.io/stdarch/aarch64/core_arch/
[powerpc]: https://rust-lang.github.io/stdarch/powerpc/core_arch/
[powerpc64]: https://rust-lang.github.io/stdarch/powerpc64/core_arch/

# License

`core_arch` в основному розповсюджується на умовах як ліцензії MIT, так і ліцензії Apache (версія 2.0), причому частини, охоплені різними BSD-подібними ліцензіями.

Детальніше див. У розділі LICENSE-APACHE та LICENSE-MIT.

# Contribution

Якщо ви прямо не вказали інше, будь-який внесок, який ви навмисно подали для включення до `core_arch`, як визначено в ліцензії Apache-2.0, повинен мати подвійну ліцензію, як зазначено вище, без будь-яких додаткових умов чи умов.


[core_arch_crate_badge]: https://img.shields.io/crates/v/core_arch.svg
[core_arch_crate_link]: https://crates.io/crates/core_arch
[core_arch_docs_badge]: https://docs.rs/core_arch/badge.svg
[core_arch_docs_link]: https://docs.rs/core_arch/












