use super::super::*;
use core::num::bignum::Big32x40 as Big;
use core::num::flt2dec::strategy::dragon::*;

#[test]
fn test_mul_pow10() {
    let mut prevpow10 = Big::from_small(1);
    for i in 1..340 {
        let mut curpow10 = Big::from_small(1);
        mul_pow10(&mut curpow10, i);
        assert_eq!(curpow10, *prevpow10.clone().mul_small(10));
        prevpow10 = curpow10;
    }
}

#[test]
fn shortest_sanity_test() {
    f64_shortest_sanity_test(format_shortest);
    f32_shortest_sanity_test(format_shortest);
    more_shortest_sanity_test(format_shortest);
}

#[test]
#[cfg_attr(miri, ignore)] // Miri alon banget
fn exact_sanity_test() {
    // Tes iki pungkasane mbukak apa sing bisa dakkira yaiku sawetara kasus sudhut fungsi perpustakaan `exp2`, sing ditemtokake ing C runtime apa wae sing digunakake.
    // Ing VS 2013, fungsi iki jebule duwe bug amarga tes iki gagal nalika disambung, nanging karo VS 2015 bug kasebut katon tetep amarga tes kasebut mlaku kanthi apik.
    //
    // Bug kasebut koyone beda karo nilai bali `exp2(-1057)`, lan ing VS 2013 ngasilake dobel kanthi pola bit 0x2 lan ing VS 2015 ngasilake 0x20000.
    //
    //
    // Kanggo saiki, coba coba coba coba ora ditrapake ing MSVC amarga wis dites ing papan liya lan kita ora kepengin banget nyoba ngetrapake implementasi exp2 saben platform.
    //
    //
    //
    //
    //
    //
    if !cfg!(target_env = "msvc") {
        f64_exact_sanity_test(format_exact);
    }
    f32_exact_sanity_test(format_exact);
}

#[test]
fn test_to_shortest_str() {
    to_shortest_str_test(format_shortest);
}

#[test]
fn test_to_shortest_exp_str() {
    to_shortest_exp_str_test(format_shortest);
}

#[test]
fn test_to_exact_exp_str() {
    to_exact_exp_str_test(format_exact);
}

#[test]
fn test_to_exact_fixed_str() {
    to_exact_fixed_str_test(format_exact);
}