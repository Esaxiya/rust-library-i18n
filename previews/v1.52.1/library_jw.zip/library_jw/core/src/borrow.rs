//! Modul kanggo nggarap data sing dipinjam.

#![stable(feature = "rust1", since = "1.0.0")]

/// trait kanggo data utang.
///
/// Ing Rust, umume nyedhiyakake macem-macem representasi kanggo macem-macem kasus panggunaan.
/// Contone, lokasi panyimpenan lan manajemen kanggo nilai bisa dipilih kanthi tepat kanggo panggunaan tartamtu liwat jinis penunjuk kayata [`Box<T>`] utawa [`Rc<T>`].
/// Ngluwihi pambungkus umum iki sing bisa digunakake kanthi jinis apa wae, sawetara jinis nyedhiyakake aspek opsional sing nyedhiyakake fungsi sing larang regane.
/// Contone kanggo jinis kasebut yaiku [`String`] sing nambah kemampuan kanggo ngluwihi senar menyang [`str`] dhasar.
/// Iki mbutuhake supaya informasi tambahan ora prelu kanggo senar sing gampang diganti.
///
/// Jinis kasebut nyedhiyakake akses menyang data dhasar liwat referensi jinis data kasebut.Dheweke diarani 'diselang' jinis kasebut.
/// Contone, [`Box<T>`] bisa dipinjam dadi `T` dene [`String`] bisa disilih dadi `str`.
///
/// Jinis nyebutake yen bisa disilih minangka sawetara jinis `T` kanthi ngetrapake `Borrow<T>`, menehi referensi menyang `T` ing metode [`borrow`] XX trait.Jinis bebas nyilih minangka macem-macem jinis.
/// Yen kapengin mutably nyilih minangka jinis-saéngga data ndasari dipunéwahi, iku tambahan bisa ngleksanakake [`BorrowMut<T>`].
///
/// Salajengipun, nalika nyedhiyakake implementasi kanggo traits tambahan, kudu dipikirake manawa tumindak kasebut kudu padha karo jinis-jinis dhasar minangka akibat saka tumindak minangka perwakilan saka jinis dhasar kasebut.
/// kode Generic biasane migunakake `Borrow<T>` nalika gumantung ing prilaku podho rupo iki nindakake trait tambahan.
/// traits iki bisa uga katon minangka trait bounds tambahan.
///
/// Khusus `Eq`, `Ord` lan `Hash` kudu padha karo nilai sing dipinjam lan diduweni: `x.borrow() == y.borrow()` kudu menehi asil sing padha karo `x == y`.
///
/// Yen kode umum namung perlu kanggo karya kanggo kabeh jinis sing bisa nyedhiyani referensi kanggo jinis sing gegandhengan `T`, iku luwih kerep nggunakake [`AsRef<T>`] minangka liyane jinis aman bisa ngleksanakake iku.
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
/// [`Mutex<T>`]: ../../std/sync/struct.Mutex.html
/// [`Rc<T>`]: ../../std/rc/struct.Rc.html
/// [`String`]: ../../std/string/struct.String.html
/// [`borrow`]: Borrow::borrow
///
/// # Examples
///
/// Minangka nglumpukake data, [`HashMap<K, V>`] duwe kunci lan nilai.Yen data tombol kang nyata wis kebungkus ing jinis ngatur saka sawetara jenis, iku kudu, Nanging, isih bisa nelusuri Nilai nggunakake referensi kanggo data tombol kang.
/// Contone, yen tombol iku senar, mula bisa disimpen karo peta hash minangka [`String`], sauntara kudune bisa digoleki nggunakake [`&str`][`str`].
/// Mangkene, `insert` kudu beroperasi ing `String` nalika `get` kudu bisa nggunakake `&str`.
///
/// Sederhana, bagean `HashMap<K, V>` sing relevan katon kaya iki:
///
/// ```
/// use std::borrow::Borrow;
/// use std::hash::Hash;
///
/// pub struct HashMap<K, V> {
///     # marker: ::std::marker::PhantomData<(K, V)>,
///     // lapangan tilar
/// }
///
/// impl<K, V> HashMap<K, V> {
///     pub fn insert(&self, key: K, value: V) -> Option<V>
///     where K: Hash + Eq
///     {
///         # unimplemented!()
///         // ...
///     }
///
///     pub fn get<Q>(&self, k: &Q) -> Option<&V>
///     where
///         K: Borrow<Q>,
///         Q: Hash + Eq + ?Sized
///     {
///         # unimplemented!()
///         // ...
///     }
/// }
/// ```
///
/// Peta hash umum kanggo jinis kunci `K`.Amarga tombol iki disimpen nganggo peta hash, jinis iki kudu nduweni data kunci.
/// Nalika nambahi pasangan tombol-nilai, peta diwenehi kuwi `K` lan kabutuhan kanggo golek ember ngrembug bener lan mriksa yen tombol wis saiki adhedhasar sing `K`.Mula mbutuhake `K: Hash + Eq`.
///
/// Nalika nggoleki nilai ing peta, Nanging, gadhah kanggo nyedhiyani referensi kanggo `K` minangka tombol kanggo nelusuri bakal mbutuhake kanggo tansah nggawe kuwi nilai diduweni.
/// Kanggo tombol senar, iki bakal jahat Nilai `String` perlu digawe mung kanggo search for njagani mung `str` cumawis.
///
/// Nanging, metode `get` umum kanggo jinis data kunci sing diarani, diarani `Q` ing teken metode ing ndhuwur.Iki nyatakake yen `K` nyilih minangka `Q` kanthi mbutuhake `K: Borrow<Q>` kasebut.
/// Kajaba mbutuhake `Q: Hash + Eq`, sinyal kasebut sarat yen `K` lan `Q` duwe implementasi `Hash` lan `Eq` traits sing ngasilake asil sing padha.
///
/// Implementasine saka `get` gumantung ing tartamtu ing nindakake podho rupo `Hash` dening nentokake ember ngrembug tombol kang dening nelpon `Hash::hash` ing Nilai `Q` sanadyan iku dipasang tombol adhedhasar Nilai ngrembug diwilang saka nilai `K`.
///
///
/// Akibate, peta hash rusak yen `K` sing mbungkus nilai `Q` ngasilake hash beda tinimbang `Q`.Contone, bayangake sampeyan duwe jinis sing mbungkus senar nanging mbandhingake huruf ASCII sing ora nggatekake kasus kasebut:
///
/// ```
/// pub struct CaseInsensitiveString(String);
///
/// impl PartialEq for CaseInsensitiveString {
///     fn eq(&self, other: &Self) -> bool {
///         self.0.eq_ignore_ascii_case(&other.0)
///     }
/// }
///
/// impl Eq for CaseInsensitiveString { }
/// ```
///
/// Amarga rong nilai sing padha kudu ngasilake nilai hash sing padha, implementasine `Hash` uga kudu ora nggatekake kasus ASCII:
///
/// ```
/// # use std::hash::{Hash, Hasher};
/// # pub struct CaseInsensitiveString(String);
/// impl Hash for CaseInsensitiveString {
///     fn hash<H: Hasher>(&self, state: &mut H) {
///         for c in self.0.as_bytes() {
///             c.to_ascii_lowercase().hash(state)
///         }
///     }
/// }
/// ```
///
/// Apa `CaseInsensitiveString` bisa ngetrapake `Borrow<str>`?Mesthi bisa menehi referensi irisan senar liwat senar sing diduweni.
/// Nanging amarga implementasine `Hash` beda-beda, beda karo `str`, mula ora kudu ngetrapake `Borrow<str>`.
/// Yen kepengin kanggo ngidini akses wong kanggo ing `str` ndasari, bisa nindakake sing liwat `AsRef<str>` kang ora nindakake apa syarat ekstra.
///
/// [`Hash`]: crate::hash::Hash
/// [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
/// [`String`]: ../../std/string/struct.String.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Borrow"]
pub trait Borrow<Borrowed: ?Sized> {
    /// Ora bisa ganti nyilih saka regane sing diduweni.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::borrow::Borrow;
    ///
    /// fn check<T: Borrow<str>>(s: T) {
    ///     assert_eq!("Hello", s.borrow());
    /// }
    ///
    /// let s = "Hello".to_string();
    ///
    /// check(s);
    ///
    /// let s = "Hello";
    ///
    /// check(s);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn borrow(&self) -> &Borrowed;
}

/// trait kanggo data utang sing bisa diganti.
///
/// Minangka kanca kanggo [`Borrow<T>`] trait iki ngidini jinis nyilih minangka jinis ndasari dening nyediakake referensi mutable.
/// Waca [`Borrow<T>`] kanggo informasi sing luwih utang minangka jinis.
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait BorrowMut<Borrowed: ?Sized>: Borrow<Borrowed> {
    /// Mutably borrows saka nilai diduweni.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::borrow::BorrowMut;
    ///
    /// fn check<T: BorrowMut<[i32]>>(mut v: T) {
    ///     assert_eq!(&mut [1, 2, 3], v.borrow_mut());
    /// }
    ///
    /// let v = vec![1, 2, 3];
    ///
    /// check(v);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn borrow_mut(&mut self) -> &mut Borrowed;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for T {
    #[rustc_diagnostic_item = "noop_method_borrow"]
    fn borrow(&self) -> &T {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> BorrowMut<T> for T {
    fn borrow_mut(&mut self) -> &mut T {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for &T {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for &mut T {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> BorrowMut<T> for &mut T {
    fn borrow_mut(&mut self) -> &mut T {
        &mut **self
    }
}