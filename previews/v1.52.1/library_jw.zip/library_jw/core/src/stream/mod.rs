//! Pengulangan asinkron sing bisa digawe.
//!
//! Yen futures sing angka bedo, banjur lepen sing iterators bedo.
//! Yen wis ketemu dhewe karo koleksi bedo saka sawetara jinis, lan perlu kanggo nindakake operasi ing unsur kang koleksi ngandika, sampeyan bakal cepet mbukak menyang 'streams'.
//! Aliran digunakake banget ing kode Rust asinkron idiomatik, mula dadi akrab karo dheweke.
//!
//! Sadurunge nerangake luwih lengkap, ayo ngobrol babagan cara struktur modul iki:
//!
//! # Organization
//!
//! modul iki umumé diatur dening jinis:
//!
//! * [Traits] sing bagean inti: traits iki nemtokaké apa jenis lepen ana lan apa sing bisa apa karo wong.Ing cara traits iki worth panggolekan sawetara wektu sinau ekstra menyang.
//! * Fungsi nyedhiyani sawetara cara mbiyantu kanggo nggawe sawetara lepen dhasar.
//! * Struktur asring minangka jinis bali saka macem-macem cara ing traits modul iki.Sampeyan biasane pengin ndeleng cara sing nggawe `struct`, tinimbang `struct` dhewe.
//! Kanggo luwih rinci babagan sebab apa, waca '[Stream Implementing Stream](#implementing-stream)'.
//!
//! [Traits]: #traits
//!
//! Iku kabeh!Ayo digali menyang lepen.
//!
//! # Stream
//!
//! Jantung lan jiwa modul iki yaiku [`Stream`] trait.Inti [`Stream`] katon kaya iki:
//!
//! ```
//! # use core::task::{Context, Poll};
//! # use core::pin::Pin;
//! trait Stream {
//!     type Item;
//!     fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>>;
//! }
//! ```
//!
//! Boten kados `Iterator`, `Stream` ndadekake bédané antara cara [`poll_next`] kang digunakake nalika penerapan `Stream`, lan cara (to-be-implemented) `next` kang digunakake nalika akeh stream.
//!
//! Konsumen saka `Stream` mung perlu nimbang `next`, kang nalika disebut, ngasilake future kang panenan `Option<Stream::Item>`.
//!
//! future bali dening `next` bakal ngasilake `Some(Item)` anggere ana elemen, lan yen kabeh wis kesel, bakal ngasilake `None` kanggo nunjukake yen pengulangan rampung.
//! Yen kita ngenteni asinkron kanggo ngrampungake, future bakal ngenteni nganti stream siap ngasilake maneh.
//!
//! Aliran individu bisa milih nerusake pengulangan, lan nelpon `next` maneh bisa uga ngasilake `Some(Item)` maneh ing sawetara wektu.
//!
//! Definisi lengkap [`Stream`] kalebu uga sawetara cara liyane, nanging kalebu metode default, dibangun ing ndhuwur [`poll_next`], mula sampeyan bisa njaluk gratis.
//!
//! [`Poll`]: super::task::Poll
//! [`poll_next`]: Stream::poll_next
//!
//! # Ngleksanakake Stream
//!
//! Nggawe stream sampeyan dhewe kalebu rong langkah: nggawe `struct` kanggo nahan status stream, lan banjur ngetrapake [`Stream`] kanggo `struct` kasebut.
//!
//! Ayo dadi gawe stream jenenge `Counter` kang counts saka `1` kanggo `5`:
//!
//! ```no_run
//! #![feature(async_stream)]
//! # use core::stream::Stream;
//! # use core::task::{Context, Poll};
//! # use core::pin::Pin;
//!
//! // Pisanan, strukture:
//!
//! /// Aliran sing cacahe saka siji nganti lima
//! struct Counter {
//!     count: usize,
//! }
//!
//! // kita pengin hitungan diwiwiti, dadi ayo nambah cara new() kanggo mbantu.
//! // Iki ora prelu banget, nanging luwih gampang.
//! // Elinga yen kita miwiti `count` nol, kita bakal ngerteni kenapa implementasine `poll_next()`'s ing ngisor iki.
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // Banjur, kita ngetrapake `Stream` kanggo `Counter`:
//!
//! impl Stream for Counter {
//!     // kita bakal ngetung nganggo usize
//!     type Item = usize;
//!
//!     // poll_next() mung cara sing dibutuhake
//!     fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
//!         // Nambah jumlah kita.Iki kok kita miwiti ing nul.
//!         self.count += 1;
//!
//!         // Priksa manawa kita wis rampung ngetung utawa ora.
//!         if self.count < 6 {
//!             Poll::Ready(Some(self.count))
//!         } else {
//!             Poll::Ready(None)
//!         }
//!     }
//! }
//! ```
//!
//! # Laziness
//!
//! Aliran sing *puguh*.Tegese sing mung nggawe stream ora _do_ akèh kabèh.Ora ana kedadeyan sing nyata nganti sampeyan nelpon `next`.
//! Kadang iki dadi sumber kebingungan nalika nggawe stream mung kanggo efek samping.
//! Panyusun bakal menehi peringatan babagan prilaku kasebut:
//!
//! ```text
//! warning: unused result that must be used: streams do nothing unless polled
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

mod stream;

pub use stream::Stream;