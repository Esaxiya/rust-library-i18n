use crate::ops::DerefMut;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// Antarmuka kanggo dealing with iterators bedo.
///
/// Iki stream utama trait.
/// Kanggo luwih lengkap babagan konsep aliran umume, waca [module-level documentation].
/// Utamane, sampeyan bisa uga pengin ngerti cara [implement `Stream`][impl].
///
/// [module-level documentation]: index.html
/// [impl]: index.html#implementing-stream
#[unstable(feature = "async_stream", issue = "79024")]
#[must_use = "streams do nothing unless polled"]
pub trait Stream {
    /// Jinis barang sing ngasilake aliran.
    type Item;

    /// Nyoba kanggo narik angka sabanjure stream iki, ndhaptar tugas saiki kanggo tangi yen regane durung kasedhiya, lan ngasilake `None` yen stream wis entek.
    ///
    /// # Nilai bali
    ///
    /// Ana sawetara kemungkinan nilai bali, masing-masing nuduhake kahanan stream sing beda:
    ///
    /// - `Poll::Pending` tegese regane sabanjure stream iki durung siyap.Implementasi bakal njamin manawa tugas saiki bakal dikabari nalika regane sabanjure wis siyap.
    ///
    /// - `Poll::Ready(Some(val))` tegese stream wis sukses ngasilake angka, `val`, lan bisa ngasilake angka luwih lanjut ing telpon `poll_next` sabanjure.
    ///
    /// - `Poll::Ready(None)` tegese stream wis diakhiri, lan `poll_next` ora bisa ditimbali maneh.
    ///
    /// # Panics
    ///
    /// Sawise stream wis rampung (bali `Ready(None)` from `poll_next`), nelpon cara `poll_next` maneh bisa panic, mblokir salawas-lawase, utawa sabab jinis masalah; ing `Stream` trait panggonan ora syarat ing efek saka telpon kuwi.
    ///
    /// Nanging, minangka cara `poll_next` ora ditandhani `unsafe`, aturan biasanipun Rust kang aplikasi: telpon ora kudu nimbulaké prilaku cetho (korupsi memori, nggunakake salah fungsi `unsafe`, utawa kaya), preduli saka negara stream kang.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>>;

    /// Ngasilake wates ing sisa aliran kasebut.
    ///
    /// Khusus, `size_hint()` ngasilake tuple ngendi unsur kapisan ing ngisor kaiket, lan unsur kaping kalih inggih punika ndhuwur kaiket.
    ///
    /// Separo ing tuple sing wis bali iku sawijining [: Option`]: <: [: usize`]:>:.
    /// A [`None`] kene liya sing salah siji ana dikenal ndhuwur kaiket, utawa ing ndhuwur kaiket luwih [`usize`].
    ///
    /// # Implementasi
    ///
    /// Iku ora tindakaken sing implementasine stream panenan nomer ngumumaké unsur.A stream jip bisa ngasilaken kurang luwih murah kaiket utawa luwih saka ing ndhuwur kaiket saka unsur.
    ///
    /// `size_hint()` utamane dimaksudake kanggo digunakake kanggo optimalisasi kayata cadangan papan kanggo elemen stream, nanging ora kudu dipercaya, umpamane, ngilangi cek ing kode sing ora aman.
    /// Implementasi `size_hint()` sing salah ora nyebabake pelanggaran keamanan memori.
    ///
    /// Sing ngandika, implementasine ngirim nyedhiyani ngira-ira, amarga digunakake, iku bakal nglanggar protokol trait kang.
    ///
    /// Implementasine default ngasilake `(0,` [`Nothing`]`)` sing bener kanggo stream apa wae.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<S: ?Sized + Stream + Unpin> Stream for &mut S {
    type Item = S::Item;

    fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        S::poll_next(Pin::new(&mut **self), cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<P> Stream for Pin<P>
where
    P: DerefMut + Unpin,
    P::Target: Stream,
{
    type Item = <P::Target as Stream>::Item;

    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        self.get_mut().as_mut().poll_next(cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}