//! Jinis sing nyelehake data menyang dununge ing memori.
//!
//! Iku kadang migunani kanggo duwe obyek sing dijamin ora kanggo mindhah, ing pangertèn sing seko ing memori ora ngganti, lan bisa mangkono bakal migunaaké marang.
//! Conto utama skenario kasebut yaiku nggawe struktural referensi, amarga obah obyek kanthi petunjuk kanggo awake dhewe bakal mbatalake, sing bisa nyebabake prilaku sing durung ditemtokake.
//!
//! Ing tingkat dhuwur, sing [`Pin<P>`] njamin yen pointee sembarang tipe pitunjuk `P` wis lokasi stabil ing memori, tegesipun ora bisa dipindhah liya lan memori ora bisa deallocated nganti bakal dropped.Kita ujar manawa pointee yaiku "pinned".Prekara bakal luwih alus nalika ngrembug jinis sing nggabung karo data sing ora disemat;[see below](#projections-and-structural-pinning) kanggo rincian liyane.
//!
//! Kanthi gawan, kabeh jinis ing Rust bisa dipindhah.
//! Rust ngidini ngliwati kabeh jinis angka, lan jinis pointer cerdas umum kayata [`Box<T>`] lan `&mut T` ngidini ngganti lan mindhah angka sing dikandung: sampeyan bisa metu saka [`Box<T>`], utawa sampeyan bisa nggunakake [`mem::swap`].
//! [`Pin<P>`] bungkus jinis penunjuk `P`, mula [`Pin`]`<`[`Box`]`<T>>`fungsine kaya biasane
//!
//! [`Box<T>`]: when a [`Pin`]`<`[`Box`] `<T>>`bakal mudhun, uga isine, lan memori bisa dadi
//!
//! kesepakatanKajaba iku, [`Pin`]`<&mut T>` kaya `&mut T`.Nanging, [`Pin<P>`] ora ngidini klien entuk [`Box<T>`] utawa `&mut T` kanggo data sing disematkan, sing tegese sampeyan ora bisa nggunakake operasi kayata [`mem::swap`]:
//!
//! ```
//! use std::pin::Pin;
//! fn swap_pins<T>(x: Pin<&mut T>, y: Pin<&mut T>) {
//!     // `mem::swap` butuh `&mut T`, nanging ora bisa dipikolehi.
//!     // Kita macet, kita ora bisa ngganti isi referensi kasebut.
//!     // Kita bisa nggunakake `Pin::get_unchecked_mut`, nanging ora aman amarga ana sebab:
//!     // kita ora diidini nggunakake kanggo mindhah `Pin`.
//! }
//! ```
//!
//! Iku reiterating worth sing [`Pin<P>`] panjenengan *ora tau* ngowahi kasunyatan sing compiler Rust nganggep kabeh jinis dipindhahaké.[`mem::swap`] tetep bisa ditrapake kanggo `T`.Nanging, [`Pin<P>`] ngalangi *nilai* tartamtu (ditunjuk karo pointer sing dibungkus [`Pin<P>`]) supaya ora bisa dipindhah kanthi ora bisa nelpon metode sing mbutuhake `&mut T` (kaya [`mem::swap`]).
//!
//! [`Pin<P>`] bisa digunakake kanggo mbungkus jinis pointer `P`, lan kaya ngono interaksi karo [`Deref`] lan [`DerefMut`].[`Pin<P>`] ing endi `P: Deref` kudu dianggep minangka "`P`-style pointer" menyang `P::Target` sing disemat-dadi, [`Pin`]`<`[`Box`] `<T>>`minangka penunjuk kagungan `T` sing disemat, lan [`Pin`] `<` [`Rc`]`<T>>`minangka pitunjuk sing diitung referensi menyang `T` sing disemat.
//! Kanggo bener, [`Pin<P>`] gumantung karo implementasine [`Deref`] lan [`DerefMut`] supaya ora metu saka parameter `self`, lan mung bakal mbalikake pitunjuk menyang data sing disemat nalika ditunjuk ing pointer sing disemat.
//!
//! # `Unpin`
//!
//! Akeh jinis tansah bebas movable, malah nalika pinned, amarga padha ora gumantung ing gadhah alamat stabil.Iki kalebu kabeh jinis dhasar (kaya [`bool`], [`i32`], lan referensi) uga jinis sing kalebu mung kalebu jinis kasebut.Jinis-jinis sing ora Care babagan pinning ngleksanakake [`Unpin`] otomatis trait, kang cancels efek saka [`Pin<P>`].
//! Kanggo `T: Unpin`, [`Pin`]`<`[`Box`] `<T>>`lan fungsi [`Box<T>`] identik, uga [`Pin`] `<&mut T>` lan `&mut T`.
//!
//! Elinga yen pinning lan [`Unpin`] mung mengaruhi tipe `P::Target` sing runcing, dudu tipe pointer `P` dhewe sing dibungkus [`Pin<P>`].Contone, [`Box<T>`] utawa [`Unpin`] ora pengaruh ing prilaku [`Pin`]`<`[`Box`]`<T>>`((ing kene, `T` minangka jinis sing ditunjuk).
//!
//! # Tuladha: struktural referensi dhiri
//!
//! Sadurunge nerangake rincian liyane kanggo nerangake jaminan lan pilihan sing ana gandhengane karo `Pin<T>`, kita ngrembug sawetara conto babagan cara nggunakake.
//! Bebas bae kanggo [skip to where the theoretical discussion continues](#drop-guarantee).
//!
//! ```rust
//! use std::pin::Pin;
//! use std::marker::PhantomPinned;
//! use std::ptr::NonNull;
//!
//! // Iki minangka referensi mandhiri amarga kolom irisan nuduhake kolom data.
//! // Kita ora bisa menehi informasi babagan panyusun kanthi referensi normal, amarga pola iki ora bisa diterangake kanthi aturan utang umum.
//! //
//! // Nanging kita nggunakake pitunjuk mentahan, sanadyan kang dikenal ora dadi null, kita ngerti sikile iku ing senar.
//! //
//! struct Unmovable {
//!     data: String,
//!     slice: NonNull<String>,
//!     _pin: PhantomPinned,
//! }
//!
//! impl Unmovable {
//!     // Kanggo mesthekake data ora pindhah nalika fungsi bali, kita lebokake ing tumpukan ing endi obyek bakal tetep urip, lan siji-sijine cara kanggo ngakses yaiku liwat petunjuk.
//!     //
//!     //
//!     fn new(data: String) -> Pin<Box<Self>> {
//!         let res = Unmovable {
//!             data,
//!             // kita mung nggawe pointer yen data wis ana, mula wis bakal pindhah sadurunge diwiwiti
//!             //
//!             slice: NonNull::dangling(),
//!             _pin: PhantomPinned,
//!         };
//!         let mut boxed = Box::pin(res);
//!
//!         let slice = NonNull::from(&boxed.data);
//!         // kita ngerti iki aman amarga ngowahi lapangan ora mindhah kabeh struktur
//!         unsafe {
//!             let mut_ref: Pin<&mut Self> = Pin::as_mut(&mut boxed);
//!             Pin::get_unchecked_mut(mut_ref).slice = slice;
//!         }
//!         boxed
//!     }
//! }
//!
//! let unmoved = Unmovable::new("hello".to_string());
//! // Pointer kudu nuduhake lokasi sing bener, yen strukture durung pindhah.
//! //
//! // Sauntara kuwi, kita bebas milih pitunjuk.
//! # #[allow(unused_mut)]
//! let mut still_unmoved = unmoved;
//! assert_eq!(still_unmoved.slice, NonNull::from(&still_unmoved.data));
//!
//! // Amarga jinis kita ora ngetrapake Unpin, iki bakal gagal dikompilasi:
//! // ayo mut new_unmove= Unmovable::new("world".to_string());
//! // std::mem::swap(&mut *still_unmoved, &mut *new_unmoved);
//! ```
//!
//! # Tuladha: dhaptar mlebu dobel sing diganggu
//!
//! Ing dhaptar sing gegandhengan karo dobel sing diganggu, koleksi kasebut sejatine ora nyedhiyakake memori kanggo elemen kasebut dhewe.
//! Alokasi dikontrol dening klien, lan elemen bisa urip ing pigura tumpukan sing umure luwih cendhek tinimbang koleksi.
//!
//! Kanggo nggarap iki, saben elemen duwe pituduh sadurunge lan dhaptar ing dhaptar kasebut.Unsur mung bisa ditambahake nalika disemat, amarga pamindhahan elemen kasebut bakal ngilangi petunjuk.Menapa malih, ing implementasine [`Drop`] saka dhaftar unsur disambung bakal tembelan penunjuk saka sawijining leluhur lan panerus mbusak dhewe saka dhaftar.
//!
//! Sing penting, kita kudu bisa ngandel yen [`drop`] diarani.Yen sawijining elemen bisa dislokasi utawa ora valid tanpa nyebut [`drop`], panunjuk saka elemen tetanggane bakal dadi salah, sing bakal ngrusak struktur data.
//!
//! Mula, pinning uga menehi jaminan sing ana gandhengane karo [`drop`].
//!
//! # `Drop` guarantee
//!
//! Tujuan semat yaiku supaya bisa gumantung ing panggolekan sawetara data ing memori.
//! Kanggo nggarap iki, ora mung mindhah data diwatesi;deallocating, repurposing, utawa digunakake invalidating memori digunakake kanggo nyimpen data wis diwatesi, banget.
//! Secara konkrit, kanggo data sing disematkan sampeyan kudu njaga invariant sing *memori ora bakal divalidasi utawa dibalekake wiwit wayahe disemat nganti [`drop`] diarani*.Mung sapisan [`drop`] ngasilake utawa panics, memori bisa dienggo maneh.
//!
//! Memori bisa dadi "invalidated" kanthi deallocation, nanging uga ngganti [`Some(v)`] dening [`None`], utawa nelpon [`Vec::set_len`] dadi "kill" sawetara elemen saka vector.Bisa repurposed kanthi nggunakake [`ptr::write`] kanggo nimpa tanpa nelpon destruktor luwih dhisik.Ora ana siji-sijine sing diidini kanggo pin data tanpa nelpon [`drop`].
//!
//! Iki minangka jinis jaminan manawa dhaptar sing ana gandhengane saka bagean sadurunge kudu dienggo kanthi bener.
//!
//! Elinga yen jaminan iki *dudu* tegese memori ora bocor!Sampeyan isih pancen ora nate nyebut [`drop`] ing elemen sing disematkan (kayata, sampeyan isih bisa nelpon [`mem::forget`] ing [`Pin`]`<`[`Box`]`<T>>`).Ing conto dhaptar sing dobel, elemen kasebut mung bakal tetep ana ing dhaptar.Nanging sampeyan ora bisa free utawa nganggo maneh panyimpenan *tanpa nelpon [: drop`]*.
//!
//! # `Drop` implementation
//!
//! Yen jinis nggunakake pinning (kayata rong conto ing ndhuwur), sampeyan kudu ati-ati nalika ngetrapake [`Drop`].Fungsi [`drop`] njupuk `&mut self`, nanging iki diarani *sanajan jinis sampeyan sadurunge disemat*!Kayane kompilator kanthi otomatis nyebut [`Pin::get_unchecked_mut`].
//!
//! Iki ora bisa nyebabake masalah kode sing aman amarga ngetrapake jinis sing gumantung pinning mbutuhake kode sing ora aman, nanging kudu waspada yen sampeyan milih nggunakake pin ing jinis sampeyan (kayata nggunakake sawetara operasi ing [`Pin`]`<&Self>`utawa [`Pin`] `<&mut Self>`) uga duwe akibat kanggo implementasi [`Drop`]: yen elemen saka jinis sampeyan bisa disemat, sampeyan kudu nganggep [`Drop`] kanthi implisit [[Pin`]`<&mut Dhewe> `.
//!
//!
//! Contone, sampeyan bisa ngetrapake `Drop` kaya ing ngisor iki:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # struct Type { }
//! impl Drop for Type {
//!     fn drop(&mut self) {
//!         // `new_unchecked` ora apa-apa amarga kita ngerti yen nilai iki ora digunakake maneh sawise dicopot.
//!         //
//!         inner_drop(unsafe { Pin::new_unchecked(self)});
//!         fn inner_drop(this: Pin<&mut Type>) {
//!             // Kode gulung sing bener kasedhiya ing kene.
//!         }
//!     }
//! }
//! ```
//!
//! Fungsi `inner_drop` duwe jinis [`drop`]*sing kudune*, dadi iki priksa manawa sampeyan ora sengaja nggunakake `self`/`this` kanthi cara sing ora cocog karo pin.
//!
//! Menapa malih, yen jinis sampeyan `#[repr(packed)]`, panyusun kanthi otomatis bakal mindhah lapangan supaya bisa nyelehake.Sampeyan bisa uga nggawe lapangan sing cocog supaya cukup.Akibate, sampeyan ora bisa nggunakake pin kanthi jinis `#[repr(packed)]`.
//!
//! # Proyeksi lan Pin Struktural
//!
//! Nalika nggarap strukture sing disematkan, bakal ana pitakon manawa bisa ngakses kolom strukture kanthi cara sing mung njupuk [`Pin`]`<&mut Struct>`.
//! Pendekatan sing biasane yaiku nulis metode helper (sing diarani *proyeksi*) sing ngowahi [`Pin`]`<&mut Struct>` dadi referensi menyang lapangan, nanging jinis apa sing kudu ana referensi kasebut?Apa [`Pin`]`<&mut Field>`utawa `&mut Field`?
//! Pitakon sing padha muncul karo lapangan `enum`, lan uga nalika ngelingi jinis container/wrapper kayata [`Vec<T>`], [`Box<T>`], utawa [`RefCell<T>`].
//! (Pitakon iki ditrapake kanggo referensi sing bisa dipateni lan dituduhake, mung digunakake ing kene kanggo referensi sing luwih umum.)
//!
//! Pranyata sing metu iku bener nganti penulis saka struktur data kanggo mutusaké apa nggambarake pinned kanggo dadi lapangan tartamtu [: Pin`]: <&The Struct>: menyang [: Pin`]: <&The Field>: utawa `&mut Field` Nanging ana sawetara kendala, lan kendala sing paling penting yaiku *konsistensi*:
//! saben lapangan bisa *bisa uga* diproyeksikan menyang referensi sing disematkan,*utawa* wis dicopot pinning minangka bagean saka proyeksi.
//! Yen kalorone rampung ing lapangan sing padha, mesthine bakal ora sehat!
//!
//! Minangka penulis struktur data sampeyan arep kanggo saben lapangan apa pinning "propagates" kanggo lapangan iki utawa ora.
//! Semat sing nyebar uga diarani "structural", amarga ngetutake struktur jinis kasebut.
//! Ing bagean ngisor iki, kita nerangake babagan pertimbangan sing kudu digawe kanggo salah siji pilihan.
//!
//! ## Semat *ora* struktural kanggo `field`
//!
//! Kayane kontra-intuitif yen bidang strukture ora disemat, nanging iku pilihan sing paling gampang: yen [`Pin`]`<&mut Field>` ora nate digawe, ora ana sing salah!Dadi, yen sampeyan mutusake sawetara lapangan ora duwe pin struktural, sing kudu sampeyan priksa yaiku ora bakal nggawe referensi pin ing kolom kasebut.
//!
//! Bidang tanpa pin struktural bisa uga duwe metode proyeksi sing dadi [X Pin Struct>> dadi `&mut Field`:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # type Field = i32;
//! # struct Struct { field: Field }
//! impl Struct {
//!     fn pin_get_field(self: Pin<&mut Self>) -> &mut Field {
//!         // Iki ora apa-apa amarga `field` ora dianggep pin pin.
//!         unsafe { &mut self.get_unchecked_mut().field }
//!     }
//! }
//! ```
//!
//! Sampeyan bisa uga `impl Unpin for Struct`*sanajan* jinis `field` dudu [`Unpin`].Apa sing dipikirake jinis kasebut babagan pinning ora relevan nalika ora ana [`Pin`]`<&mut Field>` sing digawe.
//!
//! ## Semat *minangka* struktural kanggo `field`
//!
//! Pilihan liyane yaiku mutusake pinning yaiku "structural" kanggo `field`, tegese yen strukture disematkan uga lapangan.
//!
//! Iki ngidini nulis proyeksi sing nggawe [`Pin`]`<&mut Field>`, saengga dadi saksi manawa lapangan kasebut disemat:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # type Field = i32;
//! # struct Struct { field: Field }
//! impl Struct {
//!     fn pin_get_field(self: Pin<&mut Self>) -> Pin<&mut Field> {
//!         // Iki ora apa-apa amarga `field` pin nalika `self` wis.
//!         unsafe { self.map_unchecked_mut(|s| &mut s.field) }
//!     }
//! }
//! ```
//!
//! Nanging, pin struktural kasedhiya karo sawetara syarat ekstra:
//!
//! 1. Strukture mung kudu [`Unpin`] yen kabeh struktural bidang [`Unpin`].Iki minangka standar, nanging [`Unpin`] minangka trait sing aman, dadi panulis struktur dadi tanggung jawab sampeyan *ora* kanggo nambah kaya `impl<T> Unpin for Struct<T>`.
//! (Elinga yen nambah operasi proyeksi mbutuhake kode sing ora aman, mula kasunyatan manawa [`Unpin`] minangka trait sing aman ora nglanggar prinsip yen sampeyan mung kuwatir karo apa wae yen nggunakake `ora aman`.)
//! 2. Perusak struktur kudu ora mindhah struktural metu saka argumen kasebut.Iki minangka titik sing tepat sing diangkat ing [previous section][drop-impl]: `drop` njupuk `&mut self`, nanging strukture (lan mula lapangane) bisa uga wis pin sadurunge.
//!     Sampeyan kudu njamin yen sampeyan ora mindhah lapangan ing implementasine [`Drop`].
//!     Utamane, kaya sing wis dijelasake sadurunge, iki tegese strukture kudu *ora* dadi `#[repr(packed)]`.
//!     Deleng bagean kasebut babagan cara nulis [`drop`] kanthi cara kompilator bisa mbantu sampeyan ora sengaja ngilangi pin.
//! 3. Sampeyan kudu nggawe manawa sampeyan njogo [`Drop` guarantee][drop-guarantee]:
//!     yen strukture wis disemat, memori sing ngemot konten ora bakal ditimpa utawa dilunasi tanpa kudu ngrusak konten.
//!     Iki bisa dadi angel, minangka sekseni dening [`VecDeque<T>`]: ing destructor saka [`VecDeque<T>`] bisa gagal kanggo nelpon [`drop`] ing kabeh unsur yen siji saka destructors panics.Iki nglanggar garansi [`Drop`], amarga bisa nyebabake elemen ditrapake nalika destruktor ora diarani.([`VecDeque<T>`] ora duwe prabawa semat, mula iki ora nyebabake keganggu.)
//! 4. Sampeyan ora kudu nawakake operasi liyane sing bisa nyebabake data dipindhah saka kolom struktural nalika jinis sampeyan disemat.Contone, yen struct ngandhut lan [`Option<T>`] lan ana: take`-kaya operasi karo jinis `fn(Pin<&mut Struct<T>>) -> Option<T>`, operasi sing bisa digunakake kanggo mindhah `T` metu saka pinned `Struct<T>`-kang liya pinning ora bisa struktural palemahan nyekeli iki data
//!
//!     Kanggo conto sing luwih rumit kanggo mindhah data saka jinis pin, bayangake yen [`RefCell<T>`] duwe metode `fn get_pin_mut(self: Pin<&mut Self>) -> Pin<&mut T>`.
//!     Banjur kita bisa nindakake ing ngisor iki:
//!
//!     ```compile_fail
//!     fn exploit_ref_cell<T>(rc: Pin<&mut RefCell<T>>) {
//!         { let p = rc.as_mut().get_pin_mut(); } // Here we get pinned access to the `T`.
//!         let rc_shr: &RefCell<T> = rc.into_ref().get_ref();
//!         let b = rc_shr.borrow_mut();
//!         let content = &mut *b; // And here we have `&mut T` to the same data.
//!     }
//!     ```
//!
//!     Iki nyebabake bencana, tegese luwih dhisik bisa nyithak isi [`RefCell<T>`] (nggunakake `RefCell::get_pin_mut`) banjur mindhah konten kasebut nggunakake referensi sing bisa diowahi mengko.
//!
//! ## Examples
//!
//! Kanggo jinis kaya [`Vec<T>`], loro kemungkinan (pinning struktural utawa ora) nggawe pangertèn.
//! [`Vec<T>`] kanthi pin struktural bisa duwe metode `get_pin`/`get_pin_mut` kanggo njaluk referensi pin ing elemen.Nanging, ora *ora* ngidini nelpon [`pop`][Vec::pop] ing [`Vec<T>`] sing disemat amarga bakal mindhah konten (pin pin struktural)!Uga ora ngidini [`push`][Vec::push], sing bisa reallocate lan uga mindhah konten.
//!
//! A [`Vec<T>`] tanpa pinning struktural bisa `impl<T> Unpin for Vec<T>`, amarga isi sing tau pinned lan [`Vec<T>`] dhewe iku nggoleki karo kang dipindhah uga.
//! Nalika semat, pin mung ora ana pengaruhe marang vector.
//!
//! Ing perpustakaan standar, jinis penunjuk umume ora duwe pin struktural, mula ora menehi prabawa pin.Iki sebabé `Box<T>: Unpin` nyekel `T` kabeh.
//! Mupangat kanggo nindakake iki kanggo jinis penunjuk, amarga mindhah `Box<T>` pancen ora mindhah `T`: [`Box<T>`] bisa dipindhah kanthi bebas (aka `Unpin`) sanajan `T` ora.Nyatane, malah [`Pin`]`<`[`Box`]`<T>>: Lan [: Pin`]: <&The T>: tansah [`Unpin`] piyambak, amarga alasan ing padha: isi (ing `T`) sing pinned, nanging penunjuk piyambak bisa dipindhah tanpa obah data pinned.
//! Kanggo [`Box<T>`] lan [`Pin`]`<`[`Box`]`<T>>`, manawa konten disematake pancen independen apa pointer wis disemat, tegese pinning ora * struktural.
//!
//! Nalika ngetrapake kombinator [`Future`], sampeyan biasane mbutuhake pin struktural kanggo futures sing bersarang, amarga sampeyan kudu njaluk referensi semat kanggo nelpon [`poll`].
//! Nanging yen kombinator sampeyan ngemot data liyane sing ora perlu disematkan, sampeyan bisa nggawe kolom kasebut ora struktural lan kanthi bebas ngakses kanthi referensi sing bisa diowahi sanajan sampeyan mung duwe [`Pin`]`<&mut Self>`((kaya ing implementasine [`poll`] dhewe).
//!
//! [`Deref`]: crate::ops::Deref
//! [`DerefMut`]: crate::ops::DerefMut
//! [`mem::swap`]: crate::mem::swap
//! [`mem::forget`]: crate::mem::forget
//! [`Box<T>`]: ../../std/boxed/struct.Box.html
//! [`Vec<T>`]: ../../std/vec/struct.Vec.html
//! [`Vec::set_len`]: ../../std/vec/struct.Vec.html#method.set_len
//! [`Box`]: ../../std/boxed/struct.Box.html
//! [Vec::pop]: ../../std/vec/struct.Vec.html#method.pop
//! [Vec::push]: ../../std/vec/struct.Vec.html#method.push
//! [`Rc`]: ../../std/rc/struct.Rc.html
//! [`RefCell<T>`]: crate::cell::RefCell
//! [`drop`]: Drop::drop
//! [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
//! [`Some(v)`]: Some
//! [`ptr::write`]: crate::ptr::write
//! [`Future`]: crate::future::Future
//! [drop-impl]: #drop-implementation
//! [drop-guarantee]: #drop-guarantee
//! [`poll`]: crate::future::Future::poll
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "pin", since = "1.33.0")]

use crate::cmp::{self, PartialEq, PartialOrd};
use crate::fmt;
use crate::hash::{Hash, Hasher};
use crate::marker::{Sized, Unpin};
use crate::ops::{CoerceUnsized, Deref, DerefMut, DispatchFromDyn, Receiver};

/// Pointer sing disemat.
///
/// Iki minangka bungkus ing sekitar jinis pitunjuk sing nggawe pointer "pin" regane tetep, bisa nyegah nilai sing dirujuk dening pointer kasebut supaya ora bisa dipindhah kajaba ngetrapake [`Unpin`].
///
///
/// *Deleng dokumentasi [`pin` module] kanggo panjelasan pinning.*
///
/// [`pin` module]: self
///
// Note: asil `Clone` ing ngisor iki nyebabake unsoundness amarga bisa ditindakake
// `Clone` kanggo referensi sing bisa diowahi.
// Deleng <https://internals.rust-lang.org/t/unsoundness-in-pin/11311> kanggo rincian liyane.
#[stable(feature = "pin", since = "1.33.0")]
#[lang = "pin"]
#[fundamental]
#[repr(transparent)]
#[derive(Copy, Clone)]
pub struct Pin<P> {
    pointer: P,
}

// Implementasi ing ngisor iki ora ditemokake supaya bisa ngindhari masalah kesehatan.
// `&self.pointer` ngirim ora bisa diakses implementasine trait sing ora dipercaya.
//
// Deleng <https://internals.rust-lang.org/t/unsoundness-in-pin/11311/73> kanggo rincian liyane.
//

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref, Q: Deref> PartialEq<Pin<Q>> for Pin<P>
where
    P::Target: PartialEq<Q::Target>,
{
    fn eq(&self, other: &Pin<Q>) -> bool {
        P::Target::eq(self, other)
    }

    fn ne(&self, other: &Pin<Q>) -> bool {
        P::Target::ne(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Eq>> Eq for Pin<P> {}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref, Q: Deref> PartialOrd<Pin<Q>> for Pin<P>
where
    P::Target: PartialOrd<Q::Target>,
{
    fn partial_cmp(&self, other: &Pin<Q>) -> Option<cmp::Ordering> {
        P::Target::partial_cmp(self, other)
    }

    fn lt(&self, other: &Pin<Q>) -> bool {
        P::Target::lt(self, other)
    }

    fn le(&self, other: &Pin<Q>) -> bool {
        P::Target::le(self, other)
    }

    fn gt(&self, other: &Pin<Q>) -> bool {
        P::Target::gt(self, other)
    }

    fn ge(&self, other: &Pin<Q>) -> bool {
        P::Target::ge(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Ord>> Ord for Pin<P> {
    fn cmp(&self, other: &Self) -> cmp::Ordering {
        P::Target::cmp(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Hash>> Hash for Pin<P> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        P::Target::hash(self, state);
    }
}

impl<P: Deref<Target: Unpin>> Pin<P> {
    /// Mbangun `Pin<P>` anyar ing saubenge pointer menyang sawetara data jinis sing ngetrapake [`Unpin`].
    ///
    /// Beda karo `Pin::new_unchecked`, cara iki aman amarga pointer `P` menehi referensi menyang jinis [`Unpin`], sing mbatalake jaminan pinning.
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn new(pointer: P) -> Pin<P> {
        // SAFETY: regane sing dituduhake yaiku `Unpin`, mula ora ana sarat
        // sak pinning.
        unsafe { Pin::new_unchecked(pointer) }
    }

    /// Mbusak `Pin<P>` iki mbalekake pitunjuk dhasar.
    ///
    /// Iki mbutuhake data ing `Pin` iki yaiku [`Unpin`] supaya kita bisa nglirwakake undhangan semat nalika mbukak kunci.
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin_into_inner", since = "1.39.0")]
    pub const fn into_inner(pin: Pin<P>) -> P {
        pin.pointer
    }
}

impl<P: Deref> Pin<P> {
    /// Mbangun `Pin<P>` anyar ing sekitar referensi kanggo sawetara data saka jinis sing bisa ngleksanakake `Unpin` utawa ora.
    ///
    /// Yen `pointer` ngilangi jinis `Unpin`, `Pin::new` kudu digunakake.
    ///
    /// # Safety
    ///
    /// Konstruktor iki ora aman amarga kita ora bisa njamin yen data sing dituduhake dening `pointer` wis disematkan, tegese data ora bakal dipindhah utawa panyimpenan ora valid nganti ilang.
    /// Yen `Pin<P>` sing dibangun ora njamin yen data `P` sing ditempelake, iku nglanggar kontrak API lan bisa uga nyebabake tumindak sing durung mesthi ing operasi (safe) mengko.
    ///
    /// Kanthi nggunakake metode iki, sampeyan nggawe promise babagan implementasi `P::Deref` lan `P::DerefMut`, yen wis ana.
    /// Sing paling penting, dheweke ora kudu metu saka argumen `self`: `Pin::as_mut` lan `Pin::as_ref` bakal nelpon `DerefMut::deref_mut` lan `Deref::deref`*ing pointer sing disemat* lan ngarepake cara kasebut kanggo njaga inviting pin.
    /// Menapa malih, dening nelpon cara iki sampeyan promise sing referensi `P` dereferences kanggo ora bakal dipindhah metu saka maneh;ing tartamtu, iku ora kudu bisa diwenehi `&mut P::Target` lan banjur pindhah metu saka referensi sing (nggunakake, contone [`mem::swap`]).
    ///
    ///
    /// Contone, nelpon `Pin::new_unchecked` ing `&'a mut T` ora aman amarga sampeyan bisa menehi pin kanggo `'a` umur tartamtu, sampeyan ora bisa ngontrol manawa terus dijepet nalika `'a` rampung:
    ///
    /// ```
    /// use std::mem;
    /// use std::pin::Pin;
    ///
    /// fn move_pinned_ref<T>(mut a: T, mut b: T) {
    ///     unsafe {
    ///         let p: Pin<&mut T> = Pin::new_unchecked(&mut a);
    ///         // Iki tegese pointee `a` ora bisa pindhah maneh.
    ///     }
    ///     mem::swap(&mut a, &mut b);
    ///     // Alamat `a` diganti dadi slot tumpukan `b`, mula `a` pindhah sanajan kita sadurunge wis pin!Kita wis nglanggar kontrak API semat.
    /////
    /// }
    /// ```
    ///
    /// Angka, sapisan pinned, kudu tetep pinned salawas-lawase (kajaba jinis nindakake sawijining `Unpin`).
    ///
    /// Kajaba, nelpon `Pin::new_unchecked` ing `Rc<T>` ora aman amarga bisa uga ana alias kanggo data sing padha sing ora dikenani watesan pin:
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::pin::Pin;
    ///
    /// fn move_pinned_rc<T>(mut x: Rc<T>) {
    ///     let pinned = unsafe { Pin::new_unchecked(Rc::clone(&x)) };
    ///     {
    ///         let p: Pin<&T> = pinned.as_ref();
    ///         // Iki tegese wong sing nunjuk ora bisa pindhah maneh.
    ///     }
    ///     drop(pinned);
    ///     let content = Rc::get_mut(&mut x).unwrap();
    ///     // Saiki, yen `x` minangka referensi siji-sijine, kita duwe referensi sing bisa diowahi kanggo data sing wis dipasang ing ndhuwur, sing bisa digunakake kanggo mindhah kaya sing dideleng ing conto sadurunge.
    ///     // Kita wis nglanggar kontrak API semat.
    /////
    ///  }
    ///  ```
    ///
    /// [`mem::swap`]: crate::mem::swap
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[lang = "new_unchecked"]
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const unsafe fn new_unchecked(pointer: P) -> Pin<P> {
        Pin { pointer }
    }

    /// Entuk referensi sambungan sing disemat saka pitunjuk semat iki.
    ///
    /// Iki minangka cara umum kanggo pindhah saka `&Pin<Pointer<T>>` dadi `Pin<&T>`.
    /// Aman amarga, minangka bagean saka kontrak `Pin::new_unchecked`, pointee ora bisa obah sawise `Pin<Pointer<T>>` digawe.
    ///
    /// "Malicious" implementasi `Pointer::Deref` uga dikalahake karo kontrak `Pin::new_unchecked`.
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn as_ref(&self) -> Pin<&P::Target> {
        // SAFETY: deleng dokumentasi babagan fungsi iki
        unsafe { Pin::new_unchecked(&*self.pointer) }
    }

    /// Mbusak `Pin<P>` iki mbalekake pitunjuk dhasar.
    ///
    /// # Safety
    ///
    /// Fungsi iki ora aman.Sampeyan kudu njamin sing bakal terus kanggo nambani pitunjuk `P` minangka pinned sawise sampeyan nelpon fungsi iki, supaya invariants ing jinis `Pin` bisa ayating.
    /// Yen kode sing nggunakake `P` sing diasilake ora terus njaga invariants pinning sing nglanggar kontrak API lan bisa uga nyebabake tumindak sing durung mesthi ing operasi (safe) mengko.
    ///
    ///
    /// Yen data sing ndasari [`Unpin`], [`Pin::into_inner`] kudu digunakake.
    ///
    ///
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin_into_inner", since = "1.39.0")]
    pub const unsafe fn into_inner_unchecked(pin: Pin<P>) -> P {
        pin.pointer
    }
}

impl<P: DerefMut> Pin<P> {
    /// Entuk referensi sing bisa dipateni saka pin pointer iki.
    ///
    /// Iki minangka cara umum kanggo pindhah saka `&mut Pin<Pointer<T>>` dadi `Pin<&mut T>`.
    /// Aman amarga, minangka bagean saka kontrak `Pin::new_unchecked`, pointee ora bisa obah sawise `Pin<Pointer<T>>` digawe.
    ///
    /// "Malicious" implementasi `Pointer::DerefMut` uga dikalahake karo kontrak `Pin::new_unchecked`.
    ///
    /// Cara iki migunani nalika nindakake sawetara panggilan menyang fungsi sing nggunakake jinis pin.
    ///
    /// # Example
    ///
    /// ```
    /// use std::pin::Pin;
    ///
    /// # struct Type {}
    /// impl Type {
    ///     fn method(self: Pin<&mut Self>) {
    ///         // nindakake soko
    ///     }
    ///
    ///     fn call_method_twice(mut self: Pin<&mut Self>) {
    ///         // `method` nganggo `self`, mula mbaleni maneh `Pin<&mut Self>` liwat `as_mut`.
    ///         self.as_mut().method();
    ///         self.as_mut().method();
    ///     }
    /// }
    /// ```
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn as_mut(&mut self) -> Pin<&mut P::Target> {
        // SAFETY: deleng dokumentasi babagan fungsi iki
        unsafe { Pin::new_unchecked(&mut *self.pointer) }
    }

    /// Menehi nilai anyar menyang memori ing mburi referensi sing disematkan.
    ///
    /// Iki bakal nimpa data sing disemat, nanging ora apa-apa: sing ngrusak bisa mbukak sadurunge ditimpa, dadi ora ana jaminan pinning sing dilanggar.
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn set(&mut self, value: P::Target)
    where
        P::Target: Sized,
    {
        *(self.pointer) = value;
    }
}

impl<'a, T: ?Sized> Pin<&'a T> {
    /// Mbangun pin anyar kanthi menehi peta nilai interior.
    ///
    /// Contone, yen wanted kanggo njaluk `Pin` saka lapangan soko, sampeyan bisa nggunakake kanggo njaluk akses menyang lapangan sing ing siji garis kode.
    /// Nanging, ana pirang-pirang gotza kanthi "pinning projections" iki;
    /// deleng dokumentasi [`pin` module] kanggo rincian luwih lengkap babagan topik kasebut.
    ///
    /// # Safety
    ///
    /// Fungsi iki ora aman.
    /// Sampeyan kudu njamin yen data sing sampeyan baleni ora bakal pindhah suwe yen nilai argumen ora pindhah (umpamane, amarga iki minangka salah sawijining kolom nilai kasebut), lan uga sampeyan ora bisa metu saka argumen sing ditampa fungsi interior.
    ///
    ///
    /// [`pin` module]: self#projections-and-structural-pinning
    ///
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    pub unsafe fn map_unchecked<U, F>(self, func: F) -> Pin<&'a U>
    where
        U: ?Sized,
        F: FnOnce(&T) -> &U,
    {
        let pointer = &*self.pointer;
        let new_pointer = func(pointer);

        // SAFETY: kontrak keamanan kanggo `new_unchecked` kudu
        // ayating panelpon.
        unsafe { Pin::new_unchecked(new_pointer) }
    }

    /// Entuk referensi bareng saka pin.
    ///
    /// Iki aman amarga ora bisa metu saka referensi sing dituduhake.
    /// Kayane ana masalah ing kene kanthi mutasi interior: nyatane *bisa* mindhah `T` saka `&RefCell<T>`.
    /// Nanging, iki ora dadi masalah anggere ora ana `Pin<&T>` sing nuduhake data sing padha, lan `RefCell<T>` ora ngidini sampeyan nggawe referensi pin kanggo isine.
    ///
    /// Deleng diskusi ing ["pinning projections"] kanggo rincian luwih lengkap.
    ///
    /// Note: `Pin` uga ngetrapake `Deref` menyang target, sing bisa digunakake kanggo ngakses nilai batin.
    /// Nanging, `Deref` mung nyedhiyakake referensi sing bisa urip sajrone utang `Pin`, dudu umur `Pin` dhewe.
    /// Cara iki ngidini ngowahi `Pin` dadi referensi kanthi umur sing padha karo `Pin` asli.
    ///
    /// ["pinning projections"]: self#projections-and-structural-pinning
    ///
    ///
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn get_ref(self) -> &'a T {
        self.pointer
    }
}

impl<'a, T: ?Sized> Pin<&'a mut T> {
    /// Ngonversi `Pin<&mut T>` iki dadi `Pin<&T>` kanthi umur sing padha.
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn into_ref(self) -> Pin<&'a T> {
        Pin { pointer: self.pointer }
    }

    /// Entuk referensi sing bisa diowahi kanggo data ing `Pin` iki.
    ///
    /// Iki mbutuhake data ing `Pin` iki yaiku `Unpin`.
    ///
    /// Note: `Pin` uga ngetrapake `DerefMut` menyang data, sing bisa digunakake kanggo ngakses nilai batin.
    /// Nanging, `DerefMut` mung nyedhiyakake referensi sing bisa urip sajrone utang `Pin`, dudu umur `Pin` dhewe.
    ///
    /// Cara iki ngidini ngowahi `Pin` dadi referensi kanthi umur sing padha karo `Pin` asli.
    ///
    #[inline(always)]
    #[stable(feature = "pin", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn get_mut(self) -> &'a mut T
    where
        T: Unpin,
    {
        self.pointer
    }

    /// Entuk referensi sing bisa diowahi kanggo data ing `Pin` iki.
    ///
    /// # Safety
    ///
    /// Fungsi iki ora aman.
    /// Sampeyan kudu njamin manawa sampeyan ora bakal bisa mindhah data saka referensi sing bisa ditampa nalika sampeyan nelpon fungsi iki, supaya invariant ing jinis `Pin` bisa dikuatake.
    ///
    ///
    /// Yen data sing ndasari `Unpin`, `Pin::get_mut` kudu digunakake.
    ///
    #[inline(always)]
    #[stable(feature = "pin", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const unsafe fn get_unchecked_mut(self) -> &'a mut T {
        self.pointer
    }

    /// Mbangun pin anyar kanthi menehi peta nilai interior.
    ///
    /// Contone, yen wanted kanggo njaluk `Pin` saka lapangan soko, sampeyan bisa nggunakake kanggo njaluk akses menyang lapangan sing ing siji garis kode.
    /// Nanging, ana pirang-pirang gotza kanthi "pinning projections" iki;
    /// deleng dokumentasi [`pin` module] kanggo rincian luwih lengkap babagan topik kasebut.
    ///
    /// # Safety
    ///
    /// Fungsi iki ora aman.
    /// Sampeyan kudu njamin yen data sing sampeyan baleni ora bakal pindhah suwe yen nilai argumen ora pindhah (umpamane, amarga iki minangka salah sawijining kolom nilai kasebut), lan uga sampeyan ora bisa metu saka argumen sing ditampa fungsi interior.
    ///
    ///
    /// [`pin` module]: self#projections-and-structural-pinning
    ///
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    pub unsafe fn map_unchecked_mut<U, F>(self, func: F) -> Pin<&'a mut U>
    where
        U: ?Sized,
        F: FnOnce(&mut T) -> &mut U,
    {
        // SAFETY: panelpon tanggung jawab kanggo ora mindhah
        // regane saka referensi iki.
        let pointer = unsafe { Pin::get_unchecked_mut(self) };
        let new_pointer = func(pointer);
        // SAFETY: amarga regane `this` dijamin ora bakal duwe
        // wis dipindhah, telpon menyang `new_unchecked` iki aman.
        unsafe { Pin::new_unchecked(new_pointer) }
    }
}

impl<T: ?Sized> Pin<&'static T> {
    /// Entuk referensi sing disematkan saka referensi statis.
    ///
    /// Iki aman, amarga `T` dipinjam ing umur `'static`, sing ora ana enteke.
    ///
    #[unstable(feature = "pin_static_ref", issue = "78186")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn static_ref(r: &'static T) -> Pin<&'static T> {
        // SAFETY: 'Pinjaman statis njamin data bakal ora
        // moved/invalidated nganti tiba (sing ora tau).
        unsafe { Pin::new_unchecked(r) }
    }
}

impl<T: ?Sized> Pin<&'static mut T> {
    /// Goleki referensi sing bisa dipateni saka referensi sing bisa diowahi kanthi statis.
    ///
    /// Iki aman, amarga `T` dipinjam ing umur `'static`, sing ora ana enteke.
    ///
    #[unstable(feature = "pin_static_ref", issue = "78186")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn static_mut(r: &'static mut T) -> Pin<&'static mut T> {
        // SAFETY: 'Pinjaman statis njamin data bakal ora
        // moved/invalidated nganti tiba (sing ora tau).
        unsafe { Pin::new_unchecked(r) }
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: Deref> Deref for Pin<P> {
    type Target = P::Target;
    fn deref(&self) -> &P::Target {
        Pin::get_ref(Pin::as_ref(self))
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: DerefMut<Target: Unpin>> DerefMut for Pin<P> {
    fn deref_mut(&mut self) -> &mut P::Target {
        Pin::get_mut(Pin::as_mut(self))
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<P: Receiver> Receiver for Pin<P> {}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Debug> fmt::Debug for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.pointer, f)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Display> fmt::Display for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&self.pointer, f)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Pointer> fmt::Pointer for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.pointer, f)
    }
}

// Note: iki tegese impl `CoerceUnsized` sing ngidini meksa saka
// jinis sing ngetrapake `Deref<Target=impl !Unpin>` menyang jinis sing nyebabake `Deref<Target=Unpin>` ora valid.
// Nanging impl apa wae bisa uga ora ana gunane amarga ana sebab liyane, mula kita kudu ati-ati supaya ora ngidini impls kasebut mlebu ing std.
//
//
#[stable(feature = "pin", since = "1.33.0")]
impl<P, U> CoerceUnsized<Pin<U>> for Pin<P> where P: CoerceUnsized<U> {}

#[stable(feature = "pin", since = "1.33.0")]
impl<P, U> DispatchFromDyn<Pin<U>> for Pin<P> where P: DispatchFromDyn<U> {}