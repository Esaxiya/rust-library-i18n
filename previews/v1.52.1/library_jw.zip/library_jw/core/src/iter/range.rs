use crate::char;
use crate::convert::TryFrom;
use crate::mem;
use crate::ops::{self, Try};

use super::{FusedIterator, TrustedLen};

/// Obyek sing duwe pemanggih *penerus* lan *leluhur* operasi.
///
/// The *penerus* gerakane operasi menyang angka sing mbandhingaké luwih.
/// The *leluhur* gerakane operasi menyang angka sing mbandhingaké rodok kurang.
///
/// # Safety
///
/// trait iki `unsafe` amarga menehi implementasine kudu bener kanggo safety saka nindakake `unsafe trait TrustedLen`, lan asil saka nggunakake trait iki bisa digunakake bakal dipercaya kode `unsafe` dadi bener lan nepaki kewajiban kadhaptar.
///
///
///
#[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
pub unsafe trait Step: Clone + PartialOrd + Sized {
    /// Ngasilake nomer *penerus* langkah sing njaluk saka `start` kanggo `end`.
    ///
    /// Ngasilake `None` yen sawetara langkah bakal kebanjiran `usize` (utawa tanpa wates, utawa yen `end` ora bakal bisa digayuh).
    ///
    ///
    /// # Invariants
    ///
    /// Kanggo sembarang `a`, `b`, lan `n`:
    ///
    /// * `steps_between(&a, &b) == Some(n)` yen lan mung yen `Step::forward_checked(&a, n) == Some(b)`
    /// * `steps_between(&a, &b) == Some(n)` yen lan mung yen `Step::backward_checked(&a, n) == Some(a)`
    /// * `steps_between(&a, &b) == Some(n)` mung yen `a <= b`
    ///   * Mogok: `steps_between(&a, &b) == Some(0)` yen lan mung yen `a == b`
    ///   * Elinga yen `a <= b` Panjenengan _not_ pati jelas `steps_between(&a, &b) != None`;
    ///     iki kasus nalika iku bakal mbutuhake luwih saka `usize::MAX` langkah kanggo njaluk `b`
    /// * `steps_between(&a, &b) == None` yen `a > b`
    fn steps_between(start: &Self, end: &Self) -> Option<usize>;

    /// Ngasilake nilai sing bakal dipikolehi kanthi njupuk *penerus* kaping `self` `count`.
    ///
    /// Yen iki bakal kebanjiran sawetara nilai didhukung dening `Self`, ngasilake `None`.
    ///
    /// # Invariants
    ///
    /// Kanggo sembarang `a`, `n`, lan `m`:
    ///
    /// * `Step::forward_checked(a, n).and_then(|x| Step::forward_checked(x, m)) == Step::forward_checked(a, m).and_then(|x| Step::forward_checked(x, n))`
    ///
    ///
    /// Kanggo sembarang `a`, `n`, lan `m` ngendi `n + m` ora kebanjiran:
    ///
    /// * `Step::forward_checked(a, n).and_then(|x| Step::forward_checked(x, m)) == Step::forward_checked(a, n + m)`
    ///
    /// Kanggo `a` lan `n`:
    ///
    /// * `Step::forward_checked(a, n) == (0..n).try_fold(a, |x, _| Step::forward_checked(&x, 1))`
    ///   * Corollary: `Step::forward_checked(&a, 0) == Some(a)`
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn forward_checked(start: Self, count: usize) -> Option<Self>;

    /// Ngasilake nilai sing bakal dipikolehi kanthi njupuk *penerus* kaping `self` `count`.
    ///
    /// Yen iki bakal kebanjiran sawetara nilai didhukung dening `Self`, fungsi iki wis diijini panic, Lebokake, utawa saturate.
    ///
    /// prilaku sing disaranake kanggo panic nalika pandhedhesan debug sing aktif, lan kanggo Lebokake utawa saturate digunakake.
    ///
    /// Kode sing ora aman ora kudu gumantung saka bener tumindak sawise kebanjiran.
    ///
    /// # Invariants
    ///
    /// Kanggo sembarang `a`, `n`, lan `m`, ngendi ora kebanjiran ana:
    ///
    /// * `Step::forward(Step::forward(a, n), m) == Step::forward(a, n + m)`
    ///
    /// Kanggo `a` lan `n`, ora ana kebanjiran:
    ///
    /// * `Step::forward_checked(a, n) == Some(Step::forward(a, n))`
    /// * `Step::forward(a, n) == (0..n).fold(a, |x, _| Step::forward(x, 1))`
    ///   * Corollary: `Step::forward(a, 0) == a`
    /// * `Step::forward(a, n) >= a`
    /// * `Step::backward(Step::forward(a, n), n) == a`
    ///
    ///
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn forward(start: Self, count: usize) -> Self {
        Step::forward_checked(start, count).expect("overflow in `Step::forward`")
    }

    /// Ngasilake nilai sing bakal dipikolehi kanthi njupuk *penerus* kaping `self` `count`.
    ///
    /// # Safety
    ///
    /// Iku prilaku undefined kanggo operasi iki kanggo kebanjiran sawetara nilai didhukung dening `Self`.
    /// Yen sampeyan ora bisa njamin yen bakal ora kebanjiran, nggunakake `forward` utawa `forward_checked` tinimbang.
    ///
    /// # Invariants
    ///
    /// Kanggo `a` wae:
    ///
    /// * yen ana `b` kuwi sing `b > a`, wis aman kanggo nelpon `Step::forward_unchecked(a, 1)`
    /// * yen ana `b`, `n` kuwi sing `steps_between(&a, &b) == Some(n)`, wis aman kanggo nelpon `Step::forward_unchecked(a, m)` kanggo maksud apa `m <= n`.
    ///
    ///
    /// Kanggo `a` lan `n`, ora ana kebanjiran:
    ///
    /// * `Step::forward_unchecked(a, n)` padha karo `Step::forward(a, n)`
    ///
    ///
    #[unstable(feature = "unchecked_math", reason = "niche optimization path", issue = "none")]
    unsafe fn forward_unchecked(start: Self, count: usize) -> Self {
        Step::forward(start, count)
    }

    /// Ngasilake angka sing bakal dijupuk dening njupuk *leluhur* saka `self` `count` kaping.
    ///
    /// Yen iki bakal kebanjiran sawetara nilai didhukung dening `Self`, ngasilake `None`.
    ///
    /// # Invariants
    ///
    /// Kanggo sembarang `a`, `n`, lan `m`:
    ///
    /// * `Step::backward_checked(a, n).and_then(|x| Step::backward_checked(x, m)) == n.checked_add(m).and_then(|x| Step::backward_checked(a, x))`
    ///
    /// * `Step::backward_checked(a, n).and_then(|x| Step::backward_checked(x, m)) == try { Step::backward_checked(a, n.checked_add(m)?) }`
    ///
    /// Kanggo `a` lan `n`:
    ///
    /// * `Step::backward_checked(a, n) == (0..n).try_fold(a, |x, _| Step::backward_checked(&x, 1))`
    ///   * Corollary: `Step::backward_checked(&a, 0) == Some(a)`
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn backward_checked(start: Self, count: usize) -> Option<Self>;

    /// Ngasilake angka sing bakal dijupuk dening njupuk *leluhur* saka `self` `count` kaping.
    ///
    /// Yen iki bakal kebanjiran sawetara nilai didhukung dening `Self`, fungsi iki wis diijini panic, Lebokake, utawa saturate.
    ///
    /// prilaku sing disaranake kanggo panic nalika pandhedhesan debug sing aktif, lan kanggo Lebokake utawa saturate digunakake.
    ///
    /// Kode sing ora aman ora kudu gumantung saka bener tumindak sawise kebanjiran.
    ///
    /// # Invariants
    ///
    /// Kanggo sembarang `a`, `n`, lan `m`, ngendi ora kebanjiran ana:
    ///
    /// * `Step::backward(Step::backward(a, n), m) == Step::backward(a, n + m)`
    ///
    /// Kanggo `a` lan `n`, ora ana kebanjiran:
    ///
    /// * `Step::backward_checked(a, n) == Some(Step::backward(a, n))`
    /// * `Step::backward(a, n) == (0..n).fold(a, |x, _| Step::backward(x, 1))`
    ///   * Corollary: `Step::backward(a, 0) == a`
    /// * `Step::backward(a, n) <= a`
    /// * `Step::forward(Step::backward(a, n), n) == a`
    ///
    ///
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn backward(start: Self, count: usize) -> Self {
        Step::backward_checked(start, count).expect("overflow in `Step::backward`")
    }

    /// Ngasilake angka sing bakal dijupuk dening njupuk *leluhur* saka `self` `count` kaping.
    ///
    /// # Safety
    ///
    /// Iku prilaku undefined kanggo operasi iki kanggo kebanjiran sawetara nilai didhukung dening `Self`.
    /// Yen sampeyan ora bisa njamin manawa iki ora bakal kebanjiran, gunakake `backward` utawa `backward_checked`.
    ///
    /// # Invariants
    ///
    /// Kanggo `a` wae:
    ///
    /// * yen ana `b` kuwi sing `b < a`, wis aman kanggo nelpon `Step::backward_unchecked(a, 1)`
    /// * yen ana `b`, `n` kuwi sing `steps_between(&b, &a) == Some(n)`, wis aman kanggo nelpon `Step::backward_unchecked(a, m)` kanggo maksud apa `m <= n`.
    ///
    ///
    /// Kanggo `a` lan `n`, ora ana kebanjiran:
    ///
    /// * `Step::backward_unchecked(a, n)` padha karo `Step::backward(a, n)`
    ///
    ///
    #[unstable(feature = "unchecked_math", reason = "niche optimization path", issue = "none")]
    unsafe fn backward_unchecked(start: Self, count: usize) -> Self {
        Step::backward(start, count)
    }
}

// Iki isih gedhe kui amarga ongko ing literals mutusake masalah kanggo macem-macem.
macro_rules! step_identical_methods {
    () => {
        #[inline]
        unsafe fn forward_unchecked(start: Self, n: usize) -> Self {
            // SAFETY: panelpon wis njamin sing `start + n` ora kebanjiran.
            unsafe { start.unchecked_add(n as Self) }
        }

        #[inline]
        unsafe fn backward_unchecked(start: Self, n: usize) -> Self {
            // SAFETY: panelpon wis njamin sing `start - n` ora kebanjiran.
            unsafe { start.unchecked_sub(n as Self) }
        }

        #[inline]
        #[allow(arithmetic_overflow)]
        #[rustc_inherit_overflow_checks]
        fn forward(start: Self, n: usize) -> Self {
            // Ing debug di bangun, pemicu panic ing kebanjiran.
            // Iki kudu ngoptimalake rampung metu ing release di bangun.
            if Self::forward_checked(start, n).is_none() {
                let _ = Self::MAX + 1;
            }
            // Bungkus matématika kanggo ngidini eg `Step::forward(-128i8, 255)`.
            start.wrapping_add(n as Self)
        }

        #[inline]
        #[allow(arithmetic_overflow)]
        #[rustc_inherit_overflow_checks]
        fn backward(start: Self, n: usize) -> Self {
            // Ing debug di bangun, pemicu panic ing kebanjiran.
            // Iki kudu ngoptimalake rampung metu ing release di bangun.
            if Self::backward_checked(start, n).is_none() {
                let _ = Self::MIN - 1;
            }
            // Bungkus matématika kanggo ngidini eg `Step::backward(127i8, 255)`.
            start.wrapping_sub(n as Self)
        }
    };
}

macro_rules! step_integer_impls {
    {
        narrower than or same width as usize:
            $( [ $u_narrower:ident $i_narrower:ident ] ),+;
        wider than usize:
            $( [ $u_wider:ident $i_wider:ident ] ),+;
    } => {
        $(
            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $u_narrower {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        // Iki gumantung karo $u_narrower <=usize
                        Some((*end - *start) as usize)
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    match Self::try_from(n) {
                        Ok(n) => start.checked_add(n),
                        Err(_) => None, // yen n punika saking sawetara, `unsigned_start + n` banget
                    }
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    match Self::try_from(n) {
                        Ok(n) => start.checked_sub(n),
                        Err(_) => None, // yen n punika saking sawetara, `unsigned_start - n` banget
                    }
                }
            }

            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $i_narrower {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        // Iki gumantung karo $i_narrower <=usize
                        //
                        // Casting kanggo isize ngluwihi jembaré nanging ngreksa tandha.
                        // Gunakake wrapping_sub ing papan isize lan cast kanggo usize kanggo ngétung prabédan sing uga ora pas nang sawetara isize.
                        //
                        Some((*end as isize).wrapping_sub(*start as isize) as usize)
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    match $u_narrower::try_from(n) {
                        Ok(n) => {
                            // Bungkusan kasus Ngalahake kaya `Step::forward(-120_i8, 200) == Some(80_i8)`, malah sanadyan 200 metu saka sawetara kanggo i8.
                            //
                            //
                            let wrapped = start.wrapping_add(n as Self);
                            if wrapped >= start {
                                Some(wrapped)
                            } else {
                                None // Tambahan kebanjiran
                            }
                        }
                        // Yen n punika saking sawetara eg
                        // u8, banjur iku ageng saka sawetara kabeh kanggo i8 iku sudhut supaya `any_i8 + n` kudu overflows i8.
                        //
                        Err(_) => None,
                    }
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    match $u_narrower::try_from(n) {
                        Ok(n) => {
                            // Bungkusan kasus Ngalahake kaya `Step::forward(-120_i8, 200) == Some(80_i8)`, malah sanadyan 200 metu saka sawetara kanggo i8.
                            //
                            //
                            let wrapped = start.wrapping_sub(n as Self);
                            if wrapped <= start {
                                Some(wrapped)
                            } else {
                                None // Pengurangan kebanjiran
                            }
                        }
                        // Yen n punika saking sawetara eg
                        // u8, banjur iku ageng saka sawetara kabeh kanggo i8 iku sudhut supaya `any_i8 - n` kudu overflows i8.
                        //
                        Err(_) => None,
                    }
                }
            }
        )+

        $(
            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $u_wider {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        usize::try_from(*end - *start).ok()
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_add(n as Self)
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_sub(n as Self)
                }
            }

            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $i_wider {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        match end.checked_sub(*start) {
                            Some(result) => usize::try_from(result).ok(),
                            // Yen prabédan amba banget kanggo eg
                            // i128, iku uga badhe dadi amba banget kanggo usize karo bit kurang.
                            None => None,
                        }
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_add(n as Self)
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_sub(n as Self)
                }
            }
        )+
    };
}

#[cfg(target_pointer_width = "64")]
step_integer_impls! {
    narrower than or same width as usize: [u8 i8], [u16 i16], [u32 i32], [u64 i64], [usize isize];
    wider than usize: [u128 i128];
}

#[cfg(target_pointer_width = "32")]
step_integer_impls! {
    narrower than or same width as usize: [u8 i8], [u16 i16], [u32 i32], [usize isize];
    wider than usize: [u64 i64], [u128 i128];
}

#[cfg(target_pointer_width = "16")]
step_integer_impls! {
    narrower than or same width as usize: [u8 i8], [u16 i16], [usize isize];
    wider than usize: [u32 i32], [u64 i64], [u128 i128];
}

#[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
unsafe impl Step for char {
    #[inline]
    fn steps_between(&start: &char, &end: &char) -> Option<usize> {
        let start = start as u32;
        let end = end as u32;
        if start <= end {
            let count = end - start;
            if start < 0xD800 && 0xE000 <= end {
                usize::try_from(count - 0x800).ok()
            } else {
                usize::try_from(count).ok()
            }
        } else {
            None
        }
    }

    #[inline]
    fn forward_checked(start: char, count: usize) -> Option<char> {
        let start = start as u32;
        let mut res = Step::forward_checked(start, count)?;
        if start < 0xD800 && 0xD800 <= res {
            res = Step::forward_checked(res, 0x800)?;
        }
        if res <= char::MAX as u32 {
            // SAFETY: res iki skalar ndhukung Unicode, bener
            // (ngisor 0x110000 lan ora ing 0xD800..0xE000)
            Some(unsafe { char::from_u32_unchecked(res) })
        } else {
            None
        }
    }

    #[inline]
    fn backward_checked(start: char, count: usize) -> Option<char> {
        let start = start as u32;
        let mut res = Step::backward_checked(start, count)?;
        if start >= 0xE000 && 0xE000 > res {
            res = Step::backward_checked(res, 0x800)?;
        }
        // SAFETY: res iki skalar ndhukung Unicode, bener
        // (ngisor 0x110000 lan ora ing 0xD800..0xE000)
        Some(unsafe { char::from_u32_unchecked(res) })
    }

    #[inline]
    unsafe fn forward_unchecked(start: char, count: usize) -> char {
        let start = start as u32;
        // SAFETY: panelpon kudu njamin manawa ora kebanjiran
        // ing sawetara nilai kanggo char a.
        let mut res = unsafe { Step::forward_unchecked(start, count) };
        if start < 0xD800 && 0xD800 <= res {
            // SAFETY: panelpon kudu njamin manawa ora kebanjiran
            // ing sawetara nilai kanggo char a.
            res = unsafe { Step::forward_unchecked(res, 0x800) };
        }
        // SAFETY: amarga kontrak sadurunge, iki dijamin
        // dening panelpon dadi char bener.
        unsafe { char::from_u32_unchecked(res) }
    }

    #[inline]
    unsafe fn backward_unchecked(start: char, count: usize) -> char {
        let start = start as u32;
        // SAFETY: panelpon kudu njamin manawa ora kebanjiran
        // ing sawetara nilai kanggo char a.
        let mut res = unsafe { Step::backward_unchecked(start, count) };
        if start >= 0xE000 && 0xE000 > res {
            // SAFETY: panelpon kudu njamin manawa ora kebanjiran
            // ing sawetara nilai kanggo char a.
            res = unsafe { Step::backward_unchecked(res, 0x800) };
        }
        // SAFETY: amarga kontrak sadurunge, iki dijamin
        // dening panelpon dadi char bener.
        unsafe { char::from_u32_unchecked(res) }
    }
}

macro_rules! range_exact_iter_impl {
    ($($t:ty)*) => ($(
        #[stable(feature = "rust1", since = "1.0.0")]
        impl ExactSizeIterator for ops::Range<$t> { }
    )*)
}

macro_rules! range_incl_exact_iter_impl {
    ($($t:ty)*) => ($(
        #[stable(feature = "inclusive_range", since = "1.26.0")]
        impl ExactSizeIterator for ops::RangeInclusive<$t> { }
    )*)
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Step> Iterator for ops::Range<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        if self.start < self.end {
            // SAFETY: mung priksa precondition
            let n = unsafe { Step::forward_unchecked(self.start.clone(), 1) };
            Some(mem::replace(&mut self.start, n))
        } else {
            None
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.start < self.end {
            let hint = Step::steps_between(&self.start, &self.end);
            (hint.unwrap_or(usize::MAX), hint)
        } else {
            (0, Some(0))
        }
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<A> {
        if let Some(plus_n) = Step::forward_checked(self.start.clone(), n) {
            if plus_n < self.end {
                // SAFETY: mung priksa precondition
                self.start = unsafe { Step::forward_unchecked(plus_n.clone(), 1) };
                return Some(plus_n);
            }
        }

        self.start = self.end.clone();
        None
    }

    #[inline]
    fn last(mut self) -> Option<A> {
        self.next_back()
    }

    #[inline]
    fn min(mut self) -> Option<A> {
        self.next()
    }

    #[inline]
    fn max(mut self) -> Option<A> {
        self.next_back()
    }
}

// macro iki generate impls `ExactSizeIterator` kanggo macem-macem jinis sawetara.
//
// * `ExactSizeIterator::len` dibutuhake kanggo tansah bali lan `usize` pas, supaya ora sawetara bisa maneh saka `usize::MAX`.
//
// * Kanggo jinis bilangan bulat ing `Range<_>`, iki kalebu jinis sing luwih sempit tinimbang utawa wiyar `usize`.
//   Kanggo jinis ongko ing `RangeInclusive<_>` iki cilik kanggo jinis *strictly sempit* saka `usize` wiwit eg
//   `(0..=u64::MAX).len()` bakal `u64::MAX + 1`.
//
range_exact_iter_impl! {
    usize u8 u16
    isize i8 i16

    // Iki kalebu saben alesan ing ndhuwur, nanging ngilangi bakal dadi owah-owahan amarga stabil ing Rust 1.0.0.
    // dadi eg
    // `(0..66_000_u32).len()` contone, bakal dikompilasi tanpa ana kesalahan utawa peringatan ing platform 16-bit, nanging terus menehi asil sing salah.
    //
    u32
    i32
}
range_incl_exact_iter_impl! {
    u8
    i8

    // Iki incorect saben pertimbangan ndhuwur, nanging njabut bakal owah-owahan bejat padha owah ing Rust 1.26.0.
    // dadi eg
    // `(0..=u16::MAX).len()` contone, bakal dikompilasi tanpa ana kesalahan utawa peringatan ing platform 16-bit, nanging terus menehi asil sing salah.
    //
    u16
    i16
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Step> DoubleEndedIterator for ops::Range<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        if self.start < self.end {
            // SAFETY: mung priksa precondition
            self.end = unsafe { Step::backward_unchecked(self.end.clone(), 1) };
            Some(self.end.clone())
        } else {
            None
        }
    }

    #[inline]
    fn nth_back(&mut self, n: usize) -> Option<A> {
        if let Some(minus_n) = Step::backward_checked(self.end.clone(), n) {
            if minus_n > self.start {
                // SAFETY: mung priksa precondition
                self.end = unsafe { Step::backward_unchecked(minus_n, 1) };
                return Some(self.end.clone());
            }
        }

        self.end = self.start.clone();
        None
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Step> TrustedLen for ops::Range<A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Step> FusedIterator for ops::Range<A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Step> Iterator for ops::RangeFrom<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        let n = Step::forward(self.start.clone(), 1);
        Some(mem::replace(&mut self.start, n))
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<A> {
        let plus_n = Step::forward(self.start.clone(), n);
        self.start = Step::forward(plus_n.clone(), 1);
        Some(plus_n)
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Step> FusedIterator for ops::RangeFrom<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Step> TrustedLen for ops::RangeFrom<A> {}

#[stable(feature = "inclusive_range", since = "1.26.0")]
impl<A: Step> Iterator for ops::RangeInclusive<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        if self.is_empty() {
            return None;
        }
        let is_iterating = self.start < self.end;
        Some(if is_iterating {
            // SAFETY: mung priksa precondition
            let n = unsafe { Step::forward_unchecked(self.start.clone(), 1) };
            mem::replace(&mut self.start, n)
        } else {
            self.exhausted = true;
            self.start.clone()
        })
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.is_empty() {
            return (0, Some(0));
        }

        match Step::steps_between(&self.start, &self.end) {
            Some(hint) => (hint.saturating_add(1), hint.checked_add(1)),
            None => (usize::MAX, None),
        }
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<A> {
        if self.is_empty() {
            return None;
        }

        if let Some(plus_n) = Step::forward_checked(self.start.clone(), n) {
            use crate::cmp::Ordering::*;

            match plus_n.partial_cmp(&self.end) {
                Some(Less) => {
                    self.start = Step::forward(plus_n.clone(), 1);
                    return Some(plus_n);
                }
                Some(Equal) => {
                    self.start = plus_n.clone();
                    self.exhausted = true;
                    return Some(plus_n);
                }
                _ => {}
            }
        }

        self.start = self.end.clone();
        self.exhausted = true;
        None
    }

    #[inline]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        if self.is_empty() {
            return try { init };
        }

        let mut accum = init;

        while self.start < self.end {
            // SAFETY: mung priksa precondition
            let n = unsafe { Step::forward_unchecked(self.start.clone(), 1) };
            let n = mem::replace(&mut self.start, n);
            accum = f(accum, n)?;
        }

        self.exhausted = true;

        if self.start == self.end {
            accum = f(accum, self.start.clone())?;
        }

        try { accum }
    }

    #[inline]
    fn fold<B, F>(mut self, init: B, f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_fold(init, ok(f)).unwrap()
    }

    #[inline]
    fn last(mut self) -> Option<A> {
        self.next_back()
    }

    #[inline]
    fn min(mut self) -> Option<A> {
        self.next()
    }

    #[inline]
    fn max(mut self) -> Option<A> {
        self.next_back()
    }
}

#[stable(feature = "inclusive_range", since = "1.26.0")]
impl<A: Step> DoubleEndedIterator for ops::RangeInclusive<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        if self.is_empty() {
            return None;
        }
        let is_iterating = self.start < self.end;
        Some(if is_iterating {
            // SAFETY: mung priksa precondition
            let n = unsafe { Step::backward_unchecked(self.end.clone(), 1) };
            mem::replace(&mut self.end, n)
        } else {
            self.exhausted = true;
            self.end.clone()
        })
    }

    #[inline]
    fn nth_back(&mut self, n: usize) -> Option<A> {
        if self.is_empty() {
            return None;
        }

        if let Some(minus_n) = Step::backward_checked(self.end.clone(), n) {
            use crate::cmp::Ordering::*;

            match minus_n.partial_cmp(&self.start) {
                Some(Greater) => {
                    self.end = Step::backward(minus_n.clone(), 1);
                    return Some(minus_n);
                }
                Some(Equal) => {
                    self.end = minus_n.clone();
                    self.exhausted = true;
                    return Some(minus_n);
                }
                _ => {}
            }
        }

        self.end = self.start.clone();
        self.exhausted = true;
        None
    }

    #[inline]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        if self.is_empty() {
            return try { init };
        }

        let mut accum = init;

        while self.start < self.end {
            // SAFETY: mung priksa precondition
            let n = unsafe { Step::backward_unchecked(self.end.clone(), 1) };
            let n = mem::replace(&mut self.end, n);
            accum = f(accum, n)?;
        }

        self.exhausted = true;

        if self.start == self.end {
            accum = f(accum, self.start.clone())?;
        }

        try { accum }
    }

    #[inline]
    fn rfold<B, F>(mut self, init: B, f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_rfold(init, ok(f)).unwrap()
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Step> TrustedLen for ops::RangeInclusive<A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Step> FusedIterator for ops::RangeInclusive<A> {}