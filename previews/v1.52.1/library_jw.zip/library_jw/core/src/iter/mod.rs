//! Pengulangan eksternal sing bisa digawe.
//!
//! Yen sampeyan wis duwe koleksi sawetara jinis, lan kudu nindakake operasi ing unsur koleksi kasebut, sampeyan bakal bisa nempuh 'iterators' kanthi cepet.
//! Iterators sing akeh banget digunakake ing kode Rust idiomatic, supaya kang worth dadi menowo wong-wong mau.
//!
//! Sadurunge nerangake luwih lengkap, ayo ngobrol babagan cara struktur modul iki:
//!
//! # Organization
//!
//! modul iki umumé diatur dening jinis:
//!
//! * [Traits] sing bagean inti: traits iki nemtokaké apa jenis iterators ana lan apa sing bisa apa karo wong.Ing cara traits iki worth panggolekan sawetara wektu sinau ekstra menyang.
//! * [Functions] nyedhiyakake sawetara cara sing migunani kanggo nggawe sawetara pengulangan dhasar.
//! * [Structs] asring jinis bali saka macem-macem cara ing traits iki modul kang.Sampeyan biasane bakal pengin katon ing cara sing nggawe `struct`, tinimbang `struct` dhewe.
//! Kanggo luwih rinci bab apa, weruh [penerapan Iterator](#penerapan-iterator) '.
//!
//! [Traits]: #traits
//! [Functions]: #functions
//! [Structs]: #structs
//!
//! Mekaten!Sampeyan Ayo menyang iterators.
//!
//! # Iterator
//!
//! Jantung lan nyawa modul iki [`Iterator`] trait.Inti saka [`Iterator`] katon kaya iki:
//!
//! ```
//! trait Iterator {
//!     type Item;
//!     fn next(&mut self) -> Option<Self::Item>;
//! }
//! ```
//!
//! Lan iterator wis cara, [`next`], kang nalika disebut, ngasilake lan [: Option`]:<Item>`.
//! [`next`] bakal ngasilake [`Some(Item)`] anggere ana unsur, lan yen padha wis kabeh wis kesel, bakal bali `None` kanggo nunjukaké sing pengulangan wis rampung.
//! Pengulangan individu bisa milih nerusake pengulangan, lan nelpon [`next`] maneh bisa uga miwiti mbalik [`Some(Item)`] maneh ing sawetara titik (contone, deleng [`TryIter`]).
//!
//!
//! Definisi lengkap [Iterator`] kalebu uga cara liyane, nanging cara kasebut default, dibangun ing ndhuwur [`next`], mula sampeyan bisa njaluk gratis.
//!
//! Iterators uga composable, lan umum kang kanggo chain mau bebarengan kanggo nindakake jroning luwih akèh wangun kompleks saka Processing.Deleng bagean [Adapters](#adapters) ing ngisor iki kanggo rincian liyane.
//!
//! [`Some(Item)`]: Some
//! [`next`]: Iterator::next
//! [`TryIter`]: ../../std/sync/mpsc/struct.TryIter.html
//!
//! # Telu Wangun pengulangan
//!
//! Ana telung cara umum sing bisa nggawe iterator saka koleksi:
//!
//! * `iter()`, sing ngirangi `&T`.
//! * `iter_mut()`, kang iterates liwat `&mut T`.
//! * `into_iter()`, sing ngirangi `T`.
//!
//! Maneka warna perkara ing perpustakaan standar bisa uga ngetrapake siji utawa luwih saka telu, yen cocog.
//!
//! # penerapan Iterator
//!
//! Nggawe iterator saka dhewe melu rong langkah: nggawe `struct` terus negara iterator kang, lan banjur penerapan [`Iterator`] kanggo sing `struct`.
//! Iki kok ana akeh: struct`s ing modul iki: ana siji kanggo saben iterator lan adaptor iterator.
//!
//! Ayo dadi gawe iterator jenenge `Counter` kang counts saka `1` kanggo `5`:
//!
//! ```
//! // Pisanan, strukture:
//!
//! /// Lan iterator kang counts saka siji limang
//! struct Counter {
//!     count: usize,
//! }
//!
//! // kita pengin hitungan diwiwiti, dadi ayo nambah cara new() kanggo mbantu.
//! // Iki ora prelu banget, nanging luwih gampang.
//! // Elinga yen kita miwiti `count` ing nul, kita bakal weruh kok ing implementasine `next()`'s ngisor.
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // Banjur, kita ngetrapake `Iterator` kanggo `Counter`:
//!
//! impl Iterator for Counter {
//!     // kita bakal ngetung nganggo usize
//!     type Item = usize;
//!
//!     // next() mung cara sing dibutuhake
//!     fn next(&mut self) -> Option<Self::Item> {
//!         // Nambah jumlah kita.Iki kok kita miwiti ing nul.
//!         self.count += 1;
//!
//!         // Priksa manawa kita wis rampung ngetung utawa ora.
//!         if self.count < 6 {
//!             Some(self.count)
//!         } else {
//!             None
//!         }
//!     }
//! }
//!
//! // Lan saiki kita bisa nggunakake!
//!
//! let mut counter = Counter::new();
//!
//! assert_eq!(counter.next(), Some(1));
//! assert_eq!(counter.next(), Some(2));
//! assert_eq!(counter.next(), Some(3));
//! assert_eq!(counter.next(), Some(4));
//! assert_eq!(counter.next(), Some(5));
//! assert_eq!(counter.next(), None);
//! ```
//!
//! Nelpon [`next`] kanthi cara iki bakal bola-bali.Rust wis nbangun kang bisa nelpon [`next`] ing iterator Panjenengan, nganti tekan `None`.Ayo dadi pindhah liwat sing sabanjuré.
//!
//! Uga Wigati `Iterator` menehi implementasine standar cara kayata `nth` lan `fold` kang nelpon `next` njero.
//! Nanging, iku uga bisa kanggo nulis implementasine adat cara kaya `nth` lan `fold` yen iterator bisa ngétung wong-wong mau luwih irit tanpa nelpon `next`.
//!
//! # `for` puteran lan `IntoIterator`
//!
//! sintaks daur ulang `for` Rust iku bener gula kanggo iterators.Mangkene conto dhasar `for`:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Iki bakal print siji nomer liwat lima, saben ing baris dhewe.Nanging sampeyan bakal sok dong mirsani ing kene: kita ora nate nelpon babagan vector kanggo ngasilake pengulangan.Apa sing menehi?
//!
//! Ana trait ing perpustakaan standar kanggo ngonversi soko menyang iterator: [`IntoIterator`].
//! trait iki duwé siji cara, [`into_iter`], kang ngowahi ing bab nindakaken [`IntoIterator`] menyang iterator.
//! Ayo dadi njupuk dipikir ing `for` daur ulang maneh, lan apa ngowahi compiler menyang:
//!
//! [`into_iter`]: IntoIterator::into_iter
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Rust de-gula iki menyang:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//! {
//!     let result = match IntoIterator::into_iter(values) {
//!         mut iter => loop {
//!             let next;
//!             match iter.next() {
//!                 Some(val) => next = val,
//!                 None => break,
//!             };
//!             let x = next;
//!             let () = { println!("{}", x); };
//!         },
//!     };
//!     result
//! }
//! ```
//!
//! Pisanan, kita nelpon `into_iter()` ing regane.Banjur, kita cocog ing iterator sing ngasilake, nelpon [`next`] liwat lan liwat nganti kita waca `None`.
//! Ing titik, kita `break` metu saka daur ulang, lan kita lagi rampung mbaleni.
//!
//! Ana siji dicokot liyane subtle kene: perpustakaan standar ngandhut implementasi menarik saka [`IntoIterator`]:
//!
//! ```ignore (only-for-syntax-highlight)
//! impl<I: Iterator> IntoIterator for I
//! ```
//!
//! Ing tembung liyane, kabeh [: Iterator`] s ngleksanakake [`IntoIterator`], dening mung bali piyambak.Iki tegese loro iku:
//!
//! 1. Yen sampeyan lagi nulis [`Iterator`], sampeyan bisa nggunakake karo daur ulang `for`.
//! 2. Yen sampeyan lagi nggawe koleksi, penerapan [`IntoIterator`] iku bakal ngidini koleksi kanggo digunakake karo daur ulang `for`.
//!
//! # Muter kanthi referensi
//!
//! Wiwit [`into_iter()`] njupuk `self` dening nilai, nggunakake daur ulang `for` kanggo iterate liwat koleksi nganggo sing koleksi.Asring, sampeyan bisa uga pengin iterate liwat koleksi tanpa akeh iku.
//! Akeh koleksi kurban cara sing nyedhiyani iterators liwat referensi, konvènsi disebut `iter()` lan `iter_mut()` mungguh:
//!
//! ```
//! let mut values = vec![41];
//! for x in values.iter_mut() {
//!     *x += 1;
//! }
//! for x in values.iter() {
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1); // `values` isih diduweni dening fungsi iki.
//! ```
//!
//! Yen jinis koleksi `C` menehi `iter()`, iku biasane uga nindakake `IntoIterator` kanggo `&C`, karo implementasine mung Telpon `iter()`.
//! Uga, koleksi `C` sing nyedhiyani `iter_mut()` umume nindakake `IntoIterator` kanggo `&mut C` dening delegating kanggo `iter_mut()`.Iki mbisakake minangka cekakan trep:
//!
//! ```
//! let mut values = vec![41];
//! for x in &mut values { // padha `values.iter_mut()`
//!     *x += 1;
//! }
//! for x in &values { // padha karo `values.iter()`
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1);
//! ```
//!
//! Nalika akeh koleksi kurban `iter()`, ora kabeh kurban `iter_mut()`.
//! Contone, mutasi tombol [`HashSet<T>`] utawa [`HashMap<K, V>`] bisa nggawe koleksi dadi kahanan sing ora konsisten yen tombol kasebut wis diganti, mula koleksi kasebut mung nawakake `iter()`.
//!
//! [`into_iter()`]: IntoIterator::into_iter
//! [`HashSet<T>`]: ../../std/collections/struct.HashSet.html
//! [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
//!
//! # Adapters
//!
//! Fungsi kang njupuk [`Iterator`] lan bali [`Iterator`] liyane asring disebut 'iterator adaptor', minangka lagi wangun saka 'adaptor
//! pattern'.
//!
//! Adaptor iterator umum kalebu [`map`], [`take`], lan [`filter`].
//! Kanggo luwih lengkap, deleng dokumentasi.
//!
//! Menawi iterator adaptor panics, iterator bakal ing (nanging aman memori) negara unspecified.
//! negara iki uga ora dijamin kanggo tetep padha tengen versi Rust, dadi sampeyan kudu ngindhari nggunakake angka pas bali dening iterator kang panicked.
//!
//! [`map`]: Iterator::map
//! [`take`]: Iterator::take
//! [`filter`]: Iterator::filter
//!
//! # Laziness
//!
//! Iterators (lan iterator [adapters](#adapters)) sing *puguh*. Iki liya sing mung nggawe iterator ora _do_ akèh kabèh. Apa tenan mengkono nganti sampeyan nelpon [`next`].
//! Kadang iki dadi sumber kebingungan nalika nggawe iterator mung kanggo efek samping.
//! Contone, cara [`map`] Telpon panutupan ing saben unsur iku iterates liwat:
//!
//! ```
//! # #![allow(unused_must_use)]
//! let v = vec![1, 2, 3, 4, 5];
//! v.iter().map(|x| println!("{}", x));
//! ```
//!
//! Iki ora print nilai sembarang, kita mung digawe iterator, tinimbang nggunakake.Panyusun bakal menehi peringatan babagan prilaku kasebut:
//!
//! ```text
//! warning: unused result that must be used: iterators are lazy and
//! do nothing unless consumed
//! ```
//!
//! Cara idiomatik kanggo nulis [`map`] kanggo efek samping yaiku nggunakake loop `for` utawa nelpon metode [`for_each`]:
//!
//! ```
//! let v = vec![1, 2, 3, 4, 5];
//!
//! v.iter().for_each(|x| println!("{}", x));
//! // or
//! for x in &v {
//!     println!("{}", x);
//! }
//! ```
//!
//! [`map`]: Iterator::map
//! [`for_each`]: Iterator::for_each
//!
//! Liyane cara umum kanggo ngira-ngira lan iterator iku kanggo nggunakake cara [`collect`] kanggo gawé koleksi anyar.
//!
//! [`collect`]: Iterator::collect
//!
//! # Infinity
//!
//! Iterators ora kudu ono wates.Contone, sawetara sing mbukak minangka pengulangan tanpa wates:
//!
//! ```
//! let numbers = 0..;
//! ```
//!
//! Punika umum nggunakake iterator adaptor [`take`] kanggo nguripake iterator tanpa wates dadi siji ono wates:
//!
//! ```
//! let numbers = 0..;
//! let five_numbers = numbers.take(5);
//!
//! for number in five_numbers {
//!     println!("{}", number);
//! }
//! ```
//!
//! Iki bakal nyithak nomer `0` nganti `4`, saben baris kasebut dhewe.
//!
//! Metokake ing atine sing cara ing iterators tanpa wates, malah sing sing asil bisa ditemtokake matématis ing wektu ono wates, bisa ora siksa.
//! Khusus, cara kayata [`min`], kang ing cilik general mbutuhake traversing saben unsur ing iterator, sing kamungkinan ora bali kasil kanggo maksud apa iterators tanpa wates.
//!
//! ```no_run
//! let ones = std::iter::repeat(1);
//! let least = ones.min().unwrap(); // Oh ora!Lan daur ulang tanpa wates!
//! // `ones.min()` nyebabake loop tanpa wates, mula kita ora bakal tekan titik iki!
//! println!("The smallest number one is {}.", least);
//! ```
//!
//! [`take`]: Iterator::take
//! [`min`]: Iterator::min
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::Iterator;

#[unstable(
    feature = "step_trait",
    reason = "likely to be replaced by finer-grained traits",
    issue = "42168"
)]
pub use self::range::Step;

#[stable(feature = "iter_empty", since = "1.2.0")]
pub use self::sources::{empty, Empty};
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub use self::sources::{from_fn, FromFn};
#[stable(feature = "iter_once", since = "1.2.0")]
pub use self::sources::{once, Once};
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub use self::sources::{once_with, OnceWith};
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::sources::{repeat, Repeat};
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub use self::sources::{repeat_with, RepeatWith};
#[stable(feature = "iter_successors", since = "1.34.0")]
pub use self::sources::{successors, Successors};

#[stable(feature = "fused", since = "1.26.0")]
pub use self::traits::FusedIterator;
#[unstable(issue = "none", feature = "inplace_iteration")]
pub use self::traits::InPlaceIterable;
#[unstable(feature = "trusted_len", issue = "37572")]
pub use self::traits::TrustedLen;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::{
    DoubleEndedIterator, ExactSizeIterator, Extend, FromIterator, IntoIterator, Product, Sum,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::adapters::Cloned;
#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::adapters::Copied;
#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::adapters::Flatten;
#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::adapters::MapWhile;
#[unstable(feature = "inplace_iteration", issue = "none")]
pub use self::adapters::SourceIter;
#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::adapters::StepBy;
#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::adapters::TrustedRandomAccess;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::adapters::{
    Chain, Cycle, Enumerate, Filter, FilterMap, FlatMap, Fuse, Inspect, Map, Peekable, Rev, Scan,
    Skip, SkipWhile, Take, TakeWhile, Zip,
};
#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::adapters::{Intersperse, IntersperseWith};

pub(crate) use self::adapters::process_results;

mod adapters;
mod range;
mod sources;
mod traits;