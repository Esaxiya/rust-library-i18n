use crate::ops::{ControlFlow, Try};

/// Lan iterator bisa unsur ngasilaken saka ends.
///
/// Soko sing nindakake `DoubleEndedIterator` wis siji kemampuan ekstra liwat soko sing nindakake [`Iterator`]: kemampuan kanggo uga njupuk: Item`s saka mburi, uga ngarep.
///
///
/// Penting cathetan sing loro maneh lan karya kasebut ing sawetara padha, lan apa ora salib: pengulangan punika liwat nalika padha ketemu ing tengah.
///
/// Ing fashion padha kanggo protokol [`Iterator`], sapisan `DoubleEndedIterator` ngasilake [`None`] saka [`next_back()`], nelpon maneh bisa utawa ora bisa tau bali [`Some`] maneh.
/// [`next()`] lan [`next_back()`] bisa diganti kanggo tujuan iki.
///
/// [`next_back()`]: DoubleEndedIterator::next_back
/// [`next()`]: Iterator::next
///
/// # Examples
///
/// Panggunaan dhasar:
///
/// ```
/// let numbers = vec![1, 2, 3, 4, 5, 6];
///
/// let mut iter = numbers.iter();
///
/// assert_eq!(Some(&1), iter.next());
/// assert_eq!(Some(&6), iter.next_back());
/// assert_eq!(Some(&5), iter.next_back());
/// assert_eq!(Some(&2), iter.next());
/// assert_eq!(Some(&3), iter.next());
/// assert_eq!(Some(&4), iter.next());
/// assert_eq!(None, iter.next());
/// assert_eq!(None, iter.next_back());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DoubleEndedIterator: Iterator {
    /// Mbusak lan ngasilake elemen saka mburi iterator.
    ///
    /// Ngasilake `None` nalika ana unsur liyane.
    ///
    /// Dokumen [trait-level] ngemot rincian liyane.
    ///
    /// [trait-level]: DoubleEndedIterator
    ///
    /// # Examples
    ///
    /// Panggunaan dhasar:
    ///
    /// ```
    /// let numbers = vec![1, 2, 3, 4, 5, 6];
    ///
    /// let mut iter = numbers.iter();
    ///
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&6), iter.next_back());
    /// assert_eq!(Some(&5), iter.next_back());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    /// assert_eq!(Some(&4), iter.next());
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next_back());
    /// ```
    ///
    /// # Remarks
    ///
    /// Unsur menehi dening: cara DoubleEndedIterator`kang beda-beda saka sing gedhe-gedhe menehi kanthi cara [: Iterator`] 's:
    ///
    ///
    /// ```
    /// let vec = vec![(1, 'a'), (1, 'b'), (1, 'c'), (2, 'a'), (2, 'b')];
    /// let uniq_by_fst_comp = || {
    ///     let mut seen = std::collections::HashSet::new();
    ///     vec.iter().copied().filter(move |x| seen.insert(x.0))
    /// };
    ///
    /// assert_eq!(uniq_by_fst_comp().last(), Some((2, 'a')));
    /// assert_eq!(uniq_by_fst_comp().next_back(), Some((2, 'b')));
    ///
    /// assert_eq!(
    ///     uniq_by_fst_comp().fold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(1, 'a'), (2, 'a')]
    /// );
    /// assert_eq!(
    ///     uniq_by_fst_comp().rfold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(2, 'b'), (1, 'c')]
    /// );
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next_back(&mut self) -> Option<Self::Item>;

    /// Maju iterator saka mburi dening unsur `n`.
    ///
    /// `advance_back_by` versi mbalikke saka [`advance_by`].Cara iki eagerly bakal skip unsur `n` miwiti saka mburi dening nelpon [`next_back`] nganti `n` kaping nganti [`None`] wis pinanggih.
    ///
    /// `advance_back_by(n)` bakal ngasilake [`Ok(())`] yen iterator bisa maju maju kanthi elemen `n`, utawa [`Err(k)`] yen [`None`] ditemokake, ing endi `k` minangka pirang-pirang elemen iterator sing dikepengini sadurunge entek elemen (yaiku
    /// dawa iterator ing).
    /// Elinga yen `k` tansah kurang saka `n`.
    ///
    /// Nelpon `advance_back_by(0)` ora nganggo unsur lan tansah ngasilake [`Ok(())`].
    ///
    /// [`advance_by`]: Iterator::advance_by
    /// [`next_back`]: DoubleEndedIterator::next_back
    ///
    /// # Examples
    ///
    /// Panggunaan dhasar:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [3, 4, 5, 6];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_back_by(2), Ok(()));
    /// assert_eq!(iter.next_back(), Some(&4));
    /// assert_eq!(iter.advance_back_by(0), Ok(()));
    /// assert_eq!(iter.advance_back_by(100), Err(1)); // mung `&3` sing dilewati
    /// ```
    ///
    /// [`Ok(())`]: Ok
    /// [`Err(k)`]: Err
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next_back().ok_or(i)?;
        }
        Ok(())
    }

    /// Ngasilake ing: unsur n`th saka mburi iterator ing.
    ///
    /// Iki ateges versi [`Iterator::nth()`] sing dibalikke.
    /// Senajan kaya operasi indeksasi paling, count diwiwiti saka nol, supaya `nth_back(0)` ngasilake angka pisanan saka mburi, `nth_back(1)` kaloro, lan ing.
    ///
    ///
    /// Elinga yen kabeh unsur antarane mburi lan unsur bali bakal migunakaken, kalebu unsur bali.
    /// Iki uga liya sing nelpon `nth_back(0)` kaping pirang-pirang ing iterator padha bakal ngasilake unsur beda.
    ///
    /// `nth_back()` bakal ngasilake [`None`] yen `n` iku luwih saka utawa witjaksono menyang dawa saka iterator ing.
    ///
    /// # Examples
    ///
    /// Panggunaan dhasar:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(2), Some(&1));
    /// ```
    ///
    /// Nelpon `nth_back()` kaping pirang-pirang ora mundurake iterator:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth_back(1), Some(&2));
    /// assert_eq!(iter.nth_back(1), None);
    /// ```
    ///
    /// Bali `None` yen kurang saka elemen `n + 1`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(10), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_nth_back", since = "1.37.0")]
    fn nth_back(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_back_by(n).ok()?;
        self.next_back()
    }

    /// Iki versi mbalikke saka [`Iterator::try_fold()`]: iku njupuk unsur miwiti saka mburi iterator ing.
    ///
    ///
    /// # Examples
    ///
    /// Panggunaan dhasar:
    ///
    /// ```
    /// let a = ["1", "2", "3"];
    /// let sum = a.iter()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert_eq!(sum, Ok(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = ["1", "rust", "3"];
    /// let mut it = a.iter();
    /// let sum = it
    ///     .by_ref()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert!(sum.is_err());
    ///
    /// // Amarga sirkulasi singkat, elemen sing isih ana isih kasedhiya liwat iterator.
    /////
    /// assert_eq!(it.next_back(), Some(&"1"));
    /// ```
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// Metode iterator sing nyuda unsur iterator dadi siji, angka pungkasan, diwiwiti saka mburi.
    ///
    /// Iki versi mbalikke saka [`Iterator::fold()`]: iku njupuk unsur miwiti saka mburi iterator ing.
    ///
    /// `rfold()` njupuk loro bantahan: nilai dhisikan, lan panutupan karo loro bantahan: lan 'accumulator', lan unsur.
    /// penutupan kasus ngasilake angka sing accumulator kudu kanggo pengulangan sabanjuré.
    ///
    /// Nilai dhisikan punika Nilai accumulator bakal ing telpon pisanan.
    ///
    /// Sawise nglamar penutupan kasus iki kanggo saben unsur iterator ing, `rfold()` ngasilake accumulator ing.
    ///
    /// operasi iki kadhangkala disebut 'reduce' utawa 'inject'.
    ///
    /// Lempitan migunani kapan duwe koleksi soko, lan pengin kanggo gawé Nilai siji saka iku.
    ///
    /// # Examples
    ///
    /// Panggunaan dhasar:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // gunggunge kabeh unsur a
    /// let sum = a.iter()
    ///            .rfold(0, |acc, &x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// Contone di bangun senar, miwiti karo nilai dhisikan lan terus saben unsur saka mburi nganti ngarep:
    ///
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let zero = "0".to_string();
    ///
    /// let result = numbers.iter().rfold(zero, |acc, &x| {
    ///     format!("({} + {})", x, acc)
    /// });
    ///
    /// assert_eq!(result, "(1 + (2 + (3 + (4 + (5 + 0)))))");
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfold", since = "1.27.0")]
    fn rfold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x);
        }
        accum
    }

    /// Nggoleki unsur iterator saka mburi sing nglegakake predikat.
    ///
    /// `rfind()` njupuk penutupan sing ngasilake `true` utawa `false`.
    /// Iki ditrapake kanggo saben elemen iterator, diwiwiti ing pungkasan, lan yen ana sing bali `true`, mula `rfind()` ngasilake [`Some(element)`].
    /// Yen kabeh bali `false`, ngasilake [`None`].
    ///
    /// `rfind()` cendhak-circuiting;ing tembung liyane, iku bakal mungkasi Processing sanalika penutupan kasus ngasilake `true`.
    ///
    /// Amarga `rfind()` njupuk referensi, lan akeh iterators iterate liwat referensi, ndadékaké iki kanggo kahanan bisa bingung ngendi pitakonan kuwi referensi pindho.
    ///
    /// Sampeyan bisa ndeleng efek iki ing conto ing ngisor iki, kanthi `&&x`.
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// Panggunaan dhasar:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 5), None);
    /// ```
    ///
    /// Mandheg `true` pisanan:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rfind(|&&x| x == 2), Some(&2));
    ///
    /// // kita isih bisa nggunakake `iter`, amarga ana elemen liyane.
    /// assert_eq!(iter.next_back(), Some(&1));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfind", since = "1.27.0")]
    fn rfind<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_rfold((), check(predicate)).break_value()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, I: DoubleEndedIterator + ?Sized> DoubleEndedIterator for &'a mut I {
    fn next_back(&mut self) -> Option<I::Item> {
        (**self).next_back()
    }
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_back_by(n)
    }
    fn nth_back(&mut self, n: usize) -> Option<I::Item> {
        (**self).nth_back(n)
    }
}