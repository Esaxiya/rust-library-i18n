/// Lan iterator sing mangerténi uga dawané kang persis.
///
/// Akeh [: Iterator`] s ora ngerti carane kakehan padha iterate, nanging sawetara.
/// Menawi iterator mangerténi carane kakehan bisa iterate, nyediakake akses menyang informasi sing bisa migunani.
/// Contone, yen sampeyan pengin mundur mundur, wiwitan sing apik yaiku ngerti endi pungkasane.
///
/// Nalika nindakaken lan `ExactSizeIterator`, sampeyan uga kudu ngleksanakake [`Iterator`].
/// Nalika mengkono, lampahipun [`Iterator::size_hint`]*kudu* bali ukuran pas iterator ing.
///
/// Cara [`len`] wis implementasine standar, supaya sampeyan biasane ora kudu ngleksanakake iku.
/// Nanging, sampeyan uga bisa kanggo nyedhiyani implementasine performant liyane saka gawan, supaya overriding ing kasus iki ndadekake pangertèn.
///
///
/// Elinga yen trait iki trait aman lan kuwi ora *ora* lan *ora bisa* njamin sing dawa bali bener.
/// Tegese sing kode `unsafe`**ora kudu** gumantung ing bener [`Iterator::size_hint`].
/// The boten stabil lan aman [`TrustedLen`](super::marker::TrustedLen) trait menehi garansi tambahan.
///
/// [`len`]: ExactSizeIterator::len
///
/// # Examples
///
/// Panggunaan dhasar:
///
/// ```
/// // kisaran winates ngerti persis carane kakehan
/// let five = 0..5;
///
/// assert_eq!(5, five.len());
/// ```
///
/// Ing [module-level docs], kita ginakaken [`Iterator`], `Counter`.
/// Ayo ngleksanakake `ExactSizeIterator` uga:
///
/// [module-level docs]: crate::iter
///
/// ```
/// # struct Counter {
/// #     count: usize,
/// # }
/// # impl Counter {
/// #     fn new() -> Counter {
/// #         Counter { count: 0 }
/// #     }
/// # }
/// # impl Iterator for Counter {
/// #     type Item = usize;
/// #     fn next(&mut self) -> Option<Self::Item> {
/// #         self.count += 1;
/// #         if self.count < 6 {
/// #             Some(self.count)
/// #         } else {
/// #             None
/// #         }
/// #     }
/// # }
/// impl ExactSizeIterator for Counter {
///     // Kita bisa gampang ngetung nomer isih iterasi.
///     fn len(&self) -> usize {
///         5 - self.count
///     }
/// }
///
/// // Lan saiki kita bisa nggunakake!
///
/// let counter = Counter::new();
///
/// assert_eq!(5, counter.len());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ExactSizeIterator: Iterator {
    /// Ngasilake dawa sing tepat saka iterator.
    ///
    /// Implementasine agawé iterator bakal ngasilake persis `len()` liyane kaping Nilai [`Some(T)`], sadurunge bali [`None`].
    ///
    /// Cara iki nduweni implementasine standar, supaya sampeyan biasane ora kudu ngleksanakake langsung.
    /// Nanging, yen sampeyan bisa nyedhiyakake implementasi sing luwih efisien, sampeyan bisa nindakake.
    /// Deleng docs [trait-level] kanggo conto.
    ///
    /// Fungsi iki wis njamin safety padha fungsi [`Iterator::size_hint`].
    ///
    /// [trait-level]: ExactSizeIterator
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// Panggunaan dhasar:
    ///
    /// ```
    /// // kisaran winates ngerti persis carane kakehan
    /// let five = 0..5;
    ///
    /// assert_eq!(5, five.len());
    /// ```
    ///
    ///
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn len(&self) -> usize {
        let (lower, upper) = self.size_hint();
        // Note: tuntutan iki kebacut pertahanan, nanging ngecek podho ing
        // dijamin dening trait.
        // Yen trait iki padha rust-internal, kita bisa nggunakake debug_assert !;assert_eq!bakal mriksa kabeh nindakake pengguna Rust banget.
        //
        assert_eq!(upper, Some(lower));
        lower
    }

    /// Ngasilake `true` yen iterator kosong.
    ///
    /// Cara iki nduweni implementasine standar nggunakake [`ExactSizeIterator::len()`], supaya sampeyan ora perlu kanggo ngleksanakake dhewe.
    ///
    ///
    /// # Examples
    ///
    /// Panggunaan dhasar:
    ///
    /// ```
    /// #![feature(exact_size_is_empty)]
    ///
    /// let mut one_element = std::iter::once(0);
    /// assert!(!one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), Some(0));
    /// assert!(one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), None);
    /// ```
    #[inline]
    #[unstable(feature = "exact_size_is_empty", issue = "35428")]
    fn is_empty(&self) -> bool {
        self.len() == 0
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator + ?Sized> ExactSizeIterator for &mut I {
    fn len(&self) -> usize {
        (**self).len()
    }
    fn is_empty(&self) -> bool {
        (**self).is_empty()
    }
}