/// Pengulangan sing mesthi terus ngasilake `None` yen kesel.
///
/// Nelpon sabanjuré ing nggabungke iterator sing wis bali `None` sapisan wis dijamin kanggo bali [`None`] maneh.
/// trait iki kudu dipun ginakaken dening kabeh iterators sing nindakake cara iki amarga ngidini optimalisasi [`Iterator::fuse()`].
///
///
/// Note: Umumé, sampeyan ora kudu nganggo `FusedIterator` ing wates umum yen mbutuhake nggabungke iterator.
/// Nanging, sampeyan kudu mung nelpon [`Iterator::fuse()`] ing iterator ing.
/// Yen iterator wis nyawiji, bungkus [`Fuse`] tambahan bakal dadi no-op tanpa paukuman kinerja.
///
/// [`Fuse`]: crate::iter::Fuse
///
#[stable(feature = "fused", since = "1.26.0")]
#[rustc_unsafe_specialization_marker]
pub trait FusedIterator: Iterator {}

#[stable(feature = "fused", since = "1.26.0")]
impl<I: FusedIterator + ?Sized> FusedIterator for &mut I {}

/// Pengulangan sing nglaporake dawa akurat nggunakake size_hint.
///
/// Iterator nglaporake tandha ukuran ing endi sing pas (wates ngisor padha karo wates ndhuwur), utawa wates ndhuwur yaiku [`None`].
///
/// Ing ndhuwur bound kudu mung dadi [`None`] yen dawane iterator nyata luwih [`usize::MAX`].
/// Ing kasus-kasus iku, ing ngisor kaiket kudu [`usize::MAX`], asil ing [`Iterator::size_hint()`] saka `(usize::MAX, None)`.
///
/// iterator kudu gawé persis nomer unsur iku kacarita utawa diverge sadurunge sik njongko mburi.
///
/// # Safety
///
/// trait iki mung kudu dileksanakake nalika kontrak ditanggepi.
/// Konsumen saka trait iki kudu mriksa wates ndhuwur [`Iterator::size_hint()`]’s.
///
///
///
#[unstable(feature = "trusted_len", issue = "37572")]
#[rustc_unsafe_specialization_marker]
pub unsafe trait TrustedLen: Iterator {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<I: TrustedLen + ?Sized> TrustedLen for &mut I {}

/// Lan iterator yen ngasilke item bakal wis dijupuk ing paling siji unsur saka [`SourceIter`] sawijining ndasari.
///
/// Nelpon cara sembarang sing maju iterator ing, contone
/// [`next()`] utawa [`try_fold()`], njamin sing kanggo saben langkah paling siji Nilai saka sumber ndasari iterator kang wis dipindhah metu lan asil saka chain iterator bisa dipasang ing sawijining panggonan, assuming alangan struktural sumber ngidini selipan kuwi.
///
/// Ing tembung liyane trait iki nuduhake yen pipa iterator bisa diklumpukake ing papan.
///
/// [`SourceIter`]: crate::iter::SourceIter
/// [`next()`]: Iterator::next
/// [`try_fold()`]: Iterator::try_fold
///
///
#[unstable(issue = "none", feature = "inplace_iteration")]
pub unsafe trait InPlaceIterable: Iterator {}