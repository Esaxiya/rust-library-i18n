// nglirwakake-apik-filelength berkas iki meh istimewa kasusun saka definisi `Iterator`.
// Ora bisa dipérang dadi pirang-pirang file.
//

use crate::cmp::{self, Ordering};
use crate::ops::{ControlFlow, Try};

use super::super::TrustedRandomAccess;
use super::super::{Chain, Cloned, Copied, Cycle, Enumerate, Filter, FilterMap, Fuse};
use super::super::{FlatMap, Flatten};
use super::super::{FromIterator, Intersperse, IntersperseWith, Product, Sum, Zip};
use super::super::{
    Inspect, Map, MapWhile, Peekable, Rev, Scan, Skip, SkipWhile, StepBy, Take, TakeWhile,
};

fn _assert_is_object_safe(_: &dyn Iterator<Item = ()>) {}

/// Antarmuka kanggo dealing with iterators.
///
/// Iki minangka iterator utama trait.
/// Kanggo luwih bab konsep iterators umume, pirsani [module-level documentation].
/// Ing tartamtu, sampeyan bisa uga pengin ngerti carane [implement `Iterator`][impl].
///
/// [module-level documentation]: crate::iter
/// [impl]: crate::iter#implementing-iterator
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    on(
        _Self = "[std::ops::Range<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..end]` is an array of one `Range`; you might have meant to have a `Range` \
                without the brackets: `start..end`"
    ),
    on(
        _Self = "[std::ops::RangeFrom<Idx>; 1]",
        label = "if you meant to iterate from a value onwards, remove the square brackets",
        note = "`[start..]` is an array of one `RangeFrom`; you might have meant to have a \
              `RangeFrom` without the brackets: `start..`, keeping in mind that iterating over an \
              unbounded iterator will run forever unless you `break` or `return` from within the \
              loop"
    ),
    on(
        _Self = "[std::ops::RangeTo<Idx>; 1]",
        label = "if you meant to iterate until a value, remove the square brackets and add a \
                 starting value",
        note = "`[..end]` is an array of one `RangeTo`; you might have meant to have a bounded \
                `Range` without the brackets: `0..end`"
    ),
    on(
        _Self = "[std::ops::RangeInclusive<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..=end]` is an array of one `RangeInclusive`; you might have meant to have a \
              `RangeInclusive` without the brackets: `start..=end`"
    ),
    on(
        _Self = "[std::ops::RangeToInclusive<Idx>; 1]",
        label = "if you meant to iterate until a value (including it), remove the square brackets \
                 and add a starting value",
        note = "`[..=end]` is an array of one `RangeToInclusive`; you might have meant to have a \
                bounded `RangeInclusive` without the brackets: `0..=end`"
    ),
    on(
        _Self = "std::ops::RangeTo<Idx>",
        label = "if you meant to iterate until a value, add a starting value",
        note = "`..end` is a `RangeTo`, which cannot be iterated on; you might have meant to have a \
              bounded `Range`: `0..end`"
    ),
    on(
        _Self = "std::ops::RangeToInclusive<Idx>",
        label = "if you meant to iterate until a value (including it), add a starting value",
        note = "`..=end` is a `RangeToInclusive`, which cannot be iterated on; you might have meant \
              to have a bounded `RangeInclusive`: `0..=end`"
    ),
    on(
        _Self = "&str",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "std::string::String",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "[]",
        label = "borrow the array with `&` or call `.iter()` on it to iterate over it",
        note = "arrays are not iterators, but slices like the following are: `&[1, 2, 3]`"
    ),
    on(
        _Self = "{integral}",
        note = "if you want to iterate between `start` until a value `end`, use the exclusive range \
              syntax `start..end` or the inclusive range syntax `start..=end`"
    ),
    label = "`{Self}` is not an iterator",
    message = "`{Self}` is not an iterator"
)]
#[doc(spotlight)]
#[rustc_diagnostic_item = "Iterator"]
#[must_use = "iterators are lazy and do nothing unless consumed"]
pub trait Iterator {
    /// Jinis unsur sing diulangi.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// Maju iterator lan ngasilake nilai sabanjure.
    ///
    /// Ngasilake [`None`] nalika pengulangan rampung.
    /// nindakake iterator individu bisa milih kanggo nerusake pengulangan, lan nelpon `next()` maneh bisa utawa ora bisa pungkasanipun miwiti bali [`Some(Item)`] maneh ing sawetara titik.
    ///
    ///
    /// [`Some(Item)`]: Some
    ///
    /// # Examples
    ///
    /// Panggunaan dhasar:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // A telpon kanggo next() ngasilake angka sabanjuré ...
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    ///
    /// // ... lan banjur Ana sapisan iku liwat.
    /// assert_eq!(None, iter.next());
    ///
    /// // telpon liyane utawa bisa bali `None`.Ing kene, dheweke mesthi bakal.
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[lang = "next"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next(&mut self) -> Option<Self::Item>;

    /// Ngasilake wates ing dawa isih iterator ing.
    ///
    /// Khusus, `size_hint()` ngasilake tuple ngendi unsur kapisan ing ngisor kaiket, lan unsur kaping kalih inggih punika ndhuwur kaiket.
    ///
    /// Separo ing tuple sing wis bali iku sawijining [: Option`]: <: [: usize`]:>:.
    /// A [`None`] kene liya sing salah siji ana dikenal ndhuwur kaiket, utawa ing ndhuwur kaiket luwih [`usize`].
    ///
    /// # Implementasi
    ///
    /// Ora dileksanakake yen implementasi iterator ngasilake jumlah unsur sing diumumake.A jip iterator bisa ngasilaken kurang luwih murah kaiket utawa luwih saka ing ndhuwur kaiket saka unsur.
    ///
    /// `size_hint()` utamané dimaksudaké kanggo digunakake kanggo optimizations kayata reserving papan kanggo unsur iterator, nanging ora kudu dipercaya kanggo eg, wates kir omit ing kode aman.
    /// Implementasi `size_hint()` sing salah ora nyebabake pelanggaran keamanan memori.
    ///
    /// Sing ngandika, implementasine ngirim nyedhiyani ngira-ira, amarga digunakake, iku bakal nglanggar protokol trait kang.
    ///
    /// Implementasine default ngasilake `(0,` [`Nothing`]`)` sing bener kanggo iterator apa wae.
    ///
    /// [`usize`]: type@usize
    ///
    /// # Examples
    ///
    /// Panggunaan dhasar:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let iter = a.iter();
    ///
    /// assert_eq!((3, Some(3)), iter.size_hint());
    /// ```
    ///
    /// Conto liyane Komplek:
    ///
    /// ```
    /// // Angka malah saka nul kanggo sepuluh.
    /// let iter = (0..10).filter(|x| x % 2 == 0);
    ///
    /// // Kita bisa ngetung kaping nol nganti kaping sepuluh.
    /// // Ngerti manawa limang sejatine ora bakal bisa dilakoni tanpa nglakokake filter().
    /// assert_eq!((0, Some(10)), iter.size_hint());
    ///
    /// // Ayo tambah limang nomer maneh nganggo chain()
    /// let iter = (0..10).filter(|x| x % 2 == 0).chain(15..20);
    ///
    /// // saiki loro wates sing tambah dening limang
    /// assert_eq!((5, Some(15)), iter.size_hint());
    /// ```
    ///
    /// Bali `None` kanggo wates ndhuwur:
    ///
    /// ```
    /// // winates iterator wis ora ndhuwur kaiket lan maksimum bisa murah bound
    /////
    /// let iter = 0..;
    ///
    /// assert_eq!((usize::MAX, None), iter.size_hint());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }

    /// Nganggo iterator, sarego nomer iterasi lan bali iku.
    ///
    /// Cara iki bakal nelpon [`next`] bola-bali nganti [`None`] wis pinanggih, bali nomer kaping weruh [`Some`].
    /// Elinga yen [`next`] kudu ditelpon paling ora sapisan sanajan iterator ora ana unsur apa wae.
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Tumindake kebanjiran
    ///
    /// Cara kang ora ndjogo marang overflows, supaya ngetang unsur saka iterator karo luwih saka [`usize::MAX`] unsur salah siji mrodhuksi asil salah utawa panics.
    ///
    /// Yen pandhedhesan debug sing aktif, a panic dijamin.
    ///
    /// # Panics
    ///
    /// Fungsi iki, ketjobo panic yen iterator wis luwih saka unsur [`usize::MAX`].
    ///
    /// # Examples
    ///
    /// Panggunaan dhasar:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().count(), 3);
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().count(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn count(self) -> usize
    where
        Self: Sized,
    {
        self.fold(
            0,
            #[rustc_inherit_overflow_checks]
            |count, _| count + 1,
        )
    }

    /// Nganggo iterator, ngasilake elemen pungkasan.
    ///
    /// Cara iki bakal ngevaluasi iterator nganti ngasilake [`None`].
    /// Nalika mengkono, iku tansah trek saka unsur saiki.
    /// Sawise [`None`] bali, `last()` banjur bakal ngasilake elemen pungkasan sing katon.
    ///
    /// # Examples
    ///
    /// Panggunaan dhasar:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().last(), Some(&3));
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().last(), Some(&5));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn last(self) -> Option<Self::Item>
    where
        Self: Sized,
    {
        #[inline]
        fn some<T>(_: Option<T>, x: T) -> Option<T> {
            Some(x)
        }

        self.fold(None, some)
    }

    /// Maju iterator dening unsur `n`.
    ///
    /// Cara iki eagerly bakal skip unsur `n` dening nelpon [`next`] nganti `n` kaping nganti [`None`] wis pinanggih.
    ///
    /// `advance_by(n)` bakal ngasilake [`Ok(())`][Ok] yen iterator kasil maju dening unsur `n`, utawa [`Err(k)`][Err] yen [`None`] wis pinanggih, ngendi `k` nomer unsur iterator iku linuwih kanthi sadurunge mlaku metu saka unsur (IE
    /// dawa iterator ing).
    /// Elinga yen `k` tansah kurang saka `n`.
    ///
    /// Nelpon `advance_by(0)` ora nganggo unsur apa wae lan mesthi ngasilake [`Ok(())`][Ok].
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// Panggunaan dhasar:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_by(2), Ok(()));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.advance_by(0), Ok(()));
    /// assert_eq!(iter.advance_by(100), Err(1)); // mung `&4` iki Mlayu
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next().ok_or(i)?;
        }
        Ok(())
    }

    /// Ngasilake ing: unsur n`th saka iterator ing.
    ///
    /// Kaya umume operasi indeks, cacah diwiwiti saka nol, mula `nth(0)` ngasilake angka pisanan, `nth(1)` nomer loro, lan liya-liyane.
    ///
    /// Elinga yen kabeh unsur sadurungé, uga unsur bali, bakal migunakaken saka iterator ing.
    /// Iki tegese elemen sadurunge bakal dibuwang, lan uga nelpon `nth(0)` kaping pirang-pirang ing iterator sing padha bakal ngasilake elemen sing beda.
    ///
    ///
    /// `nth()` bakal ngasilake [`None`] yen `n` iku luwih saka utawa witjaksono menyang dawa saka iterator ing.
    ///
    /// # Examples
    ///
    /// Panggunaan dhasar:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(1), Some(&2));
    /// ```
    ///
    /// Nelpon `nth()` kaping pirang-pirang ora mundurake iterator:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth(1), Some(&2));
    /// assert_eq!(iter.nth(1), None);
    /// ```
    ///
    /// Bali `None` yen kurang saka elemen `n + 1`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(10), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_by(n).ok()?;
        self.next()
    }

    /// Nggawe iterator miwiti ing titik sing padha, nanging mlaku dening jumlah tartamtu ing saben pengulangan.
    ///
    /// Wigati 1: Ing unsur pisanan iterator bakal tansah bali, preduli saka langkah diwenehi.
    ///
    /// Cathetan 2: Wektu nalika elemen ditarik ora ditarik.
    /// `StepBy` dumadakan kaya urutan `next(), nth(step-1), nth(step-1),…`, nanging uga bebas nindakake kaya urutan
    ///
    /// `advance_n_and_return_first(step), advance_n_and_return_first(step), …`
    /// cara digunakake bisa ngganti kanggo sawetara iterators kanggo alesan kinerja kang.
    /// Cara liyane bakal advance iterator sadurungé lan uga akeh liyane item.
    ///
    /// `advance_n_and_return_first` padha karo:
    ///
    /// ```
    /// fn advance_n_and_return_first<I>(iter: &mut I, total_step: usize) -> Option<I::Item>
    /// where
    ///     I: Iterator,
    /// {
    ///     let next = iter.next();
    ///     if total_step > 1 {
    ///         iter.nth(total_step-2);
    ///     }
    ///     next
    /// }
    /// ```
    ///
    /// # Panics
    ///
    /// Cara bakal panic yen langkah ing ngisor iki: `0`.
    ///
    /// # Examples
    ///
    /// Panggunaan dhasar:
    ///
    /// ```
    /// let a = [0, 1, 2, 3, 4, 5];
    /// let mut iter = a.iter().step_by(2);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_step_by", since = "1.28.0")]
    fn step_by(self, step: usize) -> StepBy<Self>
    where
        Self: Sized,
    {
        StepBy::new(self, step)
    }

    /// Njupuk loro iterators lan nggawe iterator anyar liwat loro ing urutan.
    ///
    /// `chain()` bakal ngasilake iterator anyar sing luwih dhisik bakal ngetrapake angka saka iterator pisanan lan banjur liwat nilai saka iterator nomer loro.
    ///
    /// Kanthi tembung liya, ngubungake rong iterator ing rantai.🔗
    ///
    /// [`once`] umume digunakake kanggo adaptasi siji regane dadi rantai jinis iterasi liyane.
    ///
    /// # Examples
    ///
    /// Panggunaan dhasar:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().chain(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Wiwit pitakonan kanggo `chain()` migunakake [`IntoIterator`], kita bisa pass apa sing bisa diowahi menyang [`Iterator`], ora mung sing [`Iterator`] dhewe.
    /// Contone, irisan-irisan (`&[T]`) ngleksanakake [`IntoIterator`], lan supaya bisa liwati kanggo `chain()` langsung:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().chain(s2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Yen sampeyan nggarap Windows API, sampeyan bisa ngowahi [`OsStr`] dadi `Vec<u16>`:
    ///
    /// ```
    /// #[cfg(windows)]
    /// fn os_str_to_utf16(s: &std::ffi::OsStr) -> Vec<u16> {
    ///     use std::os::windows::ffi::OsStrExt;
    ///     s.encode_wide().chain(std::iter::once(0)).collect()
    /// }
    /// ```
    ///
    /// [`once`]: crate::iter::once
    /// [`OsStr`]: ../../std/ffi/struct.OsStr.html
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn chain<U>(self, other: U) -> Chain<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator<Item = Self::Item>,
    {
        Chain::new(self, other.into_iter())
    }

    /// 'Stingrays munggah' loro iterators menyang iterator siji saka pasangan.
    ///
    /// `zip()` ngasilake a iterator anyar sing bakal iterate liwat loro iterators liyane, bali tuple endi unsur kapisan rawuh saka iterator pisanan, lan unsur liya asalé saka iterator kapindho.
    ///
    ///
    /// Kanthi tembung liyane, bakal zip loro iterator dadi siji.
    ///
    /// Yen salah siji iterator ngasilake [`None`], [`next`] saka zip iterator bakal ngasilake [`None`].
    /// Yen iterator pisanan ngasilake [`None`], `zip` bakal short-circuit lan `next` bakal ora disebut ing iterator kapindho.
    ///
    /// # Examples
    ///
    /// Panggunaan dhasar:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().zip(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Wiwit pitakonan kanggo `zip()` migunakake [`IntoIterator`], kita bisa pass apa sing bisa diowahi menyang [`Iterator`], ora mung sing [`Iterator`] dhewe.
    /// Contone, irisan-irisan (`&[T]`) ngleksanakake [`IntoIterator`], lan supaya bisa liwati kanggo `zip()` langsung:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().zip(s2);
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `zip()` asring digunakake kanggo pos lan iterator tanpa wates kanggo siji ono wates.
    /// Iki dianggo amarga wates ing iterator pungkasanipun bakal ngasilake [`None`], pungkasan zipper.Zipping karo `(0..)` bisa katon akèh kaya [`enumerate`]:
    ///
    /// ```
    /// let enumerate: Vec<_> = "foo".chars().enumerate().collect();
    ///
    /// let zipper: Vec<_> = (0..).zip("foo".chars()).collect();
    ///
    /// assert_eq!((0, 'f'), enumerate[0]);
    /// assert_eq!((0, 'f'), zipper[0]);
    ///
    /// assert_eq!((1, 'o'), enumerate[1]);
    /// assert_eq!((1, 'o'), zipper[1]);
    ///
    /// assert_eq!((2, 'o'), enumerate[2]);
    /// assert_eq!((2, 'o'), zipper[2]);
    /// ```
    ///
    /// [`enumerate`]: Iterator::enumerate
    /// [`next`]: Iterator::next
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn zip<U>(self, other: U) -> Zip<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator,
    {
        Zip::new(self, other.into_iter())
    }

    /// Nggawe iterator anyar kang panggonan salinan `separator` antarane item jejer ing iterator asli.
    ///
    /// Yen `separator` ora ngetrapake [`Clone`] utawa kudu diitung saben wektu, gunakake [`intersperse_with`].
    ///
    ///
    /// # Examples
    ///
    /// Panggunaan dhasar:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let mut a = [0, 1, 2].iter().intersperse(&100);
    /// assert_eq!(a.next(), Some(&0));   // Unsur pisanan saka `a`.
    /// assert_eq!(a.next(), Some(&100)); // Ing pamisah.
    /// assert_eq!(a.next(), Some(&1));   // Unsur sabanjuré saka `a`.
    /// assert_eq!(a.next(), Some(&100)); // Ing pamisah.
    /// assert_eq!(a.next(), Some(&2));   // Elemen pungkasan saka `a`.
    /// assert_eq!(a.next(), None);       // iterator punika rampung.
    /// ```
    ///
    /// `intersperse` bisa banget migunani kanggo nggabungake item lan iterator nggunakake unsur umum:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let hello = ["Hello", "World", "!"].iter().copied().intersperse(" ").collect::<String>();
    /// assert_eq!(hello, "Hello World !");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse_with`]: Iterator::intersperse_with
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse(self, separator: Self::Item) -> Intersperse<Self>
    where
        Self: Sized,
        Self::Item: Clone,
    {
        Intersperse::new(self, separator)
    }

    /// Nggawe iterator anyar kang panggonan item déning `separator` antarane item jejer ing iterator asli.
    ///
    /// penutupan kasus bakal disebut persis sapisan saben wektu item wis diselehake antarane loro item jejer saka iterator ndasari;
    /// khusus, penutupan kasus ora disebut yen ndasari iterator panenan kurang saka rong item lan sawise item pungkasan menehi.
    ///
    ///
    /// Yen item iterator ngleksanakake [`Clone`], bisa uga luwih gampang nggunakake [`intersperse`].
    ///
    /// # Examples
    ///
    /// Panggunaan dhasar:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// #[derive(PartialEq, Debug)]
    /// struct NotClone(usize);
    ///
    /// let v = vec![NotClone(0), NotClone(1), NotClone(2)];
    /// let mut it = v.into_iter().intersperse_with(|| NotClone(99));
    ///
    /// assert_eq!(it.next(), Some(NotClone(0)));  // Unsur pisanan saka `v`.
    /// assert_eq!(it.next(), Some(NotClone(99))); // Ing pamisah.
    /// assert_eq!(it.next(), Some(NotClone(1)));  // Elemen sabanjure saka `v`.
    /// assert_eq!(it.next(), Some(NotClone(99))); // Ing pamisah.
    /// assert_eq!(it.next(), Some(NotClone(2)));  // Unsur pungkasan saka `v`.
    /// assert_eq!(it.next(), None);               // iterator punika rampung.
    /// ```
    ///
    /// `intersperse_with` bisa digunakake ing kahanan pamisah perlu komputer:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let src = ["Hello", "to", "all", "people", "!!"].iter().copied();
    ///
    /// // Penutupan kasebut bisa uga menehi kontek kanggo ngasilake barang.
    /// let mut happy_emojis = [" ❤️ ", " 😀 "].iter().copied();
    /// let separator = || happy_emojis.next().unwrap_or(" 🦀 ");
    ///
    /// let result = src.intersperse_with(separator).collect::<String>();
    /// assert_eq!(result, "Hello ❤️ to 😀 all 🦀 people 🦀 !!");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse`]: Iterator::intersperse
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse_with<G>(self, separator: G) -> IntersperseWith<Self, G>
    where
        Self: Sized,
        G: FnMut() -> Self::Item,
    {
        IntersperseWith::new(self, separator)
    }

    /// Nindakake penutupan lan nggawe pengulangan sing nyebut penutupan kasebut kanggo saben elemen.
    ///
    /// `map()` bentuk siji iterator menyang liyane, kanthi pitakonan sawijining:
    /// soko sing nindakake [`FnMut`].Iku mrodhuksi iterator anyar kang nyebut penutupan kasus iki ing saben unsur ing iterator asli.
    ///
    /// Yen sing apik ing mikir ing jinis, sampeyan bisa mikiraken `map()` kaya iki:
    /// Yen sampeyan duwe iterator sing menehi unsur sawetara jinis `A`, lan pengin sing iterator saka sawetara jinis liyane `B`, sampeyan bisa nggunakake `map()`, maringaken panutupan sing njupuk `A` lan ngasilake `B`.
    ///
    ///
    /// `map()` iku conceptually padha daur ulang [`for`].Nanging, minangka `map()` kesed, iku paling apik digunakake nalika sampeyan wis nggarap iterators liyane.
    /// Yen sampeyan lagi dilakoni sawetara Urut saka looping kanggo efek sisih, iku dianggep luwih idiomatic nggunakake [`for`] saka `map()`.
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    /// [`FnMut`]: crate::ops::FnMut
    ///
    /// # Examples
    ///
    /// Panggunaan dhasar:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().map(|x| 2 * x);
    ///
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), Some(6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Yen sampeyan lagi dilakoni sawetara Urut saka efek sisih, seneng [`for`] kanggo `map()`:
    ///
    /// ```
    /// # #![allow(unused_must_use)]
    /// // ojo ngene iki:
    /// (0..5).map(|x| println!("{}", x));
    ///
    /// // malah ora bakal dieksekusi, amarga kesed.Rust bakal ngelingake sampeyan babagan iki.
    ///
    /// // Nanging, digunakake kanggo:
    /// for x in 0..5 {
    ///     println!("{}", x);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn map<B, F>(self, f: F) -> Map<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> B,
    {
        Map::new(self, f)
    }

    /// Telpon panutupan ing saben unsur saka iterator.
    ///
    /// Iki padha karo nggunakake loop [`for`] ing iterator, sanajan `break` lan `continue` ora bisa ditutup.
    /// Iku langkung idiomatic nggunakake daur ulang `for`, nanging `for_each` uga liyane kawaca nalika proses item ing mburi rentengan iterator maneh.
    ///
    /// Ing sawetara kasus `for_each` uga luwih cepet saka daur ulang, amarga bakal nggunakake pengulangan internal ing adaptor kaya `Chain`.
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// # Examples
    ///
    /// Panggunaan dhasar:
    ///
    /// ```
    /// use std::sync::mpsc::channel;
    ///
    /// let (tx, rx) = channel();
    /// (0..5).map(|x| x * 2 + 1)
    ///       .for_each(move |x| tx.send(x).unwrap());
    ///
    /// let v: Vec<_> =  rx.iter().collect();
    /// assert_eq!(v, vec![1, 3, 5, 7, 9]);
    /// ```
    ///
    /// Contone cilik kaya ngono, loop `for` bisa uga luwih resik, nanging `for_each` luwih becik njaga gaya fungsional kanthi pengulangan sing luwih dawa:
    ///
    /// ```
    /// (0..5).flat_map(|x| x * 100 .. x * 110)
    ///       .enumerate()
    ///       .filter(|&(i, x)| (i + x) % 3 == 0)
    ///       .for_each(|(i, x)| println!("{}:{}", i, x));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_for_each", since = "1.21.0")]
    fn for_each<F>(self, f: F)
    where
        Self: Sized,
        F: FnMut(Self::Item),
    {
        #[inline]
        fn call<T>(mut f: impl FnMut(T)) -> impl FnMut((), T) {
            move |(), item| f(item)
        }

        self.fold((), call(f));
    }

    /// Nggawe iterator kang migunakake penutupan kasus kanggo nemtokake yen unsur kudu menehi.
    ///
    /// Yen diwenehi elemen, penutupan kudu ngasilake `true` utawa `false`.Bali iterator bakal mung ngasilaken unsur sing penutupan kasus ngasilake bener.
    ///
    /// # Examples
    ///
    /// Panggunaan dhasar:
    ///
    /// ```
    /// let a = [0i32, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| x.is_positive());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Amarga penutupan liwati kanggo `filter()` njupuk referensi, lan akeh iterators iterate liwat referensi, ndadékaké iki kanggo kahanan bisa bingung, ngendi jinis penutupan kasus minangka referensi pindho:
    ///
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| **x > 1); // perlu loro * s!
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Iku kang umum kanggo tandha yen destructuring ing pitakonan kanggo Strip adoh siji:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&x| *x > 1); // loro&lan *
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// utawa kalorone:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&&x| x > 1); // loro &s
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// saka lapisan iki.
    ///
    /// Elinga yen `iter.filter(f).next()` padha karo `iter.find(f)`.
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter<P>(self, predicate: P) -> Filter<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        Filter::new(self, predicate)
    }

    /// Nggawe iterator sing loro saringan lan peta.
    ///
    /// Bali iterator panenan mung ing: value`s sing penutupan diwenehake ngasilake `Some(value)`.
    ///
    /// `filter_map` bisa digunakake kanggo nggawe rantai [`filter`] lan [`map`] luwih ringkes.
    /// Conto ing ngisor iki nuduhake carane `map().filter().map()` bisa shortened kanggo telpon single kanggo `filter_map`.
    ///
    ///
    /// [`filter`]: Iterator::filter
    /// [`map`]: Iterator::map
    ///
    /// # Examples
    ///
    /// Panggunaan dhasar:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    ///
    /// let mut iter = a.iter().filter_map(|s| s.parse().ok());
    ///
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Punika conto padha, nanging karo [`filter`] lan [`map`]:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    /// let mut iter = a.iter().map(|s| s.parse()).filter(|s| s.is_ok()).map(|s| s.unwrap());
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter_map<B, F>(self, f: F) -> FilterMap<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        FilterMap::new(self, f)
    }

    /// Nggawe iterator kang menehi count pengulangan saiki uga nilai sabanjuré.
    ///
    /// The iterator panenan bali pasangan `(i, val)`, ngendi `i` iku indeks saiki pengulangan lan `val` punika Nilai bali dening iterator ing.
    ///
    ///
    /// `enumerate()` tansah count minangka [`usize`].
    /// Yen sampeyan pengin count dening ongko ukuran beda, fungsi [`zip`] menehi fungsi padha.
    ///
    /// # Tumindake kebanjiran
    ///
    /// Cara kang ora njaga marang overflows, supaya enumerating luwih saka unsur [`usize::MAX`] salah siji mrodhuksi asil salah utawa panics.
    /// Yen pandhedhesan debug sing aktif, a panic dijamin.
    ///
    /// # Panics
    ///
    /// Bali iterator bisa panic yen indeks kanggo-bakal-bali bakal kebanjiran a [`usize`].
    ///
    /// [`usize`]: type@usize
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ['a', 'b', 'c'];
    ///
    /// let mut iter = a.iter().enumerate();
    ///
    /// assert_eq!(iter.next(), Some((0, &'a')));
    /// assert_eq!(iter.next(), Some((1, &'b')));
    /// assert_eq!(iter.next(), Some((2, &'c')));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn enumerate(self) -> Enumerate<Self>
    where
        Self: Sized,
    {
        Enumerate::new(self)
    }

    /// Nggawe iterator kang bisa digunakake [`peek`] dipikir ing unsur sabanjure iterator tanpa akeh iku.
    ///
    /// Nambahake cara [`peek`] menyang iterator.Deleng dokumentasi kanggo informasi luwih lengkap.
    ///
    /// Elinga yen iterator sing ndasari isih maju nalika [`peek`] diarani kaping pisanan: Kanggo njupuk elemen sabanjure, [`next`] diarani iterator sing ndasari, mula ana efek samping (yaiku
    ///
    /// tindakan liyane saka rega Nilai sabanjuré) saka cara [`next`] bakal kelakon.
    ///
    /// [`peek`]: Peekable::peek
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// Panggunaan dhasar:
    ///
    /// ```
    /// let xs = [1, 2, 3];
    ///
    /// let mut iter = xs.iter().peekable();
    ///
    /// // peek() ngijini kita ndeleng menyang future
    /// assert_eq!(iter.peek(), Some(&&1));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), Some(&2));
    ///
    /// // kita bisa peek() kaping pirang-pirang, ing iterator ora bakal advance
    /// assert_eq!(iter.peek(), Some(&&3));
    /// assert_eq!(iter.peek(), Some(&&3));
    ///
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // sawise iterator wis rampung, supaya iku peek()
    /// assert_eq!(iter.peek(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn peekable(self) -> Peekable<Self>
    where
        Self: Sized,
    {
        Peekable::new(self)
    }

    /// Nggawe iterator sing unsur [: skip`] adedasar predikat a.
    ///
    /// [`skip`]: Iterator::skip
    ///
    /// `skip_while()` njupuk panutupan minangka pitakonan.Iku bakal nelpon penutupan kasus iki ing saben unsur iterator, lan ditolak lewat unsur nganti ngasilake `false`.
    ///
    /// Sawise `false` bali, tugas `skip_while()`'s rampung, lan elemen liyane diwenehake.
    ///
    /// # Examples
    ///
    /// Panggunaan dhasar:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Amarga penutupan sing diwenehake menyang `skip_while()` njupuk referensi, lan akeh iterator liwat referensi, iki nyebabake kahanan sing bisa uga mbingungake, ing endi jinis argumen penutupan minangka referensi dobel:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0); // perlu loro * s!
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Nolak sawise `false` dhisikan:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// // nalika iki bakal wis palsu, awit kita wis tak palsu a, skip_while() ora digunakake sembarang liyane
    /////
    /// assert_eq!(iter.next(), Some(&-2));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip_while<P>(self, predicate: P) -> SkipWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        SkipWhile::new(self, predicate)
    }

    /// Nggawe iterator sing ngasilake unsur adhedhasar predikat.
    ///
    /// `take_while()` njupuk panutupan minangka pitakonan.Iku bakal nelpon penutupan kasus iki ing saben unsur iterator, lan ngasilaken unsur nalika ngasilake `true`.
    ///
    /// Sawise `false` wis bali, `take_while()`'s proyek iki liwat, lan liyane saka unsur digatèkaké.
    ///
    /// # Examples
    ///
    /// Panggunaan dhasar:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Amarga penutupan liwati kanggo `take_while()` njupuk referensi, lan akeh iterators iterate liwat referensi, ndadékaké iki kanggo kahanan bisa bingung, ngendi jinis penutupan kasus minangka referensi pindho:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0); // perlu loro * s!
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Nolak sawise `false` dhisikan:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    ///
    /// // We kudu unsur liyane sing kurang saka nul, nanging awit kita wis tak palsu a, take_while() ora digunakake sembarang liyane
    /////
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Amarga `take_while()` kudu ndeleng regane supaya bisa dikatutake utawa ora, sing nganggo iterator bakal weruh manawa dicopot:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<i32> = iter.by_ref()
    ///                            .take_while(|n| **n != 3)
    ///                            .cloned()
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// The `3` ora ono ana, amarga migunakaken supaya weruh yen pengulangan ngirim mungkasi, nanging iki ora diselehake bali menyang iterator ing.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take_while<P>(self, predicate: P) -> TakeWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        TakeWhile::new(self, predicate)
    }

    /// Nggawe iterator sing loro panenan unsur adhedhasar predikat lan peta.
    ///
    /// `map_while()` njupuk penutupan minangka bantahan.
    /// Bakal nelpon panutupan iki ing saben elemen iterator, lan ngasilake elemen nalika ngasilake [`Some(_)`][`Some`].
    ///
    /// # Examples
    ///
    /// Panggunaan dhasar:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter().map_while(|x| 16i32.checked_div(*x));
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Punika conto padha, nanging karo [`take_while`] lan [`map`]:
    ///
    /// [`take_while`]: Iterator::take_while
    /// [`map`]: Iterator::map
    ///
    /// ```
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter()
    ///                 .map(|x| 16i32.checked_div(*x))
    ///                 .take_while(|x| x.is_some())
    ///                 .map(|x| x.unwrap());
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Mandheg sawise [`None`] awal:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [0, 1, 2, -3, 4, 5, -6];
    ///
    /// let iter = a.iter().map_while(|x| u32::try_from(*x).ok());
    /// let vec = iter.collect::<Vec<_>>();
    ///
    /// // We kudu unsur liyane kang bisa pas u32 (4, 5), nanging `map_while` bali `None` kanggo `-3` (minangka `predicate` bali `None`) lan `collect` mandheg ing `None` pisanan pinanggih.
    /////
    /// assert_eq!(vec, vec![0, 1, 2]);
    /// ```
    ///
    /// Amarga `map_while()` perlu kanggo katon ing Nilai supaya weruh yen kudu klebu utawa ora, akeh iterators bakal ndeleng sing lagi dibusak:
    ///
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [1, 2, -3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<u32> = iter.by_ref()
    ///                            .map_while(|n| u32::try_from(*n).ok())
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// `-3` wis ora ana maneh, amarga dikonsumsi kanggo ngerteni yen pengulangan kudu mandheg, nanging ora dilebokake maneh ing iterator.
    ///
    /// Elinga yen ora kaya [`take_while`], iterator iki **ora** nyawiji.
    /// Iku uga ora kasebut apa iterator ngasilake sawise [`None`] pisanan wis bali.
    /// Yen sampeyan perlu nggabungke iterator, nggunakake [`fuse`].
    ///
    /// [`fuse`]: Iterator::fuse
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
    fn map_while<B, P>(self, predicate: P) -> MapWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> Option<B>,
    {
        MapWhile::new(self, predicate)
    }

    /// Nggawe iterator sing ngilangi elemen `n` pisanan.
    ///
    /// Sawise padha wis migunakaken, liyane saka unsur sing menehi.
    /// Luwih saka overriding cara iki langsung, tinimbang ngilangi cara `nth`.
    ///
    /// # Examples
    ///
    /// Panggunaan dhasar:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().skip(2);
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip(self, n: usize) -> Skip<Self>
    where
        Self: Sized,
    {
        Skip::new(self, n)
    }

    /// Nggawe iterator sing panenan unsur `n` menehi kawitan.
    ///
    /// # Examples
    ///
    /// Panggunaan dhasar:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().take(2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `take()` asring digunakake nganggo iterator tanpa wates, supaya bisa diwatesi:
    ///
    /// ```
    /// let mut iter = (0..).take(3);
    ///
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Yen kurang saka unsur `n` kasedhiya, `take` bakal matesi dhewe kanggo ukuran iterator ndasari:
    ///
    ///
    /// ```
    /// let v = vec![1, 2];
    /// let mut iter = v.into_iter().take(5);
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take(self, n: usize) -> Take<Self>
    where
        Self: Sized,
    {
        Take::new(self, n)
    }

    /// Adaptor iterator padha karo [`fold`] sing ngemu internal internal lan ngasilake iterator anyar.
    ///
    /// [`fold`]: Iterator::fold
    ///
    /// `scan()` njupuk loro bantahan: nilai dhisikan kang wiji negara internal, lan panutupan karo loro bantahan, kang pisanan referensi mutable kanggo negara internal lan liya unsur iterator.
    ///
    /// Penutupan kasebut bisa diwenehake menyang negara internal kanggo nuduhake negara ing antarane pengulangan.
    ///
    /// Nalika iterasi, penutupan bakal ditrapake kanggo saben unsur iterator lan nilai bali saka penutupan, [`Option`], diwenehake dening pengulangan.
    ///
    /// # Examples
    ///
    /// Panggunaan dhasar:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().scan(1, |state, &x| {
    ///     // saben pengulangan, kita bakal nikelake negara kanthi unsur
    ///     *state = *state * x;
    ///
    ///     // banjur, kita bakal ngasilake negasi negara kasebut
    ///     Some(-*state)
    /// });
    ///
    /// assert_eq!(iter.next(), Some(-1));
    /// assert_eq!(iter.next(), Some(-2));
    /// assert_eq!(iter.next(), Some(-6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn scan<St, B, F>(self, initial_state: St, f: F) -> Scan<Self, St, F>
    where
        Self: Sized,
        F: FnMut(&mut St, Self::Item) -> Option<B>,
    {
        Scan::new(self, initial_state, f)
    }

    /// Nggawe iterator sing dianggo kaya map, nanging flattens struktur ketik teks utawa.
    ///
    /// The [`map`] adaptor banget migunani, nanging mung nalika pitakonan closure mrodhuksi angka.
    /// Yen ngasilake iterator, bakal ana lapisan iritasi tambahan.
    /// `flat_map()` bakal mbusak lapisan ekstra iki dhewe.
    ///
    /// Sampeyan bisa mikir `flat_map(f)` minangka semantik padha karo [: map`] ping, lan banjur [: flatten`] ing ing `map(f).flatten()`.
    ///
    /// Liyane cara mikir bab `flat_map()`: [: map`] 's closure ngasilake siji item kanggo saben unsur, lan `flat_map()`'s closure ngasilake lan iterator kanggo saben unsur.
    ///
    ///
    /// [`map`]: Iterator::map
    /// [`flatten`]: Iterator::flatten
    ///
    /// # Examples
    ///
    /// Panggunaan dhasar:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() ngasilake lan iterator
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn flat_map<U, F>(self, f: F) -> FlatMap<Self, U, F>
    where
        Self: Sized,
        U: IntoIterator,
        F: FnMut(Self::Item) -> U,
    {
        FlatMap::new(self, f)
    }

    /// Nggawe iterator sing flattens struktur ketik teks utawa.
    ///
    /// Iki migunani nalika sampeyan duwe iterator saka iterators utawa iterator iku sing bisa nguripake menyang iterators lan sing pengin dibusak siji tingkat indirection.
    ///
    ///
    /// # Examples
    ///
    /// Panggunaan dhasar:
    ///
    /// ```
    /// let data = vec![vec![1, 2, 3, 4], vec![5, 6]];
    /// let flattened = data.into_iter().flatten().collect::<Vec<u8>>();
    /// assert_eq!(flattened, &[1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    /// Pemetaan lan banjur flattening:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() ngasilake lan iterator
    /// let merged: String = words.iter()
    ///                           .map(|s| s.chars())
    ///                           .flatten()
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// Sampeyan uga bisa nulis ulang iki kanthi istilah [`flat_map()`], sing luwih disenengi ing kasus iki amarga nerangake maksud sing luwih jelas:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() ngasilake lan iterator
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// Flattening mung mbusak siji level susuh sekaligus:
    ///
    /// ```
    /// let d3 = [[[1, 2], [3, 4]], [[5, 6], [7, 8]]];
    ///
    /// let d2 = d3.iter().flatten().collect::<Vec<_>>();
    /// assert_eq!(d2, [&[1, 2], &[3, 4], &[5, 6], &[7, 8]]);
    ///
    /// let d1 = d3.iter().flatten().flatten().collect::<Vec<_>>();
    /// assert_eq!(d1, [&1, &2, &3, &4, &5, &6, &7, &8]);
    /// ```
    ///
    /// Ing kene kita waca manawa `flatten()` ora nindakake flatten "deep".
    /// Nanging, mung siji level nyarang sing dicopot.Sing, yen sampeyan `flatten()` Uploaded telung dimensi, asil bakal loro-dimensi lan ora siji-dimensi.
    /// Kanggo struktur siji-dimensi, sampeyan kudu `flatten()` maneh.
    ///
    /// [`flat_map()`]: Iterator::flat_map
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_flatten", since = "1.29.0")]
    fn flatten(self) -> Flatten<Self>
    where
        Self: Sized,
        Self::Item: IntoIterator,
    {
        Flatten::new(self)
    }

    /// Nggawe iterator kang ends sawise [`None`] pisanan.
    ///
    /// Sasampunipun iterator ngasilake [`None`], telpon future bisa utawa ora bisa ngasilaken [`Some(T)`] maneh.
    /// `fuse()` adapts lan iterator, njupuk sing sawise [`None`] diwenehi, tansah bakal ngasilake [`None`] salawas-lawase.
    ///
    ///
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// Panggunaan dhasar:
    ///
    /// ```
    /// // iterator sing sulih antara Sawetara lan Ora Ana
    /// struct Alternate {
    ///     state: i32,
    /// }
    ///
    /// impl Iterator for Alternate {
    ///     type Item = i32;
    ///
    ///     fn next(&mut self) -> Option<i32> {
    ///         let val = self.state;
    ///         self.state = self.state + 1;
    ///
    ///         // yen iku malah, Some(i32), liya Ana
    ///         if val % 2 == 0 {
    ///             Some(val)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    ///
    /// let mut iter = Alternate { state: 0 };
    ///
    /// // kita bisa ndeleng kita iterator bali arep lan kasebut
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    ///
    /// // Nanging, yen kita sekring ...
    /// let mut iter = iter.fuse();
    ///
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    ///
    /// // bakal mesthi ngasilake `None` sawise pisanan.
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fuse(self) -> Fuse<Self>
    where
        Self: Sized,
    {
        Fuse::new(self)
    }

    /// Apa karo saben unsur pengulangan, terus regane.
    ///
    /// Nalika nggunakake iterators, sampeyan bakal kerep chain saperangan saka wong-wong mau bebarengan.
    /// Nalika nggarap kode kuwi, sampeyan bisa uga pengin mriksa metu apa kadadosan ing macem-macem bagian ing pipo.Apa sing, masang telpon kanggo `inspect()`.
    ///
    /// Umume `inspect()` digunakake minangka alat debugging tinimbang ana ing kode pungkasan, nanging aplikasi bisa uga migunani ing kahanan tartamtu nalika ana kesalahan sing kudu diangkut sadurunge dibuwang.
    ///
    ///
    /// # Examples
    ///
    /// Panggunaan dhasar:
    ///
    /// ```
    /// let a = [1, 4, 2, 3];
    ///
    /// // urutan iterator iki kompleks.
    /// let sum = a.iter()
    ///     .cloned()
    ///     .filter(|x| x % 2 == 0)
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    ///
    /// // ayo kang nambah sawetara telpon inspect() kanggo neliti apa ta
    /// let sum = a.iter()
    ///     .cloned()
    ///     .inspect(|x| println!("about to filter: {}", x))
    ///     .filter(|x| x % 2 == 0)
    ///     .inspect(|x| println!("made it through filter: {}", x))
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    /// ```
    ///
    /// Iki bakal print:
    ///
    /// ```text
    /// 6
    /// about to filter: 1
    /// about to filter: 4
    /// made it through filter: 4
    /// about to filter: 2
    /// made it through filter: 2
    /// about to filter: 3
    /// 6
    /// ```
    ///
    /// Kesalahan ngangkut barang sadurunge dibuwang:
    ///
    /// ```
    /// let lines = ["1", "2", "a"];
    ///
    /// let sum: i32 = lines
    ///     .iter()
    ///     .map(|line| line.parse::<i32>())
    ///     .inspect(|num| {
    ///         if let Err(ref e) = *num {
    ///             println!("Parsing error: {}", e);
    ///         }
    ///     })
    ///     .filter_map(Result::ok)
    ///     .sum();
    ///
    /// println!("Sum: {}", sum);
    /// ```
    ///
    /// Iki bakal print:
    ///
    /// ```text
    /// Parsing error: invalid digit found in string
    /// Sum: 3
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn inspect<F>(self, f: F) -> Inspect<Self, F>
    where
        Self: Sized,
        F: FnMut(&Self::Item),
    {
        Inspect::new(self, f)
    }

    /// Nyilih iterator, tinimbang dikonsumsi.
    ///
    /// Iki migunani kanggo ngidini ngetrapake adaptor iterator nalika isih duwe kepemilikan pengulangan asli.
    ///
    ///
    /// # Examples
    ///
    /// Panggunaan dhasar:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let iter = a.iter();
    ///
    /// let sum: i32 = iter.take(5).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 6);
    ///
    /// // yen nyoba nggunakake iter maneh, ora bakal bisa digunakake.
    /// // Ing baris ngisor menehi "kesalahan: nggunakake nilai dipindhah: `iter`
    /// // assert_eq!(iter.next(), None);
    ///
    /// // ayo nyoba maneh
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // nanging, kita nambahake .by_ref()
    /// let sum: i32 = iter.by_ref().take(2).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 3);
    ///
    /// // saiki iki mung nggoleki:
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn by_ref(&mut self) -> &mut Self
    where
        Self: Sized,
    {
        self
    }

    /// Ngganti iterator dadi koleksi.
    ///
    /// `collect()` bisa njupuk tindakan iterable, lan nguripake iku menyang koleksi cocog.
    /// Iki minangka salah sawijining metode sing luwih kuat ing perpustakaan standar, sing digunakake ing macem-macem konteks.
    ///
    /// Pola paling dhasar sing digunakake `collect()` yaiku ngowahi siji koleksi dadi liyane.
    /// Sampeyan njupuk koleksi, nelpon [`iter`], nindakake pirang-pirang transformasi, banjur `collect()` ing pungkasan.
    ///
    /// `collect()` uga bisa nggawe kedadean saka jinis-jinis sing ora koleksi khas.
    /// Contone, [`String`] bisa dibangun saka [: char`] s, lan iterator saka [`Result<T, E>`][`Result`] item bisa diklumpukake menyang `Result<Collection<T>, E>`.
    ///
    /// Waca conto ing ngisor iki kanggo liyane.
    ///
    /// Amarga `collect()` umume, bisa nyebabake masalah inferensi jinis.
    /// Nalika kuwi, `collect()` iku salah siji saka sawetara kaping sampeyan bakal weruh ukara affectionately dikenal minangka 'turbofish': `::<>`.
    /// Iki mbantu algoritma inferensi ngerti kanthi khusus koleksi sing pengin dikoleksi.
    ///
    /// # Examples
    ///
    /// Panggunaan dhasar:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled: Vec<i32> = a.iter()
    ///                          .map(|&x| x * 2)
    ///                          .collect();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Elinga yen kita needed ing `: Vec<i32>` ing sisih kiwa-tangan.Iki amarga kita bisa ngumpulake menyang, contone, [`VecDeque<T>`] tinimbang:
    ///
    /// [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let a = [1, 2, 3];
    ///
    /// let doubled: VecDeque<i32> = a.iter().map(|&x| x * 2).collect();
    ///
    /// assert_eq!(2, doubled[0]);
    /// assert_eq!(4, doubled[1]);
    /// assert_eq!(6, doubled[2]);
    /// ```
    ///
    /// Nggunakake 'turbofish' tinimbang nyathet `doubled`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<i32>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Amarga `collect()` mung peduli bab apa sing lagi ngempalaken menyang, sampeyan isih bisa nggunakake jinis Petunjuk sebagean, `_`, karo turbofish ing:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<_>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Nggunakake `collect()` kanggo nggawe [`String`]:
    ///
    /// ```
    /// let chars = ['g', 'd', 'k', 'k', 'n'];
    ///
    /// let hello: String = chars.iter()
    ///     .map(|&x| x as u8)
    ///     .map(|x| (x + 1) as char)
    ///     .collect();
    ///
    /// assert_eq!("hello", hello);
    /// ```
    ///
    /// Yen sampeyan duwe dhaptar [`Hasil<T, E>:][: Result`] s, sampeyan bisa nggunakake `collect()` kanggo ndeleng yen wong gagal:
    ///
    /// ```
    /// let results = [Ok(1), Err("nope"), Ok(3), Err("bad")];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // menehi kesalahan pertama
    /// assert_eq!(Err("nope"), result);
    ///
    /// let results = [Ok(1), Ok(3)];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // menehi dhaptar wangsulan
    /// assert_eq!(Ok(vec![1, 3]), result);
    /// ```
    ///
    /// [`iter`]: Iterator::next
    /// [`String`]: ../../std/string/struct.String.html
    /// [`char`]: type@char
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "if you really need to exhaust the iterator, consider `.for_each(drop)` instead"]
    fn collect<B: FromIterator<Self::Item>>(self) -> B
    where
        Self: Sized,
    {
        FromIterator::from_iter(self)
    }

    /// Nganggo sing iterator, nggawe loro kolèksi saka iku.
    ///
    /// Predikat sing diterusake menyang `partition()` bisa ngasilake `true`, utawa `false`.
    /// `partition()` ngasilake pasangan, kabeh unsur sing bali `true`, lan kabeh unsur sing bali `false`.
    ///
    ///
    /// Deleng uga [`is_partitioned()`] lan [`partition_in_place()`].
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// Panggunaan dhasar:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let (even, odd): (Vec<i32>, Vec<i32>) = a
    ///     .iter()
    ///     .partition(|&n| n % 2 == 0);
    ///
    /// assert_eq!(even, vec![2]);
    /// assert_eq!(odd, vec![1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn partition<B, F>(self, f: F) -> (B, B)
    where
        Self: Sized,
        B: Default + Extend<Self::Item>,
        F: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn extend<'a, T, B: Extend<T>>(
            mut f: impl FnMut(&T) -> bool + 'a,
            left: &'a mut B,
            right: &'a mut B,
        ) -> impl FnMut((), T) + 'a {
            move |(), x| {
                if f(&x) {
                    left.extend_one(x);
                } else {
                    right.extend_one(x);
                }
            }
        }

        let mut left: B = Default::default();
        let mut right: B = Default::default();

        self.fold((), extend(f, &mut left, &mut right));

        (left, right)
    }

    /// Reorders unsur iterator iki *ing-Panggonan* miturut predikat diwenehi, kuwi kabeh sing bali `true` ndhisiki kabeh sing bali `false`.
    ///
    /// Ngasilake nomer unsur `true` ketemu.
    ///
    /// Urutan relatif saka item partitioned ora maintained.
    ///
    /// Deleng uga [`is_partitioned()`] lan [`partition()`].
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition()`]: Iterator::partition
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_partition_in_place)]
    ///
    /// let mut a = [1, 2, 3, 4, 5, 6, 7];
    ///
    /// // Pemisahan ing papan antarane sore lan rintangan
    /// let i = a.iter_mut().partition_in_place(|&n| n % 2 == 0);
    ///
    /// assert_eq!(i, 3);
    /// assert!(a[..i].iter().all(|&n| n % 2 == 0)); // evens
    /// assert!(a[i..].iter().all(|&n| n % 2 == 1)); // odds
    /// ```
    #[unstable(feature = "iter_partition_in_place", reason = "new API", issue = "62543")]
    fn partition_in_place<'a, T: 'a, P>(mut self, ref mut predicate: P) -> usize
    where
        Self: Sized + DoubleEndedIterator<Item = &'a mut T>,
        P: FnMut(&T) -> bool,
    {
        // FIXME: kudu kita padha sumelang ing bab toja count?Cara mung duwe luwih saka
        // `usize::MAX` referensi sing bisa diowahi nganggo ZST, sing ora migunani kanggo pemisahan ...

        // closure fungsi "factory" iki ana supaya genericity ing `Self`.

        #[inline]
        fn is_false<'a, T>(
            predicate: &'a mut impl FnMut(&T) -> bool,
            true_count: &'a mut usize,
        ) -> impl FnMut(&&mut T) -> bool + 'a {
            move |x| {
                let p = predicate(&**x);
                *true_count += p as usize;
                !p
            }
        }

        #[inline]
        fn is_true<T>(predicate: &mut impl FnMut(&T) -> bool) -> impl FnMut(&&mut T) -> bool + '_ {
            move |x| predicate(&**x)
        }

        // Baleni maneh `false` pisanan banjur pertukaran nganggo `true` pungkasan.
        let mut true_count = 0;
        while let Some(head) = self.find(is_false(predicate, &mut true_count)) {
            if let Some(tail) = self.rfind(is_true(predicate)) {
                crate::mem::swap(head, tail);
                true_count += 1;
            } else {
                break;
            }
        }
        true_count
    }

    /// Kir yen unsur iki iterator sing partitioned miturut predikat diwenehi, kuwi kabeh sing bali `true` ndhisiki kabeh sing bali `false`.
    ///
    ///
    /// Deleng uga [`partition()`] lan [`partition_in_place()`].
    ///
    /// [`partition()`]: Iterator::partition
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_is_partitioned)]
    ///
    /// assert!("Iterator".chars().is_partitioned(char::is_uppercase));
    /// assert!(!"IntoIterator".chars().is_partitioned(char::is_uppercase));
    /// ```
    #[unstable(feature = "iter_is_partitioned", reason = "new API", issue = "62544")]
    fn is_partitioned<P>(mut self, mut predicate: P) -> bool
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        // Salah siji item tes `true`, utawa klausa pertama mandheg ing `false` lan priksa manawa ora ana item `true` sawise iku.
        //
        self.all(&mut predicate) || !self.any(predicate)
    }

    /// Lan cara iterator sing ditrapake fungsi anggere ngasilake kasil, ngasilaken, Nilai final siji.
    ///
    /// `try_fold()` njupuk loro bantahan: nilai dhisikan, lan panutupan karo loro bantahan: lan 'accumulator', lan unsur.
    /// Penutupan bisa ngasilake kanthi sukses, kanthi nilai sing kudu ana akumulator kanggo pengulangan sabanjure, utawa ngasilake kegagalan, kanthi nilai kesalahan sing disebar maneh menyang panelpon langsung (short-circuiting).
    ///
    ///
    /// Nilai dhisikan punika Nilai accumulator bakal ing telpon pisanan.Yen ngetrapake penutupan sukses tumrap saben unsur iterator, `try_fold()` ngasilake akumulator pungkasan dadi sukses.
    ///
    /// Lempitan migunani kapan duwe koleksi soko, lan pengin kanggo gawé Nilai siji saka iku.
    ///
    /// # Cathetan kanggo Pelaksana
    ///
    /// Sawetara cara (forward) liyane duwe implementasine gawan ing syarat-syarat sing iki, dadi coba coba coba eksplisit manawa bisa nindakake sing luwih apik tinimbang implementasi loop `for` default.
    ///
    /// Ing tartamtu, nyoba kanggo duwe telpon iki `try_fold()` ing bagean internal saka kang iterator iki dumadi.
    /// Yen sawetara telpon sing perlu, ing operator `?` uga trep kanggo chaining Nilai accumulator bebarengan, nanging ngati-ati invariants sembarang sing perlu ayating sadurunge sing ngasilake awal.
    /// Iki minangka cara `&mut self`, dadi pengulangan kudu ditrapake maneh sawise tekan kesalahan ing kene.
    ///
    /// # Examples
    ///
    /// Panggunaan dhasar:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // jumlah sing dicenthang kanggo kabeh unsur larik
    /// let sum = a.iter().try_fold(0i8, |acc, &x| acc.checked_add(x));
    ///
    /// assert_eq!(sum, Some(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = [10, 20, 30, 100, 40, 50];
    /// let mut it = a.iter();
    ///
    /// // jumlah iki overflows nalika nambah 100 unsur
    /// let sum = it.try_fold(0i8, |acc, &x| acc.checked_add(x));
    /// assert_eq!(sum, None);
    ///
    /// // Amarga sirkulasi singkat, elemen sing isih ana isih kasedhiya liwat iterator.
    /////
    /// assert_eq!(it.len(), 2);
    /// assert_eq!(it.next(), Some(&40));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// Lan cara iterator sing ditrapake fungsi fallible kanggo saben item ing iterator ing, sing nolak ing kesalahan pisanan lan bali kesalahan sing.
    ///
    ///
    /// Iki uga bisa dianggep minangka wujud [`for_each()`] sing bisa ditemokake utawa minangka versi [`try_fold()`] sing ora ana statuse.
    ///
    /// [`for_each()`]: Iterator::for_each
    /// [`try_fold()`]: Iterator::try_fold
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fs::rename;
    /// use std::io::{stdout, Write};
    /// use std::path::Path;
    ///
    /// let data = ["no_tea.txt", "stale_bread.json", "torrential_rain.png"];
    ///
    /// let res = data.iter().try_for_each(|x| writeln!(stdout(), "{}", x));
    /// assert!(res.is_ok());
    ///
    /// let mut it = data.iter().cloned();
    /// let res = it.try_for_each(|x| rename(x, Path::new(x).with_extension("old")));
    /// assert!(res.is_err());
    /// // Iku short-circuited, supaya item isih isih ing iterator ing:
    /// assert_eq!(it.next(), Some("stale_bread.json"));
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_for_each<F, R>(&mut self, f: F) -> R
    where
        Self: Sized,
        F: FnMut(Self::Item) -> R,
        R: Try<Ok = ()>,
    {
        #[inline]
        fn call<T, R>(mut f: impl FnMut(T) -> R) -> impl FnMut((), T) -> R {
            move |(), x| f(x)
        }

        self.try_fold((), call(f))
    }

    /// Pambungkus saben unsur menyang accumulator dening nglamar operasi, bali asil Final.
    ///
    /// `fold()` njupuk loro bantahan: nilai dhisikan, lan panutupan karo loro bantahan: lan 'accumulator', lan unsur.
    /// penutupan kasus ngasilake angka sing accumulator kudu kanggo pengulangan sabanjuré.
    ///
    /// Nilai dhisikan punika Nilai accumulator bakal ing telpon pisanan.
    ///
    /// Sawise nglamar penutupan kasus iki kanggo saben unsur iterator ing, `fold()` ngasilake accumulator ing.
    ///
    /// operasi iki kadhangkala disebut 'reduce' utawa 'inject'.
    ///
    /// Lempitan migunani kapan duwe koleksi soko, lan pengin kanggo gawé Nilai siji saka iku.
    ///
    /// Note: `fold()`, lan cara sing padha ngliwati kabeh iterator, uga ora siksa kanggo iterators tanpa wates, malah ing traits sing asil punika determinable ing wektu ono wates.
    ///
    /// Note: [`reduce()`] bisa digunakake kanggo nggunakake elemen pisanan minangka nilai awal, yen jinis akumulator lan jinis barang padha.
    ///
    /// # Cathetan kanggo Pelaksana
    ///
    /// Sawetara cara (forward) liyane duwe implementasine gawan ing syarat-syarat sing iki, dadi coba coba coba eksplisit manawa bisa nindakake sing luwih apik tinimbang implementasi loop `for` default.
    ///
    ///
    /// Ing tartamtu, nyoba kanggo duwe telpon iki `fold()` ing bagean internal saka kang iterator iki dumadi.
    ///
    /// # Examples
    ///
    /// Panggunaan dhasar:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // jumlah kabeh unsur larik
    /// let sum = a.iter().fold(0, |acc, x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// Ayo mate liwat saben langkah pengulangan kene:
    ///
    /// | element | acc | x | result |
    /// |---------|-----|---|--------|
    /// |         | 0   |   |        |
    /// | 1       | 0   | 1 | 1      |
    /// | 2       | 1   | 2 | 3      |
    /// | 3       | 3   | 3 | 6      |
    ///
    /// Lan, asil Final kita, `6`.
    ///
    /// Iku kang umum kanggo wong sing wis ora digunakake iterators kathah nggunakake daur ulang `for` karo dhaftar panjarwa iku kanggo mbangun munggah asil.Sing bisa nguripake menyang `fold()`s:
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let mut result = 0;
    ///
    /// // kanggo daur ulang:
    /// for i in &numbers {
    ///     result = result + i;
    /// }
    ///
    /// // fold:
    /// let result2 = numbers.iter().fold(0, |acc, &x| acc + x);
    ///
    /// // lagi padha
    /// assert_eq!(result, result2);
    /// ```
    ///
    /// [`reduce()`]: Iterator::reduce
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[doc(alias = "reduce")]
    #[doc(alias = "inject")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x);
        }
        accum
    }

    /// Nyuda unsur kanggo siji, kanthi kaping nglamar operasi ngurangi.
    ///
    /// Yen iterator kosong, ngasilake [`None`];digunakake, ngasilake asil saka abang ing.
    ///
    /// Kanggo iterators ing paling siji unsur, iki padha [`fold()`] karo unsur pisanan saka iterator minangka dhisikan Nilai, lempitan saben unsur sakteruse menyang iku.
    ///
    ///
    /// [`fold()`]: Iterator::fold
    ///
    /// # Example
    ///
    /// Golek Nilai maksimum:
    ///
    /// ```
    /// fn find_max<I>(iter: I) -> Option<I::Item>
    ///     where I: Iterator,
    ///           I::Item: Ord,
    /// {
    ///     iter.reduce(|a, b| {
    ///         if a >= b { a } else { b }
    ///     })
    /// }
    /// let a = [10, 20, 5, -23, 0];
    /// let b: [u32; 0] = [];
    ///
    /// assert_eq!(find_max(a.iter()), Some(&20));
    /// assert_eq!(find_max(b.iter()), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_fold_self", since = "1.51.0")]
    fn reduce<F>(mut self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(Self::Item, Self::Item) -> Self::Item,
    {
        let first = self.next()?;
        Some(self.fold(first, f))
    }

    /// Tes yen saben unsur iterator cocog predikat a.
    ///
    /// `all()` njupuk panutupan sing ngasilake `true` utawa `false`.Iku ditrapake penutupan kasus iki kanggo saben unsur iterator, lan kabeh padha bali `true`, banjur dadi ora `all()`.
    /// Yen wong bali `false`, ngasilake `false`.
    ///
    /// `all()` yaiku sirkuit cendhak;ing tembung liyane, iku bakal mungkasi Processing sanalika iku ketemu `false`, diwenehi sing ana prakara apa liya mengkono, asil uga bakal `false`.
    ///
    ///
    /// Pengulangan kosong ngasilake `true`.
    ///
    /// # Examples
    ///
    /// Panggunaan dhasar:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().all(|&x| x > 0));
    ///
    /// assert!(!a.iter().all(|&x| x > 2));
    /// ```
    ///
    /// Mandheg `false` pisanan:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(!iter.all(|&x| x != 2));
    ///
    /// // kita isih bisa nggunakake `iter`, amarga ana elemen liyane.
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    ///
    ///
    #[doc(alias = "every")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn all<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::CONTINUE } else { ControlFlow::BREAK }
            }
        }
        self.try_fold((), check(f)) == ControlFlow::CONTINUE
    }

    /// Tes yen unsur iterator cocog predikat a.
    ///
    /// `any()` njupuk penutupan sing ngasilake `true` utawa `false`.Iki ditrapake kanggo saben unsur iterator, lan yen ana `true` sing bali, mula uga `any()`.
    /// Yen kabeh bali `false`, ngasilake `false`.
    ///
    /// `any()` cendhak-circuiting;ing tembung liyane, iku bakal mungkasi Processing sanalika iku ketemu `true`, diwenehi sing ana prakara apa liya mengkono, asil uga bakal `true`.
    ///
    ///
    /// Pengulangan kosong ngasilake `false`.
    ///
    /// # Examples
    ///
    /// Panggunaan dhasar:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().any(|&x| x > 0));
    ///
    /// assert!(!a.iter().any(|&x| x > 5));
    /// ```
    ///
    /// Mandheg `true` pisanan:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(iter.any(|&x| x != 2));
    ///
    /// // kita isih bisa nggunakake `iter`, amarga ana elemen liyane.
    /// assert_eq!(iter.next(), Some(&2));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn any<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::BREAK } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(f)) == ControlFlow::BREAK
    }

    /// Nggoleki unsur pengulangan sing nyenengake predikat.
    ///
    /// `find()` njupuk penutupan sing ngasilake `true` utawa `false`.
    /// Iku ditrapake penutupan kasus iki kanggo saben unsur iterator, lan yen wong bali `true`, banjur `find()` ngasilake [`Some(element)`].
    /// Yen kabeh bali `false`, ngasilake [`None`].
    ///
    /// `find()` cendhak-circuiting;ing tembung liyane, iku bakal mungkasi Processing sanalika penutupan kasus ngasilake `true`.
    ///
    /// Amarga `find()` njupuk referensi, lan akeh iterators iterate liwat referensi, ndadékaké iki kanggo kahanan bisa bingung ngendi pitakonan kuwi referensi pindho.
    ///
    /// Sampeyan bisa ndeleng efek iki ing conto ing ngisor iki, kanthi `&&x`.
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// Panggunaan dhasar:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 5), None);
    /// ```
    ///
    /// Mandheg `true` pisanan:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.find(|&&x| x == 2), Some(&2));
    ///
    /// // kita isih bisa nggunakake `iter`, amarga ana elemen liyane.
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    /// Elinga yen `iter.find(f)` padha karo `iter.filter(f).next()`.
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn find<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(predicate)).break_value()
    }

    /// Ditrapake kanggo unsur iterator lan ngasilake asil sing dudu pisanan.
    ///
    ///
    /// `iter.find_map(f)` padha karo `iter.filter_map(f).next()`.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ["lol", "NaN", "2", "5"];
    ///
    /// let first_number = a.iter().find_map(|s| s.parse().ok());
    ///
    /// assert_eq!(first_number, Some(2));
    /// ```
    #[inline]
    #[stable(feature = "iterator_find_map", since = "1.30.0")]
    fn find_map<B, F>(&mut self, f: F) -> Option<B>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        #[inline]
        fn check<T, B>(mut f: impl FnMut(T) -> Option<B>) -> impl FnMut((), T) -> ControlFlow<B> {
            move |(), x| match f(x) {
                Some(x) => ControlFlow::Break(x),
                None => ControlFlow::CONTINUE,
            }
        }

        self.try_fold((), check(f)).break_value()
    }

    /// Nèng saubenging fungsi kanggo unsur iterator lan ngasilake asil sejati utawa kesalahan pisanan.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_find)]
    ///
    /// let a = ["1", "2", "lol", "NaN", "5"];
    ///
    /// let is_my_num = |s: &str, search: i32| -> Result<bool, std::num::ParseIntError> {
    ///     Ok(s.parse::<i32>()?  == search)
    /// };
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 2));
    /// assert_eq!(result, Ok(Some(&"2")));
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 5));
    /// assert!(result.is_err());
    /// ```
    #[inline]
    #[unstable(feature = "try_find", reason = "new API", issue = "63178")]
    fn try_find<F, R>(&mut self, f: F) -> Result<Option<Self::Item>, R::Error>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> R,
        R: Try<Ok = bool>,
    {
        #[inline]
        fn check<F, T, R>(mut f: F) -> impl FnMut((), T) -> ControlFlow<Result<T, R::Error>>
        where
            F: FnMut(&T) -> R,
            R: Try<Ok = bool>,
        {
            move |(), x| match f(&x).into_result() {
                Ok(false) => ControlFlow::CONTINUE,
                Ok(true) => ControlFlow::Break(Ok(x)),
                Err(x) => ControlFlow::Break(Err(x)),
            }
        }

        self.try_fold((), check(f)).break_value().transpose()
    }

    /// Searches kanggo unsur ing iterator, bali index.
    ///
    /// `position()` njupuk penutupan sing ngasilake `true` utawa `false`.
    /// Iki ditrapake kanggo saben elemen iterator, lan yen salah sawijine ngasilake `true`, mula `position()` ngasilake [`Some(index)`].
    /// Yen kabeh ngasilake `false`, [`None`] bakal ngasilake.
    ///
    /// `position()` cendhak-circuiting;kanthi tembung liya, bakal mandheg ngolah sanalika nemokake `true`.
    ///
    /// # Tumindake kebanjiran
    ///
    /// Cara kasebut ora bisa ngindhari kebanjiran, mula yen ana luwih saka [`usize::MAX`] unsur sing ora cocog, bisa uga ngasilake asil sing salah utawa panics.
    ///
    /// Yen pandhedhesan debug sing aktif, a panic dijamin.
    ///
    /// # Panics
    ///
    /// Fungsi iki bisa uga panic yen iterator wis luwih saka unsur non-cocog `usize::MAX`.
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// Panggunaan dhasar:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().position(|&x| x == 2), Some(1));
    ///
    /// assert_eq!(a.iter().position(|&x| x == 5), None);
    /// ```
    ///
    /// Mandheg `true` pisanan:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.position(|&x| x >= 2), Some(1));
    ///
    /// // kita isih bisa nggunakake `iter`, amarga ana elemen liyane.
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // Indeks sing dibalekake gumantung ing negara pengulangan
    /// assert_eq!(iter.position(|&x| x == 4), Some(0));
    ///
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn position<P>(&mut self, predicate: P) -> Option<usize>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            #[rustc_inherit_overflow_checks]
            move |i, x| {
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i + 1) }
            }
        }

        self.try_fold(0, check(predicate)).break_value()
    }

    /// Nggoleki elemen ing iterator saka sisih tengen, ngasilake indeks kasebut.
    ///
    /// `rposition()` njupuk penutupan sing ngasilake `true` utawa `false`.
    /// Iki ditrapake kanggo saben elemen iterator, diwiwiti saka pungkasan, lan yen salah sawijine ngasilake `true`, mula `rposition()` ngasilake [`Some(index)`].
    ///
    /// Yen kabeh ngasilake `false`, [`None`] bakal ngasilake.
    ///
    /// `rposition()` cendhak-circuiting;kanthi tembung liya, bakal mandheg ngolah sanalika nemokake `true`.
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// Panggunaan dhasar:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 3), Some(2));
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 5), None);
    /// ```
    ///
    /// Mandheg `true` pisanan:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rposition(|&x| x == 2), Some(1));
    ///
    /// // kita isih bisa nggunakake `iter`, amarga ana elemen liyane.
    /// assert_eq!(iter.next(), Some(&1));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rposition<P>(&mut self, predicate: P) -> Option<usize>
    where
        P: FnMut(Self::Item) -> bool,
        Self: Sized + ExactSizeIterator + DoubleEndedIterator,
    {
        // Ora prelu mriksa kebanjiran ing kene, amarga `ExactSizeIterator` tegese jumlah unsur cocog karo `usize`.
        //
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            move |i, x| {
                let i = i - 1;
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i) }
            }
        }

        let n = self.len();
        self.try_rfold(n, check(predicate)).break_value()
    }

    /// Ngasilake unsur maksimum saka iterator.
    ///
    /// Yen sawetara unsur merata maksimum, unsur pungkasan wis bali.
    /// Yen iterator kosong, [`None`] bakal bali.
    ///
    /// # Examples
    ///
    /// Panggunaan dhasar:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().max(), Some(&3));
    /// assert_eq!(b.iter().max(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn max(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.max_by(Ord::cmp)
    }

    /// Ngasilake elemen minimal iterator.
    ///
    /// Yen sawetara elemen padha minimal, elemen pisanan bakal bali.
    /// Yen iterator kosong, [`None`] bakal bali.
    ///
    /// # Examples
    ///
    /// Panggunaan dhasar:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().min(), Some(&1));
    /// assert_eq!(b.iter().min(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn min(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.min_by(Ord::cmp)
    }

    /// Ngasilake unsur sing menehi nilai maksimum saka fungsi kasebut.
    ///
    ///
    /// Yen sawetara unsur merata maksimum, unsur pungkasan wis bali.
    /// Yen iterator kosong, [`None`] bakal bali.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by_key(|x| x.abs()).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn max_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).max_by(compare)?;
        Some(x)
    }

    /// Ngasilake unsur sing menehi nilai maksimum bab fungsi comparison kasebut.
    ///
    ///
    /// Yen sawetara unsur merata maksimum, unsur pungkasan wis bali.
    /// Yen iterator kosong, [`None`] bakal bali.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by(|x, y| x.cmp(y)).unwrap(), 5);
    /// ```
    #[inline]
    #[stable(feature = "iter_max_by", since = "1.15.0")]
    fn max_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::max_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// Ngasilake elemen sing menehi nilai minimal saka fungsi sing ditemtokake.
    ///
    ///
    /// Yen sawetara elemen padha minimal, elemen pisanan bakal bali.
    /// Yen iterator kosong, [`None`] bakal bali.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by_key(|x| x.abs()).unwrap(), 0);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn min_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).min_by(compare)?;
        Some(x)
    }

    /// Ngasilake elemen sing menehi nilai minimal babagan fungsi perbandingan sing ditemtokake.
    ///
    ///
    /// Yen sawetara elemen padha minimal, elemen pisanan bakal bali.
    /// Yen iterator kosong, [`None`] bakal bali.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by(|x, y| x.cmp(y)).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_min_by", since = "1.15.0")]
    fn min_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::min_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// Reverses arah lan iterator kang.
    ///
    /// Biasane, iterators iterate saka kiwa menyang tengen.
    /// Sawise nggunakake `rev()`, lan iterator bakal tinimbang iterate saka tengen ngiwa.
    ///
    /// Iki mung bisa yen iterator wis mburi, supaya `rev()` mung dianggo ing [: DoubleEndedIterator`] s.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().rev();
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[doc(alias = "reverse")]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rev(self) -> Rev<Self>
    where
        Self: Sized + DoubleEndedIterator,
    {
        Rev::new(self)
    }

    /// Ngowahi lan iterator pasangan menyang Pasangan kontaner.
    ///
    /// `unzip()` nganggo kabeh iterator pasangan, prodhuksi loro kolèksi: salah siji saka unsur kiwa pasangan, lan salah siji saka unsur tengen.
    ///
    ///
    /// Fungsi kasebut, ing sawetara pangertene, ngelawan [`zip`].
    ///
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// Panggunaan dhasar:
    ///
    /// ```
    /// let a = [(1, 2), (3, 4)];
    ///
    /// let (left, right): (Vec<_>, Vec<_>) = a.iter().cloned().unzip();
    ///
    /// assert_eq!(left, [1, 3]);
    /// assert_eq!(right, [2, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn unzip<A, B, FromA, FromB>(self) -> (FromA, FromB)
    where
        FromA: Default + Extend<A>,
        FromB: Default + Extend<B>,
        Self: Sized + Iterator<Item = (A, B)>,
    {
        fn extend<'a, A, B>(
            ts: &'a mut impl Extend<A>,
            us: &'a mut impl Extend<B>,
        ) -> impl FnMut((), (A, B)) + 'a {
            move |(), (t, u)| {
                ts.extend_one(t);
                us.extend_one(u);
            }
        }

        let mut ts: FromA = Default::default();
        let mut us: FromB = Default::default();

        let (lower_bound, _) = self.size_hint();
        if lower_bound > 0 {
            ts.extend_reserve(lower_bound);
            us.extend_reserve(lower_bound);
        }

        self.fold((), extend(&mut ts, &mut us));

        (ts, us)
    }

    /// Nggawe iterator sing nyalin kabeh elemene.
    ///
    /// Iki migunani nalika sampeyan duwe iterator liwat `&T`, nanging sampeyan perlu iterator liwat `T`.
    ///
    ///
    /// # Examples
    ///
    /// Panggunaan dhasar:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_copied: Vec<_> = a.iter().copied().collect();
    ///
    /// // sing disalin padha karo .map(|&x| x)
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_copied, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "iter_copied", since = "1.36.0")]
    fn copied<'a, T: 'a>(self) -> Copied<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Copy,
    {
        Copied::new(self)
    }

    /// Nggawe iterator kang [: clone`] s kabeh sawijining unsur.
    ///
    /// Iki migunani nalika sampeyan duwe iterator liwat `&T`, nanging sampeyan perlu iterator liwat `T`.
    ///
    ///
    /// [`clone`]: Clone::clone
    ///
    /// # Examples
    ///
    /// Panggunaan dhasar:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_cloned: Vec<_> = a.iter().cloned().collect();
    ///
    /// // kloning padha .map(|&x| x), kanggo wilangan bulat
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_cloned, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn cloned<'a, T: 'a>(self) -> Cloned<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Clone,
    {
        Cloned::new(self)
    }

    /// Baleni pengulangan tanpa wates.
    ///
    /// Tinimbang nolak ing [`None`], iterator tinimbang bakal miwiti maneh, saka awal.Sawise mbaleni maneh, iku bakal miwiti ing awal maneh.Lan maneh.
    /// Lan maneh.
    /// Forever.
    ///
    /// # Examples
    ///
    /// Panggunaan dhasar:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut it = a.iter().cycle();
    ///
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    fn cycle(self) -> Cycle<Self>
    where
        Self: Sized + Clone,
    {
        Cycle::new(self)
    }

    /// Cacah unsur saka iterator.
    ///
    /// Milih saben elemen, ditambahake bebarengan, lan ngasilake asil.
    ///
    /// Pengulangan kosong ngasilake angka nol jinis kasebut.
    ///
    /// # Panics
    ///
    /// Nalika nelpon `sum()` lan jinis ongko primitif lagi bali, cara iki bakal panic yen overflows komputasi lan pandhedhesan debug sing aktif.
    ///
    ///
    /// # Examples
    ///
    /// Panggunaan dhasar:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let sum: i32 = a.iter().sum();
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn sum<S>(self) -> S
    where
        Self: Sized,
        S: Sum<Self::Item>,
    {
        Sum::sum(self)
    }

    /// Iterates liwat kabeh iterator, tikel kabeh elemen
    ///
    /// Lan iterator P ngasilake siji Nilai saka jinis.
    ///
    /// # Panics
    ///
    /// Nalika nelpon `product()` lan jinis ongko primitif lagi bali, cara bakal panic yen overflows komputasi lan pandhedhesan debug sing aktif.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// fn factorial(n: u32) -> u32 {
    ///     (1..=n).product()
    /// }
    /// assert_eq!(factorial(0), 1);
    /// assert_eq!(factorial(1), 1);
    /// assert_eq!(factorial(5), 120);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn product<P>(self) -> P
    where
        Self: Sized,
        P: Product<Self::Item>,
    {
        Product::product(self)
    }

    /// [Lexicographically](Ord#lexicographical-comparison) mbandhingake unsur [`Iterator`] iki karo liyane.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1].iter().cmp([1].iter()), Ordering::Equal);
    /// assert_eq!([1].iter().cmp([1, 2].iter()), Ordering::Less);
    /// assert_eq!([1, 2].iter().cmp([1].iter()), Ordering::Greater);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn cmp<I>(self, other: I) -> Ordering
    where
        I: IntoIterator<Item = Self::Item>,
        Self::Item: Ord,
        Self: Sized,
    {
        self.cmp_by(other, |x, y| x.cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) bandingke unsur [`Iterator`] iki karo sing liyane bab fungsi comparison kasebut.
    ///
    ///
    /// # Examples
    ///
    /// Panggunaan dhasar:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| x.cmp(&y)), Ordering::Less);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (x * x).cmp(&y)), Ordering::Equal);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (2 * x).cmp(&y)), Ordering::Greater);
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn cmp_by<I, F>(mut self, other: I, mut cmp: F) -> Ordering
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Ordering,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Ordering::Equal;
                    } else {
                        return Ordering::Less;
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Ordering::Greater,
                Some(val) => val,
            };

            match cmp(x, y) {
                Ordering::Equal => (),
                non_eq => return non_eq,
            }
        }
    }

    /// [Lexicographically](Ord#lexicographical-comparison) mbandhingake unsur [`Iterator`] iki karo liyane.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1.].iter().partial_cmp([1.].iter()), Some(Ordering::Equal));
    /// assert_eq!([1.].iter().partial_cmp([1., 2.].iter()), Some(Ordering::Less));
    /// assert_eq!([1., 2.].iter().partial_cmp([1.].iter()), Some(Ordering::Greater));
    ///
    /// assert_eq!([f64::NAN].iter().partial_cmp([1.].iter()), None);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn partial_cmp<I>(self, other: I) -> Option<Ordering>
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp_by(other, |x, y| x.partial_cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) bandingke unsur [`Iterator`] iki karo sing liyane bab fungsi comparison kasebut.
    ///
    ///
    /// # Examples
    ///
    /// Panggunaan dhasar:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1.0, 2.0, 3.0, 4.0];
    /// let ys = [1.0, 4.0, 9.0, 16.0];
    ///
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| x.partial_cmp(&y)),
    ///     Some(Ordering::Less)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (x * x).partial_cmp(&y)),
    ///     Some(Ordering::Equal)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (2.0 * x).partial_cmp(&y)),
    ///     Some(Ordering::Greater)
    /// );
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn partial_cmp_by<I, F>(mut self, other: I, mut partial_cmp: F) -> Option<Ordering>
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Option<Ordering>,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Some(Ordering::Equal);
                    } else {
                        return Some(Ordering::Less);
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Some(Ordering::Greater),
                Some(val) => val,
            };

            match partial_cmp(x, y) {
                Some(Ordering::Equal) => (),
                non_eq => return non_eq,
            }
        }
    }

    /// Nemtokake manawa unsur [`Iterator`] iki biasané padha karo sing saka liyane.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().eq([1].iter()), true);
    /// assert_eq!([1].iter().eq([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn eq<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        self.eq_by(other, |x, y| x == y)
    }

    /// Nemtokake manawa unsur [`Iterator`] iki biasané padha karo sing saka liyane bab fungsi podo kasebut.
    ///
    ///
    /// # Examples
    ///
    /// Panggunaan dhasar:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert!(xs.iter().eq_by(&ys, |&x, &y| x * x == y));
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn eq_by<I, F>(mut self, other: I, mut eq: F) -> bool
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> bool,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => return other.next().is_none(),
                Some(val) => val,
            };

            let y = match other.next() {
                None => return false,
                Some(val) => val,
            };

            if !eq(x, y) {
                return false;
            }
        }
    }

    /// Nemtokake manawa unsur [`Iterator`] iki unequal kanggo sing liyane.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ne([1].iter()), false);
    /// assert_eq!([1].iter().ne([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ne<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        !self.eq(other)
    }

    /// Nemtokake manawa unsur [`Iterator`] iki [lexicographically](Ord#lexicographical-comparison) kurang saka sing liyane.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().lt([1].iter()), false);
    /// assert_eq!([1].iter().lt([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().lt([1].iter()), false);
    /// assert_eq!([1, 2].iter().lt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn lt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Less)
    }

    /// Nemtokake manawa unsur [`Iterator`] iki [lexicographically](Ord#lexicographical-comparison) kurang utawa witjaksono kanggo sing liyane.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().le([1].iter()), true);
    /// assert_eq!([1].iter().le([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().le([1].iter()), false);
    /// assert_eq!([1, 2].iter().le([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn le<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Less | Ordering::Equal))
    }

    /// Nemtokake manawa unsur [`Iterator`] iki [lexicographically](Ord#lexicographical-comparison) luwih gedhe tinimbang sing liyane.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().gt([1].iter()), false);
    /// assert_eq!([1].iter().gt([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().gt([1].iter()), true);
    /// assert_eq!([1, 2].iter().gt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn gt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Greater)
    }

    /// Nemtokake manawa unsur [`Iterator`] iki [lexicographically](Ord#lexicographical-comparison) luwih saka utawa witjaksono kanggo sing liyane.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ge([1].iter()), true);
    /// assert_eq!([1].iter().ge([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().ge([1].iter()), true);
    /// assert_eq!([1, 2].iter().ge([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ge<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Greater | Ordering::Equal))
    }

    /// Priksa manawa unsur iterator iki diurutake.
    ///
    /// Sing, kanggo saben unsur `a` lan unsur sawijining ngisor `b`, `a <= b` kudu terus.Yen iterator ngasilake persis nol utawa siji elemen, `true` bakal bali.
    ///
    /// Wigati yen `Self::Item` mung `PartialOrd`, nanging ora `Ord`, definisi ing ndhuwur nggadahi sing fungsi iki ngasilake `false` yen ragam consecutive ora iso dibandhingke.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted());
    /// assert!(![1, 3, 2, 4].iter().is_sorted());
    /// assert!([0].iter().is_sorted());
    /// assert!(std::iter::empty::<i32>().is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted(self) -> bool
    where
        Self: Sized,
        Self::Item: PartialOrd,
    {
        self.is_sorted_by(PartialOrd::partial_cmp)
    }

    /// Kir yen unsur iterator iki sing diurutake nggunakake fungsi comparator diwenehi.
    ///
    /// Tinimbang nggunakake `PartialOrd::partial_cmp`, fungsi iki nggunakake fungsi `compare` sing diwenehake kanggo nemtokake urutan rong elemen.
    /// Loro saka, iku padha karo kanggo [`is_sorted`];deleng dokumentasi kanggo informasi luwih lengkap.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![1, 3, 2, 4].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!([0].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(std::iter::empty::<i32>().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// ```
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by<F>(mut self, compare: F) -> bool
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Option<Ordering>,
    {
        #[inline]
        fn check<'a, T>(
            last: &'a mut T,
            mut compare: impl FnMut(&T, &T) -> Option<Ordering> + 'a,
        ) -> impl FnMut(T) -> bool + 'a {
            move |curr| {
                if let Some(Ordering::Greater) | None = compare(&last, &curr) {
                    return false;
                }
                *last = curr;
                true
            }
        }

        let mut last = match self.next() {
            Some(e) => e,
            None => return true,
        };

        self.all(check(&mut last, compare))
    }

    /// Kir yen unsur iterator iki sing diurutake nggunakake fungsi extraction tombol tartamtu.
    ///
    /// Tinimbang mbandingaken unsur iterator langsung, fungsi iki bandingke tombol ing unsur, minangka ditemtokake dening `f`.
    /// Loro saka, iku padha karo kanggo [`is_sorted`];deleng dokumentasi kanggo informasi luwih lengkap.
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].iter().is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].iter().is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by_key<F, K>(self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> K,
        K: PartialOrd,
    {
        self.map(f).is_sorted()
    }

    /// Waca [TrustedRandomAccess]
    // Jeneng mboten umum supaya tabrakan jeneng resolusi cara ndeleng #76479.
    //
    #[inline]
    #[doc(hidden)]
    #[unstable(feature = "trusted_random_access", issue = "none")]
    unsafe fn __iterator_get_unchecked(&mut self, _idx: usize) -> Self::Item
    where
        Self: TrustedRandomAccess,
    {
        unreachable!("Always specialized");
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator + ?Sized> Iterator for &mut I {
    type Item = I::Item;
    fn next(&mut self) -> Option<I::Item> {
        (**self).next()
    }
    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_by(n)
    }
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        (**self).nth(n)
    }
}