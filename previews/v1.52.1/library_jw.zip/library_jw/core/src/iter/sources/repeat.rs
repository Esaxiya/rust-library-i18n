use crate::iter::{FusedIterator, TrustedLen};

/// Nggawe iterator anyar sing endlessly mbaleni unsur siji.
///
/// Fungsi `repeat()` mbaleni Nilai siji liwat lan liwat maneh.
///
/// iterators tanpa wates kaya `repeat()` asring digunakake karo adaptor kaya [`Iterator::take()`], supaya wong-wong mau ono wates.
///
/// Yen jinis unsur saka iterator sampeyan kudu ora ngleksanakake `Clone`, utawa yen ora pengin tetep unsur bola ing memori, sampeyan tinimbang bisa nggunakake fungsi [`repeat_with()`].
///
///
/// [`repeat_with()`]: crate::iter::repeat_with
///
/// # Examples
///
/// Panggunaan dhasar:
///
/// ```
/// use std::iter;
///
/// // nomer papat 4ever:
/// let mut fours = iter::repeat(4);
///
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
///
/// // yup, Patang
/// assert_eq!(Some(4), fours.next());
/// ```
///
/// Bakal winates karo [`Iterator::take()`]:
///
/// ```
/// use std::iter;
///
/// // conto pungkasan iku kakehan papat.Ayo mung papat papat.
/// let mut four_fours = iter::repeat(4).take(4);
///
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
///
/// // ... lan saiki kita wis rampung
/// assert_eq!(None, four_fours.next());
/// ```
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn repeat<T: Clone>(elt: T) -> Repeat<T> {
    Repeat { element: elt }
}

/// Pengulangan sing mbaleni unsur kanthi tanpa wates.
///
/// `struct` iki digawe dening fungsi [`repeat()`].Waca dokumentasi sawijining liyane.
#[derive(Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Repeat<A> {
    element: A,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> Iterator for Repeat<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> DoubleEndedIterator for Repeat<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Clone> FusedIterator for Repeat<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Clone> TrustedLen for Repeat<A> {}