use crate::fmt;

/// Nggawe iterator anyar ngendi saben pengulangan Telpon closure `F: FnMut() -> Option<T>` kasedhiya.
///
/// Iki ngidini nggawe iterator adat karo prilaku tanpa nggunakake liyane verbose ukara nggawe jinis darmabakti lan penerapan [`Iterator`] trait iku.
///
/// Wigati sing `FromFn` iterator ora nggawe pemanggih bab prilaku penutupan kasus, lan mulane conservatively ora ngleksanakake [`FusedIterator`], utawa ngilangi [`Iterator::size_hint()`] saka standar sawijining `(0, None)`.
///
///
/// penutupan kasus bisa nggunakake nuduhke lan lingkungan kanggo trek negara tengen iterasi.Gumantung carane iterator digunakake, iki mbutuhake khusus keyword [`move`] ing penutupan kasus.
///
/// [`move`]: ../../std/keyword.move.html
/// [`FusedIterator`]: crate::iter::FusedIterator
///
/// # Examples
///
/// Ayo re-ngleksanakake iterator counter saka [module-level documentation]:
///
/// [module-level documentation]: crate::iter
///
/// ```
/// let mut count = 0;
/// let counter = std::iter::from_fn(move || {
///     // Nambah jumlah kita.Iki kok kita miwiti ing nul.
///     count += 1;
///
///     // Priksa manawa kita wis rampung ngetung utawa ora.
///     if count < 6 {
///         Some(count)
///     } else {
///         None
///     }
/// });
/// assert_eq!(counter.collect::<Vec<_>>(), &[1, 2, 3, 4, 5]);
/// ```
///
///
///
///
///
#[inline]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub fn from_fn<T, F>(f: F) -> FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    FromFn(f)
}

/// Pengulangan ing endi saben iterasi nyebutake penutupan `F: FnMut() -> Option<T>`.
///
/// `struct` iki digawe dening fungsi [`iter::from_fn()`].
/// Deleng dokumentasi kanggo luwih lengkap.
///
/// [`iter::from_fn()`]: from_fn
#[derive(Clone)]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub struct FromFn<F>(F);

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<T, F> Iterator for FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<Self::Item> {
        (self.0)()
    }
}

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<F> fmt::Debug for FromFn<F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("FromFn").finish()
    }
}