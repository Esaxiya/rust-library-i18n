use crate::iter::{FusedIterator, TrustedLen};

/// Nggawe iterator sing panenan unsur persis sapisan.
///
/// Iki wis umum digunakake kanggo ngganti Nilai siji menyang [`chain()`] saka jinis pengulangan.
/// Mungkin sampeyan duwe iterator sing isine meh kabeh, nanging sampeyan perlu cilik khusus ekstra.
/// Mungkin sampeyan duwe fungsi kang dianggo ing iterators, nanging sampeyan mung perlu kanggo proses siji nilai.
///
/// [`chain()`]: Iterator::chain
///
/// # Examples
///
/// Panggunaan dhasar:
///
/// ```
/// use std::iter;
///
/// // siji nomer loneliest
/// let mut one = iter::once(1);
///
/// assert_eq!(Some(1), one.next());
///
/// // mung siji, iku kabeh sing oleh
/// assert_eq!(None, one.next());
/// ```
///
/// Rantai bebarengan karo iterator liyane.
/// Muga-muga sampeyan pengin ngetrapake saben file direktori `.foo`, nanging uga file konfigurasi,
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // kita perlu ngowahi saka iterator saka DirEntry-s menyang iterator saka PathBufs, supaya kita nggunakake map
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // saiki, iterator kita mung kanggo file config kita
/// let config = iter::once(PathBuf::from(".foorc"));
///
/// // chain loro iterators bebarengan menyang siji iterator amba
/// let files = dirs.chain(config);
///
/// // iki bakal menehi kita kabeh file ing .foo uga .foorc
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
#[stable(feature = "iter_once", since = "1.2.0")]
pub fn once<T>(value: T) -> Once<T> {
    Once { inner: Some(value).into_iter() }
}

/// Lan iterator sing panenan unsur persis sapisan.
///
/// `struct` iki digawe dening fungsi [`once()`].Waca dokumentasi sawijining liyane.
#[derive(Clone, Debug)]
#[stable(feature = "iter_once", since = "1.2.0")]
pub struct Once<T> {
    inner: crate::option::IntoIter<T>,
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> Iterator for Once<T> {
    type Item = T;

    fn next(&mut self) -> Option<T> {
        self.inner.next()
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> DoubleEndedIterator for Once<T> {
    fn next_back(&mut self) -> Option<T> {
        self.inner.next_back()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> ExactSizeIterator for Once<T> {
    fn len(&self) -> usize {
        self.inner.len()
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T> TrustedLen for Once<T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Once<T> {}