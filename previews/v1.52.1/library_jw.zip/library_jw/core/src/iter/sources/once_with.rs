use crate::iter::{FusedIterator, TrustedLen};

/// Nggawe iterator sing lazily ngasilake nilai persis sapisan dening invoking penutupan diwenehake.
///
/// Iki wis umum digunakake kanggo ngganti Nilai generator siji menyang [`chain()`] saka jinis pengulangan.
/// Mungkin sampeyan duwe iterator sing isine meh kabeh, nanging sampeyan perlu cilik khusus ekstra.
/// Mungkin sampeyan duwe fungsi kang dianggo ing iterators, nanging sampeyan mung perlu kanggo proses siji nilai.
///
/// Beda karo [`once()`], fungsi iki kanthi malas ngasilake regane miturut panjaluk.
///
/// [`chain()`]: Iterator::chain
/// [`once()`]: crate::iter::once
///
/// # Examples
///
/// Panggunaan dhasar:
///
/// ```
/// use std::iter;
///
/// // siji nomer loneliest
/// let mut one = iter::once_with(|| 1);
///
/// assert_eq!(Some(1), one.next());
///
/// // mung siji, iku kabeh sing oleh
/// assert_eq!(None, one.next());
/// ```
///
/// Rantai bebarengan karo iterator liyane.
/// Muga-muga sampeyan pengin ngetrapake saben file direktori `.foo`, nanging uga file konfigurasi,
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // kita perlu ngowahi saka iterator saka DirEntry-s menyang iterator saka PathBufs, supaya kita nggunakake map
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // saiki, iterator kita mung kanggo file config kita
/// let config = iter::once_with(|| PathBuf::from(".foorc"));
///
/// // chain loro iterators bebarengan menyang siji iterator amba
/// let files = dirs.chain(config);
///
/// // iki bakal menehi kita kabeh file ing .foo uga .foorc
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
///
#[inline]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub fn once_with<A, F: FnOnce() -> A>(gen: F) -> OnceWith<F> {
    OnceWith { gen: Some(gen) }
}

/// Iterator sing ngasilake unsur siji tipe `A` kanthi nggunakake `F: FnOnce() -> A` penutupan sing disedhiyakake.
///
///
/// `struct` iki digawe dening fungsi [`once_with()`].
/// Deleng dokumentasi kanggo luwih lengkap.
#[derive(Clone, Debug)]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub struct OnceWith<F> {
    gen: Option<F>,
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> Iterator for OnceWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        let f = self.gen.take()?;
        Some(f())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.gen.iter().size_hint()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> DoubleEndedIterator for OnceWith<F> {
    fn next_back(&mut self) -> Option<A> {
        self.next()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> ExactSizeIterator for OnceWith<F> {
    fn len(&self) -> usize {
        self.gen.iter().len()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> FusedIterator for OnceWith<F> {}

#[stable(feature = "iter_once_with", since = "1.43.0")]
unsafe impl<A, F: FnOnce() -> A> TrustedLen for OnceWith<F> {}