#![stable(feature = "futures_api", since = "1.36.0")]

use crate::marker::Unpin;
use crate::ops;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// A future nggantosi etungan bedo.
///
/// A future aji sing uga wis ora rampung komputerisasi durung.
/// "asynchronous value" semacam iki nggawe benang bisa terus makarya migunani nalika ngenteni regane kasedhiya.
///
///
/// # Cara `poll`
///
/// Cara inti saka future, `poll`, usaha * * kanggo mutusake masalah future menyang Nilai final.
/// Cara iki ora mblokir yen nilai ora siap.
/// Nanging, tugas saiki wis dijadwal kanggo bakal woken nalika iku bisa gawe kemajuan luwih dening: poll`ing maneh.
/// `context` sing diterusake menyang metode `poll` bisa nyedhiyakake [`Waker`], yaiku gagang kanggo tangi tugas saiki.
///
/// Nalika nggunakake future, anjeun ora nelpon `poll` langsung, nanging `.await` Nilai.
///
/// [`Waker`]: crate::task::Waker
///
///
///
#[doc(spotlight)]
#[must_use = "futures do nothing unless you `.await` or poll them"]
#[stable(feature = "futures_api", since = "1.36.0")]
#[lang = "future_trait"]
#[rustc_on_unimplemented(label = "`{Self}` is not a future", message = "`{Self}` is not a future")]
pub trait Future {
    /// Jinis nilai sing diproduksi sawise rampung.
    #[stable(feature = "futures_api", since = "1.36.0")]
    type Output;

    /// Coba ngrampungake future dadi nilai pungkasan, ndhaptar tugas saiki kanggo tangi yen regane durung kasedhiya.
    ///
    /// # Nilai bali
    ///
    /// fungsi ngasilake:
    ///
    /// - [`Poll::Pending`] yen future ora siap durung
    /// - [`Poll::Ready(val)`] kanthi asil `val` saka future iki yen rampung kanthi sukses.
    ///
    /// Sawise a future wis rampung, klien ngirim ora `poll` maneh.
    ///
    /// Nalika future durung siyap, `poll` ngasilake `Poll::Pending` lan nyimpen klon [`Waker`] sing disalin saka [`Context`] saiki.
    /// [`Waker`] iki banjur di bangun sawise future bisa maju.
    /// Contone, future sing ngenteni soket supaya bisa diwaca bakal nelpon `.clone()` ing [`Waker`] lan nyimpen.
    /// Nalika sinyal teka ing panggon liya sing nuduhake manawa soket bisa diwaca, [`Waker::wake`] ditelpon lan tugas soket future tangi.
    /// Sawise tugas wis tangi, sampeyan kudu nyoba `poll` future maneh, sing bisa uga ora ngasilake angka pungkasan.
    ///
    /// Elinga yen ing sawetara telpon kanggo `poll`, mung ing [`Waker`] saka [`Context`] liwati kanggo paling telpon anyar kudu dijadwal kanggo nampa wakeup a.
    ///
    /// # ciri durasi
    ///
    /// Futures mung *inert*;padha kudu *aktif*: poll`ed gawe kemajuan, tegesé saben wektu tugas saiki wis woken, iku kudu aktif nunggu futures re-`poll` sing isih duwe kapentingan ing.
    ///
    /// Fungsi `poll` ora diarani bola-bali ing loop sing nyenyet-nanging luwih becik yen future wis siyap nggawe proses (kanthi nelpon `wake()`).
    /// Yen sampeyan lagi menowo karo `poll(2)` utawa `select(2)` syscalls ing Unix worth iku kang lagi nyimak sing futures biasane apa *ora tau* nandhang masalah padha "all wakeups must poll all events";padha luwih kaya `epoll(4)`.
    ///
    /// Lan implementasine saka `poll` kudu usaha kanggo bali cepet, lan ora kudu mblokir.Bali kanthi cepet ngalangi benang utawa puteran acara sing ora perlu.
    /// Yen wis dingerteni sadurunge, yen telpon menyang `poll` bisa uga suwe, kerja kasebut kudu diunggah menyang kolam thread (utawa sing padha) kanggo mesthekake yen `poll` bisa bali kanthi cepet.
    ///
    /// # Panics
    ///
    /// Sawise future rampung (bali `Ready` saka `poll`), nelpon cara `poll` maneh bisa uga panic, diblokir selawase, utawa nyebabake masalah liyane;ing `Future` trait panggonan ora syarat ing efek saka telpon kuwi.
    /// Nanging, minangka cara `poll` ora ditandhani `unsafe`, aturan biasanipun Rust kang aplikasi: telpon ora kudu nimbulaké prilaku cetho (korupsi memori, nggunakake salah fungsi `unsafe`, utawa kaya), preduli saka negara future kang.
    ///
    ///
    /// [`Poll::Ready(val)`]: Poll::Ready
    /// [`Waker`]: crate::task::Waker
    /// [`Waker::wake`]: crate::task::Waker::wake
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[lang = "poll"]
    #[stable(feature = "futures_api", since = "1.36.0")]
    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output>;
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<F: ?Sized + Future + Unpin> Future for &mut F {
    type Output = F::Output;

    fn poll(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        F::poll(Pin::new(&mut **self), cx)
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<P> Future for Pin<P>
where
    P: Unpin + ops::DerefMut<Target: Future>,
{
    type Output = <<P as ops::Deref>::Target as Future>::Output;

    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        Pin::get_mut(self).as_mut().poll(cx)
    }
}