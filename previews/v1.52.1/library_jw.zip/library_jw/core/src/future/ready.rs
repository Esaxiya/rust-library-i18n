use crate::future::Future;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// Nggawe future sing langsung siyap karo regane.
///
/// `struct` iki digawe dening [`ready()`].
/// Deleng dokumentasi kanggo luwih lengkap.
#[stable(feature = "future_readiness_fns", since = "1.48.0")]
#[derive(Debug, Clone)]
#[must_use = "futures do nothing unless you `.await` or poll them"]
pub struct Ready<T>(Option<T>);

#[stable(feature = "future_readiness_fns", since = "1.48.0")]
impl<T> Unpin for Ready<T> {}

#[stable(feature = "future_readiness_fns", since = "1.48.0")]
impl<T> Future for Ready<T> {
    type Output = T;

    #[inline]
    fn poll(mut self: Pin<&mut Self>, _cx: &mut Context<'_>) -> Poll<T> {
        Poll::Ready(self.0.take().expect("Ready polled after completion"))
    }
}

/// Nggawe future sing langsung siyap karo regane.
///
/// Futures digawe liwat fungsi iki ing fungsi-fungsi padha karo sing digawé liwat `async {}`.
/// Bentenipun utama iku futures digawe liwat fungsi iki sing jenenge lan ngleksanakake `Unpin`.
///
/// # Examples
///
/// ```
/// use std::future;
///
/// # async fn run() {
/// let a = future::ready(1);
/// assert_eq!(a.await, 1);
/// # }
/// ```
///
#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub fn ready<T>(t: T) -> Ready<T> {
    Ready(Some(t))
}