//! Cara nggawe `str` saka irisan bait.

use crate::mem;

use super::validations::run_utf8_validation;
use super::Utf8Error;

/// Ngowahi irisan bita menyang irisan senar.
///
/// Irisan senar ([`&str`]) digawe saka byte ([`u8`]), lan irisan byte ([`&[u8]`][byteslice]) digawe saka byte, mula fungsi iki diowahi dadi loro.
/// Ora kabeh irisan-irisan bait sing irisan-irisan senar bener, Nanging: [`&str`] mbutuhake iku bener UTF-8.
/// `from_utf8()` mriksa kanggo mesthekake yen byte bener UTF-8, banjur konversi.
///
/// [`&str`]: str
/// [byteslice]: slice
///
/// Yen sampeyan yakin yen irisan byte bener UTF-8, lan sampeyan ora pengin overhead mriksa validitas, ana versi sing ora aman kanggo fungsi iki, [`from_utf8_unchecked`], sing nduweni prilaku sing padha nanging ora ngecek centhang kasebut.
///
///
/// Yen sampeyan butuh `String` tinimbang `&str`, coba [`String::from_utf8`][string].
///
/// [string]: ../../std/string/struct.String.html#method.from_utf8
///
/// Amarga sampeyan bisa tumpukan-alokasi `[u8; N]`, lan sampeyan bisa njupuk [`&[u8]`][byteslice], fungsi iki minangka salah sawijining cara kanggo nggawe string sing dialokasikan tumpukan.Ana conto iki ing bagean conto ing ngisor iki.
///
/// [byteslice]: slice
///
/// # Errors
///
/// Ngasilake `Err` yen irisan dudu UTF-8 kanthi katrangan kenapa irisan sing disedhiyakake dudu UTF-8.
///
/// # Examples
///
/// Panggunaan dhasar:
///
/// ```
/// use std::str;
///
/// // sawetara bait, ing vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // Kita ngerti bait kasebut bener, mula nganggo `unwrap()`.
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// Bita salah:
///
/// ```
/// use std::str;
///
/// // sawetara bait sing ora valid, ing vector
/// let sparkle_heart = vec![0, 159, 146, 150];
///
/// assert!(str::from_utf8(&sparkle_heart).is_err());
/// ```
///
/// Deleng dokumen kanggo [`Utf8Error`] kanggo rincian liyane babagan jinis kesalahan sing bisa dibalekake.
///
/// "stack allocated string":
///
/// ```
/// use std::str;
///
/// // sawetara bait, ing susunan sing diparengake tumpukan
/// let sparkle_heart = [240, 159, 146, 150];
///
/// // Kita ngerti bait kasebut bener, mula nganggo `unwrap()`.
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_utf8(v: &[u8]) -> Result<&str, Utf8Error> {
    run_utf8_validation(v)?;
    // SAFETY: Mung mbukak validasi.
    Ok(unsafe { from_utf8_unchecked(v) })
}

/// Ngonversi irisan byte sing bisa diowahi dadi irisan senar sing bisa diowahi.
///
/// # Examples
///
/// Panggunaan dhasar:
///
/// ```
/// use std::str;
///
/// // "Hello, Rust!" minangka vector sing bisa diowahi
/// let mut hellorust = vec![72, 101, 108, 108, 111, 44, 32, 82, 117, 115, 116, 33];
///
/// // Kaya sing dingerteni byte kasebut bener, kita bisa nggunakake `unwrap()`
/// let outstr = str::from_utf8_mut(&mut hellorust).unwrap();
///
/// assert_eq!("Hello, Rust!", outstr);
/// ```
///
/// Bita salah:
///
/// ```
/// use std::str;
///
/// // Sawetara bait sing ora valid ing vector sing bisa diowahi
/// let mut invalid = vec![128, 223];
///
/// assert!(str::from_utf8_mut(&mut invalid).is_err());
/// ```
/// Deleng dokumen kanggo [`Utf8Error`] kanggo rincian liyane babagan jinis kesalahan sing bisa dibalekake.
///
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub fn from_utf8_mut(v: &mut [u8]) -> Result<&mut str, Utf8Error> {
    run_utf8_validation(v)?;
    // SAFETY: Mung mbukak validasi.
    Ok(unsafe { from_utf8_unchecked_mut(v) })
}

/// Ngowahi irisan bita menyang irisan senar tanpa ngecek sing senar ngandhut UTF-8 bener.
///
/// Deleng versi aman, [`from_utf8`], kanggo informasi lengkap.
///
/// # Safety
///
/// Fungsi iki ora aman amarga ora mriksa manawa bait sing diterusake UTF-8 bener.
/// Yen watesan iki dilanggar, asil tumindak sing ora ditemtokake, amarga sisa Rust nganggep yen [`&str`] valid UTF-8.
///
///
/// [`&str`]: str
///
/// # Examples
///
/// Panggunaan dhasar:
///
/// ```
/// use std::str;
///
/// // sawetara bait, ing vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// let sparkle_heart = unsafe {
///     str::from_utf8_unchecked(&sparkle_heart)
/// };
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_str_from_utf8_unchecked", issue = "75196")]
#[rustc_allow_const_fn_unstable(const_fn_transmute)]
pub const unsafe fn from_utf8_unchecked(v: &[u8]) -> &str {
    // SAFETY: panelpon kudu njamin yen bait `v` bener UTF-8.
    // Uga gumantung ing `&str` lan `&[u8]` sing duwe tata letak sing padha.
    unsafe { mem::transmute(v) }
}

/// Ngonversi irisan bait menyang irisan senar tanpa mriksa manawa senar kasebut ngemot UTF-8 sing valid;versi sing bisa diowahi
///
///
/// Deleng versi sing ora bisa diowahi, [`from_utf8_unchecked()`] kanggo informasi lengkap.
///
/// # Examples
///
/// Panggunaan dhasar:
///
/// ```
/// use std::str;
///
/// let mut heart = vec![240, 159, 146, 150];
/// let heart = unsafe { str::from_utf8_unchecked_mut(&mut heart) };
///
/// assert_eq!("💖", heart);
/// ```
#[inline]
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub unsafe fn from_utf8_unchecked_mut(v: &mut [u8]) -> &mut str {
    // SAFETY: panelpon kudu njamin yen bait `v`
    // bener UTF-8, mula cor menyang `*mut str` aman.
    // Uga, dereferensi pointer aman amarga pointer kasebut asale saka referensi sing dijamin valid kanggo nulis.
    //
    unsafe { &mut *(v as *mut [u8] as *mut str) }
}