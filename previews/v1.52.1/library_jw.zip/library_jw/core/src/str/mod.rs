//! Manipulasi senar.
//!
//! Kanggo rincian liyane, waca modul [`std::str`].
//!
//! [`std::str`]: ../../std/str/index.html

#![stable(feature = "rust1", since = "1.0.0")]

mod converts;
mod error;
mod iter;
mod traits;
mod validations;

use self::pattern::Pattern;
use self::pattern::{DoubleEndedSearcher, ReverseSearcher, Searcher};

use crate::char;
use crate::mem;
use crate::slice::{self, SliceIndex};

pub mod pattern;

#[unstable(feature = "str_internals", issue = "none")]
#[allow(missing_docs)]
pub mod lossy;

#[stable(feature = "rust1", since = "1.0.0")]
pub use converts::{from_utf8, from_utf8_unchecked};

#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub use converts::{from_utf8_mut, from_utf8_unchecked_mut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use error::{ParseBoolError, Utf8Error};

#[stable(feature = "rust1", since = "1.0.0")]
pub use traits::FromStr;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Bytes, CharIndices, Chars, Lines, SplitWhitespace};

#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated)]
pub use iter::LinesAny;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplit, RSplitTerminator, Split, SplitTerminator};

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplitN, SplitN};

#[stable(feature = "str_matches", since = "1.2.0")]
pub use iter::{Matches, RMatches};

#[stable(feature = "str_match_indices", since = "1.5.0")]
pub use iter::{MatchIndices, RMatchIndices};

#[stable(feature = "encode_utf16", since = "1.8.0")]
pub use iter::EncodeUtf16;

#[stable(feature = "str_escape", since = "1.34.0")]
pub use iter::{EscapeDebug, EscapeDefault, EscapeUnicode};

#[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
pub use iter::SplitAsciiWhitespace;

#[stable(feature = "split_inclusive", since = "1.51.0")]
pub use iter::SplitInclusive;

#[unstable(feature = "str_internals", issue = "none")]
pub use validations::next_code_point;

use iter::MatchIndicesInternal;
use iter::SplitInternal;
use iter::{MatchesInternal, SplitNInternal};

use validations::truncate_to_char_boundary;

#[inline(never)]
#[cold]
#[track_caller]
fn slice_error_fail(s: &str, begin: usize, end: usize) -> ! {
    const MAX_DISPLAY_LENGTH: usize = 256;
    let (truncated, s_trunc) = truncate_to_char_boundary(s, MAX_DISPLAY_LENGTH);
    let ellipsis = if truncated { "[...]" } else { "" };

    // 1. metu saka wates
    if begin > s.len() || end > s.len() {
        let oob_index = if begin > s.len() { begin } else { end };
        panic!("byte index {} is out of bounds of `{}`{}", oob_index, s_trunc, ellipsis);
    }

    // 2. wiwiti <=pungkasan
    assert!(
        begin <= end,
        "begin <= end ({} <= {}) when slicing `{}`{}",
        begin,
        end,
        s_trunc,
        ellipsis
    );

    // 3. wates karakter
    let index = if !s.is_char_boundary(begin) { begin } else { end };
    // golek watak
    let mut char_start = index;
    while !s.is_char_boundary(char_start) {
        char_start -= 1;
    }
    // `char_start` kudu kurang saka len lan wates char
    let ch = s[char_start..].chars().next().unwrap();
    let char_range = char_start..char_start + ch.len_utf8();
    panic!(
        "byte index {} is not a char boundary; it is inside {:?} (bytes {:?}) of `{}`{}",
        index, ch, char_range, s_trunc, ellipsis
    );
}

#[lang = "str"]
#[cfg(not(test))]
impl str {
    /// Ngasilake dawa `self`.
    ///
    /// Dawane iki ana ing bait, dudu [`char`] utawa graphemes.
    /// Kanthi tembung liyane, bisa uga ora dianggep manungsa sing dawa senar kasebut.
    ///
    /// [`char`]: prim@char
    ///
    /// # Examples
    ///
    /// Panggunaan dhasar:
    ///
    /// ```
    /// let len = "foo".len();
    /// assert_eq!(3, len);
    ///
    /// assert_eq!("ƒoo".len(), 4); // apik f!
    /// assert_eq!("ƒoo".chars().count(), 3);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_str_len", since = "1.32.0")]
    #[inline]
    pub const fn len(&self) -> usize {
        self.as_bytes().len()
    }

    /// Ngasilake `true` yen `self` dawane nol.
    ///
    /// # Examples
    ///
    /// Panggunaan dhasar:
    ///
    /// ```
    /// let s = "";
    /// assert!(s.is_empty());
    ///
    /// let s = "not empty";
    /// assert!(!s.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_str_is_empty", since = "1.32.0")]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Kir sing: index`-th bait iku bait pisanan ing UTF-8 kode titik urutan utawa mburi saka senar.
    ///
    ///
    /// Wiwitan lan pungkasan senar (nalika `indeks== self.len()`) dianggep dadi wates.
    ///
    /// Ngasilake `false` yen `index` luwih gedhe tinimbang `self.len()`.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// assert!(s.is_char_boundary(0));
    /// // wiwitan `老`
    /// assert!(s.is_char_boundary(6));
    /// assert!(s.is_char_boundary(s.len()));
    ///
    /// // byte kapindho `ö`
    /// assert!(!s.is_char_boundary(2));
    ///
    /// // byte katelu `老`
    /// assert!(!s.is_char_boundary(8));
    /// ```
    ///
    #[stable(feature = "is_char_boundary", since = "1.9.0")]
    #[inline]
    pub fn is_char_boundary(&self, index: usize) -> bool {
        // 0 lan len mesthi ok.
        // Tes 0 kanthi jelas supaya bisa ngoptimalake pamriksa kanthi gampang lan nglumpati data senar maca kanggo kasus kasebut.
        //
        if index == 0 || index == self.len() {
            return true;
        }
        match self.as_bytes().get(index) {
            None => false,
            // Iki sulap sing padha karo: b <128 ||b>=192
            Some(&b) => (b as i8) >= -0x40,
        }
    }

    /// Ngonversi irisan senar menyang irisan byte.
    /// Kanggo ngowahi bait irisan bali menyang irisan senar, nggunakake fungsi [`from_utf8`].
    ///
    /// # Examples
    ///
    /// Panggunaan dhasar:
    ///
    /// ```
    /// let bytes = "bors".as_bytes();
    /// assert_eq!(b"bors", bytes);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "str_as_bytes", since = "1.32.0")]
    #[inline(always)]
    #[allow(unused_attributes)]
    #[rustc_allow_const_fn_unstable(const_fn_transmute)]
    pub const fn as_bytes(&self) -> &[u8] {
        // SAFETY: swara const amarga kita transmute rong jinis karo rancangan padha
        unsafe { mem::transmute(self) }
    }

    /// Ngonversi irisan senar sing bisa diowahi dadi irisan byte sing bisa diowahi.
    ///
    /// # Safety
    ///
    /// Panelpon kudu mesthekake manawa isi irisan kasebut UTF-8 bener sadurunge utang diselehake lan `str` sing ndasari digunakake.
    ///
    ///
    /// Panganggone `str` sing isine ora valid UTF-8 dudu tumindak sing durung ditemtokake.
    ///
    /// # Examples
    ///
    /// Panggunaan dhasar:
    ///
    /// ```
    /// let mut s = String::from("Hello");
    /// let bytes = unsafe { s.as_bytes_mut() };
    ///
    /// assert_eq!(b"Hello", bytes);
    /// ```
    ///
    /// Mutability:
    ///
    /// ```
    /// let mut s = String::from("🗻∈🌏");
    ///
    /// unsafe {
    ///     let bytes = s.as_bytes_mut();
    ///
    ///     bytes[0] = 0xF0;
    ///     bytes[1] = 0x9F;
    ///     bytes[2] = 0x8D;
    ///     bytes[3] = 0x94;
    /// }
    ///
    /// assert_eq!("🍔∈🌏", s);
    /// ```
    #[stable(feature = "str_mut_extras", since = "1.20.0")]
    #[inline(always)]
    pub unsafe fn as_bytes_mut(&mut self) -> &mut [u8] {
        // SAFETY: pemeran saka `&str` dadi `&[u8]` aman wiwit `str`
        // nduweni tata letak sing padha karo `&[u8]` (mung libstd sing bisa njamin iki).
        // Ing pitunjuk dereference aman awit iku asalé saka referensi mutable kang dijamin dadi bener kanggo nyerat.
        //
        unsafe { &mut *(self as *mut str as *mut [u8]) }
    }

    /// Ngonversi irisan senar menyang pitunjuk mentah.
    ///
    /// Minangka senar irisan-irisan sing irisan bita, nilai pitunjuk mentahan menyang [`u8`].
    /// pointer iki bakal pointing menyang bait pisanan saka irisan senar.
    ///
    /// panelpon kudu mesthekake yen pitunjuk bali wis tau ditulis kanggo.
    /// Yen sampeyan kudu mutasi isi irisan senar, gunakake [`as_mut_ptr`].
    ///
    ///
    /// [`as_mut_ptr`]: str::as_mut_ptr
    ///
    /// # Examples
    ///
    /// Panggunaan dhasar:
    ///
    /// ```
    /// let s = "Hello";
    /// let ptr = s.as_ptr();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "rustc_str_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(&self) -> *const u8 {
        self as *const str as *const u8
    }

    /// Ngowahi senar irisan mutable kanggo pitunjuk mentahan.
    ///
    /// Minangka senar irisan-irisan sing irisan bita, nilai pitunjuk mentahan menyang [`u8`].
    /// pointer iki bakal pointing menyang bait pisanan saka irisan senar.
    ///
    /// Punika sampeyan tanggung jawab kanggo nggawe manawa irisan senar mung bakal dipunéwahi ing cara sing tetep UTF-8 bener.
    ///
    ///
    #[stable(feature = "str_as_mut_ptr", since = "1.36.0")]
    #[inline]
    pub fn as_mut_ptr(&mut self) -> *mut u8 {
        self as *mut str as *mut u8
    }

    /// Ngasilake subslice `str`.
    ///
    /// Iki minangka alternatif non-panik kanggo ngindeks `str`.
    /// Ngasilake [`None`] kapan wae operasi indeksasi sing padha karo panic.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = String::from("🗻∈🌏");
    ///
    /// assert_eq!(Some("🗻"), v.get(0..4));
    ///
    /// // indeks ora ana ing watesan urutan UTF-8
    /// assert!(v.get(1..).is_none());
    /// assert!(v.get(..8).is_none());
    ///
    /// // metu saka wates
    /// assert!(v.get(..42).is_none());
    /// ```
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub fn get<I: SliceIndex<str>>(&self, i: I) -> Option<&I::Output> {
        i.get(self)
    }

    /// Ngasilake subslice `str` sing bisa diowahi.
    ///
    /// Iki minangka alternatif non-panik kanggo ngindeks `str`.
    /// Ngasilake [`None`] kapan wae operasi indeksasi sing padha karo panic.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = String::from("hello");
    /// // dawa sing bener
    /// assert!(v.get_mut(0..5).is_some());
    /// // metu saka wates
    /// assert!(v.get_mut(..42).is_none());
    /// assert_eq!(Some("he"), v.get_mut(0..2).map(|v| &*v));
    ///
    /// assert_eq!("hello", v);
    /// {
    ///     let s = v.get_mut(0..2);
    ///     let s = s.map(|s| {
    ///         s.make_ascii_uppercase();
    ///         &*s
    ///     });
    ///     assert_eq!(Some("HE"), s);
    /// }
    /// assert_eq!("HEllo", v);
    /// ```
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub fn get_mut<I: SliceIndex<str>>(&mut self, i: I) -> Option<&mut I::Output> {
        i.get_mut(self)
    }

    /// Ngasilake subskrip `str` sing ora dicenthang.
    ///
    /// Iki minangka alternatif sing ora dicenthang kanggo ngindeks `str`.
    ///
    /// # Safety
    ///
    /// Panelpon fungsi iki tanggung jawab manawa prasyarat kasebut kepenak:
    ///
    /// * Ing indeks miwiti kudu ora ngluwihi indeks pungkasan;
    /// * Indeks kudu ana ing wates irisan asli;
    /// * Indeks kudu ana ing wates urutan UTF-8.
    ///
    /// Gagal, irisan senar sing dibalekake bisa uga referensi memori sing ora valid utawa nglanggar invarian sing disampekno karo jinis `str`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let v = "🗻∈🌏";
    /// unsafe {
    ///     assert_eq!("🗻", v.get_unchecked(0..4));
    ///     assert_eq!("∈", v.get_unchecked(4..7));
    ///     assert_eq!("🌏", v.get_unchecked(7..11));
    /// }
    /// ```
    ///
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub unsafe fn get_unchecked<I: SliceIndex<str>>(&self, i: I) -> &I::Output {
        // SAFETY: panelpon kudu njaga kontrak keamanan kanggo `get_unchecked`;
        // irisan bisa dibatalake amarga `self` minangka referensi sing aman.
        // Pointer sing bali wis aman amarga impl `SliceIndex` kudu njamin manawa wis ana.
        unsafe { &*i.get_unchecked(self) }
    }

    /// Ngasilake subslice `str` sing bisa diowahi lan ora dicenthang.
    ///
    /// Iki minangka alternatif sing ora dicenthang kanggo ngindeks `str`.
    ///
    /// # Safety
    ///
    /// Panelpon fungsi iki tanggung jawab manawa prasyarat kasebut kepenak:
    ///
    /// * Ing indeks miwiti kudu ora ngluwihi indeks pungkasan;
    /// * Indeks kudu ana ing wates irisan asli;
    /// * Indeks kudu ana ing wates urutan UTF-8.
    ///
    /// Gagal, irisan senar sing dibalekake bisa uga referensi memori sing ora valid utawa nglanggar invarian sing disampekno karo jinis `str`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = String::from("🗻∈🌏");
    /// unsafe {
    ///     assert_eq!("🗻", v.get_unchecked_mut(0..4));
    ///     assert_eq!("∈", v.get_unchecked_mut(4..7));
    ///     assert_eq!("🌏", v.get_unchecked_mut(7..11));
    /// }
    /// ```
    ///
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I: SliceIndex<str>>(&mut self, i: I) -> &mut I::Output {
        // SAFETY: panelpon kudu njaga kontrak keamanan kanggo `get_unchecked_mut`;
        // irisan bisa dibatalake amarga `self` minangka referensi sing aman.
        // Pointer sing bali wis aman amarga impl `SliceIndex` kudu njamin manawa wis ana.
        unsafe { &mut *i.get_unchecked_mut(self) }
    }

    /// Nggawe irisan senar saka irisan senar liyane, ngliwati cek keamanan.
    ///
    /// Iki umume ora disaranake, gunakake kanthi ati-ati!Kanggo alternatif sing aman, deleng [`str`] lan [`Index`].
    ///
    ///
    /// [`Index`]: crate::ops::Index
    ///
    /// Irisan anyar iki diwiwiti saka `begin` dadi `end`, kalebu `begin` nanging ora kalebu `end`.
    ///
    /// Kanggo entuk irisan senar sing bisa diowahi, deleng cara [`slice_mut_unchecked`].
    ///
    /// [`slice_mut_unchecked`]: str::slice_mut_unchecked
    ///
    /// # Safety
    ///
    /// Panelpon fungsi iki tanggung jawab yen telung prasyarat kepenak:
    ///
    /// * `begin` ora kudu ngluwihi `end`.
    /// * `begin` lan `end` kudu bait posisi ing irisan senar.
    /// * `begin` lan `end` kudu mapan ing watesan urutan UTF-8.
    ///
    /// # Examples
    ///
    /// Panggunaan dhasar:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// unsafe {
    ///     assert_eq!("Löwe 老虎 Léopard", s.slice_unchecked(0, 21));
    /// }
    ///
    /// let s = "Hello, world!";
    ///
    /// unsafe {
    ///     assert_eq!("world", s.slice_unchecked(7, 12));
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.29.0", reason = "use `get_unchecked(begin..end)` instead")]
    #[inline]
    pub unsafe fn slice_unchecked(&self, begin: usize, end: usize) -> &str {
        // SAFETY: panelpon kudu njaga kontrak keamanan kanggo `get_unchecked`;
        // irisan bisa dibatalake amarga `self` minangka referensi sing aman.
        // Pointer sing bali wis aman amarga impl `SliceIndex` kudu njamin manawa wis ana.
        unsafe { &*(begin..end).get_unchecked(self) }
    }

    /// Nggawe irisan senar saka irisan senar liyane, ngliwati cek keamanan.
    /// Iki umume ora disaranake, gunakake kanthi ati-ati!Kanggo alternatif sing aman, deleng [`str`] lan [`IndexMut`].
    ///
    ///
    /// [`IndexMut`]: crate::ops::IndexMut
    ///
    /// Irisan anyar iki diwiwiti saka `begin` dadi `end`, kalebu `begin` nanging ora kalebu `end`.
    ///
    /// Kanggo entuk irisan senar sing ora bisa diganti, deleng cara [`slice_unchecked`].
    ///
    /// [`slice_unchecked`]: str::slice_unchecked
    ///
    /// # Safety
    ///
    /// Panelpon fungsi iki tanggung jawab yen telung prasyarat kepenak:
    ///
    /// * `begin` ora kudu ngluwihi `end`.
    /// * `begin` lan `end` kudu bait posisi ing irisan senar.
    /// * `begin` lan `end` kudu mapan ing watesan urutan UTF-8.
    ///
    ///
    ///
    ///
    #[stable(feature = "str_slice_mut", since = "1.5.0")]
    #[rustc_deprecated(since = "1.29.0", reason = "use `get_unchecked_mut(begin..end)` instead")]
    #[inline]
    pub unsafe fn slice_mut_unchecked(&mut self, begin: usize, end: usize) -> &mut str {
        // SAFETY: panelpon kudu njaga kontrak keamanan kanggo `get_unchecked_mut`;
        // irisan bisa dibatalake amarga `self` minangka referensi sing aman.
        // Pointer sing bali wis aman amarga impl `SliceIndex` kudu njamin manawa wis ana.
        unsafe { &mut *(begin..end).get_unchecked_mut(self) }
    }

    /// Dibagi irisan senar dadi loro ing indeks.
    ///
    /// Argumentasi, `mid`, kudu diimbangi byte saka wiwitan senar.
    /// Sampeyan uga kudu ana ing wates titik kode UTF-8.
    ///
    /// Loro irisan kasebut bali wiwit irisan irisan nganti `mid`, lan saka `mid` nganti pungkasan irisan senar.
    ///
    /// Kanggo entuk irisan senar sing bisa diowahi, deleng cara [`split_at_mut`].
    ///
    /// [`split_at_mut`]: str::split_at_mut
    ///
    /// # Panics
    ///
    /// Panics yen `mid` ora ana ing wates titik kode UTF-8, utawa yen wis kepungkur pungkasan titik kode pungkasan irisan senar.
    ///
    ///
    /// # Examples
    ///
    /// Panggunaan dhasar:
    ///
    /// ```
    /// let s = "Per Martin-Löf";
    ///
    /// let (first, last) = s.split_at(3);
    ///
    /// assert_eq!("Per", first);
    /// assert_eq!(" Martin-Löf", last);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "str_split_at", since = "1.4.0")]
    pub fn split_at(&self, mid: usize) -> (&str, &str) {
        // is_char_boundary mriksa manawa indeks ana ing [0, .len()]
        if self.is_char_boundary(mid) {
            // SAFETY: mung mriksa yen `mid` ana ing wates char.
            unsafe { (self.get_unchecked(0..mid), self.get_unchecked(mid..self.len())) }
        } else {
            slice_error_fail(self, 0, mid)
        }
    }

    /// Dibagi siji irisan senar sing bisa diowahi dadi loro ing indeks.
    ///
    /// Argumentasi, `mid`, kudu diimbangi byte saka wiwitan senar.
    /// Sampeyan uga kudu ana ing wates titik kode UTF-8.
    ///
    /// Loro irisan kasebut bali wiwit irisan irisan nganti `mid`, lan saka `mid` nganti pungkasan irisan senar.
    ///
    /// Kanggo entuk irisan senar sing ora bisa diganti, deleng cara [`split_at`].
    ///
    /// [`split_at`]: str::split_at
    ///
    /// # Panics
    ///
    /// Panics yen `mid` ora ana ing wates titik kode UTF-8, utawa yen wis kepungkur pungkasan titik kode pungkasan irisan senar.
    ///
    ///
    /// # Examples
    ///
    /// Panggunaan dhasar:
    ///
    /// ```
    /// let mut s = "Per Martin-Löf".to_string();
    /// {
    ///     let (first, last) = s.split_at_mut(3);
    ///     first.make_ascii_uppercase();
    ///     assert_eq!("PER", first);
    ///     assert_eq!(" Martin-Löf", last);
    /// }
    /// assert_eq!("PER Martin-Löf", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "str_split_at", since = "1.4.0")]
    pub fn split_at_mut(&mut self, mid: usize) -> (&mut str, &mut str) {
        // is_char_boundary mriksa manawa indeks ana ing [0, .len()]
        if self.is_char_boundary(mid) {
            let len = self.len();
            let ptr = self.as_mut_ptr();
            // SAFETY: mung mriksa yen `mid` ana ing wates char.
            unsafe {
                (
                    from_utf8_unchecked_mut(slice::from_raw_parts_mut(ptr, mid)),
                    from_utf8_unchecked_mut(slice::from_raw_parts_mut(ptr.add(mid), len - mid)),
                )
            }
        } else {
            slice_error_fail(self, 0, mid)
        }
    }

    /// Ngasilake iterator ing irisan irisan senar.
    ///
    /// Minangka irisan senar kalebu UTF-8 sing valid, kita bisa ngatasi irisan senar kanthi [`char`].
    /// Cara iki ngasilake iterator kuwi.
    ///
    /// Perlu dielingi yen [`char`] nggambarake Nilai Skala Unicode, lan bisa uga ora cocog karo ide sampeyan babagan 'character'.
    ///
    /// kelompok-kelompok pengulangan liwat grapheme uga apa sing bener pengin.
    /// Fungsi iki ora diwenehake dening perpustakaan standar Rust, priksa crates.io.
    ///
    /// # Examples
    ///
    /// Panggunaan dhasar:
    ///
    /// ```
    /// let word = "goodbye";
    ///
    /// let count = word.chars().count();
    /// assert_eq!(7, count);
    ///
    /// let mut chars = word.chars();
    ///
    /// assert_eq!(Some('g'), chars.next());
    /// assert_eq!(Some('o'), chars.next());
    /// assert_eq!(Some('o'), chars.next());
    /// assert_eq!(Some('d'), chars.next());
    /// assert_eq!(Some('b'), chars.next());
    /// assert_eq!(Some('y'), chars.next());
    /// assert_eq!(Some('e'), chars.next());
    ///
    /// assert_eq!(None, chars.next());
    /// ```
    ///
    /// Elinga, [`char`] bisa uga ora cocog karo intuisi sampeyan babagan karakter:
    ///
    /// [`char`]: prim@char
    ///
    /// ```
    /// let y = "y̆";
    ///
    /// let mut chars = y.chars();
    ///
    /// assert_eq!(Some('y'), chars.next()); // dudu 'y̆'
    /// assert_eq!(Some('\u{0306}'), chars.next());
    ///
    /// assert_eq!(None, chars.next());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chars(&self) -> Chars<'_> {
        Chars { iter: self.as_bytes().iter() }
    }

    /// Ngasilake iterator ing irisan irisan senar, lan posisine.
    ///
    /// Minangka irisan senar kalebu UTF-8 sing valid, kita bisa ngatasi irisan senar kanthi [`char`].
    /// Cara iki ngasilake pengulangan kalorone [`char`] kasebut, uga posisi byte.
    ///
    /// iterator ing panenan tuples.Posisi pisanan, ing [`char`] punika liyane.
    ///
    /// # Examples
    ///
    /// Panggunaan dhasar:
    ///
    /// ```
    /// let word = "goodbye";
    ///
    /// let count = word.char_indices().count();
    /// assert_eq!(7, count);
    ///
    /// let mut char_indices = word.char_indices();
    ///
    /// assert_eq!(Some((0, 'g')), char_indices.next());
    /// assert_eq!(Some((1, 'o')), char_indices.next());
    /// assert_eq!(Some((2, 'o')), char_indices.next());
    /// assert_eq!(Some((3, 'd')), char_indices.next());
    /// assert_eq!(Some((4, 'b')), char_indices.next());
    /// assert_eq!(Some((5, 'y')), char_indices.next());
    /// assert_eq!(Some((6, 'e')), char_indices.next());
    ///
    /// assert_eq!(None, char_indices.next());
    /// ```
    ///
    /// Elinga, [`char`] bisa uga ora cocog karo intuisi sampeyan babagan karakter:
    ///
    /// [`char`]: prim@char
    ///
    /// ```
    /// let yes = "y̆es";
    ///
    /// let mut char_indices = yes.char_indices();
    ///
    /// assert_eq!(Some((0, 'y')), char_indices.next()); // ora (0, 'y̆')
    /// assert_eq!(Some((1, '\u{0306}')), char_indices.next());
    ///
    /// // cathet 3 ing kene, karakter pungkasan njupuk rong bait
    /// assert_eq!(Some((3, 'e')), char_indices.next());
    /// assert_eq!(Some((4, 's')), char_indices.next());
    ///
    /// assert_eq!(None, char_indices.next());
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn char_indices(&self) -> CharIndices<'_> {
        CharIndices { front_offset: 0, iter: self.chars() }
    }

    /// Pengulangan liwat bait irisan senar.
    ///
    /// Minangka irisan senar kasusun saka urutan byte, kita bisa ngetrapake irisan byte byte.
    /// Cara iki ngasilake iterator kuwi.
    ///
    /// # Examples
    ///
    /// Panggunaan dhasar:
    ///
    /// ```
    /// let mut bytes = "bors".bytes();
    ///
    /// assert_eq!(Some(b'b'), bytes.next());
    /// assert_eq!(Some(b'o'), bytes.next());
    /// assert_eq!(Some(b'r'), bytes.next());
    /// assert_eq!(Some(b's'), bytes.next());
    ///
    /// assert_eq!(None, bytes.next());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn bytes(&self) -> Bytes<'_> {
        Bytes(self.as_bytes().iter().copied())
    }

    /// Dibagi irisan senar kanthi ruang putih.
    ///
    /// Iterator sing bali bakal ngasilake irisan senar sing ana ing irisan irisan senar asli, dipisahake karo jumlah ruang putih.
    ///
    ///
    /// 'Whitespace' ditetepake miturut syarat-syarat Unicode Derried Core Properti `White_Space`.
    /// Yen sampeyan mung pengin pisah ing ruang putih ASCII, gunakake [`split_ascii_whitespace`].
    ///
    /// [`split_ascii_whitespace`]: str::split_ascii_whitespace
    ///
    /// # Examples
    ///
    /// Panggunaan dhasar:
    ///
    /// ```
    /// let mut iter = "A few words".split_whitespace();
    ///
    /// assert_eq!(Some("A"), iter.next());
    /// assert_eq!(Some("few"), iter.next());
    /// assert_eq!(Some("words"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    /// Kabeh jinis ruang putih dianggep:
    ///
    /// ```
    /// let mut iter = " Mary   had\ta\u{2009}little  \n\t lamb".split_whitespace();
    /// assert_eq!(Some("Mary"), iter.next());
    /// assert_eq!(Some("had"), iter.next());
    /// assert_eq!(Some("a"), iter.next());
    /// assert_eq!(Some("little"), iter.next());
    /// assert_eq!(Some("lamb"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[stable(feature = "split_whitespace", since = "1.1.0")]
    #[inline]
    pub fn split_whitespace(&self) -> SplitWhitespace<'_> {
        SplitWhitespace { inner: self.split(IsWhitespace).filter(IsNotEmpty) }
    }

    /// Pamisah irisan senar kanthi ruang putih ASCII.
    ///
    /// Iterator sing bali bakal ngasilake irisan senar sing ana ing irisan irisan senar asli, dipisahake karo jumlah ruang putih ASCII.
    ///
    ///
    /// Kanggo dipisahake karo Unicode `Whitespace`, gunakake [`split_whitespace`].
    ///
    /// [`split_whitespace`]: str::split_whitespace
    ///
    /// # Examples
    ///
    /// Panggunaan dhasar:
    ///
    /// ```
    /// let mut iter = "A few words".split_ascii_whitespace();
    ///
    /// assert_eq!(Some("A"), iter.next());
    /// assert_eq!(Some("few"), iter.next());
    /// assert_eq!(Some("words"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    /// Kabeh jinis ruang putih ASCII dianggep:
    ///
    /// ```
    /// let mut iter = " Mary   had\ta little  \n\t lamb".split_ascii_whitespace();
    /// assert_eq!(Some("Mary"), iter.next());
    /// assert_eq!(Some("had"), iter.next());
    /// assert_eq!(Some("a"), iter.next());
    /// assert_eq!(Some("little"), iter.next());
    /// assert_eq!(Some("lamb"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    #[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
    #[inline]
    pub fn split_ascii_whitespace(&self) -> SplitAsciiWhitespace<'_> {
        let inner =
            self.as_bytes().split(IsAsciiWhitespace).filter(BytesIsNotEmpty).map(UnsafeBytesToStr);
        SplitAsciiWhitespace { inner }
    }

    /// Iterator liwat garis senar, kaya irisan senar.
    ///
    /// Garis sing rampung karo salah siji sing newline (`\n`) utawa kreta bali karo feed line (`\r\n`).
    ///
    /// Pungkasan baris pungkasan iku opsional.
    /// A senar sing ends karo baris pungkasan final bakal ngasilake garis padha minangka senar digunakake memper tanpa baris pungkasan final.
    ///
    ///
    /// # Examples
    ///
    /// Panggunaan dhasar:
    ///
    /// ```
    /// let text = "foo\r\nbar\n\nbaz\n";
    /// let mut lines = text.lines();
    ///
    /// assert_eq!(Some("foo"), lines.next());
    /// assert_eq!(Some("bar"), lines.next());
    /// assert_eq!(Some(""), lines.next());
    /// assert_eq!(Some("baz"), lines.next());
    ///
    /// assert_eq!(None, lines.next());
    /// ```
    ///
    /// Pungkasan baris pungkasan ora dibutuhake:
    ///
    /// ```
    /// let text = "foo\nbar\n\r\nbaz";
    /// let mut lines = text.lines();
    ///
    /// assert_eq!(Some("foo"), lines.next());
    /// assert_eq!(Some("bar"), lines.next());
    /// assert_eq!(Some(""), lines.next());
    /// assert_eq!(Some("baz"), lines.next());
    ///
    /// assert_eq!(None, lines.next());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn lines(&self) -> Lines<'_> {
        Lines(self.split_terminator('\n').map(LinesAnyMap))
    }

    /// Pengulangan liwat garis senar.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.4.0", reason = "use lines() instead now")]
    #[inline]
    #[allow(deprecated)]
    pub fn lines_any(&self) -> LinesAny<'_> {
        LinesAny(self.lines())
    }

    /// Ngasilake iterator `u16` liwat string sing dienkode dadi UTF-16.
    ///
    /// # Examples
    ///
    /// Panggunaan dhasar:
    ///
    /// ```
    /// let text = "Zażółć gęślą jaźń";
    ///
    /// let utf8_len = text.len();
    /// let utf16_len = text.encode_utf16().count();
    ///
    /// assert!(utf16_len <= utf8_len);
    /// ```
    #[stable(feature = "encode_utf16", since = "1.8.0")]
    pub fn encode_utf16(&self) -> EncodeUtf16<'_> {
        EncodeUtf16 { chars: self.chars(), extra: 0 }
    }

    /// Ngasilake `true` yen pola sing diwenehake cocog karo sub-irisan irisan senar iki.
    ///
    /// Ngasilake `false` yen ora.
    ///
    /// The [pattern] bisa dadi `&str`, [`char`], irisan saka [: char`] s, utawa fungsi utawa penutupan kasus sing nemtokake menawa cocog karakter.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Panggunaan dhasar:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.contains("nana"));
    /// assert!(!bananas.contains("apples"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn contains<'a, P: Pattern<'a>>(&'a self, pat: P) -> bool {
        pat.is_contained_in(self)
    }

    /// Ngasilake `true` yen pola diwenehi cocog ater-ater saka irisan senar iki.
    ///
    /// Ngasilake `false` yen ora.
    ///
    /// The [pattern] bisa dadi `&str`, [`char`], irisan saka [: char`] s, utawa fungsi utawa penutupan kasus sing nemtokake menawa cocog karakter.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Panggunaan dhasar:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.starts_with("bana"));
    /// assert!(!bananas.starts_with("nana"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn starts_with<'a, P: Pattern<'a>>(&'a self, pat: P) -> bool {
        pat.is_prefix_of(self)
    }

    /// Ngasilake `true` yen pola sing diwenehake cocog karo akhiran irisan senar iki.
    ///
    /// Ngasilake `false` yen ora.
    ///
    /// The [pattern] bisa dadi `&str`, [`char`], irisan saka [: char`] s, utawa fungsi utawa penutupan kasus sing nemtokake menawa cocog karakter.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Panggunaan dhasar:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.ends_with("anas"));
    /// assert!(!bananas.ends_with("nana"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ends_with<'a, P>(&'a self, pat: P) -> bool
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        pat.is_suffix_of(self)
    }

    /// Ngasilake indeks byte karakter pertama irisan senar iki sing cocog karo pola.
    ///
    /// Ngasilake [`None`] yen pola ora cocog.
    ///
    /// The [pattern] bisa dadi `&str`, [`char`], irisan saka [: char`] s, utawa fungsi utawa penutupan kasus sing nemtokake menawa cocog karakter.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// pola prasaja:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard Gepardi";
    ///
    /// assert_eq!(s.find('L'), Some(0));
    /// assert_eq!(s.find('é'), Some(14));
    /// assert_eq!(s.find("pard"), Some(17));
    /// ```
    ///
    /// Pola sing luwih rumit nggunakake gaya lan penutupan tanpa titik:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// assert_eq!(s.find(char::is_whitespace), Some(5));
    /// assert_eq!(s.find(char::is_lowercase), Some(1));
    /// assert_eq!(s.find(|c: char| c.is_whitespace() || c.is_lowercase()), Some(1));
    /// assert_eq!(s.find(|c: char| (c < 'o') && (c > 'a')), Some(4));
    /// ```
    ///
    /// Ora nemokake pola:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// let x: &[_] = &['1', '2'];
    ///
    /// assert_eq!(s.find(x), None);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn find<'a, P: Pattern<'a>>(&'a self, pat: P) -> Option<usize> {
        pat.into_searcher(self).next_match().map(|(i, _)| i)
    }

    /// Ngasilake indeks bait karakter pisanan saka match paling tengen saka pola ing irisan senar iki.
    ///
    /// Ngasilake [`None`] yen pola ora cocog.
    ///
    /// The [pattern] bisa dadi `&str`, [`char`], irisan saka [: char`] s, utawa fungsi utawa penutupan kasus sing nemtokake menawa cocog karakter.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// pola prasaja:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard Gepardi";
    ///
    /// assert_eq!(s.rfind('L'), Some(13));
    /// assert_eq!(s.rfind('é'), Some(14));
    /// assert_eq!(s.rfind("pard"), Some(24));
    /// ```
    ///
    /// More pola Komplek karo nutup:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// assert_eq!(s.rfind(char::is_whitespace), Some(12));
    /// assert_eq!(s.rfind(char::is_lowercase), Some(20));
    /// ```
    ///
    /// Ora nemokake pola:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// let x: &[_] = &['1', '2'];
    ///
    /// assert_eq!(s.rfind(x), None);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rfind<'a, P>(&'a self, pat: P) -> Option<usize>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        pat.into_searcher(self).next_match_back().map(|(i, _)| i)
    }

    /// Pengulangan liwat substrings irisan senar iki, dipisahake karo karakter sing dicocogake karo pola.
    ///
    /// The [pattern] bisa dadi `&str`, [`char`], irisan saka [: char`] s, utawa fungsi utawa penutupan kasus sing nemtokake menawa cocog karakter.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Tindak tanduk Iterator
    ///
    /// Pengulangan sing bali bakal dadi [`DoubleEndedIterator`] yen pola ngidini telusuran mbalikke lan telusuran forward/reverse ngasilake elemen sing padha.
    /// Iki bener kanggo, contone, [`char`], nanging ora kanggo `&str`.
    ///
    /// Yen pola ngidini telusuran mbalikke nanging asile bisa beda karo telusuran ing ngarep, metode [`rsplit`] bisa digunakake.
    ///
    /// [`rsplit`]: str::rsplit
    ///
    /// # Examples
    ///
    /// pola prasaja:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".split(' ').collect();
    /// assert_eq!(v, ["Mary", "had", "a", "little", "lamb"]);
    ///
    /// let v: Vec<&str> = "".split('X').collect();
    /// assert_eq!(v, [""]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".split('X').collect();
    /// assert_eq!(v, ["lion", "", "tiger", "leopard"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".split("::").collect();
    /// assert_eq!(v, ["lion", "tiger", "leopard"]);
    ///
    /// let v: Vec<&str> = "abc1def2ghi".split(char::is_numeric).collect();
    /// assert_eq!(v, ["abc", "def", "ghi"]);
    ///
    /// let v: Vec<&str> = "lionXtigerXleopard".split(char::is_uppercase).collect();
    /// assert_eq!(v, ["lion", "tiger", "leopard"]);
    /// ```
    ///
    /// Yen pola kasebut minangka potongan irisan, dibagi saben kedadeyan karakter kasebut:
    ///
    /// ```
    /// let v: Vec<&str> = "2020-11-03 23:59".split(&['-', ' ', ':', '@'][..]).collect();
    /// assert_eq!(v, ["2020", "11", "03", "23", "59"]);
    /// ```
    ///
    /// Pola sing luwih kompleks, nggunakake penutupan:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".split(|c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["abc", "def", "ghi"]);
    /// ```
    ///
    /// Yen senar ngemot macem-macem pemisah, sampeyan bakal entuk tali kosong ing output:
    ///
    /// ```
    /// let x = "||||a||b|c".to_string();
    /// let d: Vec<_> = x.split('|').collect();
    ///
    /// assert_eq!(d, &["", "", "", "", "a", "", "b", "c"]);
    /// ```
    ///
    /// Pemisah contigu dipisahake karo senar kosong.
    ///
    /// ```
    /// let x = "(///)".to_string();
    /// let d: Vec<_> = x.split('/').collect();
    ///
    /// assert_eq!(d, &["(", "", "", ")"]);
    /// ```
    ///
    /// Separator ing wiwitan utawa pungkasan senar diapit karo senar kosong.
    ///
    /// ```
    /// let d: Vec<_> = "010".split("0").collect();
    /// assert_eq!(d, &["", "1", ""]);
    /// ```
    ///
    /// Nalika senar kosong digunakake minangka pamisah, pamisahan saben karakter ing senar, bebarengan karo wiwitan lan pungkasan senar kasebut.
    ///
    /// ```
    /// let f: Vec<_> = "rust".split("").collect();
    /// assert_eq!(f, &["", "r", "u", "s", "t", ""]);
    /// ```
    ///
    /// Pemisah sing gegandhengan bisa nyebabake tumindak sing kaget nalika papan putih digunakake minangka pamisah.Kode iki bener:
    ///
    /// ```
    /// let x = "    a  b c".to_string();
    /// let d: Vec<_> = x.split(' ').collect();
    ///
    /// assert_eq!(d, &["", "", "", "", "a", "", "b", "c"]);
    /// ```
    ///
    /// _not_ menehi sampeyan:
    ///
    /// ```,ignore
    /// assert_eq!(d, &["a", "b", "c"]);
    /// ```
    ///
    /// Gunakake [`split_whitespace`] kanggo tumindak iki.
    ///
    /// [`split_whitespace`]: str::split_whitespace
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split<'a, P: Pattern<'a>>(&'a self, pat: P) -> Split<'a, P> {
        Split(SplitInternal {
            start: 0,
            end: self.len(),
            matcher: pat.into_searcher(self),
            allow_trailing_empty: true,
            finished: false,
        })
    }

    /// Pengulangan liwat substrings irisan senar iki, dipisahake karo karakter sing dicocogake karo pola.
    /// Beda karo iterator sing diproduksi dening `split` ing `split_inclusive` ninggalake bagean sing cocog minangka terminator saka substring.
    ///
    ///
    /// The [pattern] bisa dadi `&str`, [`char`], irisan saka [: char`] s, utawa fungsi utawa penutupan kasus sing nemtokake menawa cocog karakter.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb\nlittle lamb\nlittle lamb."
    ///     .split_inclusive('\n').collect();
    /// assert_eq!(v, ["Mary had a little lamb\n", "little lamb\n", "little lamb."]);
    /// ```
    ///
    /// Yen unsur pungkasan saka senar cocog, elemen kasebut bakal dianggep dadi terminator saka substring sadurunge.
    /// substring sing bakal item pungkasan bali dening iterator ing.
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb\nlittle lamb\nlittle lamb.\n"
    ///     .split_inclusive('\n').collect();
    /// assert_eq!(v, ["Mary had a little lamb\n", "little lamb\n", "little lamb.\n"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive<'a, P: Pattern<'a>>(&'a self, pat: P) -> SplitInclusive<'a, P> {
        SplitInclusive(SplitInternal {
            start: 0,
            end: self.len(),
            matcher: pat.into_searcher(self),
            allow_trailing_empty: false,
            finished: false,
        })
    }

    /// Lan iterator liwat substrings saka irisan senar diwenehi, kapisah dening karakter dicocogaké dening pola lan menehi supaya mbalikke.
    ///
    /// The [pattern] bisa dadi `&str`, [`char`], irisan saka [: char`] s, utawa fungsi utawa penutupan kasus sing nemtokake menawa cocog karakter.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Tindak tanduk Iterator
    ///
    /// Pengulangan sing mbalekake mbutuhake pola ndhukung telusuran balik, lan bakal dadi [`DoubleEndedIterator`] yen telusuran forward/reverse ngasilake unsur sing padha.
    ///
    ///
    /// Kanggo iterasi saka ngarep, cara [`split`] bisa digunakake.
    ///
    /// [`split`]: str::split
    ///
    /// # Examples
    ///
    /// pola prasaja:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".rsplit(' ').collect();
    /// assert_eq!(v, ["lamb", "little", "a", "had", "Mary"]);
    ///
    /// let v: Vec<&str> = "".rsplit('X').collect();
    /// assert_eq!(v, [""]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".rsplit('X').collect();
    /// assert_eq!(v, ["leopard", "tiger", "", "lion"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".rsplit("::").collect();
    /// assert_eq!(v, ["leopard", "tiger", "lion"]);
    /// ```
    ///
    /// Pola sing luwih kompleks, nggunakake penutupan:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".rsplit(|c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["ghi", "def", "abc"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplit<'a, P>(&'a self, pat: P) -> RSplit<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplit(self.split(pat).0)
    }

    /// Pengulangan liwat substrings irisan senar sing diwenehake, dipisahake karo karakter sing dicocogake karo pola.
    ///
    /// The [pattern] bisa dadi `&str`, [`char`], irisan saka [: char`] s, utawa fungsi utawa penutupan kasus sing nemtokake menawa cocog karakter.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// Padha [`split`], kajaba sing mburine substring wis Mlayu yen kosong.
    ///
    /// [`split`]: str::split
    ///
    /// Cara iki bisa digunakake kanggo data senar sing _terminated_, tinimbang _separated_ dening pola.
    ///
    /// # Tindak tanduk Iterator
    ///
    /// Pengulangan sing bali bakal dadi [`DoubleEndedIterator`] yen pola ngidini telusuran mbalikke lan telusuran forward/reverse ngasilake elemen sing padha.
    /// Iki bener kanggo, contone, [`char`], nanging ora kanggo `&str`.
    ///
    /// Yen pola ngidini telusuran mbalikke nanging asile bisa beda karo telusuran ing ngarep, metode [`rsplit_terminator`] bisa digunakake.
    ///
    /// [`rsplit_terminator`]: str::rsplit_terminator
    ///
    /// # Examples
    ///
    /// Panggunaan dhasar:
    ///
    /// ```
    /// let v: Vec<&str> = "A.B.".split_terminator('.').collect();
    /// assert_eq!(v, ["A", "B"]);
    ///
    /// let v: Vec<&str> = "A..B..".split_terminator(".").collect();
    /// assert_eq!(v, ["A", "", "B", ""]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_terminator<'a, P: Pattern<'a>>(&'a self, pat: P) -> SplitTerminator<'a, P> {
        SplitTerminator(SplitInternal { allow_trailing_empty: false, ..self.split(pat).0 })
    }

    /// Lan iterator liwat substrings saka `self`, kapisah dening karakter dicocogaké dening pola lan menehi supaya mbalikke.
    ///
    /// The [pattern] bisa dadi `&str`, [`char`], irisan saka [: char`] s, utawa fungsi utawa penutupan kasus sing nemtokake menawa cocog karakter.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// Padha [`split`], kajaba sing mburine substring wis Mlayu yen kosong.
    ///
    /// [`split`]: str::split
    ///
    /// Cara iki bisa digunakake kanggo data senar sing _terminated_, tinimbang _separated_ dening pola.
    ///
    /// # Tindak tanduk Iterator
    ///
    /// Bali iterator mbutuhake pola ndhukung search mbalikke, lan bakal pindho rampung menawa search forward/reverse panenan unsur padha.
    ///
    ///
    /// Kanggo mbaleni saka ngarep, cara [`split_terminator`] bisa digunakake.
    ///
    /// [`split_terminator`]: str::split_terminator
    ///
    /// # Examples
    ///
    /// ```
    /// let v: Vec<&str> = "A.B.".rsplit_terminator('.').collect();
    /// assert_eq!(v, ["B", "A"]);
    ///
    /// let v: Vec<&str> = "A..B..".rsplit_terminator(".").collect();
    /// assert_eq!(v, ["", "B", "", "A"]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplit_terminator<'a, P>(&'a self, pat: P) -> RSplitTerminator<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplitTerminator(self.split_terminator(pat).0)
    }

    /// Lan iterator liwat substrings saka irisan senar diwenehi, kapisah dening pola, diwatesi kanggo bali ing paling `n` item.
    ///
    /// Yen substring `n` bali, substring pungkasan (substring `n`th) bakal ngemot sisa senar.
    ///
    /// The [pattern] bisa dadi `&str`, [`char`], irisan saka [: char`] s, utawa fungsi utawa penutupan kasus sing nemtokake menawa cocog karakter.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Tindak tanduk Iterator
    ///
    /// Bali iterator ora bakal pindho rampung, amarga iku ora efisien kanggo ndhukung.
    ///
    /// Yen pola ngidini telusuran mbalikke, metode [`rsplitn`] bisa digunakake.
    ///
    /// [`rsplitn`]: str::rsplitn
    ///
    /// # Examples
    ///
    /// pola prasaja:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lambda".splitn(3, ' ').collect();
    /// assert_eq!(v, ["Mary", "had", "a little lambda"]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".splitn(3, "X").collect();
    /// assert_eq!(v, ["lion", "", "tigerXleopard"]);
    ///
    /// let v: Vec<&str> = "abcXdef".splitn(1, 'X').collect();
    /// assert_eq!(v, ["abcXdef"]);
    ///
    /// let v: Vec<&str> = "".splitn(1, 'X').collect();
    /// assert_eq!(v, [""]);
    /// ```
    ///
    /// Pola sing luwih kompleks, nggunakake penutupan:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".splitn(2, |c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["abc", "defXghi"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn<'a, P: Pattern<'a>>(&'a self, n: usize, pat: P) -> SplitN<'a, P> {
        SplitN(SplitNInternal { iter: self.split(pat).0, count: n })
    }

    /// Iterator liwat substrings irisan senar iki, dipisahake kanthi pola, wiwit saka pungkasan senar, diwatesi bali ing paling akeh item `n`.
    ///
    ///
    /// Yen substring `n` bali, substring pungkasan (substring `n`th) bakal ngemot sisa senar.
    ///
    /// The [pattern] bisa dadi `&str`, [`char`], irisan saka [: char`] s, utawa fungsi utawa penutupan kasus sing nemtokake menawa cocog karakter.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Tindak tanduk Iterator
    ///
    /// Bali iterator ora bakal pindho rampung, amarga iku ora efisien kanggo ndhukung.
    ///
    /// Kanggo pisah saka sisih ngarep, cara [`splitn`] bisa digunakake.
    ///
    /// [`splitn`]: str::splitn
    ///
    /// # Examples
    ///
    /// pola prasaja:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".rsplitn(3, ' ').collect();
    /// assert_eq!(v, ["lamb", "little", "Mary had a"]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".rsplitn(3, 'X').collect();
    /// assert_eq!(v, ["leopard", "tiger", "lionX"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".rsplitn(2, "::").collect();
    /// assert_eq!(v, ["leopard", "lion::tiger"]);
    /// ```
    ///
    /// Pola sing luwih kompleks, nggunakake penutupan:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".rsplitn(2, |c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["ghi", "abc1def"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn<'a, P>(&'a self, n: usize, pat: P) -> RSplitN<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplitN(self.splitn(n, pat).0)
    }

    /// Pamisahan senar ing kedadeyan pisanan ing delimiter kasebut lan ngasilake ater sadurunge delimiter lan seselan sawise delimiter.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("cfg".split_once('='), None);
    /// assert_eq!("cfg=foo".split_once('='), Some(("cfg", "foo")));
    /// assert_eq!("cfg=foo=bar".split_once('='), Some(("cfg", "foo=bar")));
    /// ```
    #[stable(feature = "str_split_once", since = "1.52.0")]
    #[inline]
    pub fn split_once<'a, P: Pattern<'a>>(&'a self, delimiter: P) -> Option<(&'a str, &'a str)> {
        let (start, end) = delimiter.into_searcher(self).next_match()?;
        Some((&self[..start], &self[end..]))
    }

    /// Misah senar ing kedadeyan pungkasan saka pembatas sing ditemtokake lan ngasilake awalan sadurunge pembates lan akhiran sawise pembates.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("cfg".rsplit_once('='), None);
    /// assert_eq!("cfg=foo".rsplit_once('='), Some(("cfg", "foo")));
    /// assert_eq!("cfg=foo=bar".rsplit_once('='), Some(("cfg=foo", "bar")));
    /// ```
    #[stable(feature = "str_split_once", since = "1.52.0")]
    #[inline]
    pub fn rsplit_once<'a, P>(&'a self, delimiter: P) -> Option<(&'a str, &'a str)>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        let (start, end) = delimiter.into_searcher(self).next_match_back()?;
        Some((&self[..start], &self[end..]))
    }

    /// Pengulangan cocog karo pola sing cocog ing irisan senar sing diwenehake.
    ///
    /// The [pattern] bisa dadi `&str`, [`char`], irisan saka [: char`] s, utawa fungsi utawa penutupan kasus sing nemtokake menawa cocog karakter.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Tindak tanduk Iterator
    ///
    /// Pengulangan sing bali bakal dadi [`DoubleEndedIterator`] yen pola ngidini telusuran mbalikke lan telusuran forward/reverse ngasilake elemen sing padha.
    /// Iki bener kanggo, contone, [`char`], nanging ora kanggo `&str`.
    ///
    /// Yen pola ngidini search mbalikke nanging asil sawijining bisa beda-beda saka search maju, cara [`rmatches`] bisa digunakake.
    ///
    /// [`rmatches`]: str::matches
    ///
    /// # Examples
    ///
    /// Panggunaan dhasar:
    ///
    /// ```
    /// let v: Vec<&str> = "abcXXXabcYYYabc".matches("abc").collect();
    /// assert_eq!(v, ["abc", "abc", "abc"]);
    ///
    /// let v: Vec<&str> = "1abc2abc3".matches(char::is_numeric).collect();
    /// assert_eq!(v, ["1", "2", "3"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "str_matches", since = "1.2.0")]
    #[inline]
    pub fn matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> Matches<'a, P> {
        Matches(MatchesInternal(pat.into_searcher(self)))
    }

    /// Iterator ing match sing cocog karo pola ing irisan senar iki, ngasilake kanthi urutan mbalikke.
    ///
    /// The [pattern] bisa dadi `&str`, [`char`], irisan saka [: char`] s, utawa fungsi utawa penutupan kasus sing nemtokake menawa cocog karakter.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Tindak tanduk Iterator
    ///
    /// Pengulangan sing mbalekake mbutuhake pola ndhukung telusuran balik, lan bakal dadi [`DoubleEndedIterator`] yen telusuran forward/reverse ngasilake unsur sing padha.
    ///
    ///
    /// Kanggo mbaleni saka ngarep, cara [`matches`] bisa digunakake.
    ///
    /// [`matches`]: str::matches
    ///
    /// # Examples
    ///
    /// Panggunaan dhasar:
    ///
    /// ```
    /// let v: Vec<&str> = "abcXXXabcYYYabc".rmatches("abc").collect();
    /// assert_eq!(v, ["abc", "abc", "abc"]);
    ///
    /// let v: Vec<&str> = "1abc2abc3".rmatches(char::is_numeric).collect();
    /// assert_eq!(v, ["3", "2", "1"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "str_matches", since = "1.2.0")]
    #[inline]
    pub fn rmatches<'a, P>(&'a self, pat: P) -> RMatches<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RMatches(self.matches(pat).0)
    }

    /// Iterator ing match sing cocog karo pola ing irisan senar iki uga indeks sing diwiwiti match kasebut.
    ///
    /// Kanggo pertandhingan `pat` ing `self` sing tumpang tindih, mung indeks cocog kanggo pertandhingan pisanan sing bali.
    ///
    /// The [pattern] bisa dadi `&str`, [`char`], irisan saka [: char`] s, utawa fungsi utawa penutupan kasus sing nemtokake menawa cocog karakter.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Tindak tanduk Iterator
    ///
    /// Pengulangan sing bali bakal dadi [`DoubleEndedIterator`] yen pola ngidini telusuran mbalikke lan telusuran forward/reverse ngasilake elemen sing padha.
    /// Iki bener kanggo, contone, [`char`], nanging ora kanggo `&str`.
    ///
    /// Yen pola ngidini search mbalikke nanging asil sawijining bisa beda-beda saka search maju, cara [`rmatch_indices`] bisa digunakake.
    ///
    /// [`rmatch_indices`]: str::match_indices
    ///
    /// # Examples
    ///
    /// Panggunaan dhasar:
    ///
    /// ```
    /// let v: Vec<_> = "abcXXXabcYYYabc".match_indices("abc").collect();
    /// assert_eq!(v, [(0, "abc"), (6, "abc"), (12, "abc")]);
    ///
    /// let v: Vec<_> = "1abcabc2".match_indices("abc").collect();
    /// assert_eq!(v, [(1, "abc"), (4, "abc")]);
    ///
    /// let v: Vec<_> = "ababa".match_indices("aba").collect();
    /// assert_eq!(v, [(0, "aba")]); // mung `aba` pisanan
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "str_match_indices", since = "1.5.0")]
    #[inline]
    pub fn match_indices<'a, P: Pattern<'a>>(&'a self, pat: P) -> MatchIndices<'a, P> {
        MatchIndices(MatchIndicesInternal(pat.into_searcher(self)))
    }

    /// Lan iterator liwat disjoint cocog saka pola ing `self`, menehi supaya mbalikke bebarengan karo indeks saka match.
    ///
    /// Kanggo pertandhingan `pat` ing `self` sing tumpang tindih, mung indeks cocog kanggo pertandhingan pungkasan sing bali.
    ///
    /// The [pattern] bisa dadi `&str`, [`char`], irisan saka [: char`] s, utawa fungsi utawa penutupan kasus sing nemtokake menawa cocog karakter.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Tindak tanduk Iterator
    ///
    /// Pengulangan sing mbalekake mbutuhake pola ndhukung telusuran balik, lan bakal dadi [`DoubleEndedIterator`] yen telusuran forward/reverse ngasilake unsur sing padha.
    ///
    ///
    /// Kanggo iterasi saka ngarep, cara [`match_indices`] bisa digunakake.
    ///
    /// [`match_indices`]: str::match_indices
    ///
    /// # Examples
    ///
    /// Panggunaan dhasar:
    ///
    /// ```
    /// let v: Vec<_> = "abcXXXabcYYYabc".rmatch_indices("abc").collect();
    /// assert_eq!(v, [(12, "abc"), (6, "abc"), (0, "abc")]);
    ///
    /// let v: Vec<_> = "1abcabc2".rmatch_indices("abc").collect();
    /// assert_eq!(v, [(4, "abc"), (1, "abc")]);
    ///
    /// let v: Vec<_> = "ababa".rmatch_indices("aba").collect();
    /// assert_eq!(v, [(2, "aba")]); // mung `aba` pungkasan
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "str_match_indices", since = "1.5.0")]
    #[inline]
    pub fn rmatch_indices<'a, P>(&'a self, pat: P) -> RMatchIndices<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RMatchIndices(self.match_indices(pat).0)
    }

    /// Ngasilake irisan senar kanthi spasi putih sing dipimpin lan dilacak.
    ///
    /// 'Whitespace' ditetepake miturut syarat-syarat Unicode Derried Core Properti `White_Space`.
    ///
    ///
    /// # Examples
    ///
    /// Panggunaan dhasar:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!("Hello\tworld", s.trim());
    /// ```
    #[inline]
    #[must_use = "this returns the trimmed string as a slice, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn trim(&self) -> &str {
        self.trim_matches(|c: char| c.is_whitespace())
    }

    /// Ngasilake irisan senar kanthi spasi putih sing dipimpin.
    ///
    /// 'Whitespace' ditetepake miturut syarat-syarat Unicode Derried Core Properti `White_Space`.
    ///
    /// # Arahan teks
    ///
    /// Senar yaiku urutan byte.
    /// `start` ing konteks iki tegese posisi pertama senar bait kasebut;kanggo basa kiwa-kanggo-tengen kaya Inggris utawa Rusia, iki bakal sisih kiwa, lan basa-tengen kanggo-ngiwa kaya Arab utawa Ibrani, iki bakal sisih tengen.
    ///
    ///
    /// # Examples
    ///
    /// Panggunaan dhasar:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    /// assert_eq!("Hello\tworld\t", s.trim_start());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English  ";
    /// assert!(Some('E') == s.trim_start().chars().next());
    ///
    /// let s = "  עברית  ";
    /// assert!(Some('ע') == s.trim_start().chars().next());
    /// ```
    ///
    ///
    #[inline]
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_start(&self) -> &str {
        self.trim_start_matches(|c: char| c.is_whitespace())
    }

    /// Ngasilake senar irisan karo mburine whitespace dibusak.
    ///
    /// 'Whitespace' ditetepake miturut syarat-syarat Unicode Derried Core Properti `White_Space`.
    ///
    /// # Arahan teks
    ///
    /// Senar yaiku urutan byte.
    /// `end` ing kontèks sing tegesé posisi pungkasan sing bait senar;kanggo basa kiwa-tengen kaya Inggris utawa Rusia, iki bakal dadi sisih tengen, lan kanggo basa kiwa-kiwa kaya Arab utawa Ibrani, iki bakal dadi sisih kiwa.
    ///
    ///
    /// # Examples
    ///
    /// Panggunaan dhasar:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    /// assert_eq!(" Hello\tworld", s.trim_end());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English  ";
    /// assert!(Some('h') == s.trim_end().chars().rev().next());
    ///
    /// let s = "  עברית  ";
    /// assert!(Some('ת') == s.trim_end().chars().rev().next());
    /// ```
    ///
    ///
    #[inline]
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_end(&self) -> &str {
        self.trim_end_matches(|c: char| c.is_whitespace())
    }

    /// Ngasilake irisan senar kanthi spasi putih sing dipimpin.
    ///
    /// 'Whitespace' ditetepake miturut syarat-syarat Unicode Derried Core Properti `White_Space`.
    ///
    /// # Arahan teks
    ///
    /// Senar yaiku urutan byte.
    /// 'Left' ing konteks iki tegese posisi pertama senar bait kasebut;kanggo basa kaya Arab utawa Ibrani sing 'nengen ngiwa' tinimbang 'kiwa nengen', iki bakal dadi sisih _right_, dudu sisih kiwa.
    ///
    ///
    /// # Examples
    ///
    /// Panggunaan dhasar:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!("Hello\tworld\t", s.trim_left());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English";
    /// assert!(Some('E') == s.trim_left().chars().next());
    ///
    /// let s = "  עברית";
    /// assert!(Some('ע') == s.trim_left().chars().next());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_start`",
        suggestion = "trim_start"
    )]
    pub fn trim_left(&self) -> &str {
        self.trim_start()
    }

    /// Ngasilake senar irisan karo mburine whitespace dibusak.
    ///
    /// 'Whitespace' ditetepake miturut syarat-syarat Unicode Derried Core Properti `White_Space`.
    ///
    /// # Arahan teks
    ///
    /// Senar yaiku urutan byte.
    /// 'Right' ing konteks iki tegese posisi pungkasan senar bait kasebut;kanggo basa kaya Arab utawa Ibrani sing 'nengen ngiwa' tinimbang 'kiwa nengen', iki bakal dadi sisih _left_, dudu sisih tengen.
    ///
    ///
    /// # Examples
    ///
    /// Panggunaan dhasar:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!(" Hello\tworld", s.trim_right());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "English  ";
    /// assert!(Some('h') == s.trim_right().chars().rev().next());
    ///
    /// let s = "עברית  ";
    /// assert!(Some('ת') == s.trim_right().chars().rev().next());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_end`",
        suggestion = "trim_end"
    )]
    pub fn trim_right(&self) -> &str {
        self.trim_end()
    }

    /// Ngasilake irisan senar kanthi kabeh prefiks lan akhiran sing cocog karo pola sing dibuwang bola-bali.
    ///
    /// The [pattern] bisa dadi [`char`], irisan saka [: char`] s, utawa fungsi utawa penutupan kasus sing nemtokake menawa cocog karakter.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// pola prasaja:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_matches('1'), "foo1bar");
    /// assert_eq!("123foo1bar123".trim_matches(char::is_numeric), "foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_matches(x), "foo1bar");
    /// ```
    ///
    /// Pola sing luwih kompleks, nggunakake penutupan:
    ///
    /// ```
    /// assert_eq!("1foo1barXX".trim_matches(|c| c == '1' || c == 'X'), "foo1bar");
    /// ```
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn trim_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: DoubleEndedSearcher<'a>>,
    {
        let mut i = 0;
        let mut j = 0;
        let mut matcher = pat.into_searcher(self);
        if let Some((a, b)) = matcher.next_reject() {
            i = a;
            j = b; // Elingi match sing paling dikenal sadurunge, benerna ing ngisor iki yen
            // pertandingan terakhir beda
        }
        if let Some((_, b)) = matcher.next_reject_back() {
            j = b;
        }
        // SAFETY: `Searcher` dikenal bisa ngasilake indeks sing valid.
        unsafe { self.get_unchecked(i..j) }
    }

    /// Ngasilake irisan senar karo kabeh Préfiks sing cocog pola bola-bali dibusak.
    ///
    /// The [pattern] bisa dadi `&str`, [`char`], irisan saka [: char`] s, utawa fungsi utawa penutupan kasus sing nemtokake menawa cocog karakter.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Arahan teks
    ///
    /// Senar yaiku urutan byte.
    /// `start` ing konteks iki tegese posisi pertama senar bait kasebut;kanggo basa kiwa-kanggo-tengen kaya Inggris utawa Rusia, iki bakal sisih kiwa, lan basa-tengen kanggo-ngiwa kaya Arab utawa Ibrani, iki bakal sisih tengen.
    ///
    ///
    /// # Examples
    ///
    /// Panggunaan dhasar:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_start_matches('1'), "foo1bar11");
    /// assert_eq!("123foo1bar123".trim_start_matches(char::is_numeric), "foo1bar123");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_start_matches(x), "foo1bar12");
    /// ```
    ///
    ///
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_start_matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> &'a str {
        let mut i = self.len();
        let mut matcher = pat.into_searcher(self);
        if let Some((a, _)) = matcher.next_reject() {
            i = a;
        }
        // SAFETY: `Searcher` dikenal bisa ngasilake indeks sing valid.
        unsafe { self.get_unchecked(i..self.len()) }
    }

    /// Ngasilake irisan senar kanthi mbusak prefiks.
    ///
    /// Yen senar diwiwiti karo pola `prefix`, ngasilake substring sawise prefiks, dibungkus `Some`.
    /// Boten kados `trim_start_matches`, cara iki mbusak ater-ater ing persis sapisan.
    ///
    /// Yen senar ora diwiwiti karo `prefix`, ngasilake `None`.
    ///
    /// The [pattern] bisa dadi `&str`, [`char`], irisan saka [: char`] s, utawa fungsi utawa penutupan kasus sing nemtokake menawa cocog karakter.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("foo:bar".strip_prefix("foo:"), Some("bar"));
    /// assert_eq!("foo:bar".strip_prefix("bar"), None);
    /// assert_eq!("foofoo".strip_prefix("foo"), Some("foo"));
    /// ```
    #[must_use = "this returns the remaining substring as a new slice, \
                  without modifying the original"]
    #[stable(feature = "str_strip", since = "1.45.0")]
    pub fn strip_prefix<'a, P: Pattern<'a>>(&'a self, prefix: P) -> Option<&'a str> {
        prefix.strip_prefix_of(self)
    }

    /// Baliake irisan senar kanthi seselan sing dicopot.
    ///
    /// Yen senar diakhiri nganggo pola `suffix`, ngasilake substring sadurunge seselan, dibungkus `Some`.
    /// Beda karo `trim_end_matches`, cara iki mbusak akhiran persis sapisan.
    ///
    /// Yen senar ora mungkasi karo `suffix`, ngasilake `None`.
    ///
    /// The [pattern] bisa dadi `&str`, [`char`], irisan saka [: char`] s, utawa fungsi utawa penutupan kasus sing nemtokake menawa cocog karakter.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("bar:foo".strip_suffix(":foo"), Some("bar"));
    /// assert_eq!("bar:foo".strip_suffix("bar"), None);
    /// assert_eq!("foofoo".strip_suffix("foo"), Some("foo"));
    /// ```
    #[must_use = "this returns the remaining substring as a new slice, \
                  without modifying the original"]
    #[stable(feature = "str_strip", since = "1.45.0")]
    pub fn strip_suffix<'a, P>(&'a self, suffix: P) -> Option<&'a str>
    where
        P: Pattern<'a>,
        <P as Pattern<'a>>::Searcher: ReverseSearcher<'a>,
    {
        suffix.strip_suffix_of(self)
    }

    /// Ngasilake irisan senar kanthi kabeh akhiran sing cocog karo pola sing dibuwang bola-bali.
    ///
    /// The [pattern] bisa dadi `&str`, [`char`], irisan saka [: char`] s, utawa fungsi utawa penutupan kasus sing nemtokake menawa cocog karakter.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Arahan teks
    ///
    /// Senar yaiku urutan byte.
    /// `end` ing kontèks sing tegesé posisi pungkasan sing bait senar;kanggo basa kiwa-tengen kaya Inggris utawa Rusia, iki bakal dadi sisih tengen, lan kanggo basa kiwa-kiwa kaya Arab utawa Ibrani, iki bakal dadi sisih kiwa.
    ///
    ///
    /// # Examples
    ///
    /// pola prasaja:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_end_matches('1'), "11foo1bar");
    /// assert_eq!("123foo1bar123".trim_end_matches(char::is_numeric), "123foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_end_matches(x), "12foo1bar");
    /// ```
    ///
    /// Pola sing luwih kompleks, nggunakake penutupan:
    ///
    /// ```
    /// assert_eq!("1fooX".trim_end_matches(|c| c == '1' || c == 'X'), "1foo");
    /// ```
    ///
    ///
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_end_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        let mut j = 0;
        let mut matcher = pat.into_searcher(self);
        if let Some((_, b)) = matcher.next_reject_back() {
            j = b;
        }
        // SAFETY: `Searcher` dikenal bisa ngasilake indeks sing valid.
        unsafe { self.get_unchecked(0..j) }
    }

    /// Ngasilake irisan senar karo kabeh Préfiks sing cocog pola bola-bali dibusak.
    ///
    /// The [pattern] bisa dadi `&str`, [`char`], irisan saka [: char`] s, utawa fungsi utawa penutupan kasus sing nemtokake menawa cocog karakter.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Arahan teks
    ///
    /// Senar yaiku urutan byte.
    /// 'Left' ing konteks iki tegese posisi pertama senar bait kasebut;kanggo basa kaya Arab utawa Ibrani sing 'nengen ngiwa' tinimbang 'kiwa nengen', iki bakal dadi sisih _right_, dudu sisih kiwa.
    ///
    ///
    /// # Examples
    ///
    /// Panggunaan dhasar:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_left_matches('1'), "foo1bar11");
    /// assert_eq!("123foo1bar123".trim_left_matches(char::is_numeric), "foo1bar123");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_left_matches(x), "foo1bar12");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_start_matches`",
        suggestion = "trim_start_matches"
    )]
    pub fn trim_left_matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> &'a str {
        self.trim_start_matches(pat)
    }

    /// Ngasilake irisan senar kanthi kabeh akhiran sing cocog karo pola sing dibuwang bola-bali.
    ///
    /// The [pattern] bisa dadi `&str`, [`char`], irisan saka [: char`] s, utawa fungsi utawa penutupan kasus sing nemtokake menawa cocog karakter.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Arahan teks
    ///
    /// Senar yaiku urutan byte.
    /// 'Right' ing konteks iki tegese posisi pungkasan senar bait kasebut;kanggo basa kaya Arab utawa Ibrani sing 'nengen ngiwa' tinimbang 'kiwa nengen', iki bakal dadi sisih _left_, dudu sisih tengen.
    ///
    ///
    /// # Examples
    ///
    /// pola prasaja:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_right_matches('1'), "11foo1bar");
    /// assert_eq!("123foo1bar123".trim_right_matches(char::is_numeric), "123foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_right_matches(x), "12foo1bar");
    /// ```
    ///
    /// Pola sing luwih kompleks, nggunakake penutupan:
    ///
    /// ```
    /// assert_eq!("1fooX".trim_right_matches(|c| c == '1' || c == 'X'), "1foo");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_end_matches`",
        suggestion = "trim_end_matches"
    )]
    pub fn trim_right_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        self.trim_end_matches(pat)
    }

    /// Geser irisan senar iki dadi jinis liyane.
    ///
    /// Amarga `parse` umume, bisa nyebabake masalah inferensi jinis.
    /// Kayane, `parse` minangka salah sawijining sawetara kali sampeyan bakal weruh sintaksis sing dikenal kanthi jeneng 'turbofish': `::<>`.
    ///
    /// Iki mbantu algoritma kesimpulan ngerti khusus ngetik sampeyan lagi nyoba kanggo njlentrehake menyang.
    ///
    /// `parse` bisa diuripake menyang jinis apa wae sing ngetrapake [`FromStr`] trait.
    ///

    /// # Errors
    ///
    /// Bakal ngasilake [`Err`] yen iku ora bisa kanggo njlentrehake irisan senar iki menyang jinis dikarepake.
    ///
    ///
    /// [`Err`]: FromStr::Err
    ///
    /// # Examples
    ///
    /// Panggunaan dhasar
    ///
    /// ```
    /// let four: u32 = "4".parse().unwrap();
    ///
    /// assert_eq!(4, four);
    /// ```
    ///
    /// Nggunakake 'turbofish' tinimbang nyathet `four`:
    ///
    /// ```
    /// let four = "4".parse::<u32>();
    ///
    /// assert_eq!(Ok(4), four);
    /// ```
    ///
    /// Gagal di parse:
    ///
    /// ```
    /// let nope = "j".parse::<u32>();
    ///
    /// assert!(nope.is_err());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn parse<F: FromStr>(&self) -> Result<F, F::Err> {
        FromStr::from_str(self)
    }

    /// Priksa manawa kabeh karakter ing string iki ana ing kisaran ASCII.
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = "hello!\n";
    /// let non_ascii = "Grüße, Jürgen ❤";
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        // Kita bisa nganggep saben byte minangka karakter ing kene: kabeh karakter multibyte diwiwiti kanthi byte sing ora ana ing kisaran ascii, mula kita bakal mandheg ing kono.
        //
        //
        self.as_bytes().is_ascii()
    }

    /// Priksa manawa rong senar minangka match case-sensitif ASCII.
    ///
    /// Padha karo `to_ascii_lowercase(a) == to_ascii_lowercase(b)`, nanging tanpa alokasi lan nyalin sementara.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert!("Ferris".eq_ignore_ascii_case("FERRIS"));
    /// assert!("Ferrös".eq_ignore_ascii_case("FERRöS"));
    /// assert!(!"Ferrös".eq_ignore_ascii_case("FERRÖS"));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &str) -> bool {
        self.as_bytes().eq_ignore_ascii_case(other.as_bytes())
    }

    /// Ngowahi senar iki menyang sing padha ing ASCII sing padha ing ndhuwur.
    ///
    /// Huruf ASCII 'a' dadi 'z' dipetakan menyang 'A' dadi 'Z', nanging huruf non-ASCII ora owah.
    ///
    /// Kanggo ngasilake angka ndhuwur sing anyar tanpa ngowahi sing ana, gunakake [`to_ascii_uppercase()`].
    ///
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("Grüße, Jürgen ❤");
    ///
    /// s.make_ascii_uppercase();
    ///
    /// assert_eq!("GRüßE, JüRGEN ❤", s);
    /// ```
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        // SAFETY: aman amarga kita ngirim rong jinis kanthi tata letak sing padha.
        let me = unsafe { self.as_bytes_mut() };
        me.make_ascii_uppercase()
    }

    /// Ngonversi string iki menyang ASCII cilik sing padha karo ing panggonan.
    ///
    /// Huruf ASCII 'A' dadi 'Z' dipetakan menyang 'a' dadi 'z', nanging huruf non-ASCII ora owah.
    ///
    /// Kanggo bali Nilai lowercased anyar tanpa ngowahi siji ana, nggunakake [`to_ascii_lowercase()`].
    ///
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("GRÜßE, JÜRGEN ❤");
    ///
    /// s.make_ascii_lowercase();
    ///
    /// assert_eq!("grÜße, jÜrgen ❤", s);
    /// ```
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        // SAFETY: aman amarga kita ngirim rong jinis kanthi tata letak sing padha.
        let me = unsafe { self.as_bytes_mut() };
        me.make_ascii_lowercase()
    }

    /// Baleni iterator sing bisa uwal saben char ing `self` nganggo [`char::escape_debug`].
    ///
    ///
    /// Note: mung codepoints grapheme sing ditambahi sing miwiti senar bakal bisa uwal.
    ///
    /// # Examples
    ///
    /// Minangka pengulangan:
    ///
    /// ```
    /// for c in "❤\n!".escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Nggunakake `println!` langsung:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_debug());
    /// ```
    ///
    /// Loro-lorone padha:
    ///
    /// ```
    /// println!("❤\\n!");
    /// ```
    ///
    /// Nggunakake `to_string`:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_debug().to_string(), "❤\\n!");
    /// ```
    ///
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_debug(&self) -> EscapeDebug<'_> {
        let mut chars = self.chars();
        EscapeDebug {
            inner: chars
                .next()
                .map(|first| first.escape_debug_ext(true))
                .into_iter()
                .flatten()
                .chain(chars.flat_map(CharEscapeDebugContinue)),
        }
    }

    /// Wangsul lan iterator sing oncat saben char ing `self` karo [`char::escape_default`].
    ///
    ///
    /// # Examples
    ///
    /// Minangka pengulangan:
    ///
    /// ```
    /// for c in "❤\n!".escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Nggunakake `println!` langsung:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_default());
    /// ```
    ///
    /// Loro-lorone padha:
    ///
    /// ```
    /// println!("\\u{{2764}}\\n!");
    /// ```
    ///
    /// Nggunakake `to_string`:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_default().to_string(), "\\u{2764}\\n!");
    /// ```
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_default(&self) -> EscapeDefault<'_> {
        EscapeDefault { inner: self.chars().flat_map(CharEscapeDefault) }
    }

    /// Baleni iterator sing bisa uwal saben char ing `self` nganggo [`char::escape_unicode`].
    ///
    ///
    /// # Examples
    ///
    /// Minangka pengulangan:
    ///
    /// ```
    /// for c in "❤\n!".escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Nggunakake `println!` langsung:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_unicode());
    /// ```
    ///
    /// Loro-lorone padha:
    ///
    /// ```
    /// println!("\\u{{2764}}\\u{{a}}\\u{{21}}");
    /// ```
    ///
    /// Nggunakake `to_string`:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_unicode().to_string(), "\\u{2764}\\u{a}\\u{21}");
    /// ```
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_unicode(&self) -> EscapeUnicode<'_> {
        EscapeUnicode { inner: self.chars().flat_map(CharEscapeUnicode) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<[u8]> for str {
    #[inline]
    fn as_ref(&self) -> &[u8] {
        self.as_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Default for &str {
    /// Nggawe str kosong
    #[inline]
    fn default() -> Self {
        ""
    }
}

#[stable(feature = "default_mut_str", since = "1.28.0")]
impl Default for &mut str {
    /// Nggawe str mutable P
    #[inline]
    fn default() -> Self {
        // SAFETY: Senar kosong valid UTF-8.
        unsafe { from_utf8_unchecked_mut(&mut []) }
    }
}

impl_fn_for_zst! {
    /// A nameable, jinis fn cloneable
    #[derive(Clone)]
    struct LinesAnyMap impl<'a> Fn = |line: &'a str| -> &'a str {
        let l = line.len();
        if l > 0 && line.as_bytes()[l - 1] == b'\r' { &line[0 .. l - 1] }
        else { line }
    };

    #[derive(Clone)]
    struct CharEscapeDebugContinue impl Fn = |c: char| -> char::EscapeDebug {
        c.escape_debug_ext(false)
    };

    #[derive(Clone)]
    struct CharEscapeUnicode impl Fn = |c: char| -> char::EscapeUnicode {
        c.escape_unicode()
    };
    #[derive(Clone)]
    struct CharEscapeDefault impl Fn = |c: char| -> char::EscapeDefault {
        c.escape_default()
    };

    #[derive(Clone)]
    struct IsWhitespace impl Fn = |c: char| -> bool {
        c.is_whitespace()
    };

    #[derive(Clone)]
    struct IsAsciiWhitespace impl Fn = |byte: &u8| -> bool {
        byte.is_ascii_whitespace()
    };

    #[derive(Clone)]
    struct IsNotEmpty impl<'a, 'b> Fn = |s: &'a &'b str| -> bool {
        !s.is_empty()
    };

    #[derive(Clone)]
    struct BytesIsNotEmpty impl<'a, 'b> Fn = |s: &'a &'b [u8]| -> bool {
        !s.is_empty()
    };

    #[derive(Clone)]
    struct UnsafeBytesToStr impl<'a> Fn = |bytes: &'a [u8]| -> &'a str {
        // SAFETY: ora aman
        unsafe { from_utf8_unchecked(bytes) }
    };
}