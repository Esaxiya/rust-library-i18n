//! nindakake Trait kanggo `str`.

use crate::cmp::Ordering;
use crate::ops;
use crate::ptr;
use crate::slice::SliceIndex;

use super::ParseBoolError;

/// Ngleksanakake nindakake senar.
///
/// String dipesen [lexicographically](Ord#lexicographical-comparison) kanthi nilai byte.
/// pesenan kode Unicode iki nilai adhedhasar posisi sing ing denah kode.
/// Iki ora mesthi padha karo urutan "alphabetical", sing beda-beda miturut basa lan lokal.
/// Ngurutake senar miturut standar sing ditampa budaya mbutuhake data spesifik lokal sing ana ing sanjabane jinis `str`.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Ord for str {
    #[inline]
    fn cmp(&self, other: &str) -> Ordering {
        self.as_bytes().cmp(other.as_bytes())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for str {
    #[inline]
    fn eq(&self, other: &str) -> bool {
        self.as_bytes() == other.as_bytes()
    }
    #[inline]
    fn ne(&self, other: &str) -> bool {
        !(*self).eq(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Eq for str {}

/// Ngleksanakake operasi perbandingan ing senar.
///
/// Senar dibandhingake [lexicographically](Ord#lexicographical-comparison) kanthi nilai bait.
/// Iki mbandhingake poin kode Unicode adhedhasar posisine ing diagram kode.
/// Iki ora mesthi padha karo urutan "alphabetical", sing beda-beda miturut basa lan lokal.
/// Mbandhingake senar miturut standar sing ditampa budaya mbutuhake data spesifik lokal sing ana ing sanjabane jinis `str`.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl PartialOrd for str {
    #[inline]
    fn partial_cmp(&self, other: &str) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::Index<I> for str
where
    I: SliceIndex<str>,
{
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &I::Output {
        index.index(self)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::IndexMut<I> for str
where
    I: SliceIndex<str>,
{
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut I::Output {
        index.index_mut(self)
    }
}

#[inline(never)]
#[cold]
#[track_caller]
fn str_index_overflow_fail() -> ! {
    panic!("attempted to index str up to maximum usize");
}

/// Ngleksanakake irisan substring kanthi sintaks `&self[..]` utawa `&mut self[..]`.
///
/// Ngasilake irisan saka kabèh senar, IE, ngasilake `&self` utawa `&mut self`.Padha karo `&awake [0 ..
/// len] `utawa`&mut dhewe [0 ..
/// len]`.
/// Boten kados operasi indeksasi liyane, iki ora bisa panic.
///
/// Operasi iki yaiku *O*(1).
///
/// Sadurunge 1.20.0, operasi indeksasi iki isih didhukung dening implementasine langsung saka `Index` lan `IndexMut`.
///
/// Setara karo `&self[0 .. len]` utawa `&mut self[0 .. len]`.
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFull {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        Some(slice)
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        Some(slice)
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        slice
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        slice
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        slice
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        slice
    }
}

/// Ngleksanakake irisan substring kanthi sintaks `&self[begin .. end]` utawa `&mut self[begin .. end]`.
///
/// Ngasilake irisan saka senar diwenehi saka sawetara bait [: begin`, `end`).
///
/// Operasi iki yaiku *O*(1).
///
/// Sadurunge 1.20.0, operasi indeksasi iki isih didhukung dening implementasine langsung saka `Index` lan `IndexMut`.
///
/// # Panics
///
/// Panics yen `begin` utawa `end` ora tumuju marang bait miwiti nutup kerugian saka karakter (kaya sing ditegesake dening `is_char_boundary`), yen `begin > end`, utawa yen `end > len`.
///
///
/// # Examples
///
/// ```
/// let s = "Löwe 老虎 Léopard";
/// assert_eq!(&s[0 .. 1], "L");
///
/// assert_eq!(&s[1 .. 9], "öwe 老");
///
/// // bakal panic iki:
/// // bait 2 dununge ing `ö`:
/// // &S [2 ..3];
///
/// // bait 8 kawulo ing `老`&s [1 ..
/// // 8];
///
/// // bait 100 ana sanjabane senar&[3 ..
/// // 100];
/// ```
///
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::Range<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // SAFETY: mung dicenthang sing `start` lan `end` ing bates char,
            // lan kita maringaken ing referensi aman, supaya nilai bali uga bakal dadi salah siji.
            // Kita uga dicenthang wates char, supaya iki bener UTF-8.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // SAFETY: mung mriksa yen `start` lan `end` ana ing wates char.
            // We ngerti pitunjuk punika unik amarga kita entuk saka `slice`.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // njamin panelpon sing `self` ing wates saka `slice`: SAFETY
        // sing nglegakake kabeh kahanan kanggo `add`.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // SAFETY: ndeleng komentar kanggo `get_unchecked`.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, self.end);
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        // kir is_char_boundary sing indeks ing [0, .len()] bisa nganggo maneh `get` minangka ndhuwur, amarga saka alangan NLL
        //
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // SAFETY: mung dicenthang sing `start` lan `end` ing bates char,
            // lan kita maringaken ing referensi aman, supaya nilai bali uga bakal dadi salah siji.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, self.end)
        }
    }
}

/// Ngleksanakake irisan substring kanthi sintaks `&self[.. end]` utawa `&mut self[.. end]`.
///
/// Ngasilake irisan senar sing diwenehake saka sawetara byte [`0`, `end`).
/// Setara karo `&self[0 .. end]` utawa `&mut self[0 .. end]`.
///
/// Operasi iki yaiku *O*(1).
///
/// Sadurunge 1.20.0, operasi indeksasi iki isih didhukung dening implementasine langsung saka `Index` lan `IndexMut`.
///
/// # Panics
///
/// Panics yen `end` ora tumuju marang bait miwiti nutup kerugian saka karakter (kaya sing ditegesake dening `is_char_boundary`), utawa yen `end > len`.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeTo<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.end) {
            // SAFETY: mung mriksa yen `end` ana ing wates char,
            // lan kita maringaken ing referensi aman, supaya nilai bali uga bakal dadi salah siji.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.end) {
            // SAFETY: mung mriksa yen `end` ana ing wates char,
            // lan kita maringaken ing referensi aman, supaya nilai bali uga bakal dadi salah siji.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        let ptr = slice.as_ptr();
        ptr::slice_from_raw_parts(ptr, self.end) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        let ptr = slice.as_mut_ptr();
        ptr::slice_from_raw_parts_mut(ptr, self.end) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let end = self.end;
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, 0, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.end) {
            // SAFETY: mung mriksa yen `end` ana ing wates char,
            // lan kita maringaken ing referensi aman, supaya nilai bali uga bakal dadi salah siji.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, 0, self.end)
        }
    }
}

/// Nindakake substring slicing karo ukara `&self[begin ..]` utawa `&mut self[begin ..]`.
///
/// Ngasilake irisan saka senar diwenehi saka sawetara bait [: begin`, `len`).Padha karo`&awake dhewe [wiwit ..
/// len] `utawa`&mut dhewe [wiwiti ..
/// len]`.
///
/// Operasi iki yaiku *O*(1).
///
/// Sadurunge 1.20.0, operasi indeksasi iki isih didhukung dening implementasine langsung saka `Index` lan `IndexMut`.
///
/// # Panics
///
/// Panics yen `begin` ora tumuju marang bait miwiti nutup kerugian saka karakter (kaya sing ditegesake dening `is_char_boundary`), utawa yen `begin > len`.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFrom<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.start) {
            // SAFETY: mung dicenthang sing `start` ing bates char,
            // lan kita maringaken ing referensi aman, supaya nilai bali uga bakal dadi salah siji.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.start) {
            // SAFETY: mung dicenthang sing `start` ing bates char,
            // lan kita maringaken ing referensi aman, supaya nilai bali uga bakal dadi salah siji.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // njamin panelpon sing `self` ing wates saka `slice`: SAFETY
        // sing nglegakake kabeh kahanan kanggo `add`.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // SAFETY: padha karo `get_unchecked`.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, slice.len());
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.start) {
            // SAFETY: mung dicenthang sing `start` ing bates char,
            // lan kita maringaken ing referensi aman, supaya nilai bali uga bakal dadi salah siji.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, slice.len())
        }
    }
}

/// Nindakake substring slicing karo ukara `&self[begin ..= end]` utawa `&mut self[begin ..= end]`.
///
/// Ngasilake irisan saka senar diwenehi saka sawetara bait [`begin`, `end`].Podo karo `&self [begin .. end + 1]` utawa `&mut self[begin .. end + 1]`, kajaba yen `end` duwe nilai maksimal kanggo `usize`.
///
/// Operasi iki yaiku *O*(1).
///
/// # Panics
///
/// Panics yen `begin` ora tumuju marang bait miwiti nutup kerugian saka karakter (kaya sing ditegesake dening `is_char_boundary`), yen `end` ora titik ing bait pungkasan nutup kerugian saka karakter (`end + 1` iku salah siji bait miwiti nutup kerugian utawa witjaksono kanggo `len`), yen `begin > end`, utawa yen `end >= len`.
///
///
///
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // SAFETY: panelpon kudu njaga kontrak keamanan kanggo `get_unchecked`.
        unsafe { self.into_slice_range().get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // SAFETY: panelpon kudu njaga kontrak keamanan kanggo `get_unchecked_mut`.
        unsafe { self.into_slice_range().get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index_mut(slice)
    }
}

/// Nindakake substring slicing karo ukara `&self[..= end]` utawa `&mut self[..= end]`.
///
/// Ngasilake irisan saka senar diwenehi saka sawetara bait [0, `end`].
/// Padha `&self [0 .. end + 1]`, kajaba yen `end` nduweni nilai maksimal kanggo `usize`.
///
/// Operasi iki yaiku *O*(1).
///
/// # Panics
///
/// Panics yen `end` ora nuduhake akhir byte karakter (`end + 1` minangka offset byte wiwitan kaya sing ditegesake dening `is_char_boundary`, utawa padha karo `len`), utawa yen `end >= len`.
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeToInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // SAFETY: panelpon kudu njaga kontrak keamanan kanggo `get_unchecked`.
        unsafe { (..self.end + 1).get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // SAFETY: panelpon kudu njaga kontrak keamanan kanggo `get_unchecked_mut`.
        unsafe { (..self.end + 1).get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index_mut(slice)
    }
}

/// Ngurai nilai saka senar
///
/// : Cara [`from_str`] FromStr`kang asring digunakake implicitly, liwat [: str`] 's cara [`parse`].
/// Waca [: parse`] 's dhokumèntasi kanggo conto.
///
/// [`from_str`]: FromStr::from_str
/// [`parse`]: str::parse
///
/// `FromStr` ora duwe paramèter seumur hidup, mula sampeyan mung bisa ngatasi jinis sing ora ngemot paramèter seumur hidup.
///
/// Kanthi tembung liyane, sampeyan bisa ngatasi `i32` nganggo `FromStr`, nanging ora `&i32`.
/// Sampeyan bisa njlentrehake sing struct sing ngandhut `i32`, nanging ora siji sing ngandhut `&i32`.
///
/// # Examples
///
/// Implementasi dhasar `FromStr` ing conto jinis `Point`:
///
/// ```
/// use std::str::FromStr;
/// use std::num::ParseIntError;
///
/// #[derive(Debug, PartialEq)]
/// struct Point {
///     x: i32,
///     y: i32
/// }
///
/// impl FromStr for Point {
///     type Err = ParseIntError;
///
///     fn from_str(s: &str) -> Result<Self, Self::Err> {
///         let coords: Vec<&str> = s.trim_matches(|p| p == '(' || p == ')' )
///                                  .split(',')
///                                  .collect();
///
///         let x_fromstr = coords[0].parse::<i32>()?;
///         let y_fromstr = coords[1].parse::<i32>()?;
///
///         Ok(Point { x: x_fromstr, y: y_fromstr })
///     }
/// }
///
/// let p = Point::from_str("(1,2)");
/// assert_eq!(p.unwrap(), Point{ x: 1, y: 2} )
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait FromStr: Sized {
    /// kesalahan ingkang kang bisa bali saka parsing.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Err;

    /// Parses senar `s` kanggo ngasilake nilai saka jinis iki.
    ///
    /// Yen parsing sukses, baliake regane ing [`Ok`], yen string kasebut ora diformat maneh, ngasilake kesalahan khusus ing [`Err`] ing njero.
    /// Jinis kesalahan tartamtu kanggo implementasine saka trait.
    ///
    /// # Examples
    ///
    /// Panggunan dhasar karo [`i32`], jinis sing nindakake `FromStr`:
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// let s = "5";
    /// let x = i32::from_str(s).unwrap();
    ///
    /// assert_eq!(5, x);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_str(s: &str) -> Result<Self, Self::Err>;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for bool {
    type Err = ParseBoolError;

    /// Parse `bool` saka senar.
    ///
    /// Ngasilake `Result<bool, ParseBoolError>`, amarga `s` bisa uga bisa diurai.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// assert_eq!(FromStr::from_str("true"), Ok(true));
    /// assert_eq!(FromStr::from_str("false"), Ok(false));
    /// assert!(<bool as FromStr>::from_str("not even a boolean").is_err());
    /// ```
    ///
    /// Elinga, ing pirang-pirang kasus, metode `.parse()` ing `str` luwih tepat.
    ///
    /// ```
    /// assert_eq!("true".parse(), Ok(true));
    /// assert_eq!("false".parse(), Ok(false));
    /// assert!("not even a boolean".parse::<bool>().is_err());
    /// ```
    #[inline]
    fn from_str(s: &str) -> Result<bool, ParseBoolError> {
        match s {
            "true" => Ok(true),
            "false" => Ok(false),
            _ => Err(ParseBoolError { _priv: () }),
        }
    }
}