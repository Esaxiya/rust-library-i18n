//! API Pola senar.
//!
//! Pola API nyedhiyakake mekanisme umum kanggo nggunakake macem-macem jinis pola nalika nggoleki liwat senar.
//!
//! Kanggo rincian liyane, waca traits [`Pattern`], [`Searcher`], [`ReverseSearcher`], lan [`DoubleEndedSearcher`].
//!
//! Sanajan API iki ora stabil, kapapar liwat API stabil ing jinis [`str`].
//!
//! # Examples
//!
//! [`Pattern`] iku [implemented][pattern-impls] ing stabil API kanggo [`&str`][`str`], [`char`], irisan-irisan saka [`char`], lan fungsi lan nutup penerapan `FnMut(char) -> bool`.
//!
//!
//! ```
//! let s = "Can you find a needle in a haystack?";
//!
//! // &str pattern
//! assert_eq!(s.find("you"), Some(4));
//! // pola char
//! assert_eq!(s.find('n'), Some(2));
//! // irisan pola chars
//! assert_eq!(s.find(&['a', 'e', 'i', 'o', 'u'][..]), Some(1));
//! // pola penutupan
//! assert_eq!(s.find(|c: char| c.is_ascii_punctuation()), Some(35));
//! ```
//!
//! [pattern-impls]: Pattern#implementors
//!
//!
//!
//!

#![unstable(
    feature = "pattern",
    reason = "API not fully fleshed out and ready to be stabilized",
    issue = "27721"
)]

use crate::cmp;
use crate::fmt;
use crate::slice::memchr;

// Pattern

/// Pola senar.
///
/// A `Pattern<'a>` ndudohake sing jinis penerapan bisa digunakake minangka pola senar kanggo nggoleki ing [`&'a str`][str].
///
/// Contone, `'a'` lan `"aa"` minangka pola sing cocog karo indeks `1` ing string `"baaaab"`.
///
/// trait dhewe tumindak minangka tukang kanggo jinis [`Searcher`] sing gegandhengan, sing nindakake karya nyata kanggo nemokake kedadeyan pola ing senar.
///
///
/// Gumantung saka jinis pola, prilaku cara kaya [`str::find`] lan [`str::contains`] bisa diganti.
/// Tabel ing ngisor iki nggambarake sawetara tindak tanduk kasebut.
///
/// | Pattern type             | Match condition                           |
/// |--------------------------|-------------------------------------------|
/// | `&str`                   | is substring                              |
/// | `char`                   | is contained in string                    |
/// | `&[char]`                | any char in slice is contained in string  |
/// | `F: FnMut(char) -> bool` | `F` returns `true` for a char in string   |
/// | `&&str`                  | is substring                              |
/// | `&String`                | is substring                              |
///
/// # Examples
///
/// ```
/// // &str
/// assert_eq!("abaaa".find("ba"), Some(1));
/// assert_eq!("abaaa".find("bac"), None);
///
/// // char
/// assert_eq!("abaaa".find('a'), Some(0));
/// assert_eq!("abaaa".find('b'), Some(1));
/// assert_eq!("abaaa".find('c'), None);
///
/// // &[char]
/// assert_eq!("ab".find(&['b', 'a'][..]), Some(0));
/// assert_eq!("abaaa".find(&['a', 'z'][..]), Some(0));
/// assert_eq!("abaaa".find(&['c', 'd'][..]), None);
///
/// // FnMut(char) -> bool
/// assert_eq!("abcdef_z".find(|ch| ch > 'd' && ch < 'y'), Some(4));
/// assert_eq!("abcddd_z".find(|ch| ch > 'd' && ch < 'y'), None);
/// ```
///
///
///
///
pub trait Pattern<'a>: Sized {
    /// Panelusuran sing digandhengake kanggo pola iki
    type Searcher: Searcher<'a>;

    /// Mbangun panelusur sing digandhengake saka `self` lan `haystack` kanggo nggoleki.
    ///
    fn into_searcher(self, haystack: &'a str) -> Self::Searcher;

    /// Kir apa pola cocog ngendi wae ing haystack ing
    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        self.into_searcher(haystack).next_match().is_some()
    }

    /// Priksa manawa pola kasebut cocog ing sisih ngarep tumpukan jerami
    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        matches!(self.into_searcher(haystack).next(), SearchStep::Match(0, _))
    }

    /// Priksa manawa pola kasebut cocog ing mburi tumpukan jerami
    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        matches!(self.into_searcher(haystack).next_back(), SearchStep::Match(_, j) if haystack.len() == j)
    }

    /// Copot pola saka sisih ngarep tumpukan jerami, yen cocog.
    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        if let SearchStep::Match(start, len) = self.into_searcher(haystack).next() {
            debug_assert_eq!(
                start, 0,
                "The first search step from Searcher \
                 must include the first character"
            );
            // SAFETY: `Searcher` dikenal bisa ngasilake indeks sing valid.
            unsafe { Some(haystack.get_unchecked(len..)) }
        } else {
            None
        }
    }

    /// Mbusak pola saka mburi haystack, yen cocog.
    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        if let SearchStep::Match(start, end) = self.into_searcher(haystack).next_back() {
            debug_assert_eq!(
                end,
                haystack.len(),
                "The first search step from ReverseSearcher \
                 must include the last character"
            );
            // SAFETY: `Searcher` dikenal bisa ngasilake indeks sing valid.
            unsafe { Some(haystack.get_unchecked(..start)) }
        } else {
            None
        }
    }
}

// Searcher

/// Asil nelpon [`Searcher::next()`] utawa [`ReverseSearcher::next_back()`].
#[derive(Copy, Clone, Eq, PartialEq, Debug)]
pub enum SearchStep {
    /// Nyatakake manawa match pola ditemokake ing `haystack[a..b]`.
    ///
    Match(usize, usize),
    /// Ndudohake sing `haystack[a..b]` ditulak pertandhingan bisa pola.
    ///
    /// Elinga yen ana uga luwih saka siji `Reject` antarane loro: Match`es, ana requirement kanggo wong-wong mau kanggo digabung dadi siji.
    ///
    ///
    Reject(usize, usize),
    /// Ndudohake sing saben bait saka haystack wis dibukak, pungkasan pengulangan ing.
    ///
    Done,
}

/// Panelusuran pola tali.
///
/// trait iki nyedhiyakake cara kanggo nggoleki pola sing ora tumpang tindih saka pola sing diwiwiti saka (left) ngarep string.
///
/// Iki bakal dileksanakake dening jinis `Searcher` sing gegandhengan karo [`Pattern`] trait.
///
/// trait ditandhani ora aman amarga indeks sing bali kanthi metode [`next()`][Searcher::next] kudu diwenehi wates utf8 sing valid ing tumpukan jerami.
/// Iki nggawe konsumen trait iki bisa ngiris tumpukan jerami tanpa priksa runtime tambahan.
///
///
///
///
pub unsafe trait Searcher<'a> {
    /// Getter kanggo senar ndasari dititi ing
    ///
    /// Bakal mesthi ngasilake [`&str`][str] sing padha.
    fn haystack(&self) -> &'a str;

    /// Nindakake langkah telusuran sabanjure diwiwiti saka ngarep.
    ///
    /// - Ngasilake [`Match(a, b)`][SearchStep::Match] yen `haystack[a..b]` cocog karo pola kasebut.
    /// - Ngasilake [`Reject(a, b)`][SearchStep::Reject] yen `haystack[a..b]` ora bisa cocog karo pola, sanajan sebagian.
    /// - Ngasilake [`Done`][SearchStep::Done] yen saben bait tumpukan jerami wis dikunjungi.
    ///
    /// Aliran nilai [`Match`][SearchStep::Match] lan [`Reject`][SearchStep::Reject] nganti [`Done`][SearchStep::Done] bakal ngemot kisaran indeks sing jejer, ora tumpang tindih, nutupi kabeh tumpukan jerami, lan mbatesi wates utf8.
    ///
    ///
    /// Asil [`Match`][SearchStep::Match] kudu ngemot pola sing cocog kabeh, nanging asil [`Reject`][SearchStep::Reject] bisa dipisahake dadi sawetara fragmen jejer sing ora wenang.Kaloro rentang kasebut bisa uga dawane nol.
    ///
    /// Contone, pola `"aaa"` lan haystack `"cbaaaaab"` bisa ngasilake stream kasebut
    /// `[Reject(0, 1), Reject(1, 2), Match(2, 5), Reject(5, 8)]`
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn next(&mut self) -> SearchStep;

    /// Ketemu asil [`Match`][SearchStep::Match] sabanjuré.Waca [`next()`][Searcher::next].
    ///
    /// Beda karo [`next()`][Searcher::next], ora ana jaminan yen rentang sing bali iki lan [`next_reject`][Searcher::next_reject] bakal tumpang tindih.
    /// Iki bakal ngasilake `(start_match, end_match)`, ngendi start_match iku indeks saka ngendi match wiwit, lan end_match iku indeks sawise mburi pertandhingan.
    ///
    ///
    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next() {
                SearchStep::Match(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }

    /// Nemokake asil [`Reject`][SearchStep::Reject] sabanjure.Deleng [`next()`][Searcher::next] lan [`next_match()`][Searcher::next_match].
    ///
    /// Boten kados [`next()`][Searcher::next], ana ora njamin yen kisaran bali saka [`next_match`][Searcher::next_match] iki lan bakal tumpang tindih.
    ///
    ///
    #[inline]
    fn next_reject(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next() {
                SearchStep::Reject(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }
}

/// A searcher mbalikke kanggo pola senar.
///
/// trait iki nyedhiyakake cara kanggo nggoleki pola sing ora tumpang tindih pola wiwit saka mburi (right) saka senar.
///
/// Bakal dipun ginakaken dening jinis [`Searcher`] ingkang ing [`Pattern`] trait yen ndhukung pola nggoleki saka mburi.
///
///
/// Rentang indeks sing dibalekake dening trait iki ora dibutuhake cocog karo sing digoleki ing ngarep.
///
/// Kanggo alesan ngapa trait iki ditandhani ora aman, deleng wong tuwa trait [`Searcher`].
///
///
///
///
pub unsafe trait ReverseSearcher<'a>: Searcher<'a> {
    /// Nindakake langkah telusuran sabanjure wiwit mburi.
    ///
    /// - Ngasilake [`Match(a, b)`][SearchStep::Match] yen `haystack[a..b]` cocog karo pola kasebut.
    /// - Ngasilake [`Reject(a, b)`][SearchStep::Reject] yen `haystack[a..b]` ora bisa cocog karo pola, sanajan sebagian.
    /// - Ngasilake [`Done`][SearchStep::Done] yen saben bait tumpukan jerami wis dikunjungi
    ///
    /// Aliran nilai [`Match`][SearchStep::Match] lan [`Reject`][SearchStep::Reject] nganti [`Done`][SearchStep::Done] bakal ngemot kisaran indeks sing jejer, ora tumpang tindih, nutupi kabeh tumpukan jerami, lan mbatesi wates utf8.
    ///
    ///
    /// Asil [`Match`][SearchStep::Match] kudu ngemot pola sing cocog kabeh, nanging asil [`Reject`][SearchStep::Reject] bisa dipisahake dadi sawetara fragmen jejer sing ora wenang.Kaloro rentang kasebut bisa uga dawane nol.
    ///
    /// Contone, pola `"aaa"` lan haystack `"cbaaaaab"` bisa ngasilake stream `[Reject(7, 8), Match(4, 7), Reject(1, 4), Reject(0, 1)]`.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn next_back(&mut self) -> SearchStep;

    /// Nemokake asil [`Match`][SearchStep::Match] sabanjure.
    /// Waca [`next_back()`][ReverseSearcher::next_back].
    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next_back() {
                SearchStep::Match(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }

    /// Nemokake asil [`Reject`][SearchStep::Reject] sabanjure.
    /// Waca [`next_back()`][ReverseSearcher::next_back].
    #[inline]
    fn next_reject_back(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next_back() {
                SearchStep::Reject(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }
}

/// trait panandha kanggo nyebutake yen [`ReverseSearcher`] bisa digunakake kanggo implementasine [`DoubleEndedIterator`].
///
/// Kanggo iki, impl [`Searcher`] lan [`ReverseSearcher`] kudu ngetutake kahanan kasebut:
///
/// - Kabeh asil saka `next()` kudu dadi podho rupo kanggo asil saka `next_back()` supaya mbalikke.
/// - `next()` lan `next_back()` kudu tumindak minangka rong ujung sawetara nilai, yaiku ora bisa "walk past each other".
///
/// # Examples
///
/// `char::Searcher` minangka `DoubleEndedSearcher` amarga nggoleki [`char`] mung mbutuhake nyawang siji-siji, sing tumindake padha saka loro-lorone.
///
/// `(&str)::Searcher` dudu `DoubleEndedSearcher` amarga pola `"aa"` ing tumpukan hayam `"aaa"` cocog karo `"[aa]a"` utawa `"a[aa]"`, gumantung saka sisih endi sing digoleki.
///
///
///
///
///
///
///
///
///
pub trait DoubleEndedSearcher<'a>: ReverseSearcher<'a> {}

/////////////////////////////////////////////////////////////////////////////
// Nglakokake kanggo char
/////////////////////////////////////////////////////////////////////////////

/// Gadhah jinis kanggo `<char as Pattern<'a>>::Searcher`.
#[derive(Clone, Debug)]
pub struct CharSearcher<'a> {
    haystack: &'a str,
    // invariant safety: `finger`/`finger_back` kudu indeks byte utf8 valid saka `haystack` Invariant iki bisa dipecah *ing* next_match lan next_match_back, nanging kudu metu nganggo driji ing wates titik kode sing valid.
    //
    //
    /// `finger` minangka indeks byte saiki kanggo telusuran maju.
    /// Mbayangno sing ana sadurunge bait ing index, IE
    /// `haystack[finger]` punika bait pisanan saka irisan kita kudu mriksa sak searching maju
    ///
    finger: usize,
    /// `finger_back` minangka indeks byte saiki kanggo telusuran mbalikke.
    /// Bayangake yen ana sawise bait ing indeks, yaiku
    /// haystack [finger_back, 1] minangka bait terakhir saka irisan sing kudu kita priksa sajrone digoleki ing ngarep (mula byte pisanan sing bakal ditliti nalika nelpon next_back()).
    ///
    finger_back: usize,
    /// Tokoh kang nggolèki
    needle: char,

    // invariant keamanan: `utf8_size` kudu kurang saka 5
    /// Jumlah bita `needle` njupuk munggah nalika dienkode ing utf8.
    utf8_size: usize,
    /// Salinan utf8 sing dienkode saka `needle`
    utf8_encoded: [u8; 4],
}

unsafe impl<'a> Searcher<'a> for CharSearcher<'a> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }
    #[inline]
    fn next(&mut self) -> SearchStep {
        let old_finger = self.finger;
        // SAFETY: safety 1-4 njamin `get_unchecked`
        // 1. `self.finger` lan `self.finger_back` tetep ing wates unicode (iki ora mesthi)
        // 2. `self.finger >= 0` wiwit diwiwiti ing 0 lan mung mundhak
        // 3. `self.finger < self.finger_back` amarga yen char `iter` bakal ngasilake `SearchStep::Done`
        // 4.
        // `self.finger` rawuh sadurunge pungkasan haystack amarga `self.finger_back` wiwit ing pungkasan lan mung sudo
        //
        //
        let slice = unsafe { self.haystack.get_unchecked(old_finger..self.finger_back) };
        let mut iter = slice.chars();
        let old_len = iter.iter.len();
        if let Some(ch) = iter.next() {
            // nambahake byte karakter saiki tanpa enkode ulang minangka utf-8
            //
            self.finger += old_len - iter.iter.len();
            if ch == self.needle {
                SearchStep::Match(old_finger, self.finger)
            } else {
                SearchStep::Reject(old_finger, self.finger)
            }
        } else {
            SearchStep::Done
        }
    }
    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        loop {
            // entuk tumpukan jerami sawise karakter pungkasan sing ditemokake
            let bytes = self.haystack.as_bytes().get(self.finger..self.finger_back)?;
            // ing bait pungkasan saka utf8 dienkode SAFETY jarum: kita duwe podho sing `utf8_size < 5`
            //
            let last_byte = unsafe { *self.utf8_encoded.get_unchecked(self.utf8_size - 1) };
            if let Some(index) = memchr::memchr(last_byte, bytes) {
                // Driji anyar minangka indeks byte sing ditemokake, ditambah siji, amarga kita ngelingi byte pungkasan karakter kasebut.
                //
                // Elinga yen iki ora mesthi menehi driji ing wates UTF8.
                // Yen *ora* nemokake karakter kita, kita bisa uga ngindeks menyang byte non-pungkasan karakter 3-byte utawa 4-byte.
                // Kita ora bisa langsung mbukak byte wiwitan sing valid sabanjure amarga karakter kaya ꁁ (U + A041 YI SYLLABLE PA), utf-8 `EA 81 81` bakal menehi kita byte kaping pindho nalika nggoleki sing nomer telu.
                //
                //
                // Nanging, iki pancen ora apa-apa.
                // Nalika kita duwe podho sing self.finger ing bates UTF8, podho iki ora migunaaké marang ing cara iki (kang migunaaké marang ing CharSearcher::next()).
                //
                // Kita mung metu saka cara iki nalika tekan pucuk senar, utawa yen bisa nemokake.Nalika nemokake soko `finger` bakal disetel menyang wates UTF8.
                //
                //
                //
                //
                //
                //
                self.finger += index + 1;
                if self.finger >= self.utf8_size {
                    let found_char = self.finger - self.utf8_size;
                    if let Some(slice) = self.haystack.as_bytes().get(found_char..self.finger) {
                        if slice == &self.utf8_encoded[0..self.utf8_size] {
                            return Some((found_char, self.finger));
                        }
                    }
                }
            } else {
                // ora nemu apa-apa, metu
                self.finger = self.finger_back;
                return None;
            }
        }
    }

    // ayo next_reject nggunakake implementasine gawan saka Searcher trait
}

unsafe impl<'a> ReverseSearcher<'a> for CharSearcher<'a> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        let old_finger = self.finger_back;
        // SAFETY: deleng komentar next() ing ndhuwur
        let slice = unsafe { self.haystack.get_unchecked(self.finger..old_finger) };
        let mut iter = slice.chars();
        let old_len = iter.iter.len();
        if let Some(ch) = iter.next_back() {
            // nyuda byte karakter saiki tanpa enkode ulang minangka utf-8
            //
            self.finger_back -= old_len - iter.iter.len();
            if ch == self.needle {
                SearchStep::Match(self.finger_back, old_finger)
            } else {
                SearchStep::Reject(self.finger_back, old_finger)
            }
        } else {
            SearchStep::Done
        }
    }
    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        let haystack = self.haystack.as_bytes();
        loop {
            // entuk tumpukan jerami nanging ora kalebu karakter pungkasan sing digoleki
            let bytes = haystack.get(self.finger..self.finger_back)?;
            // ing bait pungkasan saka utf8 dienkode SAFETY jarum: kita duwe podho sing `utf8_size < 5`
            //
            let last_byte = unsafe { *self.utf8_encoded.get_unchecked(self.utf8_size - 1) };
            if let Some(index) = memchr::memrchr(last_byte, bytes) {
                // kita digolekki irisan sing nutup kerugian dening self.finger, nambah self.finger kanggo nutup indeks asli
                //
                let index = self.finger + index;
                // memrchr bakal ngasilake indeks saka bait kita pengin golek.
                // Ing cilik saka karakter ASCII, iki tenan padha kita pengin driji anyar kita dadi ("after" ing char ditemokaké ing paradigma saka pengulangan mbalikke).
                //
                // Kanggo karakter multibyte, kita kudu mudhun kanthi jumlah byte luwih akeh tinimbang ASCII
                //
                //
                let shift = self.utf8_size - 1;
                if index >= shift {
                    let found_char = index - shift;
                    if let Some(slice) = haystack.get(found_char..(found_char + self.utf8_size)) {
                        if slice == &self.utf8_encoded[0..self.utf8_size] {
                            // mindhah driji kanggo sadurunge karakter ketemu (IE, ing indeks wiwitan sawijining)
                            self.finger_back = found_char;
                            return Some((self.finger_back, self.finger_back + self.utf8_size));
                        }
                    }
                }
                // Kita ora bisa nggunakake finger_back=indeks, ukuran + 1 ing kene.
                // Yen kita nemokake karakter pungkasan kanggo karakter sing beda-beda (utawa byte tengah kanggo karakter liyane), kita kudu ngetokake driji menyang `index`.
                // Iki Kajaba ndadekake `finger_back` duwe potensial kanggo maneh ing bates, nanging iki OK awit kita mung metu fungsi iki ing bates utawa nalika haystack wis nggolèki rampung.
                //
                //
                // Boten kados next_match, iki ora duwe masalah bait bola-bali ing utf-8 amarga kita nggoleki byte pungkasan, lan mung bisa nemokake byte pungkasan nalika nggoleki ing mbalikke.
                //
                //
                //
                //
                //
                self.finger_back = index;
            } else {
                self.finger_back = self.finger;
                // ora nemu apa-apa, metu
                return None;
            }
        }
    }

    // supaya next_reject_back nggunakake implementasine standar saka Searcher trait
}

impl<'a> DoubleEndedSearcher<'a> for CharSearcher<'a> {}

/// Nggoleki karakter sing padha karo [`char`] sing diwenehake.
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find('o'), Some(4));
/// ```
impl<'a> Pattern<'a> for char {
    type Searcher = CharSearcher<'a>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> Self::Searcher {
        let mut utf8_encoded = [0; 4];
        let utf8_size = self.encode_utf8(&mut utf8_encoded).len();
        CharSearcher {
            haystack,
            finger: 0,
            finger_back: haystack.len(),
            needle: self,
            utf8_size,
            utf8_encoded,
        }
    }

    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        if (self as u32) < 128 {
            haystack.as_bytes().contains(&(self as u8))
        } else {
            let mut buffer = [0u8; 4];
            self.encode_utf8(&mut buffer).is_contained_in(haystack)
        }
    }

    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        self.encode_utf8(&mut [0u8; 4]).is_prefix_of(haystack)
    }

    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        self.encode_utf8(&mut [0u8; 4]).strip_prefix_of(haystack)
    }

    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        self.encode_utf8(&mut [0u8; 4]).is_suffix_of(haystack)
    }

    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        self.encode_utf8(&mut [0u8; 4]).strip_suffix_of(haystack)
    }
}

/////////////////////////////////////////////////////////////////////////////
// Nganggo pambungkus MultiCharEq
/////////////////////////////////////////////////////////////////////////////

#[doc(hidden)]
trait MultiCharEq {
    fn matches(&mut self, c: char) -> bool;
}

impl<F> MultiCharEq for F
where
    F: FnMut(char) -> bool,
{
    #[inline]
    fn matches(&mut self, c: char) -> bool {
        (*self)(c)
    }
}

impl MultiCharEq for &[char] {
    #[inline]
    fn matches(&mut self, c: char) -> bool {
        self.iter().any(|&m| m == c)
    }
}

struct MultiCharEqPattern<C: MultiCharEq>(C);

#[derive(Clone, Debug)]
struct MultiCharEqSearcher<'a, C: MultiCharEq> {
    char_eq: C,
    haystack: &'a str,
    char_indices: super::CharIndices<'a>,
}

impl<'a, C: MultiCharEq> Pattern<'a> for MultiCharEqPattern<C> {
    type Searcher = MultiCharEqSearcher<'a, C>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> MultiCharEqSearcher<'a, C> {
        MultiCharEqSearcher { haystack, char_eq: self.0, char_indices: haystack.char_indices() }
    }
}

unsafe impl<'a, C: MultiCharEq> Searcher<'a> for MultiCharEqSearcher<'a, C> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }

    #[inline]
    fn next(&mut self) -> SearchStep {
        let s = &mut self.char_indices;
        // Bandhingake dawa iterator irisan bait internal kanggo nemokake dawa char saiki
        //
        let pre_len = s.iter.iter.len();
        if let Some((i, c)) = s.next() {
            let len = s.iter.iter.len();
            let char_len = pre_len - len;
            if self.char_eq.matches(c) {
                return SearchStep::Match(i, i + char_len);
            } else {
                return SearchStep::Reject(i, i + char_len);
            }
        }
        SearchStep::Done
    }
}

unsafe impl<'a, C: MultiCharEq> ReverseSearcher<'a> for MultiCharEqSearcher<'a, C> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        let s = &mut self.char_indices;
        // Bandhingake dawa iterator irisan bait internal kanggo nemokake dawa char saiki
        //
        let pre_len = s.iter.iter.len();
        if let Some((i, c)) = s.next_back() {
            let len = s.iter.iter.len();
            let char_len = pre_len - len;
            if self.char_eq.matches(c) {
                return SearchStep::Match(i, i + char_len);
            } else {
                return SearchStep::Reject(i, i + char_len);
            }
        }
        SearchStep::Done
    }
}

impl<'a, C: MultiCharEq> DoubleEndedSearcher<'a> for MultiCharEqSearcher<'a, C> {}

/////////////////////////////////////////////////////////////////////////////

macro_rules! pattern_methods {
    ($t:ty, $pmap:expr, $smap:expr) => {
        type Searcher = $t;

        #[inline]
        fn into_searcher(self, haystack: &'a str) -> $t {
            ($smap)(($pmap)(self).into_searcher(haystack))
        }

        #[inline]
        fn is_contained_in(self, haystack: &'a str) -> bool {
            ($pmap)(self).is_contained_in(haystack)
        }

        #[inline]
        fn is_prefix_of(self, haystack: &'a str) -> bool {
            ($pmap)(self).is_prefix_of(haystack)
        }

        #[inline]
        fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
            ($pmap)(self).strip_prefix_of(haystack)
        }

        #[inline]
        fn is_suffix_of(self, haystack: &'a str) -> bool
        where
            $t: ReverseSearcher<'a>,
        {
            ($pmap)(self).is_suffix_of(haystack)
        }

        #[inline]
        fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
        where
            $t: ReverseSearcher<'a>,
        {
            ($pmap)(self).strip_suffix_of(haystack)
        }
    };
}

macro_rules! searcher_methods {
    (forward) => {
        #[inline]
        fn haystack(&self) -> &'a str {
            self.0.haystack()
        }
        #[inline]
        fn next(&mut self) -> SearchStep {
            self.0.next()
        }
        #[inline]
        fn next_match(&mut self) -> Option<(usize, usize)> {
            self.0.next_match()
        }
        #[inline]
        fn next_reject(&mut self) -> Option<(usize, usize)> {
            self.0.next_reject()
        }
    };
    (reverse) => {
        #[inline]
        fn next_back(&mut self) -> SearchStep {
            self.0.next_back()
        }
        #[inline]
        fn next_match_back(&mut self) -> Option<(usize, usize)> {
            self.0.next_match_back()
        }
        #[inline]
        fn next_reject_back(&mut self) -> Option<(usize, usize)> {
            self.0.next_reject_back()
        }
    };
}

/////////////////////////////////////////////////////////////////////////////
// Nglakokake kanggo&[char]
/////////////////////////////////////////////////////////////////////////////

// Todo: Owahi/Copot amarga ora jelas tegese.

/// Jinis sing digandhengake kanggo `<&[char] as Pattern<'a>>::Searcher`.
#[derive(Clone, Debug)]
pub struct CharSliceSearcher<'a, 'b>(<MultiCharEqPattern<&'b [char]> as Pattern<'a>>::Searcher);

unsafe impl<'a, 'b> Searcher<'a> for CharSliceSearcher<'a, 'b> {
    searcher_methods!(forward);
}

unsafe impl<'a, 'b> ReverseSearcher<'a> for CharSliceSearcher<'a, 'b> {
    searcher_methods!(reverse);
}

impl<'a, 'b> DoubleEndedSearcher<'a> for CharSliceSearcher<'a, 'b> {}

/// Nggoleki karakter sing padha karo [char] ing irisan.
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find(&['l', 'l'] as &[_]), Some(2));
/// assert_eq!("Hello world".find(&['l', 'l'][..]), Some(2));
/// ```
impl<'a, 'b> Pattern<'a> for &'b [char] {
    pattern_methods!(CharSliceSearcher<'a, 'b>, MultiCharEqPattern, CharSliceSearcher);
}

/////////////////////////////////////////////////////////////////////////////
// Impl F: FnMut(char)-> bool
/////////////////////////////////////////////////////////////////////////////

/// Jinis sing digandhengake kanggo `<F as Pattern<'a>>::Searcher`.
#[derive(Clone)]
pub struct CharPredicateSearcher<'a, F>(<MultiCharEqPattern<F> as Pattern<'a>>::Searcher)
where
    F: FnMut(char) -> bool;

impl<F> fmt::Debug for CharPredicateSearcher<'_, F>
where
    F: FnMut(char) -> bool,
{
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("CharPredicateSearcher")
            .field("haystack", &self.0.haystack)
            .field("char_indices", &self.0.char_indices)
            .finish()
    }
}
unsafe impl<'a, F> Searcher<'a> for CharPredicateSearcher<'a, F>
where
    F: FnMut(char) -> bool,
{
    searcher_methods!(forward);
}

unsafe impl<'a, F> ReverseSearcher<'a> for CharPredicateSearcher<'a, F>
where
    F: FnMut(char) -> bool,
{
    searcher_methods!(reverse);
}

impl<'a, F> DoubleEndedSearcher<'a> for CharPredicateSearcher<'a, F> where F: FnMut(char) -> bool {}

/// Nggoleki [`char`] sing cocog karo predikat sing diwenehake.
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find(char::is_uppercase), Some(0));
/// assert_eq!("Hello world".find(|c| "aeiou".contains(c)), Some(1));
/// ```
impl<'a, F> Pattern<'a> for F
where
    F: FnMut(char) -> bool,
{
    pattern_methods!(CharPredicateSearcher<'a, F>, MultiCharEqPattern, CharPredicateSearcher);
}

/////////////////////////////////////////////////////////////////////////////
// Nglakoni&&str
/////////////////////////////////////////////////////////////////////////////

/// Delegasi kanggo impl `&str`.
impl<'a, 'b, 'c> Pattern<'a> for &'c &'b str {
    pattern_methods!(StrSearcher<'a, 'b>, |&s| s, |s| s);
}

/////////////////////////////////////////////////////////////////////////////
// Nganggo &str
/////////////////////////////////////////////////////////////////////////////

/// Telusuran substring sing ora dialokasikan.
///
/// Bakal nangani pola `""` minangka bali kosong ing saben wates karakter.
///
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find("world"), Some(6));
/// ```
impl<'a, 'b> Pattern<'a> for &'b str {
    type Searcher = StrSearcher<'a, 'b>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> StrSearcher<'a, 'b> {
        StrSearcher::new(haystack, self)
    }

    /// Kir apa pola cocog ing ngarepe haystack ing.
    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        haystack.as_bytes().starts_with(self.as_bytes())
    }

    /// Copot pola saka sisih ngarep tumpukan jerami, yen cocog.
    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        if self.is_prefix_of(haystack) {
            // SAFETY: prefiks mung diverifikasi ana.
            unsafe { Some(haystack.get_unchecked(self.as_bytes().len()..)) }
        } else {
            None
        }
    }

    /// Priksa manawa pola kasebut cocog ing mburi tumpukan jerami.
    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool {
        haystack.as_bytes().ends_with(self.as_bytes())
    }

    /// Mbusak pola saka mburi haystack, yen cocog.
    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str> {
        if self.is_suffix_of(haystack) {
            let i = haystack.len() - self.as_bytes().len();
            // SAFETY: seselan iki mung diverifikasi ana.
            unsafe { Some(haystack.get_unchecked(..i)) }
        } else {
            None
        }
    }
}

/////////////////////////////////////////////////////////////////////////////
// Panelusuran substring Two Way
/////////////////////////////////////////////////////////////////////////////

#[derive(Clone, Debug)]
/// Jinis sing digandhengake kanggo `<&str as Pattern<'a>>::Searcher`.
pub struct StrSearcher<'a, 'b> {
    haystack: &'a str,
    needle: &'b str,

    searcher: StrSearcherImpl,
}

#[derive(Clone, Debug)]
enum StrSearcherImpl {
    Empty(EmptyNeedle),
    TwoWay(TwoWaySearcher),
}

#[derive(Clone, Debug)]
struct EmptyNeedle {
    position: usize,
    end: usize,
    is_match_fw: bool,
    is_match_bw: bool,
}

impl<'a, 'b> StrSearcher<'a, 'b> {
    fn new(haystack: &'a str, needle: &'b str) -> StrSearcher<'a, 'b> {
        if needle.is_empty() {
            StrSearcher {
                haystack,
                needle,
                searcher: StrSearcherImpl::Empty(EmptyNeedle {
                    position: 0,
                    end: haystack.len(),
                    is_match_fw: true,
                    is_match_bw: true,
                }),
            }
        } else {
            StrSearcher {
                haystack,
                needle,
                searcher: StrSearcherImpl::TwoWay(TwoWaySearcher::new(
                    needle.as_bytes(),
                    haystack.len(),
                )),
            }
        }
    }
}

unsafe impl<'a, 'b> Searcher<'a> for StrSearcher<'a, 'b> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }

    #[inline]
    fn next(&mut self) -> SearchStep {
        match self.searcher {
            StrSearcherImpl::Empty(ref mut searcher) => {
                // jarum kosong nolak saben char lan cocog karo saben senar kosong
                let is_match = searcher.is_match_fw;
                searcher.is_match_fw = !searcher.is_match_fw;
                let pos = searcher.position;
                match self.haystack[pos..].chars().next() {
                    _ if is_match => SearchStep::Match(pos, pos),
                    None => SearchStep::Done,
                    Some(ch) => {
                        searcher.position += ch.len_utf8();
                        SearchStep::Reject(pos, searcher.position)
                    }
                }
            }
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                // TwoWaySearcher ngasilake indeks *Cocokake* sing bener sing dibagi ing wates char anggere cocog karo sing cocog lan tumpukan jarum lan jarum UTF-8 *Ditolak* saka algoritma bisa ditemokake ing indeks apa wae, nanging kita bakal mbukak kanthi manual menyang wates karakter sabanjure, supaya luwih aman utf-8.
                //
                //
                //
                //
                if searcher.position == self.haystack.len() {
                    return SearchStep::Done;
                }
                let is_long = searcher.memory == usize::MAX;
                match searcher.next::<RejectAndMatch>(
                    self.haystack.as_bytes(),
                    self.needle.as_bytes(),
                    is_long,
                ) {
                    SearchStep::Reject(a, mut b) => {
                        // mlumpat menyang wates char sabanjure
                        while !self.haystack.is_char_boundary(b) {
                            b += 1;
                        }
                        searcher.position = cmp::max(b, searcher.position);
                        SearchStep::Reject(a, b)
                    }
                    otherwise => otherwise,
                }
            }
        }
    }

    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        match self.searcher {
            StrSearcherImpl::Empty(..) => loop {
                match self.next() {
                    SearchStep::Match(a, b) => return Some((a, b)),
                    SearchStep::Done => return None,
                    SearchStep::Reject(..) => {}
                }
            },
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                let is_long = searcher.memory == usize::MAX;
                // nulis metu `true` lan `false` kasus kanggo kasurung compiler sing mligi kasus loro dhewe.
                //
                if is_long {
                    searcher.next::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        true,
                    )
                } else {
                    searcher.next::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        false,
                    )
                }
            }
        }
    }
}

unsafe impl<'a, 'b> ReverseSearcher<'a> for StrSearcher<'a, 'b> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        match self.searcher {
            StrSearcherImpl::Empty(ref mut searcher) => {
                let is_match = searcher.is_match_bw;
                searcher.is_match_bw = !searcher.is_match_bw;
                let end = searcher.end;
                match self.haystack[..end].chars().next_back() {
                    _ if is_match => SearchStep::Match(end, end),
                    None => SearchStep::Done,
                    Some(ch) => {
                        searcher.end -= ch.len_utf8();
                        SearchStep::Reject(searcher.end, end)
                    }
                }
            }
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                if searcher.end == 0 {
                    return SearchStep::Done;
                }
                let is_long = searcher.memory == usize::MAX;
                match searcher.next_back::<RejectAndMatch>(
                    self.haystack.as_bytes(),
                    self.needle.as_bytes(),
                    is_long,
                ) {
                    SearchStep::Reject(mut a, b) => {
                        // mlumpat menyang wates char sabanjure
                        while !self.haystack.is_char_boundary(a) {
                            a -= 1;
                        }
                        searcher.end = cmp::min(a, searcher.end);
                        SearchStep::Reject(a, b)
                    }
                    otherwise => otherwise,
                }
            }
        }
    }

    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        match self.searcher {
            StrSearcherImpl::Empty(..) => loop {
                match self.next_back() {
                    SearchStep::Match(a, b) => return Some((a, b)),
                    SearchStep::Done => return None,
                    SearchStep::Reject(..) => {}
                }
            },
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                let is_long = searcher.memory == usize::MAX;
                // tulis `true` lan `false`, kaya `next_match`
                if is_long {
                    searcher.next_back::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        true,
                    )
                } else {
                    searcher.next_back::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        false,
                    )
                }
            }
        }
    }
}

/// Status internal algoritma telusuran substring loro arah.
#[derive(Clone, Debug)]
struct TwoWaySearcher {
    // constants
    /// indeks faktorisasi kritis
    crit_pos: usize,
    /// indeks faktorisasi kritis kanggo jarum sing dibalikke
    crit_pos_back: usize,
    period: usize,
    /// `byteset` minangka ekstensi (dudu bagean saka algoritma rong arah);
    /// iku 64-dicokot "fingerprint" ngendi saben pesawat dicokot `j` ono hubungane menyang (bait&63)==j saiki ing jarum.
    ///
    byteset: u64,

    // variables
    position: usize,
    end: usize,
    /// indeks menyang jarum sadurunge kang kita wis dicocogaké
    memory: usize,
    /// indeks dadi jarum sawise kita wis cocog
    memory_back: usize,
}

/*
    This is the Two-Way search algorithm, which was introduced in the paper:
    Crochemore, M., Perrin, D., 1991, Two-way string-matching, Journal of the ACM 38(3):651-675.

    Here's some background information.

    A *word* is a string of symbols. The *length* of a word should be a familiar
    notion, and here we denote it for any word x by |x|.
    (We also allow for the possibility of the *empty word*, a word of length zero).

    If x is any non-empty word, then an integer p with 0 < p <= |x| is said to be a
    *period* for x iff for all i with 0 <= i <= |x| - p - 1, we have x[i] == x[i+p].
    For example, both 1 and 2 are periods for the string "aa". As another example,
    the only period of the string "abcd" is 4.

    We denote by period(x) the *smallest* period of x (provided that x is non-empty).
    This is always well-defined since every non-empty word x has at least one period,
    |x|. We sometimes call this *the period* of x.

    If u, v and x are words such that x = uv, where uv is the concatenation of u and
    v, then we say that (u, v) is a *factorization* of x.

    Let (u, v) be a factorization for a word x. Then if w is a non-empty word such
    that both of the following hold

      - either w is a suffix of u or u is a suffix of w
      - either w is a prefix of v or v is a prefix of w

    then w is said to be a *repetition* for the factorization (u, v).

    Just to unpack this, there are four possibilities here. Let w = "abc". Then we
    might have:

      - w is a suffix of u and w is a prefix of v. ex: ("lolabc", "abcde")
      - w is a suffix of u and v is a prefix of w. ex: ("lolabc", "ab")
      - u is a suffix of w and w is a prefix of v. ex: ("bc", "abchi")
      - u is a suffix of w and v is a prefix of w. ex: ("bc", "a")

    Note that the word vu is a repetition for any factorization (u,v) of x = uv,
    so every factorization has at least one repetition.

    If x is a string and (u, v) is a factorization for x, then a *local period* for
    (u, v) is an integer r such that there is some word w such that |w| = r and w is
    a repetition for (u, v).

    We denote by local_period(u, v) the smallest local period of (u, v). We sometimes
    call this *the local period* of (u, v). Provided that x = uv is non-empty, this
    is well-defined (because each non-empty word has at least one factorization, as
    noted above).

    It can be proven that the following is an equivalent definition of a local period
    for a factorization (u, v): any positive integer r such that x[i] == x[i+r] for
    all i such that |u| - r <= i <= |u| - 1 and such that both x[i] and x[i+r] are
    defined. (i.e., i > 0 and i + r < |x|).

    Using the above reformulation, it is easy to prove that

        1 <= local_period(u, v) <= period(uv)

    A factorization (u, v) of x such that local_period(u,v) = period(x) is called a
    *critical factorization*.

    The algorithm hinges on the following theorem, which is stated without proof:

    **Critical Factorization Theorem** Any word x has at least one critical
    factorization (u, v) such that |u| < period(x).

    The purpose of maximal_suffix is to find such a critical factorization.

    If the period is short, compute another factorization x = u' v' to use
    for reverse search, chosen instead so that |v'| < period(x).

*/
impl TwoWaySearcher {
    fn new(needle: &[u8], end: usize) -> TwoWaySearcher {
        let (crit_pos_false, period_false) = TwoWaySearcher::maximal_suffix(needle, false);
        let (crit_pos_true, period_true) = TwoWaySearcher::maximal_suffix(needle, true);

        let (crit_pos, period) = if crit_pos_false > crit_pos_true {
            (crit_pos_false, period_false)
        } else {
            (crit_pos_true, period_true)
        };

        // Katrangan sing bisa diwaca babagan kedadeyan ing kene bisa ditemokake ing buku Crochemore lan Rytter "Text Algorithms", ch 13.
        // Khusus ndeleng kode kanggo "Algorithm CP" ing hal.
        // 323.
        //
        // Apa sing kedadeyan yaiku kita duwe faktorisasi kritis (u, v) saka jarum, lan kita pengin nemtokake manawa sampeyan minangka akhiran&v [.. periode].
        // Yen iku, digunakake "Algorithm CP1".
        // Yen ora, kita nggunakake "Algorithm CP2", sing dioptimalake nalika jarum gedhe.
        //
        //
        if needle[..crit_pos] == needle[period..period + crit_pos] {
            // cilik wektu cendhak-periode kasebut ngitung faktorisasi kritis sing beda kanggo jarum sing dibalikke x=u 'v' ing endi | v '|<period(x).
            //
            // Iki nyepetake kanthi wektu sing wis dingerteni.
            // Wigati sing cilik kaya x= "acba" bisa factored persis forwards (crit_pos=1, periode=3) nalika kang factored karo wektu kira-kira ing mbalikke (crit_pos=2, periode=2).
            // Kita nggunakake faktorisasi mbalikke, nanging tetep wektu sing pas.
            //
            //
            //
            //
            let crit_pos_back = needle.len()
                - cmp::max(
                    TwoWaySearcher::reverse_maximal_suffix(needle, period, false),
                    TwoWaySearcher::reverse_maximal_suffix(needle, period, true),
                );

            TwoWaySearcher {
                crit_pos,
                crit_pos_back,
                period,
                byteset: Self::byteset_create(&needle[..period]),

                position: 0,
                end,
                memory: 0,
                memory_back: needle.len(),
            }
        } else {
            // cilik wektu dawa-kita duwe panyerakan kanggo periode nyata, lan ora nganggo lampah.
            //
            //
            // Kira-kira periode kasebut kanthi wates ngisor max(|u|, |v|) + 1.
            // The factorization kritis punika efisien digunakake kanggo loro search maju lan mbalikke.
            //

            TwoWaySearcher {
                crit_pos,
                crit_pos_back: crit_pos,
                period: cmp::max(crit_pos, needle.len() - crit_pos) + 1,
                byteset: Self::byteset_create(needle),

                position: 0,
                end,
                memory: usize::MAX, // Nilai dummy kanggo mlebu manawa suwene wis suwe
                memory_back: usize::MAX,
            }
        }
    }

    #[inline]
    fn byteset_create(bytes: &[u8]) -> u64 {
        bytes.iter().fold(0, |a, &b| (1 << (b & 0x3f)) | a)
    }

    #[inline]
    fn byteset_contains(&self, byte: u8) -> bool {
        (self.byteset >> ((byte & 0x3f) as usize)) & 1 != 0
    }

    // Salah siji saka gagasan utama Two-Way iku kita factorize jarum dados kalih bageyan, (u, v), lan miwiti nyoba golek v ing haystack dening mindhai kiwa.
    // Yen cocog karo v, kita bakal nyoba cocog karo sampeyan kanthi mindhai nengen.
    // Sepira adohé kita bisa mlumpat nalika nemoni kesalahan, kabeh adhedhasar kasunyatan (u, v) minangka faktorisasi kritis jarum.
    //
    //
    #[inline]
    fn next<S>(&mut self, haystack: &[u8], needle: &[u8], long_period: bool) -> S::Output
    where
        S: TwoWayStrategy,
    {
        // `next()` nggunakake `self.position` minangka kursor
        let old_pos = self.position;
        let needle_last = needle.len() - 1;
        'search: loop {
            // Priksa sing duwe kamar kanggo nelusuri ing posisi + needle_last bisa ora kebanjiran yen kita nganggep irisan-irisan sing diwatesi dening sawetara isize kang.
            //
            //
            let tail_byte = match haystack.get(self.position + needle_last) {
                Some(&b) => b,
                None => {
                    self.position = haystack.len();
                    return S::rejecting(old_pos, self.position);
                }
            };

            if S::use_early_reject() && old_pos != self.position {
                return S::rejecting(old_pos, self.position);
            }

            // Cepet kliwat bagean gedhe sing ora ana gandhengane karo substring kita
            if !self.byteset_contains(tail_byte) {
                self.position += needle.len();
                if !long_period {
                    self.memory = 0;
                }
                continue 'search;
            }

            // Delengen yen sisih tengen jarum cocog
            let start =
                if long_period { self.crit_pos } else { cmp::max(self.crit_pos, self.memory) };
            for i in start..needle.len() {
                if needle[i] != haystack[self.position + i] {
                    self.position += i - self.crit_pos + 1;
                    if !long_period {
                        self.memory = 0;
                    }
                    continue 'search;
                }
            }

            // Delengen yen sisih kiwa jarum cocog
            let start = if long_period { 0 } else { self.memory };
            for i in (start..self.crit_pos).rev() {
                if needle[i] != haystack[self.position + i] {
                    self.position += self.period;
                    if !long_period {
                        self.memory = needle.len() - self.period;
                    }
                    continue 'search;
                }
            }

            // Kita wis nemokake match!
            let match_pos = self.position;

            // Note: nambah self.period tinimbang needle.len() duwe nyalip cocog
            self.position += needle.len();
            if !long_period {
                self.memory = 0; // disetel menyang needle.len(), self.period kanggo pertandingan sing tumpang tindih
            }

            return S::matching(match_pos, match_pos + needle.len());
        }
    }

    // Nderek ide ing `next()`.
    //
    // Definisi kasebut simetris, kanthi period(x) = period(reverse(x)) lan local_period(u, v) = local_period(reverse(v), reverse(u)), dadi yen (u, v) minangka faktorisasi kritis, mula uga (reverse(v), reverse(u)).
    //
    //
    // Kanggo cilik mbalikke kita wis komputer kritis factorization x=u 'v' (lapangan `crit_pos_back`).Kita butuh | u |<period(x) kanggo kasus sing diterusake banjur | v '|<period(x) kanggo mbalikke.
    //
    // Kanggo nelusuri ing mbalikke liwat haystack, kita nelusuri nerusake liwat haystack ngowahi karo jarum ngowahi, cocog pisanan u 'lan banjur v'.
    //
    //
    //
    //
    #[inline]
    fn next_back<S>(&mut self, haystack: &[u8], needle: &[u8], long_period: bool) -> S::Output
    where
        S: TwoWayStrategy,
    {
        // `next_back()` nggunakake `self.end` minangka kursor-dadi `next()` lan `next_back()` bebas.
        //
        let old_end = self.end;
        'search: loop {
            // Priksa manawa kita duwe ruangan sing bisa digoleki, needle.len() bakal dibungkus nalika ora ana ruangan maneh, nanging amarga watesan dawa irisan mula ora bisa dibungkus maneh menyang dawa jerami.
            //
            //
            //
            let front_byte = match haystack.get(self.end.wrapping_sub(needle.len())) {
                Some(&b) => b,
                None => {
                    self.end = 0;
                    return S::rejecting(0, old_end);
                }
            };

            if S::use_early_reject() && old_end != self.end {
                return S::rejecting(self.end, old_end);
            }

            // Cepet kliwat bagean gedhe sing ora ana gandhengane karo substring kita
            if !self.byteset_contains(front_byte) {
                self.end -= needle.len();
                if !long_period {
                    self.memory_back = needle.len();
                }
                continue 'search;
            }

            // Delengen yen sisih kiwa jarum cocog
            let crit = if long_period {
                self.crit_pos_back
            } else {
                cmp::min(self.crit_pos_back, self.memory_back)
            };
            for i in (0..crit).rev() {
                if needle[i] != haystack[self.end - needle.len() + i] {
                    self.end -= self.crit_pos_back - i;
                    if !long_period {
                        self.memory_back = needle.len();
                    }
                    continue 'search;
                }
            }

            // Delengen yen sisih tengen jarum cocog
            let needle_end = if long_period { needle.len() } else { self.memory_back };
            for i in self.crit_pos_back..needle_end {
                if needle[i] != haystack[self.end - needle.len() + i] {
                    self.end -= self.period;
                    if !long_period {
                        self.memory_back = self.period;
                    }
                    continue 'search;
                }
            }

            // Kita wis nemokake match!
            let match_pos = self.end - needle.len();
            // Note: sub self.period tinimbang needle.len() supaya cocog karo tumpang tindih
            self.end -= needle.len();
            if !long_period {
                self.memory_back = needle.len();
            }

            return S::matching(match_pos, match_pos + needle.len());
        }
    }

    // Ngitung akhiran maksimal `arr`.
    //
    // Sufiks maksimal minangka faktorisasi kritis (u, v) `arr`.
    //
    // Bali (`i`, `p`) ing endi `i` minangka indeks wiwitan v lan `p` minangka periode v.
    //
    // `order_greater` nemtokake urutan leksikal yaiku `<` utawa `>`.
    // Kaloro pesenan kasebut kudu diitung-pesenan kanthi `i` paling gedhe menehi faktorisasi kritis.
    //
    //
    // Kanggo kasus wektu sing suwe, periode sing diasilake ora pas (banget cendhak).
    //
    #[inline]
    fn maximal_suffix(arr: &[u8], order_greater: bool) -> (usize, usize) {
        let mut left = 0; // Cocog karo i ing kertas
        let mut right = 1; // Ono hubungane kanggo j ing kertas
        let mut offset = 0; // Ono hubungane kanggo k ing kertas, nanging miwiti ing 0
        // kanggo cocog karo indeksasi adhedhasar 0.
        let mut period = 1; // Cocog karo p ing kertas

        while let Some(&a) = arr.get(right + offset) {
            // `left` bakal mlebu nalika `right`.
            let b = arr[left + offset];
            if (a < b && !order_greater) || (a > b && order_greater) {
                // Seselan iku cilik, wektu iku kabeh ater-ater supaya adoh.
                right += offset + 1;
                offset = 0;
                period = right - left;
            } else if a == b {
                // Maju liwat pengulangan periode saiki.
                if offset + 1 == period {
                    right += offset + 1;
                    offset = 0;
                } else {
                    offset += 1;
                }
            } else {
                // Suffix luwih gedhe, wiwit saka lokasi saiki.
                left = right;
                right += 1;
                offset = 0;
                period = 1;
            }
        }
        (left, period)
    }

    // Ngétung pungkasan maksimal saka mbalikke saka `arr`.
    //
    // Pungkasan maksimal iku factorization kritis bisa (u ', v') saka `arr`.
    //
    // Ngasilake `i` ing endi `i` minangka indeks wiwitan v ', saka sisih mburi;
    // bali langsung nalika tekan `known_period`.
    //
    // `order_greater` nemtokake urutan leksikal yaiku `<` utawa `>`.
    // Kaloro pesenan kasebut kudu diitung-pesenan kanthi `i` paling gedhe menehi faktorisasi kritis.
    //
    //
    // Kanggo kasus wektu sing suwe, periode sing diasilake ora pas (banget cendhak).
    fn reverse_maximal_suffix(arr: &[u8], known_period: usize, order_greater: bool) -> usize {
        let mut left = 0; // Cocog karo i ing kertas
        let mut right = 1; // Ono hubungane kanggo j ing kertas
        let mut offset = 0; // Ono hubungane kanggo k ing kertas, nanging miwiti ing 0
        // kanggo cocog karo indeksasi adhedhasar 0.
        let mut period = 1; // Cocog karo p ing kertas
        let n = arr.len();

        while right + offset < n {
            let a = arr[n - (1 + right + offset)];
            let b = arr[n - (1 + left + offset)];
            if (a < b && !order_greater) || (a > b && order_greater) {
                // Seselan iku cilik, wektu iku kabeh ater-ater supaya adoh.
                right += offset + 1;
                offset = 0;
                period = right - left;
            } else if a == b {
                // Maju liwat pengulangan periode saiki.
                if offset + 1 == period {
                    right += offset + 1;
                    offset = 0;
                } else {
                    offset += 1;
                }
            } else {
                // Suffix luwih gedhe, wiwit saka lokasi saiki.
                left = right;
                right += 1;
                offset = 0;
                period = 1;
            }
            if period == known_period {
                break;
            }
        }
        debug_assert!(period <= known_period);
        left
    }
}

// TwoWayStrategy ngidini algoritma kanggo salah siji skip non-cocog minangka cepet sabisa, utawa kanggo karya ing mode ngendi mancaraken nolak sacepete.
//
trait TwoWayStrategy {
    type Output;
    fn use_early_reject() -> bool;
    fn rejecting(a: usize, b: usize) -> Self::Output;
    fn matching(a: usize, b: usize) -> Self::Output;
}

/// Mlayu supaya cocog karo interval kanthi cepet
enum MatchOnly {}

impl TwoWayStrategy for MatchOnly {
    type Output = Option<(usize, usize)>;

    #[inline]
    fn use_early_reject() -> bool {
        false
    }
    #[inline]
    fn rejecting(_a: usize, _b: usize) -> Self::Output {
        None
    }
    #[inline]
    fn matching(a: usize, b: usize) -> Self::Output {
        Some((a, b))
    }
}

/// Emit Nolak kanthi rutin
enum RejectAndMatch {}

impl TwoWayStrategy for RejectAndMatch {
    type Output = SearchStep;

    #[inline]
    fn use_early_reject() -> bool {
        true
    }
    #[inline]
    fn rejecting(a: usize, b: usize) -> Self::Output {
        SearchStep::Reject(a, b)
    }
    #[inline]
    fn matching(a: usize, b: usize) -> Self::Output {
        SearchStep::Match(a, b)
    }
}