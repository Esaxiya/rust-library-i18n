use crate::iter::FromIterator;

/// Runtuh kabeh item unit saka sawijining iterator dadi siji.
///
/// Iki luwih migunani yen dikombinasikake karo abstraksi level sing luwih dhuwur, kayata nglumpukake menyang `Result<(), E>` sing mung peduli karo kesalahan:
///
///
/// ```
/// use std::io::*;
/// let data = vec![1, 2, 3, 4, 5];
/// let res: Result<()> = data.iter()
///     .map(|x| writeln!(stdout(), "{}", x))
///     .collect();
/// assert!(res.is_ok());
/// ```
#[stable(feature = "unit_from_iter", since = "1.23.0")]
impl FromIterator<()> for () {
    fn from_iter<I: IntoIterator<Item = ()>>(iter: I) -> Self {
        iter.into_iter().for_each(|()| {})
    }
}