use crate::ops::{Deref, DerefMut};
use crate::ptr;

/// Bungkus kanggo nyegah compiler kanthi otomatis nyebut 'destruktor' T`.
/// pambungkus Iki 0-biaya.
///
/// `ManuallyDrop<T>` tundhuk pangoptimal tata letak sing padha karo `T`.
/// Minangka akibat, wis *efek* pemanggih sing compiler ndadekake bab isi.
/// Contone, dhisik sing `ManuallyDrop<&mut T>` karo [`mem::zeroed`] punika prilaku cetho.
/// Yen sampeyan kudu ngatasi data sing durung diresmine, gunakake [`MaybeUninit<T>`].
///
/// Elinga yen ngakses nilai ing `ManuallyDrop<T>` aman.
/// liya iki sing `ManuallyDrop<T>` kang isi wis dropped ora kudu kapapar liwat API aman umum.
/// Kajaba, `ManuallyDrop::drop` ora aman.
///
/// # `ManuallyDrop` lan nyelehake supaya.
///
/// Rust wis uga ditetepake [drop order] nilai.
/// Kanggo nggawe manawa kothak utawa warga sing dropped ing urutan tartamtu, diurutake maneh ing pranyatan sing gulung supaya iso dilacak iku kang bener.
///
/// Sampeyan bisa nggunakake `ManuallyDrop` kanggo ngontrol pesenan gulung, nanging iki mbutuhake kode sing ora aman lan angel ditindakake kanthi bener nalika ngaso.
///
///
/// Contone, yen sampeyan pengin nggawe manawa kolom tartamtu dropped sawise wong, wis lapangan pungkasan struct a:
///
/// ```
/// struct Context;
///
/// struct Widget {
///     children: Vec<Widget>,
///     // `context` bakal dropped sawise `children`.
///     // Rust njamin bilih lapangan-lapangan sing dropped ing urutan Pranyatan.
///     context: Context,
/// }
/// ```
///
/// [drop order]: https://doc.rust-lang.org/reference/destructors.html
/// [`mem::zeroed`]: crate::mem::zeroed
/// [`MaybeUninit<T>`]: crate::mem::MaybeUninit
///
///
///
///
///
#[stable(feature = "manually_drop", since = "1.20.0")]
#[lang = "manually_drop"]
#[derive(Copy, Clone, Debug, Default, PartialEq, Eq, PartialOrd, Ord, Hash)]
#[repr(transparent)]
pub struct ManuallyDrop<T: ?Sized> {
    value: T,
}

impl<T> ManuallyDrop<T> {
    /// Lebokake Nilai kanggo bakal dropped manual.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let mut x = ManuallyDrop::new(String::from("Hello World!"));
    /// x.truncate(5); // Sampeyan isih bisa aman operate ing Nilai
    /// assert_eq!(*x, "Hello");
    /// // Nanging `Drop` ora bakal mbukak ing kene
    /// ```
    #[must_use = "if you don't need the wrapper, you can use `mem::forget` instead"]
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(value: T) -> ManuallyDrop<T> {
        ManuallyDrop { value }
    }

    /// Ekstrak regane saka wadhah `ManuallyDrop`.
    ///
    /// Iki ngidini Nilai kanggo bakal dropped maneh.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let x = ManuallyDrop::new(Box::new(()));
    /// let _: Box<()> = ManuallyDrop::into_inner(x); // Iki ngeculake `Box`.
    /// ```
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn into_inner(slot: ManuallyDrop<T>) -> T {
        slot.value
    }

    /// Entuk nilai saka kontainer `ManuallyDrop<T>`.
    ///
    /// Cara iki utamane dimaksudake kanggo mindhah angka-angka.
    /// Tinimbang nggunakake [`ManuallyDrop::drop`] kanggo nyelehake angka kanthi manual, sampeyan bisa nggunakake metode iki kanggo njupuk regane lan digunakake, nanging dikepengini.
    ///
    /// Yen bisa, luwih becik nggunakake [`into_inner`][`ManuallyDrop::into_inner`], sing ngalangi duplikat konten `ManuallyDrop<T>`.
    ///
    ///
    /// # Safety
    ///
    /// Fungsi iki redaksional gerakane metu Nilai sing tanpa nyegah Panggunan luwih, ninggalake negara sing iki panggah.
    /// Tanggung jawab sampeyan kanggo mesthekake yen `ManuallyDrop` iki ora digunakake maneh.
    ///
    ///
    ///
    #[must_use = "if you don't need the value, you can use `ManuallyDrop::drop` instead"]
    #[stable(feature = "manually_drop_take", since = "1.42.0")]
    #[inline]
    pub unsafe fn take(slot: &mut ManuallyDrop<T>) -> T {
        // SAFETY: kita maca saka referensi, kang wis dijamin
        // dadi valid kanggo maos.
        unsafe { ptr::read(&slot.value) }
    }
}

impl<T: ?Sized> ManuallyDrop<T> {
    /// Manual irungnya ing Nilai sing.Iki padha karo panggilan [`ptr::drop_in_place`] kanthi pitunjuk kanggo nilai sing ana.
    /// Kaya ngono, kajaba yen regane ngemot minangka strukture sing dikemas, destruktor bakal kasebut ing panggonane tanpa obah-obah, lan mula bisa digunakake kanggo nyelehake data [pinned] kanthi aman.
    ///
    /// Yen sampeyan duwe angka kasebut, sampeyan bisa nggunakake [`ManuallyDrop::into_inner`].
    ///
    /// # Safety
    ///
    /// Fungsi iki mbukak destruktor kanggo nilai sing ana.
    /// Liyane saka owah-owahan digawe dening destructor dhewe, memori wis ngiwa panggah, lan minangka adoh minangka compiler sing mrihatinake isih ngemu dicokot-pola kang bener kanggo jinis `T`.
    ///
    ///
    /// Nanging, nilai "zombie" iki ora bisa ngirim kapapar kode aman, lan fungsi iki ora bisa disebut luwih saka sapisan.
    /// Kanggo nggunakake nilai sawise iku wis dropped, utawa nyelehake nilai kaping pirang-pirang, bisa nimbulaké Behavior Undefined (gumantung apa `drop` ora).
    /// Iki biasane nyegah dening sistem jinis, nanging pangguna saka `ManuallyDrop` kudu njejegaké sing njamin tanpa pitulungan saka compiler ing.
    ///
    /// [pinned]: crate::pin
    ///
    ///
    ///
    ///
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[inline]
    pub unsafe fn drop(slot: &mut ManuallyDrop<T>) {
        // SAFETY: kita ngeculake Nilai nuding kanthi referensi mutable
        // kang dijamin dadi bener kanggo nyerat.
        // Mungkasi panelpon manawa `slot` ora dicopot maneh.
        unsafe { ptr::drop_in_place(&mut slot.value) }
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> Deref for ManuallyDrop<T> {
    type Target = T;
    #[inline(always)]
    fn deref(&self) -> &T {
        &self.value
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> DerefMut for ManuallyDrop<T> {
    #[inline(always)]
    fn deref_mut(&mut self) -> &mut T {
        &mut self.value
    }
}