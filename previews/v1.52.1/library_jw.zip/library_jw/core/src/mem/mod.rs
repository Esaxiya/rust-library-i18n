//! fungsi-fungsi dhasar kanggo dealing with memori.
//!
//! modul iki ngandhut fungsi kanggo querying ukuran lan Alignment saka jinis, dhisik lan manipulasi memori.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::clone;
use crate::cmp;
use crate::fmt;
use crate::hash;
use crate::intrinsics;
use crate::marker::{Copy, DiscriminantKind, Sized};
use crate::ptr;

mod manually_drop;
#[stable(feature = "manually_drop", since = "1.20.0")]
pub use manually_drop::ManuallyDrop;

mod maybe_uninit;
#[stable(feature = "maybe_uninit", since = "1.36.0")]
pub use maybe_uninit::MaybeUninit;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::transmute;

/// Njupuk kepemilikan lan "forgets" babagan nilai **tanpa mlaku destructor sawijining**.
///
/// Sumber daya apa wae sing dikelola regane, kayata memori tumpukan utawa gagang file, bakal tetep ing salawas-lawase ing kahanan sing ora bisa digayuh.Nanging, iku ora njamin sing penunjuk kanggo memori iki bakal tetep bener.
///
/// * Yen sampeyan pengin bocor memori, deleng [`Box::leak`].
/// * Yen sampeyan pengin diwenehi pitunjuk mentahan kanggo memori, ndeleng [`Box::into_raw`].
/// * Yen sampeyan pengin mbuwang regane mlaku, mlaku destructor sawijining, ndeleng [`mem::drop`].
///
/// # Safety
///
/// `forget` ora ditandhani minangka `unsafe`, amarga jaminan keamanan Rust ora kalebu jaminan yen destruktor bakal terus mlaku.
/// Contone, program bisa nggawe siklus referensi nggunakake [`Rc`][rc], utawa nelpon [`process::exit`][exit] kanggo metu tanpa mlaku destructors.
/// Mangkono, ngidini `mem::forget` saka kode sing aman ora dhasar ngganti jaminan keamanan Rust.
///
/// Sing ngandika, bocor sumber daya kayata memori utawa obyek I/O biasane undesirable.
/// perlu rawuh ing sawetara kasus panggunaan kanggo urip FFI utawa kode aman, nanging malah banjur, [`ManuallyDrop`] biasane disenengi.
///
/// Amarga dilalekake Nilai wis diijini, sembarang kode `unsafe` nulis kudu ngidini kanggo kamungkinan iki.Sampeyan ora bisa ngasilake angka lan ngarepake manawa panelpon kudu mbukak kerusakan nilai kasebut.
///
/// [rc]: ../../std/rc/struct.Rc.html
/// [exit]: ../../std/process/fn.exit.html
///
/// # Examples
///
/// Panggunaan aman kanonis `mem::forget` yaiku kanggo ngrusak destruktor nilai sing dileksanakake dening `Drop` trait.Contone, iki bakal bocor a `File`, IE
/// mbalekake papan dijupuk dening global nanging ora tau cedhak sumber sistem ndasari:
///
/// ```no_run
/// use std::mem;
/// use std::fs::File;
///
/// let file = File::open("foo.txt").unwrap();
/// mem::forget(file);
/// ```
///
/// Iki migunani nalika kepemilikan sumber dhasar sing sadurunge ditransfer menyang kode ing sanjabane Rust, umpamane ngirimake deskriptor file mentah menyang kode C.
///
/// # Hubungan karo `ManuallyDrop`
///
/// Nalika `mem::forget` bisa uga dipigunakaké kanggo mindhah *memori* kepemilikan, mengkono iku kesalahan-rawan.
/// [`ManuallyDrop`] kudu digunakake wae.Coba, contone, kode iki:
///
/// ```
/// use std::mem;
///
/// let mut v = vec![65, 122];
/// // Mbangun `String` nggunakake isi `v`
/// let s = unsafe { String::from_raw_parts(v.as_mut_ptr(), v.len(), v.capacity()) };
/// // bocor `v` amarga memori saiki dikelola déning `s`
/// mem::forget(v);  // ERROR, v ora sah lan ora kudu liwati menyang fungsi
/// assert_eq!(s, "Az");
/// // `s` wis implicitly dropped lan memori deallocated.
/// ```
///
/// Ana rong masalah karo conto ing ndhuwur:
///
/// * Yen ditambahake kode ing antarane konstruksi `String` lan invasi `mem::forget()`, panic ing njero kasebut bakal nyebabake kaping pindho gratis amarga memori sing padha ditangani dening `v` lan `s`.
/// * Sawise nelpon `v.as_mut_ptr()` lan ngirim kepemilikan saka data kanggo `s`, nilai `v` ora sah.
/// Sanajan regane mung dipindhah menyang `mem::forget` (sing ora bakal dipriksa), sawetara jinis duwe syarat sing ketat kanggo nilai sing ndadekake ora valid nalika digantung utawa ora diduweni maneh.
/// Nggunakake nilai sing ora valid kanthi cara apa wae, kalebu ngirim utawa mbalekake saka fungsi, minangka tumindak sing durung ditemtokake lan bisa uga ngilangi asumsi sing digawe dening panyusun.
///
/// Ngalih menyang `ManuallyDrop` ngindhari kaloro masalah:
///
/// ```
/// use std::mem::ManuallyDrop;
///
/// let v = vec![65, 122];
/// // Sadurunge mbubarake `v` menyang bagean sing mentah, priksa manawa ora tiba!
/////
/// let mut v = ManuallyDrop::new(v);
/// // Saiki mbongkar `v`.Operasi kasebut ora bisa panic, mula ora bisa ana bocor.
/// let (ptr, len, cap) = (v.as_mut_ptr(), v.len(), v.capacity());
/// // Akhire, mbangun `String`.
/// let s = unsafe { String::from_raw_parts(ptr, len, cap) };
/// assert_eq!(s, "Az");
/// // `s` wis implicitly dropped lan memori deallocated.
/// ```
///
/// `ManuallyDrop` kuat ngalangi bebas dobel amarga kita mateni perusak `v` sadurunge nindakake tindakan liya.
/// `mem::forget()` ora ngidini iki amarga nggunakake argumen, meksa kita nelpon mung sawise ngekstrak apa wae sing dibutuhake saka `v`.
/// Sanajan panic dilebokake ing antarane konstruksi `ManuallyDrop` lan nggawe senar (sing ora bisa kedadeyan ing kode kaya sing dituduhake), bakal nyebabake bocor lan ora bebas dobel.
/// Kanthi tembung liyane, `ManuallyDrop` salah ing sisih bocor tinimbang kesalahan ing sisih (gandha-) ngeculake.
///
/// Kajaba iku, `ManuallyDrop` ngalangi kita supaya ora "touch" `v` sawise transfer kepemilikan menyang `s`-langkah pungkasan kanggo sesambungan karo `v` kanggo mbuwang tanpa nggunakake destruktore bisa dihindari.
///
///
/// [`Box`]: ../../std/boxed/struct.Box.html
/// [`Box::leak`]: ../../std/boxed/struct.Box.html#method.leak
/// [`Box::into_raw`]: ../../std/boxed/struct.Box.html#method.into_raw
/// [`mem::drop`]: drop
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[rustc_const_stable(feature = "const_forget", since = "1.46.0")]
#[stable(feature = "rust1", since = "1.0.0")]
pub const fn forget<T>(t: T) {
    let _ = ManuallyDrop::new(t);
}

/// Kaya [`forget`], nanging uga nampa angka tanpa ukuran.
///
/// Fungsi iki mung kanggo tujuan nalika fitur `unsized_locals` dadi stabil.
///
#[inline]
#[unstable(feature = "forget_unsized", issue = "none")]
pub fn forget_unsized<T: ?Sized>(t: T) {
    intrinsics::forget(t)
}

/// Ngasilake ukuran jinis bait.
///
/// Luwih khusus, iki minangka offset byte ing antarane unsur-unsur berturut-turut ing larik kanthi jinis item kalebu padding alignment.
///
/// Dadi, kanggo jinis `T` lan dawa `n`, `[T; n]` duwe ukuran `n * size_of::<T>()`.
///
/// Umume, ukuran jinis ora stabil ing kompilasi, nanging jinis tartamtu kayata primitif.
///
/// Tabel ing ngisor iki menehi ukuran kanggo primitif.
///
/// Jinis |size_of: :\<Type>()
/// ---- | ---------------
/// () |0 bool |1 u8 |1 u16 |2 u32 |4 u64 |8 u128 |16 i8 |1 i16 |2 i32 |4 i64 |8 i128 |16 f32 |4 f64 |8 char |4
///
/// Salajengipun, `usize` lan `isize` duwe ukuran sing padha.
///
/// Jinis `*const T`, `&T`, `Box<T>`, `Option<&T>`, lan `Option<Box<T>>` kabeh padha ukurane.
/// Yen `T` Ukuran, kabeh jinis kasebut duwe ukuran padha karo `usize`.
///
/// Mutasi pitunjuk ora ngganti ukurane.Kaya ngono, `&T` lan `&mut T` duwe ukuran sing padha.
/// Kajaba iku kanggo `*const T` lan `* mut T`.
///
/// # Ukuran barang `#[repr(C)]`
///
/// Perwakilan `C` kanggo item duwe tata letak sing wis ditemtokake.
/// Kanthi tata letak iki, ukuran item uga stabil anggere kabeh kolom duwe ukuran stabil.
///
/// ## Ukuran Struktur
///
/// Kanggo `structs`, ukuran ditemtokake dening algoritma ing ngisor iki.
///
/// Kanggo saben lapangan ing struktur sing diprentahake kanthi urutan deklarasi:
///
/// 1. Tambahake ukuran lapangan.
/// 2. Babak ukuran saiki menyang macem-macem paling cedhak [alignment] lapangan sabanjure.
///
/// Pungkasan, bunder ukuran strukture menyang pirang-pirang [alignment] sing paling cedhak.
/// Alignment saka struktur biasane dadi jajaran paling gedhe ing kabeh lapangan;iki bisa diganti nganggo `repr(align(N))`.
///
/// Beda karo `C`, strukture ukuran nol ora dibunderaké nganti siji byte.
///
/// ## Ukuran Enum
///
/// Enum sing ora nggawa data liyane kajaba diskriminasi duwe ukuran padha karo enum C ing platform sing dikompilasi.
///
/// ## Ukuran Serikat Pekerjaan
///
/// Ukuran uni yaiku ukuran lapangan sing paling gedhe.
///
/// Beda karo `C`, serikat ukuran nol ora dibunderaké nganti siji byte.
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// // Sawetara primitif
/// assert_eq!(4, mem::size_of::<i32>());
/// assert_eq!(8, mem::size_of::<f64>());
/// assert_eq!(0, mem::size_of::<()>());
///
/// // sawetara susunan
/// assert_eq!(8, mem::size_of::<[i32; 2]>());
/// assert_eq!(12, mem::size_of::<[i32; 3]>());
/// assert_eq!(0, mem::size_of::<[i32; 0]>());
///
///
/// // Kesetaraan ukuran pointer
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<*const i32>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Box<i32>>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Option<&i32>>());
/// assert_eq!(mem::size_of::<Box<i32>>(), mem::size_of::<Option<Box<i32>>>());
/// ```
///
/// Nggunakake `#[repr(C)]`.
///
/// ```
/// use std::mem;
///
/// #[repr(C)]
/// struct FieldStruct {
///     first: u8,
///     second: u16,
///     third: u8
/// }
///
/// // Ukuran kolom kapisan yaiku 1, mula nambahake ukuran 1.Ukuran punika 1.
/// // Alignment saka lapangan kapindho iku 2, supaya nambah 1 kanggo ukuran kanggo lapis.Size 2.
/// // Ukuran lapangan kapindho iku 2, supaya nambah 2 ukuran sing.Ukuran punika 4.
/// // Jajaran kolom kaping telu yaiku 1, mula tambah 0 kanggo ukuran padding.Ukurane 4.
/// // Ukuran lapangan katelu 1, supaya nambah 1 kanggo ukuran.Size 5.
/// // Pungkasane, keselarasan strukture 2 (amarga jajaran paling gedhe ing antarane lapangan 2), mula tambahi 1 ukuran kanggo bantalan.
/// // Ukurane 6.
/// assert_eq!(6, mem::size_of::<FieldStruct>());
///
/// #[repr(C)]
/// struct TupleStruct(u8, u16, u8);
///
/// // Tuple structs tindakake aturan padha.
/// assert_eq!(6, mem::size_of::<TupleStruct>());
///
/// // Elinga yen reordering kothak bisa murah ukuran.
/// // Kita bisa mbusak bait padding kanthi nyelehake `third` sadurunge `second`.
/// #[repr(C)]
/// struct FieldStructOptimized {
///     first: u8,
///     third: u8,
///     second: u16
/// }
///
/// assert_eq!(4, mem::size_of::<FieldStructOptimized>());
///
/// // Ukuran Union minangka ukuran lapangan paling gedhe.
/// #[repr(C)]
/// union ExampleUnion {
///     smaller: u8,
///     larger: u16
/// }
///
/// assert_eq!(2, mem::size_of::<ExampleUnion>());
/// ```
///
/// [alignment]: align_of
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_size_of", since = "1.32.0")]
pub const fn size_of<T>() -> usize {
    intrinsics::size_of::<T>()
}

/// Ngasilake ukuran nilai sing dituduhake ing bait.
///
/// Biasane padha karo `size_of::<T>()`.
/// Nanging, nalika `T`*ora duwe* ukuran sing dingerteni sacara statis, kayata irisan [`[T]`][slice] utawa [trait object], mula `size_of_val` bisa digunakake kanggo njupuk ukuran sing dingerteni kanthi dinamis.
///
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, mem::size_of_val(y));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
pub const fn size_of_val<T: ?Sized>(val: &T) -> usize {
    // SAFETY: `val` minangka referensi, dadi pitunjuk mentah sing bener
    unsafe { intrinsics::size_of_val(val) }
}

/// Ngasilake ukuran nilai sing dituduhake ing bait.
///
/// Biasane padha karo `size_of::<T>()`.Nanging, nalika `T`*ora duwe* ukuran sing dingerteni sacara statis, kayata irisan [`[T]`][slice] utawa [trait object], mula `size_of_val_raw` bisa digunakake kanggo njupuk ukuran sing dingerteni kanthi dinamis.
///
/// # Safety
///
/// Fungsi iki mung aman ditelpon yen ana kahanan ing ngisor iki:
///
/// - Yen `T` `Sized`, fungsi iki mesthi aman ditelpon.
/// - Yen buntut `T` sing ora diukur yaiku:
///     - [slice], banjur dawa buntut irisan kudu dadi ongko inisialisasi, lan ukuran *kabeh nilai*(dawa buntut dinamis + awalan ukuran statis) kudu pas karo `isize`.
///     - [trait object], mula bagean sing bisa ditampilake ing pointer kudu nuduhake tabel sing valid sing dipikolehi kanthi paksaan sing ukurane, lan ukuran *kabeh nilai*(dawa buntut dinamis + awalan ukuran statis) kudu pas karo `isize`.
///
///     - lan (unstable) [extern type], banjur fungsi iki tansah aman kanggo nelpon, nanging uga panic utawa digunakake bali Nilai salah, minangka tata jinis extern kang wis ora dikenal.
///     Iki minangka tindak tanduk sing padha karo [`size_of_val`] babagan referensi jinis sing buntut jinis eksternal.
///     - yen ora, konservatif ora diijini nelpon fungsi iki.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, unsafe { mem::size_of_val_raw(y) });
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_size_of_val_raw", issue = "46571")]
pub const unsafe fn size_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // SAFETY: panelpon kudu menehi penunjuk mentah sing valid
    unsafe { intrinsics::size_of_val(val) }
}

/// Ngasilake alignment minimal [ABI] sing dibutuhake kanggo jinis.
///
/// Saben referensi kanggo nilai jinis `T` kudu ana pirang-pirang nomer iki.
///
/// Iki minangka alignment sing digunakake kanggo kolom struktural.Bisa uga luwih cilik tinimbang keselarasan sing disenengi.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of::<i32>());
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of` instead", since = "1.2.0")]
pub fn min_align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// Ngasilake alignment minimal [ABI] sing dibutuhake kanggo jinis nilai sing dituduhake `val`.
///
/// Saben referensi kanggo nilai jinis `T` kudu ana pirang-pirang nomer iki.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of_val` instead", since = "1.2.0")]
pub fn min_align_of_val<T: ?Sized>(val: &T) -> usize {
    // SAFETY: val minangka referensi, dadi pitunjuk mentah sing bener
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Ngasilake alignment minimal [ABI] sing dibutuhake kanggo jinis.
///
/// Saben referensi kanggo nilai jinis `T` kudu ana pirang-pirang nomer iki.
///
/// Iki minangka alignment sing digunakake kanggo kolom struktural.Bisa uga luwih cilik tinimbang keselarasan sing disenengi.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of::<i32>());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_align_of", since = "1.32.0")]
pub const fn align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// Ngasilake alignment minimal [ABI] sing dibutuhake kanggo jinis nilai sing dituduhake `val`.
///
/// Saben referensi kanggo nilai jinis `T` kudu ana pirang-pirang nomer iki.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
#[allow(deprecated)]
pub const fn align_of_val<T: ?Sized>(val: &T) -> usize {
    // SAFETY: val minangka referensi, dadi pitunjuk mentah sing bener
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Ngasilake alignment minimal [ABI] sing dibutuhake kanggo jinis nilai sing dituduhake `val`.
///
/// Saben referensi kanggo nilai jinis `T` kudu ana pirang-pirang nomer iki.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Safety
///
/// Fungsi iki mung aman ditelpon yen ana kahanan ing ngisor iki:
///
/// - Yen `T` `Sized`, fungsi iki mesthi aman ditelpon.
/// - Yen buntut `T` sing ora diukur yaiku:
///     - [slice], banjur dawa buntut irisan kudu dadi ongko inisialisasi, lan ukuran *kabeh nilai*(dawa buntut dinamis + awalan ukuran statis) kudu pas karo `isize`.
///     - [trait object], mula bagean sing bisa ditampilake ing pointer kudu nuduhake tabel sing valid sing dipikolehi kanthi paksaan sing ukurane, lan ukuran *kabeh nilai*(dawa buntut dinamis + awalan ukuran statis) kudu pas karo `isize`.
///
///     - lan (unstable) [extern type], banjur fungsi iki tansah aman kanggo nelpon, nanging uga panic utawa digunakake bali Nilai salah, minangka tata jinis extern kang wis ora dikenal.
///     Iki minangka tindak tanduk sing padha karo [`align_of_val`] babagan referensi jinis sing buntut jinis eksternal.
///     - yen ora, konservatif ora diijini nelpon fungsi iki.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, unsafe { mem::align_of_val_raw(&5i32) });
/// ```
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_align_of_val_raw", issue = "46571")]
pub const unsafe fn align_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // SAFETY: panelpon kudu menehi penunjuk mentah sing valid
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Ngasilake `true` yen ngeculake angka jinis `T`.
///
/// Iki sejatine minangka pitunjuk optimasi, lan bisa uga diterapake kanthi konservatif:
/// bisa ngasilake `true` kanggo jinis sing ora nate dibuwang.
/// Kaya ngono `true` bali mesthi dadi implementasi fungsi iki sing valid.Nanging yen fungsi iki nyata ngasilake `false`, mula sampeyan bakal bisa ngeculake `T` ora ana efek samping.
///
/// Implementasi barang sing kurang kaya koleksi, sing kudu nyelehake data kanthi manual, kudu nggunakake fungsi iki supaya ora nyoba nyoba ngeculake kabeh konten nalika rusak.
///
/// Iki bisa uga ora nggawe bedane nalika nggawe rilis (nalika loop sing ora duwe efek samping gampang dideteksi lan diilangi), nanging asring menang gedhe kanggo nggawe debug.
///
/// Elinga yen [`drop_in_place`] wis nindakake cek iki, mula yen beban kerja sampeyan bisa dikurangi dadi sawetara telpon [`drop_in_place`], mula ora perlu.
/// Utamane, elinga yen sampeyan bisa [`drop_in_place`] sepotong, lan bakal mriksa priksa siji kanggo kabeh nilai.
///
/// Jinis kaya Vec, mung `drop_in_place(&mut self[..])` tanpa nggunakake `needs_drop` kanthi jelas.
/// Jinis kaya [`HashMap`], ing tangan liyane, kudu ngeculake angka siji-siji lan kudu nggunakake API iki.
///
/// [`drop_in_place`]: crate::ptr::drop_in_place
/// [`HashMap`]: ../../std/collections/struct.HashMap.html
///
/// # Examples
///
/// Mangkene conto babagan cara nglumpukake `needs_drop`:
///
/// ```
/// use std::{mem, ptr};
///
/// pub struct MyCollection<T> {
/// #   data: [T; 1],
///     /* ... */
/// }
/// # impl<T> MyCollection<T> {
/// #   fn iter_mut(&mut self) -> &mut [T] { &mut self.data }
/// #   fn free_buffer(&mut self) {}
/// # }
///
/// impl<T> Drop for MyCollection<T> {
///     fn drop(&mut self) {
///         unsafe {
///             // nyelehake data
///             if mem::needs_drop::<T>() {
///                 for x in self.iter_mut() {
///                     ptr::drop_in_place(x);
///                 }
///             }
///             self.free_buffer();
///         }
///     }
/// }
/// ```
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "needs_drop", since = "1.21.0")]
#[rustc_const_stable(feature = "const_needs_drop", since = "1.36.0")]
#[rustc_diagnostic_item = "needs_drop"]
pub const fn needs_drop<T>() -> bool {
    intrinsics::needs_drop::<T>()
}

/// Ngasilake angka jinis `T` sing dituduhake pola kabeh-nol byte.
///
/// Iki tegese, contone, byte bantalan ing `(u8, u16)` durung mesthi nol.
///
/// Ora ana jaminan manawa pola byte kabeh nol nuduhake nilai valid kanggo sawetara jinis `T`.
/// Contone, pola byte kabeh-nol dudu nilai sing valid kanggo jinis referensi (`&T`, `&mut T`) lan petunjuk fungsi.
/// Nggunakake `zeroed` ing jinis kasebut nyebabake [undefined behavior][ub] langsung amarga [the Rust compiler assumes][inv] sing mesthi ana nilai sing valid ing variabel sing dianggep wiwitan.
///
///
/// Iki duwe efek sing padha karo [`MaybeUninit::zeroed().assume_init()`][zeroed].
/// Kadhangkala migunani kanggo FFI, nanging umume kudu dihindari.
///
/// [zeroed]: MaybeUninit::zeroed
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [inv]: MaybeUninit#initialization-invariant
///
/// # Examples
///
/// Panggunaan fungsi iki kanthi bener: nginisialisasi bilangan bulat karo nol.
///
/// ```
/// use std::mem;
///
/// let x: i32 = unsafe { mem::zeroed() };
/// assert_eq!(0, x);
/// ```
///
/// *Salah* panggunaan fungsi iki: miwiti referensi kanthi nol.
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem;
///
/// let _x: &i32 = unsafe { mem::zeroed() }; // Prilaku sing durung ditemtokake!
/// let _y: fn() = unsafe { mem::zeroed() }; // Lan maneh!
/// ```
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_zeroed"]
pub unsafe fn zeroed<T>() -> T {
    // SAFETY: panelpon kudu njamin yen nilai nol kabeh valid kanggo `T`.
    unsafe {
        intrinsics::assert_zero_valid::<T>();
        MaybeUninit::zeroed().assume_init()
    }
}

/// Priksa inisialisasi memori normal Bypass Rust kanthi pura-pura ngasilake angka jinis `T`, nalika ora nindakake apa-apa.
///
/// **Fungsi iki ora digunakake maneh.** Gunakake [`MaybeUninit<T>`] wae.
///
/// Alesan panyusutan yaiku fungsi sing dhasar ora bisa digunakake kanthi bener: duwe efek sing padha karo [`MaybeUninit::uninit().assume_init()`][uninit].
///
/// Minangka [`assume_init` documentation][assume_init] nerangake, [the Rust compiler assumes][inv] yen angka diwiwiti kanthi bener.
/// Akibate, nelpon eg
/// `mem::uninitialized::<bool>()` nyebabake tumindak sing durung ditemtokake langsung kanggo ngasilake `bool` sing durung mesthi `true` utawa `false`.
/// Memori sing luwih elek, sejatine ora diresmine kaya sing bali ing kene khusus amarga kompiler ngerti manawa ora duwe nilai tetep.
/// Iki ndadekake prilaku sing durung ditemtokake duwe data sing durung dinialisasi ing variabel sanajan variabel kasebut duwe jinis integer.
/// (Elinga yen aturan babagan wilangan bulat sing durung diresmine durung rampung, nanging nganti luwih becik, luwih becik disingkiri.)
///
/// [uninit]: MaybeUninit::uninit
/// [assume_init]: MaybeUninit::assume_init
/// [inv]: MaybeUninit#initialization-invariant
///
///
///
///
///
#[inline(always)]
#[rustc_deprecated(since = "1.39.0", reason = "use `mem::MaybeUninit` instead")]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_uninitialized"]
pub unsafe fn uninitialized<T>() -> T {
    // SAFETY: panelpon kudu njamin manawa regane unitialisasi valid kanggo `T`.
    unsafe {
        intrinsics::assert_uninit_valid::<T>();
        MaybeUninit::uninit().assume_init()
    }
}

/// Ganti angka ing rong lokasi sing bisa diowahi, tanpa ngilangi salah siji.
///
/// * Yen sampeyan pengin ngganti karo nilai default utawa dummy, deleng [`take`].
/// * Yen sampeyan pengin ijolan karo nilai sing kliwat, baliake nilai lawas, deleng [`replace`].
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// let mut x = 5;
/// let mut y = 42;
///
/// mem::swap(&mut x, &mut y);
///
/// assert_eq!(42, x);
/// assert_eq!(5, y);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn swap<T>(x: &mut T, y: &mut T) {
    // KESELAMATAN: pitunjuk mentah digawe saka referensi sing bisa diowahi kanthi aman sing kabeh
    // watesan ing `ptr::swap_nonoverlapping_one`
    unsafe {
        ptr::swap_nonoverlapping_one(x, y);
    }
}

/// Ngganti `dest` kanthi nilai standar `T`, ngasilake angka `dest` sadurunge.
///
/// * Yen sampeyan pengin ngganti angka loro variabel, deleng [`swap`].
/// * Yen sampeyan pengin ngganti karo nilai liwati tinimbang nilai standar, deleng [`replace`].
///
/// # Examples
///
/// Tuladha sing gampang:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::take(&mut v);
/// assert_eq!(vec![1, 2], old_v);
/// assert!(v.is_empty());
/// ```
///
/// `take` ngidini njupuk kepemilikan kolom strom kanthi ngganti karo nilai "empty".
/// Tanpa `take` sampeyan bisa nemoni masalah kaya ing ngisor iki:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let buf = self.buf;
///         self.buf = Vec::new();
///         buf
///     }
/// }
/// ```
///
/// Elinga yen `T` ora kudu ngetrapake [`Clone`], mula malah ora bakal dikloning lan ngreset `self.buf`.
/// Nanging `take` bisa digunakake kanggo ngilangi nilai asli `self.buf` saka `self`, supaya bisa dibalekake:
///
///
/// ```
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         mem::take(&mut self.buf)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf.len(), 2);
///
/// assert_eq!(buffer.get_and_reset(), vec![0, 1]);
/// assert_eq!(buffer.buf.len(), 0);
/// ```
#[inline]
#[stable(feature = "mem_take", since = "1.40.0")]
pub fn take<T: Default>(dest: &mut T) -> T {
    replace(dest, T::default())
}

/// Pindhah `src` menyang `dest` sing dirujuk, ngasilake angka `dest` sadurunge.
///
/// Ora ana regane sing mudhun.
///
/// * Yen sampeyan pengin ngganti angka loro variabel, deleng [`swap`].
/// * Yen sampeyan pengin ngganti karo nilai gawan, deleng [`take`].
///
/// # Examples
///
/// Tuladha sing gampang:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::replace(&mut v, vec![3, 4, 5]);
/// assert_eq!(vec![1, 2], old_v);
/// assert_eq!(vec![3, 4, 5], v);
/// ```
///
/// `replace` ngidini konsumsi kolom struktural kanthi ngganti karo nilai liyane.
/// Tanpa `replace` sampeyan bisa nemoni masalah kaya ing ngisor iki:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let t = self.buf[i];
///         self.buf[i] = v;
///         t
///     }
/// }
/// ```
///
/// Elinga yen `T` ora kudu ngetrapake [`Clone`], mula kita malah ora bisa menehi klone `self.buf[i]` kanggo ngindhari pamindhahan kasebut.
/// Nanging `replace` bisa digunakake kanggo ngilangi nilai asli ing indeks kasebut saka `self`, saengga bisa dikembalikan:
///
///
/// ```
/// # #![allow(dead_code)]
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         mem::replace(&mut self.buf[i], v)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf[0], 0);
///
/// assert_eq!(buffer.replace_index(0, 2), 0);
/// assert_eq!(buffer.buf[0], 2);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[must_use = "if you don't need the old value, you can just assign the new value directly"]
pub fn replace<T>(dest: &mut T, src: T) -> T {
    // SAFETY: Kita maca saka `dest` nanging langsung nulis `src`,
    // kayata regane lawas ora diduplikasi.
    // Ora ana barang sing diluncurake lan ora ana ing kene sing bisa panic.
    unsafe {
        let result = ptr::read(dest);
        ptr::write(dest, src);
        result
    }
}

/// Mbuwang regane.
///
/// Iki ditindakake kanthi nyebut implementasi argumen [`Drop`][drop].
///
/// Iki kanthi efektif ora nindakake apa-apa kanggo jinis sing ngetrapake `Copy`, kayata
/// integers.
/// Nilai kasebut disalin lan _then_ dipindhah menyang fungsi, mula regane tetep sawise telpon fungsi iki.
///
///
/// Fungsi iki dudu sulap;secara harfiah ditetepake minangka
///
/// ```
/// pub fn drop<T>(_x: T) { }
/// ```
///
/// Amarga `_x` dipindhah menyang fungsi, kanthi otomatis mudhun sadurunge fungsi bali.
///
/// [drop]: Drop
///
/// # Examples
///
/// Panggunaan dhasar:
///
/// ```
/// let v = vec![1, 2, 3];
///
/// drop(v); // tegas nyelehake vector
/// ```
///
/// Amarga [`RefCell`] ngetrapake aturan utang nalika runtime, `drop` bisa ngeculake utang [`RefCell`]:
///
/// ```
/// use std::cell::RefCell;
///
/// let x = RefCell::new(1);
///
/// let mut mutable_borrow = x.borrow_mut();
/// *mutable_borrow = 1;
///
/// drop(mutable_borrow); // masrahake ing utang mutable ing slot iki
///
/// let borrow = x.borrow();
/// println!("{}", *borrow);
/// ```
///
/// Integer lan jinis liyane sing ngetrapake [`Copy`] ora kena pengaruh `drop`.
///
/// ```
/// #[derive(Copy, Clone)]
/// struct Foo(u8);
///
/// let x = 1;
/// let y = Foo(2);
/// drop(x); // salinan `x` wis dipindhah lan dropped
/// drop(y); // salinan `y` dipindhah lan diluncurake
///
/// println!("x: {}, y: {}", x, y.0); // isih kasedhiya
/// ```
///
/// [`RefCell`]: crate::cell::RefCell
///
#[doc(alias = "delete")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn drop<T>(_x: T) {}

/// Nafsirake `src` minangka jinis `&U`, lan banjur maca `src` tanpa mindhah nilai sing ana.
///
/// Fungsi iki kanthi ora aman nganggep pointer `src` bener kanggo bait [`size_of::<U>`][size_of] kanthi ngirim `&T` menyang `&U` lan banjur maca `&U` (kajaba sing ditindakake kanthi cara sing bener sanajan `&U` nggawe persyaratan alignment sing luwih ketat tinimbang `&T`).
/// Uga bakal nggawe salinan nilai sing wis ora aman tinimbang ora pindhah saka `src`.
///
/// Iki dudu kesalahan kompilasi yen `T` lan `U` duwe ukuran sing beda, nanging luwih disengkuyung supaya mung nggunakake fungsi iki ing `T` lan `U` duwe ukuran sing padha.Fungsi iki micu [undefined behavior][ub] yen `U` luwih gedhe tinimbang `T`.
///
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// #[repr(packed)]
/// struct Foo {
///     bar: u8,
/// }
///
/// let foo_array = [10u8];
///
/// unsafe {
///     // Nyalin data saka 'foo_array' lan dianggep minangka 'Foo'
///     let mut foo_struct: Foo = mem::transmute_copy(&foo_array);
///     assert_eq!(foo_struct.bar, 10);
///
///     // Ngowahi data disalin
///     foo_struct.bar = 20;
///     assert_eq!(foo_struct.bar, 20);
/// }
///
/// // Isi 'foo_array' kudune ora diganti
/// assert_eq!(foo_array, [10]);
/// ```
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_transmute_copy", issue = "83165")]
pub const unsafe fn transmute_copy<T, U>(src: &T) -> U {
    // Yen U nduweni persyaratan alignment sing luwih dhuwur, src bisa uga ora cocog.
    if align_of::<U>() > align_of::<T>() {
        // SAFETY: `src` minangka referensi sing dijamin valid kanggo maca.
        // Panelpon kudu njamin manawa transmutasi nyata aman.
        unsafe { ptr::read_unaligned(src as *const T as *const U) }
    } else {
        // SAFETY: `src` minangka referensi sing dijamin valid kanggo maca.
        // Kita mung mriksa manawa `src as *const U` didadekake siji kanthi bener.
        // Panelpon kudu njamin manawa transmutasi nyata aman.
        unsafe { ptr::read(src as *const T as *const U) }
    }
}

/// Jinis opaque sing nuduhake diskriminasi enum.
///
/// Deleng fungsi [`discriminant`] ing modul iki kanggo informasi lengkap.
#[stable(feature = "discriminant_value", since = "1.21.0")]
pub struct Discriminant<T>(<T as DiscriminantKind>::Discriminant);

// N.B. Implementasi trait iki ora bisa ditemokake amarga kita ora pengin wates ing T.

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> Copy for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> clone::Clone for Discriminant<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::PartialEq for Discriminant<T> {
    fn eq(&self, rhs: &Self) -> bool {
        self.0 == rhs.0
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::Eq for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> hash::Hash for Discriminant<T> {
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.0.hash(state);
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> fmt::Debug for Discriminant<T> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_tuple("Discriminant").field(&self.0).finish()
    }
}

/// Ngasilake nilai kanthi unik nalika ngidentifikasi varian enum ing `v`.
///
/// Yen `T` dudu enum, nelpon fungsi iki ora bakal ngasilake prilaku sing durung ditemtokake, nanging nilai bali ora ditemtokake.
///
///
/// # Stability
///
/// Diskriminasi varian enum bisa diganti yen definisi enum diganti.
/// Diskriminasi sawetara varian ora bakal beda-beda ing antarane kompilasi karo kompilator sing padha.
///
/// # Examples
///
/// Iki bisa digunakake kanggo mbandhingake enum sing nggawa data, uga ora nggatekake data asline:
///
/// ```
/// use std::mem;
///
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::discriminant(&Foo::A("bar")), mem::discriminant(&Foo::A("baz")));
/// assert_eq!(mem::discriminant(&Foo::B(1)), mem::discriminant(&Foo::B(2)));
/// assert_ne!(mem::discriminant(&Foo::B(3)), mem::discriminant(&Foo::C(3)));
/// ```
///
#[stable(feature = "discriminant_value", since = "1.21.0")]
#[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
pub const fn discriminant<T>(v: &T) -> Discriminant<T> {
    Discriminant(intrinsics::discriminant_value(v))
}

/// Ngasilake nomer macem-macem jinis enum `T`.
///
/// Yen `T` dudu enum, nelpon fungsi iki ora bakal ngasilake prilaku sing durung ditemtokake, nanging nilai bali ora ditemtokake.
/// Kajaba, yen `T` minangka enum kanthi varian luwih akeh tinimbang `usize::MAX`, angka bali ora ditemtokake.
/// Varian sing ora dipanggoni bakal dietung.
///
/// # Examples
///
/// ```
/// # #![feature(never_type)]
/// # #![feature(variant_count)]
///
/// use std::mem;
///
/// enum Void {}
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::variant_count::<Void>(), 0);
/// assert_eq!(mem::variant_count::<Foo>(), 3);
///
/// assert_eq!(mem::variant_count::<Option<!>>(), 2);
/// assert_eq!(mem::variant_count::<Result<!, !>>(), 2);
/// ```
#[inline(always)]
#[unstable(feature = "variant_count", issue = "73662")]
#[rustc_const_unstable(feature = "variant_count", issue = "73662")]
pub const fn variant_count<T>() -> usize {
    intrinsics::variant_count::<T>()
}