use crate::any::type_name;
use crate::fmt;
use crate::intrinsics;
use crate::mem::ManuallyDrop;
use crate::ptr;

/// A jinis pambungkus kanggo mbangun kedadean uninitialized saka `T`.
///
/// # initialization podho
///
/// compiler, ing umum, nompo sing rupo sing wis mlaku initialized miturut syarat jinis variabel kang.Contone, variabel jinis referensi kudu didadekake siji lan ora nol.
/// Iki minangka invarian sing kudu *mesthi* dijaga, sanajan ana ing kode sing ora aman.
/// Akibate, nol-inisialisasi variabel jinis referensi nyebabake [undefined behavior][ub] cepet, ora preduli manawa referensi kasebut digunakake kanggo ngakses memori:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: &i32 = unsafe { mem::zeroed() }; // prilaku cetho!️
/// // Padha karo kode karo `MaybeUninit<&i32>`:
/// let x: &i32 = unsafe { MaybeUninit::zeroed().assume_init() }; // prilaku cetho!️
/// ```
///
/// Iki eksploitasi dening compiler kanggo macem-macem optimizations, kayata eliding kir roto-wektu lan optimalisasi tata `enum`.
///
/// Kajaba iku, memori tanggung uninitialized kudu konten, nalika `bool` kudu tansah dadi `true` utawa `false`.Mula, nggawe `bool` sing ora diresmine minangka tumindak sing durung ditemtokake:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let b: bool = unsafe { mem::uninitialized() }; // prilaku cetho!️
/// // Kode sing padha karo `MaybeUninit<bool>`:
/// let b: bool = unsafe { MaybeUninit::uninit().assume_init() }; // prilaku cetho!️
/// ```
///
/// Menapa malih, memori uninitialized khusus ing sing ora duwe nilai tetep ("fixed" meaning "it won't change without being written to").Reading padha uninitialized bait kaping pirang-pirang bisa menehi asil beda.
/// Iki nggawe prilaku sing ora ditemtokake duwe data sing durung dinialisasi ing variabel sanajan variabel kasebut duwe jinis bilangan bulat, sing bisa uga nduwe pola bit *tetep*:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: i32 = unsafe { mem::uninitialized() }; // prilaku cetho!️
/// // Padha karo kode karo `MaybeUninit<i32>`:
/// let x: i32 = unsafe { MaybeUninit::uninit().assume_init() }; // prilaku cetho!️
/// ```
/// (Elinga yen aturan babagan wilangan bulat sing durung diresmine durung rampung, nanging nganti luwih becik, luwih becik disingkiri.)
///
/// Kajaba iku, elinga yen umume jinis duwe invarian tambahan kajaba mung dianggep diwiwiti ing level jinis.
/// Contone, a: 1`-initialized [`Vec<T>`] dianggep initialized (ing implementasine saiki, iki ora akehe njamin stabil) amarga mung requirement compiler mangerténi babagan iku ing pitunjuk data kudu non-null.
/// Nggawe `Vec<T>` kaya ngono ora nyebabake tumindak *sing ora langsung*, nanging bakal nyebabake tumindak sing durung mesthi karo operasi sing paling aman (kalebu ngeculake).
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
///
/// # Examples
///
/// `MaybeUninit<T>` kanggo ngaktifake kode sing ora aman kanggo ngatasi data sing durung dinisialisasi.
/// Iki minangka sinyal kanggo kompiler sing nuduhake manawa data ing kene *ora* bakal diinisialisasi:
///
/// ```rust
/// use std::mem::MaybeUninit;
///
/// // Nggawe referensi tegas uninitialized.
/// // compiler mangerténi sing data nang `MaybeUninit<T>` bisa dadi bener, lan Empu iki ora UB:
/// let mut x = MaybeUninit::<&i32>::uninit();
/// // Nyetel menyang Nilai bener.
/// unsafe { x.as_mut_ptr().write(&0); }
/// // Ekstrak data inisialisasi-iki mung diidini *sawise* kanthi inisialisasi `x`!
/////
/// let x = unsafe { x.assume_init() };
/// ```
///
/// compiler banjur mirsa kanggo ora nggawe pemanggih salah utawa optimizations ing kode iki.
///
/// Sampeyan bisa nganggep `MaybeUninit<T>` kaya `Option<T>` nanging ora ana pelacakan wektu mlaku lan tanpa mriksa keamanan.
///
/// ## out-pointers
///
/// Sampeyan bisa nggunakake `MaybeUninit<T>` kanggo ngetrapake "out-pointers": tinimbang ngasilake data saka fungsi, kirimake pitunjuk menyang sawetara memori (uninitialized) kanggo nyelehake asil.
/// Iki bisa migunani yen penting kanggo panelpon ngontrol kepiye memori sing disimpen ing memori bakal dialokasikan, lan sampeyan pengin ngindhari pamindhahan sing ora perlu.
///
/// ```
/// use std::mem::MaybeUninit;
///
/// unsafe fn make_vec(out: *mut Vec<i32>) {
///     // `write` ora nyelehake isi lawas, kang penting.
///     out.write(vec![1, 2, 3]);
/// }
///
/// let mut v = MaybeUninit::uninit();
/// unsafe { make_vec(v.as_mut_ptr()); }
/// // Saiki kita ngerti `v` wis initialized!Iki uga ndadekake manawa vector bakal mlaku dropped.
/////
/// let v = unsafe { v.assume_init() };
/// assert_eq!(&v, &[1, 2, 3]);
/// ```
///
/// ## Nggawe unsur elemen miturut unsur
///
/// `MaybeUninit<T>` bisa digunakake kanggo miwiti unsur-unsur kanthi unsur gedhe:
///
/// ```
/// use std::mem::{self, MaybeUninit};
///
/// let data = {
///     // Nggawe Uploaded uninitialized saka `MaybeUninit`.
///     // The `assume_init` aman amarga jinis kita ngakoni wis initialized punika Bunch saka: MaybeUninit`s, kang ora mbutuhake initialization.
/////
///     let mut data: [MaybeUninit<Vec<u32>>; 1000] = unsafe {
///         MaybeUninit::uninit().assume_init()
///     };
///
///     // Gulung `MaybeUninit` ora nindakake apa-apa.
///     // Mangkono nggunakake assignment pointer mentah tinimbang `ptr::write` ora nyebabake nilai lawas sing ora diresmine bakal mudhun.
/////
///     // Uga yen ana panic sajrone loop iki, kita bakal duwe bocor memori, nanging ora ana masalah keamanan memori.
/////
///     for elem in &mut data[..] {
///         *elem = MaybeUninit::new(vec![42]);
///     }
///
///     // Kabeh wis initialized.
///     // Transmute Uploaded kanggo jinis initialized.
///     unsafe { mem::transmute::<_, [Vec<u32>; 1000]>(data) }
/// };
///
/// assert_eq!(&data[0], &[42]);
/// ```
///
/// Sampeyan uga bisa karo susunan sebagian initialized, kang bisa ditemokake ing datastructures-tingkat kurang.
///
/// ```
/// use std::mem::MaybeUninit;
/// use std::ptr;
///
/// // Nggawe Uploaded uninitialized saka `MaybeUninit`.
/// // The `assume_init` aman amarga jinis kita ngakoni wis initialized punika Bunch saka: MaybeUninit`s, kang ora mbutuhake initialization.
/////
/// let mut data: [MaybeUninit<String>; 1000] = unsafe { MaybeUninit::uninit().assume_init() };
/// // Cacahake nomer elemen sing wis ditemtokake.
/// let mut data_len: usize = 0;
///
/// for elem in &mut data[0..500] {
///     *elem = MaybeUninit::new(String::from("hello"));
///     data_len += 1;
/// }
///
/// // Kanggo saben item ing larik, gulung yen diwenehake.
/// for elem in &mut data[0..data_len] {
///     unsafe { ptr::drop_in_place(elem.as_mut_ptr()); }
/// }
/// ```
///
/// ## Dhisik a struct lapangan-by-lapangan
///
/// Sampeyan bisa nggunakake `MaybeUninit<T>`, lan makro [`std::ptr::addr_of_mut`], kanggo nggawe inisialisasi kolom kanthi kolom:
///
/// ```rust
/// use std::mem::MaybeUninit;
/// use std::ptr::addr_of_mut;
///
/// #[derive(Debug, PartialEq)]
/// pub struct Foo {
///     name: String,
///     list: Vec<u8>,
/// }
///
/// let foo = {
///     let mut uninit: MaybeUninit<Foo> = MaybeUninit::uninit();
///     let ptr = uninit.as_mut_ptr();
///
///     // Dhisik lapangan `name`
///     unsafe { addr_of_mut!((*ptr).name).write("Bob".to_string()); }
///
///     // Dhisik lapangan `list` Yen ana panic kene, banjur `String` ing bocor lapangan `name`.
/////
///     unsafe { addr_of_mut!((*ptr).list).write(vec![0, 1, 2]); }
///
///     // Kabeh kolom diwiwiti, mula kita nelpon `assume_init` kanggo entuk Foo sing wis diinisialisasi.
///     unsafe { uninit.assume_init() }
/// };
///
/// assert_eq!(
///     foo,
///     Foo {
///         name: "Bob".to_string(),
///         list: vec![0, 1, 2]
///     }
/// );
/// ```
/// [`std::ptr::addr_of_mut`]: crate::ptr::addr_of_mut
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Layout
///
/// `MaybeUninit<T>` dijamin duwe ukuran, alignment, lan ABI sing padha karo `T`:
///
/// ```rust
/// use std::mem::{MaybeUninit, size_of, align_of};
/// assert_eq!(size_of::<MaybeUninit<u64>>(), size_of::<u64>());
/// assert_eq!(align_of::<MaybeUninit<u64>>(), align_of::<u64>());
/// ```
///
/// Nanging elinga jinis *ngemot* a `MaybeUninit<T>` ora kudu rancangan padha;Rust ora ing njamin umum sing kothak saka `Foo<T>` duwe supaya padha minangka `Foo<U>` sanajan `T` lan `U` duwe ukuran lan Alignment padha.
///
/// Salajengipun amarga Nilai dicokot iku bener kanggo `MaybeUninit<T>` compiler sing ora bisa aplikasi non-zero/niche-filling optimizations, potensi asil sing luwih gedhe:
///
/// ```rust
/// # use std::mem::{MaybeUninit, size_of};
/// assert_eq!(size_of::<Option<bool>>(), 1);
/// assert_eq!(size_of::<Option<MaybeUninit<bool>>>(), 2);
/// ```
///
/// Yen `T` aman FFI, mula `MaybeUninit<T>` uga aman.
///
/// Nalika `MaybeUninit` punika `#[repr(transparent)]` (nuduhake njamin ukuran padha, alignment, lan ABI minangka `T`), iki ora *ora* ngganti samubarang caveats sadurungé.
/// `Option<T>` lan `Option<MaybeUninit<T>>` uga isih duwe macem-macem ukuran, lan jinis-jinis sing ngemot lapangan jinis `T` bisa glethakaken metu (lan ukuran) beda saka yen lapangan sing padha `MaybeUninit<T>`.
/// `MaybeUninit` jinis Uni, lan `#[repr(transparent)]` ing kumpulan punika boten stabil (ndeleng [the tracking issue](https://github.com/rust-lang/rust/issues/60405)).
/// Suwe-suwe, garansi tenan `#[repr(transparent)]` ing serikat kerja bisa uga mekar, lan `MaybeUninit` bisa uga tetep `#[repr(transparent)]` utawa ora.
/// Sing ngandika, `MaybeUninit<T>` bakal *tansah* njamin sing nduweni ukuran padha, alignment, lan ABI minangka `T`;iku mung sing cara `MaybeUninit` nindakake sing njamin bisa mekar.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "maybe_uninit", since = "1.36.0")]
// Lang item supaya kita bisa Lebokake jinis ing.Iki migunani kanggo generator.
#[lang = "maybe_uninit"]
#[derive(Copy)]
#[repr(transparent)]
pub union MaybeUninit<T> {
    uninit: (),
    value: ManuallyDrop<T>,
}

#[stable(feature = "maybe_uninit", since = "1.36.0")]
impl<T: Copy> Clone for MaybeUninit<T> {
    #[inline(always)]
    fn clone(&self) -> Self {
        // Ora nelpon `T::clone()`, kita ora bisa ngerti yen cukup diwiwiti kanggo prekara kasebut.
        *self
    }
}

#[stable(feature = "maybe_uninit_debug", since = "1.41.0")]
impl<T> fmt::Debug for MaybeUninit<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad(type_name::<Self>())
    }
}

impl<T> MaybeUninit<T> {
    /// Nggawe `MaybeUninit<T>` anyar initialized karo nilai kang.
    /// Aman kanggo nelpon [`assume_init`] ing nilai bali saka fungsi iki.
    ///
    /// Wigati sing nempel `MaybeUninit<T>` ora bakal nelpon: kode gulung T` kang.
    /// Punika sampeyan tanggung jawab kanggo nggawe manawa `T` bakal dropped yen tak initialized.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<Vec<u8>> = MaybeUninit::new(vec![42]);
    /// ```
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(val: T) -> MaybeUninit<T> {
        MaybeUninit { value: ManuallyDrop::new(val) }
    }

    /// Nggawe `MaybeUninit<T>` anyar ing negara sing durung ditemtokake.
    ///
    /// Wigati sing nempel `MaybeUninit<T>` ora bakal nelpon: kode gulung T` kang.
    /// Punika sampeyan tanggung jawab kanggo nggawe manawa `T` bakal dropped yen tak initialized.
    ///
    /// Deleng [type-level documentation][MaybeUninit] kanggo sawetara conto.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<String> = MaybeUninit::uninit();
    /// ```
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    #[rustc_diagnostic_item = "maybe_uninit_uninit"]
    pub const fn uninit() -> MaybeUninit<T> {
        MaybeUninit { uninit: () }
    }

    /// Nggawe Uploaded anyar `MaybeUninit<T>` item, ing negara uninitialized.
    ///
    /// Note: ing versi future Rust cara iki bisa dadi rasah nalika ukara Uploaded harfiah ngidini [repeating const expressions](https://github.com/rust-lang/rust/issues/49147).
    ///
    /// Contone ing ngisor iki bisa nggunakake `let mut buf = [MaybeUninit::<u8>::uninit(); 32];`.
    ///
    /// # Examples
    ///
    /// ```no_run
    /// #![feature(maybe_uninit_uninit_array, maybe_uninit_extra, maybe_uninit_slice)]
    ///
    /// use std::mem::MaybeUninit;
    ///
    /// extern "C" {
    ///     fn read_into_buffer(ptr: *mut u8, max_len: usize) -> usize;
    /// }
    ///
    /// /// Ngasilake irisan data (bisa uga luwih cilik) sing wis diwaca sejatine
    /// fn read(buf: &mut [MaybeUninit<u8>]) -> &[u8] {
    ///     unsafe {
    ///         let len = read_into_buffer(buf.as_mut_ptr() as *mut u8, buf.len());
    ///         MaybeUninit::slice_assume_init_ref(&buf[..len])
    ///     }
    /// }
    ///
    /// let mut buf: [MaybeUninit<u8>; 32] = MaybeUninit::uninit_array();
    /// let data = read(&mut buf);
    /// ```
    ///
    #[unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[rustc_const_unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[inline(always)]
    pub const fn uninit_array<const LEN: usize>() -> [Self; LEN] {
        // SAFETY: Lan uninitialized `[MaybeUninit<_>; LEN]` bener.
        unsafe { MaybeUninit::<[MaybeUninit<T>; LEN]>::uninit().assume_init() }
    }

    /// Nggawe `MaybeUninit<T>` anyar ing negara sing ora diresmine, kanthi memori diisi karo bait `0`.Gumantung ing `T` apa sing wis nggawe inisialisasi sing tepat.
    ///
    /// Contone, `MaybeUninit<usize>::zeroed()` wis initialized, nanging `MaybeUninit<&'static i32>::zeroed()` ora amarga referensi ora kudu null.
    ///
    /// Wigati sing nempel `MaybeUninit<T>` ora bakal nelpon: kode gulung T` kang.
    /// Punika sampeyan tanggung jawab kanggo nggawe manawa `T` bakal dropped yen tak initialized.
    ///
    /// # Example
    ///
    /// Panggunaan fungsi iki kanthi bener: miwiti struktur kanthi nol, ing endi kabeh kolom strukture bisa nahan pola bit 0 minangka nilai sing valid.
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<(u8, bool)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// assert_eq!(x, (0, false));
    /// ```
    ///
    /// *Salah Panggunan* fungsi iki: nelpon `x.zeroed().assume_init()` nalika `0` ora dicokot-pola bener kanggo jinis:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// enum NotZero { One = 1, Two = 2 }
    ///
    /// let x = MaybeUninit::<(u8, NotZero)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// // Nang pasangan, kita nggawe `NotZero` sing ora duwe Diskriminan bener.
    /// // Iki prilaku cetho.️
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[inline]
    #[rustc_diagnostic_item = "maybe_uninit_zeroed"]
    pub fn zeroed() -> MaybeUninit<T> {
        let mut u = MaybeUninit::<T>::uninit();
        // SAFETY: `u.as_mut_ptr()` nuduhake memori sing dialokasikan.
        unsafe {
            u.as_mut_ptr().write_bytes(0u8, 1);
        }
        u
    }

    /// Nyetel regane `MaybeUninit<T>`.
    /// Iki bakal nimpa nilai sadurunge tanpa ngeculake, mula ati-ati supaya ora nggunakake kaping pindho kajaba sampeyan pengin mlumpat supaya bisa ngrusak.
    ///
    /// Kanggo penak, iki uga ngasilake referensi sing bisa diowahi kanggo konten `self` (saiki wis diinisialisasi kanthi aman).
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const fn write(&mut self, val: T) -> &mut T {
        *self = MaybeUninit::new(val);
        // SAFETY: We mung initialized Nilai iki.
        unsafe { self.assume_init_mut() }
    }

    /// Nemu pitunjuk kanggo nilai sing.
    /// Maca saka pitunjuk iki utawa dadi referensi ora mesthi tumindak kajaba `MaybeUninit<T>` diwiwiti.
    /// Nulis menyang memori sing diwenehi pointer (non-transitively) iki minangka tumindak sing durung ditemtokake (kajaba ing `UnsafeCell<T>`).
    ///
    /// # Examples
    ///
    /// Panggunaan cara sing bener iki:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // Gawe referensi menyang `MaybeUninit<T>`.Iki ora apa-apa amarga kita wis nggawe inisialisasi.
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// assert_eq!(x_vec.len(), 3);
    /// ```
    ///
    /// *Salah Panggunan* cara iki:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// // Kita wis nggawe referensi menyang vector sing ora dinamis!Iki prilaku cetho.⚠️
    /// ```
    ///
    /// (Kabar sing aturan watara referensi kanggo data uninitialized ora dirampungaké durung, nanging nganti padha, iku luwih apik kanggo supaya wong-wong mau.)
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_ptr(&self) -> *const T {
        // `MaybeUninit` lan `ManuallyDrop` kalorone `repr(transparent)` saengga kita bisa menehi petunjuk.
        self as *const _ as *const T
    }

    /// Nemu pitunjuk mutable menyang Nilai sing.
    /// Maca saka pitunjuk iki utawa dadi referensi ora mesthi tumindak kajaba `MaybeUninit<T>` diwiwiti.
    ///
    /// # Examples
    ///
    /// Panggunaan cara sing bener iki:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // Gawe referensi menyang `MaybeUninit<Vec<u32>>`.
    /// // Iki oke amarga kita initialized iku.
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// x_vec.push(3);
    /// assert_eq!(x_vec.len(), 4);
    /// ```
    ///
    /// *Salah Panggunan* cara iki:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// // Kita wis nggawe referensi menyang vector sing ora dinamis!Iki prilaku cetho.⚠️
    /// ```
    ///
    /// (Kabar sing aturan watara referensi kanggo data uninitialized ora dirampungaké durung, nanging nganti padha, iku luwih apik kanggo supaya wong-wong mau.)
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        // `MaybeUninit` lan `ManuallyDrop` kalorone `repr(transparent)` saengga kita bisa menehi petunjuk.
        self as *mut _ as *mut T
    }

    /// Mbeber Nilai saka wadhah `MaybeUninit<T>`.Iki cara gedhe kanggo mesthekake yen data bakal dropped, amarga `T` asil tundhuk biasanipun gulung jawab.
    ///
    /// # Safety
    ///
    /// Mungkasi panelpon kanggo njamin yen `MaybeUninit<T>` pancen wis ana ing negara sing diwiwiti.Nelpon iki nalika konten durung diwiwiti kanthi otomatis nyebabake prilaku sing durung ditemtokake langsung.
    /// The [type-level documentation][inv] ngandhut informasi luwih lengkap babagan initialization podho iki.
    ///
    /// [inv]: #initialization-invariant
    ///
    /// Kajaba iku, elinga yen umume jinis duwe invarian tambahan kajaba mung dianggep diwiwiti ing level jinis.
    /// Contone, a: 1`-initialized [`Vec<T>`] dianggep initialized (ing implementasine saiki, iki ora akehe njamin stabil) amarga mung requirement compiler mangerténi babagan iku ing pitunjuk data kudu non-null.
    ///
    /// Nggawe `Vec<T>` kaya ngono ora nyebabake tumindak *sing ora langsung*, nanging bakal nyebabake tumindak sing durung mesthi karo operasi sing paling aman (kalebu ngeculake).
    ///
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    /// # Examples
    ///
    /// Panggunaan cara sing bener iki:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<bool>::uninit();
    /// unsafe { x.as_mut_ptr().write(true); }
    /// let x_init = unsafe { x.assume_init() };
    /// assert_eq!(x_init, true);
    /// ```
    ///
    /// *Salah Panggunan* cara iki:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_init = unsafe { x.assume_init() };
    /// // `x` durung diwiwiti, mula garis pungkasan iki nyebabake tumindak sing durung mesthi.⚠️
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    #[rustc_diagnostic_item = "assume_init"]
    pub const unsafe fn assume_init(self) -> T {
        // SAFETY: njamin panelpon kudu sing `self` wis initialized.
        // Iki uga ateges `self` kudu varian `value`.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            ManuallyDrop::into_inner(self.value)
        }
    }

    /// Maos nilai saka wadhah `MaybeUninit<T>`.`T` sing diasilake tundhuk penanganan gulung biasa.
    ///
    /// Yen bisa, luwih becik nggunakake [`assume_init`], sing ngalangi duplikat konten `MaybeUninit<T>`.
    ///
    /// # Safety
    ///
    /// Mungkasi panelpon kanggo njamin yen `MaybeUninit<T>` pancen wis ana ing negara sing diwiwiti.Nelpon iki nalika isi wis durung initialized nimbulaké prilaku cetho.
    /// The [type-level documentation][inv] ngandhut informasi luwih lengkap babagan initialization podho iki.
    ///
    /// Menapa malih, iki nilar salinan data sing padha ing `MaybeUninit<T>`.
    /// Nalika nggunakake macem-macem salinan data (kanthi nelpon `assume_init_read` kaping pirang-pirang, utawa pisanan nelpon `assume_init_read` banjur [`assume_init`]), dadi tanggung jawab sampeyan kanggo mesthekake yen data kasebut bisa uga diduplikasi.
    ///
    ///
    /// [inv]: #initialization-invariant
    /// [`assume_init`]: MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// Panggunaan cara sing bener iki:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<u32>::uninit();
    /// x.write(13);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // `u32` iku `Copy`, supaya kita bisa maca kaping pirang-pirang.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(None);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // Duplikat Nilai `None` oke, supaya kita bisa maca kaping pirang-pirang.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    /// ```
    ///
    /// *Salah Panggunan* cara iki:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(Some(vec![0, 1, 2]));
    /// let x1 = unsafe { x.assume_init_read() };
    /// let x2 = unsafe { x.assume_init_read() };
    /// // Saiki kita nggawe loro salinan vector sing padha, lan nuwuhake double️ gratis nalika kalorone tiba!
    /////
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const unsafe fn assume_init_read(&self) -> T {
        // SAFETY: njamin panelpon kudu sing `self` wis initialized.
        // Maca saka `self.as_ptr()` iku aman `self` kudu initialized.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            self.as_ptr().read()
        }
    }

    /// Nyelehake nilai sing ana ing papane.
    ///
    /// Yen sampeyan duwe kepemilikan saka `MaybeUninit`, sampeyan bisa nggunakake [`assume_init`] tinimbang.
    ///
    /// # Safety
    ///
    /// Mungkasi panelpon kanggo njamin yen `MaybeUninit<T>` pancen wis ana ing negara sing diwiwiti.Nelpon iki nalika isi wis durung initialized nimbulaké prilaku cetho.
    ///
    /// Ing ndhuwur sing, kabeh invariants tambahan jinis `T` kudu wareg, minangka implementasine `Drop` saka `T` (utawa anggota sawijining) uga gumantung ing iki.
    /// Contone, a: 1`-initialized [`Vec<T>`] dianggep initialized (ing implementasine saiki, iki ora akehe njamin stabil) amarga mung requirement compiler mangerténi babagan iku ing pitunjuk data kudu non-null.
    ///
    /// Ngeculake `Vec<T>` kaya ngono, bakal nyebabake tumindak sing durung mesthi.
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    pub unsafe fn assume_init_drop(&mut self) {
        // SAFETY: njamin panelpon kudu sing `self` wis initialized lan
        // marem kabeh invariants `T`.
        // Nyelehake regane wis aman yen kedadeyan kasebut.
        unsafe { ptr::drop_in_place(self.as_mut_ptr()) }
    }

    /// Entuk referensi bareng karo nilai sing ana.
    ///
    /// Iki bisa migunani nalika kita arep kanggo ngakses `MaybeUninit` sing wis initialized nanging ora duwe kepemilikan saka `MaybeUninit` (nyegah nggunakake `.assume_init()`).
    ///
    /// # Safety
    ///
    /// Nelpon iki nalika isi wis durung initialized nimbulaké prilaku cetho: iku munggah menyang panelpon kanggo njamin menawa `MaybeUninit<T>` tenan ing negara initialized.
    ///
    ///
    /// # Examples
    ///
    /// ### Panggunaan cara sing bener iki:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// // Initialisasi `x`:
    /// unsafe { x.as_mut_ptr().write(vec![1, 2, 3]); }
    /// // Saiki sing `MaybeUninit<_>` kita wis dikenal kanggo initialized, iku oke nggawe referensi sambungan iku:
    /////
    /// let x: &Vec<u32> = unsafe {
    ///     // SAFETY: `x` wis diwiwiti.
    ///     x.assume_init_ref()
    /// };
    /// assert_eq!(x, &vec![1, 2, 3]);
    /// ```
    ///
    /// ### * * Salah usages saka cara iki:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec: &Vec<u32> = unsafe { x.assume_init_ref() };
    /// // Kita wis nggawe referensi menyang vector sing ora dinamis!Iki prilaku cetho.⚠️
    /// ```
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{cell::Cell, mem::MaybeUninit};
    ///
    /// let b = MaybeUninit::<Cell<bool>>::uninit();
    /// // Initialize ing `MaybeUninit` nggunakake `Cell::set`:
    /// unsafe {
    ///     b.assume_init_ref().set(true);
    ///    // ^^^^^^^^^^^^^^^
    ///    // Referensi kanggo `Cell<bool>` uninitialized: UB!
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_ref(&self) -> &T {
        // SAFETY: njamin panelpon kudu sing `self` wis initialized.
        // Iki uga ateges `self` kudu varian `value`.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &*self.as_ptr()
        }
    }

    /// Entuk referensi (unique) sing bisa diowahi kanggo nilai sing ana.
    ///
    /// Iki bisa migunani nalika kita arep kanggo ngakses `MaybeUninit` sing wis initialized nanging ora duwe kepemilikan saka `MaybeUninit` (nyegah nggunakake `.assume_init()`).
    ///
    /// # Safety
    ///
    /// Nelpon iki nalika isi wis durung initialized nimbulaké prilaku cetho: iku munggah menyang panelpon kanggo njamin menawa `MaybeUninit<T>` tenan ing negara initialized.
    /// Kayata, `.assume_init_mut()` ora bisa digunakake kanggo initialize a `MaybeUninit`.
    ///
    /// # Examples
    ///
    /// ### Panggunaan cara sing bener iki:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// # unsafe extern "C" fn initialize_buffer(buf: *mut [u8; 2048]) { *buf = [0; 2048] }
    /// # #[cfg(FALSE)]
    /// extern "C" {
    ///     /// Initializes *kabeh* ing bita saka buffer input.
    ///     fn initialize_buffer(buf: *mut [u8; 2048]);
    /// }
    ///
    /// let mut buf = MaybeUninit::<[u8; 2048]>::uninit();
    ///
    /// // Initialize `buf`:
    /// unsafe { initialize_buffer(buf.as_mut_ptr()); }
    /// // Saiki kita ngerti sing `buf` wis initialized, supaya kita bisa `.assume_init()` iku.
    /// // Nanging, nggunakake `.assume_init()` bisa uga nyebabake `memcpy` saka 2048 bait.
    /// // Kanggo njaluk buffer kita wis initialized tanpa Nyalin iku, kita nganyarke `&mut MaybeUninit<[u8; 2048]>` menyang `&mut [u8; 2048]`:
    /////
    /// let buf: &mut [u8; 2048] = unsafe {
    ///     // SAFETY: `buf` wis initialized.
    ///     buf.assume_init_mut()
    /// };
    ///
    /// // Saiki kita bisa nggunakake `buf` minangka irisan normal:
    /// buf.sort_unstable();
    /// assert!(
    ///     buf.windows(2).all(|pair| pair[0] <= pair[1]),
    ///     "buffer is sorted",
    /// );
    /// ```
    ///
    /// ### * * Salah usages saka cara iki:
    ///
    /// Sampeyan ora bisa nggunakake `.assume_init_mut()` kanggo initialize Nilai:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut b = MaybeUninit::<bool>::uninit();
    /// unsafe {
    ///     *b.assume_init_mut() = true;
    ///     // Kita wis digawe referensi (mutable) menyang `bool` uninitialized!
    ///     // Iki prilaku cetho.️
    /// }
    /// ```
    ///
    /// Kayata, sampeyan bisa ora [`Read`] menyang buffer uninitialized:
    ///
    /// [`Read`]: https://doc.rust-lang.org/std/io/trait.Read.html
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{io, mem::MaybeUninit};
    ///
    /// fn read_chunk (reader: &'_ mut dyn io::Read) -> io::Result<[u8; 64]>
    /// {
    ///     let mut buffer = MaybeUninit::<[u8; 64]>::uninit();
    ///     reader.read_exact(unsafe { buffer.assume_init_mut() })?;
    ///                             // ^^^^^^^^^^^^^^^^^^^^^^^^
    ///                             // (mutable) referensi kanggo memori sing ora diresmine!
    ///                             // Iki prilaku cetho.
    ///     Ok(unsafe { buffer.assume_init() })
    /// }
    /// ```
    ///
    /// Sampeyan uga ora bisa nggunakake akses lapangan langsung kanggo nggawe inisialisasi kanthi alon-alon ing lapangan:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{mem::MaybeUninit, ptr};
    ///
    /// struct Foo {
    ///     a: u32,
    ///     b: u8,
    /// }
    ///
    /// let foo: Foo = unsafe {
    ///     let mut foo = MaybeUninit::<Foo>::uninit();
    ///     ptr::write(&mut foo.assume_init_mut().a as *mut u32, 1337);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) referensi kanggo memori sing ora diresmine!
    ///                  // Iki prilaku cetho.
    ///     ptr::write(&mut foo.assume_init_mut().b as *mut u8, 42);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) referensi kanggo memori sing ora diresmine!
    ///                  // Iki prilaku cetho.
    ///     foo.assume_init()
    /// };
    /// ```
    ///
    ///
    ///
    ///
    // FIXME(#76092): Saiki kita gumantung ing ndhuwur sing salah, yaiku, kita duwe referensi kanggo data sing ora dinisialisasi (kayata, ing `libcore/fmt/float.rs`).
    // We kudu nggawe kaputusan pungkasan bab aturan sadurunge stabil.
    //
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_mut(&mut self) -> &mut T {
        // SAFETY: njamin panelpon kudu sing `self` wis initialized.
        // Iki uga ateges `self` kudu varian `value`.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &mut *self.as_mut_ptr()
        }
    }

    /// Ekstrak nilai saka macem-macem kontainer `MaybeUninit`.
    ///
    /// # Safety
    ///
    /// Iku nganti panelpon kanggo njamin sing kabeh unsur Uploaded ana ing negara initialized.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_uninit_array)]
    /// #![feature(maybe_uninit_array_assume_init)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut array: [MaybeUninit<i32>; 3] = MaybeUninit::uninit_array();
    /// array[0] = MaybeUninit::new(0);
    /// array[1] = MaybeUninit::new(1);
    /// array[2] = MaybeUninit::new(2);
    ///
    /// // SAFETY: Saiki aman kita initialised kabeh unsur
    /// let array = unsafe {
    ///     MaybeUninit::array_assume_init(array)
    /// };
    ///
    /// assert_eq!(array, [0, 1, 2]);
    /// ```
    #[unstable(feature = "maybe_uninit_array_assume_init", issue = "80908")]
    #[inline(always)]
    pub unsafe fn array_assume_init<const N: usize>(array: [Self; N]) -> [T; N] {
        // SAFETY:
        // * Jaminan panelpon sing kabeh unsur Uploaded sing initialized
        // * `MaybeUninit<T>` lan T dijamin duwe tata letak sing padha
        // * MaybeUnint ora nyelehake, supaya ora ana pindho Frees Lan kanthi mangkono konversi aman
        //
        unsafe {
            intrinsics::assert_inhabited::<[T; N]>();
            (&array as *const _ as *const [T; N]).read()
        }
    }

    /// Assuming kabeh unsur sing initialized, njaluk irisan kanggo wong-wong mau.
    ///
    /// # Safety
    ///
    /// Kasedhiya panelpon kanggo njamin manawa elemen `MaybeUninit<T>` pancen wis ana ing negara sing diwiwiti.
    ///
    /// Nelpon iki nalika isi wis durung initialized nimbulaké prilaku cetho.
    ///
    /// Waca [`assume_init_ref`] kanggo rincian liyane lan conto.
    ///
    /// [`assume_init_ref`]: MaybeUninit::assume_init_ref
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_ref(slice: &[Self]) -> &[T] {
        // SAFETY: casting irisan menyang `*const [T]` aman wiwit njamin panelpon sing
        // `slice` iku initialized, and`MaybeUninit` dijamin duwe tata padha `T`.
        // Pointer sing dipikolehi bener amarga nuduhake memori sing diduweni dening `slice` sing dadi referensi mula dijamin valid kanggo diwaca.
        //
        unsafe { &*(slice as *const [Self] as *const [T]) }
    }

    /// Yen kabeh elemen diinisialisasi, entuk irisan sing bisa diowahi.
    ///
    /// # Safety
    ///
    /// Kasedhiya panelpon kanggo njamin manawa elemen `MaybeUninit<T>` pancen wis ana ing negara sing diwiwiti.
    ///
    /// Nelpon iki nalika isi wis durung initialized nimbulaké prilaku cetho.
    ///
    /// Deleng [`assume_init_mut`] kanggo rincian lan conto liyane.
    ///
    /// [`assume_init_mut`]: MaybeUninit::assume_init_mut
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_mut(slice: &mut [Self]) -> &mut [T] {
        // SAFETY: padha karo cathetan safety kanggo `slice_get_ref`, nanging kita duwe
        // referensi mutable kang uga dijamin dadi bener kanggo nyerat.
        unsafe { &mut *(slice as *mut [Self] as *mut [T]) }
    }

    /// Entuk penunjuk menyang elemen pisanan saka susunan.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_ptr(this: &[MaybeUninit<T>]) -> *const T {
        this.as_ptr() as *const T
    }

    /// Nemu pitunjuk mutable kanggo unsur pisanan Uploaded ing.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_mut_ptr(this: &mut [MaybeUninit<T>]) -> *mut T {
        this.as_mut_ptr() as *mut T
    }

    /// Salinan unsur saka `src` kanggo `this`, bali referensi mutable kanggo isi saiki initalized saka `this`.
    ///
    /// Yen `T` ora ngleksanakake `Copy`, nggunakake [`write_slice_cloned`]
    ///
    /// Iki padha [`slice::copy_from_slice`].
    ///
    /// # Panics
    ///
    /// Fungsi iki bakal panic yen irisan loro kasebut dawane beda.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(); 32];
    /// let src = [0; 32];
    ///
    /// let init = MaybeUninit::write_slice(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = [0; 16];
    ///
    /// MaybeUninit::write_slice(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // SAFETY: kita wis njiplak kabeh unsur Kagamine Rin Kagamine Len menyang kapasitas spare
    /// // elemen src.len() pertama saka vektor saiki wis valid.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice_cloned`]: MaybeUninit::write_slice_cloned
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Copy,
    {
        // KESELAMATAN: &[T] lan&[MungkinUninit<T>] duwe tata letak sing padha
        let uninit_src: &[MaybeUninit<T>] = unsafe { super::transmute(src) };

        this.copy_from_slice(uninit_src);

        // SAFETY: unsur Valid wis mung wis disalin menyang `this` supaya initalized
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }

    /// Turunan unsur saka `src` kanggo `this`, bali referensi mutable kanggo isi saiki initalized saka `this`.
    /// Sembarang unsur wis initalized ora bakal dropped.
    ///
    /// Yen `T` ngleksanakake `Copy`, gunakake [`write_slice`]
    ///
    /// Iki padha [`slice::clone_from_slice`] nanging ora nyelehake unsur ana.
    ///
    /// # Panics
    ///
    /// Fungsi iki bakal panic yen loro irisan-irisan duwe beda tebih, utawa yen lampahipun `Clone` panics.
    ///
    /// Yen ana panic, elemen sing wis kloning bakal mudhun.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit()];
    /// let src = ["wibbly".to_string(), "wobbly".to_string(), "timey".to_string(), "wimey".to_string(), "stuff".to_string()];
    ///
    /// let init = MaybeUninit::write_slice_cloned(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = ["rust", "is", "a", "pretty", "cool", "language"];
    ///
    /// MaybeUninit::write_slice_cloned(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // SAFETY: kita mung kloning kabeh unsur Kagamine Rin Kagamine Len menyang kapasitas spare
    /// // elemen src.len() pertama saka vektor saiki wis valid.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice`]: MaybeUninit::write_slice
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice_cloned<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Clone,
    {
        // kados copy_from_slice iki ora nelpon clone_from_slice ing irisan iki amarga `MaybeUninit<T: Clone>` ora ngleksanakake Klone.
        //

        struct Guard<'a, T> {
            slice: &'a mut [MaybeUninit<T>],
            initialized: usize,
        }

        impl<'a, T> Drop for Guard<'a, T> {
            fn drop(&mut self) {
                let initialized_part = &mut self.slice[..self.initialized];
                // SAFETY: irisan mentah iki mung bakal ngemot obyek inisialisasi
                // mula, pareng nyelehake.
                unsafe {
                    crate::ptr::drop_in_place(MaybeUninit::slice_assume_init_mut(initialized_part));
                }
            }
        }

        assert_eq!(this.len(), src.len(), "destination and source slices have different lengths");
        // NOTE: Kita kudu nyoto kanthi eksplisit kanthi dawa sing padha
        // kanggo mriksa wates sing bakal dipilih, lan pangoptimal bakal ngasilake memcpy kanggo kasus sing gampang (contone T= u8).
        //
        let len = this.len();
        let src = &src[..len];

        // njaga perlu b/c panic bisa kelakon sak Klone
        let mut guard = Guard { slice: this, initialized: 0 };

        for i in 0..len {
            guard.slice[i].write(src[i].clone());
            guard.initialized += 1;
        }

        super::forget(guard);

        // SAFETY: Unsur sing valid mung ditulis dadi `this` mula diinitalisasi
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }
}