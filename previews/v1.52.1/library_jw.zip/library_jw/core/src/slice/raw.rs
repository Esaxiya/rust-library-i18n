//! Fungsi gratis kanggo nggawe `&[T]` lan `&mut [T]`.

use crate::array;
use crate::intrinsics::is_aligned_and_not_null;
use crate::mem;
use crate::ptr;

/// Mbentuk irisan saka pitunjuk lan dawa.
///
/// Argumentasi `len` minangka nomer **elemen**, dudu jumlah bait.
///
/// # Safety
///
/// Prilaku wis cetho yen kahanan ing ngisor iki sing nerak:
///
/// * `data` kudu [valid] kanggo diwaca kanggo `len * mem::size_of::<T>()` akeh bait, lan kudu didadekake siji kanthi bener.Iki tegese khusus:
///
///     * Kabeh rentang memori irisan iki kudu dikatutake ing obyek sing diparengake!
///       Irisan ora bisa ditemokake ing pirang-pirang obyek sing dialokasikan.Waca [below](#incorrect-usage) kanggo conto salah ora njupuk iki menyang akun.
///     * `data` kudu non-batal lan selaras sanajan irisan dawa-nol.
///     Salah sawijining sebab yaiku optimisasi tata letak enum bisa uga gumantung karo referensi (kalebu irisan apa wae) sing selaras lan ora batal kanggo mbedakake saka data liyane.
///     Sampeyan bisa entuk pitunjuk sing bisa digunakake minangka `data` kanggo irisan dawa-nol nggunakake [`NonNull::dangling()`].
///
/// * `data` kudu nggawa kanggo `len` consecutive angka initialized mlaku saka jinis `T`.
///
/// * Memori acuan déning irisan bali kudu ora bakal mutated kanggo duration umur `'a`, kajaba nang `UnsafeCell`.
///
/// * Ukuran total `len * mem::size_of::<T>()` irisan kudu ora luwih gedhe tinimbang `isize::MAX`.
///   Deleng dokumentasi keamanan [`pointer::offset`].
///
/// # Caveat
///
/// Umur kanggo irisan sing bali dikatutake saka panggunaan.
/// Kanggo nyegah penyalahgunaan sing ora disengaja, disaranake supaya umur sampeyan tundhuk karo sumber umur apa wae sing aman ing konteks kasebut, kayata nyedhiyakake fungsi helper kanggo entuk nilai host sajrone irisan, utawa kanthi anotasi eksplisit.
///
///
/// # Examples
///
/// ```
/// use std::slice;
///
/// // mujudake irisan kanggo siji unsur
/// let x = 42;
/// let ptr = &x as *const _;
/// let slice = unsafe { slice::from_raw_parts(ptr, 1) };
/// assert_eq!(slice[0], 42);
/// ```
///
/// ### Panggunan salah
///
/// Fungsi `join_slices` ing ngisor iki yaiku **unsound** ⚠️
///
/// ```rust,no_run
/// use std::slice;
///
/// fn join_slices<'a, T>(fst: &'a [T], snd: &'a [T]) -> &'a [T] {
///     let fst_end = fst.as_ptr().wrapping_add(fst.len());
///     let snd_start = snd.as_ptr();
///     assert_eq!(fst_end, snd_start, "Slices must be contiguous!");
///     unsafe {
///         // Pratelan ing ndhuwur njamin `fst` lan `snd` bisa dipasang, nanging bisa uga ana ing _different allocated objects_, sing nggawe irisan iki minangka tumindak sing durung ditemtokake.
/////
/////
///         slice::from_raw_parts(fst.as_ptr(), fst.len() + snd.len())
///     }
/// }
///
/// fn main() {
///     // `a` lan `b` minangka obyek sing dialokasikan beda ...
///     let a = 42;
///     let b = 27;
///     // ... sing bisa uga dilebokake ing memori: |a |b |
///     let _ = join_slices(slice::from_ref(&a), slice::from_ref(&b)); // UB
/// }
/// ```
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts<'a, T>(data: *const T, len: usize) -> &'a [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // SAFETY: panelpon kudu njaga kontrak keamanan kanggo `from_raw_parts`.
    unsafe { &*ptr::slice_from_raw_parts(data, len) }
}

/// Performs fungsi sing padha minangka [`from_raw_parts`], kejaba irisan mutable wis bali.
///
/// # Safety
///
/// Prilaku wis cetho yen kahanan ing ngisor iki sing nerak:
///
/// * `data` kudu [valid] kanggo maos lan nulis kanggo `len * mem::size_of::<T>()` akeh bait, lan kudu didadekake siji kanthi bener.Iki tegese khusus:
///
///     * Kabeh rentang memori irisan iki kudu dikatutake ing obyek sing diparengake!
///       Irisan ora bisa ditemokake ing pirang-pirang obyek sing dialokasikan.
///     * `data` kudu non-batal lan selaras sanajan irisan dawa-nol.
///     Salah sawijining sebab yaiku optimisasi tata letak enum bisa uga gumantung karo referensi (kalebu irisan apa wae) sing selaras lan ora batal kanggo mbedakake saka data liyane.
///
///     Sampeyan bisa entuk pitunjuk sing bisa digunakake minangka `data` kanggo irisan dawa-nol nggunakake [`NonNull::dangling()`].
///
/// * `data` kudu nggawa kanggo `len` consecutive angka initialized mlaku saka jinis `T`.
///
/// * Memori acuan déning irisan bali kudu ora diakses liwat sembarang pitunjuk liyane (ora asalé saka nilai bali) kanggo duration umur `'a`.
///   Akses maca lan nulis ora dilarang.
///
/// * Ukuran total `len * mem::size_of::<T>()` irisan kudu ora luwih gedhe tinimbang `isize::MAX`.
///   Deleng dokumentasi keamanan [`pointer::offset`].
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts_mut<'a, T>(data: *mut T, len: usize) -> &'a mut [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // SAFETY: panelpon kudu njaga kontrak keamanan kanggo `from_raw_parts_mut`.
    unsafe { &mut *ptr::slice_from_raw_parts_mut(data, len) }
}

/// Ngonversi referensi menyang T dadi irisan dawa 1 (tanpa disalin).
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_ref<T>(s: &T) -> &[T] {
    array::from_ref(s)
}

/// Ngonversi referensi menyang T dadi irisan dawa 1 (tanpa disalin).
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_mut<T>(s: &mut T) -> &mut [T] {
    array::from_mut(s)
}