//! Makro digunakake irisan irisan.

// Inlining is_empty len makes prabédan ageng kinerja
macro_rules! is_empty {
    // Cara kita encode dawa ing iterator ZST, iki dianggo loro kanggo ZST lan non-ZST.
    //
    ($self: ident) => {
        $self.ptr.as_ptr() as *const T == $self.end
    };
}

// Kanggo nyisihaken saka sawetara wates kir (ndeleng `position`), kita ngétung dawa ing cara kakinten.
// (Diuji dening `codegen/slice-position-bounds-check`.)
macro_rules! len {
    ($self: ident) => {{
        #![allow(unused_unsafe)] // kadang digunakake ing blok sing ora aman

        let start = $self.ptr;
        let size = size_from_ptr(start.as_ptr());
        if size == 0 {
            // _cannot_ iki nggunakake `unchecked_sub` amarga kita gumantung bungkusan kanggo makili dawa ZST dawa iterators irisan.
            //
            ($self.end as usize).wrapping_sub(start.as_ptr() as usize)
        } else {
            // Kita ngerti manawa `start <= end`, dadi bisa luwih apik tinimbang `offset_from`, sing kudu ditangani.
            // Kanthi nyetel panji sing cocog ing kene, kita bisa menehi katrangan babagan LLVM, sing mbantu mbusak cek wates.
            // SAFETY: Miturut jinis invarian, `start <= end`
            //
            let diff = unsafe { unchecked_sub($self.end as usize, start.as_ptr() as usize) };
            // Miturut uga mulangi LLVM sing penunjuk sing loro dening macem-macem pas ukuran jinis, iku bisa ngoptimalake `len() == 0` mudhun kanggo `start == end` tinimbang `(end - start) < size`.
            //
            // SAFETY: Kanthi jinis invariant, pointer didadekake siji supaya
            //         jarak antarane kudu ukuran tikel kaping pirang-pirang
            //
            unsafe { exact_div(diff, size) }
        }
    }};
}

// Definisi bareng saka iterator `Iter` lan `IterMut`
macro_rules! iterator {
    (
        struct $name:ident -> $ptr:ty,
        $elem:ty,
        $raw_mut:tt,
        {$( $mut_:tt )?},
        {$($extra:tt)*}
    ) => {
        // Ngasilake elemen pisanan lan mindhah wiwitan iterator kanthi 1.
        // Ngapikake kinerja yen dibandhingake karo fungsi inline.
        // Iterator ngirim ora kosong.
        macro_rules! next_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.post_inc_start(1)}
        }

        // Ngasilake elemen pungkasan lan mindhah mburi iterator mundur dadi 1.
        // Ngapikake kinerja yen dibandhingake karo fungsi inline.
        // Iterator ngirim ora kosong.
        macro_rules! next_back_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.pre_dec_end(1)}
        }

        // Nyilikake iterator nalika T minangka ZST, kanthi mindhah mburi iterator mundur kanthi `n`.
        // `n` ora kudu ngluwihi `self.len()`.
        macro_rules! zst_shrink {
            ($self: ident, $n: ident) => {
                $self.end = ($self.end as * $raw_mut u8).wrapping_offset(-$n) as * $raw_mut T;
            }
        }

        impl<'a, T> $name<'a, T> {
            // Fungsi helper kanggo nggawe irisan saka iterator.
            #[inline(always)]
            fn make_slice(&self) -> &'a [T] {
                // SAFETY: iterator digawe saka irisan kanthi pitunjuk
                // `self.ptr` lan dawa `len!(self)`.
                // Iki njamin manawa kabeh prasyarat kanggo `from_raw_parts` wis kawujud.
                unsafe { from_raw_parts(self.ptr.as_ptr(), len!(self)) }
            }

            // fungsi Helper kanggo obah ing wiwitan iterator ing forwards dening unsur `offset`, bali wiwitan lawas.
            //
            // Ora aman amarga offset ora kudu ngluwihi `self.len()`.
            #[inline(always)]
            unsafe fn post_inc_start(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    let old = self.ptr.as_ptr();
                    // SAFETY: panelpon njamin `offset` ora ngluwihi `self.len()`,
                    // supaya pitunjuk anyar iki nang `self` lan kanthi mangkono dijamin dadi non-null.
                    self.ptr = unsafe { NonNull::new_unchecked(self.ptr.as_ptr().offset(offset)) };
                    old
                }
            }

            // Fungsi helper kanggo mindhah mburi iterator mundur kanthi elemen `offset`, ngasilake pungkasan anyar.
            //
            // Ora aman amarga offset ora kudu ngluwihi `self.len()`.
            #[inline(always)]
            unsafe fn pre_dec_end(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    // SAFETY: panelpon njamin `offset` ora ngluwihi `self.len()`,
                    // sing dijamin ora kebanjiran `isize`.
                    // Uga, pitunjuk sing diasilake ing wates `slice`, sing memenuhi syarat liyane kanggo `offset`.
                    self.end = unsafe { self.end.offset(-offset) };
                    self.end
                }
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T> ExactSizeIterator for $name<'_, T> {
            #[inline(always)]
            fn len(&self) -> usize {
                len!(self)
            }

            #[inline(always)]
            fn is_empty(&self) -> bool {
                is_empty!(self)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> Iterator for $name<'a, T> {
            type Item = $elem;

            #[inline]
            fn next(&mut self) -> Option<$elem> {
                // bisa dileksanakake kanthi irisan, nanging iki supaya ora ana watesan

                // SAFETY: telpon `assume` sing aman irisan kang wiwitan pitunjuk
                // kudu non-batal, lan irisan kanggo non-ZST uga kudu duwe pointer pungkasan non-nol.
                // Telpon kanggo `next_unchecked!` aman awit kita mriksa yen iterator kosong pisanan.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                let exact = len!(self);
                (exact, Some(exact))
            }

            #[inline]
            fn count(self) -> usize {
                len!(self)
            }

            #[inline]
            fn nth(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // Pengulangan iki saiki kosong.
                    if mem::size_of::<T>() == 0 {
                        // Kita kudu nindakake kanthi cara iki amarga `ptr` bisa uga 0, nanging `end` bisa uga (amarga bungkus).
                        //
                        self.end = self.ptr.as_ptr();
                    } else {
                        // SAFETY: pungkasan ora bisa 0 yen T dudu ZST amarga ptr ora 0 lan pungkasan>=ptr
                        unsafe {
                            self.ptr = NonNull::new_unchecked(self.end as *mut T);
                        }
                    }
                    return None;
                }
                // SAFETY: We are ing wates.`post_inc_start` nindakake sing bener sanajan kanggo ZST.
                unsafe {
                    self.post_inc_start(n as isize);
                    Some(next_unchecked!(self))
                }
            }

            #[inline]
            fn last(mut self) -> Option<$elem> {
                self.next_back()
            }

            // Kita ngilangi implementasine gawan, sing nggunakake `try_fold`, amarga implementasi sederhana iki ngasilake kurang LLVM IR lan luwih cepet dikompilasi.
            //
            //
            #[inline]
            fn for_each<F>(mut self, mut f: F)
            where
                Self: Sized,
                F: FnMut(Self::Item),
            {
                while let Some(x) = self.next() {
                    f(x);
                }
            }

            // Kita ngilangi implementasine gawan, sing nggunakake `try_fold`, amarga implementasi sederhana iki ngasilake kurang LLVM IR lan luwih cepet dikompilasi.
            //
            //
            #[inline]
            fn all<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if !f(x) {
                        return false;
                    }
                }
                true
            }

            // Kita ngilangi implementasine gawan, sing nggunakake `try_fold`, amarga implementasi sederhana iki ngasilake kurang LLVM IR lan luwih cepet dikompilasi.
            //
            //
            #[inline]
            fn any<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if f(x) {
                        return true;
                    }
                }
                false
            }

            // Kita ngilangi implementasine gawan, sing nggunakake `try_fold`, amarga implementasi sederhana iki ngasilake kurang LLVM IR lan luwih cepet dikompilasi.
            //
            //
            #[inline]
            fn find<P>(&mut self, mut predicate: P) -> Option<Self::Item>
            where
                Self: Sized,
                P: FnMut(&Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if predicate(&x) {
                        return Some(x);
                    }
                }
                None
            }

            // Kita ngilangi implementasine gawan, sing nggunakake `try_fold`, amarga implementasi sederhana iki ngasilake kurang LLVM IR lan luwih cepet dikompilasi.
            //
            //
            #[inline]
            fn find_map<B, F>(&mut self, mut f: F) -> Option<B>
            where
                Self: Sized,
                F: FnMut(Self::Item) -> Option<B>,
            {
                while let Some(x) = self.next() {
                    if let Some(y) = f(x) {
                        return Some(y);
                    }
                }
                None
            }

            // Kita ngilangi implementasine gawan, sing nggunakake `try_fold`, amarga implementasi sederhana iki ngasilake kurang LLVM IR lan luwih cepet dikompilasi.
            // Uga, `assume` ngindhari mriksa wates.
            //
            #[inline]
            #[rustc_inherit_overflow_checks]
            fn position<P>(&mut self, mut predicate: P) -> Option<usize> where
                Self: Sized,
                P: FnMut(Self::Item) -> bool,
            {
                let n = len!(self);
                let mut i = 0;
                while let Some(x) = self.next() {
                    if predicate(x) {
                        // SAFETY: kita dijamin bakal diwatesi dening invariant loop:
                        // nalika `i >= n`, `self.next()` ngasilake `None` lan loop rusak.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                    i += 1;
                }
                None
            }

            // Kita ngilangi implementasine gawan, sing nggunakake `try_fold`, amarga implementasi sederhana iki ngasilake kurang LLVM IR lan luwih cepet dikompilasi.
            // Uga, `assume` ngindhari mriksa wates.
            //
            #[inline]
            fn rposition<P>(&mut self, mut predicate: P) -> Option<usize> where
                P: FnMut(Self::Item) -> bool,
                Self: Sized + ExactSizeIterator + DoubleEndedIterator
            {
                let n = len!(self);
                let mut i = n;
                while let Some(x) = self.next_back() {
                    i -= 1;
                    if predicate(x) {
                        // SAFETY: `i` kudu luwih murah tinimbang `n` wiwit diwiwiti ing `n`
                        // lan mung nyuda.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                }
                None
            }

            #[doc(hidden)]
            unsafe fn __iterator_get_unchecked(&mut self, idx: usize) -> Self::Item {
                // SAFETY: panelpon kudu njamin yen `i` ana wates
                // irisan sing ndasari, dadi `i` ora bisa kebanjiran `isize`, lan referensi sing bali dijamin bakal nuduhake elemen irisan banjur dijamin bisa valid.
                //
                // Uga elinga yen panelpon uga njamin manawa kita ora bakal ditelpon maneh kanthi indeks sing padha, lan ora ana cara liya sing bakal ngakses lengganan iki diarani, mula valid kanggo referensi bali supaya bisa diganti ing kasus
                //
                // `IterMut`
                //
                //
                //
                //
                unsafe { & $( $mut_ )? * self.ptr.as_ptr().add(idx) }
            }

            $($extra)*
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> DoubleEndedIterator for $name<'a, T> {
            #[inline]
            fn next_back(&mut self) -> Option<$elem> {
                // bisa dileksanakake kanthi irisan, nanging iki supaya ora ana watesan

                // SAFETY: `assume` telpon aman amarga tandha wiwitan irisan kudu ora batal,
                // lan irisan liwat non-ZST uga kudu duwe pointer pungkasan non-nol.
                // Telpon menyang `next_back_unchecked!` aman amarga kita mriksa yen iterator kosong luwih dhisik.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_back_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn nth_back(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // Pengulangan iki saiki kosong.
                    self.end = self.ptr.as_ptr();
                    return None;
                }
                // SAFETY: Kita pancen wates.`pre_dec_end` nindakake sing bener sanajan kanggo ZST.
                unsafe {
                    self.pre_dec_end(n as isize);
                    Some(next_back_unchecked!(self))
                }
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<T> FusedIterator for $name<'_, T> {}

        #[unstable(feature = "trusted_len", issue = "37572")]
        unsafe impl<T> TrustedLen for $name<'_, T> {}
    }
}

macro_rules! forward_iterator {
    ($name:ident: $elem:ident, $iter_of:ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, $elem, P> Iterator for $name<'a, $elem, P>
        where
            P: FnMut(&T) -> bool,
        {
            type Item = $iter_of;

            #[inline]
            fn next(&mut self) -> Option<$iter_of> {
                self.inner.next()
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                self.inner.size_hint()
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<'a, $elem, P> FusedIterator for $name<'a, $elem, P> where P: FnMut(&T) -> bool {}
    };
}