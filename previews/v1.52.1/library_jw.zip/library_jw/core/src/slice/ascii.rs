//! Operasi ing ASCII `[u8]`.

use crate::mem;

#[lang = "slice_u8"]
#[cfg(not(test))]
impl [u8] {
    /// Priksa manawa kabeh bait ing irisan iki ana ing kisaran ASCII.
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        is_ascii(self)
    }

    /// Priksa manawa rong irisan minangka match case-sensitif ASCII.
    ///
    /// Padha karo `to_ascii_lowercase(a) == to_ascii_lowercase(b)`, nanging tanpa alokasi lan nyalin sementara.
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &[u8]) -> bool {
        self.len() == other.len() && self.iter().zip(other).all(|(a, b)| a.eq_ignore_ascii_case(b))
    }

    /// Ngonversi irisan iki menyang ASCII sing kasus ing ndhuwur sing padha.
    ///
    /// Huruf ASCII 'a' dadi 'z' dipetakan menyang 'A' dadi 'Z', nanging huruf non-ASCII ora owah.
    ///
    /// Kanggo ngasilake angka ndhuwur sing anyar tanpa ngowahi sing ana, gunakake [`to_ascii_uppercase`].
    ///
    ///
    /// [`to_ascii_uppercase`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        for byte in self {
            byte.make_ascii_uppercase();
        }
    }

    /// Ngonversi irisan iki menyang ASCII cilik sing padha karo ing panggonan.
    ///
    /// Huruf ASCII 'A' dadi 'Z' dipetakan menyang 'a' dadi 'z', nanging huruf non-ASCII ora owah.
    ///
    /// Kanggo ngasilake angka murah anyar tanpa ngowahi sing ana, gunakake [`to_ascii_lowercase`].
    ///
    ///
    /// [`to_ascii_lowercase`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        for byte in self {
            byte.make_ascii_lowercase();
        }
    }
}

/// Ngasilake `true` yen ana bait ing tembung `v` nonascii (>=128).
/// Snarfed saka `../str/mod.rs`, sing padha karo validasi utf8.
#[inline]
fn contains_nonascii(v: usize) -> bool {
    const NONASCII_MASK: usize = 0x80808080_80808080u64 as usize;
    (NONASCII_MASK & v) != 0
}

/// Tes ASCII sing dioptimalake sing bakal nggunakake operasi usize-at-a-time tinimbang operasi byte-at-a-time (yen bisa).
///
/// Algoritma sing digunakake ing kene cukup gampang.Yen `s` cendhak banget, kita mung mriksa saben bait lan ngrampungake.Yen ora:
///
/// - Waca tembung kapisan kanthi mbukak sing ora larut.
/// - Selaras pitunjuk, waca tembung sabanjure nganti pungkasan kanthi larut karo beban.
/// - Waca `usize` pungkasan saka `s` kanthi mbukak sing ora larut.
///
/// Yen ana beban sing ngasilake `contains_nonascii` (above), mula wangsulane salah.
///
///
///
#[inline]
fn is_ascii(s: &[u8]) -> bool {
    const USIZE_SIZE: usize = mem::size_of::<usize>();

    let len = s.len();
    let align_offset = s.as_ptr().align_offset(USIZE_SIZE);

    // Yen ora entuk apa-apa saka implementasine tembung-wektu, bali menyang lingkaran skalar.
    //
    // Kita uga nindakake iki kanggo arsitektur ing endi `size_of::<usize>()` ora cukup cocog karo `usize`, amarga kasus iki edge sing aneh.
    //
    //
    if len < USIZE_SIZE || len < align_offset || USIZE_SIZE < mem::align_of::<usize>() {
        return s.iter().all(|b| b.is_ascii());
    }

    // Kita mesthi maca tembung pisanan sing ora diselarasake, tegese `align_offset` yaiku
    // 0, kita bakal maca maneh angka sing padha kanggo maca sing didadekake siji.
    let offset_to_aligned = if align_offset == 0 { USIZE_SIZE } else { align_offset };

    let start = s.as_ptr();
    // SAFETY: Kita verifikasi `len < USIZE_SIZE` ing ndhuwur.
    let first_word = unsafe { (start as *const usize).read_unaligned() };

    if contains_nonascii(first_word) {
        return false;
    }
    // Iki dicenthang ing ndhuwur, kanthi implisit.
    // Elinga yen `offset_to_aligned` iku salah siji `align_offset` utawa `USIZE_SIZE`, loro sing tegas dicenthang ndhuwur.
    //
    debug_assert!(offset_to_aligned <= len);

    // SAFETY: word_ptr minangka ptr nggunakake (digunakake kanthi bener) kanggo maca
    // potongan tengah irisan.
    let mut word_ptr = unsafe { start.add(offset_to_aligned) as *const usize };

    // `byte_pos` minangka indeks byte `word_ptr`, digunakake kanggo mriksa loop loop.
    let mut byte_pos = offset_to_aligned;

    // Paranoia mriksa babagan keselarasan, amarga kita bakal nindakake akeh beban sing ora cocog.
    // Praktek iki mesthine ora bisa ngalangi kesalahan ing `align_offset`.
    //
    debug_assert_eq!((word_ptr as usize) % mem::align_of::<usize>(), 0);

    // Waca tembung sabanjure nganti tembung pungkasan sing didadekake siji, ora kalebu tembung didadekake pungkasan sing bakal ditindakake kanthi mriksa buntut mengko, kanggo mesthekake yen buntut mesthi paling `usize` nganti branch `byte_pos == len`.
    //
    //
    while byte_pos < len - USIZE_SIZE {
        debug_assert!(
            // Sanity mriksa manawa diwaca ana ing wates
            (word_ptr as usize + USIZE_SIZE) <= (start.wrapping_add(len) as usize) &&
            // Lan asumsi kita babagan `byte_pos` ditahan.
            (word_ptr as usize) - (start as usize) == byte_pos
        );

        // SAFETY: Kita ngerti `word_ptr` selaras kanthi bener (amarga
        // `align_offset`), lan kita ngerti manawa kita duwe cukup bait antara `word_ptr` lan pungkasan
        let word = unsafe { word_ptr.read() };
        if contains_nonascii(word) {
            return false;
        }

        byte_pos += USIZE_SIZE;
        // SAFETY: Kita ngerti yen `byte_pos <= len - USIZE_SIZE`, tegese
        // sawise `add` iki, `word_ptr` bakal paling pungkasan.
        word_ptr = unsafe { word_ptr.add(1) };
    }

    // Priksa sanity kanggo mesthekake yen isih ana siji `usize`.
    // Iki kudu dijamin dening kahanan loop kita.
    debug_assert!(byte_pos <= len && len - byte_pos <= USIZE_SIZE);

    // SAFETY: Iki gumantung ing `len >= USIZE_SIZE`, kang kita mriksa ing wiwitan.
    let last_word = unsafe { (start.add(len - USIZE_SIZE) as *const usize).read_unaligned() };

    !contains_nonascii(last_word)
}