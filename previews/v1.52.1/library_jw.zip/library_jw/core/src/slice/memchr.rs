// Implementasi asli dijupuk saka rust-memchr.
// Hak cipta 2015 Andrew Gallant, bluss lan Nicolas Koch

use crate::cmp;
use crate::mem;

const LO_U64: u64 = 0x0101010101010101;
const HI_U64: u64 = 0x8080808080808080;

// Gunakake truncation.
const LO_USIZE: usize = LO_U64 as usize;
const HI_USIZE: usize = HI_U64 as usize;
const USIZE_BYTES: usize = mem::size_of::<usize>();

/// Ngasilake `true` yen `x` ngemot byte nol.
///
/// Saka *Matters Komputasi*, J. Arndt:
///
/// "Ing idea kanggo ngurangi sak saka saben bita banjur katon kanggo bita ngendi utang ing propagated kabeh cara kanggo paling pinunjul
///
/// bit."
#[inline]
fn contains_zero_byte(x: usize) -> bool {
    x.wrapping_sub(LO_USIZE) & !x & HI_USIZE != 0
}

#[cfg(target_pointer_width = "16")]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) << 8 | b as usize
}

#[cfg(not(target_pointer_width = "16"))]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) * (usize::MAX / 255)
}

/// Ngasilake indeks pisanan sing cocog karo byte `x` ing `text`.
#[inline]
pub fn memchr(x: u8, text: &[u8]) -> Option<usize> {
    // Jalur cepet kanggo irisan cilik
    if text.len() < 2 * USIZE_BYTES {
        return text.iter().position(|elt| *elt == x);
    }

    memchr_general_case(x, text)
}

fn memchr_general_case(x: u8, text: &[u8]) -> Option<usize> {
    // Pindai nilai byte siji kanthi maca rong tembung `usize` sekaligus.
    //
    // Split `text` dadi telung bagean
    // - bagean wiwitan sing ora sejajar, sadurunge alamat sing didadekake siji ing teks
    // - awak, pindai kanthi 2 tembung sekaligus
    // - pérangan pungkasan, <2 ukuran tembung

    // goleki wates sing selaras
    let len = text.len();
    let ptr = text.as_ptr();
    let mut offset = ptr.align_offset(USIZE_BYTES);

    if offset > 0 {
        offset = cmp::min(offset, len);
        if let Some(index) = text[..offset].iter().position(|elt| *elt == x) {
            return Some(index);
        }
    }

    // goleki awak teks
    let repeated_x = repeat_byte(x);
    while offset <= len - 2 * USIZE_BYTES {
        // SAFETY: predikat nalika njamin jarak paling ora 2 * usize_bytes
        // ing antarane nutup kerugian lan pungkasan irisan.
        unsafe {
            let u = *(ptr.add(offset) as *const usize);
            let v = *(ptr.add(offset + USIZE_BYTES) as *const usize);

            // break yen ana bait sing cocog
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset += USIZE_BYTES * 2;
    }

    // Temokake byte sawise titik loop awak mandheg.
    text[offset..].iter().position(|elt| *elt == x).map(|i| offset + i)
}

/// Ngasilake indeks pungkasan sing cocog karo byte `x` ing `text`.
pub fn memrchr(x: u8, text: &[u8]) -> Option<usize> {
    // Pindai nilai byte siji kanthi maca rong tembung `usize` sekaligus.
    //
    // Split `text` dadi telung bagean:
    // - buntut sing ora sejajar, sawise tembung pungkasan didadekake siji ing teks,
    // - awak, dipindai kanthi 2 tembung sekaligus,
    // - bait kaping pisanan, <2 ukuran tembung.
    let len = text.len();
    let ptr = text.as_ptr();
    type Chunk = usize;

    let (min_aligned_offset, max_aligned_offset) = {
        // Iki diarani mung kanggo entuk dawa awalan lan akhiran.
        // Ing tengah kita tansah proses loro tulisan bebarengan.
        // SAFETY: ngirim `[u8]` menyang `[usize]` aman kajaba bedane ukuran sing ditangani `align_to`.
        //
        let (prefix, _, suffix) = unsafe { text.align_to::<(Chunk, Chunk)>() };
        (prefix.len(), len - suffix.len())
    };

    let mut offset = max_aligned_offset;
    if let Some(index) = text[offset..].iter().rposition(|elt| *elt == x) {
        return Some(offset + index);
    }

    // Telusuri isi teks, priksa manawa kita ora nyebrang min_aligned_offset.
    // nutup kerugian tansah didadekake siji, supaya mung Testing `>` punika cekap lan ngindari bisa kebanjiran.
    //
    let repeated_x = repeat_byte(x);
    let chunk_bytes = mem::size_of::<Chunk>();

    while offset > min_aligned_offset {
        // SAFETY: offset diwiwiti ing len, suffix.len(), anggere luwih gedhe tinimbang
        // min_aligned_offset (prefix.len()) jarak sing isih paling ora 2 * chunk_bytes.
        unsafe {
            let u = *(ptr.offset(offset as isize - 2 * chunk_bytes as isize) as *const Chunk);
            let v = *(ptr.offset(offset as isize - chunk_bytes as isize) as *const Chunk);

            // Break yen ana bait sing cocog.
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset -= 2 * chunk_bytes;
    }

    // Temokake byte sadurunge titik loop awak mandheg.
    text[..offset].iter().rposition(|elt| *elt == x)
}