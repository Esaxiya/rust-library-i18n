//! Ngurutake irisan
//!
//! Modul iki ngemot algoritma ngurutake adhedhasar quicksort sing bisa ngalahake pola Orson Peters, diterbitake ing: <https://github.com/orlp/pdqsort>
//!
//!
//! ngurutake boten stabil kompatibel karo libcore amarga ora nyedhiakke memori, kados ngurutake implementasine stabil kita.
//!

// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// Yen mudhun, salinan saka `src` dadi `dest`.
struct CopyOnDrop<T> {
    src: *mut T,
    dest: *mut T,
}

impl<T> Drop for CopyOnDrop<T> {
    fn drop(&mut self) {
        // KESELAMATAN: Iki minangka kelas pembantu.
        //          Mangga deleng panggunaan sing bener.
        //          Yaiku, siji kudu manawa `src` lan `dst` ora tumpang tindih dibutuhna `ptr::copy_nonoverlapping`.
        unsafe {
            ptr::copy_nonoverlapping(self.src, self.dest, 1);
        }
    }
}

/// Shifts unsur pisanan nengen sampe manggihaken luwih utawa unsur kang padha.
fn shift_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // SAFETY: Operasi aman ngisor melu indeksasi tanpa mriksa bound (`get_unchecked` lan `get_unchecked_mut`)
    // lan nyalin memori (`ptr::copy_nonoverlapping`).
    //
    // a.Pengindeksan:
    //  1. Kita mriksa ukuran larik dadi>=2.
    //  2. Kabeh indeks sing bakal kita lakoni mesthi paling antara {0 <= index < len}.
    //
    // b.Nyalin memori
    //  1. Kita entuk referensi kanggo referensi sing dijamin bener.
    //  2. Padha ora bisa tumpang tindih amarga kita diwenehi penunjuk kanggo indeks prabédan saka irisan.
    //     Yaiku, `i` lan `i-1`.
    //  3. Yen irisan didadekake siji kanthi bener, unsur-unsur kasebut sejajar kanthi bener.
    //     Iku tanggung jawab panelpon kanggo nggawe manawa irisan mlaku didadekake siji.
    //
    // Deleng komentar ing ngisor iki kanggo rincian luwih lengkap.
    unsafe {
        // Yen rong elemen pisanan ora ana ...
        if len >= 2 && is_less(v.get_unchecked(1), v.get_unchecked(0)) {
            // Maca unsur pisanan menyang global tumpukan-diparengake.
            // Yen operasi perbandingan ing ngisor iki panics, `hole` bakal mudhun lan nulis elemen kanthi otomatis menyang irisan.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(0)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(1) };
            ptr::copy_nonoverlapping(v.get_unchecked(1), v.get_unchecked_mut(0), 1);

            for i in 2..len {
                if !is_less(v.get_unchecked(i), &*tmp) {
                    break;
                }

                // Pindhahake elemen siji ing sisih kiwa, lan banjur ngalihake bolongan nengen.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i - 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` bakal tiba lan banjur nyalin `tmp` menyang bolongan sing isih ana ing `v`.
        }
    }
}

/// Papindhahan unsur pungkasan ing sisih kiwa nganti manggihaken unsur cilik utawa witjaksono.
fn shift_tail<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // SAFETY: Operasi aman ngisor melu indeksasi tanpa mriksa bound (`get_unchecked` lan `get_unchecked_mut`)
    // lan nyalin memori (`ptr::copy_nonoverlapping`).
    //
    // a.Pengindeksan:
    //  1. Kita mriksa ukuran larik dadi>=2.
    //  2. Kabeh indeks sing bakal kita lakoni mesthi paling antara `0 <= index < len-1`.
    //
    // b.Nyalin memori
    //  1. Kita entuk referensi kanggo referensi sing dijamin bener.
    //  2. Padha ora bisa tumpang tindih amarga kita diwenehi penunjuk kanggo indeks prabédan saka irisan.
    //     Yaiku, `i` lan `i+1`.
    //  3. Yen irisan didadekake siji kanthi bener, unsur-unsur kasebut sejajar kanthi bener.
    //     Iku tanggung jawab panelpon kanggo nggawe manawa irisan mlaku didadekake siji.
    //
    // Deleng komentar ing ngisor iki kanggo rincian luwih lengkap.
    unsafe {
        // Yen rong elemen pungkasan ora ana ...
        if len >= 2 && is_less(v.get_unchecked(len - 1), v.get_unchecked(len - 2)) {
            // Waca elemen pungkasan dadi variabel sing dialokasikan tumpukan.
            // Yen operasi perbandingan ing ngisor iki panics, `hole` bakal mudhun lan nulis elemen kanthi otomatis menyang irisan.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(len - 1)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(len - 2) };
            ptr::copy_nonoverlapping(v.get_unchecked(len - 2), v.get_unchecked_mut(len - 1), 1);

            for i in (0..len - 2).rev() {
                if !is_less(&*tmp, v.get_unchecked(i)) {
                    break;
                }

                // Pindhahake elemen 'siji' ing sisih tengen, banjur ganti bolongan ing sisih kiwa.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i + 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` bakal tiba lan banjur nyalin `tmp` menyang bolongan sing isih ana ing `v`.
        }
    }
}

/// Sebagean ngurutake irisan kanthi ngowahi sawetara elemen sing ora cocog.
///
/// Ngasilake `true` yen irisan diurut ing pungkasan.Fungsi iki kasus paling gedhe *O*(*n*).
#[cold]
fn partial_insertion_sort<T, F>(v: &mut [T], is_less: &mut F) -> bool
where
    F: FnMut(&T, &T) -> bool,
{
    // Nomer maksimal pasangan out-of-order jejer sing bakal ganti.
    const MAX_STEPS: usize = 5;
    // Yen irisan luwih cekak tinimbang iki, aja mindhah elemen apa wae.
    const SHORTEST_SHIFTING: usize = 50;

    let len = v.len();
    let mut i = 1;

    for _ in 0..MAX_STEPS {
        // SAFETY: Kita wis kanthi cetha nindakake pamriksa kanthi `i < len`.
        // Kabeh indeksasi sabanjure mung ana ing kisaran `0 <= index < len`
        unsafe {
            // Temokake pasangan elemen out-of-order jejer sabanjure.
            while i < len && !is_less(v.get_unchecked(i), v.get_unchecked(i - 1)) {
                i += 1;
            }
        }

        // Apa kita wis rampung?
        if i == len {
            return true;
        }

        // Aja ngowahi elemen ing susunan sing cendhak, sing duwe biaya kinerja.
        if len < SHORTEST_SHIFTING {
            return false;
        }

        // Tukar pasangan unsur sing ditemokake.Iki nggawe supaya bener.
        v.swap(i - 1, i);

        // Shift unsur cilik ngiwa.
        shift_tail(&mut v[..i], is_less);
        // Ganti elemen sing luwih gedhe ing sisih tengen.
        shift_head(&mut v[i..], is_less);
    }

    // Ora ngatur ngurutake irisan kanthi sawetara langkah sing winates.
    false
}

/// Ngurutake irisan kanthi nggunakake sisipan, yaiku *O*(*n*^ 2) kasus paling ala.
fn insertion_sort<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    for i in 1..v.len() {
        shift_tail(&mut v[..i + 1], is_less);
    }
}

/// Limo `v` nggunakake heapsort, kang njamin *O*(*n*\*log(* n*)) awon-cilik.
#[cold]
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub fn heapsort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Tumpukan binar iki ngormati `parent >= child` sing invarian.
    let mut sift_down = |v: &mut [T], mut node| {
        loop {
            // Anak-anak `node`:
            let left = 2 * node + 1;
            let right = 2 * node + 2;

            // Pilih anak luwih.
            let greater =
                if right < v.len() && is_less(&v[left], &v[right]) { right } else { left };

            // Mungkasi yen invariant ditahan ing `node`.
            if greater >= v.len() || !is_less(&v[node], &v[greater]) {
                break;
            }

            // Tukar `node` karo bocah sing luwih gedhe, selangkah mudhun, lan terus ayak.
            v.swap(node, greater);
            node = greater;
        }
    };

    // Mbangun tumpukan ing wektu linier.
    for i in (0..v.len() / 2).rev() {
        sift_down(v, i);
    }

    // Pop elemen maksimal saka tumpukan.
    for i in (1..v.len()).rev() {
        v.swap(0, i);
        sift_down(&mut v[..i], 0);
    }
}

/// Partisi `v` dadi elemen sing luwih cilik tinimbang `pivot`, diikuti karo unsur sing luwih gedhe tinimbang utawa padha karo `pivot`.
///
///
/// Ngasilake nomer elemen sing luwih cilik tinimbang `pivot`.
///
/// Pemisahan ditindakake kanthi blok supaya bisa nyuda biaya operasi cabang.
/// idea iki presented ing kertas [BlockQuicksort][pdf].
///
/// [pdf]: http://drops.dagstuhl.de/opus/volltexte/2016/6389/pdf/LIPIcs-ESA-2016-38.pdf
fn partition_in_blocks<T, F>(v: &mut [T], pivot: &T, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // Jumlah elemen ing blok khas.
    const BLOCK: usize = 128;

    // Algoritma pemisahan mbaleni langkah-langkah ing ngisor iki nganti rampung:
    //
    // 1. Lacak blok saka sisih kiwa kanggo ngidentifikasi elemen sing luwih gedhe tinimbang utawa padha karo poros kasebut.
    // 2. Lacak blok saka sisih tengen kanggo ngenali elemen sing luwih cilik tinimbang poros kasebut.
    // 3. Ganti elemen sing diidentifikasi ing antarane kiwa lan tengen.
    //
    // Kita njaga variabel ing ngisor iki kanggo blok elemen:
    //
    // 1. `block` - Jumlah elemen ing blok kasebut.
    // 2. `start` - Mulai pitunjuk menyang larik `offsets`.
    // 3. `end` - Titik pitunjuk menyang larik `offsets`.
    // 4. : Tambahan, Indeks saka metu-saka-urutan unsur ing pemblokiran.

    // Blok saiki ing sisih kiwa (saka `l` nganti `l.add(block_l)`).
    let mut l = v.as_mut_ptr();
    let mut block_l = BLOCK;
    let mut start_l = ptr::null_mut();
    let mut end_l = ptr::null_mut();
    let mut offsets_l = [MaybeUninit::<u8>::uninit(); BLOCK];

    // Blok saiki ing sisih tengen (saka `r.sub(block_r)` to `r`).
    // SAFETY: Dokumentasi kanggo .add() khusus sebutno `vec.as_ptr().add(vec.len())` tansah safe`
    let mut r = unsafe { l.add(v.len()) };
    let mut block_r = BLOCK;
    let mut start_r = ptr::null_mut();
    let mut end_r = ptr::null_mut();
    let mut offsets_r = [MaybeUninit::<u8>::uninit(); BLOCK];

    // FIXME: Nalika kita njaluk VLAs, nyoba nggawe siji Uploaded dawa `min(v.len(), 2 * BLOCK): rodo
    // saka rong susunan ukuran tetep dawane `BLOCK`.VLA bisa uga luwih efisien ing cache.

    // Ngasilake nomer elemen ing antarane petunjuk `l` (inclusive) lan `r` (exclusive).
    fn width<T>(l: *mut T, r: *mut T) -> usize {
        assert!(mem::size_of::<T>() > 0);
        (r as usize - l as usize) / mem::size_of::<T>()
    }

    loop {
        // Kita wis rampung karo pembagian block-by-block nalika `l` lan `r` njaluk banget cedhak.
        // Banjur kita nindakake sawetara tugas tambalan supaya bisa partisi elemen sing isih ana.
        let is_done = width(l, r) <= 2 * BLOCK;

        if is_done {
            // Jumlah unsur sing isih ana (isih ora dibandhingake karo poros).
            let mut rem = width(l, r);
            if start_l < end_l || start_r < end_r {
                rem -= BLOCK;
            }

            // Setel ukuran blok supaya blok kiwa lan tengen ora tumpang tindih, nanging selaras kanthi sampurna kanggo nutupi jurang sing isih ana.
            //
            if start_l < end_l {
                block_r = rem;
            } else if start_r < end_r {
                block_l = rem;
            } else {
                block_l = rem / 2;
                block_r = rem - block_l;
            }
            debug_assert!(block_l <= BLOCK && block_r <= BLOCK);
            debug_assert!(width(l, r) == block_l + block_r);
        }

        if start_l == end_l {
            // Lacak elemen `block_l` saka sisih kiwa.
            start_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            end_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            let mut elem = l;

            for i in 0..block_l {
                // SAFETY: Operasi unsafety ngisor ndherek panggunaan saka `offset`.
                //         Miturut kahanan dibutuhaké déning fungsi, kita gawe marem amarga:
                //         1. `offsets_l` iku tumpukan-diparengake, lan kanthi mangkono dianggep kapisah obyek diparengake.
                //         2. Fungsi `is_less` ngasilake `bool`.
                //            Casting `bool` ora bakal kebanjiran `isize`.
                //         3. Kita wis njamin yen `block_l` bakal `<= BLOCK`.
                //            Plus, `end_l` wiwitanipun disetel kanggo wiwiti pitunjuk saka `offsets_` kang dinyatakaké ing tumpukan.
                //            Mangkono, kita ngerti manawa ing kasus sing paling ala (kabeh invasi `is_less` ngasilake palsu) kita mung bakal entuk 1 byte pungkasan.
                //        Operasi liyane sing ora aman ing kene yaiku dereferencing `elem`.
                //        Nanging, `elem` wiwitanipun wiwiti pitunjuk kanggo irisan kang tansah bener.
                unsafe {
                    // Bandhing tanpa cabang.
                    *end_l = i as u8;
                    end_l = end_l.offset(!is_less(&*elem, pivot) as isize);
                    elem = elem.offset(1);
                }
            }
        }

        if start_r == end_r {
            // Lacak elemen `block_r` saka sisih tengen.
            start_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            end_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            let mut elem = r;

            for i in 0..block_r {
                // SAFETY: Operasi unsafety ngisor ndherek panggunaan saka `offset`.
                //         Miturut kahanan dibutuhaké déning fungsi, kita gawe marem amarga:
                //         1. `offsets_r` iku tumpukan-diparengake, lan kanthi mangkono dianggep kapisah obyek diparengake.
                //         2. Fungsi `is_less` ngasilake `bool`.
                //            Casting `bool` ora bakal kebanjiran `isize`.
                //         3. Kita wis njamin yen `block_r` bakal `<= BLOCK`.
                //            Ditambah maneh, `end_r` wiwitane diwenehake menyang penunjuk wiwitan `offsets_` sing diumumake ing tumpukan.
                //            Mangkono, kita ngerti manawa ing kasus sing paling ala (kabeh invasi `is_less` bakal bali nyata) kita mung bakal entuk paling akeh 1 byte pungkasane.
                //        Operasi liyane sing ora aman ing kene yaiku dereferencing `elem`.
                //        Nanging, `elem` wiwitanipun `1 *sizeof(T)` kepungkur mburi lan kita decrement kanthi `1* sizeof(T)` sadurunge ngakses iku.
                //        Ditambah maneh, `block_r` negesake kurang saka `BLOCK` lan `elem` mula bakal nuduhake wiwitan irisan kasebut.
                unsafe {
                    // Bandhing tanpa cabang.
                    elem = elem.offset(-1);
                    *end_r = i as u8;
                    end_r = end_r.offset(is_less(&*elem, pivot) as isize);
                }
            }
        }

        // Jumlah elemen sing ora pesenan kanggo ngganti antarane sisih kiwa lan tengen.
        let count = cmp::min(width(start_l, end_l), width(start_r, end_r));

        if count > 0 {
            macro_rules! left {
                () => {
                    l.offset(*start_l as isize)
                };
            }
            macro_rules! right {
                () => {
                    r.offset(-(*start_r as isize) - 1)
                };
            }

            // Ora ngganti siji pasangan ing wektu iki, luwih efektif kanggo nindakake permutasi siklik.
            // Iki ora padha karo pertukaran, nanging ngasilake asil sing padha nggunakake operasi memori sing luwih sithik.
            //
            unsafe {
                let tmp = ptr::read(left!());
                ptr::copy_nonoverlapping(right!(), left!(), 1);

                for _ in 1..count {
                    start_l = start_l.offset(1);
                    ptr::copy_nonoverlapping(left!(), right!(), 1);
                    start_r = start_r.offset(1);
                    ptr::copy_nonoverlapping(right!(), left!(), 1);
                }

                ptr::copy_nonoverlapping(&tmp, right!(), 1);
                mem::forget(tmp);
                start_l = start_l.offset(1);
                start_r = start_r.offset(1);
            }
        }

        if start_l == end_l {
            // Kabeh elemen sing ora duwe urutan ing blok kiwa dipindhah.Pindhah menyang blok sabanjure.
            l = unsafe { l.offset(block_l as isize) };
        }

        if start_r == end_r {
            // Kabeh elemen sing ora pesenan ing blok tengen dipindhah.Pindhah menyang blok sadurunge.
            r = unsafe { r.offset(-(block_r as isize)) };
        }

        if is_done {
            break;
        }
    }

    // Kabeh sing isih ana saiki paling akeh siji blok (ing sisih kiwa utawa ing sisih tengen) kanthi elemen sing ora bisa diatur sing kudu dipindhah.
    // Elemen sing isih ana bisa diganti nganti pungkasan ing blok kasebut.
    //

    if start_l < end_l {
        // Blok kiwa isih ana.
        // Pindhah isih metu-saka-urutan unsur kanggo sisih tengen adoh.
        debug_assert_eq!(width(l, r), block_l);
        while start_l < end_l {
            unsafe {
                end_l = end_l.offset(-1);
                ptr::swap(l.offset(*end_l as isize), r.offset(-1));
                r = r.offset(-1);
            }
        }
        width(v.as_mut_ptr(), r)
    } else if start_r < end_r {
        // Blok tengen isih ana.
        // Pindhah isih metu-saka-urutan unsur sawijining adoh kiwa.
        debug_assert_eq!(width(l, r), block_r);
        while start_r < end_r {
            unsafe {
                end_r = end_r.offset(-1);
                ptr::swap(l, r.offset(-(*end_r as isize) - 1));
                l = l.offset(1);
            }
        }
        width(v.as_mut_ptr(), l)
    } else {
        // Ora ana liyane sing kudu ditindakake, kita wis rampung.
        width(v.as_mut_ptr(), l)
    }
}

/// Sekat `v` menyang unsur cilik saka `v[pivot]`, ngiring dening unsur luwih saka utawa witjaksono kanggo `v[pivot]`.
///
///
/// Ngasilake tuple saka:
///
/// 1. Jumlah unsur sing luwih cilik tinimbang `v[pivot]`.
/// 2. Bener yen `v` wis partisi.
fn partition<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    let (mid, was_partitioned) = {
        // Selehake poros ing awal irisan.
        v.swap(0, pivot);
        let (pivot, v) = v.split_at_mut(1);
        let pivot = &mut pivot[0];

        // Waca poros menyang variabel sing dialokasikan kanggo efisiensi.
        // Yen operasi perbandingan ing ngisor iki panics, poros bakal kanthi otomatis ditulis bali menyang irisan.
        let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
        let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
        let pivot = &*tmp;

        // Temokake pasangan elemen out-of-order pasangan pisanan.
        let mut l = 0;
        let mut r = v.len();

        // SAFETY: Ora aman ing ngisor iki kalebu ngindeks rangking.
        // Kanggo sing pertama: Kita wis mriksa wates ing kene kanthi `l < r`.
        // Kanggo sing nomer loro: Wiwitane duwe `l == 0` lan `r == v.len()` lan mriksa yen `l < r` ing saben operasi indeksasi.
        //                     Saka kene kita ngerti sing `r` kudu paling sethithik `r == l` kang ditampilake dadi bener saka siji.
        unsafe {
            // Temokake elemen pertama sing luwih gedhe saka utawa padha karo poros kasebut.
            while l < r && is_less(v.get_unchecked(l), pivot) {
                l += 1;
            }

            // Temokake unsur pungkasan sing luwih cilik tinimbang poros kasebut.
            while l < r && !is_less(v.get_unchecked(r - 1), pivot) {
                r -= 1;
            }
        }

        (l + partition_in_blocks(&mut v[l..r], pivot, is_less), l >= r)

        // `_pivot_guard` dadi saking orane katrangan lan nyerat ing poros (kang punika variabel tumpukan-diparengake) bali menyang irisan ngendi iku yaiku.
        // Langkah iki penting kanggo njamin keamanan!
        //
    };

    // Selehake poros ing antarane rong partisi kasebut.
    v.swap(0, mid);

    (mid, was_partitioned)
}

/// Partisi `v` dadi unsur sing padha karo `v[pivot]` diikuti karo unsur sing luwih gedhe tinimbang `v[pivot]`.
///
/// Ngasilake nomer unsur sing padha karo poros.
/// Dianggep yen `v` ora ngemot unsur sing luwih cilik tinimbang poros kasebut.
fn partition_equal<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // Selehake poros ing awal irisan.
    v.swap(0, pivot);
    let (pivot, v) = v.split_at_mut(1);
    let pivot = &mut pivot[0];

    // Waca poros menyang variabel sing dialokasikan kanggo efisiensi.
    // Yen operasi perbandingan ing ngisor iki panics, poros bakal kanthi otomatis ditulis bali menyang irisan.
    // SAFETY: Penunjuk ing kene bener amarga dipikolehi saka referensi irisan.
    let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
    let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
    let pivot = &*tmp;

    // Saiki partisi irisan.
    let mut l = 0;
    let mut r = v.len();
    loop {
        // SAFETY: Ora aman ing ngisor iki kalebu ngindeks rangking.
        // Kanggo sing pertama: Kita wis mriksa wates ing kene kanthi `l < r`.
        // Kanggo sing nomer loro: Wiwitane duwe `l == 0` lan `r == v.len()` lan mriksa yen `l < r` ing saben operasi indeksasi.
        //                     Saka kene kita ngerti sing `r` kudu paling sethithik `r == l` kang ditampilake dadi bener saka siji.
        unsafe {
            // Temokake elemen pertama sing luwih gedhe tinimbang poros kasebut.
            while l < r && !is_less(pivot, v.get_unchecked(l)) {
                l += 1;
            }

            // Temokake unsur pungkasan sing padha karo poros.
            while l < r && is_less(pivot, v.get_unchecked(r - 1)) {
                r -= 1;
            }

            // Apa kita wis rampung?
            if l >= r {
                break;
            }

            // Tukar pasangan sing ditemokake saka unsur sing ora pesenan.
            r -= 1;
            ptr::swap(v.get_unchecked_mut(l), v.get_unchecked_mut(r));
            l += 1;
        }
    }

    // Kita nemokake elemen `l` sing padha karo poros kasebut.Tambah 1 menyang akun kanggo poros kasebut dhewe.
    l + 1

    // `_pivot_guard` dadi saking orane katrangan lan nyerat ing poros (kang punika variabel tumpukan-diparengake) bali menyang irisan ngendi iku yaiku.
    // Langkah iki penting kanggo njamin keamanan!
}

/// Nyawurake sawetara unsur watara ing upaya kanggo break pola sing bisa nimbulaké imbalanced sekat ing quicksort.
///
#[cold]
fn break_patterns<T>(v: &mut [T]) {
    let len = v.len();
    if len >= 8 {
        // Generator nomer pseudorandom saka kertas "Xorshift RNGs" dening George Marsaglia.
        let mut random = len as u32;
        let mut gen_u32 = || {
            random ^= random << 13;
            random ^= random >> 17;
            random ^= random << 5;
            random
        };
        let mut gen_usize = || {
            if usize::BITS <= 32 {
                gen_u32() as usize
            } else {
                (((gen_u32() as u64) << 32) | (gen_u32() as u64)) as usize
            }
        };

        // Pilih nomer acak modulo nomer iki.
        // Nomer mathuk menyang `usize` amarga `len` ora luwih saka `isize::MAX`.
        let modulus = len.next_power_of_two();

        // Sawetara calon poros bakal ana ing cedhak indeks iki.Ayo dadi acak.
        let pos = len / 4 * 2;

        for i in 0..3 {
            // Gawe nomer acak modulo `len`.
            // Nanging, supaya supaya operasi larang regane kita njupuk Modulo daya saka loro, lan banjur ngurangi `len` nganti mathuk menyang sawetara `[0, len - 1]`.
            //
            let mut other = gen_usize() & (modulus - 1);

            // `other` dijamin kurang saka `2 * len`.
            if other >= len {
                other -= len;
            }

            v.swap(pos - 1 + i, other);
        }
    }
}

/// Milih sing poros ing `v` lan ngasilake indeks lan `true` yen irisan wis kamungkinan wis diurutake.
///
/// Unsur ing `v` bisa uga disusun ulang ing proses kasebut.
fn choose_pivot<T, F>(v: &mut [T], is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    // Dawa paling sithik kanggo milih cara rata-rata rata-rata.
    // irisan-irisan cendhek nggunakake cara prasaja belekan-of-telu.
    const SHORTEST_MEDIAN_OF_MEDIANS: usize = 50;
    // Nomer swap maksimal sing bisa ditindakake ing fungsi iki.
    const MAX_SWAPS: usize = 4 * 3;

    let len = v.len();

    // Telung indeks ing sacedhake kita bakal milih poros.
    let mut a = len / 4 * 1;
    let mut b = len / 4 * 2;
    let mut c = len / 4 * 3;

    // Count nomer total swaps kita babagan nindakake nalika ngurutake indeks.
    let mut swaps = 0;

    if len >= 8 {
        // Tukar indeks supaya `v[a] <= v[b]`.
        let mut sort2 = |a: &mut usize, b: &mut usize| unsafe {
            if is_less(v.get_unchecked(*b), v.get_unchecked(*a)) {
                ptr::swap(a, b);
                swaps += 1;
            }
        };

        // Tukar indeks supaya `v[a] <= v[b] <= v[c]`.
        let mut sort3 = |a: &mut usize, b: &mut usize, c: &mut usize| {
            sort2(a, b);
            sort2(b, c);
            sort2(a, b);
        };

        if len >= SHORTEST_MEDIAN_OF_MEDIANS {
            // Temokake rata-rata `v[a - 1], v[a], v[a + 1]` lan nyimpen indeks dadi `a`.
            let mut sort_adjacent = |a: &mut usize| {
                let tmp = *a;
                sort3(&mut (tmp - 1), a, &mut (tmp + 1));
            };

            // Golek medians ing tetanggan saka `a`, `b`, lan `c`.
            sort_adjacent(&mut a);
            sort_adjacent(&mut b);
            sort_adjacent(&mut c);
        }

        // Temokake rata-rata ing antarane `a`, `b`, lan `c`.
        sort3(&mut a, &mut b, &mut c);
    }

    if swaps < MAX_SWAPS {
        (b, swaps == 0)
    } else {
        // Nomer swap maksimal ditindakake.
        // Kemungkinan irisan mudhun utawa umume mudhun, mula bisa uga bisa mbalikke ngurutake luwih cepet.
        v.reverse();
        (len - 1 - b, true)
    }
}

/// Ngurutake `v` kanthi rekursif.
///
/// Yen irisan wis leluhur ing Uploaded asli, iku kasebut minangka `pred`.
///
/// `limit` yaiku nomer partisi sing ora seimbang sadurunge diowahi dadi `heapsort`.
/// Yen nol, fungsi iki bakal langsung diowahi dadi tumpukan.
fn recurse<'a, T, F>(mut v: &'a mut [T], is_less: &mut F, mut pred: Option<&'a T>, mut limit: u32)
where
    F: FnMut(&T, &T) -> bool,
{
    // Irisan nganti suwene bisa diurutake nganggo jinis sisipan.
    const MAX_INSERTION: usize = 20;

    // Bener yen partisi pungkasan cukup imbang.
    let mut was_balanced = true;
    // Bener yen partisi pungkasan ora ngacak unsur (irisan wis partisi).
    let mut was_partitioned = true;

    loop {
        let len = v.len();

        // Irisan sing cendhak banget bisa diurutake nganggo jinis sisipan.
        if len <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // Yen akeh pilihan pivot sing ora digawe, cukup bali menyang jaminan supaya bisa ngatasi kasus paling ala `O(n * log(n))`.
        //
        if limit == 0 {
            heapsort(v, is_less);
            return;
        }

        // Yen partisi pungkasan ora seimbang, coba corak pola ing irisan kanthi ngowahi sawetara elemen.
        // Muga-muga kita bakal milih poros sing luwih apik wektu iki.
        if !was_balanced {
            break_patterns(v);
            limit -= 1;
        }

        // Pilih poros lan coba coba kira irisan kasebut wis diurutake.
        let (pivot, likely_sorted) = choose_pivot(v, is_less);

        // Yen pembagian pungkasan iki patut imbang lan ora ngacak unsur, lan yen pilihan poros prediksi irisan wis kamungkinan wis diurutake ...
        //
        if was_balanced && was_partitioned && likely_sorted {
            // Coba identifikasi sawetara elemen sing ora pesenan lan ganti menyang posisi sing bener.
            // Yen irisan ends munggah kang rampung diurutake, kita wis rampung.
            if partial_insertion_sort(v, is_less) {
                return;
            }
        }

        // Yen poros pendhet witjaksono kanggo leluhur, banjur iku unsur paling cilik ing irisan.
        // Pemisahan irisan menyang unsur witjaksono kanggo lan unsur luwih saka poros ing.
        // Kasus iki biasane kena nalika irisan ngemot akeh unsur duplikat.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // Terusake ngurutake elemen sing luwih gedhe tinimbang poros kasebut.
                v = &mut { v }[mid..];
                continue;
            }
        }

        // Pisahake irisan.
        let (mid, was_p) = partition(v, pivot, is_less);
        was_balanced = cmp::min(mid, len - mid) >= len / 8;
        was_partitioned = was_p;

        // Split irisan menyang `left`, `pivot`, lan `right`.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        // Baleni menyang sisih sing luwih cendhek mung kanggo minimalake jumlah panggilan rekursif lan ngonsumsi kurang akeh tumpukan.
        // Banjur terus karo sisih sing luwih dawa (iki padha karo rekurasi buntut).
        //
        if left.len() < right.len() {
            recurse(left, is_less, pred, limit);
            v = right;
            pred = Some(pivot);
        } else {
            recurse(right, is_less, Some(pivot), limit);
            v = left;
        }
    }
}

/// Ngurutake `v` nggunakake quicksort sing bisa ngalahake pola, yaiku *O*(*n*\*log(* n*)) kasus paling ala.
pub fn quicksort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Ngurutake ora duwe tumindak sing migunani babagan jinis ukuran nol.
    if mem::size_of::<T>() == 0 {
        return;
    }

    // Matesi jumlah sekat imbalanced kanggo `floor(log2(len)) + 1`.
    let limit = usize::BITS - v.len().leading_zeros();

    recurse(v, &mut is_less, None, limit);
}

fn partition_at_index_loop<'a, T, F>(
    mut v: &'a mut [T],
    mut index: usize,
    is_less: &mut F,
    mut pred: Option<&'a T>,
) where
    F: FnMut(&T, &T) -> bool,
{
    loop {
        // Kanggo irisan nganti suwene iki, luwih cepet bisa diurutake.
        const MAX_INSERTION: usize = 10;
        if v.len() <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // Pilih poros
        let (pivot, _) = choose_pivot(v, is_less);

        // Yen poros pendhet witjaksono kanggo leluhur, banjur iku unsur paling cilik ing irisan.
        // Pemisahan irisan menyang unsur witjaksono kanggo lan unsur luwih saka poros ing.
        // Kasus iki biasane kena nalika irisan ngemot akeh unsur duplikat.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // Yen wis nglewati indeks, mula luwih becik.
                if mid > index {
                    return;
                }

                // Yen ora, terus ngurutake unsur luwih saka poros ing.
                v = &mut v[mid..];
                index = index - mid;
                pred = None;
                continue;
            }
        }

        let (mid, _) = partition(v, pivot, is_less);

        // Split irisan menyang `left`, `pivot`, lan `right`.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        if mid < index {
            v = right;
            index = index - mid - 1;
            pred = Some(pivot);
        } else if mid > index {
            v = left;
        } else {
            // Yen agêng==indeks, banjur kita wis rampung, wiwit partition() dijamin kabeh unsur sawise agêng luwih saka utawa witjaksono kanggo agêng.
            //
            return;
        }
    }
}

pub fn partition_at_index<T, F>(
    v: &mut [T],
    index: usize,
    mut is_less: F,
) -> (&mut [T], &mut T, &mut [T])
where
    F: FnMut(&T, &T) -> bool,
{
    use cmp::Ordering::Greater;
    use cmp::Ordering::Less;

    if index >= v.len() {
        panic!("partition_at_index index {} greater than length of slice {}", index, v.len());
    }

    if mem::size_of::<T>() == 0 {
        // Ngurutake ora duwe tumindak sing migunani babagan jinis ukuran nol.Aja nindakake apa-apa.
    } else if index == v.len() - 1 {
        // Temokake elemen maksimal banjur lebokake ing posisi pungkasan saka susunan kasebut.
        // Kita lagi free nggunakake `unwrap()` kene amarga kita ngerti v ora kudu kosong.
        let (max_index, _) = v
            .iter()
            .enumerate()
            .max_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(max_index, index);
    } else if index == 0 {
        // Golek min unsur lan manggonake ing posisi pisanan Uploaded ing.
        // Kita lagi free nggunakake `unwrap()` kene amarga kita ngerti v ora kudu kosong.
        let (min_index, _) = v
            .iter()
            .enumerate()
            .min_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(min_index, index);
    } else {
        partition_at_index_loop(v, index, &mut is_less, None);
    }

    let (left, right) = v.split_at_mut(index);
    let (pivot, right) = right.split_at_mut(1);
    let pivot = &mut pivot[0];
    (left, pivot, right)
}