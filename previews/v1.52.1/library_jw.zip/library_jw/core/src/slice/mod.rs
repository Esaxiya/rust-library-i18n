// ignore-tidy-filelength

//! Manajemen irisan lan manipulasi.
//!
//! Kanggo rincian liyane, waca [`std::slice`].
//!
//! [`std::slice`]: ../../std/slice/index.html

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering::{self, Greater, Less};
use crate::marker::Copy;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ops::{FnMut, Range, RangeBounds};
use crate::option::Option;
use crate::option::Option::{None, Some};
use crate::ptr;
use crate::result::Result;
use crate::result::Result::{Err, Ok};
use crate::slice;

#[unstable(
    feature = "slice_internals",
    issue = "none",
    reason = "exposed from core to be reused in std; use the memchr crate"
)]
/// Pure rust implementasine memchr, dijupuk saka rust-memchr
pub mod memchr;

mod ascii;
mod cmp;
mod index;
mod iter;
mod raw;
mod rotate;
mod sort;
mod specialize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Chunks, ChunksMut, Windows};
#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Iter, IterMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplitN, RSplitNMut, Split, SplitMut, SplitN, SplitNMut};

#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub use iter::{RSplit, RSplitMut};

#[stable(feature = "chunks_exact", since = "1.31.0")]
pub use iter::{ChunksExact, ChunksExactMut};

#[stable(feature = "rchunks", since = "1.31.0")]
pub use iter::{RChunks, RChunksExact, RChunksExactMut, RChunksMut};

#[unstable(feature = "array_chunks", issue = "74985")]
pub use iter::{ArrayChunks, ArrayChunksMut};

#[unstable(feature = "array_windows", issue = "75027")]
pub use iter::ArrayWindows;

#[unstable(feature = "slice_group_by", issue = "80552")]
pub use iter::{GroupBy, GroupByMut};

#[stable(feature = "split_inclusive", since = "1.51.0")]
pub use iter::{SplitInclusive, SplitInclusiveMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use raw::{from_raw_parts, from_raw_parts_mut};

#[stable(feature = "from_ref", since = "1.28.0")]
pub use raw::{from_mut, from_ref};

// Fungsi iki mung umum amarga ora ana cara liya kanggo heapsort tes unit.
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub use sort::heapsort;

#[stable(feature = "slice_get_slice", since = "1.28.0")]
pub use index::SliceIndex;

#[unstable(feature = "slice_range", issue = "76393")]
pub use index::range;

#[lang = "slice"]
#[cfg(not(test))]
impl<T> [T] {
    /// Ngasilake nomer elemen ing irisan.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_len", since = "1.32.0")]
    #[inline]
    // SAFETY: muni amarga kita ngirim lapangan dawa minangka usize (mesthine kudu)
    #[rustc_allow_const_fn_unstable(const_fn_union)]
    pub const fn len(&self) -> usize {
        #[cfg(bootstrap)]
        {
            // SAFETY: iki aman amarga `&[T]` lan `FatPtr<T>` duwe tata letak sing padha.
            // Mung `std` sing bisa njamin iki.
            unsafe { crate::ptr::Repr { rust: self }.raw.len }
        }
        #[cfg(not(bootstrap))]
        {
            // FIXME: Ganti nganggo `crate::ptr::metadata(self)` yen wis stabil.
            // Wiwit nulis iki, iki nyebabake kesalahan "Const-stable functions can only call other const-stable functions".
            //

            // SAFETY: Ngakses nilai saka serikat `PtrRepr` aman wiwit * const T
            // lan PtrComponents<T>duwe noto memori sing padha.
            // Mung std sing bisa njamin.
            unsafe { crate::ptr::PtrRepr { const_ptr: self }.components.metadata }
        }
    }

    /// Ngasilake `true` yen irisan dawane 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert!(!a.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_is_empty", since = "1.32.0")]
    #[inline]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Ngasilake elemen irisan pertama, utawa `None` yen kosong.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&10), v.first());
    ///
    /// let w: &[i32] = &[];
    /// assert_eq!(None, w.first());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn first(&self) -> Option<&T> {
        if let [first, ..] = self { Some(first) } else { None }
    }

    /// Ngasilake pitunjuk sing bisa diowahi menyang elemen pertama irisan, utawa `None` yen kosong.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(first) = x.first_mut() {
    ///     *first = 5;
    /// }
    /// assert_eq!(x, &[5, 1, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn first_mut(&mut self) -> Option<&mut T> {
        if let [first, ..] = self { Some(first) } else { None }
    }

    /// Ngasilake pisanan lan kabeh liyane saka unsur saka irisan, utawa `None` yen kosong.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[0, 1, 2];
    ///
    /// if let Some((first, elements)) = x.split_first() {
    ///     assert_eq!(first, &0);
    ///     assert_eq!(elements, &[1, 2]);
    /// }
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_first(&self) -> Option<(&T, &[T])> {
        if let [first, tail @ ..] = self { Some((first, tail)) } else { None }
    }

    /// Ngasilake pisanan lan kabeh liyane saka unsur saka irisan, utawa `None` yen kosong.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some((first, elements)) = x.split_first_mut() {
    ///     *first = 3;
    ///     elements[0] = 4;
    ///     elements[1] = 5;
    /// }
    /// assert_eq!(x, &[3, 4, 5]);
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_first_mut(&mut self) -> Option<(&mut T, &mut [T])> {
        if let [first, tail @ ..] = self { Some((first, tail)) } else { None }
    }

    /// Ngasilake pungkasan lan kabeh unsur irisan, utawa `None` yen kosong.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[0, 1, 2];
    ///
    /// if let Some((last, elements)) = x.split_last() {
    ///     assert_eq!(last, &2);
    ///     assert_eq!(elements, &[0, 1]);
    /// }
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_last(&self) -> Option<(&T, &[T])> {
        if let [init @ .., last] = self { Some((last, init)) } else { None }
    }

    /// Ngasilake pungkasan lan kabeh unsur irisan, utawa `None` yen kosong.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some((last, elements)) = x.split_last_mut() {
    ///     *last = 3;
    ///     elements[0] = 4;
    ///     elements[1] = 5;
    /// }
    /// assert_eq!(x, &[4, 5, 3]);
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_last_mut(&mut self) -> Option<(&mut T, &mut [T])> {
        if let [init @ .., last] = self { Some((last, init)) } else { None }
    }

    /// Ngasilake elemen pungkasan irisan, utawa `None` yen kosong.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&30), v.last());
    ///
    /// let w: &[i32] = &[];
    /// assert_eq!(None, w.last());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn last(&self) -> Option<&T> {
        if let [.., last] = self { Some(last) } else { None }
    }

    /// Ngasilake pitunjuk sing bisa diowahi menyang item pungkasan ing irisan.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(last) = x.last_mut() {
    ///     *last = 10;
    /// }
    /// assert_eq!(x, &[0, 1, 10]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn last_mut(&mut self) -> Option<&mut T> {
        if let [.., last] = self { Some(last) } else { None }
    }

    /// Ngasilake referensi kanggo unsur utawa subslice, gumantung karo jinis indeks.
    ///
    /// - Yen diwenehi posisi, ngasilake referensi kanggo unsur ing posisi sing utawa `None` yen metu saka wates.
    ///
    /// - Yen diwenehi sawetara, ngasilake subslice cocog kanggo sawetara sing, utawa `None` yen metu saka wates.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&40), v.get(1));
    /// assert_eq!(Some(&[10, 40][..]), v.get(0..2));
    /// assert_eq!(None, v.get(3));
    /// assert_eq!(None, v.get(0..4));
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn get<I>(&self, index: I) -> Option<&I::Output>
    where
        I: SliceIndex<Self>,
    {
        index.get(self)
    }

    /// Ngasilake referensi sing bisa diowahi kanggo unsur utawa langganan gumantung saka jinis indeks (waca [`get`]) utawa `None` yen indeks kasebut ora ana watesan.
    ///
    ///
    /// [`get`]: slice::get
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(elem) = x.get_mut(1) {
    ///     *elem = 42;
    /// }
    /// assert_eq!(x, &[0, 42, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn get_mut<I>(&mut self, index: I) -> Option<&mut I::Output>
    where
        I: SliceIndex<Self>,
    {
        index.get_mut(self)
    }

    /// Ngasilake referensi kanggo elemen utawa subslice, tanpa mriksa wates.
    ///
    /// Kanggo alternatif sing aman, deleng [`get`].
    ///
    /// # Safety
    ///
    /// Nelpon metode iki kanthi indeks njaba wates * *[prilaku sing durung ditemtokake] * sanajan referensi sing diasilake ora digunakake.
    ///
    ///
    /// [`get`]: slice::get
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked(1), &2);
    /// }
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub unsafe fn get_unchecked<I>(&self, index: I) -> &I::Output
    where
        I: SliceIndex<Self>,
    {
        // SAFETY: panelpon kudu njogo kabeh syarat keamanan `get_unchecked`;
        // irisan bisa dibatalake amarga `self` minangka referensi sing aman.
        // Pointer sing bali wis aman amarga impl `SliceIndex` kudu njamin manawa wis ana.
        unsafe { &*index.get_unchecked(self) }
    }

    /// Ngasilake referensi sing bisa diowahi kanggo unsur utawa subslice, tanpa mriksa wates.
    ///
    /// Kanggo alternatif aman ndeleng [`get_mut`].
    ///
    /// # Safety
    ///
    /// Nelpon metode iki kanthi indeks njaba wates * *[prilaku sing durung ditemtokake] * sanajan referensi sing diasilake ora digunakake.
    ///
    ///
    /// [`get_mut`]: slice::get_mut
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    ///
    /// unsafe {
    ///     let elem = x.get_unchecked_mut(1);
    ///     *elem = 13;
    /// }
    /// assert_eq!(x, &[1, 13, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(&mut self, index: I) -> &mut I::Output
    where
        I: SliceIndex<Self>,
    {
        // SAFETY: panelpon kudu netepi syarat keamanan `get_unchecked_mut`;
        // irisan bisa dibatalake amarga `self` minangka referensi sing aman.
        // Pointer sing bali wis aman amarga impl `SliceIndex` kudu njamin manawa wis ana.
        unsafe { &mut *index.get_unchecked_mut(self) }
    }

    /// Ngasilake pitunjuk mentah menyang buffer irisan.
    ///
    /// Panelpon kudu mesthekake yen irisan luwih dhuwur tinimbang pitunjuk fungsi iki bali, utawa yen bakal ngarahake sampah.
    ///
    /// Panelpon uga kudu mesthekake yen memori sing diwenehi pointer (non-transitively) ora nate ditulis (kajaba ing `UnsafeCell`) nggunakake pitunjuk iki utawa pitunjuk apa wae sing asale.
    /// Yen sampeyan perlu kanggo mutasi isi saka irisan, nggunakake [`as_mut_ptr`].
    ///
    /// Ngowahi wadhah sing dirujuk nganggo irisan iki bisa uga nyebabake buffer bisa dialokasikan maneh, sing uga bakal menehi petunjuk apa wae sing ora valid.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    /// let x_ptr = x.as_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         assert_eq!(x.get_unchecked(i), &*x_ptr.add(i));
    ///     }
    /// }
    /// ```
    ///
    /// [`as_mut_ptr`]: slice::as_mut_ptr
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(&self) -> *const T {
        self as *const [T] as *const T
    }

    /// Ngasilake pitunjuk sing bisa diowahi kanthi ora aman menyang buffer irisan.
    ///
    /// Panelpon kudu mesthekake yen irisan luwih dhuwur tinimbang pitunjuk fungsi iki bali, utawa yen bakal ngarahake sampah.
    ///
    /// Ngowahi wadhah sing dirujuk nganggo irisan iki bisa uga nyebabake buffer bisa dialokasikan maneh, sing uga bakal menehi petunjuk apa wae sing ora valid.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    /// let x_ptr = x.as_mut_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         *x_ptr.add(i) += 2;
    ///     }
    /// }
    /// assert_eq!(x, &[3, 4, 6]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        self as *mut [T] as *mut T
    }

    /// Ngasilake loro penunjuk mentahan pepak irisan.
    ///
    /// Ing sawetara bali punika setengah kabuka, kang liya sing mburi pitunjuk TCTerms *siji sasi* unsur pungkasan saka irisan.
    /// Kanthi cara iki, lan irisan P dicekak loro penunjuk witjaksono, lan prabédan ing antarane loro penunjuk nggantosi ukuran saka irisan.
    ///
    /// Deleng [`as_ptr`] kanggo peringatan babagan nggunakake petunjuk kasebut.Pointer pungkasan kudu luwih ati-ati, amarga ora nuduhake elemen sing bener ing irisan kasebut.
    ///
    /// Fungsi iki migunani kanggo sesambungan karo antarmuka asing sing nggunakake rong petunjuk kanggo ngrujuk macem-macem elemen ing memori, kaya umume ing C++ .
    ///
    ///
    /// Sampeyan uga migunani kanggo mriksa manawa penunjuk menyang elemen nuduhake unsur irisan iki:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let x = &a[1] as *const _;
    /// let y = &5 as *const _;
    ///
    /// assert!(a.as_ptr_range().contains(&x));
    /// assert!(!a.as_ptr_range().contains(&y));
    /// ```
    ///
    /// [`as_ptr`]: slice::as_ptr
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_ptr_range", since = "1.48.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_ptr_range(&self) -> Range<*const T> {
        let start = self.as_ptr();
        // SAFETY: `add` ing kene aman, amarga:
        //
        //   - Kaloro petunjuk kasebut minangka bagean saka obyek sing padha, amarga nuduhake langsung obyek uga dietung.
        //
        //   - Ukuran irisan kasebut ora bakal luwih gedhe tinimbang byte isize::MAX, kaya sing kacathet ing kene:
        //       - https://github.com/rust-lang/unsafe-code-guidelines/issues/102#issuecomment-473340447
        //       - https://doc.rust-lang.org/reference/behavior-considered-undefined.html
        //       - https://doc.rust-lang.org/core/slice/fn.from_raw_parts.html#safety(This doesn't seem normative yet, but the very same assumption is made in many places, including the Index implementation of slices.)
        //
        //
        //   - Ora ana bungkus sing ana gandhengane, amarga irisan ora dibungkus ing pungkasan ruang alamat.
        //
        // Deleng dokumentasi pointer::add.
        //
        //
        //
        //
        let end = unsafe { start.add(self.len()) };
        start..end
    }

    /// Ngasilake rong petunjuk sing bisa diowahi sing ora aman sing bisa diiris.
    ///
    /// Ing sawetara bali punika setengah kabuka, kang liya sing mburi pitunjuk TCTerms *siji sasi* unsur pungkasan saka irisan.
    /// Kanthi cara iki, lan irisan P dicekak loro penunjuk witjaksono, lan prabédan ing antarane loro penunjuk nggantosi ukuran saka irisan.
    ///
    /// Deleng [`as_mut_ptr`] kanggo peringatan babagan nggunakake petunjuk kasebut.
    /// Pointer pungkasan kudu luwih ati-ati, amarga ora nuduhake elemen sing bener ing irisan kasebut.
    ///
    /// Fungsi iki migunani kanggo sesambungan karo antarmuka asing sing nggunakake rong petunjuk kanggo ngrujuk macem-macem elemen ing memori, kaya umume ing C++ .
    ///
    ///
    /// [`as_mut_ptr`]: slice::as_mut_ptr
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_ptr_range", since = "1.48.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_mut_ptr_range(&mut self) -> Range<*mut T> {
        let start = self.as_mut_ptr();
        // SAFETY: Deleng as_ptr_range() ing ndhuwur kenapa `add` ing kene aman.
        let end = unsafe { start.add(self.len()) };
        start..end
    }

    /// Tukar rong elemen ing irisan kasebut.
    ///
    /// # Arguments
    ///
    /// * a, Indeks unsur kaping pisanan
    /// * b, Indeks saka unsur nomer loro
    ///
    /// # Panics
    ///
    /// Panics yen `a` utawa `b` metu saka wates.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = ["a", "b", "c", "d"];
    /// v.swap(1, 3);
    /// assert!(v == ["a", "d", "c", "b"]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn swap(&mut self, a: usize, b: usize) {
        // ora bisa njupuk loro silihan mutable saka siji vector, supaya tinimbang nggunakake penunjuk mentahan.
        let pa = ptr::addr_of_mut!(self[a]);
        let pb = ptr::addr_of_mut!(self[b]);
        // SAFETY: `pa` lan `pb` digawe saka referensi sing bisa diowahi kanthi aman
        // kanggo elemen ing irisan lan mulane dijamin valid lan selaras.
        // Elinga yen ngakses unsur konco `a` lan `b` wis dicenthang lan bakal panic nalika metu saka wates.
        //
        unsafe {
            ptr::swap(pa, pb);
        }
    }

    /// Reverses urutan unsur ing irisan, ing panggonan.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [1, 2, 3];
    /// v.reverse();
    /// assert!(v == [3, 2, 1]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn reverse(&mut self) {
        let mut i: usize = 0;
        let ln = self.len();

        // Kanggo jinis sing cilik banget, kabeh individu maca ing dalan sing normal ora apik.
        // Kita bisa luwih apik, yen load/store sing ora laras karo efisiensin, kanthi mbukak potongan sing luwih gedhe lan ngowahi dhaptar.
        //

        // Luwih becik LLVM bakal nindakake iki kanggo kita, amarga luwih ngerti tinimbang yen maca sing ora larang efisien (amarga ana owah-owahan ing antarane versi ARM sing beda) lan ukuran potongan sing paling apik.
        // Nanging, nalika LLVM 4.0 (2017-05) mung mbukak loop, mula kita kudu nindakake iki.
        // (Hipotesis: mbalikke repot amarga sisih bisa diselarasake kanthi beda-bakal beda, yen dawane aneh-mula ora ana cara kanggo ngirim pra lan postludes nggunakake SIMD sing lengkap ing tengah.)
        //
        //
        //
        //
        //

        let fast_unaligned = cfg!(any(target_arch = "x86", target_arch = "x86_64"));

        if fast_unaligned && mem::size_of::<T>() == 1 {
            // Gunakake intrinsik llvm.bswap kanggo mbalikke u8 ing usize
            let chunk = mem::size_of::<usize>();
            while i + chunk - 1 < ln / 2 {
                // SAFETY: Ana sawetara perkara sing kudu dipriksa ing kene:
                //
                // - Elinga yen `chunk` iku salah siji 4 utawa 8 amarga mriksa cfg ndhuwur.Dadi `chunk - 1` positif.
                // - Ngindeks karo indeks `i` apik banget amarga jaminan mriksa loop
                //   `i + chunk - 1 < ln / 2`
                //   <=> `i < ln / 2 - (chunk - 1) < ln / 2 < ln`.
                // - Ngindeks kanthi indeks `ln - i - chunk = ln - (i + chunk)` ora apa-apa:
                //   - `i + chunk > 0` iku sepele sejatine.
                //   - Priksa loop njamin:
                //     `i + chunk - 1 < ln / 2`
                //     <=> `i + chunk ≤ ln / 2 ≤ ln`, mula pengurangan ora bakal mili.
                // - Telpon `read_unaligned` lan `write_unaligned` ora apa-apa:
                //   - `pa` nilai menyang indeks `i` ing endi `i < ln / 2 - (chunk - 1)` (ndeleng ndhuwur) lan `pb` nuduhake indeks `ln - i - chunk`, mula kalorone paling ora `chunk` akeh byte adoh saka pungkasan `self`.
                //
                //   - Sembarang memori sing diinisialisasi valid `usize`.
                //
                //
                //
                unsafe {
                    let ptr = self.as_mut_ptr();
                    let pa = ptr.add(i);
                    let pb = ptr.add(ln - i - chunk);
                    let va = ptr::read_unaligned(pa as *mut usize);
                    let vb = ptr::read_unaligned(pb as *mut usize);
                    ptr::write_unaligned(pa as *mut usize, vb.swap_bytes());
                    ptr::write_unaligned(pb as *mut usize, va.swap_bytes());
                }
                i += chunk;
            }
        }

        if fast_unaligned && mem::size_of::<T>() == 2 {
            // Gunakake muter-by-16 kanggo mbalikke u16s ing u32
            let chunk = mem::size_of::<u32>() / 2;
            while i + chunk - 1 < ln / 2 {
                // SAFETY: u32 sing ora ana gandhengane bisa diwaca saka `i` yen `i + 1 < ln`
                // (lan jelas `i < ln`), amarga saben unsur 2 bait lan kita lagi maca 4.
                //
                // `i + chunk - 1 < ln / 2` # nalika kahanan
                // `i + 2 - 1 < ln / 2`
                // `i + 1 < ln / 2`
                //
                // Amarga kurang saka dawa sing dibagi 2, mula kudu ana ing wates.
                //
                // Iki uga ateges kawontenan `0 < i + chunk <= ln` tansah dihormati, njupuk pitunjuk `pb` bisa digunakake kanthi aman.
                //
                //
                //
                //
                unsafe {
                    let ptr = self.as_mut_ptr();
                    let pa = ptr.add(i);
                    let pb = ptr.add(ln - i - chunk);
                    let va = ptr::read_unaligned(pa as *mut u32);
                    let vb = ptr::read_unaligned(pb as *mut u32);
                    ptr::write_unaligned(pa as *mut u32, vb.rotate_left(16));
                    ptr::write_unaligned(pb as *mut u32, va.rotate_left(16));
                }
                i += chunk;
            }
        }

        while i < ln / 2 {
            // SAFETY: `i` iku cendhek kanggo setengah dawa saka irisan supaya
            // ngakses `i` lan `ln - i - 1` aman (`i` wiwit ing 0 lan ora bakal pindhah luwih saka `ln / 2 - 1`).
            // Penunjuk sing diasilake `pa` lan `pb` mula valid lan selaras, lan bisa diwaca lan ditulis menyang.
            //
            //
            unsafe {
                // Ganti pertukaran sing ora aman kanggo ngindhari watesan ing swap aman.
                let ptr = self.as_mut_ptr();
                let pa = ptr.add(i);
                let pb = ptr.add(ln - i - 1);
                ptr::swap(pa, pb);
            }
            i += 1;
        }
    }

    /// Ngasilake lan iterator liwat irisan.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    /// let mut iterator = x.iter();
    ///
    /// assert_eq!(iterator.next(), Some(&1));
    /// assert_eq!(iterator.next(), Some(&2));
    /// assert_eq!(iterator.next(), Some(&4));
    /// assert_eq!(iterator.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter::new(self)
    }

    /// Ngasilake iterator sing ngidini ngowahi saben regane.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    /// for elem in x.iter_mut() {
    ///     *elem += 2;
    /// }
    /// assert_eq!(x, &[3, 4, 6]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        IterMut::new(self)
    }

    /// Ngasilake lan iterator liwat kabeh cedhak windows dawa `size`.
    /// windows tumpang tindih.
    /// Yen irisan luwih cendhek saka `size`, iterator ngasilake ora nilai.
    ///
    /// # Panics
    ///
    /// Panics yen `size` yaiku 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['r', 'u', 's', 't'];
    /// let mut iter = slice.windows(2);
    /// assert_eq!(iter.next().unwrap(), &['r', 'u']);
    /// assert_eq!(iter.next().unwrap(), &['u', 's']);
    /// assert_eq!(iter.next().unwrap(), &['s', 't']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Yen irisan luwih cekak tinimbang `size`:
    ///
    /// ```
    /// let slice = ['f', 'o', 'o'];
    /// let mut iter = slice.windows(4);
    /// assert!(iter.next().is_none());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn windows(&self, size: usize) -> Windows<'_, T> {
        let size = NonZeroUsize::new(size).expect("size is zero");
        Windows::new(self, size)
    }

    /// Ngasilake iterator liwat elemen `chunk_size` irisan sekaligus, diwiwiti ing wiwitan irisan.
    ///
    /// Ing tulisan sing irisan-irisan lan ora tumpang tindih.Yen `chunk_size` ora dibagi dawa saka irisan, banjur cuwilan pungkasan ora duwe dawa `chunk_size`.
    ///
    /// Waca [`chunks_exact`] kanggo varian saka iterator iki sing ngasilake tulisan saka tansah persis unsur `chunk_size`, lan [`rchunks`] kanggo iterator padha nanging miwiti ing mburi irisan.
    ///
    ///
    /// # Panics
    ///
    /// Panics yen `chunk_size` 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.chunks(2);
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert_eq!(iter.next().unwrap(), &['m']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`chunks_exact`]: slice::chunks_exact
    /// [`rchunks`]: slice::rchunks
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chunks(&self, chunk_size: usize) -> Chunks<'_, T> {
        assert_ne!(chunk_size, 0);
        Chunks::new(self, chunk_size)
    }

    /// Ngasilake iterator liwat elemen `chunk_size` irisan sekaligus, diwiwiti ing wiwitan irisan.
    ///
    /// Potongan minangka irisan sing bisa diowahi, lan ora tumpang tindih.Yen `chunk_size` ora dibagi dawa irisan, mula potongan pungkasan ora duwe dawa `chunk_size`.
    ///
    /// Deleng [`chunks_exact_mut`] kanggo varian iterator iki sing ngasilake potongan elemen `chunk_size` sing persis persis, lan [`rchunks_mut`] kanggo iterator sing padha nanging diwiwiti ing pungkasan irisan.
    ///
    ///
    /// # Panics
    ///
    /// Panics yen `chunk_size` 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.chunks_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 3]);
    /// ```
    ///
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    /// [`rchunks_mut`]: slice::rchunks_mut
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chunks_mut(&mut self, chunk_size: usize) -> ChunksMut<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksMut::new(self, chunk_size)
    }

    /// Ngasilake iterator liwat elemen `chunk_size` irisan sekaligus, diwiwiti ing wiwitan irisan.
    ///
    /// Potongan kasebut irisan lan ora tumpang tindih.
    /// Yen `chunk_size` ora mbagi dawa irisan, mula unsur pungkasan nganti `chunk_size-1` bakal disingkirake lan bisa dijupuk saka fungsi `remainder` saka iterator kasebut.
    ///
    ///
    /// Amarga saben cuwilan gadhah persis unsur `chunk_size`, compiler sing asring bisa ngoptimalake kode asil luwih saka ing cilik saka [`chunks`].
    ///
    /// Waca [`chunks`] kanggo varian saka iterator iki sing uga ngasilake seko minangka cuwilan cilik, lan [`rchunks_exact`] kanggo iterator padha nanging miwiti ing mburi irisan.
    ///
    /// # Panics
    ///
    /// Panics yen `chunk_size` 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.chunks_exact(2);
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['m']);
    /// ```
    ///
    /// [`chunks`]: slice::chunks
    /// [`rchunks_exact`]: slice::rchunks_exact
    ///
    ///
    ///
    #[stable(feature = "chunks_exact", since = "1.31.0")]
    #[inline]
    pub fn chunks_exact(&self, chunk_size: usize) -> ChunksExact<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksExact::new(self, chunk_size)
    }

    /// Ngasilake iterator liwat elemen `chunk_size` irisan sekaligus, diwiwiti ing wiwitan irisan.
    ///
    /// Potongan minangka irisan sing bisa diowahi, lan ora tumpang tindih.
    /// Yen `chunk_size` ora dibagi dawa saka irisan, banjur munggah pungkasan kanggo unsur `chunk_size-1` bakal dilirwakaké lan bisa njupuk saka fungsi `into_remainder` saka iterator ing.
    ///
    ///
    /// Amarga saben potongan duwe elemen `chunk_size` sing tepat, compiler asring bisa ngoptimalake kode sing diasilake luwih apik tinimbang ing [`chunks_mut`].
    ///
    /// Waca [`chunks_mut`] kanggo varian saka iterator iki sing uga ngasilake seko minangka cuwilan cilik, lan [`rchunks_exact_mut`] kanggo iterator padha nanging miwiti ing mburi irisan.
    ///
    /// # Panics
    ///
    /// Panics yen `chunk_size` 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.chunks_exact_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 0]);
    /// ```
    ///
    /// [`chunks_mut`]: slice::chunks_mut
    /// [`rchunks_exact_mut`]: slice::rchunks_exact_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "chunks_exact", since = "1.31.0")]
    #[inline]
    pub fn chunks_exact_mut(&mut self, chunk_size: usize) -> ChunksExactMut<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksExactMut::new(self, chunk_size)
    }

    /// Misah irisan dadi irisan susunan unsur-unsur `N`, kanthi asumsi ora ana sisa.
    ///
    ///
    /// # Safety
    ///
    /// Iki mung bisa diarani nalika
    /// - Irisan kasebut dipérang dadi potongan 'unsur N` (aka `self.len() % N == 0`).
    /// - `N != 0`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice: &[char] = &['l', 'o', 'r', 'e', 'm', '!'];
    /// let chunks: &[[char; 1]] =
    ///     // SAFETY: potongan 1-unsur ora duwe sisa
    ///     unsafe { slice.as_chunks_unchecked() };
    /// assert_eq!(chunks, &[['l'], ['o'], ['r'], ['e'], ['m'], ['!']]);
    /// let chunks: &[[char; 3]] =
    ///     // SAFETY: Panjang irisan (6) yaiku pirang-pirang 3
    ///     unsafe { slice.as_chunks_unchecked() };
    /// assert_eq!(chunks, &[['l', 'o', 'r'], ['e', 'm', '!']]);
    ///
    /// // Iki bakal ora sehat:
    /// // ayo cuwilan: &[[_;5]]= slice.as_chunks_unchecked()//Dawane irisan dudu pirang-pirang potongan 5 ayo:&[[_;0]]= slice.as_chunks_unchecked()//Potongan dawa nul ora diidini
    /////
    /// ```
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub unsafe fn as_chunks_unchecked<const N: usize>(&self) -> &[[T; N]] {
        debug_assert_ne!(N, 0);
        debug_assert_eq!(self.len() % N, 0);
        let new_len =
            // SAFETY: precondition Kita persis apa perlu kanggo nelpon iki
            unsafe { crate::intrinsics::exact_div(self.len(), N) };
        // SAFETY: Kita irisan irisan `new_len * N` elemen menyang
        // irisan `new_len` akeh elemen `N` potongan.
        unsafe { from_raw_parts(self.as_ptr().cast(), new_len) }
    }

    /// Pamisahan ing irisan menyang irisan: susunan N`-unsur, miwiti ing awal saka irisan, lan irisan seko karo dawa strictly kurang saka `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics yen `N` yaiku 0. Priksa iki kemungkinan bakal diganti dadi kesalahan wektu kompilasi sadurunge metode iki stabil.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let (chunks, remainder) = slice.as_chunks();
    /// assert_eq!(chunks, &[['l', 'o'], ['r', 'e']]);
    /// assert_eq!(remainder, &['m']);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_chunks<const N: usize>(&self) -> (&[[T; N]], &[T]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (multiple_of_n, remainder) = self.split_at(len * N);
        // SAFETY: Kita wis gupuh nol, lan njamin kanthi konstruksi
        // dawane langganan kasebut yaiku pirang-pirang N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked() };
        (array_slice, remainder)
    }

    /// Pamisahan ing irisan menyang irisan: susunan N`-unsur, miwiti ing mburi irisan, lan irisan seko karo dawa strictly kurang saka `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics yen `N` yaiku 0. Priksa iki kemungkinan bakal diganti dadi kesalahan wektu kompilasi sadurunge metode iki stabil.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let (remainder, chunks) = slice.as_rchunks();
    /// assert_eq!(remainder, &['l']);
    /// assert_eq!(chunks, &[['o', 'r'], ['e', 'm']]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_rchunks<const N: usize>(&self) -> (&[T], &[[T; N]]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (remainder, multiple_of_n) = self.split_at(self.len() - len * N);
        // SAFETY: Kita wis gupuh nol, lan njamin kanthi konstruksi
        // dawane langganan kasebut yaiku pirang-pirang N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked() };
        (remainder, array_slice)
    }

    /// Ngasilake lan iterator liwat unsur `N` saka irisan ing wektu, miwiti ing awal saka irisan.
    ///
    /// Ing tulisan sing referensi Uploaded lan ora tumpang tindih.
    /// Yen `N` ora dibagi dawa saka irisan, banjur munggah pungkasan kanggo unsur `N-1` bakal dilirwakaké lan bisa njupuk saka fungsi `remainder` saka iterator ing.
    ///
    ///
    /// Cara iki padha karo padha karo generik [`chunks_exact`].
    ///
    /// # Panics
    ///
    /// Panics yen `N` yaiku 0. Priksa iki kemungkinan bakal diganti dadi kesalahan wektu kompilasi sadurunge metode iki stabil.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.array_chunks();
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['m']);
    /// ```
    ///
    /// [`chunks_exact`]: slice::chunks_exact
    ///
    ///
    #[unstable(feature = "array_chunks", issue = "74985")]
    #[inline]
    pub fn array_chunks<const N: usize>(&self) -> ArrayChunks<'_, T, N> {
        assert_ne!(N, 0);
        ArrayChunks::new(self)
    }

    /// Misah irisan dadi irisan susunan unsur-unsur `N`, kanthi asumsi ora ana sisa.
    ///
    ///
    /// # Safety
    ///
    /// Iki mung bisa diarani nalika
    /// - Irisan kasebut dipérang dadi potongan 'unsur N` (aka `self.len() % N == 0`).
    /// - `N != 0`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice: &mut [char] = &mut ['l', 'o', 'r', 'e', 'm', '!'];
    /// let chunks: &mut [[char; 1]] =
    ///     // SAFETY: potongan 1-unsur ora duwe sisa
    ///     unsafe { slice.as_chunks_unchecked_mut() };
    /// chunks[0] = ['L'];
    /// assert_eq!(chunks, &[['L'], ['o'], ['r'], ['e'], ['m'], ['!']]);
    /// let chunks: &mut [[char; 3]] =
    ///     // SAFETY: Panjang irisan (6) yaiku pirang-pirang 3
    ///     unsafe { slice.as_chunks_unchecked_mut() };
    /// chunks[1] = ['a', 'x', '?'];
    /// assert_eq!(slice, &['L', 'o', 'r', 'a', 'x', '?']);
    ///
    /// // Iki bakal ora sehat:
    /// // ayo cuwilan: &[[_;5]]= slice.as_chunks_unchecked_mut()//Dawane irisan dudu pirang-pirang potongan 5 ayo:&[[_;0]]= slice.as_chunks_unchecked_mut()//Potongan dawa nul ora diidini
    /////
    /// ```
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub unsafe fn as_chunks_unchecked_mut<const N: usize>(&mut self) -> &mut [[T; N]] {
        debug_assert_ne!(N, 0);
        debug_assert_eq!(self.len() % N, 0);
        let new_len =
            // SAFETY: precondition Kita persis apa perlu kanggo nelpon iki
            unsafe { crate::intrinsics::exact_div(self.len(), N) };
        // SAFETY: Kita irisan irisan `new_len * N` elemen menyang
        // irisan `new_len` akeh elemen `N` potongan.
        unsafe { from_raw_parts_mut(self.as_mut_ptr().cast(), new_len) }
    }

    /// Pamisahan ing irisan menyang irisan: susunan N`-unsur, miwiti ing awal saka irisan, lan irisan seko karo dawa strictly kurang saka `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics yen `N` yaiku 0. Priksa iki kemungkinan bakal diganti dadi kesalahan wektu kompilasi sadurunge metode iki stabil.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// let (chunks, remainder) = v.as_chunks_mut();
    /// remainder[0] = 9;
    /// for chunk in chunks {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 9]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_chunks_mut<const N: usize>(&mut self) -> (&mut [[T; N]], &mut [T]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (multiple_of_n, remainder) = self.split_at_mut(len * N);
        // SAFETY: Kita wis gupuh nol, lan njamin kanthi konstruksi
        // dawane langganan kasebut yaiku pirang-pirang N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked_mut() };
        (array_slice, remainder)
    }

    /// Pamisahan ing irisan menyang irisan: susunan N`-unsur, miwiti ing mburi irisan, lan irisan seko karo dawa strictly kurang saka `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics yen `N` yaiku 0. Priksa iki kemungkinan bakal diganti dadi kesalahan wektu kompilasi sadurunge metode iki stabil.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// let (remainder, chunks) = v.as_rchunks_mut();
    /// remainder[0] = 9;
    /// for chunk in chunks {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[9, 1, 1, 2, 2]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_rchunks_mut<const N: usize>(&mut self) -> (&mut [T], &mut [[T; N]]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (remainder, multiple_of_n) = self.split_at_mut(self.len() - len * N);
        // SAFETY: Kita wis gupuh nol, lan njamin kanthi konstruksi
        // dawane langganan kasebut yaiku pirang-pirang N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked_mut() };
        (remainder, array_slice)
    }

    /// Ngasilake lan iterator liwat unsur `N` saka irisan ing wektu, miwiti ing awal saka irisan.
    ///
    /// Potongan minangka referensi larik sing bisa diowahi lan ora tumpang tindih.
    /// Yen `N` ora dibagi dawa saka irisan, banjur munggah pungkasan kanggo unsur `N-1` bakal dilirwakaké lan bisa njupuk saka fungsi `into_remainder` saka iterator ing.
    ///
    ///
    /// Cara iki padha karo padha karo generik [`chunks_exact_mut`].
    ///
    /// # Panics
    ///
    /// Panics yen `N` yaiku 0. Priksa iki kemungkinan bakal diganti dadi kesalahan wektu kompilasi sadurunge metode iki stabil.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.array_chunks_mut() {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 0]);
    /// ```
    ///
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    ///
    ///
    #[unstable(feature = "array_chunks", issue = "74985")]
    #[inline]
    pub fn array_chunks_mut<const N: usize>(&mut self) -> ArrayChunksMut<'_, T, N> {
        assert_ne!(N, 0);
        ArrayChunksMut::new(self)
    }

    /// Ngasilake iterator kanthi overlap windows elemen `N` saka irisan, diwiwiti ing wiwitan irisan.
    ///
    ///
    /// Iki padha karo umum generik [`windows`].
    ///
    /// Yen `N` iku luwih saka ukuran saka irisan, iku bakal ngasilake ora windows.
    ///
    /// # Panics
    ///
    /// Panics yen `N` yaiku 0.
    /// Priksa iki bisa uga diganti kesalahan wektu kompilasi sadurunge metode iki dadi stabil.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_windows)]
    /// let slice = [0, 1, 2, 3];
    /// let mut iter = slice.array_windows();
    /// assert_eq!(iter.next().unwrap(), &[0, 1]);
    /// assert_eq!(iter.next().unwrap(), &[1, 2]);
    /// assert_eq!(iter.next().unwrap(), &[2, 3]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`windows`]: slice::windows
    #[unstable(feature = "array_windows", issue = "75027")]
    #[inline]
    pub fn array_windows<const N: usize>(&self) -> ArrayWindows<'_, T, N> {
        assert_ne!(N, 0);
        ArrayWindows::new(self)
    }

    /// Ngasilake iterator liwat elemen `chunk_size` irisan sekaligus, diwiwiti ing pungkasan irisan.
    ///
    /// Ing tulisan sing irisan-irisan lan ora tumpang tindih.Yen `chunk_size` ora dibagi dawa saka irisan, banjur cuwilan pungkasan ora duwe dawa `chunk_size`.
    ///
    /// Waca [`rchunks_exact`] kanggo varian saka iterator iki sing ngasilake tulisan saka tansah persis unsur `chunk_size`, lan [`chunks`] kanggo iterator padha nanging miwiti ing awal saka irisan.
    ///
    ///
    /// # Panics
    ///
    /// Panics yen `chunk_size` 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.rchunks(2);
    /// assert_eq!(iter.next().unwrap(), &['e', 'm']);
    /// assert_eq!(iter.next().unwrap(), &['o', 'r']);
    /// assert_eq!(iter.next().unwrap(), &['l']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`rchunks_exact`]: slice::rchunks_exact
    /// [`chunks`]: slice::chunks
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks(&self, chunk_size: usize) -> RChunks<'_, T> {
        assert!(chunk_size != 0);
        RChunks::new(self, chunk_size)
    }

    /// Ngasilake iterator liwat elemen `chunk_size` irisan sekaligus, diwiwiti ing pungkasan irisan.
    ///
    /// Potongan minangka irisan sing bisa diowahi, lan ora tumpang tindih.Yen `chunk_size` ora dibagi dawa irisan, mula potongan pungkasan ora duwe dawa `chunk_size`.
    ///
    /// Deleng [`rchunks_exact_mut`] kanggo varian iterator iki sing ngasilake potongan elemen `chunk_size` sing persis persis, lan [`chunks_mut`] kanggo iterator sing padha nanging diwiwiti ing wiwitan irisan.
    ///
    ///
    /// # Panics
    ///
    /// Panics yen `chunk_size` 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.rchunks_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[3, 2, 2, 1, 1]);
    /// ```
    ///
    /// [`rchunks_exact_mut`]: slice::rchunks_exact_mut
    /// [`chunks_mut`]: slice::chunks_mut
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_mut(&mut self, chunk_size: usize) -> RChunksMut<'_, T> {
        assert!(chunk_size != 0);
        RChunksMut::new(self, chunk_size)
    }

    /// Ngasilake iterator liwat elemen `chunk_size` irisan sekaligus, diwiwiti ing pungkasan irisan.
    ///
    /// Potongan kasebut irisan lan ora tumpang tindih.
    /// Yen `chunk_size` ora mbagi dawa irisan, mula unsur pungkasan nganti `chunk_size-1` bakal disingkirake lan bisa dijupuk saka fungsi `remainder` saka iterator kasebut.
    ///
    /// Amarga saben cuwilan gadhah persis unsur `chunk_size`, compiler sing asring bisa ngoptimalake kode asil luwih saka ing cilik saka [`chunks`].
    ///
    /// Waca [`rchunks`] kanggo varian saka iterator iki sing uga ngasilake seko minangka cuwilan cilik, lan [`chunks_exact`] kanggo iterator padha nanging miwiti ing awal saka irisan.
    ///
    ///
    /// # Panics
    ///
    /// Panics yen `chunk_size` 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.rchunks_exact(2);
    /// assert_eq!(iter.next().unwrap(), &['e', 'm']);
    /// assert_eq!(iter.next().unwrap(), &['o', 'r']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['l']);
    /// ```
    ///
    /// [`chunks`]: slice::chunks
    /// [`rchunks`]: slice::rchunks
    /// [`chunks_exact`]: slice::chunks_exact
    ///
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_exact(&self, chunk_size: usize) -> RChunksExact<'_, T> {
        assert!(chunk_size != 0);
        RChunksExact::new(self, chunk_size)
    }

    /// Ngasilake iterator liwat elemen `chunk_size` irisan sekaligus, diwiwiti ing pungkasan irisan.
    ///
    /// Potongan minangka irisan sing bisa diowahi, lan ora tumpang tindih.
    /// Yen `chunk_size` ora dibagi dawa saka irisan, banjur munggah pungkasan kanggo unsur `chunk_size-1` bakal dilirwakaké lan bisa njupuk saka fungsi `into_remainder` saka iterator ing.
    ///
    /// Amarga saben potongan duwe elemen `chunk_size` sing tepat, compiler asring bisa ngoptimalake kode sing diasilake luwih apik tinimbang ing [`chunks_mut`].
    ///
    /// Waca [`rchunks_mut`] kanggo varian saka iterator iki sing uga ngasilake seko minangka cuwilan cilik, lan [`chunks_exact_mut`] kanggo iterator padha nanging miwiti ing awal saka irisan.
    ///
    ///
    /// # Panics
    ///
    /// Panics yen `chunk_size` 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.rchunks_exact_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[0, 2, 2, 1, 1]);
    /// ```
    ///
    /// [`chunks_mut`]: slice::chunks_mut
    /// [`rchunks_mut`]: slice::rchunks_mut
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_exact_mut(&mut self, chunk_size: usize) -> RChunksExactMut<'_, T> {
        assert!(chunk_size != 0);
        RChunksExactMut::new(self, chunk_size)
    }

    /// Ngasilake iterator liwat irisan sing ngasilake elemen sing ora tumpang tindih nggunakake predikat kanggo misahake.
    ///
    /// Predikat kasebut diarani loro elemen sing ngetutake awake dhewe, tegese predikat kasebut diarani `slice[0]` lan `slice[1]` banjur ing `slice[1]` lan `slice[2]` lan liya-liyane.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &[1, 1, 1, 3, 3, 2, 2, 2];
    ///
    /// let mut iter = slice.group_by(|a, b| a == b);
    ///
    /// assert_eq!(iter.next(), Some(&[1, 1, 1][..]));
    /// assert_eq!(iter.next(), Some(&[3, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 2, 2][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Cara iki bisa digunakake kanggo ngekstrak langgan sing diurutake:
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &[1, 1, 2, 3, 2, 3, 2, 3, 4];
    ///
    /// let mut iter = slice.group_by(|a, b| a <= b);
    ///
    /// assert_eq!(iter.next(), Some(&[1, 1, 2, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 3, 4][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_group_by", issue = "80552")]
    #[inline]
    pub fn group_by<F>(&self, pred: F) -> GroupBy<'_, T, F>
    where
        F: FnMut(&T, &T) -> bool,
    {
        GroupBy::new(self, pred)
    }

    /// Ngasilake iterator liwat irisan sing ngasilake elemen sing bisa ditrapake sing ora tumpang tindih nggunakake predikat kanggo misahake.
    ///
    /// Predikat kasebut diarani loro elemen sing ngetutake awake dhewe, tegese predikat kasebut diarani `slice[0]` lan `slice[1]` banjur ing `slice[1]` lan `slice[2]` lan liya-liyane.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &mut [1, 1, 1, 3, 3, 2, 2, 2];
    ///
    /// let mut iter = slice.group_by_mut(|a, b| a == b);
    ///
    /// assert_eq!(iter.next(), Some(&mut [1, 1, 1][..]));
    /// assert_eq!(iter.next(), Some(&mut [3, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 2, 2][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Cara iki bisa digunakake kanggo ngekstrak langgan sing diurutake:
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &mut [1, 1, 2, 3, 2, 3, 2, 3, 4];
    ///
    /// let mut iter = slice.group_by_mut(|a, b| a <= b);
    ///
    /// assert_eq!(iter.next(), Some(&mut [1, 1, 2, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 3, 4][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_group_by", issue = "80552")]
    #[inline]
    pub fn group_by_mut<F>(&mut self, pred: F) -> GroupByMut<'_, T, F>
    where
        F: FnMut(&T, &T) -> bool,
    {
        GroupByMut::new(self, pred)
    }

    /// Dibagi siji irisan dadi loro ing indeks.
    ///
    /// Sing pertama ngemot kabeh indeks saka `[0, mid)` (ora kalebu indeks `mid` dhewe) lan sing nomer loro bakal ngemot kabeh indeks saka `[mid, len)` (ora kalebu indeks `len` dhewe).
    ///
    ///
    /// # Panics
    ///
    /// Panics yen `mid > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [1, 2, 3, 4, 5, 6];
    ///
    /// {
    ///    let (left, right) = v.split_at(0);
    ///    assert_eq!(left, []);
    ///    assert_eq!(right, [1, 2, 3, 4, 5, 6]);
    /// }
    ///
    /// {
    ///     let (left, right) = v.split_at(2);
    ///     assert_eq!(left, [1, 2]);
    ///     assert_eq!(right, [3, 4, 5, 6]);
    /// }
    ///
    /// {
    ///     let (left, right) = v.split_at(6);
    ///     assert_eq!(left, [1, 2, 3, 4, 5, 6]);
    ///     assert_eq!(right, []);
    /// }
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_at(&self, mid: usize) -> (&[T], &[T]) {
        assert!(mid <= self.len());
        // SAFETY: `[ptr; mid]` lan `[mid; len]` ana ing `self`, yaiku
        // ngisi syarat `from_raw_parts_mut`.
        unsafe { self.split_at_unchecked(mid) }
    }

    /// Dibagi siji irisan sing bisa diganti dadi loro ing indeks.
    ///
    /// Sing pertama ngemot kabeh indeks saka `[0, mid)` (ora kalebu indeks `mid` dhewe) lan sing nomer loro bakal ngemot kabeh indeks saka `[mid, len)` (ora kalebu indeks `len` dhewe).
    ///
    ///
    /// # Panics
    ///
    /// Panics yen `mid > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [1, 0, 3, 0, 5, 6];
    /// let (left, right) = v.split_at_mut(2);
    /// assert_eq!(left, [1, 0]);
    /// assert_eq!(right, [3, 0, 5, 6]);
    /// left[1] = 2;
    /// right[1] = 4;
    /// assert_eq!(v, [1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_at_mut(&mut self, mid: usize) -> (&mut [T], &mut [T]) {
        assert!(mid <= self.len());
        // SAFETY: `[ptr; mid]` lan `[mid; len]` ana ing `self`, yaiku
        // ngisi syarat `from_raw_parts_mut`.
        unsafe { self.split_at_mut_unchecked(mid) }
    }

    /// Divides irisan siji dadi loro ing indeks, tanpa mengkono wates pamriksa.
    ///
    /// Sing pertama ngemot kabeh indeks saka `[0, mid)` (ora kalebu indeks `mid` dhewe) lan sing nomer loro bakal ngemot kabeh indeks saka `[mid, len)` (ora kalebu indeks `len` dhewe).
    ///
    ///
    /// Kanggo alternatif sing aman, deleng [`split_at`].
    ///
    /// # Safety
    ///
    /// Nelpon metode iki kanthi indeks njaba wates * *[prilaku sing durung ditemtokake] * sanajan referensi sing diasilake ora digunakake.Panelpon kudu mesthekake yen `0 <= mid <= self.len()`.
    ///
    /// [`split_at`]: slice::split_at
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```compile_fail
    /// #![feature(slice_split_at_unchecked)]
    ///
    /// let v = [1, 2, 3, 4, 5, 6];
    ///
    /// unsafe {
    ///    let (left, right) = v.split_at_unchecked(0);
    ///    assert_eq!(left, []);
    ///    assert_eq!(right, [1, 2, 3, 4, 5, 6]);
    /// }
    ///
    /// unsafe {
    ///     let (left, right) = v.split_at_unchecked(2);
    ///     assert_eq!(left, [1, 2]);
    ///     assert_eq!(right, [3, 4, 5, 6]);
    /// }
    ///
    /// unsafe {
    ///     let (left, right) = v.split_at_unchecked(6);
    ///     assert_eq!(left, [1, 2, 3, 4, 5, 6]);
    ///     assert_eq!(right, []);
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "slice_split_at_unchecked", reason = "new API", issue = "76014")]
    #[inline]
    unsafe fn split_at_unchecked(&self, mid: usize) -> (&[T], &[T]) {
        // SAFETY: panelpon kudu mriksa `0 <= mid <= self.len()` kasebut
        unsafe { (self.get_unchecked(..mid), self.get_unchecked(mid..)) }
    }

    /// Dibagi siji irisan sing bisa diowahi dadi loro ing indeks, tanpa mriksa wates.
    ///
    /// Sing pertama ngemot kabeh indeks saka `[0, mid)` (ora kalebu indeks `mid` dhewe) lan sing nomer loro bakal ngemot kabeh indeks saka `[mid, len)` (ora kalebu indeks `len` dhewe).
    ///
    ///
    /// Kanggo alternatif sing aman, deleng [`split_at_mut`].
    ///
    /// # Safety
    ///
    /// Nelpon metode iki kanthi indeks njaba wates * *[prilaku sing durung ditemtokake] * sanajan referensi sing diasilake ora digunakake.Panelpon kudu mesthekake yen `0 <= mid <= self.len()`.
    ///
    /// [`split_at_mut`]: slice::split_at_mut
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```compile_fail
    /// #![feature(slice_split_at_unchecked)]
    ///
    /// let mut v = [1, 0, 3, 0, 5, 6];
    /// // scoped to restrict the lifetime of the borrows
    /// unsafe {
    ///     let (left, right) = v.split_at_mut_unchecked(2);
    ///     assert_eq!(left, [1, 0]);
    ///     assert_eq!(right, [3, 0, 5, 6]);
    ///     left[1] = 2;
    ///     right[1] = 4;
    /// }
    /// assert_eq!(v, [1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "slice_split_at_unchecked", reason = "new API", issue = "76014")]
    #[inline]
    unsafe fn split_at_mut_unchecked(&mut self, mid: usize) -> (&mut [T], &mut [T]) {
        let len = self.len();
        let ptr = self.as_mut_ptr();

        // SAFETY: panelpon kudu mriksa `0 <= mid <= self.len()` kasebut.
        //
        // `[ptr; mid]` lan `[mid; len]` ora tumpang tindih, mula bali referensi sing bisa diowahi ora apa-apa.
        //
        unsafe { (from_raw_parts_mut(ptr, mid), from_raw_parts_mut(ptr.add(mid), len - mid)) }
    }

    /// Ngasilake iterator liwat langganan sing dipisahake karo unsur sing cocog karo `pred`.
    /// Unsur sing dicocogake ora ana ing lengganan.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [10, 40, 33, 20];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Yen elemen pertama dicocogake, irisan kosong bakal dadi item pertama sing dibalekake karo iterator.
    /// Kajaba iku, yen elemen pungkasan ing irisan dicocogake, irisan kosong bakal dadi item pungkasan sing dikembalikan karo iterator:
    ///
    ///
    /// ```
    /// let slice = [10, 40, 33];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40]);
    /// assert_eq!(iter.next().unwrap(), &[]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Yen loro unsur dicocogaké sing wewatesan, irisan kosong bakal saiki antarane wong-wong mau:
    ///
    /// ```
    /// let slice = [10, 6, 33, 20];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10]);
    /// assert_eq!(iter.next().unwrap(), &[]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split<F>(&self, pred: F) -> Split<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        Split::new(self, pred)
    }

    /// Ngasilake lan iterator liwat subslices mutable dipisahake dening unsur sing cocog `pred`.
    /// Unsur sing dicocogake ora ana ing lengganan.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.split_mut(|num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(v, [1, 40, 30, 1, 60, 1]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_mut<F>(&mut self, pred: F) -> SplitMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitMut::new(self, pred)
    }

    /// Ngasilake iterator liwat langganan sing dipisahake karo unsur sing cocog karo `pred`.
    /// Unsur sing dicocogake ana ing pungkasan subslice sadurunge minangka terminator.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [10, 40, 33, 20];
    /// let mut iter = slice.split_inclusive(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40, 33]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Yen elemen irisan pungkasan dicocogake, elemen kasebut bakal dianggep dadi terminator irisan sadurunge.
    ///
    /// Irisan kasebut bakal dadi item pungkasan sing dikembalikan karo pengulangan.
    ///
    /// ```
    /// let slice = [3, 10, 40, 33];
    /// let mut iter = slice.split_inclusive(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[3]);
    /// assert_eq!(iter.next().unwrap(), &[10, 40, 33]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive<F>(&self, pred: F) -> SplitInclusive<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitInclusive::new(self, pred)
    }

    /// Ngasilake lan iterator liwat subslices mutable dipisahake dening unsur sing cocog `pred`.
    /// Unsur sing dicocogake ana ing subslice sadurunge minangka terminator.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.split_inclusive_mut(|num| *num % 3 == 0) {
    ///     let terminator_idx = group.len()-1;
    ///     group[terminator_idx] = 1;
    /// }
    /// assert_eq!(v, [10, 40, 1, 20, 1, 1]);
    /// ```
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive_mut<F>(&mut self, pred: F) -> SplitInclusiveMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitInclusiveMut::new(self, pred)
    }

    /// Ngasilake lan iterator liwat subslices dipisahake dening unsur sing cocog `pred`, miwiti ing mburi irisan lan apa mundur.
    /// Unsur sing dicocogake ora ana ing lengganan.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [11, 22, 33, 0, 44, 55];
    /// let mut iter = slice.rsplit(|num| *num == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[44, 55]);
    /// assert_eq!(iter.next().unwrap(), &[11, 22, 33]);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Karo `split()`, yen unsur pisanan utawa pungkasan dicocogaké, irisan kosong bakal pisanan (utawa pungkasan) item bali dening iterator ing.
    ///
    ///
    /// ```
    /// let v = &[0, 1, 1, 2, 3, 5, 8];
    /// let mut it = v.rsplit(|n| *n % 2 == 0);
    /// assert_eq!(it.next().unwrap(), &[]);
    /// assert_eq!(it.next().unwrap(), &[3, 5]);
    /// assert_eq!(it.next().unwrap(), &[1, 1]);
    /// assert_eq!(it.next().unwrap(), &[]);
    /// assert_eq!(it.next(), None);
    /// ```
    ///
    #[stable(feature = "slice_rsplit", since = "1.27.0")]
    #[inline]
    pub fn rsplit<F>(&self, pred: F) -> RSplit<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplit::new(self, pred)
    }

    /// Ngasilake lan iterator liwat subslices mutable dipisahake dening unsur sing cocog `pred`, miwiti ing mburi irisan lan mundur apa.
    /// Unsur sing dicocogake ora ana ing lengganan.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [100, 400, 300, 200, 600, 500];
    ///
    /// let mut count = 0;
    /// for group in v.rsplit_mut(|num| *num % 3 == 0) {
    ///     count += 1;
    ///     group[0] = count;
    /// }
    /// assert_eq!(v, [3, 400, 300, 2, 600, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "slice_rsplit", since = "1.27.0")]
    #[inline]
    pub fn rsplit_mut<F>(&mut self, pred: F) -> RSplitMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitMut::new(self, pred)
    }

    /// Ngasilake iterator liwat langganan sing dipisahake karo elemen sing cocog karo `pred`, diwatesi bali ing paling akeh item `n`.
    /// Unsur sing dicocogake ora ana ing lengganan.
    ///
    /// Unsur pungkasan sing bali, yen ana, bakal ngemot sisa potongan.
    ///
    /// # Examples
    ///
    /// Print irisan pamisah sapisan dening nomer dipara 3 (IE, `[10, 40]`, `[20, 60, 50]`):
    ///
    /// ```
    /// let v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.splitn(2, |num| *num % 3 == 0) {
    ///     println!("{:?}", group);
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn<F>(&self, n: usize, pred: F) -> SplitN<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitN::new(self.split(pred), n)
    }

    /// Ngasilake iterator liwat langganan sing dipisahake karo elemen sing cocog karo `pred`, diwatesi bali ing paling akeh item `n`.
    /// Unsur sing dicocogake ora ana ing lengganan.
    ///
    /// Unsur pungkasan sing bali, yen ana, bakal ngemot sisa potongan.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.splitn_mut(2, |num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(v, [1, 40, 30, 1, 60, 50]);
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn_mut<F>(&mut self, n: usize, pred: F) -> SplitNMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitNMut::new(self.split_mut(pred), n)
    }

    /// Ngasilake iterator liwat langganan sing dipisahake karo elemen sing cocog karo `pred` winates kanggo ngasilake paling akeh item `n`.
    /// Iki diwiwiti ing pungkasan irisan lan bisa mundur.
    /// Unsur sing dicocogake ora ana ing lengganan.
    ///
    /// Unsur pungkasan sing bali, yen ana, bakal ngemot sisa potongan.
    ///
    /// # Examples
    ///
    /// Cetak potongan irisan sapisan, diwiwiti saka pungkasan, kanthi nomer sing bisa dipisahake karo 3 (yaiku, `[50]`, `[10, 40, 30, 20]`):
    ///
    /// ```
    /// let v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.rsplitn(2, |num| *num % 3 == 0) {
    ///     println!("{:?}", group);
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn<F>(&self, n: usize, pred: F) -> RSplitN<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitN::new(self.rsplit(pred), n)
    }

    /// Ngasilake iterator liwat langganan sing dipisahake karo elemen sing cocog karo `pred` winates kanggo ngasilake paling akeh item `n`.
    /// Iki diwiwiti ing pungkasan irisan lan bisa mundur.
    /// Unsur sing dicocogake ora ana ing lengganan.
    ///
    /// Unsur pungkasan sing bali, yen ana, bakal ngemot sisa potongan.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in s.rsplitn_mut(2, |num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(s, [1, 40, 30, 20, 60, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn_mut<F>(&mut self, n: usize, pred: F) -> RSplitNMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitNMut::new(self.rsplit_mut(pred), n)
    }

    /// Ngasilake `true` yen irisan ngemot elemen kanthi nilai sing diwenehake.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.contains(&30));
    /// assert!(!v.contains(&50));
    /// ```
    ///
    /// Yen sampeyan ora duwe `&T`, nanging mung `&U` kayata `T: Borrow<U>` (kayata
    /// `Senar: Nyilih<str>`), sampeyan bisa nggunakake `iter().any`:
    ///
    /// ```
    /// let v = [String::from("hello"), String::from("world")]; // irisan `String`
    /// assert!(v.iter().any(|e| e == "hello")); // nelusuri nganggo `&str`
    /// assert!(!v.iter().any(|e| e == "hi"));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn contains(&self, x: &T) -> bool
    where
        T: PartialEq,
    {
        cmp::SliceContains::slice_contains(x, self)
    }

    /// Ngasilake `true` yen `needle` minangka prefiksasi irisan kasebut.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.starts_with(&[10]));
    /// assert!(v.starts_with(&[10, 40]));
    /// assert!(!v.starts_with(&[50]));
    /// assert!(!v.starts_with(&[10, 50]));
    /// ```
    ///
    /// Tansah ngasilake `true` yen `needle` minangka irisan kosong:
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert!(v.starts_with(&[]));
    /// let v: &[u8] = &[];
    /// assert!(v.starts_with(&[]));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn starts_with(&self, needle: &[T]) -> bool
    where
        T: PartialEq,
    {
        let n = needle.len();
        self.len() >= n && needle == &self[..n]
    }

    /// Ngasilake `true` yen `needle` minangka seselan irisan.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.ends_with(&[30]));
    /// assert!(v.ends_with(&[40, 30]));
    /// assert!(!v.ends_with(&[50]));
    /// assert!(!v.ends_with(&[50, 30]));
    /// ```
    ///
    /// Tansah ngasilake `true` yen `needle` minangka irisan kosong:
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert!(v.ends_with(&[]));
    /// let v: &[u8] = &[];
    /// assert!(v.ends_with(&[]));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ends_with(&self, needle: &[T]) -> bool
    where
        T: PartialEq,
    {
        let (m, n) = (self.len(), needle.len());
        m >= n && needle == &self[m - n..]
    }

    /// Ngasilake subslice karo ater-ater dibusak.
    ///
    /// Yen irisan diwiwiti karo `prefix`, baleni langganan sawise prefiks, dibungkus `Some`.
    /// Yen `prefix` kosong, mung ngasilake irisan asli.
    ///
    /// Yen irisan ora diwiwiti karo `prefix`, ngasilake `None`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert_eq!(v.strip_prefix(&[10]), Some(&[40, 30][..]));
    /// assert_eq!(v.strip_prefix(&[10, 40]), Some(&[30][..]));
    /// assert_eq!(v.strip_prefix(&[50]), None);
    /// assert_eq!(v.strip_prefix(&[10, 50]), None);
    ///
    /// let prefix : &str = "he";
    /// assert_eq!(b"hello".strip_prefix(prefix.as_bytes()),
    ///            Some(b"llo".as_ref()));
    /// ```
    #[must_use = "returns the subslice without modifying the original"]
    #[stable(feature = "slice_strip", since = "1.51.0")]
    pub fn strip_prefix<P: SlicePattern<Item = T> + ?Sized>(&self, prefix: &P) -> Option<&[T]>
    where
        T: PartialEq,
    {
        // Fungsi iki kudu nulis maneh yen lan kapan SlicePattern dadi luwih canggih.
        let prefix = prefix.as_slice();
        let n = prefix.len();
        if n <= self.len() {
            let (head, tail) = self.split_at(n);
            if head == prefix {
                return Some(tail);
            }
        }
        None
    }

    /// Ngasilake subslice kanthi seselan sing dicopot.
    ///
    /// Yen irisan ends karo `suffix`, ngasilake subslice sadurunge seselan, kebungkus ing `Some`.
    /// Yen `suffix` kosong, cukup bali irisan asli.
    ///
    /// Yen irisan ora diakhiri karo `suffix`, ngasilake `None`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert_eq!(v.strip_suffix(&[30]), Some(&[10, 40][..]));
    /// assert_eq!(v.strip_suffix(&[40, 30]), Some(&[10][..]));
    /// assert_eq!(v.strip_suffix(&[50]), None);
    /// assert_eq!(v.strip_suffix(&[50, 30]), None);
    /// ```
    #[must_use = "returns the subslice without modifying the original"]
    #[stable(feature = "slice_strip", since = "1.51.0")]
    pub fn strip_suffix<P: SlicePattern<Item = T> + ?Sized>(&self, suffix: &P) -> Option<&[T]>
    where
        T: PartialEq,
    {
        // Fungsi iki kudu nulis maneh yen lan kapan SlicePattern dadi luwih canggih.
        let suffix = suffix.as_slice();
        let (len, n) = (self.len(), suffix.len());
        if n <= len {
            let (head, tail) = self.split_at(len - n);
            if tail == suffix {
                return Some(head);
            }
        }
        None
    }

    /// Binary nggoleki irisan sing diurutake iki kanggo elemen sing diwenehake.
    ///
    /// Yen regane ditemokake, [`Result::Ok`] bakal dikembalikan, ngemot indeks unsur sing cocog.
    /// Yen ana pirang-pirang pertandingan, mula salah siji saka match bisa dikembalikan.
    /// Yen regane ora ditemokake, [`Result::Err`] bakal dikembalikan, ngemot indeks ing endi elemen sing cocog bisa dilebokake nalika njaga urutan sing diurutake.
    ///
    ///
    /// Deleng uga [`binary_search_by`], [`binary_search_by_key`], lan [`partition_point`].
    ///
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// Nggoleki seri papat elemen.
    /// Sing pertama ditemokake, kanthi posisi sing ditemtokake kanthi unik;sing nomer loro lan nomer telu ora ditemokake;nomer papat bisa cocog karo posisi apa wae ing `[1, 4]`.
    ///
    /// ```
    /// let s = [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    ///
    /// assert_eq!(s.binary_search(&13),  Ok(9));
    /// assert_eq!(s.binary_search(&4),   Err(7));
    /// assert_eq!(s.binary_search(&100), Err(13));
    /// let r = s.binary_search(&1);
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    /// Yen sampeyan pengin nglebokake item menyang vector diurutake, nalika ngramut dhaftar urutan:
    ///
    /// ```
    /// let mut s = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    /// let num = 42;
    /// let idx = s.binary_search(&num).unwrap_or_else(|x| x);
    /// s.insert(idx, num);
    /// assert_eq!(s, [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 42, 55]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn binary_search(&self, x: &T) -> Result<usize, usize>
    where
        T: Ord,
    {
        self.binary_search_by(|p| p.cmp(x))
    }

    /// searches binar iki diurutake irisan karo fungsi comparator.
    ///
    /// Fungsi comparator kudu ngleksanakake supaya konsisten karo dhaftar urutan saka irisan ndasari, bali lan kode supaya nuduhake apa pitakonan sawijining `Less`, `Equal` utawa `Greater` target dikarepake.
    ///
    ///
    /// Yen regane ditemokake, [`Result::Ok`] bakal dikembalikan, ngemot indeks unsur sing cocog.Yen ana pirang-pirang pertandingan, mula salah siji saka match bisa dikembalikan.
    /// Yen regane ora ditemokake, [`Result::Err`] bakal dikembalikan, ngemot indeks ing endi elemen sing cocog bisa dilebokake nalika njaga urutan sing diurutake.
    ///
    /// Deleng uga [`binary_search`], [`binary_search_by_key`], lan [`partition_point`].
    ///
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// Nggoleki seri papat elemen.Sing pertama ditemokake, kanthi posisi sing ditemtokake kanthi unik;sing nomer loro lan nomer telu ora ditemokake;nomer papat bisa cocog karo posisi apa wae ing `[1, 4]`.
    ///
    /// ```
    /// let s = [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    ///
    /// let seek = 13;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Ok(9));
    /// let seek = 4;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Err(7));
    /// let seek = 100;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Err(13));
    /// let seek = 1;
    /// let r = s.binary_search_by(|probe| probe.cmp(&seek));
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn binary_search_by<'a, F>(&'a self, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> Ordering,
    {
        let mut size = self.len();
        let mut left = 0;
        let mut right = size;
        while left < right {
            let mid = left + size / 2;

            // SAFETY: telpon digawe aman dening invariants ing ngisor iki:
            // - `mid >= 0`
            // - `mid < size`: `mid` diwatesi dening `[left; right)` kaiket.
            let cmp = f(unsafe { self.get_unchecked(mid) });

            // Alesan kenapa nggunakake aliran kontrol if/else lan ora cocog yaiku amarga match match mbandhingake maneh operasi, sing sensitif parfum.
            //
            // Iki x86 asm kanggo u8: https://rust.godbolt.org/z/8Y8Pra.
            if cmp == Less {
                left = mid + 1;
            } else if cmp == Greater {
                right = mid;
            } else {
                return Ok(mid);
            }

            size = right - left;
        }
        Err(left)
    }

    /// Binary nggoleki irisan sing diurutake iki kanthi fungsi ekstraksi kunci.
    ///
    /// Nompo sing irisan wis miturut tombol, kanggo Kayata karo [`sort_by_key`] nggunakake fungsi extraction tombol padha.
    ///
    /// Yen regane ditemokake, [`Result::Ok`] bakal dikembalikan, ngemot indeks unsur sing cocog.
    /// Yen ana pirang-pirang pertandingan, mula salah siji saka match bisa dikembalikan.
    /// Yen regane ora ditemokake, [`Result::Err`] bakal dikembalikan, ngemot indeks ing endi elemen sing cocog bisa dilebokake nalika njaga urutan sing diurutake.
    ///
    ///
    /// Deleng uga [`binary_search`], [`binary_search_by`], lan [`partition_point`].
    ///
    /// [`sort_by_key`]: slice::sort_by_key
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// Nggoleki seri papat elemen ing irisan pasangan sing diurutake miturut unsur nomer loro.
    /// Sing pertama ditemokake, kanthi posisi sing ditemtokake kanthi unik;sing nomer loro lan nomer telu ora ditemokake;nomer papat bisa cocog karo posisi apa wae ing `[1, 4]`.
    ///
    /// ```
    /// let s = [(0, 0), (2, 1), (4, 1), (5, 1), (3, 1),
    ///          (1, 2), (2, 3), (4, 5), (5, 8), (3, 13),
    ///          (1, 21), (2, 34), (4, 55)];
    ///
    /// assert_eq!(s.binary_search_by_key(&13, |&(a, b)| b),  Ok(9));
    /// assert_eq!(s.binary_search_by_key(&4, |&(a, b)| b),   Err(7));
    /// assert_eq!(s.binary_search_by_key(&100, |&(a, b)| b), Err(13));
    /// let r = s.binary_search_by_key(&1, |&(a, b)| b);
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    ///
    ///
    ///
    // Lint rustdoc::broken_intra_doc_links diijini amarga `slice::sort_by_key` ana ing crate `alloc`, lan kaya ngono durung ana nalika nggawe `core`.
    //
    // link menyang hilir crate: #74481.Amarga primitif mung didokumentasikan ing libstd (#73423), iki ora nate nyebabake link sing rusak ditindakake.
    //
    #[cfg_attr(not(bootstrap), allow(rustdoc::broken_intra_doc_links))]
    #[cfg_attr(bootstrap, allow(broken_intra_doc_links))]
    #[stable(feature = "slice_binary_search_by_key", since = "1.10.0")]
    #[inline]
    pub fn binary_search_by_key<'a, B, F>(&'a self, b: &B, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> B,
        B: Ord,
    {
        self.binary_search_by(|k| f(k).cmp(b))
    }

    /// Urut irisan, nanging bisa uga ora njaga urutan unsur sing padha.
    ///
    /// Urut ora stabil (yaiku, bisa nyusun ulang unsur sing padha), ing papan (yaiku, ora dialokasikan), lan *O*(*n*\*log(* n*)) kasus paling ala.
    ///
    /// # Implementasi saiki
    ///
    /// Algoritma saiki adhedhasar [pattern-defeating quicksort][pdqsort] dening Orson Peters, sing nggabungake kasus rata-rata quicksort acak kanthi kasus paling cepet ing heapsort, nalika entuk wektu linier ing irisan kanthi pola tartamtu.
    /// Nggunakake sawetara acak kanggo ngindhari kasus sing degenerasi, nanging kanthi seed tetep bisa nyedhiyakake prilaku deterministik.
    ///
    /// Biasane luwih cepet tinimbang ngurutake sing stabil, kajaba ing sawetara kasus khusus, kayata, irisan kasebut kalebu sawetara urutan urut gabungan.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5, 4, 1, -3, 2];
    ///
    /// v.sort_unstable();
    /// assert!(v == [-5, -3, 1, 2, 4]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable(&mut self)
    where
        T: Ord,
    {
        sort::quicksort(self, |a, b| a.lt(b));
    }

    /// Ngurutake irisan kanthi fungsi komparator, nanging bisa uga ora njaga urutan unsur sing padha.
    ///
    /// Urut ora stabil (yaiku, bisa nyusun ulang unsur sing padha), ing papan (yaiku, ora dialokasikan), lan *O*(*n*\*log(* n*)) kasus paling ala.
    ///
    /// Fungsi komparator kudu netepake urutan total kanggo elemen ing irisan.Yen pesenan ora total, urutan unsur kasebut ora ditemtokake.Pesenan minangka urutan total yen (kanggo kabeh `a`, `b` lan `c`):
    ///
    /// * total lan antisimetri: persis salah siji `a < b`, `a == b` utawa `a > b` bener, lan
    /// * transitif, `a < b` lan `b < c` tegese `a < c`.Sampeyan kudu padha nganggo `==` lan `>`.
    ///
    /// Contone, nalika [`f64`] ora ngetrapake [`Ord`] amarga `NaN != NaN`, kita bisa nggunakake `partial_cmp` minangka fungsi sortir nalika ngerti irisan kasebut ora ngemot `NaN`.
    ///
    /// ```
    /// let mut floats = [5f64, 4.0, 1.0, 3.0, 2.0];
    /// floats.sort_unstable_by(|a, b| a.partial_cmp(b).unwrap());
    /// assert_eq!(floats, [1.0, 2.0, 3.0, 4.0, 5.0]);
    /// ```
    ///
    /// # Implementasi saiki
    ///
    /// Algoritma saiki adhedhasar [pattern-defeating quicksort][pdqsort] dening Orson Peters, sing nggabungake kasus rata-rata quicksort acak kanthi kasus paling cepet ing heapsort, nalika entuk wektu linier ing irisan kanthi pola tartamtu.
    /// Nggunakake sawetara acak kanggo ngindhari kasus sing degenerasi, nanging kanthi seed tetep bisa nyedhiyakake prilaku deterministik.
    ///
    /// Biasane luwih cepet tinimbang ngurutake sing stabil, kajaba ing sawetara kasus khusus, kayata, irisan kasebut kalebu sawetara urutan urut gabungan.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [5, 4, 1, 3, 2];
    /// v.sort_unstable_by(|a, b| a.cmp(b));
    /// assert!(v == [1, 2, 3, 4, 5]);
    ///
    /// // ngurutake mbalikke
    /// v.sort_unstable_by(|a, b| b.cmp(a));
    /// assert!(v == [5, 4, 3, 2, 1]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable_by<F>(&mut self, mut compare: F)
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        sort::quicksort(self, |a, b| compare(a, b) == Ordering::Less);
    }

    /// Limo irisan karo fungsi extraction tombol, nanging uga ora ngreksa urutan unsur kang padha.
    ///
    /// Urut punika boten stabil (IE, bisa diurutake maneh unsur padha), ing-Panggonan (IE, ora nyedhiakke), lan *O*(m\* * n *\* log(*n*)) awon-cilik, ngendi fungsi tombol *O*(*m*).
    ///
    /// # Implementasi saiki
    ///
    /// Algoritma saiki adhedhasar [pattern-defeating quicksort][pdqsort] dening Orson Peters, sing nggabungake kasus rata-rata quicksort acak kanthi kasus paling cepet ing heapsort, nalika entuk wektu linier ing irisan kanthi pola tartamtu.
    /// Nggunakake sawetara acak kanggo ngindhari kasus sing degenerasi, nanging kanthi seed tetep bisa nyedhiyakake prilaku deterministik.
    ///
    /// Amarga strategi panggilan utamane, [`sort_unstable_by_key`](#method.sort_unstable_by_key) bisa uga luwih alon tinimbang [`sort_by_cached_key`](#method.sort_by_cached_key) ing kasus yen fungsi kunci larang.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// v.sort_unstable_by_key(|k| k.abs());
    /// assert!(v == [1, 2, -3, 4, -5]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable_by_key<K, F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        sort::quicksort(self, |a, b| f(a).lt(&f(b)));
    }

    /// Urut maneh irisan supaya elemen ing `index` ana ing posisi pungkasan.
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use the select_nth_unstable() instead")]
    #[inline]
    pub fn partition_at_index(&mut self, index: usize) -> (&mut [T], &mut T, &mut [T])
    where
        T: Ord,
    {
        self.select_nth_unstable(index)
    }

    /// Urut maneh irisan kanthi fungsi komparator supaya unsur ing `index` ana ing posisi sing pungkasan.
    ///
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use select_nth_unstable_by() instead")]
    #[inline]
    pub fn partition_at_index_by<F>(
        &mut self,
        index: usize,
        compare: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        self.select_nth_unstable_by(index, compare)
    }

    /// Urut maneh irisan nganggo fungsi ekstraksi tombol saengga elemen ing `index` ana ing posisi pungkasan.
    ///
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use the select_nth_unstable_by_key() instead")]
    #[inline]
    pub fn partition_at_index_by_key<K, F>(
        &mut self,
        index: usize,
        f: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        self.select_nth_unstable_by_key(index, f)
    }

    /// Urut maneh irisan supaya elemen ing `index` ana ing posisi pungkasan.
    ///
    /// Panyusunan ulang iki nduweni properti tambahan yen nilai apa wae ing posisi `i < index` bakal kurang saka utawa padha karo nilai apa wae ing posisi `j > index`.
    /// Kajaba iku, nyusun ulang iki ora stabil (yaiku
    /// sawetara unsur sing padha bisa pungkasan ing posisi `index`), ing papan (yaiku
    /// ora menehi dana), lan *O*(*n*) kasus paling ala.
    /// Fungsi iki uga/dikenal minangka "kth element" ing perpustakaan liyane.
    /// Ngasilake triplet saka angka ing ngisor iki: kabeh elemen kurang saka siji ing indeks sing diwenehake, nilai ing indeks sing diwenehake, lan kabeh elemen sing luwih gedhe tinimbang sing ana ing indeks sing diwenehake.
    ///
    ///
    /// # Implementasi saiki
    ///
    /// Algoritma saiki adhedhasar bagean pilihan sing cepet ing algoritma quicksort sing padha digunakake kanggo [`sort_unstable`].
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics nalika `index >= len()`, tegese mesthi panics ing irisan kosong.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // Temokake rata-rata
    /// v.select_nth_unstable(2);
    ///
    /// // Kita mung dijamin irisan bakal dadi salah siji saka ing ngisor iki, adhedhasar cara ngurutake babagan indeks sing ditemtokake.
    /////
    /// assert!(v == [-3, -5, 1, 2, 4] ||
    ///         v == [-5, -3, 1, 2, 4] ||
    ///         v == [-3, -5, 1, 4, 2] ||
    ///         v == [-5, -3, 1, 4, 2]);
    /// ```
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable(&mut self, index: usize) -> (&mut [T], &mut T, &mut [T])
    where
        T: Ord,
    {
        let mut f = |a: &T, b: &T| a.lt(b);
        sort::partition_at_index(self, index, &mut f)
    }

    /// Urut maneh irisan kanthi fungsi komparator supaya unsur ing `index` ana ing posisi sing pungkasan.
    ///
    /// reordering iki nduweni sifat tambahan sing migunani babar pisan ing posisi `i < index` bakal kurang saka utawa witjaksono kanggo nilai sembarang ing posisi `j > index` nggunakake fungsi comparator.
    /// Tambahan, reordering iki ora bakal tentrem (IE nomer unsur witjaksono bisa mungkasi munggah ing posisi `index`), ing-Panggonan (IE ora nyedhiakke), lan *O*(*n*) awon-cilik.
    /// Fungsi iki uga dikenal minangka "kth element" ing perpustakaan liyane.
    /// Ngasilake triplet saka angka ing ngisor iki: kabeh elemen kurang saka siji ing indeks sing diwenehake, nilai ing indeks sing diwenehake, lan kabeh elemen sing luwih gedhe tinimbang sing ana ing indeks sing diwenehake, nggunakake fungsi komparator sing diwenehake.
    ///
    ///
    /// # Implementasi saiki
    ///
    /// Algoritma saiki adhedhasar bagean pilihan sing cepet ing algoritma quicksort sing padha digunakake kanggo [`sort_unstable`].
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics nalika `index >= len()`, tegese mesthi panics ing irisan kosong.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // Temokake rata-rata kaya irisan diurutake kanthi mudhun.
    /// v.select_nth_unstable_by(2, |a, b| b.cmp(a));
    ///
    /// // Kita mung dijamin irisan bakal dadi salah siji saka ing ngisor iki, adhedhasar cara ngurutake babagan indeks sing ditemtokake.
    /////
    /// assert!(v == [2, 4, 1, -5, -3] ||
    ///         v == [2, 4, 1, -3, -5] ||
    ///         v == [4, 2, 1, -5, -3] ||
    ///         v == [4, 2, 1, -3, -5]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable_by<F>(
        &mut self,
        index: usize,
        mut compare: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        let mut f = |a: &T, b: &T| compare(a, b) == Less;
        sort::partition_at_index(self, index, &mut f)
    }

    /// Urut maneh irisan nganggo fungsi ekstraksi tombol saengga elemen ing `index` ana ing posisi pungkasan.
    ///
    /// Panyusunan ulang iki nduweni properti tambahan yen nilai apa wae ing posisi `i < index` bakal kurang saka utawa padha karo nilai apa wae ing posisi `j > index` nggunakake fungsi ekstraksi utama.
    /// Tambahan, reordering iki ora bakal tentrem (IE nomer unsur witjaksono bisa mungkasi munggah ing posisi `index`), ing-Panggonan (IE ora nyedhiakke), lan *O*(*n*) awon-cilik.
    /// Fungsi iki uga dikenal minangka "kth element" ing perpustakaan liyane.
    /// Iku ngasilake triplet angka ing ngisor iki: kabeh unsur kurang saka siji ing indeks diwenehi, nilai ing indeks diwenehi, lan kabeh unsur luwih saka siji ing indeks diwenehi, nggunakake fungsi extraction tombol kasedhiya.
    ///
    ///
    /// # Implementasi saiki
    ///
    /// Algoritma saiki adhedhasar bagean pilihan sing cepet ing algoritma quicksort sing padha digunakake kanggo [`sort_unstable`].
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics nalika `index >= len()`, tegese mesthi panics ing irisan kosong.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // Baliake median kaya yen susunan diurutake miturut nilai absolut.
    /// v.select_nth_unstable_by_key(2, |a| a.abs());
    ///
    /// // Kita mung dijamin irisan bakal dadi salah siji saka ing ngisor iki, adhedhasar cara ngurutake babagan indeks sing ditemtokake.
    /////
    /// assert!(v == [1, 2, -3, 4, -5] ||
    ///         v == [1, 2, -3, -5, 4] ||
    ///         v == [2, 1, -3, 4, -5] ||
    ///         v == [2, 1, -3, -5, 4]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable_by_key<K, F>(
        &mut self,
        index: usize,
        mut f: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        let mut g = |a: &T, b: &T| f(a).lt(&f(b));
        sort::partition_at_index(self, index, &mut g)
    }

    /// Pindhah kabeh elemen sing terus-terusan ing pungkasan irisan miturut implementasi [`PartialEq`] trait.
    ///
    ///
    /// Baliake rong irisan.Pisanan ora ngemot unsur kaping bola-bali.
    /// Sing nomer loro ngemot kabeh duplikat tanpa urutan sing ditemtokake.
    ///
    /// Yen irisan diurutake, irisan sing bali pisanan ora ana duplikat.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = [1, 2, 2, 3, 3, 2, 1, 1];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup();
    ///
    /// assert_eq!(dedup, [1, 2, 3, 2, 1]);
    /// assert_eq!(duplicates, [2, 3, 1]);
    /// ```
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup(&mut self) -> (&mut [T], &mut [T])
    where
        T: PartialEq,
    {
        self.partition_dedup_by(|a, b| a == b)
    }

    /// Gerakane kabeh nanging pisanan unsur consecutive kanggo mburi irisan muasake hubungan podo diwenehi.
    ///
    /// Baliake rong irisan.Pisanan ora ngemot unsur kaping bola-bali.
    /// Sing nomer loro ngemot kabeh duplikat tanpa urutan sing ditemtokake.
    ///
    /// Fungsi `same_bucket` liwati referensi kanggo rong elemen saka irisan lan kudu nemtokake manawa unsur kasebut mbandhingake padha.
    /// Unsur kasebut dilewati kanthi urutan sing beda saka urutane ing irisan, dadi yen `same_bucket(a, b)` ngasilake `true`, `a` bakal dipindhah ing mburi irisan.
    ///
    ///
    /// Yen irisan diurutake, irisan sing bali pisanan ora ana duplikat.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = ["foo", "Foo", "BAZ", "Bar", "bar", "baz", "BAZ"];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup_by(|a, b| a.eq_ignore_ascii_case(b));
    ///
    /// assert_eq!(dedup, ["foo", "BAZ", "Bar", "baz"]);
    /// assert_eq!(duplicates, ["bar", "Foo", "BAZ"]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup_by<F>(&mut self, mut same_bucket: F) -> (&mut [T], &mut [T])
    where
        F: FnMut(&mut T, &mut T) -> bool,
    {
        // Senajan kita duwe referensi mutable kanggo `self`, kita ora bisa nggawe *kasepakatan* owahan.The `same_bucket` telpon bisa panic, supaya kita kudu mesthekake yen irisan punika ing negara bener ing kaping.
        //
        // Cara sing ditangani yaiku nggunakake swap;kita iterate liwat kabeh unsur, ngganteni kita lunga supaya ing mburi unsur kita pengin supaya ana ing ngarep, lan sing kita pengin nolak ing mburi.
        // Banjur bisa dipotong irisan.
        // Operasi iki isih `O(n)`.
        //
        // Contone: Kita miwiti ing negara iki, ing endi `r` makili "sabanjure
        // maca "lan `w` nggantosi" next_write`.
        //
        //           r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //           w
        //
        // Mbandingaken self[r] marang poto [w-1], iki ora duplikat, supaya kita pertukaran self[r] lan self[w] (ora efek minangka r==w) lan banjur tambahan loro r lan w, nilaraken kita karo:
        //
        //               r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //               w
        //
        // Mbandhingake self[r] karo awake [w-1], regane iki minangka duplikat, mula kita nambah `r` nanging ora ana sing owah:
        //
        //                   r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //               w
        //
        // Mbandingaken self[r] marang poto [w-1], iki ora duplikat, supaya pertukaran self[r] lan self[w] lan advance r lan w:
        //
        //                       r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 2 | 1 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //                   w
        //
        // Ora duplikat, baleni:
        //
        //                           r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 2 | 3 | 1 | 3 |
        //     +---+---+---+---+---+---+
        //                       w
        //
        // Dobel, irisan advance r. End.Pisah ing w.
        //
        //
        //
        //
        //
        //
        //
        //

        let len = self.len();
        if len <= 1 {
            return (self, &mut []);
        }

        let ptr = self.as_mut_ptr();
        let mut next_read: usize = 1;
        let mut next_write: usize = 1;

        // SAFETY: kawontenan `while` njamin `next_read` lan `next_write`
        // kurang saka `len`, saengga ana ing `self`.
        // `prev_ptr_write` TCTerms kanggo siji unsur sadurunge `ptr_write`, nanging `next_write` diwiwiti ing 1, supaya `prev_ptr_write` tau kurang saka 0 lan nang irisan.
        // Iki nerak syarat kanggo dereferencing `ptr_read`, `prev_ptr_write` lan `ptr_write`, lan kanggo nggunakake `ptr.add(next_read)`, `ptr.add(next_write - 1)` lan `prev_ptr_write.offset(1)`.
        //
        //
        // `next_write` uga ditambah paling ora sapisan saben daur ulang paling gedhe tegese ora ana elemen sing dilewati nalika kudu diganti.
        //
        // `ptr_read` lan `prev_ptr_write` ora nate nuduhake elemen sing padha.Iki dibutuhake kanggo `&mut *ptr_read`, `&mut* prev_ptr_write` dadi aman.
        // panjelasan mung sing `next_read >= next_write` tansah bener, mangkono `next_read > next_write - 1` banget.
        //
        //
        //
        //
        //
        unsafe {
            // Aja mriksa wates kanthi nggunakake petunjuk mentah.
            while next_read < len {
                let ptr_read = ptr.add(next_read);
                let prev_ptr_write = ptr.add(next_write - 1);
                if !same_bucket(&mut *ptr_read, &mut *prev_ptr_write) {
                    if next_read != next_write {
                        let ptr_write = prev_ptr_write.offset(1);
                        mem::swap(&mut *ptr_read, &mut *ptr_write);
                    }
                    next_write += 1;
                }
                next_read += 1;
            }
        }

        self.split_at_mut(next_write)
    }

    /// Pindhah kabeh, nanging elemen pertama sing pungkasan ing irisan irisan sing bisa diselehake menyang tombol sing padha.
    ///
    ///
    /// Baliake rong irisan.Pisanan ora ngemot unsur kaping bola-bali.
    /// Sing nomer loro ngemot kabeh duplikat tanpa urutan sing ditemtokake.
    ///
    /// Yen irisan diurutake, irisan sing bali pisanan ora ana duplikat.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = [10, 20, 21, 30, 30, 20, 11, 13];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup_by_key(|i| *i / 10);
    ///
    /// assert_eq!(dedup, [10, 20, 30, 20, 11]);
    /// assert_eq!(duplicates, [21, 30, 13]);
    /// ```
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup_by_key<K, F>(&mut self, mut key: F) -> (&mut [T], &mut [T])
    where
        F: FnMut(&mut T) -> K,
        K: PartialEq,
    {
        self.partition_dedup_by(|a, b| key(a) == key(b))
    }

    /// Rotates irisan ing-Panggonan kuwi yen unsur `mid` pisanan saka irisan pamindhahan kanggo mburi nalika unsur `self.len() - mid` pungkasan pindhah menyang ngarep.
    /// Sawise nelpon `rotate_left`, unsur sadurunge ing indeks `mid` bakal dadi unsur pisanan ing irisan.
    ///
    /// # Panics
    ///
    /// Fungsi iki bakal panic yen `mid` luwih gedhe tinimbang dawa irisan.Elinga yen `mid == self.len()` nindakake _not_ panic lan minangka rotasi tanpa op.
    ///
    /// # Complexity
    ///
    /// Butuh linear (ing wektu `self.len()`).
    ///
    /// # Examples
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a.rotate_left(2);
    /// assert_eq!(a, ['c', 'd', 'e', 'f', 'a', 'b']);
    /// ```
    ///
    /// Muterake subslice:
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a[1..5].rotate_left(1);
    /// assert_eq!(a, ['a', 'c', 'd', 'e', 'b', 'f']);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_rotate", since = "1.26.0")]
    pub fn rotate_left(&mut self, mid: usize) {
        assert!(mid <= self.len());
        let k = self.len() - mid;
        let p = self.as_mut_ptr();

        // SAFETY: Range `[p.add(mid) - mid, p.add(mid) + k)` sepele
        // bener kanggo maca lan nulis, minangka dibutuhaké déning `ptr_rotate`.
        unsafe {
            rotate::ptr_rotate(mid, p.add(mid), k);
        }
    }

    /// Rotates irisan ing-Panggonan kuwi yen unsur `self.len() - k` pisanan saka irisan pamindhahan kanggo mburi nalika unsur `k` pungkasan pindhah menyang ngarep.
    /// Sawise nelpon `rotate_right`, unsur sadurunge ing indeks `self.len() - k` bakal dadi unsur pisanan ing irisan.
    ///
    /// # Panics
    ///
    /// Fungsi iki bakal panic yen `k` luwih gedhe tinimbang dawa irisan.Elinga yen `k == self.len()` ora _not_ panic lan rotasi ora-op.
    ///
    /// # Complexity
    ///
    /// Butuh linear (ing wektu `self.len()`).
    ///
    /// # Examples
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a.rotate_right(2);
    /// assert_eq!(a, ['e', 'f', 'a', 'b', 'c', 'd']);
    /// ```
    ///
    /// Puter subslice:
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a[1..5].rotate_right(1);
    /// assert_eq!(a, ['a', 'e', 'b', 'c', 'd', 'f']);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_rotate", since = "1.26.0")]
    pub fn rotate_right(&mut self, k: usize) {
        assert!(k <= self.len());
        let mid = self.len() - k;
        let p = self.as_mut_ptr();

        // SAFETY: Range `[p.add(mid) - mid, p.add(mid) + k)` sepele
        // bener kanggo maca lan nulis, minangka dibutuhaké déning `ptr_rotate`.
        unsafe {
            rotate::ptr_rotate(mid, p.add(mid), k);
        }
    }

    /// Isi `self` kanthi unsur kanthi kloning `value`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut buf = vec![0; 10];
    /// buf.fill(1);
    /// assert_eq!(buf, vec![1; 10]);
    /// ```
    #[doc(alias = "memset")]
    #[stable(feature = "slice_fill", since = "1.50.0")]
    pub fn fill(&mut self, value: T)
    where
        T: Clone,
    {
        specialize::SpecFill::spec_fill(self, value);
    }

    /// Isi `self` karo elemen sing bali kanthi nelpon penutupan kanthi bola-bali.
    ///
    /// Cara iki nggunakake penutupan kanggo nggawe nilai anyar.Yen luwih seneng [`Clone`] nilai tartamtu, gunakake [`fill`].
    /// Yen sampeyan pengin nggunakake [`Default`] trait kanggo ngasilake angka, sampeyan bisa ngliwati [`Default::default`] minangka argumen.
    ///
    ///
    /// [`fill`]: slice::fill
    ///
    /// # Examples
    ///
    /// ```
    /// let mut buf = vec![1; 10];
    /// buf.fill_with(Default::default);
    /// assert_eq!(buf, vec![0; 10]);
    /// ```
    ///
    #[doc(alias = "memset")]
    #[stable(feature = "slice_fill_with", since = "1.51.0")]
    pub fn fill_with<F>(&mut self, mut f: F)
    where
        F: FnMut() -> T,
    {
        for el in self {
            *el = f();
        }
    }

    /// Nyalin elemen saka `src` dadi `self`.
    ///
    /// Dawane `src` kudu padha karo `self`.
    ///
    /// Yen `T` nindakake `Copy`, iku bisa dadi luwih performant nggunakake [`copy_from_slice`].
    ///
    /// # Panics
    ///
    /// Fungsi iki bakal panic yen irisan loro kasebut dawane beda.
    ///
    /// # Examples
    ///
    /// Kloning rong elemen saka irisan dadi liyane:
    ///
    /// ```
    /// let src = [1, 2, 3, 4];
    /// let mut dst = [0, 0];
    ///
    /// // Amarga irisan-irisan kudu dawa padha, kita irisan ing irisan sumber saka papat unsur kanggo loro.
    /// // Bakal panic yen ora nindakake iki.
    /////
    /// dst.clone_from_slice(&src[2..]);
    ///
    /// assert_eq!(src, [1, 2, 3, 4]);
    /// assert_eq!(dst, [3, 4]);
    /// ```
    ///
    /// Rust negesake manawa mung bisa ana siji referensi sing ora bisa diowahi kanthi referensi sing ora bisa diowahi kanggo bagean data tartamtu ing ruang lingkup tartamtu.
    /// Amarga iku, nyoba nggunakake `clone_from_slice` ing irisan siji bakal nyebabake gagal nyusun:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// slice[..2].clone_from_slice(&slice[3..]); // compile fail!
    /// ```
    ///
    /// Kanggo ngrampungake, kita bisa nggunakake [`split_at_mut`] kanggo nggawe rong irisan khas saka irisan:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.clone_from_slice(&right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 4, 5]);
    /// ```
    ///
    /// [`copy_from_slice`]: slice::copy_from_slice
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "clone_from_slice", since = "1.7.0")]
    pub fn clone_from_slice(&mut self, src: &[T])
    where
        T: Clone,
    {
        self.spec_clone_from(src);
    }

    /// Nyalin kabeh elemen saka `src` dadi `self`, nggunakake memcpy.
    ///
    /// Dawane `src` kudu padha karo `self`.
    ///
    /// Yen `T` ora ngleksanakake `Copy`, nggunakake [`clone_from_slice`].
    ///
    /// # Panics
    ///
    /// Fungsi iki bakal panic yen irisan loro kasebut dawane beda.
    ///
    /// # Examples
    ///
    /// Nyalin rong elemen saka irisan menyang liyane:
    ///
    /// ```
    /// let src = [1, 2, 3, 4];
    /// let mut dst = [0, 0];
    ///
    /// // Amarga irisan-irisan kudu dawa padha, kita irisan ing irisan sumber saka papat unsur kanggo loro.
    /// // Bakal panic yen ora nindakake iki.
    /////
    /// dst.copy_from_slice(&src[2..]);
    ///
    /// assert_eq!(src, [1, 2, 3, 4]);
    /// assert_eq!(dst, [3, 4]);
    /// ```
    ///
    /// Rust negesake manawa mung bisa ana siji referensi sing ora bisa diowahi kanthi referensi sing ora bisa diowahi kanggo bagean data tartamtu ing ruang lingkup tartamtu.
    /// Amarga iki, nyoba kanggo nggunakake `copy_from_slice` ing irisan siji bakal kasil Gagal ngripta:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// slice[..2].copy_from_slice(&slice[3..]); // compile fail!
    /// ```
    ///
    /// Kanggo ngrampungake, kita bisa nggunakake [`split_at_mut`] kanggo nggawe rong irisan khas saka irisan:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.copy_from_slice(&right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 4, 5]);
    /// ```
    ///
    /// [`clone_from_slice`]: slice::clone_from_slice
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    ///
    #[doc(alias = "memcpy")]
    #[stable(feature = "copy_from_slice", since = "1.9.0")]
    pub fn copy_from_slice(&mut self, src: &[T])
    where
        T: Copy,
    {
        // Jalur kode panic dilebokake menyang fungsi sing adhem supaya ora ngganggu situs telpon.
        //
        #[inline(never)]
        #[cold]
        #[track_caller]
        fn len_mismatch_fail(dst_len: usize, src_len: usize) -> ! {
            panic!(
                "source slice length ({}) does not match destination slice length ({})",
                src_len, dst_len,
            );
        }

        if self.len() != src.len() {
            len_mismatch_fail(self.len(), src.len());
        }

        // SAFETY: `self` bener kanggo elemen `self.len()` miturut definisi, lan `src` bener
        // dicenthang duwe dawane padha.
        // Irisan kasebut ora bisa tumpang tindih amarga referensi sing bisa diowahi eksklusif.
        unsafe {
            ptr::copy_nonoverlapping(src.as_ptr(), self.as_mut_ptr(), self.len());
        }
    }

    /// unsur Salinan saka salah siji bagéan saka irisan kanggo bagean liyane dhewe, nggunakake memmove a.
    ///
    /// `src` yaiku kisaran ing `self` kanggo disalin.
    /// `dest` iku indeks miwiti saka sawetara ing `self` kanggo nyalin kanggo, kang bakal duwe dawa padha `src`.
    /// Rong rentang bisa tumpang tindih.
    /// Pucuk saka rong jajaran kasebut kudu kurang saka utawa padha karo `self.len()`.
    ///
    /// # Panics
    ///
    /// Fungsi iki bakal panic yen salah siji sawetara ngluwihi mburi irisan, utawa yen mburi `src` iku sadurunge wiwitan.
    ///
    ///
    /// # Examples
    ///
    /// Nyalin papat bait ing irisan:
    ///
    /// ```
    /// let mut bytes = *b"Hello, World!";
    ///
    /// bytes.copy_within(1..5, 8);
    ///
    /// assert_eq!(&bytes, b"Hello, Wello!");
    /// ```
    ///
    #[stable(feature = "copy_within", since = "1.37.0")]
    #[track_caller]
    pub fn copy_within<R: RangeBounds<usize>>(&mut self, src: R, dest: usize)
    where
        T: Copy,
    {
        let Range { start: src_start, end: src_end } = slice::range(src, ..self.len());
        let count = src_end - src_start;
        assert!(dest <= self.len() - count, "dest is out of bounds");
        // SAFETY: kahanan kanggo `ptr::copy` kabeh wis dicenthang ing ndhuwur,
        // minangka duwe sing kanggo `ptr::add`.
        unsafe {
            ptr::copy(self.as_ptr().add(src_start), self.as_mut_ptr().add(dest), count);
        }
    }

    /// Tukar kabeh elemen ing `self` karo sing ana ing `other`.
    ///
    /// Dawane `other` kudu padha karo `self`.
    ///
    /// # Panics
    ///
    /// Fungsi iki bakal panic yen irisan loro kasebut dawane beda.
    ///
    /// # Example
    ///
    /// Ngganteni loro unsur tengen irisan-irisan:
    ///
    /// ```
    /// let mut slice1 = [0, 0];
    /// let mut slice2 = [1, 2, 3, 4];
    ///
    /// slice1.swap_with_slice(&mut slice2[2..]);
    ///
    /// assert_eq!(slice1, [3, 4]);
    /// assert_eq!(slice2, [1, 2, 0, 0]);
    /// ```
    ///
    /// Rust negesake manawa mung bisa ana siji referensi sing bisa diowahi kanggo bagean data tartamtu ing ruang lingkup tartamtu.
    ///
    /// Amarga iku, nyoba nggunakake `swap_with_slice` ing irisan siji bakal nyebabake gagal nyusun:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    /// slice[..2].swap_with_slice(&mut slice[3..]); // compile fail!
    /// ```
    ///
    /// Kanggo ngrampungake, kita bisa nggunakake [`split_at_mut`] kanggo nggawe rong irisan sing bisa diowahi kanthi irisan:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.swap_with_slice(&mut right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 1, 2]);
    /// ```
    ///
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    #[stable(feature = "swap_with_slice", since = "1.27.0")]
    pub fn swap_with_slice(&mut self, other: &mut [T]) {
        assert!(self.len() == other.len(), "destination and source slices have different lengths");
        // SAFETY: `self` bener kanggo elemen `self.len()` miturut definisi, lan `src` bener
        // dicenthang duwe dawane padha.
        // Irisan kasebut ora bisa tumpang tindih amarga referensi sing bisa diowahi eksklusif.
        unsafe {
            ptr::swap_nonoverlapping(self.as_mut_ptr(), other.as_mut_ptr(), self.len());
        }
    }

    /// Fungsi kanggo ngetung dawa irisan tengah lan trailing kanggo `align_to{,_mut}`.
    fn align_to_offsets<U>(&self) -> (usize, usize) {
        // Apa sing bakal ditindakake babagan `rest` yaiku ngerteni pirang-pirang `U` sing bisa dilebokake ing nomer paling murah.
        //
        // Lan pinten `T sing dibutuhake kanggo "multiple" kasebut.
        //
        // Coba contone T=u8 U=u16.Banjur kita bisa nyelehake 1 U ing 2 Ts.Sederhana
        // Saiki, coba contone kasus sing ukuran_of: :<T>=16, ukuran_of::<U>=24.</u>
        // Kita bisa nyelehake 2 Kita ing saben 3 Ts ing irisan `rest`.
        // Luwih rumit.
        //
        // Formula kanggo ngetung yaiku:
        //
        // Us= lcm(size_of::<T>, size_of::<U>)/size_of: : <U>Ts= lcm(size_of::<T>, size_of::<U>)/size_of::</u><T>
        //
        // Ditambahi lan disederhanakake:
        //
        // Us=size_of: :<T>/gcd(size_of::<T>, size_of::<U>) Ts=size_of::<U>/gcd(size_of::<T>, size_of::<U>)</u>
        //
        // Untunge amarga kabeh iki dievaluasi terus-terusan ... kinerja ing kene ora masalah!
        #[inline]
        fn gcd(a: usize, b: usize) -> usize {
            use crate::intrinsics;
            // algoritma iteratif stein kang Kawulo kudu nggawe `const fn` iki (lan revert kanggo algoritma rekursif yen kita apa) amarga nggunakake llvm kanggo consteval kabeh iki ... uga, iku ndadekake kula ora adil.
            //
            //

            // SAFETY: `a` lan `b` sing dicenthang dadi angka-nol.
            let (ctz_a, mut ctz_b) = unsafe {
                if a == 0 {
                    return b;
                }
                if b == 0 {
                    return a;
                }
                (intrinsics::cttz_nonzero(a), intrinsics::cttz_nonzero(b))
            };
            let k = ctz_a.min(ctz_b);
            let mut a = a >> ctz_a;
            let mut b = b;
            loop {
                // mbusak kabeh faktor 2 saka b
                b >>= ctz_b;
                if a > b {
                    mem::swap(&mut a, &mut b);
                }
                b = b - a;
                // SAFETY: `b` dicenthang dadi nol.
                unsafe {
                    if b == 0 {
                        break;
                    }
                    ctz_b = intrinsics::cttz_nonzero(b);
                }
            }
            a << k
        }
        let gcd: usize = gcd(mem::size_of::<T>(), mem::size_of::<U>());
        let ts: usize = mem::size_of::<U>() / gcd;
        let us: usize = mem::size_of::<T>() / gcd;

        // Bersenjata karo kawruh iki, kita bisa nemokake cara akeh: U`s kita bisa pas!
        let us_len = self.len() / ts * us;
        // Lan pinten-pinten `T ing irisan sing bakal dilakoni!
        let ts_len = self.len() % ts;
        (us_len, ts_len)
    }

    /// Transmisi irisan menyang irisan jinis liyane, supaya keselarasan jinis dijaga.
    ///
    /// Cara iki pamisahan irisan dadi telung irisan sing beda: awalan, irisan tengah sing cocog kanthi bener kanggo jinis anyar, lan irisan akhiran.
    /// Cara kasebut bisa nggawe irisan tengah paling dawa kanggo jinis lan irisan input tartamtu, nanging mung kinerja algoritma sampeyan sing kudu gumantung, dudu sing bener.
    ///
    /// Dileksanakake kanggo kabeh data input bali minangka prefiks utawa irisan akhiran.
    ///
    /// Cara iki wis ora waé nalika salah siji unsur input `T` utawa output unsur `U` nul-ukuran lan bakal bali ing irisan asli tanpa pisah apa.
    ///
    /// # Safety
    ///
    /// Cara iki ateges `transmute` bab unsur ing irisan tengah bali, supaya kabeh caveats biasanipun ngenani `transmute::<T, U>` uga aplikasi kene.
    ///
    /// # Examples
    ///
    /// Panggunaan dhasar:
    ///
    /// ```
    /// unsafe {
    ///     let bytes: [u8; 7] = [1, 2, 3, 4, 5, 6, 7];
    ///     let (prefix, shorts, suffix) = bytes.align_to::<u16>();
    ///     // less_efficient_algorithm_for_bytes(prefix);
    ///     // more_efficient_algorithm_for_aligned_shorts(shorts);
    ///     // less_efficient_algorithm_for_bytes(suffix);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_align_to", since = "1.30.0")]
    pub unsafe fn align_to<U>(&self) -> (&[T], &[U], &[T]) {
        // Elinga yen umume fungsi iki bakal dievaluasi terus-terusan,
        if mem::size_of::<U>() == 0 || mem::size_of::<T>() == 0 {
            // nangani ZST khusus, yaiku-aja nangani kabeh.
            return (self, &[], &[]);
        }

        // Kaping pisanan, goleki ing titik apa sing bakal dipisahake ing irisan pertama lan kaping 2.
        // Gampang nganggo ptr.align_offset.
        let ptr = self.as_ptr();
        // SAFETY: Deleng cara `align_to_mut` kanggo komentar keamanan rinci.
        let offset = unsafe { crate::ptr::align_offset(ptr, mem::align_of::<U>()) };
        if offset > self.len() {
            (self, &[], &[])
        } else {
            let (left, rest) = self.split_at(offset);
            let (us_len, ts_len) = rest.align_to_offsets::<U>();
            // SAFETY: saiki `rest` temtunipun didadekake siji, supaya `from_raw_parts` ngisor oke,
            // amarga panelpon njamin manawa kita bisa ngirim `T` menyang `U` kanthi aman.
            unsafe {
                (
                    left,
                    from_raw_parts(rest.as_ptr() as *const U, us_len),
                    from_raw_parts(rest.as_ptr().add(rest.len() - ts_len), ts_len),
                )
            }
        }
    }

    /// Transmisi irisan menyang irisan jinis liyane, supaya keselarasan jinis dijaga.
    ///
    /// Cara iki pamisahan irisan dadi telung irisan sing beda: awalan, irisan tengah sing cocog kanthi bener kanggo jinis anyar, lan irisan akhiran.
    /// Cara kasebut bisa nggawe irisan tengah paling dawa kanggo jinis lan irisan input tartamtu, nanging mung kinerja algoritma sampeyan sing kudu gumantung, dudu sing bener.
    ///
    /// Dileksanakake kanggo kabeh data input bali minangka prefiks utawa irisan akhiran.
    ///
    /// Cara iki wis ora waé nalika salah siji unsur input `T` utawa output unsur `U` nul-ukuran lan bakal bali ing irisan asli tanpa pisah apa.
    ///
    /// # Safety
    ///
    /// Cara iki ateges `transmute` bab unsur ing irisan tengah bali, supaya kabeh caveats biasanipun ngenani `transmute::<T, U>` uga aplikasi kene.
    ///
    /// # Examples
    ///
    /// Panggunaan dhasar:
    ///
    /// ```
    /// unsafe {
    ///     let mut bytes: [u8; 7] = [1, 2, 3, 4, 5, 6, 7];
    ///     let (prefix, shorts, suffix) = bytes.align_to_mut::<u16>();
    ///     // less_efficient_algorithm_for_bytes(prefix);
    ///     // more_efficient_algorithm_for_aligned_shorts(shorts);
    ///     // less_efficient_algorithm_for_bytes(suffix);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_align_to", since = "1.30.0")]
    pub unsafe fn align_to_mut<U>(&mut self) -> (&mut [T], &mut [U], &mut [T]) {
        // Elinga yen umume fungsi iki bakal dievaluasi terus-terusan,
        if mem::size_of::<U>() == 0 || mem::size_of::<T>() == 0 {
            // nangani ZST khusus, yaiku-aja nangani kabeh.
            return (self, &mut [], &mut []);
        }

        // Kaping pisanan, goleki ing titik apa sing bakal dipisahake ing irisan pertama lan kaping 2.
        // Gampang nganggo ptr.align_offset.
        let ptr = self.as_ptr();
        // SAFETY: Ing kene, kita bakal nggunakake petunjuk sing cocog kanggo U kanggo
        // cara liyane.Iki ditindakake kanthi menehi petunjuk menyang&[T] kanthi target sing cocog kanggo U.
        // `crate::ptr::align_offset` diarani karo pitunjuk bener didadekake siji lan bener `ptr` (tekané referensi kanggo `self`) lan karo ukuran sing daya saka loro (awit iku asalé saka alignement kanggo U), marem alangan safety.
        //
        //
        //
        //
        let offset = unsafe { crate::ptr::align_offset(ptr, mem::align_of::<U>()) };
        if offset > self.len() {
            (self, &mut [], &mut [])
        } else {
            let (left, rest) = self.split_at_mut(offset);
            let (us_len, ts_len) = rest.align_to_offsets::<U>();
            let rest_len = rest.len();
            let mut_ptr = rest.as_mut_ptr();
            // Kita ora bisa nggunakake `rest` maneh sawise iki, sing bakal invalidate alias sawijining `mut_ptr`!SAFETY: deleng komentar kanggo `align_to`.
            //
            unsafe {
                (
                    left,
                    from_raw_parts_mut(mut_ptr as *mut U, us_len),
                    from_raw_parts_mut(mut_ptr.add(rest_len - ts_len), ts_len),
                )
            }
        }
    }

    /// Kir yen unsur saka irisan iki sing diurutake.
    ///
    /// Sing, kanggo saben unsur `a` lan unsur sawijining ngisor `b`, `a <= b` kudu terus.Yen irisan ngasilake persis nol utawa siji elemen, `true` bakal bali.
    ///
    /// Wigati yen `Self::Item` mung `PartialOrd`, nanging ora `Ord`, definisi ing ndhuwur nggadahi sing fungsi iki ngasilake `false` yen ragam consecutive ora iso dibandhingke.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    /// let empty: [i32; 0] = [];
    ///
    /// assert!([1, 2, 2, 9].is_sorted());
    /// assert!(![1, 3, 2, 4].is_sorted());
    /// assert!([0].is_sorted());
    /// assert!(empty.is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted(&self) -> bool
    where
        T: PartialOrd,
    {
        self.is_sorted_by(|a, b| a.partial_cmp(b))
    }

    /// Kir yen unsur saka irisan iki sing diurutake nggunakake fungsi comparator diwenehi.
    ///
    /// Tinimbang nggunakake `PartialOrd::partial_cmp`, fungsi iki nggunakake fungsi `compare` sing diwenehake kanggo nemtokake urutan rong elemen.
    /// Loro saka, iku padha karo kanggo [`is_sorted`];deleng dokumentasi kanggo informasi luwih lengkap.
    ///
    /// [`is_sorted`]: slice::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted_by<F>(&self, mut compare: F) -> bool
    where
        F: FnMut(&T, &T) -> Option<Ordering>,
    {
        self.iter().is_sorted_by(|a, b| compare(*a, *b))
    }

    /// Priksa manawa unsur irisan iki diurutake nggunakake fungsi ekstraksi tombol sing diwenehake.
    ///
    /// Tinimbang mbandingaken unsur irisan kang langsung, fungsi iki bandingke tombol ing unsur, minangka ditemtokake dening `f`.
    /// Loro saka, iku padha karo kanggo [`is_sorted`];deleng dokumentasi kanggo informasi luwih lengkap.
    ///
    /// [`is_sorted`]: slice::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted_by_key<F, K>(&self, f: F) -> bool
    where
        F: FnMut(&T) -> K,
        K: PartialOrd,
    {
        self.iter().is_sorted_by_key(f)
    }

    /// Ngasilake indeks titik partisi miturut predikat sing diwenehake (indeks unsur pisanan saka partisi nomer loro).
    ///
    /// Irisan kasebut dianggep dibedakake miturut predikat sing diwenehake.
    /// liya sing kabeh unsur sing ngasilake predikat bener ing wiwitan saka irisan lan kabeh unsur sing ngasilake predikat palsu ing mburi.
    ///
    /// Contone, [7, 15, 3, 5, 4, 12, 6] minangka partisi ing predikat x% 2!=0 (kabeh nomer ganjil ana ing wiwitan, sanajan pungkasane).
    ///
    /// Yen irisan iki ora partitioned, hasil iku unspecified lan guna, minangka cara iki performs jenis binar.
    ///
    /// Deleng uga [`binary_search`], [`binary_search_by`], lan [`binary_search_by_key`].
    ///
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [1, 2, 3, 3, 5, 6, 7];
    /// let i = v.partition_point(|&x| x < 5);
    ///
    /// assert_eq!(i, 4);
    /// assert!(v[..i].iter().all(|&x| x < 5));
    /// assert!(v[i..].iter().all(|&x| !(x < 5)));
    /// ```
    ///
    ///
    ///
    #[stable(feature = "partition_point", since = "1.52.0")]
    pub fn partition_point<P>(&self, mut pred: P) -> usize
    where
        P: FnMut(&T) -> bool,
    {
        let mut left = 0;
        let mut right = self.len();

        while left != right {
            let mid = left + (right - left) / 2;
            // SAFETY: Nalika `left < right`, `left <= mid < right`.
            // Mula `left` mesthi saya mundhak lan `right` mesthi mudhun, lan salah sawijine dipilih.Ing kaloro kasus kasebut `left <= right` wareg.Mula yen `left < right` selangkah, `left <= right` wareg ing langkah sabanjure.
            //
            // Mula anggere `left != right`, `0 <= left < right <= len` wareg lan yen kasus iki `0 <= mid < len` wareg uga.
            //
            //
            //
            let value = unsafe { self.get_unchecked(mid) };
            if pred(value) {
                left = mid + 1;
            } else {
                right = mid;
            }
        }

        left
    }
}

trait CloneFromSpec<T> {
    fn spec_clone_from(&mut self, src: &[T]);
}

impl<T> CloneFromSpec<T> for [T]
where
    T: Clone,
{
    default fn spec_clone_from(&mut self, src: &[T]) {
        assert!(self.len() == src.len(), "destination and source slices have different lengths");
        // NOTE: Kita kudu nyoto kanthi eksplisit kanthi dawa sing padha
        // supaya luwih gampang pangoptimal bisa milih mriksa wates.
        // Nanging amarga ora bisa dipercaya, kita uga duwe spesialisasi eksplisit kanggo T: Copy.
        let len = self.len();
        let src = &src[..len];
        for i in 0..len {
            self[i].clone_from(&src[i]);
        }
    }
}

impl<T> CloneFromSpec<T> for [T]
where
    T: Copy,
{
    fn spec_clone_from(&mut self, src: &[T]) {
        self.copy_from_slice(src);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for &[T] {
    /// Nggawe irisan kosong.
    fn default() -> Self {
        &[]
    }
}

#[stable(feature = "mut_slice_default", since = "1.5.0")]
impl<T> Default for &mut [T] {
    /// Nggawe irisan kosong sing bisa diowahi.
    fn default() -> Self {
        &mut []
    }
}

#[unstable(feature = "slice_pattern", reason = "stopgap trait for slice patterns", issue = "56345")]
/// Pola ing irisan, saiki, mung digunakake dening `strip_prefix` lan `strip_suffix`.
/// Ing titik future, kita ngarep-arep nggawe umum `core::str::Pattern` (sing nalika nulis diwatesi dadi `str`) dadi irisan, banjur trait iki bakal diganti utawa dibatalake.
///
pub trait SlicePattern {
    /// Jinis unsur saka irisan kang cocok ing.
    type Item;

    /// Saiki, konsumen `SlicePattern` butuh irisan.
    fn as_slice(&self) -> &[Self::Item];
}

#[stable(feature = "slice_strip", since = "1.51.0")]
impl<T> SlicePattern for [T] {
    type Item = T;

    #[inline]
    fn as_slice(&self) -> &[Self::Item] {
        self
    }
}

#[stable(feature = "slice_strip", since = "1.51.0")]
impl<T, const N: usize> SlicePattern for [T; N] {
    type Item = T;

    #[inline]
    fn as_slice(&self) -> &[Self::Item] {
        self
    }
}