// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// Muter kisaran `[mid-left, mid+right)` saengga elemen ing `mid` dadi elemen pisanan.Kanthi padha, muter elemen `left` ing sisih kiwa utawa elemen `right` ing sisih tengen.
///
/// # Safety
///
/// Rentang sing ditemtokake kudu bener kanggo maca lan nulis.
///
/// # Algorithm
///
/// Algoritma 1 digunakake kanggo nilai `left + right` utawa `T` gedhe.
/// Unsur-unsur kasebut dipindhah menyang posisi pungkasan siji-siji wiwit `mid - left` lan maju kanthi langkah-langkah `right` modulo `left + right`, saengga mung dibutuhake sak sementara.
/// Pungkasane, kita tekan maneh ing `mid - left`.
/// Nanging, yen `gcd(left + right, right)` dudu 1, langkah-langkah ing ndhuwur ngilangi elemen.
/// Contone:
///
/// ```text
/// left = 10, right = 6
/// the `^` indicates an element in its final place
/// 6 7 8 9 10 11 12 13 14 15 . 0 1 2 3 4 5
/// after using one step of the above algorithm (The X will be overwritten at the end of the round,
/// and 12 is stored in a temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 2 3 4 5
///               ^
/// after using another step (now 2 is in the temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///               ^                 ^
/// after the third step (the steps wrap around, and 8 is in the temporary):
/// X 7 2 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///     ^         ^                 ^
/// after 7 more steps, the round ends with the temporary 0 getting put in the X:
/// 0 7 2 9 4 11 6 13 8 15 . 10 1 12 3 14 5
/// ^   ^   ^    ^    ^       ^    ^    ^
/// ```
///
/// Begjanipun, nomer Mlayu liwat unsur antarane unsur dirampungaké tansah witjaksono, supaya kita mung bisa nutup kerugian posisi kita miwiti lan apa liyane babak (nomer total babak punika `gcd(left + right, right)` value).
///
/// Asil pungkasan yaiku kabeh elemen dirampungake sepisan lan mung sepisan.
///
/// Algoritma 2 digunakake yen `left + right` gedhe nanging `min(left, right)` cukup cilik kanggo pas dhateng sanggan tumpukan.
/// Unsur `min(left, right)` disalin menyang buffer, `memmove` ditrapake kanggo liyane, lan sing ana ing buffer dipindhah maneh menyang bolongan ing sisih sing asale.
///
/// Kalkulus sing bisa vectorized outperform ing ndhuwur yen `left + right` dadi cukup gedhe.
/// Algoritma 1 bisa vectorized dening chunking lan Performing akeh babak bebarengan, nanging ana uga sawetara babak ing saben nganti `left + right` banget, lan ing paling awon cilik saka babak siji tansah ana.
/// Nanging, algoritma 3 nggunakake pertukaran berulang unsur `min(left, right)` nganti ana masalah rotasi sing luwih cilik.
///
/// ```text
/// left = 11, right = 4
/// [4 5 6 7 8 9 10 11 12 13 14 . 0 1 2 3]
///                  ^  ^  ^  ^   ^ ^ ^ ^ swapping the right most elements with elements to the left
/// [4 5 6 7 8 9 10 . 0 1 2 3] 11 12 13 14
///        ^ ^ ^  ^   ^ ^ ^ ^ swapping these
/// [4 5 6 . 0 1 2 3] 7 8 9 10 11 12 13 14
/// we cannot swap any more, but a smaller rotation problem is left to solve
/// ```
/// nalika `left < right` pertukaran bisa kedadeyan saka kiwa.
///
///
///
///
///
pub unsafe fn ptr_rotate<T>(mut left: usize, mut mid: *mut T, mut right: usize) {
    type BufType = [usize; 32];
    if mem::size_of::<T>() == 0 {
        return;
    }
    loop {
        // N.B. algoritma ing ngisor iki bisa gagal yen kasus kasebut ora dicenthang
        if (right == 0) || (left == 0) {
            return;
        }
        if (left + right < 24) || (mem::size_of::<T>() > mem::size_of::<[usize; 4]>()) {
            // Algoritma 1 Mikro-teko mikro nuduhake manawa kinerja rata-rata kanggo owah-owahan acak luwih apik nganti udakara `left + right == 32`, nanging kinerja kasus paling ala malah rusak udakara 16 taun.
            // 24 dipilih dadi lapangan tengah.
            // Yen ukuran `T` luwih 4: usize`s, algoritma iki uga outperforms kalkulus liyane.
            //
            //
            let x = unsafe { mid.sub(left) };
            // awal babak pertama
            let mut tmp: T = unsafe { x.read() };
            let mut i = right;
            // `gcd` bisa ditemokake sadurunge kanthi ngitung `gcd(left + right, right)`, nanging luwih cepet nggawe siji puteran sing ngitung gcd minangka efek samping, banjur nindakake bagean liyane
            //
            //
            let mut gcd = right;
            // benchmarks mbukak iku luwih cepet kanggo temporaries pertukaran kabeh cara liwat tinimbang maca siji sapisan sauntara, Nyalin mundur, lan banjur nulis sing sak wentoro ing mburi banget.
            // Iki bisa uga amarga kasunyatan yen ngganti utawa ngganti sementara nggunakake mung siji alamat memori ing daur ulang tinimbang ora kudu ngatur loro.
            //
            //
            loop {
                tmp = unsafe { x.add(i).replace(tmp) };
                // tinimbang incrementing `i` lan banjur mriksa yen njaba wates, kita mriksa yen `i` bakal metu ing wates ing tambahan sabanjuré.
                // Iki ngalangi pembungkus pointer utawa `usize`.
                //
                if i >= left {
                    i -= left;
                    if i == 0 {
                        // pungkasan babak pisanan
                        unsafe { x.write(tmp) };
                        break;
                    }
                    // kondisional iki kudu ana ing kene yen `left + right >= 15`
                    if i < gcd {
                        gcd = i;
                    }
                } else {
                    i += right;
                }
            }
            // rampung potongan kanthi luwih akeh babak
            for start in 1..gcd {
                tmp = unsafe { x.add(start).read() };
                i = start + right;
                loop {
                    tmp = unsafe { x.add(i).replace(tmp) };
                    if i >= left {
                        i -= left;
                        if i == start {
                            unsafe { x.add(start).write(tmp) };
                            break;
                        }
                    } else {
                        i += right;
                    }
                }
            }
            return;
        // `T` dudu jinis ukuran nol, mula luwih becik dibagi miturut ukurane.
        } else if cmp::min(left, right) <= mem::size_of::<BufType>() / mem::size_of::<T>() {
            // Algoritma 2 `[T; 0]` ing kene kanggo mesthekake yen selaras karo T
            //
            let mut rawarray = MaybeUninit::<(BufType, [T; 0])>::uninit();
            let buf = rawarray.as_mut_ptr() as *mut T;
            let dim = unsafe { mid.sub(left).add(right) };
            if left <= right {
                unsafe {
                    ptr::copy_nonoverlapping(mid.sub(left), buf, left);
                    ptr::copy(mid, mid.sub(left), right);
                    ptr::copy_nonoverlapping(buf, dim, left);
                }
            } else {
                unsafe {
                    ptr::copy_nonoverlapping(mid, buf, right);
                    ptr::copy(mid.sub(left), dim, left);
                    ptr::copy_nonoverlapping(buf, mid.sub(left), right);
                }
            }
            return;
        } else if left >= right {
            // Algoritma 3 Ana cara liya kanggo ngganti sing kalebu nemokake pertukaran pungkasan saka algoritma iki, lan pertukaran nggunakake potongan pungkasan tinimbang ngganti potongan sing cedhak kaya algoritma iki, nanging cara iki isih luwih cepet.
            //
            //
            //
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(right), mid, right);
                    mid = mid.sub(right);
                }
                left -= right;
                if left < right {
                    break;
                }
            }
        } else {
            // Algoritma 3, `left < right`
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(left), mid, left);
                    mid = mid.add(left);
                }
                right -= left;
                if right < left {
                    break;
                }
            }
        }
    }
}