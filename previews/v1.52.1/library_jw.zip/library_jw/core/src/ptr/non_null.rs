use crate::cmp::Ordering;
use crate::convert::From;
use crate::fmt;
use crate::hash;
use crate::marker::Unsize;
use crate::mem::{self, MaybeUninit};
use crate::ops::{CoerceUnsized, DispatchFromDyn};
use crate::ptr::Unique;
use crate::slice::{self, SliceIndex};

/// `*mut T` nanging ora nol lan kovarian.
///
/// Iki asring dadi perkara sing bener digunakake nalika mbangun struktur data nggunakake petunjuk mentah, nanging pungkasane luwih mbebayani yen digunakake amarga sifat tambahane.Yen sampeyan ora yakin manawa nggunakake `NonNull<T>`, cukup nganggo `*mut T`!
///
/// Beda karo `*mut T`, pointer kudu mesthi non-nol, sanajan penunjuk ora bisa disuda.Iki supaya enum bisa nggunakake nilai terlarang iki minangka diskriminasi-`Option<NonNull<T>>` ukurane padha karo `* mut T`.
/// Nanging, pointer isih bisa digantung yen ora diresepake.
///
/// Beda karo `*mut T`, `NonNull<T>` dipilih dadi kovarian tinimbang `T`.Iki nggawe panggunaan `NonNull<T>` nalika nggawe jinis kovarian, nanging nyebabake risiko ora sehat yen digunakake ing jinis sing ora kudu kovarian.
/// (Pilihan ngelawan digawe kanggo `*mut T` sanajan teknis unsoundness mung bisa disebabake nelpon fungsi sing ora aman.)
///
/// Covariance bener kanggo abstraksi sing paling aman, kayata `Box`, `Rc`, `Arc`, `Vec`, lan `LinkedList`.Iki kedadeyan amarga nyedhiyakake API umum sing ngetutake aturan normal XOR sing bisa diowahi Rust.
///
/// Yen jinis sampeyan ora bisa kovarian kanthi aman, sampeyan kudu mesthekake ngemot sawetara lapangan tambahan kanggo nyedhiyakake invarian.Asring lapangan iki bakal dadi jinis [`PhantomData`] kaya `PhantomData<Cell<T>>` utawa `PhantomData<&'a mut T>`.
///
/// Elinga yen `NonNull<T>` duwe conto `From` kanggo `&T`.Nanging, iki ora ngowahi kasunyatan sing mutating liwat (pitunjuk asalé saka) referensi sambungan iku prilaku undefined kajaba mutasi ing mengkono nang [`UnsafeCell<T>`].Semono uga nggawe referensi sing bisa diowahi saka referensi sing dituduhake.
///
/// Nalika nggunakake conto `From` iki tanpa `UnsafeCell<T>`, dadi tanggung jawab sampeyan supaya `as_mut` ora bakal ditelpon, lan `as_ptr` ora bakal digunakake kanggo mutasi.
///
/// [`PhantomData`]: crate::marker::PhantomData
/// [`UnsafeCell<T>`]: crate::cell::UnsafeCell
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "nonnull", since = "1.25.0")]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
#[rustc_nonnull_optimization_guaranteed]
pub struct NonNull<T: ?Sized> {
    pointer: *const T,
}

/// `NonNull` pointer dudu `Send` amarga data sing dirujuk bisa dadi alias.
// NB, impl iki ora perlu, nanging ngirim pesen kesalahan sing luwih apik.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Send for NonNull<T> {}

/// `NonNull` pointer dudu `Sync` amarga data sing dirujuk bisa dadi alias.
// NB, impl iki ora perlu, nanging ngirim pesen kesalahan sing luwih apik.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Sync for NonNull<T> {}

impl<T: Sized> NonNull<T> {
    /// Nggawe `NonNull` anyar sing nggantung, nanging selaras kanthi apik.
    ///
    /// Iki migunani kanggo nggawe inisialisasi jinis sing lazim dialokasikan, kaya `Vec::new`.
    ///
    /// Elinga yen nilai penunjuk bisa uga nuduhake pointer sing valid menyang `T`, tegese iki ora bisa digunakake minangka nilai sentinel "not yet initialized".
    /// Jinis-jinis sing kesasar nyedhiyakake kudu nglacak inisialisasi kanthi cara liya.
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_dangling", since = "1.32.0")]
    #[inline]
    pub const fn dangling() -> Self {
        // SAFETY: mem::align_of() ngasilake usize sing nol lan banjur dibuwang
        // menyang * The T.
        // Mula, `ptr` ora batal lan kahanan nelpon new_unchecked() diajeni.
        unsafe {
            let ptr = mem::align_of::<T>() as *mut T;
            NonNull::new_unchecked(ptr)
        }
    }

    /// Ngasilake referensi bareng kanggo nilai kasebut.Beda karo [`as_ref`], iki ora mbutuhake regane kudu diinisialisasi.
    ///
    /// Kanggo pasangan sing bisa diowahi, deleng [`as_uninit_mut`].
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    ///
    /// # Safety
    ///
    /// Nalika nelpon metode iki, sampeyan kudu mesthekake manawa kabeh perkara ing ngisor iki bener:
    ///
    /// * Pointer kudu didadekake siji kanthi bener.
    ///
    /// * Kudu "dereferencable" ing pangertene sing ditemtokake ing [the module documentation].
    ///
    /// * Sampeyan kudu ngetrapake aturan aliasing Rust, amarga umur bali `'a` dipilih kanthi sewenang-wenang lan ora kudu nuduhake umur data sing nyata.
    ///
    ///   Utamane, sajrone urip iki, memori sing nuduhake poin ora kudu diowahi (kajaba ing `UnsafeCell`).
    ///
    /// Iki ditrapake sanajan asil saka metode iki ora digunakake!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref(&self) -> &MaybeUninit<T> {
        // SAFETY: panelpon kudu njamin yen `self` ketemu kabeh
        // syarat kanggo referensi.
        unsafe { &*self.cast().as_ptr() }
    }

    /// Ngasilake referensi unik kanggo nilai kasebut.Beda karo [`as_mut`], iki ora mbutuhake regane kudu diinisialisasi.
    ///
    /// Kanggo mitra sing dituduhake, waca [`as_uninit_ref`].
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    ///
    /// # Safety
    ///
    /// Nalika nelpon metode iki, sampeyan kudu mesthekake manawa kabeh perkara ing ngisor iki bener:
    ///
    /// * Pointer kudu didadekake siji kanthi bener.
    ///
    /// * Kudu "dereferencable" ing pangertene sing ditemtokake ing [the module documentation].
    ///
    /// * Sampeyan kudu ngetrapake aturan aliasing Rust, amarga umur bali `'a` dipilih kanthi sewenang-wenang lan ora kudu nuduhake umur data sing nyata.
    ///
    ///   Utamane, sajrone urip iki, memori sing nuduhake poin ora kudu diakses (diwaca utawa ditulis) liwat pitunjuk liyane.
    ///
    /// Iki ditrapake sanajan asil saka metode iki ora digunakake!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_mut(&mut self) -> &mut MaybeUninit<T> {
        // SAFETY: panelpon kudu njamin yen `self` ketemu kabeh
        // syarat kanggo referensi.
        unsafe { &mut *self.cast().as_ptr() }
    }
}

impl<T: ?Sized> NonNull<T> {
    /// Nggawe `NonNull` anyar.
    ///
    /// # Safety
    ///
    /// `ptr` kudu ora batal.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_new_unchecked", since = "1.32.0")]
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // SAFETY: panelpon kudu njamin yen `ptr` ora batal.
        unsafe { NonNull { pointer: ptr as _ } }
    }

    /// Nggawe `NonNull` anyar yen `ptr` ora batal.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // SAFETY: Penunjuk wis dicenthang lan ora batal
            Some(unsafe { Self::new_unchecked(ptr) })
        } else {
            None
        }
    }

    /// Nindakake fungsi sing padha karo [`std::ptr::from_raw_parts`], kajaba pitunjuk `NonNull` bali, beda karo pitunjuk `*const` mentah.
    ///
    ///
    /// Deleng dokumentasi [`std::ptr::from_raw_parts`] kanggo rincian liyane.
    ///
    /// [`std::ptr::from_raw_parts`]: crate::ptr::from_raw_parts
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn from_raw_parts(
        data_address: NonNull<()>,
        metadata: <T as super::Pointee>::Metadata,
    ) -> NonNull<T> {
        // SAFETY: Asil `ptr::from::raw_parts_mut` ora batal amarga `data_address`.
        unsafe {
            NonNull::new_unchecked(super::from_raw_parts_mut(data_address.as_ptr(), metadata))
        }
    }

    /// Decompose a (might wide) pointer dadi alamat lan komponen metadata.
    ///
    /// pitunjuk bisa mengko direkonstruksi karo [`NonNull::from_raw_parts`].
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (NonNull<()>, <T as super::Pointee>::Metadata) {
        (self.cast(), super::metadata(self.as_ptr()))
    }

    /// Entuk penunjuk `*mut` sing ndasari.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// Ngasilake referensi sambungan Nilai.Yen regane bisa dingerteni, [`as_uninit_ref`] kudu digunakake.
    ///
    /// Kanggo pasangan sing bisa diowahi, deleng [`as_mut`].
    ///
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    /// [`as_mut`]: NonNull::as_mut
    ///
    /// # Safety
    ///
    /// Nalika nelpon metode iki, sampeyan kudu mesthekake manawa kabeh perkara ing ngisor iki bener:
    ///
    /// * Pointer kudu didadekake siji kanthi bener.
    ///
    /// * Kudu "dereferencable" ing pangertene sing ditemtokake ing [the module documentation].
    ///
    /// * Pointer kudu nuduhake conto sing diwiwiti saka `T`.
    ///
    /// * Sampeyan kudu ngetrapake aturan aliasing Rust, amarga umur bali `'a` dipilih kanthi sewenang-wenang lan ora kudu nuduhake umur data sing nyata.
    ///
    ///   Utamane, sajrone urip iki, memori sing nuduhake poin ora kudu diowahi (kajaba ing `UnsafeCell`).
    ///
    /// Iki ditrapake sanajan asil saka metode iki ora digunakake!
    /// (Bagean babagan inisialisasi durung bisa diputusake kanthi lengkap, nanging nganti saiki, siji-sijine cara sing aman yaiku kanggo mesthekake yen wis diinisialisasi.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // SAFETY: panelpon kudu njamin yen `self` ketemu kabeh
        // syarat kanggo referensi.
        unsafe { &*self.as_ptr() }
    }

    /// Ngasilake referensi unik kanggo nilai kasebut.Yen regane bisa dingerteni, [`as_uninit_mut`] kudu digunakake.
    ///
    /// Kanggo mitra sing dituduhake, deleng [`as_ref`].
    ///
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    /// [`as_ref`]: NonNull::as_ref
    ///
    /// # Safety
    ///
    /// Nalika nelpon metode iki, sampeyan kudu mesthekake manawa kabeh perkara ing ngisor iki bener:
    ///
    /// * Pointer kudu didadekake siji kanthi bener.
    ///
    /// * Kudu "dereferencable" ing pangertene sing ditemtokake ing [the module documentation].
    ///
    /// * Pointer kudu nuduhake conto sing diwiwiti saka `T`.
    ///
    /// * Sampeyan kudu ngetrapake aturan aliasing Rust, amarga umur bali `'a` dipilih kanthi sewenang-wenang lan ora kudu nuduhake umur data sing nyata.
    ///
    ///   Utamane, sajrone urip iki, memori sing nuduhake poin ora kudu diakses (diwaca utawa ditulis) liwat pitunjuk liyane.
    ///
    /// Iki ditrapake sanajan asil saka metode iki ora digunakake!
    /// (Bagean babagan inisialisasi durung bisa diputusake kanthi lengkap, nanging nganti saiki, siji-sijine cara sing aman yaiku kanggo mesthekake yen wis diinisialisasi.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // SAFETY: panelpon kudu njamin yen `self` ketemu kabeh
        // syarat kanggo referensi sing bisa diowahi.
        unsafe { &mut *self.as_ptr() }
    }

    /// Mundur menyang pitunjuk jinis liyane.
    #[stable(feature = "nonnull_cast", since = "1.27.0")]
    #[rustc_const_stable(feature = "const_nonnull_cast", since = "1.32.0")]
    #[inline]
    pub const fn cast<U>(self) -> NonNull<U> {
        // SAFETY: `self` minangka pitunjuk `NonNull` sing mesthi ora batal
        unsafe { NonNull::new_unchecked(self.as_ptr() as *mut U) }
    }
}

impl<T> NonNull<[T]> {
    /// Nggawe irisan mentah sing ora bathi saka pitunjuk lancip lan dawa.
    ///
    /// Argumentasi `len` minangka nomer **elemen**, dudu jumlah bait.
    ///
    /// Fungsi iki aman, nanging nyuda referensi bali ora aman.
    /// Deleng dokumentasi [`slice::from_raw_parts`] kanggo syarat keamanan irisan.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(nonnull_slice_from_raw_parts)]
    ///
    /// use std::ptr::NonNull;
    ///
    /// // nggawe irisan pitunjuk nalika diwiwiti karo pitunjuk menyang elemen pisanan
    /// let mut x = [5, 6, 7];
    /// let nonnull_pointer = NonNull::new(x.as_mut_ptr()).unwrap();
    /// let slice = NonNull::slice_from_raw_parts(nonnull_pointer, 3);
    /// assert_eq!(unsafe { slice.as_ref()[2] }, 7);
    /// ```
    ///
    /// (Elinga yen conto iki nuduhake kanthi cara panggunaan metode iki, nanging `supaya irisan= NonNull::from(&x[..]);` would be a better way to write code like this.)
    ///
    #[unstable(feature = "nonnull_slice_from_raw_parts", issue = "71941")]
    #[rustc_const_unstable(feature = "const_nonnull_slice_from_raw_parts", issue = "71941")]
    #[inline]
    pub const fn slice_from_raw_parts(data: NonNull<T>, len: usize) -> Self {
        // SAFETY: `data` minangka pitunjuk `NonNull` sing mesthi ora batal
        unsafe { Self::new_unchecked(super::slice_from_raw_parts_mut(data.as_ptr(), len)) }
    }

    /// Ngasilake dawa irisan mentah sing ora bathi.
    ///
    /// Nilai bali nomer unsur ** **, ora nomer bita.
    ///
    /// Fungsi iki aman, sanajan irisan mentah sing non-nol ora bisa dibuwang irisan amarga pointer ora duwe alamat sing bener.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    #[inline]
    pub const fn len(self) -> usize {
        self.as_ptr().len()
    }

    /// Ngasilake pitunjuk sing ora nol menyang buffer irisan.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_non_null_ptr(), NonNull::new(1 as *mut i8).unwrap());
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_non_null_ptr(self) -> NonNull<T> {
        // SAFETY: Kita ngerti `self` ora batal.
        unsafe { NonNull::new_unchecked(self.as_ptr().as_mut_ptr()) }
    }

    /// Ngasilake pitunjuk mentah menyang buffer irisan.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_mut_ptr(), 1 as *mut i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_mut_ptr(self) -> *mut T {
        self.as_non_null_ptr().as_ptr()
    }

    /// Ngasilake referensi bareng menyang irisan sing bisa uga ora dingerteni nilai.Beda karo [`as_ref`], iki ora mbutuhake regane kudu diinisialisasi.
    ///
    /// Kanggo pasangan sing bisa diowahi, deleng [`as_uninit_slice_mut`].
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_slice_mut`]: NonNull::as_uninit_slice_mut
    ///
    /// # Safety
    ///
    /// Nalika nelpon metode iki, sampeyan kudu mesthekake manawa kabeh perkara ing ngisor iki bener:
    ///
    /// * Pointer kudu [valid] kanggo diwaca kanggo `ptr.len() * mem::size_of::<T>()` akeh bait, lan kudu didol kanthi bener.Iki tegese khusus:
    ///
    ///     * Kabeh rentang memori irisan iki kudu dikatutake ing obyek sing diparengake!
    ///       Irisan ora bisa ditemokake ing pirang-pirang obyek sing dialokasikan.
    ///
    ///     * Pointer kudu didadekake siji sanajan irisan dawa-nol.
    ///     Salah sawijining sebab yaiku optimisasi tata letak enum bisa uga gumantung karo referensi (kalebu irisan apa wae) sing selaras lan ora batal kanggo mbedakake saka data liyane.
    ///
    ///     Sampeyan bisa entuk pitunjuk sing bisa digunakake minangka `data` kanggo irisan dawa-nol nggunakake [`NonNull::dangling()`].
    ///
    /// * Ukuran total `ptr.len() * mem::size_of::<T>()` irisan kudu ora luwih gedhe tinimbang `isize::MAX`.
    ///   Deleng dokumentasi keamanan [`pointer::offset`].
    ///
    /// * Sampeyan kudu ngetrapake aturan aliasing Rust, amarga umur bali `'a` dipilih kanthi sewenang-wenang lan ora kudu nuduhake umur data sing nyata.
    ///   Utamane, sajrone urip iki, memori sing nuduhake poin ora kudu diowahi (kajaba ing `UnsafeCell`).
    ///
    /// Iki ditrapake sanajan asil saka metode iki ora digunakake!
    ///
    /// Deleng uga [`slice::from_raw_parts`].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice(&self) -> &[MaybeUninit<T>] {
        // SAFETY: panelpon kudu njaga kontrak keamanan kanggo `as_uninit_slice`.
        unsafe { slice::from_raw_parts(self.cast().as_ptr(), self.len()) }
    }

    /// Ngasilake referensi unik menyang irisan sing bisa uga ora dingerteni nilai.Beda karo [`as_mut`], iki ora mbutuhake regane kudu diinisialisasi.
    ///
    /// Kanggo mitra sing dituduhake, waca [`as_uninit_slice`].
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_slice`]: NonNull::as_uninit_slice
    ///
    /// # Safety
    ///
    /// Nalika nelpon metode iki, sampeyan kudu mesthekake manawa kabeh perkara ing ngisor iki bener:
    ///
    /// * Pointer kudu [valid] kanggo maca lan nulis `ptr.len() * mem::size_of::<T>()` akeh byte, lan kudu didandani kanthi bener.Iki tegese khusus:
    ///
    ///     * Kabeh rentang memori irisan iki kudu dikatutake ing obyek sing diparengake!
    ///       Irisan ora bisa ditemokake ing pirang-pirang obyek sing dialokasikan.
    ///
    ///     * Pointer kudu didadekake siji sanajan irisan dawa-nol.
    ///     Salah sawijining sebab yaiku optimisasi tata letak enum bisa uga gumantung karo referensi (kalebu irisan apa wae) sing selaras lan ora batal kanggo mbedakake saka data liyane.
    ///
    ///     Sampeyan bisa entuk pitunjuk sing bisa digunakake minangka `data` kanggo irisan dawa-nol nggunakake [`NonNull::dangling()`].
    ///
    /// * Ukuran total `ptr.len() * mem::size_of::<T>()` irisan kudu ora luwih gedhe tinimbang `isize::MAX`.
    ///   Deleng dokumentasi keamanan [`pointer::offset`].
    ///
    /// * Sampeyan kudu ngetrapake aturan aliasing Rust, amarga umur bali `'a` dipilih kanthi sewenang-wenang lan ora kudu nuduhake umur data sing nyata.
    ///   Utamane, sajrone urip iki, memori sing nuduhake poin ora kudu diakses (diwaca utawa ditulis) liwat pitunjuk liyane.
    ///
    /// Iki ditrapake sanajan asil saka metode iki ora digunakake!
    ///
    /// Deleng uga [`slice::from_raw_parts_mut`].
    ///
    /// [valid]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(allocator_api, ptr_as_uninit)]
    ///
    /// use std::alloc::{Allocator, Layout, Global};
    /// use std::mem::MaybeUninit;
    /// use std::ptr::NonNull;
    ///
    /// let memory: NonNull<[u8]> = Global.allocate(Layout::new::<[u8; 32]>())?;
    /// // Iki aman amarga `memory` bener kanggo maca lan nulis kanggo `memory.len()` akeh bait.
    /// // Elinga yen nelpon `memory.as_mut()` ora diidini ing kene amarga konten bisa uga ora dinamis.
    /// # #[allow(unused_variables)]
    /// let slice: &mut [MaybeUninit<u8>] = unsafe { memory.as_uninit_slice_mut() };
    /// # Ok::<_, std::alloc::AllocError>(())
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice_mut(&self) -> &mut [MaybeUninit<T>] {
        // SAFETY: panelpon kudu njaga kontrak keamanan kanggo `as_uninit_slice_mut`.
        unsafe { slice::from_raw_parts_mut(self.cast().as_ptr(), self.len()) }
    }

    /// Ngasilake pitunjuk mentah menyang elemen utawa subslice, tanpa mriksa wates.
    ///
    /// Nelpon cara iki kanthi indeks sing ora ana wates utawa yen `self` ora bisa dibebasake * *[prilaku sing ora ditemtokake] * sanajan penunjuk sing diasilake ora digunakake.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let x = &mut [1, 2, 4];
    /// let x = NonNull::slice_from_raw_parts(NonNull::new(x.as_mut_ptr()).unwrap(), x.len());
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked_mut(1).as_ptr(), x.as_non_null_ptr().as_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(self, index: I) -> NonNull<I::Output>
    where
        I: SliceIndex<[T]>,
    {
        // SAFETY: panelpon njamin manawa `self` ora bisa dibebasake lan `index` ing wates.
        // Akibate, pointer sing diasilake ora bisa NUL.
        unsafe { NonNull::new_unchecked(self.as_ptr().get_unchecked_mut(index)) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Clone for NonNull<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Copy for NonNull<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Debug for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Pointer for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Eq for NonNull<T> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialEq for NonNull<T> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        self.as_ptr() == other.as_ptr()
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Ord for NonNull<T> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        self.as_ptr().cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialOrd for NonNull<T> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.as_ptr().partial_cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> hash::Hash for NonNull<T> {
    #[inline]
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.as_ptr().hash(state)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<Unique<T>> for NonNull<T> {
    #[inline]
    fn from(unique: Unique<T>) -> Self {
        // SAFETY: Penunjuk unik ora bisa dibatalake, mula sarat kanggo
        // new_unchecked() sing dihormati.
        unsafe { NonNull::new_unchecked(unique.as_ptr()) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&mut T> for NonNull<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // SAFETY: Referensi sing bisa dipateni ora bisa dibatalake.
        unsafe { NonNull { pointer: reference as *mut T } }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&T> for NonNull<T> {
    #[inline]
    fn from(reference: &T) -> Self {
        // SAFETY: Referensi ora bisa dibatalake, mula kahanane
        // new_unchecked() sing dihormati.
        unsafe { NonNull { pointer: reference as *const T } }
    }
}