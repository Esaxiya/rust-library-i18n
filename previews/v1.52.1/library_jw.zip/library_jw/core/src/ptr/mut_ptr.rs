use super::*;
use crate::cmp::Ordering::{self, Equal, Greater, Less};
use crate::intrinsics;
use crate::slice::{self, SliceIndex};

#[lang = "mut_ptr"]
impl<T: ?Sized> *mut T {
    /// Ngasilake `true` yen pitunjuk ora ana bathi.
    ///
    /// Elinga yen jinis sing ora diukur ukuran bisa uga duwe petunjuk sing kosong, amarga mung pitunjuk data mentah sing dianggep, dudu dawane, meja lsp.
    /// Mula, rong petunjuk sing nul isih bisa uga ora padha-padha dibandhingake.
    ///
    /// ## Prilaku sajrone evaluasi konst
    ///
    /// Yen fungsi iki digunakake sajrone evaluasi konst, bisa ngasilake `false` kanggo pitunjuk sing ternyata batal nalika runtime.
    /// Khusus, nalika pitunjuk kanggo sawetara memori wis nutup kerugian ngluwihi wates ing kuwi cara sing pitunjuk asil null, fungsi isih bali `false`.
    ///
    /// Ora ana cara kanggo CTFE ngerti posisi absolut saka memori kasebut, mula kita ora bisa ngerti manawa pitunjuk kasebut bathi utawa ora.
    ///
    /// # Examples
    ///
    /// Panggunaan dhasar:
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    /// assert!(!ptr.is_null());
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_ptr_is_null", issue = "74939")]
    #[inline]
    pub const fn is_null(self) -> bool {
        // Bandhingake kanthi cara menyang pointer sing tipis, dadi pitunjuk lemak mung nganggep bagean "data" kanggo bathi.
        //
        (self as *mut u8).guaranteed_eq(null_mut())
    }

    /// Mundur menyang pitunjuk jinis liyane.
    #[stable(feature = "ptr_cast", since = "1.38.0")]
    #[rustc_const_stable(feature = "const_ptr_cast", since = "1.38.0")]
    #[inline]
    pub const fn cast<U>(self) -> *mut U {
        self as _
    }

    /// Decompose a (might wide) pointer dadi alamat lan komponen metadata.
    ///
    /// Penunjuk mengko bisa direkonstruksi nganggo [`from_raw_parts_mut`].
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (*mut (), <T as super::Pointee>::Metadata) {
        (self.cast(), super::metadata(self))
    }

    /// Ngasilake `None` yen pitunjuk ora ana gunane, utawa ngasilake referensi bareng kanggo nilai sing dibungkus `Some`.Yen regane bisa dingerteni, [`as_uninit_ref`] kudu digunakake.
    ///
    /// Kanggo pasangan sing bisa diowahi, deleng [`as_mut`].
    ///
    /// [`as_uninit_ref`]: #method.as_uninit_ref-1
    /// [`as_mut`]: #method.as_mut
    ///
    /// # Safety
    ///
    /// Nalika nelpon metode iki, sampeyan kudu mriksa manawa *salah siji* pointer NULL *utawa* kabeh ing ngisor iki bener:
    ///
    /// * Pointer kudu didadekake siji kanthi bener.
    ///
    /// * Kudu "dereferencable" ing pangertene sing ditemtokake ing [the module documentation].
    ///
    /// * Pointer kudu nuduhake conto sing diwiwiti saka `T`.
    ///
    /// * Sampeyan kudu ngetrapake aturan aliasing Rust, amarga umur bali `'a` dipilih kanthi sewenang-wenang lan ora kudu nuduhake umur data sing nyata.
    ///   Utamane, sajrone urip iki, memori sing nuduhake poin ora kudu diowahi (kajaba ing `UnsafeCell`).
    ///
    /// Iki ditrapake sanajan asil saka metode iki ora digunakake!
    /// (Bagean babagan inisialisasi durung bisa diputusake kanthi lengkap, nanging nganti saiki, siji-sijine cara sing aman yaiku kanggo mesthekake yen wis diinisialisasi.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Panggunaan dhasar:
    ///
    /// ```
    /// let ptr: *mut u8 = &mut 10u8 as *mut u8;
    ///
    /// unsafe {
    ///     if let Some(val_back) = ptr.as_ref() {
    ///         println!("We got back the value: {}!", val_back);
    ///     }
    /// }
    /// ```
    ///
    /// # Versi sing ora dicenthang
    ///
    /// Yen sampeyan manawa pitunjuk tau bisa null lan looking kanggo sawetara jenis `as_ref_unchecked` sing ngasilake `&T` tinimbang `Option<&T>`, ngerti sing bisa dereference pitunjuk langsung.
    ///
    ///
    /// ```
    /// let ptr: *mut u8 = &mut 10u8 as *mut u8;
    ///
    /// unsafe {
    ///     let val_back = &*ptr;
    ///     println!("We got back the value: {}!", val_back);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_as_ref", since = "1.9.0")]
    #[inline]
    pub unsafe fn as_ref<'a>(self) -> Option<&'a T> {
        // SAFETY: panelpon kudu njamin yen `self` bener a
        // referensi yen ora batal.
        if self.is_null() { None } else { unsafe { Some(&*self) } }
    }

    /// Ngasilake `None` yen pitunjuk ora ana bathi, utawa ngasilake referensi bareng karo nilai sing dibungkus `Some`.
    /// Beda karo [`as_ref`], iki ora mbutuhake regane kudu diinisialisasi.
    ///
    /// Kanggo pasangan sing bisa diowahi, deleng [`as_uninit_mut`].
    ///
    /// [`as_ref`]: #method.as_ref-1
    /// [`as_uninit_mut`]: #method.as_uninit_mut
    ///
    /// # Safety
    ///
    /// Nalika nelpon metode iki, sampeyan kudu mriksa manawa *salah siji* pointer NULL *utawa* kabeh ing ngisor iki bener:
    ///
    /// * Pointer kudu didadekake siji kanthi bener.
    ///
    /// * Kudu "dereferencable" ing pangertene sing ditemtokake ing [the module documentation].
    ///
    /// * Sampeyan kudu ngetrapake aturan aliasing Rust, amarga umur bali `'a` dipilih kanthi sewenang-wenang lan ora kudu nuduhake umur data sing nyata.
    ///
    ///   Utamane, sajrone urip iki, memori sing nuduhake poin ora kudu diowahi (kajaba ing `UnsafeCell`).
    ///
    /// Iki ditrapake sanajan asil saka metode iki ora digunakake!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Panggunaan dhasar:
    ///
    /// ```
    /// #![feature(ptr_as_uninit)]
    ///
    /// let ptr: *mut u8 = &mut 10u8 as *mut u8;
    ///
    /// unsafe {
    ///     if let Some(val_back) = ptr.as_uninit_ref() {
    ///         println!("We got back the value: {}!", val_back.assume_init());
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref<'a>(self) -> Option<&'a MaybeUninit<T>>
    where
        T: Sized,
    {
        // SAFETY: panelpon kudu njamin yen `self` ketemu kabeh
        // syarat kanggo referensi.
        if self.is_null() { None } else { Some(unsafe { &*(self as *const MaybeUninit<T>) }) }
    }

    /// Ngetung nutup kerugian saka pitunjuk.
    ///
    /// `count` ana ing unit T;contone, `count` saka 3 nuduhake offset pointer saka byte `3 * size_of::<T>()`.
    ///
    /// # Safety
    ///
    /// Yen ana kondisi ing ngisor iki sing dilanggar, asile tumindak sing ora ditemtokake:
    ///
    /// * Penunjuk wiwitan lan asil kudu ing wates utawa siji byte liwat pungkasan obyek sing dialokasikan sing padha.
    /// Elinga yen ing Rust, saben variabel (stack-allocated) dianggep obyek sing dipisahake kanthi kapisah.
    ///
    /// * Offset sing diitung,**ing bait**, ora bisa kebanjiran `isize`.
    ///
    /// * Offset ing wates ora bisa gumantung ing "wrapping around" ruang alamat.Yaiku, jumlah presisi tanpa wates,**ing bait** kudu pas karo usize.
    ///
    /// Panyusunan lan pustaka standar umume nyoba njamin alokasi ora bakal tekan ukuran nalika masalah offset dadi masalah.
    /// Contone, `Vec` lan `Box` mesthekake ora bakal menehi luwih saka `isize::MAX` byte, mula `vec.as_ptr().add(vec.len())` mesthi aman.
    ///
    /// Umume platform dhasar ora bisa nggawe alokasi kaya ngono.
    /// Contone, ora ana platform 64-bit sing dingerteni sing bisa nyedhiyakake panjaluk 2 <sup>63</sup> bait amarga watesan tabel utawa mbagi ruang alamat.
    /// Nanging, sawetara platform 32-bit lan 16-bit bisa uga sukses nyedhiyakake panjaluk luwih saka `isize::MAX` byte kanthi barang kayata Extension Address Physical.
    ///
    /// Kayane, memori sing dipikolehi langsung saka alokasi utawa file sing dipetakan memori *bisa uga* gedhe banget kanggo ngatasi fungsi iki.
    ///
    /// Coba gunakake [`wrapping_offset`] yen watesan kasebut angel ditindakake.
    /// Kauntungan mung metode iki yaiku ngoptimalake optimisasi kompilator sing luwih agresif.
    ///
    /// [`wrapping_offset`]: #method.wrapping_offset
    ///
    /// # Examples
    ///
    /// Panggunaan dhasar:
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    ///
    /// unsafe {
    ///     println!("{}", *ptr.offset(1));
    ///     println!("{}", *ptr.offset(2));
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn offset(self, count: isize) -> *mut T
    where
        T: Sized,
    {
        // SAFETY: panelpon kudu njaga kontrak keamanan kanggo `offset`.
        // Pointer sing dipikolehi bener valid kanggo nulis amarga panelpon kudu njamin yen nuduhake obyek sing dialokasikan padha karo `self`.
        //
        unsafe { intrinsics::offset(self, count) as *mut T }
    }

    /// Ngetung nutup kerugian saka pitunjuk kanthi nggunakake aritmetika bungkus.
    /// `count` ana ing unit T;contone, `count` saka 3 nuduhake offset pointer saka byte `3 * size_of::<T>()`.
    ///
    /// # Safety
    ///
    /// Operasi iki dhewe mesthi aman, nanging nggunakake petunjuk ora bakal.
    ///
    /// Pointer sing diasilake tetep dipasang ing obyek sing dialokasikan padha karo `self`.
    /// Bisa uga *ora* digunakake kanggo ngakses obyek liyane sing dialokasikan.Elinga yen ing Rust, saben variabel (stack-allocated) dianggep obyek sing dipisahake kanthi kapisah.
    ///
    /// Kanthi tembung liya, `let z = x.wrapping_offset((y as isize) - (x as isize))`*ora* nggawe `z` padha karo `y` sanajan kita nganggep `T` duwe ukuran `1` lan ora ana kebanjiran: `z` isih dipasang ing obyek `x` sing dipasang, lan dereferensi kasebut minangka Perilaku Undefined kajaba `x` lan `y` arahake obyek sing padha dialokasikan.
    ///
    /// Dibandhingake [`offset`], cara iki Sejatine telat requirement tetep ing obyek diparengake padha: [`offset`] iku langsung Behavior Undefined wates nyebrang obyek;`wrapping_offset` mrodhuksi pitunjuk nanging isih ndadékaké kanggo Undefined Behavior menawa pitunjuk wis dereferenced nalika iku metu-saka-wates saka obyek ditempelake.
    /// [`offset`] bisa dioptimalake kanthi luwih apik lan saengga luwih disenengi ing kode sensitif kinerja.
    ///
    /// Priksa sing telat mung nganggep nilai pointer sing diresepake, dudu nilai-nilai menengah sing digunakake sajrone ngetung asil pungkasan.
    /// Contone, `x.wrapping_offset(o).wrapping_offset(o.wrapping_neg())` mesthi padha karo `x`.Kanthi tembung liyane, ninggalake obyek sing dialokasikan banjur ngetik maneh mengko diidini.
    ///
    /// Yen sampeyan kudu nyebrang watesan obyek, wenehi titik menyang integer lan wenehi aritmatika ing kana.
    ///
    /// [`offset`]: #method.offset
    ///
    /// # Examples
    ///
    /// Panggunaan dhasar:
    ///
    /// ```
    /// // Iterate nggunakake pitunjuk mentah kanthi tambahan rong elemen
    /// let mut data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *mut u8 = data.as_mut_ptr();
    /// let step = 2;
    /// let end_rounded_up = ptr.wrapping_offset(6);
    ///
    /// while ptr != end_rounded_up {
    ///     unsafe {
    ///         *ptr = 0;
    ///     }
    ///     ptr = ptr.wrapping_offset(step);
    /// }
    /// assert_eq!(&data, &[0, 2, 0, 4, 0]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_wrapping_offset", since = "1.16.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_offset(self, count: isize) -> *mut T
    where
        T: Sized,
    {
        // SAFETY: intrinsik `arith_offset` ora ana prasyarat sing bakal diarani.
        unsafe { intrinsics::arith_offset(self, count) as *mut T }
    }

    /// Ngasilake `None` yen pitunjuk batal, utawa ngasilake referensi unik kanggo nilai sing dibungkus `Some`.Yen regane bisa dingerteni, [`as_uninit_mut`] kudu digunakake.
    ///
    /// Kanggo mitra sing dituduhake, deleng [`as_ref`].
    ///
    /// [`as_uninit_mut`]: #method.as_uninit_mut
    /// [`as_ref`]: #method.as_ref-1
    ///
    /// # Safety
    ///
    /// Nalika nelpon metode iki, sampeyan kudu mriksa manawa *salah siji* pointer NULL *utawa* kabeh ing ngisor iki bener:
    ///
    /// * Pointer kudu didadekake siji kanthi bener.
    ///
    /// * Kudu "dereferencable" ing pangertene sing ditemtokake ing [the module documentation].
    ///
    /// * Pointer kudu nuduhake conto sing diwiwiti saka `T`.
    ///
    /// * Sampeyan kudu ngetrapake aturan aliasing Rust, amarga umur bali `'a` dipilih kanthi sewenang-wenang lan ora kudu nuduhake umur data sing nyata.
    ///   Utamane, sajrone urip iki, memori sing nuduhake poin ora kudu diakses (diwaca utawa ditulis) liwat pitunjuk liyane.
    ///
    /// Iki ditrapake sanajan asil saka metode iki ora digunakake!
    /// (Bagean babagan inisialisasi durung bisa diputusake kanthi lengkap, nanging nganti saiki, siji-sijine cara sing aman yaiku kanggo mesthekake yen wis diinisialisasi.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Panggunaan dhasar:
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    /// let first_value = unsafe { ptr.as_mut().unwrap() };
    /// *first_value = 4;
    /// # assert_eq!(s, [4, 2, 3]);
    /// println!("{:?}", s); // Bakal dicithak: "[4, 2, 3]".
    /// ```
    ///
    /// # Versi sing ora dicenthang
    ///
    /// Yen sampeyan yakin pointer ora bakal nul lan golek jinis `as_mut_unchecked` sing ngasilake `&mut T` tinimbang `Option<&mut T>`, ngerti manawa sampeyan bisa langsung milih pointer kasebut.
    ///
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    /// let first_value = unsafe { &mut *ptr };
    /// *first_value = 4;
    /// # assert_eq!(s, [4, 2, 3]);
    /// println!("{:?}", s); // Bakal dicithak: "[4, 2, 3]".
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_as_ref", since = "1.9.0")]
    #[inline]
    pub unsafe fn as_mut<'a>(self) -> Option<&'a mut T> {
        // SAFETY: panelpon kudu njamin yen `self` bener
        // referensi sing bisa diowahi yen ora batal.
        if self.is_null() { None } else { unsafe { Some(&mut *self) } }
    }

    /// Ngasilake `None` yen pitunjuk ora valid, utawa ngasilake referensi unik kanggo nilai sing dibungkus `Some`.
    /// Beda karo [`as_mut`], iki ora mbutuhake regane kudu diinisialisasi.
    ///
    /// Kanggo mitra sing dituduhake, waca [`as_uninit_ref`].
    ///
    /// [`as_mut`]: #method.as_mut
    /// [`as_uninit_ref`]: #method.as_uninit_ref-1
    ///
    /// # Safety
    ///
    /// Nalika nelpon metode iki, sampeyan kudu mriksa manawa *salah siji* pointer NULL *utawa* kabeh ing ngisor iki bener:
    ///
    /// * Pointer kudu didadekake siji kanthi bener.
    ///
    /// * Kudu "dereferencable" ing pangertene sing ditemtokake ing [the module documentation].
    ///
    /// * Sampeyan kudu ngetrapake aturan aliasing Rust, amarga umur bali `'a` dipilih kanthi sewenang-wenang lan ora kudu nuduhake umur data sing nyata.
    ///
    ///   Utamane, sajrone urip iki, memori sing nuduhake poin ora kudu diakses (diwaca utawa ditulis) liwat pitunjuk liyane.
    ///
    /// Iki ditrapake sanajan asil saka metode iki ora digunakake!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_mut<'a>(self) -> Option<&'a mut MaybeUninit<T>>
    where
        T: Sized,
    {
        // SAFETY: panelpon kudu njamin yen `self` ketemu kabeh
        // syarat kanggo referensi.
        if self.is_null() { None } else { Some(unsafe { &mut *(self as *mut MaybeUninit<T>) }) }
    }

    /// Ngasilake manawa rong petunjuk dijamin padha.
    ///
    /// Nalika runtime, fungsi iki tumindak kaya `self == other`.
    /// Nanging, ing sawetara konteks (kayata, evaluasi kompilasi-wektu), ora mesthi bisa nemtokake kesetaraan rong pointer, mula fungsi iki bisa ngasilake `false` kanthi spurious kanggo petunjuk sing mengko bisa uga padha.
    ///
    /// Nanging nalika ngasilake `true`, pointer dijamin padha.
    ///
    /// Fungsi iki minangka pangilon [`guaranteed_ne`], nanging ora kuwalik.Ana perbandingan pitunjuk sing loro fungsi ngasilake `false`.
    ///
    /// [`guaranteed_ne`]: #method.guaranteed_ne
    ///
    /// Nilai bali bisa uga beda-beda gumantung karo versi kompiler lan kode sing ora aman bisa uga ora gumantung karo asil fungsi iki kanggo kesehatan.
    /// Disaranake mung nggunakake fungsi iki kanggo optimalisasi kinerja ing endi nilai bali `false` palsu kanthi fungsi iki ora mengaruhi asil, nanging mung kinerja.
    /// Konsekuensi nggunakake metode iki kanggo nggawe runtime lan kode kompilasi wektu tumindak beda-beda durung dingerteni.
    /// Cara iki ora digunakake kanggo ngenalake bedane kaya mengkene, lan uga ora kudu stabil sadurunge kita luwih ngerti babagan masalah iki.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[inline]
    pub const fn guaranteed_eq(self, other: *mut T) -> bool
    where
        T: Sized,
    {
        intrinsics::ptr_guaranteed_eq(self as *const _, other as *const _)
    }

    /// Ngasilake manawa rong petunjuk dijamin ora padha.
    ///
    /// Nalika runtime, fungsi iki tumindak kaya `self != other`.
    /// Nanging, ing sawetara konteks (contone, evaluasi kompilasi-wektu), ora mesthi bisa nemtokake ketimpangan loro petunjuk, mula fungsi iki bisa ngasilake `false` kanthi spurious kanggo petunjuk sing mengko jebule ora padha.
    ///
    /// Nanging nalika ngasilake `true`, pointer dijamin ora padha.
    ///
    /// Fungsi iki minangka pangilon [`guaranteed_eq`], nanging ora kuwalik.Ana perbandingan pitunjuk sing loro fungsi ngasilake `false`.
    ///
    /// [`guaranteed_eq`]: #method.guaranteed_eq
    ///
    /// Nilai bali bisa uga beda-beda gumantung karo versi kompiler lan kode sing ora aman bisa uga ora gumantung karo asil fungsi iki kanggo kesehatan.
    /// Disaranake mung nggunakake fungsi iki kanggo optimalisasi kinerja ing endi nilai bali `false` palsu kanthi fungsi iki ora mengaruhi asil, nanging mung kinerja.
    /// Konsekuensi nggunakake metode iki kanggo nggawe runtime lan kode kompilasi wektu tumindak beda-beda durung dingerteni.
    /// Cara iki ora digunakake kanggo ngenalake bedane kaya mengkene, lan uga ora kudu stabil sadurunge kita luwih ngerti babagan masalah iki.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[inline]
    pub const unsafe fn guaranteed_ne(self, other: *mut T) -> bool
    where
        T: Sized,
    {
        intrinsics::ptr_guaranteed_ne(self as *const _, other as *const _)
    }

    /// Ngetung jarak antarane rong petunjuk.Nilai bali ana ing unit T: jarak byte dipérang dadi `mem::size_of::<T>()`.
    ///
    /// Fungsi iki minangka kuwalik [`offset`].
    ///
    /// [`offset`]: #method.offset-1
    ///
    /// # Safety
    ///
    /// Yen ana kondisi ing ngisor iki sing dilanggar, asile tumindak sing ora ditemtokake:
    ///
    /// * Panunjuk lan panunjuk liyane kudu ana ing wates utawa siji byte liwat pungkasan obyek sing dialokasikan sing padha.
    /// Elinga yen ing Rust, saben variabel (stack-allocated) dianggep obyek sing dipisahake kanthi kapisah.
    ///
    /// * Kaloro petunjuk kasebut kudu *asale saka* pitunjuk menyang obyek sing padha.
    ///   (Deleng ing ngisor iki kanggo conto.)
    ///
    /// * Jarak antarane petunjuk, ing bait, mesthine kudu tikel persis saka ukuran `T`.
    ///
    /// * Jarak antarane petunjuk,**ing bait**, ora bisa kebanjiran `isize`.
    ///
    /// * Jarak sing ana ing wates ora bisa gumantung ing "wrapping around" ruang alamat.
    ///
    /// Jinis Rust ora bakal luwih gedhe tinimbang alokasi `isize::MAX` lan Rust ora nate ngubengi ruang alamat, mula rong poin ing sawetara jinis Rust tipe `T` bakal mesthi gawe marem rong kahanan pungkasan.
    ///
    /// Pustaka standar uga umume mesthekake yen alokasi ora bakal tekan ukuran sing dadi perhatian yaiku offset.
    /// Contone, `Vec` lan `Box` mesthekake ora bakal menehi luwih saka `isize::MAX` byte, mula `ptr_into_vec.offset_from(vec.as_ptr())` mesthi ngisi rong kahanan pungkasan.
    ///
    /// Umume platform dhasar ora bisa nggawe alokasi gedhe kasebut.
    /// Contone, ora ana platform 64-bit sing dingerteni sing bisa nyedhiyakake panjaluk 2 <sup>63</sup> bait amarga watesan tabel utawa mbagi ruang alamat.
    /// Nanging, sawetara platform 32-bit lan 16-bit bisa uga sukses nyedhiyakake panjaluk luwih saka `isize::MAX` byte kanthi barang kayata Extension Address Physical.
    /// Kayane, memori sing dipikolehi langsung saka alokasi utawa file sing dipetakan memori *bisa uga* gedhe banget kanggo ngatasi fungsi iki.
    /// (Elinga yen [`offset`] lan [`add`] uga duwe watesan sing padha lan mula ora bisa digunakake kanggo alokasi gedhe kasebut.)
    ///
    /// [`add`]: #method.add
    ///
    /// # Panics
    ///
    /// Fungsi panics iki yen `T` minangka Zero-Sized Type ("ZST").
    ///
    /// # Examples
    ///
    /// Panggunaan dhasar:
    ///
    /// ```
    /// let mut a = [0; 5];
    /// let ptr1: *mut i32 = &mut a[1];
    /// let ptr2: *mut i32 = &mut a[3];
    /// unsafe {
    ///     assert_eq!(ptr2.offset_from(ptr1), 2);
    ///     assert_eq!(ptr1.offset_from(ptr2), -2);
    ///     assert_eq!(ptr1.offset(2), ptr2);
    ///     assert_eq!(ptr2.offset(-2), ptr1);
    /// }
    /// ```
    ///
    /// *Panggunaan salah*:
    ///
    /// ```rust,no_run
    /// let ptr1 = Box::into_raw(Box::new(0u8));
    /// let ptr2 = Box::into_raw(Box::new(1u8));
    /// let diff = (ptr2 as isize).wrapping_sub(ptr1 as isize);
    /// // Gawe ptr2_lain "alias" ptr2, nanging asale saka ptr1.
    /// let ptr2_other = (ptr1 as *mut u8).wrapping_offset(diff);
    /// assert_eq!(ptr2 as usize, ptr2_other as usize);
    /// // Amarga ptr2_other lan ptr2 asale saka petunjuk menyang obyek sing beda, ngitung offset minangka tumindak sing durung ditemtokake, sanajan padha nuduhake alamat sing padha!
    /////
    /////
    /// unsafe {
    ///     let zero = ptr2_other.offset_from(ptr2); // Prilaku sing durung ditemtokake
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_offset_from", since = "1.47.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    #[inline]
    pub const unsafe fn offset_from(self, origin: *const T) -> isize
    where
        T: Sized,
    {
        // SAFETY: panelpon kudu njaga kontrak keamanan kanggo `offset_from`.
        unsafe { (self as *const T).offset_from(origin) }
    }

    /// Ngetung nutup kerugian saka pitunjuk (penak kanggo `.offset(count as isize)`).
    ///
    /// `count` ana ing unit T;contone, `count` saka 3 nuduhake offset pointer saka byte `3 * size_of::<T>()`.
    ///
    /// # Safety
    ///
    /// Yen ana kondisi ing ngisor iki sing dilanggar, asile tumindak sing ora ditemtokake:
    ///
    /// * Penunjuk wiwitan lan asil kudu ing wates utawa siji byte liwat pungkasan obyek sing dialokasikan sing padha.
    /// Elinga yen ing Rust, saben variabel (stack-allocated) dianggep obyek sing dipisahake kanthi kapisah.
    ///
    /// * Offset sing diitung,**ing bait**, ora bisa kebanjiran `isize`.
    ///
    /// * Offset ing wates ora bisa gumantung ing "wrapping around" ruang alamat.Yaitu, jumlah presisi tanpa wates kudu pas karo `usize`.
    ///
    /// Panyusunan lan pustaka standar umume nyoba njamin alokasi ora bakal tekan ukuran nalika masalah offset dadi masalah.
    /// Contone, `Vec` lan `Box` mesthekake ora bakal menehi luwih saka `isize::MAX` byte, mula `vec.as_ptr().add(vec.len())` mesthi aman.
    ///
    /// Umume platform dhasar ora bisa nggawe alokasi kaya ngono.
    /// Contone, ora ana platform 64-bit sing dingerteni sing bisa nyedhiyakake panjaluk 2 <sup>63</sup> bait amarga watesan tabel utawa mbagi ruang alamat.
    /// Nanging, sawetara platform 32-bit lan 16-bit bisa uga sukses nyedhiyakake panjaluk luwih saka `isize::MAX` byte kanthi barang kayata Extension Address Physical.
    ///
    /// Kayane, memori sing dipikolehi langsung saka alokasi utawa file sing dipetakan memori *bisa uga* gedhe banget kanggo ngatasi fungsi iki.
    ///
    /// Coba gunakake [`wrapping_add`] yen watesan kasebut angel ditindakake.
    /// Kauntungan mung metode iki yaiku ngoptimalake optimisasi kompilator sing luwih agresif.
    ///
    /// [`wrapping_add`]: #method.wrapping_add
    ///
    /// # Examples
    ///
    /// Panggunaan dhasar:
    ///
    /// ```
    /// let s: &str = "123";
    /// let ptr: *const u8 = s.as_ptr();
    ///
    /// unsafe {
    ///     println!("{}", *ptr.add(1) as char);
    ///     println!("{}", *ptr.add(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn add(self, count: usize) -> Self
    where
        T: Sized,
    {
        // SAFETY: panelpon kudu njaga kontrak keamanan kanggo `offset`.
        unsafe { self.offset(count as isize) }
    }

    /// Ngetung nutup kerugian saka pitunjuk (penak kanggo `.offset ((dietung minangka isize).wrapping_neg())`).
    ///
    /// `count` ana ing unit T;contone, `count` saka 3 nuduhake offset pointer saka byte `3 * size_of::<T>()`.
    ///
    /// # Safety
    ///
    /// Yen ana kondisi ing ngisor iki sing dilanggar, asile tumindak sing ora ditemtokake:
    ///
    /// * Penunjuk wiwitan lan asil kudu ing wates utawa siji byte liwat pungkasan obyek sing dialokasikan sing padha.
    /// Elinga yen ing Rust, saben variabel (stack-allocated) dianggep obyek sing dipisahake kanthi kapisah.
    ///
    /// * Offset sing diitung ora bisa ngluwihi `isize::MAX`**bait**.
    ///
    /// * Offset ing wates ora bisa gumantung ing "wrapping around" ruang alamat.Yaitu, jumlah presisi tanpa wates kudu pas karo usize.
    ///
    /// Panyusunan lan pustaka standar umume nyoba njamin alokasi ora bakal tekan ukuran nalika masalah offset dadi masalah.
    /// Contone, `Vec` lan `Box` mesthekake ora bakal menehi luwih saka `isize::MAX` byte, mula `vec.as_ptr().add(vec.len()).sub(vec.len())` mesthi aman.
    ///
    /// Umume platform dhasar ora bisa nggawe alokasi kaya ngono.
    /// Contone, ora ana platform 64-bit sing dingerteni sing bisa nyedhiyakake panjaluk 2 <sup>63</sup> bait amarga watesan tabel utawa mbagi ruang alamat.
    /// Nanging, sawetara platform 32-bit lan 16-bit bisa uga sukses nyedhiyakake panjaluk luwih saka `isize::MAX` byte kanthi barang kayata Extension Address Physical.
    ///
    /// Kayane, memori sing dipikolehi langsung saka alokasi utawa file sing dipetakan memori *bisa uga* gedhe banget kanggo ngatasi fungsi iki.
    ///
    /// Coba gunakake [`wrapping_sub`] yen watesan kasebut angel ditindakake.
    /// Kauntungan mung metode iki yaiku ngoptimalake optimisasi kompilator sing luwih agresif.
    ///
    /// [`wrapping_sub`]: #method.wrapping_sub
    ///
    /// # Examples
    ///
    /// Panggunaan dhasar:
    ///
    /// ```
    /// let s: &str = "123";
    ///
    /// unsafe {
    ///     let end: *const u8 = s.as_ptr().add(3);
    ///     println!("{}", *end.sub(1) as char);
    ///     println!("{}", *end.sub(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn sub(self, count: usize) -> Self
    where
        T: Sized,
    {
        // SAFETY: panelpon kudu njaga kontrak keamanan kanggo `offset`.
        unsafe { self.offset((count as isize).wrapping_neg()) }
    }

    /// Ngetung nutup kerugian saka pitunjuk kanthi nggunakake aritmetika bungkus.
    /// (penak kanggo `.wrapping_offset(count as isize)`)
    ///
    /// `count` ana ing unit T;contone, `count` saka 3 nuduhake offset pointer saka byte `3 * size_of::<T>()`.
    ///
    /// # Safety
    ///
    /// Operasi iki dhewe mesthi aman, nanging nggunakake petunjuk ora bakal.
    ///
    /// Pointer sing diasilake tetep dipasang ing obyek sing dialokasikan padha karo `self`.
    /// Bisa uga *ora* digunakake kanggo ngakses obyek liyane sing dialokasikan.Elinga yen ing Rust, saben variabel (stack-allocated) dianggep obyek sing dipisahake kanthi kapisah.
    ///
    /// Kanthi tembung liya, `let z = x.wrapping_add((y as usize) - (x as usize))`*ora* nggawe `z` padha karo `y` sanajan kita nganggep `T` duwe ukuran `1` lan ora ana kebanjiran: `z` isih dipasang ing obyek `x` sing dipasang, lan dereferensi kasebut minangka Perilaku Undefined kajaba `x` lan `y` arahake obyek sing padha dialokasikan.
    ///
    /// Yen dibandhingake karo [`add`], metode iki biasane tundha syarat tetep ing obyek sing dialokasikan sing padha: [`add`] yaiku Perilaku sing durung ditemtokake langsung nalika nyebrang watesan obyek;`wrapping_add` ngasilake pitunjuk nanging isih nyebabake Prilaku sing durung ditemtokake yen penunjuk dibatalake nalika njaba obyek sing dipasang.
    /// [`add`] bisa dioptimalake kanthi luwih apik lan saengga luwih disenengi ing kode sensitif kinerja.
    ///
    /// Priksa sing telat mung nganggep nilai pointer sing diresepake, dudu nilai-nilai menengah sing digunakake sajrone ngetung asil pungkasan.
    /// Contone, `x.wrapping_add(o).wrapping_sub(o)` mesthi padha karo `x`.Kanthi tembung liyane, ninggalake obyek sing dialokasikan banjur ngetik maneh mengko diidini.
    ///
    /// Yen sampeyan kudu nyebrang watesan obyek, wenehi titik menyang integer lan wenehi aritmatika ing kana.
    ///
    /// [`add`]: #method.add
    ///
    /// # Examples
    ///
    /// Panggunaan dhasar:
    ///
    /// ```
    /// // Iterate nggunakake pitunjuk mentah kanthi tambahan rong elemen
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let step = 2;
    /// let end_rounded_up = ptr.wrapping_add(6);
    ///
    /// // Gelung iki nyithak "1, 3, 5, "
    /// while ptr != end_rounded_up {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_add(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_add(self, count: usize) -> Self
    where
        T: Sized,
    {
        self.wrapping_offset(count as isize)
    }

    /// Ngetung nutup kerugian saka pitunjuk kanthi nggunakake aritmetika bungkus.
    /// (penak kanggo `.wrapping_offset ((dietung minangka isize).wrapping_neg())`)
    ///
    /// `count` ana ing unit T;contone, `count` saka 3 nuduhake offset pointer saka byte `3 * size_of::<T>()`.
    ///
    /// # Safety
    ///
    /// Operasi iki dhewe mesthi aman, nanging nggunakake petunjuk ora bakal.
    ///
    /// Pointer sing diasilake tetep dipasang ing obyek sing dialokasikan padha karo `self`.
    /// Bisa uga *ora* digunakake kanggo ngakses obyek liyane sing dialokasikan.Elinga yen ing Rust, saben variabel (stack-allocated) dianggep obyek sing dipisahake kanthi kapisah.
    ///
    /// Kanthi tembung liyane, `let z = x.wrapping_sub((x as usize) - (y as usize))`*ora* nggawe `z` padha karo `y` sanajan kita nganggep `T` duwe ukuran `1` lan ora ana kebanjiran: `z` isih dipasang ing obyek `x` sing dipasang, lan dereferensi kasebut minangka Perilaku Undefined kajaba `x` lan `y` arahake obyek sing padha dialokasikan.
    ///
    /// Dibandhingake [`sub`], cara iki Sejatine telat requirement tetep ing obyek diparengake padha: [`sub`] iku langsung Behavior Undefined wates nyebrang obyek;`wrapping_sub` ngasilake pitunjuk nanging isih nyebabake Prilaku sing durung ditemtokake yen penunjuk dibatalake nalika njaba obyek sing dipasang.
    /// [`sub`] bisa dioptimalake kanthi luwih apik lan saengga luwih disenengi ing kode sensitif kinerja.
    ///
    /// Priksa sing telat mung nganggep nilai pointer sing diresepake, dudu nilai-nilai menengah sing digunakake sajrone ngetung asil pungkasan.
    /// Contone, `x.wrapping_add(o).wrapping_sub(o)` mesthi padha karo `x`.Kanthi tembung liyane, ninggalake obyek sing dialokasikan banjur ngetik maneh mengko diidini.
    ///
    /// Yen sampeyan kudu nyebrang watesan obyek, wenehi titik menyang integer lan wenehi aritmatika ing kana.
    ///
    /// [`sub`]: #method.sub
    ///
    /// # Examples
    ///
    /// Panggunaan dhasar:
    ///
    /// ```
    /// // Iterate nggunakake pitunjuk mentah kanthi tambahan rong elemen (backwards)
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let start_rounded_down = ptr.wrapping_sub(2);
    /// ptr = ptr.wrapping_add(4);
    /// let step = 2;
    /// // Gelung iki nyithak "5, 3, 1, "
    /// while ptr != start_rounded_down {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_sub(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_sub(self, count: usize) -> Self
    where
        T: Sized,
    {
        self.wrapping_offset((count as isize).wrapping_neg())
    }

    /// Nyetel nilai pitunjuk menyang `ptr`.
    ///
    /// Yen `self` minangka pointer (fat) menyang jinis sing ora ukuran, operasi iki mung bakal mengaruhi bagean pitunjuk, dene kanggo petunjuk (thin) menyang jinis ukuran, iki efek padha karo tugas sing sederhana.
    ///
    /// Pointer sing diasilake duwe bukti `val`, yaiku kanggo pitunjuk lemak, operasi iki sacara semantik padha karo nggawe pitunjuk lemak anyar kanthi nilai pointer data `val` nanging metadata `self`.
    ///
    ///
    /// # Examples
    ///
    /// Fungsi iki utamane migunani kanggo ngidini aritmatika penunjuk kanthi bait ing petunjuk sing bisa lemak:
    ///
    /// ```
    /// #![feature(set_ptr_value)]
    /// # use core::fmt::Debug;
    /// let mut arr: [i32; 3] = [1, 2, 3];
    /// let mut ptr = &mut arr[0] as *mut dyn Debug;
    /// let thin = ptr as *mut u8;
    /// unsafe {
    ///     ptr = ptr.set_ptr_value(thin.add(8));
    ///     # assert_eq!(*(ptr as *mut i32), 3);
    ///     println!("{:?}", &*ptr); // bakal nyithak "3"
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "set_ptr_value", issue = "75091")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[inline]
    pub fn set_ptr_value(mut self, val: *mut u8) -> Self {
        let thin = &mut self as *mut *mut T as *mut *mut u8;
        // SAFETY: Yen ana petunjuk sing tipis, operasi iki padha
        // menyang tugas sing sederhana.
        // Yen ana pitunjuk sing lemu, kanthi implementasi tata letak pitunjuk lemak saiki, kolom pertama kanggo pitunjuk kaya ngono mesthi dadi penunjuk data, sing uga diwenehake.
        //
        unsafe { *thin = val };
        self
    }

    /// Maca regane saka `self` tanpa mindhah.
    /// Iki ndadekake memori ing `self` ora owah.
    ///
    /// Deleng [`ptr::read`] kanggo masalah keamanan lan conto.
    ///
    /// [`ptr::read`]: crate::ptr::read()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
    #[inline]
    pub const unsafe fn read(self) -> T
    where
        T: Sized,
    {
        // SAFETY: panelpon kudu njaga kontrak keamanan kanggo ``.
        unsafe { read(self) }
    }

    /// Nindakake maca kanthi stabil babagan regane saka `self` tanpa mindhah.Iki ndadekake memori ing `self` ora owah.
    ///
    /// Operasi volatil ditrapake kanggo tumindak ing memori I/O, lan dijamin ora bakal dipilih utawa diatur maneh dening kompiler ing antarane operasi liyane sing ora stabil.
    ///
    ///
    /// Deleng [`ptr::read_volatile`] kanggo masalah keamanan lan conto.
    ///
    /// [`ptr::read_volatile`]: crate::ptr::read_volatile()
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn read_volatile(self) -> T
    where
        T: Sized,
    {
        // SAFETY: panelpon kudu njaga kontrak keamanan kanggo `read_volatile`.
        unsafe { read_volatile(self) }
    }

    /// Maca regane saka `self` tanpa mindhah.
    /// Iki ndadekake memori ing `self` ora owah.
    ///
    /// Beda karo `read`, pointer bisa uga sejajar.
    ///
    /// Deleng [`ptr::read_unaligned`] kanggo masalah keamanan lan conto.
    ///
    /// [`ptr::read_unaligned`]: crate::ptr::read_unaligned()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
    #[inline]
    pub const unsafe fn read_unaligned(self) -> T
    where
        T: Sized,
    {
        // SAFETY: panelpon kudu njaga kontrak keamanan kanggo `read_unaligned`.
        unsafe { read_unaligned(self) }
    }

    /// Nyalin byte `count * size_of<T>` saka `self` nganti `dest`.
    /// Sumber lan tujuan bisa uga tumpang tindih.
    ///
    /// NOTE: iki nduweni urutan argumen *padha* karo [`ptr::copy`].
    ///
    /// Deleng [`ptr::copy`] kanggo masalah keamanan lan conto.
    ///
    /// [`ptr::copy`]: crate::ptr::copy()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_to(self, dest: *mut T, count: usize)
    where
        T: Sized,
    {
        // SAFETY: panelpon kudu njaga kontrak keamanan kanggo `copy`.
        unsafe { copy(self, dest, count) }
    }

    /// Nyalin byte `count * size_of<T>` saka `self` nganti `dest`.
    /// Sumber lan tujuan bisa uga *ora* tumpang tindih.
    ///
    /// NOTE: iki nduweni urutan bantahan *padha* karo [`ptr::copy_nonoverlapping`].
    ///
    /// Deleng [`ptr::copy_nonoverlapping`] kanggo masalah keamanan lan conto.
    ///
    /// [`ptr::copy_nonoverlapping`]: crate::ptr::copy_nonoverlapping()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_to_nonoverlapping(self, dest: *mut T, count: usize)
    where
        T: Sized,
    {
        // SAFETY: panelpon kudu njaga kontrak keamanan kanggo `copy_nonoverlapping`.
        unsafe { copy_nonoverlapping(self, dest, count) }
    }

    /// Nyalin byte `count * size_of<T>` saka `src` nganti `self`.
    /// Sumber lan tujuan bisa uga tumpang tindih.
    ///
    /// NOTE: iki nduweni urutan argumen *ngelawan*[`ptr::copy`].
    ///
    /// Deleng [`ptr::copy`] kanggo masalah keamanan lan conto.
    ///
    /// [`ptr::copy`]: crate::ptr::copy()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_from(self, src: *const T, count: usize)
    where
        T: Sized,
    {
        // SAFETY: panelpon kudu njaga kontrak keamanan kanggo `copy`.
        unsafe { copy(src, self, count) }
    }

    /// Nyalin byte `count * size_of<T>` saka `src` nganti `self`.
    /// Sumber lan tujuan bisa uga *ora* tumpang tindih.
    ///
    /// NOTE: iki nduweni urutan argumen *ngelawan*[`ptr::copy_nonoverlapping`].
    ///
    /// Deleng [`ptr::copy_nonoverlapping`] kanggo masalah keamanan lan conto.
    ///
    /// [`ptr::copy_nonoverlapping`]: crate::ptr::copy_nonoverlapping()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_from_nonoverlapping(self, src: *const T, count: usize)
    where
        T: Sized,
    {
        // SAFETY: panelpon kudu njaga kontrak keamanan kanggo `copy_nonoverlapping`.
        unsafe { copy_nonoverlapping(src, self, count) }
    }

    /// Nglakokaké destruktor (yen ana) nilai sing dituduhake.
    ///
    /// Deleng [`ptr::drop_in_place`] kanggo masalah keamanan lan conto.
    ///
    /// [`ptr::drop_in_place`]: crate::ptr::drop_in_place()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn drop_in_place(self) {
        // SAFETY: panelpon kudu njaga kontrak keamanan kanggo `drop_in_place`.
        unsafe { drop_in_place(self) }
    }

    /// Nulis lokasi memori kanthi nilai tartamtu tanpa maca utawa ngeculake nilai lawas.
    ///
    ///
    /// Deleng [`ptr::write`] kanggo masalah keamanan lan conto.
    ///
    /// [`ptr::write`]: crate::ptr::write()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn write(self, val: T)
    where
        T: Sized,
    {
        // SAFETY: panelpon kudu njaga kontrak keamanan kanggo `write`.
        unsafe { write(self, val) }
    }

    /// Manggil memset ing pitunjuk sing ditemtokake, nyetel memori byte `count * size_of::<T>()` wiwit `self` nganti `val`.
    ///
    ///
    /// Deleng [`ptr::write_bytes`] kanggo masalah keamanan lan conto.
    ///
    /// [`ptr::write_bytes`]: crate::ptr::write_bytes()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn write_bytes(self, val: u8, count: usize)
    where
        T: Sized,
    {
        // SAFETY: panelpon kudu njaga kontrak keamanan kanggo `write_bytes`.
        unsafe { write_bytes(self, val, count) }
    }

    /// Nindakake nulis babagan lokasi memori kanthi molah malih kanthi nilai tartamtu tanpa maca utawa ngeculake nilai lawas.
    ///
    /// Operasi volatil ditrapake kanggo tumindak ing memori I/O, lan dijamin ora bakal dipilih utawa diatur maneh dening kompiler ing antarane operasi liyane sing ora stabil.
    ///
    ///
    /// Deleng [`ptr::write_volatile`] kanggo masalah keamanan lan conto.
    ///
    /// [`ptr::write_volatile`]: crate::ptr::write_volatile()
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn write_volatile(self, val: T)
    where
        T: Sized,
    {
        // SAFETY: panelpon kudu njaga kontrak keamanan kanggo `write_volatile`.
        unsafe { write_volatile(self, val) }
    }

    /// Nulis lokasi memori kanthi nilai tartamtu tanpa maca utawa ngeculake nilai lawas.
    ///
    ///
    /// Beda karo `write`, pointer bisa uga sejajar.
    ///
    /// Deleng [`ptr::write_unaligned`] kanggo masalah keamanan lan conto.
    ///
    /// [`ptr::write_unaligned`]: crate::ptr::write_unaligned()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_write", issue = "none")]
    #[inline]
    pub const unsafe fn write_unaligned(self, val: T)
    where
        T: Sized,
    {
        // SAFETY: panelpon kudu njaga kontrak keamanan kanggo `write_unaligned`.
        unsafe { write_unaligned(self, val) }
    }

    /// Ngganti nilai ing `self` karo `src`, ngasilake nilai lawas, tanpa ngeculake.
    ///
    ///
    /// Deleng [`ptr::replace`] kanggo masalah keamanan lan conto.
    ///
    /// [`ptr::replace`]: crate::ptr::replace()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn replace(self, src: T) -> T
    where
        T: Sized,
    {
        // SAFETY: panelpon kudu njaga kontrak keamanan kanggo `replace`.
        unsafe { replace(self, src) }
    }

    /// Ganti angka ing rong lokasi sing bisa diowahi kanthi jinis sing padha, tanpa uga nggunakake deinitialisasi.
    /// Dheweke bisa tumpang tindih, beda karo `mem::swap` sing padha karo sampeyan.
    ///
    /// Deleng [`ptr::swap`] kanggo masalah keamanan lan conto.
    ///
    /// [`ptr::swap`]: crate::ptr::swap()
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn swap(self, with: *mut T)
    where
        T: Sized,
    {
        // SAFETY: panelpon kudu njaga kontrak keamanan kanggo `swap`.
        unsafe { swap(self, with) }
    }

    /// Ngétung nutup kerugian sing kudu ditrapake ing pitunjuk supaya selaras karo `align`.
    ///
    /// Yen ora bisa nyelarasake pitunjuk, implementasine ngasilake `usize::MAX`.
    /// Diijini kanggo implementasine supaya *tansah* ngasilake `usize::MAX`.
    /// Mung kinerja algoritma sampeyan sing bisa gumantung karo entuk offset sing bisa digunakake ing kene, dudu sing bener.
    ///
    /// Offset ditulis ing nomer unsur `T`, lan ora byte.Nilai sing dikembalikan bisa digunakake kanthi metode `wrapping_add`.
    ///
    /// Ora ana jaminan apa wae sing ngimbangi pointer ora bakal kebanjiran utawa ngluwihi alokasi sing diwenehake pointer.
    ///
    /// Mungkasi panelpon kanggo mesthekake yen nutup kerugian bali bener ing kabeh istilah kajaba penyelarasan.
    ///
    /// # Panics
    ///
    /// Fungsi panics yen `align` dudu kekuwatan loro.
    ///
    /// # Examples
    ///
    /// Ngakses `u8` jejer minangka `u16`
    ///
    /// ```
    /// # fn foo(n: usize) {
    /// # use std::mem::align_of;
    /// # unsafe {
    /// let x = [5u8, 6u8, 7u8, 8u8, 9u8];
    /// let ptr = x.as_ptr().add(n) as *const u8;
    /// let offset = ptr.align_offset(align_of::<u16>());
    /// if offset < x.len() - n - 1 {
    ///     let u16_ptr = ptr.add(offset) as *const u16;
    ///     assert_ne!(*u16_ptr, 500);
    /// } else {
    ///     // nalika pointer bisa didadekake siji liwat `offset`, iku bakal nuduhake ing sanjabane alokasi
    /////
    /// }
    /// # } }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "align_offset", since = "1.36.0")]
    pub fn align_offset(self, align: usize) -> usize
    where
        T: Sized,
    {
        if !align.is_power_of_two() {
            panic!("align_offset: align is not a power-of-two");
        }
        // SAFETY: `align` wis dicenthang dadi kekuwatan 2 ing ndhuwur
        unsafe { align_offset(self, align) }
    }
}

#[lang = "mut_slice_ptr"]
impl<T> *mut [T] {
    /// Ngasilake dawa irisan mentah.
    ///
    /// Nilai bali nomer unsur ** **, ora nomer bita.
    ///
    /// Fungsi iki aman, sanajan irisan mentah ora bisa diluncurake menyang referensi irisan amarga pointer batal utawa ora selaras.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len)]
    /// use std::ptr;
    ///
    /// let slice: *mut [i8] = ptr::slice_from_raw_parts_mut(ptr::null_mut(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    pub const fn len(self) -> usize {
        #[cfg(bootstrap)]
        {
            // SAFETY: iki aman amarga `*const [T]` lan `FatPtr<T>` duwe tata letak sing padha.
            // Mung `std` sing bisa njamin iki.
            unsafe { Repr { rust_mut: self }.raw }.len
        }
        #[cfg(not(bootstrap))]
        metadata(self)
    }

    /// Ngasilake pitunjuk mentah menyang buffer irisan.
    ///
    /// Iki padha karo casting `self` dadi `*mut T`, nanging luwih aman kanggo jinis.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get)]
    /// use std::ptr;
    ///
    /// let slice: *mut [i8] = ptr::slice_from_raw_parts_mut(ptr::null_mut(), 3);
    /// assert_eq!(slice.as_mut_ptr(), 0 as *mut i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_mut_ptr(self) -> *mut T {
        self as *mut T
    }

    /// Ngasilake pitunjuk mentah menyang elemen utawa subslice, tanpa mriksa wates.
    ///
    /// Nelpon cara iki kanthi indeks sing ora ana wates utawa yen `self` ora bisa dibebasake * *[prilaku sing ora ditemtokake] * sanajan penunjuk sing diasilake ora digunakake.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get)]
    ///
    /// let x = &mut [1, 2, 4] as *mut [i32];
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked_mut(1), x.as_mut_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(self, index: I) -> *mut I::Output
    where
        I: SliceIndex<[T]>,
    {
        // SAFETY: panelpon njamin manawa `self` ora bisa dibebasake lan `index` ing wates.
        unsafe { index.get_unchecked_mut(self) }
    }

    /// Ngasilake `None` yen pitunjuk ora ana gunane, utawa ngasilake irisan bareng menyang nilai sing dibungkus `Some`.
    /// Beda karo [`as_ref`], iki ora mbutuhake regane kudu diinisialisasi.
    ///
    /// Kanggo pasangan sing bisa diowahi, deleng [`as_uninit_slice_mut`].
    ///
    /// [`as_ref`]: #method.as_ref-1
    /// [`as_uninit_slice_mut`]: #method.as_uninit_slice_mut
    ///
    /// # Safety
    ///
    /// Nalika nelpon metode iki, sampeyan kudu mriksa manawa *salah siji* pointer NULL *utawa* kabeh ing ngisor iki bener:
    ///
    /// * Pointer kudu [valid] kanggo diwaca kanggo `ptr.len() * mem::size_of::<T>()` akeh bait, lan kudu didol kanthi bener.Iki tegese khusus:
    ///
    ///     * Kabeh rentang memori irisan iki kudu dikatutake ing obyek sing diparengake!
    ///       Irisan ora bisa ditemokake ing pirang-pirang obyek sing dialokasikan.
    ///
    ///     * Pointer kudu didadekake siji sanajan irisan dawa-nol.
    ///     Salah sawijining sebab yaiku optimisasi tata letak enum bisa uga gumantung karo referensi (kalebu irisan apa wae) sing selaras lan ora batal kanggo mbedakake saka data liyane.
    ///
    ///     Sampeyan bisa entuk pitunjuk sing bisa digunakake minangka `data` kanggo irisan dawa-nol nggunakake [`NonNull::dangling()`].
    ///
    /// * Ukuran total `ptr.len() * mem::size_of::<T>()` irisan kudu ora luwih gedhe tinimbang `isize::MAX`.
    ///   Deleng dokumentasi keamanan [`pointer::offset`].
    ///
    /// * Sampeyan kudu ngetrapake aturan aliasing Rust, amarga umur bali `'a` dipilih kanthi sewenang-wenang lan ora kudu nuduhake umur data sing nyata.
    ///   Utamane, sajrone urip iki, memori sing nuduhake poin ora kudu diowahi (kajaba ing `UnsafeCell`).
    ///
    /// Iki ditrapake sanajan asil saka metode iki ora digunakake!
    ///
    /// Deleng uga [`slice::from_raw_parts`][].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice<'a>(self) -> Option<&'a [MaybeUninit<T>]> {
        if self.is_null() {
            None
        } else {
            // SAFETY: panelpon kudu njaga kontrak keamanan kanggo `as_uninit_slice`.
            Some(unsafe { slice::from_raw_parts(self as *const MaybeUninit<T>, self.len()) })
        }
    }

    /// Ngasilake `None` yen pitunjuk batal, utawa ngasilake irisan unik menyang nilai sing dibungkus `Some`.
    /// Beda karo [`as_mut`], iki ora mbutuhake regane kudu diinisialisasi.
    ///
    /// Kanggo mitra sing dituduhake, waca [`as_uninit_slice`].
    ///
    /// [`as_mut`]: #method.as_mut
    /// [`as_uninit_slice`]: #method.as_uninit_slice-1
    ///
    /// # Safety
    ///
    /// Nalika nelpon metode iki, sampeyan kudu mriksa manawa *salah siji* pointer NULL *utawa* kabeh ing ngisor iki bener:
    ///
    /// * Pointer kudu [valid] kanggo maca lan nulis `ptr.len() * mem::size_of::<T>()` akeh byte, lan kudu didandani kanthi bener.Iki tegese khusus:
    ///
    ///     * Kabeh rentang memori irisan iki kudu dikatutake ing obyek sing diparengake!
    ///       Irisan ora bisa ditemokake ing pirang-pirang obyek sing dialokasikan.
    ///
    ///     * Pointer kudu didadekake siji sanajan irisan dawa-nol.
    ///     Salah sawijining sebab yaiku optimisasi tata letak enum bisa uga gumantung karo referensi (kalebu irisan apa wae) sing selaras lan ora batal kanggo mbedakake saka data liyane.
    ///
    ///     Sampeyan bisa entuk pitunjuk sing bisa digunakake minangka `data` kanggo irisan dawa-nol nggunakake [`NonNull::dangling()`].
    ///
    /// * Ukuran total `ptr.len() * mem::size_of::<T>()` irisan kudu ora luwih gedhe tinimbang `isize::MAX`.
    ///   Deleng dokumentasi keamanan [`pointer::offset`].
    ///
    /// * Sampeyan kudu ngetrapake aturan aliasing Rust, amarga umur bali `'a` dipilih kanthi sewenang-wenang lan ora kudu nuduhake umur data sing nyata.
    ///   Utamane, sajrone urip iki, memori sing nuduhake poin ora kudu diakses (diwaca utawa ditulis) liwat pitunjuk liyane.
    ///
    /// Iki ditrapake sanajan asil saka metode iki ora digunakake!
    ///
    /// Deleng uga [`slice::from_raw_parts_mut`][].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice_mut<'a>(self) -> Option<&'a mut [MaybeUninit<T>]> {
        if self.is_null() {
            None
        } else {
            // SAFETY: panelpon kudu njaga kontrak keamanan kanggo `as_uninit_slice_mut`.
            Some(unsafe { slice::from_raw_parts_mut(self as *mut MaybeUninit<T>, self.len()) })
        }
    }
}

// Kesetaraan kanggo petunjuk
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> PartialEq for *mut T {
    #[inline]
    fn eq(&self, other: &*mut T) -> bool {
        *self == *other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Eq for *mut T {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Ord for *mut T {
    #[inline]
    fn cmp(&self, other: &*mut T) -> Ordering {
        if self < other {
            Less
        } else if self == other {
            Equal
        } else {
            Greater
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> PartialOrd for *mut T {
    #[inline]
    fn partial_cmp(&self, other: &*mut T) -> Option<Ordering> {
        Some(self.cmp(other))
    }

    #[inline]
    fn lt(&self, other: &*mut T) -> bool {
        *self < *other
    }

    #[inline]
    fn le(&self, other: &*mut T) -> bool {
        *self <= *other
    }

    #[inline]
    fn gt(&self, other: &*mut T) -> bool {
        *self > *other
    }

    #[inline]
    fn ge(&self, other: &*mut T) -> bool {
        *self >= *other
    }
}