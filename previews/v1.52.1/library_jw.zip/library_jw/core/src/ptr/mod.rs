//! Ngatur memori kanthi manual liwat petunjuk mentah.
//!
//! *[See also the pointer primitive types](pointer).*
//!
//! # Safety
//!
//! Akeh fungsi ing modul iki sing nuduhake penunjuk mentah minangka argumen lan maca utawa nulis kanggo dheweke.Supaya aman, petunjuk iki kudu *valid*.
//! Apa penunjuk sing bener gumantung karo operasi sing digunakake (maca utawa nulis), lan ukuran memori sing diakses (yaiku, pinten bait read/written).
//! Umume fungsi nggunakake `*mut T` lan `* const T` kanggo ngakses mung siji nilai, ing endi dokumentasi ngilangi ukuran lan kanthi implisit nganggep dadi `size_of::<T>()` byte.
//!
//! Aturan sing bener kanggo validitas durung ditemtokake.Jaminan sing diwenehake saiki, paling tithik:
//!
//! * Pointer [null]*ora nate bener*, malah kanggo akses [size zero][zst].
//! * Supaya penunjuk bisa valid, perlu, nanging ora mesthi cekap, supaya penunjuk *ora bisa disenengi*: sawetara memori ukuran sing diwenehake wiwit saka penunjuk kabeh kudu ana ing wates obyek sing diparengake.
//!
//! Elinga yen ing Rust, saben variabel (stack-allocated) dianggep obyek sing dipisahake kanthi kapisah.
//! * Malah kanggo operasi saka [size zero][zst], pitunjuk ora kudu pointing menyang memori deallocated, IE, deallocation ndadekake penunjuk bener malah kanggo operasi nul-ukuran.
//! Nanging, casting sembarang integer *literal* menyang pointer ora valid kanggo akses ukuran nol, sanajan ana memori sing ana ing alamat kasebut lan entuk kesepakatan.
//! Iki cocog karo nulis alokasi dhewe: alokasi obyek ukuran nol ora angel banget.
//! Cara kanonik kanggo entuk pointer sing valid kanggo akses ukuran nol yaiku [`NonNull::dangling`].
//! * Kabeh akses sing ditindakake kanthi fungsi ing modul iki yaiku *non-atom* ing pangertene [atomic operations] sing digunakake kanggo nyinkronake ing antarane utas.
//! Iki tegese tumindak sing ora ditemtokake kanggo nindakake rong akses bebarengan menyang lokasi sing padha saka macem-macem utas kajaba loro-lorone ngakses mung diwaca saka memori.
//! Elinga yen kanthi jelas kalebu [`read_volatile`] lan [`write_volatile`]: Akses molah malih ora bisa digunakake kanggo sinkronisasi antar-benang.
//! * Asil casting referensi menyang pitunjuk bener yen obyek sing ndasari urip lan ora ana referensi (mung pitunjuk mentah) sing digunakake kanggo ngakses memori sing padha.
//!
//! Aksioma kasebut, uga nggunakake [`offset`] kanthi ati-ati kanggo aritmatika pointer, cukup kanggo ngetrapake akeh barang sing migunani ing kode sing ora aman.
//! Jaminan sing luwih kuat bakal kasedhiya, amarga aturan [aliasing] wis ditemtokake.
//! Kanggo informasi luwih lengkap, waca [book] uga bagean ing referensi sing dikhaskan kanggo [undefined behavior][ub].
//!
//! ## Alignment
//!
//! penunjuk mentahan bener ditetepake ndhuwur ora kudu mlaku didadekake siji (ngendi "proper" Alignment wis ditetepake dening jinis pointee, IE, `*const T` kudu didadekake siji kanggo `mem::align_of::<T>()`).
//! Nanging, umume fungsi mbutuhake argumen sing didadekake siji, lan kanthi tegas bakal nyuarakake syarat iki ing dokumentasi.
//! Istiméwa sing misuwur yaiku [`read_unaligned`] lan [`write_unaligned`].
//!
//! Nalika fungsi mbutuhake Alignment tepat, ora dadi malah yen akses wis ukuran 0, IE, malah yen memori ora bener kena.Coba gunakake [`NonNull::dangling`] ing kasus kasebut.
//!
//! [aliasing]: ../../nomicon/aliasing.html
//! [book]: ../../book/ch19-01-unsafe-rust.html#dereferencing-a-raw-pointer
//! [ub]: ../../reference/behavior-considered-undefined.html
//! [zst]: ../../nomicon/exotic-sizes.html#zero-sized-types-zsts
//! [atomic operations]: crate::sync::atomic
//! [`offset`]: pointer::offset
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering;
use crate::fmt;
use crate::hash;
use crate::intrinsics::{self, abort, is_aligned_and_not_null};
use crate::mem::{self, MaybeUninit};

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::copy_nonoverlapping;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::copy;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::write_bytes;

#[cfg(not(bootstrap))]
mod metadata;
#[cfg(not(bootstrap))]
pub(crate) use metadata::PtrRepr;
#[cfg(not(bootstrap))]
#[unstable(feature = "ptr_metadata", issue = "81513")]
pub use metadata::{from_raw_parts, from_raw_parts_mut, metadata, DynMetadata, Pointee, Thin};

mod non_null;
#[stable(feature = "nonnull", since = "1.25.0")]
pub use non_null::NonNull;

mod unique;
#[unstable(feature = "ptr_internals", issue = "none")]
pub use unique::Unique;

mod const_ptr;
mod mut_ptr;

/// Nglakokaké destruktor (yen ana) nilai sing dituduhake.
///
/// Iki padha karo semantik kanggo nyebut [`ptr::read`] lan mbuwang asil, nanging duwe kaluwihan kaya ing ngisor iki:
///
/// * *Dibutuhake* nggunakake `drop_in_place` kanggo nyelehake jinis tanpa ukuran kaya obyek trait, amarga ora bisa diwaca menyang tumpukan lan biasane mudhun.
///
/// * Iku friendlier kanggo Pangoptimal apa iki liwat [`ptr::read`] nalika nempel diparengake manual memori (eg, ing nindakake saka `Box`/`Rc`/`Vec`), minangka compiler ora perlu kanggo mbuktekaken sing swara iku kanggo Élide kanthi sub salinan.
///
///
/// * Bisa digunakake kanggo nyelehake data [pinned] nalika `T` dudu `repr(packed)` (data sing disematkan ora kudu dipindhah sadurunge diluncurake).
///
/// Nilai sing ora diselarasake ora bisa diluncurake, kudu disalin menyang lokasi sing didhasarake luwih dhisik nggunakake [`ptr::read_unaligned`].Kanggo strukture sing dikemas, langkah iki rampung kanthi otomatis dening compiler.
/// Iki tegese lapangan strukture sing dikemas ora dilebokake ing papane.
///
/// [`ptr::read`]: self::read
/// [`ptr::read_unaligned`]: self::read_unaligned
/// [pinned]: crate::pin
///
/// # Safety
///
/// Prilaku wis cetho yen kahanan ing ngisor iki sing nerak:
///
/// * `to_drop` kudu [valid] kanggo maca lan nulis.
///
/// * `to_drop` kudu selaras kanthi bener.
///
/// * Nilai `to_drop` poin kudu valid kanggo ngeculake, sing bisa uga tegese kudu nglindhungi undhangan tambahan, gumantung saka jinis iki.
///
/// Kajaba iku, yen `T` dudu [`Copy`], nggunakake nilai sing ditunjuk sawise nelpon `drop_in_place` bisa nyebabake tumindak sing durung mesthi.Elinga yen `*to_drop = foo` diitung minangka panggunaan amarga bakal nyebabake regane mudhun maneh.
/// [`write()`] bisa digunakake kanggo nimpa data tanpa nyebabake dicopot.
///
/// Elinga yen sanajan `T` duwe ukuran `0`, penunjuk kudu non-NUL lan selaras kanthi bener.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Mbusak item pungkasan kanthi manual saka vector:
///
/// ```
/// use std::ptr;
/// use std::rc::Rc;
///
/// let last = Rc::new(1);
/// let weak = Rc::downgrade(&last);
///
/// let mut v = vec![Rc::new(0), last];
///
/// unsafe {
///     // Entuk penunjuk mentah menyang elemen pungkasan ing `v`.
///     let ptr = &mut v[1] as *mut _;
///     // Cekak `v` supaya barang pungkasan ora bakal mudhun.
///     // Kita luwih dhisik, kanggo nyegah masalah yen `drop_in_place` ing ngisor panics.
///     v.set_len(1);
///     // Tanpa telpon `drop_in_place`, item pungkasan ora bakal ditinggal, lan memori sing dikelola bakal bocor.
/////
///     ptr::drop_in_place(ptr);
/// }
///
/// assert_eq!(v, &[0.into()]);
///
/// // Priksa manawa item pungkasan dijadwalake.
/// assert!(weak.upgrade().is_none());
/// ```
///
/// Elinga yen kompiler nindakake salinan iki kanthi otomatis nalika ngeculake strukture sing dikemas, yaiku, sampeyan ora biasane kuwatir karo masalah kaya ngono, kajaba sampeyan ngubungi `drop_in_place` kanthi manual.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "drop_in_place", since = "1.8.0")]
#[lang = "drop_in_place"]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // Kode ing kene ora masalah, iki diganti lem gulung asli saka kompilator.
    //

    // SAFETY: deleng komentar ing ndhuwur
    unsafe { drop_in_place(to_drop) }
}

/// Nggawe pointer mentah nol.
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let p: *const i32 = ptr::null();
/// assert!(p.is_null());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_ptr_null", since = "1.32.0")]
pub const fn null<T>() -> *const T {
    0 as *const T
}

/// Nggawe petunjuk mentah sing bisa diowahi.
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let p: *mut i32 = ptr::null_mut();
/// assert!(p.is_null());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_ptr_null", since = "1.32.0")]
pub const fn null_mut<T>() -> *mut T {
    0 as *mut T
}

#[cfg(bootstrap)]
#[repr(C)]
pub(crate) union Repr<T> {
    pub(crate) rust: *const [T],
    rust_mut: *mut [T],
    pub(crate) raw: FatPtr<T>,
}

#[cfg(bootstrap)]
#[repr(C)]
pub(crate) struct FatPtr<T> {
    data: *const T,
    pub(crate) len: usize,
}

#[cfg(bootstrap)]
// Manual implan dibutuhake supaya `T: Clone` ora kaiket.
impl<T> Clone for FatPtr<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[cfg(bootstrap)]
// Manual implan dibutuhake supaya `T: Copy` ora kaiket.
impl<T> Copy for FatPtr<T> {}

/// Mbentuk irisan mentah saka pitunjuk lan dawane.
///
/// Argumentasi `len` minangka nomer **elemen**, dudu jumlah bait.
///
/// Fungsi iki wis aman, nanging bener nggunakake nilai bali punika aman.
/// Deleng dokumentasi [`slice::from_raw_parts`] kanggo syarat keamanan irisan.
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
///
/// # Examples
///
/// ```rust
/// use std::ptr;
///
/// // nggawe irisan pitunjuk nalika diwiwiti karo pitunjuk menyang elemen pisanan
/// let x = [5, 6, 7];
/// let raw_pointer = x.as_ptr();
/// let slice = ptr::slice_from_raw_parts(raw_pointer, 3);
/// assert_eq!(unsafe { &*slice }[2], 7);
/// ```
#[inline]
#[stable(feature = "slice_from_raw_parts", since = "1.42.0")]
#[rustc_const_unstable(feature = "const_slice_from_raw_parts", issue = "67456")]
pub const fn slice_from_raw_parts<T>(data: *const T, len: usize) -> *const [T] {
    #[cfg(bootstrap)]
    {
        // SAFETY: Ngakses nilai saka serikat `Repr` aman wiwit * const [T]
        //
        // lan FatPtr duwe noto memori sing padha.Mung std sing bisa njamin.
        unsafe { Repr { raw: FatPtr { data, len } }.rust }
    }
    #[cfg(not(bootstrap))]
    from_raw_parts(data.cast(), len)
}

/// Performs fungsi sing padha minangka [`slice_from_raw_parts`], kejaba irisan mutable mentahan wis bali, minangka gantos kanggo irisan tetep mentahan.
///
///
/// Waca dokumentasi [`slice_from_raw_parts`] kanggo rincian liyane.
///
/// Fungsi iki wis aman, nanging bener nggunakake nilai bali punika aman.
/// Deleng dokumentasi [`slice::from_raw_parts_mut`] kanggo syarat keamanan irisan.
///
/// [`slice::from_raw_parts_mut`]: crate::slice::from_raw_parts_mut
///
/// # Examples
///
/// ```rust
/// use std::ptr;
///
/// let x = &mut [5, 6, 7];
/// let raw_pointer = x.as_mut_ptr();
/// let slice = ptr::slice_from_raw_parts_mut(raw_pointer, 3);
///
/// unsafe {
///     (*slice)[2] = 99; // menehi nilai ing indeks ing irisan
/// };
///
/// assert_eq!(unsafe { &*slice }[2], 99);
/// ```
#[inline]
#[stable(feature = "slice_from_raw_parts", since = "1.42.0")]
#[rustc_const_unstable(feature = "const_slice_from_raw_parts", issue = "67456")]
pub const fn slice_from_raw_parts_mut<T>(data: *mut T, len: usize) -> *mut [T] {
    #[cfg(bootstrap)]
    {
        // SAFETY: Ngakses nilai saka serikat `Repr` aman wiwit * mut [T]
        // lan FatPtr duwe noto memori sing padha
        unsafe { Repr { raw: FatPtr { data, len } }.rust_mut }
    }
    #[cfg(not(bootstrap))]
    from_raw_parts_mut(data.cast(), len)
}

/// Ganti angka ing rong lokasi sing bisa diowahi kanthi jinis sing padha, tanpa uga nggunakake deinitialisasi.
///
/// Nanging kanggo loro pangecualian ing ngisor iki, fungsi iki padha karo [`mem::swap`]:
///
///
/// * Makaryakke ing petunjuk mentah tinimbang referensi.
/// Yen kasedhiya referensi, [`mem::swap`] luwih disenengi.
///
/// * Rong nilai sing dituduhake bisa tumpang tindih.
/// Yen regane tumpang tindih, mula wilayah memori sing tumpang tindih saka `x` bakal digunakake.
/// Iki ditampilake ing conto kapindho ing ngisor iki.
///
/// # Safety
///
/// Prilaku wis cetho yen kahanan ing ngisor iki sing nerak:
///
/// * `x` lan `y` kudu [valid] kanggo maos lan nulis.
///
/// * `x` lan `y` kudu didadekake siji kanthi bener.
///
/// Elinga yen sanajan `T` duwe ukuran `0`, pointer kudu non-NULL lan selaras kanthi bener.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Ganti rong wilayah sing ora tumpang tindih:
///
/// ```
/// use std::ptr;
///
/// let mut array = [0, 1, 2, 3];
///
/// let x = array[0..].as_mut_ptr() as *mut [u32; 2]; // iki `array[0..2]`
/// let y = array[2..].as_mut_ptr() as *mut [u32; 2]; // iki `array[2..4]`
///
/// unsafe {
///     ptr::swap(x, y);
///     assert_eq!([2, 3, 0, 1], array);
/// }
/// ```
///
/// Ganti rong wilayah sing tumpang tindih:
///
/// ```
/// use std::ptr;
///
/// let mut array = [0, 1, 2, 3];
///
/// let x = array[0..].as_mut_ptr() as *mut [u32; 3]; // iki `array[0..3]`
/// let y = array[1..].as_mut_ptr() as *mut [u32; 3]; // iki `array[1..4]`
///
/// unsafe {
///     ptr::swap(x, y);
///     // Indeks `1..3` irisan tumpang tindih antarane `x` lan `y`.
///     // asil cukup bakal kanggo wong-wong mau dadi `[2, 3]`, supaya indeks `0..3` sing `[1, 2, 3]` (cocog `y` sadurunge `swap`);utawa supaya `[0, 1]` dadi indeks `1..4` yaiku `[0, 1, 2]` (cocog karo `x` sadurunge `swap`).
/////
///     // Pelaksanaan iki ditetepake kanggo nggawe pilihan sing terakhir.
/////
///     assert_eq!([1, 0, 1, 2], array);
/// }
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
pub const unsafe fn swap<T>(x: *mut T, y: *mut T) {
    // Wenehi papan ringkes kanggo nggarap awake dhewe.
    // Kita ora prelu kuwatir tetes: `MaybeUninit` ora nindakake apa-apa nalika mudhun.
    let mut tmp = MaybeUninit::<T>::uninit();

    // Nindakake SAFETY pertukaran: panelpon kudu njamin yen `x` lan `y` bener kanggo nulis lan didadekake siji kanthi bener.
    // `tmp` ora bisa tumpang tindih `x` utawa `y` amarga `tmp` mung diparengake ing tumpukan minangka obyek sing dialokasikan kanthi kapisah.
    //
    //
    //
    unsafe {
        copy_nonoverlapping(x, tmp.as_mut_ptr(), 1);
        copy(y, x, 1); // `x` lan `y` bisa tumpang tindih
        copy_nonoverlapping(tmp.as_ptr(), y, 1);
    }
}

/// Ganti byte `count * size_of::<T>()` ing antarane rong wilayah memori diwiwiti ing `x` lan `y`.
/// Kaloro wilayah kasebut kudu * ora tumpang tindih.
///
/// # Safety
///
/// Prilaku wis cetho yen kahanan ing ngisor iki sing nerak:
///
/// * Kalorone `x` lan `y` kudu [valid] kanggo loro maca lan nulis `count *
///   size_of: :<T>() `bait.
///
/// * `x` lan `y` kudu didadekake siji kanthi bener.
///
/// * Wilayah memori diwiwiti `x` kanthi ukuran `count *
///   size_of: :<T>() `bait kudu *ora* tumpang tindih karo wilayah memori wiwit `y` kanthi ukuran sing padha.
///
/// Elinga yen sanajan ukuran sing disalin kanthi efektif (`count * size_of: :<T>():) Iku `0`, penunjuk kudu non-NULL lan didadekake siji mlaku.
///
///
/// [valid]: self#safety
///
/// # Examples
///
/// Panggunaan dhasar:
///
/// ```
/// use std::ptr;
///
/// let mut x = [1, 2, 3, 4];
/// let mut y = [7, 8, 9];
///
/// unsafe {
///     ptr::swap_nonoverlapping(x.as_mut_ptr(), y.as_mut_ptr(), 2);
/// }
///
/// assert_eq!(x, [7, 8, 3, 4]);
/// assert_eq!(y, [1, 2, 9]);
/// ```
///
#[inline]
#[stable(feature = "swap_nonoverlapping", since = "1.27.0")]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
pub const unsafe fn swap_nonoverlapping<T>(x: *mut T, y: *mut T, count: usize) {
    let x = x as *mut u8;
    let y = y as *mut u8;
    let len = mem::size_of::<T>() * count;
    // SAFETY: panelpon kudu njamin yen `x` lan `y`
    // bener kanggo nyerat lan didadekake siji mlaku.
    unsafe { swap_nonoverlapping_bytes(x, y, len) }
}

#[inline]
pub(crate) unsafe fn swap_nonoverlapping_one<T>(x: *mut T, y: *mut T) {
    // Kanggo jinis sing luwih cilik tinimbang optimasi blok ing ngisor iki, cukup langsung pertukaran supaya ora codegen sing pesimis.
    //
    if mem::size_of::<T>() < 32 {
        // SAFETY: panelpon kudu njamin yen `x` lan `y` bener
        // kanggo nulis, selaras kanthi bener, lan ora tumpang tindih.
        unsafe {
            let z = read(x);
            copy_nonoverlapping(y, x, 1);
            write(y, z);
        }
    } else {
        // SAFETY: panelpon kudu njaga kontrak keamanan kanggo `swap_nonoverlapping`.
        unsafe { swap_nonoverlapping(x, y, 1) };
    }
}

#[inline]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
const unsafe fn swap_nonoverlapping_bytes(x: *mut u8, y: *mut u8, len: usize) {
    // Pendekatan ing kene yaiku nggunakake simd kanggo pertukaran x&y kanthi efisien.
    // Tes nuduhake manawa ngganti 32 byte utawa 64 byte sekaligus paling efisien kanggo prosesor Intel Haswell E.
    // LLVM luwih bisa ngoptimalake yen menehi strukture #[repr(simd)], sanajan ora nggunakake langsung strukture iki kanthi langsung.
    //
    //
    // FIXME repr(simd) rusak ing emscripten lan redox
    #[cfg_attr(not(any(target_os = "emscripten", target_os = "redox")), repr(simd))]
    struct Block(u64, u64, u64, u64);
    struct UnalignedBlock(u64, u64, u64, u64);

    let block_size = mem::size_of::<Block>();

    // Loop liwat x&y, salin `Block` sekaligus Pangoptimal kudu mbuka gelung kanthi akeh kanggo jinis NB
    // Kita ora bisa nggunakake loop kanggo impl `range` nelpon `mem::swap` kanthi rekursif
    //
    let mut i = 0;
    while i + block_size <= len {
        // Gawe sawetara memori sing ora diresmine minangka ruang ngeruk Ngandharake `t` ing kene supaya ora nyetel tumpukan nalika loop iki ora digunakake
        //
        let mut t = mem::MaybeUninit::<Block>::uninit();
        let t = t.as_mut_ptr() as *mut u8;

        // SAFETY: Minangka `i < len`, lan minangka njamin panelpon kudu sing `x` lan `y` sing bener
        // kanggo bait `len`, `x + i` lan `y + i` kudu alamat sing bener, sing memenuhi kontrak keamanan kanggo `add`.
        //
        // Uga, panelpon kudu njamin manawa `x` lan `y` bener kanggo nulis, didadekake siji, lan ora tumpang tindih, sing ngrampungake kontrak keamanan kanggo `copy_nonoverlapping`.
        //
        //
        unsafe {
            let x = x.add(i);
            let y = y.add(i);

            // Kundasang pemblokiran bita saka x&y, nggunakake t minangka sanggan sawetara iki kudu optimized menyang operasi SIMD efisien ngendi kasedhiya
            //
            copy_nonoverlapping(x, t, block_size);
            copy_nonoverlapping(y, x, block_size);
            copy_nonoverlapping(t, y, block_size);
        }
        i += block_size;
    }

    if i < len {
        // Tukar bait sing isih ana
        let mut t = mem::MaybeUninit::<UnalignedBlock>::uninit();
        let rem = len - i;

        let t = t.as_mut_ptr() as *mut u8;

        // SAFETY: deleng komentar keamanan sadurunge.
        unsafe {
            let x = x.add(i);
            let y = y.add(i);

            copy_nonoverlapping(x, t, rem);
            copy_nonoverlapping(y, x, rem);
            copy_nonoverlapping(t, y, rem);
        }
    }
}

/// Pindhah `src` menyang `dst` sing runcing, ngasilake angka `dst` sadurunge.
///
/// Ora ana regane sing mudhun.
///
/// Fungsi iki padha karo semantik [`mem::replace`] kajaba sing dienggo ing petunjuk mentah tinimbang referensi.
/// Yen kasedhiya referensi, [`mem::replace`] luwih disenengi.
///
/// # Safety
///
/// Prilaku wis cetho yen kahanan ing ngisor iki sing nerak:
///
/// * `dst` kudu [valid] kanggo maca lan nulis.
///
/// * `dst` kudu selaras kanthi bener.
///
/// * `dst` kudu nuduhake angka inisialisasi kanthi bener jinis `T`.
///
/// Elinga yen sanajan `T` duwe ukuran `0`, penunjuk kudu non-NUL lan selaras kanthi bener.
///
/// [valid]: self#safety
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let mut rust = vec!['b', 'u', 's', 't'];
///
/// // `mem::replace` bakal duwe efek sing padha tanpa mbutuhake blokir sing ora aman.
/////
/// let b = unsafe {
///     ptr::replace(&mut rust[0], 'r')
/// };
///
/// assert_eq!(b, 'b');
/// assert_eq!(rust, &['r', 'u', 's', 't']);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn replace<T>(dst: *mut T, mut src: T) -> T {
    // SAFETY: panelpon kudu njamin yen `dst` bener
    // diluncurake menyang referensi sing bisa diowahi (bener kanggo nulis, didadekake siji, diwiwiti) lan ora bisa tumpang tindih `src` amarga `dst` kudu nuduhake obyek sing dialokasikan kanthi beda.
    //
    //
    unsafe {
        mem::swap(&mut *dst, &mut src); // ora bisa tumpang tindih
    }
    src
}

/// Maca regane saka `src` tanpa mindhah.Iki ndadekake memori ing `src` ora owah.
///
/// # Safety
///
/// Prilaku wis cetho yen kahanan ing ngisor iki sing nerak:
///
/// * `src` kudu [valid] kanggo maca.
///
/// * `src` kudu selaras kanthi bener.Gunakake [`read_unaligned`] yen ora kaya ngono.
///
/// * `src` kudu nuduhake angka inisialisasi kanthi bener jinis `T`.
///
/// Elinga yen sanajan `T` duwe ukuran `0`, penunjuk kudu non-NUL lan selaras kanthi bener.
///
/// # Examples
///
/// Panggunaan dhasar:
///
/// ```
/// let x = 12;
/// let y = &x as *const i32;
///
/// unsafe {
///     assert_eq!(std::ptr::read(y), 12);
/// }
/// ```
///
/// Kanthi manual ngleksanakake [`mem::swap`]:
///
/// ```
/// use std::ptr;
///
/// fn swap<T>(a: &mut T, b: &mut T) {
///     unsafe {
///         // Gawe salinan bitwise regane ing `a` ing `tmp`.
///         let tmp = ptr::read(a);
///
///         // Metu ing titik iki (kanthi kanthi jelas bali utawa nelpon fungsi sing panics) bakal nyebabake nilai ing `tmp` bakal mudhun nalika nilai sing padha isih dirujuk dening `a`.
///         // Iki bisa nyebabake tumindak sing ora ditemtokake yen `T` dudu `Copy`.
/////
/////
///
///         // Gawe salinan bitwise regane ing `b` ing `a`.
///         // Iki aman amarga referensi sing ora bisa diowahi ora bisa alias.
///         ptr::copy_nonoverlapping(b, a, 1);
///
///         // Kaya ing ndhuwur, metu ing kene bisa nyebabake prilaku sing durung ditemtokake amarga nilai sing padha dirujuk dening `a` lan `b`.
/////
///
///         // Pindhah `tmp` dadi `b`.
///         ptr::write(b, tmp);
///
///         // `tmp` wis dipindhah (`write` duwe kepemilikan argumen sing nomer loro), mula ora ana sing diluncurake kanthi implisit ing kene.
/////
///     }
/// }
///
/// let mut foo = "foo".to_owned();
/// let mut bar = "bar".to_owned();
///
/// swap(&mut foo, &mut bar);
///
/// assert_eq!(foo, "bar");
/// assert_eq!(bar, "foo");
/// ```
///
/// ## Kepemilikan Nilai sing Dikembalikan
///
/// `read` nggawe salinan bitwise `T`, ora preduli apa `T` yaiku [`Copy`].
/// Yen `T` dudu [`Copy`], nggunakake nilai bali lan nilai ing `*src` bisa nglanggar keamanan memori.
/// Elinga yen menehi tugas menyang `*src` dianggep minangka panggunaan amarga bakal nyoba nyelehake regane ing `* src`.
///
/// [`write()`] bisa digunakake kanggo nimpa data tanpa nyebabake dicopot.
///
/// ```
/// use std::ptr;
///
/// let mut s = String::from("foo");
/// unsafe {
///     // `s2` saiki nilai kanggo memori ndasari padha `s`.
///     let mut s2: String = ptr::read(&s);
///
///     assert_eq!(s2, "foo");
///
///     // Nugasake menyang `s2` nyebabake nilai asline mudhun.
///     // Nglangkungi titik iki, `s` ora kudu digunakake maneh, amarga memori sing ndasari wis dibebasake.
/////
///     s2 = String::default();
///     assert_eq!(s2, "");
///
///     // Menehi tugas menyang `s` bakal nyebabake nilai lawas bakal mudhun maneh, nyebabake tumindak sing ora ditemtokake.
/////
///     // s= String::from("bar");//Kesalahan
///
///     // `ptr::write` bisa digunakake kanggo nimpa nilai tanpa ngeculake.
///     ptr::write(&mut s, String::from("bar"));
/// }
///
/// assert_eq!(s, "bar");
/// ```
///
/// [valid]: self#safety
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
pub const unsafe fn read<T>(src: *const T) -> T {
    let mut tmp = MaybeUninit::<T>::uninit();
    // SAFETY: panelpon kudu njamin yen `src` bener kanggo diwaca.
    // `src` ora bisa tumpang tindih `tmp` amarga `tmp` mung diparengake ing tumpukan minangka obyek sing diparengake kapisah.
    //
    //
    // Uga, amarga mung nulis angka sing valid menyang `tmp`, sampeyan bakal diinalisasi kanthi bener.
    //
    unsafe {
        copy_nonoverlapping(src, tmp.as_mut_ptr(), 1);
        tmp.assume_init()
    }
}

/// Maca regane saka `src` tanpa mindhah.Iki ndadekake memori ing `src` ora owah.
///
/// Ora kaya [`read`], `read_unaligned` bisa digunakake kanthi petunjuk sing ora larut.
///
/// # Safety
///
/// Prilaku wis cetho yen kahanan ing ngisor iki sing nerak:
///
/// * `src` kudu [valid] kanggo maca.
///
/// * `src` kudu nuduhake angka inisialisasi kanthi bener jinis `T`.
///
/// Kaya [`read`], `read_unaligned` nggawe salinan bitwise `T`, ora preduli apa `T` yaiku [`Copy`].
/// Yen `T` dudu [`Copy`], nggunakake nilai bali lan nilai ing `*src` bisa [violate memory safety][read-ownership].
///
/// Elinga yen sanajan `T` duwe ukuran `0`, pointer kudu non-NULL.
///
/// [read-ownership]: read#ownership-of-the-returned-value
/// [valid]: self#safety
///
/// ## Ing strukture `packed`
///
/// Saiki ora bisa nggawe pitunjuk mentah menyang kolom sing durung larang saka strukture sing dikemas.
///
/// Nyoba nggawe pointer mentah menyang kolom strukture `unaligned` kanthi ekspresi kayata `&packed.unaligned as *const FieldType` nggawe referensi sing ora larang tengah sadurunge diowahi dadi pitunjuk mentah.
///
/// Sing referensi iki sauntara lan langsung matak iku inconsequential minangka compiler tansah ngarepake referensi kanggo sekuthon mlaku.
/// Asile, nggunakake `&packed.unaligned as *const FieldType` nyebabake* tumindak sing durung ditemtokake * ing program sampeyan.
///
/// Tuladha sing ora kudu ditindakake lan kepiye hubungane karo `read_unaligned` yaiku:
///
/// ```no_run
/// #[repr(packed, C)]
/// struct Packed {
///     _padding: u8,
///     unaligned: u32,
/// }
///
/// let packed = Packed {
///     _padding: 0x00,
///     unaligned: 0x01020304,
/// };
///
/// let v = unsafe {
///     // Kene kita nyoba kanggo njupuk alamat saka ongko 32-dicokot kang ora didadekake siji.
///     let unaligned =
///         // Referensi unaligned sementara digawe ing kene sing nyebabake tumindak ora mesthi preduli digunakake utawa ora referensi kasebut.
/////
///         &packed.unaligned
///         // Ngirim pointer mentah ora mbantu;kesalahan wis kelakon.
///         as *const u32;
///
///     let v = std::ptr::read_unaligned(unaligned);
///
///     v
/// };
/// ```
///
/// Ngakses lapangan sing ora diresmike langsung karo eg `packed.unaligned` nanging aman.
///
///
///
///
///
///
// FIXME: Nganyari dokumen adhedhasar asil RFC #2582 lan kanca.
/// # Examples
///
/// Waca regane usize saka buffer bait:
///
/// ```
/// use std::mem;
///
/// fn read_usize(x: &[u8]) -> usize {
///     assert!(x.len() >= mem::size_of::<usize>());
///
///     let ptr = x.as_ptr() as *const usize;
///
///     unsafe { ptr.read_unaligned() }
/// }
/// ```
#[inline]
#[stable(feature = "ptr_unaligned", since = "1.17.0")]
#[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
pub const unsafe fn read_unaligned<T>(src: *const T) -> T {
    let mut tmp = MaybeUninit::<T>::uninit();
    // SAFETY: panelpon kudu njamin yen `src` bener kanggo diwaca.
    // `src` ora bisa tumpang tindih `tmp` amarga `tmp` mung diparengake ing tumpukan minangka obyek sing diparengake kapisah.
    //
    //
    // Uga, amarga mung nulis angka sing valid menyang `tmp`, sampeyan bakal diinalisasi kanthi bener.
    //
    unsafe {
        copy_nonoverlapping(src as *const u8, tmp.as_mut_ptr() as *mut u8, mem::size_of::<T>());
        tmp.assume_init()
    }
}

/// Nulis lokasi memori kanthi nilai tartamtu tanpa maca utawa ngeculake nilai lawas.
///
/// `write` ora ngeculake isi `dst`.
/// Iki aman, nanging bisa menehi alokasi utawa sumber daya bocor, mula kudu ati-ati supaya ora nimpa obyek sing bakal dicopot.
///
///
/// Kajaba iku, ora ngeculake `src`.Secara semi, `src` dipindhah menyang lokasi sing dituduhake dening `dst`.
///
/// Iki cocog kanggo miwiti memori sing durung diresmine, utawa nimpa memori sing sadurunge wis [`read`] saka.
///
/// # Safety
///
/// Prilaku wis cetho yen kahanan ing ngisor iki sing nerak:
///
/// * `dst` kudu [valid] kanggo nulis.
///
/// * `dst` kudu selaras kanthi bener.Gunakake [`write_unaligned`] yen ora kaya ngono.
///
/// Elinga yen sanajan `T` duwe ukuran `0`, penunjuk kudu non-NUL lan selaras kanthi bener.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Panggunaan dhasar:
///
/// ```
/// let mut x = 0;
/// let y = &mut x as *mut i32;
/// let z = 12;
///
/// unsafe {
///     std::ptr::write(y, z);
///     assert_eq!(std::ptr::read(y), 12);
/// }
/// ```
///
/// Kanthi manual ngleksanakake [`mem::swap`]:
///
/// ```
/// use std::ptr;
///
/// fn swap<T>(a: &mut T, b: &mut T) {
///     unsafe {
///         // Gawe salinan bitwise regane ing `a` ing `tmp`.
///         let tmp = ptr::read(a);
///
///         // Metu ing titik iki (kanthi kanthi jelas bali utawa nelpon fungsi sing panics) bakal nyebabake nilai ing `tmp` bakal mudhun nalika nilai sing padha isih dirujuk dening `a`.
///         // Iki bisa nyebabake tumindak sing ora ditemtokake yen `T` dudu `Copy`.
/////
/////
///
///         // Gawe salinan bitwise regane ing `b` ing `a`.
///         // Iki aman amarga referensi sing ora bisa diowahi ora bisa alias.
///         ptr::copy_nonoverlapping(b, a, 1);
///
///         // Kaya ing ndhuwur, metu ing kene bisa nyebabake prilaku sing durung ditemtokake amarga nilai sing padha dirujuk dening `a` lan `b`.
/////
///
///         // Pindhah `tmp` dadi `b`.
///         ptr::write(b, tmp);
///
///         // `tmp` wis dipindhah (`write` duwe kepemilikan argumen sing nomer loro), mula ora ana sing diluncurake kanthi implisit ing kene.
/////
///     }
/// }
///
/// let mut foo = "foo".to_owned();
/// let mut bar = "bar".to_owned();
///
/// swap(&mut foo, &mut bar);
///
/// assert_eq!(foo, "bar");
/// assert_eq!(bar, "foo");
/// ```
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn write<T>(dst: *mut T, src: T) {
    // Kita langsung nelpon intrinsik kanggo ngindhari panggilan fungsi ing kode sing digawe amarga `intrinsics::copy_nonoverlapping` minangka fungsi pambungkus.
    //
    extern "rust-intrinsic" {
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // SAFETY: panelpon kudu njamin yen `dst` bener kanggo nulis.
    // `dst` ora bisa tumpang tindih `src` amarga panelpon duwe akses sing bisa diowahi menyang `dst` nalika `src` duweke fungsi iki.
    //
    unsafe {
        copy_nonoverlapping(&src as *const T, dst, 1);
        intrinsics::forget(src);
    }
}

/// Nulis lokasi memori kanthi nilai tartamtu tanpa maca utawa ngeculake nilai lawas.
///
/// Beda karo [`write()`], pointer bisa uga sejajar.
///
/// `write_unaligned` ora ngeculake isi `dst`.Iki aman, nanging bisa bocor allocations utawa sumber daya, supaya care kudu dijupuk ora kanggo Panganggoan obyek sing kudu dropped.
///
/// Kajaba iku, ora ngeculake `src`.Secara semi, `src` dipindhah menyang lokasi sing dituduhake dening `dst`.
///
/// Iki cocok kanggo dhisik memori uninitialized, utawa Nibani memori sing wis tau maca karo [`read_unaligned`].
///
/// # Safety
///
/// Prilaku wis cetho yen kahanan ing ngisor iki sing nerak:
///
/// * `dst` kudu [valid] kanggo nulis.
///
/// Elinga yen sanajan `T` duwe ukuran `0`, pointer kudu non-NULL.
///
/// [valid]: self#safety
///
/// ## Ing strukture `packed`
///
/// Saiki ora bisa nggawe pitunjuk mentah menyang kolom sing durung larang saka strukture sing dikemas.
///
/// Nyoba nggawe pointer mentah menyang kolom strukture `unaligned` kanthi ekspresi kayata `&packed.unaligned as *const FieldType` nggawe referensi sing ora larang tengah sadurunge diowahi dadi pitunjuk mentah.
///
/// Sing referensi iki sauntara lan langsung matak iku inconsequential minangka compiler tansah ngarepake referensi kanggo sekuthon mlaku.
/// Asile, nggunakake `&packed.unaligned as *const FieldType` nyebabake* tumindak sing durung ditemtokake * ing program sampeyan.
///
/// Tuladha sing ora kudu ditindakake lan kepiye hubungane karo `write_unaligned` yaiku:
///
/// ```no_run
/// #[repr(packed, C)]
/// struct Packed {
///     _padding: u8,
///     unaligned: u32,
/// }
///
/// let v = 0x01020304;
/// let mut packed: Packed = unsafe { std::mem::zeroed() };
///
/// let v = unsafe {
///     // Kene kita nyoba kanggo njupuk alamat saka ongko 32-dicokot kang ora didadekake siji.
///     let unaligned =
///         // Referensi unaligned sementara digawe ing kene sing nyebabake tumindak ora mesthi preduli digunakake utawa ora referensi kasebut.
/////
///         &mut packed.unaligned
///         // Ngirim pointer mentah ora mbantu;kesalahan wis kelakon.
///         as *mut u32;
///
///     std::ptr::write_unaligned(unaligned, v);
///
///     v
/// };
/// ```
///
/// Ngakses lapangan sing ora diresmike langsung karo eg `packed.unaligned` nanging aman.
///
///
///
///
///
///
///
///
///
// FIXME: Nganyari dokumen adhedhasar asil RFC #2582 lan kanca.
/// # Examples
///
/// Tulis nilai usize menyang buffer bait:
///
/// ```
/// use std::mem;
///
/// fn write_usize(x: &mut [u8], val: usize) {
///     assert!(x.len() >= mem::size_of::<usize>());
///
///     let ptr = x.as_mut_ptr() as *mut usize;
///
///     unsafe { ptr.write_unaligned(val) }
/// }
/// ```
#[inline]
#[stable(feature = "ptr_unaligned", since = "1.17.0")]
#[rustc_const_unstable(feature = "const_ptr_write", issue = "none")]
pub const unsafe fn write_unaligned<T>(dst: *mut T, src: T) {
    // SAFETY: panelpon kudu njamin yen `dst` bener kanggo nulis.
    // `dst` ora bisa tumpang tindih `src` amarga panelpon duwe akses sing bisa diowahi menyang `dst` nalika `src` duweke fungsi iki.
    //
    unsafe {
        copy_nonoverlapping(&src as *const T as *const u8, dst as *mut u8, mem::size_of::<T>());
        // Kita langsung nelpon intrinsik kanggo ngindhari panggilan fungsi ing kode sing digawe.
        intrinsics::forget(src);
    }
}

/// Nindakake maca kanthi stabil babagan regane saka `src` tanpa mindhah.Iki ndadekake memori ing `src` ora owah.
///
/// Operasi volatil ditrapake kanggo tumindak ing memori I/O, lan dijamin ora bakal dipilih utawa diatur maneh dening kompiler ing antarane operasi liyane sing ora stabil.
///
/// # Notes
///
/// Rust ora saiki duwe model memori kaku lan formal ditetepake, supaya semantik pas apa "volatile" tegese punika tundhuk pangowahan liwat wektu.
/// Kang ngandika, ing semantik bakal meh tansah mungkasi munggah cantik padha [C11's definition of volatile][c11].
///
/// Kompilator ngirim ora ngganti urutan relatif utawa sawetara operasi memori sing ora stabil.
/// Nanging, operasi memori sing ora stabil ing jinis ukuran nol (kayata, yen jinis ukuran nol diterusake menyang `read_volatile`) ora bakal katon lan bisa uga ora digatekake.
///
/// [c11]: http://www.open-std.org/jtc1/sc22/wg14/www/docs/n1570.pdf
///
/// # Safety
///
/// Prilaku wis cetho yen kahanan ing ngisor iki sing nerak:
///
/// * `src` kudu [valid] kanggo maca.
///
/// * `src` kudu selaras kanthi bener.
///
/// * `src` kudu nuduhake angka inisialisasi kanthi bener jinis `T`.
///
/// Kaya [`read`], `read_volatile` nggawe salinan bitwise `T`, ora preduli apa `T` yaiku [`Copy`].
/// Yen `T` dudu [`Copy`], nggunakake nilai bali lan nilai ing `*src` bisa [violate memory safety][read-ownership].
/// Nanging, nyimpen non [: Copy`] jinis ing memori molah malih meh mesthi salah.
///
/// Elinga yen sanajan `T` duwe ukuran `0`, penunjuk kudu non-NUL lan selaras kanthi bener.
///
/// [valid]: self#safety
/// [read-ownership]: read#ownership-of-the-returned-value
///
/// Kaya ing C, manawa operasi ora stabil, ora ana gandhengane karo pitakonan babagan akses bebarengan saka macem-macem utas.Akses volatil tumindak persis kaya akses non-atom ing gati.
///
/// Utamane, balapan ing antarane `read_volatile` lan operasi nulis menyang lokasi sing padha yaiku tumindak sing durung ditemtokake.
///
/// # Examples
///
/// Panggunaan dhasar:
///
/// ```
/// let x = 12;
/// let y = &x as *const i32;
///
/// unsafe {
///     assert_eq!(std::ptr::read_volatile(y), 12);
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "volatile", since = "1.9.0")]
pub unsafe fn read_volatile<T>(src: *const T) -> T {
    if cfg!(debug_assertions) && !is_aligned_and_not_null(src) {
        // Ora panicking supaya impact codegen cilik.
        abort();
    }
    // SAFETY: panelpon kudu njaga kontrak keamanan kanggo `volatile_load`.
    unsafe { intrinsics::volatile_load(src) }
}

/// Nindakake nulis babagan lokasi memori kanthi molah malih kanthi nilai tartamtu tanpa maca utawa ngeculake nilai lawas.
///
/// Operasi volatil ditrapake kanggo tumindak ing memori I/O, lan dijamin ora bakal dipilih utawa diatur maneh dening kompiler ing antarane operasi liyane sing ora stabil.
///
/// `write_volatile` ora ngeculake isi `dst`.Iki aman, nanging bisa bocor allocations utawa sumber daya, supaya care kudu dijupuk ora kanggo Panganggoan obyek sing kudu dropped.
///
/// Kajaba iku, ora ngeculake `src`.Secara semi, `src` dipindhah menyang lokasi sing dituduhake dening `dst`.
///
/// # Notes
///
/// Rust ora saiki duwe model memori kaku lan formal ditetepake, supaya semantik pas apa "volatile" tegese punika tundhuk pangowahan liwat wektu.
/// Kang ngandika, ing semantik bakal meh tansah mungkasi munggah cantik padha [C11's definition of volatile][c11].
///
/// Kompilator ngirim ora ngganti urutan relatif utawa sawetara operasi memori sing ora stabil.
/// Nanging, operasi memori sing ora stabil ing jinis ukuran nol (kayata, yen jinis ukuran nol diterusake menyang `write_volatile`) ora bakal katon lan bisa uga ora digatekake.
///
/// [c11]: http://www.open-std.org/jtc1/sc22/wg14/www/docs/n1570.pdf
///
/// # Safety
///
/// Prilaku wis cetho yen kahanan ing ngisor iki sing nerak:
///
/// * `dst` kudu [valid] kanggo nulis.
///
/// * `dst` kudu selaras kanthi bener.
///
/// Elinga yen sanajan `T` duwe ukuran `0`, penunjuk kudu non-NUL lan selaras kanthi bener.
///
/// [valid]: self#safety
///
/// Kaya ing C, manawa operasi ora stabil, ora ana gandhengane karo pitakonan babagan akses bebarengan saka macem-macem utas.Akses volatil tumindak persis kaya akses non-atom ing gati.
///
/// Ing tartamtu, lomba antarane `write_volatile` lan operasi liyané (maca utawa nulis) ing panggonan sing padha iku prilaku cetho.
///
/// # Examples
///
/// Panggunaan dhasar:
///
/// ```
/// let mut x = 0;
/// let y = &mut x as *mut i32;
/// let z = 12;
///
/// unsafe {
///     std::ptr::write_volatile(y, z);
///     assert_eq!(std::ptr::read_volatile(y), 12);
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "volatile", since = "1.9.0")]
pub unsafe fn write_volatile<T>(dst: *mut T, src: T) {
    if cfg!(debug_assertions) && !is_aligned_and_not_null(dst) {
        // Ora panicking supaya impact codegen cilik.
        abort();
    }
    // SAFETY: panelpon kudu njaga kontrak keamanan kanggo `volatile_store`.
    unsafe {
        intrinsics::volatile_store(dst, src);
    }
}

/// Selaras pointer `p`.
///
/// Ngetung nutup kerugian (ing babagan unsur langkah `stride`) sing kudu ditrapake menyang pointer `p` saengga penunjuk `p` bisa didadekake siji karo `a`.
///
/// Note: implementasine iki wis kasebut kanthi teliti, ngarang ora panic.Iku UB iki kanggo panic.
/// Siji-sijine pangowahan nyata sing bisa ditindakake ing kene yaiku pangowahan `INV_TABLE_MOD_16` lan konstanta sing gegandhengan.
///
/// Yen kita mutusake supaya bisa nyebut intrinsik karo `a` sing dudu kekuwatan loro, bisa uga luwih wicaksana yen mung ngganti implementasi naif tinimbang nyoba adaptasi iki kanggo nampa pangowahan kasebut.
///
///
/// Ana pitakon menyang@nagisa.
///
///
///
#[lang = "align_offset"]
pub(crate) unsafe fn align_offset<T: Sized>(p: *const T, a: usize) -> usize {
    // FIXME(#75598): Panganggone langsung intrinsik kasebut nambah codegen kanthi signifikan ing level opt <=
    // 1, ing endi versi metode operasi kasebut ora digarisake.
    use intrinsics::{
        unchecked_shl, unchecked_shr, unchecked_sub, wrapping_add, wrapping_mul, wrapping_sub,
    };

    /// Ngetung kuwalik modular multiplikatif saka `x` modulo `m`.
    ///
    /// Implementasine iki dirancang kanggo `align_offset` lan duwe prasyarat kaya ing ngisor iki:
    ///
    /// * `m` yaiku kekuwatan-saka-loro;
    /// * `x < m`; (yen `x ≥ m`, pass `x % m`)
    ///
    /// Implementasi fungsi iki ora bakal panic.Wis tau.
    #[inline]
    unsafe fn mod_inv(x: usize, m: usize) -> usize {
        /// Tabel modular kuwalik modular multiplikasi 2⁴=16.
        ///
        /// Elinga, tabel iki ora ngemot nilai-nilai sing ora ana kuwalik (yaiku, kanggo `0⁻¹ mod 16`, `2⁻¹ mod 16`, lsp)
        ///
        const INV_TABLE_MOD_16: [u8; 8] = [1, 11, 13, 7, 9, 3, 5, 15];
        /// Modulo sing dimaksudake `INV_TABLE_MOD_16`.
        const INV_TABLE_MOD: usize = 16;
        /// INV_TABLE_MOD²
        const INV_TABLE_MOD_SQUARED: usize = INV_TABLE_MOD * INV_TABLE_MOD;

        let table_inverse = INV_TABLE_MOD_16[(x & (INV_TABLE_MOD - 1)) >> 1] as usize;
        // KESELAMATAN: `m` dibutuhake kanggo kekuwatan-saka-loro, mula ora nol.
        let m_minus_one = unsafe { unchecked_sub(m, 1) };
        if m <= INV_TABLE_MOD {
            table_inverse & m_minus_one
        } else {
            // Kita ngetrapake "up" nggunakake rumus ing ngisor iki:
            //
            // $$ xy ≡ 1 (mod 2ⁿ) → xy (2, xy) ≡ 1 (mod 2²ⁿ) $$
            //
            // nganti 2 ⁿⁿ ≥ mBanjur kita bisa nyuda `m` sing dikarepake kanthi njupuk `mod m` asil.
            let mut inverse = table_inverse;
            let mut going_mod = INV_TABLE_MOD_SQUARED;
            loop {
                // y=y * (2, xy) mod n
                //
                // Elinga, yen nggunakake operasi pambungkus ing kene kanthi sengaja-formula asli nggunakake conto, pengurangan `mod n`.
                // Ora masalah yen kudu `mod usize::MAX`, amarga kita entuk asil `mod n` ing pungkasan.
                //
                //
                inverse = wrapping_mul(inverse, wrapping_sub(2usize, wrapping_mul(x, inverse)));
                if going_mod >= m {
                    return inverse & m_minus_one;
                }
                going_mod = wrapping_mul(going_mod, going_mod);
            }
        }
    }

    let stride = mem::size_of::<T>();
    // SAFETY: `a` minangka kekuwatane, mula dudu nol.
    let a_minus_one = unsafe { unchecked_sub(a, 1) };
    if stride == 1 {
        // `stride == 1` kasus bisa diitung kanthi luwih gampang liwat `-p (mod a)`, nanging nglakoni bisa nyegah kemampuan LLVM kanggo milih pandhuan kaya `lea`.Nanging kita ngetung
        //
        //    round_up_to_next_alignment(p, a) - p
        //
        // ingkang operasi sak mbukak-prewangan, nanging pessimizing `and` cekap kanggo LLVM dadi bisa nggunakke macem-macem optimizations mangerténi babagan.
        //
        //
        return wrapping_sub(
            wrapping_add(p as usize, a_minus_one) & wrapping_sub(0, a),
            p as usize,
        );
    }

    let pmoda = p as usize & a_minus_one;
    if pmoda == 0 {
        // Wis selaras.Yay!
        return 0;
    } else if stride == 0 {
        // Yen penunjuk ora selaras, lan unsur ukurane nol, mula ora ana unsur sing bakal nyelarasake pitunjuk.
        //
        return usize::MAX;
    }

    let smoda = stride & a_minus_one;
    // SAFETY: a yaiku kekuwatan saka loro mula dudu nol.stride==0 kasus ditangani ing ndhuwur.
    let gcdpow = unsafe { intrinsics::cttz_nonzero(stride).min(intrinsics::cttz_nonzero(a)) };
    // SAFETY: gcdpow duwe wates ndhuwur sing paling akeh jumlah bit ing usize.
    let gcd = unsafe { unchecked_shl(1usize, gcdpow) };

    // SAFETY: gcd mesthi luwih utawa padha karo 1.
    if p as usize & unsafe { unchecked_sub(gcd, 1) } == 0 {
        // branch iki ngatasi persamaan kongruensi linear ing ngisor iki:
        //
        // ` p + so = 0 mod a `
        //
        // `p` iki nilai pointer, `s`, langkah `T`, `o` offset ing `T`s, lan `a`, keselarasan sing dijaluk.
        //
        // Kanthi `g = gcd(a, s)`, lan kahanan ing ndhuwur negesake manawa `p` uga bisa dipisahake karo `g`, kita bisa menehi tandha `a' = a/g`, `s' = s/g`, `p' = p/g`, mula iki padha karo:
        //
        // ` p' + s'o = 0 mod a' `
        // ` o = (a' - (p' mod a')) * (s'^-1 mod a') `
        //
        // Istilah kaping pisanan yaiku "the relative alignment of `p` to `a`" (dipérang karo `g`), istilah nomer loro yaiku "how does incrementing `p` by `s` bytes change the relative alignment of `p`" (maneh dipérang karo `g`).
        //
        // Pambagian `g` perlu nggawe kuwalik uga kawangun yen `a` lan `s` ora co-Perdana.
        //
        // Salajengipun, asil sing digawe dening solusi iki dudu "minimal", mula prelu njupuk asil `o mod lcm(s, a)`.Kita bisa ngganti `lcm(s, a)` karo mung `a'`.
        //
        //
        //
        //
        //

        // SAFETY: `gcdpow` duwe wates ndhuwur sing ora luwih saka jumlah 0 bit ing `a`.
        //
        let a2 = unsafe { unchecked_shr(a, gcdpow) };
        // SAFETY: `a2` ora nol.Ngowahi `a` dening `gcdpow` ora bisa ngalih saka bit sing disetel
        // ing `a` (sing nduwe persis siji).
        let a2minus1 = unsafe { unchecked_sub(a2, 1) };
        // SAFETY: `gcdpow` duwe wates ndhuwur sing ora luwih saka jumlah 0 bit ing `a`.
        //
        let s2 = unsafe { unchecked_shr(smoda, gcdpow) };
        // SAFETY: `gcdpow` duwe wates ndhuwur sing ora luwih saka jumlah 0 bit ing
        // `a`.
        // Kajaba iku, pangirangan ora bisa kebanjiran, amarga `a2 = a >> gcdpow` bakal mesthi luwih gedhe tinimbang `(p % a) >> gcdpow`.
        let minusp2 = unsafe { unchecked_sub(a2, unchecked_shr(pmoda, gcdpow)) };
        // SAFETY: `a2` punika daya-of-loro, minangka buktiaken ndhuwur.`s2` pancen kurang saka `a2`
        // amarga `(s % a) >> gcdpow` pancen kurang saka `a >> gcdpow`.
        return wrapping_mul(minusp2, unsafe { mod_inv(s2, a2) }) & a2minus1;
    }

    // Ora bisa sejajar babar pisan.
    usize::MAX
}

/// Mbandhingake pitunjuk mentah kanggo kesetaraan.
///
/// Iki padha karo nggunakake operator `==`, nanging kurang umum:
/// bantahan kasebut kudu dadi poin mentah `*const T`, dudu apa wae sing ngetrapake `PartialEq`.
///
/// Iki bisa digunakake kanggo mbandhingake referensi `&T` (sing meksa `*const T` kanthi implisit) kanthi alamat tinimbang mbandhingake nilai sing dituju (yaiku apa implementasine `PartialEq for &T`).
///
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let five = 5;
/// let other_five = 5;
/// let five_ref = &five;
/// let same_five_ref = &five;
/// let other_five_ref = &other_five;
///
/// assert!(five_ref == same_five_ref);
/// assert!(ptr::eq(five_ref, same_five_ref));
///
/// assert!(five_ref == other_five_ref);
/// assert!(!ptr::eq(five_ref, other_five_ref));
/// ```
///
/// Irisan uga dibandhingake karo dawa (pitunjuk lemak):
///
/// ```
/// let a = [1, 2, 3];
/// assert!(std::ptr::eq(&a[..3], &a[..3]));
/// assert!(!std::ptr::eq(&a[..2], &a[..3]));
/// assert!(!std::ptr::eq(&a[0..2], &a[1..3]));
/// ```
///
/// Traits uga dibandhingake karo implementasine:
///
/// ```
/// #[repr(transparent)]
/// struct Wrapper { member: i32 }
///
/// trait Trait {}
/// impl Trait for Wrapper {}
/// impl Trait for i32 {}
///
/// let wrapper = Wrapper { member: 10 };
///
/// // Pointer duwe alamat sing padha.
/// assert!(std::ptr::eq(
///     &wrapper as *const Wrapper as *const u8,
///     &wrapper.member as *const i32 as *const u8
/// ));
///
/// // Obyek duwe alamat sing padha, nanging `Trait` duwe implementasi sing beda.
/// assert!(!std::ptr::eq(
///     &wrapper as &dyn Trait,
///     &wrapper.member as &dyn Trait,
/// ));
/// assert!(!std::ptr::eq(
///     &wrapper as &dyn Trait as *const dyn Trait,
///     &wrapper.member as &dyn Trait as *const dyn Trait,
/// ));
///
/// // Ngonversi referensi menyang `*const u8` dibandhingake karo alamat.
/// assert!(std::ptr::eq(
///     &wrapper as &dyn Trait as *const dyn Trait as *const u8,
///     &wrapper.member as &dyn Trait as *const dyn Trait as *const u8,
/// ));
/// ```
///
///
#[stable(feature = "ptr_eq", since = "1.17.0")]
#[inline]
pub fn eq<T: ?Sized>(a: *const T, b: *const T) -> bool {
    a == b
}

/// Tandha pitunjuk mentah.
///
/// Iki bisa digunakake kanggo menehi referensi `&T` (sing meksa `*const T`) kanthi alamat tinimbang nilai sing dituduhake (yaiku apa implementasine `Hash for &T`).
///
///
/// # Examples
///
/// ```
/// use std::collections::hash_map::DefaultHasher;
/// use std::hash::{Hash, Hasher};
/// use std::ptr;
///
/// let five = 5;
/// let five_ref = &five;
///
/// let mut hasher = DefaultHasher::new();
/// ptr::hash(five_ref, &mut hasher);
/// let actual = hasher.finish();
///
/// let mut hasher = DefaultHasher::new();
/// (five_ref as *const i32).hash(&mut hasher);
/// let expected = hasher.finish();
///
/// assert_eq!(actual, expected);
/// ```
///
#[stable(feature = "ptr_hash", since = "1.35.0")]
pub fn hash<T: ?Sized, S: hash::Hasher>(hashee: *const T, into: &mut S) {
    use crate::hash::Hash;
    hashee.hash(into);
}

// Nganggo pitunjuk fungsi
macro_rules! fnptr_impls_safety_abi {
    ($FnTy: ty, $($Arg: ident),*) => {
        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> PartialEq for $FnTy {
            #[inline]
            fn eq(&self, other: &Self) -> bool {
                *self as usize == *other as usize
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> Eq for $FnTy {}

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> PartialOrd for $FnTy {
            #[inline]
            fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
                (*self as usize).partial_cmp(&(*other as usize))
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> Ord for $FnTy {
            #[inline]
            fn cmp(&self, other: &Self) -> Ordering {
                (*self as usize).cmp(&(*other as usize))
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> hash::Hash for $FnTy {
            fn hash<HH: hash::Hasher>(&self, state: &mut HH) {
                state.write_usize(*self as usize)
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> fmt::Pointer for $FnTy {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                // HACK: Pemeran menengah minangka usize dibutuhake kanggo AVR
                // saengga papan alamat penunjuk fungsi sumber disimpen ing pitunjuk fungsi pungkasan.
                //
                //
                // https://github.com/avr-rust/rust/issues/143
                fmt::Pointer::fmt(&(*self as usize as *const ()), f)
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> fmt::Debug for $FnTy {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                // HACK: Pemeran menengah minangka usize dibutuhake kanggo AVR
                // saengga papan alamat penunjuk fungsi sumber disimpen ing pitunjuk fungsi pungkasan.
                //
                //
                // https://github.com/avr-rust/rust/issues/143
                fmt::Pointer::fmt(&(*self as usize as *const ()), f)
            }
        }
    }
}

macro_rules! fnptr_impls_args {
    ($($Arg: ident),+) => {
        fnptr_impls_safety_abi! { extern "Rust" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { extern "C" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { extern "C" fn($($Arg),+ , ...) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "Rust" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "C" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "C" fn($($Arg),+ , ...) -> Ret, $($Arg),+ }
    };
    () => {
        // Ora ana fungsi variadis kanthi 0 paramèter
        fnptr_impls_safety_abi! { extern "Rust" fn() -> Ret, }
        fnptr_impls_safety_abi! { extern "C" fn() -> Ret, }
        fnptr_impls_safety_abi! { unsafe extern "Rust" fn() -> Ret, }
        fnptr_impls_safety_abi! { unsafe extern "C" fn() -> Ret, }
    };
}

fnptr_impls_args! {}
fnptr_impls_args! { A }
fnptr_impls_args! { A, B }
fnptr_impls_args! { A, B, C }
fnptr_impls_args! { A, B, C, D }
fnptr_impls_args! { A, B, C, D, E }
fnptr_impls_args! { A, B, C, D, E, F }
fnptr_impls_args! { A, B, C, D, E, F, G }
fnptr_impls_args! { A, B, C, D, E, F, G, H }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J, K }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J, K, L }

/// Gawe pitunjuk mentah `const` menyang sawijining panggonan, tanpa nggawe referensi menengah.
///
/// Nggawe referensi nganggo `&`/`&mut` mung diidini yen pitunjuk didadekake siji kanthi bener lan nuduhake data sing diwiwiti.
/// Kanggo kasus sing ora ana sarat, petunjuk mentah kudu digunakake.
/// Nanging, `&expr as *const _` nggawe referensi sadurunge dikirim menyang pitunjuk mentah, lan referensi kasebut tundhuk karo aturan sing padha karo kabeh referensi liyane.
///
/// Makro iki bisa nggawe pointer mentah *tanpa* nggawe referensi luwih dhisik.
///
/// # Example
///
/// ```
/// use std::ptr;
///
/// #[repr(packed)]
/// struct Packed {
///     f1: u8,
///     f2: u16,
/// }
///
/// let packed = Packed { f1: 1, f2: 2 };
/// // `&packed.f2` bakal nggawe referensi sing ora larut, lan mula tumindak sing ora ditemtokake!
/// let raw_f2 = ptr::addr_of!(packed.f2);
/// assert_eq!(unsafe { raw_f2.read_unaligned() }, 2);
/// ```
///
#[stable(feature = "raw_ref_macros", since = "1.51.0")]
#[rustc_macro_transparency = "semitransparent"]
#[allow_internal_unstable(raw_ref_op)]
pub macro addr_of($place:expr) {
    &raw const $place
}

/// Gawe pitunjuk mentah `mut` menyang sawijining panggonan, tanpa nggawe referensi menengah.
///
/// Nggawe referensi nganggo `&`/`&mut` mung diidini yen pitunjuk didadekake siji kanthi bener lan nuduhake data sing diwiwiti.
/// Kanggo kasus sing ora ana sarat, petunjuk mentah kudu digunakake.
/// Nanging, `&mut expr as *mut _` nggawe referensi sadurunge dikirim menyang pitunjuk mentah, lan referensi kasebut tundhuk karo aturan sing padha karo kabeh referensi liyane.
///
/// Makro iki bisa nggawe pointer mentah *tanpa* nggawe referensi luwih dhisik.
///
/// # Example
///
/// ```
/// use std::ptr;
///
/// #[repr(packed)]
/// struct Packed {
///     f1: u8,
///     f2: u16,
/// }
///
/// let mut packed = Packed { f1: 1, f2: 2 };
/// // `&mut packed.f2` bakal nggawe referensi sing ora larut, lan mula tumindak sing ora ditemtokake!
/// let raw_f2 = ptr::addr_of_mut!(packed.f2);
/// unsafe { raw_f2.write_unaligned(42); }
/// assert_eq!({packed.f2}, 42); // `{...}` pasukan Nyalin lapangan tinimbang nggawe referensi.
/// ```
///
#[stable(feature = "raw_ref_macros", since = "1.51.0")]
#[rustc_macro_transparency = "semitransparent"]
#[allow_internal_unstable(raw_ref_op)]
pub macro addr_of_mut($place:expr) {
    &raw mut $place
}