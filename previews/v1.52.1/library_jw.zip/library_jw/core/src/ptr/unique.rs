use crate::convert::From;
use crate::fmt;
use crate::marker::{PhantomData, Unsize};
use crate::mem;
use crate::ops::{CoerceUnsized, DispatchFromDyn};

/// Bungkus ngubengi `*mut T` non-nol sing mentah sing nuduhake manawa sing duwe bungkus iki nduweni referensi.
/// Migunakake kanggo nggawe abstraksi kaya `Box<T>`, `Vec<T>`, `String`, lan `HashMap<K, V>`.
///
/// Boten kados `*mut T`, `Unique<T>` dumadakan "as if" padha Kayata saka `T`.
/// Iki ngetrapake `Send`/`Sync` yen `T` yaiku `Send`/`Sync`.
/// Iki uga tegese jinis aliasing sing kuwat njamin kedadeyan `T` sing bisa diarepake:
/// referensi penunjuk ora kudu diowahi tanpa dalan unik kanggo duwe Unik.
///
/// Yen sampeyan ora yakin apa bener nggunakake `Unique` kanggo tujuan sampeyan, coba gunakake `NonNull`, sing nduweni semantik sing luwih lemah.
///
///
/// Beda karo `*mut T`, penunjuk kudu mesthi batal, sanajan penunjuk ora bisa disuda.
/// Iki supaya enums bisa nggunakake nilai pareng iki minangka Diskriminan a-`Option<Unique<T>>` nduweni ukuran padha minangka `Unique<T>`.
/// Nanging, pointer isih bisa digantung yen ora diresepake.
///
/// Beda karo `*mut T`, `Unique<T>` kovarian luwih saka `T`.
/// Iki mesthine kudu bener kanggo jinis apa wae sing netepi syarat aliasing Unik.
///
///
///
#[unstable(
    feature = "ptr_internals",
    issue = "none",
    reason = "use `NonNull` instead and consider `PhantomData<T>` \
              (if you also use `#[may_dangle]`), `Send`, and/or `Sync`"
)]
#[doc(hidden)]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
pub struct Unique<T: ?Sized> {
    pointer: *const T,
    // NOTE: panandha iki ora duwe konsekuensi kanggo variasi, nanging perlu
    // kanggo dropck ngerti manawa kanthi logis duwe `T`.
    //
    // Kanggo rincian, deleng:
    // https://github.com/rust-lang/rfcs/blob/master/text/0769-sound-generic-drop.md#phantom-data
    _marker: PhantomData<T>,
}

/// `Unique` pointer yaiku `Send` yen `T` yaiku `Send` amarga data sing dirujuk ora diowahi.
/// Elinga yen invarian aliasing iki ora dikuatake karo sistem jinis;abstraksi nggunakake `Unique` kudu dileksanakake.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Send + ?Sized> Send for Unique<T> {}

/// `Unique` penunjuk sing `Sync` yen `T` punika `Sync` amarga data padha ngrujuk punika unaliased.
/// Elinga yen invarian aliasing iki ora dikuatake karo sistem jinis;abstraksi nggunakake `Unique` kudu dileksanakake.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Sync + ?Sized> Sync for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: Sized> Unique<T> {
    /// Nggawe `Unique` anyar sing nggantung, nanging selaras kanthi apik.
    ///
    /// Iki migunani kanggo nggawe inisialisasi jinis sing lazim dialokasikan, kaya `Vec::new`.
    ///
    /// Elinga yen nilai penunjuk bisa uga nuduhake pointer sing valid menyang `T`, tegese iki ora bisa digunakake minangka nilai sentinel "not yet initialized".
    /// Jinis-jinis sing kesasar nyedhiyakake kudu nglacak inisialisasi kanthi cara liya.
    ///
    ///
    ///
    #[inline]
    pub const fn dangling() -> Self {
        // SAFETY: mem::align_of() ngasilake petunjuk sing bener lan ora batal.Ing
        // kahanan sing nelpon new_unchecked() mula dihormati.
        unsafe { Unique::new_unchecked(mem::align_of::<T>() as *mut T) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Unique<T> {
    /// Nggawe `Unique` anyar.
    ///
    /// # Safety
    ///
    /// `ptr` kudu ora batal.
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // SAFETY: panelpon kudu njamin yen `ptr` ora batal.
        unsafe { Unique { pointer: ptr as _, _marker: PhantomData } }
    }

    /// Nggawe `Unique` anyar yen `ptr` ora batal.
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // SAFETY: Penunjuk wis dicenthang lan ora batal.
            Some(unsafe { Unique { pointer: ptr as _, _marker: PhantomData } })
        } else {
            None
        }
    }

    /// Entuk penunjuk `*mut` sing ndasari.
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// Dereferensi isi.
    ///
    /// Umur sing diasilake pancen mandhiri mula, mula tumindak "as if" iki sejatine minangka conto T sing bakal disilih.
    /// Yen (unbound) umur maneh dibutuhake, gunakake `&*my_ptr.as_ptr()`.
    ///
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // SAFETY: panelpon kudu njamin yen `self` ketemu kabeh
        // syarat kanggo referensi.
        unsafe { &*self.as_ptr() }
    }

    /// Bisa uga ngilangi konten kasebut.
    ///
    /// Umur sing diasilake pancen mandhiri mula, mula tumindak "as if" iki sejatine minangka conto T sing bakal disilih.
    /// Yen (unbound) umur maneh dibutuhake, gunakake `&mut *my_ptr.as_ptr()`.
    ///
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // SAFETY: panelpon kudu njamin yen `self` ketemu kabeh
        // syarat kanggo referensi sing bisa diowahi.
        unsafe { &mut *self.as_ptr() }
    }

    /// Mundur menyang pitunjuk jinis liyane.
    #[inline]
    pub const fn cast<U>(self) -> Unique<U> {
        // SAFETY: Unique::new_unchecked() nggawe unik lan kabutuhan anyar
        // pitunjuk diwenehi ora dadi batal.
        // Amarga kita nganggep awake dhewe minangka petunjuk, mula ora bisa dibatalake.
        unsafe { Unique::new_unchecked(self.as_ptr() as *mut U) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Clone for Unique<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Copy for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Debug for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Pointer for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<&mut T> for Unique<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // SAFETY: Referensi sing bisa dipateni ora bisa dibatalake
        unsafe { Unique { pointer: reference as *mut T, _marker: PhantomData } }
    }
}