#![unstable(feature = "ptr_metadata", issue = "81513")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

/// Nyedhiyakake jinis metadata pitunjuk kanggo jinis sing ditunjuk.
///
/// # Metadata pointer
///
/// Jinis pitunjuk mentah lan jinis referensi ing Rust bisa dianggep digawe saka rong bagean:
/// pitunjuk data sing ngemot alamat memori regane, lan sawetara metadata.
///
/// Kanggo jinis ukuran statis (sing ngetrapake `Sized` traits) uga kanggo jinis `extern`, pointer diarani "tipis": metadata ukurane nol lan jinise `()`.
///
///
/// Pointer menyang [dynamically-sized types][dst] diarani "jembar" utawa "lemu", duwe metadata ukuran ora nol:
///
/// * Kanggo strukture sing lapangan pungkasan yaiku DST, metadata minangka metadata kanggo kolom pungkasan
/// * Kanggo jinis `str`, metadata dawa ing bait dadi `usize`
/// * Kanggo jinis irisan kaya `[T]`, metadata minangka dawa ing item yaiku `usize`
/// * Kanggo trait obyek kaya `dyn SomeTrait`, metadata punika [`DynMetadata<Self>`][DynMetadata] (eg `DynMetadata<dyn SomeTrait>`)
///
/// Ing future, basa Rust bisa entuk jinis jinis anyar sing duwe metadata penunjuk sing beda.
///
/// [dst]: https://doc.rust-lang.org/nomicon/exotic-sizes.html#dynamically-sized-types-dsts
///
/// # `Pointee` trait
///
/// Intine trait iki yaiku jinis sing gegandhengan `Metadata`, yaiku `()` utawa `usize` utawa `DynMetadata<_>` kaya sing dijelasake ing ndhuwur.
/// Kanthi otomatis dileksanakake kanggo saben jinis.
/// Bisa dianggep diterapake ing konteks umum, sanajan tanpa wates sing cocog.
///
/// # Usage
///
/// Pointer mentah bisa dipecah dadi alamat data lan komponen metadata kanthi metode [`to_raw_parts`].
///
/// Utawa, metadata dhewe bisa diekstraksi kanthi fungsi [`metadata`].
/// Referensi bisa dilewati menyang [`metadata`] lan implisit dipeksa.
///
/// Pointer (possibly-wide) bisa dipasang maneh saka alamat lan metadata kanthi [`from_raw_parts`] utawa [`from_raw_parts_mut`].
///
/// [`to_raw_parts`]: *const::to_raw_parts
///
///
///
///
///
///
///
///
///
#[lang = "pointee_trait"]
pub trait Pointee {
    /// Jinis kanggo metadata ing petunjuk lan referensi menyang `Self`.
    #[lang = "metadata_type"]
    // NOTE: Tetep trait bounds ing `static_assert_expected_bounds_for_metadata`
    //
    // ing `library/core/src/ptr/metadata.rs` diselarasake karo sing ana ing kene:
    type Metadata: Copy + Send + Sync + Ord + Hash + Unpin;
}

/// Petunjuk kanggo jinis sing ngetrapake alias trait iki "tipis".
///
/// Iki kalebu jinis `Ukuran 'statis lan jinis `extern`.
///
/// # Example
///
/// ```rust
/// #![feature(ptr_metadata)]
///
/// fn this_never_panics<T: std::ptr::Thin>() {
///     assert_eq!(std::mem::size_of::<&T>(), std::mem::size_of::<usize>())
/// }
/// ```
#[unstable(feature = "ptr_metadata", issue = "81513")]
// NOTE: aja stabilake sadurunge trait alias stabil ing basa?
pub trait Thin = Pointee<Metadata = ()>;

/// Ekstrak komponen metadata pitunjuk.
///
/// Nilai-nilai jinis `*mut T`, `&T`, utawa `&mut T` bisa liwati langsung menyang fungsi iki lagi implicitly meksa kanggo `* const T`.
///
///
/// # Example
///
/// ```
/// #![feature(ptr_metadata)]
///
/// assert_eq!(std::ptr::metadata("foo"), 3_usize);
/// ```
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn metadata<T: ?Sized>(ptr: *const T) -> <T as Pointee>::Metadata {
    // SAFETY: Ngakses nilai saka serikat `PtrRepr` aman wiwit * const T
    // lan PtrComponents<T>duwe noto memori sing padha.
    // Mung std sing bisa njamin.
    unsafe { PtrRepr { const_ptr: ptr }.components.metadata }
}

/// Mbentuk pointer mentah (possibly-wide) saka alamat data lan metadata.
///
/// Fungsi iki aman nanging pitunjuk sing bali durung mesthi aman.
/// Kanggo irisan, deleng dokumentasi [`slice::from_raw_parts`] kanggo syarat keamanan.
/// Kanggo trait obyek, metadata kudu teka saka pitunjuk kanggo jinis ereased ndasari padha.
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts<T: ?Sized>(
    data_address: *const (),
    metadata: <T as Pointee>::Metadata,
) -> *const T {
    // SAFETY: Ngakses nilai saka serikat `PtrRepr` aman wiwit * const T
    // lan PtrComponents<T>duwe noto memori sing padha.
    // Mung std sing bisa njamin.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.const_ptr }
}

/// Nindakake fungsi sing padha karo [`from_raw_parts`], kajaba pitunjuk `*mut` mentah bali, beda karo pitunjuk `* const` mentah.
///
///
/// Deleng dokumentasi [`from_raw_parts`] kanggo rincian liyane.
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts_mut<T: ?Sized>(
    data_address: *mut (),
    metadata: <T as Pointee>::Metadata,
) -> *mut T {
    // SAFETY: Ngakses nilai saka serikat `PtrRepr` aman wiwit * const T
    // lan PtrComponents<T>duwe noto memori sing padha.
    // Mung std sing bisa njamin.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.mut_ptr }
}

#[repr(C)]
pub(crate) union PtrRepr<T: ?Sized> {
    pub(crate) const_ptr: *const T,
    pub(crate) mut_ptr: *mut T,
    pub(crate) components: PtrComponents<T>,
}

#[repr(C)]
pub(crate) struct PtrComponents<T: ?Sized> {
    pub(crate) data_address: *const (),
    pub(crate) metadata: <T as Pointee>::Metadata,
}

// Manual implan dibutuhake supaya `T: Copy` ora kaiket.
impl<T: ?Sized> Copy for PtrComponents<T> {}

// Manual implan dibutuhake supaya `T: Clone` ora kaiket.
impl<T: ?Sized> Clone for PtrComponents<T> {
    fn clone(&self) -> Self {
        *self
    }
}

/// Metadata kanggo jinis obyek `Dyn = dyn SomeTrait` trait.
///
/// Iki minangka penunjuk menyang tabel (tabel panggilan virtual) sing nuduhake kabeh informasi sing dibutuhake kanggo ngapusi jinis konkrit sing disimpen ing obyek trait.
/// Meja kasebut utamane ngemot:
///
/// * ukuran jinis
/// * jinis alignment
/// * pitunjuk kanggo `drop_in_place` impl jinis (bisa uga ora ana op-op kanggo data lawas-lawas)
/// * nuduhake kabeh cara kanggo jinis implementasine trait
///
/// Elinga yen telung sing pertama khusus amarga kudu alokasi, culake, lan menehi hasil menyang obyek trait.
///
/// Sampeyan bisa menehi jeneng strukture iki kanthi paramèter jinis sing dudu obyek `dyn` trait (contone `DynMetadata<u64>`) nanging ora éntuk nilai sing migunani kanggo strukture kasebut.
///
///
///
///
#[lang = "dyn_metadata"]
pub struct DynMetadata<Dyn: ?Sized> {
    vtable_ptr: &'static VTable,
    phantom: crate::marker::PhantomData<Dyn>,
}

/// Awalan umum kabeh vtables.Ngiringi pitunjuk fungsi kanggo metode trait.
///
/// Private implementasine rinci `DynMetadata::size_of` etc.
#[repr(C)]
struct VTable {
    drop_in_place: fn(*mut ()),
    size_of: usize,
    align_of: usize,
}

impl<Dyn: ?Sized> DynMetadata<Dyn> {
    /// Ngasilake ukuran jinis sing ana gandhengane karo vtable iki.
    #[inline]
    pub fn size_of(self) -> usize {
        self.vtable_ptr.size_of
    }

    /// Ngasilake keselarasan jinis sing ana gandhengane karo meja iki.
    #[inline]
    pub fn align_of(self) -> usize {
        self.vtable_ptr.align_of
    }

    /// Ngasilake ukuran lan keselarasan minangka `Layout`
    #[inline]
    pub fn layout(self) -> crate::alloc::Layout {
        // SAFETY: kompiler ngasilake meja iki kanggo jinis Rust beton sing
        // dikenal duwe tata letak sing bener.Rasional sing padha kaya ing `Layout::for_value`.
        unsafe { crate::alloc::Layout::from_size_align_unchecked(self.size_of(), self.align_of()) }
    }
}

unsafe impl<Dyn: ?Sized> Send for DynMetadata<Dyn> {}
unsafe impl<Dyn: ?Sized> Sync for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> fmt::Debug for DynMetadata<Dyn> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("DynMetadata").field(&(self.vtable_ptr as *const VTable)).finish()
    }
}

// Manual implan dibutuhake kanggo nyegah wates `Dyn: $Trait`.

impl<Dyn: ?Sized> Unpin for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Copy for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Clone for DynMetadata<Dyn> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

impl<Dyn: ?Sized> Eq for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> PartialEq for DynMetadata<Dyn> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        crate::ptr::eq::<VTable>(self.vtable_ptr, other.vtable_ptr)
    }
}

impl<Dyn: ?Sized> Ord for DynMetadata<Dyn> {
    #[inline]
    fn cmp(&self, other: &Self) -> crate::cmp::Ordering {
        (self.vtable_ptr as *const VTable).cmp(&(other.vtable_ptr as *const VTable))
    }
}

impl<Dyn: ?Sized> PartialOrd for DynMetadata<Dyn> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<crate::cmp::Ordering> {
        Some(self.cmp(other))
    }
}

impl<Dyn: ?Sized> Hash for DynMetadata<Dyn> {
    #[inline]
    fn hash<H: Hasher>(&self, hasher: &mut H) {
        crate::ptr::hash::<VTable, _>(self.vtable_ptr, hasher)
    }
}