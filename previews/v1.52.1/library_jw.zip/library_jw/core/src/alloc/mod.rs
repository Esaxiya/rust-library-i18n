//! API alokasi memori

#![stable(feature = "alloc_module", since = "1.28.0")]

mod global;
mod layout;

#[stable(feature = "global_alloc", since = "1.28.0")]
pub use self::global::GlobalAlloc;
#[stable(feature = "alloc_layout", since = "1.28.0")]
pub use self::layout::Layout;
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
#[allow(deprecated, deprecated_in_future)]
pub use self::layout::LayoutErr;

#[stable(feature = "alloc_layout_error", since = "1.50.0")]
pub use self::layout::LayoutError;

use crate::fmt;
use crate::ptr::{self, NonNull};

/// Kesalahan `AllocError` nuduhake kegagalan alokasi sing bisa uga amarga kekurangan sumber daya utawa ana kesalahan nalika nggabungake argumen input sing diwenehake karo alokasi iki.
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[derive(Copy, Clone, PartialEq, Eq, Debug)]
pub struct AllocError;

// (kita butuh iki kanggo kesalahan trait ing hilir)
#[unstable(feature = "allocator_api", issue = "32838")]
impl fmt::Display for AllocError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("memory allocation failed")
    }
}

/// Implementasi `Allocator` bisa nyedhiyakake, nambah, nyuda, lan menehi transaksi blok data sing ora disengaja sing diterangake liwat [`Layout`][].
///
/// `Allocator` dirancang kanggo dileksanakake ing ZST, referensi, utawa petunjuk pinter amarga duwe alokator kaya `MyAlloc([u8; N])` ora bisa dipindhah, tanpa nganyari pitunjuk menyang memori sing dialokasikan.
///
/// Ora kaya [`GlobalAlloc`][], alokasi ukuran nol diidini ing `Allocator`.
/// Yen alokator sing ndasari ora ndhukung iki (kaya jemalloc) utawa ngasilake pointer nol (kayata `libc::malloc`), iki kudu ditrapake.
///
/// ### Saiki memori dialokasikan
///
/// Sawetara cara mbutuhake blok memori *saiki dialokasikan* liwat alokasi.Iki tegese:
///
/// * alamat wiwitan blok memori kasebut sadurunge bali dening [`allocate`], [`grow`], utawa [`shrink`], lan
///
/// * blok memori durung bisa diterusake, ing endi blok kasebut bisa ditanggepi langsung kanthi diterusake menyang [`deallocate`] utawa diganti dadi [`grow`] utawa [`shrink`] sing ngasilake `Ok`.
///
/// Yen `grow` utawa `shrink` wis ngasilake `Err`, pointer sing diterusake tetep valid.
///
/// [`allocate`]: Allocator::allocate
/// [`grow`]: Allocator::grow
/// [`shrink`]: Allocator::shrink
/// [`deallocate`]: Allocator::deallocate
///
/// ### Pas memori
///
/// Sawetara cara mbutuhake tata letak *pas* blok memori.
/// Apa tegese tata letak menyang "fit" blok memori tegese (utawa padha karo blok memori kanggo "fit" tata letak) yaiku kahanan ing ngisor iki:
///
/// * Blokir kudu dialokasikan kanthi keselarasan sing padha karo [`layout.align()`], lan
///
/// * [`layout.size()`] kasedhiya kudu tiba ing sawetara `min ..= max`, ngendi:
///   - `min` yaiku ukuran tata letak sing paling anyar sing digunakake kanggo alokasi blok, lan
///   - `max` yaiku ukuran nyata paling anyar sing bali saka [`allocate`], [`grow`], utawa [`shrink`].
///
/// [`layout.align()`]: Layout::align
/// [`layout.size()`]: Layout::size
///
/// # Safety
///
/// * Blok memori sing bali saka alokator kudu nuduhake memori sing valid lan tetep validitas nganti kedadeyan lan kabeh klon kasebut mudhun,
///
/// * kloning utawa mindhah alokator ora kudu mbatalake blok memori sing bali saka alokasi iki.Aloktor klon kudu tumindak kaya alokasi sing padha, lan
///
/// * pointer menyang blok memori sing [*currently allocated*] bisa uga diterusake menyang metode alokasi liyane.
///
/// [*currently allocated*]: #currently-allocated-memory
///
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
pub unsafe trait Allocator {
    /// Usaha nyedhiakke pemblokiran saka memori.
    ///
    /// On sukses, ngasilake [`NonNull<[u8]>`][NonNull] patemon ukuran lan Alignment njamin saka `layout`.
    ///
    /// Blokir bali kudu sing luwih gedhe saka kasebut dening `layout.size()`, lan bisa utawa ora bisa duwe isi initialized.
    ///
    /// # Errors
    ///
    /// Bali `Err` nuduhake manawa memori wis entek utawa `layout` ora nemoni ukuran alokasi utawa alangan jajaran.
    ///
    /// Implementasi disaranake ngasilake `Err` amarga lemes amarga ora panik utawa aborsi, nanging iki dudu sarat sing ketat.
    /// (Khusus:*sah* kanggo ngetrapake trait iki ing ndhuwur perpustakaan alokasi asli sing nyebabake gangguan memori.)
    ///
    /// Klien sing pengin ngilangi komputasi kanggo nanggepi kesalahan alokasi disaranake nyebut fungsi [`handle_alloc_error`], tinimbang langsung njaluk `panic!` utawa sing padha.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError>;

    /// Bungah kaya `allocate`, nanging uga mesthekake yen memori bali dadi nol.
    ///
    /// # Errors
    ///
    /// Bali `Err` nuduhake manawa memori wis entek utawa `layout` ora nemoni ukuran alokasi utawa alangan jajaran.
    ///
    /// Implementasi disaranake ngasilake `Err` amarga lemes amarga ora panik utawa aborsi, nanging iki dudu sarat sing ketat.
    /// (Khusus:*sah* kanggo ngetrapake trait iki ing ndhuwur perpustakaan alokasi asli sing nyebabake gangguan memori.)
    ///
    /// Klien sing pengin ngilangi komputasi kanggo nanggepi kesalahan alokasi disaranake nyebut fungsi [`handle_alloc_error`], tinimbang langsung njaluk `panic!` utawa sing padha.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        let ptr = self.allocate(layout)?;
        // SAFETY: `alloc` ngasilake pemblokiran memori bener
        unsafe { ptr.as_non_null_ptr().as_ptr().write_bytes(0, ptr.len()) }
        Ok(ptr)
    }

    /// Deallocates memori sing dirujuk dening `ptr`.
    ///
    /// # Safety
    ///
    /// * `ptr` kudu nuduhake blok memori [*currently allocated*] liwat alokasi iki, lan
    /// * `layout` kudu [*fit*] blok memori.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout);

    /// Usaha kanggo nambah blok memori.
    ///
    /// Ngasilake [`NonNull<[u8]>`][NonNull] anyar sing ngemot pitunjuk lan ukuran nyata memori sing dialokasikan.pitunjuk punika cocok kanggo nyekeli data diterangake dening `new_layout`.
    /// Kanggo ngrampungake, alokator bisa nambah alokasi sing dirujuk dening `ptr` supaya cocog karo tata letak anyar.
    ///
    /// Yen ngasilake `Ok`, mula kepemilikan blok memori sing dirujuk dening `ptr` wis ditransfer menyang alokasi iki.
    /// Memori bisa uga wis dibebasake, lan kudu dianggep ora bisa digunakake kajaba yen ditransfer maneh menyang panelpon maneh liwat nilai bali saka metode iki.
    ///
    /// Yen metode iki ngasilake `Err`, mula kepemilikan blok memori durung ditransfer menyang alokasi iki, lan konten blok memori ora diowahi.
    ///
    /// # Safety
    ///
    /// * `ptr` kudu nuduhake blok memori [*currently allocated*] liwat alokasi iki.
    /// * `old_layout` kudu [*fit*] sing pemblokiran saka memori (The `new_layout` pitakonan perlu ora pas.).
    /// * `new_layout.size()` kudu luwih saka utawa padha karo `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Ngasilake `Err` yen tata letak anyar ora cocog karo ukuran lan alokasi alokasi alokasi, utawa yen gagal gagal.
    ///
    /// Implementasi disaranake ngasilake `Err` amarga lemes amarga ora panik utawa aborsi, nanging iki dudu sarat sing ketat.
    /// (Khusus:*sah* kanggo ngetrapake trait iki ing ndhuwur perpustakaan alokasi asli sing nyebabake gangguan memori.)
    ///
    /// Klien sing pengin ngilangi komputasi kanggo nanggepi kesalahan alokasi disaranake nyebut fungsi [`handle_alloc_error`], tinimbang langsung njaluk `panic!` utawa sing padha.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // SAFETY: amarga `new_layout.size()` kudu luwih saka utawa witjaksono kanggo
        // `old_layout.size()`, alokasi memori lawas lan anyar bener ditrapake kanggo diwaca lan nulis kanthi byte `old_layout.size()`.
        // Uga, amarga alokasi lawas durung menehi hasil, mula ora bisa tumpang tindih `new_ptr`.
        // Dadi, telpon menyang `copy_nonoverlapping` aman.
        // Kontrak keamanan kanggo `dealloc` kudu dikuatake dening panelpon.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Bhaves kaya `grow`, nanging uga njamin manawa konten anyar disetel dadi nol sadurunge dibalekake.
    ///
    /// Pemblokiran memori bakal ngemot isi ngisor sawise panggilan sukses kanggo
    /// `grow_zeroed`:
    ///   * Bita `0..old_layout.size()` disimpen saka alokasi asli.
    ///   * Bita `old_layout.size()..old_size` bakal salah siji wadi utawa zeroed, gumantung ing implementasine allocator.
    ///   `old_size` nuduhake ukuran blok memori sadurunge telpon `grow_zeroed`, sing bisa uga luwih gedhe tinimbang ukuran sing sadurunge dijaluk nalika dialokasikan.
    ///   * Bita `old_size..new_size` nol.`new_size` nuduhake ukuran blok memori sing dibukak kanthi telpon `grow_zeroed`.
    ///
    /// # Safety
    ///
    /// * `ptr` kudu nuduhake blok memori [*currently allocated*] liwat alokasi iki.
    /// * `old_layout` kudu [*fit*] sing pemblokiran saka memori (The `new_layout` pitakonan perlu ora pas.).
    /// * `new_layout.size()` kudu luwih saka utawa padha karo `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Ngasilake `Err` yen tata letak anyar ora cocog karo ukuran lan alokasi alokasi alokasi, utawa yen gagal gagal.
    ///
    /// Implementasi disaranake ngasilake `Err` amarga lemes amarga ora panik utawa aborsi, nanging iki dudu sarat sing ketat.
    /// (Khusus:*sah* kanggo ngetrapake trait iki ing ndhuwur perpustakaan alokasi asli sing nyebabake gangguan memori.)
    ///
    /// Klien sing pengin ngilangi komputasi kanggo nanggepi kesalahan alokasi disaranake nyebut fungsi [`handle_alloc_error`], tinimbang langsung njaluk `panic!` utawa sing padha.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate_zeroed(new_layout)?;

        // SAFETY: amarga `new_layout.size()` kudu luwih saka utawa witjaksono kanggo
        // `old_layout.size()`, alokasi memori lawas lan anyar bener ditrapake kanggo diwaca lan nulis kanthi byte `old_layout.size()`.
        // Uga, amarga alokasi lawas durung menehi hasil, mula ora bisa tumpang tindih `new_ptr`.
        // Dadi, telpon menyang `copy_nonoverlapping` aman.
        // Kontrak keamanan kanggo `dealloc` kudu dikuatake dening panelpon.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Upaya nyuda blok memori.
    ///
    /// Ngasilake [`NonNull<[u8]>`][NonNull] anyar sing ngemot pitunjuk lan ukuran nyata memori sing dialokasikan.pitunjuk punika cocok kanggo nyekeli data diterangake dening `new_layout`.
    /// Kanggo ngrampungake, alokator bisa nyuda alokasi sing dirujuk dening `ptr` supaya cocog karo tata letak anyar.
    ///
    /// Yen ngasilake `Ok`, mula kepemilikan blok memori sing dirujuk dening `ptr` wis ditransfer menyang alokasi iki.
    /// Memori bisa uga wis dibebasake, lan kudu dianggep ora bisa digunakake kajaba yen ditransfer maneh menyang panelpon maneh liwat nilai bali saka metode iki.
    ///
    /// Yen metode iki ngasilake `Err`, mula kepemilikan blok memori durung ditransfer menyang alokasi iki, lan konten blok memori ora diowahi.
    ///
    /// # Safety
    ///
    /// * `ptr` kudu nuduhake blok memori [*currently allocated*] liwat alokasi iki.
    /// * `old_layout` kudu [*fit*] sing pemblokiran saka memori (The `new_layout` pitakonan perlu ora pas.).
    /// * `new_layout.size()` kudu luwih cilik tinimbang utawa padha karo `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Ngasilake `Err` yen tata letak anyar ora cocog karo ukuran lan alokasi alokasi alokasi, utawa yen nyusut gagal.
    ///
    /// Implementasi disaranake ngasilake `Err` amarga lemes amarga ora panik utawa aborsi, nanging iki dudu sarat sing ketat.
    /// (Khusus:*sah* kanggo ngetrapake trait iki ing ndhuwur perpustakaan alokasi asli sing nyebabake gangguan memori.)
    ///
    /// Klien sing pengin ngilangi komputasi kanggo nanggepi kesalahan alokasi disaranake nyebut fungsi [`handle_alloc_error`], tinimbang langsung njaluk `panic!` utawa sing padha.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() <= old_layout.size(),
            "`new_layout.size()` must be smaller than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // SAFETY: amarga `new_layout.size()` kudu luwih murah tinimbang utawa padha karo
        // `old_layout.size()`, alokasi memori lawas lan anyar bener ditrapake kanggo diwaca lan nulis kanthi byte `new_layout.size()`.
        // Uga, amarga alokasi lawas durung menehi hasil, mula ora bisa tumpang tindih `new_ptr`.
        // Dadi, telpon menyang `copy_nonoverlapping` aman.
        // Kontrak keamanan kanggo `dealloc` kudu dikuatake dening panelpon.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), new_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Nggawe adaptor "by reference" kanggo conto `Allocator` iki.
    ///
    /// Adaptor sing bali uga ngetrapake `Allocator` lan mung bakal utangan iki.
    #[inline(always)]
    fn by_ref(&self) -> &Self
    where
        Self: Sized,
    {
        self
    }
}

#[unstable(feature = "allocator_api", issue = "32838")]
unsafe impl<A> Allocator for &A
where
    A: Allocator + ?Sized,
{
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate(layout)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate_zeroed(layout)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        // KESELAMATAN: kontrak keamanan kudu dijaluk dening wong sing nelpon
        unsafe { (**self).deallocate(ptr, layout) }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // KESELAMATAN: kontrak keamanan kudu dijaluk dening wong sing nelpon
        unsafe { (**self).grow(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // KESELAMATAN: kontrak keamanan kudu dijaluk dening wong sing nelpon
        unsafe { (**self).grow_zeroed(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // KESELAMATAN: kontrak keamanan kudu dijaluk dening wong sing nelpon
        unsafe { (**self).shrink(ptr, old_layout, new_layout) }
    }
}