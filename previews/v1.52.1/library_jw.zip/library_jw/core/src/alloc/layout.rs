use crate::cmp;
use crate::fmt;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ptr::NonNull;

// Nalika fungsi iki digunakake ing sak panggonan lan implementasine bisa uga digambarake, upaya sadurunge nggawe rustc luwih alon:
//
//
// * https://github.com/rust-lang/rust/pull/72189
// * https://github.com/rust-lang/rust/pull/79827
//
const fn size_align<T>() -> (usize, usize) {
    (mem::size_of::<T>(), mem::align_of::<T>())
}

/// Tata letak blok memori.
///
/// Kayata `Layout` nggambarake tata letak memori.
/// Sampeyan nggawe `Layout` munggah minangka input kanggo menehi kanggo alokasi.
///
/// Kabeh noto duwe ukuran sing gegandhengan lan keselarasan loro-daya.
///
/// (Elinga yen tata letak *ora* dibutuhake ukuran non-nol, sanajan `GlobalAlloc` mbutuhake kabeh panjaluk memori ukuran ora nol.
/// Panelpon kudu mesthekake yen kahanan kaya iki wis ketemu, nggunakake alokasi khusus kanthi syarat sing luwih longgar, utawa nggunakake antarmuka `Allocator` sing luwih entheng.)
///
///
///
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[lang = "alloc_layout"]
pub struct Layout {
    // ukuran blok memori sing dijaluk, diukur kanthi bita.
    size_: usize,

    // Alignment saka blok memori sing dijaluk, diukur kanthi bita.
    // kita mesthekake yen iki tansah daya-of-loro, amarga API kang kaya `posix_memalign` mbutuhake lan iku larangan cukup kanggo nemtokke ing konstruktorkang Layout.
    //
    //
    // (Nanging, kita ora mbutuhake analogi `align>= sizeof(void *)`, even though that is* also* a requirement of `posix_memalign`.)
    //
    //
    align_: NonZeroUsize,
}

impl Layout {
    /// Mbangun `Layout` saka `size` lan `align` tartamtu, utawa ngasilake `LayoutError` yen ana kondisi ing ngisor iki sing durung kawujud:
    ///
    /// * `align` ora kudu nol,
    ///
    /// * `align` kudu dadi daya saka loro,
    ///
    /// * `size`, nalika dibunderaké nganti pirang-pirang `align` paling cedhak, ora kudu kebanjiran (yaiku, Nilai bunder kudu kurang saka utawa padha karo `usize::MAX`).
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn from_size_align(size: usize, align: usize) -> Result<Self, LayoutError> {
        if !align.is_power_of_two() {
            return Err(LayoutError { private: () });
        }

        // (kekuwatan-saka-loro tegese kempal!=0.)

        // Ukuran sing dibunderaké yaiku:
        //   size_rounds_up=(size + align, 1)&! (kempal, 1);
        //
        // Kita ngerti saka ndhuwur sing cocog!=0.
        // Yen nambah (align, 1) ora kebanjiran, banjur lambé dibunderaké munggah bakal nggoleki.
        //
        // Kosok baline,&-masking karo! (Kempal, 1) mung bakal nyuda potongan sing murah.
        // Mangkono yen kebanjiran kedadeyan kanthi jumlah,&-mask ora bisa nyuda cukup kanggo mbatalake kebanjiran kasebut.
        //
        //
        // Ndhuwur tegese manawa mriksa kebanjiran penjumlahan perlu lan cukup.
        //
        if size > usize::MAX - (align - 1) {
            return Err(LayoutError { private: () });
        }

        // SAFETY: kahanan kanggo `from_size_align_unchecked` wis
        // dicenthang ndhuwur.
        unsafe { Ok(Layout::from_size_align_unchecked(size, align)) }
    }

    /// Nggawe tata letak, ngliwati kabeh cek.
    ///
    /// # Safety
    ///
    /// Fungsi iki ora aman amarga ora verifikasi prasyarat saka [`Layout::from_size_align`].
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub const unsafe fn from_size_align_unchecked(size: usize, align: usize) -> Self {
        // SAFETY: panelpon kudu mesthekake yen `align` luwih gedhe tinimbang nol.
        Layout { size_: size, align_: unsafe { NonZeroUsize::new_unchecked(align) } }
    }

    /// Ukuran minimal byte kanggo blok memori tata letak iki.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn size(&self) -> usize {
        self.size_
    }

    /// Minimal bait alignment kanggo pemblokiran memori saka tata iki.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn align(&self) -> usize {
        self.align_.get()
    }

    /// Mbangun `Layout` sing cocog kanggo nahan nilai tipe `T`.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout_const_new", since = "1.42.0")]
    #[inline]
    pub const fn new<T>() -> Self {
        let (size, align) = size_align::<T>();
        // SAFETY: align dijamin karo Rust dadi kekuwatan loro lan
        // ukuran + kempal combo dijamin pas ing ruang alamat.
        // Akibaté, gunakake konstruktor sing ora dicenthang ing kene kanggo ngindhari kode panics yen ora cukup dioptimalake.
        //
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Mrodhuksi tata njlentrehke rekaman sing bisa digunakake kanggo nyedhiakke struktur backing kanggo `T` (kang bisa dadi trait utawa jinis unsized kaya irisan a).
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub fn for_value<T: ?Sized>(t: &T) -> Self {
        let (size, align) = (mem::size_of_val(t), mem::align_of_val(t));
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // SAFETY: deleng alesan ing `new` kenapa nggunakake varian sing ora aman
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Mrodhuksi tata njlentrehke rekaman sing bisa digunakake kanggo nyedhiakke struktur backing kanggo `T` (kang bisa dadi trait utawa jinis unsized kaya irisan a).
    ///
    /// # Safety
    ///
    /// Fungsi iki mung aman ditelpon yen ana kahanan ing ngisor iki:
    ///
    /// - Yen `T` `Sized`, fungsi iki mesthi aman ditelpon.
    /// - Yen buntut `T` sing ora diukur yaiku:
    ///     - [slice], banjur dawane buntut irisan kudu integer intialisasi, lan ukuran *kabeh nilai*(dawa buntut dinamis + awalan ukuran statis) kudu pas karo `isize`.
    ///     - [trait object], mula bagean sing bisa ditampilake ing pointer kudu nuduhake tabel sing bener kanggo jinis `T` sing dipikolehi kanthi koordinasi sing ukurane, lan ukuran *kabeh nilai*(dawa buntut dinamis + awalan ukuran statis) kudu pas karo `isize`.
    ///
    ///     - lan (unstable) [extern type], banjur fungsi iki tansah aman kanggo nelpon, nanging uga panic utawa digunakake bali Nilai salah, minangka tata jinis extern kang wis ora dikenal.
    ///     Iki tumindak sing padha karo [`Layout::for_value`] nalika nuduhake buntut jinis eksternal.
    ///     - yen ora, konservatif ora diijini nelpon fungsi iki.
    ///
    /// [trait object]: ../../book/ch17-02-trait-objects.html
    /// [extern type]: ../../unstable-book/language-features/extern-types.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "layout_for_ptr", issue = "69835")]
    pub unsafe fn for_value_raw<T: ?Sized>(t: *const T) -> Self {
        // SAFETY: kita ngirim prasyarat fungsi kasebut menyang panelpon
        let (size, align) = unsafe { (mem::size_of_val_raw(t), mem::align_of_val_raw(t)) };
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // SAFETY: deleng alesan ing `new` kenapa nggunakake varian sing ora aman
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Nggawe `NonNull` sing nggantung, nanging jumbuh karo Layout iki.
    ///
    /// Elinga yen nilai penunjuk bisa uga nuduhake pointer sing valid, tegese iki ora bisa digunakake minangka nilai sentinel "not yet initialized".
    /// Jinis-jinis sing kesasar nyedhiyakake kudu nglacak inisialisasi kanthi cara liya.
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub const fn dangling(&self) -> NonNull<u8> {
        // SAFETY: align dijamin dadi non-zero
        unsafe { NonNull::new_unchecked(self.align() as *mut u8) }
    }

    /// Nggawe rancangan njlentrehke rekaman sing bisa terus regane saka rancangan padha `self`, nanging sing uga didadekake siji kanggo alignment `align` (diukur ing bita).
    ///
    ///
    /// Yen `self` wis cocog karo alignment sing wis ditemtokake, mula ngasilake `self`.
    ///
    /// Elinga yen cara iki ora nambah padding kanggo ukuran sakabèhé, ora preduli manawa tata letak bali duwe jajaran sing beda.
    /// Kanthi tembung liyane, yen `K` duwe ukuran 16, `K.align_to(32)` bakal *isih* duwe ukuran 16.
    ///
    /// Ngasilake kesalahan yen kombinasi `self.size()` lan `align` tartamtu nglanggar kondisi sing kacathet ing [`Layout::from_size_align`].
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn align_to(&self, align: usize) -> Result<Self, LayoutError> {
        Layout::from_size_align(self.size(), cmp::max(self.align(), align))
    }

    /// Ngasilake jumlah padding sing kudu dilebokake sawise `self` kanggo mesthekake yen alamat ing ngisor iki bakal nglegakake `align` (diukur kanthi bita).
    ///
    /// eg, yen `self.size()` 9, mula `self.padding_needed_for(4)` ngasilake 3, amarga jumlah minimum byte padding sing dibutuhake kanggo entuk alamat sing selaras karo 4 (kanthi asumsi yen blok memori sing cocog diwiwiti ing alamat sing didadekake 4).
    ///
    ///
    /// Nilai bali fungsi iki ora ana artine yen `align` dudu kekuwatan loro.
    ///
    /// Elinga yen panggunaan nilai bali mbutuhake `align` kurang saka utawa padha karo keselarasan alamat wiwitan kanggo kabeh memori sing dialokasikan.Salah sawijining cara kanggo ngatasi kendala iki yaiku njamin `align <= self.align()`.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "const_alloc_layout", issue = "67521")]
    #[inline]
    pub const fn padding_needed_for(&self, align: usize) -> usize {
        let len = self.size();

        // Nilai sing dibunderaké yaiku:
        //   len_rounds_up=(len + align, 1)&! (kempal, 1);
        // banjur kita bali bedane bantalan: `len_rounded_up - len`.
        //
        // Kita nggunakake aritmatika modular ing saindenging:
        //
        // 1. align dijamin dadi> 0, supaya align, 1 tansah bener.
        //
        // 2.
        // `len + align - 1` bisa kebanjiran paling akeh `align - 1`, saengga&-mask kanthi `!(align - 1)` bakal mesthekake yen ing kasus kebanjiran, `len_rounded_up` bakal 0.
        //
        //    Mangkono lapis bali, nalika ditambahaké kanggo `len`, panenan 0, kang trivially nglegakake Alignment `align`.
        //
        // (Mesthi wae, nyoba kanggo alokasi blok memori sing ukurane lan bantalan kebanjiran kanthi cara ing ndhuwur kudu nyebabake alokator ngasilake kesalahan.)
        //
        //
        //
        //

        let len_rounded_up = len.wrapping_add(align).wrapping_sub(1) & !align.wrapping_sub(1);
        len_rounded_up.wrapping_sub(len)
    }

    /// Nggawe tata dening lambé dibunderaké ukuran tata iki nganti sawetara saka alignment ing tata kang.
    ///
    ///
    /// Iki padha karo nambah asil `padding_needed_for` menyang ukuran tata letak saiki.
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn pad_to_align(&self) -> Layout {
        let pad = self.padding_needed_for(self.align());
        // Iki ora bisa kebanjiran.Kutipan saka invarian Layout:
        // > `size`, nalika dibunderake menyang pirang-pirang `align` paling cedhak,
        // > kudu ora kebanjiran (yaiku, nilai bunder kudu kurang saka
        // > `usize::MAX`)
        let new_size = self.size() + pad;

        Layout::from_size_align(new_size, self.align()).unwrap()
    }

    /// Nggawe tata letak sing nggambarake rekor `n` instansi `self`, kanthi jumlah padding sing pas ing antarane masing-masing kanggo mesthekake yen saben conto diwenehi ukuran lan jajaran sing dijaluk.
    /// Sukses, ngasilake `(k, offs)` ing endi `k` minangka tata letak array lan `offs` yaiku jarak antarane wiwitan saben elemen ing larik kasebut.
    ///
    /// Nalika kebanjiran aritmatika, ngasilake `LayoutError`.
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat(&self, n: usize) -> Result<(Self, usize), LayoutError> {
        // Iki ora bisa kebanjiran.Kutipan saka invarian Layout:
        // > `size`, nalika dibunderake menyang pirang-pirang `align` paling cedhak,
        // > kudu ora kebanjiran (yaiku, nilai bunder kudu kurang saka
        // > `usize::MAX`)
        let padded_size = self.size() + self.padding_needed_for(self.align());
        let alloc_size = padded_size.checked_mul(n).ok_or(LayoutError { private: () })?;

        // SAFETY: self.align wis dikenal dadi bener lan alloc_size wis
        // wis empuk.
        unsafe { Ok((Layout::from_size_align_unchecked(alloc_size, self.align()), padded_size)) }
    }

    /// Nggawe tata letak sing nggambarake rekor `self` banjur `next`, kalebu padding sing dibutuhake kanggo mesthekake yen `next` bakal didadekake siji kanthi bener, nanging *ora ana padding*.
    ///
    /// Kanggo cocog karo tata letak perwakilan C `repr(C)`, sampeyan kudu nelpon `pad_to_align` sawise nambah tata letak karo kabeh kolom.
    /// (Ora ana cara kanggo cocog karo tata letak perwakilan Rust standar `repr(Rust)`, as it is unspecified.)
    ///
    /// Elinga yen keselarasan tata letak sing diasilake bakal maksimal kanggo `self` lan `next`, supaya bisa nyelarasake kalorone bagean.
    ///
    /// Ngasilake `Ok((k, offset))`, ing endi `k` minangka tata letak rekaman gabungan lan `offset` minangka lokasi sing relatif, ing bait, wiwitan `next` sing ditempelake ing rekaman sing digabungake (nganggep yen rekaman kasebut diwiwiti ing offset 0).
    ///
    ///
    /// Nalika kebanjiran aritmatika, ngasilake `LayoutError`.
    ///
    /// # Examples
    ///
    /// Kanggo ngetung tata letak struktur `#[repr(C)]` lan offset lapangan saka noto kolom:
    ///
    /// ```rust
    /// # use std::alloc::{Layout, LayoutError};
    /// pub fn repr_c(fields: &[Layout]) -> Result<(Layout, Vec<usize>), LayoutError> {
    ///     let mut offsets = Vec::new();
    ///     let mut layout = Layout::from_size_align(0, 1)?;
    ///     for &field in fields {
    ///         let (new_layout, offset) = layout.extend(field)?;
    ///         layout = new_layout;
    ///         offsets.push(offset);
    ///     }
    ///     // Elinga finalisasi nganggo `pad_to_align`!
    ///     Ok((layout.pad_to_align(), offsets))
    /// }
    /// # // nyoba sing bisa digunakake
    /// # #[repr(C)] struct S { a: u64, b: u32, c: u16, d: u32 }
    /// # let s = Layout::new::<S>();
    /// # let u16 = Layout::new::<u16>();
    /// # let u32 = Layout::new::<u32>();
    /// # let u64 = Layout::new::<u64>();
    /// # assert_eq!(repr_c(&[u64, u32, u16, u32]), Ok((s, vec![0, 8, 12, 16])));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn extend(&self, next: Self) -> Result<(Self, usize), LayoutError> {
        let new_align = cmp::max(self.align(), next.align());
        let pad = self.padding_needed_for(next.align());

        let offset = self.size().checked_add(pad).ok_or(LayoutError { private: () })?;
        let new_size = offset.checked_add(next.size()).ok_or(LayoutError { private: () })?;

        let layout = Layout::from_size_align(new_size, new_align)?;
        Ok((layout, offset))
    }

    /// Nggawe rancangan njlentrehke rekor `n` kedadean saka `self`, karo ora lapis antarane saben Kayata.
    ///
    /// Elinga, ora kaya `repeat`, `repeat_packed` ora njamin yen kedadeyan `self` sing bola-bali bakal didadekake siji kanthi bener, sanajan kedadeyan `self` diwenehi kanthi bener.
    /// Kanthi tembung liyane, yen tata letak sing dibalekake dening `repeat_packed` digunakake kanggo nyedhiyakake array, ora bakal dijamin kabeh elemen ing susunan kasebut bakal didadekake siji kanthi bener.
    ///
    /// Nalika kebanjiran aritmatika, ngasilake `LayoutError`.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat_packed(&self, n: usize) -> Result<Self, LayoutError> {
        let size = self.size().checked_mul(n).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(size, self.align())
    }

    /// Nggawe tata letak sing nggambarake rekor `self` banjur `next` tanpa padding tambahan ing antarane kalorone.
    /// Awit ora lapis dipasang, Alignment saka `next` iku ora salaras, lan ora digabung *ing kabeh* menyang tata letak asil.
    ///
    ///
    /// Nalika kebanjiran aritmatika, ngasilake `LayoutError`.
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn extend_packed(&self, next: Self) -> Result<Self, LayoutError> {
        let new_size = self.size().checked_add(next.size()).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(new_size, self.align())
    }

    /// Nggawe tata letak sing nggambarake rekor kanggo `[T; n]`.
    ///
    /// Nalika kebanjiran aritmatika, ngasilake `LayoutError`.
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn array<T>(n: usize) -> Result<Self, LayoutError> {
        let (layout, offset) = Layout::new::<T>().repeat(n)?;
        debug_assert_eq!(offset, mem::size_of::<T>());
        Ok(layout.pad_to_align())
    }
}

#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
pub type LayoutErr = LayoutError;

/// Parameter sing diwenehake menyang `Layout::from_size_align` utawa konstruktor `Layout` liyane ora nyenengake watesan sing didokumentasikan.
///
///
#[stable(feature = "alloc_layout_error", since = "1.50.0")]
#[derive(Clone, PartialEq, Eq, Debug)]
pub struct LayoutError {
    private: (),
}

// (kita butuh iki kanggo kesalahan trait ing hilir)
#[stable(feature = "alloc_layout", since = "1.28.0")]
impl fmt::Display for LayoutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("invalid parameters to Layout::from_size_align")
    }
}