use crate::alloc::Layout;
use crate::cmp;
use crate::ptr;

/// Alokasi memori sing bisa didaftar minangka standar perpustakaan standar liwat atribut `#[global_allocator]`.
///
/// Sawetara cara mbutuhake blok memori *saiki dialokasikan* liwat alokasi.Iki tegese:
///
/// * alamat miwiti kanggo sing pemblokiran memori sadurunge bali dening nelpon sakdurunge cara persediaan kayata `alloc`, lan
///
/// * pemblokiran memori durung salajengipun deallocated, ngendi pamblokiran sing deallocated kanthi kang liwati kanggo cara deallocation kayata `dealloc` utawa dening kang liwati kanggo cara reallocation sing ngasilake a non-null pitunjuk.
///
///
/// # Example
///
/// ```no_run
/// use std::alloc::{GlobalAlloc, Layout, alloc};
/// use std::ptr::null_mut;
///
/// struct MyAllocator;
///
/// unsafe impl GlobalAlloc for MyAllocator {
///     unsafe fn alloc(&self, _layout: Layout) -> *mut u8 { null_mut() }
///     unsafe fn dealloc(&self, _ptr: *mut u8, _layout: Layout) {}
/// }
///
/// #[global_allocator]
/// static A: MyAllocator = MyAllocator;
///
/// fn main() {
///     unsafe {
///         assert!(alloc(Layout::new::<u32>()).is_null())
///     }
/// }
/// ```
///
/// # Safety
///
/// `GlobalAlloc` trait minangka `unsafe` trait amarga sawetara alasan, lan pelaksana kudu mesthekake yen tundhuk kontrak kasebut:
///
/// * Prilaku sing durung ditemtokake yen para alokasi global mundur.watesan iki bisa diangkat ing future, nanging saiki panic saka samubarang fungsi iki bisa mimpin kanggo unsafety memori.
///
/// * `Layout` pitakon lan petungan ing umum kudu bener.Panelpon trait iki diijini gumantung karo kontrak sing ditemtokake ing saben metode, lan pelaksana kudu mesthekake manawa kontrak kasebut tetep nyata.
///
/// * Sampeyan bisa uga ora ngandelake alokasi sing kedadeyan, sanajan ana alokasi tumpukan sing jelas ing sumber kasebut.
/// Pangoptimal bisa ndeteksi alokasi sing ora digunakake sing bisa ngilangi kabeh utawa pindhah menyang tumpukan lan mula aja njaluk alokasi.
/// The Pangoptimal bisa luwih nganggep persediaan sing sampurna, supaya kode sing digunakake kanggo gagal amarga allocator gagal bisa saiki dumadakan karya amarga Pangoptimal makarya sak perlu kanggo persediaan.
/// Luwih konkrit, conto kode ing ngisor iki ora cocog, preduli apa alokasi khusus sampeyan ngidini ngetung pira alokasi sing kedadeyan.
///
///   ```rust,ignore (unsound and has placeholders)
///   drop(Box::new(42));
///   let number_of_heap_allocs = /* call private allocator API */;
///   unsafe { std::intrinsics::assume(number_of_heap_allocs > 0); }
///   ```
///
///   Elinga yen pangoptimasi kasebut ing ndhuwur dudu mung pangoptimal sing bisa ditrapake.Sampeyan umume ora gumantung karo alokasi tumpukan yen bisa dicopot tanpa ngowahi prilaku program.
///   Apa allocations kelakon utawa ora iku ora bagean saka prilaku program, malah yen bisa dideteksi liwat allocator sing trek allocations dening Printing utawa digunakake efek sisih.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
pub unsafe trait GlobalAlloc {
    /// Alokasi memori kaya sing dijelasake karo `layout` sing diwenehake.
    ///
    /// Ngasilake pitunjuk menyang memori sing mentas dialokasikan, utawa mbatalake kanggo nuduhake gagal alokasi.
    ///
    /// # Safety
    ///
    /// Fungsi iki saiki lagi aman amarga prilaku cetho bisa kasil yen panelpon ora njamin yen `layout` wis ukuran-nol.
    ///
    /// (Subtraits ekstensi bisa uga nyedhiyakake wates tumindak sing luwih spesifik, kayata, njamin alamat sentinel utawa pointer nol kanggo nanggepi panjaluk alokasi ukuran nol.)
    ///
    /// Blok memori sing dialokasikan bisa uga ora diinisialisasi.
    ///
    /// # Errors
    ///
    /// Baliake pointer nol nuduhake manawa memori wis entek utawa `layout` ora bisa ngatasi ukuran alokasi utawa alangan alignment iki.
    ///
    /// Implementasi disaranake mbatalake keletihan memori tinimbang mbatalake, nanging iki dudu sarat sing ketat.
    /// (Khusus:*sah* kanggo ngetrapake trait iki ing ndhuwur perpustakaan alokasi asli sing nyebabake gangguan memori.)
    ///
    /// Klien sing pengin ngilangi komputasi kanggo nanggepi kesalahan alokasi disaranake nyebut fungsi [`handle_alloc_error`], tinimbang langsung njaluk `panic!` utawa sing padha.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn alloc(&self, layout: Layout) -> *mut u8;

    /// Deallocate pemblokiran saka memori ing pitunjuk `ptr` diwenehi karo `layout` diwenehi.
    ///
    /// # Safety
    ///
    /// Fungsi iki ora aman amarga tumindak sing ora ditemtokake bisa nyebabake yen panelpon ora njamin kabeh perkara ing ngisor iki:
    ///
    ///
    /// * `ptr` kudu nuduhake blok memori sing saiki dialokasikan liwat alokasi iki,
    ///
    /// * `layout` kudu tata letak sing padha karo sing digunakake kanggo menehi alangan memori.
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn dealloc(&self, ptr: *mut u8, layout: Layout);

    /// Bhaves kaya `alloc`, nanging uga mesthekake manawa isine disetel dadi nol sadurunge dibalekake.
    ///
    /// # Safety
    ///
    /// Fungsi iki ora aman amarga alasan sing padha karo `alloc`.
    /// Nanging blok memori sing diparengake dijamin bakal diinisialisasi.
    ///
    /// # Errors
    ///
    /// Mbalekake pointer nol nuduhake manawa memori wis entek utawa `layout` ora bisa ngatasi ukuran alokasi utawa alangan alignment, kaya ing `alloc`.
    ///
    /// Klien sing pengin ngilangi komputasi kanggo nanggepi kesalahan alokasi disaranake nyebut fungsi [`handle_alloc_error`], tinimbang langsung njaluk `panic!` utawa sing padha.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn alloc_zeroed(&self, layout: Layout) -> *mut u8 {
        let size = layout.size();
        // SAFETY: kontrak keamanan kanggo `alloc` kudu dikuatake dening panelpon.
        let ptr = unsafe { self.alloc(layout) };
        if !ptr.is_null() {
            // SAFETY: amarga alokasi sukses, wilayah saka `ptr`
            // ukuran `size` dijamin bisa digunakake kanggo nulis.
            unsafe { ptr::write_bytes(ptr, 0, size) };
        }
        ptr
    }

    /// Nyilikake utawa tambah blok memori menyang `new_size` sing diwenehake.
    /// Blok kasebut diandharake dening pointer `ptr` lan `layout` sing diwenehake.
    ///
    /// Yen ngasilake panunjuk non-nol, mula kepemilikan blok memori sing dirujuk dening `ptr` wis ditransfer menyang alokasi iki.
    /// Memori bisa uga wis bisa ditanggepi, lan kudu dianggep ora bisa digunakake (kajaba mesthi ditransfer maneh menyang panelpon maneh liwat nilai bali saka metode iki).
    /// Blok memori anyar diparengake nganggo `layout`, nanging kanthi `size` dianyari dadi `new_size`.
    /// Tata letak anyar iki kudu digunakake nalika menehi blok blok memori anyar karo `dealloc`.
    /// Rentang `0..min(layout.size(), new_size) `saka blok memori anyar dijamin duwe nilai sing padha karo blok asli.
    ///
    /// Yen metode iki mbatalake, mula kepemilikan blok memori durung ditransfer menyang alokasi iki, lan konten blok memori ora diowahi.
    ///
    /// # Safety
    ///
    /// Fungsi iki ora aman amarga tumindak sing ora ditemtokake bisa nyebabake yen panelpon ora njamin kabeh perkara ing ngisor iki:
    ///
    /// * `ptr` saiki kudu dialokasikan liwat alokasi iki,
    ///
    /// * `layout` kudu tata letak sing padha karo sing digunakake kanggo nyedhiyakake blok memori,
    ///
    /// * `new_size` kudu luwih gedhe tinimbang nol.
    ///
    /// * `new_size`, nalika dibunderaké nganti pirang-pirang `layout.align()` sing paling cedhak, ora kudu kebanjiran (yaiku, Nilai bunder kudu kurang saka `usize::MAX`).
    ///
    /// (Subtraits ekstensi bisa uga nyedhiyakake wates tumindak sing luwih spesifik, kayata, njamin alamat sentinel utawa pointer nol kanggo nanggepi panjaluk alokasi ukuran nol.)
    ///
    /// # Errors
    ///
    /// Mbalik maneh yen tata letak anyar ora bisa nemokake ukuran lan alangan alokasi alokasi, utawa yen realokasi sejatine gagal.
    ///
    /// Pelaksanaane disaranake mbatalake keletihan memori tinimbang panik utawa aborsi, nanging iki dudu sarat sing ketat.
    /// (Khusus:*sah* kanggo ngetrapake trait iki ing ndhuwur perpustakaan alokasi asli sing nyebabake gangguan memori.)
    ///
    /// Klien sing pengin ngilangi komputasi kanggo nanggepi kesalahan realokasi disaranake nelpon fungsi [`handle_alloc_error`], tinimbang langsung njaluk `panic!` utawa sing padha.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn realloc(&self, ptr: *mut u8, layout: Layout, new_size: usize) -> *mut u8 {
        // SAFETY: panelpon kudu mesthekake yen `new_size` ora kebanjiran.
        // `layout.align()` asale saka `Layout` lan mula bisa diamanake.
        let new_layout = unsafe { Layout::from_size_align_unchecked(new_size, layout.align()) };
        // SAFETY: panelpon kudu mesthekake yen `new_layout` luwih gedhe tinimbang nol.
        let new_ptr = unsafe { self.alloc(new_layout) };
        if !new_ptr.is_null() {
            // SAFETY: blok sing dialokasikan sadurunge ora bisa tumpang tindih blok sing mentas dialokasikan.
            // Kontrak keamanan kanggo `dealloc` kudu dikuatake dening panelpon.
            unsafe {
                ptr::copy_nonoverlapping(ptr, new_ptr, cmp::min(layout.size(), new_size));
                self.dealloc(ptr, layout);
            }
        }
        new_ptr
    }
}