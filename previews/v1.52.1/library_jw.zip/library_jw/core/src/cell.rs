//! Wadhah sing bisa diowahi bisa ditampilake.
//!
//! Keamanan memori Rust adhedhasar aturan iki: Yen diwenehi obyek `T`, bisa uga duwe salah sawijining ing ngisor iki:
//!
//! - Duwe sawetara referensi (`&T`) sing ora bisa diowahi kanggo obyek kasebut (uga dikenal minangka **aliasing**).
//! - Duwe siji referensi mutable (: &The T`) kanggo obyek (uga dikenal minangka mutability ** **).
//!
//! Iki dileksanakake dening compiler Rust.Nanging, ana kahanan sing aturan iki ora cukup fleksibel.Kadhangkala dibutuhake sawetara referensi menyang obyek nanging durung bisa diowahi.
//!
//! Wadhah sing bisa diowahi bisa ditampilake kanggo ngidini mutasi kanthi cara sing dikontrol, sanajan ana aliasing.Loro-lorone [`Cell<T>`] lan [`RefCell<T>`] ngidini mengkono iki ing cara siji-Utas.
//! Nanging, `Cell<T>` utawa `RefCell<T>` ora aman Utas (ora ngetrapake [`Sync`]).
//! Yen sampeyan kudu nindakake aliasing lan mutasi ing antarane sawetara utas, sampeyan bisa nggunakake jinis [`Mutex<T>`], [`RwLock<T>`] utawa [`atomic`].
//!
//! Angka saka jinis `Cell<T>` lan `RefCell<T>` bisa mutated liwat referensi sambungan (IE
//! jinis `&T` umum), dene umume jinis Rust mung bisa diowahi nganggo referensi unik (`&mut T`).
//! Kita ujar manawa `Cell<T>` lan `RefCell<T>` nyedhiyakake 'mutasi interior', beda karo jinis Rust khas sing nuduhake 'mutabilitas warisan'.
//!
//! Jinis sel kalebu rong rasa: `Cell<T>` lan `RefCell<T>`.`Cell<T>` nindakake mutability Interior obah nilai lan metu saka `Cell<T>`.
//! Kanggo nggunakake referensi tinimbang nilai, siji kudu nggunakake jinis `RefCell<T>`, éntuk kunci nulis sadurunge mutating.`Cell<T>` menehi cara kanggo nompo lan ngganti angka interior saiki:
//!
//!  - Kanggo jinis sing ngetrapake [`Copy`], metode [`get`](Cell::get) njupuk nilai interior saiki.
//!  - Kanggo jinis sing ngetrapake [`Default`], metode [`take`](Cell::take) ngganti nilai interior saiki karo [`Default::default()`] lan ngasilake nilai sing diganti.
//!  - Kanggo kabeh jinis, metode [`replace`](Cell::replace) ngganti nilai interior saiki lan ngasilake nilai sing diganti lan cara [`into_inner`](Cell::into_inner) nganggo `Cell<T>` lan ngasilake nilai interior.
//!  Kajaba iku, cara [`set`](Cell::set) ngganti angka interior, ngeculake nilai sing diganti.
//!
//! `RefCell<T>` nggunakake umur Rust kanggo ngetrapake 'utang dinamis', proses sing bisa njaluk akses sementara, eksklusif, lan mutable menyang nilai batin.
//! Nyilih kanggo `RefCell<T>: S sing dilacak 'ing durasi', kados jinis referensi native Rust kang kang tanggung dilacak statically, ing wektu ngripta.
//! Amarga yen pinjaman `RefCell<T>` dinamis, mula bisa nyoba nyilih nilai sing wis bisa diselehake;nalika kedadeyan kasebut ngasilake benang panic.
//!
//! # Nalika milih mutability interior
//!
//! Mutabilitas sing diwarisake luwih umum, ing endi kudu nduweni akses unik kanggo mutasi nilai, minangka salah sawijining elemen basa kunci sing ngidini Rust kanggo alesan babagan aliasing pointer, kanthi statis nyegah bug crash.
//! Amarga saka iku, dipun warisaken mutability disenengi, lan mutability interior soko saka Resor pungkasan.
//! Wiwit jinis sel ngaktifake mutasi ing ngendi iku bakal digunakake bakal diolehake sanadyan, ana kesempatan nalika mutability interior bisa cocok, utawa malah *kudu* digunakake, contone
//!
//! * Ngenalke mutability 'inside' soko tetep
//! * Detil implementasi metode sing ora bisa diganti kanthi logis.
//! * Implementasi mutasi [`Clone`].
//!
//! ## Ngenalke mutability 'inside' soko tetep
//!
//! Akeh sambungan jinis pitunjuk pinter, kalebu [`Rc<T>`] lan [`Arc<T>`], nyedhiyani kontaner sing bisa kloning lan sambungan antarane sawetara pihak.
//! Amarga nilai sing ana bisa uga alias multiplikasi, mula mung bisa disilih nganggo `&`, dudu `&mut`.
//! Tanpa sel iku bakal mokal kanggo nang data mutasi iki penunjuk pinter ing kabeh.
//!
//! Umume umume nyelehake `RefCell<T>` ing jinis penunjuk sing dituduhake kanggo ngasilake mutasi:
//!
//! ```
//! use std::cell::{RefCell, RefMut};
//! use std::collections::HashMap;
//! use std::rc::Rc;
//!
//! fn main() {
//!     let shared_map: Rc<RefCell<_>> = Rc::new(RefCell::new(HashMap::new()));
//!     // Nggawe anyar pemblokiran kanggo matesi orane katrangan saka utang dinamis
//!     {
//!         let mut map: RefMut<_> = shared_map.borrow_mut();
//!         map.insert("africa", 92388);
//!         map.insert("kyoto", 11837);
//!         map.insert("piccadilly", 11826);
//!         map.insert("marbles", 38);
//!     }
//!
//!     // Elinga yen kita ora ngidini utang cache sadurunge ora ana ing ruang lingkup, utangan sabanjure bakal nyebabake benang panic sing dinamis.
//!     //
//!     // Iki minangka bebaya utama nggunakake `RefCell`.
//!     let total: i32 = shared_map.borrow().values().sum();
//!     println!("{}", total);
//! }
//! ```
//!
//! Elinga yen conto iki migunakake `Rc<T>` lan ora `Arc<T>`.: RefCell<T>`s kanggo skenario Utas siji.Coba gunakake [`RwLock<T>`] utawa [`Mutex<T>`] yen sampeyan butuh mutasi bareng ing kahanan multi-utas.
//!
//! ## Rincian implementasine cara logis-tetep
//!
//! Sok-sok uga seng di pengeni ora kanggo mbabarake ing API sing ana mutasi kedados "under the hood".
//! Iki bisa uga amarga kanthi logis, operasi kasebut ora bisa owah, nanging kayata, meksa meksa implementasine kanggo nindakake mutasi;utawa amarga sampeyan kudu nggunakake mutasi kanggo ngetrapake metode trait sing asline ditetepake kanggo njupuk `&self`.
//!
//!
//! ```
//! # #![allow(dead_code)]
//! use std::cell::RefCell;
//!
//! struct Graph {
//!     edges: Vec<(i32, i32)>,
//!     span_tree_cache: RefCell<Option<Vec<(i32, i32)>>>
//! }
//!
//! impl Graph {
//!     fn minimum_spanning_tree(&self) -> Vec<(i32, i32)> {
//!         self.span_tree_cache.borrow_mut()
//!             .get_or_insert_with(|| self.calc_span_tree())
//!             .clone()
//!     }
//!
//!     fn calc_span_tree(&self) -> Vec<(i32, i32)> {
//!         // Komputasi larang dadi ing kene
//!         vec![]
//!     }
//! }
//! ```
//!
//! ## Implementasi mutasi `Clone`
//!
//! Iki mung minangka kasus khusus, nanging umum: ndhelikake mutasi kanggo operasi sing katon ora bisa diganti.
//! Cara [`clone`](Clone::clone) wis samesthine kanggo ora ngganti angka sumber, lan iku dinyatakaké njupuk `&self`, ora `&mut self`.
//! Mula, mutasi apa wae sing kedadeyan ing metode `clone` kudu nggunakake jinis sel.
//! Contone, [`Rc<T>`] njaga angka referensi ing `Cell<T>`.
//!
//! ```
//! use std::cell::Cell;
//! use std::ptr::NonNull;
//! use std::process::abort;
//! use std::marker::PhantomData;
//!
//! struct Rc<T: ?Sized> {
//!     ptr: NonNull<RcBox<T>>,
//!     phantom: PhantomData<RcBox<T>>,
//! }
//!
//! struct RcBox<T: ?Sized> {
//!     strong: Cell<usize>,
//!     refcount: Cell<usize>,
//!     value: T,
//! }
//!
//! impl<T: ?Sized> Clone for Rc<T> {
//!     fn clone(&self) -> Rc<T> {
//!         self.inc_strong();
//!         Rc {
//!             ptr: self.ptr,
//!             phantom: PhantomData,
//!         }
//!     }
//! }
//!
//! trait RcBoxPtr<T: ?Sized> {
//!
//!     fn inner(&self) -> &RcBox<T>;
//!
//!     fn strong(&self) -> usize {
//!         self.inner().strong.get()
//!     }
//!
//!     fn inc_strong(&self) {
//!         self.inner()
//!             .strong
//!             .set(self.strong()
//!                      .checked_add(1)
//!                      .unwrap_or_else(|| abort() ));
//!     }
//! }
//!
//! impl<T: ?Sized> RcBoxPtr<T> for Rc<T> {
//!    fn inner(&self) -> &RcBox<T> {
//!        unsafe {
//!            self.ptr.as_ref()
//!        }
//!    }
//! }
//! ```
//!
//! [`Arc<T>`]: ../../std/sync/struct.Arc.html
//! [`Rc<T>`]: ../../std/rc/struct.Rc.html
//! [`RwLock<T>`]: ../../std/sync/struct.RwLock.html
//! [`Mutex<T>`]: ../../std/sync/struct.Mutex.html
//! [`atomic`]: ../../core/sync/atomic/index.html
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering;
use crate::fmt::{self, Debug, Display};
use crate::marker::Unsize;
use crate::mem;
use crate::ops::{CoerceUnsized, Deref, DerefMut};
use crate::ptr;

/// Lokasi memori sing bisa diowahi.
///
/// # Examples
///
/// Ing conto iki, sampeyan bisa ndeleng sing `Cell<T>` mbisakake mutasi nang struct wong.
/// Kanthi tembung liyane, ngidini "interior mutability".
///
/// ```
/// use std::cell::Cell;
///
/// struct SomeStruct {
///     regular_field: u8,
///     special_field: Cell<u8>,
/// }
///
/// let my_struct = SomeStruct {
///     regular_field: 0,
///     special_field: Cell::new(1),
/// };
///
/// let new_value = 100;
///
/// // Kesalahan: `my_struct` ora bisa diganti
/// // my_struct.regular_field =new_value;
///
/// // KARYA: sanajan `my_struct` ora bisa diowahi, `special_field` minangka `Cell`,
/// // sing bisa mesthi dimutasi
/// my_struct.special_field.set(new_value);
/// assert_eq!(my_struct.special_field.get(), new_value);
/// ```
///
/// Deleng [module-level documentation](self) kanggo liyane.
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
pub struct Cell<T: ?Sized> {
    value: UnsafeCell<T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for Cell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for Cell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Copy> Clone for Cell<T> {
    #[inline]
    fn clone(&self) -> Cell<T> {
        Cell::new(self.get())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Cell<T> {
    /// Nggawe `Cell<T>`, karo nilai `Default` kanggo T.
    #[inline]
    fn default() -> Cell<T> {
        Cell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialEq + Copy> PartialEq for Cell<T> {
    #[inline]
    fn eq(&self, other: &Cell<T>) -> bool {
        self.get() == other.get()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: Eq + Copy> Eq for Cell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: PartialOrd + Copy> PartialOrd for Cell<T> {
    #[inline]
    fn partial_cmp(&self, other: &Cell<T>) -> Option<Ordering> {
        self.get().partial_cmp(&other.get())
    }

    #[inline]
    fn lt(&self, other: &Cell<T>) -> bool {
        self.get() < other.get()
    }

    #[inline]
    fn le(&self, other: &Cell<T>) -> bool {
        self.get() <= other.get()
    }

    #[inline]
    fn gt(&self, other: &Cell<T>) -> bool {
        self.get() > other.get()
    }

    #[inline]
    fn ge(&self, other: &Cell<T>) -> bool {
        self.get() >= other.get()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: Ord + Copy> Ord for Cell<T> {
    #[inline]
    fn cmp(&self, other: &Cell<T>) -> Ordering {
        self.get().cmp(&other.get())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for Cell<T> {
    fn from(t: T) -> Cell<T> {
        Cell::new(t)
    }
}

impl<T> Cell<T> {
    /// Nggawe `Cell` anyar ngemot nilai kang.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> Cell<T> {
        Cell { value: UnsafeCell::new(value) }
    }

    /// Mranata Nilai sing.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// c.set(10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn set(&self, val: T) {
        let old = self.replace(val);
        drop(old);
    }

    /// Ganti angka loro Sel.
    /// Prabédan karo `std::mem::swap` iku fungsi iki ora mbutuhake referensi `&mut`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c1 = Cell::new(5i32);
    /// let c2 = Cell::new(10i32);
    /// c1.swap(&c2);
    /// assert_eq!(10, c1.get());
    /// assert_eq!(5, c2.get());
    /// ```
    #[inline]
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn swap(&self, other: &Self) {
        if ptr::eq(self, other) {
            return;
        }
        // SAFETY: Iki bisa mbebayani yen diarani saka utas sing kapisah, nanging `Cell`
        // yaiku `!Sync` dadi ora bakal kelakon.
        // Iki uga ora bakal mbatalake petunjuk amarga `Cell` nggawe manawa ora ana liyane sing nuduhake salah siji saka `Cell`s iki.
        //
        unsafe {
            ptr::swap(self.value.get(), other.value.get());
        }
    }

    /// Ngganti nilai sing dikandung nganggo `val`, lan ngasilake nilai sing wis lawas.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let cell = Cell::new(5);
    /// assert_eq!(cell.get(), 5);
    /// assert_eq!(cell.replace(10), 5);
    /// assert_eq!(cell.get(), 10);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn replace(&self, val: T) -> T {
        // SAFETY: Iki bisa nyebabake balapan data yen diarani saka utas sing kapisah,
        // nanging `Cell` punika `!Sync` supaya iki ora bakal kelakon.
        mem::replace(unsafe { &mut *self.value.get() }, val)
    }

    /// Mbusak regane.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.into_inner();
    ///
    /// assert_eq!(five, 5);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value.into_inner()
    }
}

impl<T: Copy> Cell<T> {
    /// Ngasilake salinan Nilai sing.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let five = c.get();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get(&self) -> T {
        // SAFETY: Iki bisa nyebabake balapan data yen diarani saka utas sing kapisah,
        // nanging `Cell` punika `!Sync` supaya iki ora bakal kelakon.
        unsafe { *self.value.get() }
    }

    /// Nganyari nilai sing dikandung nggunakake fungsi lan ngasilake regane sing anyar.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_update)]
    ///
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let new = c.update(|x| x + 1);
    ///
    /// assert_eq!(new, 6);
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[unstable(feature = "cell_update", issue = "50186")]
    pub fn update<F>(&self, f: F) -> T
    where
        F: FnOnce(T) -> T,
    {
        let old = self.get();
        let new = f(old);
        self.set(new);
        new
    }
}

impl<T: ?Sized> Cell<T> {
    /// Ngasilake pitunjuk mentah menyang data sing ana ing sel iki.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    #[rustc_const_stable(feature = "const_cell_as_ptr", since = "1.32.0")]
    pub const fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// Ngasilake referensi sing bisa diowahi kanggo data sing ndasari.
    ///
    /// Panggilan iki nyilih `Cell` bisa diganti (nalika dikompilasi) sing njamin manawa kita duwe referensi.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let mut c = Cell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// Ngasilake `&Cell<T>` saka `&mut T`
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[inline]
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn from_mut(t: &mut T) -> &Cell<T> {
        // SAFETY: `&mut` njamin akses unik.
        unsafe { &*(t as *mut T as *const Cell<T>) }
    }
}

impl<T: Default> Cell<T> {
    /// Njupuk ing Nilai saka sel, ninggalake `Default::default()` ing sawijining panggonan.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<Cell<U>> for Cell<T> {}

impl<T> Cell<[T]> {
    /// Ngasilake `&[Cell<T>]` saka `&Cell<[T]>`
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn as_slice_of_cells(&self) -> &[Cell<T>] {
        // SAFETY: `Cell<T>` wis tata memori padha `T`.
        unsafe { &*(self as *const Cell<[T]> as *const [Cell<T>]) }
    }
}

/// Lokasi memori sing bisa diowahi kanthi aturan utang sing dicenthang kanthi dinamis
///
/// Deleng [module-level documentation](self) kanggo liyane.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefCell<T: ?Sized> {
    borrow: Cell<BorrowFlag>,
    value: UnsafeCell<T>,
}

/// Kesalahan bali dening [`RefCell::try_borrow`].
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already mutably borrowed", f)
    }
}

/// Kesalahan ngasilake [`RefCell::try_borrow_mut`].
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowMutError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowMutError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already borrowed", f)
    }
}

// angka positif makili nomer `Ref` aktif.Nilai negatif nuduhake nomer `RefMut` aktif.
// Multiple: RefMut`s mung bisa aktif ing wektu yen padha deleng béda, komponen nonoverlapping saka `RefCell` (eg, kisaran beda saka irisan a).
//
// `Ref` lan `RefMut` kalorone rong tembung, mula ora bakal ana cukup `Ref`s utawa`RefMut` sing bakal kebanjiran setengah saka kisaran `usize`.
// Mangkono, `BorrowFlag` bisa uga ora bakal kebanjiran utawa mlebu.
// Nanging, iki dudu jaminan, amarga program patologis bisa bola-bali nggawe banjur mem::forget `Ref`s utawa`RefMut`s.
// Mangkono, kabeh kode kanthi eksplisit kudu mriksa overflow lan underflow supaya ora aman, utawa paling ora tumindak kanthi bener yen kedadeyan overflow utawa underflow (contone, waca BorrowRef::new).
//
//
//
//
//
//
type BorrowFlag = isize;
const UNUSED: BorrowFlag = 0;

#[inline(always)]
fn is_writing(x: BorrowFlag) -> bool {
    x < UNUSED
}

#[inline(always)]
fn is_reading(x: BorrowFlag) -> bool {
    x > UNUSED
}

impl<T> RefCell<T> {
    /// Nggawe `RefCell` anyar sing ngemot `value`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_refcell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> RefCell<T> {
        RefCell { value: UnsafeCell::new(value), borrow: Cell::new(UNUSED) }
    }

    /// Nganggo `RefCell`, ngasilake angka sing dibungkus.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let five = c.into_inner();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    #[inline]
    pub const fn into_inner(self) -> T {
        // Wiwit fungsi iki njupuk `self` (ing `RefCell`) dening nilai, kompilasi statically verifies sing ora saiki diselang.
        //
        self.value.into_inner()
    }

    /// Ngganti nilai sing dibungkus nganggo sing anyar, ngasilake regane sing lawas, tanpa ngilangi salah siji.
    ///
    ///
    /// Fungsi iki cocog karo [`std::mem::replace`](../mem/fn.replace.html).
    ///
    /// # Panics
    ///
    /// Panics yen regane saiki dipinjam.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace(6);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace", since = "1.24.0")]
    #[track_caller]
    pub fn replace(&self, t: T) -> T {
        mem::replace(&mut *self.borrow_mut(), t)
    }

    /// Ngganti nilai sing dibungkus nganggo sing anyar diitung saka `f`, ngasilake nilai lawas, tanpa ngilangi salah siji.
    ///
    ///
    /// # Panics
    ///
    /// Panics yen regane saiki dipinjam.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace_with(|&mut old| old + 1);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace_swap", since = "1.35.0")]
    #[track_caller]
    pub fn replace_with<F: FnOnce(&mut T) -> T>(&self, f: F) -> T {
        let mut_borrow = &mut *self.borrow_mut();
        let replacement = f(mut_borrow);
        mem::replace(mut_borrow, replacement)
    }

    /// Ganti nilai bungkus `self` kanthi nilai dibungkus `other`, tanpa ngilangi salah siji.
    ///
    ///
    /// Fungsi iki cocok kanggo [`std::mem::swap`](../mem/fn.swap.html).
    ///
    /// # Panics
    ///
    /// Panics yen nilai ing salah siji `RefCell` lagi diselang.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let c = RefCell::new(5);
    /// let d = RefCell::new(6);
    /// c.swap(&d);
    /// assert_eq!(c, RefCell::new(6));
    /// assert_eq!(d, RefCell::new(5));
    /// ```
    #[inline]
    #[stable(feature = "refcell_swap", since = "1.24.0")]
    pub fn swap(&self, other: &Self) {
        mem::swap(&mut *self.borrow_mut(), &mut *other.borrow_mut())
    }
}

impl<T: ?Sized> RefCell<T> {
    /// Immutably borrows Nilai kebungkus.
    ///
    /// Pinjaman tetep nganti `Ref` metu saka ruang lingkup.
    /// Pinjaman pirang-pirang sing ora bisa diowahi bisa dijupuk bebarengan.
    ///
    /// # Panics
    ///
    /// Panics yen regane saiki bisa diganti.
    /// Kanggo varian non-panicking, nggunakake [`try_borrow`](#method.try_borrow).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let borrowed_five = c.borrow();
    /// let borrowed_five2 = c.borrow();
    /// ```
    ///
    /// Tuladha panic:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let m = c.borrow_mut();
    /// let b = c.borrow(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow(&self) -> Ref<'_, T> {
        self.try_borrow().expect("already mutably borrowed")
    }

    /// Ora bisa ganti nyilih regane sing wis dibungkus, ngasilake kesalahan yen regane saiki bisa diganti.
    ///
    ///
    /// Pinjaman tetep nganti `Ref` metu saka ruang lingkup.
    /// Pinjaman pirang-pirang sing ora bisa diowahi bisa dijupuk bebarengan.
    ///
    /// Iki varian non-panicking saka [`borrow`](#method.borrow).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(c.try_borrow().is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow().is_ok());
    /// }
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow(&self) -> Result<Ref<'_, T>, BorrowError> {
        match BorrowRef::new(&self.borrow) {
            // SAFETY: `BorrowRef` agawé ana mung akses tetep
            // kanggo regane nalika disilih.
            Some(b) => Ok(Ref { value: unsafe { &*self.value.get() }, borrow: b }),
            None => Err(BorrowError { _private: () }),
        }
    }

    /// Mutably borrows Nilai kebungkus.
    ///
    /// Pinjaman tetep nganti `RefMut` bali utawa kabeh `RefMut` sing ditemokake saka ruang lingkup.
    ///
    /// Regane ora bisa dipinjam nalika utang iki aktif.
    ///
    /// # Panics
    ///
    /// Panics yen regane saiki dipinjam.
    /// Kanggo varian sing ora panik, gunakake [`try_borrow_mut`](#method.try_borrow_mut).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new("hello".to_owned());
    ///
    /// *c.borrow_mut() = "bonjour".to_owned();
    ///
    /// assert_eq!(&*c.borrow(), "bonjour");
    /// ```
    ///
    /// Tuladha panic:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let m = c.borrow();
    ///
    /// let b = c.borrow_mut(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow_mut(&self) -> RefMut<'_, T> {
        self.try_borrow_mut().expect("already borrowed")
    }

    /// Bisa ganti nyilih nilai sing dibungkus, ngasilake kesalahan yen regane saiki dipinjam.
    ///
    ///
    /// Pinjaman tetep nganti `RefMut` bali utawa kabeh `RefMut` sing ditemokake saka ruang lingkup.
    /// Regane ora bisa dipinjam nalika utang iki aktif.
    ///
    /// Iki minangka varian non-panicking [`borrow_mut`](#method.borrow_mut).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow_mut().is_err());
    /// }
    ///
    /// assert!(c.try_borrow_mut().is_ok());
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow_mut(&self) -> Result<RefMut<'_, T>, BorrowMutError> {
        match BorrowRefMut::new(&self.borrow) {
            // SAFETY: `BorrowRef` njamin akses unik.
            Some(b) => Ok(RefMut { value: unsafe { &mut *self.value.get() }, borrow: b }),
            None => Err(BorrowMutError { _private: () }),
        }
    }

    /// Ngasilake pitunjuk mentah menyang data sing ana ing sel iki.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    pub fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// Ngasilake referensi sing bisa diowahi kanggo data sing ndasari.
    ///
    /// Panggilan iki nyilih `RefCell` bisa diganti (nalika dikompilasi) dadi ora prelu mriksa dinamis.
    ///
    /// Nanging kudu ati-ati: cara iki ngarepake `self` bisa diowahi, sing umume dudu nalika nggunakake `RefCell`.
    ///
    /// Priksa cara [`borrow_mut`] yen `self` ora bisa diowahi.
    ///
    /// Kajaba iku, priksa manawa metode iki mung kanggo kahanan khusus lan biasane ora kaya sing dikarepake.
    /// Yen ora mangu, gunakake [`borrow_mut`].
    ///
    /// [`borrow_mut`]: RefCell::borrow_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c, RefCell::new(6));
    /// ```
    ///
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// Batalaken efek saka pengawal trocoh ing negara utang saka `RefCell`.
    ///
    /// Telpon iki padha karo [`get_mut`] nanging luwih khusus.
    /// Nyilih `RefCell` kanthi mutlak kanggo mesthekake yen ora ana utangan banjur ngreset maneh utang sing dilacak negara.
    /// Iki cocog yen sawetara `Ref` utawa `RefMut` sing wis trocoh.
    ///
    /// [`get_mut`]: RefCell::get_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(0);
    /// std::mem::forget(c.borrow_mut());
    ///
    /// assert!(c.try_borrow().is_err());
    /// c.undo_leak();
    /// assert!(c.try_borrow().is_ok());
    /// ```
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn undo_leak(&mut self) -> &mut T {
        *self.borrow.get_mut() = UNUSED;
        self.get_mut()
    }

    /// Ora bisa ganti nyilih regane sing wis dibungkus, ngasilake kesalahan yen regane saiki bisa diganti.
    ///
    /// # Safety
    ///
    /// Beda karo `RefCell::borrow`, cara iki ora aman amarga ora ngasilake `Ref`, mula bendera utang ora tutul.
    /// Mutably utang ing `RefCell` nalika referensi bali dening cara iki urip iku prilaku cetho.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_ok());
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "borrow_state", since = "1.37.0")]
    #[inline]
    pub unsafe fn try_borrow_unguarded(&self) -> Result<&T, BorrowError> {
        if !is_writing(self.borrow.get()) {
            // SAFETY: Kita mriksa manawa ora ana sing aktif nulis saiki, nanging
            // tanggung jawab panelpon kanggo mesthekake ora ana sing nulis nganti referensi bali ora digunakake maneh.
            // Uga, `self.value.get()` nuduhake nilai sing diduweni dening `self` lan mulane dijamin bisa valid sajrone umur `self`.
            //
            //
            Ok(unsafe { &*self.value.get() })
        } else {
            Err(BorrowError { _private: () })
        }
    }
}

impl<T: Default> RefCell<T> {
    /// Nganggo nilai sing dibungkus, kari `Default::default()` ing panggonane.
    ///
    /// # Panics
    ///
    /// Panics yen regane saiki dipinjam.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "refcell_take", since = "1.50.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for RefCell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for RefCell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for RefCell<T> {
    /// # Panics
    ///
    /// Panics yen regane saiki bisa diganti.
    #[inline]
    #[track_caller]
    fn clone(&self) -> RefCell<T> {
        RefCell::new(self.borrow().clone())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for RefCell<T> {
    /// Nggawe `RefCell<T>`, karo nilai `Default` kanggo T.
    #[inline]
    fn default() -> RefCell<T> {
        RefCell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for RefCell<T> {
    /// # Panics
    ///
    /// Panics yen nilai ing salah siji `RefCell` lagi diselang.
    #[inline]
    fn eq(&self, other: &RefCell<T>) -> bool {
        *self.borrow() == *other.borrow()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: ?Sized + Eq> Eq for RefCell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for RefCell<T> {
    /// # Panics
    ///
    /// Panics yen nilai ing salah siji `RefCell` lagi diselang.
    #[inline]
    fn partial_cmp(&self, other: &RefCell<T>) -> Option<Ordering> {
        self.borrow().partial_cmp(&*other.borrow())
    }

    /// # Panics
    ///
    /// Panics yen nilai ing salah siji `RefCell` lagi diselang.
    #[inline]
    fn lt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() < *other.borrow()
    }

    /// # Panics
    ///
    /// Panics yen nilai ing salah siji `RefCell` lagi diselang.
    #[inline]
    fn le(&self, other: &RefCell<T>) -> bool {
        *self.borrow() <= *other.borrow()
    }

    /// # Panics
    ///
    /// Panics yen nilai ing salah siji `RefCell` lagi diselang.
    #[inline]
    fn gt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() > *other.borrow()
    }

    /// # Panics
    ///
    /// Panics yen nilai ing salah siji `RefCell` lagi diselang.
    #[inline]
    fn ge(&self, other: &RefCell<T>) -> bool {
        *self.borrow() >= *other.borrow()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + Ord> Ord for RefCell<T> {
    /// # Panics
    ///
    /// Panics yen nilai ing salah siji `RefCell` lagi diselang.
    #[inline]
    fn cmp(&self, other: &RefCell<T>) -> Ordering {
        self.borrow().cmp(&*other.borrow())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for RefCell<T> {
    fn from(t: T) -> RefCell<T> {
        RefCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<RefCell<U>> for RefCell<T> {}

struct BorrowRef<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl<'b> BorrowRef<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRef<'b>> {
        let b = borrow.get().wrapping_add(1);
        if !is_reading(b) {
            // Incrementing utang bisa kasil Nilai non-maca (<=0) ing kasus iki:
            // 1. Yaiku <0, yaiku ana utang nulis, mula ora bisa ngidini utang sing diwaca amarga aturan aliasing referensi Rust
            // 2.
            // Iku isize::MAX (jumlah max saka maca borrows) lan overflowed menyang isize::MIN (jumlah max nulis borrows) supaya kita ora bisa ngidini diwaca utang tambahan amarga isize ora bisa makili dadi akeh borrows diwaca (iki mung bisa kelakon yen sampeyan mem::forget luwih saka sekedhik pancet `Ref`s, sing dudu praktik sing apik)
            //
            //
            //
            //
            None
        } else {
            // Incrementing utang bisa kasil Nilai maca (> 0) ing kasus iki:
            // 1. Iku=0, IE iki ora diselang, lan kita njupuk ing diwaca utang pisanan
            // 2. Iku> 0 lan <isize::MAX, IE
            // ana borrows diwaca, lan isize cukup gedhe kanggo makili gadhah siji utang liyane diwaca
            borrow.set(b);
            Some(BorrowRef { borrow })
        }
    }
}

impl Drop for BorrowRef<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        self.borrow.set(borrow - 1);
    }
}

impl Clone for BorrowRef<'_> {
    #[inline]
    fn clone(&self) -> Self {
        // Amarga Ref iki ana, kita ngerti yen bendera utang yaiku utang maca.
        //
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        // Nyegah counter utang saka kakehan dadi utang nulis.
        //
        assert!(borrow != isize::MAX);
        self.borrow.set(borrow + 1);
        BorrowRef { borrow: self.borrow }
    }
}

/// Bungkus referensi sing disilih menyang nilai ing kothak `RefCell`.
/// A jinis pambungkus kanggo nilai immutably diselang saka `RefCell<T>`.
///
/// Deleng [module-level documentation](self) kanggo liyane.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Ref<'b, T: ?Sized + 'b> {
    value: &'b T,
    borrow: BorrowRef<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Ref<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

impl<'b, T: ?Sized> Ref<'b, T> {
    /// Nyalin `Ref`.
    ///
    /// `RefCell` wis ora bisa diganti maneh, mula ora bakal gagal.
    ///
    /// Iki minangka fungsi sing gegandhengan sing kudu digunakake minangka `Ref::clone(...)`.
    /// A implementasine `Clone` utawa cara bakal ngganggu nyebar nggunakake `r.borrow().clone()` tiron isi `RefCell`.
    ///
    ///
    #[stable(feature = "cell_extras", since = "1.15.0")]
    #[inline]
    pub fn clone(orig: &Ref<'b, T>) -> Ref<'b, T> {
        Ref { value: orig.value, borrow: orig.borrow.clone() }
    }

    /// Nggawe `Ref` anyar kanggo komponen data sing dipinjam.
    ///
    /// `RefCell` wis ora bisa diganti maneh, mula ora bakal gagal.
    ///
    /// Iki minangka fungsi sing gegandhengan sing kudu digunakake minangka `Ref::map(...)`.
    /// Cara sing bakal ngganggu metode kanthi jeneng sing padha ing konten `RefCell` sing digunakake liwat `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// let b1: Ref<(u32, char)> = c.borrow();
    /// let b2: Ref<u32> = Ref::map(b1, |t| &t.0);
    /// assert_eq!(*b2, 5)
    /// ```
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Ref<'b, U>
    where
        F: FnOnce(&T) -> &U,
    {
        Ref { value: f(orig.value), borrow: orig.borrow }
    }

    /// Ndadekake `Ref` anyar kanggo komponen pilihan saka data diselang.
    /// Ing njaga asli wis bali minangka `Err(..)` yen penutupan kasus ngasilake `None`.
    ///
    /// `RefCell` wis ora bisa diganti maneh, mula ora bakal gagal.
    ///
    /// Iki minangka fungsi sing gegandhengan sing kudu digunakake minangka `Ref::filter_map(...)`.
    /// Cara sing bakal ngganggu metode kanthi jeneng sing padha ing konten `RefCell` sing digunakake liwat `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    /// let b1: Ref<Vec<u32>> = c.borrow();
    /// let b2: Result<Ref<u32>, _> = Ref::filter_map(b1, |v| v.get(1));
    /// assert_eq!(*b2.unwrap(), 2);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Result<Ref<'b, U>, Self>
    where
        F: FnOnce(&T) -> Option<&U>,
    {
        match f(orig.value) {
            Some(value) => Ok(Ref { value, borrow: orig.borrow }),
            None => Err(orig),
        }
    }

    /// Pamisahan sing `Ref` menyang macem-macem: Ref`s kanggo macem-macem komponen saka data diselang.
    ///
    /// `RefCell` wis ora bisa diganti maneh, mula ora bakal gagal.
    ///
    /// Iki minangka fungsi sing gegandhengan sing kudu digunakake minangka `Ref::map_split(...)`.
    /// Cara sing bakal ngganggu metode kanthi jeneng sing padha ing konten `RefCell` sing digunakake liwat `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{Ref, RefCell};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow();
    /// let (begin, end) = Ref::map_split(borrow, |slice| slice.split_at(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// ```
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(orig: Ref<'b, T>, f: F) -> (Ref<'b, U>, Ref<'b, V>)
    where
        F: FnOnce(&T) -> (&U, &V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (Ref { value: a, borrow }, Ref { value: b, borrow: orig.borrow })
    }

    /// Ngonversi menyang referensi kanggo data ndasari.
    ///
    /// Ndasari `RefCell` tau bisa mutably dijupuk saka maneh lan bakal tansah katon wis immutably diselang.
    ///
    /// Ora apike bocor luwih akeh tinimbang referensi sing terus-terusan.
    /// The `RefCell` bisa immutably diselang maneh yen mung nomer cilik bocor wis dumadi ing total.
    ///
    /// Iki minangka fungsi sing gegandhengan sing kudu digunakake minangka `Ref::leak(...)`.
    /// Cara sing bakal ngganggu metode kanthi jeneng sing padha ing konten `RefCell` sing digunakake liwat `Deref`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, Ref};
    /// let cell = RefCell::new(0);
    ///
    /// let value = Ref::leak(cell.borrow());
    /// assert_eq!(*value, 0);
    ///
    /// assert!(cell.try_borrow().is_ok());
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: Ref<'b, T>) -> &'b T {
        // Kanthi lali karo Ref iki, kita mesthekake manawa counter utang ing RefCell ora bisa bali menyang UNUSED sajrone `'b`.
        // Ngreset negara ranging referensi bakal mbutuhake referensi unik RefCell diselang.
        // Ora ana referensi sing bisa diowahi maneh saka sel asli.
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Ref<'b, U>> for Ref<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Ref<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

impl<'b, T: ?Sized> RefMut<'b, T> {
    /// Ndadekake `RefMut` anyar kanggo komponèn saka data diselang, contone, lan enum varian.
    ///
    /// The `RefCell` wis mutably diselang, supaya iki ora bisa gagal.
    ///
    /// Iki fungsi sing kagayut sing perlu kanggo digunakake minangka `RefMut::map(...)`.
    /// Cara sing bakal ngganggu metode kanthi jeneng sing padha ing konten `RefCell` sing digunakake liwat `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// {
    ///     let b1: RefMut<(u32, char)> = c.borrow_mut();
    ///     let mut b2: RefMut<u32> = RefMut::map(b1, |t| &mut t.0);
    ///     assert_eq!(*b2, 5);
    ///     *b2 = 42;
    /// }
    /// assert_eq!(*c.borrow(), (42, 'b'));
    /// ```
    ///
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> RefMut<'b, U>
    where
        F: FnOnce(&mut T) -> &mut U,
    {
        // FIXME(nll-rfc#40): ndandani utang-mriksa
        let RefMut { value, borrow } = orig;
        RefMut { value: f(value), borrow }
    }

    /// Ndadekake `RefMut` anyar kanggo komponen pilihan saka data diselang.
    /// Ing njaga asli wis bali minangka `Err(..)` yen penutupan kasus ngasilake `None`.
    ///
    /// The `RefCell` wis mutably diselang, supaya iki ora bisa gagal.
    ///
    /// Iki minangka fungsi sing gegandhengan sing kudu digunakake minangka `RefMut::filter_map(...)`.
    /// Cara sing bakal ngganggu metode kanthi jeneng sing padha ing konten `RefCell` sing digunakake liwat `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    ///
    /// {
    ///     let b1: RefMut<Vec<u32>> = c.borrow_mut();
    ///     let mut b2: Result<RefMut<u32>, _> = RefMut::filter_map(b1, |v| v.get_mut(1));
    ///
    ///     if let Ok(mut b2) = b2 {
    ///         *b2 += 2;
    ///     }
    /// }
    ///
    /// assert_eq!(*c.borrow(), vec![1, 4, 3]);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> Result<RefMut<'b, U>, Self>
    where
        F: FnOnce(&mut T) -> Option<&mut U>,
    {
        // FIXME(nll-rfc#40): ndandani utang-mriksa
        let RefMut { value, borrow } = orig;
        let value = value as *mut T;
        // SAFETY: fungsi nduwe referensi eksklusif kanggo durasi kasebut
        // telpon liwat `orig`, lan penunjuk mung dirujuk ing njero telpon fungsi ora nate ngidini referensi eksklusif bisa uwal.
        //
        //
        match f(unsafe { &mut *value }) {
            Some(value) => Ok(RefMut { value, borrow }),
            None => {
                // SAFETY: padha karo ing ndhuwur.
                Err(RefMut { value: unsafe { &mut *value }, borrow })
            }
        }
    }

    /// Misah `RefMut` dadi pirang-pirang `RefMut` kanggo macem-macem komponen data sing dipinjam.
    ///
    /// `RefCell` sing ndasari bakal tetep bisa diselang nganti loro RefMut bali ora ana ing lingkup.
    ///
    /// The `RefCell` wis mutably diselang, supaya iki ora bisa gagal.
    ///
    /// Iki minangka fungsi sing gegandhengan sing kudu digunakake minangka `RefMut::map_split(...)`.
    /// Cara sing bakal ngganggu metode kanthi jeneng sing padha ing konten `RefCell` sing digunakake liwat `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow_mut();
    /// let (mut begin, mut end) = RefMut::map_split(borrow, |slice| slice.split_at_mut(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// begin.copy_from_slice(&[4, 3]);
    /// end.copy_from_slice(&[2, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(
        orig: RefMut<'b, T>,
        f: F,
    ) -> (RefMut<'b, U>, RefMut<'b, V>)
    where
        F: FnOnce(&mut T) -> (&mut U, &mut V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (RefMut { value: a, borrow }, RefMut { value: b, borrow: orig.borrow })
    }

    /// Ngonversi dadi referensi sing bisa diowahi kanggo data sing ndasari.
    ///
    /// Ndasari `RefCell` ora bisa dijupuk saka maneh lan bakal tansah katon wis mutably diselang, nggawe referensi bali mung kanggo interior.
    ///
    ///
    /// Iki fungsi sing kagayut sing perlu kanggo digunakake minangka `RefMut::leak(...)`.
    /// Cara sing bakal ngganggu metode kanthi jeneng sing padha ing konten `RefCell` sing digunakake liwat `Deref`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, RefMut};
    /// let cell = RefCell::new(0);
    ///
    /// let value = RefMut::leak(cell.borrow_mut());
    /// assert_eq!(*value, 0);
    /// *value = 1;
    ///
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: RefMut<'b, T>) -> &'b mut T {
        // Kanthi lali karo BorrowRefMut iki, kita njamin manawa counter utang ing RefCell ora bisa bali menyang UNUSED sajrone `'b`.
        // Ngreset negara ranging referensi bakal mbutuhake referensi unik RefCell diselang.
        // Ora referensi luwih bisa digawe saka sel asli umur sing, nggawe utang saiki mung referensi kanggo umur isih.
        //
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

struct BorrowRefMut<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl Drop for BorrowRefMut<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        self.borrow.set(borrow + 1);
    }
}

impl<'b> BorrowRefMut<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRefMut<'b>> {
        // NOTE: Boten kados BorrowRefMut::clone, anyar diarani nggawe dhisikan
        // referensi sing bisa diowahi, mula saiki ora ana referensi sing ana.
        // Mangkono, nalika klone nambah angka ulang sing bisa diowahi, ing kene kanthi tegas mung ngidini saka UNUSED menyang UNUSED, 1.
        //
        match borrow.get() {
            UNUSED => {
                borrow.set(UNUSED - 1);
                Some(BorrowRefMut { borrow })
            }
            _ => None,
        }
    }

    // Klone `BorrowRefMut`.
    //
    // Iki mung ditrapake yen saben `BorrowRefMut` digunakake kanggo nglacak referensi sing bisa diowahi menyang macem-macem obyek sing beda-beda saka obyek asli.
    //
    // Iki ora ana ing impl Clone supaya kode ora nyebutake kanthi implisit.
    #[inline]
    fn clone(&self) -> BorrowRefMut<'b> {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        // Nyegah counter loan supaya ora akeh banget.
        assert!(borrow != isize::MIN);
        self.borrow.set(borrow - 1);
        BorrowRefMut { borrow: self.borrow }
    }
}

/// A jinis pambungkus kanggo Nilai mutably diselang saka `RefCell<T>`.
///
/// Deleng [module-level documentation](self) kanggo liyane.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefMut<'b, T: ?Sized + 'b> {
    value: &'b mut T,
    borrow: BorrowRefMut<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for RefMut<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for RefMut<'_, T> {
    #[inline]
    fn deref_mut(&mut self) -> &mut T {
        self.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<RefMut<'b, U>> for RefMut<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for RefMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

/// inti primitif kanggo mutability interior ing Rust.
///
/// Yen sampeyan duwe referensi `&T`, banjur biasane ing Rust kompilasi performs optimizations adhedhasar kawruh sing `&T` TCTerms kanggo data wong.Mutating sing data, contone liwat alias utawa dening transmuting lan `&T` menyang `&mut T`, dianggep prilaku cetho.
/// `UnsafeCell<T>` milih metu saka jaminan sing ora bisa diganti kanggo `&T`: referensi `&UnsafeCell<T>` sing dituduhake bisa uga nuduhake data sing lagi dimatakake.Iki diarani "interior mutability".
///
/// Kabeh jinis liyane sing ngidini mutasi internal, kayata `Cell<T>` lan `RefCell<T>`, nggunakake internal `UnsafeCell` kanggo mbungkus data.
///
/// Elinga yen mung jaminan sing ora bisa diganti kanggo referensi bareng kena pengaruh `UnsafeCell`.Njamin uniqueness kanggo referensi mutable iku ora kena pengaruh.Ana *ora* cara legal diwenehi aliasing `&mut`, ora malah karo `UnsafeCell<T>`.
///
/// The `UnsafeCell` API dhewe iku teknis banget prasaja: [`.get()`] menehi pitunjuk `*mut T` mentahan kanggo isi.Iku nganti _you_ minangka Desainer abstraksi kanggo nggunakake pitunjuk mentahan bener.
///
/// [`.get()`]: `UnsafeCell::get`
///
/// Aturan aliasing Rust sing pas wis rada lancar, nanging intine ora regejegan:
///
/// - Yen sampeyan nggawe referensi aman kanthi umur `'a` (referensi `&T` utawa `&mut T`) sing bisa diakses nganggo kode aman (contone, amarga sampeyan mbalekake), mula ora kudu ngakses data kanthi cara apa wae sing bertentangan karo referensi kanggo sisa saka `'a`.
/// Contone, iki tegese yen sampeyan njupuk `*mut T` saka `UnsafeCell<T>` lan dikirim menyang `&T`, mula data ing `T` kudu tetep ora bisa diowahi (modulo data `UnsafeCell` sing ditemokake ing `T`, mesthi wae) nganti umur referensi kasebut kadaluwarsa.
/// Kajaba, yen sampeyan nggawe referensi `&mut T` sing diluncurake menyang kode aman, sampeyan ora kudu ngakses data ing `UnsafeCell` nganti referensi kasebut kadaluwarsa.
///
/// - Kabeh wektu, sampeyan kudu ngindhari balapan data.Yen pirang-pirang utas duwe akses menyang `UnsafeCell` sing padha, mula wae nulis kudu ana hubungane sadurunge karo kabeh akses liyane (utawa nggunakake atom).
///
/// Ngewangi karo desain sing tepat, cara ing ngisor iki sing tegas ngumumaké legal kanggo kode siji-Utas:
///
/// 1. referensi A `&T` bisa dirilis kanggo kode aman lan ana bisa co-ana referensi liyane `&T`, nanging ora karo `&mut T`
///
/// 2. Referensi `&mut T` bisa uga diluncurake menyang kode sing aman yen ora ana `&mut T` utawa `&T` liyane sing ana.A `&mut T` kudu tansah dadi unik.
///
/// Wigati sing salawasé mutating isi `&UnsafeCell<T>` (malah nalika referensi `&UnsafeCell<T>` liyane alias sel) iku ok (kasedhiya dilakokaké ing invariants ndhuwur sawetara cara liyane), iku isih prilaku undefined duwe macem-macem jeneng alias `&mut UnsafeCell<T>`.
/// Yaiku, `UnsafeCell` minangka bungkus sing dirancang kanggo duwe interaksi khusus karo _shared_ accesses (_i.e._, liwat referensi `&UnsafeCell<_>`);ana Piandel punapa wae nalika dealing with _exclusive_ accesses (_e.g._, liwat `&mut UnsafeCell<_>`): sanadyan ing sel utawa nilai kebungkus bisa aliased kanggo duration sing `&mut` utang.
///
/// Iki showcased dening accessor [`.get_mut()`], kang getter _safe_ sing panenan sing `&mut T`.
///
/// [`.get_mut()`]: `UnsafeCell::get_mut`
///
/// # Examples
///
/// Mangkene conto sing nuduhake cara mutasi konten `UnsafeCell<_>` kanthi apik sanajan ana pirang-pirang referensi aliasing sel:
///
/// ```
/// use std::cell::UnsafeCell;
///
/// let x: UnsafeCell<i32> = 42.into();
/// // Entuk pirang-pirang/bareng referensi menyang `x` sing padha.
/// let (p1, p2): (&UnsafeCell<i32>, &UnsafeCell<i32>) = (&x, &x);
///
/// unsafe {
///     // SAFETY: ing ruang lingkup iki, ora ana referensi liyane kanggo isi `x`,
///     // dadi kita pancen unik.
///     let p1_exclusive: &mut i32 = &mut *p1.get(); // -- nyilih-+
///     *p1_exclusive += 27; // |
/// } // <---------- ora bisa ngluwihi titik iki -------------------+
///
/// unsafe {
///     // SAFETY: ing ruang lingkup iki, ora ana sing ngarepake duwe akses eksklusif menyang konten `x`,
///     // dadi kita bisa duwe macem-macem akses bareng.
///     let p2_shared: &i32 = &*p2.get();
///     assert_eq!(*p2_shared, 42 + 27);
///     let p1_shared: &i32 = &*p1.get();
///     assert_eq!(*p1_shared, *p2_shared);
/// }
/// ```
///
/// Tuladha ing ngisor iki etalase kasunyatan sing akses eksklusif kanggo `UnsafeCell<T>` nggadahi akses eksklusif kanggo sawijining `T`:
///
/// ```rust
/// #![forbid(unsafe_code)] // kanthi akses eksklusif,
///                         // `UnsafeCell` iku ora-op pambungkus transparent, dadi ora perlu kanggo `unsafe` kene.
/////
/// use std::cell::UnsafeCell;
///
/// let mut x: UnsafeCell<i32> = 42.into();
///
/// // Entuk referensi unik sing dicenthang kanthi kompilasi menyang `x`.
/// let p_unique: &mut UnsafeCell<i32> = &mut x;
/// // Kanthi referensi eksklusif, kita bisa mutasi konten kanthi gratis.
/// *p_unique.get_mut() = 0;
/// // Utawa, equivalently:
/// x = UnsafeCell::new(0);
///
/// // Yen duwe regane, kita bisa ngekstrak konten kanthi gratis.
/// let contents: i32 = x.into_inner();
/// assert_eq!(contents, 0);
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "unsafe_cell"]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
#[repr(no_niche)] // rust-lang/rust#68303.
pub struct UnsafeCell<T: ?Sized> {
    value: T,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for UnsafeCell<T> {}

impl<T> UnsafeCell<T> {
    /// Mbangun Kayata anyar `UnsafeCell` kang bakal Lebokake Nilai kasebut.
    ///
    ///
    /// Kabeh akses menyang nilai batin liwat metode yaiku `unsafe`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafe_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> UnsafeCell<T> {
        UnsafeCell { value }
    }

    /// Mbusak regane.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.into_inner();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value
    }
}

impl<T: ?Sized> UnsafeCell<T> {
    /// Entuk penunjuk sing bisa diowahi kanggo nilai sing dibungkus.
    ///
    /// Iki bisa dadi cast kanggo pitunjuk jinis.
    /// Mesthekake yen akses punika unik (ora referensi aktif, mutable utawa ora) nalika casting kanggo `&mut T`, lan mesthekake yen ana wujud utawa jeneng alias mutable arep ing nalika casting kanggo `&T`
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.get();
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafecell_get", since = "1.32.0")]
    pub const fn get(&self) -> *mut T {
        // Kita mung bisa milih pointer saka `UnsafeCell<T>` dadi `T` amarga #[repr(transparent)].
        // Iki exploitasi status khusus libstd kang, ana ora njamin kanggo kode panganggo sing iki bisa ing versi future saka compiler sing!
        //
        self as *const UnsafeCell<T> as *const T as *mut T
    }

    /// Ngasilake referensi sing bisa diowahi kanggo data sing ndasari.
    ///
    /// telpon iki borrows ing `UnsafeCell` mutably (ing ngripta-wektu) kang njamin sing kita ugi mung referensi.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let mut c = UnsafeCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(*c.get_mut(), 6);
    /// ```
    #[inline]
    #[stable(feature = "unsafe_cell_get_mut", since = "1.50.0")]
    pub fn get_mut(&mut self) -> &mut T {
        &mut self.value
    }

    /// Entuk penunjuk sing bisa diowahi kanggo nilai sing dibungkus.
    /// Bedane kanggo [`get`] yaiku fungsi iki nampa pointer mentah, sing migunani kanggo nyegah nggawe referensi sementara.
    ///
    /// Asil bisa matak pitunjuk jinis.
    /// Mesthekake yen akses punika (referensi ora aktif, mutable utawa ora) unik nalika casting kanggo `&mut T`, lan mesthekake yen ana wujud utawa jeneng alias mutable arep ing nalika casting kanggo `&T`.
    ///
    ///
    /// [`get`]: UnsafeCell::get()
    ///
    /// # Examples
    ///
    /// initialization bertahap saka `UnsafeCell` mbutuhake `raw_get`, minangka nelpon `get` bakal mbutuhake nggawe referensi kanggo data uninitialized:
    ///
    /// ```
    /// #![feature(unsafe_cell_raw_get)]
    /// use std::cell::UnsafeCell;
    /// use std::mem::MaybeUninit;
    ///
    /// let m = MaybeUninit::<UnsafeCell<i32>>::uninit();
    /// unsafe { UnsafeCell::raw_get(m.as_ptr()).write(5); }
    /// let uc = unsafe { m.assume_init() };
    ///
    /// assert_eq!(uc.into_inner(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "unsafe_cell_raw_get", issue = "66358")]
    pub const fn raw_get(this: *const Self) -> *mut T {
        // Kita mung bisa milih pointer saka `UnsafeCell<T>` dadi `T` amarga #[repr(transparent)].
        // Iki exploitasi status khusus libstd kang, ana ora njamin kanggo kode panganggo sing iki bisa ing versi future saka compiler sing!
        //
        this as *const T as *mut T
    }
}

#[stable(feature = "unsafe_cell_default", since = "1.10.0")]
impl<T: Default> Default for UnsafeCell<T> {
    /// Nggawe `UnsafeCell`, kanthi nilai `Default` kanggo T.
    fn default() -> UnsafeCell<T> {
        UnsafeCell::new(Default::default())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for UnsafeCell<T> {
    fn from(t: T) -> UnsafeCell<T> {
        UnsafeCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<UnsafeCell<U>> for UnsafeCell<T> {}

#[allow(unused)]
fn assert_coerce_unsized(a: UnsafeCell<&i32>, b: Cell<&i32>, c: RefCell<&i32>) {
    let _: UnsafeCell<&dyn Send> = a;
    let _: Cell<&dyn Send> = b;
    let _: RefCell<&dyn Send> = c;
}