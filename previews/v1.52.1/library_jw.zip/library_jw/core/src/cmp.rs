//! Fungsi kanggo nindakake lan comparison.
//!
//! Modul iki ngemot macem-macem alat kanggo pesen lan mbandhingake nilai.Ringkesan:
//!
//! * [`Eq`] lan [`PartialEq`] sing traits sing ngijini sampeyan kanggo netepake podo total lan sebagean antarane nilai-nilai, mungguh.
//! Ngleksanakake kakehan operator `==` lan `!=`.
//! * [`Ord`] lan [`PartialOrd`] minangka traits sing ngidini sampeyan nemtokake urutan total lan sebagean antarane nilai.
//!
//! Ngleksanakake kakehan operator `<`, `<=`, `>`, lan `>=`.
//! * [`Ordering`] iku sawijining enum bali dening fungsi utama [`Ord`] lan [`PartialOrd`], lan nggambaraké sawijining nindakake.
//! * [`Reverse`] punika struct sing ngijini sampeyan kanggo gampang malik lan nindakake.
//! * [`max`] lan [`min`] sing fungsi sing mbangun mati saka [`Ord`] lan ngidini sampeyan kanggo nemokake maksimum utawa minimal rong angka.
//!
//! Kanggo rincian liyane, waca dokumentasi pamilike saben item ing dhaptar.
//!
//! [`max`]: Ord::max
//! [`min`]: Ord::min
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use self::Ordering::*;

/// Trait kanggo mbandhingake kesetaraan yaiku [partial equivalence relations](https://en.wikipedia.org/wiki/Partial_equivalence_relation).
///
/// trait iki ngidini persamaan parsial, kanggo jinis sing ora ana hubungane karo kesetaraan.
/// Contone, ing nomer ngambang titik `NaN != NaN`, supaya jinis ngambang titik ngleksanakake `PartialEq` nanging ora [`trait@Eq`].
///
/// Resmi, podo kudu (kanggo kabeh `a`, `b`, `c` saka jinis `A`, `B`, `C`):
///
/// - **Simetris**: yen `A: PartialEq<B>` lan `B: PartialEq<A>`, mula **`a==b` tegese`b==a`**;lan
///
/// - **Transitif**: yen `A: PartialEq<B>` lan `B: PartialEq<C>` lan `A:
///   PartialEq<C>`, banjur **` a==b`lan `b == c` tegese`a==c`**.
///
/// Elinga yen impl `B: PartialEq<A>` (symmetric) lan `A: PartialEq<C>` (transitive) ora dipeksa ana, nanging syarat kasebut ditrapake nalika ana.
///
/// ## Derivable
///
/// trait iki bisa digunakake nganggo `#[derive]`.Nalika: derive`d ing structs, loro kedadean sing padha yen kabeh kothak sing padha, lan ora witjaksono yen sembarang kothak ora padha.Nalika`turunan`d ing enum, saben varian padha karo awake dhewe lan ora padha karo varian liyane.
///
/// ## Kepiye cara ngetrapake `PartialEq`?
///
/// `PartialEq` mung mbutuhake cara [`eq`] kanggo dileksanakake;[`ne`] ditetepake kanthi standar.Implementasi manual [`ne`]*kudu* ngormati aturan yen [`eq`] minangka kuwalik [`ne`] sing ketat;yaiku, `!(a == b)` yen lan mung yen `a != b`.
///
/// Implementasi `PartialEq`, [`PartialOrd`], lan [`Ord`]*kudu* saling setuju.Iku gampang kanggo sengaja nggawe wong ora setuju dening deriving sawetara saka traits lan manual penerapan wong.
///
/// Conto implementasine kanggo domain kang loro buku sing dianggep buku padha yen cocog ISBN sing, malah yen format beda-beda:
///
/// ```
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// impl PartialEq for Book {
///     fn eq(&self, other: &Self) -> bool {
///         self.isbn == other.isbn
///     }
/// }
///
/// let b1 = Book { isbn: 3, format: BookFormat::Paperback };
/// let b2 = Book { isbn: 3, format: BookFormat::Ebook };
/// let b3 = Book { isbn: 10, format: BookFormat::Paperback };
///
/// assert!(b1 == b2);
/// assert!(b1 != b3);
/// ```
///
/// ## Kepiye cara mbandhingake rong jinis?
///
/// Jinis sing bisa dibandhingake dikontrol dening paramèter jinis `PartialEq`.
/// Contone, ayo ngapiki kode sadurunge:
///
/// ```
/// // Asale alat kasebut<BookFormat>==<BookFormat>bandhingane
/// #[derive(PartialEq)]
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// // Ngleksanakake<Book>==<BookFormat>bandhingane
/// impl PartialEq<BookFormat> for Book {
///     fn eq(&self, other: &BookFormat) -> bool {
///         self.format == *other
///     }
/// }
///
/// // Ngleksanakake<BookFormat>==<Book>bandingaken
/// impl PartialEq<Book> for BookFormat {
///     fn eq(&self, other: &Book) -> bool {
///         *self == other.format
///     }
/// }
///
/// let b1 = Book { isbn: 3, format: BookFormat::Paperback };
///
/// assert!(b1 == BookFormat::Paperback);
/// assert!(BookFormat::Ebook != b1);
/// ```
///
/// Kanthi ngganti `impl PartialEq for Book` kanggo `impl PartialEq<BookFormat> for Book`, kita ngidini: BookFormat`s kanggo dibandhingake karo: Book`s.
///
/// A comparison kaya siji ndhuwur, kang mratelakake sawetara kothak struct, bisa mbebayani.Bisa gampang mimpin kanggo nglanggar unintended syarat kanggo padanan hubungan sebagean.
/// Contone, yen tetep ngetrapake `PartialEq<Book>` ing ndhuwur kanggo `BookFormat` lan nambah implementasine `PartialEq<Book>` kanggo `Book` (bisa uga liwat `#[derive]` utawa liwat implementasi manual saka conto pisanan) mula asile bakal nglanggar transitivitas:
///
///
/// ```should_panic
/// #[derive(PartialEq)]
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// #[derive(PartialEq)]
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// impl PartialEq<BookFormat> for Book {
///     fn eq(&self, other: &BookFormat) -> bool {
///         self.format == *other
///     }
/// }
///
/// impl PartialEq<Book> for BookFormat {
///     fn eq(&self, other: &Book) -> bool {
///         *self == other.format
///     }
/// }
///
/// fn main() {
///     let b1 = Book { isbn: 1, format: BookFormat::Paperback };
///     let b2 = Book { isbn: 2, format: BookFormat::Paperback };
///
///     assert!(b1 == BookFormat::Paperback);
///     assert!(BookFormat::Paperback == b2);
///
///     // The following should hold by transitivity but doesn't.
///     assert!(b1 == b2); // <-- PANICS
/// }
/// ```
///
/// # Examples
///
/// ```
/// let x: u32 = 0;
/// let y: u32 = 1;
///
/// assert_eq!(x == y, false);
/// assert_eq!(x.eq(&y), false);
/// ```
///
/// [`eq`]: PartialEq::eq
/// [`ne`]: PartialEq::ne
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "eq"]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = "==")]
#[doc(alias = "!=")]
#[rustc_on_unimplemented(
    message = "can't compare `{Self}` with `{Rhs}`",
    label = "no implementation for `{Self} == {Rhs}`"
)]
pub trait PartialEq<Rhs: ?Sized = Self> {
    /// Cara iki tes kanggo `self` lan `other` angka dadi witjaksono, lan digunakake dening `==`.
    ///
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn eq(&self, other: &Rhs) -> bool;

    /// Cara iki nyoba `!=`.
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn ne(&self, other: &Rhs) -> bool {
        !self.eq(other)
    }
}

/// Nurunake makro sing ngasilake impl trait `PartialEq`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, structural_match)]
pub macro PartialEq($item:item) {
    /* compiler built-in */
}

/// Trait kanggo mbandhingake kesetaraan yaiku [equivalence relations](https://en.wikipedia.org/wiki/Equivalence_relation).
///
/// Iki tegese, kajaba `a == b` lan `a != b` dadi kuwalik, kesetaraan kudu (kanggo kabeh `a`, `b` lan `c`):
///
/// - reflexive: `a == a`;
/// - simetris: `a == b` gawe katut `b == a`;lan
/// - transitif: `a == b` lan `b == c` tegese `a == c`.
///
/// Properti iki ora bisa dicenthang dening kompilator, lan mulane `Eq` tegese [`PartialEq`], lan ora duwe cara ekstra.
///
/// ## Derivable
///
/// trait iki bisa digunakake nganggo `#[derive]`.
/// Nalika `turunan`d, amarga `Eq` ora duwe metode ekstra, mula mung menehi informasi marang panyusun manawa iki ana hubungane kesetaraan tinimbang hubungan parsial kesetaraan.
///
/// Elinga yen strategi `derive` mbutuhake kabeh lapangan yaiku `Eq`, sing ora mesthi dikarepake.
///
/// ## Kepiye cara ngetrapake `Eq`?
///
/// Yen sampeyan ora bisa nggunakake strategi `derive`, pilih jinis sampeyan ngetrapake `Eq`, sing ora duwe metode:
///
/// ```
/// enum BookFormat { Paperback, Hardback, Ebook }
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
/// impl PartialEq for Book {
///     fn eq(&self, other: &Self) -> bool {
///         self.isbn == other.isbn
///     }
/// }
/// impl Eq for Book {}
/// ```
///
///
///
///
///
#[doc(alias = "==")]
#[doc(alias = "!=")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Eq: PartialEq<Self> {
    // cara iki digunakake mung dening#[nurunake] kanggo negesake manawa kabeh komponen jinis ngetrapake#[turunan] dhewe, infrastruktur nurunake saiki tegese nggawe pratelan iki tanpa nggunakake metode ing trait iki meh ora bisa ditindakake.
    //
    //
    // Iki ora kudu dileksanakake kanthi tangan.
    //
    //
    //
    #[doc(hidden)]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn assert_receiver_is_total_eq(&self) {}
}

/// Nurunake makro sing ngasilake impl trait `Eq`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_eq, structural_match)]
pub macro Eq($item:item) {
    /* compiler built-in */
}

// FIXME: struct iki digunakake namung dening#[Niru] kanggo
// negesake manawa kabeh komponen jinis ngetrapake Eq.
//
// Struktur iki ora kena ditampilake ing kode pangguna.
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(feature = "derive_eq", reason = "deriving hack, should not be public", issue = "none")]
pub struct AssertParamIsEq<T: Eq + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// Lan `Ordering` iku asil saka perbandingan antara rong angka.
///
/// # Examples
///
/// ```
/// use std::cmp::Ordering;
///
/// let result = 1.cmp(&2);
/// assert_eq!(Ordering::Less, result);
///
/// let result = 1.cmp(&1);
/// assert_eq!(Ordering::Equal, result);
///
/// let result = 2.cmp(&1);
/// assert_eq!(Ordering::Greater, result);
/// ```
#[derive(Clone, Copy, PartialEq, Debug, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub enum Ordering {
    /// Pesenan sing regane mbandhingake kurang saka liyane.
    #[stable(feature = "rust1", since = "1.0.0")]
    Less = -1,
    /// Pesenan ing endi nilai sing dibandhingake padha karo sing liyane.
    #[stable(feature = "rust1", since = "1.0.0")]
    Equal = 0,
    /// Pesenan sing nilai mbandhingake luwih gedhe tinimbang liyane.
    #[stable(feature = "rust1", since = "1.0.0")]
    Greater = 1,
}

impl Ordering {
    /// Ngasilake `true` yen pesen yaiku varian `Equal`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_eq(), false);
    /// assert_eq!(Ordering::Equal.is_eq(), true);
    /// assert_eq!(Ordering::Greater.is_eq(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_eq(self) -> bool {
        matches!(self, Equal)
    }

    /// Ngasilake `true` yen nindakake ora varian `Equal`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_ne(), true);
    /// assert_eq!(Ordering::Equal.is_ne(), false);
    /// assert_eq!(Ordering::Greater.is_ne(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_ne(self) -> bool {
        !matches!(self, Equal)
    }

    /// Ngasilake `true` yen nindakake iku varian `Less`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_lt(), true);
    /// assert_eq!(Ordering::Equal.is_lt(), false);
    /// assert_eq!(Ordering::Greater.is_lt(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_lt(self) -> bool {
        matches!(self, Less)
    }

    /// Ngasilake `true` yen nindakake iku varian `Greater`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_gt(), false);
    /// assert_eq!(Ordering::Equal.is_gt(), false);
    /// assert_eq!(Ordering::Greater.is_gt(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_gt(self) -> bool {
        matches!(self, Greater)
    }

    /// Ngasilake `true` yen nindakake iku salah siji `Less` utawa `Equal` varian.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_le(), true);
    /// assert_eq!(Ordering::Equal.is_le(), true);
    /// assert_eq!(Ordering::Greater.is_le(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_le(self) -> bool {
        !matches!(self, Greater)
    }

    /// Ngasilake `true` yen nindakake iku salah siji `Greater` utawa `Equal` varian.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_ge(), false);
    /// assert_eq!(Ordering::Equal.is_ge(), true);
    /// assert_eq!(Ordering::Greater.is_ge(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_ge(self) -> bool {
        !matches!(self, Less)
    }

    /// Mbalik `Ordering`.
    ///
    /// * `Less` dadi `Greater`.
    /// * `Greater` dadi `Less`.
    /// * `Equal` dadi `Equal`.
    ///
    /// # Examples
    ///
    /// Prilaku dhasar:
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.reverse(), Ordering::Greater);
    /// assert_eq!(Ordering::Equal.reverse(), Ordering::Equal);
    /// assert_eq!(Ordering::Greater.reverse(), Ordering::Less);
    /// ```
    ///
    /// Cara iki bisa digunakake kanggo mbalikke perbandingan:
    ///
    /// ```
    /// let data: &mut [_] = &mut [2, 10, 5, 8];
    ///
    /// // ngurutake larik saka paling gedhe nganti paling cilik.
    /// data.sort_by(|a, b| a.cmp(b).reverse());
    ///
    /// let b: &mut [_] = &mut [10, 8, 5, 2];
    /// assert!(data == b);
    /// ```
    #[inline]
    #[must_use]
    #[rustc_const_stable(feature = "const_ordering", since = "1.48.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn reverse(self) -> Ordering {
        match self {
            Less => Greater,
            Equal => Equal,
            Greater => Less,
        }
    }

    /// Rantai loro pesenan.
    ///
    /// Ngasilake `self` nalika dudu `Equal`.Yen ora ngasilake `other`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = Ordering::Equal.then(Ordering::Less);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then(Ordering::Equal);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then(Ordering::Greater);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Equal.then(Ordering::Equal);
    /// assert_eq!(result, Ordering::Equal);
    ///
    /// let x: (i64, i64, i64) = (1, 2, 7);
    /// let y: (i64, i64, i64) = (1, 5, 3);
    /// let result = x.0.cmp(&y.0).then(x.1.cmp(&y.1)).then(x.2.cmp(&y.2));
    ///
    /// assert_eq!(result, Ordering::Less);
    /// ```
    #[inline]
    #[must_use]
    #[rustc_const_stable(feature = "const_ordering", since = "1.48.0")]
    #[stable(feature = "ordering_chaining", since = "1.17.0")]
    pub const fn then(self, other: Ordering) -> Ordering {
        match self {
            Equal => other,
            _ => self,
        }
    }

    /// Rentengan ing nindakake karo fungsi tartamtu.
    ///
    /// Ngasilake `self` nalika dudu `Equal`.
    /// Yen ora, nelpon `f` lan ngasilake asil.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = Ordering::Equal.then_with(|| Ordering::Less);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then_with(|| Ordering::Equal);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then_with(|| Ordering::Greater);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Equal.then_with(|| Ordering::Equal);
    /// assert_eq!(result, Ordering::Equal);
    ///
    /// let x: (i64, i64, i64) = (1, 2, 7);
    /// let y: (i64, i64, i64) = (1, 5, 3);
    /// let result = x.0.cmp(&y.0).then_with(|| x.1.cmp(&y.1)).then_with(|| x.2.cmp(&y.2));
    ///
    /// assert_eq!(result, Ordering::Less);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "ordering_chaining", since = "1.17.0")]
    pub fn then_with<F: FnOnce() -> Ordering>(self, f: F) -> Ordering {
        match self {
            Equal => f(),
            _ => self,
        }
    }
}

/// A struct helper kanggo nindakake mbalikke.
///
/// Struktur iki minangka helper kanggo digunakake kanthi fungsi kaya [`Vec::sort_by_key`] lan bisa digunakake kanggo mbalikke urutan bagean tombol.
///
///
/// [`Vec::sort_by_key`]: ../../std/vec/struct.Vec.html#method.sort_by_key
///
/// # Examples
///
/// ```
/// use std::cmp::Reverse;
///
/// let mut v = vec![1, 2, 3, 4, 5, 6];
/// v.sort_by_key(|&num| (num > 3, Reverse(num)));
/// assert_eq!(v, vec![3, 2, 1, 6, 5, 4]);
/// ```
#[derive(PartialEq, Eq, Debug, Copy, Clone, Default, Hash)]
#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
#[repr(transparent)]
pub struct Reverse<T>(#[stable(feature = "reverse_cmp_key", since = "1.19.0")] pub T);

#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
impl<T: PartialOrd> PartialOrd for Reverse<T> {
    #[inline]
    fn partial_cmp(&self, other: &Reverse<T>) -> Option<Ordering> {
        other.0.partial_cmp(&self.0)
    }

    #[inline]
    fn lt(&self, other: &Self) -> bool {
        other.0 < self.0
    }
    #[inline]
    fn le(&self, other: &Self) -> bool {
        other.0 <= self.0
    }
    #[inline]
    fn gt(&self, other: &Self) -> bool {
        other.0 > self.0
    }
    #[inline]
    fn ge(&self, other: &Self) -> bool {
        other.0 >= self.0
    }
}

#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
impl<T: Ord> Ord for Reverse<T> {
    #[inline]
    fn cmp(&self, other: &Reverse<T>) -> Ordering {
        other.0.cmp(&self.0)
    }
}

/// Trait kanggo jinis sing mbentuk [total order](https://en.wikipedia.org/wiki/Total_order).
///
/// Pesenan minangka urutan total yen (kanggo kabeh `a`, `b` lan `c`):
///
/// - total lan asimetris: persis siji saka `a < b`, `a == b` utawa `a > b` bener;lan
/// - transitif, `a < b` lan `b < c` tegese `a < c`.Sampeyan kudu padha nganggo `==` lan `>`.
///
/// ## Derivable
///
/// trait iki bisa digunakake nganggo `#[derive]`.
/// Nalika: derive`d ing structs, iku bakal gawé nindakake [lexicographic](https://en.wikipedia.org/wiki/Lexicographic_order) adhedhasar ndhuwur-kanggo-ngisor Pranyatan urutan anggota struct kang.
///
/// Nalika `turunan`d ing enum, Varian dipesen kanthi urutan diskriminasi ndhuwur-kanggo-ngisor.
///
/// ## Bandhingan leksikografi
///
/// Perbandingan leksikografi minangka operasi karo sifat-sifat ing ngisor iki:
///  - Rong urutan dibandhingake kanthi unsur.
///  - Unsur sing ora cocog pisanan nemtokake urutan sing kurang utawa luwih gedhe tinimbang leksikografis liyane.
///  - Yen salah sawijining urutan awalan liyane, urutan sing luwih cekak luwih murah tinimbang leksikeografis.
///  - Yen rong urutan duwe unsur sing padha lan dawane padha, mula urutane padha karo leksikografis.
///  - Urutan kosong leksikografis kurang saka urutan non-kosong.
///  - Two urutan kosong sing lexicographically witjaksono.
///
/// ## Aku bisa ngleksanakake `Ord`?
///
/// `Ord` mbutuhake jinis kasebut uga [`PartialOrd`] lan [`Eq`] (sing mbutuhake [`PartialEq`]).
///
/// Banjur sampeyan kudu netepake implementasine kanggo [`cmp`].Sampeyan bisa nemokake iku migunani kanggo nggunakake [`cmp`] ing kothak jinis kang.
///
/// Nindakake saka [`PartialEq`], [`PartialOrd`], lan `Ord`*kudu* setuju karo saben liyane.
/// Yaiku, `a.cmp(b) == Ordering::Equal` yen lan mung yen `a == b` lan `Some(a.cmp(b)) == a.partial_cmp(b)` kanggo kabeh `a` lan `b`.
/// Iku gampang kanggo sengaja nggawe wong ora setuju dening deriving sawetara saka traits lan manual penerapan wong.
///
/// Mangkene conto sing pengin diurutake mung wong-wong mau, ora preduli karo `id` lan `name`:
///
/// ```
/// use std::cmp::Ordering;
///
/// #[derive(Eq)]
/// struct Person {
///     id: u32,
///     name: String,
///     height: u32,
/// }
///
/// impl Ord for Person {
///     fn cmp(&self, other: &Self) -> Ordering {
///         self.height.cmp(&other.height)
///     }
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         Some(self.cmp(other))
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// [`cmp`]: Ord::cmp
///
///
///
#[doc(alias = "<")]
#[doc(alias = ">")]
#[doc(alias = "<=")]
#[doc(alias = ">=")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Ord: Eq + PartialOrd<Self> {
    /// Cara iki ngasilake lan [`Ordering`] antarane `self` lan `other`.
    ///
    /// Miturut konvensi, `self.cmp(&other)` ngasilake pesenan sing cocog karo ekspresi `self <operator> other` yen bener.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(5.cmp(&10), Ordering::Less);
    /// assert_eq!(10.cmp(&5), Ordering::Greater);
    /// assert_eq!(5.cmp(&5), Ordering::Equal);
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn cmp(&self, other: &Self) -> Ordering;

    /// Bandingke lan ngasilake maksimum loro nilai.
    ///
    /// Ngasilake argumen nomer loro yen mbandhingake nemtokake padha.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(2, 1.max(2));
    /// assert_eq!(2, 2.max(2));
    /// ```
    #[stable(feature = "ord_max_min", since = "1.21.0")]
    #[inline]
    #[must_use]
    fn max(self, other: Self) -> Self
    where
        Self: Sized,
    {
        max_by(self, other, Ord::cmp)
    }

    /// Mbandhingake lan ngasilake minimal rong nilai.
    ///
    /// Ngasilake pitakonan pisanan yen comparison nemtokake mau dadi padha.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(1, 1.min(2));
    /// assert_eq!(2, 2.min(2));
    /// ```
    #[stable(feature = "ord_max_min", since = "1.21.0")]
    #[inline]
    #[must_use]
    fn min(self, other: Self) -> Self
    where
        Self: Sized,
    {
        min_by(self, other, Ord::cmp)
    }

    /// Matesi nilai menyang interval tartamtu.
    ///
    /// Ngasilake `max` yen `self` luwih gedhe tinimbang `max`, lan `min` yen `self` kurang saka `min`.
    /// Yen ora, iki ngasilake `self`.
    ///
    /// # Panics
    ///
    /// Panics yen `min > max`.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!((-3).clamp(-2, 1) == -2);
    /// assert!(0.clamp(-2, 1) == 0);
    /// assert!(2.clamp(-2, 1) == 1);
    /// ```
    #[must_use]
    #[stable(feature = "clamp", since = "1.50.0")]
    fn clamp(self, min: Self, max: Self) -> Self
    where
        Self: Sized,
    {
        assert!(min <= max);
        if self < min {
            min
        } else if self > max {
            max
        } else {
            self
        }
    }
}

/// Nurunake makro sing ngasilake impl trait `Ord`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics)]
pub macro Ord($item:item) {
    /* compiler built-in */
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Eq for Ordering {}

#[stable(feature = "rust1", since = "1.0.0")]
impl Ord for Ordering {
    #[inline]
    fn cmp(&self, other: &Ordering) -> Ordering {
        (*self as i32).cmp(&(*other as i32))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialOrd for Ordering {
    #[inline]
    fn partial_cmp(&self, other: &Ordering) -> Option<Ordering> {
        (*self as i32).partial_cmp(&(*other as i32))
    }
}

/// Trait kanggo nilai sing bisa dibandhingake karo urutan-urutan.
///
/// Perbandingan kasebut kudu memuaskan, kanggo kabeh `a`, `b` lan `c`:
///
/// - asimetri: yen `a < b` banjur `!(a > b)`, uga `a > b` nuduhake `!(a < b)`;lan
/// - transitivity: `a < b` lan `b < c` tegese `a < c`.Kudu ditahan padha kanggo loro `==` lan `>`.
///
/// Wigati sing syarat tegese sing trait dhewe kudu dipun ginakaken symmetrically lan transitively: yen `T: PartialOrd<U>` lan `U: PartialOrd<V>` banjur `U: PartialOrd<T>` lan: T:
///
/// PartialOrd<V>`.
///
/// ## Derivable
///
/// trait iki bisa digunakake nganggo `#[derive]`.Nalika: derive`d ing structs, iku bakal gawé nindakake lexicographic adhedhasar ndhuwur-kanggo-ngisor Pranyatan urutan anggota struct kang.
/// Nalika `turunan`d ing enum, Varian dipesen kanthi urutan diskriminasi ndhuwur-kanggo-ngisor.
///
/// ## Kepiye cara ngetrapake `PartialOrd`?
///
/// `PartialOrd` mung mbutuhake implementasi metode [`partial_cmp`], lan liyane digawe saka implementasi standar.
///
/// Nanging isih bisa ngetrapake liyane kanthi kapisah kanggo jinis sing ora duwe urutan total.
/// Contone, kanggo nomer ngambang titik, `NaN < 0 == false` lan `NaN >= 0 == false` (cf.
/// IEEE 754-2008 bagean 5.11).
///
/// `PartialOrd` mbutuhake Tipe dadi [`PartialEq`].
///
/// Nindakake saka [`PartialEq`], `PartialOrd`, lan [`Ord`]*kudu* setuju karo saben liyane.
/// Iku gampang kanggo sengaja nggawe wong ora setuju dening deriving sawetara saka traits lan manual penerapan wong.
///
/// Yen jinis punika [`Ord`], sampeyan bisa ngleksanakake [`partial_cmp`] kanthi nggunakake [`cmp`]:
///
/// ```
/// use std::cmp::Ordering;
///
/// #[derive(Eq)]
/// struct Person {
///     id: u32,
///     name: String,
///     height: u32,
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         Some(self.cmp(other))
///     }
/// }
///
/// impl Ord for Person {
///     fn cmp(&self, other: &Self) -> Ordering {
///         self.height.cmp(&other.height)
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// Sampeyan uga bisa migunani yen nggunakake [`partial_cmp`] ing kolom jinis sampeyan.
/// Punika conto jinis `Person` sing duwe ngambang-titik lapangan `height` sing mung lapangan kanggo digunakake ngurutake:
///
/// ```
/// use std::cmp::Ordering;
///
/// struct Person {
///     id: u32,
///     name: String,
///     height: f64,
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         self.height.partial_cmp(&other.height)
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// # Examples
///
/// ```
/// let x : u32 = 0;
/// let y : u32 = 1;
///
/// assert_eq!(x < y, true);
/// assert_eq!(x.lt(&y), true);
/// ```
///
/// [`partial_cmp`]: PartialOrd::partial_cmp
/// [`cmp`]: Ord::cmp
///
///
///
///
#[lang = "partial_ord"]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = ">")]
#[doc(alias = "<")]
#[doc(alias = "<=")]
#[doc(alias = ">=")]
#[rustc_on_unimplemented(
    message = "can't compare `{Self}` with `{Rhs}`",
    label = "no implementation for `{Self} < {Rhs}` and `{Self} > {Rhs}`"
)]
pub trait PartialOrd<Rhs: ?Sized = Self>: PartialEq<Rhs> {
    /// Cara iki ngasilake lan nindakake antarane nilai-nilai `self` lan `other` yen siji ana.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = 1.0.partial_cmp(&2.0);
    /// assert_eq!(result, Some(Ordering::Less));
    ///
    /// let result = 1.0.partial_cmp(&1.0);
    /// assert_eq!(result, Some(Ordering::Equal));
    ///
    /// let result = 2.0.partial_cmp(&1.0);
    /// assert_eq!(result, Some(Ordering::Greater));
    /// ```
    ///
    /// Yen ora bisa dibandhingake:
    ///
    /// ```
    /// let result = f64::NAN.partial_cmp(&1.0);
    /// assert_eq!(result, None);
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn partial_cmp(&self, other: &Rhs) -> Option<Ordering>;

    /// Cara iki tes kurang saka (kanggo `self` lan `other`) lan digunakake dening operator `<`.
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 < 2.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 < 1.0;
    /// assert_eq!(result, false);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn lt(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Less))
    }

    /// Cara iki tes kurang saka utawa padha (kanggo `self` lan `other`) lan digunakake dening operator `<=`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 <= 2.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 <= 2.0;
    /// assert_eq!(result, true);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn le(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Less | Equal))
    }

    /// Metode iki tes luwih gedhe tinimbang (kanggo `self` lan `other`) lan digunakake dening operator `>`.
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 > 2.0;
    /// assert_eq!(result, false);
    ///
    /// let result = 2.0 > 2.0;
    /// assert_eq!(result, false);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn gt(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Greater))
    }

    /// Cara iki tes luwih saka utawa witjaksono kanggo (kanggo `self` lan `other`) lan digunakake dening operator `>=`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 2.0 >= 1.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 >= 2.0;
    /// assert_eq!(result, true);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn ge(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Greater | Equal))
    }
}

/// Nurunake makro sing ngasilake impl trait `PartialOrd`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics)]
pub macro PartialOrd($item:item) {
    /* compiler built-in */
}

/// Mbandhingake lan ngasilake minimal rong nilai.
///
/// Ngasilake pitakonan pisanan yen comparison nemtokake mau dadi padha.
///
/// Sacara internal migunakake alias kanggo [`Ord::min`].
///
/// # Examples
///
/// ```
/// use std::cmp;
///
/// assert_eq!(1, cmp::min(1, 2));
/// assert_eq!(2, cmp::min(2, 2));
/// ```
#[inline]
#[must_use]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn min<T: Ord>(v1: T, v2: T) -> T {
    v1.min(v2)
}

/// Ngasilake minimal rong nilai babagan fungsi perbandingan sing ditemtokake.
///
/// Ngasilake pitakonan pisanan yen comparison nemtokake mau dadi padha.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::min_by(-2, 1, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), 1);
/// assert_eq!(cmp::min_by(-2, 2, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), -2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn min_by<T, F: FnOnce(&T, &T) -> Ordering>(v1: T, v2: T, compare: F) -> T {
    match compare(&v1, &v2) {
        Ordering::Less | Ordering::Equal => v1,
        Ordering::Greater => v2,
    }
}

/// Ngasilake elemen sing menehi nilai minimal saka fungsi sing ditemtokake.
///
/// Ngasilake pitakonan pisanan yen comparison nemtokake mau dadi padha.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::min_by_key(-2, 1, |x: &i32| x.abs()), 1);
/// assert_eq!(cmp::min_by_key(-2, 2, |x: &i32| x.abs()), -2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn min_by_key<T, F: FnMut(&T) -> K, K: Ord>(v1: T, v2: T, mut f: F) -> T {
    min_by(v1, v2, |v1, v2| f(v1).cmp(&f(v2)))
}

/// Bandingke lan ngasilake maksimum loro nilai.
///
/// Ngasilake argumen nomer loro yen mbandhingake nemtokake padha.
///
/// Sacara internal migunakake alias kanggo [`Ord::max`].
///
/// # Examples
///
/// ```
/// use std::cmp;
///
/// assert_eq!(2, cmp::max(1, 2));
/// assert_eq!(2, cmp::max(2, 2));
/// ```
#[inline]
#[must_use]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn max<T: Ord>(v1: T, v2: T) -> T {
    v1.max(v2)
}

/// Ngasilake maksimal rong nilai babagan fungsi perbandingan sing ditemtokake.
///
/// Ngasilake argumen nomer loro yen mbandhingake nemtokake padha.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::max_by(-2, 1, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), -2);
/// assert_eq!(cmp::max_by(-2, 2, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), 2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn max_by<T, F: FnOnce(&T, &T) -> Ordering>(v1: T, v2: T, compare: F) -> T {
    match compare(&v1, &v2) {
        Ordering::Less | Ordering::Equal => v2,
        Ordering::Greater => v1,
    }
}

/// Ngasilake unsur sing menehi nilai maksimum saka fungsi kasebut.
///
/// Ngasilake argumen nomer loro yen mbandhingake nemtokake padha.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::max_by_key(-2, 1, |x: &i32| x.abs()), -2);
/// assert_eq!(cmp::max_by_key(-2, 2, |x: &i32| x.abs()), 2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn max_by_key<T, F: FnMut(&T) -> K, K: Ord>(v1: T, v2: T, mut f: F) -> T {
    max_by(v1, v2, |v1, v2| f(v1).cmp(&f(v2)))
}

// Implementasi PartialEq, podo, PartialOrd lan Ord kanggo jinis primitif
mod impls {
    use crate::cmp::Ordering::{self, Equal, Greater, Less};
    use crate::hint::unreachable_unchecked;

    macro_rules! partial_eq_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialEq for $t {
                #[inline]
                fn eq(&self, other: &$t) -> bool { (*self) == (*other) }
                #[inline]
                fn ne(&self, other: &$t) -> bool { (*self) != (*other) }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialEq for () {
        #[inline]
        fn eq(&self, _other: &()) -> bool {
            true
        }
        #[inline]
        fn ne(&self, _other: &()) -> bool {
            false
        }
    }

    partial_eq_impl! {
        bool char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 f32 f64
    }

    macro_rules! eq_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl Eq for $t {}
        )*)
    }

    eq_impl! { () bool char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 }

    macro_rules! partial_ord_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialOrd for $t {
                #[inline]
                fn partial_cmp(&self, other: &$t) -> Option<Ordering> {
                    match (self <= other, self >= other) {
                        (false, false) => None,
                        (false, true) => Some(Greater),
                        (true, false) => Some(Less),
                        (true, true) => Some(Equal),
                    }
                }
                #[inline]
                fn lt(&self, other: &$t) -> bool { (*self) < (*other) }
                #[inline]
                fn le(&self, other: &$t) -> bool { (*self) <= (*other) }
                #[inline]
                fn ge(&self, other: &$t) -> bool { (*self) >= (*other) }
                #[inline]
                fn gt(&self, other: &$t) -> bool { (*self) > (*other) }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialOrd for () {
        #[inline]
        fn partial_cmp(&self, _: &()) -> Option<Ordering> {
            Some(Equal)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialOrd for bool {
        #[inline]
        fn partial_cmp(&self, other: &bool) -> Option<Ordering> {
            Some(self.cmp(other))
        }
    }

    partial_ord_impl! { f32 f64 }

    macro_rules! ord_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialOrd for $t {
                #[inline]
                fn partial_cmp(&self, other: &$t) -> Option<Ordering> {
                    Some(self.cmp(other))
                }
                #[inline]
                fn lt(&self, other: &$t) -> bool { (*self) < (*other) }
                #[inline]
                fn le(&self, other: &$t) -> bool { (*self) <= (*other) }
                #[inline]
                fn ge(&self, other: &$t) -> bool { (*self) >= (*other) }
                #[inline]
                fn gt(&self, other: &$t) -> bool { (*self) > (*other) }
            }

            #[stable(feature = "rust1", since = "1.0.0")]
            impl Ord for $t {
                #[inline]
                fn cmp(&self, other: &$t) -> Ordering {
                    // Pesenan ing kene penting kanggo ngasilake perakitan sing luwih optimal.
                    // Waca <https://github.com/rust-lang/rust/issues/63758> kanggo info liyane.
                    if *self < *other { Less }
                    else if *self == *other { Equal }
                    else { Greater }
                }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl Ord for () {
        #[inline]
        fn cmp(&self, _other: &()) -> Ordering {
            Equal
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl Ord for bool {
        #[inline]
        fn cmp(&self, other: &bool) -> Ordering {
            // Casting menyang i8 lan ngowahi prabédan dadi Pesenan ngasilake majelis sing luwih optimal.
            //
            // Waca <https://github.com/rust-lang/rust/issues/66780> kanggo info liyane.
            match (*self as i8) - (*other as i8) {
                -1 => Less,
                0 => Equal,
                1 => Greater,
                // SAFETY: bool minangka i8 ngasilake 0 utawa 1, supaya prabédan ora bisa apa-apa liya
                _ => unsafe { unreachable_unchecked() },
            }
        }
    }

    ord_impl! { char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 }

    #[unstable(feature = "never_type", issue = "35121")]
    impl PartialEq for ! {
        fn eq(&self, _: &!) -> bool {
            *self
        }
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Eq for ! {}

    #[unstable(feature = "never_type", issue = "35121")]
    impl PartialOrd for ! {
        fn partial_cmp(&self, _: &!) -> Option<Ordering> {
            *self
        }
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Ord for ! {
        fn cmp(&self, _: &!) -> Ordering {
            *self
        }
    }

    // &pitunjuk

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&B> for &A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialOrd<&B> for &A
    where
        A: PartialOrd<B>,
    {
        #[inline]
        fn partial_cmp(&self, other: &&B) -> Option<Ordering> {
            PartialOrd::partial_cmp(*self, *other)
        }
        #[inline]
        fn lt(&self, other: &&B) -> bool {
            PartialOrd::lt(*self, *other)
        }
        #[inline]
        fn le(&self, other: &&B) -> bool {
            PartialOrd::le(*self, *other)
        }
        #[inline]
        fn gt(&self, other: &&B) -> bool {
            PartialOrd::gt(*self, *other)
        }
        #[inline]
        fn ge(&self, other: &&B) -> bool {
            PartialOrd::ge(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Ord for &A
    where
        A: Ord,
    {
        #[inline]
        fn cmp(&self, other: &Self) -> Ordering {
            Ord::cmp(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Eq for &A where A: Eq {}

    // &mut pointers

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&mut B> for &mut A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&mut B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&mut B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialOrd<&mut B> for &mut A
    where
        A: PartialOrd<B>,
    {
        #[inline]
        fn partial_cmp(&self, other: &&mut B) -> Option<Ordering> {
            PartialOrd::partial_cmp(*self, *other)
        }
        #[inline]
        fn lt(&self, other: &&mut B) -> bool {
            PartialOrd::lt(*self, *other)
        }
        #[inline]
        fn le(&self, other: &&mut B) -> bool {
            PartialOrd::le(*self, *other)
        }
        #[inline]
        fn gt(&self, other: &&mut B) -> bool {
            PartialOrd::gt(*self, *other)
        }
        #[inline]
        fn ge(&self, other: &&mut B) -> bool {
            PartialOrd::ge(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Ord for &mut A
    where
        A: Ord,
    {
        #[inline]
        fn cmp(&self, other: &Self) -> Ordering {
            Ord::cmp(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Eq for &mut A where A: Eq {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&mut B> for &A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&mut B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&mut B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&B> for &mut A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
}