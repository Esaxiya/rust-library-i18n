#![allow(missing_docs)]
#![unstable(feature = "raw", issue = "27751")]

//! Ngemot definisi struktural kanggo tata letak kompilator jinis internal.
//!
//! Iki bisa digunakake minangka target pemancar ing kode sing ora aman kanggo manipulasi perwakilan mentah kanthi langsung.
//!
//!
//! definisi kudu tansah cocog ABI ditetepake ing `rustc_middle::ty::layout`.
//!

/// Perwakilan obyek trait kaya `&dyn SomeTrait`.
///
/// Struktur iki duwe tata letak sing padha karo jinis kayata `&dyn SomeTrait` lan `Box<dyn AnotherTrait>`.
///
/// `TraitObject` dijamin cocog noto, nanging ora jinis obyek trait (eg, kothak sing ora langsung diakses ing `&dyn SomeTrait`) utawa ora iku ngontrol tata sing (ganti definisi ora ngganti tata letak saka `&dyn SomeTrait`).
///
/// Iki mung dirancang kanggo digunakake kanthi kode sing ora aman sing kudu ngapusi rincian level sedheng.
///
/// Ora ana cara kanggo ngrujuk kabeh obyek trait umume, dadi cara mung kanggo nggawe nilai saka jinis iki yaiku karo fungsi kaya [`std::mem::transmute`][transmute].
/// Kajaba iku, cara mung kanggo nggawe obyek trait sejati saka nilai `TraitObject` yaiku karo `transmute`.
///
/// [transmute]: crate::intrinsics::transmute
///
/// Synthesizing barang trait karo mismatched jinis-ngendi vtable ora cocog kanggo jinis Nilai kanggo kang data pitunjuk TCTerms-Highly kamungkinan kanggo mimpin kanggo prilaku cetho.
///
/// # Examples
///
/// ```
/// #![feature(raw)]
///
/// use std::{mem, raw};
///
/// // conto trait
/// trait Foo {
///     fn bar(&self) -> i32;
/// }
///
/// impl Foo for i32 {
///     fn bar(&self) -> i32 {
///          *self + 1
///     }
/// }
///
/// let value: i32 = 123;
///
/// // supaya kompiler nggawe obyek trait
/// let object: &dyn Foo = &value;
///
/// // deleng perwakilan mentah
/// let raw_object: raw::TraitObject = unsafe { mem::transmute(object) };
///
/// // pitunjuk data alamat `value`
/// assert_eq!(raw_object.data as *const i32, &value as *const _);
///
/// let other_value: i32 = 456;
///
/// // bangun obyek anyar, nuduhake `i32` sing beda, ati-ati nggunakake `i32` vtable saka `object`
/////
/// let synthesized: &dyn Foo = unsafe {
///      mem::transmute(raw::TraitObject {
///          data: &other_value as *const _ as *mut (),
///          vtable: raw_object.vtable,
///      })
/// };
///
/// // iku kudu bisa kaya yen kita wis dibangun barang trait saking `other_value` langsung
/////
/// assert_eq!(synthesized.bar(), 457);
/// ```
///
///
///
///
///
///
///
///
///
#[repr(C)]
#[derive(Copy, Clone)]
#[allow(missing_debug_implementations)]
pub struct TraitObject {
    pub data: *mut (),
    pub vtable: *mut (),
}