//! `Clone` trait kanggo jinis sing ora bisa 'disalin kanthi implisit'.
//!
//! Ing Rust, sawetara jinis prasaja "implicitly copyable" lan nalika nemtokake utawa pass minangka bantahan, panrima bakal salinan, nilaraken Nilai asli ing panggonan.
//! Jinis-jinis ora mbutuhake persediaan kanggo nyalin lan ora duwe finalizers (IE, padha ora ngemot kothak diduweni utawa ngleksanakake [`Drop`]), supaya compiler nganggep wong murah lan aman kanggo nyalin.
//!
//! Kanggo jinis liyane, salinan kudu digawe kanthi eksplisit, kanthi konvensi sing ngetrapake [`Clone`] trait lan nelpon cara [`clone`].
//!
//! [`clone`]: Clone::clone
//!
//! Panggunan dhasar conto:
//!
//! ```
//! let s = String::new(); // Jinis senar ngetrapake Klone
//! let copy = s.clone(); // supaya kita bisa tiron iku
//! ```
//!
//! Kanggo nggunakake Klone trait kanthi gampang, sampeyan uga bisa nggunakake `#[derive(Clone)]`.Tuladha:
//!
//! ```
//! #[derive(Clone)] // kita nambah Klone trait kanggo Morpheus struct
//! struct Morpheus {
//!    blue_pill: f32,
//!    red_pill: i64,
//! }
//!
//! fn main() {
//!    let f = Morpheus { blue_pill: 0.0, red_pill: 0 };
//!    let copy = f.clone(); // lan saiki kita bisa Klone!
//! }
//! ```
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

/// trait umum kanggo katrampilan kanthi duplikat obyek kanthi eksplisit.
///
/// Beda karo [`Copy`] ing [`Copy`] implisit lan larang banget, dene `Clone` mesthi eksplisit lan bisa uga larang.
/// Supaya nglakokake iki ciri, Rust ora ngijini sampeyan kanggo reimplement [`Copy`], nanging sampeyan bisa uga reimplement `Clone` lan mbukak kode kasepakatan.
///
/// Amarga `Clone` luwih umum tinimbang [`Copy`], sampeyan kanthi otomatis bisa nggawe [`Copy`] dadi `Clone` uga.
///
/// ## Derivable
///
/// trait iki bisa digunakake karo `#[derive]` yen kabeh kolom `Clone`.Ing: implementasine derive`d saka [`Clone`] Telpon [`clone`] ing saben lapangan.
///
/// [`clone`]: Clone::clone
///
/// Kanggo struktur umum, `#[derive]` ngleksanakake `Clone` kanthi kondisional kanthi nambah `Clone` sing kaiket ing paramèter umum.
///
/// ```
/// // `derive` nindakake Klone kanggo Reading<T>nalika T Klone.
/// #[derive(Clone)]
/// struct Reading<T> {
///     frequency: T,
/// }
/// ```
///
/// ## Aku bisa ngleksanakake `Clone`?
///
/// Jinis sing [`Copy`] kudu implementasine ora pati penting saka `Clone`.More resmi:
/// yen `T: Copy`, `x: T`, lan `y: &T`, mula `let x = y.clone();` padha karo `let x = *y;`.
/// Implementasi manual kudu ati-ati kanggo njaga invariant iki;Nanging, kode aman ora kudu gumantung ing kanggo njamin safety memori.
///
/// Contone yaiku struktur umum sing nyekel fungsi pitunjuk.Ing kasus iki, implementasi `Clone` ora bisa `diturunake ', nanging bisa diimplementasikake minangka:
///
/// ```
/// struct Generate<T>(fn() -> T);
///
/// impl<T> Copy for Generate<T> {}
///
/// impl<T> Clone for Generate<T> {
///     fn clone(&self) -> Self {
///         *self
///     }
/// }
/// ```
///
/// ## Pelaksana tambahan
///
/// Saliyane [implementors listed below][impls], jinis-jinis ing ngisor iki uga ngetrapake `Clone`:
///
/// * Jinis item fungsi (yaiku, macem-macem jinis sing ditemtokake kanggo saben fungsi)
/// * Fungsi jinis pitunjuk (kayata, `fn() -> i32`)
/// * jinis Array, kanggo kabeh ukuran, manawa jinis item uga nindakake `Clone` (eg, `[i32; 123456]`)
/// * Jinis Tuple, yen saben komponen uga nggunakake `Clone` (contone, `()`, `(i32, bool)`)
/// * Jinis penutupan, yen ora entuk regane saka lingkungan utawa yen kabeh nilai sing dijupuk kalebu `Clone` dhewe.
///   Elinga yen variabel sing dijupuk nganggo referensi bareng mesthi ngetrapake `Clone` (sanajan referensi ora), dene variabel sing dijupuk nganggo referensi sing bisa diowahi ora nate ngetrapake `Clone`.
///
///
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "clone"]
#[rustc_diagnostic_item = "Clone"]
pub trait Clone: Sized {
    /// Ngasilake salinan Nilai.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(noop_method_call)]
    /// let hello = "Hello"; // &str ngleksanakake Klone
    ///
    /// assert_eq!("Hello", hello.clone());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "cloning is often expensive and is not expected to have side effects"]
    fn clone(&self) -> Self;

    /// Nindakake tugas salinan saka `source`.
    ///
    /// `a.clone_from(&b)` padha karo `a = b.clone()` ing fungsi, nanging bisa ditindhih nganggo maneh sumber `a` supaya allocations rasah.
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn clone_from(&mut self, source: &Self) {
        *self = source.clone()
    }
}

/// Nurunake makro sing ngasilake impl trait `Clone`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Clone($item:item) {
    /* compiler built-in */
}

// FIXME(aburka): strukture iki digunakake mung dening#[turunan] kanggo negesake manawa kabeh komponen jinis nindakake Klone utawa Salin.
//
//
// Strukture kasebut ora kena ditampilake ing kode pangguna.
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsClone<T: Clone + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsCopy<T: Copy + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// Nindakake saka `Clone` kanggo jinis primitif.
///
/// Nindakake sing ora bisa diterangake ing Rust sing dipun ginakaken ing `traits::SelectionContext::copy_clone_conditions()` ing `rustc_trait_selection`.
///
///
mod impls {

    use super::Clone;

    macro_rules! impl_clone {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Clone for $t {
                    #[inline]
                    fn clone(&self) -> Self {
                        *self
                    }
                }
            )*
        }
    }

    impl_clone! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Clone for ! {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *const T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *mut T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// Referensi bareng bisa dikloning, nanging referensi sing bisa diowahi *ora bisa*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for &T {
        #[inline]
        #[rustc_diagnostic_item = "noop_method_clone"]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// Referensi bareng bisa dikloning, nanging referensi sing bisa diowahi *ora bisa*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> !Clone for &mut T {}
}