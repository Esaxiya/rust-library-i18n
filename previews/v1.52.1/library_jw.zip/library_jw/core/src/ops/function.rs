/// Versi operator telpon sing njupuk panrima sing ora bisa diowahi.
///
/// Kadhangkala `Fn` bisa diarani bola-bali tanpa mutasi negara.
///
/// *trait (`Fn`) iki ora bakal bingung karo [function pointers] (`fn`).*
///
/// `Fn` dileksanakake kanthi otomatis kanthi penutupan sing mung njupuk referensi sing ora bisa diowahi kanggo variabel sing dijupuk utawa ora nangkep apa-apa, uga (safe) [function pointers] (kanthi sawetara peringatan, deleng dokumentasi kanggo rincian liyane).
///
/// Kajaba iku, kanggo jinis `F` sing ngetrapake `Fn`, `&F` uga nggunakake `Fn`.
///
/// Amarga [`FnMut`] lan [`FnOnce`] minangka supertraits `Fn`, kedadeyan `Fn` bisa digunakake minangka parameter sing diarepake [`FnMut`] utawa [`FnOnce`].
///
/// Gunakake `Fn` minangka wates nalika sampeyan pengin nampa paramèter saka jinis fungsi lan kudu nelpon bola-bali lan tanpa mutasi negara (umpamane, nalika diarani bebarengan).
/// Yen sampeyan ora butuh syarat sing ketat, gunakake [`FnMut`] utawa [`FnOnce`] minangka wates.
///
/// Deleng [chapter on closures in *The Rust Programming Language*][book] kanggo informasi lengkap babagan topik iki.
///
/// Uga wigati yaiku sintaks khusus kanggo `Fn` traits (kayata
/// `Fn(usize, bool) -> usize`).Sing seneng rincian teknis babagan iki bisa waca [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Nelpon nutup
///
/// ```
/// let square = |x| x * x;
/// assert_eq!(square(5), 25);
/// ```
///
/// ## Nggunakake parameter `Fn`
///
/// ```
/// fn call_with_one<F>(func: F) -> usize
///     where F: Fn(usize) -> usize {
///     func(1)
/// }
///
/// let double = |x| x * 2;
/// assert_eq!(call_with_one(double), 2);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{Fn}<{Args}>` closure, found `{Self}`",
    label = "expected an `Fn<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // supaya regex bisa ngandelake `&str: !FnMut` kasebut
#[must_use = "closures are lazy and do nothing unless called"]
pub trait Fn<Args>: FnMut<Args> {
    /// Nindakake operasi telpon.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call(&self, args: Args) -> Self::Output;
}

/// Versi operator telpon sing njupuk panampa sing bisa diowahi.
///
/// Instalasi `FnMut` bisa diarani bola-bali lan bisa mutasi negara.
///
/// `FnMut` dileksanakake kanthi otomatis kanthi penutupan sing njupuk referensi sing bisa diowahi kanggo variabel sing dijupuk, uga kabeh jinis sing ngetrapake [`Fn`], kayata, (safe) [function pointers] (amarga `FnMut` minangka supertrait of [`Fn`]).
/// Kajaba iku, kanggo jinis `F` sing ngetrapake `FnMut`, `&mut F` uga nggunakake `FnMut`.
///
/// Amarga [`FnOnce`] minangka supertrait of `FnMut`, sembarang conto `FnMut` bisa digunakake ing [`FnOnce`], lan amarga [`Fn`] minangka subtrait `FnMut`, [`Fn`] bakal digunakake ing endi sing diarepake `FnMut`.
///
/// Gunakake `FnMut` minangka wates nalika sampeyan pengin nampa paramèter saka jinis fungsi lan kudu nelpon bola-bali, nalika ngidini mutasi negara.
/// Yen sampeyan ora pengin parameter kasebut mutasi, gunakake [`Fn`] minangka wates;yen ora prelu diarani bola-bali, gunakake [`FnOnce`].
///
/// Deleng [chapter on closures in *The Rust Programming Language*][book] kanggo informasi lengkap babagan topik iki.
///
/// Uga wigati yaiku sintaks khusus kanggo `Fn` traits (kayata
/// `Fn(usize, bool) -> usize`).Sing seneng rincian teknis babagan iki bisa waca [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Nelpon nutup sing bisa dijupuk
///
/// ```
/// let mut x = 5;
/// {
///     let mut square_x = || x *= x;
///     square_x();
/// }
/// assert_eq!(x, 25);
/// ```
///
/// ## Nggunakake parameter `FnMut`
///
/// ```
/// fn do_twice<F>(mut func: F)
///     where F: FnMut()
/// {
///     func();
///     func();
/// }
///
/// let mut x: usize = 1;
/// {
///     let add_two_to_x = || x += 2;
///     do_twice(add_two_to_x);
/// }
///
/// assert_eq!(x, 5);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn_mut"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnMut}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnMut<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // supaya regex bisa ngandelake `&str: !FnMut` kasebut
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnMut<Args>: FnOnce<Args> {
    /// Nindakake operasi telpon.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_mut(&mut self, args: Args) -> Self::Output;
}

/// Versi operator telpon sing njupuk panampa nilai.
///
/// Kadhangkala `FnOnce` bisa ditelpon, nanging bisa uga ora bisa ditelpon kaping pirang-pirang.Amarga iki, yen siji-sijine sing ngerti babagan jinis yaiku ngetrapake `FnOnce`, mung bisa diarani sepisan.
///
/// `FnOnce` ditrapake kanthi otomatis kanthi penutupan sing bisa nggunakake variabel sing dijupuk, uga kabeh jinis sing ngetrapake [`FnMut`], kayata, (safe) [function pointers] (amarga `FnOnce` minangka supertrait of [`FnMut`]).
///
///
/// Amarga kalorone [`Fn`] lan [`FnMut`] minangka subtrait `FnOnce`, kedadeyan [`Fn`] utawa [`FnMut`] bisa digunakake ing endi `FnOnce` diarepake.
///
/// Gunakake `FnOnce` minangka wates nalika sampeyan pengin nampa paramèter saka jinis fungsi lan mung kudu nelpon sapisan.
/// Yen sampeyan kudu nelpon parameter kanthi bola-bali, gunakake [`FnMut`] minangka wates;yen sampeyan uga ora mbutuhake mutasi, gunakake [`Fn`].
///
/// Deleng [chapter on closures in *The Rust Programming Language*][book] kanggo informasi lengkap babagan topik iki.
///
/// Uga wigati yaiku sintaks khusus kanggo `Fn` traits (kayata
/// `Fn(usize, bool) -> usize`).Sing seneng rincian teknis babagan iki bisa waca [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Nggunakake parameter `FnOnce`
///
/// ```
/// fn consume_with_relish<F>(func: F)
///     where F: FnOnce() -> String
/// {
///     // `func` nganggo variabel sing dijupuk, mula ora bisa mbukak luwih saka sepisan.
/////
///     println!("Consumed: {}", func());
///
///     println!("Delicious!");
///
///     // Nyoba njaluk `func()` maneh bakal mbuwang kesalahan `use of moved value` kanggo `func`.
/////
/// }
///
/// let x = String::from("x");
/// let consume_and_return_x = move || x;
/// consume_with_relish(consume_and_return_x);
///
/// // `consume_and_return_x` ora bisa digunakake maneh ing wektu iki
/// ```
///
///
///
///
///
///
///
///
#[lang = "fn_once"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnOnce}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnOnce<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // supaya regex bisa ngandelake `&str: !FnMut` kasebut
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnOnce<Args> {
    /// Jinis bali sawise operator telpon digunakake.
    #[lang = "fn_once_output"]
    #[stable(feature = "fn_once_output", since = "1.12.0")]
    type Output;

    /// Nindakake operasi telpon.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_once(self, args: Args) -> Self::Output;
}

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> Fn<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call(&self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &F
    where
        F: Fn<A>,
    {
        type Output = F::Output;

        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &mut F
    where
        F: FnMut<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &mut F
    where
        F: FnMut<A>,
    {
        type Output = F::Output;
        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }
}