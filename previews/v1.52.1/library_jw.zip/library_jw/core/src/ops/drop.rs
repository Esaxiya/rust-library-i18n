/// Kode khusus ing destruktor.
///
/// Yen regane ora dibutuhake maneh, Rust bakal mbukak "destructor" ing nilai kasebut.
/// Cara sing paling umum sing regane wis ora dibutuhake maneh yaiku nalika metu saka ruang lingkup.Destructor isih bisa mlaku ing kahanan liyane, nanging kita bakal fokus ing lingkup conto ing kene.
/// Kanggo sinau babagan sawetara kasus liyane, waca bagean [the reference] ing destruktor.
///
/// [the reference]: https://doc.rust-lang.org/reference/destructors.html
///
/// Penghancur iki kalebu rong komponen:
/// - Telpon menyang `Drop::drop` kanggo rega kasebut, yen `Drop` trait khusus iki dileksanakake kanggo jinis kasebut.
/// - "drop glue" sing digawe kanthi otomatis kanthi rekursif nyebutake destruktor kabeh kolom nilai kasebut.
///
/// Amarga Rust kanthi otomatis nyebut para destruktor kabeh kolom sing ana, sampeyan ora kudu ngetrapake `Drop` ing pirang-pirang kasus.
/// Nanging ana sawetara kasus sing migunani, kayata kanggo jinis sing ngatur sumber kanthi langsung.
/// Sumber kasebut bisa uga memori, bisa uga dadi deskriptor file, bisa uga soket jaringan.
/// Sawise regane jinis kasebut ora digunakake maneh, mesthine kudu "clean up" sumber kanthi mbebasake memori utawa nutup file utawa soket.
/// Iki minangka tugas kanggo ngrusak, lan mula pakaryan `Drop::drop`.
///
/// ## Examples
///
/// Kanggo ndeleng destruktor sing tumindak, ayo goleki program ing ngisor iki:
///
/// ```rust
/// struct HasDrop;
///
/// impl Drop for HasDrop {
///     fn drop(&mut self) {
///         println!("Dropping HasDrop!");
///     }
/// }
///
/// struct HasTwoDrops {
///     one: HasDrop,
///     two: HasDrop,
/// }
///
/// impl Drop for HasTwoDrops {
///     fn drop(&mut self) {
///         println!("Dropping HasTwoDrops!");
///     }
/// }
///
/// fn main() {
///     let _x = HasTwoDrops { one: HasDrop, two: HasDrop };
///     println!("Running!");
/// }
/// ```
///
/// Rust pisanan bakal nyebut `Drop::drop` kanggo `_x` lan banjur kanggo `_x.one` lan `_x.two`, tegese yen mbukak iki bakal dicithak
///
/// ```text
/// Running!
/// Dropping HasTwoDrops!
/// Dropping HasDrop!
/// Dropping HasDrop!
/// ```
///
/// Sanajan kita ngilangi implementasi `Drop` kanggo `HasTwoDrop`, para destruktor ing lapangan isih diarani.
/// Iki bakal nyebabake
///
/// ```test
/// Running!
/// Dropping HasDrop!
/// Dropping HasDrop!
/// ```
///
/// ## Sampeyan ora bisa nelpon `Drop::drop` dhewe
///
/// Amarga `Drop::drop` digunakake kanggo ngresiki nilai, bisa uga mbebayani nggunakake nilai kasebut sawise metode kasebut diarani.
/// Amarga `Drop::drop` ora duwe kepemilikan masukane, Rust nyegah penyalahgunaan kanthi ora ngidini sampeyan nelpon `Drop::drop` kanthi langsung.
///
/// Kanthi tembung liyane, yen sampeyan nyoba nelpon `Drop::drop` kanthi cetha ing conto ing ndhuwur, sampeyan bakal entuk kesalahan kompiler.
///
/// Yen sampeyan kanthi eksplisit nelpon destruktor nilai, [`mem::drop`] bisa digunakake.
///
/// [`mem::drop`]: drop
///
/// ## Pesenan gulung
///
/// Sing loro `HasDrop` sing endi sing pertama tiba?Kanggo strukture, padha karo urutan sing diandharake: `one` pisanan, banjur `two`.
/// Yen sampeyan pengin nyoba dhewe, sampeyan bisa ngowahi `HasDrop` ing ndhuwur kanggo ngemot sawetara data, kaya bilangan bulat, banjur gunakake ing `println!` ing `Drop`.
/// Prilaku iki dijamin karo basa.
///
/// Beda karo strukture, variabel lokal mudhun ing urutan terbalik:
///
/// ```rust
/// struct Foo;
///
/// impl Drop for Foo {
///     fn drop(&mut self) {
///         println!("Dropping Foo!")
///     }
/// }
///
/// struct Bar;
///
/// impl Drop for Bar {
///     fn drop(&mut self) {
///         println!("Dropping Bar!")
///     }
/// }
///
/// fn main() {
///     let _foo = Foo;
///     let _bar = Bar;
/// }
/// ```
///
/// Iki bakal dicithak
///
/// ```text
/// Dropping Bar!
/// Dropping Foo!
/// ```
///
/// Waca [the reference] kanggo aturan lengkap.
///
/// [the reference]: https://doc.rust-lang.org/reference/destructors.html
///
/// ## `Copy` lan `Drop` eksklusif
///
/// Sampeyan ora bisa ngetrapake [`Copy`] lan `Drop` kanthi jinis sing padha.Jinis sing `Copy` kanthi implisit diduplikasi dening kompiler, saengga angel diprediksi kapan, lan sepira kerusakan sing bakal ditindakake.
///
/// Kaya ngono, jinis kasebut ora bisa duwe karusakan.
///
///
///
///
///
///
///
///
///
///
#[lang = "drop"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Drop {
    /// Melakukan destruktor kanggo jinis iki.
    ///
    /// Cara iki diarani implisit nalika regane metu saka ruang lingkup, lan ora bisa diarani kanthi eksplisit (iki kesalahan compiler [E0040]).
    /// Nanging, fungsi [`mem::drop`] ing prelude bisa digunakake kanggo nyebut implementasi `Drop` argumen.
    ///
    /// Nalika metode iki diarani, `self` durung bisa ditanggepi.
    /// Iku mung kedadeyan sawise cara rampung.
    /// Yen ora kaya ngono, `self` bakal dadi referensi sing nggantung.
    ///
    /// # Panics
    ///
    /// Amarga [`panic!`] bakal nelpon `drop` nalika ngaso, [`panic!`] ing implementasine `drop` mesthine bakal dibatalake.
    ///
    /// Elinga yen sanajan panics iki, regane dianggep bakal mudhun;
    /// sampeyan ora kudu nyebabake `drop` ditelpon maneh.
    /// Iki biasane ditangani kanthi otomatis dening compiler, nanging nalika nggunakake kode sing ora aman, kadhang kala ora sengaja, utamane nalika nggunakake [`ptr::drop_in_place`].
    ///
    ///
    /// [E0040]: ../../error-index.html#E0040 [`panic!`]: crate::panic!
    /// [`mem::drop`]: drop
    /// [`ptr::drop_in_place`]: crate::ptr::drop_in_place
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn drop(&mut self);
}