//! Operator sing kakehan tuku
//!
//! Ngleksanakake traits iki ngidini sampeyan kakehan operator tartamtu.
//!
//! Sawetara traits iki diimpor dening prelude, mula kasedhiya ing saben program Rust.Mung operator digawe dening traits bisa overloaded.
//! Contone, operator tambahan (`+`) bisa kakehan liwat [`Add`] trait, nanging amarga operator tugas (`=`) ora duwe backing trait, mula ora bisa kakehan semantik.
//! Kajaba iku, modul iki ora nyedhiyakake mekanisme kanggo nggawe operator anyar.
//! Yen operator overload utawa traitless dibutuhake, sampeyan kudu ndeleng makro utawa plugin compiler kanggo nambah sintaks Rust.
//!
//! Implementasi operator traits mesthine ora nggumunake ing konteks dhewe-dhewe, ngelingi makna sing biasane lan [operator precedence].
//! Contone, nalika ngetrapake [`Mul`], operasi kasebut kudu padha karo multiplikasi (lan nuduhake sifat sing diarepake kaya asosiatif).
//!
//! Elinga yen sirkuit cendhak operator `&&` lan `||`, yaiku mung evaluasi operan kapindho yen menehi asil.Amarga tumindak kasebut ora bisa dileksanakake dening traits, `&&` lan `||` ora didhukung minangka operator sing kakehan.
//!
//! Akeh operator sing njupuk operan regane.Ing konteks non-umum sing kalebu jinis internal, iki biasane ora dadi masalah.
//! Nanging, nggunakake operator kasebut ing kode umum, mbutuhake sawetara perhatian yen nilai kudu digunakake maneh, tinimbang operator bisa nggunakake.Salah sawijining pilihan yaiku nggunakake [`clone`] kadang-kadang.
//! Pilihan liyane yaiku ngandelake jinis sing ana ing ngisor iki kanggo nyedhiyakake implementasi operator tambahan kanggo referensi.
//! Contone, kanggo jinis `T` sing ditemtokake pangguna sing mesthine bakal ndhukung tambahan, bisa uga luwih becik yen `T` lan `&T` ngetrapake traits [`Add<T>`][`Add`] lan [`Add<&T>`][`Add`] saengga kode umum bisa ditulis tanpa kloning sing ora perlu.
//!
//!
//! # Examples
//!
//! Contone iki nggawe struktur `Point` sing ngetrapake [`Add`] lan [`Sub`], banjur nduduhake nambah lan nyuda loro `Point`s.
//!
//! ```rust
//! use std::ops::{Add, Sub};
//!
//! #[derive(Debug, Copy, Clone, PartialEq)]
//! struct Point {
//!     x: i32,
//!     y: i32,
//! }
//!
//! impl Add for Point {
//!     type Output = Self;
//!
//!     fn add(self, other: Self) -> Self {
//!         Self {x: self.x + other.x, y: self.y + other.y}
//!     }
//! }
//!
//! impl Sub for Point {
//!     type Output = Self;
//!
//!     fn sub(self, other: Self) -> Self {
//!         Self {x: self.x - other.x, y: self.y - other.y}
//!     }
//! }
//!
//! assert_eq!(Point {x: 3, y: 3}, Point {x: 1, y: 0} + Point {x: 2, y: 3});
//! assert_eq!(Point {x: -1, y: -3}, Point {x: 1, y: 0} - Point {x: 2, y: 3});
//! ```
//!
//! Deleng dokumentasi kanggo saben trait kanggo conto implementasine.
//!
//! [`Fn`], [`FnMut`], lan [`FnOnce`] traits dileksanakake kanthi jinis sing bisa diarani kaya fungsi.Elinga yen [`Fn`] njupuk `&self`, [`FnMut`] njupuk `&mut self` lan [`FnOnce`] njupuk `self`.
//! Iki cocog karo telung jinis metode sing bisa ditindakake kanthi conto: call-by-referensi, referensi call-by-mutable, lan call-by-nilai.
//! Panggunaan paling umum saka traits iki yaiku tumindak wates kanggo fungsi level sing luwih dhuwur sing njupuk fungsi utawa penutupan minangka argumen.
//!
//! Njupuk [`Fn`] minangka parameter:
//!
//! ```rust
//! fn call_with_one<F>(func: F) -> usize
//!     where F: Fn(usize) -> usize
//! {
//!     func(1)
//! }
//!
//! let double = |x| x * 2;
//! assert_eq!(call_with_one(double), 2);
//! ```
//!
//! Njupuk [`FnMut`] minangka parameter:
//!
//! ```rust
//! fn do_twice<F>(mut func: F)
//!     where F: FnMut()
//! {
//!     func();
//!     func();
//! }
//!
//! let mut x: usize = 1;
//! {
//!     let add_two_to_x = || x += 2;
//!     do_twice(add_two_to_x);
//! }
//!
//! assert_eq!(x, 5);
//! ```
//!
//! Njupuk [`FnOnce`] minangka parameter:
//!
//! ```rust
//! fn consume_with_relish<F>(func: F)
//!     where F: FnOnce() -> String
//! {
//!     // `func` nganggo variabel sing dijupuk, mula ora bisa mbukak luwih saka sepisan
//!     //
//!     println!("Consumed: {}", func());
//!
//!     println!("Delicious!");
//!
//!     // Nyoba njaluk `func()` maneh bakal mbuwang kesalahan `use of moved value` kanggo `func`
//!     //
//! }
//!
//! let x = String::from("x");
//! let consume_and_return_x = move || x;
//! consume_with_relish(consume_and_return_x);
//!
//! // `consume_and_return_x` ora bisa digunakake maneh ing wektu iki
//! ```
//!
//! [`clone`]: Clone::clone
//! [operator precedence]: ../../reference/expressions.html#expression-precedence
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

mod arith;
mod bit;
mod control_flow;
mod deref;
mod drop;
mod function;
mod generator;
mod index;
mod range;
mod r#try;
mod unsize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::arith::{Add, Div, Mul, Neg, Rem, Sub};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::arith::{AddAssign, DivAssign, MulAssign, RemAssign, SubAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::bit::{BitAnd, BitOr, BitXor, Not, Shl, Shr};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::bit::{BitAndAssign, BitOrAssign, BitXorAssign, ShlAssign, ShrAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::deref::{Deref, DerefMut};

#[unstable(feature = "receiver_trait", issue = "none")]
pub use self::deref::Receiver;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::drop::Drop;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::function::{Fn, FnMut, FnOnce};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::index::{Index, IndexMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::range::{Range, RangeFrom, RangeFull, RangeTo};

#[stable(feature = "inclusive_range", since = "1.26.0")]
pub use self::range::{Bound, RangeBounds, RangeInclusive, RangeToInclusive};

#[unstable(feature = "try_trait", issue = "42327")]
pub use self::r#try::Try;

#[unstable(feature = "generator_trait", issue = "43122")]
pub use self::generator::{Generator, GeneratorState};

#[unstable(feature = "coerce_unsized", issue = "27732")]
pub use self::unsize::CoerceUnsized;

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
pub use self::unsize::DispatchFromDyn;

#[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
pub use self::control_flow::ControlFlow;