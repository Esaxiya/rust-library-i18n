/// Digunakake kanggo operasi dereferencing sing ora bisa diowahi, kaya `*v`.
///
/// Saliyane kang digunakake kanggo operasi dereferencing nyata karo operator (unary) `*` ing kahanan tetep, `Deref` uga digunakake implicitly dening compiler ing akeh kahanan.
/// Mekanisme iki diarani ['`Deref` coercion'][more].
/// Ing konteks sing bisa diowahi, [`DerefMut`] digunakake.
///
/// Ngleksanakake `Deref` kanggo petunjuk pinter nggawe gampang ngakses data ing mburine, mula ngleksanakake `Deref`.
/// Saliyane, aturan babagan `Deref` lan [`DerefMut`] dirancang khusus kanggo nampung petunjuk sing cerdas.
/// Amarga iku,**`Deref` mung kudu diterapake kanggo pitunjuk sing cerdas** supaya ora ana kebingungan.
///
/// Amarga alasan sing padha,**trait iki ora bakal gagal**.Gagal sak dereferencing bisa banget bingung nalika `Deref` wis kasebut implicitly.
///
/// # Luwih akeh babagan paksaan `Deref`
///
/// Yen `T` nindakake `Deref<Target = U>`, lan `x` aji jinis `T`, banjur:
///
/// * Ing konteks sing ora bisa diowahi, `*x` (ing endi `T` dudu referensi utawa pitunjuk mentah) padha karo `* Deref::deref(&x)`.
/// * Nilai-jinis jinis `&T` dipeksa nganti jinis `&U`
/// * `T` implisit implisit kabeh cara (immutable) jinis `U`.
///
/// Kanggo rincian liyane, bukak [the chapter in *The Rust Programming Language*][book] uga bagean referensi ing [the dereference operator][ref-deref-op], [method resolution] lan [type coercions].
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// Strukture kanthi siji lapangan sing bisa diakses kanthi ngilangi strukture.
///
/// ```
/// use std::ops::Deref;
///
/// struct DerefExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// let x = DerefExample { value: 'a' };
/// assert_eq!('a', *x);
/// ```
///
///
///
///
///
///
///
#[lang = "deref"]
#[doc(alias = "*")]
#[doc(alias = "&*")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Deref"]
pub trait Deref {
    /// Jinis sing diasilake sawise dereferensi.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_target"]
    #[cfg_attr(not(bootstrap), lang = "deref_target")]
    type Target: ?Sized;

    /// Dereferensi regane.
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_method"]
    fn deref(&self) -> &Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &T {
    type Target = T;

    #[rustc_diagnostic_item = "noop_method_deref"]
    fn deref(&self) -> &T {
        *self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !DerefMut for &T {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &mut T {
    type Target = T;

    fn deref(&self) -> &T {
        *self
    }
}

/// Digunakake kanggo operasi dereferencing sing bisa diowahi, kaya ing `*v = 1;`.
///
/// Saliyane digunakake kanggo operasi dereferensi eksplisit karo operator (unary) `*` ing konteks sing bisa diowahi, `DerefMut` uga digunakake kanthi implisit dening kompiler ing pirang-pirang kahanan.
/// Mekanisme iki diarani ['`Deref` coercion'][more].
/// Ing konteks sing ora bisa diowahi, [`Deref`] digunakake.
///
/// Ngleksanakake `DerefMut` kanggo petunjuk sing cerdas nggawe data mutasi bisa dadi gampang, mula ngleksanakake `DerefMut`.
/// Saliyane, aturan babagan [`Deref`] lan `DerefMut` dirancang khusus kanggo nampung petunjuk sing cerdas.
/// Amarga iku,**`DerefMut` mung kudu diterapake kanggo pitunjuk sing cerdas** supaya ora ana kebingungan.
///
/// Amarga alasan sing padha,**trait iki ora bakal gagal**.Gagal sajrone dereferensia bisa uga mbingungake nalika `DerefMut` ditrapake kanthi implisit.
///
/// # Luwih akeh babagan paksaan `Deref`
///
/// Yen `T` ngetrapake `DerefMut<Target = U>`, lan `x` minangka jinis tipe `T`, mula:
///
/// * Ing konteks sing bisa diowahi, `*x` (ing endi `T` dudu referensi utawa pitunjuk mentah) padha karo `* DerefMut::deref_mut(&mut x)`.
/// * Nilai-jinis jinis `&mut T` dipeksa nganti jinis `&mut U`
/// * `T` implisit implisit kabeh cara (mutable) jinis `U`.
///
/// Kanggo rincian liyane, bukak [the chapter in *The Rust Programming Language*][book] uga bagean referensi ing [the dereference operator][ref-deref-op], [method resolution] lan [type coercions].
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// Strukture kanthi siji lapangan sing bisa dimodifikasi kanthi ngilangi strukture.
///
/// ```
/// use std::ops::{Deref, DerefMut};
///
/// struct DerefMutExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefMutExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// impl<T> DerefMut for DerefMutExample<T> {
///     fn deref_mut(&mut self) -> &mut Self::Target {
///         &mut self.value
///     }
/// }
///
/// let mut x = DerefMutExample { value: 'a' };
/// *x = 'b';
/// assert_eq!('b', *x);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "deref_mut"]
#[doc(alias = "*")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DerefMut: Deref {
    /// Bisa uga ngilangi regane.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn deref_mut(&mut self) -> &mut Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for &mut T {
    fn deref_mut(&mut self) -> &mut T {
        *self
    }
}

/// Nuduhake manawa strukture bisa digunakake minangka panrima metode, tanpa fitur `arbitrary_self_types`.
///
/// Iki diimplementasikake kanthi jinis pointer stdlib kaya `Box<T>`, `Rc<T>`, `&T`, lan `Pin<P>`.
#[lang = "receiver"]
#[unstable(feature = "receiver_trait", issue = "none")]
#[doc(hidden)]
pub trait Receiver {
    // Empty.
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &T {}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &mut T {}