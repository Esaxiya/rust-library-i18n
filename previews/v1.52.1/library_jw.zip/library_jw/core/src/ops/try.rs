/// trait kanggo ngatur prilaku operator `?`.
///
/// Jinis sing ngetrapake `Try` yaiku jinis sing duwe cara kanonik kanggo ndeleng babagan dikotomi success/failure.
/// trait iki ngidini loro ngekstrak angka sukses utawa gagal kasebut saka conto sing wis ana lan nggawe conto anyar saka nilai sukses utawa gagal.
///
///
#[unstable(feature = "try_trait", issue = "42327")]
#[rustc_on_unimplemented(
    on(
        all(
            any(from_method = "from_error", from_method = "from_ok"),
            from_desugaring = "QuestionMark"
        ),
        message = "the `?` operator can only be used in {ItemContext} \
                    that returns `Result` or `Option` \
                    (or another type that implements `{Try}`)",
        label = "cannot use the `?` operator in {ItemContext} that returns `{Self}`",
        enclosing_scope = "this function should return `Result` or `Option` to accept `?`"
    ),
    on(
        all(from_method = "into_result", from_desugaring = "QuestionMark"),
        message = "the `?` operator can only be applied to values \
                    that implement `{Try}`",
        label = "the `?` operator cannot be applied to type `{Self}`"
    )
)]
#[doc(alias = "?")]
#[lang = "try"]
pub trait Try {
    /// Jinis nilai kasebut yen dideleng sukses.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Ok;
    /// Jinis nilai kasebut yen dideleng gagal.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Error;

    /// Ditrapake karo operator "?".Mbalik saka `Ok(t)` tegese eksekusi kudu diterusake kanthi normal, lan asil `?` yaiku nilai `t`.
    /// Bali saka `Err(e)` tegese eksekusi kudu branch menyang `catch` sing paling njero, utawa bali saka fungsi kasebut.
    ///
    /// Yen asil `Err(e)` bali, nilai `e` bakal "wrapped" ing jinis bali saka lingkup enkoding (sing kudu ngetrapake `Try`).
    ///
    /// Khusus, nilai `X::from_error(From::from(e))` bali, ing endi `X` minangka jinis bali saka fungsi enklusi.
    ///
    ///
    ///
    #[lang = "into_result"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn into_result(self) -> Result<Self::Ok, Self::Error>;

    /// Bungkus nilai kesalahan kanggo ngasilake asil gabungan.
    /// Contone, `Result::Err(x)` lan `Result::from_error(x)` padha karo.
    #[lang = "from_error"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_error(v: Self::Error) -> Self;

    /// Bungkus nilai OK kanggo nggawe asil gabungan.
    /// Contone, `Result::Ok(x)` lan `Result::from_ok(x)` padha karo.
    #[lang = "from_ok"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_ok(v: Self::Ok) -> Self;
}