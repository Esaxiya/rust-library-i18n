//! Iki minangka modul internal sing digunakake dening ifmt!durasi.struktur sing cemlorot kanggo susunan statis kanggo precompile format strings ahead wektu.
//!
//! dhéfinisi iki meh padha `ct` sami, nanging beda-beda ing iki bisa statically diparengake lan rada optimized kanggo durasi ing
//!
//!
#![allow(missing_debug_implementations)]

#[derive(Copy, Clone)]
pub struct Argument {
    pub position: usize,
    pub format: FormatSpec,
}

#[derive(Copy, Clone)]
pub struct FormatSpec {
    pub fill: char,
    pub align: Alignment,
    pub flags: u32,
    pub precision: Count,
    pub width: Count,
}

/// Kemungkinan sing bisa dijaluk minangka bagean saka arahan format.
#[derive(Copy, Clone, PartialEq, Eq)]
pub enum Alignment {
    /// Pratondo isi sing arep kiwa-didadekake siji.
    Left,
    /// Tandha manawa isi kudu didadekake siji.
    Right,
    /// Pratondo isi sing arep tengah-didadekake siji.
    Center,
    /// Ora Alignment iki dijaluk.
    Unknown,
}

/// Digunakake dening spesifikasi [width](https://doc.rust-lang.org/std/fmt/#width) lan [precision](https://doc.rust-lang.org/std/fmt/#precision).
#[derive(Copy, Clone)]
pub enum Count {
    /// Ditemtokake kanthi nomer harfiah, nyimpen regane
    Is(usize),
    /// Ditetepake nggunakake sintaksis `$` lan `*`, nyimpen indeks dadi `args`
    Param(usize),
    /// Ora kasebut
    Implied,
}