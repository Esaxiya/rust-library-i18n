//! Dhukungan Panic kanggo pornografi
//!
//! Perpustakaan inti ora bisa netepake panik, nanging *ngumumake* panik.
//! Iki tegese fungsi ing njero pornografi diijini menyang panic, nanging supaya migunani crate hulu kudu netepake panik supaya bisa digunakake pornografi.
//! Antarmuka saiki kanggo panik yaiku:
//!
//! ```
//! fn panic_impl(pi: &core::panic::PanicInfo<'_>) -> !
//! # { loop {} }
//! ```
//!
//! Definisi iki ngidini panik nganggo pesen umum, nanging ora bisa gagal kanthi nilai `Box<Any>`.
//! (`PanicInfo` mung ngemot `&(dyn Any + Send)`, sing ngisi angka dummy ing `PanicInfo: : internal_constructor`.) Alesan kanggo iki yaiku yen pornografi ora diidini.
//!
//!
//! Modul iki ngemot sawetara fungsi panik liyane, nanging iki mung item sing dibutuhake kanggo kompiler.Kabeh panics di-funnel liwat fungsi sing siji iki.
//! Simbol nyata dinyatakake liwat atribut `#[panic_handler]`.
//!
//!
//!

#![allow(dead_code, missing_docs)]
#![unstable(
    feature = "core_panic",
    reason = "internal details of the implementation of the `panic!` and related macros",
    issue = "none"
)]

use crate::fmt;
use crate::panic::{Location, PanicInfo};

/// Pengimplementasian makro `panic!` libcore yen ora ana format sing digunakake.
#[cold]
// aja nganti mandheg kajaba panic_im Mediate_abort kanggo ngindhari kode bloat ing situs telpon sabisa-bisa
//
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic"] // dibutuhake dening codegen kanggo panic nalika kebanjiran lan terminator `Assert` MIR liyane
pub fn panic(expr: &'static str) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // Gunakake Arguments::new_v1 tinimbang format_args! ("{}", Expr) supaya bisa nyuda overhead ukuran.
    // Format_args!makro nggunakake Tampilan trait kanggo nulis expr, sing nyebut Formatter::pad, sing kudu nampung truncation lan bantalan senar (sanajan ora ana sing digunakake ing kene).
    //
    // Nggunakake Arguments::new_v1 bisa uga ngidini kompiler ngilangi Formatter::pad saka biner output, ngirit nganti sawetara kilobita.
    //
    //
    panic_fmt(fmt::Arguments::new_v1(&[expr], &[]));
}

#[inline]
#[track_caller]
#[lang = "panic_str"] // needed kanggo const-mandhiri panics
pub fn panic_str(expr: &str) -> ! {
    panic_fmt(format_args!("{}", expr));
}

#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic_bounds_check"] // dibutuhake dening codegen kanggo panic ing akses OOB array/slice
fn panic_bounds_check(index: usize, len: usize) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    panic!("index out of bounds: the len is {} but the index is {}", len, index)
}

/// Pengimplementasian makro `panic!` libcore nalika digunakake ing format.
#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[cfg_attr(feature = "panic_immediate_abort", inline)]
#[track_caller]
pub fn panic_fmt(fmt: fmt::Arguments<'_>) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // CATETAN Fungsi iki ora nate nyebrang wates FFI;iku telpon Rust-to-Rust sing bisa dirampungake menyang fungsi `#[panic_handler]`.
    //
    extern "Rust" {
        #[lang = "panic_impl"]
        fn panic_impl(pi: &PanicInfo<'_>) -> !;
    }

    let pi = PanicInfo::internal_constructor(Some(&fmt), Location::caller());

    // SAFETY: `panic_impl` ditetepake ing kode Rust sing aman lan mula aman kanggo ditelpon.
    unsafe { panic_impl(&pi) }
}

#[derive(Debug)]
#[doc(hidden)]
pub enum AssertKind {
    Eq,
    Ne,
}

/// Fungsi internal kanggo makro `assert_eq!` lan `assert_ne!`
#[cold]
#[track_caller]
#[doc(hidden)]
pub fn assert_failed<T, U>(
    kind: AssertKind,
    left: &T,
    right: &U,
    args: Option<fmt::Arguments<'_>>,
) -> !
where
    T: fmt::Debug + ?Sized,
    U: fmt::Debug + ?Sized,
{
    #[track_caller]
    fn inner(
        kind: AssertKind,
        left: &dyn fmt::Debug,
        right: &dyn fmt::Debug,
        args: Option<fmt::Arguments<'_>>,
    ) -> ! {
        let op = match kind {
            AssertKind::Eq => "==",
            AssertKind::Ne => "!=",
        };

        match args {
            Some(args) => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`: {}"#,
                op, left, right, args
            ),
            None => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`"#,
                op, left, right,
            ),
        }
    }
    inner(kind, &left, &right, args)
}