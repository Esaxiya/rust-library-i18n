//! Traits kanggo konversi antarane jinis.
//!
//! traits ing modul iki nyedhiyakake cara kanggo ngowahi saka siji jinis menyang jinis liyane.
//! Saben trait duwe tujuan sing beda:
//!
//! - Nindakake [`AsRef`] trait kanggo konversi referensi referensi sing murah
//! - Nindakake [`AsMut`] trait kanggo konversi sing bisa diowahi kanthi murah
//! - Ngleksanakake [`From`] trait ngonsumsi mata uang Nilai-kanggo-nilai
//! - Ngleksanakake [`Into`] trait ngonsumsi mata uang Nilai-kanggo-nilai kanggo jinis njaba crate saiki
//! - The [`TryFrom`] lan [`TryInto`] traits nindakake kaya [`From`] lan [`Into`], nanging kudu dipun ginakaken nalika konversi bisa gagal.
//!
//! The traits ing modul iki asring digunakake minangka trait bounds kanggo fungsi umum sing kanggo bantahan kaping jinis sing didhukung.Waca dokumentasi saben trait kanggo conto.
//!
//! Minangka penulis perpustakaan, sampeyan kudu tansah seneng penerapan [`From<T>`][`From`] utawa [`TryFrom<T>`][`TryFrom`] tinimbang [`Into<U>`][`Into`] utawa [`TryInto<U>`][`TryInto`], minangka [`From`] lan [`TryFrom`] menehi luwih lan kurban padha [`Into`] utawa [`TryInto`] nindakake kanggo free, thanks kanggo implementasine kemul ing perpustakaan standar.
//! Nalika nargetake versi sadurunge Rust 1.41, iku uga perlu kanggo ngleksanakake [`Into`] utawa [`TryInto`] langsung nalika nindakake kanggo jinis njaba crate saiki.
//!
//! # Implementasi Generik
//!
//! - [`AsRef`] lan [`AsMut`] otomatis dereference manawa jinis utama referensi
//! - [`Saka`]`<U>kanggo T` tegese [`Into`]`</u><T><U>kanggo U`</u>
//! - [`CobaFrom`]`<U>kanggo T` gawe katut [`Coba Into`]`</u><T><U>kanggo U`</u>
//! - [`From`] lan [`Into`] refleksif, tegese kabeh jinis bisa `into` dhewe lan `from` dhewe
//!
//! Waca saben trait kanggo conto panggunaan.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

mod num;

#[unstable(feature = "convert_float_to_int", issue = "67057")]
pub use num::FloatToInt;

/// Fungsi identitas.
///
/// Rong perkara penting kanggo dicathet babagan fungsi iki:
///
/// - Ora mesthi padha karo penutupan kaya `|x| x`, amarga penutupan bisa ndadekake `x` dadi jinis sing beda.
///
/// - Ngalih input `x` sing diterusake menyang fungsi.
///
/// Nalika iku bisa koyone aneh duwe fungsi sing mung ngasilake gawe input, ana sawetara Efesus menarik.
///
///
/// # Examples
///
/// Nggunakake `identity` kanggo nindakake apa-apa ing urutan liyane, menarik, fungsi:
///
/// ```rust
/// use std::convert::identity;
///
/// fn manipulation(x: u32) -> u32 {
///     // Ayo padha ndalang yen nambah siji minangka fungsi sing menarik.
///     x + 1
/// }
///
/// let _arr = &[identity, manipulation];
/// ```
///
/// Nggunakake `identity` minangka kasus dhasar "do nothing" kanthi kondisional:
///
/// ```rust
/// use std::convert::identity;
///
/// # let condition = true;
/// #
/// # fn manipulation(x: u32) -> u32 { x + 1 }
/// #
/// let do_stuff = if condition { manipulation } else { identity };
///
/// // Lakukan luwih menarik ...
///
/// let _results = do_stuff(42);
/// ```
///
/// Nggunakake `identity` kanggo njaga `Some` Varian saka iterator saka `Option<T>`:
///
/// ```rust
/// use std::convert::identity;
///
/// let iter = vec![Some(1), None, Some(3)].into_iter();
/// let filtered = iter.filter_map(identity).collect::<Vec<_>>();
/// assert_eq!(vec![1, 3], filtered);
/// ```
///
///
#[stable(feature = "convert_id", since = "1.33.0")]
#[rustc_const_stable(feature = "const_identity", since = "1.33.0")]
#[inline]
pub const fn identity<T>(x: T) -> T {
    x
}

/// Digunakake kanggo nindakake konversi referensi-kanggo-referensi mirah.
///
/// trait iki padha karo [`AsMut`] sing digunakake kanggo ngowahi antarane referensi sing bisa diowahi.
/// Yen sampeyan kudu nindakake konversi larang, luwih becik ngetrapake [`From`] kanthi tipe `&T` utawa nulis fungsi khusus.
///
/// `AsRef` nduweni teken sing padha karo [`Borrow`], nanging [`Borrow`] beda-beda ing sawetara aspek:
///
/// - Boten kados `AsRef`, [`Borrow`] wis impl kemul kanggo maksud apa `T`, lan bisa digunakake kanggo nampa salah siji referensi utawa nilai.
/// - [`Borrow`] uga mbutuhake [`Hash`], [`Eq`] lan [`Ord`] kanggo nilai utangan padha karo regane sing diduweni.
/// Menawi mekaten, yen sampeyan pengin mung nyilih kolom siji strukture, sampeyan bisa ngetrapake `AsRef`, nanging ora [`Borrow`].
///
/// **Note: trait iki ora kudu gagal **.Yen konversi bisa gagal, gunakake cara khusus kanggo ngasilake [`Option<T>`] utawa [`Result<T, E>`].
///
/// # Implementasi Generik
///
/// - `AsRef` otomatis dereferences manawa jinis utama minangka referensi utawa referensi mutable (eg: `foo.as_ref()` will work the same if `foo` has type   `&mut Foo` or `&&mut Foo`)
///
///
/// # Examples
///
/// Kanthi nggunakake trait bounds, kita bisa nampa bantahan saka macem-macem jinis anggere bisa diowahi dadi jinis `T`.
///
/// Contone: Kanthi nggawe fungsi umum sing njupuk `AsRef<str>` kita nyebut sing kita arep kanggo nampa kabeh referensi sing bisa diowahi kanggo [`&str`] minangka pitakonan.
/// Amarga [`String`] lan [`&str`] ngetrapake `AsRef<str>`, kita bisa nampa loro kasebut minangka argumen input.
///
/// [`&str`]: primitive@str
/// [`Borrow`]: crate::borrow::Borrow
/// [`Eq`]: crate::cmp::Eq
/// [`Ord`]: crate::cmp::Ord
/// [`String`]: ../../std/string/struct.String.html
///
/// ```
/// fn is_hello<T: AsRef<str>>(s: T) {
///    assert_eq!("hello", s.as_ref());
/// }
///
/// let s = "hello";
/// is_hello(s);
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsRef<T: ?Sized> {
    /// Nindakake konversi.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_ref(&self) -> &T;
}

/// Digunakake kanggo nindakake konversi referensi sing bisa diowahi kanthi gampang.
///
/// trait iki mèmper [`AsRef`] nanging digunakake kanggo nindakake antarane referensi mutable.
/// Yen sampeyan kudu nindakake konversi larang, luwih becik ngetrapake [`From`] kanthi tipe `&mut T` utawa nulis fungsi khusus.
///
/// **Note: trait iki ora kudu gagal **.Yen konversi bisa gagal, gunakake cara khusus kanggo ngasilake [`Option<T>`] utawa [`Result<T, E>`].
///
/// # Implementasi Generik
///
/// - `AsMut` dereferensi otomatis yen jinis batin minangka referensi sing bisa diowahi (kayata: `foo.as_mut()` will work the same if `foo` has type `&mut Foo`   or `&mut &mut Foo`)
///
///
/// # Examples
///
/// Nggunakake `AsMut` minangka trait bound kanggo fungsi umum, kita bisa nampa kabeh referensi sing bisa diowahi sing bisa diowahi dadi tipe `&mut T`.
/// Amarga [`Box<T>`] ngleksanakake `AsMut<T>`, kita bisa nulis fungsi `add_one` sing njupuk kabeh argumen sing bisa dikonversi dadi `&mut u64`.
/// Amarga [`Box<T>`] ngetrapake `AsMut<T>`, `add_one` uga nampa bantahan jinis `&mut Box<u64>` uga:
///
/// ```
/// fn add_one<T: AsMut<u64>>(num: &mut T) {
///     *num.as_mut() += 1;
/// }
///
/// let mut boxed_num = Box::new(0);
/// add_one(&mut boxed_num);
/// assert_eq!(*boxed_num, 1);
/// ```
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsMut<T: ?Sized> {
    /// Nindakake konversi.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_mut(&mut self) -> &mut T;
}

/// Konversi regane-kanggo-nilai sing nggunakake nilai input.Kosok baline [`From`].
///
/// Siji ngirim supaya nindakaken [`Into`] lan ngleksanakake [`From`] tinimbang.
/// Penerapan [`From`] otomatis menehi siji karo implementasine [`Into`] thanks kanggo implementasine kemul ing perpustakaan standar.
///
/// Seneng nggunakake [`Into`] liwat [`From`] nalika khusus trait bounds ing fungsi umum kanggo mesthekake yen jinis sing mung ngleksanakake [`Into`] bisa digunakake uga.
///
/// **Note: trait iki ora kudu gagal **.Yen konversi bisa gagal, nggunakake [`TryInto`].
///
/// # Implementasi Generik
///
/// - [`Saka`]`<T>kanggo U` nggadahi `Into<U> for T`
/// - [`Into`] punika tanggapan, kang tegese `Into<T> for T` implementasi
///
/// # Penerapan [`Into`] mata kanggo jinis njaba ing versi lawas saka Rust
///
/// Sadurunge Rust 1.41, yen jinis tujuane dudu bagean saka crate saiki, mula sampeyan ora bisa ngetrapake [`From`] kanthi langsung.
/// Contone, njupuk kode iki:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> From<Wrapper<T>> for Vec<T> {
///     fn from(w: Wrapper<T>) -> Vec<T> {
///         w.0
///     }
/// }
/// ```
/// Iki bakal gagal nyusun versi lawas saka basa amarga aturan yatim piatu Rust biyen dadi luwih ketat.
/// Kanggo lulus iki, sampeyan bisa ngleksanakake [`Into`] langsung:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> Into<Vec<T>> for Wrapper<T> {
///     fn into(self) -> Vec<T> {
///         self.0
///     }
/// }
/// ```
///
/// Penting, sampeyan kudu ngerti yen [`Into`] ora nyedhiyakake implementasi [`From`] (kaya [`From`] karo [`Into`]).
/// Mula, sampeyan kudu terus nyoba ngetrapake [`From`] banjur bali menyang [`Into`] yen [`From`] ora bisa kaleksanan.
///
/// # Examples
///
/// [`String`] nindakake [: Into`]: <: [: Vec`]: <: [: u8`]: >>::
///
/// Kanggo nyebutake manawa kita pengin fungsi umum njupuk kabeh argumen sing bisa diowahi dadi jinis `T` sing ditemtokake, kita bisa nggunakake trait bound saka [`Into`]`<T>`.
///
/// Contone: Fungsi `is_hello` njupuk kabeh bantahan sing bisa diowahi dadi [: Vec`]: <: [: u8`]:>:.
///
/// ```
/// fn is_hello<T: Into<Vec<u8>>>(s: T) {
///    let bytes = b"hello".to_vec();
///    assert_eq!(bytes, s.into());
/// }
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`Vec`]: ../../std/vec/struct.Vec.html
///
///
///
///
///
///
#[rustc_diagnostic_item = "into_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Into<T>: Sized {
    /// Nindakake konversi.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into(self) -> T;
}

/// Digunakake kanggo nindakake konversi nilai-ke-nilai nalika nggunakake nilai input.Minangka wangsalan [`Into`].
///
/// Siji kudu luwih seneng ngetrapake `From` tinimbang [`Into`] amarga ngleksanakake `From` kanthi otomatis nyedhiyakake implementasi [`Into`] amarga implementasi kemul ing perpustakaan standar.
///
///
/// Mung gunakake [`Into`] nalika nargetake versi sadurunge Rust 1.41 lan konversi menyang jinis ing njaba crate saiki.
/// `From` ora bisa apa jinis iki mata uang ing versi sadurungé amarga saka aturan orphaning Rust kang.
/// Deleng [`Into`] kanggo rincian liyane.
///
/// Seneng nggunakake [`Into`] liwat nggunakake `From` nalika khusus trait bounds ing fungsi umum.
/// Kanthi cara iki, jinis sing langsung ngetrapake [`Into`] bisa uga digunakake minangka argumen.
///
/// `From` uga migunani banget nalika nindakake kesalahan.Nalika mbangun fungsi ingkang saged netepi, jinis bali umume bakal saka wangun `Result<T, E>`.
/// Kesalahan `From` trait simplifies nangani dening saéngga fungsi kanggo bali jinis kesalahan siji sing encapsulate kaping jinis kesalahan.Deleng bagean "Examples" lan [the book][book] kanggo rincian liyane.
///
/// **Note: trait iki ora kudu gagal **.Yen konversi bisa gagal, gunakake [`TryFrom`].
///
/// # Implementasi Generik
///
/// - `From<T> for U` tegese [`Into`]`<U>kanggo T`</u>
/// - `From` refleksif, tegese `From<T> for T` dileksanakake
///
/// # Examples
///
/// [`String`] nindakake `From<&str>`:
///
/// Lan konversi nyata saka `&str` menyang String wis rampung minangka nderek:
///
/// ```
/// let string = "hello".to_string();
/// let other_string = String::from("hello");
///
/// assert_eq!(string, other_string);
/// ```
///
/// Nalika nindakake kesalahan, asring migunani kanggo ngetrapake `From` kanggo jinis kesalahan sampeyan dhewe.
/// Kanthi ngowahi jinis kesalahan sing ndasari menyang jinis kesalahan kustom dhewe sing nyakup jinis kesalahan sing ana, kita bisa ngasilake siji jinis kesalahan tanpa kelangan informasi babagan panyebabe.
/// Operator '?' otomatis ngowahi jinis kesalahan ndasari kanggo jinis kesalahan adat kita dening nelpon `Into<CliError>::into` kang otomatis kasedhiya nalika nindakaken `From`.
/// Kompilator banjur nggunakake implementasine `Into` sing kudu digunakake.
///
/// ```
/// use std::fs;
/// use std::io;
/// use std::num;
///
/// enum CliError {
///     IoError(io::Error),
///     ParseError(num::ParseIntError),
/// }
///
/// impl From<io::Error> for CliError {
///     fn from(error: io::Error) -> Self {
///         CliError::IoError(error)
///     }
/// }
///
/// impl From<num::ParseIntError> for CliError {
///     fn from(error: num::ParseIntError) -> Self {
///         CliError::ParseError(error)
///     }
/// }
///
/// fn open_and_parse_file(file_name: &str) -> Result<i32, CliError> {
///     let mut contents = fs::read_to_string(&file_name)?;
///     let num: i32 = contents.trim().parse()?;
///     Ok(num)
/// }
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`from`]: From::from
/// [book]: ../../book/ch09-00-error-handling.html
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "from_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(on(
    all(_Self = "&str", T = "std::string::String"),
    note = "to coerce a `{T}` into a `{Self}`, use `&*` as a prefix",
))]
pub trait From<T>: Sized {
    /// Nindakake konversi.
    #[lang = "from"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from(_: T) -> Self;
}

/// Lan nyoba konversi sing nganggo `self`, kang bisa utawa ora bisa dadi larang.
///
/// Penulis pustaka biasane ora langsung ngetrapake trait iki, nanging luwih seneng ngetrapake [`TryFrom`] trait, sing menehi keluwesan sing luwih gedhe lan nyedhiyakake implementasi `TryInto` sing padha kanthi gratis, amarga implementasi kemul ing perpustakaan standar.
/// Kanggo informasi luwih lengkap babagan iki, deleng dokumentasi kanggo [`Into`].
///
/// # Ngleksanakake `TryInto`
///
/// Iki ciloko Watesan padha lan pertimbangan minangka penerapan [`Into`], ndeleng ana gamblang.
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_into_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryInto<T>: Sized {
    /// Jinis kasebut bali yen ana kesalahan konversi.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// Nindakake konversi.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_into(self) -> Result<T, Self::Error>;
}

/// Prasaja lan jinis mata uang aman sing bisa gagal ing cara kontrol ing sawetara kahanan.Iki minangka wangsalan [`TryInto`].
///
/// Iki migunani nalika sing mengkono konversi jinis sing bisa trivially kasil nanging uga perlu penanganan khusus.
/// Contone, ana cara kanggo ngowahi lan [`i64`] menyang [`i32`] nggunakake [`From`] trait, amarga [`i64`] bisa ngemot nilai sing [`i32`] ora bisa makili lan konversi bakal kelangan data.
///
/// Iki bisa ditangani dening truncating ing [`i64`] menyang [`i32`] (ateges menehi [: i64`] 's Nilai Modulo [`i32::MAX`]) utawa dening mung bali [`i32::MAX`], utawa dening sawetara cara liyane.
/// The [`From`] trait dimaksudaké mata sampurna, supaya `TryFrom` trait informs Programmer nalika konversi jinis bisa pindhah ala lan ngijini dheweke mutusake carane kanggo nangani iku.
///
/// # Implementasi Generik
///
/// - `TryFrom<T> for U` tegese [`Coba Into`]`<U>kanggo T`</u>
/// - [`try_from`] punika tanggapan, kang tegese `TryFrom<T> for T` implementasi lan ora bisa gagal-jinis `Error` digandhengake kanggo nelpon `T::try_from()` ing Nilai saka jinis `T` punika [`Infallible`].
/// Nalika jinis [`!`] wis owah [`Infallible`] lan [`!`] bakal padha.
///
/// `TryFrom<T>` bisa dileksanakake kaya ing ngisor iki:
///
/// ```
/// use std::convert::TryFrom;
///
/// struct GreaterThanZero(i32);
///
/// impl TryFrom<i32> for GreaterThanZero {
///     type Error = &'static str;
///
///     fn try_from(value: i32) -> Result<Self, Self::Error> {
///         if value <= 0 {
///             Err("GreaterThanZero only accepts value superior than zero!")
///         } else {
///             Ok(GreaterThanZero(value))
///         }
///     }
/// }
/// ```
///
/// # Examples
///
/// Minangka diterangake, [`i32`] nindakake: TryFrom <: [: i64`]:>::
///
/// ```
/// use std::convert::TryFrom;
///
/// let big_number = 1_000_000_000_000i64;
/// // Meneng truncates `big_number`, mbutuhake pendeteksi lan nangani truncation sawise kasunyatan.
/////
/// let smaller_number = big_number as i32;
/// assert_eq!(smaller_number, -727379968);
///
/// // Ngasilake kesalahan amarga `big_number` gedhe banget yen ora pas karo `i32`.
/////
/// let try_smaller_number = i32::try_from(big_number);
/// assert!(try_smaller_number.is_err());
///
/// // Ngasilake `Ok(3)`.
/// let try_successful_smaller_number = i32::try_from(3);
/// assert!(try_successful_smaller_number.is_ok());
/// ```
///
/// [`try_from`]: TryFrom::try_from
///
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_from_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryFrom<T>: Sized {
    /// Jinis kasebut bali yen ana kesalahan konversi.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// Nindakake konversi.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_from(value: T) -> Result<Self, Self::Error>;
}

////////////////////////////////////////////////////////////////////////////////
// IMPLS UMUM
////////////////////////////////////////////////////////////////////////////////

// Minangka ngangkat liwat&
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// Minangka ngangkat &mut
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &mut T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// FIXME (#45742): ngganti impls ing ndhuwur kanggo&/&mut kanthi luwih umum ing ngisor iki:
// // Minangka ngangkat Deref
// impl <D: ?Sized + Deref<Target: AsRef<U>>, U:? Ukuran> AsRef <U>kanggo D {fn as_ref(&self)-> &U {</u>
//
//         self.deref().as_ref()
//     }
// }

// AsMut ngangkat &mut
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsMut<U> for &mut T
where
    T: AsMut<U>,
{
    fn as_mut(&mut self) -> &mut U {
        (*self).as_mut()
    }
}

// FIXME (#45742): ganti impl ing ndhuwur kanggo &mut kanthi luwih umum ing ngisor iki:
// // AsMut ngangkat liwat DerefMut
// impl <D: ?Sized + Deref<Target: AsMut<U>>, U: ukuran> AsMut <U>kanggo D {fn as_mut(&mut self)-> &mut U {</u>
//
//         self.deref_mut().as_mut()
//     }
// }

// Saka nggadahi Into
#[stable(feature = "rust1", since = "1.0.0")]
impl<T, U> Into<U> for T
where
    U: From<T>,
{
    fn into(self) -> U {
        U::from(self)
    }
}

// Saka (lan kanthi mangkono Into) punika tanggapan
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> From<T> for T {
    fn from(t: T) -> T {
        t
    }
}

/// **Cathetan stabilitas:** impl Iki durung ana, nanging kita "reserving space" kanggo ditambahake ing future.
/// Deleng [rust-lang/rust#64715][#64715] kanggo rincian.
///
/// [#64715]: https://github.com/rust-lang/rust/issues/64715
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[allow(unused_attributes)] // FIXME(#58633): aja ndandani prinsip.
#[rustc_reservation_impl = "permitting this impl would forbid us from adding \
                            `impl<T> From<!> for T` later; see rust-lang/rust#64715 for details"]
impl<T> From<!> for T {
    fn from(t: !) -> T {
        t
    }
}

// TryFrom nggadahi TryInto
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryInto<U> for T
where
    U: TryFrom<T>,
{
    type Error = U::Error;

    fn try_into(self) -> Result<U, U::Error> {
        U::try_from(self)
    }
}

// Konversi tanpa wates padha karo konversi sing bisa ditemokake kanthi jinis kesalahan sing ora ana ing omah.
//
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryFrom<U> for T
where
    U: Into<T>,
{
    type Error = Infallible;

    fn try_from(value: U) -> Result<Self, Self::Error> {
        Ok(U::into(value))
    }
}

////////////////////////////////////////////////////////////////////////////////
// IMPLS KONKRIT
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsRef<[T]> for [T] {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsMut<[T]> for [T] {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for str {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "as_mut_str_for_str", since = "1.51.0")]
impl AsMut<str> for str {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

////////////////////////////////////////////////////////////////////////////////
// Jinis Kasalahan sing Ora Ana Kesalahan
////////////////////////////////////////////////////////////////////////////////

/// Jinis kesalahan kanggo kesalahan sing ora bisa kedadeyan.
///
/// Wiwit enum iki wis ora varian, Nilai saka jinis iki ora bisa bener ana.
/// Iki bisa migunani kanggo API umum sing nggunakake [`Result`] lan parameterisasi jinis kesalahan, kanggo nunjukake yen asile mesthi [`Ok`].
///
/// Contone, [`TryFrom`] trait (konversi sing ngasilake [`Result`]) duwe implementasi kemul kanggo kabeh jinis ing endi implementasi [`Into`] mbalikke.
///
/// ```ignore (illustrates std code, duplicating the impl in a doctest would be an error)
/// impl<T, U> TryFrom<U> for T where U: Into<T> {
///     type Error = Infallible;
///
///     fn try_from(value: U) -> Result<Self, Infallible> {
///         Ok(U::into(value))  // Never returns `Err`
///     }
/// }
/// ```
///
/// # kompatibilitas Future
///
/// Enum iki duwe peran sing padha karo [the `!`“never”type][never], sing ora stabil ing versi Rust iki.
/// Nalika `!` wis owah, kita rencana kanggo nggawe `Infallible` jinis alias menyang:
///
/// ```ignore (illustrates future std change)
/// pub type Infallible = !;
/// ```
///
/// ... lan pungkasanipun deprecate `Infallible`.
///
/// Nanging ana sawijining kasus sintaks `!` bisa digunakake sadurunge `!` distabilake minangka jinis lengkap: ing posisi jinis fungsi bali.
/// Khusus, iku bisa nindakake rong jinis fungsi pitunjuk beda:
///
/// ```
/// trait MyTrait {}
/// impl MyTrait for fn() -> ! {}
/// impl MyTrait for fn() -> std::convert::Infallible {}
/// ```
///
/// Kanthi `Infallible` dadi enum, kode iki bener.
/// Nanging nalika `Infallible` dadi alias kanggo never type, loro: impl`s bakal miwiti tumpang tindih lan mulane bakal diolehake dening aturan sesambungan trait basa.
///
///
///
///
///
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[derive(Copy)]
pub enum Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Clone for Infallible {
    fn clone(&self) -> Infallible {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Debug for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Display for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialEq for Infallible {
    fn eq(&self, _: &Infallible) -> bool {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Eq for Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialOrd for Infallible {
    fn partial_cmp(&self, _other: &Self) -> Option<crate::cmp::Ordering> {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Ord for Infallible {
    fn cmp(&self, _other: &Self) -> crate::cmp::Ordering {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl From<!> for Infallible {
    fn from(x: !) -> Self {
        x
    }
}

#[stable(feature = "convert_infallible_hash", since = "1.44.0")]
impl Hash for Infallible {
    fn hash<H: Hasher>(&self, _: &mut H) {
        match *self {}
    }
}