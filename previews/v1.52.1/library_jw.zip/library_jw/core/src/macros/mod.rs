#[doc = include_str!("panic.md")]
#[macro_export]
#[rustc_builtin_macro = "core_panic"]
#[allow_internal_unstable(edition_panic)]
#[stable(feature = "core", since = "1.6.0")]
#[rustc_diagnostic_item = "core_panic_macro"]
macro_rules! panic {
    // Ngembangaké kanggo salah siji `$crate::panic::panic_2015` utawa `$crate::panic::panic_2021` gumantung ing edition saka panelpon.
    //
    ($($arg:tt)*) => {
        /* compiler built-in */
    };
}

/// Negesake manawa rong ekspresi padha karo siji liyane (nggunakake [`PartialEq`]).
///
/// Ing panic, makro iki bakal nyithak nilai ekspresi kanthi perwakilan debug.
///
///
/// Kaya [`assert!`], gedhe iki nduwèni wangun liya, ngendi adat pesen panic bisa kasedhiya.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// assert_eq!(a, b);
///
/// assert_eq!(a, b, "we are testing addition with {} and {}", a, b);
/// ```
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_eq {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // The reborrows ngisor iki disengojo.
                    // Tanpa kasebut, slot tumpukan kanggo utang wis diwiwiti uga sadurunge regane dibandhingake, nyebabake bisa mudhun.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // The reborrows ngisor iki disengojo.
                    // Tanpa kasebut, slot tumpukan kanggo utang wis diwiwiti uga sadurunge regane dibandhingake, nyebabake bisa mudhun.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// Nengenaken bilih loro ungkapan ora padha kanggo saben liyane (nggunakake [`PartialEq`]).
///
/// Ing panic, makro iki bakal nyithak nilai ekspresi kanthi perwakilan debug.
///
///
/// Kaya [`assert!`], gedhe iki nduwèni wangun liya, ngendi adat pesen panic bisa kasedhiya.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// assert_ne!(a, b);
///
/// assert_ne!(a, b, "we are testing that the values are not equal");
/// ```
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_ne {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // The reborrows ngisor iki disengojo.
                    // Tanpa kasebut, slot tumpukan kanggo utang wis diwiwiti uga sadurunge regane dibandhingake, nyebabake bisa mudhun.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&($left), &($right)) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // The reborrows ngisor iki disengojo.
                    // Tanpa kasebut, slot tumpukan kanggo utang wis diwiwiti uga sadurunge regane dibandhingake, nyebabake bisa mudhun.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// Negesaké sing expression Sinar-X iku `true` ing durasi.
///
/// Iki bakal njaluk gedhe [`panic!`] yèn ekspresi sing diwènèhaké ora bisa mandhiri kanggo `true` ing durasi.
///
/// Kaya [`assert!`], makro iki uga duwe versi kaping pindho, ing endi pesen panic khusus bisa diwenehake.
///
/// # Uses
///
/// Boten kados [`assert!`], statements `debug_assert!` sing mung aktif ing non optimized di bangun minangka standar.
/// Lan mbangun optimized ora nglakokaké statements `debug_assert!` kajaba `-C debug-assertions` wis liwati kanggo compiler ing.
/// Iki ndadekake `debug_assert!` migunani kanggo kir sing larang banget kanggo saiki ing release mbangun nanging uga mbiyantu sak pembangunan.
/// Asil ngembangake `debug_assert!` mesthi dicenthang jinis.
///
/// Pratelan sing ora dicenthang ngidini program ing negara sing ora konsisten bisa terus mlaku, sing bisa uga duwe akibat sing ora dikarepake nanging ora bakal nyebabake kahanan aman yen mung kedadeyan ing kode sing aman.
///
/// Nanging, biaya kinerja pratelan ora bisa diukur umume.
/// Ngganti [`assert!`] karo `debug_assert!` mangkono mung disaranaké sawise penggambaran riwayat pepek, lan liyane Jahwéh, mung ing kode aman!
///
/// # Examples
///
/// ```
/// // pesen panic kanggo pandhedhesan iki nilai stringified saka expression diwenehi.
/////
/// debug_assert!(true);
///
/// fn some_expensive_computation() -> bool { true } // fungsi banget prasaja
/// debug_assert!(some_expensive_computation());
///
/// // njaluk karo pesen adat
/// let x = true;
/// debug_assert!(x, "x wasn't true!");
///
/// let a = 3; let b = 27;
/// debug_assert!(a + b == 30, "a = {}, b = {}", a, b);
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "debug_assert_macro"]
macro_rules! debug_assert {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert!($($arg)*); })
}

/// Nengenaken bilih loro ungkapan sing padha kanggo saben liyane.
///
/// Ing panic, makro iki bakal nyithak nilai ekspresi kanthi perwakilan debug.
///
/// Boten kados [`assert_eq!`], statements `debug_assert_eq!` sing mung aktif ing non optimized di bangun minangka standar.
/// Lan mbangun optimized ora nglakokaké statements `debug_assert_eq!` kajaba `-C debug-assertions` wis liwati kanggo compiler ing.
/// Iki ndadekake `debug_assert_eq!` migunani kanggo kir sing larang banget kanggo saiki ing release mbangun nanging uga mbiyantu sak pembangunan.
///
/// Asil ngembangake `debug_assert_eq!` mesthi dicenthang jinis.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// debug_assert_eq!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! debug_assert_eq {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_eq!($($arg)*); })
}

/// Nengenaken bilih loro ungkapan ora padha kanggo saben liyane.
///
/// Ing panic, makro iki bakal nyithak nilai ekspresi kanthi perwakilan debug.
///
/// Ora kaya [`assert_ne!`], pernyataan `debug_assert_ne!` mung diaktifake ing pambangunan sing ora dioptimalake kanthi gawan.
/// Mbangun sing dioptimalake ora bakal nglakokake pernyataan `debug_assert_ne!` kajaba `-C debug-assertions` dikirim menyang kompiler.
/// Iki nggawe `debug_assert_ne!` migunani kanggo mriksa sing larang banget kanggo ana ing rilis, nanging bisa uga migunani sajrone pangembangan.
///
/// Asil ngembangaken `debug_assert_ne!` tansah type dicenthang.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// debug_assert_ne!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
macro_rules! debug_assert_ne {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_ne!($($arg)*); })
}

/// Ngasilake apa expression diwenehi cocog samubarang pola tartamtu.
///
/// Kaya ing expression `match`, pola bisa optionally ngiring dening `if` lan expression njaga sing wis akses kanggo jeneng kaiket dening pola.
///
///
/// # Examples
///
/// ```
/// let foo = 'f';
/// assert!(matches!(foo, 'A'..='Z' | 'a'..='z'));
///
/// let bar = Some(4);
/// assert!(matches!(bar, Some(x) if x > 2));
/// ```
#[macro_export]
#[stable(feature = "matches_macro", since = "1.42.0")]
macro_rules! matches {
    ($expression:expr, $( $pattern:pat )|+ $( if $guard: expr )? $(,)?) => {
        match $expression {
            $( $pattern )|+ $( if $guard )? => true,
            _ => false
        }
    }
}

/// Unwraps asil utawa propagates kesalahan sawijining.
///
/// Operator `?` iki ditambahaké kanggo ngganti `try!` lan kudu digunakake tinimbang.
/// Salajengipun, `try` tembung reserved ing Rust 2018, supaya yen sampeyan kudu nggunakake, sampeyan kudu nggunakake [raw-identifier syntax][ris]: `r#try`.
///
///
/// [ris]: https://doc.rust-lang.org/nightly/rust-by-example/compatibility/raw_identifiers.html
///
/// `try!` cocog [`Result`] diwenehi.Ing cilik saka varian `Ok`, expression nduweni nilai saka cahya kebungkus.
///
/// Yen ana varian `Err`, kesalahan ing ngisor bakal ditemokake.`try!` banjur nindakake konversi nggunakake `From`.
/// Iki nyedhiyakake konversi otomatis ing antarane kesalahan khusus lan kesalahan sing luwih umum.
/// Kesalahan sing diasilake banjur langsung dibalekake.
///
/// Amarga bali awal, `try!` mung bisa digunakake ing fungsi sing ngasilake [`Result`].
///
/// # Examples
///
/// ```
/// use std::io;
/// use std::fs::File;
/// use std::io::prelude::*;
///
/// enum MyError {
///     FileWriteError
/// }
///
/// impl From<io::Error> for MyError {
///     fn from(e: io::Error) -> MyError {
///         MyError::FileWriteError
///     }
/// }
///
/// // Cara preferred saka Kasalahan bali cepet
/// fn write_to_file_question() -> Result<(), MyError> {
///     let mut file = File::create("my_best_friends.txt")?;
///     file.write_all(b"This is a list of my best friends.")?;
///     Ok(())
/// }
///
/// // Sadurunge cara saka Kasalahan bali cepet
/// fn write_to_file_using_try() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     r#try!(file.write_all(b"This is a list of my best friends."));
///     Ok(())
/// }
///
/// // Iki padha karo:
/// fn write_to_file_using_match() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     match file.write_all(b"This is a list of my best friends.") {
///         Ok(v) => v,
///         Err(e) => return Err(From::from(e)),
///     }
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "1.39.0", reason = "use the `?` operator instead")]
#[doc(alias = "?")]
macro_rules! r#try {
    ($expr:expr $(,)?) => {
        match $expr {
            $crate::result::Result::Ok(val) => val,
            $crate::result::Result::Err(err) => {
                return $crate::result::Result::Err($crate::convert::From::from(err));
            }
        }
    };
}

/// Nyerat data format menyang sanggan.
///
/// Makro iki nampa 'writer', string format, lan dhaptar argumen.
/// Argumentasi bakal diformat miturut senar format sing ditemtokake lan asile bakal diwenehake menyang panulis.
/// Panyerat uga Nilai karo cara `write_fmt`;umume iki rawuh saka implementasine saka salah siji ing [`fmt::Write`] utawa [`io::Write`] trait.
/// Makro ngasilake apa wae sing ngasilake metode `write_fmt`;umume [`fmt::Result`], utawa [`io::Result`].
///
/// Waca [`std::fmt`] kanggo informasi luwih lengkap ing ukara format senar.
///
/// [`std::fmt`]: ../std/fmt/index.html
/// [`fmt::Write`]: crate::fmt::Write
/// [`io::Write`]: ../std/io/trait.Write.html
/// [`fmt::Result`]: crate::fmt::Result
/// [`io::Result`]: ../std/io/type.Result.html
///
/// # Examples
///
/// ```
/// use std::io::Write;
///
/// fn main() -> std::io::Result<()> {
///     let mut w = Vec::new();
///     write!(&mut w, "test")?;
///     write!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(w, b"testformatted arguments");
///     Ok(())
/// }
/// ```
///
/// A modul bisa ngimpor loro `std::fmt::Write` lan `std::io::Write` lan telpon `write!` ing obyek penerapan salah siji, minangka obyek ora biasane ngleksanakake loro.
///
/// Nanging, modul kasebut kudu ngimpor kualifikasi traits supaya jenenge ora konflik:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     write!(&mut s, "{} {}", "abc", 123)?; // migunakake fmt::Write::write_fmt
///     write!(&mut v, "s = {:?}", s)?; // nggunakake io::Write::write_fmt
///     assert_eq!(v, b"s = \"abc 123\"");
///     Ok(())
/// }
/// ```
///
/// Note: gedhe iki bisa digunakake ing setups `no_std` uga.
/// Ing persiyapan `no_std` sampeyan tanggung jawab kanggo rincian implementasi komponen.
///
/// ```no_run
/// # extern crate core;
/// use core::fmt::Write;
///
/// struct Example;
///
/// impl Write for Example {
///     fn write_str(&mut self, _s: &str) -> core::fmt::Result {
///          unimplemented!();
///     }
/// }
///
/// let mut m = Example{};
/// write!(&mut m, "Hello World").expect("Not written");
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! write {
    ($dst:expr, $($arg:tt)*) => ($dst.write_fmt($crate::format_args!($($arg)*)))
}

/// Tulis data sing diformat dadi buffer, kanthi larik anyar ditambahake.
///
/// Ing kabeh platform, newline punika karakter LINE FEED (`\n`/`U+000A`) piyambak (ora tambahan kreta BALI (`\r`/`U+000D`).
///
/// Kanggo informasi luwih lengkap, waca [`write!`].Kanggo informasi ing ukara senar format, ndeleng [`std::fmt`].
///
/// [`std::fmt`]: ../std/fmt/index.html
///
/// # Examples
///
/// ```
/// use std::io::{Write, Result};
///
/// fn main() -> Result<()> {
///     let mut w = Vec::new();
///     writeln!(&mut w)?;
///     writeln!(&mut w, "test")?;
///     writeln!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(&w[..], "\ntest\nformatted arguments\n".as_bytes());
///     Ok(())
/// }
/// ```
///
/// A modul bisa ngimpor loro `std::fmt::Write` lan `std::io::Write` lan telpon `write!` ing obyek penerapan salah siji, minangka obyek ora biasane ngleksanakake loro.
/// Nanging, modul kasebut kudu ngimpor kualifikasi traits supaya jenenge ora konflik:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     writeln!(&mut s, "{} {}", "abc", 123)?; // migunakake fmt::Write::write_fmt
///     writeln!(&mut v, "s = {:?}", s)?; // nggunakake io::Write::write_fmt
///     assert_eq!(v, b"s = \"abc 123\\n\"\n");
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(format_args_nl)]
macro_rules! writeln {
    ($dst:expr $(,)?) => (
        $crate::write!($dst, "\n")
    );
    ($dst:expr, $($arg:tt)*) => (
        $dst.write_fmt($crate::format_args_nl!($($arg)*))
    );
}

/// Nuduhake kode dipunjangkau.
///
/// Iki migunani yen sampeyan ora bisa nemtokake manawa sawetara kode ora bisa digayuh.Contone:
///
/// * Cocokake tangan karo kahanan njaga.
/// * Loop sing dinamis mandheg.
/// * Iterator sing mungkasi kanthi dinamis.
///
/// Yen panentu yen kode kasebut ora bisa dibuktekake wis kabukten salah, program kasebut langsung diakhiri karo [`panic!`].
///
/// Ing pasangan aman saka gedhe iki fungsi [`unreachable_unchecked`], kang bakal nimbulaké prilaku cetho yen kode wis ngrambah.
///
///
/// [`unreachable_unchecked`]: crate::hint::unreachable_unchecked
///
/// # Panics
///
/// bakal tansah [`panic!`].
///
/// # Examples
///
/// Cocokake tangan:
///
/// ```
/// # #[allow(dead_code)]
/// fn foo(x: Option<i32>) {
///     match x {
///         Some(n) if n >= 0 => println!("Some(Non-negative)"),
///         Some(n) if n <  0 => println!("Some(Negative)"),
///         Some(_)           => unreachable!(), // ngumpulake kesalahan yen komentar metu
///         None              => println!("None")
///     }
/// }
/// ```
///
/// Iterators:
///
/// ```
/// # #[allow(dead_code)]
/// fn divide_by_three(x: u32) -> u32 { // salah sawijining implementasi x/3 paling mlarat
///     for i in 0.. {
///         if 3*i < i { panic!("u32 overflow"); }
///         if x < 3*i { return i-1; }
///     }
///     unreachable!();
/// }
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unreachable {
    () => ({
        $crate::panic!("internal error: entered unreachable code")
    });
    ($msg:expr $(,)?) => ({
        $crate::unreachable!("{}", $msg)
    });
    ($fmt:expr, $($arg:tt)*) => ({
        $crate::panic!($crate::concat!("internal error: entered unreachable code: ", $fmt), $($arg)*)
    });
}

/// Nuduhake kode unimplemented dening panicking karo pesen saka "not implemented".
///
/// Iki ngidini kode kanggo jinis-mriksa, sing migunani yen Stamping utawa penerapan trait sing kaping cara kang ora apa rencana saka nggunakake kabeh.
///
/// Bedane `unimplemented!` lan [`todo!`] yaiku nalika `todo!` nyedhiyakake maksud ngleksanakke fungsi mengko lan pesen kasebut "not yet implemented", `unimplemented!` ora menehi klaim kaya ngono.
/// sawijining pesen punika "not implemented".
/// Uga sawetara IDEs bakal menehi tandha: todo!: S.
///
/// # Panics
///
/// bakal tansah [`panic!`] amarga `unimplemented!` namung minangka cekakan kanggo `panic!` karo, pesen tartamtu tetep.
///
/// Kaya `panic!`, gedhe iki nduwèni wangun liya kanggo nampilake nilai adat.
///
/// # Examples
///
/// Ngomong kita duwe trait `Foo`:
///
/// ```
/// trait Foo {
///     fn bar(&self) -> u8;
///     fn baz(&self);
///     fn qux(&self) -> Result<u64, ()>;
/// }
/// ```
///
/// Kita pengin ngimplementasikake `Foo` kanggo 'MyStruct', nanging amarga ana sebab manawa mung ngetrapake fungsi `bar()`.
/// `baz()` lan `qux()` isih kudu ditetepake ing implementasine `Foo`, nanging kita bisa nggunakake `unimplemented!` ing definisi kasebut supaya kode bisa dikompilasi.
///
/// Kawulo pengin duwe kita program mandeg mlaku yen cara unimplemented sing ngrambah.
///
/// ```
/// # trait Foo {
/// #     fn bar(&self) -> u8;
/// #     fn baz(&self);
/// #     fn qux(&self) -> Result<u64, ()>;
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) -> u8 {
///         1 + 1
///     }
///
///     fn baz(&self) {
///         // Iku ndadekake ora pangertèn kanggo `baz` a `MyStruct`, supaya kita ora logika kene ing kabeh.
/////
///         // Iki bakal nampilaké "thread 'main' panicked at 'not implemented'".
///         unimplemented!();
///     }
///
///     fn qux(&self) -> Result<u64, ()> {
///         // We have sawetara logika kene, Kita bisa nambah pesen kanggo unimplemented!kanggo nampilake ngilangi kita.
///         // Iki bakal ditampilake: "thread 'main' panicked at 'not implemented: MyStruct isn't quxable'".
/////
/////
///         unimplemented!("MyStruct isn't quxable");
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
/// }
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unimplemented {
    () => ($crate::panic!("not implemented"));
    ($($arg:tt)+) => ($crate::panic!("not implemented: {}", $crate::format_args!($($arg)+)));
}

/// Nuduhake kode sing durung rampung.
///
/// Iki bisa migunani yen sampeyan Stamping lan mung looking kanggo duwe typecheck kode.
///
/// Bentenipun antarane [`unimplemented!`] lan `todo!` punika nalika `todo!` conveys maksud saka penerapan fungsi mengko lan pesen punika "not yet implemented", `unimplemented!` ndadekake ora claims kuwi.
/// sawijining pesen punika "not implemented".
/// Uga sawetara IDEs bakal menehi tandha: todo!: S.
///
/// # Panics
///
/// bakal tansah [`panic!`].
///
/// # Examples
///
/// Punika conto saka sawetara kode ing-proses.Kita duwe trait `Foo`:
///
/// ```
/// trait Foo {
///     fn bar(&self);
///     fn baz(&self);
/// }
/// ```
///
/// Kita arep kanggo ngleksanakake `Foo` ing salah siji jinis kita, nanging kita uga pengin karya ing mung `bar()` pisanan.Supaya kanggo kode kita kanggo ngripta, kita kudu ngleksanakake `baz()`, supaya kita bisa nggunakake `todo!`:
///
/// ```
/// # trait Foo {
/// #     fn bar(&self);
/// #     fn baz(&self);
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) {
///         // implementasine ing kene
///     }
///
///     fn baz(&self) {
///         // ayo kang ora padha sumelang ing bab nindakaken baz() kanggo saiki
///         todo!();
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
///
///     // kita malah ora nggunakake baz(), mula ora apa-apa.
/// }
/// ```
///
///
///
///
#[macro_export]
#[stable(feature = "todo_macro", since = "1.40.0")]
macro_rules! todo {
    () => ($crate::panic!("not yet implemented"));
    ($($arg:tt)+) => ($crate::panic!("not yet implemented: {}", $crate::format_args!($($arg)+)));
}

/// Definisi makro internal.
///
/// Umume sifat makro (stabilitas, visibilitas, lan liya-liyane) dijupuk saka kode sumber ing kene, kajaba fungsi ekspansi sing ngowahi input makro dadi output, fungsi kasebut diwenehake dening kompiler.
///
///
pub(crate) mod builtin {

    /// Panyebab kompilasi kanggo gagal karo pesen kesalahan ing diwenehi nalika pinanggih.
    ///
    /// Makro iki kudu digunakake nalika crate nggunakake strategi kompilasi bersyarat kanggo nyedhiyakake pesen kesalahan sing luwih apik kanggo kahanan sing salah.
    ///
    /// Iku wangun compiler-tingkat [`panic!`], nanging mancaraken kesalahan sak *kompilasi* tinimbang ing *durasi*.
    ///
    /// # Examples
    ///
    /// Loro conto kuwi macro lan lingkungan `#[cfg]`.
    ///
    /// Emit kesalahan compiler luwih apik yen gedhe sing wis liwati nilai bener.
    /// Tanpa branch pungkasan, kompilator isih bakal ngetokake kesalahan, nanging pesen kesalahan ora bakal nyebutake loro nilai sing valid.
    ///
    /// ```compile_fail
    /// macro_rules! give_me_foo_or_bar {
    ///     (foo) => {};
    ///     (bar) => {};
    ///     ($x:ident) => {
    ///         compile_error!("This macro only accepts `foo` or `bar`");
    ///     }
    /// }
    ///
    /// give_me_foo_or_bar!(neither);
    /// // ^ will fail at compile time with message "This macro only accepts `foo` or `bar`"
    /// ```
    ///
    /// Emit kesalahan compiler yen siji saka sawetara fitur ora kasedhiya.
    ///
    /// ```compile_fail
    /// #[cfg(not(any(feature = "foo", feature = "bar")))]
    /// compile_error!("Either feature \"foo\" or \"bar\" must be enabled for this crate.");
    /// ```
    ///
    #[stable(feature = "compile_error_macro", since = "1.20.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! compile_error {
        ($msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Mbangun paramèter kanggo macro senar format liyane.
    ///
    /// Fungsi makro iki kanthi njupuk string format literal sing ngemot `{}` kanggo saben argumen tambahan sing dilewati.
    /// `format_args!` nyiyapake paramèter tambahan kanggo mesthekake output bisa ditafsirake minangka senar lan kanonikake argumen dadi siji jinis.
    /// Nilai sing nindakake ing [`Display`] trait bisa liwati kanggo `format_args!`, minangka bisa sembarang implementasine [`Debug`] liwati menyang `{:?}` ing senar format.
    ///
    ///
    /// Makro iki ngasilake angka jinis [`fmt::Arguments`].Nilai iki bisa liwati menyang macro ing [`std::fmt`] kanggo Performing Pengalihan migunani.
    /// Kabeh makro format liyane ([`format!`], [`write!`], [`println!`], lsp) diproksi liwat siji iki.
    /// `format_args!`, ora kaya makro sing asale, ngindhari alokasi tumpukan.
    ///
    /// Sampeyan bisa nggunakake nilai [`fmt::Arguments`] sing `format_args!` ngasilake ing `Debug` lan `Display` kahanan katon ing ngisor iki.
    /// Conto uga nuduhake sing `Debug` lan format `Display` kanggo bab sing padha: senar format interpolated ing `format_args!`.
    ///
    /// ```rust
    /// let debug = format!("{:?}", format_args!("{} foo {:?}", 1, 2));
    /// let display = format!("{}", format_args!("{} foo {:?}", 1, 2));
    /// assert_eq!("1 foo 2", display);
    /// assert_eq!(display, debug);
    /// ```
    ///
    /// Kanggo informasi luwih lengkap, waca dokumentasi [`std::fmt`].
    ///
    /// [`Display`]: crate::fmt::Display
    /// [`Debug`]: crate::fmt::Debug
    /// [`fmt::Arguments`]: crate::fmt::Arguments
    /// [`std::fmt`]: ../std/fmt/index.html
    /// [`format!`]: ../std/macro.format.html
    /// [`println!`]: ../std/macro.println.html
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// let s = fmt::format(format_args!("hello {}", "world"));
    /// assert_eq!(s, format!("hello {}", "world"));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// Padha karo `format_args`, nanging nambah baris anyar ing pungkasan.
    #[unstable(
        feature = "format_args_nl",
        issue = "none",
        reason = "`format_args_nl` is only for internal \
                  language use and is subject to change"
    )]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args_nl {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// Inspects lan global lingkungan ing wektu ngripta.
    ///
    /// gedhe iki bakal nggedhekake kanggo ing Nilai saka global lingkungan dijenengi ing wektu ngripta, ngasilke expression saka jinis `&'static str`.
    ///
    ///
    /// Yen variabel lingkungan ora ditetepake, mula bakal ana kesalahan kompilasi.
    /// Kanggo ora emit kesalahan ngripta, nggunakake gedhe [`option_env!`] tinimbang.
    ///
    /// # Examples
    ///
    /// ```
    /// let path: &'static str = env!("PATH");
    /// println!("the $PATH variable at the time of compiling was: {}", path);
    /// ```
    ///
    /// Sampeyan bisa ngatur pesen kesalahan kanthi ngirim senar minangka parameter kapindho:
    ///
    /// ```compile_fail
    /// let doc: &'static str = env!("documentation", "what's that?!");
    /// ```
    ///
    /// Yen variabel lingkungan `documentation` ora ditetepake, sampeyan bakal entuk kesalahan ing ngisor iki:
    ///
    /// ```text
    /// error: what's that?!
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
        ($name:expr, $error_msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Optionally inspects lan global lingkungan ing wektu ngripta.
    ///
    /// Yen variabel lingkungan sing dijenengi saiki ana ing wektu kompilasi, iki bakal tuwuh dadi ekspresi jinis `Option<&'static str>` sing regane `Some` saka nilai variabel lingkungan.
    /// Yen variabel lingkungan ora ana, mula bakal ditambah dadi `None`.
    /// Deleng [`Option<T>`][Option] kanggo informasi luwih lengkap babagan jinis iki.
    ///
    /// Kesalahan kompilasi ora bakal diluncurake nalika nggunakake makro iki preduli ana variabel lingkungan utawa ora.
    ///
    /// # Examples
    ///
    /// ```
    /// let key: Option<&'static str> = option_env!("SECRET_KEY");
    /// println!("the secret key might be: {:?}", key);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! option_env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Concatenates Identifikasi menyang siji pengenal.
    ///
    /// gedhe iki njupuk nomer Identifikasi koma-dipisahake, lan concatenates wong kabeh dadi siji, ngasilke expression kang pengenal anyar.
    /// Wigati kesehatan sing ndadekake kaya sing gedhe iki ora bisa dijupuk variabel lokal.
    /// Uga, minangka aturan umum, macro sing mung diijini ing item, statement utawa posisi expression.
    /// Tegese nalika sampeyan nggunakake makro iki kanggo ngrujuk variabel, fungsi utawa modul liyane sing ana, sampeyan ora bisa nemtokake sing anyar.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(concat_idents)]
    ///
    /// # fn main() {
    /// fn foobar() -> u32 { 23 }
    ///
    /// let f = concat_idents!(foo, bar);
    /// println!("{}", f());
    ///
    /// // fn concat_idente! (anyar, nyenengake, jeneng) { }//ora bisa digunakake kanthi cara iki!
    /// # }
    /// ```
    ///
    ///
    ///
    #[unstable(
        feature = "concat_idents",
        issue = "29599",
        reason = "`concat_idents` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat_idents {
        ($($e:ident),+ $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Gabungan literal dadi irisan senar statis.
    ///
    /// Makro iki njupuk sawetara literal sing dipisahake koma, ngasilake ekspresi jinis `&'static str` sing nuduhake kabeh literal sing digandhengake kiwa-tengen.
    ///
    ///
    /// Ongko lan titik ngambang literals sing stringified supaya bisa sabendhel.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = concat!("test", 10, 'b', true);
    /// assert_eq!(s, "test10btrue");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat {
        ($($e:expr),* $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Ngembangaké kanggo nomer baris ing kang iki kasebut.
    ///
    /// Kanthi [`column!`] lan [`file!`], macro iki nyedhiyani informasi debugging kanggo gawe bab lokasi ing sumber.
    ///
    /// Ekspresi ditambahi wis jinis `u32` lan 1 basis, supaya baris pisanan ing saben file ngetung kanggo 1, liya kanggo 2, etc.
    /// Iki cocog karo pesen kesalahan dening kompiler utawa editor populer.
    /// baris bali *ora kudu* baris saka Wingi `line!` dhewe, nanging rodo Wingi gedhe pisanan anjog nganti Wingi saka gedhe `line!`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_line = line!();
    /// println!("defined on line: {}", current_line);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! line {
        () => {
            /* compiler built-in */
        };
    }

    /// Ngembangaké kanggo nomer kolom ing kang iki kasebut.
    ///
    /// Kanthi [`line!`] lan [`file!`], makro iki nyedhiyakake informasi debugging kanggo pangembang babagan lokasi ing sumber kasebut.
    ///
    /// Ekspresi sing ditambahi duwe jinis `u32` lan adhedhasar 1, mula kolom pertama ing saben baris ngevaluasi dadi 1, sing nomer loro nganti 2, lsp.
    /// Iki cocog karo pesen kesalahan dening kompiler utawa editor populer.
    /// asli bali *ora kudu* baris saka Wingi `column!` dhewe, nanging rodo Wingi gedhe pisanan anjog nganti Wingi saka gedhe `column!`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_col = column!();
    /// println!("defined on column: {}", current_col);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! column {
        () => {
            /* compiler built-in */
        };
    }

    /// Ngembangaké kanggo jeneng berkas kang iki kasebut.
    ///
    /// Kanthi [`line!`] lan [`column!`], macro iki nyedhiyani informasi debugging kanggo gawe bab lokasi ing sumber.
    ///
    /// Ekspresi ditambahi wis ngetik `&'static str`, lan file bali ora Wingi saka gedhe `file!` dhewe, nanging rodo Wingi gedhe pisanan anjog nganti Wingi saka gedhe `file!`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let this_file = file!();
    /// println!("defined in file: {}", this_file);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! file {
        () => {
            /* compiler built-in */
        };
    }

    /// Stringifies bantahan sawijining.
    ///
    /// gedhe iki bakal ngasilaken expression saka jinis `&'static str` kang stringification kabeh tokens liwati kanggo gedhe.
    /// Ora Watesan diselehake ing ukara saka Wingi gedhe dhewe.
    ///
    /// Wigati dimangerteni menawa asil ditambahi saka input tokens bisa ngganti ing future.Sampeyan kudu ati-ati yen gumantung ing output.
    ///
    /// # Examples
    ///
    /// ```
    /// let one_plus_one = stringify!(1 + 1);
    /// assert_eq!(one_plus_one, "1 + 1");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! stringify {
        ($($t:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Kalebu file sing dienkode UTF-8 minangka senar.
    ///
    /// File kasebut dununge ana hubungane karo file sing saiki (padha karo cara ditemokake modul).
    /// Path sing diwenehake ditafsirake kanthi cara khusus platform nalika nyusun wektu.
    /// Dadi, kanggo Kayata, lan Wingi karo path Windows ngemot backslashes `\` bakal ora ngumpulake bener ing Unix.
    ///
    ///
    /// gedhe iki bakal ngasilaken expression saka jinis `&'static str` kang isi berkas.
    ///
    /// # Examples
    ///
    /// Nganggep ana loro file ing direktori padha karo isi ing ngisor iki:
    ///
    /// Gambar 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// Gambar 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_str = include_str!("spanish.in");
    ///     assert_eq!(my_str, "adiós\n");
    ///     print!("{}", my_str);
    /// }
    /// ```
    ///
    /// Kompilasi 'main.rs' lan mlaku binar asil bakal print "adiós".
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_str {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Kalebu file minangka referensi kanggo Uploaded bait.
    ///
    /// File kasebut dununge ana hubungane karo file sing saiki (padha karo cara ditemokake modul).
    /// Path sing diwenehake ditafsirake kanthi cara khusus platform nalika nyusun wektu.
    /// Dadi, kanggo Kayata, lan Wingi karo path Windows ngemot backslashes `\` bakal ora ngumpulake bener ing Unix.
    ///
    ///
    /// gedhe iki bakal ngasilaken expression saka jinis `&'static [u8; N]` kang isi berkas.
    ///
    /// # Examples
    ///
    /// Nganggep ana loro file ing direktori padha karo isi ing ngisor iki:
    ///
    /// Gambar 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// Gambar 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let bytes = include_bytes!("spanish.in");
    ///     assert_eq!(bytes, b"adi\xc3\xb3s\n");
    ///     print!("{}", String::from_utf8_lossy(bytes));
    /// }
    /// ```
    ///
    /// Kompilasi 'main.rs' lan mlaku binar asil bakal print "adiós".
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_bytes {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Ngembangake senar sing nuduhake jalur modul saiki.
    ///
    /// Path modul saiki bisa panginten kang minangka hirarki modul anjog bali munggah menyang crate root.
    /// Komponèn pisanan saka path bali iku jeneng saka crate saiki kang nyawiji.
    ///
    /// # Examples
    ///
    /// ```
    /// mod test {
    ///     pub fn foo() {
    ///         assert!(module_path!().ends_with("test"));
    ///     }
    /// }
    ///
    /// test::foo();
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! module_path {
        () => {
            /* compiler built-in */
        };
    }

    /// Ngevaluasi kombinasi boolean flag konfigurasi ing wektu kompilasi.
    ///
    /// Saliyane atribut `#[cfg]`, makro iki diwenehake kanggo ngidini evaluasi ekspresi boolean flag konfigurasi.
    /// Iki kerep ndadékaké kanggo kode kurang duplikat gambar.
    ///
    /// Sintaks sing diwenehake menyang makro iki minangka sintaks sing padha karo atribut [`cfg`].
    ///
    /// `cfg!`, kados `#[cfg]`, ora mbusak kode lan mung ngetung bener utawa palsu.
    /// Contone, kabeh blok ing ekspresi if/else kudu valid nalika `cfg!` digunakake kanggo kondhisi kasebut, preduli apa sing dievaluasi `cfg!`.
    ///
    ///
    /// [`cfg`]: ../reference/conditional-compilation.html#the-cfg-attribute
    ///
    /// # Examples
    ///
    /// ```
    /// let my_directory = if cfg!(windows) {
    ///     "windows-specific-directory"
    /// } else {
    ///     "unix-directory"
    /// };
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! cfg {
        ($($cfg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Parses file minangka ekspresi utawa item miturut konteks.
    ///
    /// berkas iki dumunung relatif menyang berkas saiki (Kajaba kanggo carane modul sing ditemokaké).Path sing diwenehake ditafsirake kanthi cara khusus platform nalika nyusun wektu.
    /// Dadi, kanggo Kayata, lan Wingi karo path Windows ngemot backslashes `\` bakal ora ngumpulake bener ing Unix.
    ///
    /// Nggunakake makro iki asring dadi ide sing ala, amarga yen file diurai minangka ekspresi, mula bakal dilebokake ing kode sekitar kanthi ora higienis.
    /// Iki bisa nyebabake variabel utawa fungsi beda karo sing diarepake file yen ana variabel utawa fungsi sing duwe jeneng sing padha ing file saiki.
    ///
    ///
    /// # Examples
    ///
    /// Nganggep ana loro file ing direktori padha karo isi ing ngisor iki:
    ///
    /// File 'monkeys.in':
    ///
    /// ```ignore (only-for-syntax-highlight)
    /// ['🙈', '🙊', '🙉']
    ///     .iter()
    ///     .cycle()
    ///     .take(6)
    ///     .collect::<String>()
    /// ```
    ///
    /// Gambar 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_string = include!("monkeys.in");
    ///     assert_eq!("🙈🙊🙉🙈🙊🙉", my_string);
    ///     println!("{}", my_string);
    /// }
    /// ```
    ///
    /// Nyusun 'main.rs' lan mbukak binar sing diasilake bakal nyithak "🙈🙊🙉🙈🙊🙉".
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Negesaké sing expression Sinar-X iku `true` ing durasi.
    ///
    /// Iki bakal njaluk gedhe [`panic!`] yèn ekspresi sing diwènèhaké ora bisa mandhiri kanggo `true` ing durasi.
    ///
    /// # Uses
    ///
    /// Pandhedhesan sing tansah dicenthang ing loro debug lan release di bangun, lan ora bisa dipatèni.
    /// Waca [`debug_assert!`] kanggo pandhedhesan sing ora aktif ing release di bangun minangka standar.
    ///
    /// kode aman bisa gumantung ing `assert!` dilakokaké invariants mbukak-wektu sing, yen nerak bisa mimpin kanggo unsafety.
    ///
    /// nggunakake-kasus liyane `assert!` kalebu Testing lan enforcing invariants roto-wektu ing kode aman (kang nglanggar ora bisa kasil unsafety).
    ///
    ///
    /// # Pesen Custom
    ///
    /// gedhe iki nduwèni wangun liya, ngendi adat pesen panic bisa kasedhiya karo utawa tanpa bantahan kanggo format.
    /// Deleng [`std::fmt`] kanggo sintaks kanggo formulir iki.
    /// Ungkapan digunakake minangka format bantahan bakal mung mandhiri yen tuntutan gagal.
    ///
    /// [`std::fmt`]: ../std/fmt/index.html
    ///
    /// # Examples
    ///
    /// ```
    /// // pesen panic kanggo pandhedhesan iki nilai stringified saka expression diwenehi.
    /////
    /// assert!(true);
    ///
    /// fn some_computation() -> bool { true } // fungsi banget prasaja
    ///
    /// assert!(some_computation());
    ///
    /// // njaluk karo pesen adat
    /// let x = true;
    /// assert!(x, "x wasn't true!");
    ///
    /// let a = 3; let b = 27;
    /// assert!(a + b == 30, "a = {}, b = {}", a, b);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    #[rustc_diagnostic_item = "assert_macro"]
    #[allow_internal_unstable(core_panic, edition_panic)]
    macro_rules! assert {
        ($cond:expr $(,)?) => {{ /* compiler built-in */ }};
        ($cond:expr, $($arg:tt)+) => {{ /* compiler built-in */ }};
    }

    /// Déwan Inline
    ///
    /// Maca [unstable book] kanggo panggunaan.
    ///
    /// [unstable book]: ../unstable-book/library-features/asm.html
    #[unstable(
        feature = "asm",
        issue = "72016",
        reason = "inline assembly is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! asm {
        ("assembly template",
            $(operands,)*
            $(options($(option),*))?
        ) => {
            /* compiler built-in */
        };
    }

    /// LLVM-gaya apik Déwan.
    ///
    /// Maca [unstable book] kanggo panggunaan.
    ///
    /// [unstable book]: ../unstable-book/library-features/llvm-asm.html
    #[unstable(
        feature = "llvm_asm",
        issue = "70173",
        reason = "prefer using the new asm! syntax instead"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! llvm_asm {
        ("assembly template"
                        : $("output"(operand),)*
                        : $("input"(operand),)*
                        : $("clobbers",)*
                        : $("options",)*) => {
            /* compiler built-in */
        };
    }

    /// Modul-tingkat apik Déwan.
    #[unstable(
        feature = "global_asm",
        issue = "35119",
        reason = "`global_asm!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! global_asm {
        ("assembly") => {
            /* compiler built-in */
        };
    }

    /// Prints liwati tokens menyang output standar.
    #[unstable(
        feature = "log_syntax",
        issue = "29598",
        reason = "`log_syntax!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! log_syntax {
        ($($arg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Mbisakake utawa Disables jiplakan fungsi digunakake kanggo debugging macro liyane.
    #[unstable(
        feature = "trace_macros",
        issue = "29598",
        reason = "`trace_macros` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! trace_macros {
        (true) => {{ /* compiler built-in */ }};
        (false) => {{ /* compiler built-in */ }};
    }

    /// Atribut gedhe digunakake kanggo aplikasi macro Niru.
    #[cfg(not(bootstrap))]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    pub macro derive($item:item) {
        /* compiler built-in */
    }

    /// Makro atribut ditrapake menyang fungsi kanggo dadi tes unit.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test($item:item) {
        /* compiler built-in */
    }

    /// Atribut gedhe Applied menyang fungsi kanggo nguripake iku menyang test pathokan.
    #[unstable(
        feature = "test",
        issue = "50297",
        soft,
        reason = "`bench` is a part of custom test frameworks which are unstable"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro bench($item:item) {
        /* compiler built-in */
    }

    /// Detil implementasi makro `#[test]` lan `#[bench]`.
    #[unstable(
        feature = "custom_test_frameworks",
        issue = "50297",
        reason = "custom test frameworks are an unstable feature"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test_case($item:item) {
        /* compiler built-in */
    }

    /// Makro atribut ditrapake menyang statis kanggo ndhaptar minangka alokasi global.
    ///
    /// Deleng uga [`std::alloc::GlobalAlloc`](../std/alloc/trait.GlobalAlloc.html).
    #[stable(feature = "global_allocator", since = "1.28.0")]
    #[allow_internal_unstable(rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro global_allocator($item:item) {
        /* compiler built-in */
    }

    /// Tansah item iku Applied kanggo yen path liwati diaksès, lan mbusak digunakake.
    #[unstable(
        feature = "cfg_accessible",
        issue = "64797",
        reason = "`cfg_accessible` is not fully implemented"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_accessible($item:item) {
        /* compiler built-in */
    }

    /// Ngembangake kabeh atribut `#[cfg]` lan `#[cfg_attr]` ing fragmen kode sing ditrapake.
    #[cfg(not(bootstrap))]
    #[unstable(
        feature = "cfg_eval",
        issue = "82679",
        reason = "`cfg_eval` is a recently implemented feature"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_eval($($tt:tt)*) {
        /* compiler built-in */
    }

    /// Boten stabil implementasine rinci saka compiler `rustc`, aja nganggo.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics, libstd_sys_internals)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcDecodable($item:item) {
        /* compiler built-in */
    }

    /// Boten stabil implementasine rinci saka compiler `rustc`, aja nganggo.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcEncodable($item:item) {
        /* compiler built-in */
    }
}