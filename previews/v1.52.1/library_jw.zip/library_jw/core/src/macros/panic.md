Panics benang saiki.

Iki ngidini program kanggo siksa langsung lan nyedhiyani saran menyang panelpon saka program.
`panic!` kudu digunakake nalika program tekan negara sing ora bisa dibalekake maneh.

gedhe iki cara sampurna kanggo kahanan njaluk ing tuladha kode lan ing tes.
`panic!` disambungake rapet karo cara `unwrap` loro [`Option`][ounwrap] lan [`Result`][runwrap] enums.
Loro-lorone nindakake nelpon `panic!` nalika lagi disetel kanggo [`None`] utawa [`Err`] Varian.

Nalika nggunakake `panic!()` sampeyan bisa nemtokake DLL senar, sing dibangun nganggo ukara [`format!`].
Payload kasebut digunakake nalika nyuntikake panic menyang utas Rust sing nelpon, nyebabake benang dadi panic kabeh.

Prilaku standar ing `std` hook, IE
kode sing nganggo langsung sawise panic wis kasebut, iku print DLL pesen kanggo `stderr` bebarengan karo informasi file/line/column saka telpon `panic!()`.

Sampeyan bisa ngalahake panic hook nggunakake [`std::panic::set_hook()`].
Nang hook a panic bisa diakses minangka `&dyn Any + Send`, kang ngandhut salah siji `&str` utawa `String` kanggo invocations `panic!()` biasa.
Kanggo panic karo nilai jinis liyane liyane, [`panic_any`] bisa digunakake.

[`Result`] enum asring solusi sing luwih apik kanggo mbalek maneh saka kasalahan saka nggunakake gedhe `panic!`.
gedhe iki khusus dipigunakaké kanggo supaya nerusake nggunakake nilai salah, kayata saka sumber eksternal.
Rincian informasi bab jawab kesalahan ditemokake ing [book].

Deleng uga ing [`compile_error!`] gedhe, kanggo mundhakaken kasalahan sak kompilasi.

[ounwrap]: Option::unwrap
[runwrap]: Result::unwrap
[`std::panic::set_hook()`]: ../std/panic/fn.set_hook.html
[`panic_any`]: ../std/panic/fn.panic_any.html
[`Box`]: ../std/boxed/struct.Box.html
[`Any`]: crate::any::Any
[`format!`]: ../std/macro.format.html
[book]: ../book/ch09-00-error-handling.html

# Implementasi saiki

Yen thread utama panics bakal siksa kabeh Utas lan mungkasi program karo kode `101`.

# Examples

```should_panic
# #![allow(unreachable_code)]
panic!();
panic!("this is a terrible mistake!");
panic!("this is a {} {message}", "fancy", message = "message");
std::panic::panic_any(4); // panic with the value of 4 to be collected elsewhere
```





