//! Intrinsik panyusun.
//!
//! Ing ukara cocog ing `compiler/rustc_codegen_llvm/src/intrinsic.rs`.
//! Implementasi sing cocog ana ing `compiler/rustc_mir/src/interpret/intrinsics.rs`
//!
//! # intrinsics const
//!
//! Note: owah-owahan menyang constness saka intrinsics kudu rembugan karo tim basa.
//! Iki kalebu owahan ing stabilitas saka constness ing.
//!
//! Kanggo nggawe intrinsik bisa digunakake ing wektu kompilasi, kudu nyalin implementasine saka <https://github.com/rust-lang/miri/blob/master/src/shims/intrinsics.rs> dadi `compiler/rustc_mir/src/interpret/intrinsics.rs` lan nambah `#[rustc_const_unstable(feature = "foo", issue = "01234")]` menyang intrinsik.
//!
//!
//! Menawi kasirat mestine kanggo digunakake saka `const fn` karo ngubungake `rustc_const_stable`, ngubungake ing kasirat kudu `rustc_const_stable`, banget.
//! owah-owahan kuwi ora rampung tanpa rembugan T-lang, amarga Bakes fitur menyang basa sing ora bisa replicated ing kode pengguna tanpa compiler.
//!
//! # Volatiles
//!
//! The intrinsics molah malih nyedhiyani operasi dimaksudaké kanggo tumindak ing memori I/O, kang dijamin ora bakal reordered dening compiler tengen intrinsics molah malih liyane.Waca dokumentasi LLVM ing [[volatile]].
//!
//! [volatile]: http://llvm.org/docs/LangRef.html#volatile-memory-accesses
//!
//! # Atomics
//!
//! Intrinsik atom nyedhiyakake operasi atom umum ing tembung mesin, kanthi macem-macem urutan memori.Padha mbangun-turut ing semantik padha C++ 11.Waca dokumentasi LLVM ing [[atomics]].
//!
//! [atomics]: http://llvm.org/docs/Atomics.html
//!
//! A refresher cepet ing nindakake memori:
//!
//! * Ndarbeni, alangi kanggo éntuk kunci.Sabanjure maca lan nulis kedadeyan sawise alangan.
//! * Angkat, alangi kanggo ngeculake kunci.Sadurunge maos lan nyerat njupuk Panggonan sadurunge alangi.
//! * Operasi sing terus-terusan, terus-terusan konsisten dijamin kedadeyan kanthi tertib.Iki mode standar kanggo nggarap jinis atom lan padha karo Java kang `volatile`.
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![unstable(
    feature = "core_intrinsics",
    reason = "intrinsics are unlikely to ever be stabilized, instead \
                      they should be used through stabilized interfaces \
                      in the rest of the standard library",
    issue = "none"
)]
#![allow(missing_docs)]

use crate::marker::DiscriminantKind;
use crate::mem;

// Impor kasebut digunakake kanggo nyederhanakake link intra-doc
#[allow(unused_imports)]
#[cfg(all(target_has_atomic = "8", target_has_atomic = "32", target_has_atomic = "ptr"))]
use crate::sync::atomic::{self, AtomicBool, AtomicI32, AtomicIsize, AtomicU32, Ordering};

#[stable(feature = "drop_in_place", since = "1.8.0")]
#[rustc_deprecated(
    reason = "no longer an intrinsic - use `ptr::drop_in_place` directly",
    since = "1.52.0"
)]
#[inline]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // SAFETY: deleng `ptr::drop_in_place`
    unsafe { crate::ptr::drop_in_place(to_drop) }
}

extern "rust-intrinsic" {
    // NB, intrinsik iki njupuk pitunjuk mentah amarga mutasi memori alias, sing ora valid kanggo `&` utawa `&mut`.
    //

    /// Nyimpen angka yen nilai saiki padha karo nilai `old`.
    ///
    /// Versi stabil intrinsik iki kasedhiya ing jinis [`atomic`] liwat metode `compare_exchange` kanthi ngliwati [`Ordering::SeqCst`] minangka parameter `success` lan `failure`.
    ///
    /// Contone, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Nyimpen angka yen nilai saiki padha karo nilai `old`.
    ///
    /// Versi owah saka intrinsik iki kasedhiya ing jinis [`atomic`] liwat cara `compare_exchange` dening maringaken [`Ordering::Acquire`] minangka loro paramèter `success` lan `failure`.
    ///
    /// Contone, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Nyimpen angka yen nilai saiki padha karo nilai `old`.
    ///
    /// Versi stabil intrinsik iki kasedhiya ing jinis [`atomic`] liwat metode `compare_exchange` kanthi ngliwati [`Ordering::Release`] minangka `success` lan [`Ordering::Relaxed`] minangka parameter `failure`.
    /// Contone, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Nyimpen angka yen nilai saiki padha karo nilai `old`.
    ///
    /// Versi owah saka intrinsik iki kasedhiya ing jinis [`atomic`] liwat cara `compare_exchange` dening maringaken [`Ordering::AcqRel`] minangka `success` lan [`Ordering::Acquire`] minangka paramèter `failure`.
    /// Contone, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Nyimpen angka yen nilai saiki padha karo nilai `old`.
    ///
    /// Versi stabil intrinsik iki kasedhiya ing jinis [`atomic`] liwat metode `compare_exchange` kanthi ngliwati [`Ordering::Relaxed`] minangka parameter `success` lan `failure`.
    ///
    /// Contone, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Nyimpen angka yen nilai saiki padha karo nilai `old`.
    ///
    /// Versi stabil intrinsik iki kasedhiya ing jinis [`atomic`] liwat metode `compare_exchange` kanthi ngliwati [`Ordering::SeqCst`] minangka `success` lan [`Ordering::Relaxed`] minangka parameter `failure`.
    /// Contone, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Nyimpen angka yen nilai saiki padha karo nilai `old`.
    ///
    /// Versi owah saka intrinsik iki kasedhiya ing jinis [`atomic`] liwat cara `compare_exchange` dening maringaken [`Ordering::SeqCst`] minangka `success` lan [`Ordering::Acquire`] minangka paramèter `failure`.
    /// Contone, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Nyimpen angka yen nilai saiki padha karo nilai `old`.
    ///
    /// Versi owah saka intrinsik iki kasedhiya ing jinis [`atomic`] liwat cara `compare_exchange` dening maringaken [`Ordering::Acquire`] minangka `success` lan [`Ordering::Relaxed`] minangka paramèter `failure`.
    /// Contone, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Nyimpen angka yen nilai saiki padha karo nilai `old`.
    ///
    /// Versi owah saka intrinsik iki kasedhiya ing jinis [`atomic`] liwat cara `compare_exchange` dening maringaken [`Ordering::AcqRel`] minangka `success` lan [`Ordering::Relaxed`] minangka paramèter `failure`.
    /// Contone, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// Nyimpen angka yen nilai saiki padha karo nilai `old`.
    ///
    /// Versi owah saka intrinsik iki kasedhiya ing jinis [`atomic`] liwat cara `compare_exchange_weak` dening maringaken [`Ordering::SeqCst`] minangka loro paramèter `success` lan `failure`.
    ///
    /// Contone, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Nyimpen angka yen nilai saiki padha karo nilai `old`.
    ///
    /// Versi owah saka intrinsik iki kasedhiya ing jinis [`atomic`] liwat cara `compare_exchange_weak` dening maringaken [`Ordering::Acquire`] minangka loro paramèter `success` lan `failure`.
    ///
    /// Contone, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Nyimpen angka yen nilai saiki padha karo nilai `old`.
    ///
    /// Versi stabil intrinsik iki kasedhiya ing jinis [`atomic`] liwat metode `compare_exchange_weak` kanthi ngliwati [`Ordering::Release`] minangka `success` lan [`Ordering::Relaxed`] minangka parameter `failure`.
    /// Contone, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Nyimpen angka yen nilai saiki padha karo nilai `old`.
    ///
    /// Versi owah saka intrinsik iki kasedhiya ing jinis [`atomic`] liwat cara `compare_exchange_weak` dening maringaken [`Ordering::AcqRel`] minangka `success` lan [`Ordering::Acquire`] minangka paramèter `failure`.
    /// Contone, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Nyimpen angka yen nilai saiki padha karo nilai `old`.
    ///
    /// Versi owah saka intrinsik iki kasedhiya ing jinis [`atomic`] liwat cara `compare_exchange_weak` dening maringaken [`Ordering::Relaxed`] minangka loro paramèter `success` lan `failure`.
    ///
    /// Contone, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Nyimpen angka yen nilai saiki padha karo nilai `old`.
    ///
    /// Versi owah saka intrinsik iki kasedhiya ing jinis [`atomic`] liwat cara `compare_exchange_weak` dening maringaken [`Ordering::SeqCst`] minangka `success` lan [`Ordering::Relaxed`] minangka paramèter `failure`.
    /// Contone, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Nyimpen angka yen nilai saiki padha karo nilai `old`.
    ///
    /// Versi owah saka intrinsik iki kasedhiya ing jinis [`atomic`] liwat cara `compare_exchange_weak` dening maringaken [`Ordering::SeqCst`] minangka `success` lan [`Ordering::Acquire`] minangka paramèter `failure`.
    /// Contone, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Nyimpen angka yen nilai saiki padha karo nilai `old`.
    ///
    /// Versi owah saka intrinsik iki kasedhiya ing jinis [`atomic`] liwat cara `compare_exchange_weak` dening maringaken [`Ordering::Acquire`] minangka `success` lan [`Ordering::Relaxed`] minangka paramèter `failure`.
    /// Contone, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Nyimpen angka yen nilai saiki padha karo nilai `old`.
    ///
    /// Versi stabil intrinsik iki kasedhiya ing jinis [`atomic`] liwat metode `compare_exchange_weak` kanthi ngliwati [`Ordering::AcqRel`] minangka `success` lan [`Ordering::Relaxed`] minangka parameter `failure`.
    /// Contone, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// Muat nilai saiki pitunjuk.
    ///
    /// Versi owah saka intrinsik iki kasedhiya ing jinis [`atomic`] liwat cara `load` dening maringaken [`Ordering::SeqCst`] minangka `order`.
    /// Contone, [`AtomicBool::load`].
    ///
    pub fn atomic_load<T: Copy>(src: *const T) -> T;
    /// Muat nilai saiki pitunjuk.
    ///
    /// Versi owah saka intrinsik iki kasedhiya ing jinis [`atomic`] liwat cara `load` dening maringaken [`Ordering::Acquire`] minangka `order`.
    /// Contone, [`AtomicBool::load`].
    ///
    pub fn atomic_load_acq<T: Copy>(src: *const T) -> T;
    /// Muat nilai saiki pitunjuk.
    ///
    /// Versi stabil intrinsik iki kasedhiya ing jinis [`atomic`] liwat metode `load` kanthi ngliwati [`Ordering::Relaxed`] dadi `order`.
    /// Contone, [`AtomicBool::load`].
    ///
    pub fn atomic_load_relaxed<T: Copy>(src: *const T) -> T;
    pub fn atomic_load_unordered<T: Copy>(src: *const T) -> T;

    /// Nyimpen regane ing lokasi memori sing ditemtokake.
    ///
    /// Versi stabil intrinsik iki kasedhiya ing jinis [`atomic`] liwat metode `store` kanthi ngliwati [`Ordering::SeqCst`] dadi `order`.
    /// Contone, [`AtomicBool::store`].
    ///
    pub fn atomic_store<T: Copy>(dst: *mut T, val: T);
    /// Nyimpen regane ing lokasi memori sing ditemtokake.
    ///
    /// Versi stabil intrinsik iki kasedhiya ing jinis [`atomic`] liwat metode `store` kanthi ngliwati [`Ordering::Release`] dadi `order`.
    /// Contone, [`AtomicBool::store`].
    ///
    pub fn atomic_store_rel<T: Copy>(dst: *mut T, val: T);
    /// Nyimpen regane ing lokasi memori sing ditemtokake.
    ///
    /// Versi owah saka intrinsik iki kasedhiya ing jinis [`atomic`] liwat cara `store` dening maringaken [`Ordering::Relaxed`] minangka `order`.
    /// Contone, [`AtomicBool::store`].
    ///
    pub fn atomic_store_relaxed<T: Copy>(dst: *mut T, val: T);
    pub fn atomic_store_unordered<T: Copy>(dst: *mut T, val: T);

    /// Nyimpen Nilai ing lokasi memori kasebut, bali Nilai lawas.
    ///
    /// Versi owah saka intrinsik iki kasedhiya ing jinis [`atomic`] liwat cara `swap` dening maringaken [`Ordering::SeqCst`] minangka `order`.
    /// Contone, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg<T: Copy>(dst: *mut T, src: T) -> T;
    /// Nyimpen Nilai ing lokasi memori kasebut, bali Nilai lawas.
    ///
    /// Versi owah saka intrinsik iki kasedhiya ing jinis [`atomic`] liwat cara `swap` dening maringaken [`Ordering::Acquire`] minangka `order`.
    /// Contone, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Nyimpen Nilai ing lokasi memori kasebut, bali Nilai lawas.
    ///
    /// Versi stabil intrinsik iki kasedhiya ing jinis [`atomic`] liwat metode `swap` kanthi ngliwati [`Ordering::Release`] dadi `order`.
    /// Contone, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Nyimpen Nilai ing lokasi memori kasebut, bali Nilai lawas.
    ///
    /// Versi owah saka intrinsik iki kasedhiya ing jinis [`atomic`] liwat cara `swap` dening maringaken [`Ordering::AcqRel`] minangka `order`.
    /// Contone, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Nyimpen Nilai ing lokasi memori kasebut, bali Nilai lawas.
    ///
    /// Versi owah saka intrinsik iki kasedhiya ing jinis [`atomic`] liwat cara `swap` dening maringaken [`Ordering::Relaxed`] minangka `order`.
    /// Contone, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Nambah menyang Nilai saiki, bali Nilai sadurungé.
    ///
    /// Versi owah saka intrinsik iki kasedhiya ing jinis [`atomic`] liwat cara `fetch_add` dening maringaken [`Ordering::SeqCst`] minangka `order`.
    /// Contone, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd<T: Copy>(dst: *mut T, src: T) -> T;
    /// Nambah menyang Nilai saiki, bali Nilai sadurungé.
    ///
    /// Versi owah saka intrinsik iki kasedhiya ing jinis [`atomic`] liwat cara `fetch_add` dening maringaken [`Ordering::Acquire`] minangka `order`.
    /// Contone, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Nambah menyang Nilai saiki, bali Nilai sadurungé.
    ///
    /// Versi stabil intrinsik iki kasedhiya ing jinis [`atomic`] liwat metode `fetch_add` kanthi ngliwati [`Ordering::Release`] dadi `order`.
    /// Contone, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Nambah menyang Nilai saiki, bali Nilai sadurungé.
    ///
    /// Versi owah saka intrinsik iki kasedhiya ing jinis [`atomic`] liwat cara `fetch_add` dening maringaken [`Ordering::AcqRel`] minangka `order`.
    /// Contone, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Nambah menyang Nilai saiki, bali Nilai sadurungé.
    ///
    /// Versi owah saka intrinsik iki kasedhiya ing jinis [`atomic`] liwat cara `fetch_add` dening maringaken [`Ordering::Relaxed`] minangka `order`.
    /// Contone, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Kurangi saka nilai saiki, ngasilake regane sadurunge.
    ///
    /// Versi stabil intrinsik iki kasedhiya ing jinis [`atomic`] liwat metode `fetch_sub` kanthi ngliwati [`Ordering::SeqCst`] dadi `order`.
    /// Contone, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub<T: Copy>(dst: *mut T, src: T) -> T;
    /// Kurangi saka nilai saiki, ngasilake regane sadurunge.
    ///
    /// Versi stabil intrinsik iki kasedhiya ing jinis [`atomic`] liwat metode `fetch_sub` kanthi ngliwati [`Ordering::Acquire`] dadi `order`.
    /// Contone, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Kurangi saka nilai saiki, ngasilake regane sadurunge.
    ///
    /// Versi stabil intrinsik iki kasedhiya ing jinis [`atomic`] liwat metode `fetch_sub` kanthi ngliwati [`Ordering::Release`] dadi `order`.
    /// Contone, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Kurangi saka nilai saiki, ngasilake regane sadurunge.
    ///
    /// Versi owah saka intrinsik iki kasedhiya ing jinis [`atomic`] liwat cara `fetch_sub` dening maringaken [`Ordering::AcqRel`] minangka `order`.
    /// Contone, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Kurangi saka nilai saiki, ngasilake regane sadurunge.
    ///
    /// Versi owah saka intrinsik iki kasedhiya ing jinis [`atomic`] liwat cara `fetch_sub` dening maringaken [`Ordering::Relaxed`] minangka `order`.
    /// Contone, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitwise lan karo nilai saiki, bali Nilai sadurungé.
    ///
    /// Versi owah saka intrinsik iki kasedhiya ing jinis [`atomic`] liwat cara `fetch_and` dening maringaken [`Ordering::SeqCst`] minangka `order`.
    /// Contone, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise lan karo nilai saiki, bali Nilai sadurungé.
    ///
    /// Versi stabil intrinsik iki kasedhiya ing jinis [`atomic`] liwat metode `fetch_and` kanthi ngliwati [`Ordering::Acquire`] dadi `order`.
    /// Contone, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise lan karo nilai saiki, bali Nilai sadurungé.
    ///
    /// Versi stabil intrinsik iki kasedhiya ing jinis [`atomic`] liwat metode `fetch_and` kanthi ngliwati [`Ordering::Release`] dadi `order`.
    /// Contone, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise lan karo nilai saiki, bali Nilai sadurungé.
    ///
    /// Versi stabil intrinsik iki kasedhiya ing jinis [`atomic`] liwat metode `fetch_and` kanthi ngliwati [`Ordering::AcqRel`] dadi `order`.
    /// Contone, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise lan karo nilai saiki, bali Nilai sadurungé.
    ///
    /// Versi owah saka intrinsik iki kasedhiya ing jinis [`atomic`] liwat cara `fetch_and` dening maringaken [`Ordering::Relaxed`] minangka `order`.
    /// Contone, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitwise nand kanthi nilai saiki, ngasilake angka sadurunge.
    ///
    /// Versi owah saka intrinsik iki kasedhiya ing jinis [`AtomicBool`] liwat cara `fetch_nand` dening maringaken [`Ordering::SeqCst`] minangka `order`.
    /// Contone, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise nand kanthi nilai saiki, ngasilake angka sadurunge.
    ///
    /// Versi owah saka intrinsik iki kasedhiya ing jinis [`AtomicBool`] liwat cara `fetch_nand` dening maringaken [`Ordering::Acquire`] minangka `order`.
    /// Contone, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise nand kanthi nilai saiki, ngasilake angka sadurunge.
    ///
    /// Versi owah saka intrinsik iki kasedhiya ing jinis [`AtomicBool`] liwat cara `fetch_nand` dening maringaken [`Ordering::Release`] minangka `order`.
    /// Contone, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise nand kanthi nilai saiki, ngasilake angka sadurunge.
    ///
    /// Versi stabil intrinsik iki kasedhiya ing jinis [`AtomicBool`] liwat metode `fetch_nand` kanthi ngliwati [`Ordering::AcqRel`] dadi `order`.
    /// Contone, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise nand kanthi nilai saiki, ngasilake angka sadurunge.
    ///
    /// Versi owah saka intrinsik iki kasedhiya ing jinis [`AtomicBool`] liwat cara `fetch_nand` dening maringaken [`Ordering::Relaxed`] minangka `order`.
    /// Contone, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitwise utawa karo nilai saiki, bali Nilai sadurungé.
    ///
    /// Versi owah saka intrinsik iki kasedhiya ing jinis [`atomic`] liwat cara `fetch_or` dening maringaken [`Ordering::SeqCst`] minangka `order`.
    /// Contone, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise utawa karo nilai saiki, bali Nilai sadurungé.
    ///
    /// Versi stabil intrinsik iki kasedhiya ing jinis [`atomic`] liwat metode `fetch_or` kanthi ngliwati [`Ordering::Acquire`] dadi `order`.
    /// Contone, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise utawa karo nilai saiki, bali Nilai sadurungé.
    ///
    /// Versi owah saka intrinsik iki kasedhiya ing jinis [`atomic`] liwat cara `fetch_or` dening maringaken [`Ordering::Release`] minangka `order`.
    /// Contone, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise utawa karo nilai saiki, bali Nilai sadurungé.
    ///
    /// Versi owah saka intrinsik iki kasedhiya ing jinis [`atomic`] liwat cara `fetch_or` dening maringaken [`Ordering::AcqRel`] minangka `order`.
    /// Contone, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise utawa karo nilai saiki, bali Nilai sadurungé.
    ///
    /// Versi owah saka intrinsik iki kasedhiya ing jinis [`atomic`] liwat cara `fetch_or` dening maringaken [`Ordering::Relaxed`] minangka `order`.
    /// Contone, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// xor Bitwise karo nilai saiki, bali Nilai sadurungé.
    ///
    /// Versi owah saka intrinsik iki kasedhiya ing jinis [`atomic`] liwat cara `fetch_xor` dening maringaken [`Ordering::SeqCst`] minangka `order`.
    /// Contone, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor<T: Copy>(dst: *mut T, src: T) -> T;
    /// xor Bitwise karo nilai saiki, bali Nilai sadurungé.
    ///
    /// Versi owah saka intrinsik iki kasedhiya ing jinis [`atomic`] liwat cara `fetch_xor` dening maringaken [`Ordering::Acquire`] minangka `order`.
    /// Contone, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// xor Bitwise karo nilai saiki, bali Nilai sadurungé.
    ///
    /// Versi owah saka intrinsik iki kasedhiya ing jinis [`atomic`] liwat cara `fetch_xor` dening maringaken [`Ordering::Release`] minangka `order`.
    /// Contone, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// xor Bitwise karo nilai saiki, bali Nilai sadurungé.
    ///
    /// Versi owah saka intrinsik iki kasedhiya ing jinis [`atomic`] liwat cara `fetch_xor` dening maringaken [`Ordering::AcqRel`] minangka `order`.
    /// Contone, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// xor Bitwise karo nilai saiki, bali Nilai sadurungé.
    ///
    /// Versi owah saka intrinsik iki kasedhiya ing jinis [`atomic`] liwat cara `fetch_xor` dening maringaken [`Ordering::Relaxed`] minangka `order`.
    /// Contone, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bukaan karo nilai saiki nggunakake comparison mlebu.
    ///
    /// Versi owah saka intrinsik iki kasedhiya ing [`atomic`] mlebu ongko jinis liwat cara `fetch_max` dening maringaken [`Ordering::SeqCst`] minangka `order`.
    /// Contone, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bukaan karo nilai saiki nggunakake comparison mlebu.
    ///
    /// Versi stabil intrinsik iki kasedhiya ing jinis integer [`atomic`] sing mlebu liwat metode `fetch_max` kanthi ngliwati [`Ordering::Acquire`] dadi `order`.
    /// Contone, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bukaan karo nilai saiki nggunakake comparison mlebu.
    ///
    /// Versi owah saka intrinsik iki kasedhiya ing [`atomic`] mlebu ongko jinis liwat cara `fetch_max` dening maringaken [`Ordering::Release`] minangka `order`.
    /// Contone, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bukaan karo nilai saiki nggunakake comparison mlebu.
    ///
    /// Versi stabil intrinsik iki kasedhiya ing jinis integer [`atomic`] sing mlebu liwat metode `fetch_max` kanthi ngliwati [`Ordering::AcqRel`] dadi `order`.
    /// Contone, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maksimum kanthi nilai saiki.
    ///
    /// Versi owah saka intrinsik iki kasedhiya ing [`atomic`] mlebu ongko jinis liwat cara `fetch_max` dening maringaken [`Ordering::Relaxed`] minangka `order`.
    /// Contone, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Minimal karo nilai saiki nggunakake comparison mlebu.
    ///
    /// Versi owah saka intrinsik iki kasedhiya ing [`atomic`] mlebu ongko jinis liwat cara `fetch_min` dening maringaken [`Ordering::SeqCst`] minangka `order`.
    /// Contone, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimal karo nilai saiki nggunakake comparison mlebu.
    ///
    /// Versi owah saka intrinsik iki kasedhiya ing [`atomic`] mlebu ongko jinis liwat cara `fetch_min` dening maringaken [`Ordering::Acquire`] minangka `order`.
    /// Contone, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimal karo nilai saiki nggunakake comparison mlebu.
    ///
    /// Versi owah saka intrinsik iki kasedhiya ing [`atomic`] mlebu ongko jinis liwat cara `fetch_min` dening maringaken [`Ordering::Release`] minangka `order`.
    /// Contone, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimal karo nilai saiki nggunakake comparison mlebu.
    ///
    /// Versi owah saka intrinsik iki kasedhiya ing [`atomic`] mlebu ongko jinis liwat cara `fetch_min` dening maringaken [`Ordering::AcqRel`] minangka `order`.
    /// Contone, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimal karo nilai saiki nggunakake comparison mlebu.
    ///
    /// Versi stabil intrinsik iki kasedhiya ing jinis ongko [`atomic`] sing ditandatangani liwat metode `fetch_min` kanthi ngliwati [`Ordering::Relaxed`] dadi `order`.
    /// Contone, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Minimal kanthi nilai saiki nggunakake perbandingan sing ora ditandatangani.
    ///
    /// Versi owah saka intrinsik iki kasedhiya ing [`atomic`] jinis ongko gak peduli liwat cara `fetch_min` dening maringaken [`Ordering::SeqCst`] minangka `order`.
    /// Contone, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimal kanthi nilai saiki nggunakake perbandingan sing ora ditandatangani.
    ///
    /// Versi owah saka intrinsik iki kasedhiya ing [`atomic`] jinis ongko gak peduli liwat cara `fetch_min` dening maringaken [`Ordering::Acquire`] minangka `order`.
    /// Contone, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimal kanthi nilai saiki nggunakake perbandingan sing ora ditandatangani.
    ///
    /// Versi stabil intrinsik iki kasedhiya ing jinis bilangan bulat [`atomic`] sing ora ditandatangani liwat metode `fetch_min` kanthi ngliwati [`Ordering::Release`] dadi `order`.
    /// Contone, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimal kanthi nilai saiki nggunakake perbandingan sing ora ditandatangani.
    ///
    /// Versi owah saka intrinsik iki kasedhiya ing [`atomic`] jinis ongko gak peduli liwat cara `fetch_min` dening maringaken [`Ordering::AcqRel`] minangka `order`.
    /// Contone, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimal kanthi nilai saiki nggunakake perbandingan sing ora ditandatangani.
    ///
    /// Versi stabil intrinsik iki kasedhiya ing jinis bilangan bulat [`atomic`] sing ora ditandatangani liwat metode `fetch_min` kanthi ngliwati [`Ordering::Relaxed`] dadi `order`.
    /// Contone, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Maksimum kanthi nilai saiki nggunakake perbandingan sing ora ditandatangani.
    ///
    /// Versi owah saka intrinsik iki kasedhiya ing [`atomic`] jinis ongko gak peduli liwat cara `fetch_max` dening maringaken [`Ordering::SeqCst`] minangka `order`.
    /// Contone, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maksimum kanthi nilai saiki nggunakake perbandingan sing ora ditandatangani.
    ///
    /// Versi stabil intrinsik iki kasedhiya ing jinis bilangan bulat [`atomic`] sing ora ditandatangani liwat metode `fetch_max` kanthi ngliwati [`Ordering::Acquire`] dadi `order`.
    /// Contone, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maksimum kanthi nilai saiki nggunakake perbandingan sing ora ditandatangani.
    ///
    /// Versi owah saka intrinsik iki kasedhiya ing [`atomic`] jinis ongko gak peduli liwat cara `fetch_max` dening maringaken [`Ordering::Release`] minangka `order`.
    /// Contone, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maksimum kanthi nilai saiki nggunakake perbandingan sing ora ditandatangani.
    ///
    /// Versi stabil intrinsik iki kasedhiya ing jinis bilangan bulat [`atomic`] sing ora ditandatangani liwat metode `fetch_max` kanthi ngliwati [`Ordering::AcqRel`] dadi `order`.
    /// Contone, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maksimum kanthi nilai saiki nggunakake perbandingan sing ora ditandatangani.
    ///
    /// Versi stabil intrinsik iki kasedhiya ing jinis bilangan bulat [`atomic`] sing ora ditandatangani liwat metode `fetch_max` kanthi ngliwati [`Ordering::Relaxed`] dadi `order`.
    /// Contone, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// The `prefetch` kasirat Petunjuk menyang generator kode masang instruction prefetch yen didhukung;digunakake, iku ora-op.
    /// Prefetches duwe pengaruh ana ing prilaku program nanging bisa ngganti ciri kinerja.
    ///
    /// The `locality` pitakonan kudu dadi ongko pancet lan lokalitas specifier Temporal kiro-kiro saka (0), ora lokalitas, kanggo (3), arang banget tetep lokal ing cache.
    ///
    ///
    /// Intrinsik iki ora duwe pasangan sing stabil.
    ///
    ///
    pub fn prefetch_read_data<T>(data: *const T, locality: i32);
    /// The `prefetch` kasirat Petunjuk menyang generator kode masang instruction prefetch yen didhukung;digunakake, iku ora-op.
    /// Prefetches duwe pengaruh ana ing prilaku program nanging bisa ngganti ciri kinerja.
    ///
    /// The `locality` pitakonan kudu dadi ongko pancet lan lokalitas specifier Temporal kiro-kiro saka (0), ora lokalitas, kanggo (3), arang banget tetep lokal ing cache.
    ///
    ///
    /// Intrinsik iki ora duwe pasangan sing stabil.
    ///
    ///
    pub fn prefetch_write_data<T>(data: *const T, locality: i32);
    /// The `prefetch` kasirat Petunjuk menyang generator kode masang instruction prefetch yen didhukung;digunakake, iku ora-op.
    /// Prefetches duwe pengaruh ana ing prilaku program nanging bisa ngganti ciri kinerja.
    ///
    /// The `locality` pitakonan kudu dadi ongko pancet lan lokalitas specifier Temporal kiro-kiro saka (0), ora lokalitas, kanggo (3), arang banget tetep lokal ing cache.
    ///
    ///
    /// Intrinsik iki ora duwe pasangan sing stabil.
    ///
    ///
    pub fn prefetch_read_instruction<T>(data: *const T, locality: i32);
    /// The `prefetch` kasirat Petunjuk menyang generator kode masang instruction prefetch yen didhukung;digunakake, iku ora-op.
    /// Prefetches duwe pengaruh ana ing prilaku program nanging bisa ngganti ciri kinerja.
    ///
    /// The `locality` pitakonan kudu dadi ongko pancet lan lokalitas specifier Temporal kiro-kiro saka (0), ora lokalitas, kanggo (3), arang banget tetep lokal ing cache.
    ///
    ///
    /// Intrinsik iki ora duwe pasangan sing stabil.
    ///
    ///
    pub fn prefetch_write_instruction<T>(data: *const T, locality: i32);
}

extern "rust-intrinsic" {
    /// Pager atom.
    ///
    /// Versi owah saka intrinsik iki sumadhiya nèng [`atomic::fence`] dening maringaken [`Ordering::SeqCst`] minangka `order`.
    ///
    ///
    pub fn atomic_fence();
    /// Pager atom.
    ///
    /// Versi stabil intrinsik iki kasedhiya ing [`atomic::fence`] kanthi ngliwati [`Ordering::Acquire`] dadi `order`.
    ///
    ///
    pub fn atomic_fence_acq();
    /// Pager atom.
    ///
    /// Versi stabil intrinsik iki kasedhiya ing [`atomic::fence`] kanthi ngliwati [`Ordering::Release`] dadi `order`.
    ///
    ///
    pub fn atomic_fence_rel();
    /// Pager atom.
    ///
    /// Versi stabil intrinsik iki kasedhiya ing [`atomic::fence`] kanthi ngliwati [`Ordering::AcqRel`] dadi `order`.
    ///
    ///
    pub fn atomic_fence_acqrel();

    /// Alangi memori mung compiler.
    ///
    /// accesses memori ora bakal reordered tengen alangi dening compiler, nanging ora instruksi bakal cemlorot iku.
    /// Iki cocog kanggo operasi ing utas sing padha sing bisa diprayogakake, kayata nalika sesambungan karo pawang sinyal.
    ///
    /// Versi stabil intrinsik iki kasedhiya ing [`atomic::compiler_fence`] kanthi ngliwati [`Ordering::SeqCst`] dadi `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence();
    /// Alangi memori mung compiler.
    ///
    /// accesses memori ora bakal reordered tengen alangi dening compiler, nanging ora instruksi bakal cemlorot iku.
    /// Iki cocog kanggo operasi ing utas sing padha sing bisa diprayogakake, kayata nalika sesambungan karo pawang sinyal.
    ///
    /// Versi owah saka intrinsik iki sumadhiya nèng [`atomic::compiler_fence`] dening maringaken [`Ordering::Acquire`] minangka `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acq();
    /// Alangi memori mung compiler.
    ///
    /// accesses memori ora bakal reordered tengen alangi dening compiler, nanging ora instruksi bakal cemlorot iku.
    /// Iki cocog kanggo operasi ing utas sing padha sing bisa diprayogakake, kayata nalika sesambungan karo pawang sinyal.
    ///
    /// Versi stabil intrinsik iki kasedhiya ing [`atomic::compiler_fence`] kanthi ngliwati [`Ordering::Release`] dadi `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_rel();
    /// Alangi memori mung compiler.
    ///
    /// accesses memori ora bakal reordered tengen alangi dening compiler, nanging ora instruksi bakal cemlorot iku.
    /// Iki cocog kanggo operasi ing utas sing padha sing bisa diprayogakake, kayata nalika sesambungan karo pawang sinyal.
    ///
    /// Versi owah saka intrinsik iki sumadhiya nèng [`atomic::compiler_fence`] dening maringaken [`Ordering::AcqRel`] minangka `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acqrel();

    /// kasirat Magic sing asalé tegesé saka kawicaksanan ditempelake fungsi.
    ///
    /// Contone, aliran data nggunakake iki kanggo nyuntikake pratelan statis saengga `rustc_peek(potentially_uninitialized)` sejatine bakal mriksa kaping pindho yen aliran data pancen ngetung manawa ora diinputialisasi nalika aliran kontrol.
    ///
    ///
    /// Intrinsik iki ora digunakake ing njaba kompilator.
    ///
    ///
    ///
    pub fn rustc_peek<T>(_: T) -> T;

    /// Aborts tumapake proses.
    ///
    /// Versi operasi sing luwih ramah pangguna lan stabil yaiku [`std::process::abort`](../../std/process/fn.abort.html).
    ///
    pub fn abort() -> !;

    /// Informs ing Pangoptimal sing titik iki ing kode ora reachable, mbisakake optimizations luwih.
    ///
    /// NB, iki beda banget karo makro `unreachable!()`: Ora kaya makro, sing panics nalika dieksekusi, prilaku *ora ditemtokake* kanggo nggayuh kode sing ditandhani karo fungsi iki.
    ///
    ///
    /// Versi owah saka intrinsik iki [`core::hint::unreachable_unchecked`](crate::hint::unreachable_unchecked).
    ///
    ///
    #[rustc_const_unstable(feature = "const_unreachable_unchecked", issue = "53188")]
    pub fn unreachable() -> !;

    /// Ngandhani pangoptimal manawa sawijining kahanan mesthi wae bener.
    /// Yen kondhisi kasebut salah, tumindak kasebut ora bisa ditemtokake.
    ///
    /// Ora kode kui kanggo kasirat iki, nanging Pangoptimal bakal nyoba kanggo ngreksa iku (lan kondisi sawijining) antarane liwat, kang bisa ngganggu Optimization saka kode lingkungan lan ngurangi kinerja.
    /// Sampeyan ngirim ora digunakake yen podho bisa ditemokaké déning Pangoptimal ing dhewe, utawa yen ora ngaktifake sembarang optimizations wujud.
    ///
    /// Intrinsik iki ora duwe pasangan sing stabil.
    ///
    ///
    ///
    #[rustc_const_unstable(feature = "const_assume", issue = "76972")]
    pub fn assume(b: bool);

    /// Petunjuk kanggo kompiler sing kondhisi branch bisa uga bener.
    /// Ngasilake Nilai liwati kanggo iku.
    ///
    /// Panggunaan liyane saka perkawis `if` mbokmenawa ora duwe efek.
    ///
    /// Intrinsik iki ora duwe pasangan sing stabil.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn likely(b: bool) -> bool;

    /// Diwenehi kanggo kompilasi sing kondisi branch Koyone dadi palsu.
    /// Ngasilake Nilai liwati kanggo iku.
    ///
    /// Panggunaan liyane saka perkawis `if` mbokmenawa ora duwe efek.
    ///
    /// Intrinsik iki ora duwe pasangan sing stabil.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn unlikely(b: bool) -> bool;

    /// Wis kaleksanan sworo cangkem breakpoint, kanggo pengawasan dening debugger a.
    ///
    /// Intrinsik iki ora duwe pasangan sing stabil.
    pub fn breakpoint();

    /// Ukuran jinis ing bait.
    ///
    /// Sing luwih khusus, iki minangka offset byte ing antarane item sing padha kanthi jinis sing padha, kalebu padding alignment.
    ///
    ///
    /// Versi stabil intrinsik iki yaiku [`core::mem::size_of`](crate::mem::size_of).
    #[rustc_const_stable(feature = "const_size_of", since = "1.40.0")]
    pub fn size_of<T>() -> usize;

    /// Alignment minimal jinis.
    ///
    /// Versi owah saka intrinsik iki [`core::mem::align_of`](crate::mem::align_of).
    #[rustc_const_stable(feature = "const_min_align_of", since = "1.40.0")]
    pub fn min_align_of<T>() -> usize;
    /// Alignment sing disenengi kanggo jinis.
    ///
    /// Intrinsik iki ora duwe pasangan sing stabil.
    #[rustc_const_unstable(feature = "const_pref_align_of", issue = "none")]
    pub fn pref_align_of<T>() -> usize;

    /// Ukuran nilai referensi ing bait.
    ///
    /// Versi owah saka intrinsik iki [`mem::size_of_val`].
    #[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
    pub fn size_of_val<T: ?Sized>(_: *const T) -> usize;
    /// alignment sing dibutuhake saka cahya referensi.
    ///
    /// Versi owah saka intrinsik iki [`core::mem::align_of_val`](crate::mem::align_of_val).
    #[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
    pub fn min_align_of_val<T: ?Sized>(_: *const T) -> usize;

    /// Nemu senar irisan statis ngemot jeneng jinis.
    ///
    /// Versi stabil intrinsik iki yaiku [`core::any::type_name`](crate::any::type_name).
    #[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
    pub fn type_name<T: ?Sized>() -> &'static str;

    /// Nemu pengenal kang global unik kanggo jinis kasebut.
    /// Fungsi iki bakal ngasilake Nilai padha kanggo jinis preduli saka whichever crate iku kasebut ing.
    ///
    ///
    /// Versi stabil intrinsik iki yaiku [`core::any::TypeId::of`](crate::any::TypeId::of).
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub fn type_id<T: ?Sized + 'static>() -> u64;

    /// Pengawal kanggo fungsi sing ora aman sing ora bisa dieksekusi yen `T` ora dipanggoni:
    /// Iki bakal statis panic, utawa ora nindakake apa-apa.
    ///
    /// Intrinsik iki ora duwe pasangan sing stabil.
    #[rustc_const_unstable(feature = "const_assert_type", issue = "none")]
    pub fn assert_inhabited<T>();

    /// A njaga kanggo fungsi aman sing ora bisa tau kaleksanan yen `T` ora ngidini nul-initialization: Iki statically salah siji bakal panic, utawa nindakake apa-apa.
    ///
    ///
    /// Intrinsik iki ora duwe pasangan sing stabil.
    pub fn assert_zero_valid<T>();

    /// A njaga kanggo fungsi aman sing ora bisa tau kaleksanan yen `T` wis pola dicokot bener: Iki statically salah siji bakal panic, utawa nindakake apa-apa.
    ///
    ///
    /// Intrinsik iki ora duwe pasangan sing stabil.
    pub fn assert_uninit_valid<T>();

    /// Nemu referensi menyang statis `Location` nuduhake ngendi iki disebut.
    ///
    /// Nganggo [`core::panic::Location::caller`](crate::panic::Location::caller) tinimbang.
    #[rustc_const_unstable(feature = "const_caller_location", issue = "76156")]
    pub fn caller_location() -> &'static crate::panic::Location<'static>;

    /// Ngalih angka ing ruang lingkup tanpa nganggo lem drop.
    ///
    /// Iki ana namung kanggo [`mem::forget_unsized`];`forget` normal nggunakake `ManuallyDrop`.
    ///
    #[rustc_const_unstable(feature = "const_intrinsic_forget", issue = "none")]
    pub fn forget<T: ?Sized>(_: T);

    /// Jelasake regane siji jinis karo jinis liyane.
    ///
    /// Kaloro jinis kasebut kudu duwe ukuran sing padha.
    /// Ora asli, utawa asile, bisa uga [invalid value](../../nomicon/what-unsafe-does.html).
    ///
    /// `transmute` iku redaksional padha pamindhahan bitwise saka siji jinis menyang basa liyane.Iku salinan bit saka nilai sumber menyang Nilai panggonan, banjur lali asli.
    /// Iki padha karo C's `memcpy` ing hood, kaya `transmute_copy`.
    ///
    /// Amarga `transmute` minangka operasi miturut nilai, penyelarasan saka *nilai sing ditransmisikan dhewe* ora dadi masalah.
    /// Kaya dene fungsi liyane, panyusun wis mesthekake yen `T` lan `U` didadekake siji kanthi bener.
    /// Nanging, nalika transmuting angka sing *titik liya*(kayata penunjuk, referensi, kothak ...), panelpon wis mesthekake Alignment tepat saka angka nuding-kanggo.
    ///
    /// `transmute` iku **luar biasa** aman.Ana macem-macem cara kanggo nyebabake [undefined behavior][ub] kanthi fungsi iki.`transmute` kudu Absolute Resor pungkasan.
    ///
    /// [nomicon](../../nomicon/transmutes.html) duwe dokumentasi tambahan.
    ///
    /// [ub]: ../../reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// Ana sawetara bab sing `transmute` punika saestu migunani kanggo.
    ///
    /// Ngowahi pitunjuk dadi pitunjuk fungsi.Iki *ora tau* hotspot kanggo mesin ngendi penunjuk fungsi lan data penunjuk duwe macem-macem ukuran.
    ///
    /// ```
    /// fn foo() -> i32 {
    ///     0
    /// }
    /// let pointer = foo as *const ();
    /// let function = unsafe {
    ///     std::mem::transmute::<*const (), fn() -> i32>(pointer)
    /// };
    /// assert_eq!(function(), 0);
    /// ```
    ///
    /// Ndhuwur umur, utawa nyuda umur sing ora tetep.Iki majeng, banget aman Rust!
    ///
    /// ```
    /// struct R<'a>(&'a i32);
    /// unsafe fn extend_lifetime<'b>(r: R<'b>) -> R<'static> {
    ///     std::mem::transmute::<R<'b>, R<'static>>(r)
    /// }
    ///
    /// unsafe fn shorten_invariant_lifetime<'b, 'c>(r: &'b mut R<'static>)
    ///                                              -> &'b mut R<'c> {
    ///     std::mem::transmute::<&'b mut R<'static>, &'b mut R<'c>>(r)
    /// }
    /// ```
    ///
    /// # Alternatives
    ///
    /// Aja putus asa: akeh panggunaan `transmute` bisa ditindakake kanthi cara liya.
    /// Ngisor aplikasi umum `transmute` kang bisa diganti karo konstruksi luwih aman.
    ///
    /// Nguripake bytes(`&[u8]`) mentah dadi `u32`, `f64`, lsp:
    ///
    /// ```
    /// let raw_bytes = [0x78, 0x56, 0x34, 0x12];
    ///
    /// let num = unsafe {
    ///     std::mem::transmute::<[u8; 4], u32>(raw_bytes)
    /// };
    ///
    /// // nggunakake `u32::from_ne_bytes` tinimbang
    /// let num = u32::from_ne_bytes(raw_bytes);
    /// // utawa nggunakake `u32::from_le_bytes` utawa `u32::from_be_bytes` kanggo nemtokake endianness ing
    /// let num = u32::from_le_bytes(raw_bytes);
    /// assert_eq!(num, 0x12345678);
    /// let num = u32::from_be_bytes(raw_bytes);
    /// assert_eq!(num, 0x78563412);
    /// ```
    ///
    /// Ngowahi pitunjuk menyang `usize`:
    ///
    /// ```
    /// let ptr = &0;
    /// let ptr_num_transmute = unsafe {
    ///     std::mem::transmute::<&i32, usize>(ptr)
    /// };
    ///
    /// // Gunakake pemeran `as`
    /// let ptr_num_cast = ptr as *const i32 as usize;
    /// ```
    ///
    /// Ngowahi `*mut T` menyang `&mut T`:
    ///
    /// ```
    /// let ptr: *mut i32 = &mut 0;
    /// let ref_transmuted = unsafe {
    ///     std::mem::transmute::<*mut i32, &mut i32>(ptr)
    /// };
    ///
    /// // Gunakake balesan maneh
    /// let ref_casted = unsafe { &mut *ptr };
    /// ```
    ///
    /// Ngowahi `&mut T` dadi `&mut U`:
    ///
    /// ```
    /// let ptr = &mut 0;
    /// let val_transmuted = unsafe {
    ///     std::mem::transmute::<&mut i32, &mut u32>(ptr)
    /// };
    ///
    /// // Saiki, sijine bebarengan `as` lan reborrowing, Wigati chaining saka `as` `as` ora transitive
    /////
    /// let val_casts = unsafe { &mut *(ptr as *mut i32 as *mut u32) };
    /// ```
    ///
    /// Nguripake lan `&str` menyang `&[u8]`:
    ///
    /// ```
    /// // iki dudu cara sing apik kanggo nindakake iki.
    /// let slice = unsafe { std::mem::transmute::<&str, &[u8]>("Rust") };
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // Sampeyan bisa nggunakake `str::as_bytes`
    /// let slice = "Rust".as_bytes();
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // Utawa, mung nggunakake bait senar, yen sampeyan duwe kontrol liwat harfiah senar
    /////
    /// assert_eq!(b"Rust", &[82, 117, 115, 116]);
    /// ```
    ///
    /// Ngowahi `Vec<&T>` menyang `Vec<Option<&T>>`.
    ///
    /// Kanggo transmute jinis utama saka isi sing, sampeyan kudu nggawe manawa kanggo ora nglanggar samubarang invariants sing kang.
    /// Kanggo `Vec`, tegese yen ukuran *lan Alignment* saka jinis utama kudu cocog.
    /// Wadhah liyane bisa uga gumantung karo ukuran, jajaran, utawa uga `TypeId`, yen transmisi ora bakal bisa dilakoni tanpa nglanggar invariants kontainer.
    ///
    ///
    /// ```
    /// let store = [0, 1, 2, 3];
    /// let v_orig = store.iter().collect::<Vec<&i32>>();
    ///
    /// // Klone vector amarga bakal digunakake maneh mengko
    /// let v_clone = v_orig.clone();
    ///
    /// // Nggunakake transmute: iki gumantung ing tata letak data unspecified saka `Vec`, kang idea ala lan bisa nimbulaké Undefined Behavior.
    /////
    /// // Nanging, ora ana salinan.
    /// let v_transmuted = unsafe {
    ///     std::mem::transmute::<Vec<&i32>, Vec<Option<&i32>>>(v_clone)
    /// };
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // Iki disaranake, cara aman.
    /// // Nanging, nyalin kabeh vector, dadi larik anyar.
    /// let v_collected = v_clone.into_iter()
    ///                          .map(Some)
    ///                          .collect::<Vec<Option<&i32>>>();
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // Iki sing tepat ora-copy, cara aman saka "transmuting" a `Vec`, tanpa gumantung ing tata letak data.
    /// // Tinimbang secara harfiah nelpon `transmute`, kita nindakake Cast pitunjuk, nanging ing syarat-syarat nindakake jinis utama asli (`&i32`) menyang siji anyar (`Option<&i32>`), iki wis kabeh caveats padha.
    /////
    /// // Kejabi informasi sing disedhiyakake ing ndhuwur, uga konsultasi dokumentasi [`from_raw_parts`].
    /////
    /// let v_from_raw = unsafe {
    ///     // FIXME Anyari iki nalika vektor_into_raw_parts wis stabil.
    ///     // Njamin asli vector ora dropped.
    ///     let mut v_clone = std::mem::ManuallyDrop::new(v_clone);
    ///     Vec::from_raw_parts(v_clone.as_mut_ptr() as *mut Option<&i32>,
    ///                         v_clone.len(),
    ///                         v_clone.capacity())
    /// };
    /// ```
    ///
    /// [`from_raw_parts`]: ../../std/vec/struct.Vec.html#method.from_raw_parts
    ///
    /// Penerapan `split_at_mut`:
    ///
    /// ```
    /// use std::{slice, mem};
    ///
    /// // Ana macem-macem cara kanggo nindakake iki, lan ana macem-macem masalah kanthi cara (transmute) ing ngisor iki.
    /////
    /// fn split_at_mut_transmute<T>(slice: &mut [T], mid: usize)
    ///                              -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = mem::transmute::<&mut [T], &mut [T]>(slice);
    ///         // pisanan: transmute ora ngetik aman;kabeh sing dipriksa yaiku T lan
    ///         // U ukurane padha.
    ///         // Kapindho, ing kene, sampeyan duwe rong referensi sing bisa diowahi kanggo memori sing padha.
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // Iki bakal nyisihaken saka masalah tipe safety;`&mut *` bakal* mung *menehi `&mut T` saka `&mut T` utawa `* mut T`.
    /////
    /// fn split_at_mut_casts<T>(slice: &mut [T], mid: usize)
    ///                          -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = &mut *(slice as *mut [T]);
    ///         // Nanging, sampeyan isih duwe rong referensi sing bisa diowahi kanggo memori sing padha.
    /////
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // Iki carane perpustakaan standar ora.
    /// // Iki cara sing paling apik, yen sampeyan kudu nindakake perkara kaya iki
    /// fn split_at_stdlib<T>(slice: &mut [T], mid: usize)
    ///                       -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let ptr = slice.as_mut_ptr();
    ///         // Iki saiki wis telung referensi mutable pointing ing memori padha.`slice`, ing rvalue ret.0, lan rvalue ret.1.
    ///         // `slice` wis tau digunakaké `let ptr = ...`, lan dadi siji bisa nambani minangka "dead", lan mulane, namung wonten kalih irisan-irisan mutable nyata.
    /////
    /////
    /////
    ///         (slice::from_raw_parts_mut(ptr, mid),
    ///          slice::from_raw_parts_mut(ptr.add(mid), len - mid))
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    // NOTE: Nalika nggawe intrinsik tetep stabil, kita duwe sawetara kode khusus ing fn fn
    // kir sing nyegah panggunaan ing `const fn`.
    #[rustc_const_stable(feature = "const_transmute", since = "1.46.0")]
    #[rustc_diagnostic_item = "transmute"]
    pub fn transmute<T, U>(e: T) -> U;

    /// Ngasilake `true` yen jinis nyata sing diwenehake `T` mbutuhake lem drop;ngasilake `false` yen jinis nyata kasedhiya kanggo `T` nindakake `Copy`.
    ///
    ///
    /// Yen jinis nyata sanadyan mbutuhake gulung lim utawa nindakake `Copy`, banjur Nilai bali saka fungsi iki unspecified.
    ///
    /// Versi stabil intrinsik iki yaiku [`mem::needs_drop`](crate::mem::needs_drop).
    ///
    ///
    #[rustc_const_stable(feature = "const_needs_drop", since = "1.40.0")]
    pub fn needs_drop<T>() -> bool;

    /// Ngetung nutup kerugian saka pitunjuk.
    ///
    /// Iki dipun ginakaken minangka kasirat supaya nindakake kanggo lan saka ongko, wiwit konversi bakal mbuwangi aliasing informasi.
    ///
    /// # Safety
    ///
    /// Loro-lorone ing miwiti lan asil pitunjuk kudu salah siji ing wates utawa siji bait sasi pungkasan obyek diparengake.
    /// Yen salah sawijining pointer ora ana wates utawa kebanjiran aritmetika, mula ana panggunaan maneh nilai bali sing bakal nyebabake tumindak sing durung mesthi.
    ///
    ///
    /// Versi owah saka intrinsik iki [`pointer::offset`].
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn offset<T>(dst: *const T, offset: isize) -> *const T;

    /// Ngetung nutup kerugian saka pitunjuk, bisa uga dibungkus.
    ///
    /// Iki dipun ginakaken minangka kasirat supaya nindakake kanggo lan saka ongko, wiwit konversi nyegah optimizations tartamtu.
    ///
    /// # Safety
    ///
    /// Boten kados ing kasirat `offset`, intrinsik iki ora matesi pitunjuk asil kanggo titik menyang utawa siji bait sasi pungkasan obyek diparengake, lan nggabung karo loro kang aritmetika ngompliti.
    /// Nilai sing diasilake ora mesthi valid kanggo digunakake kanggo ngakses memori kanthi bener.
    ///
    /// Versi owah saka intrinsik iki [`pointer::wrapping_offset`].
    ///
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn arith_offset<T>(dst: *const T, offset: isize) -> *const T;

    /// Padha karo cocok `llvm.memcpy.p0i8.0i8.*` kasirat, kanthi ukuran `count`*`size_of::<T>()` lan Alignment saka
    ///
    /// `min_align_of::<T>()`
    ///
    /// Parameter molah malih disetel kanggo `true`, supaya ora bisa optimized metu kajaba ukuran padha karo nol.
    ///
    /// Intrinsik iki ora duwe pasangan sing stabil.
    ///
    pub fn volatile_copy_nonoverlapping_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// Padha karo cocok `llvm.memmove.p0i8.0i8.*` kasirat, kanthi ukuran `count* size_of::<T>()` lan Alignment saka
    ///
    /// `min_align_of::<T>()`
    ///
    /// Parameter molah malih disetel kanggo `true`, supaya ora bisa optimized metu kajaba ukuran padha karo nol.
    ///
    /// Intrinsik iki ora duwe pasangan sing stabil.
    ///
    pub fn volatile_copy_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// Podo karo intrinsik `llvm.memset.p0i8.*` sing pas, kanthi ukuran `count* size_of::<T>()` lan alignment `min_align_of::<T>()`.
    ///
    ///
    /// Parameter molah malih disetel kanggo `true`, supaya ora bisa optimized metu kajaba ukuran padha karo nol.
    ///
    /// Intrinsik iki ora duwe pasangan sing stabil.
    ///
    ///
    pub fn volatile_set_memory<T>(dst: *mut T, val: u8, count: usize);

    /// Nindakake momen sing molah malih saka pointer `src`.
    ///
    /// Versi stabil intrinsik iki yaiku [`core::ptr::read_volatile`](crate::ptr::read_volatile).
    pub fn volatile_load<T>(src: *const T) -> T;
    /// Performs nyimpen molah malih ing pitunjuk `dst`.
    ///
    /// Versi owah saka intrinsik iki [`core::ptr::write_volatile`](crate::ptr::write_volatile).
    pub fn volatile_store<T>(dst: *mut T, val: T);

    /// Performs mbukak molah malih saka pitunjuk `src` pitunjuk iki ora dibutuhaké kanggo sekuthon.
    ///
    ///
    /// Intrinsik iki ora duwe pasangan sing stabil.
    pub fn unaligned_volatile_load<T>(src: *const T) -> T;
    /// Performs nyimpen molah malih ing pitunjuk `dst`.
    /// pointer iki ora dibutuhaké kanggo didadekake siji.
    ///
    /// Intrinsik iki ora duwe pasangan sing stabil.
    pub fn unaligned_volatile_store<T>(dst: *mut T, val: T);

    /// Ngasilake root square `f32`
    ///
    /// Versi owah saka intrinsik iki
    /// [`f32::sqrt`](../../std/primitive.f32.html#method.sqrt)
    pub fn sqrtf32(x: f32) -> f32;
    /// Ngasilake ROOT kothak saka `f64`
    ///
    /// Versi owah saka intrinsik iki
    /// [`f64::sqrt`](../../std/primitive.f64.html#method.sqrt)
    pub fn sqrtf64(x: f64) -> f64;

    /// Ngundakake lan `f32` menyang daya ongko.
    ///
    /// Versi owah saka intrinsik iki
    /// [`f32::powi`](../../std/primitive.f32.html#method.powi)
    pub fn powif32(a: f32, x: i32) -> f32;
    /// Ngundakake lan `f64` menyang daya ongko.
    ///
    /// Versi owah saka intrinsik iki
    /// [`f64::powi`](../../std/primitive.f64.html#method.powi)
    pub fn powif64(a: f64, x: i32) -> f64;

    /// Ngasilake sine saka `f32`.
    ///
    /// Versi owah saka intrinsik iki
    /// [`f32::sin`](../../std/primitive.f32.html#method.sin)
    pub fn sinf32(x: f32) -> f32;
    /// Ngasilake sine saka `f64`.
    ///
    /// Versi owah saka intrinsik iki
    /// [`f64::sin`](../../std/primitive.f64.html#method.sin)
    pub fn sinf64(x: f64) -> f64;

    /// Ngasilake cosine `f32`.
    ///
    /// Versi owah saka intrinsik iki
    /// [`f32::cos`](../../std/primitive.f32.html#method.cos)
    pub fn cosf32(x: f32) -> f32;
    /// Ngasilake cosine saka `f64`.
    ///
    /// Versi owah saka intrinsik iki
    /// [`f64::cos`](../../std/primitive.f64.html#method.cos)
    pub fn cosf64(x: f64) -> f64;

    /// Ngundakake lan `f32` menyang daya `f32`.
    ///
    /// Versi owah saka intrinsik iki
    /// [`f32::powf`](../../std/primitive.f32.html#method.powf)
    pub fn powf32(a: f32, x: f32) -> f32;
    /// Ngundakake lan `f64` menyang daya `f64`.
    ///
    /// Versi owah saka intrinsik iki
    /// [`f64::powf`](../../std/primitive.f64.html#method.powf)
    pub fn powf64(a: f64, x: f64) -> f64;

    /// Ngasilake eksponensial `f32`.
    ///
    /// Versi owah saka intrinsik iki
    /// [`f32::exp`](../../std/primitive.f32.html#method.exp)
    pub fn expf32(x: f32) -> f32;
    /// Ngasilake èksponènsial lan `f64`.
    ///
    /// Versi owah saka intrinsik iki
    /// [`f64::exp`](../../std/primitive.f64.html#method.exp)
    pub fn expf64(x: f64) -> f64;

    /// Ngasilake 2 wungu kanggo daya saka `f32`.
    ///
    /// Versi owah saka intrinsik iki
    /// [`f32::exp2`](../../std/primitive.f32.html#method.exp2)
    pub fn exp2f32(x: f32) -> f32;
    /// Ngasilake 2 wungu kanggo daya saka `f64`.
    ///
    /// Versi owah saka intrinsik iki
    /// [`f64::exp2`](../../std/primitive.f64.html#method.exp2)
    pub fn exp2f64(x: f64) -> f64;

    /// Ngasilake logarithm alam saka `f32`.
    ///
    /// Versi owah saka intrinsik iki
    /// [`f32::ln`](../../std/primitive.f32.html#method.ln)
    pub fn logf32(x: f32) -> f32;
    /// Ngasilake logaritma alami `f64`.
    ///
    /// Versi owah saka intrinsik iki
    /// [`f64::ln`](../../std/primitive.f64.html#method.ln)
    pub fn logf64(x: f64) -> f64;

    /// Ngasilake basa 10 logarithm saka `f32`.
    ///
    /// Versi owah saka intrinsik iki
    /// [`f32::log10`](../../std/primitive.f32.html#method.log10)
    pub fn log10f32(x: f32) -> f32;
    /// Ngasilake logaritma 10 dhasar `f64`.
    ///
    /// Versi owah saka intrinsik iki
    /// [`f64::log10`](../../std/primitive.f64.html#method.log10)
    pub fn log10f64(x: f64) -> f64;

    /// Ngasilake basa 2 logarithm saka `f32`.
    ///
    /// Versi owah saka intrinsik iki
    /// [`f32::log2`](../../std/primitive.f32.html#method.log2)
    pub fn log2f32(x: f32) -> f32;
    /// Ngasilake basa 2 logarithm saka `f64`.
    ///
    /// Versi owah saka intrinsik iki
    /// [`f64::log2`](../../std/primitive.f64.html#method.log2)
    pub fn log2f64(x: f64) -> f64;

    /// Ngasilake `a * b + c` kanggo nilai `f32`.
    ///
    /// Versi owah saka intrinsik iki
    /// [`f32::mul_add`](../../std/primitive.f32.html#method.mul_add)
    pub fn fmaf32(a: f32, b: f32, c: f32) -> f32;
    /// Ngasilake `a * b + c` kanggo nilai `f64`.
    ///
    /// Versi owah saka intrinsik iki
    /// [`f64::mul_add`](../../std/primitive.f64.html#method.mul_add)
    pub fn fmaf64(a: f64, b: f64, c: f64) -> f64;

    /// Ngasilake Nilai Absolute saka `f32`.
    ///
    /// Versi owah saka intrinsik iki
    /// [`f32::abs`](../../std/primitive.f32.html#method.abs)
    pub fn fabsf32(x: f32) -> f32;
    /// Ngasilake nilai absolut `f64`.
    ///
    /// Versi owah saka intrinsik iki
    /// [`f64::abs`](../../std/primitive.f64.html#method.abs)
    pub fn fabsf64(x: f64) -> f64;

    /// Ngasilake minimal rong angka `f32`.
    ///
    /// Versi owah saka intrinsik iki
    /// [`f32::min`]
    pub fn minnumf32(x: f32, y: f32) -> f32;
    /// Ngasilake minimal rong angka `f64`.
    ///
    /// Versi owah saka intrinsik iki
    /// [`f64::min`]
    pub fn minnumf64(x: f64, y: f64) -> f64;
    /// Ngasilake maksimal rong nilai `f32`.
    ///
    /// Versi owah saka intrinsik iki
    /// [`f32::max`]
    pub fn maxnumf32(x: f32, y: f32) -> f32;
    /// Ngasilake maksimal rong nilai `f64`.
    ///
    /// Versi owah saka intrinsik iki
    /// [`f64::max`]
    pub fn maxnumf64(x: f64, y: f64) -> f64;

    /// Nyalin tandha saka `y` dadi `x` kanggo nilai `f32`.
    ///
    /// Versi owah saka intrinsik iki
    /// [`f32::copysign`](../../std/primitive.f32.html#method.copysign)
    pub fn copysignf32(x: f32, y: f32) -> f32;
    /// Salinan tandha saka `y` kanggo `x` kanggo angka `f64`.
    ///
    /// Versi owah saka intrinsik iki
    /// [`f64::copysign`](../../std/primitive.f64.html#method.copysign)
    pub fn copysignf64(x: f64, y: f64) -> f64;

    /// Ngasilake ing ongko paling gedhé kurang saka utawa witjaksono menyang `f32`.
    ///
    /// Versi owah saka intrinsik iki
    /// [`f32::floor`](../../std/primitive.f32.html#method.floor)
    pub fn floorf32(x: f32) -> f32;
    /// Ngasilake bilangan bulat paling gedhe kurang saka utawa padha karo `f64`.
    ///
    /// Versi owah saka intrinsik iki
    /// [`f64::floor`](../../std/primitive.f64.html#method.floor)
    pub fn floorf64(x: f64) -> f64;

    /// Ngasilake luwih ongko cilik saka utawa witjaksono menyang `f32`.
    ///
    /// Versi owah saka intrinsik iki
    /// [`f32::ceil`](../../std/primitive.f32.html#method.ceil)
    pub fn ceilf32(x: f32) -> f32;
    /// Ngasilake bilangan bulat paling cilik sing luwih saka utawa padha karo `f64`.
    ///
    /// Versi owah saka intrinsik iki
    /// [`f64::ceil`](../../std/primitive.f64.html#method.ceil)
    pub fn ceilf64(x: f64) -> f64;

    /// Ngasilake bagean ongko ongko `f32`.
    ///
    /// Versi owah saka intrinsik iki
    /// [`f32::trunc`](../../std/primitive.f32.html#method.trunc)
    pub fn truncf32(x: f32) -> f32;
    /// Ngasilake bagean ongko ongko `f64`.
    ///
    /// Versi owah saka intrinsik iki
    /// [`f64::trunc`](../../std/primitive.f64.html#method.trunc)
    pub fn truncf64(x: f64) -> f64;

    /// Ngasilake ongko paling cedhak menyang `f32`.
    /// Bisa mundhakaken lan inexact ngambang-titik istiméwa yen pitakonan ora ongko.
    pub fn rintf32(x: f32) -> f32;
    /// Ngasilake nomer bulat paling cedhak menyang `f64`.
    /// Bisa mundhakaken lan inexact ngambang-titik istiméwa yen pitakonan ora ongko.
    pub fn rintf64(x: f64) -> f64;

    /// Ngasilake ongko paling cedhak menyang `f32`.
    ///
    /// Intrinsik iki ora duwe pasangan sing stabil.
    pub fn nearbyintf32(x: f32) -> f32;
    /// Ngasilake nomer bulat paling cedhak menyang `f64`.
    ///
    /// Intrinsik iki ora duwe pasangan sing stabil.
    pub fn nearbyintf64(x: f64) -> f64;

    /// Ngasilake ongko paling cedhak menyang `f32`.Babagan setengah cara adoh saka nol.
    ///
    /// Versi owah saka intrinsik iki
    /// [`f32::round`](../../std/primitive.f32.html#method.round)
    pub fn roundf32(x: f32) -> f32;
    /// Ngasilake ongko paling cedhak menyang `f64`.Babagan setengah cara adoh saka nol.
    ///
    /// Versi owah saka intrinsik iki
    /// [`f64::round`](../../std/primitive.f64.html#method.round)
    pub fn roundf64(x: f64) -> f64;

    /// Penambahan float sing ngidini optimisasi adhedhasar aturan aljabar.
    /// Bisa nganggep input wis winates.
    ///
    /// Intrinsik iki ora duwe pasangan sing stabil.
    pub fn fadd_fast<T: Copy>(a: T, b: T) -> T;

    /// Pangurangan float sing ngidini optimisasi adhedhasar aturan aljabar.
    /// Bisa nganggep input wis winates.
    ///
    /// Intrinsik iki ora duwe pasangan sing stabil.
    pub fn fsub_fast<T: Copy>(a: T, b: T) -> T;

    /// Ngawang pingan sing ngidini optimizations adhedhasar aljabar aturan.
    /// Bisa nganggep input wis winates.
    ///
    /// Intrinsik iki ora duwe pasangan sing stabil.
    pub fn fmul_fast<T: Copy>(a: T, b: T) -> T;

    /// Ngawang divisi sing ngidini optimizations adhedhasar aljabar aturan.
    /// Bisa nganggep input wis winates.
    ///
    /// Intrinsik iki ora duwe pasangan sing stabil.
    pub fn fdiv_fast<T: Copy>(a: T, b: T) -> T;

    /// Sisa Float sing ngidini optimisasi adhedhasar aturan aljabar.
    /// Bisa nganggep input wis winates.
    ///
    /// Intrinsik iki ora duwe pasangan sing stabil.
    pub fn frem_fast<T: Copy>(a: T, b: T) -> T;

    /// Ngonversi karo LLVM kang fptoui/fptosi, kang bisa bali undef kanggo angka metu saka sawetara
    /// (<https://github.com/rust-lang/rust/issues/10184>)
    ///
    /// Owah minangka [`f32::to_int_unchecked`] lan [`f64::to_int_unchecked`].
    pub fn float_to_int_unchecked<Float: Copy, Int: Copy>(value: Float) -> Int;

    /// Ngasilake nomer bit nyetel ing jinis ongko `T`
    ///
    /// Versi stabil intrinsik iki kasedhiya ing primitif integer liwat metode `count_ones`.
    /// Contone,
    /// [`u32::count_ones`]
    #[rustc_const_stable(feature = "const_ctpop", since = "1.40.0")]
    pub fn ctpop<T: Copy>(x: T) -> T;

    /// Ngasilake nomer bit unset anjog (zeroes) ing jinis ongko `T`.
    ///
    /// versi ing owah saka intrinsik iki kasedhiya ing primitives ongko liwat cara `leading_zeros`.
    /// Contone,
    /// [`u32::leading_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 3);
    /// ```
    ///
    /// `x` kanthi nilai `0` bakal ngasilake jembaré `T`.
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0u16;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 16);
    /// ```
    #[rustc_const_stable(feature = "const_ctlz", since = "1.40.0")]
    pub fn ctlz<T: Copy>(x: T) -> T;

    /// Kaya `ctlz`, nanging ekstra-aman minangka ngasilake `undef` nalika diwenehi `x` karo nilai `0`.
    ///
    ///
    /// Intrinsik iki ora duwe pasangan sing stabil.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz_nonzero;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = unsafe { ctlz_nonzero(x) };
    /// assert_eq!(num_leading, 3);
    /// ```
    #[rustc_const_stable(feature = "constctlz", since = "1.50.0")]
    pub fn ctlz_nonzero<T: Copy>(x: T) -> T;

    /// Ngasilake nomer bit sing ora disetel (zeroes) kanthi tipe integer `T`.
    ///
    /// Versi stabil intrinsik iki kasedhiya ing primitif integer liwat metode `trailing_zeros`.
    /// Contone,
    /// [`u32::trailing_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 3);
    /// ```
    ///
    /// Lan `x` karo nilai `0` bakal ngasilake jembaré dicokot saka `T`:
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0u16;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 16);
    /// ```
    #[rustc_const_stable(feature = "const_cttz", since = "1.40.0")]
    pub fn cttz<T: Copy>(x: T) -> T;

    /// Kaya `cttz`, nanging ora aman amarga ngasilake `undef` nalika diwenehi `x` kanthi nilai `0`.
    ///
    ///
    /// Intrinsik iki ora duwe pasangan sing stabil.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz_nonzero;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = unsafe { cttz_nonzero(x) };
    /// assert_eq!(num_trailing, 3);
    /// ```
    #[rustc_const_unstable(feature = "const_cttz", issue = "none")]
    pub fn cttz_nonzero<T: Copy>(x: T) -> T;

    /// Reverses bita ing jinis ongko `T`.
    ///
    /// Versi stabil intrinsik iki kasedhiya ing primitif integer liwat metode `swap_bytes`.
    /// Contone,
    /// [`u32::swap_bytes`]
    #[rustc_const_stable(feature = "const_bswap", since = "1.40.0")]
    pub fn bswap<T: Copy>(x: T) -> T;

    /// Reverses bit ing jinis ongko `T`.
    ///
    /// versi ing owah saka intrinsik iki kasedhiya ing primitives ongko liwat cara `reverse_bits`.
    /// Contone,
    /// [`u32::reverse_bits`]
    #[rustc_const_stable(feature = "const_bitreverse", since = "1.40.0")]
    pub fn bitreverse<T: Copy>(x: T) -> T;

    /// Singing dicenthang ongko Saliyane.
    ///
    /// versi ing owah saka intrinsik iki kasedhiya ing primitives ongko liwat cara `overflowing_add`.
    /// Contone,
    /// [`u32::overflowing_add`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn add_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Nindakake pangurangan ongko ongko dicenthang
    ///
    /// versi ing owah saka intrinsik iki kasedhiya ing primitives ongko liwat cara `overflowing_sub`.
    /// Contone,
    /// [`u32::overflowing_sub`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn sub_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Singing dicenthang ongko pingan
    ///
    /// versi ing owah saka intrinsik iki kasedhiya ing primitives ongko liwat cara `overflowing_mul`.
    /// Contone,
    /// [`u32::overflowing_mul`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn mul_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Performs pamérangan pas, asil ing prilaku undefined ngendi `x % y != 0` utawa `y == 0` utawa `x == T::MIN && y == -1`
    ///
    ///
    /// Intrinsik iki ora duwe pasangan sing stabil.
    pub fn exact_div<T: Copy>(x: T, y: T) -> T;

    /// Nindakake divisi sing ora dicenthang, nyebabake tumindak sing ora ditemtokake ing endi `y == 0` utawa `x == T::MIN && y == -1`
    ///
    ///
    /// wrappers aman kanggo kasirat iki kasedhiya ing primitives ongko liwat cara `checked_div`.
    /// Contone,
    /// [`u32::checked_div`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_div<T: Copy>(x: T, y: T) -> T;
    /// Ngasilake seko saka divisi dicenthang, asil ing prilaku undefined nalika `y == 0` utawa `x == T::MIN && y == -1`
    ///
    ///
    /// wrappers aman kanggo kasirat iki kasedhiya ing primitives ongko liwat cara `checked_rem`.
    /// Contone,
    /// [`u32::checked_rem`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_rem<T: Copy>(x: T, y: T) -> T;

    /// Nindakake shift kiwa sing ora dicenthang, nyebabake tumindak sing ora ditemtokake nalika `y < 0` utawa `y >= N`, ing endi N jembaré T ing bit.
    ///
    ///
    /// Bungkus aman kanggo intrinsik iki kasedhiya ing primitif integer liwat metode `checked_shl`.
    /// Contone,
    /// [`u32::checked_shl`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shl<T: Copy>(x: T, y: T) -> T;
    /// Performs lan shift tengen dicenthang, asil ing prilaku undefined nalika `y < 0` utawa `y >= N`, ngendi N punika wiyaripun T ing bit.
    ///
    ///
    /// Bungkus aman kanggo intrinsik iki kasedhiya ing primitif integer liwat metode `checked_shr`.
    /// Contone,
    /// [`u32::checked_shr`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shr<T: Copy>(x: T, y: T) -> T;

    /// Ngasilake asil tambahan sing ora dicenthang, nyebabake tumindak sing ora ditemtokake nalika `x + y > T::MAX` utawa `x + y < T::MIN`.
    ///
    ///
    /// Intrinsik iki ora duwe pasangan sing stabil.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_add<T: Copy>(x: T, y: T) -> T;

    /// Ngasilake asil pangurangan sing ora dicenthang, nyebabake tumindak sing ora ditemtokake nalika `x - y > T::MAX` utawa `x - y < T::MIN`.
    ///
    ///
    /// Intrinsik iki ora duwe pasangan sing stabil.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_sub<T: Copy>(x: T, y: T) -> T;

    /// Ngasilake asil saka ping dicenthang, asil ing prilaku undefined nalika `x *y > T::MAX` utawa `x* y < T::MIN`.
    ///
    ///
    /// Intrinsik iki ora duwe pasangan sing stabil.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_mul<T: Copy>(x: T, y: T) -> T;

    /// Nindakake muter kiwa.
    ///
    /// Versi stabil intrinsik iki kasedhiya ing primitif integer liwat metode `rotate_left`.
    /// Contone,
    /// [`u32::rotate_left`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_left<T: Copy>(x: T, y: T) -> T;

    /// Nindakake muter nengen.
    ///
    /// Versi stabil intrinsik iki kasedhiya ing primitif integer liwat metode `rotate_right`.
    /// Contone,
    /// [`u32::rotate_right`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_right<T: Copy>(x: T, y: T) -> T;

    /// Returns (a + b) mod 2 <sup>N,</sup> ngendi N punika wiyaripun T ing bit.
    ///
    /// Versi stabil intrinsik iki kasedhiya ing primitif integer liwat metode `wrapping_add`.
    /// Contone,
    /// [`u32::wrapping_add`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_add<T: Copy>(a: T, b: T) -> T;
    /// Ngasilake (a, b) mod 2 <sup>N</sup>, ing endi N ukurane T ing bit.
    ///
    /// versi ing owah saka intrinsik iki kasedhiya ing primitives ongko liwat cara `wrapping_sub`.
    /// Contone,
    /// [`u32::wrapping_sub`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_sub<T: Copy>(a: T, b: T) -> T;
    /// Bali (a * b) mod 2 <sup>N</sup>, ing endi N ukurane T ing bit.
    ///
    /// versi ing owah saka intrinsik iki kasedhiya ing primitives ongko liwat cara `wrapping_mul`.
    /// Contone,
    /// [`u32::wrapping_mul`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_mul<T: Copy>(a: T, b: T) -> T;

    /// Ngitung `a + b`, saturating ing wates numerik.
    ///
    /// versi ing owah saka intrinsik iki kasedhiya ing primitives ongko liwat cara `saturating_add`.
    /// Contone,
    /// [`u32::saturating_add`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_add<T: Copy>(a: T, b: T) -> T;
    /// Ngitung `a - b`, jenuh ing wates angka.
    ///
    /// versi ing owah saka intrinsik iki kasedhiya ing primitives ongko liwat cara `saturating_sub`.
    /// Contone,
    /// [`u32::saturating_sub`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_sub<T: Copy>(a: T, b: T) -> T;

    /// Ngasilake Nilai saka Diskriminan kanggo varian ing 'v';
    /// yen `T` ora Diskriminan, ngasilake `0`.
    ///
    /// Versi owah saka intrinsik iki [`core::mem::discriminant`](crate::mem::discriminant).
    #[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
    pub fn discriminant_value<T>(v: &T) -> <T as DiscriminantKind>::Discriminant;

    /// Ngasilake nomer Varian saka jinis `T` matak menyang `usize`;
    /// yen `T` ora duwe varian, ngasilake `0`.Varian pedunung bakal dietung.
    ///
    /// Versi kanggo-bakal-owah saka intrinsik iki [`mem::variant_count`].
    #[rustc_const_unstable(feature = "variant_count", issue = "73662")]
    pub fn variant_count<T>() -> usize;

    /// nbangun "try catch" Rust kang njejaluk fungsi pitunjuk `try_fn` karo pitunjuk data `data`.
    ///
    /// Ing pitakonan katelu sing fungsi diarani menawa panic ana.
    /// Fungsi iki njupuk pitunjuk data lan pitunjuk kanggo obyek istiméwa target-tartamtu sing kejiret.
    ///
    /// Kanggo informasi luwih lengkap, deleng sumber kompiler uga implementasi nyekel std.
    ///
    pub fn r#try(try_fn: fn(*mut u8), data: *mut u8, catch_fn: fn(*mut u8, *mut u8)) -> i32;

    /// Mancaraken toko `!nontemporal` miturut LLVM (ndeleng docs sing).
    /// Bisa uga ora bakal stabil.
    pub fn nontemporal_store<T>(ptr: *mut T, val: T);

    /// Waca dokumentasi `<*const T>::offset_from` gamblang.
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    pub fn ptr_offset_from<T>(ptr: *const T, base: *const T) -> isize;

    /// Waca dokumentasi `<*const T>::guaranteed_eq` gamblang.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_eq<T>(ptr: *const T, other: *const T) -> bool;

    /// Deleng dokumentasi `<*const T>::guaranteed_ne` kanggo rincian.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_ne<T>(ptr: *const T, other: *const T) -> bool;

    /// Nyedhiakke ing wektu ngripta.Apa ora bisa ditelpon nalika runtime.
    #[rustc_const_unstable(feature = "const_heap", issue = "79597")]
    pub fn const_allocate(size: usize, align: usize) -> *mut u8;
}

// Sawetara fungsi sing ditetepake kene amarga padha sengaja tak digawe kasedhiya ing modul iki ing stabil.
// Waca <https://github.com/rust-lang/rust/issues/15702>.
// (`transmute` uga bisa dideleng ing kategori iki, nanging ora bisa kebungkus amarga mriksa sing `T` lan `U` ukurane padha.)
//

/// Priksa manawa `ptr` didadekake siji sing cocog karo `align_of::<T>()`.
///
pub(crate) fn is_aligned_and_not_null<T>(ptr: *const T) -> bool {
    !ptr.is_null() && ptr as usize % mem::align_of::<T>() == 0
}

/// Nyalin byte `count *size_of::<T>()` saka `src` nganti `dst`.Sumber lan tujuan kudu* ora * tumpang tindih.
///
/// Kanggo wilayah memori sing bisa tumpang tindih, gunakake [`copy`].
///
/// `copy_nonoverlapping` iku redaksional padha C kang [`memcpy`], nanging karo urutan pitakonan swapped.
///
/// [`memcpy`]: https://en.cppreference.com/w/c/string/byte/memcpy
///
/// # Safety
///
/// Prilaku wis cetho yen kahanan ing ngisor iki sing nerak:
///
/// * `src` kudu [valid] kanggo maos saka `count * size_of::<T>()` bita.
///
/// * `dst` kudu [valid] kanggo nulis byte `count * size_of::<T>()`.
///
/// * Loro-lorone `src` lan `dst` kudu didadekake siji mlaku.
///
/// * Ing wilayah saka memori diwiwiti ing `src` karo ukuran: Count *
///   size_of: :<T>(): Bita kudu *ora tau* tumpang tindih karo wilayah saka memori diwiwiti ing `dst` karo ukuran padha.
///
/// Kaya [`read`], `copy_nonoverlapping` nggawe salinan bitwise saka `T`, preduli saka apa `T` punika [`Copy`].
/// Yen `T` ora [`Copy`], nggunakake *loro* angka ing wilayah wiwit ing `*src` lan wilayah wiwit ing `* dst` bisa [violate memory safety][read-ownership].
///
///
/// Elinga yen sanajan ukuran sing disalin kanthi efektif (`count * size_of: :<T>():) Iku `0`, penunjuk kudu non-NULL lan didadekake siji mlaku.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Kanthi manual ngleksanakake [`Vec::append`]:
///
/// ```
/// use std::ptr;
///
/// /// Gerakane kabeh unsur `src` menyang `dst`, ninggalake `src` kosong.
/// fn append<T>(dst: &mut Vec<T>, src: &mut Vec<T>) {
///     let src_len = src.len();
///     let dst_len = dst.len();
///
///     // Mesthekake yen `dst` duwe cukup kapasitas kanggo nahan kabeh `src`.
///     dst.reserve(src_len);
///
///     unsafe {
///         // Telpon kanggo nutup kerugian mesthi aman amarga `Vec` ora bakal nemtokake luwih saka `isize::MAX` byte.
/////
///         let dst_ptr = dst.as_mut_ptr().offset(dst_len as isize);
///         let src_ptr = src.as_ptr();
///
///         // Potong `src` tanpa ngeculake isine.
///         // We nindakake iki pisanan, kanggo masalah supaya ing kasus soko luwih mudhun panics.
///         src.set_len(0);
///
///         // Kaloro wilayah kasebut ora bisa tumpang tindih amarga referensi sing bisa diowahi ora alias, lan loro vectors sing beda ora bisa duwe memori sing padha.
/////
/////
///         ptr::copy_nonoverlapping(src_ptr, dst_ptr, src_len);
///
///         // Menawa pengiriman notifikasi `dst` sing saiki ngemu isi `src`.
///         dst.set_len(dst_len + src_len);
///     }
/// }
///
/// let mut a = vec!['r'];
/// let mut b = vec!['u', 's', 't'];
///
/// append(&mut a, &mut b);
///
/// assert_eq!(a, &['r', 'u', 's', 't']);
/// assert!(b.is_empty());
/// ```
///
/// [`Vec::append`]: ../../std/vec/struct.Vec.html#method.append
///
///
///
///
///
#[doc(alias = "memcpy")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: Nindakake kir iki mung ing wektu roto
    /*if cfg!(debug_assertions)
        && !(is_aligned_and_not_null(src)
            && is_aligned_and_not_null(dst)
            && is_nonoverlapping(src, dst, count))
    {
        // Ora panicking supaya impact codegen cilik.
        abort();
    }*/

    // SAFETY: kontrak keamanan kanggo `copy_nonoverlapping` kudu
    // ayating panelpon.
    unsafe { copy_nonoverlapping(src, dst, count) }
}

/// Nyalin byte `count * size_of::<T>()` saka `src` nganti `dst`.Sumber lan tujuan bisa uga tumpang tindih.
///
/// Yen sumber lan tujuan *ora bakal* tumpang tindih, [`copy_nonoverlapping`] bisa digunakake.
///
/// `copy` iku redaksional padha C kang [`memmove`], nanging karo urutan pitakonan swapped.
/// Nyalin kedadeyan kaya yen bait disalin saka `src` menyang rangking sementara banjur disalin saka larik menyang `dst`.
///
/// [`memmove`]: https://en.cppreference.com/w/c/string/byte/memmove
///
/// # Safety
///
/// Prilaku wis cetho yen kahanan ing ngisor iki sing nerak:
///
/// * `src` kudu [valid] kanggo maos saka `count * size_of::<T>()` bita.
///
/// * `dst` kudu [valid] kanggo nulis byte `count * size_of::<T>()`.
///
/// * Loro-lorone `src` lan `dst` kudu didadekake siji mlaku.
///
/// Kaya [`read`], `copy` nggawe salinan bitwise saka `T`, preduli saka apa `T` punika [`Copy`].
/// Yen `T` ora [`Copy`], nggunakake loro angka ing wilayah wiwit ing `*src` lan wilayah wiwit ing `* dst` bisa [violate memory safety][read-ownership].
///
///
/// Elinga yen sanajan ukuran sing disalin kanthi efektif (`count * size_of: :<T>():) Iku `0`, penunjuk kudu non-NULL lan didadekake siji mlaku.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Irit nggawe Rust vector saka buffer aman:
///
/// ```
/// use std::ptr;
///
/// /// # Safety
//////
/// /// * `ptr` kudu diselarasake kanthi bener kanggo jinis lan non-nol.
/// /// * `ptr` kudu bener kanggo maos saka `elts` unsur cedhak saka jinis `T`.
/// /// * Unsur kasebut ora bisa digunakake sawise nelpon fungsi iki kajaba `T: Copy`.
/// # #[allow(dead_code)]
/// unsafe fn from_buf_raw<T>(ptr: *const T, elts: usize) -> Vec<T> {
///     let mut dst = Vec::with_capacity(elts);
///
///     // SAFETY: Prasyarat kita njamin supaya sumber didadekake siji lan bener,
///     // lan `Vec::with_capacity` njamin manawa kita duwe ruang sing bisa digunakake kanggo nulis.
///     ptr::copy(ptr, dst.as_mut_ptr(), elts);
///
///     // SAFETY: Kita nggawe kanthi kapasitas luwih dhisik,
///     // lan `copy` sadurunge wis miwiti unsur kasebut.
///     dst.set_len(elts);
///     dst
/// }
/// ```
///
///
///
///
///
#[doc(alias = "memmove")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: Nindakake kir iki mung ing wektu roto
    /*if cfg!(debug_assertions) && !(is_aligned_and_not_null(src) && is_aligned_and_not_null(dst)) {
        // Ora panicking supaya impact codegen cilik.
        abort();
    }*/

    // SAFETY: kontrak keamanan kanggo `copy` kudu dikuatake dening panelpon.
    unsafe { copy(src, dst, count) }
}

/// Sets `count * size_of::<T>()` Bita memori miwiti ing `dst` kanggo `val`.
///
/// `write_bytes` iku padha C kang [`memset`], nanging mranata `count * size_of::<T>()` bita kanggo `val`.
///
/// [`memset`]: https://en.cppreference.com/w/c/string/byte/memset
///
/// # Safety
///
/// Prilaku wis cetho yen kahanan ing ngisor iki sing nerak:
///
/// * `dst` kudu [valid] kanggo nulis byte `count * size_of::<T>()`.
///
/// * `dst` kudu selaras kanthi bener.
///
/// Tambahan, panelpon kudu mesthekake yen nulis `count * size_of::<T>()` bita kanggo wilayah tartamtu saka asil memori ing Nilai bener `T`.
/// Nggunakake wilayah saka memori diketik minangka `T` sing ngandhut nilai bener saka `T` punika prilaku cetho.
///
/// Wigati sing malah yen ukuran èfèktif disalin (: Count * size_of::<T>():) Iku `0`, pointer kudu non-NULL lan didadekake siji mlaku.
///
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Panggunaan dhasar:
///
/// ```
/// use std::ptr;
///
/// let mut vec = vec![0u32; 4];
/// unsafe {
///     let vec_ptr = vec.as_mut_ptr();
///     ptr::write_bytes(vec_ptr, 0xfe, 2);
/// }
/// assert_eq!(vec, [0xfefefefe, 0xfefefefe, 0, 0]);
/// ```
///
/// Nggawe nilai sing ora valid:
///
/// ```
/// use std::ptr;
///
/// let mut v = Box::new(0i32);
///
/// unsafe {
///     // Bocorake nilai sing sadurunge ditahan kanthi nimpa `Box<T>` kanthi null pointer.
/////
///     ptr::write_bytes(&mut v as *mut Box<i32>, 0, 1);
/// }
///
/// // Ing jalur iki, nggunakake utawa nempel asil `v` ing prilaku cetho.
/// // drop(v); // ERROR
///
/// // Malah bocor `v` "uses" iku, lan Empu iku prilaku cetho.
/// // mem::forget(v); // ERROR
///
/// // Ing kasunyatan, `v` ora sah miturut invariants jinis tata dhasar,*sembarang operasi* ndemek iku prilaku cetho.
/////
/// // supaya v2 =v;//ERROR
///
/// unsafe {
///     // Ayo, ayo menehi angka sing valid
///     ptr::write(&mut v as *mut Box<i32>, Box::new(42i32));
/// }
///
/// // Saiki kothak wis apik
/// assert_eq!(*v, 42);
/// ```
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[inline]
pub unsafe fn write_bytes<T>(dst: *mut T, val: u8, count: usize) {
    extern "rust-intrinsic" {
        fn write_bytes<T>(dst: *mut T, val: u8, count: usize);
    }

    debug_assert!(is_aligned_and_not_null(dst), "attempt to write to unaligned or null pointer");

    // SAFETY: kontrak safety kanggo `write_bytes` kudu ayating panelpon.
    unsafe { write_bytes(dst, val, count) }
}