//! Modul iki ngetrapake `Any` trait, sing mbisakake ngetik dinamis jinis `'static` liwat refleksi runtime.
//!
//! `Any` dhewe bisa digunakake kanggo njaluk `TypeId`, lan nduweni fitur liyane nalika digunakake minangka obyek trait.
//! Minangka `&dyn Any` (obyek trait sing dipinjam), duwe metode `is` lan `downcast_ref`, kanggo nyoba yen nilai sing ana kalebu jinis sing diwenehake, lan kanggo njaluk referensi nilai batin minangka jinis.
//! Minangka `&mut dyn Any`, uga ana metode `downcast_mut`, kanggo entuk referensi sing bisa diowahi kanggo nilai batin.
//! `Box<dyn Any>` nambah cara `downcast`, sing nyoba diowahi dadi `Box<T>`.
//! Deleng dokumentasi [`Box`] kanggo rincian lengkap.
//!
//! Elinga yen `&dyn Any` diwatesi kanggo Testing apa nilai kalebu tipe konkrit kasebut, lan ora bisa digunakake kanggo test apa jinis nindakake a trait.
//!
//! [`Box`]: ../../std/boxed/struct.Box.html
//!
//! # Titik cerdas lan `dyn Any`
//!
//! Siji prilaku sing kudu dieling-eling nalika nggunakake `Any` minangka obyek trait, utamane karo jinis kayata `Box<dyn Any>` utawa `Arc<dyn Any>`, yaiku yen mung nelpon `.type_id()` ing nilai kasebut bakal ngasilake `TypeId` saka *kontainer*, dudu obyek trait sing ndasari.
//!
//! Iki bisa dihindari kanthi ngonversi pointer cerdas dadi `&dyn Any`, sing bakal ngasilake `TypeId` obyek.
//! Contone:
//!
//! ```
//! use std::any::{Any, TypeId};
//!
//! let boxed: Box<dyn Any> = Box::new(3_i32);
//!
//! // Sampeyan luwih seneng pengin iki:
//! let actual_id = (&*boxed).type_id();
//! // ... saka iki:
//! let boxed_id = boxed.type_id();
//!
//! assert_eq!(actual_id, TypeId::of::<i32>());
//! assert_eq!(boxed_id, TypeId::of::<Box<dyn Any>>());
//! ```
//!
//! # Examples
//!
//! Coba ana kahanan sing pengin metu saka nilai sing diwenehake menyang fungsi.
//! Kita ngerti regane sing digunakake kanggo ngetrapake Debug, nanging ora ngerti jinis konkrit kasebut.Kita pengin menehi perawatan khusus kanggo jinis tartamtu: ing kasus iki nyithak dawa Nilai String sadurunge regane.
//! Kita ora ngerti jinis konkrit regane nalika dikompilasi, mula luwih becik nggunakake refleksi runtime.
//!
//! ```rust
//! use std::fmt::Debug;
//! use std::any::Any;
//!
//! // Fungsi logger kanggo jinis apa wae sing ngetrapake Debug.
//! fn log<T: Any + Debug>(value: &T) {
//!     let value_any = value as &dyn Any;
//!
//!     // Coba konversi regane kita dadi `String`.
//!     // Yen sukses, kita pengin ngasilake dawa String` uga regane.
//!     // Yen ora, iku jinis sing beda: cukup dicithak tanpa hiasan.
//!     match value_any.downcast_ref::<String>() {
//!         Some(as_string) => {
//!             println!("String ({}): {}", as_string.len(), as_string);
//!         }
//!         None => {
//!             println!("{:?}", value);
//!         }
//!     }
//! }
//!
//! // Fungsi iki pengin log metu paramèter sadurunge bisa digunakake.
//! fn do_work<T: Any + Debug>(value: &T) {
//!     log(value);
//!     // ... nindakake gaweyan liyane
//! }
//!
//! fn main() {
//!     let my_string = "Hello World".to_string();
//!     do_work(&my_string);
//!
//!     let my_i8: i8 = 100;
//!     do_work(&my_i8);
//! }
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::intrinsics;

///////////////////////////////////////////////////////////////////////////////
// Sembarang trait
///////////////////////////////////////////////////////////////////////////////

/// trait kanggo niru typing dinamis.
///
/// Umume jinis ngetrapake `Any`.Nanging, jinis sing ana referensi non-`'static` ora.
/// Deleng [module-level documentation][mod] kanggo rincian liyane.
///
/// [mod]: crate::any
// trait iki ora aman, sanajan kita gumantung karo spesifik fungsi `type_id` impl dhewe-dhewe ing kode sing ora aman (contone, `downcast`).Biasane, iki bakal dadi masalah, nanging amarga impl `Any` mung implementasine kemul, ora ana kode liyane sing bisa ngetrapake `Any`.
//
// Kita bisa nggawe trait iki ora aman-ora bakal nyebabake kerusakan, amarga kita ngontrol kabeh implementasine-nanging kita milih ora amarga kalorone ora perlu banget lan bisa uga mbingungake pangguna babagan mbedakake metode traits sing ora aman lan cara sing ora aman (yaiku, `type_id` isih aman ditelpon, nanging bisa uga kasebut ing dokumentasi).
//
//
//
//
//
//
//
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Any: 'static {
    /// Entuk `TypeId` `self`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string(s: &dyn Any) -> bool {
    ///     TypeId::of::<String>() == s.type_id()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "get_type_id", since = "1.34.0")]
    fn type_id(&self) -> TypeId;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: 'static + ?Sized> Any for T {
    fn type_id(&self) -> TypeId {
        TypeId::of::<T>()
    }
}

///////////////////////////////////////////////////////////////////////////////
// cara tambahan kanggo Sembarang obyek trait.
///////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

// Priksa manawa asil conto, gabung karo utas bisa dicithak lan mula digunakake karo `unwrap`.
// Muga-muga pungkasane ora dibutuhake maneh yen pengiriman bisa digunakake kanthi upcasting.
//
#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any + Send {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

#[stable(feature = "any_send_sync_methods", since = "1.28.0")]
impl fmt::Debug for dyn Any + Send + Sync {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

impl dyn Any {
    /// Ngasilake `true` yen jinis kothak padha karo `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &dyn Any) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        // Njaluk `TypeId` saka jinis fungsi iki dilanggar karo.
        let t = TypeId::of::<T>();

        // Entuk `TypeId` jinis ing obyek trait (`self`).
        let concrete = self.type_id();

        // Bandhingake `TypeId` kanthi padha.
        t == concrete
    }

    /// Ngasilake sawetara referensi kanggo nilai kothak yen jinis `T`, utawa `None` yen ora.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &dyn Any) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        if self.is::<T>() {
            // SAFETY: mung mriksa apa kita nuduhake jinis sing bener, lan kita bisa ngandelake
            // sing mriksa keamanan memori amarga wis ngetrapake Sembarang kanggo kabeh jinis;ora ana impls liyane sing bisa wujud amarga bisa bertentangan karo impl.
            //
            unsafe { Some(&*(self as *const dyn Any as *const T)) }
        } else {
            None
        }
    }

    /// Ngasilake referensi sing bisa diowahi kanggo nilai kothak yen jinis `T`, utawa `None` yen ora.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut dyn Any) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        if self.is::<T>() {
            // SAFETY: mung mriksa apa kita nuduhake jinis sing bener, lan kita bisa ngandelake
            // sing mriksa keamanan memori amarga wis ngetrapake Sembarang kanggo kabeh jinis;ora ana impls liyane sing bisa wujud amarga bisa bertentangan karo impl.
            //
            unsafe { Some(&mut *(self as *mut dyn Any as *mut T)) }
        } else {
            None
        }
    }
}

impl dyn Any + Send {
    /// Maju menyang metode sing ditemtokake ing jinis `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// Maju menyang metode sing ditemtokake ing jinis `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// Maju menyang metode sing ditemtokake ing jinis `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

impl dyn Any + Send + Sync {
    /// Maju menyang metode sing ditemtokake ing jinis `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send + Sync)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// Maju menyang metode sing ditemtokake ing jinis `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send + Sync)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// Maju menyang metode sing ditemtokake ing jinis `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send + Sync)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

///////////////////////////////////////////////////////////////////////////////
// TypeID lan cara-cara
///////////////////////////////////////////////////////////////////////////////

/// `TypeId` makili pengenal unik global kanggo jinis.
///
/// Saben `TypeId` arupa objek opaque kang ora ngidini pengawasan saka apa nang nanging ora memungkinkan operasi dhasar kayata cloning, comparison, Printing, lan nuduhake.
///
///
/// `TypeId` saiki kasedhiya mung kanggo jinis sing dianggep `'static`, nanging watesan iki bisa uga dicopot ing future.
///
/// Nalika `TypeId` ngetrapake `Hash`, `PartialOrd`, lan `Ord`, perlu dielingi manawa hash lan pesen bakal beda-beda antarane rilis Rust.
/// Ati-ati saka gumantung ing njero kode sampeyan!
///
///
///
#[derive(Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Debug, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct TypeId {
    t: u64,
}

impl TypeId {
    /// Ngasilake `TypeId` saka jinis fungsi umum iki wis diwiwiti.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string<T: ?Sized + Any>(_s: &T) -> bool {
    ///     TypeId::of::<String>() == TypeId::of::<T>()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub const fn of<T: ?Sized + 'static>() -> TypeId {
        TypeId { t: intrinsics::type_id::<T>() }
    }
}

/// Ngasilake jeneng jinis minangka irisan senar.
///
/// # Note
///
/// Iki dimaksudake kanggo nggunakake diagnostik.
/// Isi lan format sing tepat saka string sing dikembalikan ora ditemtokake, kajaba minangka deskripsi gaweyan sing paling apik kanggo jinis kasebut.
/// Contone, ing antarane senar sing bisa ngasilake `type_name::<Option<String>>()` yaiku `"Option<String>"` lan `"std::option::Option<std::string::String>"`.
///
///
/// senar bali kudu ora dianggep dadi pengenal unik saka jinis minangka kaping jinis uga peta kanggo jeneng jinis padha.
/// Kajaba iku, ora ana jaminan yen kabeh bagean saka jinis bakal katon ing senar sing dikembalikan: contone, spesifikasi umur saiki ora kalebu.
/// Kajaba iku, output bisa uga beda-beda ing antarane versi kompiler.
///
/// Implementasi saiki nggunakake infrastruktur sing padha karo diagnostik compiler lan debuginfo, nanging iki ora bisa dijamin.
///
/// # Examples
///
/// ```rust
/// assert_eq!(
///     std::any::type_name::<Option<String>>(),
///     "core::option::Option<alloc::string::String>",
/// );
/// ```
///
///
///
///
#[stable(feature = "type_name", since = "1.38.0")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name<T: ?Sized>() -> &'static str {
    intrinsics::type_name::<T>()
}

/// Ngasilake jeneng jinis nilai sing dituduhake minangka irisan senar.
/// Iki padha karo `type_name::<T>()`, nanging bisa digunakake ing endi jinis variabel ora gampang kasedhiya.
///
/// # Note
///
/// Iki dimaksudake kanggo nggunakake diagnostik.Isi lan format senar sing pas ora ditemtokake, kajaba minangka deskripsi gaweyan sing paling apik kanggo jinis kasebut.
/// Contone, `type_name_of_val::<Option<String>>(None)` bisa ngasilake `"Option<String>"` utawa `"std::option::Option<std::string::String>"`, nanging ora `"foobar"`.
///
/// Kajaba iku, output bisa uga beda-beda ing antarane versi kompiler.
///
/// Fungsi iki ora ngatasi obyek trait, tegese `type_name_of_val(&7u32 as &dyn Debug)` bisa ngasilake `"dyn Debug"`, nanging ora `"u32"`.
///
/// Jeneng jinis ngirim ora dianggep minangka pengenal unik kanggo jinis;
/// macem-macem jinis bisa nuduhake jeneng jinis sing padha.
///
/// Implementasi saiki nggunakake infrastruktur sing padha karo diagnostik compiler lan debuginfo, nanging iki ora bisa dijamin.
///
/// # Examples
///
/// Nyithak nomer bunder lan float default.
///
/// ```rust
/// #![feature(type_name_of_val)]
/// use std::any::type_name_of_val;
///
/// let x = 1;
/// println!("{}", type_name_of_val(&x));
/// let y = 1.0;
/// println!("{}", type_name_of_val(&y));
/// ```
///
///
///
///
///
///
#[unstable(feature = "type_name_of_val", issue = "66359")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name_of_val<T: ?Sized>(_val: &T) -> &'static str {
    type_name::<T>()
}