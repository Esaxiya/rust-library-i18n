macro_rules! uint_impl {
    ($SelfT:ty, $ActualT:ty, $BITS:expr, $MaxV:expr,
        $rot:expr, $rot_op:expr, $rot_result:expr, $swap_op:expr, $swapped:expr,
        $reversed:expr, $le_bytes:expr, $be_bytes:expr,
        $to_xe_bytes_doc:expr, $from_xe_bytes_doc:expr) => {
        /// Nilai paling cilik sing bisa diwakili dening jinis bilangan bulat iki.
        ///
        /// # Examples
        ///
        /// Panggunaan dhasar:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN, 0);")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MIN: Self = 0;

        /// Nilai paling gedhe sing bisa diwakili dening jinis bilangan bulat iki.
        ///
        /// # Examples
        ///
        /// Panggunaan dhasar:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX, ", stringify!($MaxV), ");")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MAX: Self = !0;

        /// Ukuran jinis wilangan bulat iki ing bit.
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(int_bits_const)]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::BITS, ", stringify!($BITS), ");")]
        /// ```
        #[unstable(feature = "int_bits_const", issue = "76904")]
        pub const BITS: u32 = $BITS;

        /// Ngonversi irisan senar ing basis tartamtu menyang bilangan bulat.
        ///
        /// senar wis samesthine dadi tandha `+` pilihan ngiring dening digit.
        ///
        /// Mimpin lan mburine papan putih nuduhake kesalahan.
        /// Digit minangka bagean saka karakter kasebut, gumantung saka `radix`:
        ///
        /// * `0-9`
        /// * `a-z`
        /// * `A-Z`
        ///
        /// # Panics
        ///
        /// Fungsi panics iki yen `radix` ora ana ing kisaran 2 nganti 36.
        ///
        /// # Examples
        ///
        /// Panggunaan dhasar:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::from_str_radix(\"A\", 16), Ok(10));")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        pub fn from_str_radix(src: &str, radix: u32) -> Result<Self, ParseIntError> {
            from_str_radix(src, radix)
        }

        /// Ngasilake nomer siji ing perwakilan binar `self`.
        ///
        /// # Examples
        ///
        /// Panggunaan dhasar:
        ///
        /// ```
        #[doc = concat!("let n = 0b01001100", stringify!($SelfT), ";")]
        /// assert_eq!(n.count_ones(), 3);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[doc(alias = "popcount")]
        #[doc(alias = "popcnt")]
        #[inline]
        pub const fn count_ones(self) -> u32 {
            intrinsics::ctpop(self as $ActualT) as u32
        }

        /// Ngasilake jumlah nol ing perwakilan binar `self`.
        ///
        /// # Examples
        ///
        /// Panggunaan dhasar:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.count_zeros(), 0);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn count_zeros(self) -> u32 {
            (!self).count_ones()
        }

        /// Ngasilake nomer nol utama ing perwakilan binar `self`.
        ///
        /// # Examples
        ///
        /// Panggunaan dhasar:
        ///
        /// ```
        #[doc = concat!("let n = ", stringify!($SelfT), "::MAX >> 2;")]
        /// assert_eq!(n.leading_zeros(), 2);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn leading_zeros(self) -> u32 {
            intrinsics::ctlz(self as $ActualT) as u32
        }

        /// Ngasilake nomer nol trailing ing perwakilan binar `self`.
        ///
        ///
        /// # Examples
        ///
        /// Panggunaan dhasar:
        ///
        /// ```
        #[doc = concat!("let n = 0b0101000", stringify!($SelfT), ";")]
        /// assert_eq!(n.trailing_zeros(), 3);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn trailing_zeros(self) -> u32 {
            intrinsics::cttz(self) as u32
        }

        /// Ngasilake nomer pimpinan utama ing perwakilan binar `self`.
        ///
        /// # Examples
        ///
        /// Panggunaan dhasar:
        ///
        /// ```
        #[doc = concat!("let n = !(", stringify!($SelfT), "::MAX >> 2);")]
        /// assert_eq!(n.leading_ones(), 2);
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[inline]
        pub const fn leading_ones(self) -> u32 {
            (!self).leading_zeros()
        }

        /// Ngasilake nomer trailing ing perwakilan binar `self`.
        ///
        ///
        /// # Examples
        ///
        /// Panggunaan dhasar:
        ///
        /// ```
        #[doc = concat!("let n = 0b1010111", stringify!($SelfT), ";")]
        /// assert_eq!(n.trailing_ones(), 3);
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[inline]
        pub const fn trailing_ones(self) -> u32 {
            (!self).trailing_zeros()
        }

        /// Ganti bit ing sisih kiwa kanthi jumlah sing ditemtokake, `n`, bungkus bit sing wis dipotong nganti pungkasan bilangan bulat sing diasilake.
        ///
        ///
        /// Elinga, iki dudu operasi sing padha karo operator ganti `<<`!
        ///
        /// # Examples
        ///
        /// Panggunaan dhasar:
        ///
        /// ```
        #[doc = concat!("let n = ", $rot_op, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_result, ";")]

        #[doc = concat!("assert_eq!(n.rotate_left(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn rotate_left(self, n: u32) -> Self {
            intrinsics::rotate_left(self, n as $SelfT)
        }

        /// Ganti bit menyang sisih tengen kanthi jumlah sing ditemtokake, `n`, bungkus bit sing wis dipotong nganti wiwitan bilangan bulat sing diasilake.
        ///
        ///
        /// Elinga, iki dudu operasi sing padha karo operator ganti `>>`!
        ///
        /// # Examples
        ///
        /// Panggunaan dhasar:
        ///
        /// ```
        ///
        #[doc = concat!("let n = ", $rot_result, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_op, ";")]

        #[doc = concat!("assert_eq!(n.rotate_right(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn rotate_right(self, n: u32) -> Self {
            intrinsics::rotate_right(self, n as $SelfT)
        }

        /// Nguripake urutan byte wilangan bulat.
        ///
        /// # Examples
        ///
        /// Panggunaan dhasar:
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// ayo m= n.swap_bytes();
        ///
        #[doc = concat!("assert_eq!(m, ", $swapped, ");")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn swap_bytes(self) -> Self {
            intrinsics::bswap(self as $ActualT) as Self
        }

        /// Nguripake urutan bit ing bilangan bulat.
        /// Bit sing paling penting dadi sing paling penting, sing paling liya sing liya dadi sing paling penting nomer loro, lsp.
        ///
        /// # Examples
        ///
        /// Panggunaan dhasar:
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// ayo m= n.reverse_bits();
        ///
        #[doc = concat!("assert_eq!(m, ", $reversed, ");")]
        #[doc = concat!("assert_eq!(0, 0", stringify!($SelfT), ".reverse_bits());")]
        /// ```
        #[stable(feature = "reverse_bits", since = "1.37.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        #[must_use]
        pub const fn reverse_bits(self) -> Self {
            intrinsics::bitreverse(self as $ActualT) as Self
        }

        /// Ngowahi angka bulat saka endian amba menyang endianness target.
        ///
        /// Ing endian gedhe, iki ora ana gandhengane.
        /// Ing endian cilik, bait diganti.
        ///
        /// # Examples
        ///
        /// Panggunaan dhasar:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// yen CFG! (target_endian= "big"){
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n)")]
        /// } liya {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn from_be(x: Self) -> Self {
            #[cfg(target_endian = "big")]
            {
                x
            }
            #[cfg(not(target_endian = "big"))]
            {
                x.swap_bytes()
            }
        }

        /// Ngowahi wilangan bulat saka endian cilik menyang endianness target.
        ///
        /// Ing endian cilik, iki ora ana gandhengane.
        /// Ing endian gedhe bait diganti.
        ///
        /// # Examples
        ///
        /// Panggunaan dhasar:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// yen CFG! (target_endian= "little"){
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n)")]
        /// } liya {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn from_le(x: Self) -> Self {
            #[cfg(target_endian = "little")]
            {
                x
            }
            #[cfg(not(target_endian = "little"))]
            {
                x.swap_bytes()
            }
        }

        /// Ngowahi `self` dadi endian gedhe saka endianness target.
        ///
        /// Ing endian gedhe, iki ora ana gandhengane.
        /// Ing endian cilik, bait diganti.
        ///
        /// # Examples
        ///
        /// Panggunaan dhasar:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// yen CFG! (target_endian= "big"){
        ///     assert_eq!(n.to_be(), n)
        /// } liya { assert_eq!(n.to_be(), n.swap_bytes()) }
        ///
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn to_be(self) -> Self { // utawa ora dadi?
            #[cfg(target_endian = "big")]
            {
                self
            }
            #[cfg(not(target_endian = "big"))]
            {
                self.swap_bytes()
            }
        }

        /// Ngowahi `self` dadi endian cilik saka endianness target.
        ///
        /// Ing endian cilik, iki ora ana gandhengane.
        /// Ing endian gedhe bait diganti.
        ///
        /// # Examples
        ///
        /// Panggunaan dhasar:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// yen CFG! (target_endian= "little"){
        ///     assert_eq!(n.to_le(), n)
        /// } liya { assert_eq!(n.to_le(), n.swap_bytes()) }
        ///
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn to_le(self) -> Self {
            #[cfg(target_endian = "little")]
            {
                self
            }
            #[cfg(not(target_endian = "little"))]
            {
                self.swap_bytes()
            }
        }

        /// Ditambah nomer ongko.
        /// Ngitung `self + rhs`, ngasilake `None` yen ana overflow.
        ///
        /// # Examples
        ///
        /// Panggunaan dhasar:
        ///
        /// ```
        #[doc = concat!(
            "assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(1), ",
            "Some(", stringify!($SelfT), "::MAX - 1));"
        )]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(3), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_add(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_add(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Kajaba ora dicenthang nomer ongko.Ngitung `self + rhs`, kanthi asumsi kebanjiran ora bisa kedadeyan.
        /// Iki nyebabake tumindak sing ora ditemtokake nalika
        #[doc = concat!("`self + rhs > ", stringify!($SelfT), "::MAX` or `self + rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_add(self, rhs: Self) -> Self {
            // SAFETY: panelpon kudu njaga kontrak keamanan kanggo `unchecked_add`.
            //
            unsafe { intrinsics::unchecked_add(self, rhs) }
        }

        /// Pangirangan bilangan bunder sing dicenthang.
        /// Ngitung `self - rhs`, ngasilake `None` yen ana overflow.
        ///
        /// # Examples
        ///
        /// Panggunaan dhasar:
        ///
        /// ```
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_sub(1), Some(0));")]
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".checked_sub(1), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_sub(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_sub(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Pangurangan bilangan bulat sing ora dicenthang.Ngitung `self - rhs`, kanthi asumsi kebanjiran ora bisa kedadeyan.
        /// Iki nyebabake tumindak sing ora ditemtokake nalika
        #[doc = concat!("`self - rhs > ", stringify!($SelfT), "::MAX` or `self - rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_sub(self, rhs: Self) -> Self {
            // SAFETY: panelpon kudu njaga kontrak keamanan kanggo `unchecked_sub`.
            //
            unsafe { intrinsics::unchecked_sub(self, rhs) }
        }

        /// Penggandaan bilangan bulat.
        /// Ngitung `self * rhs`, bali `None` yen kebanjiran wonten.
        ///
        /// # Examples
        ///
        /// Panggunaan dhasar:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_mul(1), Some(5));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_mul(2), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_mul(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_mul(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Perkalian bilangan bulat sing ora dicenthang.Ngitung `self * rhs`, kanthi asumsi kebanjiran ora bisa kedadeyan.
        /// Iki nyebabake tumindak sing ora ditemtokake nalika
        #[doc = concat!("`self * rhs > ", stringify!($SelfT), "::MAX` or `self * rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_mul(self, rhs: Self) -> Self {
            // SAFETY: panelpon kudu njaga kontrak keamanan kanggo `unchecked_mul`.
            //
            unsafe { intrinsics::unchecked_mul(self, rhs) }
        }

        /// Divisi wilangan bunder sing dicenthang.
        /// Ngitung `self / rhs`, bali `None` yen `rhs == 0`.
        ///
        /// # Examples
        ///
        /// Panggunaan dhasar:
        ///
        /// ```
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".checked_div(2), Some(64));")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_div(0), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                // SAFETY: div by nol wis dicenthang ing ndhuwur lan jinis sing ora ditandatangani ora ana liyane
                // mode kegagalan kanggo divisi
                Some(unsafe { intrinsics::unchecked_div(self, rhs) })
            }
        }

        /// Divisi Euclidean sing dicenthang.
        /// Ngitung `self.div_euclid(rhs)`, ngasilake `None` yen `rhs == 0`.
        ///
        /// # Examples
        ///
        /// Panggunaan dhasar:
        ///
        /// ```
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".checked_div_euclid(2), Some(64));")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_div_euclid(0), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                Some(self.div_euclid(rhs))
            }
        }


        /// Sisa ongko ongko.
        /// Ngitung `self % rhs`, ngasilake `None` yen `rhs == 0`.
        ///
        /// # Examples
        ///
        /// Panggunaan dhasar:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(0), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                // SAFETY: div by nol wis dicenthang ing ndhuwur lan jinis sing ora ditandatangani ora ana liyane
                // mode kegagalan kanggo divisi
                Some(unsafe { intrinsics::unchecked_rem(self, rhs) })
            }
        }

        /// Modifikasi Euclidean sing dicenthang.
        /// Ngitung `self.rem_euclid(rhs)`, ngasilake `None` yen `rhs == 0`.
        ///
        /// # Examples
        ///
        /// Panggunaan dhasar:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(0), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                Some(self.rem_euclid(rhs))
            }
        }

        /// Negasi sing dicenthang.Ngitung `-self`, ngasilake `None` kajaba `self==
        /// 0`.
        ///
        /// Elinga yen negesake bilangan bulat positif bakal kebanjiran.
        ///
        /// # Examples
        ///
        /// Panggunaan dhasar:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".checked_neg(), Some(0));")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_neg(), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn checked_neg(self) -> Option<Self> {
            let (a, b) = self.overflowing_neg();
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Diperiksa shift kiwa.
        /// Ngitung `self << rhs`, ngasilake `None` yen `rhs` luwih gedhe tinimbang utawa padha karo jumlah bit ing `self`.
        ///
        /// # Examples
        ///
        /// Panggunaan dhasar:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".checked_shl(4), Some(0x10));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shl(129), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shl(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shl(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Diperiksa shift nengen.
        /// Ngitung `self >> rhs`, ngasilake `None` yen `rhs` luwih gedhe tinimbang utawa padha karo jumlah bit ing `self`.
        ///
        /// # Examples
        ///
        /// Panggunaan dhasar:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(4), Some(0x1));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(129), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shr(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shr(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Eksponentasi sing dicenthang.
        /// Ngitung `self.pow(exp)`, ngasilake `None` yen ana overflow.
        ///
        /// # Examples
        ///
        /// Panggunaan dhasar:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".checked_pow(5), Some(32));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_pow(2), None);")]
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_pow(self, mut exp: u32) -> Option<Self> {
            if exp == 0 {
                return Some(1);
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = try_opt!(acc.checked_mul(base));
                }
                exp /= 2;
                base = try_opt!(base.checked_mul(base));
            }

            // wiwit exp!=0, pungkasane exp kudu 1.
            // Nangani bit pungkasan saka exponent kanthi kapisah, amarga kuadrat dhasar sawise iku ora prelu lan bisa nyebabake kebanjiran sing ora perlu.
            //
            //

            Some(try_opt!(acc.checked_mul(base)))
        }

        /// Kajaba ongko wilangan bunder.
        /// Ngitung `self + rhs`, jenuh ing wates angka tinimbang kakehan.
        ///
        /// # Examples
        ///
        /// Panggunaan dhasar:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_add(1), 101);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_add(127), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn saturating_add(self, rhs: Self) -> Self {
            intrinsics::saturating_add(self, rhs)
        }

        /// Pangirangan bilangan bulat sing jenuh.
        /// Ngitung `self - rhs`, jenuh ing wates angka tinimbang kakehan.
        ///
        /// # Examples
        ///
        /// Panggunaan dhasar:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_sub(27), 73);")]
        #[doc = concat!("assert_eq!(13", stringify!($SelfT), ".saturating_sub(127), 0);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn saturating_sub(self, rhs: Self) -> Self {
            intrinsics::saturating_sub(self, rhs)
        }

        /// Penggandaan bilangan bulat sing jenuh.
        /// Ngitung `self * rhs`, jenuh ing wates angka tinimbang kakehan.
        ///
        /// # Examples
        ///
        /// Panggunaan dhasar:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".saturating_mul(10), 20);")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX).saturating_mul(10), ", stringify!($SelfT),"::MAX);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_mul(self, rhs: Self) -> Self {
            match self.checked_mul(rhs) {
                Some(x) => x,
                None => Self::MAX,
            }
        }

        /// Eksponentasi bilangan bulat sing jenuh.
        /// Ngitung `self.pow(exp)`, jenuh ing wates angka tinimbang kakehan.
        ///
        /// # Examples
        ///
        /// Panggunaan dhasar:
        ///
        /// ```
        #[doc = concat!("assert_eq!(4", stringify!($SelfT), ".saturating_pow(3), 64);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_pow(2), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_pow(self, exp: u32) -> Self {
            match self.checked_pow(exp) {
                Some(x) => x,
                None => Self::MAX,
            }
        }

        /// Kajaba mbungkus (modular).
        /// Ngitung `self + rhs`, bungkus ing wates jinis kasebut.
        ///
        /// # Examples
        ///
        /// Panggunaan dhasar:
        ///
        /// ```
        #[doc = concat!("assert_eq!(200", stringify!($SelfT), ".wrapping_add(55), 255);")]
        #[doc = concat!("assert_eq!(200", stringify!($SelfT), ".wrapping_add(", stringify!($SelfT), "::MAX), 199);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_add(self, rhs: Self) -> Self {
            intrinsics::wrapping_add(self, rhs)
        }

        /// Mbungkus pangirangan (modular).
        /// Ngitung `self - rhs`, bungkus ing wates jinis kasebut.
        ///
        /// # Examples
        ///
        /// Panggunaan dhasar:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_sub(100), 0);")]
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_sub(", stringify!($SelfT), "::MAX), 101);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_sub(self, rhs: Self) -> Self {
            intrinsics::wrapping_sub(self, rhs)
        }

        /// Mbungkus multiplikasi (modular).
        /// Ngitung `self * rhs`, bungkus ing wates jinis kasebut.
        ///
        /// # Examples
        ///
        /// Panggunaan dhasar:
        ///
        /// Elinga yen conto iki dituduhake ing antarane jinis bilangan bunder.
        /// Sing nerangake kenapa `u8` digunakake ing kene.
        ///
        /// ```
        /// assert_eq!(10u8.wrapping_mul(12), 120);
        /// assert_eq!(25u8.wrapping_mul(12), 44);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
        #[inline]
        pub const fn wrapping_mul(self, rhs: Self) -> Self {
            intrinsics::wrapping_mul(self, rhs)
        }

        /// Pembungkus divisi (modular).Ngitung `self / rhs`.
        /// Divisi sing dibungkus ing jinis sing durung ditandatangani mung divisi normal.
        /// Ora ana cara mbungkus sing bisa kedadeyan.
        /// Fungsi iki ana, saengga kabeh operasi dipertanggungjawabake ing operasi pambungkus.
        ///
        ///
        /// # Examples
        ///
        /// Panggunaan dhasar:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div(10), 10);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div(self, rhs: Self) -> Self {
            self / rhs
        }

        /// Pembungkus divisi Euclidean.Ngitung `self.div_euclid(rhs)`.
        /// Divisi sing dibungkus ing jinis sing durung ditandatangani mung divisi normal.
        /// Ora ana cara mbungkus sing bisa kedadeyan.
        /// Fungsi iki ana, saengga kabeh operasi dipertanggungjawabake ing operasi pambungkus.
        /// Amarga, kanggo bilangan bulat positif, kabeh definisi umum divisi padha, iki padha karo `self.wrapping_div(rhs)`.
        ///
        ///
        /// # Examples
        ///
        /// Panggunaan dhasar:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div_euclid(10), 10);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div_euclid(self, rhs: Self) -> Self {
            self / rhs
        }

        /// Bungkus sisane (modular).Ngitung `self % rhs`.
        /// Pitungan sisan sing dibungkus ing jinis sing durung ditandatangani mung minangka petungan sisan biasa.
        ///
        /// Ora ana cara mbungkus sing bisa kedadeyan.
        /// Fungsi iki ana, saengga kabeh operasi dipertanggungjawabake ing operasi pambungkus.
        ///
        /// # Examples
        ///
        /// Panggunaan dhasar:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem(10), 0);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem(self, rhs: Self) -> Self {
            self % rhs
        }

        /// Bungkus modhél Euclidean.Ngitung `self.rem_euclid(rhs)`.
        /// Petungan modulo sing dibungkus ing jinis sing durung ditandatangani mung minangka petungan seko biasa.
        /// Ora ana cara mbungkus sing bisa kedadeyan.
        /// Fungsi iki ana, saengga kabeh operasi dipertanggungjawabake ing operasi pambungkus.
        /// Amarga, kanggo bilangan bulat positif, kabeh definisi umum divisi padha, iki padha karo `self.wrapping_rem(rhs)`.
        ///
        ///
        /// # Examples
        ///
        /// Panggunaan dhasar:
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem_euclid(10), 0);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem_euclid(self, rhs: Self) -> Self {
            self % rhs
        }

        /// Mbungkus negosiasi (modular).
        /// Ngitung `-self`, bungkus ing wates jinis kasebut.
        ///
        /// Amarga jinis sing ora ditandatangani ora padha karo sing padha, kabeh aplikasi kanggo fungsi iki bakal dibungkus (kajaba `-0`).
        /// Kanggo angka sing luwih cilik tinimbang maksimum jinis sing ditandatangani, asil padha karo nyithak nilai sing ditandatangani sing cocog.
        ///
        /// Nilai sing luwih gedhe padha karo `MAX + 1 - (val - MAX - 1)` ing endi `MAX` maksimal jinis mlebu sing cocog.
        ///
        /// # Examples
        ///
        /// Panggunaan dhasar:
        ///
        /// Elinga yen conto iki dituduhake ing antarane jinis bilangan bunder.
        /// Sing nerangake kenapa `i8` digunakake ing kene.
        ///
        /// ```
        /// assert_eq!(100i8.wrapping_neg(), -100);
        /// assert_eq!((-128i8).wrapping_neg(), -128);
        /// ```
        ///
        ///
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[inline]
        pub const fn wrapping_neg(self) -> Self {
            self.overflowing_neg().0
        }

        /// Panic bebas ngalih sak kiwa-kiwa;
        /// ngasilake `self << mask(rhs)`, ing endi `mask` mbusak bit urutan `rhs` sing dhuwur sing bakal nyebabake shift ngluwihi bitwidth jinis kasebut.
        ///
        /// Elinga yen iki *ora* padha karo muter-kiwa;RHS shift-kiwa bungkus diwatesi karo sawetara jinis, tinimbang bit sing digeser metu saka LHS sing bali menyang ujung liyane.
        /// Jinis bilangan bulat primitif kabeh ngetrapake fungsi [`rotate_left`](Self::rotate_left), sing uga dadi sing dikarepake.
        ///
        /// # Examples
        ///
        /// Panggunaan dhasar:
        ///
        /// ```
        ///
        ///
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".wrapping_shl(7), 128);")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".wrapping_shl(128), 1);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_shl(self, rhs: u32) -> Self {
            // SAFETY: masking kanthi bitis jinis mesthekake yen kita ora ngalih
            // metu saka wates
            unsafe {
                intrinsics::unchecked_shl(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// Panic-bebas ngalih ing sisih tengen;
        /// ngasilake `self >> mask(rhs)`, ing endi `mask` mbusak bit urutan `rhs` sing dhuwur sing bakal nyebabake shift ngluwihi bitwidth jinis kasebut.
        ///
        /// Elinga yen iki *ora* padha karo puteran-tengen;RHS saka shift-tengen bungkus diwatesi karo sawetara jinis, tinimbang bit sing digeser metu saka LHS sing bali menyang ujung liyane.
        /// Jinis bilangan bulat primitif kabeh ngetrapake fungsi [`rotate_right`](Self::rotate_right), sing uga dadi sing dikarepake.
        ///
        /// # Examples
        ///
        /// Panggunaan dhasar:
        ///
        /// ```
        ///
        ///
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".wrapping_shr(7), 1);")]
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".wrapping_shr(128), 128);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_shr(self, rhs: u32) -> Self {
            // SAFETY: masking kanthi bitis jinis mesthekake yen kita ora ngalih
            // metu saka wates
            unsafe {
                intrinsics::unchecked_shr(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// Mbungkus eksponentasi (modular).
        /// Ngitung `self.pow(exp)`, bungkus ing wates jinis kasebut.
        ///
        /// # Examples
        ///
        /// Panggunaan dhasar:
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".wrapping_pow(5), 243);")]
        /// assert_eq!(3u8.wrapping_pow(6), 217);
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc.wrapping_mul(base);
                }
                exp /= 2;
                base = base.wrapping_mul(base);
            }

            // wiwit exp!=0, pungkasane exp kudu 1.
            // Nangani bit pungkasan saka exponent kanthi kapisah, amarga kuadrat dhasar sawise iku ora prelu lan bisa nyebabake kebanjiran sing ora perlu.
            //
            //
            acc.wrapping_mul(base)
        }

        /// Ngetung `self` + `rhs`
        ///
        /// Ngasilake tambahan tambahan bebarengan karo boolean sing nuduhake manawa kebanjiran aritmetika bakal kedadeyan.
        /// Yen kebanjiran bakal kedadeyan, mula bakal dibungkus maneh.
        ///
        /// # Examples
        ///
        /// Panggunaan dhasar
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_add(2), (7, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.overflowing_add(1), (0, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_add(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::add_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// Ngetung `self`, `rhs`
        ///
        /// Ngasilake tuple pangurangan bebarengan karo boolean sing nuduhake manawa kebanjiran aritmetika bakal kedadeyan.
        /// Yen kebanjiran bakal kedadeyan, mula bakal dibungkus maneh.
        ///
        /// # Examples
        ///
        /// Panggunaan dhasar
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_sub(2), (3, false));")]
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".overflowing_sub(1), (", stringify!($SelfT), "::MAX, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_sub(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::sub_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// Ngetung perkalian `self` lan `rhs`.
        ///
        /// Ngasilake tuple saka perkalian bebarengan karo boolean sing nuduhake manawa kebanjiran aritmetika bakal kedadeyan.
        /// Yen kebanjiran bakal kedadeyan, mula bakal dibungkus maneh.
        ///
        /// # Examples
        ///
        /// Panggunaan dhasar:
        ///
        /// Elinga yen conto iki dituduhake ing antarane jinis bilangan bunder.
        /// Sing nerangake kenapa `u32` digunakake ing kene.
        ///
        /// ```
        /// assert_eq!(5u32.overflowing_mul(2), (10, false));
        /// assert_eq!(1_000_000_000u32.overflowing_mul(10), (1410065408, true));
        /// ```
        ///
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
        #[inline]
        pub const fn overflowing_mul(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::mul_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// Ngetung pembagi nalika `self` dipérang dadi `rhs`.
        ///
        /// Ngasilake tuple pembagi bebarengan karo boolean sing nuduhake manawa kebanjiran aritmetika bakal kedadeyan.
        /// Elinga yen kakehan bilangan bulat sing ora ditandatangani ora bakal kedadeyan, mula regane nomer loro `false`.
        ///
        /// # Panics
        ///
        /// Fungsi iki bakal panic yen `rhs` yaiku 0.
        ///
        /// # Examples
        ///
        /// Panggunaan dhasar
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div(2), (2, false));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div(self, rhs: Self) -> (Self, bool) {
            (self / rhs, false)
        }

        /// Ngetung kuite saka divisi Euclidean `self.div_euclid(rhs)`.
        ///
        /// Ngasilake tuple pembagi bebarengan karo boolean sing nuduhake manawa kebanjiran aritmetika bakal kedadeyan.
        /// Elinga yen kakehan bilangan bulat sing ora ditandatangani ora bakal kedadeyan, mula regane nomer loro `false`.
        /// Amarga, kanggo bilangan bulat positif, kabeh definisi umum divisi padha, iki padha karo `self.overflowing_div(rhs)`.
        ///
        ///
        /// # Panics
        ///
        /// Fungsi iki bakal panic yen `rhs` yaiku 0.
        ///
        /// # Examples
        ///
        /// Panggunaan dhasar
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div_euclid(2), (2, false));")]
        /// ```
        #[inline]
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div_euclid(self, rhs: Self) -> (Self, bool) {
            (self / rhs, false)
        }

        /// Ngetung seko nalika `self` dipérang dening `rhs`.
        ///
        /// Ngasilake sisan saka sisa sawise dipisahake karo boolean sing nuduhake manawa kebanjiran aritmetika bakal kedadeyan.
        /// Elinga yen kakehan bilangan bulat sing ora ditandatangani ora bakal kedadeyan, mula regane nomer loro `false`.
        ///
        /// # Panics
        ///
        /// Fungsi iki bakal panic yen `rhs` yaiku 0.
        ///
        /// # Examples
        ///
        /// Panggunaan dhasar
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem(2), (1, false));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_rem(self, rhs: Self) -> (Self, bool) {
            (self % rhs, false)
        }

        /// Ngitung sisan `self.rem_euclid(rhs)` kaya divisi Euclidean.
        ///
        /// Ngasilake tutupe modulo sawise dibagi bareng karo boolean sing nuduhake manawa kebanjiran aritmetika bakal kedadeyan.
        /// Elinga yen kakehan bilangan bulat sing ora ditandatangani ora bakal kedadeyan, mula regane nomer loro `false`.
        /// Amarga, kanggo bilangan bulat positif, kabeh definisi umum divisi padha, operasi iki persis padha karo `self.overflowing_rem(rhs)`.
        ///
        ///
        /// # Panics
        ///
        /// Fungsi iki bakal panic yen `rhs` yaiku 0.
        ///
        /// # Examples
        ///
        /// Panggunaan dhasar
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem_euclid(2), (1, false));")]
        /// ```
        #[inline]
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_rem_euclid(self, rhs: Self) -> (Self, bool) {
            (self % rhs, false)
        }

        /// Negates dhewe kanthi mode sing kebanjiran.
        ///
        /// Ngasilake `!self + 1` nggunakake operasi pambungkus kanggo ngasilake nilai sing nuduhake negasi saka nilai sing ora ditandatangani iki.
        /// Elinga yen nilai kebanjiran positif sing durung ditandatangani mesthi kedadeyan, nanging neges 0 ora kebanjiran.
        ///
        /// # Examples
        ///
        /// Panggunaan dhasar
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".overflowing_neg(), (0, false));")]
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".overflowing_neg(), (-2i32 as ", stringify!($SelfT), ", true));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        pub const fn overflowing_neg(self) -> (Self, bool) {
            ((!self).wrapping_add(1), self != 0)
        }

        /// Ngalih kanthi kiwa dening `rhs` bit.
        ///
        /// Ngasilake tuple saka versi sing digeser dhewe bebarengan karo boolean sing nuduhake manawa nilai shift luwih gedhe tinimbang utawa padha karo jumlah bit.
        /// Yen nilai shift gedhe banget, mula nilai kasebut bakal ditutupi (N-1) ing endi N minangka jumlah bit, lan nilai iki banjur digunakake kanggo nindakake shift.
        ///
        /// # Examples
        ///
        /// Panggunaan dhasar
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".overflowing_shl(4), (0x10, false));")]
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".overflowing_shl(132), (0x10, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shl(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shl(rhs), (rhs > ($BITS - 1)))
        }

        /// Ngganti kanthi bener nganggo bit `rhs`.
        ///
        /// Ngasilake tuple saka versi sing digeser dhewe bebarengan karo boolean sing nuduhake manawa nilai shift luwih gedhe tinimbang utawa padha karo jumlah bit.
        /// Yen nilai shift gedhe banget, mula nilai kasebut bakal ditutupi (N-1) ing endi N minangka jumlah bit, lan nilai iki banjur digunakake kanggo nindakake shift.
        ///
        /// # Examples
        ///
        /// Panggunaan dhasar
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".overflowing_shr(4), (0x1, false));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".overflowing_shr(132), (0x1, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shr(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shr(rhs), (rhs > ($BITS - 1)))
        }

        /// Ngunggahake kekuwatan `exp`, nggunakake exponentiation kanthi kuadrat.
        ///
        /// Ngasilake tuple exponentiation bebarengan karo bool sing nuduhake manawa kebanjiran kedadeyan.
        ///
        ///
        /// # Examples
        ///
        /// Panggunaan dhasar:
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".overflowing_pow(5), (243, false));")]
        /// assert_eq!(3u8.overflowing_pow(6), (217, bener));
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_pow(self, mut exp: u32) -> (Self, bool) {
            if exp == 0{
                return (1,false);
            }
            let mut base = self;
            let mut acc: Self = 1;
            let mut overflown = false;
            // Gosok papan kanggo nyimpen asil over_lun_mul.
            let mut r;

            while exp > 1 {
                if (exp & 1) == 1 {
                    r = acc.overflowing_mul(base);
                    acc = r.0;
                    overflown |= r.1;
                }
                exp /= 2;
                r = base.overflowing_mul(base);
                base = r.0;
                overflown |= r.1;
            }

            // wiwit exp!=0, pungkasane exp kudu 1.
            // Nangani bit pungkasan saka exponent kanthi kapisah, amarga kuadrat dhasar sawise iku ora prelu lan bisa nyebabake kebanjiran sing ora perlu.
            //
            //
            r = acc.overflowing_mul(base);
            r.1 |= overflown;

            r
        }

        /// Ngunggahake kekuwatan `exp`, nggunakake exponentiation kanthi kuadrat.
        ///
        /// # Examples
        ///
        /// Panggunaan dhasar:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".pow(5), 32);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc * base;
                }
                exp /= 2;
                base = base * base;
            }

            // wiwit exp!=0, pungkasane exp kudu 1.
            // Nangani bit pungkasan saka exponent kanthi kapisah, amarga kuadrat dhasar sawise iku ora prelu lan bisa nyebabake kebanjiran sing ora perlu.
            //
            //
            acc * base
        }

        /// Nindakake divisi Euclidean.
        ///
        /// Amarga, kanggo bilangan bulat positif, kabeh definisi umum divisi padha, iki padha karo `self / rhs`.
        ///
        ///
        /// # Panics
        ///
        /// Fungsi iki bakal panic yen `rhs` yaiku 0.
        ///
        /// # Examples
        ///
        /// Panggunaan dhasar:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(7", stringify!($SelfT), ".div_euclid(4), 1); // or any other integer type")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn div_euclid(self, rhs: Self) -> Self {
            self / rhs
        }


        /// Ngetung sisane paling sithik `self (mod rhs)`.
        ///
        /// Amarga, kanggo bilangan bulat positif, kabeh definisi umum divisi padha, iki padha karo `self % rhs`.
        ///
        ///
        /// # Panics
        ///
        /// Fungsi iki bakal panic yen `rhs` yaiku 0.
        ///
        /// # Examples
        ///
        /// Panggunaan dhasar:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(7", stringify!($SelfT), ".rem_euclid(4), 3); // or any other integer type")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn rem_euclid(self, rhs: Self) -> Self {
            self % rhs
        }

        /// Ngasilake `true` yen lan mung yen `self == 2^k` sawetara `k`.
        ///
        /// # Examples
        ///
        /// Panggunaan dhasar:
        ///
        /// ```
        #[doc = concat!("assert!(16", stringify!($SelfT), ".is_power_of_two());")]
        #[doc = concat!("assert!(!10", stringify!($SelfT), ".is_power_of_two());")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_is_power_of_two", since = "1.32.0")]
        #[inline]
        pub const fn is_power_of_two(self) -> bool {
            self.count_ones() == 1
        }

        // Ngasilake siji kurang saka kekuwatan sabanjure dadi loro.
        // (Kanggo 8u8 kekuwatan sabanjure yaiku 8u8 lan kanggo 6u8 yaiku 8u8)
        //
        // 8u8.one_less_than_next_power_of_two() ==7
        // 6u8.one_less_than_next_power_of_two() ==7
        //
        // Cara iki ora bisa kebanjiran, kaya ing kasus overflow `next_power_of_two`, mula ngasilake nilai maksimum jinis kasebut, lan bisa ngasilake 0 kanggo 0.
        //
        //
        #[inline]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        const fn one_less_than_next_power_of_two(self) -> Self {
            if self <= 1 { return 0; }

            let p = self - 1;
            // SAFETY: Amarga `p > 0`, nol ora kalebu kabeh nol.
            // Tegese shift kasebut mesthi ana ing wates, lan sawetara prosesor (kayata intel has-haswell) duwe intrinsik ctlz sing luwih efisien nalika argumen kasebut dudu nol.
            //
            //
            let z = unsafe { intrinsics::ctlz_nonzero(p) };
            <$SelfT>::MAX >> z
        }

        /// Ngasilake kekuwatan paling cilik saka loro sing luwih gedhe tinimbang utawa padha karo `self`.
        ///
        /// Nalika nilai bali kebanjiran (yaiku `self > (1 << (N-1))` kanggo jinis `uN`), panics ing mode debug lan nilai bali dibungkus dadi 0 ing mode rilis (mung kahanan sing bisa ngasilake 0).
        ///
        ///
        /// # Examples
        ///
        /// Panggunaan dhasar:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".next_power_of_two(), 2);")]
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".next_power_of_two(), 4);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn next_power_of_two(self) -> Self {
            self.one_less_than_next_power_of_two() + 1
        }

        /// Ngasilake kekuwatan paling cilik saka loro sing luwih gedhe tinimbang utawa padha karo `n`.
        /// Yen kekuwatan sabanjure loro luwih gedhe tinimbang nilai maksimum jinis, `None` bakal bali, yen kekuwatan loro dibungkus `Some`.
        ///
        ///
        /// # Examples
        ///
        /// Panggunaan dhasar:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".checked_next_power_of_two(), Some(2));")]
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".checked_next_power_of_two(), Some(4));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_next_power_of_two(), None);")]
        /// ```
        #[inline]
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        pub const fn checked_next_power_of_two(self) -> Option<Self> {
            self.one_less_than_next_power_of_two().checked_add(1)
        }

        /// Ngasilake kekuwatan paling cilik saka loro sing luwih gedhe tinimbang utawa padha karo `n`.
        /// Yen kekuwatan sabanjure, luwih gedhe tinimbang nilai maksimum jinis, nilai bali dibungkus dadi `0`.
        ///
        ///
        /// # Examples
        ///
        /// Panggunaan dhasar:
        ///
        /// ```
        /// #![feature(wrapping_next_power_of_two)]
        ///
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".wrapping_next_power_of_two(), 2);")]
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".wrapping_next_power_of_two(), 4);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.wrapping_next_power_of_two(), 0);")]
        /// ```
        #[unstable(feature = "wrapping_next_power_of_two", issue = "32463",
                   reason = "needs decision on wrapping behaviour")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        pub const fn wrapping_next_power_of_two(self) -> Self {
            self.one_less_than_next_power_of_two().wrapping_add(1)
        }

        /// Baliake perwakilan memori bilangan bulat iki minangka susunan bait kanthi urutan byte (network) big-endian.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_be_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $be_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn to_be_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_be().to_ne_bytes()
        }

        /// Baliake perwakilan memori nomer bulat iki minangka larik bait kanthi urutan byte sethitik-endian.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_le_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $le_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn to_le_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_le().to_ne_bytes()
        }

        /// Baliake perwakilan memori nomer bulat iki minangka larik bait kanthi urutan byte asli.
        ///
        /// Minangka endianness asli target platform digunakake, kode portabel kudu nggunakake [`to_be_bytes`] utawa [`to_le_bytes`], yen cocog.
        ///
        ///
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// [`to_be_bytes`]: Self::to_be_bytes
        /// [`to_le_bytes`]: Self::to_le_bytes
        ///
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_ne_bytes();")]
        /// assert_eq!(
        ///     bait, yen CFG! (target_endian= "big"){
        ///
        #[doc = concat!("        ", $be_bytes)]
        /// } liya {
        #[doc = concat!("        ", $le_bytes)]
        /// }
        /// );
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // SAFETY: muni amarga bilangan bulat minangka sawijining datatypes lawas sing biasa mula kita mesthi bisa
        // transmisi menyang susunan bait
        #[rustc_allow_const_fn_unstable(const_fn_transmute)]
        #[inline]
        pub const fn to_ne_bytes(self) -> [u8; mem::size_of::<Self>()] {
            // SAFETY: wilangan bulat minangka sawijining data lawas sing biyasa mula bisa ditularake
            // susunan bait
            unsafe { mem::transmute(self) }
        }

        /// Baliake perwakilan memori nomer bulat iki minangka larik bait kanthi urutan byte asli.
        ///
        ///
        /// [`to_ne_bytes`] kudu luwih becik tinimbang iki yen bisa.
        ///
        /// [`to_ne_bytes`]: Self::to_ne_bytes
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(num_as_ne_bytes)]
        #[doc = concat!("let num = ", $swap_op, stringify!($SelfT), ";")]
        /// ayo bait= num.as_ne_bytes();
        /// assert_eq!(
        ///     bait, yen CFG! (target_endian= "big"){
        ///
        #[doc = concat!("        &", $be_bytes)]
        /// } liya {
        #[doc = concat!("        &", $le_bytes)]
        /// }
        /// );
        /// ```
        #[unstable(feature = "num_as_ne_bytes", issue = "76976")]
        #[inline]
        pub fn as_ne_bytes(&self) -> &[u8; mem::size_of::<Self>()] {
            // SAFETY: wilangan bulat minangka sawijining data lawas sing biyasa mula bisa ditularake
            // susunan bait
            unsafe { &*(self as *const Self as *const _) }
        }

        /// Nggawe Nilai ongko endian native saka perwakilan minangka Uploaded bait ing endian amba.
        ///
        ///
        #[doc = $from_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_be_bytes(", $be_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// nggunakake std::convert::TryInto;
        #[doc = concat!("fn read_be_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * input=ngaso;
        #[doc = concat!("    ", stringify!($SelfT), "::from_be_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn from_be_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_be(Self::from_ne_bytes(bytes))
        }

        /// Gawe nilai angka bulat endian asli saka perwakilan minangka susunan byte ing endian cilik.
        ///
        ///
        #[doc = $from_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_le_bytes(", $le_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// nggunakake std::convert::TryInto;
        #[doc = concat!("fn read_le_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * input=ngaso;
        #[doc = concat!("    ", stringify!($SelfT), "::from_le_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn from_le_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_le(Self::from_ne_bytes(bytes))
        }

        /// Gawe nilai angka bulat endian asli saka perwakilan memori minangka susunan byte ing endianness asli.
        ///
        /// Minangka endianness native ing target platform kang digunakake, kode hotspot kamungkinan kepengin nggunakake [`from_be_bytes`] utawa [`from_le_bytes`], minangka cocok wae.
        ///
        ///
        /// [`from_be_bytes`]: Self::from_be_bytes
        /// [`from_le_bytes`]: Self::from_le_bytes
        ///
        ///
        ///
        #[doc = $from_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_ne_bytes(if cfg!(target_endian = \"big\") {")]
        #[doc = concat!("    ", $be_bytes, "")]
        /// } liya {
        #[doc = concat!("    ", $le_bytes, "")]
        /// });
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// nggunakake std::convert::TryInto;
        #[doc = concat!("fn read_ne_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * input=ngaso;
        #[doc = concat!("    ", stringify!($SelfT), "::from_ne_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // SAFETY: muni amarga bilangan bulat minangka sawijining datatypes lawas sing biasa mula kita mesthi bisa
        // transmute kanggo wong-wong mau
        #[rustc_allow_const_fn_unstable(const_fn_transmute)]
        #[inline]
        pub const fn from_ne_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            // SAFETY: wilangan bulat minangka sawijining data lawas sing biyasa mula bisa ditularake
            unsafe { mem::transmute(bytes) }
        }

        /// Kode anyar luwih seneng digunakake
        #[doc = concat!("[`", stringify!($SelfT), "::MIN", "`] instead.")]
        /// Ngasilake nilai paling cilik sing bisa diwakili dening jinis bilangan bulat iki.
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_promotable]
        #[inline(always)]
        #[rustc_const_stable(feature = "const_max_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MIN` associated constant on this type")]
        pub const fn min_value() -> Self { Self::MIN }

        /// Kode anyar luwih seneng digunakake
        #[doc = concat!("[`", stringify!($SelfT), "::MAX", "`] instead.")]
        /// Ngasilake nilai paling gedhe sing bisa diwakili dening jinis bilangan bulat iki.
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_promotable]
        #[inline(always)]
        #[rustc_const_stable(feature = "const_max_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MAX` associated constant on this type")]
        pub const fn max_value() -> Self { Self::MAX }
    }
}