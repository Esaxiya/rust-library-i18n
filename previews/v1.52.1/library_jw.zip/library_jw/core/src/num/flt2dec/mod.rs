/*!

Floating-point number to decimal conversion routines.

# Problem statement

We are given the floating-point number `v = f * 2^e` with an integer `f`,
and its bounds `minus` and `plus` such that any number between `v - minus` and
`v + plus` will be rounded to `v`. For the simplicity we assume that
this range is exclusive. Then we would like to get the unique decimal
representation `V = 0.d[0..n-1] * 10^k` such that:

- `d[0]` is non-zero.

- It's correctly rounded when parsed back: `v - minus < V < v + plus`.
  Furthermore it is shortest such one, i.e., there is no representation
  with less than `n` digits that is correctly rounded.

- It's closest to the original value: `abs(V - v) <= 10^(k-n) / 2`. Note that
  there might be two representations satisfying this uniqueness requirement,
  in which case some tie-breaking mechanism is used.

We will call this mode of operation as to the *shortest* mode. This mode is used
when there is no additional constraint, and can be thought as a "natural" mode
as it matches the ordinary intuition (it at least prints `0.1f32` as "0.1").

We have two more modes of operation closely related to each other. In these modes
we are given either the number of significant digits `n` or the last-digit
limitation `limit` (which determines the actual `n`), and we would like to get
the representation `V = 0.d[0..n-1] * 10^k` such that:

- `d[0]` is non-zero, unless `n` was zero in which case only `k` is returned.

- It's closest to the original value: `abs(V - v) <= 10^(k-n) / 2`. Again,
  there might be some tie-breaking mechanism.

When `limit` is given but not `n`, we set `n` such that `k - n = limit`
so that the last digit `d[n-1]` is scaled by `10^(k-n) = 10^limit`.
If such `n` is negative, we clip it to zero so that we will only get `k`.
We are also limited by the supplied buffer. This limitation is used to print
the number up to given number of fractional digits without knowing
the correct `k` beforehand.

We will call the mode of operation requiring `n` as to the *exact* mode,
and one requiring `limit` as to the *fixed* mode. The exact mode is a subset of
the fixed mode: the sufficiently large last-digit limitation will eventually fill
the supplied buffer and let the algorithm to return.

# Implementation overview

It is easy to get the floating point printing correct but slow (Russ Cox has
[demonstrated](http://research.swtch.com/ftoa) how it's easy), or incorrect but
fast (naïve division and modulo). But it is surprisingly hard to print
floating point numbers correctly *and* efficiently.

There are two classes of algorithms widely known to be correct.

- The "Dragon" family of algorithm is first described by Guy L. Steele Jr. and
  Jon L. White. They rely on the fixed-size big integer for their correctness.
  A slight improvement was found later, which is posthumously described by
  Robert G. Burger and R. Kent Dybvig. David Gay's `dtoa.c` routine is
  a popular implementation of this strategy.

- The "Grisu" family of algorithm is first described by Florian Loitsch.
  They use very cheap integer-only procedure to determine the close-to-correct
  representation which is at least guaranteed to be shortest. The variant,
  Grisu3, actively detects if the resulting representation is incorrect.

We implement both algorithms with necessary tweaks to suit our requirements.
In particular, published literatures are short of the actual implementation
difficulties like how to avoid arithmetic overflows. Each implementation,
available in `strategy::dragon` and `strategy::grisu` respectively,
extensively describes all necessary justifications and many proofs for them.
(It is still difficult to follow though. You have been warned.)

Both implementations expose two public functions:

- `format_shortest(decoded, buf)`, which always needs at least
  `MAX_SIG_DIGITS` digits of buffer. Implements the shortest mode.

- `format_exact(decoded, buf, limit)`, which accepts as small as
  one digit of buffer. Implements exact and fixed modes.

They try to fill the `u8` buffer with digits and returns the number of digits
written and the exponent `k`. They are total for all finite `f32` and `f64`
inputs (Grisu internally falls back to Dragon if necessary).

The rendered digits are formatted into the actual string form with
four functions:

- `to_shortest_str` prints the shortest representation, which can be padded by
  zeroes to make *at least* given number of fractional digits.

- `to_shortest_exp_str` prints the shortest representation, which can be
  padded by zeroes when its exponent is in the specified ranges,
  or can be printed in the exponential form such as `1.23e45`.

- `to_exact_exp_str` prints the exact representation with given number of
  digits in the exponential form.

- `to_exact_fixed_str` prints the fixed representation with *exactly*
  given number of fractional digits.

They all return a slice of preallocated `Part` array, which corresponds to
the individual part of strings: a fixed string, a part of rendered digits,
a number of zeroes or a small (`u16`) number. The caller is expected to
provide a large enough buffer and `Part` array, and to assemble the final
string from resulting `Part`s itself.

All algorithms and formatting functions are accompanied by extensive tests
in `coretests::num::flt2dec` module. It also shows how to use individual
functions.

*/

// nalika iki didokumentasikake kanthi akeh, iki minangka prinsip pribadi sing mung digawe umum kanggo nyoba.
// ojo mbabarake awake dhewe.
#![doc(hidden)]
#![unstable(
    feature = "flt2dec",
    reason = "internal routines only exposed for testing",
    issue = "none"
)]

pub use self::decoder::{decode, DecodableFloat, Decoded, FullDecoded};

use crate::mem::MaybeUninit;

pub mod decoder;
pub mod estimator;

/// Algoritma generasi Digit.
pub mod strategy {
    pub mod dragon;
    pub mod grisu;
}

/// Ukuran buffer minimal kanggo mode paling cendhak.
///
/// Kayane ora sepele kanggo dijupuk, nanging iki kalebu nomer maksimal digit desimal sing signifikan saka algoritma format kanthi asil paling cendhak.
///
/// Formula sing pas yaiku `ceil(# bits in mantissa * log_10 2 + 1)`.
pub const MAX_SIG_DIGITS: usize = 17;

/// Nalika `d` ngemot digit desimal, tambahi digit pungkasan lan tambahi nggawa.
/// Ngasilake digit sabanjure nalika nyebabake dawa diganti.
#[doc(hidden)]
pub fn round_up(d: &mut [u8]) -> Option<u8> {
    match d.iter().rposition(|&c| c != b'9') {
        Some(i) => {
            // d [i + 1..n] iku kabeh
            d[i] += 1;
            for j in i + 1..d.len() {
                d[j] = b'0';
            }
            None
        }
        None if d.len() > 0 => {
            // 999..999 babak dadi 1000..000 kanthi exponent sing tambah
            d[0] = b'1';
            for j in 1..d.len() {
                d[j] = b'0';
            }
            Some(b'0')
        }
        None => {
            // buffer kosong dibunderake (rada aneh nanging cukup)
            Some(b'1')
        }
    }
}

/// Bagéan sing wis diformat.
#[derive(Copy, Clone, PartialEq, Eq, Debug)]
pub enum Part<'a> {
    /// Nomer nol angka.
    Zero(usize),
    /// Nomer harfiah nganti 5 digit.
    Num(u16),
    /// Salinan kriya verba sing diwenehake.
    Copy(&'a [u8]),
}

impl<'a> Part<'a> {
    /// Ngasilake dawa bita saka bagean sing diwenehake.
    pub fn len(&self) -> usize {
        match *self {
            Part::Zero(nzeroes) => nzeroes,
            Part::Num(v) => {
                if v < 1_000 {
                    if v < 10 {
                        1
                    } else if v < 100 {
                        2
                    } else {
                        3
                    }
                } else {
                    if v < 10_000 { 4 } else { 5 }
                }
            }
            Part::Copy(buf) => buf.len(),
        }
    }

    /// Nyerat bagean menyang buffer sing disedhiyakake.
    /// Ngasilake nomer bait sing ditulis, utawa `None` yen buffer ora cukup.
    /// (Sampeyan isih bisa nyimpen bita sing ditulis kanthi sawetara ing buffer; aja gumantung karo iku.)
    pub fn write(&self, out: &mut [u8]) -> Option<usize> {
        let len = self.len();
        if out.len() >= len {
            match *self {
                Part::Zero(nzeroes) => {
                    for c in &mut out[..nzeroes] {
                        *c = b'0';
                    }
                }
                Part::Num(mut v) => {
                    for c in out[..len].iter_mut().rev() {
                        *c = b'0' + (v % 10) as u8;
                        v /= 10;
                    }
                }
                Part::Copy(buf) => {
                    out[..buf.len()].copy_from_slice(buf);
                }
            }
            Some(len)
        } else {
            None
        }
    }
}

/// Asil sing diformat ngemot siji utawa luwih bagean.
/// Iki bisa ditulis menyang buffer byte utawa diowahi dadi string sing dialokasikan.
#[allow(missing_debug_implementations)]
#[derive(Clone)]
pub struct Formatted<'a> {
    /// Irisan byte makili tandha, bisa uga `""`, `"-"` utawa `"+"`.
    pub sign: &'static str,
    /// Bagéan sing diformat kanggo diterjemahake sawise tandha lan bantalan nol opsional.
    pub parts: &'a [Part<'a>],
}

impl<'a> Formatted<'a> {
    /// Ngasilake dawa bita saka asil format sing dikombinasikake.
    pub fn len(&self) -> usize {
        let mut len = self.sign.len();
        for part in self.parts {
            len += part.len();
        }
        len
    }

    /// Nyerat kabeh bagean sing diformat menyang buffer sing disedhiyakake.
    /// Ngasilake nomer bait sing ditulis, utawa `None` yen buffer ora cukup.
    /// (Sampeyan isih bisa nyimpen bita sing ditulis kanthi sawetara ing buffer; aja gumantung karo iku.)
    pub fn write(&self, out: &mut [u8]) -> Option<usize> {
        if out.len() < self.sign.len() {
            return None;
        }
        out[..self.sign.len()].copy_from_slice(self.sign.as_bytes());

        let mut written = self.sign.len();
        for part in self.parts {
            let len = part.write(&mut out[written..])?;
            written += len;
        }
        Some(written)
    }
}

/// Format sing diwenehi angka desimal `0.<...buf...> * 10^exp` dadi bentuk desimal kanthi paling ora diwenehi nomer pecahan.
///
/// Asil disimpen ing larik bagean sing wis disedhiyakake lan irisan bagean sing ditulis bali.
///
/// `frac_digits` bisa kurang saka jumlah digit pecahan nyata ing `buf`;
/// bakal diabaikan lan digit kebak bakal dicithak.Mung digunakake kanggo nyithak angka tambahan nul saka digit sing diwenehake.
/// Mangkono `frac_digits` saka 0 tegese mung bakal nyithak digit tartamtu lan ora liya.
///
fn digits_to_dec_str<'a>(
    buf: &'a [u8],
    exp: i16,
    frac_digits: usize,
    parts: &'a mut [MaybeUninit<Part<'a>>],
) -> &'a [Part<'a>] {
    assert!(!buf.is_empty());
    assert!(buf[0] > b'0');
    assert!(parts.len() >= 4);

    // yen ana watesan ing posisi digit pungkasan, `buf` dianggep empuk kiwa karo nol virtual.
    // nomer nol virtual, `nzeroes`, padha karo `max(0, exp + frac_digits - buf.len())`, saengga posisi digit pungkasan `exp - buf.len() - nzeroes` ora luwih saka `-frac_digits`:
    //
    //
    //                       |<-virtual->|
    //       | <----buf----> |nul |exp
    //    0. 1 2 3 4 5 6 7 8 9 _ _ _ _ _ _ x 10
    //    |                  |           |
    // 10 ^ exp 10^(exp-buf.len()) 10^(exp-buf.len()-nzeroes)
    //
    // `nzeroes` diitung kanthi individual kanggo saben kasus supaya ora kebanjiran.
    //

    if exp <= 0 {
        // titik desimal sadurunge diwenehi digit: [0.][000...000][1234][____]
        let minus_exp = -(exp as i32) as usize;
        parts[0] = MaybeUninit::new(Part::Copy(b"0."));
        parts[1] = MaybeUninit::new(Part::Zero(minus_exp));
        parts[2] = MaybeUninit::new(Part::Copy(buf));
        if frac_digits > buf.len() && frac_digits - buf.len() > minus_exp {
            parts[3] = MaybeUninit::new(Part::Zero((frac_digits - buf.len()) - minus_exp));
            // SAFETY: kita mung miwiti unsur `..4`.
            unsafe { MaybeUninit::slice_assume_init_ref(&parts[..4]) }
        } else {
            // SAFETY: kita mung miwiti unsur `..3`.
            unsafe { MaybeUninit::slice_assume_init_ref(&parts[..3]) }
        }
    } else {
        let exp = exp as usize;
        if exp < buf.len() {
            // titik desimal ana ing digit sing diwenehake: [12][.][34][____]
            parts[0] = MaybeUninit::new(Part::Copy(&buf[..exp]));
            parts[1] = MaybeUninit::new(Part::Copy(b"."));
            parts[2] = MaybeUninit::new(Part::Copy(&buf[exp..]));
            if frac_digits > buf.len() - exp {
                parts[3] = MaybeUninit::new(Part::Zero(frac_digits - (buf.len() - exp)));
                // SAFETY: kita mung miwiti unsur `..4`.
                unsafe { MaybeUninit::slice_assume_init_ref(&parts[..4]) }
            } else {
                // SAFETY: kita mung miwiti unsur `..3`.
                unsafe { MaybeUninit::slice_assume_init_ref(&parts[..3]) }
            }
        } else {
            // titik desimal sawise diwenehi digit: [1234][____0000] utawa [1234][__][.][__].
            parts[0] = MaybeUninit::new(Part::Copy(buf));
            parts[1] = MaybeUninit::new(Part::Zero(exp - buf.len()));
            if frac_digits > 0 {
                parts[2] = MaybeUninit::new(Part::Copy(b"."));
                parts[3] = MaybeUninit::new(Part::Zero(frac_digits));
                // SAFETY: kita mung miwiti unsur `..4`.
                unsafe { MaybeUninit::slice_assume_init_ref(&parts[..4]) }
            } else {
                // SAFETY: kita mung miwiti unsur `..2`.
                unsafe { MaybeUninit::slice_assume_init_ref(&parts[..2]) }
            }
        }
    }
}

/// Formulir angka desimal `0.<...buf...> * 10^exp` dadi formulir eksponensial kanthi paling ora nomer digit pinunjul.
///
/// Nalika `upper` dadi `true`, exponent bakal diisi nganggo `E`;yen ora `e`.
/// Asil disimpen ing larik bagean sing wis disedhiyakake lan irisan bagean sing ditulis bali.
///
/// `min_digits` bisa kurang saka jumlah digit nyata ing `buf`;
/// bakal diabaikan lan digit kebak bakal dicithak.Mung digunakake kanggo nyithak angka tambahan nul saka digit sing diwenehake.
/// Dadi, `min_digits == 0` tegese mung bakal nyithak digit sing diwenehake lan ora ana liyane.
///
fn digits_to_exp_str<'a>(
    buf: &'a [u8],
    exp: i16,
    min_ndigits: usize,
    upper: bool,
    parts: &'a mut [MaybeUninit<Part<'a>>],
) -> &'a [Part<'a>] {
    assert!(!buf.is_empty());
    assert!(buf[0] > b'0');
    assert!(parts.len() >= 6);

    let mut n = 0;

    parts[n] = MaybeUninit::new(Part::Copy(&buf[..1]));
    n += 1;

    if buf.len() > 1 || min_ndigits > 1 {
        parts[n] = MaybeUninit::new(Part::Copy(b"."));
        parts[n + 1] = MaybeUninit::new(Part::Copy(&buf[1..]));
        n += 2;
        if min_ndigits > buf.len() {
            parts[n] = MaybeUninit::new(Part::Zero(min_ndigits - buf.len()));
            n += 1;
        }
    }

    // 0.1234 x 10 ^ exp= 1.234 x 10 ^ (exp-1)
    let exp = exp as i32 - 1; // aja mudhun nalika exp i16::MIN
    if exp < 0 {
        parts[n] = MaybeUninit::new(Part::Copy(if upper { b"E-" } else { b"e-" }));
        parts[n + 1] = MaybeUninit::new(Part::Num(-exp as u16));
    } else {
        parts[n] = MaybeUninit::new(Part::Copy(if upper { b"E" } else { b"e" }));
        parts[n + 1] = MaybeUninit::new(Part::Num(exp as u16));
    }
    // SAFETY: kita mung miwiti unsur `..n + 2`.
    unsafe { MaybeUninit::slice_assume_init_ref(&parts[..n + 2]) }
}

/// Opsi format tandha.
#[derive(Copy, Clone, PartialEq, Eq, Debug)]
pub enum Sign {
    /// Nyithak `-` mung kanggo nilai nol-nol sing negatif.
    Minus, // -inf -1 0 0 1 inf nan
    /// Nyithak `-` mung kanggo nilai negatif (kalebu nol negatif).
    MinusRaw, // -inf -1 -0 0 1 inf nan
    /// Nyithak `-` kanggo nilai nol-nol sing negatif, utawa `+` liya.
    MinusPlus, // -inf -1 +0 +0 +1 + inf nan
    /// Nyithak `-` kanggo nilai negatif apa wae (kalebu nol negatif), utawa `+` liya.
    MinusPlusRaw, // -inf -1 -0 +0 +1 + inf nan
}

/// Ngasilake string byte statis sing cocog karo tandha sing bakal diformat.
/// Bisa uga `""`, `"+"` utawa `"-"`.
fn determine_sign(sign: Sign, decoded: &FullDecoded, negative: bool) -> &'static str {
    match (*decoded, sign) {
        (FullDecoded::Nan, _) => "",
        (FullDecoded::Zero, Sign::Minus) => "",
        (FullDecoded::Zero, Sign::MinusRaw) => {
            if negative {
                "-"
            } else {
                ""
            }
        }
        (FullDecoded::Zero, Sign::MinusPlus) => "+",
        (FullDecoded::Zero, Sign::MinusPlusRaw) => {
            if negative {
                "-"
            } else {
                "+"
            }
        }
        (_, Sign::Minus | Sign::MinusRaw) => {
            if negative {
                "-"
            } else {
                ""
            }
        }
        (_, Sign::MinusPlus | Sign::MinusPlusRaw) => {
            if negative {
                "-"
            } else {
                "+"
            }
        }
    }
}

/// Format nomer titik ngambang sing diwenehake dadi bentuk desimal kanthi paling ora diwenehi nomer pecahan.
/// Asil disimpen ing macem-macem komponen sing diwenehake nalika nggunakake buffer byte minangka goresan.
/// `upper` saiki ora digunakake, nanging isih ana ing keputusan future kanggo ngganti kasus nilai non-finite, yaiku `inf` lan `nan`.
///
/// Bagean pisanan sing bakal digawe mesthi `Part::Sign` (sing bisa dadi senar kosong yen ora ana tandha sing diwenehake).
///
/// `format_shortest` kudu dadi fungsi generasi digit sing ndasari.
/// Sampeyan kudu ngasilake bagean saka buffer sing diwiwiti.
/// Sampeyan bisa uga pengin `strategy::grisu::format_shortest` kanggo iki.
///
/// `frac_digits` bisa kurang saka jumlah digit pecahan nyata ing `v`;
/// bakal diabaikan lan digit kebak bakal dicithak.Mung digunakake kanggo nyithak angka tambahan nul saka digit sing diwenehake.
/// Mangkono `frac_digits` saka 0 tegese mung bakal nyithak digit tartamtu lan ora liya.
///
/// Buffer byte paling dawa kudu `MAX_SIG_DIGITS` byte.
/// Paling ora kudu kasedhiya 4 bagean, amarga kasus paling ala kaya `[+][0.][0000][2][0000]` lan `frac_digits = 10`.
///
///
///
pub fn to_shortest_str<'a, T, F>(
    mut format_shortest: F,
    v: T,
    sign: Sign,
    frac_digits: usize,
    buf: &'a mut [MaybeUninit<u8>],
    parts: &'a mut [MaybeUninit<Part<'a>>],
) -> Formatted<'a>
where
    T: DecodableFloat,
    F: FnMut(&Decoded, &'a mut [MaybeUninit<u8>]) -> (&'a [u8], i16),
{
    assert!(parts.len() >= 4);
    assert!(buf.len() >= MAX_SIG_DIGITS);

    let (negative, full_decoded) = decode(v);
    let sign = determine_sign(sign, &full_decoded, negative);
    match full_decoded {
        FullDecoded::Nan => {
            parts[0] = MaybeUninit::new(Part::Copy(b"NaN"));
            // SAFETY: kita mung miwiti unsur `..1`.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Infinite => {
            parts[0] = MaybeUninit::new(Part::Copy(b"inf"));
            // SAFETY: kita mung miwiti unsur `..1`.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Zero => {
            if frac_digits > 0 {
                // [0.][0000]
                parts[0] = MaybeUninit::new(Part::Copy(b"0."));
                parts[1] = MaybeUninit::new(Part::Zero(frac_digits));
                Formatted {
                    sign,
                    // SAFETY: kita mung miwiti unsur `..2`.
                    parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..2]) },
                }
            } else {
                parts[0] = MaybeUninit::new(Part::Copy(b"0"));
                Formatted {
                    sign,
                    // SAFETY: kita mung miwiti unsur `..1`.
                    parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) },
                }
            }
        }
        FullDecoded::Finite(ref decoded) => {
            let (buf, exp) = format_shortest(decoded, buf);
            Formatted { sign, parts: digits_to_dec_str(buf, exp, frac_digits, parts) }
        }
    }
}

/// Format nomer titik ngambang sing diwenehake menyang bentuk desimal utawa bentuk eksponensial, gumantung karo eksponen sing diasilake.
/// Asil disimpen ing macem-macem komponen sing diwenehake nalika nggunakake buffer byte minangka goresan.
/// `upper` digunakake kanggo nemtokake kasus nilai non-finite (`inf` lan `nan`) utawa kasus prefenen awalan (`e` utawa `E`).
/// Bagean pisanan sing bakal digawe mesthi `Part::Sign` (sing bisa dadi senar kosong yen ora ana tandha sing diwenehake).
///
/// `format_shortest` kudu dadi fungsi generasi digit sing ndasari.
/// Sampeyan kudu ngasilake bagean saka buffer sing diwiwiti.
/// Sampeyan bisa uga pengin `strategy::grisu::format_shortest` kanggo iki.
///
/// `dec_bounds` minangka tupul `(lo, hi)` saengga angka kasebut diformat dadi desimal mung nalika `10^lo <= V < 10^hi`.
/// Elinga yen iki `V`*nyoto* tinimbang `v` nyata!Dadi, eksponen sing dicithak ing formulir eksponensial ora bisa ana ing kisaran iki, supaya ora ana kebingungan.
///
///
/// Buffer byte paling dawa kudu `MAX_SIG_DIGITS` byte.
/// Paling ora kudu kasedhiya 6 bagean, amarga kasus paling ala kaya `[+][1][.][2345][e][-][6]`.
///
///
///
///
///
pub fn to_shortest_exp_str<'a, T, F>(
    mut format_shortest: F,
    v: T,
    sign: Sign,
    dec_bounds: (i16, i16),
    upper: bool,
    buf: &'a mut [MaybeUninit<u8>],
    parts: &'a mut [MaybeUninit<Part<'a>>],
) -> Formatted<'a>
where
    T: DecodableFloat,
    F: FnMut(&Decoded, &'a mut [MaybeUninit<u8>]) -> (&'a [u8], i16),
{
    assert!(parts.len() >= 6);
    assert!(buf.len() >= MAX_SIG_DIGITS);
    assert!(dec_bounds.0 <= dec_bounds.1);

    let (negative, full_decoded) = decode(v);
    let sign = determine_sign(sign, &full_decoded, negative);
    match full_decoded {
        FullDecoded::Nan => {
            parts[0] = MaybeUninit::new(Part::Copy(b"NaN"));
            // SAFETY: kita mung miwiti unsur `..1`.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Infinite => {
            parts[0] = MaybeUninit::new(Part::Copy(b"inf"));
            // SAFETY: kita mung miwiti unsur `..1`.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Zero => {
            parts[0] = if dec_bounds.0 <= 0 && 0 < dec_bounds.1 {
                MaybeUninit::new(Part::Copy(b"0"))
            } else {
                MaybeUninit::new(Part::Copy(if upper { b"0E0" } else { b"0e0" }))
            };
            // SAFETY: kita mung miwiti unsur `..1`.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Finite(ref decoded) => {
            let (buf, exp) = format_shortest(decoded, buf);
            let vis_exp = exp as i32 - 1;
            let parts = if dec_bounds.0 as i32 <= vis_exp && vis_exp < dec_bounds.1 as i32 {
                digits_to_dec_str(buf, exp, 0, parts)
            } else {
                digits_to_exp_str(buf, exp, 0, upper, parts)
            };
            Formatted { sign, parts }
        }
    }
}

/// Ngasilake perkiraan sing rada ora sopan (wates ndhuwur) kanggo ukuran buffer maksimum sing diwilang saka eksponen sing didekode.
///
/// Watesan sing tepat yaiku:
///
/// - nalika `exp < 0`, dawane maksimal `ceil(log_10 (5^-exp * (2^64 - 1)))`.
/// - nalika `exp >= 0`, dawane maksimal `ceil(log_10 (2^exp * (2^64 - 1)))`.
///
/// `ceil(log_10 (x^exp * (2^64 - 1)))` kurang saka `ceil(log_10 (2^64 - 1)) + ceil(exp *log_10 x)`, sing siji luwih murah tinimbang `20 + (1 + exp* log_10 x)`.
/// Kita nggunakake kasunyatan sing `log_10 2 < 5/16` lan `log_10 5 < 12/16`, sing cukup kanggo tujuan kita.
///
/// Napa kita butuh iki?Fungsi `format_exact` bakal ngisi kabeh buffer kajaba diwatesi karo watesan digit pungkasan, nanging bisa uga jumlah digit sing dijaluk gedhe banget (ujar, 30.000 digit).
///
/// Sebagéyan gedhe buffer bakal diisi karo nol, mula kita ora pengin menehi alokasi kabeh buffer sadurunge.
/// Akibate, kanggo argumen apa wae,
/// 826 bait buffer kudu cukup kanggo `f64`.Bandingke karo nomer nyata kanggo kasus paling ala: 770 bait (nalika `exp = -1074`).
///
///
///
///
///
fn estimate_max_buf_len(exp: i16) -> usize {
    21 + ((if exp < 0 { -12 } else { 5 } * exp as i32) as usize >> 4)
}

/// Format sing diwenehi angka titik ngambang dadi wujud eksponensial kanthi jumlah digit pinunjul sing ditemtokake.
/// Asil disimpen ing macem-macem komponen sing diwenehake nalika nggunakake buffer byte minangka goresan.
/// `upper` digunakake kanggo nemtokake kasus awalan eksponen (`e` utawa `E`).
/// Bagean pisanan sing bakal digawe mesthi `Part::Sign` (sing bisa dadi senar kosong yen ora ana tandha sing diwenehake).
///
/// `format_exact` kudu dadi fungsi generasi digit sing ndasari.
/// Sampeyan kudu ngasilake bagean saka buffer sing diwiwiti.
/// Sampeyan bisa uga pengin `strategy::grisu::format_exact` kanggo iki.
///
/// Buffer byte paling ora kudu dawa `ndigits` byte kajaba `ndigits` gedhe banget mung nomer digit sing bakal ditulis.
/// (Titik tip kanggo `f64` udakara 800, mula 1000 bait kudu cukup.) Paling ora kudu ana 6 bagean, amarga kasus paling ala kaya `[+][1][.][2345][e][-][6]`.
///
///
///
///
///
pub fn to_exact_exp_str<'a, T, F>(
    mut format_exact: F,
    v: T,
    sign: Sign,
    ndigits: usize,
    upper: bool,
    buf: &'a mut [MaybeUninit<u8>],
    parts: &'a mut [MaybeUninit<Part<'a>>],
) -> Formatted<'a>
where
    T: DecodableFloat,
    F: FnMut(&Decoded, &'a mut [MaybeUninit<u8>], i16) -> (&'a [u8], i16),
{
    assert!(parts.len() >= 6);
    assert!(ndigits > 0);

    let (negative, full_decoded) = decode(v);
    let sign = determine_sign(sign, &full_decoded, negative);
    match full_decoded {
        FullDecoded::Nan => {
            parts[0] = MaybeUninit::new(Part::Copy(b"NaN"));
            // SAFETY: kita mung miwiti unsur `..1`.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Infinite => {
            parts[0] = MaybeUninit::new(Part::Copy(b"inf"));
            // SAFETY: kita mung miwiti unsur `..1`.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Zero => {
            if ndigits > 1 {
                // [0.][0000][e0]
                parts[0] = MaybeUninit::new(Part::Copy(b"0."));
                parts[1] = MaybeUninit::new(Part::Zero(ndigits - 1));
                parts[2] = MaybeUninit::new(Part::Copy(if upper { b"E0" } else { b"e0" }));
                Formatted {
                    sign,
                    // SAFETY: kita mung miwiti unsur `..3`.
                    parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..3]) },
                }
            } else {
                parts[0] = MaybeUninit::new(Part::Copy(if upper { b"0E0" } else { b"0e0" }));
                Formatted {
                    sign,
                    // SAFETY: kita mung miwiti unsur `..1`.
                    parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) },
                }
            }
        }
        FullDecoded::Finite(ref decoded) => {
            let maxlen = estimate_max_buf_len(decoded.exp);
            assert!(buf.len() >= ndigits || buf.len() >= maxlen);

            let trunc = if ndigits < maxlen { ndigits } else { maxlen };
            let (buf, exp) = format_exact(decoded, &mut buf[..trunc], i16::MIN);
            Formatted { sign, parts: digits_to_exp_str(buf, exp, ndigits, upper, parts) }
        }
    }
}

/// Format sing diwenehi nomer titik ngambang dadi bentuk desimal kanthi jumlah pecahan sing diwenehi angka.
/// Asil disimpen ing macem-macem komponen sing diwenehake nalika nggunakake buffer byte minangka goresan.
/// `upper` saiki ora digunakake, nanging isih ana ing keputusan future kanggo ngganti kasus nilai non-finite, yaiku `inf` lan `nan`.
/// Bagean pisanan sing bakal digawe mesthi `Part::Sign` (sing bisa dadi senar kosong yen ora ana tandha sing diwenehake).
///
/// `format_exact` kudu dadi fungsi generasi digit sing ndasari.
/// Sampeyan kudu ngasilake bagean saka buffer sing diwiwiti.
/// Sampeyan bisa uga pengin `strategy::grisu::format_exact` kanggo iki.
///
/// Buffer byte kudu cukup kanggo output kajaba `frac_digits` gedhe banget, mula mung angka tetep digit sing bakal ditulis.
/// (Tipping point kanggo `f64` udakara 800, lan 1000 bait kudu cukup.) Paling ora kudu ana 4 bagean, amarga kasus paling ala kaya `[+][0.][0000][2][0000]` karo `frac_digits = 10`.
///
///
///
///
///
pub fn to_exact_fixed_str<'a, T, F>(
    mut format_exact: F,
    v: T,
    sign: Sign,
    frac_digits: usize,
    buf: &'a mut [MaybeUninit<u8>],
    parts: &'a mut [MaybeUninit<Part<'a>>],
) -> Formatted<'a>
where
    T: DecodableFloat,
    F: FnMut(&Decoded, &'a mut [MaybeUninit<u8>], i16) -> (&'a [u8], i16),
{
    assert!(parts.len() >= 4);

    let (negative, full_decoded) = decode(v);
    let sign = determine_sign(sign, &full_decoded, negative);
    match full_decoded {
        FullDecoded::Nan => {
            parts[0] = MaybeUninit::new(Part::Copy(b"NaN"));
            // SAFETY: kita mung miwiti unsur `..1`.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Infinite => {
            parts[0] = MaybeUninit::new(Part::Copy(b"inf"));
            // SAFETY: kita mung miwiti unsur `..1`.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Zero => {
            if frac_digits > 0 {
                // [0.][0000]
                parts[0] = MaybeUninit::new(Part::Copy(b"0."));
                parts[1] = MaybeUninit::new(Part::Zero(frac_digits));
                Formatted {
                    sign,
                    // SAFETY: kita mung miwiti unsur `..2`.
                    parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..2]) },
                }
            } else {
                parts[0] = MaybeUninit::new(Part::Copy(b"0"));
                Formatted {
                    sign,
                    // SAFETY: kita mung miwiti unsur `..1`.
                    parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) },
                }
            }
        }
        FullDecoded::Finite(ref decoded) => {
            let maxlen = estimate_max_buf_len(decoded.exp);
            assert!(buf.len() >= maxlen);

            // bisa * bisa uga yen `frac_digits` gedhe banget.
            // `format_exact` bakal mungkasi rendering digit sadurunge, amarga kita winates banget karo `maxlen`.
            //
            let limit = if frac_digits < 0x8000 { -(frac_digits as i16) } else { i16::MIN };
            let (buf, exp) = format_exact(decoded, &mut buf[..maxlen], limit);
            if exp <= limit {
                // watesan ora bisa dipenuhi, mula iki bakal menehi nol kaya prakara `exp`.
                // iki ora kalebu kasus sing diwatesi mung sawise babak final;iku kasus biasa karo `exp = limit + 1`.
                //
                debug_assert_eq!(buf.len(), 0);
                if frac_digits > 0 {
                    // [0.][0000]
                    parts[0] = MaybeUninit::new(Part::Copy(b"0."));
                    parts[1] = MaybeUninit::new(Part::Zero(frac_digits));
                    Formatted {
                        sign,
                        // SAFETY: kita mung miwiti unsur `..2`.
                        parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..2]) },
                    }
                } else {
                    parts[0] = MaybeUninit::new(Part::Copy(b"0"));
                    Formatted {
                        sign,
                        // SAFETY: kita mung miwiti unsur `..1`.
                        parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) },
                    }
                }
            } else {
                Formatted { sign, parts: digits_to_dec_str(buf, exp, frac_digits, parts) }
            }
        }
    }
}