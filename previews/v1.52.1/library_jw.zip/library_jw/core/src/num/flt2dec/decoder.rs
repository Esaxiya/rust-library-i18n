//! Nulis angka titik ngambang dadi bagean lan kisaran kesalahan.

use crate::num::dec2flt::rawfp::RawFloat;
use crate::num::FpCategory;

/// Nilai terhingga sing ora ditandatangani, kayata:
///
/// - Nilai asli padha karo `mant * 2^exp`.
///
/// - Nomer apa wae saka `(mant - minus)*2^exp` nganti `(mant + plus)* 2^exp` bakal dibunderake dadi regane asline.
/// Rentang kalebu mung nalika `inclusive` yaiku `true`.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct Decoded {
    /// Mantissa skala.
    pub mant: u64,
    /// Rentang kesalahan ngisor.
    pub minus: u64,
    /// Rentang kesalahan ndhuwur.
    pub plus: u64,
    /// Eksponen sing dituduhake ing basis 2.
    pub exp: i16,
    /// Bener nalika sawetara kesalahan kalebu.
    ///
    /// Ing IEEE 754, iki bener nalika mantissa asli padha.
    pub inclusive: bool,
}

/// Nilai sing durung ditandatangani
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub enum FullDecoded {
    /// Not-a-number.
    Nan,
    /// Infinitas, positif utawa negatif.
    Infinite,
    /// Enol, positif utawa negatif.
    Zero,
    /// Nomer winates kanthi kolom sing wis diuripake.
    Finite(Decoded),
}

/// Jinis titik ngambang sing bisa `decode`d.
pub trait DecodableFloat: RawFloat + Copy {
    /// Nilai normal minimal minimum.
    fn min_pos_norm_value() -> Self;
}

impl DecodableFloat for f32 {
    fn min_pos_norm_value() -> Self {
        f32::MIN_POSITIVE
    }
}

impl DecodableFloat for f64 {
    fn min_pos_norm_value() -> Self {
        f64::MIN_POSITIVE
    }
}

/// Ngasilake tandha (bener yen negatif) lan nilai `FullDecoded` saka nomer titik ngambang sing diwenehake.
///
pub fn decode<T: DecodableFloat>(v: T) -> (/*negative?*/ bool, FullDecoded) {
    let (mant, exp, sign) = v.integer_decode();
    let even = (mant & 1) == 0;
    let decoded = match v.classify() {
        FpCategory::Nan => FullDecoded::Nan,
        FpCategory::Infinite => FullDecoded::Infinite,
        FpCategory::Zero => FullDecoded::Zero,
        FpCategory::Subnormal => {
            // tangga teparo: (mant, 2, exp)-(mant, exp)-(mant + 2, exp)
            // Float::integer_decode tansah ngreksa eksponen, mula mantissa ditrapake kanggo subnormal.
            //
            FullDecoded::Finite(Decoded { mant, minus: 1, plus: 1, exp, inclusive: even })
        }
        FpCategory::Normal => {
            let minnorm = <T as DecodableFloat>::min_pos_norm_value().integer_decode();
            if mant == minnorm.0 {
                // tanggi: (maxmant, exp, 1)-(minnormmant, exp)-(minnormmant + 1, exp)
                // ing endi maxmant=minnormmant * 2, 1
                FullDecoded::Finite(Decoded {
                    mant: mant << 2,
                    minus: 1,
                    plus: 2,
                    exp: exp - 2,
                    inclusive: even,
                })
            } else {
                // tangga teparo: (mant, 1, exp)-(mant, exp)-(mant + 1, exp)
                FullDecoded::Finite(Decoded {
                    mant: mant << 1,
                    minus: 1,
                    plus: 1,
                    exp: exp - 1,
                    inclusive: even,
                })
            }
        }
    };
    (sign < 0, decoded)
}