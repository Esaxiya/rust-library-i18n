//! Adaptasi Rust saka algoritma Grisu3 sing dijlentrehake ing "Cetak Nomer Angka Ngambang Cepet lan Akurat nganggo Integer" [^ 1].
//! Nggunakake udakara 1KB saka tabel sadurunge, lan sabanjure, cepet banget kanggo input sing paling akeh.
//!
//! [^1]: Florian Loitsch.2010. Nyithak nomer titik ngambang kanthi cepet lan
//!   akurat karo wilangan bulat.SIGPLAN Ora.45, 6 (Juni 2010), 233-243.
//!

use crate::mem::MaybeUninit;
use crate::num::diy_float::Fp;
use crate::num::flt2dec::{round_up, Decoded, MAX_SIG_DIGITS};

// deleng komentar ing `format_shortest_opt` kanggo nyoto.
#[doc(hidden)]
pub const ALPHA: i16 = -60;
#[doc(hidden)]
pub const GAMMA: i16 = -32;

/*
# the following Python code generates this table:
for i in xrange(-308, 333, 8):
    if i >= 0: f = 10**i; e = 0
    else: f = 2**(80-4*i) // 10 **-i;e=4* i, 80
    l = f.bit_length()
    f = ((f << 64 >> (l-1)) + 1) >> 1; e += l - 64
    print '    (%#018x, %5d, %4d),' % (f, e, i)
*/

#[doc(hidden)]
pub static CACHED_POW10: [(u64, i16, i16); 81] = [
    // (f, e, k)
    (0xe61acf033d1a45df, -1087, -308),
    (0xab70fe17c79ac6ca, -1060, -300),
    (0xff77b1fcbebcdc4f, -1034, -292),
    (0xbe5691ef416bd60c, -1007, -284),
    (0x8dd01fad907ffc3c, -980, -276),
    (0xd3515c2831559a83, -954, -268),
    (0x9d71ac8fada6c9b5, -927, -260),
    (0xea9c227723ee8bcb, -901, -252),
    (0xaecc49914078536d, -874, -244),
    (0x823c12795db6ce57, -847, -236),
    (0xc21094364dfb5637, -821, -228),
    (0x9096ea6f3848984f, -794, -220),
    (0xd77485cb25823ac7, -768, -212),
    (0xa086cfcd97bf97f4, -741, -204),
    (0xef340a98172aace5, -715, -196),
    (0xb23867fb2a35b28e, -688, -188),
    (0x84c8d4dfd2c63f3b, -661, -180),
    (0xc5dd44271ad3cdba, -635, -172),
    (0x936b9fcebb25c996, -608, -164),
    (0xdbac6c247d62a584, -582, -156),
    (0xa3ab66580d5fdaf6, -555, -148),
    (0xf3e2f893dec3f126, -529, -140),
    (0xb5b5ada8aaff80b8, -502, -132),
    (0x87625f056c7c4a8b, -475, -124),
    (0xc9bcff6034c13053, -449, -116),
    (0x964e858c91ba2655, -422, -108),
    (0xdff9772470297ebd, -396, -100),
    (0xa6dfbd9fb8e5b88f, -369, -92),
    (0xf8a95fcf88747d94, -343, -84),
    (0xb94470938fa89bcf, -316, -76),
    (0x8a08f0f8bf0f156b, -289, -68),
    (0xcdb02555653131b6, -263, -60),
    (0x993fe2c6d07b7fac, -236, -52),
    (0xe45c10c42a2b3b06, -210, -44),
    (0xaa242499697392d3, -183, -36),
    (0xfd87b5f28300ca0e, -157, -28),
    (0xbce5086492111aeb, -130, -20),
    (0x8cbccc096f5088cc, -103, -12),
    (0xd1b71758e219652c, -77, -4),
    (0x9c40000000000000, -50, 4),
    (0xe8d4a51000000000, -24, 12),
    (0xad78ebc5ac620000, 3, 20),
    (0x813f3978f8940984, 30, 28),
    (0xc097ce7bc90715b3, 56, 36),
    (0x8f7e32ce7bea5c70, 83, 44),
    (0xd5d238a4abe98068, 109, 52),
    (0x9f4f2726179a2245, 136, 60),
    (0xed63a231d4c4fb27, 162, 68),
    (0xb0de65388cc8ada8, 189, 76),
    (0x83c7088e1aab65db, 216, 84),
    (0xc45d1df942711d9a, 242, 92),
    (0x924d692ca61be758, 269, 100),
    (0xda01ee641a708dea, 295, 108),
    (0xa26da3999aef774a, 322, 116),
    (0xf209787bb47d6b85, 348, 124),
    (0xb454e4a179dd1877, 375, 132),
    (0x865b86925b9bc5c2, 402, 140),
    (0xc83553c5c8965d3d, 428, 148),
    (0x952ab45cfa97a0b3, 455, 156),
    (0xde469fbd99a05fe3, 481, 164),
    (0xa59bc234db398c25, 508, 172),
    (0xf6c69a72a3989f5c, 534, 180),
    (0xb7dcbf5354e9bece, 561, 188),
    (0x88fcf317f22241e2, 588, 196),
    (0xcc20ce9bd35c78a5, 614, 204),
    (0x98165af37b2153df, 641, 212),
    (0xe2a0b5dc971f303a, 667, 220),
    (0xa8d9d1535ce3b396, 694, 228),
    (0xfb9b7cd9a4a7443c, 720, 236),
    (0xbb764c4ca7a44410, 747, 244),
    (0x8bab8eefb6409c1a, 774, 252),
    (0xd01fef10a657842c, 800, 260),
    (0x9b10a4e5e9913129, 827, 268),
    (0xe7109bfba19c0c9d, 853, 276),
    (0xac2820d9623bf429, 880, 284),
    (0x80444b5e7aa7cf85, 907, 292),
    (0xbf21e44003acdd2d, 933, 300),
    (0x8e679c2f5e44ff8f, 960, 308),
    (0xd433179d9c8cb841, 986, 316),
    (0x9e19db92b4e31ba9, 1013, 324),
    (0xeb96bf6ebadf77d9, 1039, 332),
];

#[doc(hidden)]
pub const CACHED_POW10_FIRST_E: i16 = -1087;
#[doc(hidden)]
pub const CACHED_POW10_LAST_E: i16 = 1039;

#[doc(hidden)]
pub fn cached_power(alpha: i16, gamma: i16) -> (i16, Fp) {
    let offset = CACHED_POW10_FIRST_E as i32;
    let range = (CACHED_POW10.len() as i32) - 1;
    let domain = (CACHED_POW10_LAST_E - CACHED_POW10_FIRST_E) as i32;
    let idx = ((gamma as i32) - offset) * range / domain;
    let (f, e, k) = CACHED_POW10[idx as usize];
    debug_assert!(alpha <= e && e <= gamma);
    (k, Fp { f, e })
}

/// Yen diwenehi `x > 0`, ngasilake `(k, 10^k)` kaya `10^k <= x < 10^(k+1)`.
#[doc(hidden)]
pub fn max_pow10_no_more_than(x: u32) -> (u8, u32) {
    debug_assert!(x > 0);

    const X9: u32 = 10_0000_0000;
    const X8: u32 = 1_0000_0000;
    const X7: u32 = 1000_0000;
    const X6: u32 = 100_0000;
    const X5: u32 = 10_0000;
    const X4: u32 = 1_0000;
    const X3: u32 = 1000;
    const X2: u32 = 100;
    const X1: u32 = 10;

    if x < X4 {
        if x < X2 {
            if x < X1 { (0, 1) } else { (1, X1) }
        } else {
            if x < X3 { (2, X2) } else { (3, X3) }
        }
    } else {
        if x < X6 {
            if x < X5 { (4, X4) } else { (5, X5) }
        } else if x < X8 {
            if x < X7 { (6, X6) } else { (7, X7) }
        } else {
            if x < X9 { (8, X8) } else { (9, X9) }
        }
    }
}

/// Implementasi mode paling cendhak kanggo Grisu.
///
/// Ngasilake `None` nalika bakal ngasilake perwakilan sing ora nyata.
pub fn format_shortest_opt<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> Option<(/*digits*/ &'a [u8], /*exp*/ i16)> {
    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());
    assert!(buf.len() >= MAX_SIG_DIGITS);
    assert!(d.mant + d.plus < (1 << 61)); // kita butuh paling ora telung bit presisi tambahan

    // diwiwiti kanthi nilai normal karo exponent sing dituduhake
    let plus = Fp { f: d.mant + d.plus, e: d.exp }.normalize();
    let minus = Fp { f: d.mant - d.minus, e: d.exp }.normalize_to(plus.e);
    let v = Fp { f: d.mant, e: d.exp }.normalize_to(plus.e);

    // temokake `cached = 10^minusk` kaya `ALPHA <= minusk + plus.e + 64 <= GAMMA`.
    // wiwit `plus` dinormalisasi, iki tegese `2^(62 + ALPHA) <= plus * cached < 2^(64 + GAMMA)`;
    // amarga pilihan saka `ALPHA` lan `GAMMA`, iki ndadekake `plus * cached` dadi `[4, 2^32)`.
    //
    // mesthine kudu dimaksimalake `GAMMA - ALPHA`, supaya kita ora butuh kekuwatan cache 10, nanging ana sawetara pertimbangan:
    //
    //
    // 1. kita pengin tetep `floor(plus * cached)` ing `u32` amarga butuh divisi sing larang.
    //    (iki pancen ora bisa dicegah, sisane dibutuhake kanggo ngira akurasi.)
    // 2.
    // seko `floor(plus * cached)` bola-bali tambah ping 10, lan ora kebanjiran.
    //
    // sing pertama menehi `64 + GAMMA <= 32`, dene sing nomer loro menehi `10 * 2^-ALPHA <= 2^64`;
    // -60 lan -32 minangka kisaran maksimal kanthi kendala iki, lan V8 uga nggunakake.
    let (minusk, cached) = cached_power(ALPHA - plus.e - 64, GAMMA - plus.e - 64);

    // skala fps.iki menehi kesalahan maksimal 1 ulp (kabukten saka Teorema 5.1).
    let plus = plus.mul(&cached);
    let minus = minus.mul(&cached);
    let v = v.mul(&cached);
    debug_assert_eq!(plus.e, minus.e);
    debug_assert_eq!(plus.e, v.e);

    // +-kisaran nyata minus
    //   | <---|---------------------- unsafe region --------------------------> |
    //   |     |                                                                 |
    //   |  |<--->|  | <--------------- safe region ---------------> |           |
    //   |  |     |  |                                               |           |
    //   | 1 ulp | 1 ulp || 1 ulp | 1 ulp || 1 ulp | 1 ulp |
    //   |<--->|<--->|                 |<--->|<--->|                 |<--->|<--->|
    //   |-----|-----|-------...-------|-----|-----|-------...-------|-----|-----|
    //   |   minus   |                 |     v     |                 |   plus    | minus1     minus0           v - 1 ulp   v + 1 ulp           plus0       plus1
    //
    //
    // sadhuwure `minus`, `v` lan `plus` minangka *jumlah* perkiraan (kesalahan <1 ulp).
    // amarga ora ngerti kesalahan kasebut positif utawa negatif, mula nggunakake rong prakiraan jarak sing padha lan duwe kesalahan maksimal 2 ulps.
    //
    // "unsafe region" minangka interval liberal sing wiwitane digawe.
    // "safe region" minangka interval konservatif sing mung ditampa.
    // kita miwiti karo repr sing bener ing wilayah sing ora aman, lan nyoba golek repr sing paling cedhak karo `v` sing uga ana ing wilayah sing aman.
    // yen ora bisa, kita nyerah.
    //
    let plus1 = plus.f + 1;
    // ayo plus0 = plus.f, 1;//mung kanggo panjelasan ayo minus0 = minus.f + 1;//mung kanggo panjelasan
    //
    let minus1 = minus.f - 1;
    let e = -plus.e as usize; // exponent bareng

    // dibagi `plus1` dadi bagean integral lan fraksional.
    // bagean integral dijamin pas karo u32, amarga daya cache njamin `plus < 2^32` lan `plus.f` normalisasi mesthi kurang saka `2^64 - 2^4` amarga sarat presisi.
    //
    let plus1int = (plus1 >> e) as u32;
    let plus1frac = plus1 & ((1 << e) - 1);

    // ngetung `10^max_kappa` paling gedhe ora luwih saka `plus1` (saengga `plus1 < 10^(max_kappa+1)`).
    // iki wates ndhuwur `kappa` ing ngisor iki.
    let (max_kappa, max_ten_kappa) = max_pow10_no_more_than(plus1int);

    let mut i = 0;
    let exp = max_kappa as i16 - minusk + 1;

    // Teorema 6.2: yen `k` minangka bilangan bulat paling gedhe
    // `0 <= y mod 10^k <= y - x`,              banjur `V = floor(y / 10^k) * 10^k` ana ing `[x, y]` lan salah sawijining representasi paling cendhak (kanthi nomer minimal digit) ing kisaran kasebut.
    //
    //
    // temokake dawa digit `kappa` ing antarane `(minus1, plus1)` kaya miturut Teorema 6.2.
    // Teorema 6.2 bisa digunakake kanggo ngilangi `x` kanthi mbutuhake `y mod 10^k < y - x`.
    // (eg, `x` =32000, `y` =32777; `kappa` =2 wiwit `y mod 10 ^ 3=777 <y, x=777`.) Algoritma kasebut gumantung ing tahap verifikasi mengko kanggo ngilangi `y`.
    //
    let delta1 = plus1 - minus1;
    // ayo delta1int=(delta1>> e) minangka usize;//mung kanggo panjelasan
    let delta1frac = delta1 & ((1 << e) - 1);

    // menehi bagean integral, nalika mriksa akurasi ing saben langkah.
    let mut kappa = max_kappa as i16;
    let mut ten_kappa = max_ten_kappa; // 10^kappa
    let mut remainder = plus1int; // digit sing durung diwenehake
    loop {
        // kita mesthi duwe paling ora siji digit sing bakal diwenehake, minangka undhangan `plus1 >= 10^kappa`:
        // - `delta1int <= remainder < 10^(kappa+1)`
        // - `plus1int = d[0..n-1] * 10^(kappa+1) + remainder`   (nderek `remainder = plus1int % 10^(kappa+1)`)
        //
        //

        // dibagi `remainder` karo `10^kappa`.kalorone skala dening `2^-e`.
        let q = remainder / ten_kappa;
        let r = remainder % ten_kappa;
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        let plus1rem = ((r as u64) << e) + plus1frac; // ==(plus1% 10 ^ kappa) * 2 ^ e
        if plus1rem < delta1 {
            // `plus1 % 10^kappa < delta1 = plus1 - minus1`; kita wis nemokake `kappa` sing bener.
            let ten_kappa = (ten_kappa as u64) << e; // skala 10 ^ kappa bali menyang eksponen sing dituduhake
            return round_and_weed(
                // SAFETY: memori diwiwiti ing ndhuwur.
                unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) },
                exp,
                plus1rem,
                delta1,
                plus1 - v.f,
                ten_kappa,
                1,
            );
        }

        // break loop nalika wis nggawe kabeh digit integral.
        // jumlah digit sing pas yaiku `max_kappa + 1` dadi `plus1 < 10^(max_kappa+1)`.
        if i > max_kappa as usize {
            debug_assert_eq!(ten_kappa, 1);
            debug_assert_eq!(kappa, 0);
            break;
        }

        // mulihake invariants
        kappa -= 1;
        ten_kappa /= 10;
        remainder = r;
    }

    // menehi bagean pecahan, nalika mriksa akurasi ing saben langkah.
    // wektu iki kita gumantung karo perkalian sing bola-bali, amarga divisi bakal kelangan presisi.
    let mut remainder = plus1frac;
    let mut threshold = delta1frac;
    let mut ulp = 1;
    loop {
        // digit sabanjure kudu signifikan amarga kita wis nyoba sadurunge ngilangi invarian, ing endi `m = max_kappa + 1` (#digit ing bagean integral):
        //
        // - `remainder < 2^e`
        // - `plus1frac * 10^(n-m) = d[m..n-1] * 2^e + remainder`

        remainder *= 10; // ora bakal kebanjiran, `2^e * 10 < 2^64`
        threshold *= 10;
        ulp *= 10;

        // dibagi `remainder` karo `10^kappa`.
        // kalorone skala dening `2^e / 10^kappa`, mula sing terakhir implisit ing kene.
        let q = remainder >> e;
        let r = remainder & ((1 << e) - 1);
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        if r < threshold {
            let ten_kappa = 1 << e; // pembagi implisit
            return round_and_weed(
                // SAFETY: memori diwiwiti ing ndhuwur.
                unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) },
                exp,
                r,
                threshold,
                (plus1 - v.f) * ulp,
                ten_kappa,
                ulp,
            );
        }

        // mulihake invariants
        kappa -= 1;
        remainder = r;
    }

    // kita wis ngasilake kabeh digit pinunjul `plus1`, nanging ora yakin manawa sing paling optimal.
    // contone, yen `minus1` yaiku 3.14153 ... lan `plus1` yaiku 3.14158 ..., ana 5 perwakilan paling ringkes beda saka 3.14154 dadi 3.14158 nanging mung duwe sing paling gedhe.
    // kita kudu terus nyuda digit pungkasan lan mriksa manawa iki repr optimal.
    // paling ora ana 9 calon (..1 nganti ..9), mula iki cukup cepet.(Phase "rounding")
    //
    // fungsi mriksa manawa repr "optimal" iki sejatine ana ing kisaran ulp, lan uga bisa uga manawa repr "second-to-optimal" bisa optimal amarga ana kesalahan pambulatan.
    // ing kalorone kasus iki ngasilake `None`.
    // (Phase "weeding")
    //
    // kabeh argumen ing kene diukur kanthi nilai `k` umum (nanging implisit), saengga:
    // - `remainder = (plus1 % 10^kappa) * k`
    // - `threshold = (plus1 - minus1) * k` (lan uga, `remainder < threshold`)
    // - `plus1v = (plus1 - v) * k` (lan uga, `threshold > plus1v` saka invarian sadurunge)
    // - `ten_kappa = 10^kappa * k`
    // - `ulp = 2^-e * k`
    //
    fn round_and_weed(
        buf: &mut [u8],
        exp: i16,
        remainder: u64,
        threshold: u64,
        plus1v: u64,
        ten_kappa: u64,
        ulp: u64,
    ) -> Option<(&[u8], i16)> {
        assert!(!buf.is_empty());

        // ngasilake rong perkiraan menyang `v` (asline `plus1 - v`) ing njero 1.5 ulps.
        // perwakilan sing diasilake kudu dadi representasi paling cedhak kanggo kalorone.
        //
        // ing kene `plus1 - v` digunakake amarga petungan rampung karo `plus1` supaya ora overflow/underflow (mula jeneng-jeneng kasebut katon ganti).
        //
        let plus1v_down = plus1v + ulp; // plus1 - (v, 1 ulp)
        let plus1v_up = plus1v - ulp; // plus1 - (v + 1 ulp)

        // nyuda digit pungkasan lan mandheg ing perwakilan paling cedhak karo `v + 1 ulp`.
        let mut plus1w = remainder; // plus1w(n) = plus1, w(n)
        {
            let last = buf.last_mut().unwrap();

            // kita nggarap angka `w(n)` sing kira-kira, sing wiwitane padha karo `plus1 - plus1 % 10^kappa`.sawise mlaku awak daur ulang `n` kaping, `w(n) = plus1 - plus1 % 10^kappa - n * 10^kappa`.
            // kita nyetel `plus1w(n) = plus1 - w(n) = plus1 % 10^kappa + n * 10^kappa` (kanthi mangkono `sisane= plus1w(0)`) kanggo nyederhanakake kir.
            // elinga yen `plus1w(n)` mesthi saya tambah.
            //
            // kita duwe telung syarat kanggo mungkasi.ana sing bakal nggawe loop ora bisa dilanjutake, nanging kita paling ora duwe perwakilan sing valid sing paling cedhak karo `v + 1 ulp`.
            // kita bakal menehi tandha minangka TC1 nganti TC3 amarga luwih ringkes.
            //
            // TC1: `w(n) <= v + 1 ulp`, yaiku, iki repr pungkasan sing bisa dadi sing paling cedhak.
            // iki padha karo `plus1 - w(n) = plus1w(n) >= plus1 - (v + 1 ulp) = plus1v_up`.
            // digabungake karo TC2 (kang kir yen `w(n+1)` is valid), ngalangi iki bisa kebanjiran ing pitungan `plus1w(n)`.
            //
            // TC2: `w(n+1) < minus1`, yaiku repr sabanjure ora bisa dibentuk nganti `v`.
            // iki padha karo `plus1 - w(n) + 10^kappa = plus1w(n) + 10^kappa > plus1 - minus1 = threshold`.
            // sisih kiwa bisa kebanjiran, nanging kita ngerti `threshold > plus1v`, dadi yen TC1 salah, `threshold - plus1w(n) > threshold - (plus1v - 1 ulp) > 1 ulp` lan kita bisa nyoba yen `threshold - plus1w(n) < 10^kappa` kanthi aman.
            //
            //
            // TC3: `abs(w(n) - (v + 1 ulp)) <= abs(w(n+1) - (v + 1 ulp))`, yaiku repr sabanjure
            // ora luwih cedhak karo `v + 1 ulp` tinimbang repr saiki.
            // diwenehi `z(n) = plus1v_up - plus1w(n)`, iki dadi `abs(z(n)) <= abs(z(n+1))`.maneh assuming yen TC1 iku salah, kita duwe `z(n) > 0`.kita duwe rong kasus sing kudu dipikirake:
            //
            // - nalika `z(n+1) >= 0`: TC3 dadi `z(n) <= z(n+1)`.
            // amarga `plus1w(n)` saya tambah, `z(n)` mesthine bakal mudhun lan iki jelas salah.
            // - nalika `z(n+1) < 0`:
            //   - TC3a: precondition yaiku `plus1v_up < plus1w(n) + 10^kappa`.nganggep TC2 iku salah, `threshold >= plus1w(n) + 10^kappa` dadi ora bisa kebanjiran.
            //   - TC3b: TC3 dadi `z(n) <= -z(n+1)`, yaiku `plus1v_up - plus1w(n) >=     plus1w(n+1) - plus1v_up = plus1w(n) + 10^kappa - plus1v_up`.
            //   TC1 sing ditegesi menehi `plus1v_up > plus1w(n)`, mula ora bisa kebanjiran utawa mlebu arus nalika digabung karo TC3a.
            //
            // Akibate, kita kudu mandheg nalika `TC1 || TC2 || (TC3a && TC3b)`.ing ngisor iki padha karo kuwalik, `!TC1 && !TC2 && (!TC3a || !TC3b)`.
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            while plus1w < plus1v_up
                && threshold - plus1w >= ten_kappa
                && (plus1w + ten_kappa < plus1v_up
                    || plus1v_up - plus1w >= plus1w + ten_kappa - plus1v_up)
            {
                *last -= 1;
                debug_assert!(*last > b'0'); // repr paling cedhak ora bisa mungkasi karo `0`
                plus1w += ten_kappa;
            }
        }

        // priksa manawa perwakilan iki uga minangka perwakilan paling cedhak karo `v - 1 ulp`.
        //
        // iki mung padha karo kahanan sing mandheg kanggo `v + 1 ulp`, kanthi kabeh `plus1v_up` diganti `plus1v_down`.
        // analisis kebanjiran uga nduweni.
        if plus1w < plus1v_down
            && threshold - plus1w >= ten_kappa
            && (plus1w + ten_kappa < plus1v_down
                || plus1v_down - plus1w >= plus1w + ten_kappa - plus1v_down)
        {
            return None;
        }

        // saiki kita duwe perwakilan paling cedhak karo `v` antarane `plus1` lan `minus1`.
        // iki pancen liberal, mula kita nolak `w(n)` ora antara `plus0` lan `minus0`, yaiku `plus1 - plus1w(n) <= minus0` utawa `plus1 - plus1w(n) >= plus0`.
        // kita nggunakake kasunyatan sing `threshold = plus1 - minus1` lan `plus1 - plus0 = minus0 - minus1 = 2 ulp`.
        //
        if 2 * ulp <= plus1w && plus1w <= threshold - 4 * ulp { Some((buf, exp)) } else { None }
    }
}

/// Implementasi mode paling cendhak kanggo Grisu kanthi fallback Dragon.
///
/// Iki kudu digunakake ing pirang-pirang kasus.
pub fn format_shortest<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    use crate::num::flt2dec::strategy::dragon::format_shortest as fallback;
    // SAFETY: Checker utang ora cukup pinter supaya bisa nggunakake `buf`
    // ing branch kapindho, mula kita ora bisa urip ing kene.
    // Nanging kita mung nggunakake maneh `buf` yen `format_shortest_opt` ngasilake `None` dadi ora apa-apa.
    match format_shortest_opt(d, unsafe { &mut *(buf as *mut _) }) {
        Some(ret) => ret,
        None => fallback(d, buf),
    }
}

/// Implementasi mode sing tepat lan tetep kanggo Grisu.
///
/// Ngasilake `None` nalika bakal ngasilake perwakilan sing ora nyata.
pub fn format_exact_opt<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> Option<(/*digits*/ &'a [u8], /*exp*/ i16)> {
    assert!(d.mant > 0);
    assert!(d.mant < (1 << 61)); // kita butuh paling ora telung bit presisi tambahan
    assert!(!buf.is_empty());

    // normal lan skala `v`.
    let v = Fp { f: d.mant, e: d.exp }.normalize();
    let (minusk, cached) = cached_power(ALPHA - v.e - 64, GAMMA - v.e - 64);
    let v = v.mul(&cached);

    // dibagi `v` dadi bagean integral lan fraksional.
    let e = -v.e as usize;
    let vint = (v.f >> e) as u32;
    let vfrac = v.f & ((1 << e) - 1);

    // kaloro `v` lawas lan `v` anyar (skala dening `10^-k`) duwe kesalahan <1 ulp (Theorem 5.1).
    // amarga ora ngerti kesalahan kasebut positif utawa negatif, mula nggunakake rong prakiraan jarak sing padha lan duwe kesalahan maksimal 2 ulps (padha karo kasus paling cedhak).
    //
    //
    // tujuane yaiku nemokake seri digit sing dibunderaké kanthi umum kanggo `v - 1 ulp` lan `v + 1 ulp`, saengga kita bisa yakin kanthi maksimal.
    // yen ora bisa ditindakake, kita ora ngerti output sing bener kanggo `v`, mula kita nyerah lan mundur maneh.
    //
    // `err` ditetepake minangka `1 ulp * 2^e` ing kene (padha karo ulp ing `vfrac`), lan kita bakal ngukur kapan `v` skala.
    //
    //
    //
    let mut err = 1;

    // ngetung `10^max_kappa` paling gedhe ora luwih saka `v` (saengga `v < 10^(max_kappa+1)`).
    // iki wates ndhuwur `kappa` ing ngisor iki.
    let (max_kappa, max_ten_kappa) = max_pow10_no_more_than(vint);

    let mut i = 0;
    let exp = max_kappa as i16 - minusk + 1;

    // yen kita nggarap watesan digit pungkasan, kita kudu nyuda buffer sadurunge menehi rendering supaya bisa ora dibunderaké kaping pindho.
    //
    // elinga yen kita kudu nambah buffer maneh nalika ana kedadeyan!
    let len = if exp <= limit {
        // oops, kita malah ora bisa ngasilake *siji* digit.
        // iki bisa ditindakake, saupama kita duwe kaya 9.5 lan dibunderake dadi 10.
        //
        // Sejatine, kita bisa langsung nelpon `possibly_round` kanthi buffer kosong, nanging skala `max_ten_kappa << e` nganti 10 bisa nyebabake kebanjiran.
        //
        // mula kita dadi ora sopan ing kene lan nggedhekake kisaran kesalahan kanthi faktor 10.
        // iki bakal nambah tarif negatif sing salah, nanging mung rada,*banget*;
        // mung bisa ditemokake nalika mantissa luwih gedhe tinimbang 60 bit.
        //
        // SAFETY: `len=0`, dadi kewajiban milih memori iki sepele.
        return unsafe {
            possibly_round(buf, 0, exp, limit, v.f / 10, (max_ten_kappa as u64) << e, err << e)
        };
    } else if ((exp as i32 - limit as i32) as usize) < buf.len() {
        (exp - limit) as usize
    } else {
        buf.len()
    };
    debug_assert!(len > 0);

    // nggawe bagean integral.
    // kesalahan kabeh pecahan, dadi kita ora prelu mriksa ing bagean iki.
    let mut kappa = max_kappa as i16;
    let mut ten_kappa = max_ten_kappa; // 10^kappa
    let mut remainder = vint; // digit sing durung diwenehake
    loop {
        // kita mesthi duwe paling ora siji digit kanggo menehi invariants:
        // - `remainder < 10^(kappa+1)`
        // - `vint = d[0..n-1] * 10^(kappa+1) + remainder`   (nderek `remainder = vint % 10^(kappa+1)`)
        //
        //

        // dibagi `remainder` karo `10^kappa`.kalorone skala dening `2^-e`.
        let q = remainder / ten_kappa;
        let r = remainder % ten_kappa;
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        // apa buffer wis kebak?mbukak babak bunder karo turahan.
        if i == len {
            let vrem = ((r as u64) << e) + vfrac; // ==(v% 10 ^ kappa) * 2 ^ e
            // SAFETY: kita wis miwiti `len` akeh bait.
            return unsafe {
                possibly_round(buf, len, exp, limit, vrem, (ten_kappa as u64) << e, err << e)
            };
        }

        // break loop nalika wis nggawe kabeh digit integral.
        // jumlah digit sing pas yaiku `max_kappa + 1` dadi `plus1 < 10^(max_kappa+1)`.
        if i > max_kappa as usize {
            debug_assert_eq!(ten_kappa, 1);
            debug_assert_eq!(kappa, 0);
            break;
        }

        // mulihake invariants
        kappa -= 1;
        ten_kappa /= 10;
        remainder = r;
    }

    // nggawe bagean pecahan.
    //
    // ing asas kita bisa terus menyang digit pungkasan sing kasedhiya lan mriksa akurasi.
    // sayangé, kita nggunakake bilangan bulat kanthi ukuran, mula kita butuh kriteria kanggo ndeteksi kebanjiran.
    // V8 nggunakake `remainder > err`, sing dadi salah nalika `i` angka pinunjul pisanan `v - 1 ulp` lan `v` beda.
    // nanging iki nolak akeh banget input sing bener.
    //
    // amarga fase mengko nduwe deteksi overflow sing bener, luwih becik nggunakake kriteria sing luwih ketat:
    // kita terus nganti `err` ngluwihi `10^kappa / 2`, mula kisaran antara `v - 1 ulp` lan `v + 1 ulp` mesthi ngemot loro utawa luwih perwakilan bunder.
    //
    // iki padha karo rong perbandingan pertama `possibly_round`, kanggo referensi.
    //
    let mut remainder = vfrac;
    let maxerr = 1 << (e - 1);
    while err < maxerr {
        // invarian, ing endi `m = max_kappa + 1` (#digit ing bagean integral):
        // - `remainder < 2^e`
        // - `vfrac * 10^(n-m) = d[m..n-1] * 2^e + remainder`
        // - `err = 10^(n-m)`

        remainder *= 10; // ora bakal kebanjiran, `2^e * 10 < 2^64`
        err *= 10; // ora bakal kebanjiran, `err * 10 < 2^e * 5 < 2^64`

        // dibagi `remainder` karo `10^kappa`.
        // kalorone skala dening `2^e / 10^kappa`, mula sing terakhir implisit ing kene.
        let q = remainder >> e;
        let r = remainder & ((1 << e) - 1);
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        // apa buffer wis kebak?mbukak babak bunder karo turahan.
        if i == len {
            // SAFETY: kita wis miwiti `len` akeh bait.
            return unsafe { possibly_round(buf, len, exp, limit, r, 1 << e, err) };
        }

        // mulihake invariants
        remainder = r;
    }

    // pitungan luwih lanjut ora ana gunane (`possibly_round` mesthi gagal), mula kita nyerah.
    return None;

    // kita wis ngasilake kabeh digit `v` sing dijaluk, sing kudu padha karo digit `v - 1 ulp` sing cocog.
    // saiki kita mriksa manawa ana perwakilan unik sing dituduhake dening `v - 1 ulp` lan `v + 1 ulp`;iki bisa dadi padha karo digit sing digawe, utawa kanggo versi sing dibunderaké saka digit kasebut.
    //
    // yen kisaran kasebut ngemot pirang-pirang perwakilan kanthi dawa sing padha, kita ora bakal mesthine kudu bali `None`.
    //
    // kabeh argumen ing kene diukur kanthi nilai `k` umum (nanging implisit), saengga:
    // - `remainder = (v % 10^kappa) * k`
    // - `ten_kappa = 10^kappa * k`
    // - `ulp = 2^-e * k`
    //
    // SAFETY: bait `len` pertama `buf` kudu diwiwiti.
    //
    unsafe fn possibly_round(
        buf: &mut [MaybeUninit<u8>],
        mut len: usize,
        mut exp: i16,
        limit: i16,
        remainder: u64,
        ten_kappa: u64,
        ulp: u64,
    ) -> Option<(&[u8], i16)> {
        debug_assert!(remainder < ten_kappa);

        // 10^kappa
        //    :   :   :<->:   :
        //    :   :   :   :   :
        //    : | 1 ulp | 1 ulp |:
        //    :|<--->|<--->|  :
        // ----|-----|-----|----
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // (kanggo referensi, garis burik nuduhake nilai sing tepat kanggo kemungkinan representasi ing jumlah digit.)
        //
        //
        // kesalahan gedhe banget, paling ora ana telung kemungkinan representasi antara `v - 1 ulp` lan `v + 1 ulp`.
        // kita ora bisa nemtokake endi sing bener.
        //
        if ulp >= ten_kappa {
            return None;
        }

        // 10^kappa
        //   :<------->:
        //   :         :
        //   : | 1 ulp | 1 ulp |
        //   : |<--->|<--->|
        // ----|-----|-----|----
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // nyatane, 1/2 ulp cukup kanggo ngenalake rong kemungkinan representasi.
        // (elinga yen kita butuh perwakilan unik kanggo `v - 1 ulp` lan `v + 1 ulp`.) iki ora bakal kebanjiran, amarga `ulp < ten_kappa` saka pamriksan pisanan.
        //
        //
        if ten_kappa - ulp <= ulp {
            return None;
        }

        // remainder
        //       :<->|                           :
        //       :   |                           :
        //       : <---------10 ^ kappa-- -------->:
        //     | :   |                           :
        //     | 1 ulp | 1 ulp |:
        //     |<--->|<--->|                     :
        // ----|-----|-----|------------------------
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // yen `v + 1 ulp` luwih cedhak karo perwakilan bunder (sing wis ana ing `buf`), mula kita bisa bali kanthi aman.
        // elinga yen `v - 1 ulp`*bisa* kurang saka perwakilan saiki, nanging amarga `1 ulp < 10^kappa / 2`, kondhisi iki cukup:
        // jarak antarane `v - 1 ulp` lan perwakilan saiki ora bisa ngluwihi `10^kappa / 2`.
        //
        // kondhisi padha karo `remainder + ulp < 10^kappa / 2`.
        // amarga iki bisa gampang kakehan, priksa dhisik `remainder < 10^kappa / 2`.
        // kita wis verifikasi yen `ulp < 10^kappa / 2`, dadi yen `10^kappa` ora kakehan, cek nomer loro ora apa-apa.
        //
        //
        //
        //
        if ten_kappa - remainder > remainder && ten_kappa - 2 * remainder >= 2 * ulp {
            // SAFETY: panelpon kita miwiti memori kasebut.
            return Some((unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, exp));
        }

        // : <-------seko------> |:
        //   :                          |   :
        //   : <---------10 ^ kappa-- ------->:
        //   :                    |     |   : |
        //   : | 1 ulp | 1 ulp |
        //   :                    |<--->|<--->|
        // -----------------------|-----|-----|-----
        //                        |     v     |                    v - 1 ulp   v + 1 ulp
        //
        // ing tangan liyane, yen `v - 1 ulp` luwih cedhak karo perwakilan sing dibunderaké, kita kudu mbunder lan bali.
        // amarga padha, kita ora prelu mriksa `v + 1 ulp`.
        //
        // kondhisi padha karo `remainder - ulp >= 10^kappa / 2`.
        // maneh, luwih dhisik dipriksa manawa `remainder > ulp` (elinga yen iki dudu `remainder >= ulp`, amarga `10^kappa` ora nul).
        //
        // uga cathet yen `remainder - ulp <= 10^kappa`, mula priksa liya ora kebanjiran.
        //
        if remainder > ulp && ten_kappa - (remainder - ulp) <= remainder - ulp {
            if let Some(c) =
                // SAFETY: panelpon mesthine kudu nggawe memori wiwitan.
                round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..len]) })
            {
                // mung nambahake digit tambahan yen wis dijaluk presisi sing tetep.
                // kita uga kudu mriksa, yen buffer asli kosong, digit tambahan mung bisa ditambahake nalika `exp == limit` (kasus edge).
                //
                exp += 1;
                if exp > limit && len < buf.len() {
                    buf[len] = MaybeUninit::new(c);
                    len += 1;
                }
            }
            // SAFETY: kita lan panelpon nginisialisasi memori kasebut.
            return Some((unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, exp));
        }

        // Yen ora, kita bakal pinasthi (yaiku, sawetara nilai ing antarane `v - 1 ulp` lan `v + 1 ulp` dibunderake lan liyane uga dibunderake) lan nyerah.
        //
        None
    }
}

/// Implementasi mode sing pas lan tetep kanggo Grisu kanthi fallback Dragon.
///
/// Iki kudu digunakake ing pirang-pirang kasus.
pub fn format_exact<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    use crate::num::flt2dec::strategy::dragon::format_exact as fallback;
    // SAFETY: Checker utang ora cukup pinter supaya bisa nggunakake `buf`
    // ing branch kapindho, mula kita ora bisa urip ing kene.
    // Nanging kita mung nggunakake maneh `buf` yen `format_exact_opt` ngasilake `None` dadi ora apa-apa.
    match format_exact_opt(d, unsafe { &mut *(buf as *mut _) }, limit) {
        Some(ret) => ret,
        None => fallback(d, buf, limit),
    }
}