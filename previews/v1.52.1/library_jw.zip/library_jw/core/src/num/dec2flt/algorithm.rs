//! Macem-macem algoritma saka kertas.

use crate::cmp::min;
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::rawfp::{self, fp_to_float, next_float, prev_float, RawFloat, Unpacked};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;

/// Jumlah bit sing penting ing Fp
const P: u32 = 64;

// Kita mung nyimpen perkiraan paling apik kanggo *kabeh* eksponen, mula variabel "h" lan kahanan sing ana gandhengane bisa ngilangi.
// Iki kinerja kinerja kanggo sawetara kilobytes ruang.

fn power_of_ten(e: i16) -> Fp {
    assert!(e >= table::MIN_E);
    let i = e - table::MIN_E;
    let sig = table::POWERS.0[i as usize];
    let exp = table::POWERS.1[i as usize];
    Fp { f: sig, e: exp }
}

// Ing umume arsitektur, operasi titik ngambang duwe ukuran sing eksplisit, mula presisi komputasi ditemtokake kanthi basis saben operasi.
//
#[cfg(any(not(target_arch = "x86"), target_feature = "sse2"))]
mod fpu_precision {
    pub fn set_precision<T>() {}
}

// Ing x86, x87 FPU digunakake kanggo operasi float yen ekstensi SSE/SSE2 ora kasedhiya.
// x87 FPU dioperasikake kanthi presisi 80 bit kanthi standar, sing tegese operasi bakal dibunderake nganti 80 bit, mula ana pambulatan dobel nalika nilai diwakili dadi
//
// 32/64 nilai float bit.Kanggo ngatasi iki, tembung kontrol FPU bisa diatur supaya komputasi ditindakake kanthi tliti sing dikarepake.
//
#[cfg(all(target_arch = "x86", not(target_feature = "sse2")))]
mod fpu_precision {
    use crate::mem::size_of;

    /// Struktur sing digunakake kanggo ngreksa nilai asli tembung kontrol FPU, saengga bisa dipulihake nalika struktur mudhun.
    ///
    ///
    /// x87 FPU minangka dhaptar 16 bit sing bidange kaya ing ngisor iki:
    ///
    /// | 12-15 | 10-11 | 8-9 | 6-7 |  5 |  4 |  3 |  2 |  1 |  0 |
    /// |------:|------:|----:|----:|---:|---:|---:|---:|---:|---:|
    /// |       | RC    | PC  |     | PM | UM | OM | ZM | DM | IM |
    ///
    /// Dokumentasi kanggo kabeh lapangan kasedhiya ing Manual Pangembang Piranti Lunak Arsitektur IA-32 (Volume 1).
    ///
    /// Siji-sijine lapangan sing cocog kanggo kode ing ngisor iki yaiku PC, Control Precision.
    /// Bidang iki nemtokake tliti operasi sing ditindakake dening FPU.
    /// Bisa disetel menyang:
    ///  - 0b00, presisi tunggal, 32-bit
    ///  - 0b10, presisi dobel, 64-bit
    ///  - 0b11, presisi tambahan dobel, 80-bit (negara default) Nilai 0b01 dilindhungi undhang-undhang lan ora digunakake.
    ///
    pub struct FPUControlWord(u16);

    fn set_cw(cw: u16) {
        // SAFETY: instruksi `fldcw` wis diaudit supaya bisa digunakake kanthi bener
        // `u16` wae
        unsafe {
            asm!(
                "fldcw ({})",
                in(reg) &cw,
                // FIXME: Kita nggunakake sintaks ATT kanggo ndhukung LLVM 8 lan LLVM 9.
                options(att_syntax, nostack),
            )
        }
    }

    /// Nyetel kolom presisi FPU dadi `T` lan ngasilake `FPUControlWord`.
    pub fn set_precision<T>() -> FPUControlWord {
        let mut cw = 0_u16;

        // Ngitung nilai kanggo kolom Precision Control sing cocog karo `T`.
        let cw_precision = match size_of::<T>() {
            4 => 0x0000, // 32 bit
            8 => 0x0200, // 64 bit
            _ => 0x0300, // standar, 80 bit
        };

        // Goleki nilai asli tembung kontrol kanggo mulihake mengko, yen struktur `FPUControlWord` dicopot SAFETY: instruksi `fnstcw` wis diaudit supaya bisa digunakake kanthi bener karo `u16`
        //
        //
        //
        unsafe {
            asm!(
                "fnstcw ({})",
                in(reg) &mut cw,
                // FIXME: Kita nggunakake sintaks ATT kanggo ndhukung LLVM 8 lan LLVM 9.
                options(att_syntax, nostack),
            )
        }

        // Setel tembung kontrol menyang presisi sing dikarepake.
        // Iki bisa ditindakake kanthi masking presisi lawas (bit 8 lan 9, 0x300) lan ganti nganggo gendéra presisi sing diitung ing ndhuwur.
        set_cw((cw & 0xFCFF) | cw_precision);

        FPUControlWord(cw)
    }

    impl Drop for FPUControlWord {
        fn drop(&mut self) {
            set_cw(self.0)
        }
    }
}

/// Jalur cepet Bellerophon nggunakake bilangan bulat lan float ukuran mesin.
///
/// Iki diekstrak dadi fungsi sing kapisah supaya bisa dicoba sadurunge nggawe bignum.
///
pub fn fast_path<T: RawFloat>(integral: &[u8], fractional: &[u8], e: i64) -> Option<T> {
    let num_digits = integral.len() + fractional.len();
    // log_10(f64::MAX_SIG) ~ 15.95.
    // Kita mbandhingake regane pas karo MAX_SIG ing pungkasan, iki mung ditolak kanthi cepet lan murah (lan uga mbebasake kode liyane supaya ora kuwatir yen ana aliran arus).
    //
    if num_digits > 16 {
        return None;
    }
    if e.abs() >= T::CEIL_LOG5_OF_MAX_SIG as i64 {
        return None;
    }
    let f = num::from_str_unchecked(integral.iter().chain(fractional.iter()));
    if f > T::MAX_SIG {
        return None;
    }

    // Jalur sing cepet banget gumantung karo aritmatika sing dibunderake dadi jumlah sing bener tanpa dibunderake penengah.
    // Ing x86 (tanpa SSE utawa SSE2) iki mbutuhake presisi tumpukan x87 FPU bakal diganti supaya langsung dibunderake dadi 64/32.
    // Fungsi `set_precision` kudu ngatasi presisi arsitektur sing kudu disetel kanthi ngganti negara global (kaya tembung kontrol x87 FPU).
    //
    //
    let _cw = fpu_precision::set_precision::<T>();

    // Kasus e <0 ora bisa dilipat menyang branch liyane.
    // Kekuwatan negatif nyebabake bagean fraksi baleni ing binar, sing dibunderaké, sing nyebabake kesalahan nyata (lan sok-sok cukup signifikan!) Ing asil pungkasan.
    //
    if e >= 0 {
        Some(T::from_int(f) * T::short_fast_pow10(e as usize))
    } else {
        Some(T::from_int(f) / T::short_fast_pow10(e.abs() as usize))
    }
}

/// Algoritma Bellerophon minangka kode sepele sing dibenerake kanthi analisis angka non-sepele.
///
/// Babak "f" menyang float kanthi 64 bit lan banjur dikalikan kanthi jarak paling apik `10^e` (ing format titik ngambang sing padha).Iki asring cukup kanggo entuk asil sing bener.
/// Nanging, yen asile cedhak karo setengah antarane rong float (ordinary) jejer, kesalahan bunder senyawa saka multiplikasi loro tegese asil bisa dipateni sawetara bit.
/// Yen kedadeyan kasebut, Algoritma R iteratif mbenakake kabeh perkara.
///
/// "close to halfway" sing dicukur tangan digawe tepat kanthi analisis angka ing kertas.
/// Ing tembung Clinger:
///
/// > Slop, ditulis ing unit sing paling ora penting, kalebu kesalahan kasebut
/// > nglumpukake sajrone pitungan ngambang kira-kira f * 10 ^ e.(Slop yaiku
/// > dudu wates kesalahan sing bener, nanging mbatesi prabédan antawisipun z lan
/// > panyerakan paling apik sing nggunakake p teges.)
///
///
pub fn bellerophon<T: RawFloat>(f: &Big, e: i16) -> T {
    let slop = if f <= &Big::from_u64(T::MAX_SIG) {
        // Kasus abs(e) <log5(2^N) ing fast_path()
        if e >= 0 { 0 } else { 3 }
    } else {
        if e >= 0 { 1 } else { 4 }
    };
    let z = rawfp::big_to_fp(f).mul(&power_of_ten(e)).normalize();
    let exp_p_n = 1 << (P - T::SIG_BITS as u32);
    let lowbits: i64 = (z.f % exp_p_n) as i64;
    // Apa slop cukup gedhe kanggo nggawe prabédan nalika mbunder nganti n bit?
    //
    if (lowbits - exp_p_n as i64 / 2).abs() <= slop {
        algorithm_r(f, e, fp_to_float(z))
    } else {
        fp_to_float(z)
    }
}

/// Algoritme iteratif sing nambah perkiraan titik ngambang `f * 10^e`.
///
/// Saben pengulangan entuk sak unit ing papan pungkasan, sing mesthi wae suwe banget kanggo konvergensi yen `z0` malah mati.
/// Untunge, yen digunakake minangka fallback kanggo Bellerophon, perkiraan wiwitan dipungkasi paling ora siji ULP.
///
fn algorithm_r<T: RawFloat>(f: &Big, e: i16, z0: T) -> T {
    let mut z = z0;
    loop {
        let raw = z.unpack();
        let (m, k) = (raw.sig, raw.k);
        let mut x = f.clone();
        let mut y = Big::from_u64(m);

        // Temokake bilangan bulat positif `x`, `y` saengga `x / y` persis `(f *10^e) / (m* 2^k)`.
        // Iki ora mung supaya bisa ngatasi pratandha `e` lan `k`, kita uga ngilangi kekuwatan loro sing umum dadi `10^e` lan `2^k` kanggo nggawe angka luwih cilik.
        //
        make_ratio(&mut x, &mut y, e, k);

        let m_digits = [(m & 0xFF_FF_FF_FF) as u32, (m >> 32) as u32];
        // Iki ditulis rada kikuk amarga bignum kita ora ndhukung nomer negatif, mula nggunakake informasi tandha + nilai absolut.
        // Perkalian karo m_digits ora bisa kakehan.
        // Yen `x` utawa `y` cukup gedhe mula kita kudu kuwatir kebanjiran, mula bisa uga cukup yen `make_ratio` nyuda fraksi kanthi faktor 2 ^ 64 utawa luwih.
        //
        //
        let (d2, d_negative) = if x >= y {
            // Aja mbutuhake x maneh, ngirit clone().
            x.sub(&y).mul_pow2(1).mul_digits(&m_digits);
            (x, false)
        } else {
            // Isih butuh y, gawe salinan.
            let mut y = y.clone();
            y.sub(&x).mul_pow2(1).mul_digits(&m_digits);
            (y, true)
        };

        if d2 < y {
            let mut d2_double = d2;
            d2_double.mul_pow2(1);
            if m == T::MIN_SIG && d_negative && d2_double > y {
                z = prev_float(z);
            } else {
                return z;
            }
        } else if d2 == y {
            if m % 2 == 0 {
                if m == T::MIN_SIG && d_negative {
                    z = prev_float(z);
                } else {
                    return z;
                }
            } else if d_negative {
                z = prev_float(z);
            } else {
                z = next_float(z);
            }
        } else if d_negative {
            z = prev_float(z);
        } else {
            z = next_float(z);
        }
    }
}

/// Yen diwenehi `x = f` lan `y = m` ing endi `f` nggambarake digit desimal kaya biasane lan `m` minangka pinunjul saka titik ngambang, rasio `x / y` padha karo `(f *10^e) / (m* 2^k)`, bisa uga dikurangi kanthi kekuwatan saka kalorone.
///
///
fn make_ratio(x: &mut Big, y: &mut Big, e: i16, k: i16) {
    let (e_abs, k_abs) = (e.abs() as usize, k.abs() as usize);
    if e >= 0 {
        if k >= 0 {
            // x=f *10 ^ e, y=m* 2 ^ k, kajaba kita nyuda fraksi kanthi sawetara kekuwatan.
            let common = min(e_abs, k_abs);
            x.mul_pow5(e_abs).mul_pow2(e_abs - common);
            y.mul_pow2(k_abs - common);
        } else {
            // x=f *10 ^ e* 2^abs(k), y=m Iki ora bisa kebanjiran amarga mbutuhake `e` positif lan `k` negatif, sing mung bisa kedadeyan kanggo angka sing cedhak banget karo 1, tegese `e` lan `k` bakal cukup cilik.
            //
            //
            //
            x.mul_pow5(e_abs).mul_pow2(e_abs + k_abs);
        }
    } else {
        if k >= 0 {
            // x=f, y=m *10^abs(e)* 2 ^ k Iki ora bisa kebanjiran, deleng ndhuwur.
            //
            y.mul_pow5(e_abs).mul_pow2(k_abs + e_abs);
        } else {
            // x=f *2^abs(k), y=m* 10^abs(e), maneh dikurangi kanthi kekuwatan umum loro.
            let common = min(e_abs, k_abs);
            x.mul_pow2(k_abs - common);
            y.mul_pow5(e_abs).mul_pow2(e_abs - common);
        }
    }
}

/// Secara konseptual, Algoritma M minangka cara paling gampang kanggo ngowahi desimal dadi float.
///
/// Kita mbentuk rasio sing padha karo `f * 10^e`, banjur mbuwang kekuwatan loro nganti menehi float tegesand sing valid.
/// Eksponen biner `k` yaiku kaping pirang-pirang kaping pindho saka multiplikator utawa denominator, yaiku, ing kabeh kaping `f *10^e` padha karo `(u / v)* 2^k`.
/// Yen wis ngerteni pentinge, kita mung kudu muter kanthi mriksa sisa divisi, sing rampung ing fungsi helper ing ngisor iki.
///
///
/// Algoritma iki super alon, sanajan karo optimisasi sing diterangake ing `quick_start()`.
/// Nanging, algoritma sing paling gampang kanggo adaptasi kanggo asil overflow, underflow, lan subnormal.
/// Implementasine iki njupuk alih nalika Bellerophon lan Algorithm R kewalahan.
/// Ndeteksi underflow lan kebanjiran gampang: Rasio isih durung ditemtokake, nanging eksponen minimum/maximum wis ditemokake.
/// Ing kasus kebanjiran, kita mung bakal bali tanpa wates.
///
/// Nangani underflow lan subnormal luwih angel.
/// Siji masalah gedhe yaiku, kanthi eksponen minimal, rasio bisa uga gedhe banget kanggo a.
/// Deleng underflow() kanggo rincian.
///
pub fn algorithm_m<T: RawFloat>(f: &Big, e: i16) -> T {
    let mut u;
    let mut v;
    let e_abs = e.abs() as usize;
    let mut k = 0;
    if e < 0 {
        u = f.clone();
        v = Big::from_small(1);
        v.mul_pow5(e_abs).mul_pow2(e_abs);
    } else {
        // FIXME sing bisa dioptimalake: umumake big_to_fp supaya kita bisa nindakake padha karo fp_to_float(big_to_fp(u)) ing kene, mung tanpa dibunderaké kaping pindho.
        //
        u = f.clone();
        u.mul_pow5(e_abs).mul_pow2(e_abs);
        v = Big::from_small(1);
    }
    quick_start::<T>(&mut u, &mut v, &mut k);
    let mut rem = Big::from_small(0);
    let mut x = Big::from_small(0);
    let min_sig = Big::from_u64(T::MIN_SIG);
    let max_sig = Big::from_u64(T::MAX_SIG);
    loop {
        u.div_rem(&v, &mut x, &mut rem);
        if k == T::MIN_EXP_INT {
            // Kita kudu mandheg ing eksponen minimal, yen ngenteni nganti `k < T::MIN_EXP_INT`, mula bakal rong faktor.
            // Sayange, iki tegese kita kudu khusus-nomer normal karo exponent minimal.
            // FIXME temokake formulasi sing luwih elegan, nanging jalanake tes `tiny-pow10` kanggo mesthekake yen bener!
            //
            //
            if x >= min_sig && x <= max_sig {
                break;
            }
            return underflow(x, v, rem);
        }
        if k > T::MAX_EXP_INT {
            return T::INFINITY;
        }
        if x < min_sig {
            u.mul_pow2(1);
            k -= 1;
        } else if x > max_sig {
            v.mul_pow2(1);
            k += 1;
        } else {
            break;
        }
    }
    let q = num::to_u64(&x);
    let z = rawfp::encode_normal(Unpacked::new(q, k));
    round_by_remainder(v, rem, q, z)
}

/// Nglewati paling akeh pengulangan Algoritma M kanthi mriksa dawa sing dawa.
fn quick_start<T: RawFloat>(u: &mut Big, v: &mut Big, k: &mut i16) {
    // Dawa bit minangka perkiraan logaritma basa loro, lan log(u / v) = log(u), log(v).
    // Prakiraan paling ora 1, nanging mesthi kira-kira kurang, mula kesalahan ing log(u) lan log(v) minangka tandha sing padha lan batal (yen kalorone gedhe).
    // Mula kesalahan kanggo log(u / v) paling uga siji.
    // Rasio target yaiku yen u/v ana ing rentang sing padha.Dadi, kondhisi mandap kita yaiku log2(u / v) minangka bit wigati, plus/minus siji.
    // FIXME Nggoleki sing kapindho bisa nambah perkiraan lan nyegah sawetara divisi liyane.
    //
    //
    let target_ratio = T::SIG_BITS as i16;
    let log2_u = u.bit_length() as i16;
    let log2_v = v.bit_length() as i16;
    let mut u_shift: i16 = 0;
    let mut v_shift: i16 = 0;
    assert!(*k == 0);
    loop {
        if *k == T::MIN_EXP_INT {
            // Underflow utawa ora normal.Ninggalake fungsi utama.
            break;
        }
        if *k == T::MAX_EXP_INT {
            // KebanjiranNinggalake fungsi utama.
            break;
        }
        let log2_ratio = (log2_u + u_shift) - (log2_v + v_shift);
        if log2_ratio < target_ratio - 1 {
            u_shift += 1;
            *k -= 1;
        } else if log2_ratio > target_ratio + 1 {
            v_shift += 1;
            *k += 1;
        } else {
            break;
        }
    }
    u.mul_pow2(u_shift as usize);
    v.mul_pow2(v_shift as usize);
}

fn underflow<T: RawFloat>(x: Big, v: Big, rem: Big) -> T {
    if x < Big::from_u64(T::MIN_SIG) {
        let q = num::to_u64(&x);
        let z = rawfp::encode_subnormal(q);
        return round_by_remainder(v, rem, q, z);
    }
    // Rasio dudu teges sing ana ing sacedhake karo eksponen minimal, mula kita kudu ngatasi kaluwihan lan nyetel eksponen.
    // Nilai nyata saiki katon kaya iki:
    //
    //        x lsb
    // /--------------\/
    // 1010101010101010.10101010101010 * 2^k
    // \-----/\-------/ \------------/
    //    q trunc.(diwakili dening rem)
    //
    // Mula, yen bit sing dibunderaké dadi!= 0.5 ULP, dheweke bakal milih puteran kasebut dhewe.
    // Yen padha lan sisane dudu nol, regane isih kudu dibunderaké.
    // Mung yen bit sing dibunderaké 1/2 lan sisané nol, kita bakal ngalami kahanan setengah-nganti-rata.
    //
    let bits = x.bit_length();
    let lsb = bits - T::SIG_BITS as usize;
    let q = num::get_bits(&x, lsb, bits);
    let k = T::MIN_EXP_INT + lsb as i16;
    let z = rawfp::encode_normal(Unpacked::new(q, k));
    let q_even = q % 2 == 0;
    match num::compare_with_half_ulp(&x, lsb) {
        Greater => next_float(z),
        Less => z,
        Equal if rem.is_zero() && q_even => z,
        Equal => next_float(z),
    }
}

/// Babak-menyang-malah biasa, disametake kanthi kudu muter adhedhasar sisa divisi.
fn round_by_remainder<T: RawFloat>(v: Big, r: Big, q: u64, z: T) -> T {
    let mut v_minus_r = v;
    v_minus_r.sub(&r);
    if r < v_minus_r {
        z
    } else if r > v_minus_r {
        next_float(z)
    } else if q % 2 == 0 {
        z
    } else {
        next_float(z)
    }
}