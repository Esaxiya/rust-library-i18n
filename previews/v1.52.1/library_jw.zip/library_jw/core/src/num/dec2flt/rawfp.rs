//! Bit fiddling ing IEEE 754 float positif.Nomer negatif ora lan ora kudu ditangani.
//! Nomer titik ngambang normal duwe perwakilan kanonis kaya (frac, exp) saengga regane 2 <sup>exp</sup> * (1 + sum(frac[N-i] / 2<sup>i</sup>)) ing endi N minangka jumlah bit.
//!
//! Subnormal rada beda lan aneh, nanging prinsip sing padha ditrapake.
//!
//! Nanging, ing kene kita makili minangka (sig, k) kanthi f positif, mula regane f *
//! 2 <sup>e</sup> .Kejabi nggawe "hidden bit" eksplisit, iki ngganti eksponen kanthi owah-owahan mantissa sing diarani.
//!
//! Cara liya, biasane floats ditulis dadi (1) nanging ing kene ditulis (2):
//!
//! 1. `1.101100...11 * 2^m`
//! 2. `1101100...11 * 2^n`
//!
//! Kita nyebat (1) minangka **perwakilan pecahan** lan (2) minangka **perwakilan integral**.
//!
//! Akeh fungsi ing modul iki sing mung nangani angka normal.Rutinitas dec2flt kanthi konservatif njupuk jalur alon sing bener sacara universal (Algoritma M) kanggo jumlah sing sithik lan gedhe banget.
//! Algoritma kasebut mung mbutuhake next_float() sing nangani subnormal lan nol.
//!
//!
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::convert::{TryFrom, TryInto};
use crate::fmt::{Debug, LowerExp};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;
use crate::num::FpCategory;
use crate::num::FpCategory::{Infinite, Nan, Normal, Subnormal, Zero};
use crate::ops::{Add, Div, Mul, Neg};

#[derive(Copy, Clone, Debug)]
pub struct Unpacked {
    pub sig: u64,
    pub k: i16,
}

impl Unpacked {
    pub fn new(sig: u64, k: i16) -> Self {
        Unpacked { sig, k }
    }
}

/// trait helper kanggo nyegah duplikat kabeh kode konversi kanggo `f32` lan `f64`.
///
/// Deleng komentar dokumen modul induk kanggo ngapa perlu.
///
/// Apa **ora nate** dileksanakake kanggo jinis liyane utawa digunakake ing njaba modul dec2flt.
pub trait RawFloat:
    Copy + Debug + LowerExp + Mul<Output = Self> + Div<Output = Self> + Neg<Output = Self>
{
    const INFINITY: Self;
    const NAN: Self;
    const ZERO: Self;

    /// Jinis digunakake dening `to_bits` lan `from_bits`.
    type Bits: Add<Output = Self::Bits> + From<u8> + TryFrom<u64>;

    /// Nindakake transmutasi mentah menyang bilangan bulat.
    fn to_bits(self) -> Self::Bits;

    /// Nindakake transmutasi mentah saka wilangan bulat.
    fn from_bits(v: Self::Bits) -> Self;

    /// Ngasilake kategori sing nomer kasebut kalebu.
    fn classify(self) -> FpCategory;

    /// Ngasilake mantissa, exponent lan mlebu minangka ongko.
    fn integer_decode(self) -> (u64, i16, i8);

    /// Ngeculake float.
    fn unpack(self) -> Unpacked;

    /// Cores saka ongko bunder cilik sing bisa diwakili kanthi tepat.
    /// Panic yen wilangan bulat ora bisa diwakili, kode liyane ing modul iki mesthekake ora bakal kelakon.
    fn from_int(x: u64) -> Self;

    /// Entuk nilai 10 <sup>e</sup> saka tabel sing wis diitung.
    /// Panics kanggo `e >= CEIL_LOG5_OF_MAX_SIG`.
    fn short_fast_pow10(e: usize) -> Self;

    /// Apa jenenge jeneng.
    /// Kode hard luwih gampang tinimbang juggling intrinsik lan muga-muga LLVM terus dilipat.
    const CEIL_LOG5_OF_MAX_SIG: i16;

    // Konservatif kaiket ing digit desimal input sing ora bisa ngasilake kebanjiran utawa nol utawa
    /// subnormals.Bisa uga eksponen desimal nilai normal maksimal, mula jenenge.
    const MAX_NORMAL_DIGITS: usize;

    /// Yen digit desimal paling penting duwe nilai panggonan sing luwih gedhe tinimbang iki, jumlah kasebut mesthi dibunderaké dadi tanpa wates.
    ///
    const INF_CUTOFF: i64;

    /// Yen digit desimal sing paling penting duwe nilai panggonan kurang saka iki, jumlah kasebut mesthi dibunderaké dadi nol.
    ///
    const ZERO_CUTOFF: i64;

    /// Jumlah bit ing eksponen.
    const EXP_BITS: u8;

    /// Nomer bit ing hintand,*kalebu* bit sing didhelikake.
    const SIG_BITS: u8;

    /// Nomer bit ing hintand,*ora kalebu* bit sing didhelikake.
    const EXPLICIT_SIG_BITS: u8;

    /// Eksponen hukum maksimal ing perwakilan fraksional.
    const MAX_EXP: i16;

    /// Eksponen sah minimal ing perangan fraksional, ora kalebu subnormal.
    const MIN_EXP: i16;

    /// `MAX_EXP` kanggo perwakilan integral, yaiku kanthi shift sing ditrapake.
    const MAX_EXP_INT: i16;

    /// `MAX_EXP` dienkode (yaiku, kanthi bias nutup kerugian)
    const MAX_ENCODED_EXP: i16;

    /// `MIN_EXP` kanggo perwakilan integral, yaiku kanthi shift sing ditrapake.
    const MIN_EXP_INT: i16;

    /// Teges normalisasi maksimum ing perwakilan integral.
    const MAX_SIG: u64;

    /// Signifikansi normal minimalis ing perwakilan integral.
    const MIN_SIG: u64;
}

// Umume solusi kanggo #34344.
macro_rules! other_constants {
    ($type: ident) => {
        const EXPLICIT_SIG_BITS: u8 = Self::SIG_BITS - 1;
        const MAX_EXP: i16 = (1 << (Self::EXP_BITS - 1)) - 1;
        const MIN_EXP: i16 = -<Self as RawFloat>::MAX_EXP + 1;
        const MAX_EXP_INT: i16 = <Self as RawFloat>::MAX_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_ENCODED_EXP: i16 = (1 << Self::EXP_BITS) - 1;
        const MIN_EXP_INT: i16 = <Self as RawFloat>::MIN_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_SIG: u64 = (1 << Self::SIG_BITS) - 1;
        const MIN_SIG: u64 = 1 << (Self::SIG_BITS - 1);

        const INFINITY: Self = $type::INFINITY;
        const NAN: Self = $type::NAN;
        const ZERO: Self = 0.0;
    };
}

impl RawFloat for f32 {
    type Bits = u32;

    const SIG_BITS: u8 = 24;
    const EXP_BITS: u8 = 8;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 11;
    const MAX_NORMAL_DIGITS: usize = 35;
    const INF_CUTOFF: i64 = 40;
    const ZERO_CUTOFF: i64 = -48;
    other_constants!(f32);

    /// Ngasilake mantissa, exponent lan mlebu minangka ongko.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 31 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 23) & 0xff) as i16;
        let mantissa =
            if exponent == 0 { (bits & 0x7fffff) << 1 } else { (bits & 0x7fffff) | 0x800000 };
        // Bias eksponensial + pergeseran mantissa
        exponent -= 127 + 23;
        (mantissa as u64, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f32 {
        // rkruppe ora yakin manawa `as` babak kanthi bener ing kabeh platform.
        debug_assert!(x as f32 == fp_to_float(Fp { f: x, e: 0 }));
        x as f32
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F32_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

impl RawFloat for f64 {
    type Bits = u64;

    const SIG_BITS: u8 = 53;
    const EXP_BITS: u8 = 11;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 23;
    const MAX_NORMAL_DIGITS: usize = 305;
    const INF_CUTOFF: i64 = 310;
    const ZERO_CUTOFF: i64 = -326;
    other_constants!(f64);

    /// Ngasilake mantissa, exponent lan mlebu minangka ongko.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 63 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 52) & 0x7ff) as i16;
        let mantissa = if exponent == 0 {
            (bits & 0xfffffffffffff) << 1
        } else {
            (bits & 0xfffffffffffff) | 0x10000000000000
        };
        // Bias eksponensial + pergeseran mantissa
        exponent -= 1023 + 52;
        (mantissa, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f64 {
        // rkruppe ora yakin manawa `as` babak kanthi bener ing kabeh platform.
        debug_assert!(x as f64 == fp_to_float(Fp { f: x, e: 0 }));
        x as f64
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F64_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

/// Ngonversi `Fp` menyang jinis float mesin sing paling cedhak.
/// Ora ngatasi asil subnormal.
pub fn fp_to_float<T: RawFloat>(x: Fp) -> T {
    let x = x.normalize();
    // x.f 64 bit, dadi xe duwe pergeseran mantissa 63
    let e = x.e + 63;
    if e > T::MAX_EXP {
        panic!("fp_to_float: exponent {} too large", e)
    } else if e > T::MIN_EXP {
        encode_normal(round_normal::<T>(x))
    } else {
        panic!("fp_to_float: exponent {} too small", e)
    }
}

/// Babak bit 64-bit lan nganti T::SIG_BITS bit kanthi setengah.
/// Ora ngatasi kakehan eksponen.
pub fn round_normal<T: RawFloat>(x: Fp) -> Unpacked {
    let excess = 64 - T::SIG_BITS as i16;
    let half: u64 = 1 << (excess - 1);
    let (q, rem) = (x.f >> excess, x.f & ((1 << excess) - 1));
    assert_eq!(q << excess | rem, x.f);
    // Setel shift mantissa
    let k = x.e + excess;
    if rem < half {
        Unpacked::new(q, k)
    } else if rem == half && (q % 2) == 0 {
        Unpacked::new(q, k)
    } else if q == T::MAX_SIG {
        Unpacked::new(T::MIN_SIG, k + 1)
    } else {
        Unpacked::new(q + 1, k)
    }
}

/// Kuwalik `RawFloat::unpack()` kanggo nomer normal.
/// Panics yen teges utawa eksponen ora valid kanggo nomer normal.
pub fn encode_normal<T: RawFloat>(x: Unpacked) -> T {
    debug_assert!(
        T::MIN_SIG <= x.sig && x.sig <= T::MAX_SIG,
        "encode_normal: significand not normalized"
    );
    // Copot dicokot sing didhelikake
    let sig_enc = x.sig & !(1 << T::EXPLICIT_SIG_BITS);
    // Setel eksponen kanggo bias eksponen lan shift mantissa
    let k_enc = x.k + T::MAX_EXP + T::EXPLICIT_SIG_BITS as i16;
    debug_assert!(k_enc != 0 && k_enc < T::MAX_ENCODED_EXP, "encode_normal: exponent out of range");
    // Ninggalake tandha ing 0 ("+"), kabeh nomer positif
    let bits = (k_enc as u64) << T::EXPLICIT_SIG_BITS | sig_enc;
    T::from_bits(bits.try_into().unwrap_or_else(|_| unreachable!()))
}

/// Mbangun subnormal.Mantissa 0 diijini lan dibangun nol.
pub fn encode_subnormal<T: RawFloat>(significand: u64) -> T {
    assert!(significand < T::MIN_SIG, "encode_subnormal: not actually subnormal");
    // Eksponen sing dienkode yaiku 0, tandha tandha 0, dadi mung kudu nafsirake bit maneh.
    T::from_bits(significand.try_into().unwrap_or_else(|_| unreachable!()))
}

/// Kira-kira bignum karo Fp.Babak ing 0.5 ULP kanthi setengah-nganti-rata.
pub fn big_to_fp(f: &Big) -> Fp {
    let end = f.bit_length();
    assert!(end != 0, "big_to_fp: unexpectedly, input is zero");
    let start = end.saturating_sub(64);
    let leading = num::get_bits(f, start, end);
    // Kita ngilangi kabeh bit sadurunge indeks `start`, yaiku, kanthi efektif bisa ngalih kanthi bener kanthi jumlah `start`, mula iki uga exponent sing dibutuhake.
    //
    let e = start as i16;
    let rounded_down = Fp { f: leading, e }.normalize();
    // Babak (half-to-even) gumantung saka bit sing wis dipotong.
    match num::compare_with_half_ulp(f, start) {
        Less => rounded_down,
        Equal if leading % 2 == 0 => rounded_down,
        Equal | Greater => match leading.checked_add(1) {
            Some(f) => Fp { f, e }.normalize(),
            None => Fp { f: 1 << 63, e: e + 1 },
        },
    }
}

/// Nemokake nomer titik ngambang paling gedhe sing luwih cilik tinimbang argumen.
/// Ora nangani subnormal, nol, utawa underflow eksponen.
pub fn prev_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Infinite => panic!("prev_float: argument is infinite"),
        Nan => panic!("prev_float: argument is NaN"),
        Subnormal => panic!("prev_float: argument is subnormal"),
        Zero => panic!("prev_float: argument is zero"),
        Normal => {
            let Unpacked { sig, k } = x.unpack();
            if sig == T::MIN_SIG {
                encode_normal(Unpacked::new(T::MAX_SIG, k - 1))
            } else {
                encode_normal(Unpacked::new(sig - 1, k))
            }
        }
    }
}

// Temokake nomer titik ngambang sing paling cilik sing luwih gedhe tinimbang argumen.
// Operasi iki jenuh, yaiku, next_float(inf) ==inf.
// Ora kaya kode sing paling akeh ing modul iki, fungsi iki ora nangani, subnormal, lan infinitas.
// Nanging, kaya kabeh kode liyane ing kene, ora ana gandhengane karo NaN lan nomer negatif.
pub fn next_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Nan => panic!("next_float: argument is NaN"),
        Infinite => T::INFINITY,
        // Iki kayane apik banget, nanging bisa uga.
        // 0.0 dienkode dadi tembung nol kabeh.Subnormal yaiku 0x000m ... ing endi mantissa.
        // Utamane, subnormal paling cilik yaiku 0x0 ... 01 lan sing paling gedhe 0x000F ... F.
        // Nomer normal paling cilik yaiku 0x0010 ... 0, dadi kasus pojok iki uga bisa digunakake.
        // Yen kenaikan nambah mantissa, bit bakal nambah eksponen kaya sing dikarepake, lan potongan mantissa dadi nol.
        // Amarga konvensi sing didhelikake, iki uga sing dikarepake!
        // Pungkasane, f64::MAX + 1=7eff ... f + 1=7ff0 ... 0= f64::INFINITY.
        //
        Zero | Subnormal | Normal => T::from_bits(x.to_bits() + T::Bits::from(1u8)),
    }
}