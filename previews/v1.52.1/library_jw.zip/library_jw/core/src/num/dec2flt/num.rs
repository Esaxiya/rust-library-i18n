//! Fungsi utilitas kanggo bignum sing ora duwe akal banget kanggo dadi metode.

// FIXME Jeneng modul iki rada apes, amarga modul liyane uga ngimpor `core::num`.

use crate::cmp::Ordering::{self, Equal, Greater, Less};

pub use crate::num::bignum::Big32x40 as Big;

/// Tes apa cara motong kabeh bit sing kurang penting tinimbang `ones_place` ngenalake kesalahan relatif kurang, padha, utawa luwih gedhe tinimbang 0.5 ULP.
///
pub fn compare_with_half_ulp(f: &Big, ones_place: usize) -> Ordering {
    if ones_place == 0 {
        return Less;
    }
    let half_bit = ones_place - 1;
    if f.get_bit(half_bit) == 0 {
        // <0.5 ULP
        return Less;
    }
    // Yen kabeh bit sing isih ana nol, mula= 0.5 ULP, liya> 0.5 Yen ora ana bit maneh (half_bit==0), ing ngisor iki uga ngasilake Equal kanthi bener.
    //
    for i in 0..half_bit {
        if f.get_bit(i) == 1 {
            return Greater;
        }
    }
    Equal
}

/// Ngowahi senar ASCII sing mung ngemot digit desimal dadi `u64`.
///
/// Ora nindakake cek kanggo karakter kebanjiran utawa karakter sing ora valid, mula yen panelpon ora ati-ati, asile bogus lan bisa panic (sanajan ora `unsafe`).
/// Kajaba iku, senar kosong dianggep nol.
/// Fungsi iki ana amarga
///
/// 1. nggunakake `FromStr` ing `&[u8]` mbutuhake `from_utf8_unchecked`, sing ala, lan
/// 2. nyusun asil `integral.parse()` lan `fractional.parse()` luwih rumit tinimbang kabeh fungsi iki.
///
pub fn from_str_unchecked<'a, T>(bytes: T) -> u64
where
    T: IntoIterator<Item = &'a u8>,
{
    let mut result = 0;
    for &c in bytes {
        result = result * 10 + (c - b'0') as u64;
    }
    result
}

/// Ngonversi string digit ASCII dadi bignum.
///
/// Kaya `from_str_unchecked`, fungsi iki gumantung karo parser kanggo ngilangi non-digit.
pub fn digits_to_big(integral: &[u8], fractional: &[u8]) -> Big {
    let mut f = Big::from_small(0);
    for &c in integral.iter().chain(fractional) {
        let n = (c - b'0') as u32;
        f.mul_small(10);
        f.add_small(n);
    }
    f
}

/// Mbukak bignum dadi 64 bilangan bulat.Panics yen nomer akeh banget.
pub fn to_u64(x: &Big) -> u64 {
    assert!(x.bit_length() < 64);
    let d = x.digits();
    if d.len() < 2 { d[0] as u64 } else { (d[1] as u64) << 32 | d[0] as u64 }
}

/// Ekstrak macem-macem bit.

/// Indeks 0 paling ora penting lan kisaran kasebut mbukak setengah kaya biasane.
/// Panics yen dijaluk ngekstrak bit luwih akeh tinimbang jinis bali.
pub fn get_bits(x: &Big, start: usize, end: usize) -> u64 {
    assert!(end - start <= 64);
    let mut result: u64 = 0;
    for i in (start..end).rev() {
        result = result << 1 | x.get_bit(i) as u64;
    }
    result
}