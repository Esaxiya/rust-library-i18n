//! Validasi lan dekomposisi string desimal saka formulir:
//!
//! `(digits | digits? '.'? digits?) (('e' | 'E') ('+' | '-')? digits)?`
//!
//! Kanthi tembung liyane, sintaks titik ngambang standar, kanthi loro pangecualian: Ora ana tandha, lan ora nangani "inf" lan "NaN".Iki ditangani dening fungsi driver (super::dec2flt).
//!
//! Sanajan ngenali masukan sing valid cukup gampang, modul iki uga kudu nolak variasi sing ora valid sing ora kaetung, aja nganti panic, lan nindakake akeh priksa yen modul liyane ora gumantung ing panic (utawa overflow).
//!
//! Kanggo nggawe masalah dadi luwih elek, kabeh kedadeyan ing input tunggal input.
//! Dadi, ati-ati nalika ngowahi apa-apa, lan priksa maneh karo modul liyane.
//!
//!
use self::ParseResult::{Invalid, ShortcutToInf, ShortcutToZero, Valid};
use super::num;

#[derive(Debug)]
pub enum Sign {
    Positive,
    Negative,
}

#[derive(Debug, PartialEq, Eq)]
/// Bagéan sing apik saka senar desimal.
pub struct Decimal<'a> {
    pub integral: &'a [u8],
    pub fractional: &'a [u8],
    /// Eksponen desimal, dijamin duwe kurang saka 18 digit desimal.
    pub exp: i64,
}

impl<'a> Decimal<'a> {
    pub fn new(integral: &'a [u8], fractional: &'a [u8], exp: i64) -> Decimal<'a> {
        Decimal { integral, fractional, exp }
    }
}

#[derive(Debug, PartialEq, Eq)]
pub enum ParseResult<'a> {
    Valid(Decimal<'a>),
    ShortcutToInf,
    ShortcutToZero,
    Invalid,
}

/// Priksa manawa senar input minangka nomer titik ngambang sing bener lan yen mangkono, goleki bagean integral, bagean pecahan, lan exponent ing njero.
/// Ora ngatasi pratandha.
pub fn parse_decimal(s: &str) -> ParseResult<'_> {
    if s.is_empty() {
        return Invalid;
    }

    let s = s.as_bytes();
    let (integral, s) = eat_digits(s);

    match s.first() {
        None => Valid(Decimal::new(integral, b"", 0)),
        Some(&b'e' | &b'E') => {
            if integral.is_empty() {
                return Invalid; // Ora ana digit sadurunge 'e'
            }

            parse_exp(integral, b"", &s[1..])
        }
        Some(&b'.') => {
            let (fractional, s) = eat_digits(&s[1..]);
            if integral.is_empty() && fractional.is_empty() {
                // Kita mbutuhake paling ora siji digit sadurunge utawa sawise titik kasebut.
                return Invalid;
            }

            match s.first() {
                None => Valid(Decimal::new(integral, fractional, 0)),
                Some(&b'e' | &b'E') => parse_exp(integral, fractional, &s[1..]),
                _ => Invalid, // Mbuwang sampah sawise bagean fraksi
            }
        }
        _ => Invalid, // Mbuwang sampah sawise senar digit pisanan
    }
}

/// Ngukir digit desimal nganti karakter non-digit pisanan.
fn eat_digits(s: &[u8]) -> (&[u8], &[u8]) {
    let pos = s.iter().position(|c| !c.is_ascii_digit()).unwrap_or(s.len());
    s.split_at(pos)
}

/// Ekstraksi eksponen lan mriksa kesalahan.
fn parse_exp<'a>(integral: &'a [u8], fractional: &'a [u8], rest: &'a [u8]) -> ParseResult<'a> {
    let (sign, rest) = match rest.first() {
        Some(&b'-') => (Sign::Negative, &rest[1..]),
        Some(&b'+') => (Sign::Positive, &rest[1..]),
        _ => (Sign::Positive, rest),
    };
    let (mut number, trailing) = eat_digits(rest);
    if !trailing.is_empty() {
        return Invalid; // Mbuwang sampah sawise dadi eksponen
    }
    if number.is_empty() {
        return Invalid; // Eksponen kosong
    }
    // Ing jalur iki, kita mesthi duwe sawetara digit sing bener.Sampeyan bisa uga kudu dawa yen `i64` dilebokake, nanging yen gedhe banget, input mesthi nol utawa tanpa wates.
    // Amarga saben nol ing digit desimal mung nyetel eksponen kanthi +/-1, ing exp=10 ^ 18 input kudu 17 exabyte (!) nol kanggo entuk jarak adoh saka wates.
    //
    // Iki dudu kasus panggunaan sing kudu digunakake.
    //
    while number.first() == Some(&b'0') {
        number = &number[1..];
    }
    if number.len() >= 18 {
        return match sign {
            Sign::Positive => ShortcutToInf,
            Sign::Negative => ShortcutToZero,
        };
    }
    let abs_exp = num::from_str_unchecked(number);
    let e = match sign {
        Sign::Positive => abs_exp as i64,
        Sign::Negative => -(abs_exp as i64),
    };
    Valid(Decimal::new(integral, fractional, e))
}