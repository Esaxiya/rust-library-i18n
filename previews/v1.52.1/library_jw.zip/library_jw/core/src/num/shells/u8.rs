//! Pancet kanggo jinis ongko wilangan 8-bit sing durung ditandatangani.
//!
//! *[See also the `u8` primitive type][u8].*
//!
//! Kode anyar kudu nggunakake konstanta sing gegandhengan langsung ing jinis primitif.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `u8`"
)]

int_module! { u8 }