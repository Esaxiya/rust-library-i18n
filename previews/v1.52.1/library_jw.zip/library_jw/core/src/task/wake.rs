#![stable(feature = "futures_api", since = "1.36.0")]

use crate::fmt;
use crate::marker::{PhantomData, Unpin};

/// A `RawWaker` ngidini implementor saka eksekutor tugas kanggo nggawe [`Waker`] kang menehi prilaku wakeup selaras.
///
/// [vtable]: https://en.wikipedia.org/wiki/Virtual_method_table
///
/// Iku kasusun saka pitunjuk data lan [virtual function pointer table (vtable)][vtable] sing customizes tumindaké `RawWaker`.
///
///
#[derive(PartialEq, Debug)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct RawWaker {
    /// A pitunjuk data, kang bisa digunakake kanggo nyimpen data kasepakatan dibutuhna eksekutor.
    /// Iki bisa uga contone
    /// pitunjuk jinis-dibusak menyang `Arc` sing digandhengake karo tugas.
    /// Nilai kolom iki diwenehake menyang kabeh fungsi sing kalebu bagean saka tabel minangka parameter pisanan.
    ///
    data: *const (),
    /// Meja penunjuk fungsi virtual sing ngatur tumindake waker iki.
    vtable: &'static RawWakerVTable,
}

impl RawWaker {
    /// Nggawe `RawWaker` anyar saka `data` pitunjuk lan `vtable` kasedhiya.
    ///
    /// The `data` pitunjuk bisa digunakake kanggo nyimpen data kasepakatan dibutuhna eksekutor.Iki bisa uga contone
    /// pitunjuk jinis-dibusak menyang `Arc` sing digandhengake karo tugas.
    /// Nilai penunjuk iki bakal diwenehake menyang kabeh fungsi sing dadi bagean saka `vtable` minangka parameter pertama.
    ///
    /// `vtable` ngatur prilaku `Waker` sing digawe saka `RawWaker`.
    /// Kanggo saben operasi ing `Waker`, fungsi sing gegandhengan ing `vtable` saka `RawWaker` sing ndasari bakal disebut.
    ///
    ///
    ///
    #[inline]
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    pub const fn new(data: *const (), vtable: &'static RawWakerVTable) -> RawWaker {
        RawWaker { data, vtable }
    }
}

/// Tabel pointer fungsi virtual (vtable) sing nemtokake prilaku [`RawWaker`].
///
/// Ing pitunjuk liwati kanggo kabeh fungsi nang vtable punika pitunjuk `data` saka obyek [`RawWaker`] enclosing.
///
/// Fungsi nang struct iki sing mung dimaksudaké kanggo bisa disebut ing `data` pitunjuk barang [`RawWaker`] dibangun mlaku saka njero implementasine [`RawWaker`].
/// Nelpon siji saka fungsi sing nggunakake sembarang pitunjuk liyane `data` bakal nimbulaké prilaku cetho.
///
///
///
///
#[stable(feature = "futures_api", since = "1.36.0")]
#[derive(PartialEq, Copy, Clone, Debug)]
pub struct RawWakerVTable {
    /// Fungsi iki bakal ditelpon nalika [`RawWaker`] kloning, kayata nalika [`Waker`] sing disimpen [`RawWaker`] bakal dikloning.
    ///
    /// Implementasine saka fungsi iki kudu nyegah kabeh sumber daya sing dibutuhaké kanggo Kayata tambahan iki saka [`RawWaker`] lan tugas sing kagayut.
    /// Nelpon `wake` ing [`RawWaker`] sing diasilake kudu ngasilake tugas sing padha sing bakal dibangun karo [`RawWaker`] asli.
    ///
    ///
    ///
    clone: unsafe fn(*const ()) -> RawWaker,

    /// Fungsi iki bakal disebut nalika `wake` diarani ing [`Waker`].
    /// Sampeyan kudu nggawe tugas sing gegandhengan karo [`RawWaker`] iki.
    ///
    /// Implementasine fungsi iki kudu nggawe manawa ngeculake sumber daya sing ana gandhengane karo [`RawWaker`] lan tugas sing gegandhengan.
    ///
    ///
    wake: unsafe fn(*const ()),

    /// Fungsi iki bakal ditelpon nalika `wake_by_ref` ditelpon ing [`Waker`].
    /// Sampeyan kudu nggawe tugas sing gegandhengan karo [`RawWaker`] iki.
    ///
    /// Fungsi iki saiki lagi padha `wake`, nanging ora kudu nganggo pointer data kasedhiya.
    ///
    wake_by_ref: unsafe fn(*const ()),

    /// Fungsi iki diarani nalika [`RawWaker`] mudhun.
    ///
    /// Implementasine fungsi iki kudu nggawe manawa ngeculake sumber daya sing ana gandhengane karo [`RawWaker`] lan tugas sing gegandhengan.
    ///
    ///
    drop: unsafe fn(*const ()),
}

impl RawWakerVTable {
    /// Nggawe `RawWakerVTable` anyar saka fungsi `clone`, `wake`, `wake_by_ref`, lan `drop` kasedhiya.
    ///
    /// # `clone`
    ///
    /// Fungsi iki bakal ditelpon nalika [`RawWaker`] kloning, kayata nalika [`Waker`] sing disimpen [`RawWaker`] bakal dikloning.
    ///
    /// Implementasine saka fungsi iki kudu nyegah kabeh sumber daya sing dibutuhaké kanggo Kayata tambahan iki saka [`RawWaker`] lan tugas sing kagayut.
    /// Nelpon `wake` ing [`RawWaker`] sing diasilake kudu ngasilake tugas sing padha sing bakal dibangun karo [`RawWaker`] asli.
    ///
    /// # `wake`
    ///
    /// Fungsi iki bakal disebut nalika `wake` diarani ing [`Waker`].
    /// Sampeyan kudu nggawe tugas sing gegandhengan karo [`RawWaker`] iki.
    ///
    /// Implementasine fungsi iki kudu nggawe manawa ngeculake sumber daya sing ana gandhengane karo [`RawWaker`] lan tugas sing gegandhengan.
    ///
    ///
    /// # `wake_by_ref`
    ///
    /// Fungsi iki bakal ditelpon nalika `wake_by_ref` ditelpon ing [`Waker`].
    /// Sampeyan kudu nggawe tugas sing gegandhengan karo [`RawWaker`] iki.
    ///
    /// Fungsi iki saiki lagi padha `wake`, nanging ora kudu nganggo pointer data kasedhiya.
    ///
    /// # `drop`
    ///
    /// Fungsi iki diarani nalika [`RawWaker`] mudhun.
    ///
    /// Implementasine fungsi iki kudu nggawe manawa ngeculake sumber daya sing ana gandhengane karo [`RawWaker`] lan tugas sing gegandhengan.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_allow_const_fn_unstable(const_fn_fn_ptr_basics)]
    pub const fn new(
        clone: unsafe fn(*const ()) -> RawWaker,
        wake: unsafe fn(*const ()),
        wake_by_ref: unsafe fn(*const ()),
        drop: unsafe fn(*const ()),
    ) -> Self {
        Self { clone, wake, wake_by_ref, drop }
    }
}

/// `Context` tugas bedo.
///
/// Saiki, `Context` mung serves kanggo nyedhiyani akses menyang `&Waker` kang bisa digunakake kanggo tangi ing tugas saiki.
///
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Context<'a> {
    waker: &'a Waker,
    // Mesthekake kita future-bukti marang owah-owahan sing bedo dening mekso umur dadi podho (umur pitakonan-posisi sing contravariant nalika umur bali-posisi sing sajinis).
    //
    //
    //
    _marker: PhantomData<fn(&'a ()) -> &'a ()>,
}

impl<'a> Context<'a> {
    /// Nggawe `Context` anyar saka `&Waker`.
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn from_waker(waker: &'a Waker) -> Self {
        Context { waker, _marker: PhantomData }
    }

    /// Ngasilake referensi menyang `Waker` kanggo tugas saiki.
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn waker(&self) -> &'a Waker {
        &self.waker
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Context<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Context").field("waker", &self.waker).finish()
    }
}

/// A `Waker` iku nangani kanggo tangi tugas dening notifying eksekutor sing siap kanggo mbukak.
///
/// Pegangan iki ngemot conto [`RawWaker`], sing nemtokake prilaku tangi khusus eksekutor.
///
///
/// Ngleksanakake [`Clone`], [`Send`], lan [`Sync`].
///
#[repr(transparent)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Waker {
    waker: RawWaker,
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Unpin for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Send for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Sync for Waker {}

impl Waker {
    /// Tindakake tugas sing ana gandhengane karo `Waker` iki.
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake(self) {
        // Telpon bangun nyata didelegasikan liwat panggilan fungsi virtual kanggo implementasi sing ditemtokake dening pelaksana.
        //
        let wake = self.waker.vtable.wake;
        let data = self.waker.data;

        // Aja nelpon `drop`-waker bakal dikonsumsi dening `wake`.
        crate::mem::forget(self);

        // SAFETY: Iki aman amarga `Waker::from_raw` mung cara
        // kanggo nggawe inisialisasi `wake` lan `data` sing mbutuhake pangguna ngakoni yen kontrak `RawWaker` ditanggepi.
        //
        unsafe { (wake)(data) };
    }

    /// Tindakake tugas sing ana gandhengane karo `Waker` iki tanpa nganggo `Waker`.
    ///
    /// Iki padha `wake`, nanging kang luwih kurang efisien ing cilik ngendi `Waker` diduweni cumawis.
    /// Cara iki kudu luwih disenengi tinimbang nelpon `waker.clone().wake()`.
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake_by_ref(&self) {
        // Telpon bangun nyata didelegasikan liwat panggilan fungsi virtual kanggo implementasi sing ditemtokake dening pelaksana.
        //

        // SAFETY: deleng `wake`
        unsafe { (self.waker.vtable.wake_by_ref)(self.waker.data) }
    }

    /// Ngasilake `true` yen iki `Waker` lan `Waker` liyane wis awoken tugas padha.
    ///
    /// Fungsi iki bisa digunakake kanthi gaweyan paling apik, lan bisa uga ngasilake palsu sanajan `Waker` bakal nggugah tugas sing padha.
    /// Nanging, yen fungsi iki ngasilake `true`, dijamin manawa `Waker` bakal nggugah tugas sing padha.
    ///
    /// Fungsi iki utamane digunakake kanggo tujuan optimalisasi.
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn will_wake(&self, other: &Waker) -> bool {
        self.waker == other.waker
    }

    /// Nggawe `Waker` anyar saka [`RawWaker`].
    ///
    /// Tumindaké `Waker` bali wis cetho yen kontrak ditetepake ing [: RawWaker`] 's lan [: RawWakerVTable`]' s dokumentasi ora ayating.
    ///
    /// Mula cara iki ora aman.
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub unsafe fn from_raw(waker: RawWaker) -> Waker {
        Waker { waker }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Clone for Waker {
    #[inline]
    fn clone(&self) -> Self {
        Waker {
            // SAFETY: Iki aman amarga `Waker::from_raw` mung cara
            // kanggo nggawe inisialisasi `clone` lan `data` sing mbutuhake pangguna ngakoni yen kontrak [`RawWaker`] ditanggepi.
            //
            waker: unsafe { (self.waker.vtable.clone)(self.waker.data) },
        }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Drop for Waker {
    #[inline]
    fn drop(&mut self) {
        // SAFETY: Iki aman amarga `Waker::from_raw` mung cara
        // kanggo initialize `drop` lan `data` mrintahake pangguna kanggo ngakoni yen kontrak `RawWaker` wis ayating.
        //
        unsafe { (self.waker.vtable.drop)(self.waker.data) }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Waker {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let vtable_ptr = self.waker.vtable as *const RawWakerVTable;
        f.debug_struct("Waker")
            .field("data", &self.waker.data)
            .field("vtable", &vtable_ptr)
            .finish()
    }
}