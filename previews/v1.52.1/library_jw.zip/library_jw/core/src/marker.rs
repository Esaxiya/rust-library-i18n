//! traits primitif lan jinis sing makili sifat dhasar kanggo jinis.
//!
//! jinis Rust bisa diklasifikasikaké ing macem-macem cara migunani miturut sifat intrinsik sing.
//! klasifikasi Iki sing dituduhake minangka traits.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cell::UnsafeCell;
use crate::cmp;
use crate::fmt::Debug;
use crate::hash::Hash;
use crate::hash::Hasher;

/// Jinis-jinis sing bisa ditransfer tengen wates thread.
///
/// trait iki kanthi otomatis dipun ginakaken nalika compiler sing nemtokake iku cocok.
///
/// Contone jinis non-`Kirim" yaiku referensi-ngetung pitunjuk [`rc::Rc`][`Rc`].
/// Yen loro Utas nyoba kanggo Klone [: Rc`] s sing titik menyang Nilai referensi-dietung padha, padha bisa uga nyoba kanggo nganyari count referensi ing wektu sing padha, kang [undefined behavior][ub] amarga [`Rc`] ora nganggo operasi atom.
///
/// seduluré sawijining [`sync::Arc`][arc] ora nggunakake operasi atom (incurring sawetara nduwur sirah) lan kanthi mangkono `Send`.
///
/// Deleng [the Nomicon](../../nomicon/send-and-sync.html) kanggo rincian liyane.
///
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "send_trait")]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be sent between threads safely",
    label = "`{Self}` cannot be sent between threads safely"
)]
pub unsafe auto trait Send {
    // empty.
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *mut T {}

/// Jinis kanthi ukuran tetep dingerteni nalika nyusun.
///
/// Kabeh paramèter jinis duwe iso dilacak kaiket saka `Sized`.Ing ukara khusus `?Sized` bisa digunakake kanggo mbusak iki kaiket yen ora cocok.
///
/// ```
/// # #![allow(dead_code)]
/// struct Foo<T>(T);
/// struct Bar<T: ?Sized>(T);
///
/// // struct FooUse(Foo<[i32]>);//kesalahan: ukuran ora ginakaken kanggo [i32]
/// struct BarUse(Bar<[i32]>); // OK
/// ```
///
/// Pangecualian siji yaiku jinis `Self` sing implisit saka trait.
/// A trait ora duwe `Sized` iso dilacak bound minangka iki kompatibel karo [trait obyek] s ngendi, dening definisi, ing trait perlu kanggo karya karo kabeh implementors bisa, lan kanthi mangkono bisa dadi ukuran sembarang.
///
///
/// Sanajan Rust bakal ngidini sampeyan ngiket `Sized` menyang trait, sampeyan ora bakal bisa nggunakake aplikasi kasebut kanggo mbentuk obyek trait mengko:
///
/// ```
/// # #![allow(unused_variables)]
/// trait Foo { }
/// trait Bar: Sized { }
///
/// struct Impl;
/// impl Foo for Impl { }
/// impl Bar for Impl { }
///
/// let x: &dyn Foo = &Impl;    // OK
/// // ayo y: &dyn Bar= &Impl;//error: trait `Bar` ora bisa digawe obyek
/////
/// ```
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "sized"]
#[rustc_on_unimplemented(
    message = "the size for values of type `{Self}` cannot be known at compilation time",
    label = "doesn't have a size known at compile-time"
)]
#[fundamental] // kanggo Default, contone, sing mbutuhake `[T]: !Default` bisa dievaluasi
#[rustc_specialization_trait]
pub trait Sized {
    // Empty.
}

/// Jinis sing bisa "unsized" dadi jinis ukuran dinamis.
///
/// Contone, ing ukuran Uploaded jinis `[i8; 2]` nindakake `Unsize<[i8]>` lan `Unsize<dyn fmt::Debug>`.
///
/// Kabeh nindakake saka `Unsize` sing kasedhiya kanthi otomatis déning compiler ing.
///
/// `Unsize` dipun ginakaken kanggo:
///
/// - `[T; N]` iku `Unsize<[T]>`
/// - `T` yaiku `Unsize<dyn Trait>` nalika `T: Trait`
/// - `Foo<..., T, ...>` iku `Unsize<Foo<..., U, ...>>` yen:
///   - `T: Unsize<U>`
///   - Foo minangka struktur
///   - Mung ing lapangan pungkasan `Foo` wis jinis nglibatno `T`
///   - `T` dudu bagean saka jinis lapangan liyane
///   - `Bar<T>: Unsize<Bar<U>>`, yen ing lapangan pungkasan `Foo` wis jinis `Bar<T>`
///
/// `Unsize` digunakake bebarengan karo [`ops::CoerceUnsized`] kanggo ngidini kontaner "user-defined" kayata [`Rc`] ngemot jinis ukuran kanthi dinamis.
/// Deleng [DST coercion RFC][RFC982] lan [the nomicon entry on coercion][nomicon-coerce] kanggo rincian liyane.
///
/// [`ops::CoerceUnsized`]: crate::ops::CoerceUnsized
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [RFC982]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
#[unstable(feature = "unsize", issue = "27732")]
#[lang = "unsize"]
pub trait Unsize<T: ?Sized> {
    // Empty.
}

/// Dibutuhake trait kanggo ajeg digunakake ing pertandhingan pola.
///
/// Sembarang jinis sing entuk `PartialEq` kanthi otomatis ngetrapake trait iki,*tanpa preduli* manawa paramèter jinis kasebut ngetrapake `Eq`.
///
/// Yen item `const` ngandhut sawetara jinis sing ora ngleksanakake trait iki, banjur sing jinis salah siji (1.) ora ngleksanakake `PartialEq` (kang tegese pancet ora nyedhiyani sing cara comparison, kang generasi kode nompo cumawis), utawa (2.) iku nindakake *dhewe* versi `PartialEq` (kang kita nganggep ora salaras kanggo panglimbang struktural-podo).
///
///
/// Ing salah siji saka loro cara ing ndhuwur, kita nolak panggunaan saka pancet kuwi ing pertandhingan pola.
///
/// Deleng uga ing [structural match RFC][RFC1445], lan [issue 63438] kang motivasi pindah saka desain basis ngubungake kanggo trait iki.
///
/// [RFC1445]: https://github.com/rust-lang/rfcs/blob/master/text/1445-restrict-constants-in-patterns.md
/// [issue 63438]: https://github.com/rust-lang/rust/issues/63438
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(PartialEq)]`")]
#[lang = "structural_peq"]
pub trait StructuralPartialEq {
    // Empty.
}

/// Dibutuhake trait kanggo ajeg digunakake ing pertandhingan pola.
///
/// Sembarang jinis sing asalé `Eq` otomatis nindakake trait iki,*preduli* saka apa jinis paramèter sawijining ngleksanakake `Eq`.
///
/// Iki hack bisa watara watesan ing sistem jinis kita.
///
/// # Background
///
/// Kita arep kanggo sing sing jinis consts digunakake ing pertandhingan pola duwe ngubungake `#[derive(PartialEq, Eq)]`.
///
/// Ing jagad sing luwih ideal, kita bisa mriksa syarat kasebut kanthi mriksa jinis sing diwenehake `StructuralPartialEq` trait *lan*`Eq` trait.
/// Nanging, sampeyan bisa duwe ADT sing *nindakake*`derive(PartialEq, Eq)`, lan dadi kasus sing pengin ditampa dening compiler, nanging jinis sing tetep ora bisa ngetrapake `Eq`.
///
/// Yaiku, kasus kaya iki:
///
/// ```rust
/// #[derive(PartialEq, Eq)]
/// struct Wrap<X>(X);
///
/// fn higher_order(_: &()) { }
///
/// const CFN: Wrap<fn(&())> = Wrap(higher_order);
///
/// fn main() {
///     match CFN {
///         CFN => {}
///         _ => {}
///     }
/// }
/// ```
///
/// (Masalah ing kode ndhuwur iku `Wrap<fn(&())>` ora ngleksanakake `PartialEq`, utawa `Eq`, amarga: kanggo < 'a> fn(&'a _)` does not implement those traits.)
///
/// Mula, kita ora bisa ngandelake mriksa naif kanggo `StructuralPartialEq` lan `Eq`.
///
/// Minangka hack kanggo karya sak iki, kita nggunakake rong traits kapisah nyuntikaken dening saben loro asalé (`#[derive(PartialEq)]` lan `#[derive(Eq)]`) lan mriksa sing loro mau sing saiki minangka bagéan saka pamriksa struktural-match.
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(Eq)]`")]
#[lang = "structural_teq"]
pub trait StructuralEq {
    // Empty.
}

/// Jinis kang angka bisa Samarinda mung dening Nyalin bit.
///
/// Kanthi gawan, ikatan variabel duwe 'pamindhahan semantik.'Kanthi tembung liyane:
///
/// ```
/// #[derive(Debug)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `x` wis pindhah menyang `y`, lan mula ora bisa digunakake
///
/// // println ("{: ?}", x);//error: panggunaan nilai sing dipindhah
/// ```
///
/// Nanging, yen jinis nindakake `Copy`, tinimbang wis 'nyalin semantik':
///
/// ```
/// // Kita bisa niru implementasine `Copy`.
/// // `Clone` uga dibutuhake, minangka iku supertrait saka `Copy`.
/// #[derive(Debug, Copy, Clone)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `y` yaiku salinan `x`
///
/// println!("{:?}", x); // A-OK!
/// ```
///
/// Iku penting kanggo Wigati sing ing loro conto iki, ing prabédan mung apa sing diijini akses `x` sawise assignment.
/// Ing hood, loro salinan lan pamindhahan bisa kasil bit kang disalin ing memori, senajan iki kadhangkala optimized adoh.
///
/// ## Kepiye cara ngetrapake `Copy`?
///
/// Ana rong cara kanggo ngleksanakake `Copy` ing jinis.gampang iku kanggo nggunakake `derive`:
///
/// ```
/// #[derive(Copy, Clone)]
/// struct MyStruct;
/// ```
///
/// Sampeyan uga bisa ngetrapake `Copy` lan `Clone` kanthi manual:
///
/// ```
/// struct MyStruct;
///
/// impl Copy for MyStruct { }
///
/// impl Clone for MyStruct {
///     fn clone(&self) -> MyStruct {
///         *self
///     }
/// }
/// ```
///
/// Ana prabédan cilik ing antarane loro: strategi `derive` uga bakal menehi `Copy` sing kaiket ing paramèter jinis, sing ora mesthi dikepengini.
///
/// ## Apa ing antarane prabédan `Copy` lan `Clone`?
///
/// Salinan kedadeyan kanthi implisit, contone minangka bagean saka tugas `y = x`.Prilaku `Copy` ora overloadable;iku mesthi dadi salinan sing cukup bijaksana.
///
/// Kloning minangka tumindak eksplisit, `x.clone()`.Implementasi [`Clone`] bisa nyedhiyakake prilaku khusus jinis sing dibutuhake kanggo nyalin nilai kanthi aman.
/// Contone, ing implementasine saka [`Clone`] kanggo [`String`] perlu kanggo nyalin-kanggo nuding senar buffer ing numpuk ing.
/// Copy bitwise prasaja nilai [`String`] namung badhe nyalin pitunjuk, anjog menyang free pindho mudhun baris.
/// Amarga alasan iki, [`String`] yaiku [`Clone`] nanging ora `Copy`.
///
/// [`Clone`] punika supertrait saka `Copy`, supaya kabeh kang `Copy` uga kudu ngleksanakake [`Clone`].
/// Yen jinis punika `Copy` banjur implementasine [`Clone`] mung perlu kanggo bali `*self` (ndeleng conto ing ndhuwur).
///
/// ## Nalika jinis bisa dadi `Copy`?
///
/// Jinis bisa ngetrapake `Copy` yen kabeh komponen ngetrapake `Copy`.Contone, struct iki bisa dadi `Copy`:
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Copy, Clone)]
/// struct Point {
///    x: i32,
///    y: i32,
/// }
/// ```
///
/// Struktur bisa `Copy`, lan [`i32`] yaiku `Copy`, mula `Point` layak dadi `Copy`.
/// Miturut kontras, nimbang
///
/// ```
/// # #![allow(dead_code)]
/// # struct Point;
/// struct PointList {
///     points: Vec<Point>,
/// }
/// ```
///
/// The struct `PointList` ora bisa ngleksanakake `Copy`, amarga [`Vec<T>`] ora `Copy`.Yen nyoba ngetrapake implementasi `Copy`, kita bakal entuk kesalahan:
///
/// ```text
/// the trait `Copy` may not be implemented for this type; field `points` does not implement `Copy`
/// ```
///
/// Referensi sing dituduhake (`&T`) uga `Copy`, mula jinis bisa uga `Copy`, sanajan uga nuduhake referensi jinis `T` yaiku *dudu*`Copy`.
/// Coba struct ngisor, kang bisa ngleksanakake `Copy`, amarga mung ngemu *sambungan referensi* kanggo kita jinis non-`Copy` `PointList` saka ndhuwur:
///
/// ```
/// # #![allow(dead_code)]
/// # struct PointList;
/// #[derive(Copy, Clone)]
/// struct PointListWrapper<'a> {
///     point_list_ref: &'a PointList,
/// }
/// ```
///
/// ## Nalika ora bisa * Tipe sandi dadi `Copy`?
///
/// Sawetara jinis ora bisa disalin aman.Contone, Nyalin `&mut T` bakal nggawe referensi mutable aliased.
/// Nyalin [`String`] bakal duplikat tanggung jawab kanggo ngatur [: String`] 's buffer, anjog menyang free pindho.
///
/// Umumake kasus pungkasan, jinis apa wae sing ngetrapake [`Drop`] ora bisa `Copy`, amarga ngatur sawetara sumber saliyane bait [`size_of::<T>`] dhewe.
///
/// Yen sampeyan nyoba ngetrapake `Copy` ing strukture utawa enum sing ngemot data non-`Copy`, sampeyan bakal entuk kesalahan [E0204].
///
/// [E0204]: ../../error-index.html#E0204
///
/// ## Nalika *kudu* Tipe sandi dadi `Copy`?
///
/// Umumé ngandika, yen jinis _can_ ngleksanakake `Copy`, ngirim.
/// Tetep wonten ing pikiran, sanadyan, sing penerapan `Copy` bagéan saka API umum saka jinis.
/// Yen jinis bisa dadi non-`Copy` ing future, iku bisa dadi bijaksana kanggo ngilangake implementasine `Copy` saiki, supaya owah-owahan API bejat.
///
/// ## Pelaksana tambahan
///
/// Saliyane [implementors listed below][impls], jinis-jinis ing ngisor iki uga ngetrapake `Copy`:
///
/// * Jinis item fungsi (yaiku, macem-macem jinis sing ditemtokake kanggo saben fungsi)
/// * Fungsi jinis pitunjuk (kayata, `fn() -> i32`)
/// * jinis Array, kanggo kabeh ukuran, manawa jinis item uga nindakake `Copy` (eg, `[i32; 123456]`)
/// * jinis Tuple, yen saben komponèn uga nindakake `Copy` (eg, `()`, `(i32, bool)`)
/// * jinis Press, yen padha dijupuk ora Nilai saka lingkungan utawa yen kabeh nilai dijupuk kuwi ngleksanakake `Copy` piyambak.
///   Elinga yen variabel sing dijupuk nganggo referensi bareng mesthi ngetrapake `Copy` (sanajan referensi ora), dene variabel sing dijupuk nganggo referensi sing bisa diowahi ora nate ngetrapake `Copy`.
///
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
/// [`String`]: ../../std/string/struct.String.html
/// [`size_of::<T>`]: crate::mem::size_of
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "copy"]
// FIXME(matthewjasper) Iki ngidini Nyalin jinis sing ora ngleksanakake `Copy` amarga saka wates umur Good news (niru `A<'_>` nalika mung `A<'static>: Copy` lan `A<'_>: Clone`).
// We kudu ngubungake iki kene kanggo saiki mung amarga ana cukup sawetara Spesialisasi ana ing `Copy` sing wis ana ing perpustakaan standar, lan boten wonten cara kanggo aman duwe prilaku sapunika.
//
//
//
//
#[rustc_unsafe_specialization_marker]
pub trait Copy: Clone {
    // Empty.
}

/// gedhe Niru ngasilaken impl saka trait `Copy`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Copy($item:item) {
    /* compiler built-in */
}

/// Jinis sing aman kanggo nuduhake referensi ing antarane utas.
///
/// trait iki kanthi otomatis dipun ginakaken nalika compiler sing nemtokake iku cocok.
///
/// Ing makna punika: jinis `T` punika [`Sync`] yen lan mung yen `&T` punika [`Send`].
/// Kanthi tembung liyane, yen ora ana kemungkinan [undefined behavior][ub] (kalebu balapan data) nalika ngliwati referensi `&T` ing antarane utas.
///
/// Kaya sing diarepake, jinis primitif kaya [`u8`] lan [`f64`] kabeh ana [`Sync`], lan uga jinis agregat sederhana sing ngemot, kayata tupel, strukture lan enum.
/// Conto liyane jinis [`Sync`] dhasar kalebu jinis "immutable" kaya `&T`, lan sing nduweni mutasi warisan sing luwih murah, kayata [`Box<T>`][box], [`Vec<T>`][vec] lan umume jinis koleksi liyane.
///
/// (Parameter umum kudu [`Sync`] supaya kontainer dadi [`Sync`].)
///
/// A akibat Luwih ngagetne definisi iku `&mut T` punika `Sync` (yen `T` punika `Sync`) sanadyan iku misale jek kaya sing bisa nyedhiyani mutasi unsynchronized.
/// Trick sing referensi mutable konco referensi sambungan (sing, `& &mut T`) dadi maca-mung, yen iku `& &T`.
/// Empu ana risiko lomba data.
///
/// Jinis sing ora `Sync` sing sing duwe "interior mutability" ing wangun non-thread-aman, kayata [`Cell`][cell] lan [`RefCell`][refcell].
/// Jinis kasebut ngidini mutasi isine sanajan uga referensi sambungan sing ora bisa diganti.
/// Contone cara `set` ing [`Cell<T>`][cell] njupuk `&self`, supaya mung mbutuhake referensi sambungan [`&Cell<T>`][cell].
/// Cara kasebut ora nindakake sinkronisasi, mula [`Cell`][cell] ora bisa dadi `Sync`.
///
/// Conto liyane jinis non-`Sync` yaiku referensi-ngetung pointer [`Rc`][rc].
/// Yen diwenehi referensi [`&Rc<T>`][rc], sampeyan bisa nglonk [`Rc<T>`][rc] anyar, ngowahi jumlah referensi kanthi cara non-atom.
///
/// Kanggo kasus yen perlu mutasi mutakhir sing aman, Rust nyedhiyakake [atomic data types], uga kunci eksplisit liwat [`sync::Mutex`][mutex] lan [`sync::RwLock`][rwlock].
/// Jinis-jinis mesthekake yen sembarang mutasi bisa ora sabab balapan data, Empu jinis `Sync`.
/// Uga, [`sync::Arc`][arc] menehi analog thread-aman saka [`Rc`][rc].
///
/// Sembarang jinis karo mutability interior uga kudu nggunakake pambungkus [`cell::UnsafeCell`][unsafecell] sak value(s) kang bisa mutated liwat referensi sambungan.
/// Netepi mengkono iki [undefined behavior][ub].
/// Contone, [`transmute`][transmute]-ing saka `&T` dadi `&mut T` ora valid.
///
/// Waca [the Nomicon][nomicon-send-and-sync] kanggo katrangan bab `Sync`.
///
/// [box]: ../../std/boxed/struct.Box.html
/// [vec]: ../../std/vec/struct.Vec.html
/// [cell]: crate::cell::Cell
/// [refcell]: crate::cell::RefCell
/// [rc]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [atomic data types]: crate::sync::atomic
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [unsafecell]: crate::cell::UnsafeCell
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [transmute]: crate::mem::transmute
/// [nomicon-send-and-sync]: ../../nomicon/send-and-sync.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "sync_trait")]
#[lang = "sync"]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be shared between threads safely",
    label = "`{Self}` cannot be shared between threads safely"
)]
pub unsafe auto trait Sync {
    // FIXME(estebank): sawise dhukungan kanggo nambah cathetan ing `rustc_on_unimplemented` ing beta, lan wis ditambahake kanggo mriksa manawa penutupan ana ing endi wae ing rantai syarat, tambahake kaya (#48534):
    //
    //
    // ```
    // on(
    //     closure,
    //     note="`{Self}` cannot be shared safely, consider marking the closure `move`"
    // ),
    // ```

    // Empty
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *mut T {}

macro_rules! impls {
    ($t: ident) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Hash for $t<T> {
            #[inline]
            fn hash<H: Hasher>(&self, _: &mut H) {}
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialEq for $t<T> {
            fn eq(&self, _other: &$t<T>) -> bool {
                true
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Eq for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialOrd for $t<T> {
            fn partial_cmp(&self, _other: &$t<T>) -> Option<cmp::Ordering> {
                Option::Some(cmp::Ordering::Equal)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Ord for $t<T> {
            fn cmp(&self, _other: &$t<T>) -> cmp::Ordering {
                cmp::Ordering::Equal
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Copy for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Clone for $t<T> {
            fn clone(&self) -> Self {
                Self
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Default for $t<T> {
            fn default() -> Self {
                Self
            }
        }

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralPartialEq for $t<T> {}

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralEq for $t<T> {}
    };
}

/// Zero-ukuran jinis digunakake kanggo menehi tandha bab sing "act like" padha duwe `T`.
///
/// Nambahake lapangan `PhantomData<T>` kanggo jinis ngandhani compiler sing jinis tumindak minangka sanadyan iku nyimpen Nilai saka jinis `T`, sanadyan ora tenan.
/// Informasi iki digunakake nalika ngitung sifat keamanan tartamtu.
///
/// Kanggo panjelasan luwih jero babagan cara nggunakake `PhantomData<T>`, waca [the Nomicon](../../nomicon/phantom-data.html).
///
/// # A cathetan ghastly 👻👻👻
///
/// Sanadyan wong loro duwe jeneng medeni, `PhantomData` lan 'jinis phantom' sing gegandhengan, nanging ora podho rupo.A parameter jinis phantom iku mung parameter jinis kang tau digunakake.
/// Ing Rust, iki asring nimbulaké compiler kanggo sambat, lan solusi kanggo nambah nggunakake "dummy" kanthi cara `PhantomData`.
///
/// # Examples
///
/// ## paramèter umur dienggo
///
/// Mbok menawa paling cilik umum kanggo `PhantomData` punika struct sing duwe parameter umur dienggo, biasane minangka bagéan saka sawetara kode aman.
/// Contone, iki str `Slice` sing duwe rong petunjuk tipe `*const T`, bisa uga nuduhake rangking ing endi wae:
///
/// ```compile_fail,E0392
/// struct Slice<'a, T> {
///     start: *const T,
///     end: *const T,
/// }
/// ```
///
/// Tujuane supaya data dhasar mung valid sajrone `'a`, dadi `Slice` ora kudu ngluwihi `'a`.
/// Nanging, maksud iki ora ditulis ing kode, awit ora ana ulah saka umur `'a` lan Empu iku ora mbusak data apa iku ditrapake kanggo.
/// Kita bisa mbenerake iki dening nuduhake compiler kanggo tumindak *kaya* ing struct `Slice` sing referensi `&'a T`:
///
/// ```
/// use std::marker::PhantomData;
///
/// # #[allow(dead_code)]
/// struct Slice<'a, T: 'a> {
///     start: *const T,
///     end: *const T,
///     phantom: PhantomData<&'a T>,
/// }
/// ```
///
/// Iki uga ing siji mbutuhake cathetan `T: 'a`, nuduhake yen apa referensi ing `T` sing bener liwat umur `'a`.
///
/// Nalika dhisik a `Slice` sampeyan mung nyedhiyani Nilai `PhantomData` kanggo lapangan `phantom`:
///
/// ```
/// # #![allow(dead_code)]
/// # use std::marker::PhantomData;
/// # struct Slice<'a, T: 'a> {
/// #     start: *const T,
/// #     end: *const T,
/// #     phantom: PhantomData<&'a T>,
/// # }
/// fn borrow_vec<T>(vec: &Vec<T>) -> Slice<'_, T> {
///     let ptr = vec.as_ptr();
///     Slice {
///         start: ptr,
///         end: unsafe { ptr.add(vec.len()) },
///         phantom: PhantomData,
///     }
/// }
/// ```
///
/// ## jinis paramèter sing ora dienggo
///
/// Kadhangkala sampeyan duwe parameter jinis sing ora digunakake sing nuduhake jinis data sing diarani "tied", sanajan data kasebut ora ditemokake ing strukture dhewe.
/// Punika conto ngendi iki mengkene karo [FFI].
/// Antarmuka asing nggunakake gagang jinis `*mut ()` kanggo ngrujuk angka Rust kanthi macem-macem jinis.
/// We trek jinis Rust nggunakake parameter jinis phantom ing struct `ExternalResource` kang nggabung nangani.
///
/// [FFI]: ../../book/ch19-01-unsafe-rust.html#using-extern-functions-to-call-external-code
///
/// ```
/// # #![allow(dead_code)]
/// # trait ResType { }
/// # struct ParamType;
/// # mod foreign_lib {
/// #     pub fn new(_: usize) -> *mut () { 42 as *mut () }
/// #     pub fn do_stuff(_: *mut (), _: usize) {}
/// # }
/// # fn convert_params(_: ParamType) -> usize { 42 }
/// use std::marker::PhantomData;
/// use std::mem;
///
/// struct ExternalResource<R> {
///    resource_handle: *mut (),
///    resource_type: PhantomData<R>,
/// }
///
/// impl<R: ResType> ExternalResource<R> {
///     fn new() -> Self {
///         let size_of_res = mem::size_of::<R>();
///         Self {
///             resource_handle: foreign_lib::new(size_of_res),
///             resource_type: PhantomData,
///         }
///     }
///
///     fn do_stuff(&self, param: ParamType) {
///         let foreign_params = convert_params(param);
///         foreign_lib::do_stuff(self.resource_handle, foreign_params);
///     }
/// }
/// ```
///
/// ## Kepemilikan lan mriksa gulung
///
/// Nambahake lapangan jinis `PhantomData<T>` nuduhake yen jinis ndarbeni data saka jinis `T`.Sabanjure, iki tegese nalika jinis sampeyan mudhun, bisa uga ngeculake siji utawa luwih jinis `T`.
/// Iki wis bearing ing analisis [drop check] ing Rust compiler kang.
///
/// Yen struct Panjenengan ora nyatane *dhewe* data saka jinis `T`, iku luwih apik kanggo nggunakake tipe referensi, kaya `PhantomData<&'a T>` (ideally) utawa `PhantomData<*const T>` (yen ora umur ditrapake), supaya dadi ora kanggo nunjukaké kepemilikan.
///
///
/// [drop check]: ../../nomicon/dropck.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "phantom_data"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct PhantomData<T: ?Sized>;

impls! { PhantomData }

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Sync + ?Sized> Send for &T {}
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Send + ?Sized> Send for &mut T {}
}

/// Compiler-internal trait digunakake kanggo nunjukaké jinis discriminants enum.
///
/// trait iki kanthi otomatis dileksanakake kanggo saben jinis lan ora nambah jaminan menyang [`mem::Discriminant`].
/// Iku prilaku undefined ** ** kanggo transmute antarane `DiscriminantKind::Discriminant` lan `mem::Discriminant`.
///
/// [`mem::Discriminant`]: crate::mem::Discriminant
///
#[unstable(
    feature = "discriminant_kind",
    issue = "none",
    reason = "this trait is unlikely to ever be stabilized, use `mem::discriminant` instead"
)]
#[lang = "discriminant_kind"]
pub trait DiscriminantKind {
    /// Jinis Diskriminan, kang kudu gawe marem trait bounds dibutuhaké déning `mem::Discriminant`.
    ///
    #[lang = "discriminant_type"]
    type Discriminant: Clone + Copy + Debug + Eq + PartialEq + Hash + Send + Sync + Unpin;
}

/// trait internal-kompiler digunakake kanggo nemtokake jinis apa sing ana `UnsafeCell` ing njero internal, nanging ora liwat indireksi.
///
/// Contone, mengaruhi apa `static` saka jinis kasebut dilebokake ing memori statis mung maca utawa memori statis sing bisa ditulis.
///
#[lang = "freeze"]
pub(crate) unsafe auto trait Freeze {}

impl<T: ?Sized> !Freeze for UnsafeCell<T> {}
unsafe impl<T: ?Sized> Freeze for PhantomData<T> {}
unsafe impl<T: ?Sized> Freeze for *const T {}
unsafe impl<T: ?Sized> Freeze for *mut T {}
unsafe impl<T: ?Sized> Freeze for &T {}
unsafe impl<T: ?Sized> Freeze for &mut T {}

/// Jinis-jinis sing bisa aman dipindhah sawise kang pinned.
///
/// Rust dhewe wis ora pemanggih saka jinis immovable, lan nganggep gerakane (eg, liwat assignment utawa [`mem::replace`]) tansah aman.
///
/// Jinis [`Pin`][Pin] digunakake kanggo nyegah pamindhahan liwat sistem tipe.Penunjuk `P<T>` kebungkus ing [`Pin<P<T>>`][Pin] pambungkus ora bisa dipindhah metu saka.
/// Deleng dokumentasi [`pin` module] kanggo informasi luwih lengkap babagan pin.
///
/// Ngleksanakake `Unpin` trait kanggo `T` ngangkat watesan mateni jinis kasebut, sing banjur ngidini mindhah `T` saka [`Pin<P<T>>`][Pin] kanthi fungsi kayata [`mem::replace`].
///
///
/// `Unpin` ora duwe akibat babar pisan kanggo data sing ora disemat.
/// Ing tartamtu, [`mem::replace`] seneng gerakane data `!Unpin` (kerjane kanggo maksud apa `&mut T`, ora mung nalika `T: Unpin`).
/// Nanging, sampeyan ora bisa nggunakake [`mem::replace`] ing data kebungkus nang [`Pin<P<T>>`][Pin] amarga sampeyan ora bisa njaluk `&mut T` sing perlu kanggo sing, lan *sing* apa ndadekake sistem karya iki.
///
/// Dadi iki, contone, mung bisa rampung ing jinis penerapan `Unpin`:
///
/// ```rust
/// # #![allow(unused_must_use)]
/// use std::mem;
/// use std::pin::Pin;
///
/// let mut string = "this".to_string();
/// let mut pinned_string = Pin::new(&mut string);
///
/// // Kita butuh referensi sing bisa diowahi kanggo telpon `mem::replace`.
/// // Kita bisa diwenehi referensi kuwi dening (implicitly) invoking `Pin::deref_mut`, nanging sing mung bisa amarga `String` nindakake `Unpin`.
/////
/// mem::replace(&mut *pinned_string, "other".to_string());
/// ```
///
/// trait iki kanthi otomatis dileksanakake kanggo meh kabeh jinis.
///
/// [`mem::replace`]: crate::mem::replace
/// [Pin]: crate::pin::Pin
/// [`pin` module]: crate::pin
///
///
///
///
///
///
#[stable(feature = "pin", since = "1.33.0")]
#[rustc_on_unimplemented(
    on(_Self = "std::future::Future", note = "consider using `Box::pin`",),
    message = "`{Self}` cannot be unpinned"
)]
#[lang = "unpin"]
pub auto trait Unpin {}

/// Jinis panandha sing ora ngetrapake `Unpin`.
///
/// Yen jinis ngemot `PhantomPinned`, standar ora bakal dileksanakake `Unpin`.
#[stable(feature = "pin", since = "1.33.0")]
#[derive(Debug, Default, Copy, Clone, Eq, PartialEq, Ord, PartialOrd, Hash)]
pub struct PhantomPinned;

#[stable(feature = "pin", since = "1.33.0")]
impl !Unpin for PhantomPinned {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a T {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a mut T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *const T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *mut T {}

/// Implementasi `Copy` kanggo jinis primitif.
///
/// Nindakake sing ora bisa diterangake ing Rust sing dipun ginakaken ing `traits::SelectionContext::copy_clone_conditions()` ing `rustc_trait_selection`.
///
///
mod copy_impls {

    use super::Copy;

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Copy for ! {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *const T {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *mut T {}

    /// Referensi bareng bisa disalin, nanging referensi sing bisa diowahi *ora bisa*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for &T {}
}