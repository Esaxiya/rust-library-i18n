//! Nemtokake iterator sing diduweni `IntoIter` kanggo susunan.

use crate::{
    fmt,
    iter::{ExactSizeIterator, FusedIterator, TrustedLen},
    mem::{self, MaybeUninit},
    ops::Range,
    ptr,
};

/// Pengulangan [array] regane.
#[stable(feature = "array_value_iter", since = "1.51.0")]
pub struct IntoIter<T, const N: usize> {
    /// Iki minangka rangking sing lagi diowahi.
    ///
    /// Unsur kanthi indeks `i` ing endi `alive.start <= i < alive.end` durung diasilake lan kalebu entri larik.
    /// Unsur karo indeks `i < alive.start` utawa `i >= alive.end` wis menehi wis lan ora kudu diakses maneh!Unsur-unsur sing mati bisa uga ana ing negara sing ora ana gandhengane!
    ///
    ///
    /// Dadi sing ngundang yaiku:
    /// - `data[alive]` urip (IE ngandhut unsur bener)
    /// - `data[..alive.start]` lan `data[alive.end..]` mati (IE unsur padha wis maca lan ora kudu kena maneh!)
    ///
    ///
    ///
    data: [MaybeUninit<T>; N],

    /// Unsur ing `data` sing durung diasilake.
    ///
    /// Invariants:
    /// - `alive.start <= alive.end`
    /// - `alive.end <= N`
    alive: Range<usize>,
}

impl<T, const N: usize> IntoIter<T, N> {
    /// Nggawe iterator anyar liwat `array` sing diwenehake.
    ///
    /// *Cathetan*: cara iki bisa uga ora digunakake ing future, sawise [`IntoIterator` is implemented for arrays][array-into-iter].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::array;
    ///
    /// for value in array::IntoIter::new([1, 2, 3, 4, 5]) {
    ///     // Jinis `value` punika `i32` kene, tinimbang `&i32`
    ///     let _: i32 = value;
    /// }
    /// ```
    /// [array-into-iter]: https://github.com/rust-lang/rust/pull/65819
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn new(array: [T; N]) -> Self {
        // SAFETY: Transmisi ing kene pancen aman.Dokumen saka `MaybeUninit`
        // promise:
        //
        // > `MaybeUninit<T>` dijamin duwe ukuran lan keselarasan sing padha
        // > minangka `T`.
        //
        // Dokumen malah nuduhake transmute saka larik `MaybeUninit<T>` menyang larik `T`.
        //
        //
        // Kanthi mekaten, inisialisasi iki nglegakake kanggo para undhangan.

        // FIXME(LukasKalbertodt): bener nggunakake `mem::transmute` kene, yen kerjane karo generics const:
        //     `mem::transmute::<[T; N], [MaybeUninit<T>; N]>(array)`
        //
        // Nganti banjur, kita bisa nggunakake `mem::transmute_copy` kanggo nggawe salinan bitwise minangka jinis beda, banjur lali `array` supaya ora dropped.
        //
        //
        unsafe {
            let iter = Self { data: mem::transmute_copy(&array), alive: 0..N };
            mem::forget(array);
            iter
        }
    }

    /// Ngasilake irisan sing ora bisa diowahi kanggo kabeh elemen sing durung ngasilake.
    ///
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_slice(&self) -> &[T] {
        // SAFETY: Kita ngerti manawa kabeh elemen ing `alive` diwiwiti kanthi bener.
        unsafe {
            let slice = self.data.get_unchecked(self.alive.clone());
            MaybeUninit::slice_assume_init_ref(slice)
        }
    }

    /// Ngasilake irisan mutable kabeh unsur sing durung menehi durung.
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        // SAFETY: Kita ngerti manawa kabeh elemen ing `alive` diwiwiti kanthi bener.
        unsafe {
            let slice = self.data.get_unchecked_mut(self.alive.clone());
            MaybeUninit::slice_assume_init_mut(slice)
        }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Iterator for IntoIter<T, N> {
    type Item = T;
    fn next(&mut self) -> Option<Self::Item> {
        // Goleki indeks sabanjure saka ngarep.
        //
        // Nambah `alive.start` kanthi 1 njaga invarian babagan `alive`.
        // Nanging, amarga ana pangowahan kasebut, zona sing urip ora `data[alive]` maneh, nanging `data[idx..alive.end]`.
        //
        self.alive.next().map(|idx| {
            // Waca unsur saka larik.
            // SAFETY: `idx` minangka indeks menyang bekas wilayah "alive" ing
            // larikMaca elemen iki tegese `data[idx]` dianggep saiki wis mati (yaiku ora ndemek).
            // Amarga `idx` minangka wiwitan zona sing urip, zona sing urip saiki dadi `data[alive]` maneh, mulihake kabeh invarian.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        let len = self.len();
        (len, Some(len))
    }

    fn count(self) -> usize {
        self.len()
    }

    fn last(mut self) -> Option<Self::Item> {
        self.next_back()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> DoubleEndedIterator for IntoIter<T, N> {
    fn next_back(&mut self) -> Option<Self::Item> {
        // Goleki indeks sabanjure saka mburi.
        //
        // Ngurangi `alive.end` kanthi 1 njaga invarian babagan `alive`.
        // Nanging, amarga ana pangowahan kasebut, zona sing urip ora `data[alive]` maneh, nanging `data[alive.start..=idx]`.
        //
        self.alive.next_back().map(|idx| {
            // Waca unsur saka larik.
            // SAFETY: `idx` minangka indeks menyang bekas wilayah "alive" ing
            // larikMaca elemen iki tegese `data[idx]` dianggep saiki wis mati (yaiku ora ndemek).
            // Amarga `idx` minangka pungkasan zona sing urip, zona sing urip saiki dadi `data[alive]` maneh, mulihake kabeh invarian.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Drop for IntoIter<T, N> {
    fn drop(&mut self) {
        // SAFETY: Iki aman: `as_mut_slice` ngasilake persis sub-irisan
        // unsur sing durung dipindhah lan tetep bakal mudhun.
        //
        unsafe { ptr::drop_in_place(self.as_mut_slice()) }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> ExactSizeIterator for IntoIter<T, N> {
    fn len(&self) -> usize {
        // Ora bakal kebanjiran amarga invariant `urip.wiwiti <=
        // alive.end`.
        self.alive.end - self.alive.start
    }
    fn is_empty(&self) -> bool {
        self.alive.is_empty()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> FusedIterator for IntoIter<T, N> {}

// Iterator kasebut nglaporake dawa sing bener.
// Jumlah elemen "alive" (sing isih bakal diasilake) yaiku dawa kisaran `alive`.
// sawetara iki decremented ing dawa ing salah siji `next` utawa `next_back`.
// Sampeyan mesthi mudhun dening 1 ing cara kasebut, nanging mung yen `Some(_)` bali.
#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
unsafe impl<T, const N: usize> TrustedLen for IntoIter<T, N> {}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: Clone, const N: usize> Clone for IntoIter<T, N> {
    fn clone(&self) -> Self {
        // Elinga, kita ora prelu cocog karo kisaran urip sing padha, mula mung bisa dikloning dadi offset 0 tanpa preduli ing endi `self`.
        //
        let mut new = Self { data: MaybeUninit::uninit_array(), alive: 0..0 };

        // Klone kabeh elemen urip.
        for (src, dst) in self.as_slice().iter().zip(&mut new.data) {
            // Tulis klone menyang larik anyar, banjur nganyari sawetara sing isih ana.
            // Yen kloning panics, kita bakal ngeculake item sadurunge.
            dst.write(src.clone());
            new.alive.end += 1;
        }

        new
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: fmt::Debug, const N: usize> fmt::Debug for IntoIter<T, N> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Mung nyithak elemen sing durung ngasilake: kita ora bisa ngakses elemen sing ngasilake maneh.
        //
        f.debug_tuple("IntoIter").field(&self.as_slice()).finish()
    }
}