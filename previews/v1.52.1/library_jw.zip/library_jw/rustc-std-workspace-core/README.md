# `rustc-std-workspace-core` crate

crate iki shim lan kosong crate kang mung gumantung ing `libcore` lan reexports kabeh isi.
crate minangka inti saka pemberdayaan perpustakaan standar kanggo gumantung ing crates saka crates.io

Crates ing crates.io sing perpustakaan standar gumantung perlu kanggo gumantung ing `rustc-std-workspace-core` crate saka crates.io, kang kosong.

Kita nggunakake `[patch]` kanggo ngilangi crate iki ing repositori iki.
Akibaté, crates ing crates.io bakal tarik ketergantungan edge kanggo `libcore`, versi ditetepake ing gudhang iki.
Sing kudu tarik kabeh sudhut ketergantungan kanggo mesthekake Cargo di bangun crates kasil!

Elinga yen crates ing crates.io kudu gumantung ing crate iki kanthi jeneng `core` kanggo kabeh kanggo karya bener.Kanggo nindakake iku bisa digunakake:

```toml
core = { version = "1.0.0", optional = true, package = 'rustc-std-workspace-core' }
```

Liwat panggunaan tombol `package` ing crate wis namanipun `core`, tegesipun bakal katon kaya

```
--extern core=.../librustc_std_workspace_core-XXXXXXX.rlib
```

nalika Cargo njejaluk compiler sing, muasake iso dilacak `extern crate core` arahan nyuntikaken dening compiler ing.




