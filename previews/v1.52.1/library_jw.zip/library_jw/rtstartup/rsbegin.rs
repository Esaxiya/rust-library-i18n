// rsbegin.o lan rsend.o sing supaya disebut "compiler runtime startup objects".
// Dheweke ngemot kode sing dibutuhake kanggo nggawe inisialisasi runtime kompiler kanthi bener.
//
// Nalika gambar eksekusi utawa dylib wis disambung, kabeh kode pangguna lan perpustakaan sing "sandwiched" antarane loro file obyek iki, supaya kode utawa data saka rsbegin.o dadi pisanan ing bagean pamilike gambar, déné kode lan data saka rsend.o dadi gedhe-gedhe pungkasan.
// Efek iki bisa digunakake kanggo nyelehake simbol ing wiwitan utawa ing pungkasan bagean, uga kanggo masang header utawa sikil sing dibutuhake.
//
// Elinga yen titik entri modul nyata dumunung ing C durasi obyek wiwitan (biasane disebut `crtX.o`), kang banjur ngundang initialization callbacks komponen durasi liyane (kedhaftar liwat durung bagean gambar khusus liyane).
//
//
//
//
//
//

#![feature(no_core)]
#![feature(lang_items)]
#![feature(auto_traits)]
#![crate_type = "rlib"]
#![no_core]
#![allow(non_camel_case_types)]

#[lang = "sized"]
trait Sized {}
#[lang = "sync"]
auto trait Sync {}
#[lang = "copy"]
trait Copy {}
#[lang = "freeze"]
auto trait Freeze {}

#[lang = "drop_in_place"]
#[inline]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    drop_in_place(to_drop);
}

#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frames {
    #[no_mangle]
    #[link_section = ".eh_frame"]
    // Tandha diwiwiti saka pigura tumpukan info unwind bagean
    pub static __EH_FRAME_BEGIN__: [u8; 0] = [];

    // Ngisi papan kanggo nyimpen buku internal sing ora ana gandhengane.
    // Iki wis ditetepake minangka `struct object` ing $ GCC/unwind-dw2-fde.h.
    static mut OBJ: [isize; 6] = [0; 6];

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                impl ::Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    // Mbusak rutinitas registration/deregistration info.
    // Deleng dokumen libpanic_unwind.
    extern "C" {
        fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8);
        fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8);
    }

    unsafe extern "C" fn init() {
        // ndaftar info santai ing wiwitan modul
        rust_eh_register_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    unsafe extern "C" fn uninit() {
        // unregister ing mati
        rust_eh_unregister_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    // Registrasi rutin init/uninit khusus MinGW
    pub mod mingw_init {
        // MinGW kang wiwitan obyek (crt0.o/dllcrt0.o) bakal njaluk konstruktorkang global ing .ctors lan .dtors bagean ing wiwitan lan metu.
        // Ing cilik saka DLLs, iki wis rampung nalika DLL dimuat lan prosedhur.
        //
        // Linker bakal ngurutake bagean-bagean kasebut, sing njamin panelpon bali ditemokake ing pungkasan dhaptar.
        // Wiwit konstruktorkang sing mbukak supaya mbalikke, njamin sing callbacks kita sing gedhe-gedhe pisanan lan pungkasan kaleksanan.
        //
        //

        #[link_section = ".ctors.65535"] // .ctor. *: Callback inisialisasi C
        pub static P_INIT: unsafe extern "C" fn() = super::init;

        #[link_section = ".dtors.65535"] // .dtors *: . callbacks C mandap
        pub static P_UNINIT: unsafe extern "C" fn() = super::uninit;
    }
}