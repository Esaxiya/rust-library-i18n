use std::env;

fn main() {
    println!("cargo:rustc-cfg=core_arch_docs");

    // Digunakake kanggo ngomong annotations `#[assert_instr]` kita sing kabeh intrinsics simd kasedhiya kanggo nyoba codegen sing, wiwit sawetara sing gerbang konco `-Ctarget-feature=+unimplemented-simd128` ekstra sing ora duwe padha karo `#[target_feature]` sapunika.
    //
    //
    //
    println!("cargo:rerun-if-env-changed=RUSTFLAGS");
    if env::var("RUSTFLAGS")
        .unwrap_or_default()
        .contains("unimplemented-simd128")
    {
        println!("cargo:rustc-cfg=all_simd");
    }
}