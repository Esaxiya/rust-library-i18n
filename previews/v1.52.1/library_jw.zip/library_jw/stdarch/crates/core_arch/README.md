`core::arch` - perpustakaan inti intrinsics arsitektur-tartamtu Rust kang
=======

[![core_arch_crate_badge]][core_arch_crate_link] [![core_arch_docs_badge]][core_arch_docs_link]

The `core::arch` nindakake modul arsitektur-gumantung intrinsics (eg SIMD).

# Usage 

`core::arch` kasedhiya minangka bagean `libcore` lan diekspor maneh dening `libstd`.Seneng nggunakake liwat `core::arch` utawa `std::arch` saka liwat crate iki.
fitur boten stabil asring kasedhiya ing Rust nightly liwat `feature(stdsimd)`.

Nggunakake `core::arch` liwat crate iki mbutuhake nightly Rust, lan iku bisa (lan ora) break asring.Siji-sijine kasus sing kudu dipikirake nggunakake crate iki yaiku:

* yen perlu re-ngumpulake `core::arch` dhewe, contone, karo tartamtu target-fitur aktif sing ora aktif kanggo `libcore`/`libstd`.
Note: yen perlu re-ngumpulake iku kanggo target non-standar, please seneng nggunakake `xargo` lan re-kompilasi `libcore`/`libstd` minangka cocok tinimbang nggunakake crate iki.
  
* nggunakake fitur sing bisa uga ora kasedhiya malah konco boten stabil Rust fitur.Kita nyoba supaya minimal.
Yen sampeyan perlu nggunakake fitur iki, mangga mbukak masalah supaya kita bisa mbabarake wong ing nightly Rust lan bisa digunakake saka ana.

# Documentation

* [Documentation - i686][i686]
* [Documentation - x86\_64][x86_64]
* [Documentation - arm][arm]
* [Documentation - aarch64][aarch64]
* [Documentation - powerpc][powerpc]
* [Documentation - powerpc64][powerpc64]
* [How to get started][contrib]
* [How to help implement intrinsics][help-implement]

[contrib]: https://github.com/rust-lang/stdarch/blob/master/CONTRIBUTING.md
[help-implement]: https://github.com/rust-lang/stdarch/issues/40
[i686]: https://rust-lang.github.io/stdarch/i686/core_arch/
[x86_64]: https://rust-lang.github.io/stdarch/x86_64/core_arch/
[arm]: https://rust-lang.github.io/stdarch/arm/core_arch/
[aarch64]: https://rust-lang.github.io/stdarch/aarch64/core_arch/
[powerpc]: https://rust-lang.github.io/stdarch/powerpc/core_arch/
[powerpc64]: https://rust-lang.github.io/stdarch/powerpc64/core_arch/

# License

`core_arch` utamané mbagekke miturut syarat-syarat loro lisènsi MIT lan ing saandhaping Lisensi Apache (Version 2.0), karo bagian dijamin dening macem-macem BSD-kaya lisensi.

Waca LICENSE-APACHE, lan LICENSE-MIT gamblang.

# Contribution

Kajaba sampeyan kanthi tegas nyatakake, apa wae sumbangan sing sengaja diajukake kanggo dilebokake ing `core_arch`, kaya sing wis ditemtokake ing lisensi Apache-2.0, bakal dilisensi kaping pindho ing ndhuwur, tanpa syarat utawa katemtuan tambahan.


[core_arch_crate_badge]: https://img.shields.io/crates/v/core_arch.svg
[core_arch_crate_link]: https://crates.io/crates/core_arch
[core_arch_docs_badge]: https://docs.rs/core_arch/badge.svg
[core_arch_docs_link]: https://docs.rs/core_arch/












