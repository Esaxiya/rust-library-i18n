# Kontribusi kanggo pati

The `stdarch` crate luwih saka kekarepan kanggo nampa panganggo!Kaping pisanan sampeyan pengin mriksa repositori lan priksa manawa tes lulus kanggo sampeyan:

```
$ git clone https://github.com/rust-lang/stdarch
$ cd stdarch
$ TARGET="<your-target-arch>" ci/run.sh
```

Yen `<your-target-arch>` minangka target triple kaya sing digunakake `rustup`, kayata `x86_x64-unknown-linux-gnu` (tanpa `nightly-` sadurunge utawa padha).
Uga eling yen repositori iki mbutuhake saluran Rust saben wengi!
Tes ing ndhuwur nyatane mbutuhake rust ing wayah wengi dadi standar ing sistem sampeyan, kanggo nyetel panggunaan `rustup default nightly` (lan `rustup default stable` kanggo mbalekake).

Yen salah sawijining langkah ing ndhuwur ora bisa digunakake, [please let us know][new]!

Sabanjure munggah sampeyan bisa [find an issue][issues] kanggo metu ing, kita wis milih sawetara karo [`help wanted`][help] lan [`impl-period`][impl] tags kang utamané bisa nggunakake sawetara bantuan. 
Sampeyan bisa uga paling interested in [#40][vendor], penerapan kabeh intrinsics vendor ing x86.Sing masalah kang tak sawetara penunjuk apik babagan ngendi kanggo miwiti!

Yen sampeyan wis tak pitakonan general aran gratis kanggo [join us on gitter][gitter] lan takon watara!Bebas bae kanggo ping salah siji@BurntSushi utawa@alexcrichton karo pitakonan.

[gitter]: https://gitter.im/rust-impl-period/WG-libs-simd

# Cara nulis conto kanggo intrinsik pati

Ana sawetara fitur sing kudu aktif kanggo kasirat diwenehi kanggo karya mlaku lan umpamane kudu mung bisa mbukak dening `cargo test --doc` nalika fitur iki didhukung dening CPU.

Akibaté, gawan `fn main` sing déning `rustdoc` ora bisa (ing paling kasus).
Nganggo iki minangka panuntun kanggo mesthekake conto karya kaya samesthine.

```rust
/// # // Kita butuh CFg_target_feature kanggo mesthekake conto mung
/// # // mbukak dening `cargo test --doc` nalika CPU ndhukung fitur kasebut
/// # #![feature(cfg_target_feature)]
/// # // We need target_feature kanggo kasirat kanggo karya
/// # #![feature(target_feature)]
/// #
/// # // rustdoc minangka standar migunakake `extern crate stdarch`, nanging kita kudu
/// # // `#[macro_use]`
/// # # [macro_use] extern crate stdarch;
/// #
/// # // Fungsi utama sing nyata
/// # fn main() {
/// #     // Mung mbukak iki yen `<target feature>` wis didhukung
/// #     yen cfg_feature_enabled! ("<target feature>"){
/// #         // Gawe fungsi `worker` sing bakal mbukak yen fitur target
/// #         // didhukung lan priksa manawa `target_feature` diaktifake kanggo kuli sampeyan
/// #         // function
/// #         #[target_feature(enable = "<target feature>")]
/// #         aman fn worker() {
/// // Tulisen conto ing kene.intrinsics fitur tartamtu bisa kene!Go wild!
///
/// #         }
///
/// #         aman { worker(); }
/// #     }
/// # }
```

Yen sawetara saka ukara ing ndhuwur ora katon menowo, bagean [Documentation as tests] saka [Rust Book] nggambaraké ukara `rustdoc` cukup uga.
Minangka tansah, aran gratis kanggo [join us on gitter][gitter] lan takon kita yen sampeyan mencet snags sembarang, lan matur nuwun kanggo ngewangi kanggo nambah dokumentasi `stdarch`!

# Pandhuan Tes Alternatif

Bab iki wektu iki dianjurake sing nggunakake `ci/run.sh` kanggo mbukak tes.
Nanging iki bisa uga ora bisa kanggo sampeyan, contone, yen sampeyan ana ing Windows.

Ing cilik sing bisa tiba maneh kanggo mlaku `cargo +nightly test` lan `cargo +nightly test --release -p core_arch` kanggo Testing generasi kode.
Wigati sing iki mbutuhake toolchain nightly diinstal lan kanggo `rustc` ngerti bab target telung lan CPU sawijining.
Ing tartamtu sampeyan kudu ngeset global lingkungan `TARGET` sing ngatur kanggo `ci/run.sh`.
Saliyane sampeyan kudu ngeset `RUSTCFLAGS` (perlu `C`) kanggo nunjukaké fitur target, eg `RUSTCFLAGS="-C -target-features=+avx2"`.
Sampeyan uga bisa nyetel `-C -target-cpu=native` yen sampeyan lagi "just" ngembangaken marang CPU saiki.

Dielingake yen nggunakake instruksi alternatif iki, [things may go less smoothly than they would with `ci/run.sh`][ci-run-good], kayata
tes generasi instruksi bisa uga gagal amarga disassembler menehi jeneng beda, kayata
bisa ngasilake `vaesenc` tinimbang pandhuan `aesenc` sanajan prilaku padha.
Uga instruksi nglakokaké tes kurang saka kang biasane bakal rampung, supaya ora kaget yen sampeyan pungkasanipun narik-nyuwun sawetara kasalahan bisa nuduhake kanggo tes ora dijamin kene.

[new]: https://github.com/rust-lang/stdarch/issues/new
[issues]: https://github.com/rust-lang/stdarch/issues
[help]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3A%22help+wanted%22
[impl]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3Aimpl-period
[vendor]: https://github.com/rust-lang/stdarch/issues/40
[Documentation as tests]: https://doc.rust-lang.org/book/first-edition/documentation.html#documentation-as-tests
[Rust Book]: https://doc.rust-lang.org/book/first-edition
[ci-run-good]: https://github.com/rust-lang/stdarch/issues/931#issuecomment-711412126






