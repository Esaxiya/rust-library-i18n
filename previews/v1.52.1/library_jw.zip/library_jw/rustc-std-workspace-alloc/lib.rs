#![feature(no_core)]
#![no_core]

// Deleng rustc-std-workspace-core ngapa dibutuhake crate iki.

// Ganti jeneng crate supaya bertentangan karo modul alloc ing liballoc.
extern crate alloc as foo;

pub use foo::*;