//! A perpustakaan support kanggo penulis gedhe nalika mesthi macro anyar.
//!
//! Pustaka iki, disedhiyakake dening distribusi standar, nyedhiyakake jinis-jinis sing dikonsumsi ing antarmuka definisi makro sing ditetepake kanthi prosedur kayata makro `#[proc_macro]` kaya fungsi, atribut makro `#[proc_macro_attribute]` lan atribut turunan khusus`#[proc_macro_derive]`.
//!
//!
//! Deleng [the book] kanggo liyane.
//!
//! [the book]: ../book/ch19-06-macros.html#procedural-macros-for-generating-code-from-attributes
//!
//!

#![stable(feature = "proc_macro_lib", since = "1.15.0")]
#![deny(missing_docs)]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    html_playground_url = "https://play.rust-lang.org/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/",
    test(no_crate_inject, attr(deny(warnings))),
    test(attr(allow(dead_code, deprecated, unused_variables, unused_mut)))
)]
#![feature(rustc_allow_const_fn_unstable)]
#![feature(nll)]
#![feature(staged_api)]
#![feature(const_fn)]
#![feature(const_fn_fn_ptr_basics)]
#![feature(allow_internal_unstable)]
#![feature(decl_macro)]
#![feature(extern_types)]
#![feature(in_band_lifetimes)]
#![feature(negative_impls)]
#![feature(auto_traits)]
#![feature(restricted_std)]
#![feature(rustc_attrs)]
#![feature(min_specialization)]
#![recursion_limit = "256"]

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
pub mod bridge;

mod diagnostic;

#[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
pub use diagnostic::{Diagnostic, Level, MultiSpan};

use std::cmp::Ordering;
use std::ops::{Bound, RangeBounds};
use std::path::PathBuf;
use std::str::FromStr;
use std::{error, fmt, iter, mem};

/// Nemtokake apa proc_macro wis digawe diakses kanggo program kang lagi mlaku.
///
/// The proc_macro crate mung dimaksudaké kanggo nggunakake nang implementasine saka macro prosedural.Kabeh fungsi ing crate panic iki yen kasebut saka njaba saka gedhe prosedural, kayata saka script mbangun utawa test unit utawa binar Rust biasa.
///
/// Kanthi wawasan kanggo perpustakaan Rust sing dirancang kanggo ndhukung loro gedhe lan kasus panggunaan non-gedhe, `proc_macro::is_available()` menehi cara non-panicking kanggo ndeteksi apa fasilitas sing nggunakake API saka proc_macro punika sapunika kasedhiya.
/// Ngasilake kanthi bener yen dijaluk saka makro prosedur, salah yen njaluk saka binar liyane.
///
///
///
///
///
///
///
#[unstable(feature = "proc_macro_is_available", issue = "71436")]
pub fn is_available() -> bool {
    bridge::Bridge::is_available()
}

/// Jinis utama sing diwenehake dening crate iki, nuduhake stream abstrak saka tokens, utawa, luwih khusus, urutan wit token.
/// Jinis nyedhiyani antar muka kanggo mbaleni liwat sing wit token lan, Kosok baline, ngempalaken sawetara wit token dadi siji stream.
///
///
/// Iki loro input lan output saka `#[proc_macro]`, `#[proc_macro_attribute]` lan `#[proc_macro_derive]` ukara.
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Clone)]
pub struct TokenStream(bridge::client::TokenStream);

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for TokenStream {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for TokenStream {}

/// Kesalahan bali saka `TokenStream::from_str`.
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Debug)]
pub struct LexError {
    _inner: (),
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl fmt::Display for LexError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("cannot parse string into token stream")
    }
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl error::Error for LexError {}

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for LexError {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for LexError {}

impl TokenStream {
    /// Ngasilake lan `TokenStream` kosong ora ngemot wit token.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new() -> TokenStream {
        TokenStream(bridge::client::TokenStream::new())
    }

    /// Kir yen `TokenStream` iki kosong.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn is_empty(&self) -> bool {
        self.0.is_empty()
    }
}

/// Usaha kanggo break senar menyang tokens lan njlentrehake sing tokens menyang stream token.
/// Bisa uga gagal amarga sawetara alasan, kayata, yen senar kasebut ngemot pembates utawa karakter sing ora seimbang sing ora ana ing basa kasebut.
///
/// Kabeh tokens ing stream parsed entuk rentang `Span::call_site()`.
///
/// NOTE: sawetara kasalahan bisa nimbulaké panics tinimbang bali `LexError`.Kita duwe hak ngganti kesalahan kasebut dadi `LexError` mengko.
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl FromStr for TokenStream {
    type Err = LexError;

    fn from_str(src: &str) -> Result<TokenStream, LexError> {
        Ok(TokenStream(bridge::client::TokenStream::from_str(src)))
    }
}

// NB, jembatan mung menehi `to_string`, ngleksanakake `fmt::Display` adhedhasar iku (mbalikke saka hubungan biasanipun antarane loro).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenStream {
    fn to_string(&self) -> String {
        self.0.to_string()
    }
}

/// Prints stream token minangka senar sing wis mestine dadi losslessly konversi bali menyang stream token padha (kedaden Modulo), kajaba kanggo bisa: TokenTree::Group`s karo delimiters `Delimiter::None` lan literals numerik negatif.
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Display for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// Prints token ing wangun trep kanggo debugging.
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Debug for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("TokenStream ")?;
        f.debug_list().entries(self.clone()).finish()
    }
}

#[stable(feature = "proc_macro_token_stream_default", since = "1.45.0")]
impl Default for TokenStream {
    fn default() -> Self {
        TokenStream::new()
    }
}

#[unstable(feature = "proc_macro_quote", issue = "54722")]
pub use quote::{quote, quote_span};

/// Nggawe aliran token sing ngemot siji wit token.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<TokenTree> for TokenStream {
    fn from(tree: TokenTree) -> TokenStream {
        TokenStream(bridge::client::TokenStream::from_token_tree(match tree {
            TokenTree::Group(tt) => bridge::TokenTree::Group(tt.0),
            TokenTree::Punct(tt) => bridge::TokenTree::Punct(tt.0),
            TokenTree::Ident(tt) => bridge::TokenTree::Ident(tt.0),
            TokenTree::Literal(tt) => bridge::TokenTree::Literal(tt.0),
        }))
    }
}

/// Nglumpukake sawetara wit token menyang stream siji.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl iter::FromIterator<TokenTree> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenTree>>(trees: I) -> Self {
        trees.into_iter().map(TokenStream::from).collect()
    }
}

/// A "flattening" operasi ing token lepen, nglumpukake wit token saka macem-macem token lepen menyang stream siji.
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl iter::FromIterator<TokenStream> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenStream>>(streams: I) -> Self {
        let mut builder = bridge::client::TokenStreamBuilder::new();
        streams.into_iter().for_each(|stream| builder.push(stream.0));
        TokenStream(builder.build())
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenTree> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenTree>>(&mut self, trees: I) {
        self.extend(trees.into_iter().map(TokenStream::from));
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenStream> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenStream>>(&mut self, streams: I) {
        // FIXME(eddyb) Gunakake implementasi if/when sing dioptimalake kanthi bisa.
        *self = iter::once(mem::replace(self, Self::new())).chain(streams).collect();
    }
}

/// Rincian implementasi umum kanggo jinis `TokenStream`, kayata iterator.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub mod token_stream {
    use crate::{bridge, Group, Ident, Literal, Punct, TokenStream, TokenTree};

    /// Pengulangan liwat `TokenTree`s`TokenStream`.
    /// pengulangan punika "shallow", contone, ing iterator ora recurse menyang kelompok delimited, lan ngasilake kabèh kelompok minangka wit token.
    ///
    #[derive(Clone)]
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub struct IntoIter(bridge::client::TokenStreamIter);

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl Iterator for IntoIter {
        type Item = TokenTree;

        fn next(&mut self) -> Option<TokenTree> {
            self.0.next().map(|tree| match tree {
                bridge::TokenTree::Group(tt) => TokenTree::Group(Group(tt)),
                bridge::TokenTree::Punct(tt) => TokenTree::Punct(Punct(tt)),
                bridge::TokenTree::Ident(tt) => TokenTree::Ident(Ident(tt)),
                bridge::TokenTree::Literal(tt) => TokenTree::Literal(Literal(tt)),
            })
        }
    }

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl IntoIterator for TokenStream {
        type Item = TokenTree;
        type IntoIter = IntoIter;

        fn into_iter(self) -> IntoIter {
            IntoIter(self.0.into_iter())
        }
    }
}

/// `quote!(..)` nampa kasepakatan tokens lan ngembang menyang `TokenStream` njlentrehke input.
/// Contone, `quote!(a + b)` bakal gawé expression, sing, nalika mandhiri, mbangun ing `TokenStream` `[Ident("a"), Punct('+', Alone), Ident("b")]`.
///
///
/// Unquoting wis rampung karo `$`, lan dianggo dening njupuk ident sabanjuré siji minangka istilah unquoted.
/// Kanggo ngutip `$` dhewe, gunakake `$$`.
#[unstable(feature = "proc_macro_quote", issue = "54722")]
#[allow_internal_unstable(proc_macro_def_site)]
#[rustc_builtin_macro]
pub macro quote($($t:tt)*) {
    /* compiler built-in */
}

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
mod quote;

/// A wilayah sumber kode, bebarengan karo katrangan expansion gedhe.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Copy, Clone)]
pub struct Span(bridge::client::Span);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Span {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Span {}

macro_rules! diagnostic_method {
    ($name:ident, $level:expr) => {
        /// Nggawe `Diagnostic` anyar kanthi `message` tartamtu ing span `self`.
        ///
        #[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
        pub fn $name<T: Into<String>>(self, message: T) -> Diagnostic {
            Diagnostic::spanned(self, $level, message)
        }
    };
}

impl Span {
    /// A span sing ilang sawise ing situs definisi gedhe.
    #[unstable(feature = "proc_macro_def_site", issue = "54724")]
    pub fn def_site() -> Span {
        Span(bridge::client::Span::def_site())
    }

    /// Span saka Wingi saka gedhe prosedural saiki.
    /// Identifier sing digawe kanthi rentang iki bakal bisa diatasi kaya yen ditulis langsung ing lokasi panggilan makro (kebersihan situs panggilan) lan kode liyane ing situs panggilan makro uga bakal bisa ngrujuk.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn call_site() -> Span {
        Span(bridge::client::Span::call_site())
    }

    /// A span sing nggantosi `macro_rules` kesehatan, lan kadhangkala ilang sawise ing situs gedhe definisi (kemungkinan lokal, labels, `$crate`) lan kadhangkala ing situs telpon gedhe (kabeh liya).
    ///
    /// Lokasi span dijupuk saka telpon-situs.
    ///
    #[stable(feature = "proc_macro_mixed_site", since = "1.45.0")]
    pub fn mixed_site() -> Span {
        Span(bridge::client::Span::mixed_site())
    }

    /// File sumber asli sing dikatutake.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_file(&self) -> SourceFile {
        SourceFile(self.0.source_file())
    }

    /// `Span` kanggo tokens ing ekspansi makro sadurunge sing digawe `self`, yen ana.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn parent(&self) -> Option<Span> {
        self.0.parent().map(Span)
    }

    /// Jangka kode sumber asal sing digawe `self`.
    /// Yen `Span` iki ora digawe saka ekspansi makro liyane, mula regane bali padha karo `*self`.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source(&self) -> Span {
        Span(self.0.source())
    }

    /// Nemu line/column miwiti ing file sumberé Wikipedia iki.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn start(&self) -> LineColumn {
        self.0.start()
    }

    /// Bakal pungkasan line/column ing file sumberé Wikipedia iki.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn end(&self) -> LineColumn {
        self.0.end()
    }

    /// Nggawe span anyar nyakup `self` lan `other`.
    ///
    /// Ngasilake `None` yen `self` lan `other` saka macem-macem file.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn join(&self, other: Span) -> Option<Span> {
        self.0.join(other.0).map(Span)
    }

    /// Nggawe span anyar karo informasi line/column padha `self` nanging sing ilang sawise simbol minangka sanadyan iku padha ing `other`.
    ///
    #[stable(feature = "proc_macro_span_resolved_at", since = "1.45.0")]
    pub fn resolved_at(&self, other: Span) -> Span {
        Span(self.0.resolved_at(other.0))
    }

    /// Nggawe span anyar karo prilaku résolusi jeneng padha `self` nanging karo informasi line/column saka `other`.
    ///
    #[stable(feature = "proc_macro_span_located_at", since = "1.45.0")]
    pub fn located_at(&self, other: Span) -> Span {
        other.resolved_at(*self)
    }

    /// Bandingke kedaden kanggo ndeleng yen lagi padha.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn eq(&self, other: &Span) -> bool {
        self.0 == other.0
    }

    /// Ngasilake teks sumber ing bunderan.
    /// Iki ngreksa kode sumber asli, kalebu spasi lan komentar.
    /// Iku mung ngasilake kasil span cocok kanggo kode sumber nyata.
    ///
    /// Note: Asil makro sing bisa diamati mung kudu gumantung ing tokens lan ora ing teks sumber iki.
    ///
    /// Asil saka fungsi iki minangka upaya paling apik kanggo digunakake kanggo diagnosis wae.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_text(&self) -> Option<String> {
        self.0.source_text()
    }

    diagnostic_method!(error, Level::Error);
    diagnostic_method!(warning, Level::Warning);
    diagnostic_method!(note, Level::Note);
    diagnostic_method!(help, Level::Help);
}

/// Nyithak span ing formulir sing cocog kanggo debugging.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Span {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// Pasangan kolom kolom sing nuduhake wiwitan utawa pungkasan `Span`.
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct LineColumn {
    /// 1-indeks line ing file sumber kang span diwiwiti utawa ends (inclusive).
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub line: usize,
    /// 0-indeks kolom (ing karakter UTF-8) ing file sumber kang span diwiwiti utawa ends (inclusive).
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub column: usize,
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Send for LineColumn {}
#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Sync for LineColumn {}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Ord for LineColumn {
    fn cmp(&self, other: &Self) -> Ordering {
        self.line.cmp(&other.line).then(self.column.cmp(&other.column))
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialOrd for LineColumn {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

/// File sumber `Span` sing diwenehake.
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Clone)]
pub struct SourceFile(bridge::client::SourceFile);

impl SourceFile {
    /// Nemu dalan menyang berkas iki sumber.
    ///
    /// ### Note
    /// Yen span kode gadhah `SourceFile` iki kui dening gedhe external, gedhe iki, iki mungkin ora dalan nyata ing filesystem ing.
    /// Gunakake [`is_real`] kanggo mriksa.
    ///
    /// Uga cathetan sing malah yen `is_real` ngasilake `true`, yen `--remap-path-prefix` iki liwati ing baris printah, path diwenehi uga ora bener bener.
    ///
    ///
    /// [`is_real`]: Self::is_real
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn path(&self) -> PathBuf {
        PathBuf::from(self.0.path())
    }

    /// Ngasilake `true` yen file sumber iki file sumber nyata, lan ora déning expansion sing gedhe external kang.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn is_real(&self) -> bool {
        // Iki hack nganti kedaden intercrate sing dipun ginakaken lan kita bisa duwe file sumber nyata kanggo kedaden kui ing macro external.
        //
        // https://github.com/rust-lang/rust/pull/43604#issuecomment-333334368
        self.0.is_real()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl fmt::Debug for SourceFile {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("SourceFile")
            .field("path", &self.path())
            .field("is_real", &self.is_real())
            .finish()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialEq for SourceFile {
    fn eq(&self, other: &Self) -> bool {
        self.0.eq(&other.0)
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Eq for SourceFile {}

/// token tunggal utawa urutan token urutan sing diwatesi (contone, `[1, (), ..]`).
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub enum TokenTree {
    /// stream A token diubengi dening delimiters krenjang.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Group(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Group),
    /// Pengenal
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Ident(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Ident),
    /// Paraga tandha wacan tunggal (`+`, `,`, `$`, lsp).
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Punct(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Punct),
    /// Karakter literal (`'a'`), senar (`"hello"`), nomer (`2.3`), lsp.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Literal(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Literal),
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for TokenTree {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for TokenTree {}

impl TokenTree {
    /// Ngasilake rentang wit iki, delegasi menyang metode `span` saka token utawa stream sing diwatesi.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        match *self {
            TokenTree::Group(ref t) => t.span(),
            TokenTree::Ident(ref t) => t.span(),
            TokenTree::Punct(ref t) => t.span(),
            TokenTree::Literal(ref t) => t.span(),
        }
    }

    /// Configures span kanggo *mung token* iki.
    ///
    /// Elinga yen yen token iki minangka `Group`, metode iki ora bakal ngonfigurasi rentang saben tokens internal, iki bakal dilebokake menyang metode `set_span` saben varian.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        match *self {
            TokenTree::Group(ref mut t) => t.set_span(span),
            TokenTree::Ident(ref mut t) => t.set_span(span),
            TokenTree::Punct(ref mut t) => t.set_span(span),
            TokenTree::Literal(ref mut t) => t.set_span(span),
        }
    }
}

/// Nyithak wit token ing bentuk sing cocog kanggo debugging.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Saben iki nduweni jeneng ing jinis struct ing debug asalé, supaya ora keganggu karo lapisan ekstra indirection
        //
        match *self {
            TokenTree::Group(ref tt) => tt.fmt(f),
            TokenTree::Ident(ref tt) => tt.fmt(f),
            TokenTree::Punct(ref tt) => tt.fmt(f),
            TokenTree::Literal(ref tt) => tt.fmt(f),
        }
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Group> for TokenTree {
    fn from(g: Group) -> TokenTree {
        TokenTree::Group(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Ident> for TokenTree {
    fn from(g: Ident) -> TokenTree {
        TokenTree::Ident(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Punct> for TokenTree {
    fn from(g: Punct) -> TokenTree {
        TokenTree::Punct(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Literal> for TokenTree {
    fn from(g: Literal) -> TokenTree {
        TokenTree::Literal(g)
    }
}

// NB, jembatan mung menehi `to_string`, ngleksanakake `fmt::Display` adhedhasar iku (mbalikke saka hubungan biasanipun antarane loro).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenTree {
    fn to_string(&self) -> String {
        match *self {
            TokenTree::Group(ref t) => t.to_string(),
            TokenTree::Ident(ref t) => t.to_string(),
            TokenTree::Punct(ref t) => t.to_string(),
            TokenTree::Literal(ref t) => t.to_string(),
        }
    }
}

/// Prints wit token minangka senar sing wis mestine dadi losslessly konversi bali menyang token wit padha (kedaden Modulo), kajaba kanggo bisa: TokenTree::Group`s karo delimiters `Delimiter::None` lan literals numerik negatif.
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// Aliran token sing diwatesi.
///
/// A `Group` njero ngandhut `TokenStream` kang diubengi dening: Delimiter`s.
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Group(bridge::client::Group);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Group {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Group {}

/// Kepripun urutan wit token wis delimited.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Delimiter {
    /// `( ... )`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Parenthesis,
    /// `{ ... }`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Brace,
    /// `[ ... ]`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Bracket,
    /// `Ø ... Ø`
    /// Lan delimiter iso dilacak, sing bisa, contone, katon watara tokens teka saka "macro variable" `$var`.
    /// Penting kanggo njaga prioritas operator ing kasus kaya `$var * 3` lan `$var` yaiku `1 + 2`.
    /// delimiters iso dilacak bisa ora tahan roundtrip saka stream token liwat senar.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    None,
}

impl Group {
    /// Nggawe `Group` anyar kanthi delimiter lan stream token sing diwenehake.
    ///
    /// konstruktor iki bakal nyetel span kanggo klompok iki kanggo `Span::call_site()`.
    /// Kanggo ngganti span sampeyan bisa nggunakake cara `set_span` ngisor.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(delimiter: Delimiter, stream: TokenStream) -> Group {
        Group(bridge::client::Group::new(delimiter, stream.0))
    }

    /// Ngasilake pembatas `Group` iki
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn delimiter(&self) -> Delimiter {
        self.0.delimiter()
    }

    /// Ngasilake `TokenStream` tokens sing diwatesi ing `Group` iki.
    ///
    /// Elinga yen stream token sing bali ora kalebu pembates sing bali ing ndhuwur.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn stream(&self) -> TokenStream {
        TokenStream(self.0.stream())
    }

    /// Ngasilake span kanggo delimiters saka stream token iki, pepak kabeh `Group`.
    ///
    ///
    /// ```text
    /// pub fn span(&self) -> Span {
    ///            ^^^^^^^
    /// ```
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Ngasilake span pointing menyang delimiter bukaan saka grup iki.
    ///
    /// ```text
    /// pub fn span_open(&self) -> Span {
    ///                 ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_open(&self) -> Span {
        Span(self.0.span_open())
    }

    /// Ngasilake rentang sing nuduhake watesan pungkasan klompok iki.
    ///
    /// ```text
    /// pub fn span_close(&self) -> Span {
    ///                        ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_close(&self) -> Span {
        Span(self.0.span_close())
    }

    /// Configures span iki: delimiters Group` kang, nanging ora tokens internal.
    ///
    /// Cara iki bakal **ora** nyetel span kabeh tokens internal mbentang kaliyan klompok iki, nanging rodo iku mung ngeset span saka delimiter tokens ing tingkat saka `Group`.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }
}

// NB, jembatan mung menehi `to_string`, ngleksanakake `fmt::Display` adhedhasar iku (mbalikke saka hubungan biasanipun antarane loro).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Group {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Prints grup minangka senar sing arep losslessly konversi bali menyang grup sing padha (kedaden Modulo), kajaba kanggo bisa: TokenTree::Group`s karo delimiters `Delimiter::None`.
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Group")
            .field("delimiter", &self.delimiter())
            .field("stream", &self.stream())
            .field("span", &self.span())
            .finish()
    }
}

/// Lan `Punct` iku sawijining Karakter tandha wacan siji kaya `+`, `-` utawa `#`.
///
/// operator Multi-karakter kaya `+=` sing dituduhake minangka loro kedadean saka `Punct` karo macem-macem formulir saka `Spacing` bali.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub struct Punct(bridge::client::Punct);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Punct {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Punct {}

/// Apa `Punct` diterusake langsung dening `Punct` liyane utawa disusul karo token utawa ruang putih liyane.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Spacing {
    /// contone, `+` yaiku `Alone` ing `+ =`, `+ident` utawa `+()`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Alone,
    /// contone, `+` yaiku `Joint` ing `+=` utawa `'#`.
    /// Tambahan, penawaran siji `'` bisa nggabungake karo Identifikasi kanggo wangun umur `'ident`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Joint,
}

impl Punct {
    /// Nggawe `Punct` anyar saka karakter tartamtu lan let.
    /// The `ch` pitakonan kudu Karakter tandha wacan bener dileksanakake dening basa, digunakake fungsi bakal panic.
    ///
    /// `Punct` bali bakal duwe span gawan saka `Span::call_site()` kang bisa luwih diatur karo cara `set_span` ngisor.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(ch: char, spacing: Spacing) -> Punct {
        Punct(bridge::client::Punct::new(ch, spacing))
    }

    /// Ngasilake nilai karakter tandha wacan iki dadi `char`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn as_char(&self) -> char {
        self.0.as_char()
    }

    /// Ngasilake ing let saka Karakter tandha wacan iki, nuduhake apa iku langsung diteruske `Punct` liyane ing stream token, supaya padha bisa duweni potensi bakal digabungake menyang operator multi-karakter (`Joint`), utawa iku ngiring dening sawetara token utawa whitespace (`Alone`) supaya operator wis mesthi rampung.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn spacing(&self) -> Spacing {
        self.0.spacing()
    }

    /// Ngasilake rentang wektu kanggo karakter tandha wacan iki.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Konfigurasi rentang kanggo karakter tandha wacan iki.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// NB, jembatan mung menehi `to_string`, ngleksanakake `fmt::Display` adhedhasar iku (mbalikke saka hubungan biasanipun antarane loro).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Punct {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Prints ing Karakter tandha wacan minangka senar sing arep losslessly konversi bali menyang karakter padha.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Punct")
            .field("ch", &self.as_char())
            .field("spacing", &self.spacing())
            .field("span", &self.span())
            .finish()
    }
}

#[stable(feature = "proc_macro_punct_eq", since = "1.50.0")]
impl PartialEq<char> for Punct {
    fn eq(&self, rhs: &char) -> bool {
        self.as_char() == *rhs
    }
}

#[stable(feature = "proc_macro_punct_eq_flipped", since = "1.52.0")]
impl PartialEq<Punct> for char {
    fn eq(&self, rhs: &Punct) -> bool {
        *self == rhs.as_char()
    }
}

/// Lan pengenal (`ident`).
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Ident(bridge::client::Ident);

impl Ident {
    /// Nggawe `Ident` anyar kanthi `string` sing diwenehake uga `span` sing ditemtokake.
    /// The `string` pitakonan kudu pengenal bener dileksanakake dening basa (kalebu tembung kunci, contone `self` utawa `fn`).Yen ora, fungsi bakal panic.
    ///
    /// Elinga yen `span`, saiki ing rustc, configures informasi kesehatan kanggo pengenal iki.
    ///
    /// Ing wektu iki `Span::call_site()` tegas opts-in kanggo "call-site" kesehatan makna sing Identifikasi digawe karo span iki bakal sampun mantun kaya padha ditulis langsung ing lokasi telpon gedhe, lan kode liyane ing situs telpon gedhe bakal bisa kanggo deleng dheweke uga.
    ///
    ///
    /// Mengko kedaden kaya `Span::def_site()` bakal ngidini kanggo kanggo "definition-site" kesehatan tegesé Identifikasi digawe karo span iki bakal sampun mantun ing lokasi definisi gedhe lan kode liyane ing situs telpon gedhe ora bakal bisa kanggo deleng wong-wong mau milih ing.
    ///
    /// Amarga pentinge kebersihan saiki, konstruktor iki, ora kaya tokens liyane, mbutuhake `Span` sing bakal ditemtokake ing konstruksi.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, false))
    }

    /// Padha karo `Ident::new`, nanging nggawe pengenal mentah (`r#ident`).
    /// The `string` pitakonan dadi pengenal bener dileksanakake dening basa (kalebu tembung kunci, contone `fn`).
    /// Tembung kunci sing bisa digunakake ing bagean dalan (contone
    /// `self`, : Super`) ora didhukung, lan bakal nimbulaké panic.
    #[stable(feature = "proc_macro_raw_ident", since = "1.47.0")]
    pub fn new_raw(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, true))
    }

    /// Ngasilake jengkal `Ident` iki, nyakup kabeh senar bali dening [`to_string`](Self::to_string).
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Configures jengkal `Ident` iki, bisa ganti context kesehatan sawijining.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// NB, jembatan mung menehi `to_string`, ngleksanakake `fmt::Display` adhedhasar iku (mbalikke saka hubungan biasanipun antarane loro).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Ident {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Nyithak pengenal minangka senar sing kudu bisa rugi diowahi dadi pengenal sing padha.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Ident")
            .field("ident", &self.to_string())
            .field("span", &self.span())
            .finish()
    }
}

/// A senar harfiah (`"hello"`), bait senar (`b"hello"`), karakter (`'a'`), karakter bait (`b'a'`), lan ongko utawa nomer ngambang titik karo utawa tanpa seselan (: 1`, `1u8`, `2.3`, `2.3f32`).
///
/// literals Boolean kaya `true` lan `false` ora ana nang kene, lagi: Ident`s.
///
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Literal(bridge::client::Literal);

macro_rules! suffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// Nggawe anyar suffixed ongko harfiah karo nilai kasebut.
        ///
        /// Fungsi iki bakal nggawe ongko kaya `1u32` endi Nilai ongko kasebut iku pérangan pisanan saka token lan integral uga suffixed ing mburi.
        /// Literals digawe saka nomer negatif bisa ora tahan babak-lelungan liwat `TokenStream` utawa strings lan uga bejat dadi loro tokens (`-` lan harfiah positif).
        ///
        ///
        /// Literal sing digawe liwat metode iki duwe rentang `Span::call_site()` kanthi standar, sing bisa diatur karo metode `set_span` ing ngisor iki.
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::typed_integer(&n.to_string(), stringify!($kind)))
        }
    )*)
}

macro_rules! unsuffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// Nggawe literal integer tanpa angka anyar kanthi nilai sing ditemtokake.
        ///
        /// Fungsi iki bakal nggawe ongko kaya `1` endi Nilai ongko kasebut iku pérangan pisanan saka token.
        /// Ora seselan kasebut ing token iki, tegesé invocations kaya `Literal::i8_unsuffixed(1)` sing padha karo kanggo `Literal::u32_unsuffixed(1)`.
        /// Literals digawe saka nomer negatif bisa ora tahan rountrips liwat `TokenStream` utawa strings lan uga bejat dadi loro tokens (`-` lan harfiah positif).
        ///
        ///
        /// Literal sing digawe liwat metode iki duwe rentang `Span::call_site()` kanthi standar, sing bisa diatur karo metode `set_span` ing ngisor iki.
        ///
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::integer(&n.to_string()))
        }
    )*)
}

impl Literal {
    suffixed_int_literals! {
        u8_suffixed => u8,
        u16_suffixed => u16,
        u32_suffixed => u32,
        u64_suffixed => u64,
        u128_suffixed => u128,
        usize_suffixed => usize,
        i8_suffixed => i8,
        i16_suffixed => i16,
        i32_suffixed => i32,
        i64_suffixed => i64,
        i128_suffixed => i128,
        isize_suffixed => isize,
    }

    unsuffixed_int_literals! {
        u8_unsuffixed => u8,
        u16_unsuffixed => u16,
        u32_unsuffixed => u32,
        u64_unsuffixed => u64,
        u128_unsuffixed => u128,
        usize_unsuffixed => usize,
        i8_unsuffixed => i8,
        i16_unsuffixed => i16,
        i32_unsuffixed => i32,
        i64_unsuffixed => i64,
        i128_unsuffixed => i128,
        isize_unsuffixed => isize,
    }

    /// Nggawe unsuffixed ngambang-titik harfiah anyar.
    ///
    /// Konstruktor iki padha karo kaya `Literal::i8_unsuffixed`, yen nilai float dipancarkan langsung menyang token, nanging ora ana akhiran sing digunakake, mula bisa diarani `f64` mengko ing kompiler.
    ///
    /// Literals digawe saka nomer negatif bisa ora tahan rountrips liwat `TokenStream` utawa strings lan uga bejat dadi loro tokens (`-` lan harfiah positif).
    ///
    /// # Panics
    ///
    /// Fungsi iki mbutuhake float sing ditemtokake wis winates, contone yen tanpa wates utawa NaN, fungsi iki bakal panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_unsuffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// Nggawe suffixed ngambang-titik harfiah anyar.
    ///
    /// Konstruktor iki bakal nggawe literal kaya `1.0f32` ing endi nilai sing ditemtokake minangka bagean sadurunge token lan `f32` minangka akhiran token.
    /// token iki bakal mesthi disimpulake dadi `f32` ing kompiler.
    /// Literals digawe saka nomer negatif bisa ora tahan rountrips liwat `TokenStream` utawa strings lan uga bejat dadi loro tokens (`-` lan harfiah positif).
    ///
    ///
    /// # Panics
    ///
    /// Fungsi iki mbutuhake float sing ditemtokake wis winates, contone yen tanpa wates utawa NaN, fungsi iki bakal panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_suffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f32(&n.to_string()))
    }

    /// Nggawe unsuffixed ngambang-titik harfiah anyar.
    ///
    /// Konstruktor iki padha karo kaya `Literal::i8_unsuffixed`, yen nilai float dipancarkan langsung menyang token, nanging ora ana akhiran sing digunakake, mula bisa diarani `f64` mengko ing kompiler.
    ///
    /// Literals digawe saka nomer negatif bisa ora tahan rountrips liwat `TokenStream` utawa strings lan uga bejat dadi loro tokens (`-` lan harfiah positif).
    ///
    /// # Panics
    ///
    /// Fungsi iki mbutuhake float sing ditemtokake wis winates, contone yen tanpa wates utawa NaN, fungsi iki bakal panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_unsuffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// Nggawe suffixed ngambang-titik harfiah anyar.
    ///
    /// konstruktor iki bakal nggawe harfiah kaya `1.0f64` ngendi nilai kasebut iku bagéan sadurungé saka token lan `f64` punika pungkasan saka token.
    /// token iki bakal mesthi disimpulake dadi `f64` ing kompiler.
    /// Literals digawe saka nomer negatif bisa ora tahan rountrips liwat `TokenStream` utawa strings lan uga bejat dadi loro tokens (`-` lan harfiah positif).
    ///
    ///
    /// # Panics
    ///
    /// Fungsi iki mbutuhake float sing ditemtokake wis winates, contone yen tanpa wates utawa NaN, fungsi iki bakal panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_suffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f64(&n.to_string()))
    }

    /// String harfiah.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn string(string: &str) -> Literal {
        Literal(bridge::client::Literal::string(string))
    }

    /// Karakter harfiah.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn character(ch: char) -> Literal {
        Literal(bridge::client::Literal::character(ch))
    }

    /// Byte senar literal.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn byte_string(bytes: &[u8]) -> Literal {
        Literal(bridge::client::Literal::byte_string(bytes))
    }

    /// Ngasilake rentang sing kalebu harfiah iki.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Ngatur rentang sing ana gandhengane karo literal iki.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }

    /// Ngasilake `Span` iku seng luwih gedhe saka `self.span()` ngemot mung sumber bita ing sawetara `range`.
    /// Ngasilake `None` yen spaneng sing bakal dipotong ana ing sanjabane wates `self`.
    ///
    // FIXME(SergioBenitez): mriksa sing sawetara bait wiwit lan ends ing bates UTF-8 sumber.
    // yen ora, kemungkinan panic bakal kedadeyan ing panggon liya nalika teks sumber dicithak.
    // FIXME(SergioBenitez): ora ana cara kanggo pangguna ngerti apa sejatine peta `self.span()`, mula metode iki saiki mung bisa diarani wuta.
    // Contone, `to_string()` kanggo karakter 'c' ngasilake "'\u{63}'";ora ana cara kanggo pangguna kanggo ngerti apa tèks sumberé ana 'c' utawa apa iku '\u{63}'.
    //
    //
    //
    //
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn subspan<R: RangeBounds<usize>>(&self, range: R) -> Option<Span> {
        // HACK(eddyb) soko mirip `Option::cloned`, nanging kanggo `Bound<&T>`.
        fn cloned_bound<T: Clone>(bound: Bound<&T>) -> Bound<T> {
            match bound {
                Bound::Included(x) => Bound::Included(x.clone()),
                Bound::Excluded(x) => Bound::Excluded(x.clone()),
                Bound::Unbounded => Bound::Unbounded,
            }
        }

        self.0.subspan(cloned_bound(range.start_bound()), cloned_bound(range.end_bound())).map(Span)
    }
}

// NB, jembatan mung menehi `to_string`, ngleksanakake `fmt::Display` adhedhasar iku (mbalikke saka hubungan biasanipun antarane loro).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Literal {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Prints ing harfiah minangka senar sing arep losslessly konversi bali menyang harfiah padha (kajaba kanggo bisa dibunderaké kanggo ngambang titik literals).
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// Akses dilacak menyang variabel lingkungan.
#[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
pub mod tracked_env {
    use std::env::{self, VarError};
    use std::ffi::OsStr;

    /// Goleki variabel lingkungan lan tambahi kanggo nggawe info katergantungan.
    /// sistem mbangun ngukum compiler bakal ngerti sing global iki diakses sak kompilasi, lan bakal bisa kanggo rerun mbangun nalika ing Nilai saka global sing diganti.
    ///
    /// Kejabi ketergantungan nelusuri fungsi iki kudu padha karo kanggo `env::var` saka perpustakaan standar, kajaba sing pitakonan kudu UTF-8.
    ///
    #[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
    pub fn var<K: AsRef<OsStr> + AsRef<str>>(key: K) -> Result<String, VarError> {
        let key: &str = key.as_ref();
        let value = env::var(key);
        crate::bridge::client::FreeFunctions::track_env_var(key, value.as_deref().ok());
        value
    }
}