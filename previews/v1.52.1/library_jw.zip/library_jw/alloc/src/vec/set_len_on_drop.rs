// Setel dawa vektor nalika nilai `SetLenOnDrop` metu saka ruang lingkup.
//
// Gagasane yaiku: Bidang dawa ing SetLenOnDrop minangka variabel lokal sing bakal dioptimalake dening pangoptimal ora alias karo toko liwat pointer data Vec.
// Iki minangka solusi kanggo masalah analisis alias #32155
//
pub(super) struct SetLenOnDrop<'a> {
    len: &'a mut usize,
    local_len: usize,
}

impl<'a> SetLenOnDrop<'a> {
    #[inline]
    pub(super) fn new(len: &'a mut usize) -> Self {
        SetLenOnDrop { local_len: *len, len }
    }

    #[inline]
    pub(super) fn increment_len(&mut self, increment: usize) {
        self.local_len += increment;
    }
}

impl Drop for SetLenOnDrop<'_> {
    #[inline]
    fn drop(&mut self) {
        *self.len = self.local_len;
    }
}