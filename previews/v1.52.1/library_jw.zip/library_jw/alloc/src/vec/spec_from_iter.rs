use core::mem::ManuallyDrop;
use core::ptr::{self};
use core::slice::{self};

use super::{IntoIter, SpecExtend, SpecFromIterNested, Vec};

/// Spesialisasi trait digunakake kanggo Vec::from_iter
///
/// ## Grafik delegasi:
///
/// ```text
/// +-------------+
/// |FromIterator |
/// +-+-----------+
///   |
///   v
/// +-+-------------------------------+  +---------------------+
/// |SpecFromIter                  +---->+SpecFromIterNested   |
/// |where I:                      |  |  |where I:             |
/// |  Iterator (default)----------+  |  |  Iterator (default) |
/// |  vec::IntoIter               |  |  |  TrustedLen         |
/// |  SourceIterMarker---fallback-+  |  |                     |
/// |  slice::Iter                    |  |                     |
/// |  Iterator<Item = &Clone>        |  +---------------------+
/// +---------------------------------+
/// ```
pub(super) trait SpecFromIter<T, I> {
    fn from_iter(iter: I) -> Self;
}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T>,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIterNested::from_iter(iterator)
    }
}

impl<T> SpecFromIter<T, IntoIter<T>> for Vec<T> {
    fn from_iter(iterator: IntoIter<T>) -> Self {
        // Kasus umum yaiku vector dadi fungsi sing langsung dikoleksi menyang vector.
        // Kita bisa nggawe sirkuit iki yen IntoIter durung maju babar pisan.
        // Yen wis maju Kita uga bisa nggunakake maneh memori lan mindhah data menyang ngarep.
        // Nanging kita mung nindakake nalika Vec sing diasilake ora duwe kapasitas sing luwih akeh digunakake tinimbang nggawe liwat implementasi FromIterator umum.
        //
        // Watesan kasebut ora perlu banget amarga prilaku alokasi Vec sengaja ora ditemtokake.
        // Nanging iku pilihan sing konservatif.
        //
        let has_advanced = iterator.buf.as_ptr() as *const _ != iterator.ptr;
        if !has_advanced || iterator.len() >= iterator.cap / 2 {
            unsafe {
                let it = ManuallyDrop::new(iterator);
                if has_advanced {
                    ptr::copy(it.ptr, it.buf.as_ptr(), it.len());
                }
                return Vec::from_raw_parts(it.buf.as_ptr(), it.len(), it.cap);
            }
        }

        let mut vec = Vec::new();
        // kudu utusan kanggo spec_extend() wiwit delegasi extend() dhewe kanggo spec_from kanggo Vecs P
        //
        vec.spec_extend(iterator);
        vec
    }
}

impl<'a, T: 'a, I> SpecFromIter<&'a T, I> for Vec<T>
where
    I: Iterator<Item = &'a T>,
    T: Clone,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIter::from_iter(iterator.cloned())
    }
}

// Ngompliti `iterator.as_slice().to_vec()` wiwit spec_extend kudu njupuk langkah liyane kanggo alesan bab final dawa kapasitas + lan kanthi mangkono apa liyane karya.
// `to_vec()` langsung nyedhiyakake jumlah sing bener lan ngisi persis.
//
//
impl<'a, T: 'a + Clone> SpecFromIter<&'a T, slice::Iter<'a, T>> for Vec<T> {
    #[cfg(not(test))]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        iterator.as_slice().to_vec()
    }

    // HACK(japaric): kanthi cfg(test) cara `[T]::to_vec` sing ana, sing dibutuhake kanggo definisi metode iki, ora kasedhiya.
    // Nanging gunakake fungsi `slice::to_vec` sing mung kasedhiya karo cfg(test) NB deleng modul slice::hack ing slice.rs kanggo informasi luwih lengkap
    //
    //
    #[cfg(test)]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        crate::slice::to_vec(iterator.as_slice(), crate::alloc::Global)
    }
}