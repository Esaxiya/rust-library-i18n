use core::iter::{InPlaceIterable, SourceIter};
use core::mem::{self, ManuallyDrop};
use core::ptr::{self};

use super::{AsIntoIter, InPlaceDrop, SpecFromIter, SpecFromIterNested, Vec};

/// Tandha khusus kanggo nglumpukake pipa iterator menyang Vec nalika nggunakake maneh alokasi sumber, yaiku
/// nglakokake pipa ing panggonane.
///
/// Induk SourceIter trait perlu kanggo fungsi khusus kanggo ngakses alokasi sing bakal digunakake maneh.
/// Nanging ora cukup spesialisasi kasebut bener.
/// Deleng watesan tambahan ing impl.
#[rustc_unsafe_specialization_marker]
pub(super) trait SourceIterMarker: SourceIter<Source: AsIntoIter> {}

// std-internal SourceIter/InPlaceIterable traits mung dileksanakake kanthi rantai Adaptor <Adapter<Adapter<IntoIter>>> (kabeh duweke core/std).
// Watesan tambahan kanggo implementasi adaptor (ngluwihi `impl<I: Trait> Trait for Adapter<I>`) mung gumantung ing traits liyane sing wis ditandhani minangka spesialisasi traits (Copy, TrustedRandomAccess, FusedIterator).
//
// I.e. panandha ora gumantung ing umur jinis-jinis sing disedhiyakake pangguna.Modulo bolongan Salin, sing wis gumantung karo sawetara spesialisasi liyane.
//
//
impl<T> SourceIterMarker for T where T: SourceIter<Source: AsIntoIter> + InPlaceIterable {}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T> + SourceIterMarker,
{
    default fn from_iter(mut iterator: I) -> Self {
        // Syarat tambahan sing ora bisa ditulis liwat trait bounds.Nanging, kita mung ngandelake:
        // a) ora ana ZST amarga ora bakal ana alokasi kanggo nggunakake maneh lan aritmetika pitunjuk bakal panic b) cocog ukuran kaya sing diperlokake dening kontrak Alloc c) cocog sing cocog karo kontrak Alloc
        //
        //
        //
        if mem::size_of::<T>() == 0
            || mem::size_of::<T>()
                != mem::size_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
            || mem::align_of::<T>()
                != mem::align_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
        {
            // fallback kanggo implementasine luwih umum
            return SpecFromIterNested::from_iter(iterator);
        }

        let (src_buf, src_ptr, dst_buf, dst_end, cap) = unsafe {
            let inner = iterator.as_inner().as_into_iter();
            (
                inner.buf.as_ptr(),
                inner.ptr,
                inner.buf.as_ptr() as *mut T,
                inner.end as *const T,
                inner.cap,
            )
        };

        // nggunakake nyoba-melu wiwit
        // - iku vectorize luwih apik kanggo sawetara adaptor iterator
        // - ora kaya cara pengulangan internal, mung mbutuhake &mut dhewe
        // - ngidini kita ngetrapake panunjuk nulis ing njero bathi lan mbalekake ing pungkasan
        let sink = InPlaceDrop { inner: dst_buf, dst: dst_buf };
        let sink = iterator
            .try_fold::<_, _, Result<_, !>>(sink, write_in_place_with_drop(dst_end))
            .unwrap();
        // iterasi sukses, ojo nganti gojlok
        let dst = ManuallyDrop::new(sink).dst;

        let src = unsafe { iterator.as_inner().as_into_iter() };
        // priksa manawa kontrak SourceIter tetep ana: yen ora, kita malah ora bakal tekan titik iki
        //
        debug_assert_eq!(src_buf, src.buf.as_ptr());
        // mriksa kontrak InPlaceIterable.Iki mung bisa ditindakake yen iterator nyedhiyakake pointer sumber kabeh.
        // Yen nggunakake akses sing ora dicenthang liwat TrustedRandomAccess, pointer sumber bakal tetep ing posisi dhisikan lan kita ora bisa nggunakake minangka referensi
        //
        if src.ptr != src_ptr {
            debug_assert!(
                dst as *const _ <= src.ptr,
                "InPlaceIterable contract violation, write pointer advanced beyond read pointer"
            );
        }

        // nyelehake angka sing isih ana ing buntut sumber, nanging cegah alokasi dhewe yen IntoIter metu saka ruang lingkup yen drop panics, kita uga bocor elemen sing dikoleksi menyang dst_buf
        //
        //
        src.forget_allocation_drop_remaining();

        let vec = unsafe {
            let len = dst.offset_from(dst_buf) as usize;
            Vec::from_raw_parts(dst_buf, len, cap)
        };

        vec
    }
}

fn write_in_place_with_drop<T>(
    src_end: *const T,
) -> impl FnMut(InPlaceDrop<T>, T) -> Result<InPlaceDrop<T>, !> {
    move |mut sink, item| {
        unsafe {
            // kontrak InPlaceIterable ora bisa diverifikasi kanthi tepat ing kene amarga try_fold duwe referensi eksklusif menyang pointer sumber sing bisa kita lakoni yaiku mriksa manawa isih ana ing kisaran
            //
            //
            debug_assert!(sink.dst as *const _ <= src_end, "InPlaceIterable contract violation");
            ptr::write(sink.dst, item);
            sink.dst = sink.dst.add(1);
        }
        Ok(sink)
    }
}