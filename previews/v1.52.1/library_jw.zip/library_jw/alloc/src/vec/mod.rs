//! Jinis array sing bisa tuwuh kanthi kontemporer kanthi isi sing ditawakake tumpukan, ditulis `Vec<T>`.
//!
//! Vektor duwe indeksasi `O(1)`, push `O(1)` sing diamortisasi (nganti pungkasan) lan pop `O(1)` (saka pungkasan).
//!
//!
//! Vector mesthekake ora bakal menehi luwih saka `isize::MAX` byte.
//!
//! # Examples
//!
//! Sampeyan kanthi eksplisit bisa nggawe [`Vec`] kanthi [`Vec::new`]:
//!
//! ```
//! let v: Vec<i32> = Vec::new();
//! ```
//!
//! ... utawa nggunakake makro [`vec!`]:
//!
//! ```
//! let v: Vec<i32> = vec![];
//!
//! let v = vec![1, 2, 3, 4, 5];
//!
//! let v = vec![0; 10]; // sepuluh nul
//! ```
//!
//! Sampeyan bisa [`push`] nilai ing mburi vector (sing bakal tuwuh vector yen dibutuhake):
//!
//! ```
//! let mut v = vec![1, 2];
//!
//! v.push(3);
//! ```
//!
//! Nilai Popping bisa digunakake kanthi cara sing padha:
//!
//! ```
//! let mut v = vec![1, 2];
//!
//! let two = v.pop();
//! ```
//!
//! Vector uga ndhukung indeksasi (liwat [`Index`] lan [`IndexMut`] traits):
//!
//! ```
//! let mut v = vec![1, 2, 3];
//! let three = v[2];
//! v[1] = v[1] + 5;
//! ```
//!
//! [`push`]: Vec::push
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::cmp::{self, Ordering};
use core::convert::TryFrom;
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::{arith_offset, assume};
use core::iter::FromIterator;
use core::marker::PhantomData;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::{self, Index, IndexMut, Range, RangeBounds};
use core::ptr::{self, NonNull};
use core::slice::{self, SliceIndex};

use crate::alloc::{Allocator, Global};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::collections::TryReserveError;
use crate::raw_vec::RawVec;

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
pub use self::drain_filter::DrainFilter;

mod drain_filter;

#[stable(feature = "vec_splice", since = "1.21.0")]
pub use self::splice::Splice;

mod splice;

#[stable(feature = "drain", since = "1.6.0")]
pub use self::drain::Drain;

mod drain;

mod cow;

pub(crate) use self::into_iter::AsIntoIter;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::into_iter::IntoIter;

mod into_iter;

use self::is_zero::IsZero;

mod is_zero;

mod source_iter_marker;

mod partial_eq;

use self::spec_from_elem::SpecFromElem;

mod spec_from_elem;

use self::set_len_on_drop::SetLenOnDrop;

mod set_len_on_drop;

use self::in_place_drop::InPlaceDrop;

mod in_place_drop;

use self::spec_from_iter_nested::SpecFromIterNested;

mod spec_from_iter_nested;

use self::spec_from_iter::SpecFromIter;

mod spec_from_iter;

use self::spec_extend::SpecExtend;

mod spec_extend;

/// Jinis array sing bisa tuwuh, bisa ditulis nganggo `Vec<T>` lan diucapake 'vector'.
///
/// # Examples
///
/// ```
/// let mut vec = Vec::new();
/// vec.push(1);
/// vec.push(2);
///
/// assert_eq!(vec.len(), 2);
/// assert_eq!(vec[0], 1);
///
/// assert_eq!(vec.pop(), Some(2));
/// assert_eq!(vec.len(), 1);
///
/// vec[0] = 7;
/// assert_eq!(vec[0], 7);
///
/// vec.extend([1, 2, 3].iter().copied());
///
/// for x in &vec {
///     println!("{}", x);
/// }
/// assert_eq!(vec, [7, 1, 2, 3]);
/// ```
///
/// Makro [`vec!`] diwenehake supaya inisialisasi luwih gampang:
///
/// ```
/// let mut vec = vec![1, 2, 3];
/// vec.push(4);
/// assert_eq!(vec, [1, 2, 3, 4]);
/// ```
///
/// Sampeyan uga bisa nggawe inisialisasi saben elemen `Vec<T>` kanthi nilai tartamtu.
/// Iki bisa uga luwih efisien tinimbang nindakake alokasi lan inisialisasi ing langkah sing beda, utamane nalika nggawe nol vector nol:
///
/// ```
/// let vec = vec![0; 5];
/// assert_eq!(vec, [0, 0, 0, 0, 0]);
///
/// // Ing ngisor iki padha, nanging bisa uga luwih alon:
/// let mut vec = Vec::with_capacity(5);
/// vec.resize(5, 0);
/// assert_eq!(vec, [0, 0, 0, 0, 0]);
/// ```
///
/// Kanggo informasi luwih lengkap, waca [Capacity and Reallocation](#capacity-and-reallocation).
///
/// Gunakake `Vec<T>` minangka tumpukan sing efisien:
///
/// ```
/// let mut stack = Vec::new();
///
/// stack.push(1);
/// stack.push(2);
/// stack.push(3);
///
/// while let Some(top) = stack.pop() {
///     // Cetakan 3, 2, 1
///     println!("{}", top);
/// }
/// ```
///
/// # Indexing
///
/// Jinis `Vec` ngidini ngakses angka miturut indeks, amarga ngetrapake [`Index`] trait.Contone bakal luwih jelas:
///
/// ```
/// let v = vec![0, 2, 4, 6];
/// println!("{}", v[1]); // bakal nampilake '2'
/// ```
///
/// Nanging ati-ati: yen sampeyan nyoba ngakses indeks sing ora ana ing `Vec`, piranti lunak bakal panic!Sampeyan ora bisa nindakake iki:
///
/// ```should_panic
/// let v = vec![0, 2, 4, 6];
/// println!("{}", v[6]); // it will panic!
/// ```
///
/// Gunakake [`get`] lan [`get_mut`] yen sampeyan pengin mriksa manawa indeks kasebut ana ing `Vec`.
///
/// # Slicing
///
/// `Vec` bisa diowahi.Saliyane, irisan minangka obyek sing bisa diwaca mung.
/// Kanggo entuk [slice][prim@slice], gunakake [`&`].Tuladha:
///
/// ```
/// fn read_slice(slice: &[usize]) {
///     // ...
/// }
///
/// let v = vec![0, 1];
/// read_slice(&v);
///
/// // ... lan kabeh iku!
/// // sampeyan uga bisa nindakake kaya iki:
/// let u: &[usize] = &v;
/// // utawa kaya iki:
/// let u: &[_] = &v;
/// ```
///
/// Ing Rust, luwih umum ngliwati irisan minangka argumen tinimbang vectors nalika sampeyan pengin menehi akses maca.Semono uga [`String`] lan [`&str`].
///
/// # Kapasitas lan realokasi
///
/// Kapasitas vector minangka jumlah ruang sing dialokasikan kanggo elemen future sing bakal ditambahake menyang vector.Iki ora bakal bingung karo *dawane* vector, sing nemtokake nomer unsur nyata ing vector.
/// Yen dawane vector ngluwihi kapasitas, kapasitas bakal kanthi otomatis ditambah, nanging unsur-unsur kasebut kudu dialokasikan maneh.
///
/// Contone, vector kanthi kapasitas 10 lan dawa 0 bakal dadi vector kosong kanthi papan kanggo 10 elemen liyane.Nyurung 10 elemen utawa luwih sithik ing vector ora bakal ngganti kapasitas utawa nyebabake realokasi nyata.
/// Nanging, yen dawane vector ditambah dadi 11, mula kudu nyata, sing bisa alon.Amarga alasan iki, disaranake nggunakake [`Vec::with_capacity`] yen bisa ditetepake sepira gedhene vector sing dikarepake.
///
/// # Guarantees
///
/// Amarga sifat dhasar sing luar biasa, `Vec` nggawe akeh jaminan babagan desaine.Iki mesthekake yen paling murah ing kasus umume, lan bisa dimanipulasi kanthi cara primitif kanthi kode sing ora aman.Elinga yen jaminan kasebut nuduhake `Vec<T>` sing ora kualifikasi.
/// Yen paramèter jinis tambahan ditambahake (contone, kanggo ndhukung alokasi khusus), nyalahi standar bisa uga ngganti prilaku.
///
/// Paling dhasar, `Vec` lan mesthi bakal dadi triplet (pitunjuk, kapasitas, dawa).Ora luwih, ora kurang.Urutan kolom kasebut pancen durung ditemtokake, lan sampeyan kudu nggunakake cara sing cocog kanggo ngowahi iki.
/// Pointer ora bakal nul, mula jinis iki dioptimalake kanthi nol.
///
/// Nanging, pitunjuk bisa uga ora nuduhake memori sing dialokasikan.
/// Utamane, yen sampeyan nggawe `Vec` kanthi kapasitas 0 liwat [`Vec::new`], [`vec![]`][`vec!`], [`Vec::with_capacity(0)`][`Vec::with_capacity`], utawa nelpon [`shrink_to_fit`] ing Vec kosong, ora bakal menehi memori.Kajaba, yen sampeyan nyimpen jinis ukuran nol ing `Vec`, ora bakal menehi ruang kanggo dheweke.
/// *Elinga yen ing kasus iki `Vec` bisa uga ora nglaporake [`capacity`] 0*.
/// `Vec` bakal dialokasikan yen lan mung yen [`mem: : size_of::<T>`]`() * capacity()> 0`.
/// Umumé, rincian alokasi `Vec` pancen angel banget-yen sampeyan pengin menehi memori nganggo `Vec` lan digunakake kanggo liya-liyane (kanggo pindhah menyang kode sing ora aman, utawa kanggo nggawe koleksi sing didhukung memori dhewe), aja manawa kanggo menehi hasil memori iki kanthi nggunakake `from_raw_parts` kanggo mbalekake `Vec` banjur culake.
///
/// Yen `Vec`*duwe* memori sing diparengake, mula memori sing dituju kasebut ana ing tumpukan (kaya sing ditegesake dening alokasi Rust dikonfigurasi kanggo digunakake kanthi standar), lan titik kasebut nuduhake [`len`] unsur inisialisasi, contiguous (apa sing bakal ditindakake delengen yen sampeyan meksa ngiris), diikuti karo [`kapasitas`]`,`[`len`] kanthi logis sing ora ana artine, unsur-unsur sing ana gandhengane.
///
///
/// vector ngemot unsur `'a'` lan `'b'` kanthi kapasitas 4 bisa dibayangke kaya ing ngisor iki.Sisih ndhuwur yaiku struktur `Vec`, ngemot pointer menyang kepala alokasi ing tumpukan, dawa lan kapasitas.
/// Sisih ngisor yaiku alokasi ing tumpukan, blok memori sing ana gandhengane.
///
/// ```text
///             ptr      len  capacity
///        +--------+--------+--------+
///        | 0x0123 |      2 |      4 |
///        +--------+--------+--------+
///             |
///             v
/// Heap   +--------+--------+--------+--------+
///        |    'a' |    'b' | uninit | uninit |
///        +--------+--------+--------+--------+
/// ```
///
/// - **uninit** nggambarake memori sing ora diinisialisasi, deleng [`MaybeUninit`].
/// - Note: ABI ora stabil lan `Vec` ora menehi jaminan babagan tata letak memori (kalebu urutan lapangan).
///
/// `Vec` ora bakal nate nindakake "small optimization" ing endi unsur-unsur disimpen ing tumpukan amarga rong sebab:
///
/// * Bakal luwih angel yen kode sing ora aman bisa ngapusi `Vec` kanthi bener.Isi `Vec` ora duwe alamat sing stabil yen mung dipindhah, lan bakal luwih angel kanggo nemtokake manawa `Vec` wis saestu menehi memori.
///
/// * Iki bakal ngukum kasus umum, lan nambah branch ing saben akses.
///
/// `Vec` ora bakal otomatis nyusut, sanajan kosong.Iki njamin ora ana alokasi utawa transaksi sing ora perlu.Ngilangi `Vec` banjur ngiseni nganti [`len`] sing padha, ora bakal ana panggilan menyang alokasi.Yen sampeyan pengin mbebasake memori sing ora digunakake, gunakake [`shrink_to_fit`] utawa [`shrink_to`].
///
/// [`push`] lan [`insert`] ora bakal menehi alokasi yen kapasitas sing dilaporake cukup.[`push`] lan [`insert`]*bakal*(re) dialokasikan yen [`len`]`==`[`kapasitas`].Yaiku, kapasitas sing dilaporake pancen akurat, lan bisa diandelake.Malah bisa digunakake kanggo mbebasake memori kanthi manual sing dialokasikan dening `Vec` yen dikarepake.
/// Cara nyisipake akeh *bisa uga* nyata, sanajan ora prelu.
///
/// `Vec` ora njamin strategi pertumbuhan tartamtu nalika reallocating nalika kebak, utawa nalika [`reserve`] diarani.Strategi saiki minangka dhasar lan bisa uga kabukten pengin nggunakake faktor pertumbuhan sing ora tetep.Strategi apa wae sing digunakake mesthi bakal njamin *O*(1) amortisasi [`push`].
///
/// `vec![x; n]`, `vec![a, b, c, d]`, lan [`Vec::with_capacity(n)`][`Vec::with_capacity`], kabeh bakal ngasilake `Vec` kanthi kapasitas sing dijaluk.
/// Yen [`len`]`==`[`kapasitas`], (kayadene makro [`vec!`]), mula `Vec<T>` bisa diowahi dadi lan saka [`Box<[T]>`][owned slice] tanpa reallocating utawa mindhah elemen kasebut.
///
/// `Vec` ora bakal khusus nimpa data sing dicopot, nanging uga ora bakal dilestarikan.Memori sing ora diresmine yaiku ruang gores sing bisa digunakake miturut kekarepane.Umume bakal nindakake apa wae sing paling efisien utawa gampang ditindakake.Aja ngandelake data sing dicopot kanggo mbusak kanggo tujuan keamanan.
/// Sanajan sampeyan ngeculake `Vec`, buffer bisa digunakake maneh dening `Vec` liyane.
/// Sanajan sampeyan nol dhisik memori `Vec`, bisa uga ora kedadeyan amarga pangoptimal ora nganggep iki efek samping sing kudu dijaga.
/// Nanging ana salah sawijining kasus sing ora bakal dilanggar: nggunakake kode `unsafe` kanggo nulis kanthi kapasitas sing luwih gedhe, lan banjur nambah dawa supaya bisa cocog, mesthi valid.
///
/// Saiki, `Vec` ora njamin supaya elemen bakal mudhun.
/// Pesenan wis diganti sadurunge lan bisa uga diganti maneh.
///
/// [`get`]: ../../std/vec/struct.Vec.html#method.get
/// [`get_mut`]: ../../std/vec/struct.Vec.html#method.get_mut
/// [`String`]: crate::string::String
/// [`&str`]: type@str
/// [`shrink_to_fit`]: Vec::shrink_to_fit
/// [`shrink_to`]: Vec::shrink_to
/// [`capacity`]: Vec::capacity
/// [`mem::size_of::<T>`]: core::mem::size_of
/// [`len`]: Vec::len
/// [`push`]: Vec::push
/// [`insert`]: Vec::insert
/// [`reserve`]: Vec::reserve
/// [`MaybeUninit`]: core::mem::MaybeUninit
/// [owned slice]: Box
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "vec_type")]
pub struct Vec<T, #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global> {
    buf: RawVec<T, A>,
    len: usize,
}

////////////////////////////////////////////////////////////////////////////////
// Metode sing diwarisake
////////////////////////////////////////////////////////////////////////////////

impl<T> Vec<T> {
    /// Mbangun `Vec<T>` anyar sing kosong.
    ///
    /// vector ora bakal diparengake nganti unsur ditekan.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(unused_mut)]
    /// let mut vec: Vec<i32> = Vec::new();
    /// ```
    #[inline]
    #[rustc_const_stable(feature = "const_vec_new", since = "1.39.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> Self {
        Vec { buf: RawVec::NEW, len: 0 }
    }

    /// Mbangun `Vec<T>` kosong anyar kanthi kapasitas sing ditemtokake.
    ///
    /// vector bakal bisa nyekel elemen `capacity` persis tanpa realokasi.
    /// Yen `capacity` yaiku 0, vector ora bakal dialokasikan.
    ///
    /// Penting, sampeyan kudu nyathet, sanajan vector sing bali duwe *kapasitas* sing ditemtokake, vector bakal dawane nol *.
    ///
    /// Kanggo panjelasan babagan bedane dawa lan kapasitas, deleng *[Kapasitas lan realokasi]*.
    ///
    /// [Capacity and reallocation]: #capacity-and-reallocation
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    ///
    /// // vector ora ngemot barang, sanajan kapasitase luwih akeh
    /// assert_eq!(vec.len(), 0);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // Iki kabeh rampung tanpa reallocating ...
    /// for i in 0..10 {
    ///     vec.push(i);
    /// }
    /// assert_eq!(vec.len(), 10);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // ... nanging iki bisa uga nggawe vector nyata-nyata
    /// vec.push(11);
    /// assert_eq!(vec.len(), 11);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    #[inline]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// Nggawe `Vec<T>` langsung saka komponen mentah vector liyane.
    ///
    /// # Safety
    ///
    /// Iki pancen ora aman, amarga nomer undhangan sing ora dicenthang:
    ///
    /// * `ptr` kudu sadurunge dialokasikan liwat [`String`]/`Vec<T>"(paling ora, bisa uga salah yen ora).
    /// * `T` kudu duwe ukuran lan jajaran sing padha karo `ptr` sing dialokasikan.
    ///   (`T` sing nduwe keselarasan sing kurang ketat ora cukup, keselarasan pancen kudu padha kanggo memenuhi syarat [`dealloc`] yen memori kudu dialokasikan lan ditrapake kanthi tata letak sing padha.)
    ///
    /// * `length` kudu kurang saka utawa padha karo `capacity`.
    /// * `capacity` kudu dadi kapasitas sing diwenehake pointer.
    ///
    /// Pelanggaran kasebut bisa uga nyebabake masalah kaya ngrusak struktur data internal alokasi.Contone,**ora** aman kanggo nggawe `Vec<u8>` saka pitunjuk menyang C C C02X kanthi dawa `size_t`.
    /// Sampeyan uga ora aman kanggo nggawe siji saka `Vec<u16>` lan dawa, amarga alokator peduli karo keselarasan, lan rong jinis kasebut beda-beda.
    /// Buffer diparengake kanthi alignment 2 (kanggo `u16`), nanging sawise malih dadi `Vec<u8>` mula bakal diselehake karo alignment 1.
    ///
    /// Kepemilikan `ptr` kanthi efektif ditransfer menyang `Vec<T>` sing banjur bisa menehi hasil, realokasi utawa ngganti isi memori sing dituduhake dening penunjuk miturut kekarepan.
    /// Priksa manawa ora ana sing nggunakake pointer sawise nelpon fungsi iki.
    ///
    /// [`String`]: crate::string::String
    /// [`dealloc`]: crate::alloc::GlobalAlloc::dealloc
    ///
    /// # Examples
    ///
    /// ```
    /// use std::ptr;
    /// use std::mem;
    ///
    /// let v = vec![1, 2, 3];
    ///
    ///     // FIXME Anyari iki nalika vektor_into_raw_parts wis stabil.
    ///     // Nyegah nglakokake destruktor `v` dadi kita bisa ngontrol alokasi kanthi lengkap.
    /////
    /// let mut v = mem::ManuallyDrop::new(v);
    ///
    /// // Tarik macem-macem informasi penting babagan `v`
    /// let p = v.as_mut_ptr();
    /// let len = v.len();
    /// let cap = v.capacity();
    ///
    /// unsafe {
    ///     // Nulis memori nganggo 4, 5, 6
    ///     for i in 0..len as isize {
    ///         ptr::write(p.offset(i), 4 + i);
    ///     }
    ///
    ///     // Wenehake kabeh menyang Vec
    ///     let rebuilt = Vec::from_raw_parts(p, len, cap);
    ///     assert_eq!(rebuilt, [4, 5, 6]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_raw_parts(ptr: *mut T, length: usize, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, length, capacity, Global) }
    }
}

impl<T, A: Allocator> Vec<T, A> {
    /// Mbangun `Vec<T, A>` anyar sing kosong.
    ///
    /// vector ora bakal diparengake nganti unsur ditekan.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// # #[allow(unused_mut)]
    /// let mut vec: Vec<i32, _> = Vec::new_in(System);
    /// ```
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub const fn new_in(alloc: A) -> Self {
        Vec { buf: RawVec::new_in(alloc), len: 0 }
    }

    /// Mbangun `Vec<T, A>` kosong anyar kanthi kapasitas sing ditemtokake karo alokasi sing diwenehake.
    ///
    /// vector bakal bisa nyekel elemen `capacity` persis tanpa realokasi.
    /// Yen `capacity` yaiku 0, vector ora bakal dialokasikan.
    ///
    /// Penting, sampeyan kudu nyathet, sanajan vector sing bali duwe *kapasitas* sing ditemtokake, vector bakal dawane nol *.
    ///
    /// Kanggo panjelasan babagan bedane dawa lan kapasitas, deleng *[Kapasitas lan realokasi]*.
    ///
    /// [Capacity and reallocation]: #capacity-and-reallocation
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut vec = Vec::with_capacity_in(10, System);
    ///
    /// // vector ora ngemot barang, sanajan kapasitase luwih akeh
    /// assert_eq!(vec.len(), 0);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // Iki kabeh rampung tanpa reallocating ...
    /// for i in 0..10 {
    ///     vec.push(i);
    /// }
    /// assert_eq!(vec.len(), 10);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // ... nanging iki bisa uga nggawe vector nyata-nyata
    /// vec.push(11);
    /// assert_eq!(vec.len(), 11);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Vec { buf: RawVec::with_capacity_in(capacity, alloc), len: 0 }
    }

    /// Nggawe `Vec<T, A>` langsung saka komponen mentah vector liyane.
    ///
    /// # Safety
    ///
    /// Iki pancen ora aman, amarga nomer undhangan sing ora dicenthang:
    ///
    /// * `ptr` kudu sadurunge dialokasikan liwat [`String`]/`Vec<T>"(paling ora, bisa uga salah yen ora).
    /// * `T` kudu duwe ukuran lan jajaran sing padha karo `ptr` sing dialokasikan.
    ///   (`T` sing nduwe keselarasan sing kurang ketat ora cukup, keselarasan pancen kudu padha kanggo memenuhi syarat [`dealloc`] yen memori kudu dialokasikan lan ditrapake kanthi tata letak sing padha.)
    ///
    /// * `length` kudu kurang saka utawa padha karo `capacity`.
    /// * `capacity` kudu dadi kapasitas sing diwenehake pointer.
    ///
    /// Pelanggaran kasebut bisa uga nyebabake masalah kaya ngrusak struktur data internal alokasi.Contone,**ora** aman kanggo nggawe `Vec<u8>` saka pitunjuk menyang C C C02X kanthi dawa `size_t`.
    /// Sampeyan uga ora aman kanggo nggawe siji saka `Vec<u16>` lan dawa, amarga alokator peduli karo keselarasan, lan rong jinis kasebut beda-beda.
    /// Buffer diparengake kanthi alignment 2 (kanggo `u16`), nanging sawise malih dadi `Vec<u8>` mula bakal diselehake karo alignment 1.
    ///
    /// Kepemilikan `ptr` kanthi efektif ditransfer menyang `Vec<T>` sing banjur bisa menehi hasil, realokasi utawa ngganti isi memori sing dituduhake dening penunjuk miturut kekarepan.
    /// Priksa manawa ora ana sing nggunakake pointer sawise nelpon fungsi iki.
    ///
    /// [`String`]: crate::string::String
    /// [`dealloc`]: crate::alloc::GlobalAlloc::dealloc
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// use std::ptr;
    /// use std::mem;
    ///
    /// let mut v = Vec::with_capacity_in(3, System);
    /// v.push(1);
    /// v.push(2);
    /// v.push(3);
    ///
    ///     // FIXME Anyari iki nalika vektor_into_raw_parts wis stabil.
    ///     // Nyegah nglakokake destruktor `v` dadi kita bisa ngontrol alokasi kanthi lengkap.
    /////
    /// let mut v = mem::ManuallyDrop::new(v);
    ///
    /// // Tarik macem-macem informasi penting babagan `v`
    /// let p = v.as_mut_ptr();
    /// let len = v.len();
    /// let cap = v.capacity();
    /// let alloc = v.allocator();
    ///
    /// unsafe {
    ///     // Nulis memori nganggo 4, 5, 6
    ///     for i in 0..len as isize {
    ///         ptr::write(p.offset(i), 4 + i);
    ///     }
    ///
    ///     // Wenehake kabeh menyang Vec
    ///     let rebuilt = Vec::from_raw_parts_in(p, len, cap, alloc.clone());
    ///     assert_eq!(rebuilt, [4, 5, 6]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, length: usize, capacity: usize, alloc: A) -> Self {
        unsafe { Vec { buf: RawVec::from_raw_parts_in(ptr, capacity, alloc), len: length } }
    }

    /// Ngurai `Vec<T>` dadi komponen mentah.
    ///
    /// Ngasilake pitunjuk mentah menyang data sing ndasari, dawa vector (ing unsur), lan kapasitas data sing dialokasikan (ing elemen).
    /// Iki minangka bantahan sing padha ing urutan sing padha karo bantahan menyang [`from_raw_parts`].
    ///
    /// Sawise nelpon fungsi iki, panelpon tanggung jawab kanggo memori sing sadurunge dikelola dening `Vec`.
    /// Siji-sijine cara kanggo nindakake iki yaiku ngowahi pointer, dawa, lan kapasitas mentah maneh dadi `Vec` kanthi fungsi [`from_raw_parts`], saéngga bisa ngrusak kanggo ngrampungake.
    ///
    ///
    /// [`from_raw_parts`]: Vec::from_raw_parts
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_into_raw_parts)]
    /// let v: Vec<i32> = vec![-1, 0, 1];
    ///
    /// let (ptr, len, cap) = v.into_raw_parts();
    ///
    /// let rebuilt = unsafe {
    ///     // Saiki kita bisa nggawe pangowahan komponen, kayata ngirim pointer mentah menyang jinis sing kompatibel.
    /////
    ///     let ptr = ptr as *mut u32;
    ///
    ///     Vec::from_raw_parts(ptr, len, cap)
    /// };
    /// assert_eq!(rebuilt, [4294967295, 0, 1]);
    /// ```
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts(self) -> (*mut T, usize, usize) {
        let mut me = ManuallyDrop::new(self);
        (me.as_mut_ptr(), me.len(), me.capacity())
    }

    /// Ngurai `Vec<T>` dadi komponen mentah.
    ///
    /// Ngasilake pitunjuk mentah menyang data sing ndasari, dawa vector (ing unsur), kapasitas data sing dialokasikan (ing elemen), lan alokasi.
    /// Iki bantahan sing padha ing urutan padha bantahan kanggo [`from_raw_parts_in`].
    ///
    /// Sawise nelpon fungsi iki, panelpon tanggung jawab kanggo memori sing sadurunge dikelola dening `Vec`.
    /// Siji-sijine cara kanggo nindakake iki yaiku ngowahi pointer, dawa, lan kapasitas mentah maneh dadi `Vec` kanthi fungsi [`from_raw_parts_in`], saéngga bisa ngrusak kanggo ngrampungake.
    ///
    ///
    /// [`from_raw_parts_in`]: Vec::from_raw_parts_in
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, vec_into_raw_parts)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut v: Vec<i32, System> = Vec::new_in(System);
    /// v.push(-1);
    /// v.push(0);
    /// v.push(1);
    ///
    /// let (ptr, len, cap, alloc) = v.into_raw_parts_with_alloc();
    ///
    /// let rebuilt = unsafe {
    ///     // Saiki kita bisa nggawe pangowahan komponen, kayata ngirim pointer mentah menyang jinis sing kompatibel.
    /////
    ///     let ptr = ptr as *mut u32;
    ///
    ///     Vec::from_raw_parts_in(ptr, len, cap, alloc)
    /// };
    /// assert_eq!(rebuilt, [4294967295, 0, 1]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts_with_alloc(self) -> (*mut T, usize, usize, A) {
        let mut me = ManuallyDrop::new(self);
        let len = me.len();
        let capacity = me.capacity();
        let ptr = me.as_mut_ptr();
        let alloc = unsafe { ptr::read(me.allocator()) };
        (ptr, len, capacity, alloc)
    }

    /// Ngasilake pirang-pirang elemen sing bisa dicekel vector tanpa realokasi.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let vec: Vec<i32> = Vec::with_capacity(10);
    /// assert_eq!(vec.capacity(), 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.buf.capacity()
    }

    /// Kapasitas cadangan paling ora `additional` elemen liyane sing bakal dilebokake ing `Vec<T>` tartamtu.
    /// Koleksi kasebut bisa uga duwe papan luwih akeh kanggo nyegah realokasi sing asring.
    /// Sawise nelpon `reserve`, kapasitas bakal luwih gedhe tinimbang utawa padha karo `self.len() + additional`.
    /// Apa-apa yen kapasitas wis cukup.
    ///
    /// # Panics
    ///
    /// Panics yen kapasitas anyar ngluwihi `isize::MAX` byte.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.reserve(10);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.buf.reserve(self.len, additional);
    }

    /// Cadangan kapasitas minimal kanggo elemen `additional` luwih akeh kanggo dilebokake ing `Vec<T>` sing diwenehake.
    ///
    /// Sawise nelpon `reserve_exact`, kapasitas bakal luwih gedhe tinimbang utawa padha karo `self.len() + additional`.
    /// Apa-apa yen kapasitase wis cukup.
    ///
    /// Elinga yen alokasi bisa menehi koleksi luwih akeh ruangan tinimbang sing dijaluk.
    /// Mula, kapasitas ora bisa dipercaya dadi minimalis sabenere.
    /// Luwih milih `reserve` yen disisipake future.
    ///
    /// # Panics
    ///
    /// Panics yen kapasitas anyar kebanjiran `usize`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.reserve_exact(10);
    /// assert!(vec.capacity() >= 11);
    /// ```
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.buf.reserve_exact(self.len, additional);
    }

    /// Nyoba cadangan kapasitas paling ora `additional` elemen liyane sing bakal dilebokake ing `Vec<T>` sing diwenehake.
    /// Koleksi kasebut bisa uga duwe papan luwih akeh kanggo nyegah realokasi sing asring.
    /// Sawise nelpon `try_reserve`, kapasitas bakal luwih gedhe tinimbang utawa padha karo `self.len() + additional`.
    /// Apa-apa yen kapasitas wis cukup.
    ///
    /// # Errors
    ///
    /// Yen kapasitas kebanjiran, utawa alokator nglaporake kegagalan, mula kesalahan bakal bali.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &[u32]) -> Result<Vec<u32>, TryReserveError> {
    ///     let mut output = Vec::new();
    ///
    ///     // Pre-cadangan memori, metu yen ora bisa
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Saiki kita ngerti iki ora bisa OOM ing tengah-tengah karya kompleks
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // rumit banget
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[doc(alias = "realloc")]
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.buf.try_reserve(self.len, additional)
    }

    /// Nyoba cadangan kapasitas minimal kanggo elemen `additional` persis sing bakal dilebokake ing `Vec<T>` sing diwenehake.
    /// Sawise nelpon `try_reserve_exact`, kapasitas bakal luwih gedhe tinimbang utawa padha karo `self.len() + additional` yen ngasilake `Ok(())`.
    ///
    /// Apa-apa yen kapasitase wis cukup.
    ///
    /// Elinga yen alokasi bisa menehi koleksi luwih akeh ruangan tinimbang sing dijaluk.
    /// Mula, kapasitas ora bisa dipercaya dadi minimalis sabenere.
    /// Luwih milih `reserve` yen disisipake future.
    ///
    /// # Errors
    ///
    /// Yen kapasitas kebanjiran, utawa alokator nglaporake kegagalan, mula kesalahan bakal bali.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &[u32]) -> Result<Vec<u32>, TryReserveError> {
    ///     let mut output = Vec::new();
    ///
    ///     // Pre-cadangan memori, metu yen ora bisa
    ///     output.try_reserve_exact(data.len())?;
    ///
    ///     // Saiki kita ngerti iki ora bisa OOM ing tengah-tengah karya kompleks
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // rumit banget
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[doc(alias = "realloc")]
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.buf.try_reserve_exact(self.len, additional)
    }

    /// Nyilikake kapasitas vector sabisa.
    ///
    /// Bakal mudhun nganti cedhak karo dawa, nanging alokator isih menehi informasi marang vector manawa ana papan kanggo sawetara elemen liyane.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    /// assert_eq!(vec.capacity(), 10);
    /// vec.shrink_to_fit();
    /// assert!(vec.capacity() >= 3);
    /// ```
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        // Kapasitas kasebut ora bisa kurang saka dawa, lan ora ana hubungane yen padha, mula kita bisa ngindhari kasus panic ing `RawVec::shrink_to_fit` kanthi mung nelpon kanthi kapasitas luwih gedhe.
        //
        //
        if self.capacity() > self.len {
            self.buf.shrink_to_fit(self.len);
        }
    }

    /// Nyilikake kapasitas vector kanthi wates ngisor.
    ///
    /// Kapasitas bakal tetep paling ora sepira dawa lan nilai sing diwenehake.
    ///
    ///
    /// Yen kapasitas saiki kurang saka watesan ngisor, iki ora bisa digunakake.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    /// assert_eq!(vec.capacity(), 10);
    /// vec.shrink_to(4);
    /// assert!(vec.capacity() >= 4);
    /// vec.shrink_to(0);
    /// assert!(vec.capacity() >= 3);
    /// ```
    #[doc(alias = "realloc")]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        if self.capacity() > min_capacity {
            self.buf.shrink_to_fit(cmp::max(self.len, min_capacity));
        }
    }

    /// Ngowahi vector dadi [`Box<[T]>`][owned slice].
    ///
    /// Elinga yen iki bakal ngeculake kapasitas berlebihan.
    ///
    /// [owned slice]: Box
    ///
    /// # Examples
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    ///
    /// let slice = v.into_boxed_slice();
    /// ```
    ///
    /// Sembarang kapasitas keluwihan dijupuk:
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    ///
    /// assert_eq!(vec.capacity(), 10);
    /// let slice = vec.into_boxed_slice();
    /// assert_eq!(slice.into_vec().capacity(), 3);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_boxed_slice(mut self) -> Box<[T], A> {
        unsafe {
            self.shrink_to_fit();
            let me = ManuallyDrop::new(self);
            let buf = ptr::read(&me.buf);
            let len = me.len();
            buf.into_box(len).assume_init()
        }
    }

    /// Shortens vector, tetep unsur `len` pisanan lan nyelehake sisane.
    ///
    /// Yen `len` luwih gedhe tinimbang dawa vector saiki, iki ora bakal duwe pengaruh.
    ///
    /// Metode [`drain`] bisa niru `truncate`, nanging nyebabake keluwihan elemen bisa dikembalikan tinimbang dicopot.
    ///
    ///
    /// Elinga yen cara iki ora duwe pengaruh marang kapasitas vector sing dialokasikan.
    ///
    /// # Examples
    ///
    /// Truncating limang elemen vector dadi rong elemen:
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4, 5];
    /// vec.truncate(2);
    /// assert_eq!(vec, [1, 2]);
    /// ```
    ///
    /// Ora ana truncasi nalika `len` luwih gedhe tinimbang dawa vector saiki:
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.truncate(8);
    /// assert_eq!(vec, [1, 2, 3]);
    /// ```
    ///
    /// Truncating nalika `len == 0` padha karo nelpon metode [`clear`].
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.truncate(0);
    /// assert_eq!(vec, []);
    /// ```
    ///
    /// [`clear`]: Vec::clear
    /// [`drain`]: Vec::drain
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn truncate(&mut self, len: usize) {
        // Iki aman amarga:
        //
        // * irisan sing diwenehake menyang `drop_in_place` bener;kasus `len > self.len` ngindhari nggawe irisan sing ora valid, lan
        // * `len` vector nyusut sadurunge nelpon `drop_in_place`, saengga ora ana regane bakal mudhun kaping pindho yen `drop_in_place` panic sapisan (yen panics kaping pindho, program kasebut bakal dibatalake).
        //
        //
        //
        unsafe {
            // Note: Sengaja iki `>` lan dudu `>=`.
            //       Owahi dadi `>=` duwe implikasi kinerja negatif ing sawetara kasus.
            //       Deleng #78884 kanggo liyane.
            if len > self.len {
                return;
            }
            let remaining_len = self.len - len;
            let s = ptr::slice_from_raw_parts_mut(self.as_mut_ptr().add(len), remaining_len);
            self.len = len;
            ptr::drop_in_place(s);
        }
    }

    /// Ekstrak irisan sing ngemot kabeh vector.
    ///
    /// Padha karo `&s[..]`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::io::{self, Write};
    /// let buffer = vec![1, 2, 3, 5, 8];
    /// io::sink().write(buffer.as_slice()).unwrap();
    /// ```
    #[inline]
    #[stable(feature = "vec_as_slice", since = "1.7.0")]
    pub fn as_slice(&self) -> &[T] {
        self
    }

    /// Ekstrak irisan sing bisa diowahi kanggo kabeh vector.
    ///
    /// Padha karo `&mut s[..]`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::io::{self, Read};
    /// let mut buffer = vec![0; 3];
    /// io::repeat(0b101).read_exact(buffer.as_mut_slice()).unwrap();
    /// ```
    #[inline]
    #[stable(feature = "vec_as_slice", since = "1.7.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        self
    }

    /// Ngasilake pitunjuk mentah menyang buffer vector.
    ///
    /// Panelpon kudu mesthekake yen vector luwih gedhe tinimbang pitunjuk sing ngasilake fungsi iki, yen ora bakal nuduhake sampah.
    /// Ngowahi vector bisa uga nyebabake buffer bisa dialokasikan maneh, sing uga bakal menehi petunjuk yen ora valid.
    ///
    /// Panelpon uga kudu mesthekake yen memori sing diwenehi pointer (non-transitively) ora nate ditulis (kajaba ing `UnsafeCell`) nggunakake pitunjuk iki utawa pitunjuk apa wae sing asale.
    /// Yen sampeyan perlu kanggo mutasi isi saka irisan, nggunakake [`as_mut_ptr`].
    ///
    /// # Examples
    ///
    /// ```
    /// let x = vec![1, 2, 4];
    /// let x_ptr = x.as_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         assert_eq!(*x_ptr.add(i), 1 << i);
    ///     }
    /// }
    /// ```
    ///
    /// [`as_mut_ptr`]: Vec::as_mut_ptr
    ///
    ///
    ///
    #[stable(feature = "vec_as_ptr", since = "1.37.0")]
    #[inline]
    pub fn as_ptr(&self) -> *const T {
        // Kita mbayangake cara irisan kanthi jeneng sing padha supaya ora liwat `deref`, sing nggawe referensi menengah.
        //
        let ptr = self.buf.ptr();
        unsafe {
            assume(!ptr.is_null());
        }
        ptr
    }

    /// Ngasilake pitunjuk sing bisa diowahi kanthi aman menyang buffer vector.
    ///
    /// Panelpon kudu mesthekake yen vector luwih gedhe tinimbang pitunjuk sing ngasilake fungsi iki, yen ora bakal nuduhake sampah.
    ///
    /// Ngowahi vector bisa uga nyebabake buffer bisa dialokasikan maneh, sing uga bakal menehi petunjuk yen ora valid.
    ///
    /// # Examples
    ///
    /// ```
    /// // Alokasi vector cukup gedhe kanggo 4 elemen.
    /// let size = 4;
    /// let mut x: Vec<i32> = Vec::with_capacity(size);
    /// let x_ptr = x.as_mut_ptr();
    ///
    /// // Initialisasi elemen liwat panunjuk pointer mentah, banjur atur dawa.
    /// unsafe {
    ///     for i in 0..size {
    ///         *x_ptr.add(i) = i as i32;
    ///     }
    ///     x.set_len(size);
    /// }
    /// assert_eq!(&*x, &[0, 1, 2, 3]);
    /// ```
    ///
    #[stable(feature = "vec_as_ptr", since = "1.37.0")]
    #[inline]
    pub fn as_mut_ptr(&mut self) -> *mut T {
        // Kita mbayangake cara irisan kanthi jeneng sing padha supaya ora liwat `deref_mut`, sing nggawe referensi menengah.
        //
        let ptr = self.buf.ptr();
        unsafe {
            assume(!ptr.is_null());
        }
        ptr
    }

    /// Ngasilake referensi menyang alokasi dhasar.
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn allocator(&self) -> &A {
        self.buf.allocator()
    }

    /// Meksa dawa vector nganti `new_len`.
    ///
    /// Iki minangka operasi tingkat rendah sing ora njaga invarian normal jinis kasebut.
    /// Biasane ngganti dawa vector rampung nggunakake salah sawijining operasi sing aman, kayata [`truncate`], [`resize`], [`extend`], utawa [`clear`].
    ///
    ///
    /// [`truncate`]: Vec::truncate
    /// [`resize`]: Vec::resize
    /// [`extend`]: Extend::extend
    /// [`clear`]: Vec::clear
    ///
    /// # Safety
    ///
    /// - `new_len` kudu kurang saka utawa padha karo [`capacity()`].
    /// - Elemen ing `old_len..new_len` kudu diinisialisasi.
    ///
    /// [`capacity()`]: Vec::capacity
    ///
    /// # Examples
    ///
    /// Cara iki bisa migunani kanggo kahanan ing vector dadi buffer kanggo kode liyane, utamane liwat FFI:
    ///
    /// ```no_run
    /// # #![allow(dead_code)]
    /// # // Iki mung balung tithik kanggo conto doc;
    /// # // aja nggunakake iki minangka titik wiwitan perpustakaan nyata.
    /// # pub struct StreamWrapper { strm: *mut std::ffi::c_void }
    /// # const Z_OK: i32 = 0;
    /// # extern "C" {
    /// #     fn deflateGetDictionary(
    /// #         strm: *mut std::ffi::c_void,
    /// #         dictionary: *mut u8,
    /// #         dictLength: *mut usize,
    /// #     ) -> i32;
    /// # }
    /// # impl StreamWrapper {
    /// pub fn get_dictionary(&self) -> Option<Vec<u8>> {
    ///     // Saben dokumen metode FFI, "32768 bytes is always enough".
    ///     let mut dict = Vec::with_capacity(32_768);
    ///     let mut dict_length = 0;
    ///     // SAFETY: Nalika `deflateGetDictionary` ngasilake `Z_OK`, sampeyan duwe:
    ///     // 1. `dict_length` unsur diwiwiti.
    ///     // 2.
    ///     // `dict_length` <=kapasitas (32_768) sing nggawe `set_len` aman ditelpon.
    ///     unsafe {
    ///         // Telpon FFI ...
    ///         let r = deflateGetDictionary(self.strm, dict.as_mut_ptr(), &mut dict_length);
    ///         if r == Z_OK {
    ///             // ... lan nganyari dawa apa sing wis diwiwiti.
    ///             dict.set_len(dict_length);
    ///             Some(dict)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    /// # }
    /// ```
    ///
    /// Nalika conto ing ngisor iki swara, ana bocor memori amarga vectors ing njero ora dibebasake sadurunge telpon `set_len`:
    ///
    /// ```
    /// let mut vec = vec![vec![1, 0, 0],
    ///                    vec![0, 1, 0],
    ///                    vec![0, 0, 1]];
    /// // SAFETY:
    /// // 1. `old_len..0` kosong dadi ora ana elemen sing kudu diinisialisasi.
    /// // 2. `0 <= capacity` tansah nyekel `capacity` apa wae.
    /// unsafe {
    ///     vec.set_len(0);
    /// }
    /// ```
    ///
    /// Biasane, ing kene, bakal nggunakake [`clear`] kanggo nyelehake konten kanthi bener lan mula ora bocor memori.
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn set_len(&mut self, new_len: usize) {
        debug_assert!(new_len <= self.capacity());

        self.len = new_len;
    }

    /// Mbusak unsur saka vector lan ngasilake.
    ///
    /// Unsur sing dicopot diganti unsur pungkasan vector.
    ///
    /// Iki ora ngreksa pesenan, nanging O(1).
    ///
    /// # Panics
    ///
    /// Panics yen `index` ora ana wates.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec!["foo", "bar", "baz", "qux"];
    ///
    /// assert_eq!(v.swap_remove(1), "bar");
    /// assert_eq!(v, ["foo", "qux", "baz"]);
    ///
    /// assert_eq!(v.swap_remove(0), "foo");
    /// assert_eq!(v, ["baz", "qux"]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn swap_remove(&mut self, index: usize) -> T {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("swap_remove index (is {}) should be < len (is {})", index, len);
        }

        let len = self.len();
        if index >= len {
            assert_failed(index, len);
        }
        unsafe {
            // Kita ngganti [indeks] awake dhewe karo elemen pungkasan.
            // Elinga yen yen mriksa wates ing ndhuwur kudu ana elemen pungkasan (sing bisa dadi indeks dhewe).
            //
            let last = ptr::read(self.as_ptr().add(len - 1));
            let hole = self.as_mut_ptr().add(index);
            self.set_len(len - 1);
            ptr::replace(hole, last)
        }
    }

    /// Lebokake elemen ing posisi `index` ing vector, ganti kabeh elemen ing sisih tengen.
    ///
    ///
    /// # Panics
    ///
    /// Panics yen `index > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.insert(1, 4);
    /// assert_eq!(vec, [1, 4, 2, 3]);
    /// vec.insert(4, 5);
    /// assert_eq!(vec, [1, 4, 2, 3, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn insert(&mut self, index: usize, element: T) {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("insertion index (is {}) should be <= len (is {})", index, len);
        }

        let len = self.len();
        if index > len {
            assert_failed(index, len);
        }

        // papan kanggo elemen anyar
        if len == self.buf.capacity() {
            self.reserve(1);
        }

        unsafe {
            // infallible Titik kanggo nyelehake regane anyar
            //
            {
                let p = self.as_mut_ptr().add(index);
                // Geser kabeh kanggo nggawe ruangan.
                // (Duplikasi elemen `indeks` dadi rong panggonan berturut-turut.)
                ptr::copy(p, p.offset(1), len - index);
                // Tulis ing, nimpa salinan pisanan elemen `indeks`.
                //
                ptr::write(p, element);
            }
            self.set_len(len + 1);
        }
    }

    /// Mbusak lan ngasilake elemen ing posisi `index` ing vector, ngowahi kabeh elemen sawise ing sisih kiwa.
    ///
    ///
    /// # Panics
    ///
    /// Panics yen `index` ora ana wates.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// assert_eq!(v.remove(1), 2);
    /// assert_eq!(v, [1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, index: usize) -> T {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("removal index (is {}) should be < len (is {})", index, len);
        }

        let len = self.len();
        if index >= len {
            assert_failed(index, len);
        }
        unsafe {
            // infallible
            let ret;
            {
                // papan sing kita njupuk saka.
                let ptr = self.as_mut_ptr().add(index);
                // salin metu, kanthi aman duwe salinan regane ing tumpukan lan ing vector sekaligus.
                //
                ret = ptr::read(ptr);

                // Ganti kabeh kanggo ngisi titik kasebut.
                ptr::copy(ptr.offset(1), ptr, len - index - 1);
            }
            self.set_len(len - 1);
            ret
        }
    }

    /// Mung nahan unsur sing ditemtokake dening predikat.
    ///
    /// Kanthi tembung liyane, mbusak kabeh elemen `e` saengga `f(&e)` ngasilake `false`.
    /// Cara iki bisa digunakake ing papan, ngunjungi saben elemen persis sapisan ing urutan asline, lan ngreksa urutan unsur-unsur sing ditahan.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4];
    /// vec.retain(|&x| x % 2 == 0);
    /// assert_eq!(vec, [2, 4]);
    /// ```
    ///
    /// Amarga elemen kasebut dikunjungi persis sapisan ing urutan asline, negara eksternal bisa uga digunakake kanggo mutusake unsur sing bakal disimpen.
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4, 5];
    /// let keep = [false, true, true, false, true];
    /// let mut iter = keep.iter();
    /// vec.retain(|_| *iter.next().unwrap());
    /// assert_eq!(vec, [2, 3, 5]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> bool,
    {
        let original_len = self.len();
        // Aja gulung kaping pindho yen penjaga gulung ora dieksekusi, amarga kita bisa nggawe bolongan sajrone proses kasebut.
        //
        unsafe { self.set_len(0) };

        // Vec: [Kept, Kept, Hole, Hole, Hole, Hole, Unchecked, Unchecked]
        //      | <-olahan len-> |^-sabanjure dipriksa
        //                  | <-mbusak cnt-> |
        //      | <-original_len-> |Ditahan: Unsur sing predikat bakal nyata maneh.
        //
        // Lubuk: Slot unsur sing dipindhah utawa mudhun.
        // Ora dicenthang: Unsur sing bener sing ora dicenthang.
        //
        // Penjaga gulung iki bakal digunakake nalika predikat utawa `drop` elemen gupuh.
        // Ngowahi unsur sing ora dicenthang kanggo nutupi bolongan lan `set_len` kanthi dawa sing bener.
        // Ing kasus nalika predikat lan `drop` ora bakal gupuh, bakal dioptimalake.
        struct BackshiftOnDrop<'a, T, A: Allocator> {
            v: &'a mut Vec<T, A>,
            processed_len: usize,
            deleted_cnt: usize,
            original_len: usize,
        }

        impl<T, A: Allocator> Drop for BackshiftOnDrop<'_, T, A> {
            fn drop(&mut self) {
                if self.deleted_cnt > 0 {
                    // SAFETY: Item sing ora dicenthang ing ngisor kudu bener amarga ora nate demek.
                    unsafe {
                        ptr::copy(
                            self.v.as_ptr().add(self.processed_len),
                            self.v.as_mut_ptr().add(self.processed_len - self.deleted_cnt),
                            self.original_len - self.processed_len,
                        );
                    }
                }
                // SAFETY: Sawise ngisi bolongan, kabeh item ana ing memori contiguous.
                unsafe {
                    self.v.set_len(self.original_len - self.deleted_cnt);
                }
            }
        }

        let mut g = BackshiftOnDrop { v: self, processed_len: 0, deleted_cnt: 0, original_len };

        while g.processed_len < original_len {
            // SAFETY: Elemen sing ora dicenthang kudu bener.
            let cur = unsafe { &mut *g.v.as_mut_ptr().add(g.processed_len) };
            if !f(cur) {
                // Maju luwih dhisik supaya ora gulung tikel yen `drop_in_place` gupuh.
                g.processed_len += 1;
                g.deleted_cnt += 1;
                // SAFETY: Kita ora nate nutul elemen iki maneh sawise mudhun.
                unsafe { ptr::drop_in_place(cur) };
                // Kita wis maju loket.
                continue;
            }
            if g.deleted_cnt > 0 {
                // SAFETY: `deleted_cnt`> 0, mula slot bolongan ora kudu tumpang tindih karo elemen saiki.
                // Kita nggunakake salinan kanggo pamindhahan, lan aja nganti tutul elemen iki maneh.
                unsafe {
                    let hole_slot = g.v.as_mut_ptr().add(g.processed_len - g.deleted_cnt);
                    ptr::copy_nonoverlapping(cur, hole_slot, 1);
                }
            }
            g.processed_len += 1;
        }

        // Kabeh barang wis diproses.Iki bisa optimized kanggo `set_len` dening LLVM.
        drop(g);
    }

    /// Mbusak kabeh elemen elemen pisanan ing vector sing ngrampungake tombol sing padha.
    ///
    ///
    /// Yen vector diurutake, iki bakal mbusak kabeh duplikat.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![10, 20, 21, 30, 20];
    ///
    /// vec.dedup_by_key(|i| *i / 10);
    ///
    /// assert_eq!(vec, [10, 20, 30, 20]);
    /// ```
    #[stable(feature = "dedup_by", since = "1.16.0")]
    #[inline]
    pub fn dedup_by_key<F, K>(&mut self, mut key: F)
    where
        F: FnMut(&mut T) -> K,
        K: PartialEq,
    {
        self.dedup_by(|a, b| key(a) == key(b))
    }

    /// Mbusak kabeh, nanging unsur pertama sing berturut-turut ing vector sing maringi hubungan sing padha.
    ///
    /// Fungsi `same_bucket` liwati referensi kanggo rong unsur saka vector lan kudu nemtokake manawa unsur kasebut mbandhingake padha.
    /// Unsur kasebut dilewati kanthi urutan sing beda saka urutane irisan, mula yen `same_bucket(a, b)` ngasilake `true`, `a` bakal dicopot.
    ///
    ///
    /// Yen vector diurutake, iki bakal mbusak kabeh duplikat.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec!["foo", "bar", "Bar", "baz", "bar"];
    ///
    /// vec.dedup_by(|a, b| a.eq_ignore_ascii_case(b));
    ///
    /// assert_eq!(vec, ["foo", "bar", "baz", "bar"]);
    /// ```
    ///
    #[stable(feature = "dedup_by", since = "1.16.0")]
    pub fn dedup_by<F>(&mut self, mut same_bucket: F)
    where
        F: FnMut(&mut T, &mut T) -> bool,
    {
        let len = self.len();
        if len <= 1 {
            return;
        }

        /* INVARIANT: vec.len() > read >= write > write-1 >= 0 */
        struct FillGapOnDrop<'a, T, A: core::alloc::Allocator> {
            /* Offset of the element we want to check if it is duplicate */
            read: usize,

            /* Offset of the place where we want to place the non-duplicate
             * when we find it. */
            write: usize,

            /* The Vec that would need correction if `same_bucket` panicked */
            vec: &'a mut Vec<T, A>,
        }

        impl<'a, T, A: core::alloc::Allocator> Drop for FillGapOnDrop<'a, T, A> {
            fn drop(&mut self) {
                /* This code gets executed when `same_bucket` panics */

                /* SAFETY: invariant guarantees that `read - write`
                 * and `len - read` never overflow and that the copy is always
                 * in-bounds. */
                unsafe {
                    let ptr = self.vec.as_mut_ptr();
                    let len = self.vec.len();

                    /* How many items were left when `same_bucket` paniced.
                     * Basically vec[read..].len() */
                    let items_left = len.wrapping_sub(self.read);

                    /* Pointer to first item in vec[write..write+items_left] slice */
                    let dropped_ptr = ptr.add(self.write);
                    /* Pointer to first item in vec[read..] slice */
                    let valid_ptr = ptr.add(self.read);

                    /* Copy `vec[read..]` to `vec[write..write+items_left]`.
                     * The slices can overlap, so `copy_nonoverlapping` cannot be used */
                    ptr::copy(valid_ptr, dropped_ptr, items_left);

                    /* How many items have been already dropped
                     * Basically vec[read..write].len() */
                    let dropped = self.read.wrapping_sub(self.write);

                    self.vec.set_len(len - dropped);
                }
            }
        }

        let mut gap = FillGapOnDrop { read: 1, write: 1, vec: self };
        let ptr = gap.vec.as_mut_ptr();

        /* Drop items while going through Vec, it should be more efficient than
         * doing slice partition_dedup + truncate */

        /* SAFETY: Because of the invariant, read_ptr, prev_ptr and write_ptr
         * are always in-bounds and read_ptr never aliases prev_ptr */
        unsafe {
            while gap.read < len {
                let read_ptr = ptr.add(gap.read);
                let prev_ptr = ptr.add(gap.write.wrapping_sub(1));

                if same_bucket(&mut *read_ptr, &mut *prev_ptr) {
                    /* We have found duplicate, drop it in-place */
                    ptr::drop_in_place(read_ptr);
                } else {
                    let write_ptr = ptr.add(gap.write);

                    /* Because `read_ptr` can be equal to `write_ptr`, we either
                     * have to use `copy` or conditional `copy_nonoverlapping`.
                     * Looks like the first option is faster. */
                    ptr::copy(read_ptr, write_ptr, 1);

                    /* We have filled that place, so go further */
                    gap.write += 1;
                }

                gap.read += 1;
            }

            /* Technically we could let `gap` clean up with its Drop, but
             * when `same_bucket` is guaranteed to not panic, this bloats a little
             * the codegen, so we just do it manually */
            gap.vec.set_len(gap.write);
            mem::forget(gap);
        }
    }

    /// Nambahake unsur ing mburi koleksi.
    ///
    /// # Panics
    ///
    /// Panics yen kapasitas anyar ngluwihi `isize::MAX` byte.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2];
    /// vec.push(3);
    /// assert_eq!(vec, [1, 2, 3]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, value: T) {
        // Iki bakal panic utawa ngilangi yen bakal menehi> byte isize::MAX utawa yen kenaikan dawa bakal melu kanggo jinis ukuran nol.
        //
        if self.len == self.buf.capacity() {
            self.reserve(1);
        }
        unsafe {
            let end = self.as_mut_ptr().add(self.len);
            ptr::write(end, value);
            self.len += 1;
        }
    }

    /// Mbusak unsur pungkasan saka vector lan ngasilake, utawa [`None`] yen kosong.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// assert_eq!(vec.pop(), Some(3));
    /// assert_eq!(vec, [1, 2]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<T> {
        if self.len == 0 {
            None
        } else {
            unsafe {
                self.len -= 1;
                Some(ptr::read(self.as_ptr().add(self.len())))
            }
        }
    }

    /// Pindhah kabeh elemen `other` dadi `Self`, dadi kosongake `other`.
    ///
    /// # Panics
    ///
    /// Panics yen jumlah elemen ing vector kebanjiran `usize`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// let mut vec2 = vec![4, 5, 6];
    /// vec.append(&mut vec2);
    /// assert_eq!(vec, [1, 2, 3, 4, 5, 6]);
    /// assert_eq!(vec2, []);
    /// ```
    #[inline]
    #[stable(feature = "append", since = "1.4.0")]
    pub fn append(&mut self, other: &mut Self) {
        unsafe {
            self.append_elements(other.as_slice() as _);
            other.set_len(0);
        }
    }

    /// Nambah unsur menyang `Self` saka buffer liyane.
    #[inline]
    unsafe fn append_elements(&mut self, other: *const [T]) {
        let count = unsafe { (*other).len() };
        self.reserve(count);
        let len = self.len();
        unsafe { ptr::copy_nonoverlapping(other as *const T, self.as_mut_ptr().add(len), count) };
        self.len += count;
    }

    /// Nggawe draining iterator sing mbusak sawetara kasebut ing vector lan panenan item dibusak.
    ///
    /// Nalika iterator **mudhun**, kabeh unsur ing kisaran dicopot saka vector, sanajan iterator durung dikonsumsi kanthi lengkap.
    /// Yen iterator **ora** mudhun (contone karo [`mem::forget`]), ora ditemtokake pirang-pirang elemen sing dibusak.
    ///
    /// # Panics
    ///
    /// Panics yen titik wiwitan luwih gedhe tinimbang titik pungkasan utawa yen titik pungkasan luwih gedhe tinimbang dawa vector.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// let u: Vec<_> = v.drain(1..).collect();
    /// assert_eq!(v, &[1]);
    /// assert_eq!(u, &[2, 3]);
    ///
    /// // Jangkauan lengkap mbusak vector
    /// v.drain(..);
    /// assert_eq!(v, &[]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_, T, A>
    where
        R: RangeBounds<usize>,
    {
        // Keamanan memori
        //
        // Nalika Drain digawe kaping pisanan, bakal nyuda dawa sumber vector kanggo mesthekake ora ana unsur sing ora diresmine utawa dipindhah saka elemen sing bisa diakses kabeh yen destruktor Drain ora bisa mlaku.
        //
        //
        // Drain bakal ptr::read nilai metu kanggo mbusak.
        // Yen wis rampung, buntut sisa vektor disalin maneh kanggo nutupi bolongan, lan dawa vector dipulihake dadi dawa anyar.
        //
        //
        //
        let len = self.len();
        let Range { start, end } = slice::range(range, ..len);

        unsafe {
            // Nyetel dawa self.vec kanggo miwiti, supaya aman yen bocor Drain
            self.set_len(start);
            // Gunakake utang ing IterMut kanggo nunjukake tumindak utang kabeh iterator Drain (kaya &mut T).
            //
            let range_slice = slice::from_raw_parts_mut(self.as_mut_ptr().add(start), end - start);
            Drain {
                tail_start: end,
                tail_len: len - end,
                iter: range_slice.iter(),
                vec: NonNull::from(self),
            }
        }
    }

    /// Ngilangi vector, njabut kabeh angka.
    ///
    /// Elinga yen cara iki ora duwe pengaruh marang kapasitas vector sing dialokasikan.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    ///
    /// v.clear();
    ///
    /// assert!(v.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.truncate(0)
    }

    /// Ngasilake jumlah elemen ing vector, uga diarani 'length'.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = vec![1, 2, 3];
    /// assert_eq!(a.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.len
    }

    /// Ngasilake `true` yen vector ora ana unsur.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = Vec::new();
    /// assert!(v.is_empty());
    ///
    /// v.push(1);
    /// assert!(!v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Misahake koleksi dadi loro ing indeks sing diwenehake.
    ///
    /// Ngasilake vector sing mentas dialokasikan ngemot unsur ing kisaran `[at, len)`.
    /// Sawise telpon, vector asli bakal kari ngemot elemen `[0, at)` kanthi kapasitas sadurunge ora diganti.
    ///
    ///
    /// # Panics
    ///
    /// Panics yen `at > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// let vec2 = vec.split_off(1);
    /// assert_eq!(vec, [1]);
    /// assert_eq!(vec2, [2, 3]);
    /// ```
    #[inline]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    #[stable(feature = "split_off", since = "1.4.0")]
    pub fn split_off(&mut self, at: usize) -> Self
    where
        A: Clone,
    {
        #[cold]
        #[inline(never)]
        fn assert_failed(at: usize, len: usize) -> ! {
            panic!("`at` split index (is {}) should be <= len (is {})", at, len);
        }

        if at > self.len() {
            assert_failed(at, self.len());
        }

        if at == 0 {
            // vector anyar bisa njupuk buffer asli lan ngindhari salinan kasebut
            return mem::replace(
                self,
                Vec::with_capacity_in(self.capacity(), self.allocator().clone()),
            );
        }

        let other_len = self.len - at;
        let mut other = Vec::with_capacity_in(other_len, self.allocator().clone());

        // `set_len` ora aman lan salin item menyang `other`.
        unsafe {
            self.set_len(at);
            other.set_len(other_len);

            ptr::copy_nonoverlapping(self.as_ptr().add(at), other.as_mut_ptr(), other.len());
        }
        other
    }

    /// Resizes ing `Vec` ing-Panggonan supaya `len` punika witjaksono menyang `new_len`.
    ///
    /// Yen `new_len` luwih gedhe tinimbang `len`, `Vec` bakal ditambah kanthi bedane, kanthi saben slot tambahan diisi karo asil ngundang `f`.
    ///
    /// Nilai bali saka `f` bakal pungkasan ing `Vec` miturut urutan sing digawe.
    ///
    /// Yen `new_len` kurang saka `len`, ing `Vec` mung truncated.
    ///
    /// Cara iki nggunakake penutupan kanggo nggawe nilai anyar ing saben push.Yen luwih seneng [`Clone`] nilai tartamtu, gunakake [`Vec::resize`].
    /// Yen sampeyan pengin nggunakake [`Default`] trait kanggo ngasilake angka, sampeyan bisa ngliwati [`Default::default`] minangka argumen nomer loro.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.resize_with(5, Default::default);
    /// assert_eq!(vec, [1, 2, 3, 0, 0]);
    ///
    /// let mut vec = vec![];
    /// let mut p = 1;
    /// vec.resize_with(4, || { p *= 2; p });
    /// assert_eq!(vec, [2, 4, 8, 16]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "vec_resize_with", since = "1.33.0")]
    pub fn resize_with<F>(&mut self, new_len: usize, f: F)
    where
        F: FnMut() -> T,
    {
        let len = self.len();
        if new_len > len {
            self.extend_with(new_len - len, ExtendFunc(f));
        } else {
            self.truncate(new_len);
        }
    }

    /// Nganggo lan bocor `Vec`, ngasilake referensi sing bisa diowahi kanggo konten, `&'a mut [T]`.
    /// Elinga yen jinis `T` kudu urip luwih dhisik `'a`.
    /// Yen jinis kasebut mung duwe referensi statis, utawa ora ana kabeh, mula iki bisa dipilih dadi `'static`.
    ///
    /// Fungsi iki padha karo fungsi [`leak`][Box::leak] ing [`Box`] kajaba ora ana cara kanggo mbalekake memori sing bocor.
    ///
    ///
    /// Fungsi iki utamane migunani kanggo data sing isih urip sajrone program kasebut.
    /// Nindakake referensi bali bakal nyebabake bocor memori.
    ///
    /// # Examples
    ///
    /// Panggunaan sing gampang:
    ///
    /// ```
    /// let x = vec![1, 2, 3];
    /// let static_ref: &'static mut [usize] = x.leak();
    /// static_ref[0] += 1;
    /// assert_eq!(static_ref, &[2, 2, 3]);
    /// ```
    ///
    ///
    #[stable(feature = "vec_leak", since = "1.47.0")]
    #[inline]
    pub fn leak<'a>(self) -> &'a mut [T]
    where
        A: 'a,
    {
        Box::leak(self.into_boxed_slice())
    }

    /// Ngasilake sisa kapasitas vector minangka potongan `MaybeUninit<T>`.
    ///
    /// Irisan sing bali bisa digunakake kanggo ngisi data vector (kayata
    /// kanthi maca saka file) sadurunge menehi tandha data minangka inisialisasi nggunakake metode [`set_len`].
    ///
    ///
    /// [`set_len`]: Vec::set_len
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_spare_capacity, maybe_uninit_extra)]
    ///
    /// // Alokasi vector cukup gedhe kanggo 10 elemen.
    /// let mut v = Vec::with_capacity(10);
    ///
    /// // Isi 3 elemen pertama.
    /// let uninit = v.spare_capacity_mut();
    /// uninit[0].write(0);
    /// uninit[1].write(1);
    /// uninit[2].write(2);
    ///
    /// // Tandhani 3 unsur pisanan vector minangka sing wis diwiwiti.
    /// unsafe {
    ///     v.set_len(3);
    /// }
    ///
    /// assert_eq!(&v, &[0, 1, 2]);
    /// ```
    ///
    #[unstable(feature = "vec_spare_capacity", issue = "75017")]
    #[inline]
    pub fn spare_capacity_mut(&mut self) -> &mut [MaybeUninit<T>] {
        // Note:
        // Cara iki ora ditrapake ing `split_at_spare_mut`, kanggo nyegah validasi pointer menyang buffer.
        //
        unsafe {
            slice::from_raw_parts_mut(
                self.as_mut_ptr().add(self.len) as *mut MaybeUninit<T>,
                self.buf.capacity() - self.len,
            )
        }
    }

    /// Ngasilake konten vector minangka irisan `T`, bebarengan karo sisa kapasitas vector minangka irisan `MaybeUninit<T>`.
    ///
    /// Irisan kapasitas cadhangan bali bisa digunakake kanggo ngisi data vector (kayata maca saka file) sadurunge menehi tandha data minangka inisialisasi nggunakake metode [`set_len`].
    ///
    /// [`set_len`]: Vec::set_len
    ///
    /// Elinga yen iki API tingkat rendah, sing kudu digunakake kanthi ati-ati kanggo tujuan optimalisasi.
    /// Yen sampeyan kudu nambah data menyang `Vec`, sampeyan bisa nggunakake [`push`], [`extend`], [`extend_from_slice`], [`extend_from_within`], [`insert`], [`append`], [`resize`] utawa [`resize_with`], gumantung saka kabutuhan sampeyan.
    ///
    ///
    /// [`push`]: Vec::push
    /// [`extend`]: Vec::extend
    /// [`extend_from_slice`]: Vec::extend_from_slice
    /// [`extend_from_within`]: Vec::extend_from_within
    /// [`insert`]: Vec::insert
    /// [`append`]: Vec::append
    /// [`resize`]: Vec::resize
    /// [`resize_with`]: Vec::resize_with
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_split_at_spare, maybe_uninit_extra)]
    ///
    /// let mut v = vec![1, 1, 2];
    ///
    /// // Cadangan papan tambahan cukup gedhe kanggo 10 elemen.
    /// v.reserve(10);
    ///
    /// let (init, uninit) = v.split_at_spare_mut();
    /// let sum = init.iter().copied().sum::<u32>();
    ///
    /// // Iseni 4 elemen sabanjure.
    /// uninit[0].write(sum);
    /// uninit[1].write(sum * 2);
    /// uninit[2].write(sum * 3);
    /// uninit[3].write(sum * 4);
    ///
    /// // Tandhani 4 unsur vector minangka wis diwiwiti.
    /// unsafe {
    ///     let len = v.len();
    ///     v.set_len(len + 4);
    /// }
    ///
    /// assert_eq!(&v, &[1, 1, 2, 4, 8, 12, 16]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_split_at_spare", issue = "81944")]
    #[inline]
    pub fn split_at_spare_mut(&mut self) -> (&mut [T], &mut [MaybeUninit<T>]) {
        // SAFETY:
        // - Len ora digatekake lan mula ora owah
        let (init, spare, _) = unsafe { self.split_at_spare_mut_with_len() };
        (init, spare)
    }

    /// Keamanan: ganti bali .2 (&mut usize) dianggep padha karo nelpon `.set_len(_)`.
    ///
    /// Cara iki digunakake kanggo nduweni akses unik menyang kabeh bagean vektor sekaligus ing `extend_from_within`.
    unsafe fn split_at_spare_mut_with_len(
        &mut self,
    ) -> (&mut [T], &mut [MaybeUninit<T>], &mut usize) {
        let Range { start: ptr, end: spare_ptr } = self.as_mut_ptr_range();
        let spare_ptr = spare_ptr.cast::<MaybeUninit<T>>();
        let spare_len = self.buf.capacity() - self.len;

        // SAFETY:
        // - `ptr` dijamin bener kanggo elemen `len`
        // - `spare_ptr` nuduhake salah sawijining elemen liwat buffer, dadi ora tumpang tindih karo `initialized`
        unsafe {
            let initialized = slice::from_raw_parts_mut(ptr, self.len);
            let spare = slice::from_raw_parts_mut(spare_ptr, spare_len);

            (initialized, spare, &mut self.len)
        }
    }
}

impl<T: Clone, A: Allocator> Vec<T, A> {
    /// Resizes ing `Vec` ing-Panggonan supaya `len` punika witjaksono menyang `new_len`.
    ///
    /// Yen `new_len` luwih gedhe tinimbang `len`, `Vec` bakal ditambah kanthi bedane, kanthi saben slot tambahan diisi karo `value`.
    ///
    /// Yen `new_len` kurang saka `len`, ing `Vec` mung truncated.
    ///
    /// Cara iki mbutuhake `T` kanggo ngetrapake [`Clone`], supaya bisa klone nilai sing dilewati.
    /// Yen sampeyan butuh keluwesan luwih akeh (utawa pengin ngandelake [`Default`] tinimbang [`Clone`]), gunakake [`Vec::resize_with`].
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec!["hello"];
    /// vec.resize(3, "world");
    /// assert_eq!(vec, ["hello", "world", "world"]);
    ///
    /// let mut vec = vec![1, 2, 3, 4];
    /// vec.resize(2, 0);
    /// assert_eq!(vec, [1, 2]);
    /// ```
    ///
    ///
    #[stable(feature = "vec_resize", since = "1.5.0")]
    pub fn resize(&mut self, new_len: usize, value: T) {
        let len = self.len();

        if new_len > len {
            self.extend_with(new_len - len, ExtendElement(value))
        } else {
            self.truncate(new_len);
        }
    }

    /// Klon lan nambah kabeh elemen ing irisan menyang `Vec`.
    ///
    /// Iterates ing irisan `other`, klon saben elemen, lan banjur tambah menyang `Vec` iki.
    /// `other` vector dilintasi kanthi urutan.
    ///
    /// Elinga yen fungsi iki padha karo [`extend`], kajaba nggunakake khusus irisan.
    ///
    /// Yen lan nalika Rust entuk spesialisasi, fungsi iki kemungkinan bakal mudhun (nanging isih kasedhiya).
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.extend_from_slice(&[2, 3, 4]);
    /// assert_eq!(vec, [1, 2, 3, 4]);
    /// ```
    ///
    /// [`extend`]: Vec::extend
    ///
    #[stable(feature = "vec_extend_from_slice", since = "1.6.0")]
    pub fn extend_from_slice(&mut self, other: &[T]) {
        self.spec_extend(other.iter())
    }

    /// Nyalin elemen saka kisaran `src` nganti pungkasan vector.
    ///
    /// ## Examples
    ///
    /// ```
    /// #![feature(vec_extend_from_within)]
    ///
    /// let mut vec = vec![0, 1, 2, 3, 4];
    ///
    /// vec.extend_from_within(2..);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4]);
    ///
    /// vec.extend_from_within(..2);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4, 0, 1]);
    ///
    /// vec.extend_from_within(4..8);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4, 0, 1, 4, 2, 3, 4]);
    /// ```
    #[unstable(feature = "vec_extend_from_within", issue = "81656")]
    pub fn extend_from_within<R>(&mut self, src: R)
    where
        R: RangeBounds<usize>,
    {
        let range = slice::range(src, ..self.len());
        self.reserve(range.len());

        // SAFETY:
        // - `slice::range` njamin manawa sawetara sing diwenehake bener kanggo indeksasi dhewe
        unsafe {
            self.spec_extend_from_within(range);
        }
    }
}

// Kode iki umume `extend_with_{element,default}`.
trait ExtendWith<T> {
    fn next(&mut self) -> T;
    fn last(self) -> T;
}

struct ExtendElement<T>(T);
impl<T: Clone> ExtendWith<T> for ExtendElement<T> {
    fn next(&mut self) -> T {
        self.0.clone()
    }
    fn last(self) -> T {
        self.0
    }
}

struct ExtendDefault;
impl<T: Default> ExtendWith<T> for ExtendDefault {
    fn next(&mut self) -> T {
        Default::default()
    }
    fn last(self) -> T {
        Default::default()
    }
}

struct ExtendFunc<F>(F);
impl<T, F: FnMut() -> T> ExtendWith<T> for ExtendFunc<F> {
    fn next(&mut self) -> T {
        (self.0)()
    }
    fn last(mut self) -> T {
        (self.0)()
    }
}

impl<T, A: Allocator> Vec<T, A> {
    /// Tambah angka vector kanthi nilai `n`, nggunakake generator sing diwenehake.
    fn extend_with<E: ExtendWith<T>>(&mut self, n: usize, mut value: E) {
        self.reserve(n);

        unsafe {
            let mut ptr = self.as_mut_ptr().add(self.len());
            // Gunakake SetLenOnDrop kanggo nggarap bug ing ngendi kompiler bisa uga ora sadhar toko liwat `ptr` nganti self.set_len() aja alias.
            //
            //
            let mut local_len = SetLenOnDrop::new(&mut self.len);

            // Tulis kabeh elemen kajaba sing terakhir
            for _ in 1..n {
                ptr::write(ptr, value.next());
                ptr = ptr.offset(1);
                // Tambah dawa ing saben langkah ing kasus next() panics
                local_len.increment_len(1);
            }

            if n > 0 {
                // Kita bisa nulis unsur pungkasan kanthi langsung tanpa kloning tanpa perlu
                ptr::write(ptr, value.last());
                local_len.increment_len(1);
            }

            // len diatur dening penjaga ruang lingkup
        }
    }
}

impl<T: PartialEq, A: Allocator> Vec<T, A> {
    /// Mbusak unsur bola consecutive ing vector miturut lampahipun [`PartialEq`] trait.
    ///
    ///
    /// Yen vector diurutake, iki bakal mbusak kabeh duplikat.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 2, 3, 2];
    ///
    /// vec.dedup();
    ///
    /// assert_eq!(vec, [1, 2, 3, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn dedup(&mut self) {
        self.dedup_by(|a, b| a == b)
    }
}

////////////////////////////////////////////////////////////////////////////////
// Cara lan fungsi internal
////////////////////////////////////////////////////////////////////////////////

#[doc(hidden)]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_elem<T: Clone>(elem: T, n: usize) -> Vec<T> {
    <T as SpecFromElem>::from_elem(elem, n, Global)
}

#[doc(hidden)]
#[unstable(feature = "allocator_api", issue = "32838")]
pub fn from_elem_in<T: Clone, A: Allocator>(elem: T, n: usize, alloc: A) -> Vec<T, A> {
    <T as SpecFromElem>::from_elem(elem, n, alloc)
}

trait ExtendFromWithinSpec {
    /// # Safety
    ///
    /// - `src` kudu indeks sing bener
    /// - `self.capacity() - self.len()` kudu `>= src.len()`
    unsafe fn spec_extend_from_within(&mut self, src: Range<usize>);
}

impl<T: Clone, A: Allocator> ExtendFromWithinSpec for Vec<T, A> {
    default unsafe fn spec_extend_from_within(&mut self, src: Range<usize>) {
        // SAFETY:
        // - len mung ditambah sawise nggawe elemen wiwitan
        let (this, spare, len) = unsafe { self.split_at_spare_mut_with_len() };

        // SAFETY:
        // - panelpon njamin manawa src minangka indeks sing valid
        let to_clone = unsafe { this.get_unchecked(src) };

        to_clone
            .iter()
            .cloned()
            .zip(spare.iter_mut())
            .map(|(src, dst)| dst.write(src))
            // Note:
            // - Unsur mung diwiwiti karo `MaybeUninit::write`, mula luwih becik nambah len
            // - len ditambah sawise saben elemen kanggo nyegah bocor (waca masalah #82533)
            .for_each(|_| *len += 1);
    }
}

impl<T: Copy, A: Allocator> ExtendFromWithinSpec for Vec<T, A> {
    unsafe fn spec_extend_from_within(&mut self, src: Range<usize>) {
        let count = src.len();
        {
            let (init, spare) = self.split_at_spare_mut();

            // SAFETY:
            // - panelpon njamin manawa `src` minangka indeks sing valid
            let source = unsafe { init.get_unchecked(src) };

            // SAFETY:
            // - Kaloro petunjuk digawe saka referensi irisan unik (`&mut [_]`) saengga valid lan ora tumpang tindih.
            //
            // - Elemen yaiku: Salin dadi OK kanggo nyalin, tanpa nindakake apa-apa kanthi nilai asli
            // - `count` padha karo len `source`, dadi sumber bener kanggo `count` maos
            // - `.reserve(count)` njamin manawa `spare.len() >= count` dadi ganti kanggo `count` nyerat
            //
            //
            //
            unsafe { ptr::copy_nonoverlapping(source.as_ptr(), spare.as_mut_ptr() as _, count) };
        }

        // SAFETY:
        // - Unsur kasebut mung diwiwiti karo `copy_nonoverlapping`
        self.len += count;
    }
}

////////////////////////////////////////////////////////////////////////////////
// Implementasi trait umum kanggo Vec
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> ops::Deref for Vec<T, A> {
    type Target = [T];

    fn deref(&self) -> &[T] {
        unsafe { slice::from_raw_parts(self.as_ptr(), self.len) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> ops::DerefMut for Vec<T, A> {
    fn deref_mut(&mut self) -> &mut [T] {
        unsafe { slice::from_raw_parts_mut(self.as_mut_ptr(), self.len) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone, A: Allocator + Clone> Clone for Vec<T, A> {
    #[cfg(not(test))]
    fn clone(&self) -> Self {
        let alloc = self.allocator().clone();
        <[T]>::to_vec_in(&**self, alloc)
    }

    // HACK(japaric): kanthi cfg(test) cara `[T]::to_vec` sing ana, sing dibutuhake kanggo definisi metode iki, ora kasedhiya.
    // Nanging gunakake fungsi `slice::to_vec` sing mung kasedhiya karo cfg(test) NB deleng modul slice::hack ing slice.rs kanggo informasi luwih lengkap
    //
    //
    #[cfg(test)]
    fn clone(&self) -> Self {
        let alloc = self.allocator().clone();
        crate::slice::to_vec(&**self, alloc)
    }

    fn clone_from(&mut self, other: &Self) {
        // nyelehake apa wae sing ora bakal ditumpuk
        self.truncate(other.len());

        // self.len <= other.len amarga truncate ing ndhuwur, mula irisan ing kene mesthi ana ing wates.
        //
        let (init, tail) = other.split_at(self.len());

        // gunakake maneh nilai sing ana ing allocations/resources.
        self.clone_from_slice(init);
        self.extend_from_slice(tail);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Hash, A: Allocator> Hash for Vec<T, A> {
    #[inline]
    fn hash<H: Hasher>(&self, state: &mut H) {
        Hash::hash(&**self, state)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "vector indices are of type `usize` or ranges of `usize`",
    label = "vector indices are of type `usize` or ranges of `usize`"
)]
impl<T, I: SliceIndex<[T]>, A: Allocator> Index<I> for Vec<T, A> {
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &Self::Output {
        Index::index(&**self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "vector indices are of type `usize` or ranges of `usize`",
    label = "vector indices are of type `usize` or ranges of `usize`"
)]
impl<T, I: SliceIndex<[T]>, A: Allocator> IndexMut<I> for Vec<T, A> {
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut Self::Output {
        IndexMut::index_mut(&mut **self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> FromIterator<T> for Vec<T> {
    #[inline]
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> Vec<T> {
        <Self as SpecFromIter<T, I::IntoIter>>::from_iter(iter.into_iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> IntoIterator for Vec<T, A> {
    type Item = T;
    type IntoIter = IntoIter<T, A>;

    /// Nggawe iterator sing akeh, yaiku sing mindhah saben nilai metu saka vector (saka wiwitan nganti pungkasan).
    /// vector ora bisa digunakake sawise nelpon iki.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = vec!["a".to_string(), "b".to_string()];
    /// for s in v.into_iter() {
    ///     // s duwe jinis String, dudu &String
    ///     println!("{}", s);
    /// }
    /// ```
    ///
    #[inline]
    fn into_iter(self) -> IntoIter<T, A> {
        unsafe {
            let mut me = ManuallyDrop::new(self);
            let alloc = ptr::read(me.allocator());
            let begin = me.as_mut_ptr();
            let end = if mem::size_of::<T>() == 0 {
                arith_offset(begin as *const i8, me.len() as isize) as *const T
            } else {
                begin.add(me.len()) as *const T
            };
            let cap = me.buf.capacity();
            IntoIter {
                buf: NonNull::new_unchecked(begin),
                phantom: PhantomData,
                cap,
                alloc,
                ptr: begin,
                end,
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, A: Allocator> IntoIterator for &'a Vec<T, A> {
    type Item = &'a T;
    type IntoIter = slice::Iter<'a, T>;

    fn into_iter(self) -> slice::Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, A: Allocator> IntoIterator for &'a mut Vec<T, A> {
    type Item = &'a mut T;
    type IntoIter = slice::IterMut<'a, T>;

    fn into_iter(self) -> slice::IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> Extend<T> for Vec<T, A> {
    #[inline]
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        <Self as SpecExtend<T, I::IntoIter>>::spec_extend(self, iter.into_iter())
    }

    #[inline]
    fn extend_one(&mut self, item: T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

impl<T, A: Allocator> Vec<T, A> {
    // cara rwaning delegasi macem-macem implementasi SpecFrom/SpecExtend nalika ora duwe optimasi luwih dhisik
    //
    fn extend_desugared<I: Iterator<Item = T>>(&mut self, mut iterator: I) {
        // Iki minangka kasus kanggo pengulangan umum.
        //
        // Fungsi iki kudu padha karo moral ing:
        //
        //      kanggo item ing iterator {
        //          self.push(item);
        //      }
        while let Some(element) = iterator.next() {
            let len = self.len();
            if len == self.capacity() {
                let (lower, _) = iterator.size_hint();
                self.reserve(lower.saturating_add(1));
            }
            unsafe {
                ptr::write(self.as_mut_ptr().add(len), element);
                // NB ora bisa kebanjiran amarga kita kudu menehi ruang alamat
                self.set_len(len + 1);
            }
        }
    }

    /// Nggawe itungan splicing sing ngganti sawetara sing ditemtokake ing vector kanthi iterator `replace_with` sing diwenehake lan ngasilake barang sing dicopot.
    ///
    /// `replace_with` ora prelu dawa padha karo `range`.
    ///
    /// `range` dicopot sanajan iterator ora dikonsumsi nganti pungkasan.
    ///
    /// Ora ditemtokake pirang-pirang elemen sing dibuang saka vector yen bocor `Splice`.
    ///
    /// Iterator input `replace_with` mung dikonsumsi nalika nilai `Splice` mudhun.
    ///
    /// Iki paling optimal yen:
    ///
    /// * Buntut (unsur ing vector sawise `range`) kosong,
    /// * utawa `replace_with` ngasilake unsur sing kurang utawa padha tinimbang dawa `range`
    /// * utawa wates ngisor `size_hint()` persis.
    ///
    /// Yen ora, sing vector sauntara wis diparengake lan buntut wis dipindhah kaping pindho.
    ///
    /// # Panics
    ///
    /// Panics yen titik wiwitan luwih gedhe tinimbang titik pungkasan utawa yen titik pungkasan luwih gedhe tinimbang dawa vector.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// let new = [7, 8];
    /// let u: Vec<_> = v.splice(..2, new.iter().cloned()).collect();
    /// assert_eq!(v, &[7, 8, 3]);
    /// assert_eq!(u, &[1, 2]);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "vec_splice", since = "1.21.0")]
    pub fn splice<R, I>(&mut self, range: R, replace_with: I) -> Splice<'_, I::IntoIter, A>
    where
        R: RangeBounds<usize>,
        I: IntoIterator<Item = T>,
    {
        Splice { drain: self.drain(range), replace_with: replace_with.into_iter() }
    }

    /// Nggawe iterator sing nggunakake penutupan kanggo nemtokake manawa unsur kudu dicopot.
    ///
    /// Yen penutupan nyata, mula elemen kasebut bakal dicopot lan diwenehake.
    /// Yen penutupan ngasilake palsu, unsur kasebut bakal tetep ana ing vector lan ora bakal diwenehake dening pengangitan.
    ///
    /// Nggunakake cara iki padha karo kode ing ngisor iki:
    ///
    /// ```
    /// # let some_predicate = |x: &mut i32| { *x == 2 || *x == 3 || *x == 6 };
    /// # let mut vec = vec![1, 2, 3, 4, 5, 6];
    /// let mut i = 0;
    /// while i != vec.len() {
    ///     if some_predicate(&mut vec[i]) {
    ///         let val = vec.remove(i);
    ///         // kode sampeyan ing kene
    ///     } else {
    ///         i += 1;
    ///     }
    /// }
    ///
    /// # assert_eq!(vec, vec![1, 4, 5]);
    /// ```
    ///
    /// Nanging `drain_filter` luwih gampang digunakake.
    /// `drain_filter` uga luwih efisien, amarga bisa mundur saka unsur susunan kanthi akeh.
    ///
    /// Elinga yen `drain_filter` uga ngidini sampeyan mutasi kabeh elemen ing penutupan filter, ora preduli sampeyan milih tetep utawa mbusak.
    ///
    ///
    /// # Examples
    ///
    /// Pisah Uploaded menyang evens lan rintangan, Anggo manèh persediaan asli:
    ///
    /// ```
    /// #![feature(drain_filter)]
    /// let mut numbers = vec![1, 2, 3, 4, 5, 6, 8, 9, 11, 13, 14, 15];
    ///
    /// let evens = numbers.drain_filter(|x| *x % 2 == 0).collect::<Vec<_>>();
    /// let odds = numbers;
    ///
    /// assert_eq!(evens, vec![2, 4, 6, 8, 14]);
    /// assert_eq!(odds, vec![1, 3, 5, 9, 11, 13, 15]);
    /// ```
    ///
    #[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
    pub fn drain_filter<F>(&mut self, filter: F) -> DrainFilter<'_, T, F, A>
    where
        F: FnMut(&mut T) -> bool,
    {
        let old_len = self.len();

        // Pengawal supaya kita bocor (amplifikasi bocor)
        unsafe {
            self.set_len(0);
        }

        DrainFilter { vec: self, idx: 0, del: 0, old_len, pred: filter, panic_flag: false }
    }
}

/// Tambahake implementasi sing nyalin elemen saka referensi sadurunge push menyang Vec.
///
/// Implementasi iki khusus kanggo irisan irisan, sing nggunakake [`copy_from_slice`] kanggo nambah kabeh irisan sekaligus.
///
///
/// [`copy_from_slice`]: slice::copy_from_slice
#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: Copy + 'a, A: Allocator + 'a> Extend<&'a T> for Vec<T, A> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.spec_extend(iter.into_iter())
    }

    #[inline]
    fn extend_one(&mut self, &item: &'a T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

/// Ngleksanakake mbandhingake vectors, [lexicographically](core::cmp::Ord#lexicographical-comparison).
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialOrd, A: Allocator> PartialOrd for Vec<T, A> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        PartialOrd::partial_cmp(&**self, &**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Eq, A: Allocator> Eq for Vec<T, A> {}

/// Ngleksanakake pesen vectors, [lexicographically](core::cmp::Ord#lexicographical-comparison).
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord, A: Allocator> Ord for Vec<T, A> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        Ord::cmp(&**self, &**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T, A: Allocator> Drop for Vec<T, A> {
    fn drop(&mut self) {
        unsafe {
            // gunakake gulung kanggo [T] gunakake irisan mentah kanggo deleng elemen vector minangka jinis sing paling ringkih;
            //
            // bisa ngindhari pitakon validitas ing kasus tartamtu
            ptr::drop_in_place(ptr::slice_from_raw_parts_mut(self.as_mut_ptr(), self.len))
        }
        // RawVec nangani deallocation
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for Vec<T> {
    /// Nggawe `Vec<T>` kosong.
    fn default() -> Vec<T> {
        Vec::new()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug, A: Allocator> fmt::Debug for Vec<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> AsRef<Vec<T, A>> for Vec<T, A> {
    fn as_ref(&self) -> &Vec<T, A> {
        self
    }
}

#[stable(feature = "vec_as_mut", since = "1.5.0")]
impl<T, A: Allocator> AsMut<Vec<T, A>> for Vec<T, A> {
    fn as_mut(&mut self) -> &mut Vec<T, A> {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> AsRef<[T]> for Vec<T, A> {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "vec_as_mut", since = "1.5.0")]
impl<T, A: Allocator> AsMut<[T]> for Vec<T, A> {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> From<&[T]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: &[T]) -> Vec<T> {
        s.to_vec()
    }
    #[cfg(test)]
    fn from(s: &[T]) -> Vec<T> {
        crate::slice::to_vec(s, Global)
    }
}

#[stable(feature = "vec_from_mut", since = "1.19.0")]
impl<T: Clone> From<&mut [T]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: &mut [T]) -> Vec<T> {
        s.to_vec()
    }
    #[cfg(test)]
    fn from(s: &mut [T]) -> Vec<T> {
        crate::slice::to_vec(s, Global)
    }
}

#[stable(feature = "vec_from_array", since = "1.44.0")]
impl<T, const N: usize> From<[T; N]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: [T; N]) -> Vec<T> {
        <[T]>::into_vec(box s)
    }
    #[cfg(test)]
    fn from(s: [T; N]) -> Vec<T> {
        crate::slice::into_vec(box s)
    }
}

#[stable(feature = "vec_from_cow_slice", since = "1.14.0")]
impl<'a, T> From<Cow<'a, [T]>> for Vec<T>
where
    [T]: ToOwned<Owned = Vec<T>>,
{
    fn from(s: Cow<'a, [T]>) -> Vec<T> {
        s.into_owned()
    }
}

// note: tes narik libstd, sing nyebabake kesalahan ing kene
#[cfg(not(test))]
#[stable(feature = "vec_from_box", since = "1.18.0")]
impl<T, A: Allocator> From<Box<[T], A>> for Vec<T, A> {
    fn from(s: Box<[T], A>) -> Self {
        let len = s.len();
        Self { buf: RawVec::from_box(s), len }
    }
}

// note: tes narik libstd, sing nyebabake kesalahan ing kene
#[cfg(not(test))]
#[stable(feature = "box_from_vec", since = "1.20.0")]
impl<T, A: Allocator> From<Vec<T, A>> for Box<[T], A> {
    fn from(v: Vec<T, A>) -> Self {
        v.into_boxed_slice()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl From<&str> for Vec<u8> {
    fn from(s: &str) -> Vec<u8> {
        From::from(s.as_bytes())
    }
}

#[stable(feature = "array_try_from_vec", since = "1.48.0")]
impl<T, A: Allocator, const N: usize> TryFrom<Vec<T, A>> for [T; N] {
    type Error = Vec<T, A>;

    /// Entuk kabeh konten `Vec<T>` minangka larik, yen ukurane cocog persis karo larik sing dijaluk.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::convert::TryInto;
    /// assert_eq!(vec![1, 2, 3].try_into(), Ok([1, 2, 3]));
    /// assert_eq!(<Vec<i32>>::new().try_into(), Ok([]));
    /// ```
    ///
    /// Yen dawane ora cocog, input bakal bali ing `Err`:
    ///
    /// ```
    /// use std::convert::TryInto;
    /// let r: Result<[i32; 4], _> = (0..10).collect::<Vec<_>>().try_into();
    /// assert_eq!(r, Err(vec![0, 1, 2, 3, 4, 5, 6, 7, 8, 9]));
    /// ```
    ///
    /// Yen ora apa-apa mung entuk prefiks `Vec<T>`, sampeyan bisa nelpon [`.truncate(N)`](Vec::truncate) luwih dhisik.
    ///
    /// ```
    /// use std::convert::TryInto;
    /// let mut v = String::from("hello world").into_bytes();
    /// v.sort();
    /// v.truncate(2);
    /// let [a, b]: [_; 2] = v.try_into().unwrap();
    /// assert_eq!(a, b' ');
    /// assert_eq!(b, b'd');
    /// ```
    fn try_from(mut vec: Vec<T, A>) -> Result<[T; N], Vec<T, A>> {
        if vec.len() != N {
            return Err(vec);
        }

        // SAFETY: `.set_len(0)` mesthi apik.
        unsafe { vec.set_len(0) };

        // SAFETY: A: pitunjuk Vec` kang tansah didadekake siji mlaku, lan
        // alignment sing dibutuhake array padha karo item.
        // We dicenthang sadurungé sing duwe item cekap.
        // Barang kasebut ora bakal tikel kaping pindho amarga `set_len` ngandhani `Vec` supaya ora uga nyelehake.
        //
        let array = unsafe { ptr::read(vec.as_ptr() as *const [T; N]) };
        Ok(array)
    }
}