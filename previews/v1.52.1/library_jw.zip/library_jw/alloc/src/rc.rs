//! Titik referensi-ngetung referensi Utas.'Rc' tegese 'Referensi
//! Counted'.
//!
//! Tipe [`Rc<T>`][`Rc`] nyedhiyakake pamilikan bareng kanggo jinis `T`, dialokasikan ing tumpukan.
//! Nganggo [`clone`][clone] ing [`Rc`] ngasilake pitunjuk anyar kanggo alokasi sing padha ing tumpukan.
//! Nalika penunjuk [`Rc`] pungkasan menyang alokasi tartamtu bakal rusak, regane sing disimpen ing alokasi kasebut (asring diarani "inner value") uga bakal mudhun.
//!
//! Referensi sing dituduhake ing Rust ora ngidini mutasi kanthi standar, lan [`Rc`] ora ana sing istimewane: sampeyan umume ora bisa entuk referensi sing bisa diowahi kanggo [`Rc`].
//! Yen sampeyan butuh mutasi, lebokake [`Cell`] utawa [`RefCell`] ing [`Rc`];ndeleng [an example of mutability inside an `Rc`][mutability].
//!
//! [`Rc`] nggunakake ngetang referensi non-atom.
//! Iki tegese overhead kurang banget, nanging [`Rc`] ora bisa dikirim ing antarane utas, lan akibate [`Rc`] ora ngetrapake [`Send`][send].
//! Akibate, kompilator Rust bakal mriksa *ing wektu kompilasi* yen sampeyan ora ngirim [`Rc`] ing antarane utas.
//! Yen sampeyan butuh ngetang referensi atom kanthi multi-utas, gunakake [`sync::Arc`][arc].
//!
//! Cara [`downgrade`][downgrade] bisa digunakake kanggo nggawe pointer [`Weak`] sing ora duwe.
//! Penunjuk [`Weak`] bisa dadi [`upgrade`][upgrade] d menyang [`Rc`], nanging iki bakal ngasilake [`None`] yen nilai sing disimpen ing alokasi wis mudhun.
//! Kanthi tembung liyane, petunjuk `Weak` ora tetep njaga nilai ing alokasi kasebut;Nanging, dheweke * tetep njaga alokasi (toko cadangan kanggo nilai batin) supaya tetep urip.
//!
//! Siklus ing antarane petunjuk [`Rc`] ora bakal bisa ditanggepi.
//! Amarga iku, [`Weak`] digunakake kanggo ngilangi siklus.
//! Contone, wit bisa duwe petunjuk [`Rc`] sing kuat saka simpul induk nganti bocah, lan petunjuk [`Weak`] saka bocah bali menyang wong tuwa.
//!
//! `Rc<T>` kanthi otomatis ngilangi referensi menyang `T` (liwat [`Deref`] trait), supaya sampeyan bisa nelpon cara `T` kanthi nilai jinis [`Rc<T>`][`Rc`].
//! Kanggo ngindhari bentrokan jeneng karo metode `T`, metode [`Rc<T>`][`Rc`] dhewe minangka fungsi sing gegandhengan, diarani nggunakake [fully qualified syntax]:
//!
//! ```
//! use std::rc::Rc;
//!
//! let my_rc = Rc::new(());
//! Rc::downgrade(&my_rc);
//! ```
//!
//! `Rc<T>Implementasine traits kaya `Clone` bisa uga diarani nggunakake sintaks kualifikasi.
//! Sawetara wong seneng nggunakake sintaks sing nduweni kualifikasi, dene sing liyane seneng nggunakake sintaks-panggilan metode.
//!
//! ```
//! use std::rc::Rc;
//!
//! let rc = Rc::new(());
//! // Sintaks metode-call
//! let rc2 = rc.clone();
//! // Sintaks sing nduweni kualifikasi
//! let rc3 = Rc::clone(&rc);
//! ```
//!
//! [`Weak<T>`][`Weak`] ora otomatis ngilangi `T`, amarga nilai batin bisa uga wis mudhun.
//!
//! # Referensi kloning
//!
//! Nggawe referensi anyar kanggo alokasi sing padha karo pitunjuk referensi sing wis ana rampung nggunakake `Clone` trait sing diterapake kanggo [`Rc<T>`][`Rc`] lan [`Weak<T>`][`Weak`].
//!
//!
//! ```
//! use std::rc::Rc;
//!
//! let foo = Rc::new(vec![1.0, 2.0, 3.0]);
//! // Kaloro sintaks ing ngisor iki padha.
//! let a = foo.clone();
//! let b = Rc::clone(&foo);
//! // a lan b loro nuduhake lokasi memori sing padha karo foo.
//! ```
//!
//! Sintaks `Rc::clone(&from)` minangka idiomatik sing paling idiomatis amarga luwih jelas babagan makna kode kasebut.
//! Ing conto ing ndhuwur, sintaks iki luwih gampang kanggo ndeleng manawa kode iki nggawe referensi anyar tinimbang nyalin kabeh konten foo.
//!
//! # Examples
//!
//! Coba skenario ing endi set `Gadget` diduweni dening `Owner` tartamtu.
//! Kita pengin nuduhake `Gadget`s menyang `Owner`.Kita ora bisa nindakake iki kanthi kepemilikan unik, amarga luwih saka siji gadget kalebu ing `Owner` sing padha.
//! [`Rc`] ngidini kita nuduhake `Owner` ing antarane macem-macem `Gadget`s, lan supaya `Owner` tetep dialokasikan anggere `Gadget` nuduhake.
//!
//! ```
//! use std::rc::Rc;
//!
//! struct Owner {
//!     name: String,
//!     // ... lapangan liyane
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... lapangan liyane
//! }
//!
//! fn main() {
//!     // Gawe referensi sing dietung `Owner`.
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!         }
//!     );
//!
//!     // Gawe `Gadget` duweke `gadget_owner`.
//!     // Kloning `Rc<Owner>` menehi pitunjuk anyar kanggo alokasi `Owner` sing padha, nambah jumlah referensi ing proses kasebut.
//!     //
//!     let gadget1 = Gadget {
//!         id: 1,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!     let gadget2 = Gadget {
//!         id: 2,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!
//!     // Buwang variabel lokal `gadget_owner` kita.
//!     drop(gadget_owner);
//!
//!     // Sanajan ngeculake `gadget_owner`, kita isih bisa nyithak jeneng `Owner` saka `Gadget`s.
//!     // Iki amarga kita mung nyelehake `Rc<Owner>` siji, dudu `Owner` sing dituduhake.
//!     // Anggere `Rc<Owner>` liyane nuduhake alokasi `Owner` sing padha, bakal tetep urip.
//!     // Proyeksi lapangan `gadget1.owner.name` bisa digunakake amarga `Rc<Owner>` kanthi otomatis ngilangi `Owner`.
//!     //
//!     //
//!     println!("Gadget {} owned by {}", gadget1.id, gadget1.owner.name);
//!     println!("Gadget {} owned by {}", gadget2.id, gadget2.owner.name);
//!
//!     // Ing pungkasan fungsi, `gadget1` lan `gadget2` bakal rusak, lan referensi sing dietung pungkasan kanggo `Owner` kita.
//!     // Gadget Man saiki uga bakal musnah.
//!     //
//! }
//! ```
//!
//! Yen sarat diganti, lan kita uga kudu bisa liwat `Owner` nganti `Gadget`, kita bakal nemoni masalah.
//! Penunjuk [`Rc`] saka `Owner` nganti `Gadget` ngenalake siklus.
//! Iki tegese jumlah referensi ora bisa tekan 0, lan alokasi kasebut ora bakal dirusak:
//! bocor memori.Kanggo ngubengi iki, kita bisa nggunakake petunjuk [`Weak`].
//!
//! Rust pancen nggawe sing paling angel nggawe loop iki luwih dhisik.Supaya bisa mungkasi karo rong nilai sing nuduhake siji liyane, salah sijine kudu bisa diowahi.
//! Iki angel amarga [`Rc`] ngetrapake keamanan memori kanthi menehi referensi bareng babagan nilai sing dibungkus, lan iki ora ngidini mutasi langsung.
//! Kita kudu mbungkus bagean saka rega sing pengin diowahi dadi [`RefCell`], sing nyedhiyakake *mutasi interior*: cara kanggo nggayuh mutasi liwat referensi sing dituduhake.
//! [`RefCell`] ngetrapake aturan utang Rust nalika runtime.
//!
//! ```
//! use std::rc::Rc;
//! use std::rc::Weak;
//! use std::cell::RefCell;
//!
//! struct Owner {
//!     name: String,
//!     gadgets: RefCell<Vec<Weak<Gadget>>>,
//!     // ... lapangan liyane
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... lapangan liyane
//! }
//!
//! fn main() {
//!     // Gawe referensi sing dietung `Owner`.
//!     // Elinga yen kita wis nyelehake `Gadget`'s vector saka`Gadget` ing `RefCell` supaya kita bisa mutasi liwat referensi sing dituduhake.
//!     //
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!             gadgets: RefCell::new(vec![]),
//!         }
//!     );
//!
//!     // Gawe `Gadget` duweke `gadget_owner`, kaya sadurunge.
//!     let gadget1 = Rc::new(
//!         Gadget {
//!             id: 1,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!     let gadget2 = Rc::new(
//!         Gadget {
//!             id: 2,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!
//!     // Tambah `Gadget`s menyang `Owner`.
//!     {
//!         let mut gadgets = gadget_owner.gadgets.borrow_mut();
//!         gadgets.push(Rc::downgrade(&gadget1));
//!         gadgets.push(Rc::downgrade(&gadget2));
//!
//!         // `RefCell` utang dinamis mungkasi ing kene.
//!     }
//!
//!     // Ngelingi `Gadget` kita, nyithak rinciane.
//!     for gadget_weak in gadget_owner.gadgets.borrow().iter() {
//!
//!         // `gadget_weak` yaiku `Weak<Gadget>`.
//!         // Amarga petunjuk `Weak` ora bisa njamin yen alokasi isih ana, kita kudu nelpon `upgrade`, sing ngasilake `Option<Rc<Gadget>>`.
//!         //
//!         //
//!         // Ing kasus iki, kita ngerti alokasi isih ana, mula kita mung `unwrap` `Option`.
//!         // Ing program sing luwih rumit, sampeyan bisa uga kudu nangani kesalahan nalika `None`.
//!         //
//!
//!         let gadget = gadget_weak.upgrade().unwrap();
//!         println!("Gadget {} owned by {}", gadget.id, gadget.owner.name);
//!     }
//!
//!     // Ing pungkasan fungsi, `gadget_owner`, `gadget1`, lan `gadget2` dirusak.
//!     // Saiki ora ana petunjuk (`Rc`) sing kuat kanggo gadget, mula bakal rusak.
//!     // Iki dadi angka referensi ing Gadget Man, mula dheweke uga bakal musnah.
//!     //
//! }
//! ```
//!
//! [clone]: Clone::clone
//! [`Cell`]: core::cell::Cell
//! [`RefCell`]: core::cell::RefCell
//! [send]: core::marker::Send
//! [arc]: crate::sync::Arc
//! [`Deref`]: core::ops::Deref
//! [downgrade]: Rc::downgrade
//! [upgrade]: Weak::upgrade
//! [mutability]: core::cell#introducing-mutability-inside-of-something-immutable
//! [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[cfg(not(test))]
use crate::boxed::Box;
#[cfg(test)]
use std::boxed::Box;

use core::any::Any;
use core::borrow;
use core::cell::Cell;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::abort;
use core::iter;
use core::marker::{self, PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, forget, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

// Iki minangka bukti repr(C) nganti future tumrap panyuntingan lapangan sing bisa uga, sing bakal ngganggu [into|from]_raw() sing aman saka jinis njero sing bisa ditularake.
//
//
#[repr(C)]
struct RcBox<T: ?Sized> {
    strong: Cell<usize>,
    weak: Cell<usize>,
    value: T,
}

/// Pointer referensi-pancacahan referensi siji Utas.'Rc' tegese 'Referensi
/// Counted'.
///
/// Deleng [module-level documentation](./index.html) kanggo rincian liyane.
///
/// Cara `Rc` sing ana gandhengane yaiku kabeh fungsi sing ana gandhengane, tegese sampeyan kudu nyebut kasebut minangka eg, [`Rc::get_mut(&mut value)`][get_mut] tinimbang `value.get_mut()`.
/// Iki ngindhari konflik karo metode jinis `T` batin.
///
/// [get_mut]: Rc::get_mut
///
#[cfg_attr(not(test), rustc_diagnostic_item = "Rc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Rc<T: ?Sized> {
    ptr: NonNull<RcBox<T>>,
    phantom: PhantomData<RcBox<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Send for Rc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Sync for Rc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Rc<U>> for Rc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T> {}

impl<T: ?Sized> Rc<T> {
    #[inline(always)]
    fn inner(&self) -> &RcBox<T> {
        // Ketahanan sing aman iki ora apa-apa amarga Rc isih urip, kita bakal menehi petunjuk manawa petunjuk ing njero bener.
        //
        unsafe { self.ptr.as_ref() }
    }

    fn from_inner(ptr: NonNull<RcBox<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut RcBox<T>) -> Self {
        Self::from_inner(unsafe { NonNull::new_unchecked(ptr) })
    }
}

impl<T> Rc<T> {
    /// Mbangun `Rc<T>` anyar.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(value: T) -> Rc<T> {
        // Ana petunjuk sing ringkih implisit sing diduweni kabeh pitunjuk sing kuwat, sing njamin manawa destruktor sing ringkih ora nate mbebasake alokasi nalika destruktor sing kuwat bisa mlaku, sanajan penunjuk sing lemah disimpen ing njero sing kuwat.
        //
        //
        //
        Self::from_inner(
            Box::leak(box RcBox { strong: Cell::new(1), weak: Cell::new(1), value }).into(),
        )
    }

    /// Mbangun `Rc<T>` anyar kanthi nggunakake referensi sing ringkih.
    /// Upaya nganyari referensi sing ringkih sadurunge fungsi iki ngasilake bakal ngasilake nilai `None`.
    ///
    /// Nanging, referensi sing ringkih bisa dikloning kanthi bebas lan disimpen kanggo digunakake mengko wektu.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Gadget {
    ///     self_weak: Weak<Self>,
    ///     // ... lapangan liyane
    /// }
    /// impl Gadget {
    ///     pub fn new() -> Rc<Self> {
    ///         Rc::new_cyclic(|self_weak| {
    ///             Gadget { self_weak: self_weak.clone(), /* ... */ }
    ///         })
    ///     }
    /// }
    /// ```
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Rc<T> {
        // Mbangun bagian jero ing negara "uninitialized" kanthi siji referensi sing ringkih.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box RcBox {
            strong: Cell::new(0),
            weak: Cell::new(1),
            value: mem::MaybeUninit::<T>::uninit(),
        })
        .into();

        let init_ptr: NonNull<RcBox<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // Penting, kita aja nyerah kepemilikan pitunjuk sing ringkih, utawa memori bisa uga dibebasake nalika `data_fn` bali.
        // Yen pancene pengin ngliwati kepemilikan, kita bisa nggawe petunjuk tambahan sing ringkih kanggo awake dhewe, nanging iki bakal nyebabake tambahan nganyari jumlah referensi sing ringkih sing bisa uga ora perlu.
        //
        //
        //
        //
        let data = data_fn(&weak);

        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).value), data);

            let prev_value = (*inner).strong.get();
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
            (*inner).strong.set(1);
        }

        let strong = Rc::from_inner(init_ptr);

        // Referensi sing kuat kudu duwe referensi sing ringkes bareng, mula aja ngrusak kanggo referensi lawas sing ringkih.
        //
        mem::forget(weak);
        strong
    }

    /// Mbangun `Rc` anyar kanthi konten sing durung diresmine.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Inisialisasi sing ditundha:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Mbangun `Rc` anyar kanthi konten sing durung diresmine, kanthi memori diisi karo bait `0`.
    ///
    ///
    /// Deleng [`MaybeUninit::zeroed`][zeroed] kanggo conto panggunaan metode sing bener lan salah.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Mbangun `Rc<T>` anyar, ngasilake kesalahan yen alokasi gagal
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::rc::Rc;
    ///
    /// let five = Rc::try_new(5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn try_new(value: T) -> Result<Rc<T>, AllocError> {
        // Ana petunjuk sing ringkih implisit sing diduweni kabeh pitunjuk sing kuwat, sing njamin manawa destruktor sing ringkih ora nate mbebasake alokasi nalika destruktor sing kuwat bisa mlaku, sanajan penunjuk sing lemah disimpen ing njero sing kuwat.
        //
        //
        //
        Ok(Self::from_inner(
            Box::leak(Box::try_new(RcBox { strong: Cell::new(1), weak: Cell::new(1), value })?)
                .into(),
        ))
    }

    /// Mbangun `Rc` anyar kanthi konten sing durung diresmine, ngasilake kesalahan yen alokasi gagal
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // Inisialisasi sing ditundha:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// Mbangun `Rc` anyar kanthi konten sing ora diresmine, kanthi memori diisi byte `0`, ngasilake kesalahan yen alokasi gagal
    ///
    ///
    /// Deleng [`MaybeUninit::zeroed`][zeroed] kanggo conto panggunaan metode sing bener lan salah.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// Mbangun `Pin<Rc<T>>` anyar.
    /// Yen `T` ora ngetrapake `Unpin`, mula `value` bakal disematake ing memori lan ora bisa dipindhah.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(value: T) -> Pin<Rc<T>> {
        unsafe { Pin::new_unchecked(Rc::new(value)) }
    }

    /// Ngasilake nilai batin, yen `Rc` duwe siji referensi sing kuat.
    ///
    /// Yen ora, [`Err`] bakal bali kanthi `Rc` sing padha dilewati.
    ///
    ///
    /// Iki bakal sukses sanajan ana referensi sing ringkih.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new(3);
    /// assert_eq!(Rc::try_unwrap(x), Ok(3));
    ///
    /// let x = Rc::new(4);
    /// let _y = Rc::clone(&x);
    /// assert_eq!(*Rc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if Rc::strong_count(&this) == 1 {
            unsafe {
                let val = ptr::read(&*this); // salin obyek sing ana

                // Tandha yen Lemah ora bisa dipromosikake kanthi nyuda jumlah sing kuwat, lan banjur mbusak pitunjuk "strong weak" sing implisit nalika uga nangani logika gulung kanthi nggawe Lemah palsu.
                //
                //
                //
                this.inner().dec_strong();
                let _weak = Weak { ptr: this.ptr };
                forget(this);
                Ok(val)
            }
        } else {
            Err(this)
        }
    }
}

impl<T> Rc<[T]> {
    /// Mbangun irisan sing dietung referensi sing anyar kanthi konten sing durung diresmine.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Inisialisasi sing ditundha:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe { Rc::from_ptr(Rc::allocate_for_slice(len)) }
    }

    /// Mbangun irisan sing diitung kanthi referensi anyar kanthi konten sing durung diresmine, kanthi memori diisi karo bait `0`.
    ///
    ///
    /// Deleng [`MaybeUninit::zeroed`][zeroed] kanggo conto panggunaan metode sing bener lan salah.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let values = Rc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut RcBox<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Rc<mem::MaybeUninit<T>> {
    /// Ngonversi menyang `Rc<T>`.
    ///
    /// # Safety
    ///
    /// Kaya ing [`MaybeUninit::assume_init`], dadi panelpon kanggo njamin manawa bathi tenan ana ing negara sing diwiwiti.
    ///
    /// Nelpon iki nalika konten durung diwiwiti kanthi otomatis nyebabake prilaku sing durung ditemtokake langsung.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Inisialisasi sing ditundha:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<T> {
        Rc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Rc<[mem::MaybeUninit<T>]> {
    /// Ngonversi menyang `Rc<[T]>`.
    ///
    /// # Safety
    ///
    /// Kaya ing [`MaybeUninit::assume_init`], dadi panelpon kanggo njamin manawa bathi tenan ana ing negara sing diwiwiti.
    ///
    /// Nelpon iki nalika konten durung diwiwiti kanthi otomatis nyebabake prilaku sing durung ditemtokake langsung.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Inisialisasi sing ditundha:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<[T]> {
        unsafe { Rc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Rc<T> {
    /// Nganggo `Rc`, ngasilake pitunjuk sing dibungkus.
    ///
    /// Kanggo ngindhari bocor memori, pointer kudu diowahi dadi `Rc` nggunakake [`Rc::from_raw`][from_raw].
    ///
    ///
    /// [from_raw]: Rc::from_raw
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// Nyedhiyakake pitunjuk mentah kanggo data.
    ///
    /// Jumlah ora kena pengaruh ing sembarang cara lan `Rc` ora dikonsumsi.
    /// Pointer bener yen ana jumlah sing kuwat ing `Rc`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let y = Rc::clone(&x);
    /// let x_ptr = Rc::as_ptr(&x);
    /// assert_eq!(x_ptr, Rc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(this.ptr);

        // SAFETY: Iki ora bisa dilewati Deref::deref utawa Rc::inner amarga
        // iki dibutuhake kanggo njaga bukti asli raw/mut, kayata
        // `get_mut` bisa nulis liwat pointer sawise Rc dibalekake liwat `from_raw`.
        unsafe { ptr::addr_of_mut!((*ptr).value) }
    }

    /// Mbangun `Rc<T>` saka pitunjuk mentah.
    ///
    /// Pointer mentah kudu sadurunge bali nganggo telpon menyang [`Rc<U>::into_raw`][into_raw] ing endi `U` kudu duwe ukuran lan jajaran sing padha karo `T`.
    /// Iki pancen sepele yen `U` yaiku `T`.
    /// Elinga yen `U` dudu `T` nanging nduweni ukuran lan jajaran sing padha, iki biasane kaya referensi transmisi saka macem-macem jinis.
    /// Deleng [`mem::transmute`][transmute] kanggo informasi luwih lengkap babagan watesan apa sing ditrapake ing kasus iki.
    ///
    /// Pangguna `from_raw` kudu nggawe manawa nilai tartamtu `T` mung ambruk sapisan.
    ///
    /// Fungsi iki ora aman amarga panggunaan sing ora bener bisa nyebabake memori ora aman, sanajan `Rc<T>` bali ora nate diakses.
    ///
    /// [into_raw]: Rc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    ///
    /// unsafe {
    ///     // Ngonversi maneh menyang `Rc` kanggo nyegah bocor.
    ///     let x = Rc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // Telpon maneh menyang `Rc::from_raw(x_ptr)` bakal ora aman ing memori.
    /// }
    ///
    /// // Memori dibebasake nalika `x` metu saka ruang lingkup ing ndhuwur, mula `x_ptr` saiki lagi nggantung!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        let offset = unsafe { data_offset(ptr) };

        // Mundur offset kanggo nemokake RcBox asli.
        let rc_ptr =
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) };

        unsafe { Self::from_ptr(rc_ptr) }
    }

    /// Nggawe penunjuk [`Weak`] anyar kanggo alokasi iki.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        this.inner().inc_weak();
        // Priksa manawa kita ora nggawe Lemah sing mudhun
        debug_assert!(!is_dangling(this.ptr.as_ptr()));
        Weak { ptr: this.ptr }
    }

    /// Entuk jumlah petunjuk [`Weak`] menyang alokasi iki.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _weak_five = Rc::downgrade(&five);
    ///
    /// assert_eq!(1, Rc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        this.inner().weak() - 1
    }

    /// Entuk jumlah petunjuk (`Rc`) sing kuwat kanggo alokasi iki.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _also_five = Rc::clone(&five);
    ///
    /// assert_eq!(2, Rc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong()
    }

    /// Ngasilake `true` yen ora ana petunjuk `Rc` utawa [`Weak`] liyane kanggo alokasi iki.
    ///
    #[inline]
    fn is_unique(this: &Self) -> bool {
        Rc::weak_count(this) == 0 && Rc::strong_count(this) == 1
    }

    /// Ngasilake referensi sing bisa diowahi dadi `Rc` sing diwenehake, yen ora ana petunjuk `Rc` utawa [`Weak`] liyane menyang alokasi sing padha.
    ///
    ///
    /// Yen ngasilake [`None`], amarga ora aman kanggo mutasi nilai sing dituduhake.
    ///
    /// Deleng uga [`make_mut`][make_mut], sing bakal [`clone`][clone] regane batin yen ana petunjuk liyane.
    ///
    /// [make_mut]: Rc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(3);
    /// *Rc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Rc::clone(&x);
    /// assert!(Rc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if Rc::is_unique(this) { unsafe { Some(Rc::get_mut_unchecked(this)) } } else { None }
    }

    /// Ngasilake referensi sing bisa diowahi menyang `Rc` tartamtu, tanpa mriksa.
    ///
    /// Deleng uga [`get_mut`], sing aman lan uga mriksa sing cocog.
    ///
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Safety
    ///
    /// Petunjuk `Rc` utawa [`Weak`] liyane sing padha karo alokasi sing padha ora kudu dibebasake sajrone utang sing bali.
    ///
    /// Iki pancen sepele yen ora ana petunjuk, kayata sanalika sawise `Rc::new`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(String::new());
    /// unsafe {
    ///     Rc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // Kita ati-ati supaya *ora* nggawe referensi sing nyakup lapangan "count", amarga iki bakal beda karo akses menyang jumlah referensi (eg
        // dening `Weak`).
        unsafe { &mut (*this.ptr.as_ptr()).value }
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// Ngasilake `true` yen loro `Rc` nuduhake alokasi sing padha (kanthi urat padha karo [`ptr::eq`]).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let same_five = Rc::clone(&five);
    /// let other_five = Rc::new(5);
    ///
    /// assert!(Rc::ptr_eq(&five, &same_five));
    /// assert!(!Rc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: Clone> Rc<T> {
    /// Nggawe referensi sing bisa diowahi dadi `Rc` sing diwenehake.
    ///
    /// Yen ana petunjuk `Rc` liyane ing alokasi sing padha, mula `make_mut` bakal [`clone`] nilai batin menyang alokasi anyar kanggo njamin kepemilikan unik.
    /// Iki uga diarani klon-on-nulis.
    ///
    /// Yen ora ana petunjuk `Rc` liyane kanggo alokasi iki, mula pitunjuk [`Weak`] kanggo alokasi iki bakal dipisahake.
    ///
    /// Deleng uga [`get_mut`], sing bakal gagal tinimbang kloning.
    ///
    /// [`clone`]: Clone::clone
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(5);
    ///
    /// *Rc::make_mut(&mut data) += 1;        // Ora bakal Klone apa-apa
    /// let mut other_data = Rc::clone(&data);    // Ora bakal kloning data njero
    /// *Rc::make_mut(&mut data) += 1;        // Data njero klon
    /// *Rc::make_mut(&mut data) += 1;        // Ora bakal Klone apa-apa
    /// *Rc::make_mut(&mut other_data) *= 2;  // Ora bakal Klone apa-apa
    ///
    /// // Saiki `data` lan `other_data` nuduhake alokasi sing beda.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    /// [`Weak`] pointer bakal dipisahake:
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(75);
    /// let weak = Rc::downgrade(&data);
    ///
    /// assert!(75 == *data);
    /// assert!(75 == *weak.upgrade().unwrap());
    ///
    /// *Rc::make_mut(&mut data) += 1;
    ///
    /// assert!(76 == *data);
    /// assert!(weak.upgrade().is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        if Rc::strong_count(this) != 1 {
            // Kudu kloning data, ana liyane Rcs.
            // Memori alokasi sadurunge kanggo ngidini nulis nilai kloning kanthi langsung.
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = rc.assume_init();
            }
        } else if Rc::weak_count(this) != 0 {
            // Mung bisa nyolong data, sing isih ana yaiku Weaks
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);

                this.inner().dec_strong();
                // Copot ref sing kuwat banget (ora prelu nggawe Lemah palsu ing kene-kita ngerti manawa Lemah liyane bisa ngresiki awake dhewe)
                //
                this.inner().dec_weak();
                ptr::write(this, rc.assume_init());
            }
        }
        // Ketahanan sing aman iki ora apa-apa amarga kita dijamin manawa pitunjuk sing dibalekake minangka siji-sijine * petunjuk sing bakal bali menyang T.
        // Jumlah referensi dijamin 1 ing wektu iki, lan kita mbutuhake `Rc<T>` dhewe dadi `mut`, mula kita bakal bali mung referensi alokasi kasebut.
        //
        //
        //
        unsafe { &mut this.ptr.as_mut().value }
    }
}

impl Rc<dyn Any> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// Coba downcast `Rc<dyn Any>` dadi jinis konkrit.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::rc::Rc;
    ///
    /// fn print_if_string(value: Rc<dyn Any>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Rc::new(my_string));
    /// print_if_string(Rc::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Rc<T>, Rc<dyn Any>> {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<RcBox<T>>();
            forget(self);
            Ok(Rc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T: ?Sized> Rc<T> {
    /// Alokasi `RcBox<T>` kanthi papan sing cukup kanggo nilai batin sing bisa diukur yen regane wis diwenehake.
    ///
    /// Fungsi `mem_to_rcbox` diarani nganggo data pointer lan kudu mbalekake (berpotensi lemu)-pointer kanggo `RcBox<T>`.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> *mut RcBox<T> {
        // Ngetung tata letak nggunakake tata letak nilai sing diwenehake.
        // Sadurunge, tata letak diitung ing ekspresi `&*(ptr as* const RcBox<T>)`, nanging iki nggawe referensi sing salah (deleng #54908).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Rc::try_allocate_for_layout(value_layout, allocate, mem_to_rcbox)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// Alokasi `RcBox<T>` kanthi papan sing cukup kanggo nilai batin sing bisa diukur yen regane wis diwenehi tata letak, ngasilake kesalahan yen alokasi gagal.
    ///
    ///
    /// Fungsi `mem_to_rcbox` diarani nganggo data pointer lan kudu mbalekake (berpotensi lemu)-pointer kanggo `RcBox<T>`.
    ///
    ///
    #[inline]
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> Result<*mut RcBox<T>, AllocError> {
        // Ngetung tata letak nggunakake tata letak nilai sing diwenehake.
        // Sadurunge, tata letak diitung ing ekspresi `&*(ptr as* const RcBox<T>)`, nanging iki nggawe referensi sing salah (deleng #54908).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();

        // Alokasi kanggo tata letak.
        let ptr = allocate(layout)?;

        // Initialisasi RcBox
        let inner = mem_to_rcbox(ptr.as_non_null_ptr().as_ptr());
        unsafe {
            debug_assert_eq!(Layout::for_value(&*inner), layout);

            ptr::write(&mut (*inner).strong, Cell::new(1));
            ptr::write(&mut (*inner).weak, Cell::new(1));
        }

        Ok(inner)
    }

    /// Alokasi `RcBox<T>` kanthi papan sing cukup kanggo nilai batin sing durung diukur
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut RcBox<T> {
        // Alokasi `RcBox<T>` nggunakake nilai sing diwenehake.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut RcBox<T>).set_ptr_value(mem),
            )
        }
    }

    fn from_box(v: Box<T>) -> Rc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // Nilai salinan minangka bait
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).value as *mut _ as *mut u8,
                value_size,
            );

            // Gratisake alokasi kasebut tanpa ngeculake isine
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Rc<[T]> {
    /// Alokasi `RcBox<[T]>` kanthi dawa sing diwenehake.
    unsafe fn allocate_for_slice(len: usize) -> *mut RcBox<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut RcBox<[T]>,
            )
        }
    }

    /// Salin elemen saka irisan menyang Rc <\[T\]> sing mentas dialokasikan
    ///
    /// Ora aman amarga panelpon kudu duwe kepemilikan utawa obligasi `T: Copy`
    unsafe fn copy_from_slice(v: &[T]) -> Rc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());
            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).value as *mut [T] as *mut T, v.len());
            Self::from_ptr(ptr)
        }
    }

    /// Mbangun `Rc<[T]>` saka iterator sing dingerteni ukuran tartamtu.
    ///
    /// Prilaku ora bisa ditemtokake manawa ukurane salah.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Rc<[T]> {
        // Panic njaga nalika kloning elemen T.
        // Yen ana panic, elemen sing wis ditulis menyang RcBox anyar bakal mudhun, banjur memori dibebasake.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // Pointer kanggo elemen pisanan
            let elems = &mut (*ptr).value as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // Kabeh jelas.Lali njaga supaya ora mbebasake RcBox anyar.
            forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// Spesialisasi trait digunakake kanggo `From<&[T]>`.
trait RcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Rc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Rc<T> {
    type Target = T;

    #[inline(always)]
    fn deref(&self) -> &T {
        &self.inner().value
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Rc<T> {
    /// Nyelehake `Rc`.
    ///
    /// Iki bakal nyuda jumlah referensi sing kuwat.
    /// Yen jumlah referensi sing kuwat tekan nol, mula referensi liyane (yen ana) yaiku [`Weak`], mula kita bakal entuk nilai batin ing `drop`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Rc::new(Foo);
    /// let foo2 = Rc::clone(&foo);
    ///
    /// drop(foo);    // Ora nyithak apa-apa
    /// drop(foo2);   // Nyithak "dropped!"
    /// ```
    fn drop(&mut self) {
        unsafe {
            self.inner().dec_strong();
            if self.inner().strong() == 0 {
                // ngrusak obyek sing ana
                ptr::drop_in_place(Self::get_mut_unchecked(self));

                // mbusak pointer "strong weak" sing implisit saiki wis ngrusak konten.
                //
                self.inner().dec_weak();

                if self.inner().weak() == 0 {
                    Global.deallocate(self.ptr.cast(), Layout::for_value(self.ptr.as_ref()));
                }
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Rc<T> {
    /// Nggawe klon penunjuk `Rc`.
    ///
    /// Iki nggawe penunjuk liyane menyang alokasi sing padha, nambah jumlah referensi sing kuwat.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let _ = Rc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Rc<T> {
        self.inner().inc_strong();
        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Rc<T> {
    /// Nggawe `Rc<T>` anyar, kanthi nilai `Default` kanggo `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x: Rc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    #[inline]
    fn default() -> Rc<T> {
        Rc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait RcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Rc<T>) -> bool;
    fn ne(&self, other: &Rc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    default fn eq(&self, other: &Rc<T>) -> bool {
        **self == **other
    }

    #[inline]
    default fn ne(&self, other: &Rc<T>) -> bool {
        **self != **other
    }
}

// Hack kanggo ngidini spesialisasi ing `Eq` sanajan `Eq` duwe metode.
#[rustc_unsafe_specialization_marker]
pub(crate) trait MarkerEq: PartialEq<Self> {}

impl<T: Eq> MarkerEq for T {}

/// Kita nindakake spesialisasi iki ing kene, lan dudu ngoptimalake `&T` sing luwih umum, amarga bakal nambah biaya kanggo kabeh priksa kesetaraan ing ref.
/// Kita nganggep manawa `Rc` digunakake kanggo nyimpen nilai sing akeh, sing klone alon, nanging uga angel kanggo mriksa kesetaraan, saengga biaya iki bisa mbayar kanthi luwih gampang.
///
/// Sampeyan uga luwih cenderung duwe rong klon `Rc`, sing nuduhake regane padha, tinimbang loro `&T`s.
///
/// Kita mung bisa nindakake iki nalika `T: Eq` minangka `PartialEq` bisa uga sengaja ora sopan.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + MarkerEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        Rc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        !Rc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Rc<T> {
    /// Kesetaraan kanggo rong `Rc`s.
    ///
    /// Rong `Rc` padha yen regane batin padha, sanajan disimpen ing alokasi sing beda.
    ///
    /// Yen `T` uga ngetrapake `Eq` (tegese refleksivitas kesetaraan), loro `Rc` sing nuduhake alokasi sing padha mesthi padha.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five == Rc::new(5));
    /// ```
    ///
    ///
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        RcEqIdent::eq(self, other)
    }

    /// Ketimpangan kanggo rong `Rc`s.
    ///
    /// Rong `Rc` ora padha yen regane batin ora padha.
    ///
    /// Yen `T` uga ngetrapake `Eq` (tegese refleksivitas kesetaraan), loro `Rc` sing nuduhake alokasi sing padha ora bakal padha.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five != Rc::new(6));
    /// ```
    ///
    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        RcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Rc<T> {
    /// Bandhing parsial kanggo rong `Rc`s.
    ///
    /// Kalorone dibandhingake kanthi nyebut `partial_cmp()` ing nilai batin.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Rc::new(6)));
    /// ```
    #[inline(always)]
    fn partial_cmp(&self, other: &Rc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// Perbandingan sing kurang saka rong rc`s.
    ///
    /// Kalorone dibandhingake kanthi nyebut `<` ing nilai batin.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five < Rc::new(6));
    /// ```
    #[inline(always)]
    fn lt(&self, other: &Rc<T>) -> bool {
        **self < **other
    }

    /// 'Kurang saka utawa padha karo' perbandingan kanggo rong `Rc`s.
    ///
    /// Kalorone dibandhingake kanthi nyebut `<=` ing nilai batin.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five <= Rc::new(5));
    /// ```
    #[inline(always)]
    fn le(&self, other: &Rc<T>) -> bool {
        **self <= **other
    }

    /// Perbandingan sing luwih gedhe tinimbang rong Rc`s.
    ///
    /// Kalorone dibandhingake kanthi nyebut `>` ing nilai batin.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five > Rc::new(4));
    /// ```
    #[inline(always)]
    fn gt(&self, other: &Rc<T>) -> bool {
        **self > **other
    }

    /// 'Luwih gedhe utawa padha karo' perbandingan kanggo rong Rc`s.
    ///
    /// Kalorone dibandhingake kanthi nyebut `>=` ing nilai batin.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five >= Rc::new(5));
    /// ```
    #[inline(always)]
    fn ge(&self, other: &Rc<T>) -> bool {
        **self >= **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Rc<T> {
    /// Comparison for two `Rc`s.
    ///
    /// Kalorone dibandhingake kanthi nyebut `cmp()` ing nilai batin.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Rc::new(6)));
    /// ```
    #[inline]
    fn cmp(&self, other: &Rc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Rc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Rc<T> {
    fn from(t: T) -> Self {
        Rc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Rc<[T]> {
    /// Alokasi irisan sing dietung referensi banjur iseni kanthi kloning item `v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Rc<[i32]> = Rc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Rc<[T]> {
        <Self as RcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Rc<str> {
    /// Alokasi irisan senar sing dietung referensi banjur salin `v` ing kana.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let shared: Rc<str> = Rc::from("statue");
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Rc<str> {
        let rc = Rc::<[u8]>::from(v.as_bytes());
        unsafe { Rc::from_raw(Rc::into_raw(rc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Rc<str> {
    /// Alokasi irisan senar sing dietung referensi banjur salin `v` ing kana.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: String = "statue".to_owned();
    /// let shared: Rc<str> = Rc::from(original);
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Rc<str> {
        Rc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Rc<T> {
    /// Pindhah obyek kothak menyang alokasi referensi sing anyar lan dietung.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<i32> = Box::new(1);
    /// let shared: Rc<i32> = Rc::from(original);
    /// assert_eq!(1, *shared);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Rc<T> {
        Rc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Rc<[T]> {
    /// Alokasi irisan sing dietung referensi banjur pindhah item `v` menyang njero.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<Vec<i32>> = Box::new(vec![1, 2, 3]);
    /// let shared: Rc<Vec<i32>> = Rc::from(original);
    /// assert_eq!(vec![1, 2, 3], *shared);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Rc<[T]> {
        unsafe {
            let rc = Rc::copy_from_slice(&v);

            // Allow Vec kanggo mbebasake memori, nanging aja ngrusak isine
            v.set_len(0);

            rc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Rc<B>
where
    B: ToOwned + ?Sized,
    Rc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Rc<B> {
        match cow {
            Cow::Borrowed(s) => Rc::from(s),
            Cow::Owned(s) => Rc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Rc<[T]>> for Rc<[T; N]> {
    type Error = Rc<[T]>;

    fn try_from(boxed_slice: Rc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Rc::from_raw(Rc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Rc<[T]> {
    /// Nganggo saben elemen ing `Iterator` lan dikumpulake dadi `Rc<[T]>`.
    ///
    /// # Karakteristik kinerja
    ///
    /// ## Kasus umum
    ///
    /// Ing kasus umume, nglumpukake menyang `Rc<[T]>` ditindakake kanthi luwih dhisik nglumpukake menyang `Vec<T>`.Yaiku, nalika nulis ing ngisor iki:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// iki tumindak kaya nalika nulis:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // Kumpulan alokasi pertama kedadeyan ing kene.
    ///     .into(); // Alokasi liya kanggo `Rc<[T]>` kedadeyan ing kene.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// Iki bakal menehi kaping pirang-pirang sing dibutuhake kanggo mbangun `Vec<T>` lan banjur bakal alokasi sapisan kanggo ngowahi `Vec<T>` dadi `Rc<[T]>`.
    ///
    ///
    /// ## Iterator sing dawane dingerteni
    ///
    /// Nalika `Iterator` sampeyan ngetrapake `TrustedLen` lan ukurane pas, alokasi siji bakal digawe kanggo `Rc<[T]>`.Contone:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).collect(); // Mung ana alokasi siji ing kene.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToRcSlice::to_rc_slice(iter.into_iter())
    }
}

/// Spesialisasi trait digunakake kanggo nglumpukake menyang `Rc<[T]>`.
trait ToRcSlice<T>: Iterator<Item = T> + Sized {
    fn to_rc_slice(self) -> Rc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToRcSlice<T> for I {
    default fn to_rc_slice(self) -> Rc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToRcSlice<T> for I {
    fn to_rc_slice(self) -> Rc<[T]> {
        // Iki minangka kasus kanggo iterator `TrustedLen`.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // SAFETY: Kita kudu mesthekake yen iterator duwe dawa sing pas lan saiki wis ana.
                Rc::from_iter_exact(self, low)
            }
        } else {
            // Mbalik maneh menyang implementasi normal.
            self.collect::<Vec<T>>().into()
        }
    }
}

/// `Weak` minangka versi [`Rc`] sing nyekel referensi sing ora duwe alokasi ngatur.Alokasi kasebut diakses kanthi nelpon [`upgrade`] ing pointer `Weak`, sing ngasilake [`Option`]`<`[`Rc`] `<T>>`.
///
/// Amarga referensi `Weak` ora dianggep nduweni, mula ora bakal nyegah regane sing disimpen ing alokasi supaya mudhun, lan `Weak` dhewe ora menehi jaminan babagan nilai sing isih ana.
/// Mangkono bisa ngasilake [`None`] nalika [`upgrade`] d.
/// Nanging, elinga yen referensi `Weak`*ora* nyegah alokasi dhewe (toko cadangan) supaya ora bisa ditanggepi.
///
/// Penunjuk `Weak` migunani kanggo njaga referensi sementara kanggo alokasi sing dikelola dening [`Rc`] tanpa nyegah nilai batin saka mudhun.
/// Iki uga digunakake kanggo nyegah referensi bunder ing antarane pointer [`Rc`], amarga referensi ndhuweni bebarengan ora bakal ngidini [`Rc`] dicopot.
/// Contone, wit bisa duwe petunjuk [`Rc`] sing kuat saka simpul induk nganti bocah, lan petunjuk `Weak` saka bocah bali menyang wong tuwa.
///
/// Cara khas kanggo entuk pointer `Weak` yaiku nelpon [`Rc::downgrade`].
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
///
///
#[stable(feature = "rc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // Iki minangka `NonNull` kanggo ngidini ngoptimalake ukuran jinis iki ing enum, nanging durung mesthi penunjuk sing bener.
    //
    // `Weak::new` setel iki menyang `usize::MAX` supaya ora prelu ngisi ruang ing tumpukan kasebut.
    // Iki dudu nilai sing bakal diduweni pointer nyata amarga RcBox duwe alignment paling ora 2.
    // Iki mung bisa ditindakake nalika `T: Sized`;`T` tanpa ukuran ora tau digantung.
    //
    ptr: NonNull<RcBox<T>>,
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Send for Weak<T> {}
#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

impl<T> Weak<T> {
    /// Mbangun `Weak<T>` anyar, tanpa menehi memori.
    /// Nelpon [`upgrade`] ing rega bali mesthi menehi [`None`].
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut RcBox<T>).expect("MAX is not 0") }
    }
}

pub(crate) fn is_dangling<T: ?Sized>(ptr: *mut T) -> bool {
    let address = ptr as *mut () as usize;
    address == usize::MAX
}

/// Jinis helper kanggo ngidini ngakses jumlah referensi tanpa negesake babagan kolom data.
///
struct WeakInner<'a> {
    weak: &'a Cell<usize>,
    strong: &'a Cell<usize>,
}

impl<T: ?Sized> Weak<T> {
    /// Ngasilake pitunjuk mentah menyang obyek `T` sing dituduhake dening `Weak<T>` iki.
    ///
    /// Pointer mung valid yen ana referensi sing kuat.
    /// Pointer bisa uga nggantung, ora salaras utawa malah [`null`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::ptr;
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// // Kalorone nuduhake obyek sing padha
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // Kuat ing kene tetep urip, mula isih bisa ngakses obyek kasebut.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // Nanging ora ono liyane.
    /// // Kita bisa nindakake weak.as_ptr(), nanging yen ngakses pointer bakal nyebabake tumindak sing durung mesthi.
    /// // assert_eq! ("hello", ora aman {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // Yen penunjuk wis nggantung, kita langsung bali menyang sentinel.
            // Iki ora bisa dadi alamat muatan sing bener, amarga muatan paling ora padha karo RcBox (usize).
            ptr as *const T
        } else {
            // SAFETY: yen_dangling ngasilake salah, mula pitunjuk ora bisa dibatalake.
            // Payload bisa uga diturunake ing titik iki, lan kita kudu njaga bukti, mula nggunakake manipulasi pointer mentah.
            //
            unsafe { ptr::addr_of_mut!((*ptr).value) }
        }
    }

    /// Nganggo `Weak<T>` lan dadi pitunjuk mentah.
    ///
    /// Iki ngowahi pointer sing lemah dadi pitunjuk mentah, nalika isih njaga kepemilikan siji referensi sing lemah (jumlah sing ringkih ora diowahi karo operasi iki).
    /// Bisa diowahi dadi `Weak<T>` nganggo [`from_raw`].
    ///
    /// Watesan sing padha kanggo ngakses target pointer lan [`as_ptr`] ditrapake.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Rc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Rc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// Ngonversi pitunjuk mentah sing sadurunge digawe dening [`into_raw`] bali menyang `Weak<T>`.
    ///
    /// Iki bisa digunakake kanggo entuk referensi sing kuat (kanthi nelpon [`upgrade`] mengko) utawa menehi hasil jumlah sing ringkih kanthi ngeculake `Weak<T>`.
    ///
    /// Sampeyan butuh siji referensi sing ringkih (kajaba petunjuk sing digawe dening [`new`], amarga ora duwe apa-apa; cara isih bisa digunakake).
    ///
    /// # Safety
    ///
    /// Pointer kudu asale saka [`into_raw`] lan isih kudu duwe referensi sing ringkih.
    ///
    /// Jumlah sing diijini luwih saka 0 nalika sampeyan nelpon iki.
    /// Nanging, iki nduweni kepemilikan siji referensi sing ringkih sing saiki diwakili minangka penunjuk mentah (jumlah sing ringkih ora dimodifikasi karo operasi iki) lan mula kudu dipasangake karo [`into_raw`] sadurunge.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    ///
    /// let raw_1 = Rc::downgrade(&strong).into_raw();
    /// let raw_2 = Rc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Rc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Rc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // Ngurangi jumlah sing pungkasan banget.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`new`]: Weak::new
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // Deleng Weak::as_ptr kanggo konteks babagan cara pointer input.

        let ptr = if is_dangling(ptr as *mut T) {
            // Iki minangka Lemah sing nggantung.
            ptr as *mut RcBox<T>
        } else {
            // Yen ora, kita bakal menehi penunjuk yen teka saka Lemah sing ora ana gunane.
            // SAFETY: data_offset aman ditelpon, amarga referensi ptr sing nyata (duweni potensi mudhun) T
            let offset = unsafe { data_offset(ptr) };
            // Mangkono, kita mbalikke offset kanggo entuk RcBox kabeh.
            // SAFETY: pointer asale saka Lemah, mula offset iki aman.
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // SAFETY: saiki kita wis nemokake pointer Weak asli, mula bisa nggawe Lemah.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }

    /// Usaha kanggo upgrade pointer `Weak` dadi [`Rc`], tundha nyelehake nilai batin yen sukses.
    ///
    ///
    /// Ngasilake [`None`] yen nilai batine wis mudhun.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    ///
    /// let strong_five: Option<Rc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // Rusak kabeh pitunjuk sing kuat.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Rc<T>> {
        let inner = self.inner()?;
        if inner.strong() == 0 {
            None
        } else {
            inner.inc_strong();
            Some(Rc::from_inner(self.ptr))
        }
    }

    /// Entuk nomer petunjuk (`Rc`) sing kuat sing nuduhake alokasi iki.
    ///
    /// Yen `self` digawe nggunakake [`Weak::new`], iki bakal ngasilake 0.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong() } else { 0 }
    }

    /// Entuk nomer petunjuk `Weak` sing nuduhake alokasi iki.
    ///
    /// Yen ora ana petunjuk sing kuwat, mula bakal nol.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                if inner.strong() > 0 {
                    inner.weak() - 1 // nyuda ptr sing ringkih implisit
                } else {
                    0
                }
            })
            .unwrap_or(0)
    }

    /// Ngasilake `None` nalika pitunjuk wis digantung lan ora ana `RcBox` sing dialokasikan, (yaiku, nalika `Weak` iki digawe dening `Weak::new`).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // Kita ati-ati supaya *ora* nggawe referensi sing nutupi lapangan "data", amarga lapangan bisa uga diowahi (contone, yen `Rc` pungkasan dicopot, kolom data bakal mudhun ing papane).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// Ngasilake `true` yen loro `Lemah 'nuduhake alokasi sing padha (padha karo [`ptr::eq`]), utawa yen kalorone ora nuduhake alokasi apa wae (amarga digawe nganggo `Weak::new()`).
    ///
    ///
    /// # Notes
    ///
    /// Amarga iki mbandhingake pitunjuk, tegese `Weak::new()` bakal padha, sanajan ora nuduhake alokasi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let first_rc = Rc::new(5);
    /// let first = Rc::downgrade(&first_rc);
    /// let second = Rc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(5);
    /// let third = Rc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// Mbandhingake `Weak::new`.
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(());
    /// let third = Rc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// Nyelehake pointer `Weak`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Rc::new(Foo);
    /// let weak_foo = Rc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // Ora nyithak apa-apa
    /// drop(foo);        // Nyithak "dropped!"
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        inner.dec_weak();
        // petungan sing ringkih diwiwiti jam 1, lan mung bakal nol yen kabeh pitunjuk kuwat wis ilang.
        //
        if inner.weak() == 0 {
            unsafe {
                Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr()));
            }
        }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// Nggawe klon penunjuk `Weak` sing nuduhake alokasi sing padha.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let weak_five = Rc::downgrade(&Rc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        if let Some(inner) = self.inner() {
            inner.inc_weak()
        }
        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// Mbangun `Weak<T>` anyar, nyedhiyakake memori kanggo `T` tanpa nggawe inisialisasi.
    /// Nelpon [`upgrade`] ing rega bali mesthi menehi [`None`].
    ///
    /// [`None`]: Option
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

// NOTE: We check_add ing kene kanggo menehi hasil karo mem::forget kanthi aman.Khususe
// yen sampeyan mem::forget Rcs (utawa Lemah), count ref bisa kakehan, banjur sampeyan bisa mbebasake alokasi nalika Rcs (utawa Lemah) sing luar biasa.
//
// Kita mbatalake amarga iki minangka skenario sing mudhun lan ora preduli apa sing kedadeyan-ora ana program nyata sing bakal ngalami iki.
//
// Iki mesthine duwe overhead sing bisa diabaikan amarga sampeyan ora butuh kloning iki ing Rust amarga kepemilikan lan semantik.
//
//

#[doc(hidden)]
trait RcInnerPtr {
    fn weak_ref(&self) -> &Cell<usize>;
    fn strong_ref(&self) -> &Cell<usize>;

    #[inline]
    fn strong(&self) -> usize {
        self.strong_ref().get()
    }

    #[inline]
    fn inc_strong(&self) {
        let strong = self.strong();

        // Kita pengin ngilangi kebanjiran tinimbang ngeculake regane.
        // Cacah referensi ora bakal nul nalika diarani;
        // Nanging, kita masang abort ing kene kanggo menehi saran LLVM kanthi optimalisasi sing ora kejawab.
        //
        if strong == 0 || strong == usize::MAX {
            abort();
        }
        self.strong_ref().set(strong + 1);
    }

    #[inline]
    fn dec_strong(&self) {
        self.strong_ref().set(self.strong() - 1);
    }

    #[inline]
    fn weak(&self) -> usize {
        self.weak_ref().get()
    }

    #[inline]
    fn inc_weak(&self) {
        let weak = self.weak();

        // Kita pengin ngilangi kebanjiran tinimbang ngeculake regane.
        // Cacah referensi ora bakal nul nalika diarani;
        // Nanging, kita masang abort ing kene kanggo menehi saran LLVM kanthi optimalisasi sing ora kejawab.
        //
        if weak == 0 || weak == usize::MAX {
            abort();
        }
        self.weak_ref().set(weak + 1);
    }

    #[inline]
    fn dec_weak(&self) {
        self.weak_ref().set(self.weak() - 1);
    }
}

impl<T: ?Sized> RcInnerPtr for RcBox<T> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        &self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        &self.strong
    }
}

impl<'a> RcInnerPtr for WeakInner<'a> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        self.strong
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Rc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Rc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Rc<T> {}

/// Entuk offset ing `RcBox` kanggo muatan ing mburi pitunjuk.
///
/// # Safety
///
/// Pointer kudu nuduhake (lan duwe metadata sing bener) conto T sing valid sadurunge, nanging T diidini dicopot.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // Selarasake nilai sing durung diukur menyang pungkasan RcBox.
    // Amarga RcBox minangka repr(C), mesthi bakal dadi lapangan pungkasan ing memori.
    // SAFETY: amarga jinis sing durung ditemtokake mung yaiku irisan, obyek trait,
    // lan jinis eksternal, syarat keamanan input saiki cukup kanggo nyukupi kebutuhan align_of_val_raw;iki minangka rincian implementasi basa sing ora bisa dipercaya ing sanjabane std.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<RcBox<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}