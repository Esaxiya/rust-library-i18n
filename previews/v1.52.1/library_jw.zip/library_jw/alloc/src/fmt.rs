//! Piranti kanggo format lan nyithak `String`s.
//!
//! Modul iki ngemot dhukungan runtime kanggo ekstensi sintaks [`format!`].
//! Makro iki dileksanakake ing kompiler kanggo nerbitake telpon menyang modul iki supaya bisa mbentuk argumen nalika runtime dadi senar.
//!
//! # Usage
//!
//! Makro [`format!`] dimaksudake supaya kenal karo fungsi `printf`/`fprintf` C utawa fungsi `str.format` Python.
//!
//! Sawetara conto ekstensi [`format!`] yaiku:
//!
//! ```
//! format!("Hello");                 // => "Hello"
//! format!("Hello, {}!", "world");   // => "Hello, world!"
//! format!("The number is {}", 1);   // => "The number is 1"
//! format!("{:?}", (3, 4));          // => "(3, 4)"
//! format!("{value}", value=4);      // => "4"
//! format!("{} {}", 1, 2);           // => "1 2"
//! format!("{:04}", 42);             // => "0042" karo nul anjog
//! ```
//!
//! Saka kasebut, sampeyan bisa ndeleng manawa argumen pertama yaiku string format.Dibutuhake dening panyusun supaya literal dadi senar;ora bisa dadi variabel sing dilewati (kanggo mriksa validitas).
//! Kompilator banjur bakal ngrampungake senar format lan nemtokake manawa dhaptar argumen sing disedhiyakake cocog kanggo dikirim menyang string format iki.
//!
//! Kanggo ngowahi siji nilai menyang senar, gunakake cara [`to_string`].Iki bakal nggunakake format [`Display`] trait.
//!
//! ## Parameter posisi
//!
//! Saben argumen format diijini nemtokake argumen nilai sing diarani, lan yen dilalekake bisa dianggep "the next argument".
//! Contone, senar format `{} {} {}` bakal njupuk telung paramèter, lan bakal diformat kanthi urutan sing padha kaya sing diwenehake.
//! String format `{2} {1} {0}`, Nanging, bakal format argumen kanthi urutan mbalikke.
//!
//! Kabeh bisa dadi angel yen sampeyan miwiti nyampur karo rong jinis spesifikasi posisi.Spesifikasi "next argument" bisa dianggep minangka iterator babagan argumen kasebut.
//! Saben ditampilake spesifikasi "next argument", iterator kasebut maju.Iki nyebabake tumindak kaya mangkene:
//!
//! ```
//! format!("{1} {} {0} {}", 1, 2); // => "2 1 1 2"
//! ```
//!
//! Iterator internal babagan argumen durung maju nalika `{}` pisanan katon, mula prints bisa dibahas.Banjur nalika tekan `{}` kapindho, iterator wis maju menyang argumen kaping pindho.
//! Intine, paramèter sing kanthi eksplisit menehi jeneng argumen ora mengaruhi paramèter sing ora menehi jeneng argumen ing babagan spesifikasi posisi.
//!
//! Senar format dibutuhake kanggo nggunakake kabeh argumen, yen ora minangka kesalahan kompilasi-wektu.Sampeyan bisa ngrujuk bantahan sing padha luwih saka sepisan ing string format.
//!
//! ## Parameter sing dijenengi
//!
//! Rust dhewe ora duwe paramèter sing dijenengi kaya Python, nanging makro [`format!`] minangka ekstensi sintaksis sing ngidini bisa nggunakake paramèter sing dijenengi.
//! Parameter sing dijenengi dicantumake ing pungkasan dhaptar argumen lan duwe sintaksis:
//!
//! ```text
//! identifier '=' expression
//! ```
//!
//! Contone, ekspresi [`format!`] ing ngisor iki kabeh nggunakake argumen sing dijenengi:
//!
//! ```
//! format!("{argument}", argument = "test");   // => "test"
//! format!("{name} {}", 1, name = 2);          // => "2 1"
//! format!("{a} {c} {b}", a="a", b='b', c=3);  // => "a 3 b"
//! ```
//!
//! Ora valid kanggo nyelehake paramèter posisi (sing tanpa jeneng) sawise bantahan sing ana jeneng.Kaya paramèter posisi, ora valid kanggo nyedhiyani paramèter sing dijenengi sing ora digunakake dening string format.
//!
//! # Parameter Format
//!
//! Saben argumen sing diformat bisa diowahi kanthi sawetara paramèter format (cocog karo `format_spec` ing [the syntax](#syntax)). Paramèter kasebut mengaruhi perwakilan senar saka apa sing diformat.
//!
//! ## Width
//!
//! ```
//! // Kabeh print "Hello x !" iki
//! println!("Hello {:5}!", "x");
//! println!("Hello {:1$}!", "x", 5);
//! println!("Hello {1:0$}!", 5, "x");
//! println!("Hello {:width$}!", "x", width = 5);
//! ```
//!
//! Iki minangka parameter kanggo "minimum width" sing kudu dijupuk format.
//! Yen senar regane ora ngisi akeh karakter iki, banjur bantalan sing ditemtokake dening fill/alignment bakal digunakake kanggo njupuk spasi sing dibutuhake (pirsani ing ngisor iki).
//!
//! Nilai jembaré uga bisa disedhiyakake minangka [`usize`] ing dhaptar paramèter kanthi nambahake postcode `$`, nuduhake yen argumen nomer loro yaiku [`usize`] sing nemtokake jembaré.
//!
//! Referensi babagan argumen kanthi sintaks dolar ora mengaruhi counter "next argument", mula biasane dadi ide sing apik kanggo ngrujuk argumen miturut posisi, utawa nggunakake argumen sing dijenengi.
//!
//! ## Fill/Alignment
//!
//! ```
//! assert_eq!(format!("Hello {:<5}!", "x"),  "Hello x    !");
//! assert_eq!(format!("Hello {:-<5}!", "x"), "Hello x----!");
//! assert_eq!(format!("Hello {:^5}!", "x"),  "Hello   x  !");
//! assert_eq!(format!("Hello {:>5}!", "x"),  "Hello     x!");
//! ```
//!
//! Karakter lan pilihan jajaran opsional diwenehake biasane bebarengan karo parameter [`width`](#width).Kudu ditetepake sadurunge `width`, sawise `:`.
//! Iki nuduhake yen yen regane diformat luwih cilik tinimbang `width`, sawetara karakter ekstra bakal dicithak ing sakiwa tengene.
//! Ngisi macem-macem jinis ing ngisor iki:
//!
//! * `[fill]<` - argumen kasebut diselehake ing sisih kiwa ing kolom `width`
//! * `[fill]^` - bantahan kasebut didadekake tengah ing kolom `width`
//! * `[fill]>` - bantahan kasebut didadekake siji ing kolom `width`
//!
//! [fill/alignment](#fillalignment) standar kanggo non-numerik yaiku spasi lan selaras karo kiwa.Default kanggo format angka uga karakter spasi nanging kanthi alignment tengen.
//! Yen panji `0` (pirsani ing ngisor iki) ditemtokake kanggo numerik, mula karakter pangisi implisit yaiku `0`.
//!
//! Elinga yen keselarasan bisa uga ora dileksanakake dening sawetara jinis.Utamane, umume ora dileksanakake kanggo `Debug` trait.
//! Cara sing apik kanggo njamin padding ditrapake yaiku format input sampeyan, banjur wenehake tali asil iki supaya bisa ngasilake:
//!
//! ```
//! println!("Hello {:^15}!", format!("{:?}", Some("hi"))); // => "Halo Some("hi")!"
//! ```
//!
//! ## Sign/`#`/`0`
//!
//! ```
//! assert_eq!(format!("Hello {:+}!", 5), "Hello +5!");
//! assert_eq!(format!("{:#x}!", 27), "0x1b!");
//! assert_eq!(format!("Hello {:05}!", 5),  "Hello 00005!");
//! assert_eq!(format!("Hello {:05}!", -5), "Hello -0005!");
//! assert_eq!(format!("{:#010x}!", 27), "0x0000001b!");
//! ```
//!
//! Iki kabeh umbul sing ngowahi prilaku formatter.
//!
//! * `+` - Iki ditujokake kanggo jinis angka lan nuduhake manawa tandha kudu dicithak.Tandha positif ora nate dicithak kanthi gawan, lan tandha negatif mung dicithak kanthi standar kanggo `Signed` trait.
//! Gendera iki nuduhake manawa tandha sing bener (`+` utawa `-`) kudu dicithak.
//! * `-` - Saiki ora digunakake
//! * `#` - Gendera iki nuduhake manawa bentuk cetak "alternate" kudu digunakake.Wangun alternatif yaiku:
//!     * `#?` - cukup cetak format [`Debug`]
//!     * `#x` - ndhisiki argumen nganggo `0x`
//!     * `#X` - ndhisiki argumen nganggo `0x`
//!     * `#b` - ndhisiki argumen nganggo `0b`
//!     * `#o` - ndhisiki argumen nganggo `0o`
//! * `0` - Iki digunakake kanggo nunjukake format bilangan bulat yen padding menyang `width` kudu kaloro kanthi karakter `0` uga tandha-tandha.
//! Format kaya `{:08}` bakal ngasilake `00000001` kanggo integer `1`, dene format sing padha bakal ngasilake `-0000001` kanggo integer `-1`.
//! Elinga yen versi negatif duwe luwih sithik nol tinimbang versi positif.
//!         Elinga yen nol padding mesthi diselehake sawise tandha (yen ana) lan sadurunge digit.Yen digunakake bebarengan karo flag `#`, aturan sing padha ditrapake: nol padding dilebokake sawise ater-ater nanging sadurunge digit.
//!         Awalan kalebu ing jembar total.
//!
//! ## Precision
//!
//! Kanggo jinis non-numerik, iki bisa dianggep "maximum width".
//! Yen senar asil luwih dawa tinimbang jembar iki, mula bakal dipotong nganti pirang-pirang karakter iki lan nilai sing dipotong bakal dipasang karo `fill`, `alignment` lan `width` sing tepat yen parameter kasebut disetel.
//!
//! Kanggo jinis integral, iki ora digatekake.
//!
//! Kanggo jinis titik ngambang, iki nuduhake pirang-pirang digit sawise titik desimal sing kudu dicithak.
//!
//! Ana telung cara sing bisa ditemtokake kanggo `precision` sing dikepengini:
//!
//! 1. `.N` bilangan bulat:
//!
//!    integer `N` dhewe yaiku presisi.
//!
//! 2. Bilangan utawa jeneng sing diikuti tandha dolar `.N$`:
//!
//!    gunakake format *argumen*`N` (sing kudu `usize`) minangka presisi.
//!
//! 3. Asterisk `.*`:
//!
//!    `.*` tegese `{...}` iki digandhengake karo masukan format *loro* tinimbang siji: input kapisan ngemot presisi `usize`, lan sing nomer loro nduweni nilai kanggo dicithak.
//!    Elinga yen ing kasus iki, yen nggunakake string format `{<arg>:<spec>.*}`, mula bagean `<arg>` nuduhake* nilai * kanggo dicithak, lan `precision` kudu mlebu ing input sadurunge `<arg>`.
//!
//! Contone, ing ngisor iki nelpon kabeh print sing padha karo `Hello x is 0.01000`:
//!
//! ```
//! // Halo {arg 0 ("x")} yaiku {arg 1 (0.01) with precision specified inline (5)}
//! println!("Hello {0} is {1:.5}", "x", 0.01);
//!
//! // Halo {arg 1 ("x")} yaiku {arg 2 (0.01) with precision specified in arg 0 (5)}
//! println!("Hello {1} is {2:.0$}", 5, "x", 0.01);
//!
//! // Halo {arg 0 ("x")} yaiku {arg 2 (0.01) with precision specified in arg 1 (5)}
//! println!("Hello {0} is {2:.1$}", "x", 5, 0.01);
//!
//! // Halo {next arg ("x")} yaiku {second of next two args (0.01) with precision specified in first of next two args (5)}
//! //
//! println!("Hello {} is {:.*}",    "x", 5, 0.01);
//!
//! // Halo {next arg ("x")} yaiku {arg 2 (0.01) with precision specified in its predecessor (5)}
//! //
//! println!("Hello {} is {2:.*}",   "x", 5, 0.01);
//!
//! // Halo {next arg ("x")} yaiku {arg "number" (0.01) with precision specified in arg "prec" (5)}
//! //
//! println!("Hello {} is {number:.prec$}", "x", prec = 5, number = 0.01);
//! ```
//!
//! Nalika iki:
//!
//! ```
//! println!("{}, `{name:.*}` has 3 fractional digits", "Hello", 3, name=1234.56);
//! println!("{}, `{name:.*}` has 3 characters", "Hello", 3, name="1234.56");
//! println!("{}, `{name:>8.*}` has 3 right-aligned characters", "Hello", 3, name="1234.56");
//! ```
//!
//! nyithak telung prekara sing beda-beda:
//!
//! ```text
//! Hello, `1234.560` has 3 fractional digits
//! Hello, `123` has 3 characters
//! Hello, `     123` has 3 right-aligned characters
//! ```
//!
//! ## Localization
//!
//! Ing sawetara basa pamrograman, tumindak fungsi format string gumantung saka setelan lokal sistem operasi.
//! Fungsi format sing diwenehake dening perpustakaan standar Rust ora duwe konsep lokal lan bakal ngasilake asil sing padha ing kabeh sistem tanpa dipikirake konfigurasi pangguna.
//!
//! Contone, kode ing ngisor iki bakal terus nyithak `1.5` sanajan lokal sistem nggunakake pemisah desimal liyane tinimbang titik.
//!
//! ```
//! println!("The value is {}", 1.5);
//! ```
//!
//! # Escaping
//!
//! Karakter harfiah `{` lan `}` bisa uga kalebu ing senar kanthi sadurunge nganggo karakter sing padha.Contone, karakter `{` bisa lolos nganggo `{{` lan karakter `}` bisa lolos nganggo `}}`.
//!
//! ```
//! assert_eq!(format!("Hello {{}}"), "Hello {}");
//! assert_eq!(format!("{{ Hello"), "{ Hello");
//! ```
//!
//! # Syntax
//!
//! Kanggo ngringkes, ing kene sampeyan bisa nemokake grammar lengkap format string.
//! Sintaksis kanggo basa format sing digunakake ditarik saka basa liyane, mula ora kudu asing banget.Argumentasi diformat nganggo sintaksis kaya Python, tegese argumen diubengi `{}` tinimbang `%` kaya C.
//! Tata bahasa sing nyata kanggo sintaks format yaiku:
//!
//! ```text
//! format_string := text [ maybe_format text ] *
//! maybe_format := '{' '{' | '}' '}' | format
//! format := '{' [ argument ] [ ':' format_spec ] '}'
//! argument := integer | identifier
//!
//! format_spec := [[fill]align][sign]['#']['0'][width]['.' precision]type
//! fill := character
//! align := '<' | '^' | '>'
//! sign := '+' | '-'
//! width := count
//! precision := count | '*'
//! type := '' | '?' | 'x?' | 'X?' | identifier
//! count := parameter | integer
//! parameter := argument '$'
//! ```
//! Ing grammar ing ndhuwur, `text` bisa uga ora ngemot karakter `'{'` utawa `'}'`.
//!
//! # Ngformat traits
//!
//! Nalika njaluk supaya argumen diformat nganggo jinis tartamtu, sampeyan sejatine njaluk argumen kanggo trait tartamtu.
//! Iki ngidini macem-macem jinis nyata bisa diformat liwat `{:x}` (kaya [`i8`] uga [`isize`]).Pemetaan jinis saiki menyang traits yaiku:
//!
//! * *ora ono* ⇒ [`Display`]
//! * `?` [`Debug`]
//! * `x?` ⇒ [`Debug`] kanthi bilangan bulat heksadesimal cilik
//! * `X?` ⇒ [`Debug`] kanthi bilangan bulat heksadesimal
//! * `o` [`Octal`]
//! * `x` [`LowerHex`]
//! * `X` [`UpperHex`]
//! * `p` [`Pointer`]
//! * `b` [`Binary`]
//! * `e` [`LowerExp`]
//! * `E` [`UpperExp`]
//!
//! Tegese yaiku kabeh jinis argumen sing ngetrapake [`fmt::Binary`][`Binary`] trait banjur bisa diformat nganggo `{:b}`.Implementasi diwenehake kanggo traits iki kanggo sawetara jinis primitif dening perpustakaan standar uga.
//!
//! Yen ora ana format sing ditemtokake (kaya ing `{}` utawa `{:6}`), mula format sing digunakake trait yaiku [`Display`] trait.
//!
//! Nalika ngetrapake format trait kanggo jinis sampeyan dhewe, sampeyan kudu ngetrapake cara teken:
//!
//! ```
//! # #![allow(dead_code)]
//! # use std::fmt;
//! # struct Foo; // jinis adat kita
//! # impl fmt::Display for Foo {
//! fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//! # write!(f, "testing, testing")
//! # } }
//! ```
//!
//! Jinis sampeyan bakal dilewati minangka referensi `self`, lan banjur fungsine ngirim output menyang stream `f.buf`.Kasedhiya kanggo saben implementasi trait format kanggo bener ngetrapake paramèter format sing dijaluk.
//! Nilai paramèter kasebut bakal didaftar ing kolom strukture [`Formatter`].Kanggo mbantu ngatasi iki, struktur [`Formatter`] uga nyedhiyakake sawetara cara pambantu.
//!
//! Kajaba iku, nilai bali fungsi iki yaiku [`fmt::Result`] yaiku jinis alias [`Result`]`<(),`[`std: : fmt::Error`] `>`.
//! Implementasi format kudu mesthekake yen nyebarake kesalahan saka [`Formatter`] (kayata, nalika nelpon [`write!`]).
//! Nanging, dheweke ora nate ngasilake kesalahan kanthi spurious.
//! Yaiku, implementasi format kudu lan mung bisa ngasilake kesalahan yen [`Formatter`] sing kliwat ngasilake kesalahan.
//! Iki amarga, bertentangan karo apa sing disaranake tandha tangan fungsi, format senar minangka operasi sing salah.
//! Fungsi iki mung ngasilake asil amarga nulis menyang stream sing ndasari bisa uga gagal lan kudu menehi cara kanggo nyebarake manawa ana kesalahan nalika nggawe cadangan.
//!
//! Contone ngleksanakake format traits bakal katon kaya:
//!
//! ```
//! use std::fmt;
//!
//! #[derive(Debug)]
//! struct Vector2D {
//!     x: isize,
//!     y: isize,
//! }
//!
//! impl fmt::Display for Vector2D {
//!     fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//!         // Nilai `f` ngleksanakake `Write` trait, yaiku sing ditulis!makro ngarepake
//!         // Elinga yen format iki ora nggatekake macem-macem panji sing disedhiyakake kanggo senar format.
//!         //
//!         write!(f, "({}, {})", self.x, self.y)
//!     }
//! }
//!
//! // traits sing beda-beda ngidini macem-macem jinis output.
//! // Makna format iki yaiku nyithak gedhene vector.
//! impl fmt::Binary for Vector2D {
//!     fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//!         let magnitude = (self.x * self.x + self.y * self.y) as f64;
//!         let magnitude = magnitude.sqrt();
//!
//!         // Nguripake panji format kanthi nggunakake metode helper `pad_integral` ing obyek Formatter.
//!         // Deleng dokumentasi metode kanggo rincian, lan fungsi `pad` bisa digunakake kanggo tali senar.
//!         //
//!         //
//!         let decimals = f.precision().unwrap_or(3);
//!         let string = format!("{:.*}", decimals, magnitude);
//!         f.pad_integral(true, "", &string)
//!     }
//! }
//!
//! fn main() {
//!     let myvector = Vector2D { x: 3, y: 4 };
//!
//!     println!("{}", myvector);       // => "(3, 4)"
//!     println!("{:?}", myvector);     // => "Vector2D {x: 3, y:4}"
//!     println!("{:10.3b}", myvector); // => "     5.000"
//! }
//! ```
//!
//! ### `fmt::Display` vs `fmt::Debug`
//!
//! Kaloro format traits iki duwe tujuan sing beda:
//!
//! - [`fmt::Display`][`Display`] implementasine negesake manawa jinis kasebut bisa kanthi setya diwakili minangka senar UTF-8 sawayah-wayah.**Ora** diarepake kabeh jinis ngetrapake [`Display`] trait.
//! - [`fmt::Debug`][`Debug`] implementasine kudu dileksanakake kanggo **kabeh** jinis umum.
//!   Output biasane bakal makili negara internal kanthi setya.
//!   Tujuan [`Debug`] trait yaiku kanggo nggampangake kode debugging Rust.Ing kasus paling, nggunakake `#[derive(Debug)]` cukup lan disaranake.
//!
//! Sawetara conto output saka kaloro traits:
//!
//! ```
//! assert_eq!(format!("{} {:?}", 3, 4), "3 4");
//! assert_eq!(format!("{} {:?}", 'a', 'b'), "a 'b'");
//! assert_eq!(format!("{} {:?}", "foo\n", "bar\n"), "foo\n \"bar\\n\"");
//! ```
//!
//! # Makro sing gegandhengan
//!
//! Ana pirang-pirang makro sing gegandhengan ing kulawarga [`format!`].Sing ditrapake saiki yaiku:
//!
//! ```ignore (only-for-syntax-highlight)
//! format!      // described above
//! write!       // first argument is a &mut io::Write, the destination
//! writeln!     // same as write but appends a newline
//! print!       // the format string is printed to the standard output
//! println!     // same as print but appends a newline
//! eprint!      // the format string is printed to the standard error
//! eprintln!    // same as eprint but appends a newline
//! format_args! // described below.
//! ```
//!
//! ### `write!`
//!
//! Iki lan [`writeln!`] minangka loro makro sing digunakake kanggo ngetokake senar format menyang stream sing ditemtokake.Iki digunakake kanggo nyegah alokasi tengah strings format lan langsung nulis output.
//! Ing hood, fungsi iki nyatane nggunakake fungsi [`write_fmt`] sing ditetepake ing [`std::io::Write`] trait.
//! Tuladha panggunaan yaiku:
//!
//! ```
//! # #![allow(unused_must_use)]
//! use std::io::Write;
//! let mut w = Vec::new();
//! write!(&mut w, "Hello {}!", "world");
//! ```
//!
//! ### `print!`
//!
//! Iki lan [`println!`] ngetokake output menyang stdout.Kajaba kanggo makro [`write!`], tujuan makro kasebut yaiku supaya alokasi menengah nalika nyithak output.Tuladha panggunaan yaiku:
//!
//! ```
//! print!("Hello {}!", "world");
//! println!("I have a newline {}", "character at the end");
//! ```
//!
//! ### `eprint!`
//!
//! Makro [`eprint!`] lan [`eprintln!`] padha karo [`print!`] lan [`println!`], kajaba sing ngasilake output menyang stderr.
//!
//! ### `format_args!`
//!
//! Iki minangka makro penasaran sing digunakake kanthi aman ngubengi obyek buram sing nggambarake senar format.Objek iki ora mbutuhake alokasi tumpukan kanggo digawe, lan mung referensi informasi ing tumpukan.
//! Ing hood, kabeh makro sing gegandhengan ditrapake ing babagan iki.
//! Pisanan, sawetara conto panggunaan yaiku:
//!
//! ```
//! # #![allow(unused_must_use)]
//! use std::fmt;
//! use std::io::{self, Write};
//!
//! let mut some_writer = io::stdout();
//! write!(&mut some_writer, "{}", format_args!("print with a {}", "macro"));
//!
//! fn my_fmt_fn(args: fmt::Arguments) {
//!     write!(&mut io::stdout(), "{}", args);
//! }
//! my_fmt_fn(format_args!(", or a {} too", "function"));
//! ```
//!
//! Asil makro [`format_args!`] yaiku regane jinis [`fmt::Arguments`].
//! Struktur iki banjur bisa diterusake menyang fungsi [`write`] lan [`format`] ing njero modul iki kanggo ngolah string format.
//! Tujuan makro iki yaiku supaya luwih nyegah alokasi menengah nalika menehi strings format.
//!
//! Contone, perpustakaan logging bisa nggunakake sintaks format standar, nanging internal bakal ngubengi struktur iki nganti wis ditemtokake tekan endi output.
//!
//! [`fmt::Result`]: Result
//! [`Result`]: core::result::Result
//! [`std::fmt::Error`]: Error
//! [`write!`]: core::write
//! [`write`]: core::write
//! [`format!`]: crate::format
//! [`to_string`]: crate::string::ToString
//! [`writeln!`]: core::writeln
//! [`write_fmt`]: ../../std/io/trait.Write.html#method.write_fmt
//! [`std::io::Write`]: ../../std/io/trait.Write.html
//! [`print!`]: ../../std/macro.print.html
//! [`println!`]: ../../std/macro.println.html
//! [`eprint!`]: ../../std/macro.eprint.html
//! [`eprintln!`]: ../../std/macro.eprintln.html
//! [`format_args!`]: core::format_args
//! [`fmt::Arguments`]: Arguments
//! [`format`]: crate::format
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[unstable(feature = "fmt_internals", issue = "none")]
pub use core::fmt::rt;
#[stable(feature = "fmt_flags_align", since = "1.28.0")]
pub use core::fmt::Alignment;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::Error;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{write, ArgumentV1, Arguments};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Binary, Octal};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Debug, Display};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{DebugList, DebugMap, DebugSet, DebugStruct, DebugTuple};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Formatter, Result, Write};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{LowerExp, UpperExp};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{LowerHex, Pointer, UpperHex};

use crate::string;

/// Fungsi `format` njupuk struktur [`Arguments`] lan ngasilake string format sing diasilake.
///
///
/// Kayata [`Arguments`] bisa digawe nganggo makro [`format_args!`].
///
/// # Examples
///
/// Panggunaan dhasar:
///
/// ```
/// use std::fmt;
///
/// let s = fmt::format(format_args!("Hello, {}!", "world"));
/// assert_eq!(s, "Hello, world!");
/// ```
///
/// Elinga yen nggunakake [`format!`] luwih apik.
/// Example:
///
/// ```
/// let s = format!("Hello, {}!", "world");
/// assert_eq!(s, "Hello, world!");
/// ```
///
/// [`format_args!`]: core::format_args
/// [`format!`]: crate::format
#[stable(feature = "rust1", since = "1.0.0")]
pub fn format(args: Arguments<'_>) -> string::String {
    let capacity = args.estimated_capacity();
    let mut output = string::String::with_capacity(capacity);
    output.write_fmt(args).expect("a formatting trait implementation returned an error");
    output
}