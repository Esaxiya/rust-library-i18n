#![unstable(feature = "raw_vec_internals", reason = "implementation detail", issue = "none")]
#![doc(hidden)]

use core::alloc::LayoutError;
use core::cmp;
use core::intrinsics;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::Drop;
use core::ptr::{self, NonNull, Unique};
use core::slice;

use crate::alloc::{handle_alloc_error, Allocator, Global, Layout};
use crate::boxed::Box;
use crate::collections::TryReserveError::{self, *};

#[cfg(test)]
mod tests;

enum AllocInit {
    /// Isi memori sing anyar durung ditemtokake.
    Uninitialized,
    /// Memori anyar dijamin bakal nol.
    Zeroed,
}

/// Utilitas tingkat murah kanggo alokasi, realokasi, lan deallocating buffer memori sing luwih ergonomis ing tumpukan tanpa kudu kuwatir kabeh kasus sudhut sing ana gandhengane.
///
/// Jinis iki apik banget kanggo mbangun struktur data sampeyan dhewe kaya Vec lan VecDeque.
/// Khususipun:
///
/// * Ngasilake `Unique::dangling()` kanthi jinis ukuran nol.
/// * Ngasilake `Unique::dangling()` kanthi alokasi dawa-nol.
/// * Nyingkiri `Unique::dangling()` mbebasake.
/// * Nyekel kabeh kebanjiran ing petungan kapasitas (promosi dadi "capacity overflow" panics).
/// * Pengawal nglawan sistem 32-bit sing nyedhiyakake luwih saka isize::MAX byte.
/// * Pengawal nglawan kebanjiran sampeyan.
/// * Telpon `handle_alloc_error` kanggo alokasi sing bisa dingerteni.
/// * Ngemot `ptr::Unique` lan mulane menehi pangguna kabeh mupangat sing gegandhengan.
/// * Nggunakake keluwihan sing dibalekake saka alokator kanggo nggunakake kapasitas sing kasedhiya paling gedhe.
///
/// Jinis iki ora mriksa memori sing dikelola.Nalika nyelehake *bakal* mbebasake memori, nanging * ora bakal nyoba ngeculake isine.
/// Terserah pangguna `RawVec` kanggo nangani samubarang sing nyata *disimpen* ing `RawVec`.
///
/// Elinga yen keluwihan jinis ukuran nol mesthi tanpa wates, mula `capacity()` mesthi ngasilake `usize::MAX`.
/// Iki tegese sampeyan kudu ati-ati nalika tripping babak jinis iki nganggo `Box<[T]>`, amarga `capacity()` ora bakal ngasilake dawa.
///
///
#[allow(missing_debug_implementations)]
pub struct RawVec<T, A: Allocator = Global> {
    ptr: Unique<T>,
    cap: usize,
    alloc: A,
}

impl<T> RawVec<T, Global> {
    /// HACK(Centril): Iki ana amarga `#[unstable]` `const fn`s ora kudu salaras karo `min_const_fn` lan mula ora bisa diarani`min_const_fn`s uga.
    ///
    /// Yen sampeyan ngganti `RawVec<T>::new` utawa katergantungan, ati-ati supaya ora ngenalake apa wae sing bakal nglanggar `min_const_fn`.
    ///
    /// NOTE: Kita bisa ngindhari hack iki lan mriksa salaras karo sawetara atribut `#[rustc_force_min_const_fn]` sing mbutuhake salaras karo `min_const_fn` nanging ora mesthi ngidini nelpon kode `stable(...) const fn`/pangguna ora ngaktifake `foo` nalika `#[rustc_const_unstable(feature = "foo", issue = "01234")]` saiki.
    ///
    ///
    ///
    ///
    ///
    ///
    pub const NEW: Self = Self::new();

    /// Nggawe `RawVec` paling gedhe (ing tumpukan sistem) tanpa alokasi.
    /// Yen `T` duwe ukuran positif, mula iki bakal nggawe `RawVec` kanthi kapasitas `0`.
    /// Yen `T` ukurane nol, mula bakal nggawe `RawVec` kanthi kapasitas `usize::MAX`.
    /// Migunani kanggo ngetrapake alokasi telat.
    ///
    pub const fn new() -> Self {
        Self::new_in(Global)
    }

    /// Nggawe `RawVec` (ing tumpukan sistem) kanthi kapasitas lan syarat sing cocog kanggo `[T; capacity]`.
    /// Iki padha karo nelpon `RawVec::new` nalika `capacity` yaiku `0` utawa `T` ukurane nol.
    /// Elinga yen `T` ukuran nol iki tegese sampeyan ora bakal * entuk `RawVec` kanthi kapasitas sing dijaluk.
    ///
    /// # Panics
    ///
    /// Panics yen kapasitas sing dijaluk ngluwihi `isize::MAX` byte.
    ///
    /// # Aborts
    ///
    /// Abort ing OOM.
    ///
    ///
    #[inline]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// Kaya `with_capacity`, nanging njamin buffer nol.
    #[inline]
    pub fn with_capacity_zeroed(capacity: usize) -> Self {
        Self::with_capacity_zeroed_in(capacity, Global)
    }

    /// Ngatur maneh `RawVec` saka pitunjuk lan kapasitas.
    ///
    /// # Safety
    ///
    /// `ptr` kudu dialokasikan (ing tumpukan sistem), lan kanthi `capacity` sing diwenehake.
    /// `capacity` ora bisa ngluwihi `isize::MAX` kanggo jinis ukuran.(mung masalah ing sistem 32-bit).
    /// ZST vectors bisa uga duwe kapasitas nganti `usize::MAX`.
    /// Yen `ptr` lan `capacity` asale `RawVec`, mula bakal dijamin.
    #[inline]
    pub unsafe fn from_raw_parts(ptr: *mut T, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, capacity, Global) }
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    // Vecs cilik bisu.Skip menyang:
    // - 8 yen ukuran elemen yaiku 1, amarga alokasi tumpukan bisa uga njaluk panjaluk kurang saka 8 bait nganti paling ora 8 bait.
    //
    // - 4 yen unsur ukurane sedhengan (<=1 KiB).
    // - 1 yen ora, supaya ora mbuang-mbuwang papan kanggo Vecs sing cendhak banget.
    const MIN_NON_ZERO_CAP: usize = if mem::size_of::<T>() == 1 {
        8
    } else if mem::size_of::<T>() <= 1024 {
        4
    } else {
        1
    };

    /// Kaya `new`, nanging parameterisasi ing pilihan alokasi kanggo `RawVec` bali.
    ///
    #[rustc_allow_const_fn_unstable(const_fn)]
    pub const fn new_in(alloc: A) -> Self {
        // `cap: 0` tegese "unallocated".jinis ukuran nol ora digatekake.
        Self { ptr: Unique::dangling(), cap: 0, alloc }
    }

    /// Kaya `with_capacity`, nanging parameterisasi ing pilihan alokasi kanggo `RawVec` bali.
    ///
    #[inline]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Uninitialized, alloc)
    }

    /// Kaya `with_capacity_zeroed`, nanging parameterisasi ing pilihan alokasi kanggo `RawVec` bali.
    ///
    #[inline]
    pub fn with_capacity_zeroed_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Zeroed, alloc)
    }

    /// Ngowahi `Box<[T]>` dadi `RawVec<T>`.
    pub fn from_box(slice: Box<[T], A>) -> Self {
        unsafe {
            let (slice, alloc) = Box::into_raw_with_allocator(slice);
            RawVec::from_raw_parts_in(slice.as_mut_ptr(), slice.len(), alloc)
        }
    }

    /// Ngonversi kabeh buffer dadi `Box<[MaybeUninit<T>]>` kanthi `len` sing ditemtokake.
    ///
    /// Elinga yen iki bakal ngganti maneh pangowahan `cap` sing bisa ditindakake.(Deleng katrangan jinis kanggo rincian.)
    ///
    /// # Safety
    ///
    /// * `len` kudu luwih saka utawa padha karo kapasitas sing paling anyar sing dijaluk, lan
    /// * `len` kudu kurang saka utawa padha karo `self.capacity()`.
    ///
    /// Elinga, yen kapasitas sing dijaluk lan `self.capacity()` bisa beda-beda, amarga alokator bisa milih jumlah gedhe lan ngasilake blok memori sing luwih gedhe tinimbang sing dijaluk.
    ///
    ///
    pub unsafe fn into_box(self, len: usize) -> Box<[MaybeUninit<T>], A> {
        // Sanity-mriksa separo persyaratan keamanan (kita ora bisa mriksa separo liyane).
        debug_assert!(
            len <= self.capacity(),
            "`len` must be smaller than or equal to `self.capacity()`"
        );

        let me = ManuallyDrop::new(self);
        unsafe {
            let slice = slice::from_raw_parts_mut(me.ptr() as *mut MaybeUninit<T>, len);
            Box::from_raw_in(slice, ptr::read(&me.alloc))
        }
    }

    fn allocate_in(capacity: usize, init: AllocInit, alloc: A) -> Self {
        if mem::size_of::<T>() == 0 {
            Self::new_in(alloc)
        } else {
            // Kita nyingkiri `unwrap_or_else` ing kene amarga kembung jumlah LLVM IR sing digawe.
            //
            let layout = match Layout::array::<T>(capacity) {
                Ok(layout) => layout,
                Err(_) => capacity_overflow(),
            };
            match alloc_guard(layout.size()) {
                Ok(_) => {}
                Err(_) => capacity_overflow(),
            }
            let result = match init {
                AllocInit::Uninitialized => alloc.allocate(layout),
                AllocInit::Zeroed => alloc.allocate_zeroed(layout),
            };
            let ptr = match result {
                Ok(ptr) => ptr,
                Err(_) => handle_alloc_error(layout),
            };

            Self {
                ptr: unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) },
                cap: Self::capacity_from_bytes(ptr.len()),
                alloc,
            }
        }
    }

    /// Ngatur maneh `RawVec` saka pitunjuk, kapasitas, lan alokasi.
    ///
    /// # Safety
    ///
    /// `ptr` kudu dialokasikan (liwat alokasi `alloc`), lan kanthi `capacity` sing diwenehake.
    /// `capacity` ora bisa ngluwihi `isize::MAX` kanggo jinis ukuran.
    /// (mung masalah ing sistem 32-bit).
    /// ZST vectors bisa uga duwe kapasitas nganti `usize::MAX`.
    /// Yen `ptr` lan `capacity` teka saka `RawVec` sing digawe liwat `alloc`, mula bakal dijamin.
    ///
    #[inline]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, capacity: usize, alloc: A) -> Self {
        Self { ptr: unsafe { Unique::new_unchecked(ptr) }, cap: capacity, alloc }
    }

    /// Entuk penunjuk mentah kanggo wiwitan alokasi.
    /// Elinga yen iki `Unique::dangling()` yen `capacity == 0` utawa `T` ukurane nol.
    /// Ing bekas kasus kasebut, sampeyan kudu ngati-ati.
    #[inline]
    pub fn ptr(&self) -> *mut T {
        self.ptr.as_ptr()
    }

    /// Entuk kapasitas alokasi kasebut.
    ///
    /// Iki bakal dadi `usize::MAX` yen `T` ukurane nol.
    #[inline(always)]
    pub fn capacity(&self) -> usize {
        if mem::size_of::<T>() == 0 { usize::MAX } else { self.cap }
    }

    /// Ngasilake referensi bareng karo alokasi sing nggawe `RawVec` iki.
    pub fn allocator(&self) -> &A {
        &self.alloc
    }

    fn current_memory(&self) -> Option<(NonNull<u8>, Layout)> {
        if mem::size_of::<T>() == 0 || self.cap == 0 {
            None
        } else {
            // Kita duwe potongan memori sing dialokasikan, mula kita bisa ngliwati cek runtime kanggo entuk tata letak saiki.
            //
            unsafe {
                let align = mem::align_of::<T>();
                let size = mem::size_of::<T>() * self.cap;
                let layout = Layout::from_size_align_unchecked(size, align);
                Some((self.ptr.cast().into(), layout))
            }
        }
    }

    /// Mesthekake manawa buffer ngemot paling ora ruangan kanggo nahan elemen `len + additional`.
    /// Yen durung cukup kapasitas, bakal reallocate cukup papan plus papan kendur sing kepenak kanggo tumindak *O*(1) sing diamortisasi.
    ///
    /// Bakal matesi prilaku iki yen sampeyan kudu nyebabake panic.
    ///
    /// Yen `len` ngluwihi `self.capacity()`, iki bisa uga gagal nyawisake ruang sing dijaluk.
    /// Iki pancen ora aman, nanging kode *sampeyan* sing ora aman sing gumantung marang tumindake fungsi iki bisa uga rusak.
    ///
    /// Iki cocog kanggo ngetrapake operasi push-pressure kaya `extend`.
    ///
    /// # Panics
    ///
    /// Panics yen kapasitas anyar ngluwihi `isize::MAX` byte.
    ///
    /// # Aborts
    ///
    /// Abort ing OOM.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![feature(raw_vec_internals)]
    /// # extern crate alloc;
    /// # use std::ptr;
    /// # use alloc::raw_vec::RawVec;
    /// struct MyVec<T> {
    ///     buf: RawVec<T>,
    ///     len: usize,
    /// }
    ///
    /// impl<T: Clone> MyVec<T> {
    ///     pub fn push_all(&mut self, elems: &[T]) {
    ///         self.buf.reserve(self.len, elems.len());
    ///         // cadangan bakal ngilangi utawa panik yen len ngluwihi `isize::MAX` dadi saiki aman yen ora dicenthang.
    /////
    ///         for x in elems {
    ///             unsafe {
    ///                 ptr::write(self.buf.ptr().add(self.len), x.clone());
    ///             }
    ///             self.len += 1;
    ///         }
    ///     }
    /// }
    /// # fn main() {
    /// #   let mut vector = MyVec { buf: RawVec::new(), len: 0 };
    /// #   vector.push_all(&[1, 3, 5, 7, 9]);
    /// # }
    /// ```
    ///
    ///
    pub fn reserve(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve(len, additional));
    }

    /// Padha karo `reserve`, nanging ngasilake kesalahan tinimbang panik utawa aborsi.
    pub fn try_reserve(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) {
            self.grow_amortized(len, additional)
        } else {
            Ok(())
        }
    }

    /// Mesthekake manawa buffer ngemot paling ora ruangan kanggo nahan elemen `len + additional`.
    /// Yen durung, bakal reallocate memori minimal sing dibutuhake.
    /// Umume iki bakal padha karo jumlah memori sing dibutuhake, nanging miturut prinsip, alokator bebas menehi luwih akeh tinimbang sing dijaluk.
    ///
    ///
    /// Yen `len` ngluwihi `self.capacity()`, iki bisa uga gagal nyawisake ruang sing dijaluk.
    /// Iki pancen ora aman, nanging kode *sampeyan* sing ora aman sing gumantung marang tumindake fungsi iki bisa uga rusak.
    ///
    /// # Panics
    ///
    /// Panics yen kapasitas anyar ngluwihi `isize::MAX` byte.
    ///
    /// # Aborts
    ///
    /// Abort ing OOM.
    ///
    ///
    pub fn reserve_exact(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve_exact(len, additional));
    }

    /// Padha karo `reserve_exact`, nanging ngasilake kesalahan tinimbang panik utawa aborsi.
    pub fn try_reserve_exact(
        &mut self,
        len: usize,
        additional: usize,
    ) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) { self.grow_exact(len, additional) } else { Ok(()) }
    }

    /// Nyilikake alokasi nganti jumlah sing ditemtokake.
    /// Yen jumlah sing diwenehake yaiku 0, sejatine kabeh menehi hasil.
    ///
    /// # Panics
    ///
    /// Panics yen jumlah sing diwenehake *luwih gedhe* tinimbang kapasitas saiki.
    ///
    /// # Aborts
    ///
    /// Abort ing OOM.
    pub fn shrink_to_fit(&mut self, amount: usize) {
        handle_reserve(self.shrink(amount));
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    /// Bali yen buffer kudu tuwuh kanggo ngisi kapasitas ekstra sing dibutuhake.
    /// Utamane digunakake kanggo nggawe panggilan inlining cadangan tanpa inlining `grow`.
    fn needs_to_grow(&self, len: usize, additional: usize) -> bool {
        additional > self.capacity().wrapping_sub(len)
    }

    fn capacity_from_bytes(excess: usize) -> usize {
        debug_assert_ne!(mem::size_of::<T>(), 0);
        excess / mem::size_of::<T>()
    }

    fn set_ptr(&mut self, ptr: NonNull<[u8]>) {
        self.ptr = unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) };
        self.cap = Self::capacity_from_bytes(ptr.len());
    }

    // Cara iki biasane diwiwiti kaping pirang-pirang.Dadi, kita kepengin supaya bisa sekecil mungkin, kanggo nambah wektu kompilasi.
    // Nanging kita uga pengin supaya akeh isine bisa diitung kanthi statis, supaya kode sing digawe luwih cepet.
    // Mula, cara iki ditulis kanthi tliti saengga kabeh kode sing gumantung ing `T` ana ing kana, dene kode sing ora gumantung karo `T` sabisa-bisa ana ing fungsi sing ora umum ing `T`.
    //
    //
    //
    //
    fn grow_amortized(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        // Iki dijamin karo konteks panggilan.
        debug_assert!(additional > 0);

        if mem::size_of::<T>() == 0 {
            // Amarga kita ngasilake kapasitas `usize::MAX` nalika `elem_size`
            // 0, tekan kene mesthi tegese `RawVec` overfull.
            return Err(CapacityOverflow);
        }

        // Ora ana prekara sing bisa ditindakake babagan kir kasebut.
        let required_cap = len.checked_add(additional).ok_or(CapacityOverflow)?;

        // Iki njamin tuwuhing eksponensial.
        // Dobel ora bisa kebanjiran amarga `cap <= isize::MAX` lan jinis `cap` yaiku `usize`.
        let cap = cmp::max(self.cap * 2, required_cap);
        let cap = cmp::max(Self::MIN_NON_ZERO_CAP, cap);

        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` non-umum liwat `T`.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    // Watesan metode iki padha karo sing ana ing `grow_amortized`, nanging cara iki biasane kurang asring ditindakake saengga kurang kritis.
    //
    //
    fn grow_exact(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if mem::size_of::<T>() == 0 {
            // Amarga kita ngasilake kapasitas `usize::MAX` nalika ukuran jinis kasebut
            // 0, tekan kene mesthi tegese `RawVec` overfull.
            return Err(CapacityOverflow);
        }

        let cap = len.checked_add(additional).ok_or(CapacityOverflow)?;
        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` non-umum liwat `T`.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    fn shrink(&mut self, amount: usize) -> Result<(), TryReserveError> {
        assert!(amount <= self.capacity(), "Tried to shrink to a larger capacity");

        let (ptr, layout) = if let Some(mem) = self.current_memory() { mem } else { return Ok(()) };
        let new_size = amount * mem::size_of::<T>();

        let ptr = unsafe {
            let new_layout = Layout::from_size_align_unchecked(new_size, layout.align());
            self.alloc.shrink(ptr, layout, new_layout).map_err(|_| TryReserveError::AllocError {
                layout: new_layout,
                non_exhaustive: (),
            })?
        };
        self.set_ptr(ptr);
        Ok(())
    }
}

// Fungsi iki njaba `RawVec` kanggo nyilikake wektu kompilasi.Deleng komentar ing ndhuwur `RawVec::grow_amortized` kanggo rincian.
// (Parameter `A` ora signifikan, amarga jumlah jinis `A` sing beda-beda sing katon ing praktik luwih cilik tinimbang jumlah `T`.)
//
//
#[inline(never)]
fn finish_grow<A>(
    new_layout: Result<Layout, LayoutError>,
    current_memory: Option<(NonNull<u8>, Layout)>,
    alloc: &mut A,
) -> Result<NonNull<[u8]>, TryReserveError>
where
    A: Allocator,
{
    // Priksa kesalahan ing kene kanggo nyilikake ukuran `RawVec::grow_*`.
    let new_layout = new_layout.map_err(|_| CapacityOverflow)?;

    alloc_guard(new_layout.size())?;

    let memory = if let Some((ptr, old_layout)) = current_memory {
        debug_assert_eq!(old_layout.align(), new_layout.align());
        unsafe {
            // Aloktor mriksa kesetaraan keselarasan
            intrinsics::assume(old_layout.align() == new_layout.align());
            alloc.grow(ptr, old_layout, new_layout)
        }
    } else {
        alloc.allocate(new_layout)
    };

    memory.map_err(|_| AllocError { layout: new_layout, non_exhaustive: () })
}

unsafe impl<#[may_dangle] T, A: Allocator> Drop for RawVec<T, A> {
    /// Mbebasake memori sing diduweni dening `RawVec`*tanpa* nyoba ngeculake isine.
    fn drop(&mut self) {
        if let Some((ptr, layout)) = self.current_memory() {
            unsafe { self.alloc.deallocate(ptr, layout) }
        }
    }
}

// Fungsi pusat kanggo nangani kesalahan cadangan.
#[inline]
fn handle_reserve(result: Result<(), TryReserveError>) {
    match result {
        Err(CapacityOverflow) => capacity_overflow(),
        Err(AllocError { layout, .. }) => handle_alloc_error(layout),
        Ok(()) => { /* yay */ }
    }
}

// Kita kudu njamin kaya ing ngisor iki:
// * Kita ora nate nyedhiyakake obyek ukuran byte `> isize::MAX`.
// * Kita ora kebanjiran `usize::MAX` lan nyatane nyedhiyakake sethithik banget.
//
// Ing 64-bit, kita mung kudu mriksa kebanjiran amarga nyoba menehi byte `> isize::MAX` mesthi bakal gagal.
// Ing 32-bit lan 16-bit, kita kudu nambah penjaga tambahan yen kita mlaku ing platform sing bisa nggunakake kabeh 4GB ing ruang pangguna, kayata PAE utawa x32.
//
//

#[inline]
fn alloc_guard(alloc_size: usize) -> Result<(), TryReserveError> {
    if usize::BITS < 64 && alloc_size > isize::MAX as usize {
        Err(CapacityOverflow)
    } else {
        Ok(())
    }
}

// Siji fungsi pusat sing tanggung jawab nglaporake kebanjiran kapasitas.
// Iki bakal mesthekake yen generasi kode sing ana gandhengane karo panics iki minimal amarga mung ana siji lokasi sing panics tinimbang akeh modul.
//
fn capacity_overflow() -> ! {
    panic!("capacity overflow");
}