/// Nggawe [`Vec`] sing ngemot bantahan.
///
/// `vec!` ngidini `Vec`s ditetepake kanthi sintaksis sing padha karo ekspresi larik.
/// Ana rong wujud makro iki:
///
/// - Gawe [`Vec`] sing ngemot dhaptar elemen:
///
/// ```
/// let v = vec![1, 2, 3];
/// assert_eq!(v[0], 1);
/// assert_eq!(v[1], 2);
/// assert_eq!(v[2], 3);
/// ```
///
/// - Gawe [`Vec`] saka elemen lan ukuran sing diwenehake:
///
/// ```
/// let v = vec![1; 3];
/// assert_eq!(v, [1, 1, 1]);
/// ```
///
/// Elinga, ora kaya ekspresi rangkai, sintaks iki ndhukung kabeh unsur sing ngetrapake [`Clone`] lan jumlah elemen ora kudu tetep.
///
/// Iki bakal nggunakake `clone` kanggo duplikat ekspresi, mula kudu ngati-ati nganggo jinis iki kanthi implementasi `Clone` sing ora standar.
/// Contone, `vec![Rc::new(1);5] `bakal nggawe vector saka limang referensi angka integer kothak sing padha, dudu limang referensi sing nuduhake integer kothak kanthi independen.
///
///
/// Uga cathet yen `vec![expr; 0]` diidini, lan ngasilake vector kosong.
/// Nanging, iki isih bakal ngevaluasi `expr`, lan langsung nyelehake angka sing diasilake, mula elingake efek samping.
///
/// [`Vec`]: crate::vec::Vec
///
///
///
///
///
#[cfg(not(test))]
#[doc(alias = "alloc")]
#[doc(alias = "malloc")]
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(box_syntax, liballoc_internals)]
macro_rules! vec {
    () => (
        $crate::__rust_force_expr!($crate::vec::Vec::new())
    );
    ($elem:expr; $n:expr) => (
        $crate::__rust_force_expr!($crate::vec::from_elem($elem, $n))
    );
    ($($x:expr),+ $(,)?) => (
        $crate::__rust_force_expr!(<[_]>::into_vec(box [$($x),+]))
    );
}

// HACK(japaric): kanthi cfg(test) cara `[T]::into_vec` sing ana, sing dibutuhake kanggo definisi makro iki, ora kasedhiya.
// Nanging gunakake fungsi `slice::into_vec` sing mung kasedhiya karo cfg(test) NB deleng modul slice::hack ing slice.rs kanggo informasi luwih lengkap
//
//
#[cfg(test)]
macro_rules! vec {
    () => (
        $crate::vec::Vec::new()
    );
    ($elem:expr; $n:expr) => (
        $crate::vec::from_elem($elem, $n)
    );
    ($($x:expr),*) => (
        $crate::slice::into_vec(box [$($x),*])
    );
    ($($x:expr,)*) => (vec![$($x),*])
}

/// Nggawe `String` nggunakake interpolasi ekspresi runtime.
///
/// Argumen pertama `format!` sing ditampa yaiku string format.Iki mesthine minangka harfiah senar.Daya saka senar format ing: {}: s sing.
///
/// Parameter tambahan sing diwenehake menyang `format!` ngganti `{}` ing string format ing urutan sing diwenehake kajaba paramèter sing dijenengi utawa posisi digunakake;deleng [`std::fmt`] kanggo informasi luwih lengkap.
///
///
/// Panggunaan umum kanggo `format!` yaiku concatenation lan interpolation of strings.
/// Konvensi sing padha digunakake karo makro [`print!`] lan [`write!`], gumantung karo tujuan sing dituju kanggo senar kasebut.
///
/// Kanggo ngowahi siji nilai menyang senar, gunakake cara [`to_string`].Iki bakal nggunakake format [`Display`] trait.
///
/// [`std::fmt`]: ../std/fmt/index.html
/// [`print!`]: ../std/macro.print.html
/// [`write!`]: core::write
/// [`to_string`]: crate::string::ToString
/// [`Display`]: core::fmt::Display
///
/// # Panics
///
/// `format!` panics yen implementasi format trait ngasilake kesalahan.
/// Iki nuduhake implementasi sing salah amarga `fmt::Write for String` ora nate ngasilake kesalahan.
///
/// # Examples
///
/// ```
/// format!("test");
/// format!("hello {}", "world!");
/// format!("x = {}, y = {y}", 10, y = 30);
/// ```
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "format_macro")]
macro_rules! format {
    ($($arg:tt)*) => {{
        let res = $crate::fmt::format($crate::__export::format_args!($($arg)*));
        res
    }}
}

/// Meksa simpul AST menyang ekspresi kanggo nambah diagnostik ing posisi pola.
#[doc(hidden)]
#[macro_export]
#[unstable(feature = "liballoc_internals", issue = "none", reason = "implementation detail")]
macro_rules! __rust_force_expr {
    ($e:expr) => {
        $e
    };
}