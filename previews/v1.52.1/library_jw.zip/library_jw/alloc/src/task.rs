#![stable(feature = "wake_trait", since = "1.51.0")]
//! Jinis lan Traits kanggo nggarap tugas bedo.
use core::mem::ManuallyDrop;
use core::task::{RawWaker, RawWakerVTable, Waker};

use crate::sync::Arc;

/// Implementasi nggugah tugas marang pelaksana.
///
/// trait iki bisa digunakake kanggo nggawe [`Waker`].
/// Pelaksana bisa netepake implementasine trait iki, lan nggunakake aplikasi kasebut kanggo nggawe Waker supaya bisa tugas sing dileksanakake marang pelaksana kasebut.
///
/// trait iki minangka alternatif memori-aman lan ergonomis kanggo mbangun [`RawWaker`].
/// Ndhukung desain pelaksana umum ing endi data sing digunakake kanggo nggawe tugas disimpen ing [`Arc`].
/// Sawetara eksekutor (utamane sing kanggo sistem semat) ora bisa nggunakake API iki, mulane [`RawWaker`] ana minangka alternatif kanggo sistem kasebut.
///
/// [arc]: ../../std/sync/struct.Arc.html
///
/// # Examples
///
/// Fungsi `block_on` dhasar sing njupuk future lan bisa rampung ing utas saiki.
///
/// **Note:** Contone iki dagang bener kanggo kesederhanaan.
/// Kanggo nyegah buntu, implementasi kelas produksi uga kudu ngatasi panggilan menengah menyang `thread::unpark` uga invasi sing disarangake.
///
///
/// ```rust
/// use std::future::Future;
/// use std::sync::Arc;
/// use std::task::{Context, Poll, Wake};
/// use std::thread::{self, Thread};
///
/// /// Tangga sing nggugah utas saiki nalika ditelpon.
/// struct ThreadWaker(Thread);
///
/// impl Wake for ThreadWaker {
///     fn wake(self: Arc<Self>) {
///         self.0.unpark();
///     }
/// }
///
/// /// Jalanake future nganti rampung ing utas saiki.
/// fn block_on<T>(fut: impl Future<Output = T>) -> T {
///     // Semat future supaya bisa poling.
///     let mut fut = Box::pin(fut);
///
///     // Gawe konteks anyar sing bakal diterusake menyang future.
///     let t = thread::current();
///     let waker = Arc::new(ThreadWaker(t)).into();
///     let mut cx = Context::from_waker(&waker);
///
///     // Jalanake future nganti rampung.
///     loop {
///         match fut.as_mut().poll(&mut cx) {
///             Poll::Ready(res) => return res,
///             Poll::Pending => thread::park(),
///         }
///     }
/// }
///
/// block_on(async {
///     println!("Hi from inside a future!");
/// });
/// ```
///
///
///
///
#[stable(feature = "wake_trait", since = "1.51.0")]
pub trait Wake {
    /// Tangi tugas iki.
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake(self: Arc<Self>);

    /// Tindakake tugas iki tanpa nggunakake waker.
    ///
    /// Yen eksekutor ndhukung cara sing luwih murah kanggo tangi tanpa nggunakake waker, mesthine kudu ngilangi metode iki.
    /// Kanthi gawan, kloning [`Arc`] lan nelpon [`wake`] ing Klone.
    ///
    /// [`wake`]: Wake::wake
    ///
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake_by_ref(self: &Arc<Self>) {
        self.clone().wake();
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for Waker {
    fn from(waker: Arc<W>) -> Waker {
        // SAFETY: Iki aman amarga raw_waker dibangun kanthi aman
        // RawWaker saka Arc<W>.
        unsafe { Waker::from_raw(raw_waker(waker)) }
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for RawWaker {
    fn from(waker: Arc<W>) -> RawWaker {
        raw_waker(waker)
    }
}

// NB: Fungsi pribadi kanggo mbangun RawWaker digunakake, tinimbang
// inlining iki menyang impl `From<Arc<W>> for RawWaker`, supaya keamanan `From<Arc<W>> for Waker` ora gumantung karo pengiriman trait sing bener, nanging kaloro impls kasebut nelpon fungsi iki kanthi langsung lan eksplisit.
//
//
//
#[inline(always)]
fn raw_waker<W: Wake + Send + Sync + 'static>(waker: Arc<W>) -> RawWaker {
    // Tambah jumlah referensi busur kanggo Klone.
    unsafe fn clone_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) -> RawWaker {
        unsafe { Arc::increment_strong_count(waker as *const W) };
        RawWaker::new(
            waker as *const (),
            &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
        )
    }

    // Tangi kanthi regane, ngalihake Arc menyang fungsi Wake::wake
    unsafe fn wake<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { Arc::from_raw(waker as *const W) };
        <W as Wake>::wake(waker);
    }

    // Bangun kanthi referensi, bungkus waker ing ManualDrop supaya ora ngeculake
    unsafe fn wake_by_ref<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { ManuallyDrop::new(Arc::from_raw(waker as *const W)) };
        <W as Wake>::wake_by_ref(&waker);
    }

    // Ngurangi jumlah referensi Arc nalika nyelehake
    unsafe fn drop_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        unsafe { Arc::decrement_strong_count(waker as *const W) };
    }

    RawWaker::new(
        Arc::into_raw(waker) as *const (),
        &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
    )
}