#![stable(feature = "rust1", since = "1.0.0")]

//! Tunjuk-ngitung referensi-aman benang.
//!
//! Deleng dokumentasi [`Arc<T>`][Arc] kanggo rincian liyane.

use core::any::Any;
use core::borrow;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::hint;
use core::intrinsics::abort;
use core::iter;
use core::marker::{PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;
use core::sync::atomic;
use core::sync::atomic::Ordering::{Acquire, Relaxed, Release, SeqCst};

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::rc::is_dangling;
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

/// Watesan alus babagan jumlah referensi sing bisa digawe ing `Arc`.
///
/// Ndhuwur watesan iki bakal ngilangi program sampeyan (sanajan ora prelu) ing referensi _exactly_ `MAX_REFCOUNT + 1`.
///
const MAX_REFCOUNT: usize = (isize::MAX) as usize;

#[cfg(not(sanitize = "thread"))]
macro_rules! acquire {
    ($x:expr) => {
        atomic::fence(Acquire)
    };
}

// ThreadSanitizer ora ndhukung pager memori.
// Kanggo ngindhari laporan positif palsu ing implementasine Arc/Lemah, gunakake akeh atom kanggo sinkronisasi.
//
#[cfg(sanitize = "thread")]
macro_rules! acquire {
    ($x:expr) => {
        $x.load(Acquire)
    };
}

/// Pointer referensi-ngitung referensi sing aman.'Arc' tegese 'Atomically Reference Counted'.
///
/// Jinis `Arc<T>` nyedhiyakake pamilikan bareng kanggo jinis `T`, dialokasikan ing tumpukan.Nganggo [`clone`][clone] ing `Arc` ngasilake conto `Arc` anyar, sing nuduhake alokasi sing padha ing tumpukan kaya sumber `Arc`, nalika nambah jumlah referensi.
/// Nalika penunjuk `Arc` pungkasan menyang alokasi tartamtu bakal rusak, regane sing disimpen ing alokasi kasebut (asring diarani "inner value") uga bakal mudhun.
///
/// Referensi sing dituduhake ing Rust ora ngidini mutasi kanthi standar, lan `Arc` ora ana sing istimewane: sampeyan umume ora bisa entuk referensi sing bisa diowahi kanggo `Arc`.Yen sampeyan kudu mutasi `Arc`, gunakake [`Mutex`][mutex], [`RwLock`][rwlock], utawa salah sawijining jinis [`Atomic`][atomic].
///
/// ## Keselamatan Utas
///
/// Beda karo [`Rc<T>`], `Arc<T>` nggunakake operasi atom kanggo ngetang referensi.Iki tegese aman ing Utas.Kerugiane yaiku operasi atom luwih larang tinimbang akses memori biasa.Yen sampeyan ora nuduhake alokasi sing dietung referensi ing antarane utas, coba gunakake [`Rc<T>`] kanggo overhead ngisor.
/// [`Rc<T>`] minangka standar sing aman, amarga kompiler bakal nyoba nyoba ngirim [`Rc<T>`] ing antarane utas.
/// Nanging, perpustakaan bisa milih `Arc<T>` supaya konsumen bisa terus luwes.
///
/// `Arc<T>` bakal ngetrapake [`Send`] lan [`Sync`] anggere `T` ngetrapake [`Send`] lan [`Sync`].
/// Napa sampeyan ora bisa nyelehake jinis `T` sing ora aman ing `Arc<T>` supaya aman karo Utas?Wiwitane bisa uga rada counter-intuitive: sawise kabeh, apa ora titik keamanan `Arc<T>` thread?Intine yaiku: `Arc<T>` nggawe benang aman kanggo nduwe macem-macem data sing padha, nanging ora nambah keamanan utas ing datane.
///
/// Coba `Arc <` ['RefCell<T>`]`> `.
/// [`RefCell<T>`] dudu [`Sync`], lan yen `Arc<T>` mesthi [`Send`], `Arc <` ['RefCell<T>`]`> `uga bakal dadi.
/// Nanging kita bakal duwe masalah:
/// [`RefCell<T>`] ora aman Utas;nglacak jumlah utang nalika nggunakake operasi non-atom.
///
/// Pungkasane, iki tegese sampeyan kudu masangake `Arc<T>` kanthi jinis [`std::sync`], biasane [`Mutex<T>`][mutex].
///
/// ## Siklus rusak kanthi `Weak`
///
/// Cara [`downgrade`][downgrade] bisa digunakake kanggo nggawe pointer [`Weak`] sing ora duwe.Penunjuk [`Weak`] bisa dadi [`upgrade`][upgrade] d menyang `Arc`, nanging iki bakal ngasilake [`None`] yen nilai sing disimpen ing alokasi wis mudhun.
/// Kanthi tembung liyane, petunjuk `Weak` ora tetep njaga nilai ing alokasi kasebut;Nanging, dheweke * tetep njaga alokasi (toko cadangan kanggo regane) supaya tetep urip.
///
/// Siklus ing antarane petunjuk `Arc` ora bakal bisa ditanggepi.
/// Amarga iku, [`Weak`] digunakake kanggo ngilangi siklus.Contone, wit bisa duwe petunjuk `Arc` sing kuat saka simpul induk nganti bocah, lan [`Weak`] pitunjuk saka bocah bali menyang wong tuwa.
///
/// # Referensi kloning
///
/// Nggawe referensi anyar saka pitunjuk referensi sing wis dietung wis rampung nggunakake `Clone` trait sing dileksanakake kanggo [`Arc<T>`][Arc] lan [`Weak<T>`][Weak].
///
/// ```
/// use std::sync::Arc;
/// let foo = Arc::new(vec![1.0, 2.0, 3.0]);
/// // Kaloro sintaks ing ngisor iki padha.
/// let a = foo.clone();
/// let b = Arc::clone(&foo);
/// // a, b, lan foo iku kabeh busur sing nuduhake lokasi memori sing padha
/// ```
///
/// ## `Deref` behavior
///
/// `Arc<T>` kanthi otomatis ngilangi referensi menyang `T` (liwat [`Deref`][deref] trait), mula sampeyan bisa nelpon metode `T` kanthi nilai jinis `Arc<T>`.Kanggo ngindhari bentrokan jeneng karo metode `T`, metode `Arc<T>` dhewe minangka fungsi sing gegandhengan, diarani nggunakake [fully qualified syntax]:
///
/// ```
/// use std::sync::Arc;
///
/// let my_arc = Arc::new(());
/// Arc::downgrade(&my_arc);
/// ```
///
/// `Arc<T>Implementasine traits kaya `Clone` bisa uga diarani nggunakake sintaks kualifikasi.
/// Sawetara wong seneng nggunakake sintaks sing nduweni kualifikasi, dene sing liyane seneng nggunakake sintaks-panggilan metode.
///
/// ```
/// use std::sync::Arc;
///
/// let arc = Arc::new(());
/// // Sintaks metode-call
/// let arc2 = arc.clone();
/// // Sintaks sing nduweni kualifikasi
/// let arc3 = Arc::clone(&arc);
/// ```
///
/// [`Weak<T>`][Weak] ora otomatis ngilangi `T`, amarga nilai batin bisa uga wis mudhun.
///
/// [`Rc<T>`]: crate::rc::Rc
/// [clone]: Clone::clone
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [atomic]: core::sync::atomic
/// [`Send`]: core::marker::Send
/// [`Sync`]: core::marker::Sync
/// [deref]: core::ops::Deref
/// [downgrade]: Arc::downgrade
/// [upgrade]: Weak::upgrade
/// [`RefCell<T>`]: core::cell::RefCell
/// [`std::sync`]: ../../std/sync/index.html
/// [`Arc::clone(&from)`]: Arc::clone
/// [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
///
/// # Examples
///
/// Nuduhake sawetara data sing ora bisa diowahi ing antarane utas:
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
// Elinga yen kita **ora** mbukak tes iki ing kene.
// Tukang bangunan windows dadi ora seneng banget yen utas luwih gedhe tinimbang utas utama banjur metu sekaligus (ana sawetara buntu) mula kita kabeh ora bisa ngindhari tes kasebut.
//
//
/// ```no_run
/// use std::sync::Arc;
/// use std::thread;
///
/// let five = Arc::new(5);
///
/// for _ in 0..10 {
///     let five = Arc::clone(&five);
///
///     thread::spawn(move || {
///         println!("{:?}", five);
///     });
/// }
/// ```
///
/// Nuduhake [`AtomicUsize`] sing bisa diowahi:
///
/// [`AtomicUsize`]: core::sync::atomic::AtomicUsize
///
/// ```no_run
/// use std::sync::Arc;
/// use std::sync::atomic::{AtomicUsize, Ordering};
/// use std::thread;
///
/// let val = Arc::new(AtomicUsize::new(5));
///
/// for _ in 0..10 {
///     let val = Arc::clone(&val);
///
///     thread::spawn(move || {
///         let v = val.fetch_add(1, Ordering::SeqCst);
///         println!("{:?}", v);
///     });
/// }
/// ```
///
/// Deleng [`rc` documentation][rc_examples] kanggo conto liyane babagan ngetang referensi umume.
///
///
/// [rc_examples]: crate::rc#examples
#[cfg_attr(not(test), rustc_diagnostic_item = "Arc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Arc<T: ?Sized> {
    ptr: NonNull<ArcInner<T>>,
    phantom: PhantomData<ArcInner<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Arc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Arc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Arc<U>> for Arc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Arc<U>> for Arc<T> {}

impl<T: ?Sized> Arc<T> {
    fn from_inner(ptr: NonNull<ArcInner<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut ArcInner<T>) -> Self {
        unsafe { Self::from_inner(NonNull::new_unchecked(ptr)) }
    }
}

/// `Weak` minangka versi [`Arc`] sing nyekel referensi sing ora duwe alokasi ngatur.
/// Alokasi kasebut diakses kanthi nelpon [`upgrade`] ing pointer `Weak`, sing ngasilake [`Option`]`<`[Arc`]`<T>> `.
///
/// Amarga referensi `Weak` ora dianggep nduweni, mula ora bakal nyegah regane sing disimpen ing alokasi supaya mudhun, lan `Weak` dhewe ora menehi jaminan babagan nilai sing isih ana.
///
/// Mangkono bisa ngasilake [`None`] nalika [`upgrade`] d.
/// Nanging, elinga yen referensi `Weak`*ora* nyegah alokasi dhewe (toko cadangan) supaya ora bisa ditanggepi.
///
/// Penunjuk `Weak` migunani kanggo njaga referensi sementara kanggo alokasi sing dikelola dening [`Arc`] tanpa nyegah nilai batin saka mudhun.
/// Iki uga digunakake kanggo nyegah referensi bunder ing antarane pointer [`Arc`], amarga referensi ndhuweni bebarengan ora bakal ngidini [`Arc`] dicopot.
/// Contone, wit bisa duwe petunjuk [`Arc`] sing kuat saka simpul induk nganti bocah, lan petunjuk `Weak` saka bocah bali menyang wong tuwa.
///
/// Cara khas kanggo entuk pointer `Weak` yaiku nelpon [`Arc::downgrade`].
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
#[stable(feature = "arc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // Iki minangka `NonNull` kanggo ngidini ngoptimalake ukuran jinis iki ing enum, nanging durung mesthi penunjuk sing bener.
    //
    // `Weak::new` setel iki menyang `usize::MAX` supaya ora prelu ngisi ruang ing tumpukan kasebut.
    // Iki dudu nilai sing bakal diduweni pointer nyata amarga RcBox duwe alignment paling ora 2.
    // Iki mung bisa ditindakake nalika `T: Sized`;`T` tanpa ukuran ora tau digantung.
    //
    ptr: NonNull<ArcInner<T>>,
}

#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Weak<T> {}
#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

// Iki minangka bukti repr(C) nganti future tumrap panyuntingan lapangan sing bisa uga, sing bakal ngganggu [into|from]_raw() sing aman saka jinis njero sing bisa ditularake.
//
//
#[repr(C)]
struct ArcInner<T: ?Sized> {
    strong: atomic::AtomicUsize,

    // regane usize::MAX tumindak minangka sentinel kanggo sementara "locking" kemampuan kanggo nganyarke petunjuk sing lemah utawa nyuda versi sing kuwat;iki digunakake kanggo ngindhari balapan ing `make_mut` lan `get_mut`.
    //
    //
    weak: atomic::AtomicUsize,

    data: T,
}

unsafe impl<T: ?Sized + Sync + Send> Send for ArcInner<T> {}
unsafe impl<T: ?Sized + Sync + Send> Sync for ArcInner<T> {}

impl<T> Arc<T> {
    /// Mbangun `Arc<T>` anyar.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(data: T) -> Arc<T> {
        // Miwiti jumlah pitunjuk sing ringkih minangka 1 yaiku pitunjuk sing lemah sing dicekel dening kabeh petunjuk (kinda), deleng std/rc.rs kanggo info lengkap
        //
        let x: Box<_> = box ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        };
        Self::from_inner(Box::leak(x).into())
    }

    /// Mbangun `Arc<T>` anyar kanthi nggunakake referensi sing ringkih.
    /// Upaya nganyari referensi sing ringkih sadurunge fungsi iki ngasilake bakal ngasilake nilai `None`.
    /// Nanging, referensi sing ringkih bisa dikloning kanthi bebas lan disimpen kanggo digunakake mengko wektu.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    ///
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo {
    ///     me: Weak<Foo>,
    /// }
    ///
    /// let foo = Arc::new_cyclic(|me| Foo {
    ///     me: me.clone(),
    /// });
    /// ```
    #[inline]
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Arc<T> {
        // Mbangun bagian jero ing negara "uninitialized" kanthi siji referensi sing ringkih.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box ArcInner {
            strong: atomic::AtomicUsize::new(0),
            weak: atomic::AtomicUsize::new(1),
            data: mem::MaybeUninit::<T>::uninit(),
        })
        .into();
        let init_ptr: NonNull<ArcInner<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // Penting, kita aja nyerah kepemilikan pitunjuk sing ringkih, utawa memori bisa uga dibebasake nalika `data_fn` bali.
        // Yen pancene pengin ngliwati kepemilikan, kita bisa nggawe petunjuk tambahan sing ringkih kanggo awake dhewe, nanging iki bakal nyebabake tambahan nganyari jumlah referensi sing ringkih sing bisa uga ora perlu.
        //
        //
        //
        //
        let data = data_fn(&weak);

        // Saiki kita bisa kanthi bener nggawe inisial bathi lan ngowahi referensi sing ringkih dadi referensi sing kuat.
        //
        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).data), data);

            // Tulis ing ndhuwur lapangan ing data kudu katon ing sembarang utas sing bisa ngetung jumlah sing dudu nol.
            // Mula, kita paling ora butuh pesen "Release" supaya bisa nyinkronake karo `compare_exchange_weak` ing `Weak::upgrade`.
            //
            // "Acquire" pesenan ora dibutuhake.
            // Nalika ngelingi tumindak sing bisa `data_fn`, kita mung kudu ndeleng apa sing bisa ditindakake kanthi referensi `Weak` sing ora bisa dianyari:
            //
            // - Bisa *kloning*`Weak`, nambah jumlah referensi sing ringkih.
            // - Iki bisa nyelehake klon kasebut, nyuda jumlah referensi sing ringkih (nanging ora bakal nol).
            //
            // Efek samping iki ora mengaruhi kita apa wae, lan ora ana efek samping liyane sing bisa ditindakake kanthi kode aman wae.
            //
            //
            let prev_value = (*inner).strong.fetch_add(1, Release);
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
        }

        let strong = Arc::from_inner(init_ptr);

        // Referensi sing kuat kudu duwe referensi sing ringkes bareng, mula aja ngrusak kanggo referensi lawas sing ringkih.
        //
        mem::forget(weak);
        strong
    }

    /// Mbangun `Arc` anyar kanthi konten sing durung diresmine.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Inisialisasi sing ditundha:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Mbangun `Arc` anyar kanthi konten sing durung diresmine, kanthi memori diisi karo bait `0`.
    ///
    ///
    /// Deleng [`MaybeUninit::zeroed`][zeroed] kanggo conto panggunaan metode sing bener lan salah.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Mbangun `Pin<Arc<T>>` anyar.
    /// Yen `T` ora ngetrapake `Unpin`, mula `data` bakal disematake ing memori lan ora bisa dipindhah.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(data: T) -> Pin<Arc<T>> {
        unsafe { Pin::new_unchecked(Arc::new(data)) }
    }

    /// Mbangun `Arc<T>` anyar, ngasilake kesalahan yen alokasi gagal.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::sync::Arc;
    ///
    /// let five = Arc::try_new(5)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new(data: T) -> Result<Arc<T>, AllocError> {
        // Miwiti jumlah pitunjuk sing ringkih minangka 1 yaiku pitunjuk sing lemah sing dicekel dening kabeh petunjuk (kinda), deleng std/rc.rs kanggo info lengkap
        //
        let x: Box<_> = Box::try_new(ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        })?;
        Ok(Self::from_inner(Box::leak(x).into()))
    }

    /// Mbangun `Arc` anyar kanthi konten sing durung diresmine, ngasilake kesalahan yen alokasi gagal.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // Inisialisasi sing ditundha:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// Mbangun `Arc` anyar kanthi konten sing ora diresmine, kanthi memori diisi byte `0`, ngasilake kesalahan yen alokasi gagal.
    ///
    ///
    /// Deleng [`MaybeUninit::zeroed`][zeroed] kanggo conto panggunaan metode sing bener lan salah.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// Ngasilake nilai batin, yen `Arc` duwe siji referensi sing kuat.
    ///
    /// Yen ora, [`Err`] bakal bali kanthi `Arc` sing padha dilewati.
    ///
    ///
    /// Iki bakal sukses sanajan ana referensi sing ringkih.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new(3);
    /// assert_eq!(Arc::try_unwrap(x), Ok(3));
    ///
    /// let x = Arc::new(4);
    /// let _y = Arc::clone(&x);
    /// assert_eq!(*Arc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if this.inner().strong.compare_exchange(1, 0, Relaxed, Relaxed).is_err() {
            return Err(this);
        }

        acquire!(this.inner().strong);

        unsafe {
            let elem = ptr::read(&this.ptr.as_ref().data);

            // Gawe pitunjuk sing ringkih kanggo ngresiki referensi sing kuwat banget
            let _weak = Weak { ptr: this.ptr };
            mem::forget(this);

            Ok(elem)
        }
    }
}

impl<T> Arc<[T]> {
    /// Mbangun irisan sing diitung kanthi referensi atom kanthi isi sing durung dinamis.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Inisialisasi sing ditundha:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe { Arc::from_ptr(Arc::allocate_for_slice(len)) }
    }

    /// Mbangun irisan sing diitung kanthi referensi atom kanthi isi sing ora dinamis, kanthi memori diisi karo bait `0`.
    ///
    ///
    /// Deleng [`MaybeUninit::zeroed`][zeroed] kanggo conto panggunaan metode sing bener lan salah.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let values = Arc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut ArcInner<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Arc<mem::MaybeUninit<T>> {
    /// Ngonversi menyang `Arc<T>`.
    ///
    /// # Safety
    ///
    /// Kaya ing [`MaybeUninit::assume_init`], dadi panelpon kanggo njamin manawa bathi tenan ana ing negara sing diwiwiti.
    ///
    /// Nelpon iki nalika konten durung diwiwiti kanthi otomatis nyebabake prilaku sing durung ditemtokake langsung.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Inisialisasi sing ditundha:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<T> {
        Arc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Arc<[mem::MaybeUninit<T>]> {
    /// Ngonversi menyang `Arc<[T]>`.
    ///
    /// # Safety
    ///
    /// Kaya ing [`MaybeUninit::assume_init`], dadi panelpon kanggo njamin manawa bathi tenan ana ing negara sing diwiwiti.
    ///
    /// Nelpon iki nalika konten durung diwiwiti kanthi otomatis nyebabake prilaku sing durung ditemtokake langsung.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Inisialisasi sing ditundha:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<[T]> {
        unsafe { Arc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// Nganggo `Arc`, ngasilake pitunjuk sing dibungkus.
    ///
    /// Kanggo ngindhari bocor memori, pointer kudu diowahi dadi `Arc` nggunakake [`Arc::from_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// Nyedhiyakake pitunjuk mentah kanggo data.
    ///
    /// Jumlah ora kena pengaruh ing sembarang cara lan `Arc` ora dikonsumsi.
    /// Pointer bener yen ana jumlah sing kuwat ing `Arc`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let y = Arc::clone(&x);
    /// let x_ptr = Arc::as_ptr(&x);
    /// assert_eq!(x_ptr, Arc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(this.ptr);

        // SAFETY: Iki ora bisa dilewati Deref::deref utawa RcBoxPtr::inner amarga
        // iki dibutuhake kanggo njaga bukti asli raw/mut, kayata
        // `get_mut` bisa nulis liwat pointer sawise Rc dibalekake liwat `from_raw`.
        unsafe { ptr::addr_of_mut!((*ptr).data) }
    }

    /// Mbangun `Arc<T>` saka pitunjuk mentah.
    ///
    /// Pointer mentah kudu sadurunge bali nganggo telpon menyang [`Arc<U>::into_raw`][into_raw] ing endi `U` kudu duwe ukuran lan jajaran sing padha karo `T`.
    /// Iki pancen sepele yen `U` yaiku `T`.
    /// Elinga yen `U` dudu `T` nanging nduweni ukuran lan jajaran sing padha, iki biasane kaya referensi transmisi saka macem-macem jinis.
    /// Deleng [`mem::transmute`][transmute] kanggo informasi luwih lengkap babagan watesan apa sing ditrapake ing kasus iki.
    ///
    /// Pangguna `from_raw` kudu nggawe manawa nilai tartamtu `T` mung ambruk sapisan.
    ///
    /// Fungsi iki ora aman amarga panggunaan sing ora bener bisa nyebabake memori ora aman, sanajan `Arc<T>` bali ora nate diakses.
    ///
    /// [into_raw]: Arc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    ///
    /// unsafe {
    ///     // Ngonversi maneh menyang `Arc` kanggo nyegah bocor.
    ///     let x = Arc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // Telpon maneh menyang `Arc::from_raw(x_ptr)` bakal ora aman ing memori.
    /// }
    ///
    /// // Memori dibebasake nalika `x` metu saka ruang lingkup ing ndhuwur, mula `x_ptr` saiki lagi nggantung!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        unsafe {
            let offset = data_offset(ptr);

            // Mbalikake offset kanggo nemokake ArcInner asli.
            let arc_ptr = (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset));

            Self::from_ptr(arc_ptr)
        }
    }

    /// Nggawe penunjuk [`Weak`] anyar kanggo alokasi iki.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        // Relaksasi iki OK amarga kita mriksa regane ing CAS ing ngisor iki.
        //
        let mut cur = this.inner().weak.load(Relaxed);

        loop {
            // mriksa manawa counter sing ringkih saiki "locked";yen mangkono, muter.
            if cur == usize::MAX {
                hint::spin_loop();
                cur = this.inner().weak.load(Relaxed);
                continue;
            }

            // NOTE: kode iki saiki ora nggatekake kemungkinan kebanjiran
            // menyang usize::MAX;umume, Rc lan Arc kudu disesuaikan kanggo ngatasi kebanjiran.
            //

            // Beda karo Clone(), kita prelu dadi Acquire read kanggo nyinkronake karo tulisan sing asale saka `is_unique`, supaya kedadeyan sadurunge nulis kasebut kedadeyan sadurunge diwaca iki.
            //
            //
            match this.inner().weak.compare_exchange_weak(cur, cur + 1, Acquire, Relaxed) {
                Ok(_) => {
                    // Priksa manawa kita ora nggawe Lemah sing mudhun
                    debug_assert!(!is_dangling(this.ptr.as_ptr()));
                    return Weak { ptr: this.ptr };
                }
                Err(old) => cur = old,
            }
        }
    }

    /// Entuk jumlah petunjuk [`Weak`] menyang alokasi iki.
    ///
    /// # Safety
    ///
    /// Cara iki kanthi aman, nanging nggunakake kanthi bener kudu luwih ati-ati.
    /// Utas liyane bisa ngganti jumlah sing ringkih kapan wae, kalebu potensial antarane nelpon metode iki lan tumindak miturut asil.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _weak_five = Arc::downgrade(&five);
    ///
    /// // Pratelan iki ditemtokake amarga kita durung nuduhake `Arc` utawa `Weak` ing antarane utas.
    /////
    /// assert_eq!(1, Arc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        let cnt = this.inner().weak.load(SeqCst);
        // Yen jumlah sing ringkih saiki dikunci, regane ngetung yaiku 0 sadurunge njupuk kunci.
        //
        if cnt == usize::MAX { 0 } else { cnt - 1 }
    }

    /// Entuk jumlah petunjuk (`Arc`) sing kuwat kanggo alokasi iki.
    ///
    /// # Safety
    ///
    /// Cara iki kanthi aman, nanging nggunakake kanthi bener kudu luwih ati-ati.
    /// Utas liyane bisa ngganti jumlah sing kuwat kapan wae, kalebu potensial antarane nelpon metode iki lan tumindak miturut asil.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _also_five = Arc::clone(&five);
    ///
    /// // Penegasan iki ditemtokake amarga durung nuduhake `Arc` ing antarane utas.
    /////
    /// assert_eq!(2, Arc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong.load(SeqCst)
    }

    /// Nambah jumlah referensi sing kuat ing `Arc<T>` sing ana gandhengane karo pitunjuk sing diwenehake kanthi siji.
    ///
    /// # Safety
    ///
    /// Pointer kudu dipikolehi liwat `Arc::into_raw`, lan conto `Arc` sing gegandhengan kudu valid (yaiku
    /// jumlah sing kuwat kudu paling ora 1) suwene metode iki.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // Penegasan iki ditemtokake amarga durung nuduhake `Arc` ing antarane utas.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn increment_strong_count(ptr: *const T) {
        // Tahan Arc, nanging aja ndemek mundur maneh kanthi mbungkus ing ManualDrop
        let arc = unsafe { mem::ManuallyDrop::new(Arc::<T>::from_raw(ptr)) };
        // Saiki tambah maneh, nanging aja uga ngeculake maneh
        let _arc_clone: mem::ManuallyDrop<_> = arc.clone();
    }

    /// Ngurangi jumlah referensi sing kuat ing `Arc<T>` sing ana gandhengane karo pitunjuk sing diwenehake siji.
    ///
    /// # Safety
    ///
    /// Pointer kudu dipikolehi liwat `Arc::into_raw`, lan conto `Arc` sing gegandhengan kudu valid (yaiku
    /// jumlah sing kuat kudu paling ora 1) nalika nggunakake metode iki.
    /// Cara iki bisa digunakake kanggo ngeculake `Arc` final lan panyimpenan cadangan, nanging **ora kudu** ditelpon sawise `Arc` final dirilis.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // Pratelan kasebut ditemtokake amarga kita durung nuduhake `Arc` ing antarane utas.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    ///     Arc::decrement_strong_count(ptr);
    ///     assert_eq!(1, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn decrement_strong_count(ptr: *const T) {
        unsafe { mem::drop(Arc::from_raw(ptr)) };
    }

    #[inline]
    fn inner(&self) -> &ArcInner<T> {
        // Ketahanan sing aman iki ora apa-apa amarga busar iki isih urip, kita bakal menehi petunjuk manawa petunjuk internal bener.
        // Salajengipun, kita ngerti manawa struktur `ArcInner` dhewe yaiku `Sync` amarga data batin uga `Sync`, mula kita ora bisa menehi petunjuk babagan konten kasebut.
        //
        //
        //
        unsafe { self.ptr.as_ref() }
    }

    // Bagean non-garis `drop`.
    #[inline(never)]
    unsafe fn drop_slow(&mut self) {
        // Rusak data saiki, sanajan kita ora bisa mbebasake alokasi kothak dhewe (bisa uga isih ana petunjuk sing ringkih).
        //
        unsafe { ptr::drop_in_place(Self::get_mut_unchecked(self)) };

        // Selehake ref sing kuwat dikelola dening kabeh referensi sing kuat
        drop(Weak { ptr: self.ptr });
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// Ngasilake `true` yen loro `Arc`s nuduhake alokasi sing padha (ing pembuluh getih padha karo [`ptr::eq`]).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let same_five = Arc::clone(&five);
    /// let other_five = Arc::new(5);
    ///
    /// assert!(Arc::ptr_eq(&five, &same_five));
    /// assert!(!Arc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: ?Sized> Arc<T> {
    /// Alokasi `ArcInner<T>` kanthi papan sing cukup kanggo nilai batin sing bisa diukur yen regane wis diwenehake.
    ///
    /// Fungsi `mem_to_arcinner` diarani nganggo data pointer lan kudu mbalekake (berpotensi lemu)-pointer kanggo `ArcInner<T>`.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> *mut ArcInner<T> {
        // Ngetung tata letak nggunakake tata letak nilai sing diwenehake.
        // Sadurunge, tata letak diitung ing ekspresi `&*(ptr as* const ArcInner<T>)`, nanging iki nggawe referensi sing salah (deleng #54908).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Arc::try_allocate_for_layout(value_layout, allocate, mem_to_arcinner)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// Alokasi `ArcInner<T>` kanthi papan sing cukup kanggo nilai batin sing bisa diukur yen regane wis diwenehi tata letak, ngasilake kesalahan yen alokasi gagal.
    ///
    ///
    /// Fungsi `mem_to_arcinner` diarani nganggo data pointer lan kudu mbalekake (berpotensi lemu)-pointer kanggo `ArcInner<T>`.
    ///
    ///
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> Result<*mut ArcInner<T>, AllocError> {
        // Ngetung tata letak nggunakake tata letak nilai sing diwenehake.
        // Sadurunge, tata letak diitung ing ekspresi `&*(ptr as* const ArcInner<T>)`, nanging iki nggawe referensi sing salah (deleng #54908).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();

        let ptr = allocate(layout)?;

        // Initialisasi ArcInner
        let inner = mem_to_arcinner(ptr.as_non_null_ptr().as_ptr());
        debug_assert_eq!(unsafe { Layout::for_value(&*inner) }, layout);

        unsafe {
            ptr::write(&mut (*inner).strong, atomic::AtomicUsize::new(1));
            ptr::write(&mut (*inner).weak, atomic::AtomicUsize::new(1));
        }

        Ok(inner)
    }

    /// Alokasi `ArcInner<T>` kanthi papan sing cukup kanggo nilai batin sing durung diukur.
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut ArcInner<T> {
        // Alokasi `ArcInner<T>` nggunakake nilai sing diwenehake.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut ArcInner<T>).set_ptr_value(mem) as *mut ArcInner<T>,
            )
        }
    }

    fn from_box(v: Box<T>) -> Arc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // Nilai salinan minangka bait
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).data as *mut _ as *mut u8,
                value_size,
            );

            // Gratisake alokasi kasebut tanpa ngeculake isine
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Arc<[T]> {
    /// Alokasi `ArcInner<[T]>` kanthi dawa sing diwenehake.
    unsafe fn allocate_for_slice(len: usize) -> *mut ArcInner<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut ArcInner<[T]>,
            )
        }
    }

    /// Salin elemen saka irisan menyang Arc <\[T\]> sing mentas dialokasikan
    ///
    /// Ora aman amarga panelpon kudu duwe kepemilikan utawa obligasi `T: Copy`.
    unsafe fn copy_from_slice(v: &[T]) -> Arc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());

            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).data as *mut [T] as *mut T, v.len());

            Self::from_ptr(ptr)
        }
    }

    /// Mbangun `Arc<[T]>` saka iterator sing dingerteni ukuran tartamtu.
    ///
    /// Prilaku ora bisa ditemtokake manawa ukurane salah.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Arc<[T]> {
        // Panic njaga nalika kloning elemen T.
        // Yen ana panic, elemen sing wis ditulis menyang ArcInner anyar bakal mudhun, banjur memori dibebasake.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // Pointer kanggo elemen pisanan
            let elems = &mut (*ptr).data as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // Kabeh jelas.Lali penjaga supaya ora gratis ArcInner anyar.
            mem::forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// Spesialisasi trait digunakake kanggo `From<&[T]>`.
trait ArcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Arc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Arc<T> {
    /// Nggawe klon penunjuk `Arc`.
    ///
    /// Iki nggawe penunjuk liyane menyang alokasi sing padha, nambah jumlah referensi sing kuwat.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let _ = Arc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Arc<T> {
        // Nggunakake pesenan santai apa wae ing kene, amarga pengetahuan babagan referensi asli ngalangi utas liyane supaya ora sengaja mbusak obyek kasebut.
        //
        // Kaya sing diandharake ing [Boost documentation][1], Nambah counter referensi bisa ditindakake kanthi memory_order_relaxed: Referensi anyar kanggo obyek mung bisa digawe saka referensi sing ana, lan ngirim referensi sing ana saka siji utas menyang thread liyane kudu nyediakake sinkronisasi sing dibutuhake.
        //
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        //
        //
        //
        //
        //
        let old_size = self.inner().strong.fetch_add(1, Relaxed);

        // Nanging kita kudu ngati-ati supaya bisa ngetrapake maneh akun manawa ana wong sing `mem: : lali`ing Arcs.
        // Yen ora ditindakake, jumlah bisa kakehan lan pangguna bakal nggunakake sawise gratis.
        // Kita kanthi kejen nganti `isize::MAX` kanthi asumsi ora ana ~2 milyar utas sing nambah jumlah referensi sekaligus.
        //
        // branch iki ora bakal dijupuk ing program realistis.
        //
        // Kita mbatalake amarga program kasebut pancen saya mudhun, lan kita ora prelu ndhukung.
        //
        //
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Arc<T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        &self.inner().data
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Arc<T> {}

impl<T: Clone> Arc<T> {
    /// Nggawe referensi sing bisa diowahi dadi `Arc` sing diwenehake.
    ///
    /// Yen ana petunjuk `Arc` utawa [`Weak`] liyane ing alokasi sing padha, mula `make_mut` bakal nggawe alokasi anyar lan njaluk [`clone`][clone] ing nilai batin kanggo njamin kepemilikan unik.
    /// Iki uga diarani klon-on-nulis.
    ///
    /// Elinga yen iki beda karo prilaku [`Rc::make_mut`] sing ngilangi petunjuk `Weak` sing isih ana.
    ///
    /// Deleng uga [`get_mut`][get_mut], sing bakal gagal tinimbang kloning.
    ///
    /// [clone]: Clone::clone
    /// [get_mut]: Arc::get_mut
    /// [`Rc::make_mut`]: super::rc::Rc::make_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut data = Arc::new(5);
    ///
    /// *Arc::make_mut(&mut data) += 1;         // Ora bakal Klone apa-apa
    /// let mut other_data = Arc::clone(&data); // Ora bakal kloning data njero
    /// *Arc::make_mut(&mut data) += 1;         // Data njero klon
    /// *Arc::make_mut(&mut data) += 1;         // Ora bakal Klone apa-apa
    /// *Arc::make_mut(&mut other_data) *= 2;   // Ora bakal Klone apa-apa
    ///
    /// // Saiki `data` lan `other_data` nuduhake alokasi sing beda.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        // Elinga yen kita duwe referensi sing kuat lan referensi sing ringkih.
        // Mula, yen ngeculake referensi sing kuat, ora bakal nyebabake memori bisa diganti.
        //
        // Gunakake Enquire kanggo mesthekake yen kita ndeleng nulis menyang `weak` sing kedadeyan sadurunge rilis nyerat (yaiku decrement) menyang `strong`.
        // Awit kita terus count banget, boten wonten kasempatan ArcInner dhewe bisa deallocated.
        //
        //
        //
        if this.inner().strong.compare_exchange(1, 0, Acquire, Relaxed).is_err() {
            // Ana petunjuk liyane sing kuwat, mula kita kudu kloning.
            // Memori alokasi sadurunge kanggo ngidini nulis nilai kloning kanthi langsung.
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = arc.assume_init();
            }
        } else if this.inner().weak.load(Relaxed) != 1 {
            // Relaksasi cekap ing ndhuwur amarga iki minangka optimalisasi dhasar: kita mesthi balap kanthi nggawa petunjuk sing ringkih.
            // Kasus paling ala, kita pungkasane menehi Arc sing ora perlu.
            //

            // Kita ngilangi ref sing kuwat pungkasan, nanging isih ana sisa tambahan sing ringkih.
            // Kita bakal mindhah konten menyang Arc anyar, lan mbatalake ref sing ringkih liyane.
            //

            // Elinga yen ora bisa diwaca `weak` ngasilake usize::MAX (yaiku, dikunci), amarga jumlah sing ringkih mung bisa dikunci dening utas kanthi referensi sing kuwat.
            //
            //

            // Mupangatake pitunjuk implisit sing ringkih, supaya bisa ngresiki ArcInner sing dibutuhake.
            //
            let _weak = Weak { ptr: this.ptr };

            // Mung bisa nyolong data, sing isih ana yaiku Weaks
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);
                ptr::write(this, arc.assume_init());
            }
        } else {
            // Kita minangka referensi siji-sijine;nabrak munggah count ref kuwat.
            //
            this.inner().strong.store(1, Release);
        }

        // Kaya `get_mut()`, rasa aman iku ora apa-apa amarga referensi kita unik kanggo diwiwiti, utawa dadi kloning konten.
        //
        unsafe { Self::get_mut_unchecked(this) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// Ngasilake referensi sing bisa diowahi dadi `Arc` sing diwenehake, yen ora ana petunjuk `Arc` utawa [`Weak`] liyane menyang alokasi sing padha.
    ///
    ///
    /// Yen ngasilake [`None`], amarga ora aman kanggo mutasi nilai sing dituduhake.
    ///
    /// Deleng uga [`make_mut`][make_mut], sing bakal [`clone`][clone] regane batin yen ana petunjuk liyane.
    ///
    /// [make_mut]: Arc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(3);
    /// *Arc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Arc::clone(&x);
    /// assert!(Arc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if this.is_unique() {
            // Ketahanan sing aman iki ora apa-apa amarga kita dijamin manawa pitunjuk sing dibalekake minangka siji-sijine * petunjuk sing bakal bali menyang T.
            // Jumlah referensi dijamin 1 ing wektu iki, lan Arc kudu `mut`, mula mung bisa ngrujukake referensi data internal.
            //
            //
            //
            unsafe { Some(Arc::get_mut_unchecked(this)) }
        } else {
            None
        }
    }

    /// Ngasilake referensi sing bisa diowahi menyang `Arc` tartamtu, tanpa mriksa.
    ///
    /// Deleng uga [`get_mut`], sing aman lan uga mriksa sing cocog.
    ///
    /// [`get_mut`]: Arc::get_mut
    ///
    /// # Safety
    ///
    /// Petunjuk `Arc` utawa [`Weak`] liyane sing padha karo alokasi sing padha ora kudu dibebasake sajrone utang sing bali.
    ///
    /// Iki pancen sepele yen ora ana petunjuk, kayata sanalika sawise `Arc::new`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(String::new());
    /// unsafe {
    ///     Arc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // Kita ngati-ati supaya *ora* nggawe referensi sing nyakup lapangan "count", amarga iki bakal duwe akses bebarengan karo jumlah referensi (eg
        // dening `Weak`).
        unsafe { &mut (*this.ptr.as_ptr()).data }
    }

    /// Temtokake manawa iki minangka referensi unik (kalebu ref sing ringkih) kanggo data sing ndasari.
    ///
    ///
    /// Elinga yen iki mbutuhake ngunci count ref sing ringkih.
    fn is_unique(&mut self) -> bool {
        // ngunci jumlah pitunjuk sing ringkih yen katon mung duwe panunjuk sing ringkih.
        //
        // Label ndarbeni ing kene njamin hubungan sadurunge karo tulisan menyang `strong` (khususe `Weak::upgrade`) sadurunge decrement count `weak` (liwat `Weak::drop`, sing nggunakake rilis).
        // Yen ref sing direnovasi ora bakal mudhun, CAS ing kene bakal gagal dadi kita ora prelu nyinkronake.
        //
        //
        //
        if self.inner().weak.compare_exchange(1, usize::MAX, Acquire, Relaxed).is_ok() {
            // Iki kudu dadi `Acquire` kanggo nyinkronake karo penurunan counter `strong` ing `drop`-siji-sijine akses sing kedadeyan nalika referensi pungkasan lagi diluncurake.
            //
            //
            let unique = self.inner().strong.load(Acquire) == 1;

            // Rilis nulis ing kene disinkronake karo diwaca ing `downgrade`, kanthi efektif ngalangi maca `strong` ing ndhuwur supaya ora kedadeyan sawise nulis.
            //
            //
            self.inner().weak.store(1, Release); // ngeculake kunci
            unique
        } else {
            false
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Arc<T> {
    /// Nyelehake `Arc`.
    ///
    /// Iki bakal nyuda jumlah referensi sing kuwat.
    /// Yen jumlah referensi sing kuwat tekan nol, mula referensi liyane (yen ana) yaiku [`Weak`], mula kita bakal entuk nilai batin ing `drop`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Arc::new(Foo);
    /// let foo2 = Arc::clone(&foo);
    ///
    /// drop(foo);    // Ora nyithak apa-apa
    /// drop(foo2);   // Nyithak "dropped!"
    /// ```
    #[inline]
    fn drop(&mut self) {
        // Amarga `fetch_sub` wis dadi atom, kita ora perlu nyinkronake karo utas liyane kajaba kita bakal mbusak obyek kasebut.
        // Logika sing padha ditrapake ing ngisor `fetch_sub` kanggo jumlah `weak`.
        //
        if self.inner().strong.fetch_sub(1, Release) != 1 {
            return;
        }

        // Pagar iki dibutuhake kanggo nyegah nyusun panggunaan data lan mbusak data.
        // Amarga ditandhani `Release`, penurunan jumlah referensi bakal disinkronake karo pager `Acquire` iki.
        // Iki tegese panganggone data kedadeyan sadurunge nyuda jumlah referensi, sing kedadeyan sadurunge pager iki, sing kedadeyan sadurunge mbusak data.
        //
        // Kaya sing diterangake ing [Boost documentation][1],
        //
        // > Penting kanggo ngetrapake sembarang akses menyang obyek ing siji
        // > utas (liwat referensi sing wis ana) supaya *kedadeyan sadurunge* mbusak
        // > obyek ing utas liyane.Iki diraih dening "release"
        // > operasi sawise ngeculake referensi (akses menyang obyek
        // > liwat referensi iki mesthine kudu kedadeyan sadurunge), lan an
        // > "acquire" operasi sadurunge mbusak obyek.
        //
        // Utamane, sanajan isi Arc biasane ora bisa diowahi, bisa uga ana tulisan interior sing ditulis karo Bisu Bis<T>.
        // Amarga Biseks ora dipikolehi nalika dibusak, kita ora bisa ngandelake logika sinkronisasi kanggo nggawe nyerat ing utas A sing bisa dideleng saka destruktor sing mlaku ing utas B.
        //
        //
        // Uga elinga manawa pagar Entuk ing kene bisa uga diganti karo beban Entuk, sing bisa nambah kinerja ing kahanan sing rame banget.Waca [2].
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        // [2]: (https://github.com/rust-lang/rust/pull/41714)
        //
        //
        //
        //
        //
        //
        //
        acquire!(self.inner().strong);

        unsafe {
            self.drop_slow();
        }
    }
}

impl Arc<dyn Any + Send + Sync> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// Coba downcast `Arc<dyn Any + Send + Sync>` dadi jinis konkrit.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::sync::Arc;
    ///
    /// fn print_if_string(value: Arc<dyn Any + Send + Sync>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Arc::new(my_string));
    /// print_if_string(Arc::new(0i8));
    /// ```
    pub fn downcast<T>(self) -> Result<Arc<T>, Self>
    where
        T: Any + Send + Sync + 'static,
    {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<ArcInner<T>>();
            mem::forget(self);
            Ok(Arc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T> Weak<T> {
    /// Mbangun `Weak<T>` anyar, tanpa menehi memori.
    /// Nelpon [`upgrade`] ing rega bali mesthi menehi [`None`].
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut ArcInner<T>).expect("MAX is not 0") }
    }
}

/// Jinis helper kanggo ngidini ngakses jumlah referensi tanpa negesake babagan kolom data.
///
struct WeakInner<'a> {
    weak: &'a atomic::AtomicUsize,
    strong: &'a atomic::AtomicUsize,
}

impl<T: ?Sized> Weak<T> {
    /// Ngasilake pitunjuk mentah menyang obyek `T` sing dituduhake dening `Weak<T>` iki.
    ///
    /// Pointer mung valid yen ana referensi sing kuat.
    /// Pointer bisa uga nggantung, ora salaras utawa malah [`null`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::ptr;
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// // Kalorone nuduhake obyek sing padha
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // Kuat ing kene tetep urip, mula isih bisa ngakses obyek kasebut.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // Nanging ora ono liyane.
    /// // Kita bisa nindakake weak.as_ptr(), nanging yen ngakses pointer bakal nyebabake tumindak sing durung mesthi.
    /// // assert_eq! ("hello", ora aman {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // Yen penunjuk wis nggantung, kita langsung bali menyang sentinel.
            // Iki ora bisa dadi alamat muatan sing bener, amarga muatan paling ora padha karo ArcInner (usize).
            ptr as *const T
        } else {
            // SAFETY: yen_dangling ngasilake salah, mula pitunjuk ora bisa dibatalake.
            // Payload bisa uga diturunake ing titik iki, lan kita kudu njaga bukti, mula nggunakake manipulasi pointer mentah.
            //
            unsafe { ptr::addr_of_mut!((*ptr).data) }
        }
    }

    /// Nganggo `Weak<T>` lan dadi pitunjuk mentah.
    ///
    /// Iki ngowahi pointer sing lemah dadi pitunjuk mentah, nalika isih njaga kepemilikan siji referensi sing lemah (jumlah sing ringkih ora diowahi karo operasi iki).
    /// Bisa diowahi dadi `Weak<T>` nganggo [`from_raw`].
    ///
    /// Watesan sing padha kanggo ngakses target pointer lan [`as_ptr`] ditrapake.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Arc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Arc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// Ngonversi pitunjuk mentah sing sadurunge digawe dening [`into_raw`] bali menyang `Weak<T>`.
    ///
    /// Iki bisa digunakake kanggo entuk referensi sing kuat (kanthi nelpon [`upgrade`] mengko) utawa menehi hasil jumlah sing ringkih kanthi ngeculake `Weak<T>`.
    ///
    /// Sampeyan butuh siji referensi sing ringkih (kajaba petunjuk sing digawe dening [`new`], amarga ora duwe apa-apa; cara isih bisa digunakake).
    ///
    /// # Safety
    ///
    /// Pointer kudu asale saka [`into_raw`] lan isih kudu duwe referensi sing ringkih.
    ///
    /// Jumlah sing diijini luwih saka 0 nalika sampeyan nelpon iki.
    /// Nanging, iki nduweni kepemilikan siji referensi sing ringkih sing saiki diwakili minangka penunjuk mentah (jumlah sing ringkih ora dimodifikasi karo operasi iki) lan mula kudu dipasangake karo [`into_raw`] sadurunge.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    ///
    /// let raw_1 = Arc::downgrade(&strong).into_raw();
    /// let raw_2 = Arc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Arc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Arc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // Ngurangi jumlah sing pungkasan banget.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`new`]: Weak::new
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`forget`]: std::mem::forget
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // Deleng Weak::as_ptr kanggo konteks babagan cara pointer input.

        let ptr = if is_dangling(ptr as *mut T) {
            // Iki minangka Lemah sing nggantung.
            ptr as *mut ArcInner<T>
        } else {
            // Yen ora, kita bakal menehi penunjuk yen teka saka Lemah sing ora ana gunane.
            // SAFETY: data_offset aman ditelpon, amarga referensi ptr sing nyata (duweni potensi mudhun) T
            let offset = unsafe { data_offset(ptr) };
            // Mangkono, kita mbalikke offset kanggo entuk RcBox kabeh.
            // SAFETY: pointer asale saka Lemah, mula offset iki aman.
            unsafe { (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // SAFETY: saiki kita wis nemokake pointer Weak asli, mula bisa nggawe Lemah.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }
}

impl<T: ?Sized> Weak<T> {
    /// Usaha kanggo upgrade pointer `Weak` dadi [`Arc`], tundha nyelehake nilai batin yen sukses.
    ///
    ///
    /// Ngasilake [`None`] yen nilai batine wis mudhun.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    ///
    /// let strong_five: Option<Arc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // Rusak kabeh pitunjuk sing kuat.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Arc<T>> {
        // Kita nggunakake loop CAS kanggo nambah jumlah sing kuwat tinimbang njupuk fetch_add amarga fungsi iki ora bakal ngitung jumlah referensi saka nol dadi siji.
        //
        //
        let inner = self.inner()?;

        // Beban santai amarga ana tulisan 0 sing bisa kita deleng ninggalake lapangan ing negara nol permanen (saengga diwaca "stale" 0 ora apa-apa), lan nilai liyane dikonfirmasi liwat CAS ing ngisor iki.
        //
        //
        //
        let mut n = inner.strong.load(Relaxed);

        loop {
            if n == 0 {
                return None;
            }

            // Deleng komentar ing `Arc::clone` kenapa kita nindakake iki (kanggo `mem::forget`).
            if n > MAX_REFCOUNT {
                abort();
            }

            // Relaksasi apik kanggo kasus kegagalan amarga kita ora duwe pangarep-arep babagan negara anyar.
            // Entuk prelu supaya kasus sukses bisa disinkronake karo `Arc::new_cyclic`, yen regane batin bisa diwiwiti sawise referensi `Weak` wis digawe.
            // Yen ngono, kita ngarepake bisa ngetrapake nilai sing wis diwiwiti.
            //
            match inner.strong.compare_exchange_weak(n, n + 1, Acquire, Relaxed) {
                Ok(_) => return Some(Arc::from_inner(self.ptr)), // batal dicenthang ing ndhuwur
                Err(old) => n = old,
            }
        }
    }

    /// Entuk nomer petunjuk (`Arc`) sing kuat sing nuduhake alokasi iki.
    ///
    /// Yen `self` digawe nggunakake [`Weak::new`], iki bakal ngasilake 0.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong.load(SeqCst) } else { 0 }
    }

    /// Entuk pendekatan nomer pointer `Weak` sing nuduhake alokasi iki.
    ///
    /// Yen `self` digawe nggunakake [`Weak::new`], utawa yen ora ana petunjuk sing kuat, iki bakal ngasilake 0.
    ///
    /// # Accuracy
    ///
    /// Amarga rincian implementasine, nilai bali bisa dipateni 1 ing salah sawijining arah nalika utas liyane ngolah manipulasi `Arc`s utawa` Lemah 'sing nuduhake alokasi sing padha.
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                let weak = inner.weak.load(SeqCst);
                let strong = inner.strong.load(SeqCst);
                if strong == 0 {
                    0
                } else {
                    // Amarga kita ngelingi paling ora ana siji poin sing kuwat sawise maca jumlah sing ringkih, kita ngerti manawa referensi lemah sing implisit (saiki yen ana referensi sing kuat isih ana) nalika kita ngetrapake jumlah sing ringkih, mula bisa nyuda kanthi aman.
                    //
                    //
                    //
                    //
                    weak - 1
                }
            })
            .unwrap_or(0)
    }

    /// Ngasilake `None` nalika pitunjuk wis digantung lan ora ana `ArcInner` sing dialokasikan, (yaiku, nalika `Weak` iki digawe dening `Weak::new`).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // Kita ati-ati supaya *ora* nggawe referensi sing nutupi lapangan "data", amarga lapangan bisa uga diowahi (contone, yen `Arc` pungkasan dicopot, kolom data bakal mudhun ing papane).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// Ngasilake `true` yen loro `Lemah 'nuduhake alokasi sing padha (padha karo [`ptr::eq`]), utawa yen kalorone ora nuduhake alokasi apa wae (amarga digawe nganggo `Weak::new()`).
    ///
    ///
    /// # Notes
    ///
    /// Amarga iki mbandhingake pitunjuk, tegese `Weak::new()` bakal padha, sanajan ora nuduhake alokasi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let first_rc = Arc::new(5);
    /// let first = Arc::downgrade(&first_rc);
    /// let second = Arc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(5);
    /// let third = Arc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// Mbandhingake `Weak::new`.
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(());
    /// let third = Arc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// Nggawe klon penunjuk `Weak` sing nuduhake alokasi sing padha.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let weak_five = Arc::downgrade(&Arc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        let inner = if let Some(inner) = self.inner() {
            inner
        } else {
            return Weak { ptr: self.ptr };
        };
        // Deleng komentar ing Arc::clone() kenapa santai iki.
        // Iki bisa nggunakake fetch_add (nglirwakake kunci) amarga jumlah sing ringkih mung dikunci ing endi *ora ana liyane* petunjuk sing lemah.
        //
        // (Dadi, kita ora bisa mbukak kode iki).
        let old_size = inner.weak.fetch_add(1, Relaxed);

        // Deleng komentar ing Arc::clone() kenapa kita nindakake iki (kanggo mem::forget).
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// Mbangun `Weak<T>` anyar, tanpa memori persediaan.
    /// Nelpon [`upgrade`] ing rega bali mesthi menehi [`None`].
    ///
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// Nyelehake pointer `Weak`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Arc::new(Foo);
    /// let weak_foo = Arc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // Ora nyithak apa-apa
    /// drop(foo);        // Nyithak "dropped!"
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        // Yen kita ngerteni manawa kita minangka pointer pungkasan sing ringkih, mula wektune kanggo menehi transaksi kanthi total.Deleng diskusi ing Arc::drop() babagan urutan memori
        //
        // Sampeyan ora prelu mriksa negara sing dikunci ing kene, amarga jumlah sing ringkih mung bisa dikunci yen sabenere ana ref sing lemah, tegese penurunan kasebut sabanjure bisa mbukak ON ref sing isih ringkih, sing mung bisa kedadeyan sawise kunci diluncurake.
        //
        //
        //
        //
        //
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        if inner.weak.fetch_sub(1, Release) == 1 {
            acquire!(inner.weak);
            unsafe { Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr())) }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait ArcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Arc<T>) -> bool;
    fn ne(&self, other: &Arc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    default fn eq(&self, other: &Arc<T>) -> bool {
        **self == **other
    }
    #[inline]
    default fn ne(&self, other: &Arc<T>) -> bool {
        **self != **other
    }
}

/// Kita nindakake spesialisasi iki ing kene, lan dudu ngoptimalake `&T` sing luwih umum, amarga bakal nambah biaya kanggo kabeh priksa kesetaraan ing ref.
/// Kita nganggep manawa `Arc`s digunakake kanggo nyimpen angka-angka sing gedhe, sing klone alon, nanging uga angel kanggo mriksa kesetaraan, nyebabake biaya iki bisa mbayar kanthi luwih gampang.
///
/// Sampeyan uga luwih cenderung duwe rong klon `Arc`, sing nuduhake regane padha, tinimbang loro `&T`s.
///
/// Kita mung bisa nindakake iki nalika `T: Eq` minangka `PartialEq` bisa uga sengaja ora sopan.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + crate::rc::MarkerEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        Arc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        !Arc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Arc<T> {
    /// Kesetaraan kanggo loro `Arc`s.
    ///
    /// Rong `Arc` padha yen regane batin padha, sanajan disimpen ing alokasi sing beda.
    ///
    /// Yen `T` uga ngetrapake `Eq` (tegese refleksivitas kesetaraan), loro `Arc` sing nuduhake alokasi sing padha mesthi padha.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five == Arc::new(5));
    /// ```
    ///
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::eq(self, other)
    }

    /// Ketimpangan kanggo rong `Arc`s.
    ///
    /// Rong `Arc` ora padha yen regane batin ora padha.
    ///
    /// Yen `T` uga ngetrapake `Eq` (tegese refleksivitas kesetaraan), loro `Arc` sing nuduhake angka sing padha ora bakal padha.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five != Arc::new(6));
    /// ```
    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Arc<T> {
    /// Bandhing parsial kanggo loro `Arc`s.
    ///
    /// Kalorone dibandhingake kanthi nyebut `partial_cmp()` ing nilai batin.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Arc::new(6)));
    /// ```
    fn partial_cmp(&self, other: &Arc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// Perbandingan sing kurang saka rong Arc.
    ///
    /// Kalorone dibandhingake kanthi nyebut `<` ing nilai batin.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five < Arc::new(6));
    /// ```
    fn lt(&self, other: &Arc<T>) -> bool {
        *(*self) < *(*other)
    }

    /// 'Kurang saka utawa padha karo' perbandingan kanggo rong `Arc '.
    ///
    /// Kalorone dibandhingake kanthi nyebut `<=` ing nilai batin.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five <= Arc::new(5));
    /// ```
    fn le(&self, other: &Arc<T>) -> bool {
        *(*self) <= *(*other)
    }

    /// Perbandingan sing luwih gedhe tinimbang rong Arc.
    ///
    /// Kalorone dibandhingake kanthi nyebut `>` ing nilai batin.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five > Arc::new(4));
    /// ```
    fn gt(&self, other: &Arc<T>) -> bool {
        *(*self) > *(*other)
    }

    /// Perbandingan 'Luwih gedhe utawa padha' kanggo 'Arc` loro.
    ///
    /// Kalorone dibandhingake kanthi nyebut `>=` ing nilai batin.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five >= Arc::new(5));
    /// ```
    fn ge(&self, other: &Arc<T>) -> bool {
        *(*self) >= *(*other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Arc<T> {
    /// Comparison for two `Arc`s.
    ///
    /// Kalorone dibandhingake kanthi nyebut `cmp()` ing nilai batin.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Arc::new(6)));
    /// ```
    fn cmp(&self, other: &Arc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Arc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Arc<T> {
    /// Nggawe `Arc<T>` anyar, kanthi nilai `Default` kanggo `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x: Arc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    fn default() -> Arc<T> {
        Arc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Arc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Arc<T> {
    fn from(t: T) -> Self {
        Arc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Arc<[T]> {
    /// Alokasi irisan sing dietung referensi banjur iseni kanthi kloning item `v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Arc<[T]> {
        <Self as ArcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Arc<str> {
    /// Alokasi `str` sing dietung referensi lan salin `v` ing kana.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let shared: Arc<str> = Arc::from("eggplant");
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Arc<str> {
        let arc = Arc::<[u8]>::from(v.as_bytes());
        unsafe { Arc::from_raw(Arc::into_raw(arc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Arc<str> {
    /// Alokasi `str` sing dietung referensi lan salin `v` ing kana.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: String = "eggplant".to_owned();
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Arc<str> {
        Arc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Arc<T> {
    /// Pindhah obyek kothak menyang alokasi referensi sing dietung anyar.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Box<str> = Box::from("eggplant");
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Arc<T> {
        Arc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Arc<[T]> {
    /// Alokasi irisan sing dietung referensi banjur pindhah item `v` menyang njero.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Vec<i32> = vec![1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(unique);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Arc<[T]> {
        unsafe {
            let arc = Arc::copy_from_slice(&v);

            // Allow Vec kanggo mbebasake memori, nanging aja ngrusak isine
            v.set_len(0);

            arc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Arc<B>
where
    B: ToOwned + ?Sized,
    Arc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Arc<B> {
        match cow {
            Cow::Borrowed(s) => Arc::from(s),
            Cow::Owned(s) => Arc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Arc<[T]>> for Arc<[T; N]> {
    type Error = Arc<[T]>;

    fn try_from(boxed_slice: Arc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Arc::from_raw(Arc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Arc<[T]> {
    /// Nganggo saben elemen ing `Iterator` lan dikumpulake dadi `Arc<[T]>`.
    ///
    /// # Karakteristik kinerja
    ///
    /// ## Kasus umum
    ///
    /// Ing kasus umume, nglumpukake menyang `Arc<[T]>` rampung kanthi pisanan nglumpukake menyang `Vec<T>`.Yaiku, nalika nulis ing ngisor iki:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// iki tumindak kaya nalika nulis:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // Kumpulan alokasi pertama kedadeyan ing kene.
    ///     .into(); // Alokasi liya kanggo `Arc<[T]>` kedadeyan ing kene.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// Iki bakal menehi kaping pirang-pirang sing dibutuhake kanggo mbangun `Vec<T>` lan banjur bakal alokasi sapisan kanggo ngowahi `Vec<T>` dadi `Arc<[T]>`.
    ///
    ///
    /// ## Iterator sing dawane dingerteni
    ///
    /// Nalika `Iterator` sampeyan ngetrapake `TrustedLen` lan ukurane pas, alokasi siji bakal digawe kanggo `Arc<[T]>`.Contone:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).collect(); // Mung ana alokasi siji ing kene.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToArcSlice::to_arc_slice(iter.into_iter())
    }
}

/// Spesialisasi trait digunakake kanggo nglumpukake menyang `Arc<[T]>`.
trait ToArcSlice<T>: Iterator<Item = T> + Sized {
    fn to_arc_slice(self) -> Arc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToArcSlice<T> for I {
    default fn to_arc_slice(self) -> Arc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToArcSlice<T> for I {
    fn to_arc_slice(self) -> Arc<[T]> {
        // Iki minangka kasus kanggo iterator `TrustedLen`.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // SAFETY: Kita kudu mesthekake yen iterator duwe dawa sing pas lan saiki wis ana.
                Arc::from_iter_exact(self, low)
            }
        } else {
            // Mbalik maneh menyang implementasi normal.
            self.collect::<Vec<T>>().into()
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Arc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Arc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Arc<T> {}

/// Entuk offset ing `ArcInner` kanggo muatan ing mburi pitunjuk.
///
/// # Safety
///
/// Pointer kudu nuduhake (lan duwe metadata sing bener) conto T sing valid sadurunge, nanging T diidini dicopot.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // Selarasake nilai sing durung diukur menyang pungkasan ArcInner.
    // Amarga RcBox minangka repr(C), mesthi bakal dadi lapangan pungkasan ing memori.
    // SAFETY: amarga jinis sing durung ditemtokake mung yaiku irisan, obyek trait,
    // lan jinis eksternal, syarat keamanan input saiki cukup kanggo nyukupi kebutuhan align_of_val_raw;iki minangka rincian implementasi basa sing ora bisa dipercaya ing sanjabane std.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<ArcInner<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}