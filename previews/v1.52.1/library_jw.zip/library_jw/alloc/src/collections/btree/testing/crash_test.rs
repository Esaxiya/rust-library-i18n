use crate::fmt::Debug;
use std::cmp::Ordering;
use std::sync::atomic::{AtomicUsize, Ordering::SeqCst};

/// Cithak biru kanggo conto dummy tes kacilakan sing ngawasi kedadeyan tartamtu.
/// Sawetara kedadean bisa uga dikonfigurasi menyang panic ing sawetara wektu.
/// Acara yaiku `clone`, `drop` utawa sawetara `query` anonim.
///
/// Dummies test crash diidentifikasi lan dipesen dening id, mula bisa digunakake minangka kunci ing BTreeMap.
/// Implementasine kanthi sengaja nggunakake ora gumantung karo apa wae sing ditemtokake ing crate, kajaba `Debug` trait.
///
#[derive(Debug)]
pub struct CrashTestDummy {
    id: usize,
    cloned: AtomicUsize,
    dropped: AtomicUsize,
    queried: AtomicUsize,
}

impl CrashTestDummy {
    /// Nggawe desain dummy test crash.`id` nemtokake urutan lan kesetaraan conto.
    pub fn new(id: usize) -> CrashTestDummy {
        CrashTestDummy {
            id,
            cloned: AtomicUsize::new(0),
            dropped: AtomicUsize::new(0),
            queried: AtomicUsize::new(0),
        }
    }

    /// Nggawe conto dummy test crash sing nyathet kedadeyan sing dialami lan kanthi opsional panics.
    ///
    pub fn spawn(&self, panic: Panic) -> Instance<'_> {
        Instance { origin: self, panic }
    }

    /// Ngasilake kaping pirang-pirang conto dummy sing wis dikloning.
    pub fn cloned(&self) -> usize {
        self.cloned.load(SeqCst)
    }

    /// Ngasilake kaping pirang-pirang conto dummy sing dicopot.
    pub fn dropped(&self) -> usize {
        self.dropped.load(SeqCst)
    }

    /// Ngasilake kaping pirang-pirang kedadean dummy yen anggota `query` diundang.
    pub fn queried(&self) -> usize {
        self.queried.load(SeqCst)
    }
}

#[derive(Debug)]
pub struct Instance<'a> {
    origin: &'a CrashTestDummy,
    panic: Panic,
}

#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub enum Panic {
    Never,
    InClone,
    InDrop,
    InQuery,
}

impl Instance<'_> {
    pub fn id(&self) -> usize {
        self.origin.id
    }

    /// Sawetara pitakon anonim, asile wis diwenehake.
    pub fn query<R>(&self, result: R) -> R {
        self.origin.queried.fetch_add(1, SeqCst);
        if self.panic == Panic::InQuery {
            panic!("panic in `query`");
        }
        result
    }
}

impl Clone for Instance<'_> {
    fn clone(&self) -> Self {
        self.origin.cloned.fetch_add(1, SeqCst);
        if self.panic == Panic::InClone {
            panic!("panic in `clone`");
        }
        Self { origin: self.origin, panic: Panic::Never }
    }
}

impl Drop for Instance<'_> {
    fn drop(&mut self) {
        self.origin.dropped.fetch_add(1, SeqCst);
        if self.panic == Panic::InDrop {
            panic!("panic in `drop`");
        }
    }
}

impl PartialOrd for Instance<'_> {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.id().partial_cmp(&other.id())
    }
}

impl Ord for Instance<'_> {
    fn cmp(&self, other: &Self) -> Ordering {
        self.id().cmp(&other.id())
    }
}

impl PartialEq for Instance<'_> {
    fn eq(&self, other: &Self) -> bool {
        self.id().eq(&other.id())
    }
}

impl Eq for Instance<'_> {}