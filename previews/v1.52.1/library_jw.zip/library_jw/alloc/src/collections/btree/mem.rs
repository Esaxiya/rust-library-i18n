use core::intrinsics;
use core::mem;
use core::ptr;

/// Iki ngganti nilai ing mburi referensi unik `v` kanthi nelpon fungsi sing relevan.
///
///
/// Yen panic ana ing penutupan `change`, kabeh proses bakal dibatalake.
#[allow(dead_code)] // tetep dadi ilustrasi lan kanggo nggunakake future
#[inline]
pub fn take_mut<T>(v: &mut T, change: impl FnOnce(T) -> T) {
    replace(v, |value| (change(value), ()))
}

/// Iki ngganti nilai ing mburi referensi unik `v` kanthi nelpon fungsi sing relevan, lan ngasilake asil sing dipikolehi ing dalan.
///
///
/// Yen panic ana ing penutupan `change`, kabeh proses bakal dibatalake.
#[inline]
pub fn replace<T, R>(v: &mut T, change: impl FnOnce(T) -> (T, R)) -> R {
    struct PanicGuard;
    impl Drop for PanicGuard {
        fn drop(&mut self) {
            intrinsics::abort()
        }
    }
    let guard = PanicGuard;
    let value = unsafe { ptr::read(v) };
    let (new_value, ret) = change(value);
    unsafe {
        ptr::write(v, new_value);
    }
    mem::forget(guard);
    ret
}