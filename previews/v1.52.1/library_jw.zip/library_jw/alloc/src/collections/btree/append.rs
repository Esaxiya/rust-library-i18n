use super::merge_iter::MergeIterInner;
use super::node::{self, Root};
use core::iter::FusedIterator;

impl<K, V> Root<K, V> {
    /// Nambahake kabeh pasangan nilai kunci saka gabungan rong iterator munggah, nambah variabel `length` ing dalan.Sing terakhir nggawe panelpon luwih gampang ngindhari bocor nalika handler gulung panik.
    ///
    /// Yen loro iterator ngasilake kunci sing padha, cara iki ngeculake pasangan saka iterator kiwa lan nambah pasangan kasebut saka iterator tengen.
    ///
    /// Yen sampeyan pengin wit kasebut rampung kanthi urutan munggah, kayata `BTreeMap`, kaloro iterator kudu ngasilake kunci kanthi urutan munggah, saben luwih gedhe tinimbang kabeh tombol ing wit, kalebu tombol sing wis ana ing wit nalika mlebu.
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn append_from_sorted_iters<I>(&mut self, left: I, right: I, length: &mut usize)
    where
        K: Ord,
        I: Iterator<Item = (K, V)> + FusedIterator,
    {
        // Kita siyap kanggo nggabungake `left` lan `right` dadi urutan sing diurutake ing wektu linier.
        let iter = MergeIter(MergeIterInner::new(left, right));

        // Kangge, kita bangun wit saka urutan sing diurutake ing wektu linear.
        self.bulk_push(iter, length)
    }

    /// Nyurung kabeh pasangan kunci-kunci ing pungkasan wit, nambah variabel `length` ing dalan.
    /// Sing terakhir nggawe luwih gampang panelpon supaya ora bocor nalika iterator panik.
    ///
    pub fn bulk_push<I>(&mut self, iter: I, length: &mut usize)
    where
        I: Iterator<Item = (K, V)>,
    {
        let mut cur_node = self.borrow_mut().last_leaf_edge().into_node();
        // Lebokake kabeh pasangan kunci-nilai, dorong menyang simpul ing level sing bener.
        for (key, value) in iter {
            // Coba push pasangan nilai kunci menyang simpul godhong saiki.
            if cur_node.len() < node::CAPACITY {
                cur_node.push(key, value);
            } else {
                // Ora ana papan sing isih ana, munggah banjur push ing kana.
                let mut open_node;
                let mut test_node = cur_node.forget_type();
                loop {
                    match test_node.ascend() {
                        Ok(parent) => {
                            let parent = parent.into_node();
                            if parent.len() < node::CAPACITY {
                                // Temokake simpul kanthi papan kiwa, tekan kene.
                                open_node = parent;
                                break;
                            } else {
                                // Munggah maneh.
                                test_node = parent.forget_type();
                            }
                        }
                        Err(_) => {
                            // Kita ana ing sisih ndhuwur, nggawe simpul root anyar banjur tekan ing kana.
                            open_node = self.push_internal_level();
                            break;
                        }
                    }
                }

                // Push pasangan nilai-kunci lan subtree tengen anyar.
                let tree_height = open_node.height() - 1;
                let mut right_tree = Root::new();
                for _ in 0..tree_height {
                    right_tree.push_internal_level();
                }
                open_node.push(key, value, right_tree);

                // Mudhun menyang godhong paling tengen maneh.
                cur_node = open_node.forget_type().last_leaf_edge().into_node();
            }

            // Tambah dawa saben pengulangan, kanggo mesthekake yen peta ngeculake elemen sing ditambah sanajan maju luwih cepet.
            //
            *length += 1;
        }
        self.fix_right_border_of_plentiful();
    }
}

// Pengulangan kanggo nggabungake rong urutan sing diurutake dadi siji
struct MergeIter<K, V, I: Iterator<Item = (K, V)>>(MergeIterInner<I>);

impl<K: Ord, V, I> Iterator for MergeIter<K, V, I>
where
    I: Iterator<Item = (K, V)> + FusedIterator,
{
    type Item = (K, V);

    /// Yen rong tombol padha, bali pasangan nilai-kunci saka sumber sing bener.
    fn next(&mut self) -> Option<(K, V)> {
        let (a_next, b_next) = self.0.nexts(|a: &(K, V), b: &(K, V)| K::cmp(&a.0, &b.0));
        b_next.or(a_next)
    }
}