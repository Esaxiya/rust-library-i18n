use core::marker::PhantomData;
use core::ptr::NonNull;

/// Model modhél referensi unik maneh, yen sampeyan ngerti yen mbalekake lan kabeh turune (yaiku, kabeh petunjuk lan referensi sing dipikolehi) ora bakal digunakake maneh ing sawetara titik, sawise sampeyan pengin nggunakake referensi unik asli maneh .
///
///
/// Checker utang biasane nangani tumpukan utangan iki kanggo sampeyan, nanging sawetara aliran kontrol sing ngrampungake tumpukan iki rumit banget kanggo tindakake kompilator.
/// `DormantMutRef` ngidini sampeyan mriksa utang dhewe, nalika isih nyebut sifat sing ditumpuk, lan nyusun kode penunjuk mentah sing dibutuhake kanggo nindakake iki tanpa prilaku sing durung ditemtokake.
///
///
///
///
///
pub struct DormantMutRef<'a, T> {
    ptr: NonNull<T>,
    _marker: PhantomData<&'a mut T>,
}

unsafe impl<'a, T> Sync for DormantMutRef<'a, T> where &'a mut T: Sync {}
unsafe impl<'a, T> Send for DormantMutRef<'a, T> where &'a mut T: Send {}

impl<'a, T> DormantMutRef<'a, T> {
    /// Nangkep utang sing unik, lan enggal utangan maneh.
    /// Kanggo kompiler, umure referensi anyar padha karo umure referensi asli, nanging sampeyan promise nggunakake kasebut kanggo wektu sing luwih cekak.
    ///
    pub fn new(t: &'a mut T) -> (&'a mut T, Self) {
        let ptr = NonNull::from(t);
        // SAFETY: kita nyilih utang liwat 'a liwat `_marker`, lan kita mbabarake
        // mung referensi iki, dadi unik.
        let new_ref = unsafe { &mut *ptr.as_ptr() };
        (new_ref, Self { ptr, _marker: PhantomData })
    }

    /// Bali menyang utang unik sing pisanan dijupuk.
    ///
    /// # Safety
    ///
    /// Utang maneh kudu rampung, yaiku referensi sing dikembalikan dening `new` lan kabeh petunjuk lan referensi sing dipikolehi, ora bisa digunakake maneh.
    ///
    pub unsafe fn awaken(self) -> &'a mut T {
        // KESELAMATAN: kahanan keamanan kita dhewe tegese referensi iki unik maneh.
        unsafe { &mut *self.ptr.as_ptr() }
    }
}

#[cfg(test)]
mod tests;