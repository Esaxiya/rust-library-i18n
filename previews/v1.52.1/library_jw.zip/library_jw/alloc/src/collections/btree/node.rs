// Iki minangka upaya implementasi miturut cita-cita
//
// ```
// struct BTreeMap<K, V> {
//     height: usize,
//     root: Option<Box<Node<K, V, height>>>
// }
//
// struct Node<K, V, height: usize> {
//     keys: [K; 2 * B - 1],
//     vals: [V; 2 * B - 1],
//     edges: [if height > 0 { Box<Node<K, V, height - 1>> } else { () }; 2 * B],
//     parent: Option<(NonNull<Node<K, V, height + 1>>, u16)>,
//     len: u16,
// }
// ```
//
// Amarga Rust pancen ora duwe jinis gumantung lan rekurasi polimorfik, mula bisa ditindakake kanthi ora aman.
//

// Tujuan utama saka modul iki yaiku supaya ora rumit kanthi nganggep wit kasebut minangka wadhah umum (yen bentuke aneh) lan supaya ora ngatasi umume invasi B-Tree.
//
// Kaya ngono, modul iki ora preduli manawa entri kasebut diurutake, simpul endi sing bisa diremehake, utawa apa tegese underfull.Nanging, kita gumantung karo sawetara undhangan:
//
// - Wit-witan kudu duwe depth/height seragam.Iki tegese saben dalan mudhun menyang godhong saka simpul tartamtu dawane padha.
// - Simpul dawane `n` nduweni tombol `n`, nilai `n`, lan pinggir `n + 1`.
//   Iki tegese malah simpul kosong paling ora ana siji edge.
//   Kanggo simpul rwaning, "having an edge" mung tegese kita bisa ngenali posisi ing simpul, amarga ujung godhong kosong lan ora butuh perwakilan data.
// Ing simpul internal, edge kudu ngidentifikasi posisi lan ngemot titik menyang simpul bocah.
//
//
//

use core::marker::PhantomData;
use core::mem::{self, MaybeUninit};
use core::ptr::{self, NonNull};
use core::slice::SliceIndex;

use crate::alloc::{Allocator, Global, Layout};
use crate::boxed::Box;

const B: usize = 6;
pub const CAPACITY: usize = 2 * B - 1;
pub const MIN_LEN_AFTER_SPLIT: usize = B - 1;
const KV_IDX_CENTER: usize = B - 1;
const EDGE_IDX_LEFT_OF_CENTER: usize = B - 1;
const EDGE_IDX_RIGHT_OF_CENTER: usize = B;

/// Perwakilan saka simpul rwaning lan bagean saka representasi node internal.
struct LeafNode<K, V> {
    /// Kita pengin dadi kovarian ing `K` lan `V`.
    parent: Option<NonNull<InternalNode<K, V>>>,

    /// Indeks simpul iki dadi rangkai `edges` simpul induk.
    /// `*node.parent.edges[node.parent_idx]` kudu padha karo `node`.
    /// Iki mung dijamin bakal diinisialisasi nalika `parent` ora batal.
    parent_idx: MaybeUninit<u16>,

    /// Jumlah tombol lan nilai sing disimpen ing simpul iki.
    len: u16,

    /// Susun-atur nyimpen data node nyata.
    /// Mung elemen `len` pisanan ing saben susunan sing diwiwiti lan valid.
    keys: [MaybeUninit<K>; CAPACITY],
    vals: [MaybeUninit<V>; CAPACITY],
}

impl<K, V> LeafNode<K, V> {
    /// Initialisasi `LeafNode` anyar ing papan.
    unsafe fn init(this: *mut Self) {
        // Minangka kabijakan umum, kita ninggali lapangan sing durung bisa diresmine manawa bisa, amarga iki kudu luwih cepet lan luwih gampang dilacak ing Valgrind.
        //
        unsafe {
            // parent_idx, tombol, lan vals kabeh MungkinUninit
            ptr::addr_of_mut!((*this).parent).write(None);
            ptr::addr_of_mut!((*this).len).write(0);
        }
    }

    /// Nggawe `LeafNode` kothak anyar.
    fn new() -> Box<Self> {
        unsafe {
            let mut leaf = Box::new_uninit();
            LeafNode::init(leaf.as_mut_ptr());
            leaf.assume_init()
        }
    }
}

/// Perwakilan node internal sing ndasari.Kaya dene `LeafNode`s, iki kudu didhelikake ing mburi`BoxedNode`s supaya ora ngeculake tombol lan nilai sing ora diresiki.
/// Sembarang pointer menyang `InternalNode` bisa langsung dibuwang menyang pointer menyang bagean `LeafNode` ing simpul, saéngga kode bisa tumindak ing simpul rwaning lan internal kanthi umum tanpa kudu mriksa endi wae pointer sing ditunjuk.
///
/// Properti iki diaktifake kanthi nggunakake `repr(C)`.
///
#[repr(C)]
// gdb_providers.py nggunakake jeneng jinis iki kanggo introspeksi.
struct InternalNode<K, V> {
    data: LeafNode<K, V>,

    /// Tunjuk menyang bocah-bocah ing simpul iki.
    /// `len + 1` iki dianggep minangka inisialisasi lan valid, kajaba sing cedhak pungkasane, nalika wit kasebut dicekel nganggo jinis utang `Dying`, sawetara petunjuk kasebut nggantung.
    ///
    edges: [MaybeUninit<BoxedNode<K, V>>; 2 * B],
}

impl<K, V> InternalNode<K, V> {
    /// Nggawe `InternalNode` kothak anyar.
    ///
    /// # Safety
    /// Invariant simpul internal yaiku paling ora duwe edge inisial lan valid.
    /// Fungsi iki ora nyiyapake edge kasebut.
    ///
    unsafe fn new() -> Box<Self> {
        unsafe {
            let mut node = Box::<Self>::new_uninit();
            // Kita mung kudu nggawe data dhisikan;pinggiré MungkinUninit.
            LeafNode::init(ptr::addr_of_mut!((*node.as_mut_ptr()).data));
            node.assume_init()
        }
    }
}

/// Pointer sing dikelola lan ora nul menyang simpul.Iki minangka pointer duweke `LeafNode<K, V>` utawa pointer duweke `InternalNode<K, V>`.
///
/// Nanging, `BoxedNode` ora ngemot informasi babagan kaloro jinis node sing sejatine dikandung, lan, sebagian amarga ora ana informasi iki, dudu jinis sing kapisah lan ora duwe destruktor.
///
///
///
type BoxedNode<K, V> = NonNull<LeafNode<K, V>>;

/// ROOT simpul wit duweke.
///
/// Elinga yen iki ora duwe kerusakan, lan kudu dibersihake kanthi manual.
pub type Root<K, V> = NodeRef<marker::Owned, K, V, marker::LeafOrInternal>;

impl<K, V> Root<K, V> {
    /// Ngasilake wit duweke anyar, kanthi simpul oyod dhewe sing wiwitane kosong.
    pub fn new() -> Self {
        NodeRef::new_leaf().forget_type()
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Leaf> {
    fn new_leaf() -> Self {
        Self::from_new_leaf(LeafNode::new())
    }

    fn from_new_leaf(leaf: Box<LeafNode<K, V>>) -> Self {
        NodeRef { height: 0, node: NonNull::from(Box::leak(leaf)), _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Internal> {
    fn new_internal(child: Root<K, V>) -> Self {
        let mut new_node = unsafe { InternalNode::new() };
        new_node.edges[0].write(child.node);
        unsafe { NodeRef::from_new_internal(new_node, child.height + 1) }
    }

    /// # Safety
    /// `height` kudu ora nol.
    unsafe fn from_new_internal(internal: Box<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        let node = NonNull::from(Box::leak(internal)).cast();
        let mut this = NodeRef { height, node, _marker: PhantomData };
        this.borrow_mut().correct_all_childrens_parent_links();
        this
    }
}

impl<K, V, Type> NodeRef<marker::Owned, K, V, Type> {
    /// Bisa uga nyilih simpul root sing diduweni.
    /// Ora kaya `reborrow_mut`, iki aman amarga regane bali ora bisa digunakake kanggo ngrusak oyot, lan ora bisa ana referensi liyane kanggo wit kasebut.
    ///
    pub fn borrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Rada bisa ganti menehi simpul simpul sing diduweni.
    pub fn borrow_valmut(&mut self) -> NodeRef<marker::ValMut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Transisi sing ora bisa dibalekake menyang referensi sing ngidini traversal lan nawakake cara ngrusak lan liya-liyane.
    ///
    pub fn into_dying(self) -> NodeRef<marker::Dying, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// Nambah simpul internal anyar kanthi edge tunggal sing nuduhake simpul root sadurunge, nggawe simpul anyar dadi simpul root, lan pulihake.
    /// Iki nambah dhuwur nganti 1 lan ngelawan `pop_internal_level`.
    ///
    pub fn push_internal_level(&mut self) -> NodeRef<marker::Mut<'_>, K, V, marker::Internal> {
        super::mem::take_mut(self, |old_root| NodeRef::new_internal(old_root).forget_type());

        // `self.borrow_mut()`, kajaba kita mung lali saiki internal:
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Mbusak simpul root internal, nggunakake anak sing pertama dadi simpul root anyar.
    /// Kaya sing dimaksud mung kanggo diarani nalika simpul ROOT mung duwe siji bocah, ora ana reresik ing kunci, nilai lan bocah liyane.
    ///
    /// Iki nyuda dhuwur nganti 1 lan ngelawan `push_internal_level`.
    ///
    /// Mbukak akses eksklusif menyang obyek `Root` nanging ora menyang simpul root;
    /// ora bakal mbatalake gagang utawa referensi liyane menyang simpul root.
    ///
    /// Panics yen ora ana level internal, yaiku yen simpul root yaiku godhong.
    pub fn pop_internal_level(&mut self) {
        assert!(self.height > 0);

        let top = self.node;

        // SAFETY: kita negesake internal.
        let internal_self = unsafe { self.borrow_mut().cast_to_internal_unchecked() };
        // SAFETY: kita nyilih `self` kanthi eksklusif lan jinis utangane eksklusif.
        let internal_node = unsafe { &mut *NodeRef::as_internal_ptr(&internal_self) };
        // SAFETY: edge pisanan mesthi diwiwiti.
        self.node = unsafe { internal_node.edges[0].assume_init_read() };
        self.height -= 1;
        self.clear_parent_link();

        unsafe {
            Global.deallocate(top.cast(), Layout::new::<InternalNode<K, V>>());
        }
    }
}

// N.B. `NodeRef` mesthi kovarian ing `K` lan `V`, sanajan `BorrowType` yaiku `Mut`.
// Iki salah kanthi teknis, nanging ora bisa nyebabake rasa ora aman amarga panggunaan internal `NodeRef` amarga kita tetep umum liwat `K` lan `V`.
//
// Nanging, kapan jinis publik mbungkus `NodeRef`, priksa manawa nduweni variasi sing bener.
//
/// Referensi menyang simpul.
///
/// Jinis iki duwe sawetara paramèter sing ngontrol tumindak:
/// - `BorrowType`: Jinis dummy sing nggambarake jinis utangan lan urip.
///    - Nalika `Immut<'a>`, `NodeRef` tumindak kira-kira kaya `&'a Node`.
///    - Nalika `ValMut<'a>`, `NodeRef` tumindak kira-kira kaya `&'a Node` gegayutan karo tombol lan struktur wit, nanging uga ngidini akeh referensi sing bisa diowahi kanggo kabeh wit bisa urip bebarengan.
///    - Nalika `Mut<'a>`, `NodeRef` tumindak kira-kira kaya `&'a mut Node`, sanajan cara insert ngidini pointer bisa diganti dadi nilai kanggo urip bebarengan.
///    - Nalika `Owned`, `NodeRef` tumindak kira-kira kaya `Box<Node>`, nanging ora duwe kerusakan, lan kudu dibersihake kanthi manual.
///    - Nalika `Dying`, `NodeRef` isih tumindak kira-kira kaya `Box<Node>`, nanging duwe metode kanggo ngrusak wit kanthi sethithik, lan cara biasa, sanajan ora ditandhani ora aman kanggo ditelpon, bisa njaluk UB yen diarani salah.
///
///   Amarga `NodeRef` ngidini navigasi liwat wit, `BorrowType` ditrapake kanthi efektif ing kabeh wit, ora mung ing simpul kasebut.
/// - `K` lan `V`: Iki minangka jinis tombol lan nilai sing disimpen ing simpul.
/// - `Type`: Iki bisa uga `Leaf`, `Internal`, utawa `LeafOrInternal`.
/// Nalika `Leaf`, `NodeRef` nuduhake simpul rwaning, yen `Internal` `NodeRef` nuduhake simpul internal, lan nalika `LeafOrInternal` `NodeRef` bisa nuduhake salah siji jinis simpul.
///   `Type` dijenengi `NodeType` nalika digunakake ing njaba `NodeRef`.
///
/// `BorrowType` lan `NodeType` mbatesi cara apa sing kita lakoni, kanggo ngeksploitasi keamanan jinis statis.Ana watesan cara ngetrapake watesan kasebut:
/// - Kanggo saben paramèter jinis, kita mung bisa netepake cara kanthi umum utawa kanggo siji jinis tartamtu.
/// Contone, kita ora bisa netepake cara kaya `into_kv` umume kanggo kabeh `BorrowType`, utawa sepisan kanggo kabeh jinis sing urip, amarga kita pengin ngasilake referensi `&'a`.
///   Mula, kita nemtokake mung kanggo tipe `Immut<'a>` sing paling kuat.
/// - Kita ora bisa meksa implisit saka ujar `Mut<'a>` nganti `Immut<'a>`.
///   Mula, kita kudu nelpon kanthi cetha `reborrow` ing `NodeRef` sing luwih kuat supaya bisa nggayuh cara kaya `into_kv`.
///
/// Kabeh cara ing `NodeRef` sing ngasilake sawetara referensi, uga:
/// - Pilih `self` kanthi regane, lan baleni maneh umur sing digawa `BorrowType`.
///   Kadhangkala, kanggo nggunakake metode kaya ngono, kita kudu nelpon `reborrow_mut`.
/// - Pilih `self` kanthi referensi, lan (implicitly) baleni maneh referensi kasebut, tinimbang umur sing ditindakake `BorrowType`.
/// Kanthi mangkono, pamriksa utang menehi jaminan yen `NodeRef` tetep diselehake anggere referensi bali digunakake.
///   Cara sing nyengkuyung insert bisa ngatasi aturan iki kanthi ngasilake pitunjuk mentah, yaiku referensi tanpa umur.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
pub struct NodeRef<BorrowType, K, V, Type> {
    /// Nomer level sing simpul lan level godhonge pisah, konstanta simpul sing ora bisa diandharake dening `Type`, lan simpul kasebut ora disimpen.
    /// Kita mung kudu nyimpen dhuwure simpul ROOT, lan nuwuhake dhuwure saben simpul liyane.
    /// Kudu nol yen `Type` `Leaf` lan non-nol yen `Type` yaiku `Internal`.
    ///
    ///
    height: usize,
    /// Penunjuk menyang rwaning utawa simpul internal.
    /// Definisi `InternalNode` njamin manawa penunjuk kasebut valid kanthi cara apa wae.
    node: NonNull<LeafNode<K, V>>,
    _marker: PhantomData<(BorrowType, Type)>,
}

impl<'a, K: 'a, V: 'a, Type> Copy for NodeRef<marker::Immut<'a>, K, V, Type> {}
impl<'a, K: 'a, V: 'a, Type> Clone for NodeRef<marker::Immut<'a>, K, V, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

unsafe impl<BorrowType, K: Sync, V: Sync, Type> Sync for NodeRef<BorrowType, K, V, Type> {}

unsafe impl<'a, K: Sync + 'a, V: Sync + 'a, Type> Send for NodeRef<marker::Immut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::Mut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::ValMut<'a>, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Owned, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Dying, K, V, Type> {}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Bukak referensi simpul sing dikemas dadi `NodeRef::parent`.
    fn from_internal(node: NonNull<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        NodeRef { height, node: node.cast(), _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Mbabarake data simpul internal.
    ///
    /// Ngasilake ptr mentah supaya ora validasi referensi liyane menyang simpul iki.
    fn as_internal_ptr(this: &Self) -> *mut InternalNode<K, V> {
        // SAFETY: jinis simpul statis yaiku `Internal`.
        this.node.as_ptr() as *mut InternalNode<K, V>
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Nyilih akses eksklusif menyang data simpul internal.
    fn as_internal_mut(&mut self) -> &mut InternalNode<K, V> {
        let ptr = Self::as_internal_ptr(self);
        unsafe { &mut *ptr }
    }
}

impl<BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// Nemokake dawa simpul.Iki nomer tombol utawa nilai.
    /// Cacahé `len() + 1`.
    /// Elinga yen, sanajan aman, nelpon fungsi iki bisa menehi efek samping saka referensi sing ora bisa diowahi sing digawe kode sing ora aman.
    ///
    pub fn len(&self) -> usize {
        // Sing penting, kita mung ngakses lapangan `len` ing kene.
        // Yen BorrowType yaiku marker::ValMut, bisa uga ana referensi sing bisa diowahi kanggo nilai sing kudu kita batal.
        unsafe { usize::from((*Self::as_leaf_ptr(self)).len) }
    }

    /// Ngasilake jumlah level sing simpul lan godhonge pisah.
    /// Dhuwur nol tegese simpul yaiku godhong dhewe.
    /// Yen sampeyan gambar wit kanthi oyot ing sisih ndhuwur, angka kasebut bakal katon node katon.
    /// Yen sampeyan nggambarake wit sing ana godhong ing ndhuwur, cacahe ujar manawa dhuwur wit kasebut ing ndhuwur simpul.
    ///
    pub fn height(&self) -> usize {
        self.height
    }

    /// Sedhela njupuk referensi liyane sing ora bisa diowahi menyang simpul sing padha.
    pub fn reborrow(&self) -> NodeRef<marker::Immut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Mbabarake bagean godhong saka godhong utawa simpul internal.
    ///
    /// Ngasilake ptr mentah supaya ora validasi referensi liyane menyang simpul iki.
    fn as_leaf_ptr(this: &Self) -> *mut LeafNode<K, V> {
        // Simpul kudu bener paling ora bagean LeafNode.
        // Iki dudu referensi ing jinis NodeRef amarga kita ora ngerti kudu unik utawa dituduhake.
        //
        this.node.as_ptr()
    }
}

impl<BorrowType: marker::BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// Golek wong tuwa simpul saiki.
    /// Ngasilake `Ok(handle)` yen simpul saiki sejatine duwe induk, ing endi `handle` nuduhake edge saka induk sing nuduhake simpul saiki.
    ///
    /// Ngasilake `Err(self)` yen simpul saiki ora duwe wong tuwa, menehi `NodeRef` asli.
    ///
    /// Jeneng metode nganggep sampeyan gambar wit kanthi simpul oyot ing sisih ndhuwur.
    ///
    /// `edge.descend().ascend().unwrap()` lan `node.ascend().unwrap().descend()` kudu loro, yen sukses, ora nindakake apa-apa.
    ///
    pub fn ascend(
        self,
    ) -> Result<Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>, Self> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // Kita kudu nggunakake petunjuk mentah menyang simpul amarga, yen BorrowType yaiku marker::ValMut, bisa uga ana referensi sing bisa diowahi kanggo nilai sing ora bisa dibatalake.
        //
        let leaf_ptr: *const _ = Self::as_leaf_ptr(&self);
        unsafe { (*leaf_ptr).parent }
            .as_ref()
            .map(|parent| Handle {
                node: NodeRef::from_internal(*parent, self.height + 1),
                idx: unsafe { usize::from((*leaf_ptr).parent_idx.assume_init()) },
                _marker: PhantomData,
            })
            .ok_or(self)
    }

    pub fn first_edge(self) -> Handle<Self, marker::Edge> {
        unsafe { Handle::new_edge(self, 0) }
    }

    pub fn last_edge(self) -> Handle<Self, marker::Edge> {
        let len = self.len();
        unsafe { Handle::new_edge(self, len) }
    }

    /// Elinga yen `self` kudu nonempty.
    pub fn first_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, 0) }
    }

    /// Elinga yen `self` kudu nonempty.
    pub fn last_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, len - 1) }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Immut<'a>, K, V, Type> {
    /// Mbabarake bagean godhong apa wae godhong utawa simpul internal ing wit sing ora owah.
    fn into_leaf(self) -> &'a LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&self);
        // SAFETY: ora ana referensi sing bisa diowahi menyang wit iki sing disilih dadi `Immut`.
        unsafe { &*ptr }
    }

    /// Nyilih tampilan menyang tombol sing disimpen ing simpul.
    pub fn keys(&self) -> &[K] {
        let leaf = self.into_leaf();
        unsafe {
            MaybeUninit::slice_assume_init_ref(leaf.keys.get_unchecked(..usize::from(leaf.len)))
        }
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// Mirip karo `ascend`, entuk referensi menyang simpul induk simpul, nanging uga menehi transaksi node saiki ing proses kasebut.
    /// Iki ora aman amarga simpul saiki isih bisa diakses sanajan wis ditanggepi.
    ///
    pub unsafe fn deallocate_and_ascend(
        self,
    ) -> Option<Handle<NodeRef<marker::Dying, K, V, marker::Internal>, marker::Edge>> {
        let height = self.height;
        let node = self.node;
        let ret = self.ascend().ok();
        unsafe {
            Global.deallocate(
                node.cast(),
                if height > 0 {
                    Layout::new::<InternalNode<K, V>>()
                } else {
                    Layout::new::<LeafNode<K, V>>()
                },
            );
        }
        ret
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Unfafely negesake menyang compiler informasi statis yen simpul iki `Leaf`.
    unsafe fn cast_to_leaf_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
        debug_assert!(self.height == 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Unfecely negesake menyang compiler informasi statis manawa simpul iki `Internal`.
    unsafe fn cast_to_internal_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        debug_assert!(self.height > 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Sementara njupuk referensi liyane sing bisa diowahi menyang simpul sing padha.Ati-ati, amarga cara iki mbebayani banget, bisa uga tikel amarga ora bisa katon mbebayani.
    ///
    /// Amarga pointer sing bisa diowahi bisa mlaku-mlaku ing endi wae ing wit, pointer sing bali bisa digunakake kanthi gampang kanggo nggawe pointer sing asli, ora ana wates, utawa ora valid miturut aturan utang sing ditumpuk.
    ///
    ///
    ///
    ///
    // FIXME(@gereeter) coba tambahi paramèter jinis liya menyang `NodeRef` sing matesi panggunaan cara navigasi ing pitunjuk sing dibalekake, kanggo nyegah kahanan sing aman.
    //
    //
    unsafe fn reborrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Nyilih akses eksklusif menyang bagean rwaning utawa simpul internal.
    fn as_leaf_mut(&mut self) -> &mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(self);
        // SAFETY: kita duwe akses eksklusif menyang kabeh simpul.
        unsafe { &mut *ptr }
    }

    /// Nawakake akses eksklusif menyang bagean godhong saka sembarang rwaning utawa simpul internal.
    fn into_leaf_mut(mut self) -> &'a mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&mut self);
        // SAFETY: kita duwe akses eksklusif menyang kabeh simpul.
        unsafe { &mut *ptr }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Nyilih akses eksklusif menyang elemen area panyimpenan kunci.
    ///
    /// # Safety
    /// `index` ana ing wates 0..KABASITAS
    unsafe fn key_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<K>], Output = Output>,
    {
        // SAFETY: panelpon ora bakal bisa nelpon metode luwih dhisik
        // nganti referensi irisan kunci diluncurake, amarga kita duwe akses unik kanggo umume utang.
        //
        unsafe { self.as_leaf_mut().keys.as_mut_slice().get_unchecked_mut(index) }
    }

    /// Nyilih akses eksklusif menyang elemen utawa irisan area panyimpenan nilai simpul.
    ///
    /// # Safety
    /// `index` ana ing wates 0..KABASITAS
    unsafe fn val_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<V>], Output = Output>,
    {
        // SAFETY: panelpon ora bakal bisa nelpon metode luwih dhisik
        // nganti referensi irisan regane mudhun, amarga kita duwe akses unik kanggo umume utang.
        //
        unsafe { self.as_leaf_mut().vals.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Nyilih akses eksklusif menyang elemen utawa irisan area panyimpenan simpul kanggo konten edge.
    ///
    /// # Safety
    /// `index` ana ing wates 0..KAPASITAS + 1
    unsafe fn edge_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<BoxedNode<K, V>>], Output = Output>,
    {
        // SAFETY: panelpon ora bakal bisa nelpon metode luwih dhisik
        // nganti referensi irisan edge mudhun, amarga kita duwe akses unik sajrone utang.
        //
        unsafe { self.as_internal_mut().edges.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K, V, Type> NodeRef<marker::ValMut<'a>, K, V, Type> {
    /// # Safety
    /// - Simpul kasebut nduweni luwih saka `idx` unsur inisialisasi.
    unsafe fn into_key_val_mut_at(mut self, idx: usize) -> (&'a K, &'a mut V) {
        // Kita mung nggawe referensi menyang siji elemen sing dikarepake, supaya ora aliasing nganggo referensi sing luar biasa kanggo elemen liyane, khususe, sing bali menyang panelpon kanthi pengulangan sadurunge.
        //
        //
        let leaf = Self::as_leaf_ptr(&mut self);
        let keys = unsafe { ptr::addr_of!((*leaf).keys) };
        let vals = unsafe { ptr::addr_of_mut!((*leaf).vals) };
        // Kita kudu meksa pituduh sing ora ditemtokake amarga Rust ngetokake #74679.
        let keys: *const [_] = keys;
        let vals: *mut [_] = vals;
        let key = unsafe { (&*keys.get_unchecked(idx)).assume_init_ref() };
        let val = unsafe { (&mut *vals.get_unchecked_mut(idx)).assume_init_mut() };
        (key, val)
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Nyilih akses eksklusif menyang dawa simpul.
    pub fn len_mut(&mut self) -> &mut u16 {
        &mut self.as_leaf_mut().len
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Nyetel link simpul menyang edge induk, tanpa mbatalake referensi liyane menyang simpul.
    ///
    fn set_parent_link(&mut self, parent: NonNull<InternalNode<K, V>>, parent_idx: usize) {
        let leaf = Self::as_leaf_ptr(self);
        unsafe { (*leaf).parent = Some(parent) };
        unsafe { (*leaf).parent_idx.write(parent_idx as u16) };
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// Mbusak link ROOT menyang edge induk.
    fn clear_parent_link(&mut self) {
        let mut root_node = self.borrow_mut();
        let leaf = root_node.as_leaf_mut();
        leaf.parent = None;
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
    /// Nambahake pasangan kunci-nilai ing mburi simpul.
    pub fn push(&mut self, key: K, val: V) {
        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// # Safety
    /// Saben item sing bali dening `range` minangka indeks edge sing valid kanggo simpul.
    unsafe fn correct_childrens_parent_links<R: Iterator<Item = usize>>(&mut self, range: R) {
        for i in range {
            debug_assert!(i <= self.len());
            unsafe { Handle::new_edge(self.reborrow_mut(), i) }.correct_parent_link();
        }
    }

    fn correct_all_childrens_parent_links(&mut self) {
        let len = self.len();
        unsafe { self.correct_childrens_parent_links(0..=len) };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Nambahake pasangan nilai-kunci, lan edge kanggo nengen pasangan kasebut, menyang ujung simpul.
    ///
    pub fn push(&mut self, key: K, val: V, edge: Root<K, V>) {
        assert!(edge.height == self.height - 1);

        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
            self.edge_area_mut(idx + 1).write(edge.node);
            Handle::new_edge(self.reborrow_mut(), idx + 1).correct_parent_link();
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Priksa manawa simpul minangka simpul `Internal` utawa simpul `Leaf`.
    pub fn force(
        self,
    ) -> ForceResult<
        NodeRef<BorrowType, K, V, marker::Leaf>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        if self.height == 0 {
            ForceResult::Leaf(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        } else {
            ForceResult::Internal(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        }
    }
}

/// Referensi kanggo pasangan kunci-nilai tartamtu utawa edge ing simpul.
/// Parameter `Node` kudu `NodeRef`, dene `Type` bisa uga `KV` (tegese gagang ing pasangan nilai kunci) utawa `Edge` (tegese gagang ing edge).
///
/// Elinga, sanajan kelenjar `Leaf` bisa uga gagang `Edge`.
/// Tinimbang makili pitunjuk menyang simpul bocah, iki nuduhake papan sing nuduhake target bocah ing antarane pasangan nilai kunci.
/// Contone, ing simpul kanthi dawa 2, bisa uga ana 3 lokasi edge, siji ing sisih kiwa simpul, siji ing antarane rong pasangan, lan siji ing sisih tengen simpul.
///
///
pub struct Handle<Node, Type> {
    node: Node,
    idx: usize,
    _marker: PhantomData<Type>,
}

impl<Node: Copy, Type> Copy for Handle<Node, Type> {}
// Kita ora butuh umume `#[derive(Clone)]`, amarga mung `Node` bakal dadi `Klone` yaiku nalika dadi referensi sing ora bisa diganti lan mulane `Copy`.
//
impl<Node: Copy, Type> Clone for Handle<Node, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

impl<Node, Type> Handle<Node, Type> {
    /// Nimba simpul sing ngemot pasangan edge utawa kunci-nilai sing dituju dening nangani iki.
    pub fn into_node(self) -> Node {
        self.node
    }

    /// Ngasilake posisi gagang iki ing simpul.
    pub fn idx(&self) -> usize {
        self.idx
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV> {
    /// Nggawe gagang anyar kanggo pasangan nilai kunci ing `node`.
    /// Ora aman amarga panelpon kudu mesthekake yen `idx < node.len()`.
    pub unsafe fn new_kv(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx < node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx) }
    }

    pub fn right_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx + 1) }
    }
}

impl<BorrowType, K, V, NodeType> NodeRef<BorrowType, K, V, NodeType> {
    /// Bisa dadi implementasi PartialEq kanggo umum, nanging mung digunakake ing modul iki.
    fn eq(&self, other: &Self) -> bool {
        let Self { node, height, _marker } = self;
        if node.eq(&other.node) {
            debug_assert_eq!(*height, other.height);
            true
        } else {
            false
        }
    }
}

impl<BorrowType, K, V, NodeType, HandleType> PartialEq
    for Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    fn eq(&self, other: &Self) -> bool {
        let Self { node, idx, _marker } = self;
        node.eq(&other.node) && *idx == other.idx
    }
}

impl<BorrowType, K, V, NodeType, HandleType>
    Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    /// Sementara njupuk gagang liyane sing ora bisa diganti ing lokasi sing padha.
    pub fn reborrow(&self) -> Handle<NodeRef<marker::Immut<'_>, K, V, NodeType>, HandleType> {
        // Kita ora bisa nggunakake Handle::new_kv utawa Handle::new_edge amarga ora ngerti jinis apa
        Handle { node: self.node.reborrow(), idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, Type> {
    /// Kanthi ora aman negesake menyang panyusun informasi statis manawa simpul nangani yaiku `Leaf`.
    pub unsafe fn cast_to_leaf_unchecked(
        self,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, Type> {
        let node = unsafe { self.node.cast_to_leaf_unchecked() };
        Handle { node, idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, NodeType, HandleType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, HandleType> {
    /// Sementara njupuk gagang liyane sing bisa dipateni ing lokasi sing padha.
    /// Ati-ati, amarga cara iki mbebayani banget, bisa uga tikel amarga ora bisa katon mbebayani.
    ///
    ///
    /// Kanggo rincian, waca `NodeRef::reborrow_mut`.
    pub unsafe fn reborrow_mut(
        &mut self,
    ) -> Handle<NodeRef<marker::Mut<'_>, K, V, NodeType>, HandleType> {
        // Kita ora bisa nggunakake Handle::new_kv utawa Handle::new_edge amarga ora ngerti jinis apa
        Handle { node: unsafe { self.node.reborrow_mut() }, idx: self.idx, _marker: PhantomData }
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
    /// Nggawe gagang anyar menyang edge ing `node`.
    /// Ora aman amarga panelpon kudu mesthekake yen `idx <= node.len()`.
    pub unsafe fn new_edge(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx <= node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx > 0 {
            Ok(unsafe { Handle::new_kv(self.node, self.idx - 1) })
        } else {
            Err(self)
        }
    }

    pub fn right_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx < self.node.len() {
            Ok(unsafe { Handle::new_kv(self.node, self.idx) })
        } else {
            Err(self)
        }
    }
}

pub enum LeftOrRight<T> {
    Left(T),
    Right(T),
}

/// Diwenehi indeks edge sing pengin dilebokake menyang simpul sing diisi nganti kapasitas, ngitung indeks KV sing wicaksana kanggo titik pamisah lan ing endi bakal nindakake sisipan.
///
/// Tujuan saka titik pamisahan yaiku supaya kunci lan regane bisa pungkasan ing simpul induk;
/// tombol, nilai lan sudhut ing sisih kiwa titik pamisah dadi bocah kiwa;
/// tombol, nilai lan sudhut ing sisih tengen titik pamisah dadi bocah sing bener.
fn splitpoint(edge_idx: usize) -> (usize, LeftOrRight<usize>) {
    debug_assert!(edge_idx <= CAPACITY);
    // Rust ngetokake #74834 nyoba nerangake aturan simetris kasebut.
    match edge_idx {
        0..EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER - 1, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_RIGHT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Right(0)),
        _ => (KV_IDX_CENTER + 1, LeftOrRight::Right(edge_idx - (KV_IDX_CENTER + 1 + 1))),
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Lebokake pasangan nilai kunci anyar ing antarane pasangan nilai-kunci ing sisih tengen lan kiwa edge iki.
    /// Cara iki nganggep yen cukup papan ing simpul kanggo pasangan sing pas.
    ///
    /// Pointer sing bali nuduhake nilai sing dipasang.
    ///
    fn insert_fit(&mut self, key: K, val: V) -> *mut V {
        debug_assert!(self.node.len() < CAPACITY);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            *self.node.len_mut() = new_len as u16;

            self.node.val_area_mut(self.idx).assume_init_mut()
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Lebokake pasangan nilai kunci anyar ing antarane pasangan nilai-kunci ing sisih tengen lan kiwa edge iki.
    /// Cara iki mbagi simpul yen ora cukup ruangan.
    ///
    /// Pointer sing bali nuduhake nilai sing dipasang.
    fn insert(mut self, key: K, val: V) -> (InsertResult<'a, K, V, marker::Leaf>, *mut V) {
        if self.node.len() < CAPACITY {
            let val_ptr = self.insert_fit(key, val);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            (InsertResult::Fit(kv), val_ptr)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            let val_ptr = insertion_edge.insert_fit(key, val);
            (InsertResult::Split(result), val_ptr)
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// Ndandani pointer indeks lan indeks ing simpul anak sing nyambungake edge iki.
    /// Iki migunani yen pesen pesenan wis diganti,
    fn correct_parent_link(self) {
        // Gawe backpointer tanpa validasi referensi liyane menyang simpul.
        let ptr = unsafe { NonNull::new_unchecked(NodeRef::as_internal_ptr(&self.node)) };
        let idx = self.idx;
        let mut child = self.descend();
        child.set_parent_link(ptr, idx);
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// Masang pasangan nilai kunci anyar lan edge sing bakal ana ing sisih tengen pasangan anyar antarane edge iki lan pasangan nilai kunci ing sisih tengen edge iki.
    /// Cara iki nganggep yen cukup papan ing simpul kanggo pasangan sing pas.
    ///
    fn insert_fit(&mut self, key: K, val: V, edge: Root<K, V>) {
        debug_assert!(self.node.len() < CAPACITY);
        debug_assert!(edge.height == self.node.height - 1);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            slice_insert(self.node.edge_area_mut(..new_len + 1), self.idx + 1, edge.node);
            *self.node.len_mut() = new_len as u16;

            self.node.correct_childrens_parent_links(self.idx + 1..new_len + 1);
        }
    }

    /// Masang pasangan nilai kunci anyar lan edge sing bakal ana ing sisih tengen pasangan anyar antarane edge iki lan pasangan nilai kunci ing sisih tengen edge iki.
    /// Cara iki mbagi simpul yen ora cukup ruangan.
    ///
    fn insert(
        mut self,
        key: K,
        val: V,
        edge: Root<K, V>,
    ) -> InsertResult<'a, K, V, marker::Internal> {
        assert!(edge.height == self.node.height - 1);

        if self.node.len() < CAPACITY {
            self.insert_fit(key, val, edge);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            InsertResult::Fit(kv)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            insertion_edge.insert_fit(key, val, edge);
            InsertResult::Split(result)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Lebokake pasangan nilai kunci anyar ing antarane pasangan nilai-kunci ing sisih tengen lan kiwa edge iki.
    /// Cara iki mbagi simpul yen ora cukup ruangan, lan nyoba masang bagean sing dipisahake menyang simpul induk kanthi rekursif, nganti tekan oyot.
    ///
    ///
    /// Yen asil sing bali yaiku `Fit`, simpul node bisa dadi simpul edge utawa leluhur.
    /// Yen asil sing bali yaiku `Split`, kolom `left` bakal dadi simpul root.
    /// Pointer sing bali nuduhake nilai sing dipasang.
    pub fn insert_recursing(
        self,
        key: K,
        value: V,
    ) -> (InsertResult<'a, K, V, marker::LeafOrInternal>, *mut V) {
        let (mut split, val_ptr) = match self.insert(key, value) {
            (InsertResult::Fit(handle), ptr) => {
                return (InsertResult::Fit(handle.forget_node_type()), ptr);
            }
            (InsertResult::Split(split), val_ptr) => (split.forget_node_type(), val_ptr),
        };

        loop {
            split = match split.left.ascend() {
                Ok(parent) => match parent.insert(split.kv.0, split.kv.1, split.right) {
                    InsertResult::Fit(handle) => {
                        return (InsertResult::Fit(handle.forget_node_type()), val_ptr);
                    }
                    InsertResult::Split(split) => split.forget_node_type(),
                },
                Err(root) => {
                    return (InsertResult::Split(SplitResult { left: root, ..split }), val_ptr);
                }
            };
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// Temokake simpul sing dituduhake dening edge iki.
    ///
    /// Jeneng metode nganggep sampeyan gambar wit kanthi simpul oyot ing sisih ndhuwur.
    ///
    /// `edge.descend().ascend().unwrap()` lan `node.ascend().unwrap().descend()` kudu loro, yen sukses, ora nindakake apa-apa.
    ///
    pub fn descend(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // Kita kudu nggunakake petunjuk mentah menyang simpul amarga, yen BorrowType yaiku marker::ValMut, bisa uga ana referensi sing bisa diowahi kanggo nilai sing ora bisa dibatalake.
        // Ora ana sumelang ngakses lapangan dhuwur amarga nilai kasebut disalin.
        // Ati-ati, yen penunjuk simpul nundha referensi, kita ngakses rangking pinggir kanthi referensi (Rust ngetokake #73987) lan ora validasi referensi liyane menyang utawa ing njero larik, mesthine ana sekitar.
        //
        //
        //
        //
        let parent_ptr = NodeRef::as_internal_ptr(&self.node);
        let node = unsafe { (*parent_ptr).edges.get_unchecked(self.idx).assume_init_read() };
        NodeRef { node, height: self.node.height - 1, _marker: PhantomData }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Immut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv(self) -> (&'a K, &'a V) {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf();
        let k = unsafe { leaf.keys.get_unchecked(self.idx).assume_init_ref() };
        let v = unsafe { leaf.vals.get_unchecked(self.idx).assume_init_ref() };
        (k, v)
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn key_mut(&mut self) -> &mut K {
        unsafe { self.node.key_area_mut(self.idx).assume_init_mut() }
    }

    pub fn into_val_mut(self) -> &'a mut V {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf_mut();
        unsafe { leaf.vals.get_unchecked_mut(self.idx).assume_init_mut() }
    }
}

impl<'a, K, V, NodeType> Handle<NodeRef<marker::ValMut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv_valmut(self) -> (&'a K, &'a mut V) {
        unsafe { self.node.into_key_val_mut_at(self.idx) }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn kv_mut(&mut self) -> (&mut K, &mut V) {
        debug_assert!(self.idx < self.node.len());
        // Kita ora bisa nelpon cara tombol lan nilai sing kapisah, amarga nelpon nomer loro bakal ngilangi referensi sing bali.
        //
        unsafe {
            let leaf = self.node.as_leaf_mut();
            let key = leaf.keys.get_unchecked_mut(self.idx).assume_init_mut();
            let val = leaf.vals.get_unchecked_mut(self.idx).assume_init_mut();
            (key, val)
        }
    }

    /// Ganti tombol lan nilai sing diarani KV.
    pub fn replace_kv(&mut self, k: K, v: V) -> (K, V) {
        let (key, val) = self.kv_mut();
        (mem::replace(key, k), mem::replace(val, v))
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    /// Mbantu implementasi `split` kanggo `NodeType` tartamtu, kanthi ngurus data godhong.
    ///
    fn split_leaf_data(&mut self, new_node: &mut LeafNode<K, V>) -> (K, V) {
        debug_assert!(self.idx < self.node.len());
        let old_len = self.node.len();
        let new_len = old_len - self.idx - 1;
        new_node.len = new_len as u16;
        unsafe {
            let k = self.node.key_area_mut(self.idx).assume_init_read();
            let v = self.node.val_area_mut(self.idx).assume_init_read();

            move_to_slice(
                self.node.key_area_mut(self.idx + 1..old_len),
                &mut new_node.keys[..new_len],
            );
            move_to_slice(
                self.node.val_area_mut(self.idx + 1..old_len),
                &mut new_node.vals[..new_len],
            );

            *self.node.len_mut() = self.idx as u16;
            (k, v)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::KV> {
    /// Pisah simpul sing dadi telung bagean:
    ///
    /// - Node dipotong supaya mung ngemot pasangan kunci-nilai ing sisih kiwa gagang iki.
    /// - Kunci lan nilai sing dituduhake dening gagang iki dijupuk.
    /// - Kabeh pasangan nilai kunci ing sisih tengen gagang iki dilebokake ing simpul sing mentas dialokasikan.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Leaf> {
        let mut new_node = LeafNode::new();

        let kv = self.split_leaf_data(&mut new_node);

        let right = NodeRef::from_new_leaf(new_node);
        SplitResult { left: self.node, kv, right }
    }

    /// Mbusak pasangan rega-kunci sing dituduhake dening gagang iki lan ngasilake, bebarengan karo edge sing pasangan kunci-nilai kasebut ambruk.
    ///
    pub fn remove(
        mut self,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        let old_len = self.node.len();
        unsafe {
            let k = slice_remove(self.node.key_area_mut(..old_len), self.idx);
            let v = slice_remove(self.node.val_area_mut(..old_len), self.idx);
            *self.node.len_mut() = (old_len - 1) as u16;
            ((k, v), self.left_edge())
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    /// Pisah simpul sing dadi telung bagean:
    ///
    /// - Node dipotong supaya mung ngemot pinggiran lan pasangan nilai kunci ing sisih kiwa gagang iki.
    /// - Kunci lan nilai sing dituduhake dening gagang iki dijupuk.
    /// - Kabeh pinggiran lan pasangan nilai kunci ing sisih tengen gagang iki dilebokake ing simpul sing mentas dialokasikan.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Internal> {
        let old_len = self.node.len();
        unsafe {
            let mut new_node = InternalNode::new();
            let kv = self.split_leaf_data(&mut new_node.data);
            let new_len = usize::from(new_node.data.len);
            move_to_slice(
                self.node.edge_area_mut(self.idx + 1..old_len + 1),
                &mut new_node.edges[..new_len + 1],
            );

            let height = self.node.height;
            let right = NodeRef::from_new_internal(new_node, height);

            SplitResult { left: self.node, kv, right }
        }
    }
}

/// Makili sesi kanggo ngevaluasi lan nindakake operasi wawas sajrone pasangan nilai kunci internal.
///
pub struct BalancingContext<'a, K, V> {
    parent: Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV>,
    left_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    right_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    pub fn consider_for_balancing(self) -> BalancingContext<'a, K, V> {
        let self1 = unsafe { ptr::read(&self) };
        let self2 = unsafe { ptr::read(&self) };
        BalancingContext {
            parent: self,
            left_child: self1.left_edge().descend(),
            right_child: self2.right_edge().descend(),
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Milih konteks saldo sing nyakup simpul minangka bocah, mula ing antarane KV langsung ing sisih kiwa utawa nengen ing simpul induk.
    /// Ngasilake `Err` yen ora ana wong tuwa.
    /// Panics yen wong tuwa kosong.
    ///
    /// Luwih seneng sisih kiwa, dadi optimal yen simpul sing diwenehake ora pati penting, tegese ing kene mung unsur sing luwih sithik tinimbang sadulur kiwa lan sadulure sing bener, yen ana.
    /// Yen ngono, gabung karo sedulur kiwa luwih cepet, amarga kita mung kudu mindhah elemen N simpul, tinimbang ngalih menyang sisih tengen lan mindhah luwih saka elemen N ing ngarep.
    /// Nyolong saka sadulur kiwa uga biasane luwih cepet, amarga kita mung kudu ngalihake elemen N simpul menyang sisih tengen, tinimbang ngowahi paling ora unsur-unsur saka sadulur ing kiwa.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn choose_parent_kv(self) -> Result<LeftOrRight<BalancingContext<'a, K, V>>, Self> {
        match unsafe { ptr::read(&self) }.ascend() {
            Ok(parent_edge) => match parent_edge.left_kv() {
                Ok(left_parent_kv) => Ok(LeftOrRight::Left(BalancingContext {
                    parent: unsafe { ptr::read(&left_parent_kv) },
                    left_child: left_parent_kv.left_edge().descend(),
                    right_child: self,
                })),
                Err(parent_edge) => match parent_edge.right_kv() {
                    Ok(right_parent_kv) => Ok(LeftOrRight::Right(BalancingContext {
                        parent: unsafe { ptr::read(&right_parent_kv) },
                        left_child: self,
                        right_child: right_parent_kv.right_edge().descend(),
                    })),
                    Err(_) => unreachable!("empty internal node"),
                },
            },
            Err(root) => Err(root),
        }
    }
}

impl<'a, K, V> BalancingContext<'a, K, V> {
    pub fn left_child_len(&self) -> usize {
        self.left_child.len()
    }

    pub fn right_child_len(&self) -> usize {
        self.right_child.len()
    }

    pub fn into_left_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.left_child
    }

    pub fn into_right_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.right_child
    }

    /// Ngasilake manawa gabungan bisa uga, yaiku, manawa ana cukup ruangan ing simpul kanggo nggabungake KV tengah kanthi kalor kelenjar bocah.
    ///
    pub fn can_merge(&self) -> bool {
        self.left_child.len() + 1 + self.right_child.len() <= CAPACITY
    }
}

impl<'a, K: 'a, V: 'a> BalancingContext<'a, K, V> {
    /// Nindakake penggabungan lan ngidini panutupan mutusake apa sing bakal bali.
    fn do_merge<
        F: FnOnce(
            NodeRef<marker::Mut<'a>, K, V, marker::Internal>,
            NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
        ) -> R,
        R,
    >(
        self,
        result: F,
    ) -> R {
        let Handle { node: mut parent_node, idx: parent_idx, _marker } = self.parent;
        let old_parent_len = parent_node.len();
        let mut left_node = self.left_child;
        let old_left_len = left_node.len();
        let mut right_node = self.right_child;
        let right_len = right_node.len();
        let new_left_len = old_left_len + 1 + right_len;

        assert!(new_left_len <= CAPACITY);

        unsafe {
            *left_node.len_mut() = new_left_len as u16;

            let parent_key = slice_remove(parent_node.key_area_mut(..old_parent_len), parent_idx);
            left_node.key_area_mut(old_left_len).write(parent_key);
            move_to_slice(
                right_node.key_area_mut(..right_len),
                left_node.key_area_mut(old_left_len + 1..new_left_len),
            );

            let parent_val = slice_remove(parent_node.val_area_mut(..old_parent_len), parent_idx);
            left_node.val_area_mut(old_left_len).write(parent_val);
            move_to_slice(
                right_node.val_area_mut(..right_len),
                left_node.val_area_mut(old_left_len + 1..new_left_len),
            );

            slice_remove(&mut parent_node.edge_area_mut(..old_parent_len + 1), parent_idx + 1);
            parent_node.correct_childrens_parent_links(parent_idx + 1..old_parent_len);
            *parent_node.len_mut() -= 1;

            if parent_node.height > 1 {
                // SAFETY: dhuwure simpul sing digabung ana ing ngisor dhuwur
                // saka simpul edge iki, mula ing ndhuwur nol, mula internal.
                let mut left_node = left_node.reborrow_mut().cast_to_internal_unchecked();
                let mut right_node = right_node.cast_to_internal_unchecked();
                move_to_slice(
                    right_node.edge_area_mut(..right_len + 1),
                    left_node.edge_area_mut(old_left_len + 1..new_left_len + 1),
                );

                left_node.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);

                Global.deallocate(right_node.node.cast(), Layout::new::<InternalNode<K, V>>());
            } else {
                Global.deallocate(right_node.node.cast(), Layout::new::<LeafNode<K, V>>());
            }
        }
        result(parent_node, left_node)
    }

    /// Nggabungake pasangan nilai kunci wong tuwa lan kalor simpul bocah ing simpul bocah kiwa lan ngasilake simpul induk sing nyusut.
    ///
    ///
    /// Panics kajaba kita `.can_merge()`.
    pub fn merge_tracking_parent(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        self.do_merge(|parent, _child| parent)
    }

    /// Nggabungake pasangan nilai kunci wong tuwa lan kalor kelenjar bocah ing simpul bocah kiwa lan ngasilake simpul bocah kasebut.
    ///
    ///
    /// Panics kajaba kita `.can_merge()`.
    pub fn merge_tracking_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.do_merge(|_parent, child| child)
    }

    /// Nggabungake pasangan nilai kunci wong tuwa lan kalor simpul bocah ing simpul bocah kiwa lan ngasilake gagang edge ing simpul bocah ing endi edge bocah sing dilacak rampung,
    ///
    ///
    /// Panics kajaba kita `.can_merge()`.
    ///
    pub fn merge_tracking_child_edge(
        self,
        track_edge_idx: LeftOrRight<usize>,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        let old_left_len = self.left_child.len();
        let right_len = self.right_child.len();
        assert!(match track_edge_idx {
            LeftOrRight::Left(idx) => idx <= old_left_len,
            LeftOrRight::Right(idx) => idx <= right_len,
        });
        let child = self.merge_tracking_child();
        let new_idx = match track_edge_idx {
            LeftOrRight::Left(idx) => idx,
            LeftOrRight::Right(idx) => old_left_len + 1 + idx,
        };
        unsafe { Handle::new_edge(child, new_idx) }
    }

    /// Copot pasangan nilai-kunci saka bocah kiwa lan lebokake ing panyimpenan nilai-tuwa saka wong tuwa, nalika meksa pasangan kunci-kunci tuwa menyang bocah sing bener.
    ///
    /// Ngasilake gagang menyang edge ing bocah tengen sing cocog karo endi edge asli sing ditemtokake dening `track_right_edge_idx` rampung.
    ///
    pub fn steal_left(
        mut self,
        track_right_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_left(1);
        unsafe { Handle::new_edge(self.right_child, 1 + track_right_edge_idx) }
    }

    /// Copot pasangan nilai-kunci saka bocah sing tengen lan lebokake ing panyimpenan nilai-tuwa saka wong tuwa, nalika meksa pasangan kunci-kunci tuwa menyang bocah kiwa.
    ///
    /// Ngasilake gagang menyang edge ing bocah kiwa sing ditemtokake dening `track_left_edge_idx`, sing ora obah.
    ///
    pub fn steal_right(
        mut self,
        track_left_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_right(1);
        unsafe { Handle::new_edge(self.left_child, track_left_edge_idx) }
    }

    /// Iki nyolong padha karo `steal_left` nanging nyolong macem-macem elemen sekaligus.
    pub fn bulk_steal_left(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // Priksa manawa kita bisa nyolong kanthi aman.
            assert!(old_right_len + count <= CAPACITY);
            assert!(old_left_len >= count);

            let new_left_len = old_left_len - count;
            let new_right_len = old_right_len + count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // Pindhah data godhong.
            {
                // Gawe ruang kanggo unsur sing dicolong ing bocah sing bener.
                slice_shr(right_node.key_area_mut(..new_right_len), count);
                slice_shr(right_node.val_area_mut(..new_right_len), count);

                // Pindhah elemen saka bocah kiwa menyang tengen.
                move_to_slice(
                    left_node.key_area_mut(new_left_len + 1..old_left_len),
                    right_node.key_area_mut(..count - 1),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len + 1..old_left_len),
                    right_node.val_area_mut(..count - 1),
                );

                // Pindhah pasangan sing paling dicolong kiwa menyang wong tuwa.
                let k = left_node.key_area_mut(new_left_len).assume_init_read();
                let v = left_node.val_area_mut(new_left_len).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // Pindhah pasangan nilai kunci wong tuwa menyang bocah sing bener.
                right_node.key_area_mut(count - 1).write(k);
                right_node.val_area_mut(count - 1).write(v);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // Gawe ruangan kanggo sudhut sing dicolong.
                    slice_shr(right.edge_area_mut(..new_right_len + 1), count);

                    // Nyolong sudhut.
                    move_to_slice(
                        left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                        right.edge_area_mut(..count),
                    );

                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }

    /// Klon simetris `bulk_steal_left`.
    pub fn bulk_steal_right(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // Priksa manawa kita bisa nyolong kanthi aman.
            assert!(old_left_len + count <= CAPACITY);
            assert!(old_right_len >= count);

            let new_left_len = old_left_len + count;
            let new_right_len = old_right_len - count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // Pindhah data godhong.
            {
                // Pindhah pasangan sing paling dicolong paling bener menyang wong tuwa.
                let k = right_node.key_area_mut(count - 1).assume_init_read();
                let v = right_node.val_area_mut(count - 1).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // Pindhah pasangan nilai kunci wong tuwa menyang bocah kiwa.
                left_node.key_area_mut(old_left_len).write(k);
                left_node.val_area_mut(old_left_len).write(v);

                // Pindhah elemen saka bocah nengen menyang kiwa.
                move_to_slice(
                    right_node.key_area_mut(..count - 1),
                    left_node.key_area_mut(old_left_len + 1..new_left_len),
                );
                move_to_slice(
                    right_node.val_area_mut(..count - 1),
                    left_node.val_area_mut(old_left_len + 1..new_left_len),
                );

                // Isi longkangan ing endi unsur sing wis dicolong.
                slice_shl(right_node.key_area_mut(..old_right_len), count);
                slice_shl(right_node.val_area_mut(..old_right_len), count);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // Nyolong sudhut.
                    move_to_slice(
                        right.edge_area_mut(..count),
                        left.edge_area_mut(old_left_len + 1..new_left_len + 1),
                    );

                    // Isi celah ing endi sing dicolong sadurunge.
                    slice_shl(right.edge_area_mut(..old_right_len + 1), count);

                    left.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);
                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Leaf> {
    /// Mbusak informasi statis apa wae sing negesake manawa simpul iki minangka simpul `Leaf`.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Mbusak informasi statis apa wae sing negesake manawa simpul iki minangka simpul `Internal`.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V, Type> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, Type> {
    /// Priksa manawa simpul sing ndasari yaiku simpul `Internal` utawa simpul `Leaf`.
    pub fn force(
        self,
    ) -> ForceResult<
        Handle<NodeRef<BorrowType, K, V, marker::Leaf>, Type>,
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, Type>,
    > {
        match self.node.force() {
            ForceResult::Leaf(node) => {
                ForceResult::Leaf(Handle { node, idx: self.idx, _marker: PhantomData })
            }
            ForceResult::Internal(node) => {
                ForceResult::Internal(Handle { node, idx: self.idx, _marker: PhantomData })
            }
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
    /// Pindhah akhiran sawise `self` saka siji simpul menyang liyane.`right` kudu kosong.
    /// edge pertama `right` tetep ora owah.
    pub fn move_suffix(
        &mut self,
        right: &mut NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    ) {
        unsafe {
            let new_left_len = self.idx;
            let mut left_node = self.reborrow_mut().into_node();
            let old_left_len = left_node.len();

            let new_right_len = old_left_len - new_left_len;
            let mut right_node = right.reborrow_mut();

            assert!(right_node.len() == 0);
            assert!(left_node.height == right_node.height);

            if new_right_len > 0 {
                *left_node.len_mut() = new_left_len as u16;
                *right_node.len_mut() = new_right_len as u16;

                move_to_slice(
                    left_node.key_area_mut(new_left_len..old_left_len),
                    right_node.key_area_mut(..new_right_len),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len..old_left_len),
                    right_node.val_area_mut(..new_right_len),
                );
                match (left_node.force(), right_node.force()) {
                    (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                        move_to_slice(
                            left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                            right.edge_area_mut(1..new_right_len + 1),
                        );
                        right.correct_childrens_parent_links(1..new_right_len + 1);
                    }
                    (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                    _ => unreachable!(),
                }
            }
        }
    }
}

pub enum ForceResult<Leaf, Internal> {
    Leaf(Leaf),
    Internal(Internal),
}

/// Asil sisipan, nalika simpul perlu kanggo ngluwihi kapasitas.
pub struct SplitResult<'a, K, V, NodeType> {
    // Simpul sing diowahi ing wit sing ana kanthi unsur lan pinggiran sing ana ing sisih kiwa `kv`.
    pub left: NodeRef<marker::Mut<'a>, K, V, NodeType>,
    // Sawetara tombol lan nilai dipisahake, kanggo dilebokake ing papan liya.
    pub kv: (K, V),
    // Simpul anyar sing diduweni, ora dipasang, nganggo elemen lan pinggiran sing ana ing sisih tengen `kv`.
    pub right: NodeRef<marker::Owned, K, V, NodeType>,
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Leaf> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Internal> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

pub enum InsertResult<'a, K, V, NodeType> {
    Fit(Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV>),
    Split(SplitResult<'a, K, V, NodeType>),
}

pub mod marker {
    use core::marker::PhantomData;

    pub enum Leaf {}
    pub enum Internal {}
    pub enum LeafOrInternal {}

    pub enum Owned {}
    pub enum Dying {}
    pub struct Immut<'a>(PhantomData<&'a ()>);
    pub struct Mut<'a>(PhantomData<&'a mut ()>);
    pub struct ValMut<'a>(PhantomData<&'a mut ()>);

    pub trait BorrowType {
        // Apa referensi simpul jinis utang iki ngidini ngliwati simpul liyane ing wit.
        //
        const PERMITS_TRAVERSAL: bool = true;
    }
    impl BorrowType for Owned {
        // Traversal ora perlu, kedadeyan nggunakake asil `borrow_mut`.
        // Kanthi mateni traversal, lan mung nggawe referensi anyar kanggo root, kita ngerti manawa saben referensi jinis `Owned` yaiku simpul root.
        //
        const PERMITS_TRAVERSAL: bool = false;
    }
    impl BorrowType for Dying {}
    impl<'a> BorrowType for Immut<'a> {}
    impl<'a> BorrowType for Mut<'a> {}
    impl<'a> BorrowType for ValMut<'a> {}

    pub enum KV {}
    pub enum Edge {}
}

/// Nyisipake nilai menyang irisan elemen inisialisasi sing diikuti karo siji unsur sing ora dinisialisasi.
///
/// # Safety
/// Irisan kasebut duwe luwih saka `idx` elemen.
unsafe fn slice_insert<T>(slice: &mut [MaybeUninit<T>], idx: usize, val: T) {
    unsafe {
        let len = slice.len();
        debug_assert!(len > idx);
        let slice_ptr = slice.as_mut_ptr();
        if len > idx + 1 {
            ptr::copy(slice_ptr.add(idx), slice_ptr.add(idx + 1), len - idx - 1);
        }
        (*slice_ptr.add(idx)).write(val);
    }
}

/// Mbusak lan ngasilake regane saka irisan kabeh unsur sing wis diwiwiti, dadi siji unsur sing ora bisa diresiki.
///
///
/// # Safety
/// Irisan kasebut duwe luwih saka `idx` elemen.
unsafe fn slice_remove<T>(slice: &mut [MaybeUninit<T>], idx: usize) -> T {
    unsafe {
        let len = slice.len();
        debug_assert!(idx < len);
        let slice_ptr = slice.as_mut_ptr();
        let ret = (*slice_ptr.add(idx)).assume_init_read();
        ptr::copy(slice_ptr.add(idx + 1), slice_ptr.add(idx), len - idx - 1);
        ret
    }
}

/// Ganti elemen ing posisi `distance` irisan ngiwa.
///
/// # Safety
/// Irisan paling ora duwe elemen `distance`.
unsafe fn slice_shl<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr.add(distance), slice_ptr, slice.len() - distance);
    }
}

/// Ganti elemen ing posisi `distance` irisan ing sisih tengen.
///
/// # Safety
/// Irisan paling ora duwe elemen `distance`.
unsafe fn slice_shr<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr, slice_ptr.add(distance), slice.len() - distance);
    }
}

/// Pindhah kabeh nilai saka irisan elemen sing diinisialisasi dadi irisan elemen sing ora diresmine, lan nuli ditinggalake `src` minangka kabeh sing ora diresmine.
///
/// Bisa kaya `dst.copy_from_slice(src)` nanging ora mbutuhake `T` dadi `Copy`.
fn move_to_slice<T>(src: &mut [MaybeUninit<T>], dst: &mut [MaybeUninit<T>]) {
    assert!(src.len() == dst.len());
    unsafe {
        ptr::copy_nonoverlapping(src.as_ptr(), dst.as_mut_ptr(), src.len());
    }
}

#[cfg(test)]
mod tests;