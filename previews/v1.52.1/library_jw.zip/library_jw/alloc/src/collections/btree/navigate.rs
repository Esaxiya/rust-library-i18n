use core::borrow::Borrow;
use core::ops::RangeBounds;
use core::ptr;

use super::node::{marker, ForceResult::*, Handle, NodeRef};

pub struct LeafRange<BorrowType, K, V> {
    pub front: Option<Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>>,
    pub back: Option<Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>>,
}

impl<BorrowType, K, V> LeafRange<BorrowType, K, V> {
    pub fn none() -> Self {
        LeafRange { front: None, back: None }
    }

    pub fn is_empty(&self) -> bool {
        self.front == self.back
    }

    /// Sedhela njupuk sing padha, sing ora bisa diowahi kanthi sawetara sing padha.
    pub fn reborrow(&self) -> LeafRange<marker::Immut<'_>, K, V> {
        LeafRange {
            front: self.front.as_ref().map(|f| f.reborrow()),
            back: self.back.as_ref().map(|b| b.reborrow()),
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Temokake sudhut godhong sing beda sing mbatesi sawetara sing ditemtokake ing wit.
    /// Ngasilake sepasang gagang sing beda menyang wit sing padha utawa sepasang opsi kosong.
    ///
    /// # Safety
    ///
    /// Kajaba `BorrowType` minangka `Immut`, aja nganggo gagang duplikat kanggo ngunjungi KV sing padha kaping pindho.
    unsafe fn find_leaf_edges_spanning_range<Q: ?Sized, R>(
        self,
        range: R,
    ) -> LeafRange<BorrowType, K, V>
    where
        Q: Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        match self.search_tree_for_bifurcation(&range) {
            Err(_) => LeafRange::none(),
            Ok((
                node,
                lower_edge_idx,
                upper_edge_idx,
                mut lower_child_bound,
                mut upper_child_bound,
            )) => {
                let mut lower_edge = unsafe { Handle::new_edge(ptr::read(&node), lower_edge_idx) };
                let mut upper_edge = unsafe { Handle::new_edge(node, upper_edge_idx) };
                loop {
                    match (lower_edge.force(), upper_edge.force()) {
                        (Leaf(f), Leaf(b)) => return LeafRange { front: Some(f), back: Some(b) },
                        (Internal(f), Internal(b)) => {
                            (lower_edge, lower_child_bound) =
                                f.descend().find_lower_bound_edge(lower_child_bound);
                            (upper_edge, upper_child_bound) =
                                b.descend().find_upper_bound_edge(upper_child_bound);
                        }
                        _ => unreachable!("BTreeMap has different depths"),
                    }
                }
            }
        }
    }
}

/// Setara karo `(root1.first_leaf_edge(), root2.last_leaf_edge())` nanging luwih efisien.
fn full_range<BorrowType: marker::BorrowType, K, V>(
    root1: NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    root2: NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
) -> LeafRange<BorrowType, K, V> {
    let mut min_node = root1;
    let mut max_node = root2;
    loop {
        let front = min_node.first_edge();
        let back = max_node.last_edge();
        match (front.force(), back.force()) {
            (Leaf(f), Leaf(b)) => {
                return LeafRange { front: Some(f), back: Some(b) };
            }
            (Internal(min_int), Internal(max_int)) => {
                min_node = min_int.descend();
                max_node = max_int.descend();
            }
            _ => unreachable!("BTreeMap has different depths"),
        };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Immut<'a>, K, V, marker::LeafOrInternal> {
    /// Temokake pasangan pinggiran godhong sing mbatesi sawetara tartamtu ing wit.
    ///
    /// Asil kasebut mung migunani yen wit dipesen kanthi tombol, kaya wit ing `BTreeMap` yaiku.
    ///
    pub fn range_search<Q, R>(self, range: R) -> LeafRange<marker::Immut<'a>, K, V>
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        // SAFETY: jinis utangan kita ora bisa diowahi.
        unsafe { self.find_leaf_edges_spanning_range(range) }
    }

    /// Temokake pasangan pinggiran godhong sing mbatesi kabeh wit.
    pub fn full_range(self) -> LeafRange<marker::Immut<'a>, K, V> {
        full_range(self, self)
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::ValMut<'a>, K, V, marker::LeafOrInternal> {
    /// Misahake referensi unik menyang sepasang sudhut godhong sing mbatesi sawetara sing ditemtokake.
    /// Asil kasebut minangka referensi non-unik sing ngidini mutasi (some), sing kudu digunakake kanthi tliti.
    ///
    /// Asil kasebut mung migunani yen wit dipesen kanthi tombol, kaya wit ing `BTreeMap` yaiku.
    ///
    ///
    /// # Safety
    /// Aja nggunakake gagang duplikat kanggo ngunjungi KV sing padha kaping pindho.
    ///
    pub fn range_search<Q, R>(self, range: R) -> LeafRange<marker::ValMut<'a>, K, V>
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        unsafe { self.find_leaf_edges_spanning_range(range) }
    }

    /// Misahake referensi unik menyang sepasang sudhut godhong sing mbatesi macem-macem wit.
    /// Asil kasebut minangka referensi non-unik sing ngidini mutasi (mung regane), mula kudu digunakake kanthi ati-ati.
    ///
    pub fn full_range(self) -> LeafRange<marker::ValMut<'a>, K, V> {
        // Kita nduplikat ROOT NodeRef ing kene-ora bakal ngunjungi KV sing padha kaping pindho, lan ora bakal mungkasi referensi nilai sing tumpang tindih.
        //
        let self2 = unsafe { ptr::read(&self) };
        full_range(self, self2)
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// Misahake referensi unik menyang sepasang sudhut godhong sing mbatesi macem-macem wit.
    /// Asil kasebut minangka referensi non-unik sing ngidini mutasi sing rusak banget, mula kudu digunakake kanthi ati-ati.
    ///
    pub fn full_range(self) -> LeafRange<marker::Dying, K, V> {
        // Kita nduplikat root NodeRef ing kene-ora bakal bisa ngakses kanthi cara tumpang tindih referensi sing dipikolehi saka root.
        //
        let self2 = unsafe { ptr::read(&self) };
        full_range(self, self2)
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>
{
    /// Menehi gagang edge godhong, ngasilake [`Result::Ok`] nganggo gagang menyang KV tanggané ing sisih tengen, sing ana ing simpul godhong sing padha utawa ing simpul leluhur.
    ///
    /// Yen rwaning edge minangka sing terakhir ing wit, bali [`Result::Err`] kanthi simpul root.
    pub fn next_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    > {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.right_kv() {
                Ok(kv) => return Ok(kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge.forget_node_type(),
                    Err(root) => return Err(root),
                },
            }
        }
    }

    /// Diwenehi gagang edge godhong, ngasilake [`Result::Ok`] kanthi gagang menyang KV tetanggan ing sisih kiwa, sing ana ing simpul godhong sing padha utawa ing simpul leluhur.
    ///
    /// Yen godhong edge minangka sing pertama ing wit, bali [`Result::Err`] kanthi simpul root.
    pub fn next_back_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    > {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.left_kv() {
                Ok(kv) => return Ok(kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge.forget_node_type(),
                    Err(root) => return Err(root),
                },
            }
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// Diwenehi gagang edge internal, ngasilake [`Result::Ok`] kanthi gagang menyang KV tetanggan ing sisih tengen, yaiku ing simpul internal sing padha utawa ing simpul leluhur.
    ///
    /// Yen edge internal minangka sing terakhir ing wit, bali [`Result::Err`] kanthi simpul root.
    pub fn next_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        let mut edge = self;
        loop {
            edge = match edge.right_kv() {
                Ok(internal_kv) => return Ok(internal_kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge,
                    Err(root) => return Err(root),
                },
            }
        }
    }
}

impl<K, V> Handle<NodeRef<marker::Dying, K, V, marker::Leaf>, marker::Edge> {
    /// Menehi gagang edge dadi wit sing lagi sekarat, ngasilake godhong sabanjure edge ing sisih tengen, lan pasangan nilai kunci ing antarane, yaiku ing simpul godhong sing padha, ing simpul leluhur, utawa ora ana.
    ///
    ///
    /// Cara iki uga bisa ngatasi node(s) sing pungkasan.
    /// Iki tegese yen ora ana pasangan kunci-kunci maneh, kabeh sisa wit bakal ditrapake lan ora ana sing bisa dibalekake maneh.
    ///
    /// # Safety
    /// edge sing diwenehake mesthine kudu sadurunge dibalekake karo mitra `deallocating_next_back`.
    ///
    ///
    ///
    unsafe fn deallocating_next(self) -> Option<(Self, (K, V))> {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.right_kv() {
                Ok(kv) => {
                    let k = unsafe { ptr::read(kv.reborrow().into_kv().0) };
                    let v = unsafe { ptr::read(kv.reborrow().into_kv().1) };
                    return Some((kv.next_leaf_edge(), (k, v)));
                }
                Err(last_edge) => match unsafe { last_edge.into_node().deallocate_and_ascend() } {
                    Some(parent_edge) => parent_edge.forget_node_type(),
                    None => return None,
                },
            }
        }
    }

    /// Diwenehi gagang edge dadi wit sing lagi sekarat, ngasilake godhong sabanjure edge ing sisih kiwa, lan pasangan nilai utama ing antarane, yaiku ing simpul godhong sing padha, ing simpul leluhur, utawa ora ana.
    ///
    ///
    /// Cara iki uga bisa ngatasi node(s) sing pungkasan.
    /// Iki tegese yen ora ana pasangan kunci-kunci maneh, kabeh sisa wit bakal ditrapake lan ora ana sing bisa dibalekake maneh.
    ///
    /// # Safety
    /// edge sing diwenehake mesthine kudu sadurunge dibalekake karo mitra `deallocating_next`.
    ///
    ///
    ///
    unsafe fn deallocating_next_back(self) -> Option<(Self, (K, V))> {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.left_kv() {
                Ok(kv) => {
                    let k = unsafe { ptr::read(kv.reborrow().into_kv().0) };
                    let v = unsafe { ptr::read(kv.reborrow().into_kv().1) };
                    return Some((kv.next_back_leaf_edge(), (k, v)));
                }
                Err(last_edge) => match unsafe { last_edge.into_node().deallocate_and_ascend() } {
                    Some(parent_edge) => parent_edge.forget_node_type(),
                    None => return None,
                },
            }
        }
    }

    /// Deallocates tumpukan simpul saka godhong nganti oyot.
    /// Iki minangka cara mung kanggo ngatasi sisan wit sawise `deallocating_next` lan `deallocating_next_back` wis nibbling ing loro-lorone wit, lan tekan edge sing padha.
    /// Kaya sing dimaksud mung kanggo ditelpon nalika kabeh tombol lan nilai wis dikembalikan, ora ana reresik ing tombol utawa nilai apa wae.
    ///
    ///
    ///
    pub fn deallocating_end(self) {
        let mut edge = self.forget_node_type();
        while let Some(parent_edge) = unsafe { edge.into_node().deallocate_and_ascend() } {
            edge = parent_edge.forget_node_type();
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Immut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Pindhah gagang edge menyang godhong edge sabanjure lan ngasilake referensi tombol lan nilai ing antarane.
    ///
    ///
    /// # Safety
    /// Mesthi ana KV liyane ing arah sing dituju.
    pub unsafe fn next_unchecked(&mut self) -> (&'a K, &'a V) {
        super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (kv.next_leaf_edge(), kv.into_kv())
        })
    }

    /// Pindhah gagang edge rwaning menyang godhong edge sadurunge lan ngasilake referensi tombol lan nilai ing antarane.
    ///
    ///
    /// # Safety
    /// Mesthi ana KV liyane ing arah sing dituju.
    pub unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a V) {
        super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_back_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (kv.next_back_leaf_edge(), kv.into_kv())
        })
    }
}

impl<'a, K, V> Handle<NodeRef<marker::ValMut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Pindhah gagang edge menyang godhong edge sabanjure lan ngasilake referensi tombol lan nilai ing antarane.
    ///
    ///
    /// # Safety
    /// Mesthi ana KV liyane ing arah sing dituju.
    pub unsafe fn next_unchecked(&mut self) -> (&'a K, &'a mut V) {
        let kv = super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (unsafe { ptr::read(&kv) }.next_leaf_edge(), kv)
        });
        // Nindakake pungkasan iki luwih cepet, miturut pathokan.
        kv.into_kv_valmut()
    }

    /// Pindhah gagang edge godhong menyang rwaning sadurunge lan ngasilake referensi tombol lan nilai ing antarane.
    ///
    ///
    /// # Safety
    /// Mesthi ana KV liyane ing arah sing dituju.
    pub unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a mut V) {
        let kv = super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_back_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (unsafe { ptr::read(&kv) }.next_back_leaf_edge(), kv)
        });
        // Nindakake pungkasan iki luwih cepet, miturut pathokan.
        kv.into_kv_valmut()
    }
}

impl<K, V> Handle<NodeRef<marker::Dying, K, V, marker::Leaf>, marker::Edge> {
    /// Pindhah gagang edge menyang godhong edge sabanjure lan bali kunci lan regane ing antarane, menehi transaksi node apa wae sing ditinggalake nalika ninggalake edge sing ana ing simpul induk.
    ///
    /// # Safety
    /// - Mesthi ana KV liyane ing arah sing dituju.
    /// - KV kasebut sadurunge ora bali dening mitra `next_back_unchecked` ing salinan gagang sing digunakake kanggo nyebrang wit kasebut.
    ///
    /// Siji-sijine cara sing aman kanggo nerusake gagang sing dianyari yaiku mbandhingake, nyelehake, nelpon cara iki maneh tundhuk kahanan keamanan, utawa nelpon mitra `next_back_unchecked` sing tundhuk kahanan keamanan.
    ///
    ///
    ///
    ///
    ///
    pub unsafe fn deallocating_next_unchecked(&mut self) -> (K, V) {
        super::mem::replace(self, |leaf_edge| unsafe {
            leaf_edge.deallocating_next().unwrap_unchecked()
        })
    }

    /// Pindhah gagang edge menyang godhong edge sadurunge lan ngasilake kunci lan regane ing antarane, menehi transaksi node apa wae sing ditinggalake nalika ninggalake edge sing ana ing simpul induk.
    ///
    /// # Safety
    /// - Mesthi ana KV liyane ing arah sing dituju.
    /// - Godhong edge sadurunge ora dibalekake karo mitra `next_unchecked` ing salinan gagang sing digunakake kanggo nyebrang wit kasebut.
    ///
    /// Siji-sijine cara sing aman kanggo nerusake gagang sing dianyari yaiku mbandhingake, nyelehake, nelpon cara iki maneh tundhuk kondhisi aman, utawa nelpon mitra `next_unchecked` sing tundhuk kahanan keamanan.
    ///
    ///
    ///
    ///
    ///
    pub unsafe fn deallocating_next_back_unchecked(&mut self) -> (K, V) {
        super::mem::replace(self, |leaf_edge| unsafe {
            leaf_edge.deallocating_next_back().unwrap_unchecked()
        })
    }
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Ngasilake rwaning kiwa edge ing utawa ing sangisore simpul, kanthi tembung liya, edge sing sampeyan butuhake nalika navigasi maju (utawa pungkasan nalika navigasi mundur).
    ///
    #[inline]
    pub fn first_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        let mut node = self;
        loop {
            match node.force() {
                Leaf(leaf) => return leaf.first_edge(),
                Internal(internal) => node = internal.first_edge().descend(),
            }
        }
    }

    /// Ngasilake rwaning sisih tengen edge ing utawa ing sangisore simpul, kanthi tembung liya, edge sing sampeyan butuhake nalika navigasi maju (utawa luwih dhisik nalika navigasi mundur).
    ///
    #[inline]
    pub fn last_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        let mut node = self;
        loop {
            match node.force() {
                Leaf(leaf) => return leaf.last_edge(),
                Internal(internal) => node = internal.last_edge().descend(),
            }
        }
    }
}

pub enum Position<BorrowType, K, V> {
    Leaf(NodeRef<BorrowType, K, V, marker::Leaf>),
    Internal(NodeRef<BorrowType, K, V, marker::Internal>),
    InternalKV(Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV>),
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Immut<'a>, K, V, marker::LeafOrInternal> {
    /// Kunjungan node rwaning lan KV internal supaya tombol munggah, lan uga node node internal kanthi urutan pertama, tegese simpul internal ndhisiki KV masing-masing lan kelenjar anake.
    ///
    ///
    pub fn visit_nodes_in_order<F>(self, mut visit: F)
    where
        F: FnMut(Position<marker::Immut<'a>, K, V>),
    {
        match self.force() {
            Leaf(leaf) => visit(Position::Leaf(leaf)),
            Internal(internal) => {
                visit(Position::Internal(internal));
                let mut edge = internal.first_edge();
                loop {
                    edge = match edge.descend().force() {
                        Leaf(leaf) => {
                            visit(Position::Leaf(leaf));
                            match edge.next_kv() {
                                Ok(kv) => {
                                    visit(Position::InternalKV(kv));
                                    kv.right_edge()
                                }
                                Err(_) => return,
                            }
                        }
                        Internal(internal) => {
                            visit(Position::Internal(internal));
                            internal.first_edge()
                        }
                    }
                }
            }
        }
    }

    /// Ngetung jumlah unsur ing wit (sub).
    pub fn calc_length(self) -> usize {
        let mut result = 0;
        self.visit_nodes_in_order(|pos| match pos {
            Position::Leaf(node) => result += node.len(),
            Position::Internal(node) => result += node.len(),
            Position::InternalKV(_) => (),
        });
        result
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>
{
    /// Ngasilake rwaning edge paling cedhak karo KV kanggo pandhu arah maju.
    pub fn next_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        match self.force() {
            Leaf(leaf_kv) => leaf_kv.right_edge(),
            Internal(internal_kv) => {
                let next_internal_edge = internal_kv.right_edge();
                next_internal_edge.descend().first_leaf_edge()
            }
        }
    }

    /// Ngasilake rwaning edge paling cedhak karo KV kanggo pandhu arah mundur.
    pub fn next_back_leaf_edge(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        match self.force() {
            Leaf(leaf_kv) => leaf_kv.left_edge(),
            Internal(internal_kv) => {
                let next_internal_edge = internal_kv.left_edge();
                next_internal_edge.descend().last_leaf_edge()
            }
        }
    }
}