//! Alokasi Prelude
//!
//! Tujuan modul iki kanggo nyuda impor barang sing umum digunakake ing `alloc` crate kanthi nambahake impor glob menyang ndhuwur modul:
//!
//!
//! ```
//! # #![allow(unused_imports)]
//! #![feature(alloc_prelude)]
//! extern crate alloc;
//! use alloc::prelude::v1::*;
//! ```

#![unstable(feature = "alloc_prelude", issue = "58935")]

pub mod v1;