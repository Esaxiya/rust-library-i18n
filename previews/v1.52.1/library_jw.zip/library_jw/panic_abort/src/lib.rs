//! Implementasi Rust panics liwat proses abort
//!
//! Yen dibandhingake karo implementasine liwat santai, crate iki *luwih* gampang!Yen wis dikandhani, iku ora bisa digunakake serbaguna, nanging saiki uga!
//!

#![no_std]
#![unstable(feature = "panic_abort", issue = "32837")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/"
)]
#![panic_runtime]
#![allow(unused_features)]
#![feature(core_intrinsics)]
#![feature(nll)]
#![feature(panic_runtime)]
#![feature(std_internals)]
#![feature(staged_api)]
#![feature(rustc_attrs)]
#![feature(asm)]

use core::any::Any;
use core::panic::BoxMeUp;

#[rustc_std_internal_symbol]
#[allow(improper_ctypes_definitions)]
pub unsafe extern "C" fn __rust_panic_cleanup(_: *mut u8) -> *mut (dyn Any + Send + 'static) {
    unreachable!()
}

// "Leak" muatan lan shim menyang aborsi sing relevan ing platform sing dimaksud.
#[rustc_std_internal_symbol]
pub unsafe extern "C" fn __rust_start_panic(_payload: *mut &mut dyn BoxMeUp) -> u32 {
    abort();

    cfg_if::cfg_if! {
        if #[cfg(unix)] {
            unsafe fn abort() -> ! {
                libc::abort();
            }
        } else if #[cfg(any(target_os = "hermit",
                            all(target_vendor = "fortanix", target_env = "sgx")
        ))] {
            unsafe fn abort() -> ! {
                // nelpon std::sys::abort_internal
                extern "C" {
                    pub fn __rust_abort() -> !;
                }
                __rust_abort();
            }
        } else if #[cfg(all(windows, not(miri)))] {
            // Ing Windows, gunakake mekanisme __fastfail khusus prosesor.Ing Windows 8 lan mengko, iki bakal mungkasi proses kasebut kanthi cepet tanpa nglakokake penanganan istiméwa ing proses.
            // Ing versi sadurungé saka Windows, urutan saka pandhuan bakal dianggep minangka nglanggar akses, terminating proses nanging tanpa kudu bypassing kabeh Penanganan istiméwa.
            //
            //
            // https://docs.microsoft.com/en-us/cpp/intrinsics/fastfail
            //
            // Note: iki implementasine padha karo libstd's `abort_internal`
            //
            //
            //
            unsafe fn abort() -> ! {
                const FAST_FAIL_FATAL_APP_EXIT: usize = 7;
                cfg_if::cfg_if! {
                    if #[cfg(any(target_arch = "x86", target_arch = "x86_64"))] {
                        asm!("int $$0x29", in("ecx") FAST_FAIL_FATAL_APP_EXIT);
                    } else if #[cfg(all(target_arch = "arm", target_feature = "thumb-mode"))] {
                        asm!(".inst 0xDEFB", in("r0") FAST_FAIL_FATAL_APP_EXIT);
                    } else if #[cfg(target_arch = "aarch64")] {
                        asm!("brk 0xF003", in("x0") FAST_FAIL_FATAL_APP_EXIT);
                    } else {
                        core::intrinsics::abort();
                    }
                }
                core::intrinsics::unreachable();
            }
        } else {
            unsafe fn abort() -> ! {
                core::intrinsics::abort();
            }
        }
    }
}

// Iki ... minangka sawijining keanehan.Tl; dr;yaiku yen diwajibake ngubungake kanthi bener, panjelasan sing luwih dawa ing ngisor iki.
//
// Sapunika ing lintang saka libcore/libstd kita kapal sing kabeh nyawiji karo `-C panic=unwind`.Iki wis rampung kanggo mesthekake yen lintang sing maximally kompatibel karo akeh kahanan sabisa.
// compiler, Nanging, mbutuhake "personality function" kanggo kabeh fungsi nyawiji karo `-C panic=unwind`.fungsi pribadine iki hardcoded kanggo simbol `rust_eh_personality` lan wis ditetepake dening item `eh_personality` lang.
//
// So...
// apa ora mung netepake sing item lang kene?Pitakon apik!Cara runtime panic disambungake, sejatine sithik banget amarga "sort of" ing toko crate kompilator, nanging mung disambung yen wong liya ora ana gandhengane.
//
// Iki tegese tegese crate lan panic_unwind crate bisa ditampilake ing toko crate, lan yen kalorone nemtokake item lang `eh_personality`, mula bakal ana kesalahan.
//
// Kanggo nangani iki compiler mung mbutuhake `eh_personality` wis ditetepake yen durasi panic kang disambung ing punika durasi unwinding, lan digunakake iku ora dibutuhake kanggo ditetepake (rightfully supaya).
// Nanging, ing kasus iki, perpustakaan iki mung nemtokake simbol iki saora-orane ana sawetara kepribadian ing endi wae.
//
// Intine simbol iki mung ditetepake kanggo entuk kabel nganti binar libcore/libstd, nanging ora kena diarani amarga kita ora nyambung ing wektu proses sing ora dikendhaleni.
//
//
//
//
//
//
//
//
//
//
//
//
pub mod personalities {
    #[rustc_std_internal_symbol]
    #[cfg(not(any(
        all(target_arch = "wasm32", not(target_os = "emscripten"),),
        all(target_os = "windows", target_env = "gnu", target_arch = "x86_64",),
    )))]
    pub extern "C" fn rust_eh_personality() {}

    // On x86_64-pc-windows-gnu digunakake fungsi kita pribadine dhewe sing kabutuhan kanggo bali `ExceptionContinueSearch` kita lagi maringaken ing kabeh pigura kita.
    //
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86_64"))]
    pub extern "C" fn rust_eh_personality(
        _record: usize,
        _frame: usize,
        _context: usize,
        _dispatcher: usize,
    ) -> u32 {
        1 // `ExceptionContinueSearch`
    }

    // Kaya ing ndhuwur, iki cocog karo item `eh_catch_typeinfo` lang sing saiki digunakake ing Emscripten.
    //
    // Wiwit panics ora generate seng lan seng manca saiki UB karo -C panic=Abort (senajan bisa uga tundhuk pangowahan), sembarang telpon catch_unwind ora bakal nggunakake typeinfo iki.
    //
    //
    //
    #[rustc_std_internal_symbol]
    #[allow(non_upper_case_globals)]
    #[cfg(target_os = "emscripten")]
    static rust_eh_catch_typeinfo: [usize; 2] = [0; 2];

    // loro iki disebut dening obyek wiwitan kita ing i686-pc-windows-gnu, nanging padha ora perlu kanggo nindakake tindakan supaya badan sing nops.
    //
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86"))]
    pub extern "C" fn rust_eh_register_frames() {}
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86"))]
    pub extern "C" fn rust_eh_unregister_frames() {}
}