use core::ffi::c_void;
use core::fmt;

/// Priksa tumpukan panggilan saiki, ngliwati kabeh bingkai aktif menyang penutupan sing kasedhiya kanggo ngetung tilak tumpukan.
///
/// Fungsi iki minangka workhorse perpustakaan iki kanggo ngitung tilas tumpukan kanggo program.closure `cb` diwenehi wis menehi kedadean saka `Frame` kang makili informasi bab sing pigura telpon ing tumpukan.
/// Panutupan ngasilake pigura kanthi mode top-down (sing paling anyar diarani fungsi luwih dhisik).
///
/// Nilai bali penutupan minangka indikasi manawa mundur bisa diterusake.Angka bali saka `false` bakal siksa backtrace lan bali langsung.
///
/// Sawise `Frame` dipikolehi sampeyan bisa uga pengin nelpon `backtrace::resolve` kanggo ngowahi `ip` (pituduh pitunjuk) utawa alamat simbol menyang `Symbol` sing bisa dingerteni jeneng lan/utawa jeneng filename/baris.
///
///
/// Elinga yen iki minangka fungsi level sing cukup murah lan yen sampeyan pengin, contone, njupuk backtrace kanggo dititi priksa mengko, mula jinis `Backtrace` bisa uga luwih cocog.
///
/// # Fitur sing dibutuhake
///
/// Fungsi iki mbutuhake fitur `std` saka `backtrace` crate supaya bisa aktif, lan fitur `std` diaktifake kanthi gawan.
///
/// # Panics
///
/// Fungsi iki ngupayakake ora nate panic, nanging yen `cb` nyedhiyakake panics, mula sawetara platform bakal meksa panic dobel kanggo ngilangi proses kasebut.
/// Sawetara platform nggunakake perpustakaan C sing nggunakake callback internal sing ora bisa dibukak, mula panicking saka `cb` bisa uga nyebabake proses aborsi.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         // ...
///
///         true // terusake backtrace
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn trace<F: FnMut(&Frame) -> bool>(cb: F) {
    let _guard = crate::lock::lock();
    unsafe { trace_unsynchronized(cb) }
}

/// Padha karo `trace`, mung ora aman amarga ora diselarasake.
///
/// Fungsi iki ora duwe jaminan sinkronisasi nanging kasedhiya yen fitur `std` crate iki ora dikompilasi.
/// Deleng fungsi `trace` kanggo dokumentasi lan conto liyane.
///
/// # Panics
///
/// Deleng informasi babagan `trace` kanggo tandha-tandha nalika panik `cb`.
///
pub unsafe fn trace_unsynchronized<F: FnMut(&Frame) -> bool>(mut cb: F) {
    trace_imp(&mut cb)
}

/// trait makili siji pigura latar mburi, ngasilake fungsi `trace` saka crate iki.
///
/// Penutupan fungsi nelusuri bakal diwenehi pigura, lan pigura meh dikirim amarga implementasine sing ndasari ora mesthi dingerteni nganti runtime.
///
///
///
#[derive(Clone)]
pub struct Frame {
    pub(crate) inner: FrameImp,
}

impl Frame {
    /// Ngasilake pandhuan saiki babagan pigura iki.
    ///
    /// Iki biasane minangka instruksi sabanjure kanggo nglakokake ing pigura, nanging ora kabeh implementasine nyathet iki kanthi akurasi 100% (nanging umume cukup cedhak).
    ///
    ///
    /// Disaranake ngirim angka iki menyang `backtrace::resolve` supaya bisa dadi jeneng simbol.
    ///
    ///
    pub fn ip(&self) -> *mut c_void {
        self.inner.ip()
    }

    /// Ngasilake penunjuk tumpukan saiki saka pigura iki.
    ///
    /// Yen backend ora bisa nemokake pointer tumpukan kanggo pigura iki, pointer nol bakal dikembalikan.
    ///
    pub fn sp(&self) -> *mut c_void {
        self.inner.sp()
    }

    /// Ngasilake alamat simbol wiwitan saka pigura fungsi iki.
    ///
    /// Iki bakal nyoba mundur pointer instruksi sing bali dening `ip` menyang wiwitan fungsi, ngasilake nilai kasebut.
    ///
    /// Nanging, ing sawetara kasus, backend mung ngasilake `ip` saka fungsi iki.
    ///
    /// Nilai bali bisa uga digunakake yen `backtrace::resolve` gagal ing `ip` sing kasebut ing ndhuwur.
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.inner.symbol_address()
    }

    /// Ngasilake alamat dhasar modul sing kalebu pigura.
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.inner.module_base_address()
    }
}

impl fmt::Debug for Frame {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Frame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

cfg_if::cfg_if! {
    // Iki kudu didhisiki, kanggo mesthekake manawa Miri dadi prioritas tinimbang platform host
    //
    if #[cfg(miri)] {
        pub(crate) mod miri;
        use self::miri::trace as trace_imp;
        pub(crate) use self::miri::Frame as FrameImp;
    } else if #[cfg(
        any(
            all(
                unix,
                not(target_os = "emscripten"),
                not(all(target_os = "ios", target_arch = "arm")),
            ),
            all(
                target_env = "sgx",
                target_vendor = "fortanix",
            ),
        )
    )] {
        mod libunwind;
        use self::libunwind::trace as trace_imp;
        pub(crate) use self::libunwind::Frame as FrameImp;
    } else if #[cfg(all(windows, not(target_vendor = "uwp")))] {
        mod dbghelp;
        use self::dbghelp::trace as trace_imp;
        pub(crate) use self::dbghelp::Frame as FrameImp;
        #[cfg(target_env = "msvc")] // mung digunakake ing simbol dbghelp
        pub(crate) use self::dbghelp::StackFrame;
    } else {
        mod noop;
        use self::noop::trace as trace_imp;
        pub(crate) use self::noop::Frame as FrameImp;
    }
}