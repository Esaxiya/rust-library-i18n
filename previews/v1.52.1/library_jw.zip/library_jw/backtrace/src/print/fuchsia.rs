use core::fmt::{self, Write};
use core::mem::{size_of, transmute};
use core::slice::from_raw_parts;
use libc::c_char;

extern "C" {
    // dl_iterate_phdr njupuk panggilan balik sing bakal nampa pointer dl_phdr_info kanggo saben DSO sing wis ana gandhengane karo proses kasebut.
    // dl_iterate_phdr uga njamin manawa linker dinamis dikunci saka wiwitan nganti rampung iterasi.
    // Yen callback ing ngasilake-nol Nilai pengulangan punika mungkasi awal.
    // 'data' bakal dilewati minangka argumen kaping telu kanggo telpon balik ing saben telpon.
    // 'size' menehi ukuran dl_phdr_info.
    //
    #[allow(improper_ctypes)]
    fn dl_iterate_phdr(
        f: extern "C" fn(info: &dl_phdr_info, size: usize, data: &mut DsoPrinter<'_, '_>) -> i32,
        data: &mut DsoPrinter<'_, '_>,
    ) -> i32;
}

// Kita kudu ngatasi ID build lan sawetara data header program dhasar sing tegese uga butuh sawetara barang saka spesifikasi ELF.
//

const PT_LOAD: u32 = 1;
const PT_NOTE: u32 = 4;

// Saiki kita kudu nurun, ngetrapake bit, struktur jinis dl_phdr_info sing digunakake dening linker dinamis fuchsia saiki.
// Chromium uga duwe wates ABI iki uga crashpad.
// Muga-muga kita pengin mindhah kasus kasebut kanggo nggunakake panelusur elf, nanging kita kudu menehi ing SDK lan durung rampung.
//
// Mangkono, kita (lan dheweke) macet kudu nggunakake metode iki sing nyebabake kopling sing ketat karo libur fuchsia.
//

#[allow(non_camel_case_types)]
#[repr(C)]
struct dl_phdr_info {
    addr: *const u8,
    name: *const c_char,
    phdr: *const Elf_Phdr,
    phnum: u16,
    adds: u64,
    subs: u64,
    tls_modid: usize,
    tls_data: *const u8,
}

impl dl_phdr_info {
    fn program_headers(&self) -> PhdrIter<'_> {
        PhdrIter {
            phdrs: self.phdr_slice(),
            base: self.addr,
        }
    }
    // Kita ora bisa ngerti manawa mriksa manawa e_phoff lan e_phnum bener.
    // libc kudu njamin iki kanggo kita, dadi luwih aman kanggo irisan ing kene.
    fn phdr_slice(&self) -> &[Elf_Phdr] {
        unsafe { from_raw_parts(self.phdr, self.phnum as usize) }
    }
}

struct PhdrIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: *const u8,
}

impl<'a> Iterator for PhdrIter<'a> {
    type Item = Phdr<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().map(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            Phdr {
                phdr,
                base: self.base,
            }
        })
    }
}

// Elf_Phdr nuduhake header program ELF 64-bit ing pungkasan arsitektur target.
//
#[allow(non_camel_case_types)]
#[derive(Clone, Debug)]
#[repr(C)]
struct Elf_Phdr {
    p_type: u32,
    p_flags: u32,
    p_offset: u64,
    p_vaddr: u64,
    p_paddr: u64,
    p_filesz: u64,
    p_memsz: u64,
    p_align: u64,
}

// Phdr nggambarake header program ELF sing valid lan isine.
struct Phdr<'a> {
    phdr: &'a Elf_Phdr,
    base: *const u8,
}

impl<'a> Phdr<'a> {
    // Kita ora bisa mriksa apa p_addr utawa p_memsz bener.
    // libc Fuchsia kang parses cathetan pisanan Nanging supaya dening kabecikan saka kang kene header iki kudu bener.
    //
    // NoteIter ora mbutuhake data sing ndasari dadi valid nanging mbutuhake wates sing bener.
    // Kita percaya yen libc wis njamin manawa iki kedadeyan ing kene.
    fn notes(&self) -> NoteIter<'a> {
        unsafe {
            NoteIter::new(
                self.base.add(self.phdr.p_offset as usize),
                self.phdr.p_memsz as usize,
            )
        }
    }
}

// Jinis cathetan kanggo ID pambangun.
const NT_GNU_BUILD_ID: u32 = 3;

// Elf_Nhdr nuduhake header cathetan ELF ing pungkasan target.
#[allow(non_camel_case_types)]
#[repr(C)]
struct Elf_Nhdr {
    n_namesz: u32,
    n_descsz: u32,
    n_type: u32,
}

// Cathetan nggambarake cathetan ELF (header + isi).
// Jeneng iki kiwa minangka irisan u8 amarga iku ora tansah null mungkasi lan rust ndadekake cukup gampang kanggo mriksa yen bita cocog eitherway.
//
struct Note<'a> {
    name: &'a [u8],
    desc: &'a [u8],
    tipe: u32,
}

// NoteIter ngidini sampeyan kanthi aman liwat segmen cathetan.
// Bakal mandheg sanalika ana kesalahan utawa ora ana cathetan maneh.
// Yen sampeyan ngulang data sing ora valid, bakal bisa digunakake kaya ora ana cathetan sing ditemokake.
struct NoteIter<'a> {
    base: &'a [u8],
    error: bool,
}

impl<'a> NoteIter<'a> {
    // Minangka invariant saka fungsi sing pitunjuk lan ukuran sing diwenehake nuduhake sawetara bait sing valid sing bisa diwaca kabeh.
    // Isi bita iki bisa dadi apa-apa nanging sawetara kudu bener iki dadi aman.
    //
    unsafe fn new(base: *const u8, size: usize) -> Self {
        NoteIter {
            base: from_raw_parts(base, size),
            error: false,
        }
    }
}

// align_to aligns 'x' kanggo 'to'-bait Alignment assuming 'to' punika daya saka 2.
// Iki kalebu pola standar ing kode parsing C/C ++ ELF ing endi (x + nganti, 1)&-to digunakake.
// Rust ora supaya negate usize supaya nganggo
// Konversi 2-pelengkap kanggo nggawe maneh.
fn align_to(x: usize, to: usize) -> usize {
    (x + to - 1) & (!to + 1)
}

// take_bytes_align4 nganggo num bita saka irisan (yen saiki) lan tambahan njamin yen irisan final wis properlly didadekake siji.
// Yen jumlah bait sing dijaluk gedhe banget utawa irisan kasebut ora bisa diselehake mengko amarga ora cukup sisa bait, Ora ana sing bakal bali lan irisan kasebut ora dimodifikasi.
//
//
//
fn take_bytes_align4<'a>(num: usize, bytes: &mut &'a [u8]) -> Option<&'a [u8]> {
    if bytes.len() < align_to(num, 4) {
        return None;
    }
    let (out, bytes_new) = bytes.split_at(num);
    *bytes = &bytes_new[align_to(num, 4) - num..];
    Some(out)
}

// Fungsi iki ora duwe invariant nyata panelpon kudu dijaluk liyane kajaba yen 'bytes' kudu didadekake siji kanggo kinerja (lan sawetara arsitektur sing bener).
// Nilai ing kolom Elf_Nhdr bisa uga omong kosong nanging fungsi iki ora njamin apa-apa.
//
//
fn take_nhdr<'a>(bytes: &mut &'a [u8]) -> Option<&'a Elf_Nhdr> {
    if size_of::<Elf_Nhdr>() > bytes.len() {
        return None;
    }
    // Iki aman yen ana cukup ruangan lan kita mung negesake manawa ing pratelan kasebut ing ndhuwur mula iki bakal aman.
    //
    let out = unsafe { transmute::<*const u8, &'a Elf_Nhdr>(bytes.as_ptr()) };
    // Elinga yen sice_of: :<Elf_Nhdr>() selaras karo 4-byte.
    *bytes = &bytes[size_of::<Elf_Nhdr>()..];
    Some(out)
}

impl<'a> Iterator for NoteIter<'a> {
    type Item = Note<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        // Priksa manawa kita wis tekan pungkasan.
        if self.base.len() == 0 || self.error {
            return None;
        }
        // Kita nularake nhdr, nanging kita kudu nimbang strukture sing diasilake.
        // Aku ora dipercaya namesz utawa descsz lan kita wis ora pancasan aman adhedhasar jinis.
        //
        // Dadi, yen entuk sampah lengkap, kita isih kudu aman.
        let nhdr = take_nhdr(&mut self.base)?;
        let name = take_bytes_align4(nhdr.n_namesz as usize, &mut self.base)?;
        let desc = take_bytes_align4(nhdr.n_descsz as usize, &mut self.base)?;
        Some(Note {
            name: name,
            desc: desc,
            tipe: nhdr.n_type,
        })
    }
}

struct Perm(u32);

/// Nuduhake yen segmen bisa dieksekusi.
const PERM_X: u32 = 0b00000001;
/// Nuduhake yen segmen bisa ditulis.
const PERM_W: u32 = 0b00000010;
/// Nuduhake yen segmen bisa diwaca.
const PERM_R: u32 = 0b00000100;

impl core::fmt::Display for Perm {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let v = self.0;
        if v & PERM_R != 0 {
            f.write_char('r')?
        }
        if v & PERM_W != 0 {
            f.write_char('w')?
        }
        if v & PERM_X != 0 {
            f.write_char('x')?
        }
        Ok(())
    }
}

/// Makili segmen ELF nalika runtime.
struct Segment {
    /// Menehi alamat virtual runtime saka konten babagan iki.
    addr: usize,
    /// Menehi ukuran memori isi segmen iki.
    size: usize,
    /// Menehi alamat virtual modul babagan iki nganggo file ELF.
    mod_rel_addr: usize,
    /// Menehi ijin sing ditemokake ing file ELF.
    /// Idin kasebut ora mesthi diidinan saiki.
    flags: Perm,
}

/// Ngijini siji pengulangan babagan Segmen saka DSO.
struct SegmentIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: usize,
}

impl Iterator for SegmentIter<'_> {
    type Item = Segment;

    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().and_then(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            if phdr.p_type != PT_LOAD {
                self.next()
            } else {
                Some(Segment {
                    addr: phdr.p_vaddr as usize + self.base,
                    size: phdr.p_memsz as usize,
                    mod_rel_addr: phdr.p_vaddr as usize,
                    flags: Perm(phdr.p_flags),
                })
            }
        })
    }
}

/// Makili DSF ELF (Objek sing Dituduhake Dinamis).
/// Jinis iki referensi data sing disimpen ing DSO nyata tinimbang nggawe salinan dhewe.
struct Dso<'a> {
    /// Linker dinamis mesthi menehi jeneng, sanajan jenenge kosong.
    /// Ing kasus eksekusi utama jeneng iki bakal kosong.
    /// Ing obyek yen dienggo bareng bakal dadi soname (waca DT_SONAME).
    name: &'a str,
    /// Ing Fuchsia, meh kabeh binar duwe ID sing dibangun, nanging iki dudu panjaluk sing ketat.
    /// Boten wonten cara kanggo cocog informasi DSO karo file FPE nyata sesampunipun yen ana build_id supaya kita mbutuhake sing saben DSO duwe siji kene.
    ///
    /// DSO kang tanpa build_id a digatèkaké.
    build_id: &'a [u8],

    base: usize,
    phdrs: &'a [Elf_Phdr],
}

impl Dso<'_> {
    /// Ngasilake pengulangan babagan Segmen ing DSO iki.
    fn segments(&self) -> SegmentIter<'_> {
        SegmentIter {
            phdrs: self.phdrs.as_ref(),
            base: self.base,
        }
    }
}

struct HexSlice<'a> {
    bytes: &'a [u8],
}

impl fmt::Display for HexSlice<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        for byte in self.bytes {
            write!(f, "{:02x}", byte)?;
        }
        Ok(())
    }
}

fn get_build_id<'a>(info: &'a dl_phdr_info) -> Option<&'a [u8]> {
    for phdr in info.program_headers() {
        if phdr.phdr.p_type == PT_NOTE {
            for note in phdr.notes() {
                if note.tipe == NT_GNU_BUILD_ID && (note.name == b"GNU\0" || note.name == b"GNU") {
                    return Some(note.desc);
                }
            }
        }
    }
    None
}

/// Kesalahan iki ngode masalah sing muncul nalika ngurai informasi babagan saben DSO.
///
enum Error {
    /// NameError tegese ana kesalahan nalika ngowahi senar gaya C dadi senar rust.
    ///
    NameError(core::str::Utf8Error),
    /// BuildIDError tegese ora nemokake ID build.
    /// Iki bisa uga amarga DSO ora duwe ID pambangun utawa amarga segmen sing ngemot ID pambuat salah.
    ///
    BuildIDError,
}

/// Telpon salah siji 'dso' utawa 'error' kanggo saben DSO disambung menyang proses dening Linker dinamis.
///
///
/// # Arguments
///
/// * `visitor` - DsoPrinter sing bakal duwe salah siji cara mangan sing diarani ngarep DSO.
fn for_each_dso(mut visitor: &mut DsoPrinter<'_, '_>) {
    extern "C" fn callback(
        info: &dl_phdr_info,
        _size: usize,
        visitor: &mut DsoPrinter<'_, '_>,
    ) -> i32 {
        // dl_iterate_phdr njamin yen info.name bakal nuduhake lokasi sing bener.
        //
        let name_len = unsafe { libc::strlen(info.name) };
        let name_slice: &[u8] =
            unsafe { core::slice::from_raw_parts(info.name as *const u8, name_len) };
        let name = match core::str::from_utf8(name_slice) {
            Ok(name) => name,
            Err(err) => {
                return visitor.error(Error::NameError(err)) as i32;
            }
        };
        let build_id = match get_build_id(info) {
            Some(build_id) => build_id,
            None => {
                return visitor.error(Error::BuildIDError) as i32;
            }
        };
        visitor.dso(Dso {
            name: name,
            build_id: build_id,
            phdrs: info.phdr_slice(),
            base: info.addr as usize,
        }) as i32
    }
    unsafe { dl_iterate_phdr(callback, &mut visitor) };
}

struct DsoPrinter<'a, 'b> {
    writer: &'a mut core::fmt::Formatter<'b>,
    module_count: usize,
    error: core::fmt::Result,
}

impl DsoPrinter<'_, '_> {
    fn dso(&mut self, dso: Dso<'_>) -> bool {
        let mut write = || {
            write!(
                self.writer,
                "{{{{{{module:{:#x}:{}:elf:{}}}}}}}\n",
                self.module_count,
                dso.name,
                HexSlice {
                    bytes: dso.build_id.as_ref()
                }
            )?;
            for seg in dso.segments() {
                write!(
                    self.writer,
                    "{{{{{{mmap:{:#x}:{:#x}:load:{:#x}:{}:{:#x}}}}}}}\n",
                    seg.addr, seg.size, self.module_count, seg.flags, seg.mod_rel_addr
                )?;
            }
            self.module_count += 1;
            Ok(())
        };
        match write() {
            Ok(()) => false,
            Err(err) => {
                self.error = Err(err);
                true
            }
        }
    }
    fn error(&mut self, _error: Error) -> bool {
        false
    }
}

/// Fungsi iki nyithak markup simbol Fuchsia kanggo kabeh informasi sing ana ing DSO.
pub fn print_dso_context(out: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
    out.write_str("{{{reset}}}\n")?;
    let mut visitor = DsoPrinter {
        writer: out,
        module_count: 0,
        error: Ok(()),
    };
    for_each_dso(&mut visitor);
    visitor.error
}