//! Modul kanggo mbantu ngatur ikatan dbghelp ing Windows
//!
//! Backtraces ing Windows (paling ora kanggo MSVC) umume digunakake liwat `dbghelp.dll` lan macem-macem fungsi sing dikandung.
//! Fungsi kasebut saiki dimuat *kanthi dinamis* tinimbang ngubungake menyang `dbghelp.dll` kanthi statis.
//! Saiki ditindakake perpustakaan standar (lan miturut teori dibutuhake), nanging minangka upaya kanggo nyuda katergantungan dll statis perpustakaan amarga backtraces biasane opsional.
//!
//! Yen wis dikandhani, `dbghelp.dll` meh mesthi sukses mbukak Windows.
//!
//! Elinga, amarga kita ngemot kabeh dhukungan iki kanthi dinamis, kita ora bisa nggunakake definisi mentah ing `winapi`, nanging luwih becik kita kudu nemtokake jinis pointer fungsi banjur nggunakake.
//! Kita ora pengin banget nggawe duplikat winapi, mula kita duwe fitur Cargo `verify-winapi` sing negesake manawa kabeh ikatan cocog karo winapi lan fitur iki diaktifake ing CI.
//!
//! Pungkasan, sampeyan bakal nyathet ing kene manawa dll kanggo `dbghelp.dll` ora tau dibongkar, lan saiki disengaja.
//! pikiran iku kita global bisa ngakses lan nggunakake antarane telpon kanggo API, Nyingkiri larang loads/unloads.
//! Yen masalah kanggo detektor bocor utawa kaya ngono, kita bisa nyebrang jembatan nalika tekan kana.
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(non_snake_case)]

use super::windows::*;
use core::mem;
use core::ptr;

// Bisa ngubengi `SymGetOptions` lan `SymSetOptions` ora ana ing winapi dhewe.
// Yen iki mung dianggo yen lagi jinis pindho mriksa marang winapi.
//
#[cfg(feature = "verify-winapi")]
mod dbghelp {
    use crate::windows::*;
    pub use winapi::um::dbghelp::{
        StackWalk64, SymCleanup, SymFromAddrW, SymFunctionTableAccess64, SymGetLineFromAddrW64,
        SymGetModuleBase64, SymInitializeW,
    };

    extern "system" {
        // Ora ditetepake ing winapi
        pub fn SymGetOptions() -> u32;
        pub fn SymSetOptions(_: u32);

        // Iki ditemtokake ing winapi, nanging ora bener (FIXME winapi-rs#768)
        pub fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD,
        ) -> BOOL;

        // Ora ditetepake ing winapi
        pub fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW,
        ) -> BOOL;
        pub fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64,
        ) -> BOOL;
    }

    pub fn assert_equal_types<T>(a: T, _b: T) -> T {
        a
    }
}

// Makro iki digunakake kanggo netepake struktur `Dbghelp` sing ngemot internal kabeh pituduh fungsi sing bisa dimuat ing njero.
//
macro_rules! dbghelp {
    (extern "system" {
        $(fn $name:ident($($arg:ident: $argty:ty),*) -> $ret: ty;)*
    }) => (
        pub struct Dbghelp {
            /// DLL sing dimuat kanggo `dbghelp.dll`
            dll: HMODULE,

            // Saben fungsi pointer kanggo saben fungsi sing bisa digunakake
            $($name: usize,)*
        }

        static mut DBGHELP: Dbghelp = Dbghelp {
            // Wiwitane, kita durung ngemot DLL
            dll: 0 as *mut _,
            // Initiall kabeh fungsi sing disetel menyang nul ngomong padha kudu mbosenke dimuat.
            //
            $($name: 0,)*
        };

        // Typedef penak kanggo saben jinis fungsi.
        $(pub type $name = unsafe extern "system" fn($($argty),*) -> $ret;)*

        impl Dbghelp {
            /// Upaya mbukak `dbghelp.dll`.
            /// Ngasilake sukses yen bisa digunakake utawa kesalahan yen `LoadLibraryW` gagal.
            ///
            /// Panics yen perpustakaan wis dimuat.
            fn ensure_open(&mut self) -> Result<(), ()> {
                if !self.dll.is_null() {
                    return Ok(())
                }
                let lib = b"dbghelp.dll\0";
                unsafe {
                    self.dll = LoadLibraryA(lib.as_ptr() as *const i8);
                    if self.dll.is_null() {
                        Err(())
                    }  else {
                        Ok(())
                    }
                }
            }

            // Fungsi kanggo saben cara sing pengin digunakake.
            // Yen diarani, bisa uga maca petunjuk fungsi cache utawa mbukak lan ngasilake angka sing dimuat.
            // Beban dikonfirmasi sukses.
            $(pub fn $name(&mut self) -> Option<$name> {
                unsafe {
                    if self.$name == 0 {
                        let name = concat!(stringify!($name), "\0");
                        self.$name = self.symbol(name.as_bytes())?;
                    }
                    let ret = mem::transmute::<usize, $name>(self.$name);
                    #[cfg(feature = "verify-winapi")]
                    dbghelp::assert_equal_types(ret, dbghelp::$name);
                    Some(ret)
                }
            })*

            fn symbol(&self, symbol: &[u8]) -> Option<usize> {
                unsafe {
                    match GetProcAddress(self.dll, symbol.as_ptr() as *const _) as usize {
                        0 => None,
                        n => Some(n),
                    }
                }
            }
        }

        // Proksi penake nggunakake kunci pembersih kanggo ngrujuk fungsi dbghelp.
        //
        #[allow(dead_code)]
        impl Init {
            $(pub fn $name(&self) -> $name {
                unsafe {
                    DBGHELP.$name().unwrap()
                }
            })*

            pub fn dbghelp(&self) -> *mut Dbghelp {
                unsafe {
                    &mut DBGHELP
                }
            }
        }
    )

}

const SYMOPT_DEFERRED_LOADS: DWORD = 0x00000004;

dbghelp! {
    extern "system" {
        fn SymGetOptions() -> DWORD;
        fn SymSetOptions(options: DWORD) -> ();
        fn SymInitializeW(
            handle: HANDLE,
            path: PCWSTR,
            invade: BOOL
        ) -> BOOL;
        fn SymCleanup(handle: HANDLE) -> BOOL;
        fn StackWalk64(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME64,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64
        ) -> BOOL;
        fn SymFunctionTableAccess64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> PVOID;
        fn SymGetModuleBase64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> DWORD64;
        fn SymFromAddrW(
            hProcess: HANDLE,
            Address: DWORD64,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromAddrW64(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
        fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD
        ) -> BOOL;
        fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
    }
}

pub struct Init {
    lock: HANDLE,
}

/// Initialisasi kabeh dhukungan sing dibutuhake kanggo ngakses fungsi API `dbghelp` saka crate iki.
///
///
/// Elinga yen fungsi iki **aman**, internal duwe sinkronisasi dhewe.
/// Uga elinga yen aman kanggo nelpon fungsi iki kaping pirang-pirang kanthi rekursif.
///
pub fn init() -> Result<Init, ()> {
    use core::sync::atomic::{AtomicUsize, Ordering::SeqCst};

    unsafe {
        // Pisanan sing kudu kita lakoni yaiku nyinkronake fungsi iki.Iki bisa diarani bebarengan saka utas liyane utawa rekursif ing sak utas.
        // Elinga yen luwih angel tinimbang, amarga sing digunakake ing kene, `dbghelp`,*uga* kudu disinkronake karo kabeh panelpon liyane menyang `dbghelp` ing proses iki.
        //
        // Biasane, ora ana akeh telpon menyang `dbghelp` sajrone proses sing padha lan bisa uga nganggep aman yen mung kita sing ngakses.
        // Nanging, ana siji pangguna utama liyane sing kudu kuwatir yaiku ironis awake dhewe, nanging ing perpustakaan standar.
        // Pustaka standar Rust gumantung ing crate iki kanggo dhukungan backtrace, lan crate iki uga ana ing crates.io.
        // Iki tegese yen perpustakaan standar nyithak latar mburi panic, bisa uga balapan kanthi crate iki asale saka crates.io, nyebabake segfault.
        //
        // Kanggo ngatasi masalah sinkronisasi iki, kita nggunakake trik khusus Windows ing kene (sawise kabeh, watesan khusus Windows babagan sinkronisasi).
        // Kita nggawe *session-local* sing jenenge mutex kanggo nglindhungi telpon iki.
        // Tujuane ing kene yaiku perpustakaan standar lan crate iki ora prelu nuduhake API level Rust kanggo nyinkronake ing kene, nanging bisa uga kerja ing mburi layar kanggo nggawe manawa padha sinkronisasi.
        //
        // cara sing yen fungsi iki diarani liwat perpustakaan standar utawa liwat crates.io kita bisa manawa mutex padha lagi angsal.
        //
        // Dadi, kabeh mau tegese sing pertama sing kita lakoni ing kene yaiku kanthi atom nggawe `HANDLE` sing diarani mutex ing Windows.
        // Kita nyelarasake sithik karo utas liyane sing nuduhake fungsi iki khusus lan mesthekake yen mung siji gagang sing digawe saben conto fungsi iki.
        // Elinga yen gagang kasebut ora nate ditutup yen disimpen ing global.
        //
        // Sawise ngunci, kita bakal entuk, lan gagang `Init` sing bakal diwenehake mengko bakal ngeculake.
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        static LOCK: AtomicUsize = AtomicUsize::new(0);
        let mut lock = LOCK.load(SeqCst);
        if lock == 0 {
            lock = CreateMutexA(
                ptr::null_mut(),
                0,
                "Local\\RustBacktraceMutex\0".as_ptr() as _,
            ) as usize;
            if lock == 0 {
                return Err(());
            }
            if let Err(other) = LOCK.compare_exchange(0, lock, SeqCst, SeqCst) {
                debug_assert!(other != 0);
                CloseHandle(lock as HANDLE);
                lock = other;
            }
        }
        debug_assert!(lock != 0);
        let lock = lock as HANDLE;
        let r = WaitForSingleObjectEx(lock, INFINITE, FALSE);
        debug_assert_eq!(r, 0);
        let ret = Init { lock };

        // Ok, piye!Saiki kabeh wis disinkronake kanthi aman, ayo miwiti proses kabeh.
        // Kaping pisanan, kita kudu mesthekake yen `dbghelp.dll` bener-bener dimuat ing proses iki.
        // Kita nindakake kanthi dinamis kanggo nyegah katergantungan statis.
        // Iki wis ditindakake kanthi historis kanggo ngrampungake masalah ngubungake sing aneh lan dimaksudake supaya binar luwih portabel amarga umume mung sarana debugging.
        //
        //
        // Sawise mbukak `dbghelp.dll`, kita kudu nelpon sawetara fungsi inisialisasi, lan luwih rinci ing ngisor iki.
        // Nanging kita mung nindakake sepisan iki, mula duwe boolean global sing nuduhake manawa kita wis rampung utawa durung.
        //
        //
        //
        //
        DBGHELP.ensure_open()?;

        static mut INITIALIZED: bool = false;
        if INITIALIZED {
            return Ok(ret);
        }

        let orig = DBGHELP.SymGetOptions().unwrap()();

        // Priksa manawa gendera `SYMOPT_DEFERRED_LOADS` wis disetel, amarga miturut dokumen MSVC dhewe babagan iki: "This is the fastest, most efficient way to use the symbol handler.", mula ayo ngono!
        //
        //
        DBGHELP.SymSetOptions().unwrap()(orig | SYMOPT_DEFERRED_LOADS);

        // Sejatine nginisialisasi simbol karo MSVC.Elinga yen iki bisa gagal, nanging kita ora nggatekake.
        // Ana ora ton seni sadurunge iki saben se, nanging LLVM jek njero nglirwakake Nilai bali kene lan salah siji saka perpustakaan bahan sanitasi ing LLVM prints bebaya medeni yen iki gagal nanging Sejatine mratelakake ing roto dawa.
        //
        //
        // Siji kasus iki asring ditemokake kanggo Rust yaiku perpustakaan standar lan crate ing crates.io loro-lorone pengin saingan karo `SymInitializeW`.
        // Pustaka standar kanthi historis pengin nggawe inisialisasi mula biasane, nanging saiki nggunakake crate iki tegese ana sing bakal miwiti dhisikan lan liyane bakal njupuk inisialisasi kasebut.
        //
        //
        //
        //
        //
        //
        DBGHELP.SymInitializeW().unwrap()(GetCurrentProcess(), ptr::null_mut(), TRUE);
        INITIALIZED = true;
        Ok(ret)
    }
}

impl Drop for Init {
    fn drop(&mut self) {
        unsafe {
            let r = ReleaseMutex(self.lock);
            debug_assert!(r != 0);
        }
    }
}