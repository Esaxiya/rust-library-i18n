//! Strategi simbolisasi nggunakake kode parsing DWARF ing libbacktrace.
//!
//! The libbacktrace C perpustakaan, biasane mbagekke karo gcc, ndhukung ora mung ngasilaken backtrace (kang ora kita bener nggunakake) nanging uga symbolicating backtrace lan nangani Alexa debug dwarf bab kaya pigura inlined lan whatnot.
//!
//!
//! Iki relatif rumit amarga persil saka macem-macem uneg-uneg kene, nanging gagasan dhasar iki:
//!
//! * Pisanan kita nelpon `backtrace_syminfo`.Iki entuk informasi simbol saka tabel simbol dinamis yen bisa.
//! * Sabanjure kita nelpon `backtrace_pcinfo`.Iki bakal ngrampungake tabel debuginfo yen kasedhiya lan ngidini kita nemokake informasi babagan pigura inline, jeneng file, nomer baris, lsp.
//!
//! Ana akeh trik babagan nggawe tabel dwarf dadi latar mburi, nanging muga-muga dudu pungkasane donya lan cukup jelas nalika maca ing ngisor iki.
//!
//! Iki minangka strategi simbolisasi standar kanggo platform non-MSVC lan non-OSX.Ing libstd sanadyan iki strategi gawan kanggo OSX.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(bad_style)]

extern crate backtrace_sys as bt;

use core::{marker, ptr, slice};
use libc::{self, c_char, c_int, c_void, uintptr_t};

use crate::symbolize::{ResolveWhat, SymbolName};
use crate::types::BytesOrWideString;

pub enum Symbol<'a> {
    Syminfo {
        pc: uintptr_t,
        symname: *const c_char,
        _marker: marker::PhantomData<&'a ()>,
    },
    Pcinfo {
        pc: uintptr_t,
        filename: *const c_char,
        lineno: c_int,
        function: *const c_char,
        symname: *const c_char,
    },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        let symbol = |ptr: *const c_char| unsafe {
            if ptr.is_null() {
                None
            } else {
                let len = libc::strlen(ptr);
                Some(SymbolName::new(slice::from_raw_parts(
                    ptr as *const u8,
                    len,
                )))
            }
        };
        match *self {
            Symbol::Syminfo { symname, .. } => symbol(symname),
            Symbol::Pcinfo {
                function, symname, ..
            } => {
                // Yen bisa, luwih milih jeneng `function` sing asale saka debuginfo lan biasane luwih akurat kanggo pigura inline, kayata.
                // Yen ora ana, bali menyang jeneng tabel simbol sing ditemtokake ing `symname`.
                //
                // Elinga yen kadang `function` rumangsa kurang akurat, contone didhaptar minangka `try<i32,closure>` isntead saka `std::panicking::try::do_call`.
                //
                // Ora jelas kenapa, nanging umume jeneng `function` kayane luwih akurat.
                //
                //
                //
                if let Some(sym) = symbol(function) {
                    return Some(sym);
                }
                symbol(symname)
            }
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        let pc = match *self {
            Symbol::Syminfo { pc, .. } => pc,
            Symbol::Pcinfo { pc, .. } => pc,
        };
        if pc == 0 {
            None
        } else {
            Some(pc as *mut _)
        }
    }

    fn filename_bytes(&self) -> Option<&[u8]> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { filename, .. } => {
                let ptr = filename as *const u8;
                if ptr.is_null() {
                    return None;
                }
                unsafe {
                    let len = libc::strlen(filename);
                    Some(slice::from_raw_parts(ptr, len))
                }
            }
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.filename_bytes().map(BytesOrWideString::Bytes)
    }

    #[cfg(feature = "std")]
    pub fn filename(&self) -> Option<&::std::path::Path> {
        use std::path::Path;

        #[cfg(unix)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::ffi::OsStr;
            use std::os::unix::prelude::*;
            Some(Path::new(OsStr::from_bytes(bytes)))
        }

        #[cfg(windows)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::str;
            str::from_utf8(bytes).ok().map(Path::new)
        }

        self.filename_bytes().and_then(bytes2path)
    }

    pub fn lineno(&self) -> Option<u32> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { lineno, .. } => Some(lineno as u32),
        }
    }

    pub fn colno(&self) -> Option<u32> {
        None
    }
}

extern "C" fn error_cb(_data: *mut c_void, _msg: *const c_char, _errnum: c_int) {
    // aja nindakake apa-apa saiki
}

/// Jinis pointer `data` liwati menyang `syminfo_cb`
struct SyminfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    pc: usize,
}

extern "C" fn syminfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    symname: *const c_char,
    _symval: uintptr_t,
    _symsize: uintptr_t,
) {
    let mut bomb = crate::Bomb { enabled: true };

    // Sawise panelpon balik iki dijaluk saka `backtrace_syminfo` nalika miwiti ngrampungake, mula luwih becik nelpon `backtrace_pcinfo`.
    // Fungsi `backtrace_pcinfo` bakal takon informasi debug lan nyoba nindakake perkara kaya mulihake informasi file/line uga pigura inline.
    // Wigati sanadyan sing `backtrace_pcinfo` bisa gagal utawa ora nindakake akeh yen ana ora info debug, supaya yen sing mengkono kita lagi manawa kanggo nelpon callback ing paling siji simbol saka `syminfo_cb`.
    //
    //
    //
    //
    unsafe {
        let syminfo_state = &mut *(data as *mut SyminfoState<'_>);
        let mut pcinfo_state = PcinfoState {
            symname,
            called: false,
            cb: syminfo_state.cb,
        };
        bt::backtrace_pcinfo(
            init_state(),
            syminfo_state.pc as uintptr_t,
            pcinfo_cb,
            error_cb,
            &mut pcinfo_state as *mut _ as *mut _,
        );
        if !pcinfo_state.called {
            (pcinfo_state.cb)(&super::Symbol {
                inner: Symbol::Syminfo {
                    pc: pc,
                    symname: symname,
                    _marker: marker::PhantomData,
                },
            });
        }
    }

    bomb.enabled = false;
}

/// Jinis pointer `data` liwati menyang `pcinfo_cb`
struct PcinfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    symname: *const c_char,
    called: bool,
}

extern "C" fn pcinfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    filename: *const c_char,
    lineno: c_int,
    function: *const c_char,
) -> c_int {
    let mut bomb = crate::Bomb { enabled: true };

    unsafe {
        let state = &mut *(data as *mut PcinfoState<'_>);
        state.called = true;
        (state.cb)(&super::Symbol {
            inner: Symbol::Pcinfo {
                pc: pc,
                filename: filename,
                lineno: lineno,
                symname: state.symname,
                function,
            },
        });
    }

    bomb.enabled = false;
    return 0;
}

// The ndhukung libbacktrace API nggawe negara, nanging ora ndhukung ngancurake negara.
// Aku dhewe nganggep iki tegese negara kudu digawe banjur urip selawase.
//
// Aku seneng ndhaptar pawang at_exit() sing ngresiki negara iki, nanging libbacktrace ora ana cara kanggo nglakoni.
//
// Kanthi alangan kasebut, fungsi iki nduwe status cache statis sing diwilang kaping pisanan dijaluk.
//
// Elinga yen backtracing kabeh mengkono serially (siji kunci global).
//
// Elinga yen ora ana sinkronisasi ing kene amarga ana syarat yen `resolve` disinkronake kanthi eksternal.
//
//
//
unsafe fn init_state() -> *mut bt::backtrace_state {
    static mut STATE: *mut bt::backtrace_state = 0 as *mut _;

    if !STATE.is_null() {
        return STATE;
    }

    STATE = bt::backtrace_create_state(
        load_filename(),
        // Ora ngleksanani threadsafe kabisan libbacktrace awit kita lagi tansah nelpon iku ing fashion diselarasake.
        //
        0,
        error_cb,
        ptr::null_mut(), // ora ana data ekstra
    );

    return STATE;

    // Elinga, yen libbacktrace bisa digunakake kabeh kudu nemokake info debug DWARF sing bisa dieksekusi saiki.Biasane ditindakake liwat pirang-pirang mekanisme, kalebu, nanging ora winates kanggo:
    //
    // * /proc/self/exe ing platform sing didhukung
    // * Jeneng jeneng kasebut dilaporake kanthi eksplisit nalika nggawe negara
    //
    // Perpustakaan libbacktrace punika wad amba saka kode C.Iki tegese duwe kerentanan keamanan memori, luwih-luwih nalika nangani debuginfo sing salah.
    // Libstd wis nemoni sejarah kasebut.
    //
    // Yen /proc/self/exe digunakake, kita biasane bisa nglirwakake iki amarga nganggep libbacktrace yaiku "mostly correct" lan ora nindakake perkara sing aneh karo info debug "attempted to be correct" kerdil.
    //
    //
    // Yen kita ngirim jeneng filename, mula bisa wae ing sawetara platform (kaya BSD) ing endi aktor jahat bisa nyebabake file sewenang-wenang dilebokake ing lokasi kasebut.
    // Tegese yen kita marang libbacktrace babagan filename iku uga nggunakake file kasepakatan, bisa nyebabake segfaults.
    // Yen ora ngandhani libbacktrace, mula ora bakal nindakake apa-apa ing platform sing ora ndhukung dalan kaya /proc/self/exe!
    //
    // Amarga kabeh upaya sing kita coba supaya *ora* dilebokake ing jeneng filen, nanging kita kudu ing platform sing ora ndhukung /proc/self/exe.
    //
    //
    //
    //
    //
    //
    //
    //
    cfg_if::cfg_if! {
        if #[cfg(any(target_os = "macos", target_os = "ios"))] {
            // Elinga yen saenipun kita ngene nggunakake `std::env::current_exe`, nanging kita ora bisa mbutuhake `std` kene.
            //
            // Gunakake `_NSGetExecutablePath` kanggo mbukak dalan sing bisa dieksekusi saiki menyang area statis (sing yen cilik banget, banjur nyerah).
            //
            //
            // Elinga yen kita wis akeh dipercaya libbacktrace ing kene supaya ora mati ing eksekusi korup, nanging mesthine ...
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                const N: usize = 256;
                static mut BUF: [u8; N] = [0; N];
                extern {
                    fn _NSGetExecutablePath(
                        buf: *mut libc::c_char,
                        bufsize: *mut u32,
                    ) -> libc::c_int;
                }
                let mut sz: u32 = BUF.len() as u32;
                let ptr = BUF.as_mut_ptr() as *mut libc::c_char;
                if _NSGetExecutablePath(ptr, &mut sz) == 0 {
                    ptr
                } else {
                    ptr::null()
                }
            }
        } else if #[cfg(windows)] {
            use crate::windows::*;

            // Windows duwe mode mbukak file yen sawise dibukak ora bisa dibusak.
            // Sing umume kita karepake ing kene amarga kita kepengin supaya eksekusi ora bisa diganti maneh sawise kita pasrah menyang libbacktrace, muga-muga bisa nyuda kemampuan kanggo ngirim data sewenang-wenang menyang libbacktrace (sing bisa dianggep salah).
            //
            //
            // Amarga kita nari ing kene kanggo nyoba golek kunci ing gambar kita dhewe:
            //
            // * Entuk cekelan kanggo proses saiki, muat jeneng file.
            // * Bukak file menyang jeneng berkas kasebut kanthi panji sing tengen.
            // * Muat ulang jeneng proses saiki, priksa manawa padha
            //
            // Yen sing kabeh liwat kita ing teori wis tenan kabuka file proses kita lan kita lagi dijamin ora bakal ngganti.FWIW Bunch saka iki disalin saka libstd historis, supaya iki interpretasi paling apa iki kedados.
            //
            //
            //
            //
            //
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                load_filename_opt().unwrap_or(ptr::null())
            }

            unsafe fn load_filename_opt() -> Result<*const libc::c_char, ()> {
                const N: usize = 256;
                // Iki urip ing memori statis supaya bisa bali ..
                static mut BUF: [i8; N] = [0; N];
                // ... lan iki urip ing tumpukan amarga iku sawetara
                let mut stack_buf = [0; N];
                let name1 = query_full_name(&mut BUF)?;

                let handle = CreateFileA(
                    name1.as_ptr(),
                    GENERIC_READ,
                    FILE_SHARE_READ | FILE_SHARE_WRITE,
                    ptr::null_mut(),
                    OPEN_EXISTING,
                    0,
                    ptr::null_mut(),
                );
                if handle.is_null() {
                    return Err(());
                }

                let name2 = query_full_name(&mut stack_buf)?;
                if name1 != name2 {
                    CloseHandle(handle);
                    return Err(())
                }
                // sengojo bocor `handle` kene amarga gadhah mbukak sing kudu ngreksa kunci kita ing jeneng berkas iki.
                //
                Ok(name1.as_ptr())
            }

            unsafe fn query_full_name(buf: &mut [i8]) -> Result<&[i8], ()> {
                let dll = GetModuleHandleA(b"kernel32.dll\0".as_ptr() as *const i8);
                if dll.is_null() {
                    return Err(())
                }
                let ptrQueryFullProcessImageNameA =
                    GetProcAddress(dll, b"QueryFullProcessImageNameA\0".as_ptr() as *const _) as usize;
                if ptrQueryFullProcessImageNameA == 0
                {
                    return Err(());
                }
                use core::mem;
                let p1 = OpenProcess(PROCESS_QUERY_INFORMATION, FALSE, GetCurrentProcessId());
                let mut len = buf.len() as u32;
                let pfnQueryFullProcessImageNameA : extern "system" fn(
                    hProcess: HANDLE,
                    dwFlags: DWORD,
                    lpExeName: LPSTR,
                    lpdwSize: PDWORD,
                ) -> BOOL = mem::transmute(ptrQueryFullProcessImageNameA);

                let rc = pfnQueryFullProcessImageNameA(p1, 0, buf.as_mut_ptr(), &mut len);
                CloseHandle(p1);

                // Kita pengin ngasilake irisan sing wis entek, mula yen kabeh diisi lan padha karo dawa total, podo karo sing gagal.
                //
                //
                // Yen ora, nalika ngasilake sukses, priksa manawa bait kasebut kalebu ing irisan.
                //
                //
                if rc == 0 || len == buf.len() as u32 {
                    Err(())
                } else {
                    assert_eq!(buf[len as usize], 0);
                    Ok(&buf[..(len + 1) as usize])
                }
            }
        } else if #[cfg(target_os = "vxworks")] {
            unsafe fn load_filename() -> *const libc::c_char {
                use libc;
                use core::mem;

                const N: usize = libc::VX_RTP_NAME_LENGTH as usize + 1;
                static mut BUF: [libc::c_char; N] = [0; N];

                let mut rtp_desc : libc::RTP_DESC = mem::zeroed();
                if (libc::rtpInfoGet(0, &mut rtp_desc as *mut libc::RTP_DESC) == 0) {
                    BUF.copy_from_slice(&rtp_desc.pathName);
                    BUF.as_ptr()
                } else {
                    ptr::null()
                }
            }
        } else {
            unsafe fn load_filename() -> *const libc::c_char {
                ptr::null()
            }
        }
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let symaddr = what.address_or_ip() as usize;

    // Kesalahan backtrace saiki disapu ing karpet
    let state = init_state();
    if state.is_null() {
        return;
    }

    // Nelpon `backtrace_syminfo` API sing (saka maca kode) kudu nelpon `syminfo_cb` persis sapisan (utawa gagal amarga ana kesalahan).
    // We banjur nangani luwih ing `syminfo_cb`.
    //
    // Elinga yen kita apa iki wiwit `syminfo` bakal takon Tabel simbol, nemokake jeneng simbol sanajan boten wonten informasi debug ing binar.
    //
    //
    let mut syminfo_state = SyminfoState { pc: symaddr, cb };
    bt::backtrace_syminfo(
        state,
        symaddr as uintptr_t,
        syminfo_cb,
        error_cb,
        &mut syminfo_state as *mut _ as *mut _,
    );
}

pub unsafe fn clear_symbol_cache() {}