use core::{fmt, str};

cfg_if::cfg_if! {
    if #[cfg(feature = "std")] {
        use std::path::Path;
        use std::prelude::v1::*;
    }
}

use super::backtrace::Frame;
use super::types::BytesOrWideString;
use core::ffi::c_void;
use rustc_demangle::{try_demangle, Demangle};

/// Ngatasi alamat menyang simbol, ngirim simbol menyang penutupan sing ditemtokake.
///
/// Fungsi iki bakal nggoleki alamat sing diwenehake ing wilayah kayata tabel simbol lokal, tabel simbol dinamis, utawa info debug DWARF (gumantung saka implementasi sing diaktifake) kanggo nemokake simbol sing bakal ngasilake.
///
///
/// Panutupan bisa uga ora ditelpon yen resolusi ora bisa ditindakake, lan uga bisa uga diarani luwih saka sepisan yen ana fungsi garis besar.
///
/// Simbol sing diwenehake minangka eksekusi ing `addr` sing ditemtokake, ngasilake pasangan file/line kanggo alamat kasebut (yen kasedhiya).
///
/// Elinga yen yen sampeyan duwe `Frame` banjur iku dianjurake kanggo nggunakake fungsi `resolve_frame` tinimbang siji iki.
///
/// # Fitur sing dibutuhake
///
/// Fungsi iki mbutuhake fitur `std` saka `backtrace` crate supaya bisa aktif, lan fitur `std` diaktifake kanthi gawan.
///
/// # Panics
///
/// Fungsi iki ngupayakake ora nate panic, nanging yen `cb` nyedhiyakake panics, mula sawetara platform bakal meksa panic dobel kanggo ngilangi proses kasebut.
/// Sawetara platform nggunakake perpustakaan C sing nggunakake callback internal sing ora bisa dibukak, mula panicking saka `cb` bisa uga nyebabake proses aborsi.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         let ip = frame.ip();
///
///         backtrace::resolve(ip, |symbol| {
///             // ...
///         });
///
///         false // mung deleng pigura ndhuwur
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve<F: FnMut(&Symbol)>(addr: *mut c_void, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_unsynchronized(addr, cb) }
}

/// Ngatasi bingkai sing dijupuk sadurunge menyang simbol, ngirim simbol menyang penutupan sing ditemtokake.
///
/// Funcin iki nindakake fungsi sing padha karo `resolve`, nanging ora mbutuhake `Frame` minangka argumen, tinimbang alamat.
/// Iki bisa ngidini sawetara nindakake platform saka backtracing kanggo nyedhiyani informasi simbol luwih akurat utawa informasi bab pigura apik contone.
///
/// Disaranake nggunakake iki yen sampeyan bisa.
///
/// # Fitur sing dibutuhake
///
/// Fungsi iki mbutuhake fitur `std` saka `backtrace` crate supaya bisa aktif, lan fitur `std` diaktifake kanthi gawan.
///
/// # Panics
///
/// Fungsi iki ngupayakake ora nate panic, nanging yen `cb` nyedhiyakake panics, mula sawetara platform bakal meksa panic dobel kanggo ngilangi proses kasebut.
/// Sawetara platform nggunakake perpustakaan C sing nggunakake callback internal sing ora bisa dibukak, mula panicking saka `cb` bisa uga nyebabake proses aborsi.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         backtrace::resolve_frame(frame, |symbol| {
///             // ...
///         });
///
///         false // mung deleng pigura ndhuwur
///     });
/// }
/// ```
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve_frame<F: FnMut(&Symbol)>(frame: &Frame, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_frame_unsynchronized(frame, cb) }
}

pub enum ResolveWhat<'a> {
    Address(*mut c_void),
    Frame(&'a Frame),
}

impl<'a> ResolveWhat<'a> {
    #[allow(dead_code)]
    fn address_or_ip(&self) -> *mut c_void {
        match self {
            ResolveWhat::Address(a) => adjust_ip(*a),
            ResolveWhat::Frame(f) => adjust_ip(f.ip()),
        }
    }
}

// Nilai IP saka pigura tumpukan biasane (always?) instruksi *sawise* telpon yaiku tilas tumpukan asline.
// Simbol iki nyebabake nomer filename/line dadi luwih maju lan bisa uga batal yen wis cedhak fungsi.
//
// Iki umume biasane dadi kasus ing kabeh platform, mula kita bakal terus ngilangi siji saka ip sing wis dirampungake kanggo ngrampungake instruksi telpon sadurunge, tinimbang instruksi sing dibalekake.
//
//
// Saenipun kita ora bakal nindakake iki.
// Saenipun kita bakal mbutuhake panelpon saka API `resolve` kene kanggo manual apa -1 lan akun sing padha arep informasi lokasi kanggo *sadurungé* instruction, ora saiki.
// Saenipun kita uga bakal mbabarake `Frame` yen pancen alamat instruksi sabanjure utawa saiki.
//
// Saiki, iki minangka keprigelan ceruk sing cukup, mula kanthi internal kita mesthi bisa nyuda siji.
// Pelanggan kudu terus makarya lan entuk asil sing cukup apik, mula kita kudu cukup.
//
//
//
//
//
//
fn adjust_ip(a: *mut c_void) -> *mut c_void {
    if a.is_null() {
        a
    } else {
        (a as usize - 1) as *mut c_void
    }
}

/// Padha karo `resolve`, mung ora aman amarga ora diselarasake.
///
/// Fungsi iki ora duwe jaminan sinkronisasi nanging kasedhiya yen fitur `std` crate iki ora dikompilasi.
/// Deleng fungsi `resolve` kanggo dokumentasi lan conto liyane.
///
/// # Panics
///
/// Deleng informasi babagan `resolve` kanggo tandha-tandha nalika panik `cb`.
///
pub unsafe fn resolve_unsynchronized<F>(addr: *mut c_void, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Address(addr), &mut cb)
}

/// Padha `resolve_frame`, mung aman minangka iku unsynchronized.
///
/// Fungsi iki ora duwe jaminan sinkronisasi nanging kasedhiya yen fitur `std` crate iki ora dikompilasi.
/// Deleng fungsi `resolve_frame` kanggo dokumentasi lan conto liyane.
///
/// # Panics
///
/// Deleng informasi babagan `resolve_frame` kanggo tandha-tandha nalika panik `cb`.
///
pub unsafe fn resolve_frame_unsynchronized<F>(frame: &Frame, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Frame(frame), &mut cb)
}

/// trait makili resolusi simbol ing sawijining file.
///
/// trait iki digawe minangka obyek trait menyang penutupan fungsi `backtrace::resolve`, lan meh dikirim amarga ora dingerteni implementasine sing ana ing mburine.
///
///
/// A simbol bisa menehi informasi kontekstual bab fungsi, contone jeneng, filename, nomer baris, alamat pas, etc.
/// Ora kabeh informasi mesthi kasedhiya ing simbol, nanging kabeh cara ngasilake `Option`.
///
///
pub struct Symbol {
    // TODO: umur iki kudu terus dikatutake nganti `Symbol`,
    // nanging saiki owah-owahan anyar.
    // Saiki, iki aman amarga `Symbol` mung diwenehake kanthi referensi lan ora bisa dikloning.
    inner: imp::Symbol<'static>,
}

impl Symbol {
    /// Ngasilake jeneng fungsi iki.
    ///
    /// Struktur bali bisa digunakake kanggo takon macem-macem properti babagan jeneng simbol:
    ///
    ///
    /// * Implementasi `Display` bakal nyithak simbol sing wis demangled.
    /// * Nilai simbol `str` mentah bisa diakses (yen valid utf-8).
    /// * Bait mentah kanggo jeneng simbol bisa diakses.
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.inner.name()
    }

    /// Ngasilake alamat wiwitan fungsi iki.
    pub fn addr(&self) -> Option<*mut c_void> {
        self.inner.addr().map(|p| p as *mut _)
    }

    /// Ngasilake jeneng file mentah dadi irisan.
    /// Iki utamane migunani kanggo lingkungan `no_std`.
    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.inner.filename_raw()
    }

    /// Ngasilake nomer kolom ing endi simbol iki saiki dieksekusi.
    ///
    /// Mung gimli saiki sing menehi regane ing kene lan mung yen `filename` ngasilake `Some`, mula bisa uga ana gubernur sing padha.
    ///
    pub fn colno(&self) -> Option<u32> {
        self.inner.colno()
    }

    /// Ngasilake nomer baris kanggo simbol sing saiki dieksekusi.
    ///
    /// Nilai bali iki biasane `Some` yen `filename` ngasilake `Some`, lan Akibate tundhuk caveats padha.
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.inner.lineno()
    }

    /// Ngasilake jeneng file sing ditemtokake ing fungsi iki.
    ///
    /// Iki saiki mung kasedhiya nalika libbacktrace utawa Gimli digunakake (eg
    /// unix platform liyane) lan nalika binar dikompilasi karo debuginfo.
    /// Yen ora kahanan iki wis ketemu banjur iki kamungkinan bakal ngasilake `None`.
    ///
    /// # Fitur sing dibutuhake
    ///
    /// Fungsi iki mbutuhake fitur `std` saka `backtrace` crate supaya bisa aktif, lan fitur `std` diaktifake kanthi gawan.
    ///
    ///
    #[cfg(feature = "std")]
    #[allow(unreachable_code)]
    pub fn filename(&self) -> Option<&Path> {
        self.inner.filename()
    }
}

impl fmt::Debug for Symbol {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let mut d = f.debug_struct("Symbol");
        if let Some(name) = self.name() {
            d.field("name", &name);
        }
        if let Some(addr) = self.addr() {
            d.field("addr", &addr);
        }

        #[cfg(feature = "std")]
        {
            if let Some(filename) = self.filename() {
                d.field("filename", &filename);
            }
        }

        if let Some(lineno) = self.lineno() {
            d.field("lineno", &lineno);
        }
        d.finish()
    }
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        // Mungkin simbol C++ parsed, yen parsing simbol mangled minangka Rust gagal.
        //
        struct OptionCppSymbol<'a>(Option<::cpp_demangle::BorrowedSymbol<'a>>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(input: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(::cpp_demangle::BorrowedSymbol::new(input).ok())
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(None)
            }
        }
    } else {
        use core::marker::PhantomData;

        // Priksa manawa tetep ukuran nol iki, supaya fitur `cpp_demangle` ora duwe biaya yen dipateni.
        //
        struct OptionCppSymbol<'a>(PhantomData<&'a ()>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(_: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }
        }
    }
}

/// Pambungkus jeneng simbol kanggo nyedhiyakake aksesoris ergonomis kanggo jeneng sing wis entek, bait mentah, senar mentah, lsp.
///
// Allow kode mati nalika fitur `cpp_demangle` ora diaktifake.
#[allow(dead_code)]
pub struct SymbolName<'a> {
    bytes: &'a [u8],
    demangled: Option<Demangle<'a>>,
    cpp_demangled: OptionCppSymbol<'a>,
}

impl<'a> SymbolName<'a> {
    /// Nggawe jeneng simbol anyar saka bait sing nduwe dhasar.
    pub fn new(bytes: &'a [u8]) -> SymbolName<'a> {
        let str_bytes = str::from_utf8(bytes).ok();
        let demangled = str_bytes.and_then(|s| try_demangle(s).ok());

        let cpp = if demangled.is_none() {
            OptionCppSymbol::parse(bytes)
        } else {
            OptionCppSymbol::none()
        };

        SymbolName {
            bytes: bytes,
            demangled: demangled,
            cpp_demangled: cpp,
        }
    }

    /// Ngasilake mentahan (mangled) jeneng simbol minangka `str` yen simbol kasebut iku absah utf-8.
    ///
    /// Gunakake implementasine `Display` yen pengin versi sing wis demangled.
    pub fn as_str(&self) -> Option<&'a str> {
        self.demangled
            .as_ref()
            .map(|s| s.as_str())
            .or_else(|| str::from_utf8(self.bytes).ok())
    }

    /// Ngasilake jeneng simbol mentah minangka dhaptar bait
    pub fn as_bytes(&self) -> &'a [u8] {
        self.bytes
    }
}

fn format_symbol_name(
    fmt: fn(&str, &mut fmt::Formatter<'_>) -> fmt::Result,
    mut bytes: &[u8],
    f: &mut fmt::Formatter<'_>,
) -> fmt::Result {
    while bytes.len() > 0 {
        match str::from_utf8(bytes) {
            Ok(name) => {
                fmt(name, f)?;
                break;
            }
            Err(err) => {
                fmt("\u{FFFD}", f)?;

                match err.error_len() {
                    Some(len) => bytes = &bytes[err.valid_up_to() + len..],
                    None => break,
                }
            }
        }
    }
    Ok(())
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else if let Some(ref cpp) = self.cpp_demangled.0 {
                    cpp.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    } else {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    }
}

cfg_if::cfg_if! {
    if #[cfg(all(feature = "std", feature = "cpp_demangle"))] {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                use std::fmt::Write;

                if let Some(ref s) = self.demangled {
                    return s.fmt(f)
                }

                // Iki bisa dicithak yen simbol sing wis dibatalake ora bener, mula nangani kesalahan ing kene kanthi aja nyebar metu.
                //
                //
                if let Some(ref cpp) = self.cpp_demangled.0 {
                    let mut s = String::new();
                    if write!(s, "{}", cpp).is_ok() {
                        return s.fmt(f)
                    }
                }

                format_symbol_name(fmt::Debug::fmt, self.bytes, f)
            }
        }
    } else {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Debug::fmt, self.bytes, f)
                }
            }
        }
    }
}

/// Nyoba kanggo mbalekake memori cache sing digunakake kanggo simbolik alamat.
///
/// Cara iki bakal nyoba ngeculake sembarang struktur data global sing wis digunakake wis cached global utawa ing thread kang biasane makili informasi dwarf parsed utawa padha.
///
///
/// # Caveats
///
/// Nalika fungsi iki tansah kasedhiya iku ora bener apa ing paling nindakake.
/// Libraries kaya dbghelp utawa libbacktrace ora menehi fasilitas kanggo negara deallocate lan ngatur memori diparengake.
/// Kanggo saiki fitur `gimli-symbolize` saka crate iki mung fitur ngendi fungsi iki wis efek.
///
///
///
#[cfg(feature = "std")]
pub fn clear_symbol_cache() {
    let _guard = crate::lock::lock();
    unsafe {
        imp::clear_symbol_cache();
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        mod miri;
        use miri as imp;
    } else if #[cfg(all(windows, target_env = "msvc", not(target_vendor = "uwp")))] {
        mod dbghelp;
        use dbghelp as imp;
    } else if #[cfg(all(
        feature = "libbacktrace",
        any(unix, all(windows, not(target_vendor = "uwp"), target_env = "gnu")),
        not(target_os = "fuchsia"),
        not(target_os = "emscripten"),
        not(target_env = "uclibc"),
        not(target_env = "libnx"),
    ))] {
        mod libbacktrace;
        use libbacktrace as imp;
    } else if #[cfg(all(
        feature = "gimli-symbolize",
        any(unix, windows),
        not(target_vendor = "uwp"),
        not(target_os = "emscripten"),
    ))] {
        mod gimli;
        use gimli as imp;
    } else {
        mod noop;
        use noop as imp;
    }
}