// mung digunakake ing Linux saiki, dadi ngidini kode mati ing panggon liya
#![cfg_attr(not(target_os = "linux"), allow(dead_code))]

use alloc::vec;
use alloc::vec::Vec;
use core::cell::UnsafeCell;

/// Alokasi arena sederhana kanggo buffer bait.
pub struct Stash {
    buffers: UnsafeCell<Vec<Vec<u8>>>,
}

impl Stash {
    pub fn new() -> Stash {
        Stash {
            buffers: UnsafeCell::new(Vec::new()),
        }
    }

    /// Alokasi buffer ukuran sing ditemtokake banjur ngasilake referensi sing bisa diowahi.
    ///
    pub fn allocate(&self, size: usize) -> &mut [u8] {
        // SAFETY: iki minangka siji-sijine fungsi sing bisa mutasi
        // referensi kanggo `self.buffers`.
        let buffers = unsafe { &mut *self.buffers.get() };
        let i = buffers.len();
        buffers.push(vec![0; size]);
        // SAFETY: kita ora nate mbusak elemen saka `self.buffers`, dadi referensi
        // menyang data ing buffer apa wae, bakal urip anggere `self` urip.
        &mut buffers[i]
    }
}