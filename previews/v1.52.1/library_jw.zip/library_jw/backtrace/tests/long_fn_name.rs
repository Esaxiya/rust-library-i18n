use backtrace::Backtrace;

// Jeneng modul 50 karakter
mod _234567890_234567890_234567890_234567890_234567890 {
    // Jeneng strukture 50 karakter
    #[allow(non_camel_case_types)]
    pub struct _234567890_234567890_234567890_234567890_234567890<T>(T);
    impl<T> _234567890_234567890_234567890_234567890_234567890<T> {
        #[allow(dead_code)]
        pub fn new() -> crate::Backtrace {
            crate::Backtrace::new()
        }
    }
}

// Jeneng fungsi sing dawa kudu dipotong dadi (MAX_SYM_NAME, 1) karakter.
// Mung mbukak tes iki kanggo msvc, amarga gnu nyithak "<no info>" kanggo kabeh bingkai.
#[test]
#[cfg(all(windows, target_env = "msvc"))]
fn test_long_fn_name() {
    use _234567890_234567890_234567890_234567890_234567890::_234567890_234567890_234567890_234567890_234567890 as S;

    // 10 repetisi jeneng strukture, mula jeneng fungsi sing mumpuni paling ora 10 *(50 + 50)* 2=2000 karakter.
    //
    // Sejatine luwih suwe amarga uga kalebu `::`, `<>` lan jeneng modul saiki
    //
    let bt = S::<S<S<S<S<S<S<S<S<S<i32>>>>>>>>>>::new();
    println!("{:?}", bt);

    let mut found_long_name_frame = false;

    for frame in bt.frames() {
        let symbols = frame.symbols();
        if symbols.is_empty() {
            continue;
        }

        if let Some(function_name) = symbols[0].name() {
            let function_name = function_name.as_str().unwrap();
            if function_name.contains("::_234567890_234567890_234567890_234567890_234567890") {
                found_long_name_frame = true;
                assert!(function_name.len() > 200);
            }
        }
    }

    assert!(found_long_name_frame);
}