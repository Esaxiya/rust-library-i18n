# backtrace-rs

[Documentation](https://docs.rs/backtrace)

Perpustakaan kanggo entuk backtraces nalika runtime kanggo Rust.
Perpustakaan iki tujuane kanggo nambah dhukungan saka perpustakaan standar kanthi menehi antarmuka program kanggo bisa digunakake, nanging uga ndhukung kanthi gampang nyithak backtrace saiki kaya libstd's panics.

## Install

```toml
[dependencies]
backtrace = "0.3"
```

## Usage

Kanggo mung njupuk backtrace lan nundha urusan nganti mengko, sampeyan bisa nggunakake jinis `Backtrace` level paling dhuwur.

```rust
use backtrace::Backtrace;

fn main() {
    let bt = Backtrace::new();

    // do_some_work();

    println!("{:?}", bt);
}
```

Nanging, yen sampeyan pengin luwih akeh akses menyang fungsi nelusuri sing nyata, sampeyan bisa nggunakake fungsi `trace` lan `resolve` kanthi langsung.

```rust
fn main() {
    backtrace::trace(|frame| {
        let ip = frame.ip();
        let symbol_address = frame.symbol_address();

        // Ngatasi petunjuk pitunjuk iki menyang jeneng simbol
        backtrace::resolve_frame(frame, |symbol| {
            if let Some(name) = symbol.name() {
                // ...
            }
            if let Some(filename) = symbol.filename() {
                // ...
            }
        });

        true // terus menyang pigura sabanjure
    });
}
```

# License

Proyek iki dilisensi miturut salah siji

 * Lisensi Apache, Versi 2.0, ([LICENSE-APACHE](LICENSE-APACHE) utawa http://www.apache.org/licenses/LICENSE-2.0)
 * Lisensi MIT ([LICENSE-MIT](LICENSE-MIT) utawa http://opensource.org/licenses/MIT)

miturut pilihan sampeyan.

### Contribution

Kajaba sampeyan kanthi tegas negesake, sumbangan sing disengaja kanthi sengaja dilebokake ing backtrace-rs dening sampeyan, kaya sing wis ditemtokake ing lisensi Apache-2.0, bakal dilisensi kaping pindho kaya ing ndhuwur, tanpa syarat utawa katemtuan tambahan.







