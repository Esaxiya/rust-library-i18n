//! Mbusak panics kanggo Miri.
use alloc::boxed::Box;
use core::any::Any;

// Jinis DLL sing engine Miri propagates liwat unwinding kanggo kita.
// Kudu pitunjuk-ukuran.
type Payload = Box<Box<dyn Any + Send>>;

extern "Rust" {
    /// Miri-kasedhiya fungsi extern kanggo miwiti unwinding.
    fn miri_start_panic(payload: *mut u8) -> !;
}

pub unsafe fn panic(payload: Box<dyn Any + Send>) -> u32 {
    // Beban sing dilampahi menyang `miri_start_panic` bakal dadi argumen sing bisa ditemokake ing `cleanup` ing ngisor iki.
    // Dadi kita mung kothak kaping sapisan, kanggo entuk ukuran kaya pointer.
    let payload_box: Payload = Box::new(payload);
    miri_start_panic(Box::into_raw(payload_box) as *mut u8)
}

pub unsafe fn cleanup(payload_box: *mut u8) -> Box<dyn Any + Send> {
    // Waras `Box` sing ndasari.
    let payload_box: Payload = Box::from_raw(payload_box as *mut _);
    *payload_box
}