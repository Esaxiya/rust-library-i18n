//! Windows SEH
//!
//! On Windows (saiki mung ing MSVC), sing istiméwa standar mekanisme nangani wis kabentuk Pengecualian Penanganan (SEH).
//! Iki cukup beda saka basis Dwarf-jawab istiméwa (eg, apa platform liyane unix nggunakake) ing syarat-syarat internals compiler, supaya LLVM dibutuhake kanggo duwe hasil apik support ekstra kanggo Seh.
//!
//! Cekakipun, apa mengkono punika:
//!
//! 1. Fungsi `panic` nyebut fungsi Windows standar `_CxxThrowException` kanggo mbuwang pengecualian kaya C++ , sing nyebabake proses santai.
//! 2.
//! Kabeh bantalan landing déning compiler nggunakake fungsi pribadine `__CxxFrameHandler3`, fungsi ing CRT, lan kode unwinding ing Windows bakal nggunakake fungsi pribadine iki kanggo nglakokaké kode ngresiki ing tumpukan.
//!
//! 3. Kabeh telpon compiler-kui kanggo `invoke` duwe pesawat landing pad minangka instruction `cleanuppad` LLVM, kang nuduhake wiwitan tumindake ngresiki.
//! Kepribadian (ing langkah 2, sing ditemtokake ing CRT) tanggung jawab kanggo nindakake rutinitas reresik.
//! 4. Pungkasanipun kode "catch" ing kasirat `try` (déning compiler ing) wis kaleksanan lan nuduhake kontrol sing kudu teka maneh menyang Rust.
//! Iki wis rampung liwat `catchswitch` plus instruction `catchpad` ing syarat-syarat LLVM IR, pungkasanipun bali kontrol normal kanggo program karo instruction `catchret`.
//!
//! Sawetara beda tartamtu saka jawab istiméwa basis gcc sing:
//!
//! * Rust ora fungsi pribadine adat, iku tinimbang *tansah*`__CxxFrameHandler3`.Tambahan, ora nyaring ekstra wis dileksanakake, supaya kita mungkasi munggah keno sembarang C++ seng sing kelakon kanggo katon kaya jenis kita mbuwang kuwi.
//! Elinga yen mbuwang pangecualian menyang Rust punika prilaku cetho tho, supaya iki kudu nggoleki.
//! * Kita wis tak sawetara data kanggo ngirimaken tengen wates unwinding, khusus sing `Box<dyn Any + Send>`.Kaya pengecualian Dwarf, loro petunjuk kasebut disimpen minangka muatan kajaba.
//! On MSVC, Nanging, ana ora perlu kanggo persediaan numpuk ekstra amarga tumpukan telpon wadi nalika fungsi Filter kang kaleksanan.
//! Tegese sing penunjuk sing liwati langsung kanggo `_CxxThrowException` kang banjur mbalekake ing fungsi Filter ditulis kanggo pigura tumpukan saka kasirat `try`.
//!
//! [win64]: https://docs.microsoft.com/en-us/cpp/build/exception-handling-x64
//! [llvm]: http://llvm.org/docs/ExceptionHandling.html#background-on-windows-exceptions
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(nonstandard_style)]

use alloc::boxed::Box;
use core::any::Any;
use core::mem::{self, ManuallyDrop};
use libc::{c_int, c_uint, c_void};

struct Exception {
    // Iki kudu dadi Opsi amarga kita entuk pangecualian kanthi referensi lan destruktor kasebut dieksekusi dening runtime C++ .
    // Nalika ngilangi Box ing istiméwa, kita kudu tetep istiméwa ing negara sing sah kanggo ngrusak supaya bisa mlaku tanpa ngeculake Kothak kasebut.
    //
    //
    data: Option<Box<dyn Any + Send>>,
}

// pisanan, a Bunch wutuh saka jinis ukara.Ana sawetara oddities platform-tartamtu kene, lan akèh sing mung blatantly disalin saka LLVM.Tujuan kabeh iki kanggo ngleksanakake fungsi `panic` ngisor liwat telpon kanggo `_CxxThrowException`.
//
// Fungsi iki mbutuhake rong bantahan.Kapisan iku pitunjuk kanggo data kita lagi maringaken ing, kang ing kasus iki obyek trait kita.Cantik gampang kanggo nggoleki!sabanjuré, Nanging, luwih rumit.
// Iki minangka petunjuk kanggo struktur `_ThrowInfo`, lan umume mung dimaksudake kanggo nggambarake istiméwa sing dibuwang.
//
// Saiki definisi jinis iki [1] punika wulu sethitik, lan oddity utama (lan prabédan ing artikel online) iku ing 32-dicokot penunjuk sing penunjuk nanging ing 64-dicokot penunjuk sing ditulis minangka 32-dicokot tambahan saka Simbol `__ImageBase`.
//
// The `ptr_t` lan `ptr!` gedhe ing modul ngisor digunakake kanggo nyebut iki.
//
// Mbingungake saka jinis ukara uga rapet nderek apa LLVM mancaraken iki Urut saka operasi.Contone, yen sampeyan nyusun kode C++ iki ing MSVC lan ngetokake LLVM IR:
//
//      #include <stdint.h>
//
//      str rust_panic {
//          rust_panic(const rust_panic&);
//          ~rust_panic();
//
//          uint64_t x[2];};
//
//      batal foo() { rust_panic a = {0, 1};
//          mbuwang a;}
//
// Sing ateges apa kang kita lagi nyoba niru.Paling angka pancet ngisor iki njiplak saka LLVM,
//
// Ing kasus, struktur sing kabeh dibangun ing proses padha, lan iku mung Luwih verbose kanggo kita.
//
// [1]: http://www.geoffchappell.com/studies/msvc/language/predefined/
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

#[cfg(target_arch = "x86")]
#[macro_use]
mod imp {
    pub type ptr_t = *mut u8;

    macro_rules! ptr {
        (0) => {
            core::ptr::null_mut()
        };
        ($e:expr) => {
            $e as *mut u8
        };
    }
}

#[cfg(not(target_arch = "x86"))]
#[macro_use]
mod imp {
    pub type ptr_t = u32;

    extern "C" {
        pub static __ImageBase: u8;
    }

    macro_rules! ptr {
        (0) => (0);
        ($e:expr) => {
            (($e as usize) - (&imp::__ImageBase as *const _ as usize)) as u32
        }
    }
}

#[repr(C)]
pub struct _ThrowInfo {
    pub attributes: c_uint,
    pub pmfnUnwind: imp::ptr_t,
    pub pForwardCompat: imp::ptr_t,
    pub pCatchableTypeArray: imp::ptr_t,
}

#[repr(C)]
pub struct _CatchableTypeArray {
    pub nCatchableTypes: c_int,
    pub arrayOfCatchableTypes: [imp::ptr_t; 1],
}

#[repr(C)]
pub struct _CatchableType {
    pub properties: c_uint,
    pub pType: imp::ptr_t,
    pub thisDisplacement: _PMD,
    pub sizeOrOffset: c_int,
    pub copyFunction: imp::ptr_t,
}

#[repr(C)]
pub struct _PMD {
    pub mdisp: c_int,
    pub pdisp: c_int,
    pub vdisp: c_int,
}

#[repr(C)]
pub struct _TypeDescriptor {
    pub pVFTable: *const u8,
    pub spare: *mut u8,
    pub name: [u8; 11],
}

// Elinga yen kita sengaja nglirwakake aturan mangling jeneng ing kene: kita ora pengin C++ bisa nyekel Rust panics kanthi mung ngumumake `struct rust_panic`.
//
//
// Nalika ngowahi, priksa manawa senar jeneng jinis cocog banget karo sing digunakake ing `compiler/rustc_codegen_llvm/src/intrinsic.rs`.
//
const TYPE_NAME: [u8; 11] = *b"rust_panic\0";

static mut THROW_INFO: _ThrowInfo = _ThrowInfo {
    attributes: 0,
    pmfnUnwind: ptr!(0),
    pForwardCompat: ptr!(0),
    pCatchableTypeArray: ptr!(0),
};

static mut CATCHABLE_TYPE_ARRAY: _CatchableTypeArray =
    _CatchableTypeArray { nCatchableTypes: 1, arrayOfCatchableTypes: [ptr!(0)] };

static mut CATCHABLE_TYPE: _CatchableType = _CatchableType {
    properties: 0,
    pType: ptr!(0),
    thisDisplacement: _PMD { mdisp: 0, pdisp: -1, vdisp: 0 },
    sizeOrOffset: mem::size_of::<Exception>() as c_int,
    copyFunction: ptr!(0),
};

extern "C" {
    // Anjog `\x01` bait punika bener sinyal gaib kanggo LLVM kanggo *ora* aplikasi sembarang mangling kaya prefixing karo karakter `_`.
    //
    //
    // simbol Iki vtable digunakake dening C++ 's `std::type_info`.
    // Obyek tipe `std::type_info`, jinis deskriptor, duwe petunjuk ing tabel iki.
    // Deskripter jinis dirujuk dening struktur C++ EH sing wis ditemtokake ing ndhuwur lan sing dibangun ing ngisor iki.
    //
    #[link_name = "\x01??_7type_info@@6B@"]
    static TYPE_INFO_VTABLE: *const u8;
}

// Deskriptor jinis iki mung digunakake nalika nggawe istiméwa.
// Bagean nyekel ditangani dening intrinsik coba, sing ngasilake TypeDescriptor dhewe.
//
// Iki nggoleki wiwit MSVC Efesus durasi senar comparison ing jeneng jinis TypeDescriptors match tinimbang pitunjuk podo.
//
static mut TYPE_DESCRIPTOR: _TypeDescriptor = _TypeDescriptor {
    pVFTable: unsafe { &TYPE_INFO_VTABLE } as *const _ as *const _,
    spare: core::ptr::null_mut(),
    name: TYPE_NAME,
};

// Destructor digunakake yen kode C++ mutusake kanggo njupuk pengecualian lan nyelehake tanpa nyebar.
// Nyekel bagéan saka kasirat nyoba ngeset tembung pisanan obyek istiméwa kanggo 0 supaya Mlayu dening destructor ing.
//
// Elinga yen x86 Windows nggunakake konvensi nelpon "thiscall" kanggo fungsi anggota C++ tinimbang konvensi panggilan "C" standar.
//
// Fungsi exception_copy iku khusus ing kene: diarani nganggo runtime MSVC ing blok try/catch lan panic sing digawe ing kene bakal digunakake minangka asil saka salinan istiméwa.
//
// Iki digunakake dening C++ durasi kanggo ndhukung njupuk seng karo std::exception_ptr, kang kita ora bisa ndhukung amarga Box<dyn Any>ora bisa dikloning.
//
//
//
//
//
macro_rules! define_cleanup {
    ($abi:tt) => {
        unsafe extern $abi fn exception_cleanup(e: *mut Exception) {
            if let Exception { data: Some(b) } = e.read() {
                drop(b);
                super::__rust_drop_panic();
            }
        }
        #[unwind(allowed)]
        unsafe extern $abi fn exception_copy(_dest: *mut Exception,
                                             _src: *mut Exception)
                                             -> *mut Exception {
            panic!("Rust panics cannot be copied");
        }
    }
}
cfg_if::cfg_if! {
   if #[cfg(target_arch = "x86")] {
       define_cleanup!("thiscall");
   } else {
       define_cleanup!("C");
   }
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    use core::intrinsics::atomic_store;

    // _CxxThrowException nglakokake kabeh ing pigura tumpukan iki, mula ora prelu transfer `data` menyang tumpukan.
    // Kita mung menehi pointer tumpukan menyang fungsi iki.
    //
    // The ManuallyDrop perlu kene awit kita ora pengin Pengecualian kanggo bakal dropped nalika unwinding.
    // Nanging, bakal diturunake kanthi istiméwa_cleanup sing ditimbali karo runtime C++ .
    //
    //
    let mut exception = ManuallyDrop::new(Exception { data: Some(data) });
    let throw_ptr = &mut exception as *mut _ as *mut _;

    // Iki ... bisa uga katon ngagetne, lan bisa dibenerake.On 32-dicokot MSVC penunjuk antarane struktur iki mung sing, penunjuk.
    // Nanging, ing MSVC 64-bit, penunjuk ing antarane struktur kasebut diarani offset 32-bit saka `__ImageBase`.
    //
    // Akibate, ing MSVC 32-bit, kita bisa ngumumake kabeh petunjuk kasebut ing `statis` ing ndhuwur.
    // Ing MSVC 64-bit, kita kudu nyebutake pitunjuk ing statis, sing saiki ora diidini Rust, mula kita ora bisa nindakake.
    //
    // Sing paling apik sabanjure, yaiku ngisi struktur kasebut nalika runtime (panicking wis "slow path").
    // Dadi ing kene kita nafsirake kabeh bidang penunjuk kasebut minangka bilangan bulat 32-bit banjur nyimpen nilai sing relevan (kanthi atom, amarga panics bebarengan bisa uga kedadeyan).
    //
    // Teknis durasi sing mbokmenawa bakal nggawe diwaca nonatomic lapangan iki, nanging ing teori padha tau maca *salah* Nilai supaya ngirim ora banget ala ...
    //
    // Ing kasus, kita Sejatine kudu nglakoni kaya iki nganti kita bisa nyebut operasi liyane ing statics (lan kita bakal bisa).
    //
    //
    //
    //
    //
    //
    //
    //
    atomic_store(&mut THROW_INFO.pmfnUnwind as *mut _ as *mut u32, ptr!(exception_cleanup) as u32);
    atomic_store(
        &mut THROW_INFO.pCatchableTypeArray as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE_ARRAY as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE_ARRAY.arrayOfCatchableTypes[0] as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.pType as *mut _ as *mut u32,
        ptr!(&TYPE_DESCRIPTOR as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.copyFunction as *mut _ as *mut u32,
        ptr!(exception_copy) as u32,
    );

    extern "system" {
        #[unwind(allowed)]
        fn _CxxThrowException(pExceptionObject: *mut c_void, pThrowInfo: *mut u8) -> !;
    }

    _CxxThrowException(throw_ptr, &mut THROW_INFO as *mut _ as *mut _);
}

pub unsafe fn cleanup(payload: *mut u8) -> Box<dyn Any + Send> {
    // Payload NULL ing kene tegese teka ing kene saka nyekel (...) saka __rust_try.
    // Mengkono nalika istiméwa manca non-Rust disusul.
    if payload.is_null() {
        super::__rust_foreign_exception();
    } else {
        let exception = &mut *(payload as *mut Exception);
        exception.data.take().unwrap()
    }
}

// Iki dibutuhake dening compiler kanggo ana (eg, iku item lang), nanging iku ora bener disebut dening compiler amarga __C_specific_handler utawa_except_handler3 fungsi pribadine sing tansah digunakake.
//
// Mula, iki mung rintisan aborsi.
//
#[lang = "eh_personality"]
#[cfg(not(test))]
fn rust_eh_personality() {
    core::intrinsics::abort()
}