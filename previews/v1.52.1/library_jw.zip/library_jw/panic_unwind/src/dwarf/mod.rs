//! Utilitas kanggo ngramal aliran data sing dienkode DWARF.
//! Deleng standar <http://www.dwarfstd.org>, DWARF-4, Bagean 7, "Data Representation"
//!

// Modul iki mung digunakake x86_64-pc-windows-gnu saiki, nanging kita kompilasi ing endi wae kanggo ngindhari regresi.
//
#![allow(unused)]

#[cfg(test)]
mod tests;

pub mod eh;

use core::mem;

pub struct DwarfReader {
    pub ptr: *const u8,
}

#[repr(C, packed)]
struct Unaligned<T>(T);

impl DwarfReader {
    pub fn new(ptr: *const u8) -> DwarfReader {
        DwarfReader { ptr }
    }

    // Dwarf lepen sing dikempalken, supaya contone, u32 bakal ora kudu bisa didadekake siji ing bates 4-bait.
    // Iki bisa uga nimbulaké masalah ing platform kanthi syarat sing cocog.
    // Kanthi mbungkus data ing struktur "packed", kita ngandhani backend supaya ngasilake kode "misalignment-safe".
    //
    pub unsafe fn read<T: Copy>(&mut self) -> T {
        let Unaligned(result) = *(self.ptr as *const Unaligned<T>);
        self.ptr = self.ptr.add(mem::size_of::<T>());
        result
    }

    // ULEB128 lan SLEB128 encodings sing ditetepake ing bagean 7.6, "Variable Length Data".
    //
    pub unsafe fn read_uleb128(&mut self) -> u64 {
        let mut shift: usize = 0;
        let mut result: u64 = 0;
        let mut byte: u8;
        loop {
            byte = self.read::<u8>();
            result |= ((byte & 0x7F) as u64) << shift;
            shift += 7;
            if byte & 0x80 == 0 {
                break;
            }
        }
        result
    }

    pub unsafe fn read_sleb128(&mut self) -> i64 {
        let mut shift: u32 = 0;
        let mut result: u64 = 0;
        let mut byte: u8;
        loop {
            byte = self.read::<u8>();
            result |= ((byte & 0x7F) as u64) << shift;
            shift += 7;
            if byte & 0x80 == 0 {
                break;
            }
        }
        // sign-extend
        if shift < u64::BITS && (byte & 0x40) != 0 {
            result |= (!0 as u64) << shift;
        }
        result as i64
    }
}