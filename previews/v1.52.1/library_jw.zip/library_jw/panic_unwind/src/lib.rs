//! Implementasi panics liwat tumpukan tombol
//!
//! crate Iki lampahing panics ing Rust nggunakake "most native" tumpukan mekanisme unwinding saka platform iki kang nyawiji kanggo.
//! Iki ateges dikategorikake dadi telung ember saiki:
//!
//! 1. Target MSVC nggunakake SEH ing file `seh.rs`.
//! 2. Emscripten migunakake C++ seng ing file `emcc.rs`.
//! 3. Kabeh target liyane nggunakake libunwind/libgcc ing file `gcc.rs`.
//!
//! dokumentasi meneh implementasine bisa ditemokaké ing modul gegandhengan.
//!
//!

#![no_std]
#![unstable(feature = "panic_unwind", issue = "32837")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/"
)]
#![feature(core_intrinsics)]
#![feature(int_bits_const)]
#![feature(lang_items)]
#![feature(nll)]
#![feature(panic_unwind)]
#![feature(staged_api)]
#![feature(std_internals)]
#![feature(unwind_attributes)]
#![feature(abi_thiscall)]
#![feature(rustc_attrs)]
#![feature(raw)]
#![panic_runtime]
#![feature(panic_runtime)]
// `real_imp` ora digunakake karo Miri, mula ora ana bebaya.
#![cfg_attr(miri, allow(dead_code))]

use alloc::boxed::Box;
use core::any::Any;
use core::panic::BoxMeUp;

cfg_if::cfg_if! {
    if #[cfg(target_os = "emscripten")] {
        #[path = "emcc.rs"]
        mod real_imp;
    } else if #[cfg(target_os = "hermit")] {
        #[path = "hermit.rs"]
        mod real_imp;
    } else if #[cfg(target_env = "msvc")] {
        #[path = "seh.rs"]
        mod real_imp;
    } else if #[cfg(any(
        all(target_family = "windows", target_env = "gnu"),
        target_os = "psp",
        target_family = "unix",
        all(target_vendor = "fortanix", target_env = "sgx"),
    ))] {
        // obyek wiwitan Rust durasi kang gumantung ing simbol, supaya wong-wong mau umum.
        #[cfg(all(target_os="windows", target_arch = "x86", target_env="gnu"))]
        pub use real_imp::eh_frame_registry::*;
        #[path = "gcc.rs"]
        mod real_imp;
    } else {
        // Target sing ora ndhukung santai.
        // - arch=wasm32
        // - OS=ora ana (target "bare metal")
        // - os=uefi
        // - nvptx64-nvidia-cuda
        // - arch=avr
        #[path = "dummy.rs"]
        mod real_imp;
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        // Gunakake runtime Miri.
        // Kawulo kudu uga mbukak durasi normal ndhuwur, minangka rustc ngarepake item lang tartamtu saka ing kono bakal ditetepake.
        //
        #[path = "miri.rs"]
        mod imp;
    } else {
        // Gunakake durasi nyata.
        use real_imp as imp;
    }
}

extern "C" {
    /// Penangan ing libstd diarani nalika obyek panic diluncurake ing njaba `catch_unwind`.
    ///
    fn __rust_drop_panic() -> !;

    /// Handler ing libstd disebut nalika istiméwa manca disusul.
    fn __rust_foreign_exception() -> !;
}

mod dwarf;

#[rustc_std_internal_symbol]
#[allow(improper_ctypes_definitions)]
pub unsafe extern "C" fn __rust_panic_cleanup(payload: *mut u8) -> *mut (dyn Any + Send + 'static) {
    Box::into_raw(imp::cleanup(payload))
}

// titik entri kanggo mundhakaken pangecualian, mung delegasi kanggo implementasine platform-tartamtu.
//
#[rustc_std_internal_symbol]
#[unwind(allowed)]
pub unsafe extern "C" fn __rust_start_panic(payload: *mut &mut dyn BoxMeUp) -> u32 {
    let payload = Box::from_raw((*payload).take_box());

    imp::panic(payload)
}