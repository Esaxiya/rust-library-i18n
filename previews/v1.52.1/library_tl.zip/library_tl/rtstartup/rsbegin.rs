// rsbegin.o at rsend.o ay ang gayon tinatawag "compiler runtime startup objects".
// naglalaman ang mga ito code na kailangan upang tama initialize ang compiler runtime.
//
// Kapag ang isang maipapatupad o dylib na imahe ay naka-link, ang lahat ng mga code ng gumagamit at aklatan ay "sandwiched" sa pagitan ng dalawang mga file ng object, kaya't ang code o data mula sa rsbegin.o ay naging una sa kani-kanilang mga seksyon ng imahe, samantalang ang code at data mula sa rsend.o ay naging ang huli.
// Ang epektong ito ay maaaring gamitin upang simbolo ng lugar sa simula o sa katapusan ng isang seksyon, pati na rin upang magpasok ng anumang mga kinakailangang mga header o footer.
//
// Tandaan na ang aktwal na module entry point ay matatagpuan sa C runtime startup object (karaniwan ay tinatawag `crtX.o`), na pagkatapos ay invokes initialization callback ng iba pang mga bahagi runtime (nakarehistro sa pamamagitan ng isa pang espesyal na seksyon ng imahe).
//
//
//
//
//
//

#![feature(no_core)]
#![feature(lang_items)]
#![feature(auto_traits)]
#![crate_type = "rlib"]
#![no_core]
#![allow(non_camel_case_types)]

#[lang = "sized"]
trait Sized {}
#[lang = "sync"]
auto trait Sync {}
#[lang = "copy"]
trait Copy {}
#[lang = "freeze"]
auto trait Freeze {}

#[lang = "drop_in_place"]
#[inline]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    drop_in_place(to_drop);
}

#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frames {
    #[no_mangle]
    #[link_section = ".eh_frame"]
    // Minarkahan na nagsisimula ng seksyon ng impormasyon ng stack frame na makapagpahinga
    pub static __EH_FRAME_BEGIN__: [u8; 0] = [];

    // Scratch space para sa panloob na pag-iingat ng libro ng unwinder.
    // Ito ay tinukoy bilang `struct object` sa $ GCC/makalas sa pagkakaikid-dw2-fde.h.
    static mut OBJ: [isize; 6] = [0; 6];

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                impl ::Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    // I-unwind ang mga gawain sa registration/deregistration na impormasyon.
    // Tingnan ang mga dokumento ng libpanic_unwind.
    extern "C" {
        fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8);
        fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8);
    }

    unsafe extern "C" fn init() {
        // magparehistro makalas sa pagkakaikid impormasyon sa module startup
        rust_eh_register_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    unsafe extern "C" fn uninit() {
        // unregister sa pag-shutdown
        rust_eh_unregister_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    // MinGW-specific registration init/uninit routine
    pub mod mingw_init {
        // Ang mga startup na bagay ng MinGW (crt0.o/dllcrt0.o) ay magtatanong ng mga pandaigdigang tagapagbuo sa mga seksyon na .ctors at .dtors sa pagsisimula at paglabas.
        // Sa kaso ng DLLs, ito ay tapos na kapag ang DLL ay ikinarga at diskargado.
        //
        // linker ay-uri-uriin ang mga seksyon, na kung saan ay nagsisigurado na ang aming callback ay matatagpuan sa dulo ng listahan.
        // Dahil ang mga tagapagbuo ay pinapatakbo sa reverse order, tinitiyak nito na ang aming mga callback ay ang una at huling naipatupad.
        //
        //

        #[link_section = ".ctors.65535"] // .ctor. *: Mga callback ng inisyal na C
        pub static P_INIT: unsafe extern "C" fn() = super::init;

        #[link_section = ".dtors.65535"] // .dtors *: . C termination callback
        pub static P_UNINIT: unsafe extern "C" fn() = super::uninit;
    }
}