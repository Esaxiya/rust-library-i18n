# Ang `rustc-std-workspace-core` crate

Ang crate na ito ay isang shim at walang laman na crate na depende lamang sa `libcore` at muling i-export ang lahat ng nilalaman nito.
Ang crate ay ang puno ng empowering ang standard library na nakadepende sa crates mula crates.io

Crates sa crates.io na ang karaniwang silid-aklatan ay nakasalalay sa pangangailangan na depende sa `rustc-std-workspace-core` crate mula sa crates.io, na walang laman.

Ginagamit namin ang `[patch]` upang ma-override ito sa crate na ito sa repository.
Bilang isang resulta, ang crates sa crates.io ay maglalagay ng isang dependency edge sa `libcore`, ang bersyon na tinukoy sa lalagyan na ito.
Dapat na iguhit ang lahat ng mga gilid ng pagtitiwala upang matiyak na matagumpay na nabubuo ng Cargo ang crates!

Tandaan na ang crates sa crates.io ay kailangang umasa sa crate na may pangalang `core` para sa lahat upang gumana nang tama.Upang gawin na maaari nilang gamitin ang:

```toml
core = { version = "1.0.0", optional = true, package = 'rustc-std-workspace-core' }
```

Sa pamamagitan ng paggamit ng `package` key ng crate ay muling pinangalanan sa `core`, ibig sabihin makikita itong parang

```
--extern core=.../librustc_std_workspace_core-XXXXXXX.rlib
```

kapag Cargo invokes ang compiler, nagbibigay-kasiyahan ang mga implicit directive `extern crate core` na binigay ng mga compiler.




