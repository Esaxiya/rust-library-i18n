//! Unwinding panics para sa Miri.
use alloc::boxed::Box;
use core::any::Any;

// Ang uri ng mga kargamento na ang Miri engine propagates sa pamamagitan ng unwinding para sa amin.
// Kailangan ay pointer-sized.
type Payload = Box<Box<dyn Any + Send>>;

extern "Rust" {
    /// Miri-ibinigay ekstern function na upang simulan ang unwinding.
    fn miri_start_panic(payload: *mut u8) -> !;
}

pub unsafe fn panic(payload: Box<dyn Any + Send>) -> u32 {
    // Ang payload pumasa kami sa `miri_start_panic` ay eksakto ang argument makuha namin sa `cleanup` ibaba.
    // Kung kaya't inilalagay lamang natin ito sa isang beses, upang makakuha ng isang bagay na may sukat sa pointer.
    let payload_box: Payload = Box::new(payload);
    miri_start_panic(Box::into_raw(payload_box) as *mut u8)
}

pub unsafe fn cleanup(payload_box: *mut u8) -> Box<dyn Any + Send> {
    // Ibalik muli ang napapailalim `Box`.
    let payload_box: Payload = Box::from_raw(payload_box as *mut _);
    *payload_box
}