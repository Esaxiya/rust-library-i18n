//! Pagpapatupad ng panics sa pamamagitan ng pag-unwind ng stack
//!
//! Ito crate ay isang pagpapatupad ng panics in Rust gamit "most native" stack unwinding mekanismo ng platform na ito ay pinagsama-sama para sa.
//! Mahalagang naiuri ito sa tatlong timba na kasalukuyang:
//!
//! 1. Ang mga target ng MSVC ay gumagamit ng SEH sa `seh.rs` file.
//! 2. Gumagamit si Emscripten ng mga pagbubukod ng C++ sa `emcc.rs` file.
//! 3. Ang lahat ng iba pang mga target gamitin libunwind/libgcc sa `gcc.rs` file.
//!
//! Ang mas maraming dokumentasyon tungkol sa bawat pagpapatupad ay maaaring matagpuan sa kani-kanilang modyul.
//!
//!

#![no_std]
#![unstable(feature = "panic_unwind", issue = "32837")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/"
)]
#![feature(core_intrinsics)]
#![feature(int_bits_const)]
#![feature(lang_items)]
#![feature(nll)]
#![feature(panic_unwind)]
#![feature(staged_api)]
#![feature(std_internals)]
#![feature(unwind_attributes)]
#![feature(abi_thiscall)]
#![feature(rustc_attrs)]
#![feature(raw)]
#![panic_runtime]
#![feature(panic_runtime)]
// `real_imp` ay hindi nagamit sa Miri, kaya babala katahimikan.
#![cfg_attr(miri, allow(dead_code))]

use alloc::boxed::Box;
use core::any::Any;
use core::panic::BoxMeUp;

cfg_if::cfg_if! {
    if #[cfg(target_os = "emscripten")] {
        #[path = "emcc.rs"]
        mod real_imp;
    } else if #[cfg(target_os = "hermit")] {
        #[path = "hermit.rs"]
        mod real_imp;
    } else if #[cfg(target_env = "msvc")] {
        #[path = "seh.rs"]
        mod real_imp;
    } else if #[cfg(any(
        all(target_family = "windows", target_env = "gnu"),
        target_os = "psp",
        target_family = "unix",
        all(target_vendor = "fortanix", target_env = "sgx"),
    ))] {
        // startup bagay Rust runtime ni nakasalalay sa mga simbolong ito, kaya gawin ang mga ito ng publiko.
        #[cfg(all(target_os="windows", target_arch = "x86", target_env="gnu"))]
        pub use real_imp::eh_frame_registry::*;
        #[path = "gcc.rs"]
        mod real_imp;
    } else {
        // Mga target na hindi sumusuporta sa pag-aalis ng unwind.
        // - arch=wasm32
        // - os=wala (mga target na "bare metal")
        // - os=uefi
        // - nvptx64-nvidia-cuda
        // - arch=avr
        #[path = "dummy.rs"]
        mod real_imp;
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        // Gamitin ang Miri runtime.
        // Kailangan pa rin naming i-load ang normal na runtime sa itaas, tulad ng inaasahan ng rustc na ilang mga item lang mula doon na matutukoy.
        //
        #[path = "miri.rs"]
        mod imp;
    } else {
        // Gamitin ang totoong runtime.
        use real_imp as imp;
    }
}

extern "C" {
    /// Handler sa libstd tinatawag na kapag ang isang panic bagay ay bumaba sa labas ng `catch_unwind`.
    ///
    fn __rust_drop_panic() -> !;

    /// Tinawag ang handler sa libstd kapag nahuli ang isang banyagang pagbubukod.
    fn __rust_foreign_exception() -> !;
}

mod dwarf;

#[rustc_std_internal_symbol]
#[allow(improper_ctypes_definitions)]
pub unsafe extern "C" fn __rust_panic_cleanup(payload: *mut u8) -> *mut (dyn Any + Send + 'static) {
    Box::into_raw(imp::cleanup(payload))
}

// Entry point para sa pagtaas ng isang pagbubukod, mga delegado lamang sa pagpapatupad na tukoy sa platform.
//
#[rustc_std_internal_symbol]
#[unwind(allowed)]
pub unsafe extern "C" fn __rust_start_panic(payload: *mut &mut dyn BoxMeUp) -> u32 {
    let payload = Box::from_raw((*payload).take_box());

    imp::panic(payload)
}