//! Utility para sa pag-parse bulilit na-encode ng data stream.
//! Tingnan ang <http://www.dwarfstd.org>, pamantayan ng DWARF-4, Seksyon 7, "Data Representation"
//!

// Ang modyul na ito ay ginagamit lamang ng x86_64-pc-windows-gnu sa ngayon, ngunit pinagsasama namin ito saanman upang maiwasan ang mga pagbabalik.
//
#![allow(unused)]

#[cfg(test)]
mod tests;

pub mod eh;

use core::mem;

pub struct DwarfReader {
    pub ptr: *const u8,
}

#[repr(C, packed)]
struct Unaligned<T>(T);

impl DwarfReader {
    pub fn new(ptr: *const u8) -> DwarfReader {
        DwarfReader { ptr }
    }

    // Naka-pack ang DWARF stream, kaya hal, isang u32 ay hindi kinakailangang nakahanay sa isang 4-byte na hangganan.
    // Maaari itong maging sanhi ng mga problema sa mga platform na may mahigpit na mga kinakailangan sa pagkakahanay.
    // Sa pamamagitan ng pambalot ng data sa isang "packed" struct, sinasabi namin sa backend upang makabuo ng "misalignment-safe" code.
    //
    pub unsafe fn read<T: Copy>(&mut self) -> T {
        let Unaligned(result) = *(self.ptr as *const Unaligned<T>);
        self.ptr = self.ptr.add(mem::size_of::<T>());
        result
    }

    // Ang pag-encode ng ULEB128 at SLEB128 ay tinukoy sa Seksyon 7.6, "Variable Length Data".
    //
    pub unsafe fn read_uleb128(&mut self) -> u64 {
        let mut shift: usize = 0;
        let mut result: u64 = 0;
        let mut byte: u8;
        loop {
            byte = self.read::<u8>();
            result |= ((byte & 0x7F) as u64) << shift;
            shift += 7;
            if byte & 0x80 == 0 {
                break;
            }
        }
        result
    }

    pub unsafe fn read_sleb128(&mut self) -> i64 {
        let mut shift: u32 = 0;
        let mut result: u64 = 0;
        let mut byte: u8;
        loop {
            byte = self.read::<u8>();
            result |= ((byte & 0x7F) as u64) << shift;
            shift += 7;
            if byte & 0x80 == 0 {
                break;
            }
        }
        // sign-extend
        if shift < u64::BITS && (byte & 0x40) != 0 {
            result |= (!0 as u64) << shift;
        }
        result as i64
    }
}