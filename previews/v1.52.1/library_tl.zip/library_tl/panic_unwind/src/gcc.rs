//! Pagpapatupad ng panics sinuportahan ng libgcc/libunwind (sa ilang mga form).
//!
//! Para sa background sa kataliwasan paghawak at stack unwinding pakitingnan ang "Exception Handling in LLVM" (llvm.org/docs/ExceptionHandling.html) at mga dokumento na naka-link mula dito.
//! Ang mga ito ay mahusay ding magbasa:
//!  * <https://itanium-cxx-abi.github.io/cxx-abi/abi-eh.html>
//!  * <http://monoinfinito.wordpress.com/series/exception-handling-in-c/>
//!  * <http://www.airs.com/blog/index.php?s=exception+frames>
//!
//! ## Isang maikling buod
//!
//! Exception paghawak mangyayari sa dalawang phase: ang isang paghahanap phase at isang cleanup phase.
//!
//! Sa parehong mga phase ng unwinder ay nagtuturo sa stack frame mula sa itaas hanggang sa ibaba ng paggamit ng impormasyon mula sa stack frame makalas sa pagkakaikid seksyon ng mga module sa kasalukuyang proseso noon ng ("module" dito ay tumutukoy sa isang module OS, ie, isang executable o isang dynamic na library).
//!
//!
//! Para sa bawat stack frame, inaanyayahan nito ang nauugnay na "personality routine", na ang address ay nakaimbak din sa seksyon ng impormasyon na makapagpahinga
//!
//! Sa phase ng paghahanap, ang trabaho ng isang personalidad na gawain ay upang suriin exception object hagis, at upang magpasya kung ito ay dapat na nahuli sa na stack frame.Kapag nakilala ang frame ng handler, nagsisimula ang yugto ng paglilinis.
//!
//! Sa yugto ng paglilinis, muling pinanghihimok ng muling pag-iwas ang bawat gawain sa pagkatao.
//! Oras na ito ito ay nagpapasya kung saan (kung mayroon man) pangangailangan cleanup code na tumakbo para sa kasalukuyang stack frame.Kung gayon, ang control ay inilipat sa isang espesyal na branch sa ang pag-andar ng katawan, ang "landing pad", na invokes destructors, frees memory, at iba pa
//! Sa pagtatapos ng landing pad, ang kontrol ay inililipat pabalik sa mga hindi kanais-nais na paggalaw at pag-aliw.
//!
//! Kapag ang stack ay na-unsound pababa sa antas ng handler frame, ang pag-aalis ng hintuan at ang huling gawain ng pagkatao ay inililipat ang kontrol sa catch block.
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

use alloc::boxed::Box;
use core::any::Any;

use crate::dwarf::eh::{self, EHAction, EHContext};
use libc::{c_int, uintptr_t};
use unwind as uw;

#[repr(C)]
struct Exception {
    _uwe: uw::_Unwind_Exception,
    cause: Box<dyn Any + Send>,
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    let exception = Box::new(Exception {
        _uwe: uw::_Unwind_Exception {
            exception_class: rust_exception_class(),
            exception_cleanup,
            private: [0; uw::unwinder_private_data_size],
        },
        cause: data,
    });
    let exception_param = Box::into_raw(exception) as *mut uw::_Unwind_Exception;
    return uw::_Unwind_RaiseException(exception_param) as u32;

    extern "C" fn exception_cleanup(
        _unwind_code: uw::_Unwind_Reason_Code,
        exception: *mut uw::_Unwind_Exception,
    ) {
        unsafe {
            let _: Box<Exception> = Box::from_raw(exception as *mut Exception);
            super::__rust_drop_panic();
        }
    }
}

pub unsafe fn cleanup(ptr: *mut u8) -> Box<dyn Any + Send> {
    let exception = ptr as *mut uw::_Unwind_Exception;
    if (*exception).exception_class != rust_exception_class() {
        uw::_Unwind_DeleteException(exception);
        super::__rust_foreign_exception();
    } else {
        let exception = Box::from_raw(exception as *mut Exception);
        exception.cause
    }
}

// exception class identifier ni Rust.
// Ginagamit ito ng mga gawain sa pagkatao upang matukoy kung ang pagbubukod ay itinapon ng kanilang sariling runtime.
fn rust_exception_class() -> uw::_Unwind_Exception_Class {
    // MOZ\0 RUST-vendor, wika
    0x4d4f5a_00_52555354
}

// Ang mga id ng rehistro ay itinaas mula sa LLVM's TargetLowering::getExceptionPointerRegister() at TargetLowering::getExceptionSelectorRegister() para sa bawat arkitektura, pagkatapos ay nai-map sa mga numero ng rehistro ng DWARF sa pamamagitan ng mga talahanayan ng kahulugan ng rehistro (karaniwang<arch>MagrehistroInfo.td, maghanap para sa "DwarfRegNum").
//
// Tingnan din ang http://llvm.org/docs/WritingAnLLVMBackend.html#defining-a-register.
//
//

#[cfg(target_arch = "x86")]
const UNWIND_DATA_REG: (i32, i32) = (0, 2); // EAX, EDX

#[cfg(target_arch = "x86_64")]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // RAX, RDX

#[cfg(any(target_arch = "arm", target_arch = "aarch64"))]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // R0, R1/X0, X1

#[cfg(any(target_arch = "mips", target_arch = "mips64"))]
const UNWIND_DATA_REG: (i32, i32) = (4, 5); // A0, A1

#[cfg(any(target_arch = "powerpc", target_arch = "powerpc64"))]
const UNWIND_DATA_REG: (i32, i32) = (3, 4); // R3, R4/X3, X4

#[cfg(target_arch = "s390x")]
const UNWIND_DATA_REG: (i32, i32) = (6, 7); // R6, R7

#[cfg(any(target_arch = "sparc", target_arch = "sparc64"))]
const UNWIND_DATA_REG: (i32, i32) = (24, 25); // I0, I1

#[cfg(target_arch = "hexagon")]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // R0, R1

#[cfg(any(target_arch = "riscv64", target_arch = "riscv32"))]
const UNWIND_DATA_REG: (i32, i32) = (10, 11); // x10, x11

// Ang sumusunod na code ay batay sa GCC C at C++ pagkatao routines.Para sa sanggunian, tingnan ang:
// https://github.com/gcc-mirror/gcc/blob/master/libstdc++-v3/libsupc++/eh_personality.cc
// https://github.com/gcc-mirror/gcc/blob/trunk/libgcc/unwind-c.c

cfg_if::cfg_if! {
    if #[cfg(all(target_arch = "arm", not(target_os = "ios"), not(target_os = "netbsd")))] {
        // ARM EHABI na gawain sa pagkatao.
        // http://infocenter.arm.com/help/topic/com.arm.doc.ihi0038b/IHI0038B_ehabi.pdf
        //
        // iOS ay gumagamit ng mga default na routine sa halip dahil ito ay gumagamit ng SjLj unwinding.
        #[lang = "eh_personality"]
        unsafe extern "C" fn rust_eh_personality(state: uw::_Unwind_State,
                                                 exception_object: *mut uw::_Unwind_Exception,
                                                 context: *mut uw::_Unwind_Context)
                                                 -> uw::_Unwind_Reason_Code {
            let state = state as c_int;
            let action = state & uw::_US_ACTION_MASK as c_int;
            let search_phase = if action == uw::_US_VIRTUAL_UNWIND_FRAME as c_int {
                // Tatawagan ng mga backtrace sa ARM ang nakagawiang pagkatao kasama ang estado==_US_VIRTUAL_UNWIND_FRAME |_US_FORCE_UNWIND.
                // Sa mga kasong nais namin upang magpatuloy unwinding ang stack, kung hindi man lahat ng aming mga backtraces Gusto magtatapos sa __rust_try
                //
                //
                if state & uw::_US_FORCE_UNWIND as c_int != 0 {
                    return continue_unwind(exception_object, context);
                }
                true
            } else if action == uw::_US_UNWIND_FRAME_STARTING as c_int {
                false
            } else if action == uw::_US_UNWIND_FRAME_RESUME as c_int {
                return continue_unwind(exception_object, context);
            } else {
                return uw::_URC_FAILURE;
            };

            // Ang DWARF unwinder Ipinapalagay na_Unwind_Context humahawak ng mga bagay tulad ng mga function at LSDA payo, gayunpaman ARM EHABI naglalagay ng mga ito sa exception object.
            // Upang mapangalagaan ang mga lagda ng mga pag-andar tulad ng _Unwind_GetLanguageSpecificData(), na kumukuha lamang ng tagaturo ng konteksto, ang mga gawain sa GCC na pagkatao ay nagtatago ng isang pointer sa exception_object sa konteksto, gamit ang lokasyon na nakalaan para sa "scratch register" (r12) ng ARM.
            //
            //
            //
            //
            uw::_Unwind_SetGR(context,
                              uw::UNWIND_POINTER_REG,
                              exception_object as uw::_Unwind_Ptr);
            // ... Ang isang mas may prinsipyo na diskarte ay upang magbigay ng buong kahulugan ng ARM_Unwind_Context sa aming libunwind binding at sunduin ang mga kinakailangang mga data mula doon direkta, bypassing DWARF function compatibility.
            //
            //

            let eh_action = match find_eh_action(context) {
                Ok(action) => action,
                Err(_) => return uw::_URC_FAILURE,
            };
            if search_phase {
                match eh_action {
                    EHAction::None |
                    EHAction::Cleanup(_) => return continue_unwind(exception_object, context),
                    EHAction::Catch(_) => {
                        // EHABI ay nangangailangan ng pagkatao routine i-update ang SP halaga sa barrier cache ng exception object.
                        //
                        (*exception_object).private[5] =
                            uw::_Unwind_GetGR(context, uw::UNWIND_SP_REG);
                        return uw::_URC_HANDLER_FOUND;
                    }
                    EHAction::Terminate => return uw::_URC_FAILURE,
                }
            } else {
                match eh_action {
                    EHAction::None => return continue_unwind(exception_object, context),
                    EHAction::Cleanup(lpad) |
                    EHAction::Catch(lpad) => {
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.0,
                                          exception_object as uintptr_t);
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.1, 0);
                        uw::_Unwind_SetIP(context, lpad);
                        return uw::_URC_INSTALL_CONTEXT;
                    }
                    EHAction::Terminate => return uw::_URC_FAILURE,
                }
            }

            // Sa ARM EHABI ang pagkatao routine ay responsable para sa aktwal na unwinding isang solong stack frame bago bumalik (ARM EHABI Sec.
            // 6.1).
            unsafe fn continue_unwind(exception_object: *mut uw::_Unwind_Exception,
                                      context: *mut uw::_Unwind_Context)
                                      -> uw::_Unwind_Reason_Code {
                if __gnu_unwind_frame(exception_object, context) == uw::_URC_NO_REASON {
                    uw::_URC_CONTINUE_UNWIND
                } else {
                    uw::_URC_FAILURE
                }
            }
            // tinukoy sa libgcc
            extern "C" {
                fn __gnu_unwind_frame(exception_object: *mut uw::_Unwind_Exception,
                                      context: *mut uw::_Unwind_Context)
                                      -> uw::_Unwind_Reason_Code;
            }
        }
    } else {
        // Default na gawain sa pagkatao, na direktang ginagamit sa karamihan ng mga target at hindi direkta sa Windows x86_64 sa pamamagitan ng SEH.
        //
        unsafe extern "C" fn rust_eh_personality_impl(version: c_int,
                                                      actions: uw::_Unwind_Action,
                                                      _exception_class: uw::_Unwind_Exception_Class,
                                                      exception_object: *mut uw::_Unwind_Exception,
                                                      context: *mut uw::_Unwind_Context)
                                                      -> uw::_Unwind_Reason_Code {
            if version != 1 {
                return uw::_URC_FATAL_PHASE1_ERROR;
            }
            let eh_action = match find_eh_action(context) {
                Ok(action) => action,
                Err(_) => return uw::_URC_FATAL_PHASE1_ERROR,
            };
            if actions as i32 & uw::_UA_SEARCH_PHASE as i32 != 0 {
                match eh_action {
                    EHAction::None |
                    EHAction::Cleanup(_) => uw::_URC_CONTINUE_UNWIND,
                    EHAction::Catch(_) => uw::_URC_HANDLER_FOUND,
                    EHAction::Terminate => uw::_URC_FATAL_PHASE1_ERROR,
                }
            } else {
                match eh_action {
                    EHAction::None => uw::_URC_CONTINUE_UNWIND,
                    EHAction::Cleanup(lpad) |
                    EHAction::Catch(lpad) => {
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.0,
                            exception_object as uintptr_t);
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.1, 0);
                        uw::_Unwind_SetIP(context, lpad);
                        uw::_URC_INSTALL_CONTEXT
                    }
                    EHAction::Terminate => uw::_URC_FATAL_PHASE2_ERROR,
                }
            }
        }

        cfg_if::cfg_if! {
            if #[cfg(all(windows, target_arch = "x86_64", target_env = "gnu"))] {
                // Sa mga target na x86_64 MinGW, ang mekanismo ng pag-unwind ay SEH gayunpaman ang data ng paghawak ng handler (aka LSDA) ay gumagamit ng pag-encode ng GCC na katugma.
                //
                #[lang = "eh_personality"]
                #[allow(nonstandard_style)]
                unsafe extern "C" fn rust_eh_personality(exceptionRecord: *mut uw::EXCEPTION_RECORD,
                        establisherFrame: uw::LPVOID,
                        contextRecord: *mut uw::CONTEXT,
                        dispatcherContext: *mut uw::DISPATCHER_CONTEXT)
                        -> uw::EXCEPTION_DISPOSITION {
                    uw::_GCC_specific_handler(exceptionRecord,
                                             establisherFrame,
                                             contextRecord,
                                             dispatcherContext,
                                             rust_eh_personality_impl)
                }
            } else {
                // Ang gawain sa pagkatao para sa karamihan ng aming mga target.
                #[lang = "eh_personality"]
                unsafe extern "C" fn rust_eh_personality(version: c_int,
                        actions: uw::_Unwind_Action,
                        exception_class: uw::_Unwind_Exception_Class,
                        exception_object: *mut uw::_Unwind_Exception,
                        context: *mut uw::_Unwind_Context)
                        -> uw::_Unwind_Reason_Code {
                    rust_eh_personality_impl(version,
                                             actions,
                                             exception_class,
                                             exception_object,
                                             context)
                }
            }
        }
    }
}

unsafe fn find_eh_action(context: *mut uw::_Unwind_Context) -> Result<EHAction, ()> {
    let lsda = uw::_Unwind_GetLanguageSpecificData(context) as *const u8;
    let mut ip_before_instr: c_int = 0;
    let ip = uw::_Unwind_GetIPInfo(context, &mut ip_before_instr);
    let eh_context = EHContext {
        // Ang return address tumuturo 1 byte nakalipas na ang tawag pagtuturo, na maaaring maging sa susunod na hanay IP sa LSDA hanay table.
        //
        ip: if ip_before_instr != 0 { ip } else { ip - 1 },
        func_start: uw::_Unwind_GetRegionStart(context),
        get_text_start: &|| uw::_Unwind_GetTextRelBase(context),
        get_data_start: &|| uw::_Unwind_GetDataRelBase(context),
    };
    eh::find_eh_action(lsda, &eh_context)
}

// Pagrerehistro ng impormasyon sa frame
//
// Naglalaman ang imahe ng bawat module ng seksyon ng impormasyon na nag-unwind ng frame (karaniwang ".eh_frame").Kapag ang isang module ay loaded/unloaded sa proseso, ang pag-iwas ay dapat na ipagbigay-alam tungkol sa lokasyon ng seksyon na ito sa memorya.Ang mga paraan ng pagkamit na nag-iiba sa pamamagitan ng platform.
// Sa ilang (hal., Linux), ang undinder ay maaaring makatuklas ng mga seksyon ng impormasyon ng pag-iwas sa sarili nitong (sa pamamagitan ng pag-enumerate ng kasalukuyang naka-load na mga module sa pamamagitan ng dl_iterate_phdr() API and finding their ".eh_frame" sections); Ang iba, tulad ng Windows, ay nangangailangan ng mga modyul upang aktibong irehistro ang kanilang mga seksyon ng impormasyon sa pag-unwind sa pamamagitan ng unwinder API.
//
//
// Tinutukoy ng modyul na ito ang dalawang mga simbolo na isinangguni at tinawag mula sa rsbegin.rs upang irehistro ang aming impormasyon sa runtime ng GCC.
// Ang pagpapatupad ng stack ng pag-unwind ay (sa ngayon) ipinagpaliban sa libgcc_eh, subalit ang Rust crates ay gumagamit ng mga puntong Rust na tukoy na puntong ito upang maiwasan ang mga potensyal na sagupaan sa anumang runtime ng GCC.
//
//
//
//
//
//
//
//
#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frame_registry {
    extern "C" {
        fn __register_frame_info(eh_frame_begin: *const u8, object: *mut u8);
        fn __deregister_frame_info(eh_frame_begin: *const u8, object: *mut u8);
    }

    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8) {
        __register_frame_info(eh_frame_begin, object);
    }

    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8) {
        __deregister_frame_info(eh_frame_begin, object);
    }
}