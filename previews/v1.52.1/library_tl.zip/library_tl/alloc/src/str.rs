//! Mag-unicode ng mga hiwa ng string.
//!
//! *[See also the `str` primitive type](str).*
//!
//! Ang uri ng `&str` ay isa sa dalawang pangunahing uri ng string, ang isa ay `String`.
//! Hindi tulad ng kanyang `String` kamukhang-mukha, ang mga nilalaman nito ay hiniram.
//!
//! # Pangunahing Paggamit
//!
//! Isang pangunahing deklarasyon ng string ng uri ng `&str`:
//!
//! ```
//! let hello_world = "Hello, World!";
//! ```
//!
//! Dineklara namin ang isang literal na string, na kilala rin bilang isang hiwa ng string.
//! Ang mga string literals ay may isang static habang buhay, na nangangahulugang ang string `hello_world` ay ginagarantiyahan na maging wasto para sa tagal ng buong programa.
//!
//! Maaari naming malinaw na tukuyin ang buhay ng `hello_world` pati na rin:
//!
//! ```
//! let hello_world: &'static str = "Hello, world!";
//! ```

#![stable(feature = "rust1", since = "1.0.0")]
// Marami sa mga ginagamit sa modyul na ito ay ginagamit lamang sa pagsasaayos ng pagsubok.
// Mas malinis na patayin lamang ang hindi nagamit na_imports na babala kaysa upang ayusin ang mga ito.
#![allow(unused_imports)]

use core::borrow::{Borrow, BorrowMut};
use core::iter::FusedIterator;
use core::mem;
use core::ptr;
use core::str::pattern::{DoubleEndedSearcher, Pattern, ReverseSearcher, Searcher};
use core::unicode::conversions;

use crate::borrow::ToOwned;
use crate::boxed::Box;
use crate::slice::{Concat, Join, SliceIndex};
use crate::string::String;
use crate::vec::Vec;

#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::pattern;
#[stable(feature = "encode_utf16", since = "1.8.0")]
pub use core::str::EncodeUtf16;
#[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
pub use core::str::SplitAsciiWhitespace;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::SplitWhitespace;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{from_utf8, from_utf8_mut, Bytes, CharIndices, Chars};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{from_utf8_unchecked, from_utf8_unchecked_mut, ParseBoolError};
#[stable(feature = "str_escape", since = "1.34.0")]
pub use core::str::{EscapeDebug, EscapeDefault, EscapeUnicode};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{FromStr, Utf8Error};
#[allow(deprecated)]
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{Lines, LinesAny};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{MatchIndices, RMatchIndices};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{Matches, RMatches};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{RSplit, Split};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{RSplitN, SplitN};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{RSplitTerminator, SplitTerminator};

/// Note: Ang `str` sa `Concat<str>` ay hindi makahulugan dito.
/// Ang uri ng parameter na ito ng trait ay mayroon lamang upang paganahin ang isa pang impl.
#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<S: Borrow<str>> Concat<str> for [S] {
    type Output = String;

    fn concat(slice: &Self) -> String {
        Join::join(slice, "")
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<S: Borrow<str>> Join<&str> for [S] {
    type Output = String;

    fn join(slice: &Self, sep: &str) -> String {
        unsafe { String::from_utf8_unchecked(join_generic_copy(slice, sep.as_bytes())) }
    }
}

macro_rules! specialize_for_lengths {
    ($separator:expr, $target:expr, $iter:expr; $($num:expr),*) => {{
        let mut target = $target;
        let iter = $iter;
        let sep_bytes = $separator;
        match $separator.len() {
            $(
                // ang mga loop na may hardcoded na laki ay nagpapatakbo ng mas mabilis na dalubhasa ang mga kaso na may maliit na haba ng paghihiwalay
                //
                $num => {
                    for s in iter {
                        copy_slice_and_advance!(target, sep_bytes);
                        let content_bytes = s.borrow().as_ref();
                        copy_slice_and_advance!(target, content_bytes);
                    }
                },
            )*
            _ => {
                // di-makatwirang fallback ng laki na hindi zero
                for s in iter {
                    copy_slice_and_advance!(target, sep_bytes);
                    let content_bytes = s.borrow().as_ref();
                    copy_slice_and_advance!(target, content_bytes);
                }
            }
        }
        target
    }}
}

macro_rules! copy_slice_and_advance {
    ($target:expr, $bytes:expr) => {
        let len = $bytes.len();
        let (head, tail) = { $target }.split_at_mut(len);
        head.copy_from_slice($bytes);
        $target = tail;
    };
}

// Na-optimize na pagsali sa pagsali na gumagana para sa parehong Vec<T>(T: Kopyahin) at panloob na mga vector ng String Sa kasalukuyan (2018-05-13) mayroong isang bug na may uri ng paghihinuha at pagdadalubhasa (tingnan ang isyu #36262) Para sa kadahilanang ito SliceConcat<T>ay hindi dalubhasa para sa T: Copy at SliceConcat<str>ay ang nag-iisang gumagamit ng pagpapaandar na ito.
// Naiiwan ito sa lugar para sa oras kung kailan naayos iyon.
//
// ang hangganan para sa String-join ay S: Pahiram<str>at para sa Vec-join Borrow <[T]> [T] at str parehong impl AsRef <[T]> para sa ilang T
// => s.borrow().as_ref() at palagi kaming may hiwa
//
//
//
fn join_generic_copy<B, T, S>(slice: &[S], sep: &[T]) -> Vec<T>
where
    T: Copy,
    B: AsRef<[T]> + ?Sized,
    S: Borrow<B>,
{
    let sep_len = sep.len();
    let mut iter = slice.iter();

    // ang unang slice ay ang isa lamang na walang isang separator sinusundang
    let first = match iter.next() {
        Some(first) => first,
        None => return vec![],
    };

    // kalkulahin ang eksaktong kabuuang haba ng sumali na Vec kung umaapaw ang pagkalkula ng `len`, magkakaroon kami ng panic na maubusan pa rin kami ng memorya at ang natitirang pag-andar ay nangangailangan ng buong Vec na paunang inilalaan para sa kaligtasan
    //
    //
    //
    let reserved_len = sep_len
        .checked_mul(iter.len())
        .and_then(|n| {
            slice.iter().map(|s| s.borrow().as_ref().len()).try_fold(n, usize::checked_add)
        })
        .expect("attempt to join into collection with len > usize::MAX");

    // maghanda ng isang uninitialized buffer
    let mut result = Vec::with_capacity(reserved_len);
    debug_assert!(result.capacity() >= reserved_len);

    result.extend_from_slice(first.borrow().as_ref());

    unsafe {
        let pos = result.len();
        let target = result.get_unchecked_mut(pos..reserved_len);

        // kopyahin ang separator at hiwa ng higit nang walang hangganan ng mga tseke na makabuo ng mga loop na may hardcoded offset para sa maliit na separators napakalaking pagpapabuti posible (~ x2)
        //
        //
        let remain = specialize_for_lengths!(sep, target, iter; 0, 1, 2, 3, 4);

        // A weird humiram pagpapatupad maaaring bumalik iba't ibang mga hiwa para sa mga pagkalkula haba at ang aktwal na kopya.
        //
        // Siguraduhin na hindi namin ilalantad ang mga hindi pa nakikilalang byte sa tumatawag.
        let result_len = reserved_len - remain.len();
        result.set_len(result_len);
    }
    result
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Borrow<str> for String {
    #[inline]
    fn borrow(&self) -> &str {
        &self[..]
    }
}

#[stable(feature = "string_borrow_mut", since = "1.36.0")]
impl BorrowMut<str> for String {
    #[inline]
    fn borrow_mut(&mut self) -> &mut str {
        &mut self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ToOwned for str {
    type Owned = String;
    #[inline]
    fn to_owned(&self) -> String {
        unsafe { String::from_utf8_unchecked(self.as_bytes().to_owned()) }
    }

    fn clone_into(&self, target: &mut String) {
        let mut b = mem::take(target).into_bytes();
        self.as_bytes().clone_into(&mut b);
        *target = unsafe { String::from_utf8_unchecked(b) }
    }
}

/// Mga pamamaraan para sa mga hiwa ng string.
#[lang = "str_alloc"]
#[cfg(not(test))]
impl str {
    /// Binabago ang isang `Box<str>` sa isang `Box<[u8]>` nang hindi kinopya o naglalaan.
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// let s = "this is a string";
    /// let boxed_str = s.to_owned().into_boxed_str();
    /// let boxed_bytes = boxed_str.into_boxed_bytes();
    /// assert_eq!(*boxed_bytes, *s.as_bytes());
    /// ```
    #[stable(feature = "str_box_extras", since = "1.20.0")]
    #[inline]
    pub fn into_boxed_bytes(self: Box<str>) -> Box<[u8]> {
        self.into()
    }

    /// Pinapalitan ang lahat ng mga tugma ng isang pattern sa ibang string.
    ///
    /// `replace` lumilikha ng isang bagong [`String`], at kinopya ang data mula sa hiwa ng string dito.
    /// Habang ginagawa ito, nagtatangka itong makahanap ng mga tugma ng isang pattern.
    /// Kung nakakita ito ng anumang, pinalitan nito ang mga ito ng kapalit na hiwa ng string.
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// let s = "this is old";
    ///
    /// assert_eq!("this is new", s.replace("old", "new"));
    /// ```
    ///
    /// Kapag hindi tumutugma ang pattern:
    ///
    /// ```
    /// let s = "this is old";
    /// assert_eq!(s, s.replace("cookie monster", "little lamb"));
    /// ```
    #[must_use = "this returns the replaced string as a new allocation, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn replace<'a, P: Pattern<'a>>(&'a self, from: P, to: &str) -> String {
        let mut result = String::new();
        let mut last_end = 0;
        for (start, part) in self.match_indices(from) {
            result.push_str(unsafe { self.get_unchecked(last_end..start) });
            result.push_str(to);
            last_end = start + part.len();
        }
        result.push_str(unsafe { self.get_unchecked(last_end..self.len()) });
        result
    }

    /// Pinapalitan ang unang mga tugma ng N sa isang pattern sa ibang string.
    ///
    /// `replacen` lumilikha ng isang bagong [`String`], at kinopya ang data mula sa hiwa ng string dito.
    /// Habang ginagawa ito, nagtatangka itong makahanap ng mga tugma ng isang pattern.
    /// Kung nakakahanap ito ng anumang, pinalitan nito ang mga ito ng kapalit na hiwa ng string na halos `count` beses.
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// let s = "foo foo 123 foo";
    /// assert_eq!("new new 123 foo", s.replacen("foo", "new", 2));
    /// assert_eq!("faa fao 123 foo", s.replacen('o', "a", 3));
    /// assert_eq!("foo foo new23 foo", s.replacen(char::is_numeric, "new", 1));
    /// ```
    ///
    /// Kapag hindi tumutugma ang pattern:
    ///
    /// ```
    /// let s = "this is old";
    /// assert_eq!(s, s.replacen("cookie monster", "little lamb", 10));
    /// ```
    #[must_use = "this returns the replaced string as a new allocation, \
                  without modifying the original"]
    #[stable(feature = "str_replacen", since = "1.16.0")]
    pub fn replacen<'a, P: Pattern<'a>>(&'a self, pat: P, to: &str, count: usize) -> String {
        // Inaasahan na mabawasan ang mga oras ng muling paglalaan
        let mut result = String::with_capacity(32);
        let mut last_end = 0;
        for (start, part) in self.match_indices(pat).take(count) {
            result.push_str(unsafe { self.get_unchecked(last_end..start) });
            result.push_str(to);
            last_end = start + part.len();
        }
        result.push_str(unsafe { self.get_unchecked(last_end..self.len()) });
        result
    }

    /// Ibinabalik ang maliit na maliit na katumbas ng hiwa ng string na ito, bilang isang bagong [`String`].
    ///
    /// 'Lowercase' ay tinukoy alinsunod sa mga tuntunin ng Unicode Derived Core Property `Lowercase`.
    ///
    /// Dahil ang ilang mga character ay maaaring mapalawak sa maraming mga character kapag binabago ang kaso, ang pagpapaandar na ito ay nagbabalik ng isang [`String`] sa halip na baguhin ang parameter sa lugar.
    ///
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// let s = "HELLO";
    ///
    /// assert_eq!("hello", s.to_lowercase());
    /// ```
    ///
    /// Isang nakakalito na halimbawa, na may sigma:
    ///
    /// ```
    /// let sigma = "Σ";
    ///
    /// assert_eq!("σ", sigma.to_lowercase());
    ///
    /// // ngunit sa pagtatapos ng isang salita, ito ay ς, hindi σ:
    /// let odysseus = "ὈΔΥΣΣΕΎΣ";
    ///
    /// assert_eq!("ὀδυσσεύς", odysseus.to_lowercase());
    /// ```
    ///
    /// Ang mga wikang walang kaso ay hindi binago:
    ///
    /// ```
    /// let new_year = "农历新年";
    ///
    /// assert_eq!(new_year, new_year.to_lowercase());
    /// ```
    ///
    ///
    #[stable(feature = "unicode_case_mapping", since = "1.2.0")]
    pub fn to_lowercase(&self) -> String {
        let mut s = String::with_capacity(self.len());
        for (i, c) in self[..].char_indices() {
            if c == 'Σ' {
                // Σ mga mapa sa σ, maliban sa dulo ng isang salita kung saan ito naka-map sa ς.
                // Ito ang nag-iisang kondisyong (contextual) ngunit malayang pagma-map sa wika sa `SpecialCasing.txt`, kaya't hard-code ito sa halip na magkaroon ng isang generic na "condition" na mekanismo.
                //
                // See https://github.com/rust-lang/rust/issues/26035
                //
                map_uppercase_sigma(self, i, &mut s)
            } else {
                match conversions::to_lower(c) {
                    [a, '\0', _] => s.push(a),
                    [a, b, '\0'] => {
                        s.push(a);
                        s.push(b);
                    }
                    [a, b, c] => {
                        s.push(a);
                        s.push(b);
                        s.push(c);
                    }
                }
            }
        }
        return s;

        fn map_uppercase_sigma(from: &str, i: usize, to: &mut String) {
            // See http://www.unicode.org/versions/Unicode7.0.0/ch03.pdf#G33992
            // para sa kahulugan ng `Final_Sigma`.
            debug_assert!('Σ'.len_utf8() == 2);
            let is_word_final = case_ignoreable_then_cased(from[..i].chars().rev())
                && !case_ignoreable_then_cased(from[i + 2..].chars());
            to.push_str(if is_word_final { "ς" } else { "σ" });
        }

        fn case_ignoreable_then_cased<I: Iterator<Item = char>>(iter: I) -> bool {
            use core::unicode::{Case_Ignorable, Cased};
            match iter.skip_while(|&c| Case_Ignorable(c)).next() {
                Some(c) => Cased(c),
                None => false,
            }
        }
    }

    /// Ibinabalik ang uppercase na katumbas ng hiwa ng string na ito, bilang isang bagong [`String`].
    ///
    /// 'Uppercase' ay tinukoy alinsunod sa mga tuntunin ng Unicode Derived Core Property `Uppercase`.
    ///
    /// Dahil ang ilang mga character ay maaaring mapalawak sa maraming mga character kapag binabago ang kaso, ang pagpapaandar na ito ay nagbabalik ng isang [`String`] sa halip na baguhin ang parameter sa lugar.
    ///
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// let s = "hello";
    ///
    /// assert_eq!("HELLO", s.to_uppercase());
    /// ```
    ///
    /// Ang mga script nang walang kaso ay hindi binago:
    ///
    /// ```
    /// let new_year = "农历新年";
    ///
    /// assert_eq!(new_year, new_year.to_uppercase());
    /// ```
    ///
    /// Ang isang character ay maaaring maging maramihang:
    ///
    /// ```
    /// let s = "tschüß";
    ///
    /// assert_eq!("TSCHÜSS", s.to_uppercase());
    /// ```
    ///
    #[stable(feature = "unicode_case_mapping", since = "1.2.0")]
    pub fn to_uppercase(&self) -> String {
        let mut s = String::with_capacity(self.len());
        for c in self[..].chars() {
            match conversions::to_upper(c) {
                [a, '\0', _] => s.push(a),
                [a, b, '\0'] => {
                    s.push(a);
                    s.push(b);
                }
                [a, b, c] => {
                    s.push(a);
                    s.push(b);
                    s.push(c);
                }
            }
        }
        s
    }

    /// Binabago ang isang [`Box<str>`] sa isang [`String`] nang hindi kinopya o naglalaan.
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// let string = String::from("birthday gift");
    /// let boxed_str = string.clone().into_boxed_str();
    ///
    /// assert_eq!(boxed_str.into_string(), string);
    /// ```
    #[stable(feature = "box_str", since = "1.4.0")]
    #[inline]
    pub fn into_string(self: Box<str>) -> String {
        let slice = Box::<[u8]>::from(self);
        unsafe { String::from_utf8_unchecked(slice.into_vec()) }
    }

    /// Lumilikha ng isang bagong [`String`] sa pamamagitan ng pag-ulit ng isang string `n` beses.
    ///
    /// # Panics
    ///
    /// Ang pagpapaandar na ito ay panic kung ang kapasidad ay mag-overflow.
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// assert_eq!("abc".repeat(4), String::from("abcabcabcabc"));
    /// ```
    ///
    /// Isang panic sa pag-apaw:
    ///
    /// ```should_panic
    /// // this will panic at runtime
    /// "0123456789abcdef".repeat(usize::MAX);
    /// ```
    #[stable(feature = "repeat_str", since = "1.16.0")]
    pub fn repeat(&self, n: usize) -> String {
        unsafe { String::from_utf8_unchecked(self.as_bytes().repeat(n)) }
    }

    /// Nagbabalik ng isang kopya ng string na ito kung saan ang bawat character ay nai-map sa kanyang katumbas na ASCII sa itaas na kaso.
    ///
    ///
    /// Ang mga titik ng ASCII 'a' hanggang 'z' ay nai-map sa 'A' hanggang 'Z', ngunit ang mga hindi ASCII na titik ay hindi nagbabago.
    ///
    /// Upang mai-uppercase ang in-place na halaga, gamitin ang [`make_ascii_uppercase`].
    ///
    /// Upang itaas ang mga character na ASCII bilang karagdagan sa mga hindi ASCII na character, gamitin ang [`to_uppercase`].
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Grüße, Jürgen ❤";
    ///
    /// assert_eq!("GRüßE, JüRGEN ❤", s.to_ascii_uppercase());
    /// ```
    ///
    /// [`make_ascii_uppercase`]: str::make_ascii_uppercase
    /// [`to_uppercase`]: #method.to_uppercase
    ///
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_uppercase(&self) -> String {
        let mut bytes = self.as_bytes().to_vec();
        bytes.make_ascii_uppercase();
        // make_ascii_uppercase() nagpapanatili ng UTF-8 invariant.
        unsafe { String::from_utf8_unchecked(bytes) }
    }

    /// Nagbabalik ng isang kopya ng string na ito kung saan ang bawat character ay nai-map sa kanyang ASCII na mas mababang katumbas na kaso.
    ///
    ///
    /// ASCII titik 'A' na 'Z' ay nama-map sa 'a' na 'z', ngunit hindi ASCII mga titik ay hindi magbabago.
    ///
    /// Upang maliitin ang in-place na halaga, gamitin ang [`make_ascii_lowercase`].
    ///
    /// Upang maliliit ang mga character na ASCII bilang karagdagan sa mga character na hindi ASCII, gamitin ang [`to_lowercase`].
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Grüße, Jürgen ❤";
    ///
    /// assert_eq!("grüße, jürgen ❤", s.to_ascii_lowercase());
    /// ```
    ///
    /// [`make_ascii_lowercase`]: str::make_ascii_lowercase
    /// [`to_lowercase`]: #method.to_lowercase
    ///
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_lowercase(&self) -> String {
        let mut bytes = self.as_bytes().to_vec();
        bytes.make_ascii_lowercase();
        // make_ascii_lowercase() nagpapanatili ng UTF-8 invariant.
        unsafe { String::from_utf8_unchecked(bytes) }
    }
}

/// Nagko-convert ng isang box na hiwa ng mga byte sa isang box na hiwa ng string nang hindi sinusuri na ang string ay naglalaman ng wastong UTF-8.
///
///
/// # Examples
///
/// Pangunahing paggamit:
///
/// ```
/// let smile_utf8 = Box::new([226, 152, 186]);
/// let smile = unsafe { std::str::from_boxed_utf8_unchecked(smile_utf8) };
///
/// assert_eq!("☺", &*smile);
/// ```
#[stable(feature = "str_box_extras", since = "1.20.0")]
#[inline]
pub unsafe fn from_boxed_utf8_unchecked(v: Box<[u8]>) -> Box<str> {
    unsafe { Box::from_raw(Box::into_raw(v) as *mut str) }
}