//! Isang pagtingin na kasing-lakas sa isang magkadikit na pagkakasunud-sunod, `[T]`.
//!
//! *[See also the slice primitive type](slice).*
//!
//! Ang mga hiwa ay isang pagtingin sa isang bloke ng memorya na kinakatawan bilang isang pointer at isang haba.
//!
//! ```
//! // paghihiwa ng isang Vec
//! let vec = vec![1, 2, 3];
//! let int_slice = &vec[..];
//! // pinipilit ang isang array sa isang hiwa
//! let str_slice: &[&str] = &["one", "two", "three"];
//! ```
//!
//! Ang mga hiwa ay maaaring nabago o naibahagi.
//! Ang ibinahaging uri ng hiwa ay `&[T]`, habang ang nababagong uri ng hiwa ay `&mut [T]`, kung saan ang `T` ay kumakatawan sa uri ng elemento.
//! Halimbawa, maaari mong i-mutate ang bloke ng memorya na itinuturo ng isang nababagabag na hiwa sa:
//!
//! ```
//! let x = &mut [1, 2, 3];
//! x[1] = 7;
//! assert_eq!(x, &[1, 7, 3]);
//! ```
//!
//! Narito ang ilan sa mga bagay na naglalaman ng modyul na ito:
//!
//! ## Structs
//!
//! Mayroong maraming mga struct na kapaki-pakinabang para sa mga hiwa, tulad ng [`Iter`], na kumakatawan sa pag-ulit sa isang slice.
//!
//! ## Mga Pagpapatupad ng Trait
//!
//! Mayroong maraming mga pagpapatupad ng karaniwang traits para sa mga hiwa.Ang ilang mga halimbawa ay kinabibilangan ng:
//!
//! * [`Clone`]
//! * [`Eq`], [`Ord`], para sa mga hiwa na ang uri ng elemento ay [`Eq`] o [`Ord`].
//! * [`Hash`] - para sa mga hiwa na ang uri ng elemento ay [`Hash`].
//!
//! ## Iteration
//!
//! Ang mga hiwa ay nagpapatupad ng `IntoIterator`.Nagbibigay ang iterator ng mga sanggunian sa mga elemento ng slice.
//!
//! ```
//! let numbers = &[0, 1, 2];
//! for n in numbers {
//!     println!("{} is a number!", n);
//! }
//! ```
//!
//! Ang nababagabag na hiwa ay nagbubunga ng mga nababagong sanggunian sa mga elemento:
//!
//! ```
//! let mut scores = [7, 8, 9];
//! for score in &mut scores[..] {
//!     *score += 1;
//! }
//! ```
//!
//! Nagbibigay ang iterator na ito ng mga nababagong sanggunian sa mga elemento ng hiwa, kaya't habang ang uri ng elemento ng hiwa ay `i32`, ang uri ng elemento ng iterator ay `&mut i32`.
//!
//!
//! * [`.iter`] at [`.iter_mut`] ang mga tahasang pamamaraan upang maibalik ang mga default na iterator.
//! * Ang mga karagdagang pamamaraan na nagbabalik ng mga iterator ay [`.split`], [`.splitn`], [`.chunks`], [`.windows`] at marami pa.
//!
//! [`Hash`]: core::hash::Hash
//! [`.iter`]: slice::iter
//! [`.iter_mut`]: slice::iter_mut
//! [`.split`]: slice::split
//! [`.splitn`]: slice::splitn
//! [`.chunks`]: slice::chunks
//! [`.windows`]: slice::windows
//!
//!
//!
//!
//!
//!
//!
//!
#![stable(feature = "rust1", since = "1.0.0")]
// Marami sa mga ginagamit sa modyul na ito ay ginagamit lamang sa pagsasaayos ng pagsubok.
// Mas malinis na patayin lamang ang hindi nagamit na_imports na babala kaysa upang ayusin ang mga ito.
#![cfg_attr(test, allow(unused_imports, dead_code))]

use core::borrow::{Borrow, BorrowMut};
use core::cmp::Ordering::{self, Less};
use core::mem::{self, size_of};
use core::ptr;

use crate::alloc::{Allocator, Global};
use crate::borrow::ToOwned;
use crate::boxed::Box;
use crate::vec::Vec;

#[unstable(feature = "slice_range", issue = "76393")]
pub use core::slice::range;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunks;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunksMut;
#[unstable(feature = "array_windows", issue = "75027")]
pub use core::slice::ArrayWindows;
#[stable(feature = "slice_get_slice", since = "1.28.0")]
pub use core::slice::SliceIndex;
#[stable(feature = "from_ref", since = "1.28.0")]
pub use core::slice::{from_mut, from_ref};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{from_raw_parts, from_raw_parts_mut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Chunks, Windows};
#[stable(feature = "chunks_exact", since = "1.31.0")]
pub use core::slice::{ChunksExact, ChunksExactMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{ChunksMut, Split, SplitMut};
#[unstable(feature = "slice_group_by", issue = "80552")]
pub use core::slice::{GroupBy, GroupByMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Iter, IterMut};
#[stable(feature = "rchunks", since = "1.31.0")]
pub use core::slice::{RChunks, RChunksExact, RChunksExactMut, RChunksMut};
#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub use core::slice::{RSplit, RSplitMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{RSplitN, RSplitNMut, SplitN, SplitNMut};

////////////////////////////////////////////////////////////////////////////////
// Pangunahing pamamaraan ng extension ng hiwa
////////////////////////////////////////////////////////////////////////////////

// HACK(japaric) kinakailangan para sa pagpapatupad ng `vec!` macro habang sinusubukan ang NB, tingnan ang `hack` module sa file na ito para sa higit pang mga detalye.
//
#[cfg(test)]
pub use hack::into_vec;

// HACK(japaric) kinakailangan para sa pagpapatupad ng `Vec::clone` habang sinusubukan ang NB, tingnan ang `hack` module sa file na ito para sa higit pang mga detalye.
//
#[cfg(test)]
pub use hack::to_vec;

// HACK(japaric): Sa cfg(test) `impl [T]` ay hindi magagamit, ang tatlong mga pagpapaandar na ito ay talagang pamamaraan na nasa `impl [T]` ngunit hindi sa `core::slice::SliceExt`, kailangan nating ibigay ang mga pagpapaandar na ito para sa `test_permutations` test
//
//
//
mod hack {
    use core::alloc::Allocator;

    use crate::boxed::Box;
    use crate::vec::Vec;

    // Hindi namin dapat idagdag ang inline na katangian dito dahil ginagamit ito sa `vec!` macro karamihan at sanhi ng pagbabalik ng perf.
    // Tingnan ang #71204 para sa talakayan at mga resulta ng perf.
    //
    pub fn into_vec<T, A: Allocator>(b: Box<[T], A>) -> Vec<T, A> {
        unsafe {
            let len = b.len();
            let (b, alloc) = Box::into_raw_with_allocator(b);
            Vec::from_raw_parts_in(b as *mut T, len, len, alloc)
        }
    }

    #[inline]
    pub fn to_vec<T: ConvertVec, A: Allocator>(s: &[T], alloc: A) -> Vec<T, A> {
        T::to_vec(s, alloc)
    }

    pub trait ConvertVec {
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A>
        where
            Self: Sized;
    }

    impl<T: Clone> ConvertVec for T {
        #[inline]
        default fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            struct DropGuard<'a, T, A: Allocator> {
                vec: &'a mut Vec<T, A>,
                num_init: usize,
            }
            impl<'a, T, A: Allocator> Drop for DropGuard<'a, T, A> {
                #[inline]
                fn drop(&mut self) {
                    // SAFETY:
                    // ang mga item ay minarkahan na inisyal sa loop sa ibaba
                    unsafe {
                        self.vec.set_len(self.num_init);
                    }
                }
            }
            let mut vec = Vec::with_capacity_in(s.len(), alloc);
            let mut guard = DropGuard { vec: &mut vec, num_init: 0 };
            let slots = guard.vec.spare_capacity_mut();
            // .take(slots.len()) ay kinakailangan para sa LLVM upang alisin ang mga hangganan ng tseke at may mas mahusay na codegen kaysa sa zip.
            //
            for (i, b) in s.iter().enumerate().take(slots.len()) {
                guard.num_init = i;
                slots[i].write(b.clone());
            }
            core::mem::forget(guard);
            // SAFETY:
            // ang mga vector ay inilalaan at isinugod sa itaas ng hindi bababa sa haba na ito.
            unsafe {
                vec.set_len(s.len());
            }
            vec
        }
    }

    impl<T: Copy> ConvertVec for T {
        #[inline]
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            let mut v = Vec::with_capacity_in(s.len(), alloc);
            // SAFETY:
            // inilalaan sa itaas na may kapasidad na `s`, at ipasimula sa `s.len()` sa ptr::copy_to_non_overlapping sa ibaba.
            //
            unsafe {
                s.as_ptr().copy_to_nonoverlapping(v.as_mut_ptr(), s.len());
                v.set_len(s.len());
            }
            v
        }
    }
}

#[lang = "slice_alloc"]
#[cfg_attr(not(test), rustc_diagnostic_item = "slice")]
#[cfg(not(test))]
impl<T> [T] {
    /// Inaayos ang hiwa.
    ///
    /// Ang uri na ito ay matatag (ibig sabihin, hindi muling ayusin ang pantay na mga elemento) at *O*(*n*\*log(* n*)) pinakamasamang kaso.
    ///
    /// Kung naaangkop, ang hindi matatag na pag-uuri ay ginustong dahil sa pangkalahatan ito ay mas mabilis kaysa sa matatag na pag-uuri at hindi ito naglalaan ng pandiwang pantulong na memorya.
    /// Tingnan ang [`sort_unstable`](slice::sort_unstable).
    ///
    /// # Kasalukuyang pagpapatupad
    ///
    /// Ang kasalukuyang algorithm ay isang umaangkop, umuulit na pagsasama-sama ng pag-uuri na inspirasyon ng [timsort](https://en.wikipedia.org/wiki/Timsort).
    /// Dinisenyo ito upang maging napakabilis sa mga kaso kung saan ang hiwa ay halos pinagsunod-sunod, o binubuo ng dalawa o higit pang mga pinagsunod-sunod na pagkakasunud-sunod na nagkakasunod-sunod.
    ///
    ///
    /// Gayundin, naglalaan ito ng pansamantalang pag-iimbak ng kalahati ng laki ng `self`, ngunit para sa mga maikling hiwa ay isang halip na paglalaan ng uri ng pagpapasok ang ginamit sa halip.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5, 4, 1, -3, 2];
    ///
    /// v.sort();
    /// assert!(v == [-5, -3, 1, 2, 4]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort(&mut self)
    where
        T: Ord,
    {
        merge_sort(self, |a, b| a.lt(b));
    }

    /// Inaayos ang hiwa na may pagpapaandar na kumpare.
    ///
    /// Ang uri na ito ay matatag (ibig sabihin, hindi muling ayusin ang pantay na mga elemento) at *O*(*n*\*log(* n*)) pinakamasamang kaso.
    ///
    /// Dapat na tukuyin ng pagpapaandar ng kumpare ang isang kabuuang pag-order para sa mga elemento sa hiwa.Kung ang pag-order ay hindi kabuuan, ang pagkakasunud-sunod ng mga elemento ay hindi tinukoy.
    /// Ang isang order ay isang kabuuang pagkakasunud-sunod kung ito ay (para sa lahat ng `a`, `b` at `c`):
    ///
    /// * kabuuan at antisymmetric: eksaktong isa sa `a < b`, `a == b` o `a > b` ay totoo, at
    /// * palipat, `a < b` at `b < c` ay nagpapahiwatig ng `a < c`.Ang pareho ay dapat na hawakan para sa parehong `==` at `>`.
    ///
    /// Halimbawa, habang ang [`f64`] ay hindi nagpapatupad ng [`Ord`] dahil `NaN != NaN`, maaari naming gamitin ang `partial_cmp` bilang aming pag-uuri ng pag-uuri kapag alam namin na ang slice ay hindi naglalaman ng isang `NaN`.
    ///
    ///
    /// ```
    /// let mut floats = [5f64, 4.0, 1.0, 3.0, 2.0];
    /// floats.sort_by(|a, b| a.partial_cmp(b).unwrap());
    /// assert_eq!(floats, [1.0, 2.0, 3.0, 4.0, 5.0]);
    /// ```
    ///
    /// Kung naaangkop, ang hindi matatag na pag-uuri ay ginustong dahil sa pangkalahatan ito ay mas mabilis kaysa sa matatag na pag-uuri at hindi ito naglalaan ng pandiwang pantulong na memorya.
    /// Tingnan ang [`sort_unstable_by`](slice::sort_unstable_by).
    ///
    /// # Kasalukuyang pagpapatupad
    ///
    /// Ang kasalukuyang algorithm ay isang umaangkop, umuulit na pagsasama-sama ng pag-uuri na inspirasyon ng [timsort](https://en.wikipedia.org/wiki/Timsort).
    /// Dinisenyo ito upang maging napakabilis sa mga kaso kung saan ang hiwa ay halos pinagsunod-sunod, o binubuo ng dalawa o higit pang mga pinagsunod-sunod na pagkakasunud-sunod na nagkakasunod-sunod.
    ///
    /// Gayundin, naglalaan ito ng pansamantalang pag-iimbak ng kalahati ng laki ng `self`, ngunit para sa mga maikling hiwa ay isang halip na paglalaan ng uri ng pagpapasok ang ginamit sa halip.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [5, 4, 1, 3, 2];
    /// v.sort_by(|a, b| a.cmp(b));
    /// assert!(v == [1, 2, 3, 4, 5]);
    ///
    /// // reverse sorting
    /// v.sort_by(|a, b| b.cmp(a));
    /// assert!(v == [5, 4, 3, 2, 1]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort_by<F>(&mut self, mut compare: F)
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        merge_sort(self, |a, b| compare(a, b) == Less);
    }

    /// Inaayos ang hiwa na may isang pangunahing pag-andar ng pagkuha.
    ///
    /// Ang uri na ito ay matatag (ibig sabihin, hindi muling ayusin ang pantay na mga elemento) at *O*(*m*\* * n *\* log(*n*)) pinakamasamang kaso, kung saan ang pangunahing pagpapaandar ay *O*(*m*).
    ///
    /// Para sa mga mamahaling key function (hal
    /// mga pag-andar na hindi simpleng pag-access sa pag-aari o pangunahing pagpapatakbo), ang [`sort_by_cached_key`](slice::sort_by_cached_key) ay malamang na maging mas mabilis, dahil hindi nito kinukumpara ang mga key ng elemento.
    ///
    ///
    /// Kung naaangkop, ang hindi matatag na pag-uuri ay ginustong dahil sa pangkalahatan ito ay mas mabilis kaysa sa matatag na pag-uuri at hindi ito naglalaan ng pandiwang pantulong na memorya.
    /// Tingnan ang [`sort_unstable_by_key`](slice::sort_unstable_by_key).
    ///
    /// # Kasalukuyang pagpapatupad
    ///
    /// Ang kasalukuyang algorithm ay isang umaangkop, umuulit na pagsasama-sama ng pag-uuri na inspirasyon ng [timsort](https://en.wikipedia.org/wiki/Timsort).
    /// Dinisenyo ito upang maging napakabilis sa mga kaso kung saan ang hiwa ay halos pinagsunod-sunod, o binubuo ng dalawa o higit pang mga pinagsunod-sunod na pagkakasunud-sunod na nagkakasunod-sunod.
    ///
    /// Gayundin, naglalaan ito ng pansamantalang pag-iimbak ng kalahati ng laki ng `self`, ngunit para sa mga maikling hiwa ay isang halip na paglalaan ng uri ng pagpapasok ang ginamit sa halip.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// v.sort_by_key(|k| k.abs());
    /// assert!(v == [1, 2, -3, 4, -5]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_key", since = "1.7.0")]
    #[inline]
    pub fn sort_by_key<K, F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        merge_sort(self, |a, b| f(a).lt(&f(b)));
    }

    /// Inaayos ang hiwa na may isang pangunahing pag-andar ng pagkuha.
    ///
    /// Sa panahon ng pag-uuri, ang pangunahing pagpapaandar ay tinatawag na isang beses lamang bawat elemento.
    ///
    /// Ang uri na ito ay matatag (ibig sabihin, hindi muling ayusin ang pantay na mga elemento) at *O*(*m*\* * n *+* n *\* log(*n*)) pinakamasamang kaso, kung saan ang pangunahing pagpapaandar ay *O*(*m*) .
    ///
    /// Para sa mga simpleng key function (hal., Mga pagpapaandar na pag-access sa pag-aari o pangunahing operasyon), ang [`sort_by_key`](slice::sort_by_key) ay malamang na mas mabilis.
    ///
    /// # Kasalukuyang pagpapatupad
    ///
    /// Ang kasalukuyang algorithm ay batay sa [pattern-defeating quicksort][pdqsort] ni Orson Peters, na pinagsasama ang mabilis na average na kaso ng randomized quicksort na may pinakamabilis na pinakamasamang kaso ng heapsort, habang nakakamit ang linear time sa mga hiwa na may ilang mga pattern.
    /// Gumagamit ito ng ilang randomization upang maiwasan ang mga degenerate na kaso, ngunit may isang nakapirming seed upang palaging magbigay ng deterministic na pag-uugali.
    ///
    /// Sa pinakapangit na kaso, ang algorithm ay naglalaan ng pansamantalang pag-iimbak sa isang `Vec<(K, usize)>` ang haba ng hiwa.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 32, -3, 2];
    ///
    /// v.sort_by_cached_key(|k| k.to_string());
    /// assert!(v == [-3, -5, 2, 32, 4]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_cached_key", since = "1.34.0")]
    #[inline]
    pub fn sort_by_cached_key<K, F>(&mut self, f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        // Helper ng macro para sa pag-index ng aming vector ng pinakamaliit na posibleng uri, upang mabawasan ang paglalaan.
        macro_rules! sort_by_key {
            ($t:ty, $slice:ident, $f:ident) => {{
                let mut indices: Vec<_> =
                    $slice.iter().map($f).enumerate().map(|(i, k)| (k, i as $t)).collect();
                // Ang mga elemento ng `indices` ay natatangi, dahil naka-index ang mga ito, kaya't ang anumang uri ay magiging matatag na may paggalang sa orihinal na hiwa.
                // Gumagamit kami ng `sort_unstable` dito dahil nangangailangan ito ng mas kaunting paglalaan ng memorya.
                //
                indices.sort_unstable();
                for i in 0..$slice.len() {
                    let mut index = indices[i].1;
                    while (index as usize) < i {
                        index = indices[index as usize].1;
                    }
                    indices[i].1 = index;
                    $slice.swap(i, index as usize);
                }
            }};
        }

        let sz_u8 = mem::size_of::<(K, u8)>();
        let sz_u16 = mem::size_of::<(K, u16)>();
        let sz_u32 = mem::size_of::<(K, u32)>();
        let sz_usize = mem::size_of::<(K, usize)>();

        let len = self.len();
        if len < 2 {
            return;
        }
        if sz_u8 < sz_u16 && len <= (u8::MAX as usize) {
            return sort_by_key!(u8, self, f);
        }
        if sz_u16 < sz_u32 && len <= (u16::MAX as usize) {
            return sort_by_key!(u16, self, f);
        }
        if sz_u32 < sz_usize && len <= (u32::MAX as usize) {
            return sort_by_key!(u32, self, f);
        }
        sort_by_key!(usize, self, f)
    }

    /// Kinokopya ang `self` sa isang bagong `Vec`.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = [10, 40, 30];
    /// let x = s.to_vec();
    /// // Dito, ang `s` at `x` ay maaaring mabago nang nakapag-iisa.
    /// ```
    #[rustc_conversion_suggestion]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_vec(&self) -> Vec<T>
    where
        T: Clone,
    {
        self.to_vec_in(Global)
    }

    /// Kinokopya ang `self` sa isang bagong `Vec` na may isang tagapaglaan.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let s = [10, 40, 30];
    /// let x = s.to_vec_in(System);
    /// // Dito, ang `s` at `x` ay maaaring mabago nang nakapag-iisa.
    /// ```
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn to_vec_in<A: Allocator>(&self, alloc: A) -> Vec<T, A>
    where
        T: Clone,
    {
        // NB, tingnan ang `hack` module sa file na ito para sa karagdagang detalye.
        hack::to_vec(self, alloc)
    }

    /// Binabago ang `self` sa isang vector nang walang mga clone o paglalaan.
    ///
    /// Ang nagresultang vector ay maaaring mai-convert pabalik sa isang kahon sa pamamagitan ng `Vec<T>`into_boxed_slice` na pamamaraan.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let s: Box<[i32]> = Box::new([10, 40, 30]);
    /// let x = s.into_vec();
    /// // `s` hindi na magagamit dahil nagawa itong `x`.
    ///
    /// assert_eq!(x, vec![10, 40, 30]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn into_vec<A: Allocator>(self: Box<Self, A>) -> Vec<T, A> {
        // NB, tingnan ang `hack` module sa file na ito para sa karagdagang detalye.
        hack::into_vec(self)
    }

    /// Lumilikha ng isang vector sa pamamagitan ng pag-uulit ng isang slice `n` beses.
    ///
    /// # Panics
    ///
    /// Ang pagpapaandar na ito ay panic kung ang kapasidad ay mag-overflow.
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// assert_eq!([1, 2].repeat(3), vec![1, 2, 1, 2, 1, 2]);
    /// ```
    ///
    /// Isang panic sa pag-apaw:
    ///
    /// ```should_panic
    /// // this will panic at runtime
    /// b"0123456789abcdef".repeat(usize::MAX);
    /// ```
    #[stable(feature = "repeat_generic_slice", since = "1.40.0")]
    pub fn repeat(&self, n: usize) -> Vec<T>
    where
        T: Copy,
    {
        if n == 0 {
            return Vec::new();
        }

        // Kung ang `n` ay mas malaki kaysa sa zero, maaari itong hatiin bilang `n = 2^expn + rem (2^expn > rem, expn >= 0, rem >= 0)`.
        // `2^expn` ay ang bilang na kinatawan ng kaliwang '1' na bit ng `n`, at ang `rem` ay ang natitirang bahagi ng `n`.
        //
        //

        // Paggamit ng `Vec` upang ma-access ang `set_len()`.
        let capacity = self.len().checked_mul(n).expect("capacity overflow");
        let mut buf = Vec::with_capacity(capacity);

        // `2^expn` Ang pag-uulit ay ginagawa sa pamamagitan ng pagdodoble ng `buf` `expn`-beses.
        buf.extend(self);
        {
            let mut m = n >> 1;
            // Kung `m > 0`, may mga natitirang bits hanggang sa ang pinakakaliwa '1'.
            while m > 0 {
                // `buf.extend(buf)`:
                unsafe {
                    ptr::copy_nonoverlapping(
                        buf.as_ptr(),
                        (buf.as_mut_ptr() as *mut T).add(buf.len()),
                        buf.len(),
                    );
                    // `buf` may kapasidad na `self.len() * n`.
                    let buf_len = buf.len();
                    buf.set_len(buf_len * 2);
                }

                m >>= 1;
            }
        }

        // `rem` (`=n, 2 ^ expn`) ang pag-uulit ay ginagawa sa pamamagitan ng pagkopya ng unang mga pag-uulit ng `rem` mula sa `buf` mismo.
        //
        let rem_len = capacity - buf.len(); // `self.len() * rem`
        if rem_len > 0 {
            // `buf.extend(buf[0 .. rem_len])`:
            unsafe {
                // Ito ay hindi nag-o-overlap mula `2^expn > rem`.
                ptr::copy_nonoverlapping(
                    buf.as_ptr(),
                    (buf.as_mut_ptr() as *mut T).add(buf.len()),
                    rem_len,
                );
                // `buf.len() + rem_len` katumbas ng `buf.capacity()` (`= self.len() * n`).
                buf.set_len(capacity);
            }
        }
        buf
    }

    /// Nag-flatt ng isang slice ng `T` sa isang solong halagang `Self::Output`.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].concat(), "helloworld");
    /// assert_eq!([[1, 2], [3, 4]].concat(), [1, 2, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn concat<Item: ?Sized>(&self) -> <Self as Concat<Item>>::Output
    where
        Self: Concat<Item>,
    {
        Concat::concat(self)
    }

    /// Flattens isang slice ng `T` sa isang solong halaga `Self::Output`, paglalagay ng isang ibinigay na separator sa pagitan ng bawat isa.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].join(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].join(&0), [1, 2, 0, 3, 4]);
    /// assert_eq!([[1, 2], [3, 4]].join(&[0, 0][..]), [1, 2, 0, 0, 3, 4]);
    /// ```
    #[stable(feature = "rename_connect_to_join", since = "1.3.0")]
    pub fn join<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }

    /// Flattens isang slice ng `T` sa isang solong halaga `Self::Output`, paglalagay ng isang ibinigay na separator sa pagitan ng bawat isa.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(deprecated)]
    /// assert_eq!(["hello", "world"].connect(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].connect(&0), [1, 2, 0, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.3.0", reason = "renamed to join")]
    pub fn connect<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }
}

#[lang = "slice_u8_alloc"]
#[cfg(not(test))]
impl [u8] {
    /// Nagbabalik ng isang vector na naglalaman ng isang kopya ng hiwa na ito kung saan ang bawat byte ay nai-map sa kanyang katumbas na ASCII sa itaas na kaso.
    ///
    ///
    /// Ang mga titik ng ASCII 'a' hanggang 'z' ay nai-map sa 'A' hanggang 'Z', ngunit ang mga hindi ASCII na titik ay hindi nagbabago.
    ///
    /// Upang mai-uppercase ang in-place na halaga, gamitin ang [`make_ascii_uppercase`].
    ///
    /// [`make_ascii_uppercase`]: u8::make_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_uppercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_uppercase();
        me
    }

    /// Nagbabalik ng isang vector na naglalaman ng isang kopya ng hiwa na ito kung saan ang bawat byte ay nai-mapa sa ASCII na mas mababang katumbas na kaso.
    ///
    ///
    /// ASCII titik 'A' na 'Z' ay nama-map sa 'a' na 'z', ngunit hindi ASCII mga titik ay hindi magbabago.
    ///
    /// Upang maliitin ang in-place na halaga, gamitin ang [`make_ascii_lowercase`].
    ///
    /// [`make_ascii_lowercase`]: u8::make_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_lowercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_lowercase();
        me
    }
}

////////////////////////////////////////////////////////////////////////////////
// Extension traits para sa mga hiwa sa mga tukoy na uri ng data
////////////////////////////////////////////////////////////////////////////////

/// Helper trait para sa [`[T]: : concat`](hiwa::concat).
///
/// Note: ang parameter na uri ng `Item` ay hindi ginagamit sa trait na ito, ngunit pinapayagan nitong maging mas generic ang impls.
/// Kung wala ito, nakukuha natin ang error na ito:
///
/// ```error
/// error[E0207]: the type parameter `T` is not constrained by the impl trait, self type, or predica
///    --> src/liballoc/slice.rs:608:6
///     |
/// 608 | impl<T: Clone, V: Borrow<[T]>> Concat for [V] {
///     |      ^ unconstrained type parameter
/// ```
///
/// Ito ay dahil maaaring may umiiral na mga uri ng `V` na may maraming mga `Borrow<[_]>` impl, tulad ng maraming uri ng `T` na nalalapat:
///
///
/// ```
/// # #[allow(dead_code)]
/// pub struct Foo(Vec<u32>, Vec<String>);
///
/// impl std::borrow::Borrow<[u32]> for Foo {
///     fn borrow(&self) -> &[u32] { &self.0 }
/// }
///
/// impl std::borrow::Borrow<[String]> for Foo {
///     fn borrow(&self) -> &[String] { &self.1 }
/// }
/// ```
///
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Concat<Item: ?Sized> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// Ang nagresultang uri pagkatapos ng pagsasabay
    type Output;

    /// Pagpapatupad ng [`[T]: : concat`](hiwa::concat)
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn concat(slice: &Self) -> Self::Output;
}

/// Helper trait para sa [`[T]: : sumali`](hiwa::sumali)
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Join<Separator> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// Ang nagresultang uri pagkatapos ng pagsasabay
    type Output;

    /// Pagpapatupad ng [`[T]: : sumali`](hiwa::sumali)
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn join(slice: &Self, sep: Separator) -> Self::Output;
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Concat<T> for [V] {
    type Output = Vec<T>;

    fn concat(slice: &Self) -> Vec<T> {
        let size = slice.iter().map(|slice| slice.borrow().len()).sum();
        let mut result = Vec::with_capacity(size);
        for v in slice {
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&T> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &T) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size = slice.iter().map(|v| v.borrow().len()).sum::<usize>() + slice.len() - 1;
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.push(sep.clone());
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&[T]> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &[T]) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size =
            slice.iter().map(|v| v.borrow().len()).sum::<usize>() + sep.len() * (slice.len() - 1);
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.extend_from_slice(sep);
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

////////////////////////////////////////////////////////////////////////////////
// Karaniwang pagpapatupad ng trait para sa mga hiwa
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Borrow<[T]> for Vec<T> {
    fn borrow(&self) -> &[T] {
        &self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> BorrowMut<[T]> for Vec<T> {
    fn borrow_mut(&mut self) -> &mut [T] {
        &mut self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> ToOwned for [T] {
    type Owned = Vec<T>;
    #[cfg(not(test))]
    fn to_owned(&self) -> Vec<T> {
        self.to_vec()
    }

    #[cfg(test)]
    fn to_owned(&self) -> Vec<T> {
        hack::to_vec(self, Global)
    }

    fn clone_into(&self, target: &mut Vec<T>) {
        // i-drop ang anumang bagay sa target na hindi mai-o-overtake
        target.truncate(self.len());

        // target.len <= self.len dahil sa truncate sa itaas, kaya ang mga hiwa dito ay laging nasa-hangganan.
        //
        let (init, tail) = self.split_at(target.len());

        // muling gamitin ang mga nakapaloob na halagang allocations/resources.
        target.clone_from_slice(init);
        target.extend_from_slice(tail);
    }
}

////////////////////////////////////////////////////////////////////////////////
// Sorting
////////////////////////////////////////////////////////////////////////////////

/// Ipasok ang `v[0]` sa paunang pagkakasunod-sunod na `v[1..]` upang ang buong `v[..]` ay pinagsunod-sunod.
///
/// Ito ang integral subroutine ng uri ng pagpapasok.
fn insert_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    if v.len() >= 2 && is_less(&v[1], &v[0]) {
        unsafe {
            // Mayroong tatlong paraan upang ipatupad ang pagpapasok dito:
            //
            // 1. Ipagpalit ang mga katabing elemento hanggang sa ang una ay makarating sa huling hantungan.
            //    Gayunpaman, sa ganitong paraan kumokopya kami ng data sa higit sa kinakailangan.
            //    Kung ang mga elemento ay malalaking istraktura (magastos upang makopya), ang pamamaraang ito ay magiging mabagal.
            //
            // 2. Iterate hanggang sa makita ang tamang lugar para sa unang elemento.
            // Pagkatapos ay ilipat ang mga elementong sumusunod dito upang magkaroon ng puwang para dito at sa wakas ay ilagay ito sa natitirang butas.
            // Ito ay isang mahusay na pamamaraan.
            //
            // 3. Kopyahin ang unang elemento sa isang pansamantalang variable.Umulit hanggang sa tamang lugar para sa mga ito ay natagpuan.
            // Habang nagpapatuloy kami, kopyahin ang bawat elemento na nadaanan sa puwang na nauna dito.
            // Panghuli, kopyahin ang data mula sa pansamantalang variable sa natitirang hole.
            // Napakaganda ng pamamaraang ito.
            // Ang mga benchmark ay nagpakita ng bahagyang mas mahusay na pagganap kaysa sa ika-2 na pamamaraan.
            //
            // Ang lahat ng mga pamamaraan ay nai-benchmark, at ang ika-3 ay nagpakita ng pinakamahusay na mga resulta.Kaya pinili namin ang isa.
            let mut tmp = mem::ManuallyDrop::new(ptr::read(&v[0]));

            // Ang kalagitnaan ng estado ng proseso ng pagpapasok ay laging sinusubaybayan ng `hole`, na nagsisilbing dalawang layunin:
            // 1. Pinoprotektahan ang integridad ng `v` mula sa panics sa `is_less`.
            // 2. Pinupunan ang natitirang butas sa `v` sa dulo.
            //
            // Kaligtasan ng Panic:
            //
            // Kung ang `is_less` panics sa anumang punto sa panahon ng proseso, ang `hole` ay mahuhulog at pupunan ang butas sa `v` ng `tmp`, sa gayon ay tinitiyak na ang `v` ay nagtataglay pa rin ng bawat bagay na una nitong hinawakan nang eksakto nang isang beses.
            //
            //
            //
            let mut hole = InsertionHole { src: &mut *tmp, dest: &mut v[1] };
            ptr::copy_nonoverlapping(&v[1], &mut v[0], 1);

            for i in 2..v.len() {
                if !is_less(&v[i], &*tmp) {
                    break;
                }
                ptr::copy_nonoverlapping(&v[i], &mut v[i - 1], 1);
                hole.dest = &mut v[i];
            }
            // `hole` nahuhulog at sa gayon ay kinopya ang `tmp` sa natitirang butas sa `v`.
        }
    }

    // Kapag nahulog, ang mga kopya mula `src` hanggang `dest`.
    struct InsertionHole<T> {
        src: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for InsertionHole<T> {
        fn drop(&mut self) {
            unsafe {
                ptr::copy_nonoverlapping(self.src, self.dest, 1);
            }
        }
    }
}

/// Ang pagsasama-sama na hindi nagtatapos ay nagpapatakbo ng `v[..mid]` at `v[mid..]` gamit ang `buf` bilang pansamantalang pag-iimbak, at iniimbak ang resulta sa `v[..]`.
///
/// # Safety
///
/// Ang dalawang hiwa ay dapat na walang laman at ang `mid` ay dapat na nasa mga hangganan.
/// Ang Buffer `buf` ay dapat na sapat na mahaba upang makapaghawak ng isang kopya ng mas maikling hiwa.
/// Gayundin, ang `T` ay hindi dapat isang zero-size na uri.
unsafe fn merge<T, F>(v: &mut [T], mid: usize, buf: *mut T, is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    let v = v.as_mut_ptr();
    let (v_mid, v_end) = unsafe { (v.add(mid), v.add(len)) };

    // Ang proseso ng pagsasama ay unang kinopya ang mas maikli na tumakbo sa `buf`.
    // Pagkatapos ay sinusubaybayan nito ang bagong kinopyang run at ang mas matagal na pagpapatakbo ng pasulong (o paatras), na inihambing ang kanilang susunod na mga hindi kinakailangang elemento at pagkopya ng mas kaunti (o mas malaki) na isa sa `v`.
    //
    // Sa sandaling ang mas maikling run ay ganap na natupok, ang proseso ay tapos na.Kung mas mahaba run ay makakakuha natupok muna, pagkatapos ay kailangan naming kopyahin ang kahit anong hinayaang ng mas maikling run sa natitirang butas sa `v`.
    //
    // Ang kalagitnaan ng estado ng proseso ay laging sinusubaybayan ng `hole`, na nagsisilbing dalawang layunin:
    // 1. Pinoprotektahan ang integridad ng `v` mula sa panics sa `is_less`.
    // 2. Pinupunan ang natitirang butas sa `v` kung ang mas matagal na run ay natupok muna.
    //
    // Kaligtasan ng Panic:
    //
    // Kung ang `is_less` panics sa anumang punto sa panahon ng proseso, ang `hole` ay mahuhulog at pupunan ang butas sa `v` sa hindi naaangkop na saklaw sa `buf`, sa gayon tinitiyak na hawak pa rin ng `v` ang bawat bagay na una nitong hinawakan nang eksakto nang isang beses.
    //
    //
    //
    //
    //
    let mut hole;

    if mid <= len - mid {
        // Ang kaliwang takbo ay mas maikli.
        unsafe {
            ptr::copy_nonoverlapping(v, buf, mid);
            hole = MergeHole { start: buf, end: buf.add(mid), dest: v };
        }

        // Sa una, ang mga pahiwatig na ito ay tumuturo sa mga pagsisimula ng kanilang mga arrays.
        let left = &mut hole.start;
        let mut right = v_mid;
        let out = &mut hole.dest;

        while *left < hole.end && right < v_end {
            // Ubusin ang mas mababang panig.
            // Kung pantay, ginusto ang kaliwang patakbo upang mapanatili ang katatagan.
            unsafe {
                let to_copy = if is_less(&*right, &**left) {
                    get_and_increment(&mut right)
                } else {
                    get_and_increment(left)
                };
                ptr::copy_nonoverlapping(to_copy, get_and_increment(out), 1);
            }
        }
    } else {
        // Ang tamang patakbo ay mas maikli.
        unsafe {
            ptr::copy_nonoverlapping(v_mid, buf, len - mid);
            hole = MergeHole { start: buf, end: buf.add(len - mid), dest: v_mid };
        }

        // Sa una, ang mga pahiwatig na ito ay tumuturo sa mga dulo ng kanilang mga arrays.
        let left = &mut hole.dest;
        let right = &mut hole.end;
        let mut out = v_end;

        while v < *left && buf < *right {
            // Ubusin ang mas higit na bahagi.
            // Kung pantay, ginusto ang tamang patakbo upang mapanatili ang katatagan.
            unsafe {
                let to_copy = if is_less(&*right.offset(-1), &*left.offset(-1)) {
                    decrement_and_get(left)
                } else {
                    decrement_and_get(right)
                };
                ptr::copy_nonoverlapping(to_copy, decrement_and_get(&mut out), 1);
            }
        }
    }
    // Sa wakas, bumagsak ang `hole`.
    // Kung ang mas maikli na pagtakbo ay hindi ganap na natupok, ang anumang natitira dito ay makopya ngayon sa butas sa `v`.

    unsafe fn get_and_increment<T>(ptr: &mut *mut T) -> *mut T {
        let old = *ptr;
        *ptr = unsafe { ptr.offset(1) };
        old
    }

    unsafe fn decrement_and_get<T>(ptr: &mut *mut T) -> *mut T {
        *ptr = unsafe { ptr.offset(-1) };
        *ptr
    }

    // Kapag nahulog, kopyahin ang saklaw `start..end` sa `dest..`.
    struct MergeHole<T> {
        start: *mut T,
        end: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for MergeHole<T> {
        fn drop(&mut self) {
            // `T` ay hindi isang zero-size na uri, kaya't okay na hatiin ayon sa laki nito.
            let len = (self.end as usize - self.start as usize) / mem::size_of::<T>();
            unsafe {
                ptr::copy_nonoverlapping(self.start, self.dest, len);
            }
        }
    }
}

/// Ang pagsasama-sama ng pag-uuri ay humihiram ng ilang (ngunit hindi lahat) mga ideya mula sa TimSort, na inilarawan nang detalyado [here](http://svn.python.org/projects/python/trunk/Objects/listsort.txt).
///
///
/// Kinikilala ng algorithm ang mahigpit na pagbaba at hindi pababang mga kasunod, na kung tawagin ay natural na pagtakbo.Mayroong isang stack ng mga nakabinbing pagpapatakbo na maisasama pa.
/// Ang bawat bagong nahanap na pagtakbo ay itinulak papunta sa stack, at pagkatapos ang ilang mga pares ng mga katabing run ay pinagsasama hanggang sa nasiyahan ang dalawang invariant na ito:
///
/// 1. para sa bawat `i` sa `1..runs.len()`: `runs[i - 1].len > runs[i].len`
/// 2. para sa bawat `i` sa `2..runs.len()`: `runs[i - 2].len > runs[i - 1].len + runs[i].len`
///
/// Tinitiyak ng mga invariant na ang kabuuang oras ng pagtakbo ay *O*(*n*\*log(* n*)) pinakamasamang kaso.
///
///
fn merge_sort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Ang mga hiwa ng hanggang sa haba na ito ay pinagsunod-sunod gamit ang uri ng pagpapasok.
    const MAX_INSERTION: usize = 20;
    // Napakaikli na nagpapatakbo ay pinahaba gamit ang pagsingit ng uri upang saklaw ng hindi bababa sa maraming mga elemento.
    const MIN_RUN: usize = 10;

    // Pag-uuri Wala pang makabuluhang pag-uugali sa zero-sized uri.
    if size_of::<T>() == 0 {
        return;
    }

    let len = v.len();

    // Ang mga maikling array ay napagsunod-sunod sa lugar sa pamamagitan ng pag-uuri ng pagpapasok upang maiwasan ang mga paglalaan.
    if len <= MAX_INSERTION {
        if len >= 2 {
            for i in (0..len - 1).rev() {
                insert_head(&mut v[i..], &mut is_less);
            }
        }
        return;
    }

    // Maglaan ng isang buffer upang magamit bilang memory memory.Pinapanatili namin ang haba 0 upang mapapanatili namin dito ang mababaw na mga kopya ng mga nilalaman ng `v` nang hindi isapalaran ang mga dtor na tumatakbo sa mga kopya kung `is_less` panics.
    //
    // Kapag pinagsasama ang dalawang pinagsunod-sunod na pagpapatakbo, ang buffer na ito ay nagtataglay ng isang kopya ng mas maikli na pagtakbo, na palaging may haba sa halos `len / 2`.
    //
    let mut buf = Vec::with_capacity(len / 2);

    // Upang makilala ang natural na mga pagpapatakbo sa `v`, daanan namin ito paurong.
    // Maaaring mukhang isang kakaibang desisyon iyon, ngunit isaalang-alang ang katotohanan na ang pagsasama ay mas madalas na pumunta sa kabaligtaran na direksyon (forwards).
    // Ayon sa mga benchmark, ang pagsasama sa pasulong ay medyo mas mabilis kaysa sa pagsasama ng paatras.
    // Sa pagtatapos, ang pagtukoy ng mga pagpapatakbo sa pamamagitan ng pagtawid pabalik ay nagpapabuti sa pagganap.
    let mut runs = vec![];
    let mut end = len;
    while end > 0 {
        // Hanapin ang susunod na natural run, at baligtarin ito kung mahigpit itong bumababa.
        let mut start = end - 1;
        if start > 0 {
            start -= 1;
            unsafe {
                if is_less(v.get_unchecked(start + 1), v.get_unchecked(start)) {
                    while start > 0 && is_less(v.get_unchecked(start), v.get_unchecked(start - 1)) {
                        start -= 1;
                    }
                    v[start..end].reverse();
                } else {
                    while start > 0 && !is_less(v.get_unchecked(start), v.get_unchecked(start - 1))
                    {
                        start -= 1;
                    }
                }
            }
        }

        // Ipasok ang ilang higit pang mga elemento sa pagtakbo kung ito ay masyadong maikli.
        // Ang pag-uuri ng pagpasok ay mas mabilis kaysa sa pagsasama-sama ng pag-uuri sa mga maikling pagkakasunud-sunod, kaya't makabuluhang nagpapabuti sa pagganap.
        while start > 0 && end - start < MIN_RUN {
            start -= 1;
            insert_head(&mut v[start..end], &mut is_less);
        }

        // Itulak ang patakbong ito papunta sa stack.
        runs.push(Run { start, len: end - start });
        end = start;

        // Pagsamahin ang ilang mga pares ng katabi na pagtakbo upang masiyahan ang mga invariant.
        while let Some(r) = collapse(&runs) {
            let left = runs[r + 1];
            let right = runs[r];
            unsafe {
                merge(
                    &mut v[left.start..right.start + right.len],
                    left.len,
                    buf.as_mut_ptr(),
                    &mut is_less,
                );
            }
            runs[r] = Run { start: left.start, len: left.len + right.len };
            runs.remove(r + 1);
        }
    }

    // Sa wakas, eksaktong isang run ay dapat manatili sa stack.
    debug_assert!(runs.len() == 1 && runs[0].start == 0 && runs[0].len == len);

    // Sinusuri ang stack ng mga tumatakbo at kinikilala ang susunod na pares ng mga tumatakbo upang pagsamahin.
    // Mas partikular, kung ang `Some(r)` ay ibinalik, nangangahulugan ito na ang `runs[r]` at `runs[r + 1]` ay dapat na pagsamahin sa susunod.
    // Kung ang algorithm ay dapat magpatuloy sa pagbuo ng isang bagong run sa halip, ibabalik ang `None`.
    //
    // Ang TimSort ay kasumpa-sumpa para sa mga pagpapatupad ng maraming buggy nito, tulad ng inilarawan dito:
    // http://envisage-project.eu/timsort-specification-and-verification/
    //
    // Ang diwa ng kwento ay: dapat nating ipatupad ang mga invariant sa nangungunang apat na tumatakbo sa stack.
    // Ang pagpapatupad sa kanila sa nangungunang tatlong lamang ay hindi sapat upang matiyak na ang mga invariant ay hahawak pa rin para sa *lahat* na tumatakbo sa stack.
    //
    // Ang pagpapaandar na ito ay tama na sumusuri sa mga invariant para sa nangungunang apat na pagpapatakbo.
    // Bilang karagdagan, kung ang tuktok na patakbo ay nagsisimula sa index 0, palagi itong hihiling ng isang operasyon ng pagsasama hanggang sa ganap na gumuho ang stack, upang makumpleto ang uri.
    //
    //
    #[inline]
    fn collapse(runs: &[Run]) -> Option<usize> {
        let n = runs.len();
        if n >= 2
            && (runs[n - 1].start == 0
                || runs[n - 2].len <= runs[n - 1].len
                || (n >= 3 && runs[n - 3].len <= runs[n - 2].len + runs[n - 1].len)
                || (n >= 4 && runs[n - 4].len <= runs[n - 3].len + runs[n - 2].len))
        {
            if n >= 3 && runs[n - 3].len < runs[n - 1].len { Some(n - 3) } else { Some(n - 2) }
        } else {
            None
        }
    }

    #[derive(Clone, Copy)]
    struct Run {
        start: usize,
        len: usize,
    }
}