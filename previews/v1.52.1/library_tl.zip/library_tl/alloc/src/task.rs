#![stable(feature = "wake_trait", since = "1.51.0")]
//! Mga uri at Traits para sa pagtatrabaho sa mga asynchronous na gawain.
use core::mem::ManuallyDrop;
use core::task::{RawWaker, RawWakerVTable, Waker};

use crate::sync::Arc;

/// Ang pagpapatupad ng paggising ng isang gawain sa isang tagapagpatupad.
///
/// Ang trait na ito ay maaaring magamit upang lumikha ng isang [`Waker`].
/// Isang tagagawa ay maaaring tukuyin ang isang pagpapatupad ng mga ito trait, at gamitin iyon upang makagawa ng isang Waker upang pumasa sa mga gawain na ay executed sa executor iyon.
///
/// Ang trait na ito ay isang ligtas na memorya at ergonomic na kahalili sa pagbuo ng isang [`RawWaker`].
/// Sinusuportahan nito ang karaniwang disenyo ng tagapagpatupad kung saan ang data na ginamit upang gisingin ang isang gawain ay nakaimbak sa isang [`Arc`].
/// Ang ilang mga tagapagpatupad (lalo na ang mga para sa mga naka-embed na system) ay hindi maaaring gumamit ng API na ito, na ang dahilan kung bakit umiiral ang [`RawWaker`] bilang isang kahalili para sa mga sistemang iyon.
///
/// [arc]: ../../std/sync/struct.Arc.html
///
/// # Examples
///
/// Isang pangunahing pagpapaandar ng `block_on` na tumatagal ng isang future at pinapatakbo ito hanggang sa makumpleto sa kasalukuyang thread.
///
/// **Note:** Ang halimbawang ito trades kawastuhan para sa pagiging simple.
/// Upang maiwasan ang mga deadlock, ang mga pagpapatupad sa antas ng produksyon ay kakailanganin ding hawakan ang mga panggitnang tawag sa `thread::unpark` pati na rin ang mga pugad na pag-uusap.
///
///
/// ```rust
/// use std::future::Future;
/// use std::sync::Arc;
/// use std::task::{Context, Poll, Wake};
/// use std::thread::{self, Thread};
///
/// /// Isang tagapagising na gumising sa kasalukuyang thread kapag tinawag.
/// struct ThreadWaker(Thread);
///
/// impl Wake for ThreadWaker {
///     fn wake(self: Arc<Self>) {
///         self.0.unpark();
///     }
/// }
///
/// /// Patakbuhin ang isang future hanggang makumpleto ang kasalukuyang thread.
/// fn block_on<T>(fut: impl Future<Output = T>) -> T {
///     // I-pin ang future upang maaari itong ma-poll.
///     let mut fut = Box::pin(fut);
///
///     // Lumikha ng isang bagong konteksto upang maipasa sa future.
///     let t = thread::current();
///     let waker = Arc::new(ThreadWaker(t)).into();
///     let mut cx = Context::from_waker(&waker);
///
///     // Patakbuhin ang future hanggang makumpleto.
///     loop {
///         match fut.as_mut().poll(&mut cx) {
///             Poll::Ready(res) => return res,
///             Poll::Pending => thread::park(),
///         }
///     }
/// }
///
/// block_on(async {
///     println!("Hi from inside a future!");
/// });
/// ```
///
///
///
///
#[stable(feature = "wake_trait", since = "1.51.0")]
pub trait Wake {
    /// Gisingin ang gawaing ito.
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake(self: Arc<Self>);

    /// Gisingin ang gawaing ito nang hindi naubos ang tagapagising.
    ///
    /// Kung sinusuportahan ng isang tagapagpatupad ang isang mas murang paraan upang magising nang hindi naubos ang waker, dapat itong i-override ang pamamaraang ito.
    /// Bilang default, na-clone nito ang [`Arc`] at tinatawag na [`wake`] sa clone.
    ///
    /// [`wake`]: Wake::wake
    ///
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake_by_ref(self: &Arc<Self>) {
        self.clone().wake();
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for Waker {
    fn from(waker: Arc<W>) -> Waker {
        // KALIGTASAN: Ito ay ligtas dahil raw_waker ligtas na constructs
        // isang RawWaker mula sa Arc<W>.
        unsafe { Waker::from_raw(raw_waker(waker)) }
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for RawWaker {
    fn from(waker: Arc<W>) -> RawWaker {
        raw_waker(waker)
    }
}

// NB: Ang pribadong pagpapaandar na ito para sa pagbuo ng isang RawWaker ay ginagamit, sa halip na
// inlining ito sa `From<Arc<W>> for RawWaker` impl, upang matiyak na ang kaligtasan ng `From<Arc<W>> for Waker` ay hindi nakasalalay sa tamang pagpapadala ng trait, sa halip ang parehong impls ay tumawag sa pagpapaandar na ito nang direkta at malinaw.
//
//
//
#[inline(always)]
fn raw_waker<W: Wake + Send + Sync + 'static>(waker: Arc<W>) -> RawWaker {
    // Palakihin ang bilang ng sanggunian ng arc upang i-clone ito.
    unsafe fn clone_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) -> RawWaker {
        unsafe { Arc::increment_strong_count(waker as *const W) };
        RawWaker::new(
            waker as *const (),
            &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
        )
    }

    // Gumising ayon sa halaga, ilipat ang Arc sa pagpapaandar ng Wake::wake
    unsafe fn wake<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { Arc::from_raw(waker as *const W) };
        <W as Wake>::wake(waker);
    }

    // Gumising sa pamamagitan ng sanggunian, balutin ang tagapagmata sa Manu-manong Pag-drop upang maiwasan ang pagbagsak nito
    unsafe fn wake_by_ref<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { ManuallyDrop::new(Arc::from_raw(waker as *const W)) };
        <W as Wake>::wake_by_ref(&waker);
    }

    // Bawasan ang drop bilang ng sanggunian sa drop
    unsafe fn drop_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        unsafe { Arc::decrement_strong_count(waker as *const W) };
    }

    RawWaker::new(
        Arc::into_raw(waker) as *const (),
        &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
    )
}