//! Mga pahiwatig ng pagbibilang ng solong-sinulid na sanggunian.Ang 'Rc' ay nangangahulugang 'Sanggunian
//! Counted'.
//!
//! Ang uri [`Rc<T>`][`Rc`] nagbibigay shared pagmamay-ari ng ang halaga ng mga uri `T`, inilalaan sa magbunton.
//! Ang invoking [`clone`][clone] sa [`Rc`] ay gumagawa ng isang bagong pointer sa parehong paglalaan sa tumpok.
//! Kapag ang huling [`Rc`] pointer sa isang naibigay na paglalaan ay nawasak, ang halagang nakaimbak sa paglaanang iyon (na madalas na tinukoy bilang "inner value") ay nahuhulog din.
//!
//! Ang mga nakabahaging sanggunian sa Rust ay hindi pinapayagan ang pag-mutate bilang default, at ang [`Rc`] ay walang kataliwasan: hindi ka makakakuha ng pangkalahatang isang nababagabag na sanggunian sa isang bagay sa loob ng [`Rc`].
//! Kung kailangan mo ng kakayahang magbago, maglagay ng [`Cell`] o [`RefCell`] sa loob ng [`Rc`];tingnan ang [an example of mutability inside an `Rc`][mutability].
//!
//! [`Rc`] gumagamit ng pagbibilang ng sanggunian na hindi atomic.
//! Nangangahulugan ito na ang overhead ay napakababa, ngunit ang isang [`Rc`] ay hindi maipapadala sa pagitan ng mga thread, at dahil dito ay hindi ipinatupad ng [`Rc`] ang [`Send`][send].
//! Bilang isang resulta, susuriin ng tagatala ng Rust *sa oras ng pag-ipon* na hindi ka nagpapadala ng [`Rc`] sa pagitan ng mga thread.
//! Kung kailangan mo ng multi-thread, pagbilang ng sanggunian ng atomic, gamitin ang [`sync::Arc`][arc].
//!
//! Ang [`downgrade`][downgrade] na pamamaraan ay maaaring magamit upang lumikha ng isang hindi pagmamay-ari na [`Weak`] pointer.
//! Ang isang [`Weak`] pointer ay maaaring maging [`pag-upgrade`][pag-upgrade] d sa isang [`Rc`], ngunit ibabalik nito ang [`None`] kung ang halagang nakaimbak sa paglalaan ay nahulog na.
//! Sa madaling salita, hindi pinapanatili ng mga pointer ng `Weak` ang halaga sa loob ng paglalaan na buhay;gayunpaman, ang mga ito *huwag* panatilihin ang allocation (ang mga tagapagtaguyod tindahan para sa panloob na halaga) buhay.
//!
//! Ang isang pag-ikot sa pagitan ng [`Rc`] pointers ay hindi kailanman maaaksyunan.
//! Para sa kadahilanang ito, ang [`Weak`] ay ginagamit upang masira ang mga pag-ikot.
//! Halimbawa, ang isang puno ay maaaring magkaroon ng malakas na [`Rc`] pointers mula sa mga node ng magulang hanggang sa mga bata, at [`Weak`] pointers mula sa mga bata pabalik sa kanilang mga magulang.
//!
//! `Rc<T>` awtomatikong dereferences sa `T` (sa pamamagitan ng [`Deref`] trait), upang maaari mong tawagan ang mga pamamaraan ng `T` sa isang halaga ng uri [`Rc<T>`][`Rc`].
//! Upang maiwasan ang mga pag-aaway ng pangalan sa mga pamamaraan ng `T`, ang mga pamamaraan ng [`Rc<T>`][`Rc`] mismo ay nauugnay na mga pagpapaandar, na tinatawag na paggamit ng [fully qualified syntax]:
//!
//! ```
//! use std::rc::Rc;
//!
//! let my_rc = Rc::new(());
//! Rc::downgrade(&my_rc);
//! ```
//!
//! `Rc<T>Ang mga pagpapatupad ng traits tulad ng `Clone` ay maaari ding tawagan gamit ang ganap na kwalipikadong syntax.
//! Ang ilang mga tao ay ginusto na gumamit ng ganap na kwalipikadong syntax, habang ang iba ay ginusto ang paggamit ng paraan-tawag na syntax.
//!
//! ```
//! use std::rc::Rc;
//!
//! let rc = Rc::new(());
//! // Syntax ng tawag sa pamamaraan
//! let rc2 = rc.clone();
//! // Ganap na kwalipikadong syntax
//! let rc3 = Rc::clone(&rc);
//! ```
//!
//! [`Weak<T>`][`Weak`] ay hindi awtomatikong pag-aakma sa `T`, dahil ang panloob na halaga ay maaaring nahulog na.
//!
//! # Mga sanggunian sa pag-clone
//!
//! Ang paglikha ng isang bagong sanggunian sa parehong paglalaan bilang isang mayroon nang sanggunian na binibilang na pointer ay tapos na gamit ang `Clone` trait na ipinatupad para sa [`Rc<T>`][`Rc`] at [`Weak<T>`][`Weak`].
//!
//!
//! ```
//! use std::rc::Rc;
//!
//! let foo = Rc::new(vec![1.0, 2.0, 3.0]);
//! // Ang dalawang syntaxes sa ibaba ay katumbas.
//! let a = foo.clone();
//! let b = Rc::clone(&foo);
//! // a at b parehong tumuturo sa parehong lokasyon ng memorya bilang foo.
//! ```
//!
//! Ang `Rc::clone(&from)` syntax ay ang pinaka idiomatiko sapagkat mas malinaw na ihinahatid nito ang kahulugan ng code.
//! Sa halimbawa sa itaas, ginagawang mas madali ng syntax na ito na makita na ang code na ito ay lumilikha ng isang bagong sanggunian sa halip na kopyahin ang buong nilalaman ng foo.
//!
//! # Examples
//!
//! Isaalang-alang ang isang senaryo kung saan ang isang hanay ng mga `Gadget` ay pagmamay-ari ng isang naibigay na `Owner`.
//! Nais naming ituro ang aming `Gadget` sa kanilang `Owner`.Hindi namin ito magagawa sa natatanging pagmamay-ari, dahil higit sa isang gadget ang maaaring kabilang sa parehong `Owner`.
//! [`Rc`] ay nagbibigay-daan sa amin upang ibahagi ang isang `Owner` sa pagitan ng maraming `Gadget`s, at ang `Owner` ay mananatiling inilalaan hangga't may anumang `Gadget` na puntos dito.
//!
//! ```
//! use std::rc::Rc;
//!
//! struct Owner {
//!     name: String,
//!     // ... iba pang mga bukirin
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... iba pang mga bukirin
//! }
//!
//! fn main() {
//!     // Lumikha ng isang nabanggit na sanggunian na `Owner`.
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!         }
//!     );
//!
//!     // Lumikha ng `Gadget`s na kabilang sa `gadget_owner`.
//!     // Ang pag-clone ng `Rc<Owner>` ay nagbibigay sa amin ng isang bagong pointer sa parehong paglalaan ng `Owner`, na nagdaragdag ng bilang ng sanggunian sa proseso.
//!     //
//!     let gadget1 = Gadget {
//!         id: 1,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!     let gadget2 = Gadget {
//!         id: 2,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!
//!     // Itapon ang aming lokal na variable `gadget_owner`.
//!     drop(gadget_owner);
//!
//!     // Sa kabila ng pag-drop ng `gadget_owner`, nakakapag-print pa rin kami ng pangalan ng `Owner` ng `Gadget`s.
//!     // Ito ay dahil nag-drop lamang kami ng isang solong `Rc<Owner>`, hindi ang `Owner` na itinuturo nito.
//!     // Hangga't may iba pang `Rc<Owner>` na tumuturo sa parehong paglalaan ng `Owner`, mananatili itong live.
//!     // Gumagana ang projection ng patlang na `gadget1.owner.name` dahil awtomatikong nagde-refer ang `Rc<Owner>` sa `Owner`.
//!     //
//!     //
//!     println!("Gadget {} owned by {}", gadget1.id, gadget1.owner.name);
//!     println!("Gadget {} owned by {}", gadget2.id, gadget2.owner.name);
//!
//!     // Sa pagtatapos ng pagpapaandar, ang `gadget1` at `gadget2` ay nawasak, at kasama nila ang huling binilang na mga sanggunian sa aming `Owner`.
//!     // Ang Gadget Man ay nawasak din ngayon.
//!     //
//! }
//! ```
//!
//! Kung nagbago ang aming mga kinakailangan, at kailangan din naming makapag-daanan mula `Owner` hanggang `Gadget`, magkakaroon kami ng mga problema.
//! Ang isang [`Rc`] pointer mula `Owner` hanggang `Gadget` ay nagpapakilala sa isang ikot.
//! Nangangahulugan ito na ang kanilang mga bilang ng sanggunian ay hindi maaaring umabot sa 0, at ang paglalaan ay hindi kailanman mawawasak:
//! isang butas na alaala.Upang makaikot dito, maaari naming gamitin ang [`Weak`] pointers.
//!
//! Talagang ginagawang mahirap ng Rust na gumawa ng loop na ito sa unang lugar.Upang magwakas sa dalawang halagang tumuturo sa bawat isa, ang isa sa mga ito ay kailangang maging nabago.
//! Mahirap ito dahil ang [`Rc`] ay nagpapatupad ng kaligtasan ng memorya sa pamamagitan lamang ng pagbibigay ng mga nakabahaging sanggunian sa halagang binabalot nito, at hindi pinapayagan ng mga ito ang direktang pagbago.
//! Kailangan nating balutin ang bahagi ng halagang nais naming mutate sa isang [`RefCell`], na nagbibigay ng *interior mutability*: isang pamamaraan upang makamit ang mutability sa pamamagitan ng isang nakabahaging sanggunian.
//! [`RefCell`] nagpapatupad ng mga alituntunin sa paghiram ng Rust sa runtime.
//!
//! ```
//! use std::rc::Rc;
//! use std::rc::Weak;
//! use std::cell::RefCell;
//!
//! struct Owner {
//!     name: String,
//!     gadgets: RefCell<Vec<Weak<Gadget>>>,
//!     // ... iba pang mga bukirin
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... iba pang mga bukirin
//! }
//!
//! fn main() {
//!     // Lumikha ng isang nabanggit na sanggunian na `Owner`.
//!     // Tandaan na inilagay namin ang vector ng `May-ari` sa loob ng isang `RefCell` upang mai-mutate namin ito sa pamamagitan ng isang nakabahaging sanggunian.
//!     //
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!             gadgets: RefCell::new(vec![]),
//!         }
//!     );
//!
//!     // Lumikha ng `Gadget` na pag-aari ng `gadget_owner`, tulad ng dati.
//!     let gadget1 = Rc::new(
//!         Gadget {
//!             id: 1,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!     let gadget2 = Rc::new(
//!         Gadget {
//!             id: 2,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!
//!     // Idagdag ang `Gadget`s sa kanilang `Owner`.
//!     {
//!         let mut gadgets = gadget_owner.gadgets.borrow_mut();
//!         gadgets.push(Rc::downgrade(&gadget1));
//!         gadgets.push(Rc::downgrade(&gadget2));
//!
//!         // `RefCell` dito natatapos ang pag-utang.
//!     }
//!
//!     // Magkaroon ng pansin sa aming mga `Gadget`, i-print ang kanilang mga detalye.
//!     for gadget_weak in gadget_owner.gadgets.borrow().iter() {
//!
//!         // `gadget_weak` ay isang `Weak<Gadget>`.
//!         // Dahil ang `Weak` pointers ay hindi magagarantiyahan ang paglalaan ay mayroon pa rin, kailangan naming tawagan ang `upgrade`, na nagbabalik ng isang `Option<Rc<Gadget>>`.
//!         //
//!         //
//!         // Sa kasong ito alam namin na ang paglalaan ay mayroon pa rin, kaya simpleng `unwrap` namin ang `Option`.
//!         // Sa isang mas kumplikadong programa, maaaring kailanganin mo ang kaaya-ayaang paghawak ng error para sa isang resulta na `None`.
//!         //
//!
//!         let gadget = gadget_weak.upgrade().unwrap();
//!         println!("Gadget {} owned by {}", gadget.id, gadget.owner.name);
//!     }
//!
//!     // Sa pagtatapos ng pagpapaandar, ang `gadget_owner`, `gadget1`, at `gadget2` ay nawasak.
//!     // Wala nang malakas na (`Rc`) na mga payo sa mga gadget, kaya't sila ay nawasak.
//!     // Nawawalan nito ang bilang ng sanggunian sa Gadget Man, kaya't nawasak din siya.
//!     //
//! }
//! ```
//!
//! [clone]: Clone::clone
//! [`Cell`]: core::cell::Cell
//! [`RefCell`]: core::cell::RefCell
//! [send]: core::marker::Send
//! [arc]: crate::sync::Arc
//! [`Deref`]: core::ops::Deref
//! [downgrade]: Rc::downgrade
//! [upgrade]: Weak::upgrade
//! [mutability]: core::cell#introducing-mutability-inside-of-something-immutable
//! [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[cfg(not(test))]
use crate::boxed::Box;
#[cfg(test)]
use std::boxed::Box;

use core::any::Any;
use core::borrow;
use core::cell::Cell;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::abort;
use core::iter;
use core::marker::{self, PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, forget, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

// Ito ay repr(C) hanggang future-patunay laban sa posibleng pag-aayos muli ng patlang, na makagambala sa kung hindi man ligtas na [into|from]_raw() ng maaaring mailipat na panloob na mga uri.
//
//
#[repr(C)]
struct RcBox<T: ?Sized> {
    strong: Cell<usize>,
    weak: Cell<usize>,
    value: T,
}

/// Isang solong sinulid na pointer na nagbibilang ng sanggunian.Ang 'Rc' ay nangangahulugang 'Sanggunian
/// Counted'.
///
/// Tingnan ang [module-level documentation](./index.html) para sa karagdagang detalye.
///
/// Ang likas na pamamaraan ng `Rc` ay lahat ng mga kaugnay na pag-andar, na nangangahulugang kailangan mong tawagan ang mga ito bilang hal, [`Rc::get_mut(&mut value)`][get_mut] sa halip na `value.get_mut()`.
/// Iniiwasan nito ang mga salungatan sa mga pamamaraan ng panloob na uri `T`.
///
/// [get_mut]: Rc::get_mut
///
#[cfg_attr(not(test), rustc_diagnostic_item = "Rc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Rc<T: ?Sized> {
    ptr: NonNull<RcBox<T>>,
    phantom: PhantomData<RcBox<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Send for Rc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Sync for Rc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Rc<U>> for Rc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T> {}

impl<T: ?Sized> Rc<T> {
    #[inline(always)]
    fn inner(&self) -> &RcBox<T> {
        // Ang hindi kaligtasan na ito ay ok dahil habang buhay ang Rc na ito ay ginagarantiyahan namin na ang panloob na pointer ay wasto.
        //
        unsafe { self.ptr.as_ref() }
    }

    fn from_inner(ptr: NonNull<RcBox<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut RcBox<T>) -> Self {
        Self::from_inner(unsafe { NonNull::new_unchecked(ptr) })
    }
}

impl<T> Rc<T> {
    /// Bumubuo ng isang bagong `Rc<T>`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(value: T) -> Rc<T> {
        // Mayroong isang implicit mahina na pointer na pagmamay-ari ng lahat ng mga malakas na payo, na tinitiyak na ang mahinang destructor ay hindi kailanman pinalaya ang paglalaan habang ang malakas na destructor ay tumatakbo, kahit na ang mahina na pointer ay nakaimbak sa loob ng malakas.
        //
        //
        //
        Self::from_inner(
            Box::leak(box RcBox { strong: Cell::new(1), weak: Cell::new(1), value }).into(),
        )
    }

    /// Bumubuo ng isang bagong `Rc<T>` gamit ang isang mahinang sanggunian sa sarili nito.
    /// Ang pagtatangkang i-upgrade ang mahinang sanggunian bago ang pagbalik ng pagpapaandar na ito ay magreresulta sa isang halagang `None`.
    ///
    /// Gayunpaman, ang mahinang sanggunian ay maaaring ma-clone nang malaya at maiimbak para magamit sa ibang oras.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Gadget {
    ///     self_weak: Weak<Self>,
    ///     // ... maraming mga patlang
    /// }
    /// impl Gadget {
    ///     pub fn new() -> Rc<Self> {
    ///         Rc::new_cyclic(|self_weak| {
    ///             Gadget { self_weak: self_weak.clone(), /* ... */ }
    ///         })
    ///     }
    /// }
    /// ```
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Rc<T> {
        // Buuin ang panloob sa estado ng "uninitialized" na may isang solong mahinang sanggunian.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box RcBox {
            strong: Cell::new(0),
            weak: Cell::new(1),
            value: mem::MaybeUninit::<T>::uninit(),
        })
        .into();

        let init_ptr: NonNull<RcBox<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // Mahalagang hindi namin isusuko ang pagmamay-ari ng mahinang pointer, o kung hindi man mapalaya ang memorya sa oras ng pagbabalik ng `data_fn`.
        // Kung talagang nais naming ipasa ang pagmamay-ari, makakagawa kami ng isang karagdagang mahinang pointer para sa aming sarili, ngunit magreresulta ito sa mga karagdagang pag-update sa mahinang bilang ng sanggunian na maaaring hindi kinakailangan kung hindi man.
        //
        //
        //
        //
        let data = data_fn(&weak);

        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).value), data);

            let prev_value = (*inner).strong.get();
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
            (*inner).strong.set(1);
        }

        let strong = Rc::from_inner(init_ptr);

        // Ang mga malakas na sanggunian ay dapat na magkasama na pagmamay-ari ng isang ibinahaging mahinang sanggunian, kaya huwag patakbuhin ang destructor para sa aming dating mahinang sanggunian.
        //
        mem::forget(weak);
        strong
    }

    /// Bumubuo ng isang bagong `Rc` na may uninitialized na mga nilalaman.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Ipinagpaliban na pagsisimula:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Bumubuo ng isang bagong `Rc` na may uninitialized na mga nilalaman, na may memorya na puno ng `0` bytes.
    ///
    ///
    /// Tingnan ang [`MaybeUninit::zeroed`][zeroed] para sa mga halimbawa ng wasto at maling paggamit ng pamamaraang ito.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Bumubuo ng isang bagong `Rc<T>`, nagbabalik ng isang error kung nabigo ang paglalaan
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::rc::Rc;
    ///
    /// let five = Rc::try_new(5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn try_new(value: T) -> Result<Rc<T>, AllocError> {
        // Mayroong isang implicit mahina na pointer na pagmamay-ari ng lahat ng mga malakas na payo, na tinitiyak na ang mahinang destructor ay hindi kailanman pinalaya ang paglalaan habang ang malakas na destructor ay tumatakbo, kahit na ang mahina na pointer ay nakaimbak sa loob ng malakas.
        //
        //
        //
        Ok(Self::from_inner(
            Box::leak(Box::try_new(RcBox { strong: Cell::new(1), weak: Cell::new(1), value })?)
                .into(),
        ))
    }

    /// Gumagawa ng isang bagong `Rc` na may mga uninitialized na nilalaman, na nagbabalik ng isang error kung nabigo ang paglalaan
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // Ipinagpaliban na pagsisimula:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// Gumagawa ng isang bagong `Rc` na may mga uninitialized na nilalaman, kasama ang memorya na pinunan ng `0` bytes, na nagbabalik ng isang error kung nabigo ang paglalaan
    ///
    ///
    /// Tingnan ang [`MaybeUninit::zeroed`][zeroed] para sa mga halimbawa ng wasto at maling paggamit ng pamamaraang ito.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// Bumubuo ng isang bagong `Pin<Rc<T>>`.
    /// Kung ang `T` ay hindi nagpapatupad ng `Unpin`, kung gayon ang `value` ay mai-pin sa memorya at hindi mailipat.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(value: T) -> Pin<Rc<T>> {
        unsafe { Pin::new_unchecked(Rc::new(value)) }
    }

    /// Ibinabalik ang panloob na halaga, kung ang `Rc` ay may eksaktong isang malakas na sanggunian.
    ///
    /// Kung hindi man, isang [`Err`] ay ibinalik na may parehong `Rc` na naipasa.
    ///
    ///
    /// Magtatagumpay ito kahit na may mga natitirang mahinang sanggunian.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new(3);
    /// assert_eq!(Rc::try_unwrap(x), Ok(3));
    ///
    /// let x = Rc::new(4);
    /// let _y = Rc::clone(&x);
    /// assert_eq!(*Rc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if Rc::strong_count(&this) == 1 {
            unsafe {
                let val = ptr::read(&*this); // kopyahin ang nilalaman na bagay

                // Ipahiwatig sa Weaks na hindi sila maaaring maitaguyod sa pamamagitan ng pagbawas ng malakas na bilang, at pagkatapos ay alisin ang ipinahiwatig na "strong weak" pointer habang hinahawakan din ang drop lohika sa pamamagitan lamang ng paggawa ng isang pekeng Mahina.
                //
                //
                //
                this.inner().dec_strong();
                let _weak = Weak { ptr: this.ptr };
                forget(this);
                Ok(val)
            }
        } else {
            Err(this)
        }
    }
}

impl<T> Rc<[T]> {
    /// Gumagawa ng isang bagong slice na binibilang ng sanggunian na may mga hindi unipormasyong nilalaman.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Ipinagpaliban na pagsisimula:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe { Rc::from_ptr(Rc::allocate_for_slice(len)) }
    }

    /// Gumagawa ng isang bagong slice na binibilang ng sanggunian na may mga hindi unipormasyong nilalaman, na ang memorya ay pinupunan ng `0` bytes.
    ///
    ///
    /// Tingnan ang [`MaybeUninit::zeroed`][zeroed] para sa mga halimbawa ng wasto at maling paggamit ng pamamaraang ito.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let values = Rc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut RcBox<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Rc<mem::MaybeUninit<T>> {
    /// Nag-convert sa `Rc<T>`.
    ///
    /// # Safety
    ///
    /// Tulad ng sa [`MaybeUninit::assume_init`], nasa sa tumatawag na garantiya na ang panloob na halaga ay talagang nasa isang inisyal na estado.
    ///
    /// Ang pagtawag nito kapag ang nilalaman ay hindi pa ganap na naisasimulan ay nagiging sanhi ng agarang hindi natukoy na pag-uugali.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Ipinagpaliban na pagsisimula:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<T> {
        Rc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Rc<[mem::MaybeUninit<T>]> {
    /// Nag-convert sa `Rc<[T]>`.
    ///
    /// # Safety
    ///
    /// Tulad ng sa [`MaybeUninit::assume_init`], nasa sa tumatawag na garantiya na ang panloob na halaga ay talagang nasa isang inisyal na estado.
    ///
    /// Ang pagtawag nito kapag ang nilalaman ay hindi pa ganap na naisasimulan ay nagiging sanhi ng agarang hindi natukoy na pag-uugali.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Ipinagpaliban na pagsisimula:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<[T]> {
        unsafe { Rc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Rc<T> {
    /// Naubos ang `Rc`, ibinabalik ang balot na pointer.
    ///
    /// Upang maiwasan ang isang pagtagas ng memorya ang pointer ay dapat na mai-convert pabalik sa isang `Rc` gamit ang [`Rc::from_raw`][from_raw].
    ///
    ///
    /// [from_raw]: Rc::from_raw
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// Nagbibigay ng isang hilaw na pointer sa data.
    ///
    /// Ang mga bilang ay hindi apektado sa anumang paraan at ang `Rc` ay hindi natupok.
    /// Ang pointer ay may bisa para sa hangga't may mga mabibilang na bilang sa `Rc`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let y = Rc::clone(&x);
    /// let x_ptr = Rc::as_ptr(&x);
    /// assert_eq!(x_ptr, Rc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(this.ptr);

        // KALIGTASAN: Hindi ito maaaring dumaan sa Deref::deref o Rc::inner dahil
        // ito ay kinakailangan upang mapanatili ang raw/mut probansya tulad ng hal
        // `get_mut` maaaring sumulat sa pamamagitan ng pointer pagkatapos makuha ang Rc sa pamamagitan ng `from_raw`.
        unsafe { ptr::addr_of_mut!((*ptr).value) }
    }

    /// Bumubuo ng isang `Rc<T>` mula sa isang hilaw na pointer.
    ///
    /// Ang raw pointer ay dapat na dating ibinalik ng isang tawag sa [`Rc<U>::into_raw`][into_raw] kung saan ang `U` ay dapat magkaroon ng parehong laki at pagkakahanay bilang `T`.
    /// Ito ay walang katotohanan totoo kung `U` ay `T`.
    /// Tandaan na kung ang `U` ay hindi `T` ngunit may parehong laki at pagkakahanay, ito ay karaniwang tulad ng paglilipat ng mga sanggunian ng iba't ibang uri.
    /// Tingnan ang [`mem::transmute`][transmute] para sa karagdagang impormasyon tungkol sa kung anong mga paghihigpit ang nalalapat sa kasong ito.
    ///
    /// Ang gumagamit ng `from_raw` ay dapat tiyakin na ang isang tukoy na halaga ng `T` ay isang beses lamang na bumagsak.
    ///
    /// Ang pag-andar na ito ay hindi ligtas dahil ang hindi wastong paggamit ay maaaring humantong sa kaligtasan ng memorya, kahit na ang naibalik na `Rc<T>` ay hindi kailanman na-access.
    ///
    /// [into_raw]: Rc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    ///
    /// unsafe {
    ///     // I-convert pabalik sa isang `Rc` upang maiwasan ang pagtulo.
    ///     let x = Rc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // Ang mga karagdagang tawag sa `Rc::from_raw(x_ptr)` ay magiging hindi ligtas sa memorya.
    /// }
    ///
    /// // Ang memorya ay napalaya nang ang `x` ay lumabas sa saklaw sa itaas, kaya't ang `x_ptr` ay nakalawit na ngayon!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        let offset = unsafe { data_offset(ptr) };

        // Baligtarin ang offset upang mahanap ang orihinal na RcBox.
        let rc_ptr =
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) };

        unsafe { Self::from_ptr(rc_ptr) }
    }

    /// Lumilikha ng isang bagong [`Weak`] pointer sa paglalaan na ito.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        this.inner().inc_weak();
        // Tiyaking hindi kami lumilikha ng isang nakalawit na Mahina
        debug_assert!(!is_dangling(this.ptr.as_ptr()));
        Weak { ptr: this.ptr }
    }

    /// Nakukuha ang bilang ng mga [`Weak`] pointer sa paglalaan na ito.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _weak_five = Rc::downgrade(&five);
    ///
    /// assert_eq!(1, Rc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        this.inner().weak() - 1
    }

    /// Nakukuha ang bilang ng mga malakas na (`Rc`) pointer sa paglalaan na ito.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _also_five = Rc::clone(&five);
    ///
    /// assert_eq!(2, Rc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong()
    }

    /// Ibinabalik ang `true` kung walang ibang mga pointer ng `Rc` o [`Weak`] sa paglalaan na ito.
    ///
    #[inline]
    fn is_unique(this: &Self) -> bool {
        Rc::weak_count(this) == 0 && Rc::strong_count(this) == 1
    }

    /// Nagbabalik ng isang nababagabag na sanggunian sa ibinigay na `Rc`, kung walang iba pang mga `Rc` o [`Weak`] pointers sa parehong paglalaan.
    ///
    ///
    /// Ibinabalik ang [`None`] kung hindi man, sapagkat hindi ligtas na i-mutate ang isang ibinahaging halaga.
    ///
    /// Tingnan din ang [`make_mut`][make_mut], na kung saan ay [`clone`][clone] ang panloob na halaga kapag may iba pang mga payo.
    ///
    /// [make_mut]: Rc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(3);
    /// *Rc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Rc::clone(&x);
    /// assert!(Rc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if Rc::is_unique(this) { unsafe { Some(Rc::get_mut_unchecked(this)) } } else { None }
    }

    /// Nagbabalik ng isang nababagabag na sanggunian sa ibinigay na `Rc`, nang walang anumang tseke.
    ///
    /// Tingnan din ang [`get_mut`], na kung saan ay ligtas at gumagawa ng mga naaangkop na tseke.
    ///
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Safety
    ///
    /// Anumang iba pang mga `Rc` o [`Weak`] payo sa parehong paglalaan ay hindi dapat dereferenced para sa tagal ng ibinalik na humiram.
    ///
    /// Ito ay walang kabuluhan ang kaso kung walang mga naturang mga payo na mayroon, halimbawa kaagad pagkatapos ng `Rc::new`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(String::new());
    /// unsafe {
    ///     Rc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // Maingat kami na *hindi* lumikha ng isang sanggunian na sumasaklaw sa mga patlang ng "count", dahil makasalungat ito sa mga pag-access sa mga bilang ng sanggunian (hal.
        // ni `Weak`).
        unsafe { &mut (*this.ptr.as_ptr()).value }
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// Ibinabalik ang `true` kung ang dalawang `Rc` ay tumuturo sa parehong paglalaan (sa isang ugat na katulad ng [`ptr::eq`]).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let same_five = Rc::clone(&five);
    /// let other_five = Rc::new(5);
    ///
    /// assert!(Rc::ptr_eq(&five, &same_five));
    /// assert!(!Rc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: Clone> Rc<T> {
    /// Gumagawa ng isang nababagabag na sanggunian sa ibinigay na `Rc`.
    ///
    /// Kung may iba pang mga pointer ng `Rc` sa parehong paglalaan, pagkatapos ang `make_mut` ay [`clone`] ang panloob na halaga sa isang bagong paglalaan upang matiyak ang natatanging pagmamay-ari.
    /// Ito ay tinukoy din bilang clone-on-write.
    ///
    /// Kung walang iba pang mga pointer ng `Rc` sa paglalaan na ito, pagkatapos ay ang mga pointer ng [`Weak`] sa paglalaan na ito ay aalisin.
    ///
    /// Tingnan din ang [`get_mut`], na mabibigo kaysa sa pag-clone.
    ///
    /// [`clone`]: Clone::clone
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(5);
    ///
    /// *Rc::make_mut(&mut data) += 1;        // Hindi mag-clone ng kahit ano
    /// let mut other_data = Rc::clone(&data);    // Hindi makakapag-clone ng panloob na data
    /// *Rc::make_mut(&mut data) += 1;        // Pag-clone ng panloob na data
    /// *Rc::make_mut(&mut data) += 1;        // Hindi mag-clone ng kahit ano
    /// *Rc::make_mut(&mut other_data) *= 2;  // Hindi mag-clone ng kahit ano
    ///
    /// // Ngayon ang `data` at `other_data` ay tumuturo sa iba't ibang mga paglalaan.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    /// [`Weak`] tatanggalin ang mga payo:
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(75);
    /// let weak = Rc::downgrade(&data);
    ///
    /// assert!(75 == *data);
    /// assert!(75 == *weak.upgrade().unwrap());
    ///
    /// *Rc::make_mut(&mut data) += 1;
    ///
    /// assert!(76 == *data);
    /// assert!(weak.upgrade().is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        if Rc::strong_count(this) != 1 {
            // Kailangan i-clone ang data, may iba pang mga Rcs.
            // Paunang maglaan ng memorya upang payagan ang pagsulat nang direkta ng na-clone na halaga.
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = rc.assume_init();
            }
        } else if Rc::weak_count(this) != 0 {
            // Maaari lamang nakawin ang data, ang natitira lamang ay Weaks
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);

                this.inner().dec_strong();
                // Alisin ang ipinahiwatig na malakas na mahina na ref (hindi na kailangang gumawa ng pekeng Mahina dito-alam namin na ang ibang mga Weaks ay maaaring malinis para sa atin)
                //
                this.inner().dec_weak();
                ptr::write(this, rc.assume_init());
            }
        }
        // Ang hindi ligtas na ito ay ok dahil ginagarantiyahan namin na ang pointer ay ibinalik ang *tanging* pointer na ibabalik sa T.
        // Ang aming bilang ng sanggunian ay garantisadong maging 1 sa puntong ito, at kinakailangan namin ang `Rc<T>` mismo na maging `mut`, kaya binabalik namin ang tanging posibleng sanggunian sa paglalaan.
        //
        //
        //
        unsafe { &mut this.ptr.as_mut().value }
    }
}

impl Rc<dyn Any> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// Subukang i-downcast ang `Rc<dyn Any>` sa isang kongkretong uri.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::rc::Rc;
    ///
    /// fn print_if_string(value: Rc<dyn Any>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Rc::new(my_string));
    /// print_if_string(Rc::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Rc<T>, Rc<dyn Any>> {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<RcBox<T>>();
            forget(self);
            Ok(Rc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T: ?Sized> Rc<T> {
    /// Naglalaan ng isang `RcBox<T>` na may sapat na puwang para sa isang posibleng na-unsized na panloob na halaga kung saan ang halaga ay may ibinigay na layout.
    ///
    /// Ang pagpapaandar `mem_to_rcbox` ay tinatawag na may data pointer at dapat bumalik sa isang (potensyal na fat)-pointer para sa `RcBox<T>`.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> *mut RcBox<T> {
        // Kalkulahin ang layout gamit ang ibinigay na layout ng halaga.
        // Dati, ang layout ay kinakalkula sa expression na `&*(ptr as* const RcBox<T>)`, ngunit lumikha ito ng isang maling pagkakakilanlan (tingnan ang #54908).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Rc::try_allocate_for_layout(value_layout, allocate, mem_to_rcbox)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// Naglalaan ng isang `RcBox<T>` na may sapat na puwang para sa isang posibleng na-unsized na panloob na halaga kung saan ang halaga ay may ibinigay na layout, na nagbabalik ng isang error kung nabigo ang paglalaan.
    ///
    ///
    /// Ang pagpapaandar `mem_to_rcbox` ay tinatawag na may data pointer at dapat bumalik sa isang (potensyal na fat)-pointer para sa `RcBox<T>`.
    ///
    ///
    #[inline]
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> Result<*mut RcBox<T>, AllocError> {
        // Kalkulahin ang layout gamit ang ibinigay na layout ng halaga.
        // Dati, ang layout ay kinakalkula sa expression na `&*(ptr as* const RcBox<T>)`, ngunit lumikha ito ng isang maling pagkakakilanlan (tingnan ang #54908).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();

        // Maglaan para sa layout.
        let ptr = allocate(layout)?;

        // Pasimulan ang RcBox
        let inner = mem_to_rcbox(ptr.as_non_null_ptr().as_ptr());
        unsafe {
            debug_assert_eq!(Layout::for_value(&*inner), layout);

            ptr::write(&mut (*inner).strong, Cell::new(1));
            ptr::write(&mut (*inner).weak, Cell::new(1));
        }

        Ok(inner)
    }

    /// Allocates ng isang `RcBox<T>` na may sapat na espasyo para sa unsized panloob na halaga
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut RcBox<T> {
        // Maglaan para sa mga `RcBox<T>` gamit ang ibinigay na halaga.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut RcBox<T>).set_ptr_value(mem),
            )
        }
    }

    fn from_box(v: Box<T>) -> Rc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // Kopyahin ang halaga bilang mga byte
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).value as *mut _ as *mut u8,
                value_size,
            );

            // Libre ang paglalaan nang hindi inaalis ang mga nilalaman nito
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Rc<[T]> {
    /// Naglalaan ng `RcBox<[T]>` na may ibinigay na haba.
    unsafe fn allocate_for_slice(len: usize) -> *mut RcBox<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut RcBox<[T]>,
            )
        }
    }

    /// Kopyahin ang mga elemento mula sa hiwa sa bagong inilalaan na Rc <\[T\]>
    ///
    /// Hindi ligtas dahil ang tumatawag ay dapat na kumuha ng pagmamay-ari o magbigkis ng `T: Copy`
    unsafe fn copy_from_slice(v: &[T]) -> Rc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());
            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).value as *mut [T] as *mut T, v.len());
            Self::from_ptr(ptr)
        }
    }

    /// Bumubuo ng isang `Rc<[T]>` mula sa isang iterator na alam na may isang tiyak na laki.
    ///
    /// Ang pag-uugali ay hindi natukoy kung ang laki ay mali.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Rc<[T]> {
        // Panic bantay habang ang pag-clone ng mga elemento ng T.
        // Sa kaganapan ng isang panic, ang mga elemento na nakasulat sa bagong RcBox ay mahuhulog, pagkatapos ay mapalaya ang memorya.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // Ituro ang unang elemento
            let elems = &mut (*ptr).value as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // Malinaw ang lahatKalimutan ang guwardiya upang hindi nito mapalaya ang bagong RcBox.
            forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// Ang pagdadalubhasa trait na ginagamit para sa `From<&[T]>`.
trait RcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Rc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Rc<T> {
    type Target = T;

    #[inline(always)]
    fn deref(&self) -> &T {
        &self.inner().value
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Rc<T> {
    /// Patak ang `Rc`.
    ///
    /// Babawasan nito ang malakas na bilang ng sanggunian.
    /// Kung ang malakas na bilang ng sanggunian ay umabot sa zero kung gayon ang tanging iba pang mga sanggunian (kung mayroon man) ay [`Weak`], kaya't `drop` namin ang panloob na halaga.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Rc::new(Foo);
    /// let foo2 = Rc::clone(&foo);
    ///
    /// drop(foo);    // Hindi naka-print kahit ano
    /// drop(foo2);   // Nagpi-print "dropped!"
    /// ```
    fn drop(&mut self) {
        unsafe {
            self.inner().dec_strong();
            if self.inner().strong() == 0 {
                // sirain ang nilalaman na bagay
                ptr::drop_in_place(Self::get_mut_unchecked(self));

                // alisin ang implicit "strong weak" pointer ngayong nawasak namin ang mga nilalaman.
                //
                self.inner().dec_weak();

                if self.inner().weak() == 0 {
                    Global.deallocate(self.ptr.cast(), Layout::for_value(self.ptr.as_ref()));
                }
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Rc<T> {
    /// Gumagawa ng isang clone ng `Rc` pointer.
    ///
    /// Lumilikha ito ng isa pang pointer sa parehong paglalaan, pagdaragdag ng malakas na bilang ng sanggunian.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let _ = Rc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Rc<T> {
        self.inner().inc_strong();
        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Rc<T> {
    /// Lumilikha ng isang bagong `Rc<T>`, na may halagang `Default` para sa `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x: Rc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    #[inline]
    fn default() -> Rc<T> {
        Rc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait RcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Rc<T>) -> bool;
    fn ne(&self, other: &Rc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    default fn eq(&self, other: &Rc<T>) -> bool {
        **self == **other
    }

    #[inline]
    default fn ne(&self, other: &Rc<T>) -> bool {
        **self != **other
    }
}

// Hack upang payagan ang pagdadalubhasa sa `Eq` kahit na ang `Eq` ay may isang pamamaraan.
#[rustc_unsafe_specialization_marker]
pub(crate) trait MarkerEq: PartialEq<Self> {}

impl<T: Eq> MarkerEq for T {}

/// Ginagawa namin ang pagdadalubhasa dito, at hindi bilang isang mas pangkalahatang pag-optimize sa `&T`, dahil sa kabilang banda ay magdagdag ng gastos sa lahat ng mga pagsusuri sa pagkakapantay-pantay sa mga ref.
/// Ipinapalagay namin na ang `Rc`s ay ginagamit upang mag-imbak ng malalaking halaga, na mabagal sa pag-clone, ngunit mabigat din upang suriin ang pagkakapantay-pantay, na nagiging sanhi ng mas madaling pagbayad ng gastos na ito.
///
/// Malamang na mayroon ding dalawang `Rc` clone, na tumuturo sa parehong halaga, kaysa sa dalawang `&T`s.
///
/// Magagawa lamang namin ito kapag ang `T: Eq` bilang isang `PartialEq` ay maaaring sadyang hindi masugpo.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + MarkerEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        Rc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        !Rc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Rc<T> {
    /// Pagkakapantay-pantay para sa dalawang `Rc`s.
    ///
    /// Ang dalawang `Rc` ay pantay kung ang kanilang panloob na halaga ay pantay, kahit na nakaimbak sila sa iba't ibang paglalaan.
    ///
    /// Kung ang `T` ay nagpapatupad din ng `Eq` (nagpapahiwatig ng reflexivity ng pagkakapantay-pantay), dalawang `Rc` na tumuturo sa parehong paglalaan ay palaging pantay.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five == Rc::new(5));
    /// ```
    ///
    ///
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        RcEqIdent::eq(self, other)
    }

    /// Hindi pagkakapantay-pantay para sa dalawang `Rc`s.
    ///
    /// Dalawang `Rc`s ay hindi pantay kung ang kanilang panloob na halaga ay hindi pantay.
    ///
    /// Kung ang `T` ay nagpapatupad din ng `Eq` (na nagpapahiwatig ng reflexivity ng pagkakapantay-pantay), dalawang `Rc` na tumuturo sa parehong paglalaan ay hindi kailanman pantay.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five != Rc::new(6));
    /// ```
    ///
    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        RcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Rc<T> {
    /// Bahagyang paghahambing para sa dalawang `Rc`s.
    ///
    /// Ang dalawa ay inihambing sa pamamagitan ng pagtawag sa `partial_cmp()` sa kanilang panloob na mga halaga.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Rc::new(6)));
    /// ```
    #[inline(always)]
    fn partial_cmp(&self, other: &Rc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// Mas mababa kaysa sa paghahambing para sa dalawang `Rc`s.
    ///
    /// Ang dalawa ay inihambing sa pamamagitan ng pagtawag sa `<` sa kanilang panloob na mga halaga.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five < Rc::new(6));
    /// ```
    #[inline(always)]
    fn lt(&self, other: &Rc<T>) -> bool {
        **self < **other
    }

    /// 'Mas mababa sa o katumbas ng' paghahambing para sa dalawang `Rc`s.
    ///
    /// Ang dalawa ay inihambing sa pamamagitan ng pagtawag sa `<=` sa kanilang panloob na mga halaga.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five <= Rc::new(5));
    /// ```
    #[inline(always)]
    fn le(&self, other: &Rc<T>) -> bool {
        **self <= **other
    }

    /// Mas mahusay kaysa sa paghahambing para sa dalawang `Rc`s.
    ///
    /// Ang dalawa ay inihambing sa pamamagitan ng pagtawag sa `>` sa kanilang panloob na mga halaga.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five > Rc::new(4));
    /// ```
    #[inline(always)]
    fn gt(&self, other: &Rc<T>) -> bool {
        **self > **other
    }

    /// 'Mas malaki kaysa sa o katumbas ng' paghahambing para sa dalawang `Rc`s.
    ///
    /// Ang dalawa ay inihambing sa pamamagitan ng pagtawag sa `>=` sa kanilang panloob na mga halaga.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five >= Rc::new(5));
    /// ```
    #[inline(always)]
    fn ge(&self, other: &Rc<T>) -> bool {
        **self >= **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Rc<T> {
    /// Paghahambing para sa dalawang `Rc`s.
    ///
    /// Ang dalawa ay inihambing sa pamamagitan ng pagtawag sa `cmp()` sa kanilang panloob na mga halaga.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Rc::new(6)));
    /// ```
    #[inline]
    fn cmp(&self, other: &Rc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Rc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Rc<T> {
    fn from(t: T) -> Self {
        Rc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Rc<[T]> {
    /// Maglaan ng isang slice na binibilang ng sanggunian at punan ito sa pamamagitan ng pag-clone ng mga item ng 'v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Rc<[i32]> = Rc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Rc<[T]> {
        <Self as RcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Rc<str> {
    /// Magtalaga ng isang slice ng string na binibilang ng sanggunian at kopyahin ang `v` dito.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let shared: Rc<str> = Rc::from("statue");
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Rc<str> {
        let rc = Rc::<[u8]>::from(v.as_bytes());
        unsafe { Rc::from_raw(Rc::into_raw(rc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Rc<str> {
    /// Magtalaga ng isang slice ng string na binibilang ng sanggunian at kopyahin ang `v` dito.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: String = "statue".to_owned();
    /// let shared: Rc<str> = Rc::from(original);
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Rc<str> {
        Rc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Rc<T> {
    /// Ilipat ang isang boxed bagay sa isang bagong, reference binibilang, allocation.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<i32> = Box::new(1);
    /// let shared: Rc<i32> = Rc::from(original);
    /// assert_eq!(1, *shared);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Rc<T> {
        Rc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Rc<[T]> {
    /// Maglaan ng isang slice na binibilang ng sanggunian at ilipat dito ang mga item ng `v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<Vec<i32>> = Box::new(vec![1, 2, 3]);
    /// let shared: Rc<Vec<i32>> = Rc::from(original);
    /// assert_eq!(vec![1, 2, 3], *shared);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Rc<[T]> {
        unsafe {
            let rc = Rc::copy_from_slice(&v);

            // Payagan ang Vec na palayain ang memorya nito, ngunit hindi sirain ang mga nilalaman nito
            v.set_len(0);

            rc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Rc<B>
where
    B: ToOwned + ?Sized,
    Rc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Rc<B> {
        match cow {
            Cow::Borrowed(s) => Rc::from(s),
            Cow::Owned(s) => Rc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Rc<[T]>> for Rc<[T; N]> {
    type Error = Rc<[T]>;

    fn try_from(boxed_slice: Rc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Rc::from_raw(Rc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Rc<[T]> {
    /// Kinukuha ang bawat elemento sa `Iterator` at kinokolekta ito sa isang `Rc<[T]>`.
    ///
    /// # Mga katangian sa pagganap
    ///
    /// ## Ang pangkalahatang kaso
    ///
    /// Sa pangkalahatang kaso, ang pagkolekta sa `Rc<[T]>` ay ginagawa sa pamamagitan ng unang pagkolekta sa isang `Vec<T>`.Iyon ay, kapag sumusulat ng sumusunod:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// ito behaves bilang kung kami ay sumulat:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // Ang unang hanay ng mga paglalaan ay nangyayari dito.
    ///     .into(); // Ang isang pangalawang paglalaan para sa `Rc<[T]>` ay nangyayari dito.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// Ito ay maglalaan ng maraming beses kung kinakailangan para sa pagbuo ng `Vec<T>` at pagkatapos ay maglalaan ito ng isang beses para sa pag-on sa `Vec<T>` sa `Rc<[T]>`.
    ///
    ///
    /// ## Iterator na alam ang haba
    ///
    /// Kapag ang iyong `Iterator` ay nagpapatupad ng `TrustedLen` at eksaktong sukat, isang solong paglalaan ang gagawin para sa `Rc<[T]>`.Halimbawa:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).collect(); // Isang solong paglalaan lamang ang nangyayari dito.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToRcSlice::to_rc_slice(iter.into_iter())
    }
}

/// Ang pagdadalubhasa na ginagamit ng trait para sa pagkolekta sa `Rc<[T]>`.
trait ToRcSlice<T>: Iterator<Item = T> + Sized {
    fn to_rc_slice(self) -> Rc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToRcSlice<T> for I {
    default fn to_rc_slice(self) -> Rc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToRcSlice<T> for I {
    fn to_rc_slice(self) -> Rc<[T]> {
        // Ito ang kaso para sa isang `TrustedLen` iterator.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // KALIGTASAN: Kailangan naming tiyakin na ang iterator ay may eksaktong haba at mayroon kami.
                Rc::from_iter_exact(self, low)
            }
        } else {
            // Bumalik sa normal na pagpapatupad.
            self.collect::<Vec<T>>().into()
        }
    }
}

/// `Weak` ay isang bersyon ng [`Rc`] na nagtataglay ng isang hindi pagmamay-ari na sanggunian sa pinamamahalaang paglalaan.Ang paglalaan ay na-access sa pamamagitan ng pagtawag sa [`upgrade`] sa `Weak` pointer, na nagbabalik ng isang [`Option`]`<`[`Rc`] `<T>>`.
///
/// Dahil ang isang sanggunian na `Weak` ay hindi binibilang patungo sa pagmamay-ari, hindi nito pipigilan ang halagang nakaimbak sa alokasyon mula sa pagbagsak, at ang `Weak` mismo ay hindi gumagawa ng mga garantiya tungkol sa halaga na naroroon pa rin.
/// Kaya't maibabalik nito ang [`None`] kapag [`upgrade`] d.
/// Gayunpaman, tandaan na ang isang sanggunian na `Weak`*ay* pinipigilan ang paglalaan mismo (ang backing store) mula sa ma-deallocated.
///
/// Ang isang `Weak` pointer ay kapaki-pakinabang para sa pagpapanatili ng isang pansamantalang sanggunian sa paglalaan na pinamamahalaan ng [`Rc`] nang hindi pinipigilan ang panloob na halaga mula sa pagbagsak.
/// Ginagamit din ito upang maiwasan ang mga pabilog na sanggunian sa pagitan ng mga payo ng [`Rc`], dahil ang kapwa pagmamay-ari ng mga sanggunian ay hindi kailanman papayagan ang alinman sa [`Rc`] na mahulog.
/// Halimbawa, ang isang puno ay maaaring magkaroon ng malakas na [`Rc`] pointers mula sa mga node ng magulang hanggang sa mga bata, at `Weak` pointers mula sa mga bata pabalik sa kanilang mga magulang.
///
/// Ang tipikal na paraan upang makakuha ng isang `Weak` pointer ay upang tawagan ang [`Rc::downgrade`].
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
///
///
#[stable(feature = "rc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // Ito ay isang `NonNull` upang payagan ang pag-optimize ng laki ng ganitong uri sa mga enum, ngunit hindi ito kinakailangang isang wastong pointer.
    //
    // `Weak::new` Itinatakda ito sa `usize::MAX` upang hindi na kailanganin na maglaan ng puwang sa tambak.
    // Iyon ay hindi isang halaga na magkakaroon ng isang tunay na pointer dahil ang RcBox ay may pagkakahanay ng hindi bababa sa 2.
    // Posible lamang ito kapag `T: Sized`;hindi pinalaki ang XSX na hindi naka-unsize.
    //
    ptr: NonNull<RcBox<T>>,
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Send for Weak<T> {}
#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

impl<T> Weak<T> {
    /// Bumubuo ng isang bagong `Weak<T>`, nang hindi naglalaan ng anumang memorya.
    /// Ang pagtawag sa [`upgrade`] sa halaga ng pagbabalik ay laging nagbibigay ng [`None`].
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut RcBox<T>).expect("MAX is not 0") }
    }
}

pub(crate) fn is_dangling<T: ?Sized>(ptr: *mut T) -> bool {
    let address = ptr as *mut () as usize;
    address == usize::MAX
}

/// Uri ng helper upang payagan ang pag-access sa mga bilang ng sanggunian nang hindi gumagawa ng anumang mga pagpapahayag tungkol sa patlang ng data.
///
struct WeakInner<'a> {
    weak: &'a Cell<usize>,
    strong: &'a Cell<usize>,
}

impl<T: ?Sized> Weak<T> {
    /// Nagbabalik ng isang hilaw na pointer sa bagay na `T` na itinuro ng `Weak<T>` na ito.
    ///
    /// Ang pointer ay may bisa lamang kung mayroong ilang mga malakas na sanggunian.
    /// Ang pointer ay maaaring nakabitin, hindi nakahanay o kahit [`null`] kung hindi man.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::ptr;
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// // Parehong tumuturo sa parehong bagay
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // Ang malakas dito ay pinapanatili itong buhay, kaya maaari pa rin nating ma-access ang object.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // Pero hindi na ngayon.
    /// // Maaari naming gawin weak.as_ptr(), ngunit ang pag-access sa pointer ay hahantong sa hindi natukoy na pag-uugali.
    /// // assert_eq! ("hello", hindi ligtas na {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // Kung nakabitin ang pointer, ibabalik namin nang direkta ang bantay.
            // Hindi ito maaaring maging isang wastong address ng payload, dahil ang payload ay hindi bababa sa pagkakahanay sa RcBox (usize).
            ptr as *const T
        } else {
            // KALIGTASAN: kung ang__langling ay nagbabalik ng hindi totoo, kung gayon ang pointer ay hindi maaalis.
            // Ang payload ay maaaring mahulog sa puntong ito, at kailangan naming mapanatili ang kakayahang magamit, kaya't gumamit ng hilaw na pagmamanipula ng pointer.
            //
            unsafe { ptr::addr_of_mut!((*ptr).value) }
        }
    }

    /// Naubos ang `Weak<T>` at ginawang isang raw pointer.
    ///
    /// Ito ay nagko-convert ng mahina pointer sa isang raw pointer, habang pinapanatili ang pagmamay-ari ng isang mahinang sanggunian (ang mahinang bilang ay hindi binago ng operasyong ito).
    /// Maaari itong ibalik sa `Weak<T>` na may [`from_raw`].
    ///
    /// Ang parehong mga paghihigpit ng pag-access sa target ng pointer tulad ng sa [`as_ptr`] ay nalalapat.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Rc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Rc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// Nag-convert ng isang hilaw na pointer na dati nang nilikha ng [`into_raw`] pabalik sa `Weak<T>`.
    ///
    /// Maaari itong magamit upang ligtas na makakuha ng isang malakas na sanggunian (sa pamamagitan ng pagtawag sa [`upgrade`] sa paglaon) o upang makitungo sa mahinang bilang sa pamamagitan ng pagbagsak ng `Weak<T>`.
    ///
    /// Kinakailangan ang pagmamay-ari ng isang mahinang sanggunian (maliban sa mga payo na nilikha ng [`new`], dahil ang mga ito ay hindi nagmamay-ari ng anupaman; gumagana pa rin ang pamamaraan sa kanila).
    ///
    /// # Safety
    ///
    /// Ang pointer ay dapat na nagmula sa [`into_raw`] at dapat pa ring pagmamay-ari ang potensyal na mahinang sanggunian nito.
    ///
    /// Pinapayagan ang malakas na bilang na maging 0 sa oras ng pagtawag nito.
    /// Gayunpaman, kinukuha ang pagmamay-ari ng isang mahinang sanggunian na kasalukuyang kinakatawan bilang isang hilaw na pointer (ang mahinang bilang ay hindi binago ng operasyong ito) at samakatuwid dapat itong ipares sa isang nakaraang tawag sa [`into_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    ///
    /// let raw_1 = Rc::downgrade(&strong).into_raw();
    /// let raw_2 = Rc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Rc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Rc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // Pagbawas ng huling mahina na bilang.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`new`]: Weak::new
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // Tingnan ang Weak::as_ptr para sa konteksto kung paano nakuha ang input pointer.

        let ptr = if is_dangling(ptr as *mut T) {
            // Ito ay isang nakalawit Mahinang.
            ptr as *mut RcBox<T>
        } else {
            // Kung hindi man, ginagarantiyahan namin na ang pointer ay nagmula sa isang nondangling Weak.
            // KALIGTASAN: ang data_offset ay ligtas na tawagan, dahil ang ptr ay tumutukoy sa isang tunay (potensyal na bumagsak) T.
            let offset = unsafe { data_offset(ptr) };
            // Sa gayon, binabaligtad namin ang offset upang makuha ang buong RcBox.
            // KALIGTASAN: ang pointer ay nagmula sa isang Mahina, kaya't ang offset na ito ay ligtas.
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // KALIGTASAN: nakuhang muli namin ang orihinal na Weak pointer, kaya makalikha ng Mahina.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }

    /// Mga pagtatangka upang i-upgrade ang `Weak` pointer sa isang [`Rc`], naantala ang pagbaba ng panloob na halaga kung matagumpay.
    ///
    ///
    /// Ibinabalik ang [`None`] kung ang panloob na halaga ay nai-drop na.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    ///
    /// let strong_five: Option<Rc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // Wasakin ang lahat ng malakas na mga payo.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Rc<T>> {
        let inner = self.inner()?;
        if inner.strong() == 0 {
            None
        } else {
            inner.inc_strong();
            Some(Rc::from_inner(self.ptr))
        }
    }

    /// Nakukuha ang bilang ng mga malakas na (`Rc`) pointer na tumuturo sa paglalaan na ito.
    ///
    /// Kung ang `self` ay nilikha gamit ang [`Weak::new`], ibabalik nito ang 0.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong() } else { 0 }
    }

    /// Nakukuha ang bilang ng mga `Weak` pointer na tumuturo sa paglalaan na ito.
    ///
    /// Kung walang mananatiling malakas na payo, ibabalik ito sa zero.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                if inner.strong() > 0 {
                    inner.weak() - 1 // ibawas ang ipinahiwatig na mahina na ptr
                } else {
                    0
                }
            })
            .unwrap_or(0)
    }

    /// Ibinabalik `None` kapag ang pointer ay nakabitin at walang inilalaan `RcBox`, (ibig sabihin, kapag ang `Weak` na ito ay nilikha ng `Weak::new`).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // Maingat kaming *hindi* lumikha ng isang sanggunian na sumasaklaw sa patlang "data", dahil ang patlang ay maaaring na-mutate nang sabay-sabay (halimbawa, kung ang huling `Rc` ay nahulog, ang patlang ng data ay mahuhulog sa lugar).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// Ibinabalik ang `true` kung ang dalawang `Mahina` ay tumuturo sa parehong paglalaan (katulad ng [`ptr::eq`]), o kung pareho ay hindi tumuturo sa anumang paglalaan (sapagkat nilikha ang mga ito sa `Weak::new()`).
    ///
    ///
    /// # Notes
    ///
    /// Dahil pinaghahambing nito ang mga pahiwatig nangangahulugan ito na ang `Weak::new()` ay pantay-pantay sa bawat isa, kahit na hindi sila tumuturo sa anumang paglalaan.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let first_rc = Rc::new(5);
    /// let first = Rc::downgrade(&first_rc);
    /// let second = Rc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(5);
    /// let third = Rc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// Ang paghahambing ng `Weak::new`.
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(());
    /// let third = Rc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// Patak ang `Weak` pointer.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Rc::new(Foo);
    /// let weak_foo = Rc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // Hindi naka-print kahit ano
    /// drop(foo);        // Nagpi-print "dropped!"
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        inner.dec_weak();
        // ang mahinang bilang ay nagsisimula sa 1, at mapupunta lamang sa zero kung ang lahat ng mga malakas na payo ay nawala.
        //
        if inner.weak() == 0 {
            unsafe {
                Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr()));
            }
        }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// Gumagawa ng isang clone ng `Weak` pointer na tumuturo sa parehong paglalaan.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let weak_five = Rc::downgrade(&Rc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        if let Some(inner) = self.inner() {
            inner.inc_weak()
        }
        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// Bumubuo ng isang bagong `Weak<T>`, naglalaan ng memorya para sa `T` nang hindi pa pinasimulan ito.
    /// Ang pagtawag sa [`upgrade`] sa halaga ng pagbabalik ay laging nagbibigay ng [`None`].
    ///
    /// [`None`]: Option
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

// NOTE: Nagcheck_add kami dito upang makitungo nang ligtas sa mem::forget.Sa partikular
// kung ikaw ay mem::forget Rcs (o Weaks), ang ref-count ay maaaring umapaw, at pagkatapos ay maaari mong palayain ang paglalaan habang ang natitirang Rcs (o Weaks) ay mayroon.
//
// Nag-abort kami dahil ito ay isang masamang sitwasyon na wala kaming pakialam sa kung ano ang mangyayari-walang tunay na programa ang dapat maranasan ito.
//
// Ito ay dapat na may negligible overhead dahil hindi mo talaga kailangang i-clone ang mga ito sa Rust salamat sa pagmamay-ari at mga move-semantics.
//
//

#[doc(hidden)]
trait RcInnerPtr {
    fn weak_ref(&self) -> &Cell<usize>;
    fn strong_ref(&self) -> &Cell<usize>;

    #[inline]
    fn strong(&self) -> usize {
        self.strong_ref().get()
    }

    #[inline]
    fn inc_strong(&self) {
        let strong = self.strong();

        // Nais naming mag-abort sa overflow sa halip na ihulog ang halaga.
        // Ang bilang ng sanggunian ay hindi kailanman magiging zero kapag tinawag ito;
        // gayunpaman, nagsingit kami ng isang pagpapalaglag dito upang ipahiwatig ang LLVM sa isang hindi nasagot na pag-optimize.
        //
        if strong == 0 || strong == usize::MAX {
            abort();
        }
        self.strong_ref().set(strong + 1);
    }

    #[inline]
    fn dec_strong(&self) {
        self.strong_ref().set(self.strong() - 1);
    }

    #[inline]
    fn weak(&self) -> usize {
        self.weak_ref().get()
    }

    #[inline]
    fn inc_weak(&self) {
        let weak = self.weak();

        // Nais naming mag-abort sa overflow sa halip na ihulog ang halaga.
        // Ang bilang ng sanggunian ay hindi kailanman magiging zero kapag tinawag ito;
        // gayunpaman, nagsingit kami ng isang pagpapalaglag dito upang ipahiwatig ang LLVM sa isang hindi nasagot na pag-optimize.
        //
        if weak == 0 || weak == usize::MAX {
            abort();
        }
        self.weak_ref().set(weak + 1);
    }

    #[inline]
    fn dec_weak(&self) {
        self.weak_ref().set(self.weak() - 1);
    }
}

impl<T: ?Sized> RcInnerPtr for RcBox<T> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        &self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        &self.strong
    }
}

impl<'a> RcInnerPtr for WeakInner<'a> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        self.strong
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Rc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Rc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Rc<T> {}

/// Kunin ang offset sa loob ng isang `RcBox` para sa payload sa likod ng isang pointer.
///
/// # Safety
///
/// Ang pointer ay dapat na magturo sa (at may wastong metadata para sa) isang dating wastong halimbawa ng T, ngunit ang T ay pinapayagan na mahulog.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // Ihanay ang hindi pinagsamang halaga sa dulo ng RcBox.
    // Dahil ang RcBox ay repr(C), palagi itong magiging huling larangan sa memorya.
    // KALIGTASAN: yamang ang tanging mga hindi naisasadyang uri na posible ay mga hiwa, mga bagay na trait,
    // at mga panlabas na uri, ang kinakailangan sa kaligtasan ng pag-input ay kasalukuyang sapat upang masiyahan ang mga kinakailangan ng align_of_val_raw;ito ay isang detalye ng pagpapatupad ng wika na maaaring hindi umaasa sa labas ng std.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<RcBox<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}