#![stable(feature = "rust1", since = "1.0.0")]

//! Thread-ligtas na mga pahiwatig ng pagbanggit ng sanggunian.
//!
//! Tingnan ang dokumentasyon ng [`Arc<T>`][Arc] para sa higit pang mga detalye.

use core::any::Any;
use core::borrow;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::hint;
use core::intrinsics::abort;
use core::iter;
use core::marker::{PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;
use core::sync::atomic;
use core::sync::atomic::Ordering::{Acquire, Relaxed, Release, SeqCst};

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::rc::is_dangling;
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

/// Isang malambot na limitasyon sa dami ng mga sanggunian na maaaring gawin sa isang `Arc`.
///
/// Ang pagpunta sa itaas ng limitasyong ito ay magbubawas ng iyong programa (kahit na hindi kinakailangan) sa _exactly_ `MAX_REFCOUNT + 1` mga sanggunian.
///
const MAX_REFCOUNT: usize = (isize::MAX) as usize;

#[cfg(not(sanitize = "thread"))]
macro_rules! acquire {
    ($x:expr) => {
        atomic::fence(Acquire)
    };
}

// Hindi sinusuportahan ng ThreadSanitizer ang mga fences ng memorya.
// Upang maiwasan ang maling mga positibong ulat sa Arc/Mahinang pagpapatupad gumamit ng mga atomic load para sa pagsabay sa halip.
//
#[cfg(sanitize = "thread")]
macro_rules! acquire {
    ($x:expr) => {
        $x.load(Acquire)
    };
}

/// Isang thread-safe na referral-pagbibilang ng pointer.Ang 'Arc' ay nangangahulugang binibilang ang 'Atomically Reference Count'.
///
/// Ang uri na `Arc<T>` ay nagbibigay ng nakabahaging pagmamay-ari ng isang halaga ng uri `T`, na inilalaan sa tambak.Ang invoking [`clone`][clone] sa `Arc` ay gumagawa ng isang bagong halimbawa ng `Arc`, na tumuturo sa parehong paglalaan sa bunton bilang mapagkukunan `Arc`, habang pinapataas ang isang bilang ng sanggunian.
/// Kapag ang huling `Arc` pointer sa isang naibigay na paglalaan ay nawasak, ang halagang nakaimbak sa paglaanang iyon (na madalas na tinukoy bilang "inner value") ay nahuhulog din.
///
/// Ang mga nakabahaging sanggunian sa Rust ay hindi pinapayagan ang pag-mutate bilang default, at ang `Arc` ay walang kataliwasan: hindi ka makakakuha ng pangkalahatang isang nababagabag na sanggunian sa isang bagay sa loob ng `Arc`.Kung kailangan mong mutate sa pamamagitan ng isang `Arc`, gumamit ng [`Mutex`][mutex], [`RwLock`][rwlock], o isa sa mga [`Atomic`][atomic] na uri.
///
/// ## Kaligtasan ng Thread
///
/// Hindi tulad ng [`Rc<T>`], ang `Arc<T>` ay gumagamit ng mga pagpapatakbo ng atomic para sa pagbibilang ng sanggunian nito.Nangangahulugan ito na ito ay ligtas sa thread.Ang dehado ay ang mga pagpapatakbo ng atomic na mas mahal kaysa sa mga ordinaryong pag-access sa memorya.Kung hindi ka nagbabahagi ng mga alokasyong binibilang ng sanggunian sa pagitan ng mga thread, isaalang-alang ang paggamit ng [`Rc<T>`] para sa mas mababang overhead.
/// [`Rc<T>`] ay isang ligtas na default, dahil mahuhuli ng tagatala ang anumang pagtatangka upang magpadala ng isang [`Rc<T>`] sa pagitan ng mga thread.
/// Gayunpaman, ang isang aklatan ay maaaring pumili ng `Arc<T>` upang mabigyan ng higit na kakayahang umangkop ang mga mamimili sa library.
///
/// `Arc<T>` ipapatupad ang [`Send`] at [`Sync`] basta ang `T` ay nagpapatupad ng [`Send`] at [`Sync`].
/// Bakit hindi mo mailagay ang isang hindi-thread-safe na uri `T` sa isang `Arc<T>` upang gawin itong ligtas sa thread?Maaari itong maging medyo counter-intuitive sa una: pagkatapos ng lahat, hindi ba ang punto ng kaligtasan ng thread ng `Arc<T>`?Ang susi ay ito: Ginagawang ligtas ng `Arc<T>` ang thread na magkaroon ng maraming pagmamay-ari ng parehong data, ngunit hindi ito nagdaragdag ng kaligtasan ng thread sa data nito.
///
/// Isaalang-alang ang `Arc <` ['RefCell<T>`]`> `.
/// [`RefCell<T>`] ay hindi [`Sync`], at kung ang `Arc<T>` ay palaging [`Send`], `Arc <` ['RefCell<T>`]`> `magiging ganun din.
/// Ngunit magkakaroon kami ng problema:
/// [`RefCell<T>`] ay hindi ligtas na thread;sinusubaybayan nito ang bilang ng paghiram gamit ang mga pagpapatakbo na hindi atomic.
///
/// Sa katapusan, ibig sabihin nito na maaaring kailangan mong ipares `Arc<T>` na may ilang mga uri ng [`std::sync`] uri, ay karaniwang [`Mutex<T>`][mutex].
///
/// ## Pag-break ng mga cycle na may `Weak`
///
/// Ang pamamaraang [`downgrade`][downgrade] ay maaaring magamit upang lumikha ng isang hindi pagmamay-ari na [`Weak`] pointer.Ang isang [`Weak`] pointer ay maaaring maging [`pag-upgrade`][pag-upgrade] d sa isang `Arc`, ngunit ibabalik nito ang [`None`] kung ang halagang nakaimbak sa paglalaan ay naalis na.
/// Sa madaling salita, hindi pinapanatili ng mga pointer ng `Weak` ang halaga sa loob ng paglalaan na buhay;gayunpaman,*pinapanatili nila* ang paglalaan (ang backing store para sa halaga) na buhay.
///
/// Ang isang pag-ikot sa pagitan ng `Arc` pointers ay hindi kailanman maaaksyunan.
/// Para sa kadahilanang ito, ang [`Weak`] ay ginagamit upang masira ang mga pag-ikot.Halimbawa, ang isang puno ay maaaring magkaroon ng malakas na `Arc` pointers mula sa mga node ng magulang hanggang sa mga bata, at [`Weak`] pointers mula sa mga bata pabalik sa kanilang mga magulang.
///
/// # Mga sanggunian sa pag-clone
///
/// Ang paglikha ng isang bagong sanggunian mula sa isang umiiral na pointer na binibilang ng sanggunian ay tapos na gamit ang `Clone` trait na ipinatupad para sa [`Arc<T>`][Arc] at [`Weak<T>`][Weak].
///
/// ```
/// use std::sync::Arc;
/// let foo = Arc::new(vec![1.0, 2.0, 3.0]);
/// // Ang dalawang syntaxes sa ibaba ay katumbas.
/// let a = foo.clone();
/// let b = Arc::clone(&foo);
/// // a, b, at foo ay ang lahat ng Arcs na tumuturo sa parehong lokasyon ng memorya
/// ```
///
/// ## `Deref` behavior
///
/// `Arc<T>` awtomatikong dereferences sa `T` (sa pamamagitan ng [`Deref`][deref] trait), kaya maaari mong tawagan ang mga pamamaraan ng `T` sa isang halaga ng uri `Arc<T>`.Upang maiwasan ang mga pag-aaway ng pangalan sa mga pamamaraan ng `T`, ang mga pamamaraan ng `Arc<T>` mismo ay nauugnay na mga pagpapaandar, na tinatawag na paggamit ng [fully qualified syntax]:
///
/// ```
/// use std::sync::Arc;
///
/// let my_arc = Arc::new(());
/// Arc::downgrade(&my_arc);
/// ```
///
/// `Arc<T>Ang mga pagpapatupad ng traits tulad ng `Clone` ay maaari ding tawagan gamit ang ganap na kwalipikadong syntax.
/// Ang ilang mga tao ay ginusto na gumamit ng ganap na kwalipikadong syntax, habang ang iba ay ginusto ang paggamit ng paraan-tawag na syntax.
///
/// ```
/// use std::sync::Arc;
///
/// let arc = Arc::new(());
/// // Syntax ng tawag sa pamamaraan
/// let arc2 = arc.clone();
/// // Ganap na kwalipikadong syntax
/// let arc3 = Arc::clone(&arc);
/// ```
///
/// [`Weak<T>`][Weak] ay hindi awtomatikong pag-aakma sa `T`, dahil ang panloob na halaga ay maaaring nahulog na.
///
/// [`Rc<T>`]: crate::rc::Rc
/// [clone]: Clone::clone
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [atomic]: core::sync::atomic
/// [`Send`]: core::marker::Send
/// [`Sync`]: core::marker::Sync
/// [deref]: core::ops::Deref
/// [downgrade]: Arc::downgrade
/// [upgrade]: Weak::upgrade
/// [`RefCell<T>`]: core::cell::RefCell
/// [`std::sync`]: ../../std/sync/index.html
/// [`Arc::clone(&from)`]: Arc::clone
/// [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
///
/// # Examples
///
/// Pagbabahagi ng ilang hindi nababago na data sa pagitan ng mga thread:
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
// Tandaan na hindi namin ** pinapatakbo ang mga pagsubok na ito dito.
// Ang mga tagabuo ng windows ay sobrang nasisiyahan kung ang isang sinulid ay mas matagal ang pangunahing thread at pagkatapos ay lalabas nang sabay (isang bagay na bara) kaya't iniiwasan lamang natin ito sa pamamagitan ng hindi pagpapatakbo ng mga pagsubok na ito.
//
//
/// ```no_run
/// use std::sync::Arc;
/// use std::thread;
///
/// let five = Arc::new(5);
///
/// for _ in 0..10 {
///     let five = Arc::clone(&five);
///
///     thread::spawn(move || {
///         println!("{:?}", five);
///     });
/// }
/// ```
///
/// Pagbabahagi ng isang nababagabag na [`AtomicUsize`]:
///
/// [`AtomicUsize`]: core::sync::atomic::AtomicUsize
///
/// ```no_run
/// use std::sync::Arc;
/// use std::sync::atomic::{AtomicUsize, Ordering};
/// use std::thread;
///
/// let val = Arc::new(AtomicUsize::new(5));
///
/// for _ in 0..10 {
///     let val = Arc::clone(&val);
///
///     thread::spawn(move || {
///         let v = val.fetch_add(1, Ordering::SeqCst);
///         println!("{:?}", v);
///     });
/// }
/// ```
///
/// Tingnan ang [`rc` documentation][rc_examples] para sa higit pang mga halimbawa ng pagbibilang ng sanggunian sa pangkalahatan.
///
///
/// [rc_examples]: crate::rc#examples
#[cfg_attr(not(test), rustc_diagnostic_item = "Arc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Arc<T: ?Sized> {
    ptr: NonNull<ArcInner<T>>,
    phantom: PhantomData<ArcInner<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Arc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Arc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Arc<U>> for Arc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Arc<U>> for Arc<T> {}

impl<T: ?Sized> Arc<T> {
    fn from_inner(ptr: NonNull<ArcInner<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut ArcInner<T>) -> Self {
        unsafe { Self::from_inner(NonNull::new_unchecked(ptr)) }
    }
}

/// `Weak` ay isang bersyon ng [`Arc`] na nagtataglay ng isang hindi pagmamay-ari na sanggunian sa pinamamahalaang paglalaan.
/// Ang paglalaan ay na-access sa pamamagitan ng pagtawag sa [`upgrade`] sa `Weak` pointer, na nagbabalik ng isang [`Option`]`<`[`Arc`] `<T>>`.
///
/// Dahil ang isang sanggunian na `Weak` ay hindi binibilang patungo sa pagmamay-ari, hindi nito pipigilan ang halagang nakaimbak sa alokasyon mula sa pagbagsak, at ang `Weak` mismo ay hindi gumagawa ng mga garantiya tungkol sa halaga na naroroon pa rin.
///
/// Kaya't maibabalik nito ang [`None`] kapag [`upgrade`] d.
/// Gayunpaman, tandaan na ang isang sanggunian na `Weak`*ay* pinipigilan ang paglalaan mismo (ang backing store) mula sa ma-deallocated.
///
/// Ang isang `Weak` pointer ay kapaki-pakinabang para sa pagpapanatili ng isang pansamantalang sanggunian sa paglalaan na pinamamahalaan ng [`Arc`] nang hindi pinipigilan ang panloob na halaga mula sa pagbagsak.
/// Ginagamit din ito upang maiwasan ang mga pabilog na sanggunian sa pagitan ng mga payo ng [`Arc`], dahil ang mga pagmamay-ari na sanggunian sa pagmamay-ari ay hindi papayagan ang alinman sa [`Arc`] na mahulog.
/// Halimbawa, ang isang puno ay maaaring magkaroon ng malakas na [`Arc`] pointers mula sa mga node ng magulang hanggang sa mga bata, at `Weak` pointers mula sa mga bata pabalik sa kanilang mga magulang.
///
/// Ang tipikal na paraan upang makakuha ng isang `Weak` pointer ay upang tawagan ang [`Arc::downgrade`].
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
#[stable(feature = "arc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // Ito ay isang `NonNull` upang payagan ang pag-optimize ng laki ng ganitong uri sa mga enum, ngunit hindi ito kinakailangang isang wastong pointer.
    //
    // `Weak::new` Itinatakda ito sa `usize::MAX` upang hindi na kailanganin na maglaan ng puwang sa tambak.
    // Iyon ay hindi isang halaga na magkakaroon ng isang tunay na pointer dahil ang RcBox ay may pagkakahanay ng hindi bababa sa 2.
    // Posible lamang ito kapag `T: Sized`;hindi pinalaki ang XSX na hindi naka-unsize.
    //
    ptr: NonNull<ArcInner<T>>,
}

#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Weak<T> {}
#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

// Ito ay repr(C) hanggang future-patunay laban sa posibleng pag-aayos muli ng patlang, na makagambala sa kung hindi man ligtas na [into|from]_raw() ng maaaring mailipat na panloob na mga uri.
//
//
#[repr(C)]
struct ArcInner<T: ?Sized> {
    strong: atomic::AtomicUsize,

    // ang halaga usize::MAX kumikilos bilang isang tanod para sa pansamantalang "locking" ang kakayahan upang i-upgrade ang mahinang mga payo o i-downgrade ang malalakas;ginagamit ito upang maiwasan ang mga karera sa `make_mut` at `get_mut`.
    //
    //
    weak: atomic::AtomicUsize,

    data: T,
}

unsafe impl<T: ?Sized + Sync + Send> Send for ArcInner<T> {}
unsafe impl<T: ?Sized + Sync + Send> Sync for ArcInner<T> {}

impl<T> Arc<T> {
    /// Bumubuo ng isang bagong `Arc<T>`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(data: T) -> Arc<T> {
        // Simulan ang mahina na bilang ng pointer bilang 1 na kung saan ay ang mahinang pointer na hawak ng lahat ng mga malakas na pointers (kinda), tingnan ang std/rc.rs para sa karagdagang impormasyon
        //
        let x: Box<_> = box ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        };
        Self::from_inner(Box::leak(x).into())
    }

    /// Bumubuo ng isang bagong `Arc<T>` gamit ang isang mahinang sanggunian sa sarili nito.
    /// Ang pagtatangkang i-upgrade ang mahinang sanggunian bago ang pagbalik ng pagpapaandar na ito ay magreresulta sa isang halagang `None`.
    /// Gayunpaman, ang mahinang sanggunian ay maaaring ma-clone nang malaya at maiimbak para magamit sa ibang oras.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    ///
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo {
    ///     me: Weak<Foo>,
    /// }
    ///
    /// let foo = Arc::new_cyclic(|me| Foo {
    ///     me: me.clone(),
    /// });
    /// ```
    #[inline]
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Arc<T> {
        // Buuin ang panloob sa estado ng "uninitialized" na may isang solong mahinang sanggunian.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box ArcInner {
            strong: atomic::AtomicUsize::new(0),
            weak: atomic::AtomicUsize::new(1),
            data: mem::MaybeUninit::<T>::uninit(),
        })
        .into();
        let init_ptr: NonNull<ArcInner<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // Mahalagang hindi namin isusuko ang pagmamay-ari ng mahinang pointer, o kung hindi man mapalaya ang memorya sa oras ng pagbabalik ng `data_fn`.
        // Kung talagang nais naming ipasa ang pagmamay-ari, makakagawa kami ng isang karagdagang mahinang pointer para sa aming sarili, ngunit magreresulta ito sa mga karagdagang pag-update sa mahinang bilang ng sanggunian na maaaring hindi kinakailangan kung hindi man.
        //
        //
        //
        //
        let data = data_fn(&weak);

        // Ngayon ay maaari nating maayos na simulan ang panloob na halaga at gawing isang malakas na sanggunian ang aming mahinang sanggunian.
        //
        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).data), data);

            // Ang nasa itaas na sumulat sa patlang ng data ay dapat na nakikita ng anumang mga thread na nagmamasid sa isang hindi zero na malakas na bilang.
            // Samakatuwid kailangan namin ng hindi bababa sa "Release" na pag-order upang ma-synchronize ang `compare_exchange_weak` sa `Weak::upgrade`.
            //
            // "Acquire" hindi kinakailangan ang pag-order.
            // Kapag isinasaalang-alang ang mga posibleng pag-uugali ng `data_fn` kailangan lamang naming tingnan kung ano ang magagawa nito sa isang sanggunian sa isang hindi na-upgrade na `Weak`:
            //
            // - Maaari itong *i-clone* ang `Weak`, pagdaragdag ng mahinang bilang ng sanggunian.
            // - Maaari nitong i-drop ang mga clone na iyon, binabawasan ang mahinang bilang ng sanggunian (ngunit hindi kailanman zero).
            //
            // Ang mga epektong ito ay hindi nakakaapekto sa amin sa anumang paraan, at walang ibang mga epekto na posible na may ligtas na code lamang.
            //
            //
            let prev_value = (*inner).strong.fetch_add(1, Release);
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
        }

        let strong = Arc::from_inner(init_ptr);

        // Ang mga malakas na sanggunian ay dapat na magkasama na pagmamay-ari ng isang ibinahaging mahinang sanggunian, kaya huwag patakbuhin ang destructor para sa aming dating mahinang sanggunian.
        //
        mem::forget(weak);
        strong
    }

    /// Bumubuo ng isang bagong `Arc` na may uninitialized na mga nilalaman.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Ipinagpaliban na pagsisimula:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Bumubuo ng isang bagong `Arc` na may uninitialized na mga nilalaman, na may memorya na puno ng `0` bytes.
    ///
    ///
    /// Tingnan ang [`MaybeUninit::zeroed`][zeroed] para sa mga halimbawa ng wasto at maling paggamit ng pamamaraang ito.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Bumubuo ng isang bagong `Pin<Arc<T>>`.
    /// Kung ang `T` ay hindi nagpapatupad ng `Unpin`, kung gayon ang `data` ay mai-pin sa memorya at hindi mailipat.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(data: T) -> Pin<Arc<T>> {
        unsafe { Pin::new_unchecked(Arc::new(data)) }
    }

    /// Bumubuo ng isang bagong `Arc<T>`, nagbabalik ng isang error kung nabigo ang paglalaan.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::sync::Arc;
    ///
    /// let five = Arc::try_new(5)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new(data: T) -> Result<Arc<T>, AllocError> {
        // Simulan ang mahina na bilang ng pointer bilang 1 na kung saan ay ang mahinang pointer na hawak ng lahat ng mga malakas na pointers (kinda), tingnan ang std/rc.rs para sa karagdagang impormasyon
        //
        let x: Box<_> = Box::try_new(ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        })?;
        Ok(Self::from_inner(Box::leak(x).into()))
    }

    /// Bumubuo ng isang bagong `Arc` na may uninitialized na mga nilalaman, na nagbabalik ng isang error kung nabigo ang paglalaan.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // Ipinagpaliban na pagsisimula:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// Bumubuo ng isang bagong `Arc` na may mga uninitialized na nilalaman, na may memorya na puno ng `0` bytes, na nagbabalik ng isang error kung nabigo ang paglalaan.
    ///
    ///
    /// Tingnan ang [`MaybeUninit::zeroed`][zeroed] para sa mga halimbawa ng wasto at maling paggamit ng pamamaraang ito.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// Ibinabalik ang panloob na halaga, kung ang `Arc` ay may eksaktong isang malakas na sanggunian.
    ///
    /// Kung hindi man, isang [`Err`] ay ibinalik na may parehong `Arc` na naipasa.
    ///
    ///
    /// Magtatagumpay ito kahit na may mga natitirang mahinang sanggunian.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new(3);
    /// assert_eq!(Arc::try_unwrap(x), Ok(3));
    ///
    /// let x = Arc::new(4);
    /// let _y = Arc::clone(&x);
    /// assert_eq!(*Arc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if this.inner().strong.compare_exchange(1, 0, Relaxed, Relaxed).is_err() {
            return Err(this);
        }

        acquire!(this.inner().strong);

        unsafe {
            let elem = ptr::read(&this.ptr.as_ref().data);

            // Gumawa ng isang mahinang pointer upang linisin ang ipinahiwatig na malakas-mahina na sanggunian
            let _weak = Weak { ptr: this.ptr };
            mem::forget(this);

            Ok(elem)
        }
    }
}

impl<T> Arc<[T]> {
    /// Gumagawa ng isang bagong piraso ng atomically reference-bilang na hiwa na may mga hindi unipormadong nilalaman.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Ipinagpaliban na pagsisimula:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe { Arc::from_ptr(Arc::allocate_for_slice(len)) }
    }

    /// Gumagawa ng isang bagong atomically reference-count slice na may mga hindi unipormadong nilalaman, na may memorya na puno ng `0` bytes.
    ///
    ///
    /// Tingnan ang [`MaybeUninit::zeroed`][zeroed] para sa mga halimbawa ng wasto at maling paggamit ng pamamaraang ito.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let values = Arc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut ArcInner<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Arc<mem::MaybeUninit<T>> {
    /// Nag-convert sa `Arc<T>`.
    ///
    /// # Safety
    ///
    /// Tulad ng sa [`MaybeUninit::assume_init`], nasa sa tumatawag na garantiya na ang panloob na halaga ay talagang nasa isang inisyal na estado.
    ///
    /// Ang pagtawag nito kapag ang nilalaman ay hindi pa ganap na naisasimulan ay nagiging sanhi ng agarang hindi natukoy na pag-uugali.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Ipinagpaliban na pagsisimula:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<T> {
        Arc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Arc<[mem::MaybeUninit<T>]> {
    /// Nag-convert sa `Arc<[T]>`.
    ///
    /// # Safety
    ///
    /// Tulad ng sa [`MaybeUninit::assume_init`], nasa sa tumatawag na garantiya na ang panloob na halaga ay talagang nasa isang inisyal na estado.
    ///
    /// Ang pagtawag nito kapag ang nilalaman ay hindi pa ganap na naisasimulan ay nagiging sanhi ng agarang hindi natukoy na pag-uugali.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Ipinagpaliban na pagsisimula:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<[T]> {
        unsafe { Arc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// Naubos ang `Arc`, ibinabalik ang balot na pointer.
    ///
    /// Upang maiwasan ang isang pagtagas ng memorya ang pointer ay dapat na mai-convert pabalik sa isang `Arc` gamit ang [`Arc::from_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// Nagbibigay ng isang hilaw na pointer sa data.
    ///
    /// Ang mga bilang ay hindi apektado sa anumang paraan at ang `Arc` ay hindi natupok.
    /// Ang pointer ay may bisa para sa hangga't may mga mabibilang na bilang sa `Arc`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let y = Arc::clone(&x);
    /// let x_ptr = Arc::as_ptr(&x);
    /// assert_eq!(x_ptr, Arc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(this.ptr);

        // KALIGTASAN: Ito ay hindi maaaring pumunta sa pamamagitan ng Deref::deref o RcBoxPtr::inner dahil
        // ito ay kinakailangan upang mapanatili ang raw/mut probansya tulad ng hal
        // `get_mut` maaaring sumulat sa pamamagitan ng pointer pagkatapos makuha ang Rc sa pamamagitan ng `from_raw`.
        unsafe { ptr::addr_of_mut!((*ptr).data) }
    }

    /// Bumubuo ng isang `Arc<T>` mula sa isang hilaw na pointer.
    ///
    /// Ang raw pointer ay dapat na dating ibinalik ng isang tawag sa [`Arc<U>::into_raw`][into_raw] kung saan ang `U` ay dapat magkaroon ng parehong laki at pagkakahanay bilang `T`.
    /// Ito ay walang katotohanan totoo kung `U` ay `T`.
    /// Tandaan na kung ang `U` ay hindi `T` ngunit may parehong laki at pagkakahanay, ito ay karaniwang tulad ng paglilipat ng mga sanggunian ng iba't ibang uri.
    /// Tingnan ang [`mem::transmute`][transmute] para sa karagdagang impormasyon tungkol sa kung anong mga paghihigpit ang nalalapat sa kasong ito.
    ///
    /// Ang gumagamit ng `from_raw` ay dapat tiyakin na ang isang tukoy na halaga ng `T` ay isang beses lamang na bumagsak.
    ///
    /// Ang pag-andar na ito ay hindi ligtas dahil ang hindi wastong paggamit ay maaaring humantong sa kaligtasan ng memorya, kahit na ang naibalik na `Arc<T>` ay hindi kailanman na-access.
    ///
    /// [into_raw]: Arc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    ///
    /// unsafe {
    ///     // I-convert pabalik sa isang `Arc` upang maiwasan ang pagtulo.
    ///     let x = Arc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // Ang mga karagdagang tawag sa `Arc::from_raw(x_ptr)` ay magiging hindi ligtas sa memorya.
    /// }
    ///
    /// // Ang memorya ay napalaya nang ang `x` ay lumabas sa saklaw sa itaas, kaya't ang `x_ptr` ay nakalawit na ngayon!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        unsafe {
            let offset = data_offset(ptr);

            // Baligtarin ang offset upang mahanap ang orihinal na ArcInner.
            let arc_ptr = (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset));

            Self::from_ptr(arc_ptr)
        }
    }

    /// Lumilikha ng isang bagong [`Weak`] pointer sa paglalaan na ito.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        // OK ang Relaks na ito dahil sinusuri namin ang halaga sa CAS sa ibaba.
        //
        let mut cur = this.inner().weak.load(Relaxed);

        loop {
            // suriin kung ang mahina na counter ay kasalukuyang "locked";kung gayon, paikutin.
            if cur == usize::MAX {
                hint::spin_loop();
                cur = this.inner().weak.load(Relaxed);
                continue;
            }

            // NOTE: kasalukuyang binabalewala ng code na ito ang posibilidad ng pag-apaw
            // sa usize::MAX;sa pangkalahatan ang parehong Rc at Arc ay kailangang ayusin upang makitungo sa overflow.
            //

            // Hindi tulad ng Clone(), kailangan namin ito upang maging isang Acquire read upang mai-synchronize sa sulat na nagmumula sa `is_unique`, upang ang mga kaganapan bago ang pagsulat na iyon ay mangyari bago ito basahin.
            //
            //
            match this.inner().weak.compare_exchange_weak(cur, cur + 1, Acquire, Relaxed) {
                Ok(_) => {
                    // Tiyaking hindi kami lumilikha ng isang nakalawit na Mahina
                    debug_assert!(!is_dangling(this.ptr.as_ptr()));
                    return Weak { ptr: this.ptr };
                }
                Err(old) => cur = old,
            }
        }
    }

    /// Nakukuha ang bilang ng mga [`Weak`] pointer sa paglalaan na ito.
    ///
    /// # Safety
    ///
    /// Ang pamamaraang ito mismo ay ligtas, ngunit ang tamang paggamit nito ay nangangailangan ng labis na pangangalaga.
    /// Ang isa pang thread ay maaaring baguhin ang mahinang bilang sa anumang oras, kabilang ang potensyal sa pagitan ng pagtawag sa pamamaraang ito at pag-arte sa resulta.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _weak_five = Arc::downgrade(&five);
    ///
    /// // Ang pagpapahayag na ito ay deterministic dahil hindi namin naibahagi ang `Arc` o `Weak` sa pagitan ng mga thread.
    /////
    /// assert_eq!(1, Arc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        let cnt = this.inner().weak.load(SeqCst);
        // Kung ang mahinang bilang ay kasalukuyang naka-lock, ang halaga ng bilang ay 0 bago makuha ang lock.
        //
        if cnt == usize::MAX { 0 } else { cnt - 1 }
    }

    /// Nakukuha ang bilang ng mga malakas na (`Arc`) pointer sa paglalaan na ito.
    ///
    /// # Safety
    ///
    /// Ang pamamaraang ito mismo ay ligtas, ngunit ang tamang paggamit nito ay nangangailangan ng labis na pangangalaga.
    /// Ang isa pang thread ay maaaring baguhin ang malakas na bilang sa anumang oras, kabilang ang potensyal sa pagitan ng pagtawag sa pamamaraang ito at pag-arte sa resulta.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _also_five = Arc::clone(&five);
    ///
    /// // Ang pagpapahayag na ito ay deterministic dahil hindi namin naibahagi ang `Arc` sa pagitan ng mga thread.
    /////
    /// assert_eq!(2, Arc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong.load(SeqCst)
    }

    /// Nagpapataas ng malakas na bilang ng sanggunian sa `Arc<T>` na nauugnay sa ibinigay na pointer ng isa.
    ///
    /// # Safety
    ///
    /// Ang pointer ay dapat na nakuha sa pamamagitan ng `Arc::into_raw`, at ang nauugnay na halimbawa ng `Arc` ay dapat na wasto (ibig sabihin
    /// ang malakas na bilang ay dapat na hindi bababa sa 1) para sa tagal ng pamamaraang ito.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // Ang pagpapahayag na ito ay deterministic dahil hindi namin naibahagi ang `Arc` sa pagitan ng mga thread.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn increment_strong_count(ptr: *const T) {
        // Panatilihin ang Arc, ngunit huwag hawakan ang refcount sa pamamagitan ng pambalot sa Manu-manongDrop
        let arc = unsafe { mem::ManuallyDrop::new(Arc::<T>::from_raw(ptr)) };
        // Taasan ngayon ang refcount, ngunit huwag ring bumagsak ng bagong refcount
        let _arc_clone: mem::ManuallyDrop<_> = arc.clone();
    }

    /// Nagbabawas ng malakas na bilang ng sanggunian sa `Arc<T>` na nauugnay sa ibinigay na pointer ng isa.
    ///
    /// # Safety
    ///
    /// Ang pointer ay dapat na nakuha sa pamamagitan ng `Arc::into_raw`, at ang nauugnay na halimbawa ng `Arc` ay dapat na wasto (ibig sabihin
    /// ang malakas na bilang ay dapat na hindi bababa sa 1) kapag ginagamit ang pamamaraang ito.
    /// Ang pamamaraan na ito ay maaaring gamitin upang i-release ang huling `Arc` at mga tagapagtaguyod imbakan, ngunit **Dapat hindi** tatawaging pagkatapos ng huling `Arc` ay inilabas.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // Ang mga assertions na iyon ay deterministic dahil hindi namin naibahagi ang `Arc` sa pagitan ng mga thread.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    ///     Arc::decrement_strong_count(ptr);
    ///     assert_eq!(1, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn decrement_strong_count(ptr: *const T) {
        unsafe { mem::drop(Arc::from_raw(ptr)) };
    }

    #[inline]
    fn inner(&self) -> &ArcInner<T> {
        // Ang hindi ligtas na ito ay ok dahil habang buhay ang arc na ito ginagarantiyahan namin na ang panloob na pointer ay wasto.
        // Bukod dito, alam namin na ang istraktura ng `ArcInner` mismo ay `Sync` dahil ang panloob na data ay `Sync` din, kaya't ok kami ng pag-loan ng isang hindi nababago na pointer sa mga nilalaman na ito.
        //
        //
        //
        unsafe { self.ptr.as_ref() }
    }

    // Non-inlined bahagi ng `drop`.
    #[inline(never)]
    unsafe fn drop_slow(&mut self) {
        // Wasakin ang data sa oras na ito, kahit na hindi namin maaaring palayain ang paglalaan ng kahon mismo (maaaring may mga mahina ring pahiwatig na nakahiga).
        //
        unsafe { ptr::drop_in_place(Self::get_mut_unchecked(self)) };

        // I-drop ang mahina ref kolektibong gaganapin ng lahat ng mga malakas na sanggunian
        drop(Weak { ptr: self.ptr });
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// Ibinabalik ang `true` kung ang dalawang `Arc` ay tumuturo sa parehong paglalaan (sa isang ugat na katulad ng [`ptr::eq`]).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let same_five = Arc::clone(&five);
    /// let other_five = Arc::new(5);
    ///
    /// assert!(Arc::ptr_eq(&five, &same_five));
    /// assert!(!Arc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: ?Sized> Arc<T> {
    /// Naglalaan ng isang `ArcInner<T>` na may sapat na puwang para sa isang posibleng na-unsized na panloob na halaga kung saan ang halaga ay may ibinigay na layout.
    ///
    /// Ang pagpapaandar `mem_to_arcinner` ay tinatawag na may data pointer at dapat bumalik sa isang (potensyal na fat)-pointer para sa `ArcInner<T>`.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> *mut ArcInner<T> {
        // Kalkulahin ang layout gamit ang ibinigay na layout ng halaga.
        // Dati, ang layout ay kinakalkula sa expression na `&*(ptr as* const ArcInner<T>)`, ngunit lumikha ito ng isang maling pagkakakilanlan (tingnan ang #54908).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Arc::try_allocate_for_layout(value_layout, allocate, mem_to_arcinner)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// Naglalaan ng isang `ArcInner<T>` na may sapat na puwang para sa isang posibleng na-unsized na panloob na halaga kung saan ang halaga ay may ibinigay na layout, na nagbabalik ng isang error kung nabigo ang paglalaan.
    ///
    ///
    /// Ang pagpapaandar `mem_to_arcinner` ay tinatawag na may data pointer at dapat bumalik sa isang (potensyal na fat)-pointer para sa `ArcInner<T>`.
    ///
    ///
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> Result<*mut ArcInner<T>, AllocError> {
        // Kalkulahin ang layout gamit ang ibinigay na layout ng halaga.
        // Dati, ang layout ay kinakalkula sa expression na `&*(ptr as* const ArcInner<T>)`, ngunit lumikha ito ng isang maling pagkakakilanlan (tingnan ang #54908).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();

        let ptr = allocate(layout)?;

        // Pasimulan ang ArcInner
        let inner = mem_to_arcinner(ptr.as_non_null_ptr().as_ptr());
        debug_assert_eq!(unsafe { Layout::for_value(&*inner) }, layout);

        unsafe {
            ptr::write(&mut (*inner).strong, atomic::AtomicUsize::new(1));
            ptr::write(&mut (*inner).weak, atomic::AtomicUsize::new(1));
        }

        Ok(inner)
    }

    /// Naglalaan ng isang `ArcInner<T>` na may sapat na puwang para sa isang hindi sukat na panloob na halaga.
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut ArcInner<T> {
        // Maglaan para sa `ArcInner<T>` gamit ang ibinigay na halaga.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut ArcInner<T>).set_ptr_value(mem) as *mut ArcInner<T>,
            )
        }
    }

    fn from_box(v: Box<T>) -> Arc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // Kopyahin ang halaga bilang mga byte
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).data as *mut _ as *mut u8,
                value_size,
            );

            // Libre ang paglalaan nang hindi inaalis ang mga nilalaman nito
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Arc<[T]> {
    /// Naglalaan ng `ArcInner<[T]>` na may ibinigay na haba.
    unsafe fn allocate_for_slice(len: usize) -> *mut ArcInner<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut ArcInner<[T]>,
            )
        }
    }

    /// Kopyahin ang mga elemento mula sa hiwa sa bagong inilalaan na Arc <\[T\]>
    ///
    /// Hindi ligtas dahil ang tumatawag ay dapat na kumuha ng pagmamay-ari o magbigkis ng `T: Copy`.
    unsafe fn copy_from_slice(v: &[T]) -> Arc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());

            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).data as *mut [T] as *mut T, v.len());

            Self::from_ptr(ptr)
        }
    }

    /// Bumubuo ng isang `Arc<[T]>` mula sa isang iterator na alam na may isang tiyak na laki.
    ///
    /// Ang pag-uugali ay hindi natukoy kung ang laki ay mali.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Arc<[T]> {
        // Panic bantay habang ang pag-clone ng mga elemento ng T.
        // Sa kaganapan ng isang panic, ang mga elemento na nakasulat sa bagong ArcInner ay mahuhulog, pagkatapos ay mapalaya ang memorya.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // Ituro ang unang elemento
            let elems = &mut (*ptr).data as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // Malinaw ang lahatKalimutan ang guwardiya upang hindi nito mapalaya ang bagong ArcInner.
            mem::forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// Ang pagdadalubhasa trait na ginagamit para sa `From<&[T]>`.
trait ArcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Arc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Arc<T> {
    /// Gumagawa ng isang clone ng `Arc` pointer.
    ///
    /// Lumilikha ito ng isa pang pointer sa parehong paglalaan, pagdaragdag ng malakas na bilang ng sanggunian.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let _ = Arc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Arc<T> {
        // Ang paggamit ng isang nakakarelaks na pag-order ay tama dito, dahil ang kaalaman sa orihinal na sanggunian ay humahadlang sa iba pang mga thread mula sa maling pagtanggal ng object.
        //
        // Tulad ng ipinaliwanag sa [Boost documentation][1], Ang pagdaragdag ng counter ng sanggunian ay maaaring palaging gawin sa memorya_order_relaxed: Ang mga bagong sanggunian sa isang bagay ay maaari lamang mabuo mula sa isang mayroon nang sanggunian, at ang pagpasa ng isang umiiral na sanggunian mula sa isang thread patungo sa isa pa ay dapat na magbigay ng anumang kinakailangang pagsabay.
        //
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        //
        //
        //
        //
        //
        let old_size = self.inner().strong.fetch_add(1, Relaxed);

        // Gayunpaman kailangan naming magbantay laban sa napakalaking refcount kung sakaling may isang tao na `mem: : nakakalimutan 'Arcs.
        // Kung hindi namin ito gagawin ang bilang ay maaaring umapaw at ang mga gumagamit ay gagamit ng-pagkatapos ng libre.
        // Karera naming nababad sa `isize::MAX` sa palagay na walang ~2 bilyong mga thread na nagdaragdag ng bilang ng sanggunian nang sabay-sabay.
        //
        // Ang branch na ito ay hindi kailanman makukuha sa anumang makatotohanang programa.
        //
        // Nag-abort kami dahil ang nasabing programa ay napapahina, at wala kaming pakialam na suportahan ito.
        //
        //
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Arc<T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        &self.inner().data
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Arc<T> {}

impl<T: Clone> Arc<T> {
    /// Gumagawa maaaring mabago ng isang reference sa mga ibinigay na `Arc`.
    ///
    /// Kung may iba pang mga pointer ng `Arc` o [`Weak`] sa parehong paglalaan, pagkatapos ang `make_mut` ay lilikha ng isang bagong paglalaan at ipataw sa [`clone`][clone] sa panloob na halaga upang matiyak ang natatanging pagmamay-ari.
    /// Ito ay tinukoy din bilang clone-on-write.
    ///
    /// Tandaan na naiiba ito mula sa pag-uugali ng [`Rc::make_mut`] na nagdidissociate ng anumang natitirang mga pointer ng `Weak`.
    ///
    /// Tingnan din ang [`get_mut`][get_mut], na mabibigo kaysa sa pag-clone.
    ///
    /// [clone]: Clone::clone
    /// [get_mut]: Arc::get_mut
    /// [`Rc::make_mut`]: super::rc::Rc::make_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut data = Arc::new(5);
    ///
    /// *Arc::make_mut(&mut data) += 1;         // Hindi mag-clone ng kahit ano
    /// let mut other_data = Arc::clone(&data); // Hindi makakapag-clone ng panloob na data
    /// *Arc::make_mut(&mut data) += 1;         // Pag-clone ng panloob na data
    /// *Arc::make_mut(&mut data) += 1;         // Hindi mag-clone ng kahit ano
    /// *Arc::make_mut(&mut other_data) *= 2;   // Hindi mag-clone ng kahit ano
    ///
    /// // Ngayon ang `data` at `other_data` ay tumuturo sa iba't ibang mga paglalaan.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        // Tandaan na hawak namin ang parehong isang malakas na sanggunian at isang mahinang sanggunian.
        // Samakatuwid, ang paglabas ng aming malakas na sanggunian lamang ay hindi, sa pamamagitan ng kanyang sarili, maging sanhi ng memorya na maipalit ng pansin.
        //
        // Gumamit ng Kumuha upang matiyak na nakikita namin ang anumang mga pagsusulat sa `weak` na nangyari bago ilabas ang mga pagsusulat (ibig sabihin, mga pagbawas) hanggang `strong`.
        // Dahil mahinahon kaming bilang, walang pagkakataon na ang ArcInner mismo ay maaaring makipagpalitan.
        //
        //
        //
        if this.inner().strong.compare_exchange(1, 0, Acquire, Relaxed).is_err() {
            // Ang isa pang malakas na pointer ay umiiral, kaya dapat nating i-clone.
            // Paunang maglaan ng memorya upang payagan ang pagsulat nang direkta ng na-clone na halaga.
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = arc.assume_init();
            }
        } else if this.inner().weak.load(Relaxed) != 1 {
            // Ang nakakarelaks ay sapat na sa itaas dahil sa panimula ito ay isang pag-optimize: palagi kaming nakikipag-karera sa mga mahihinang payo na ibinabagsak.
            // Pinakamasamang kaso, nagtapos kami na naglaan ng isang bagong Arc nang hindi kinakailangan.
            //

            // Inalis namin ang huling malakas na ref, ngunit may mga karagdagang mahinang ref na natitira.
            // Ililipat namin ang mga nilalaman sa isang bagong Arc, at tatawarin ang bisa ng iba pang mga mahina na ref.
            //

            // Tandaan na hindi posible para sa nabasa ng `weak` na magbunga ng usize::MAX (ibig sabihin, naka-lock), dahil ang mahinang bilang ay maaari lamang ma-lock ng isang thread na may isang malakas na sanggunian.
            //
            //

            // Pag-materialize ng aming sariling implicit mahina na pointer, upang malinis nito ang ArcInner kung kinakailangan.
            //
            let _weak = Weak { ptr: this.ptr };

            // Maaari lamang nakawin ang data, ang natitira lamang ay Weaks
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);
                ptr::write(this, arc.assume_init());
            }
        } else {
            // Kami ang nag-iisa na sanggunian ng alinmang uri;maibalik ang malakas na bilang ng ref.
            //
            this.inner().strong.store(1, Release);
        }

        // Tulad ng `get_mut()`, ang hindi ligtas na ok dahil ang aming sanggunian ay natatangi upang magsimula sa, o naging isa sa pag-clone ng mga nilalaman.
        //
        unsafe { Self::get_mut_unchecked(this) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// Nagbabalik ng isang nababagabag na sanggunian sa ibinigay na `Arc`, kung walang iba pang mga `Arc` o [`Weak`] pointers sa parehong paglalaan.
    ///
    ///
    /// Ibinabalik ang [`None`] kung hindi man, sapagkat hindi ligtas na i-mutate ang isang ibinahaging halaga.
    ///
    /// Tingnan din ang [`make_mut`][make_mut], na kung saan ay [`clone`][clone] ang panloob na halaga kapag may iba pang mga payo.
    ///
    /// [make_mut]: Arc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(3);
    /// *Arc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Arc::clone(&x);
    /// assert!(Arc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if this.is_unique() {
            // Ang hindi ligtas na ito ay ok dahil ginagarantiyahan namin na ang pointer ay ibinalik ang *tanging* pointer na ibabalik sa T.
            // Ang aming bilang ng sanggunian ay garantisadong maging 1 sa puntong ito, at hiniling namin ang Arc mismo na maging `mut`, kaya binabalik namin ang tanging posibleng sanggunian sa panloob na data.
            //
            //
            //
            unsafe { Some(Arc::get_mut_unchecked(this)) }
        } else {
            None
        }
    }

    /// Nagbabalik ng isang nababagabag na sanggunian sa ibinigay na `Arc`, nang walang anumang tseke.
    ///
    /// Tingnan din ang [`get_mut`], na kung saan ay ligtas at gumagawa ng mga naaangkop na tseke.
    ///
    /// [`get_mut`]: Arc::get_mut
    ///
    /// # Safety
    ///
    /// Anumang iba pang mga `Arc` o [`Weak`] pointers sa parehong paglalaan ay hindi dapat na maibawas sa respeto para sa tagal ng ibinalik na utang.
    ///
    /// Ito ay walang kabuluhan ang kaso kung walang mga naturang mga payo na mayroon, halimbawa kaagad pagkatapos ng `Arc::new`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(String::new());
    /// unsafe {
    ///     Arc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // Kami ay maingat na *hindi* lumikha ng isang reference na sumasaklaw sa "count" mga patlang, tulad ng ito gagawin alias na may kasabay na access sa mga bilang reference (eg
        // ni `Weak`).
        unsafe { &mut (*this.ptr.as_ptr()).data }
    }

    /// Tukuyin kung ito ang natatanging sanggunian (kabilang ang mga mahihinang ref) sa pinagbabatayan ng data.
    ///
    ///
    /// Tandaan na nangangailangan ito ng pagla-lock ng mahina na bilang ng ref.
    fn is_unique(&mut self) -> bool {
        // i-lock ang mahina na bilang ng pointer kung lumilitaw na kami lamang ang mahina na may-ari ng pointer.
        //
        // Ang mamana label here Tinitiyak nito ang isang mangyayari-bago relasyon sa anumang writes sa `strong` (sa partikular sa `Weak::upgrade`) bago decrements ng count `weak` (sa pamamagitan ng `Weak::drop`, na gumagamit release).
        // Kung ang na-upgrade na mahina na ref ay hindi kailanman nahulog, ang CAS dito ay mabibigo kaya wala kaming pakialam na mag-synchronize.
        //
        //
        //
        if self.inner().weak.compare_exchange(1, usize::MAX, Acquire, Relaxed).is_ok() {
            // Kailangan itong maging isang `Acquire` upang mai-synchronize ang pagbawas ng `strong` counter sa `drop`-ang nag-iisang pag-access na nangyayari kapag mayroon ngunit ang huling sanggunian ay ibinaba.
            //
            //
            let unique = self.inner().strong.load(Acquire) == 1;

            // Ang pagsulat ng paglabas dito ay sumasabay sa isang nabasa sa `downgrade`, na mabisang pumipigil sa nabasa sa itaas ng `strong` na mangyari pagkatapos ng pagsulat.
            //
            //
            self.inner().weak.store(1, Release); // bitawan ang kandado
            unique
        } else {
            false
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Arc<T> {
    /// Patak ang `Arc`.
    ///
    /// Babawasan nito ang malakas na bilang ng sanggunian.
    /// Kung ang malakas na bilang ng sanggunian ay umabot sa zero kung gayon ang tanging iba pang mga sanggunian (kung mayroon man) ay [`Weak`], kaya't `drop` namin ang panloob na halaga.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Arc::new(Foo);
    /// let foo2 = Arc::clone(&foo);
    ///
    /// drop(foo);    // Hindi naka-print kahit ano
    /// drop(foo2);   // Nagpi-print "dropped!"
    /// ```
    #[inline]
    fn drop(&mut self) {
        // Dahil ang `fetch_sub` ay mayroon nang atomic, hindi namin kailangang magsabay sa ibang mga thread maliban kung tatanggalin namin ang bagay.
        // Nalalapat ang parehong lohika na ito sa ibaba `fetch_sub` sa bilang ng `weak`.
        //
        if self.inner().strong.fetch_sub(1, Release) != 1 {
            return;
        }

        // Kailangan ang bakod na ito upang maiwasan ang muling pag-ayos ng paggamit ng data at pagtanggal ng data.
        // Dahil minarkahan ito ng `Release`, ang pagbawas ng bilang ng sanggunian ay sumasabay sa `Acquire` na bakod na ito.
        // Nangangahulugan ito na ang paggamit ng data ay nangyayari bago bawasan ang bilang ng sanggunian, na nangyayari bago ang bakod na ito, na nangyayari bago ang pagtanggal ng data.
        //
        // Tulad ng ipinaliwanag sa [Boost documentation][1],
        //
        // > Mahalagang ipatupad ang anumang posibleng pag-access sa object sa isa
        // > thread (sa pamamagitan ng isang umiiral na reference) sa *mangyayari bago* pagtanggal
        // > ang bagay sa ibang thread.Nakamit ito ng isang "release"
        // > operasyon matapos ang pag-drop ng isang sanggunian (anumang pag-access sa object
        // > sa pamamagitan ng sanggunian na ito ay dapat malinaw na nangyari dati), at an
        // > "acquire" operasyon bago tanggalin ang bagay.
        //
        // Sa partikular, habang ang mga nilalaman ng isang Arc ay karaniwang hindi nababago, posible na magkaroon ng panloob na pagsusulat sa isang bagay tulad ng isang Mutex<T>.
        // Dahil ang isang Mutex ay hindi nakuha kapag ito ay tinanggal, hindi kami maaaring umasa sa lohika ng pagsabay nito upang gumawa ng mga pagsusulat sa thread na Makikita ng isang destructor na tumatakbo sa thread B.
        //
        //
        // Tandaan din na ang kuha ng Kumuha dito ay maaaring mapalitan ng isang Kumuha ng pag-load, na maaaring mapabuti ang pagganap sa mga sitwasyong lubos na pinagtatalunan.Tingnan ang [2].
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        // [2]: (https://github.com/rust-lang/rust/pull/41714)
        //
        //
        //
        //
        //
        //
        //
        acquire!(self.inner().strong);

        unsafe {
            self.drop_slow();
        }
    }
}

impl Arc<dyn Any + Send + Sync> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// Subukang i-downcast ang `Arc<dyn Any + Send + Sync>` sa isang kongkretong uri.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::sync::Arc;
    ///
    /// fn print_if_string(value: Arc<dyn Any + Send + Sync>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Arc::new(my_string));
    /// print_if_string(Arc::new(0i8));
    /// ```
    pub fn downcast<T>(self) -> Result<Arc<T>, Self>
    where
        T: Any + Send + Sync + 'static,
    {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<ArcInner<T>>();
            mem::forget(self);
            Ok(Arc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T> Weak<T> {
    /// Bumubuo ng isang bagong `Weak<T>`, nang hindi naglalaan ng anumang memorya.
    /// Ang pagtawag sa [`upgrade`] sa halaga ng pagbabalik ay laging nagbibigay ng [`None`].
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut ArcInner<T>).expect("MAX is not 0") }
    }
}

/// Uri ng helper upang payagan ang pag-access sa mga bilang ng sanggunian nang hindi gumagawa ng anumang mga pagpapahayag tungkol sa patlang ng data.
///
struct WeakInner<'a> {
    weak: &'a atomic::AtomicUsize,
    strong: &'a atomic::AtomicUsize,
}

impl<T: ?Sized> Weak<T> {
    /// Nagbabalik ng isang hilaw na pointer sa bagay na `T` na itinuro ng `Weak<T>` na ito.
    ///
    /// Ang pointer ay may bisa lamang kung mayroong ilang mga malakas na sanggunian.
    /// Ang pointer ay maaaring nakabitin, hindi nakahanay o kahit [`null`] kung hindi man.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::ptr;
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// // Parehong tumuturo sa parehong bagay
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // Ang malakas dito ay pinapanatili itong buhay, kaya maaari pa rin nating ma-access ang object.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // Pero hindi na ngayon.
    /// // Maaari naming gawin weak.as_ptr(), ngunit ang pag-access sa pointer ay hahantong sa hindi natukoy na pag-uugali.
    /// // assert_eq! ("hello", hindi ligtas na {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // Kung nakabitin ang pointer, ibabalik namin nang direkta ang bantay.
            // Hindi ito maaaring maging isang wastong address ng payload, dahil ang payload ay hindi bababa sa pagkakahanay sa ArcInner (usize).
            ptr as *const T
        } else {
            // KALIGTASAN: kung ang__langling ay nagbabalik ng hindi totoo, kung gayon ang pointer ay hindi maaalis.
            // Ang payload ay maaaring mahulog sa puntong ito, at kailangan naming mapanatili ang kakayahang magamit, kaya't gumamit ng hilaw na pagmamanipula ng pointer.
            //
            unsafe { ptr::addr_of_mut!((*ptr).data) }
        }
    }

    /// Naubos ang `Weak<T>` at ginawang isang raw pointer.
    ///
    /// Ito ay nagko-convert ng mahina pointer sa isang raw pointer, habang pinapanatili ang pagmamay-ari ng isang mahinang sanggunian (ang mahinang bilang ay hindi binago ng operasyong ito).
    /// Maaari itong ibalik sa `Weak<T>` na may [`from_raw`].
    ///
    /// Ang parehong mga paghihigpit ng pag-access sa target ng pointer tulad ng sa [`as_ptr`] ay nalalapat.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Arc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Arc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// Nag-convert ng isang hilaw na pointer na dati nang nilikha ng [`into_raw`] pabalik sa `Weak<T>`.
    ///
    /// Maaari itong magamit upang ligtas na makakuha ng isang malakas na sanggunian (sa pamamagitan ng pagtawag sa [`upgrade`] sa paglaon) o upang makitungo sa mahinang bilang sa pamamagitan ng pagbagsak ng `Weak<T>`.
    ///
    /// Kinakailangan ang pagmamay-ari ng isang mahinang sanggunian (maliban sa mga payo na nilikha ng [`new`], dahil ang mga ito ay hindi nagmamay-ari ng anupaman; gumagana pa rin ang pamamaraan sa kanila).
    ///
    /// # Safety
    ///
    /// Ang pointer ay dapat na nagmula sa [`into_raw`] at dapat pa ring pagmamay-ari ang potensyal na mahinang sanggunian nito.
    ///
    /// Pinapayagan ang malakas na bilang na maging 0 sa oras ng pagtawag nito.
    /// Gayunpaman, kinukuha ang pagmamay-ari ng isang mahinang sanggunian na kasalukuyang kinakatawan bilang isang hilaw na pointer (ang mahinang bilang ay hindi binago ng operasyong ito) at samakatuwid dapat itong ipares sa isang nakaraang tawag sa [`into_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    ///
    /// let raw_1 = Arc::downgrade(&strong).into_raw();
    /// let raw_2 = Arc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Arc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Arc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // Pagbawas ng huling mahina na bilang.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`new`]: Weak::new
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`forget`]: std::mem::forget
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // Tingnan ang Weak::as_ptr para sa konteksto kung paano nakuha ang input pointer.

        let ptr = if is_dangling(ptr as *mut T) {
            // Ito ay isang nakalawit Mahinang.
            ptr as *mut ArcInner<T>
        } else {
            // Kung hindi man, ginagarantiyahan namin na ang pointer ay nagmula sa isang nondangling Weak.
            // KALIGTASAN: ang data_offset ay ligtas na tawagan, dahil ang ptr ay tumutukoy sa isang tunay (potensyal na bumagsak) T.
            let offset = unsafe { data_offset(ptr) };
            // Sa gayon, binabaligtad namin ang offset upang makuha ang buong RcBox.
            // KALIGTASAN: ang pointer ay nagmula sa isang Mahina, kaya't ang offset na ito ay ligtas.
            unsafe { (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // KALIGTASAN: nakuhang muli namin ang orihinal na Weak pointer, kaya makalikha ng Mahina.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }
}

impl<T: ?Sized> Weak<T> {
    /// Mga pagtatangka upang i-upgrade ang `Weak` pointer sa isang [`Arc`], naantala ang pagbaba ng panloob na halaga kung matagumpay.
    ///
    ///
    /// Ibinabalik ang [`None`] kung ang panloob na halaga ay nai-drop na.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    ///
    /// let strong_five: Option<Arc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // Wasakin ang lahat ng malakas na mga payo.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Arc<T>> {
        // Gumagamit kami ng isang CAS loop upang madagdagan ang malakas na bilang sa halip na isang fetch_add dahil ang pagpapaandar na ito ay hindi dapat gawin ang bilang ng sanggunian mula sa zero hanggang sa isa.
        //
        //
        let inner = self.inner()?;

        // Ang nakakarelaks na pag-load dahil ang anumang pagsulat ng 0 na maaari nating obserbahan ay umalis sa patlang sa isang permanenteng zero na estado (kaya't ang "stale" na nabasa na 0 ay pagmultahin), at anumang iba pang halaga ay nakumpirma sa pamamagitan ng CAS sa ibaba.
        //
        //
        //
        let mut n = inner.strong.load(Relaxed);

        loop {
            if n == 0 {
                return None;
            }

            // Tingnan ang mga komento sa `Arc::clone` para sa kung bakit namin ito ginagawa (para sa `mem::forget`).
            if n > MAX_REFCOUNT {
                abort();
            }

            // Ang pagpapahinga ay mabuti para sa kaso ng kabiguan dahil wala kaming anumang mga inaasahan tungkol sa bagong estado.
            // Kinakailangan ang pagkuha upang ang kaso ng tagumpay ay mag-synchronize sa `Arc::new_cyclic`, kapag ang panloob na halaga ay maaaring mapasimulan pagkatapos na malikha ang mga sanggunian ng `Weak`.
            // Sa kasong iyon, inaasahan naming obserbahan ang ganap na naisimulang halaga.
            //
            match inner.strong.compare_exchange_weak(n, n + 1, Acquire, Relaxed) {
                Ok(_) => return Some(Arc::from_inner(self.ptr)), // null check sa itaas
                Err(old) => n = old,
            }
        }
    }

    /// Nakukuha ang bilang ng mga malakas na (`Arc`) pointer na tumuturo sa paglalaan na ito.
    ///
    /// Kung ang `self` ay nilikha gamit ang [`Weak::new`], ibabalik nito ang 0.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong.load(SeqCst) } else { 0 }
    }

    /// Nakakakuha ng isang approximation ng bilang ng mga `Weak` pointers na tumuturo sa paglalaan na ito.
    ///
    /// Kung ang `self` ay nilikha gamit ang [`Weak::new`], o kung walang natitirang mga malakas na payo, ibabalik nito ang 0.
    ///
    /// # Accuracy
    ///
    /// Dahil sa mga detalye ng pagpapatupad, ang naibalik na halaga ay maaaring i-off ng 1 sa alinmang direksyon kapag ang iba pang mga thread ay nagmamanipula ng anumang `Arc`s o`Weak`s na tumuturo sa parehong paglalaan.
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                let weak = inner.weak.load(SeqCst);
                let strong = inner.strong.load(SeqCst);
                if strong == 0 {
                    0
                } else {
                    // Dahil naobserbahan namin na mayroong hindi bababa sa isang malakas na pointer pagkatapos basahin ang mahinang bilang, alam namin na ang implicit mahinang sanggunian (naroroon tuwing buhay ang anumang malakas na sanggunian) ay nasa paligid pa rin kapag naobserbahan namin ang mahinang bilang, at kung gayon ay ligtas na mabawasan ito.
                    //
                    //
                    //
                    //
                    weak - 1
                }
            })
            .unwrap_or(0)
    }

    /// Ibinabalik `None` kapag ang pointer ay nakabitin at walang inilalaan `ArcInner`, (ibig sabihin, kapag ang `Weak` na ito ay nilikha ng `Weak::new`).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // Maingat kaming *hindi* lumikha ng isang sanggunian na sumasaklaw sa patlang "data", dahil ang patlang ay maaaring na-mutate nang sabay-sabay (halimbawa, kung ang huling `Arc` ay nahulog, ang patlang ng data ay mahuhulog sa lugar).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// Ibinabalik ang `true` kung ang dalawang `Mahina` ay tumuturo sa parehong paglalaan (katulad ng [`ptr::eq`]), o kung pareho ay hindi tumuturo sa anumang paglalaan (sapagkat nilikha ang mga ito sa `Weak::new()`).
    ///
    ///
    /// # Notes
    ///
    /// Dahil pinaghahambing nito ang mga pahiwatig nangangahulugan ito na ang `Weak::new()` ay pantay-pantay sa bawat isa, kahit na hindi sila tumuturo sa anumang paglalaan.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let first_rc = Arc::new(5);
    /// let first = Arc::downgrade(&first_rc);
    /// let second = Arc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(5);
    /// let third = Arc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// Ang paghahambing ng `Weak::new`.
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(());
    /// let third = Arc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// Gumagawa ng isang clone ng `Weak` pointer na tumuturo sa parehong paglalaan.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let weak_five = Arc::downgrade(&Arc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        let inner = if let Some(inner) = self.inner() {
            inner
        } else {
            return Weak { ptr: self.ptr };
        };
        // Tingnan ang mga komento sa Arc::clone() kung bakit ito nakakarelaks.
        // Maaari itong gumamit ng isang fetch_add (hindi papansin ang kandado) dahil ang mahinang bilang ay naka-lock lamang kung saan walang *ibang* mahihinang mga payo na mayroon.
        //
        // (Kaya't hindi namin maaaring patakbuhin ang code na ito sa kasong iyon).
        let old_size = inner.weak.fetch_add(1, Relaxed);

        // Tingnan ang mga komento sa Arc::clone() kung bakit ginagawa namin ito (para sa mem::forget).
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// Bumubuo ng isang bagong `Weak<T>`, nang hindi naglalaan ng memorya.
    /// Ang pagtawag sa [`upgrade`] sa halaga ng pagbabalik ay laging nagbibigay ng [`None`].
    ///
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// Patak ang `Weak` pointer.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Arc::new(Foo);
    /// let weak_foo = Arc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // Hindi naka-print kahit ano
    /// drop(foo);        // Nagpi-print "dropped!"
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        // Kung malalaman natin na tayo ang huling mahina na taguduro, oras na upang tuluyang makitungo ang data.Tingnan ang talakayan sa Arc::drop() tungkol sa mga pag-order ng memorya
        //
        // Ito ay hindi kinakailangan upang suriin para sa mga naka-lock na estado dito, dahil ang mahina count ay maaari lamang na naka-lock kung mayroong tiyak isang mahinang ref, ibig sabihin na drop maaari lamang magkakasunod na tumakbo ON na natitira mahina ref, na kung saan ay maaari lamang mangyari matapos ang lock ay inilabas.
        //
        //
        //
        //
        //
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        if inner.weak.fetch_sub(1, Release) == 1 {
            acquire!(inner.weak);
            unsafe { Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr())) }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait ArcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Arc<T>) -> bool;
    fn ne(&self, other: &Arc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    default fn eq(&self, other: &Arc<T>) -> bool {
        **self == **other
    }
    #[inline]
    default fn ne(&self, other: &Arc<T>) -> bool {
        **self != **other
    }
}

/// Ginagawa namin ang pagdadalubhasa dito, at hindi bilang isang mas pangkalahatang pag-optimize sa `&T`, dahil sa kabilang banda ay magdagdag ng gastos sa lahat ng mga pagsusuri sa pagkakapantay-pantay sa mga ref.
/// Ipinapalagay namin na ang `Arc`s ay ginagamit upang mag-imbak ng malalaking halaga, mabagal na i-clone, ngunit mabigat din upang suriin ang pagkakapantay-pantay, na nagiging sanhi ng mas madaling pagbayad ng gastos na ito.
///
/// Malamang na mayroon ding dalawang `Arc` clone, na tumuturo sa parehong halaga, kaysa sa dalawang `&T`s.
///
/// Magagawa lamang namin ito kapag ang `T: Eq` bilang isang `PartialEq` ay maaaring sadyang hindi masugpo.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + crate::rc::MarkerEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        Arc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        !Arc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Arc<T> {
    /// Pagkakapantay-pantay para sa dalawang `Arc`s.
    ///
    /// Dalawang `Arc`s ay pantay kung ang kanilang panloob na halaga ay pantay, kahit na nakaimbak sila sa iba't ibang paglalaan.
    ///
    /// Kung ang `T` ay nagpapatupad din ng `Eq` (nagpapahiwatig ng reflexivity ng pagkakapantay-pantay), dalawang `Arc` na tumuturo sa parehong paglalaan ay palaging pantay.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five == Arc::new(5));
    /// ```
    ///
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::eq(self, other)
    }

    /// Hindi pagkakapantay-pantay para sa dalawang `Arc`s.
    ///
    /// Dalawang `Arc`s ay hindi pantay kung ang kanilang panloob na halaga ay hindi pantay.
    ///
    /// Kung `T` ring nagpapatupad `Eq` (implying reflexivity ng pagkakapantay-pantay), dalawang `Arc`s na tumuturo sa parehong halaga ay hindi patas.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five != Arc::new(6));
    /// ```
    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Arc<T> {
    /// Bahagyang paghahambing para sa dalawang `Arc`s.
    ///
    /// Ang dalawa ay inihambing sa pamamagitan ng pagtawag sa `partial_cmp()` sa kanilang panloob na mga halaga.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Arc::new(6)));
    /// ```
    fn partial_cmp(&self, other: &Arc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// Mas mababa kaysa sa paghahambing para sa dalawang `Arc`s.
    ///
    /// Ang dalawa ay inihambing sa pamamagitan ng pagtawag sa `<` sa kanilang panloob na mga halaga.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five < Arc::new(6));
    /// ```
    fn lt(&self, other: &Arc<T>) -> bool {
        *(*self) < *(*other)
    }

    /// 'Mas mababa sa o katumbas ng' paghahambing para sa dalawang `Arc`s.
    ///
    /// Ang dalawa ay inihambing sa pamamagitan ng pagtawag sa `<=` sa kanilang panloob na mga halaga.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five <= Arc::new(5));
    /// ```
    fn le(&self, other: &Arc<T>) -> bool {
        *(*self) <= *(*other)
    }

    /// Mas mahusay kaysa sa paghahambing para sa dalawang `Arc`s.
    ///
    /// Ang dalawa ay inihambing sa pamamagitan ng pagtawag sa `>` sa kanilang panloob na mga halaga.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five > Arc::new(4));
    /// ```
    fn gt(&self, other: &Arc<T>) -> bool {
        *(*self) > *(*other)
    }

    /// 'Mas malaki kaysa sa o katumbas ng' paghahambing para sa dalawang `Arc`s.
    ///
    /// Ang dalawa ay inihambing sa pamamagitan ng pagtawag sa `>=` sa kanilang panloob na mga halaga.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five >= Arc::new(5));
    /// ```
    fn ge(&self, other: &Arc<T>) -> bool {
        *(*self) >= *(*other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Arc<T> {
    /// Paghahambing para sa dalawang `Arc`s.
    ///
    /// Ang dalawa ay inihambing sa pamamagitan ng pagtawag sa `cmp()` sa kanilang panloob na mga halaga.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Arc::new(6)));
    /// ```
    fn cmp(&self, other: &Arc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Arc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Arc<T> {
    /// Lumilikha ng isang bagong `Arc<T>`, na may halagang `Default` para sa `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x: Arc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    fn default() -> Arc<T> {
        Arc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Arc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Arc<T> {
    fn from(t: T) -> Self {
        Arc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Arc<[T]> {
    /// Maglaan ng isang slice na binibilang ng sanggunian at punan ito sa pamamagitan ng pag-clone ng mga item ng 'v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Arc<[T]> {
        <Self as ArcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Arc<str> {
    /// Magtalaga ng isang referral na binibilang na `str` at kopyahin ang `v` dito.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let shared: Arc<str> = Arc::from("eggplant");
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Arc<str> {
        let arc = Arc::<[u8]>::from(v.as_bytes());
        unsafe { Arc::from_raw(Arc::into_raw(arc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Arc<str> {
    /// Magtalaga ng isang referral na binibilang na `str` at kopyahin ang `v` dito.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: String = "eggplant".to_owned();
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Arc<str> {
        Arc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Arc<T> {
    /// Ilipat ang isang boxed bagay sa isang bagong, reference-binibilang allocation.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Box<str> = Box::from("eggplant");
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Arc<T> {
        Arc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Arc<[T]> {
    /// Maglaan ng isang slice na binibilang ng sanggunian at ilipat dito ang mga item ng `v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Vec<i32> = vec![1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(unique);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Arc<[T]> {
        unsafe {
            let arc = Arc::copy_from_slice(&v);

            // Payagan ang Vec na palayain ang memorya nito, ngunit hindi sirain ang mga nilalaman nito
            v.set_len(0);

            arc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Arc<B>
where
    B: ToOwned + ?Sized,
    Arc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Arc<B> {
        match cow {
            Cow::Borrowed(s) => Arc::from(s),
            Cow::Owned(s) => Arc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Arc<[T]>> for Arc<[T; N]> {
    type Error = Arc<[T]>;

    fn try_from(boxed_slice: Arc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Arc::from_raw(Arc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Arc<[T]> {
    /// Kinukuha ang bawat elemento sa `Iterator` at kinokolekta ito sa isang `Arc<[T]>`.
    ///
    /// # Mga katangian sa pagganap
    ///
    /// ## Ang pangkalahatang kaso
    ///
    /// Sa pangkalahatang kaso, pagkolekta sa `Arc<[T]>` ay ginagawa sa pamamagitan ng unang pagkolekta sa isang `Vec<T>`.Iyon ay, kapag sumusulat ng sumusunod:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// ito behaves bilang kung kami ay sumulat:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // Ang unang hanay ng mga paglalaan ay nangyayari dito.
    ///     .into(); // Ang isang pangalawang paglalaan para sa `Arc<[T]>` ay nangyayari dito.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// Ito ay maglalaan ng maraming beses kung kinakailangan para sa pagbuo ng `Vec<T>` at pagkatapos ay maglalaan ito ng isang beses para sa pag-on sa `Vec<T>` sa `Arc<[T]>`.
    ///
    ///
    /// ## Iterator na alam ang haba
    ///
    /// Kapag ang iyong `Iterator` ay nagpapatupad ng `TrustedLen` at eksaktong sukat, isang solong paglalaan ang gagawin para sa `Arc<[T]>`.Halimbawa:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).collect(); // Isang solong paglalaan lamang ang nangyayari dito.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToArcSlice::to_arc_slice(iter.into_iter())
    }
}

/// Ang pagdadalubhasa na ginagamit ng trait para sa pagkolekta sa `Arc<[T]>`.
trait ToArcSlice<T>: Iterator<Item = T> + Sized {
    fn to_arc_slice(self) -> Arc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToArcSlice<T> for I {
    default fn to_arc_slice(self) -> Arc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToArcSlice<T> for I {
    fn to_arc_slice(self) -> Arc<[T]> {
        // Ito ang kaso para sa isang `TrustedLen` iterator.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // KALIGTASAN: Kailangan naming tiyakin na ang iterator ay may eksaktong haba at mayroon kami.
                Arc::from_iter_exact(self, low)
            }
        } else {
            // Bumalik sa normal na pagpapatupad.
            self.collect::<Vec<T>>().into()
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Arc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Arc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Arc<T> {}

/// Kunin ang offset sa loob ng isang `ArcInner` para sa payload sa likod ng isang pointer.
///
/// # Safety
///
/// Ang pointer ay dapat na magturo sa (at may wastong metadata para sa) isang dating wastong halimbawa ng T, ngunit ang T ay pinapayagan na mahulog.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // Ihanay ang hindi pinagsamang halaga sa dulo ng ArcInner.
    // Dahil ang RcBox ay repr(C), palagi itong magiging huling larangan sa memorya.
    // KALIGTASAN: yamang ang tanging mga hindi naisasadyang uri na posible ay mga hiwa, mga bagay na trait,
    // at mga panlabas na uri, ang kinakailangan sa kaligtasan ng pag-input ay kasalukuyang sapat upang masiyahan ang mga kinakailangan ng align_of_val_raw;ito ay isang detalye ng pagpapatupad ng wika na maaaring hindi umaasa sa labas ng std.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<ArcInner<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}