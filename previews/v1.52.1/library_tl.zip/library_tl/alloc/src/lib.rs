//! # Ang pangunahing paglalaan ng Rust at library ng mga koleksyon
//!
//! Nagbibigay ang library na ito ng mga matalinong payo at koleksyon para sa pamamahala ng mga halagang inilalaan ng tambak
//!
//! Ang library na ito, tulad ng libcore, karaniwang hindi kailangang gamitin nang direkta dahil ang mga nilalaman nito ay muling na-export sa [`std` crate](../std/index.html).
//! Ang Crates na gumagamit ng `#![no_std]` na katangian gayunpaman ay karaniwang hindi nakasalalay sa `std`, kaya sa halip ay gagamitin nila ang crate na ito.
//!
//! ## Mga kahon ng halaga
//!
//! Ang uri ng [`Box`] ay isang matalinong uri ng pointer.Maaari lamang magkaroon ng isang may-ari ng isang [`Box`], at maaaring magpasya ang may-ari na i-mutate ang mga nilalaman, na live sa tambak.
//!
//! Ang uri na ito ay maaaring maipadala sa mga thread nang mahusay dahil ang laki ng isang halagang `Box` ay kapareho ng isang pointer.
//! Ang mga istraktura ng data na tulad ng puno ay madalas na itinayo sa mga kahon dahil ang bawat node ay madalas na may isang may-ari lamang, ang magulang.
//!
//! ## Binibilang ang mga payo ng sanggunian
//!
//! Ang uri ng [`Rc`] ay isang di-threadsafe na nabibilang na sangguniang uri ng pointer na inilaan para sa pagbabahagi ng memorya sa loob ng isang thread.
//! Ang isang [`Rc`] pointer ay nagbabalot ng isang uri, `T`, at pinapayagan lamang ang pag-access sa `&T`, isang nakabahaging sanggunian.
//!
//! Ang uri na ito ay kapaki-pakinabang kapag ang minana na pagkakabago (tulad ng paggamit ng [`Box`]) ay masyadong pumipigil para sa isang application, at madalas na ipinares sa mga uri ng [`Cell`] o [`RefCell`] upang payagan ang pag-mutate.
//!
//!
//! ## Atomiko na sanggunian ang binibilang na mga payo
//!
//! Ang uri ng [`Arc`] ay ang katumbas ng threadsafe ng [`Rc`] na uri.Nagbibigay ito ng lahat ng parehong pag-andar ng [`Rc`], maliban kung kinakailangan nito na maibabahagi ang nilalaman na uri na `T`.
//! Bilang karagdagan, ang [`Arc<T>`][`Arc`] ay mismong maipapadala habang ang [`Rc<T>`][`Rc`] ay hindi.
//!
//! Pinapayagan ng uri na ito para sa ibinahaging pag-access sa nilalaman na nilalaman, at madalas na ipinares sa mga primitibo ng pag-synchronize tulad ng mga mutexes upang payagan ang pag-mutate ng mga ibinahaging mapagkukunan.
//!
//! ## Collections
//!
//! Ang pagpapatupad ng pinaka-karaniwang pangkalahatang layunin ng mga istraktura ng data ay tinukoy sa library na ito.Ang mga ito ay muling nai-export sa pamamagitan ng [standard collections library](../std/collections/index.html).
//!
//! ## Mga interface ng tambak
//!
//! Tinutukoy ng module na [`alloc`](alloc/index.html) ang mababang antas na interface sa default na global na tagapaglaan.Hindi ito katugma sa libc allocator API.
//!
//! [`Arc`]: sync
//! [`Box`]: boxed
//! [`Cell`]: core::cell
//! [`Rc`]: rc
//! [`RefCell`]: core::cell
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(unused_attributes)]
#![stable(feature = "alloc", since = "1.36.0")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    html_playground_url = "https://play.rust-lang.org/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/",
    test(no_crate_inject, attr(allow(unused_variables), deny(warnings)))
)]
#![no_std]
#![needs_allocator]
#![warn(deprecated_in_future)]
#![warn(missing_docs)]
#![warn(missing_debug_implementations)]
#![allow(explicit_outlives_requirements)]
#![deny(unsafe_op_in_unsafe_fn)]
#![feature(rustc_allow_const_fn_unstable)]
#![cfg_attr(not(test), feature(generator_trait))]
#![cfg_attr(test, feature(test))]
#![cfg_attr(test, feature(new_uninit))]
#![feature(allocator_api)]
#![feature(vec_extend_from_within)]
#![feature(array_chunks)]
#![feature(array_methods)]
#![feature(array_windows)]
#![feature(allow_internal_unstable)]
#![feature(arbitrary_self_types)]
#![feature(async_stream)]
#![feature(box_patterns)]
#![feature(box_syntax)]
#![feature(cfg_sanitize)]
#![feature(cfg_target_has_atomic)]
#![feature(coerce_unsized)]
#![feature(const_btree_new)]
#![feature(const_fn)]
#![feature(cow_is_borrowed)]
#![feature(const_cow_is_borrowed)]
#![feature(destructuring_assignment)]
#![feature(dispatch_from_dyn)]
#![feature(core_intrinsics)]
#![feature(dropck_eyepatch)]
#![feature(exact_size_is_empty)]
#![feature(exclusive_range_pattern)]
#![feature(extend_one)]
#![feature(fmt_internals)]
#![feature(fn_traits)]
#![feature(fundamental)]
#![feature(inplace_iteration)]
#![feature(int_bits_const)]
// Sa teknikal na paraan, ito ay isang bug sa rustdoc: nakikita ng rustdoc ang dokumentasyon sa mga bloke ng `#[lang = slice_alloc]` ay para sa `&[T]`, na mayroon ding dokumentasyon na ginagamit ang tampok na ito sa `core`, at nagalit na ang tampok na gate ay hindi pinagana.
// Sa isip, hindi nito susuriin ang tampok na gate para sa mga doc mula sa iba pang crates, ngunit dahil maaari lamang itong lumitaw para sa mga lang na item, tila hindi ito nagkakahalaga ng pag-aayos.
//
//
#![feature(intra_doc_pointers)]
#![feature(lang_items)]
#![feature(layout_for_ptr)]
#![feature(maybe_uninit_ref)]
#![feature(negative_impls)]
#![feature(never_type)]
#![feature(nll)]
#![feature(nonnull_slice_from_raw_parts)]
#![feature(auto_traits)]
#![feature(option_result_unwrap_unchecked)]
#![feature(or_patterns)]
#![feature(pattern)]
#![feature(ptr_internals)]
#![feature(rustc_attrs)]
#![feature(receiver_trait)]
#![feature(min_specialization)]
#![feature(set_ptr_value)]
#![feature(slice_ptr_get)]
#![feature(slice_ptr_len)]
#![feature(slice_range)]
#![feature(staged_api)]
#![feature(str_internals)]
#![feature(trusted_len)]
#![feature(unboxed_closures)]
#![feature(unicode_internals)]
#![cfg_attr(bootstrap, feature(unsafe_block_in_unsafe_fn))]
#![feature(unsize)]
#![feature(unsized_fn_params)]
#![feature(allocator_internals)]
#![feature(slice_partition_dedup)]
#![feature(maybe_uninit_extra, maybe_uninit_slice, maybe_uninit_uninit_array)]
#![feature(alloc_layout_extra)]
#![feature(trusted_random_access)]
#![feature(try_trait)]
#![cfg_attr(bootstrap, feature(type_alias_impl_trait))]
#![cfg_attr(not(bootstrap), feature(min_type_alias_impl_trait))]
#![feature(associated_type_bounds)]
#![feature(slice_group_by)]
#![feature(decl_macro)]
// Payagan ang pagsubok sa library na ito

#[cfg(test)]
#[macro_use]
extern crate std;
#[cfg(test)]
extern crate test;

// Modyul na may panloob na macros na ginagamit ng iba pang mga module (kailangang isama bago ang iba pang mga module).
#[macro_use]
mod macros;

// Mga tambak na ibinigay para sa mga diskarte sa paglalaan ng mababang antas

pub mod alloc;

// Mga pangunahing uri gamit ang mga tambak sa itaas

// Kailangang tukuyin nang may kondisyon ang mod mula sa `boxed.rs` upang maiwasan ang pagdoble ng mga lang-item kapag nagtatayo sa pagsubok na cfg;ngunit kailangan ding payagan ang code na magkaroon ng mga deklarasyong `use boxed::Box;`.
//
//
#[cfg(not(test))]
pub mod boxed;
#[cfg(test)]
mod boxed {
    pub use std::boxed::Box;
}
pub mod borrow;
pub mod collections;
pub mod fmt;
pub mod prelude;
pub mod raw_vec;
pub mod rc;
pub mod slice;
pub mod str;
pub mod string;
#[cfg(target_has_atomic = "ptr")]
pub mod sync;
#[cfg(target_has_atomic = "ptr")]
pub mod task;
#[cfg(test)]
mod tests;
pub mod vec;

#[doc(hidden)]
#[unstable(feature = "liballoc_internals", issue = "none", reason = "implementation detail")]
pub mod __export {
    pub use core::format_args;
}