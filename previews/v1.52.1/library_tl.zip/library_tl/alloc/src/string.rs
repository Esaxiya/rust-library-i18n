//! Ang isang UTF-8-encode, growable string.
//!
//! Naglalaman ang modyul na ito ng uri ng [`String`], ang [`ToString`] trait para sa pag-convert sa mga string, at maraming mga uri ng error na maaaring magresulta mula sa pagtatrabaho sa mga [`String`] s.
//!
//!
//! # Examples
//!
//! Mayroong maraming mga paraan upang lumikha ng isang bagong [`String`] mula sa isang literal na string:
//!
//! ```
//! let s = "Hello".to_string();
//!
//! let s = String::from("world");
//! let s: String = "also this".into();
//! ```
//!
//! Maaari kang lumikha ng isang bagong [`String`] mula sa isang mayroon nang sa pamamagitan ng concatenating sa
//! `+`:
//!
//! ```
//! let s = "Hello".to_string();
//!
//! let message = s + " world!";
//! ```
//!
//! Kung mayroon kang isang vector ng wastong UTF-8 bytes, maaari kang gumawa ng isang [`String`] mula rito.Maaari mo ring gawin ang reverse.
//!
//! ```
//! let sparkle_heart = vec![240, 159, 146, 150];
//!
//! // Alam namin na ang mga byte na ito ay wasto, kaya gagamitin namin ang `unwrap()`.
//! let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
//!
//! assert_eq!("💖", sparkle_heart);
//!
//! let bytes = sparkle_heart.into_bytes();
//!
//! assert_eq!(bytes, [240, 159, 146, 150]);
//! ```
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::char::{decode_utf16, REPLACEMENT_CHARACTER};
use core::fmt;
use core::hash;
use core::iter::{FromIterator, FusedIterator};
use core::ops::Bound::{Excluded, Included, Unbounded};
use core::ops::{self, Add, AddAssign, Index, IndexMut, Range, RangeBounds};
use core::ptr;
use core::slice;
use core::str::{lossy, pattern::Pattern};

use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::collections::TryReserveError;
use crate::str::{self, from_boxed_utf8_unchecked, Chars, FromStr, Utf8Error};
use crate::vec::Vec;

/// Ang isang UTF-8-encode, growable string.
///
/// Ang uri ng `String` ay ang pinakakaraniwang uri ng string na may pagmamay-ari sa mga nilalaman ng string.Ito ay may malapit na ugnayan sa hiniram nitong katapat, ang primitive [`str`].
///
/// # Examples
///
/// Maaari kang lumikha ng isang `String` mula sa [a literal string][`str`] na may [`String::from`]:
///
/// [`String::from`]: From::from
///
/// ```
/// let hello = String::from("Hello, world!");
/// ```
///
/// Maaari mong idagdag ang isang [`char`] sa isang `String` gamit ang [`push`] na pamamaraan, at idagdag ang isang [`&str`] gamit ang [`push_str`] na pamamaraan:
///
/// ```
/// let mut hello = String::from("Hello, ");
///
/// hello.push('w');
/// hello.push_str("orld!");
/// ```
///
/// [`push`]: String::push
/// [`push_str`]: String::push_str
///
/// Kung mayroon kang isang vector ng UTF-8 bytes, maaari kang lumikha ng isang `String` mula dito gamit ang [`from_utf8`] na pamamaraan:
///
/// ```
/// // ilang mga byte, sa isang vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // Alam namin na ang mga byte na ito ay wasto, kaya gagamitin namin ang `unwrap()`.
/// let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// [`from_utf8`]: String::from_utf8
///
/// # UTF-8
///
/// Ang mga string ay palaging may bisa UTF-8.Ito ay may ilang mga implikasyon, ang una sa mga ito ay kung kailangan mo ng isang hindi UTF-8 string, isaalang-alang ang [`OsString`].Ito ay katulad, ngunit wala ang UTF-8 hadlang.Ang pangalawang implikasyon ay hindi ka maaaring mag-index sa isang `String`:
///
/// ```compile_fail,E0277
/// let s = "hello";
///
/// println!("The first letter of s is {}", s[0]); // ERROR!!!
/// ```
///
/// [`OsString`]: ../../std/ffi/struct.OsString.html
///
/// Ang pag-index ay inilaan upang maging isang pagpapatakbo ng patuloy na oras, ngunit hindi kami pinapayagan ng pag-encode ng UTF-8 na gawin ito.Higit pa rito, hindi ito i-clear kung ano ang uri ng bagay ang index ay dapat ibalik: isang byte, isang codepoint, o isang grapheme kumpol.
/// Ang [`bytes`] at [`chars`] na pamamaraan ay nagbabalik ng mga iterator sa unang dalawa, ayon sa pagkakabanggit.
///
/// [`bytes`]: str::bytes
/// [`chars`]: str::chars
///
/// # Deref
///
/// Ipapatupad ng `String 'ang [` Deref`]`<Target=str>`, at kaya pagmamana ng lahat ng mga pamamaraan ng [` str`].Bilang karagdagan, nangangahulugan ito na maaari mong ipasa ang isang `String` sa isang pagpapaandar na tumatagal ng isang [`&str`] sa pamamagitan ng paggamit ng isang ampersand (`&`):
///
/// ```
/// fn takes_str(s: &str) { }
///
/// let s = String::from("Hello");
///
/// takes_str(&s);
/// ```
///
/// Lilikha ito ng isang [`&str`] mula sa `String` at ipasa ito. Ang conversion na ito ay napaka-mura, at sa pangkalahatan, tatanggapin ng mga function ang [`&str`] s bilang mga argumento maliban kung kailangan nila ng `String` para sa ilang partikular na dahilan.
///
/// Sa ilang mga kaso, walang sapat na impormasyon ang Rust upang magawa ang conversion na ito, na kilala bilang pamimilit [`Deref`].Sa sumusunod na halimbawa ang isang string slice [`&'a str`][`&str`] ay nagpapatupad ng trait `TraitExample`, at ang pagpapaandar na `example_func` ay kumukuha ng anumang nagpapatupad ng trait.
/// Sa kasong ito, kakailanganin ng Rust na gumawa ng dalawang implicit na conversion, na walang paraan ang Rust.
/// Para sa kadahilanang iyon, ang sumusunod na halimbawa ay hindi makakaipon.
///
/// ```compile_fail,E0277
/// trait TraitExample {}
///
/// impl<'a> TraitExample for &'a str {}
///
/// fn example_func<A: TraitExample>(example_arg: A) {}
///
/// let example_string = String::from("example_string");
/// example_func(&example_string);
/// ```
///
/// Mayroong dalawang mga pagpipilian na gagana sa halip.Ang una ay upang palitan ang linya `example_func(&example_string);` sa `example_func(example_string.as_str());`, gamit ang pamamaraang [`as_str()`] upang tahasang makuha ang hiwa ng string na naglalaman ng string.
/// Ang pangalawang paraan ay binabago ang `example_func(&example_string);` sa `example_func(&*example_string);`.
/// Sa kasong ito, dinidisermefer namin ang isang `String` sa isang [`str`][`&str`], pagkatapos ay isinangguni ang [`str`][`&str`] pabalik sa [`&str`].
/// Ang pangalawang paraan ay mas idiomatiko, subalit pareho ang gumagana upang tahasang gawin ang conversion sa halip na umasa sa implicit na conversion.
///
/// # Representation
///
/// Ang isang `String` ay binubuo ng tatlong mga bahagi: isang pointer sa ilang mga byte, isang haba, at isang kapasidad.Ang pointer ay tumuturo sa isang panloob na buffer na ginagamit ng `String` upang maimbak ang data nito.Ang haba ay ang bilang ng mga byte na kasalukuyang nakaimbak sa buffer, at ang kapasidad ay ang laki ng buffer sa mga byte.
///
/// Tulad ng naturan, ang haba ay palaging magiging mas mababa sa o katumbas ng kakayahan.
///
/// Ang buffer na ito ay laging nakaimbak sa tambak.
///
/// Maaari mong tingnan ang mga ito sa pamamaraang [`as_ptr`], [`len`], at [`capacity`]:
///
/// ```
/// use std::mem;
///
/// let story = String::from("Once upon a time...");
///
/// // FIXME I-update ito kapag na-stabilize ang vector_into_raw_parts.
/// // Pigilan ang awtomatikong pag-drop ng data ng String
/// let mut story = mem::ManuallyDrop::new(story);
///
/// let ptr = story.as_mut_ptr();
/// let len = story.len();
/// let capacity = story.capacity();
///
/// // ang kwento ay mayroong labing siyam na byte
/// assert_eq!(19, len);
///
/// // Maaari naming muling itayo ang isang String out of ptr, len, at kapasidad.
/// // Lahat ito ay hindi ligtas sapagkat responsable kaming tiyakin na wasto ang mga bahagi:
/////
/// let s = unsafe { String::from_raw_parts(ptr, len, capacity) } ;
///
/// assert_eq!(String::from("Once upon a time..."), s);
/// ```
///
/// [`as_ptr`]: str::as_ptr
/// [`len`]: String::len
/// [`capacity`]: String::capacity
///
/// Kung ang isang `String` ay may sapat na kapasidad, ang pagdaragdag ng mga elemento dito ay hindi muling ilalaan.Halimbawa, isaalang-alang ang program na ito:
///
/// ```
/// let mut s = String::new();
///
/// println!("{}", s.capacity());
///
/// for _ in 0..5 {
///     s.push_str("hello");
///     println!("{}", s.capacity());
/// }
/// ```
///
/// Ipapalabas nito ang sumusunod:
///
/// ```text
/// 0
/// 5
/// 10
/// 20
/// 20
/// 40
/// ```
///
/// Sa una, wala kaming memorya na inilalaan sa lahat, ngunit sa pagdaragdag namin sa string, pinapataas nito nang naaangkop ang kapasidad nito.Kung sa halip ay gagamitin namin ang [`with_capacity`] na paraan upang maglaan ng tamang kapasidad nang una:
///
/// ```
/// let mut s = String::with_capacity(25);
///
/// println!("{}", s.capacity());
///
/// for _ in 0..5 {
///     s.push_str("hello");
///     println!("{}", s.capacity());
/// }
/// ```
///
/// [`with_capacity`]: String::with_capacity
///
/// Nagtapos kami sa ibang output:
///
/// ```text
/// 25
/// 25
/// 25
/// 25
/// 25
/// 25
/// ```
///
/// Dito, hindi na kailangang maglaan ng higit na memorya sa loob ng loop.
///
/// [`str`]: prim@str
/// [`&str`]: prim@str
/// [`Deref`]: core::ops::Deref
/// [`as_str()`]: String::as_str
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[derive(PartialOrd, Eq, Ord)]
#[cfg_attr(not(test), rustc_diagnostic_item = "string_type")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct String {
    vec: Vec<u8>,
}

/// Ang isang posibleng halaga ng error kapag nagko-convert ng isang `String` mula sa isang UTF-8 byte vector.
///
/// Ang uri na ito ay ang uri ng error para sa [`from_utf8`] na pamamaraan sa [`String`].
/// Dinisenyo ito sa paraang maingat na maiiwasan ang mga reallocation: ibabalik ng pamamaraang [`into_bytes`] ang byte vector na ginamit sa pagtatangka ng conversion.
///
///
/// [`from_utf8`]: String::from_utf8
/// [`into_bytes`]: FromUtf8Error::into_bytes
///
/// Ang uri ng [`Utf8Error`] na ibinigay ng [`std::str`] ay kumakatawan sa isang error na maaaring mangyari kapag nagko-convert ng isang hiwa ng [`u8`] s sa isang [`&str`].
/// Sa puntong ito, ito ay isang analogue sa `FromUtf8Error`, at maaari kang makakuha ng isa mula sa isang `FromUtf8Error` sa pamamagitan ng [`utf8_error`] na pamamaraan.
///
/// [`Utf8Error`]: core::str::Utf8Error
/// [`std::str`]: core::str
/// [`&str`]: prim@str
/// [`utf8_error`]: Self::utf8_error
///
/// # Examples
///
/// Pangunahing paggamit:
///
/// ```
/// // ilang mga hindi wastong byte, sa isang vector
/// let bytes = vec![0, 159];
///
/// let value = String::from_utf8(bytes);
///
/// assert!(value.is_err());
/// assert_eq!(vec![0, 159], value.unwrap_err().into_bytes());
/// ```
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct FromUtf8Error {
    bytes: Vec<u8>,
    error: Utf8Error,
}

/// Ang isang posibleng halaga ng error kapag nagko-convert ng isang `String` mula sa isang UTF-16 byte slice.
///
/// Ang uri na ito ay ang uri ng error para sa [`from_utf16`] na pamamaraan sa [`String`].
///
/// [`from_utf16`]: String::from_utf16
/// # Examples
///
/// Pangunahing paggamit:
///
/// ```
/// // 𝄞mu<invalid>ic
/// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
///           0xD800, 0x0069, 0x0063];
///
/// assert!(String::from_utf16(v).is_err());
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug)]
pub struct FromUtf16Error(());

impl String {
    /// Lumilikha ng isang bagong walang laman na `String`.
    ///
    /// Dahil sa walang laman ang `String`, hindi ito maglalaan ng anumang paunang buffer.Habang nangangahulugan iyon na ang paunang pagpapatakbo na ito ay napaka-mura, maaari itong maging sanhi ng labis na paglalaan sa paglaon kapag nagdagdag ka ng data.
    ///
    /// Kung mayroon kang isang ideya kung gaano karaming data ang hahawak sa `String`, isaalang-alang ang pamamaraan na [`with_capacity`] upang maiwasan ang labis na muling paglalaan.
    ///
    /// [`with_capacity`]: String::with_capacity
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// let s = String::new();
    /// ```
    ///
    ///
    ///
    #[inline]
    #[rustc_const_stable(feature = "const_string_new", since = "1.32.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> String {
        String { vec: Vec::new() }
    }

    /// Lumilikha ng isang bagong walang laman na `String` na may isang partikular na kapasidad.
    ///
    /// Ang 'String`s ay mayroong panloob na buffer upang hawakan ang kanilang data.
    /// Ang kapasidad ay ang haba ng buffer na iyon, at maaaring ma-query sa pamamaraang [`capacity`].
    /// Ang pamamaraan na ito ay lumilikha ng isang walang laman na `String`, ngunit isa na may isang paunang buffer na maaaring humawak ng `capacity` bytes.
    /// Kapaki-pakinabang ito kapag maaaring naidugtong mo ang isang pangkat ng data sa `String`, binabawasan ang bilang ng mga reallocation na kailangan nitong gawin.
    ///
    ///
    /// [`capacity`]: String::capacity
    ///
    /// Kung ang ibinigay na kapasidad ay `0`, walang alokasyon na magaganap, at ang pamamaraang ito ay magkapareho sa pamamaraang [`new`].
    ///
    /// [`new`]: String::new
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    ///
    /// // Ang String ay naglalaman ng walang mga char, kahit na may kapasidad ito para sa higit pa
    /// assert_eq!(s.len(), 0);
    ///
    /// // Ang mga ito ay tapos na nang walang reallocating ...
    /// let cap = s.capacity();
    /// for _ in 0..10 {
    ///     s.push('a');
    /// }
    ///
    /// assert_eq!(s.capacity(), cap);
    ///
    /// // ... ngunit maaari itong gawing reallocate ang string
    /// s.push('a');
    /// ```
    ///
    ///
    #[inline]
    #[doc(alias = "alloc")]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> String {
        String { vec: Vec::with_capacity(capacity) }
    }

    // HACK(japaric): na may cfg(test) ang taglay na `[T]::to_vec` na pamamaraan, na kinakailangan para sa kahulugan ng pamamaraang ito, ay hindi magagamit.
    // Dahil hindi namin kinakailangan ang pamamaraang ito para sa mga layunin sa pagsubok, makikita ko lang sa NB na makita ang slice::hack module sa slice.rs para sa karagdagang impormasyon
    //
    //
    #[inline]
    #[cfg(test)]
    pub fn from_str(_: &str) -> String {
        panic!("not available with cfg(test)");
    }

    /// Binabago ang isang vector ng bytes sa isang `String`.
    ///
    /// Ang isang string ([`String`]) ay gawa sa bytes ([`u8`]), at isang vector ng bytes ([`Vec<u8>`]) ay gawa sa bytes, kaya't ang function na ito ay nagko-convert sa pagitan ng dalawa.
    /// Hindi lahat ng mga byte slice ay wastong `String`s, subalit: kinakailangan ng `String` na ito ay wastong UTF-8.
    /// `from_utf8()` mga tseke upang matiyak na ang mga byte ay wastong UTF-8, at pagkatapos ay ang pag-convert.
    ///
    /// Kung nakatiyak ka na ang byte slice ay wastong UTF-8, at hindi mo nais na maabot ang overhead ng validity check, mayroong isang hindi ligtas na bersyon ng pagpapaandar na ito, [`from_utf8_unchecked`], na may parehong pag-uugali ngunit nilaktawan ang tseke.
    ///
    ///
    /// Mag-iingat ang pamamaraang ito upang hindi makopya ang vector, alang-alang sa kahusayan.
    ///
    /// Kung kailangan mo ng isang [`&str`] sa halip na isang `String`, isaalang-alang ang [`str::from_utf8`].
    ///
    /// Ang kabaligtaran ng pamamaraang ito ay [`into_bytes`].
    ///
    /// # Errors
    ///
    /// Ibinabalik ang [`Err`] kung ang slice ay hindi UTF-8 na may isang paglalarawan kung bakit ang mga ibinigay na byte ay hindi UTF-8.Ang vector na inilipat mo ay kasama din.
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// // ilang mga byte, sa isang vector
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// // Alam namin na ang mga byte na ito ay wasto, kaya gagamitin namin ang `unwrap()`.
    /// let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    /// Maling mga byte:
    ///
    /// ```
    /// // ilang mga hindi wastong byte, sa isang vector
    /// let sparkle_heart = vec![0, 159, 146, 150];
    ///
    /// assert!(String::from_utf8(sparkle_heart).is_err());
    /// ```
    ///
    /// Tingnan ang mga dokumento para sa [`FromUtf8Error`] para sa higit pang mga detalye sa kung ano ang maaari mong gawin sa error na ito.
    ///
    /// [`from_utf8_unchecked`]: String::from_utf8_unchecked
    /// [`Vec<u8>`]: crate::vec::Vec
    /// [`&str`]: prim@str
    /// [`into_bytes`]: String::into_bytes
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf8(vec: Vec<u8>) -> Result<String, FromUtf8Error> {
        match str::from_utf8(&vec) {
            Ok(..) => Ok(String { vec }),
            Err(e) => Err(FromUtf8Error { bytes: vec, error: e }),
        }
    }

    /// Nagko-convert ng isang slice ng bytes sa isang string, kasama ang mga hindi wastong character.
    ///
    /// Ang mga string ay gawa sa bytes ([`u8`]), at isang slice ng bytes ([`&[u8]`][byteslice]) ay gawa sa bytes, kaya't ang function na ito ay nagko-convert sa pagitan ng dalawa.Hindi lahat ng mga byte slice ay wastong mga string, gayunpaman: ang mga string ay kinakailangan upang maging wastong UTF-8.
    /// Sa panahon ng conversion na ito, `from_utf8_lossy()` Papalitan nito ang anumang di-wasto UTF-8 mga pagkakasunud-sunod na may [`U+FFFD REPLACEMENT CHARACTER`][U+FFFD], na ganito ang hitsura:
    ///
    /// [byteslice]: prim@slice
    /// [U+FFFD]: core::char::REPLACEMENT_CHARACTER
    ///
    /// Kung natitiyak mo na ang byte slice ay wastong UTF-8, at hindi mo nais na maabot ang overhead ng conversion, mayroong isang hindi ligtas na bersyon ng pagpapaandar na ito, [`from_utf8_unchecked`], na may parehong pag-uugali ngunit nilalaktawan ang mga tseke.
    ///
    ///
    /// [`from_utf8_unchecked`]: String::from_utf8_unchecked
    ///
    /// Ang pagpapaandar na ito ay nagbabalik ng [`Cow<'a, str>`].Kung ang aming byte slice ay hindi wasto UTF-8, pagkatapos ay kailangan naming ipasok ang mga character na kapalit, na magbabago sa laki ng string, at samakatuwid, mangangailangan ng `String`.
    /// Ngunit kung may bisa na UTF-8, hindi na namin kailangan ng bagong paglalaan.
    /// Pinapayagan kami ng uri ng pagbabalik na hawakan ang parehong mga kaso.
    ///
    /// [`Cow<'a, str>`]: crate::borrow::Cow
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// // ilang mga byte, sa isang vector
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// let sparkle_heart = String::from_utf8_lossy(&sparkle_heart);
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    /// Maling mga byte:
    ///
    /// ```
    /// // ilang mga hindi wastong byte
    /// let input = b"Hello \xF0\x90\x80World";
    /// let output = String::from_utf8_lossy(input);
    ///
    /// assert_eq!("Hello �World", output);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf8_lossy(v: &[u8]) -> Cow<'_, str> {
        let mut iter = lossy::Utf8Lossy::from_bytes(v).chunks();

        let (first_valid, first_broken) = if let Some(chunk) = iter.next() {
            let lossy::Utf8LossyChunk { valid, broken } = chunk;
            if valid.len() == v.len() {
                debug_assert!(broken.is_empty());
                return Cow::Borrowed(valid);
            }
            (valid, broken)
        } else {
            return Cow::Borrowed("");
        };

        const REPLACEMENT: &str = "\u{FFFD}";

        let mut res = String::with_capacity(v.len());
        res.push_str(first_valid);
        if !first_broken.is_empty() {
            res.push_str(REPLACEMENT);
        }

        for lossy::Utf8LossyChunk { valid, broken } in iter {
            res.push_str(valid);
            if !broken.is_empty() {
                res.push_str(REPLACEMENT);
            }
        }

        Cow::Owned(res)
    }

    /// Na-decode ang isang UTF-16 - na naka-encode ng vector `v` sa isang `String`, na ibinabalik ang [`Err`] kung ang `v` ay naglalaman ng anumang hindi wastong data.
    ///
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// // 𝄞music
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0x0073, 0x0069, 0x0063];
    /// assert_eq!(String::from("𝄞music"),
    ///            String::from_utf16(v).unwrap());
    ///
    /// // 𝄞mu<invalid>ic
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0xD800, 0x0069, 0x0063];
    /// assert!(String::from_utf16(v).is_err());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf16(v: &[u16]) -> Result<String, FromUtf16Error> {
        // Hindi ito ginagawa sa pamamagitan ng pagkolekta: : <Result<_, _>> () para sa mga kadahilanan sa pagganap.
        // FIXME: ang pagpapaandar ay maaaring gawing simple muli kapag ang #48994 ay sarado.
        let mut ret = String::with_capacity(v.len());
        for c in decode_utf16(v.iter().cloned()) {
            if let Ok(c) = c {
                ret.push(c);
            } else {
                return Err(FromUtf16Error(()));
            }
        }
        Ok(ret)
    }

    /// Decode ng isang UTF-16-encode slice `v` sa isang `String`, na pinapalitan ang di-wastong data na may [the replacement character (`U+FFFD`)][U+FFFD].
    ///
    /// Hindi tulad ng [`from_utf8_lossy`] na nagbabalik ng isang [`Cow<'a, str>`], `from_utf16_lossy` nagbabalik ng isang `String` dahil ang UTF-16 na UTF-8 conversion ay nangangailangan ng isang memory allocation.
    ///
    ///
    /// [`from_utf8_lossy`]: String::from_utf8_lossy
    /// [`Cow<'a, str>`]: crate::borrow::Cow
    /// [U+FFFD]: core::char::REPLACEMENT_CHARACTER
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0x0073, 0xDD1E, 0x0069, 0x0063,
    ///           0xD834];
    ///
    /// assert_eq!(String::from("𝄞mus\u{FFFD}ic\u{FFFD}"),
    ///            String::from_utf16_lossy(v));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf16_lossy(v: &[u16]) -> String {
        decode_utf16(v.iter().cloned()).map(|r| r.unwrap_or(REPLACEMENT_CHARACTER)).collect()
    }

    /// Nabubulok ang isang `String` sa mga hilaw na sangkap nito.
    ///
    /// Ibinabalik ang hilaw na pointer sa pinagbabatayan ng data, ang haba ng string (sa mga byte), at ang inilaan na kakayahan ng data (sa mga byte).
    /// Ito ang magkatulad na mga argumento sa parehong pagkakasunud-sunod ng mga argumento sa [`from_raw_parts`].
    ///
    /// Matapos tawagan ang pagpapaandar na ito, ang tumatawag ay responsable para sa memorya na dating pinamamahalaan ng `String`.
    /// Ang tanging paraan upang magawa ito ay upang i-convert ang hilaw na pointer, haba, at kapasidad na bumalik sa isang `String` na may [`from_raw_parts`] function, na pinapayagan ang destructor na gawin ang paglilinis.
    ///
    ///
    /// [`from_raw_parts`]: String::from_raw_parts
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_into_raw_parts)]
    /// let s = String::from("hello");
    ///
    /// let (ptr, len, cap) = s.into_raw_parts();
    ///
    /// let rebuilt = unsafe { String::from_raw_parts(ptr, len, cap) };
    /// assert_eq!(rebuilt, "hello");
    /// ```
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts(self) -> (*mut u8, usize, usize) {
        self.vec.into_raw_parts()
    }

    /// Lumilikha ng isang bagong `String` mula sa isang haba, kapasidad, at pointer.
    ///
    /// # Safety
    ///
    /// Ito ay lubos na hindi ligtas, dahil sa bilang ng mga invariant na hindi naka-check:
    ///
    /// * Ang memorya sa `buf` ay kailangang naunang inilalaan ng parehong tagapaglaan na ginagamit ng karaniwang silid-aklatan, na may kinakailangang pagkakahanay ng eksaktong 1.
    /// * `length` kailangang mas mababa sa o katumbas ng `capacity`.
    /// * `capacity` kailangang maging wastong halaga.
    /// * Ang unang `length` bytes sa `buf` ay kailangang wastong UTF-8.
    ///
    /// Ang paglabag sa mga ito ay maaaring maging sanhi ng mga problema tulad ng pagwawasak sa panloob na mga istruktura ng data ng tagapaglaan.
    ///
    /// Ang pagmamay-ari ng `buf` ay mabisang inilipat sa `String` na maaaring makipag-ugnay sa ibang pagkakataon, muling ilipat o baguhin ang mga nilalaman ng memorya na itinuro ng pointer ayon sa kalooban.
    /// Tiyaking walang ibang gumagamit ng pointer pagkatapos tawagan ang pagpapaandar na ito.
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// use std::mem;
    ///
    /// unsafe {
    ///     let s = String::from("hello");
    ///
    ///     // FIXME I-update ito kapag na-stabilize ang vector_into_raw_parts.
    ///     // Pigilan ang awtomatikong pag-drop ng data ng String
    ///     let mut s = mem::ManuallyDrop::new(s);
    ///
    ///     let ptr = s.as_mut_ptr();
    ///     let len = s.len();
    ///     let capacity = s.capacity();
    ///
    ///     let s = String::from_raw_parts(ptr, len, capacity);
    ///
    ///     assert_eq!(String::from("hello"), s);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_raw_parts(buf: *mut u8, length: usize, capacity: usize) -> String {
        unsafe { String { vec: Vec::from_raw_parts(buf, length, capacity) } }
    }

    /// Binabago ang isang vector ng mga byte sa isang `String` nang hindi sinusuri na ang string ay naglalaman ng wastong UTF-8.
    ///
    /// Tingnan ang ligtas na bersyon, [`from_utf8`], para sa karagdagang detalye.
    ///
    /// [`from_utf8`]: String::from_utf8
    ///
    /// # Safety
    ///
    /// Ang pag-andar na ito ay hindi ligtas dahil hindi nito sinusuri kung ang mga byte na naipasa dito ay wastong UTF-8.
    /// Kung ang paghihigpit na ito ay nilabag, maaari itong maging sanhi ng mga isyu sa hindi ligtas na memorya sa mga gumagamit ng future ng `String`, dahil ang natitirang pamantayang aklatan ay ipinapalagay na ang 'String`s ay wastong UTF-8.
    ///
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// // ilang mga byte, sa isang vector
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// let sparkle_heart = unsafe {
    ///     String::from_utf8_unchecked(sparkle_heart)
    /// };
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_utf8_unchecked(bytes: Vec<u8>) -> String {
        String { vec: bytes }
    }

    /// Binabago ang isang `String` sa isang byte vector.
    ///
    /// Naubos nito ang `String`, kaya hindi namin kailangang kopyahin ang mga nilalaman nito.
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// let s = String::from("hello");
    /// let bytes = s.into_bytes();
    ///
    /// assert_eq!(&[104, 101, 108, 108, 111][..], &bytes[..]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_bytes(self) -> Vec<u8> {
        self.vec
    }

    /// Kinukuha ang isang hiwa ng string na naglalaman ng buong `String`.
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// let s = String::from("foo");
    ///
    /// assert_eq!("foo", s.as_str());
    /// ```
    #[inline]
    #[stable(feature = "string_as_str", since = "1.7.0")]
    pub fn as_str(&self) -> &str {
        self
    }

    /// Binabago ang isang `String` sa isang nababagabag na hiwa ng string.
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// let mut s = String::from("foobar");
    /// let s_mut_str = s.as_mut_str();
    ///
    /// s_mut_str.make_ascii_uppercase();
    ///
    /// assert_eq!("FOOBAR", s_mut_str);
    /// ```
    #[inline]
    #[stable(feature = "string_as_str", since = "1.7.0")]
    pub fn as_mut_str(&mut self) -> &mut str {
        self
    }

    /// Nagdadagdag ng isang ibinigay na hiwa ng string sa dulo ng `String` na ito.
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.push_str("bar");
    ///
    /// assert_eq!("foobar", s);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_str(&mut self, string: &str) {
        self.vec.extend_from_slice(string.as_bytes())
    }

    /// Ibinabalik ang kapasidad ng `String` na ito, sa mga byte.
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// let s = String::with_capacity(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.vec.capacity()
    }

    /// Tinitiyak na ang kapasidad ng `String` na ito ay hindi bababa sa `additional` bytes na mas malaki kaysa sa haba nito.
    ///
    /// kapasidad ay maaaring nadagdagan ng higit sa `additional` bytes kung ito pinipili, upang maiwasan ang madalas na muling paglalaan.
    ///
    ///
    /// Kung hindi mo nais ang pag-uugaling "at least" na ito, tingnan ang pamamaraang [`reserve_exact`].
    ///
    /// # Panics
    ///
    /// Panics kung ang bagong kapasidad ay umaapaw sa [`usize`].
    ///
    /// [`reserve_exact`]: String::reserve_exact
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// let mut s = String::new();
    ///
    /// s.reserve(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    ///
    /// Maaaring hindi nito talaga dagdagan ang kapasidad:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    /// s.push('a');
    /// s.push('b');
    ///
    /// // s ngayon ay may haba na 2 at may kapasidad na 10
    /// assert_eq!(2, s.len());
    /// assert_eq!(10, s.capacity());
    ///
    /// // Dahil mayroon na kaming sobrang 8 na kakayahan, tinatawagan ito ...
    /// s.reserve(8);
    ///
    /// // ... hindi talaga tumaas.
    /// assert_eq!(10, s.capacity());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.vec.reserve(additional)
    }

    /// Tinitiyak na ang kapasidad ng `String` na ito ay `additional` bytes na mas malaki kaysa sa haba nito.
    ///
    /// Isaalang-alang ang paggamit ng [`reserve`] na pamamaraan maliban kung talagang lubos mong nalalaman kaysa sa tagapaglaan.
    ///
    ///
    /// [`reserve`]: String::reserve
    ///
    /// # Panics
    ///
    /// Panics kung ang bagong kapasidad ay umaapaw sa `usize`.
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// let mut s = String::new();
    ///
    /// s.reserve_exact(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    ///
    /// Maaaring hindi nito talaga dagdagan ang kapasidad:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    /// s.push('a');
    /// s.push('b');
    ///
    /// // s ngayon ay may haba na 2 at may kapasidad na 10
    /// assert_eq!(2, s.len());
    /// assert_eq!(10, s.capacity());
    ///
    /// // Dahil mayroon na kaming sobrang 8 na kakayahan, tinatawagan ito ...
    /// s.reserve_exact(8);
    ///
    /// // ... hindi talaga tumaas.
    /// assert_eq!(10, s.capacity());
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.vec.reserve_exact(additional)
    }

    /// Sinusubukan upang magreserba ng kapasidad para sa hindi bababa sa `additional` higit pang mga elemento na maipasok sa ibinigay na `String`.
    /// Ang koleksyon ay maaaring magreserba ng mas maraming puwang upang maiwasan ang madalas na mga reallocation.
    /// Matapos tumawag sa `reserve`, ang kapasidad ay magiging mas malaki sa o katumbas ng `self.len() + additional`.
    /// Walang ginagawa kung sapat na ang kapasidad.
    ///
    /// # Errors
    ///
    /// Kung umaapaw ang kapasidad, o nag-uulat ang tagapaglaan ng isang pagkabigo, pagkatapos ay may isang error na ibinalik.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &str) -> Result<String, TryReserveError> {
    ///     let mut output = String::new();
    ///
    ///     // I-paunang reserba ang memorya, paglabas kung hindi namin magawa
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Ngayon alam namin na hindi ito maaaring OOM sa gitna ng aming kumplikadong gawain
    ///     output.push_str(data);
    ///
    ///     Ok(output)
    /// }
    /// # process_data("rust").expect("why is the test harness OOMing on 4 bytes?");
    /// ```
    ///
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.vec.try_reserve(additional)
    }

    /// Sinusubukan na ireserba ang minimum na kapasidad para sa eksaktong `additional` higit pang mga elemento na maipasok sa ibinigay na `String`.
    ///
    /// Matapos tumawag sa `reserve_exact`, ang kapasidad ay magiging mas malaki sa o katumbas ng `self.len() + additional`.
    /// Walang ginagawa kung ang kapasidad ay sapat na.
    ///
    /// Tandaan na ang tagapagtalaga ay maaaring magbigay sa koleksyon ng mas maraming puwang kaysa sa hiniling nito.
    /// Samakatuwid, ang kakayahan ay hindi maaasahan na maging tiyak na minimal.
    /// Mas gusto ang `reserve` kung inaasahan ang mga pagpasok ng future.
    ///
    /// # Errors
    ///
    /// Kung umaapaw ang kapasidad, o nag-uulat ang tagapaglaan ng isang pagkabigo, pagkatapos ay may isang error na ibinalik.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &str) -> Result<String, TryReserveError> {
    ///     let mut output = String::new();
    ///
    ///     // I-paunang reserba ang memorya, paglabas kung hindi namin magawa
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Ngayon alam namin na hindi ito maaaring OOM sa gitna ng aming kumplikadong gawain
    ///     output.push_str(data);
    ///
    ///     Ok(output)
    /// }
    /// # process_data("rust").expect("why is the test harness OOMing on 4 bytes?");
    /// ```
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.vec.try_reserve_exact(additional)
    }

    /// Pinapaliit ang kapasidad ng `String` na ito upang tumugma sa haba nito.
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.reserve(100);
    /// assert!(s.capacity() >= 100);
    ///
    /// s.shrink_to_fit();
    /// assert_eq!(3, s.capacity());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        self.vec.shrink_to_fit()
    }

    /// Pinapaliit ang kapasidad ng `String` na ito na may mas mababang gapos.
    ///
    /// Ang kapasidad ay mananatiling hindi bababa sa kasing laki ng parehong haba at ang ibinigay na halaga.
    ///
    ///
    /// Kung ang kasalukuyang kapasidad ay mas mababa sa mas mababang limitasyon, ito ay isang no-op.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// let mut s = String::from("foo");
    ///
    /// s.reserve(100);
    /// assert!(s.capacity() >= 100);
    ///
    /// s.shrink_to(10);
    /// assert!(s.capacity() >= 10);
    /// s.shrink_to(0);
    /// assert!(s.capacity() >= 3);
    /// ```
    #[inline]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        self.vec.shrink_to(min_capacity)
    }

    /// Nagdadagdag ng ibinigay na [`char`] sa dulo ng `String` na ito.
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// let mut s = String::from("abc");
    ///
    /// s.push('1');
    /// s.push('2');
    /// s.push('3');
    ///
    /// assert_eq!("abc123", s);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, ch: char) {
        match ch.len_utf8() {
            1 => self.vec.push(ch as u8),
            _ => self.vec.extend_from_slice(ch.encode_utf8(&mut [0; 4]).as_bytes()),
        }
    }

    /// Nagbabalik ng isang byte slice ng mga nilalaman ng `String` na ito.
    ///
    /// Ang kabaligtaran ng pamamaraang ito ay [`from_utf8`].
    ///
    /// [`from_utf8`]: String::from_utf8
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// let s = String::from("hello");
    ///
    /// assert_eq!(&[104, 101, 108, 108, 111], s.as_bytes());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn as_bytes(&self) -> &[u8] {
        &self.vec
    }

    /// Paikliin ang `String` na ito sa tinukoy na haba.
    ///
    /// Kung ang `new_len` ay mas malaki kaysa sa kasalukuyang haba ng string, wala itong epekto.
    ///
    ///
    /// Tandaan na ang pamamaraang ito ay walang epekto sa inilaan na kapasidad ng string
    ///
    /// # Panics
    ///
    /// Panics kung ang `new_len` ay hindi nagsisinungaling sa isang [`char`] na hangganan.
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// let mut s = String::from("hello");
    ///
    /// s.truncate(2);
    ///
    /// assert_eq!("he", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn truncate(&mut self, new_len: usize) {
        if new_len <= self.len() {
            assert!(self.is_char_boundary(new_len));
            self.vec.truncate(new_len)
        }
    }

    /// Tinatanggal ang huling character mula sa string buffer at ibinalik ito.
    ///
    /// Ibinabalik ang [`None`] kung ang `String` na ito ay walang laman.
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// assert_eq!(s.pop(), Some('o'));
    /// assert_eq!(s.pop(), Some('o'));
    /// assert_eq!(s.pop(), Some('f'));
    ///
    /// assert_eq!(s.pop(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<char> {
        let ch = self.chars().rev().next()?;
        let newlen = self.len() - ch.len_utf8();
        unsafe {
            self.vec.set_len(newlen);
        }
        Some(ch)
    }

    /// Tinatanggal ang isang [`char`] mula sa `String` na ito sa isang byte na posisyon at ibabalik ito.
    ///
    /// Ito ay isang operasyon na *O*(*n*), dahil nangangailangan ito ng pagkopya ng bawat elemento sa buffer.
    ///
    /// # Panics
    ///
    /// Ang Panics kung ang `idx` ay mas malaki kaysa o katumbas ng haba ng `String`, o kung hindi ito namamalagi sa isang hangganan ng [`char`].
    ///
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// assert_eq!(s.remove(0), 'f');
    /// assert_eq!(s.remove(1), 'o');
    /// assert_eq!(s.remove(0), 'o');
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, idx: usize) -> char {
        let ch = match self[idx..].chars().next() {
            Some(ch) => ch,
            None => panic!("cannot remove a char from the end of a string"),
        };

        let next = idx + ch.len_utf8();
        let len = self.len();
        unsafe {
            ptr::copy(self.vec.as_ptr().add(next), self.vec.as_mut_ptr().add(idx), len - next);
            self.vec.set_len(len - (next - idx));
        }
        ch
    }

    /// Alisin ang lahat ng mga tugma ng pattern `pat` sa `String`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(string_remove_matches)]
    /// let mut s = String::from("Trees are not green, the sky is not blue.");
    /// s.remove_matches("not ");
    /// assert_eq!("Trees are green, the sky is blue.", s);
    /// ```
    ///
    /// Ang mga pagtutugma ay makikita at aalisin nang paulit-ulit, kaya sa mga kaso kung saan nagsasapawan ang mga pattern, ang unang pattern lamang ang aalisin:
    ///
    ///
    /// ```
    /// #![feature(string_remove_matches)]
    /// let mut s = String::from("banana");
    /// s.remove_matches("ana");
    /// assert_eq!("bna", s);
    /// ```
    #[unstable(feature = "string_remove_matches", reason = "new API", issue = "72826")]
    pub fn remove_matches<'a, P>(&'a mut self, pat: P)
    where
        P: for<'x> Pattern<'x>,
    {
        use core::str::pattern::Searcher;

        let matches = {
            let mut searcher = pat.into_searcher(self);
            let mut matches = Vec::new();

            while let Some(m) = searcher.next_match() {
                matches.push(m);
            }

            matches
        };

        let len = self.len();
        let mut shrunk_by = 0;

        // KALIGTASAN: ang pagsisimula at pagtatapos ay nasa utf8 byte na hangganan bawat
        // ang mga dokumento ng Searcher
        unsafe {
            for (start, end) in matches {
                ptr::copy(
                    self.vec.as_mut_ptr().add(end - shrunk_by),
                    self.vec.as_mut_ptr().add(start - shrunk_by),
                    len - end,
                );
                shrunk_by += end - start;
            }
            self.vec.set_len(len - shrunk_by);
        }
    }

    /// Pinapanatili lamang ang mga character na tinukoy ng panaguri.
    ///
    /// Sa madaling salita, alisin ang lahat ng mga character `c` na tulad ng `f(c)` ay nagbabalik ng `false`.
    /// Nagpapatakbo ang pamamaraang ito sa lugar, pagbisita sa bawat character nang eksakto isang beses sa orihinal na pagkakasunud-sunod, at pinapanatili ang pagkakasunud-sunod ng mga pinanatili na character.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("f_o_ob_ar");
    ///
    /// s.retain(|c| c != '_');
    ///
    /// assert_eq!(s, "foobar");
    /// ```
    ///
    /// Ang eksaktong order ay maaaring maging kapaki-pakinabang para sa pagsubaybay sa panlabas na estado, tulad ng isang index.
    ///
    /// ```
    /// let mut s = String::from("abcde");
    /// let keep = [false, true, true, false, true];
    /// let mut i = 0;
    /// s.retain(|_| (keep[i], i += 1).0);
    /// assert_eq!(s, "bce");
    /// ```
    #[inline]
    #[stable(feature = "string_retain", since = "1.26.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(char) -> bool,
    {
        let len = self.len();
        let mut del_bytes = 0;
        let mut idx = 0;

        unsafe {
            self.vec.set_len(0);
        }

        while idx < len {
            let ch = unsafe { self.get_unchecked(idx..len).chars().next().unwrap() };
            let ch_len = ch.len_utf8();

            if !f(ch) {
                del_bytes += ch_len;
            } else if del_bytes > 0 {
                unsafe {
                    ptr::copy(
                        self.vec.as_ptr().add(idx),
                        self.vec.as_mut_ptr().add(idx - del_bytes),
                        ch_len,
                    );
                }
            }

            // Ituro ang idx sa susunod na char
            idx += ch_len;
        }

        unsafe {
            self.vec.set_len(len - del_bytes);
        }
    }

    /// Nagpapasok ng character sa `String` na ito sa isang byte na posisyon.
    ///
    /// Ito ay isang operasyon na *O*(*n*) dahil nangangailangan ito ng pagkopya ng bawat elemento sa buffer.
    ///
    /// # Panics
    ///
    /// Panics kung `idx` ay mas malaki kaysa sa `length ni String`, o kung ito ay hindi nagsasabi ng totoo sa isang [`char`] hangganan.
    ///
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// let mut s = String::with_capacity(3);
    ///
    /// s.insert(0, 'f');
    /// s.insert(1, 'o');
    /// s.insert(2, 'o');
    ///
    /// assert_eq!("foo", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn insert(&mut self, idx: usize, ch: char) {
        assert!(self.is_char_boundary(idx));
        let mut bits = [0; 4];
        let bits = ch.encode_utf8(&mut bits).as_bytes();

        unsafe {
            self.insert_bytes(idx, bits);
        }
    }

    unsafe fn insert_bytes(&mut self, idx: usize, bytes: &[u8]) {
        let len = self.len();
        let amt = bytes.len();
        self.vec.reserve(amt);

        unsafe {
            ptr::copy(self.vec.as_ptr().add(idx), self.vec.as_mut_ptr().add(idx + amt), len - idx);
            ptr::copy(bytes.as_ptr(), self.vec.as_mut_ptr().add(idx), amt);
            self.vec.set_len(len + amt);
        }
    }

    /// Nagpapasok ng isang hiwa ng string sa `String` na ito sa isang byte na posisyon.
    ///
    /// Ito ay isang operasyon na *O*(*n*) dahil nangangailangan ito ng pagkopya ng bawat elemento sa buffer.
    ///
    /// # Panics
    ///
    /// Panics kung `idx` ay mas malaki kaysa sa `length ni String`, o kung ito ay hindi nagsasabi ng totoo sa isang [`char`] hangganan.
    ///
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// let mut s = String::from("bar");
    ///
    /// s.insert_str(0, "foo");
    ///
    /// assert_eq!("foobar", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "insert_str", since = "1.16.0")]
    pub fn insert_str(&mut self, idx: usize, string: &str) {
        assert!(self.is_char_boundary(idx));

        unsafe {
            self.insert_bytes(idx, string.as_bytes());
        }
    }

    /// Nagbabalik ng isang nababagabag na sanggunian sa mga nilalaman ng `String` na ito.
    ///
    /// # Safety
    ///
    /// Ang pag-andar na ito ay hindi ligtas dahil hindi nito sinusuri kung ang mga byte na naipasa dito ay wastong UTF-8.
    /// Kung ang paghihigpit na ito ay nilabag, maaari itong maging sanhi ng mga isyu sa hindi ligtas na memorya sa mga gumagamit ng future ng `String`, dahil ang natitirang pamantayang aklatan ay ipinapalagay na ang 'String`s ay wastong UTF-8.
    ///
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// let mut s = String::from("hello");
    ///
    /// unsafe {
    ///     let vec = s.as_mut_vec();
    ///     assert_eq!(&[104, 101, 108, 108, 111][..], &vec[..]);
    ///
    ///     vec.reverse();
    /// }
    /// assert_eq!(s, "olleh");
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn as_mut_vec(&mut self) -> &mut Vec<u8> {
        &mut self.vec
    }

    /// Ibinabalik ang haba ng `String` na ito, sa mga byte, hindi sa [`char`] s o graphemes.
    /// Sa madaling salita, maaaring hindi ito ang isinasaalang-alang ng isang tao sa haba ng string.
    ///
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// let a = String::from("foo");
    /// assert_eq!(a.len(), 3);
    ///
    /// let fancy_f = String::from("ƒoo");
    /// assert_eq!(fancy_f.len(), 4);
    /// assert_eq!(fancy_f.chars().count(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.vec.len()
    }

    /// Ibinabalik ang `true` kung ang `String` na ito ay may haba ng zero, at kung hindi man ang `false`.
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// let mut v = String::new();
    /// assert!(v.is_empty());
    ///
    /// v.push('a');
    /// assert!(!v.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Hinahati ang string sa dalawa sa ibinigay na byte index.
    ///
    /// Nagbabalik ng isang bagong inilalaan na `String`.
    /// `self` naglalaman ng bytes `[0, at)`, at ang ibinalik na `String` ay naglalaman ng bytes `[at, len)`.
    /// `at` dapat nasa hangganan ng isang UTF-8 code point.
    ///
    /// Tandaan na ang kapasidad ng `self` ay hindi nagbabago.
    ///
    /// # Panics
    ///
    /// Panics kung ang `at` ay wala sa isang hangganan ng point ng `UTF-8` code, o kung ito ay lampas sa huling punto ng code ng string.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # fn main() {
    /// let mut hello = String::from("Hello, World!");
    /// let world = hello.split_off(7);
    /// assert_eq!(hello, "Hello, ");
    /// assert_eq!(world, "World!");
    /// # }
    /// ```
    #[inline]
    #[stable(feature = "string_split_off", since = "1.16.0")]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    pub fn split_off(&mut self, at: usize) -> String {
        assert!(self.is_char_boundary(at));
        let other = self.vec.split_off(at);
        unsafe { String::from_utf8_unchecked(other) }
    }

    /// Pinutol ang `String` na ito, inaalis ang lahat ng nilalaman.
    ///
    /// Habang nangangahulugan ito na ang `String` ay magkakaroon ng haba ng zero, hindi nito hinahawakan ang kapasidad nito.
    ///
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.clear();
    ///
    /// assert!(s.is_empty());
    /// assert_eq!(0, s.len());
    /// assert_eq!(3, s.capacity());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.vec.clear()
    }

    /// Lumilikha ng isang draining iterator na inaalis ang tinukoy na saklaw sa `String` at nagbubunga ng tinanggal na `chars`.
    ///
    ///
    /// Note: Ang hanay ng elemento ay tinanggal kahit na ang iterator ay hindi natupok hanggang sa katapusan.
    ///
    /// # Panics
    ///
    /// Panics kung ang panimulang punto o end point ay hindi nagsisinungaling sa isang [`char`] na hangganan, o kung wala sila sa mga hangganan.
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// let mut s = String::from("α is alpha, β is beta");
    /// let beta_offset = s.find('β').unwrap_or(s.len());
    ///
    /// // Alisin ang saklaw hanggang sa β mula sa string
    /// let t: String = s.drain(..beta_offset).collect();
    /// assert_eq!(t, "α is alpha, ");
    /// assert_eq!(s, "β is beta");
    ///
    /// // Ang isang buong saklaw na nililimas ang string
    /// s.drain(..);
    /// assert_eq!(s, "");
    /// ```
    ///
    ///
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_>
    where
        R: RangeBounds<usize>,
    {
        // Kaligtasan sa memorya
        //
        // Ang String bersyon ng Drain ay walang mga isyu memory kaligtasan ng mga vector bersyon.
        // Ang data ay simpleng byte lamang.
        // Dahil ang pag-aalis ng saklaw ay nangyayari sa Drop, kung ang tagapagpatuloy ng Drain ay leak, ang pagtanggal ay hindi mangyayari.
        //
        let Range { start, end } = slice::range(range, ..self.len());
        assert!(self.is_char_boundary(start));
        assert!(self.is_char_boundary(end));

        // Lumabas ng dalawang sabay na paghiram.
        // Hindi maa-access ang &mut String hanggang sa matapos ang pag-ulit, sa Drop.
        let self_ptr = self as *mut _;
        // KALIGTASAN: Ginagawa ng `slice::range` at `is_char_boundary` ang mga naaangkop na tseke sa hangganan.
        let chars_iter = unsafe { self.get_unchecked(start..end) }.chars();

        Drain { start, end, iter: chars_iter, string: self_ptr }
    }

    /// Tinatanggal ang tinukoy na saklaw sa string, at pinalitan ito ng ibinigay na string.
    /// Ang ibinigay na string ay hindi kailangang maging pareho ang haba ng saklaw.
    ///
    /// # Panics
    ///
    /// Panics kung ang panimulang punto o end point ay hindi nagsisinungaling sa isang [`char`] na hangganan, o kung wala sila sa mga hangganan.
    ///
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// let mut s = String::from("α is alpha, β is beta");
    /// let beta_offset = s.find('β').unwrap_or(s.len());
    ///
    /// // Palitan ang saklaw hanggang sa β mula sa string
    /// s.replace_range(..beta_offset, "Α is capital alpha; ");
    /// assert_eq!(s, "Α is capital alpha; β is beta");
    /// ```
    ///
    #[stable(feature = "splice", since = "1.27.0")]
    pub fn replace_range<R>(&mut self, range: R, replace_with: &str)
    where
        R: RangeBounds<usize>,
    {
        // Kaligtasan sa memorya
        //
        // Ang Change_range ay walang mga isyu sa kaligtasan ng memorya ng isang vector Splice.
        // ng bersyon ng vector.Ang data ay simpleng byte lamang.

        // BABALA: Ang pagsasama ng variable na ito ay magiging unsound (#81138)
        let start = range.start_bound();
        match start {
            Included(&n) => assert!(self.is_char_boundary(n)),
            Excluded(&n) => assert!(self.is_char_boundary(n + 1)),
            Unbounded => {}
        };
        // BABALA: Ang pagsasama ng variable na ito ay magiging unsound (#81138)
        let end = range.end_bound();
        match end {
            Included(&n) => assert!(self.is_char_boundary(n + 1)),
            Excluded(&n) => assert!(self.is_char_boundary(n)),
            Unbounded => {}
        };

        // Ang paggamit ng `range` muli ay magiging unsound (#81138) Ipinapalagay namin na ang mga hangganan na iniulat ng `range` ay mananatiling pareho, ngunit ang isang pagpapatupad ng salungat ay maaaring magbago sa pagitan ng mga tawag
        //
        //
        unsafe { self.as_mut_vec() }.splice((start, end), replace_with.bytes());
    }

    /// Ginagawa itong `String` sa isang [`Box`]`<`[`str`] `>`.
    ///
    /// Ibabagsak nito ang anumang labis na kapasidad.
    ///
    /// [`str`]: prim@str
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// let s = String::from("hello");
    ///
    /// let b = s.into_boxed_str();
    /// ```
    #[stable(feature = "box_str", since = "1.4.0")]
    #[inline]
    pub fn into_boxed_str(self) -> Box<str> {
        let slice = self.vec.into_boxed_slice();
        unsafe { from_boxed_utf8_unchecked(slice) }
    }
}

impl FromUtf8Error {
    /// Nagbabalik ng isang hiwa ng [`u8`] mga byte na tinangkang i-convert sa isang `String`.
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// // ilang mga hindi wastong byte, sa isang vector
    /// let bytes = vec![0, 159];
    ///
    /// let value = String::from_utf8(bytes);
    ///
    /// assert_eq!(&[0, 159], value.unwrap_err().as_bytes());
    /// ```
    #[stable(feature = "from_utf8_error_as_bytes", since = "1.26.0")]
    pub fn as_bytes(&self) -> &[u8] {
        &self.bytes[..]
    }

    /// Ibinabalik ang mga byte na tinangkang i-convert sa isang `String`.
    ///
    /// Maingat na itinayo ang pamamaraang ito upang maiwasan ang paglalaan.
    /// Naubos nito ang error, inililipat ang mga byte, upang ang isang kopya ng mga byte ay hindi kailangang gawin.
    ///
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// // ilang mga hindi wastong byte, sa isang vector
    /// let bytes = vec![0, 159];
    ///
    /// let value = String::from_utf8(bytes);
    ///
    /// assert_eq!(vec![0, 159], value.unwrap_err().into_bytes());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_bytes(self) -> Vec<u8> {
        self.bytes
    }

    /// Kumuha ng isang `Utf8Error` upang makakuha ng maraming mga detalye tungkol sa pagkabigo sa conversion.
    ///
    /// Ang uri ng [`Utf8Error`] na ibinigay ng [`std::str`] ay kumakatawan sa isang error na maaaring mangyari kapag nagko-convert ng isang hiwa ng [`u8`] s sa isang [`&str`].
    /// Sa puntong ito, ito ay isang analogue sa `FromUtf8Error`.
    /// Tingnan ang dokumentasyon nito para sa higit pang mga detalye sa paggamit nito.
    ///
    /// [`std::str`]: core::str
    /// [`&str`]: prim@str
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// // ilang mga hindi wastong byte, sa isang vector
    /// let bytes = vec![0, 159];
    ///
    /// let error = String::from_utf8(bytes).unwrap_err().utf8_error();
    ///
    /// // ang unang byte ay hindi wasto dito
    /// assert_eq!(1, error.valid_up_to());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn utf8_error(&self) -> Utf8Error {
        self.error
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for FromUtf8Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&self.error, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for FromUtf16Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt("invalid utf-16: lone surrogate found", f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Clone for String {
    fn clone(&self) -> Self {
        String { vec: self.vec.clone() }
    }

    fn clone_from(&mut self, source: &Self) {
        self.vec.clone_from(&source.vec);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromIterator<char> for String {
    fn from_iter<I: IntoIterator<Item = char>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "string_from_iter_by_ref", since = "1.17.0")]
impl<'a> FromIterator<&'a char> for String {
    fn from_iter<I: IntoIterator<Item = &'a char>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> FromIterator<&'a str> for String {
    fn from_iter<I: IntoIterator<Item = &'a str>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "extend_string", since = "1.4.0")]
impl FromIterator<String> for String {
    fn from_iter<I: IntoIterator<Item = String>>(iter: I) -> String {
        let mut iterator = iter.into_iter();

        // Dahil inuulit namin ang `String`s, maiiwasan natin ang kahit isang alokasyon sa pamamagitan ng pagkuha ng unang string mula sa iterator at idagdag dito ang lahat ng mga kasunod na string.
        //
        //
        match iterator.next() {
            None => String::new(),
            Some(mut buf) => {
                buf.extend(iterator);
                buf
            }
        }
    }
}

#[stable(feature = "box_str2", since = "1.45.0")]
impl FromIterator<Box<str>> for String {
    fn from_iter<I: IntoIterator<Item = Box<str>>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "herd_cows", since = "1.19.0")]
impl<'a> FromIterator<Cow<'a, str>> for String {
    fn from_iter<I: IntoIterator<Item = Cow<'a, str>>>(iter: I) -> String {
        let mut iterator = iter.into_iter();

        // Dahil inuulit namin ang mga CoW, maaari naming maiwasan ang (potentially) kahit isang alokasyon sa pamamagitan ng pagkuha ng unang item at idagdag dito ang lahat ng mga kasunod na item.
        //
        //
        match iterator.next() {
            None => String::new(),
            Some(cow) => {
                let mut buf = cow.into_owned();
                buf.extend(iterator);
                buf
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Extend<char> for String {
    fn extend<I: IntoIterator<Item = char>>(&mut self, iter: I) {
        let iterator = iter.into_iter();
        let (lower_bound, _) = iterator.size_hint();
        self.reserve(lower_bound);
        iterator.for_each(move |c| self.push(c));
    }

    #[inline]
    fn extend_one(&mut self, c: char) {
        self.push(c);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a> Extend<&'a char> for String {
    fn extend<I: IntoIterator<Item = &'a char>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &c: &'a char) {
        self.push(c);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> Extend<&'a str> for String {
    fn extend<I: IntoIterator<Item = &'a str>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(s));
    }

    #[inline]
    fn extend_one(&mut self, s: &'a str) {
        self.push_str(s);
    }
}

#[stable(feature = "box_str2", since = "1.45.0")]
impl Extend<Box<str>> for String {
    fn extend<I: IntoIterator<Item = Box<str>>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }
}

#[stable(feature = "extend_string", since = "1.4.0")]
impl Extend<String> for String {
    fn extend<I: IntoIterator<Item = String>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }

    #[inline]
    fn extend_one(&mut self, s: String) {
        self.push_str(&s);
    }
}

#[stable(feature = "herd_cows", since = "1.19.0")]
impl<'a> Extend<Cow<'a, str>> for String {
    fn extend<I: IntoIterator<Item = Cow<'a, str>>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }

    #[inline]
    fn extend_one(&mut self, s: Cow<'a, str>) {
        self.push_str(&s);
    }
}

/// Isang kaginhawaan impl na nagdudulot ng impl para sa `&str`.
///
/// # Examples
///
/// ```
/// assert_eq!(String::from("Hello world").find("world"), Some(6));
/// ```
#[unstable(
    feature = "pattern",
    reason = "API not fully fleshed out and ready to be stabilized",
    issue = "27721"
)]
impl<'a, 'b> Pattern<'a> for &'b String {
    type Searcher = <&'b str as Pattern<'a>>::Searcher;

    fn into_searcher(self, haystack: &'a str) -> <&'b str as Pattern<'a>>::Searcher {
        self[..].into_searcher(haystack)
    }

    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        self[..].is_contained_in(haystack)
    }

    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        self[..].is_prefix_of(haystack)
    }

    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        self[..].strip_prefix_of(haystack)
    }

    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool {
        self[..].is_suffix_of(haystack)
    }

    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str> {
        self[..].strip_suffix_of(haystack)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for String {
    #[inline]
    fn eq(&self, other: &String) -> bool {
        PartialEq::eq(&self[..], &other[..])
    }
    #[inline]
    fn ne(&self, other: &String) -> bool {
        PartialEq::ne(&self[..], &other[..])
    }
}

macro_rules! impl_eq {
    ($lhs:ty, $rhs: ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        #[allow(unused_lifetimes)]
        impl<'a, 'b> PartialEq<$rhs> for $lhs {
            #[inline]
            fn eq(&self, other: &$rhs) -> bool {
                PartialEq::eq(&self[..], &other[..])
            }
            #[inline]
            fn ne(&self, other: &$rhs) -> bool {
                PartialEq::ne(&self[..], &other[..])
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        #[allow(unused_lifetimes)]
        impl<'a, 'b> PartialEq<$lhs> for $rhs {
            #[inline]
            fn eq(&self, other: &$lhs) -> bool {
                PartialEq::eq(&self[..], &other[..])
            }
            #[inline]
            fn ne(&self, other: &$lhs) -> bool {
                PartialEq::ne(&self[..], &other[..])
            }
        }
    };
}

impl_eq! { String, str }
impl_eq! { String, &'a str }
impl_eq! { Cow<'a, str>, str }
impl_eq! { Cow<'a, str>, &'b str }
impl_eq! { Cow<'a, str>, String }

#[stable(feature = "rust1", since = "1.0.0")]
impl Default for String {
    /// Lumilikha ng isang walang laman na `String`.
    #[inline]
    fn default() -> String {
        String::new()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for String {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for String {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl hash::Hash for String {
    #[inline]
    fn hash<H: hash::Hasher>(&self, hasher: &mut H) {
        (**self).hash(hasher)
    }
}

/// Ipinatutupad ang `+` operator para sa pagsasama-sama ng dalawang mga string.
///
/// Naubos nito ang `String` sa kaliwang bahagi at muling ginagamit ang buffer nito (lumalaki ito kung kinakailangan).
/// Ginagawa ito upang maiwasan ang paglalaan ng isang bagong `String` at pagkopya ng buong nilalaman sa bawat operasyon, na hahantong sa *O*(*n*^ 2) na tumatakbo na oras kapag nagtatayo ng isang *n*-byte na string sa pamamagitan ng paulit-ulit na pagsasama.
///
///
/// Ang string sa kanang bahagi ay hiniram lamang;ang mga nilalaman nito ay kinopya sa ibinalik na `String`.
///
/// # Examples
///
/// Ang pagsasama-sama ng dalawang `String` ay kukuha ng una sa pamamagitan ng halaga at hinihiram ang pangalawa:
///
/// ```
/// let a = String::from("hello");
/// let b = String::from(" world");
/// let c = a + &b;
/// // `a` ay inilipat at hindi na magagamit dito.
/// ```
///
/// Kung nais mong patuloy na gamitin ang unang `String`, maaari mo itong i-clone at idagdag sa clone sa halip:
///
/// ```
/// let a = String::from("hello");
/// let b = String::from(" world");
/// let c = a.clone() + &b;
/// // `a` valid pa rin dito.
/// ```
///
/// Ang nag-uugnay na mga hiwa ng `&str` ay maaaring gawin sa pamamagitan ng pag-convert ng una sa isang `String`:
///
/// ```
/// let a = "hello";
/// let b = " world";
/// let c = a.to_string() + b;
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Add<&str> for String {
    type Output = String;

    #[inline]
    fn add(mut self, other: &str) -> String {
        self.push_str(other);
        self
    }
}

/// Ipinatutupad ang `+=` operator para sa pagdaragdag sa isang `String`.
///
/// Ito ay may parehong pag-uugali sa pamamaraang [`push_str`][String::push_str].
#[stable(feature = "stringaddassign", since = "1.12.0")]
impl AddAssign<&str> for String {
    #[inline]
    fn add_assign(&mut self, other: &str) {
        self.push_str(other);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::Range<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::Range<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeTo<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeTo<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeFrom<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeFrom<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeFull> for String {
    type Output = str;

    #[inline]
    fn index(&self, _index: ops::RangeFull) -> &str {
        unsafe { str::from_utf8_unchecked(&self.vec) }
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::Index<ops::RangeInclusive<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeInclusive<usize>) -> &str {
        Index::index(&**self, index)
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::Index<ops::RangeToInclusive<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeToInclusive<usize>) -> &str {
        Index::index(&**self, index)
    }
}

#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::Range<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::Range<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeTo<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeTo<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeFrom<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeFrom<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeFull> for String {
    #[inline]
    fn index_mut(&mut self, _index: ops::RangeFull) -> &mut str {
        unsafe { str::from_utf8_unchecked_mut(&mut *self.vec) }
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::IndexMut<ops::RangeInclusive<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeInclusive<usize>) -> &mut str {
        IndexMut::index_mut(&mut **self, index)
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::IndexMut<ops::RangeToInclusive<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeToInclusive<usize>) -> &mut str {
        IndexMut::index_mut(&mut **self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Deref for String {
    type Target = str;

    #[inline]
    fn deref(&self) -> &str {
        unsafe { str::from_utf8_unchecked(&self.vec) }
    }
}

#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::DerefMut for String {
    #[inline]
    fn deref_mut(&mut self) -> &mut str {
        unsafe { str::from_utf8_unchecked_mut(&mut *self.vec) }
    }
}

/// Isang uri ng alias para sa [`Infallible`].
///
/// Ang alias na ito ay umiiral para sa paatras na pagiging tugma, at maaaring sa wakas ay hindi na magamit.
///
/// [`Infallible`]: core::convert::Infallible
#[stable(feature = "str_parse_error", since = "1.5.0")]
pub type ParseError = core::convert::Infallible;

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for String {
    type Err = core::convert::Infallible;
    #[inline]
    fn from_str(s: &str) -> Result<String, Self::Err> {
        Ok(String::from(s))
    }
}

/// Isang trait para sa pag-convert ng isang halaga sa isang `String`.
///
/// Ang trait na ito ay awtomatikong ipinatupad para sa anumang uri na nagpapatupad ng [`Display`] trait.
/// Tulad ng naturan, ang `ToString` ay hindi dapat ipatupad nang direkta:
/// [`Display`] dapat na ipatupad sa halip, at makuha mo ang pagpapatupad ng `ToString` nang libre.
///
///
/// [`Display`]: fmt::Display
#[cfg_attr(not(test), rustc_diagnostic_item = "ToString")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ToString {
    /// Nagko-convert ang ibinigay na halaga sa isang `String`.
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// let i = 5;
    /// let five = String::from("5");
    ///
    /// assert_eq!(five, i.to_string());
    /// ```
    #[rustc_conversion_suggestion]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn to_string(&self) -> String;
}

/// # Panics
///
/// Sa pagpapatupad na ito, ang pamamaraan na `to_string` na panics kung ang pagpapatupad ng `Display` ay nagbabalik ng isang error.
/// Ipinapahiwatig nito ang isang maling `Display` pagpapatupad dahil ang `fmt::Write for String` ay hindi kailanman nagbalik ng isang error mismo.
///
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Display + ?Sized> ToString for T {
    // Ang isang karaniwang guideline ay upang hindi na inline generic function.
    // Gayunpaman, ang pag-alis ng `#[inline]` mula sa pamamaraang ito ay nagdudulot ng mga hindi bale-waling pagbabalik.
    // Tingnan ang <https://github.com/rust-lang/rust/pull/74852>, ang huling pagtatangka upang subukang alisin ito.
    //
    #[inline]
    default fn to_string(&self) -> String {
        use fmt::Write;
        let mut buf = String::new();
        buf.write_fmt(format_args!("{}", self))
            .expect("a Display implementation returned an error unexpectedly");
        buf
    }
}

#[stable(feature = "char_to_string_specialization", since = "1.46.0")]
impl ToString for char {
    #[inline]
    fn to_string(&self) -> String {
        String::from(self.encode_utf8(&mut [0; 4]))
    }
}

#[stable(feature = "str_to_string_specialization", since = "1.9.0")]
impl ToString for str {
    #[inline]
    fn to_string(&self) -> String {
        String::from(self)
    }
}

#[stable(feature = "cow_str_to_string_specialization", since = "1.17.0")]
impl ToString for Cow<'_, str> {
    #[inline]
    fn to_string(&self) -> String {
        self[..].to_owned()
    }
}

#[stable(feature = "string_to_string_specialization", since = "1.17.0")]
impl ToString for String {
    #[inline]
    fn to_string(&self) -> String {
        self.to_owned()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for String {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "string_as_mut", since = "1.43.0")]
impl AsMut<str> for String {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<[u8]> for String {
    #[inline]
    fn as_ref(&self) -> &[u8] {
        self.as_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl From<&str> for String {
    #[inline]
    fn from(s: &str) -> String {
        s.to_owned()
    }
}

#[stable(feature = "from_mut_str_for_string", since = "1.44.0")]
impl From<&mut str> for String {
    /// Kino-convert ng isang `&mut str` sa isang `String`.
    ///
    /// Ang resulta ay inilalaan sa tumpok.
    #[inline]
    fn from(s: &mut str) -> String {
        s.to_owned()
    }
}

#[stable(feature = "from_ref_string", since = "1.35.0")]
impl From<&String> for String {
    #[inline]
    fn from(s: &String) -> String {
        s.clone()
    }
}

// note: ang mga pagsubok ay humihila sa libstd, na nagiging sanhi ng mga pagkakamali dito
#[cfg(not(test))]
#[stable(feature = "string_from_box", since = "1.18.0")]
impl From<Box<str>> for String {
    /// Nagko-convert ang ibinigay na boxed `str` slice sa isang `String`.
    /// Kapansin-pansin na ang `str` slice ay pagmamay-ari.
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// let s1: String = String::from("hello world");
    /// let s2: Box<str> = s1.into_boxed_str();
    /// let s3: String = String::from(s2);
    ///
    /// assert_eq!("hello world", s3)
    /// ```
    fn from(s: Box<str>) -> String {
        s.into_string()
    }
}

#[stable(feature = "box_from_str", since = "1.20.0")]
impl From<String> for Box<str> {
    /// Nagko-convert ang ibinigay na `String` sa isang box na `str` slice na pagmamay-ari.
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// let s1: String = String::from("hello world");
    /// let s2: Box<str> = Box::from(s1);
    /// let s3: String = String::from(s2);
    ///
    /// assert_eq!("hello world", s3)
    /// ```
    fn from(s: String) -> Box<str> {
        s.into_boxed_str()
    }
}

#[stable(feature = "string_from_cow_str", since = "1.14.0")]
impl<'a> From<Cow<'a, str>> for String {
    fn from(s: Cow<'a, str>) -> String {
        s.into_owned()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> From<&'a str> for Cow<'a, str> {
    /// Nagko-convert ng isang hiwa ng string sa isang Pinahiram na variant.
    /// Walang ginanap na paglalaan na ginanap, at ang string ay hindi nakopya.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// assert_eq!(Cow::from("eggplant"), Cow::Borrowed("eggplant"));
    /// ```
    #[inline]
    fn from(s: &'a str) -> Cow<'a, str> {
        Cow::Borrowed(s)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> From<String> for Cow<'a, str> {
    /// Nag-convert ng isang String sa isang Pag-aari na variant.
    /// Walang ginanap na paglalaan na ginanap, at ang string ay hindi nakopya.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// let s = "eggplant".to_string();
    /// let s2 = "eggplant".to_string();
    /// assert_eq!(Cow::from(s), Cow::<'static, str>::Owned(s2));
    /// ```
    #[inline]
    fn from(s: String) -> Cow<'a, str> {
        Cow::Owned(s)
    }
}

#[stable(feature = "cow_from_string_ref", since = "1.28.0")]
impl<'a> From<&'a String> for Cow<'a, str> {
    /// Nag-convert ng isang sanggunian sa String sa isang Pinahiram na variant.
    /// Walang ginanap na paglalaan na ginanap, at ang string ay hindi nakopya.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// let s = "eggplant".to_string();
    /// assert_eq!(Cow::from(&s), Cow::Borrowed("eggplant"));
    /// ```
    #[inline]
    fn from(s: &'a String) -> Cow<'a, str> {
        Cow::Borrowed(s.as_str())
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a> FromIterator<char> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = char>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a, 'b> FromIterator<&'b str> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = &'b str>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a> FromIterator<String> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = String>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "from_string_for_vec_u8", since = "1.14.0")]
impl From<String> for Vec<u8> {
    /// Binabago ang ibinigay na `String` sa isang vector `Vec` na nagtataglay ng mga halagang uri ng `u8`.
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// let s1 = String::from("hello world");
    /// let v1 = Vec::from(s1);
    ///
    /// for b in v1 {
    ///     println!("{}", b);
    /// }
    /// ```
    fn from(string: String) -> Vec<u8> {
        string.into_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Write for String {
    #[inline]
    fn write_str(&mut self, s: &str) -> fmt::Result {
        self.push_str(s);
        Ok(())
    }

    #[inline]
    fn write_char(&mut self, c: char) -> fmt::Result {
        self.push(c);
        Ok(())
    }
}

/// Isang draining iterator para sa `String`.
///
/// Ang istrukturang ito ay nilikha ng pamamaraang [`drain`] sa [`String`].
/// Tingnan ang dokumentasyon nito para sa higit pa.
///
/// [`drain`]: String::drain
#[stable(feature = "drain", since = "1.6.0")]
pub struct Drain<'a> {
    /// Gagamitin bilang&'isang mut String sa destructor
    string: *mut String,
    /// Simula ng bahagi upang alisin
    start: usize,
    /// Pagtatapos ng bahagi upang alisin
    end: usize,
    /// Kasalukuyang natitirang saklaw upang alisin
    iter: Chars<'a>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl fmt::Debug for Drain<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Drain").field(&self.as_str()).finish()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
unsafe impl Sync for Drain<'_> {}
#[stable(feature = "drain", since = "1.6.0")]
unsafe impl Send for Drain<'_> {}

#[stable(feature = "drain", since = "1.6.0")]
impl Drop for Drain<'_> {
    fn drop(&mut self) {
        unsafe {
            // Gumamit ng Vec::drain.
            // "Reaffirm" ang hangganan pagsusuri upang maiwasan ang panic code na ipinasok muli.
            let self_vec = (*self.string).as_mut_vec();
            if self.start <= self.end && self.end <= self_vec.len() {
                self_vec.drain(self.start..self.end);
            }
        }
    }
}

impl<'a> Drain<'a> {
    /// Ibinabalik ang natitirang (sub) string ng iterator na ito bilang isang slice.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(string_drain_as_str)]
    /// let mut s = String::from("abc");
    /// let mut drain = s.drain(..);
    /// assert_eq!(drain.as_str(), "abc");
    /// let _ = drain.next().unwrap();
    /// assert_eq!(drain.as_str(), "bc");
    /// ```
    #[unstable(feature = "string_drain_as_str", issue = "76905")] // Note: hindi komportable AsRef impls sa ibaba kapag nagpapatatag.
    pub fn as_str(&self) -> &str {
        self.iter.as_str()
    }
}

// Uncomment kapag nagpapatatag ng `string_drain_as_str`.
// #[unstable(feature = "string_drain_as_str", issue = "76905")]
// impl <'a> AsRef<str>para sa Drain <'a> {fn as_ref(&self)-> &str {
//         self.as_str()
//     }
// }
//
// #[unstable(feature = "string_drain_as_str", issue = "76905")]
// impl <'a> AsRef <[u8]> para sa Drain <' a> {fn as_ref(&self)->&[u8]{
//
//         self.as_str().as_bytes()
//     }
// }
//

#[stable(feature = "drain", since = "1.6.0")]
impl Iterator for Drain<'_> {
    type Item = char;

    #[inline]
    fn next(&mut self) -> Option<char> {
        self.iter.next()
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }

    #[inline]
    fn last(mut self) -> Option<char> {
        self.next_back()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl DoubleEndedIterator for Drain<'_> {
    #[inline]
    fn next_back(&mut self) -> Option<char> {
        self.iter.next_back()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl FusedIterator for Drain<'_> {}

#[stable(feature = "from_char_for_string", since = "1.46.0")]
impl From<char> for String {
    #[inline]
    fn from(c: char) -> Self {
        c.to_string()
    }
}