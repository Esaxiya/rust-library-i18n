#![unstable(feature = "raw_vec_internals", reason = "implementation detail", issue = "none")]
#![doc(hidden)]

use core::alloc::LayoutError;
use core::cmp;
use core::intrinsics;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::Drop;
use core::ptr::{self, NonNull, Unique};
use core::slice;

use crate::alloc::{handle_alloc_error, Allocator, Global, Layout};
use crate::boxed::Box;
use crate::collections::TryReserveError::{self, *};

#[cfg(test)]
mod tests;

enum AllocInit {
    /// Ang nilalaman ng bagong memorya ay uninitialized.
    Uninitialized,
    /// Ang bagong memorya ay ginagarantiyahan na magiging zero.
    Zeroed,
}

/// Isang mababang antas ng utility para sa higit na ergonomically paglalaan, reallocating, at deallocating isang buffer ng memorya sa magbunton nang hindi nag-aalala tungkol sa lahat ng mga kasangkot na sulok kaso.
///
/// Ang uri na ito ay mahusay para sa pagbuo ng iyong sariling mga istraktura ng data tulad ng Vec at VecDeque.
/// Sa partikular:
///
/// * Gumagawa ng `Unique::dangling()` sa mga zero-size na uri.
/// * Gumagawa ng `Unique::dangling()` sa mga paglalaan ng zero-haba.
/// * Iniiwasan ang pagpapalaya sa `Unique::dangling()`.
/// * Nakukuha ang lahat ng pag-apaw sa mga computation ng kapasidad (isinusulong ang mga ito sa "capacity overflow" panics).
/// * Mga guwardiya laban sa 32-bit na mga system na naglalaan ng higit sa isize::MAX bytes.
/// * Mga bantay laban sa pag-apaw sa iyong haba.
/// * Tumatawag sa `handle_alloc_error` para sa mga mahihinang paglalaan.
/// * Naglalaman ng isang `ptr::Unique` at sa gayon ay pinagkalooban ang gumagamit ng lahat ng mga kaugnay na benepisyo.
/// * Gumagamit ng labis na ibinalik mula sa tagapaglaan upang magamit ang pinakamalaking magagamit na kakayahan.
///
/// Ang ganitong uri ay hindi pa rin siyasatin ang memorya na pinamamahalaan nito.Kapag nahulog ito *ay palalayain ang memorya nito, ngunit hindi nito* susubukan i-drop ang mga nilalaman nito.
/// Nasa sa gumagamit ng `RawVec` na hawakan ang aktwal na mga bagay *nakaimbak* sa loob ng isang `RawVec`.
///
/// Tandaan na ang labis ng isang uri na walang sukat ay palaging walang hanggan, kaya't laging nagbabalik ang `capacity()` ng `usize::MAX`.
/// Nangangahulugan ito na kailangan mong mag-ingat kapag paikot-ikot ang ganitong uri sa isang `Box<[T]>`, dahil ang `capacity()` ay hindi magbubunga ng haba.
///
///
#[allow(missing_debug_implementations)]
pub struct RawVec<T, A: Allocator = Global> {
    ptr: Unique<T>,
    cap: usize,
    alloc: A,
}

impl<T> RawVec<T, Global> {
    /// HACK(Centril): Ito ay umiiral dahil ang `#[unstable]` `const fn`s ay hindi kailangang sumunod sa `min_const_fn` at sa gayon ay hindi rin sila matawag sa`min_const_fn`s alinman.
    ///
    /// Kung binago mo ang `RawVec<T>::new` o mga dependency, mangyaring mag-ingat upang hindi ipakilala ang anumang bagay na tunay na lumalabag sa `min_const_fn`.
    ///
    /// NOTE: Maaari naming maiwasan ang pag-hack na ito at suriin ang pagsunod sa ilang katangian ng `#[rustc_force_min_const_fn]` na nangangailangan ng pagsunod sa `min_const_fn` ngunit hindi kinakailangang payagan ang pagtawag nito sa `stable(...) const fn`/user code na hindi pinapagana ang `foo` kapag naroroon ang `#[rustc_const_unstable(feature = "foo", issue = "01234")]`.
    ///
    ///
    ///
    ///
    ///
    ///
    pub const NEW: Self = Self::new();

    /// Lumilikha ng pinakamalaking posibleng `RawVec` (sa tambak ng system) nang hindi naglalaan.
    /// Kung ang `T` ay may positibong sukat, pagkatapos ay gumagawa ito ng `RawVec` na may kapasidad `0`.
    /// Kung ang `T` ay zero-size, pagkatapos ay gumagawa ito ng `RawVec` na may kapasidad `usize::MAX`.
    /// Kapaki-pakinabang para sa pagpapatupad ng naantala na paglalaan.
    ///
    pub const fn new() -> Self {
        Self::new_in(Global)
    }

    /// Lumilikha ng isang `RawVec` (sa tumpok ng system) na may eksaktong kapasidad at mga kinakailangan sa pagkakahanay para sa isang `[T; capacity]`.
    /// Katumbas ito ng pagtawag sa `RawVec::new` kapag ang `capacity` ay `0` o `T` ay zero-size.
    /// Tandaan na kung ang `T` ay zero-size nangangahulugan ito na hindi ka * makakakuha ng isang `RawVec` na may hiniling na kapasidad.
    ///
    /// # Panics
    ///
    /// Panics kung ang hiniling na kapasidad ay lumampas `isize::MAX` bytes.
    ///
    /// # Aborts
    ///
    /// Aborts sa OOM.
    ///
    ///
    #[inline]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// Tulad ng `with_capacity`, ngunit ginagarantiyahan ang buffer ay zero.
    #[inline]
    pub fn with_capacity_zeroed(capacity: usize) -> Self {
        Self::with_capacity_zeroed_in(capacity, Global)
    }

    /// Muling nagtataguyod ng isang `RawVec` mula sa isang pointer at kapasidad.
    ///
    /// # Safety
    ///
    /// Ang `ptr` ay dapat na ilaan (sa tumpok ng system), at sa ibinigay na `capacity`.
    /// Ang `capacity` ay hindi maaaring lumagpas sa `isize::MAX` para sa laki ng mga uri.(isang alalahanin lamang sa mga 32-bit na system).
    /// Ang ZST vectors ay maaaring may kapasidad hanggang sa `usize::MAX`.
    /// Kung ang `ptr` at `capacity` ay nagmula sa isang `RawVec`, pagkatapos ay garantisado ito.
    #[inline]
    pub unsafe fn from_raw_parts(ptr: *mut T, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, capacity, Global) }
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    // Ang mga maliliit na Vec ay pipi.Laktaw papunta sa:
    // - 8 kung ang sukat ng elemento ay 1, dahil ang anumang tagapagtalaga ng magbunton ay malamang na mag-ikot ng isang kahilingan na mas mababa sa 8 bytes hanggang sa hindi bababa sa 8 bytes.
    //
    // - 4 kung ang mga elemento ay katamtaman ang laki (<=1 KiB).
    // - 1 kung hindi man, upang maiwasan ang pag-aaksaya ng labis na puwang para sa mga napakaikling Vecs.
    const MIN_NON_ZERO_CAP: usize = if mem::size_of::<T>() == 1 {
        8
    } else if mem::size_of::<T>() <= 1024 {
        4
    } else {
        1
    };

    /// Tulad ng `new`, ngunit na-parameter sa pagpili ng tagapaglaan para sa ibinalik na `RawVec`.
    ///
    #[rustc_allow_const_fn_unstable(const_fn)]
    pub const fn new_in(alloc: A) -> Self {
        // `cap: 0` nangangahulugang "unallocated".hindi pinapansin ang mga uri ng zero na laki.
        Self { ptr: Unique::dangling(), cap: 0, alloc }
    }

    /// Tulad ng `with_capacity`, ngunit na-parameter sa pagpili ng tagapaglaan para sa ibinalik na `RawVec`.
    ///
    #[inline]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Uninitialized, alloc)
    }

    /// Tulad ng `with_capacity_zeroed`, ngunit na-parameter sa pagpili ng tagapaglaan para sa ibinalik na `RawVec`.
    ///
    #[inline]
    pub fn with_capacity_zeroed_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Zeroed, alloc)
    }

    /// Binabago ang isang `Box<[T]>` sa isang `RawVec<T>`.
    pub fn from_box(slice: Box<[T], A>) -> Self {
        unsafe {
            let (slice, alloc) = Box::into_raw_with_allocator(slice);
            RawVec::from_raw_parts_in(slice.as_mut_ptr(), slice.len(), alloc)
        }
    }

    /// Binabago ang buong buffer sa `Box<[MaybeUninit<T>]>` gamit ang tinukoy na `len`.
    ///
    /// Tandaan na tama itong muling pagbubuo ng anumang mga pagbabago sa `cap` na maaaring nagawa.(Tingnan ang paglalarawan ng uri para sa mga detalye.)
    ///
    /// # Safety
    ///
    /// * `len` dapat na mas malaki sa o katumbas ng pinakahuling hiniling na kakayahan, at
    /// * `len` dapat mas mababa sa o katumbas ng `self.capacity()`.
    ///
    /// Tandaan, na ang hiniling na kapasidad at `self.capacity()` ay maaaring magkakaiba, dahil ang isang tagapaglaan ay maaaring mag-overallocate at ibalik ang isang mas malaking memory block kaysa sa hiniling.
    ///
    ///
    pub unsafe fn into_box(self, len: usize) -> Box<[MaybeUninit<T>], A> {
        // Suriin ng katinuan ang kalahati ng kinakailangan sa kaligtasan (hindi namin maaaring suriin ang kalahati).
        debug_assert!(
            len <= self.capacity(),
            "`len` must be smaller than or equal to `self.capacity()`"
        );

        let me = ManuallyDrop::new(self);
        unsafe {
            let slice = slice::from_raw_parts_mut(me.ptr() as *mut MaybeUninit<T>, len);
            Box::from_raw_in(slice, ptr::read(&me.alloc))
        }
    }

    fn allocate_in(capacity: usize, init: AllocInit, alloc: A) -> Self {
        if mem::size_of::<T>() == 0 {
            Self::new_in(alloc)
        } else {
            // Iniiwasan namin ang `unwrap_or_else` dito dahil pinapasok nito ang dami ng nabuo na LLVM IR.
            //
            let layout = match Layout::array::<T>(capacity) {
                Ok(layout) => layout,
                Err(_) => capacity_overflow(),
            };
            match alloc_guard(layout.size()) {
                Ok(_) => {}
                Err(_) => capacity_overflow(),
            }
            let result = match init {
                AllocInit::Uninitialized => alloc.allocate(layout),
                AllocInit::Zeroed => alloc.allocate_zeroed(layout),
            };
            let ptr = match result {
                Ok(ptr) => ptr,
                Err(_) => handle_alloc_error(layout),
            };

            Self {
                ptr: unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) },
                cap: Self::capacity_from_bytes(ptr.len()),
                alloc,
            }
        }
    }

    /// Muling nagtataguyod ng isang `RawVec` mula sa isang pointer, kakayahan, at tagapaglaan.
    ///
    /// # Safety
    ///
    /// Ang `ptr` ay dapat na inilaan (sa pamamagitan ng ibinigay na tagapagkaloob `alloc`), at sa ibinigay na `capacity`.
    /// Ang `capacity` ay hindi maaaring lumagpas sa `isize::MAX` para sa laki ng mga uri.
    /// (isang alalahanin lamang sa mga 32-bit na system).
    /// Ang ZST vectors ay maaaring may kapasidad hanggang sa `usize::MAX`.
    /// Kung ang `ptr` at `capacity` ay nagmula sa isang `RawVec` na nilikha sa pamamagitan ng `alloc`, pagkatapos ay garantisado ito.
    ///
    #[inline]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, capacity: usize, alloc: A) -> Self {
        Self { ptr: unsafe { Unique::new_unchecked(ptr) }, cap: capacity, alloc }
    }

    /// Nakakakuha ng isang hilaw na pointer sa simula ng paglalaan.
    /// Tandaan na ito ay `Unique::dangling()` kung ang `capacity == 0` o `T` ay zero-size.
    /// Sa dating kaso, dapat kang mag-ingat.
    #[inline]
    pub fn ptr(&self) -> *mut T {
        self.ptr.as_ptr()
    }

    /// Nakukuha ang kapasidad ng paglalaan.
    ///
    /// Ito ay palaging magiging `usize::MAX` kung ang `T` ay zero-size.
    #[inline(always)]
    pub fn capacity(&self) -> usize {
        if mem::size_of::<T>() == 0 { usize::MAX } else { self.cap }
    }

    /// Nagbabalik ng isang nakabahaging sanggunian sa tagataguyod na sumusuporta sa `RawVec` na ito.
    pub fn allocator(&self) -> &A {
        &self.alloc
    }

    fn current_memory(&self) -> Option<(NonNull<u8>, Layout)> {
        if mem::size_of::<T>() == 0 || self.cap == 0 {
            None
        } else {
            // Mayroon kaming inilalaan na tipak ng memorya, kaya maaari naming bypass ang mga pagsusuri sa runtime upang makuha ang aming kasalukuyang layout.
            //
            unsafe {
                let align = mem::align_of::<T>();
                let size = mem::size_of::<T>() * self.cap;
                let layout = Layout::from_size_align_unchecked(size, align);
                Some((self.ptr.cast().into(), layout))
            }
        }
    }

    /// Tinitiyak na ang buffer ay naglalaman ng hindi bababa sa sapat na puwang upang hawakan ang `len + additional` na mga elemento.
    /// Kung wala itong sapat na kapasidad, muling maglalaan ng sapat na puwang plus kumportableng puwang ng slack upang ma-amortize ang *O*(1) na pag-uugali.
    ///
    /// Lilimitahan na pag-uugali na ito kung ito ay needlessly maging sanhi ng sarili nito sa panic.
    ///
    /// Kung ang `len` ay lumampas sa `self.capacity()`, maaaring mabigo ito na aktwal na maglaan ng hiniling na puwang.
    /// Hindi talaga ito ligtas, ngunit ang hindi ligtas na code na *isinulat mo* na umaasa sa pag-uugali ng pagpapaandar na ito ay maaaring masira.
    ///
    /// Mainam ito para sa pagpapatupad ng isang operasyon ng maramihang push tulad ng `extend`.
    ///
    /// # Panics
    ///
    /// Panics kung ang bagong kapasidad ay lumampas sa `isize::MAX` bytes.
    ///
    /// # Aborts
    ///
    /// Aborts sa OOM.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![feature(raw_vec_internals)]
    /// # extern crate alloc;
    /// # use std::ptr;
    /// # use alloc::raw_vec::RawVec;
    /// struct MyVec<T> {
    ///     buf: RawVec<T>,
    ///     len: usize,
    /// }
    ///
    /// impl<T: Clone> MyVec<T> {
    ///     pub fn push_all(&mut self, elems: &[T]) {
    ///         self.buf.reserve(self.len, elems.len());
    ///         // ang reserba ay aalisin o nag-panic kung ang len ay lumampas sa `isize::MAX` kaya't ligtas itong gawin na hindi naka-check ngayon.
    /////
    ///         for x in elems {
    ///             unsafe {
    ///                 ptr::write(self.buf.ptr().add(self.len), x.clone());
    ///             }
    ///             self.len += 1;
    ///         }
    ///     }
    /// }
    /// # fn main() {
    /// #   let mut vector = MyVec { buf: RawVec::new(), len: 0 };
    /// #   vector.push_all(&[1, 3, 5, 7, 9]);
    /// # }
    /// ```
    ///
    ///
    pub fn reserve(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve(len, additional));
    }

    /// Kapareho ng `reserve`, ngunit bumalik sa mga error sa halip na panic o pagpapalaglag.
    pub fn try_reserve(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) {
            self.grow_amortized(len, additional)
        } else {
            Ok(())
        }
    }

    /// Tinitiyak na ang buffer ay naglalaman ng hindi bababa sa sapat na puwang upang hawakan ang `len + additional` na mga elemento.
    /// Kung hindi pa ito, muling ilalaan ang minimum na posibleng halaga ng memorya na kinakailangan.
    /// Pangkalahatan ito ay eksaktong magiging halaga ng memorya na kinakailangan, ngunit sa prinsipyo ang tagapaglaan ay libre na ibalik ang higit sa hiniling namin.
    ///
    ///
    /// Kung ang `len` ay lumampas sa `self.capacity()`, maaaring mabigo ito na aktwal na maglaan ng hiniling na puwang.
    /// Hindi talaga ito ligtas, ngunit ang hindi ligtas na code na *isinulat mo* na umaasa sa pag-uugali ng pagpapaandar na ito ay maaaring masira.
    ///
    /// # Panics
    ///
    /// Panics kung ang bagong kapasidad ay lumampas sa `isize::MAX` bytes.
    ///
    /// # Aborts
    ///
    /// Aborts sa OOM.
    ///
    ///
    pub fn reserve_exact(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve_exact(len, additional));
    }

    /// Kapareho ng `reserve_exact`, ngunit bumalik sa mga error sa halip na panic o pagpapalaglag.
    pub fn try_reserve_exact(
        &mut self,
        len: usize,
        additional: usize,
    ) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) { self.grow_exact(len, additional) } else { Ok(()) }
    }

    /// Pinapaliit ang paglalaan hanggang sa tinukoy na halaga.
    /// Kung ang ibinigay na halaga ay 0, talagang ganap na nakikipag-deal.
    ///
    /// # Panics
    ///
    /// Panics kung ang ibinigay na halaga ay *mas malaki* kaysa sa kasalukuyang kapasidad.
    ///
    /// # Aborts
    ///
    /// Aborts sa OOM.
    pub fn shrink_to_fit(&mut self, amount: usize) {
        handle_reserve(self.shrink(amount));
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    /// Nagbabalik kung ang buffer ay kailangang lumago upang matupad ang kinakailangang karagdagang kapasidad.
    /// Pangunahing ginamit upang gawing posible ang mga nakapaloob na mga tawag sa reserba nang hindi inlining ang `grow`.
    fn needs_to_grow(&self, len: usize, additional: usize) -> bool {
        additional > self.capacity().wrapping_sub(len)
    }

    fn capacity_from_bytes(excess: usize) -> usize {
        debug_assert_ne!(mem::size_of::<T>(), 0);
        excess / mem::size_of::<T>()
    }

    fn set_ptr(&mut self, ptr: NonNull<[u8]>) {
        self.ptr = unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) };
        self.cap = Self::capacity_from_bytes(ptr.len());
    }

    // Ang pamamaraang ito ay karaniwang naitatag ng maraming beses.Kaya gusto naming ito upang maging bilang maliit na hangga't maaari, upang mapabuti ang sumulat ng libro ulit.
    // Ngunit nais din namin ang karamihan sa mga nilalaman nito na maging statically computable hangga't maaari, upang mas mabilis na tumakbo ang nabuong code.
    // Samakatuwid, maingat na nakasulat ang pamamaraang ito upang ang lahat ng code na nakasalalay sa `T` ay nasa loob nito, habang ang dami ng code na hindi nakasalalay sa `T` hangga't maaari ay nasa mga pagpapaandar na hindi generic na higit sa `T`.
    //
    //
    //
    //
    fn grow_amortized(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        // Tinitiyak ito ng mga konteksto ng pagtawag.
        debug_assert!(additional > 0);

        if mem::size_of::<T>() == 0 {
            // Dahil binabalik namin ang isang kapasidad ng `usize::MAX` kapag `elem_size` ay
            // 0, ang pagpunta dito kinakailangan na nangangahulugang ang `RawVec` ay labis na labis.
            return Err(CapacityOverflow);
        }

        // Wala talaga tayong magagawa tungkol sa mga tseke na ito, nakalulungkot.
        let required_cap = len.checked_add(additional).ok_or(CapacityOverflow)?;

        // Ginagarantiyahan nito ang paglago ng exponential.
        // Ang pagdoble ay hindi maaaring mag-overflow dahil ang `cap <= isize::MAX` at ang uri ng `cap` ay `usize`.
        let cap = cmp::max(self.cap * 2, required_cap);
        let cap = cmp::max(Self::MIN_NON_ZERO_CAP, cap);

        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` ay hindi pangkaraniwan sa paglipas ng `T`.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    // Ang mga hadlang sa pamamaraang ito ay kapareho ng mga nasa `grow_amortized`, ngunit ang pamamaraang ito ay kadalasang naiintindihan nang mas madalas kaya't hindi gaanong kritikal.
    //
    //
    fn grow_exact(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if mem::size_of::<T>() == 0 {
            // Dahil binabalik namin ang isang kapasidad na `usize::MAX` kapag ang laki ng uri ay
            // 0, ang pagpunta dito kinakailangan na nangangahulugang ang `RawVec` ay labis na labis.
            return Err(CapacityOverflow);
        }

        let cap = len.checked_add(additional).ok_or(CapacityOverflow)?;
        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` ay hindi pangkaraniwan sa paglipas ng `T`.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    fn shrink(&mut self, amount: usize) -> Result<(), TryReserveError> {
        assert!(amount <= self.capacity(), "Tried to shrink to a larger capacity");

        let (ptr, layout) = if let Some(mem) = self.current_memory() { mem } else { return Ok(()) };
        let new_size = amount * mem::size_of::<T>();

        let ptr = unsafe {
            let new_layout = Layout::from_size_align_unchecked(new_size, layout.align());
            self.alloc.shrink(ptr, layout, new_layout).map_err(|_| TryReserveError::AllocError {
                layout: new_layout,
                non_exhaustive: (),
            })?
        };
        self.set_ptr(ptr);
        Ok(())
    }
}

// Ang pagpapaandar na ito ay nasa labas ng `RawVec` upang i-minimize ang mga oras ng pagsulat.Tingnan ang komento sa itaas `RawVec::grow_amortized` para sa mga detalye.
// (Ang parameter na `A` ay hindi makabuluhan, dahil ang bilang ng iba't ibang mga uri ng `A` na nakikita sa pagsasanay ay mas maliit kaysa sa bilang ng mga uri ng `T`.)
//
//
#[inline(never)]
fn finish_grow<A>(
    new_layout: Result<Layout, LayoutError>,
    current_memory: Option<(NonNull<u8>, Layout)>,
    alloc: &mut A,
) -> Result<NonNull<[u8]>, TryReserveError>
where
    A: Allocator,
{
    // Suriin ang error dito upang i-minimize ang laki ng `RawVec::grow_*`.
    let new_layout = new_layout.map_err(|_| CapacityOverflow)?;

    alloc_guard(new_layout.size())?;

    let memory = if let Some((ptr, old_layout)) = current_memory {
        debug_assert_eq!(old_layout.align(), new_layout.align());
        unsafe {
            // Sinusuri ng tagapaglaan ang pagkakapantay-pantay ng pagkakahanay
            intrinsics::assume(old_layout.align() == new_layout.align());
            alloc.grow(ptr, old_layout, new_layout)
        }
    } else {
        alloc.allocate(new_layout)
    };

    memory.map_err(|_| AllocError { layout: new_layout, non_exhaustive: () })
}

unsafe impl<#[may_dangle] T, A: Allocator> Drop for RawVec<T, A> {
    /// Pinapalaya ang memorya na pagmamay-ari ng `RawVec`*nang hindi* sinusubukang i-drop ang mga nilalaman nito.
    fn drop(&mut self) {
        if let Some((ptr, layout)) = self.current_memory() {
            unsafe { self.alloc.deallocate(ptr, layout) }
        }
    }
}

// Central function para sa paghawak ng error sa reserba.
#[inline]
fn handle_reserve(result: Result<(), TryReserveError>) {
    match result {
        Err(CapacityOverflow) => capacity_overflow(),
        Err(AllocError { layout, .. }) => handle_alloc_error(layout),
        Ok(()) => { /* yay */ }
    }
}

// Kailangan naming garantiya ang sumusunod:
// * Hindi namin kailanman inilalaan ang `> isize::MAX` byte-size na mga bagay.
// * Hindi kami umaapaw sa `usize::MAX` at talagang naglalaan ng napakaliit.
//
// Sa 64-bit kailangan lang naming suriin para sa overflow dahil ang pagsubok na maglaan ng `> isize::MAX` bytes ay tiyak na mabibigo.
// Sa 32-bit at 16-bit kailangan naming magdagdag ng dagdag na bantay para dito kung sakaling tumatakbo kami sa isang platform na maaaring magamit ang lahat ng 4GB sa puwang ng gumagamit, hal., PAE o x32.
//
//

#[inline]
fn alloc_guard(alloc_size: usize) -> Result<(), TryReserveError> {
    if usize::BITS < 64 && alloc_size > isize::MAX as usize {
        Err(CapacityOverflow)
    } else {
        Ok(())
    }
}

// Isang sentral na tungkulin na responsable para sa pag-uulat ng overflow na kapasidad.
// Titiyakin nito na ang pagbuo ng code na nauugnay sa panics na ito ay minimal dahil mayroon lamang isang lokasyon kung saan ang panics sa halip na isang bungkos sa buong module.
//
fn capacity_overflow() -> ! {
    panic!("capacity overflow");
}