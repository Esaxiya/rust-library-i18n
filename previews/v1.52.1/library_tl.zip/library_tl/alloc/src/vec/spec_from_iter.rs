use core::mem::ManuallyDrop;
use core::ptr::{self};
use core::slice::{self};

use super::{IntoIter, SpecExtend, SpecFromIterNested, Vec};

/// Ang pagdadalubhasa trait na ginagamit para sa Vec::from_iter
///
/// ## Ang graph ng delegasyon:
///
/// ```text
/// +-------------+
/// |FromIterator |
/// +-+-----------+
///   |
///   v
/// +-+-------------------------------+  +---------------------+
/// |SpecFromIter                  +---->+SpecFromIterNested   |
/// |where I:                      |  |  |where I:             |
/// |  Iterator (default)----------+  |  |  Iterator (default) |
/// |  vec::IntoIter               |  |  |  TrustedLen         |
/// |  SourceIterMarker---fallback-+  |  |                     |
/// |  slice::Iter                    |  |                     |
/// |  Iterator<Item = &Clone>        |  +---------------------+
/// +---------------------------------+
/// ```
pub(super) trait SpecFromIter<T, I> {
    fn from_iter(iter: I) -> Self;
}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T>,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIterNested::from_iter(iterator)
    }
}

impl<T> SpecFromIter<T, IntoIter<T>> for Vec<T> {
    fn from_iter(iterator: IntoIter<T>) -> Self {
        // Ang isang karaniwang kaso ay ang pagpasa ng isang vector sa isang pagpapaandar na agad na muling kolektahin sa isang vector.
        // Maaari natin itong maiikling circuit kung ang IntoIter ay hindi pa na-advance.
        // Kapag na-advance na Maaari din nating muling magamit ang memorya at ilipat ang data sa harap.
        // Ngunit ginagawa lamang namin ito kapag ang nagresultang Vec ay hindi magkakaroon ng higit na hindi nagamit na kakayahan kaysa sa paglikha nito sa pamamagitan ng pangkalahatang implementasyon ng FromIterator.
        //
        // Ang paghihigpit na iyon ay hindi mahigpit na kinakailangan dahil ang pag-uugali ng paglalaan ng Vec ay sadyang hindi natukoy.
        // Ngunit ito ay isang konserbatibong pagpipilian.
        //
        let has_advanced = iterator.buf.as_ptr() as *const _ != iterator.ptr;
        if !has_advanced || iterator.len() >= iterator.cap / 2 {
            unsafe {
                let it = ManuallyDrop::new(iterator);
                if has_advanced {
                    ptr::copy(it.ptr, it.buf.as_ptr(), it.len());
                }
                return Vec::from_raw_parts(it.buf.as_ptr(), it.len(), it.cap);
            }
        }

        let mut vec = Vec::new();
        // dapat paglaanan ng spec_extend() dahil extend() mismo delegates upang spec_from para sa walang laman Vecs
        //
        vec.spec_extend(iterator);
        vec
    }
}

impl<'a, T: 'a, I> SpecFromIter<&'a T, I> for Vec<T>
where
    I: Iterator<Item = &'a T>,
    T: Clone,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIter::from_iter(iterator.cloned())
    }
}

// Gumagamit ito ng `iterator.as_slice().to_vec()` dahil ang spec_extend ay dapat gumawa ng maraming mga hakbang upang mangatwiran tungkol sa pangwakas na kapasidad + haba at sa gayon ay gumawa ng mas maraming trabaho.
// `to_vec()` direktang naglalaan ng tamang halaga at eksaktong pinupunan ito.
//
//
impl<'a, T: 'a + Clone> SpecFromIter<&'a T, slice::Iter<'a, T>> for Vec<T> {
    #[cfg(not(test))]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        iterator.as_slice().to_vec()
    }

    // HACK(japaric): na may cfg(test) ang taglay na `[T]::to_vec` na pamamaraan, na kinakailangan para sa kahulugan ng pamamaraang ito, ay hindi magagamit.
    // Sa halip gamitin ang `slice::to_vec` function na magagamit lamang sa cfg(test) NB tingnan ang slice::hack module sa slice.rs para sa karagdagang impormasyon
    //
    //
    #[cfg(test)]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        crate::slice::to_vec(iterator.as_slice(), crate::alloc::Global)
    }
}