//! Isang magkadikit na maaaring palaguin na uri ng array na may mga nilalaman na inilalaan ng bunton, nakasulat na `Vec<T>`.
//!
//! Vectors kung `O(1)` pag-index, amortized `O(1)` push (sa dulo) at `O(1)` pop (mula sa dulo).
//!
//!
//! Tinitiyak ng Vectors na hindi sila maglaan ng higit sa `isize::MAX` bytes.
//!
//! # Examples
//!
//! Maaari mong malinaw na lumikha ng isang [`Vec`] sa [`Vec::new`]:
//!
//! ```
//! let v: Vec<i32> = Vec::new();
//! ```
//!
//! ... o sa pamamagitan ng paggamit ng [`vec!`] macro:
//!
//! ```
//! let v: Vec<i32> = vec![];
//!
//! let v = vec![1, 2, 3, 4, 5];
//!
//! let v = vec![0; 10]; // sampung zero
//! ```
//!
//! Maaari mong [`push`] halaga hanggang sa dulo ng isang vector (na kung saan ay palaguin ang vector kung kinakailangan):
//!
//! ```
//! let mut v = vec![1, 2];
//!
//! v.push(3);
//! ```
//!
//! Gumagana ang mga halaga ng paglalagay sa pareho sa parehong paraan:
//!
//! ```
//! let mut v = vec![1, 2];
//!
//! let two = v.pop();
//! ```
//!
//! Sinusuportahan din ng Vectors ang pag-index (sa pamamagitan ng [`Index`] at [`IndexMut`] traits):
//!
//! ```
//! let mut v = vec![1, 2, 3];
//! let three = v[2];
//! v[1] = v[1] + 5;
//! ```
//!
//! [`push`]: Vec::push
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::cmp::{self, Ordering};
use core::convert::TryFrom;
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::{arith_offset, assume};
use core::iter::FromIterator;
use core::marker::PhantomData;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::{self, Index, IndexMut, Range, RangeBounds};
use core::ptr::{self, NonNull};
use core::slice::{self, SliceIndex};

use crate::alloc::{Allocator, Global};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::collections::TryReserveError;
use crate::raw_vec::RawVec;

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
pub use self::drain_filter::DrainFilter;

mod drain_filter;

#[stable(feature = "vec_splice", since = "1.21.0")]
pub use self::splice::Splice;

mod splice;

#[stable(feature = "drain", since = "1.6.0")]
pub use self::drain::Drain;

mod drain;

mod cow;

pub(crate) use self::into_iter::AsIntoIter;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::into_iter::IntoIter;

mod into_iter;

use self::is_zero::IsZero;

mod is_zero;

mod source_iter_marker;

mod partial_eq;

use self::spec_from_elem::SpecFromElem;

mod spec_from_elem;

use self::set_len_on_drop::SetLenOnDrop;

mod set_len_on_drop;

use self::in_place_drop::InPlaceDrop;

mod in_place_drop;

use self::spec_from_iter_nested::SpecFromIterNested;

mod spec_from_iter_nested;

use self::spec_from_iter::SpecFromIter;

mod spec_from_iter;

use self::spec_extend::SpecExtend;

mod spec_extend;

/// Isang magkadikit na maaaring palaguin na uri ng array, nakasulat bilang `Vec<T>` at binibigkas na 'vector'.
///
/// # Examples
///
/// ```
/// let mut vec = Vec::new();
/// vec.push(1);
/// vec.push(2);
///
/// assert_eq!(vec.len(), 2);
/// assert_eq!(vec[0], 1);
///
/// assert_eq!(vec.pop(), Some(2));
/// assert_eq!(vec.len(), 1);
///
/// vec[0] = 7;
/// assert_eq!(vec[0], 7);
///
/// vec.extend([1, 2, 3].iter().copied());
///
/// for x in &vec {
///     println!("{}", x);
/// }
/// assert_eq!(vec, [7, 1, 2, 3]);
/// ```
///
/// Ibinigay ang [`vec!`] macro upang gawing mas maginhawa ang pagsisimula.
///
/// ```
/// let mut vec = vec![1, 2, 3];
/// vec.push(4);
/// assert_eq!(vec, [1, 2, 3, 4]);
/// ```
///
/// Maaari rin itong initialize bawat elemento ng isang `Vec<T>` na may ibinigay na halaga.
/// Maaari itong maging mas mahusay kaysa sa pagsasagawa ng paglalaan at pagsisimula sa magkakahiwalay na mga hakbang, lalo na kapag pinasimulan ang isang vector ng mga zero:
///
/// ```
/// let vec = vec![0; 5];
/// assert_eq!(vec, [0, 0, 0, 0, 0]);
///
/// // Ang sumusunod ay katumbas, ngunit maaaring mas mabagal:
/// let mut vec = Vec::with_capacity(5);
/// vec.resize(5, 0);
/// assert_eq!(vec, [0, 0, 0, 0, 0]);
/// ```
///
/// Para sa karagdagang impormasyon, tingnan ang [Capacity and Reallocation](#capacity-and-reallocation).
///
/// Gumamit ng isang `Vec<T>` bilang isang mahusay na stack:
///
/// ```
/// let mut stack = Vec::new();
///
/// stack.push(1);
/// stack.push(2);
/// stack.push(3);
///
/// while let Some(top) = stack.pop() {
///     // Mga Limbag 3, 2, 1
///     println!("{}", top);
/// }
/// ```
///
/// # Indexing
///
/// Pinapayagan ng uri ng `Vec` na ma-access ang mga halaga sa pamamagitan ng index, dahil ipinapatupad nito ang [`Index`] trait.Ang isang halimbawa ay magiging mas malinaw:
///
/// ```
/// let v = vec![0, 2, 4, 6];
/// println!("{}", v[1]); // ipapakita nito ang '2'
/// ```
///
/// Gayunpaman mag-ingat: kung susubukan mong mag-access ng isang index na wala sa `Vec`, ang iyong software ay panic!Hindi mo ito magagawa:
///
/// ```should_panic
/// let v = vec![0, 2, 4, 6];
/// println!("{}", v[6]); // it will panic!
/// ```
///
/// Gamitin [`get`] at [`get_mut`] kung nais mong suriin kung ang index ay nasa `Vec`.
///
/// # Slicing
///
/// Ang isang `Vec` ay maaaring nabago.Sa kabilang dako, hiwa ay read-only bagay.
/// Upang makakuha ng [slice][prim@slice], gamitin ang [`&`].Halimbawa:
///
/// ```
/// fn read_slice(slice: &[usize]) {
///     // ...
/// }
///
/// let v = vec![0, 1];
/// read_slice(&v);
///
/// // ... at yun lang!
/// // maaari mo ring gawin ito tulad na ito:
/// let u: &[usize] = &v;
/// // o tulad nito:
/// let u: &[_] = &v;
/// ```
///
/// Sa Rust, mas karaniwan na ipasa ang mga hiwa bilang mga argumento kaysa sa vectors kung nais mo lamang magbigay ng nabasang access.Ang parehong napupunta para sa [`String`] at [`&str`].
///
/// # Kapasidad at reallocation
///
/// Ang kapasidad ng isang vector ay ang halaga ng puwang na inilalaan para sa anumang mga elemento ng future na idaragdag sa vector.Na ito ay hindi dapat malito sa mga *length* ng isang vector, na tumutukoy sa bilang ng mga aktwal na mga elemento sa loob ng vector.
/// Kung ang haba ng isang vector ay lumampas sa kapasidad nito, ang kapasidad nito ay awtomatikong madaragdagan, ngunit ang mga elemento nito ay kailangang muling ibigay.
///
/// Halimbawa, ang isang vector na may kapasidad 10 at haba ng 0 ay magiging isang walang laman na vector na may puwang para sa 10 higit pang mga elemento.Ang pagtulak ng 10 o mas kaunting mga elemento sa vector ay hindi magbabago ng kapasidad nito o maging sanhi ng reallocation na maganap.
/// Gayunpaman, kung ang haba ng vector ay nadagdagan sa 11, magkakaroon ito ng reallocate, na maaaring maging mabagal.Para sa kadahilanang ito, inirerekumenda na gumamit ng [`Vec::with_capacity`] hangga't maaari upang tukuyin kung gaano kalaki ang inaasahang makuha ng vector.
///
/// # Guarantees
///
/// Dahil sa hindi kapani-paniwalang pangunahing katangian nito, ang `Vec` ay gumagawa ng maraming mga garantiya tungkol sa disenyo nito.Tinitiyak nito na ito ay bilang mababang-overhead hangga't maaari sa pangkalahatang kaso, at maaaring manipulahin nang tama sa mga paunang paraan sa pamamagitan ng hindi ligtas na code.Tandaan na ang mga garantiyang ito ay tumutukoy sa isang hindi kwalipikadong `Vec<T>`.
/// Kung ang mga karagdagang uri ng parameter ay idinagdag (hal., Upang suportahan ang mga pasadyang tagapaglaan), ang overriding ng kanilang mga default ay maaaring mabago ang pag-uugali.
///
/// Karamihan sa panimula, ang `Vec` ay at palaging magiging isang (pointer, kapasidad, haba) triplet.Wala nang, hindi kukulangin.Ang pagkakasunud-sunod ng mga patlang na ito ay ganap na hindi natukoy, at dapat mong gamitin ang mga naaangkop na pamamaraan upang baguhin ang mga ito.
/// pointer ay hindi kailanman ay magiging null, para sa ganitong uri ay null-pointer-optimize.
///
/// Gayunpaman, ang pointer ay maaaring hindi tunay na tumuturo sa inilaang memorya.
/// Sa partikular, kung bumuo ka ng isang `Vec` na may kapasidad 0 sa pamamagitan ng [`Vec::new`], [`vec![]`][`vec!`], [`Vec::with_capacity(0)`][`Vec::with_capacity`], o sa pamamagitan ng pagtawag sa [`shrink_to_fit`] sa isang walang laman na Vec, hindi ito maglalaan ng memorya.Katulad nito, kung nag-iimbak ka ng mga uri na walang sukat sa loob ng isang `Vec`, hindi ito maglalaan ng puwang para sa kanila.
/// *Tandaan na sa kasong ito ang `Vec` ay maaaring hindi mag-ulat ng [`capacity`] ng 0*.
/// `Vec` Maglalaan kung at lamang kung ang [`mem: : size_of::<T>`]`() * capacity()> 0`.
/// Sa pangkalahatan, `detalye allocation ni Vec` ay napakapino-kung balak mong maglaan ng memorya ng paggamit ng isang `Vec` at gamitin ito para sa isang bagay sino pa ang paririto (alinman upang pumasa sa mga hindi ligtas na code, o upang bumuo ng iyong sariling memory-back collection), tiyaking na deallocate ito memory sa pamamagitan ng paggamit `from_raw_parts` upang mabawi ang `Vec` at pagkatapos ay pag-drop ito.
///
/// Kung ang isang `Vec`*ay may* inilalaan na memorya, pagkatapos ang memorya na itinuro nito ay nasa tambak (tulad ng tinukoy ng tagapaglaan Rust ay naka-configure upang magamit bilang default), at ang punto ng pointer nito sa [`len`] na pinasimulan, magkakaugnay na mga elemento sa pagkakasunud-sunod (kung ano ang nais mong makita kung ikaw coerced ito sa isang slice), na sinusundan ng [`capacity`]`,`[`len`] lohikal na uninitialized, magkadikit na mga elemento.
///
///
/// Ang isang vector na naglalaman ng mga elemento `'a'` at `'b'` na may kapasidad 4 ay maaaring mailarawan sa ibaba.Ang tuktok na bahagi ay ang `Vec` struct, naglalaman ito ng isang pointer sa ulo ng paglalaan sa tumpok, haba at kapasidad.
/// Ang ibabang bahagi ay ang paglalaan sa tumpok, isang magkadikit na bloke ng memorya.
///
/// ```text
///             ptr      len  capacity
///        +--------+--------+--------+
///        | 0x0123 |      2 |      4 |
///        +--------+--------+--------+
///             |
///             v
/// Heap   +--------+--------+--------+--------+
///        |    'a' |    'b' | uninit | uninit |
///        +--------+--------+--------+--------+
/// ```
///
/// - **uninit** kumakatawan memory na hindi initialize, tingnan [`MaybeUninit`].
/// - Note: ang ABI ay hindi matatag at ang `Vec` ay walang ginagarantiyahan tungkol sa layout ng memorya nito (kasama ang pagkakasunud-sunod ng mga patlang).
///
/// `Vec` hindi kailanman magsagawa ng "small optimization" kung saan elemento ay talagang naka-imbak sa stack para sa dalawang mga kadahilanan:
///
/// * Mas pahihirapan para sa hindi ligtas na code na maayos na manipulahin ang isang `Vec`.Ang mga nilalaman ng isang `Vec` ay hindi magkakaroon ng isang matatag na address kung ito ay inilipat lamang, at magiging mas mahirap matukoy kung ang isang `Vec` ay talagang naglaan ng memorya.
///
/// * Parusahan nito ang pangkalahatang kaso, na nakakakuha ng isang karagdagang branch sa bawat pag-access.
///
/// `Vec` hindi kailanman awtomatikong magpapaliit, kahit na ganap na walang laman.Tinitiyak nito na hindi nangyayari ang mga hindi kinakailangang paglalaan o deallocation.Ang pag-alis ng isang `Vec` at pagkatapos ay pinupunan itong pabalik hanggang sa parehong [`len`] ay dapat na hindi magkaroon ng mga tawag sa tagapaglaan.Kung nais mong palayain ang hindi nagamit na memorya, gumamit ng [`shrink_to_fit`] o [`shrink_to`].
///
/// [`push`] at [`insert`] ay hindi kailanman (muling) maglalaan kung ang naiulat na kapasidad ay sapat.[`push`] at [`insert`]*ay*(re) magtalaga kung [`len`]`==`[`capacity`].Iyon ay, ang naiulat na kapasidad ay ganap na tumpak, at maaaring umasa.Maaari rin itong magamit upang manu-manong mapalaya ang memorya na inilalaan ng isang `Vec` kung ninanais.
/// Maramihang mga pamamaraan ng pagpapasok *maaaring* muling mag-redirect, kahit na hindi kinakailangan.
///
/// `Vec` ay hindi ginagarantiyahan ang anumang partikular na diskarte sa paglago kapag reallocating kapag puno, ni kapag tinawag ang [`reserve`].Ang kasalukuyang diskarte ay pangunahing at maaari itong patunayan na kanais-nais na gumamit ng isang hindi palaging factor ng paglago.Anumang diskarte na ginamit ay syempre garantiya *O*(1) amortized [`push`].
///
/// `vec![x; n]`, `vec![a, b, c, d]`, at [`Vec::with_capacity(n)`][`Vec::with_capacity`], ay ang lahat ng makabuo ng isang `Vec` na may eksakto ang hiniling na kapasidad.
/// Kung [`len`]`==`[`kapasidad`], (tulad ng kaso para sa [`vec!`] macro), kung gayon ang isang `Vec<T>` ay maaaring mai-convert sa at mula sa isang [`Box<[T]>`][owned slice] nang hindi muling kinalalagyan o ilipat ang mga elemento.
///
/// `Vec` hindi partikular na patungan ang anumang data na tinanggal mula rito, ngunit hindi rin ito partikular na mapangangalagaan.Nito uninitialized memory ay scratch space na maaari itong gamitin gayunpaman ito ay nais.Sa pangkalahatan ay gagawin lamang nito ang anumang pinakamabisa o kung hindi man madaling ipatupad.Huwag umasa sa tinanggal na data na mabubura para sa mga layuning pangseguridad.
/// Kahit na bumagsak ka ng isang `Vec`, ang buffer nito ay maaaring magamit lamang ng ibang `Vec`.
/// Kahit na una mong i-zero ang memorya ng isang `Vec`, maaaring hindi iyon aktwal na mangyari dahil hindi isinasaalang-alang ng optimizer na ito ay isang side-effects na dapat mapangalagaan.
/// Mayroong isang kaso na hindi namin masisira, gayunpaman: ang paggamit ng `unsafe` code upang sumulat sa labis na kapasidad, at pagkatapos ay taasan ang haba upang tumugma, ay palaging may bisa.
///
/// Sa kasalukuyan, hindi ginagarantiyahan ng `Vec` ang pagkakasunud-sunod kung saan ang mga elemento ay nahuhulog.
/// Ang order ay nagbago sa nakaraan at maaaring magbago muli.
///
/// [`get`]: ../../std/vec/struct.Vec.html#method.get
/// [`get_mut`]: ../../std/vec/struct.Vec.html#method.get_mut
/// [`String`]: crate::string::String
/// [`&str`]: type@str
/// [`shrink_to_fit`]: Vec::shrink_to_fit
/// [`shrink_to`]: Vec::shrink_to
/// [`capacity`]: Vec::capacity
/// [`mem::size_of::<T>`]: core::mem::size_of
/// [`len`]: Vec::len
/// [`push`]: Vec::push
/// [`insert`]: Vec::insert
/// [`reserve`]: Vec::reserve
/// [`MaybeUninit`]: core::mem::MaybeUninit
/// [owned slice]: Box
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "vec_type")]
pub struct Vec<T, #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global> {
    buf: RawVec<T, A>,
    len: usize,
}

////////////////////////////////////////////////////////////////////////////////
// Mahusay na pamamaraan
////////////////////////////////////////////////////////////////////////////////

impl<T> Vec<T> {
    /// Bumubuo ng bago, walang laman na `Vec<T>`.
    ///
    /// Ang vector ay hindi maglalaan hanggang sa ang mga elemento ay maitulak dito.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(unused_mut)]
    /// let mut vec: Vec<i32> = Vec::new();
    /// ```
    #[inline]
    #[rustc_const_stable(feature = "const_vec_new", since = "1.39.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> Self {
        Vec { buf: RawVec::NEW, len: 0 }
    }

    /// Bumubuo ng bago, walang laman na `Vec<T>` na may tinukoy na kapasidad.
    ///
    /// Ang vector ay maaaring hawakan nang eksaktong `capacity` na mga elemento nang hindi nag-relocalize.
    /// Kung ang `capacity` ay 0, ang vector ay hindi maglalaan.
    ///
    /// Mahalagang tandaan na bagaman ang naibalik na vector ay may tinukoy na *kapasidad*, ang vector ay magkakaroon ng isang zero *haba*.
    ///
    /// Para sa isang paliwanag sa pagkakaiba sa pagitan ng haba at kakayahan, tingnan ang *[Kapasidad at reallocation]*.
    ///
    /// [Capacity and reallocation]: #capacity-and-reallocation
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    ///
    /// // Ang vector ay naglalaman ng walang mga item, kahit na may kapasidad ito para sa higit pa
    /// assert_eq!(vec.len(), 0);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // Ang mga ito ay tapos na nang walang reallocating ...
    /// for i in 0..10 {
    ///     vec.push(i);
    /// }
    /// assert_eq!(vec.len(), 10);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // ... ngunit maaari itong gawin ang vector na reallocate
    /// vec.push(11);
    /// assert_eq!(vec.len(), 11);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    #[inline]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// Lumilikha ng isang `Vec<T>` nang direkta mula sa mga hilaw na bahagi ng isa pang vector.
    ///
    /// # Safety
    ///
    /// Ito ay lubos na hindi ligtas, dahil sa bilang ng mga invariant na hindi naka-check:
    ///
    /// * `ptr` kailangang naunang nailaan sa pamamagitan ng [`String`]/`Vec<T>"(kahit papaano, malamang na mali ito kung hindi).
    /// * `T` kailangang magkaroon ng parehong laki at pagkakahanay tulad ng kung saan inilaan ang `ptr`.
    ///   (Ang `T` pagkakaroon ng isang hindi gaanong mahigpit na pagkakahanay ay hindi sapat, ang pagkakahanay ay talagang kailangang pantay upang masiyahan ang kinakailangang [`dealloc`] na ang memorya ay dapat na ilaan at makitungo sa parehong layout.)
    ///
    /// * `length` kailangang mas mababa sa o katumbas ng `capacity`.
    /// * `capacity` kailangang maging kapasidad na inilaan ang pointer.
    ///
    /// Ang paglabag sa mga ito ay maaaring maging sanhi ng mga problema tulad ng pagwawasak sa panloob na mga istruktura ng data ng tagapaglaan.Halimbawa hindi ito ** ligtas na bumuo ng isang `Vec<u8>` mula sa isang pointer sa isang C `char` array na may haba na `size_t`.
    /// Hindi rin ligtas na bumuo ng isa mula sa isang `Vec<u16>` at ang haba nito, dahil nagmamalasakit ang tagapaghahati tungkol sa pagkakahanay, at ang dalawang uri na ito ay may magkakaibang pagkakahanay.
    /// Ang buffer ay inilalaan sa pagkakahanay 2 (para sa `u16`), ngunit pagkatapos na gawing `Vec<u8>` makikipag-deallocate ito sa pagkakahanay 1.
    ///
    /// Ang pagmamay-ari ng `ptr` ay mabisang inilipat sa `Vec<T>` na maaaring makipag-ugnay sa ibang pagkakataon, muling ilipat o baguhin ang mga nilalaman ng memorya na itinuro ng pointer ayon sa kalooban.
    /// Tiyaking walang ibang gumagamit ng pointer pagkatapos tawagan ang pagpapaandar na ito.
    ///
    /// [`String`]: crate::string::String
    /// [`dealloc`]: crate::alloc::GlobalAlloc::dealloc
    ///
    /// # Examples
    ///
    /// ```
    /// use std::ptr;
    /// use std::mem;
    ///
    /// let v = vec![1, 2, 3];
    ///
    ///     // FIXME I-update ito kapag na-stabilize ang vector_into_raw_parts.
    ///     // Pigilan ang pagpapatakbo ng destructor ng `v` upang makontrol natin ang paglalaan.
    /////
    /// let mut v = mem::ManuallyDrop::new(v);
    ///
    /// // Hilahin ang iba't ibang mahahalagang impormasyon tungkol sa `v`
    /// let p = v.as_mut_ptr();
    /// let len = v.len();
    /// let cap = v.capacity();
    ///
    /// unsafe {
    ///     // Overwrite memorya ng 4, 5, 6
    ///     for i in 0..len as isize {
    ///         ptr::write(p.offset(i), 4 + i);
    ///     }
    ///
    ///     // Ibalik ang lahat sa isang Vec
    ///     let rebuilt = Vec::from_raw_parts(p, len, cap);
    ///     assert_eq!(rebuilt, [4, 5, 6]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_raw_parts(ptr: *mut T, length: usize, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, length, capacity, Global) }
    }
}

impl<T, A: Allocator> Vec<T, A> {
    /// Bumubuo ng bago, walang laman na `Vec<T, A>`.
    ///
    /// Ang vector ay hindi maglalaan hanggang sa ang mga elemento ay maitulak dito.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// # #[allow(unused_mut)]
    /// let mut vec: Vec<i32, _> = Vec::new_in(System);
    /// ```
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub const fn new_in(alloc: A) -> Self {
        Vec { buf: RawVec::new_in(alloc), len: 0 }
    }

    /// Gumagawa ng bago, walang laman na `Vec<T, A>` na may tinukoy na kapasidad sa ibinigay na tagapaglaan.
    ///
    /// Ang vector ay maaaring hawakan nang eksaktong `capacity` na mga elemento nang hindi nag-relocalize.
    /// Kung ang `capacity` ay 0, ang vector ay hindi maglalaan.
    ///
    /// Mahalagang tandaan na bagaman ang naibalik na vector ay may tinukoy na *kapasidad*, ang vector ay magkakaroon ng isang zero *haba*.
    ///
    /// Para sa isang paliwanag sa pagkakaiba sa pagitan ng haba at kakayahan, tingnan ang *[Kapasidad at reallocation]*.
    ///
    /// [Capacity and reallocation]: #capacity-and-reallocation
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut vec = Vec::with_capacity_in(10, System);
    ///
    /// // Ang vector ay naglalaman ng walang mga item, kahit na may kapasidad ito para sa higit pa
    /// assert_eq!(vec.len(), 0);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // Ang mga ito ay tapos na nang walang reallocating ...
    /// for i in 0..10 {
    ///     vec.push(i);
    /// }
    /// assert_eq!(vec.len(), 10);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // ... ngunit maaari itong gawin ang vector na reallocate
    /// vec.push(11);
    /// assert_eq!(vec.len(), 11);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Vec { buf: RawVec::with_capacity_in(capacity, alloc), len: 0 }
    }

    /// Lumilikha ng isang `Vec<T, A>` nang direkta mula sa mga hilaw na bahagi ng isa pang vector.
    ///
    /// # Safety
    ///
    /// Ito ay lubos na hindi ligtas, dahil sa bilang ng mga invariant na hindi naka-check:
    ///
    /// * `ptr` kailangang naunang nailaan sa pamamagitan ng [`String`]/`Vec<T>"(kahit papaano, malamang na mali ito kung hindi).
    /// * `T` kailangang magkaroon ng parehong laki at pagkakahanay tulad ng kung saan inilaan ang `ptr`.
    ///   (Ang `T` pagkakaroon ng isang hindi gaanong mahigpit na pagkakahanay ay hindi sapat, ang pagkakahanay ay talagang kailangang pantay upang masiyahan ang kinakailangang [`dealloc`] na ang memorya ay dapat na ilaan at makitungo sa parehong layout.)
    ///
    /// * `length` kailangang mas mababa sa o katumbas ng `capacity`.
    /// * `capacity` kailangang maging kapasidad na inilaan ang pointer.
    ///
    /// Ang paglabag sa mga ito ay maaaring maging sanhi ng mga problema tulad ng pagwawasak sa panloob na mga istruktura ng data ng tagapaglaan.Halimbawa hindi ito ** ligtas na bumuo ng isang `Vec<u8>` mula sa isang pointer sa isang C `char` array na may haba na `size_t`.
    /// Hindi rin ligtas na bumuo ng isa mula sa isang `Vec<u16>` at ang haba nito, dahil nagmamalasakit ang tagapaghahati tungkol sa pagkakahanay, at ang dalawang uri na ito ay may magkakaibang pagkakahanay.
    /// Ang buffer ay inilalaan sa pagkakahanay 2 (para sa `u16`), ngunit pagkatapos na gawing `Vec<u8>` makikipag-deallocate ito sa pagkakahanay 1.
    ///
    /// Ang pagmamay-ari ng `ptr` ay mabisang inilipat sa `Vec<T>` na maaaring makipag-ugnay sa ibang pagkakataon, muling ilipat o baguhin ang mga nilalaman ng memorya na itinuro ng pointer ayon sa kalooban.
    /// Tiyaking walang ibang gumagamit ng pointer pagkatapos tawagan ang pagpapaandar na ito.
    ///
    /// [`String`]: crate::string::String
    /// [`dealloc`]: crate::alloc::GlobalAlloc::dealloc
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// use std::ptr;
    /// use std::mem;
    ///
    /// let mut v = Vec::with_capacity_in(3, System);
    /// v.push(1);
    /// v.push(2);
    /// v.push(3);
    ///
    ///     // FIXME I-update ito kapag na-stabilize ang vector_into_raw_parts.
    ///     // Pigilan ang pagpapatakbo ng destructor ng `v` upang makontrol natin ang paglalaan.
    /////
    /// let mut v = mem::ManuallyDrop::new(v);
    ///
    /// // Hilahin ang iba't ibang mahahalagang impormasyon tungkol sa `v`
    /// let p = v.as_mut_ptr();
    /// let len = v.len();
    /// let cap = v.capacity();
    /// let alloc = v.allocator();
    ///
    /// unsafe {
    ///     // Overwrite memorya ng 4, 5, 6
    ///     for i in 0..len as isize {
    ///         ptr::write(p.offset(i), 4 + i);
    ///     }
    ///
    ///     // Ibalik ang lahat sa isang Vec
    ///     let rebuilt = Vec::from_raw_parts_in(p, len, cap, alloc.clone());
    ///     assert_eq!(rebuilt, [4, 5, 6]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, length: usize, capacity: usize, alloc: A) -> Self {
        unsafe { Vec { buf: RawVec::from_raw_parts_in(ptr, capacity, alloc), len: length } }
    }

    /// Nabubulok ang isang `Vec<T>` sa mga hilaw na sangkap nito.
    ///
    /// Ibinabalik ang hilaw na pointer sa pinagbabatayan ng data, ang haba ng vector (sa mga elemento), at ang inilaan na kakayahan ng data (sa mga elemento).
    /// Ito ang magkatulad na mga argumento sa parehong pagkakasunud-sunod ng mga argumento sa [`from_raw_parts`].
    ///
    /// Matapos tawagan ang pagpapaandar na ito, ang tumatawag ay responsable para sa memorya na dating pinamamahalaan ng `Vec`.
    /// Ang tanging paraan upang magawa ito ay upang i-convert ang hilaw na pointer, haba, at kapasidad na bumalik sa isang `Vec` na may [`from_raw_parts`] function, na pinapayagan ang destructor na gawin ang paglilinis.
    ///
    ///
    /// [`from_raw_parts`]: Vec::from_raw_parts
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_into_raw_parts)]
    /// let v: Vec<i32> = vec![-1, 0, 1];
    ///
    /// let (ptr, len, cap) = v.into_raw_parts();
    ///
    /// let rebuilt = unsafe {
    ///     // Maaari na kaming gumawa ng mga pagbabago sa mga bahagi, tulad ng paglilipat ng raw pointer sa isang katugmang uri.
    /////
    ///     let ptr = ptr as *mut u32;
    ///
    ///     Vec::from_raw_parts(ptr, len, cap)
    /// };
    /// assert_eq!(rebuilt, [4294967295, 0, 1]);
    /// ```
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts(self) -> (*mut T, usize, usize) {
        let mut me = ManuallyDrop::new(self);
        (me.as_mut_ptr(), me.len(), me.capacity())
    }

    /// Nabubulok ang isang `Vec<T>` sa mga hilaw na sangkap nito.
    ///
    /// Ibinabalik ang hilaw na pointer sa pinagbabatayan ng data, ang haba ng vector (sa mga elemento), ang inilaan na kakayahan ng data (sa mga elemento), at ang tagapaglaan.
    /// Ito ang magkatulad na mga argumento sa parehong pagkakasunud-sunod ng mga argumento sa [`from_raw_parts_in`].
    ///
    /// Matapos tawagan ang pagpapaandar na ito, ang tumatawag ay responsable para sa memorya na dating pinamamahalaan ng `Vec`.
    /// Ang tanging paraan upang magawa ito ay upang i-convert ang hilaw na pointer, haba, at kapasidad na bumalik sa isang `Vec` na may [`from_raw_parts_in`] function, na pinapayagan ang destructor na gawin ang paglilinis.
    ///
    ///
    /// [`from_raw_parts_in`]: Vec::from_raw_parts_in
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, vec_into_raw_parts)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut v: Vec<i32, System> = Vec::new_in(System);
    /// v.push(-1);
    /// v.push(0);
    /// v.push(1);
    ///
    /// let (ptr, len, cap, alloc) = v.into_raw_parts_with_alloc();
    ///
    /// let rebuilt = unsafe {
    ///     // Maaari na kaming gumawa ng mga pagbabago sa mga bahagi, tulad ng paglilipat ng raw pointer sa isang katugmang uri.
    /////
    ///     let ptr = ptr as *mut u32;
    ///
    ///     Vec::from_raw_parts_in(ptr, len, cap, alloc)
    /// };
    /// assert_eq!(rebuilt, [4294967295, 0, 1]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts_with_alloc(self) -> (*mut T, usize, usize, A) {
        let mut me = ManuallyDrop::new(self);
        let len = me.len();
        let capacity = me.capacity();
        let ptr = me.as_mut_ptr();
        let alloc = unsafe { ptr::read(me.allocator()) };
        (ptr, len, capacity, alloc)
    }

    /// Ibinabalik ang bilang ng mga elemento na maaaring hawakan ng vector nang hindi nagre-reallocate.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let vec: Vec<i32> = Vec::with_capacity(10);
    /// assert_eq!(vec.capacity(), 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.buf.capacity()
    }

    /// Nakalaan ang kapasidad para sa hindi bababa sa `additional` higit pang mga elemento na maipasok sa ibinigay na `Vec<T>`.
    /// Ang koleksyon ay maaaring magreserba ng mas maraming puwang upang maiwasan ang madalas na mga reallocation.
    /// Matapos tumawag sa `reserve`, ang kapasidad ay magiging mas malaki sa o katumbas ng `self.len() + additional`.
    /// Walang ginagawa kung sapat na ang kapasidad.
    ///
    /// # Panics
    ///
    /// Panics kung ang bagong kapasidad ay lumampas sa `isize::MAX` bytes.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.reserve(10);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.buf.reserve(self.len, additional);
    }

    /// Inireserba ang minimum na kapasidad para sa eksaktong `additional` higit pang mga elemento na maipasok sa ibinigay na `Vec<T>`.
    ///
    /// Matapos tumawag sa `reserve_exact`, ang kapasidad ay magiging mas malaki sa o katumbas ng `self.len() + additional`.
    /// Walang ginagawa kung ang kapasidad ay sapat na.
    ///
    /// Tandaan na ang tagapagtalaga ay maaaring magbigay sa koleksyon ng mas maraming puwang kaysa sa hiniling nito.
    /// Samakatuwid, ang kakayahan ay hindi maaasahan na maging tiyak na minimal.
    /// Mas gusto ang `reserve` kung inaasahan ang mga pagpasok ng future.
    ///
    /// # Panics
    ///
    /// Panics kung ang bagong kapasidad ay umaapaw sa `usize`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.reserve_exact(10);
    /// assert!(vec.capacity() >= 11);
    /// ```
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.buf.reserve_exact(self.len, additional);
    }

    /// Sumusubok upang magreserba kapasidad para sa hindi bababa `additional` higit pang mga elemento na maaaring iipit sa mga ibinigay na `Vec<T>`.
    /// Ang koleksyon ay maaaring magreserba ng mas maraming puwang upang maiwasan ang madalas na mga reallocation.
    /// Matapos tumawag sa `try_reserve`, ang kapasidad ay magiging mas malaki sa o katumbas ng `self.len() + additional`.
    /// Walang ginagawa kung sapat na ang kapasidad.
    ///
    /// # Errors
    ///
    /// Kung umaapaw ang kapasidad, o nag-uulat ang tagapaglaan ng isang pagkabigo, pagkatapos ay may isang error na ibinalik.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &[u32]) -> Result<Vec<u32>, TryReserveError> {
    ///     let mut output = Vec::new();
    ///
    ///     // I-paunang reserba ang memorya, paglabas kung hindi namin magawa
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Ngayon alam namin na hindi ito maaaring OOM sa gitna ng aming kumplikadong gawain
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // sobrang kumplikado
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[doc(alias = "realloc")]
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.buf.try_reserve(self.len, additional)
    }

    /// Sumusubok upang magreserba ang minimum na kapasidad para sa eksaktong elemento `additional` na nakapasok sa ibinigay `Vec<T>`.
    /// Matapos tumawag sa `try_reserve_exact`, ang kapasidad ay magiging mas malaki sa o katumbas ng `self.len() + additional` kung ibabalik nito ang `Ok(())`.
    ///
    /// Walang ginagawa kung ang kapasidad ay sapat na.
    ///
    /// Tandaan na ang tagapagtalaga ay maaaring magbigay sa koleksyon ng mas maraming puwang kaysa sa hiniling nito.
    /// Samakatuwid, ang kakayahan ay hindi maaasahan na maging tiyak na minimal.
    /// Mas gusto ang `reserve` kung inaasahan ang mga pagpasok ng future.
    ///
    /// # Errors
    ///
    /// Kung umaapaw ang kapasidad, o nag-uulat ang tagapaglaan ng isang pagkabigo, pagkatapos ay may isang error na ibinalik.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &[u32]) -> Result<Vec<u32>, TryReserveError> {
    ///     let mut output = Vec::new();
    ///
    ///     // I-paunang reserba ang memorya, paglabas kung hindi namin magawa
    ///     output.try_reserve_exact(data.len())?;
    ///
    ///     // Ngayon alam namin na hindi ito maaaring OOM sa gitna ng aming kumplikadong gawain
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // sobrang kumplikado
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[doc(alias = "realloc")]
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.buf.try_reserve_exact(self.len, additional)
    }

    /// Paliitin ang kakayahan ng vector hangga't maaari.
    ///
    /// Babagsak ito nang mas malapit hangga't maaari sa haba ngunit maaaring ipagbigay-alam pa rin ng tagapaglaan sa vector na may puwang para sa ilang mga elemento pa.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    /// assert_eq!(vec.capacity(), 10);
    /// vec.shrink_to_fit();
    /// assert!(vec.capacity() >= 3);
    /// ```
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        // Ang kapasidad ay hindi kukulangin sa haba, at walang magagawa kapag pantay ang mga ito, kaya maiiwasan natin ang kaso na panic sa `RawVec::shrink_to_fit` sa pamamagitan lamang ng pagtawag dito sa isang mas malaking kapasidad.
        //
        //
        if self.capacity() > self.len {
            self.buf.shrink_to_fit(self.len);
        }
    }

    /// Pinapaliit ang kapasidad ng vector na may mas mababang gapos.
    ///
    /// Ang kapasidad ay mananatiling hindi bababa sa kasing laki ng parehong haba at ang ibinigay na halaga.
    ///
    ///
    /// Kung ang kasalukuyang kapasidad ay mas mababa sa mas mababang limitasyon, ito ay isang no-op.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    /// assert_eq!(vec.capacity(), 10);
    /// vec.shrink_to(4);
    /// assert!(vec.capacity() >= 4);
    /// vec.shrink_to(0);
    /// assert!(vec.capacity() >= 3);
    /// ```
    #[doc(alias = "realloc")]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        if self.capacity() > min_capacity {
            self.buf.shrink_to_fit(cmp::max(self.len, min_capacity));
        }
    }

    /// Binabago ang vector sa [`Box<[T]>`][owned slice].
    ///
    /// Tandaan na ito ay drop ang anumang labis na kapasidad.
    ///
    /// [owned slice]: Box
    ///
    /// # Examples
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    ///
    /// let slice = v.into_boxed_slice();
    /// ```
    ///
    /// Ang anumang labis na kapasidad ay tinanggal:
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    ///
    /// assert_eq!(vec.capacity(), 10);
    /// let slice = vec.into_boxed_slice();
    /// assert_eq!(slice.into_vec().capacity(), 3);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_boxed_slice(mut self) -> Box<[T], A> {
        unsafe {
            self.shrink_to_fit();
            let me = ManuallyDrop::new(self);
            let buf = ptr::read(&me.buf);
            let len = me.len();
            buf.into_box(len).assume_init()
        }
    }

    /// Paikliin ang vector, pinapanatili ang mga unang elemento ng `len` at hinuhulog ang natitira.
    ///
    /// Kung `len` ay mas malaki kaysa sa kasalukuyang haba ng vector, ito ay walang epekto.
    ///
    /// Maaaring gayahin ng [`drain`] na paraan ang `truncate`, ngunit sanhi na ibalik ang labis na mga elemento sa halip na bumagsak.
    ///
    ///
    /// Tandaan na ang pamamaraang ito ay walang epekto sa inilaan na kapasidad ng vector.
    ///
    /// # Examples
    ///
    /// Pinuputol ang isang limang elemento vector sa dalawang elemento:
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4, 5];
    /// vec.truncate(2);
    /// assert_eq!(vec, [1, 2]);
    /// ```
    ///
    /// Walang truncation na nangyayari kapag ang `len` ay mas malaki kaysa sa kasalukuyang haba ng vector:
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.truncate(8);
    /// assert_eq!(vec, [1, 2, 3]);
    /// ```
    ///
    /// Ang pagputol kapag ang `len == 0` ay katumbas ng pagtawag sa [`clear`] na pamamaraan.
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.truncate(0);
    /// assert_eq!(vec, []);
    /// ```
    ///
    /// [`clear`]: Vec::clear
    /// [`drain`]: Vec::drain
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn truncate(&mut self, len: usize) {
        // Ito ay ligtas dahil:
        //
        // * sa paghati naipasa sa `drop_in_place` ay may-bisa;ang `len > self.len` case ay iniiwasan ang paglikha ng isang hindi wastong hiwa, at
        // * ang `len` ng vector ay lumiliit bago tumawag sa `drop_in_place`, na tulad ng walang halaga ay mahuhulog nang dalawang beses sakaling ang `drop_in_place` ay sa panic isang beses (kung ito ay panics dalawang beses, ang programa ay nag-abort).
        //
        //
        //
        unsafe {
            // Note: Sinadya na ito ay `>` at hindi `>=`.
            //       Ang pagpapalit nito sa `>=` ay may mga negatibong implikasyon sa pagganap sa ilang mga kaso.
            //       Tingnan ang #78884 para sa higit pa.
            if len > self.len {
                return;
            }
            let remaining_len = self.len - len;
            let s = ptr::slice_from_raw_parts_mut(self.as_mut_ptr().add(len), remaining_len);
            self.len = len;
            ptr::drop_in_place(s);
        }
    }

    /// Kinukuha ang isang hiwa na naglalaman ng buong vector.
    ///
    /// Katumbas ng `&s[..]`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::io::{self, Write};
    /// let buffer = vec![1, 2, 3, 5, 8];
    /// io::sink().write(buffer.as_slice()).unwrap();
    /// ```
    #[inline]
    #[stable(feature = "vec_as_slice", since = "1.7.0")]
    pub fn as_slice(&self) -> &[T] {
        self
    }

    /// Kinukuha ang isang nababagabag na hiwa ng buong vector.
    ///
    /// Katumbas ng `&mut s[..]`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::io::{self, Read};
    /// let mut buffer = vec![0; 3];
    /// io::repeat(0b101).read_exact(buffer.as_mut_slice()).unwrap();
    /// ```
    #[inline]
    #[stable(feature = "vec_as_slice", since = "1.7.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        self
    }

    /// Nagbabalik ng isang hilaw na pointer sa buffer ng vector.
    ///
    /// tumatawag ay dapat na matiyak na ang vector outlives ang pointer function na ito babalik, o kung ito ay end up na tumuturo sa basura.
    /// Ang pagbabago ng vector ay maaaring maging sanhi ng muling pagkilala ng buffer nito, na gagawing hindi wasto ang anumang mga pahiwatig dito.
    ///
    /// Dapat ding tiyakin ng tumatawag na ang memorya na itinuro ng pointer (non-transitively) ay hindi kailanman nakasulat (maliban sa loob ng isang `UnsafeCell`) gamit ang pointer na ito o anumang pointer na nagmula rito.
    /// Kung kailangan mong i-mutate ang mga nilalaman ng hiwa, gamitin ang [`as_mut_ptr`].
    ///
    /// # Examples
    ///
    /// ```
    /// let x = vec![1, 2, 4];
    /// let x_ptr = x.as_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         assert_eq!(*x_ptr.add(i), 1 << i);
    ///     }
    /// }
    /// ```
    ///
    /// [`as_mut_ptr`]: Vec::as_mut_ptr
    ///
    ///
    ///
    #[stable(feature = "vec_as_ptr", since = "1.37.0")]
    #[inline]
    pub fn as_ptr(&self) -> *const T {
        // Napa-shade namin ang slice na pamamaraan ng parehong pangalan upang maiwasan ang pagdaan sa `deref`, na lumilikha ng isang intermediate na sanggunian.
        //
        let ptr = self.buf.ptr();
        unsafe {
            assume(!ptr.is_null());
        }
        ptr
    }

    /// Nagbabalik ng isang hindi ligtas na nababagabag na pointer sa buffer ng vector.
    ///
    /// tumatawag ay dapat na matiyak na ang vector outlives ang pointer function na ito babalik, o kung ito ay end up na tumuturo sa basura.
    ///
    /// Ang pagbabago ng vector ay maaaring maging sanhi ng muling pagkilala ng buffer nito, na gagawing hindi wasto ang anumang mga pahiwatig dito.
    ///
    /// # Examples
    ///
    /// ```
    /// // Maglaan ng vector sapat na malaki para sa 4 na mga elemento.
    /// let size = 4;
    /// let mut x: Vec<i32> = Vec::with_capacity(size);
    /// let x_ptr = x.as_mut_ptr();
    ///
    /// // Pinasimulan ang mga elemento sa pamamagitan ng mga panulat na hilaw na pointer, pagkatapos ay itakda ang haba.
    /// unsafe {
    ///     for i in 0..size {
    ///         *x_ptr.add(i) = i as i32;
    ///     }
    ///     x.set_len(size);
    /// }
    /// assert_eq!(&*x, &[0, 1, 2, 3]);
    /// ```
    ///
    #[stable(feature = "vec_as_ptr", since = "1.37.0")]
    #[inline]
    pub fn as_mut_ptr(&mut self) -> *mut T {
        // Napa-shade namin ang slice na pamamaraan ng parehong pangalan upang maiwasan ang pagdaan sa `deref_mut`, na lumilikha ng isang intermediate na sanggunian.
        //
        let ptr = self.buf.ptr();
        unsafe {
            assume(!ptr.is_null());
        }
        ptr
    }

    /// Nagbabalik ng isang sanggunian sa pinagbabatayan na tagapaglaan.
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn allocator(&self) -> &A {
        self.buf.allocator()
    }

    /// Pinipilit ang haba ng vector hanggang `new_len`.
    ///
    /// Ito ay isang operasyon na may mababang antas na nagpapanatili ng wala sa mga normal na invariant ng uri.
    /// Karaniwan na binabago ang haba ng isang vector ay tapos na gamit ang isa sa mga ligtas na operasyon sa halip, tulad ng [`truncate`], [`resize`], [`extend`], o [`clear`].
    ///
    ///
    /// [`truncate`]: Vec::truncate
    /// [`resize`]: Vec::resize
    /// [`extend`]: Extend::extend
    /// [`clear`]: Vec::clear
    ///
    /// # Safety
    ///
    /// - `new_len` dapat mas mababa sa o katumbas ng [`capacity()`].
    /// - Ang mga elemento sa `old_len..new_len` ay dapat na gawing pasiya.
    ///
    /// [`capacity()`]: Vec::capacity
    ///
    /// # Examples
    ///
    /// Ang pamamaraan na ito ay maaaring maging kapaki-pakinabang para sa mga sitwasyon kung saan ang vector ay nagsisilbi bilang isang buffer para sa iba pang code, lalo na sa paglipas ng FFI:
    ///
    /// ```no_run
    /// # #![allow(dead_code)]
    /// # // Ito ay isang maliit na balangkas lamang para sa halimbawa ng doc;
    /// # // huwag gamitin ito bilang isang panimulang punto para sa isang tunay na silid-aklatan.
    /// # pub struct StreamWrapper { strm: *mut std::ffi::c_void }
    /// # const Z_OK: i32 = 0;
    /// # extern "C" {
    /// #     fn deflateGetDictionary(
    /// #         strm: *mut std::ffi::c_void,
    /// #         dictionary: *mut u8,
    /// #         dictLength: *mut usize,
    /// #     ) -> i32;
    /// # }
    /// # impl StreamWrapper {
    /// pub fn get_dictionary(&self) -> Option<Vec<u8>> {
    ///     // Alinsunod sa mga dokumento ng pamamaraan ng FFI, "32768 bytes is always enough".
    ///     let mut dict = Vec::with_capacity(32_768);
    ///     let mut dict_length = 0;
    ///     // KALIGTASAN: Kapag ibinalik ng `deflateGetDictionary` ang `Z_OK`, hawak nito:
    ///     // 1. `dict_length` pinasimulan ang mga elemento.
    ///     // 2.
    ///     // `dict_length` <=ang kapasidad (32_768) na ginagawang ligtas ang `set_len` na tawagan.
    ///     unsafe {
    ///         // Tumawag sa FFI ...
    ///         let r = deflateGetDictionary(self.strm, dict.as_mut_ptr(), &mut dict_length);
    ///         if r == Z_OK {
    ///             // ... at i-update ang haba sa kung ano ang naisimulan.
    ///             dict.set_len(dict_length);
    ///             Some(dict)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    /// # }
    /// ```
    ///
    /// Habang ang sumusunod na halimbawa ay tunog, mayroong isang pagtagas sa memorya dahil ang panloob na vectors ay hindi napalaya bago ang tawag na `set_len`:
    ///
    /// ```
    /// let mut vec = vec![vec![1, 0, 0],
    ///                    vec![0, 1, 0],
    ///                    vec![0, 0, 1]];
    /// // SAFETY:
    /// // 1. `old_len..0` walang laman kaya walang mga elementong kailangang simulan.
    /// // 2. `0 <= capacity` laging may hawak kahit anong `capacity`.
    /// unsafe {
    ///     vec.set_len(0);
    /// }
    /// ```
    ///
    /// Karaniwan, dito, gagamitin ng isa ang [`clear`] sa halip upang mai-drop nang tama ang mga nilalaman at sa gayon ay hindi tumagas na memorya.
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn set_len(&mut self, new_len: usize) {
        debug_assert!(new_len <= self.capacity());

        self.len = new_len;
    }

    /// Tinatanggal ang isang elemento mula sa vector at ibinalik ito.
    ///
    /// Ang tinanggal na elemento ay pinalitan ng huling elemento ng vector.
    ///
    /// Hindi nito pinapanatili ang pag-order, ngunit O(1).
    ///
    /// # Panics
    ///
    /// Panics kung ang `index` ay wala sa mga hangganan.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec!["foo", "bar", "baz", "qux"];
    ///
    /// assert_eq!(v.swap_remove(1), "bar");
    /// assert_eq!(v, ["foo", "qux", "baz"]);
    ///
    /// assert_eq!(v.swap_remove(0), "foo");
    /// assert_eq!(v, ["baz", "qux"]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn swap_remove(&mut self, index: usize) -> T {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("swap_remove index (is {}) should be < len (is {})", index, len);
        }

        let len = self.len();
        if index >= len {
            assert_failed(index, len);
        }
        unsafe {
            // Pinalitan namin ang sarili [index] ng huling elemento.
            // Tandaan na kung ang mga hangganan ng tseke sa itaas ay magtagumpay dapat mayroong isang huling elemento (na maaaring sarili [index] mismo).
            //
            let last = ptr::read(self.as_ptr().add(len - 1));
            let hole = self.as_mut_ptr().add(index);
            self.set_len(len - 1);
            ptr::replace(hole, last)
        }
    }

    /// Nagpapasok ng isang elemento sa posisyon `index` sa loob ng vector, inililipat ang lahat ng mga elemento pagkatapos nito sa kanan.
    ///
    ///
    /// # Panics
    ///
    /// Panics kung `index > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.insert(1, 4);
    /// assert_eq!(vec, [1, 4, 2, 3]);
    /// vec.insert(4, 5);
    /// assert_eq!(vec, [1, 4, 2, 3, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn insert(&mut self, index: usize, element: T) {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("insertion index (is {}) should be <= len (is {})", index, len);
        }

        let len = self.len();
        if index > len {
            assert_failed(index, len);
        }

        // puwang para sa bagong elemento
        if len == self.buf.capacity() {
            self.reserve(1);
        }

        unsafe {
            // hindi nagkakamali Ang lugar upang ilagay ang bagong halaga
            //
            {
                let p = self.as_mut_ptr().add(index);
                // Ilipat ang lahat upang magkaroon ng puwang.
                // (Pagdoble ng elemento ng `index`th sa dalawang magkakasunod na lugar.)
                ptr::copy(p, p.offset(1), len - index);
                // Isulat ito sa, i-o-overtake ang unang kopya ng elemento ng `index`th.
                //
                ptr::write(p, element);
            }
            self.set_len(len + 1);
        }
    }

    /// Tinatanggal at nagbabalik ang elemento sa posisyon `index` loob ng vector, nagbabagong lahat ng mga elemento pagkatapos na ito sa kaliwa.
    ///
    ///
    /// # Panics
    ///
    /// Panics kung ang `index` ay wala sa mga hangganan.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// assert_eq!(v.remove(1), 2);
    /// assert_eq!(v, [1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, index: usize) -> T {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("removal index (is {}) should be < len (is {})", index, len);
        }

        let len = self.len();
        if index >= len {
            assert_failed(index, len);
        }
        unsafe {
            // infallible
            let ret;
            {
                // ang lugar na kinukuha namin.
                let ptr = self.as_mut_ptr().add(index);
                // kopyahin ito out, unsafely pagkakaroon ng isang kopya ng halaga sa stack at sa vector sa parehong oras.
                //
                ret = ptr::read(ptr);

                // Shift lahat pababa upang punan ang lugar na iyon.
                ptr::copy(ptr.offset(1), ptr, len - index - 1);
            }
            self.set_len(len - 1);
            ret
        }
    }

    /// Pinapanatili lamang ang mga elemento na tinukoy ng panaguri.
    ///
    /// Sa madaling salita, alisin ang lahat ng mga elemento `e` na tulad ng `f(&e)` ay nagbabalik ng `false`.
    /// Nagpapatakbo ang pamamaraang ito sa lugar, pagbisita sa bawat elemento nang eksakto isang beses sa orihinal na pagkakasunud-sunod, at pinapanatili ang pagkakasunud-sunod ng mga pinanatili na elemento.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4];
    /// vec.retain(|&x| x % 2 == 0);
    /// assert_eq!(vec, [2, 4]);
    /// ```
    ///
    /// Sapagkat ang mga elemento ay binibisita nang eksaktong isang beses sa orihinal na pagkakasunud-sunod, maaaring magamit ang panlabas na estado upang magpasya kung aling mga elemento ang dapat panatilihin.
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4, 5];
    /// let keep = [false, true, true, false, true];
    /// let mut iter = keep.iter();
    /// vec.retain(|_| *iter.next().unwrap());
    /// assert_eq!(vec, [2, 3, 5]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> bool,
    {
        let original_len = self.len();
        // Iwasan ang double drop kung ang drop guard ay hindi naisagawa, dahil maaari kaming gumawa ng ilang mga butas sa proseso.
        //
        unsafe { self.set_len(0) };

        // Vec: [Kept, Kept, Hole, Hole, Hole, Hole, Unchecked, Unchecked]
        //      | <-naproseso len-> |^-Susunod upang suriin
        //                  | <-tinanggal cnt-> |
        //      | <-orihinal_len-> |Itinago: Ang mga elemento na kung saan ang panaguri ay nagbabalik ng totoo.
        //
        // Hole: Inilipat o nahulog na puwang ng elemento.
        // Hindi na-check: Hindi na-check na mga wastong elemento.
        //
        // Ang drop guard na ito ay tatawagin kapag nag-panic ang predicate o `drop` ng elemento.
        // Inililipat nito ang mga hindi naka-check na elemento upang masakop ang mga butas at `set_len` sa tamang haba.
        // Sa mga kaso kung kailan ang panaguri at `drop` ay hindi kailanman nag-panick, ito ay ma-optimize.
        struct BackshiftOnDrop<'a, T, A: Allocator> {
            v: &'a mut Vec<T, A>,
            processed_len: usize,
            deleted_cnt: usize,
            original_len: usize,
        }

        impl<T, A: Allocator> Drop for BackshiftOnDrop<'_, T, A> {
            fn drop(&mut self) {
                if self.deleted_cnt > 0 {
                    // KALIGTASAN: Ang pag-trace ng mga hindi naka-check na item ay dapat na wasto dahil hindi namin sila hinawakan.
                    unsafe {
                        ptr::copy(
                            self.v.as_ptr().add(self.processed_len),
                            self.v.as_mut_ptr().add(self.processed_len - self.deleted_cnt),
                            self.original_len - self.processed_len,
                        );
                    }
                }
                // KALIGTASAN: Matapos mapunan ang mga butas, lahat ng mga item ay nasa magkadikit na memorya.
                unsafe {
                    self.v.set_len(self.original_len - self.deleted_cnt);
                }
            }
        }

        let mut g = BackshiftOnDrop { v: self, processed_len: 0, deleted_cnt: 0, original_len };

        while g.processed_len < original_len {
            // KALIGTASAN: Dapat na wasto ang hindi naka-check na elemento.
            let cur = unsafe { &mut *g.v.as_mut_ptr().add(g.processed_len) };
            if !f(cur) {
                // Maaga pa upang maiwasan ang dobleng pagbagsak kung nagpapanic ang `drop_in_place`.
                g.processed_len += 1;
                g.deleted_cnt += 1;
                // KALIGTASAN: Hindi na namin hinawakan muli ang elementong ito pagkatapos bumaba.
                unsafe { ptr::drop_in_place(cur) };
                // Na advance na namin ang counter.
                continue;
            }
            if g.deleted_cnt > 0 {
                // KALIGTASAN: `deleted_cnt`> 0, kaya't ang puwang ng butas ay hindi dapat mag-overlap sa kasalukuyang elemento.
                // Gumagamit kami ng kopya para ilipat, at hindi na muling hinahawakan ang sangkap na ito.
                unsafe {
                    let hole_slot = g.v.as_mut_ptr().add(g.processed_len - g.deleted_cnt);
                    ptr::copy_nonoverlapping(cur, hole_slot, 1);
                }
            }
            g.processed_len += 1;
        }

        // Lahat ng item ay naproseso.Maaari itong ma-optimize sa `set_len` ng LLVM.
        drop(g);
    }

    /// Tinatanggal ang lahat ngunit ang una sa magkakasunod na mga elemento sa vector na nalutas sa parehong key.
    ///
    ///
    /// Kung ang vector ay pinagsunod-sunod, aalisin nito ang lahat ng mga duplicate.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![10, 20, 21, 30, 20];
    ///
    /// vec.dedup_by_key(|i| *i / 10);
    ///
    /// assert_eq!(vec, [10, 20, 30, 20]);
    /// ```
    #[stable(feature = "dedup_by", since = "1.16.0")]
    #[inline]
    pub fn dedup_by_key<F, K>(&mut self, mut key: F)
    where
        F: FnMut(&mut T) -> K,
        K: PartialEq,
    {
        self.dedup_by(|a, b| key(a) == key(b))
    }

    /// Tinatanggal ang lahat ngunit ang una sa sunud-sunod na mga elemento sa vector nagbibigay-kasiyahan sa isang naibigay na pagkakapantay-pantay may kaugnayan.
    ///
    /// Ang pagpapaandar ng `same_bucket` ay ipinapasa mga sanggunian sa dalawang elemento mula sa vector at dapat matukoy kung ang mga elemento ay naghahambing pantay.
    /// Ang mga elemento ay ipinapasa sa kabaligtaran ng pagkakasunud-sunod mula sa kanilang pagkakasunud-sunod sa hiwa, kaya't kung ibalik ng `same_bucket(a, b)` ang `true`, ang `a` ay aalisin.
    ///
    ///
    /// Kung ang vector ay pinagsunod-sunod, aalisin nito ang lahat ng mga duplicate.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec!["foo", "bar", "Bar", "baz", "bar"];
    ///
    /// vec.dedup_by(|a, b| a.eq_ignore_ascii_case(b));
    ///
    /// assert_eq!(vec, ["foo", "bar", "baz", "bar"]);
    /// ```
    ///
    #[stable(feature = "dedup_by", since = "1.16.0")]
    pub fn dedup_by<F>(&mut self, mut same_bucket: F)
    where
        F: FnMut(&mut T, &mut T) -> bool,
    {
        let len = self.len();
        if len <= 1 {
            return;
        }

        /* INVARIANT: vec.len() > read >= write > write-1 >= 0 */
        struct FillGapOnDrop<'a, T, A: core::alloc::Allocator> {
            /* Offset of the element we want to check if it is duplicate */
            read: usize,

            /* Offset of the place where we want to place the non-duplicate
             * when we find it. */
            write: usize,

            /* The Vec that would need correction if `same_bucket` panicked */
            vec: &'a mut Vec<T, A>,
        }

        impl<'a, T, A: core::alloc::Allocator> Drop for FillGapOnDrop<'a, T, A> {
            fn drop(&mut self) {
                /* This code gets executed when `same_bucket` panics */

                /* SAFETY: invariant guarantees that `read - write`
                 * and `len - read` never overflow and that the copy is always
                 * in-bounds. */
                unsafe {
                    let ptr = self.vec.as_mut_ptr();
                    let len = self.vec.len();

                    /* How many items were left when `same_bucket` paniced.
                     * Basically vec[read..].len() */
                    let items_left = len.wrapping_sub(self.read);

                    /* Pointer to first item in vec[write..write+items_left] slice */
                    let dropped_ptr = ptr.add(self.write);
                    /* Pointer to first item in vec[read..] slice */
                    let valid_ptr = ptr.add(self.read);

                    /* Copy `vec[read..]` to `vec[write..write+items_left]`.
                     * The slices can overlap, so `copy_nonoverlapping` cannot be used */
                    ptr::copy(valid_ptr, dropped_ptr, items_left);

                    /* How many items have been already dropped
                     * Basically vec[read..write].len() */
                    let dropped = self.read.wrapping_sub(self.write);

                    self.vec.set_len(len - dropped);
                }
            }
        }

        let mut gap = FillGapOnDrop { read: 1, write: 1, vec: self };
        let ptr = gap.vec.as_mut_ptr();

        /* Drop items while going through Vec, it should be more efficient than
         * doing slice partition_dedup + truncate */

        /* SAFETY: Because of the invariant, read_ptr, prev_ptr and write_ptr
         * are always in-bounds and read_ptr never aliases prev_ptr */
        unsafe {
            while gap.read < len {
                let read_ptr = ptr.add(gap.read);
                let prev_ptr = ptr.add(gap.write.wrapping_sub(1));

                if same_bucket(&mut *read_ptr, &mut *prev_ptr) {
                    /* We have found duplicate, drop it in-place */
                    ptr::drop_in_place(read_ptr);
                } else {
                    let write_ptr = ptr.add(gap.write);

                    /* Because `read_ptr` can be equal to `write_ptr`, we either
                     * have to use `copy` or conditional `copy_nonoverlapping`.
                     * Looks like the first option is faster. */
                    ptr::copy(read_ptr, write_ptr, 1);

                    /* We have filled that place, so go further */
                    gap.write += 1;
                }

                gap.read += 1;
            }

            /* Technically we could let `gap` clean up with its Drop, but
             * when `same_bucket` is guaranteed to not panic, this bloats a little
             * the codegen, so we just do it manually */
            gap.vec.set_len(gap.write);
            mem::forget(gap);
        }
    }

    /// Nagdadagdag ng isang elemento sa likuran ng isang koleksyon.
    ///
    /// # Panics
    ///
    /// Panics kung ang bagong kapasidad ay lumampas sa `isize::MAX` bytes.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2];
    /// vec.push(3);
    /// assert_eq!(vec, [1, 2, 3]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, value: T) {
        // Ito ay panic o i-abort kung nais naming maglaan> isize::MAX bytes o kung ang haba increment nais pag-apaw ng zero-sized uri.
        //
        if self.len == self.buf.capacity() {
            self.reserve(1);
        }
        unsafe {
            let end = self.as_mut_ptr().add(self.len);
            ptr::write(end, value);
            self.len += 1;
        }
    }

    /// Tinatanggal ang huling elemento mula sa isang vector at ibinalik ito, o [`None`] kung ito ay walang laman.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// assert_eq!(vec.pop(), Some(3));
    /// assert_eq!(vec, [1, 2]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<T> {
        if self.len == 0 {
            None
        } else {
            unsafe {
                self.len -= 1;
                Some(ptr::read(self.as_ptr().add(self.len())))
            }
        }
    }

    /// Inililipat ang lahat ng mga elemento ng `other` sa `Self`, iniiwan ang `other` na walang laman.
    ///
    /// # Panics
    ///
    /// Panics kung ang bilang ng mga elemento sa vector ay umaapaw sa isang `usize`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// let mut vec2 = vec![4, 5, 6];
    /// vec.append(&mut vec2);
    /// assert_eq!(vec, [1, 2, 3, 4, 5, 6]);
    /// assert_eq!(vec2, []);
    /// ```
    #[inline]
    #[stable(feature = "append", since = "1.4.0")]
    pub fn append(&mut self, other: &mut Self) {
        unsafe {
            self.append_elements(other.as_slice() as _);
            other.set_len(0);
        }
    }

    /// Nagdadagdag ng mga elemento sa `Self` mula sa iba pang buffer.
    #[inline]
    unsafe fn append_elements(&mut self, other: *const [T]) {
        let count = unsafe { (*other).len() };
        self.reserve(count);
        let len = self.len();
        unsafe { ptr::copy_nonoverlapping(other as *const T, self.as_mut_ptr().add(len), count) };
        self.len += count;
    }

    /// Lumilikha ng draining iterator na nagtanggal ng tinukoy na saklaw sa vector at magbubunga inalis na item.
    ///
    /// Kapag ang iterator **ay** bumaba, ang lahat ng mga elemento sa saklaw ay aalisin mula sa vector, kahit na ang iterator ay hindi kumpletong natupok.
    /// Kung ang iterator **ay hindi** nahulog (kasama ang [`mem::forget`] halimbawa), hindi natukoy kung gaano karaming mga elemento ang tinanggal.
    ///
    /// # Panics
    ///
    /// Panics kung ang panimulang punto ay mas malaki kaysa sa end point o kung ang end point ay mas malaki kaysa sa haba ng vector.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// let u: Vec<_> = v.drain(1..).collect();
    /// assert_eq!(v, &[1]);
    /// assert_eq!(u, &[2, 3]);
    ///
    /// // Ang isang buong saklaw ay nililimas ang vector
    /// v.drain(..);
    /// assert_eq!(v, &[]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_, T, A>
    where
        R: RangeBounds<usize>,
    {
        // Kaligtasan sa memorya
        //
        // Kapag ang Drain ay unang nilikha, pinapababa nito ang haba ng pinagmulan ng vector upang matiyak na walang uninitialized o inilipat-mula sa mga elemento ang maa-access sa lahat kung ang destructor ng Drain ay hindi kailanman tumakbo.
        //
        //
        // Drain ay ptr::read ang mga halagang aalisin.
        // Kapag natapos, ang natitirang buntot ng mga vector ay makopya pabalik upang masakop ang butas, at ang haba ng vector ay naibalik sa bagong haba.
        //
        //
        //
        let len = self.len();
        let Range { start, end } = slice::range(range, ..len);

        unsafe {
            // set self.vec haba ay upang simulan, upang maging ligtas sa kaso Drain ay leaked
            self.set_len(start);
            // Gamitin ang panghihiram sa IterMut upang ipahiwatig ang pag-uugali ng paghiram ng buong Drain iterator (tulad ng &mut T).
            //
            let range_slice = slice::from_raw_parts_mut(self.as_mut_ptr().add(start), end - start);
            Drain {
                tail_start: end,
                tail_len: len - end,
                iter: range_slice.iter(),
                vec: NonNull::from(self),
            }
        }
    }

    /// Nililinis ang vector, inaalis ang lahat ng mga halaga.
    ///
    /// Tandaan na ang pamamaraang ito ay walang epekto sa inilaan na kapasidad ng vector.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    ///
    /// v.clear();
    ///
    /// assert!(v.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.truncate(0)
    }

    /// Ibinabalik ang bilang ng mga elemento sa vector, na tinukoy din bilang 'length' nito.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = vec![1, 2, 3];
    /// assert_eq!(a.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.len
    }

    /// Ibinabalik ang `true` kung ang vector ay naglalaman ng walang mga elemento.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = Vec::new();
    /// assert!(v.is_empty());
    ///
    /// v.push(1);
    /// assert!(!v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Hinahati ang koleksyon sa dalawa sa ibinigay na index.
    ///
    /// Nagbabalik ng isang bagong inilalaan na vector na naglalaman ng mga elemento sa saklaw na `[at, len)`.
    /// Matapos ang tawag, ang orihinal na vector ay maiiwan na naglalaman ng mga elemento `[0, at)` na may nakaraang kapasidad na hindi nabago.
    ///
    ///
    /// # Panics
    ///
    /// Panics kung `at > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// let vec2 = vec.split_off(1);
    /// assert_eq!(vec, [1]);
    /// assert_eq!(vec2, [2, 3]);
    /// ```
    #[inline]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    #[stable(feature = "split_off", since = "1.4.0")]
    pub fn split_off(&mut self, at: usize) -> Self
    where
        A: Clone,
    {
        #[cold]
        #[inline(never)]
        fn assert_failed(at: usize, len: usize) -> ! {
            panic!("`at` split index (is {}) should be <= len (is {})", at, len);
        }

        if at > self.len() {
            assert_failed(at, self.len());
        }

        if at == 0 {
            // maaaring makuha ng bagong vector ang orihinal na buffer at maiwasan ang kopya
            return mem::replace(
                self,
                Vec::with_capacity_in(self.capacity(), self.allocator().clone()),
            );
        }

        let other_len = self.len - at;
        let mut other = Vec::with_capacity_in(other_len, self.allocator().clone());

        // Maligtas na `set_len` at kopyahin ang mga item sa `other`.
        unsafe {
            self.set_len(at);
            other.set_len(other_len);

            ptr::copy_nonoverlapping(self.as_ptr().add(at), other.as_mut_ptr(), other.len());
        }
        other
    }

    /// Nagbabago ang laki ng `Vec` na lugar upang ang `len` ay katumbas ng `new_len`.
    ///
    /// Kung ang `new_len` ay mas malaki kaysa sa `len`, ang `Vec` ay pinalawig ng pagkakaiba, sa bawat karagdagang puwang na puno ng resulta ng pagtawag sa pagsasara na `f`.
    ///
    /// Ang mga halagang bumalik mula sa `f` ay magtatapos sa `Vec` sa pagkakasunud-sunod na nabuo.
    ///
    /// Kung ang `new_len` ay mas mababa sa `len`, ang `Vec` ay simpleng pinutol.
    ///
    /// Gumagamit ang pamamaraang ito ng pagsasara upang lumikha ng mga bagong halaga sa bawat pagtulak.Kung mas gugustuhin mong [`Clone`] ang isang naibigay na halaga, gamitin ang [`Vec::resize`].
    /// Kung nais mong gamitin ang [`Default`] trait upang makabuo ng mga halaga, maaari mong ipasa ang [`Default::default`] bilang pangalawang argument.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.resize_with(5, Default::default);
    /// assert_eq!(vec, [1, 2, 3, 0, 0]);
    ///
    /// let mut vec = vec![];
    /// let mut p = 1;
    /// vec.resize_with(4, || { p *= 2; p });
    /// assert_eq!(vec, [2, 4, 8, 16]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "vec_resize_with", since = "1.33.0")]
    pub fn resize_with<F>(&mut self, new_len: usize, f: F)
    where
        F: FnMut() -> T,
    {
        let len = self.len();
        if new_len > len {
            self.extend_with(new_len - len, ExtendFunc(f));
        } else {
            self.truncate(new_len);
        }
    }

    /// Naubos at nilalabas ang `Vec`, na nagbabalik ng isang nababagong sanggunian sa mga nilalaman, `&'a mut [T]`.
    /// Tandaan na ang uri na `T` ay dapat na mabuhay nang higit pa sa napiling `'a` habang buhay.
    /// Kung ang uri ay mayroon lamang static na mga sanggunian, o wala man, pagkatapos ito ay maaaring mapili na `'static`.
    ///
    /// Ang pagpapaandar na ito ay katulad ng pagpapaandar ng [`leak`][Box::leak] sa [`Box`] maliban na walang paraan upang mabawi ang na-leak na memorya.
    ///
    ///
    /// Pangunahing kapaki-pakinabang ang pagpapaandar na ito para sa data na nabubuhay para sa natitirang buhay ng programa.
    /// Ang pagbagsak ng ibinalik na sanggunian ay magdudulot ng isang butas sa memorya.
    ///
    /// # Examples
    ///
    /// Simpleng paggamit:
    ///
    /// ```
    /// let x = vec![1, 2, 3];
    /// let static_ref: &'static mut [usize] = x.leak();
    /// static_ref[0] += 1;
    /// assert_eq!(static_ref, &[2, 2, 3]);
    /// ```
    ///
    ///
    #[stable(feature = "vec_leak", since = "1.47.0")]
    #[inline]
    pub fn leak<'a>(self) -> &'a mut [T]
    where
        A: 'a,
    {
        Box::leak(self.into_boxed_slice())
    }

    /// Ibinabalik ang natitirang ekstrang kapasidad ng vector bilang isang slice ng `MaybeUninit<T>`.
    ///
    /// Ang naibalik na hiwa ay maaaring magamit upang punan ang vector ng data (hal
    /// sa pamamagitan ng pagbabasa mula sa isang file) bago markahan ang data bilang inisyal na gamit ang [`set_len`] na pamamaraan.
    ///
    ///
    /// [`set_len`]: Vec::set_len
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_spare_capacity, maybe_uninit_extra)]
    ///
    /// // Maglaan ng vector sapat na malaki para sa 10 elemento.
    /// let mut v = Vec::with_capacity(10);
    ///
    /// // Punan ang unang 3 elemento.
    /// let uninit = v.spare_capacity_mut();
    /// uninit[0].write(0);
    /// uninit[1].write(1);
    /// uninit[2].write(2);
    ///
    /// // Markahan ang unang 3 mga elemento ng vector bilang pinasimulan.
    /// unsafe {
    ///     v.set_len(3);
    /// }
    ///
    /// assert_eq!(&v, &[0, 1, 2]);
    /// ```
    ///
    #[unstable(feature = "vec_spare_capacity", issue = "75017")]
    #[inline]
    pub fn spare_capacity_mut(&mut self) -> &mut [MaybeUninit<T>] {
        // Note:
        // Ang pamamaraang ito ay hindi ipinatupad sa mga tuntunin ng `split_at_spare_mut`, upang maiwasan ang pag-aalis ng mga pointer sa buffer.
        //
        unsafe {
            slice::from_raw_parts_mut(
                self.as_mut_ptr().add(self.len) as *mut MaybeUninit<T>,
                self.buf.capacity() - self.len,
            )
        }
    }

    /// Ibinabalik ang nilalaman ng vector bilang isang slice ng `T`, kasama ang natitirang ekstrang kapasidad ng vector bilang isang slice ng `MaybeUninit<T>`.
    ///
    /// Ang naibalik na hiwa ng ekstrang kapasidad ay maaaring magamit upang punan ang vector ng data (hal. Sa pamamagitan ng pagbabasa mula sa isang file) bago markahan ang data bilang pinasimulan gamit ang [`set_len`] na pamamaraan.
    ///
    /// [`set_len`]: Vec::set_len
    ///
    /// Tandaan na ito ay isang mababang antas ng API, na dapat gamitin nang may pag-iingat para sa mga layunin sa pag-optimize.
    /// Kung kailangan mong idagdag ang data sa isang `Vec` maaari mong gamitin ang [`push`], [`extend`], [`extend_from_slice`], [`extend_from_within`], [`insert`], [`append`], [`resize`] o [`resize_with`], depende sa iyong eksaktong mga pangangailangan.
    ///
    ///
    /// [`push`]: Vec::push
    /// [`extend`]: Vec::extend
    /// [`extend_from_slice`]: Vec::extend_from_slice
    /// [`extend_from_within`]: Vec::extend_from_within
    /// [`insert`]: Vec::insert
    /// [`append`]: Vec::append
    /// [`resize`]: Vec::resize
    /// [`resize_with`]: Vec::resize_with
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_split_at_spare, maybe_uninit_extra)]
    ///
    /// let mut v = vec![1, 1, 2];
    ///
    /// // Magreserba ng karagdagang puwang na sapat na malaki para sa 10 elemento.
    /// v.reserve(10);
    ///
    /// let (init, uninit) = v.split_at_spare_mut();
    /// let sum = init.iter().copied().sum::<u32>();
    ///
    /// // Punan ang susunod na 4 na elemento.
    /// uninit[0].write(sum);
    /// uninit[1].write(sum * 2);
    /// uninit[2].write(sum * 3);
    /// uninit[3].write(sum * 4);
    ///
    /// // Markahan ang 4 na elemento ng vector bilang pinasimuno.
    /// unsafe {
    ///     let len = v.len();
    ///     v.set_len(len + 4);
    /// }
    ///
    /// assert_eq!(&v, &[1, 1, 2, 4, 8, 12, 16]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_split_at_spare", issue = "81944")]
    #[inline]
    pub fn split_at_spare_mut(&mut self) -> (&mut [T], &mut [MaybeUninit<T>]) {
        // SAFETY:
        // - Hindi pinapansin si len at kaya hindi na nagbago
        let (init, spare, _) = unsafe { self.split_at_spare_mut_with_len() };
        (init, spare)
    }

    /// Kaligtasan: ang pagbabago ng ibinalik na .2 (&mut usize) ay itinuturing na kapareho ng pagtawag sa `.set_len(_)`.
    ///
    /// Ang pamamaraang ito ay ginagamit upang magkaroon ng natatanging pag-access sa lahat ng mga bahagi ng vector nang sabay-sabay sa `extend_from_within`.
    unsafe fn split_at_spare_mut_with_len(
        &mut self,
    ) -> (&mut [T], &mut [MaybeUninit<T>], &mut usize) {
        let Range { start: ptr, end: spare_ptr } = self.as_mut_ptr_range();
        let spare_ptr = spare_ptr.cast::<MaybeUninit<T>>();
        let spare_len = self.buf.capacity() - self.len;

        // SAFETY:
        // - `ptr` garantisadong wasto para sa mga elemento ng `len`
        // - `spare_ptr` ay tumuturo sa isang elemento nakaraan ang buffer, kaya't hindi ito nagsasapawan sa `initialized`
        unsafe {
            let initialized = slice::from_raw_parts_mut(ptr, self.len);
            let spare = slice::from_raw_parts_mut(spare_ptr, spare_len);

            (initialized, spare, &mut self.len)
        }
    }
}

impl<T: Clone, A: Allocator> Vec<T, A> {
    /// Nagbabago ang laki ng `Vec` na lugar upang ang `len` ay katumbas ng `new_len`.
    ///
    /// Kung ang `new_len` ay mas malaki kaysa sa `len`, ang `Vec` ay pinalawig ng pagkakaiba, sa bawat karagdagang puwang na puno ng `value`.
    ///
    /// Kung ang `new_len` ay mas mababa sa `len`, ang `Vec` ay simpleng pinutol.
    ///
    /// Ang pamamaraang ito ay nangangailangan ng `T` upang ipatupad ang [`Clone`], upang ma-clone ang naipasa na halaga.
    /// Kung kailangan mo ng higit na kakayahang umangkop (o nais na umasa sa [`Default`] sa halip na [`Clone`]), gamitin ang [`Vec::resize_with`].
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec!["hello"];
    /// vec.resize(3, "world");
    /// assert_eq!(vec, ["hello", "world", "world"]);
    ///
    /// let mut vec = vec![1, 2, 3, 4];
    /// vec.resize(2, 0);
    /// assert_eq!(vec, [1, 2]);
    /// ```
    ///
    ///
    #[stable(feature = "vec_resize", since = "1.5.0")]
    pub fn resize(&mut self, new_len: usize, value: T) {
        let len = self.len();

        if new_len > len {
            self.extend_with(new_len - len, ExtendElement(value))
        } else {
            self.truncate(new_len);
        }
    }

    /// I-clone at idinaragdag ang lahat ng mga elemento sa isang slice sa `Vec`.
    ///
    /// Iterates sa hiwa `other`, i-clone ang bawat elemento, at pagkatapos ay idinaragdag ito sa `Vec` na ito.
    /// Ang `other` vector ay binagtas na in-order.
    ///
    /// Tandaan na ang pagpapaandar na ito ay kapareho ng [`extend`] maliban sa dalubhasa na gumana sa halip ng mga hiwa.
    ///
    /// Kung at kailan nakakuha ng pagdadalubhasa ang Rust ang pagpapaandar na ito ay malamang na hindi na magamit (ngunit magagamit pa rin).
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.extend_from_slice(&[2, 3, 4]);
    /// assert_eq!(vec, [1, 2, 3, 4]);
    /// ```
    ///
    /// [`extend`]: Vec::extend
    ///
    #[stable(feature = "vec_extend_from_slice", since = "1.6.0")]
    pub fn extend_from_slice(&mut self, other: &[T]) {
        self.spec_extend(other.iter())
    }

    /// Kinokopya ang mga elemento mula sa saklaw ng `src` hanggang sa dulo ng vector.
    ///
    /// ## Examples
    ///
    /// ```
    /// #![feature(vec_extend_from_within)]
    ///
    /// let mut vec = vec![0, 1, 2, 3, 4];
    ///
    /// vec.extend_from_within(2..);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4]);
    ///
    /// vec.extend_from_within(..2);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4, 0, 1]);
    ///
    /// vec.extend_from_within(4..8);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4, 0, 1, 4, 2, 3, 4]);
    /// ```
    #[unstable(feature = "vec_extend_from_within", issue = "81656")]
    pub fn extend_from_within<R>(&mut self, src: R)
    where
        R: RangeBounds<usize>,
    {
        let range = slice::range(src, ..self.len());
        self.reserve(range.len());

        // SAFETY:
        // - `slice::range` ginagarantiyahan na ang ibinigay na saklaw ay wasto para sa pag-index ng sarili
        unsafe {
            self.spec_extend_from_within(range);
        }
    }
}

// Ang code na ito ay naglalahat ng `extend_with_{element,default}`.
trait ExtendWith<T> {
    fn next(&mut self) -> T;
    fn last(self) -> T;
}

struct ExtendElement<T>(T);
impl<T: Clone> ExtendWith<T> for ExtendElement<T> {
    fn next(&mut self) -> T {
        self.0.clone()
    }
    fn last(self) -> T {
        self.0
    }
}

struct ExtendDefault;
impl<T: Default> ExtendWith<T> for ExtendDefault {
    fn next(&mut self) -> T {
        Default::default()
    }
    fn last(self) -> T {
        Default::default()
    }
}

struct ExtendFunc<F>(F);
impl<T, F: FnMut() -> T> ExtendWith<T> for ExtendFunc<F> {
    fn next(&mut self) -> T {
        (self.0)()
    }
    fn last(mut self) -> T {
        (self.0)()
    }
}

impl<T, A: Allocator> Vec<T, A> {
    /// Palawakin ang mga halagang vector ng `n`, gamit ang ibinigay na generator.
    fn extend_with<E: ExtendWith<T>>(&mut self, n: usize, mut value: E) {
        self.reserve(n);

        unsafe {
            let mut ptr = self.as_mut_ptr().add(self.len());
            // Gumamit ng SetLenOnDrop upang gumana sa paligid ng bug kung saan maaaring hindi mapagtanto ng tagatala ang tindahan sa pamamagitan ng `ptr` hanggang self.set_len() huwag mag-alias.
            //
            //
            let mut local_len = SetLenOnDrop::new(&mut self.len);

            // Isulat ang lahat ng mga elemento maliban sa huling
            for _ in 1..n {
                ptr::write(ptr, value.next());
                ptr = ptr.offset(1);
                // Dagdagan ang haba sa bawat hakbang kung sakaling next() panics
                local_len.increment_len(1);
            }

            if n > 0 {
                // Maaari naming isulat ang huling elemento nang direkta nang walang cloning nang hindi kinakailangan
                ptr::write(ptr, value.last());
                local_len.increment_len(1);
            }

            // len itinakda ng sakop ng saklaw
        }
    }
}

impl<T: PartialEq, A: Allocator> Vec<T, A> {
    /// Tinatanggal ang magkakasunod na paulit-ulit na mga elemento sa vector ayon sa pagpapatupad ng [`PartialEq`] trait.
    ///
    ///
    /// Kung ang vector ay pinagsunod-sunod, aalisin nito ang lahat ng mga duplicate.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 2, 3, 2];
    ///
    /// vec.dedup();
    ///
    /// assert_eq!(vec, [1, 2, 3, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn dedup(&mut self) {
        self.dedup_by(|a, b| a == b)
    }
}

////////////////////////////////////////////////////////////////////////////////
// Panloob na pamamaraan at pag-andar
////////////////////////////////////////////////////////////////////////////////

#[doc(hidden)]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_elem<T: Clone>(elem: T, n: usize) -> Vec<T> {
    <T as SpecFromElem>::from_elem(elem, n, Global)
}

#[doc(hidden)]
#[unstable(feature = "allocator_api", issue = "32838")]
pub fn from_elem_in<T: Clone, A: Allocator>(elem: T, n: usize, alloc: A) -> Vec<T, A> {
    <T as SpecFromElem>::from_elem(elem, n, alloc)
}

trait ExtendFromWithinSpec {
    /// # Safety
    ///
    /// - `src` kailangang wastong index
    /// - `self.capacity() - self.len()` dapat `>= src.len()`
    unsafe fn spec_extend_from_within(&mut self, src: Range<usize>);
}

impl<T: Clone, A: Allocator> ExtendFromWithinSpec for Vec<T, A> {
    default unsafe fn spec_extend_from_within(&mut self, src: Range<usize>) {
        // SAFETY:
        // - ang len ay nadagdagan lamang pagkatapos ng pagsisimula ng mga elemento
        let (this, spare, len) = unsafe { self.split_at_spare_mut_with_len() };

        // SAFETY:
        // - tinitiyak ng tumatawag na ang src ay isang wastong index
        let to_clone = unsafe { this.get_unchecked(src) };

        to_clone
            .iter()
            .cloned()
            .zip(spare.iter_mut())
            .map(|(src, dst)| dst.write(src))
            // Note:
            // - Na-initialize lang ang Element sa `MaybeUninit::write`, kaya't ok na dagdagan ang len
            // - Ang len ay nadagdagan pagkatapos ng bawat elemento upang maiwasan ang paglabas (tingnan ang isyu #82533)
            .for_each(|_| *len += 1);
    }
}

impl<T: Copy, A: Allocator> ExtendFromWithinSpec for Vec<T, A> {
    unsafe fn spec_extend_from_within(&mut self, src: Range<usize>) {
        let count = src.len();
        {
            let (init, spare) = self.split_at_spare_mut();

            // SAFETY:
            // - tinitiyak ng tumatawag na ang `src` ay isang wastong index
            let source = unsafe { init.get_unchecked(src) };

            // SAFETY:
            // - Ang parehong mga payo ay nilikha mula sa natatanging mga sangguniang hiwa (`&mut [_]`) kaya't ang mga ito ay wasto at hindi nagsasapawan.
            //
            // - Ang mga elemento ay: Kopyahin kaya OK lang na kopyahin ang mga ito, nang hindi gumagawa ng anumang bagay sa mga orihinal na halaga
            // - `count` ay katumbas ng len ng `source`, kaya't ang pinagmulan ay wasto para sa `count` na nagbabasa
            // - `.reserve(count)` ginagarantiyahan na ang `spare.len() >= count` kaya ekstrang ay wasto para sa `count` magsusulat
            //
            //
            //
            unsafe { ptr::copy_nonoverlapping(source.as_ptr(), spare.as_mut_ptr() as _, count) };
        }

        // SAFETY:
        // - Ang mga elemento ay naisugod lamang ng `copy_nonoverlapping`
        self.len += count;
    }
}

////////////////////////////////////////////////////////////////////////////////
// Mga karaniwang pagpapatupad ng trait para sa Vec
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> ops::Deref for Vec<T, A> {
    type Target = [T];

    fn deref(&self) -> &[T] {
        unsafe { slice::from_raw_parts(self.as_ptr(), self.len) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> ops::DerefMut for Vec<T, A> {
    fn deref_mut(&mut self) -> &mut [T] {
        unsafe { slice::from_raw_parts_mut(self.as_mut_ptr(), self.len) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone, A: Allocator + Clone> Clone for Vec<T, A> {
    #[cfg(not(test))]
    fn clone(&self) -> Self {
        let alloc = self.allocator().clone();
        <[T]>::to_vec_in(&**self, alloc)
    }

    // HACK(japaric): na may cfg(test) ang taglay na `[T]::to_vec` na pamamaraan, na kinakailangan para sa kahulugan ng pamamaraang ito, ay hindi magagamit.
    // Sa halip gamitin ang `slice::to_vec` function na magagamit lamang sa cfg(test) NB tingnan ang slice::hack module sa slice.rs para sa karagdagang impormasyon
    //
    //
    #[cfg(test)]
    fn clone(&self) -> Self {
        let alloc = self.allocator().clone();
        crate::slice::to_vec(&**self, alloc)
    }

    fn clone_from(&mut self, other: &Self) {
        // i-drop ang anumang bagay na hindi mai-o-overtake
        self.truncate(other.len());

        // self.len <= other.len dahil sa ang truncate sa itaas, kaya ang hiwa narito ang laging in-hangganan.
        //
        let (init, tail) = other.split_at(self.len());

        // muling gamitin ang mga nakapaloob na halagang allocations/resources.
        self.clone_from_slice(init);
        self.extend_from_slice(tail);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Hash, A: Allocator> Hash for Vec<T, A> {
    #[inline]
    fn hash<H: Hasher>(&self, state: &mut H) {
        Hash::hash(&**self, state)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "vector indices are of type `usize` or ranges of `usize`",
    label = "vector indices are of type `usize` or ranges of `usize`"
)]
impl<T, I: SliceIndex<[T]>, A: Allocator> Index<I> for Vec<T, A> {
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &Self::Output {
        Index::index(&**self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "vector indices are of type `usize` or ranges of `usize`",
    label = "vector indices are of type `usize` or ranges of `usize`"
)]
impl<T, I: SliceIndex<[T]>, A: Allocator> IndexMut<I> for Vec<T, A> {
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut Self::Output {
        IndexMut::index_mut(&mut **self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> FromIterator<T> for Vec<T> {
    #[inline]
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> Vec<T> {
        <Self as SpecFromIter<T, I::IntoIter>>::from_iter(iter.into_iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> IntoIterator for Vec<T, A> {
    type Item = T;
    type IntoIter = IntoIter<T, A>;

    /// Lumilikha ng isang umuulit na iterator, iyon ay, isa na gumagalaw sa bawat halaga mula sa vector (mula simula hanggang dulo).
    /// Hindi magamit ang vector matapos itong tawagan.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = vec!["a".to_string(), "b".to_string()];
    /// for s in v.into_iter() {
    ///     // ang may uri na String, hindi &String
    ///     println!("{}", s);
    /// }
    /// ```
    ///
    #[inline]
    fn into_iter(self) -> IntoIter<T, A> {
        unsafe {
            let mut me = ManuallyDrop::new(self);
            let alloc = ptr::read(me.allocator());
            let begin = me.as_mut_ptr();
            let end = if mem::size_of::<T>() == 0 {
                arith_offset(begin as *const i8, me.len() as isize) as *const T
            } else {
                begin.add(me.len()) as *const T
            };
            let cap = me.buf.capacity();
            IntoIter {
                buf: NonNull::new_unchecked(begin),
                phantom: PhantomData,
                cap,
                alloc,
                ptr: begin,
                end,
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, A: Allocator> IntoIterator for &'a Vec<T, A> {
    type Item = &'a T;
    type IntoIter = slice::Iter<'a, T>;

    fn into_iter(self) -> slice::Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, A: Allocator> IntoIterator for &'a mut Vec<T, A> {
    type Item = &'a mut T;
    type IntoIter = slice::IterMut<'a, T>;

    fn into_iter(self) -> slice::IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> Extend<T> for Vec<T, A> {
    #[inline]
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        <Self as SpecExtend<T, I::IntoIter>>::spec_extend(self, iter.into_iter())
    }

    #[inline]
    fn extend_one(&mut self, item: T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

impl<T, A: Allocator> Vec<T, A> {
    // paraan ng dahon kung saan ang iba't ibang mga pagpapatupad ng SpecFrom/SpecExtend ay nagtalaga kung wala silang karagdagang mga pag-optimize upang mailapat
    //
    fn extend_desugared<I: Iterator<Item = T>>(&mut self, mut iterator: I) {
        // Ito ang kaso para sa isang pangkalahatang umuulit.
        //
        // Ang pagpapaandar na ito ay dapat na katumbas sa moral ng:
        //
        //      para sa item sa iterator {
        //          self.push(item);
        //      }
        while let Some(element) = iterator.next() {
            let len = self.len();
            if len == self.capacity() {
                let (lower, _) = iterator.size_hint();
                self.reserve(lower.saturating_add(1));
            }
            unsafe {
                ptr::write(self.as_mut_ptr().add(len), element);
                // Ang NB ay hindi maaaring mag-overflow dahil kakailanganin naming ilaan ang space space
                self.set_len(len + 1);
            }
        }
    }

    /// Lumilikha ng isang splicing iterator na pumapalit sa tinukoy na saklaw sa vector ng ibinigay na `replace_with` iterator at nagbubunga ng mga inalis na item.
    ///
    /// `replace_with` ay hindi kailangang maging parehong haba ng `range`.
    ///
    /// `range` ay tinanggal kahit na ang iterator ay hindi natupok hanggang sa katapusan.
    ///
    /// Hindi natukoy kung gaano karaming mga elemento ang aalisin mula sa vector kung ang le `Splice` na halaga ay naipalabas.
    ///
    /// Ang input iterator `replace_with` ay natupok lamang kapag ang halaga ng `Splice` ay nahulog.
    ///
    /// Ito ay pinakamainam kung:
    ///
    /// * Ang buntot (mga elemento sa vector matapos `range`) ay walang laman,
    /// * o `replace_with` ay magbubunga ng mas kaunti o pantay na mga elemento kaysa sa haba ng 'saklaw`
    /// * o ang mas mababang gapos ng `size_hint()` nito ay eksaktong.
    ///
    /// Kung hindi man, ang isang pansamantalang vector ay inilalaan at ang buntot ay inilipat ng dalawang beses.
    ///
    /// # Panics
    ///
    /// Panics kung ang panimulang punto ay mas malaki kaysa sa end point o kung ang end point ay mas malaki kaysa sa haba ng vector.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// let new = [7, 8];
    /// let u: Vec<_> = v.splice(..2, new.iter().cloned()).collect();
    /// assert_eq!(v, &[7, 8, 3]);
    /// assert_eq!(u, &[1, 2]);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "vec_splice", since = "1.21.0")]
    pub fn splice<R, I>(&mut self, range: R, replace_with: I) -> Splice<'_, I::IntoIter, A>
    where
        R: RangeBounds<usize>,
        I: IntoIterator<Item = T>,
    {
        Splice { drain: self.drain(range), replace_with: replace_with.into_iter() }
    }

    /// Lumilikha ng isang umuulit na gumagamit ng isang pagsasara upang matukoy kung ang isang elemento ay dapat na alisin.
    ///
    /// Kung ang pagsasara ay bumalik na totoo, pagkatapos ang elemento ay aalisin at ibigay.
    /// Kung ang pagsasara ay bumalik na hindi totoo, ang elemento ay mananatili sa vector at hindi maihahatid ng iterator.
    ///
    /// Ang paggamit ng pamamaraang ito ay katumbas ng sumusunod na code:
    ///
    /// ```
    /// # let some_predicate = |x: &mut i32| { *x == 2 || *x == 3 || *x == 6 };
    /// # let mut vec = vec![1, 2, 3, 4, 5, 6];
    /// let mut i = 0;
    /// while i != vec.len() {
    ///     if some_predicate(&mut vec[i]) {
    ///         let val = vec.remove(i);
    ///         // ang iyong code dito
    ///     } else {
    ///         i += 1;
    ///     }
    /// }
    ///
    /// # assert_eq!(vec, vec![1, 4, 5]);
    /// ```
    ///
    /// Ngunit ang `drain_filter` ay mas madaling gamitin.
    /// `drain_filter` mas mahusay din, sapagkat maaari nitong i-backshift ang mga elemento ng array nang maramihan.
    ///
    /// Tandaan na hinahayaan ka rin ng `drain_filter` na mutate ang bawat elemento sa pagsasara ng filter, hindi alintana kung pipiliin mong panatilihin o alisin ito.
    ///
    ///
    /// # Examples
    ///
    /// Paghati ng isang array sa pantay at logro, muling paggamit ng orihinal na paglalaan:
    ///
    /// ```
    /// #![feature(drain_filter)]
    /// let mut numbers = vec![1, 2, 3, 4, 5, 6, 8, 9, 11, 13, 14, 15];
    ///
    /// let evens = numbers.drain_filter(|x| *x % 2 == 0).collect::<Vec<_>>();
    /// let odds = numbers;
    ///
    /// assert_eq!(evens, vec![2, 4, 6, 8, 14]);
    /// assert_eq!(odds, vec![1, 3, 5, 9, 11, 13, 15]);
    /// ```
    ///
    #[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
    pub fn drain_filter<F>(&mut self, filter: F) -> DrainFilter<'_, T, F, A>
    where
        F: FnMut(&mut T) -> bool,
    {
        let old_len = self.len();

        // Guard laban sa amin na maging leak (leak amplification)
        unsafe {
            self.set_len(0);
        }

        DrainFilter { vec: self, idx: 0, del: 0, old_len, pred: filter, panic_flag: false }
    }
}

/// Palawakin ang pagpapatupad na kumopya ng mga elemento sa labas ng mga sanggunian bago itulak ang mga ito sa Vec.
///
/// Ang pagpapatupad na ito ay dalubhasa para sa mga slice iterator, kung saan gumagamit ito ng [`copy_from_slice`] upang idugtong ang buong hiwa nang sabay-sabay.
///
///
/// [`copy_from_slice`]: slice::copy_from_slice
#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: Copy + 'a, A: Allocator + 'a> Extend<&'a T> for Vec<T, A> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.spec_extend(iter.into_iter())
    }

    #[inline]
    fn extend_one(&mut self, &item: &'a T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

/// Nagpapatupad ng paghahambing ng vectors, [lexicographically](core::cmp::Ord#lexicographical-comparison).
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialOrd, A: Allocator> PartialOrd for Vec<T, A> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        PartialOrd::partial_cmp(&**self, &**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Eq, A: Allocator> Eq for Vec<T, A> {}

/// Nagpapatupad ng pag-order ng vectors, [lexicographically](core::cmp::Ord#lexicographical-comparison).
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord, A: Allocator> Ord for Vec<T, A> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        Ord::cmp(&**self, &**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T, A: Allocator> Drop for Vec<T, A> {
    fn drop(&mut self) {
        unsafe {
            // paggamit drop para [T] gumamit ng isang raw slice upang tukuyin ang mga elemento ng vector bilang pinakamahinang mga kinakailangang uri;
            //
            // maaaring maiwasan ang mga katanungan ng bisa sa ilang mga kaso
            ptr::drop_in_place(ptr::slice_from_raw_parts_mut(self.as_mut_ptr(), self.len))
        }
        // Hinahawakan ng RawVec ang paglipat ng transaksyon
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for Vec<T> {
    /// Lumilikha ng isang walang laman na `Vec<T>`.
    fn default() -> Vec<T> {
        Vec::new()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug, A: Allocator> fmt::Debug for Vec<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> AsRef<Vec<T, A>> for Vec<T, A> {
    fn as_ref(&self) -> &Vec<T, A> {
        self
    }
}

#[stable(feature = "vec_as_mut", since = "1.5.0")]
impl<T, A: Allocator> AsMut<Vec<T, A>> for Vec<T, A> {
    fn as_mut(&mut self) -> &mut Vec<T, A> {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> AsRef<[T]> for Vec<T, A> {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "vec_as_mut", since = "1.5.0")]
impl<T, A: Allocator> AsMut<[T]> for Vec<T, A> {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> From<&[T]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: &[T]) -> Vec<T> {
        s.to_vec()
    }
    #[cfg(test)]
    fn from(s: &[T]) -> Vec<T> {
        crate::slice::to_vec(s, Global)
    }
}

#[stable(feature = "vec_from_mut", since = "1.19.0")]
impl<T: Clone> From<&mut [T]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: &mut [T]) -> Vec<T> {
        s.to_vec()
    }
    #[cfg(test)]
    fn from(s: &mut [T]) -> Vec<T> {
        crate::slice::to_vec(s, Global)
    }
}

#[stable(feature = "vec_from_array", since = "1.44.0")]
impl<T, const N: usize> From<[T; N]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: [T; N]) -> Vec<T> {
        <[T]>::into_vec(box s)
    }
    #[cfg(test)]
    fn from(s: [T; N]) -> Vec<T> {
        crate::slice::into_vec(box s)
    }
}

#[stable(feature = "vec_from_cow_slice", since = "1.14.0")]
impl<'a, T> From<Cow<'a, [T]>> for Vec<T>
where
    [T]: ToOwned<Owned = Vec<T>>,
{
    fn from(s: Cow<'a, [T]>) -> Vec<T> {
        s.into_owned()
    }
}

// note: ang mga pagsubok ay humihila sa libstd, na nagiging sanhi ng mga pagkakamali dito
#[cfg(not(test))]
#[stable(feature = "vec_from_box", since = "1.18.0")]
impl<T, A: Allocator> From<Box<[T], A>> for Vec<T, A> {
    fn from(s: Box<[T], A>) -> Self {
        let len = s.len();
        Self { buf: RawVec::from_box(s), len }
    }
}

// note: ang mga pagsubok ay humihila sa libstd, na nagiging sanhi ng mga pagkakamali dito
#[cfg(not(test))]
#[stable(feature = "box_from_vec", since = "1.20.0")]
impl<T, A: Allocator> From<Vec<T, A>> for Box<[T], A> {
    fn from(v: Vec<T, A>) -> Self {
        v.into_boxed_slice()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl From<&str> for Vec<u8> {
    fn from(s: &str) -> Vec<u8> {
        From::from(s.as_bytes())
    }
}

#[stable(feature = "array_try_from_vec", since = "1.48.0")]
impl<T, A: Allocator, const N: usize> TryFrom<Vec<T, A>> for [T; N] {
    type Error = Vec<T, A>;

    /// Nakukuha ang buong nilalaman ng `Vec<T>` bilang isang array, kung ang sukat nito ay eksaktong tumutugma sa hiniling na array.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::convert::TryInto;
    /// assert_eq!(vec![1, 2, 3].try_into(), Ok([1, 2, 3]));
    /// assert_eq!(<Vec<i32>>::new().try_into(), Ok([]));
    /// ```
    ///
    /// Kung ang haba ay hindi tumutugma, ang input ay babalik sa `Err`:
    ///
    /// ```
    /// use std::convert::TryInto;
    /// let r: Result<[i32; 4], _> = (0..10).collect::<Vec<_>>().try_into();
    /// assert_eq!(r, Err(vec![0, 1, 2, 3, 4, 5, 6, 7, 8, 9]));
    /// ```
    ///
    /// Kung maayos ka sa pagkuha lamang ng isang unlapi ng `Vec<T>`, maaari kang tumawag muna sa [`.truncate(N)`](Vec::truncate).
    ///
    /// ```
    /// use std::convert::TryInto;
    /// let mut v = String::from("hello world").into_bytes();
    /// v.sort();
    /// v.truncate(2);
    /// let [a, b]: [_; 2] = v.try_into().unwrap();
    /// assert_eq!(a, b' ');
    /// assert_eq!(b, b'd');
    /// ```
    fn try_from(mut vec: Vec<T, A>) -> Result<[T; N], Vec<T, A>> {
        if vec.len() != N {
            return Err(vec);
        }

        // KALIGTASAN: `.set_len(0)` ay palaging tunog.
        unsafe { vec.set_len(0) };

        // KALIGTASAN: Ang pointer ng isang `Vec` ay laging nakahanay nang maayos, at
        // ang pagkakahanay na kailangan ng array ay pareho sa mga item.
        // Sinuri namin kanina na mayroon kaming sapat na mga item.
        // Ang mga item ay hindi double-drop bilang ang `set_len` nagsasabi sa `Vec` hindi rin i-drop ang mga ito.
        //
        let array = unsafe { ptr::read(vec.as_ptr() as *const [T; N]) };
        Ok(array)
    }
}