// Itakda ang haba ng mga vector kapag ang `SetLenOnDrop` na halaga ay mawawala sa saklaw.
//
// Ang ideya ay: Ang patlang ng haba sa SetLenOnDrop ay isang lokal na variable na makikita ng optimizer ay hindi alias sa anumang mga tindahan sa pamamagitan ng data pointer ng Vec.
// Ito ay isang solusyon para sa isyu ng pag-aaral ng alias #32155
//
pub(super) struct SetLenOnDrop<'a> {
    len: &'a mut usize,
    local_len: usize,
}

impl<'a> SetLenOnDrop<'a> {
    #[inline]
    pub(super) fn new(len: &'a mut usize) -> Self {
        SetLenOnDrop { local_len: *len, len }
    }

    #[inline]
    pub(super) fn increment_len(&mut self, increment: usize) {
        self.local_len += increment;
    }
}

impl Drop for SetLenOnDrop<'_> {
    #[inline]
    fn drop(&mut self) {
        *self.len = self.local_len;
    }
}