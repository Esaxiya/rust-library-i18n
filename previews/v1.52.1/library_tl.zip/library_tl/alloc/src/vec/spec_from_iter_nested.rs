use core::iter::TrustedLen;
use core::ptr::{self};

use super::{SpecExtend, Vec};

/// Ang isa pang pagdadalubhasa trait para sa Vec::from_iter kinakailangan upang manu-manong unahin ang mga nagpapatong na pagdadalubhasa tingnan ang [`SpecFromIter`](super::SpecFromIter) para sa mga detalye.
///
///
pub(super) trait SpecFromIterNested<T, I> {
    fn from_iter(iter: I) -> Self;
}

impl<T, I> SpecFromIterNested<T, I> for Vec<T>
where
    I: Iterator<Item = T>,
{
    default fn from_iter(mut iterator: I) -> Self {
        // Alisin ang takbo ng unang pag-ulit, dahil ang vector ay lalawak sa pag-ulit na ito sa bawat kaso kapag ang iterable ay hindi walang laman, ngunit ang loop sa extend_desugared() ay hindi makikita ang vector na puno sa ilang kasunod na pag-ulit ng loop.
        //
        // Kaya nakakakuha kami ng mas mahusay na hula ng branch.
        //
        //
        let mut vector = match iterator.next() {
            None => return Vec::new(),
            Some(element) => {
                let (lower, _) = iterator.size_hint();
                let mut vector = Vec::with_capacity(lower.saturating_add(1));
                unsafe {
                    ptr::write(vector.as_mut_ptr(), element);
                    vector.set_len(1);
                }
                vector
            }
        };
        // dapat paglaanan ng spec_extend() dahil extend() mismo delegates upang spec_from para sa walang laman Vecs
        //
        <Vec<T> as SpecExtend<T, I>>::spec_extend(&mut vector, iterator);
        vector
    }
}

impl<T, I> SpecFromIterNested<T, I> for Vec<T>
where
    I: TrustedLen<Item = T>,
{
    fn from_iter(iterator: I) -> Self {
        let mut vector = match iterator.size_hint() {
            (_, Some(upper)) => Vec::with_capacity(upper),
            _ => Vec::new(),
        };
        // dapat paglaanan ng spec_extend() dahil extend() mismo delegates upang spec_from para sa walang laman Vecs
        //
        vector.spec_extend(iterator);
        vector
    }
}