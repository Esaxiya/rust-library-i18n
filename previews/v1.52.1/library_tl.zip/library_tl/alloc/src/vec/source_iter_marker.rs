use core::iter::{InPlaceIterable, SourceIter};
use core::mem::{self, ManuallyDrop};
use core::ptr::{self};

use super::{AsIntoIter, InPlaceDrop, SpecFromIter, SpecFromIterNested, Vec};

/// Espesyalista marker para sa pagkolekta ng isang iterator pipeline sa isang Vec habang ginagamit muli ang mapagkukunang paglalaan, ibig sabihin
/// pagpapatupad ng pipeline sa lugar.
///
/// Ang magulang ng SourceIter na trait ay kinakailangan para sa pagdadalubhasa na pag-andar upang ma-access ang paglalaan na muling gagamitin.
/// Ngunit hindi ito sapat upang maging wasto ang pagdadalubhasa.
/// Makita ang mga karagdagang hangganan sa impl.
#[rustc_unsafe_specialization_marker]
pub(super) trait SourceIterMarker: SourceIter<Source: AsIntoIter> {}

// Ang std-panloob na SourceIter/InPlaceIterable traits ay ipinatutupad lamang ng mga kadena ng Adapter <Adapter<Adapter<IntoIter>>> (lahat pag-aari ng core/std).
// Karagdagang hangganan sa pagpapatupad adapter (lampas `impl<I: Trait> Trait for Adapter<I>`) lamang depende sa iba pang mga traits na minarkahan bilang pagdadalubhasa traits (Copy, TrustedRandomAccess, FusedIterator).
//
// I.e. ang marker ay hindi nakasalalay sa panghabang buhay ng mga uri na ibinibigay ng gumagamit.I-modulo ang hole ng Kopyahin, kung saan nakasalalay ang maraming iba pang pagdadalubhasa.
//
//
impl<T> SourceIterMarker for T where T: SourceIter<Source: AsIntoIter> + InPlaceIterable {}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T> + SourceIterMarker,
{
    default fn from_iter(mut iterator: I) -> Self {
        // Karagdagang mga kinakailangan na hindi maipahayag sa pamamagitan ng trait bounds.Sa halip ay umaasa kami sa const eval:
        // a) walang mga ZST dahil walang paglalaan upang magamit muli at ang pointer arithmetic ay panic b) laki ng tugma tulad ng hinihiling ng kontrata ng Alloc c) pagtutugma ng mga pagkakahanay ayon sa hinihiling ng kontrata ng Alloc
        //
        //
        //
        if mem::size_of::<T>() == 0
            || mem::size_of::<T>()
                != mem::size_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
            || mem::align_of::<T>()
                != mem::align_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
        {
            // fallback sa mas pangkalahatang pagpapatupad
            return SpecFromIterNested::from_iter(iterator);
        }

        let (src_buf, src_ptr, dst_buf, dst_end, cap) = unsafe {
            let inner = iterator.as_inner().as_into_iter();
            (
                inner.buf.as_ptr(),
                inner.ptr,
                inner.buf.as_ptr() as *mut T,
                inner.end as *const T,
                inner.cap,
            )
        };

        // gumamit ng try-fold mula noon
        // - mas mahusay itong nag-vectorize para sa ilang mga adapter ng iterator
        // - hindi katulad ng karamihan sa mga panloob na mga pamamaraan ng pag-ulit, ito lamang tumatagal ng isang &mut sa sarili
        // - hinahayaan nito kaming i-thread ang pagsulat ng pointer sa mga looban nito at ibalik ito sa huli
        let sink = InPlaceDrop { inner: dst_buf, dst: dst_buf };
        let sink = iterator
            .try_fold::<_, _, Result<_, !>>(sink, write_in_place_with_drop(dst_end))
            .unwrap();
        // nagtagumpay ang pag-ulit, huwag mag-ulo
        let dst = ManuallyDrop::new(sink).dst;

        let src = unsafe { iterator.as_inner().as_into_iter() };
        // suriin kung ang kontrata ng SourceIter ay napanatili ang pag-iingat: kung hindi sila hindi namin maaaring gawin ito sa puntong ito
        //
        debug_assert_eq!(src_buf, src.buf.as_ptr());
        // suriin ang InPlaceIterable na kontrata.Posible lamang ito kung isulong ng iterator ang pinagmumulan ng punter sa lahat.
        // Kung ito ay gumagamit ng walang check access sa pamamagitan ng TrustedRandomAccess pagkatapos ay ang source pointer ay mananatili sa kanyang unang posisyon at hindi namin maaaring gamitin ito bilang sanggunian
        //
        if src.ptr != src_ptr {
            debug_assert!(
                dst as *const _ <= src.ptr,
                "InPlaceIterable contract violation, write pointer advanced beyond read pointer"
            );
        }

        // i-drop ang anumang natitirang mga halaga sa buntot ng mapagkukunan ngunit pigilan ang pagbagsak ng paglalaan mismo sa sandaling ang IntoIter ay mawawala sa saklaw kung ang drop panics pagkatapos ay tumagas din kami sa anumang mga elemento na nakolekta sa dst_buf
        //
        //
        src.forget_allocation_drop_remaining();

        let vec = unsafe {
            let len = dst.offset_from(dst_buf) as usize;
            Vec::from_raw_parts(dst_buf, len, cap)
        };

        vec
    }
}

fn write_in_place_with_drop<T>(
    src_end: *const T,
) -> impl FnMut(InPlaceDrop<T>, T) -> Result<InPlaceDrop<T>, !> {
    move |mut sink, item| {
        unsafe {
            // ang InPlaceIterable na kontrata ay hindi maaring ma-verify nang tumpak dito dahil ang try_fold ay may isang eksklusibong sanggunian sa pinagmulan ng pointer na ang maaari lamang nating gawin ay suriin kung nasa saklaw pa rin
            //
            //
            debug_assert!(sink.dst as *const _ <= src_end, "InPlaceIterable contract violation");
            ptr::write(sink.dst, item);
            sink.dst = sink.dst.add(1);
        }
        Ok(sink)
    }
}