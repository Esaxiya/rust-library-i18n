use core::marker::PhantomData;
use core::ptr::NonNull;

/// Ang mga modelo ng isang reborrow ng ilang natatanging sanggunian, kapag alam mo na ang reborrow at lahat ng mga inapo nito (ibig sabihin, lahat ng mga payo at sanggunian na nagmula rito) ay hindi na gagamitin sa ilang mga punto, at pagkatapos ay nais mong gamitin muli ang orihinal na natatanging sanggunian .
///
///
/// Karaniwang hinahawakan ng checker ng panghihiram ang paglalagay ng mga borrows na ito para sa iyo, ngunit ang ilang mga daloy ng kontrol na nakakamit sa paglalagay na ito ay masyadong kumplikado para sa tagasunod na sumunod.
/// Pinapayagan ka ng isang `DormantMutRef` na suriin ang paghiram ng iyong sarili, habang ipinapahayag pa rin ang nakasalansan na likas na katangian, at encapsulate ang raw pointer code na kinakailangan upang gawin ito nang hindi natukoy na pag-uugali.
///
///
///
///
///
pub struct DormantMutRef<'a, T> {
    ptr: NonNull<T>,
    _marker: PhantomData<&'a mut T>,
}

unsafe impl<'a, T> Sync for DormantMutRef<'a, T> where &'a mut T: Sync {}
unsafe impl<'a, T> Send for DormantMutRef<'a, T> where &'a mut T: Send {}

impl<'a, T> DormantMutRef<'a, T> {
    /// Kumuha ng isang natatanging panghihiram, at agad itong muling paghimok.
    /// Para sa tagatala, ang panghabambuhay ng bagong sanggunian ay kapareho ng habang buhay ng orihinal na sanggunian, ngunit ikaw promise na gamitin ito sa isang mas maikling panahon.
    ///
    pub fn new(t: &'a mut T) -> (&'a mut T, Self) {
        let ptr = NonNull::from(t);
        // KALIGTASAN: hawak namin ang paghiram sa buong 'a sa pamamagitan ng `_marker`, at inilalantad namin
        // ang sanggunian lamang ito, kaya natatangi ito.
        let new_ref = unsafe { &mut *ptr.as_ptr() };
        (new_ref, Self { ptr, _marker: PhantomData })
    }

    /// Bumalik sa natatanging paghiram na naunang nakuha.
    ///
    /// # Safety
    ///
    /// Ang pagreretiro ay dapat na natapos, ibig sabihin, ang sanggunian na ibinalik ng `new` at lahat ng mga payo at sanggunian na nagmula rito, ay hindi na dapat gamitin.
    ///
    pub unsafe fn awaken(self) -> &'a mut T {
        // KALIGTASAN: ang aming sariling mga kondisyon sa kaligtasan ay nagpapahiwatig na ang sanggunian na ito ay muling natatangi.
        unsafe { &mut *self.ptr.as_ptr() }
    }
}

#[cfg(test)]
mod tests;