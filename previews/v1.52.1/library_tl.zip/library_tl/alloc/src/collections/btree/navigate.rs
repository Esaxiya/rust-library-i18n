use core::borrow::Borrow;
use core::ops::RangeBounds;
use core::ptr;

use super::node::{marker, ForceResult::*, Handle, NodeRef};

pub struct LeafRange<BorrowType, K, V> {
    pub front: Option<Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>>,
    pub back: Option<Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>>,
}

impl<BorrowType, K, V> LeafRange<BorrowType, K, V> {
    pub fn none() -> Self {
        LeafRange { front: None, back: None }
    }

    pub fn is_empty(&self) -> bool {
        self.front == self.back
    }

    /// Pansamantalang naglalabas ng isa pa, hindi nababago na katumbas ng parehong saklaw.
    pub fn reborrow(&self) -> LeafRange<marker::Immut<'_>, K, V> {
        LeafRange {
            front: self.front.as_ref().map(|f| f.reborrow()),
            back: self.back.as_ref().map(|b| b.reborrow()),
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Mahahanap ang natatanging mga gilid ng dahon na naglilimita sa isang tinukoy na saklaw sa isang puno.
    /// Ibinabalik ang alinman sa isang pares ng iba't ibang mga hawakan sa parehong puno o isang pares ng mga walang laman na pagpipilian.
    ///
    /// # Safety
    ///
    /// Maliban kung ang `BorrowType` ay `Immut`, huwag gamitin ang mga duplicate na hawakan upang bisitahin ang parehong KV nang dalawang beses.
    unsafe fn find_leaf_edges_spanning_range<Q: ?Sized, R>(
        self,
        range: R,
    ) -> LeafRange<BorrowType, K, V>
    where
        Q: Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        match self.search_tree_for_bifurcation(&range) {
            Err(_) => LeafRange::none(),
            Ok((
                node,
                lower_edge_idx,
                upper_edge_idx,
                mut lower_child_bound,
                mut upper_child_bound,
            )) => {
                let mut lower_edge = unsafe { Handle::new_edge(ptr::read(&node), lower_edge_idx) };
                let mut upper_edge = unsafe { Handle::new_edge(node, upper_edge_idx) };
                loop {
                    match (lower_edge.force(), upper_edge.force()) {
                        (Leaf(f), Leaf(b)) => return LeafRange { front: Some(f), back: Some(b) },
                        (Internal(f), Internal(b)) => {
                            (lower_edge, lower_child_bound) =
                                f.descend().find_lower_bound_edge(lower_child_bound);
                            (upper_edge, upper_child_bound) =
                                b.descend().find_upper_bound_edge(upper_child_bound);
                        }
                        _ => unreachable!("BTreeMap has different depths"),
                    }
                }
            }
        }
    }
}

/// Katumbas ng `(root1.first_leaf_edge(), root2.last_leaf_edge())` ngunit mas mahusay.
fn full_range<BorrowType: marker::BorrowType, K, V>(
    root1: NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    root2: NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
) -> LeafRange<BorrowType, K, V> {
    let mut min_node = root1;
    let mut max_node = root2;
    loop {
        let front = min_node.first_edge();
        let back = max_node.last_edge();
        match (front.force(), back.force()) {
            (Leaf(f), Leaf(b)) => {
                return LeafRange { front: Some(f), back: Some(b) };
            }
            (Internal(min_int), Internal(max_int)) => {
                min_node = min_int.descend();
                max_node = max_int.descend();
            }
            _ => unreachable!("BTreeMap has different depths"),
        };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Immut<'a>, K, V, marker::LeafOrInternal> {
    /// Mahahanap ang pares ng mga gilid ng dahon na naglilimita sa isang tukoy na saklaw sa isang puno.
    ///
    /// Ang resulta ay makabuluhan lamang kung ang puno ay na-order ng key, tulad ng puno sa isang `BTreeMap`.
    ///
    pub fn range_search<Q, R>(self, range: R) -> LeafRange<marker::Immut<'a>, K, V>
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        // KALIGTASAN: ang aming uri ng panghihiram ay hindi nababago.
        unsafe { self.find_leaf_edges_spanning_range(range) }
    }

    /// Mahahanap ang pares ng mga gilid ng dahon na naglilimita sa isang buong puno.
    pub fn full_range(self) -> LeafRange<marker::Immut<'a>, K, V> {
        full_range(self, self)
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::ValMut<'a>, K, V, marker::LeafOrInternal> {
    /// Hinahati ang isang natatanging sanggunian sa isang pares ng mga gilid ng dahon na nagtatanggal ng isang tinukoy na saklaw.
    /// Ang resulta ay hindi natatanging mga sanggunian na nagpapahintulot sa mutasyon ng (some), na dapat gamitin nang maingat.
    ///
    /// Ang resulta ay makabuluhan lamang kung ang puno ay na-order ng key, tulad ng puno sa isang `BTreeMap`.
    ///
    ///
    /// # Safety
    /// Huwag gamitin ang mga duplicate na hawakan upang bisitahin ang parehong KV nang dalawang beses.
    ///
    pub fn range_search<Q, R>(self, range: R) -> LeafRange<marker::ValMut<'a>, K, V>
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        unsafe { self.find_leaf_edges_spanning_range(range) }
    }

    /// Hinahati ang isang natatanging sanggunian sa isang pares ng mga gilid ng dahon na naglilimita sa buong saklaw ng puno.
    /// Ang mga resulta ay hindi natatanging mga sanggunian na pinapayagan ang pag-mutate (ng mga halaga lamang), kaya dapat gamitin nang may pag-iingat.
    ///
    pub fn full_range(self) -> LeafRange<marker::ValMut<'a>, K, V> {
        // Doblehin namin ang root NodeRef dito-hindi namin bibisitahin ang parehong KV nang dalawang beses, at hindi kailanman magtatapos sa magkakapatong na mga sanggunian sa halaga.
        //
        let self2 = unsafe { ptr::read(&self) };
        full_range(self, self2)
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// Hinahati ang isang natatanging sanggunian sa isang pares ng mga gilid ng dahon na naglilimita sa buong saklaw ng puno.
    /// Ang mga resulta ay hindi natatanging mga sanggunian na nagpapahintulot sa napakalaking mapanirang mutasyon, kaya dapat gamitin nang may lubos na pangangalaga.
    ///
    pub fn full_range(self) -> LeafRange<marker::Dying, K, V> {
        // Doblehin namin ang ugat na NodeRef dito-hindi namin ito mai-a-access sa isang paraan na nagsasapawan ng mga sanggunian na nakuha mula sa ugat.
        //
        let self2 = unsafe { ptr::read(&self) };
        full_range(self, self2)
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>
{
    /// Dahil sa isang hawakan ng dahon na edge, ibabalik ang [`Result::Ok`] na may hawakan sa kalapit na KV sa kanang bahagi, na alinman sa parehong node ng dahon o sa isang node ng ninuno.
    ///
    /// Kung ang dahon ng edge ay ang huli sa puno, ibabalik ang [`Result::Err`] gamit ang root node.
    pub fn next_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    > {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.right_kv() {
                Ok(kv) => return Ok(kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge.forget_node_type(),
                    Err(root) => return Err(root),
                },
            }
        }
    }

    /// Dahil sa isang hawakan ng dahon na edge, ibabalik ang [`Result::Ok`] na may hawakan sa kalapit na KV sa kaliwang bahagi, na alinman sa parehong node ng dahon o sa isang node ng ninuno.
    ///
    /// Kung ang dahon ng edge ay ang una sa puno, ibabalik ang [`Result::Err`] gamit ang root node.
    pub fn next_back_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    > {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.left_kv() {
                Ok(kv) => return Ok(kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge.forget_node_type(),
                    Err(root) => return Err(root),
                },
            }
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// Dahil sa isang panloob na hawakan ng edge, ibabalik ang [`Result::Ok`] na may hawakan sa kalapit na KV sa kanang bahagi, na alinman sa parehong panloob na node o sa isang node ng ninuno.
    ///
    /// Kung ang panloob na edge ay ang huli sa puno, ibabalik ang [`Result::Err`] gamit ang root node.
    pub fn next_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        let mut edge = self;
        loop {
            edge = match edge.right_kv() {
                Ok(internal_kv) => return Ok(internal_kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge,
                    Err(root) => return Err(root),
                },
            }
        }
    }
}

impl<K, V> Handle<NodeRef<marker::Dying, K, V, marker::Leaf>, marker::Edge> {
    /// Dahil sa isang hawakan ng edge sa isang namamatay na puno, ibinalik ang susunod na dahon na edge sa kanang bahagi, at ang pares ng key-halaga sa pagitan, na alinman sa parehong node ng dahon, sa isang node ng ninuno, o wala.
    ///
    ///
    /// Ang pamamaraang ito ay nakikipag-ugnay din sa anumang node(s) na naabot nito sa katapusan ng.
    /// Ipinapahiwatig nito na kung wala nang pares ng key-value, ang buong natitirang puno ay maaaksyunan at wala nang makakabalik.
    ///
    /// # Safety
    /// Ang ibinigay na edge ay dapat hindi dating naibalik ng katapat na `deallocating_next_back`.
    ///
    ///
    ///
    unsafe fn deallocating_next(self) -> Option<(Self, (K, V))> {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.right_kv() {
                Ok(kv) => {
                    let k = unsafe { ptr::read(kv.reborrow().into_kv().0) };
                    let v = unsafe { ptr::read(kv.reborrow().into_kv().1) };
                    return Some((kv.next_leaf_edge(), (k, v)));
                }
                Err(last_edge) => match unsafe { last_edge.into_node().deallocate_and_ascend() } {
                    Some(parent_edge) => parent_edge.forget_node_type(),
                    None => return None,
                },
            }
        }
    }

    /// Dahil sa isang hawakan ng edge sa isang namamatay na puno, ibinalik ang susunod na dahon edge sa kaliwang bahagi, at ang pares ng key-halaga sa pagitan, na alinman sa parehong node ng dahon, sa isang node ng ninuno, o wala.
    ///
    ///
    /// Ang pamamaraang ito ay nakikipag-ugnay din sa anumang node(s) na naabot nito sa katapusan ng.
    /// Ipinapahiwatig nito na kung wala nang pares ng key-value, ang buong natitirang puno ay maaaksyunan at wala nang makakabalik.
    ///
    /// # Safety
    /// Ang ibinigay na edge ay dapat hindi dating naibalik ng katapat na `deallocating_next`.
    ///
    ///
    ///
    unsafe fn deallocating_next_back(self) -> Option<(Self, (K, V))> {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.left_kv() {
                Ok(kv) => {
                    let k = unsafe { ptr::read(kv.reborrow().into_kv().0) };
                    let v = unsafe { ptr::read(kv.reborrow().into_kv().1) };
                    return Some((kv.next_back_leaf_edge(), (k, v)));
                }
                Err(last_edge) => match unsafe { last_edge.into_node().deallocate_and_ascend() } {
                    Some(parent_edge) => parent_edge.forget_node_type(),
                    None => return None,
                },
            }
        }
    }

    /// Nakikipag-ugnay sa isang tumpok ng mga node mula sa dahon hanggang sa ugat.
    /// Ito ang tanging paraan upang makitungo sa natitirang bahagi ng isang puno matapos ang `deallocating_next` at `deallocating_next_back` na humihimas sa magkabilang panig ng puno, at na-hit ang parehong edge.
    /// Dahil nilalayon lamang ito na tawagan kapag ang lahat ng mga susi at halaga ay naibalik, walang paglilinis na ginagawa sa alinman sa mga susi o halaga.
    ///
    ///
    ///
    pub fn deallocating_end(self) {
        let mut edge = self.forget_node_type();
        while let Some(parent_edge) = unsafe { edge.into_node().deallocate_and_ascend() } {
            edge = parent_edge.forget_node_type();
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Immut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Inililipat ang hawakan ng edge sa susunod na dahon edge at ibabalik ang mga sanggunian sa susi at halaga sa pagitan.
    ///
    ///
    /// # Safety
    /// Dapat may isa pang KV sa direksyong nalakbay.
    pub unsafe fn next_unchecked(&mut self) -> (&'a K, &'a V) {
        super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (kv.next_leaf_edge(), kv.into_kv())
        })
    }

    /// Inililipat ang hawakan ng edge ng dahon sa nakaraang dahon edge at ibabalik ang mga sanggunian sa susi at halaga sa pagitan.
    ///
    ///
    /// # Safety
    /// Dapat may isa pang KV sa direksyong nalakbay.
    pub unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a V) {
        super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_back_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (kv.next_back_leaf_edge(), kv.into_kv())
        })
    }
}

impl<'a, K, V> Handle<NodeRef<marker::ValMut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Inililipat ang hawakan ng edge sa susunod na dahon edge at ibabalik ang mga sanggunian sa susi at halaga sa pagitan.
    ///
    ///
    /// # Safety
    /// Dapat may isa pang KV sa direksyong nalakbay.
    pub unsafe fn next_unchecked(&mut self) -> (&'a K, &'a mut V) {
        let kv = super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (unsafe { ptr::read(&kv) }.next_leaf_edge(), kv)
        });
        // Ang paggawa ng huling ito ay mas mabilis, ayon sa mga benchmark.
        kv.into_kv_valmut()
    }

    /// Inililipat ang hawakan ng edge sa dating dahon at nagbabalik ng mga sanggunian sa susi at halaga sa pagitan.
    ///
    ///
    /// # Safety
    /// Dapat may isa pang KV sa direksyong nalakbay.
    pub unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a mut V) {
        let kv = super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_back_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (unsafe { ptr::read(&kv) }.next_back_leaf_edge(), kv)
        });
        // Ang paggawa ng huling ito ay mas mabilis, ayon sa mga benchmark.
        kv.into_kv_valmut()
    }
}

impl<K, V> Handle<NodeRef<marker::Dying, K, V, marker::Leaf>, marker::Edge> {
    /// Inililipat ang hawakan ng edge sa susunod na dahon edge at ibabalik ang susi at halaga sa pagitan, pinapalitan ang anumang node na naiwan habang iniiwan ang kaukulang edge sa magulang node na nakalawit.
    ///
    /// # Safety
    /// - Dapat may isa pang KV sa direksyong nalakbay.
    /// - Ang KV na iyon ay hindi dating ibinalik ng katapat na `next_back_unchecked` sa anumang kopya ng mga hawakan na ginagamit upang daanan ang puno.
    ///
    /// Ang tanging ligtas na paraan upang magpatuloy sa na-update na hawakan ay upang ihambing ito, i-drop ito, tawagan muli ang pamamaraang ito napapailalim sa mga kondisyon sa kaligtasan nito, o tawagan ang katapat na `next_back_unchecked` na napapailalim sa mga kondisyon sa kaligtasan.
    ///
    ///
    ///
    ///
    ///
    pub unsafe fn deallocating_next_unchecked(&mut self) -> (K, V) {
        super::mem::replace(self, |leaf_edge| unsafe {
            leaf_edge.deallocating_next().unwrap_unchecked()
        })
    }

    /// Inililipat ang hawakan ng edge ng dahon sa nakaraang dahon edge at ibinalik ang susi at halaga sa pagitan, pinapalitan ang anumang node na naiwan habang iniiwan ang kaukulang edge sa magulang node na nakalawit.
    ///
    /// # Safety
    /// - Dapat may isa pang KV sa direksyong nalakbay.
    /// - Ang dahon na edge ay hindi dating ibinalik ng katapat na `next_unchecked` sa anumang kopya ng mga hawakan na ginagamit upang daanan ang puno.
    ///
    /// Ang tanging ligtas na paraan upang magpatuloy sa na-update na hawakan ay upang ihambing ito, i-drop ito, tawagan muli ang pamamaraang ito napapailalim sa mga kondisyon sa kaligtasan nito, o tawagan ang katapat na `next_unchecked` na napapailalim sa mga kondisyon sa kaligtasan.
    ///
    ///
    ///
    ///
    ///
    pub unsafe fn deallocating_next_back_unchecked(&mut self) -> (K, V) {
        super::mem::replace(self, |leaf_edge| unsafe {
            leaf_edge.deallocating_next_back().unwrap_unchecked()
        })
    }
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Ibinabalik ang kaliwang dahon na edge sa o sa ilalim ng isang node, sa madaling salita, ang edge na kailangan mo muna kapag nagna-navigate pasulong (o huling kapag nagna-navigate pabalik).
    ///
    #[inline]
    pub fn first_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        let mut node = self;
        loop {
            match node.force() {
                Leaf(leaf) => return leaf.first_edge(),
                Internal(internal) => node = internal.first_edge().descend(),
            }
        }
    }

    /// Ibinabalik ang kanang dahon ng edge sa o sa ilalim ng isang node, sa madaling salita, ang edge na kailangan mo ng huli kapag nagna-navigate pasulong (o una kapag nagna-navigate pabalik).
    ///
    #[inline]
    pub fn last_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        let mut node = self;
        loop {
            match node.force() {
                Leaf(leaf) => return leaf.last_edge(),
                Internal(internal) => node = internal.last_edge().descend(),
            }
        }
    }
}

pub enum Position<BorrowType, K, V> {
    Leaf(NodeRef<BorrowType, K, V, marker::Leaf>),
    Internal(NodeRef<BorrowType, K, V, marker::Internal>),
    InternalKV(Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV>),
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Immut<'a>, K, V, marker::LeafOrInternal> {
    /// Ang mga pagbisita sa mga leaf node at panloob na KVs sa pagkakasunud-sunod ng mga pataas na key, at binibisita din ang mga panloob na node bilang isang kabuuan sa isang malalim na unang pagkakasunud-sunod, ibig sabihin na ang panloob na mga node ay nauuna ang kanilang mga indibidwal na KV at kanilang mga node ng bata.
    ///
    ///
    pub fn visit_nodes_in_order<F>(self, mut visit: F)
    where
        F: FnMut(Position<marker::Immut<'a>, K, V>),
    {
        match self.force() {
            Leaf(leaf) => visit(Position::Leaf(leaf)),
            Internal(internal) => {
                visit(Position::Internal(internal));
                let mut edge = internal.first_edge();
                loop {
                    edge = match edge.descend().force() {
                        Leaf(leaf) => {
                            visit(Position::Leaf(leaf));
                            match edge.next_kv() {
                                Ok(kv) => {
                                    visit(Position::InternalKV(kv));
                                    kv.right_edge()
                                }
                                Err(_) => return,
                            }
                        }
                        Internal(internal) => {
                            visit(Position::Internal(internal));
                            internal.first_edge()
                        }
                    }
                }
            }
        }
    }

    /// Kinakalkula ang bilang ng mga elemento sa isang (sub) puno.
    pub fn calc_length(self) -> usize {
        let mut result = 0;
        self.visit_nodes_in_order(|pos| match pos {
            Position::Leaf(node) => result += node.len(),
            Position::Internal(node) => result += node.len(),
            Position::InternalKV(_) => (),
        });
        result
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>
{
    /// Ibinabalik ang dahon ng edge na pinakamalapit sa isang KV para sa pasulong na pag-navigate.
    pub fn next_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        match self.force() {
            Leaf(leaf_kv) => leaf_kv.right_edge(),
            Internal(internal_kv) => {
                let next_internal_edge = internal_kv.right_edge();
                next_internal_edge.descend().first_leaf_edge()
            }
        }
    }

    /// Ibinabalik ang dahon ng edge na pinakamalapit sa isang KV para sa paatras na pag-navigate.
    pub fn next_back_leaf_edge(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        match self.force() {
            Leaf(leaf_kv) => leaf_kv.left_edge(),
            Internal(internal_kv) => {
                let next_internal_edge = internal_kv.left_edge();
                next_internal_edge.descend().last_leaf_edge()
            }
        }
    }
}