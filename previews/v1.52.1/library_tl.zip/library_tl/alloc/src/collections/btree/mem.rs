use core::intrinsics;
use core::mem;
use core::ptr;

/// Pinalitan nito ang halaga sa likod ng natatanging sanggunian ng `v` sa pamamagitan ng pagtawag sa nauugnay na pagpapaandar.
///
///
/// Kung ang isang panic ay nangyayari sa pagsasara ng `change`, ang buong proseso ay aalisin.
#[allow(dead_code)] // panatilihin bilang paglalarawan at para sa paggamit ng future
#[inline]
pub fn take_mut<T>(v: &mut T, change: impl FnOnce(T) -> T) {
    replace(v, |value| (change(value), ()))
}

/// Pinalitan nito ang halaga sa likod ng natatanging sanggunian ng `v` sa pamamagitan ng pagtawag sa nauugnay na pagpapaandar, at nagbabalik ng isang resulta na nakuha kasama.
///
///
/// Kung ang isang panic ay nangyayari sa pagsasara ng `change`, ang buong proseso ay aalisin.
#[inline]
pub fn replace<T, R>(v: &mut T, change: impl FnOnce(T) -> (T, R)) -> R {
    struct PanicGuard;
    impl Drop for PanicGuard {
        fn drop(&mut self) {
            intrinsics::abort()
        }
    }
    let guard = PanicGuard;
    let value = unsafe { ptr::read(v) };
    let (new_value, ret) = change(value);
    unsafe {
        ptr::write(v, new_value);
    }
    mem::forget(guard);
    ret
}