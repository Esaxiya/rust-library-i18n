// Ito ay isang pagtatangka sa isang pagpapatupad ng pagsunod sa ideal
//
// ```
// struct BTreeMap<K, V> {
//     height: usize,
//     root: Option<Box<Node<K, V, height>>>
// }
//
// struct Node<K, V, height: usize> {
//     keys: [K; 2 * B - 1],
//     vals: [V; 2 * B - 1],
//     edges: [if height > 0 { Box<Node<K, V, height - 1>> } else { () }; 2 * B],
//     parent: Option<(NonNull<Node<K, V, height + 1>>, u16)>,
//     len: u16,
// }
// ```
//
// Dahil ang Rust ay wala talagang mga umaasa na uri at recursion ng polymorphic, ginagawa namin ang maraming kaligtasan.
//

// Ang isang pangunahing layunin ng modyul na ito ay upang maiwasan ang pagiging kumplikado sa pamamagitan ng paggamot sa puno bilang isang pangkaraniwan (kung may kakaibang hugis) na lalagyan at pag-iwas sa pakikitungo sa karamihan sa mga invariant ng B-Tree.
//
// Tulad ng naturan, ang module na ito ay walang pakialam kung ang mga entry ay pinagsunod-sunod, kung aling mga node ay maaaring maging underfull, o kahit na kung ano ang ibig sabihin ng underfull.Gayunpaman, umaasa kami sa ilang mga invariant:
//
// - Ang mga puno ay dapat may pare-parehong depth/height.Nangangahulugan ito na ang bawat landas pababa sa isang dahon mula sa isang naibigay na node ay may eksaktong parehong haba.
// - Ang isang node ng haba na `n` ay may mga key na `n`, mga halagang `n`, at mga gilid ng `n + 1`.
//   Ipinapahiwatig nito na kahit ang isang walang laman na node ay mayroong kahit isang edge.
//   Para sa isang node ng dahon, nangangahulugan lamang ang "having an edge" na maaari naming makilala ang isang posisyon sa node, dahil ang mga gilid ng dahon ay walang laman at hindi nangangailangan ng representasyon ng data.
// Sa isang panloob na node, ang isang edge ay kapwa kinikilala ang isang posisyon at naglalaman ng isang pointer sa isang node ng bata.
//
//
//

use core::marker::PhantomData;
use core::mem::{self, MaybeUninit};
use core::ptr::{self, NonNull};
use core::slice::SliceIndex;

use crate::alloc::{Allocator, Global, Layout};
use crate::boxed::Box;

const B: usize = 6;
pub const CAPACITY: usize = 2 * B - 1;
pub const MIN_LEN_AFTER_SPLIT: usize = B - 1;
const KV_IDX_CENTER: usize = B - 1;
const EDGE_IDX_LEFT_OF_CENTER: usize = B - 1;
const EDGE_IDX_RIGHT_OF_CENTER: usize = B;

/// Ang pinagbabatayan na representasyon ng mga leaf node at bahagi ng representasyon ng mga panloob na node.
struct LeafNode<K, V> {
    /// Gusto naming maging covariant sa `K` at `V`.
    parent: Option<NonNull<InternalNode<K, V>>>,

    /// Ang index ng node na ito sa `edges` array ng parent node.
    /// `*node.parent.edges[node.parent_idx]` dapat na kapareho ng bagay sa `node`.
    /// Garantisado lamang itong mapasimulan kapag ang `parent` ay hindi null.
    parent_idx: MaybeUninit<u16>,

    /// Ang bilang ng mga susi at halaga na iniimbak ng node.
    len: u16,

    /// Ang mga arrays na nakaimbak ng totoong data ng node.
    /// Ang mga unang `len` na elemento lamang ng bawat array ang naisasimula at wasto.
    keys: [MaybeUninit<K>; CAPACITY],
    vals: [MaybeUninit<V>; CAPACITY],
}

impl<K, V> LeafNode<K, V> {
    /// Pinasimulan ang isang bagong `LeafNode` na lugar.
    unsafe fn init(this: *mut Self) {
        // Bilang isang pangkalahatang patakaran, iniiwan namin ang mga patlang na hindi pinag-uusapan kung maaari silang maging, dahil dapat itong parehong kapwa mas mabilis at mas madaling subaybayan sa Valgrind.
        //
        unsafe {
            // parent_idx, mga susi, at vals ay lahat ng SiguroUninit
            ptr::addr_of_mut!((*this).parent).write(None);
            ptr::addr_of_mut!((*this).len).write(0);
        }
    }

    /// Lumilikha ng isang bagong box na `LeafNode`.
    fn new() -> Box<Self> {
        unsafe {
            let mut leaf = Box::new_uninit();
            LeafNode::init(leaf.as_mut_ptr());
            leaf.assume_init()
        }
    }
}

/// Ang pinagbabatayan na representasyon ng mga panloob na node.Tulad ng sa `LeafNode`s, ang mga ito ay dapat na maitago sa likod ng 'BoxedNode`s upang maiwasan ang pag-drop ng mga uninitialized na key at halaga.
/// Ang anumang pointer sa isang `InternalNode` ay maaaring direktang itinapon sa isang pointer sa pinagbabatayan na bahagi ng `LeafNode` ng node, na pinapayagan ang code na kumilos sa dahon at panloob na mga node nang pangkalahatan nang hindi kinakailangang suriin alin sa dalawa ang itinuro ng isang pointer.
///
/// Ang accommodation na ito ay pinagana ng paggamit ng `repr(C)`.
///
#[repr(C)]
// gdb_providers.py gumagamit ng ganitong pangalan ng uri para sa pagsisiyasat.
struct InternalNode<K, V> {
    data: LeafNode<K, V>,

    /// Ang mga payo sa mga bata ng node na ito.
    /// `len + 1` ng mga ito ay itinuturing na pinasimulan at wasto, maliban sa malapit sa wakas, habang ang puno ay gaganapin sa pamamagitan ng uri ng panghihiram `Dying`, ang ilan sa mga pahiwatig na ito ay nakalawit.
    ///
    edges: [MaybeUninit<BoxedNode<K, V>>; 2 * B],
}

impl<K, V> InternalNode<K, V> {
    /// Lumilikha ng isang bagong box na `InternalNode`.
    ///
    /// # Safety
    /// Ang isang invariant ng panloob na mga node ay mayroon silang hindi bababa sa isang pinasimulan at wastong edge.
    /// Ang pagpapaandar na ito ay hindi nagse-set up ng tulad ng isang edge.
    ///
    unsafe fn new() -> Box<Self> {
        unsafe {
            let mut node = Box::<Self>::new_uninit();
            // Kailangan lang naming gawing una ang data;ang mga gilid ay MaybeUninit.
            LeafNode::init(ptr::addr_of_mut!((*node.as_mut_ptr()).data));
            node.assume_init()
        }
    }
}

/// Isang pinamamahalaang, hindi null na pointer sa isang node.Ito ay alinman sa pagmamay-ari ng pointer sa `LeafNode<K, V>` o isang pagmamay-ari na pointer sa `InternalNode<K, V>`.
///
/// Gayunpaman, ang `BoxedNode` ay walang naglalaman ng impormasyon tungkol sa alin sa dalawang uri ng mga node na talagang naglalaman nito, at, bahagyang sanhi ng kakulangan ng impormasyon na ito, ay hindi isang hiwalay na uri at walang destructor.
///
///
///
type BoxedNode<K, V> = NonNull<LeafNode<K, V>>;

/// Ang root node ng isang nagmamay-ari na puno.
///
/// Tandaan na wala itong isang destructor, at dapat na malinis nang manu-mano.
pub type Root<K, V> = NodeRef<marker::Owned, K, V, marker::LeafOrInternal>;

impl<K, V> Root<K, V> {
    /// Nagbabalik ng isang bagong pagmamay-ari na puno, na may sariling ugat na node na una nang walang laman.
    pub fn new() -> Self {
        NodeRef::new_leaf().forget_type()
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Leaf> {
    fn new_leaf() -> Self {
        Self::from_new_leaf(LeafNode::new())
    }

    fn from_new_leaf(leaf: Box<LeafNode<K, V>>) -> Self {
        NodeRef { height: 0, node: NonNull::from(Box::leak(leaf)), _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Internal> {
    fn new_internal(child: Root<K, V>) -> Self {
        let mut new_node = unsafe { InternalNode::new() };
        new_node.edges[0].write(child.node);
        unsafe { NodeRef::from_new_internal(new_node, child.height + 1) }
    }

    /// # Safety
    /// `height` hindi dapat maging zero.
    unsafe fn from_new_internal(internal: Box<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        let node = NonNull::from(Box::leak(internal)).cast();
        let mut this = NodeRef { height, node, _marker: PhantomData };
        this.borrow_mut().correct_all_childrens_parent_links();
        this
    }
}

impl<K, V, Type> NodeRef<marker::Owned, K, V, Type> {
    /// Mapaghihiram na pinahiram ang nagmamay-ari na root node.
    /// Hindi tulad ng `reborrow_mut`, ligtas ito sapagkat ang halaga ng pagbabalik ay hindi maaaring magamit upang sirain ang ugat, at hindi maaaring may iba pang mga sanggunian sa puno.
    ///
    pub fn borrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Bahagyang nababagabag ang pag-aari ng root node.
    pub fn borrow_valmut(&mut self) -> NodeRef<marker::ValMut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Hindi maibabalik ang paglipat sa isang sanggunian na nagpapahintulot sa traversal at nag-aalok ng mga mapanirang pamamaraan at kaunti pa.
    ///
    pub fn into_dying(self) -> NodeRef<marker::Dying, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// Nagdaragdag ng isang bagong panloob na node na may isang solong edge na tumuturo sa nakaraang root node, gawin ang bagong node na root node, at ibalik ito.
    /// Dagdagan nito ang taas ng 1 at kabaligtaran ng `pop_internal_level`.
    ///
    pub fn push_internal_level(&mut self) -> NodeRef<marker::Mut<'_>, K, V, marker::Internal> {
        super::mem::take_mut(self, |old_root| NodeRef::new_internal(old_root).forget_type());

        // `self.borrow_mut()`, maliban sa nakalimutan lamang namin na panloob kami ngayon:
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Tinatanggal ang panloob na node ng ugat, gamit ang unang anak nito bilang bagong root node.
    /// Dahil nilalayon lamang ito na tawagan kapag ang root node ay may isang anak lamang, walang paglilinis na ginagawa sa alinman sa mga susi, halaga at iba pang mga bata.
    ///
    /// Binabawasan nito ang taas ng 1 at kabaligtaran ng `push_internal_level`.
    ///
    /// Nangangailangan ng eksklusibong pag-access sa `Root` object ngunit hindi sa root node;
    /// hindi nito aalisin ang bisa ng iba pang mga hawakan o sanggunian sa root node.
    ///
    /// Panics kung walang panloob na antas, ibig sabihin, kung ang root node ay isang dahon.
    pub fn pop_internal_level(&mut self) {
        assert!(self.height > 0);

        let top = self.node;

        // KALIGTASAN: iginiit namin na panloob.
        let internal_self = unsafe { self.borrow_mut().cast_to_internal_unchecked() };
        // KALIGTASAN: nanghiram kami ng `self` nang eksklusibo at ang uri ng paghiram ay eksklusibo.
        let internal_node = unsafe { &mut *NodeRef::as_internal_ptr(&internal_self) };
        // KALIGTASAN: ang unang edge ay laging nasisimulan.
        self.node = unsafe { internal_node.edges[0].assume_init_read() };
        self.height -= 1;
        self.clear_parent_link();

        unsafe {
            Global.deallocate(top.cast(), Layout::new::<InternalNode<K, V>>());
        }
    }
}

// N.B. Ang `NodeRef` ay palaging covariant sa `K` at `V`, kahit na ang `BorrowType` ay `Mut`.
// Ito ay teknikal na mali, ngunit hindi maaaring magresulta sa anumang kawalan ng kapanatagan dahil sa panloob na paggamit ng `NodeRef` dahil mananatili kaming ganap na generic sa `K` at `V`.
//
// Gayunpaman, tuwing isang pampublikong uri ang bumabalot ng `NodeRef`, tiyaking mayroon itong tamang pagkakaiba-iba.
//
/// Isang sanggunian sa isang node.
///
/// Ang uri na ito ay may isang bilang ng mga parameter na kumokontrol sa kung paano ito kumilos:
/// - `BorrowType`: Isang uri ng dummy na naglalarawan sa uri ng panghihiram at nagdadala ng isang panghabang buhay.
///    - Kapag ito ay `Immut<'a>`, ang `NodeRef` ay gumaganap ng halos tulad ng `&'a Node`.
///    - Kapag ito ay `ValMut<'a>`, ang `NodeRef` ay gumaganap ng halos tulad ng `&'a Node` na patungkol sa mga susi at istraktura ng puno, ngunit pinapayagan din ang maraming mga nababagong sanggunian sa mga halaga sa buong puno na magkakasamang mabuhay.
///    - Kapag ito ay `Mut<'a>`, ang `NodeRef` ay kumikilos na halos tulad ng `&'a mut Node`, bagaman pinapayagan ng mga paraan ng pagsingit ang isang nababagabag na pointer sa isang halaga na magkakasamang mabuhay.
///    - Kapag ito ay `Owned`, ang `NodeRef` ay kumikilos na halos tulad ng `Box<Node>`, ngunit walang isang destructor, at dapat na malinis nang manu-mano.
///    - Kapag ito ay `Dying`, ang `NodeRef` ay kumikilos pa rin halos tulad ng `Box<Node>`, ngunit may mga pamamaraan upang sirain ang puno ng paunti-unti, at ang mga ordinaryong pamamaraan, habang hindi minarkahan bilang hindi ligtas na tawagan, ay maaaring mag-apply ng UB kung hindi wastong tinawag.
///
///   Dahil ang anumang `NodeRef` ay pinapayagan ang pag-navigate sa puno, mabisang nalalapat ang `BorrowType` sa buong puno, hindi lamang sa node mismo.
/// - `K` at `V`: Ito ang mga uri ng mga key at halaga na nakaimbak sa mga node.
/// - `Type`: Maaari itong maging `Leaf`, `Internal`, o `LeafOrInternal`.
/// Kapag ito ay `Leaf`, ang `NodeRef` ay tumuturo sa isang leaf node, kapag ito ay `Internal` ang `NodeRef` ay tumuturo sa isang panloob na node, at kapag ito ay `LeafOrInternal` ang `NodeRef` ay maaaring tumuturo sa alinmang uri ng node.
///   `Type` ay pinangalanang `NodeType` kapag ginamit sa labas ng `NodeRef`.
///
/// Parehong pinaghihigpitan ng `BorrowType` at `NodeType` kung anong mga pamamaraan ang ipinatutupad namin, upang magamit ang kaligtasan ng static na uri.Mayroong mga limitasyon sa paraan na maaari naming mailapat ang mga nasabing paghihigpit:
/// - Para sa bawat parameter ng uri, maaari lamang naming tukuyin ang isang pamamaraan alinman sa pangkalahatan o para sa isang partikular na uri.
/// Halimbawa, hindi namin matukoy ang isang paraan tulad ng `into_kv` sa pangkalahatan para sa lahat ng `BorrowType`, o isang beses para sa lahat ng mga uri na nagdadala ng isang buhay, dahil nais naming ibalik ang mga sanggunian na `&'a`.
///   Samakatuwid, tinutukoy lamang namin ito para sa hindi gaanong makapangyarihang uri ng `Immut<'a>`.
/// - Hindi kami makakakuha ng implicit pamimilit mula sa sabihin na `Mut<'a>` hanggang `Immut<'a>`.
///   Samakatuwid, kailangan nating malinaw na tawagan ang `reborrow` sa isang mas malakas na `NodeRef` upang maabot ang isang pamamaraan tulad ng `into_kv`.
///
/// Ang lahat ng mga pamamaraan sa `NodeRef` na nagbabalik ng ilang uri ng sanggunian, alinman sa:
/// - Dalhin ang `self` ayon sa halaga, at ibalik ang habang buhay na dala ng `BorrowType`.
///   Minsan, upang mapatawag ang gayong pamamaraan, kailangan nating tawagan ang `reborrow_mut`.
/// - Dalhin ang `self` sa pamamagitan ng sanggunian, at ibalik ng (implicitly) ang buhay ng sanggunian na iyon, sa halip na ang buhay na dinala ng `BorrowType`.
/// Sa ganoong paraan, ginagarantiyahan ng checker ng panghihiram na ang `NodeRef` ay mananatiling hiniram hangga't ginagamit ang ibinalik na sanggunian.
///   Ang mga pamamaraang sumusuporta sa insert ay yumuko sa panuntunang ito sa pamamagitan ng pagbabalik ng isang raw pointer, ibig sabihin, isang sanggunian nang walang anumang buhay.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
pub struct NodeRef<BorrowType, K, V, Type> {
    /// Ang bilang ng mga antas na ang node at ang antas ng mga dahon ay magkahiwalay, isang pare-pareho ng node na hindi maaaring buong inilarawan ng `Type`, at ang node mismo ay hindi nag-iimbak.
    /// Kailangan lamang nating iimbak ang taas ng root node, at kunin ang taas ng bawat ibang node mula rito.
    /// Dapat ay zero kung `Type` ay `Leaf` at hindi-zero kung `Type` ay `Internal`.
    ///
    ///
    height: usize,
    /// Ang pointer sa dahon o panloob na node.
    /// Ang kahulugan ng `InternalNode` ay nagsisiguro na ang pointer ay wasto alinman sa parehong paraan.
    node: NonNull<LeafNode<K, V>>,
    _marker: PhantomData<(BorrowType, Type)>,
}

impl<'a, K: 'a, V: 'a, Type> Copy for NodeRef<marker::Immut<'a>, K, V, Type> {}
impl<'a, K: 'a, V: 'a, Type> Clone for NodeRef<marker::Immut<'a>, K, V, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

unsafe impl<BorrowType, K: Sync, V: Sync, Type> Sync for NodeRef<BorrowType, K, V, Type> {}

unsafe impl<'a, K: Sync + 'a, V: Sync + 'a, Type> Send for NodeRef<marker::Immut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::Mut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::ValMut<'a>, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Owned, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Dying, K, V, Type> {}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// I-unpack ang isang sangguniang node na naka-pack bilang `NodeRef::parent`.
    fn from_internal(node: NonNull<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        NodeRef { height, node: node.cast(), _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Inilalantad ang data ng isang panloob na node.
    ///
    /// Nagbabalik ng isang hilaw na ptr upang maiwasan ang pag-invalidate ng iba pang mga sanggunian sa node na ito.
    fn as_internal_ptr(this: &Self) -> *mut InternalNode<K, V> {
        // KALIGTASAN: ang uri ng static node ay `Internal`.
        this.node.as_ptr() as *mut InternalNode<K, V>
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Humihiram ng eksklusibong pag-access sa data ng isang panloob na node.
    fn as_internal_mut(&mut self) -> &mut InternalNode<K, V> {
        let ptr = Self::as_internal_ptr(self);
        unsafe { &mut *ptr }
    }
}

impl<BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// Mahahanap ang haba ng node.Ito ang bilang ng mga susi o halaga.
    /// Ang bilang ng mga gilid ay `len() + 1`.
    /// Tandaan na, sa kabila ng pagiging ligtas, ang pagtawag sa pagpapaandar na ito ay maaaring magkaroon ng masamang epekto ng pag-aalis ng bisa ng mga nababagong sanggunian na nilikha ng hindi ligtas na code.
    ///
    pub fn len(&self) -> usize {
        // Pangkahalagaan, mai-access lamang natin ang patlang `len` dito.
        // Kung ang BorrowType ay marker::ValMut, maaaring may mga natitirang nababagong sanggunian sa mga halagang hindi namin dapat patunayan.
        unsafe { usize::from((*Self::as_leaf_ptr(self)).len) }
    }

    /// Ibinabalik ang bilang ng mga antas na hiwalay ang node at dahon.
    /// Ang taas ng zero ay nangangahulugang ang node ay isang dahon mismo.
    /// Kung ang larawan mo puno na may root sa itaas, ang bilang sabi ni kung saan elevation ng node ay lilitaw.
    /// Kung larawan mo ang mga puno na may mga dahon sa itaas, sinasabi ng bilang kung gaano kataas ang pag-abot ng puno sa itaas ng node.
    ///
    pub fn height(&self) -> usize {
        self.height
    }

    /// Pansamantalang naglalabas ng isa pa, hindi nababago na sanggunian sa parehong node.
    pub fn reborrow(&self) -> NodeRef<marker::Immut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Inilantad ang bahagi ng dahon ng anumang dahon o panloob na node.
    ///
    /// Nagbabalik ng isang hilaw na ptr upang maiwasan ang pag-invalidate ng iba pang mga sanggunian sa node na ito.
    fn as_leaf_ptr(this: &Self) -> *mut LeafNode<K, V> {
        // Ang node ay dapat na wasto para sa hindi bababa sa bahagi ng LeafNode.
        // Hindi ito isang sanggunian sa uri ng NodeRef sapagkat hindi namin alam kung dapat itong maging natatangi o ibinahagi.
        //
        this.node.as_ptr()
    }
}

impl<BorrowType: marker::BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// Mahahanap ang magulang ng kasalukuyang node.
    /// Ibinabalik ang `Ok(handle)` kung ang kasalukuyang node ay talagang may magulang, kung saan ang `handle` ay tumuturo sa edge ng magulang na tumuturo sa kasalukuyang node.
    ///
    /// Ibinabalik ang `Err(self)` kung ang kasalukuyang node ay walang magulang, na ibinabalik ang orihinal na `NodeRef`.
    ///
    /// Ipinapalagay sa iyo ng pangalan ng pamamaraan ang mga puno ng larawan na may root node sa itaas.
    ///
    /// `edge.descend().ascend().unwrap()` at `node.ascend().unwrap().descend()` ay dapat kapwa, sa tagumpay, ay walang gawin.
    ///
    pub fn ascend(
        self,
    ) -> Result<Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>, Self> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // Kailangan naming gumamit ng mga hilaw na pahiwatig sa mga node sapagkat, kung ang BorrowType ay marker::ValMut, maaaring mayroong natitirang mga nababagong sanggunian sa mga halagang hindi namin dapat patunayan.
        //
        let leaf_ptr: *const _ = Self::as_leaf_ptr(&self);
        unsafe { (*leaf_ptr).parent }
            .as_ref()
            .map(|parent| Handle {
                node: NodeRef::from_internal(*parent, self.height + 1),
                idx: unsafe { usize::from((*leaf_ptr).parent_idx.assume_init()) },
                _marker: PhantomData,
            })
            .ok_or(self)
    }

    pub fn first_edge(self) -> Handle<Self, marker::Edge> {
        unsafe { Handle::new_edge(self, 0) }
    }

    pub fn last_edge(self) -> Handle<Self, marker::Edge> {
        let len = self.len();
        unsafe { Handle::new_edge(self, len) }
    }

    /// Tandaan na ang `self` ay dapat na nonempty.
    pub fn first_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, 0) }
    }

    /// Tandaan na ang `self` ay dapat na nonempty.
    pub fn last_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, len - 1) }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Immut<'a>, K, V, Type> {
    /// Inilantad ang bahagi ng dahon ng anumang dahon o panloob na node sa isang hindi nababago na puno.
    fn into_leaf(self) -> &'a LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&self);
        // KALIGTASAN: maaaring walang mutable na sanggunian sa punong ito na hiniram bilang `Immut`.
        unsafe { &*ptr }
    }

    /// Pinahiram ang isang view sa mga key na nakaimbak sa node.
    pub fn keys(&self) -> &[K] {
        let leaf = self.into_leaf();
        unsafe {
            MaybeUninit::slice_assume_init_ref(leaf.keys.get_unchecked(..usize::from(leaf.len)))
        }
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// Katulad ng `ascend`, nakakakuha ng isang sanggunian sa node ng isang node, ngunit din ay nakikipagpalitan ng kasalukuyang node sa proseso.
    /// Ito ay hindi ligtas dahil ang kasalukuyang node ay maa-access pa rin sa kabila ng pagkakalipat ng pansin.
    ///
    pub unsafe fn deallocate_and_ascend(
        self,
    ) -> Option<Handle<NodeRef<marker::Dying, K, V, marker::Internal>, marker::Edge>> {
        let height = self.height;
        let node = self.node;
        let ret = self.ascend().ok();
        unsafe {
            Global.deallocate(
                node.cast(),
                if height > 0 {
                    Layout::new::<InternalNode<K, V>>()
                } else {
                    Layout::new::<LeafNode<K, V>>()
                },
            );
        }
        ret
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Hindi ligtas na iginiit sa tagatala ang static na impormasyon na ang node na ito ay isang `Leaf`.
    unsafe fn cast_to_leaf_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
        debug_assert!(self.height == 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Hindi ligtas na iginiit sa tagatala ang static na impormasyon na ang node na ito ay isang `Internal`.
    unsafe fn cast_to_internal_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        debug_assert!(self.height > 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Pansamantalang naglalabas ng isa pa, nababagong sanggunian sa parehong node.Mag-ingat, dahil ang pamamaraang ito ay lubhang mapanganib, doble kaya't dahil hindi ito kaagad lumitaw na mapanganib.
    ///
    /// Dahil ang mga nababagabag na payo ay maaaring gumala kahit saan sa paligid ng puno, ang naibalik na pointer ay madaling magamit upang gawing nakalawit ang orihinal na pointer, wala sa mga hangganan, o hindi wasto sa ilalim ng mga nakasalansan na panuntunan.
    ///
    ///
    ///
    ///
    // FIXME(@gereeter) isaalang-alang ang pagdaragdag ng isa pang uri ng parameter sa `NodeRef` na naghihigpit sa paggamit ng mga pamamaraan sa pag-navigate sa mga muling hinihiling na payo, na pumipigil sa hindi ligtas na ito.
    //
    //
    unsafe fn reborrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Nanghihiram ng eksklusibong pag-access sa bahagi ng dahon ng anumang dahon o panloob na node.
    fn as_leaf_mut(&mut self) -> &mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(self);
        // KALIGTASAN: mayroon kaming eksklusibong pag-access sa buong node.
        unsafe { &mut *ptr }
    }

    /// Nag-aalok ng eksklusibong pag-access sa bahagi ng dahon ng anumang dahon o panloob na node.
    fn into_leaf_mut(mut self) -> &'a mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&mut self);
        // KALIGTASAN: mayroon kaming eksklusibong pag-access sa buong node.
        unsafe { &mut *ptr }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Humihiram ng eksklusibong pag-access sa isang elemento ng pangunahing lugar ng imbakan.
    ///
    /// # Safety
    /// `index` ay nasa hangganan ng 0..CAPACITY
    unsafe fn key_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<K>], Output = Output>,
    {
        // KALIGTASAN: ang tumatawag ay hindi makakatawag sa karagdagang mga pamamaraan sa sarili
        // hanggang sa mahulog ang pangunahing sanggunian ng hiwa, dahil mayroon kaming natatanging pag-access para sa panghabambuhay na paghiram.
        //
        unsafe { self.as_leaf_mut().keys.as_mut_slice().get_unchecked_mut(index) }
    }

    /// Humihiram ng eksklusibong pag-access sa isang elemento o hiwa ng lugar ng imbakan ng halaga ng node.
    ///
    /// # Safety
    /// `index` ay nasa hangganan ng 0..CAPACITY
    unsafe fn val_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<V>], Output = Output>,
    {
        // KALIGTASAN: ang tumatawag ay hindi makakatawag sa karagdagang mga pamamaraan sa sarili
        // hanggang sa bumaba ang sanggunian ng hiwa ng halaga, dahil mayroon kaming natatanging pag-access para sa panghabambuhay na paghiram.
        //
        unsafe { self.as_leaf_mut().vals.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Humihiram ng eksklusibong pag-access sa isang elemento o hiwa ng lugar ng imbakan ng node para sa mga nilalaman ng edge.
    ///
    /// # Safety
    /// `index` ay nasa hangganan ng 0..CAPACITY + 1
    unsafe fn edge_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<BoxedNode<K, V>>], Output = Output>,
    {
        // KALIGTASAN: ang tumatawag ay hindi makakatawag sa karagdagang mga pamamaraan sa sarili
        // hanggang sa bumagsak ang sanggunian ng hiwa ng edge, dahil mayroon kaming natatanging pag-access sa buong buhay ng paghiram.
        //
        unsafe { self.as_internal_mut().edges.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K, V, Type> NodeRef<marker::ValMut<'a>, K, V, Type> {
    /// # Safety
    /// - Ang node ay may higit sa `idx` mga inisyal na elemento.
    unsafe fn into_key_val_mut_at(mut self, idx: usize) -> (&'a K, &'a mut V) {
        // Lumilikha lamang kami ng isang sanggunian sa isang elemento na interesado kami, upang maiwasan ang aliasing na may natitirang mga sanggunian sa iba pang mga elemento, sa partikular, na bumalik sa tumatawag sa mga naunang pag-ulit.
        //
        //
        let leaf = Self::as_leaf_ptr(&mut self);
        let keys = unsafe { ptr::addr_of!((*leaf).keys) };
        let vals = unsafe { ptr::addr_of_mut!((*leaf).vals) };
        // Dapat naming pilitin ang mga hindi pinabilis na mga pointer ng array dahil sa Rust isyu #74679.
        let keys: *const [_] = keys;
        let vals: *mut [_] = vals;
        let key = unsafe { (&*keys.get_unchecked(idx)).assume_init_ref() };
        let val = unsafe { (&mut *vals.get_unchecked_mut(idx)).assume_init_mut() };
        (key, val)
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Humihiram ng eksklusibong pag-access sa haba ng node.
    pub fn len_mut(&mut self) -> &mut u16 {
        &mut self.as_leaf_mut().len
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Itinatakda ang link ng node sa magulang nitong edge, nang hindi na-aalis ang ibang mga sanggunian sa node.
    ///
    fn set_parent_link(&mut self, parent: NonNull<InternalNode<K, V>>, parent_idx: usize) {
        let leaf = Self::as_leaf_ptr(self);
        unsafe { (*leaf).parent = Some(parent) };
        unsafe { (*leaf).parent_idx.write(parent_idx as u16) };
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// Inaalis ang link ng ugat sa magulang nitong edge.
    fn clear_parent_link(&mut self) {
        let mut root_node = self.borrow_mut();
        let leaf = root_node.as_leaf_mut();
        leaf.parent = None;
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
    /// Nagdaragdag ng isang pares ng key-halaga sa dulo ng node.
    pub fn push(&mut self, key: K, val: V) {
        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// # Safety
    /// Ang bawat item na ibinalik ng `range` ay isang wastong edge index para sa node.
    unsafe fn correct_childrens_parent_links<R: Iterator<Item = usize>>(&mut self, range: R) {
        for i in range {
            debug_assert!(i <= self.len());
            unsafe { Handle::new_edge(self.reborrow_mut(), i) }.correct_parent_link();
        }
    }

    fn correct_all_childrens_parent_links(&mut self) {
        let len = self.len();
        unsafe { self.correct_childrens_parent_links(0..=len) };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Nagdaragdag ng isang pares ng key-halaga, at isang edge upang pumunta sa kanan ng pares na iyon, sa dulo ng node.
    ///
    pub fn push(&mut self, key: K, val: V, edge: Root<K, V>) {
        assert!(edge.height == self.height - 1);

        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
            self.edge_area_mut(idx + 1).write(edge.node);
            Handle::new_edge(self.reborrow_mut(), idx + 1).correct_parent_link();
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Sinusuri kung ang isang node ay isang `Internal` node o isang `Leaf` node.
    pub fn force(
        self,
    ) -> ForceResult<
        NodeRef<BorrowType, K, V, marker::Leaf>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        if self.height == 0 {
            ForceResult::Leaf(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        } else {
            ForceResult::Internal(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        }
    }
}

/// Isang sanggunian sa isang tukoy na pares na key-halaga o edge sa loob ng isang node.
/// Ang parameter na `Node` ay dapat na isang `NodeRef`, habang ang `Type` ay maaaring maging `KV` (nagpapahiwatig ng isang hawakan sa isang pares ng key-halaga) o `Edge` (nagpapahiwatig ng isang hawakan sa isang edge).
///
/// Tandaan na kahit na ang mga `Leaf` node ay maaaring magkaroon ng mga paghawak ng `Edge`.
/// Sa halip na kumakatawan sa isang pointer sa isang node ng bata, kinakatawan nito ang mga puwang kung saan pupunta ang mga payo ng bata sa pagitan ng mga pares ng key-value.
/// Halimbawa, sa isang node na may haba na 2, magkakaroon ng 3 posibleng mga lokasyon ng edge, isa sa kaliwa ng node, isa sa pagitan ng dalawang pares, at isa sa kanan ng node.
///
///
pub struct Handle<Node, Type> {
    node: Node,
    idx: usize,
    _marker: PhantomData<Type>,
}

impl<Node: Copy, Type> Copy for Handle<Node, Type> {}
// Hindi namin kailangan ang buong pangkalahatang `#[derive(Clone)]`, dahil ang tanging oras na `Node` ay magiging "Clone`able ay kapag ito ay isang hindi nababago na sanggunian at samakatuwid `Copy`.
//
impl<Node: Copy, Type> Clone for Handle<Node, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

impl<Node, Type> Handle<Node, Type> {
    /// Kinukuha ang node na naglalaman ng edge o key-value na pares na itinuturo ng hawakan na ito.
    pub fn into_node(self) -> Node {
        self.node
    }

    /// Ibinabalik ang posisyon ng hawakan na ito sa node.
    pub fn idx(&self) -> usize {
        self.idx
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV> {
    /// Lumilikha ng isang bagong hawakan sa isang pares ng key-halaga sa `node`.
    /// Hindi ligtas dahil dapat tiyakin ng tumatawag na `idx < node.len()`.
    pub unsafe fn new_kv(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx < node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx) }
    }

    pub fn right_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx + 1) }
    }
}

impl<BorrowType, K, V, NodeType> NodeRef<BorrowType, K, V, NodeType> {
    /// Maaaring isang pampublikong pagpapatupad ng PartialEq, ngunit ginagamit lamang sa modyul na ito.
    fn eq(&self, other: &Self) -> bool {
        let Self { node, height, _marker } = self;
        if node.eq(&other.node) {
            debug_assert_eq!(*height, other.height);
            true
        } else {
            false
        }
    }
}

impl<BorrowType, K, V, NodeType, HandleType> PartialEq
    for Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    fn eq(&self, other: &Self) -> bool {
        let Self { node, idx, _marker } = self;
        node.eq(&other.node) && *idx == other.idx
    }
}

impl<BorrowType, K, V, NodeType, HandleType>
    Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    /// Pansamantalang naglalabas ng isa pa, hindi nababago na hawakan sa parehong lokasyon.
    pub fn reborrow(&self) -> Handle<NodeRef<marker::Immut<'_>, K, V, NodeType>, HandleType> {
        // Hindi namin magagamit ang Handle::new_kv o Handle::new_edge dahil hindi namin alam ang aming uri
        Handle { node: self.node.reborrow(), idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, Type> {
    /// Hindi ligtas na iginiit sa tagatala ang static na impormasyon na ang node ng hawakan ay isang `Leaf`.
    pub unsafe fn cast_to_leaf_unchecked(
        self,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, Type> {
        let node = unsafe { self.node.cast_to_leaf_unchecked() };
        Handle { node, idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, NodeType, HandleType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, HandleType> {
    /// Pansamantalang naglalabas ng isa pa, nababagong hawakan sa parehong lokasyon.
    /// Mag-ingat, pati na ang paraan na ito ay lubhang mapanganib, doble kaya dahil ito ay maaaring hindi agad lilitaw mapanganib.
    ///
    ///
    /// Para sa mga detalye, tingnan ang `NodeRef::reborrow_mut`.
    pub unsafe fn reborrow_mut(
        &mut self,
    ) -> Handle<NodeRef<marker::Mut<'_>, K, V, NodeType>, HandleType> {
        // Hindi namin magagamit ang Handle::new_kv o Handle::new_edge dahil hindi namin alam ang aming uri
        Handle { node: unsafe { self.node.reborrow_mut() }, idx: self.idx, _marker: PhantomData }
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
    /// Lumilikha ng isang bagong hawakan sa isang edge sa `node`.
    /// Hindi ligtas dahil dapat tiyakin ng tumatawag na `idx <= node.len()`.
    pub unsafe fn new_edge(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx <= node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx > 0 {
            Ok(unsafe { Handle::new_kv(self.node, self.idx - 1) })
        } else {
            Err(self)
        }
    }

    pub fn right_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx < self.node.len() {
            Ok(unsafe { Handle::new_kv(self.node, self.idx) })
        } else {
            Err(self)
        }
    }
}

pub enum LeftOrRight<T> {
    Left(T),
    Right(T),
}

/// Dahil sa isang edge index kung saan nais naming ipasok sa isang node na puno ng kapasidad, kinakalkula ang isang makatwirang KV index ng isang split point at kung saan isasagawa ang pagpapasok.
///
/// Ang layunin ng split point ay para sa susi at halaga nito upang magtapos sa isang node ng magulang;
/// ang mga susi, halaga at gilid sa kaliwa ng split point ay magiging kaliwang anak;
/// ang mga susi, halaga at gilid sa kanan ng split point ay magiging tamang anak.
fn splitpoint(edge_idx: usize) -> (usize, LeftOrRight<usize>) {
    debug_assert!(edge_idx <= CAPACITY);
    // Sinusubukan ng isyu ng Rust na #74834 na ipaliwanag ang mga simetrikong panuntunang ito.
    match edge_idx {
        0..EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER - 1, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_RIGHT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Right(0)),
        _ => (KV_IDX_CENTER + 1, LeftOrRight::Right(edge_idx - (KV_IDX_CENTER + 1 + 1))),
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Nagpapasok ng isang bagong pares ng key-halaga sa pagitan ng mga pares ng key-halaga sa kanan at kaliwa ng edge na ito.
    /// Ipinapalagay ng pamamaraang ito na mayroong sapat na puwang sa node para magkasya ang bagong pares.
    ///
    /// Ang ibinalik na pointer ay tumuturo sa ipinasok na halaga.
    ///
    fn insert_fit(&mut self, key: K, val: V) -> *mut V {
        debug_assert!(self.node.len() < CAPACITY);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            *self.node.len_mut() = new_len as u16;

            self.node.val_area_mut(self.idx).assume_init_mut()
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Nagpapasok ng isang bagong pares ng key-halaga sa pagitan ng mga pares ng key-halaga sa kanan at kaliwa ng edge na ito.
    /// Hinahati ng pamamaraang ito ang node kung walang sapat na silid.
    ///
    /// Ang ibinalik na pointer ay tumuturo sa ipinasok na halaga.
    fn insert(mut self, key: K, val: V) -> (InsertResult<'a, K, V, marker::Leaf>, *mut V) {
        if self.node.len() < CAPACITY {
            let val_ptr = self.insert_fit(key, val);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            (InsertResult::Fit(kv), val_ptr)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            let val_ptr = insertion_edge.insert_fit(key, val);
            (InsertResult::Split(result), val_ptr)
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// Inaayos ang parent pointer at index sa node ng bata na naka-link ang edge na ito.
    /// Kapaki-pakinabang ito kapag binago ang pag-order ng mga gilid,
    fn correct_parent_link(self) {
        // Lumikha ng backpointer nang hindi pinawawalang bisa ang iba pang mga sanggunian sa node.
        let ptr = unsafe { NonNull::new_unchecked(NodeRef::as_internal_ptr(&self.node)) };
        let idx = self.idx;
        let mut child = self.descend();
        child.set_parent_link(ptr, idx);
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// Nagpapasok ng isang bagong pares ng key-halaga at isang edge na pupunta sa kanan ng bagong pares sa pagitan ng edge na ito at ang key-value na pares sa kanan ng edge na ito.
    /// Ipinapalagay ng pamamaraang ito na mayroong sapat na puwang sa node para magkasya ang bagong pares.
    ///
    fn insert_fit(&mut self, key: K, val: V, edge: Root<K, V>) {
        debug_assert!(self.node.len() < CAPACITY);
        debug_assert!(edge.height == self.node.height - 1);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            slice_insert(self.node.edge_area_mut(..new_len + 1), self.idx + 1, edge.node);
            *self.node.len_mut() = new_len as u16;

            self.node.correct_childrens_parent_links(self.idx + 1..new_len + 1);
        }
    }

    /// Nagpapasok ng isang bagong pares ng key-halaga at isang edge na pupunta sa kanan ng bagong pares sa pagitan ng edge na ito at ang key-value na pares sa kanan ng edge na ito.
    /// Hinahati ng pamamaraang ito ang node kung walang sapat na silid.
    ///
    fn insert(
        mut self,
        key: K,
        val: V,
        edge: Root<K, V>,
    ) -> InsertResult<'a, K, V, marker::Internal> {
        assert!(edge.height == self.node.height - 1);

        if self.node.len() < CAPACITY {
            self.insert_fit(key, val, edge);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            InsertResult::Fit(kv)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            insertion_edge.insert_fit(key, val, edge);
            InsertResult::Split(result)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Nagpapasok ng isang bagong pares ng key-halaga sa pagitan ng mga pares ng key-halaga sa kanan at kaliwa ng edge na ito.
    /// Hinahati ng pamamaraang ito ang node kung walang sapat na silid, at sinusubukang ipasok ang bahagi ng split off sa parent node nang paulit-ulit, hanggang sa maabot ang ugat.
    ///
    ///
    /// Kung ang ibinalik na resulta ay isang `Fit`, ang node ng hawakan nito ay maaaring maging node ng edge na ito o isang ninuno.
    /// Kung ang ibinalik na resulta ay isang `Split`, ang patlang `left` ay ang root node.
    /// Ang ibinalik na pointer ay tumuturo sa ipinasok na halaga.
    pub fn insert_recursing(
        self,
        key: K,
        value: V,
    ) -> (InsertResult<'a, K, V, marker::LeafOrInternal>, *mut V) {
        let (mut split, val_ptr) = match self.insert(key, value) {
            (InsertResult::Fit(handle), ptr) => {
                return (InsertResult::Fit(handle.forget_node_type()), ptr);
            }
            (InsertResult::Split(split), val_ptr) => (split.forget_node_type(), val_ptr),
        };

        loop {
            split = match split.left.ascend() {
                Ok(parent) => match parent.insert(split.kv.0, split.kv.1, split.right) {
                    InsertResult::Fit(handle) => {
                        return (InsertResult::Fit(handle.forget_node_type()), val_ptr);
                    }
                    InsertResult::Split(split) => split.forget_node_type(),
                },
                Err(root) => {
                    return (InsertResult::Split(SplitResult { left: root, ..split }), val_ptr);
                }
            };
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// Mahahanap ang node na tinuro ng edge na ito.
    ///
    /// Ipinapalagay sa iyo ng pangalan ng pamamaraan ang mga puno ng larawan na may root node sa itaas.
    ///
    /// `edge.descend().ascend().unwrap()` at `node.ascend().unwrap().descend()` ay dapat kapwa, sa tagumpay, ay walang gawin.
    ///
    pub fn descend(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // Kailangan naming gumamit ng mga hilaw na pahiwatig sa mga node sapagkat, kung ang BorrowType ay marker::ValMut, maaaring mayroong natitirang mga nababagong sanggunian sa mga halagang hindi namin dapat patunayan.
        // Walang pag-aalala ang pag-access sa patlang ng taas dahil ang halagang iyon ay nakopya.
        // Mag-ingat sa na, sa sandaling ang node pointer ay na-disferferensyado, ina-access namin ang mga gilid ng array na may isang sanggunian (Rust isyu #73987) at hindi pinapatunayan ang anumang iba pang mga sanggunian sa o sa loob ng array, dapat mayroon sa paligid.
        //
        //
        //
        //
        let parent_ptr = NodeRef::as_internal_ptr(&self.node);
        let node = unsafe { (*parent_ptr).edges.get_unchecked(self.idx).assume_init_read() };
        NodeRef { node, height: self.node.height - 1, _marker: PhantomData }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Immut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv(self) -> (&'a K, &'a V) {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf();
        let k = unsafe { leaf.keys.get_unchecked(self.idx).assume_init_ref() };
        let v = unsafe { leaf.vals.get_unchecked(self.idx).assume_init_ref() };
        (k, v)
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn key_mut(&mut self) -> &mut K {
        unsafe { self.node.key_area_mut(self.idx).assume_init_mut() }
    }

    pub fn into_val_mut(self) -> &'a mut V {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf_mut();
        unsafe { leaf.vals.get_unchecked_mut(self.idx).assume_init_mut() }
    }
}

impl<'a, K, V, NodeType> Handle<NodeRef<marker::ValMut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv_valmut(self) -> (&'a K, &'a mut V) {
        unsafe { self.node.into_key_val_mut_at(self.idx) }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn kv_mut(&mut self) -> (&mut K, &mut V) {
        debug_assert!(self.idx < self.node.len());
        // Hindi namin matawagan ang magkakahiwalay na mga pamamaraan ng key at halaga, dahil ang pagtawag sa pangalawa ay hindi nagpapawalang-bisa sa sangguniang ibinalik ng una.
        //
        unsafe {
            let leaf = self.node.as_leaf_mut();
            let key = leaf.keys.get_unchecked_mut(self.idx).assume_init_mut();
            let val = leaf.vals.get_unchecked_mut(self.idx).assume_init_mut();
            (key, val)
        }
    }

    /// Palitan ang susi at halagang tinutukoy ng hawakan ng KV.
    pub fn replace_kv(&mut self, k: K, v: V) -> (K, V) {
        let (key, val) = self.kv_mut();
        (mem::replace(key, k), mem::replace(val, v))
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    /// Tumutulong sa pagpapatupad ng `split` para sa isang partikular na `NodeType`, sa pamamagitan ng pag-aalaga ng data ng dahon.
    ///
    fn split_leaf_data(&mut self, new_node: &mut LeafNode<K, V>) -> (K, V) {
        debug_assert!(self.idx < self.node.len());
        let old_len = self.node.len();
        let new_len = old_len - self.idx - 1;
        new_node.len = new_len as u16;
        unsafe {
            let k = self.node.key_area_mut(self.idx).assume_init_read();
            let v = self.node.val_area_mut(self.idx).assume_init_read();

            move_to_slice(
                self.node.key_area_mut(self.idx + 1..old_len),
                &mut new_node.keys[..new_len],
            );
            move_to_slice(
                self.node.val_area_mut(self.idx + 1..old_len),
                &mut new_node.vals[..new_len],
            );

            *self.node.len_mut() = self.idx as u16;
            (k, v)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::KV> {
    /// Hinahati ang pinagbabatayan node sa tatlong bahagi:
    ///
    /// - Ang node ay pinutol upang maglaman lamang ng mga pares ng key-halaga sa kaliwa ng hawakan na ito.
    /// - Ang susi at halagang itinuro ng hawakan na ito ay nakuha.
    /// - Ang lahat ng mga pares na key-halaga sa kanan ng hawakan na ito ay inilalagay sa isang bagong inilalaan na node.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Leaf> {
        let mut new_node = LeafNode::new();

        let kv = self.split_leaf_data(&mut new_node);

        let right = NodeRef::from_new_leaf(new_node);
        SplitResult { left: self.node, kv, right }
    }

    /// Tinatanggal ang pares ng key-halaga na itinuro ng hawakan na ito at ibabalik ito, kasama ang edge na gumuho sa pares ng key-value.
    ///
    pub fn remove(
        mut self,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        let old_len = self.node.len();
        unsafe {
            let k = slice_remove(self.node.key_area_mut(..old_len), self.idx);
            let v = slice_remove(self.node.val_area_mut(..old_len), self.idx);
            *self.node.len_mut() = (old_len - 1) as u16;
            ((k, v), self.left_edge())
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    /// Hinahati ang pinagbabatayan node sa tatlong bahagi:
    ///
    /// - Ang node ay pinutol upang maglaman lamang ng mga gilid at pares ng key-halaga sa kaliwa ng hawakan na ito.
    /// - Ang susi at halagang itinuro ng hawakan na ito ay nakuha.
    /// - Ang lahat ng mga gilid at pares ng key-halaga sa kanan ng hawakan na ito ay inilalagay sa isang bagong inilalaan na node.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Internal> {
        let old_len = self.node.len();
        unsafe {
            let mut new_node = InternalNode::new();
            let kv = self.split_leaf_data(&mut new_node.data);
            let new_len = usize::from(new_node.data.len);
            move_to_slice(
                self.node.edge_area_mut(self.idx + 1..old_len + 1),
                &mut new_node.edges[..new_len + 1],
            );

            let height = self.node.height;
            let right = NodeRef::from_new_internal(new_node, height);

            SplitResult { left: self.node, kv, right }
        }
    }
}

/// Kumakatawan sa isang sesyon para sa pagsusuri at pagsasagawa ng isang pagpapatakbo ng pagbabalanse sa paligid ng isang panloob na pares na key-halaga.
///
pub struct BalancingContext<'a, K, V> {
    parent: Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV>,
    left_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    right_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    pub fn consider_for_balancing(self) -> BalancingContext<'a, K, V> {
        let self1 = unsafe { ptr::read(&self) };
        let self2 = unsafe { ptr::read(&self) };
        BalancingContext {
            parent: self,
            left_child: self1.left_edge().descend(),
            right_child: self2.right_edge().descend(),
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Pumili ng isang konteksto ng pagbabalanse na kinasasangkutan ng node bilang isang bata, sa gayon sa pagitan ng KV kaagad sa kaliwa o sa kanan sa node ng magulang.
    /// Nagbabalik ng isang `Err` kung walang magulang.
    /// Panics kung ang magulang ay walang laman.
    ///
    /// Mas gusto ang kaliwang bahagi, upang maging pinakamainam kung ang ibinigay na node ay sa anumang paraan underfull, ibig sabihin dito lamang na mayroon itong mas kaunting mga elemento kaysa sa kaliwang kapatid at kaysa sa kanang kapatid nito, kung mayroon sila.
    /// Sa kasong iyon, ang pagsasama sa kaliwang kapatid ay mas mabilis, dahil kailangan lamang nating ilipat ang mga elemento ng node, sa halip na ilipat ang mga ito sa kanan at ilipat ang higit sa mga elemento ng N sa harap.
    /// Ang pagnanakaw mula sa kaliwang kapatid ay kadalasang mas mabilis din, dahil kailangan lamang nating ilipat ang kanan ng mga elemento ng node sa kanan, sa halip na ilipat ang hindi bababa sa N ng mga elemento ng kapatid sa kaliwa.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn choose_parent_kv(self) -> Result<LeftOrRight<BalancingContext<'a, K, V>>, Self> {
        match unsafe { ptr::read(&self) }.ascend() {
            Ok(parent_edge) => match parent_edge.left_kv() {
                Ok(left_parent_kv) => Ok(LeftOrRight::Left(BalancingContext {
                    parent: unsafe { ptr::read(&left_parent_kv) },
                    left_child: left_parent_kv.left_edge().descend(),
                    right_child: self,
                })),
                Err(parent_edge) => match parent_edge.right_kv() {
                    Ok(right_parent_kv) => Ok(LeftOrRight::Right(BalancingContext {
                        parent: unsafe { ptr::read(&right_parent_kv) },
                        left_child: self,
                        right_child: right_parent_kv.right_edge().descend(),
                    })),
                    Err(_) => unreachable!("empty internal node"),
                },
            },
            Err(root) => Err(root),
        }
    }
}

impl<'a, K, V> BalancingContext<'a, K, V> {
    pub fn left_child_len(&self) -> usize {
        self.left_child.len()
    }

    pub fn right_child_len(&self) -> usize {
        self.right_child.len()
    }

    pub fn into_left_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.left_child
    }

    pub fn into_right_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.right_child
    }

    /// Ibinabalik kung posible ang pagsasama, ibig sabihin, kung mayroong sapat na silid sa isang node upang pagsamahin ang gitnang KV na may parehong katabing mga node ng bata.
    ///
    pub fn can_merge(&self) -> bool {
        self.left_child.len() + 1 + self.right_child.len() <= CAPACITY
    }
}

impl<'a, K: 'a, V: 'a> BalancingContext<'a, K, V> {
    /// Nagsasagawa ng isang pagsasama at hinahayaan ang isang pagsasara na magpasya kung ano ang ibabalik.
    fn do_merge<
        F: FnOnce(
            NodeRef<marker::Mut<'a>, K, V, marker::Internal>,
            NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
        ) -> R,
        R,
    >(
        self,
        result: F,
    ) -> R {
        let Handle { node: mut parent_node, idx: parent_idx, _marker } = self.parent;
        let old_parent_len = parent_node.len();
        let mut left_node = self.left_child;
        let old_left_len = left_node.len();
        let mut right_node = self.right_child;
        let right_len = right_node.len();
        let new_left_len = old_left_len + 1 + right_len;

        assert!(new_left_len <= CAPACITY);

        unsafe {
            *left_node.len_mut() = new_left_len as u16;

            let parent_key = slice_remove(parent_node.key_area_mut(..old_parent_len), parent_idx);
            left_node.key_area_mut(old_left_len).write(parent_key);
            move_to_slice(
                right_node.key_area_mut(..right_len),
                left_node.key_area_mut(old_left_len + 1..new_left_len),
            );

            let parent_val = slice_remove(parent_node.val_area_mut(..old_parent_len), parent_idx);
            left_node.val_area_mut(old_left_len).write(parent_val);
            move_to_slice(
                right_node.val_area_mut(..right_len),
                left_node.val_area_mut(old_left_len + 1..new_left_len),
            );

            slice_remove(&mut parent_node.edge_area_mut(..old_parent_len + 1), parent_idx + 1);
            parent_node.correct_childrens_parent_links(parent_idx + 1..old_parent_len);
            *parent_node.len_mut() -= 1;

            if parent_node.height > 1 {
                // KALIGTASAN: ang taas ng mga node na pinagsasama ay isa sa ibaba ng taas
                // ng node ng edge na ito, kaya sa itaas ng zero, kaya't panloob ang mga ito.
                let mut left_node = left_node.reborrow_mut().cast_to_internal_unchecked();
                let mut right_node = right_node.cast_to_internal_unchecked();
                move_to_slice(
                    right_node.edge_area_mut(..right_len + 1),
                    left_node.edge_area_mut(old_left_len + 1..new_left_len + 1),
                );

                left_node.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);

                Global.deallocate(right_node.node.cast(), Layout::new::<InternalNode<K, V>>());
            } else {
                Global.deallocate(right_node.node.cast(), Layout::new::<LeafNode<K, V>>());
            }
        }
        result(parent_node, left_node)
    }

    /// Pinagsama ang pares ng key-value ng magulang at parehong katabing node ng bata sa node ng kaliwang anak at ibabalik ang shrunk parent node.
    ///
    ///
    /// Panics maliban kung `.can_merge()` namin.
    pub fn merge_tracking_parent(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        self.do_merge(|parent, _child| parent)
    }

    /// Pinagsama ang pares ng key-value ng magulang at parehong katabing node ng bata sa kaliwang node ng bata at ibabalik ang node ng bata.
    ///
    ///
    /// Panics maliban kung `.can_merge()` namin.
    pub fn merge_tracking_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.do_merge(|_parent, child| child)
    }

    /// Pinagsama ang pares ng key-value ng magulang at parehong katabing node ng bata sa kaliwang node ng bata at ibabalik ang hawakan ng edge sa node ng bata kung saan natapos ang sinusubaybayang bata na edge,
    ///
    ///
    /// Panics maliban kung `.can_merge()` namin.
    ///
    pub fn merge_tracking_child_edge(
        self,
        track_edge_idx: LeftOrRight<usize>,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        let old_left_len = self.left_child.len();
        let right_len = self.right_child.len();
        assert!(match track_edge_idx {
            LeftOrRight::Left(idx) => idx <= old_left_len,
            LeftOrRight::Right(idx) => idx <= right_len,
        });
        let child = self.merge_tracking_child();
        let new_idx = match track_edge_idx {
            LeftOrRight::Left(idx) => idx,
            LeftOrRight::Right(idx) => old_left_len + 1 + idx,
        };
        unsafe { Handle::new_edge(child, new_idx) }
    }

    /// Tinatanggal ang isang pares ng key-halaga mula sa kaliwang anak at inilalagay ito sa imbakan ng key-halaga ng magulang, habang itinutulak ang matandang pares ng key-value sa kanang anak.
    ///
    /// Nagbabalik ng hawakan sa edge sa tamang anak na naaayon sa kung saan natapos ang orihinal na edge na tinukoy ng `track_right_edge_idx`.
    ///
    pub fn steal_left(
        mut self,
        track_right_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_left(1);
        unsafe { Handle::new_edge(self.right_child, 1 + track_right_edge_idx) }
    }

    /// Tinatanggal ang isang pares ng key-halaga mula sa tamang anak at inilalagay ito sa imbakan ng key-halaga ng magulang, habang itinutulak ang lumang pares na key-halaga sa magulang sa kaliwang anak.
    ///
    /// Nagbabalik ng hawakan sa edge sa kaliwang bata na tinukoy ng `track_left_edge_idx`, na hindi gumalaw.
    ///
    pub fn steal_right(
        mut self,
        track_left_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_right(1);
        unsafe { Handle::new_edge(self.left_child, track_left_edge_idx) }
    }

    /// Ang pagnanakaw na ito ay katulad ng `steal_left` ngunit nagnanakaw ng maraming elemento nang sabay-sabay.
    pub fn bulk_steal_left(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // Siguraduhin na maaari kaming magnakaw nang ligtas.
            assert!(old_right_len + count <= CAPACITY);
            assert!(old_left_len >= count);

            let new_left_len = old_left_len - count;
            let new_right_len = old_right_len + count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // Ilipat ang data ng dahon.
            {
                // Gumawa ng puwang para sa mga ninakaw na elemento sa tamang bata.
                slice_shr(right_node.key_area_mut(..new_right_len), count);
                slice_shr(right_node.val_area_mut(..new_right_len), count);

                // Ilipat ang mga elemento mula sa kaliwang bata patungo sa kanan.
                move_to_slice(
                    left_node.key_area_mut(new_left_len + 1..old_left_len),
                    right_node.key_area_mut(..count - 1),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len + 1..old_left_len),
                    right_node.val_area_mut(..count - 1),
                );

                // Ilipat ang kaliwang pinakanakaw na pares sa magulang.
                let k = left_node.key_area_mut(new_left_len).assume_init_read();
                let v = left_node.val_area_mut(new_left_len).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // Ilipat ang pares ng key-value ng magulang sa tamang anak.
                right_node.key_area_mut(count - 1).write(k);
                right_node.val_area_mut(count - 1).write(v);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // Gumawa ng puwang para sa mga ninakaw na gilid.
                    slice_shr(right.edge_area_mut(..new_right_len + 1), count);

                    // Magnanakaw gilid.
                    move_to_slice(
                        left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                        right.edge_area_mut(..count),
                    );

                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }

    /// Ang symmetric clone ng `bulk_steal_left`.
    pub fn bulk_steal_right(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // Siguraduhin na maaari kaming magnakaw nang ligtas.
            assert!(old_left_len + count <= CAPACITY);
            assert!(old_right_len >= count);

            let new_left_len = old_left_len + count;
            let new_right_len = old_right_len - count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // Ilipat ang data ng dahon.
            {
                // Ilipat ang kanang pinakanakaw na pares sa magulang.
                let k = right_node.key_area_mut(count - 1).assume_init_read();
                let v = right_node.val_area_mut(count - 1).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // Ilipat ang pares ng key-value ng magulang sa kaliwang anak.
                left_node.key_area_mut(old_left_len).write(k);
                left_node.val_area_mut(old_left_len).write(v);

                // Ilipat ang mga elemento mula sa kanang bata patungo sa kaliwa.
                move_to_slice(
                    right_node.key_area_mut(..count - 1),
                    left_node.key_area_mut(old_left_len + 1..new_left_len),
                );
                move_to_slice(
                    right_node.val_area_mut(..count - 1),
                    left_node.val_area_mut(old_left_len + 1..new_left_len),
                );

                // Punan ang puwang kung saan dating mga ninakaw na elemento.
                slice_shl(right_node.key_area_mut(..old_right_len), count);
                slice_shl(right_node.val_area_mut(..old_right_len), count);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // Magnanakaw gilid.
                    move_to_slice(
                        right.edge_area_mut(..count),
                        left.edge_area_mut(old_left_len + 1..new_left_len + 1),
                    );

                    // Punan ang puwang kung saan dating mga ninakaw na gilid.
                    slice_shl(right.edge_area_mut(..old_right_len + 1), count);

                    left.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);
                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Leaf> {
    /// Tinatanggal ang anumang static na impormasyon na nagpapahiwatig na ang node na ito ay isang `Leaf` node.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Tinatanggal ang anumang static na impormasyon na nagpapahiwatig na ang node na ito ay isang `Internal` node.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V, Type> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, Type> {
    /// Sinusuri kung ang napapailalim na node ay isang `Internal` node o isang `Leaf` node.
    pub fn force(
        self,
    ) -> ForceResult<
        Handle<NodeRef<BorrowType, K, V, marker::Leaf>, Type>,
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, Type>,
    > {
        match self.node.force() {
            ForceResult::Leaf(node) => {
                ForceResult::Leaf(Handle { node, idx: self.idx, _marker: PhantomData })
            }
            ForceResult::Internal(node) => {
                ForceResult::Internal(Handle { node, idx: self.idx, _marker: PhantomData })
            }
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
    /// Ilipat ang panlapi pagkatapos ng `self` mula sa isang node patungo sa isa pa.Dapat walang laman ang `right`.
    /// Ang unang edge ng `right` ay nananatiling hindi nagbabago.
    pub fn move_suffix(
        &mut self,
        right: &mut NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    ) {
        unsafe {
            let new_left_len = self.idx;
            let mut left_node = self.reborrow_mut().into_node();
            let old_left_len = left_node.len();

            let new_right_len = old_left_len - new_left_len;
            let mut right_node = right.reborrow_mut();

            assert!(right_node.len() == 0);
            assert!(left_node.height == right_node.height);

            if new_right_len > 0 {
                *left_node.len_mut() = new_left_len as u16;
                *right_node.len_mut() = new_right_len as u16;

                move_to_slice(
                    left_node.key_area_mut(new_left_len..old_left_len),
                    right_node.key_area_mut(..new_right_len),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len..old_left_len),
                    right_node.val_area_mut(..new_right_len),
                );
                match (left_node.force(), right_node.force()) {
                    (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                        move_to_slice(
                            left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                            right.edge_area_mut(1..new_right_len + 1),
                        );
                        right.correct_childrens_parent_links(1..new_right_len + 1);
                    }
                    (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                    _ => unreachable!(),
                }
            }
        }
    }
}

pub enum ForceResult<Leaf, Internal> {
    Leaf(Leaf),
    Internal(Internal),
}

/// Resulta ng pagpapasok, kung kailangan ng isang node upang mapalawak nang lampas sa kapasidad nito.
pub struct SplitResult<'a, K, V, NodeType> {
    // Binago ang node sa mayroon nang puno na may mga elemento at gilid na kabilang sa kaliwa ng `kv`.
    pub left: NodeRef<marker::Mut<'a>, K, V, NodeType>,
    // Ang ilang mga key at halaga split, upang maipasok sa ibang lugar.
    pub kv: (K, V),
    // Pag-aari, hindi nakakabit, bagong node na may mga elemento at gilid na kabilang sa kanan ng `kv`.
    pub right: NodeRef<marker::Owned, K, V, NodeType>,
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Leaf> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Internal> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

pub enum InsertResult<'a, K, V, NodeType> {
    Fit(Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV>),
    Split(SplitResult<'a, K, V, NodeType>),
}

pub mod marker {
    use core::marker::PhantomData;

    pub enum Leaf {}
    pub enum Internal {}
    pub enum LeafOrInternal {}

    pub enum Owned {}
    pub enum Dying {}
    pub struct Immut<'a>(PhantomData<&'a ()>);
    pub struct Mut<'a>(PhantomData<&'a mut ()>);
    pub struct ValMut<'a>(PhantomData<&'a mut ()>);

    pub trait BorrowType {
        // Kung ang mga sangguniang node ng uri ng paghiram na ito ay nagpapahintulot sa pagdaan sa iba pang mga node sa puno.
        //
        const PERMITS_TRAVERSAL: bool = true;
    }
    impl BorrowType for Owned {
        // Ang traversal ay hindi kinakailangan, nangyayari ito gamit ang resulta ng `borrow_mut`.
        // Sa pamamagitan ng hindi pagpapagana ng traversal, at paglikha lamang ng mga bagong sanggunian sa mga ugat, alam namin na ang bawat sanggunian ng uri ng `Owned` ay sa isang root node.
        //
        const PERMITS_TRAVERSAL: bool = false;
    }
    impl BorrowType for Dying {}
    impl<'a> BorrowType for Immut<'a> {}
    impl<'a> BorrowType for Mut<'a> {}
    impl<'a> BorrowType for ValMut<'a> {}

    pub enum KV {}
    pub enum Edge {}
}

/// Nagpapasok ng isang halaga sa isang slice ng mga inisyal na elemento na sinusundan ng isang hindi unialitalisadong elemento.
///
/// # Safety
/// Ang slice ay may higit sa `idx` na mga elemento.
unsafe fn slice_insert<T>(slice: &mut [MaybeUninit<T>], idx: usize, val: T) {
    unsafe {
        let len = slice.len();
        debug_assert!(len > idx);
        let slice_ptr = slice.as_mut_ptr();
        if len > idx + 1 {
            ptr::copy(slice_ptr.add(idx), slice_ptr.add(idx + 1), len - idx - 1);
        }
        (*slice_ptr.add(idx)).write(val);
    }
}

/// Tanggalin at ibabalik ang isang halaga mula sa isang slice ng lahat ng mga naisimulang elemento, na iniiwan ang isang sumusunod na hindi na-unialize na elemento.
///
///
/// # Safety
/// Ang slice ay may higit sa `idx` na mga elemento.
unsafe fn slice_remove<T>(slice: &mut [MaybeUninit<T>], idx: usize) -> T {
    unsafe {
        let len = slice.len();
        debug_assert!(idx < len);
        let slice_ptr = slice.as_mut_ptr();
        let ret = (*slice_ptr.add(idx)).assume_init_read();
        ptr::copy(slice_ptr.add(idx + 1), slice_ptr.add(idx), len - idx - 1);
        ret
    }
}

/// Inililipat ang mga elemento sa isang slice `distance` na posisyon sa kaliwa.
///
/// # Safety
/// Ang hiwa ay may hindi bababa sa `distance` na mga elemento.
unsafe fn slice_shl<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr.add(distance), slice_ptr, slice.len() - distance);
    }
}

/// Inililipat ang mga elemento sa isang slice `distance` na posisyon sa kanan.
///
/// # Safety
/// Ang hiwa ay may hindi bababa sa `distance` na mga elemento.
unsafe fn slice_shr<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr, slice_ptr.add(distance), slice.len() - distance);
    }
}

/// Inililipat ang lahat ng mga halaga mula sa isang hiwa ng mga inisyal na elemento sa isang hiwa ng mga hindi unipormalisadong elemento, na iniiwan ang `src` bilang lahat ng hindi naisalisa.
///
/// Gumagana tulad ng `dst.copy_from_slice(src)` ngunit hindi nangangailangan ng `T` upang maging `Copy`.
fn move_to_slice<T>(src: &mut [MaybeUninit<T>], dst: &mut [MaybeUninit<T>]) {
    assert!(src.len() == dst.len());
    unsafe {
        ptr::copy_nonoverlapping(src.as_ptr(), dst.as_mut_ptr(), src.len());
    }
}

#[cfg(test)]
mod tests;