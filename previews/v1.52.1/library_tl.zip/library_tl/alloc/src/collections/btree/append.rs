use super::merge_iter::MergeIterInner;
use super::node::{self, Root};
use core::iter::FusedIterator;

impl<K, V> Root<K, V> {
    /// Nagdaragdag ng lahat ng mga pares na key-halaga mula sa pagsasama ng dalawang pataas na iterator, na nagdaragdag ng isang variable na `length` sa daan.Ginagawang mas madali ng huli para sa tumatawag na maiwasan ang isang tagas kapag nag-panick ang isang drop handler.
    ///
    /// Kung ang parehong mga iterator ay gumagawa ng parehong susi, ang pamamaraang ito ay bumaba ng pares mula sa kaliwang iterator at idinagdag ang pares mula sa kanang iterator.
    ///
    /// Kung nais mo ang puno na magtapos sa isang mahigpit na pataas na pagkakasunud-sunod, tulad ng para sa isang `BTreeMap`, ang parehong mga iterator ay dapat gumawa ng mga susi sa mahigpit na pagkakasunud-sunod na pagkakasunud-sunod, bawat isa ay mas malaki kaysa sa lahat ng mga susi sa puno, kabilang ang anumang mga key na nasa puno nang pumasok.
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn append_from_sorted_iters<I>(&mut self, left: I, right: I, length: &mut usize)
    where
        K: Ord,
        I: Iterator<Item = (K, V)> + FusedIterator,
    {
        // Naghahanda kaming pagsamahin ang `left` at `right` sa isang pinagsunod-sunod na pagkakasunud-sunod sa linear na oras.
        let iter = MergeIter(MergeIterInner::new(left, right));

        // Samantala, nagtatayo kami ng isang puno mula sa pinagsunod-sunod na pagkakasunud-sunod sa linear na oras.
        self.bulk_push(iter, length)
    }

    /// Itinutulak ang lahat ng mga pares na key-value sa dulo ng puno, na nagdaragdag ng isang variable na `length` sa daan.
    /// Ginagawang madali ng huli para sa tumatawag na maiwasan ang isang tagas kapag nag-panic ang iterator.
    ///
    pub fn bulk_push<I>(&mut self, iter: I, length: &mut usize)
    where
        I: Iterator<Item = (K, V)>,
    {
        let mut cur_node = self.borrow_mut().last_leaf_edge().into_node();
        // Iterate sa pamamagitan ng lahat ng mga pares ng key-halaga, itulak ang mga ito sa mga node sa tamang antas.
        for (key, value) in iter {
            // Subukang itulak ang pares ng key-value sa kasalukuyang leaf node.
            if cur_node.len() < node::CAPACITY {
                cur_node.push(key, value);
            } else {
                // Walang natitirang puwang, umakyat at itulak doon.
                let mut open_node;
                let mut test_node = cur_node.forget_type();
                loop {
                    match test_node.ascend() {
                        Ok(parent) => {
                            let parent = parent.into_node();
                            if parent.len() < node::CAPACITY {
                                // Natagpuan ang isang node na may natitirang puwang, itulak dito.
                                open_node = parent;
                                break;
                            } else {
                                // Umakyat ulit.
                                test_node = parent.forget_type();
                            }
                        }
                        Err(_) => {
                            // Nasa tuktok kami, lumikha ng isang bagong root node at itulak doon.
                            open_node = self.push_internal_level();
                            break;
                        }
                    }
                }

                // Itulak ang pares ng key-halaga at bagong kanang subtree.
                let tree_height = open_node.height() - 1;
                let mut right_tree = Root::new();
                for _ in 0..tree_height {
                    right_tree.push_internal_level();
                }
                open_node.push(key, value, right_tree);

                // Bumaba muli sa kanang-pinaka dahon.
                cur_node = open_node.forget_type().last_leaf_edge().into_node();
            }

            // Dagdagan ang haba ng bawat pag-ulit, upang matiyak na ang mapa ay bumaba ng mga naidugtong na elemento kahit na isusulong ang mga panick ng iterator.
            //
            *length += 1;
        }
        self.fix_right_border_of_plentiful();
    }
}

// Isang iterator para sa pagsasama-sama ng dalawang pinagsunod-sunod na mga pagkakasunud-sunod sa isa
struct MergeIter<K, V, I: Iterator<Item = (K, V)>>(MergeIterInner<I>);

impl<K: Ord, V, I> Iterator for MergeIter<K, V, I>
where
    I: Iterator<Item = (K, V)> + FusedIterator,
{
    type Item = (K, V);

    /// Kung ang dalawang mga susi ay pantay, ibabalik ang pares ng key-halaga mula sa tamang mapagkukunan.
    fn next(&mut self) -> Option<(K, V)> {
        let (a_next, b_next) = self.0.nexts(|a: &(K, V), b: &(K, V)| K::cmp(&a.0, &b.0));
        b_next.or(a_next)
    }
}