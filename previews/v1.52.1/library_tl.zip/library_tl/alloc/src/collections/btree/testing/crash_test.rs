use crate::fmt::Debug;
use std::cmp::Ordering;
use std::sync::atomic::{AtomicUsize, Ordering::SeqCst};

/// Isang blueprint para sa mga pagsubok sa crash test dummy na nagsubaybay sa mga partikular na kaganapan.
/// Ang ilang mga pagkakataon ay maaaring mai-configure sa panic sa ilang mga punto.
/// Ang mga kaganapan ay `clone`, `drop` o ilang hindi nagpapakilalang `query`.
///
/// Ang mga dummies sa pag-crash ng crash ay nakilala at nai-order ng isang id, upang maaari silang magamit bilang mga susi sa isang BTreeMap.
/// Ang pagpapatupad na sadyang ginagamit ay hindi umaasa sa anumang tinukoy sa crate, bukod sa `Debug` trait.
///
#[derive(Debug)]
pub struct CrashTestDummy {
    id: usize,
    cloned: AtomicUsize,
    dropped: AtomicUsize,
    queried: AtomicUsize,
}

impl CrashTestDummy {
    /// Lumilikha ng disenyo ng dummy na pagsubok sa pag-crash.Tinutukoy ng `id` ang pagkakasunud-sunod at pagkakapantay-pantay ng mga pagkakataon.
    pub fn new(id: usize) -> CrashTestDummy {
        CrashTestDummy {
            id,
            cloned: AtomicUsize::new(0),
            dropped: AtomicUsize::new(0),
            queried: AtomicUsize::new(0),
        }
    }

    /// Lumilikha ng isang halimbawa ng isang pagsubok sa pag-crash test na nagtatala kung anong mga kaganapan ang nararanasan nito at opsyonal na panics.
    ///
    pub fn spawn(&self, panic: Panic) -> Instance<'_> {
        Instance { origin: self, panic }
    }

    /// Ibinabalik kung gaano karaming beses na na-clone ang mga pagkakataon ng dummy.
    pub fn cloned(&self) -> usize {
        self.cloned.load(SeqCst)
    }

    /// Ibinabalik kung gaano karaming beses na naiwan ang mga pagkakataon ng dummy.
    pub fn dropped(&self) -> usize {
        self.dropped.load(SeqCst)
    }

    /// Ibinabalik kung gaano karaming beses ang mga pagkakataon ng dummy na naimbitahan ang kanilang miyembro na `query`.
    pub fn queried(&self) -> usize {
        self.queried.load(SeqCst)
    }
}

#[derive(Debug)]
pub struct Instance<'a> {
    origin: &'a CrashTestDummy,
    panic: Panic,
}

#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub enum Panic {
    Never,
    InClone,
    InDrop,
    InQuery,
}

impl Instance<'_> {
    pub fn id(&self) -> usize {
        self.origin.id
    }

    /// Ang ilang hindi nagpapakilalang query, na ang resulta ay naibigay na.
    pub fn query<R>(&self, result: R) -> R {
        self.origin.queried.fetch_add(1, SeqCst);
        if self.panic == Panic::InQuery {
            panic!("panic in `query`");
        }
        result
    }
}

impl Clone for Instance<'_> {
    fn clone(&self) -> Self {
        self.origin.cloned.fetch_add(1, SeqCst);
        if self.panic == Panic::InClone {
            panic!("panic in `clone`");
        }
        Self { origin: self.origin, panic: Panic::Never }
    }
}

impl Drop for Instance<'_> {
    fn drop(&mut self) {
        self.origin.dropped.fetch_add(1, SeqCst);
        if self.panic == Panic::InDrop {
            panic!("panic in `drop`");
        }
    }
}

impl PartialOrd for Instance<'_> {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.id().partial_cmp(&other.id())
    }
}

impl Ord for Instance<'_> {
    fn cmp(&self, other: &Self) -> Ordering {
        self.id().cmp(&other.id())
    }
}

impl PartialEq for Instance<'_> {
    fn eq(&self, other: &Self) -> bool {
        self.id().eq(&other.id())
    }
}

impl Eq for Instance<'_> {}