//! Ang isang dobleng pagtatapos na pila na ipinatupad sa isang maaaring palakasin na buffer ng singsing.
//!
//! Ang pila na ito ay may *O*(1) na amortized na pagsingit at pagtanggal mula sa magkabilang dulo ng lalagyan.
//! Mayroon din itong *O*(1) pag-index tulad ng isang vector.
//! Ang mga nakapaloob na elemento ay hindi kinakailangan upang maging makopya, at ang pila ay maipapadala kung ang nakapaloob na uri ay maipapadala.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::cmp::{self, Ordering};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::iter::{repeat_with, FromIterator};
use core::marker::PhantomData;
use core::mem::{self, ManuallyDrop};
use core::ops::{Index, IndexMut, Range, RangeBounds};
use core::ptr::{self, NonNull};
use core::slice;

use crate::collections::TryReserveError;
use crate::raw_vec::RawVec;
use crate::vec::Vec;

#[macro_use]
mod macros;

#[stable(feature = "drain", since = "1.6.0")]
pub use self::drain::Drain;

mod drain;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::iter_mut::IterMut;

mod iter_mut;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::into_iter::IntoIter;

mod into_iter;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::iter::Iter;

mod iter;

use self::pair_slices::PairSlices;

mod pair_slices;

use self::ring_slices::RingSlices;

mod ring_slices;

#[cfg(test)]
mod tests;

const INITIAL_CAPACITY: usize = 7; // 2 ^ 3, 1
const MINIMUM_CAPACITY: usize = 1; // 2, 1

const MAXIMUM_ZST_CAPACITY: usize = 1 << (core::mem::size_of::<usize>() * 8 - 1); // Pinakamalaking posibleng kapangyarihan ng dalawa

/// Ang isang dobleng pagtatapos na pila na ipinatupad sa isang maaaring palakasin na buffer ng singsing.
///
/// Ang paggamit ng "default" ng ganitong uri bilang isang pila ay ang paggamit ng [`push_back`] upang idagdag sa pila, at [`pop_front`] upang alisin mula sa pila.
///
/// [`extend`] at [`append`] itulak papunta sa likuran sa paraang ito, at ang pag-ulit sa `VecDeque` ay papunta sa likod.
///
/// Dahil ang `VecDeque` ay isang ring buffer, ang mga elemento nito ay hindi kinakailangang magkadikit sa memorya.
/// Kung nais mong i-access ang mga elemento bilang isang solong hiwa, tulad ng para sa mahusay na pag-uuri, maaari mong gamitin ang [`make_contiguous`].
/// Paikutin nito ang `VecDeque` upang ang mga elemento nito ay hindi balutin, at ibabalik ang isang nababagabag na hiwa sa ngayon na magkadikit na pagkakasunud-sunod ng elemento.
///
/// [`push_back`]: VecDeque::push_back
/// [`pop_front`]: VecDeque::pop_front
/// [`extend`]: VecDeque::extend
/// [`append`]: VecDeque::append
/// [`make_contiguous`]: VecDeque::make_contiguous
///
///
///
#[cfg_attr(not(test), rustc_diagnostic_item = "vecdeque_type")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct VecDeque<T> {
    // ang buntot at ulo ay itinuro sa buffer.
    // Palaging itinuturo ng buntot ang unang elemento na maaaring mabasa, Laging itinuturo ng Head kung saan dapat isulat ang data.
    //
    // Kung buntot==ulo ang buffer ay walang laman.Ang haba ng ringbuffer ay tinukoy bilang ang distansya sa pagitan ng dalawa.
    //
    tail: usize,
    head: usize,
    buf: RawVec<T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for VecDeque<T> {
    fn clone(&self) -> VecDeque<T> {
        self.iter().cloned().collect()
    }

    fn clone_from(&mut self, other: &Self) {
        self.truncate(other.len());

        let mut iter = PairSlices::from(self, other);
        while let Some((dst, src)) = iter.next() {
            dst.clone_from_slice(&src);
        }

        if iter.has_remainder() {
            for remainder in iter.remainder() {
                self.extend(remainder.iter().cloned());
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T> Drop for VecDeque<T> {
    fn drop(&mut self) {
        /// Pinapatakbo ang destructor para sa lahat ng mga item sa hiwa kapag nahulog ito (normal o habang nag-aalis nginday).
        ///
        struct Dropper<'a, T>(&'a mut [T]);

        impl<'a, T> Drop for Dropper<'a, T> {
            fn drop(&mut self) {
                unsafe {
                    ptr::drop_in_place(self.0);
                }
            }
        }

        let (front, back) = self.as_mut_slices();
        unsafe {
            let _back_dropper = Dropper(back);
            // gumamit ng drop para sa [T]
            ptr::drop_in_place(front);
        }
        // Hinahawakan ng RawVec ang paglipat ng transaksyon
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for VecDeque<T> {
    /// Lumilikha ng isang walang laman na `VecDeque<T>`.
    #[inline]
    fn default() -> VecDeque<T> {
        VecDeque::new()
    }
}

impl<T> VecDeque<T> {
    /// Marginally mas maginhawa
    #[inline]
    fn ptr(&self) -> *mut T {
        self.buf.ptr()
    }

    /// Marginally mas maginhawa
    #[inline]
    fn cap(&self) -> usize {
        if mem::size_of::<T>() == 0 {
            // Para sa mga walang sukat na uri, palagi kaming nasa maximum na kapasidad
            MAXIMUM_ZST_CAPACITY
        } else {
            self.buf.capacity()
        }
    }

    /// Gawing isang slice ang ptr
    #[inline]
    unsafe fn buffer_as_slice(&self) -> &[T] {
        unsafe { slice::from_raw_parts(self.ptr(), self.cap()) }
    }

    /// Gawin ang mut slice
    #[inline]
    unsafe fn buffer_as_mut_slice(&mut self) -> &mut [T] {
        unsafe { slice::from_raw_parts_mut(self.ptr(), self.cap()) }
    }

    /// Inililipat ang isang elemento sa labas ng buffer
    #[inline]
    unsafe fn buffer_read(&mut self, off: usize) -> T {
        unsafe { ptr::read(self.ptr().add(off)) }
    }

    /// Nagsusulat ng isang elemento sa buffer, inililipat ito.
    #[inline]
    unsafe fn buffer_write(&mut self, off: usize, value: T) {
        unsafe {
            ptr::write(self.ptr().add(off), value);
        }
    }

    /// Ibinabalik ang `true` kung ang buffer ay nasa buong kapasidad.
    #[inline]
    fn is_full(&self) -> bool {
        self.cap() - self.len() == 1
    }

    /// Ibinabalik ang index sa pinagbabatayan na buffer para sa isang naibigay na lohikal na index ng elemento.
    ///
    #[inline]
    fn wrap_index(&self, idx: usize) -> usize {
        wrap_index(idx, self.cap())
    }

    /// Ibinabalik ang index sa pinagbabatayan na buffer para sa isang naibigay na lohikal na index ng elemento + na addend.
    ///
    #[inline]
    fn wrap_add(&self, idx: usize, addend: usize) -> usize {
        wrap_index(idx.wrapping_add(addend), self.cap())
    }

    /// Ibinabalik ang index sa pinagbabatayan na buffer para sa isang naibigay na lohikal na index ng elemento, subtrahend.
    ///
    #[inline]
    fn wrap_sub(&self, idx: usize, subtrahend: usize) -> usize {
        wrap_index(idx.wrapping_sub(subtrahend), self.cap())
    }

    /// Kinokopya ang isang magkadugtong na bloke ng memorya ng len mula sa src hanggang dst
    #[inline]
    unsafe fn copy(&self, dst: usize, src: usize, len: usize) {
        debug_assert!(
            dst + len <= self.cap(),
            "cpy dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        debug_assert!(
            src + len <= self.cap(),
            "cpy dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        unsafe {
            ptr::copy(self.ptr().add(src), self.ptr().add(dst), len);
        }
    }

    /// Kinokopya ang isang magkadugtong na bloke ng memorya ng len mula sa src hanggang dst
    #[inline]
    unsafe fn copy_nonoverlapping(&self, dst: usize, src: usize, len: usize) {
        debug_assert!(
            dst + len <= self.cap(),
            "cno dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        debug_assert!(
            src + len <= self.cap(),
            "cno dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        unsafe {
            ptr::copy_nonoverlapping(self.ptr().add(src), self.ptr().add(dst), len);
        }
    }

    /// Kinokopya ang isang potensyal na pambalot na bloke ng memorya ng len mula sa src hanggang sa dest.
    /// (abs(dst - src) + len) ay dapat na hindi mas malaki sa cap() (Dapat mayroong hindi hihigit sa isang tuloy-tuloy na magkakapatong na rehiyon sa pagitan ng src at dest).
    ///
    unsafe fn wrap_copy(&self, dst: usize, src: usize, len: usize) {
        #[allow(dead_code)]
        fn diff(a: usize, b: usize) -> usize {
            if a <= b { b - a } else { a - b }
        }
        debug_assert!(
            cmp::min(diff(dst, src), self.cap() - diff(dst, src)) + len <= self.cap(),
            "wrc dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );

        if src == dst || len == 0 {
            return;
        }

        let dst_after_src = self.wrap_sub(dst, src) < len;

        let src_pre_wrap_len = self.cap() - src;
        let dst_pre_wrap_len = self.cap() - dst;
        let src_wraps = src_pre_wrap_len < len;
        let dst_wraps = dst_pre_wrap_len < len;

        match (dst_after_src, src_wraps, dst_wraps) {
            (_, false, false) => {
                // Ang src ay hindi balot, hindi balot ng dst
                //
                //        S...
                // 1 [_ _ A A B B C C _]
                // 2 [_ _ A A A A B B _] D.
                // .
                // .
                unsafe {
                    self.copy(dst, src, len);
                }
            }
            (false, false, true) => {
                // dst bago ang src, src ay hindi balot, balot ng dst
                //
                //
                //    S...
                // 1 [A A B B _ _ _ C C]
                // 2 [A A B B _ _ _ A A]
                // 3 [B B B B _ _ _ A A] .. D.
                //
                unsafe {
                    self.copy(dst, src, dst_pre_wrap_len);
                    self.copy(0, src + dst_pre_wrap_len, len - dst_pre_wrap_len);
                }
            }
            (true, false, true) => {
                // Ang src bago ang dst, ang src ay hindi balot, binabalot ng dst
                //
                //
                //              S...
                // 1 [C C _ _ _ A A B B]
                // 2 [B B _ _ _ A A B B]
                // 3 [B B _ _ _ A A A A] .. D.
                //
                unsafe {
                    self.copy(0, src + dst_pre_wrap_len, len - dst_pre_wrap_len);
                    self.copy(dst, src, dst_pre_wrap_len);
                }
            }
            (false, true, false) => {
                // dst bago ang src, src ay nagbabalot, dst ay hindi balot
                //
                //
                //    .. S.
                // 1 [C C _ _ _ A A B B]
                // 2 [C C _ _ _ B B B B]
                // 3 [C C _ _ _ B B C C] D...
                //
                unsafe {
                    self.copy(dst, src, src_pre_wrap_len);
                    self.copy(dst + src_pre_wrap_len, 0, len - src_pre_wrap_len);
                }
            }
            (true, true, false) => {
                // Ang src bago ang dst, ang src ay nagbabalot, ang dst ay hindi balot
                //
                //
                //    .. S.
                // 1 [A A B B _ _ _ C C]
                // 2 [A A A A _ _ _ C C]
                // 3 [C C A A _ _ _ C C] D...
                //
                unsafe {
                    self.copy(dst + src_pre_wrap_len, 0, len - src_pre_wrap_len);
                    self.copy(dst, src, src_pre_wrap_len);
                }
            }
            (false, true, true) => {
                // dst bago ang src, ang src ay nagbabalot, ang dst ay nakabalot
                //
                //
                //    ... S.
                // 1 [A B C D _ E F G H]
                // 2 [A B C D _ E G H H]
                // 3 [A B C D _ E G H A]
                // 4 [B C C D _ E G H A] .. D..
                //
                debug_assert!(dst_pre_wrap_len > src_pre_wrap_len);
                let delta = dst_pre_wrap_len - src_pre_wrap_len;
                unsafe {
                    self.copy(dst, src, src_pre_wrap_len);
                    self.copy(dst + src_pre_wrap_len, 0, delta);
                    self.copy(0, delta, len - dst_pre_wrap_len);
                }
            }
            (true, true, true) => {
                // Ang src bago ang dst, ang src ay nagbabalot, ang dst ay nakabalot
                //
                //
                //    .. S..
                // 1 [A B C D _ E F G H]
                // 2 [A A B D _ E F G H]
                // 3 [H A B D _ E F G H]
                // 4 [H A B D _ E F F G]... D.
                //
                debug_assert!(src_pre_wrap_len > dst_pre_wrap_len);
                let delta = src_pre_wrap_len - dst_pre_wrap_len;
                unsafe {
                    self.copy(delta, 0, len - src_pre_wrap_len);
                    self.copy(0, self.cap() - delta, delta);
                    self.copy(dst, src, dst_pre_wrap_len);
                }
            }
        }
    }

    /// Frobs ang mga seksyon ng ulo at buntot sa paligid upang mahawakan ang katotohanan na nag-reallocate lamang kami.
    /// Hindi ligtas dahil nagtitiwala ito sa old_capacity.
    #[inline]
    unsafe fn handle_capacity_increase(&mut self, old_capacity: usize) {
        let new_capacity = self.cap();

        // Ilipat ang pinakamaikling magkadikit na seksyon ng ring buffer TH
        //
        //   [o o o o o o o . ]
        //    THA [o o o o o o o . . . . . . . . . ] HT
        //   [o o . o o o o o ]
        //          THB [...ooooooo.....
        //          ] HT
        //   [o o o o o . o o ]
        //              HTC [o o o o o . . . . . . . . . o o ]
        //
        //
        //
        //

        if self.tail <= self.head {
            // Isang Nop
            //
        } else if self.head < old_capacity - self.tail {
            // B
            unsafe {
                self.copy_nonoverlapping(old_capacity, 0, self.head);
            }
            self.head += old_capacity;
            debug_assert!(self.head > self.tail);
        } else {
            // C
            let new_tail = new_capacity - (old_capacity - self.tail);
            unsafe {
                self.copy_nonoverlapping(new_tail, self.tail, old_capacity - self.tail);
            }
            self.tail = new_tail;
            debug_assert!(self.head < self.tail);
        }
        debug_assert!(self.head < self.cap());
        debug_assert!(self.tail < self.cap());
        debug_assert!(self.cap().count_ones() == 1);
    }
}

impl<T> VecDeque<T> {
    /// Lumilikha ng isang walang laman na `VecDeque`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let vector: VecDeque<u32> = VecDeque::new();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new() -> VecDeque<T> {
        VecDeque::with_capacity(INITIAL_CAPACITY)
    }

    /// Lumilikha ng isang walang laman na `VecDeque` na may puwang para sa hindi bababa sa `capacity` na mga elemento.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let vector: VecDeque<u32> = VecDeque::with_capacity(10);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> VecDeque<T> {
        // +1 dahil palaging iniiwan ng ringbuffer na walang laman ang isang puwang
        let cap = cmp::max(capacity + 1, MINIMUM_CAPACITY + 1).next_power_of_two();
        assert!(cap > capacity, "capacity overflow");

        VecDeque { tail: 0, head: 0, buf: RawVec::with_capacity(cap) }
    }

    /// Nagbibigay ng isang sanggunian sa elemento sa ibinigay na index.
    ///
    /// Ang elemento sa index 0 ay ang harap ng pila.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// buf.push_back(5);
    /// assert_eq!(buf.get(1), Some(&4));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get(&self, index: usize) -> Option<&T> {
        if index < self.len() {
            let idx = self.wrap_add(self.tail, index);
            unsafe { Some(&*self.ptr().add(idx)) }
        } else {
            None
        }
    }

    /// Nagbibigay ng isang nababagong sanggunian sa elemento sa ibinigay na index.
    ///
    /// Ang elemento sa index 0 ay ang harap ng pila.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// buf.push_back(5);
    /// if let Some(elem) = buf.get_mut(1) {
    ///     *elem = 7;
    /// }
    ///
    /// assert_eq!(buf[1], 7);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get_mut(&mut self, index: usize) -> Option<&mut T> {
        if index < self.len() {
            let idx = self.wrap_add(self.tail, index);
            unsafe { Some(&mut *self.ptr().add(idx)) }
        } else {
            None
        }
    }

    /// Nagpapalit ng mga elemento sa mga indeks ng `i` at `j`.
    ///
    /// `i` at `j` ay maaaring pantay.
    ///
    /// Ang elemento sa index 0 ay ang harap ng pila.
    ///
    /// # Panics
    ///
    /// Panics kung ang alinman sa index ay wala sa mga hangganan.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// buf.push_back(5);
    /// assert_eq!(buf, [3, 4, 5]);
    /// buf.swap(0, 2);
    /// assert_eq!(buf, [5, 4, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn swap(&mut self, i: usize, j: usize) {
        assert!(i < self.len());
        assert!(j < self.len());
        let ri = self.wrap_add(self.tail, i);
        let rj = self.wrap_add(self.tail, j);
        unsafe { ptr::swap(self.ptr().add(ri), self.ptr().add(rj)) }
    }

    /// Ibinabalik ang bilang ng mga elemento na maaaring hawakan ng `VecDeque` nang hindi nagre-reallocate.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let buf: VecDeque<i32> = VecDeque::with_capacity(10);
    /// assert!(buf.capacity() >= 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.cap() - 1
    }

    /// Inireserba ang minimum na kapasidad para sa eksaktong `additional` higit pang mga elemento na maipasok sa ibinigay na `VecDeque`.
    /// Walang ginagawa kung ang kapasidad ay sapat na.
    ///
    /// Tandaan na ang tagapagtalaga ay maaaring magbigay sa koleksyon ng mas maraming puwang kaysa sa hiniling nito.
    /// Samakatuwid ang kapasidad ay hindi maaasahan na maging tumpak na minimal.
    /// Mas gusto ang [`reserve`] kung inaasahan ang mga pagpasok ng future.
    ///
    /// # Panics
    ///
    /// Panics kung ang bagong kapasidad ay umaapaw sa `usize`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<i32> = vec![1].into_iter().collect();
    /// buf.reserve_exact(10);
    /// assert!(buf.capacity() >= 11);
    /// ```
    ///
    /// [`reserve`]: VecDeque::reserve
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.reserve(additional);
    }

    /// Nakalaan ang kapasidad para sa hindi bababa sa `additional` higit pang mga elemento na maipasok sa ibinigay na `VecDeque`.
    /// Ang koleksyon ay maaaring magreserba ng mas maraming puwang upang maiwasan ang madalas na mga reallocation.
    ///
    /// # Panics
    ///
    /// Panics kung ang bagong kapasidad ay umaapaw sa `usize`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<i32> = vec![1].into_iter().collect();
    /// buf.reserve(10);
    /// assert!(buf.capacity() >= 11);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        let old_cap = self.cap();
        let used_cap = self.len() + 1;
        let new_cap = used_cap
            .checked_add(additional)
            .and_then(|needed_cap| needed_cap.checked_next_power_of_two())
            .expect("capacity overflow");

        if new_cap > old_cap {
            self.buf.reserve_exact(used_cap, new_cap - used_cap);
            unsafe {
                self.handle_capacity_increase(old_cap);
            }
        }
    }

    /// Sinusubukan na ireserba ang minimum na kapasidad para sa eksaktong `additional` higit pang mga elemento na maipasok sa ibinigay na `VecDeque<T>`.
    ///
    /// Matapos tumawag sa `try_reserve_exact`, ang kapasidad ay magiging mas malaki sa o katumbas ng `self.len() + additional`.
    /// Walang ginagawa kung ang kapasidad ay sapat na.
    ///
    /// Tandaan na ang tagapagtalaga ay maaaring magbigay sa koleksyon ng mas maraming puwang kaysa sa hiniling nito.
    /// Samakatuwid, ang kakayahan ay hindi maaasahan na maging tiyak na minimal.
    /// Mas gusto ang `reserve` kung inaasahan ang mga pagpasok ng future.
    ///
    /// # Errors
    ///
    /// Kung umaapaw ang kapasidad `usize`, o ang tagapaglaan ay nag-uulat ng pagkabigo, pagkatapos ay may isang error na ibinalik.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    /// use std::collections::VecDeque;
    ///
    /// fn process_data(data: &[u32]) -> Result<VecDeque<u32>, TryReserveError> {
    ///     let mut output = VecDeque::new();
    ///
    ///     // I-paunang reserba ang memorya, paglabas kung hindi namin magawa
    ///     output.try_reserve_exact(data.len())?;
    ///
    ///     // Ngayon alam namin na hindi ito maaaring OOM(Out-Of-Memory) sa gitna ng aming kumplikadong gawain
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // sobrang kumplikado
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.try_reserve(additional)
    }

    /// Sinusubukan upang magreserba ng kapasidad para sa hindi bababa sa `additional` higit pang mga elemento na maipasok sa ibinigay na `VecDeque<T>`.
    /// Ang koleksyon ay maaaring magreserba ng mas maraming puwang upang maiwasan ang madalas na mga reallocation.
    /// Matapos tumawag sa `try_reserve`, ang kapasidad ay magiging mas malaki sa o katumbas ng `self.len() + additional`.
    /// Walang ginagawa kung sapat na ang kapasidad.
    ///
    /// # Errors
    ///
    /// Kung umaapaw ang kapasidad `usize`, o ang tagapaglaan ay nag-uulat ng pagkabigo, pagkatapos ay may isang error na ibinalik.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    /// use std::collections::VecDeque;
    ///
    /// fn process_data(data: &[u32]) -> Result<VecDeque<u32>, TryReserveError> {
    ///     let mut output = VecDeque::new();
    ///
    ///     // I-paunang reserba ang memorya, paglabas kung hindi namin magawa
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Ngayon alam namin na hindi ito maaaring OOM sa gitna ng aming kumplikadong gawain
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // sobrang kumplikado
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        let old_cap = self.cap();
        let used_cap = self.len() + 1;
        let new_cap = used_cap
            .checked_add(additional)
            .and_then(|needed_cap| needed_cap.checked_next_power_of_two())
            .ok_or(TryReserveError::CapacityOverflow)?;

        if new_cap > old_cap {
            self.buf.try_reserve_exact(used_cap, new_cap - used_cap)?;
            unsafe {
                self.handle_capacity_increase(old_cap);
            }
        }
        Ok(())
    }

    /// Pinapaliit ang kapasidad ng `VecDeque` hangga't maaari.
    ///
    /// Babagsak ito nang mas malapit hangga't maaari sa haba ngunit maaaring ipagbigay-alam pa rin ng tagapaglaan sa `VecDeque` na may puwang para sa ilang mga elemento pa.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::with_capacity(15);
    /// buf.extend(0..4);
    /// assert_eq!(buf.capacity(), 15);
    /// buf.shrink_to_fit();
    /// assert!(buf.capacity() >= 4);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn shrink_to_fit(&mut self) {
        self.shrink_to(0);
    }

    /// Pinapaliit ang kapasidad ng `VecDeque` na may mas mababang gapos.
    ///
    /// Ang kapasidad ay mananatiling hindi bababa sa kasing laki ng parehong haba at ang ibinigay na halaga.
    ///
    ///
    /// Kung ang kasalukuyang kapasidad ay mas mababa sa mas mababang limitasyon, ito ay isang no-op.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::with_capacity(15);
    /// buf.extend(0..4);
    /// assert_eq!(buf.capacity(), 15);
    /// buf.shrink_to(6);
    /// assert!(buf.capacity() >= 6);
    /// buf.shrink_to(0);
    /// assert!(buf.capacity() >= 4);
    /// ```
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        let min_capacity = cmp::min(min_capacity, self.capacity());
        // Hindi namin kailangang mag-alala tungkol sa isang overflow dahil alinman sa `self.len()` o `self.capacity()` ay maaaring maging `usize::MAX`.
        // +1 bilang palaging iniiwan ng ringbuffer ang isang puwang na walang laman.
        let target_cap = cmp::max(cmp::max(min_capacity, self.len()) + 1, MINIMUM_CAPACITY + 1)
            .next_power_of_two();

        if target_cap < self.cap() {
            // Mayroong tatlong mga kaso ng interes:
            //   Ang lahat ng mga elemento ay wala sa mga hinahangad na hangganan Ang mga elemento ay magkadikit, at ang ulo ay wala sa mga hinahangad na hangganan Ang mga elemento ay hindi sigurado, at ang buntot ay wala sa nais na mga hangganan
            //
            //
            // Sa lahat ng iba pang mga oras, ang mga posisyon ng elemento ay hindi maaapektuhan.
            //
            // Ipinapahiwatig na ang mga elemento sa ulo ay dapat ilipat.
            //
            let head_outside = self.head == 0 || self.head >= target_cap;
            // Ilipat ang mga elemento mula sa mga nais na hangganan (mga posisyon pagkatapos ng target_cap)
            if self.tail >= target_cap && head_outside {
                // TH
                //   [. . . . . . . . o o o o o o o . ]
                //    TH
                //   [o o o o o o o . ]
                unsafe {
                    self.copy_nonoverlapping(0, self.tail, self.len());
                }
                self.head = self.len();
                self.tail = 0;
            } else if self.tail != 0 && self.tail < target_cap && head_outside {
                // TH
                //   [. . . o o o o o o o . . . . . . ]
                //        H T
                //   [o o . o o o o o ]
                let len = self.wrap_sub(self.head, target_cap);
                unsafe {
                    self.copy_nonoverlapping(0, target_cap, len);
                }
                self.head = len;
                debug_assert!(self.head < self.tail);
            } else if self.tail >= target_cap {
                // HT
                //   [o o o o o . . . . . . . . . o o ]
                //              H T
                //   [o o o o o . o o ]
                debug_assert!(self.wrap_sub(self.head, 1) < target_cap);
                let len = self.cap() - self.tail;
                let new_tail = target_cap - len;
                unsafe {
                    self.copy_nonoverlapping(new_tail, self.tail, len);
                }
                self.tail = new_tail;
                debug_assert!(self.head < self.tail);
            }

            self.buf.shrink_to_fit(target_cap);

            debug_assert!(self.head < self.cap());
            debug_assert!(self.tail < self.cap());
            debug_assert!(self.cap().count_ones() == 1);
        }
    }

    /// Paikliin ang `VecDeque`, pinapanatili ang mga unang elemento ng `len` at hinuhulog ang natitira.
    ///
    ///
    /// Kung ang `len` ay mas malaki kaysa sa kasalukuyang haba ng `VecDeque`, wala itong epekto.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(10);
    /// buf.push_back(15);
    /// assert_eq!(buf, [5, 10, 15]);
    /// buf.truncate(1);
    /// assert_eq!(buf, [5]);
    /// ```
    ///
    #[stable(feature = "deque_extras", since = "1.16.0")]
    pub fn truncate(&mut self, len: usize) {
        /// Pinapatakbo ang destructor para sa lahat ng mga item sa hiwa kapag nahulog ito (normal o habang nag-aalis nginday).
        ///
        struct Dropper<'a, T>(&'a mut [T]);

        impl<'a, T> Drop for Dropper<'a, T> {
            fn drop(&mut self) {
                unsafe {
                    ptr::drop_in_place(self.0);
                }
            }
        }

        // Ligtas dahil:
        //
        // * Anumang hiwa na naipasa sa `drop_in_place` ay may bisa;ang pangalawang kaso ay may `len <= front.len()` at ang pagbabalik sa `len > self.len()` ay tinitiyak ang `begin <= back.len()` sa unang kaso
        //
        // * Ang ulo ng VecDeque ay inilipat bago tumawag sa `drop_in_place`, kaya walang halaga na nahulog nang dalawang beses kung `drop_in_place` panics
        //
        //
        unsafe {
            if len > self.len() {
                return;
            }
            let num_dropped = self.len() - len;
            let (front, back) = self.as_mut_slices();
            if len > front.len() {
                let begin = len - front.len();
                let drop_back = back.get_unchecked_mut(begin..) as *mut _;
                self.head = self.wrap_sub(self.head, num_dropped);
                ptr::drop_in_place(drop_back);
            } else {
                let drop_back = back as *mut _;
                let drop_front = front.get_unchecked_mut(len..) as *mut _;
                self.head = self.wrap_sub(self.head, num_dropped);

                // Siguraduhin na ang ikalawang kalahati ay nahulog kahit na ang isang destructor sa una sa panics.
                //
                let _back_dropper = Dropper(&mut *drop_back);
                ptr::drop_in_place(drop_front);
            }
        }
    }

    /// Nagbabalik ng isang front-to-back na iterator.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// let b: &[_] = &[&5, &3, &4];
    /// let c: Vec<&i32> = buf.iter().collect();
    /// assert_eq!(&c[..], b);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter { tail: self.tail, head: self.head, ring: unsafe { self.buffer_as_slice() } }
    }

    /// Nagbabalik ng isang front-to-back na iterator na nagbabalik ng mga nababagong sanggunian.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// for num in buf.iter_mut() {
    ///     *num = *num - 2;
    /// }
    /// let b: &[_] = &[&mut 3, &mut 1, &mut 2];
    /// assert_eq!(&buf.iter_mut().collect::<Vec<&mut i32>>()[..], b);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        // KALIGTASAN: Ang panloob na kaligtasan sa `IterMut` kaligtasan ay itinatag dahil ang
        // `ring` nilikha namin ay isang hindi mapipigilan hiwa para sa panghabang buhay '_.
        IterMut {
            tail: self.tail,
            head: self.head,
            ring: ptr::slice_from_raw_parts_mut(self.ptr(), self.cap()),
            phantom: PhantomData,
        }
    }

    /// Ibinabalik ang isang pares ng mga hiwa na naglalaman, sa pagkakasunud-sunod, ng mga nilalaman ng `VecDeque`.
    ///
    /// Kung ang [`make_contiguous`] ay dating tinawag, ang lahat ng mga elemento ng `VecDeque` ay magiging sa unang hiwa at ang pangalawang hiwa ay walang laman.
    ///
    ///
    /// [`make_contiguous`]: VecDeque::make_contiguous
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vector = VecDeque::new();
    ///
    /// vector.push_back(0);
    /// vector.push_back(1);
    /// vector.push_back(2);
    ///
    /// assert_eq!(vector.as_slices(), (&[0, 1, 2][..], &[][..]));
    ///
    /// vector.push_front(10);
    /// vector.push_front(9);
    ///
    /// assert_eq!(vector.as_slices(), (&[9, 10][..], &[0, 1, 2][..]));
    /// ```
    ///
    #[inline]
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn as_slices(&self) -> (&[T], &[T]) {
        unsafe {
            let buf = self.buffer_as_slice();
            RingSlices::ring_slices(buf, self.head, self.tail)
        }
    }

    /// Ibinabalik ang isang pares ng mga hiwa na naglalaman, sa pagkakasunud-sunod, ng mga nilalaman ng `VecDeque`.
    ///
    /// Kung ang [`make_contiguous`] ay dating tinawag, ang lahat ng mga elemento ng `VecDeque` ay magiging sa unang hiwa at ang pangalawang hiwa ay walang laman.
    ///
    ///
    /// [`make_contiguous`]: VecDeque::make_contiguous
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vector = VecDeque::new();
    ///
    /// vector.push_back(0);
    /// vector.push_back(1);
    ///
    /// vector.push_front(10);
    /// vector.push_front(9);
    ///
    /// vector.as_mut_slices().0[0] = 42;
    /// vector.as_mut_slices().1[0] = 24;
    /// assert_eq!(vector.as_slices(), (&[42, 10][..], &[24, 1][..]));
    /// ```
    ///
    #[inline]
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn as_mut_slices(&mut self) -> (&mut [T], &mut [T]) {
        unsafe {
            let head = self.head;
            let tail = self.tail;
            let buf = self.buffer_as_mut_slice();
            RingSlices::ring_slices(buf, head, tail)
        }
    }

    /// Ibinabalik ang bilang ng mga elemento sa `VecDeque`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v = VecDeque::new();
    /// assert_eq!(v.len(), 0);
    /// v.push_back(1);
    /// assert_eq!(v.len(), 1);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        count(self.tail, self.head, self.cap())
    }

    /// Ibinabalik ang `true` kung ang `VecDeque` ay walang laman.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v = VecDeque::new();
    /// assert!(v.is_empty());
    /// v.push_front(1);
    /// assert!(!v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.tail == self.head
    }

    fn range_tail_head<R>(&self, range: R) -> (usize, usize)
    where
        R: RangeBounds<usize>,
    {
        let Range { start, end } = slice::range(range, ..self.len());
        let tail = self.wrap_add(self.tail, start);
        let head = self.wrap_add(self.tail, end);
        (tail, head)
    }

    /// Lumilikha ng isang iterator na sumasakop sa tinukoy na saklaw sa `VecDeque`.
    ///
    /// # Panics
    ///
    /// Panics kung ang panimulang punto ay mas malaki kaysa sa end point o kung ang end point ay mas malaki kaysa sa haba ng vector.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let v: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// let range = v.range(2..).copied().collect::<VecDeque<_>>();
    /// assert_eq!(range, [3]);
    ///
    /// // Saklaw ng isang buong saklaw ang lahat ng mga nilalaman
    /// let all = v.range(..);
    /// assert_eq!(all.len(), 3);
    /// ```
    #[inline]
    #[stable(feature = "deque_range", since = "1.51.0")]
    pub fn range<R>(&self, range: R) -> Iter<'_, T>
    where
        R: RangeBounds<usize>,
    {
        let (tail, head) = self.range_tail_head(range);
        Iter {
            tail,
            head,
            // Ang ibinahaging sanggunian na mayroon kami sa &self ay pinananatili sa '_ ng Iter.
            ring: unsafe { self.buffer_as_slice() },
        }
    }

    /// Lumilikha ng isang iterator na sumasakop sa tinukoy na nababagabag na saklaw sa `VecDeque`.
    ///
    /// # Panics
    ///
    /// Panics kung ang panimulang punto ay mas malaki kaysa sa end point o kung ang end point ay mas malaki kaysa sa haba ng vector.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// for v in v.range_mut(2..) {
    ///   *v *= 2;
    /// }
    /// assert_eq!(v, vec![1, 2, 6]);
    ///
    /// // Saklaw ng isang buong saklaw ang lahat ng mga nilalaman
    /// for v in v.range_mut(..) {
    ///   *v *= 2;
    /// }
    /// assert_eq!(v, vec![2, 4, 12]);
    /// ```
    #[inline]
    #[stable(feature = "deque_range", since = "1.51.0")]
    pub fn range_mut<R>(&mut self, range: R) -> IterMut<'_, T>
    where
        R: RangeBounds<usize>,
    {
        let (tail, head) = self.range_tail_head(range);

        // KALIGTASAN: Ang panloob na kaligtasan sa `IterMut` kaligtasan ay itinatag dahil ang
        // `ring` nilikha namin ay isang hindi mapipigilan hiwa para sa panghabang buhay '_.
        IterMut {
            tail,
            head,
            ring: ptr::slice_from_raw_parts_mut(self.ptr(), self.cap()),
            phantom: PhantomData,
        }
    }

    /// Lumilikha ng isang draining iterator na inaalis ang tinukoy na saklaw sa `VecDeque` at nagbubunga ng mga inalis na item.
    ///
    /// Tandaan 1: Ang hanay ng elemento ay tinanggal kahit na ang iterator ay hindi natupok hanggang sa katapusan.
    ///
    /// Tandaan 2: Hindi natukoy kung gaano karaming mga elemento ang tinanggal mula sa deque, kung ang halagang `Drain` ay hindi nahulog, ngunit ang utang na hawak nito ay mawawalan ng bisa (hal., Dahil sa `mem::forget`).
    ///
    ///
    /// # Panics
    ///
    /// Panics kung ang panimulang punto ay mas malaki kaysa sa end point o kung ang end point ay mas malaki kaysa sa haba ng vector.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// let drained = v.drain(2..).collect::<VecDeque<_>>();
    /// assert_eq!(drained, [3]);
    /// assert_eq!(v, [1, 2]);
    ///
    /// // Ang isang buong saklaw nililimas ang lahat ng mga nilalaman
    /// v.drain(..);
    /// assert!(v.is_empty());
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_, T>
    where
        R: RangeBounds<usize>,
    {
        // Kaligtasan sa memorya
        //
        // Kapag ang Drain ay unang nilikha, ang pinagmulang deque ay pinaikling upang matiyak na walang uninitialized o inilipat-mula sa mga elemento ang maa-access sa lahat kung ang destructor ng Drain ay hindi kailanman tumakbo.
        //
        //
        // Drain ay ptr::read ang mga halagang aalisin.
        // Kapag natapos, ang natitirang data ay makopya pabalik upang masakop ang butas, at ang mga halagang head/tail ay maibabalik nang tama.
        //
        //
        //
        let (drain_tail, drain_head) = self.range_tail_head(range);

        // Ang mga elemento ng deque ay nahahati sa tatlong mga segment:
        // * self.tail  -> drain_tail
        // * drain_tail-> drain_head
        // * drain_head-> self.head
        //
        // T= self.tail;H= self.head;t=drain_tail;h=drain_head
        //
        // Nag-iimbak kami ng drain_tail bilang self.head, at drain_head at self.head bilang after_tail at after_head ayon sa pagkakabanggit sa Drain.
        // Pinuputol din nito ang mabisang array na kung ang Drain ay leak, nakalimutan namin ang tungkol sa mga potensyal na inilipat pagkatapos ng simula ng drain.
        //
        //
        //        T ika H
        // [. . . o o x x o o . . .]
        //
        //
        //
        let head = self.head;

        // "forget" tungkol sa mga halaga pagkatapos ng simula ng drain hanggang matapos ang drain ay kumpleto at ang Drain destructor ay pinatakbo.
        //
        self.head = drain_tail;

        Drain {
            deque: NonNull::from(&mut *self),
            after_tail: drain_head,
            after_head: head,
            iter: Iter {
                tail: drain_tail,
                head: drain_head,
                // Pangkahalagaan, gumagawa lamang kami ng mga nakabahaging sanggunian mula sa `self` dito at binabasa mula rito.
                // Hindi kami sumulat sa `self` o muling manghihiram sa isang nababagabag na sanggunian.
                // Samakatuwid ang raw pointer na nilikha namin sa itaas, para sa `deque`, ay mananatiling wasto.
                ring: unsafe { self.buffer_as_slice() },
            },
        }
    }

    /// Nilinaw ang `VecDeque`, inaalis ang lahat ng mga halaga.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v = VecDeque::new();
    /// v.push_back(1);
    /// v.clear();
    /// assert!(v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn clear(&mut self) {
        self.truncate(0);
    }

    /// Ibinabalik ang `true` kung ang `VecDeque` ay naglalaman ng isang elemento na katumbas ng ibinigay na halaga.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vector: VecDeque<u32> = VecDeque::new();
    ///
    /// vector.push_back(0);
    /// vector.push_back(1);
    ///
    /// assert_eq!(vector.contains(&1), true);
    /// assert_eq!(vector.contains(&10), false);
    /// ```
    #[stable(feature = "vec_deque_contains", since = "1.12.0")]
    pub fn contains(&self, x: &T) -> bool
    where
        T: PartialEq<T>,
    {
        let (a, b) = self.as_slices();
        a.contains(x) || b.contains(x)
    }

    /// Nagbibigay ng isang sanggunian sa harap na elemento, o `None` kung ang `VecDeque` ay walang laman.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.front(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// assert_eq!(d.front(), Some(&1));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn front(&self) -> Option<&T> {
        self.get(0)
    }

    /// Nagbibigay ng isang nababagabag na sanggunian sa harap na elemento, o `None` kung ang `VecDeque` ay walang laman.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.front_mut(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// match d.front_mut() {
    ///     Some(x) => *x = 9,
    ///     None => (),
    /// }
    /// assert_eq!(d.front(), Some(&9));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn front_mut(&mut self) -> Option<&mut T> {
        self.get_mut(0)
    }

    /// Nagbibigay ng isang sanggunian sa elemento ng likod, o `None` kung ang `VecDeque` ay walang laman.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.back(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// assert_eq!(d.back(), Some(&2));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn back(&self) -> Option<&T> {
        self.get(self.len().wrapping_sub(1))
    }

    /// Nagbibigay ng isang nababagong sanggunian sa elemento ng likod, o `None` kung ang `VecDeque` ay walang laman.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.back(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// match d.back_mut() {
    ///     Some(x) => *x = 9,
    ///     None => (),
    /// }
    /// assert_eq!(d.back(), Some(&9));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn back_mut(&mut self) -> Option<&mut T> {
        self.get_mut(self.len().wrapping_sub(1))
    }

    /// Tinatanggal ang unang elemento at ibinalik ito, o `None` kung ang `VecDeque` ay walang laman.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// d.push_back(1);
    /// d.push_back(2);
    ///
    /// assert_eq!(d.pop_front(), Some(1));
    /// assert_eq!(d.pop_front(), Some(2));
    /// assert_eq!(d.pop_front(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop_front(&mut self) -> Option<T> {
        if self.is_empty() {
            None
        } else {
            let tail = self.tail;
            self.tail = self.wrap_add(self.tail, 1);
            unsafe { Some(self.buffer_read(tail)) }
        }
    }

    /// Tinatanggal ang huling elemento mula sa `VecDeque` at ibabalik ito, o `None` kung ito ay walang laman.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// assert_eq!(buf.pop_back(), None);
    /// buf.push_back(1);
    /// buf.push_back(3);
    /// assert_eq!(buf.pop_back(), Some(3));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop_back(&mut self) -> Option<T> {
        if self.is_empty() {
            None
        } else {
            self.head = self.wrap_sub(self.head, 1);
            let head = self.head;
            unsafe { Some(self.buffer_read(head)) }
        }
    }

    /// Inihahanda ang isang elemento sa `VecDeque`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// d.push_front(1);
    /// d.push_front(2);
    /// assert_eq!(d.front(), Some(&2));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_front(&mut self, value: T) {
        if self.is_full() {
            self.grow();
        }

        self.tail = self.wrap_sub(self.tail, 1);
        let tail = self.tail;
        unsafe {
            self.buffer_write(tail, value);
        }
    }

    /// Nagdadagdag ng isang elemento sa likod ng `VecDeque`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(1);
    /// buf.push_back(3);
    /// assert_eq!(3, *buf.back().unwrap());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_back(&mut self, value: T) {
        if self.is_full() {
            self.grow();
        }

        let head = self.head;
        self.head = self.wrap_add(self.head, 1);
        unsafe { self.buffer_write(head, value) }
    }

    #[inline]
    fn is_contiguous(&self) -> bool {
        // FIXME: Dapat ba nating isaalang-alang ang `head == 0` na nangangahulugang
        // magkadikit ang `self` na iyon?
        self.tail <= self.head
    }

    /// Tinatanggal ang isang elemento mula sa kahit saan sa `VecDeque` at ibinalik ito, pinalitan ito ng unang elemento.
    ///
    ///
    /// Hindi nito pinapanatili ang pag-order, ngunit ito ay *O*(1).
    ///
    /// Ibinabalik ang `None` kung ang `index` ay wala sa mga hangganan.
    ///
    /// Ang elemento sa index 0 ay ang harap ng pila.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// assert_eq!(buf.swap_remove_front(0), None);
    /// buf.push_back(1);
    /// buf.push_back(2);
    /// buf.push_back(3);
    /// assert_eq!(buf, [1, 2, 3]);
    ///
    /// assert_eq!(buf.swap_remove_front(2), Some(3));
    /// assert_eq!(buf, [2, 1]);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn swap_remove_front(&mut self, index: usize) -> Option<T> {
        let length = self.len();
        if length > 0 && index < length && index != 0 {
            self.swap(index, 0);
        } else if index >= length {
            return None;
        }
        self.pop_front()
    }

    /// Tinatanggal ang isang elemento mula sa kahit saan sa `VecDeque` at ibinalik ito, pinapalitan ito ng huling elemento.
    ///
    ///
    /// Hindi nito pinapanatili ang pag-order, ngunit ito ay *O*(1).
    ///
    /// Ibinabalik ang `None` kung ang `index` ay wala sa mga hangganan.
    ///
    /// Ang elemento sa index 0 ay ang harap ng pila.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// assert_eq!(buf.swap_remove_back(0), None);
    /// buf.push_back(1);
    /// buf.push_back(2);
    /// buf.push_back(3);
    /// assert_eq!(buf, [1, 2, 3]);
    ///
    /// assert_eq!(buf.swap_remove_back(0), Some(1));
    /// assert_eq!(buf, [3, 2]);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn swap_remove_back(&mut self, index: usize) -> Option<T> {
        let length = self.len();
        if length > 0 && index < length - 1 {
            self.swap(index, length - 1);
        } else if index >= length {
            return None;
        }
        self.pop_back()
    }

    /// Nagpapasok ng isang elemento sa `index` sa loob ng `VecDeque`, binabago ang lahat ng mga elemento na may mga indeks na mas malaki sa o katumbas ng `index` patungo sa likuran.
    ///
    ///
    /// Ang elemento sa index 0 ay ang harap ng pila.
    ///
    /// # Panics
    ///
    /// Panics kung ang `index` ay mas malaki kaysa sa haba ng `VecDeque`
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vec_deque = VecDeque::new();
    /// vec_deque.push_back('a');
    /// vec_deque.push_back('b');
    /// vec_deque.push_back('c');
    /// assert_eq!(vec_deque, &['a', 'b', 'c']);
    ///
    /// vec_deque.insert(1, 'd');
    /// assert_eq!(vec_deque, &['a', 'd', 'b', 'c']);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn insert(&mut self, index: usize, value: T) {
        assert!(index <= self.len(), "index out of bounds");
        if self.is_full() {
            self.grow();
        }

        // Ilipat ang hindi bababa sa bilang ng mga elemento sa ring buffer at ipasok ang ibinigay na object
        //
        // Hindi hihigit sa len/2, 1 elemento ang ililipat. O(min(n, n-i))
        //
        // Mayroong tatlong pangunahing mga kaso:
        //  Ang mga elemento ay magkadikit
        //      - espesyal na kaso kapag ang buntot ay 0 Ang mga elemento ay hindi sigurado at ang insert ay nasa seksyon ng buntot Ang mga elemento ay hindi mag-aalinlangan at ang insert ay nasa seksyon ng ulo
        //
        //
        // Para sa bawat isa sa mga iyon mayroong dalawa pang mga kaso:
        //  Ipasok ay mas malapit sa buntot Ang pagsingit ay mas malapit sa ulo
        //
        // Susi: H, self.head
        //      T, self.tail o, Wastong elemento I, Pagpapasok ng elemento A, Ang elemento na dapat matapos ang inserting point M, Isinasaad ang elemento ay inilipat
        //
        //
        //
        //
        //
        //
        //

        let idx = self.wrap_add(self.tail, index);

        let distance_to_tail = index;
        let distance_to_head = self.len() - index;

        let contiguous = self.is_contiguous();

        match (contiguous, distance_to_tail <= distance_to_head, idx >= self.tail) {
            (true, true, _) if index == 0 => {
                // push_front
                //
                //       TIH
                //      [Isang oooooo.......
                //      .
                //      .]
                //
                //                       HT
                //      [A o o o o o o o . . . . . I]

                self.tail = self.wrap_sub(self.tail, 1);
            }
            (true, true, _) => {
                unsafe {
                    // magkadikit, ipasok ang malapit sa buntot:
                    //
                    //             TIH
                    //      [. . . o o A o o o o . . . . . .]
                    //
                    //           TH
                    //      [. . o o I A o o o o . . . . . .]
                    //           M M
                    //
                    // magkadikit, ipasok ang malapit sa buntot at buntot ay 0:
                    //
                    //
                    //       TIH
                    //      [o o A o o o o . . . . . . . . .]
                    //
                    //                       HT
                    //      [o I A o o o o o . . . . . . . o]
                    //       MM

                    let new_tail = self.wrap_sub(self.tail, 1);

                    self.copy(new_tail, self.tail, 1);
                    // Inilipat na ang buntot, kaya't kumokopya lamang kami ng mga elemento ng `index - 1`.
                    self.copy(self.tail, self.tail + 1, index - 1);

                    self.tail = new_tail;
                }
            }
            (true, false, _) => {
                unsafe {
                    // magkadikit, ipasok ang malapit sa ulo:
                    //
                    //             TIH
                    //      [. . . o o o o A o o . . . . . .]
                    //
                    //             TH
                    //      [. . . o o o o I A o o . . . . .]
                    //                       MMM

                    self.copy(idx + 1, idx, self.head - idx);
                    self.head = self.wrap_add(self.head, 1);
                }
            }
            (false, true, true) => {
                unsafe {
                    // hindi mag-aalinlangan, ipasok ang malapit sa buntot, seksyon ng buntot:
                    //
                    //                   HTI
                    //      [o o o o o o . . . . . o o A o o]
                    //
                    //                   HT
                    //      [o o o o o o . . . . o o I A o o]
                    //                           M M

                    self.copy(self.tail - 1, self.tail, index);
                    self.tail -= 1;
                }
            }
            (false, false, true) => {
                unsafe {
                    // hindi mag-aalinlangan, ipasok ang malapit sa ulo, seksyon ng buntot:
                    //
                    //           HTI
                    //      [o o . . . . . . . o o o o o A o]
                    //
                    //             HT
                    //      [o o o . . . . . . o o o o o I A]
                    //       MMMM

                    // kopyahin ang mga elemento hanggang sa bagong ulo
                    self.copy(1, 0, self.head);

                    // kopyahin ang huling elemento sa walang laman na lugar sa ilalim ng buffer
                    self.copy(0, self.cap() - 1, 1);

                    // ilipat ang mga elemento mula sa idx upang magtapos pasulong hindi kasama ang ^ elemento
                    self.copy(idx + 1, idx, self.cap() - 1 - idx);

                    self.head += 1;
                }
            }
            (false, true, false) if idx == 0 => {
                unsafe {
                    // hindi nag-aalinlangan, ang insert ay mas malapit sa buntot, seksyon ng ulo, at nasa index zero sa panloob na buffer:
                    //
                    //
                    //       IHT
                    //      [A o o o o o o o o o . . . o o o]
                    //
                    //                           HT
                    //      [A o o o o o o o o o . . o o o I]
                    //                               MMM

                    // kopyahin ang mga elemento hanggang sa bagong buntot
                    self.copy(self.tail - 1, self.tail, self.cap() - self.tail);

                    // kopyahin ang huling elemento sa walang laman na lugar sa ilalim ng buffer
                    self.copy(self.cap() - 1, 0, 1);

                    self.tail -= 1;
                }
            }
            (false, true, false) => {
                unsafe {
                    // hindi mag-aalinlangan, ipasok ang malapit sa buntot, seksyon ng ulo:
                    //
                    //             IHT
                    //      [o o o A o o o o o o . . . o o o]
                    //
                    //                           HT
                    //      [o o I A o o o o o o . . o o o o]
                    //       MMMMMM

                    // kopyahin ang mga elemento hanggang sa bagong buntot
                    self.copy(self.tail - 1, self.tail, self.cap() - self.tail);

                    // kopyahin ang huling elemento sa walang laman na lugar sa ilalim ng buffer
                    self.copy(self.cap() - 1, 0, 1);

                    // ilipat ang mga elemento mula sa idx-1 upang magtapos pasulong na hindi kasama ang ^ elemento
                    self.copy(0, 1, idx - 1);

                    self.tail -= 1;
                }
            }
            (false, false, false) => {
                unsafe {
                    // discontiguous, magpasok ng mas malapit sa ulo, ulo seksyon:
                    //
                    //               IHT
                    //      [o o o o A o o . . . . . . o o o]
                    //
                    //                     HT
                    //      [o o o o I A o o . . . . . o o o]
                    //                 MMM

                    self.copy(idx + 1, idx, self.head - idx);
                    self.head += 1;
                }
            }
        }

        // baka nabago na ang buntot kaya kailangan nating muling kalkulahin
        let new_idx = self.wrap_add(self.tail, index);
        unsafe {
            self.buffer_write(new_idx, value);
        }
    }

    /// Tanggalin at ibabalik ang elemento sa `index` mula sa `VecDeque`.
    /// Anumang dulo ay mas malapit sa tinanggal na point ay ililipat upang magkaroon ng silid, at ang lahat ng mga apektadong elemento ay ililipat sa mga bagong posisyon.
    ///
    /// Ibinabalik ang `None` kung ang `index` ay wala sa mga hangganan.
    ///
    /// Ang elemento sa index 0 ay ang harap ng pila.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(1);
    /// buf.push_back(2);
    /// buf.push_back(3);
    /// assert_eq!(buf, [1, 2, 3]);
    ///
    /// assert_eq!(buf.remove(1), Some(2));
    /// assert_eq!(buf, [1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, index: usize) -> Option<T> {
        if self.is_empty() || self.len() <= index {
            return None;
        }

        // Mayroong tatlong pangunahing mga kaso:
        //  Ang mga elemento ay magkadikit Ang mga elemento ay hindi magkakaugnay at ang pag-aalis ay nasa seksyon ng buntot Ang mga elemento ay hindi sigurado at ang pagtanggal ay nasa seksyon ng ulo
        //
        //      - espesyal na kaso kapag ang mga elemento ay magkadikit, ngunit self.head =0
        //
        // Para sa bawat isa sa mga iyon mayroong dalawa pang mga kaso:
        //  Ipasok ay mas malapit sa buntot Ang pagsingit ay mas malapit sa ulo
        //
        // Susi: H, self.head
        //      T, self.tail o, Wastong elemento x, Elemento na minarkahan para sa pag-aalis ng R, Isinasaad ang elemento na tinatanggal M, Isinasaad ang sangkap na inilipat
        //
        //
        //
        //
        //
        //
        //

        let idx = self.wrap_add(self.tail, index);

        let elem = unsafe { Some(self.buffer_read(idx)) };

        let distance_to_tail = index;
        let distance_to_head = self.len() - index;

        let contiguous = self.is_contiguous();

        match (contiguous, distance_to_tail <= distance_to_head, idx >= self.tail) {
            (true, true, _) => {
                unsafe {
                    // magkadikit, alisin ang malapit sa buntot:
                    //
                    //             TRH
                    //      [. . . o o x o o o o . . . . . .]
                    //
                    //               TH
                    //      [. . . . o o o o o o . . . . . .]
                    //               M M

                    self.copy(self.tail + 1, self.tail, index);
                    self.tail += 1;
                }
            }
            (true, false, _) => {
                unsafe {
                    // magkadikit, alisin malapit sa ulo:
                    //
                    //             TRH
                    //      [. . . o o o o x o o . . . . . .]
                    //
                    //             TH
                    //      [. . . o o o o o o . . . . . . .]
                    //                     M M

                    self.copy(idx, idx + 1, self.head - idx - 1);
                    self.head -= 1;
                }
            }
            (false, true, true) => {
                unsafe {
                    // hindi mag-aalinlangan, alisin ang malapit sa buntot, seksyon ng buntot:
                    //
                    //                   HTR
                    //      [o o o o o o . . . . . o o x o o]
                    //
                    //                   HT
                    //      [o o o o o o . . . . . . o o o o]
                    //                               M M

                    self.copy(self.tail + 1, self.tail, index);
                    self.tail = self.wrap_add(self.tail, 1);
                }
            }
            (false, false, false) => {
                unsafe {
                    // hindi mag-aalinlangan, alisin ang malapit sa ulo, seksyon ng ulo:
                    //
                    //               RHT
                    //      [o o o o x o o . . . . . . o o o]
                    //
                    //                   HT
                    //      [o o o o o o . . . . . . . o o o]
                    //               M M

                    self.copy(idx, idx + 1, self.head - idx - 1);
                    self.head -= 1;
                }
            }
            (false, false, true) => {
                unsafe {
                    // hindi mag-aalinlangan, alisin ang malapit sa ulo, seksyon ng buntot:
                    //
                    //             HTR
                    //      [o o o . . . . . . o o o o o x o]
                    //
                    //           HT
                    //      [o o . . . . . . . o o o o o o o]
                    //       MMMM
                    //
                    // o quasi-discontiguous, alisin sa tabi ng ulo, seksyon ng buntot:
                    //
                    //       HTR
                    //      [. . . . . . . . . o o o o o x o]
                    //
                    //                         TH
                    //      [. . . . . . . . . o o o o o o .]
                    //                                   M

                    // gumuhit ng mga elemento sa seksyon ng buntot
                    self.copy(idx, idx + 1, self.cap() - idx - 1);

                    // Pinipigilan ang pag-agos.
                    if self.head != 0 {
                        // kopyahin ang unang elemento sa walang laman na lugar
                        self.copy(self.cap() - 1, 0, 1);

                        // ilipat ang mga elemento sa seksyon ng ulo paurong
                        self.copy(0, 1, self.head - 1);
                    }

                    self.head = self.wrap_sub(self.head, 1);
                }
            }
            (false, true, false) => {
                unsafe {
                    // hindi mag-aalinlangan, alisin ang malapit sa buntot, seksyon ng ulo:
                    //
                    //           RHT
                    //      [o o x o o o o o o o . . . o o o]
                    //
                    //                           HT
                    //      [o o o o o o o o o o . . . . o o]
                    //       MMMMM

                    // gumuhit ng mga elemento hanggang sa idx
                    self.copy(1, 0, idx);

                    // kopyahin ang huling elemento sa walang laman na lugar
                    self.copy(0, self.cap() - 1, 1);

                    // ilipat ang mga elemento mula sa buntot sa dulo pasulong, hindi kasama ang huli
                    self.copy(self.tail + 1, self.tail, self.cap() - self.tail - 1);

                    self.tail = self.wrap_add(self.tail, 1);
                }
            }
        }

        elem
    }

    /// Hinahati ang `VecDeque` sa dalawa sa ibinigay na index.
    ///
    /// Nagbabalik ng isang bagong inilalaan na `VecDeque`.
    /// `self` naglalaman ng mga elemento `[0, at)`, at ang ibinalik na `VecDeque` ay naglalaman ng mga elemento `[at, len)`.
    ///
    /// Tandaan na ang kapasidad ng `self` ay hindi nagbabago.
    ///
    /// Ang elemento sa index 0 ay ang harap ng pila.
    ///
    /// # Panics
    ///
    /// Panics kung `at > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// let buf2 = buf.split_off(1);
    /// assert_eq!(buf, [1]);
    /// assert_eq!(buf2, [2, 3]);
    /// ```
    #[inline]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    #[stable(feature = "split_off", since = "1.4.0")]
    pub fn split_off(&mut self, at: usize) -> Self {
        let len = self.len();
        assert!(at <= len, "`at` out of bounds");

        let other_len = len - at;
        let mut other = VecDeque::with_capacity(other_len);

        unsafe {
            let (first_half, second_half) = self.as_slices();

            let first_len = first_half.len();
            let second_len = second_half.len();
            if at < first_len {
                // `at` namamalagi sa unang kalahati.
                let amount_in_first = first_len - at;

                ptr::copy_nonoverlapping(first_half.as_ptr().add(at), other.ptr(), amount_in_first);

                // kunin mo na lang lahat ng pangalawang kalahati.
                ptr::copy_nonoverlapping(
                    second_half.as_ptr(),
                    other.ptr().add(amount_in_first),
                    second_len,
                );
            } else {
                // `at` namamalagi sa ikalawang kalahati, kailangang i-factor ang mga elementong nilaktawan namin sa unang kalahati.
                //
                let offset = at - first_len;
                let amount_in_second = second_len - offset;
                ptr::copy_nonoverlapping(
                    second_half.as_ptr().add(offset),
                    other.ptr(),
                    amount_in_second,
                );
            }
        }

        // Paglilinis kung nasaan ang mga dulo ng buffer
        self.head = self.wrap_sub(self.head, other_len);
        other.head = other.wrap_index(other_len);

        other
    }

    /// Inililipat ang lahat ng mga elemento ng `other` sa `self`, iniiwan ang `other` na walang laman.
    ///
    /// # Panics
    ///
    /// Panics kung ang bagong numero ng mga elemento sa sarili overflows isang `usize`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = vec![1, 2].into_iter().collect();
    /// let mut buf2: VecDeque<_> = vec![3, 4].into_iter().collect();
    /// buf.append(&mut buf2);
    /// assert_eq!(buf, [1, 2, 3, 4]);
    /// assert_eq!(buf2, []);
    /// ```
    #[inline]
    #[stable(feature = "append", since = "1.4.0")]
    pub fn append(&mut self, other: &mut Self) {
        // walang muwang impl
        self.extend(other.drain(..));
    }

    /// Pinapanatili lamang ang mga elemento na tinukoy ng panaguri.
    ///
    /// Sa madaling salita, alisin ang lahat ng mga elemento `e` tulad na ang `f(&e)` ay nagbabalik ng mali.
    /// Nagpapatakbo ang pamamaraang ito sa lugar, pagbisita sa bawat elemento nang eksakto isang beses sa orihinal na pagkakasunud-sunod, at pinapanatili ang pagkakasunud-sunod ng mga pinanatili na elemento.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.extend(1..5);
    /// buf.retain(|&x| x % 2 == 0);
    /// assert_eq!(buf, [2, 4]);
    /// ```
    ///
    /// Ang eksaktong order ay maaaring maging kapaki-pakinabang para sa pagsubaybay sa panlabas na estado, tulad ng isang index.
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.extend(1..6);
    ///
    /// let keep = [false, true, true, false, true];
    /// let mut i = 0;
    /// buf.retain(|_| (keep[i], i += 1).0);
    /// assert_eq!(buf, [2, 3, 5]);
    /// ```
    #[stable(feature = "vec_deque_retain", since = "1.4.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> bool,
    {
        let len = self.len();
        let mut del = 0;
        for i in 0..len {
            if !f(&self[i]) {
                del += 1;
            } else if del > 0 {
                self.swap(i - del, i);
            }
        }
        if del > 0 {
            self.truncate(len - del);
        }
    }

    // Maaari itong panic o ipalaglag
    #[inline(never)]
    fn grow(&mut self) {
        if self.is_full() {
            let old_cap = self.cap();
            // Dobleng laki ng buffer.
            self.buf.reserve_exact(old_cap, old_cap);
            assert!(self.cap() == old_cap * 2);
            unsafe {
                self.handle_capacity_increase(old_cap);
            }
            debug_assert!(!self.is_full());
        }
    }

    /// Binabago ang `VecDeque` sa lugar upang ang `len()` ay katumbas ng `new_len`, alinman sa pamamagitan ng pag-alis ng labis na mga elemento mula sa likuran o sa pamamagitan ng pagdaragdag ng mga elemento na nabuo sa pamamagitan ng pagtawag sa `generator` sa likuran.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(10);
    /// buf.push_back(15);
    /// assert_eq!(buf, [5, 10, 15]);
    ///
    /// buf.resize_with(5, Default::default);
    /// assert_eq!(buf, [5, 10, 15, 0, 0]);
    ///
    /// buf.resize_with(2, || unreachable!());
    /// assert_eq!(buf, [5, 10]);
    ///
    /// let mut state = 100;
    /// buf.resize_with(5, || { state += 1; state });
    /// assert_eq!(buf, [5, 10, 101, 102, 103]);
    /// ```
    ///
    #[stable(feature = "vec_resize_with", since = "1.33.0")]
    pub fn resize_with(&mut self, new_len: usize, generator: impl FnMut() -> T) {
        let len = self.len();

        if new_len > len {
            self.extend(repeat_with(generator).take(new_len - len))
        } else {
            self.truncate(new_len);
        }
    }

    /// Inaayos muli ang panloob na imbakan ng deque na ito kaya't ito ay isang magkadikit na hiwa, na pagkatapos ay ibinalik.
    ///
    /// Ang pamamaraang ito ay hindi naglalaan at hindi binabago ang pagkakasunud-sunod ng mga nakapasok na elemento.Habang nagbabalik ito ng isang nababagabag na hiwa, maaari itong magamit upang pag-uri-uriin ang isang deque.
    ///
    /// Sa sandaling magkadikit ang panloob na imbakan, ibabalik ng mga pamamaraan na [`as_slices`] at [`as_mut_slices`] ang buong nilalaman ng `VecDeque` sa isang solong hiwa.
    ///
    ///
    /// [`as_slices`]: VecDeque::as_slices
    /// [`as_mut_slices`]: VecDeque::as_mut_slices
    ///
    /// # Examples
    ///
    /// Pag-uuri-uri ng nilalaman ng isang deque.
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::with_capacity(15);
    ///
    /// buf.push_back(2);
    /// buf.push_back(1);
    /// buf.push_front(3);
    ///
    /// // pag-uuri ng deque
    /// buf.make_contiguous().sort();
    /// assert_eq!(buf.as_slices(), (&[1, 2, 3] as &[_], &[] as &[_]));
    ///
    /// // pag-uuri nito sa reverse order
    /// buf.make_contiguous().sort_by(|a, b| b.cmp(a));
    /// assert_eq!(buf.as_slices(), (&[3, 2, 1] as &[_], &[] as &[_]));
    /// ```
    ///
    /// Pagkuha ng hindi nababago na pag-access sa magkadikit na hiwa.
    ///
    /// ```rust
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    ///
    /// buf.push_back(2);
    /// buf.push_back(1);
    /// buf.push_front(3);
    ///
    /// buf.make_contiguous();
    /// if let (slice, &[]) = buf.as_slices() {
    ///     // maaari naming siguraduhin na ang `slice` naglalaman ng lahat ng mga elemento ng deque, habang nagkakaroon pa rin ng hindi nababago na pag-access sa `buf`.
    /////
    ///     assert_eq!(buf.len(), slice.len());
    ///     assert_eq!(slice, &[3, 2, 1] as &[_]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "deque_make_contiguous", since = "1.48.0")]
    pub fn make_contiguous(&mut self) -> &mut [T] {
        if self.is_contiguous() {
            let tail = self.tail;
            let head = self.head;
            return unsafe { RingSlices::ring_slices(self.buffer_as_mut_slice(), head, tail).0 };
        }

        let buf = self.buf.ptr();
        let cap = self.cap();
        let len = self.len();

        let free = self.tail - self.head;
        let tail_len = cap - self.tail;

        if free >= tail_len {
            // mayroong sapat na libreng puwang upang kopyahin ang buntot nang sabay-sabay, nangangahulugan ito na inilipat muna namin ang ulo paatras, at pagkatapos ay kopyahin ang buntot sa tamang posisyon.
            //
            //
            // mula sa: DEFGH .... ABC
            // sa: ABCDEFGH ....
            //
            unsafe {
                ptr::copy(buf, buf.add(tail_len), self.head);
                // ...DEFGH.ABC
                ptr::copy_nonoverlapping(buf.add(self.tail), buf, tail_len);
                // ABCDEFGH....

                self.tail = 0;
                self.head = len;
            }
        } else if free > self.head {
            // FIXME: Kasalukuyan naming hindi isinasaalang-alang .... ABCDEFGH
            // upang maging magkadikit dahil ang `head` ay magiging `0` sa kasong ito.
            // Habang malamang na baguhin namin ito ay hindi gaanong mahalaga tulad ng ilang mga lugar na inaasahan ang `is_contiguous` na nangangahulugan na maaari lamang naming hiwain ang paggamit ng `buf[tail..head]`.
            //
            //

            // mayroong sapat na libreng puwang upang kopyahin ang ulo nang sabay-sabay, nangangahulugan ito na inililipat muna namin ang buntot pasulong, at pagkatapos ay kopyahin ang ulo sa tamang posisyon.
            //
            //
            // mula sa: FGH .... ABCDE
            // sa: ... ABCDEFGH.
            //
            unsafe {
                ptr::copy(buf.add(self.tail), buf.add(self.head), tail_len);
                // FGHABCDE....
                ptr::copy_nonoverlapping(buf, buf.add(self.head + tail_len), self.head);
                // ...ABCDEFGH.

                self.tail = self.head;
                self.head = self.wrap_add(self.tail, len);
            }
        } else {
            // ang malaya ay mas maliit kaysa sa parehong ulo at buntot, nangangahulugan ito na kailangan nating dahan-dahan "swap" ang buntot at ang ulo.
            //
            //
            // mula sa: EFGHI ... ABCD o HIJK.ABCDEFG
            // sa: ABCDEFGHI ... o ABCDEFGHIJK.
            let mut left_edge: usize = 0;
            let mut right_edge: usize = self.tail;
            unsafe {
                // Ang pangkalahatang problema ay mukhang ang GHIJKLM na ito ... ABCDEF, bago ang anumang pagpapalit ng ABCDEFM ... GHIJKL, pagkatapos ng 1 pass ng swaps ABCDEFGHIJM ... KL, magpalitan hanggang sa maabot ng kaliwang edge ang temp store
                //                  - pagkatapos ay muling simulan ang algorithm sa isang bagong tindahan ng (smaller) Minsan ang temp store ay naabot kapag ang tamang edge ay nasa dulo ng buffer, nangangahulugan ito na naabot namin ang tamang pagkakasunud-sunod na may mas kaunting mga swap!
                //
                // E.g
                // EF..ABCD ABCDEF .., pagkatapos ng apat na swap lamang natapos na namin
                //
                //
                //
                //
                //
                while left_edge < len && right_edge != cap {
                    let mut right_offset = 0;
                    for i in left_edge..right_edge {
                        right_offset = (i - left_edge) % (cap - right_edge);
                        let src: isize = (right_edge + right_offset) as isize;
                        ptr::swap(buf.add(i), buf.offset(src));
                    }
                    let n_ops = right_edge - left_edge;
                    left_edge += n_ops;
                    right_edge += right_offset + 1;
                }

                self.tail = 0;
                self.head = len;
            }
        }

        let tail = self.tail;
        let head = self.head;
        unsafe { RingSlices::ring_slices(self.buffer_as_mut_slice(), head, tail).0 }
    }

    /// Paikutin ang doble-natapos na pila `mid` mga lugar sa kaliwa.
    ///
    /// Equivalently,
    /// - Paikutin ang item `mid` sa unang posisyon.
    /// - Itama ang unang mga item na `mid` at itulak ang mga ito hanggang sa wakas.
    /// - Paikutin ang mga lugar na `len() - mid` sa kanan.
    ///
    /// # Panics
    ///
    /// Kung ang `mid` ay mas malaki kaysa sa `len()`.
    /// Tandaan na ang `mid == len()` ay _not_ panic at ito ay isang pag-ikot na no-op.
    ///
    /// # Complexity
    ///
    /// Tumatagal ng `*O*(min(mid, len() - mid))` na oras at walang labis na puwang.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = (0..10).collect();
    ///
    /// buf.rotate_left(3);
    /// assert_eq!(buf, [3, 4, 5, 6, 7, 8, 9, 0, 1, 2]);
    ///
    /// for i in 1..10 {
    ///     assert_eq!(i * 3 % 10, buf[0]);
    ///     buf.rotate_left(3);
    /// }
    /// assert_eq!(buf, [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]);
    /// ```
    #[stable(feature = "vecdeque_rotate", since = "1.36.0")]
    pub fn rotate_left(&mut self, mid: usize) {
        assert!(mid <= self.len());
        let k = self.len() - mid;
        if mid <= k {
            unsafe { self.rotate_left_inner(mid) }
        } else {
            unsafe { self.rotate_right_inner(k) }
        }
    }

    /// Paikutin ang doble-natapos na pila `k` mga lugar sa kanan.
    ///
    /// Equivalently,
    /// - Paikutin ang unang item sa posisyon `k`.
    /// - Itama ang huling mga item na `k` at itulak ang mga ito sa harap.
    /// - Paikutin ang `len() - k` mga lugar sa kaliwa.
    ///
    /// # Panics
    ///
    /// Kung ang `k` ay mas malaki kaysa sa `len()`.
    /// Tandaan na ang `k == len()` ay _not_ panic at ito ay isang pag-ikot na no-op.
    ///
    /// # Complexity
    ///
    /// Tumatagal ng `*O*(min(k, len() - k))` na oras at walang labis na puwang.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = (0..10).collect();
    ///
    /// buf.rotate_right(3);
    /// assert_eq!(buf, [7, 8, 9, 0, 1, 2, 3, 4, 5, 6]);
    ///
    /// for i in 1..10 {
    ///     assert_eq!(0, buf[i * 3 % 10]);
    ///     buf.rotate_right(3);
    /// }
    /// assert_eq!(buf, [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]);
    /// ```
    #[stable(feature = "vecdeque_rotate", since = "1.36.0")]
    pub fn rotate_right(&mut self, k: usize) {
        assert!(k <= self.len());
        let mid = self.len() - k;
        if k <= mid {
            unsafe { self.rotate_right_inner(k) }
        } else {
            unsafe { self.rotate_left_inner(mid) }
        }
    }

    // KALIGTASAN: ang mga sumusunod na dalawang pamamaraan ay nangangailangan ng halaga ng pag-ikot
    // mas mababa sa kalahati ng haba ng deque.
    //
    // `wrap_copy` nangangailangan ng `min(x, cap() - x) + copy_len <= cap()` na iyon, ngunit higit sa `min` ay hindi hihigit sa kalahati ng kapasidad, anuman ang x, kaya't ang tunog ay tumawag dito dahil tumatawag kami na may isang bagay na mas mababa sa kalahati ng haba, na hindi hihigit sa kalahati ng kapasidad.
    //
    //
    //

    unsafe fn rotate_left_inner(&mut self, mid: usize) {
        debug_assert!(mid * 2 <= self.len());
        unsafe {
            self.wrap_copy(self.head, self.tail, mid);
        }
        self.head = self.wrap_add(self.head, mid);
        self.tail = self.wrap_add(self.tail, mid);
    }

    unsafe fn rotate_right_inner(&mut self, k: usize) {
        debug_assert!(k * 2 <= self.len());
        self.head = self.wrap_sub(self.head, k);
        self.tail = self.wrap_sub(self.tail, k);
        unsafe {
            self.wrap_copy(self.tail, self.head, k);
        }
    }

    /// Paghahanap ng binary ay pinagsunod-sunod ang `VecDeque` para sa isang naibigay na elemento.
    ///
    /// Kung ang halaga ay natagpuan pagkatapos ay bumalik ang [`Result::Ok`], na naglalaman ng index ng tumutugmang elemento.
    /// Kung maraming mga tugma, kung gayon ang anumang isa sa mga tugma ay maaaring ibalik.
    /// Kung ang halaga ay hindi natagpuan pagkatapos ay ibalik ang [`Result::Err`], naglalaman ng indeks kung saan maaaring ipasok ang isang tumutugma na elemento habang pinapanatili ang pinagsunod-sunod na pagkakasunud-sunod.
    ///
    ///
    /// # Examples
    ///
    /// Naghahanap ng isang serye ng apat na mga elemento.
    /// Ang una ay matatagpuan, na may natatanging natukoy na posisyon;ang pangalawa at pangatlo ay hindi natagpuan;ang pang-apat ay maaaring tumugma sa anumang posisyon sa `[1, 4]`.
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let deque: VecDeque<_> = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55].into();
    ///
    /// assert_eq!(deque.binary_search(&13),  Ok(9));
    /// assert_eq!(deque.binary_search(&4),   Err(7));
    /// assert_eq!(deque.binary_search(&100), Err(13));
    /// let r = deque.binary_search(&1);
    /// assert!(matches!(r, Ok(1..=4)));
    /// ```
    ///
    /// Kung nais mong magsingit ng isang item sa isang pinagsunod-sunod na `VecDeque`, habang pinapanatili ang pagkakasunud-sunod ng pagkakasunud-sunod:
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let mut deque: VecDeque<_> = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55].into();
    /// let num = 42;
    /// let idx = deque.binary_search(&num).unwrap_or_else(|x| x);
    /// deque.insert(idx, num);
    /// assert_eq!(deque, &[0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 42, 55]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "vecdeque_binary_search", issue = "78021")]
    #[inline]
    pub fn binary_search(&self, x: &T) -> Result<usize, usize>
    where
        T: Ord,
    {
        self.binary_search_by(|e| e.cmp(x))
    }

    /// Binari ng paghahanap ang pinagsunod-sunod na `VecDeque` na may pagpapaandar na kumpare.
    ///
    /// Dapat na magpatupad ang pagpapaandar ng kumpare ng isang order na naaayon sa pag-uuri-uri ng pagkakasunud-sunod ng pinagbabatayan `VecDeque`, na nagbabalik ng isang code ng order na nagpapahiwatig kung ang argumento nito ay `Less`, `Equal` o `Greater` kaysa sa nais na target.
    ///
    ///
    /// Kung ang halaga ay natagpuan pagkatapos ay bumalik ang [`Result::Ok`], na naglalaman ng index ng tumutugmang elemento.Kung maraming mga tugma, kung gayon ang anumang isa sa mga tugma ay maaaring ibalik.
    /// Kung ang halaga ay hindi natagpuan pagkatapos ay ibalik ang [`Result::Err`], naglalaman ng indeks kung saan maaaring ipasok ang isang tumutugma na elemento habang pinapanatili ang pinagsunod-sunod na pagkakasunud-sunod.
    ///
    /// # Examples
    ///
    /// Naghahanap ng isang serye ng apat na mga elemento.Ang una ay matatagpuan, na may natatanging natukoy na posisyon;ang pangalawa at pangatlo ay hindi natagpuan;ang pang-apat ay maaaring tumugma sa anumang posisyon sa `[1, 4]`.
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let deque: VecDeque<_> = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55].into();
    ///
    /// assert_eq!(deque.binary_search_by(|x| x.cmp(&13)),  Ok(9));
    /// assert_eq!(deque.binary_search_by(|x| x.cmp(&4)),   Err(7));
    /// assert_eq!(deque.binary_search_by(|x| x.cmp(&100)), Err(13));
    /// let r = deque.binary_search_by(|x| x.cmp(&1));
    /// assert!(matches!(r, Ok(1..=4)));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vecdeque_binary_search", issue = "78021")]
    pub fn binary_search_by<'a, F>(&'a self, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> Ordering,
    {
        let (front, back) = self.as_slices();

        if let Some(Ordering::Less | Ordering::Equal) = back.first().map(|elem| f(elem)) {
            back.binary_search_by(f).map(|idx| idx + front.len()).map_err(|idx| idx + front.len())
        } else {
            front.binary_search_by(f)
        }
    }

    /// Binari ng paghahanap ang pinagsunod-sunod na `VecDeque` na may pangunahing pagpapaandar sa pagkuha.
    ///
    /// Ipinapalagay na ang `VecDeque` ay pinagsunod-sunod ng susi, halimbawa kasama ang [`make_contiguous().sort_by_key()`](#method.make_contiguous) gamit ang parehong key function na pagkuha.
    ///
    ///
    /// Kung ang halaga ay natagpuan pagkatapos ay bumalik ang [`Result::Ok`], na naglalaman ng index ng tumutugmang elemento.
    /// Kung maraming mga tugma, kung gayon ang anumang isa sa mga tugma ay maaaring ibalik.
    /// Kung ang halaga ay hindi natagpuan pagkatapos ay ibalik ang [`Result::Err`], naglalaman ng indeks kung saan maaaring ipasok ang isang tumutugma na elemento habang pinapanatili ang pinagsunod-sunod na pagkakasunud-sunod.
    ///
    /// # Examples
    ///
    /// Naghahanap ng isang serye ng apat na elemento sa isang slice ng mga pares na pinagsunod-sunod ayon sa kanilang mga pangalawang elemento.
    /// Ang una ay matatagpuan, na may natatanging natukoy na posisyon;ang pangalawa at pangatlo ay hindi natagpuan;ang pang-apat ay maaaring tumugma sa anumang posisyon sa `[1, 4]`.
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let deque: VecDeque<_> = vec![(0, 0), (2, 1), (4, 1), (5, 1),
    ///          (3, 1), (1, 2), (2, 3), (4, 5), (5, 8), (3, 13),
    ///          (1, 21), (2, 34), (4, 55)].into();
    ///
    /// assert_eq!(deque.binary_search_by_key(&13, |&(a, b)| b),  Ok(9));
    /// assert_eq!(deque.binary_search_by_key(&4, |&(a, b)| b),   Err(7));
    /// assert_eq!(deque.binary_search_by_key(&100, |&(a, b)| b), Err(13));
    /// let r = deque.binary_search_by_key(&1, |&(a, b)| b);
    /// assert!(matches!(r, Ok(1..=4)));
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vecdeque_binary_search", issue = "78021")]
    #[inline]
    pub fn binary_search_by_key<'a, B, F>(&'a self, b: &B, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> B,
        B: Ord,
    {
        self.binary_search_by(|k| f(k).cmp(b))
    }
}

impl<T: Clone> VecDeque<T> {
    /// Binabago ang `VecDeque` sa lugar upang ang `len()` ay katumbas ng new_len, alinman sa pamamagitan ng pag-aalis ng labis na mga elemento mula sa likuran o sa pamamagitan ng pagdaragdag ng mga clone ng `value` sa likuran.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(10);
    /// buf.push_back(15);
    /// assert_eq!(buf, [5, 10, 15]);
    ///
    /// buf.resize(2, 0);
    /// assert_eq!(buf, [5, 10]);
    ///
    /// buf.resize(5, 20);
    /// assert_eq!(buf, [5, 10, 20, 20, 20]);
    /// ```
    ///
    #[stable(feature = "deque_extras", since = "1.16.0")]
    pub fn resize(&mut self, new_len: usize, value: T) {
        self.resize_with(new_len, || value.clone());
    }
}

/// Ibinabalik ang index sa pinagbabatayan na buffer para sa isang naibigay na lohikal na index ng elemento.
#[inline]
fn wrap_index(index: usize, size: usize) -> usize {
    // ang laki ay palaging isang kapangyarihan ng 2
    debug_assert!(size.is_power_of_two());
    index & (size - 1)
}

/// Kalkulahin ang bilang ng mga elemento na natitira upang mabasa sa buffer
#[inline]
fn count(tail: usize, head: usize, size: usize) -> usize {
    // ang laki ay palaging isang kapangyarihan ng 2
    (head.wrapping_sub(tail)) & (size - 1)
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: PartialEq> PartialEq for VecDeque<A> {
    fn eq(&self, other: &VecDeque<A>) -> bool {
        if self.len() != other.len() {
            return false;
        }
        let (sa, sb) = self.as_slices();
        let (oa, ob) = other.as_slices();
        if sa.len() == oa.len() {
            sa == oa && sb == ob
        } else if sa.len() < oa.len() {
            // Palaging nahahati sa tatlong seksyon, halimbawa: sarili: [a b c|d e f] iba pa: [0 1 2 3|4 5] harap=3, kalagitnaan=1, [a b c] == [0 1 2]&&[d] == [3]&&[e f] == [4 5]
            //
            //
            //
            //
            let front = sa.len();
            let mid = oa.len() - front;

            let (oa_front, oa_mid) = oa.split_at(front);
            let (sb_mid, sb_back) = sb.split_at(mid);
            debug_assert_eq!(sa.len(), oa_front.len());
            debug_assert_eq!(sb_mid.len(), oa_mid.len());
            debug_assert_eq!(sb_back.len(), ob.len());
            sa == oa_front && sb_mid == oa_mid && sb_back == ob
        } else {
            let front = oa.len();
            let mid = sa.len() - front;

            let (sa_front, sa_mid) = sa.split_at(front);
            let (ob_mid, ob_back) = ob.split_at(mid);
            debug_assert_eq!(sa_front.len(), oa.len());
            debug_assert_eq!(sa_mid.len(), ob_mid.len());
            debug_assert_eq!(sb.len(), ob_back.len());
            sa_front == oa && sa_mid == ob_mid && sb == ob_back
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Eq> Eq for VecDeque<A> {}

__impl_slice_eq1! { [] VecDeque<A>, Vec<B>, }
__impl_slice_eq1! { [] VecDeque<A>, &[B], }
__impl_slice_eq1! { [] VecDeque<A>, &mut [B], }
__impl_slice_eq1! { [const N: usize] VecDeque<A>, [B; N], }
__impl_slice_eq1! { [const N: usize] VecDeque<A>, &[B; N], }
__impl_slice_eq1! { [const N: usize] VecDeque<A>, &mut [B; N], }

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: PartialOrd> PartialOrd for VecDeque<A> {
    fn partial_cmp(&self, other: &VecDeque<A>) -> Option<Ordering> {
        self.iter().partial_cmp(other.iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Ord> Ord for VecDeque<A> {
    #[inline]
    fn cmp(&self, other: &VecDeque<A>) -> Ordering {
        self.iter().cmp(other.iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Hash> Hash for VecDeque<A> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        self.len().hash(state);
        // Hindi posible na gumamit ng Hash::hash_slice sa mga hiwa na ibinalik ng as_slices na pamamaraan dahil ang kanilang haba ay maaaring mag-iba sa kung hindi man magkapareho ng mga deque.
        //
        //
        // Ginagarantiyahan lamang ni Hasher ang katumbas para sa eksaktong parehong hanay ng mga tawag sa mga pamamaraan nito.
        //
        //
        self.iter().for_each(|elem| elem.hash(state));
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> Index<usize> for VecDeque<A> {
    type Output = A;

    #[inline]
    fn index(&self, index: usize) -> &A {
        self.get(index).expect("Out of bounds access")
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> IndexMut<usize> for VecDeque<A> {
    #[inline]
    fn index_mut(&mut self, index: usize) -> &mut A {
        self.get_mut(index).expect("Out of bounds access")
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> FromIterator<A> for VecDeque<A> {
    fn from_iter<T: IntoIterator<Item = A>>(iter: T) -> VecDeque<A> {
        let iterator = iter.into_iter();
        let (lower, _) = iterator.size_hint();
        let mut deq = VecDeque::with_capacity(lower);
        deq.extend(iterator);
        deq
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> IntoIterator for VecDeque<T> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// Naubos ang `VecDeque` sa isang harap-sa-likod na iterator na nagbibigay ng mga elemento ayon sa halaga.
    ///
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { inner: self }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a VecDeque<T> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a mut VecDeque<T> {
    type Item = &'a mut T;
    type IntoIter = IterMut<'a, T>;

    fn into_iter(self) -> IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> Extend<A> for VecDeque<A> {
    fn extend<T: IntoIterator<Item = A>>(&mut self, iter: T) {
        // Ang pagpapaandar na ito ay dapat na katumbas sa moral ng:
        //
        //      para sa item sa iter.into_iter() {
        //          self.push_back(item);
        //      }
        let mut iter = iter.into_iter();
        while let Some(element) = iter.next() {
            if self.len() == self.capacity() {
                let (lower, _) = iter.size_hint();
                self.reserve(lower.saturating_add(1));
            }

            let head = self.head;
            self.head = self.wrap_add(self.head, 1);
            unsafe {
                self.buffer_write(head, element);
            }
        }
    }

    #[inline]
    fn extend_one(&mut self, elem: A) {
        self.push_back(elem);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: 'a + Copy> Extend<&'a T> for VecDeque<T> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &elem: &T) {
        self.push_back(elem);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug> fmt::Debug for VecDeque<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self).finish()
    }
}

#[stable(feature = "vecdeque_vec_conversions", since = "1.10.0")]
impl<T> From<Vec<T>> for VecDeque<T> {
    /// Gawing isang [`Vec<T>`] sa isang [`VecDeque<T>`].
    ///
    /// [`Vec<T>`]: crate::vec::Vec
    /// [`VecDeque<T>`]: crate::collections::VecDeque
    ///
    /// Iniiwasan nito ang reallocating kung saan posible, ngunit ang mga kundisyon para sa mga iyon ay mahigpit, at napapailalim sa pagbabago, at sa gayon ay hindi dapat umasa maliban kung ang `Vec<T>` ay nagmula sa `From<VecDeque<T>>` at hindi pa nai-relocate.
    ///
    ///
    fn from(mut other: Vec<T>) -> Self {
        let len = other.len();
        if mem::size_of::<T>() == 0 {
            // Walang aktwal na paglalaan para sa mga ZST na mag-alala tungkol sa kapasidad, ngunit hindi hawakan ng `VecDeque` ang haba ng `Vec`.
            //
            assert!(len < MAXIMUM_ZST_CAPACITY, "capacity overflow");
        } else {
            // Kailangan nating baguhin ang laki kung ang kapasidad ay hindi lakas ng dalawa, masyadong maliit o walang kahit isang libreng puwang.
            // Ginagawa namin ito habang nasa `Vec` pa rin kaya ang mga item ay mahuhulog sa panic.
            //
            let min_cap = cmp::max(MINIMUM_CAPACITY, len) + 1;
            let cap = cmp::max(min_cap, other.capacity()).next_power_of_two();
            if other.capacity() != cap {
                other.reserve_exact(cap - len);
            }
        }

        unsafe {
            let (other_buf, len, capacity) = other.into_raw_parts();
            let buf = RawVec::from_raw_parts(other_buf, capacity);
            VecDeque { tail: 0, head: len, buf }
        }
    }
}

#[stable(feature = "vecdeque_vec_conversions", since = "1.10.0")]
impl<T> From<VecDeque<T>> for Vec<T> {
    /// Gawing isang [`VecDeque<T>`] sa isang [`Vec<T>`].
    ///
    /// [`Vec<T>`]: crate::vec::Vec
    /// [`VecDeque<T>`]: crate::collections::VecDeque
    ///
    /// Hindi na ito kailangang muling maglaan, ngunit kailangang gawin ang *O*(*n*) paggalaw ng data kung ang paikot na buffer ay hindi nangyari sa simula ng paglalaan.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// // Ang isang ito ay *O*(1).
    /// let deque: VecDeque<_> = (1..5).collect();
    /// let ptr = deque.as_slices().0.as_ptr();
    /// let vec = Vec::from(deque);
    /// assert_eq!(vec, [1, 2, 3, 4]);
    /// assert_eq!(vec.as_ptr(), ptr);
    ///
    /// // Ang isang ito ay nangangailangan ng muling pagsasaayos ng data.
    /// let mut deque: VecDeque<_> = (1..5).collect();
    /// deque.push_front(9);
    /// deque.push_front(8);
    /// let ptr = deque.as_slices().1.as_ptr();
    /// let vec = Vec::from(deque);
    /// assert_eq!(vec, [8, 9, 1, 2, 3, 4]);
    /// assert_eq!(vec.as_ptr(), ptr);
    /// ```
    fn from(mut other: VecDeque<T>) -> Self {
        other.make_contiguous();

        unsafe {
            let other = ManuallyDrop::new(other);
            let buf = other.buf.ptr();
            let len = other.len();
            let cap = other.cap();

            if other.tail != 0 {
                ptr::copy(buf.add(other.tail), buf, len);
            }
            Vec::from_raw_parts(buf, len, cap)
        }
    }
}