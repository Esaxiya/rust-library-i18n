//! Isang listahan na doble-link na may pagmamay-ari na mga node.
//!
//! Pinapayagan ng `LinkedList` ang pagtulak at pag-pop ng mga elemento sa alinman sa dulo ng pare-pareho ang oras.
//!
//! NOTE: Ito ay halos palaging mas mahusay na gumamit ng [`Vec`] o [`VecDeque`] dahil ang mga lalagyan na batay sa array ay karaniwang mas mabilis, mas mahusay ang memorya, at mas mahusay na magamit ang CPU cache.
//!
//!
//! [`Vec`]: crate::vec::Vec
//! [`VecDeque`]: super::vec_deque::VecDeque
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::cmp::Ordering;
use core::fmt;
use core::hash::{Hash, Hasher};
use core::iter::{FromIterator, FusedIterator};
use core::marker::PhantomData;
use core::mem;
use core::ptr::NonNull;

use super::SpecExtend;
use crate::boxed::Box;

#[cfg(test)]
mod tests;

/// Isang listahan na doble-link na may pagmamay-ari na mga node.
///
/// Pinapayagan ng `LinkedList` ang pagtulak at pag-pop ng mga elemento sa alinman sa dulo ng pare-pareho ang oras.
///
/// NOTE: Ito ay halos palaging mas mahusay na gumamit ng `Vec` o `VecDeque` dahil ang mga lalagyan na batay sa array ay karaniwang mas mabilis, mas mahusay ang memorya, at mas mahusay na magamit ang CPU cache.
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "LinkedList")]
pub struct LinkedList<T> {
    head: Option<NonNull<Node<T>>>,
    tail: Option<NonNull<Node<T>>>,
    len: usize,
    marker: PhantomData<Box<Node<T>>>,
}

struct Node<T> {
    next: Option<NonNull<Node<T>>>,
    prev: Option<NonNull<Node<T>>>,
    element: T,
}

/// Isang iterator sa mga elemento ng isang `LinkedList`.
///
/// Ang `struct` na ito ay nilikha ng [`LinkedList::iter()`].
/// Tingnan ang dokumentasyon nito para sa higit pa.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Iter<'a, T: 'a> {
    head: Option<NonNull<Node<T>>>,
    tail: Option<NonNull<Node<T>>>,
    len: usize,
    marker: PhantomData<&'a Node<T>>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for Iter<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Iter").field(&self.len).finish()
    }
}

// FIXME(#26925) Tanggalin ang pabor sa `#[derive(Clone)]`
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Clone for Iter<'_, T> {
    fn clone(&self) -> Self {
        Iter { ..*self }
    }
}

/// Isang nababagabag na iterator sa mga elemento ng isang `LinkedList`.
///
/// Ang `struct` na ito ay nilikha ng [`LinkedList::iter_mut()`].
/// Tingnan ang dokumentasyon nito para sa higit pa.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct IterMut<'a, T: 'a> {
    // Hindi namin * eksklusibong nagmamay-ari ng buong listahan dito, ang mga sanggunian sa `element` ng node ay naabot ng iterator!Kaya't mag-ingat sa paggamit nito;ang mga pamamaraan na tinawag ay dapat magkaroon ng kamalayan na maaaring may mga aliasing pointer sa `element`.
    //
    //
    list: &'a mut LinkedList<T>,
    head: Option<NonNull<Node<T>>>,
    tail: Option<NonNull<Node<T>>>,
    len: usize,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for IterMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("IterMut").field(&self.list).field(&self.len).finish()
    }
}

/// Isang nagmamay-ari na iterator sa mga elemento ng isang `LinkedList`.
///
/// Ang `struct` na ito ay nilikha ng pamamaraang [`into_iter`] sa [`LinkedList`] (na ibinigay ng `IntoIterator` trait).
/// Tingnan ang dokumentasyon nito para sa higit pa.
///
/// [`into_iter`]: LinkedList::into_iter
#[derive(Clone)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct IntoIter<T> {
    list: LinkedList<T>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for IntoIter<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("IntoIter").field(&self.list).finish()
    }
}

impl<T> Node<T> {
    fn new(element: T) -> Self {
        Node { next: None, prev: None, element }
    }

    fn into_element(self: Box<Self>) -> T {
        self.element
    }
}

// pribadong pamamaraan
impl<T> LinkedList<T> {
    /// Idinaragdag ang ibinigay na node sa harap ng listahan.
    #[inline]
    fn push_front_node(&mut self, mut node: Box<Node<T>>) {
        // Nag-iingat ang pamamaraang ito na hindi lumikha ng mga nababagong sanggunian sa buong mga node, upang mapanatili ang bisa ng mga aliasing pointer sa `element`.
        //
        unsafe {
            node.next = self.head;
            node.prev = None;
            let node = Some(Box::leak(node).into());

            match self.head {
                None => self.tail = node,
                // Hindi lumilikha ng bagong nababagong mga sanggunian na (unique!) na nagsasapawan ng `element`.
                Some(head) => (*head.as_ptr()).prev = node,
            }

            self.head = node;
            self.len += 1;
        }
    }

    /// Tanggalin at ibabalik ang node sa harap ng listahan.
    #[inline]
    fn pop_front_node(&mut self) -> Option<Box<Node<T>>> {
        // Nag-iingat ang pamamaraang ito na hindi lumikha ng mga nababagong sanggunian sa buong mga node, upang mapanatili ang bisa ng mga aliasing pointer sa `element`.
        //
        self.head.map(|node| unsafe {
            let node = Box::from_raw(node.as_ptr());
            self.head = node.next;

            match self.head {
                None => self.tail = None,
                // Hindi lumilikha ng bagong nababagong mga sanggunian na (unique!) na nagsasapawan ng `element`.
                Some(head) => (*head.as_ptr()).prev = None,
            }

            self.len -= 1;
            node
        })
    }

    /// Idinaragdag ang ibinigay na node sa likod ng listahan.
    #[inline]
    fn push_back_node(&mut self, mut node: Box<Node<T>>) {
        // Nag-iingat ang pamamaraang ito na hindi lumikha ng mga nababagong sanggunian sa buong mga node, upang mapanatili ang bisa ng mga aliasing pointer sa `element`.
        //
        unsafe {
            node.next = None;
            node.prev = self.tail;
            let node = Some(Box::leak(node).into());

            match self.tail {
                None => self.head = node,
                // Hindi lumilikha ng bagong nababagong mga sanggunian na (unique!) na nagsasapawan ng `element`.
                Some(tail) => (*tail.as_ptr()).next = node,
            }

            self.tail = node;
            self.len += 1;
        }
    }

    /// Tanggalin at ibabalik ang node sa likod ng listahan.
    #[inline]
    fn pop_back_node(&mut self) -> Option<Box<Node<T>>> {
        // Nag-iingat ang pamamaraang ito na hindi lumikha ng mga nababagong sanggunian sa buong mga node, upang mapanatili ang bisa ng mga aliasing pointer sa `element`.
        //
        self.tail.map(|node| unsafe {
            let node = Box::from_raw(node.as_ptr());
            self.tail = node.prev;

            match self.tail {
                None => self.head = None,
                // Hindi lumilikha ng bagong nababagong mga sanggunian na (unique!) na nagsasapawan ng `element`.
                Some(tail) => (*tail.as_ptr()).next = None,
            }

            self.len -= 1;
            node
        })
    }

    /// Ina-unlink ang tinukoy na node mula sa kasalukuyang listahan.
    ///
    /// Babala: hindi nito susuriing ang ibinigay na node ay kabilang sa kasalukuyang listahan.
    ///
    /// Nag-iingat ang pamamaraang ito na hindi lumikha ng mga nababagong sanggunian sa `element`, upang mapanatili ang bisa ng mga pahiwatig ng aliasing.
    ///
    #[inline]
    unsafe fn unlink_node(&mut self, mut node: NonNull<Node<T>>) {
        let node = unsafe { node.as_mut() }; // ang isang ito ay atin ngayon, makakalikha tayo ng isang &mut.

        // Hindi lumilikha ng bagong nababagong mga sanggunian na (unique!) na nagsasapawan ng `element`.
        match node.prev {
            Some(prev) => unsafe { (*prev.as_ptr()).next = node.next },
            // ang node na ito ay ang head node
            None => self.head = node.next,
        };

        match node.next {
            Some(next) => unsafe { (*next.as_ptr()).prev = node.prev },
            // ang node na ito ay ang tail node
            None => self.tail = node.prev,
        };

        self.len -= 1;
    }

    /// Pinagsasama ang isang serye ng mga node sa pagitan ng dalawang mayroon nang mga node.
    ///
    /// Babala: hindi nito susuriing ang ibinigay na node ay kabilang sa dalawang mayroon nang mga listahan.
    #[inline]
    unsafe fn splice_nodes(
        &mut self,
        existing_prev: Option<NonNull<Node<T>>>,
        existing_next: Option<NonNull<Node<T>>>,
        mut splice_start: NonNull<Node<T>>,
        mut splice_end: NonNull<Node<T>>,
        splice_length: usize,
    ) {
        // Nag-iingat ang pamamaraang ito na hindi lumikha ng maramihang mga nababagong sanggunian sa buong mga node nang sabay-sabay, upang mapanatili ang bisa ng mga aliasing pointer sa `element`.
        //
        if let Some(mut existing_prev) = existing_prev {
            unsafe {
                existing_prev.as_mut().next = Some(splice_start);
            }
        } else {
            self.head = Some(splice_start);
        }
        if let Some(mut existing_next) = existing_next {
            unsafe {
                existing_next.as_mut().prev = Some(splice_end);
            }
        } else {
            self.tail = Some(splice_end);
        }
        unsafe {
            splice_start.as_mut().prev = existing_prev;
            splice_end.as_mut().next = existing_next;
        }

        self.len += splice_length;
    }

    /// Tinatanggal ang lahat ng mga node mula sa isang naka-link na listahan bilang isang serye ng mga node.
    #[inline]
    fn detach_all_nodes(mut self) -> Option<(NonNull<Node<T>>, NonNull<Node<T>>, usize)> {
        let head = self.head.take();
        let tail = self.tail.take();
        let len = mem::replace(&mut self.len, 0);
        if let Some(head) = head {
            let tail = tail.unwrap_or_else(|| unsafe { core::hint::unreachable_unchecked() });
            Some((head, tail, len))
        } else {
            None
        }
    }

    #[inline]
    unsafe fn split_off_before_node(
        &mut self,
        split_node: Option<NonNull<Node<T>>>,
        at: usize,
    ) -> Self {
        // Ang split node ay ang bagong head node ng ikalawang bahagi
        if let Some(mut split_node) = split_node {
            let first_part_head;
            let first_part_tail;
            unsafe {
                first_part_tail = split_node.as_mut().prev.take();
            }
            if let Some(mut tail) = first_part_tail {
                unsafe {
                    tail.as_mut().next = None;
                }
                first_part_head = self.head;
            } else {
                first_part_head = None;
            }

            let first_part = LinkedList {
                head: first_part_head,
                tail: first_part_tail,
                len: at,
                marker: PhantomData,
            };

            // Ayusin ang ulo ptr ng ikalawang bahagi
            self.head = Some(split_node);
            self.len = self.len - at;

            first_part
        } else {
            mem::replace(self, LinkedList::new())
        }
    }

    #[inline]
    unsafe fn split_off_after_node(
        &mut self,
        split_node: Option<NonNull<Node<T>>>,
        at: usize,
    ) -> Self {
        // Ang split node ay ang bagong tail node ng unang bahagi at nagmamay-ari ng ulo ng pangalawang bahagi.
        //
        if let Some(mut split_node) = split_node {
            let second_part_head;
            let second_part_tail;
            unsafe {
                second_part_head = split_node.as_mut().next.take();
            }
            if let Some(mut head) = second_part_head {
                unsafe {
                    head.as_mut().prev = None;
                }
                second_part_tail = self.tail;
            } else {
                second_part_tail = None;
            }

            let second_part = LinkedList {
                head: second_part_head,
                tail: second_part_tail,
                len: self.len - at,
                marker: PhantomData,
            };

            // Ayusin ang buntot ptr ng unang bahagi
            self.tail = Some(split_node);
            self.len = at;

            second_part
        } else {
            mem::replace(self, LinkedList::new())
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for LinkedList<T> {
    /// Lumilikha ng isang walang laman na `LinkedList<T>`.
    #[inline]
    fn default() -> Self {
        Self::new()
    }
}

impl<T> LinkedList<T> {
    /// Lumilikha ng isang walang laman na `LinkedList`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let list: LinkedList<u32> = LinkedList::new();
    /// ```
    #[inline]
    #[rustc_const_stable(feature = "const_linked_list_new", since = "1.32.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> Self {
        LinkedList { head: None, tail: None, len: 0, marker: PhantomData }
    }

    /// Inililipat ang lahat ng mga elemento mula sa `other` hanggang sa dulo ng listahan.
    ///
    /// Muling ginagamit nito ang lahat ng mga node mula sa `other` at inililipat ang mga ito sa `self`.
    /// Matapos ang operasyon na ito, ang `other` ay walang laman.
    ///
    /// Ang pagpapatakbo na ito ay dapat na makalkula sa *O*(1) oras at *O*(1) memorya.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut list1 = LinkedList::new();
    /// list1.push_back('a');
    ///
    /// let mut list2 = LinkedList::new();
    /// list2.push_back('b');
    /// list2.push_back('c');
    ///
    /// list1.append(&mut list2);
    ///
    /// let mut iter = list1.iter();
    /// assert_eq!(iter.next(), Some(&'a'));
    /// assert_eq!(iter.next(), Some(&'b'));
    /// assert_eq!(iter.next(), Some(&'c'));
    /// assert!(iter.next().is_none());
    ///
    /// assert!(list2.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn append(&mut self, other: &mut Self) {
        match self.tail {
            None => mem::swap(self, other),
            Some(mut tail) => {
                // `as_mut` ayos lang dito sapagkat mayroon kaming eksklusibong pag-access sa kabuuan ng parehong listahan.
                //
                if let Some(mut other_head) = other.head.take() {
                    unsafe {
                        tail.as_mut().next = Some(other_head);
                        other_head.as_mut().prev = Some(tail);
                    }

                    self.tail = other.tail.take();
                    self.len += mem::replace(&mut other.len, 0);
                }
            }
        }
    }

    /// Inililipat ang lahat ng mga elemento mula sa `other` hanggang sa simula ng listahan.
    #[unstable(feature = "linked_list_prepend", issue = "none")]
    pub fn prepend(&mut self, other: &mut Self) {
        match self.head {
            None => mem::swap(self, other),
            Some(mut head) => {
                // `as_mut` ayos lang dito sapagkat mayroon kaming eksklusibong pag-access sa kabuuan ng parehong listahan.
                //
                if let Some(mut other_tail) = other.tail.take() {
                    unsafe {
                        head.as_mut().prev = Some(other_tail);
                        other_tail.as_mut().next = Some(head);
                    }

                    self.head = other.head.take();
                    self.len += mem::replace(&mut other.len, 0);
                }
            }
        }
    }

    /// Nagbibigay ng isang forward iterator.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut list: LinkedList<u32> = LinkedList::new();
    ///
    /// list.push_back(0);
    /// list.push_back(1);
    /// list.push_back(2);
    ///
    /// let mut iter = list.iter();
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter { head: self.head, tail: self.tail, len: self.len, marker: PhantomData }
    }

    /// Nagbibigay ng isang pasulong na umuulit na may mga nababagong sanggunian.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut list: LinkedList<u32> = LinkedList::new();
    ///
    /// list.push_back(0);
    /// list.push_back(1);
    /// list.push_back(2);
    ///
    /// for element in list.iter_mut() {
    ///     *element += 10;
    /// }
    ///
    /// let mut iter = list.iter();
    /// assert_eq!(iter.next(), Some(&10));
    /// assert_eq!(iter.next(), Some(&11));
    /// assert_eq!(iter.next(), Some(&12));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        IterMut { head: self.head, tail: self.tail, len: self.len, list: self }
    }

    /// Nagbibigay ng isang cursor sa harap na elemento.
    ///
    /// Ang cursor ay tumuturo sa "ghost" na hindi elemento kung ang listahan ay walang laman.
    #[inline]
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn cursor_front(&self) -> Cursor<'_, T> {
        Cursor { index: 0, current: self.head, list: self }
    }

    /// Nagbibigay ng isang cursor na may mga pagpapatakbo sa pag-edit sa pangunahing elemento.
    ///
    /// Ang cursor ay tumuturo sa "ghost" na hindi elemento kung ang listahan ay walang laman.
    #[inline]
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn cursor_front_mut(&mut self) -> CursorMut<'_, T> {
        CursorMut { index: 0, current: self.head, list: self }
    }

    /// Nagbibigay ng isang cursor sa elemento ng likod.
    ///
    /// Ang cursor ay tumuturo sa "ghost" na hindi elemento kung ang listahan ay walang laman.
    #[inline]
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn cursor_back(&self) -> Cursor<'_, T> {
        Cursor { index: self.len.checked_sub(1).unwrap_or(0), current: self.tail, list: self }
    }

    /// Nagbibigay ng isang cursor na may mga pagpapatakbo sa pag-edit sa elemento ng likod.
    ///
    /// Ang cursor ay tumuturo sa "ghost" na hindi elemento kung ang listahan ay walang laman.
    #[inline]
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn cursor_back_mut(&mut self) -> CursorMut<'_, T> {
        CursorMut { index: self.len.checked_sub(1).unwrap_or(0), current: self.tail, list: self }
    }

    /// Ibinabalik ang `true` kung ang `LinkedList` ay walang laman.
    ///
    /// Ang pagpapatakbong ito ay dapat na makalkula sa *O*(1) oras.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    /// assert!(dl.is_empty());
    ///
    /// dl.push_front("foo");
    /// assert!(!dl.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.head.is_none()
    }

    /// Ibinabalik ang haba ng `LinkedList`.
    ///
    /// Ang pagpapatakbong ito ay dapat na makalkula sa *O*(1) oras.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    ///
    /// dl.push_front(2);
    /// assert_eq!(dl.len(), 1);
    ///
    /// dl.push_front(1);
    /// assert_eq!(dl.len(), 2);
    ///
    /// dl.push_back(3);
    /// assert_eq!(dl.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.len
    }

    /// Tinatanggal ang lahat ng mga elemento mula sa `LinkedList`.
    ///
    /// Ang pagpapatakbong ito ay dapat na makalkula sa oras *O*(*n*).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    ///
    /// dl.push_front(2);
    /// dl.push_front(1);
    /// assert_eq!(dl.len(), 2);
    /// assert_eq!(dl.front(), Some(&1));
    ///
    /// dl.clear();
    /// assert_eq!(dl.len(), 0);
    /// assert_eq!(dl.front(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        *self = Self::new();
    }

    /// Ibinabalik ang `true` kung ang `LinkedList` ay naglalaman ng isang elemento na katumbas ng ibinigay na halaga.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut list: LinkedList<u32> = LinkedList::new();
    ///
    /// list.push_back(0);
    /// list.push_back(1);
    /// list.push_back(2);
    ///
    /// assert_eq!(list.contains(&0), true);
    /// assert_eq!(list.contains(&10), false);
    /// ```
    #[stable(feature = "linked_list_contains", since = "1.12.0")]
    pub fn contains(&self, x: &T) -> bool
    where
        T: PartialEq<T>,
    {
        self.iter().any(|e| e == x)
    }

    /// Nagbibigay ng isang sanggunian sa harap na elemento, o `None` kung ang listahan ay walang laman.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    /// assert_eq!(dl.front(), None);
    ///
    /// dl.push_front(1);
    /// assert_eq!(dl.front(), Some(&1));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn front(&self) -> Option<&T> {
        unsafe { self.head.as_ref().map(|node| &node.as_ref().element) }
    }

    /// Nagbibigay ng isang nababagong sanggunian sa harap na elemento, o `None` kung ang listahan ay walang laman.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    /// assert_eq!(dl.front(), None);
    ///
    /// dl.push_front(1);
    /// assert_eq!(dl.front(), Some(&1));
    ///
    /// match dl.front_mut() {
    ///     None => {},
    ///     Some(x) => *x = 5,
    /// }
    /// assert_eq!(dl.front(), Some(&5));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn front_mut(&mut self) -> Option<&mut T> {
        unsafe { self.head.as_mut().map(|node| &mut node.as_mut().element) }
    }

    /// Nagbibigay ng isang sanggunian sa elemento ng likod, o `None` kung ang listahan ay walang laman.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    /// assert_eq!(dl.back(), None);
    ///
    /// dl.push_back(1);
    /// assert_eq!(dl.back(), Some(&1));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn back(&self) -> Option<&T> {
        unsafe { self.tail.as_ref().map(|node| &node.as_ref().element) }
    }

    /// Nagbibigay ng isang nababagong sanggunian sa elemento ng likod, o `None` kung ang listahan ay walang laman.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    /// assert_eq!(dl.back(), None);
    ///
    /// dl.push_back(1);
    /// assert_eq!(dl.back(), Some(&1));
    ///
    /// match dl.back_mut() {
    ///     None => {},
    ///     Some(x) => *x = 5,
    /// }
    /// assert_eq!(dl.back(), Some(&5));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn back_mut(&mut self) -> Option<&mut T> {
        unsafe { self.tail.as_mut().map(|node| &mut node.as_mut().element) }
    }

    /// Nagdaragdag muna ng isang elemento sa listahan.
    ///
    /// Ang pagpapatakbong ito ay dapat na makalkula sa *O*(1) oras.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    ///
    /// dl.push_front(2);
    /// assert_eq!(dl.front().unwrap(), &2);
    ///
    /// dl.push_front(1);
    /// assert_eq!(dl.front().unwrap(), &1);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_front(&mut self, elt: T) {
        self.push_front_node(box Node::new(elt));
    }

    /// Tinatanggal ang unang elemento at ibinalik ito, o `None` kung ang listahan ay walang laman.
    ///
    ///
    /// Ang pagpapatakbong ito ay dapat na makalkula sa *O*(1) oras.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut d = LinkedList::new();
    /// assert_eq!(d.pop_front(), None);
    ///
    /// d.push_front(1);
    /// d.push_front(3);
    /// assert_eq!(d.pop_front(), Some(3));
    /// assert_eq!(d.pop_front(), Some(1));
    /// assert_eq!(d.pop_front(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop_front(&mut self) -> Option<T> {
        self.pop_front_node().map(Node::into_element)
    }

    /// Nagdadagdag ng isang elemento sa likod ng isang listahan.
    ///
    /// Ang pagpapatakbong ito ay dapat na makalkula sa *O*(1) oras.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut d = LinkedList::new();
    /// d.push_back(1);
    /// d.push_back(3);
    /// assert_eq!(3, *d.back().unwrap());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_back(&mut self, elt: T) {
        self.push_back_node(box Node::new(elt));
    }

    /// Tinatanggal ang huling elemento mula sa isang listahan at ibinalik ito, o `None` kung ito ay walang laman.
    ///
    ///
    /// Ang pagpapatakbong ito ay dapat na makalkula sa *O*(1) oras.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut d = LinkedList::new();
    /// assert_eq!(d.pop_back(), None);
    /// d.push_back(1);
    /// d.push_back(3);
    /// assert_eq!(d.pop_back(), Some(3));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop_back(&mut self) -> Option<T> {
        self.pop_back_node().map(Node::into_element)
    }

    /// Hinahati ang listahan sa dalawa sa ibinigay na index.
    /// Ibinabalik ang lahat pagkatapos ng ibinigay na index, kasama ang index.
    ///
    /// Ang pagpapatakbong ito ay dapat na makalkula sa oras *O*(*n*).
    ///
    /// # Panics
    ///
    /// Panics kung `at > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut d = LinkedList::new();
    ///
    /// d.push_front(1);
    /// d.push_front(2);
    /// d.push_front(3);
    ///
    /// let mut split = d.split_off(2);
    ///
    /// assert_eq!(split.pop_front(), Some(1));
    /// assert_eq!(split.pop_front(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn split_off(&mut self, at: usize) -> LinkedList<T> {
        let len = self.len();
        assert!(at <= len, "Cannot split off at a nonexistent index");
        if at == 0 {
            return mem::take(self);
        } else if at == len {
            return Self::new();
        }

        // Sa ibaba, umuulit kami patungo sa `i-1`th node, alinman sa simula o sa wakas, depende sa kung alin ang magiging mas mabilis.
        //
        let split_node = if at - 1 <= len - 1 - (at - 1) {
            let mut iter = self.iter_mut();
            // sa halip na laktawan ang paggamit ng .skip() (na lumilikha ng isang bagong istraktura), manu-mano kaming lumaktaw upang ma-access namin ang patlang ng ulo nang hindi nakasalalay sa mga detalye ng pagpapatupad ng Laktawan
            //
            //
            for _ in 0..at - 1 {
                iter.next();
            }
            iter.head
        } else {
            // mas mabuti simula sa huli
            let mut iter = self.iter_mut();
            for _ in 0..len - 1 - (at - 1) {
                iter.next_back();
            }
            iter.tail
        };
        unsafe { self.split_off_after_node(split_node, at) }
    }

    /// Tinatanggal ang elemento sa ibinigay na index at ibinalik ito.
    ///
    /// Ang pagpapatakbong ito ay dapat na makalkula sa oras *O*(*n*).
    ///
    /// # Panics
    /// Panics kung sa>=len
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(linked_list_remove)]
    /// use std::collections::LinkedList;
    ///
    /// let mut d = LinkedList::new();
    ///
    /// d.push_front(1);
    /// d.push_front(2);
    /// d.push_front(3);
    ///
    /// assert_eq!(d.remove(1), 2);
    /// assert_eq!(d.remove(0), 3);
    /// assert_eq!(d.remove(0), 1);
    /// ```
    #[unstable(feature = "linked_list_remove", issue = "69210")]
    pub fn remove(&mut self, at: usize) -> T {
        let len = self.len();
        assert!(at < len, "Cannot remove at an index outside of the list bounds");

        // Sa ibaba, umuulit kami patungo sa node sa ibinigay na index, alinman sa simula o sa wakas, depende sa kung alin ang magiging mas mabilis.
        //
        let offset_from_end = len - at - 1;
        if at <= offset_from_end {
            let mut cursor = self.cursor_front_mut();
            for _ in 0..at {
                cursor.move_next();
            }
            cursor.remove_current().unwrap()
        } else {
            let mut cursor = self.cursor_back_mut();
            for _ in 0..offset_from_end {
                cursor.move_prev();
            }
            cursor.remove_current().unwrap()
        }
    }

    /// Lumilikha ng isang umuulit na gumagamit ng isang pagsasara upang matukoy kung ang isang elemento ay dapat na alisin.
    ///
    /// Kung ang pagsasara ay bumalik na totoo, pagkatapos ang elemento ay aalisin at ibigay.
    /// Kung ang pagsasara ay nagbalik ng hindi totoo, ang elemento ay mananatili sa listahan at hindi ibibigay ng iterator.
    ///
    /// Tandaan na hinahayaan ka ng `drain_filter` na magbago ang bawat elemento sa pagsasara ng filter, hindi alintana kung pipiliin mong panatilihin o alisin ito.
    ///
    ///
    /// # Examples
    ///
    /// Paghahati sa isang listahan sa mga pantay at logro, muling paggamit sa orihinal na listahan:
    ///
    /// ```
    /// #![feature(drain_filter)]
    /// use std::collections::LinkedList;
    ///
    /// let mut numbers: LinkedList<u32> = LinkedList::new();
    /// numbers.extend(&[1, 2, 3, 4, 5, 6, 8, 9, 11, 13, 14, 15]);
    ///
    /// let evens = numbers.drain_filter(|x| *x % 2 == 0).collect::<LinkedList<_>>();
    /// let odds = numbers;
    ///
    /// assert_eq!(evens.into_iter().collect::<Vec<_>>(), vec![2, 4, 6, 8, 14]);
    /// assert_eq!(odds.into_iter().collect::<Vec<_>>(), vec![1, 3, 5, 9, 11, 13, 15]);
    /// ```
    ///
    #[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
    pub fn drain_filter<F>(&mut self, filter: F) -> DrainFilter<'_, T, F>
    where
        F: FnMut(&mut T) -> bool,
    {
        // iwasan ang mga isyu sa paghiram.
        let it = self.head;
        let old_len = self.len;

        DrainFilter { list: self, it, pred: filter, idx: 0, old_len }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T> Drop for LinkedList<T> {
    fn drop(&mut self) {
        struct DropGuard<'a, T>(&'a mut LinkedList<T>);

        impl<'a, T> Drop for DropGuard<'a, T> {
            fn drop(&mut self) {
                // Ipagpatuloy ang parehong loop na ginagawa namin sa ibaba.Tumatakbo lamang ito kapag nag-panic ang isang destructor.
                // Kung ang isa pang panics ay tatanggalin ito.
                while self.0.pop_front_node().is_some() {}
            }
        }

        while let Some(node) = self.pop_front_node() {
            let guard = DropGuard(self);
            drop(node);
            mem::forget(guard);
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for Iter<'a, T> {
    type Item = &'a T;

    #[inline]
    fn next(&mut self) -> Option<&'a T> {
        if self.len == 0 {
            None
        } else {
            self.head.map(|node| unsafe {
                // Kailangan mo ng isang walang hangganang buhay upang makakuha ng 'a
                let node = &*node.as_ptr();
                self.len -= 1;
                self.head = node.next;
                &node.element
            })
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (self.len, Some(self.len))
    }

    #[inline]
    fn last(mut self) -> Option<&'a T> {
        self.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for Iter<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a T> {
        if self.len == 0 {
            None
        } else {
            self.tail.map(|node| unsafe {
                // Kailangan mo ng isang walang hangganang buhay upang makakuha ng 'a
                let node = &*node.as_ptr();
                self.len -= 1;
                self.tail = node.prev;
                &node.element
            })
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for Iter<'_, T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Iter<'_, T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for IterMut<'a, T> {
    type Item = &'a mut T;

    #[inline]
    fn next(&mut self) -> Option<&'a mut T> {
        if self.len == 0 {
            None
        } else {
            self.head.map(|node| unsafe {
                // Kailangan mo ng isang walang hangganang buhay upang makakuha ng 'a
                let node = &mut *node.as_ptr();
                self.len -= 1;
                self.head = node.next;
                &mut node.element
            })
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (self.len, Some(self.len))
    }

    #[inline]
    fn last(mut self) -> Option<&'a mut T> {
        self.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for IterMut<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a mut T> {
        if self.len == 0 {
            None
        } else {
            self.tail.map(|node| unsafe {
                // Kailangan mo ng isang walang hangganang buhay upang makakuha ng 'a
                let node = &mut *node.as_ptr();
                self.len -= 1;
                self.tail = node.prev;
                &mut node.element
            })
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for IterMut<'_, T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for IterMut<'_, T> {}

/// Isang cursor sa isang `LinkedList`.
///
/// Ang `Cursor` ay tulad ng isang iterator, maliban na maaari itong malayang humingi ng pabalik-balik.
///
/// Palaging nagpapahinga ang mga Cursor sa pagitan ng dalawang elemento sa listahan, at na-index sa isang lohikal na pabilog na paraan.
/// Upang mapaunlakan ito, mayroong isang "ghost" na hindi elemento na magbubunga ng `None` sa pagitan ng ulo at buntot ng listahan.
///
///
/// Kapag nilikha, magsisimula ang mga cursor sa harap ng listahan, o ang "ghost" na hindi elemento kung ang listahan ay walang laman.
#[unstable(feature = "linked_list_cursors", issue = "58533")]
pub struct Cursor<'a, T: 'a> {
    index: usize,
    current: Option<NonNull<Node<T>>>,
    list: &'a LinkedList<T>,
}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
impl<T> Clone for Cursor<'_, T> {
    fn clone(&self) -> Self {
        let Cursor { index, current, list } = *self;
        Cursor { index, current, list }
    }
}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
impl<T: fmt::Debug> fmt::Debug for Cursor<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Cursor").field(&self.list).field(&self.index()).finish()
    }
}

/// Isang cursor sa isang `LinkedList` na may mga pagpapatakbo sa pag-edit.
///
/// Ang `Cursor` ay tulad ng isang iterator, maliban na maaari itong malayang humingi ng pabalik-balik, at ligtas na mai-mutate ang listahan sa panahon ng pag-ulit.
/// Ito ay dahil ang panghabambuhay ng mga nabuong sanggunian ay nakatali sa sarili nitong buhay, sa halip na ang napapailalim na listahan lamang.
/// Nangangahulugan ito na ang mga cursor ay hindi maaaring magbigay ng maraming elemento nang sabay-sabay.
///
/// Palaging nagpapahinga ang mga Cursor sa pagitan ng dalawang elemento sa listahan, at na-index sa isang lohikal na pabilog na paraan.
/// Upang mapaunlakan ito, mayroong isang "ghost" na hindi elemento na magbubunga ng `None` sa pagitan ng ulo at buntot ng listahan.
///
///
#[unstable(feature = "linked_list_cursors", issue = "58533")]
pub struct CursorMut<'a, T: 'a> {
    index: usize,
    current: Option<NonNull<Node<T>>>,
    list: &'a mut LinkedList<T>,
}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
impl<T: fmt::Debug> fmt::Debug for CursorMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("CursorMut").field(&self.list).field(&self.index()).finish()
    }
}

impl<'a, T> Cursor<'a, T> {
    /// Ibinabalik ang index ng posisyon ng cursor sa loob ng `LinkedList`.
    ///
    /// Ibinabalik nito ang `None` kung ang cursor ay kasalukuyang tumuturo sa "ghost" na hindi elemento.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn index(&self) -> Option<usize> {
        let _ = self.current?;
        Some(self.index)
    }

    /// Inililipat ang cursor sa susunod na elemento ng `LinkedList`.
    ///
    /// Kung ang cursor ay tumuturo sa "ghost" non-element pagkatapos ay ilipat ito sa unang elemento ng `LinkedList`.
    /// Kung ito ay tumuturo sa huling elemento ng `LinkedList` pagkatapos ay ilipat ito sa "ghost" na hindi elemento.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn move_next(&mut self) {
        match self.current.take() {
            // Wala kaming kasalukuyang elemento;ang cursor ay nakaupo sa panimulang posisyon Susunod na elemento ay dapat na ang pinuno ng listahan
            //
            None => {
                self.current = self.list.head;
                self.index = 0;
            }
            // Mayroon kaming nakaraang elemento, kaya't sundin natin ito sa susunod
            Some(current) => unsafe {
                self.current = current.as_ref().next;
                self.index += 1;
            },
        }
    }

    /// Inililipat ang cursor sa nakaraang elemento ng `LinkedList`.
    ///
    /// Kung ang cursor ay tumuturo sa "ghost" na hindi elemento pagkatapos ay ilipat ito sa huling elemento ng `LinkedList`.
    /// Kung ito ay tumuturo sa unang elemento ng `LinkedList` pagkatapos ay ilipat ito sa "ghost" na hindi elemento.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn move_prev(&mut self) {
        match self.current.take() {
            // Walang kasalukuyangNasa simula na kami ng listahan.Magbunga Wala at tumalon sa dulo.
            None => {
                self.current = self.list.tail;
                self.index = self.list.len().checked_sub(1).unwrap_or(0);
            }
            // May prevYield ito at pumunta sa nakaraang elemento.
            Some(current) => unsafe {
                self.current = current.as_ref().prev;
                self.index = self.index.checked_sub(1).unwrap_or_else(|| self.list.len());
            },
        }
    }

    /// Nagbabalik ng isang sanggunian sa elemento na kasalukuyang itinuturo ng cursor.
    ///
    /// Ibinabalik nito ang `None` kung ang cursor ay kasalukuyang tumuturo sa "ghost" na hindi elemento.
    ///
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn current(&self) -> Option<&'a T> {
        unsafe { self.current.map(|current| &(*current.as_ptr()).element) }
    }

    /// Nagbabalik ng isang sanggunian sa susunod na elemento.
    ///
    /// Kung ang cursor ay tumuturo sa "ghost" na hindi elemento pagkatapos ay ibabalik nito ang unang elemento ng `LinkedList`.
    /// Kung ito ay tumuturo sa huling elemento ng `LinkedList` pagkatapos ay ibabalik nito ang `None`.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn peek_next(&self) -> Option<&'a T> {
        unsafe {
            let next = match self.current {
                None => self.list.head,
                Some(current) => current.as_ref().next,
            };
            next.map(|next| &(*next.as_ptr()).element)
        }
    }

    /// Nagbabalik ng isang sanggunian sa nakaraang elemento.
    ///
    /// Kung ang cursor ay tumuturo sa "ghost" na hindi elemento pagkatapos ay ibabalik nito ang huling elemento ng `LinkedList`.
    /// Kung ito ay tumuturo sa unang elemento ng `LinkedList` pagkatapos ay ibabalik nito ang `None`.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn peek_prev(&self) -> Option<&'a T> {
        unsafe {
            let prev = match self.current {
                None => self.list.tail,
                Some(current) => current.as_ref().prev,
            };
            prev.map(|prev| &(*prev.as_ptr()).element)
        }
    }
}

impl<'a, T> CursorMut<'a, T> {
    /// Ibinabalik ang index ng posisyon ng cursor sa loob ng `LinkedList`.
    ///
    /// Ibinabalik nito ang `None` kung ang cursor ay kasalukuyang tumuturo sa "ghost" na hindi elemento.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn index(&self) -> Option<usize> {
        let _ = self.current?;
        Some(self.index)
    }

    /// Inililipat ang cursor sa susunod na elemento ng `LinkedList`.
    ///
    /// Kung ang cursor ay tumuturo sa "ghost" non-element pagkatapos ay ilipat ito sa unang elemento ng `LinkedList`.
    /// Kung ito ay tumuturo sa huling elemento ng `LinkedList` pagkatapos ay ilipat ito sa "ghost" na hindi elemento.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn move_next(&mut self) {
        match self.current.take() {
            // Wala kaming kasalukuyang elemento;ang cursor ay nakaupo sa panimulang posisyon Susunod na elemento ay dapat na ang pinuno ng listahan
            //
            None => {
                self.current = self.list.head;
                self.index = 0;
            }
            // Mayroon kaming nakaraang elemento, kaya't sundin natin ito sa susunod
            Some(current) => unsafe {
                self.current = current.as_ref().next;
                self.index += 1;
            },
        }
    }

    /// Inililipat ang cursor sa nakaraang elemento ng `LinkedList`.
    ///
    /// Kung ang cursor ay tumuturo sa "ghost" na hindi elemento pagkatapos ay ilipat ito sa huling elemento ng `LinkedList`.
    /// Kung ito ay tumuturo sa unang elemento ng `LinkedList` pagkatapos ay ilipat ito sa "ghost" na hindi elemento.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn move_prev(&mut self) {
        match self.current.take() {
            // Walang kasalukuyangNasa simula na kami ng listahan.Magbunga Wala at tumalon sa dulo.
            None => {
                self.current = self.list.tail;
                self.index = self.list.len().checked_sub(1).unwrap_or(0);
            }
            // May prevYield ito at pumunta sa nakaraang elemento.
            Some(current) => unsafe {
                self.current = current.as_ref().prev;
                self.index = self.index.checked_sub(1).unwrap_or_else(|| self.list.len());
            },
        }
    }

    /// Nagbabalik ng isang sanggunian sa elemento na kasalukuyang itinuturo ng cursor.
    ///
    /// Ibinabalik nito ang `None` kung ang cursor ay kasalukuyang tumuturo sa "ghost" na hindi elemento.
    ///
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn current(&mut self) -> Option<&mut T> {
        unsafe { self.current.map(|current| &mut (*current.as_ptr()).element) }
    }

    /// Nagbabalik ng isang sanggunian sa susunod na elemento.
    ///
    /// Kung ang cursor ay tumuturo sa "ghost" na hindi elemento pagkatapos ay ibabalik nito ang unang elemento ng `LinkedList`.
    /// Kung ito ay tumuturo sa huling elemento ng `LinkedList` pagkatapos ay ibabalik nito ang `None`.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn peek_next(&mut self) -> Option<&mut T> {
        unsafe {
            let next = match self.current {
                None => self.list.head,
                Some(current) => current.as_ref().next,
            };
            next.map(|next| &mut (*next.as_ptr()).element)
        }
    }

    /// Nagbabalik ng isang sanggunian sa nakaraang elemento.
    ///
    /// Kung ang cursor ay tumuturo sa "ghost" na hindi elemento pagkatapos ay ibabalik nito ang huling elemento ng `LinkedList`.
    /// Kung ito ay tumuturo sa unang elemento ng `LinkedList` pagkatapos ay ibabalik nito ang `None`.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn peek_prev(&mut self) -> Option<&mut T> {
        unsafe {
            let prev = match self.current {
                None => self.list.tail,
                Some(current) => current.as_ref().prev,
            };
            prev.map(|prev| &mut (*prev.as_ptr()).element)
        }
    }

    /// Nagbabalik ng read-only na cursor na tumuturo sa kasalukuyang elemento.
    ///
    /// Ang panghabang buhay ng naibalik na `Cursor` ay nakasalalay sa `CursorMut`, na nangangahulugang hindi nito mabubuhay ang `CursorMut` at ang `CursorMut` ay na-freeze sa habang buhay ng `Cursor`.
    ///
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn as_cursor(&self) -> Cursor<'_, T> {
        Cursor { list: self.list, current: self.current, index: self.index }
    }
}

// Ngayon ang pagpapatakbo ng pag-edit ng listahan

impl<'a, T> CursorMut<'a, T> {
    /// Nagpapasok ng isang bagong elemento sa `LinkedList` pagkatapos ng kasalukuyang isa.
    ///
    /// Kung ang cursor ay tumuturo sa "ghost" na hindi elemento pagkatapos ang bagong elemento ay naipasok sa harap ng `LinkedList`.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn insert_after(&mut self, item: T) {
        unsafe {
            let spliced_node = Box::leak(Box::new(Node::new(item))).into();
            let node_next = match self.current {
                None => self.list.head,
                Some(node) => node.as_ref().next,
            };
            self.list.splice_nodes(self.current, node_next, spliced_node, spliced_node, 1);
            if self.current.is_none() {
                // Ang index ng "ghost" na hindi elemento ay nagbago.
                self.index = self.list.len;
            }
        }
    }

    /// Nagpapasok ng isang bagong elemento sa `LinkedList` bago ang kasalukuyang isa.
    ///
    /// Kung ang cursor ay tumuturo sa "ghost" na hindi elemento pagkatapos ang bagong elemento ay naipasok sa dulo ng `LinkedList`.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn insert_before(&mut self, item: T) {
        unsafe {
            let spliced_node = Box::leak(Box::new(Node::new(item))).into();
            let node_prev = match self.current {
                None => self.list.tail,
                Some(node) => node.as_ref().prev,
            };
            self.list.splice_nodes(node_prev, self.current, spliced_node, spliced_node, 1);
            self.index += 1;
        }
    }

    /// Tinatanggal ang kasalukuyang elemento mula sa `LinkedList`.
    ///
    /// Ang elemento na tinanggal ay naibalik, at ang cursor ay inililipat upang ituro sa susunod na elemento sa `LinkedList`.
    ///
    ///
    /// Kung ang cursor ay kasalukuyang tumuturo sa "ghost" na hindi sangkap pagkatapos walang elemento ang aalisin at ibinalik ang `None`.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn remove_current(&mut self) -> Option<T> {
        let unlinked_node = self.current?;
        unsafe {
            self.current = unlinked_node.as_ref().next;
            self.list.unlink_node(unlinked_node);
            let unlinked_node = Box::from_raw(unlinked_node.as_ptr());
            Some(unlinked_node.element)
        }
    }

    /// Tinatanggal ang kasalukuyang elemento mula sa `LinkedList` nang hindi nakikipag-ugnayan sa node ng listahan.
    ///
    /// Ang node na tinanggal ay naibalik bilang isang bagong `LinkedList` na naglalaman lamang ng node na ito.
    /// Ang cursor ay inilipat upang ituro sa susunod na elemento sa kasalukuyang `LinkedList`.
    ///
    /// Kung ang cursor ay kasalukuyang tumuturo sa "ghost" na hindi sangkap pagkatapos walang elemento ang aalisin at ibinalik ang `None`.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn remove_current_as_list(&mut self) -> Option<LinkedList<T>> {
        let mut unlinked_node = self.current?;
        unsafe {
            self.current = unlinked_node.as_ref().next;
            self.list.unlink_node(unlinked_node);

            unlinked_node.as_mut().prev = None;
            unlinked_node.as_mut().next = None;
            Some(LinkedList {
                head: Some(unlinked_node),
                tail: Some(unlinked_node),
                len: 1,
                marker: PhantomData,
            })
        }
    }

    /// Ipasok ang mga elemento mula sa ibinigay na `LinkedList` pagkatapos ng kasalukuyang isa.
    ///
    /// Kung ang cursor ay tumuturo sa "ghost" na hindi elemento pagkatapos ang mga bagong elemento ay naipasok sa simula ng `LinkedList`.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn splice_after(&mut self, list: LinkedList<T>) {
        unsafe {
            let (splice_head, splice_tail, splice_len) = match list.detach_all_nodes() {
                Some(parts) => parts,
                _ => return,
            };
            let node_next = match self.current {
                None => self.list.head,
                Some(node) => node.as_ref().next,
            };
            self.list.splice_nodes(self.current, node_next, splice_head, splice_tail, splice_len);
            if self.current.is_none() {
                // Ang index ng "ghost" na hindi elemento ay nagbago.
                self.index = self.list.len;
            }
        }
    }

    /// Ipasok ang mga elemento mula sa ibinigay na `LinkedList` bago ang kasalukuyang isa.
    ///
    /// Kung ang cursor ay tumuturo sa "ghost" na hindi elemento pagkatapos ang mga bagong elemento ay naipasok sa dulo ng `LinkedList`.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn splice_before(&mut self, list: LinkedList<T>) {
        unsafe {
            let (splice_head, splice_tail, splice_len) = match list.detach_all_nodes() {
                Some(parts) => parts,
                _ => return,
            };
            let node_prev = match self.current {
                None => self.list.tail,
                Some(node) => node.as_ref().prev,
            };
            self.list.splice_nodes(node_prev, self.current, splice_head, splice_tail, splice_len);
            self.index += splice_len;
        }
    }

    /// Hinahati ang listahan sa dalawa pagkatapos ng kasalukuyang elemento.
    /// Ibabalik nito ang isang bagong listahan na binubuo ng lahat pagkatapos ng cursor, na may orihinal na listahan na pinapanatili ang lahat bago.
    ///
    ///
    /// Kung ang cursor ay tumuturo sa "ghost" na hindi elemento pagkatapos ang buong nilalaman ng `LinkedList` ay inilipat.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn split_after(&mut self) -> LinkedList<T> {
        let split_off_idx = if self.index == self.list.len { 0 } else { self.index + 1 };
        if self.index == self.list.len {
            // Ang index ng "ghost" na hindi elemento ay nabago sa 0.
            self.index = 0;
        }
        unsafe { self.list.split_off_after_node(self.current, split_off_idx) }
    }

    /// Hinahati ang listahan sa dalawa bago ang kasalukuyang elemento.
    /// Ibabalik nito ang isang bagong listahan na binubuo ng lahat bago ang cursor, kasama ang orihinal na listahan na panatilihin ang lahat pagkatapos.
    ///
    ///
    /// Kung ang cursor ay tumuturo sa "ghost" na hindi elemento pagkatapos ang buong nilalaman ng `LinkedList` ay inilipat.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn split_before(&mut self) -> LinkedList<T> {
        let split_off_idx = self.index;
        self.index = 0;
        unsafe { self.list.split_off_before_node(self.current, split_off_idx) }
    }
}

/// Isang iterator na ginawa sa pamamagitan ng pagtawag sa `drain_filter` sa LinkedList.
#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
pub struct DrainFilter<'a, T: 'a, F: 'a>
where
    F: FnMut(&mut T) -> bool,
{
    list: &'a mut LinkedList<T>,
    it: Option<NonNull<Node<T>>>,
    pred: F,
    idx: usize,
    old_len: usize,
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T, F> Iterator for DrainFilter<'_, T, F>
where
    F: FnMut(&mut T) -> bool,
{
    type Item = T;

    fn next(&mut self) -> Option<T> {
        while let Some(mut node) = self.it {
            unsafe {
                self.it = node.as_ref().next;
                self.idx += 1;

                if (self.pred)(&mut node.as_mut().element) {
                    // `unlink_node` ay okay sa aliasing `element` na mga sanggunian.
                    self.list.unlink_node(node);
                    return Some(Box::from_raw(node.as_ptr()).element);
                }
            }
        }

        None
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, Some(self.old_len - self.idx))
    }
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T, F> Drop for DrainFilter<'_, T, F>
where
    F: FnMut(&mut T) -> bool,
{
    fn drop(&mut self) {
        struct DropGuard<'r, 'a, T, F>(&'r mut DrainFilter<'a, T, F>)
        where
            F: FnMut(&mut T) -> bool;

        impl<'r, 'a, T, F> Drop for DropGuard<'r, 'a, T, F>
        where
            F: FnMut(&mut T) -> bool,
        {
            fn drop(&mut self) {
                self.0.for_each(drop);
            }
        }

        while let Some(item) = self.next() {
            let guard = DropGuard(self);
            drop(item);
            mem::forget(guard);
        }
    }
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T: fmt::Debug, F> fmt::Debug for DrainFilter<'_, T, F>
where
    F: FnMut(&mut T) -> bool,
{
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("DrainFilter").field(&self.list).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Iterator for IntoIter<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.list.pop_front()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (self.list.len, Some(self.list.len))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> DoubleEndedIterator for IntoIter<T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.list.pop_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for IntoIter<T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for IntoIter<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> FromIterator<T> for LinkedList<T> {
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> Self {
        let mut list = Self::new();
        list.extend(iter);
        list
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> IntoIterator for LinkedList<T> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// Naubos ang listahan sa isang iterator na nagbibigay ng mga elemento ayon sa halaga.
    #[inline]
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { list: self }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a LinkedList<T> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a mut LinkedList<T> {
    type Item = &'a mut T;
    type IntoIter = IterMut<'a, T>;

    fn into_iter(self) -> IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Extend<T> for LinkedList<T> {
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        <Self as SpecExtend<I>>::spec_extend(self, iter);
    }

    #[inline]
    fn extend_one(&mut self, elem: T) {
        self.push_back(elem);
    }
}

impl<I: IntoIterator> SpecExtend<I> for LinkedList<I::Item> {
    default fn spec_extend(&mut self, iter: I) {
        iter.into_iter().for_each(move |elt| self.push_back(elt));
    }
}

impl<T> SpecExtend<LinkedList<T>> for LinkedList<T> {
    fn spec_extend(&mut self, ref mut other: LinkedList<T>) {
        self.append(other);
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: 'a + Copy> Extend<&'a T> for LinkedList<T> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &elem: &'a T) {
        self.push_back(elem);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialEq> PartialEq for LinkedList<T> {
    fn eq(&self, other: &Self) -> bool {
        self.len() == other.len() && self.iter().eq(other)
    }

    fn ne(&self, other: &Self) -> bool {
        self.len() != other.len() || self.iter().ne(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Eq> Eq for LinkedList<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialOrd> PartialOrd for LinkedList<T> {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.iter().partial_cmp(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Ord for LinkedList<T> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        self.iter().cmp(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for LinkedList<T> {
    fn clone(&self) -> Self {
        self.iter().cloned().collect()
    }

    fn clone_from(&mut self, other: &Self) {
        let mut iter_other = other.iter();
        if self.len() > other.len() {
            self.split_off(other.len());
        }
        for (elem, elem_other) in self.iter_mut().zip(&mut iter_other) {
            elem.clone_from(elem_other);
        }
        if !iter_other.is_empty() {
            self.extend(iter_other.cloned());
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug> fmt::Debug for LinkedList<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Hash> Hash for LinkedList<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        self.len().hash(state);
        for elt in self {
            elt.hash(state);
        }
    }
}

// Tiyaking ang `LinkedList` at ang mga read-only iterator nito ay covariant sa kanilang mga uri ng parameter.
#[allow(dead_code)]
fn assert_covariance() {
    fn a<'a>(x: LinkedList<&'static str>) -> LinkedList<&'a str> {
        x
    }
    fn b<'i, 'a>(x: Iter<'i, &'static str>) -> Iter<'i, &'a str> {
        x
    }
    fn c<'a>(x: IntoIter<&'static str>) -> IntoIter<&'a str> {
        x
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Send> Send for LinkedList<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Sync> Sync for LinkedList<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Sync> Send for Iter<'_, T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Sync> Sync for Iter<'_, T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Send> Send for IterMut<'_, T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Sync> Sync for IterMut<'_, T> {}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
unsafe impl<T: Sync> Send for Cursor<'_, T> {}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
unsafe impl<T: Sync> Sync for Cursor<'_, T> {}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
unsafe impl<T: Send> Send for CursorMut<'_, T> {}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
unsafe impl<T: Sync> Sync for CursorMut<'_, T> {}