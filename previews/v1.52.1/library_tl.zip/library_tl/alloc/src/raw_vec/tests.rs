use super::*;
use std::cell::Cell;

#[test]
fn allocator_param() {
    use crate::alloc::AllocError;

    // Ang pagsulat ng isang pagsubok ng pagsasama sa pagitan ng mga tagataguyod ng third-party at `RawVec` ay isang maliit na nakakalito dahil ang `RawVec` API ay hindi inilalantad ang mga kakulangan na paraan ng paglalaan, kaya hindi namin masuri kung ano ang mangyayari kapag naubos na ang tagapaglaan (lampas sa pagtuklas ng isang panic).
    //
    //
    // Sa halip, suriin lamang nito na ang mga pamamaraan ng `RawVec` ay hindi bababa sa dumaan sa Allocator API kapag nagreserba ito ng imbakan.
    //
    //
    //
    //
    //

    // Isang pipi na tagapaglaan na kumonsumo ng isang nakapirming dami ng gasolina bago magsimulang mabigo ang mga pagtatangka sa paglalaan.
    //
    struct BoundedAlloc {
        fuel: Cell<usize>,
    }
    unsafe impl Allocator for BoundedAlloc {
        fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
            let size = layout.size();
            if size > self.fuel.get() {
                return Err(AllocError);
            }
            match Global.allocate(layout) {
                ok @ Ok(_) => {
                    self.fuel.set(self.fuel.get() - size);
                    ok
                }
                err @ Err(_) => err,
            }
        }
        unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
            unsafe { Global.deallocate(ptr, layout) }
        }
    }

    let a = BoundedAlloc { fuel: Cell::new(500) };
    let mut v: RawVec<u8, _> = RawVec::with_capacity_in(50, a);
    assert_eq!(v.alloc.fuel.get(), 450);
    v.reserve(50, 150); // (sanhi ng isang realloc, sa gayon gumagamit ng 50 + 150=200 mga yunit ng gasolina)
    assert_eq!(v.alloc.fuel.get(), 250);
}

#[test]
fn reserve_does_not_overallocate() {
    {
        let mut v: RawVec<u32> = RawVec::new();
        // Una, ang `reserve` ay naglalaan tulad ng `reserve_exact`.
        v.reserve(0, 9);
        assert_eq!(9, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 7);
        assert_eq!(7, v.capacity());
        // Ang 97 ay higit sa doble ng 7, kaya ang `reserve` ay dapat na gumana tulad ng `reserve_exact`.
        //
        v.reserve(7, 90);
        assert_eq!(97, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 12);
        assert_eq!(12, v.capacity());
        v.reserve(12, 3);
        // Ang 3 ay mas mababa sa kalahati ng 12, kaya't ang `reserve` ay dapat na lumago nang mabilis.
        // Sa oras ng pagsulat ng test grow grow factor na ito ay 2, kaya't ang bagong kapasidad ay 24, subalit, ang grow factor ng 1.5 ay OK din.
        //
        // Samakatuwid `>= 18` sa igiit.
        assert!(v.capacity() >= 12 + 12 / 2);
    }
}