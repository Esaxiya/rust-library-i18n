//! Mga utility para sa pag-format at pag-print ng `String`s.
//!
//! Naglalaman ang modyul na ito ng suporta sa runtime para sa [`format!`] syntax extension.
//! Ang makro na ito ay ipinatupad sa tagatala upang maglabas ng mga tawag sa modyul na ito upang mai-format ang mga argumento sa runtime sa mga string.
//!
//! # Usage
//!
//! Ang [`format!`] macro ay inilaan upang maging pamilyar sa mga nagmumula sa mga pagpapaandar ng `printf`/`fprintf` ng C o pagpapaandar ng `str.format` ng Python.
//!
//! Ang ilang mga halimbawa ng extension na [`format!`] ay:
//!
//! ```
//! format!("Hello");                 // => "Hello"
//! format!("Hello, {}!", "world");   // => "Hello, world!"
//! format!("The number is {}", 1);   // => "The number is 1"
//! format!("{:?}", (3, 4));          // => "(3, 4)"
//! format!("{value}", value=4);      // => "4"
//! format!("{} {}", 1, 2);           // => "1 2"
//! format!("{:04}", 42);             // => "0042" na may nangungunang mga zero
//! ```
//!
//! Mula sa mga ito, makikita mo na ang unang argument ay isang format string.Kinakailangan ng tagatala para sa ito upang maging isang literal na string;hindi ito maaaring maging isang variable na ipinapasa (upang maisagawa ang pag-check ng bisa).
//! Pagkatapos ay mai-parse ng compiler ang format string at matutukoy kung ang listahan ng mga argumento na ibinigay ay angkop na ipasa sa format string na ito.
//!
//! Upang mai-convert ang isang solong halaga sa isang string, gamitin ang [`to_string`] na pamamaraan.Gagamitin nito ang [`Display`] formatting trait.
//!
//! ## Mga parameter ng posisyon
//!
//! Pinapayagan ang bawat argumento sa pag-format na tukuyin kung aling halaga ang argument na tinutukoy nito, at kung tinanggal ay ipinapalagay na "the next argument".
//! Halimbawa, ang format string `{} {} {}` ay kukuha ng tatlong mga parameter, at mai-format ang mga ito sa parehong pagkakasunud-sunod tulad ng ibinigay sa kanila.
//! Ang format string `{2} {1} {0}`, gayunpaman, ay mai-format ang mga argumento sa reverse order.
//!
//! Ang mga bagay ay maaaring makakuha ng isang maliit na nakakalito sa sandaling sinimulan mo ang intermingling ng dalawang uri ng mga posisyong specifier.Ang "next argument" specifier ay maaaring maisip bilang isang iterator sa pagtatalo.
//! Sa tuwing makikita ang isang tumutukoy sa "next argument", sumusulong ang iterator.Humahantong ito sa pag-uugali na tulad nito:
//!
//! ```
//! format!("{1} {} {0} {}", 1, 2); // => "2 1 1 2"
//! ```
//!
//! Ang panloob na umuulit sa pagtatalo ay hindi pa na-advance sa oras na makita ang unang `{}`, kaya nai-print nito ang unang argumento.Pagkatapos sa pag-abot sa pangalawang `{}`, ang iterator ay sumulong sa ikalawang argumento.
//! Mahalaga, mga parameter na tahasang pangalanan ang kanilang argumento ay hindi nakakaapekto sa mga parameter na huwag pangalanan ang isang argument sa mga tuntunin ng positional specifiers.
//!
//! Kinakailangan ang isang format string upang magamit ang lahat ng mga argumento nito, kung hindi man ito ay isang error sa compile-time.Maaari kang mag-refer sa parehong argument ng higit sa isang beses sa format string.
//!
//! ## Pinangalanang mga parameter
//!
//! Ang Rust mismo ay walang katumbas na tulad ng Python ng pinangalanang mga parameter sa isang pagpapaandar, ngunit ang [`format!`] macro ay isang extension ng syntax na nagbibigay-daan sa ito upang makamit ang mga pinangalanang parameter.
//! Ang mga pinangalanang parameter ay nakalista sa dulo ng listahan ng argument at mayroon ang syntax:
//!
//! ```text
//! identifier '=' expression
//! ```
//!
//! Halimbawa, ang mga sumusunod na [`format!`] expression lahat ng gumagamit ng pinangalanang argument:
//!
//! ```
//! format!("{argument}", argument = "test");   // => "test"
//! format!("{name} {}", 1, name = 2);          // => "2 1"
//! format!("{a} {c} {b}", a="a", b='b', c=3);  // => "a 3 b"
//! ```
//!
//! Hindi wasto na maglagay ng mga posisyong parameter (mga walang pangalan) pagkatapos ng mga argument na mayroong mga pangalan.Tulad ng mga posisyonal na parameter, hindi wasto na magbigay ng mga pinangalanang parameter na hindi nagamit ng format string.
//!
//! # Mga Parameter ng Pag-format
//!
//! Ang bawat argument ini-format ay maaaring transformed sa pamamagitan ng isang bilang ng mga pag-format parameter (naaayon sa `format_spec` in [the syntax](#syntax)). Ang mga parameter makakaapekto sa string na representasyon ng kung ano ang ini-format.
//!
//! ## Width
//!
//! ```
//! // Ang lahat ng mga naka-print na "Hello x !"
//! println!("Hello {:5}!", "x");
//! println!("Hello {:1$}!", "x", 5);
//! println!("Hello {1:0$}!", 5, "x");
//! println!("Hello {:width$}!", "x", width = 5);
//! ```
//!
//! Ito ay isang parameter para sa "minimum width" na dapat gawin ng format.
//! Kung ang string ng halaga ay hindi pinupunan ang maraming mga character na ito, ang padding na tinukoy ng fill/alignment ay gagamitin upang kunin ang kinakailangang puwang (tingnan sa ibaba).
//!
//! Ang halaga para sa lapad ay maaari ring ibigay bilang isang [`usize`] sa listahan ng mga parameter sa pamamagitan ng pagdaragdag ng isang postfix `$`, na nagpapahiwatig na ang pangalawang argument ay isang [`usize`] na tumutukoy sa lapad.
//!
//! Ang pagtukoy sa isang argument sa dolyar na syntax ay hindi nakakaapekto sa counter ng "next argument", kaya karaniwang isang magandang ideya na mag-refer sa mga argumento ayon sa posisyon, o gumamit ng mga pinangalanang argumento.
//!
//! ## Fill/Alignment
//!
//! ```
//! assert_eq!(format!("Hello {:<5}!", "x"),  "Hello x    !");
//! assert_eq!(format!("Hello {:-<5}!", "x"), "Hello x----!");
//! assert_eq!(format!("Hello {:^5}!", "x"),  "Hello   x  !");
//! assert_eq!(format!("Hello {:>5}!", "x"),  "Hello     x!");
//! ```
//!
//! Ang opsyonal na pagpuno ng character at pagkakahanay ay ibinibigay nang normal kasabay ng [`width`](#width) na parameter.Dapat itong tukuyin bago ang `width`, pagkatapos mismo ng `:`.
//! Ipinapahiwatig nito na kung ang halaga na nai-format ay mas maliit kaysa sa `width` ilang sobrang mga character ay mai-print sa paligid nito.
//! Ang pagpuno ay nagmumula sa mga sumusunod na variant para sa iba't ibang mga pagkakahanay:
//!
//! * `[fill]<` - ang argumento ay naiwang nakahanay sa mga haligi ng `width`
//! * `[fill]^` - ang argumento ay nakahanay sa gitna sa mga haligi ng `width`
//! * `[fill]>` - ang argumento ay nakahanay sa kanan sa mga haligi ng `width`
//!
//! Ang default [fill/alignment](#fillalignment) para sa mga di-numerong ay isang puwang at nakahanay sa kaliwa.Ang default para sa mga numerong format ay din ng isang character na puwang ngunit may tamang pag-align.
//! Kung ang watawat `0` (tingnan sa ibaba) ay tinukoy para sa mga numero, kung gayon ang implicit na pagpuno ng character ay `0`.
//!
//! Tandaan na ang pag-align ay maaaring hindi maipatupad ng ilang mga uri.Sa partikular, hindi ito pangkalahatan ay ipinatupad para sa `Debug` trait.
//! Ang isang mahusay na paraan upang matiyak na inilalapat ang padding ay ang pag-format ng iyong input, pagkatapos ay pad ang nagresultang string upang makuha ang iyong output:
//!
//! ```
//! println!("Hello {:^15}!", format!("{:?}", Some("hi"))); // => "Hello Some("hi")!"
//! ```
//!
//! ## Sign/`#`/`0`
//!
//! ```
//! assert_eq!(format!("Hello {:+}!", 5), "Hello +5!");
//! assert_eq!(format!("{:#x}!", 27), "0x1b!");
//! assert_eq!(format!("Hello {:05}!", 5),  "Hello 00005!");
//! assert_eq!(format!("Hello {:05}!", -5), "Hello -0005!");
//! assert_eq!(format!("{:#010x}!", 27), "0x0000001b!");
//! ```
//!
//! Ang lahat ng ito ay mga flag na binabago ang pag-uugali ng formatter.
//!
//! * `+` - Ito ay inilaan para sa mga uri ng bilang at nagpapahiwatig na ang pag-sign ay dapat palaging naka-print.Ang mga positibong palatandaan ay hindi kailanman nai-print bilang default, at ang negatibong pag-sign ay naka-print lamang bilang default para sa `Signed` trait.
//! Ipinapahiwatig ng watawat na ito na ang wastong pag-sign (`+` o `-`) ay dapat palaging naka-print.
//! * `-` - Kasalukuyang hindi ginagamit
//! * `#` - Ipinapahiwatig ng watawat na ito na dapat gamitin ang "alternate" form ng pag-print.Ang mga kahaliling porma ay:
//!     * `#?` - medyo mai-print ang pag-format ng [`Debug`]
//!     * `#x` - nauuna ang pagtatalo sa isang `0x`
//!     * `#X` - nauuna ang pagtatalo sa isang `0x`
//!     * `#b` - nauuna ang pagtatalo sa isang `0b`
//!     * `#o` - nauuna ang pagtatalo sa isang `0o`
//! * `0` - Ginagamit ito upang ipahiwatig para sa mga format ng integer na ang padding sa `width` ay kapwa dapat gawin sa isang `0` character pati na rin ang maging may kamalayan sa pag-sign.
//! Ang isang format tulad ng `{:08}` ay magbubunga ng `00000001` para sa integer `1`, habang ang parehong format ay magbubunga ng `-0000001` para sa integer `-1`.
//! Pansinin na ang negatibong bersyon ay may isang mas kaunting zero kaysa sa positibong bersyon.
//!         Tandaan na ang mga padding zero ay palaging inilalagay pagkatapos ng pag-sign (kung mayroon man) at bago ang mga digit.Kapag ginamit kasama ang `#` flag, nalalapat ang isang katulad na panuntunan: ang mga padding na zero ay ipinasok pagkatapos ng unlapi ngunit bago ang mga digit.
//!         Ang unlapi ay kasama sa kabuuang lapad.
//!
//! ## Precision
//!
//! Para sa mga di-numerong uri, maaari itong maituring na isang "maximum width".
//! Kung ang nagresultang string ay mas mahaba kaysa sa lapad na ito, pagkatapos ay pinuputol ito sa maraming mga character at ang pinutol na halaga ay inilalabas ng wastong `fill`, `alignment` at `width` kung ang mga parameter na iyon ay itinakda.
//!
//! Para sa mga integral na uri, hindi ito pinapansin.
//!
//! Para sa mga uri ng lumulutang-point, ipinapahiwatig nito kung gaano karaming mga digit pagkatapos ng decimal point na dapat na mai-print.
//!
//! Mayroong tatlong posibleng paraan upang tukuyin ang nais na `precision`:
//!
//! 1. Isang integer `.N`:
//!
//!    ang integer `N` mismo ay ang katumpakan.
//!
//! 2. Isang integer o pangalan na sinusundan ng dolyar na sign `.N$`:
//!
//!    gumamit ng format *argument*`N` (na dapat ay isang `usize`) bilang katumpakan.
//!
//! 3. Isang asterisk `.*`:
//!
//!    `.*` nangangahulugan na ang `{...}` na ito ay nauugnay sa *dalawang* mga input ng format kaysa sa isa: ang unang input ay humahawak sa katumpakan ng `usize`, at ang pangalawa ay humahawak sa halaga upang mai-print.
//!    Tandaan na sa kasong ito, kung ang isang gumagamit ng format string `{<arg>:<spec>.*}`, kung gayon ang bahagi ng `<arg>` ay tumutukoy sa* halaga * upang mai-print, at ang `precision` ay dapat na dumating sa input na naunang `<arg>`.
//!
//! Halimbawa, ang mga sumusunod na tawag sa lahat ng naka-print sa parehong bagay `Hello x is 0.01000`:
//!
//! ```
//! // Kumusta {arg 0 ("x")} ay {arg 1 (0.01) with precision specified inline (5)}
//! println!("Hello {0} is {1:.5}", "x", 0.01);
//!
//! // Kumusta {arg 1 ("x")} ay {arg 2 (0.01) with precision specified in arg 0 (5)}
//! println!("Hello {1} is {2:.0$}", 5, "x", 0.01);
//!
//! // Kumusta {arg 0 ("x")} ay {arg 2 (0.01) with precision specified in arg 1 (5)}
//! println!("Hello {0} is {2:.1$}", "x", 5, 0.01);
//!
//! // Kumusta {next arg ("x")} ay {second of next two args (0.01) with precision specified in first of next two args (5)}
//! //
//! println!("Hello {} is {:.*}",    "x", 5, 0.01);
//!
//! // Kumusta {next arg ("x")} ay {arg 2 (0.01) with precision specified in its predecessor (5)}
//! //
//! println!("Hello {} is {2:.*}",   "x", 5, 0.01);
//!
//! // Kumusta {next arg ("x")} ay {arg "number" (0.01) with precision specified in arg "prec" (5)}
//! //
//! println!("Hello {} is {number:.prec$}", "x", prec = 5, number = 0.01);
//! ```
//!
//! Habang ang mga ito:
//!
//! ```
//! println!("{}, `{name:.*}` has 3 fractional digits", "Hello", 3, name=1234.56);
//! println!("{}, `{name:.*}` has 3 characters", "Hello", 3, name="1234.56");
//! println!("{}, `{name:>8.*}` has 3 right-aligned characters", "Hello", 3, name="1234.56");
//! ```
//!
//! i-print ang tatlong makabuluhang iba't ibang mga bagay:
//!
//! ```text
//! Hello, `1234.560` has 3 fractional digits
//! Hello, `123` has 3 characters
//! Hello, `     123` has 3 right-aligned characters
//! ```
//!
//! ## Localization
//!
//! Sa ilang mga wika ng programa, ang pag-uugali ng pag-andar ng pag-format ng string ay nakasalalay sa setting ng lokal na operating system.
//! Ang mga pagpapaandar na format na ibinigay ng standard na silid-aklatan ng Rust ay walang anumang konsepto ng lokal at gagawa ng parehong mga resulta sa lahat ng mga sistema anuman ang pagsasaayos ng gumagamit.
//!
//! Halimbawa, ang sumusunod na code ay palaging mai-print ang `1.5` kahit na ang lokal na system ay gumagamit ng isang decimal separator bukod sa isang tuldok.
//!
//! ```
//! println!("The value is {}", 1.5);
//! ```
//!
//! # Escaping
//!
//! Ang mga literal na character na `{` at `}` ay maaaring isama sa isang string sa pamamagitan ng nauna sa kanila na may parehong character.Halimbawa, ang character na `{` ay nakatakas kasama ang `{{` at ang `}` na character ay nakatakas sa `}}`.
//!
//! ```
//! assert_eq!(format!("Hello {{}}"), "Hello {}");
//! assert_eq!(format!("{{ Hello"), "{ Hello");
//! ```
//!
//! # Syntax
//!
//! Upang ibuod, dito maaari mong makita ang buong grammar ng mga string ng format.
//! Ang syntax para sa ginagamit na pag-format na wika ay iginuhit mula sa ibang mga wika, kaya't hindi ito dapat maging masyadong alien.Ang mga argumento ay nai-format na may katulad na syntax na Python, nangangahulugang ang mga argumento ay napapalibutan ng `{}` sa halip na ang C-tulad ng `%`.
//! Ang aktwal na grammar para sa pag-format ng syntax ay:
//!
//! ```text
//! format_string := text [ maybe_format text ] *
//! maybe_format := '{' '{' | '}' '}' | format
//! format := '{' [ argument ] [ ':' format_spec ] '}'
//! argument := integer | identifier
//!
//! format_spec := [[fill]align][sign]['#']['0'][width]['.' precision]type
//! fill := character
//! align := '<' | '^' | '>'
//! sign := '+' | '-'
//! width := count
//! precision := count | '*'
//! type := '' | '?' | 'x?' | 'X?' | identifier
//! count := parameter | integer
//! parameter := argument '$'
//! ```
//! Sa grammar sa itaas, ang `text` ay maaaring hindi maglaman ng anumang `'{'` o `'}'` character.
//!
//! # Pag-format ng traits
//!
//! Kapag humihiling na mai-format ang isang argument sa isang partikular na uri, humihiling ka talaga na ang isang argument ay naglalarawan sa isang partikular na trait.
//! Pinapayagan nito ang maraming aktwal na uri na mai-format sa pamamagitan ng `{:x}` (tulad ng [`i8`] pati na rin ang [`isize`]).Ang kasalukuyang pagmamapa ng mga uri sa traits ay:
//!
//! * *wala* ⇒ [`Display`]
//! * `?` ⇒ [`Debug`]
//! * `x?` ⇒ [`Debug`] na may mas mababang kaso na hexadecimal integers
//! * `X?` ⇒ [`Debug`] na may upper-case hexadecimal integers
//! * `o` ⇒ [`Octal`]
//! * `x` ⇒ [`LowerHex`]
//! * `X` ⇒ [`UpperHex`]
//! * `p` ⇒ [`Pointer`]
//! * `b` ⇒ [`Binary`]
//! * `e` ⇒ [`LowerExp`]
//! * `E` ⇒ [`UpperExp`]
//!
//! Ang ibig sabihin nito ay ang anumang uri ng argument na nagpapatupad ng [`fmt::Binary`][`Binary`] trait na maaaring mai-format sa `{:b}`.Ang mga pagpapatupad ay ibinibigay para sa mga traits para sa isang bilang ng mga primitive na uri ng standard library din.
//!
//! Kung walang tinukoy na format (tulad ng sa `{}` o `{:6}`), pagkatapos ang ginamit na format na trait ay ang [`Display`] trait.
//!
//! Kapag nagpapatupad ng isang format na trait para sa iyong sariling uri, kakailanganin mong magpatupad ng isang pamamaraan ng lagda:
//!
//! ```
//! # #![allow(dead_code)]
//! # use std::fmt;
//! # struct Foo; // ang aming pasadyang uri
//! # impl fmt::Display for Foo {
//! fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//! # write!(f, "testing, testing")
//! # } }
//! ```
//!
//! Ang iyong uri ay ipapasa bilang `self` by-reference, at pagkatapos ang pagpapaandar ay dapat na naglalabas ng output sa `f.buf` stream.Hanggang sa bawat format na pagpapatupad ng trait upang wastong sumunod sa hiniling na mga parameter ng pag-format.
//! Ang mga halaga ng mga parameter na ito ay nakalista sa mga patlang ng [`Formatter`] struct.Upang matulungan ito, nagbibigay din ang [`Formatter`] struct ng ilang mga pamamaraan ng tumutulong.
//!
//! Bilang karagdagan, ang halaga ng pagbabalik ng pagpapaandar na ito ay [`fmt::Result`] na isang uri ng alias ng [`Resulta`]`<(),`[`std: : fmt::Error`] `>`.
//! Ang mga pagpapatupad sa pag-format ay dapat tiyakin na nagpapalaganap sila ng mga error mula sa [`Formatter`] (hal., Kapag tumatawag sa [`write!`]).
//! Gayunpaman, hindi nila dapat ibalik nang mali ang mga pagkakamali.
//! Iyon ay, ang isang pagpapatupad ng pag-format ay dapat at maaaring bumalik lamang ng isang error kung ang pumasa sa [`Formatter`] ay nagbabalik ng isang error.
//! Ito ay sapagkat, taliwas sa maaaring imungkahi ng lagda ng pag-andar, ang pag-format ng string ay isang hindi maaaring magkamali na operasyon.
//! Nagbabalik lamang ang pag-andar na ito ng isang resulta dahil maaaring mabigo ang pagsusulat sa napapailalim na stream at dapat itong magbigay ng isang paraan upang maipalaganap ang katotohanan na ang isang error ay naganap na back up ang stack.
//!
//! Ang isang halimbawa ng pagpapatupad ng pag-format ng traits ay magiging katulad ng:
//!
//! ```
//! use std::fmt;
//!
//! #[derive(Debug)]
//! struct Vector2D {
//!     x: isize,
//!     y: isize,
//! }
//!
//! impl fmt::Display for Vector2D {
//!     fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//!         // Ang halaga ng `f` ay nagpapatupad ng `Write` trait, na kung saan ang isulat!Inaasahan ang macro.
//!         // Tandaan na hindi pinapansin ng pag-format na ito ang iba't ibang mga watawat na ibinigay sa mga string ng format.
//!         //
//!         write!(f, "({}, {})", self.x, self.y)
//!     }
//! }
//!
//! // Pinapayagan ng iba't ibang traits ang iba't ibang mga form ng output ng isang uri.
//! // Ang kahulugan ng format na ito ay upang i-print ang lakas ng isang vector.
//! impl fmt::Binary for Vector2D {
//!     fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//!         let magnitude = (self.x * self.x + self.y * self.y) as f64;
//!         let magnitude = magnitude.sqrt();
//!
//!         // Igalang ang mga flag ng pag-format sa pamamagitan ng paggamit ng helper na pamamaraan na `pad_integral` sa Formatter object.
//!         // Tingnan ang dokumentasyon ng pamamaraan para sa mga detalye, at ang pagpapaandar `pad` ay maaaring magamit upang mag-pad ng mga string.
//!         //
//!         //
//!         let decimals = f.precision().unwrap_or(3);
//!         let string = format!("{:.*}", decimals, magnitude);
//!         f.pad_integral(true, "", &string)
//!     }
//! }
//!
//! fn main() {
//!     let myvector = Vector2D { x: 3, y: 4 };
//!
//!     println!("{}", myvector);       // => "(3, 4)"
//!     println!("{:?}", myvector);     // => "Vector2D {x: 3, y:4}"
//!     println!("{:10.3b}", myvector); // => "     5.000"
//! }
//! ```
//!
//! ### `fmt::Display` vs `fmt::Debug`
//!
//! Ang dalawang pag-format na traits ay may magkakaibang mga layunin:
//!
//! - [`fmt::Display`][`Display`] pagpapatupad iginiit na ang uri ay maaaring matapat na kinatawan bilang isang UTF-8 string sa lahat ng oras.Hindi inaasahan na **ang** lahat ng mga uri ay nagpapatupad ng [`Display`] trait.
//! - [`fmt::Debug`][`Debug`] pagpapatupad ay dapat na ipatupad para sa **lahat** mga pampublikong uri.
//!   Karaniwang kinakatawan ng output ang panloob na estado bilang tapat hangga't maaari.
//!   Ang layunin ng [`Debug`] trait ay upang mapadali ang pag-debug ng Rust code.Sa karamihan ng mga kaso, ang paggamit ng `#[derive(Debug)]` ay sapat at inirerekumenda.
//!
//! Ang ilang mga halimbawa ng output mula sa parehong traits:
//!
//! ```
//! assert_eq!(format!("{} {:?}", 3, 4), "3 4");
//! assert_eq!(format!("{} {:?}", 'a', 'b'), "a 'b'");
//! assert_eq!(format!("{} {:?}", "foo\n", "bar\n"), "foo\n \"bar\\n\"");
//! ```
//!
//! # Mga nauugnay na macros
//!
//! Mayroong isang bilang ng mga kaugnay na macros sa pamilyang [`format!`].Ang mga kasalukuyang ipinatutupad ay:
//!
//! ```ignore (only-for-syntax-highlight)
//! format!      // described above
//! write!       // first argument is a &mut io::Write, the destination
//! writeln!     // same as write but appends a newline
//! print!       // the format string is printed to the standard output
//! println!     // same as print but appends a newline
//! eprint!      // the format string is printed to the standard error
//! eprintln!    // same as eprint but appends a newline
//! format_args! // described below.
//! ```
//!
//! ### `write!`
//!
//! Ito at [`writeln!`] ay dalawang macros na ginagamit upang ibuga ang format string sa isang tinukoy na stream.Ginagamit ito upang maiwasan ang mga intermediate na paglalaan ng mga string ng format at sa halip ay direktang isulat ang output.
//! Sa ilalim ng hood, ang pagpapaandar na ito ay talagang ginagamit ang [`write_fmt`] function na tinukoy sa [`std::io::Write`] trait.
//! Ang halimbawa ng paggamit ay:
//!
//! ```
//! # #![allow(unused_must_use)]
//! use std::io::Write;
//! let mut w = Vec::new();
//! write!(&mut w, "Hello {}!", "world");
//! ```
//!
//! ### `print!`
//!
//! Ito at [`println!`] naglalabas ng kanilang output sa stdout.Katulad din ng [`write!`] macro, ang layunin ng mga macros na ito ay upang maiwasan ang mga intermediate na paglalaan kapag nagpi-print ng output.Ang halimbawa ng paggamit ay:
//!
//! ```
//! print!("Hello {}!", "world");
//! println!("I have a newline {}", "character at the end");
//! ```
//!
//! ### `eprint!`
//!
//! Ang [`eprint!`] at [`eprintln!`] macros ay magkapareho sa [`print!`] at [`println!`], ayon sa pagkakabanggit, maliban sa inilalabas nila ang kanilang output sa stderr.
//!
//! ### `format_args!`
//!
//! Ito ay isang usiseryong macro na ginamit upang ligtas na pumasa sa paligid ng isang opaque na bagay na naglalarawan sa format string.Ang bagay na ito ay hindi nangangailangan ng anumang mga alokasyong magbunton upang likhain, at tumutukoy lamang ito ng impormasyon sa stack.
//! Sa ilalim ng hood, lahat ng mga nauugnay na macros ay ipinatupad sa mga tuntunin nito.
//! Una, ang ilang halimbawang paggamit ay:
//!
//! ```
//! # #![allow(unused_must_use)]
//! use std::fmt;
//! use std::io::{self, Write};
//!
//! let mut some_writer = io::stdout();
//! write!(&mut some_writer, "{}", format_args!("print with a {}", "macro"));
//!
//! fn my_fmt_fn(args: fmt::Arguments) {
//!     write!(&mut io::stdout(), "{}", args);
//! }
//! my_fmt_fn(format_args!(", or a {} too", "function"));
//! ```
//!
//! Ang resulta ng [`format_args!`] macro ay isang halaga ng uri [`fmt::Arguments`].
//! Ang istrakturang ito ay maaaring maipasa sa mga pagpapaandar ng [`write`] at [`format`] sa loob ng modyul na ito upang maproseso ang format string.
//! Ang layunin ng makro na ito ay upang higit na maiwasan ang mga intermediate na paglalaan kapag nakikipag-usap sa mga string ng pag-format.
//!
//! Halimbawa, ang isang library ng pag-log ay maaaring gumamit ng karaniwang pag-format ng syntax, ngunit papasa ito sa loob ng paligid ng istrakturang ito hanggang sa matukoy kung saan dapat mapunta ang output.
//!
//! [`fmt::Result`]: Result
//! [`Result`]: core::result::Result
//! [`std::fmt::Error`]: Error
//! [`write!`]: core::write
//! [`write`]: core::write
//! [`format!`]: crate::format
//! [`to_string`]: crate::string::ToString
//! [`writeln!`]: core::writeln
//! [`write_fmt`]: ../../std/io/trait.Write.html#method.write_fmt
//! [`std::io::Write`]: ../../std/io/trait.Write.html
//! [`print!`]: ../../std/macro.print.html
//! [`println!`]: ../../std/macro.println.html
//! [`eprint!`]: ../../std/macro.eprint.html
//! [`eprintln!`]: ../../std/macro.eprintln.html
//! [`format_args!`]: core::format_args
//! [`fmt::Arguments`]: Arguments
//! [`format`]: crate::format
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[unstable(feature = "fmt_internals", issue = "none")]
pub use core::fmt::rt;
#[stable(feature = "fmt_flags_align", since = "1.28.0")]
pub use core::fmt::Alignment;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::Error;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{write, ArgumentV1, Arguments};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Binary, Octal};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Debug, Display};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{DebugList, DebugMap, DebugSet, DebugStruct, DebugTuple};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Formatter, Result, Write};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{LowerExp, UpperExp};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{LowerHex, Pointer, UpperHex};

use crate::string;

/// Ang pagpapaandar ng `format` ay tumatagal ng isang [`Arguments`] struct at ibabalik ang nagresultang naka-format na string.
///
///
/// Ang halimbawa ng [`Arguments`] ay maaaring malikha gamit ang [`format_args!`] macro.
///
/// # Examples
///
/// Pangunahing paggamit:
///
/// ```
/// use std::fmt;
///
/// let s = fmt::format(format_args!("Hello, {}!", "world"));
/// assert_eq!(s, "Hello, world!");
/// ```
///
/// Mangyaring tandaan na ang paggamit ng [`format!`] ay maaaring lalong gusto.
/// Example:
///
/// ```
/// let s = format!("Hello, {}!", "world");
/// assert_eq!(s, "Hello, world!");
/// ```
///
/// [`format_args!`]: core::format_args
/// [`format!`]: crate::format
#[stable(feature = "rust1", since = "1.0.0")]
pub fn format(args: Arguments<'_>) -> string::String {
    let capacity = args.estimated_capacity();
    let mut output = string::String::with_capacity(capacity);
    output.write_fmt(args).expect("a formatting trait implementation returned an error");
    output
}