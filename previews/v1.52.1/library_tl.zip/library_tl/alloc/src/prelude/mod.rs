//! Ang paglalaan ng Prelude
//!
//! Ang layunin ng modyul na ito ay upang maibsan ang mga pag-import ng mga karaniwang ginagamit na item ng `alloc` crate sa pamamagitan ng pagdaragdag ng isang glob na pag-import sa tuktok ng mga module.
//!
//!
//! ```
//! # #![allow(unused_imports)]
//! #![feature(alloc_prelude)]
//! extern crate alloc;
//! use alloc::prelude::v1::*;
//! ```

#![unstable(feature = "alloc_prelude", issue = "58935")]

pub mod v1;