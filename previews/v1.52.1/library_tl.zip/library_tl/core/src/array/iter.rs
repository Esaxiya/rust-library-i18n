//! Tinutukoy ang nagmamay-ari ng `IntoIter` na iterator para sa mga arrays.

use crate::{
    fmt,
    iter::{ExactSizeIterator, FusedIterator, TrustedLen},
    mem::{self, MaybeUninit},
    ops::Range,
    ptr,
};

/// Isang paulit-ulit na [array] iterator.
#[stable(feature = "array_value_iter", since = "1.51.0")]
pub struct IntoIter<T, const N: usize> {
    /// Ito ay ang array kami ay iterating sa paglipas ng.
    ///
    /// Elemento na may index `i` kung saan `alive.start <= i < alive.end` hindi pa na nagbunga pa at ay may-bisa entries array.
    /// Elemento na may mga indeks `i < alive.start` o `i >= alive.end` ay nagbunga na at hindi dapat ma-access anymore!Yaong mga patay elemento ay maaaring nasa isang ganap na uninitialized estado!
    ///
    ///
    /// Kaya ang invariants ay ang mga:
    /// - `data[alive]` ay buhay (ibig sabihin naglalaman ng wastong mga elemento)
    /// - `data[..alive.start]` at `data[alive.end..]` ay patay na (ibig sabihin ang mga elemento ay nabasa na at hindi na dapat hawakan!)
    ///
    ///
    ///
    data: [MaybeUninit<T>; N],

    /// Ang mga elemento sa `data` na hindi pa nagagawa.
    ///
    /// Invariants:
    /// - `alive.start <= alive.end`
    /// - `alive.end <= N`
    alive: Range<usize>,
}

impl<T, const N: usize> IntoIter<T, N> {
    /// Lumilikha ng isang bagong umuulit sa ibinigay na `array`.
    ///
    /// *Tandaan*: ang paraan na ito ay maaaring hindi na ginagamit sa future, pagkatapos [`IntoIterator` is implemented for arrays][array-into-iter].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::array;
    ///
    /// for value in array::IntoIter::new([1, 2, 3, 4, 5]) {
    ///     // Ang uri ng `value` ay isang `i32` dito, sa halip na `&i32`
    ///     let _: i32 = value;
    /// }
    /// ```
    /// [array-into-iter]: https://github.com/rust-lang/rust/pull/65819
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn new(array: [T; N]) -> Self {
        // KALIGTASAN: Ang transmute dito ay talagang ligtas.Ang mga doc ng `MaybeUninit`
        // promise:
        //
        // > `MaybeUninit<T>` garantisadong magkaroon ng parehong laki at pagkakahanay
        // > bilang `T`.
        //
        // Ang mga doc ay nagpapakita rin ng isang transmute mula sa isang array ng `MaybeUninit<T>` sa isang array ng `T`.
        //
        //
        // Sa pamamagitan ng na, ito initialization satisfies ang invariants.

        // FIXME(LukasKalbertodt): talagang gumamit ng `mem::transmute` dito, sa sandaling ito ay gumagana sa mga generic na konst:
        //     `mem::transmute::<[T; N], [MaybeUninit<T>; N]>(array)`
        //
        // Hanggang sa panahong iyon, maaari naming gamitin ang `mem::transmute_copy` upang lumikha ng isang maliit na kopya bilang isang iba't ibang uri, pagkatapos ay kalimutan ang `array` upang hindi ito mahulog.
        //
        //
        unsafe {
            let iter = Self { data: mem::transmute_copy(&array), alive: 0..N };
            mem::forget(array);
            iter
        }
    }

    /// Nagbabalik ng isang hindi nababago na hiwa ng lahat ng mga elemento na hindi pa nabunga.
    ///
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_slice(&self) -> &[T] {
        // KALIGTASAN: Alam namin na ang lahat ng mga elemento sa loob `alive` ay maayos na nasimulan.
        unsafe {
            let slice = self.data.get_unchecked(self.alive.clone());
            MaybeUninit::slice_assume_init_ref(slice)
        }
    }

    /// Ibinabalik maaaring mabago ng isang slice ng lahat ng mga elemento na hindi pa na nagbunga pa.
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        // KALIGTASAN: Alam namin na ang lahat ng mga elemento sa loob `alive` ay maayos na nasimulan.
        unsafe {
            let slice = self.data.get_unchecked_mut(self.alive.clone());
            MaybeUninit::slice_assume_init_mut(slice)
        }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Iterator for IntoIter<T, N> {
    type Item = T;
    fn next(&mut self) -> Option<Self::Item> {
        // Kumuha ng mga susunod na index mula sa harap.
        //
        // Ang pagdaragdag ng `alive.start` ng 1 ay nagpapanatili ng invariant patungkol sa `alive`.
        // Gayunpaman, dahil sa pagbabagong ito, sa loob ng maikling panahon, ang buhay na zone ay hindi `data[alive]` na, ngunit `data[idx..alive.end]`.
        //
        self.alive.next().map(|idx| {
            // Basahin ang elemento mula sa array.
            // KALIGTASAN: `idx` ay isang index sa dating "alive" rehiyon ng
            // arrayBinabasa ang mga ito ng elemento ay nangangahulugan na `data[idx]` ay itinuturing na patay na ngayon (hindi ibig sabihin, huwag hawakan).
            // Bilang `idx` ay ang simula ng buhay-zone, ang buhay zone na ngayon `data[alive]` muli, pagpapanumbalik ng lahat ng invariants.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        let len = self.len();
        (len, Some(len))
    }

    fn count(self) -> usize {
        self.len()
    }

    fn last(mut self) -> Option<Self::Item> {
        self.next_back()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> DoubleEndedIterator for IntoIter<T, N> {
    fn next_back(&mut self) -> Option<Self::Item> {
        // Kunin ang susunod na index mula sa likuran.
        //
        // Ang pagbawas ng `alive.end` ng 1 ay nagpapanatili ng invariant patungkol sa `alive`.
        // Gayunpaman, dahil sa ang pagbabago na ito, para sa isang maikling panahon, ang buhay zone ay hindi `data[alive]` anymore, ngunit `data[alive.start..=idx]`.
        //
        self.alive.next_back().map(|idx| {
            // Basahin ang elemento mula sa array.
            // KALIGTASAN: `idx` ay isang index sa dating "alive" rehiyon ng
            // arrayBinabasa ang mga ito ng elemento ay nangangahulugan na `data[idx]` ay itinuturing na patay na ngayon (hindi ibig sabihin, huwag hawakan).
            // Tulad ng `idx` ay ang pagtatapos ng buhay na sona, ang buhay na sona ay `data[alive]` na ngayon, na ibalik ang lahat ng mga invariant.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Drop for IntoIter<T, N> {
    fn drop(&mut self) {
        // KALIGTASAN: Ito ay ligtas: ang `as_mut_slice` ay nagbabalik nang eksakto sa sub-slice
        // ng mga elemento na hindi pa inililipat at mananatili na malalaglag.
        //
        unsafe { ptr::drop_in_place(self.as_mut_slice()) }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> ExactSizeIterator for IntoIter<T, N> {
    fn len(&self) -> usize {
        // Hindi kailanman mapupuksa dahil sa invariant `buhay.start <=
        // alive.end`.
        self.alive.end - self.alive.start
    }
    fn is_empty(&self) -> bool {
        self.alive.is_empty()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> FusedIterator for IntoIter<T, N> {}

// Ang iterator talaga ang nag-uulat ng tamang haba.
// Ang bilang ng mga "alive" elemento (na pa rin ang yielded) ay ang haba ng hanay `alive`.
// Ang saklaw na ito ay nabawasan sa haba sa alinman sa `next` o `next_back`.
// Ito ay palaging decremented ng 1 sa mga pamamaraan, ngunit lamang kung `Some(_)` ay ibinalik.
#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
unsafe impl<T, const N: usize> TrustedLen for IntoIter<T, N> {}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: Clone, const N: usize> Clone for IntoIter<T, N> {
    fn clone(&self) -> Self {
        // Tandaan, hindi talaga namin kailangang tumugma sa eksaktong parehong saklaw ng buhay, upang maaari lamang nating mai-clone sa offset 0 anuman ang nasaan ang `self`.
        //
        let mut new = Self { data: MaybeUninit::uninit_array(), alive: 0..0 };

        // I-clone ang lahat ng buhay na elemento.
        for (src, dst) in self.as_slice().iter().zip(&mut new.data) {
            // Sumulat ng isang clone sa bagong array, pagkatapos ay i-update ang buhay na saklaw nito.
            // Kung ang pag-clone ng panics, ilalagay namin nang tama ang mga nakaraang item.
            dst.write(src.clone());
            new.alive.end += 1;
        }

        new
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: fmt::Debug, const N: usize> fmt::Debug for IntoIter<T, N> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // I-print lamang ang mga elemento na hindi pa nagagawa: hindi na namin ma-access ang mga naibigay na elemento.
        //
        f.debug_tuple("IntoIter").field(&self.as_slice()).finish()
    }
}