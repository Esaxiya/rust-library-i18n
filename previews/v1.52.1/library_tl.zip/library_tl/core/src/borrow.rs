//! Isang module para sa pagtatrabaho sa hiniram na data.

#![stable(feature = "rust1", since = "1.0.0")]

/// Isang trait para sa data ng paghiram.
///
/// Sa Rust, karaniwang magbigay ng iba't ibang mga representasyon ng isang uri para sa iba't ibang mga kaso ng paggamit.
/// Halimbawa, imbakan lokasyon at pamamahala para sa ang halaga ay maaaring partikular na pinili bilang naaangkop para sa isang partikular na paggamit sa pamamagitan ng mga uri pointer tulad ng [`Box<T>`] o [`Rc<T>`].
/// Higit pa sa mga generic wrappers na maaaring magamit sa anumang uri, ang ilang mga uri ay nagbibigay ng opsyonal na mga facet ng pagbibigay potensyal na magastos pag-andar.
/// Ang isang halimbawa para sa mga naturang isang uri ay [`String`] na nagdadagdag ng kakayahan para i-extend ng isang string sa pangunahing [`str`].
/// Ito ay nangangailangan ng pagsunod sa karagdagang impormasyon hindi kinakailangan para sa isang simple, hindi nababago string.
///
/// Ang mga uri na ito ay nagbibigay ng pag-access sa pinagbabatayan ng data sa pamamagitan ng mga sanggunian sa uri ng data na iyon.Sinasabing sila ay 'hiniram bilang' ang uri.
/// Halimbawa, ang isang [`Box<T>`] ay maaaring hiramin bilang `T` habang ang [`String`] ay maaaring hiramin bilang `str`.
///
/// Uri ipahayag na maaari nilang hiramin bilang ilang mga uri `T` sa pamamagitan ng pagpapatupad `Borrow<T>`, pagbibigay ng isang reference sa isang `T` in [`borrow`] paraan ng trait ni.Ang isang uri ay malayang mangutang ng maraming iba't ibang mga uri.
/// Kung nais nitong mutable manghiram bilang uri-pinapayagan na mabago ang pinagbabatayan ng data, maaari nitong dagdag na ipatupad ang [`BorrowMut<T>`].
///
/// Dagdag dito, kapag nagbibigay ng mga pagpapatupad para sa karagdagang traits, kailangang isaalang-alang kung dapat silang kumilos na magkapareho sa mga nasa kalakip na uri bilang kinahinatnan ng pagkilos bilang isang representasyon ng napapailalim na uri.
/// Karaniwang gumagamit ang generic code ng `Borrow<T>` kapag umaasa ito sa magkatulad na pag-uugali ng mga karagdagang pagpapatupad na trait na ito.
/// Ang mga traits na ito ay malamang na lilitaw bilang karagdagang trait bounds.
///
/// Sa partikular na `Eq`, `Ord` at `Hash` ay dapat na katumbas para sa mga hiniram at pagmamay-ari na halaga: Ang `x.borrow() == y.borrow()` ay dapat magbigay ng parehong resulta bilang `x == y`.
///
/// Kung generic code lamang ay kailangang trabaho para sa lahat ng mga uri na maaaring magbigay ng isang reference sa mga kaugnay type `T`, ito ay madalas na mas mahusay na gamitin [`AsRef<T>`] bilang higit pang mga uri ay maaaring ligtas na ipatupad ito.
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
/// [`Mutex<T>`]: ../../std/sync/struct.Mutex.html
/// [`Rc<T>`]: ../../std/rc/struct.Rc.html
/// [`String`]: ../../std/string/struct.String.html
/// [`borrow`]: Borrow::borrow
///
/// # Examples
///
/// Bilang isang koleksyon ng data, nagmamay-ari ang [`HashMap<K, V>`] ng parehong mga susi at halaga.Kung ang aktwal na data ng susi ay nakabalot sa isang uri ng pamamahala ng ilang uri, dapat, gayunpaman, posible pa ring maghanap para sa isang halaga gamit ang isang sanggunian sa data ng susi.
/// Halimbawa, kung ang susi ay isang string, pagkatapos ay malamang na nakaimbak ito sa hash map bilang isang [`String`], habang dapat posible na maghanap gamit ang isang [`&str`][`str`].
/// Kaya, `insert` pangangailangan upang gumana sa isang `String` habang `get` pangangailangan upang ma-gumamit ng isang `&str`.
///
/// Bahagyang pinasimple, ang mga kaugnay na bahagi ng `HashMap<K, V>` ay ganito:
///
/// ```
/// use std::borrow::Borrow;
/// use std::hash::Hash;
///
/// pub struct HashMap<K, V> {
///     # marker: ::std::marker::PhantomData<(K, V)>,
///     // tinanggal na mga patlang
/// }
///
/// impl<K, V> HashMap<K, V> {
///     pub fn insert(&self, key: K, value: V) -> Option<V>
///     where K: Hash + Eq
///     {
///         # unimplemented!()
///         // ...
///     }
///
///     pub fn get<Q>(&self, k: &Q) -> Option<&V>
///     where
///         K: Borrow<Q>,
///         Q: Hash + Eq + ?Sized
///     {
///         # unimplemented!()
///         // ...
///     }
/// }
/// ```
///
/// Ang buong mapa ng hash ay pangkaraniwan sa isang pangunahing uri ng `K`.Dahil ang mga key ay naka-imbak sa mapa hash, ang ganitong uri ay upang pag-aari ng data ang susi ni.
/// Kapag nagpapasok ng isang pares ng key-halaga, ang mapa ay binibigyan ng tulad ng `K` at kailangang hanapin ang tamang hash bucket at suriin kung ang key ay mayroon na batay sa `K` na.Samakatuwid nangangailangan ito ng `K: Hash + Eq`.
///
/// Kapag naghahanap para sa isang halaga sa mapa, gayunpaman, ang pagkakaroon upang magbigay ng isang sanggunian sa isang `K` bilang ang susi upang maghanap ay mangangailangan na palaging lumikha ng tulad ng isang pagmamay-ari na halaga.
/// Para sa mga string key, nangangahulugan ito na ang isang halaga ng `String` ay kailangang likhain para lamang sa paghahanap ng mga kaso kung saan isang `str` lamang ang magagamit.
///
/// Sa halip, ang `get` pamamaraan ay generic paglipas ng ang uri ng nakapailalim na key data, na tinatawag na `Q` sa paraan ng pirma sa itaas.Ipinapahayag nito na `K` humihiram bilang `Q` sa pamamagitan ng paghingi na `K: Borrow<Q>`.
/// Bilang karagdagan na nangangailangan ng `Q: Hash + Eq`, signal ito ng kinakailangan na ang `K` at `Q` ay may pagpapatupad ng `Hash` at `Eq` traits na gumagawa ng magkatulad na mga resulta.
///
/// Ang pagpapatupad ng `get` ay nakasalalay sa partikular na sa mga magkakahawig na mga pagpapatupad ng `Hash` sa pamamagitan ng pagtukoy ang susi ni hash bucket sa pamamagitan ng pagtawag `Hash::hash` sa halaga `Q` kahit na ito ipinasok ang susi batay sa halaga ng hash kinakalkula mula sa ang halaga ng `K`.
///
///
/// Bilang kinahinatnan, masira ang hash map kung ang isang `K` na nakabalot sa isang halagang `Q` ay gumagawa ng ibang hash kaysa sa `Q`.Halimbawa, isipin na mayroon kang isang uri na bumabalot ng isang string ngunit inihinahambing ang mga titik ng ASCII na hindi pinapansin ang kanilang kaso:
///
/// ```
/// pub struct CaseInsensitiveString(String);
///
/// impl PartialEq for CaseInsensitiveString {
///     fn eq(&self, other: &Self) -> bool {
///         self.0.eq_ignore_ascii_case(&other.0)
///     }
/// }
///
/// impl Eq for CaseInsensitiveString { }
/// ```
///
/// Dahil ang dalawang pantay na halaga ay kailangang makabuo ng parehong halaga ng hash, ang pagpapatupad ng `Hash` ay kailangang balewalain ang kaso ng ASCII, din:
///
/// ```
/// # use std::hash::{Hash, Hasher};
/// # pub struct CaseInsensitiveString(String);
/// impl Hash for CaseInsensitiveString {
///     fn hash<H: Hasher>(&self, state: &mut H) {
///         for c in self.0.as_bytes() {
///             c.to_ascii_lowercase().hash(state)
///         }
///     }
/// }
/// ```
///
/// Maaari bang ipatupad ng `CaseInsensitiveString` ang `Borrow<str>`?Tiyak na maaaring magbigay ito ng isang sanggunian sa isang hiwa ng string sa pamamagitan ng nilalaman na pagmamay-ari na string.
/// Ngunit dahil sa kanyang `Hash` pagpapatupad ay nagkakaiba, ito behaves naiiba mula `str` at samakatuwid ay hindi dapat, sa katunayan, ipatupad `Borrow<str>`.
/// Kung nais nitong payagan ang iba na mag-access sa pinagbabatayan ng `str`, magagawa niya iyon sa pamamagitan ng `AsRef<str>` na hindi nagdadala ng anumang labis na mga kinakailangan.
///
/// [`Hash`]: crate::hash::Hash
/// [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
/// [`String`]: ../../std/string/struct.String.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Borrow"]
pub trait Borrow<Borrowed: ?Sized> {
    /// Hindi maiiwasan na humiram mula sa isang nagmamay-ari na halaga.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::borrow::Borrow;
    ///
    /// fn check<T: Borrow<str>>(s: T) {
    ///     assert_eq!("Hello", s.borrow());
    /// }
    ///
    /// let s = "Hello".to_string();
    ///
    /// check(s);
    ///
    /// let s = "Hello";
    ///
    /// check(s);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn borrow(&self) -> &Borrowed;
}

/// Isang trait para sa maaaring baguhin na data ng paghiram.
///
/// Bilang isang kasama sa [`Borrow<T>`] pinapayagan ng trait na ito ng isang uri upang manghiram bilang isang pinagbabatayan na uri sa pamamagitan ng pagbibigay ng isang nababagong sanggunian.
/// Tingnan ang [`Borrow<T>`] para sa karagdagang impormasyon sa paghiram bilang ibang uri.
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait BorrowMut<Borrowed: ?Sized>: Borrow<Borrowed> {
    /// Nababago ang paghiram mula sa isang nagmamay-ari na halaga.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::borrow::BorrowMut;
    ///
    /// fn check<T: BorrowMut<[i32]>>(mut v: T) {
    ///     assert_eq!(&mut [1, 2, 3], v.borrow_mut());
    /// }
    ///
    /// let v = vec![1, 2, 3];
    ///
    /// check(v);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn borrow_mut(&mut self) -> &mut Borrowed;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for T {
    #[rustc_diagnostic_item = "noop_method_borrow"]
    fn borrow(&self) -> &T {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> BorrowMut<T> for T {
    fn borrow_mut(&mut self) -> &mut T {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for &T {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for &mut T {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> BorrowMut<T> for &mut T {
    fn borrow_mut(&mut self) -> &mut T {
        &mut **self
    }
}