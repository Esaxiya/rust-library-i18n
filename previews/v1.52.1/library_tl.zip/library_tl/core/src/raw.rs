#![allow(missing_docs)]
#![unstable(feature = "raw", issue = "27751")]

//! Naglalaman ng mga kahulugan ng istruktura para sa layout ng mga built-in na uri ng tagatala.
//!
//! Maaari silang magamit bilang mga target ng mga pagpapalipat-lipat sa hindi ligtas na code para sa pagmamanipula nang direkta sa mga hilaw na representasyon.
//!
//!
//! Ang kanilang kahulugan ay dapat palaging tumutugma sa tinukoy ng ABI sa `rustc_middle::ty::layout`.
//!

/// Ang representasyon ng isang bagay na trait tulad ng `&dyn SomeTrait`.
///
/// struct na ito ay may parehong layout bilang uri tulad `&dyn SomeTrait` at `Box<dyn AnotherTrait>`.
///
/// `TraitObject` garantisadong upang tumugma sa mga layout, ngunit hindi ito ang uri ng mga bagay na trait (hal., ang mga patlang ay hindi direktang mapupuntahan sa isang `&dyn SomeTrait`) at hindi rin nito kontrolado ang layout na iyon (ang pagbabago ng kahulugan ay hindi magbabago ng layout ng isang `&dyn SomeTrait`).
///
/// Dinisenyo lamang ito upang magamit ng hindi ligtas na code na kailangang manipulahin ang mga detalye ng mababang antas.
///
/// Walang paraan upang mag-refer sa lahat ng mga trait na bagay sa pangkalahatan, kaya ang tanging paraan upang lumikha ng mga halaga ng ganitong uri ay ang mga pagpapaandar tulad ng [`std::mem::transmute`][transmute].
/// Katulad nito, ang tanging paraan upang lumikha ng isang totoong bagay na trait mula sa isang halagang `TraitObject` ay sa `transmute`.
///
/// [transmute]: crate::intrinsics::transmute
///
/// Ang pagbubuo ng isang bagay na trait na may hindi magkatugma na mga uri-isa kung saan ang vtable ay hindi tumutugma sa uri ng halaga na kung saan ang mga puntos ng data pointer-ay malamang na humantong sa hindi natukoy na pag-uugali.
///
/// # Examples
///
/// ```
/// #![feature(raw)]
///
/// use std::{mem, raw};
///
/// // isang halimbawa trait
/// trait Foo {
///     fn bar(&self) -> i32;
/// }
///
/// impl Foo for i32 {
///     fn bar(&self) -> i32 {
///          *self + 1
///     }
/// }
///
/// let value: i32 = 123;
///
/// // hayaan ang tagatala na gumawa ng isang bagay na trait
/// let object: &dyn Foo = &value;
///
/// // tingnan ang hilaw na representasyon
/// let raw_object: raw::TraitObject = unsafe { mem::transmute(object) };
///
/// // ang data pointer ay ang address ng `value`
/// assert_eq!(raw_object.data as *const i32, &value as *const _);
///
/// let other_value: i32 = 456;
///
/// // bumuo ng isang bagong bagay, na tumuturo sa ibang `i32`, maingat na gamitin ang `i32` vtable mula sa `object`
/////
/// let synthesized: &dyn Foo = unsafe {
///      mem::transmute(raw::TraitObject {
///          data: &other_value as *const _ as *mut (),
///          vtable: raw_object.vtable,
///      })
/// };
///
/// // dapat itong gumana tulad ng kung nakagawa kami ng isang trait na bagay sa labas ng `other_value` nang direkta
/////
/// assert_eq!(synthesized.bar(), 457);
/// ```
///
///
///
///
///
///
///
///
///
#[repr(C)]
#[derive(Copy, Clone)]
#[allow(missing_debug_implementations)]
pub struct TraitObject {
    pub data: *mut (),
    pub vtable: *mut (),
}