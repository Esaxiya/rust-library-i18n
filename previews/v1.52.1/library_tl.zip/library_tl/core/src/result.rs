//! Error sa paghawak sa uri ng `Result`.
//!
//! [`Result<T, E>`][`Result`] ay ang uri na ginamit para sa mga error sa pagbabalik at paglaganap.
//! Ito ay isang enum na may mga variant, [`Ok(T)`], na kumakatawan sa tagumpay at naglalaman ng isang halaga, at [`Err(E)`], na kumakatawan sa error at naglalaman ng isang halaga ng error.
//!
//! ```
//! # #[allow(dead_code)]
//! enum Result<T, E> {
//!    Ok(T),
//!    Err(E),
//! }
//! ```
//!
//! Ang pagpapaandar ay nagbabalik ng [`Result`] tuwing ang mga pagkakamali ay inaasahan at mababawi.Sa `std` crate, ang [`Result`] ay higit na kilalang ginagamit para sa [I/O](../../std/io/index.html).
//!
//! Ang isang simpleng pagpapaandar na nagbabalik ng [`Result`] ay maaaring natukoy at ginamit tulad nito:
//!
//! ```
//! #[derive(Debug)]
//! enum Version { Version1, Version2 }
//!
//! fn parse_version(header: &[u8]) -> Result<Version, &'static str> {
//!     match header.get(0) {
//!         None => Err("invalid header length"),
//!         Some(&1) => Ok(Version::Version1),
//!         Some(&2) => Ok(Version::Version2),
//!         Some(_) => Err("invalid version"),
//!     }
//! }
//!
//! let version = parse_version(&[1, 2, 3, 4]);
//! match version {
//!     Ok(v) => println!("working with version: {:?}", v),
//!     Err(e) => println!("error parsing header: {:?}", e),
//! }
//! ```
//!
//! Ang pagtutugma ng pattern sa [`Resulta`] s ay malinaw at prangka para sa mga simpleng kaso, ngunit ang [`Result`] ay may kasamang ilang mga paraan ng kaginhawaan na ginagawang mas madaling gawin ito.
//!
//! ```
//! let good_result: Result<i32, i32> = Ok(10);
//! let bad_result: Result<i32, i32> = Err(10);
//!
//! // Ginagawa ng mga pamamaraan na `is_ok` at `is_err` ang sinasabi nila.
//! assert!(good_result.is_ok() && !good_result.is_err());
//! assert!(bad_result.is_err() && !bad_result.is_ok());
//!
//! // `map` Naubos ang `Result` at gumagawa ng iba pa.
//! let good_result: Result<i32, i32> = good_result.map(|i| i + 1);
//! let bad_result: Result<i32, i32> = bad_result.map(|i| i - 1);
//!
//! // Gumamit ng `and_then` upang ipagpatuloy ang pagkalkula.
//! let good_result: Result<bool, i32> = good_result.and_then(|i| Ok(i == 11));
//!
//! // Gumamit ng `or_else` upang hawakan ang error.
//! let bad_result: Result<i32, i32> = bad_result.or_else(|i| Ok(i + 20));
//!
//! // Ubusin ang resulta at ibalik ang mga nilalaman sa `unwrap`.
//! let final_awesome_result = good_result.unwrap();
//! ```
//!
//! # Dapat gamitin ang mga resulta
//!
//! Ang isang pangkaraniwang problema sa paggamit ng mga halagang bumalik upang ipahiwatig ang mga pagkakamali ay madali itong balewalain ang halaga ng pagbalik, sa gayon ay hindi pagtupad sa error.
//! [`Result`] ay na-annotate ng `#[must_use]` na katangian, na magdudulot sa compiler na maglabas ng isang babala kapag ang isang halaga ng Resulta ay hindi pinansin.
//! Ginagawa nitong lalong kapaki-pakinabang ang [`Result`] sa mga pag-andar na maaaring makaharap ng mga error ngunit hindi sa kabilang banda ay ibalik ang isang kapaki-pakinabang na halaga.
//!
//! Isaalang-alang ang paraan ng [`write_all`] na tinukoy para sa mga uri ng I/O ng [`Write`] trait:
//!
//! ```
//! use std::io;
//!
//! trait Write {
//!     fn write_all(&mut self, bytes: &[u8]) -> Result<(), io::Error>;
//! }
//! ```
//!
//! *Note: Ang tunay na kahulugan ng [`Write`] ay gumagamit ng [`io::Result`], na isang kasingkahulugan lamang para sa [`Resulta`]`<T,`[`io: :Error`]`>`.*
//!
//! Ang pamamaraang ito ay hindi gumagawa ng isang halaga, ngunit maaaring mabigo ang pagsulat.Mahalagang hawakan ang kaso ng error, at *hindi* sumulat ng tulad nito:
//!
//! ```no_run
//! # #![allow(unused_must_use)] // \o/
//! use std::fs::File;
//! use std::io::prelude::*;
//!
//! let mut file = File::create("valuable_data.txt").unwrap();
//! // Kung mga error sa `write_all`, hindi namin malalaman, dahil ang halaga ng pagbalik ay hindi pinapansin.
//! //
//! file.write_all(b"important message");
//! ```
//!
//! Kung isinulat mo * iyon sa Rust, bibigyan ka ng compiler ng isang babala (bilang default, kinokontrol ng `unused_must_use` lint).
//!
//! Maaari kang sa halip, kung hindi mo nais na hawakan ang error, igiit lamang ang tagumpay sa [`expect`].
//! Ito ay panic kung nabigo ang pagsusulat, na nagbibigay ng isang kapaki-pakinabang na mensahe na nagpapahiwatig kung bakit:
//!
//! ```no_run
//! use std::fs::File;
//! use std::io::prelude::*;
//!
//! let mut file = File::create("valuable_data.txt").unwrap();
//! file.write_all(b"important message").expect("failed to write message");
//! ```
//!
//! Maaari mo ring igiit ang tagumpay:
//!
//! ```no_run
//! # use std::fs::File;
//! # use std::io::prelude::*;
//! # let mut file = File::create("valuable_data.txt").unwrap();
//! assert!(file.write_all(b"important message").is_ok());
//! ```
//!
//! O ipalaganap ang error sa stack ng tawag sa [`?`]:
//!
//! ```
//! # use std::fs::File;
//! # use std::io::prelude::*;
//! # use std::io;
//! # #[allow(dead_code)]
//! fn write_message() -> io::Result<()> {
//!     let mut file = File::create("valuable_data.txt")?;
//!     file.write_all(b"important message")?;
//!     Ok(())
//! }
//! ```
//!
//! # Ang operator ng tandang pananong, `?`
//!
//! Kapag nagsusulat ng code na tumatawag sa maraming mga pagpapaandar na ibabalik ang uri ng [`Result`], maaaring maging nakakapagod ang paghawak ng error.
//! Ang operator ng tandang pananong, [`?`], ay nagtatago ng ilan sa boilerplate ng pagkalat ng mga error sa stack ng tawag.
//!
//! Pinalitan nito:
//!
//! ```
//! # #![allow(dead_code)]
//! use std::fs::File;
//! use std::io::prelude::*;
//! use std::io;
//!
//! struct Info {
//!     name: String,
//!     age: i32,
//!     rating: i32,
//! }
//!
//! fn write_info(info: &Info) -> io::Result<()> {
//!     // Maagang pagbalik sa error
//!     let mut file = match File::create("my_best_friends.txt") {
//!            Err(e) => return Err(e),
//!            Ok(f) => f,
//!     };
//!     if let Err(e) = file.write_all(format!("name: {}\n", info.name).as_bytes()) {
//!         return Err(e)
//!     }
//!     if let Err(e) = file.write_all(format!("age: {}\n", info.age).as_bytes()) {
//!         return Err(e)
//!     }
//!     if let Err(e) = file.write_all(format!("rating: {}\n", info.rating).as_bytes()) {
//!         return Err(e)
//!     }
//!     Ok(())
//! }
//! ```
//!
//! Kasama nito:
//!
//! ```
//! # #![allow(dead_code)]
//! use std::fs::File;
//! use std::io::prelude::*;
//! use std::io;
//!
//! struct Info {
//!     name: String,
//!     age: i32,
//!     rating: i32,
//! }
//!
//! fn write_info(info: &Info) -> io::Result<()> {
//!     let mut file = File::create("my_best_friends.txt")?;
//!     // Maagang pagbalik sa error
//!     file.write_all(format!("name: {}\n", info.name).as_bytes())?;
//!     file.write_all(format!("age: {}\n", info.age).as_bytes())?;
//!     file.write_all(format!("rating: {}\n", info.rating).as_bytes())?;
//!     Ok(())
//! }
//! ```
//!
//! *Ito ay magkano nicer!*
//!
//! Ang pagtatapos ng expression sa [`?`] ay magreresulta sa hindi nakabalot na tagumpay ([`Ok`]) na halaga, maliban kung ang resulta ay [`Err`], kung saan ang [`Err`] ay naibalik nang maaga mula sa pag-andar ng enclosing.
//!
//!
//! [`?`] Maaari lamang magamit sa mga pagpapaandar na nagbabalik ng [`Result`] dahil sa maagang pagbalik ng [`Err`] na ibinibigay nito.
//!
//! [`expect`]: Result::expect
//! [`Write`]: ../../std/io/trait.Write.html
//! [`write_all`]: ../../std/io/trait.Write.html#method.write_all
//! [`io::Result`]: ../../std/io/type.Result.html
//! [`?`]: crate::ops::Try
//! [`Ok(T)`]: Ok
//! [`Err(E)`]: Err
//! [`io::Error`]: ../../std/io/struct.Error.html
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::iter::{self, FromIterator, FusedIterator, TrustedLen};
use crate::ops::{self, Deref, DerefMut};
use crate::{convert, fmt, hint};

/// `Result` ay isang uri na kumakatawan sa alinman sa tagumpay ([`Ok`]) o pagkabigo ([`Err`]).
///
/// Tingnan ang [module documentation](self) para sa mga detalye.
#[derive(Copy, PartialEq, PartialOrd, Eq, Ord, Debug, Hash)]
#[must_use = "this `Result` may be an `Err` variant, which should be handled"]
#[rustc_diagnostic_item = "result_type"]
#[stable(feature = "rust1", since = "1.0.0")]
pub enum Result<T, E> {
    /// Naglalaman ng halaga ng tagumpay
    #[lang = "Ok"]
    #[stable(feature = "rust1", since = "1.0.0")]
    Ok(#[stable(feature = "rust1", since = "1.0.0")] T),

    /// Naglalaman ng halaga ng error
    #[lang = "Err"]
    #[stable(feature = "rust1", since = "1.0.0")]
    Err(#[stable(feature = "rust1", since = "1.0.0")] E),
}

/////////////////////////////////////////////////////////////////////////////
// Pagpapatupad ng uri
/////////////////////////////////////////////////////////////////////////////

impl<T, E> Result<T, E> {
    /////////////////////////////////////////////////////////////////////////
    // Pagtatanong sa mga nilalaman na nilalaman
    /////////////////////////////////////////////////////////////////////////

    /// Ibinabalik ang `true` kung ang resulta ay [`Ok`].
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// let x: Result<i32, &str> = Ok(-3);
    /// assert_eq!(x.is_ok(), true);
    ///
    /// let x: Result<i32, &str> = Err("Some error message");
    /// assert_eq!(x.is_ok(), false);
    /// ```
    #[must_use = "if you intended to assert that this is ok, consider `.unwrap()` instead"]
    #[rustc_const_stable(feature = "const_result", since = "1.48.0")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn is_ok(&self) -> bool {
        matches!(*self, Ok(_))
    }

    /// Ibinabalik ang `true` kung ang resulta ay [`Err`].
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// let x: Result<i32, &str> = Ok(-3);
    /// assert_eq!(x.is_err(), false);
    ///
    /// let x: Result<i32, &str> = Err("Some error message");
    /// assert_eq!(x.is_err(), true);
    /// ```
    #[must_use = "if you intended to assert that this is err, consider `.unwrap_err()` instead"]
    #[rustc_const_stable(feature = "const_result", since = "1.48.0")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn is_err(&self) -> bool {
        !self.is_ok()
    }

    /// Ibinabalik ang `true` kung ang resulta ay isang halagang [`Ok`] na naglalaman ng ibinigay na halaga.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_result_contains)]
    ///
    /// let x: Result<u32, &str> = Ok(2);
    /// assert_eq!(x.contains(&2), true);
    ///
    /// let x: Result<u32, &str> = Ok(3);
    /// assert_eq!(x.contains(&2), false);
    ///
    /// let x: Result<u32, &str> = Err("Some error message");
    /// assert_eq!(x.contains(&2), false);
    /// ```
    #[must_use]
    #[inline]
    #[unstable(feature = "option_result_contains", issue = "62358")]
    pub fn contains<U>(&self, x: &U) -> bool
    where
        U: PartialEq<T>,
    {
        match self {
            Ok(y) => x == y,
            Err(_) => false,
        }
    }

    /// Ibinabalik ang `true` kung ang resulta ay isang halagang [`Err`] na naglalaman ng ibinigay na halaga.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(result_contains_err)]
    ///
    /// let x: Result<u32, &str> = Ok(2);
    /// assert_eq!(x.contains_err(&"Some error message"), false);
    ///
    /// let x: Result<u32, &str> = Err("Some error message");
    /// assert_eq!(x.contains_err(&"Some error message"), true);
    ///
    /// let x: Result<u32, &str> = Err("Some other error message");
    /// assert_eq!(x.contains_err(&"Some error message"), false);
    /// ```
    #[must_use]
    #[inline]
    #[unstable(feature = "result_contains_err", issue = "62358")]
    pub fn contains_err<F>(&self, f: &F) -> bool
    where
        F: PartialEq<E>,
    {
        match self {
            Ok(_) => false,
            Err(e) => f == e,
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // Adapter para sa bawat variant
    /////////////////////////////////////////////////////////////////////////

    /// Mga nagko-convert mula `Result<T, E>` hanggang [`Option<T>`].
    ///
    /// Binabago ang `self` sa isang [`Option<T>`], ubusin ang `self`, at itatapon ang error, kung mayroon man.
    ///
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(2);
    /// assert_eq!(x.ok(), Some(2));
    ///
    /// let x: Result<u32, &str> = Err("Nothing here");
    /// assert_eq!(x.ok(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ok(self) -> Option<T> {
        match self {
            Ok(x) => Some(x),
            Err(_) => None,
        }
    }

    /// Hikayat mula `Result<T, E>` na [`Option<E>`].
    ///
    /// Binabago ang `self` sa isang [`Option<E>`], ubusin ang `self`, at itatapon ang halaga ng tagumpay, kung mayroon man.
    ///
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(2);
    /// assert_eq!(x.err(), None);
    ///
    /// let x: Result<u32, &str> = Err("Nothing here");
    /// assert_eq!(x.err(), Some("Nothing here"));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn err(self) -> Option<E> {
        match self {
            Ok(_) => None,
            Err(x) => Some(x),
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // Adapter para sa pagtatrabaho sa mga sanggunian
    /////////////////////////////////////////////////////////////////////////

    /// Hikayat mula `&Result<T, E>` na `Result<&T, &E>`.
    ///
    /// Gumagawa ng isang bagong `Result`, naglalaman ng isang sanggunian sa orihinal, na iniiwan ang orihinal sa lugar.
    ///
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(2);
    /// assert_eq!(x.as_ref(), Ok(&2));
    ///
    /// let x: Result<u32, &str> = Err("Error");
    /// assert_eq!(x.as_ref(), Err(&"Error"));
    /// ```
    #[inline]
    #[rustc_const_stable(feature = "const_result", since = "1.48.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn as_ref(&self) -> Result<&T, &E> {
        match *self {
            Ok(ref x) => Ok(x),
            Err(ref x) => Err(x),
        }
    }

    /// Mga nagko-convert mula `&mut Result<T, E>` hanggang `Result<&mut T, &mut E>`.
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// fn mutate(r: &mut Result<i32, i32>) {
    ///     match r.as_mut() {
    ///         Ok(v) => *v = 42,
    ///         Err(e) => *e = 0,
    ///     }
    /// }
    ///
    /// let mut x: Result<i32, i32> = Ok(2);
    /// mutate(&mut x);
    /// assert_eq!(x.unwrap(), 42);
    ///
    /// let mut x: Result<i32, i32> = Err(13);
    /// mutate(&mut x);
    /// assert_eq!(x.unwrap_err(), 0);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn as_mut(&mut self) -> Result<&mut T, &mut E> {
        match *self {
            Ok(ref mut x) => Ok(x),
            Err(ref mut x) => Err(x),
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // Ang pagbabago ng mga nilalaman na naglalaman
    /////////////////////////////////////////////////////////////////////////

    /// Mapa ang isang `Result<T, E>` hanggang `Result<U, E>` sa pamamagitan ng paglalapat ng isang pag-andar sa isang nakapaloob na halagang [`Ok`], na iniiwan ang isang halagang [`Err`] na hindi nagalaw.
    ///
    ///
    /// Ang pagpapaandar na ito ay maaaring magamit upang bumuo ng mga resulta ng dalawang pag-andar.
    ///
    /// # Examples
    ///
    /// I-print ang mga numero sa bawat linya ng isang string na pinarami ng dalawa.
    ///
    /// ```
    /// let line = "1\n2\n3\n4\n";
    ///
    /// for num in line.lines() {
    ///     match num.parse::<i32>().map(|i| i * 2) {
    ///         Ok(n) => println!("{}", n),
    ///         Err(..) => {}
    ///     }
    /// }
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn map<U, F: FnOnce(T) -> U>(self, op: F) -> Result<U, E> {
        match self {
            Ok(t) => Ok(op(t)),
            Err(e) => Err(e),
        }
    }

    /// Nalalapat ang isang pagpapaandar sa nilalaman na nilalaman (kung [`Ok`]), o ibabalik ang ibinigay na default (kung [`Err`]).
    ///
    /// Ang mga pangangatwirang naipasa sa `map_or` ay sabik na sinusuri;kung ipinapasa mo ang resulta ng isang tawag sa pag-andar, inirerekumenda na gamitin ang [`map_or_else`], na tinatamad na masuri.
    ///
    ///
    /// [`map_or_else`]: Result::map_or_else
    ///
    /// # Examples
    ///
    /// ```
    /// let x: Result<_, &str> = Ok("foo");
    /// assert_eq!(x.map_or(42, |v| v.len()), 3);
    ///
    /// let x: Result<&str, _> = Err("bar");
    /// assert_eq!(x.map_or(42, |v| v.len()), 42);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "result_map_or", since = "1.41.0")]
    pub fn map_or<U, F: FnOnce(T) -> U>(self, default: U, f: F) -> U {
        match self {
            Ok(t) => f(t),
            Err(_) => default,
        }
    }

    /// Mapa ang isang `Result<T, E>` hanggang `U` sa pamamagitan ng paglalapat ng isang pagpapaandar sa isang nakapaloob na halagang [`Ok`], o isang pagpapaandar na fallback sa isang nakapaloob na halagang [`Err`].
    ///
    ///
    /// Ang pagpapaandar na ito ay maaaring magamit upang i-unpack ang isang matagumpay na resulta habang hawakan ang isang error.
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// let k = 21;
    ///
    /// let x : Result<_, &str> = Ok("foo");
    /// assert_eq!(x.map_or_else(|e| k * 2, |v| v.len()), 3);
    ///
    /// let x : Result<&str, _> = Err("bar");
    /// assert_eq!(x.map_or_else(|e| k * 2, |v| v.len()), 42);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "result_map_or_else", since = "1.41.0")]
    pub fn map_or_else<U, D: FnOnce(E) -> U, F: FnOnce(T) -> U>(self, default: D, f: F) -> U {
        match self {
            Ok(t) => f(t),
            Err(e) => default(e),
        }
    }

    /// Mga mapa ng isang `Result<T, E>` na `Result<T, F>` sa pamamagitan ng paglalapat ng isang function sa isang nakapaloob [`Err`] halaga, nag-iiwan ng isang [`Ok`] halaga nagalaw.
    ///
    ///
    /// Ang pagpapaandar na ito ay maaaring magamit upang makapasa sa isang matagumpay na resulta habang hawakan ang isang error.
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// fn stringify(x: u32) -> String { format!("error code: {}", x) }
    ///
    /// let x: Result<u32, u32> = Ok(2);
    /// assert_eq!(x.map_err(stringify), Ok(2));
    ///
    /// let x: Result<u32, u32> = Err(13);
    /// assert_eq!(x.map_err(stringify), Err("error code: 13".to_string()));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn map_err<F, O: FnOnce(E) -> F>(self, op: O) -> Result<T, F> {
        match self {
            Ok(t) => Ok(t),
            Err(e) => Err(op(e)),
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // Mga tagapagbuo ng Iterator
    /////////////////////////////////////////////////////////////////////////

    /// Nagbabalik ng isang umuulit sa posibleng nilalaman na halaga.
    ///
    /// Nagbibigay ang iterator ng isang halaga kung ang resulta ay [`Result::Ok`], kung hindi man wala.
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(7);
    /// assert_eq!(x.iter().next(), Some(&7));
    ///
    /// let x: Result<u32, &str> = Err("nothing!");
    /// assert_eq!(x.iter().next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter { inner: self.as_ref().ok() }
    }

    /// Nagbabalik ng isang nababagabag na iterator sa posibleng nilalaman na halaga.
    ///
    /// Nagbibigay ang iterator ng isang halaga kung ang resulta ay [`Result::Ok`], kung hindi man wala.
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// let mut x: Result<u32, &str> = Ok(7);
    /// match x.iter_mut().next() {
    ///     Some(v) => *v = 40,
    ///     None => {},
    /// }
    /// assert_eq!(x, Ok(40));
    ///
    /// let mut x: Result<u32, &str> = Err("nothing!");
    /// assert_eq!(x.iter_mut().next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        IterMut { inner: self.as_mut().ok() }
    }

    ////////////////////////////////////////////////////////////////////////
    // Ang pagpapatakbo ng Boolean sa mga halaga, sabik at tamad
    /////////////////////////////////////////////////////////////////////////

    /// Ibinabalik ang `res` kung ang resulta ay [`Ok`], kung hindi man ay ibabalik ang [`Err`] na halaga ng `self`.
    ///
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(2);
    /// let y: Result<&str, &str> = Err("late error");
    /// assert_eq!(x.and(y), Err("late error"));
    ///
    /// let x: Result<u32, &str> = Err("early error");
    /// let y: Result<&str, &str> = Ok("foo");
    /// assert_eq!(x.and(y), Err("early error"));
    ///
    /// let x: Result<u32, &str> = Err("not a 2");
    /// let y: Result<&str, &str> = Err("late error");
    /// assert_eq!(x.and(y), Err("not a 2"));
    ///
    /// let x: Result<u32, &str> = Ok(2);
    /// let y: Result<&str, &str> = Ok("different result type");
    /// assert_eq!(x.and(y), Ok("different result type"));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn and<U>(self, res: Result<U, E>) -> Result<U, E> {
        match self {
            Ok(_) => res,
            Err(e) => Err(e),
        }
    }

    /// Tawag sa `op` kung ang resulta ay [`Ok`], kung hindi man ay ibabalik ang [`Err`] na halaga ng `self`.
    ///
    ///
    /// Ang pagpapaandar na ito ay maaaring magamit para sa daloy ng kontrol batay sa mga halagang `Result`.
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// fn sq(x: u32) -> Result<u32, u32> { Ok(x * x) }
    /// fn err(x: u32) -> Result<u32, u32> { Err(x) }
    ///
    /// assert_eq!(Ok(2).and_then(sq).and_then(sq), Ok(16));
    /// assert_eq!(Ok(2).and_then(sq).and_then(err), Err(4));
    /// assert_eq!(Ok(2).and_then(err).and_then(sq), Err(2));
    /// assert_eq!(Err(3).and_then(sq).and_then(sq), Err(3));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn and_then<U, F: FnOnce(T) -> Result<U, E>>(self, op: F) -> Result<U, E> {
        match self {
            Ok(t) => op(t),
            Err(e) => Err(e),
        }
    }

    /// Ibinabalik ang `res` kung ang resulta ay [`Err`], kung hindi man ay ibabalik ang [`Ok`] na halaga ng `self`.
    ///
    /// Ang mga pangangatwirang naipasa sa `or` ay sabik na sinusuri;kung ipinapasa mo ang resulta ng isang tawag sa pag-andar, inirerekumenda na gamitin ang [`or_else`], na tinatamad na masuri.
    ///
    ///
    /// [`or_else`]: Result::or_else
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(2);
    /// let y: Result<u32, &str> = Err("late error");
    /// assert_eq!(x.or(y), Ok(2));
    ///
    /// let x: Result<u32, &str> = Err("early error");
    /// let y: Result<u32, &str> = Ok(2);
    /// assert_eq!(x.or(y), Ok(2));
    ///
    /// let x: Result<u32, &str> = Err("not a 2");
    /// let y: Result<u32, &str> = Err("late error");
    /// assert_eq!(x.or(y), Err("late error"));
    ///
    /// let x: Result<u32, &str> = Ok(2);
    /// let y: Result<u32, &str> = Ok(100);
    /// assert_eq!(x.or(y), Ok(2));
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn or<F>(self, res: Result<T, F>) -> Result<T, F> {
        match self {
            Ok(v) => Ok(v),
            Err(_) => res,
        }
    }

    /// Tawag sa `op` kung ang resulta ay [`Err`], kung hindi man ay ibabalik ang [`Ok`] na halaga ng `self`.
    ///
    ///
    /// Ang pagpapaandar na ito ay maaaring magamit para sa daloy ng kontrol batay sa mga halaga ng resulta.
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// fn sq(x: u32) -> Result<u32, u32> { Ok(x * x) }
    /// fn err(x: u32) -> Result<u32, u32> { Err(x) }
    ///
    /// assert_eq!(Ok(2).or_else(sq).or_else(sq), Ok(2));
    /// assert_eq!(Ok(2).or_else(err).or_else(sq), Ok(2));
    /// assert_eq!(Err(3).or_else(sq).or_else(err), Ok(9));
    /// assert_eq!(Err(3).or_else(err).or_else(err), Err(3));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn or_else<F, O: FnOnce(E) -> Result<T, F>>(self, op: O) -> Result<T, F> {
        match self {
            Ok(t) => Ok(t),
            Err(e) => op(e),
        }
    }

    /// Ibinabalik ang nilalaman na [`Ok`] na halaga o isang ibinigay na default.
    ///
    /// Ang mga pangangatwirang naipasa sa `unwrap_or` ay sabik na sinusuri;kung ipinapasa mo ang resulta ng isang tawag sa pag-andar, inirerekumenda na gamitin ang [`unwrap_or_else`], na tinatamad na masuri.
    ///
    ///
    /// [`unwrap_or_else`]: Result::unwrap_or_else
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// let default = 2;
    /// let x: Result<u32, &str> = Ok(9);
    /// assert_eq!(x.unwrap_or(default), 9);
    ///
    /// let x: Result<u32, &str> = Err("error");
    /// assert_eq!(x.unwrap_or(default), default);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn unwrap_or(self, default: T) -> T {
        match self {
            Ok(t) => t,
            Err(_) => default,
        }
    }

    /// Ibinabalik ang nakapaloob [`Ok`] halaga o computes ito mula sa pagsasara.
    ///
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// fn count(x: &str) -> usize { x.len() }
    ///
    /// assert_eq!(Ok(2).unwrap_or_else(count), 2);
    /// assert_eq!(Err("foo").unwrap_or_else(count), 3);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn unwrap_or_else<F: FnOnce(E) -> T>(self, op: F) -> T {
        match self {
            Ok(t) => t,
            Err(e) => op(e),
        }
    }

    /// Ibinabalik ang nilalaman na [`Ok`] na halaga, ubusin ang halagang `self`, nang hindi sinusuri na ang halaga ay hindi isang [`Err`].
    ///
    ///
    /// # Safety
    ///
    /// Ang pagtawag sa pamamaraang ito sa isang [`Err`] ay *[hindi natukoy na pag-uugali]*.
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_result_unwrap_unchecked)]
    /// let x: Result<u32, &str> = Ok(2);
    /// assert_eq!(unsafe { x.unwrap_unchecked() }, 2);
    /// ```
    ///
    /// ```no_run
    /// #![feature(option_result_unwrap_unchecked)]
    /// let x: Result<u32, &str> = Err("emergency failure");
    /// unsafe { x.unwrap_unchecked(); } // Hindi natukoy na pag-uugali!
    /// ```
    #[inline]
    #[track_caller]
    #[unstable(feature = "option_result_unwrap_unchecked", reason = "newly added", issue = "81383")]
    pub unsafe fn unwrap_unchecked(self) -> T {
        debug_assert!(self.is_ok());
        match self {
            Ok(t) => t,
            // KALIGTASAN: ang kontrata sa kaligtasan ay dapat na panatilihin ng tumatawag.
            Err(_) => unsafe { hint::unreachable_unchecked() },
        }
    }

    /// Ibinabalik ang nilalaman na [`Err`] na halaga, ubusin ang halagang `self`, nang hindi sinusuri na ang halaga ay hindi isang [`Ok`].
    ///
    ///
    /// # Safety
    ///
    /// Ang pagtawag sa pamamaraang ito sa isang [`Ok`] ay *[hindi natukoy na pag-uugali]*.
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```no_run
    /// #![feature(option_result_unwrap_unchecked)]
    /// let x: Result<u32, &str> = Ok(2);
    /// unsafe { x.unwrap_err_unchecked() }; // Hindi natukoy na pag-uugali!
    /// ```
    ///
    /// ```
    /// #![feature(option_result_unwrap_unchecked)]
    /// let x: Result<u32, &str> = Err("emergency failure");
    /// assert_eq!(unsafe { x.unwrap_err_unchecked() }, "emergency failure");
    /// ```
    #[inline]
    #[track_caller]
    #[unstable(feature = "option_result_unwrap_unchecked", reason = "newly added", issue = "81383")]
    pub unsafe fn unwrap_err_unchecked(self) -> E {
        debug_assert!(self.is_err());
        match self {
            // KALIGTASAN: ang kontrata sa kaligtasan ay dapat na panatilihin ng tumatawag.
            Ok(_) => unsafe { hint::unreachable_unchecked() },
            Err(e) => e,
        }
    }
}

impl<T: Copy, E> Result<&T, E> {
    /// Mapa ang isang `Result<&T, E>` sa isang `Result<T, E>` sa pamamagitan ng pagkopya ng mga nilalaman ng `Ok` na bahagi.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(result_copied)]
    /// let val = 12;
    /// let x: Result<&i32, i32> = Ok(&val);
    /// assert_eq!(x, Ok(&12));
    /// let copied = x.copied();
    /// assert_eq!(copied, Ok(12));
    /// ```
    #[unstable(feature = "result_copied", reason = "newly added", issue = "63168")]
    pub fn copied(self) -> Result<T, E> {
        self.map(|&t| t)
    }
}

impl<T: Copy, E> Result<&mut T, E> {
    /// Mapa ang isang `Result<&mut T, E>` sa isang `Result<T, E>` sa pamamagitan ng pagkopya ng mga nilalaman ng `Ok` na bahagi.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(result_copied)]
    /// let mut val = 12;
    /// let x: Result<&mut i32, i32> = Ok(&mut val);
    /// assert_eq!(x, Ok(&mut 12));
    /// let copied = x.copied();
    /// assert_eq!(copied, Ok(12));
    /// ```
    #[unstable(feature = "result_copied", reason = "newly added", issue = "63168")]
    pub fn copied(self) -> Result<T, E> {
        self.map(|&mut t| t)
    }
}

impl<T: Clone, E> Result<&T, E> {
    /// Mapa ang isang `Result<&T, E>` sa isang `Result<T, E>` sa pamamagitan ng pag-clone ng mga nilalaman ng `Ok` na bahagi.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(result_cloned)]
    /// let val = 12;
    /// let x: Result<&i32, i32> = Ok(&val);
    /// assert_eq!(x, Ok(&12));
    /// let cloned = x.cloned();
    /// assert_eq!(cloned, Ok(12));
    /// ```
    #[unstable(feature = "result_cloned", reason = "newly added", issue = "63168")]
    pub fn cloned(self) -> Result<T, E> {
        self.map(|t| t.clone())
    }
}

impl<T: Clone, E> Result<&mut T, E> {
    /// Mapa ang isang `Result<&mut T, E>` sa isang `Result<T, E>` sa pamamagitan ng pag-clone ng mga nilalaman ng `Ok` na bahagi.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(result_cloned)]
    /// let mut val = 12;
    /// let x: Result<&mut i32, i32> = Ok(&mut val);
    /// assert_eq!(x, Ok(&mut 12));
    /// let cloned = x.cloned();
    /// assert_eq!(cloned, Ok(12));
    /// ```
    #[unstable(feature = "result_cloned", reason = "newly added", issue = "63168")]
    pub fn cloned(self) -> Result<T, E> {
        self.map(|t| t.clone())
    }
}

impl<T, E: fmt::Debug> Result<T, E> {
    /// Ibinabalik ang nilalaman na [`Ok`] na halaga, ubusin ang halagang `self`.
    ///
    /// # Panics
    ///
    /// Panics kung ang halaga ay isang [`Err`], na may isang mensahe na panic kasama ang naipasa na mensahe, at ang nilalaman ng [`Err`].
    ///
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```should_panic
    /// let x: Result<u32, &str> = Err("emergency failure");
    /// x.expect("Testing expect"); // panics with `Testing expect: emergency failure`
    /// ```
    ///
    #[inline]
    #[track_caller]
    #[stable(feature = "result_expect", since = "1.4.0")]
    pub fn expect(self, msg: &str) -> T {
        match self {
            Ok(t) => t,
            Err(e) => unwrap_failed(msg, &e),
        }
    }

    /// Ibinabalik ang nilalaman na [`Ok`] na halaga, ubusin ang halagang `self`.
    ///
    /// Dahil ang pagpapaandar na ito ay maaaring panic, ang paggamit nito sa pangkalahatan ay hindi pinanghihinaan ng loob.
    /// Sa halip, ginusto na gamitin ang pagtutugma ng pattern at hawakan nang malinaw ang kaso ng [`Err`], o tawagan ang [`unwrap_or`], [`unwrap_or_else`], o [`unwrap_or_default`].
    ///
    ///
    /// [`unwrap_or`]: Result::unwrap_or
    /// [`unwrap_or_else`]: Result::unwrap_or_else
    /// [`unwrap_or_default`]: Result::unwrap_or_default
    ///
    /// # Panics
    ///
    /// Panics kung ang halaga ay isang [`Err`], na may isang mensahe na panic na ibinigay ng halaga ng [Err`].
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(2);
    /// assert_eq!(x.unwrap(), 2);
    /// ```
    ///
    /// ```should_panic
    /// let x: Result<u32, &str> = Err("emergency failure");
    /// x.unwrap(); // panics with `emergency failure`
    /// ```
    ///
    ///
    ///
    #[inline]
    #[track_caller]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn unwrap(self) -> T {
        match self {
            Ok(t) => t,
            Err(e) => unwrap_failed("called `Result::unwrap()` on an `Err` value", &e),
        }
    }
}

impl<T: fmt::Debug, E> Result<T, E> {
    /// Ibinabalik ang nilalaman na [`Err`] na halaga, ubusin ang halagang `self`.
    ///
    /// # Panics
    ///
    /// Panics kung ang halaga ay isang [`Ok`], na may isang mensahe na panic kasama ang naipasa na mensahe, at ang nilalaman ng [`Ok`].
    ///
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```should_panic
    /// let x: Result<u32, &str> = Ok(10);
    /// x.expect_err("Testing expect_err"); // panics with `Testing expect_err: 10`
    /// ```
    ///
    #[inline]
    #[track_caller]
    #[stable(feature = "result_expect_err", since = "1.17.0")]
    pub fn expect_err(self, msg: &str) -> E {
        match self {
            Ok(t) => unwrap_failed(msg, &t),
            Err(e) => e,
        }
    }

    /// Ibinabalik ang nilalaman na [`Err`] na halaga, ubusin ang halagang `self`.
    ///
    /// # Panics
    ///
    /// Panics kung ang halaga ay isang [`Ok`], na may pasadyang mensahe ng panic na ibinigay ng halaga ng ['Ok`].
    ///
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// let x: Result<u32, &str> = Ok(2);
    /// x.unwrap_err(); // panics with `2`
    /// ```
    ///
    /// ```
    /// let x: Result<u32, &str> = Err("emergency failure");
    /// assert_eq!(x.unwrap_err(), "emergency failure");
    /// ```
    #[inline]
    #[track_caller]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn unwrap_err(self) -> E {
        match self {
            Ok(t) => unwrap_failed("called `Result::unwrap_err()` on an `Ok` value", &t),
            Err(e) => e,
        }
    }
}

impl<T: Default, E> Result<T, E> {
    /// Ibinabalik ang nilalaman na [`Ok`] na halaga o isang default
    ///
    /// Naubos ang argumentong `self` pagkatapos, kung [`Ok`], ibinalik ang nilalaman na nilalaman, kung hindi man kung [`Err`], ibabalik ang default na halaga para sa uri na iyon.
    ///
    ///
    /// # Examples
    ///
    /// Nagko-convert ng isang string sa isang integer, na ginagawang 0 (ang default na halaga para sa mga integer) ang mga string na hindi maganda ang nabuo na mga string.
    /// [`parse`] nagko-convert ng isang string sa anumang iba pang uri na nagpapatupad ng [`FromStr`], na nagbabalik ng isang [`Err`] sa error.
    ///
    /// ```
    /// let good_year_from_input = "1909";
    /// let bad_year_from_input = "190blarg";
    /// let good_year = good_year_from_input.parse().unwrap_or_default();
    /// let bad_year = bad_year_from_input.parse().unwrap_or_default();
    ///
    /// assert_eq!(1909, good_year);
    /// assert_eq!(0, bad_year);
    /// ```
    ///
    /// [`parse`]: str::parse
    /// [`FromStr`]: crate::str::FromStr
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "result_unwrap_or_default", since = "1.16.0")]
    pub fn unwrap_or_default(self) -> T {
        match self {
            Ok(x) => x,
            Err(_) => Default::default(),
        }
    }
}

#[unstable(feature = "unwrap_infallible", reason = "newly added", issue = "61695")]
impl<T, E: Into<!>> Result<T, E> {
    /// Ibinabalik ang nilalaman na [`Ok`] na halaga, ngunit hindi kailanman panics.
    ///
    /// Hindi tulad ng [`unwrap`], ang pamamaraang ito ay kilalang hindi kailanman panic sa mga uri ng resulta na ipinatupad nito.
    /// Samakatuwid, maaari itong magamit sa halip na `unwrap` bilang isang pangangalaga sa pagpapanatili na mabibigo sa pag-ipon kung ang uri ng error ng `Result` ay kalaunan ay binago sa isang error na maaaring mangyari.
    ///
    ///
    /// [`unwrap`]: Result::unwrap
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// # #![feature(never_type)]
    /// # #![feature(unwrap_infallible)]
    ///
    /// fn only_good_news() -> Result<String, !> {
    ///     Ok("this is fine".into())
    /// }
    ///
    /// let s: String = only_good_news().into_ok();
    /// println!("{}", s);
    /// ```
    ///
    ///
    #[inline]
    pub fn into_ok(self) -> T {
        match self {
            Ok(x) => x,
            Err(e) => e.into(),
        }
    }
}

impl<T: Deref, E> Result<T, E> {
    /// Nagko-convert mula `Result<T, E>` (o `&Result<T, E>`) hanggang `Result<&<T as Deref>::Target, &E>`.
    ///
    /// Pinipilit ang [`Ok`] variant ng orihinal na [`Result`] sa pamamagitan ng [`Deref`](crate::ops::Deref) at ibinabalik ang bagong [`Result`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x: Result<String, u32> = Ok("hello".to_string());
    /// let y: Result<&str, &u32> = Ok("hello");
    /// assert_eq!(x.as_deref(), y);
    ///
    /// let x: Result<String, u32> = Err(42);
    /// let y: Result<&str, &u32> = Err(&42);
    /// assert_eq!(x.as_deref(), y);
    /// ```
    #[stable(feature = "inner_deref", since = "1.47.0")]
    pub fn as_deref(&self) -> Result<&T::Target, &E> {
        self.as_ref().map(|t| t.deref())
    }
}

impl<T: DerefMut, E> Result<T, E> {
    /// Nagko-convert mula `Result<T, E>` (o `&mut Result<T, E>`) hanggang `Result<&mut <T as DerefMut>::Target, &mut E>`.
    ///
    /// Pinipilit ang [`Ok`] variant ng orihinal na [`Result`] sa pamamagitan ng [`DerefMut`](crate::ops::DerefMut) at ibinabalik ang bagong [`Result`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = "HELLO".to_string();
    /// let mut x: Result<String, u32> = Ok("hello".to_string());
    /// let y: Result<&mut str, &mut u32> = Ok(&mut s);
    /// assert_eq!(x.as_deref_mut().map(|x| { x.make_ascii_uppercase(); x }), y);
    ///
    /// let mut i = 42;
    /// let mut x: Result<String, u32> = Err(42);
    /// let y: Result<&mut str, &mut u32> = Err(&mut i);
    /// assert_eq!(x.as_deref_mut().map(|x| { x.make_ascii_uppercase(); x }), y);
    /// ```
    #[stable(feature = "inner_deref", since = "1.47.0")]
    pub fn as_deref_mut(&mut self) -> Result<&mut T::Target, &mut E> {
        self.as_mut().map(|t| t.deref_mut())
    }
}

impl<T, E> Result<Option<T>, E> {
    /// Transposes isang `Result` ng isang `Option` sa isang `Option` ng isang `Result`.
    ///
    /// `Ok(None)` mai-map sa `None`.
    /// `Ok(Some(_))` at ang `Err(_)` ay maima-map sa `Some(Ok(_))` at `Some(Err(_))`.
    ///
    /// # Examples
    ///
    /// ```
    /// #[derive(Debug, Eq, PartialEq)]
    /// struct SomeErr;
    ///
    /// let x: Result<Option<i32>, SomeErr> = Ok(Some(5));
    /// let y: Option<Result<i32, SomeErr>> = Some(Ok(5));
    /// assert_eq!(x.transpose(), y);
    /// ```
    #[inline]
    #[stable(feature = "transpose_result", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_result", issue = "82814")]
    pub const fn transpose(self) -> Option<Result<T, E>> {
        match self {
            Ok(Some(x)) => Some(Ok(x)),
            Ok(None) => None,
            Err(e) => Some(Err(e)),
        }
    }
}

impl<T, E> Result<Result<T, E>, E> {
    /// Mga nagko-convert mula `Result<Result<T, E>, E>` hanggang `Result<T, E>`
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// #![feature(result_flattening)]
    /// let x: Result<Result<&'static str, u32>, u32> = Ok(Ok("hello"));
    /// assert_eq!(Ok("hello"), x.flatten());
    ///
    /// let x: Result<Result<&'static str, u32>, u32> = Ok(Err(6));
    /// assert_eq!(Err(6), x.flatten());
    ///
    /// let x: Result<Result<&'static str, u32>, u32> = Err(6);
    /// assert_eq!(Err(6), x.flatten());
    /// ```
    ///
    /// Ang pag-flatt lang ay aalisin ang isang antas ng pamumugad nang paisa-isa:
    ///
    /// ```
    /// #![feature(result_flattening)]
    /// let x: Result<Result<Result<&'static str, u32>, u32>, u32> = Ok(Ok(Ok("hello")));
    /// assert_eq!(Ok(Ok("hello")), x.flatten());
    /// assert_eq!(Ok("hello"), x.flatten().flatten());
    /// ```
    #[inline]
    #[unstable(feature = "result_flattening", issue = "70142")]
    pub fn flatten(self) -> Result<T, E> {
        self.and_then(convert::identity)
    }
}

impl<T> Result<T, T> {
    /// Ibinabalik ang halagang [`Ok`] kung ang `self` ay `Ok`, at ang halagang [`Err`] kung `self` ay `Err`.
    ///
    /// Sa madaling salita, ibabalik ng pagpapaandar na ito ang halaga (ang `T`) ng isang `Result<T, T>`, hindi alintana kung ang resulta ay `Ok` o `Err`.
    ///
    /// Maaari itong maging kapaki-pakinabang kasabay ng mga API tulad ng [`Atomic*::compare_exchange`], o [`slice::binary_search`], ngunit sa mga kaso lamang kung saan wala kang pakialam kung ang resulta ay `Ok` o hindi.
    ///
    ///
    /// [`Atomic*::compare_exchange`]: crate::sync::atomic::AtomicBool::compare_exchange
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(result_into_ok_or_err)]
    /// let ok: Result<u32, u32> = Ok(3);
    /// let err: Result<u32, u32> = Err(4);
    ///
    /// assert_eq!(ok.into_ok_or_err(), 3);
    /// assert_eq!(err.into_ok_or_err(), 4);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "result_into_ok_or_err", reason = "newly added", issue = "82223")]
    pub const fn into_ok_or_err(self) -> T {
        match self {
            Ok(v) => v,
            Err(v) => v,
        }
    }
}

// Ito ay isang hiwalay na pagpapaandar upang mabawasan ang laki ng code ng mga pamamaraan
#[inline(never)]
#[cold]
#[track_caller]
fn unwrap_failed(msg: &str, error: &dyn fmt::Debug) -> ! {
    panic!("{}: {:?}", msg, error)
}

/////////////////////////////////////////////////////////////////////////////
// Pagpapatupad ng Trait
/////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone, E: Clone> Clone for Result<T, E> {
    #[inline]
    fn clone(&self) -> Self {
        match self {
            Ok(x) => Ok(x.clone()),
            Err(x) => Err(x.clone()),
        }
    }

    #[inline]
    fn clone_from(&mut self, source: &Self) {
        match (self, source) {
            (Ok(to), Ok(from)) => to.clone_from(from),
            (Err(to), Err(from)) => to.clone_from(from),
            (to, from) => *to = from.clone(),
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, E> IntoIterator for Result<T, E> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// Nagbabalik ng isang umuulit na iterator sa posibleng nilalaman na halaga.
    ///
    /// Nagbibigay ang iterator ng isang halaga kung ang resulta ay [`Result::Ok`], kung hindi man wala.
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(5);
    /// let v: Vec<u32> = x.into_iter().collect();
    /// assert_eq!(v, [5]);
    ///
    /// let x: Result<u32, &str> = Err("nothing!");
    /// let v: Vec<u32> = x.into_iter().collect();
    /// assert_eq!(v, []);
    /// ```
    #[inline]
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { inner: self.ok() }
    }
}

#[stable(since = "1.4.0", feature = "result_iter")]
impl<'a, T, E> IntoIterator for &'a Result<T, E> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(since = "1.4.0", feature = "result_iter")]
impl<'a, T, E> IntoIterator for &'a mut Result<T, E> {
    type Item = &'a mut T;
    type IntoIter = IterMut<'a, T>;

    fn into_iter(self) -> IterMut<'a, T> {
        self.iter_mut()
    }
}

/////////////////////////////////////////////////////////////////////////////
// Ang Mga Resulta ng Iterator
/////////////////////////////////////////////////////////////////////////////

/// Ang isang iterator sa loob ng isang reference sa [`Ok`] variant ng isang [`Result`].
///
/// Nagbibigay ang iterator ng isang halaga kung ang resulta ay [`Ok`], kung hindi man wala.
///
/// Nilikha ni [`Result::iter`].
#[derive(Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Iter<'a, T: 'a> {
    inner: Option<&'a T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for Iter<'a, T> {
    type Item = &'a T;

    #[inline]
    fn next(&mut self) -> Option<&'a T> {
        self.inner.take()
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let n = if self.inner.is_some() { 1 } else { 0 };
        (n, Some(n))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for Iter<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a T> {
        self.inner.take()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for Iter<'_, T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Iter<'_, T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A> TrustedLen for Iter<'_, A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Clone for Iter<'_, T> {
    #[inline]
    fn clone(&self) -> Self {
        Iter { inner: self.inner }
    }
}

/// Ang isang iterator sa loob ng isang mutable pagtukoy sa [`Ok`] variant ng isang [`Result`].
///
/// Nilikha ni [`Result::iter_mut`].
#[derive(Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct IterMut<'a, T: 'a> {
    inner: Option<&'a mut T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for IterMut<'a, T> {
    type Item = &'a mut T;

    #[inline]
    fn next(&mut self) -> Option<&'a mut T> {
        self.inner.take()
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let n = if self.inner.is_some() { 1 } else { 0 };
        (n, Some(n))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for IterMut<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a mut T> {
        self.inner.take()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for IterMut<'_, T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for IterMut<'_, T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A> TrustedLen for IterMut<'_, A> {}

/// Isang iterator sa paglipas ng halaga sa isang [`Ok`] variant ng isang [`Result`].
///
/// Nagbibigay ang iterator ng isang halaga kung ang resulta ay [`Ok`], kung hindi man wala.
///
/// Ang istrukturang ito ay nilikha ng pamamaraang [`into_iter`] sa [`Result`] (na ibinigay ng [`IntoIterator`] trait).
///
///
/// [`into_iter`]: IntoIterator::into_iter
#[derive(Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct IntoIter<T> {
    inner: Option<T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Iterator for IntoIter<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.inner.take()
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let n = if self.inner.is_some() { 1 } else { 0 };
        (n, Some(n))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> DoubleEndedIterator for IntoIter<T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.inner.take()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for IntoIter<T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for IntoIter<T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A> TrustedLen for IntoIter<A> {}

/////////////////////////////////////////////////////////////////////////////
// FromIterator
/////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, E, V: FromIterator<A>> FromIterator<Result<A, E>> for Result<V, E> {
    /// Kinukuha ang bawat elemento sa `Iterator`: kung ito ay isang `Err`, walang karagdagang mga elemento ang kukuha, at ang `Err` ay ibinalik.
    /// Hindi dapat maganap ang `Err`, isang container na may mga halaga ng bawat `Result` ay naibalik.
    ///
    /// Narito ang isang halimbawa kung saan palugit sa bawat integer sa isang vector, check para sa overflow:
    ///
    /// ```
    /// let v = vec![1, 2];
    /// let res: Result<Vec<u32>, &'static str> = v.iter().map(|x: &u32|
    ///     x.checked_add(1).ok_or("Overflow!")
    /// ).collect();
    /// assert_eq!(res, Ok(vec![2, 3]));
    /// ```
    ///
    /// Narito ang isa pang halimbawa na sumusubok na bawasan ang isa mula sa isa pang listahan ng mga integer, sa oras na ito suriin kung underflow:
    ///
    /// ```
    /// let v = vec![1, 2, 0];
    /// let res: Result<Vec<u32>, &'static str> = v.iter().map(|x: &u32|
    ///     x.checked_sub(1).ok_or("Underflow!")
    /// ).collect();
    /// assert_eq!(res, Err("Underflow!"));
    /// ```
    ///
    /// Narito ang isang pagkakaiba-iba sa nakaraang halimbawa, ipinapakita na walang karagdagang mga elemento ang kinuha mula sa `iter` pagkatapos ng unang `Err`.
    ///
    /// ```
    /// let v = vec![3, 2, 1, 10];
    /// let mut shared = 0;
    /// let res: Result<Vec<u32>, &'static str> = v.iter().map(|x: &u32| {
    ///     shared += x;
    ///     x.checked_sub(2).ok_or("Underflow!")
    /// }).collect();
    /// assert_eq!(res, Err("Underflow!"));
    /// assert_eq!(shared, 6);
    /// ```
    ///
    /// Dahil ang pangatlong elemento ay nagdulot ng isang underflow, walang karagdagang mga elemento ang kinuha, kaya ang huling halaga ng `shared` ay 6 (= `3 + 2 + 1`), hindi 16.
    ///
    ///
    ///
    ///
    ///
    #[inline]
    fn from_iter<I: IntoIterator<Item = Result<A, E>>>(iter: I) -> Result<V, E> {
        // FIXME(#11084): Maaari itong mapalitan ng Iterator::scan kapag ang pagganap ng bug ay sarado.
        //

        iter::process_results(iter.into_iter(), |i| i.collect())
    }
}

#[unstable(feature = "try_trait", issue = "42327")]
impl<T, E> ops::Try for Result<T, E> {
    type Ok = T;
    type Error = E;

    #[inline]
    fn into_result(self) -> Self {
        self
    }

    #[inline]
    fn from_ok(v: T) -> Self {
        Ok(v)
    }

    #[inline]
    fn from_error(v: E) -> Self {
        Err(v)
    }
}