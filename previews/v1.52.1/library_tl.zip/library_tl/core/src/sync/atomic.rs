//! Mga uri ng atomic
//!
//! Ang mga uri ng atomic ay nagbibigay ng primitive shared-memory na komunikasyon sa pagitan ng mga thread, at ang mga bloke ng iba pang mga kasabay na uri.
//!
//! Tinutukoy ng modyul na ito ang mga bersyon ng atomic ng isang piling bilang ng mga primitive na uri, kabilang ang [`AtomicBool`], [`AtomicIsize`], [`AtomicUsize`], [`AtomicI8`], [`AtomicU16`], atbp.
//! Atomic uri kasalukuyan operasyon na, kapag ginamit nang tama, synchronize mga update sa pagitan thread.
//!
//! Ang bawat pamamaraan ay tumatagal ng isang [`Ordering`] na kumakatawan sa lakas ng memory barrier para sa operasyon na iyon.Ang mga pag-order na ito ay pareho sa [C++20 atomic orderings][1].Para sa karagdagang impormasyon tingnan ang [nomicon][2].
//!
//! [1]: https://en.cppreference.com/w/cpp/atomic/memory_order
//! [2]: ../../../nomicon/atomics.html
//!
//! Ang mga variable ng atom ay ligtas na ibahagi sa pagitan ng mga thread (ipinatutupad nila ang [`Sync`]) ngunit hindi nila ibinigay ang kanilang mekanismo para sa pagbabahagi at sundin ang [threading model](../../../std/thread/index.html#the-threading-model) ng Rust.
//!
//! Ang pinaka-karaniwang paraan upang ibahagi ang isang atomic variable ay upang ilagay ito sa isang [`Arc`][arc] (isang atomically-reference-binibilang shared pointer).
//!
//! [arc]: ../../../std/sync/struct.Arc.html
//!
//! Ang mga uri ng atomic ay maaaring maiimbak sa mga static variable, isinisimulan gamit ang pare-pareho na mga initializer tulad ng [`AtomicBool::new`].Ang mga atomic statics ay madalas na ginagamit para sa tamad na pandaigdigang pagpapasimula.
//!
//! # Portability
//!
//! Lahat ng mga uri ng atomic sa modyul na ito ay garantisadong maging [lock-free] kung magagamit sila.Nangangahulugan ito na hindi sila panloob na nakakakuha ng isang pandaigdigang mutex.Ang mga uri at operasyon ng atomiko ay hindi ginagarantiyahan na maging walang hintay.
//! Nangangahulugan ito na ang mga pagpapatakbo tulad ng `fetch_or` ay maaaring ipatupad sa pamamagitan ng isang kumpara sa isang kumpas na loop.
//!
//! Ang pagpapatakbo ng atomic ay maaaring ipatupad sa layer ng pagtuturo na may mas malaking sukat na mga atomika.Halimbawa ang ilang mga platform ay gumagamit ng mga 4-byte atomic na tagubilin upang ipatupad ang `AtomicI8`.
//! Tandaan na ang pagtulad na ito ay hindi dapat magkaroon ng isang epekto sa kawastuhan ng code, ito ay isang bagay lamang na dapat magkaroon ng kamalayan.
//!
//! Ang mga uri ng atomic sa modyul na ito ay maaaring hindi magagamit sa lahat ng mga platform.Ang mga uri ng atomiko dito ay magagamit ng lahat, subalit, at sa pangkalahatan ay maaasahan sa mayroon.Ang ilang taong litaw eksepsiyon ay ang mga:
//!
//! * PowerPC at MIPS platform na may 32-bit mga payo ay hindi na `AtomicU64` o `AtomicI64` uri.
//! * ARM platform tulad `armv5te` na hindi para sa Linux lamang magbigay `load` at `store` pagpapatakbo, at ay hindi sumusuporta Ihambing at Swap (CAS) operasyon, tulad ng `swap`, `fetch_add`, etc.
//! Bilang karagdagan sa Linux, ang mga pagpapatakbo ng CAS na ito ay ipinatupad sa pamamagitan ng [operating system support], na maaaring may parusa sa pagganap.
//! * ARM ang mga target na may `thumbv6m` ay nagbibigay lamang ng mga pagpapatakbo ng `load` at `store`, at hindi sinusuportahan ang operasyon ng Compare at Swap (CAS), tulad ng `swap`, `fetch_add`, atbp.
//!
//! [operating system support]: https://www.kernel.org/doc/Documentation/arm/kernel_user_helpers.txt
//!
//! Tandaan na ang mga platform ng future ay maaaring idagdag na wala ring suporta para sa ilang mga pagpapatakbo ng atomic.Maximally portable code ay nais na maging maingat tungkol sa kung aling mga uri ng atomic ang ginagamit.
//! `AtomicUsize` at `AtomicIsize` sa pangkalahatan ay ang pinaka portable, ngunit kahit na hindi sila magagamit kahit saan.
//! Para sa sanggunian, ang `std` library ay nangangailangan ng mga atomic na kasing laki ng pointer, kahit na ang `core` ay hindi.
//!
//! Sa kasalukuyan kakailanganin mong gamitin `#[cfg(target_arch)]` lalo na sa pasubali sumulat ng libro sa code sa atomics.Mayroong isang hindi matatag na `#[cfg(target_has_atomic)]` din na maaaring maging matatag sa future.
//!
//! [lock-free]: https://en.wikipedia.org/wiki/Non-blocking_algorithm
//!
//! # Examples
//!
//! Isang simpleng spinlock:
//!
//! ```
//! use std::sync::Arc;
//! use std::sync::atomic::{AtomicUsize, Ordering};
//! use std::thread;
//!
//! fn main() {
//!     let spinlock = Arc::new(AtomicUsize::new(1));
//!
//!     let spinlock_clone = Arc::clone(&spinlock);
//!     let thread = thread::spawn(move|| {
//!         spinlock_clone.store(0, Ordering::SeqCst);
//!     });
//!
//!     // Hintayin ang ibang thread na palabasin ang lock
//!     while spinlock.load(Ordering::SeqCst) != 0 {}
//!
//!     if let Err(panic) = thread.join() {
//!         println!("Thread had an error: {:?}", panic);
//!     }
//! }
//! ```
//!
//! Panatilihin ang isang pandaigdigang bilang ng mga live na thread:
//!
//! ```
//! use std::sync::atomic::{AtomicUsize, Ordering};
//!
//! static GLOBAL_THREAD_COUNT: AtomicUsize = AtomicUsize::new(0);
//!
//! let old_thread_count = GLOBAL_THREAD_COUNT.fetch_add(1, Ordering::SeqCst);
//! println!("live threads: {}", old_thread_count + 1);
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]
#![cfg_attr(not(target_has_atomic_load_store = "8"), allow(dead_code))]
#![cfg_attr(not(target_has_atomic_load_store = "8"), allow(unused_imports))]

use self::Ordering::*;

use crate::cell::UnsafeCell;
use crate::fmt;
use crate::intrinsics;

use crate::hint::spin_loop;

/// Ang isang boolean uri na maaaring ligtas na nakabahagi sa pagitan ng mga thread.
///
/// Ang uri na ito ay may parehong in-memory na representasyon bilang isang [`bool`].
///
/// **Tandaan**: Magagamit lamang ang ganitong uri sa mga platform na sumusuporta sa mga pag-load ng atomic at mga tindahan ng `u8`.
///
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(C, align(1))]
pub struct AtomicBool {
    v: UnsafeCell<u8>,
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
impl Default for AtomicBool {
    /// Lumilikha ng isang `AtomicBool` na pinasimulan sa `false`.
    #[inline]
    fn default() -> Self {
        Self::new(false)
    }
}

// Ipadala ang implicit na ipinatupad para sa AtomicBool.
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl Sync for AtomicBool {}

/// Isang hilaw na uri ng pointer na maaaring ligtas na maibahagi sa pagitan ng mga thread.
///
/// Ang uri na ito ay may parehong representasyon in-memorya bilang `*mut T`.
///
/// **Tandaan**: Magagamit lamang ang ganitong uri sa mga platform na sumusuporta sa mga pag-load ng atomic at mga tindahan ng mga payo.
/// Ang laki nito ay nakasalalay sa laki ng target na pointer.
#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(target_pointer_width = "16", repr(C, align(2)))]
#[cfg_attr(target_pointer_width = "32", repr(C, align(4)))]
#[cfg_attr(target_pointer_width = "64", repr(C, align(8)))]
pub struct AtomicPtr<T> {
    p: UnsafeCell<*mut T>,
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for AtomicPtr<T> {
    /// Lumilikha ng isang null `AtomicPtr<T>`.
    fn default() -> AtomicPtr<T> {
        AtomicPtr::new(crate::ptr::null_mut())
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T> Send for AtomicPtr<T> {}
#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T> Sync for AtomicPtr<T> {}

/// Mga pag-order ng memorya ng atom
///
/// Memory orderings tukuyin ang paraan atomic operasyon i-synchronize ang memory.
/// Sa pinakamahina nitong [`Ordering::Relaxed`], ang memorya lamang na direktang hinawakan ng operasyon ang na-synchronize.
/// Sa kabilang banda, ang isang pares ng store-load ng mga pagpapatakbo ng [`Ordering::SeqCst`] ay nagsi-synchronize ng iba pang memorya habang karagdagan pinapanatili ang isang kabuuang pagkakasunud-sunod ng mga naturang pagpapatakbo sa lahat ng mga thread.
///
///
/// Ang mga pag-order ng memorya ng Rust ay [the same as those of C++20](https://en.cppreference.com/w/cpp/atomic/memory_order).
///
/// Para sa karagdagang impormasyon tingnan ang [nomicon].
///
/// [nomicon]: ../../../nomicon/atomics.html
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone, Debug, Eq, PartialEq, Hash)]
#[non_exhaustive]
pub enum Ordering {
    /// Walang mga hadlang sa pag-order, mga pagpapatakbo lamang ng atomic.
    ///
    /// Naaayon sa [`memory_order_relaxed`] sa C++ 20.
    ///
    /// [`memory_order_relaxed`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Relaxed_ordering
    #[stable(feature = "rust1", since = "1.0.0")]
    Relaxed,
    /// Kapag isinama sa isang tindahan, ang lahat ng mga nakaraang pagpapatakbo ay nai-order bago ang anumang pag-load ng halagang ito sa [`Acquire`] (o mas malakas) na pag-order.
    ///
    /// Sa partikular, ang lahat ng nakaraang mga writes makikita ng lahat ng mga thread na magsagawa ng isang [`Acquire`] (o malakas) pag-load ng halagang ito.
    ///
    /// Pansinin na paggamit ng pag-order para sa isang operasyon na pinagsasama naglo-load at mga tindahan ng mga lead sa isang load operasyon [`Relaxed`]!
    ///
    /// pag-order na ito ay naaangkop lamang para sa mga operasyon na maaaring gumanap sa isang store.
    ///
    /// Naaayon sa [`memory_order_release`] sa C++ 20.
    ///
    /// [`memory_order_release`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    Release,
    /// Kapag isinama sa isang pag-load, kung ang na-load na halaga ay isinulat ng isang operasyon ng tindahan na may [`Release`] (o mas malakas) na pag-order, kung gayon ang lahat ng kasunod na pagpapatakbo ay nai-order pagkatapos ng store na iyon.
    /// Sa partikular, ang lahat ng kasunod na paglo-load ay makakakita ng data na nakasulat bago ang tindahan.
    ///
    /// Pansinin na paggamit ng pag-order para sa isang operasyon na pinagsasama naglo-load at mga tindahan leads sa isang operasyon [`Relaxed`] store!
    ///
    /// Nalalapat lamang ang pag-order na ito para sa mga pagpapatakbo na maaaring magsagawa ng isang pagkarga.
    ///
    /// Naaayon sa [`memory_order_acquire`] sa C++ 20.
    ///
    /// [`memory_order_acquire`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    Acquire,
    /// Ay may mga epekto ng parehong [`Acquire`] at [`Release`]-sama:
    /// Para sa mga naglo-load ito ay gumagamit [`Acquire`] pag-order.Para sa mga tindahan ginagamit nito ang pag-order ng [`Release`].
    ///
    /// Pansinin na sa kaso ng `compare_and_swap`, posible na ang operasyon ay natapos na hindi gumaganap ng anumang tindahan at samakatuwid mayroon lamang itong [`Acquire`] na pag-order.
    ///
    /// Gayunman, `AcqRel` hindi kailanman gumanap [`Relaxed`] access.
    ///
    /// Nalalapat lamang ang pag-order na ito para sa mga pagpapatakbo na nagsasama sa parehong pag-load at mga tindahan.
    ///
    /// Naaayon sa [`memory_order_acq_rel`] sa C++ 20.
    ///
    /// [`memory_order_acq_rel`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    #[stable(feature = "rust1", since = "1.0.0")]
    AcqRel,
    /// Tulad ng [`Acquire`]/[`Bitawan`]/[`AcqRel`](para sa mga pagpapatakbo ng pag-load, pag-iimbak, at pag-load na may tindahan, ayon sa pagkakabanggit) na may karagdagang garantiya na makita ng lahat ng mga thread ang lahat ng sunud-sunod na mga pagpapatakbo sa parehong pagkakasunud-sunod .
    ///
    ///
    /// Naaayon sa [`memory_order_seq_cst`] sa C++ 20.
    ///
    /// [`memory_order_seq_cst`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Sequentially-consistent_ordering
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    SeqCst,
}

/// Isang [`AtomicBool`] na pinasimulan sa `false`.
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "1.34.0",
    reason = "the `new` function is now preferred",
    suggestion = "AtomicBool::new(false)"
)]
pub const ATOMIC_BOOL_INIT: AtomicBool = AtomicBool::new(false);

#[cfg(target_has_atomic_load_store = "8")]
impl AtomicBool {
    /// Lumilikha ng isang bagong `AtomicBool`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    ///
    /// let atomic_true  = AtomicBool::new(true);
    /// let atomic_false = AtomicBool::new(false);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_atomic_new", since = "1.32.0")]
    pub const fn new(v: bool) -> AtomicBool {
        AtomicBool { v: UnsafeCell::new(v as u8) }
    }

    /// Ibinabalik maaaring mabago ng isang reference sa napapailalim na [`bool`].
    ///
    /// Ito ay ligtas sapagkat ang nababagabagong sanggunian ay ginagarantiyahan na walang iba pang mga thread na sabay-sabay na na-access ang data ng atomic.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let mut some_bool = AtomicBool::new(true);
    /// assert_eq!(*some_bool.get_mut(), true);
    /// *some_bool.get_mut() = false;
    /// assert_eq!(some_bool.load(Ordering::SeqCst), false);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    pub fn get_mut(&mut self) -> &mut bool {
        // KALIGTASAN: ginagarantiyahan ng nababagong sanggunian ang natatanging pagmamay-ari.
        unsafe { &mut *(self.v.get() as *mut bool) }
    }

    /// Kumuha ng pag-access ng atomic sa isang `&mut bool`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(atomic_from_mut)]
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let mut some_bool = true;
    /// let a = AtomicBool::from_mut(&mut some_bool);
    /// a.store(false, Ordering::Relaxed);
    /// assert_eq!(some_bool, false);
    /// ```
    #[inline]
    #[cfg(target_has_atomic_equal_alignment = "8")]
    #[unstable(feature = "atomic_from_mut", issue = "76314")]
    pub fn from_mut(v: &mut bool) -> &Self {
        // KALIGTASAN: ang mutable reference tinitiyak natatanging pagmamay-ari, at
        // ang pagkakahanay ng parehong `bool` at `Self` ay 1.
        unsafe { &*(v as *mut bool as *mut Self) }
    }

    /// Naubos ang atomic at ibinabalik ang nilalaman na nilalaman.
    ///
    /// Ito ay ligtas dahil ang pagpasa sa `self` ayon sa halaga ay ginagarantiyahan na walang iba pang mga thread na sabay-sabay na na-access ang data ng atomic.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    ///
    /// let some_bool = AtomicBool::new(true);
    /// assert_eq!(some_bool.into_inner(), true);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> bool {
        self.v.into_inner() != 0
    }

    /// Naglo-load ng isang halaga mula sa bool.
    ///
    /// `load` tumatagal ng isang argumentong [`Ordering`] na naglalarawan sa pag-order ng memorya ng operasyong ito.
    /// Ang mga posibleng halaga ay [`SeqCst`], [`Acquire`] at [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics kung `order` ay [`Release`] o [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.load(Ordering::Relaxed), true);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn load(&self, order: Ordering) -> bool {
        // KALIGTASAN: ang anumang mga karera ng data ay pinipigilan ng mga atomic intrinsics at ang hilaw
        // pointer ipinasa sa ay may-bisa dahil nakuha namin ito mula sa isang sanggunian.
        unsafe { atomic_load(self.v.get(), order) != 0 }
    }

    /// Nag-iimbak ng isang halaga sa bool.
    ///
    /// `store` tumatagal ng isang argumentong [`Ordering`] na naglalarawan sa pag-order ng memorya ng operasyong ito.
    /// Ang mga posibleng halaga ay [`SeqCst`], [`Release`] at [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics kung `order` ay [`Acquire`] o [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// some_bool.store(false, Ordering::Relaxed);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn store(&self, val: bool, order: Ordering) {
        // KALIGTASAN: ang anumang mga karera ng data ay pinipigilan ng mga atomic intrinsics at ang hilaw
        // pointer ipinasa sa ay may-bisa dahil nakuha namin ito mula sa isang sanggunian.
        unsafe {
            atomic_store(self.v.get(), val as u8, order);
        }
    }

    /// Nag-iimbak ng halaga sa bool, na binabalik ang dating halaga.
    ///
    /// `swap` tumatagal ng isang argumentong [`Ordering`] na naglalarawan sa pag-order ng memorya ng operasyong ito.Posible ang lahat ng mga mode sa pag-order.
    /// Tandaan na ang paggamit ng [`Acquire`] ay gumagawa ng bahagi ng tindahan ng operasyong [`Relaxed`] na ito, at ang paggamit ng [`Release`] ay gumagawa ng bahagi ng pag-load na [`Relaxed`].
    ///
    ///
    /// **Note:** Magagamit lamang ang pamamaraang ito sa mga platform na sumusuporta sa mga pagpapatakbo ng atomic sa `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.swap(false, Ordering::Relaxed), true);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn swap(&self, val: bool, order: Ordering) -> bool {
        // KALIGTASAN: ang mga karera ng data ay pinipigilan ng mga atomic intrinsics.
        unsafe { atomic_swap(self.v.get(), val as u8, order) != 0 }
    }

    /// Nag-iimbak ng isang halaga sa [`bool`] kung ang kasalukuyang halaga ay pareho ng halagang `current`.
    ///
    /// Ang halaga ng pagbabalik ay palaging ang dating halaga.Kung ito ay katumbas ng `current`, pagkatapos ay na-update ang halaga.
    ///
    /// `compare_and_swap` tumatagal din ng isang [`Ordering`] argument na naglalarawan sa pag-order ng memorya ng operasyong ito.
    /// Pansinin na kahit na kapag gumagamit ng [`AcqRel`], ang operasyon ay maaaring mabibigo at samakatuwid lamang magsagawa ng isang `Acquire` load, ngunit hindi magkaroon ng `Release` semantics.
    /// Paggamit [`Acquire`] gumagawa store bahagi ng operasyon [`Relaxed`] kung ito ang mangyayari, at paggamit ng [`Release`] gumagawa ng pag-load na bahagi [`Relaxed`].
    ///
    /// **Note:** Magagamit lamang ang pamamaraang ito sa mga platform na sumusuporta sa mga pagpapatakbo ng atomic sa `u8`.
    ///
    /// # Ang paglipat sa `compare_exchange` at `compare_exchange_weak`
    ///
    /// `compare_and_swap` ay katumbas ng `compare_exchange` na may mga sumusunod na pagmamapa para sa pag-order ng memorya:
    ///
    /// Orihinal |Tagumpay |Pagkabigo
    /// -------- | ------- | -------
    /// Nakakarelaks |Nakakarelaks |Nakakarelaks na Kumuha |Kumuha ng |Kumuha ng Pakawalan |Pakawalan |Nakakarelaks na AcqRel |AcqRel |Kumuha ng SeqCst |SeqCst |SeqCst
    ///
    /// `compare_exchange_weak` ay pinahihintulutang mabigo nang mabuti kahit na magtagumpay ang paghahambing, na nagbibigay-daan sa tagatala upang makabuo ng mas mahusay na code ng pagpupulong kung ang paghahambing at pagpapalit ay ginagamit sa isang loop.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.compare_and_swap(true, false, Ordering::Relaxed), true);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    ///
    /// assert_eq!(some_bool.compare_and_swap(true, true, Ordering::Relaxed), false);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.50.0",
        reason = "Use `compare_exchange` or `compare_exchange_weak` instead"
    )]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_and_swap(&self, current: bool, new: bool, order: Ordering) -> bool {
        match self.compare_exchange(current, new, order, strongest_failure_ordering(order)) {
            Ok(x) => x,
            Err(x) => x,
        }
    }

    /// Nag-iimbak ng isang halaga sa [`bool`] kung ang kasalukuyang halaga ay pareho ng halagang `current`.
    ///
    /// Ang halaga ng pagbabalik ay isang resulta na nagpapahiwatig kung ang bagong halaga ay nakasulat at naglalaman ng nakaraang halaga.
    /// Sa tagumpay ang halaga na ito ay garantisadong upang maging katumbas ng `current`.
    ///
    /// `compare_exchange` ay tumatagal ng dalawang [`Ordering`] argumento upang ilarawan ang memory na pag-order ng pagpapatakbong ito.
    /// `success` inilalarawan ang kinakailangang pag-order para sa operasyon na basahin-baguhin-isulat na magaganap kung magtagumpay ang paghahambing sa `current`.
    /// `failure` naglalarawan ng kinakailangang pag-order para sa pagpapatakbo ng pag-load na nagaganap kapag nabigo ang paghahambing.
    /// Ang paggamit ng [`Acquire`] bilang tagumpay sa pag-order ay ginagawang bahagi ng tindahan ng operasyong ito [`Relaxed`], at ang paggamit ng [`Release`] ay ginagawang matagumpay ang pagkarga ng [`Relaxed`].
    ///
    /// Ang pagkakasunud-sunod ng kabiguan ay maaari lamang maging [`SeqCst`], [`Acquire`] o [`Relaxed`] at dapat na katumbas o mas mahina kaysa sa pag-order ng tagumpay.
    ///
    /// **Note:** Magagamit lamang ang pamamaraang ito sa mga platform na sumusuporta sa mga pagpapatakbo ng atomic sa `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.compare_exchange(true,
    ///                                       false,
    ///                                       Ordering::Acquire,
    ///                                       Ordering::Relaxed),
    ///            Ok(true));
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    ///
    /// assert_eq!(some_bool.compare_exchange(true, true,
    ///                                       Ordering::SeqCst,
    ///                                       Ordering::Acquire),
    ///            Err(false));
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[doc(alias = "compare_and_swap")]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_exchange(
        &self,
        current: bool,
        new: bool,
        success: Ordering,
        failure: Ordering,
    ) -> Result<bool, bool> {
        // KALIGTASAN: ang mga karera ng data ay pinipigilan ng mga atomic intrinsics.
        match unsafe {
            atomic_compare_exchange(self.v.get(), current as u8, new as u8, success, failure)
        } {
            Ok(x) => Ok(x != 0),
            Err(x) => Err(x != 0),
        }
    }

    /// Nag-iimbak ng isang halaga sa [`bool`] kung ang kasalukuyang halaga ay pareho ng halagang `current`.
    ///
    /// Hindi tulad ng [`AtomicBool::compare_exchange`], function na ito ay pinahihintulutang ay huwad na mabibigo kahit na kapag ang paghahambing magtagumpay, na kung saan ay maaaring magresulta sa mas mahusay na code sa ilang mga platform.
    ///
    /// Ang halaga ng pagbabalik ay isang resulta na nagpapahiwatig kung ang bagong halaga ay nakasulat at naglalaman ng nakaraang halaga.
    ///
    /// `compare_exchange_weak` ay tumatagal ng dalawang [`Ordering`] argumento upang ilarawan ang memory na pag-order ng pagpapatakbong ito.
    /// `success` inilalarawan ang kinakailangang pag-order para sa operasyon na basahin-baguhin-isulat na magaganap kung magtagumpay ang paghahambing sa `current`.
    /// `failure` naglalarawan ng kinakailangang pag-order para sa pagpapatakbo ng pag-load na nagaganap kapag nabigo ang paghahambing.
    /// Ang paggamit ng [`Acquire`] bilang tagumpay sa pag-order ay ginagawang bahagi ng tindahan ng operasyong ito [`Relaxed`], at ang paggamit ng [`Release`] ay ginagawang matagumpay ang pagkarga ng [`Relaxed`].
    /// Ang pagkakasunud-sunod ng kabiguan ay maaari lamang maging [`SeqCst`], [`Acquire`] o [`Relaxed`] at dapat na katumbas o mas mahina kaysa sa pag-order ng tagumpay.
    ///
    /// **Note:** Magagamit lamang ang pamamaraang ito sa mga platform na sumusuporta sa mga pagpapatakbo ng atomic sa `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let val = AtomicBool::new(false);
    ///
    /// let new = true;
    /// let mut old = val.load(Ordering::Relaxed);
    /// loop {
    ///     match val.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) {
    ///         Ok(_) => break,
    ///         Err(x) => old = x,
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[doc(alias = "compare_and_swap")]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_exchange_weak(
        &self,
        current: bool,
        new: bool,
        success: Ordering,
        failure: Ordering,
    ) -> Result<bool, bool> {
        // KALIGTASAN: ang mga karera ng data ay pinipigilan ng mga atomic intrinsics.
        match unsafe {
            atomic_compare_exchange_weak(self.v.get(), current as u8, new as u8, success, failure)
        } {
            Ok(x) => Ok(x != 0),
            Err(x) => Err(x != 0),
        }
    }

    /// Lohikal na "and" na may halaga ng boolean.
    ///
    /// Nagsasagawa ng isang lohikal na pagpapatakbo ng "and" sa kasalukuyang halaga at ang argumentong `val`, at itinatakda ang bagong halaga sa resulta.
    ///
    /// Ibinabalik ang dating halaga.
    ///
    /// `fetch_and` tumatagal ng isang argumentong [`Ordering`] na naglalarawan sa pag-order ng memorya ng operasyong ito.Posible ang lahat ng mga mode sa pag-order.
    /// Tandaan na ang paggamit ng [`Acquire`] ay gumagawa ng bahagi ng tindahan ng operasyong [`Relaxed`] na ito, at ang paggamit ng [`Release`] ay gumagawa ng bahagi ng pag-load na [`Relaxed`].
    ///
    ///
    /// **Note:** Magagamit lamang ang pamamaraang ito sa mga platform na sumusuporta sa mga pagpapatakbo ng atomic sa `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_and(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_and(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_and(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_and(&self, val: bool, order: Ordering) -> bool {
        // KALIGTASAN: ang mga karera ng data ay pinipigilan ng mga atomic intrinsics.
        unsafe { atomic_and(self.v.get(), val as u8, order) != 0 }
    }

    /// Lohikal na "nand" na may halaga ng boolean.
    ///
    /// Nagsasagawa isang lohikal "nand" operasyon sa kasalukuyang halaga at ang argument `val`, at mga hanay ng mga bagong halaga sa resulta.
    ///
    /// Ibinabalik ang dating halaga.
    ///
    /// `fetch_nand` tumatagal ng isang argumentong [`Ordering`] na naglalarawan sa pag-order ng memorya ng operasyong ito.Posible ang lahat ng mga mode sa pag-order.
    /// Tandaan na ang paggamit ng [`Acquire`] ay gumagawa ng bahagi ng tindahan ng operasyong [`Relaxed`] na ito, at ang paggamit ng [`Release`] ay gumagawa ng bahagi ng pag-load na [`Relaxed`].
    ///
    ///
    /// **Note:** Magagamit lamang ang pamamaraang ito sa mga platform na sumusuporta sa mga pagpapatakbo ng atomic sa `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_nand(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_nand(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst) as usize, 0);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_nand(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_nand(&self, val: bool, order: Ordering) -> bool {
        // Hindi namin maaaring gamitin atomic_nand dito dahil maaari itong magresulta sa isang bool sa di-wastong halaga.
        // Nangyayari ito dahil ang operasyon ng atomic ay tapos na sa isang 8-bit integer sa loob, na magtatakda sa itaas na 7 bits.
        //
        // Kaya gumagamit na lamang kami ng fetch_xor o pagpapalit sa halip.
        if val {
            // ! (x&true)== !x Dapat nating baligtarin ang bool.
            //
            self.fetch_xor(true, order)
        } else {
            // ! (X&false)==true Kailangan naming i-set ang bool na totoo.
            //
            self.swap(true, order)
        }
    }

    /// Lohikal na "or" na may halaga ng boolean.
    ///
    /// Nagsasagawa ng isang lohikal na pagpapatakbo ng "or" sa kasalukuyang halaga at ang argumentong `val`, at itinatakda ang bagong halaga sa resulta.
    ///
    /// Ibinabalik ang dating halaga.
    ///
    /// `fetch_or` tumatagal ng isang argumentong [`Ordering`] na naglalarawan sa pag-order ng memorya ng operasyong ito.Posible ang lahat ng mga mode sa pag-order.
    /// Tandaan na ang paggamit ng [`Acquire`] ay gumagawa ng bahagi ng tindahan ng operasyong [`Relaxed`] na ito, at ang paggamit ng [`Release`] ay gumagawa ng bahagi ng pag-load na [`Relaxed`].
    ///
    ///
    /// **Note:** Magagamit lamang ang pamamaraang ito sa mga platform na sumusuporta sa mga pagpapatakbo ng atomic sa `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_or(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_or(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_or(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_or(&self, val: bool, order: Ordering) -> bool {
        // KALIGTASAN: ang mga karera ng data ay pinipigilan ng mga atomic intrinsics.
        unsafe { atomic_or(self.v.get(), val as u8, order) != 0 }
    }

    /// Lohikal na "xor" na may halaga ng boolean.
    ///
    /// Nagsasagawa ng isang lohikal na pagpapatakbo ng "xor" sa kasalukuyang halaga at ang argumentong `val`, at itinatakda ang bagong halaga sa resulta.
    ///
    /// Ibinabalik ang dating halaga.
    ///
    /// `fetch_xor` tumatagal ng isang argumentong [`Ordering`] na naglalarawan sa pag-order ng memorya ng operasyong ito.Posible ang lahat ng mga mode sa pag-order.
    /// Tandaan na ang paggamit ng [`Acquire`] ay gumagawa ng bahagi ng tindahan ng operasyong [`Relaxed`] na ito, at ang paggamit ng [`Release`] ay gumagawa ng bahagi ng pag-load na [`Relaxed`].
    ///
    ///
    /// **Note:** Magagamit lamang ang pamamaraang ito sa mga platform na sumusuporta sa mga pagpapatakbo ng atomic sa `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_xor(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_xor(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_xor(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_xor(&self, val: bool, order: Ordering) -> bool {
        // KALIGTASAN: ang mga karera ng data ay pinipigilan ng mga atomic intrinsics.
        unsafe { atomic_xor(self.v.get(), val as u8, order) != 0 }
    }

    /// Ibinabalik maaaring mabago ng isang pointer sa napapailalim na [`bool`].
    ///
    /// Ang paggawa ng mga di-atomic bumabasa at writes sa mga nagresultang integer ay maaaring maging isang data lahi.
    /// Ang pamamaraang ito ay higit na kapaki-pakinabang para sa FFI, kung saan maaaring magamit ng signature ng pagpapaandar ang `*mut bool` sa halip na `&AtomicBool`.
    ///
    /// Ang pagbabalik ng isang `*mut` pointer mula sa isang nakabahaging sanggunian sa atomic na ito ay ligtas dahil gumagana ang mga uri ng atomic na may interior mutability.
    /// Ang lahat ng mga pagbabago ng isang atomic ay nagbabago ng halaga sa pamamagitan ng isang nakabahaging sanggunian, at maaaring gawin ito nang ligtas hangga't gumagamit sila ng mga atomic na operasyon.
    /// Ang anumang paggamit ng naibalik na hilaw na pointer ay nangangailangan ng isang `unsafe` block at kailangan pang panatilihin ang parehong paghihigpit: ang mga operasyon dito ay dapat na atomic.
    ///
    ///
    /// # Examples
    ///
    /// ```ignore (extern-declaration)
    /// # fn main() {
    /// use std::sync::atomic::AtomicBool;
    /// extern "C" {
    ///     fn my_atomic_op(arg: *mut bool);
    /// }
    ///
    /// let mut atomic = AtomicBool::new(true);
    /// unsafe {
    ///     my_atomic_op(atomic.as_mut_ptr());
    /// }
    /// # }
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_mut_ptr", reason = "recently added", issue = "66893")]
    pub fn as_mut_ptr(&self) -> *mut bool {
        self.v.get() as *mut bool
    }

    /// Kinukuha ang halaga, at naglalapat ng isang pagpapaandar dito na nagbabalik ng isang opsyonal na bagong halaga.Ibinabalik ang isang `Result` ng `Ok(previous_value)` kung ang pagpapaandar ay bumalik sa `Some(_)`, iba pa `Err(previous_value)`.
    ///
    /// Note: Maaari nitong tawagan ang pag-andar ng maraming beses kung ang halaga ay nabago mula sa iba pang mga thread pansamantala, hangga't ibabalik ng pagpapaandar ang `Some(_)`, ngunit ang pagpapaandar ay maiilapat lamang nang isang beses sa nakaimbak na halaga.
    ///
    ///
    /// `fetch_update` ay tumatagal ng dalawang [`Ordering`] argumento upang ilarawan ang memory na pag-order ng pagpapatakbong ito.
    /// Inilalarawan ng una ang kinakailangang pag-order para kailan magtagumpay ang operasyon habang ang pangalawa ay naglalarawan ng kinakailangang pag-order para sa mga karga.
    /// Ang mga ay tumutugma sa mga tagumpay at kabiguan ayos [`AtomicBool::compare_exchange`] ayon sa pagkakabanggit.
    ///
    /// Paggamit [`Acquire`] pati na tagumpay sa pag-order ay gumagawa store bahagi ng operasyon [`Relaxed`], at paggamit ng [`Release`] gumagawa ng pangwakas na tagumpay load [`Relaxed`].
    /// Ang pag-order ng pag-load ng (failed) ay maaari lamang [`SeqCst`], [`Acquire`] o [`Relaxed`] at dapat na katumbas o mas mahina kaysa sa pag-order ng tagumpay.
    ///
    /// **Note:** Magagamit lamang ang pamamaraang ito sa mga platform na sumusuporta sa mga pagpapatakbo ng atomic sa `u8`.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(atomic_fetch_update)]
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let x = AtomicBool::new(false);
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(false));
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| Some(!x)), Ok(false));
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| Some(!x)), Ok(true));
    /// assert_eq!(x.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_fetch_update", reason = "recently added", issue = "78639")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_update<F>(
        &self,
        set_order: Ordering,
        fetch_order: Ordering,
        mut f: F,
    ) -> Result<bool, bool>
    where
        F: FnMut(bool) -> Option<bool>,
    {
        let mut prev = self.load(fetch_order);
        while let Some(next) = f(prev) {
            match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                x @ Ok(_) => return x,
                Err(next_prev) => prev = next_prev,
            }
        }
        Err(prev)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
impl<T> AtomicPtr<T> {
    /// Lumilikha ng isang bagong `AtomicPtr`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicPtr;
    ///
    /// let ptr = &mut 5;
    /// let atomic_ptr  = AtomicPtr::new(ptr);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_atomic_new", since = "1.32.0")]
    pub const fn new(p: *mut T) -> AtomicPtr<T> {
        AtomicPtr { p: UnsafeCell::new(p) }
    }

    /// Nagbabalik ng isang nababagong sanggunian sa pinagbabatayan na pointer.
    ///
    /// Ito ay ligtas sapagkat ang nababagabagong sanggunian ay ginagarantiyahan na walang iba pang mga thread na sabay-sabay na na-access ang data ng atomic.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let mut atomic_ptr = AtomicPtr::new(&mut 10);
    /// *atomic_ptr.get_mut() = &mut 5;
    /// assert_eq!(unsafe { *atomic_ptr.load(Ordering::SeqCst) }, 5);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    pub fn get_mut(&mut self) -> &mut *mut T {
        self.p.get_mut()
    }

    /// Kumuha ng pag-access ng atomic sa isang pointer.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(atomic_from_mut)]
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let mut some_ptr = &mut 123 as *mut i32;
    /// let a = AtomicPtr::from_mut(&mut some_ptr);
    /// a.store(&mut 456, Ordering::Relaxed);
    /// assert_eq!(unsafe { *some_ptr }, 456);
    /// ```
    #[inline]
    #[cfg(target_has_atomic_equal_alignment = "ptr")]
    #[unstable(feature = "atomic_from_mut", issue = "76314")]
    pub fn from_mut(v: &mut *mut T) -> &Self {
        use crate::mem::align_of;
        let [] = [(); align_of::<AtomicPtr<()>>() - align_of::<*mut ()>()];
        // SAFETY:
        //  - ang nababagong sanggunian ay ginagarantiyahan ang natatanging pagmamay-ari.
        //  - ang pagkakahanay ng `*mut T` at `Self` ay pareho sa lahat ng mga platform na suportado ng rust, tulad ng na-verify sa itaas.
        //
        unsafe { &*(v as *mut *mut T as *mut Self) }
    }

    /// Naubos ang atomic at ibinabalik ang nilalaman na nilalaman.
    ///
    /// Ito ay ligtas dahil ang pagpasa sa `self` ayon sa halaga ay ginagarantiyahan na walang iba pang mga thread na sabay-sabay na na-access ang data ng atomic.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicPtr;
    ///
    /// let atomic_ptr = AtomicPtr::new(&mut 5);
    /// assert_eq!(unsafe { *atomic_ptr.into_inner() }, 5);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> *mut T {
        self.p.into_inner()
    }

    /// Naglo-load ng isang halaga mula sa pointer.
    ///
    /// `load` tumatagal ng isang argumentong [`Ordering`] na naglalarawan sa pag-order ng memorya ng operasyong ito.
    /// Ang mga posibleng halaga ay [`SeqCst`], [`Acquire`] at [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics kung `order` ay [`Release`] o [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let value = some_ptr.load(Ordering::Relaxed);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn load(&self, order: Ordering) -> *mut T {
        // KALIGTASAN: ang mga karera ng data ay pinipigilan ng mga atomic intrinsics.
        unsafe { atomic_load(self.p.get(), order) }
    }

    /// Nag-iimbak ng halaga sa pointer.
    ///
    /// `store` tumatagal ng isang argumentong [`Ordering`] na naglalarawan sa pag-order ng memorya ng operasyong ito.
    /// Ang mga posibleng halaga ay [`SeqCst`], [`Release`] at [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics kung `order` ay [`Acquire`] o [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr = &mut 10;
    ///
    /// some_ptr.store(other_ptr, Ordering::Relaxed);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn store(&self, ptr: *mut T, order: Ordering) {
        // KALIGTASAN: ang mga karera ng data ay pinipigilan ng mga atomic intrinsics.
        unsafe {
            atomic_store(self.p.get(), ptr, order);
        }
    }

    /// Nag-iimbak ng isang halaga sa pointer, na ibinabalik ang dating halaga.
    ///
    /// `swap` tumatagal ng isang argumentong [`Ordering`] na naglalarawan sa pag-order ng memorya ng operasyong ito.Posible ang lahat ng mga mode sa pag-order.
    /// Tandaan na ang paggamit ng [`Acquire`] ay gumagawa ng bahagi ng tindahan ng operasyong [`Relaxed`] na ito, at ang paggamit ng [`Release`] ay gumagawa ng bahagi ng pag-load na [`Relaxed`].
    ///
    ///
    /// **Note:** Ang pamamaraan na ito ay magagamit lamang sa mga platform na sumusuporta sa atomic operasyon sa mga payo.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr = &mut 10;
    ///
    /// let value = some_ptr.swap(other_ptr, Ordering::Relaxed);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn swap(&self, ptr: *mut T, order: Ordering) -> *mut T {
        // KALIGTASAN: ang mga karera ng data ay pinipigilan ng mga atomic intrinsics.
        unsafe { atomic_swap(self.p.get(), ptr, order) }
    }

    /// Nag-iimbak ang halaga sa ang pointer kung ang kasalukuyang halaga ay ang parehong bilang ang halaga `current`.
    ///
    /// Ang halaga ng pagbabalik ay palaging ang dating halaga.Kung ito ay katumbas ng `current`, pagkatapos ay na-update ang halaga.
    ///
    /// `compare_and_swap` tumatagal din ng isang [`Ordering`] argument na naglalarawan sa pag-order ng memorya ng operasyong ito.
    /// Pansinin na kahit na kapag gumagamit ng [`AcqRel`], ang operasyon ay maaaring mabibigo at samakatuwid lamang magsagawa ng isang `Acquire` load, ngunit hindi magkaroon ng `Release` semantics.
    /// Paggamit [`Acquire`] gumagawa store bahagi ng operasyon [`Relaxed`] kung ito ang mangyayari, at paggamit ng [`Release`] gumagawa ng pag-load na bahagi [`Relaxed`].
    ///
    /// **Note:** Ang pamamaraan na ito ay magagamit lamang sa mga platform na sumusuporta sa atomic operasyon sa mga payo.
    ///
    /// # Ang paglipat sa `compare_exchange` at `compare_exchange_weak`
    ///
    /// `compare_and_swap` ay katumbas ng `compare_exchange` na may mga sumusunod na pagmamapa para sa pag-order ng memorya:
    ///
    /// Orihinal |Tagumpay |Pagkabigo
    /// -------- | ------- | -------
    /// Nakakarelaks |Nakakarelaks |Nakakarelaks na Kumuha |Kumuha ng |Kumuha ng Pakawalan |Pakawalan |Nakakarelaks na AcqRel |AcqRel |Kumuha ng SeqCst |SeqCst |SeqCst
    ///
    /// `compare_exchange_weak` ay pinahihintulutang mabigo nang mabuti kahit na magtagumpay ang paghahambing, na nagbibigay-daan sa tagatala upang makabuo ng mas mahusay na code ng pagpupulong kung ang paghahambing at pagpapalit ay ginagamit sa isang loop.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr   = &mut 10;
    ///
    /// let value = some_ptr.compare_and_swap(ptr, other_ptr, Ordering::Relaxed);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.50.0",
        reason = "Use `compare_exchange` or `compare_exchange_weak` instead"
    )]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_and_swap(&self, current: *mut T, new: *mut T, order: Ordering) -> *mut T {
        match self.compare_exchange(current, new, order, strongest_failure_ordering(order)) {
            Ok(x) => x,
            Err(x) => x,
        }
    }

    /// Nag-iimbak ang halaga sa ang pointer kung ang kasalukuyang halaga ay ang parehong bilang ang halaga `current`.
    ///
    /// Ang halaga ng pagbabalik ay isang resulta na nagpapahiwatig kung ang bagong halaga ay nakasulat at naglalaman ng nakaraang halaga.
    /// Sa tagumpay ang halaga na ito ay garantisadong upang maging katumbas ng `current`.
    ///
    /// `compare_exchange` ay tumatagal ng dalawang [`Ordering`] argumento upang ilarawan ang memory na pag-order ng pagpapatakbong ito.
    /// `success` inilalarawan ang kinakailangang pag-order para sa operasyon na basahin-baguhin-isulat na magaganap kung magtagumpay ang paghahambing sa `current`.
    /// `failure` naglalarawan ng kinakailangang pag-order para sa pagpapatakbo ng pag-load na nagaganap kapag nabigo ang paghahambing.
    /// Ang paggamit ng [`Acquire`] bilang tagumpay sa pag-order ay ginagawang bahagi ng tindahan ng operasyong ito [`Relaxed`], at ang paggamit ng [`Release`] ay ginagawang matagumpay ang pagkarga ng [`Relaxed`].
    ///
    /// Ang pagkakasunud-sunod ng kabiguan ay maaari lamang maging [`SeqCst`], [`Acquire`] o [`Relaxed`] at dapat na katumbas o mas mahina kaysa sa pag-order ng tagumpay.
    ///
    /// **Note:** Ang pamamaraan na ito ay magagamit lamang sa mga platform na sumusuporta sa atomic operasyon sa mga payo.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr   = &mut 10;
    ///
    /// let value = some_ptr.compare_exchange(ptr, other_ptr,
    ///                                       Ordering::SeqCst, Ordering::Relaxed);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_exchange(
        &self,
        current: *mut T,
        new: *mut T,
        success: Ordering,
        failure: Ordering,
    ) -> Result<*mut T, *mut T> {
        // KALIGTASAN: ang mga karera ng data ay pinipigilan ng mga atomic intrinsics.
        unsafe { atomic_compare_exchange(self.p.get(), current, new, success, failure) }
    }

    /// Nag-iimbak ang halaga sa ang pointer kung ang kasalukuyang halaga ay ang parehong bilang ang halaga `current`.
    ///
    /// Hindi tulad ng [`AtomicPtr::compare_exchange`], function na ito ay pinahihintulutang ay huwad na mabibigo kahit na kapag ang paghahambing magtagumpay, na kung saan ay maaaring magresulta sa mas mahusay na code sa ilang mga platform.
    ///
    /// Ang halaga ng pagbabalik ay isang resulta na nagpapahiwatig kung ang bagong halaga ay nakasulat at naglalaman ng nakaraang halaga.
    ///
    /// `compare_exchange_weak` ay tumatagal ng dalawang [`Ordering`] argumento upang ilarawan ang memory na pag-order ng pagpapatakbong ito.
    /// `success` inilalarawan ang kinakailangang pag-order para sa operasyon na basahin-baguhin-isulat na magaganap kung magtagumpay ang paghahambing sa `current`.
    /// `failure` naglalarawan ng kinakailangang pag-order para sa pagpapatakbo ng pag-load na nagaganap kapag nabigo ang paghahambing.
    /// Ang paggamit ng [`Acquire`] bilang tagumpay sa pag-order ay ginagawang bahagi ng tindahan ng operasyong ito [`Relaxed`], at ang paggamit ng [`Release`] ay ginagawang matagumpay ang pagkarga ng [`Relaxed`].
    /// Ang pagkakasunud-sunod ng kabiguan ay maaari lamang maging [`SeqCst`], [`Acquire`] o [`Relaxed`] at dapat na katumbas o mas mahina kaysa sa pag-order ng tagumpay.
    ///
    /// **Note:** Ang pamamaraan na ito ay magagamit lamang sa mga platform na sumusuporta sa atomic operasyon sa mga payo.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let some_ptr = AtomicPtr::new(&mut 5);
    ///
    /// let new = &mut 10;
    /// let mut old = some_ptr.load(Ordering::Relaxed);
    /// loop {
    ///     match some_ptr.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) {
    ///         Ok(_) => break,
    ///         Err(x) => old = x,
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_exchange_weak(
        &self,
        current: *mut T,
        new: *mut T,
        success: Ordering,
        failure: Ordering,
    ) -> Result<*mut T, *mut T> {
        // KALIGTASAN: Ang intrinsic na ito ay hindi ligtas dahil nagpapatakbo ito sa isang raw pointer
        // ngunit alam namin para sigurado na ang pointer ay may-bisa (kami lang nakuha ko mula sa isang `UnsafeCell` na mayroon kami sa pamamagitan ng reference) at ang atomic operasyon mismo ay nagpapahintulot sa amin upang ligtas na mutate ang mga nilalaman `UnsafeCell`.
        //
        //
        unsafe { atomic_compare_exchange_weak(self.p.get(), current, new, success, failure) }
    }

    /// Kinukuha ang halaga, at naglalapat ng isang pagpapaandar dito na nagbabalik ng isang opsyonal na bagong halaga.Ibinabalik ang isang `Result` ng `Ok(previous_value)` kung ang pagpapaandar ay bumalik sa `Some(_)`, iba pa `Err(previous_value)`.
    ///
    /// Note: Maaari nitong tawagan ang pag-andar ng maraming beses kung ang halaga ay nabago mula sa iba pang mga thread pansamantala, hangga't ibabalik ng pagpapaandar ang `Some(_)`, ngunit ang pagpapaandar ay maiilapat lamang nang isang beses sa nakaimbak na halaga.
    ///
    ///
    /// `fetch_update` ay tumatagal ng dalawang [`Ordering`] argumento upang ilarawan ang memory na pag-order ng pagpapatakbong ito.
    /// Inilalarawan ng una ang kinakailangang pag-order para kailan magtagumpay ang operasyon habang ang pangalawa ay naglalarawan ng kinakailangang pag-order para sa mga karga.
    /// Ito ay tumutugma sa tagumpay at pagkabigo na pag-order ng [`AtomicPtr::compare_exchange`] ayon sa pagkakabanggit.
    ///
    /// Paggamit [`Acquire`] pati na tagumpay sa pag-order ay gumagawa store bahagi ng operasyon [`Relaxed`], at paggamit ng [`Release`] gumagawa ng pangwakas na tagumpay load [`Relaxed`].
    /// Ang pag-order ng pag-load ng (failed) ay maaari lamang [`SeqCst`], [`Acquire`] o [`Relaxed`] at dapat na katumbas o mas mahina kaysa sa pag-order ng tagumpay.
    ///
    /// **Note:** Ang pamamaraan na ito ay magagamit lamang sa mga platform na sumusuporta sa atomic operasyon sa mga payo.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(atomic_fetch_update)]
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr: *mut _ = &mut 5;
    /// let some_ptr = AtomicPtr::new(ptr);
    ///
    /// let new: *mut _ = &mut 10;
    /// assert_eq!(some_ptr.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(ptr));
    /// let result = some_ptr.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| {
    ///     if x == ptr {
    ///         Some(new)
    ///     } else {
    ///         None
    ///     }
    /// });
    /// assert_eq!(result, Ok(ptr));
    /// assert_eq!(some_ptr.load(Ordering::SeqCst), new);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_fetch_update", reason = "recently added", issue = "78639")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn fetch_update<F>(
        &self,
        set_order: Ordering,
        fetch_order: Ordering,
        mut f: F,
    ) -> Result<*mut T, *mut T>
    where
        F: FnMut(*mut T) -> Option<*mut T>,
    {
        let mut prev = self.load(fetch_order);
        while let Some(next) = f(prev) {
            match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                x @ Ok(_) => return x,
                Err(next_prev) => prev = next_prev,
            }
        }
        Err(prev)
    }
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "atomic_bool_from", since = "1.24.0")]
impl From<bool> for AtomicBool {
    /// Kino-convert ng isang `bool` sa isang `AtomicBool`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    /// let atomic_bool = AtomicBool::from(true);
    /// assert_eq!(format!("{:?}", atomic_bool), "true")
    /// ```
    #[inline]
    fn from(b: bool) -> Self {
        Self::new(b)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_from", since = "1.23.0")]
impl<T> From<*mut T> for AtomicPtr<T> {
    #[inline]
    fn from(p: *mut T) -> Self {
        Self::new(p)
    }
}

#[allow(unused_macros)] // Ang macro na ito ay nagtatapos na hindi ginagamit sa ilang mga arkitektura.
macro_rules! if_not_8_bit {
    (u8, $($tt:tt)*) => { "" };
    (i8, $($tt:tt)*) => { "" };
    ($_:ident, $($tt:tt)*) => { $($tt)* };
}

#[cfg(target_has_atomic_load_store = "8")]
macro_rules! atomic_int {
    ($cfg_cas:meta,
     $cfg_align:meta,
     $stable:meta,
     $stable_cxchg:meta,
     $stable_debug:meta,
     $stable_access:meta,
     $stable_from:meta,
     $stable_nand:meta,
     $const_stable:meta,
     $stable_init_const:meta,
     $s_int_type:literal,
     $extra_feature:expr,
     $min_fn:ident, $max_fn:ident,
     $align:expr,
     $atomic_new:expr,
     $int_type:ident $atomic_type:ident $atomic_init:ident) => {
        /// Isang uri ng integer na maaaring ligtas na maibahagi sa pagitan ng mga thread.
        ///
        /// Ang uri na ito ay may parehong in-memory na representasyon ng pinagbabatayan na uri ng integer, [`
        ///
        #[doc = $s_int_type]
        /// `].
        /// Para sa higit pa tungkol sa mga pagkakaiba sa pagitan atomic uri at di-atomic uri pati na rin ang impormasyon tungkol sa mga maaaring dalhin ng ganitong uri, pakitingnan ang [module-level documentation].
        ///
        ///
        /// **Note:** Magagamit lamang ang ganitong uri sa mga platform na sumusuporta sa mga pag-load ng atomic at mga tindahan ng [`
        ///
        #[doc = $s_int_type]
        /// `].
        ///
        /// [module-level documentation]: crate::sync::atomic
        #[$stable]
        #[repr(C, align($align))]
        pub struct $atomic_type {
            v: UnsafeCell<$int_type>,
        }

        /// Ang isang atomic integer ay nagpasimula sa `0`.
        #[$stable_init_const]
        #[rustc_deprecated(
            since = "1.34.0",
            reason = "the `new` function is now preferred",
            suggestion = $atomic_new,
        )]
        pub const $atomic_init: $atomic_type = $atomic_type::new(0);

        #[$stable]
        impl Default for $atomic_type {
            #[inline]
            fn default() -> Self {
                Self::new(Default::default())
            }
        }

        #[$stable_from]
        impl From<$int_type> for $atomic_type {
            #[doc = concat!("Converts an `", stringify!($int_type), "` into an `", stringify!($atomic_type), "`.")]
            #[inline]
            fn from(v: $int_type) -> Self { Self::new(v) }
        }

        #[$stable_debug]
        impl fmt::Debug for $atomic_type {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
            }
        }

        // Imbitadong ipinatupad ang pagpapadala.
        #[$stable]
        unsafe impl Sync for $atomic_type {}

        impl $atomic_type {
            /// Lumilikha ng isang bagong atomic integer.
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]

            #[doc = concat!("let atomic_forty_two = ", stringify!($atomic_type), "::new(42);")]
            /// ```
            #[inline]
            #[$stable]
            #[$const_stable]
            pub const fn new(v: $int_type) -> Self {
                Self {v: UnsafeCell::new(v)}
            }

            /// Nagbabalik ng isang nababagabag na sanggunian sa pinagbabatayan na integer.
            ///
            /// Ito ay ligtas sapagkat ang nababagabagong sanggunian ay ginagarantiyahan na walang iba pang mga thread na sabay-sabay na na-access ang data ng atomic.
            ///
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let mut some_var = ", stringify!($atomic_type), "::new(10);")]
            /// assert_eq!(*some_var.get_mut(), 10);
            /// *some_var.get_mut() =5;
            /// assert_eq!(some_var.load(Ordering::SeqCst), 5);
            /// ```
            #[inline]
            #[$stable_access]
            pub fn get_mut(&mut self) -> &mut $int_type {
                self.v.get_mut()
            }

            #[doc = concat!("Get atomic access to a `&mut ", stringify!($int_type), "`.")]

            #[doc = if_not_8_bit! {
                $int_type,
                concat!(
                    "**Note:** This function is only available on targets where `",
                    stringify!($int_type), "` has an alignment of ", $align, " bytes."
                )
            }]
            /// # Examples
            ///
            /// ```
            /// #![feature(atomic_from_mut)]
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]
            /// hayaan mut ilang_int=123;
            #[doc = concat!("let a = ", stringify!($atomic_type), "::from_mut(&mut some_int);")]
            /// a.store(100, Ordering::Relaxed);
            ///
            /// ! Assert_eq (some_int, 100);
            /// ```
            #[inline]
            #[$cfg_align]
            #[unstable(feature = "atomic_from_mut", issue = "76314")]
            pub fn from_mut(v: &mut $int_type) -> &Self {
                use crate::mem::align_of;
                let [] = [(); align_of::<Self>() - align_of::<$int_type>()];
                // SAFETY:
                //  - ang nababagong sanggunian ay ginagarantiyahan ang natatanging pagmamay-ari.
                //  - ang pagkakahanay ng `$int_type` at `Self` ay pareho, tulad ng ipinangako sa pamamagitan $cfg_align at na-verify sa itaas.
                //
                unsafe { &*(v as *mut $int_type as *mut Self) }
            }

            /// Naubos ang atomic at ibinabalik ang nilalaman na nilalaman.
            ///
            /// Ito ay ligtas dahil ang pagpasa sa `self` ayon sa halaga ay ginagarantiyahan na walang iba pang mga thread na sabay-sabay na na-access ang data ng atomic.
            ///
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.into_inner(), 5);
            /// ```
            #[inline]
            #[$stable_access]
            #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
            pub const fn into_inner(self) -> $int_type {
                self.v.into_inner()
            }

            /// Naglo-load ng isang halaga mula sa atomic integer.
            ///
            /// `load` tumatagal ng isang argumentong [`Ordering`] na naglalarawan sa pag-order ng memorya ng operasyong ito.
            /// Ang mga posibleng halaga ay [`SeqCst`], [`Acquire`] at [`Relaxed`].
            ///
            /// # Panics
            ///
            /// Panics kung `order` ay [`Release`] o [`AcqRel`].
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.load(Ordering::Relaxed), 5);
            /// ```
            #[inline]
            #[$stable]
            pub fn load(&self, order: Ordering) -> $int_type {
                // KALIGTASAN: ang mga karera ng data ay pinipigilan ng mga atomic intrinsics.
                unsafe { atomic_load(self.v.get(), order) }
            }

            /// Nag-iimbak ng isang halaga sa atomic integer.
            ///
            /// `store` tumatagal ng isang argumentong [`Ordering`] na naglalarawan sa pag-order ng memorya ng operasyong ito.
            ///  Ang mga posibleng halaga ay [`SeqCst`], [`Release`] at [`Relaxed`].
            ///
            /// # Panics
            ///
            /// Panics kung `order` ay [`Acquire`] o [`AcqRel`].
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// some_var.store(10, Ordering::Relaxed);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            #[inline]
            #[$stable]
            pub fn store(&self, val: $int_type, order: Ordering) {
                // KALIGTASAN: ang mga karera ng data ay pinipigilan ng mga atomic intrinsics.
                unsafe { atomic_store(self.v.get(), val, order); }
            }

            /// Nag-iimbak ang halaga sa atomic integer, mga bumabalik na sa nakaraang halaga.
            ///
            /// `swap` tumatagal ng isang argumentong [`Ordering`] na naglalarawan sa pag-order ng memorya ng operasyong ito.Posible ang lahat ng mga mode sa pag-order.
            /// Tandaan na ang paggamit ng [`Acquire`] ay gumagawa ng bahagi ng tindahan ng operasyong [`Relaxed`] na ito, at ang paggamit ng [`Release`] ay gumagawa ng bahagi ng pag-load na [`Relaxed`].
            ///
            ///
            /// **Tandaan**: Magagamit lamang ang pamamaraang ito sa mga platform na sumusuporta sa pagpapatakbo ng atomic
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.swap(10, Ordering::Relaxed), 5);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn swap(&self, val: $int_type, order: Ordering) -> $int_type {
                // KALIGTASAN: ang mga karera ng data ay pinipigilan ng mga atomic intrinsics.
                unsafe { atomic_swap(self.v.get(), val, order) }
            }

            /// Nag-iimbak ang halaga sa atomic integer kung ang kasalukuyang halaga ay ang parehong bilang ang halaga `current`.
            ///
            /// Ang halaga ng pagbabalik ay palaging ang dating halaga.Kung ito ay katumbas ng `current`, pagkatapos ay na-update ang halaga.
            ///
            /// `compare_and_swap` tumatagal din ng isang [`Ordering`] argument na naglalarawan sa pag-order ng memorya ng operasyong ito.
            /// Pansinin na kahit na kapag gumagamit ng [`AcqRel`], ang operasyon ay maaaring mabibigo at samakatuwid lamang magsagawa ng isang `Acquire` load, ngunit hindi magkaroon ng `Release` semantics.
            ///
            /// Paggamit [`Acquire`] gumagawa store bahagi ng operasyon [`Relaxed`] kung ito ang mangyayari, at paggamit ng [`Release`] gumagawa ng pag-load na bahagi [`Relaxed`].
            ///
            /// **Tandaan**: Magagamit lamang ang pamamaraang ito sa mga platform na sumusuporta sa pagpapatakbo ng atomic
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Ang paglipat sa `compare_exchange` at `compare_exchange_weak`
            ///
            /// `compare_and_swap` ay katumbas ng `compare_exchange` na may mga sumusunod na pagmamapa para sa pag-order ng memorya:
            ///
            /// Orihinal |Tagumpay |Pagkabigo
            /// -------- | ------- | -------
            /// Nakakarelaks |Nakakarelaks |Nakakarelaks na Kumuha |Kumuha ng |Kumuha ng Pakawalan |Pakawalan |Nakakarelaks na AcqRel |AcqRel |Kumuha ng SeqCst |SeqCst |SeqCst
            ///
            /// `compare_exchange_weak` ay pinahihintulutang mabigo nang mabuti kahit na magtagumpay ang paghahambing, na nagbibigay-daan sa tagatala upang makabuo ng mas mahusay na code ng pagpupulong kung ang paghahambing at pagpapalit ay ginagamit sa isang loop.
            ///
            ///
            /// # Examples
            ///
            /// ```
            ///
            ///
            ///
            ///
            ///
            ///
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.compare_and_swap(5, 10, Ordering::Relaxed), 5);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            ///
            /// assert_eq!(some_var.compare_and_swap(6, 12, Ordering::Relaxed), 10);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            #[inline]
            #[$stable]
            #[rustc_deprecated(
                since = "1.50.0",
                reason = "Use `compare_exchange` or `compare_exchange_weak` instead")
            ]
            #[$cfg_cas]
            pub fn compare_and_swap(&self,
                                    current: $int_type,
                                    new: $int_type,
                                    order: Ordering) -> $int_type {
                match self.compare_exchange(current,
                                            new,
                                            order,
                                            strongest_failure_ordering(order)) {
                    Ok(x) => x,
                    Err(x) => x,
                }
            }

            /// Nag-iimbak ang halaga sa atomic integer kung ang kasalukuyang halaga ay ang parehong bilang ang halaga `current`.
            ///
            /// Ang halaga ng pagbabalik ay isang resulta na nagpapahiwatig kung ang bagong halaga ay nakasulat at naglalaman ng nakaraang halaga.
            /// Sa tagumpay ang halaga na ito ay garantisadong upang maging katumbas ng `current`.
            ///
            /// `compare_exchange` ay tumatagal ng dalawang [`Ordering`] argumento upang ilarawan ang memory na pag-order ng pagpapatakbong ito.
            /// `success` inilalarawan ang kinakailangang pag-order para sa operasyon na basahin-baguhin-isulat na magaganap kung magtagumpay ang paghahambing sa `current`.
            /// `failure` naglalarawan ng kinakailangang pag-order para sa pagpapatakbo ng pag-load na nagaganap kapag nabigo ang paghahambing.
            /// Ang paggamit ng [`Acquire`] bilang tagumpay sa pag-order ay ginagawang bahagi ng tindahan ng operasyong ito [`Relaxed`], at ang paggamit ng [`Release`] ay ginagawang matagumpay ang pagkarga ng [`Relaxed`].
            ///
            /// Ang pagkakasunud-sunod ng kabiguan ay maaari lamang maging [`SeqCst`], [`Acquire`] o [`Relaxed`] at dapat na katumbas o mas mahina kaysa sa pag-order ng tagumpay.
            ///
            /// **Tandaan**: Magagamit lamang ang pamamaraang ito sa mga platform na sumusuporta sa pagpapatakbo ng atomic
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.compare_exchange(5, 10,                                      Ordering::Acquire,                                      Ordering::Relaxed),
            ///
            ///            Ok(5));
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            ///
            /// assert_eq!(some_var.compare_exchange(6, 12,                                      Ordering::SeqCst,                                      Ordering::Acquire),
            ///            Err(10));
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            ///
            ///
            ///
            #[inline]
            #[$stable_cxchg]
            #[$cfg_cas]
            pub fn compare_exchange(&self,
                                    current: $int_type,
                                    new: $int_type,
                                    success: Ordering,
                                    failure: Ordering) -> Result<$int_type, $int_type> {
                // KALIGTASAN: ang mga karera ng data ay pinipigilan ng mga atomic intrinsics.
                unsafe { atomic_compare_exchange(self.v.get(), current, new, success, failure) }
            }

            /// Nag-iimbak ang halaga sa atomic integer kung ang kasalukuyang halaga ay ang parehong bilang ang halaga `current`.
            ///
            ///
            #[doc = concat!("Unlike [`", stringify!($atomic_type), "::compare_exchange`],")]
            /// ang pagpapaandar na ito ay pinapayagan na mabilis na mabigo kahit na magtagumpay ang paghahambing, na maaaring magresulta sa mas mahusay na code sa ilang mga platform.
            /// Ang halaga ng pagbabalik ay isang resulta na nagpapahiwatig kung ang bagong halaga ay nakasulat at naglalaman ng nakaraang halaga.
            ///
            /// `compare_exchange_weak` ay tumatagal ng dalawang [`Ordering`] argumento upang ilarawan ang memory na pag-order ng pagpapatakbong ito.
            /// `success` inilalarawan ang kinakailangang pag-order para sa operasyon na basahin-baguhin-isulat na magaganap kung magtagumpay ang paghahambing sa `current`.
            /// `failure` naglalarawan ng kinakailangang pag-order para sa pagpapatakbo ng pag-load na nagaganap kapag nabigo ang paghahambing.
            /// Ang paggamit ng [`Acquire`] bilang tagumpay sa pag-order ay ginagawang bahagi ng tindahan ng operasyong ito [`Relaxed`], at ang paggamit ng [`Release`] ay ginagawang matagumpay ang pagkarga ng [`Relaxed`].
            ///
            /// Ang pagkakasunud-sunod ng kabiguan ay maaari lamang maging [`SeqCst`], [`Acquire`] o [`Relaxed`] at dapat na katumbas o mas mahina kaysa sa pag-order ng tagumpay.
            ///
            /// **Tandaan**: Magagamit lamang ang pamamaraang ito sa mga platform na sumusuporta sa pagpapatakbo ng atomic
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let val = ", stringify!($atomic_type), "::new(4);")]
            /// hayaan mut luma= val.load(Ordering::Relaxed);
            /// loop {let new=old * 2;
            ///     tugma val.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) { Ok(_) => break, Err(x) => old = x, }}
            ///
            /// ```
            ///
            ///
            ///
            ///
            #[inline]
            #[$stable_cxchg]
            #[$cfg_cas]
            pub fn compare_exchange_weak(&self,
                                         current: $int_type,
                                         new: $int_type,
                                         success: Ordering,
                                         failure: Ordering) -> Result<$int_type, $int_type> {
                // KALIGTASAN: ang mga karera ng data ay pinipigilan ng mga atomic intrinsics.
                unsafe {
                    atomic_compare_exchange_weak(self.v.get(), current, new, success, failure)
                }
            }

            /// Nagdaragdag sa kasalukuyang halaga, na binabalik ang dating halaga.
            ///
            /// Ang operasyon na ito wraps sa paligid sa overflow.
            ///
            /// `fetch_add` tumatagal ng isang argumentong [`Ordering`] na naglalarawan sa pag-order ng memorya ng operasyong ito.Posible ang lahat ng mga mode sa pag-order.
            /// Tandaan na ang paggamit ng [`Acquire`] ay gumagawa ng bahagi ng tindahan ng operasyong [`Relaxed`] na ito, at ang paggamit ng [`Release`] ay gumagawa ng bahagi ng pag-load na [`Relaxed`].
            ///
            ///
            /// **Tandaan**: Magagamit lamang ang pamamaraang ito sa mga platform na sumusuporta sa pagpapatakbo ng atomic
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0);")]
            /// assert_eq!(foo.fetch_add(10, Ordering::SeqCst), 0);
            /// assert_eq!(foo.load(Ordering::SeqCst), 10);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_add(&self, val: $int_type, order: Ordering) -> $int_type {
                // KALIGTASAN: ang mga karera ng data ay pinipigilan ng mga atomic intrinsics.
                unsafe { atomic_add(self.v.get(), val, order) }
            }

            /// Bumabawas mula sa kasalukuyang halaga, na binabalik ang dating halaga.
            ///
            /// Ang operasyon na ito wraps sa paligid sa overflow.
            ///
            /// `fetch_sub` tumatagal ng isang argumentong [`Ordering`] na naglalarawan sa pag-order ng memorya ng operasyong ito.Posible ang lahat ng mga mode sa pag-order.
            /// Tandaan na ang paggamit ng [`Acquire`] ay gumagawa ng bahagi ng tindahan ng operasyong [`Relaxed`] na ito, at ang paggamit ng [`Release`] ay gumagawa ng bahagi ng pag-load na [`Relaxed`].
            ///
            ///
            /// **Tandaan**: Magagamit lamang ang pamamaraang ito sa mga platform na sumusuporta sa pagpapatakbo ng atomic
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(20);")]
            /// assert_eq!(foo.fetch_sub(10, Ordering::SeqCst), 20);
            /// assert_eq!(foo.load(Ordering::SeqCst), 10);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_sub(&self, val: $int_type, order: Ordering) -> $int_type {
                // KALIGTASAN: ang mga karera ng data ay pinipigilan ng mga atomic intrinsics.
                unsafe { atomic_sub(self.v.get(), val, order) }
            }

            /// Bitwise "and" na may kasalukuyang halaga.
            ///
            /// Gumagawa ng isang bitwise "and" na operasyon sa kasalukuyang halaga at ang argument na `val`, at itinatakda ang bagong halaga sa resulta.
            ///
            /// Ibinabalik ang dating halaga.
            ///
            /// `fetch_and` tumatagal ng isang argumentong [`Ordering`] na naglalarawan sa pag-order ng memorya ng operasyong ito.Posible ang lahat ng mga mode sa pag-order.
            /// Tandaan na ang paggamit ng [`Acquire`] ay gumagawa ng bahagi ng tindahan ng operasyong [`Relaxed`] na ito, at ang paggamit ng [`Release`] ay gumagawa ng bahagi ng pag-load na [`Relaxed`].
            ///
            ///
            /// **Tandaan**: Magagamit lamang ang pamamaraang ito sa mga platform na sumusuporta sa pagpapatakbo ng atomic
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_and(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b100001);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_and(&self, val: $int_type, order: Ordering) -> $int_type {
                // KALIGTASAN: ang mga karera ng data ay pinipigilan ng mga atomic intrinsics.
                unsafe { atomic_and(self.v.get(), val, order) }
            }

            /// Bitwise "nand" na may kasalukuyang halaga.
            ///
            /// Gumagawa ng isang bitwise "nand" na operasyon sa kasalukuyang halaga at ang argumentong `val`, at itinatakda ang bagong halaga sa resulta.
            ///
            /// Ibinabalik ang dating halaga.
            ///
            /// `fetch_nand` tumatagal ng isang argumentong [`Ordering`] na naglalarawan sa pag-order ng memorya ng operasyong ito.Posible ang lahat ng mga mode sa pag-order.
            /// Tandaan na ang paggamit ng [`Acquire`] ay gumagawa ng bahagi ng tindahan ng operasyong [`Relaxed`] na ito, at ang paggamit ng [`Release`] ay gumagawa ng bahagi ng pag-load na [`Relaxed`].
            ///
            ///
            /// **Tandaan**: Magagamit lamang ang pamamaraang ito sa mga platform na sumusuporta sa pagpapatakbo ng atomic
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0x13);")]
            /// assert_eq!(foo.fetch_nand(0x31, Ordering::SeqCst), 0x13);
            /// assert_eq!(foo.load(Ordering::SeqCst), ! (0x13&0x31));
            /// ```
            #[inline]
            #[$stable_nand]
            #[$cfg_cas]
            pub fn fetch_nand(&self, val: $int_type, order: Ordering) -> $int_type {
                // KALIGTASAN: ang mga karera ng data ay pinipigilan ng mga atomic intrinsics.
                unsafe { atomic_nand(self.v.get(), val, order) }
            }

            /// Bitwise "or" na may kasalukuyang halaga.
            ///
            /// Gumagawa ng isang bitwise "or" na operasyon sa kasalukuyang halaga at ang argument na `val`, at itinatakda ang bagong halaga sa resulta.
            ///
            /// Ibinabalik ang dating halaga.
            ///
            /// `fetch_or` tumatagal ng isang argumentong [`Ordering`] na naglalarawan sa pag-order ng memorya ng operasyong ito.Posible ang lahat ng mga mode sa pag-order.
            /// Tandaan na ang paggamit ng [`Acquire`] ay gumagawa ng bahagi ng tindahan ng operasyong [`Relaxed`] na ito, at ang paggamit ng [`Release`] ay gumagawa ng bahagi ng pag-load na [`Relaxed`].
            ///
            ///
            /// **Tandaan**: Magagamit lamang ang pamamaraang ito sa mga platform na sumusuporta sa pagpapatakbo ng atomic
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_or(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b111111);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_or(&self, val: $int_type, order: Ordering) -> $int_type {
                // KALIGTASAN: ang mga karera ng data ay pinipigilan ng mga atomic intrinsics.
                unsafe { atomic_or(self.v.get(), val, order) }
            }

            /// Bitwise "xor" na may kasalukuyang halaga.
            ///
            /// Gumagawa ng isang bitwise "xor" na operasyon sa kasalukuyang halaga at ang argument na `val`, at itinatakda ang bagong halaga sa resulta.
            ///
            /// Ibinabalik ang dating halaga.
            ///
            /// `fetch_xor` tumatagal ng isang argumentong [`Ordering`] na naglalarawan sa pag-order ng memorya ng operasyong ito.Posible ang lahat ng mga mode sa pag-order.
            /// Tandaan na ang paggamit ng [`Acquire`] ay gumagawa ng bahagi ng tindahan ng operasyong [`Relaxed`] na ito, at ang paggamit ng [`Release`] ay gumagawa ng bahagi ng pag-load na [`Relaxed`].
            ///
            ///
            /// **Tandaan**: Magagamit lamang ang pamamaraang ito sa mga platform na sumusuporta sa pagpapatakbo ng atomic
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_xor(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b011110);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_xor(&self, val: $int_type, order: Ordering) -> $int_type {
                // KALIGTASAN: ang mga karera ng data ay pinipigilan ng mga atomic intrinsics.
                unsafe { atomic_xor(self.v.get(), val, order) }
            }

            /// Kinukuha ang halaga, at naglalapat ng isang pagpapaandar dito na nagbabalik ng isang opsyonal na bagong halaga.Ibinabalik ang isang `Result` ng `Ok(previous_value)` kung ang pagpapaandar ay bumalik sa `Some(_)`, iba pa `Err(previous_value)`.
            ///
            /// Note: Maaari nitong tawagan ang pag-andar ng maraming beses kung ang halaga ay nabago mula sa iba pang mga thread pansamantala, hangga't ibabalik ng pagpapaandar ang `Some(_)`, ngunit ang pagpapaandar ay maiilapat lamang nang isang beses sa nakaimbak na halaga.
            ///
            ///
            /// `fetch_update` ay tumatagal ng dalawang [`Ordering`] argumento upang ilarawan ang memory na pag-order ng pagpapatakbong ito.
            /// Ang unang naglalarawan ng mga kinakailangang pag-order para kapag ang operasyon sa wakas ay magtagumpay habang ang pangalawang ay naglalarawan ng mga kinakailangang pag-order para sa mga naglo-load.Ang mga ay tumutugma sa mga tagumpay at kabiguan ayos
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", stringify!($atomic_type), "::compare_exchange`]")]
            /// respectively.
            ///
            /// Paggamit [`Acquire`] pati na tagumpay sa pag-order ay gumagawa store bahagi ng operasyon [`Relaxed`], at paggamit ng [`Release`] gumagawa ng pangwakas na tagumpay load [`Relaxed`].
            /// Ang pag-order ng pag-load ng (failed) ay maaari lamang [`SeqCst`], [`Acquire`] o [`Relaxed`] at dapat na katumbas o mas mahina kaysa sa pag-order ng tagumpay.
            ///
            /// **Tandaan**: Magagamit lamang ang pamamaraang ito sa mga platform na sumusuporta sa pagpapatakbo ng atomic
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```rust
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let x = ", stringify!($atomic_type), "::new(7);")]
            /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(7));
            /// assert_eq! (x.fetch_update (Pag-order: : SeqCst, Ordering::SeqCst, | x | Some(x + 1)), Ok(7));
            /// assert_eq! (x.fetch_update (Pag-order: : SeqCst, Ordering::SeqCst, | x | Some(x + 1)), Ok(8));
            /// assert_eq!(x.load(Ordering::SeqCst), 9);
            /// ```
            #[inline]
            #[stable(feature = "no_more_cas", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_update<F>(&self,
                                   set_order: Ordering,
                                   fetch_order: Ordering,
                                   mut f: F) -> Result<$int_type, $int_type>
            where F: FnMut($int_type) -> Option<$int_type> {
                let mut prev = self.load(fetch_order);
                while let Some(next) = f(prev) {
                    match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                        x @ Ok(_) => return x,
                        Err(next_prev) => prev = next_prev
                    }
                }
                Err(prev)
            }

            /// Maximum sa kasalukuyang halaga.
            ///
            /// Mahahanap ang maximum ng kasalukuyang halaga at ang argument na `val`, at itinatakda ang bagong halaga sa resulta.
            ///
            /// Ibinabalik ang dating halaga.
            ///
            /// `fetch_max` tumatagal ng isang argumentong [`Ordering`] na naglalarawan sa pag-order ng memorya ng operasyong ito.Posible ang lahat ng mga mode sa pag-order.
            /// Tandaan na ang paggamit ng [`Acquire`] ay gumagawa ng bahagi ng tindahan ng operasyong [`Relaxed`] na ito, at ang paggamit ng [`Release`] ay gumagawa ng bahagi ng pag-load na [`Relaxed`].
            ///
            ///
            /// **Tandaan**: Magagamit lamang ang pamamaraang ito sa mga platform na sumusuporta sa pagpapatakbo ng atomic
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// assert_eq!(foo.fetch_max(42, Ordering::SeqCst), 23);
            /// assert_eq!(foo.load(Ordering::SeqCst), 42);
            /// ```
            ///
            /// If you want to obtain the maximum value in one step, you can use the following:
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// hayaan bar=42;
            /// hayaan ang max_foo=foo.fetch_max (bar, Ordering::SeqCst).max(bar);
            /// ! Igiit ang (max_foo==42);
            /// ```
            #[inline]
            #[stable(feature = "atomic_min_max", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_max(&self, val: $int_type, order: Ordering) -> $int_type {
                // KALIGTASAN: ang mga karera ng data ay pinipigilan ng mga atomic intrinsics.
                unsafe { $max_fn(self.v.get(), val, order) }
            }

            /// Minimum sa kasalukuyang halaga.
            ///
            /// Hinahanap ang minimum ng kasalukuyang halaga at ang argument `val`, at nagtatakda ng mga bagong halaga sa resulta.
            ///
            /// Ibinabalik ang dating halaga.
            ///
            /// `fetch_min` tumatagal ng isang argumentong [`Ordering`] na naglalarawan sa pag-order ng memorya ng operasyong ito.Posible ang lahat ng mga mode sa pag-order.
            /// Tandaan na ang paggamit ng [`Acquire`] ay gumagawa ng bahagi ng tindahan ng operasyong [`Relaxed`] na ito, at ang paggamit ng [`Release`] ay gumagawa ng bahagi ng pag-load na [`Relaxed`].
            ///
            ///
            /// **Tandaan**: Magagamit lamang ang pamamaraang ito sa mga platform na sumusuporta sa pagpapatakbo ng atomic
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// assert_eq!(foo.fetch_min(42, Ordering::Relaxed), 23);
            /// assert_eq!(foo.load(Ordering::Relaxed), 23);
            /// assert_eq!(foo.fetch_min(22, Ordering::Relaxed), 23);
            /// assert_eq!(foo.load(Ordering::Relaxed), 22);
            /// ```
            ///
            /// If you want to obtain the minimum value in one step, you can use the following:
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// hayaan bar=12;
            /// hayaan ang min_foo=foo.fetch_min (bar, Ordering::SeqCst).min(bar);
            /// assert_eq! (min_foo, 12);
            /// ```
            #[inline]
            #[stable(feature = "atomic_min_max", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_min(&self, val: $int_type, order: Ordering) -> $int_type {
                // KALIGTASAN: ang mga karera ng data ay pinipigilan ng mga atomic intrinsics.
                unsafe { $min_fn(self.v.get(), val, order) }
            }

            /// Nagbabalik ng isang nababagabag na pointer sa pinagbabatayan na integer.
            ///
            /// Ang paggawa ng mga di-atomic bumabasa at writes sa mga nagresultang integer ay maaaring maging isang data lahi.
            /// Ang pamamaraang ito ay higit na kapaki-pakinabang para sa FFI, kung saan maaaring magamit ang lagda ng pag-andar
            #[doc = concat!("`*mut ", stringify!($int_type), "` instead of `&", stringify!($atomic_type), "`.")]
            /// Ang pagbabalik ng isang `*mut` pointer mula sa isang nakabahaging sanggunian sa atomic na ito ay ligtas dahil gumagana ang mga uri ng atomic na may interior mutability.
            /// Ang lahat ng mga pagbabago ng isang atomic ay nagbabago ng halaga sa pamamagitan ng isang nakabahaging sanggunian, at maaaring gawin ito nang ligtas hangga't gumagamit sila ng mga atomic na operasyon.
            /// Ang anumang paggamit ng naibalik na hilaw na pointer ay nangangailangan ng isang `unsafe` block at kailangan pang panatilihin ang parehong paghihigpit: ang mga operasyon dito ay dapat na atomic.
            ///
            ///
            /// # Examples
            ///
            /// "huwag pansinin ang (extern-declaration)
            ///
            /// # fn main() {
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]
            /// extern "C" {
            #[doc = concat!("    fn my_atomic_op(arg: *mut ", stringify!($int_type), ");")]
            /// }
            ///
            #[doc = concat!("let mut atomic = ", stringify!($atomic_type), "::new(1);")]

            // KALIGTASAN: Ligtas basta `my_atomic_op` ay atomic.
            /// hindi ligtas {
            ///     my_atomic_op(atomic.as_mut_ptr());
            /// }
            /// # }
            /// ```
            #[inline]
            #[unstable(feature = "atomic_mut_ptr",
                   reason = "recently added",
                   issue = "66893")]
            pub fn as_mut_ptr(&self) -> *mut $int_type {
                self.v.get()
            }
        }
    }
}

#[cfg(target_has_atomic_load_store = "8")]
atomic_int! {
    cfg(target_has_atomic = "8"),
    cfg(target_has_atomic_equal_alignment = "8"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i8",
    "",
    atomic_min, atomic_max,
    1,
    "AtomicI8::new(0)",
    i8 AtomicI8 ATOMIC_I8_INIT
}
#[cfg(target_has_atomic_load_store = "8")]
atomic_int! {
    cfg(target_has_atomic = "8"),
    cfg(target_has_atomic_equal_alignment = "8"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u8",
    "",
    atomic_umin, atomic_umax,
    1,
    "AtomicU8::new(0)",
    u8 AtomicU8 ATOMIC_U8_INIT
}
#[cfg(target_has_atomic_load_store = "16")]
atomic_int! {
    cfg(target_has_atomic = "16"),
    cfg(target_has_atomic_equal_alignment = "16"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i16",
    "",
    atomic_min, atomic_max,
    2,
    "AtomicI16::new(0)",
    i16 AtomicI16 ATOMIC_I16_INIT
}
#[cfg(target_has_atomic_load_store = "16")]
atomic_int! {
    cfg(target_has_atomic = "16"),
    cfg(target_has_atomic_equal_alignment = "16"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u16",
    "",
    atomic_umin, atomic_umax,
    2,
    "AtomicU16::new(0)",
    u16 AtomicU16 ATOMIC_U16_INIT
}
#[cfg(target_has_atomic_load_store = "32")]
atomic_int! {
    cfg(target_has_atomic = "32"),
    cfg(target_has_atomic_equal_alignment = "32"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i32",
    "",
    atomic_min, atomic_max,
    4,
    "AtomicI32::new(0)",
    i32 AtomicI32 ATOMIC_I32_INIT
}
#[cfg(target_has_atomic_load_store = "32")]
atomic_int! {
    cfg(target_has_atomic = "32"),
    cfg(target_has_atomic_equal_alignment = "32"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u32",
    "",
    atomic_umin, atomic_umax,
    4,
    "AtomicU32::new(0)",
    u32 AtomicU32 ATOMIC_U32_INIT
}
#[cfg(target_has_atomic_load_store = "64")]
atomic_int! {
    cfg(target_has_atomic = "64"),
    cfg(target_has_atomic_equal_alignment = "64"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i64",
    "",
    atomic_min, atomic_max,
    8,
    "AtomicI64::new(0)",
    i64 AtomicI64 ATOMIC_I64_INIT
}
#[cfg(target_has_atomic_load_store = "64")]
atomic_int! {
    cfg(target_has_atomic = "64"),
    cfg(target_has_atomic_equal_alignment = "64"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u64",
    "",
    atomic_umin, atomic_umax,
    8,
    "AtomicU64::new(0)",
    u64 AtomicU64 ATOMIC_U64_INIT
}
#[cfg(target_has_atomic_load_store = "128")]
atomic_int! {
    cfg(target_has_atomic = "128"),
    cfg(target_has_atomic_equal_alignment = "128"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i128",
    "#![feature(integer_atomics)]\n\n",
    atomic_min, atomic_max,
    16,
    "AtomicI128::new(0)",
    i128 AtomicI128 ATOMIC_I128_INIT
}
#[cfg(target_has_atomic_load_store = "128")]
atomic_int! {
    cfg(target_has_atomic = "128"),
    cfg(target_has_atomic_equal_alignment = "128"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u128",
    "#![feature(integer_atomics)]\n\n",
    atomic_umin, atomic_umax,
    16,
    "AtomicU128::new(0)",
    u128 AtomicU128 ATOMIC_U128_INIT
}

macro_rules! atomic_int_ptr_sized {
    ( $($target_pointer_width:literal $align:literal)* ) => { $(
        #[cfg(target_has_atomic_load_store = "ptr")]
        #[cfg(target_pointer_width = $target_pointer_width)]
        atomic_int! {
            cfg(target_has_atomic = "ptr"),
            cfg(target_has_atomic_equal_alignment = "ptr"),
            stable(feature = "rust1", since = "1.0.0"),
            stable(feature = "extended_compare_and_swap", since = "1.10.0"),
            stable(feature = "atomic_debug", since = "1.3.0"),
            stable(feature = "atomic_access", since = "1.15.0"),
            stable(feature = "atomic_from", since = "1.23.0"),
            stable(feature = "atomic_nand", since = "1.27.0"),
            rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
            stable(feature = "rust1", since = "1.0.0"),
            "isize",
            "",
            atomic_min, atomic_max,
            $align,
            "AtomicIsize::new(0)",
            isize AtomicIsize ATOMIC_ISIZE_INIT
        }
        #[cfg(target_has_atomic_load_store = "ptr")]
        #[cfg(target_pointer_width = $target_pointer_width)]
        atomic_int! {
            cfg(target_has_atomic = "ptr"),
            cfg(target_has_atomic_equal_alignment = "ptr"),
            stable(feature = "rust1", since = "1.0.0"),
            stable(feature = "extended_compare_and_swap", since = "1.10.0"),
            stable(feature = "atomic_debug", since = "1.3.0"),
            stable(feature = "atomic_access", since = "1.15.0"),
            stable(feature = "atomic_from", since = "1.23.0"),
            stable(feature = "atomic_nand", since = "1.27.0"),
            rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
            stable(feature = "rust1", since = "1.0.0"),
            "usize",
            "",
            atomic_umin, atomic_umax,
            $align,
            "AtomicUsize::new(0)",
            usize AtomicUsize ATOMIC_USIZE_INIT
        }
    )* };
}

atomic_int_ptr_sized! {
    "16" 2
    "32" 4
    "64" 8
}

#[inline]
#[cfg(target_has_atomic = "8")]
fn strongest_failure_ordering(order: Ordering) -> Ordering {
    match order {
        Release => Relaxed,
        Relaxed => Relaxed,
        SeqCst => SeqCst,
        Acquire => Acquire,
        AcqRel => Acquire,
    }
}

#[inline]
unsafe fn atomic_store<T: Copy>(dst: *mut T, val: T, order: Ordering) {
    // KALIGTASAN: ang tumatawag ay dapat na itaguyod ang kaligtasan na kontrata para sa `atomic_store`.
    unsafe {
        match order {
            Release => intrinsics::atomic_store_rel(dst, val),
            Relaxed => intrinsics::atomic_store_relaxed(dst, val),
            SeqCst => intrinsics::atomic_store(dst, val),
            Acquire => panic!("there is no such thing as an acquire store"),
            AcqRel => panic!("there is no such thing as an acquire/release store"),
        }
    }
}

#[inline]
unsafe fn atomic_load<T: Copy>(dst: *const T, order: Ordering) -> T {
    // KALIGTASAN: ang tumatawag ay dapat na itaguyod ang kaligtasan na kontrata para sa `atomic_load`.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_load_acq(dst),
            Relaxed => intrinsics::atomic_load_relaxed(dst),
            SeqCst => intrinsics::atomic_load(dst),
            Release => panic!("there is no such thing as a release load"),
            AcqRel => panic!("there is no such thing as an acquire/release load"),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_swap<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // KALIGTASAN: ang tumatawag ay dapat na itaguyod ang kaligtasan na kontrata para sa `atomic_swap`.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xchg_acq(dst, val),
            Release => intrinsics::atomic_xchg_rel(dst, val),
            AcqRel => intrinsics::atomic_xchg_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xchg_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xchg(dst, val),
        }
    }
}

/// Ibinabalik ang nakaraang halaga (tulad ng __sync_fetch_and_add).
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_add<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // KALIGTASAN: ang tumatawag ay dapat na itaguyod ang kaligtasan na kontrata para sa `atomic_add`.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xadd_acq(dst, val),
            Release => intrinsics::atomic_xadd_rel(dst, val),
            AcqRel => intrinsics::atomic_xadd_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xadd_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xadd(dst, val),
        }
    }
}

/// Ibinabalik ang nakaraang halaga (tulad ng __sync_fetch_and_sub).
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_sub<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // KALIGTASAN: ang tumatawag ay dapat na itaguyod ang kaligtasan na kontrata para sa `atomic_sub`.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xsub_acq(dst, val),
            Release => intrinsics::atomic_xsub_rel(dst, val),
            AcqRel => intrinsics::atomic_xsub_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xsub_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xsub(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_compare_exchange<T: Copy>(
    dst: *mut T,
    old: T,
    new: T,
    success: Ordering,
    failure: Ordering,
) -> Result<T, T> {
    // KALIGTASAN: ang tumatawag ay dapat na itaguyod ang kaligtasan na kontrata para sa `atomic_compare_exchange`.
    let (val, ok) = unsafe {
        match (success, failure) {
            (Acquire, Acquire) => intrinsics::atomic_cxchg_acq(dst, old, new),
            (Release, Relaxed) => intrinsics::atomic_cxchg_rel(dst, old, new),
            (AcqRel, Acquire) => intrinsics::atomic_cxchg_acqrel(dst, old, new),
            (Relaxed, Relaxed) => intrinsics::atomic_cxchg_relaxed(dst, old, new),
            (SeqCst, SeqCst) => intrinsics::atomic_cxchg(dst, old, new),
            (Acquire, Relaxed) => intrinsics::atomic_cxchg_acq_failrelaxed(dst, old, new),
            (AcqRel, Relaxed) => intrinsics::atomic_cxchg_acqrel_failrelaxed(dst, old, new),
            (SeqCst, Relaxed) => intrinsics::atomic_cxchg_failrelaxed(dst, old, new),
            (SeqCst, Acquire) => intrinsics::atomic_cxchg_failacq(dst, old, new),
            (_, AcqRel) => panic!("there is no such thing as an acquire/release failure ordering"),
            (_, Release) => panic!("there is no such thing as a release failure ordering"),
            _ => panic!("a failure ordering can't be stronger than a success ordering"),
        }
    };
    if ok { Ok(val) } else { Err(val) }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_compare_exchange_weak<T: Copy>(
    dst: *mut T,
    old: T,
    new: T,
    success: Ordering,
    failure: Ordering,
) -> Result<T, T> {
    // KALIGTASAN: ang tumatawag ay dapat na itaguyod ang kaligtasan na kontrata para sa `atomic_compare_exchange_weak`.
    let (val, ok) = unsafe {
        match (success, failure) {
            (Acquire, Acquire) => intrinsics::atomic_cxchgweak_acq(dst, old, new),
            (Release, Relaxed) => intrinsics::atomic_cxchgweak_rel(dst, old, new),
            (AcqRel, Acquire) => intrinsics::atomic_cxchgweak_acqrel(dst, old, new),
            (Relaxed, Relaxed) => intrinsics::atomic_cxchgweak_relaxed(dst, old, new),
            (SeqCst, SeqCst) => intrinsics::atomic_cxchgweak(dst, old, new),
            (Acquire, Relaxed) => intrinsics::atomic_cxchgweak_acq_failrelaxed(dst, old, new),
            (AcqRel, Relaxed) => intrinsics::atomic_cxchgweak_acqrel_failrelaxed(dst, old, new),
            (SeqCst, Relaxed) => intrinsics::atomic_cxchgweak_failrelaxed(dst, old, new),
            (SeqCst, Acquire) => intrinsics::atomic_cxchgweak_failacq(dst, old, new),
            (_, AcqRel) => panic!("there is no such thing as an acquire/release failure ordering"),
            (_, Release) => panic!("there is no such thing as a release failure ordering"),
            _ => panic!("a failure ordering can't be stronger than a success ordering"),
        }
    };
    if ok { Ok(val) } else { Err(val) }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_and<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // KALIGTASAN: ang tumatawag ay dapat panindigan ang kontrata sa kaligtasan ng `atomic_and`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_and_acq(dst, val),
            Release => intrinsics::atomic_and_rel(dst, val),
            AcqRel => intrinsics::atomic_and_acqrel(dst, val),
            Relaxed => intrinsics::atomic_and_relaxed(dst, val),
            SeqCst => intrinsics::atomic_and(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_nand<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // KALIGTASAN: ang tumatawag ay dapat na itaguyod ang kaligtasan na kontrata para sa `atomic_nand`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_nand_acq(dst, val),
            Release => intrinsics::atomic_nand_rel(dst, val),
            AcqRel => intrinsics::atomic_nand_acqrel(dst, val),
            Relaxed => intrinsics::atomic_nand_relaxed(dst, val),
            SeqCst => intrinsics::atomic_nand(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_or<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // KALIGTASAN: ang tumatawag ay dapat panindigan ang kontrata sa kaligtasan ng `atomic_or`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_or_acq(dst, val),
            Release => intrinsics::atomic_or_rel(dst, val),
            AcqRel => intrinsics::atomic_or_acqrel(dst, val),
            Relaxed => intrinsics::atomic_or_relaxed(dst, val),
            SeqCst => intrinsics::atomic_or(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_xor<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // KALIGTASAN: ang tumatawag ay dapat na itaguyod ang kaligtasan na kontrata para sa `atomic_xor`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xor_acq(dst, val),
            Release => intrinsics::atomic_xor_rel(dst, val),
            AcqRel => intrinsics::atomic_xor_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xor_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xor(dst, val),
        }
    }
}

/// ibabalik ang max na halaga (naka-sign na paghahambing)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_max<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // KALIGTASAN: ang tumatawag ay dapat na itaguyod ang kaligtasan na kontrata para sa `atomic_max`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_max_acq(dst, val),
            Release => intrinsics::atomic_max_rel(dst, val),
            AcqRel => intrinsics::atomic_max_acqrel(dst, val),
            Relaxed => intrinsics::atomic_max_relaxed(dst, val),
            SeqCst => intrinsics::atomic_max(dst, val),
        }
    }
}

/// ibabalik ang halagang min (naka-sign na paghahambing)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_min<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // KALIGTASAN: ang tumatawag ay dapat na itaguyod ang kaligtasan na kontrata para sa `atomic_min`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_min_acq(dst, val),
            Release => intrinsics::atomic_min_rel(dst, val),
            AcqRel => intrinsics::atomic_min_acqrel(dst, val),
            Relaxed => intrinsics::atomic_min_relaxed(dst, val),
            SeqCst => intrinsics::atomic_min(dst, val),
        }
    }
}

/// nagbabalik ang max na halaga (unsigned paghahambing)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_umax<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // KALIGTASAN: ang tumatawag ay dapat na itaguyod ang kaligtasan na kontrata para sa `atomic_umax`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_umax_acq(dst, val),
            Release => intrinsics::atomic_umax_rel(dst, val),
            AcqRel => intrinsics::atomic_umax_acqrel(dst, val),
            Relaxed => intrinsics::atomic_umax_relaxed(dst, val),
            SeqCst => intrinsics::atomic_umax(dst, val),
        }
    }
}

/// ibabalik ang halagang min (hindi naka-sign na paghahambing)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_umin<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // KALIGTASAN: ang tumatawag ay dapat na itaguyod ang kaligtasan na kontrata para sa `atomic_umin`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_umin_acq(dst, val),
            Release => intrinsics::atomic_umin_rel(dst, val),
            AcqRel => intrinsics::atomic_umin_acqrel(dst, val),
            Relaxed => intrinsics::atomic_umin_relaxed(dst, val),
            SeqCst => intrinsics::atomic_umin(dst, val),
        }
    }
}

/// Isang bakod na atomic.
///
/// Nakasalalay sa tinukoy na pagkakasunud-sunod, pinipigilan ng isang bakod ang tagatala at CPU mula sa muling pag-ayos ng ilang mga uri ng pagpapatakbo ng memorya sa paligid nito.
/// Lumilikha iyon ng mga pag-synchronize-sa mga ugnayan sa pagitan nito at mga pagpapatakbo ng atomic o fences sa iba pang mga thread.
///
/// Ang isang bakod 'A' kung saan ay may (hindi bababa sa) [`Release`] pag-order semantics, Sini-synchronize sa isang bakod 'B' na may (hindi bababa sa) [`Acquire`] semantics, kung at tanging kung may umiiral na operasyon X at Y, parehong operating sa ilang mga atomic object 'M' tulad na A ay sequenced bago Ang X, Y ay na-synchronize bago obserbahan ng B at Y ang pagbabago sa M.
/// Nagbibigay ito ng isang pangyayari bago mangyari sa pagitan ng A at B.
///
/// ```text
///     Thread 1                                          Thread 2
///
/// fence(Release);      A --------------
/// x.store(3, Relaxed); X ---------    |
///                                |    |
///                                |    |
///                                -------------> Y  if x.load(Relaxed) == 3 {
///                                     |-------> B      fence(Acquire);
///                                                      ...
///                                                  }
/// ```
///
/// Ang mga pagpapatakbo ng atom na may [`Release`] o [`Acquire`] semantics ay maaari ding mag-synchronize sa isang bakod.
///
/// Ang isang bakod na may [`SeqCst`] pag-order, bilang karagdagan sa pagkakaroon ng parehong [`Acquire`] at [`Release`] semantics, lumalahok sa global program sunod ng mga iba pang mga pagpapaandar at/o fences [`SeqCst`].
///
/// Tumatanggap ng pag-order ng [`Acquire`], [`Release`], [`AcqRel`] at [`SeqCst`].
///
/// # Panics
///
/// Panics kung `order` ay [`Relaxed`].
///
/// # Examples
///
/// ```
/// use std::sync::atomic::AtomicBool;
/// use std::sync::atomic::fence;
/// use std::sync::atomic::Ordering;
///
/// // Ang isang mutual exclusion primitive batay sa spinlock.
/// pub struct Mutex {
///     flag: AtomicBool,
/// }
///
/// impl Mutex {
///     pub fn new() -> Mutex {
///         Mutex {
///             flag: AtomicBool::new(false),
///         }
///     }
///
///     pub fn lock(&self) {
///         // Maghintay hanggang sa ang dating halaga ay `false`.
///         while self.flag.compare_and_swap(false, true, Ordering::Relaxed) != false {}
///         // Ang bakod na ito ay sumasabay-sa tindahan sa `unlock`.
///         fence(Ordering::Acquire);
///     }
///
///     pub fn unlock(&self) {
///         self.flag.store(false, Ordering::Release);
///     }
/// }
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn fence(order: Ordering) {
    // KALIGTASAN: ligtas ang paggamit ng bakod na atomic.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_fence_acq(),
            Release => intrinsics::atomic_fence_rel(),
            AcqRel => intrinsics::atomic_fence_acqrel(),
            SeqCst => intrinsics::atomic_fence(),
            Relaxed => panic!("there is no such thing as a relaxed fence"),
        }
    }
}

/// Ang isang compiler memory bakod.
///
/// `compiler_fence` ay hindi naglalabas ng anumang code ng makina, ngunit nililimitahan ang mga uri ng memorya na muling pag-order ng pinapayagan na gawin ng tagatala.Partikular, nakasalalay sa ibinigay na [`Ordering`] semantics, ang compiler ay maaaring hindi pinapayagan mula sa paglipat ng mga nagbabasa o sumulat mula bago o pagkatapos ng tawag sa kabilang panig ng tawag sa `compiler_fence`.Tandaan na hindi ito **pinipigilan ang* hardware * mula sa paggawa ng naturang muling pag-order.
///
/// Ito ay hindi isang problema sa isang solong-sinulid, pagpapatupad konteksto, ngunit kapag ang ibang mga thread ay maaaring baguhin ang memory sa parehong oras, mas malakas na pag-synchronize primitives tulad ng [`fence`] ay kinakailangan.
///
/// Ang muling pag-order ay pinipigilan ng iba't ibang mga semantiko ng pag-order ay:
///
///  - na may [`SeqCst`], walang muling pag-order ng mga bumabasa at writes sa kabuuan puntong ito ay pinapayagan.
///  - na may [`Release`], naunang bumabasa at writes ay hindi maaaring ilipat nakaraang mga kasunod na writes.
///  - na may [`Acquire`], ang kasunod na mga pagbasa at pagsusulat ay hindi maaaring ilipat nang una sa mga naunang babasahin.
///  - na may [`AcqRel`], kapwa ng mga patakaran sa itaas ay ipinatutupad.
///
/// `compiler_fence` sa pangkalahatan ay kapaki-pakinabang lamang para sa pagpigil sa isang thread mula sa karera *gamit ang sarili*.Iyon ay, kung ang isang naibigay na thread ay nagpapatupad ng isang piraso ng code, at pagkatapos ay nagambala, at nagsisimulang ipatupad ang code sa ibang lugar (habang nasa parehong thread, at ayon sa konsepto ay nasa parehong core din).Sa tradisyunal na mga programa, maaari lamang itong maganap kapag ang isang signal handler ay nakarehistro.
/// Sa mas mababang antas ng code, ang mga naturang sitwasyon ay maaari ring lumabas kapag naghawak ng mga nakakagambala, kapag nagpapatupad ng berdeng mga thread na may paunang pag-emply, atbp.
/// Ang mga nagtataka na mambabasa ay hinihimok na basahin ang talakayan ng Linux kernel tungkol sa [memory barriers].
///
/// # Panics
///
/// Panics kung `order` ay [`Relaxed`].
///
/// # Examples
///
/// Nang walang `compiler_fence`, ang `assert_eq!` sa sumusunod na code ay *hindi* garantisadong magtagumpay, sa kabila ng lahat ng nangyayari sa isang solong thread.
/// Upang makita kung bakit, tandaan na ang compiler ay libre upang i-swap ang mga tindahan na `IMPORTANT_VARIABLE` at `IS_READ` dahil ang mga ito ang parehong `Ordering::Relaxed`.Kung gagawin ito, at ang humahawak ng signal ay naimbitahan pagkatapos mismo ng pag-update ng `IS_READY`, makikita ng signal ang handler ng `IS_READY=1`, ngunit `IMPORTANT_VARIABLE=0`.
/// Ang paggamit ng isang `compiler_fence` na remedyo sa sitwasyong ito.
///
/// ```
/// use std::sync::atomic::{AtomicBool, AtomicUsize};
/// use std::sync::atomic::Ordering;
/// use std::sync::atomic::compiler_fence;
///
/// static IMPORTANT_VARIABLE: AtomicUsize = AtomicUsize::new(0);
/// static IS_READY: AtomicBool = AtomicBool::new(false);
///
/// fn main() {
///     IMPORTANT_VARIABLE.store(42, Ordering::Relaxed);
///     // pigilan ang mas naunang pagsusulat mula sa paglipat ng higit sa puntong ito
///     compiler_fence(Ordering::Release);
///     IS_READY.store(true, Ordering::Relaxed);
/// }
///
/// fn signal_handler() {
///     if IS_READY.load(Ordering::Relaxed) {
///         assert_eq!(IMPORTANT_VARIABLE.load(Ordering::Relaxed), 42);
///     }
/// }
/// ```
///
/// [memory barriers]: https://www.kernel.org/doc/Documentation/memory-barriers.txt
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "compiler_fences", since = "1.21.0")]
pub fn compiler_fence(order: Ordering) {
    // KALIGTASAN: ligtas ang paggamit ng bakod na atomic.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_singlethreadfence_acq(),
            Release => intrinsics::atomic_singlethreadfence_rel(),
            AcqRel => intrinsics::atomic_singlethreadfence_acqrel(),
            SeqCst => intrinsics::atomic_singlethreadfence(),
            Relaxed => panic!("there is no such thing as a relaxed compiler fence"),
        }
    }
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "atomic_debug", since = "1.3.0")]
impl fmt::Debug for AtomicBool {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_debug", since = "1.3.0")]
impl<T> fmt::Debug for AtomicPtr<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_pointer", since = "1.24.0")]
impl<T> fmt::Pointer for AtomicPtr<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.load(Ordering::SeqCst), f)
    }
}

/// Senyales ang processor na nasa loob ito ng isang busy-wait spin-loop ("spin lock").
///
/// Ang pagpapaandar na ito ay hindi na ginugusto sa [`hint::spin_loop`].
///
/// [`hint::spin_loop`]: crate::hint::spin_loop
#[inline]
#[stable(feature = "spin_loop_hint", since = "1.24.0")]
#[rustc_deprecated(since = "1.51.0", reason = "use hint::spin_loop instead")]
pub fn spin_loop_hint() {
    spin_loop()
}