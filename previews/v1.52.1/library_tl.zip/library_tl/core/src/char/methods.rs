//! impl char {}

use crate::intrinsics::likely;
use crate::slice;
use crate::str::from_utf8_unchecked_mut;
use crate::unicode::printable::is_printable;
use crate::unicode::{self, conversions};

use super::*;

#[lang = "char"]
impl char {
    /// Ang pinakamataas na wastong code point na maaaring magkaroon ng `char`.
    ///
    /// Ang `char` ay isang [Unicode Scalar Value], na nangangahulugang ito ay isang [Code Point], ngunit ang mga nasa loob lamang ng isang tiyak na saklaw.
    /// `MAX` ay ang pinakamataas na wastong code point na isang wastong [Unicode Scalar Value].
    ///
    /// [Unicode Scalar Value]: http://www.unicode.org/glossary/#unicode_scalar_value
    /// [Code Point]: http://www.unicode.org/glossary/#code_point
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const MAX: char = '\u{10ffff}';

    /// `U+FFFD REPLACEMENT CHARACTER` Ginamit ang () sa Unicode upang kumatawan sa isang error sa pag-decode.
    ///
    /// Maaari itong mangyari, halimbawa, kapag nagbibigay ng hindi magandang nabuong UTF-8 bytes sa [`String::from_utf8_lossy`](string/struct.String.html#method.from_utf8_lossy).
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const REPLACEMENT_CHARACTER: char = '\u{FFFD}';

    /// Ang bersyon ng [Unicode](http://www.unicode.org/) na ang mga bahagi ng Unicode ng `char` at `str` na pamamaraan ay batay sa.
    ///
    /// Bagong bersyon ng Unicode ay inilabas nang regular at magkakasunod lahat ng mga pamamaraan sa standard library depende sa Unicode ay ina-update.
    /// Samakatuwid ang pag-uugali ng ilang mga `char` at `str` pamamaraan at ang halaga ng pare-pareho ang mga pagbabago sa paglipas ng panahon.
    /// Ito ay *hindi* itinuturing na isang paglabag sa pagbabago.
    ///
    /// Ang scheme ng pagnunumero ng bersyon ay ipinaliwanag sa [Unicode 11.0 or later, Section 3.1 Versions of the Unicode Standard](https://www.unicode.org/versions/Unicode11.0.0/ch03.pdf#page=4).
    ///
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const UNICODE_VERSION: (u8, u8, u8) = crate::unicode::UNICODE_VERSION;

    /// Lumilikha ng isang iterator sa UTF-16 na naka-encode ng mga puntos ng code sa `iter`, na binabalik ang mga hindi pares na mga kahalili bilang `Err`s.
    ///
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// use std::char::decode_utf16;
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///         .map(|r| r.map_err(|e| e.unpaired_surrogate()))
    ///         .collect::<Vec<_>>(),
    ///     vec![
    ///         Ok('𝄞'),
    ///         Ok('m'), Ok('u'), Ok('s'),
    ///         Err(0xDD1E),
    ///         Ok('i'), Ok('c'),
    ///         Err(0xD834)
    ///     ]
    /// );
    /// ```
    ///
    /// Ang isang lossy decoder ay maaaring makuha sa pamamagitan ng pagpapalit ng mga resulta ng `Err` ng kapalit na character:
    ///
    /// ```
    /// use std::char::{decode_utf16, REPLACEMENT_CHARACTER};
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///        .map(|r| r.unwrap_or(REPLACEMENT_CHARACTER))
    ///        .collect::<String>(),
    ///     "𝄞mus�ic�"
    /// );
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn decode_utf16<I: IntoIterator<Item = u16>>(iter: I) -> DecodeUtf16<I::IntoIter> {
        super::decode::decode_utf16(iter)
    }

    /// Binabago ang isang `u32` sa isang `char`.
    ///
    /// Tandaan na ang lahat ng `char`s ay may-bisa [`u32`] s, at maaaring ma-cast sa isa na may
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// Gayunpaman, hindi totoo ang baligtad: hindi lahat ng wastong [`u32`] ay wastong`char`s.
    /// `from_u32()` ay babalik `None` kung ang input ay hindi isang wastong halaga para sa isang `char`.
    ///
    /// Para sa isang hindi ligtas na bersyon ng pagpapaandar na ito na hindi pinapansin ang mga pagsusuri na ito, tingnan ang [`from_u32_unchecked`].
    ///
    ///
    /// [`from_u32_unchecked`]: #method.from_u32_unchecked
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x2764);
    ///
    /// assert_eq!(Some('❤'), c);
    /// ```
    ///
    /// Ibinabalik ang `None` kapag ang input ay hindi wastong `char`:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x110000);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_u32(i: u32) -> Option<char> {
        super::convert::from_u32(i)
    }

    /// Binabago ang isang `u32` sa isang `char`, hindi pinapansin ang bisa.
    ///
    /// Tandaan na ang lahat ng `char`s ay may-bisa [`u32`] s, at maaaring ma-cast sa isa na may
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// Gayunpaman, hindi totoo ang baligtad: hindi lahat ng wastong [`u32`] ay wastong`char`s.
    /// `from_u32_unchecked()` hindi ito papansinin, at bulag na i-cast sa `char`, posibleng lumilikha ng hindi wasto.
    ///
    ///
    /// # Safety
    ///
    /// Ang pag-andar na ito ay hindi ligtas, dahil maaari itong bumuo ng hindi wastong mga halagang `char`.
    ///
    /// Para sa isang ligtas na bersyon ng function na ito, tingnan ang [`from_u32`] function.
    ///
    /// [`from_u32`]: #method.from_u32
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = unsafe { char::from_u32_unchecked(0x2764) };
    ///
    /// assert_eq!('❤', c);
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub unsafe fn from_u32_unchecked(i: u32) -> char {
        // KALIGTASAN: ang kontrata sa kaligtasan ay dapat na panatilihin ng tumatawag.
        unsafe { super::convert::from_u32_unchecked(i) }
    }

    /// Nagko-convert ng isang digit sa ibinigay na radix sa isang `char`.
    ///
    /// Ang isang 'radix' dito kung minsan ay tinatawag ding 'base'.
    /// Ang isang radix ng dalawa ay nagpapahiwatig ng isang binary number, isang radix ng sampung, decimal, at isang radix na labing-anim, hexadecimal, upang magbigay ng ilang mga karaniwang halaga.
    ///
    /// Sinusuportahan ang di-makatwirang mga radice.
    ///
    /// `from_digit()` ibabalik ang `None` kung ang input ay hindi isang digit sa ibinigay na radix.
    ///
    /// # Panics
    ///
    /// Panics kung bibigyan ng isang radix na mas malaki sa 36.
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(4, 10);
    ///
    /// assert_eq!(Some('4'), c);
    ///
    /// // Ang Decimal 11 ay isang solong digit sa base 16
    /// let c = char::from_digit(11, 16);
    ///
    /// assert_eq!(Some('b'), c);
    /// ```
    ///
    /// Bumabalik `None` kapag ang input ay hindi isang digit:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(20, 10);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    /// Pagpasa ng isang malaking radix, na nagiging sanhi ng isang panic:
    ///
    /// ```should_panic
    /// use std::char;
    ///
    /// // this panics
    /// char::from_digit(1, 37);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_digit(num: u32, radix: u32) -> Option<char> {
        super::convert::from_digit(num, radix)
    }

    /// Sinusuri kung ang isang `char` ay isang digit sa ibinigay na radix.
    ///
    /// Ang isang 'radix' dito kung minsan ay tinatawag ding 'base'.
    /// Ang isang radix ng dalawa ay nagpapahiwatig ng isang binary number, isang radix ng sampung, decimal, at isang radix na labing-anim, hexadecimal, upang magbigay ng ilang mga karaniwang halaga.
    ///
    /// Sinusuportahan ang di-makatwirang mga radice.
    ///
    /// Kung ikukumpara sa [`is_numeric()`], function na ito ay kumikilala lamang ang mga character `0-9`, `a-z` at `A-Z`.
    ///
    /// 'Digit' ay tinukoy na magiging sumusunod lamang na mga character:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// Para sa isang mas komprehensibong pag-unawa sa 'digit', tingnan ang [`is_numeric()`].
    ///
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Panics
    ///
    /// Panics kung bibigyan ng isang radix na mas malaki sa 36.
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// assert!('1'.is_digit(10));
    /// assert!('f'.is_digit(16));
    /// assert!(!'f'.is_digit(10));
    /// ```
    ///
    /// Pagpasa ng isang malaking radix, na nagiging sanhi ng isang panic:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.is_digit(37);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_digit(self, radix: u32) -> bool {
        self.to_digit(radix).is_some()
    }

    /// Nagko-convert ng `char` sa isang digit sa ibinigay na radix.
    ///
    /// Ang isang 'radix' dito kung minsan ay tinatawag ding 'base'.
    /// Ang isang radix ng dalawa ay nagpapahiwatig ng isang binary number, isang radix ng sampung, decimal, at isang radix na labing-anim, hexadecimal, upang magbigay ng ilang mga karaniwang halaga.
    ///
    /// Sinusuportahan ang di-makatwirang mga radice.
    ///
    /// 'Digit' ay tinukoy na magiging sumusunod lamang na mga character:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// # Errors
    ///
    /// Ibinabalik `None` kung ang `char` ay hindi tumutukoy sa isang digit sa isang partikular na radix.
    ///
    /// # Panics
    ///
    /// Panics kung bibigyan ng isang radix na mas malaki sa 36.
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// assert_eq!('1'.to_digit(10), Some(1));
    /// assert_eq!('f'.to_digit(16), Some(15));
    /// ```
    ///
    /// Ang pagpasa sa isang di-digit na mga resulta sa pagkabigo:
    ///
    /// ```
    /// assert_eq!('f'.to_digit(10), None);
    /// assert_eq!('z'.to_digit(16), None);
    /// ```
    ///
    /// Pagpasa ng isang malaking radix, na nagiging sanhi ng isang panic:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.to_digit(37);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_digit(self, radix: u32) -> Option<u32> {
        assert!(radix <= 36, "to_digit: radix is too high (maximum 36)");
        // ang code ay maghiwalay upang pagbutihin ang pagpapatupad bilis para sa mga kaso kung saan ang mga `radix` ay pare-pareho at 10 o mas maliit
        //
        let val = if likely(radix <= 10) {
            // Kung hindi isang digit, isang numero na mas malaki sa radix ang malilikha.
            (self as u32).wrapping_sub('0' as u32)
        } else {
            match self {
                '0'..='9' => self as u32 - '0' as u32,
                'a'..='z' => self as u32 - 'a' as u32 + 10,
                'A'..='Z' => self as u32 - 'A' as u32 + 10,
                _ => return None,
            }
        };

        if val < radix { Some(val) } else { None }
    }

    /// Ibinabalik ng isang iterator na magbubunga ang hexadecimal Unicode pagtakas ng isang character tulad ng `char`s.
    ///
    /// Makakatakas ito sa mga character na may syntax na Rust ng form `\u{NNNNNN}` kung saan ang `NNNNNN` ay isang hexadecimal na representasyon.
    ///
    ///
    /// # Examples
    ///
    /// Bilang isang iterator:
    ///
    /// ```
    /// for c in '❤'.escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Direktang paggamit ng `println!`:
    ///
    /// ```
    /// println!("{}", '❤'.escape_unicode());
    /// ```
    ///
    /// Ang parehong ay katumbas ng:
    ///
    /// ```
    /// println!("\\u{{2764}}");
    /// ```
    ///
    /// Paggamit ng `to_string`:
    ///
    /// ```
    /// assert_eq!('❤'.escape_unicode().to_string(), "\\u{2764}");
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_unicode(self) -> EscapeUnicode {
        let c = self as u32;

        // o-ing 1 tinitiyak na para sa c==0 kinakalkula ng code na ang isang digit ay dapat na nakalimbag at (na magkapareho) iniiwasan ang (31, 32) underflow
        //
        //
        let msb = 31 - (c | 1).leading_zeros();

        // ang index ng pinaka makabuluhang hex digit
        let ms_hex_digit = msb / 4;
        EscapeUnicode {
            c: self,
            state: EscapeUnicodeState::Backslash,
            hex_digit_idx: ms_hex_digit as usize,
        }
    }

    /// Ang isang pinalawak na bersyon ng `escape_debug` na opsyonal Pinahihintulutan ng escaping Pinalawak Grapheme codepoints.
    /// Pinapayagan kaming mag-format ng mga character na mas mahusay sa pag-format ng mga marka kapag nasa simula ng isang string ang mga ito.
    ///
    #[inline]
    pub(crate) fn escape_debug_ext(self, escape_grapheme_extended: bool) -> EscapeDebug {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            _ if escape_grapheme_extended && self.is_grapheme_extended() => {
                EscapeDefaultState::Unicode(self.escape_unicode())
            }
            _ if is_printable(self) => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDebug(EscapeDefault { state: init_state })
    }

    /// Nagbabalik ng isang umuulit na nagbubunga ng literal na makatakas na code ng isang character bilang `char`s.
    ///
    /// Tatakas ito sa mga character na katulad ng pagpapatupad ng `Debug` ng `str` o `char`.
    ///
    ///
    /// # Examples
    ///
    /// Bilang isang iterator:
    ///
    /// ```
    /// for c in '\n'.escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Direktang paggamit ng `println!`:
    ///
    /// ```
    /// println!("{}", '\n'.escape_debug());
    /// ```
    ///
    /// Ang parehong ay katumbas ng:
    ///
    /// ```
    /// println!("\\n");
    /// ```
    ///
    /// Paggamit ng `to_string`:
    ///
    /// ```
    /// assert_eq!('\n'.escape_debug().to_string(), "\\n");
    /// ```
    ///
    #[stable(feature = "char_escape_debug", since = "1.20.0")]
    #[inline]
    pub fn escape_debug(self) -> EscapeDebug {
        self.escape_debug_ext(true)
    }

    /// Nagbabalik ng isang umuulit na nagbubunga ng literal na makatakas na code ng isang character bilang `char`s.
    ///
    /// Ang default ay pinili na may isang bias patungo sa paggawa literals na legal sa iba't ibang mga wika, kabilang ang C++ 11 at mga katulad na C-family wika.
    /// Ang eksaktong mga patakaran ay:
    ///
    /// * Ang tab ay nakatakas bilang `\t`.
    /// * Ang pagbalik ng karwahe ay nakatakas bilang `\r`.
    /// * Ang feed ng linya ay nakatakas bilang `\n`.
    /// * Single quote ay nakatanan na parang `\'`.
    /// * Ang dobleng quote ay nakatakas bilang `\"`.
    /// * Ang backslash ay nakatakas bilang `\\`.
    /// * Ang anumang character sa saklaw na 'nai-print ASCII' na `0x20` .. kasama ang `0x7e` ay hindi nakatakas.
    /// * Ang lahat ng iba pang mga character ay binibigyan ng hexadecimal Unicode makatakas;tingnan ang [`escape_unicode`].
    ///
    /// [`escape_unicode`]: #method.escape_unicode
    ///
    /// # Examples
    ///
    /// Bilang isang iterator:
    ///
    /// ```
    /// for c in '"'.escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Direktang paggamit ng `println!`:
    ///
    /// ```
    /// println!("{}", '"'.escape_default());
    /// ```
    ///
    /// Ang parehong ay katumbas ng:
    ///
    /// ```
    /// println!("\\\"");
    /// ```
    ///
    /// Paggamit ng `to_string`:
    ///
    /// ```
    /// assert_eq!('"'.escape_default().to_string(), "\\\"");
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_default(self) -> EscapeDefault {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            '\x20'..='\x7e' => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDefault { state: init_state }
    }

    /// Ibinabalik ang bilang ng mga byte na kakailanganin ng `char` na ito kung naka-encode sa UTF-8.
    ///
    /// Ang bilang ng mga byte ay laging nasa pagitan ng 1 at 4, kasama.
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// let len = 'A'.len_utf8();
    /// assert_eq!(len, 1);
    ///
    /// let len = 'ß'.len_utf8();
    /// assert_eq!(len, 2);
    ///
    /// let len = 'ℝ'.len_utf8();
    /// assert_eq!(len, 3);
    ///
    /// let len = '💣'.len_utf8();
    /// assert_eq!(len, 4);
    /// ```
    ///
    /// Ang `&str` i-type ang mga garantiya na ang mga nilalaman nito ay UTF-8, at upang maaari naming ihambing ang haba nais itong tumagal kung ang bawat code point ay kinakatawan bilang isang `char` vs sa `&str` mismo:
    ///
    ///
    /// ```
    /// // bilang chars
    /// let eastern = '東';
    /// let capital = '京';
    ///
    /// // parehong maaaring katawanin bilang tatlong bytes
    /// assert_eq!(3, eastern.len_utf8());
    /// assert_eq!(3, capital.len_utf8());
    ///
    /// // bilang isang &str, ang dalawang ito ay naka-encode sa UTF-8
    /// let tokyo = "東京";
    ///
    /// let len = eastern.len_utf8() + capital.len_utf8();
    ///
    /// // maaari nating makita na tumagal sila ng anim na bytes sa kabuuan ...
    /// assert_eq!(6, tokyo.len());
    ///
    /// // ... tulad ng &str
    /// assert_eq!(len, tokyo.len());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf8(self) -> usize {
        len_utf8(self as u32)
    }

    /// Ibinabalik ang bilang ng mga 16-bit mga yunit code na ito `char` kakailanganin kung naka-encode sa UTF-16.
    ///
    ///
    /// Tingnan ang dokumentasyon para [`len_utf8()`] para sa karagdagang paliwanag ng konsepto na ito.
    /// Ang pagpapaandar na ito ay isang salamin, ngunit para sa UTF-16 sa halip na UTF-8.
    ///
    /// [`len_utf8()`]: #method.len_utf8
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// let n = 'ß'.len_utf16();
    /// assert_eq!(n, 1);
    ///
    /// let len = '💣'.len_utf16();
    /// assert_eq!(len, 2);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf16(self) -> usize {
        let ch = self as u32;
        if (ch & 0xFFFF) == ch { 1 } else { 2 }
    }

    /// Na-encode ang character na ito bilang UTF-8 sa ibinigay na byte buffer, at pagkatapos ay ibabalik ang subslice ng buffer na naglalaman ng naka-encode na character.
    ///
    ///
    /// # Panics
    ///
    /// Panics kung ang buffer ay hindi malaki sapat.
    /// Ang isang buffer haba ng apat na ay malaki sapat na upang i-encode ang anumang `char`.
    ///
    /// # Examples
    ///
    /// Sa dalawang mga halimbawang ito, 'ß' ay tumatagal ng dalawang bytes upang i-encode.
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = 'ß'.encode_utf8(&mut b);
    ///
    /// assert_eq!(result, "ß");
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// Isang buffer na napakaliit:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// 'ß'.encode_utf8(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf8(self, dst: &mut [u8]) -> &mut str {
        // KALIGTASAN: Ang `char` ay hindi isang kahalili, kaya't ito ay wastong UTF-8.
        unsafe { from_utf8_unchecked_mut(encode_utf8_raw(self as u32, dst)) }
    }

    /// Na-encode ang character na ito bilang UTF-16 sa ibinigay na `u16` buffer, at pagkatapos ay ibabalik ang subslice ng buffer na naglalaman ng naka-encode na character.
    ///
    ///
    /// # Panics
    ///
    /// Panics kung ang buffer ay hindi malaki sapat.
    /// Ang isang buffer ng haba 2 ay sapat na malaki upang ma-encode ang anumang `char`.
    ///
    /// # Examples
    ///
    /// Sa pareho ng mga halimbawang ito, tumatagal ang '𝕊' ng dalawang `u16` upang ma-encode.
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = '𝕊'.encode_utf16(&mut b);
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// Isang buffer na napakaliit:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// '𝕊'.encode_utf16(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf16(self, dst: &mut [u16]) -> &mut [u16] {
        encode_utf16_raw(self as u32, dst)
    }

    /// Ibinabalik `true` kung ito `char` may `Alphabetic` ari-arian.
    ///
    /// `Alphabetic` ay inilarawan sa Kabanata 4 (Character Properties) ng [Unicode Standard] at tinukoy sa [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// assert!('a'.is_alphabetic());
    /// assert!('京'.is_alphabetic());
    ///
    /// let c = '💝';
    /// // ang pag-ibig ay maraming bagay, ngunit hindi ito ayon sa alpabetiko
    /// assert!(!c.is_alphabetic());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphabetic(self) -> bool {
        match self {
            'a'..='z' | 'A'..='Z' => true,
            c => c > '\x7f' && unicode::Alphabetic(c),
        }
    }

    /// Ibinabalik ang `true` kung ang `char` na ito ay mayroong `Lowercase` na pag-aari.
    ///
    /// `Lowercase` ay inilarawan sa Kabanata 4 (Character Properties) ng [Unicode Standard] at tinukoy sa [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// assert!('a'.is_lowercase());
    /// assert!('δ'.is_lowercase());
    /// assert!(!'A'.is_lowercase());
    /// assert!(!'Δ'.is_lowercase());
    ///
    /// // Ang iba't ibang mga script at bantas ng Intsik ay walang kaso, at iba pa:
    /// assert!(!'中'.is_lowercase());
    /// assert!(!' '.is_lowercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_lowercase(self) -> bool {
        match self {
            'a'..='z' => true,
            c => c > '\x7f' && unicode::Lowercase(c),
        }
    }

    /// Ibinabalik ang `true` kung ang `char` na ito ay mayroong `Uppercase` na pag-aari.
    ///
    /// `Uppercase` ay inilarawan sa Kabanata 4 (Character Properties) ng [Unicode Standard] at tinukoy sa [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// assert!(!'a'.is_uppercase());
    /// assert!(!'δ'.is_uppercase());
    /// assert!('A'.is_uppercase());
    /// assert!('Δ'.is_uppercase());
    ///
    /// // Ang iba't ibang mga script at bantas ng Intsik ay walang kaso, at iba pa:
    /// assert!(!'中'.is_uppercase());
    /// assert!(!' '.is_uppercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_uppercase(self) -> bool {
        match self {
            'A'..='Z' => true,
            c => c > '\x7f' && unicode::Uppercase(c),
        }
    }

    /// Ibinabalik `true` kung ito `char` may `White_Space` ari-arian.
    ///
    /// `White_Space` ay tinukoy sa [Unicode Character Database][ucd] [`PropList.txt`].
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`PropList.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/PropList.txt
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// assert!(' '.is_whitespace());
    ///
    /// // isang non-breaking na espasyo
    /// assert!('\u{A0}'.is_whitespace());
    ///
    /// assert!(!'越'.is_whitespace());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_whitespace(self) -> bool {
        match self {
            ' ' | '\x09'..='\x0d' => true,
            c => c > '\x7f' && unicode::White_Space(c),
        }
    }

    /// Ibinabalik ang `true` kung ang `char` na ito ay nasisiyahan alinman sa [`is_alphabetic()`] o [`is_numeric()`].
    ///
    /// [`is_alphabetic()`]: #method.is_alphabetic
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// assert!('٣'.is_alphanumeric());
    /// assert!('7'.is_alphanumeric());
    /// assert!('৬'.is_alphanumeric());
    /// assert!('¾'.is_alphanumeric());
    /// assert!('①'.is_alphanumeric());
    /// assert!('K'.is_alphanumeric());
    /// assert!('و'.is_alphanumeric());
    /// assert!('藏'.is_alphanumeric());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphanumeric(self) -> bool {
        self.is_alphabetic() || self.is_numeric()
    }

    /// Ibinabalik ang `true` kung ang `char` na ito ay may pangkalahatang kategorya para sa mga control code.
    ///
    /// Ang mga control code (mga puntos ng code na may pangkalahatang kategorya ng `Cc`) ay inilarawan sa Kabanata 4 (Mga Katangian ng Character) ng [Unicode Standard] at tinukoy sa [Unicode Character Database][ucd] [`UnicodeData.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// // U + 009C, STRING TERMINATOR
    /// assert!(''.is_control());
    /// assert!(!'q'.is_control());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_control(self) -> bool {
        unicode::Cc(self)
    }

    /// Ibinabalik ang `true` kung ang `char` na ito ay mayroong `Grapheme_Extend` na pag-aari.
    ///
    /// `Grapheme_Extend` ay inilarawan sa [Unicode Standard Annex #29 (Unicode Text Segmentation)][uax29] at tinukoy sa [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [uax29]: https://www.unicode.org/reports/tr29/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    #[inline]
    pub(crate) fn is_grapheme_extended(self) -> bool {
        unicode::Grapheme_Extend(self)
    }

    /// Ibinabalik ang `true` kung ang `char` na ito ay may isa sa mga pangkalahatang kategorya para sa mga numero.
    ///
    /// Ang pangkalahatang mga kategorya para sa mga numero (`Nd` para sa mga decimal digit, `Nl` liham-tulad numeric character, at `No` para sa ibang mga numeric character) ay tinukoy sa [Unicode Character Database][ucd] [`UnicodeData.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// assert!('٣'.is_numeric());
    /// assert!('7'.is_numeric());
    /// assert!('৬'.is_numeric());
    /// assert!('¾'.is_numeric());
    /// assert!('①'.is_numeric());
    /// assert!(!'K'.is_numeric());
    /// assert!(!'و'.is_numeric());
    /// assert!(!'藏'.is_numeric());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_numeric(self) -> bool {
        match self {
            '0'..='9' => true,
            c => c > '\x7f' && unicode::N(c),
        }
    }

    /// Nagbabalik ng isang iterator na nagbubunga ng maliit na maliit na pagmamapa ng `char` na ito bilang isa o higit pa
    /// `char`s.
    ///
    /// Kung ang `char` na ito ay walang isang maliit na maliit na pagmamapa, ang iterator ay magbubunga ng parehong `char`.
    ///
    /// Kung ang `char` na ito ay may isang isang maliit na maliliit na pagmamapa na ibinigay ng [Unicode Character Database][ucd] [`UnicodeData.txt`], ang iterator ay magbubunga ng `char` na iyon.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// Kung ang `char` na ito ay nangangailangan ng mga espesyal na pagsasaalang-alang (hal. Maraming `char`s) ang iterator ay nagbubunga ng`char` (s) na ibinigay ng [`SpecialCasing.txt`].
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// Gumagawa ang operasyong ito ng isang walang kondisyon na pagmamapa nang hindi pinasadya.Iyon ay, ang conversion ay malaya sa konteksto at wika.
    ///
    /// Sa [Unicode Standard], Kabanata 4 (Character Properties) Tinatalakay kasong pagmamapa sa pangkalahatan at Kabanata 3 (Conformance) tinatalakay ang default na algorithm para sa kasong conversion.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// Bilang isang iterator:
    ///
    /// ```
    /// for c in 'İ'.to_lowercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Direktang paggamit ng `println!`:
    ///
    /// ```
    /// println!("{}", 'İ'.to_lowercase());
    /// ```
    ///
    /// Ang parehong ay katumbas ng:
    ///
    /// ```
    /// println!("i\u{307}");
    /// ```
    ///
    /// Paggamit ng `to_string`:
    ///
    /// ```
    /// assert_eq!('C'.to_lowercase().to_string(), "c");
    ///
    /// // Minsan ang resulta ay higit sa isang character:
    /// assert_eq!('İ'.to_lowercase().to_string(), "i\u{307}");
    ///
    /// // Ang mga character na walang parehong malalaki at maliit na titik ay nagko-convert sa kanilang sarili.
    /////
    /// assert_eq!('山'.to_lowercase().to_string(), "山");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_lowercase(self) -> ToLowercase {
        ToLowercase(CaseMappingIter::new(conversions::to_lower(self)))
    }

    /// Nagbabalik ng isang umuulit na magbubunga ng malalaking mapa ng `char` na ito bilang isa o higit pa
    /// `char`s.
    ///
    /// Kung ang `char` na ito ay walang isang malakihang pagmamapa, ang iterator ay magbubunga ng parehong `char`.
    ///
    /// Kung ang `char` na ito ay may isa-sa-isang malalaking pagmamapa na ibinigay ng [Unicode Character Database][ucd] [`UnicodeData.txt`], ang iterator ay magbubunga ng `char` na iyon.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// Kung ang `char` na ito ay nangangailangan ng mga espesyal na pagsasaalang-alang (hal. Maraming `char`s) ang iterator ay nagbubunga ng`char` (s) na ibinigay ng [`SpecialCasing.txt`].
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// Gumagawa ang operasyong ito ng isang walang kondisyon na pagmamapa nang hindi pinasadya.Iyon ay, ang conversion ay malaya sa konteksto at wika.
    ///
    /// Sa [Unicode Standard], Kabanata 4 (Character Properties) Tinatalakay kasong pagmamapa sa pangkalahatan at Kabanata 3 (Conformance) tinatalakay ang default na algorithm para sa kasong conversion.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// Bilang isang iterator:
    ///
    /// ```
    /// for c in 'ß'.to_uppercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Direktang paggamit ng `println!`:
    ///
    /// ```
    /// println!("{}", 'ß'.to_uppercase());
    /// ```
    ///
    /// Ang parehong ay katumbas ng:
    ///
    /// ```
    /// println!("SS");
    /// ```
    ///
    /// Paggamit ng `to_string`:
    ///
    /// ```
    /// assert_eq!('c'.to_uppercase().to_string(), "C");
    ///
    /// // Minsan ang resulta ay higit sa isang character:
    /// assert_eq!('ß'.to_uppercase().to_string(), "SS");
    ///
    /// // Ang mga character na walang parehong malalaki at maliit na titik ay nagko-convert sa kanilang sarili.
    /////
    /// assert_eq!('山'.to_uppercase().to_string(), "山");
    /// ```
    ///
    /// # Tandaan sa lokal
    ///
    /// Sa Turkish, ang katumbas ng 'i' sa Latin ay may limang mga form sa halip na dalawa:
    ///
    /// * 'Dotless': Ako/, minsan nakasulat ï
    /// * 'Dotted': İ/i
    ///
    /// Tandaan na ang maliit na tuldok na may tuldok 'i' ay pareho ng Latin.Samakatuwid:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    /// ```
    ///
    /// Ang halaga ng `upper_i` dito ay nakasalalay sa wika ng teksto: kung nasa `en-US` tayo, dapat itong `"I"`, ngunit kung nasa `tr_TR` tayo, dapat itong `"İ"`.
    /// `to_uppercase()` ay hindi kumuha ito sa account, at iba pa:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    ///
    /// assert_eq!(upper_i, "I");
    /// ```
    ///
    /// humahawak sa mga wika.
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_uppercase(self) -> ToUppercase {
        ToUppercase(CaseMappingIter::new(conversions::to_upper(self)))
    }

    /// Sinusuri kung ang halaga ay nasa loob ng saklaw ng ASCII.
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.32.0")]
    #[inline]
    pub const fn is_ascii(&self) -> bool {
        *self as u32 <= 0x7F
    }

    /// Gumagawa ng isang kopya ng halaga sa katumbas nitong ASCII sa itaas na kaso.
    ///
    /// Ang mga titik ng ASCII 'a' hanggang 'z' ay nai-map sa 'A' hanggang 'Z', ngunit ang mga hindi ASCII na titik ay hindi nagbabago.
    ///
    /// Upang mai-uppercase ang in-place na halaga, gamitin ang [`make_ascii_uppercase()`].
    ///
    /// Upang itaas ang mga character na ASCII bilang karagdagan sa mga hindi ASCII na character, gamitin ang [`to_uppercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('A', ascii.to_ascii_uppercase());
    /// assert_eq!('❤', non_ascii.to_ascii_uppercase());
    /// ```
    ///
    /// [`make_ascii_uppercase()`]: #method.make_ascii_uppercase
    /// [`to_uppercase()`]: #method.to_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_uppercase(&self) -> char {
        if self.is_ascii_lowercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// Gagawa ng isang kopya ng ang halaga sa kanyang ASCII mas mababa katumbas kaso.
    ///
    /// ASCII titik 'A' na 'Z' ay nama-map sa 'a' na 'z', ngunit hindi ASCII mga titik ay hindi magbabago.
    ///
    /// Sa lowercase ang halaga ng in-lugar, gamitin [`make_ascii_lowercase()`].
    ///
    /// Upang maliliit ang mga character na ASCII bilang karagdagan sa mga character na hindi ASCII, gamitin ang [`to_lowercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'A';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('a', ascii.to_ascii_lowercase());
    /// assert_eq!('❤', non_ascii.to_ascii_lowercase());
    /// ```
    ///
    /// [`make_ascii_lowercase()`]: #method.make_ascii_lowercase
    /// [`to_lowercase()`]: #method.to_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_lowercase(&self) -> char {
        if self.is_ascii_uppercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// Sinusuri na ang dalawang halaga ay isang ASCII case-insensitive match.
    ///
    /// Katumbas ng `to_ascii_lowercase(a) == to_ascii_lowercase(b)`.
    ///
    /// # Examples
    ///
    /// ```
    /// let upper_a = 'A';
    /// let lower_a = 'a';
    /// let lower_z = 'z';
    ///
    /// assert!(upper_a.eq_ignore_ascii_case(&lower_a));
    /// assert!(upper_a.eq_ignore_ascii_case(&upper_a));
    /// assert!(!upper_a.eq_ignore_ascii_case(&lower_z));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn eq_ignore_ascii_case(&self, other: &char) -> bool {
        self.to_ascii_lowercase() == other.to_ascii_lowercase()
    }

    /// Kino-convert ng ganitong uri sa kanyang ASCII upper case katumbas in-lugar.
    ///
    /// Ang mga titik ng ASCII 'a' hanggang 'z' ay nai-map sa 'A' hanggang 'Z', ngunit ang mga hindi ASCII na titik ay hindi nagbabago.
    ///
    /// Upang ibalik ang isang bagong na-uppercased na halaga nang hindi binabago ang mayroon nang, gamitin ang [`to_ascii_uppercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'a';
    ///
    /// ascii.make_ascii_uppercase();
    ///
    /// assert_eq!('A', ascii);
    /// ```
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        *self = self.to_ascii_uppercase();
    }

    /// Binabago ang ganitong uri sa ASCII na mas mababang kaso na katumbas na lugar.
    ///
    /// ASCII titik 'A' na 'Z' ay nama-map sa 'a' na 'z', ngunit hindi ASCII mga titik ay hindi magbabago.
    ///
    /// Upang maibalik ang isang bagong nabayarang halaga nang hindi binabago ang mayroon nang, gamitin ang [`to_ascii_lowercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'A';
    ///
    /// ascii.make_ascii_lowercase();
    ///
    /// assert_eq!('a', ascii);
    /// ```
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        *self = self.to_ascii_lowercase();
    }

    /// Ang mga tseke kung ang halaga ay isang ASCII alphabetic character:
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z', o
    /// - U + 0061 'a' ..=U + 007A 'z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphabetic());
    /// assert!(uppercase_g.is_ascii_alphabetic());
    /// assert!(a.is_ascii_alphabetic());
    /// assert!(g.is_ascii_alphabetic());
    /// assert!(!zero.is_ascii_alphabetic());
    /// assert!(!percent.is_ascii_alphabetic());
    /// assert!(!space.is_ascii_alphabetic());
    /// assert!(!lf.is_ascii_alphabetic());
    /// assert!(!esc.is_ascii_alphabetic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphabetic(&self) -> bool {
        matches!(*self, 'A'..='Z' | 'a'..='z')
    }

    /// Sinusuri kung ang halaga ay isang ASCII malalaking character:
    /// U + 0041 'A' ..=U + 005A 'Z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_uppercase());
    /// assert!(uppercase_g.is_ascii_uppercase());
    /// assert!(!a.is_ascii_uppercase());
    /// assert!(!g.is_ascii_uppercase());
    /// assert!(!zero.is_ascii_uppercase());
    /// assert!(!percent.is_ascii_uppercase());
    /// assert!(!space.is_ascii_uppercase());
    /// assert!(!lf.is_ascii_uppercase());
    /// assert!(!esc.is_ascii_uppercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_uppercase(&self) -> bool {
        matches!(*self, 'A'..='Z')
    }

    /// Ang mga tseke kung ang halaga ay isang ASCII lowercase character:
    /// U + 0061 'a' ..=U + 007A 'z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_lowercase());
    /// assert!(!uppercase_g.is_ascii_lowercase());
    /// assert!(a.is_ascii_lowercase());
    /// assert!(g.is_ascii_lowercase());
    /// assert!(!zero.is_ascii_lowercase());
    /// assert!(!percent.is_ascii_lowercase());
    /// assert!(!space.is_ascii_lowercase());
    /// assert!(!lf.is_ascii_lowercase());
    /// assert!(!esc.is_ascii_lowercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_lowercase(&self) -> bool {
        matches!(*self, 'a'..='z')
    }

    /// Sinusuri kung ang halaga ay isang ASCII alphanumeric character:
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z', o
    /// - U + 0061 'a' ..=U + 007A 'z', o
    /// - U + 0030 '0' ..=U + 0039 '9'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphanumeric());
    /// assert!(uppercase_g.is_ascii_alphanumeric());
    /// assert!(a.is_ascii_alphanumeric());
    /// assert!(g.is_ascii_alphanumeric());
    /// assert!(zero.is_ascii_alphanumeric());
    /// assert!(!percent.is_ascii_alphanumeric());
    /// assert!(!space.is_ascii_alphanumeric());
    /// assert!(!lf.is_ascii_alphanumeric());
    /// assert!(!esc.is_ascii_alphanumeric());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphanumeric(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='Z' | 'a'..='z')
    }

    /// Sinusuri kung ang halaga ay isang decimal na digit na ASCII:
    /// U + 0030 '0' ..=U + 0039 '9'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_digit());
    /// assert!(!uppercase_g.is_ascii_digit());
    /// assert!(!a.is_ascii_digit());
    /// assert!(!g.is_ascii_digit());
    /// assert!(zero.is_ascii_digit());
    /// assert!(!percent.is_ascii_digit());
    /// assert!(!space.is_ascii_digit());
    /// assert!(!lf.is_ascii_digit());
    /// assert!(!esc.is_ascii_digit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_digit(&self) -> bool {
        matches!(*self, '0'..='9')
    }

    /// Sinusuri kung ang halaga ay isang ASCII hexadecimal digit:
    ///
    /// - U + 0030 '0' ..=U + 0039 '9', o
    /// - U + 0041 'A' ..=U + 0046 'F', o
    /// - U + 0061 'a' ..=U + 0066 'f'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_hexdigit());
    /// assert!(!uppercase_g.is_ascii_hexdigit());
    /// assert!(a.is_ascii_hexdigit());
    /// assert!(!g.is_ascii_hexdigit());
    /// assert!(zero.is_ascii_hexdigit());
    /// assert!(!percent.is_ascii_hexdigit());
    /// assert!(!space.is_ascii_hexdigit());
    /// assert!(!lf.is_ascii_hexdigit());
    /// assert!(!esc.is_ascii_hexdigit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_hexdigit(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='F' | 'a'..='f')
    }

    /// Sinusuri kung ang halaga ay isang character na bantas ASCII:
    ///
    /// - U + 0021 ..=U + 002F `! " # $ % & ' ( ) * + , - . /`, o
    /// - U + 003A ..=U + 0040 `: ; < = > ? @`, o
    /// - U + 005B ..=U + 0060 ""[\] ^ _``, o
    /// - U + 007B ..=U + 007E `{ | } ~`
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_punctuation());
    /// assert!(!uppercase_g.is_ascii_punctuation());
    /// assert!(!a.is_ascii_punctuation());
    /// assert!(!g.is_ascii_punctuation());
    /// assert!(!zero.is_ascii_punctuation());
    /// assert!(percent.is_ascii_punctuation());
    /// assert!(!space.is_ascii_punctuation());
    /// assert!(!lf.is_ascii_punctuation());
    /// assert!(!esc.is_ascii_punctuation());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_punctuation(&self) -> bool {
        matches!(*self, '!'..='/' | ':'..='@' | '['..='`' | '{'..='~')
    }

    /// Sinusuri kung ang halaga ay isang ASCII graphic character:
    /// U + 0021 '!' ..=U + 007E '~'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_graphic());
    /// assert!(uppercase_g.is_ascii_graphic());
    /// assert!(a.is_ascii_graphic());
    /// assert!(g.is_ascii_graphic());
    /// assert!(zero.is_ascii_graphic());
    /// assert!(percent.is_ascii_graphic());
    /// assert!(!space.is_ascii_graphic());
    /// assert!(!lf.is_ascii_graphic());
    /// assert!(!esc.is_ascii_graphic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_graphic(&self) -> bool {
        matches!(*self, '!'..='~')
    }

    /// Sinusuri kung ang halaga ay isang ASCII whitespace character:
    /// U + 0020 SPACE, U + 0009 HORIZONTAL TAB, U + 000A LINE FEED, U + 000C FORM FEED, o U + 000D CARRIAGE RETURN.
    ///
    /// Ang Rust ay gumagamit ng WhatWG Infra Standard's [definition of ASCII whitespace][infra-aw].Mayroong ilang mga iba pang mga kahulugan sa malawak na gamitin.
    /// Halimbawa, [the POSIX locale][pct] may kasamang U + 000B VERTICAL TAB pati na rin ang lahat ng mga character sa itaas, ngunit-mula sa napaka-parehong specification-[ang default na patakaran para sa "field splitting" sa Bourne shell][bfs] Isinasaalang-alang ng *lamang* SPACE, pahalang TAB, at LINE fEED bilang whitespace.
    ///
    ///
    /// Kung nagsusulat ka ng isang programa na magproseso ng isang mayroon nang format ng file, suriin kung ano ang kahulugan ng format na iyon ng whitespace bago gamitin ang pagpapaandar na ito.
    ///
    /// [infra-aw]: https://infra.spec.whatwg.org/#ascii-whitespace
    /// [pct]: http://pubs.opengroup.org/onlinepubs/9699919799/basedefs/V1_chap07.html#tag_07_03_01
    /// [bfs]: http://pubs.opengroup.org/onlinepubs/9699919799/utilities/V3_chap02.html#tag_18_06_05
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_whitespace());
    /// assert!(!uppercase_g.is_ascii_whitespace());
    /// assert!(!a.is_ascii_whitespace());
    /// assert!(!g.is_ascii_whitespace());
    /// assert!(!zero.is_ascii_whitespace());
    /// assert!(!percent.is_ascii_whitespace());
    /// assert!(space.is_ascii_whitespace());
    /// assert!(lf.is_ascii_whitespace());
    /// assert!(!esc.is_ascii_whitespace());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_whitespace(&self) -> bool {
        matches!(*self, '\t' | '\n' | '\x0C' | '\r' | ' ')
    }

    /// Sinusuri kung ang halaga ay isang character na kontrol sa ASCII:
    /// U + 0000 NUL ..=U + 001F UNIT SEPARATOR, o U + 007F TANGGALIN.
    /// Tandaan na ang karamihan sa mga character ng whitespace ng ASCII ay mga character na kontrol, ngunit ang SPACE ay hindi.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_control());
    /// assert!(!uppercase_g.is_ascii_control());
    /// assert!(!a.is_ascii_control());
    /// assert!(!g.is_ascii_control());
    /// assert!(!zero.is_ascii_control());
    /// assert!(!percent.is_ascii_control());
    /// assert!(!space.is_ascii_control());
    /// assert!(lf.is_ascii_control());
    /// assert!(esc.is_ascii_control());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_control(&self) -> bool {
        matches!(*self, '\0'..='\x1F' | '\x7F')
    }
}

#[inline]
const fn len_utf8(code: u32) -> usize {
    if code < MAX_ONE_B {
        1
    } else if code < MAX_TWO_B {
        2
    } else if code < MAX_THREE_B {
        3
    } else {
        4
    }
}

/// Naka-encode ng isang hilaw na halagang u32 bilang UTF-8 sa ibinigay na byte buffer, at pagkatapos ay ibabalik ang subslice ng buffer na naglalaman ng naka-encode na character.
///
///
/// Hindi tulad ng `char::encode_utf8`, pinangangasiwaan din ng pamamaraang ito ang mga codepoints sa saklaw ng pagpapalit.
/// (Ang paglikha ng isang `char` sa surrogate hanay ay UB.) Ang resulta ay may-bisa [generalized UTF-8] ngunit hindi wasto UTF-8.
///
/// [generalized UTF-8]: https://simonsapin.github.io/wtf-8/#generalized-utf8
///
/// # Panics
///
/// Panics kung ang buffer ay hindi malaki sapat.
/// Ang isang buffer haba ng apat na ay malaki sapat na upang i-encode ang anumang `char`.
///
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf8_raw(code: u32, dst: &mut [u8]) -> &mut [u8] {
    let len = len_utf8(code);
    match (len, &mut dst[..]) {
        (1, [a, ..]) => {
            *a = code as u8;
        }
        (2, [a, b, ..]) => {
            *a = (code >> 6 & 0x1F) as u8 | TAG_TWO_B;
            *b = (code & 0x3F) as u8 | TAG_CONT;
        }
        (3, [a, b, c, ..]) => {
            *a = (code >> 12 & 0x0F) as u8 | TAG_THREE_B;
            *b = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *c = (code & 0x3F) as u8 | TAG_CONT;
        }
        (4, [a, b, c, d, ..]) => {
            *a = (code >> 18 & 0x07) as u8 | TAG_FOUR_B;
            *b = (code >> 12 & 0x3F) as u8 | TAG_CONT;
            *c = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *d = (code & 0x3F) as u8 | TAG_CONT;
        }
        _ => panic!(
            "encode_utf8: need {} bytes to encode U+{:X}, but the buffer has {}",
            len,
            code,
            dst.len(),
        ),
    };
    &mut dst[..len]
}

/// Encodes ng isang raw u32 halaga ng UTF-16 sa ibinigay `u16` buffer, at pagkatapos ay bumalik sa subslice ng buffer na naglalaman ng na-encode ng character.
///
///
/// Hindi tulad ng `char::encode_utf16`, pinangangasiwaan din ng pamamaraang ito ang mga codepoint sa saklaw ng pagpapalit.
/// (Ang paglikha ng isang `char` sa surrogate hanay ay UB.)
///
/// # Panics
///
/// Panics kung ang buffer ay hindi malaki sapat.
/// Ang isang buffer ng haba 2 ay sapat na malaki upang ma-encode ang anumang `char`.
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf16_raw(mut code: u32, dst: &mut [u16]) -> &mut [u16] {
    // KALIGTASAN: bawat braso tseke kung mayroong sapat na bits na magsulat sa
    unsafe {
        if (code & 0xFFFF) == code && !dst.is_empty() {
            // Ang BMP ay bumaba sa pamamagitan ng
            *dst.get_unchecked_mut(0) = code as u16;
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 1)
        } else if dst.len() >= 2 {
            // Ang mga pandagdag na eroplano ay sumisira sa mga kahalili.
            code -= 0x1_0000;
            *dst.get_unchecked_mut(0) = 0xD800 | ((code >> 10) as u16);
            *dst.get_unchecked_mut(1) = 0xDC00 | ((code as u16) & 0x3FF);
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 2)
        } else {
            panic!(
                "encode_utf16: need {} units to encode U+{:X}, but the buffer has {}",
                from_u32_unchecked(code).len_utf16(),
                code,
                dst.len(),
            )
        }
    }
}