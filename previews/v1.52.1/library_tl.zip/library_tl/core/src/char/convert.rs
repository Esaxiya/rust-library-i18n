//! Mga conversion ng character.

use crate::convert::TryFrom;
use crate::fmt;
use crate::mem::transmute;
use crate::str::FromStr;

use super::MAX;

/// Binabago ang isang `u32` sa isang `char`.
///
/// Tandaan na ang lahat ng [`char`] ay may-bisa ng [`u32`] s, at maaaring i-cast sa isa kasama
/// `as`:
///
/// ```
/// let c = '💯';
/// let i = c as u32;
///
/// assert_eq!(128175, i);
/// ```
///
/// Gayunpaman, ang katotohanan ay hindi totoo: hindi lahat ng wastong [`u32`] s ay wasto [`char`] s.
/// `from_u32()` ibabalik ang `None` kung ang input ay hindi isang wastong halaga para sa isang [`char`].
///
/// Para sa isang hindi ligtas na bersyon ng pagpapaandar na ito na hindi pinapansin ang mga pagsusuri na ito, tingnan ang [`from_u32_unchecked`].
///
///
/// # Examples
///
/// Pangunahing paggamit:
///
/// ```
/// use std::char;
///
/// let c = char::from_u32(0x2764);
///
/// assert_eq!(Some('❤'), c);
/// ```
///
/// Ibinabalik ang `None` kapag ang input ay hindi wastong [`char`]:
///
/// ```
/// use std::char;
///
/// let c = char::from_u32(0x110000);
///
/// assert_eq!(None, c);
/// ```
///
#[doc(alias = "chr")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_u32(i: u32) -> Option<char> {
    char::try_from(i).ok()
}

/// Binabago ang isang `u32` sa isang `char`, hindi pinapansin ang bisa.
///
/// Tandaan na ang lahat ng [`char`] ay may-bisa ng [`u32`] s, at maaaring i-cast sa isa kasama
/// `as`:
///
/// ```
/// let c = '💯';
/// let i = c as u32;
///
/// assert_eq!(128175, i);
/// ```
///
/// Gayunpaman, ang katotohanan ay hindi totoo: hindi lahat ng wastong [`u32`] s ay wasto [`char`] s.
/// `from_u32_unchecked()` hindi ito papansinin, at bulag na i-cast sa [`char`], posibleng lumilikha ng hindi wasto.
///
///
/// # Safety
///
/// Ang pag-andar na ito ay hindi ligtas, dahil maaari itong bumuo ng hindi wastong mga halagang `char`.
///
/// Para sa isang ligtas na bersyon ng function na ito, tingnan ang [`from_u32`] function.
///
/// # Examples
///
/// Pangunahing paggamit:
///
/// ```
/// use std::char;
///
/// let c = unsafe { char::from_u32_unchecked(0x2764) };
///
/// assert_eq!('❤', c);
/// ```
#[inline]
#[stable(feature = "char_from_unchecked", since = "1.5.0")]
pub unsafe fn from_u32_unchecked(i: u32) -> char {
    // KALIGTASAN: dapat garantiya ng tumatawag na ang `i` ay isang wastong halaga ng char.
    if cfg!(debug_assertions) { char::from_u32(i).unwrap() } else { unsafe { transmute(i) } }
}

#[stable(feature = "char_convert", since = "1.13.0")]
impl From<char> for u32 {
    /// Binabago ang isang [`char`] sa isang [`u32`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = 'c';
    /// let u = u32::from(c);
    /// assert!(4 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        c as u32
    }
}

#[stable(feature = "more_char_conversions", since = "1.51.0")]
impl From<char> for u64 {
    /// Binabago ang isang [`char`] sa isang [`u64`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = '👤';
    /// let u = u64::from(c);
    /// assert!(8 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        // Ang char ay itinapon sa halaga ng code point, pagkatapos ay zero-extaced sa 64 bit.
        // Tingnan ang [https://doc.rust-lang.org/reference/expressions/operator-expr.html#semantics]
        c as u64
    }
}

#[stable(feature = "more_char_conversions", since = "1.51.0")]
impl From<char> for u128 {
    /// Binabago ang isang [`char`] sa isang [`u128`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = '⚙';
    /// let u = u128::from(c);
    /// assert!(16 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        // Ang char ay itinapon sa halaga ng code point, pagkatapos ay zero-Extended sa 128 bit.
        // Tingnan ang [https://doc.rust-lang.org/reference/expressions/operator-expr.html#semantics]
        c as u128
    }
}

/// Mapa ng isang byte ang 0x00 ..=0xFF sa isang `char` na ang code point ay may parehong halaga, sa U + 0000 ..=U + 00FF.
///
/// Ang Unicode ay dinisenyo tulad ng na epektibo itong pag-decode ng mga byte na may character encoding na tinatawag ng IANA na ISO-8859-1.
/// encoding na ito ay tugma sa ASCII.
///
/// Tandaan na ito ay naiiba mula sa ISO/IEC 8859-1 aka
/// Ang ISO 8859-1 (na may isang mas kaunting gitling), na nag-iiwan ng ilang "blanks", byte na halaga na hindi nakatalaga sa anumang character.
/// Ang ISO-8859-1 (ang IANA isa) ay nagtatalaga sa kanila sa C0 at C1 control code.
///
/// Tandaan na ito rin ay * naiiba mula sa Windows-1252 aka
/// Kodigo ng pahinang 1252, kung saan ay isang superset ISO/IEC 8859-1 na nagtatalaga ng ilang (hindi lahat!) mga blangko na bantas at iba't-ibang mga character Latin.
///
/// Upang lituhin ang mga bagay-bagay pa, [on the Web](https://encoding.spec.whatwg.org/) `ascii`, `iso-8859-1`, at `windows-1252` ay ang lahat ng mga alias para sa isang superset ng Windows-1252 na pumupuno sa mga natitirang mga blangko na may kaukulang C0 at C1 control codes.
///
///
///
///
///
#[stable(feature = "char_convert", since = "1.13.0")]
impl From<u8> for char {
    /// Binabago ang isang [`u8`] sa isang [`char`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let u = 32 as u8;
    /// let c = char::from(u);
    /// assert!(4 == mem::size_of_val(&c))
    /// ```
    #[inline]
    fn from(i: u8) -> Self {
        i as char
    }
}

/// Isang error na maaaring ibalik kapag nag-parse ng char.
#[stable(feature = "char_from_str", since = "1.20.0")]
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct ParseCharError {
    kind: CharErrorKind,
}

impl ParseCharError {
    #[unstable(
        feature = "char_error_internals",
        reason = "this method should not be available publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            CharErrorKind::EmptyString => "cannot parse char from empty string",
            CharErrorKind::TooManyChars => "too many characters in string",
        }
    }
}

#[derive(Copy, Clone, Debug, PartialEq, Eq)]
enum CharErrorKind {
    EmptyString,
    TooManyChars,
}

#[stable(feature = "char_from_str", since = "1.20.0")]
impl fmt::Display for ParseCharError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}

#[stable(feature = "char_from_str", since = "1.20.0")]
impl FromStr for char {
    type Err = ParseCharError;

    #[inline]
    fn from_str(s: &str) -> Result<Self, Self::Err> {
        let mut chars = s.chars();
        match (chars.next(), chars.next()) {
            (None, _) => Err(ParseCharError { kind: CharErrorKind::EmptyString }),
            (Some(c), None) => Ok(c),
            _ => Err(ParseCharError { kind: CharErrorKind::TooManyChars }),
        }
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl TryFrom<u32> for char {
    type Error = CharTryFromError;

    #[inline]
    fn try_from(i: u32) -> Result<Self, Self::Error> {
        if (i > MAX as u32) || (i >= 0xD800 && i <= 0xDFFF) {
            Err(CharTryFromError(()))
        } else {
            // KALIGTASAN: check na ito ay isang legal na unicode halaga
            Ok(unsafe { transmute(i) })
        }
    }
}

/// Bumalik ang uri ng error kapag nabigo ang isang conversion mula u32 hanggang char.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct CharTryFromError(());

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for CharTryFromError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        "converted integer out of range for `char`".fmt(f)
    }
}

/// Nagko-convert ng isang digit sa ibinigay na radix sa isang `char`.
///
/// Ang isang 'radix' dito kung minsan ay tinatawag ding 'base'.
/// Ang isang radix ng dalawa ay nagpapahiwatig ng isang binary number, isang radix ng sampung, decimal, at isang radix na labing-anim, hexadecimal, upang magbigay ng ilang mga karaniwang halaga.
///
/// Sinusuportahan ang di-makatwirang mga radice.
///
/// `from_digit()` ibabalik ang `None` kung ang input ay hindi isang digit sa ibinigay na radix.
///
/// # Panics
///
/// Panics kung bibigyan ng isang radix na mas malaki sa 36.
///
/// # Examples
///
/// Pangunahing paggamit:
///
/// ```
/// use std::char;
///
/// let c = char::from_digit(4, 10);
///
/// assert_eq!(Some('4'), c);
///
/// // Ang Decimal 11 ay isang solong digit sa base 16
/// let c = char::from_digit(11, 16);
///
/// assert_eq!(Some('b'), c);
/// ```
///
/// Bumabalik `None` kapag ang input ay hindi isang digit:
///
/// ```
/// use std::char;
///
/// let c = char::from_digit(20, 10);
///
/// assert_eq!(None, c);
/// ```
///
/// Pagpasa ng isang malaking radix, na nagiging sanhi ng isang panic:
///
/// ```should_panic
/// use std::char;
///
/// // this panics
/// let c = char::from_digit(1, 37);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_digit(num: u32, radix: u32) -> Option<char> {
    if radix > 36 {
        panic!("from_digit: radix is too high (maximum 36)");
    }
    if num < radix {
        let num = num as u8;
        if num < 10 { Some((b'0' + num) as char) } else { Some((b'a' + num - 10) as char) }
    } else {
        None
    }
}