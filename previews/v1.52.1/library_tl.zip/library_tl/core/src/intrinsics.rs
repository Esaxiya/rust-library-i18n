//! Mga intrinsik ng tagatala.
//!
//! Ang nararapat na kahulugan ay nasa `compiler/rustc_codegen_llvm/src/intrinsic.rs`.
//! Ang kaukulang pagpapatupad ng const ay nasa `compiler/rustc_mir/src/interpret/intrinsics.rs`
//!
//! # Const intrinsics
//!
//! Note: ang anumang mga pagbabago sa pagkakaroon ng mga intrinsik ay dapat na tinalakay kasama ang pangkat ng wika.
//! Kasama rito ang mga pagbabago sa katatagan ng pagiging pare-pareho.
//!
//! Upang makagawa ng isang intrinsic na magagamit sa compile-time, kailangang kopyahin ng isang tao ang pagpapatupad mula <https://github.com/rust-lang/miri/blob/master/src/shims/intrinsics.rs> hanggang `compiler/rustc_mir/src/interpret/intrinsics.rs` at magdagdag ng `#[rustc_const_unstable(feature = "foo", issue = "01234")]` sa intrinsic.
//!
//!
//! Kung ang isang intrinsic ay dapat na ginamit mula sa isang `const fn` na may `rustc_const_stable` na katangian, ang katangian ng intrinsic ay dapat na `rustc_const_stable` din.
//! Ang ganitong pagbabago ay hindi dapat gawin nang walang T-lang na konsultasyon, dahil ito bakes isang tampok sa wikang iyon ay hindi maaaring replicated sa user code nang walang compiler suporta.
//!
//! # Volatiles
//!
//! Nagbibigay ang pabagu-bago ng intrinsik na mga pagpapatakbo na inilaan upang kumilos sa memorya ng I/O, na ginagarantiyahan na hindi maiayos muli ng tagatala sa iba pang mga pabagu-bagong intrinsik.Tingnan ang LLVM babasahin sa [[volatile]].
//!
//! [volatile]: http://llvm.org/docs/LangRef.html#volatile-memory-accesses
//!
//! # Atomics
//!
//! Ang mga atomic intrinsics ay nagbibigay ng karaniwang mga pagpapatakbo ng atomic sa mga salitang machine, na may maraming posibleng pag-order ng memorya.sundin nila ang parehong semantika bilang C++ 11.Tingnan ang dokumentasyon ng LLVM sa [[atomics]].
//!
//! [atomics]: http://llvm.org/docs/Atomics.html
//!
//! Ang isang mabilis na refresher sa memory pag-order:
//!
//! * Kumuha, isang hadlang para sa pagkuha ng isang kandado.Ang mga kasunod na pagbabasa at pagsusulat ay nagaganap pagkatapos ng hadlang.
//! * Palabasin, isang hadlang para sa paglabas ng isang lock.Naunang bumabasa at writes na maganap bago ang barrier.
//! * Sunud-sunod pare-pareho, nang sunud-sunod pare-pareho operasyon ay garantisadong upang mangyari sa pagkakasunod-sunod.Ito ang karaniwang mode para sa nagtatrabaho sa atomic uri at ay katumbas ni Java `volatile`.
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![unstable(
    feature = "core_intrinsics",
    reason = "intrinsics are unlikely to ever be stabilized, instead \
                      they should be used through stabilized interfaces \
                      in the rest of the standard library",
    issue = "none"
)]
#![allow(missing_docs)]

use crate::marker::DiscriminantKind;
use crate::mem;

// Ginagamit ang mga pag-import na ito para sa pagpapagaan ng mga link ng intra-doc
#[allow(unused_imports)]
#[cfg(all(target_has_atomic = "8", target_has_atomic = "32", target_has_atomic = "ptr"))]
use crate::sync::atomic::{self, AtomicBool, AtomicI32, AtomicIsize, AtomicU32, Ordering};

#[stable(feature = "drop_in_place", since = "1.8.0")]
#[rustc_deprecated(
    reason = "no longer an intrinsic - use `ptr::drop_in_place` directly",
    since = "1.52.0"
)]
#[inline]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // KALIGTASAN: tingnan `ptr::drop_in_place`
    unsafe { crate::ptr::drop_in_place(to_drop) }
}

extern "rust-intrinsic" {
    // NB, mga intrinsics kumuha ng payo raw dahil sila mutate alias na memorya, na kung saan ay hindi wasto para mag-`&` o `&mut`.
    //

    /// Nag-iimbak ng isang halaga kung ang kasalukuyang halaga ay pareho ng halagang `old`.
    ///
    /// Ang nagpapatatag na bersyon ng intrinsic na ito ay magagamit sa mga uri ng [`atomic`] sa pamamagitan ng pamamaraang `compare_exchange` sa pamamagitan ng pagpasa sa [`Ordering::SeqCst`] bilang kapwa mga `success` at `failure` na mga parameter.
    ///
    /// Halimbawa, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Nag-iimbak ng isang halaga kung ang kasalukuyang halaga ay pareho ng halagang `old`.
    ///
    /// Ang nagpapatatag bersyon ng intrinsic na ito ay magagamit sa mga uri [`atomic`] pamamagitan ng `compare_exchange` paraan sa pamamagitan ng pagpasa [`Ordering::Acquire`] bilang parehong mga `success` at `failure` parameter.
    ///
    /// Halimbawa, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Nag-iimbak ng isang halaga kung ang kasalukuyang halaga ay pareho ng halagang `old`.
    ///
    /// Ang nagpapatatag bersyon ng intrinsic na ito ay magagamit sa mga uri [`atomic`] pamamagitan ng `compare_exchange` paraan sa pamamagitan ng pagpasa [`Ordering::Release`] bilang ang `success` at [`Ordering::Relaxed`] bilang ang mga parameter `failure`.
    /// Halimbawa, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Nag-iimbak ng isang halaga kung ang kasalukuyang halaga ay pareho ng halagang `old`.
    ///
    /// Ang nagpapatatag bersyon ng intrinsic na ito ay magagamit sa mga uri [`atomic`] pamamagitan ng `compare_exchange` paraan sa pamamagitan ng pagpasa [`Ordering::AcqRel`] bilang ang `success` at [`Ordering::Acquire`] bilang ang mga parameter `failure`.
    /// Halimbawa, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Nag-iimbak ng isang halaga kung ang kasalukuyang halaga ay pareho ng halagang `old`.
    ///
    /// Ang nagpapatatag na bersyon ng intrinsic na ito ay magagamit sa mga uri ng [`atomic`] sa pamamagitan ng pamamaraang `compare_exchange` sa pamamagitan ng pagpasa sa [`Ordering::Relaxed`] bilang kapwa mga `success` at `failure` na mga parameter.
    ///
    /// Halimbawa, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Nag-iimbak ng isang halaga kung ang kasalukuyang halaga ay pareho ng halagang `old`.
    ///
    /// Ang matatag na bersyon ng intrinsic na ito ay magagamit sa mga uri ng [`atomic`] sa pamamagitan ng pamamaraan na `compare_exchange` sa pamamagitan ng pagpasa sa [`Ordering::SeqCst`] bilang `success` at [`Ordering::Relaxed`] bilang mga `failure` na parameter.
    /// Halimbawa, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Nag-iimbak ng isang halaga kung ang kasalukuyang halaga ay pareho ng halagang `old`.
    ///
    /// Ang nagpapatatag bersyon ng intrinsic na ito ay magagamit sa mga uri [`atomic`] pamamagitan ng `compare_exchange` paraan sa pamamagitan ng pagpasa [`Ordering::SeqCst`] bilang ang `success` at [`Ordering::Acquire`] bilang ang mga parameter `failure`.
    /// Halimbawa, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Nag-iimbak ng isang halaga kung ang kasalukuyang halaga ay pareho ng halagang `old`.
    ///
    /// Ang matatag na bersyon ng intrinsic na ito ay magagamit sa mga uri ng [`atomic`] sa pamamagitan ng pamamaraan na `compare_exchange` sa pamamagitan ng pagpasa sa [`Ordering::Acquire`] bilang `success` at [`Ordering::Relaxed`] bilang mga `failure` na parameter.
    /// Halimbawa, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Nag-iimbak ng isang halaga kung ang kasalukuyang halaga ay pareho ng halagang `old`.
    ///
    /// Ang nagpapatatag bersyon ng intrinsic na ito ay magagamit sa mga uri [`atomic`] pamamagitan ng `compare_exchange` paraan sa pamamagitan ng pagpasa [`Ordering::AcqRel`] bilang ang `success` at [`Ordering::Relaxed`] bilang ang mga parameter `failure`.
    /// Halimbawa, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// Nag-iimbak ng isang halaga kung ang kasalukuyang halaga ay pareho ng halagang `old`.
    ///
    /// Ang nagpapatatag na bersyon ng intrinsic na ito ay magagamit sa mga uri ng [`atomic`] sa pamamagitan ng pamamaraang `compare_exchange_weak` sa pamamagitan ng pagpasa sa [`Ordering::SeqCst`] bilang kapwa mga `success` at `failure` na mga parameter.
    ///
    /// Halimbawa, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Nag-iimbak ng isang halaga kung ang kasalukuyang halaga ay pareho ng halagang `old`.
    ///
    /// Ang nagpapatatag bersyon ng intrinsic na ito ay magagamit sa mga uri [`atomic`] pamamagitan ng `compare_exchange_weak` paraan sa pamamagitan ng pagpasa [`Ordering::Acquire`] bilang parehong mga `success` at `failure` parameter.
    ///
    /// Halimbawa, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Nag-iimbak ng isang halaga kung ang kasalukuyang halaga ay pareho ng halagang `old`.
    ///
    /// Ang nagpapatatag bersyon ng intrinsic na ito ay magagamit sa mga uri [`atomic`] pamamagitan ng `compare_exchange_weak` paraan sa pamamagitan ng pagpasa [`Ordering::Release`] bilang ang `success` at [`Ordering::Relaxed`] bilang ang mga parameter `failure`.
    /// Halimbawa, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Nag-iimbak ng isang halaga kung ang kasalukuyang halaga ay pareho ng halagang `old`.
    ///
    /// Ang nagpapatatag bersyon ng intrinsic na ito ay magagamit sa mga uri [`atomic`] pamamagitan ng `compare_exchange_weak` paraan sa pamamagitan ng pagpasa [`Ordering::AcqRel`] bilang ang `success` at [`Ordering::Acquire`] bilang ang mga parameter `failure`.
    /// Halimbawa, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Nag-iimbak ng isang halaga kung ang kasalukuyang halaga ay pareho ng halagang `old`.
    ///
    /// Ang nagpapatatag na bersyon ng intrinsic na ito ay magagamit sa mga uri ng [`atomic`] sa pamamagitan ng pamamaraang `compare_exchange_weak` sa pamamagitan ng pagpasa sa [`Ordering::Relaxed`] bilang kapwa mga `success` at `failure` na mga parameter.
    ///
    /// Halimbawa, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Nag-iimbak ng isang halaga kung ang kasalukuyang halaga ay pareho ng halagang `old`.
    ///
    /// Ang nagpapatatag bersyon ng intrinsic na ito ay magagamit sa mga uri [`atomic`] pamamagitan ng `compare_exchange_weak` paraan sa pamamagitan ng pagpasa [`Ordering::SeqCst`] bilang ang `success` at [`Ordering::Relaxed`] bilang ang mga parameter `failure`.
    /// Halimbawa, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Nag-iimbak ng isang halaga kung ang kasalukuyang halaga ay pareho ng halagang `old`.
    ///
    /// Ang nagpapatatag bersyon ng intrinsic na ito ay magagamit sa mga uri [`atomic`] pamamagitan ng `compare_exchange_weak` paraan sa pamamagitan ng pagpasa [`Ordering::SeqCst`] bilang ang `success` at [`Ordering::Acquire`] bilang ang mga parameter `failure`.
    /// Halimbawa, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Nag-iimbak ng isang halaga kung ang kasalukuyang halaga ay pareho ng halagang `old`.
    ///
    /// Ang matatag na bersyon ng intrinsic na ito ay magagamit sa mga uri ng [`atomic`] sa pamamagitan ng pamamaraan na `compare_exchange_weak` sa pamamagitan ng pagpasa sa [`Ordering::Acquire`] bilang `success` at [`Ordering::Relaxed`] bilang mga `failure` na parameter.
    /// Halimbawa, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Nag-iimbak ng isang halaga kung ang kasalukuyang halaga ay pareho ng halagang `old`.
    ///
    /// Ang nagpapatatag bersyon ng intrinsic na ito ay magagamit sa mga uri [`atomic`] pamamagitan ng `compare_exchange_weak` paraan sa pamamagitan ng pagpasa [`Ordering::AcqRel`] bilang ang `success` at [`Ordering::Relaxed`] bilang ang mga parameter `failure`.
    /// Halimbawa, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// Naglo-load ang kasalukuyang halaga ng pointer.
    ///
    /// Ang matatag na bersyon ng intrinsic na ito ay magagamit sa mga uri ng [`atomic`] sa pamamagitan ng pamamaraang `load` sa pamamagitan ng pagpasa sa [`Ordering::SeqCst`] bilang `order`.
    /// Halimbawa, [`AtomicBool::load`].
    ///
    pub fn atomic_load<T: Copy>(src: *const T) -> T;
    /// Naglo-load ang kasalukuyang halaga ng pointer.
    ///
    /// Ang nagpapatatag bersyon ng intrinsic na ito ay magagamit sa mga uri [`atomic`] pamamagitan ng `load` paraan sa pamamagitan ng pagpasa [`Ordering::Acquire`] bilang ang `order`.
    /// Halimbawa, [`AtomicBool::load`].
    ///
    pub fn atomic_load_acq<T: Copy>(src: *const T) -> T;
    /// Naglo-load ang kasalukuyang halaga ng pointer.
    ///
    /// Ang nagpapatatag bersyon ng intrinsic na ito ay magagamit sa mga uri [`atomic`] pamamagitan ng `load` paraan sa pamamagitan ng pagpasa [`Ordering::Relaxed`] bilang ang `order`.
    /// Halimbawa, [`AtomicBool::load`].
    ///
    pub fn atomic_load_relaxed<T: Copy>(src: *const T) -> T;
    pub fn atomic_load_unordered<T: Copy>(src: *const T) -> T;

    /// Iniimbak ang halaga sa tinukoy na lokasyon ng memorya.
    ///
    /// Ang nagpapatatag bersyon ng intrinsic na ito ay magagamit sa mga uri [`atomic`] pamamagitan ng `store` paraan sa pamamagitan ng pagpasa [`Ordering::SeqCst`] bilang ang `order`.
    /// Halimbawa, [`AtomicBool::store`].
    ///
    pub fn atomic_store<T: Copy>(dst: *mut T, val: T);
    /// Iniimbak ang halaga sa tinukoy na lokasyon ng memorya.
    ///
    /// Ang nagpapatatag bersyon ng intrinsic na ito ay magagamit sa mga uri [`atomic`] pamamagitan ng `store` paraan sa pamamagitan ng pagpasa [`Ordering::Release`] bilang ang `order`.
    /// Halimbawa, [`AtomicBool::store`].
    ///
    pub fn atomic_store_rel<T: Copy>(dst: *mut T, val: T);
    /// Iniimbak ang halaga sa tinukoy na lokasyon ng memorya.
    ///
    /// Ang matatag na bersyon ng intrinsic na ito ay magagamit sa mga uri ng [`atomic`] sa pamamagitan ng pamamaraang `store` sa pamamagitan ng pagpasa sa [`Ordering::Relaxed`] bilang `order`.
    /// Halimbawa, [`AtomicBool::store`].
    ///
    pub fn atomic_store_relaxed<T: Copy>(dst: *mut T, val: T);
    pub fn atomic_store_unordered<T: Copy>(dst: *mut T, val: T);

    /// Iniimbak ang halaga sa tinukoy na lokasyon ng memorya, na ibinabalik ang dating halaga.
    ///
    /// Ang nagpapatatag bersyon ng intrinsic na ito ay magagamit sa mga uri [`atomic`] pamamagitan ng `swap` paraan sa pamamagitan ng pagpasa [`Ordering::SeqCst`] bilang ang `order`.
    /// Halimbawa, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg<T: Copy>(dst: *mut T, src: T) -> T;
    /// Iniimbak ang halaga sa tinukoy na lokasyon ng memorya, na ibinabalik ang dating halaga.
    ///
    /// Ang nagpapatatag bersyon ng intrinsic na ito ay magagamit sa mga uri [`atomic`] pamamagitan ng `swap` paraan sa pamamagitan ng pagpasa [`Ordering::Acquire`] bilang ang `order`.
    /// Halimbawa, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Iniimbak ang halaga sa tinukoy na lokasyon ng memorya, na ibinabalik ang dating halaga.
    ///
    /// Ang matatag na bersyon ng intrinsic na ito ay magagamit sa mga uri ng [`atomic`] sa pamamagitan ng pamamaraang `swap` sa pamamagitan ng pagpasa sa [`Ordering::Release`] bilang `order`.
    /// Halimbawa, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Iniimbak ang halaga sa tinukoy na lokasyon ng memorya, na ibinabalik ang dating halaga.
    ///
    /// Ang nagpapatatag bersyon ng intrinsic na ito ay magagamit sa mga uri [`atomic`] pamamagitan ng `swap` paraan sa pamamagitan ng pagpasa [`Ordering::AcqRel`] bilang ang `order`.
    /// Halimbawa, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Iniimbak ang halaga sa tinukoy na lokasyon ng memorya, na ibinabalik ang dating halaga.
    ///
    /// Ang nagpapatatag bersyon ng intrinsic na ito ay magagamit sa mga uri [`atomic`] pamamagitan ng `swap` paraan sa pamamagitan ng pagpasa [`Ordering::Relaxed`] bilang ang `order`.
    /// Halimbawa, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Nagdaragdag sa kasalukuyang halaga, na binabalik ang dating halaga.
    ///
    /// Ang nagpapatatag bersyon ng intrinsic na ito ay magagamit sa mga uri [`atomic`] pamamagitan ng `fetch_add` paraan sa pamamagitan ng pagpasa [`Ordering::SeqCst`] bilang ang `order`.
    /// Halimbawa, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd<T: Copy>(dst: *mut T, src: T) -> T;
    /// Nagdaragdag sa kasalukuyang halaga, na binabalik ang dating halaga.
    ///
    /// Ang nagpapatatag bersyon ng intrinsic na ito ay magagamit sa mga uri [`atomic`] pamamagitan ng `fetch_add` paraan sa pamamagitan ng pagpasa [`Ordering::Acquire`] bilang ang `order`.
    /// Halimbawa, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Nagdaragdag sa kasalukuyang halaga, na binabalik ang dating halaga.
    ///
    /// Ang nagpapatatag bersyon ng intrinsic na ito ay magagamit sa mga uri [`atomic`] pamamagitan ng `fetch_add` paraan sa pamamagitan ng pagpasa [`Ordering::Release`] bilang ang `order`.
    /// Halimbawa, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Nagdaragdag sa kasalukuyang halaga, na binabalik ang dating halaga.
    ///
    /// Ang nagpapatatag bersyon ng intrinsic na ito ay magagamit sa mga uri [`atomic`] pamamagitan ng `fetch_add` paraan sa pamamagitan ng pagpasa [`Ordering::AcqRel`] bilang ang `order`.
    /// Halimbawa, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Nagdaragdag sa kasalukuyang halaga, na binabalik ang dating halaga.
    ///
    /// Ang matatag na bersyon ng intrinsic na ito ay magagamit sa mga uri ng [`atomic`] sa pamamagitan ng pamamaraang `fetch_add` sa pamamagitan ng pagpasa sa [`Ordering::Relaxed`] bilang `order`.
    /// Halimbawa, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Magbawas mula sa kasalukuyang halaga, mga bumabalik na sa nakaraang halaga.
    ///
    /// Ang nagpapatatag bersyon ng intrinsic na ito ay magagamit sa mga uri [`atomic`] pamamagitan ng `fetch_sub` paraan sa pamamagitan ng pagpasa [`Ordering::SeqCst`] bilang ang `order`.
    /// Halimbawa, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub<T: Copy>(dst: *mut T, src: T) -> T;
    /// Magbawas mula sa kasalukuyang halaga, mga bumabalik na sa nakaraang halaga.
    ///
    /// Ang nagpapatatag bersyon ng intrinsic na ito ay magagamit sa mga uri [`atomic`] pamamagitan ng `fetch_sub` paraan sa pamamagitan ng pagpasa [`Ordering::Acquire`] bilang ang `order`.
    /// Halimbawa, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Magbawas mula sa kasalukuyang halaga, mga bumabalik na sa nakaraang halaga.
    ///
    /// Ang nagpapatatag bersyon ng intrinsic na ito ay magagamit sa mga uri [`atomic`] pamamagitan ng `fetch_sub` paraan sa pamamagitan ng pagpasa [`Ordering::Release`] bilang ang `order`.
    /// Halimbawa, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Magbawas mula sa kasalukuyang halaga, mga bumabalik na sa nakaraang halaga.
    ///
    /// Ang matatag na bersyon ng intrinsic na ito ay magagamit sa mga uri ng [`atomic`] sa pamamagitan ng pamamaraang `fetch_sub` sa pamamagitan ng pagpasa sa [`Ordering::AcqRel`] bilang `order`.
    /// Halimbawa, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Magbawas mula sa kasalukuyang halaga, mga bumabalik na sa nakaraang halaga.
    ///
    /// Ang matatag na bersyon ng intrinsic na ito ay magagamit sa mga uri ng [`atomic`] sa pamamagitan ng pamamaraang `fetch_sub` sa pamamagitan ng pagpasa sa [`Ordering::Relaxed`] bilang `order`.
    /// Halimbawa, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitwise at sa kasalukuyang halaga, ibabalik ang dating halaga.
    ///
    /// Ang nagpapatatag bersyon ng intrinsic na ito ay magagamit sa mga uri [`atomic`] pamamagitan ng `fetch_and` paraan sa pamamagitan ng pagpasa [`Ordering::SeqCst`] bilang ang `order`.
    /// Halimbawa, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise at sa kasalukuyang halaga, ibabalik ang dating halaga.
    ///
    /// Ang nagpapatatag bersyon ng intrinsic na ito ay magagamit sa mga uri [`atomic`] pamamagitan ng `fetch_and` paraan sa pamamagitan ng pagpasa [`Ordering::Acquire`] bilang ang `order`.
    /// Halimbawa, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise at sa kasalukuyang halaga, ibabalik ang dating halaga.
    ///
    /// Ang nagpapatatag bersyon ng intrinsic na ito ay magagamit sa mga uri [`atomic`] pamamagitan ng `fetch_and` paraan sa pamamagitan ng pagpasa [`Ordering::Release`] bilang ang `order`.
    /// Halimbawa, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise at sa kasalukuyang halaga, ibabalik ang dating halaga.
    ///
    /// Ang nagpapatatag bersyon ng intrinsic na ito ay magagamit sa mga uri [`atomic`] pamamagitan ng `fetch_and` paraan sa pamamagitan ng pagpasa [`Ordering::AcqRel`] bilang ang `order`.
    /// Halimbawa, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise at sa kasalukuyang halaga, ibabalik ang dating halaga.
    ///
    /// Ang nagpapatatag bersyon ng intrinsic na ito ay magagamit sa mga uri [`atomic`] pamamagitan ng `fetch_and` paraan sa pamamagitan ng pagpasa [`Ordering::Relaxed`] bilang ang `order`.
    /// Halimbawa, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitwise nand na may kasalukuyang halaga, na ibinabalik ang dating halaga.
    ///
    /// Ang nagpapatatag bersyon ng intrinsic na ito ay magagamit sa uri [`AtomicBool`] pamamagitan ng `fetch_nand` paraan sa pamamagitan ng pagpasa [`Ordering::SeqCst`] bilang ang `order`.
    /// Halimbawa, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise nand na may kasalukuyang halaga, na ibinabalik ang dating halaga.
    ///
    /// Ang nagpapatatag bersyon ng intrinsic na ito ay magagamit sa uri [`AtomicBool`] pamamagitan ng `fetch_nand` paraan sa pamamagitan ng pagpasa [`Ordering::Acquire`] bilang ang `order`.
    /// Halimbawa, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise nand na may kasalukuyang halaga, na ibinabalik ang dating halaga.
    ///
    /// Ang matatag na bersyon ng intrinsic na ito ay magagamit sa uri ng [`AtomicBool`] sa pamamagitan ng pamamaraang `fetch_nand` sa pamamagitan ng pagpasa sa [`Ordering::Release`] bilang `order`.
    /// Halimbawa, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise nand na may kasalukuyang halaga, na ibinabalik ang dating halaga.
    ///
    /// Ang nagpapatatag bersyon ng intrinsic na ito ay magagamit sa uri [`AtomicBool`] pamamagitan ng `fetch_nand` paraan sa pamamagitan ng pagpasa [`Ordering::AcqRel`] bilang ang `order`.
    /// Halimbawa, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise nand na may kasalukuyang halaga, na ibinabalik ang dating halaga.
    ///
    /// Ang nagpapatatag bersyon ng intrinsic na ito ay magagamit sa uri [`AtomicBool`] pamamagitan ng `fetch_nand` paraan sa pamamagitan ng pagpasa [`Ordering::Relaxed`] bilang ang `order`.
    /// Halimbawa, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitwise o sa kasalukuyang halaga, ibabalik ang dating halaga.
    ///
    /// Ang matatag na bersyon ng intrinsic na ito ay magagamit sa mga uri ng [`atomic`] sa pamamagitan ng pamamaraang `fetch_or` sa pamamagitan ng pagpasa sa [`Ordering::SeqCst`] bilang `order`.
    /// Halimbawa, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise o sa kasalukuyang halaga, ibabalik ang dating halaga.
    ///
    /// Ang nagpapatatag bersyon ng intrinsic na ito ay magagamit sa mga uri [`atomic`] pamamagitan ng `fetch_or` paraan sa pamamagitan ng pagpasa [`Ordering::Acquire`] bilang ang `order`.
    /// Halimbawa, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise o sa kasalukuyang halaga, ibabalik ang dating halaga.
    ///
    /// Ang matatag na bersyon ng intrinsic na ito ay magagamit sa mga uri ng [`atomic`] sa pamamagitan ng pamamaraang `fetch_or` sa pamamagitan ng pagpasa sa [`Ordering::Release`] bilang `order`.
    /// Halimbawa, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise o sa kasalukuyang halaga, ibabalik ang dating halaga.
    ///
    /// Ang nagpapatatag bersyon ng intrinsic na ito ay magagamit sa mga uri [`atomic`] pamamagitan ng `fetch_or` paraan sa pamamagitan ng pagpasa [`Ordering::AcqRel`] bilang ang `order`.
    /// Halimbawa, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise o sa kasalukuyang halaga, ibabalik ang dating halaga.
    ///
    /// Ang nagpapatatag bersyon ng intrinsic na ito ay magagamit sa mga uri [`atomic`] pamamagitan ng `fetch_or` paraan sa pamamagitan ng pagpasa [`Ordering::Relaxed`] bilang ang `order`.
    /// Halimbawa, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitwise xor gamit ang mga kasalukuyang halaga, mga bumabalik na sa nakaraang halaga.
    ///
    /// Ang nagpapatatag bersyon ng intrinsic na ito ay magagamit sa mga uri [`atomic`] pamamagitan ng `fetch_xor` paraan sa pamamagitan ng pagpasa [`Ordering::SeqCst`] bilang ang `order`.
    /// Halimbawa, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise xor gamit ang mga kasalukuyang halaga, mga bumabalik na sa nakaraang halaga.
    ///
    /// Ang nagpapatatag bersyon ng intrinsic na ito ay magagamit sa mga uri [`atomic`] pamamagitan ng `fetch_xor` paraan sa pamamagitan ng pagpasa [`Ordering::Acquire`] bilang ang `order`.
    /// Halimbawa, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise xor gamit ang mga kasalukuyang halaga, mga bumabalik na sa nakaraang halaga.
    ///
    /// Ang nagpapatatag bersyon ng intrinsic na ito ay magagamit sa mga uri [`atomic`] pamamagitan ng `fetch_xor` paraan sa pamamagitan ng pagpasa [`Ordering::Release`] bilang ang `order`.
    /// Halimbawa, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise xor gamit ang mga kasalukuyang halaga, mga bumabalik na sa nakaraang halaga.
    ///
    /// Ang nagpapatatag bersyon ng intrinsic na ito ay magagamit sa mga uri [`atomic`] pamamagitan ng `fetch_xor` paraan sa pamamagitan ng pagpasa [`Ordering::AcqRel`] bilang ang `order`.
    /// Halimbawa, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise xor gamit ang mga kasalukuyang halaga, mga bumabalik na sa nakaraang halaga.
    ///
    /// Ang matatag na bersyon ng intrinsic na ito ay magagamit sa mga uri ng [`atomic`] sa pamamagitan ng pamamaraang `fetch_xor` sa pamamagitan ng pagpasa sa [`Ordering::Relaxed`] bilang `order`.
    /// Halimbawa, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Maximum sa kasalukuyang halaga gamit ang isang naka-sign na paghahambing.
    ///
    /// Ang nagpapatatag bersyon ng intrinsic na ito ay magagamit sa [`atomic`] sign integer uri sa pamamagitan ng `fetch_max` paraan sa pamamagitan ng pagpasa [`Ordering::SeqCst`] bilang ang `order`.
    /// Halimbawa, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maximum sa kasalukuyang halaga gamit ang isang naka-sign na paghahambing.
    ///
    /// Ang nagpapatatag bersyon ng intrinsic na ito ay magagamit sa [`atomic`] sign integer uri sa pamamagitan ng `fetch_max` paraan sa pamamagitan ng pagpasa [`Ordering::Acquire`] bilang ang `order`.
    /// Halimbawa, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maximum sa kasalukuyang halaga gamit ang isang naka-sign na paghahambing.
    ///
    /// Ang matatag na bersyon ng intrinsic na ito ay magagamit sa [`atomic`] na naka-sign na mga uri ng integer sa pamamagitan ng `fetch_max` na pamamaraan sa pamamagitan ng pagpasa sa [`Ordering::Release`] bilang `order`.
    /// Halimbawa, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maximum sa kasalukuyang halaga gamit ang isang naka-sign na paghahambing.
    ///
    /// Ang matatag na bersyon ng intrinsic na ito ay magagamit sa [`atomic`] na naka-sign na mga uri ng integer sa pamamagitan ng `fetch_max` na pamamaraan sa pamamagitan ng pagpasa sa [`Ordering::AcqRel`] bilang `order`.
    /// Halimbawa, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maximum sa kasalukuyang halaga.
    ///
    /// Ang matatag na bersyon ng intrinsic na ito ay magagamit sa [`atomic`] na naka-sign na mga uri ng integer sa pamamagitan ng `fetch_max` na pamamaraan sa pamamagitan ng pagpasa sa [`Ordering::Relaxed`] bilang `order`.
    /// Halimbawa, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Minimum gamit ang mga kasalukuyang halaga ng paggamit ng isang naka-sign paghahambing.
    ///
    /// Ang nagpapatatag bersyon ng intrinsic na ito ay magagamit sa [`atomic`] sign integer uri sa pamamagitan ng `fetch_min` paraan sa pamamagitan ng pagpasa [`Ordering::SeqCst`] bilang ang `order`.
    /// Halimbawa, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum gamit ang mga kasalukuyang halaga ng paggamit ng isang naka-sign paghahambing.
    ///
    /// Ang matatag na bersyon ng intrinsic na ito ay magagamit sa [`atomic`] na naka-sign na mga uri ng integer sa pamamagitan ng `fetch_min` na pamamaraan sa pamamagitan ng pagpasa sa [`Ordering::Acquire`] bilang `order`.
    /// Halimbawa, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum gamit ang mga kasalukuyang halaga ng paggamit ng isang naka-sign paghahambing.
    ///
    /// Ang matatag na bersyon ng intrinsic na ito ay magagamit sa [`atomic`] na naka-sign na mga uri ng integer sa pamamagitan ng `fetch_min` na pamamaraan sa pamamagitan ng pagpasa sa [`Ordering::Release`] bilang `order`.
    /// Halimbawa, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum gamit ang mga kasalukuyang halaga ng paggamit ng isang naka-sign paghahambing.
    ///
    /// Ang nagpapatatag bersyon ng intrinsic na ito ay magagamit sa [`atomic`] sign integer uri sa pamamagitan ng `fetch_min` paraan sa pamamagitan ng pagpasa [`Ordering::AcqRel`] bilang ang `order`.
    /// Halimbawa, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum gamit ang mga kasalukuyang halaga ng paggamit ng isang naka-sign paghahambing.
    ///
    /// Ang nagpapatatag bersyon ng intrinsic na ito ay magagamit sa [`atomic`] sign integer uri sa pamamagitan ng `fetch_min` paraan sa pamamagitan ng pagpasa [`Ordering::Relaxed`] bilang ang `order`.
    /// Halimbawa, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Minimum gamit ang mga kasalukuyang halaga gamit ang isang wala pang kontratang paghahambing.
    ///
    /// Ang nagpapatatag bersyon ng intrinsic na ito ay magagamit sa [`atomic`] unsigned uri ng integer sa pamamagitan ng `fetch_min` paraan sa pamamagitan ng pagpasa [`Ordering::SeqCst`] bilang ang `order`.
    /// Halimbawa, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum gamit ang mga kasalukuyang halaga gamit ang isang wala pang kontratang paghahambing.
    ///
    /// Ang nagpapatatag bersyon ng intrinsic na ito ay magagamit sa [`atomic`] unsigned uri ng integer sa pamamagitan ng `fetch_min` paraan sa pamamagitan ng pagpasa [`Ordering::Acquire`] bilang ang `order`.
    /// Halimbawa, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum gamit ang mga kasalukuyang halaga gamit ang isang wala pang kontratang paghahambing.
    ///
    /// Ang nagpapatatag na bersyon ng intrinsic na ito ay magagamit sa [`atomic`] unsigned integer uri sa pamamagitan ng `fetch_min` na pamamaraan sa pamamagitan ng pagpasa sa [`Ordering::Release`] bilang `order`.
    /// Halimbawa, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum gamit ang mga kasalukuyang halaga gamit ang isang wala pang kontratang paghahambing.
    ///
    /// Ang nagpapatatag na bersyon ng intrinsic na ito ay magagamit sa [`atomic`] unsigned integer uri sa pamamagitan ng `fetch_min` na pamamaraan sa pamamagitan ng pagpasa sa [`Ordering::AcqRel`] bilang `order`.
    /// Halimbawa, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum gamit ang mga kasalukuyang halaga gamit ang isang wala pang kontratang paghahambing.
    ///
    /// Ang nagpapatatag bersyon ng intrinsic na ito ay magagamit sa [`atomic`] unsigned uri ng integer sa pamamagitan ng `fetch_min` paraan sa pamamagitan ng pagpasa [`Ordering::Relaxed`] bilang ang `order`.
    /// Halimbawa, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Maximum sa kasalukuyang halaga gamit ang isang hindi naka-sign na paghahambing.
    ///
    /// Ang nagpapatatag na bersyon ng intrinsic na ito ay magagamit sa [`atomic`] unsigned integer uri sa pamamagitan ng `fetch_max` na pamamaraan sa pamamagitan ng pagpasa sa [`Ordering::SeqCst`] bilang `order`.
    /// Halimbawa, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maximum sa kasalukuyang halaga gamit ang isang hindi naka-sign na paghahambing.
    ///
    /// Ang nagpapatatag bersyon ng intrinsic na ito ay magagamit sa [`atomic`] unsigned uri ng integer sa pamamagitan ng `fetch_max` paraan sa pamamagitan ng pagpasa [`Ordering::Acquire`] bilang ang `order`.
    /// Halimbawa, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maximum sa kasalukuyang halaga gamit ang isang hindi naka-sign na paghahambing.
    ///
    /// Ang nagpapatatag bersyon ng intrinsic na ito ay magagamit sa [`atomic`] unsigned uri ng integer sa pamamagitan ng `fetch_max` paraan sa pamamagitan ng pagpasa [`Ordering::Release`] bilang ang `order`.
    /// Halimbawa, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maximum sa kasalukuyang halaga gamit ang isang hindi naka-sign na paghahambing.
    ///
    /// Ang nagpapatatag na bersyon ng intrinsic na ito ay magagamit sa [`atomic`] unsigned integer uri sa pamamagitan ng `fetch_max` na pamamaraan sa pamamagitan ng pagpasa sa [`Ordering::AcqRel`] bilang `order`.
    /// Halimbawa, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maximum sa kasalukuyang halaga gamit ang isang hindi naka-sign na paghahambing.
    ///
    /// Ang nagpapatatag bersyon ng intrinsic na ito ay magagamit sa [`atomic`] unsigned uri ng integer sa pamamagitan ng `fetch_max` paraan sa pamamagitan ng pagpasa [`Ordering::Relaxed`] bilang ang `order`.
    /// Halimbawa, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Ang `prefetch` intrinsic ay isang hint sa code generator upang magsingit ng isang prefetch pagtuturo kung suportado;kung hindi man, ito ay isang walang-op.
    /// Ang mga prefetches ay walang epekto sa pag-uugali ng programa ngunit maaaring baguhin ang mga katangian ng pagganap nito.
    ///
    /// Ang `locality` argument ay dapat na isang pare-pareho ang integer at ito ay isang temporal lokalidad specifier sumasaklaw mula (0), walang lokalidad, na (3), lubos na lokal na ingatan ninyo sa cache.
    ///
    ///
    /// Ang intrinsic na ito ay walang isang matatag na katapat.
    ///
    ///
    pub fn prefetch_read_data<T>(data: *const T, locality: i32);
    /// Ang `prefetch` intrinsic ay isang hint sa code generator upang magsingit ng isang prefetch pagtuturo kung suportado;kung hindi man, ito ay isang walang-op.
    /// Ang mga prefetches ay walang epekto sa pag-uugali ng programa ngunit maaaring baguhin ang mga katangian ng pagganap nito.
    ///
    /// Ang `locality` argument ay dapat na isang pare-pareho ang integer at ito ay isang temporal lokalidad specifier sumasaklaw mula (0), walang lokalidad, na (3), lubos na lokal na ingatan ninyo sa cache.
    ///
    ///
    /// Ang intrinsic na ito ay walang isang matatag na katapat.
    ///
    ///
    pub fn prefetch_write_data<T>(data: *const T, locality: i32);
    /// Ang `prefetch` intrinsic ay isang hint sa code generator upang magsingit ng isang prefetch pagtuturo kung suportado;kung hindi man, ito ay isang walang-op.
    /// Ang mga prefetches ay walang epekto sa pag-uugali ng programa ngunit maaaring baguhin ang mga katangian ng pagganap nito.
    ///
    /// Ang `locality` argument ay dapat na isang pare-pareho ang integer at ito ay isang temporal lokalidad specifier sumasaklaw mula (0), walang lokalidad, na (3), lubos na lokal na ingatan ninyo sa cache.
    ///
    ///
    /// Ang intrinsic na ito ay walang isang matatag na katapat.
    ///
    ///
    pub fn prefetch_read_instruction<T>(data: *const T, locality: i32);
    /// Ang `prefetch` intrinsic ay isang hint sa code generator upang magsingit ng isang prefetch pagtuturo kung suportado;kung hindi man, ito ay isang walang-op.
    /// Ang mga prefetches ay walang epekto sa pag-uugali ng programa ngunit maaaring baguhin ang mga katangian ng pagganap nito.
    ///
    /// Ang `locality` argument ay dapat na isang pare-pareho ang integer at ito ay isang temporal lokalidad specifier sumasaklaw mula (0), walang lokalidad, na (3), lubos na lokal na ingatan ninyo sa cache.
    ///
    ///
    /// Ang intrinsic na ito ay walang isang matatag na katapat.
    ///
    ///
    pub fn prefetch_write_instruction<T>(data: *const T, locality: i32);
}

extern "rust-intrinsic" {
    /// Isang bakod na atomic.
    ///
    /// Ang matatag na bersyon ng intrinsic na ito ay magagamit sa [`atomic::fence`] sa pamamagitan ng pagpasa sa [`Ordering::SeqCst`] bilang `order`.
    ///
    ///
    pub fn atomic_fence();
    /// Isang bakod na atomic.
    ///
    /// Ang matatag na bersyon ng intrinsic na ito ay magagamit sa [`atomic::fence`] sa pamamagitan ng pagpasa sa [`Ordering::Acquire`] bilang `order`.
    ///
    ///
    pub fn atomic_fence_acq();
    /// Isang bakod na atomic.
    ///
    /// Ang nagpapatatag bersyon ng intrinsic na ito ay magagamit sa [`atomic::fence`] sa pamamagitan ng pagpasa [`Ordering::Release`] bilang ang `order`.
    ///
    ///
    pub fn atomic_fence_rel();
    /// Isang bakod na atomic.
    ///
    /// Ang nagpapatatag bersyon ng intrinsic na ito ay magagamit sa [`atomic::fence`] sa pamamagitan ng pagpasa [`Ordering::AcqRel`] bilang ang `order`.
    ///
    ///
    pub fn atomic_fence_acqrel();

    /// Ang isang compiler-only memory barrier.
    ///
    /// Memory accesses ay hindi kailanman reordered sa kabuuan na ito barrier sa pamamagitan ng compiler, ngunit walang mga tagubilin ay napalabas para dito.
    /// Angkop ito para sa mga pagpapatakbo sa parehong thread na maaaring pauna, tulad ng kapag nakikipag-ugnay sa mga handler ng signal.
    ///
    /// Ang nagpapatatag bersyon ng intrinsic na ito ay magagamit sa [`atomic::compiler_fence`] sa pamamagitan ng pagpasa [`Ordering::SeqCst`] bilang ang `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence();
    /// Ang isang compiler-only memory barrier.
    ///
    /// Memory accesses ay hindi kailanman reordered sa kabuuan na ito barrier sa pamamagitan ng compiler, ngunit walang mga tagubilin ay napalabas para dito.
    /// Angkop ito para sa mga pagpapatakbo sa parehong thread na maaaring pauna, tulad ng kapag nakikipag-ugnay sa mga handler ng signal.
    ///
    /// Ang nagpapatatag bersyon ng intrinsic na ito ay magagamit sa [`atomic::compiler_fence`] sa pamamagitan ng pagpasa [`Ordering::Acquire`] bilang ang `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acq();
    /// Ang isang compiler-only memory barrier.
    ///
    /// Memory accesses ay hindi kailanman reordered sa kabuuan na ito barrier sa pamamagitan ng compiler, ngunit walang mga tagubilin ay napalabas para dito.
    /// Angkop ito para sa mga pagpapatakbo sa parehong thread na maaaring pauna, tulad ng kapag nakikipag-ugnay sa mga handler ng signal.
    ///
    /// Ang matatag na bersyon ng intrinsic na ito ay magagamit sa [`atomic::compiler_fence`] sa pamamagitan ng pagpasa sa [`Ordering::Release`] bilang `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_rel();
    /// Ang isang compiler-only memory barrier.
    ///
    /// Memory accesses ay hindi kailanman reordered sa kabuuan na ito barrier sa pamamagitan ng compiler, ngunit walang mga tagubilin ay napalabas para dito.
    /// Angkop ito para sa mga pagpapatakbo sa parehong thread na maaaring pauna, tulad ng kapag nakikipag-ugnay sa mga handler ng signal.
    ///
    /// Ang matatag na bersyon ng intrinsic na ito ay magagamit sa [`atomic::compiler_fence`] sa pamamagitan ng pagpasa sa [`Ordering::AcqRel`] bilang `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acqrel();

    /// Magic intrinsic na nakukuha ang kahulugan nito mula sa mga katangiang nakakabit sa pagpapaandar.
    ///
    /// Halimbawa, ginagamit ito ng dataflow upang mag-iniksyon ng mga static na assertion upang ang `rustc_peek(potentially_uninitialized)` ay talagang i-double-check na ang dataflow ay talagang nagkalkula na ito ay hindi sinasadya sa puntong iyon sa daloy ng kontrol.
    ///
    ///
    /// intrinsic na ito ay hindi dapat gamitin sa labas ng compiler.
    ///
    ///
    ///
    pub fn rustc_peek<T>(_: T) -> T;

    /// Inihahatid ang pagpapatupad ng proseso.
    ///
    /// Ang isang mas madaling gamitin at matatag na bersyon ng operasyon na ito ay [`std::process::abort`](../../std/process/fn.abort.html).
    ///
    pub fn abort() -> !;

    /// Ipinaaalam sa optimizer na ang puntong ito sa code ay hindi maabot, na nagbibigay-daan sa karagdagang mga pag-optimize.
    ///
    /// NB, ito ay napaka naiiba mula sa mga `unreachable!()` macro: Hindi tulad ng macro, na kung saan panics kapag ito ay pinaandar, ito ay *hindi natukoy na pag-uugali* upang maabot ang code na minarkahan ng ang function na ito.
    ///
    ///
    /// Ang nagpapatatag na bersyon ng intrinsic na ito ay [`core::hint::unreachable_unchecked`](crate::hint::unreachable_unchecked).
    ///
    ///
    #[rustc_const_unstable(feature = "const_unreachable_unchecked", issue = "53188")]
    pub fn unreachable() -> !;

    /// Ipinaalam sa optimizer na ang isang kundisyon ay laging totoo.
    /// Kung ang kondisyon ay mali, ang pag-uugali ay hindi natukoy.
    ///
    /// Walang nabuong code para sa intrinsic na ito, ngunit susubukan ng optimizer na mapanatili ito (at ang kundisyon nito) sa pagitan ng mga pass, na maaaring makagambala sa pag-optimize ng nakapalibot na code at mabawasan ang pagganap.
    /// Hindi ito dapat gamitin kung ang invariant ay maaaring natuklasan sa pamamagitan ng optimizer sa kanyang sarili, o kung ito ay hindi paganahin ang anumang makabuluhang pag-optimize.
    ///
    /// Ang intrinsic na ito ay walang isang matatag na katapat.
    ///
    ///
    ///
    #[rustc_const_unstable(feature = "const_assume", issue = "76972")]
    pub fn assume(b: bool);

    /// Mga pahiwatig sa tagatala na ang kundisyon ng branch ay malamang na totoo.
    /// Ibinabalik ang halagang ipinasa rito.
    ///
    /// Anumang paggamit maliban sa may mga pahayag na `if` ay maaaring walang epekto.
    ///
    /// Ang intrinsic na ito ay walang isang matatag na katapat.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn likely(b: bool) -> bool;

    /// Hint sa compiler na branch kondisyon ay malamang na hindi totoo.
    /// Ibinabalik ang halagang ipinasa rito.
    ///
    /// Anumang paggamit maliban sa may mga pahayag na `if` ay maaaring walang epekto.
    ///
    /// Ang intrinsic na ito ay walang isang matatag na katapat.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn unlikely(b: bool) -> bool;

    /// Nagpapatupad ng isang breakpoint trap, para sa inspeksyon ng isang debugger.
    ///
    /// Ang intrinsic na ito ay walang isang matatag na katapat.
    pub fn breakpoint();

    /// Ang laki ng isang uri ng byte.
    ///
    /// Mas partikular, ito ay ang offset sa bytes sa pagitan ng sunud-sunod mga item ng parehong uri, kabilang ang alignment padding.
    ///
    ///
    /// Ang nagpapatatag bersyon ng intrinsic na ito ay [`core::mem::size_of`](crate::mem::size_of).
    #[rustc_const_stable(feature = "const_size_of", since = "1.40.0")]
    pub fn size_of<T>() -> usize;

    /// Ang minimum na pagkakahanay ng isang uri.
    ///
    /// Ang nagpapatatag na bersyon ng intrinsic na ito ay [`core::mem::align_of`](crate::mem::align_of).
    #[rustc_const_stable(feature = "const_min_align_of", since = "1.40.0")]
    pub fn min_align_of<T>() -> usize;
    /// Ang ginustong pag-align ng isang uri.
    ///
    /// Ang intrinsic na ito ay walang isang matatag na katapat.
    #[rustc_const_unstable(feature = "const_pref_align_of", issue = "none")]
    pub fn pref_align_of<T>() -> usize;

    /// Ang laki ng reference halaga sa bytes.
    ///
    /// Ang nagpapatatag bersyon ng intrinsic na ito ay [`mem::size_of_val`].
    #[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
    pub fn size_of_val<T: ?Sized>(_: *const T) -> usize;
    /// Ang kinakailangang pagkakahanay ng na-refer na halaga.
    ///
    /// Ang nagpapatatag na bersyon ng intrinsic na ito ay [`core::mem::align_of_val`](crate::mem::align_of_val).
    #[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
    pub fn min_align_of_val<T: ?Sized>(_: *const T) -> usize;

    /// Nakakakuha ng isang static na hiwa ng string na naglalaman ng pangalan ng isang uri.
    ///
    /// Ang nagpapatatag na bersyon ng intrinsic na ito ay [`core::any::type_name`](crate::any::type_name).
    #[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
    pub fn type_name<T: ?Sized>() -> &'static str;

    /// Ay makakakuha ng isang identifier na kung saan ay globally natatanging sa tinukoy na uri.
    /// Ang pagpapaandar na ito ay ibabalik ang parehong halaga para sa isang uri anuman ang alinman sa crate na ito ay inanyayahan.
    ///
    ///
    /// Ang nagpapatatag na bersyon ng intrinsic na ito ay [`core::any::TypeId::of`](crate::any::TypeId::of).
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub fn type_id<T: ?Sized + 'static>() -> u64;

    /// Ang isang bantay para sa mga hindi ligtas na mga pag-andar na maaaring hindi kailanman ay naisakatuparan kung `T` ay hindi tinitirahan:
    /// Ito ay statically alinman sa panic, o walang gawin.
    ///
    /// Ang intrinsic na ito ay walang isang matatag na katapat.
    #[rustc_const_unstable(feature = "const_assert_type", issue = "none")]
    pub fn assert_inhabited<T>();

    /// Ang isang bantay para sa mga hindi ligtas na mga pag-andar na maaaring hindi kailanman ay naisakatuparan kung `T` Hindi pinahihintulutan ng zero-initialization: Ito ay statically mag panic, o wala.
    ///
    ///
    /// Ang intrinsic na ito ay walang isang matatag na katapat.
    pub fn assert_zero_valid<T>();

    /// Ang isang bantay para sa mga hindi ligtas na pag-andar na hindi maaaring maipatupad kung ang `T` ay may di wastong mga pattern ng bit: Ito ay statically alinman sa panic, o wala.
    ///
    ///
    /// Ang intrinsic na ito ay walang isang matatag na katapat.
    pub fn assert_uninit_valid<T>();

    /// Nakakakuha ng isang reference sa isang static `Location` na nagpapahiwatig kung saan ito ay tinatawag na.
    ///
    /// Isaalang-alang ang paggamit ng [`core::panic::Location::caller`](crate::panic::Location::caller) sa halip.
    #[rustc_const_unstable(feature = "const_caller_location", issue = "76156")]
    pub fn caller_location() -> &'static crate::panic::Location<'static>;

    /// Inililipat ang halaga sa labas ng saklaw nang hindi nagpapatakbo drop pandikit.
    ///
    /// Ito ay umiiral lamang para sa [`mem::forget_unsized`];ang normal na `forget` ay gumagamit ng `ManuallyDrop` sa halip.
    ///
    #[rustc_const_unstable(feature = "const_intrinsic_forget", issue = "none")]
    pub fn forget<T: ?Sized>(_: T);

    /// Binibigyang kahulugan ang mga piraso ng isang halaga ng isang uri bilang ibang uri.
    ///
    /// Ang parehong mga uri ay dapat magkaroon ng parehong laki.
    /// Wala sa alinman sa orihinal, o ang mga resulta, maaaring maging isang [invalid value](../../nomicon/what-unsafe-does.html).
    ///
    /// `transmute` ay katumbas na semantiko sa isang bahagyang paglipat ng isang uri sa isa pa.Ito ay kopya ng mga piraso mula sa ang halaga ng mapagkukunan sa ang halaga na patutunguhan, at pagkatapos ay nakalimutan ang orihinal.
    /// Ito ay katumbas sa C `memcpy` sa ilalim ng hood, tulad ng `transmute_copy`.
    ///
    /// Dahil `transmute` ay isang by-halaga na operasyon, pagkakahanay ng *transmuted halaga ang kanilang mga sarili* ay hindi isang alalahanin.
    /// Tulad ng anumang iba pang pagpapaandar, tinitiyak na ng tagatala ang parehong `T` at `U` ay maayos na nakahanay.
    /// Gayunpaman, kapag nagpapalipat ng mga halagang *nagtuturo sa ibang lugar*(tulad ng mga payo, sanggunian, kahon ...), kailangang tiyakin ng tumatawag ang wastong pagkakahanay ng mga itinuturo na halaga.
    ///
    /// `transmute` ay **hindi kapani-paniwalang** hindi ligtas.May isang malawak na bilang ng mga paraan upang maging sanhi ng [undefined behavior][ub] may ganitong function.Ang `transmute` ay dapat na ang ganap na huling paraan.
    ///
    /// Ang [nomicon](../../nomicon/transmutes.html) ay may karagdagang dokumentasyon.
    ///
    /// [ub]: ../../reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// Mayroong ilang mga bagay na talagang kapaki-pakinabang para sa `transmute`.
    ///
    /// Ang pag-on ng isang puntero sa isang function pointer.Ito ay *hindi* portable na machine na kung saan ang mga payo function at data pointer may iba't-ibang mga sukat.
    ///
    /// ```
    /// fn foo() -> i32 {
    ///     0
    /// }
    /// let pointer = foo as *const ();
    /// let function = unsafe {
    ///     std::mem::transmute::<*const (), fn() -> i32>(pointer)
    /// };
    /// assert_eq!(function(), 0);
    /// ```
    ///
    /// Pagpapalawak ng isang panghabang buhay, o pagpapaikli ng isang walang paltos buhay.Ito ay advanced, napaka hindi ligtas na Rust!
    ///
    /// ```
    /// struct R<'a>(&'a i32);
    /// unsafe fn extend_lifetime<'b>(r: R<'b>) -> R<'static> {
    ///     std::mem::transmute::<R<'b>, R<'static>>(r)
    /// }
    ///
    /// unsafe fn shorten_invariant_lifetime<'b, 'c>(r: &'b mut R<'static>)
    ///                                              -> &'b mut R<'c> {
    ///     std::mem::transmute::<&'b mut R<'static>, &'b mut R<'c>>(r)
    /// }
    /// ```
    ///
    /// # Alternatives
    ///
    /// Huwag malungkot: maraming gamit ng `transmute` ay maaaring nakakamit sa pamamagitan ng ibang paraan.
    /// Nasa ibaba ang mga karaniwang aplikasyon ng `transmute` na maaaring mapalitan ng mas ligtas na constructs.
    ///
    /// Ginagawang bytes(`&[u8]`) hanggang `u32`, `f64`, atbp.:
    ///
    /// ```
    /// let raw_bytes = [0x78, 0x56, 0x34, 0x12];
    ///
    /// let num = unsafe {
    ///     std::mem::transmute::<[u8; 4], u32>(raw_bytes)
    /// };
    ///
    /// // paggamit `u32::from_ne_bytes` halip
    /// let num = u32::from_ne_bytes(raw_bytes);
    /// // o gamitin `u32::from_le_bytes` o `u32::from_be_bytes` upang tukuyin ang endianness
    /// let num = u32::from_le_bytes(raw_bytes);
    /// assert_eq!(num, 0x12345678);
    /// let num = u32::from_be_bytes(raw_bytes);
    /// assert_eq!(num, 0x78563412);
    /// ```
    ///
    /// Ang pag-on ng isang pointer sa isang `usize`:
    ///
    /// ```
    /// let ptr = &0;
    /// let ptr_num_transmute = unsafe {
    ///     std::mem::transmute::<&i32, usize>(ptr)
    /// };
    ///
    /// // Gumamit ng isang `as` cast sa halip
    /// let ptr_num_cast = ptr as *const i32 as usize;
    /// ```
    ///
    /// Ang pag-on ng isang `*mut T` sa isang `&mut T`:
    ///
    /// ```
    /// let ptr: *mut i32 = &mut 0;
    /// let ref_transmuted = unsafe {
    ///     std::mem::transmute::<*mut i32, &mut i32>(ptr)
    /// };
    ///
    /// // Gumamit ng isang reborrow halip
    /// let ref_casted = unsafe { &mut *ptr };
    /// ```
    ///
    /// Ginagawang `&mut U` ang `&mut U`:
    ///
    /// ```
    /// let ptr = &mut 0;
    /// let val_transmuted = unsafe {
    ///     std::mem::transmute::<&mut i32, &mut u32>(ptr)
    /// };
    ///
    /// // Ngayon, magkasama `as` at reborrowing, tandaan ang chaining ng `as` `as` ay hindi palipat
    /////
    /// let val_casts = unsafe { &mut *(ptr as *mut i32 as *mut u32) };
    /// ```
    ///
    /// Ginagawang `&[u8]` ang `&[u8]`:
    ///
    /// ```
    /// // hindi ito mabuting paraan upang magawa ito.
    /// let slice = unsafe { std::mem::transmute::<&str, &[u8]>("Rust") };
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // Maaari mong gamitin ang `str::as_bytes`
    /// let slice = "Rust".as_bytes();
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // O, gumamit lamang ng isang byte string, kung mayroon kang kontrol sa literal na string
    /////
    /// assert_eq!(b"Rust", &[82, 117, 115, 116]);
    /// ```
    ///
    /// Ginagawang `Vec<Option<&T>>` ang `Vec<Option<&T>>`.
    ///
    /// Upang ilipat ang panloob na uri ng mga nilalaman ng isang lalagyan, dapat mong tiyakin na hindi lumalabag sa anumang ng invariants ng sisidlan.
    /// Para sa `Vec`, nangangahulugan ito na ang parehong laki *at pagkakahanay* ng mga panloob na uri ay kailangang tumugma.
    /// Iba pang mga lalagyan ay maaaring umaasa sa ang laki ng uri, pag-align, o kahit na ang `TypeId`, kung saan transmuting ay hindi magiging posible sa lahat nang walang paglabag ang container invariants.
    ///
    ///
    /// ```
    /// let store = [0, 1, 2, 3];
    /// let v_orig = store.iter().collect::<Vec<&i32>>();
    ///
    /// // I-clone ang vector pati kami ay muling gamitin ang mga ito sa ibang pagkakataon
    /// let v_clone = v_orig.clone();
    ///
    /// // Paggamit magbago: ito ay nakasalalay sa hindi natukoy na data layout ng `Vec`, na kung saan ay isang masamang ideya at maaaring maging sanhi Di natukoy Pag-uugali.
    /////
    /// // Gayunpaman, ito ay walang kopya.
    /// let v_transmuted = unsafe {
    ///     std::mem::transmute::<Vec<&i32>, Vec<Option<&i32>>>(v_clone)
    /// };
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // Ito ang iminungkahing, ligtas na paraan.
    /// // Ito ay hindi kopyahin ang buong vector, bagaman, sa isang bagong array.
    /// let v_collected = v_clone.into_iter()
    ///                          .map(Some)
    ///                          .collect::<Vec<Option<&i32>>>();
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // Ito ang tamang walang kopya, hindi ligtas na paraan ng "transmuting" isang `Vec`, nang hindi umaasa sa layout ng data.
    /// // Sa halip na literal na tawagan ang `transmute`, nagsasagawa kami ng isang pointer cast, ngunit sa mga tuntunin ng pag-convert ng orihinal na panloob na uri na (`&i32`) sa bago ng (`Option<&i32>`), mayroon itong lahat ng parehong mga pag-uusap.
    /////
    /// // Bukod sa mga impormasyon na ibinigay sa itaas, ring konsultahin ang [`from_raw_parts`] babasahin.
    /////
    /// let v_from_raw = unsafe {
    ///     // FIXME I-update ito kapag na-stabilize ang vector_into_raw_parts.
    ///     // Tiyaking ang orihinal na vector ay hindi nahulog.
    ///     let mut v_clone = std::mem::ManuallyDrop::new(v_clone);
    ///     Vec::from_raw_parts(v_clone.as_mut_ptr() as *mut Option<&i32>,
    ///                         v_clone.len(),
    ///                         v_clone.capacity())
    /// };
    /// ```
    ///
    /// [`from_raw_parts`]: ../../std/vec/struct.Vec.html#method.from_raw_parts
    ///
    /// Pagpapatupad ng `split_at_mut`:
    ///
    /// ```
    /// use std::{slice, mem};
    ///
    /// // Mayroong maraming mga paraan upang magawa ito, at maraming mga problema sa sumusunod na (transmute) na paraan.
    /////
    /// fn split_at_mut_transmute<T>(slice: &mut [T], mid: usize)
    ///                              -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = mem::transmute::<&mut [T], &mut [T]>(slice);
    ///         // una: ang transmute ay hindi ligtas na uri;ang tseke lang nito ay ang T at
    ///         // Pareho ang laki ng U.
    ///         // Pangalawa, dito mismo, mayroon kang dalawang mga nababagong sanggunian na tumuturo sa parehong memorya.
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // Tinatanggal nito ang uri ng mga problema sa kaligtasan;`&mut *` ay* magbibigay *lamang sa iyo ng isang `&mut T` mula sa isang `&mut T` o `* mut T`.
    /////
    /// fn split_at_mut_casts<T>(slice: &mut [T], mid: usize)
    ///                          -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = &mut *(slice as *mut [T]);
    ///         // gayunpaman, mayroon ka pa ring dalawang mutable mga sanggunian na tumuturo sa parehong memorya.
    /////
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // Ganito ito ginagawa ng karaniwang silid-aklatan.
    /// // Ito ang pinakamahusay na pamamaraan, kung kailangan mong gumawa ng tulad nito
    /// fn split_at_stdlib<T>(slice: &mut [T], mid: usize)
    ///                       -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let ptr = slice.as_mut_ptr();
    ///         // Ito ngayon ay may tatlong mutable mga sanggunian na tumuturo sa parehong memorya.`slice`, ang rvalue ret.0, at ang rvalue ret.1.
    ///         // `slice` ay hindi kailanman ginamit pagkatapos ng `let ptr = ...`, at sa gayon ay maaari itong tratuhin bilang "dead", at samakatuwid, mayroon kang dalawang tunay na hiwa na nababago.
    /////
    /////
    /////
    ///         (slice::from_raw_parts_mut(ptr, mid),
    ///          slice::from_raw_parts_mut(ptr.add(mid), len - mid))
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    // NOTE: Habang ginagawa nitong matatag ang intrinsic const, mayroon kaming ilang pasadyang code sa const fn
    // tseke na maiwasan ang paggamit nito sa loob `const fn`.
    #[rustc_const_stable(feature = "const_transmute", since = "1.46.0")]
    #[rustc_diagnostic_item = "transmute"]
    pub fn transmute<T, U>(e: T) -> U;

    /// Ibinabalik ang `true` kung ang aktwal na uri na ibinigay bilang `T` ay nangangailangan ng drop glue;nagbabalik `false` kung ang aktwal na i-type ang ibinigay para `T` nagpapatupad `Copy`.
    ///
    ///
    /// Kung ang aktwal na i-type ang hindi nangangailangan ng drop pandikit o nagpapatupad `Copy`, pagkatapos ay ang return halaga ng function na ito ay hindi natukoy.
    ///
    /// Ang nagpapatatag na bersyon ng intrinsic na ito ay [`mem::needs_drop`](crate::mem::needs_drop).
    ///
    ///
    #[rustc_const_stable(feature = "const_needs_drop", since = "1.40.0")]
    pub fn needs_drop<T>() -> bool;

    /// Kinakalkula ang offset mula sa isang pointer.
    ///
    /// Ipinatupad ito bilang isang intrinsic upang maiwasan ang pag-convert sa at mula sa isang integer, dahil ang pagtatapon ay magtatapon ng impormasyon sa aliasing.
    ///
    /// # Safety
    ///
    /// Ang parehong mga nagsisimula at nagreresulta pointer ay dapat na alinman sa mga hangganan o isa byte lagpas sa pagtatapos ng isang inilalaan object.
    /// Kung ang alinman sa pointer ay wala sa mga hangganan o arithmetic overflow na nangyayari pagkatapos ng anumang karagdagang paggamit ng naibalik na halaga ay magreresulta sa hindi natukoy na pag-uugali.
    ///
    ///
    /// Ang nagpapatatag bersyon ng intrinsic na ito ay [`pointer::offset`].
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn offset<T>(dst: *const T, offset: isize) -> *const T;

    /// Kinakalkula ang mga supling mula sa isang pointer, potensyal wrapping.
    ///
    /// Ipinatupad ito bilang isang intrinsic upang maiwasan ang pag-convert sa at mula sa isang integer, dahil pinipigilan ng conversion ang ilang mga pag-optimize.
    ///
    /// # Safety
    ///
    /// Hindi tulad ng `offset` tunay, ito tunay ay hindi rendahan ang mga nagresultang pointer sa puntong sa loob o sa isa byte lagpas sa pagtatapos ng isang inilalaan object, at ito bumabalot na may dalawang ni pampuno aritmetika.
    /// Ang resultang halaga ay hindi kinakailangan valid na gagamitin sa aktwal na pag-access memory.
    ///
    /// Ang nagpapatatag bersyon ng intrinsic na ito ay [`pointer::wrapping_offset`].
    ///
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn arith_offset<T>(dst: *const T, offset: isize) -> *const T;

    /// Katumbas ng naaangkop na `llvm.memcpy.p0i8.0i8.*` intrinsic, na may isang sukat ng `count`*`size_of::<T>()` at isang pagkakahanay ng
    ///
    /// `min_align_of::<T>()`
    ///
    /// Ang volatile parameter ay nakatakda sa `true`, kaya ito ay hindi-optimize out maliban laki ay katumbas ng zero.
    ///
    /// Ang intrinsic na ito ay walang isang matatag na katapat.
    ///
    pub fn volatile_copy_nonoverlapping_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// Katumbas ng naaangkop na `llvm.memmove.p0i8.0i8.*` intrinsic, na may isang sukat ng `count* size_of::<T>()` at isang pagkakahanay ng
    ///
    /// `min_align_of::<T>()`
    ///
    /// Ang volatile parameter ay nakatakda sa `true`, kaya ito ay hindi-optimize out maliban laki ay katumbas ng zero.
    ///
    /// Ang intrinsic na ito ay walang isang matatag na katapat.
    ///
    pub fn volatile_copy_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// Katumbas ng naaangkop na `llvm.memset.p0i8.*` intrinsic, na may isang sukat ng `count* size_of::<T>()` at isang pagkakahanay ng `min_align_of::<T>()`.
    ///
    ///
    /// Ang volatile parameter ay nakatakda sa `true`, kaya ito ay hindi-optimize out maliban laki ay katumbas ng zero.
    ///
    /// Ang intrinsic na ito ay walang isang matatag na katapat.
    ///
    ///
    pub fn volatile_set_memory<T>(dst: *mut T, val: u8, count: usize);

    /// Nagsasagawa ng isang pabagu-bago ng isip na pag-load mula sa `src` pointer.
    ///
    /// Ang nagpapatatag bersyon ng intrinsic na ito ay [`core::ptr::read_volatile`](crate::ptr::read_volatile).
    pub fn volatile_load<T>(src: *const T) -> T;
    /// Nagsasagawa ng volatile store sa `dst` pointer.
    ///
    /// Ang nagpapatatag bersyon ng intrinsic na ito ay [`core::ptr::write_volatile`](crate::ptr::write_volatile).
    pub fn volatile_store<T>(dst: *mut T, val: T);

    /// Nagsasagawa ng isang pabagu-bago ng isip na pag-load mula sa pointer ng `src` Ang pointer ay hindi kinakailangan upang makahanay.
    ///
    ///
    /// Ang intrinsic na ito ay walang isang matatag na katapat.
    pub fn unaligned_volatile_load<T>(src: *const T) -> T;
    /// Nagsasagawa ng volatile store sa `dst` pointer.
    /// Ang pointer ay hindi kinakailangan upang maging nakahanay.
    ///
    /// Ang intrinsic na ito ay walang isang matatag na katapat.
    pub fn unaligned_volatile_store<T>(dst: *mut T, val: T);

    /// Ibinabalik ang square root ng isang `f32`
    ///
    /// Ang nagpapatatag na bersyon ng intrinsic na ito ay
    /// [`f32::sqrt`](../../std/primitive.f32.html#method.sqrt)
    pub fn sqrtf32(x: f32) -> f32;
    /// Ibinabalik ang square root ng isang `f64`
    ///
    /// Ang nagpapatatag na bersyon ng intrinsic na ito ay
    /// [`f64::sqrt`](../../std/primitive.f64.html#method.sqrt)
    pub fn sqrtf64(x: f64) -> f64;

    /// Tinaasan ang isang `f32` sa isang integer power.
    ///
    /// Ang nagpapatatag na bersyon ng intrinsic na ito ay
    /// [`f32::powi`](../../std/primitive.f32.html#method.powi)
    pub fn powif32(a: f32, x: i32) -> f32;
    /// Nagbabangon ito ng isang `f64` sa isang power integer.
    ///
    /// Ang nagpapatatag na bersyon ng intrinsic na ito ay
    /// [`f64::powi`](../../std/primitive.f64.html#method.powi)
    pub fn powif64(a: f64, x: i32) -> f64;

    /// Ibinabalik ang sine ng isang `f32`.
    ///
    /// Ang nagpapatatag na bersyon ng intrinsic na ito ay
    /// [`f32::sin`](../../std/primitive.f32.html#method.sin)
    pub fn sinf32(x: f32) -> f32;
    /// Ibinabalik ang sine ng isang `f64`.
    ///
    /// Ang nagpapatatag na bersyon ng intrinsic na ito ay
    /// [`f64::sin`](../../std/primitive.f64.html#method.sin)
    pub fn sinf64(x: f64) -> f64;

    /// Ibinabalik ang cosine ng isang `f32`.
    ///
    /// Ang nagpapatatag na bersyon ng intrinsic na ito ay
    /// [`f32::cos`](../../std/primitive.f32.html#method.cos)
    pub fn cosf32(x: f32) -> f32;
    /// Ibinabalik ang cosine ng isang `f64`.
    ///
    /// Ang nagpapatatag na bersyon ng intrinsic na ito ay
    /// [`f64::cos`](../../std/primitive.f64.html#method.cos)
    pub fn cosf64(x: f64) -> f64;

    /// Nagbabangon ito ng isang `f32` sa isang `f32` kapangyarihan.
    ///
    /// Ang nagpapatatag na bersyon ng intrinsic na ito ay
    /// [`f32::powf`](../../std/primitive.f32.html#method.powf)
    pub fn powf32(a: f32, x: f32) -> f32;
    /// Nagbabangon ito ng isang `f64` sa isang `f64` kapangyarihan.
    ///
    /// Ang nagpapatatag na bersyon ng intrinsic na ito ay
    /// [`f64::powf`](../../std/primitive.f64.html#method.powf)
    pub fn powf64(a: f64, x: f64) -> f64;

    /// Ibinabalik ang exponential ng isang `f32`.
    ///
    /// Ang nagpapatatag na bersyon ng intrinsic na ito ay
    /// [`f32::exp`](../../std/primitive.f32.html#method.exp)
    pub fn expf32(x: f32) -> f32;
    /// Ibinabalik ang exponential ng isang `f64`.
    ///
    /// Ang nagpapatatag na bersyon ng intrinsic na ito ay
    /// [`f64::exp`](../../std/primitive.f64.html#method.exp)
    pub fn expf64(x: f64) -> f64;

    /// Ibinabalik ang 2 na itinaas sa lakas ng isang `f32`.
    ///
    /// Ang nagpapatatag na bersyon ng intrinsic na ito ay
    /// [`f32::exp2`](../../std/primitive.f32.html#method.exp2)
    pub fn exp2f32(x: f32) -> f32;
    /// Ibinabalik ang 2 na itinaas sa lakas ng isang `f64`.
    ///
    /// Ang nagpapatatag na bersyon ng intrinsic na ito ay
    /// [`f64::exp2`](../../std/primitive.f64.html#method.exp2)
    pub fn exp2f64(x: f64) -> f64;

    /// Ibinabalik ang natural na logarithm ng isang `f32`.
    ///
    /// Ang nagpapatatag na bersyon ng intrinsic na ito ay
    /// [`f32::ln`](../../std/primitive.f32.html#method.ln)
    pub fn logf32(x: f32) -> f32;
    /// Ibinabalik ang natural na logarithm ng isang `f64`.
    ///
    /// Ang nagpapatatag na bersyon ng intrinsic na ito ay
    /// [`f64::ln`](../../std/primitive.f64.html#method.ln)
    pub fn logf64(x: f64) -> f64;

    /// Ibinabalik ang batayang 10 logarithm ng isang `f32`.
    ///
    /// Ang nagpapatatag na bersyon ng intrinsic na ito ay
    /// [`f32::log10`](../../std/primitive.f32.html#method.log10)
    pub fn log10f32(x: f32) -> f32;
    /// Ibinabalik ang batayang 10 logarithm ng isang `f64`.
    ///
    /// Ang nagpapatatag na bersyon ng intrinsic na ito ay
    /// [`f64::log10`](../../std/primitive.f64.html#method.log10)
    pub fn log10f64(x: f64) -> f64;

    /// Ibinabalik ang base 2 logarithm ng isang `f32`.
    ///
    /// Ang nagpapatatag na bersyon ng intrinsic na ito ay
    /// [`f32::log2`](../../std/primitive.f32.html#method.log2)
    pub fn log2f32(x: f32) -> f32;
    /// Ibinabalik ang batayang 2 logarithm ng isang `f64`.
    ///
    /// Ang nagpapatatag na bersyon ng intrinsic na ito ay
    /// [`f64::log2`](../../std/primitive.f64.html#method.log2)
    pub fn log2f64(x: f64) -> f64;

    /// Ibinabalik `a * b + c` para `f32` halaga.
    ///
    /// Ang nagpapatatag na bersyon ng intrinsic na ito ay
    /// [`f32::mul_add`](../../std/primitive.f32.html#method.mul_add)
    pub fn fmaf32(a: f32, b: f32, c: f32) -> f32;
    /// Ibinabalik ang `a * b + c` para sa mga halagang `f64`.
    ///
    /// Ang nagpapatatag na bersyon ng intrinsic na ito ay
    /// [`f64::mul_add`](../../std/primitive.f64.html#method.mul_add)
    pub fn fmaf64(a: f64, b: f64, c: f64) -> f64;

    /// Ibinabalik ang absolute value ng isang `f32`.
    ///
    /// Ang nagpapatatag na bersyon ng intrinsic na ito ay
    /// [`f32::abs`](../../std/primitive.f32.html#method.abs)
    pub fn fabsf32(x: f32) -> f32;
    /// Ibinabalik ang absolute value ng isang `f64`.
    ///
    /// Ang nagpapatatag na bersyon ng intrinsic na ito ay
    /// [`f64::abs`](../../std/primitive.f64.html#method.abs)
    pub fn fabsf64(x: f64) -> f64;

    /// Ibinabalik ang minimum sa dalawang halaga `f32`.
    ///
    /// Ang nagpapatatag na bersyon ng intrinsic na ito ay
    /// [`f32::min`]
    pub fn minnumf32(x: f32, y: f32) -> f32;
    /// Ibinabalik ang minimum sa dalawang halaga `f64`.
    ///
    /// Ang nagpapatatag na bersyon ng intrinsic na ito ay
    /// [`f64::min`]
    pub fn minnumf64(x: f64, y: f64) -> f64;
    /// Ibinabalik ang maximum na dalawang halaga ng `f32`.
    ///
    /// Ang nagpapatatag na bersyon ng intrinsic na ito ay
    /// [`f32::max`]
    pub fn maxnumf32(x: f32, y: f32) -> f32;
    /// Ibinabalik ang maximum ng dalawang mga halaga `f64`.
    ///
    /// Ang nagpapatatag na bersyon ng intrinsic na ito ay
    /// [`f64::max`]
    pub fn maxnumf64(x: f64, y: f64) -> f64;

    /// Kinokopya ang pag-sign mula `y` hanggang `x` para sa mga halagang `f32`.
    ///
    /// Ang nagpapatatag na bersyon ng intrinsic na ito ay
    /// [`f32::copysign`](../../std/primitive.f32.html#method.copysign)
    pub fn copysignf32(x: f32, y: f32) -> f32;
    /// Ang mga kopya ng pag-sign mula `y` na `x` para `f64` halaga.
    ///
    /// Ang nagpapatatag na bersyon ng intrinsic na ito ay
    /// [`f64::copysign`](../../std/primitive.f64.html#method.copysign)
    pub fn copysignf64(x: f64, y: f64) -> f64;

    /// Ibinabalik ang pinakamalaking integer mas mababa sa o katumbas sa isang `f32`.
    ///
    /// Ang nagpapatatag na bersyon ng intrinsic na ito ay
    /// [`f32::floor`](../../std/primitive.f32.html#method.floor)
    pub fn floorf32(x: f32) -> f32;
    /// Ibinabalik ang pinakamalaking integer mas mababa sa o katumbas sa isang `f64`.
    ///
    /// Ang nagpapatatag na bersyon ng intrinsic na ito ay
    /// [`f64::floor`](../../std/primitive.f64.html#method.floor)
    pub fn floorf64(x: f64) -> f64;

    /// Ibinabalik ang pinakamaliit na integer na mas malaki sa o katumbas ng isang `f32`.
    ///
    /// Ang nagpapatatag na bersyon ng intrinsic na ito ay
    /// [`f32::ceil`](../../std/primitive.f32.html#method.ceil)
    pub fn ceilf32(x: f32) -> f32;
    /// Ibinabalik ang pinakamaliit na mas malaki integer kaysa sa o katumbas sa isang `f64`.
    ///
    /// Ang nagpapatatag na bersyon ng intrinsic na ito ay
    /// [`f64::ceil`](../../std/primitive.f64.html#method.ceil)
    pub fn ceilf64(x: f64) -> f64;

    /// Ibinabalik ang integer bahagi ng isang `f32`.
    ///
    /// Ang nagpapatatag na bersyon ng intrinsic na ito ay
    /// [`f32::trunc`](../../std/primitive.f32.html#method.trunc)
    pub fn truncf32(x: f32) -> f32;
    /// Ibinabalik ang bahagi ng integer ng isang `f64`.
    ///
    /// Ang nagpapatatag na bersyon ng intrinsic na ito ay
    /// [`f64::trunc`](../../std/primitive.f64.html#method.trunc)
    pub fn truncf64(x: f64) -> f64;

    /// Ibinabalik ang pinakamalapit na integer sa isang `f32`.
    /// Maaaring itaas ang isang hindi eksaktong ekseptong lumulutang-point kung ang pagtatalo ay hindi isang integer.
    pub fn rintf32(x: f32) -> f32;
    /// Ibinabalik ang pinakamalapit na integer sa isang `f64`.
    /// Maaaring itaas ang isang hindi eksaktong ekseptong lumulutang-point kung ang pagtatalo ay hindi isang integer.
    pub fn rintf64(x: f64) -> f64;

    /// Ibinabalik ang pinakamalapit na integer sa isang `f32`.
    ///
    /// Ang intrinsic na ito ay walang isang matatag na katapat.
    pub fn nearbyintf32(x: f32) -> f32;
    /// Ibinabalik ang pinakamalapit na integer sa isang `f64`.
    ///
    /// Ang intrinsic na ito ay walang isang matatag na katapat.
    pub fn nearbyintf64(x: f64) -> f64;

    /// Ibinabalik ang pinakamalapit na integer sa isang `f32`.Round half-way kaso ang layo mula sa zero.
    ///
    /// Ang nagpapatatag na bersyon ng intrinsic na ito ay
    /// [`f32::round`](../../std/primitive.f32.html#method.round)
    pub fn roundf32(x: f32) -> f32;
    /// Ibinabalik ang pinakamalapit na integer sa isang `f64`.Mga bilog na kalahating-daan na mga kaso na malayo sa zero.
    ///
    /// Ang nagpapatatag na bersyon ng intrinsic na ito ay
    /// [`f64::round`](../../std/primitive.f64.html#method.round)
    pub fn roundf64(x: f64) -> f64;

    /// Float karagdagan na nagbibigay-daan pag-optimize batay sa algebraic mga patakaran.
    /// Maaaring ipalagay na ang mga input ay may hangganan.
    ///
    /// Ang intrinsic na ito ay walang isang matatag na katapat.
    pub fn fadd_fast<T: Copy>(a: T, b: T) -> T;

    /// Float pagbabawas na nagbibigay-daan sa mga pag-optimize batay sa mga patakaran ng algebraic.
    /// Maaaring ipalagay na ang mga input ay may hangganan.
    ///
    /// Ang intrinsic na ito ay walang isang matatag na katapat.
    pub fn fsub_fast<T: Copy>(a: T, b: T) -> T;

    /// Float multiplication na nagbibigay-daan sa mga pag-optimize batay sa mga patakaran ng algebraic.
    /// Maaaring ipalagay na ang mga input ay may hangganan.
    ///
    /// Ang intrinsic na ito ay walang isang matatag na katapat.
    pub fn fmul_fast<T: Copy>(a: T, b: T) -> T;

    /// Float division na nagbibigay-daan pag-optimize batay sa algebraic mga patakaran.
    /// Maaaring ipalagay na ang mga input ay may hangganan.
    ///
    /// Ang intrinsic na ito ay walang isang matatag na katapat.
    pub fn fdiv_fast<T: Copy>(a: T, b: T) -> T;

    /// Float natitira na nagpapahintulot sa pag-optimize batay sa algebraic mga patakaran.
    /// Maaaring ipalagay na ang mga input ay may hangganan.
    ///
    /// Ang intrinsic na ito ay walang isang matatag na katapat.
    pub fn frem_fast<T: Copy>(a: T, b: T) -> T;

    /// Convert sa ni LLVM fptoui/fptosi, na maaaring bumalik undef para sa mga halaga sa labas ng hanay
    /// (<https://github.com/rust-lang/rust/issues/10184>)
    ///
    /// Pinatatag bilang [`f32::to_int_unchecked`] at [`f64::to_int_unchecked`].
    pub fn float_to_int_unchecked<Float: Copy, Int: Copy>(value: Float) -> Int;

    /// Ibinabalik ang bilang ng mga bits set sa isang integer uri `T`
    ///
    /// Ang mga nagpapatatag na bersyon ng intrinsic na ito ay magagamit sa integer primitives sa pamamagitan ng `count_ones` na pamamaraan.
    /// Halimbawa,
    /// [`u32::count_ones`]
    #[rustc_const_stable(feature = "const_ctpop", since = "1.40.0")]
    pub fn ctpop<T: Copy>(x: T) -> T;

    /// Ibinabalik ang bilang ng mga nangungunang nakatakda bits (zeroes) sa isang uri ng integer `T`.
    ///
    /// Ang mga nagpapatatag na bersyon ng intrinsic na ito ay magagamit sa integer primitives sa pamamagitan ng `leading_zeros` na pamamaraan.
    /// Halimbawa,
    /// [`u32::leading_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 3);
    /// ```
    ///
    /// Isang `x` na may halaga `0` ay magbabalik sa bit lapad ng `T`.
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0u16;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 16);
    /// ```
    #[rustc_const_stable(feature = "const_ctlz", since = "1.40.0")]
    pub fn ctlz<T: Copy>(x: T) -> T;

    /// Tulad `ctlz`, ngunit dagdag-hindi ligtas dahil ito ay nagbabalik `undef` kapag naibigay na ng `x` na may halaga `0`.
    ///
    ///
    /// Ang intrinsic na ito ay walang isang matatag na katapat.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz_nonzero;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = unsafe { ctlz_nonzero(x) };
    /// assert_eq!(num_leading, 3);
    /// ```
    #[rustc_const_stable(feature = "constctlz", since = "1.50.0")]
    pub fn ctlz_nonzero<T: Copy>(x: T) -> T;

    /// Ibinabalik ang bilang ng mga trailing hindi nakatakda bits (zeroes) sa isang uri ng integer `T`.
    ///
    /// Ang nagpapatatag bersyon ng intrinsic na ito ay magagamit sa primitives integer sa pamamagitan ng `trailing_zeros` paraan.
    /// Halimbawa,
    /// [`u32::trailing_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 3);
    /// ```
    ///
    /// Ang isang `x` na may halagang `0` ay magbabalik ng kaunting lapad ng `T`:
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0u16;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 16);
    /// ```
    #[rustc_const_stable(feature = "const_cttz", since = "1.40.0")]
    pub fn cttz<T: Copy>(x: T) -> T;

    /// Tulad `cttz`, ngunit dagdag-hindi ligtas dahil ito ay nagbabalik `undef` kapag naibigay na ng `x` na may halaga `0`.
    ///
    ///
    /// Ang intrinsic na ito ay walang isang matatag na katapat.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz_nonzero;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = unsafe { cttz_nonzero(x) };
    /// assert_eq!(num_trailing, 3);
    /// ```
    #[rustc_const_unstable(feature = "const_cttz", issue = "none")]
    pub fn cttz_nonzero<T: Copy>(x: T) -> T;

    /// Baliktarin ang mga byte sa isang integer na uri `T`.
    ///
    /// Ang mga nagpapatatag na bersyon ng intrinsic na ito ay magagamit sa integer primitives sa pamamagitan ng `swap_bytes` na pamamaraan.
    /// Halimbawa,
    /// [`u32::swap_bytes`]
    #[rustc_const_stable(feature = "const_bswap", since = "1.40.0")]
    pub fn bswap<T: Copy>(x: T) -> T;

    /// Reverses ang mga bits sa isang uri ng integer `T`.
    ///
    /// Ang mga nagpapatatag na bersyon ng intrinsic na ito ay magagamit sa integer primitives sa pamamagitan ng `reverse_bits` na pamamaraan.
    /// Halimbawa,
    /// [`u32::reverse_bits`]
    #[rustc_const_stable(feature = "const_bitreverse", since = "1.40.0")]
    pub fn bitreverse<T: Copy>(x: T) -> T;

    /// Nagsasagawa ng naka-check na pagdaragdag ng integer.
    ///
    /// Ang nagpapatatag bersyon ng intrinsic na ito ay magagamit sa primitives integer sa pamamagitan ng `overflowing_add` paraan.
    /// Halimbawa,
    /// [`u32::overflowing_add`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn add_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Nagsasagawa check integer subtraction
    ///
    /// Ang mga nagpapatatag na bersyon ng intrinsic na ito ay magagamit sa integer primitives sa pamamagitan ng `overflowing_sub` na pamamaraan.
    /// Halimbawa,
    /// [`u32::overflowing_sub`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn sub_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Nagsasagawa check integer multiplikasyon
    ///
    /// Ang mga nagpapatatag na bersyon ng intrinsic na ito ay magagamit sa integer primitives sa pamamagitan ng `overflowing_mul` na pamamaraan.
    /// Halimbawa,
    /// [`u32::overflowing_mul`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn mul_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Nagsasagawa ng isang eksaktong division, na nagreresulta sa hindi natukoy na pag-uugali na kung saan ang `x % y != 0` o `y == 0` o `x == T::MIN && y == -1`
    ///
    ///
    /// Ang intrinsic na ito ay walang isang matatag na katapat.
    pub fn exact_div<T: Copy>(x: T, y: T) -> T;

    /// Nagsasagawa ng isang hindi nasuri na paghahati, na nagreresulta sa hindi natukoy na pag-uugali kung saan `y == 0` o `x == T::MIN && y == -1`
    ///
    ///
    /// Ang mga ligtas na pambalot para sa intrinsic na ito ay magagamit sa integer primitives sa pamamagitan ng `checked_div` na pamamaraan.
    /// Halimbawa,
    /// [`u32::checked_div`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_div<T: Copy>(x: T, y: T) -> T;
    /// Ibinabalik ang natitira sa isang hindi nasuri na dibisyon, na nagreresulta sa hindi natukoy na pag-uugali kapag `y == 0` o `x == T::MIN && y == -1`
    ///
    ///
    /// Ang mga ligtas na pambalot para sa intrinsic na ito ay magagamit sa integer primitives sa pamamagitan ng pamamaraang `checked_rem`.
    /// Halimbawa,
    /// [`u32::checked_rem`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_rem<T: Copy>(x: T, y: T) -> T;

    /// Nagsasagawa ng isang hindi naka-check na kaliwang paglilipat, na nagreresulta sa hindi natukoy na pag-uugali kapag `y < 0` o `y >= N`, kung saan ang N ay ang lapad ng T sa mga piraso.
    ///
    ///
    /// Safe wrappers para intrinsic na ito ay magagamit sa primitives integer sa pamamagitan ng `checked_shl` paraan.
    /// Halimbawa,
    /// [`u32::checked_shl`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shl<T: Copy>(x: T, y: T) -> T;
    /// Nagsasagawa na ng walang check right shift, na nagreresulta sa hindi natukoy na pag-uugali kapag `y < 0` o `y >= N`, kung saan N ay ang lapad ng T sa bits.
    ///
    ///
    /// Ang mga ligtas na pambalot para sa intrinsic na ito ay magagamit sa integer primitives sa pamamagitan ng `checked_shr` na pamamaraan.
    /// Halimbawa,
    /// [`u32::checked_shr`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shr<T: Copy>(x: T, y: T) -> T;

    /// Ibinabalik ang resulta ng isang walang check na karagdagan, na nagreresulta sa hindi natukoy na pag-uugali kapag `x + y > T::MAX` o `x + y < T::MIN`.
    ///
    ///
    /// Ang intrinsic na ito ay walang isang matatag na katapat.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_add<T: Copy>(x: T, y: T) -> T;

    /// Ibinabalik ang resulta ng isang hindi napirming pagbabawas, na nagreresulta sa hindi natukoy na pag-uugali kapag `x - y > T::MAX` o `x - y < T::MIN`.
    ///
    ///
    /// Ang intrinsic na ito ay walang isang matatag na katapat.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_sub<T: Copy>(x: T, y: T) -> T;

    /// Ibinabalik ang resulta ng isang walang check multiplication, na nagreresulta sa hindi natukoy na pag-uugali kapag `x *y > T::MAX` o `x* y < T::MIN`.
    ///
    ///
    /// Ang intrinsic na ito ay walang isang matatag na katapat.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_mul<T: Copy>(x: T, y: T) -> T;

    /// Nagsasagawa pihitin sa kaliwa.
    ///
    /// Ang mga nagpapatatag na bersyon ng intrinsic na ito ay magagamit sa integer primitives sa pamamagitan ng `rotate_left` na pamamaraan.
    /// Halimbawa,
    /// [`u32::rotate_left`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_left<T: Copy>(x: T, y: T) -> T;

    /// Gumaganap i-rotate pakanan.
    ///
    /// Ang mga nagpapatatag na bersyon ng intrinsic na ito ay magagamit sa integer primitives sa pamamagitan ng `rotate_right` na pamamaraan.
    /// Halimbawa,
    /// [`u32::rotate_right`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_right<T: Copy>(x: T, y: T) -> T;

    /// Ibinabalik (a + b) mod 2 <sup>N,</sup> kung saan N ay ang lapad ng T sa bits.
    ///
    /// Ang nagpapatatag bersyon ng intrinsic na ito ay magagamit sa primitives integer sa pamamagitan ng `wrapping_add` paraan.
    /// Halimbawa,
    /// [`u32::wrapping_add`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_add<T: Copy>(a: T, b: T) -> T;
    /// Ibinabalik (a, b) mga mod 2 <sup>N,</sup> kung saan N ay ang lapad ng T sa bits.
    ///
    /// Ang nagpapatatag bersyon ng intrinsic na ito ay magagamit sa primitives integer sa pamamagitan ng `wrapping_sub` paraan.
    /// Halimbawa,
    /// [`u32::wrapping_sub`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_sub<T: Copy>(a: T, b: T) -> T;
    /// Ibinabalik (a * b) mod 2 <sup>N,</sup> kung saan N ay ang lapad ng T sa bits.
    ///
    /// Ang mga nagpapatatag na bersyon ng intrinsic na ito ay magagamit sa integer primitives sa pamamagitan ng `wrapping_mul` na pamamaraan.
    /// Halimbawa,
    /// [`u32::wrapping_mul`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_mul<T: Copy>(a: T, b: T) -> T;

    /// Kinakalkula ang `a + b`, nakabubusog sa mga hangganan ng bilang.
    ///
    /// Ang nagpapatatag bersyon ng intrinsic na ito ay magagamit sa primitives integer sa pamamagitan ng `saturating_add` paraan.
    /// Halimbawa,
    /// [`u32::saturating_add`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_add<T: Copy>(a: T, b: T) -> T;
    /// Kinakalkula ang `a - b`, nakabubusog sa mga hangganan ng bilang.
    ///
    /// Ang mga nagpapatatag na bersyon ng intrinsic na ito ay magagamit sa integer primitives sa pamamagitan ng `saturating_sub` na pamamaraan.
    /// Halimbawa,
    /// [`u32::saturating_sub`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_sub<T: Copy>(a: T, b: T) -> T;

    /// Ibinabalik ang halaga ng discriminant para sa mga variant sa 'v';
    /// kung ang `T` ay walang diskriminasyon, ibabalik ang `0`.
    ///
    /// Ang nagpapatatag na bersyon ng intrinsic na ito ay [`core::mem::discriminant`](crate::mem::discriminant).
    #[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
    pub fn discriminant_value<T>(v: &T) -> <T as DiscriminantKind>::Discriminant;

    /// Ibinabalik ang bilang ng mga variant ng uri `T` cast sa isang `usize`;
    /// kung `T` Wala pang variant, nagbabalik `0`.Ang mga variant na hindi naninirahan ay mabibilang.
    ///
    /// Ang to-be-stabilized na bersyon ng intrinsic na ito ay [`mem::variant_count`].
    #[rustc_const_unstable(feature = "variant_count", issue = "73662")]
    pub fn variant_count<T>() -> usize;

    /// "try catch" tayuan ni Rust na invokes ang function pointer `try_fn` na may data pointer `data`.
    ///
    /// Ang ikatlong argumento ay isang function na tinatawag na kung ang isang panic nangyayari.
    /// Ang function na ito ay tumatagal ang data pointer at isang pointer sa target na tukoy exception bagay na iyon ay nakuha.
    ///
    /// Para sa karagdagang impormasyon tingnan ang source ang compiler pati na rin ang catch pagpapatupad ni std.
    ///
    pub fn r#try(try_fn: fn(*mut u8), data: *mut u8, catch_fn: fn(*mut u8, *mut u8)) -> i32;

    /// Emits isang tindahan `!nontemporal` ayon sa LLVM (makita ang kanilang mga docs).
    /// Marahil ay hindi magiging matatag.
    pub fn nontemporal_store<T>(ptr: *mut T, val: T);

    /// Tingnan ang dokumentasyon ng `<*const T>::offset_from` para sa mga detalye.
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    pub fn ptr_offset_from<T>(ptr: *const T, base: *const T) -> isize;

    /// Tingnan ang dokumentasyon ng `<*const T>::guaranteed_eq` para sa mga detalye.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_eq<T>(ptr: *const T, other: *const T) -> bool;

    /// Tingnan ang dokumentasyon ng `<*const T>::guaranteed_ne` para sa mga detalye.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_ne<T>(ptr: *const T, other: *const T) -> bool;

    /// Maglaan sa oras ng pag-ipon.Hindi dapat tawagan sa runtime.
    #[rustc_const_unstable(feature = "const_heap", issue = "79597")]
    pub fn const_allocate(size: usize, align: usize) -> *mut u8;
}

// Ang ilang mga pag-andar ay tinukoy dito dahil hindi sinasadya nilang magamit sa modyul na ito sa matatag.
// Tingnan ang <https://github.com/rust-lang/rust/issues/15702>.
// (Ang `transmute` ay nahuhulog din sa kategoryang ito, ngunit hindi ito maaaring balutin dahil sa tseke na ang `T` at `U` ay may parehong laki.)
//

/// Sinusuri kung ang `ptr` ay maayos na nakahanay na nauugnay sa `align_of::<T>()`.
///
pub(crate) fn is_aligned_and_not_null<T>(ptr: *const T) -> bool {
    !ptr.is_null() && ptr as usize % mem::align_of::<T>() == 0
}

/// Kinokopya ang `count *size_of::<T>()` bytes mula `src` hanggang `dst`.Ang mapagkukunan at patutunguhan ay dapat* hindi * nagsasapawan.
///
/// Para sa mga rehiyon ng memory na maaaring overlap, gamitin [`copy`] sa halip.
///
/// `copy_nonoverlapping` ay semantically katumbas ng C's [`memcpy`], ngunit may palitan ang order ng argument.
///
/// [`memcpy`]: https://en.cppreference.com/w/c/string/byte/memcpy
///
/// # Safety
///
/// Pag-uugali ay hindi maliwanag kung ang alinman sa mga sumusunod na kondisyon ay nilabag:
///
/// * `src` dapat [valid] para sa mga nagbasa ng `count * size_of::<T>()` bytes.
///
/// * `dst` Dapat na [valid] para writes ng `count * size_of::<T>()` bytes.
///
/// * Parehong `src` at `dst` ay dapat na maayos na hile-hilera.
///
/// * Ang rehiyon ng memorya na nagsisimula sa `src` na may sukat na `count *
///   sukat ng: :<T>() `bytes dapat *hindi* nagsasapawan sa rehiyon ng memorya simula sa `dst` na may parehong laki.
///
/// Tulad ng [`read`], ang `copy_nonoverlapping` ay lumilikha ng isang maliit na kopya ng `T`, hindi alintana kung ang `T` ay [`Copy`].
/// Kung ang `T` ay hindi [`Copy`], gamit ang *pareho* ang mga halaga sa rehiyon na nagsisimula sa `*src` at ang rehiyon na nagsisimula sa `* dst` ay maaaring [violate memory safety][read-ownership].
///
///
/// Tandaan na kahit na ang mabisang kinopyang laki (`count * size_of: :<T>Ang ()`) ay `0`, ang mga pahiwatig ay dapat na hindi NUL at maayos na nakahanay.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Mano-manong ipatupad ang [`Vec::append`]:
///
/// ```
/// use std::ptr;
///
/// /// Inililipat ang lahat ng mga elemento ng `src` sa `dst`, iniiwan ang `src` na walang laman.
/// fn append<T>(dst: &mut Vec<T>, src: &mut Vec<T>) {
///     let src_len = src.len();
///     let dst_len = dst.len();
///
///     // Tiyaking ang `dst` ay may sapat na kapasidad upang hawakan ang lahat ng `src`.
///     dst.reserve(src_len);
///
///     unsafe {
///         // Ang tawag sa offset ay palaging ligtas dahil ang `Vec` ay hindi kailanman maglalaan ng higit sa `isize::MAX` bytes.
/////
///         let dst_ptr = dst.as_mut_ptr().offset(dst_len as isize);
///         let src_ptr = src.as_ptr();
///
///         // Truncate `src` nang hindi bumababa ang mga nilalaman nito.
///         // Ginagawa muna namin ito, upang maiwasan ang mga problema sakaling may mas malayo sa panics.
///         src.set_len(0);
///
///         // Ang dalawang rehiyon ay hindi maaaring overlap dahil mutable mga sanggunian ay hindi alias, at dalawang magkaibang vectors ay hindi maaaring pag-aari ang parehong memory.
/////
/////
///         ptr::copy_nonoverlapping(src_ptr, dst_ptr, src_len);
///
///         // Abisuhan ang `dst` na hawak nito ngayon ang mga nilalaman ng `src`.
///         dst.set_len(dst_len + src_len);
///     }
/// }
///
/// let mut a = vec!['r'];
/// let mut b = vec!['u', 's', 't'];
///
/// append(&mut a, &mut b);
///
/// assert_eq!(a, &['r', 'u', 's', 't']);
/// assert!(b.is_empty());
/// ```
///
/// [`Vec::append`]: ../../std/vec/struct.Vec.html#method.append
///
///
///
///
///
#[doc(alias = "memcpy")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: Magsagawa ng mga tseke lamang sa tumakbo ng oras
    /*if cfg!(debug_assertions)
        && !(is_aligned_and_not_null(src)
            && is_aligned_and_not_null(dst)
            && is_nonoverlapping(src, dst, count))
    {
        // Hindi panic upang mapanatili ang maliit na epekto ng codegen.
        abort();
    }*/

    // KALIGTASAN: ang kaligtasan kontrata para `copy_nonoverlapping` ay dapat na
    // tinaguyod ng tumatawag.
    unsafe { copy_nonoverlapping(src, dst, count) }
}

/// Mga kopya `count * size_of::<T>()` bytes mula `src` na `dst`.Ang source at destination ay maaaring nagsasapawan.
///
/// Kung ang mapagkukunan at patutunguhan ay hindi * magsasapawan, maaaring gamitin ang [`copy_nonoverlapping`] sa halip.
///
/// `copy` ay semantically katumbas ng C's [`memmove`], ngunit may palitan ang order ng argument.
/// Ang pagkopya ay nagaganap na parang ang mga byte ay nakopya mula `src` sa isang pansamantalang array at pagkatapos ay nakopya mula sa array hanggang `dst`.
///
/// [`memmove`]: https://en.cppreference.com/w/c/string/byte/memmove
///
/// # Safety
///
/// Pag-uugali ay hindi maliwanag kung ang alinman sa mga sumusunod na kondisyon ay nilabag:
///
/// * `src` dapat [valid] para sa mga nagbasa ng `count * size_of::<T>()` bytes.
///
/// * `dst` Dapat na [valid] para writes ng `count * size_of::<T>()` bytes.
///
/// * Parehong `src` at `dst` ay dapat na maayos na hile-hilera.
///
/// Tulad [`read`], `copy` ay lumilikha ng isang bitwise kopya ng `T`, hindi alintana kung `T` ay [`Copy`].
/// Kung ang `T` ay hindi [`Copy`], ginagamit ang parehong mga halaga sa rehiyon simula sa `*src` at ang rehiyon na nagsisimula sa `* dst` ay maaaring [violate memory safety][read-ownership].
///
///
/// Tandaan na kahit na ang mabisang kinopyang laki (`count * size_of: :<T>Ang ()`) ay `0`, ang mga pahiwatig ay dapat na hindi NUL at maayos na nakahanay.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Mahusay na lumikha ng isang Rust vector mula sa isang hindi ligtas na buffer:
///
/// ```
/// use std::ptr;
///
/// /// # Safety
//////
/// /// * `ptr` dapat na maayos na nakahanay para sa uri nito at hindi-zero.
/// /// * `ptr` dapat na wasto para sa mga nagbasa ng `elts` na magkadugtong na mga elemento ng uri `T`.
/// /// * Yaong mga elemento ay hindi dapat gamitin pagkatapos ng pagtawag sa function na ito maliban kung `T: Copy`.
/// # #[allow(dead_code)]
/// unsafe fn from_buf_raw<T>(ptr: *const T, elts: usize) -> Vec<T> {
///     let mut dst = Vec::with_capacity(elts);
///
///     // KALIGTASAN: Ang aming precondition ay nagsisiguro na ang mapagkukunan ay nakahanay at wasto,
///     // at `Vec::with_capacity` ay nagsisigurado na kami ay may kapaki-pakinabang na espasyo upang isulat ang mga ito.
///     ptr::copy(ptr, dst.as_mut_ptr(), elts);
///
///     // KALIGTASAN: Nilikha namin ito ng may ganitong kapasidad nang mas maaga,
///     // at ang nakaraang `copy` ay nasimulan ang mga elementong ito.
///     dst.set_len(elts);
///     dst
/// }
/// ```
///
///
///
///
///
#[doc(alias = "memmove")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: Magsagawa ng mga tseke lamang sa tumakbo ng oras
    /*if cfg!(debug_assertions) && !(is_aligned_and_not_null(src) && is_aligned_and_not_null(dst)) {
        // Hindi panic upang mapanatili ang maliit na epekto ng codegen.
        abort();
    }*/

    // KALIGTASAN: ang kaligtasan kontrata para `copy` dapat na upheld sa pamamagitan ng tumatawag.
    unsafe { copy(src, dst, count) }
}

/// Nagtatakda ng `count * size_of::<T>()` bytes ng memorya na nagsisimula sa `dst` hanggang `val`.
///
/// `write_bytes` ay katulad ng C's [`memset`], ngunit nagtatakda ng `count * size_of::<T>()` bytes sa `val`.
///
/// [`memset`]: https://en.cppreference.com/w/c/string/byte/memset
///
/// # Safety
///
/// Pag-uugali ay hindi maliwanag kung ang alinman sa mga sumusunod na kondisyon ay nilabag:
///
/// * `dst` Dapat na [valid] para writes ng `count * size_of::<T>()` bytes.
///
/// * `dst` ay dapat na maayos na hile-hilera.
///
/// Bukod pa rito, ang tumatawag ay dapat matiyak na ang pagsusulat `count * size_of::<T>()` bytes sa nabanggit na rehiyon ng mga resulta ng memory sa isang wastong halaga ng `T`.
/// Ang paggamit ng isang rehiyon ng memorya na nai-type bilang isang `T` na naglalaman ng isang hindi wastong halaga ng `T` ay hindi natukoy na pag-uugali.
///
/// Tandaan na kahit na ang epektibong kinopya laki (`count * size_of: :<T>Ang ()`) ay `0`, ang pointer ay dapat na non-NULL at maayos na nakahanay.
///
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Pangunahing paggamit:
///
/// ```
/// use std::ptr;
///
/// let mut vec = vec![0u32; 4];
/// unsafe {
///     let vec_ptr = vec.as_mut_ptr();
///     ptr::write_bytes(vec_ptr, 0xfe, 2);
/// }
/// assert_eq!(vec, [0xfefefefe, 0xfefefefe, 0, 0]);
/// ```
///
/// Lumilikha ng isang hindi wastong halaga:
///
/// ```
/// use std::ptr;
///
/// let mut v = Box::new(0i32);
///
/// unsafe {
///     // Leaks dati gaganapin halaga sa pamamagitan ng overwriting ang `Box<T>` na may isang null pointer.
/////
///     ptr::write_bytes(&mut v as *mut Box<i32>, 0, 1);
/// }
///
/// // Sa puntong ito, ang paggamit o pag-drop `v` resulta sa hindi natukoy na pag-uugali.
/// // drop(v); // ERROR
///
/// // Kahit na ang pagtagas ng `v` "uses" ito, at samakatuwid ay hindi natukoy na pag-uugali.
/// // mem::forget(v); // ERROR
///
/// // Sa katunayan, `v` ay hindi wasto ayon sa pangunahing uri layout invariants, kaya *anumang* operasyon hawakan ito ay hindi natukoy na pag-uugali.
/////
/// // hayaan ang v2 =v;//ERROR
///
/// unsafe {
///     // Sa halip ay maglagay tayo ng wastong halaga
///     ptr::write(&mut v as *mut Box<i32>, Box::new(42i32));
/// }
///
/// // Ngayon ay maayos na ang kahon
/// assert_eq!(*v, 42);
/// ```
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[inline]
pub unsafe fn write_bytes<T>(dst: *mut T, val: u8, count: usize) {
    extern "rust-intrinsic" {
        fn write_bytes<T>(dst: *mut T, val: u8, count: usize);
    }

    debug_assert!(is_aligned_and_not_null(dst), "attempt to write to unaligned or null pointer");

    // KALIGTASAN: ang kaligtasan kontrata para `write_bytes` dapat na upheld sa pamamagitan ng tumatawag.
    unsafe { write_bytes(dst, val, count) }
}