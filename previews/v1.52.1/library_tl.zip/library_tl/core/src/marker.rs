//! Primitive traits at mga uri na kumakatawan sa mga pangunahing katangian ng mga uri.
//!
//! Ang mga uri ng Rust ay maaaring maiuri sa iba't ibang mga kapaki-pakinabang na paraan ayon sa kanilang mga likas na katangian.
//! Mga klasipikasyon na ito ay kinakatawan bilang traits.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cell::UnsafeCell;
use crate::cmp;
use crate::fmt::Debug;
use crate::hash::Hash;
use crate::hash::Hasher;

/// Mga uri na maaaring mailipat sa mga hangganan ng thread.
///
/// trait na ito ay awtomatikong ipinatupad kapag tumutukoy sa compiler ito ay naaangkop.
///
/// Ang isang halimbawa ng isang di-`Send` uri ay ang sanggunian-pagbibilang ng pointer [`rc::Rc`][`Rc`].
/// Kung dalawa thread tangkaing clone [`Rc`] s na tumuturo sa parehong reference-mabilang na halaga, maaari silang i-update ang reference count sa parehong oras, kung saan ay [undefined behavior][ub] dahil [`Rc`] ay hindi gumagamit ng atomic operasyon.
///
/// Nito pinsan [`sync::Arc`][arc] ang ginagamit ng atomic operasyon (incurring ilang overhead) at sa gayon ay `Send`.
///
/// Tingnan [the Nomicon](../../nomicon/send-and-sync.html) para sa karagdagang detalye.
///
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "send_trait")]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be sent between threads safely",
    label = "`{Self}` cannot be sent between threads safely"
)]
pub unsafe auto trait Send {
    // empty.
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *mut T {}

/// Mga uri na may pare-pareho ang laki na kilala sa oras ng pagtitipon.
///
/// Ang lahat ng mga parameter ng uri ay may isang implicit na nakatali ng `Sized`.Maaaring magamit ang espesyal na syntax `?Sized` upang alisin ang nakagapos na ito kung hindi ito naaangkop.
///
/// ```
/// # #![allow(dead_code)]
/// struct Foo<T>(T);
/// struct Bar<T: ?Sized>(T);
///
/// // struct FooUse(Foo<[i32]>);//error: Hindi ipinatupad ang laki para sa [i32]
/// struct BarUse(Bar<[i32]>); // OK
/// ```
///
/// Ang isang pagbubukod ay ang implicit `Self` uri ng isang trait.
/// A trait ay walang implicit `Sized` nakagapos bilang na ito ay hindi tugma sa [trait object] s kung saan, sa pamamagitan ng kahulugan, ang trait ay kailangang gawa sa lahat ng posibleng mga implementors, at sa gayon ay maaaring maging anumang laki.
///
///
/// Kahit Rust hahayaan kang panagutin `Sized` sa isang trait, hindi mo magagawang gamitin ito upang bumuo ng isang trait object sa ibang pagkakataon:
///
/// ```
/// # #![allow(unused_variables)]
/// trait Foo { }
/// trait Bar: Sized { }
///
/// struct Impl;
/// impl Foo for Impl { }
/// impl Bar for Impl { }
///
/// let x: &dyn Foo = &Impl;    // OK
/// // hayaan y: &dyn Bar= &Impl;//error: ang trait `Bar` ay hindi maaaring ginawa sa isang bagay
/////
/// ```
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "sized"]
#[rustc_on_unimplemented(
    message = "the size for values of type `{Self}` cannot be known at compilation time",
    label = "doesn't have a size known at compile-time"
)]
#[fundamental] // para Default, halimbawa, na kung saan ay nangangailangan na `[T]: !Default` maging evaluatable
#[rustc_specialization_trait]
pub trait Sized {
    // Empty.
}

/// Uri na maaaring maging "unsized" sa isang magilas na kasing-laki ng uri.
///
/// Halimbawa, ang laki ng uri ng array na `[i8; 2]` ay nagpapatupad ng `Unsize<[i8]>` at `Unsize<dyn fmt::Debug>`.
///
/// Ang lahat ng mga pagpapatupad ng `Unsize` ay awtomatikong ibinigay sa pamamagitan ng compiler.
///
/// `Unsize` ay ipinatupad para sa:
///
/// - `[T; N]` ay `Unsize<[T]>`
/// - `T` ay `Unsize<dyn Trait>` kapag `T: Trait`
/// - `Foo<..., T, ...>` ay `Unsize<Foo<..., U, ...>>` kung:
///   - `T: Unsize<U>`
///   - Foo ay isang struct
///   - Tanging ang huling field ng `Foo` ay isang uri kinasasangkutan `T`
///   - `T` ay hindi bahagi ng ang uri ng anumang iba pang mga patlang
///   - `Bar<T>: Unsize<Bar<U>>`, kung ang huling field ng `Foo` ay i-type ang `Bar<T>`
///
/// `Unsize` ay ginagamit kasama ang [`ops::CoerceUnsized`] upang payagan "user-defined" lalagyan tulad ng [`Rc`] na naglalaman ng mga dynamic na kasing-laki ng mga uri.
/// Tingnan ang [DST coercion RFC][RFC982] at [the nomicon entry on coercion][nomicon-coerce] para sa karagdagang detalye.
///
/// [`ops::CoerceUnsized`]: crate::ops::CoerceUnsized
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [RFC982]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
#[unstable(feature = "unsize", issue = "27732")]
#[lang = "unsize"]
pub trait Unsize<T: ?Sized> {
    // Empty.
}

/// Mga kinakailangang trait para constants ginagamit sa pattern matches.
///
/// Ang anumang uri na derives `PartialEq` awtomatikong ipinapatupad ito trait,*hindi alintana* ng kung kanyang uri-parameter ipatupad `Eq`.
///
/// Kung ang isang item na `const` ay naglalaman ng ilang uri na hindi ipinatupad ang trait na ito, kung gayon ang uri na alinman sa (1.) ay hindi nagpapatupad ng `PartialEq` (na nangangahulugang ang pare-pareho ay hindi magbibigay ng pamamaraang paghahambing, kung aling mga henerasyon ng code ang ipinapalagay na magagamit), o (2.) ipinapatupad nito *sarili nito* bersyon ng `PartialEq` (na ipinapalagay namin ay hindi sumasangayon sa isang structural-pantay ng paghahambing).
///
///
/// Sa alinman sa dalawang mga sitwasyon sa itaas, tinanggihan namin ang paggamit ng isang pare-pareho sa isang pattern na tugma.
///
/// Tingnan din ang [structural match RFC][RFC1445], at [issue 63438] na motivated migrating mula sa attribute-based na disenyo upang ito trait.
///
/// [RFC1445]: https://github.com/rust-lang/rfcs/blob/master/text/1445-restrict-constants-in-patterns.md
/// [issue 63438]: https://github.com/rust-lang/rust/issues/63438
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(PartialEq)]`")]
#[lang = "structural_peq"]
pub trait StructuralPartialEq {
    // Empty.
}

/// Mga kinakailangang trait para constants ginagamit sa pattern matches.
///
/// Ang anumang uri na derives `Eq` awtomatikong ipinapatupad ito trait,*hindi alintana* kung i-type ang mga parameter nito ipatupad `Eq`.
///
/// Ito ay isang hack na magtrabaho sa paligid ng isang limitasyon sa ating uri ng sistema.
///
/// # Background
///
/// Gusto naming mangangailangan na ang mga uri ng consts ginagamit sa pattern matches ay may attribute `#[derive(PartialEq, Eq)]`.
///
/// Sa isang mas mainam na mundo, maaari naming suriin na kinakailangan sa pamamagitan lamang ng paglagay ng tsek na ang naibigay na uri nagpapatupad parehong `StructuralPartialEq` trait *at* ang `Eq` trait.
/// Gayunpaman, maaari kang magkaroon ADTs na *gawin*`derive(PartialEq, Eq)`, at maging isang kaso na gusto namin ang compiler upang tanggapin, at gayon pa man i-type ang hindi nagbabagong ni nabigong ipatupad `Eq`.
///
/// Ang nangabanggit ay isang kaso tulad nito:
///
/// ```rust
/// #[derive(PartialEq, Eq)]
/// struct Wrap<X>(X);
///
/// fn higher_order(_: &()) { }
///
/// const CFN: Wrap<fn(&())> = Wrap(higher_order);
///
/// fn main() {
///     match CFN {
///         CFN => {}
///         _ => {}
///     }
/// }
/// ```
///
/// (Ang problema sa ang code sa itaas ay na `Wrap<fn(&())>` ay hindi ipatupad `PartialEq`, ni `Eq`, dahil `para sa < 'a> fn(&'a _)` does not implement those traits.)
///
/// Samakatuwid, hindi namin maaaring umasa sa walang muwang tseke para `StructuralPartialEq` at galos lamang `Eq`.
///
/// Bilang isang hack sa trabaho sa paligid ng ito, gumagamit kami ng dalawang magkahiwalay na traits injected sa pamamagitan ng bawat isa sa mga dalawang derives (`#[derive(PartialEq)]` at `#[derive(Eq)]`) at check na ang parehong sa kanila ay naroroon bilang bahagi ng istruktura-match checking.
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(Eq)]`")]
#[lang = "structural_teq"]
pub trait StructuralEq {
    // Empty.
}

/// Uri na ang mga halaga ay maaaring Nadoble sa pamamagitan lamang ng pagkopya ng bits.
///
/// Bilang default, ang mga variable na binding ay may 'ilipat ang mga semantika.'Sa ibang salita:
///
/// ```
/// #[derive(Debug)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `x` ay lumipat sa `y`, at sa gayon ay hindi maaaring gamitin
///
/// // println ("{: ?}", x);//error: paggamit ng inilipat halaga
/// ```
///
/// Gayunman, kung ang isang i-type ang mga nagpapatupad `Copy`, ito sa halip ay 'kopyahin semantics':
///
/// ```
/// // Maaari naming kunin sa isang `Copy` pagpapatupad.
/// // `Clone` ay kinakailangan din, tulad ng ito ay isang supertrait ng `Copy`.
/// #[derive(Debug, Copy, Clone)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `y` ay isang kopya ng `x`
///
/// println!("{:?}", x); // A-OK!
/// ```
///
/// Mahalagang tandaan na sa dalawang halimbawang ito, ang pagkakaiba lamang ay kung pinapayagan kang mag-access sa `x` pagkatapos ng takdang-aralin.
/// Sa ilalim ng hood, parehong ang isang kopya at isang paglipat ay maaaring magresulta sa bits na makopya sa memorya, kahit na ito ay paminsan-minsan na-optimize ang layo.
///
/// ## Paano ko ipatupad `Copy`?
///
/// Mayroong dalawang mga paraan upang ipatupad `Copy` sa iyong uri.pinakasimpleng ay upang gamitin `derive`:
///
/// ```
/// #[derive(Copy, Clone)]
/// struct MyStruct;
/// ```
///
/// Maaari mo ring ipatupad nang manu-mano ang `Copy` at `Clone`:
///
/// ```
/// struct MyStruct;
///
/// impl Copy for MyStruct { }
///
/// impl Clone for MyStruct {
///     fn clone(&self) -> MyStruct {
///         *self
///     }
/// }
/// ```
///
/// Mayroong isang maliit na pagkakaiba sa pagitan ng dalawa: ang diskarte ng `derive` ay maglalagay din ng isang `Copy` na nakasalalay sa mga parameter ng uri, na hindi palaging nais.
///
/// ## Ano ang pagkakaiba sa pagitan ng `Copy` at `Clone`?
///
/// Mga kopya mangyayari kataon lamang, halimbawa bilang bahagi ng isang assignment `y = x`.Ang pag-uugali ng `Copy` ay hindi labis na karga;palaging ito ay isang simpleng kopya na medyo matalino.
///
/// Ang cloning ay isang tahasang aksyon, `x.clone()`.Ang pagpapatupad ng [`Clone`] ay maaaring magbigay ng anumang pag-uugali na partikular sa uri na kinakailangan upang mai-duplicate ang mga halaga nang ligtas.
/// Halimbawa, ang pagpapatupad ng [`Clone`] para [`String`] kailangang kopyahin ang tulis-to string buffer sa magbunton.
/// Ang isang simpleng bitwise na kopya ng mga halagang [`String`] ay kopyahin lamang ang pointer, na humahantong sa isang doble na pababa sa linya.
/// Para sa kadahilanang ito, [`String`] ay [`Clone`] ngunit hindi `Copy`.
///
/// [`Clone`] ay isang supertrait ng `Copy`, kaya ang lahat ng bagay na kung saan ay `Copy` ay dapat ding ipatupad [`Clone`].
/// Kung ang isang uri ay `Copy` pagkatapos nito [`Clone`] pagpapatupad lamang ang mga pangangailangan upang bumalik `*self` (tingnan ang halimbawa sa itaas).
///
/// ## Kapag ang aking i-type ang magiging `Copy`?
///
/// Ang isang uri ay maaaring ipatupad `Copy` kung ang lahat ng mga bahagi nito ipatupad `Copy`.Halimbawa, ito struct ay maaaring maging `Copy`:
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Copy, Clone)]
/// struct Point {
///    x: i32,
///    y: i32,
/// }
/// ```
///
/// Ang isang struct ay maaaring `Copy`, at [`i32`] ay `Copy`, samakatuwid ang `Point` ay karapat-dapat na maging `Copy`.
/// Sa pamamagitan ng kaibahan, isaalang-alang
///
/// ```
/// # #![allow(dead_code)]
/// # struct Point;
/// struct PointList {
///     points: Vec<Point>,
/// }
/// ```
///
/// Ang istrukturang `PointList` ay hindi maaaring magpatupad ng `Copy`, dahil ang [`Vec<T>`] ay hindi `Copy`.Kung tinatangka naming kunin sa isang `Copy` pagpapatupad, kami ay makakuha ng isang error:
///
/// ```text
/// the trait `Copy` may not be implemented for this type; field `points` does not implement `Copy`
/// ```
///
/// Ibinahagi sanggunian (`&T`) ding `Copy`, kaya isang uri ay maaaring maging `Copy`, kahit na kapag ito pagpipigil shared sanggunian ng mga uri `T` na *hindi*`Copy`.
/// Isaalang-alang ang mga sumusunod na struct, na maaaring ipatupad `Copy`, sapagkat ito lamang ang humahawak ng isang *shared reference* sa aming mga non-`Copy` type `PointList` mula sa itaas:
///
/// ```
/// # #![allow(dead_code)]
/// # struct PointList;
/// #[derive(Copy, Clone)]
/// struct PointListWrapper<'a> {
///     point_list_ref: &'a PointList,
/// }
/// ```
///
/// ## Kapag *Maaari hindi* ang uri ng aking magiging `Copy`?
///
/// Ang ilang mga uri ay hindi makopya nang ligtas.Halimbawa, pagkopya `&mut T` nais lumikha ng isang alyas mutable reference.
/// Kinokopya [`String`] Gusto dobleng responsibilidad para sa pamamahala ng [`String`] 's buffer, na humahantong sa isang double libre.
///
/// Paglalahat ng huling kaso, ang anumang uri ng pagpapatupad ng [`Drop`] ay hindi maaaring maging `Copy`, sapagkat namamahala ito ng ilang mapagkukunan bukod sa sarili nitong mga byte ng [`size_of::<T>`].
///
/// Kung sinubukan mo upang ipatupad `Copy` sa isang struct o enum na naglalaman ng mga di-`Copy` data, makakakuha ka ng error [E0204].
///
/// [E0204]: ../../error-index.html#E0204
///
/// ## Kailan * dapat ang aking uri ay `Copy`?
///
/// Sa pangkalahatan, kung ang iyong uri na _can_ ay nagpapatupad ng `Copy`, dapat.
/// Isaisip, bagaman, na ang pagpapatupad `Copy` ay bahagi ng pampublikong API ng iyong uri.
/// Kung ang uri ay maaaring maging di-`Copy` sa future, maaaring ito ay masinop upang alisin ang `Copy` pagpapatupad ngayon, upang maiwasan ang paglabag ng pagbabago API.
///
/// ## karagdagang implementors
///
/// Bilang karagdagan sa [implementors listed below][impls], ang mga sumusunod na uri ay nagpapatupad din ng `Copy`:
///
/// * Mga uri ng function na item (ibig sabihin, ang mga natatanging uri na tinukoy para sa bawat pagpapaandar)
/// * Mga uri ng pagpapaandar ng pointer (hal. `fn() -> i32`)
/// * Mga uri ng Array, para sa lahat ng laki, kung ang uri ng item ay nagpapatupad din ng `Copy` (hal, `[i32; 123456]`)
/// * Tuple uri, kung ang bawat component din nagpapatupad `Copy` (eg, `()`, `(i32, bool)`)
/// * uri pagsasara, kung ang mga ito makuha ang walang halaga mula sa kapaligiran o kung lahat ng mga naturang nakunan halaga ipatupad `Copy` kanilang mga sarili.
///   Tandaan na ang mga variable nakunan ng shared reference laging ipatupad `Copy` (kahit na ang referent ay hindi), habang ang mga variable nakunan ng mutable reference kailanman ipatupad `Copy`.
///
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
/// [`String`]: ../../std/string/struct.String.html
/// [`size_of::<T>`]: crate::mem::size_of
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "copy"]
// FIXME(matthewjasper) Pinapayagan ang pagkopya ng isang uri na hindi nagpapatupad ng `Copy` dahil sa hindi nasiyahan na mga hangganan sa buhay (pagkopya ng `A<'_>` kapag `A<'static>: Copy` at `A<'_>: Clone` lamang).
// Mayroon kaming katangiang ito dito sa ngayon dahil lamang may ilang umiiral na mga pagdadalubhasa sa `Copy` na mayroon na sa karaniwang silid-aklatan, at walang paraan upang ligtas na magkaroon ng pag-uugaling ito sa ngayon.
//
//
//
//
#[rustc_unsafe_specialization_marker]
pub trait Copy: Clone {
    // Empty.
}

/// Kunin sa macro pagbuo ng isang impl ng trait `Copy`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Copy($item:item) {
    /* compiler built-in */
}

/// Uri na kung saan ito ay ligtas na magbahagi ng mga sanggunian sa pagitan thread.
///
/// trait na ito ay awtomatikong ipinatupad kapag tumutukoy sa compiler ito ay naaangkop.
///
/// Ang tumpak na kahulugan ay: isang uri `T` ay [`Sync`] kung at lamang kung `&T` ay [`Send`].
/// Sa ibang salita, kung walang posibilidad ng [undefined behavior][ub] (kabilang ang karera ng data) kapag pagpasa `&T` mga sanggunian sa pagitan thread.
///
/// Tulad ng inaasahan ng isa, ang mga primitive na uri tulad ng [`u8`] at [`f64`] ay lahat ng [`Sync`], at gayundin ang mga simpleng pinagsamang uri na naglalaman ng mga ito, tulad ng mga tuple, struct at enum.
/// Ang higit pang mga halimbawa ng pangunahing mga uri ng [`Sync`] ay nagsasama ng mga uri ng "immutable" tulad ng `&T`, at ang mga may simpleng minana na pagkabagot, tulad ng [`Box<T>`][box], [`Vec<T>`][vec] at karamihan sa iba pang mga uri ng koleksyon.
///
/// (Ang mga pangkalahatang parameter ay kailangang [`Sync`] para ang kanilang lalagyan ay maging [`Sync`].)
///
/// Ang isang medyo nakakagulat na bunga ng kahulugan ay ang `&mut T` ay `Sync` (kung ang `T` ay `Sync`) kahit na parang maaaring magbigay iyon ng hindi na-synchronize na pag-mutate.
/// Nanlilinlang ay na maaaring mabago ng isang reference sa likod ng isang shared reference (ibig sabihin, `& &mut T`) nagiging read-only, na parang ito ay isang `& &T`.
/// Samakatuwid walang panganib ng isang data lahi.
///
/// Uri na hindi `Sync` ay ang mga may "interior mutability" sa isang non-thread-safe na form, tulad ng [`Cell`][cell] at [`RefCell`][refcell].
/// Ang mga uri pahintulutan para sa pagbago ng kanilang mga nilalaman kahit sa pamamagitan ng isang hindi nababago, shared reference.
/// Halimbawa ang `set` na pamamaraan sa [`Cell<T>`][cell] ay tumatagal ng `&self`, kaya nangangailangan lamang ito ng isang nakabahaging sanggunian na [`&Cell<T>`][cell].
/// Gumagawa ang pamamaraan ng walang pagsabay, kaya't ang [`Cell`][cell] ay hindi maaaring maging `Sync`.
///
/// Ang isa pang halimbawa ng isang di-`Sync` na uri ay ang sanggunian na nagbibilang ng pointer [`Rc`][rc].
/// Given anumang reference [`&Rc<T>`][rc], maaari mong mai-clone ang isang bagong [`Rc<T>`][rc], ang pagbabago ng reference nagbibilang sa isang non-atomic paraan.
///
/// Para sa mga kaso kung kailan kailangan ng isang thread-safe interior mutability, ang Rust ay nagbibigay ng [atomic data types], pati na rin ang tahasang pag-lock sa pamamagitan ng [`sync::Mutex`][mutex] at [`sync::RwLock`][rwlock].
/// Tinitiyak ng mga uri na ang anumang mutasyon ay hindi maaaring maging sanhi ng mga karera ng data, samakatuwid ang mga uri ay `Sync`.
/// Gayundin, nagbibigay ang [`sync::Arc`][arc] ng isang thread-safe na analogue ng [`Rc`][rc].
///
/// Ang anumang uri na may panloob na mutability ay dapat ding gamitin ang [`cell::UnsafeCell`][unsafecell] wrapper sa paligid ng value(s) na maaaring mutated sa pamamagitan ng isang shared reference.
/// Nanghihina na gawin ito ay [undefined behavior][ub].
/// Halimbawa, ang [`transmute`][magbago]-ing mula `&T` na `&mut T` ay hindi wasto.
///
/// Tingnan [the Nomicon][nomicon-send-and-sync] para sa karagdagang mga detalye tungkol sa `Sync`.
///
/// [box]: ../../std/boxed/struct.Box.html
/// [vec]: ../../std/vec/struct.Vec.html
/// [cell]: crate::cell::Cell
/// [refcell]: crate::cell::RefCell
/// [rc]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [atomic data types]: crate::sync::atomic
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [unsafecell]: crate::cell::UnsafeCell
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [transmute]: crate::mem::transmute
/// [nomicon-send-and-sync]: ../../nomicon/send-and-sync.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "sync_trait")]
#[lang = "sync"]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be shared between threads safely",
    label = "`{Self}` cannot be shared between threads safely"
)]
pub unsafe auto trait Sync {
    // FIXME(estebank): sa sandaling suportahan upang magdagdag ng mga tala sa mga lupain ng `rustc_on_unimplemented` sa beta, at ito ay pinalawig upang suriin kung ang isang pagsasara ay saanman sa kadena ng kinakailangan, palawakin ito bilang tulad ng (#48534):
    //
    //
    // ```
    // on(
    //     closure,
    //     note="`{Self}` cannot be shared safely, consider marking the closure `move`"
    // ),
    // ```

    // Empty
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *mut T {}

macro_rules! impls {
    ($t: ident) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Hash for $t<T> {
            #[inline]
            fn hash<H: Hasher>(&self, _: &mut H) {}
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialEq for $t<T> {
            fn eq(&self, _other: &$t<T>) -> bool {
                true
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Eq for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialOrd for $t<T> {
            fn partial_cmp(&self, _other: &$t<T>) -> Option<cmp::Ordering> {
                Option::Some(cmp::Ordering::Equal)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Ord for $t<T> {
            fn cmp(&self, _other: &$t<T>) -> cmp::Ordering {
                cmp::Ordering::Equal
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Copy for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Clone for $t<T> {
            fn clone(&self) -> Self {
                Self
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Default for $t<T> {
            fn default() -> Self {
                Self
            }
        }

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralPartialEq for $t<T> {}

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralEq for $t<T> {}
    };
}

/// Ginagamit ang uri ng zero na laki upang markahan ang mga bagay na "act like" pagmamay-ari nila isang `T`.
///
/// Pagdaragdag ng isang `PhantomData<T>` patlang sa iyong uri nagsasabi sa compiler na ang iyong i-type ang kumikilos na parang nag-iimbak ito ng isang halaga ng mga uri `T`, kahit na ito ay hindi talagang.
/// Ginagamit ang impormasyong ito kapag kino-compute ng ilang mga katangian sa kaligtasan.
///
/// Para sa isang mas malalim na paliwanag ng kung paano gamitin ang `PhantomData<T>`, pakitingnan ang [the Nomicon](../../nomicon/phantom-data.html).
///
/// # Isang malagim note 👻👻👻
///
/// Kahit na sila ay parehong may nakakatakot na mga pangalan, `PhantomData` at 'uri multo' ay may kaugnayan, ngunit hindi magkapareho.Isang multo uri ng parameter ay lamang ng isang uri ng parameter na kung saan ay hindi kailanman ginamit.
/// Sa Rust, madalas na ito ay nagiging sanhi ng pagreklamo ng tagatala, at ang solusyon ay upang magdagdag ng "dummy" na paggamit sa pamamagitan ng `PhantomData`.
///
/// # Examples
///
/// ## Hindi nagamit na mga parameter lifetime
///
/// Marahil ang pinaka-karaniwang paggamit para sa `PhantomData` ay isang struct na may isang hindi nagamit na buhay parameter, karaniwang bilang bahagi ng ilang mga hindi ligtas na mga code.
/// Halimbawa, dito ay isang struct `Slice` na may dalawang mga payo ng uri `*const T`, siguro na tumuturo sa isang array sa isang lugar:
///
/// ```compile_fail,E0392
/// struct Slice<'a, T> {
///     start: *const T,
///     end: *const T,
/// }
/// ```
///
/// Ang layunin ay na ang pinagbabatayan ng data ay may-bisa lamang para sa mga buhay `'a`, para `Slice` dapat hindi mawalan ng kasaysayan `'a`.
/// Gayunpaman, ito layunin ay hindi ipinahayag sa mga code, dahil walang mga gamit ng lifetime `'a` at samakatuwid ito ay hindi i-clear kung ano ang data na ito ay sumasaklaw sa.
/// Maaari naming itama ito sa pamamagitan ng pagsasabi ng compiler upang kumilos *parang* ang `Slice` struct naglalaman ng isang reference `&'a T`:
///
/// ```
/// use std::marker::PhantomData;
///
/// # #[allow(dead_code)]
/// struct Slice<'a, T: 'a> {
///     start: *const T,
///     end: *const T,
///     phantom: PhantomData<&'a T>,
/// }
/// ```
///
/// Ito rin ay nangangailangan ng anotasyon `T: 'a`, na nagpapahiwatig na ang anumang mga sanggunian sa `T` ay may bisa sa buong buhay na `'a`.
///
/// Kapag pinasimulan ang isang `Slice` ibibigay mo lamang ang halagang `PhantomData` para sa patlang `phantom`:
///
/// ```
/// # #![allow(dead_code)]
/// # use std::marker::PhantomData;
/// # struct Slice<'a, T: 'a> {
/// #     start: *const T,
/// #     end: *const T,
/// #     phantom: PhantomData<&'a T>,
/// # }
/// fn borrow_vec<T>(vec: &Vec<T>) -> Slice<'_, T> {
///     let ptr = vec.as_ptr();
///     Slice {
///         start: ptr,
///         end: unsafe { ptr.add(vec.len()) },
///         phantom: PhantomData,
///     }
/// }
/// ```
///
/// ## Hindi nagamit na mga parameter type
///
/// Minsan nangyayari na mayroon kang hindi nagamit na i-type ang mga parameter na nagpapahiwatig kung ano ang uri ng data ng struct ay "tied" na, kahit na ang data ay hindi aktwal na natagpuan sa struct mismo.
/// Narito ang isang halimbawa kung saan lumilitaw ito sa [FFI].
/// Ang mga banyagang interface gamit handle ng uri `*mut ()` mag-refer sa Rust mga halaga ng iba't-ibang uri.
/// Sinusubaybayan namin ang uri ng Rust gamit ang isang parameter na uri ng multo sa istrukturang `ExternalResource` na nakabalot sa isang hawakan.
///
/// [FFI]: ../../book/ch19-01-unsafe-rust.html#using-extern-functions-to-call-external-code
///
/// ```
/// # #![allow(dead_code)]
/// # trait ResType { }
/// # struct ParamType;
/// # mod foreign_lib {
/// #     pub fn new(_: usize) -> *mut () { 42 as *mut () }
/// #     pub fn do_stuff(_: *mut (), _: usize) {}
/// # }
/// # fn convert_params(_: ParamType) -> usize { 42 }
/// use std::marker::PhantomData;
/// use std::mem;
///
/// struct ExternalResource<R> {
///    resource_handle: *mut (),
///    resource_type: PhantomData<R>,
/// }
///
/// impl<R: ResType> ExternalResource<R> {
///     fn new() -> Self {
///         let size_of_res = mem::size_of::<R>();
///         Self {
///             resource_handle: foreign_lib::new(size_of_res),
///             resource_type: PhantomData,
///         }
///     }
///
///     fn do_stuff(&self, param: ParamType) {
///         let foreign_params = convert_params(param);
///         foreign_lib::do_stuff(self.resource_handle, foreign_params);
///     }
/// }
/// ```
///
/// ## Pagmamay-ari at ang drop check
///
/// Pagdaragdag ng isang patlang ng uri `PhantomData<T>` nagpapahiwatig na ang iyong i-type ang nagmamay-ari ng data ng uri `T`.Ito naman ay nagpapahiwatig na kapag ang iyong uri ay nahulog, maaari itong i-drop ang isa o higit pang mga pagkakataon ng uri na `T`.
/// May kinalaman ito sa pagsusuri ng [drop check] compiler ng Rust.
///
/// Kung ang iyong struct ay hindi sa katunayan *sariling* ang data ng uri `T`, ito ay mas mahusay na gumamit ng isang reference uri, tulad ng `PhantomData<&'a T>` (ideally) o `PhantomData<*const T>` (kung walang lifetime nalalapat), sa gayon ay hindi upang ipahiwatig ang pagmamay-ari.
///
///
/// [drop check]: ../../nomicon/dropck.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "phantom_data"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct PhantomData<T: ?Sized>;

impls! { PhantomData }

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Sync + ?Sized> Send for &T {}
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Send + ?Sized> Send for &mut T {}
}

/// Compiler-panloob trait ginamit upang ipahiwatig ang uri ng enum discriminants.
///
/// Ito trait ay awtomatikong ipinatupad para sa bawat uri at hindi magdagdag ng anumang mga garantiya na [`mem::Discriminant`].
/// Ito ay **hindi natukoy na pag-uugali** upang magdala sa pagitan ng `DiscriminantKind::Discriminant` at `mem::Discriminant`.
///
/// [`mem::Discriminant`]: crate::mem::Discriminant
///
#[unstable(
    feature = "discriminant_kind",
    issue = "none",
    reason = "this trait is unlikely to ever be stabilized, use `mem::discriminant` instead"
)]
#[lang = "discriminant_kind"]
pub trait DiscriminantKind {
    /// Ang uri ng discriminant, na dapat bigyang-kasiyahan ang trait bounds kinakailangan ng `mem::Discriminant`.
    ///
    #[lang = "discriminant_type"]
    type Discriminant: Clone + Copy + Debug + Eq + PartialEq + Hash + Send + Sync + Unpin;
}

/// Compiler-panloob trait ginamit upang matukoy kung ang isang uri ay naglalaman ng anumang `UnsafeCell` panloob, ngunit hindi sa pamamagitan ng kawalang-tapat.
///
/// Ito ay nakakaapekto sa, halimbawa, kung ang isang `static` ng na-type ay nakalagay sa read-only static memory o writable static memory.
///
#[lang = "freeze"]
pub(crate) unsafe auto trait Freeze {}

impl<T: ?Sized> !Freeze for UnsafeCell<T> {}
unsafe impl<T: ?Sized> Freeze for PhantomData<T> {}
unsafe impl<T: ?Sized> Freeze for *const T {}
unsafe impl<T: ?Sized> Freeze for *mut T {}
unsafe impl<T: ?Sized> Freeze for &T {}
unsafe impl<T: ?Sized> Freeze for &mut T {}

/// Uri na maaaring ligtas na inilipat matapos na naka-pin.
///
/// Ang Rust mismo ay walang kuru-kuro ng hindi maiuugaw na mga uri, at isinasaalang-alang ang mga paggalaw (hal., Sa pamamagitan ng pagtatalaga o [`mem::replace`]) upang laging ligtas.
///
/// Ang uri [`Pin`][Pin] ang ginagamit sa halip upang maiwasan ang gumagalaw sa pamamagitan ng mga uri ng sistema.Payo `P<T>` nakabalot sa [`Pin<P<T>>`][Pin] wrapper ay hindi maaaring ilipat sa labas ng.
/// Tingnan ang [`pin` module] dokumentasyon para sa karagdagang impormasyon sa pinning.
///
/// Ang pagpapatupad ng `Unpin` trait para sa `T` ay nakakataas ng mga paghihigpit ng pag-pin sa uri, na pagkatapos ay pinapayagan ang paglipat ng `T` mula sa [`Pin<P<T>>`][Pin] na may mga pagpapaandar tulad ng [`mem::replace`].
///
///
/// `Unpin` Wala pang saysay ang mga para sa mga di-naka-pin data.
/// Sa partikular, masayang gumagalaw ang [`mem::replace`] ng data ng `!Unpin` (gumagana ito para sa anumang `&mut T`, hindi lamang kapag `T: Unpin`).
/// Gayunpaman, hindi mo maaaring gamitin [`mem::replace`] sa data nakabalot sa loob ng isang [`Pin<P<T>>`][Pin] dahil hindi ka maaaring makakuha ng mga `&mut T` kailangan mo para sa na, at *na* ay kung ano ang gumagawa ng system na ito sa trabaho.
///
/// Kaya ito, halimbawa, magagawa lamang sa mga uri ng pagpapatupad ng `Unpin`:
///
/// ```rust
/// # #![allow(unused_must_use)]
/// use std::mem;
/// use std::pin::Pin;
///
/// let mut string = "this".to_string();
/// let mut pinned_string = Pin::new(&mut string);
///
/// // Kailangan namin maaaring mabago ng isang reference na tumawag `mem::replace`.
/// // Maaari naming makakuha ng tulad ng isang reference sa pamamagitan (implicitly) invoking `Pin::deref_mut`, ngunit iyon ay lamang na posible dahil `String` nagpapatupad `Unpin`.
/////
/// mem::replace(&mut *pinned_string, "other".to_string());
/// ```
///
/// Ito trait ay awtomatikong ipinapatupad para sa halos bawat uri.
///
/// [`mem::replace`]: crate::mem::replace
/// [Pin]: crate::pin::Pin
/// [`pin` module]: crate::pin
///
///
///
///
///
///
#[stable(feature = "pin", since = "1.33.0")]
#[rustc_on_unimplemented(
    on(_Self = "std::future::Future", note = "consider using `Box::pin`",),
    message = "`{Self}` cannot be unpinned"
)]
#[lang = "unpin"]
pub auto trait Unpin {}

/// Isang uri ng marker na hindi nagpapatupad ng `Unpin`.
///
/// Kung ang isang uri ay naglalaman ng isang `PhantomPinned`, hindi ito ipatupad `Unpin` pamamagitan ng default.
#[stable(feature = "pin", since = "1.33.0")]
#[derive(Debug, Default, Copy, Clone, Eq, PartialEq, Ord, PartialOrd, Hash)]
pub struct PhantomPinned;

#[stable(feature = "pin", since = "1.33.0")]
impl !Unpin for PhantomPinned {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a T {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a mut T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *const T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *mut T {}

/// Pagpapatupad ng `Copy` para sa uri ng nauna.
///
/// Ang mga pagpapatupad na hindi mailarawan sa Rust ay ipinatupad sa `traits::SelectionContext::copy_clone_conditions()` sa `rustc_trait_selection`.
///
///
mod copy_impls {

    use super::Copy;

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Copy for ! {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *const T {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *mut T {}

    /// Ibinahagi mga sanggunian ay maaaring kopyahin, ngunit maaaring mabago ng mga sanggunian *hindi*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for &T {}
}