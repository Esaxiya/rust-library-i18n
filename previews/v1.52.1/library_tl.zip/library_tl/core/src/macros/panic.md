Panics ang kasalukuyang thread.

Ito ay nagpapahintulot sa isang programa upang wakasan kaagad at magbigay ng feedback sa tumatawag ng program.
`panic!` ay dapat na ginagamit kapag ang isang programa ay umabot sa isang di-mabaligtad estado.

macro Ito ay ang perpektong paraan upang igiit ang mga kondisyon sa halimbawa code at sa mga pagsubok.
`panic!` ay malapit na nakatali sa `unwrap` na pamamaraan ng parehong [`Option`][ounwrap] at [`Result`][runwrap] enums.
Ang parehong pagpapatupad ay tumatawag sa `panic!` kapag itinakda ang mga ito sa [`None`] o [`Err`] variant.

Kapag gumagamit ng `panic!()` maaari mong tukuyin ang isang string payload, na binuo gamit ang [`format!`] syntax.
Ang payload na iyon ay ginagamit kapag tinuturok ang panic sa tumatawag na thread na Rust, na sanhi ng buo sa panic.

Ang pag-uugali ng default `std` hook, ibig sabihin,
ang code na tumatakbo nang direkta pagkatapos ng panic ay tinawag, ay i-print ang payload ng mensahe sa `stderr` kasama ang impormasyong file/line/column ng tawag na `panic!()`.

Maaari mong i-override ang panic hook gamit ang [`std::panic::set_hook()`].
Sa loob ng hook ang isang panic ay maaaring ma-access bilang isang `&dyn Any + Send`, na naglalaman ng alinman sa isang `&str` o `String` para sa regular na mga pag-iimbita ng `panic!()`.
Upang panic na may halagang isa pang iba pang mga uri, [`panic_any`] maaaring gamitin.

[`Result`] Ang enum ay madalas na isang mas mahusay na solusyon para sa pagbawi mula sa mga error kaysa sa paggamit ng `panic!` macro.
macro na ito ay dapat gamitin upang maiwasan magpatuloy paggamit ng maling mga halaga, tulad ng mula sa panlabas na pinagmumulan.
Ang detalyadong impormasyon tungkol sa paghawak ng error ay matatagpuan sa [book].

Tingnan din ang macro [`compile_error!`], para sa pagtataas ng mga pagkakamali habang nagkakalap compilation.

[ounwrap]: Option::unwrap
[runwrap]: Result::unwrap
[`std::panic::set_hook()`]: ../std/panic/fn.set_hook.html
[`panic_any`]: ../std/panic/fn.panic_any.html
[`Box`]: ../std/boxed/struct.Box.html
[`Any`]: crate::any::Any
[`format!`]: ../std/macro.format.html
[book]: ../book/ch09-00-error-handling.html

# Kasalukuyang pagpapatupad

Kung ang main thread panics ito ay wakasan ang lahat ng iyong mga thread at tapusin ang iyong programa na may code `101`.

# Examples

```should_panic
# #![allow(unreachable_code)]
panic!();
panic!("this is a terrible mistake!");
panic!("this is a {} {message}", "fancy", message = "message");
std::panic::panic_any(4); // panic with the value of 4 to be collected elsewhere
```





