use crate::{iter::FusedIterator, ops::Try};

/// Isang iterator na umuulit nang walang katapusan.
///
/// Ang `struct` na ito ay nilikha ng pamamaraang [`cycle`] sa [`Iterator`].
/// Tingnan ang dokumentasyon nito para sa higit pa.
///
/// [`cycle`]: Iterator::cycle
/// [`Iterator`]: trait.Iterator.html
#[derive(Clone, Debug)]
#[must_use = "iterators are lazy and do nothing unless consumed"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Cycle<I> {
    orig: I,
    iter: I,
}

impl<I: Clone> Cycle<I> {
    pub(in crate::iter) fn new(iter: I) -> Cycle<I> {
        Cycle { orig: iter.clone(), iter }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> Iterator for Cycle<I>
where
    I: Clone + Iterator,
{
    type Item = <I as Iterator>::Item;

    #[inline]
    fn next(&mut self) -> Option<<I as Iterator>::Item> {
        match self.iter.next() {
            None => {
                self.iter = self.orig.clone();
                self.iter.next()
            }
            y => y,
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        // cycle iterator ay alinman walang laman o walang katapusan
        match self.orig.size_hint() {
            sz @ (0, Some(0)) => sz,
            (0, _) => (0, None),
            _ => (usize::MAX, None),
        }
    }

    #[inline]
    fn try_fold<Acc, F, R>(&mut self, mut acc: Acc, mut f: F) -> R
    where
        F: FnMut(Acc, Self::Item) -> R,
        R: Try<Ok = Acc>,
    {
        // ganap na paulitin ang kasalukuyang umuulit.
        // ito ay kinakailangan dahil `self.iter` ay maaaring alisan ng laman kahit na kapag `self.orig` ay hindi
        acc = self.iter.try_fold(acc, &mut f)?;
        self.iter = self.orig.clone();

        // makumpleto ang isang buong cycle, nang pinapanatili ang track ng kung ang nagbisikleta iterator ay walang laman o hindi.
        // kailangan nating bumalik nang maaga sa kaso ng walang laman na iterator upang maiwasan ang isang walang katapusang loop
        //
        let mut is_empty = true;
        acc = self.iter.try_fold(acc, |acc, x| {
            is_empty = false;
            f(acc, x)
        })?;

        if is_empty {
            return try { acc };
        }

        loop {
            self.iter = self.orig.clone();
            acc = self.iter.try_fold(acc, &mut f)?;
        }
    }

    // Walang `fold` override, dahil ang `fold` ay walang katuturan para sa `Cycle`, at wala kaming magagawa na mas mahusay kaysa sa default.
    //
}

#[stable(feature = "fused", since = "1.26.0")]
impl<I> FusedIterator for Cycle<I> where I: Clone + Iterator {}