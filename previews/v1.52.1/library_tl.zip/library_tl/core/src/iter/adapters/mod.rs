use crate::iter::{InPlaceIterable, Iterator};
use crate::ops::{ControlFlow, Try};

mod chain;
mod cloned;
mod copied;
mod cycle;
mod enumerate;
mod filter;
mod filter_map;
mod flatten;
mod fuse;
mod inspect;
mod intersperse;
mod map;
mod map_while;
mod peekable;
mod rev;
mod scan;
mod skip;
mod skip_while;
mod step_by;
mod take;
mod take_while;
mod zip;

pub use self::{
    chain::Chain, cycle::Cycle, enumerate::Enumerate, filter::Filter, filter_map::FilterMap,
    flatten::FlatMap, fuse::Fuse, inspect::Inspect, map::Map, peekable::Peekable, rev::Rev,
    scan::Scan, skip::Skip, skip_while::SkipWhile, take::Take, take_while::TakeWhile, zip::Zip,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::cloned::Cloned;

#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::step_by::StepBy;

#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::flatten::Flatten;

#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::copied::Copied;

#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::intersperse::{Intersperse, IntersperseWith};

#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::map_while::MapWhile;

#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::zip::TrustedRandomAccess;

/// Ang trait ay nagbibigay ng palipat na pag-access sa source-stage sa isang interator-adapter pipeline sa ilalim ng mga kundisyon na
/// * ang iterator pinagmulan `S` mismo nagpapatupad `SourceIter<Source = S>`
/// * mayroong isang delegasyon na pagpapatupad ng trait na ito para sa bawat adapter sa pipeline sa pagitan ng mapagkukunan at ng consumer ng pipeline.
///
/// Kapag ang source ay isang pagmamay-ari iterator struct (na karaniwang tinatawag `IntoIter`) at pagkatapos ito ay maaaring maging kapaki-pakinabang para specialize [`FromIterator`] pagpapatupad o recovering ang mga natitirang mga elemento pagkatapos ng isang iterator Bahagyang nai-ubos na.
///
///
/// Tandaan na ang mga pagpapatupad ay hindi kinakailangang magbigay upang ma-access ang panloob na mapagkukunan ng isang pipeline.Ang isang stateful intermediate adapter ay maaaring sabik na suriin ang isang bahagi ng pipeline at ilantad ang panloob na imbakan bilang mapagkukunan.
///
/// Ang trait ay hindi ligtas dahil ang mga nagpapatupad ay dapat na panatilihin ang karagdagang mga katangian ng kaligtasan.
/// Tingnan [`as_inner`] para sa mga detalye.
///
/// # Examples
///
/// Pagkuha ng isang bahagyang natupok na mapagkukunan:
///
/// ```
/// # #![feature(inplace_iteration)]
/// # use std::iter::SourceIter;
///
/// let mut iter = vec![9, 9, 9].into_iter().map(|i| i * i);
/// let _ = iter.next();
/// let mut remainder = std::mem::replace(unsafe { iter.as_inner() }, Vec::new().into_iter());
/// println!("n = {} elements remaining", remainder.len());
/// ```
///
/// [`FromIterator`]: crate::iter::FromIterator
/// [`as_inner`]: SourceIter::as_inner
///
///
///
///
///
#[unstable(issue = "none", feature = "inplace_iteration")]
pub unsafe trait SourceIter {
    /// Ang isang source stage sa isang iterator pipeline.
    type Source: Iterator;

    /// Kunin ang mapagkukunan ng isang iterator pipeline.
    ///
    /// # Safety
    ///
    /// Pagpapatupad ng dapat ibalik ang parehong nababago reference para sa kanilang buhay, maliban kung napalitan ng tumatawag.
    /// Maaari lamang palitan ng mga tumatawag ang sanggunian kapag pinahinto nila ang pag-ulit at ihulog ang tubo ng iterator pagkatapos makuha ang pinagmulan.
    ///
    /// Ang ibig sabihin nito iterator adapters maaaring umasa sa ang pinagmulan hindi nagbabago sa panahon ng pag-ulit ngunit hindi sila maaaring umasa sa ito sa kanilang Drop pagpapatupad.
    ///
    /// Ang pagpapatupad ng pamamaraang ito ay nangangahulugang tinatanggal ng mga adaptor ang pribadong pag-access lamang sa kanilang mapagkukunan at maaari lamang umasa sa mga garantiyang ginawa batay sa mga uri ng tatanggap ng pamamaraan.
    /// Ang kakulangan ng pinaghihigpitang pag-access ay nangangailangan din na ang mga adapter ay dapat na itaguyod ang pampublikong API ng mapagkukunan kahit na may access sila sa mga panloob na ito.
    ///
    /// Ang mga tumatawag siya namang dapat asahan ang source na maging sa anumang estado na ay pare-pareho sa mga pampublikong API since adapters-upo sa pagitan ng ito at ang source ay may parehong pag-access.
    /// Sa partikular ang isang adapter ay maaaring natupok ng maraming mga elemento kaysa sa mahigpit na kinakailangan.
    ///
    /// Ang pangkalahatang layunin ng mga kinakailangang ito ay upang ipaalam sa mga consumer ng isang pipeline paggamit
    /// * anuman ang mananatili sa pinagmulan pagkatapos tumigil
    /// * ang memorya na naging hindi nagamit sa pamamagitan ng pagsulong ng isang umuulit na iterator
    ///
    /// [`next()`]: Iterator::next()
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn as_inner(&mut self) -> &mut Self::Source;
}

/// Ang isang iterator adapter na naglalabas ng output hangga't ang nakapailalim na iterator gumagawa `Result::Ok` halaga.
///
///
/// Kung ang isang error ay nakatagpo, ang iterator hihinto at ang error ay naka-imbak.
///
pub(crate) struct ResultShunt<'a, I, E> {
    iter: I,
    error: &'a mut Result<(), E>,
}

/// Iproseso ang ibinigay na umuulit na parang nagbigay ng isang `T` sa halip na isang `Result<T, _>`.
/// Ang anumang mga pagkakamali ay titigil sa panloob na iterator at ang pangkalahatang resulta ay magiging isang error.
///
pub(crate) fn process_results<I, T, E, F, U>(iter: I, mut f: F) -> Result<U, E>
where
    I: Iterator<Item = Result<T, E>>,
    for<'a> F: FnMut(ResultShunt<'a, I, E>) -> U,
{
    let mut error = Ok(());
    let shunt = ResultShunt { iter, error: &mut error };
    let value = f(shunt);
    error.map(|()| value)
}

impl<I, T, E> Iterator for ResultShunt<'_, I, E>
where
    I: Iterator<Item = Result<T, E>>,
{
    type Item = T;

    fn next(&mut self) -> Option<Self::Item> {
        self.find(|_| true)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.error.is_err() {
            (0, Some(0))
        } else {
            let (_, upper) = self.iter.size_hint();
            (0, upper)
        }
    }

    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let error = &mut *self.error;
        self.iter
            .try_fold(init, |acc, x| match x {
                Ok(x) => ControlFlow::from_try(f(acc, x)),
                Err(e) => {
                    *error = Err(e);
                    ControlFlow::Break(try { acc })
                }
            })
            .into_try()
    }

    fn fold<B, F>(mut self, init: B, fold: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_fold(init, ok(fold)).unwrap()
    }
}