//! Composable panlabas na pag-ulit.
//!
//! Kung nakakita ka ng iyong sarili sa isang koleksyon ng ilang mga uri, at kinakailangan upang maisagawa ang isang operasyon sa mga elemento ng sinabi koleksyon, makikita mo agad na tumakbo sa 'iterators'.
//! Ang Iterators ay lubhang ginagamit sa idiomatikong Rust code, kaya't sulit na pamilyar sa kanila.
//!
//! Bago na nagpapaliwanag higit pa, sabihin makipag-usap tungkol sa kung paano ang module na ito ay nakabalangkas:
//!
//! # Organization
//!
//! Ang module na ito ay higit sa lahat ay nakaayos ayon sa uri:
//!
//! * [Traits] ang pangunahing bahagi: ang mga traits na tumutukoy kung anong uri ng mga iterator ang mayroon at kung ano ang maaari mong gawin sa kanila.Ang paraan ng mga traits ay nagkakahalaga ng paglagay ng ilang dagdag na oras na pag-aaral sa.
//! * [Functions] magbigay ng ilang mga kapaki-pakinabang na paraan upang lumikha ng ilang mga pangunahing iterators.
//! * [Structs] ay madalas na mga uri ng pagbabalik ng iba't ibang mga pamamaraan sa traits ng modyul na ito.Karaniwan mong gugustuhin na tingnan ang pamamaraan na lumilikha ng `struct`, sa halip na ang `struct` mismo.
//! Para sa karagdagang detalye tungkol sa kung bakit, tingnan ang '[Implementing Iterator](#pagpapatupad-iterator)'.
//!
//! [Traits]: #traits
//! [Functions]: #functions
//! [Structs]: #structs
//!
//! Ayan yun!dig Natin Ito sa iterators.
//!
//! # Iterator
//!
//! Ang puso at kaluluwa ng ang module na ito ay ang [`Iterator`] trait.Ang core ng [`Iterator`] ay ganito ang hitsura:
//!
//! ```
//! trait Iterator {
//!     type Item;
//!     fn next(&mut self) -> Option<Self::Item>;
//! }
//! ```
//!
//! Ang isang iterator ay may isang paraan, [`next`], na kapag tinatawag na, ay nagbabalik ng isang [`Option`]`<Item>`.
//! [`next`] ay babalik [`Some(Item)`] hangga't mayroong mga elemento, at sa sandaling sila na ang lahat ay ubos na, ay magbabalik `None` upang ipahiwatig na pag-ulit ay natapos na.
//! Indibidwal iterators ay maaaring pumili upang ipagpatuloy ang pag-ulit, at sa gayon pagtawag [`next`] muli maaaring o hindi maaaring kalaunan simulan bumabalik [`Some(Item)`] muli sa ilang mga punto (halimbawa, tingnan [`TryIter`]).
//!
//!
//! [`Iterator`] 's buong kahulugan ay nagsasama ng isang bilang ng iba pang mga pamamaraan pati na rin, ngunit ang mga ito ay default na pamamaraan, na binuo batay sa [`next`], at kaya kumuha ka ng mga ito para sa libre.
//!
//! Iterators ding composable, at ito ay pangkaraniwan sa chain iyon nang magkakasama upang gawin mas kumplikadong paraan ng processing.Tingnan ang seksyon [Adapters](#adapters) ibaba para sa karagdagang detalye.
//!
//! [`Some(Item)`]: Some
//! [`next`]: Iterator::next
//! [`TryIter`]: ../../std/sync/mpsc/struct.TryIter.html
//!
//! # Ang tatlong mga paraan ng pag-ulit
//!
//! May tatlong karaniwang paraan na kung saan ay maaaring lumikha ng iterators mula sa isang koleksyon:
//!
//! * `iter()`, na umuulit sa higit sa `&T`.
//! * `iter_mut()`, na umuulit sa higit sa `&mut T`.
//! * `into_iter()`, na umuulit sa higit sa `T`.
//!
//! Iba't-ibang mga bagay sa ang standard na aklatan ay maaaring ipatupad ang isa o higit pa sa mga tatlo, kung saan naaangkop.
//!
//! # Pagpapatupad ng Iterator
//!
//! Ang paglikha ng isang iterator ng iyong sarili ay nagsasangkot ng dalawang mga hakbang: paglikha ng isang `struct` upang i-hold ang estado ng iterator, at pagkatapos ay ipatupad ang [`Iterator`] para sa `struct` na iyon.
//! Ito ang dahilan kung bakit mayroong maraming `mga istr` sa modyul na ito: mayroong isa para sa bawat ad ng iterator at iterator.
//!
//! Natin gumawa ng isang iterator pinangalanan `Counter` na binibilang mula `1` na `5`:
//!
//! ```
//! // Una, ang struct:
//!
//! /// Isang iterator na binibilang mula isa hanggang lima
//! struct Counter {
//!     count: usize,
//! }
//!
//! // Gusto namin ang aming count na magsimula sa isa, kaya sabihin magdagdag ng isang new() paraan upang tulong.
//! // Ito ay hindi mahigpit na kinakailangan, ngunit ito ay maginhawa.
//! // Tandaan na sinisimulan namin ang `count` sa zero, makikita natin kung bakit sa `next()`'s pagpapatupad sa ibaba.
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // Pagkatapos, kami ay ipatupad `Iterator` para sa aming `Counter`:
//!
//! impl Iterator for Counter {
//!     // kami ay pagbibilang sa usize
//!     type Item = usize;
//!
//!     // next() ay ang tanging kinakailangang pamamaraan
//!     fn next(&mut self) -> Option<Self::Item> {
//!         // Dinagdagan aming count.Ito ay kung bakit namin nagsimula sa zero.
//!         self.count += 1;
//!
//!         // Suriin upang malaman kung natapos na namin ang pagbibilang o hindi.
//!         if self.count < 6 {
//!             Some(self.count)
//!         } else {
//!             None
//!         }
//!     }
//! }
//!
//! // At ngayon maaari naming gamitin ito!
//!
//! let mut counter = Counter::new();
//!
//! assert_eq!(counter.next(), Some(1));
//! assert_eq!(counter.next(), Some(2));
//! assert_eq!(counter.next(), Some(3));
//! assert_eq!(counter.next(), Some(4));
//! assert_eq!(counter.next(), Some(5));
//! assert_eq!(counter.next(), None);
//! ```
//!
//! Ang pagtawag sa [`next`] sa ganitong paraan ay paulit-ulit.Ang Rust ay may isang konstruksyon na maaaring tumawag sa [`next`] sa iyong iterator, hanggang sa umabot ito sa `None`.Sabihin pumunta sa paglipas na susunod.
//!
//! Tandaan din na ang `Iterator` ay nagbibigay ng isang default na pagpapatupad ng mga pamamaraan tulad ng `nth` at `fold` na tumatawag sa `next` sa loob.
//! Gayunpaman, posible ring magsulat ng isang pasadyang pagpapatupad ng mga pamamaraan tulad ng `nth` at `fold` kung ang isang iterator ay maaaring makalkula ang mga ito nang mas mahusay nang hindi tinawag ang `next`.
//!
//! # `for` mga loop at `IntoIterator`
//!
//! Ang Rust's `for` loop syntax ay talagang asukal para sa mga iterator.Narito ang isang pangunahing halimbawa ng `for`:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Ito ay i-print ang mga numero isa hanggang lima, ang bawat isa sa kanilang sariling mga linya.Ngunit mapapansin mo ang isang bagay dito: hindi kami tumawag sa anumang bagay sa aming vector upang makagawa ng isang iterator.Ano ang nagbibigay?
//!
//! Mayroong isang trait sa karaniwang silid-aklatan para sa pag-convert ng isang bagay sa isang iterator: [`IntoIterator`].
//! Ang trait ay may isang pamamaraan, [`into_iter`], na nagko-convert sa bagay na nagpapatupad ng [`IntoIterator`] sa isang iterator.
//! Tingnan natin muli ang `for` loop na iyon, at kung paano ito i-convert ng tagatala:
//!
//! [`into_iter`]: IntoIterator::into_iter
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Rust de-sugars ito sa:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//! {
//!     let result = match IntoIterator::into_iter(values) {
//!         mut iter => loop {
//!             let next;
//!             match iter.next() {
//!                 Some(val) => next = val,
//!                 None => break,
//!             };
//!             let x = next;
//!             let () = { println!("{}", x); };
//!         },
//!     };
//!     result
//! }
//! ```
//!
//! Una, tinatawag naming `into_iter()` sa halaga.Pagkatapos, aming sa iterator na nagbabalik, pagtawag [`next`] paulit hanggang sa makita namin ang isang `None`.
//! Sa puntong iyon, `break` namin wala sa loop, at tapos na kaming umulit.
//!
//! Mayroong isa pang banayad na piraso dito: ang karaniwang silid-aklatan ay naglalaman ng isang kagiliw-giliw na pagpapatupad ng [`IntoIterator`]:
//!
//! ```ignore (only-for-syntax-highlight)
//! impl<I: Iterator> IntoIterator for I
//! ```
//!
//! Sa ibang salita, ang lahat ng [`Iterator`] s ipatupad [`IntoIterator`], sa pamamagitan lamang ng pagbalik sa kanilang sarili.Ang ibig sabihin nito ang dalawang bagay:
//!
//! 1. Kung nagsusulat ka ng isang [`Iterator`], maaari mo itong gamitin sa isang `for` loop.
//! 2. Kung lumilikha ka ng isang koleksyon, pagpapatupad [`IntoIterator`] para papayagan nito ang iyong koleksyon upang magamit sa mga `for` loop.
//!
//! # Iterating sa pamamagitan ng reference
//!
//! Dahil ang [`into_iter()`] ay tumatagal ng `self` ayon sa halaga, ang paggamit ng isang `for` loop upang umulit sa isang koleksyon ay naubos ang koleksyon na iyon.Kadalasan, baka gusto mong umulit sa isang koleksyon nang hindi ito naubos.
//! Maraming mga koleksyon ay nag-aalok pamamaraan na nagbibigay ng iterators higit sa sanggunian, conventionally tinatawag `iter()` at `iter_mut()` ayon sa pagkakabanggit:
//!
//! ```
//! let mut values = vec![41];
//! for x in values.iter_mut() {
//!     *x += 1;
//! }
//! for x in values.iter() {
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1); // `values` ay pagmamay-ari pa rin ng pagpapaandar na ito.
//! ```
//!
//! Kung ang isang uri ng koleksyon na `C` ay nagbibigay ng `iter()`, karaniwang ipinapatupad din nito ang `IntoIterator` para sa `&C`, na may pagpapatupad na tumatawag lamang sa `iter()`.
//! Gayundin, ang isang koleksyon `C` na nagbibigay ng `iter_mut()` sa pangkalahatan ay nagpapatupad ng `IntoIterator` para sa `&mut C` sa pamamagitan ng paglalaan sa `iter_mut()`.Nagbibigay-daan ito sa isang maginhawang shorthand:
//!
//! ```
//! let mut values = vec![41];
//! for x in &mut values { // pareho ng `values.iter_mut()`
//!     *x += 1;
//! }
//! for x in &values { // katulad ng `values.iter()`
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1);
//! ```
//!
//! Habang maraming mga koleksyon ang nag-aalok ng `iter()`, hindi lahat ay nag-aalok ng `iter_mut()`.
//! Halimbawa, mutating ang susi ng isang [`HashSet<T>`] o [`HashMap<K, V>`] maaaring ilagay sa koleksyon na ito sa isang pabagu-bagong katayuan kung ang susi hashes pagbabago, kaya ang mga koleksyon lamang ay nag-aalok `iter()`.
//!
//! [`into_iter()`]: IntoIterator::into_iter
//! [`HashSet<T>`]: ../../std/collections/struct.HashSet.html
//! [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
//!
//! # Adapters
//!
//! Ang mga pagpapaandar na kukuha ng [`Iterator`] at ibalik ang isa pang [`Iterator`] ay madalas na tinatawag na 'iterator adapters', dahil sila ay isang form ng 'adapter
//! pattern'.
//!
//! Karaniwang iterator adapters isama ang [`map`], [`take`], at [`filter`].
//! Para sa karagdagang, tingnan ang kanilang mga babasahin.
//!
//! Kung ang isang iterator adapter panics, ang iterator ay magiging sa isang hindi tinukoy na (pero memory safe) estado.
//! Ang estado na ito ay hindi rin ginagarantiyahan na manatili sa parehong mga bersyon ng Rust, kaya dapat mong iwasan ang pag-asa sa eksaktong halaga na ibinalik ng isang iterator na nagpapanic.
//!
//! [`map`]: Iterator::map
//! [`take`]: Iterator::take
//! [`filter`]: Iterator::filter
//!
//! # Laziness
//!
//! Iterators (at iterator [adapters](#adapters)) Isasama *tamad*. Ito ay nangangahulugan na lamang ng paglikha ng isang iterator ay hindi _do_ isang buong lot. Wala talagang mangyayari hanggang sa tawagan ka [`next`].
//! Ito ay minsan isang source ng kaguluhan kapag lumilikha ng isang iterator para lamang sa mga side effects nito.
//! Halimbawa, ang [`map`] paraan sa mga tawag ng isang pagwawakas sa bawat elemento ng ito iterates sa:
//!
//! ```
//! # #![allow(unused_must_use)]
//! let v = vec![1, 2, 3, 4, 5];
//! v.iter().map(|x| println!("{}", x));
//! ```
//!
//! Hindi ito magpi-print ng anumang mga halaga, dahil lumikha lamang kami ng isang iterator, sa halip na gamitin ito.Babalaan tayo ng tagatala tungkol sa ganitong uri ng pag-uugali:
//!
//! ```text
//! warning: unused result that must be used: iterators are lazy and
//! do nothing unless consumed
//! ```
//!
//! Ang pansalitain paraan upang makapagsulat ng isang [`map`] para sa kanyang mga side effect ay ang paggamit ng isang `for` loop o tumawag sa [`for_each`] pamamaraan:
//!
//! ```
//! let v = vec![1, 2, 3, 4, 5];
//!
//! v.iter().for_each(|x| println!("{}", x));
//! // or
//! for x in &v {
//!     println!("{}", x);
//! }
//! ```
//!
//! [`map`]: Iterator::map
//! [`for_each`]: Iterator::for_each
//!
//! Isa pang mga karaniwang paraan upang suriin ang isang iterator ay ang gamitin ang [`collect`] paraan upang makabuo ng isang bagong koleksyon.
//!
//! [`collect`]: Iterator::collect
//!
//! # Infinity
//!
//! Ang mga Iterator ay hindi dapat maging may hangganan.Bilang isang halimbawa, ang isang bukas na saklaw na saklaw ay isang walang katapusang iterator:
//!
//! ```
//! let numbers = 0..;
//! ```
//!
//! Karaniwan na gamitin ang [`take`] iterator adapter upang gawing isang may hangganan ang isang walang katapusan na iterator:
//!
//! ```
//! let numbers = 0..;
//! let five_numbers = numbers.take(5);
//!
//! for number in five_numbers {
//!     println!("{}", number);
//! }
//! ```
//!
//! Ito ay i-print ang mga numero `0` pamamagitan `4`, ang bawat isa sa kanilang sariling mga linya.
//!
//! Tumungo sa isip na pamamaraan sa walang katapusan na iterators, kahit mga inilaang paggagamitan isang resulta ay maaaring tinutukoy mathematically sa may hangganan ng panahon, hindi maaaring wakasan.
//! Sa partikular, ang mga pamamaraan tulad ng [`min`], na sa pangkalahatang kaso ay nangangailangan ng pagdaan sa bawat elemento sa iterator, ay malamang na hindi matagumpay na makabalik para sa anumang walang katapusan na mga iterator.
//!
//! ```no_run
//! let ones = std::iter::repeat(1);
//! let least = ones.min().unwrap(); // Oh hindi!Isang walang katapusang loop!
//! // `ones.min()` sanhi ng isang walang katapusang loop, kaya hindi namin maaabot ang puntong ito!
//! println!("The smallest number one is {}.", least);
//! ```
//!
//! [`take`]: Iterator::take
//! [`min`]: Iterator::min
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::Iterator;

#[unstable(
    feature = "step_trait",
    reason = "likely to be replaced by finer-grained traits",
    issue = "42168"
)]
pub use self::range::Step;

#[stable(feature = "iter_empty", since = "1.2.0")]
pub use self::sources::{empty, Empty};
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub use self::sources::{from_fn, FromFn};
#[stable(feature = "iter_once", since = "1.2.0")]
pub use self::sources::{once, Once};
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub use self::sources::{once_with, OnceWith};
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::sources::{repeat, Repeat};
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub use self::sources::{repeat_with, RepeatWith};
#[stable(feature = "iter_successors", since = "1.34.0")]
pub use self::sources::{successors, Successors};

#[stable(feature = "fused", since = "1.26.0")]
pub use self::traits::FusedIterator;
#[unstable(issue = "none", feature = "inplace_iteration")]
pub use self::traits::InPlaceIterable;
#[unstable(feature = "trusted_len", issue = "37572")]
pub use self::traits::TrustedLen;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::{
    DoubleEndedIterator, ExactSizeIterator, Extend, FromIterator, IntoIterator, Product, Sum,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::adapters::Cloned;
#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::adapters::Copied;
#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::adapters::Flatten;
#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::adapters::MapWhile;
#[unstable(feature = "inplace_iteration", issue = "none")]
pub use self::adapters::SourceIter;
#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::adapters::StepBy;
#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::adapters::TrustedRandomAccess;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::adapters::{
    Chain, Cycle, Enumerate, Filter, FilterMap, FlatMap, Fuse, Inspect, Map, Peekable, Rev, Scan,
    Skip, SkipWhile, Take, TakeWhile, Zip,
};
#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::adapters::{Intersperse, IntersperseWith};

pub(crate) use self::adapters::process_results;

mod adapters;
mod range;
mod sources;
mod traits;