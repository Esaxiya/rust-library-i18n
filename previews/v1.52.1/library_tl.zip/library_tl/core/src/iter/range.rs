use crate::char;
use crate::convert::TryFrom;
use crate::mem;
use crate::ops::{self, Try};

use super::{FusedIterator, TrustedLen};

/// Mga Bagay na magkaroon ng isang ideya ng *kahalili* at *hinalinhan* operations.
///
/// Ang *kahalili* operasyon gumagalaw patungo sa mga halaga na ihambing ang mas malaki.
/// Ang *hinalinhan* operasyon gumagalaw patungo sa mga halaga na ihambing ang higit na maliit.
///
/// # Safety
///
/// Ang trait na ito ay `unsafe` sapagkat ang pagpapatupad nito ay dapat na tama para sa kaligtasan ng mga pagpapatupad ng `unsafe trait TrustedLen`, at ang mga resulta ng paggamit ng trait na ito ay maaaring mapagtiwalaan ng `unsafe` code na wasto at matupad ang nakalistang mga obligasyon.
///
///
///
#[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
pub unsafe trait Step: Clone + PartialOrd + Sized {
    /// Ibinabalik ang bilang ng *kahalili* hakbang na kinakailangan upang makakuha ng mula sa `start` na `end`.
    ///
    /// Ibinabalik `None` kung ang bilang ng mga hakbang ay pag-apaw `usize` (o ay walang hanggan, o kung `end` ay hindi kailanman maabot).
    ///
    ///
    /// # Invariants
    ///
    /// Para sa anumang `a`, `b`, at `n`:
    ///
    /// * `steps_between(&a, &b) == Some(n)` kung at lamang kung `Step::forward_checked(&a, n) == Some(b)`
    /// * `steps_between(&a, &b) == Some(n)` kung at kung `Step::backward_checked(&a, n) == Some(a)` lang
    /// * `steps_between(&a, &b) == Some(n)` kung `a <= b` lang
    ///   * Corollary: `steps_between(&a, &b) == Some(0)` kung at lamang kung `a == b`
    ///   * Tandaan na `a <= b` ay _not_ magpahiwatig `steps_between(&a, &b) != None`;
    ///     ito ang kaso kung mangangailangan ito ng higit sa `usize::MAX` mga hakbang upang makapunta sa `b`
    /// * `steps_between(&a, &b) == None` kung `a > b`
    fn steps_between(start: &Self, end: &Self) -> Option<usize>;

    /// Ibinabalik ang halagang makukuha sa pamamagitan ng pagkuha ng *kahalili* ng `self` `count` beses.
    ///
    /// Kung ito ay mapuno ng mga hanay ng mga halaga suportado ng `Self`, nagbabalik `None`.
    ///
    /// # Invariants
    ///
    /// Para sa anumang `a`, `n`, at `m`:
    ///
    /// * `Step::forward_checked(a, n).and_then(|x| Step::forward_checked(x, m)) == Step::forward_checked(a, m).and_then(|x| Step::forward_checked(x, n))`
    ///
    ///
    /// Para sa anumang `a`, `n`, at `m` kung saan ang `n + m` ay hindi umaapaw:
    ///
    /// * `Step::forward_checked(a, n).and_then(|x| Step::forward_checked(x, m)) == Step::forward_checked(a, n + m)`
    ///
    /// Para sa anumang mga `a` at `n`:
    ///
    /// * `Step::forward_checked(a, n) == (0..n).try_fold(a, |x, _| Step::forward_checked(&x, 1))`
    ///   * Corollary: `Step::forward_checked(&a, 0) == Some(a)`
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn forward_checked(start: Self, count: usize) -> Option<Self>;

    /// Ibinabalik ang halagang makukuha sa pamamagitan ng pagkuha ng *kahalili* ng `self` `count` beses.
    ///
    /// Kung ito ay mapuno ng mga hanay ng mga halaga suportado ng `Self`, function na ito ay pinahihintulutang panic, wrap, o mababad.
    ///
    /// Ang iminungkahing pag-uugali ay upang panic kapag debug asersyon ay pinagana, at i-wrap o ibabad kung hindi man.
    ///
    /// Ang hindi ligtas na code ay hindi dapat umasa sa kawastuhan ng pag-uugali pagkatapos ng overflow.
    ///
    /// # Invariants
    ///
    /// Para sa anumang `a`, `n`, at `m`, kung saan walang overflow na nangyayari:
    ///
    /// * `Step::forward(Step::forward(a, n), m) == Step::forward(a, n + m)`
    ///
    /// Para sa anumang mga `a` at `n`, kung saan walang overflow nangyayari:
    ///
    /// * `Step::forward_checked(a, n) == Some(Step::forward(a, n))`
    /// * `Step::forward(a, n) == (0..n).fold(a, |x, _| Step::forward(x, 1))`
    ///   * Corollary: `Step::forward(a, 0) == a`
    /// * `Step::forward(a, n) >= a`
    /// * `Step::backward(Step::forward(a, n), n) == a`
    ///
    ///
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn forward(start: Self, count: usize) -> Self {
        Step::forward_checked(start, count).expect("overflow in `Step::forward`")
    }

    /// Ibinabalik ang halagang makukuha sa pamamagitan ng pagkuha ng *kahalili* ng `self` `count` beses.
    ///
    /// # Safety
    ///
    /// Ito ay hindi natukoy na pag-uugali para ang operasyon na ito sa pag-apaw ng hanay ng mga halaga suportado ng `Self`.
    /// Kung hindi mo magagarantiya na ito ay hindi overflow, gamitin `forward` o `forward_checked` sa halip.
    ///
    /// # Invariants
    ///
    /// Para sa anumang mga `a`:
    ///
    /// * kung may umiiral na `b` tulad na `b > a`, ito ay ligtas na tumawag `Step::forward_unchecked(a, 1)`
    /// * kung mayroong `b`, `n` tulad ng `steps_between(&a, &b) == Some(n)`, ligtas na tawagan ang `Step::forward_unchecked(a, m)` para sa anumang `m <= n`.
    ///
    ///
    /// Para sa anumang mga `a` at `n`, kung saan walang overflow nangyayari:
    ///
    /// * `Step::forward_unchecked(a, n)` ay katumbas ng `Step::forward(a, n)`
    ///
    ///
    #[unstable(feature = "unchecked_math", reason = "niche optimization path", issue = "none")]
    unsafe fn forward_unchecked(start: Self, count: usize) -> Self {
        Step::forward(start, count)
    }

    /// Ibinabalik ang halaga na maaaring makuha sa pamamagitan ng pagkuha ang *hinalinhan* ng `self` `count` ulit.
    ///
    /// Kung ito ay mapuno ng mga hanay ng mga halaga suportado ng `Self`, nagbabalik `None`.
    ///
    /// # Invariants
    ///
    /// Para sa anumang `a`, `n`, at `m`:
    ///
    /// * `Step::backward_checked(a, n).and_then(|x| Step::backward_checked(x, m)) == n.checked_add(m).and_then(|x| Step::backward_checked(a, x))`
    ///
    /// * `Step::backward_checked(a, n).and_then(|x| Step::backward_checked(x, m)) == try { Step::backward_checked(a, n.checked_add(m)?) }`
    ///
    /// Para sa anumang mga `a` at `n`:
    ///
    /// * `Step::backward_checked(a, n) == (0..n).try_fold(a, |x, _| Step::backward_checked(&x, 1))`
    ///   * Corollary: `Step::backward_checked(&a, 0) == Some(a)`
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn backward_checked(start: Self, count: usize) -> Option<Self>;

    /// Ibinabalik ang halaga na maaaring makuha sa pamamagitan ng pagkuha ang *hinalinhan* ng `self` `count` ulit.
    ///
    /// Kung ito ay mapuno ng mga hanay ng mga halaga suportado ng `Self`, function na ito ay pinahihintulutang panic, wrap, o mababad.
    ///
    /// Ang iminungkahing pag-uugali ay upang panic kapag debug asersyon ay pinagana, at i-wrap o ibabad kung hindi man.
    ///
    /// Ang hindi ligtas na code ay hindi dapat umasa sa kawastuhan ng pag-uugali pagkatapos ng overflow.
    ///
    /// # Invariants
    ///
    /// Para sa anumang `a`, `n`, at `m`, kung saan walang overflow na nangyayari:
    ///
    /// * `Step::backward(Step::backward(a, n), m) == Step::backward(a, n + m)`
    ///
    /// Para sa anumang mga `a` at `n`, kung saan walang overflow nangyayari:
    ///
    /// * `Step::backward_checked(a, n) == Some(Step::backward(a, n))`
    /// * `Step::backward(a, n) == (0..n).fold(a, |x, _| Step::backward(x, 1))`
    ///   * Corollary: `Step::backward(a, 0) == a`
    /// * `Step::backward(a, n) <= a`
    /// * `Step::forward(Step::backward(a, n), n) == a`
    ///
    ///
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn backward(start: Self, count: usize) -> Self {
        Step::backward_checked(start, count).expect("overflow in `Step::backward`")
    }

    /// Ibinabalik ang halaga na maaaring makuha sa pamamagitan ng pagkuha ang *hinalinhan* ng `self` `count` ulit.
    ///
    /// # Safety
    ///
    /// Ito ay hindi natukoy na pag-uugali para ang operasyon na ito sa pag-apaw ng hanay ng mga halaga suportado ng `Self`.
    /// Kung hindi mo magagarantiya na ito ay hindi overflow, gamitin `backward` o `backward_checked` sa halip.
    ///
    /// # Invariants
    ///
    /// Para sa anumang mga `a`:
    ///
    /// * kung mayroong `b` tulad ng `b < a`, ligtas na tawagan ang `Step::backward_unchecked(a, 1)`
    /// * kung may umiiral na `b`, `n` tulad na `steps_between(&b, &a) == Some(n)`, ito ay ligtas na tumawag `Step::backward_unchecked(a, m)` para sa anumang `m <= n`.
    ///
    ///
    /// Para sa anumang mga `a` at `n`, kung saan walang overflow nangyayari:
    ///
    /// * `Step::backward_unchecked(a, n)` ay katumbas ng `Step::backward(a, n)`
    ///
    ///
    #[unstable(feature = "unchecked_math", reason = "niche optimization path", issue = "none")]
    unsafe fn backward_unchecked(start: Self, count: usize) -> Self {
        Step::backward(start, count)
    }
}

// Ang mga ito ay macro-generated dahil ang integer literals malutas sa iba't ibang uri pa rin.
macro_rules! step_identical_methods {
    () => {
        #[inline]
        unsafe fn forward_unchecked(start: Self, n: usize) -> Self {
            // KALIGTASAN: kailangang igagarantiya ng tumatawag na ang `start + n` ay hindi umaapaw.
            unsafe { start.unchecked_add(n as Self) }
        }

        #[inline]
        unsafe fn backward_unchecked(start: Self, n: usize) -> Self {
            // KALIGTASAN: ang tumatawag ay upang garantiya na `start - n` ay hindi overflow.
            unsafe { start.unchecked_sub(n as Self) }
        }

        #[inline]
        #[allow(arithmetic_overflow)]
        #[rustc_inherit_overflow_checks]
        fn forward(start: Self, n: usize) -> Self {
            // Sa debug build, palitawin ang isang panic sa overflow.
            // Dapat itong ganap na mag-optimize sa mga pagbuo ng paglabas.
            if Self::forward_checked(start, n).is_none() {
                let _ = Self::MAX + 1;
            }
            // Gawin ang pambalot na matematika upang payagan ang hal `Step::forward(-128i8, 255)`.
            start.wrapping_add(n as Self)
        }

        #[inline]
        #[allow(arithmetic_overflow)]
        #[rustc_inherit_overflow_checks]
        fn backward(start: Self, n: usize) -> Self {
            // Sa debug build, palitawin ang isang panic sa overflow.
            // Dapat itong ganap na mag-optimize sa mga pagbuo ng paglabas.
            if Self::backward_checked(start, n).is_none() {
                let _ = Self::MIN - 1;
            }
            // Gawin ang pambalot na matematika upang payagan ang hal `Step::backward(127i8, 255)`.
            start.wrapping_sub(n as Self)
        }
    };
}

macro_rules! step_integer_impls {
    {
        narrower than or same width as usize:
            $( [ $u_narrower:ident $i_narrower:ident ] ),+;
        wider than usize:
            $( [ $u_wider:ident $i_wider:ident ] ),+;
    } => {
        $(
            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $u_narrower {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        // Ito ay umaasa sa $u_narrower <=usize
                        Some((*end - *start) as usize)
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    match Self::try_from(n) {
                        Ok(n) => start.checked_add(n),
                        Err(_) => None, // kung ang n ay wala sa saklaw, ang `unsigned_start + n` din
                    }
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    match Self::try_from(n) {
                        Ok(n) => start.checked_sub(n),
                        Err(_) => None, // kung ang n ay wala sa saklaw, ang `unsigned_start - n` din
                    }
                }
            }

            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $i_narrower {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        // Ito ay umaasa sa $i_narrower <=usize
                        //
                        // Ang pag-cast sa isize ay nagpapalawak ng lapad ngunit pinapanatili ang pag-sign.
                        // Gamitin wrapping_sub in isize space at cast sa usize upang kalkulahin ang mga pagkakaiba na maaaring hindi magkasya sa loob ng hanay ng mga isize.
                        //
                        Some((*end as isize).wrapping_sub(*start as isize) as usize)
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    match $u_narrower::try_from(n) {
                        Ok(n) => {
                            // Hinahawak ng pambalot ang mga kaso tulad ng `Step::forward(-120_i8, 200) == Some(80_i8)`, kahit na ang 200 ay wala sa saklaw para sa i8.
                            //
                            //
                            let wrapped = start.wrapping_add(n as Self);
                            if wrapped >= start {
                                Some(wrapped)
                            } else {
                                None // Umapaw ang karagdagan
                            }
                        }
                        // Kung ang n ay wala sa saklaw ng hal
                        // u8, pagkatapos ito ay mas malaki kaysa sa buong hanay ng i8 ay malawak kaya `any_i8 + n` kinakailangang overflows i8.
                        //
                        Err(_) => None,
                    }
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    match $u_narrower::try_from(n) {
                        Ok(n) => {
                            // Hinahawak ng pambalot ang mga kaso tulad ng `Step::forward(-120_i8, 200) == Some(80_i8)`, kahit na ang 200 ay wala sa saklaw para sa i8.
                            //
                            //
                            let wrapped = start.wrapping_sub(n as Self);
                            if wrapped <= start {
                                Some(wrapped)
                            } else {
                                None // Umapaw ang pagbabawas
                            }
                        }
                        // Kung ang n ay wala sa saklaw ng hal
                        // u8, pagkatapos ito ay mas malaki kaysa sa buong hanay ng i8 ay malawak kaya `any_i8 - n` kinakailangang overflows i8.
                        //
                        Err(_) => None,
                    }
                }
            }
        )+

        $(
            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $u_wider {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        usize::try_from(*end - *start).ok()
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_add(n as Self)
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_sub(n as Self)
                }
            }

            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $i_wider {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        match end.checked_sub(*start) {
                            Some(result) => usize::try_from(result).ok(),
                            // Kung ang pagkakaiba ay masyadong malaki para sa hal
                            // i128, ito ay magiging masyadong malaki para sa usize na may mas kaunting mga piraso.
                            None => None,
                        }
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_add(n as Self)
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_sub(n as Self)
                }
            }
        )+
    };
}

#[cfg(target_pointer_width = "64")]
step_integer_impls! {
    narrower than or same width as usize: [u8 i8], [u16 i16], [u32 i32], [u64 i64], [usize isize];
    wider than usize: [u128 i128];
}

#[cfg(target_pointer_width = "32")]
step_integer_impls! {
    narrower than or same width as usize: [u8 i8], [u16 i16], [u32 i32], [usize isize];
    wider than usize: [u64 i64], [u128 i128];
}

#[cfg(target_pointer_width = "16")]
step_integer_impls! {
    narrower than or same width as usize: [u8 i8], [u16 i16], [usize isize];
    wider than usize: [u32 i32], [u64 i64], [u128 i128];
}

#[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
unsafe impl Step for char {
    #[inline]
    fn steps_between(&start: &char, &end: &char) -> Option<usize> {
        let start = start as u32;
        let end = end as u32;
        if start <= end {
            let count = end - start;
            if start < 0xD800 && 0xE000 <= end {
                usize::try_from(count - 0x800).ok()
            } else {
                usize::try_from(count).ok()
            }
        } else {
            None
        }
    }

    #[inline]
    fn forward_checked(start: char, count: usize) -> Option<char> {
        let start = start as u32;
        let mut res = Step::forward_checked(start, count)?;
        if start < 0xD800 && 0xD800 <= res {
            res = Step::forward_checked(res, 0x800)?;
        }
        if res <= char::MAX as u32 {
            // KALIGTASAN: res ay isang wastong unicode skeilar
            // (sa ibaba 0x110000 at hindi sa 0xD800..0xE000)
            Some(unsafe { char::from_u32_unchecked(res) })
        } else {
            None
        }
    }

    #[inline]
    fn backward_checked(start: char, count: usize) -> Option<char> {
        let start = start as u32;
        let mut res = Step::backward_checked(start, count)?;
        if start >= 0xE000 && 0xE000 > res {
            res = Step::backward_checked(res, 0x800)?;
        }
        // KALIGTASAN: res ay isang wastong unicode skeilar
        // (sa ibaba 0x110000 at hindi sa 0xD800..0xE000)
        Some(unsafe { char::from_u32_unchecked(res) })
    }

    #[inline]
    unsafe fn forward_unchecked(start: char, count: usize) -> char {
        let start = start as u32;
        // KALIGTASAN: ang tumatawag ay dapat garantiya na hindi ito ang ginagawa overflow
        // ang hanay ng mga halaga para sa isang char.
        let mut res = unsafe { Step::forward_unchecked(start, count) };
        if start < 0xD800 && 0xD800 <= res {
            // KALIGTASAN: ang tumatawag ay dapat garantiya na hindi ito ang ginagawa overflow
            // ang hanay ng mga halaga para sa isang char.
            res = unsafe { Step::forward_unchecked(res, 0x800) };
        }
        // KALIGTASAN: dahil sa mga nakaraang kontrata, ito ay garantisadong
        // ng tumatawag upang maging isang wastong char.
        unsafe { char::from_u32_unchecked(res) }
    }

    #[inline]
    unsafe fn backward_unchecked(start: char, count: usize) -> char {
        let start = start as u32;
        // KALIGTASAN: ang tumatawag ay dapat garantiya na hindi ito ang ginagawa overflow
        // ang hanay ng mga halaga para sa isang char.
        let mut res = unsafe { Step::backward_unchecked(start, count) };
        if start >= 0xE000 && 0xE000 > res {
            // KALIGTASAN: ang tumatawag ay dapat garantiya na hindi ito ang ginagawa overflow
            // ang hanay ng mga halaga para sa isang char.
            res = unsafe { Step::backward_unchecked(res, 0x800) };
        }
        // KALIGTASAN: dahil sa mga nakaraang kontrata, ito ay garantisadong
        // ng tumatawag upang maging isang wastong char.
        unsafe { char::from_u32_unchecked(res) }
    }
}

macro_rules! range_exact_iter_impl {
    ($($t:ty)*) => ($(
        #[stable(feature = "rust1", since = "1.0.0")]
        impl ExactSizeIterator for ops::Range<$t> { }
    )*)
}

macro_rules! range_incl_exact_iter_impl {
    ($($t:ty)*) => ($(
        #[stable(feature = "inclusive_range", since = "1.26.0")]
        impl ExactSizeIterator for ops::RangeInclusive<$t> { }
    )*)
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Step> Iterator for ops::Range<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        if self.start < self.end {
            // KALIGTASAN: naka-check lang sa precondition
            let n = unsafe { Step::forward_unchecked(self.start.clone(), 1) };
            Some(mem::replace(&mut self.start, n))
        } else {
            None
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.start < self.end {
            let hint = Step::steps_between(&self.start, &self.end);
            (hint.unwrap_or(usize::MAX), hint)
        } else {
            (0, Some(0))
        }
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<A> {
        if let Some(plus_n) = Step::forward_checked(self.start.clone(), n) {
            if plus_n < self.end {
                // KALIGTASAN: naka-check lang sa precondition
                self.start = unsafe { Step::forward_unchecked(plus_n.clone(), 1) };
                return Some(plus_n);
            }
        }

        self.start = self.end.clone();
        None
    }

    #[inline]
    fn last(mut self) -> Option<A> {
        self.next_back()
    }

    #[inline]
    fn min(mut self) -> Option<A> {
        self.next()
    }

    #[inline]
    fn max(mut self) -> Option<A> {
        self.next_back()
    }
}

// Ang mga macros bumuo `ExactSizeIterator` impls para sa iba't ibang uri range.
//
// * `ExactSizeIterator::len` ay kinakailangan upang palaging ibalik ang isang eksaktong `usize`, kaya walang saklaw na maaaring mas mahaba sa `usize::MAX`.
//
// * Para sa mga uri ng integer sa `Range<_>` ito ang kaso para sa mga uri makitid kaysa sa o bilang malawak na bilang `usize`.
//   Para sa mga uri ng integer sa `RangeInclusive<_>` ito ang kaso para sa mga uri *mahigpit na mas makitid* kaysa sa `usize` mula hal
//   `(0..=u64::MAX).len()` ay magiging `u64::MAX + 1`.
//
range_exact_iter_impl! {
    usize u8 u16
    isize i8 i16

    // Ang mga ito ay incorect per pagdadahilan sa itaas, ngunit sila tanggalin magiging isang paglabag sa pagbabago habang sila ay nagpapatatag sa Rust 1.0.0.
    // kaya eg
    // `(0..66_000_u32).len()` halimbawa ay sumulat ng libro nang walang error o babala sa 16-bit platform, ngunit patuloy na magbigay ng isang maling resulta.
    //
    u32
    i32
}
range_incl_exact_iter_impl! {
    u8
    i8

    // Ang mga ito ay incorect per pagdadahilan sa itaas, ngunit sila tanggalin magiging isang paglabag sa pagbabago habang sila ay nagpapatatag sa Rust 1.26.0.
    // kaya eg
    // `(0..=u16::MAX).len()` halimbawa ay sumulat ng libro nang walang error o babala sa 16-bit platform, ngunit patuloy na magbigay ng isang maling resulta.
    //
    u16
    i16
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Step> DoubleEndedIterator for ops::Range<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        if self.start < self.end {
            // KALIGTASAN: naka-check lang sa precondition
            self.end = unsafe { Step::backward_unchecked(self.end.clone(), 1) };
            Some(self.end.clone())
        } else {
            None
        }
    }

    #[inline]
    fn nth_back(&mut self, n: usize) -> Option<A> {
        if let Some(minus_n) = Step::backward_checked(self.end.clone(), n) {
            if minus_n > self.start {
                // KALIGTASAN: naka-check lang sa precondition
                self.end = unsafe { Step::backward_unchecked(minus_n, 1) };
                return Some(self.end.clone());
            }
        }

        self.end = self.start.clone();
        None
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Step> TrustedLen for ops::Range<A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Step> FusedIterator for ops::Range<A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Step> Iterator for ops::RangeFrom<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        let n = Step::forward(self.start.clone(), 1);
        Some(mem::replace(&mut self.start, n))
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<A> {
        let plus_n = Step::forward(self.start.clone(), n);
        self.start = Step::forward(plus_n.clone(), 1);
        Some(plus_n)
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Step> FusedIterator for ops::RangeFrom<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Step> TrustedLen for ops::RangeFrom<A> {}

#[stable(feature = "inclusive_range", since = "1.26.0")]
impl<A: Step> Iterator for ops::RangeInclusive<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        if self.is_empty() {
            return None;
        }
        let is_iterating = self.start < self.end;
        Some(if is_iterating {
            // KALIGTASAN: naka-check lang sa precondition
            let n = unsafe { Step::forward_unchecked(self.start.clone(), 1) };
            mem::replace(&mut self.start, n)
        } else {
            self.exhausted = true;
            self.start.clone()
        })
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.is_empty() {
            return (0, Some(0));
        }

        match Step::steps_between(&self.start, &self.end) {
            Some(hint) => (hint.saturating_add(1), hint.checked_add(1)),
            None => (usize::MAX, None),
        }
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<A> {
        if self.is_empty() {
            return None;
        }

        if let Some(plus_n) = Step::forward_checked(self.start.clone(), n) {
            use crate::cmp::Ordering::*;

            match plus_n.partial_cmp(&self.end) {
                Some(Less) => {
                    self.start = Step::forward(plus_n.clone(), 1);
                    return Some(plus_n);
                }
                Some(Equal) => {
                    self.start = plus_n.clone();
                    self.exhausted = true;
                    return Some(plus_n);
                }
                _ => {}
            }
        }

        self.start = self.end.clone();
        self.exhausted = true;
        None
    }

    #[inline]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        if self.is_empty() {
            return try { init };
        }

        let mut accum = init;

        while self.start < self.end {
            // KALIGTASAN: naka-check lang sa precondition
            let n = unsafe { Step::forward_unchecked(self.start.clone(), 1) };
            let n = mem::replace(&mut self.start, n);
            accum = f(accum, n)?;
        }

        self.exhausted = true;

        if self.start == self.end {
            accum = f(accum, self.start.clone())?;
        }

        try { accum }
    }

    #[inline]
    fn fold<B, F>(mut self, init: B, f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_fold(init, ok(f)).unwrap()
    }

    #[inline]
    fn last(mut self) -> Option<A> {
        self.next_back()
    }

    #[inline]
    fn min(mut self) -> Option<A> {
        self.next()
    }

    #[inline]
    fn max(mut self) -> Option<A> {
        self.next_back()
    }
}

#[stable(feature = "inclusive_range", since = "1.26.0")]
impl<A: Step> DoubleEndedIterator for ops::RangeInclusive<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        if self.is_empty() {
            return None;
        }
        let is_iterating = self.start < self.end;
        Some(if is_iterating {
            // KALIGTASAN: naka-check lang sa precondition
            let n = unsafe { Step::backward_unchecked(self.end.clone(), 1) };
            mem::replace(&mut self.end, n)
        } else {
            self.exhausted = true;
            self.end.clone()
        })
    }

    #[inline]
    fn nth_back(&mut self, n: usize) -> Option<A> {
        if self.is_empty() {
            return None;
        }

        if let Some(minus_n) = Step::backward_checked(self.end.clone(), n) {
            use crate::cmp::Ordering::*;

            match minus_n.partial_cmp(&self.start) {
                Some(Greater) => {
                    self.end = Step::backward(minus_n.clone(), 1);
                    return Some(minus_n);
                }
                Some(Equal) => {
                    self.end = minus_n.clone();
                    self.exhausted = true;
                    return Some(minus_n);
                }
                _ => {}
            }
        }

        self.end = self.start.clone();
        self.exhausted = true;
        None
    }

    #[inline]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        if self.is_empty() {
            return try { init };
        }

        let mut accum = init;

        while self.start < self.end {
            // KALIGTASAN: naka-check lang sa precondition
            let n = unsafe { Step::backward_unchecked(self.end.clone(), 1) };
            let n = mem::replace(&mut self.end, n);
            accum = f(accum, n)?;
        }

        self.exhausted = true;

        if self.start == self.end {
            accum = f(accum, self.start.clone())?;
        }

        try { accum }
    }

    #[inline]
    fn rfold<B, F>(mut self, init: B, f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_rfold(init, ok(f)).unwrap()
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Step> TrustedLen for ops::RangeInclusive<A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Step> FusedIterator for ops::RangeInclusive<A> {}