use crate::iter;
use crate::num::Wrapping;

/// Trait upang kumatawan uri na maaaring malikha sa pamamagitan ng lagom up ng isang iterator.
///
/// Ang trait na ito ay ginagamit upang ipatupad ang [`sum()`] na pamamaraan sa mga iterator.
/// Ang mga uri na nagpapatupad ng trait ay maaaring mabuo ng pamamaraang [`sum()`].
/// Tulad ng [`FromIterator`] ang trait na ito ay dapat na bihirang tawagan nang direkta at sa halip ay nakipag-ugnay sa pamamagitan ng [`Iterator::sum()`].
///
///
/// [`sum()`]: Sum::sum
/// [`FromIterator`]: iter::FromIterator
#[stable(feature = "iter_arith_traits", since = "1.12.0")]
pub trait Sum<A = Self>: Sized {
    /// Pamamaraan na kumukuha ng isang iterator at bumubuo `Self` mula sa mga elemento sa pamamagitan "summing up" ang mga item.
    ///
    #[stable(feature = "iter_arith_traits", since = "1.12.0")]
    fn sum<I: Iterator<Item = A>>(iter: I) -> Self;
}

/// Trait upang kumatawan uri na maaaring malikha sa pamamagitan ng pag-multiply elemento ng isang iterator.
///
/// trait ito ay ginagamit upang ipatupad ang [`product()`] Ang pamamaraan sa iterators.
/// Uri na ipatupad ang trait ay maaaring binuo sa pamamagitan ng [`product()`] paraan.
/// Tulad [`FromIterator`] ito trait dapat madalang na tinatawag na direkta at sa halip nakipag-ugnayan sa pamamagitan ng [`Iterator::product()`].
///
///
/// [`product()`]: Product::product
/// [`FromIterator`]: iter::FromIterator
///
#[stable(feature = "iter_arith_traits", since = "1.12.0")]
pub trait Product<A = Self>: Sized {
    /// Pamamaraan na kumukuha ng isang iterator at bumubuo `Self` mula sa mga elemento sa pamamagitan ng pag-multiply ng mga item.
    ///
    #[stable(feature = "iter_arith_traits", since = "1.12.0")]
    fn product<I: Iterator<Item = A>>(iter: I) -> Self;
}

macro_rules! integer_sum_product {
    (@impls $zero:expr, $one:expr, #[$attr:meta], $($a:ty)*) => ($(
        #[$attr]
        impl Sum for $a {
            fn sum<I: Iterator<Item=Self>>(iter: I) -> Self {
                iter.fold(
                    $zero,
                    #[rustc_inherit_overflow_checks]
                    |a, b| a + b,
                )
            }
        }

        #[$attr]
        impl Product for $a {
            fn product<I: Iterator<Item=Self>>(iter: I) -> Self {
                iter.fold(
                    $one,
                    #[rustc_inherit_overflow_checks]
                    |a, b| a * b,
                )
            }
        }

        #[$attr]
        impl<'a> Sum<&'a $a> for $a {
            fn sum<I: Iterator<Item=&'a Self>>(iter: I) -> Self {
                iter.fold(
                    $zero,
                    #[rustc_inherit_overflow_checks]
                    |a, b| a + b,
                )
            }
        }

        #[$attr]
        impl<'a> Product<&'a $a> for $a {
            fn product<I: Iterator<Item=&'a Self>>(iter: I) -> Self {
                iter.fold(
                    $one,
                    #[rustc_inherit_overflow_checks]
                    |a, b| a * b,
                )
            }
        }
    )*);
    ($($a:ty)*) => (
        integer_sum_product!(@impls 0, 1,
                #[stable(feature = "iter_arith_traits", since = "1.12.0")],
                $($a)*);
        integer_sum_product!(@impls Wrapping(0), Wrapping(1),
                #[stable(feature = "wrapping_iter_arith", since = "1.14.0")],
                $(Wrapping<$a>)*);
    );
}

macro_rules! float_sum_product {
    ($($a:ident)*) => ($(
        #[stable(feature = "iter_arith_traits", since = "1.12.0")]
        impl Sum for $a {
            fn sum<I: Iterator<Item=Self>>(iter: I) -> Self {
                iter.fold(
                    0.0,
                    #[rustc_inherit_overflow_checks]
                    |a, b| a + b,
                )
            }
        }

        #[stable(feature = "iter_arith_traits", since = "1.12.0")]
        impl Product for $a {
            fn product<I: Iterator<Item=Self>>(iter: I) -> Self {
                iter.fold(
                    1.0,
                    #[rustc_inherit_overflow_checks]
                    |a, b| a * b,
                )
            }
        }

        #[stable(feature = "iter_arith_traits", since = "1.12.0")]
        impl<'a> Sum<&'a $a> for $a {
            fn sum<I: Iterator<Item=&'a Self>>(iter: I) -> Self {
                iter.fold(
                    0.0,
                    #[rustc_inherit_overflow_checks]
                    |a, b| a + b,
                )
            }
        }

        #[stable(feature = "iter_arith_traits", since = "1.12.0")]
        impl<'a> Product<&'a $a> for $a {
            fn product<I: Iterator<Item=&'a Self>>(iter: I) -> Self {
                iter.fold(
                    1.0,
                    #[rustc_inherit_overflow_checks]
                    |a, b| a * b,
                )
            }
        }
    )*)
}

integer_sum_product! { i8 i16 i32 i64 i128 isize u8 u16 u32 u64 u128 usize }
float_sum_product! { f32 f64 }

#[stable(feature = "iter_arith_traits_result", since = "1.16.0")]
impl<T, U, E> Sum<Result<U, E>> for Result<T, E>
where
    T: Sum<U>,
{
    /// Dadalhin bawat elemento sa [`Iterator`]: kung ito ay isang [`Err`], walang karagdagang mga elemento ay kinuha, at ang [`Err`] ay ibinalik.
    /// Hindi dapat maganap ang [`Err`], ibinalik ang kabuuan ng lahat ng mga elemento.
    ///
    /// # Examples
    ///
    /// Ito ang sumsumula sa bawat integer sa isang vector, tinatanggihan ang kabuuan kung ang isang negatibong elemento ay nakatagpo:
    ///
    /// ```
    /// let v = vec![1, 2];
    /// let res: Result<i32, &'static str> = v.iter().map(|&x: &i32|
    ///     if x < 0 { Err("Negative element found") }
    ///     else { Ok(x) }
    /// ).sum();
    /// assert_eq!(res, Ok(3));
    /// ```
    ///
    ///
    fn sum<I>(iter: I) -> Result<T, E>
    where
        I: Iterator<Item = Result<U, E>>,
    {
        iter::process_results(iter, |i| i.sum())
    }
}

#[stable(feature = "iter_arith_traits_result", since = "1.16.0")]
impl<T, U, E> Product<Result<U, E>> for Result<T, E>
where
    T: Product<U>,
{
    /// Dadalhin bawat elemento sa [`Iterator`]: kung ito ay isang [`Err`], walang karagdagang mga elemento ay kinuha, at ang [`Err`] ay ibinalik.
    /// Dapat walang [`Err`] mangyari, ang produkto ng lahat ng mga elemento ay ibinalik.
    ///
    fn product<I>(iter: I) -> Result<T, E>
    where
        I: Iterator<Item = Result<U, E>>,
    {
        iter::process_results(iter, |i| i.product())
    }
}

#[stable(feature = "iter_arith_traits_option", since = "1.37.0")]
impl<T, U> Sum<Option<U>> for Option<T>
where
    T: Sum<U>,
{
    /// Dadalhin bawat elemento sa [`Iterator`]: kung ito ay isang [`None`], walang karagdagang mga elemento ay kinuha, at ang [`None`] ay ibinalik.
    /// Hindi dapat maganap ang [`None`], ibinalik ang kabuuan ng lahat ng mga elemento.
    ///
    /// # Examples
    ///
    /// Ibinubuod nito ang posisyon ng character na 'a' sa isang vector ng mga string, kung ang isang salita ay walang character na 'a' ang operasyon ay nagbabalik ng `None`:
    ///
    ///
    /// ```
    /// let words = vec!["have", "a", "great", "day"];
    /// let total: Option<usize> = words.iter().map(|w| w.find('a')).sum();
    /// assert_eq!(total, Some(5));
    /// ```
    ///
    fn sum<I>(iter: I) -> Option<T>
    where
        I: Iterator<Item = Option<U>>,
    {
        iter.map(|x| x.ok_or(())).sum::<Result<_, _>>().ok()
    }
}

#[stable(feature = "iter_arith_traits_option", since = "1.37.0")]
impl<T, U> Product<Option<U>> for Option<T>
where
    T: Product<U>,
{
    /// Dadalhin bawat elemento sa [`Iterator`]: kung ito ay isang [`None`], walang karagdagang mga elemento ay kinuha, at ang [`None`] ay ibinalik.
    /// Dapat walang [`None`] mangyari, ang produkto ng lahat ng mga elemento ay ibinalik.
    ///
    fn product<I>(iter: I) -> Option<T>
    where
        I: Iterator<Item = Option<U>>,
    {
        iter.map(|x| x.ok_or(())).product::<Result<_, _>>().ok()
    }
}