/// Ang isang iterator na alam nito eksaktong haba.
///
/// Maraming mga [`Iterator`] ang hindi nakakaalam kung gaano karaming beses sila mag-ulit, ngunit ang ilan ay alam.
/// Kung alam ng isang iterator kung gaano karaming beses maaari itong umulit, na nagbibigay ng access sa impormasyon na maaaring maging kapaki-pakinabang.
/// Halimbawa, kung nais mong umulit pabalik, ang isang mahusay na pagsisimula ay malaman kung saan ang wakas.
///
/// Kapag pagpapatupad ng isang `ExactSizeIterator`, dapat mo ring ipatupad [`Iterator`].
/// Kapag ginagawa ito, ang pagpapatupad ng [`Iterator::size_hint`]*dapat* ibalik ang eksaktong laki ng iterator.
///
/// Ang [`len`] Ang pamamaraan ay may isang default na pagpapatupad, kaya humahantong ito ay hindi dapat ipatupad ito.
/// Gayunpaman, maaari kang makapagbigay ng isang mas performant na pagpapatupad kaysa sa default, kaya't may katuturan ang pag-override nito sa kasong ito.
///
///
/// Tandaan na ito trait ay isang ligtas na trait at dahil dito ay *hindi* at *Maaari hindi* ginagarantiya na ang ibinalik na haba ay tama.
/// Nangangahulugan ito na ang `unsafe` code **ay hindi dapat** umasa sa kawastuhan ng [`Iterator::size_hint`].
/// Ang hindi matatag at hindi ligtas na [`TrustedLen`](super::marker::TrustedLen) trait ay nagbibigay ng karagdagang garantiyang ito.
///
/// [`len`]: ExactSizeIterator::len
///
/// # Examples
///
/// Pangunahing paggamit:
///
/// ```
/// // ang isang may hangganan na saklaw alam eksakto kung gaano karaming beses na ito ay paulit-ulit
/// let five = 0..5;
///
/// assert_eq!(5, five.len());
/// ```
///
/// Sa [module-level docs], ipinatupad namin ang isang [`Iterator`], `Counter`.
/// Sabihin ipatupad `ExactSizeIterator` para sa mga ito pati na rin:
///
/// [module-level docs]: crate::iter
///
/// ```
/// # struct Counter {
/// #     count: usize,
/// # }
/// # impl Counter {
/// #     fn new() -> Counter {
/// #         Counter { count: 0 }
/// #     }
/// # }
/// # impl Iterator for Counter {
/// #     type Item = usize;
/// #     fn next(&mut self) -> Option<Self::Item> {
/// #         self.count += 1;
/// #         if self.count < 6 {
/// #             Some(self.count)
/// #         } else {
/// #             None
/// #         }
/// #     }
/// # }
/// impl ExactSizeIterator for Counter {
///     // Maaari naming madaling kalkulahin ang natitirang bilang ng mga iteration.
///     fn len(&self) -> usize {
///         5 - self.count
///     }
/// }
///
/// // At ngayon maaari naming gamitin ito!
///
/// let counter = Counter::new();
///
/// assert_eq!(5, counter.len());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ExactSizeIterator: Iterator {
    /// Ibinabalik ang eksaktong haba ng iterator.
    ///
    /// Tinitiyak ng pagpapatupad na ang iterator ay babalik nang eksaktong `len()` nang mas maraming beses sa isang halagang [`Some(T)`], bago ibalik ang [`None`].
    ///
    /// Ang pamamaraang ito ay may isang default na pagpapatupad, kaya karaniwang hindi mo ito ipapatupad nang direkta.
    /// Subalit, kung maaari kang magbigay ng isang mas mahusay na implementasyon, maaari mong gawin ito.
    /// Tingnan ang [trait-level] docs para sa isang halimbawa.
    ///
    /// Ang pagpapaandar na ito ay may parehong mga garantiya sa kaligtasan tulad ng pagpapaandar ng [`Iterator::size_hint`].
    ///
    /// [trait-level]: ExactSizeIterator
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// // ang isang may hangganan na saklaw alam eksakto kung gaano karaming beses na ito ay paulit-ulit
    /// let five = 0..5;
    ///
    /// assert_eq!(5, five.len());
    /// ```
    ///
    ///
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn len(&self) -> usize {
        let (lower, upper) = self.size_hint();
        // Note: Ang pahayag na ito ay labis na nagtatanggol, ngunit sinusuri nito ang invariant
        // garantisadong sa pamamagitan ng trait.
        // Kung ito trait ay rust-panloob, maaari naming gamitin debug_assert !;assert_eq!susuriin din ang lahat ng pagpapatupad ng gumagamit ng Rust din.
        //
        assert_eq!(upper, Some(lower));
        lower
    }

    /// Ibinabalik `true` kung ang iterator ay walang laman.
    ///
    /// Ang pamamaraang ito ay may isang default na pagpapatupad gamit ang [`ExactSizeIterator::len()`], kaya hindi mo kailangang ipatupad ito mismo.
    ///
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// #![feature(exact_size_is_empty)]
    ///
    /// let mut one_element = std::iter::once(0);
    /// assert!(!one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), Some(0));
    /// assert!(one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), None);
    /// ```
    #[inline]
    #[unstable(feature = "exact_size_is_empty", issue = "35428")]
    fn is_empty(&self) -> bool {
        self.len() == 0
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator + ?Sized> ExactSizeIterator for &mut I {
    fn len(&self) -> usize {
        (**self).len()
    }
    fn is_empty(&self) -> bool {
        (**self).is_empty()
    }
}