/// Conversion mula sa isang [`Iterator`].
///
/// Sa pamamagitan ng pagpapatupad `FromIterator` para sa isang uri, tukuyin mo kung paano ito ay maaaring malikha mula sa isang iterator.
/// Karaniwan ito para sa mga uri na naglalarawan ng isang koleksyon ng ilang uri.
///
/// [`FromIterator::from_iter()`] ay bihirang tawaging malinaw, at sa halip ay ginagamit sa pamamagitan ng pamamaraang [`Iterator::collect()`].
///
/// Tingnan ang dokumentasyon ng [`Iterator::collect()`]'s para sa higit pang mga halimbawa.
///
/// Tingnan din: [`IntoIterator`].
///
/// # Examples
///
/// Pangunahing paggamit:
///
/// ```
/// use std::iter::FromIterator;
///
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v = Vec::from_iter(five_fives);
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// Paggamit ng [`Iterator::collect()`] upang implicit na gamitin ang `FromIterator`:
///
/// ```
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v: Vec<i32> = five_fives.collect();
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// Pagpapatupad ng `FromIterator` para sa iyong uri:
///
/// ```
/// use std::iter::FromIterator;
///
/// // Isang sample na koleksyon, iyon ay isang pambalot lamang sa Vec<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Sabihin bigyan ito ng ilang mga pamamaraan upang maaari naming lumikha ng isa at magdagdag ng mga bagay na ito.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // at ipapatupad namin ang FromIterator
/// impl FromIterator<i32> for MyCollection {
///     fn from_iter<I: IntoIterator<Item=i32>>(iter: I) -> Self {
///         let mut c = MyCollection::new();
///
///         for i in iter {
///             c.add(i);
///         }
///
///         c
///     }
/// }
///
/// // Ngayon ay maaari naming gumawa ng isang bagong iterator ...
/// let iter = (0..5).into_iter();
///
/// // ... at gumawa ng isang MyCollection dito
/// let c = MyCollection::from_iter(iter);
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
///
/// // mangolekta din ng mga gawa!
///
/// let iter = (0..5).into_iter();
/// let c: MyCollection = iter.collect();
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "a value of type `{Self}` cannot be built from an iterator \
               over elements of type `{A}`",
    label = "value of type `{Self}` cannot be built from `std::iter::Iterator<Item={A}>`"
)]
pub trait FromIterator<A>: Sized {
    /// Lumilikha ng isang halaga mula sa isang iterator.
    ///
    /// Tingnan ang [module-level documentation] para sa higit pa.
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// use std::iter::FromIterator;
    ///
    /// let five_fives = std::iter::repeat(5).take(5);
    ///
    /// let v = Vec::from_iter(five_fives);
    ///
    /// assert_eq!(v, vec![5, 5, 5, 5, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_iter<T: IntoIterator<Item = A>>(iter: T) -> Self;
}

/// Conversion sa isang [`Iterator`].
///
/// Sa pamamagitan ng pagpapatupad `IntoIterator` para sa isang uri, tukuyin mo kung paano ito ma-convert sa isang iterator.
/// Karaniwan ito para sa mga uri na naglalarawan ng isang koleksyon ng ilang uri.
///
/// Isa na benepisyo ng pagpapatupad ng `IntoIterator` ay na ang uri ng iyong kalooban [work with Rust's `for` loop syntax](crate::iter#for-loops-and-intoiterator).
///
///
/// Tingnan din: [`FromIterator`].
///
/// # Examples
///
/// Pangunahing paggamit:
///
/// ```
/// let v = vec![1, 2, 3];
/// let mut iter = v.into_iter();
///
/// assert_eq!(Some(1), iter.next());
/// assert_eq!(Some(2), iter.next());
/// assert_eq!(Some(3), iter.next());
/// assert_eq!(None, iter.next());
/// ```
/// Pagpapatupad `IntoIterator` para sa iyong uri:
///
/// ```
/// // Isang sample na koleksyon, iyon ay isang pambalot lamang sa Vec<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Sabihin bigyan ito ng ilang mga pamamaraan upang maaari naming lumikha ng isa at magdagdag ng mga bagay na ito.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // at ipapatupad namin ang IntoIterator
/// impl IntoIterator for MyCollection {
///     type Item = i32;
///     type IntoIter = std::vec::IntoIter<Self::Item>;
///
///     fn into_iter(self) -> Self::IntoIter {
///         self.0.into_iter()
///     }
/// }
///
/// // Ngayon ay makakagawa kami ng isang bagong koleksyon ...
/// let mut c = MyCollection::new();
///
/// // ... magdagdag ng ilang mga bagay-bagay na ito ...
/// c.add(0);
/// c.add(1);
/// c.add(2);
///
/// // ... at pagkatapos ay i-on ito sa isang Iterator:
/// for (i, n) in c.into_iter().enumerate() {
///     assert_eq!(i as i32, n);
/// }
/// ```
///
/// Ito ay karaniwan na gamitin `IntoIterator` bilang trait bound.Ito ay nagpapahintulot sa input type koleksyon upang baguhin, kaya hangga't ito ay pa rin ng isang iterator.
/// Ang mga karagdagang hangganan ay maaaring tukuyin sa pamamagitan ng paghihigpit sa
/// `Item`:
///
/// ```rust
/// fn collect_as_strings<T>(collection: T) -> Vec<String>
/// where
///     T: IntoIterator,
///     T::Item: std::fmt::Debug,
/// {
///     collection
///         .into_iter()
///         .map(|item| format!("{:?}", item))
///         .collect()
/// }
/// ```
///
///
#[rustc_diagnostic_item = "IntoIterator"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait IntoIterator {
    /// Ang uri ng mga elemento na paulit-ulit.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// Aling uri ng iterator ang ginagawa natin ito?
    #[stable(feature = "rust1", since = "1.0.0")]
    type IntoIter: Iterator<Item = Self::Item>;

    /// Lumilikha ng isang iterator mula sa isang halaga.
    ///
    /// Tingnan ang [module-level documentation] para sa higit pa.
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    /// let mut iter = v.into_iter();
    ///
    /// assert_eq!(Some(1), iter.next());
    /// assert_eq!(Some(2), iter.next());
    /// assert_eq!(Some(3), iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    #[lang = "into_iter"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into_iter(self) -> Self::IntoIter;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator> IntoIterator for I {
    type Item = I::Item;
    type IntoIter = I;

    fn into_iter(self) -> I {
        self
    }
}

/// Palawakin ang isang koleksyon kasama ang mga nilalaman ng isang iterator.
///
/// Ang mga Iterator ay gumagawa ng isang serye ng mga halaga, at ang mga koleksyon ay maaari ring isipin bilang isang serye ng mga halaga.
/// Ang `Extend` trait ay tulay sa puwang na ito, na nagpapahintulot sa iyo na pahabain ang isang koleksyon sa pamamagitan ng pagsasama ng mga nilalaman ng iterator na iyon.
/// Kapag pagpapalawak ng isang koleksyon sa isang umiiral na key, ang entry na iyon ay na-update o, sa kaso ng mga koleksyon na pahintulutan ang maramihang mga entry na may pantay na mga susi, na entry ay ipinasok.
///
///
/// # Examples
///
/// Pangunahing paggamit:
///
/// ```
/// // Maaari mong pahabain ang isang String na may ilang mga karakter:
/// let mut message = String::from("The first three letters are: ");
///
/// message.extend(&['a', 'b', 'c']);
///
/// assert_eq!("abc", &message[29..32]);
/// ```
///
/// Implementing `Extend`:
///
/// ```
/// // Isang sample na koleksyon, iyon ay isang pambalot lamang sa Vec<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Sabihin bigyan ito ng ilang mga pamamaraan upang maaari naming lumikha ng isa at magdagdag ng mga bagay na ito.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // since MyCollection ay may listahan ng i32s, kami ipatupad Extend para i32
/// impl Extend<i32> for MyCollection {
///
///     // Ito ay isang bit mas simple sa kongkretong i-type ang signature: maaari naming tawagan extend sa anumang bagay na maaaring naka sa isang Iterator na kung saan ay nagbibigay sa amin i32s.
///     // Dahil kailangan namin ng i32 upang mailagay sa MyCollection.
/////
///     fn extend<T: IntoIterator<Item=i32>>(&mut self, iter: T) {
///
///         // Ang pagpapatupad ay napaka-tapat: sa loop sa pamamagitan ng iterator, at add() bawat elemento sa ating sarili.
/////
///         for elem in iter {
///             self.add(elem);
///         }
///     }
/// }
///
/// let mut c = MyCollection::new();
///
/// c.add(5);
/// c.add(6);
/// c.add(7);
///
/// // sabihin i-extend ang aming koleksyon na may tatlong higit pang numero
/// c.extend(vec![1, 2, 3]);
///
/// // nagdagdag kami ng mga sangkap na ito papunta sa dulo
/// assert_eq!("MyCollection([5, 6, 7, 1, 2, 3])", format!("{:?}", c));
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Extend<A> {
    /// Pinapalawak ang isang koleksyon ng mga nilalaman ng isang iterator.
    ///
    /// Bilang na ito ay ang tanging kinakailangang pamamaraan para sa trait, ang [trait-level] docs maglaman ng higit pang mga detalye.
    ///
    ///
    /// [trait-level]: Extend
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// // Maaari mong pahabain ang isang String na may ilang mga karakter:
    /// let mut message = String::from("abc");
    ///
    /// message.extend(['d', 'e', 'f'].iter());
    ///
    /// assert_eq!("abcdef", &message);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn extend<T: IntoIterator<Item = A>>(&mut self, iter: T);

    /// Pinapalawak ang isang koleksyon na may eksaktong isang elemento.
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_one(&mut self, item: A) {
        self.extend(Some(item));
    }

    /// Nakalaan ang kapasidad sa isang koleksyon para sa naibigay na bilang ng mga karagdagang elemento.
    ///
    /// Ang default na pagpapatupad ay walang ginagawa.
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_reserve(&mut self, additional: usize) {
        let _ = additional;
    }
}

#[stable(feature = "extend_for_unit", since = "1.28.0")]
impl Extend<()> for () {
    fn extend<T: IntoIterator<Item = ()>>(&mut self, iter: T) {
        iter.into_iter().for_each(drop)
    }
    fn extend_one(&mut self, _item: ()) {}
}