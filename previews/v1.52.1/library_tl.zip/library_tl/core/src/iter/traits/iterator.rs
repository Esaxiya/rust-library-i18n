// ignore-maglinis-filelength file na ito ay halos eksklusibo binubuo ng mga kahulugan ng `Iterator`.
// Hindi namin ito maaaring hatiin sa maraming mga file.
//

use crate::cmp::{self, Ordering};
use crate::ops::{ControlFlow, Try};

use super::super::TrustedRandomAccess;
use super::super::{Chain, Cloned, Copied, Cycle, Enumerate, Filter, FilterMap, Fuse};
use super::super::{FlatMap, Flatten};
use super::super::{FromIterator, Intersperse, IntersperseWith, Product, Sum, Zip};
use super::super::{
    Inspect, Map, MapWhile, Peekable, Rev, Scan, Skip, SkipWhile, StepBy, Take, TakeWhile,
};

fn _assert_is_object_safe(_: &dyn Iterator<Item = ()>) {}

/// Ang isang interface para sa pagharap sa mga iterators.
///
/// Ito ay ang pangunahing iterator trait.
/// Para sa higit pa tungkol sa konsepto ng iterators pangkalahatang paraan, mangyaring tingnan ang [module-level documentation].
/// Sa partikular, maaaring gusto mong malaman kung paano [implement `Iterator`][impl].
///
/// [module-level documentation]: crate::iter
/// [impl]: crate::iter#implementing-iterator
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    on(
        _Self = "[std::ops::Range<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..end]` is an array of one `Range`; you might have meant to have a `Range` \
                without the brackets: `start..end`"
    ),
    on(
        _Self = "[std::ops::RangeFrom<Idx>; 1]",
        label = "if you meant to iterate from a value onwards, remove the square brackets",
        note = "`[start..]` is an array of one `RangeFrom`; you might have meant to have a \
              `RangeFrom` without the brackets: `start..`, keeping in mind that iterating over an \
              unbounded iterator will run forever unless you `break` or `return` from within the \
              loop"
    ),
    on(
        _Self = "[std::ops::RangeTo<Idx>; 1]",
        label = "if you meant to iterate until a value, remove the square brackets and add a \
                 starting value",
        note = "`[..end]` is an array of one `RangeTo`; you might have meant to have a bounded \
                `Range` without the brackets: `0..end`"
    ),
    on(
        _Self = "[std::ops::RangeInclusive<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..=end]` is an array of one `RangeInclusive`; you might have meant to have a \
              `RangeInclusive` without the brackets: `start..=end`"
    ),
    on(
        _Self = "[std::ops::RangeToInclusive<Idx>; 1]",
        label = "if you meant to iterate until a value (including it), remove the square brackets \
                 and add a starting value",
        note = "`[..=end]` is an array of one `RangeToInclusive`; you might have meant to have a \
                bounded `RangeInclusive` without the brackets: `0..=end`"
    ),
    on(
        _Self = "std::ops::RangeTo<Idx>",
        label = "if you meant to iterate until a value, add a starting value",
        note = "`..end` is a `RangeTo`, which cannot be iterated on; you might have meant to have a \
              bounded `Range`: `0..end`"
    ),
    on(
        _Self = "std::ops::RangeToInclusive<Idx>",
        label = "if you meant to iterate until a value (including it), add a starting value",
        note = "`..=end` is a `RangeToInclusive`, which cannot be iterated on; you might have meant \
              to have a bounded `RangeInclusive`: `0..=end`"
    ),
    on(
        _Self = "&str",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "std::string::String",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "[]",
        label = "borrow the array with `&` or call `.iter()` on it to iterate over it",
        note = "arrays are not iterators, but slices like the following are: `&[1, 2, 3]`"
    ),
    on(
        _Self = "{integral}",
        note = "if you want to iterate between `start` until a value `end`, use the exclusive range \
              syntax `start..end` or the inclusive range syntax `start..=end`"
    ),
    label = "`{Self}` is not an iterator",
    message = "`{Self}` is not an iterator"
)]
#[doc(spotlight)]
#[rustc_diagnostic_item = "Iterator"]
#[must_use = "iterators are lazy and do nothing unless consumed"]
pub trait Iterator {
    /// Ang uri ng mga elemento na paulit-ulit.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// Isusulong ang iterator at ibabalik ang susunod na halaga.
    ///
    /// Ibinabalik ang [`None`] kapag natapos ang pag-ulit.
    /// Indibidwal na pagpapatupad ng iterator ay maaaring pumili upang ipagpatuloy ang pag-ulit, at sa gayon ang pagtawag muli sa `next()` ay maaaring o hindi maaaring magsimula sa muling pagbabalik ng [`Some(Item)`] muli sa ilang mga punto.
    ///
    ///
    /// [`Some(Item)`]: Some
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // Ang isang tawag sa next() nagbabalik ng mga susunod na halaga ...
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    ///
    /// // ... at pagkatapos ay None sandaling ito ay higit sa.
    /// assert_eq!(None, iter.next());
    ///
    /// // Higit pang mga tawag ay maaaring o hindi bumalik `None`.Dito, sila ay palaging ay.
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[lang = "next"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next(&mut self) -> Option<Self::Item>;

    /// Ibinabalik ang hangganan sa natitirang haba ng iterator.
    ///
    /// Sa partikular, `size_hint()` nagbabalik ng isang tuple kung saan ang unang elemento ay ang mas mababang bound, at ang pangalawang elemento ay ang itaas na nakagapos.
    ///
    /// Ang pangalawang kalahati ng tuple na naibalik ay isang ['Pagpipilian`]`<`[`usize`]`> `.
    /// Ang isang [`None`] dito ay nangangahulugang alinman sa walang kilalang itaas na nakatali, o ang itaas na nakatali ay mas malaki kaysa sa [`usize`].
    ///
    /// # pagpapatupad ng mga tala
    ///
    /// Ito ay hindi ipapatupad na ang isang iterator pagpapatupad ay magbubunga ng ipinahayag bilang ng mga elemento.Ang isang buggy iterator ay maaaring magbunga ng mas mababa kaysa sa mas mababang bound o higit pa kaysa sa itaas na nakagapos ng mga elemento.
    ///
    /// `size_hint()` ay lalo na inilaan upang gamitin para sa pag-optimize tulad ng mapagtipid ng espasyo para sa ang mga elemento ng iterator, ngunit hindi dapat pagkatiwalaan sa eg, ligtaan hangganan tseke sa hindi ligtas na code.
    /// Ang isang maling pagpapatupad ng `size_hint()` ay hindi dapat humantong sa mga paglabag sa kaligtasan ng memorya.
    ///
    /// Sinabi nito, ang pagpapatupad ay dapat magbigay ng isang tamang pagtatantya, sapagkat kung hindi man ito ay isang paglabag sa protocol ng trait.
    ///
    /// Ang default na pagpapatupad ay nagbabalik ng `(0,` [`Wala`]`)`na tama para sa anumang iterator.
    ///
    /// [`usize`]: type@usize
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let iter = a.iter();
    ///
    /// assert_eq!((3, Some(3)), iter.size_hint());
    /// ```
    ///
    /// Isang mas kumplikadong halimbawa:
    ///
    /// ```
    /// // Ang pantay na mga numero mula zero hanggang sampu.
    /// let iter = (0..10).filter(|x| x % 2 == 0);
    ///
    /// // Maaari naming umulit mula sa zero sa sampung beses.
    /// // Pag-alam na ito ni limang eksakto ay hindi magiging posible na walang e-execute filter().
    /// assert_eq!((0, Some(10)), iter.size_hint());
    ///
    /// // Magdagdag tayo ng limang higit pang mga numero sa chain()
    /// let iter = (0..10).filter(|x| x % 2 == 0).chain(15..20);
    ///
    /// // ngayon ang parehong hangganan ay nadagdagan ng lima
    /// assert_eq!((5, Some(15)), iter.size_hint());
    /// ```
    ///
    /// Bumabalik `None` para sa isang upper bound:
    ///
    /// ```
    /// // isang walang-katapusang iterator ay walang itaas na nakagapos at ang pinakamataas na posibleng mas mababang bound
    /////
    /// let iter = 0..;
    ///
    /// assert_eq!((usize::MAX, None), iter.size_hint());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }

    /// Naubos ang umuulit, binibilang ang bilang ng mga pag-ulit at ibinabalik ito.
    ///
    /// Ang pamamaraan na ito Tatawagan [`next`] paulit-ulit hanggang [`None`] ay nakatagpo, mga bumabalik na ang bilang ng beses na ito nakita [`Some`].
    /// Tandaan na [`next`] ay tawaging bababa sa isang beses kahit na ang iterator ay walang anumang elemento.
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Overflow na Pag-uugali
    ///
    /// Ang pamamaraan ay hindi gumagawa ng pagguguwardiya laban overflows, kaya bilangin ang mga elemento ng isang iterator na may higit sa [`usize::MAX`] elemento alinman gumagawa ng maling resulta o panics.
    ///
    /// Kung pinagana ang mga assertion ng pag-debug, garantisado ang isang panic.
    ///
    /// # Panics
    ///
    /// Ang pagpapaandar na ito ay maaaring panic kung ang iterator ay may higit sa [`usize::MAX`] na mga elemento.
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().count(), 3);
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().count(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn count(self) -> usize
    where
        Self: Sized,
    {
        self.fold(
            0,
            #[rustc_inherit_overflow_checks]
            |count, _| count + 1,
        )
    }

    /// Naubos ang umuulit, na binabalik ang huling elemento.
    ///
    /// Ang pamamaraan na ito ay pag-aralan ang iterator hanggang sa pagbabalik nito [`None`].
    /// Habang ang paggawa nito, ito mapigil ang subaybayan ng kasalukuyang elemento.
    /// Matapos ibalik ang [`None`], ibabalik ng `last()` ang huling elemento na nakita nito.
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().last(), Some(&3));
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().last(), Some(&5));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn last(self) -> Option<Self::Item>
    where
        Self: Sized,
    {
        #[inline]
        fn some<T>(_: Option<T>, x: T) -> Option<T> {
            Some(x)
        }

        self.fold(None, some)
    }

    /// Isusulong ang iterator ng mga elemento ng `n`.
    ///
    /// Ang pamamaraan na ito ay sabik na skip `n` mga elemento sa pamamagitan ng pagtawag [`next`] hanggang sa `n` beses hanggang [`None`] ay nakatagpo.
    ///
    /// `advance_by(n)` ay babalik [`Ok(())`][Ok] kung ang iterator matagumpay na advances sa pamamagitan `n` elemento, o [`Err(k)`][Err] kung [`None`] ay nakatagpo, kung saan `k` ay ang bilang ng mga elemento ng iterator ay advanced sa pamamagitan ng bago nauubusan ng mga sangkap (ibig sabihin,
    /// ang haba ng iterator).
    /// Tandaan na ang `k` ay palaging mas mababa sa `n`.
    ///
    /// Ang pagtawag sa `advance_by(0)` ay hindi ubusin ang anumang mga elemento at palaging nagbabalik ng [`Ok(())`][Ok].
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_by(2), Ok(()));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.advance_by(0), Ok(()));
    /// assert_eq!(iter.advance_by(100), Err(1)); // lamang `&4` ay nilaktawan
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next().ok_or(i)?;
        }
        Ok(())
    }

    /// Ibinabalik ang `n`th elemento ng iterator.
    ///
    /// Tulad ng karamihan sa mga pagpapatakbo ng pag-index, ang count ay nagsisimula mula sa zero, kaya `nth(0)` nagbalik sa unang halaga, `nth(1)` ang pangalawa, at iba pa.
    ///
    /// Tandaan na ang lahat ng mga naunang elemento, pati na rin ang naibalik na elemento, ay matupok mula sa iterator.
    /// Nangangahulugan iyon na ang mga naunang elemento ay itatapon, at ang pagtawag sa `nth(0)` ng maraming beses sa parehong iterator ay magbabalik ng iba't ibang mga elemento.
    ///
    ///
    /// `nth()` ay babalik [`None`] kung `n` ay mas malaki kaysa sa o katumbas ng haba ng iterator.
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(1), Some(&2));
    /// ```
    ///
    /// Ang pagtawag sa `nth()` ng maraming beses ay hindi ire-rewind ang iterator:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth(1), Some(&2));
    /// assert_eq!(iter.nth(1), None);
    /// ```
    ///
    /// Pagbabalik ng `None` kung mayroong mas mababa sa `n + 1` na mga elemento:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(10), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_by(n).ok()?;
        self.next()
    }

    /// Lumilikha ng isang umuulit na nagsisimula sa parehong punto, ngunit hakbang sa pamamagitan ng ibinigay na halaga sa bawat pag-ulit.
    ///
    /// Tandaan 1: Ang unang elemento ng iterator ay palaging ibabalik, hindi alintana ang ibinigay na hakbang.
    ///
    /// Tandaan 2: Ang panahon kung papansinin elemento ay nakuha ay hindi maayos.
    /// `StepBy` behaves tulad ng ang pagkakasunod-sunod `next(), nth(step-1), nth(step-1),…`, ngunit ito ay libre rin upang kumilos tulad ng ang pagkakasunod-sunod
    ///
    /// `advance_n_and_return_first(step), advance_n_and_return_first(step), …`
    /// Aling paraan ay ginagamit ay maaaring magbago para sa ilang mga iterators para sa mga dahilan ng pagganap.
    /// Ang pangalawang paraan ay isusulong ang iterator nang mas maaga at maaaring ubusin ang higit pang mga item.
    ///
    /// `advance_n_and_return_first` ay ang katumbas ng:
    ///
    /// ```
    /// fn advance_n_and_return_first<I>(iter: &mut I, total_step: usize) -> Option<I::Item>
    /// where
    ///     I: Iterator,
    /// {
    ///     let next = iter.next();
    ///     if total_step > 1 {
    ///         iter.nth(total_step-2);
    ///     }
    ///     next
    /// }
    /// ```
    ///
    /// # Panics
    ///
    /// Ang pamamaraan ay panic kung ang ibinigay na hakbang ay `0`.
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// let a = [0, 1, 2, 3, 4, 5];
    /// let mut iter = a.iter().step_by(2);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_step_by", since = "1.28.0")]
    fn step_by(self, step: usize) -> StepBy<Self>
    where
        Self: Sized,
    {
        StepBy::new(self, step)
    }

    /// Tumatagal ng dalawang iterator at lumilikha ng isang bagong iterator sa pareho sa pagkakasunud-sunod.
    ///
    /// `chain()` ay magbabalik ng isang bagong iterator na kung saan ay unang umulit sa paglipas ng mga halaga mula sa unang iterator at pagkatapos ay sa paglipas ng mga halaga mula sa ikalawang iterator.
    ///
    /// Sa madaling salita, nag-uugnay ito ng dalawang iterator nang magkasama, sa isang kadena.🔗
    ///
    /// [`once`] ay karaniwang ginagamit upang umangkop sa isang solong halaga sa isang kadena ng mga iba pang mga uri ng pag-ulit.
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().chain(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Dahil ang argument sa `chain()` ay gumagamit ng [`IntoIterator`], maaari naming ipasa ang anumang maaaring mai-convert sa isang [`Iterator`], hindi lamang isang [`Iterator`] mismo.
    /// Halimbawa, hiwa (`&[T]`) ipatupad [`IntoIterator`], at sa gayon ay maaaring maipasa sa `chain()` direkta:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().chain(s2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Kung nagtatrabaho ka sa Windows API, maaari mong hilingin na i-convert [`OsStr`] na `Vec<u16>`:
    ///
    /// ```
    /// #[cfg(windows)]
    /// fn os_str_to_utf16(s: &std::ffi::OsStr) -> Vec<u16> {
    ///     use std::os::windows::ffi::OsStrExt;
    ///     s.encode_wide().chain(std::iter::once(0)).collect()
    /// }
    /// ```
    ///
    /// [`once`]: crate::iter::once
    /// [`OsStr`]: ../../std/ffi/struct.OsStr.html
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn chain<U>(self, other: U) -> Chain<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator<Item = Self::Item>,
    {
        Chain::new(self, other.into_iter())
    }

    /// 'Zips up' dalawang iterators sa iisang iterator ng mga pares.
    ///
    /// `zip()` nagbabalik ng isang bagong umuulit na uulit sa dalawang iba pang mga iterator, nagbabalik ng isang tuple kung saan ang unang elemento ay nagmula sa unang umuulit, at ang pangalawang elemento ay nagmula sa pangalawang umuulit.
    ///
    ///
    /// Sa madaling salita, pinagsasama nito ang dalawang iterator nang magkasama, sa isang solong.
    ///
    /// Kung mag-iterator nagbabalik [`None`], [`next`] mula sa naka-zip ay iterator bumalik [`None`].
    /// Kung ang unang iterator nagbabalik [`None`], `zip` ay short-circuit at `next` ay hindi na tinatawag na sa ikalawang iterator.
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().zip(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Dahil ang argument sa `zip()` ay gumagamit [`IntoIterator`], maaari naming ipasa ang anumang bagay na maaaring ma-convert sa isang [`Iterator`], hindi lamang ng isang [`Iterator`] mismo.
    /// Halimbawa, ang mga hiwa (`&[T]`) ay nagpapatupad ng [`IntoIterator`], at sa gayon ay maaaring maipasa nang direkta sa `zip()`:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().zip(s2);
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `zip()` ay madalas na ginagamit upang i-zip isang walang-katapusang iterator sa isang may hangganan isa.
    /// Gumagana ito dahil ang may wakas na iterator ay huli na ibabalik ang [`None`], na tatapusin ang siper.Ang pag-zip sa `(0..)` ay maaaring magmukhang katulad ng [`enumerate`]:
    ///
    /// ```
    /// let enumerate: Vec<_> = "foo".chars().enumerate().collect();
    ///
    /// let zipper: Vec<_> = (0..).zip("foo".chars()).collect();
    ///
    /// assert_eq!((0, 'f'), enumerate[0]);
    /// assert_eq!((0, 'f'), zipper[0]);
    ///
    /// assert_eq!((1, 'o'), enumerate[1]);
    /// assert_eq!((1, 'o'), zipper[1]);
    ///
    /// assert_eq!((2, 'o'), enumerate[2]);
    /// assert_eq!((2, 'o'), zipper[2]);
    /// ```
    ///
    /// [`enumerate`]: Iterator::enumerate
    /// [`next`]: Iterator::next
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn zip<U>(self, other: U) -> Zip<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator,
    {
        Zip::new(self, other.into_iter())
    }

    /// Lumilikha ng isang bagong iterator kung saan naglalagay ng isang kopya ng `separator` sa pagitan ng mga katabing item ng orihinal na umuulit.
    ///
    /// Kung sakaling ang `separator` ay hindi nagpapatupad ng [`Clone`] o kailangang mai-compute sa bawat oras, gamitin ang [`intersperse_with`].
    ///
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let mut a = [0, 1, 2].iter().intersperse(&100);
    /// assert_eq!(a.next(), Some(&0));   // Ang unang elemento mula sa `a`.
    /// assert_eq!(a.next(), Some(&100)); // Ang naghihiwalay.
    /// assert_eq!(a.next(), Some(&1));   // Ang susunod na elemento mula sa `a`.
    /// assert_eq!(a.next(), Some(&100)); // Ang naghihiwalay.
    /// assert_eq!(a.next(), Some(&2));   // Ang huling elemento mula `a`.
    /// assert_eq!(a.next(), None);       // Tapos na ang umuulit.
    /// ```
    ///
    /// `intersperse` ay maaaring maging lubhang kapaki-pakinabang upang sumali sa mga item ng isang iterator gamit ang isang karaniwang elemento:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let hello = ["Hello", "World", "!"].iter().copied().intersperse(" ").collect::<String>();
    /// assert_eq!(hello, "Hello World !");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse_with`]: Iterator::intersperse_with
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse(self, separator: Self::Item) -> Intersperse<Self>
    where
        Self: Sized,
        Self::Item: Clone,
    {
        Intersperse::new(self, separator)
    }

    /// Lumilikha ng isang bagong iterator na naglalagay ng isang item na nabuo sa pamamagitan `separator` pagitan ng mga katabing mga item ng orihinal na iterator.
    ///
    /// Ang pagsasara ay tatawaging eksaktong isang beses bawat oras na ang isang item ay inilalagay sa pagitan ng dalawang katabing mga item mula sa pinagbabatayan na iterator;
    /// partikular, ang pagsasara ay hindi na tinatawag na kung ang pinagbabatayan iterator magbubunga ng mas mababa sa dalawang mga item at pagkatapos ng huling item ay yielded.
    ///
    ///
    /// Kung ang item ng iterator ay nagpapatupad ng [`Clone`], maaaring mas madaling gamitin ang [`intersperse`].
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// #[derive(PartialEq, Debug)]
    /// struct NotClone(usize);
    ///
    /// let v = vec![NotClone(0), NotClone(1), NotClone(2)];
    /// let mut it = v.into_iter().intersperse_with(|| NotClone(99));
    ///
    /// assert_eq!(it.next(), Some(NotClone(0)));  // Ang unang elemento mula sa `v`.
    /// assert_eq!(it.next(), Some(NotClone(99))); // Ang naghihiwalay.
    /// assert_eq!(it.next(), Some(NotClone(1)));  // Ang susunod na elemento mula `v`.
    /// assert_eq!(it.next(), Some(NotClone(99))); // Ang naghihiwalay.
    /// assert_eq!(it.next(), Some(NotClone(2)));  // Ang huling elemento mula sa `v`.
    /// assert_eq!(it.next(), None);               // Tapos na ang umuulit.
    /// ```
    ///
    /// `intersperse_with` maaaring magamit sa mga sitwasyon kung saan ang compatador ay kailangang kalkulahin:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let src = ["Hello", "to", "all", "people", "!!"].iter().copied();
    ///
    /// // Ang pagsasara ay maaring humiram ng konteksto nito upang makabuo ng isang item.
    /// let mut happy_emojis = [" ❤️ ", " 😀 "].iter().copied();
    /// let separator = || happy_emojis.next().unwrap_or(" 🦀 ");
    ///
    /// let result = src.intersperse_with(separator).collect::<String>();
    /// assert_eq!(result, "Hello ❤️ to 😀 all 🦀 people 🦀 !!");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse`]: Iterator::intersperse
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse_with<G>(self, separator: G) -> IntersperseWith<Self, G>
    where
        Self: Sized,
        G: FnMut() -> Self::Item,
    {
        IntersperseWith::new(self, separator)
    }

    /// Nagsasara at lumilikha ng isang iterator na tumatawag sa pagsasara na iyon sa bawat elemento.
    ///
    /// `map()` transform ang isa iterator sa isa pang, sa pamamagitan ng kanyang mga argumento:
    /// isang bagay na nagpapatupad [`FnMut`].Ito ay gumagawa ng isang bagong iterator kung aling mga tawag na ito ng pagsasara sa bawat elemento ng orihinal na iterator.
    ///
    /// Kung ikaw ay mahusay sa pag-iisip sa uri, maaari mong isipin `map()` tulad nito:
    /// Kung mayroon kang isang iterator na nagbibigay sa iyo ng mga elemento ng ilang mga uri `A`, at nais mo ang isang iterator ng ilang mga iba pang uri `B`, maaari mong gamitin `map()`, pagpasa ng isang pagsasara na tumatagal ng isang `A` at nagbabalik ng `B`.
    ///
    ///
    /// `map()` ay ayon sa haka-haka na katulad ng isang [`for`] loop.Gayunpaman, dahil ang `map()` ay tamad, pinakamahusay na ito ay ginagamit kapag nagtatrabaho ka na sa ibang mga iterator.
    /// Kung ikaw ay gumagawa ng ilang uri ng looping para sa isang side effect, ito ay itinuturing na mas idiomatic gamitin [`for`] kaysa `map()`.
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    /// [`FnMut`]: crate::ops::FnMut
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().map(|x| 2 * x);
    ///
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), Some(6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Kung ikaw ay gumagawa ng ilang uri ng side effect, mas gusto [`for`] na `map()`:
    ///
    /// ```
    /// # #![allow(unused_must_use)]
    /// // huwag gawin ito:
    /// (0..5).map(|x| println!("{}", x));
    ///
    /// // ito ay hindi kahit execute, tulad ng ito ay tamad.Babalaan ka ng Rust tungkol dito.
    ///
    /// // Sa halip, gamitin para sa:
    /// for x in 0..5 {
    ///     println!("{}", x);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn map<B, F>(self, f: F) -> Map<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> B,
    {
        Map::new(self, f)
    }

    /// Tumatawag ng pagsasara sa bawat elemento ng isang iterator.
    ///
    /// Ito ay katumbas ng paggamit ng isang [`for`] loop sa iterator, bagaman `break` at `continue` ay hindi posible mula sa isang pagsasara.
    /// Sa pangkalahatan ay mas idiomatikong gumamit ng isang `for` loop, ngunit ang `for_each` ay maaaring maging mas mababasa kapag pinoproseso ang mga item sa dulo ng mas mahahabang chain ng iterator.
    ///
    /// Sa ilang mga kaso ang `for_each` ay maaari ding mas mabilis kaysa sa isang loop, sapagkat gagamit ito ng panloob na pag-ulit sa mga adapter tulad ng `Chain`.
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// use std::sync::mpsc::channel;
    ///
    /// let (tx, rx) = channel();
    /// (0..5).map(|x| x * 2 + 1)
    ///       .for_each(move |x| tx.send(x).unwrap());
    ///
    /// let v: Vec<_> =  rx.iter().collect();
    /// assert_eq!(v, vec![1, 3, 5, 7, 9]);
    /// ```
    ///
    /// Para sa isang maliit na halimbawa, ang isang `for` loop ay maaaring maging mas malinis, ngunit ang `for_each` ay maaaring lalong gusto na panatilihin ang isang estilo ng pagganap na may mas matagal na mga iterator:
    ///
    /// ```
    /// (0..5).flat_map(|x| x * 100 .. x * 110)
    ///       .enumerate()
    ///       .filter(|&(i, x)| (i + x) % 3 == 0)
    ///       .for_each(|(i, x)| println!("{}:{}", i, x));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_for_each", since = "1.21.0")]
    fn for_each<F>(self, f: F)
    where
        Self: Sized,
        F: FnMut(Self::Item),
    {
        #[inline]
        fn call<T>(mut f: impl FnMut(T)) -> impl FnMut((), T) {
            move |(), item| f(item)
        }

        self.fold((), call(f));
    }

    /// Lumilikha ng isang umuulit na gumagamit ng isang pagsasara upang matukoy kung ang isang elemento ay dapat na ibigay.
    ///
    /// Dahil sa isang elemento dapat na ibalik ng pagsara ang `true` o `false`.Ang naibalik na umuulit ay magbubunga lamang ng mga elemento kung saan ang pagsasara ay bumalik na totoo.
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// let a = [0i32, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| x.is_positive());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Dahil ang pagsasara lumipas na `filter()` tumatagal ng isang reference, at marami iterators umulit sa paglipas ng mga sanggunian, ito leads sa isang posibleng nakalilito sitwasyon, kung saan ang uri ng pagsasara ay isang double reference:
    ///
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| **x > 1); // kailangan ng dalawang * s!
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Karaniwan na sa halip ay gumamit ng mapanirang sa pagtatalo upang alisin ang isa:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&x| *x > 1); // pareho at *
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// o pareho:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&&x| x > 1); // dalawang &s
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// ng mga layer na ito.
    ///
    /// Tandaan na ang `iter.filter(f).next()` ay katumbas ng `iter.find(f)`.
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter<P>(self, predicate: P) -> Filter<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        Filter::new(self, predicate)
    }

    /// Lumilikha ng isang umuulit na parehong mga filter at mapa.
    ///
    /// Nagbalik ang iterator ay magbubunga lamang ng `value`s kung saan ang itinustos pagsasara nagbabalik `Some(value)`.
    ///
    /// `filter_map` ay maaaring gamitin upang gumawa ng mga chain ng [`filter`] at [`map`] mas maigsi.
    /// Ipinapakita ng halimbawa sa ibaba kung paano ang isang `map().filter().map()` ay maaaring paikliin sa isang solong tawag sa `filter_map`.
    ///
    ///
    /// [`filter`]: Iterator::filter
    /// [`map`]: Iterator::map
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    ///
    /// let mut iter = a.iter().filter_map(|s| s.parse().ok());
    ///
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Narito ang parehong halimbawa, ngunit may [`filter`] at [`map`]:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    /// let mut iter = a.iter().map(|s| s.parse()).filter(|s| s.is_ok()).map(|s| s.unwrap());
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter_map<B, F>(self, f: F) -> FilterMap<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        FilterMap::new(self, f)
    }

    /// Lumilikha ng isang iterator kung saan ay nagbibigay sa kasalukuyang count-ulit pati na rin ang susunod na halaga.
    ///
    /// Ang umuulit na bumalik ay nagbubunga ng mga pares na `(i, val)`, kung saan ang `i` ay ang kasalukuyang index ng pag-ulit at `val` ang halagang ibinalik ng iterator.
    ///
    ///
    /// `enumerate()` Pinapanatili nito count bilang [`usize`].
    /// Kung nais mong bilangin sa pamamagitan ng isang iba't ibang laki ng integer, ang pagpapaandar ng [`zip`] ay nagbibigay ng katulad na pag-andar.
    ///
    /// # Overflow na Pag-uugali
    ///
    /// Ang pamamaraan ay gumagana walang nagbabantay laban overflows, para isa-isahin mahigit [`usize::MAX`] elemento alinman gumagawa ng maling resulta o panics.
    /// Kung pinagana ang mga assertion ng pag-debug, garantisado ang isang panic.
    ///
    /// # Panics
    ///
    /// Nagbalik ang maaaring iterator panic kung ang to-ma-ibabalik index ay pag-apaw ng [`usize`].
    ///
    /// [`usize`]: type@usize
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ['a', 'b', 'c'];
    ///
    /// let mut iter = a.iter().enumerate();
    ///
    /// assert_eq!(iter.next(), Some((0, &'a')));
    /// assert_eq!(iter.next(), Some((1, &'b')));
    /// assert_eq!(iter.next(), Some((2, &'c')));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn enumerate(self) -> Enumerate<Self>
    where
        Self: Sized,
    {
        Enumerate::new(self)
    }

    /// Lumilikha ng isang iterator na maaaring gumamit ng [`peek`] upang tingnan ang susunod na elemento ng iterator nang hindi ito naubos.
    ///
    /// Nagdadagdag ng isang [`peek`] paraan upang ang isang iterator.Tingnan ang dokumentasyon para sa karagdagang impormasyon.
    ///
    /// Tandaan na ang nakapailalim pa rin iterator ay sumulong nang [`peek`] ay tinatawag na para sa unang pagkakataon: Upang makuha ang susunod na elemento, [`next`] ay tinatawag na sa napapailalim na iterator, samakatuwid ay ibinigay ang anumang mga side effect (ie
    ///
    /// kahit ano bukod sa pagkuha ng mga susunod na halaga) ng [`next`] pamamaraan ay magaganap.
    ///
    /// [`peek`]: Peekable::peek
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// let xs = [1, 2, 3];
    ///
    /// let mut iter = xs.iter().peekable();
    ///
    /// // peek() hinahayaan kaming makita sa future
    /// assert_eq!(iter.peek(), Some(&&1));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), Some(&2));
    ///
    /// // maaari naming peek() maraming beses, ang iterator ay hindi advance
    /// assert_eq!(iter.peek(), Some(&&3));
    /// assert_eq!(iter.peek(), Some(&&3));
    ///
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // pagkatapos ng iterator ay natapos na, kaya ay peek()
    /// assert_eq!(iter.peek(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn peekable(self) -> Peekable<Self>
    where
        Self: Sized,
    {
        Peekable::new(self)
    }

    /// Lumilikha ng isang umuulit na mga elemento ng [`laktawan`] batay sa isang panaguri.
    ///
    /// [`skip`]: Iterator::skip
    ///
    /// `skip_while()` tumatagal ng isang pagsasara bilang isang argument.Ito ay itawag sa pagsasara sa bawat elemento ng iterator, at huwag pansinin ang mga elemento hanggang sa pagbabalik nito `false`.
    ///
    /// Matapos ibalik ang `false`, tapos na ang trabaho na `skip_while()`'s, at ang natitirang mga elemento ay nabigyan.
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Dahil ang pagsasara lumipas na `skip_while()` tumatagal ng isang reference, at marami iterators umulit sa paglipas ng mga sanggunian, ito leads sa isang posibleng nakalilito sitwasyon, kung saan ang uri ng pagsasara argument ay isang double reference:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0); // kailangan ng dalawang * s!
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Huminto pagkatapos ng paunang `false`:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// // habang ito ay magiging mali, dahil nakakuha na kami ng hindi totoo, ang skip_while() ay hindi na ginagamit
    /////
    /// assert_eq!(iter.next(), Some(&-2));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip_while<P>(self, predicate: P) -> SkipWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        SkipWhile::new(self, predicate)
    }

    /// Lumilikha ng isang iterator na magbubunga elemento batay sa isang tambalan.
    ///
    /// `take_while()` tumatagal ng isang pagsasara bilang isang pagtatalo.Ito ay itawag sa pagsasara sa bawat elemento ng iterator, at magbunga ng mga elemento habang ito ay nagbabalik `true`.
    ///
    /// Pagkatapos `false` ay ibinalik, `take_while()`'s trabaho ay higit sa, at ang magpahinga ng ang mga elemento ay hindi papansinin.
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Dahil ang pagsasara lumipas na `take_while()` tumatagal ng isang reference, at marami iterators umulit sa paglipas ng mga sanggunian, ito leads sa isang posibleng nakalilito sitwasyon, kung saan ang uri ng pagsasara ay isang double reference:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0); // kailangan ng dalawang * s!
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Huminto pagkatapos ng paunang `false`:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    ///
    /// // Mayroon kaming higit pang mga elemento na mas mababa sa zero, ngunit dahil kami ay mayroon na got ang isang hindi totoo, take_while() ay hindi ginagamit ng anumang higit pa
    /////
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Dahil `take_while()` pangangailangan upang tumingin sa ang halaga upang makita kung ito ay dapat na kasama o hindi, ubos iterators ay makikita na ito ay inalis:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<i32> = iter.by_ref()
    ///                            .take_while(|n| **n != 3)
    ///                            .cloned()
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// Ang `3` ay hindi na doon, dahil ito ay natupok upang makita kung ang pag-ulit ay dapat huminto na, ngunit hindi inilagay pabalik sa iterator.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take_while<P>(self, predicate: P) -> TakeWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        TakeWhile::new(self, predicate)
    }

    /// Lumilikha ng isang umuulit na parehong nagbubunga ng mga elemento batay sa isang panaguri at mga mapa.
    ///
    /// `map_while()` tumatagal ng isang pagsasara bilang isang argument.
    /// Tatawagan nito ang pagsasara na ito sa bawat elemento ng iterator, at mga elemento ng ani habang binabalik nito ang [`Some(_)`][`Some`].
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter().map_while(|x| 16i32.checked_div(*x));
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Narito ang parehong halimbawa, ngunit may [`take_while`] at [`map`]:
    ///
    /// [`take_while`]: Iterator::take_while
    /// [`map`]: Iterator::map
    ///
    /// ```
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter()
    ///                 .map(|x| 16i32.checked_div(*x))
    ///                 .take_while(|x| x.is_some())
    ///                 .map(|x| x.unwrap());
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Ang pagpigil pagkatapos ng isang paunang [`None`]:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [0, 1, 2, -3, 4, 5, -6];
    ///
    /// let iter = a.iter().map_while(|x| u32::try_from(*x).ok());
    /// let vec = iter.collect::<Vec<_>>();
    ///
    /// // Mayroon kaming higit pang mga elemento na maaaring magkasya sa u32 (4, 5), ngunit `map_while` ibinalik `None` para `-3` (bilang `predicate` ibinalik `None`) at `collect` humihinto sa unang `None` nakatagpo.
    /////
    /// assert_eq!(vec, vec![0, 1, 2]);
    /// ```
    ///
    /// Sapagkat kailangang tingnan ng `map_while()` ang halaga upang makita kung dapat itong isama o hindi, makikita ng pag-ubos ng mga iterator na tinanggal ito:
    ///
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [1, 2, -3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<u32> = iter.by_ref()
    ///                            .map_while(|n| u32::try_from(*n).ok())
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// Ang `-3` ay wala na, sapagkat natupok ito upang makita kung dapat tumigil ang pag-ulit, ngunit hindi naibalik sa iterator.
    ///
    /// Tandaan na hindi katulad ng [`take_while`] ito iterator ay **hindi** fused.
    /// Ito ay hindi rin tinukoy kung ano ang iterator nagbabalik matapos ang unang [`None`] ay ibinalik.
    /// Kung kailangan mo fused iterator, gamitin [`fuse`].
    ///
    /// [`fuse`]: Iterator::fuse
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
    fn map_while<B, P>(self, predicate: P) -> MapWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> Option<B>,
    {
        MapWhile::new(self, predicate)
    }

    /// Lumilikha ng isang iterator na skips ang unang `n` elemento.
    ///
    /// Pagkatapos sila ay natupok, ang magpahinga ng ang mga elemento ay yielded.
    /// Sa halip na override ang paraan na ito ng direkta, sa halip i-override ang `nth` paraan.
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().skip(2);
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip(self, n: usize) -> Skip<Self>
    where
        Self: Sized,
    {
        Skip::new(self, n)
    }

    /// Lumilikha ng isang iterator na magbubunga ang una nitong `n` elemento.
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().take(2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `take()` ay madalas na ginagamit sa isang walang katapusang iterator, upang gawin itong may wakas:
    ///
    /// ```
    /// let mut iter = (0..).take(3);
    ///
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Kung mas mababa sa `n` elemento ay magagamit, `take` lilimitahan ang sarili nito sa laki ng ang kalakip na iterator:
    ///
    ///
    /// ```
    /// let v = vec![1, 2];
    /// let mut iter = v.into_iter().take(5);
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take(self, n: usize) -> Take<Self>
    where
        Self: Sized,
    {
        Take::new(self, n)
    }

    /// Ang isang iterator adapter na katulad ng [`fold`] na nagtataglay ng panloob na estado at gumagawa ng isang bagong iterator.
    ///
    /// [`fold`]: Iterator::fold
    ///
    /// `scan()` tumatagal ng dalawang mga argumento: isang paunang halaga na binhi ng panloob na estado, at isang pagsasara na may dalawang mga argumento, ang una ay isang nababagabag na sanggunian sa panloob na estado at ang pangalawa ay isang elemento ng umuulit.
    ///
    /// pagsasara ay maaaring italaga sa ang panloob na estado upang magbahagi ng mga estado sa pagitan ng mga iteration.
    ///
    /// Sa pag-ulit, ang pagsasara ay mailalapat sa bawat elemento ng iterator at ang halaga ng pagbabalik mula sa pagsasara, isang [`Option`], ay ibinibigay ng umuulit.
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().scan(1, |state, &x| {
    ///     // sa bawat pag-ulit, kami ay i-multiply ang estado sa pamamagitan ng mga elemento
    ///     *state = *state * x;
    ///
    ///     // pagkatapos, kami ay magbunga ng hindi pagsang-ayon ng estado
    ///     Some(-*state)
    /// });
    ///
    /// assert_eq!(iter.next(), Some(-1));
    /// assert_eq!(iter.next(), Some(-2));
    /// assert_eq!(iter.next(), Some(-6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn scan<St, B, F>(self, initial_state: St, f: F) -> Scan<Self, St, F>
    where
        Self: Sized,
        F: FnMut(&mut St, Self::Item) -> Option<B>,
    {
        Scan::new(self, initial_state, f)
    }

    /// Lumilikha ng isang iterator na gumagana tulad ng mapa, ngunit flattens nested istraktura.
    ///
    /// Ang adapter na [`map`] ay lubhang kapaki-pakinabang, ngunit kapag ang argumento ng pagsara ay gumagawa ng mga halaga.
    /// Kung gumagawa ito ng isang iterator sa halip, mayroong isang labis na layer ng indirection.
    /// `flat_map()` aalisin ang labis na layer na ito nang mag-isa.
    ///
    /// Maaari mong isipin na `flat_map(f)` bilang ang semantic katumbas ng [`map`] ping, at pagkatapos ay [`flatten`] ing tulad ng sa `map(f).flatten()`.
    ///
    /// Isa pang paraan ng pag-iisip tungkol sa `flat_map()`: Ang pagsasara ni [`map`] ay nagbabalik ng isang item para sa bawat elemento, at ang pagsasara ng `flat_map()`'s ay nagbabalik ng isang iterator para sa bawat elemento.
    ///
    ///
    /// [`map`]: Iterator::map
    /// [`flatten`]: Iterator::flatten
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() ay nagbabalik ng isang iterator
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn flat_map<U, F>(self, f: F) -> FlatMap<Self, U, F>
    where
        Self: Sized,
        U: IntoIterator,
        F: FnMut(Self::Item) -> U,
    {
        FlatMap::new(self, f)
    }

    /// Lumilikha ng isang umuulit na pumapatong sa may istrakturang istraktura.
    ///
    /// Ito ay kapaki-pakinabang kapag ikaw ay may isang iterator ng iterators o isang iterator ng mga bagay na maaaring naging mga iterators at nais mong alisin ang isang antas ng kawalang-tapat.
    ///
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// let data = vec![vec![1, 2, 3, 4], vec![5, 6]];
    /// let flattened = data.into_iter().flatten().collect::<Vec<u8>>();
    /// assert_eq!(flattened, &[1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    /// Pagma-map at pagkatapos ay pagyupi:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() ay nagbabalik ng isang iterator
    /// let merged: String = words.iter()
    ///                           .map(|s| s.chars())
    ///                           .flatten()
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// Maaari mo rin itong muling isulat sa mga tuntunin ng [`flat_map()`], na kung saan ay mas mabuti sa kasong ito dahil mas malinaw itong nagpapahiwatig ng hangarin:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() ay nagbabalik ng isang iterator
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// Ang pag-flatt lang ay aalisin ang isang antas ng pamumugad nang paisa-isa:
    ///
    /// ```
    /// let d3 = [[[1, 2], [3, 4]], [[5, 6], [7, 8]]];
    ///
    /// let d2 = d3.iter().flatten().collect::<Vec<_>>();
    /// assert_eq!(d2, [&[1, 2], &[3, 4], &[5, 6], &[7, 8]]);
    ///
    /// let d1 = d3.iter().flatten().flatten().collect::<Vec<_>>();
    /// assert_eq!(d1, [&1, &2, &3, &4, &5, &6, &7, &8]);
    /// ```
    ///
    /// Narito nakikita natin na ang `flatten()` ay hindi gumanap ng isang "deep" patagin.
    /// Sa halip, isang antas lamang ng pugad ang natanggal.Iyon ay, kung `flatten()` ka ng isang three-dimensional array, ang resulta ay magiging dalawang-dimensional at hindi one-dimensional.
    /// Upang makakuha ng isang one-dimensional na istraktura, kailangan mong `flatten()` muli.
    ///
    /// [`flat_map()`]: Iterator::flat_map
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_flatten", since = "1.29.0")]
    fn flatten(self) -> Flatten<Self>
    where
        Self: Sized,
        Self::Item: IntoIterator,
    {
        Flatten::new(self)
    }

    /// Lumilikha ng isang umuulit na nagtatapos pagkatapos ng unang [`None`].
    ///
    /// Pagkatapos ng isang iterator nagbabalik [`None`], future tawag ay maaaring o maaaring hindi magbunga ng muling [`Some(T)`].
    /// `fuse()` adapts isang iterator, tinitiyak na pagkatapos ng isang [`None`] ay ibinigay, palagi itong ibabalik ang [`None`] magpakailanman.
    ///
    ///
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// // isang iterator na kahalili sa pagitan ng Ilang at Wala
    /// struct Alternate {
    ///     state: i32,
    /// }
    ///
    /// impl Iterator for Alternate {
    ///     type Item = i32;
    ///
    ///     fn next(&mut self) -> Option<i32> {
    ///         let val = self.state;
    ///         self.state = self.state + 1;
    ///
    ///         // kung ito ay pantay, Some(i32), kung wala
    ///         if val % 2 == 0 {
    ///             Some(val)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    ///
    /// let mut iter = Alternate { state: 0 };
    ///
    /// // nakikita nating pabalik-balik ang ating iterator
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    ///
    /// // gayunpaman, sa sandaling kami ay sumanib ito ...
    /// let mut iter = iter.fuse();
    ///
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    ///
    /// // palaging ibabalik nito ang `None` pagkatapos ng unang pagkakataon.
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fuse(self) -> Fuse<Self>
    where
        Self: Sized,
    {
        Fuse::new(self)
    }

    /// Sinusuportahan ba ng isang bagay sa bawat elemento ng isang iterator, pagpasa ang halaga sa.
    ///
    /// Kapag gumagamit ng iterators, madalas kang makakakita kadena ilan sa mga ito nang magkakasama.
    /// Habang nagtatrabaho sa naturang code, baka gusto mong tingnan kung ano ang nangyayari sa iba't-ibang mga bahagi sa pipeline.Upang magawa iyon, magpasok ng isang tawag sa `inspect()`.
    ///
    /// Mas karaniwan para sa `inspect()` na magamit bilang isang tool sa pag-debug kaysa sa pagkakaroon sa iyong pangwakas na code, ngunit maaaring makita ng mga application na kapaki-pakinabang ito sa ilang mga sitwasyon kung kailan kailangang mai-log ang mga error bago itapon.
    ///
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// let a = [1, 4, 2, 3];
    ///
    /// // kumplikado ang pagkakasunud-sunod ng iterator na ito.
    /// let sum = a.iter()
    ///     .cloned()
    ///     .filter(|x| x % 2 == 0)
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    ///
    /// // magdagdag tayo ng ilang mga tawag na inspect() upang siyasatin kung ano ang nangyayari
    /// let sum = a.iter()
    ///     .cloned()
    ///     .inspect(|x| println!("about to filter: {}", x))
    ///     .filter(|x| x % 2 == 0)
    ///     .inspect(|x| println!("made it through filter: {}", x))
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    /// ```
    ///
    /// Ito ay i-print:
    ///
    /// ```text
    /// 6
    /// about to filter: 1
    /// about to filter: 4
    /// made it through filter: 4
    /// about to filter: 2
    /// made it through filter: 2
    /// about to filter: 3
    /// 6
    /// ```
    ///
    /// Mga error sa pag-log bago itapon ang mga ito:
    ///
    /// ```
    /// let lines = ["1", "2", "a"];
    ///
    /// let sum: i32 = lines
    ///     .iter()
    ///     .map(|line| line.parse::<i32>())
    ///     .inspect(|num| {
    ///         if let Err(ref e) = *num {
    ///             println!("Parsing error: {}", e);
    ///         }
    ///     })
    ///     .filter_map(Result::ok)
    ///     .sum();
    ///
    /// println!("Sum: {}", sum);
    /// ```
    ///
    /// Ito ay i-print:
    ///
    /// ```text
    /// Parsing error: invalid digit found in string
    /// Sum: 3
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn inspect<F>(self, f: F) -> Inspect<Self, F>
    where
        Self: Sized,
        F: FnMut(&Self::Item),
    {
        Inspect::new(self, f)
    }

    /// Humihiram ng isang iterator, sa halip na gugulin ito.
    ///
    /// Ito ay kapaki-pakinabang upang payagan ang paglalapat iterator adapters habang pinapanatili ang pagmamay-ari ng orihinal na iterator.
    ///
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let iter = a.iter();
    ///
    /// let sum: i32 = iter.take(5).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 6);
    ///
    /// // kung susubukan nating gamitin ulit ito, hindi ito gagana.
    /// // Nagbibigay ang sumusunod na linya ng "error: paggamit ng inilipat na halaga: `iter`
    /// // assert_eq!(iter.next(), None);
    ///
    /// // subukan natin ulit yan
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // sa halip, idagdag namin sa isang .by_ref()
    /// let sum: i32 = iter.by_ref().take(2).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 3);
    ///
    /// // ngayon ayos lang ito:
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn by_ref(&mut self) -> &mut Self
    where
        Self: Sized,
    {
        self
    }

    /// Binabago ang isang iterator sa isang koleksyon.
    ///
    /// `collect()` maaaring tumagal ng kahit ano iterable, at i-on ito sa isang may-katuturang mga koleksyon.
    /// Ito ay isa sa mga mas malakas na pamamaraan sa standard library, na ginagamit sa isang iba't ibang mga konteksto.
    ///
    /// Ang pinaka-pangunahing pattern kung saan ginagamit ang `collect()` ay upang gawing isa pa ang isang koleksyon.
    /// magdadala sa iyo ng isang koleksyon, tumawag [`iter`] sa mga ito, gawin ang isang grupo ng mga transformations, at pagkatapos ay `collect()` sa dulo.
    ///
    /// `collect()` maaari ring lumikha ng mga pagkakataon ng mga uri na hindi karaniwang mga koleksyon.
    /// Halimbawa, ang isang [`String`] ay maaaring binuo mula sa [`char`] s, at isang iterator ng [`Result<T, E>`][`Result`] item makokolekta sa `Result<Collection<T>, E>`.
    ///
    /// Tingnan ang mga halimbawa sa ibaba para sa higit pa.
    ///
    /// Dahil `collect()` ay kaya pangkalahatan, maaari itong magdulot ng mga problema na may uri ng hinuha.
    /// Gaya ng nabanggit, `collect()` ay isa sa mga ilang beses makikita mo ang syntax affectionately kilala bilang ang 'turbofish': `::<>`.
    /// Ito ay tumutulong sa mga hinuha algorithm na maunawaan ang partikular na koleksyon na sinusubukan upang mangolekta sa.
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled: Vec<i32> = a.iter()
    ///                          .map(|&x| x * 2)
    ///                          .collect();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Tandaan na kailangan namin ang `: Vec<i32>` sa kaliwang gilid.Ito ay dahil maaari kaming mangolekta sa, halimbawa, isang [`VecDeque<T>`] sa halip:
    ///
    /// [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let a = [1, 2, 3];
    ///
    /// let doubled: VecDeque<i32> = a.iter().map(|&x| x * 2).collect();
    ///
    /// assert_eq!(2, doubled[0]);
    /// assert_eq!(4, doubled[1]);
    /// assert_eq!(6, doubled[2]);
    /// ```
    ///
    /// Paggamit ng 'turbofish' sa halip na anotasyon ng `doubled`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<i32>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Dahil `collect()` lamang nagmamalasakit tungkol sa kung ano ka na pagkolekta sa, maaari mo pa ring gamitin ang isang bahagyang i-type ang hint, `_`, na may turbofish:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<_>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Paggamit ng `collect()` upang makagawa ng isang [`String`]:
    ///
    /// ```
    /// let chars = ['g', 'd', 'k', 'k', 'n'];
    ///
    /// let hello: String = chars.iter()
    ///     .map(|&x| x as u8)
    ///     .map(|x| (x + 1) as char)
    ///     .collect();
    ///
    /// assert_eq!("hello", hello);
    /// ```
    ///
    /// Kung ikaw ay may isang listahan ng mga [`Resulta<T, E>`][`Result`] s, maaari mong gamitin ang `collect()` upang makita kung alin man sa kanila ay di nagtagumpay:
    ///
    /// ```
    /// let results = [Ok(1), Err("nope"), Ok(3), Err("bad")];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // ay nagbibigay sa amin ng unang error
    /// assert_eq!(Err("nope"), result);
    ///
    /// let results = [Ok(1), Ok(3)];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // ay nagbibigay sa amin ng listahan ng mga sagot
    /// assert_eq!(Ok(vec![1, 3]), result);
    /// ```
    ///
    /// [`iter`]: Iterator::next
    /// [`String`]: ../../std/string/struct.String.html
    /// [`char`]: type@char
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "if you really need to exhaust the iterator, consider `.for_each(drop)` instead"]
    fn collect<B: FromIterator<Self::Item>>(self) -> B
    where
        Self: Sized,
    {
        FromIterator::from_iter(self)
    }

    /// Naubos ang isang umuulit, lumilikha ng dalawang koleksyon mula rito.
    ///
    /// Ang panaguri ang pumasa sa `partition()` makakabalik `true`, o `false`.
    /// `partition()` ay nagbabalik ng isang pares, ang lahat ng mga elemento na kung saan ito ay bumalik `true`, at ang lahat ng mga elemento na kung saan ito ay bumalik `false`.
    ///
    ///
    /// Tingnan din [`is_partitioned()`] at [`partition_in_place()`].
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let (even, odd): (Vec<i32>, Vec<i32>) = a
    ///     .iter()
    ///     .partition(|&n| n % 2 == 0);
    ///
    /// assert_eq!(even, vec![2]);
    /// assert_eq!(odd, vec![1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn partition<B, F>(self, f: F) -> (B, B)
    where
        Self: Sized,
        B: Default + Extend<Self::Item>,
        F: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn extend<'a, T, B: Extend<T>>(
            mut f: impl FnMut(&T) -> bool + 'a,
            left: &'a mut B,
            right: &'a mut B,
        ) -> impl FnMut((), T) + 'a {
            move |(), x| {
                if f(&x) {
                    left.extend_one(x);
                } else {
                    right.extend_one(x);
                }
            }
        }

        let mut left: B = Default::default();
        let mut right: B = Default::default();

        self.fold((), extend(f, &mut left, &mut right));

        (left, right)
    }

    /// Inayos muli ang mga elemento ng iterator na *in-place* ayon sa ibinigay na panaguri, tulad ng lahat ng mga nagbabalik ng `true` na nauna sa lahat ng mga nagbabalik ng `false`.
    ///
    /// Ibinabalik ang bilang ng mga `true` elemento na natagpuan.
    ///
    /// Ang kamag-anak na pagkakasunud-sunod ng mga na-partition na item ay hindi mapanatili.
    ///
    /// Tingnan din [`is_partitioned()`] at [`partition()`].
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition()`]: Iterator::partition
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_partition_in_place)]
    ///
    /// let mut a = [1, 2, 3, 4, 5, 6, 7];
    ///
    /// // Partition in-sa pagitan Tabla at odds
    /// let i = a.iter_mut().partition_in_place(|&n| n % 2 == 0);
    ///
    /// assert_eq!(i, 3);
    /// assert!(a[..i].iter().all(|&n| n % 2 == 0)); // evens
    /// assert!(a[i..].iter().all(|&n| n % 2 == 1)); // odds
    /// ```
    #[unstable(feature = "iter_partition_in_place", reason = "new API", issue = "62543")]
    fn partition_in_place<'a, T: 'a, P>(mut self, ref mut predicate: P) -> usize
    where
        Self: Sized + DoubleEndedIterator<Item = &'a mut T>,
        P: FnMut(&T) -> bool,
    {
        // FIXME: dapat naming mag-alala tungkol sa count umaapaw?Ang tanging paraan upang magkaroon ng higit sa
        // `usize::MAX` ang mga nababagong sanggunian ay kasama ang mga ZST, na hindi kapaki-pakinabang sa paghati ...

        // Ang mga pagsasara na "factory" function na ito ay mayroon upang maiwasan ang pagkabuong sa `Self`.

        #[inline]
        fn is_false<'a, T>(
            predicate: &'a mut impl FnMut(&T) -> bool,
            true_count: &'a mut usize,
        ) -> impl FnMut(&&mut T) -> bool + 'a {
            move |x| {
                let p = predicate(&**x);
                *true_count += p as usize;
                !p
            }
        }

        #[inline]
        fn is_true<T>(predicate: &mut impl FnMut(&T) -> bool) -> impl FnMut(&&mut T) -> bool + '_ {
            move |x| predicate(&**x)
        }

        // Paulit-ulit ang unang `false` at magpalitan ito sa huling `true`.
        let mut true_count = 0;
        while let Some(head) = self.find(is_false(predicate, &mut true_count)) {
            if let Some(tail) = self.rfind(is_true(predicate)) {
                crate::mem::swap(head, tail);
                true_count += 1;
            } else {
                break;
            }
        }
        true_count
    }

    /// Sinusuri kung ang mga elemento ng iterator na ito ay nahahati ayon sa ibinigay na panaguri, tulad ng lahat ng mga bumalik na `true` na nauna sa lahat ng mga nagbabalik ng `false`.
    ///
    ///
    /// Tingnan din [`partition()`] at [`partition_in_place()`].
    ///
    /// [`partition()`]: Iterator::partition
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_is_partitioned)]
    ///
    /// assert!("Iterator".chars().is_partitioned(char::is_uppercase));
    /// assert!(!"IntoIterator".chars().is_partitioned(char::is_uppercase));
    /// ```
    #[unstable(feature = "iter_is_partitioned", reason = "new API", issue = "62544")]
    fn is_partitioned<P>(mut self, mut predicate: P) -> bool
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        // Alinman lahat ng mga item test `true`, o ang unang sugnay humihinto sa `false` at i-check namin na wala nang mga `true` item pagkatapos nun.
        //
        self.all(&mut predicate) || !self.any(predicate)
    }

    /// Isang pamamaraang iterator na naglalapat ng isang function basta't matagumpay itong nakabalik, na gumagawa ng isang solong, pangwakas na halaga.
    ///
    /// `try_fold()` tumatagal ng dalawang mga argumento: isang paunang halaga, at isang pagsasara na may dalawang mga argumento: isang 'accumulator', at isang elemento.
    /// Ang pagsasara mag matagumpay na nagbabalik, na may halaga na ang singaw ay dapat magkaroon ng para sa susunod na pag-ulit, o ito ay nagbabalik ng kabiguan, na may isang halaga ng error na ay propagated bumalik sa tumatawag agad (short-circuiting).
    ///
    ///
    /// Ang paunang halaga ay ang halaga nagtitipon ay magkakaroon sa unang tawag.Kung ang paglalapat ng pagsasara ay nagtagumpay laban sa bawat elemento ng iterator, ibabalik ng `try_fold()` ang pangwakas na nagtitipon bilang tagumpay.
    ///
    /// Folding ay kapaki-pakinabang sa tuwing mayroon kang isang koleksyon ng mga bagay, at nais upang makabuo ng isang solong halaga mula sa mga ito.
    ///
    /// # Tandaan sa Mga Nagpapatupad
    ///
    /// Marami sa iba pang mga pamamaraan ng (forward) ay may default na pagpapatupad sa mga tuntunin ng isang ito, kaya subukang ipatupad ito nang malinaw kung maaari itong gumawa ng isang bagay na mas mahusay kaysa sa default na pagpapatupad ng loop `for`.
    ///
    /// Sa partikular, subukan na magkaroon ng ganitong tawag `try_fold()` sa panloob na mga bahagi mula sa kung saan ito iterator ay binubuo.
    /// Kung maramihang mga tawag ay kinakailangan, ang `?` operator ay maaaring maginhawa para sa chaining ang nagtitipon halaga kasama, ngunit mag-ingat ng anumang invariants na kailangang ma itinaguyod bago ang mga unang bahagi ng returns.
    /// Ito ay isang `&mut self` paraan, sa gayon pag-ulit ay kailangang resumable pagkatapos ng pagpindot ng isang error dito.
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // ang naka-check na kabuuan ng lahat ng mga elemento ng array
    /// let sum = a.iter().try_fold(0i8, |acc, &x| acc.checked_add(x));
    ///
    /// assert_eq!(sum, Some(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = [10, 20, 30, 100, 40, 50];
    /// let mut it = a.iter();
    ///
    /// // Ang kabuuan na ito overflows kapag nagdadagdag ng 100 element
    /// let sum = it.try_fold(0i8, |acc, &x| acc.checked_add(x));
    /// assert_eq!(sum, None);
    ///
    /// // Dahil ito ay umikli sa sirkito, ang mga natitirang elemento ay magagamit pa rin sa pamamagitan ng iterator.
    /////
    /// assert_eq!(it.len(), 2);
    /// assert_eq!(it.next(), Some(&40));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// Ang isang paraan iterator na nalalapat isang maaaring magkamali pag-andar sa bawat item sa iterator, pagtigil sa unang error at bumabalik na error.
    ///
    ///
    /// Maaari rin itong maiisip bilang mali ang form ng [`for_each()`] o bilang walang estado na bersyon ng [`try_fold()`].
    ///
    /// [`for_each()`]: Iterator::for_each
    /// [`try_fold()`]: Iterator::try_fold
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fs::rename;
    /// use std::io::{stdout, Write};
    /// use std::path::Path;
    ///
    /// let data = ["no_tea.txt", "stale_bread.json", "torrential_rain.png"];
    ///
    /// let res = data.iter().try_for_each(|x| writeln!(stdout(), "{}", x));
    /// assert!(res.is_ok());
    ///
    /// let mut it = data.iter().cloned();
    /// let res = it.try_for_each(|x| rename(x, Path::new(x).with_extension("old")));
    /// assert!(res.is_err());
    /// // Umikli ito ng sirkito, kaya't ang natitirang mga item ay nasa iterator pa rin:
    /// assert_eq!(it.next(), Some("stale_bread.json"));
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_for_each<F, R>(&mut self, f: F) -> R
    where
        Self: Sized,
        F: FnMut(Self::Item) -> R,
        R: Try<Ok = ()>,
    {
        #[inline]
        fn call<T, R>(mut f: impl FnMut(T) -> R) -> impl FnMut((), T) -> R {
            move |(), x| f(x)
        }

        self.try_fold((), call(f))
    }

    /// Tiklupin ang bawat elemento sa isang nagtitipon sa pamamagitan ng paglalapat ng isang operasyon, ibabalik ang pangwakas na resulta.
    ///
    /// `fold()` tumatagal ng dalawang mga argumento: isang paunang halaga, at isang pagsasara na may dalawang mga argumento: isang 'accumulator', at isang elemento.
    /// Ibinabalik ng pagsara ang halaga na dapat magkaroon ng nagtitipid para sa susunod na pag-ulit.
    ///
    /// Ang paunang halaga ay ang halaga nagtitipon ay magkakaroon sa unang tawag.
    ///
    /// Matapos ilapat ang pagsasara na ito sa bawat elemento ng iterator, ibabalik ng `fold()` ang nagtitipon.
    ///
    /// Ang operasyon na ito ay minsang tinatawag 'reduce' o 'inject'.
    ///
    /// Folding ay kapaki-pakinabang sa tuwing mayroon kang isang koleksyon ng mga bagay, at nais upang makabuo ng isang solong halaga mula sa mga ito.
    ///
    /// Note: Ang `fold()`, at mga katulad na pamamaraan na dumadaan sa buong iterator, ay maaaring hindi magtapos para sa mga walang katapusang iterator, kahit na sa traits kung saan ang isang resulta ay maaaring matukoy sa may takdang oras.
    ///
    /// Note: [`reduce()`] ay maaaring gamitin upang gamitin ang unang elemento bilang paunang halaga, kung ang nagtitipon uri at uri ng item ay pareho.
    ///
    /// # Tandaan sa Mga Nagpapatupad
    ///
    /// Marami sa iba pang mga pamamaraan ng (forward) ay may default na pagpapatupad sa mga tuntunin ng isang ito, kaya subukang ipatupad ito nang malinaw kung maaari itong gumawa ng isang bagay na mas mahusay kaysa sa default na pagpapatupad ng loop `for`.
    ///
    ///
    /// Sa partikular, subukan na magkaroon ng ganitong tawag `fold()` sa panloob na mga bahagi mula sa kung saan ito iterator ay binubuo.
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // ang kabuuan ng lahat ng mga elemento ng array
    /// let sum = a.iter().fold(0, |acc, x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// lakad Natin Ito sa pamamagitan ng bawat hakbang ng pag-ulit dito:
    ///
    /// | element | acc | x | result |
    /// |---------|-----|---|--------|
    /// |         | 0   |   |        |
    /// | 1       | 0   | 1 | 1      |
    /// | 2       | 1   | 2 | 3      |
    /// | 3       | 3   | 3 | 6      |
    ///
    /// At kaya, ang aming panghuling resulta, `6`.
    ///
    /// ni Ito ay karaniwan para sa mga taong hindi ginamit iterators isang pulutong na gumamit ng isang `for` loop na may isang listahan ng mga bagay upang bumuo ng up ng isang resulta.Yaong ay maaaring nakabukas sa `fold()`s:
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let mut result = 0;
    ///
    /// // para sa loop:
    /// for i in &numbers {
    ///     result = result + i;
    /// }
    ///
    /// // fold:
    /// let result2 = numbers.iter().fold(0, |acc, &x| acc + x);
    ///
    /// // ang mga ito ay ang parehong
    /// assert_eq!(result, result2);
    /// ```
    ///
    /// [`reduce()`]: Iterator::reduce
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[doc(alias = "reduce")]
    #[doc(alias = "inject")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x);
        }
        accum
    }

    /// Binabawasan ang mga elemento sa isang solong isa, sa pamamagitan ng paulit-ulit na paglalapat ng isang pagbabawas ng operasyon.
    ///
    /// Kung ang iterator ay walang laman, nagbabalik [`None`];sa kabilang banda, ay magbabalik ng mga resulta ng pagbawas.
    ///
    /// Para sa mga iterator na may hindi bababa sa isang elemento, ito ay kapareho ng [`fold()`] na may unang elemento ng iterator bilang paunang halaga, natitiklop ang bawat kasunod na elemento dito.
    ///
    ///
    /// [`fold()`]: Iterator::fold
    ///
    /// # Example
    ///
    /// Hanapin ang pinakamataas na halaga:
    ///
    /// ```
    /// fn find_max<I>(iter: I) -> Option<I::Item>
    ///     where I: Iterator,
    ///           I::Item: Ord,
    /// {
    ///     iter.reduce(|a, b| {
    ///         if a >= b { a } else { b }
    ///     })
    /// }
    /// let a = [10, 20, 5, -23, 0];
    /// let b: [u32; 0] = [];
    ///
    /// assert_eq!(find_max(a.iter()), Some(&20));
    /// assert_eq!(find_max(b.iter()), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_fold_self", since = "1.51.0")]
    fn reduce<F>(mut self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(Self::Item, Self::Item) -> Self::Item,
    {
        let first = self.next()?;
        Some(self.fold(first, f))
    }

    /// Pagsusuri kung ang bawat elemento ng iterator ay tumutugma sa isang tambalan.
    ///
    /// `all()` tumatagal ng isang pagsasara na nagbabalik `true` o `false`.Nalalapat ito ito pagsasara sa bawat elemento ng iterator, at kung ang mga ito ang lahat ng bumalik `true`, at pagkatapos ay sa gayon ay `all()`.
    /// Kung anuman sa mga ito bumalik `false`, ito ay nagbabalik `false`.
    ///
    /// `all()` ay short circuit;sa ibang salita, ito ay titigil sa pagpoproseso ng sa lalong madaling nahahanap nito ang isang `false`, na ibinigay na ang kahit na ano pa ang mangyayari, ang resulta ay magiging din `false`.
    ///
    ///
    /// Ang isang walang laman na iterator ay nagbabalik ng `true`.
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().all(|&x| x > 0));
    ///
    /// assert!(!a.iter().all(|&x| x > 2));
    /// ```
    ///
    /// Pagtigil sa unang `false`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(!iter.all(|&x| x != 2));
    ///
    /// // maaari pa rin naming gamitin `iter`, tulad ng may mga mas elemento.
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    ///
    ///
    #[doc(alias = "every")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn all<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::CONTINUE } else { ControlFlow::BREAK }
            }
        }
        self.try_fold((), check(f)) == ControlFlow::CONTINUE
    }

    /// Pagsusuri kung anumang elemento ng iterator ay tumutugma sa isang tambalan.
    ///
    /// `any()` tumatagal ng isang pagsasara na nagbabalik `true` o `false`.Nalalapat ito ito pagsasara sa bawat elemento ng iterator, at kung anuman sa mga ito bumalik `true`, at pagkatapos ay sa gayon ay `any()`.
    /// Kung ito ang lahat ng bumalik `false`, ito ay nagbabalik `false`.
    ///
    /// `any()` ay short circuit;sa madaling salita, ititigil nito ang pagproseso sa sandaling makahanap ito ng isang `true`, na ibinigay na anuman ang mangyari, ang resulta ay magiging `true` din.
    ///
    ///
    /// Isang walang laman na iterator nagbabalik `false`.
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().any(|&x| x > 0));
    ///
    /// assert!(!a.iter().any(|&x| x > 5));
    /// ```
    ///
    /// Pagtigil sa unang `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(iter.any(|&x| x != 2));
    ///
    /// // maaari pa rin naming gamitin `iter`, tulad ng may mga mas elemento.
    /// assert_eq!(iter.next(), Some(&2));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn any<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::BREAK } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(f)) == ControlFlow::BREAK
    }

    /// Naghahanap ng isang elemento ng isang iterator na nagbibigay-kasiyahan sa isang panaguri.
    ///
    /// `find()` tumatagal ng isang pagsasara na nagbabalik ng `true` o `false`.
    /// Nalalapat ang pagsasara na ito sa bawat elemento ng iterator, at kung ang alinman sa kanila ay bumalik sa `true`, pagkatapos ay ibabalik ng `find()` ang [`Some(element)`].
    /// Kung ibinalik nilang lahat ang `false`, ibabalik nito ang [`None`].
    ///
    /// `find()` ay maikling-circuiting;sa madaling salita, ititigil nito ang pagproseso sa sandaling ibalik ng pagsara ang `true`.
    ///
    /// Dahil `find()` tumatagal ng isang reference, at marami iterators umulit sa paglipas ng mga sanggunian, ito leads sa isang posibleng nakalilito sitwasyon kung saan ang argument ay isang dobleng pagtukoy.
    ///
    /// Maaari mong makita ang epektong ito sa mga halimbawa sa ibaba, na may `&&x`.
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 5), None);
    /// ```
    ///
    /// Pagtigil sa unang `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.find(|&&x| x == 2), Some(&2));
    ///
    /// // maaari pa rin naming gamitin `iter`, tulad ng may mga mas elemento.
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    /// Tandaan na ang `iter.find(f)` ay katumbas ng `iter.filter(f).next()`.
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn find<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(predicate)).break_value()
    }

    /// Nalalapat ang paggana sa mga elemento ng iterator at ibinabalik ang unang hindi resulta na wala.
    ///
    ///
    /// `iter.find_map(f)` ay katumbas ng `iter.filter_map(f).next()`.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ["lol", "NaN", "2", "5"];
    ///
    /// let first_number = a.iter().find_map(|s| s.parse().ok());
    ///
    /// assert_eq!(first_number, Some(2));
    /// ```
    #[inline]
    #[stable(feature = "iterator_find_map", since = "1.30.0")]
    fn find_map<B, F>(&mut self, f: F) -> Option<B>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        #[inline]
        fn check<T, B>(mut f: impl FnMut(T) -> Option<B>) -> impl FnMut((), T) -> ControlFlow<B> {
            move |(), x| match f(x) {
                Some(x) => ControlFlow::Break(x),
                None => ControlFlow::CONTINUE,
            }
        }

        self.try_fold((), check(f)).break_value()
    }

    /// Nalalapat function na ang mga elemento ng iterator at nagbabalik ang unang tunay na resulta o ang unang error.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_find)]
    ///
    /// let a = ["1", "2", "lol", "NaN", "5"];
    ///
    /// let is_my_num = |s: &str, search: i32| -> Result<bool, std::num::ParseIntError> {
    ///     Ok(s.parse::<i32>()?  == search)
    /// };
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 2));
    /// assert_eq!(result, Ok(Some(&"2")));
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 5));
    /// assert!(result.is_err());
    /// ```
    #[inline]
    #[unstable(feature = "try_find", reason = "new API", issue = "63178")]
    fn try_find<F, R>(&mut self, f: F) -> Result<Option<Self::Item>, R::Error>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> R,
        R: Try<Ok = bool>,
    {
        #[inline]
        fn check<F, T, R>(mut f: F) -> impl FnMut((), T) -> ControlFlow<Result<T, R::Error>>
        where
            F: FnMut(&T) -> R,
            R: Try<Ok = bool>,
        {
            move |(), x| match f(&x).into_result() {
                Ok(false) => ControlFlow::CONTINUE,
                Ok(true) => ControlFlow::Break(Ok(x)),
                Err(x) => ControlFlow::Break(Err(x)),
            }
        }

        self.try_fold((), check(f)).break_value().transpose()
    }

    /// Mga paghahanap para sa isang elemento sa isang iterator, mga bumabalik na index nito.
    ///
    /// `position()` tumatagal ng isang pagsasara na nagbabalik ng `true` o `false`.
    /// Nalalapat ang pagsasara na ito sa bawat elemento ng iterator, at kung ang isa sa kanila ay nagbabalik ng `true`, pagkatapos ay ibabalik ng `position()` ang [`Some(index)`].
    /// Kung ang lahat ng mga ito bumalik `false`, ito ay nagbabalik [`None`].
    ///
    /// `position()` ay maikling-circuiting;sa ibang salita, ito ay titigil sa pagpoproseso ng sa lalong madaling nahahanap nito ang isang `true`.
    ///
    /// # Overflow na Pag-uugali
    ///
    /// Ang pamamaraan ay hindi gumagawa ng pagguguwardiya laban overflows, kaya kung may mga higit sa [`usize::MAX`] walang katugmang mga sangkap, ito ay alinman gumagawa ng maling resulta o panics.
    ///
    /// Kung pinagana ang mga assertion ng pag-debug, garantisado ang isang panic.
    ///
    /// # Panics
    ///
    /// Function na ito ay maaaring panic kung ang iterator ay may higit sa `usize::MAX` walang katugmang mga elemento.
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().position(|&x| x == 2), Some(1));
    ///
    /// assert_eq!(a.iter().position(|&x| x == 5), None);
    /// ```
    ///
    /// Pagtigil sa unang `true`:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.position(|&x| x >= 2), Some(1));
    ///
    /// // maaari pa rin naming gamitin `iter`, tulad ng may mga mas elemento.
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // Ang ibinalik na indeks ay nakasalalay sa estado ng iterator
    /// assert_eq!(iter.position(|&x| x == 4), Some(0));
    ///
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn position<P>(&mut self, predicate: P) -> Option<usize>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            #[rustc_inherit_overflow_checks]
            move |i, x| {
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i + 1) }
            }
        }

        self.try_fold(0, check(predicate)).break_value()
    }

    /// Mga paghahanap para sa isang elemento sa isang iterator mula sa kanan, mga bumabalik na index nito.
    ///
    /// `rposition()` tumatagal ng isang pagsasara na nagbabalik ng `true` o `false`.
    /// Nalalapat ito ito pagsasara sa bawat elemento ng iterator, na nagsisimula mula sa dulo, at kung ang isa sa kanila ay bumalik `true`, pagkatapos `rposition()` nagbabalik [`Some(index)`].
    ///
    /// Kung ang lahat ng mga ito bumalik `false`, ito ay nagbabalik [`None`].
    ///
    /// `rposition()` ay maikling-circuiting;sa ibang salita, ito ay titigil sa pagpoproseso ng sa lalong madaling nahahanap nito ang isang `true`.
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 3), Some(2));
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 5), None);
    /// ```
    ///
    /// Pagtigil sa unang `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rposition(|&x| x == 2), Some(1));
    ///
    /// // maaari pa rin naming gamitin `iter`, tulad ng may mga mas elemento.
    /// assert_eq!(iter.next(), Some(&1));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rposition<P>(&mut self, predicate: P) -> Option<usize>
    where
        P: FnMut(Self::Item) -> bool,
        Self: Sized + ExactSizeIterator + DoubleEndedIterator,
    {
        // Hindi na kailangang para sa isang overflow check dito, dahil `ExactSizeIterator` nagpapahiwatig na ang bilang ng mga elemento Tama ang sukat sa isang `usize`.
        //
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            move |i, x| {
                let i = i - 1;
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i) }
            }
        }

        let n = self.len();
        self.try_rfold(n, check(predicate)).break_value()
    }

    /// Ibinabalik ang pinakamataas na elemento ng isang iterator.
    ///
    /// Kung maraming elemento ang pantay na maximum, ang huling elemento ay naibalik.
    /// Kung ang iterator ay walang laman, [`None`] ay ibinalik.
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().max(), Some(&3));
    /// assert_eq!(b.iter().max(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn max(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.max_by(Ord::cmp)
    }

    /// Ibinabalik ang minimum na elemento ng isang iterator.
    ///
    /// Kung ang ilang mga elemento ay pare-parehong minimum, ang unang elemento ay ibinalik.
    /// Kung ang iterator ay walang laman, [`None`] ay ibinalik.
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().min(), Some(&1));
    /// assert_eq!(b.iter().min(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn min(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.min_by(Ord::cmp)
    }

    /// Ibinabalik ang sangkap na nagbibigay ng maximum na halaga mula sa tinukoy na function.
    ///
    ///
    /// Kung maraming elemento ang pantay na maximum, ang huling elemento ay naibalik.
    /// Kung ang iterator ay walang laman, [`None`] ay ibinalik.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by_key(|x| x.abs()).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn max_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).max_by(compare)?;
        Some(x)
    }

    /// Ibinabalik ang sangkap na nagbibigay ng pinakamataas na halaga na may paggalang sa mga tinukoy na function na paghahambing.
    ///
    ///
    /// Kung maraming elemento ang pantay na maximum, ang huling elemento ay naibalik.
    /// Kung ang iterator ay walang laman, [`None`] ay ibinalik.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by(|x, y| x.cmp(y)).unwrap(), 5);
    /// ```
    #[inline]
    #[stable(feature = "iter_max_by", since = "1.15.0")]
    fn max_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::max_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// Ibinabalik ang elemento na nagbibigay ng minimum na halaga mula sa tinukoy na pagpapaandar.
    ///
    ///
    /// Kung ang ilang mga elemento ay pare-parehong minimum, ang unang elemento ay ibinalik.
    /// Kung ang iterator ay walang laman, [`None`] ay ibinalik.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by_key(|x| x.abs()).unwrap(), 0);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn min_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).min_by(compare)?;
        Some(x)
    }

    /// Ibinabalik ang elemento na nagbibigay ng minimum na halaga na patungkol sa tinukoy na pagpapaandar ng paghahambing.
    ///
    ///
    /// Kung ang ilang mga elemento ay pare-parehong minimum, ang unang elemento ay ibinalik.
    /// Kung ang iterator ay walang laman, [`None`] ay ibinalik.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by(|x, y| x.cmp(y)).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_min_by", since = "1.15.0")]
    fn min_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::min_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// Reverses direksyon ng isang iterator ni.
    ///
    /// Karaniwan, iterators umulit mula kaliwa papuntang kanan.
    /// Matapos gamitin ang `rev()`, isang iterator ay sa halip ay umulit mula kanan hanggang kaliwa.
    ///
    /// Ito ay posible lamang kung ang iterator ay may katapusan, kaya `rev()` gumagana lamang sa [`DoubleEndedIterator`] s.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().rev();
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[doc(alias = "reverse")]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rev(self) -> Rev<Self>
    where
        Self: Sized + DoubleEndedIterator,
    {
        Rev::new(self)
    }

    /// Kino-convert ng isang iterator ng mga pares sa isang pares ng mga lalagyan.
    ///
    /// `unzip()` consumes isang buong iterator ng mga pares, na gumagawa ng dalawang mga koleksyon: ang isa mula sa kaliwang elemento ng mga pares, at isa mula sa kanang elemento.
    ///
    ///
    /// Function na ito ay, sa ilang mga kahulugan, ang kabaligtaran ng [`zip`].
    ///
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// let a = [(1, 2), (3, 4)];
    ///
    /// let (left, right): (Vec<_>, Vec<_>) = a.iter().cloned().unzip();
    ///
    /// assert_eq!(left, [1, 3]);
    /// assert_eq!(right, [2, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn unzip<A, B, FromA, FromB>(self) -> (FromA, FromB)
    where
        FromA: Default + Extend<A>,
        FromB: Default + Extend<B>,
        Self: Sized + Iterator<Item = (A, B)>,
    {
        fn extend<'a, A, B>(
            ts: &'a mut impl Extend<A>,
            us: &'a mut impl Extend<B>,
        ) -> impl FnMut((), (A, B)) + 'a {
            move |(), (t, u)| {
                ts.extend_one(t);
                us.extend_one(u);
            }
        }

        let mut ts: FromA = Default::default();
        let mut us: FromB = Default::default();

        let (lower_bound, _) = self.size_hint();
        if lower_bound > 0 {
            ts.extend_reserve(lower_bound);
            us.extend_reserve(lower_bound);
        }

        self.fold((), extend(&mut ts, &mut us));

        (ts, us)
    }

    /// Lumilikha ng isang iterator na kopya ng lahat ng mga elemento nito.
    ///
    /// Ito ay kapaki-pakinabang kapag ikaw ay may isang iterator higit `&T`, ngunit kailangan mo ng isang iterator higit `T`.
    ///
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_copied: Vec<_> = a.iter().copied().collect();
    ///
    /// // ang nakopya ay kapareho ng .map(|&x| x)
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_copied, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "iter_copied", since = "1.36.0")]
    fn copied<'a, T: 'a>(self) -> Copied<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Copy,
    {
        Copied::new(self)
    }

    /// Lumilikha ng isang iterator kung aling [`clone`] ang lahat ng mga elemento nito.
    ///
    /// Ito ay kapaki-pakinabang kapag ikaw ay may isang iterator higit `&T`, ngunit kailangan mo ng isang iterator higit `T`.
    ///
    ///
    /// [`clone`]: Clone::clone
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_cloned: Vec<_> = a.iter().cloned().collect();
    ///
    /// // Cloned ay katulad ng .map(|&x| x), para sa integer
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_cloned, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn cloned<'a, T: 'a>(self) -> Cloned<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Clone,
    {
        Cloned::new(self)
    }

    /// Umuulit ng isang umuulit na walang katapusan.
    ///
    /// Sa halip ng pagpapahinto sa [`None`], ang iterator sa halip ay simulan muli, mula sa simula.Pagkatapos iterating muli, ito ay simulan sa simula muli.At muli.
    /// At muli.
    /// Forever.
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut it = a.iter().cycle();
    ///
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    fn cycle(self) -> Cycle<Self>
    where
        Self: Sized + Clone,
    {
        Cycle::new(self)
    }

    /// Sums ang elemento ng isang iterator.
    ///
    /// Kinukuha ang bawat elemento, idinagdag ang mga ito nang magkasama, at ibinabalik ang resulta.
    ///
    /// Ang isang walang laman na iterator ay nagbabalik ng zero na halaga ng uri.
    ///
    /// # Panics
    ///
    /// Kapag ang pagtawag sa `sum()` at isang uri ng primitive na integer ay ibinalik, ang pamamaraang ito ay panic kung ang pag-overflow ng pagkalkula at pag-assuger ng pag-debug ay pinagana.
    ///
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let sum: i32 = a.iter().sum();
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn sum<S>(self) -> S
    where
        Self: Sized,
        S: Sum<Self::Item>,
    {
        Sum::sum(self)
    }

    /// Iterates sa buong iterator, multiply lahat ng mga elemento
    ///
    /// Ang isang walang laman na iterator ay nagbabalik ng isang halaga ng uri.
    ///
    /// # Panics
    ///
    /// Kapag ang pagtawag sa `product()` at isang uri ng primitive na integer ay ibinalik, ang pamamaraan ay panic kung ang pag-overflow ng pagkalkula at pag-assuger ng pag-debug ay pinagana.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// fn factorial(n: u32) -> u32 {
    ///     (1..=n).product()
    /// }
    /// assert_eq!(factorial(0), 1);
    /// assert_eq!(factorial(1), 1);
    /// assert_eq!(factorial(5), 120);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn product<P>(self) -> P
    where
        Self: Sized,
        P: Product<Self::Item>,
    {
        Product::product(self)
    }

    /// [Lexicographically](Ord#lexicographical-comparison) pinagkukumpara ang elemento ng [`Iterator`] doon sa isa pa.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1].iter().cmp([1].iter()), Ordering::Equal);
    /// assert_eq!([1].iter().cmp([1, 2].iter()), Ordering::Less);
    /// assert_eq!([1, 2].iter().cmp([1].iter()), Ordering::Greater);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn cmp<I>(self, other: I) -> Ordering
    where
        I: IntoIterator<Item = Self::Item>,
        Self::Item: Ord,
        Self: Sized,
    {
        self.cmp_by(other, |x, y| x.cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) Kinukumpara ang mga elemento ng [`Iterator`] na ito sa iba pang patungkol sa tinukoy na pagpapaandar ng paghahambing.
    ///
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| x.cmp(&y)), Ordering::Less);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (x * x).cmp(&y)), Ordering::Equal);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (2 * x).cmp(&y)), Ordering::Greater);
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn cmp_by<I, F>(mut self, other: I, mut cmp: F) -> Ordering
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Ordering,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Ordering::Equal;
                    } else {
                        return Ordering::Less;
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Ordering::Greater,
                Some(val) => val,
            };

            match cmp(x, y) {
                Ordering::Equal => (),
                non_eq => return non_eq,
            }
        }
    }

    /// [Lexicographically](Ord#lexicographical-comparison) pinagkukumpara ang elemento ng [`Iterator`] doon sa isa pa.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1.].iter().partial_cmp([1.].iter()), Some(Ordering::Equal));
    /// assert_eq!([1.].iter().partial_cmp([1., 2.].iter()), Some(Ordering::Less));
    /// assert_eq!([1., 2.].iter().partial_cmp([1.].iter()), Some(Ordering::Greater));
    ///
    /// assert_eq!([f64::NAN].iter().partial_cmp([1.].iter()), None);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn partial_cmp<I>(self, other: I) -> Option<Ordering>
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp_by(other, |x, y| x.partial_cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) Kinukumpara ang mga elemento ng [`Iterator`] na ito sa iba pang patungkol sa tinukoy na pagpapaandar ng paghahambing.
    ///
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1.0, 2.0, 3.0, 4.0];
    /// let ys = [1.0, 4.0, 9.0, 16.0];
    ///
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| x.partial_cmp(&y)),
    ///     Some(Ordering::Less)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (x * x).partial_cmp(&y)),
    ///     Some(Ordering::Equal)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (2.0 * x).partial_cmp(&y)),
    ///     Some(Ordering::Greater)
    /// );
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn partial_cmp_by<I, F>(mut self, other: I, mut partial_cmp: F) -> Option<Ordering>
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Option<Ordering>,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Some(Ordering::Equal);
                    } else {
                        return Some(Ordering::Less);
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Some(Ordering::Greater),
                Some(val) => val,
            };

            match partial_cmp(x, y) {
                Some(Ordering::Equal) => (),
                non_eq => return non_eq,
            }
        }
    }

    /// Tinutukoy kung ang mga elemento ng mga ito [`Iterator`] kapantay ng pangangalagang ng isa pa.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().eq([1].iter()), true);
    /// assert_eq!([1].iter().eq([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn eq<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        self.eq_by(other, |x, y| x == y)
    }

    /// Tinutukoy kung ang mga elemento ng mga ito [`Iterator`] ay katumbas ng mga ng ibang may paggalang sa tinukoy na function na pagkakapantay-pantay.
    ///
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert!(xs.iter().eq_by(&ys, |&x, &y| x * x == y));
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn eq_by<I, F>(mut self, other: I, mut eq: F) -> bool
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> bool,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => return other.next().is_none(),
                Some(val) => val,
            };

            let y = match other.next() {
                None => return false,
                Some(val) => val,
            };

            if !eq(x, y) {
                return false;
            }
        }
    }

    /// Tinutukoy kung ang mga elemento ng mga ito [`Iterator`] ay hindi patas sa mga ng isa pa.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ne([1].iter()), false);
    /// assert_eq!([1].iter().ne([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ne<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        !self.eq(other)
    }

    /// Tinutukoy kung ang mga elemento ng mga ito [`Iterator`] ay [lexicographically](Ord#lexicographical-comparison) mas mababa kaysa sa mga ng isa pa.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().lt([1].iter()), false);
    /// assert_eq!([1].iter().lt([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().lt([1].iter()), false);
    /// assert_eq!([1, 2].iter().lt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn lt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Less)
    }

    /// Tinutukoy kung ang mga elemento ng mga ito [`Iterator`] ay [lexicographically](Ord#lexicographical-comparison) mas mababa o katumbas sa mga ng isa pa.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().le([1].iter()), true);
    /// assert_eq!([1].iter().le([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().le([1].iter()), false);
    /// assert_eq!([1, 2].iter().le([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn le<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Less | Ordering::Equal))
    }

    /// Tinutukoy kung ang mga elemento ng mga ito [`Iterator`] ay [lexicographically](Ord#lexicographical-comparison) mas malaki kaysa sa mga ng isa pa.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().gt([1].iter()), false);
    /// assert_eq!([1].iter().gt([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().gt([1].iter()), true);
    /// assert_eq!([1, 2].iter().gt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn gt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Greater)
    }

    /// Tinutukoy kung ang mga elemento ng mga ito [`Iterator`] ay [lexicographically](Ord#lexicographical-comparison) mas malaki kaysa sa o katumbas ng sa mga ng isa pa.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ge([1].iter()), true);
    /// assert_eq!([1].iter().ge([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().ge([1].iter()), true);
    /// assert_eq!([1, 2].iter().ge([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ge<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Greater | Ordering::Equal))
    }

    /// Ang mga tseke kung ang mga elemento ng iterator na ito ay nakaayos.
    ///
    /// Iyon ay, para sa bawat elemento `a` at ang mga sumusunod na sangkap `b`, `a <= b` dapat i-hold.Kung ang iterator ay magbubunga ng eksaktong zero o isa element, `true` ay ibinalik.
    ///
    /// Tandaan na kung ang `Self::Item` ay `PartialOrd` lamang, ngunit hindi `Ord`, ang kahulugan sa itaas ay nagpapahiwatig na ang pagpapaandar na ito ay nagbabalik ng `false` kung ang anumang dalawang magkakasunod na item ay hindi maihahambing.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted());
    /// assert!(![1, 3, 2, 4].iter().is_sorted());
    /// assert!([0].iter().is_sorted());
    /// assert!(std::iter::empty::<i32>().is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted(self) -> bool
    where
        Self: Sized,
        Self::Item: PartialOrd,
    {
        self.is_sorted_by(PartialOrd::partial_cmp)
    }

    /// Sinusuri kung ang mga elemento ng iterator na ito ay pinagsunod-sunod gamit ang ibinigay na pagpapaandar na kumpare.
    ///
    /// Sa halip ng paggamit `PartialOrd::partial_cmp`, function na ito ay gumagamit ng mga ibinigay na `compare` function na upang matukoy ang pagkakasunud-sunod ng dalawang elemento.
    /// Bukod sa na, katumbas ng [`is_sorted`];makita ang mga papeles para sa karagdagang impormasyon.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![1, 3, 2, 4].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!([0].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(std::iter::empty::<i32>().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// ```
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by<F>(mut self, compare: F) -> bool
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Option<Ordering>,
    {
        #[inline]
        fn check<'a, T>(
            last: &'a mut T,
            mut compare: impl FnMut(&T, &T) -> Option<Ordering> + 'a,
        ) -> impl FnMut(T) -> bool + 'a {
            move |curr| {
                if let Some(Ordering::Greater) | None = compare(&last, &curr) {
                    return false;
                }
                *last = curr;
                true
            }
        }

        let mut last = match self.next() {
            Some(e) => e,
            None => return true,
        };

        self.all(check(&mut last, compare))
    }

    /// Sinusuri kung ang mga elemento ng iterator na ito ay pinagsunod-sunod gamit ang ibinigay na key function na pagkuha.
    ///
    /// Sa halip na ihambing nang direkta ang mga elemento ng iterator, inihahambing ng pagpapaandar na ito ang mga susi ng mga elemento, na tinutukoy ng `f`.
    /// Bukod sa na, katumbas ng [`is_sorted`];makita ang mga papeles para sa karagdagang impormasyon.
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].iter().is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].iter().is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by_key<F, K>(self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> K,
        K: PartialOrd,
    {
        self.map(f).is_sorted()
    }

    /// Tingnan ang [TrustedRandomAccess]
    // Ang hindi karaniwang pangalan ko ay upang maiwasan ang mga pangalan banggaan sa method resolution makita #76479.
    //
    #[inline]
    #[doc(hidden)]
    #[unstable(feature = "trusted_random_access", issue = "none")]
    unsafe fn __iterator_get_unchecked(&mut self, _idx: usize) -> Self::Item
    where
        Self: TrustedRandomAccess,
    {
        unreachable!("Always specialized");
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator + ?Sized> Iterator for &mut I {
    type Item = I::Item;
    fn next(&mut self) -> Option<I::Item> {
        (**self).next()
    }
    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_by(n)
    }
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        (**self).nth(n)
    }
}