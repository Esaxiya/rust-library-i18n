use crate::ops::{ControlFlow, Try};

/// Ang isang iterator magagawang elemento ani mula sa parehong dulo.
///
/// Ang isang bagay na nagpapatupad ng `DoubleEndedIterator` ay may isang labis na kakayahan sa isang bagay na nagpapatupad ng [`Iterator`]: ang kakayahang kumuha din ng mga `Item` mula sa likuran, pati na rin sa harap.
///
///
/// Ito ay mahalaga upang tandaan na ang parehong lipat ng trabaho sa parehong hanay, at hindi cross:-ulit ay higit sa kapag sila ay matugunan sa gitna.
///
/// Sa isang katulad na fashion sa [`Iterator`] protocol, isang beses sa isang `DoubleEndedIterator` nagbabalik [`None`] mula sa isang [`next_back()`], pagtawag ito muli ay maaaring o hindi maaaring kailanman bumalik [`Some`] muli.
/// [`next()`] at [`next_back()`] ay mapagpapalit para sa layuning ito.
///
/// [`next_back()`]: DoubleEndedIterator::next_back
/// [`next()`]: Iterator::next
///
/// # Examples
///
/// Pangunahing paggamit:
///
/// ```
/// let numbers = vec![1, 2, 3, 4, 5, 6];
///
/// let mut iter = numbers.iter();
///
/// assert_eq!(Some(&1), iter.next());
/// assert_eq!(Some(&6), iter.next_back());
/// assert_eq!(Some(&5), iter.next_back());
/// assert_eq!(Some(&2), iter.next());
/// assert_eq!(Some(&3), iter.next());
/// assert_eq!(Some(&4), iter.next());
/// assert_eq!(None, iter.next());
/// assert_eq!(None, iter.next_back());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DoubleEndedIterator: Iterator {
    /// Tanggalin at ibabalik ang isang elemento mula sa dulo ng iterator.
    ///
    /// Ibinabalik `None` kapag wala nang mga elemento.
    ///
    /// Ang [trait-level] docs maglaman ng higit pang mga detalye.
    ///
    /// [trait-level]: DoubleEndedIterator
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// let numbers = vec![1, 2, 3, 4, 5, 6];
    ///
    /// let mut iter = numbers.iter();
    ///
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&6), iter.next_back());
    /// assert_eq!(Some(&5), iter.next_back());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    /// assert_eq!(Some(&4), iter.next());
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next_back());
    /// ```
    ///
    /// # Remarks
    ///
    /// Ang mga elemento nailabas ng `ni DoubleEndedIterator` pamamaraan ay maaaring naiiba mula sa mga nailabas ng [`Iterator`] 's pamamaraan:
    ///
    ///
    /// ```
    /// let vec = vec![(1, 'a'), (1, 'b'), (1, 'c'), (2, 'a'), (2, 'b')];
    /// let uniq_by_fst_comp = || {
    ///     let mut seen = std::collections::HashSet::new();
    ///     vec.iter().copied().filter(move |x| seen.insert(x.0))
    /// };
    ///
    /// assert_eq!(uniq_by_fst_comp().last(), Some((2, 'a')));
    /// assert_eq!(uniq_by_fst_comp().next_back(), Some((2, 'b')));
    ///
    /// assert_eq!(
    ///     uniq_by_fst_comp().fold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(1, 'a'), (2, 'a')]
    /// );
    /// assert_eq!(
    ///     uniq_by_fst_comp().rfold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(2, 'b'), (1, 'c')]
    /// );
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next_back(&mut self) -> Option<Self::Item>;

    /// Isusulong ang iterator mula sa likuran ng mga elemento ng `n`.
    ///
    /// `advance_back_by` ay ang reverse bersyon ng [`advance_by`].Ang pamamaraan na ito ay sabik na laktawan ang mga elemento `n` nagsisimula mula sa likod sa pamamagitan ng pagtawag [`next_back`] hanggang sa `n` beses hanggang [`None`] ay nakatagpo.
    ///
    /// `advance_back_by(n)` ay babalik [`Ok(())`] kung ang iterator matagumpay na advances sa pamamagitan `n` elemento, o [`Err(k)`] kung [`None`] ay nakatagpo, kung saan `k` ay ang bilang ng mga elemento ng iterator ay advanced sa pamamagitan ng bago nauubusan ng mga sangkap (ibig sabihin,
    /// ang haba ng iterator).
    /// Tandaan na ang `k` ay palaging mas mababa sa `n`.
    ///
    /// Calling `advance_back_by(0)` ay hindi ubusin ang anumang mga elemento at laging nagbabalik [`Ok(())`].
    ///
    /// [`advance_by`]: Iterator::advance_by
    /// [`next_back`]: DoubleEndedIterator::next_back
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [3, 4, 5, 6];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_back_by(2), Ok(()));
    /// assert_eq!(iter.next_back(), Some(&4));
    /// assert_eq!(iter.advance_back_by(0), Ok(()));
    /// assert_eq!(iter.advance_back_by(100), Err(1)); // lamang `&3` ay nilaktawan
    /// ```
    ///
    /// [`Ok(())`]: Ok
    /// [`Err(k)`]: Err
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next_back().ok_or(i)?;
        }
        Ok(())
    }

    /// Ibinabalik ang `n`th na elemento mula sa dulo ng iterator.
    ///
    /// Mahalaga ito ang baligtad na bersyon ng [`Iterator::nth()`].
    /// Kahit na tulad ng karamihan sa mga pagpapatakbo ng pag-index, ang count ay nagsisimula mula sa zero, kaya `nth_back(0)` nagbalik sa unang halaga mula sa dulo, `nth_back(1)` ang pangalawa, at iba pa.
    ///
    ///
    /// Tandaan na ang lahat ng mga elemento sa pagitan ng dulo at ang naibalik na elemento ay matupok, kasama ang naibalik na elemento.
    /// Ito ay nangangahulugan din na ang pagtawag `nth_back(0)` maraming beses sa parehong iterator ay babalik iba't ibang mga elemento.
    ///
    /// `nth_back()` ay babalik [`None`] kung `n` ay mas malaki kaysa sa o katumbas ng haba ng iterator.
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(2), Some(&1));
    /// ```
    ///
    /// Calling `nth_back()` maraming beses ay hindi rewind ang iterator:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth_back(1), Some(&2));
    /// assert_eq!(iter.nth_back(1), None);
    /// ```
    ///
    /// Pagbabalik ng `None` kung mayroong mas mababa sa `n + 1` na mga elemento:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(10), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_nth_back", since = "1.37.0")]
    fn nth_back(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_back_by(n).ok()?;
        self.next_back()
    }

    /// Ito ang reverse bersyon ng [`Iterator::try_fold()`]: ito ay tumatagal ng mga sangkap na nagsisimula mula sa likod ng iterator.
    ///
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// let a = ["1", "2", "3"];
    /// let sum = a.iter()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert_eq!(sum, Ok(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = ["1", "rust", "3"];
    /// let mut it = a.iter();
    /// let sum = it
    ///     .by_ref()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert!(sum.is_err());
    ///
    /// // Dahil ito ay umikli sa sirkito, ang mga natitirang elemento ay magagamit pa rin sa pamamagitan ng iterator.
    /////
    /// assert_eq!(it.next_back(), Some(&"1"));
    /// ```
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// Isang pamamaraang iterator na binabawasan ang mga elemento ng iterator sa isang solong, pangwakas na halaga, na nagsisimula sa likuran.
    ///
    /// Ito ang reverse bersyon ng [`Iterator::fold()`]: tumatagal ng mga elemento na nagsisimula sa likod ng iterator.
    ///
    /// `rfold()` tumatagal ng dalawang mga argumento: isang paunang halaga, at isang pagsasara na may dalawang mga argumento: isang 'accumulator', at isang elemento.
    /// Ibinabalik ng pagsara ang halaga na dapat magkaroon ng nagtitipid para sa susunod na pag-ulit.
    ///
    /// Ang paunang halaga ay ang halaga nagtitipon ay magkakaroon sa unang tawag.
    ///
    /// Pagkatapos ng paglalapat ng pagsasara sa bawat elemento ng iterator, `rfold()` nagbabalik ng nagtitipon.
    ///
    /// Ang operasyon na ito ay minsang tinatawag 'reduce' o 'inject'.
    ///
    /// Folding ay kapaki-pakinabang sa tuwing mayroon kang isang koleksyon ng mga bagay, at nais upang makabuo ng isang solong halaga mula sa mga ito.
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // ang kabuuan ng lahat ng mga elemento ng a
    /// let sum = a.iter()
    ///            .rfold(0, |acc, &x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// Ang halimbawang ito ay nagbubuo mula sa isang string, na nagsisimula sa isang paunang halaga at magpatuloy sa bawat elemento mula sa likod hanggang sa harap:
    ///
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let zero = "0".to_string();
    ///
    /// let result = numbers.iter().rfold(zero, |acc, &x| {
    ///     format!("({} + {})", x, acc)
    /// });
    ///
    /// assert_eq!(result, "(1 + (2 + (3 + (4 + (5 + 0)))))");
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfold", since = "1.27.0")]
    fn rfold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x);
        }
        accum
    }

    /// Naghahanap ng isang elemento ng isang iterator mula sa likuran na nagbibigay-kasiyahan sa isang panaguri.
    ///
    /// `rfind()` tumatagal ng isang pagsasara na nagbabalik ng `true` o `false`.
    /// Nalalapat ito ito pagsasara sa bawat elemento ng iterator, simula sa dulo, at kung anuman sa mga ito bumalik `true`, pagkatapos `rfind()` nagbabalik [`Some(element)`].
    /// Kung ibinalik nilang lahat ang `false`, ibabalik nito ang [`None`].
    ///
    /// `rfind()` ay maikling-circuiting;sa madaling salita, ititigil nito ang pagproseso sa sandaling ibalik ng pagsara ang `true`.
    ///
    /// Sapagkat ang `rfind()` ay kumukuha ng isang sanggunian, at maraming mga iterator ang umuulit sa mga sanggunian, humantong ito sa isang posibleng nakalilito na sitwasyon kung saan ang pagtatalo ay isang dobleng sanggunian.
    ///
    /// Maaari mong makita ang epektong ito sa mga halimbawa sa ibaba, na may `&&x`.
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 5), None);
    /// ```
    ///
    /// Pagtigil sa unang `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rfind(|&&x| x == 2), Some(&2));
    ///
    /// // maaari pa rin naming gamitin `iter`, tulad ng may mga mas elemento.
    /// assert_eq!(iter.next_back(), Some(&1));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfind", since = "1.27.0")]
    fn rfind<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_rfold((), check(predicate)).break_value()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, I: DoubleEndedIterator + ?Sized> DoubleEndedIterator for &'a mut I {
    fn next_back(&mut self) -> Option<I::Item> {
        (**self).next_back()
    }
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_back_by(n)
    }
    fn nth_back(&mut self, n: usize) -> Option<I::Item> {
        (**self).nth_back(n)
    }
}