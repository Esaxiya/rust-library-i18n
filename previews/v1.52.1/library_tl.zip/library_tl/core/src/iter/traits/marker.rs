/// Ang isang iterator na laging patuloy na nagbubunga `None` kapag ubos na.
///
/// Calling susunod sa isang fused iterator na Nagbalik `None` isang beses ay garantisadong upang bumalik [`None`] muli.
/// Ang trait na ito ay dapat na ipatupad ng lahat ng mga iterator na kumilos sa ganitong paraan sapagkat pinapayagan ang pag-optimize ng [`Iterator::fuse()`].
///
///
/// Note: Sa pangkalahatan, hindi ka dapat gumamit `FusedIterator` sa generic hangganan kung kailangan mo ng isang fused iterator.
/// Sa halip, dapat mo lamang tumawag [`Iterator::fuse()`] sa iterator.
/// Kung ang iterator ay na-fuse na, ang karagdagang [`Fuse`] na pambalot ay magiging isang no-op na walang parusa sa pagganap.
///
/// [`Fuse`]: crate::iter::Fuse
///
#[stable(feature = "fused", since = "1.26.0")]
#[rustc_unsafe_specialization_marker]
pub trait FusedIterator: Iterator {}

#[stable(feature = "fused", since = "1.26.0")]
impl<I: FusedIterator + ?Sized> FusedIterator for &mut I {}

/// Isang iterator na nag-uulat ng isang tumpak na haba gamit ang size_hint.
///
/// Ang iterator ay nag-uulat ng isang sukat ng pahiwatig kung saan ito ay eksaktong (ang ibabang nakatali ay katumbas ng itaas na nakatali), o ang itaas na bono ay [`None`].
///
/// Ang itaas na nakatali ay dapat na [`None`] kung ang aktwal na haba ng iterator ay mas malaki kaysa sa [`usize::MAX`].
/// Sa kasong iyon, ang mas mababang gapos ay dapat na [`usize::MAX`], na nagreresulta sa isang [`Iterator::size_hint()`] ng `(usize::MAX, None)`.
///
/// iterator ay dapat makabuo ng eksakto ang bilang ng mga elemento itong mga iniulat o magkaiba bago maabot ang dulo.
///
/// # Safety
///
/// trait na ito ay dapat lamang ma-ipinatupad kapag ang kontrata ay upheld.
/// Mga mamimili ng mga ito trait dapat siyasatin ang [`Iterator::size_hint()`]’s upper bound.
///
///
///
#[unstable(feature = "trusted_len", issue = "37572")]
#[rustc_unsafe_specialization_marker]
pub unsafe trait TrustedLen: Iterator {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<I: TrustedLen + ?Sized> TrustedLen for &mut I {}

/// Ang isang iterator na kapag walang tutol isang item ay kinuha ng hindi bababa sa isang elemento mula sa napapailalim na [`SourceIter`].
///
/// Calling anumang paraan na advances ang iterator, hal
/// [`next()`] o [`try_fold()`], mga garantiya na ang para sa bawat hakbang ng hindi bababa sa isang halaga ng pinagbabatayan source ang iterator ni ay inilipat out at ang resulta ng iterator chain ay maaaring nakapasok sa lugar nito, ipagpalagay na istruktura hadlang ng source payagan ang ganitong insertion.
///
/// Sa ibang salita ito trait ay nagpapahiwatig na ang isang iterator pipeline makokolekta sa lugar.
///
/// [`SourceIter`]: crate::iter::SourceIter
/// [`next()`]: Iterator::next
/// [`try_fold()`]: Iterator::try_fold
///
///
#[unstable(issue = "none", feature = "inplace_iteration")]
pub unsafe trait InPlaceIterable: Iterator {}