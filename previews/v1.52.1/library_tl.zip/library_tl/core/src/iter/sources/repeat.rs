use crate::iter::{FusedIterator, TrustedLen};

/// Lumilikha ng isang bagong iterator na endlessly uulit ng isang solong elemento.
///
/// Ang pagpapaandar ng `repeat()` ay inuulit ang isang solong halaga nang paulit-ulit.
///
/// Walang-hanggan iterators tulad `repeat()` ay kadalasang ginagamit na may adapters tulad [`Iterator::take()`], upang gawin silang hangganan.
///
/// Kung ang uri ng elemento ng iterator kailangan mo ay hindi ipatupad `Clone`, o kung hindi mo nais na panatilihin ang paulit-ulit na elemento sa memorya, maaari mong gamitin sa halip ng [`repeat_with()`] function.
///
///
/// [`repeat_with()`]: crate::iter::repeat_with
///
/// # Examples
///
/// Pangunahing paggamit:
///
/// ```
/// use std::iter;
///
/// // ang bilang apat 4ever:
/// let mut fours = iter::repeat(4);
///
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
///
/// // yup, apat pa rin
/// assert_eq!(Some(4), fours.next());
/// ```
///
/// Going may hangganan na may [`Iterator::take()`]:
///
/// ```
/// use std::iter;
///
/// // na huling halimbawa ay masyadong maraming mga fours.Mag-apat na lang tayo.
/// let mut four_fours = iter::repeat(4).take(4);
///
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
///
/// // ... at ngayon tapos na kami
/// assert_eq!(None, four_fours.next());
/// ```
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn repeat<T: Clone>(elt: T) -> Repeat<T> {
    Repeat { element: elt }
}

/// Ang isang iterator na repeats isang elemento endlessly.
///
/// Ang `struct` na ito ay nilikha ng pagpapaandar ng [`repeat()`].Tingnan ang dokumentasyon nito para sa higit pa.
#[derive(Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Repeat<A> {
    element: A,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> Iterator for Repeat<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> DoubleEndedIterator for Repeat<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Clone> FusedIterator for Repeat<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Clone> TrustedLen for Repeat<A> {}