use crate::iter::{FusedIterator, TrustedLen};

/// Lumilikha ng isang bagong iterator na uulit elemento ng uri `A` endlessly sa pamamagitan ng paglalapat ang binigay na pagsasara, ang repeater, `F: FnMut() -> A`.
///
/// Ang `repeat_with()` function na tawag sa repeater nang paulit-ulit.
///
/// Ang mga walang katapusang iterator tulad ng `repeat_with()` ay madalas na ginagamit sa mga adaptor tulad ng [`Iterator::take()`], upang mabigyan sila ng wakas.
///
/// Kung ang uri ng elemento ng iterator na kailangan mo ay nagpapatupad ng [`Clone`], at OK lang na panatilihin ang memorya ng pinagmulan, dapat mong gamitin ang [`repeat()`] function.
///
///
/// Ang isang iterator na ginawa ng `repeat_with()` ay hindi isang [`DoubleEndedIterator`].
/// Kung kailangan mo ng `repeat_with()` upang magbalik ng [`DoubleEndedIterator`], mangyaring magbukas ng GitHub isyu na nagpapaliwanag kung ang iyong paggamit kaso.
///
/// [`repeat()`]: crate::iter::repeat
/// [`DoubleEndedIterator`]: crate::iter::DoubleEndedIterator
///
/// # Examples
///
/// Pangunahing paggamit:
///
/// ```
/// use std::iter;
///
/// // ipagpalagay natin na mayroon kaming ilang halaga ng isang uri na hindi `Clone` o na hindi nais na magkaroon ng memorya pa dahil mahal ito:
/////
/// #[derive(PartialEq, Debug)]
/// struct Expensive;
///
/// // isang partikular na halaga magpakailanman:
/// let mut things = iter::repeat_with(|| Expensive);
///
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// ```
///
/// Paggamit ng pagbago at pagtatapos:
///
/// ```rust
/// use std::iter;
///
/// // Mula sa zeroth hanggang sa pangatlong lakas ng dalawa:
/// let mut curr = 1;
/// let mut pow2 = iter::repeat_with(|| { let tmp = curr; curr *= 2; tmp })
///                     .take(4);
///
/// assert_eq!(Some(1), pow2.next());
/// assert_eq!(Some(2), pow2.next());
/// assert_eq!(Some(4), pow2.next());
/// assert_eq!(Some(8), pow2.next());
///
/// // ... at ngayon tapos na kami
/// assert_eq!(None, pow2.next());
/// ```
///
///
///
///
#[inline]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub fn repeat_with<A, F: FnMut() -> A>(repeater: F) -> RepeatWith<F> {
    RepeatWith { repeater }
}

/// Isang iterator na inuulit ang mga elemento ng uri `A` na walang katapusan sa pamamagitan ng paglalapat ng ibinigay na pagsasara `F: FnMut() -> A`.
///
///
/// Ang `struct` na ito ay nilikha ng pagpapaandar ng [`repeat_with()`].
/// Tingnan ang dokumentasyon nito para sa higit pa.
#[derive(Copy, Clone, Debug)]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub struct RepeatWith<F> {
    repeater: F,
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> Iterator for RepeatWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some((self.repeater)())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> FusedIterator for RepeatWith<F> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A, F: FnMut() -> A> TrustedLen for RepeatWith<F> {}