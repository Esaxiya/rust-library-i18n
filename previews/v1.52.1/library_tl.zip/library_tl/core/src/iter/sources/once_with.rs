use crate::iter::{FusedIterator, TrustedLen};

/// Lumilikha ng isang umuulit na tamad na bumubuo ng isang halaga nang eksakto nang isang beses sa pamamagitan ng pagtawag sa ibinigay na pagsasara.
///
/// Ito ay karaniwang ginagamit upang maiakma ang isang solong generator ng halaga sa isang [`chain()`] ng iba pang mga uri ng pag-ulit.
/// Siguro mayroon kang isang iterator na cover halos lahat ng bagay, ngunit kailangan mo ng dagdag na mga espesyal na kaso.
/// Siguro ikaw ay may isang function na kung saan ay gumagana sa iterators, ngunit kailangan mo lamang upang i-proseso ang isang halaga.
///
/// Hindi tulad ng [`once()`], function na ito lazily makabuo ng halaga kapag binanggit.
///
/// [`chain()`]: Iterator::chain
/// [`once()`]: crate::iter::once
///
/// # Examples
///
/// Pangunahing paggamit:
///
/// ```
/// use std::iter;
///
/// // ang isa ay ang loneliest number
/// let mut one = iter::once_with(|| 1);
///
/// assert_eq!(Some(1), one.next());
///
/// // isa lang, yun lang ang nakukuha natin
/// assert_eq!(None, one.next());
/// ```
///
/// Kasama ang kadena sa isa pang iterator.
/// Sabihin natin na nais namin upang umulit sa ibabaw ng bawat file ng `.foo` direktoryo, ngunit din ng isang configuration file,
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // kailangan namin upang i-convert mula sa isang iterator ng DirEntry-s sa isang iterator ng PathBufs, kaya gumagamit kami ng mapa
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // ngayon, ang aming iterator para lamang sa aming config file
/// let config = iter::once_with(|| PathBuf::from(".foorc"));
///
/// // kadena ang dalawang iterators nang magkakasama sa isang malaking iterator
/// let files = dirs.chain(config);
///
/// // ito ay magbibigay sa amin ang lahat ng mga file sa .foo pati na rin .foorc
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
///
#[inline]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub fn once_with<A, F: FnOnce() -> A>(gen: F) -> OnceWith<F> {
    OnceWith { gen: Some(gen) }
}

/// Isang iterator na nagbubunga ng isang solong elemento ng uri `A` sa pamamagitan ng paglalapat ng ibinigay na pagsasara `F: FnOnce() -> A`.
///
///
/// Ang `struct` na ito ay nilikha ng pagpapaandar ng [`once_with()`].
/// Tingnan ang dokumentasyon nito para sa higit pa.
#[derive(Clone, Debug)]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub struct OnceWith<F> {
    gen: Option<F>,
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> Iterator for OnceWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        let f = self.gen.take()?;
        Some(f())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.gen.iter().size_hint()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> DoubleEndedIterator for OnceWith<F> {
    fn next_back(&mut self) -> Option<A> {
        self.next()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> ExactSizeIterator for OnceWith<F> {
    fn len(&self) -> usize {
        self.gen.iter().len()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> FusedIterator for OnceWith<F> {}

#[stable(feature = "iter_once_with", since = "1.43.0")]
unsafe impl<A, F: FnOnce() -> A> TrustedLen for OnceWith<F> {}