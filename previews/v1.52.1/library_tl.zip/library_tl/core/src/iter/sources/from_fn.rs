use crate::fmt;

/// Lumilikha ng isang bagong iterator kung saan ang bawat pag-ulit tawag ang binigay na pagsasara `F: FnMut() -> Option<T>`.
///
/// Ito ay nagpapahintulot sa paglikha ng isang pasadyang iterator sa anumang pag-uugali ng hindi gumagamit ng mas maligoy syntax ng paglikha ng isang dedikadong uri at pagpapatupad ng [`Iterator`] trait para dito.
///
/// Tandaan na ang `FromFn` iterator ay hindi gumawa ng mga pagpapalagay tungkol sa pag-uugali ng pagsasara, at samakatuwid ay sa konserbatibong ay hindi ipatupad [`FusedIterator`], o i-override [`Iterator::size_hint()`] mula sa kanyang default `(0, None)`.
///
///
/// Ang pagsasara ay maaaring gumamit ng mga kuha at sa kapaligiran nito upang subaybayan ang estado sa kabuuan iteration.Depende sa kung paano ang iterator ay ginagamit, ito ay maaaring mangailangan ng pagtukoy sa [`move`] keyword sa pagsasara.
///
/// [`move`]: ../../std/keyword.move.html
/// [`FusedIterator`]: crate::iter::FusedIterator
///
/// # Examples
///
/// Ipatupad ulit ang counter iterator mula sa [module-level documentation]:
///
/// [module-level documentation]: crate::iter
///
/// ```
/// let mut count = 0;
/// let counter = std::iter::from_fn(move || {
///     // Dinagdagan aming count.Ito ay kung bakit namin nagsimula sa zero.
///     count += 1;
///
///     // Suriin upang malaman kung natapos na namin ang pagbibilang o hindi.
///     if count < 6 {
///         Some(count)
///     } else {
///         None
///     }
/// });
/// assert_eq!(counter.collect::<Vec<_>>(), &[1, 2, 3, 4, 5]);
/// ```
///
///
///
///
///
#[inline]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub fn from_fn<T, F>(f: F) -> FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    FromFn(f)
}

/// Isang iterator kung saan ang bawat pag-ulit ay tumatawag sa ibinigay na pagsara ng `F: FnMut() -> Option<T>`.
///
/// Ang `struct` na ito ay nilikha ng pagpapaandar ng [`iter::from_fn()`].
/// Tingnan ang dokumentasyon nito para sa higit pa.
///
/// [`iter::from_fn()`]: from_fn
#[derive(Clone)]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub struct FromFn<F>(F);

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<T, F> Iterator for FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<Self::Item> {
        (self.0)()
    }
}

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<F> fmt::Debug for FromFn<F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("FromFn").finish()
    }
}