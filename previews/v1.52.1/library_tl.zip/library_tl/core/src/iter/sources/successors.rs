use crate::{fmt, iter::FusedIterator};

/// Lumilikha ng isang bagong umuulit kung saan ang bawat sunud-sunod na item ay kinalkula batay sa nauna.
///
/// Nagsisimula ang umuulit sa ibinigay na unang item (kung mayroon man) at tumatawag sa ibinigay na pagsasara ng `FnMut(&T) -> Option<T>` upang makalkula ang kahalili ng bawat item.
///
///
/// ```
/// use std::iter::successors;
///
/// let powers_of_10 = successors(Some(1_u16), |n| n.checked_mul(10));
/// assert_eq!(powers_of_10.collect::<Vec<_>>(), &[1, 10, 100, 1_000, 10_000]);
/// ```
#[stable(feature = "iter_successors", since = "1.34.0")]
pub fn successors<T, F>(first: Option<T>, succ: F) -> Successors<T, F>
where
    F: FnMut(&T) -> Option<T>,
{
    // Kung ang function na ibinalik `impl Iterator<Item=T>` maaari itong batay sa `unfold` at hindi kailangan ng isang dedikado uri.
    //
    // Gayunpaman ang pagkakaroon ng isang pinangalanang uri ng `Successors<T, F>` ay pinapayagan itong maging `Clone` kapag ang `T` at `F` ay.
    Successors { next: first, succ }
}

/// Ang isang bagong iterator kung saan ang bawat sunud-sunod na item ay nakalkula batay sa naunang isa.
///
/// Ang `struct` na ito ay nilikha ng pagpapaandar ng [`iter::successors()`].
/// Tingnan ang dokumentasyon nito para sa higit pa.
///
/// [`iter::successors()`]: successors
#[derive(Clone)]
#[stable(feature = "iter_successors", since = "1.34.0")]
pub struct Successors<T, F> {
    next: Option<T>,
    succ: F,
}

#[stable(feature = "iter_successors", since = "1.34.0")]
impl<T, F> Iterator for Successors<T, F>
where
    F: FnMut(&T) -> Option<T>,
{
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<Self::Item> {
        let item = self.next.take()?;
        self.next = (self.succ)(&item);
        Some(item)
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.next.is_some() { (1, None) } else { (0, Some(0)) }
    }
}

#[stable(feature = "iter_successors", since = "1.34.0")]
impl<T, F> FusedIterator for Successors<T, F> where F: FnMut(&T) -> Option<T> {}

#[stable(feature = "iter_successors", since = "1.34.0")]
impl<T: fmt::Debug, F> fmt::Debug for Successors<T, F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Successors").field("next", &self.next).finish()
    }
}