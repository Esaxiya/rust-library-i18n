/// Ginamit para sa pagpapatakbo ng pag-index (`container[index]`) sa hindi nababago na mga konteksto.
///
/// `container[index]` ay talagang syntactic sugar para sa `*container.index(index)`, ngunit kapag ginamit lamang bilang isang hindi nababago na halaga.
/// Kung ang isang nababagong halaga ay hiniling, [`IndexMut`] ay ginagamit sa halip.
/// Pinapayagan nito ang magagandang bagay tulad ng `let value = v[index]` kung ang uri ng `value` ay nagpapatupad ng [`Copy`].
///
/// # Examples
///
/// Ang sumusunod na halimbawa ay nagpapatupad ng `Index` sa isang read-only `NucleotideCount` na lalagyan, na nagbibigay-daan sa mga indibidwal na bilang na makuha sa index syntax.
///
///
/// ```
/// use std::ops::Index;
///
/// enum Nucleotide {
///     A,
///     C,
///     G,
///     T,
/// }
///
/// struct NucleotideCount {
///     a: usize,
///     c: usize,
///     g: usize,
///     t: usize,
/// }
///
/// impl Index<Nucleotide> for NucleotideCount {
///     type Output = usize;
///
///     fn index(&self, nucleotide: Nucleotide) -> &Self::Output {
///         match nucleotide {
///             Nucleotide::A => &self.a,
///             Nucleotide::C => &self.c,
///             Nucleotide::G => &self.g,
///             Nucleotide::T => &self.t,
///         }
///     }
/// }
///
/// let nucleotide_count = NucleotideCount {a: 14, c: 9, g: 10, t: 12};
/// assert_eq!(nucleotide_count[Nucleotide::A], 14);
/// assert_eq!(nucleotide_count[Nucleotide::C], 9);
/// assert_eq!(nucleotide_count[Nucleotide::G], 10);
/// assert_eq!(nucleotide_count[Nucleotide::T], 12);
/// ```
///
#[lang = "index"]
#[rustc_on_unimplemented(
    message = "the type `{Self}` cannot be indexed by `{Idx}`",
    label = "`{Self}` cannot be indexed by `{Idx}`"
)]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = "]")]
#[doc(alias = "[")]
#[doc(alias = "[]")]
pub trait Index<Idx: ?Sized> {
    /// Ang naibalik na uri pagkatapos ng pag-index.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Output: ?Sized;

    /// Ginagawa ang pagpapatakbo (`container[index]`) na operasyon.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[track_caller]
    fn index(&self, index: Idx) -> &Self::Output;
}

/// Ginamit para sa pagpapatakbo ng pag-index (`container[index]`) sa mga nababagong konteksto.
///
/// `container[index]` ay talagang syntactic sugar para sa `*container.index_mut(index)`, ngunit kapag ginamit lamang bilang isang mutable na halaga.
/// Kung ang isang hindi nababagong halaga ay hiniling, ang [`Index`] trait ay ginagamit sa halip.
/// Pinapayagan nito ang magagandang bagay tulad ng `v[index] = value`.
///
/// # Examples
///
/// Ang isang napaka-simpleng pagpapatupad ng isang `Balance` na istruktura na may dalawang panig, kung saan ang bawat isa ay maaaring ma-index na nabago at hindi nababago.
///
/// ```
/// use std::ops::{Index, IndexMut};
///
/// #[derive(Debug)]
/// enum Side {
///     Left,
///     Right,
/// }
///
/// #[derive(Debug, PartialEq)]
/// enum Weight {
///     Kilogram(f32),
///     Pound(f32),
/// }
///
/// struct Balance {
///     pub left: Weight,
///     pub right: Weight,
/// }
///
/// impl Index<Side> for Balance {
///     type Output = Weight;
///
///     fn index(&self, index: Side) -> &Self::Output {
///         println!("Accessing {:?}-side of balance immutably", index);
///         match index {
///             Side::Left => &self.left,
///             Side::Right => &self.right,
///         }
///     }
/// }
///
/// impl IndexMut<Side> for Balance {
///     fn index_mut(&mut self, index: Side) -> &mut Self::Output {
///         println!("Accessing {:?}-side of balance mutably", index);
///         match index {
///             Side::Left => &mut self.left,
///             Side::Right => &mut self.right,
///         }
///     }
/// }
///
/// let mut balance = Balance {
///     right: Weight::Kilogram(2.5),
///     left: Weight::Pound(1.5),
/// };
///
/// // Sa kasong ito, ang `balance[Side::Right]` ay asukal para sa `*balance.index(Side::Right)`, dahil* binabasa lamang namin ang * `balance[Side::Right]`, hindi ito sinusulat.
/////
/////
/// assert_eq!(balance[Side::Right], Weight::Kilogram(2.5));
///
/// // Gayunpaman, sa kasong ito ang `balance[Side::Left]` ay asukal para sa `*balance.index_mut(Side::Left)`, dahil nagsusulat kami ng `balance[Side::Left]`.
/////
/////
/// balance[Side::Left] = Weight::Kilogram(3.0);
/// ```
///
///
#[lang = "index_mut"]
#[rustc_on_unimplemented(
    on(
        _Self = "&str",
        note = "you can use `.chars().nth()` or `.bytes().nth()`
see chapter in The Book <https://doc.rust-lang.org/book/ch08-02-strings.html#indexing-into-strings>"
    ),
    on(
        _Self = "str",
        note = "you can use `.chars().nth()` or `.bytes().nth()`
see chapter in The Book <https://doc.rust-lang.org/book/ch08-02-strings.html#indexing-into-strings>"
    ),
    on(
        _Self = "std::string::String",
        note = "you can use `.chars().nth()` or `.bytes().nth()`
see chapter in The Book <https://doc.rust-lang.org/book/ch08-02-strings.html#indexing-into-strings>"
    ),
    message = "the type `{Self}` cannot be mutably indexed by `{Idx}`",
    label = "`{Self}` cannot be mutably indexed by `{Idx}`"
)]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = "[")]
#[doc(alias = "]")]
#[doc(alias = "[]")]
pub trait IndexMut<Idx: ?Sized>: Index<Idx> {
    /// Ginagawa ang nababagong pagpapatakbo ng (`container[index]`) na pagpapatakbo.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[track_caller]
    fn index_mut(&mut self, index: Idx) -> &mut Self::Output;
}