/// Ginamit para sa hindi nababago na mga pagpapatakbo ng dereferencing, tulad ng `*v`.
///
/// Bilang karagdagan sa ginagamit para sa tahasang pagpapatakbo ng pagdidebensa sa (unary) `*` operator sa hindi nababago na mga konteksto, ang `Deref` ay ginagamit din ng implicit na tagatala sa maraming mga pangyayari.
/// Ang mekanismong ito ay tinatawag na ['`Deref` coercion'][more].
/// Sa mga nababagong konteksto, ginagamit ang [`DerefMut`].
///
/// Ang pagpapatupad ng `Deref` para sa matalinong mga payo ay ginagawang mag-access ang data sa likod ng mga ito, kaya't ipinatupad nila ang `Deref`.
/// Sa kabilang banda, ang mga patakaran hinggil sa `Deref` at [`DerefMut`] ay partikular na idinisenyo upang mapaunlakan ang mga matalinong mga payo.
/// Dahil dito, dapat lamang ipatupad ang **`Deref` para sa mga smart point** upang maiwasan ang pagkalito.
///
/// Para sa mga katulad na kadahilanan,**ang trait na ito ay hindi dapat mabigo**.Ang kabiguan sa panahon ng pag-dereferensa ay maaaring maging lubhang nakalilito kapag ang `Deref` ay naiimbitahan nang implicit.
///
/// # Higit pa sa pamimilit `Deref`
///
/// Kung ang `T` ay nagpapatupad ng `Deref<Target = U>`, at `x` ay isang halaga ng uri `T`, kung gayon:
///
/// * Sa hindi nababago na mga konteksto, ang `*x` (kung saan ang `T` ay alinman sa isang sanggunian o isang raw pointer) ay katumbas ng `* Deref::deref(&x)`.
/// * Ang mga halaga ng uri na `&T` ay pinilit sa mga halagang `&U`
/// * `T` implicit na nagpapatupad ng lahat ng mga pamamaraan ng (immutable) ng uri na `U`.
///
/// Para sa karagdagang detalye, bisitahin ang [the chapter in *The Rust Programming Language*][book] pati na rin ang mga seksyon ng sanggunian sa [the dereference operator][ref-deref-op], [method resolution] at [type coercions].
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// Isang istruktura na may isang solong patlang kung saan maa-access sa pamamagitan ng pag-aalis ng distansya ng struktura.
///
/// ```
/// use std::ops::Deref;
///
/// struct DerefExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// let x = DerefExample { value: 'a' };
/// assert_eq!('a', *x);
/// ```
///
///
///
///
///
///
///
#[lang = "deref"]
#[doc(alias = "*")]
#[doc(alias = "&*")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Deref"]
pub trait Deref {
    /// Ang nagresultang uri pagkatapos ng dereferencing.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_target"]
    #[cfg_attr(not(bootstrap), lang = "deref_target")]
    type Target: ?Sized;

    /// Mga Dereferensya ang halaga.
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_method"]
    fn deref(&self) -> &Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &T {
    type Target = T;

    #[rustc_diagnostic_item = "noop_method_deref"]
    fn deref(&self) -> &T {
        *self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !DerefMut for &T {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &mut T {
    type Target = T;

    fn deref(&self) -> &T {
        *self
    }
}

/// Ginamit para sa nababagabag na mga pagpapatakbo ng dereferencing, tulad ng sa `*v = 1;`.
///
/// Bilang karagdagan sa ginagamit para sa tahasang pagpapatakbo ng pagdidebensa sa operator ng (unary) `*` sa nababagabagong mga konteksto, ang `DerefMut` ay ginagamit ding implicit ng tagatala sa maraming mga pangyayari.
/// Ang mekanismong ito ay tinatawag na ['`Deref` coercion'][more].
/// Sa hindi nababago na mga konteksto, ginagamit ang [`Deref`].
///
/// Ang pagpapatupad ng `DerefMut` para sa matalinong mga payo ay ginagawang mag-mutate ang data sa likod ng mga ito, na kung bakit ipinatupad nila ang `DerefMut`.
/// Sa kabilang banda, ang mga patakaran hinggil sa [`Deref`] at `DerefMut` ay partikular na idinisenyo upang mapaunlakan ang mga matalinong mga payo.
/// Dahil dito, dapat lamang ipatupad ang **`DerefMut` para sa mga matalinong payo** upang maiwasan ang pagkalito.
///
/// Para sa mga katulad na kadahilanan,**ang trait na ito ay hindi dapat mabigo**.Ang kabiguan sa panahon ng pag-dereferensa ay maaaring maging lubhang nakalilito kapag ang `DerefMut` ay naiimbitahan nang implicit.
///
/// # Higit pa sa pamimilit `Deref`
///
/// Kung ang `T` ay nagpapatupad ng `DerefMut<Target = U>`, at `x` ay isang halaga ng uri `T`, kung gayon:
///
/// * Sa mga nababagabag na konteksto, ang `*x` (kung saan ang `T` ay alinman sa isang sanggunian o isang raw pointer) ay katumbas ng `* DerefMut::deref_mut(&mut x)`.
/// * Ang mga halaga ng uri na `&mut T` ay pinilit sa mga halagang `&mut U`
/// * `T` implicit na nagpapatupad ng lahat ng mga pamamaraan ng (mutable) ng uri na `U`.
///
/// Para sa karagdagang detalye, bisitahin ang [the chapter in *The Rust Programming Language*][book] pati na rin ang mga seksyon ng sanggunian sa [the dereference operator][ref-deref-op], [method resolution] at [type coercions].
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// Ang isang struct na may isang solong patlang na kung saan ay maaaring baguhin nang bahagya sa pamamagitan dereferencing ang struct.
///
/// ```
/// use std::ops::{Deref, DerefMut};
///
/// struct DerefMutExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefMutExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// impl<T> DerefMut for DerefMutExample<T> {
///     fn deref_mut(&mut self) -> &mut Self::Target {
///         &mut self.value
///     }
/// }
///
/// let mut x = DerefMutExample { value: 'a' };
/// *x = 'b';
/// assert_eq!('b', *x);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "deref_mut"]
#[doc(alias = "*")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DerefMut: Deref {
    /// Maaaring baguhin ang pag-aalis ng halaga.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn deref_mut(&mut self) -> &mut Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for &mut T {
    fn deref_mut(&mut self) -> &mut T {
        *self
    }
}

/// Ipinapahiwatig na ang isang struct ay maaaring magamit bilang isang tatanggap ng pamamaraan, nang walang tampok na `arbitrary_self_types`.
///
/// Ipinatupad ito ng mga uri ng stdlib pointer tulad ng `Box<T>`, `Rc<T>`, `&T`, at `Pin<P>`.
#[lang = "receiver"]
#[unstable(feature = "receiver_trait", issue = "none")]
#[doc(hidden)]
pub trait Receiver {
    // Empty.
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &T {}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &mut T {}