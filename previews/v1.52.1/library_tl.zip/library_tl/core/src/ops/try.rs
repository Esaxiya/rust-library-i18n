/// Isang trait para sa pagpapasadya ng pag-uugali ng `?` operator.
///
/// Ang isang uri ng pagpapatupad ng `Try` ay isa na may isang canonical na paraan upang tingnan ito sa mga tuntunin ng isang success/failure dichotomy.
/// Pinapayagan ng trait na kapwa kinukuha ang mga halaga ng tagumpay o pagkabigo mula sa isang mayroon nang halimbawa at paglikha ng isang bagong halimbawa mula sa isang tagumpay o halaga ng pagkabigo.
///
///
#[unstable(feature = "try_trait", issue = "42327")]
#[rustc_on_unimplemented(
    on(
        all(
            any(from_method = "from_error", from_method = "from_ok"),
            from_desugaring = "QuestionMark"
        ),
        message = "the `?` operator can only be used in {ItemContext} \
                    that returns `Result` or `Option` \
                    (or another type that implements `{Try}`)",
        label = "cannot use the `?` operator in {ItemContext} that returns `{Self}`",
        enclosing_scope = "this function should return `Result` or `Option` to accept `?`"
    ),
    on(
        all(from_method = "into_result", from_desugaring = "QuestionMark"),
        message = "the `?` operator can only be applied to values \
                    that implement `{Try}`",
        label = "the `?` operator cannot be applied to type `{Self}`"
    )
)]
#[doc(alias = "?")]
#[lang = "try"]
pub trait Try {
    /// Ang uri ng halagang ito kapag tiningnan bilang matagumpay.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Ok;
    /// Ang uri ng halagang ito kapag tiningnan bilang nabigo.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Error;

    /// Nalalapat ang "?" operator.Ang isang pagbabalik ng `Ok(t)` ay nangangahulugan na ang pagpapatupad ay dapat na magpatuloy nang normal, at ang resulta ng `?` ay ang halagang `t`.
    /// Ang isang pagbabalik ng `Err(e)` ay nangangahulugang ang pagpapatupad ay dapat branch sa pinakaloob na nakapaloob na `catch`, o bumalik mula sa pagpapaandar.
    ///
    /// Kung ang isang resulta ng `Err(e)` ay ibinalik, ang halagang `e` ay magiging "wrapped" sa uri ng pagbabalik ng sakop na saklaw (na dapat ipatupad mismo ng `Try`).
    ///
    /// Partikular, ang halagang `X::from_error(From::from(e))` ay ibinalik, kung saan ang `X` ay ang uri ng pagbabalik ng pag-andar ng pag-enclose.
    ///
    ///
    ///
    #[lang = "into_result"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn into_result(self) -> Result<Self::Ok, Self::Error>;

    /// Balutin ang isang halaga ng error upang maitayo ang pinaghalo na resulta.
    /// Halimbawa, ang `Result::Err(x)` at `Result::from_error(x)` ay katumbas.
    #[lang = "from_error"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_error(v: Self::Error) -> Self;

    /// Balutin ang isang halagang OK upang mabuo ang pinaghalong resulta.
    /// Halimbawa, ang `Result::Ok(x)` at `Result::from_ok(x)` ay katumbas.
    #[lang = "from_ok"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_ok(v: Self::Ok) -> Self;
}