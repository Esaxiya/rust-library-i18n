use crate::marker::Unsize;

/// Ang Trait na nagpapahiwatig na ito ay isang pointer o isang pambalot para sa isa, kung saan maaaring maisagawa ang pag-unsize sa pointee.
///
/// Tingnan ang [DST coercion RFC][dst-coerce] at [the nomicon entry on coercion][nomicon-coerce] para sa karagdagang detalye.
///
/// Para sa mga builtin na uri ng pointer, ang mga payo sa `T` ay pipilitin sa mga payo sa `U` kung `T: Unsize<U>` sa pamamagitan ng pag-convert mula sa isang manipis na pointer sa isang fat pointer.
///
/// Para sa mga pasadyang uri, ang pamimilit dito ay gumagana sa pamamagitan ng pamimilit `Foo<T>` hanggang `Foo<U>` na ibinigay ng isang impl ng `CoerceUnsized<Foo<U>> for Foo<T>` umiiral.
/// Ang nasabing impl ay maaari lamang maisulat kung ang `Foo<T>` ay mayroon lamang isang solong larangan na hindi phantomdata na kinasasangkutan ng `T`.
/// Kung ang uri ng patlang na iyon ay `Bar<T>`, isang pagpapatupad ng `CoerceUnsized<Bar<U>> for Bar<T>` ay dapat na mayroon.
/// Ang pamimilit ay gagana sa pamamagitan ng pamimilit sa patlang `Bar<T>` sa `Bar<U>` at pagpuno sa natitirang mga patlang mula sa `Foo<T>` upang lumikha ng isang `Foo<U>`.
/// Ito ay mabisang mag-drill down sa isang pointer field at pilitin iyon.
///
/// Pangkalahatan, para sa mga matalinong payo ipapatupad mo ang `CoerceUnsized<Ptr<U>> for Ptr<T> where T: Unsize<U>, U: ?Sized`, na may isang opsyonal na `?Sized` na nakasalalay sa `T` mismo.
/// Para sa mga uri ng pambalot na direktang nag-embed ng `T` tulad ng `Cell<T>` at `RefCell<T>`, maaari mong direktang ipatupad ang `CoerceUnsized<Wrap<U>> for Wrap<T> where T: CoerceUnsized<U>`.
///
/// Hahayaan nito ang mga pamimilit ng mga uri tulad ng `Cell<Box<T>>` na gumana.
///
/// [`Unsize`][unsize] ay ginagamit upang markahan ang mga uri na maaaring coerced upang DSTS kung sa likod ng mga payo.Awtomatiko itong ipinatutupad ng tagatala.
///
/// [dst-coerce]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [unsize]: crate::marker::Unsize
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
///
///
///
///
///
///
#[unstable(feature = "coerce_unsized", issue = "27732")]
#[lang = "coerce_unsized"]
pub trait CoerceUnsized<T: ?Sized> {
    // Empty.
}

// &mut T-> &mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a mut U> for &'a mut T {}
// &mut T-> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b mut T {}
// &mut T-> * mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for &'a mut T {}
// &mut T-> * const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a mut T {}

// &T -> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b T {}
// &T -> * const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a T {}

// *Mut T->* mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for *mut T {}
// *mut T->* const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *mut T {}

// *const T->* const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *const T {}

/// Ginagamit ito para sa kaligtasan ng bagay, upang suriin na ang uri ng tatanggap ng isang pamamaraan ay maaaring maipadala.
///
/// Isang halimbawa ng pagpapatupad ng trait:
///
/// ```
/// # #![feature(dispatch_from_dyn, unsize)]
/// # use std::{ops::DispatchFromDyn, marker::Unsize};
/// # struct Rc<T: ?Sized>(std::rc::Rc<T>);
/// impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T>
/// where
///     T: Unsize<U>,
/// {}
/// ```
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
#[lang = "dispatch_from_dyn"]
pub trait DispatchFromDyn<T> {
    // Empty.
}

// &T -> &U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a U> for &'a T {}
// &mut T-> &mut U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a mut U> for &'a mut T {}
// *const T->* const U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*const U> for *const T {}
// *Mut T->* mut U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*mut U> for *mut T {}