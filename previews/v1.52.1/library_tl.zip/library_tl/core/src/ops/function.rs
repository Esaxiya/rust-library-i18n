/// Ang bersyon ng operator ng tawag na tumatagal ng isang hindi nababago na tatanggap.
///
/// Ang mga pagkakataong `Fn` ay maaaring tawaging paulit-ulit nang hindi nagbabagong estado.
///
/// *Ang trait (`Fn`) na ito ay hindi dapat malito sa [function pointers] (`fn`).*
///
/// `Fn` ay awtomatikong ipinatupad ng mga pagsasara na kumukuha lamang ng hindi nababago na mga sanggunian sa mga nakuhang variable o hindi nakakakuha ng anupaman, pati na rin ang (safe) [function pointers] (na may ilang mga pag-uusap, tingnan ang kanilang dokumentasyon para sa higit pang mga detalye).
///
/// Bilang karagdagan, para sa anumang uri ng `F` na nagpapatupad ng `Fn`, `&F` ay nagpapatupad ng `Fn`, din.
///
/// Dahil ang parehong [`FnMut`] at [`FnOnce`] ay supertraits ng `Fn`, ang anumang halimbawa ng `Fn` ay maaaring magamit bilang isang parameter kung saan inaasahan ang isang [`FnMut`] o [`FnOnce`].
///
/// Gumamit ng `Fn` bilang isang nakagapos kung nais mong tanggapin ang isang parameter ng uri na tulad ng pag-andar at kailangang tawagan ito nang paulit-ulit at hindi binago ang estado (hal., Nang tumawag ito nang sabay-sabay).
/// Kung hindi mo kailangan ng mga mahigpit na kinakailangan, gumamit ng [`FnMut`] o [`FnOnce`] bilang mga hangganan.
///
/// Tingnan ang [chapter on closures in *The Rust Programming Language*][book] para sa ilang karagdagang impormasyon sa paksang ito.
///
/// Tandaan din ang espesyal na syntax para sa `Fn` traits (hal
/// `Fn(usize, bool) -> usize`).Ang mga interesado sa mga teknikal na detalye ng ito ay maaaring sumangguni sa [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Tumatawag ng isang pagsasara
///
/// ```
/// let square = |x| x * x;
/// assert_eq!(square(5), 25);
/// ```
///
/// ## Paggamit ng isang `Fn` parameter
///
/// ```
/// fn call_with_one<F>(func: F) -> usize
///     where F: Fn(usize) -> usize {
///     func(1)
/// }
///
/// let double = |x| x * 2;
/// assert_eq!(call_with_one(double), 2);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{Fn}<{Args}>` closure, found `{Self}`",
    label = "expected an `Fn<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // upang ang regex ay maaaring umasa sa `&str: !FnMut` na iyon
#[must_use = "closures are lazy and do nothing unless called"]
pub trait Fn<Args>: FnMut<Args> {
    /// Ginagawa ang operasyon ng tawag.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call(&self, args: Args) -> Self::Output;
}

/// Ang bersyon ng operator ng tawag na tumatagal ng isang nababagabag na tatanggap.
///
/// Ang mga pagkakataon na `FnMut` ay maaaring tawaging paulit-ulit at maaaring mag-mutate ng estado.
///
/// `FnMut` ay awtomatikong ipinatupad ng mga pagsasara na kumukuha ng mga nababagong sanggunian sa mga nakuhang variable, pati na rin ang lahat ng mga uri na nagpapatupad ng [`Fn`], hal, (safe) [function pointers] (dahil ang `FnMut` ay isang supertrait ng [`Fn`]).
/// Bilang karagdagan, para sa anumang uri ng `F` na nagpapatupad ng `FnMut`, `&mut F` ay nagpapatupad ng `FnMut`, din.
///
/// Dahil ang [`FnOnce`] ay isang supertrait ng `FnMut`, ang anumang halimbawa ng `FnMut` ay maaaring magamit kung saan ang isang [`FnOnce`] ay inaasahan, at dahil ang [`Fn`] ay isang subtrait ng `FnMut`, ang anumang halimbawa ng [`Fn`] ay maaaring magamit kung saan inaasahan ang `FnMut`.
///
/// Gumamit ng `FnMut` bilang isang nakagapos kung nais mong tanggapin ang isang parameter ng uri na tulad ng pag-andar at kailangang tawagan ito nang paulit-ulit, habang pinapayagan itong i-mutate ang estado.
/// Kung hindi mo nais ang parameter na i-mutate ang estado, gamitin ang [`Fn`] bilang isang nakagapos;kung hindi mo na kailangang tawagan ito nang paulit-ulit, gamitin ang [`FnOnce`].
///
/// Tingnan ang [chapter on closures in *The Rust Programming Language*][book] para sa ilang karagdagang impormasyon sa paksang ito.
///
/// Tandaan din ang espesyal na syntax para sa `Fn` traits (hal
/// `Fn(usize, bool) -> usize`).Ang mga interesado sa mga teknikal na detalye ng ito ay maaaring sumangguni sa [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Tumatawag ng isang maaaring baguhin ang pagkuha ng pagsasara
///
/// ```
/// let mut x = 5;
/// {
///     let mut square_x = || x *= x;
///     square_x();
/// }
/// assert_eq!(x, 25);
/// ```
///
/// ## Paggamit ng isang `FnMut` parameter
///
/// ```
/// fn do_twice<F>(mut func: F)
///     where F: FnMut()
/// {
///     func();
///     func();
/// }
///
/// let mut x: usize = 1;
/// {
///     let add_two_to_x = || x += 2;
///     do_twice(add_two_to_x);
/// }
///
/// assert_eq!(x, 5);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn_mut"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnMut}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnMut<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // upang ang regex ay maaaring umasa sa `&str: !FnMut` na iyon
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnMut<Args>: FnOnce<Args> {
    /// Ginagawa ang operasyon ng tawag.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_mut(&mut self, args: Args) -> Self::Output;
}

/// Ang bersyon ng operator ng tawag na tumatagal ng isang by-halaga na tatanggap.
///
/// Ang mga pagkakataon na `FnOnce` ay maaaring tawagan, ngunit maaaring hindi ito matawag nang maraming beses.Dahil dito, kung ang tanging bagay na kilala tungkol sa isang uri ay tumutulong ito nagpapatupad `FnOnce`, ito ay maaari lamang na tinatawag na isang beses.
///
/// `FnOnce` ay awtomatikong ipinatupad ng mga pagsasara na maaaring ubusin ang mga nakakuha ng variable, pati na rin ang lahat ng mga uri na nagpapatupad ng [`FnMut`], hal, (safe) [function pointers] (dahil ang `FnOnce` ay isang supertrait ng [`FnMut`]).
///
///
/// Dahil ang parehong [`Fn`] at [`FnMut`] ay subtraits ng `FnOnce`, ang anumang halimbawa ng [`Fn`] o [`FnMut`] ay maaaring magamit kung saan inaasahan ang isang `FnOnce`.
///
/// Gumamit ng `FnOnce` bilang isang nakagapos kung nais mong tanggapin ang isang parameter ng uri na tulad ng pag-andar at kailangan mo lamang itong tawagan nang isang beses.
/// Kung kailangan mong tawagan ang parameter nang paulit-ulit, gamitin ang [`FnMut`] bilang isang nakagapos;kung kailangan mo rin ito upang hindi mutate state, gamitin ang [`Fn`].
///
/// Tingnan ang [chapter on closures in *The Rust Programming Language*][book] para sa ilang karagdagang impormasyon sa paksang ito.
///
/// Tandaan din ang espesyal na syntax para sa `Fn` traits (hal
/// `Fn(usize, bool) -> usize`).Ang mga interesado sa mga teknikal na detalye ng ito ay maaaring sumangguni sa [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Paggamit ng isang `FnOnce` parameter
///
/// ```
/// fn consume_with_relish<F>(func: F)
///     where F: FnOnce() -> String
/// {
///     // `func` natupok ang mga nakuhang variable nito, kaya't hindi ito mapapatakbo nang higit sa isang beses.
/////
///     println!("Consumed: {}", func());
///
///     println!("Delicious!");
///
///     // Ang pagtatangka na muling ipatawag ang `func()` ay magtatapon ng isang error na `use of moved value` para sa `func`.
/////
/// }
///
/// let x = String::from("x");
/// let consume_and_return_x = move || x;
/// consume_with_relish(consume_and_return_x);
///
/// // `consume_and_return_x` ay hindi na maaaring tawagan sa puntong ito
/// ```
///
///
///
///
///
///
///
///
#[lang = "fn_once"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnOnce}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnOnce<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // upang ang regex ay maaaring umasa sa `&str: !FnMut` na iyon
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnOnce<Args> {
    /// Ang naibalik na uri pagkatapos magamit ang call operator.
    #[lang = "fn_once_output"]
    #[stable(feature = "fn_once_output", since = "1.12.0")]
    type Output;

    /// Ginagawa ang operasyon ng tawag.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_once(self, args: Args) -> Self::Output;
}

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> Fn<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call(&self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &F
    where
        F: Fn<A>,
    {
        type Output = F::Output;

        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &mut F
    where
        F: FnMut<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &mut F
    where
        F: FnMut<A>,
    {
        type Output = F::Output;
        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }
}