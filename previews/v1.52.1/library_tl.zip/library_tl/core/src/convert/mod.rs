//! Traits para sa mga conversion sa pagitan ng mga uri.
//!
//! Ang traits sa modyul na ito ay nagbibigay ng isang paraan upang mai-convert mula sa isang uri patungo sa isa pang uri.
//! Ang bawat trait nagsisilbi ng ibang kadahilanan:
//!
//! - Ipatupad ang [`AsRef`] trait para sa murang mga sanggunian na sanggunian sa sanggunian
//! - Ipatupad ang [`AsMut`] trait para sa murang mutable-to-mutable conversion
//! - Ipatupad ang [`From`] trait para ubos halaga-to-halaga ng mga conversion
//! - Ipatupad ang [`Into`] trait para ubos halaga-to-halaga ang mga conversion sa mga uri sa labas ng kasalukuyang crate
//! - Ang [`TryFrom`] at [`TryInto`] traits kumilos tulad [`From`] at [`Into`], ngunit dapat na ipinatupad kapag ang conversion ay maaaring mabibigo.
//!
//! Ang traits sa modyul na ito ay madalas na ginagamit bilang trait bounds para sa mga pangkaraniwang pag-andar tulad ng sa mga argumento ng maraming uri ay sinusuportahan.Tingnan ang dokumentasyon ng bawat trait para sa mga halimbawa.
//!
//! Bilang isang may-akda ng silid-aklatan, dapat mong palaging ginusto ang pagpapatupad ng [`From<T>`][`From`] o [`TryFrom<T>`][`TryFrom`] kaysa [`Into<U>`][`Into`] o [`TryInto<U>`][`TryInto`], dahil ang [`From`] at [`TryFrom`] ay nagbibigay ng higit na kakayahang umangkop at nag-aalok ng katumbas na pagpapatupad ng [`Into`] o [`TryInto`] nang libre, salamat sa isang pagpapatupad ng kumot sa karaniwang silid aklatan.
//! Kapag nagta-target ng isang bersyon bago ang Rust 1.41, maaaring ito ay kinakailangan upang ipatupad [`Into`] o [`TryInto`] direkta kapag nagko-convert sa isang uri sa labas ng kasalukuyang crate.
//!
//! # generic pagpapatupad
//!
//! - [`AsRef`] at [`AsMut`] auto-dereferensya kung ang panloob na uri ay isang sanggunian
//! - [`Mula`]`<U>para sa T` ay nagpapahiwatig ng [`Sa'`</u><T><U>para kay U`</u>
//! - ['TryFrom`]` <U>para kay T`ay nagpapahiwatig ng [` TryInto`]`</u><T><U>para kay U`</u>
//! - [`From`] at [`Into`] ay reflexive, na nangangahulugang ang lahat ng mga uri ay maaaring `into` kanilang sarili at `from` mismo
//!
//! Tingnan ang bawat trait para sa mga halimbawa ng paggamit.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

mod num;

#[unstable(feature = "convert_float_to_int", issue = "67057")]
pub use num::FloatToInt;

/// Ang pag-andar ng pagkakakilanlan.
///
/// Dalawang bagay ang mahalagang tandaan tungkol sa pagpapaandar na ito:
///
/// - Ito ay hindi palaging katumbas ng isang pagsasara tulad ng `|x| x`, dahil ang pagsasara ay maaaring pilitin ang `x` sa ibang uri.
///
/// - Ginagalaw nito ang input `x` na ipinasa sa pagpapaandar.
///
/// Habang maaaring mukhang kakaiba na magkaroon ng isang function na lang babalik i-back ang input, may ilang mga kagiliw-giliw na mga gamit.
///
///
/// # Examples
///
/// Paggamit ng `identity` upang gumawa ng wala sa isang pagkakasunud-sunod ng iba pa, kagiliw-giliw, mga pag-andar:
///
/// ```rust
/// use std::convert::identity;
///
/// fn manipulation(x: u32) -> u32 {
///     // Sabihin magpanggap na pagdagdag ng isa ay isang kagiliw-giliw na function.
///     x + 1
/// }
///
/// let _arr = &[identity, manipulation];
/// ```
///
/// Paggamit ng `identity` bilang isang "do nothing" base case sa isang kondisyonal:
///
/// ```rust
/// use std::convert::identity;
///
/// # let condition = true;
/// #
/// # fn manipulation(x: u32) -> u32 { x + 1 }
/// #
/// let do_stuff = if condition { manipulation } else { identity };
///
/// // Gumawa ng mas maraming kagiliw-giliw na bagay ...
///
/// let _results = do_stuff(42);
/// ```
///
/// Paggamit ng `identity` upang mapanatili ang mga variant ng `Some` ng isang iterator ng `Option<T>`:
///
/// ```rust
/// use std::convert::identity;
///
/// let iter = vec![Some(1), None, Some(3)].into_iter();
/// let filtered = iter.filter_map(identity).collect::<Vec<_>>();
/// assert_eq!(vec![1, 3], filtered);
/// ```
///
///
#[stable(feature = "convert_id", since = "1.33.0")]
#[rustc_const_stable(feature = "const_identity", since = "1.33.0")]
#[inline]
pub const fn identity<T>(x: T) -> T {
    x
}

/// Ginamit upang gawin ang isang murang sanggunian na sanggunian sa sanggunian.
///
/// Ito trait ay katulad sa [`AsMut`] na kung saan ay ginagamit para sa pag-convert sa pagitan mutable sanggunian.
/// Kung kailangan mong gawin ang isang mamahaling conversion ito ay mas mahusay na ipatupad [`From`] na may uri `&T` o magsulat ng isang pasadyang function.
///
/// `AsRef` ay may parehong pirma tulad ng [`Borrow`], ngunit ang [`Borrow`] ay naiiba sa ilang mga aspeto:
///
/// - Hindi tulad ng `AsRef`, [`Borrow`] ay may isang kumot impl para sa anumang `T`, at maaaring magamit upang tanggapin ang alinman sa isang reference o isang halaga.
/// - [`Borrow`] Kinakailangan din na ang [`Hash`], [`Eq`] at [`Ord`] para sa hiniram na halaga ay katumbas ng mga pagmamay-ari na halaga.
/// Para sa kadahilanang ito, kung nais mong upang humiram lamang ng isang solong field ng isang struct maaari mong ipatupad `AsRef`, ngunit hindi [`Borrow`].
///
/// **Note: Ang trait na ito ay hindi dapat mabigo **.Kung ang conversion ay maaaring mabibigo, gumamit ng isang nakatuong paraan na nagbabalik ng isang [`Option<T>`] o isang [`Result<T, E>`].
///
/// # generic pagpapatupad
///
/// - `AsRef` auto-dereferences kung ang panloob na uri ay isang reference o maaaring mabago ng isang reference (hal: `foo.as_ref()` will work the same if `foo` has type   `&mut Foo` or `&&mut Foo`)
///
///
/// # Examples
///
/// Sa pamamagitan ng paggamit trait bounds maaari naming tanggapin ang mga argumento ng mga iba't ibang mga uri hangga't maaari silang ma-convert sa tinukoy na uri `T`.
///
/// Halimbawa: Sa pamamagitan ng paglikha ng isang pangkaraniwang function na tumatagal ng isang `AsRef<str>` ipahayag namin na gusto naming tanggapin ang lahat ng mga sanggunian na maaaring ma-convert sa [`&str`] bilang isang argument.
/// Since parehong [`String`] at [`&str`] ipatupad `AsRef<str>` maaari naming tanggapin ang parehong bilang input argument.
///
/// [`&str`]: primitive@str
/// [`Borrow`]: crate::borrow::Borrow
/// [`Eq`]: crate::cmp::Eq
/// [`Ord`]: crate::cmp::Ord
/// [`String`]: ../../std/string/struct.String.html
///
/// ```
/// fn is_hello<T: AsRef<str>>(s: T) {
///    assert_eq!("hello", s.as_ref());
/// }
///
/// let s = "hello";
/// is_hello(s);
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsRef<T: ?Sized> {
    /// Ginagawa ang conversion.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_ref(&self) -> &T;
}

/// Ginagamit upang gawin ang isang murang mutable-to-mutable reference conversion.
///
/// Ito trait ay katulad sa [`AsRef`] ngunit ginagamit para sa pag-convert sa pagitan mutable sanggunian.
/// Kung kailangan mong gawin ang isang mamahaling conversion ito ay mas mahusay na ipatupad [`From`] na may uri `&mut T` o magsulat ng isang pasadyang function.
///
/// **Note: Ang trait na ito ay hindi dapat mabigo **.Kung ang conversion ay maaaring mabibigo, gumamit ng isang nakatuong paraan na nagbabalik ng isang [`Option<T>`] o isang [`Result<T, E>`].
///
/// # generic pagpapatupad
///
/// - `AsMut` auto-dereferences kung ang panloob na uri ay maaaring mabago ng isang reference (hal: `foo.as_mut()` will work the same if `foo` has type `&mut Foo`   or `&mut &mut Foo`)
///
///
/// # Examples
///
/// Ang paggamit ng `AsMut` bilang trait bound para sa isang pangkaraniwang pag-andar maaari naming tanggapin ang lahat ng mga nababagong sanggunian na maaaring mai-convert sa uri ng `&mut T`.
/// Dahil ang [`Box<T>`] ay nagpapatupad ng `AsMut<T>` maaari kaming magsulat ng isang pagpapaandar `add_one` na tumatagal ng lahat ng mga argumento na maaaring mai-convert sa `&mut u64`.
/// Dahil ang [`Box<T>`] ay nagpapatupad ng `AsMut<T>`, ang `add_one` ay tumatanggap ng mga argumento ng uri `&mut Box<u64>` din:
///
/// ```
/// fn add_one<T: AsMut<u64>>(num: &mut T) {
///     *num.as_mut() += 1;
/// }
///
/// let mut boxed_num = Box::new(0);
/// add_one(&mut boxed_num);
/// assert_eq!(*boxed_num, 1);
/// ```
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsMut<T: ?Sized> {
    /// Ginagawa ang conversion.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_mut(&mut self) -> &mut T;
}

/// Isang conversion na halaga-sa-halaga na kumokonsumo ng halaga ng pag-input.Ang kabaligtaran ng [`From`].
///
/// Dapat iwasan ng isa ang pagpapatupad ng [`Into`] at ipatupad sa halip ang [`From`].
/// Ang pagpapatupad ng [`From`] ay awtomatikong nagbibigay ng isa na may pagpapatupad ng [`Into`] salamat sa pagpapatupad ng kumot sa karaniwang silid aklatan.
///
/// Mas gusto na gamit [`Into`] higit [`From`] kapag tumutukoy trait bounds sa isang pangkaraniwang function upang matiyak na ang mga uri na lamang ipatupad [`Into`] ay maaaring gamitin pati na rin.
///
/// **Note: Ang trait na ito ay hindi dapat mabigo **.Kung maaaring mabigo ang conversion, gamitin ang [`TryInto`].
///
/// # generic pagpapatupad
///
/// - [`Mula`]`<T>para sa U` ay nagpapahiwatig ng `Into<U> for T`
/// - [`Into`] ay reflexive, na nangangahulugang ipinatupad ang `Into<T> for T`
///
/// # Pagpapatupad [`Into`] para sa mga conversion sa mga panlabas na mga uri sa mga lumang bersyon ng Rust
///
/// Bago ang Rust 1.41, kung ang destination i-type ay hindi bahagi ng kasalukuyang crate pagkatapos ikaw ay hindi ipatupad [`From`] direkta.
/// Halimbawa, kunin ang code na ito:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> From<Wrapper<T>> for Vec<T> {
///     fn from(w: Wrapper<T>) -> Vec<T> {
///         w.0
///     }
/// }
/// ```
/// Ito ay hindi sumulat ng libro sa mas lumang bersyon ng wikang dahil orphaning panuntunan Rust ginamit upang maging isang maliit na bit mas mahigpit.
/// Upang i-bypass ito, maaari mong ipatupad nang direkta ang [`Into`]:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> Into<Vec<T>> for Wrapper<T> {
///     fn into(self) -> Vec<T> {
///         self.0
///     }
/// }
/// ```
///
/// Ito ay mahalaga na maunawaan na ang [`Into`] ay hindi nagbibigay ng isang [`From`] pagpapatupad (tulad ng [`From`] gumagana na may [`Into`]).
/// Samakatuwid, dapat mong palaging subukang ipatupad ang [`From`] at pagkatapos ay bumalik sa [`Into`] kung ang [`From`] ay hindi maipatupad.
///
/// # Examples
///
/// [`String`] nagpapatupad [`Into`]`<`[`Vec`] `<` [`u8`]`>>`:
///
/// Upang ipahayag na gusto namin ng isang generic na pagpapaandar upang gawin ang lahat ng mga argument na ma-convert sa isang tinukoy na uri `T`, maaari naming gamitin ang isang trait bound ng [`Into`]`<T>`.
///
/// Halimbawa: Ang pagpapaandar `is_hello` ay tumatagal ng lahat ng mga argumento na maaaring mai-convert sa isang [`Vec`]`<`[`u8`] `>`.
///
/// ```
/// fn is_hello<T: Into<Vec<u8>>>(s: T) {
///    let bytes = b"hello".to_vec();
///    assert_eq!(bytes, s.into());
/// }
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`Vec`]: ../../std/vec/struct.Vec.html
///
///
///
///
///
///
#[rustc_diagnostic_item = "into_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Into<T>: Sized {
    /// Ginagawa ang conversion.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into(self) -> T;
}

/// Ginamit upang gawin ang mga conversion na halaga-sa-halaga habang kinukonsumo ang halaga ng pag-input.Ito ay ang katumbas ng [`Into`].
///
/// Dapat palaging ginusto ng isa ang pagpapatupad ng `From` kaysa sa [`Into`] dahil ang pagpapatupad ng `From` ay awtomatikong nagbibigay ng isa sa isang pagpapatupad ng [`Into`] salamat sa pagpapatupad ng kumot sa karaniwang silid aklatan.
///
///
/// Tanging ipatupad [`Into`] kapag nagta-target ng isang bersyon bago ang Rust 1.41 at nagko-convert sa isang uri sa labas ng kasalukuyang crate.
/// `From` ay hindi magagawang upang gawin ang mga uri ng mga conversion sa naunang bersyon dahil sa orphaning panuntunan Rust.
/// Tingnan [`Into`] para sa karagdagang detalye.
///
/// Mas gusto ang paggamit ng [`Into`] kaysa sa paggamit ng `From` kapag tumutukoy sa trait bounds sa isang pangkaraniwang pag-andar.
/// Sa ganitong paraan, ang mga uri na direktang nagpapatupad ng [`Into`] ay maaaring magamit din bilang mga argumento.
///
/// Ang `From` ay kapaki-pakinabang din kapag gumaganap ng error sa paghawak.Kapag nagtatayo ng isang pagpapaandar na may kakayahang mabigo, ang uri ng pagbabalik sa pangkalahatan ay magiging form na `Result<T, E>`.
/// Pinapasimple ng `From` trait ang paghawak ng error sa pamamagitan ng pagpapahintulot sa isang pagpapaandar na ibalik ang isang solong uri ng error na nagpapaloob sa maraming uri ng error.Tingnan ang seksyon "Examples" at [the book][book] para sa karagdagang detalye.
///
/// **Note: Ang trait na ito ay hindi dapat mabigo **.Kung ang conversion ay maaaring mabibigo, gamitin [`TryFrom`].
///
/// # generic pagpapatupad
///
/// - `From<T> for U` nagpapahiwatig ng [`Sa```` <U>para sa T`</u>
/// - `From` ay reflexive, na nangangahulugan na `From<T> for T` ay ipinatupad
///
/// # Examples
///
/// [`String`] nagpapatupad ng `From<&str>`:
///
/// Isang tahasang conversion mula sa isang `&str` sa isang String ay tapos na tulad ng sumusunod:
///
/// ```
/// let string = "hello".to_string();
/// let other_string = String::from("hello");
///
/// assert_eq!(string, other_string);
/// ```
///
/// Habang gumaganap ng error sa paghawak ng ito ay madalas na kapaki-pakinabang upang ipatupad ang `From` para sa iyong sariling uri ng error.
/// Sa pamamagitan ng pag-convert ng napapailalim na mga uri ng error sa aming sariling pasadyang uri ng error na nag-encapsulate ng pinagbabatayan na uri ng error, maaari naming ibalik ang isang solong uri ng error nang hindi nawawala ang impormasyon sa pinagbabatayanang dahilan.
/// Ang '?' operator awtomatikong nagpalit ang kalakip na uri ng error sa aming mga pasadyang uri ng error sa pamamagitan ng pagtawag `Into<CliError>::into` na kung saan ay awtomatikong ibinigay kapag ang pagpapatupad `From`.
/// Ang tagatala pagkatapos ay infers na pagpapatupad ng `Into` dapat gamitin.
///
/// ```
/// use std::fs;
/// use std::io;
/// use std::num;
///
/// enum CliError {
///     IoError(io::Error),
///     ParseError(num::ParseIntError),
/// }
///
/// impl From<io::Error> for CliError {
///     fn from(error: io::Error) -> Self {
///         CliError::IoError(error)
///     }
/// }
///
/// impl From<num::ParseIntError> for CliError {
///     fn from(error: num::ParseIntError) -> Self {
///         CliError::ParseError(error)
///     }
/// }
///
/// fn open_and_parse_file(file_name: &str) -> Result<i32, CliError> {
///     let mut contents = fs::read_to_string(&file_name)?;
///     let num: i32 = contents.trim().parse()?;
///     Ok(num)
/// }
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`from`]: From::from
/// [book]: ../../book/ch09-00-error-handling.html
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "from_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(on(
    all(_Self = "&str", T = "std::string::String"),
    note = "to coerce a `{T}` into a `{Self}`, use `&*` as a prefix",
))]
pub trait From<T>: Sized {
    /// Ginagawa ang conversion.
    #[lang = "from"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from(_: T) -> Self;
}

/// Isang tangkang pag-convert na kumonsumo ng `self`, na maaaring o maaaring hindi maging mahal.
///
/// Library may-akda ay dapat ay karaniwang hindi direkta ipatupad ang trait, ngunit dapat ginusto pagpapatupad ng [`TryFrom`] trait, na kung saan ay nag-aalok ng higit na flexibility at nagbibigay ng isang katumbas na `TryInto` pagpapatupad ng libre, salamat sa isang kumot pagpapatupad sa standard library.
/// Para sa karagdagang impormasyon tungkol dito, tingnan ang dokumentasyon para [`Into`].
///
/// # Pagpapatupad ng `TryInto`
///
/// Naghihirap ito ng parehong mga paghihigpit at pangangatuwiran tulad ng pagpapatupad ng [`Into`], tingnan doon para sa mga detalye.
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_into_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryInto<T>: Sized {
    /// Bumalik ang uri sa kaganapan ng isang error sa conversion.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// Ginagawa ang conversion.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_into(self) -> Result<T, Self::Error>;
}

/// Simple at ligtas na mga conversion na uri na maaaring mabigo sa isang kontroladong paraan sa ilalim ng ilang mga pangyayari.Ito ay ang katumbasan ng [`TryInto`].
///
/// Ito ay kapaki-pakinabang kapag ikaw ay paggawa ng isang uri ng conversion na maaaring trivially magtagumpay ngunit maaari ring kailangan ng espesyal na handling.
/// Halimbawa, walang paraan upang i-convert ng isang [`i64`] sa isang [`i32`] gamit ang [`From`] trait, sapagka't isang [`i64`] maaaring maglaman ng isang halaga na ang isang [`i32`] ay hindi maaaring kumatawan at kaya ang mga conversion ay mawalan ng data.
///
/// Maaaring hawakan ito sa pamamagitan ng pagputol ng [`i64`] sa isang [`i32`] (mahalagang pagbibigay ng halaga ng [`i64`] na modulo [`i32::MAX`]) o sa pamamagitan lamang ng pagbabalik ng [`i32::MAX`], o ng ibang pamamaraan.
/// Ang [`From`] trait ay inilaan para sa perpektong conversion, kaya ang `TryFrom` trait informs ang programmer kapag ang isang uri ng conversion ay maaaring maging masama at nagbibigay-daan sa kanila magpasya kung paano upang mahawakan ang mga ito.
///
/// # generic pagpapatupad
///
/// - `TryFrom<T> for U` nagpapahiwatig ng [`TryInto`]`<U>para sa T`</u>
/// - [`try_from`] ay reflexive, na nangangahulugang ang `TryFrom<T> for T` ay ipinatupad at hindi mabibigo-ang kaugnay na uri ng `Error` para sa pagtawag sa `T::try_from()` sa isang halaga ng uri na `T` ay [`Infallible`].
/// Kapag ang uri ng [`!`] ay nagpapatatag [`Infallible`] at [`!`] ay magiging katumbas.
///
/// `TryFrom<T>` maaaring ipatupad tulad ng sumusunod:
///
/// ```
/// use std::convert::TryFrom;
///
/// struct GreaterThanZero(i32);
///
/// impl TryFrom<i32> for GreaterThanZero {
///     type Error = &'static str;
///
///     fn try_from(value: i32) -> Result<Self, Self::Error> {
///         if value <= 0 {
///             Err("GreaterThanZero only accepts value superior than zero!")
///         } else {
///             Ok(GreaterThanZero(value))
///         }
///     }
/// }
/// ```
///
/// # Examples
///
/// Tulad ng inilarawan, ipinatutupad ng [`i32`] ang `TryFrom <` [`i64`]`>`:
///
/// ```
/// use std::convert::TryFrom;
///
/// let big_number = 1_000_000_000_000i64;
/// // Tahimik na pinutol ang `big_number`, nangangailangan ng pagtuklas at paghawak ng truncation pagkatapos ng katotohanan.
/////
/// let smaller_number = big_number as i32;
/// assert_eq!(smaller_number, -727379968);
///
/// // Nagbabalik ng isang error dahil ang `big_number` ay masyadong malaki upang magkasya sa isang `i32`.
/////
/// let try_smaller_number = i32::try_from(big_number);
/// assert!(try_smaller_number.is_err());
///
/// // Ibinabalik `Ok(3)`.
/// let try_successful_smaller_number = i32::try_from(3);
/// assert!(try_successful_smaller_number.is_ok());
/// ```
///
/// [`try_from`]: TryFrom::try_from
///
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_from_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryFrom<T>: Sized {
    /// Bumalik ang uri sa kaganapan ng isang error sa conversion.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// Ginagawa ang conversion.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_from(value: T) -> Result<Self, Self::Error>;
}

////////////////////////////////////////////////////////////////////////////////
// GENERIC IMPLS
////////////////////////////////////////////////////////////////////////////////

// Tulad ng nakakataas&
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// Tulad ng nakakataas sa &mut
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &mut T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// FIXME (#45742): palitan ang itaas impls para sa&/&mut may mga sumusunod na karagdagang pangkalahatang isa:
// // Bilang lifts sa ibabaw Deref
// impl <D: ?Sized + Deref<Target: AsRef<U>>, U:? Laki> AsRef <U>para sa D {fn as_ref(&self)-> &U {</u>
//
//         self.deref().as_ref()
//     }
// }

// Itinaas ng AsMut ang higit sa &mut
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsMut<U> for &mut T
where
    T: AsMut<U>,
{
    fn as_mut(&mut self) -> &mut U {
        (*self).as_mut()
    }
}

// FIXME (#45742): palitan ang nasa itaas na impl para sa &mut sa sumusunod na mas pangkalahatang isa:
// // Ang AsMut ay nakakataas sa DerefMut
// impl <D: ?Sized + Deref<Target: AsMut<U>>, U:? Laki> AsMut <U>para sa D {fn as_mut(&mut self)-> &mut U {</u>
//
//         self.deref_mut().as_mut()
//     }
// }

// Mula sa nagpapahiwatig kay
#[stable(feature = "rust1", since = "1.0.0")]
impl<T, U> Into<U> for T
where
    U: From<T>,
{
    fn into(self) -> U {
        U::from(self)
    }
}

// Mula sa (at sa gayon ay Sa) ay masasalamin
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> From<T> for T {
    fn from(t: T) -> T {
        t
    }
}

/// **Tala ng katatagan:** Ang impl na ito ay wala pa, ngunit kami ay "reserving space" upang idagdag ito sa future.
/// Tingnan ang [rust-lang/rust#64715][#64715] para sa mga detalye.
///
/// [#64715]: https://github.com/rust-lang/rust/issues/64715
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[allow(unused_attributes)] // FIXME(#58633): sa halip ay gumawa ng isang may prinsipyo na pag-aayos.
#[rustc_reservation_impl = "permitting this impl would forbid us from adding \
                            `impl<T> From<!> for T` later; see rust-lang/rust#64715 for details"]
impl<T> From<!> for T {
    fn from(t: !) -> T {
        t
    }
}

// Ipinapahiwatig ng TryFrom ang TryInto
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryInto<U> for T
where
    U: TryFrom<T>,
{
    type Error = U::Error;

    fn try_into(self) -> Result<U, U::Error> {
        U::try_from(self)
    }
}

// Magkamali conversion ay semantically katumbas ng maaaring magkamali conversion na may isang walang tumitira type error.
//
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryFrom<U> for T
where
    U: Into<T>,
{
    type Error = Infallible;

    fn try_from(value: U) -> Result<Self, Self::Error> {
        Ok(U::into(value))
    }
}

////////////////////////////////////////////////////////////////////////////////
// CONCRETE IMPLS
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsRef<[T]> for [T] {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsMut<[T]> for [T] {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for str {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "as_mut_str_for_str", since = "1.51.0")]
impl AsMut<str> for str {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

////////////////////////////////////////////////////////////////////////////////
// MGA WALANG-ERROR ERROR TYPE
////////////////////////////////////////////////////////////////////////////////

/// Ang uri ng error para sa mga error na hindi maaaring mangyari.
///
/// Dahil ang enum na ito ay walang pagkakaiba-iba, ang isang halaga ng ganitong uri ay hindi talaga maaaring magkaroon.
/// Maaari itong maging kapaki-pakinabang para sa mga generic na API na gumagamit ng [`Result`] at i-parameter ang uri ng error, upang ipahiwatig na ang resulta ay palaging [`Ok`].
///
/// Halimbawa, ang [`TryFrom`] trait (conversion na nagbabalik ng [`Result`]) ay mayroong pagpapatupad ng kumot para sa lahat ng mga uri kung saan mayroong isang pabalik na pagpapatupad ng [`Into`].
///
/// ```ignore (illustrates std code, duplicating the impl in a doctest would be an error)
/// impl<T, U> TryFrom<U> for T where U: Into<T> {
///     type Error = Infallible;
///
///     fn try_from(value: U) -> Result<Self, Infallible> {
///         Ok(U::into(value))  // Never returns `Err`
///     }
/// }
/// ```
///
/// # Future compatibility
///
/// Ang enum na ito ay may parehong papel tulad ng [the `!`“never”type][never], na hindi matatag sa bersyon na ito ng Rust.
/// Kapag `!` ay nagpapatatag, plano naming gumawa ng `Infallible` isang uri alias dito:
///
/// ```ignore (illustrates future std change)
/// pub type Infallible = !;
/// ```
///
/// ... at sa huli ay magtakwil `Infallible`.
///
/// Gayunpaman mayroong isang kaso kung saan maaaring magamit ang `!` syntax bago ang `!` ay nagpapatatag bilang isang ganap na uri: sa posisyon ng uri ng pagbabalik ng isang pagpapaandar.
/// Sa partikular, ito ay posible na pagpapatupad para sa dalawang iba't-ibang uri ng function pointer:
///
/// ```
/// trait MyTrait {}
/// impl MyTrait for fn() -> ! {}
/// impl MyTrait for fn() -> std::convert::Infallible {}
/// ```
///
/// Sa `Infallible` na isang enum, ang code na ito ay wasto.
/// Gayunpaman kapag ang `Infallible` ay naging isang alias para sa never type, ang dalawang `impl`s ay magsisimulang mag-overlap at samakatuwid ay hindi papayagan ng mga panuntunan sa pagkakaisa ng trait ng wika.
///
///
///
///
///
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[derive(Copy)]
pub enum Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Clone for Infallible {
    fn clone(&self) -> Infallible {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Debug for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Display for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialEq for Infallible {
    fn eq(&self, _: &Infallible) -> bool {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Eq for Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialOrd for Infallible {
    fn partial_cmp(&self, _other: &Self) -> Option<crate::cmp::Ordering> {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Ord for Infallible {
    fn cmp(&self, _other: &Self) -> crate::cmp::Ordering {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl From<!> for Infallible {
    fn from(x: !) -> Self {
        x
    }
}

#[stable(feature = "convert_infallible_hash", since = "1.44.0")]
impl Hash for Infallible {
    fn hash<H: Hasher>(&self, _: &mut H) {
        match *self {}
    }
}