use crate::any::type_name;
use crate::fmt;
use crate::intrinsics;
use crate::mem::ManuallyDrop;
use crate::ptr;

/// Ang isang i-type ang wrapper upang bumuo ng uninitialized pagkakataon ng `T`.
///
/// # Pinasimulan invariant
///
/// Ang tagatala, sa pangkalahatan, Ipinagpapalagay na ang isang variable ay maayos na nasimulan ayon sa ang mga kinakailangan ng uri ng variable.Halimbawa, ang isang variable ng uri ng sanggunian ay dapat na nakahanay at hindi NUL.
/// Ito ay isang invariant na dapat *palaging* mapanatili, kahit na sa hindi ligtas na code.
/// Bilang kinahinatnan, zero-Sinisimulan ang isang variable ng uri ng sanggunian ay nagiging sanhi ng madalian [undefined behavior][ub], hindi mahalaga kung iyon reference kailanman ay makakakuha ng ginagamit upang access memory:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: &i32 = unsafe { mem::zeroed() }; // undefined pag-uugali!️
/// // Ang katumbas na code sa `MaybeUninit<&i32>`:
/// let x: &i32 = unsafe { MaybeUninit::zeroed().assume_init() }; // undefined pag-uugali!️
/// ```
///
/// Sinamantala ito ng tagatala para sa iba't ibang mga pag-optimize, tulad ng pagpili ng mga tseke sa run-time at pag-optimize ng layout ng `enum`.
///
/// Katulad nito, lubos na uninitialized memory ay maaaring magkaroon ng anumang nilalaman, habang ang isang `bool` dapat palaging magiging `true` o `false`.Samakatuwid, ang paglikha ng isang uninitialized `bool` ay hindi natukoy na pag-uugali:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let b: bool = unsafe { mem::uninitialized() }; // undefined pag-uugali!️
/// // Ang katumbas na code na may `MaybeUninit<bool>`:
/// let b: bool = unsafe { MaybeUninit::uninit().assume_init() }; // undefined pag-uugali!️
/// ```
///
/// Dagdag pa rito, uninitialized memory ay natatangi sa na ito ay hindi magkaroon ng isang nakapirming halaga ("fixed" nangangahulugang "it won't change without being written to").Binabasa ang parehong uninitialized byte maraming beses ay maaaring magbigay ng iba't ibang mga resulta.
/// Ginagawa nitong undefined pag-uugali na magkaroon ng uninitialized data sa isang variable kahit na variable ay isang integer uri, na kung saan kung hindi man ay maaaring magkaroon ng anumang *fixed* bit pattern:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: i32 = unsafe { mem::uninitialized() }; // undefined pag-uugali!️
/// // Ang katumbas na code sa `MaybeUninit<i32>`:
/// let x: i32 = unsafe { MaybeUninit::uninit().assume_init() }; // undefined pag-uugali!️
/// ```
/// (Pansinin na ang mga patakaran sa paligid ng uninitialized integers ay hindi tinatapos pa, pero hanggang sa ang mga ito ay, ito ay ipinapayong upang maiwasan ang mga ito.)
///
/// Bukod pa rito, alalahanin na ang karamihan sa mga uri ay may mga karagdagang invariant na lampas lamang sa isinasaalang-alang na pinasimula sa antas ng uri.
/// Halimbawa, ang isang `1`-initialize [`Vec<T>`] ay itinuturing initialize (sa ilalim ng kasalukuyang pagpapatupad, ito ay hindi bumubuo ng isang matatag na garantiya) dahil ang tanging kinakailangan compiler ang nakakaalam tungkol dito ay na ang data pointer ay dapat na non-null.
/// Paglikha ng ganoong `Vec<T>` ay hindi dahilan *agarang* undefined pag-uugali, ngunit magiging sanhi undefined pag-uugali ng karamihan sa ligtas na operasyon (kabilang ang pag-drop ito).
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
///
/// # Examples
///
/// `MaybeUninit<T>` Naghahain upang paganahin ang mga hindi ligtas na code upang harapin ang uninitialized data.
/// Ito ay isang senyas sa tagatala na nagpapahiwatig na ang data dito ay maaaring *hindi* mapasimulan:
///
/// ```rust
/// use std::mem::MaybeUninit;
///
/// // Lumikha ng isang tahasang uninitialized reference.
/// // Ang tagatala ang nakakaalam na ang data sa loob ng isang `MaybeUninit<T>` ay maaaring hindi wasto, at samakatuwid ito ay hindi UB:
/// let mut x = MaybeUninit::<&i32>::uninit();
/// // Itakda ito sa isang wastong halaga.
/// unsafe { x.as_mut_ptr().write(&0); }
/// // I-extract ang inisyal na data-pinapayagan lamang ito *pagkatapos* maayos na pagsisimula ng `x`!
/////
/// let x = unsafe { x.assume_init() };
/// ```
///
/// Ang tagatala pagkatapos ay alam na hindi gumawa ng anumang mga maling pagpapalagay o optimization sa code na ito.
///
/// Maaari mong isipin ang `MaybeUninit<T>` bilang isang medyo tulad ng `Option<T>` ngunit walang anuman sa run-time na pagsubaybay at walang anumang mga pagsusuri sa kaligtasan.
///
/// ## out-pointers
///
/// Maaari mong gamitin ang `MaybeUninit<T>` upang ipatupad ang "out-pointers": sa halip na ibalik ang data mula sa isang pagpapaandar, ipasa ito isang pointer sa ilang memorya ng (uninitialized) upang ilagay ang resulta.
/// Maaari itong maging kapaki-pakinabang kung mahalaga na makontrol ng tumatawag kung paano nakalaan ang memorya na resulta ay naimbak, at nais mong iwasan ang mga hindi kinakailangang paggalaw.
///
/// ```
/// use std::mem::MaybeUninit;
///
/// unsafe fn make_vec(out: *mut Vec<i32>) {
///     // `write` ay hindi nahuhulog ang mga lumang nilalaman, na kung saan ay mahalaga.
///     out.write(vec![1, 2, 3]);
/// }
///
/// let mut v = MaybeUninit::uninit();
/// unsafe { make_vec(v.as_mut_ptr()); }
/// // Ngayon alam na natin `v` ay initialize!Ito din ay gumagawa sigurado ang vector ay makakakuha ng maayos bumaba.
/////
/// let v = unsafe { v.assume_init() };
/// assert_eq!(&v, &[1, 2, 3]);
/// ```
///
/// ## Sinisimulan ang isang array na sangkap-by-element
///
/// `MaybeUninit<T>` ay maaaring gamitin upang magpasimula ng isang malaking array na sangkap-by-element:
///
/// ```
/// use std::mem::{self, MaybeUninit};
///
/// let data = {
///     // Lumikha ng isang uninitialized hanay ng `MaybeUninit`.
///     // Ang `assume_init` ay ligtas dahil ang uri na inaangkin namin na napasimuno dito ay isang grupo ng mga `MaybeUninit`s, na hindi nangangailangan ng pagsisimula.
/////
///     let mut data: [MaybeUninit<Vec<u32>>; 1000] = unsafe {
///         MaybeUninit::uninit().assume_init()
///     };
///
///     // Pag-drop ng isang `MaybeUninit` walang ginagawa.
///     // Kaya gamit raw pointer assignment sa halip na `ptr::write` ay hindi maging sanhi ng mga lumang uninitialized halaga na bumaba.
/////
///     // Gayundin kung mayroong isang panic sa panahon na ito loop, mayroon kaming isang memory tumagas, ngunit walang isyu memory kaligtasan.
/////
///     for elem in &mut data[..] {
///         *elem = MaybeUninit::new(vec![42]);
///     }
///
///     // Lahat ng bagay ay nasimulan.
///     // Magbago ang array sa initialize uri.
///     unsafe { mem::transmute::<_, [Vec<u32>; 1000]>(data) }
/// };
///
/// assert_eq!(&data[0], &[42]);
/// ```
///
/// Maaari mo ring gumana sa bahagyang initialize array, na maaaring matagpuan sa mababang antas ng datastructures.
///
/// ```
/// use std::mem::MaybeUninit;
/// use std::ptr;
///
/// // Lumikha ng isang uninitialized hanay ng `MaybeUninit`.
/// // Ang `assume_init` ay ligtas dahil ang uri na inaangkin namin na napasimuno dito ay isang grupo ng mga `MaybeUninit`s, na hindi nangangailangan ng pagsisimula.
/////
/// let mut data: [MaybeUninit<String>; 1000] = unsafe { MaybeUninit::uninit().assume_init() };
/// // Bilangin ang bilang ng mga elemento na namin na nakatalaga.
/// let mut data_len: usize = 0;
///
/// for elem in &mut data[0..500] {
///     *elem = MaybeUninit::new(String::from("hello"));
///     data_len += 1;
/// }
///
/// // Para sa bawat item sa array, drop kung inilalaan namin ito.
/// for elem in &mut data[0..data_len] {
///     unsafe { ptr::drop_in_place(elem.as_mut_ptr()); }
/// }
/// ```
///
/// ## Sinisimulan ang isang struct field-by-field
///
/// Maaari mong gamitin ang `MaybeUninit<T>`, at ang [`std::ptr::addr_of_mut`] macro, i-initialize structs patlang sa pamamagitan field:
///
/// ```rust
/// use std::mem::MaybeUninit;
/// use std::ptr::addr_of_mut;
///
/// #[derive(Debug, PartialEq)]
/// pub struct Foo {
///     name: String,
///     list: Vec<u8>,
/// }
///
/// let foo = {
///     let mut uninit: MaybeUninit<Foo> = MaybeUninit::uninit();
///     let ptr = uninit.as_mut_ptr();
///
///     // Sinisimulan ang `name` field
///     unsafe { addr_of_mut!((*ptr).name).write("Bob".to_string()); }
///
///     // Sinisimulan ang `list` patlang na Kung may isang panic dito, pagkatapos ay ang `String` sa `name` paglabas field.
/////
///     unsafe { addr_of_mut!((*ptr).list).write(vec![0, 1, 2]); }
///
///     // Ang lahat ng mga patlang ay initialize, kaya tinatawag naming `assume_init` upang makakuha ng isang initialize Foo.
///     unsafe { uninit.assume_init() }
/// };
///
/// assert_eq!(
///     foo,
///     Foo {
///         name: "Bob".to_string(),
///         list: vec![0, 1, 2]
///     }
/// );
/// ```
/// [`std::ptr::addr_of_mut`]: crate::ptr::addr_of_mut
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Layout
///
/// `MaybeUninit<T>` ay garantisadong na magkaroon ng parehong laki, pagkakahanay, at ABI bilang `T`:
///
/// ```rust
/// use std::mem::{MaybeUninit, size_of, align_of};
/// assert_eq!(size_of::<MaybeUninit<u64>>(), size_of::<u64>());
/// assert_eq!(align_of::<MaybeUninit<u64>>(), align_of::<u64>());
/// ```
///
/// Gayunpaman tandaan na ang isang uri *na naglalaman ng* isang `MaybeUninit<T>` ay hindi kinakailangan ang parehong layout;Rust ay hindi sa pangkalahatan garantiya na ang mga patlang ng isang `Foo<T>` ay may parehong pagkakasunud-sunod bilang `Foo<U>` kahit `T` at `U` magkaroon ng parehong laki at pag-align.
///
/// Higit pa rito dahil ang anumang bit na halaga ay may-bisa para sa isang `MaybeUninit<T>` ang tagatala ay hindi maaaring mag-apply non-zero/niche-filling pag-optimize, potensyal na nagreresulta sa isang mas malaking sukat:
///
/// ```rust
/// # use std::mem::{MaybeUninit, size_of};
/// assert_eq!(size_of::<Option<bool>>(), 1);
/// assert_eq!(size_of::<Option<MaybeUninit<bool>>>(), 2);
/// ```
///
/// Kung `T` ay FFI-safe, ganoon din ang `MaybeUninit<T>`.
///
/// Habang `MaybeUninit` ay `#[repr(transparent)]` (na nagpapahiwatig tinitiyak nito ang parehong laki, pagkakahanay, at ABI bilang `T`), ito ay *hindi* baguhin ang anuman sa mga nakaraang caveats.
/// `Option<T>` at `Option<MaybeUninit<T>>` ay maaari pa ring magkaroon ng iba't ibang mga sukat, at mga uri na naglalaman ng isang patlang ng uri `T` ay maaaring inilatag out (at ang laki) sa ibang paraan kaysa sa kung ang patlang na `MaybeUninit<T>`.
/// `MaybeUninit` ay isang uri ng unyon, at `#[repr(transparent)]` sa mga unyon ay hindi matatag (tingnan [the tracking issue](https://github.com/rust-lang/rust/issues/60405)).
/// Sa paglipas ng panahon, ang eksaktong garantiya ng `#[repr(transparent)]` sa mga unyon ay maaaring evolve, at `MaybeUninit` maaaring o hindi maaaring manatiling `#[repr(transparent)]`.
/// Sa gayon, `MaybeUninit<T>` kalooban *laging* garantiya na ito ay may parehong sukat, pagkakahanay, at ABI bilang `T`;ito ay lamang na ang paraan `MaybeUninit` nagpapatupad na garantiya ay maaaring evolve.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "maybe_uninit", since = "1.36.0")]
// Lang item upang maaari naming balutin iba pang mga uri sa loob nito.Kapaki-pakinabang ito para sa mga generator.
#[lang = "maybe_uninit"]
#[derive(Copy)]
#[repr(transparent)]
pub union MaybeUninit<T> {
    uninit: (),
    value: ManuallyDrop<T>,
}

#[stable(feature = "maybe_uninit", since = "1.36.0")]
impl<T: Copy> Clone for MaybeUninit<T> {
    #[inline(always)]
    fn clone(&self) -> Self {
        // Hindi pagtawag `T::clone()`, hindi natin malalaman kung tayo ay initialize sapat para sa na.
        *self
    }
}

#[stable(feature = "maybe_uninit_debug", since = "1.41.0")]
impl<T> fmt::Debug for MaybeUninit<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad(type_name::<Self>())
    }
}

impl<T> MaybeUninit<T> {
    /// Lumilikha ng isang bagong `MaybeUninit<T>` na pinasimulan sa ibinigay na halaga.
    /// Ito ay ligtas na tumawag [`assume_init`] sa return value ng mga ito function.
    ///
    /// Tandaan na ang pag-drop ng isang `MaybeUninit<T>` hindi kailanman ay tumawag `drop code ni T`.
    /// Ito ay ang iyong pananagutan upang siguraduhin `T` ay makakakuha ng bumaba kung ito got nasimulan.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<Vec<u8>> = MaybeUninit::new(vec![42]);
    /// ```
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(val: T) -> MaybeUninit<T> {
        MaybeUninit { value: ManuallyDrop::new(val) }
    }

    /// Lumilikha ng isang bagong `MaybeUninit<T>` sa isang uninitialized estado.
    ///
    /// Tandaan na ang pag-drop ng isang `MaybeUninit<T>` hindi kailanman ay tumawag `drop code ni T`.
    /// Ito ay ang iyong pananagutan upang siguraduhin `T` ay makakakuha ng bumaba kung ito got nasimulan.
    ///
    /// Tingnan ang [type-level documentation][MaybeUninit] para sa ilang mga halimbawa.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<String> = MaybeUninit::uninit();
    /// ```
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    #[rustc_diagnostic_item = "maybe_uninit_uninit"]
    pub const fn uninit() -> MaybeUninit<T> {
        MaybeUninit { uninit: () }
    }

    /// Lumikha ng isang bagong hanay ng mga item na `MaybeUninit<T>`, sa isang hindi unipormadong estado.
    ///
    /// Note: sa isang future Rust bersyon na ito paraan ay maaaring maging hindi kinakailangang kapag array literal na syntax ay nagbibigay-daan [repeating const expressions](https://github.com/rust-lang/rust/issues/49147).
    ///
    /// Ang halimbawa sa ibaba ay maaaring gumamit ng `let mut buf = [MaybeUninit::<u8>::uninit(); 32];`.
    ///
    /// # Examples
    ///
    /// ```no_run
    /// #![feature(maybe_uninit_uninit_array, maybe_uninit_extra, maybe_uninit_slice)]
    ///
    /// use std::mem::MaybeUninit;
    ///
    /// extern "C" {
    ///     fn read_into_buffer(ptr: *mut u8, max_len: usize) -> usize;
    /// }
    ///
    /// /// Nagbabalik ng isang (maaaring mas maliit) na hati ng data na na tunay na basahin
    /// fn read(buf: &mut [MaybeUninit<u8>]) -> &[u8] {
    ///     unsafe {
    ///         let len = read_into_buffer(buf.as_mut_ptr() as *mut u8, buf.len());
    ///         MaybeUninit::slice_assume_init_ref(&buf[..len])
    ///     }
    /// }
    ///
    /// let mut buf: [MaybeUninit<u8>; 32] = MaybeUninit::uninit_array();
    /// let data = read(&mut buf);
    /// ```
    ///
    #[unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[rustc_const_unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[inline(always)]
    pub const fn uninit_array<const LEN: usize>() -> [Self; LEN] {
        // KALIGTASAN: isang uninitialized `[MaybeUninit<_>; LEN]` ay may-bisa.
        unsafe { MaybeUninit::<[MaybeUninit<T>; LEN]>::uninit().assume_init() }
    }

    /// Lumilikha ng isang bagong `MaybeUninit<T>` sa isang uninitialized na estado, na may memorya na puno ng `0` bytes.Depende ito sa `T` kung gumagawa na iyon para sa wastong pagsisimula.
    ///
    /// Halimbawa, ang `MaybeUninit<usize>::zeroed()` ay pinasimulan, ngunit ang `MaybeUninit<&'static i32>::zeroed()` ay hindi dahil ang mga sanggunian ay hindi dapat maging null.
    ///
    /// Tandaan na ang pag-drop ng isang `MaybeUninit<T>` hindi kailanman ay tumawag `drop code ni T`.
    /// Ito ay ang iyong pananagutan upang siguraduhin `T` ay makakakuha ng bumaba kung ito got nasimulan.
    ///
    /// # Example
    ///
    /// Tamang paggamit ng function na ito: Sinisimulan ang isang struct na may mga zero, kung saan lahat ng mga patlang ng struct ay maaaring i-hold ang bit-pattern 0 bilang isang wastong halaga.
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<(u8, bool)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// assert_eq!(x, (0, false));
    /// ```
    ///
    /// *Maling* paggamit ng function na ito: pagtawag `x.zeroed().assume_init()` kapag `0` ay hindi isang wastong bit-pattern para sa uri:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// enum NotZero { One = 1, Two = 2 }
    ///
    /// let x = MaybeUninit::<(u8, NotZero)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// // Sa loob ng isang pares, lumikha kami ng isang `NotZero` na walang wastong diskriminasyon.
    /// // Ito ay hindi natukoy na pag-uugali.️
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[inline]
    #[rustc_diagnostic_item = "maybe_uninit_zeroed"]
    pub fn zeroed() -> MaybeUninit<T> {
        let mut u = MaybeUninit::<T>::uninit();
        // KALIGTASAN: `u.as_mut_ptr()` tumuturo sa inilalaan memory.
        unsafe {
            u.as_mut_ptr().write_bytes(0u8, 1);
        }
        u
    }

    /// Itinatakda ang halaga ng `MaybeUninit<T>`.
    /// Ito ay umookupa anumang mga nakaraang halaga nang hindi bumababa ito, kaya mag-ingat na huwag gamitin ito nang dalawang beses maliban kung gusto mo upang laktawan ang pagpapatakbo ng destructor.
    ///
    /// Para sa iyong kaginhawaan, ito rin ay nagbabalik maaaring mabago ng isang reference sa (ngayon ay ligtas na nasimulan) mga nilalaman ng `self`.
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const fn write(&mut self, val: T) -> &mut T {
        *self = MaybeUninit::new(val);
        // KALIGTASAN: lang namin nasimulan ang halagang ito.
        unsafe { self.assume_init_mut() }
    }

    /// Ay makakakuha ng isang pointer sa nakapaloob na halaga.
    /// Pagbasa mula sa pointer ito o i-on ito sa isang reference ay hindi natukoy na pag-uugali maliban kung ang `MaybeUninit<T>` ay nasimulan.
    /// Pagsulat sa memory na ito pointer (non-transitively) puntos sa ay hindi natukoy na pag-uugali (maliban sa loob ng isang `UnsafeCell<T>`).
    ///
    /// # Examples
    ///
    /// Tamang paggamit ng ang paraan na ito:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // Gumawa ng isang reference sa `MaybeUninit<T>`.Okay lang ito dahil inisyal namin ito.
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// assert_eq!(x_vec.len(), 3);
    /// ```
    ///
    /// *Maling* paggamit ng pamamaraang ito:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// // Gumawa kami ng isang reference sa isang uninitialized vector!Ito ay hindi natukoy na pag-uugali.️
    /// ```
    ///
    /// (Pansinin na ang mga panuntunan sa paligid ng mga sanggunian sa hindi unipormalisadong data ay hindi pa natatapos, ngunit hanggang sa mangyari, ipinapayong iwasan ang mga ito.)
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_ptr(&self) -> *const T {
        // `MaybeUninit` at `ManuallyDrop` ay parehong `repr(transparent)` upang maaari naming nagsumite ang pointer.
        self as *const _ as *const T
    }

    /// Nakakakuha ng isang nababagong pointer sa nilalaman na nilalaman.
    /// Pagbasa mula sa pointer ito o i-on ito sa isang reference ay hindi natukoy na pag-uugali maliban kung ang `MaybeUninit<T>` ay nasimulan.
    ///
    /// # Examples
    ///
    /// Tamang paggamit ng ang paraan na ito:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // Gumawa ng isang reference sa `MaybeUninit<Vec<u32>>`.
    /// // Ito ay okay dahil nasimulan namin ito.
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// x_vec.push(3);
    /// assert_eq!(x_vec.len(), 4);
    /// ```
    ///
    /// *Maling* paggamit ng pamamaraang ito:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// // Gumawa kami ng isang reference sa isang uninitialized vector!Ito ay hindi natukoy na pag-uugali.️
    /// ```
    ///
    /// (Pansinin na ang mga panuntunan sa paligid ng mga sanggunian sa hindi unipormalisadong data ay hindi pa natatapos, ngunit hanggang sa mangyari, ipinapayong iwasan ang mga ito.)
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        // `MaybeUninit` at `ManuallyDrop` ay parehong `repr(transparent)` upang maaari naming nagsumite ang pointer.
        self as *mut _ as *mut T
    }

    /// Extracts ang halaga mula sa `MaybeUninit<T>` container.Ito ay isang mahusay na paraan upang masiguro na ang data ay hindi maisasali, dahil ang mga nagresultang `T` ay napapailalim sa mga karaniwang drop handling.
    ///
    /// # Safety
    ///
    /// Ito ay hanggang sa ang mga tumatawag na garantiya na ang `MaybeUninit<T>` ay tunay na sa isang initialize ng estado.Pagtawag ito kapag ang nilalaman ay hindi pa ganap na nasimulan sanhi ng agarang undefined pag-uugali.
    /// Ang [type-level documentation][inv] ay naglalaman ng karagdagang impormasyon tungkol sa pagsisimula ng invariant.
    ///
    /// [inv]: #initialization-invariant
    ///
    /// Bukod pa rito, alalahanin na ang karamihan sa mga uri ay may mga karagdagang invariant na lampas lamang sa isinasaalang-alang na pinasimula sa antas ng uri.
    /// Halimbawa, ang isang `1`-initialize [`Vec<T>`] ay itinuturing initialize (sa ilalim ng kasalukuyang pagpapatupad, ito ay hindi bumubuo ng isang matatag na garantiya) dahil ang tanging kinakailangan compiler ang nakakaalam tungkol dito ay na ang data pointer ay dapat na non-null.
    ///
    /// Paglikha ng ganoong `Vec<T>` ay hindi dahilan *agarang* undefined pag-uugali, ngunit magiging sanhi undefined pag-uugali ng karamihan sa ligtas na operasyon (kabilang ang pag-drop ito).
    ///
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    /// # Examples
    ///
    /// Tamang paggamit ng ang paraan na ito:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<bool>::uninit();
    /// unsafe { x.as_mut_ptr().write(true); }
    /// let x_init = unsafe { x.assume_init() };
    /// assert_eq!(x_init, true);
    /// ```
    ///
    /// *Maling* paggamit ng pamamaraang ito:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_init = unsafe { x.assume_init() };
    /// // `x` hindi pa nasimulan pa, kaya ito huling linya na sanhi undefined pag-uugali.️
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    #[rustc_diagnostic_item = "assume_init"]
    pub const unsafe fn assume_init(self) -> T {
        // KALIGTASAN: ang tumatawag ay dapat garantiya na `self` ay nasimulan.
        // Nangangahulugan din ito na ang `self` ay dapat na isang `value` variant.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            ManuallyDrop::into_inner(self.value)
        }
    }

    /// Binabasa ang halaga mula sa lalagyan na `MaybeUninit<T>`.Ang resultang `T` ay napapailalim sa mga karaniwang drop handling.
    ///
    /// Hangga't maaari, ito ay lalong kanais-nais gamitin [`assume_init`] halip, na pumipigil dodoblehin ang nilalaman ng `MaybeUninit<T>`.
    ///
    /// # Safety
    ///
    /// Ito ay hanggang sa ang mga tumatawag na garantiya na ang `MaybeUninit<T>` ay tunay na sa isang initialize ng estado.Ang pagtawag nito kapag ang nilalaman ay hindi pa ganap na naisasimulan ay nagiging sanhi ng hindi natukoy na pag-uugali.
    /// Ang [type-level documentation][inv] ay naglalaman ng karagdagang impormasyon tungkol sa pagsisimula ng invariant.
    ///
    /// Bukod dito, ito dahon ng isang kopya ng parehong data sa likod sa `MaybeUninit<T>`.
    /// Kapag gumagamit ng maramihang mga kopya ng data (sa pamamagitan ng pagtawag `assume_init_read` maraming beses, o unang pagtawag `assume_init_read` at pagkatapos ay [`assume_init`]), ito ay ang iyong responsibilidad upang matiyak na ang data na iyon ay maaaring sa katunayan ay nadoble.
    ///
    ///
    /// [inv]: #initialization-invariant
    /// [`assume_init`]: MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// Tamang paggamit ng ang paraan na ito:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<u32>::uninit();
    /// x.write(13);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // `u32` ay `Copy`, kaya maaari nating basahin ang maraming beses.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(None);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // Ang pagdoble ng isang halagang `None` ay okay, kaya maaari naming basahin ang maraming beses.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    /// ```
    ///
    /// *Maling* paggamit ng pamamaraang ito:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(Some(vec![0, 1, 2]));
    /// let x1 = unsafe { x.assume_init_read() };
    /// let x2 = unsafe { x.assume_init_read() };
    /// // Lumikha kami ngayon ng dalawang kopya ng parehong vector, na humahantong sa isang dobleng-free ⚠️ nang pareho silang nalaglag!
    /////
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const unsafe fn assume_init_read(&self) -> T {
        // KALIGTASAN: ang tumatawag ay dapat garantiya na `self` ay nasimulan.
        // Pagbasa mula `self.as_ptr()` ay ligtas dahil `self` ay dapat na-initialize.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            self.as_ptr().read()
        }
    }

    /// Patak ang nilalaman na nilalaman sa lugar.
    ///
    /// Kung mayroon kang pagmamay-ari ng `MaybeUninit`, maaari mong gamitin [`assume_init`] sa halip.
    ///
    /// # Safety
    ///
    /// Ito ay hanggang sa ang mga tumatawag na garantiya na ang `MaybeUninit<T>` ay tunay na sa isang initialize ng estado.Ang pagtawag nito kapag ang nilalaman ay hindi pa ganap na naisasimulan ay nagiging sanhi ng hindi natukoy na pag-uugali.
    ///
    /// Sa itaas ng na, ang lahat ng mga karagdagang invariants ng uri `T` ay dapat na nasiyahan, bilang ang `Drop` pagpapatupad ng `T` (o mga miyembro nito) ay maaaring umaasa sa mga ito.
    /// Halimbawa, ang isang `1`-initialize [`Vec<T>`] ay itinuturing initialize (sa ilalim ng kasalukuyang pagpapatupad, ito ay hindi bumubuo ng isang matatag na garantiya) dahil ang tanging kinakailangan compiler ang nakakaalam tungkol dito ay na ang data pointer ay dapat na non-null.
    ///
    /// Bumababa tulad ng isang `Vec<T>` gayunpaman ay magiging sanhi undefined pag-uugali.
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    pub unsafe fn assume_init_drop(&mut self) {
        // KALIGTASAN: dapat magagarantiya ng tumatawag na ang `self` ay naisaisa at
        // satisfies ang lahat ng invariants ng `T`.
        // Bumababa ang halaga sa lugar ay ligtas kung iyon ang kaso.
        unsafe { ptr::drop_in_place(self.as_mut_ptr()) }
    }

    /// Ay makakakuha ng isang shared reference sa mga nakapaloob na halaga.
    ///
    /// Maaari itong maging kapaki-pakinabang kapag nais naming i-access ang isang `MaybeUninit` na naisimula ngunit walang pagmamay-ari ng `MaybeUninit` (pinipigilan ang paggamit ng `.assume_init()`).
    ///
    /// # Safety
    ///
    /// Pagtawag ito kapag ang nilalaman ay hindi pa ganap na nasimulan sanhi undefined uugali: ito ay hanggang sa tumatawag na garantiya na ang `MaybeUninit<T>` ay tunay na sa isang initialize ng estado.
    ///
    ///
    /// # Examples
    ///
    /// ### Tamang paggamit ng ang paraan na ito:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// // Pasimulan ang `x`:
    /// unsafe { x.as_mut_ptr().write(vec![1, 2, 3]); }
    /// // Ngayon na ang aming `MaybeUninit<_>` ay kilala upang ma-initialize, ito ay okay upang lumikha ng isang shared reference dito:
    /////
    /// let x: &Vec<u32> = unsafe {
    ///     // KALIGTASAN: Ang `x` ay naisimula.
    ///     x.assume_init_ref()
    /// };
    /// assert_eq!(x, &vec![1, 2, 3]);
    /// ```
    ///
    /// ### *Maling* paggamit ng pamamaraang ito:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec: &Vec<u32> = unsafe { x.assume_init_ref() };
    /// // Gumawa kami ng isang reference sa isang uninitialized vector!Ito ay hindi natukoy na pag-uugali.️
    /// ```
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{cell::Cell, mem::MaybeUninit};
    ///
    /// let b = MaybeUninit::<Cell<bool>>::uninit();
    /// // Simulan ang `MaybeUninit` gamit ang `Cell::set`:
    /// unsafe {
    ///     b.assume_init_ref().set(true);
    ///    // ^^^^^^^^^^^^^^^
    ///    // Reference sa isang uninitialized `Cell<bool>`: UB!
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_ref(&self) -> &T {
        // KALIGTASAN: ang tumatawag ay dapat garantiya na `self` ay nasimulan.
        // Nangangahulugan din ito na ang `self` ay dapat na isang `value` variant.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &*self.as_ptr()
        }
    }

    /// Ay makakakuha ng isang nagbabago (unique) reference sa mga nakapaloob na halaga.
    ///
    /// Maaari itong maging kapaki-pakinabang kapag nais naming i-access ang isang `MaybeUninit` na naisimula ngunit walang pagmamay-ari ng `MaybeUninit` (pinipigilan ang paggamit ng `.assume_init()`).
    ///
    /// # Safety
    ///
    /// Pagtawag ito kapag ang nilalaman ay hindi pa ganap na nasimulan sanhi undefined uugali: ito ay hanggang sa tumatawag na garantiya na ang `MaybeUninit<T>` ay tunay na sa isang initialize ng estado.
    /// Halimbawa, ang `.assume_init_mut()` ay hindi maaaring gamitin upang simulan ang isang `MaybeUninit`.
    ///
    /// # Examples
    ///
    /// ### Tamang paggamit ng ang paraan na ito:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// # unsafe extern "C" fn initialize_buffer(buf: *mut [u8; 2048]) { *buf = [0; 2048] }
    /// # #[cfg(FALSE)]
    /// extern "C" {
    ///     /// Initializes *lahat* ang bytes ng input buffer.
    ///     fn initialize_buffer(buf: *mut [u8; 2048]);
    /// }
    ///
    /// let mut buf = MaybeUninit::<[u8; 2048]>::uninit();
    ///
    /// // Pasimulan ang `buf`:
    /// unsafe { initialize_buffer(buf.as_mut_ptr()); }
    /// // Ngayo'y nalalaman naming mayroon `buf` ay initialize, kaya maaari kaming `.assume_init()` ito.
    /// // Gayunpaman, ang paggamit ng `.assume_init()` ay maaaring magpalitaw ng `memcpy` ng 2048 bytes.
    /// // Upang igiit ang aming buffer ay nasimulan nang walang pagkopya ng mga ito, i-upgrade namin ang `&mut MaybeUninit<[u8; 2048]>` sa isang `&mut [u8; 2048]`:
    /////
    /// let buf: &mut [u8; 2048] = unsafe {
    ///     // KALIGTASAN: `buf` ay initialize.
    ///     buf.assume_init_mut()
    /// };
    ///
    /// // Ngayon ay maaari naming gamitin ang `buf` bilang isang normal na hiwa:
    /// buf.sort_unstable();
    /// assert!(
    ///     buf.windows(2).all(|pair| pair[0] <= pair[1]),
    ///     "buffer is sorted",
    /// );
    /// ```
    ///
    /// ### *Maling* paggamit ng pamamaraang ito:
    ///
    /// Hindi mo maaaring gamitin ang `.assume_init_mut()` upang simulan ang isang halaga:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut b = MaybeUninit::<bool>::uninit();
    /// unsafe {
    ///     *b.assume_init_mut() = true;
    ///     // Gumawa kami ng isang (mutable) reference sa isang uninitialized `bool`!
    ///     // Ito ay hindi natukoy na pag-uugali.️
    /// }
    /// ```
    ///
    /// Halimbawa, hindi ka maaaring [`Read`] sa isang uninitialized buffer:
    ///
    /// [`Read`]: https://doc.rust-lang.org/std/io/trait.Read.html
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{io, mem::MaybeUninit};
    ///
    /// fn read_chunk (reader: &'_ mut dyn io::Read) -> io::Result<[u8; 64]>
    /// {
    ///     let mut buffer = MaybeUninit::<[u8; 64]>::uninit();
    ///     reader.read_exact(unsafe { buffer.assume_init_mut() })?;
    ///                             // ^^^^^^^^^^^^^^^^^^^^^^^^
    ///                             // (mutable) sanggunian sa uninitialized memory!
    ///                             // Ito ay hindi natukoy na pag-uugali.
    ///     Ok(unsafe { buffer.assume_init() })
    /// }
    /// ```
    ///
    /// Hindi ka rin makakagamit ng direktang pag-access sa patlang upang gawin ang field-by-field na unti-unting pagsisimula:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{mem::MaybeUninit, ptr};
    ///
    /// struct Foo {
    ///     a: u32,
    ///     b: u8,
    /// }
    ///
    /// let foo: Foo = unsafe {
    ///     let mut foo = MaybeUninit::<Foo>::uninit();
    ///     ptr::write(&mut foo.assume_init_mut().a as *mut u32, 1337);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) sanggunian sa uninitialized memory!
    ///                  // Ito ay hindi natukoy na pag-uugali.
    ///     ptr::write(&mut foo.assume_init_mut().b as *mut u8, 42);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) sanggunian sa uninitialized memory!
    ///                  // Ito ay hindi natukoy na pag-uugali.
    ///     foo.assume_init()
    /// };
    /// ```
    ///
    ///
    ///
    ///
    // FIXME(#76092): Kasalukuyan kaming umaasa sa hindi tama ang nasa itaas, ibig sabihin, mayroon kaming mga sanggunian sa hindi sinasabing data (hal., Sa `libcore/fmt/float.rs`).
    // Dapat tayong gumawa ng isang pangwakas na desisyon tungkol sa mga patakaran bago pagpapapanatag.
    //
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_mut(&mut self) -> &mut T {
        // KALIGTASAN: ang tumatawag ay dapat garantiya na `self` ay nasimulan.
        // Nangangahulugan din ito na ang `self` ay dapat na isang `value` variant.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &mut *self.as_mut_ptr()
        }
    }

    /// Extracts ang mga halaga mula sa isang hanay ng mga `MaybeUninit` container.
    ///
    /// # Safety
    ///
    /// Ito ay hanggang sa ang mga tumatawag na garantiya na ang lahat ng mga elemento ng array ay nasa isang initialize ng estado.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_uninit_array)]
    /// #![feature(maybe_uninit_array_assume_init)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut array: [MaybeUninit<i32>; 3] = MaybeUninit::uninit_array();
    /// array[0] = MaybeUninit::new(0);
    /// array[1] = MaybeUninit::new(1);
    /// array[2] = MaybeUninit::new(2);
    ///
    /// // KALIGTASAN: Ngayon safe namin initialised lahat ng mga elemento
    /// let array = unsafe {
    ///     MaybeUninit::array_assume_init(array)
    /// };
    ///
    /// assert_eq!(array, [0, 1, 2]);
    /// ```
    #[unstable(feature = "maybe_uninit_array_assume_init", issue = "80908")]
    #[inline(always)]
    pub unsafe fn array_assume_init<const N: usize>(array: [Self; N]) -> [T; N] {
        // SAFETY:
        // * Ang caller garantiya na ang lahat ng mga elemento ng array ay initialize
        // * `MaybeUninit<T>` at T ay garantisadong magkaroon ng parehong layout
        // * MaybeUnint ay hindi drop, kaya walang mga double-frees At sa gayon ay ang conversion ay ligtas
        //
        unsafe {
            intrinsics::assert_inhabited::<[T; N]>();
            (&array as *const _ as *const [T; N]).read()
        }
    }

    /// Sa pag-aakala ng lahat ng mga elemento ay initialize, kumuha ng isang slice sa kanila.
    ///
    /// # Safety
    ///
    /// Ito ay hanggang sa ang mga tumatawag na masiguro na ang `MaybeUninit<T>` elemento talaga sa isang initialize ng estado.
    ///
    /// Ang pagtawag nito kapag ang nilalaman ay hindi pa ganap na naisasimulan ay nagiging sanhi ng hindi natukoy na pag-uugali.
    ///
    /// Tingnan [`assume_init_ref`] para sa karagdagang detalye at mga halimbawa.
    ///
    /// [`assume_init_ref`]: MaybeUninit::assume_init_ref
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_ref(slice: &[Self]) -> &[T] {
        // KALIGTASAN: cast slice sa isang `*const [T]` ay ligtas dahil ang tumatawag garantiya na
        // `slice` ay naisimulan, at ang `MaybeUninit` ay ginagarantiyahan na magkaroon ng parehong layout tulad ng `T`.
        // Ang pointer na nakuha ay wasto dahil tumutukoy ito sa memorya na pagmamay-ari ng `slice` na isang sanggunian at sa gayon garantisadong maging wasto para sa mga bumabasa.
        //
        unsafe { &*(slice as *const [Self] as *const [T]) }
    }

    /// Sa pag-aakala ng lahat ng mga elemento ay initialize, kumuha ng isang nagbabago slice sa kanila.
    ///
    /// # Safety
    ///
    /// Ito ay hanggang sa ang mga tumatawag na masiguro na ang `MaybeUninit<T>` elemento talaga sa isang initialize ng estado.
    ///
    /// Ang pagtawag nito kapag ang nilalaman ay hindi pa ganap na naisasimulan ay nagiging sanhi ng hindi natukoy na pag-uugali.
    ///
    /// Tingnan [`assume_init_mut`] para sa karagdagang detalye at mga halimbawa.
    ///
    /// [`assume_init_mut`]: MaybeUninit::assume_init_mut
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_mut(slice: &mut [Self]) -> &mut [T] {
        // KALIGTASAN: katulad ng mga tala ng kaligtasan para sa `slice_get_ref`, ngunit mayroon kaming
        // nababagong sanggunian na ginagarantiyahan din na wasto para sa mga pagsusulat.
        unsafe { &mut *(slice as *mut [Self] as *mut [T]) }
    }

    /// Ay makakakuha ng isang pointer sa unang elemento ng array.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_ptr(this: &[MaybeUninit<T>]) -> *const T {
        this.as_ptr() as *const T
    }

    /// Ay makakakuha ng isang nagbabago pointer sa unang elemento ng array.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_mut_ptr(this: &mut [MaybeUninit<T>]) -> *mut T {
        this.as_mut_ptr() as *mut T
    }

    /// Ang mga kopya ng mga elemento mula sa `src` na `this`, mga bumabalik na maaaring mabago ng isang reference sa ngayon initalized nilalaman ng `this`.
    ///
    /// Kung `T` ay hindi ipatupad `Copy`, gamitin [`write_slice_cloned`]
    ///
    /// Ito ay katulad ng [`slice::copy_from_slice`].
    ///
    /// # Panics
    ///
    /// Function na ito ay panic kung ang dalawang hiwa ay may iba't ibang mga haba.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(); 32];
    /// let src = [0; 32];
    ///
    /// let init = MaybeUninit::write_slice(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = [0; 16];
    ///
    /// MaybeUninit::write_slice(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // KALIGTASAN: kami ay may lamang makopya ang lahat ng mga elemento ng len sa ekstrang kapasidad
    /// // ang unang mga elemento ng src.len() ng mga vector ay may bisa na ngayon.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice_cloned`]: MaybeUninit::write_slice_cloned
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Copy,
    {
        // KALIGTASAN: &[T] at&[MaybeUninit<T>] Ay may parehong layout
        let uninit_src: &[MaybeUninit<T>] = unsafe { super::transmute(src) };

        this.copy_from_slice(uninit_src);

        // KALIGTASAN: Ang mga wastong sangkap ay may lamang ay kinopya sa `this` kaya ito ay initalized
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }

    /// I-clone ang mga elemento mula sa `src` hanggang `this`, na nagbabalik ng isang nababagabag na sanggunian sa na-initalisadong nilalaman ng `this`.
    /// Ang anumang mga nakapaloob na elemento ay hindi mahuhulog.
    ///
    /// Kung `T` nagpapatupad `Copy`, gamitin [`write_slice`]
    ///
    /// Ito ay katulad ng [`slice::clone_from_slice`] ngunit hindi drop ang mga umiiral na mga elemento.
    ///
    /// # Panics
    ///
    /// Function na ito ay panic kung ang dalawang hiwa ay may iba't ibang mga haba, o kung ang pagpapatupad ng `Clone` panics.
    ///
    /// Kung may isang panic, ang naka-kopya ng mga elemento ay bumaba.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit()];
    /// let src = ["wibbly".to_string(), "wobbly".to_string(), "timey".to_string(), "wimey".to_string(), "stuff".to_string()];
    ///
    /// let init = MaybeUninit::write_slice_cloned(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = ["rust", "is", "a", "pretty", "cool", "language"];
    ///
    /// MaybeUninit::write_slice_cloned(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // KALIGTASAN: lamang namin na-kopya ang lahat ng mga elemento ng len sa ekstrang kapasidad
    /// // ang unang mga elemento ng src.len() ng mga vector ay may bisa na ngayon.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice`]: MaybeUninit::write_slice
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice_cloned<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Clone,
    {
        // hindi tulad copy_from_slice ito ay hindi tumawag clone_from_slice sa slice ito ay dahil `MaybeUninit<T: Clone>` ay hindi ipatupad ang I-clone.
        //

        struct Guard<'a, T> {
            slice: &'a mut [MaybeUninit<T>],
            initialized: usize,
        }

        impl<'a, T> Drop for Guard<'a, T> {
            fn drop(&mut self) {
                let initialized_part = &mut self.slice[..self.initialized];
                // KALIGTASAN: ang hilaw na hiwa na ito ay maglalaman lamang ng mga inisyal na bagay
                // na ang dahilan kung bakit, ito ay pinapayagan upang i-drop ito.
                unsafe {
                    crate::ptr::drop_in_place(MaybeUninit::slice_assume_init_mut(initialized_part));
                }
            }
        }

        assert_eq!(this.len(), src.len(), "destination and source slices have different lengths");
        // NOTE: Kailangan nating malinaw na hatiin ang mga ito sa parehong haba
        // para sa mga hangganan ng paglagay ng tsek na elided, at ang optimizer ay bubuo ng memcpy para sa simpleng mga kaso (halimbawa T= u8).
        //
        let len = this.len();
        let src = &src[..len];

        // kailangan ng bantay b/c panic maaaring mangyari sa panahon ng isang clone
        let mut guard = Guard { slice: this, initialized: 0 };

        for i in 0..len {
            guard.slice[i].write(src[i].clone());
            guard.initialized += 1;
        }

        super::forget(guard);

        // KALIGTASAN: Ang mga wastong elemento ay naisulat lamang sa `this` kaya't ito ay na-initalisa
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }
}