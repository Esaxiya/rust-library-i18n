use crate::ops::{Deref, DerefMut};
use crate::ptr;

/// Ang isang pambalot upang pigilan ang tagatala mula sa awtomatikong pagtawag sa 'T`'s destructor.
/// wrapper na ito ay 0-gastos.
///
/// `ManuallyDrop<T>` napapailalim sa parehong pag-optimize ng layout bilang `T`.
/// Bilang kinahinatnan, ito ay may *walang epekto* sa pagpapalagay na ang compiler ay gumagawa tungkol sa mga nilalaman nito.
/// Halimbawa, Sinisimulan ang isang `ManuallyDrop<&mut T>` na may [`mem::zeroed`] ay hindi natukoy na pag-uugali.
/// Kung kailangan mong hawakan ang hindi na-unalisadong data, gumamit ng [`MaybeUninit<T>`] sa halip.
///
/// Tandaan na ang pag-access sa ang halaga sa loob ng isang `ManuallyDrop<T>` ay ligtas.
/// Nangangahulugan ito na ang isang `ManuallyDrop<T>` na ang nilalaman ay nahulog ay hindi dapat mailantad sa pamamagitan ng isang ligtas na API.
/// Correspondingly, `ManuallyDrop::drop` ay hindi ligtas.
///
/// # `ManuallyDrop` at drop order.
///
/// Rust ay may isang maayos na natukoy na [drop order] ng mga halaga.
/// Upang matiyak na ang mga patlang o lokal ay nahulog sa isang tukoy na pagkakasunud-sunod, muling ayusin ang mga deklarasyon na ang implicit na pagkakasunud-sunod ng drop ay tama.
///
/// Ito ay posible na gamitin `ManuallyDrop` upang kontrolin ang drop-sunod, ngunit ito ay nangangailangan ng hindi ligtas na code at ito ay mahirap na gawin nang tama sa presensya ng unwinding.
///
///
/// Halimbawa, kung nais mong tiyakin na ang isang partikular na patlang ay bumaba pagkatapos ng iba, gawin itong huling field ng isang struct:
///
/// ```
/// struct Context;
///
/// struct Widget {
///     children: Vec<Widget>,
///     // `context` ay mahuhulog pagkatapos ng `children`.
///     // Rust tinitiyak na ang mga patlang ay bumaba sa pagkakasunud-sunod ng deklarasyon.
///     context: Context,
/// }
/// ```
///
/// [drop order]: https://doc.rust-lang.org/reference/destructors.html
/// [`mem::zeroed`]: crate::mem::zeroed
/// [`MaybeUninit<T>`]: crate::mem::MaybeUninit
///
///
///
///
///
#[stable(feature = "manually_drop", since = "1.20.0")]
#[lang = "manually_drop"]
#[derive(Copy, Clone, Debug, Default, PartialEq, Eq, PartialOrd, Ord, Hash)]
#[repr(transparent)]
pub struct ManuallyDrop<T: ?Sized> {
    value: T,
}

impl<T> ManuallyDrop<T> {
    /// I-wrap ang halaga na mano-manong ay bumaba.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let mut x = ManuallyDrop::new(String::from("Hello World!"));
    /// x.truncate(5); // Maaari mo pa ring ligtas na gumana sa halaga
    /// assert_eq!(*x, "Hello");
    /// // Ngunit `Drop` ay hindi tatakbo dito
    /// ```
    #[must_use = "if you don't need the wrapper, you can use `mem::forget` instead"]
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(value: T) -> ManuallyDrop<T> {
        ManuallyDrop { value }
    }

    /// Extracts ang halaga mula sa `ManuallyDrop` container.
    ///
    /// Ito ay nagpapahintulot sa ang halaga na bumaba muli.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let x = ManuallyDrop::new(Box::new(()));
    /// let _: Box<()> = ManuallyDrop::into_inner(x); // Ibinagsak nito ang `Box`.
    /// ```
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn into_inner(slot: ManuallyDrop<T>) -> T {
        slot.value
    }

    /// Kinukuha ang halaga mula sa lalagyan na `ManuallyDrop<T>`.
    ///
    /// Ang pamamaraan na ito ay lalo na inilaan para sa paglipat out halaga sa drop.
    /// Sa halip ng paggamit [`ManuallyDrop::drop`] upang mano-manong i-drop ang halaga, maaari mong gamitin ang paraan upang gawin ang mga halaga at gamitin ito gayunpaman gusto mo.
    ///
    /// Kailanman posible, mas mabuti na gamitin ang [`into_inner`][`ManuallyDrop::into_inner`] sa halip, na pumipigil sa pagdoble ng nilalaman ng `ManuallyDrop<T>`.
    ///
    ///
    /// # Safety
    ///
    /// Ang pagpapaandar na ito ay semantikal na naglilipat ng nilalaman na nilalaman nang hindi pinipigilan ang karagdagang paggamit, naiwan ang estado ng lalagyan na ito na hindi nagbabago.
    /// Ito ay iyong responsibilidad upang matiyak na ito `ManuallyDrop` ay hindi na ginagamit muli.
    ///
    ///
    ///
    #[must_use = "if you don't need the value, you can use `ManuallyDrop::drop` instead"]
    #[stable(feature = "manually_drop_take", since = "1.42.0")]
    #[inline]
    pub unsafe fn take(slot: &mut ManuallyDrop<T>) -> T {
        // KALIGTASAN: nagbabasa kami mula sa isang sanggunian, na ginagarantiyahan
        // upang maging wasto para bumabasa.
        unsafe { ptr::read(&slot.value) }
    }
}

impl<T: ?Sized> ManuallyDrop<T> {
    /// Mano-manong ibinaba ang nilalaman na nilalaman.Ito ay eksaktong katumbas ng pagtawag [`ptr::drop_in_place`] na may isang pointer sa nakapaloob na halaga.
    /// Gaya ng nabanggit, maliban kung ang nakapaloob halaga ay isang naka-pack na struct, ang destructor ay tatawaging in-lugar nang hindi nililipat ang halaga, at sa gayon ay maaaring gamitin upang ligtas na i-drop [pinned] data.
    ///
    /// Kung mayroon kang pagmamay-ari ng halaga, maaari mong gamitin ang [`ManuallyDrop::into_inner`] sa halip.
    ///
    /// # Safety
    ///
    /// Ang function na ito ay tumatakbo sa destructor ng nakapaloob na halaga.
    /// Maliban sa mga pagbabago na ginawa sa pamamagitan ng destructor mismo, ang memorya ay kaliwa hindi magbabago, at iba pa hanggang sa ang tagatala ay nababahala pa rin humahawak ng isang bit-pattern na kung saan ay may-bisa para sa uri `T`.
    ///
    ///
    /// Gayunpaman, ito "zombie" halaga ay hindi dapat malantad sa safe code, at ang function na ito ay hindi dapat na tinatawag na higit sa isang beses.
    /// Upang gamitin ang halaga matapos itong ma-bumaba, o i-drop ang halaga ng maraming beses, ay maaaring maging sanhi Di natukoy Pag-uugali (depende sa kung ano ang ginagawa `drop`).
    /// Ito ay normal na pumigil sa pamamagitan ng uri ng sistema, ngunit ang mga gumagamit ng `ManuallyDrop` dapat panindigan mga garantiya na walang tulong mula sa compiler.
    ///
    /// [pinned]: crate::pin
    ///
    ///
    ///
    ///
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[inline]
    pub unsafe fn drop(slot: &mut ManuallyDrop<T>) {
        // KALIGTASAN: namin ay bumababa ang halaga ng nakatutok sa pamamagitan ng isang nagbabago reference
        // na kung saan ay garantisadong upang maging wasto para writes.
        // Ito ay hanggang sa ang mga tumatawag upang matiyak na `slot` ay hindi bumaba muli.
        unsafe { ptr::drop_in_place(&mut slot.value) }
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> Deref for ManuallyDrop<T> {
    type Target = T;
    #[inline(always)]
    fn deref(&self) -> &T {
        &self.value
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> DerefMut for ManuallyDrop<T> {
    #[inline(always)]
    fn deref_mut(&mut self) -> &mut T {
        &mut self.value
    }
}