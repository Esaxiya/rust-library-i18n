//! Basic function para sa pagharap sa memorya.
//!
//! Naglalaman ang modyul na ito ng mga pagpapaandar para sa pagtatanong sa laki at pagkakahanay ng mga uri, pagsisimula at pagmamanipula ng memorya.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::clone;
use crate::cmp;
use crate::fmt;
use crate::hash;
use crate::intrinsics;
use crate::marker::{Copy, DiscriminantKind, Sized};
use crate::ptr;

mod manually_drop;
#[stable(feature = "manually_drop", since = "1.20.0")]
pub use manually_drop::ManuallyDrop;

mod maybe_uninit;
#[stable(feature = "maybe_uninit", since = "1.36.0")]
pub use maybe_uninit::MaybeUninit;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::transmute;

/// Dadalhin pagmamay-ari at "forgets" tungkol sa halaga **nang hindi nagpapatakbo ng kanyang destructor**.
///
/// Anumang mga mapagkukunan na pinamamahalaan ng halaga, tulad ng memorya ng magbunton o isang hawakan ng file, ay mananatili magpakailanman sa isang hindi maabot na estado.Gayunpaman, hindi ito ginagarantiyahan na ang mga pahiwatig sa memorya na ito ay mananatiling wasto.
///
/// * Kung nais mong mahayag memory, tingnan [`Box::leak`].
/// * Kung nais mong makakuha ng isang raw pointer sa memory, tingnan [`Box::into_raw`].
/// * Kung nais mong itapon ang halaga ng maayos, pagtakbo nito destructor, tingnan [`mem::drop`].
///
/// # Safety
///
/// `forget` ay hindi minarkahan bilang `unsafe`, dahil kaligtasan ng garantiya ni Rust huwag isama ang isang garantiya na destructors ay palaging tumakbo.
/// Halimbawa, ang isang programa ay maaaring lumikha ng isang reference cycle gamit [`Rc`][rc], o tumawag [`process::exit`][exit] upang lumabas nang hindi tumatakbo destructors.
/// Kaya, na nagpapahintulot sa `mem::forget` mula safe code ay hindi sa panimula baguhin ang kaligtasan ng mga garantiya ni Rust.
///
/// Sa gayon, tagas resources tulad ng memorya o I/O bagay ay karaniwang hindi kanais-nais.
/// Ang pangangailangan ay nagmumula sa ilang mga dalubhasang kaso ng paggamit para sa FFI o hindi ligtas na code, ngunit kahit na, ang [`ManuallyDrop`] ay karaniwang ginustong.
///
/// Pinapayagan ang pagkalimot sa isang halaga, ang anumang `unsafe` code na iyong isinulat ay dapat payagan para sa posibilidad na ito.Hindi mo maibabalik ang isang halaga at asahan na kinakailangang patakbuhin ng tumatawag ang destructor ng halaga.
///
/// [rc]: ../../std/rc/struct.Rc.html
/// [exit]: ../../std/process/fn.exit.html
///
/// # Examples
///
/// Ang ligtas na paggamit ng canonical ng `mem::forget` ay upang maiwasan ang destructor ng isang halaga na ipinatupad ng `Drop` trait.Halimbawa, ito ay mahayag isang `File`, ibig sabihin,
/// ibalik sa puwang na kinunan ng variable ngunit hindi kailanman isara ang kalakip na sistema ng mapagkukunan:
///
/// ```no_run
/// use std::mem;
/// use std::fs::File;
///
/// let file = File::open("foo.txt").unwrap();
/// mem::forget(file);
/// ```
///
/// Kapaki-pakinabang ito kapag ang pagmamay-ari ng pinagbabatayan na mapagkukunan ay dating inilipat sa code sa labas ng Rust, halimbawa sa pamamagitan ng paglilipat ng deskriptor ng hilaw na file sa C code.
///
/// # Relasyon sa `ManuallyDrop`
///
/// Habang ang `mem::forget` ay maaari ding magamit upang ilipat ang pagmamay-ari ng *memorya*, ang paggawa nito ay madaling kapitan ng error.
/// [`ManuallyDrop`] sa halip ay dapat gamitin.Isaalang-alang, halimbawa, ang code na ito:
///
/// ```
/// use std::mem;
///
/// let mut v = vec![65, 122];
/// // Bumuo ng isang `String` gamit ang mga nilalaman ng `v`
/// let s = unsafe { String::from_raw_parts(v.as_mut_ptr(), v.len(), v.capacity()) };
/// // mahayag `v` dahil ang memory ngayon ay pinamamahalaan ng `s`
/// mem::forget(v);  // ERROR, v ay hindi wasto at hindi dapat ipasa sa isang function
/// assert_eq!(s, "Az");
/// // `s` ay implicitly na bumagsak at ang memorya nito ay umaksyon.
/// ```
///
/// Mayroong dalawang mga isyu sa halimbawa sa itaas:
///
/// * Kung higit code ay idinagdag sa pagitan ng pagtatayo ng `String` at ang invocation ng `mem::forget()`, isang panic loob ito maging sanhi ng isang double libre dahil ang parehong memory ng paghawak ng parehong `v` at `s`.
/// * Matapos tawagan ang `v.as_mut_ptr()` at ilipat ang pagmamay-ari ng data sa `s`, ang halaga ng `v` ay hindi wasto.
/// Kahit na kapag ang halaga ay lamang inilipat sa `mem::forget` (na hindi magsisiyasat ito), ang ilang mga uri ay may mahigpit na mga kinakailangan sa kanilang mga halaga na gumawa ng mga ito di-wastong kapag nakalawit o hindi na pag-aari.
/// Ang paggamit ng mga hindi wastong halaga sa anumang paraan, kabilang ang pagpasa ng mga ito sa o pagbabalik ng mga ito mula sa mga pagpapaandar, ay bumubuo ng hindi natukoy na pag-uugali at maaaring masira ang mga pagpapalagay na ginawa ng tagatala.
///
/// Ang paglipat sa `ManuallyDrop` ay iniiwasan ang parehong mga isyu:
///
/// ```
/// use std::mem::ManuallyDrop;
///
/// let v = vec![65, 122];
/// // Bago namin i-disassemble ang `v` sa mga hilaw na bahagi nito, tiyaking hindi ito nahuhulog!
/////
/// let mut v = ManuallyDrop::new(v);
/// // Ngayon kalasin `v`.Ang mga operasyong ito ay hindi panic, kaya doon ay hindi maaaring maging isang tumagas.
/// let (ptr, len, cap) = (v.as_mut_ptr(), v.len(), v.capacity());
/// // Panghuli, bumuo ng isang `String`.
/// let s = unsafe { String::from_raw_parts(ptr, len, cap) };
/// assert_eq!(s, "Az");
/// // `s` ay implicitly na bumagsak at ang memorya nito ay umaksyon.
/// ```
///
/// `ManuallyDrop` matatag na pinipigilan ang dobleng-free dahil hindi namin pinagana ang destructor ng `v` bago gumawa ng iba pa.
/// `mem::forget()` Hindi pinapayagan ito sapagkat natupok nito ang argumento, pinipilit kaming tawagan lamang ito pagkatapos ng pagkuha ng anumang kailangan namin mula sa `v`.
/// Kahit na ang isang panic ay ipinakilala sa pagitan ng pagtatayo ng `ManuallyDrop` at pagbuo ng string (na hindi maaaring mangyari sa code tulad ng ipinakita), magreresulta ito sa isang leak at hindi isang doble na libre.
/// Sa madaling salita, ang `ManuallyDrop` ay nagkakamali sa gilid ng pagtulo sa halip na magkamali sa gilid ng (dobleng-) pagbagsak.
///
/// Gayundin, pinipigilan kami ng `ManuallyDrop` mula sa pagkakaroon ng "touch" `v` pagkatapos ilipat ang pagmamay-ari sa `s`-ang huling hakbang ng pakikipag-ugnay sa `v` upang itapon ito nang hindi pinapatakbo ang destructor nito ay ganap na naiwasan.
///
///
/// [`Box`]: ../../std/boxed/struct.Box.html
/// [`Box::leak`]: ../../std/boxed/struct.Box.html#method.leak
/// [`Box::into_raw`]: ../../std/boxed/struct.Box.html#method.into_raw
/// [`mem::drop`]: drop
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[rustc_const_stable(feature = "const_forget", since = "1.46.0")]
#[stable(feature = "rust1", since = "1.0.0")]
pub const fn forget<T>(t: T) {
    let _ = ManuallyDrop::new(t);
}

/// Tulad ng [`forget`], ngunit tumatanggap din ng hindi naka-sukat na mga halaga.
///
/// Ang pagpapaandar na ito ay isang shim lamang na inilaan upang alisin kapag ang tampok na `unsized_locals` ay nagpapatatag.
///
#[inline]
#[unstable(feature = "forget_unsized", issue = "none")]
pub fn forget_unsized<T: ?Sized>(t: T) {
    intrinsics::forget(t)
}

/// Ibinabalik ang laki ng isang uri sa mga byte.
///
/// Mas partikular, ito ang offset sa mga byte sa pagitan ng sunud-sunod na mga elemento sa isang array na may uri ng item kasama ang alignment padding.
///
/// Kaya, para sa anumang uri `T` at haba `n`, ang `[T; n]` ay may sukat na `n * size_of::<T>()`.
///
/// Sa pangkalahatan, ang laki ng isang uri ay hindi matatag sa mga pinagsama-sama, ngunit ang mga tiyak na uri tulad ng mga primitibo ay.
///
/// Ang sumusunod na talahanayan ay nagbibigay ng laki para sa mga primitibo.
///
/// Uri |sukat ng: :\<Type>()
/// ---- | ---------------
/// () |0 bool |1 u8 |1 u16 |2 u32 |4 u64 |8 u128 |16 i8 |1 i16 |2 i32 |4 i64 |8 i128 |16 f32 |4 f64 |8 char |4
///
/// Bukod dito, ang `usize` at `isize` ay may parehong laki.
///
/// Ang mga uri na `*const T`, `&T`, `Box<T>`, `Option<&T>`, at `Option<Box<T>>` lahat ay may parehong laki.
/// Kung ang `T` ay Laki, lahat ng mga uri ay may parehong sukat sa `usize`.
///
/// Ang pagbabago ng isang pointer ay hindi binabago ang laki nito.Tulad ng naturan, ang `&T` at `&mut T` ay may parehong laki.
/// Gayundin para sa `*const T` at `* mut T`.
///
/// # Laki ng mga item na `#[repr(C)]`
///
/// Ang representasyon ng `C` para sa mga item ay may tinukoy na layout.
/// Sa layout na ito, ang laki ng mga item ay matatag din hangga't ang lahat ng mga patlang ay may isang matatag na sukat.
///
/// ## Laki ng Mga Istraktura
///
/// Para sa `structs`, ang laki ay natutukoy ng sumusunod na algorithm.
///
/// Para sa bawat larangan sa istrukturang iniutos ng order ng deklarasyon:
///
/// 1. Idagdag ang laki ng patlang.
/// 2. Bilugan ang kasalukuyang laki sa pinakamalapit na maramihang ng susunod na patlang na [alignment].
///
/// Panghuli, bilugan ang laki ng struct sa pinakamalapit na maramihang ng [alignment] nito.
/// Ang pagkakahanay ng istraktura ay karaniwang ang pinakamalaking pagkakahanay ng lahat ng mga patlang nito;mababago ito sa paggamit ng `repr(align(N))`.
///
/// Hindi tulad ng `C`, ang mga sukat na zero na sukat ay hindi bilugan hanggang sa isang byte sa laki.
///
/// ## Laki ng mga Enum
///
/// Ang mga enum na walang dalang data maliban sa diskriminante ay may parehong sukat ng mga enum C sa platform na pinagsama-sama nila.
///
/// ## Laki ng Mga Unyon
///
/// Ang laki ng isang unyon ay ang laki ng pinakamalaking larangan.
///
/// Hindi tulad ng `C`, ang mga zero na laki ng unyon ay hindi bilugan hanggang sa isang byte na laki.
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// // Ang ilang mga primitives
/// assert_eq!(4, mem::size_of::<i32>());
/// assert_eq!(8, mem::size_of::<f64>());
/// assert_eq!(0, mem::size_of::<()>());
///
/// // Ang ilang mga array
/// assert_eq!(8, mem::size_of::<[i32; 2]>());
/// assert_eq!(12, mem::size_of::<[i32; 3]>());
/// assert_eq!(0, mem::size_of::<[i32; 0]>());
///
///
/// // Pagkakapantay-pantay ng laki ng pointer
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<*const i32>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Box<i32>>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Option<&i32>>());
/// assert_eq!(mem::size_of::<Box<i32>>(), mem::size_of::<Option<Box<i32>>>());
/// ```
///
/// Gumagamit ng `#[repr(C)]`.
///
/// ```
/// use std::mem;
///
/// #[repr(C)]
/// struct FieldStruct {
///     first: u8,
///     second: u16,
///     third: u8
/// }
///
/// // Ang laki ng unang field ay 1, kaya magdagdag ng 1 sa laki.Ang laki ay 1.
/// // Ang pagkakahanay ng pangalawang patlang ay 2, kaya magdagdag ng 1 sa laki para sa padding.Ang laki ay 2.
/// // Ang laki ng pangalawang patlang ay 2, kaya magdagdag ng 2 sa laki.Sukat ay 4.
/// // Ang pagkakahanay ng pangatlong patlang ay 1, kaya magdagdag ng 0 sa laki para sa padding.Sukat ay 4.
/// // Ang laki ng ikatlong field ay 1, kaya magdagdag ng 1 sa laki.Sukat ay 5.
/// // Sa wakas, ang pagkakahanay ng struct ay 2 (dahil ang pinakamalaking pag-align sa gitna ng kanyang mga patlang ay 2), kaya magdagdag ng 1 sa laki ng padding.
/// // Ang laki ay 6.
/// assert_eq!(6, mem::size_of::<FieldStruct>());
///
/// #[repr(C)]
/// struct TupleStruct(u8, u16, u8);
///
/// // Tuple structs sundin ang parehong mga panuntunan.
/// assert_eq!(6, mem::size_of::<TupleStruct>());
///
/// // Tandaan na ang muling pagsasaayos ng mga patlang ay maaaring magpababa sa laki.
/// // Maaari naming alisin ang parehong mga padding byte sa pamamagitan ng paglalagay ng `third` bago ang `second`.
/// #[repr(C)]
/// struct FieldStructOptimized {
///     first: u8,
///     third: u8,
///     second: u16
/// }
///
/// assert_eq!(4, mem::size_of::<FieldStructOptimized>());
///
/// // Union laki ay ang laki ng pinakamalaking field.
/// #[repr(C)]
/// union ExampleUnion {
///     smaller: u8,
///     larger: u16
/// }
///
/// assert_eq!(2, mem::size_of::<ExampleUnion>());
/// ```
///
/// [alignment]: align_of
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_size_of", since = "1.32.0")]
pub const fn size_of<T>() -> usize {
    intrinsics::size_of::<T>()
}

/// Ibinabalik ang laki ng itinuro na halaga sa mga byte.
///
/// Karaniwan itong kapareho ng `size_of::<T>()`.
/// Gayunpaman, kapag ang `T` * ay walang statically-kilala na sukat, hal, isang slice [`[T]`][slice] o isang [trait object], kung gayon ang `size_of_val` ay maaaring magamit upang makuha ang kilalang kilalang kilalang-kilalang.
///
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, mem::size_of_val(y));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
pub const fn size_of_val<T: ?Sized>(val: &T) -> usize {
    // KALIGTASAN: Ang `val` ay isang sanggunian, kaya't ito ay isang wastong hilaw na pointer
    unsafe { intrinsics::size_of_val(val) }
}

/// Ibinabalik ang laki ng itinuro na halaga sa mga byte.
///
/// Karaniwan itong kapareho ng `size_of::<T>()`.Gayunpaman, kapag ang `T` * ay walang statically-kilala na sukat, hal, isang slice [`[T]`][slice] o isang [trait object], kung gayon ang `size_of_val_raw` ay maaaring magamit upang makuha ang kilalang kilalang kilalang-kilalang.
///
/// # Safety
///
/// Ang pagpapaandar na ito ay ligtas lamang na tawagan kung ang mga sumusunod na kundisyon ay hawakan:
///
/// - Kung ang `T` ay `Sized`, ang pagpapaandar na ito ay laging ligtas na tawagan.
/// - Kung ang unsized tail ng `T` ay:
///     - isang [slice], pagkatapos ang haba ng hiwa ng hiwa ay dapat na isang gawing integer, at ang laki ng *buong halaga*(pabagu-bago na haba ng buntot + statically laki ng unlapi) ay dapat magkasya sa `isize`.
///     - isang [trait object], kung gayon ang bahagi ng talahanayan ng pointer ay dapat na tumuturo sa isang wastong vtable na nakuha ng isang hindi pinipilit na pamimilit, at ang laki ng *buong halaga*(pabagu-bago na haba ng buntot + statically laki ng unlapi) ay dapat magkasya sa `isize`.
///
///     - isang (unstable) [extern type], kung gayon ang pagpapaandar na ito ay laging ligtas na tawagan, ngunit maaaring ang panic o kung hindi man ay ibalik ang maling halaga, dahil hindi alam ang layout ng uri ng extern.
///     Ito ang parehong pag-uugali tulad ng [`size_of_val`] sa isang sanggunian sa isang uri na may isang buntot na uri ng buntot.
///     - kung hindi man, pinapayagan itong tawagan ang pagpapaandar na ito.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, unsafe { mem::size_of_val_raw(y) });
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_size_of_val_raw", issue = "46571")]
pub const unsafe fn size_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // KALIGTASAN: ang tumatawag ay dapat magbigay ng isang wastong hilaw na pointer
    unsafe { intrinsics::size_of_val(val) }
}

/// Ibinabalik ang [ABI]-hiniling minimum na pagkakahanay ng isang uri.
///
/// Ang bawat sanggunian sa isang halaga ng uri ng `T` ay dapat na isang maramihang ng bilang na ito.
///
/// Ito ang ginagamit na pagkakahanay para sa mga larangan ng istruktura.Maaari itong mas maliit kaysa sa ginustong pagkakahanay.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of::<i32>());
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of` instead", since = "1.2.0")]
pub fn min_align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// Ibinabalik ang [ABI]-required na minimum na pagkakahanay ng uri ng halagang tinuturo ng `val`.
///
/// Ang bawat sanggunian sa isang halaga ng uri ng `T` ay dapat na isang maramihang ng bilang na ito.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of_val` instead", since = "1.2.0")]
pub fn min_align_of_val<T: ?Sized>(val: &T) -> usize {
    // KALIGTASAN: ang val ay isang sanggunian, kaya't ito ay isang wastong hilaw na pointer
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Ibinabalik ang [ABI]-hiniling minimum na pagkakahanay ng isang uri.
///
/// Ang bawat sanggunian sa isang halaga ng uri ng `T` ay dapat na isang maramihang ng bilang na ito.
///
/// Ito ang ginagamit na pagkakahanay para sa mga larangan ng istruktura.Maaari itong mas maliit kaysa sa ginustong pagkakahanay.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of::<i32>());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_align_of", since = "1.32.0")]
pub const fn align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// Ibinabalik ang [ABI]-required na minimum na pagkakahanay ng uri ng halagang tinuturo ng `val`.
///
/// Ang bawat sanggunian sa isang halaga ng uri ng `T` ay dapat na isang maramihang ng bilang na ito.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
#[allow(deprecated)]
pub const fn align_of_val<T: ?Sized>(val: &T) -> usize {
    // KALIGTASAN: ang val ay isang sanggunian, kaya't ito ay isang wastong hilaw na pointer
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Ibinabalik ang [ABI]-required na minimum na pagkakahanay ng uri ng halagang tinuturo ng `val`.
///
/// Ang bawat sanggunian sa isang halaga ng uri ng `T` ay dapat na isang maramihang ng bilang na ito.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Safety
///
/// Ang pagpapaandar na ito ay ligtas lamang na tawagan kung ang mga sumusunod na kundisyon ay hawakan:
///
/// - Kung ang `T` ay `Sized`, ang pagpapaandar na ito ay laging ligtas na tawagan.
/// - Kung ang unsized tail ng `T` ay:
///     - isang [slice], pagkatapos ang haba ng hiwa ng hiwa ay dapat na isang gawing integer, at ang laki ng *buong halaga*(pabagu-bago na haba ng buntot + statically laki ng unlapi) ay dapat magkasya sa `isize`.
///     - isang [trait object], kung gayon ang bahagi ng talahanayan ng pointer ay dapat na tumuturo sa isang wastong vtable na nakuha ng isang hindi pinipilit na pamimilit, at ang laki ng *buong halaga*(pabagu-bago na haba ng buntot + statically laki ng unlapi) ay dapat magkasya sa `isize`.
///
///     - isang (unstable) [extern type], kung gayon ang pagpapaandar na ito ay laging ligtas na tawagan, ngunit maaaring ang panic o kung hindi man ay ibalik ang maling halaga, dahil hindi alam ang layout ng uri ng extern.
///     Ito ang parehong pag-uugali tulad ng [`align_of_val`] sa isang sanggunian sa isang uri na may isang buntot na uri ng buntot.
///     - kung hindi man, pinapayagan itong tawagan ang pagpapaandar na ito.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, unsafe { mem::align_of_val_raw(&5i32) });
/// ```
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_align_of_val_raw", issue = "46571")]
pub const unsafe fn align_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // KALIGTASAN: ang tumatawag ay dapat magbigay ng isang wastong hilaw na pointer
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Ibinabalik ang `true` kung ang pagbagsak ng mga halaga ng uri ng `T` ay mahalaga.
///
/// Ito ay pulos isang pahiwatig ng pag-optimize, at maaaring ipatupad nang konserbatibo:
/// maaari itong ibalik ang `true` para sa mga uri na hindi talaga kailangang ibagsak.
/// Tulad ng palaging nagbabalik `true` ay isang wastong pagpapatupad ng pagpapaandar na ito.Gayunpaman kung ang pagpapaandar na ito ay talagang nagbabalik ng `false`, maaari mong tiyakin na ang pagbagsak ng `T` ay walang epekto.
///
/// Ang mga pagpapatupad ng mababang antas ng mga bagay tulad ng mga koleksyon, na kailangang manu-manong ihulog ang kanilang data, dapat gamitin ang pagpapaandar na ito upang maiwasan ang hindi kinakailangang pagsubok na i-drop ang lahat ng kanilang nilalaman kapag nawasak ito.
///
/// Maaaring hindi ito makagawa ng pagkakaiba sa mga pagbuo ng paglabas (kung saan ang isang loop na walang mga side-effects ay madaling makita at matanggal), ngunit madalas na isang malaking panalo para sa mga debug build.
///
/// Tandaan na ginaganap na ng [`drop_in_place`] ang tsek na ito, kaya't kung ang iyong workload ay maaaring mabawasan sa ilang maliit na bilang ng mga tawag sa [`drop_in_place`], ang paggamit nito ay hindi kinakailangan.
/// Sa partikular na tandaan na maaari mong [`drop_in_place`] isang hiwa, at iyon ay gagawa ng isang solong pag-check sa mga pangangailangan para sa lahat ng mga halaga.
///
/// Mga uri tulad ng Vec samakatuwid `drop_in_place(&mut self[..])` lamang nang hindi gumagamit ng `needs_drop` nang malinaw.
/// Ang mga uri tulad ng [`HashMap`], sa kabilang banda, ay kailangang mag-drop ng mga halaga nang paisa-isa at dapat gamitin ang API na ito.
///
/// [`drop_in_place`]: crate::ptr::drop_in_place
/// [`HashMap`]: ../../std/collections/struct.HashMap.html
///
/// # Examples
///
/// Narito ang isang halimbawa kung paano maaaring magamit ng isang koleksyon ang `needs_drop`:
///
/// ```
/// use std::{mem, ptr};
///
/// pub struct MyCollection<T> {
/// #   data: [T; 1],
///     /* ... */
/// }
/// # impl<T> MyCollection<T> {
/// #   fn iter_mut(&mut self) -> &mut [T] { &mut self.data }
/// #   fn free_buffer(&mut self) {}
/// # }
///
/// impl<T> Drop for MyCollection<T> {
///     fn drop(&mut self) {
///         unsafe {
///             // ihulog ang data
///             if mem::needs_drop::<T>() {
///                 for x in self.iter_mut() {
///                     ptr::drop_in_place(x);
///                 }
///             }
///             self.free_buffer();
///         }
///     }
/// }
/// ```
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "needs_drop", since = "1.21.0")]
#[rustc_const_stable(feature = "const_needs_drop", since = "1.36.0")]
#[rustc_diagnostic_item = "needs_drop"]
pub const fn needs_drop<T>() -> bool {
    intrinsics::needs_drop::<T>()
}

/// Ibinabalik ang halaga ng uri na `T` na kinakatawan ng all-zero byte-pattern.
///
/// Nangangahulugan ito na, halimbawa, ang padding byte sa `(u8, u16)` ay hindi kinakailangang zero.
///
/// Walang garantiya na ang isang all-zero byte-pattern ay kumakatawan sa isang wastong halaga ng ilang uri `T`.
/// Halimbawa, ang all-zero byte-pattern ay hindi isang wastong halaga para sa mga uri ng sanggunian (`&T`, `&mut T`) at mga function point.
/// Ang paggamit ng `zeroed` sa mga nasabing uri ay nagdudulot ng agarang [undefined behavior][ub] dahil ang [the Rust compiler assumes][inv] na palaging may wastong halaga sa isang variable na isinasaalang-alang nito na pinasimulan.
///
///
/// Ito ay may parehong epekto tulad ng [`MaybeUninit::zeroed().assume_init()`][zeroed].
/// Kapaki-pakinabang ito para sa FFI minsan, ngunit sa pangkalahatan ay dapat iwasan.
///
/// [zeroed]: MaybeUninit::zeroed
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [inv]: MaybeUninit#initialization-invariant
///
/// # Examples
///
/// Tamang paggamit ng pagpapaandar na ito: pagsisimula ng isang integer na may zero.
///
/// ```
/// use std::mem;
///
/// let x: i32 = unsafe { mem::zeroed() };
/// assert_eq!(0, x);
/// ```
///
/// *Maling* paggamit ng pagpapaandar na ito: pagsisimula ng isang sanggunian na may zero.
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem;
///
/// let _x: &i32 = unsafe { mem::zeroed() }; // Hindi natukoy na pag-uugali!
/// let _y: fn() = unsafe { mem::zeroed() }; // At muli!
/// ```
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_zeroed"]
pub unsafe fn zeroed<T>() -> T {
    // KALIGTASAN: dapat magagarantiya ng tumatawag na ang isang all-zero na halaga ay may bisa para sa `T`.
    unsafe {
        intrinsics::assert_zero_valid::<T>();
        MaybeUninit::zeroed().assume_init()
    }
}

/// Ang mga normal na tseke ng memorya ng paunang memorya ng Bypass Rust sa pamamagitan ng pagpapanggap na gumawa ng isang halaga ng uri na `T`, habang wala naman ginagawa.
///
/// **Hindi na ginagamit ang pagpapaandar na ito.** Sa halip ay gumamit ng [`MaybeUninit<T>`].
///
/// Ang dahilan para sa pag-aalis ng katawan ay ang pagpapaandar na karaniwang hindi maaaring magamit nang tama: mayroon itong parehong epekto tulad ng [`MaybeUninit::uninit().assume_init()`][uninit].
///
/// Tulad ng ipinaliwanag ng [`assume_init` documentation][assume_init], ang [the Rust compiler assumes][inv] na ang mga halagang ito ay wastong naisimula.
/// Bilang kinahinatnan, pagtawag hal
/// `mem::uninitialized::<bool>()` nagiging sanhi ng agarang hindi natukoy na pag-uugali para sa pagbabalik ng isang `bool` na hindi tiyak na alinman sa `true` o `false`.
/// Mas masahol, tunay na uninitialized memory tulad ng kung ano ang naibalik dito ay espesyal sa alam ng tagatala na wala itong isang nakapirming halaga.
/// Ginagawa nitong hindi natukoy na pag-uugali na magkaroon ng uninitialized na data sa isang variable kahit na ang variable na iyon ay may isang uri ng integer.
/// (Pansinin na ang mga patakaran sa paligid ng uninitialized integers ay hindi tinatapos pa, pero hanggang sa ang mga ito ay, ito ay ipinapayong upang maiwasan ang mga ito.)
///
/// [uninit]: MaybeUninit::uninit
/// [assume_init]: MaybeUninit::assume_init
/// [inv]: MaybeUninit#initialization-invariant
///
///
///
///
///
#[inline(always)]
#[rustc_deprecated(since = "1.39.0", reason = "use `mem::MaybeUninit` instead")]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_uninitialized"]
pub unsafe fn uninitialized<T>() -> T {
    // KALIGTASAN: dapat magagarantiya ng tumatawag na may bisa ang isang unitialized na halaga para sa `T`.
    unsafe {
        intrinsics::assert_uninit_valid::<T>();
        MaybeUninit::uninit().assume_init()
    }
}

/// Ipinagpapalit ang mga halaga sa dalawang lokasyon na maaaring baguhin, nang hindi deinitialize ang alinman sa isa.
///
/// * Kung nais mong magpalit ng isang default o halaga ng dummy, tingnan ang [`take`].
/// * Kung nais mong magpalit ng isang lumipas na halaga, ibabalik ang dating halaga, tingnan ang [`replace`].
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// let mut x = 5;
/// let mut y = 42;
///
/// mem::swap(&mut x, &mut y);
///
/// assert_eq!(42, x);
/// assert_eq!(5, y);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn swap<T>(x: &mut T, y: &mut T) {
    // KALIGTASAN: ang mga hilaw na payo ay nilikha mula sa ligtas na nababagabag na mga sanggunian na nagbibigay-kasiyahan sa lahat ng
    // mga hadlang sa `ptr::swap_nonoverlapping_one`
    unsafe {
        ptr::swap_nonoverlapping_one(x, y);
    }
}

/// Pinapalitan ang `dest` ng default na halaga ng `T`, na binabalik ang dating halaga ng `dest`.
///
/// * Kung nais mong palitan ang mga halaga ng dalawang variable, tingnan ang [`swap`].
/// * Kung nais mong palitan ng isang naipasa na halaga sa halip na ang default na halaga, tingnan ang [`replace`].
///
/// # Examples
///
/// Isang simpleng halimbawa:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::take(&mut v);
/// assert_eq!(vec![1, 2], old_v);
/// assert!(v.is_empty());
/// ```
///
/// `take` Pinapayagan ang pagkuha ng pagmamay-ari ng isang istrakturang larangan sa pamamagitan ng pagpapalit nito ng isang halagang "empty".
/// Nang walang `take` maaari kang magkaroon ng mga isyu tulad nito:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let buf = self.buf;
///         self.buf = Vec::new();
///         buf
///     }
/// }
/// ```
///
/// Tandaan na ang `T` ay hindi kinakailangang magpatupad ng [`Clone`], kaya't hindi nito ma-clone at mai-reset ang `self.buf`.
/// Ngunit ang `take` ay maaaring magamit upang alisin ang pagkakaugnay sa orihinal na halaga ng `self.buf` mula sa `self`, na pinapayagan itong ibalik:
///
///
/// ```
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         mem::take(&mut self.buf)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf.len(), 2);
///
/// assert_eq!(buffer.get_and_reset(), vec![0, 1]);
/// assert_eq!(buffer.buf.len(), 0);
/// ```
#[inline]
#[stable(feature = "mem_take", since = "1.40.0")]
pub fn take<T: Default>(dest: &mut T) -> T {
    replace(dest, T::default())
}

/// Inililipat ang `src` sa isinangguni na `dest`, na ibinabalik ang dating halaga ng `dest`.
///
/// Ni ang halaga ay hindi nahulog.
///
/// * Kung nais mong palitan ang mga halaga ng dalawang variable, tingnan ang [`swap`].
/// * Kung nais mong palitan ng isang default na halaga, tingnan ang [`take`].
///
/// # Examples
///
/// Isang simpleng halimbawa:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::replace(&mut v, vec![3, 4, 5]);
/// assert_eq!(vec![1, 2], old_v);
/// assert_eq!(vec![3, 4, 5], v);
/// ```
///
/// `replace` Pinapayagan ang pagkonsumo ng isang istrakturang larangan sa pamamagitan ng pagpapalit nito ng ibang halaga.
/// Nang walang `replace` maaari kang magkaroon ng mga isyu tulad nito:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let t = self.buf[i];
///         self.buf[i] = v;
///         t
///     }
/// }
/// ```
///
/// Tandaan na ang `T` ay hindi kinakailangang magpatupad ng [`Clone`], kaya't hindi namin ma-clone ang `self.buf[i]` upang maiwasan ang paglipat.
/// Ngunit ang `replace` ay maaaring magamit upang alisin ang pagkakaugnay sa orihinal na halaga sa index na iyon mula sa `self`, na pinapayagan itong ibalik:
///
///
/// ```
/// # #![allow(dead_code)]
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         mem::replace(&mut self.buf[i], v)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf[0], 0);
///
/// assert_eq!(buffer.replace_index(0, 2), 0);
/// assert_eq!(buffer.buf[0], 2);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[must_use = "if you don't need the old value, you can just assign the new value directly"]
pub fn replace<T>(dest: &mut T, src: T) -> T {
    // KALIGTASAN: Nabasa namin mula sa `dest` ngunit direktang isinusulat ang `src` dito pagkatapos,
    // tulad na ang dating halaga ay hindi na doble.
    // Walang nahulog at wala dito ay maaaring panic.
    unsafe {
        let result = ptr::read(dest);
        ptr::write(dest, src);
        result
    }
}

/// Nagtatapon ng isang halaga.
///
/// Ginagawa ito sa pamamagitan ng pagtawag sa pagpapatupad ng argumento ng [`Drop`][drop].
///
/// Mabisa itong walang ginagawa para sa mga uri na nagpapatupad ng `Copy`, hal
/// integers.
/// Ang mga nasabing halaga ay kinopya at ang _then_ ay inilipat sa pagpapaandar, kaya't nagpatuloy ang halaga pagkatapos ng tawag na ito sa pag-andar.
///
///
/// Ang pagpapaandar na ito ay hindi mahika;literal itong tinukoy bilang
///
/// ```
/// pub fn drop<T>(_x: T) { }
/// ```
///
/// Dahil ang `_x` ay inilipat sa pagpapaandar, awtomatiko itong bumaba bago bumalik ang pagpapaandar.
///
/// [drop]: Drop
///
/// # Examples
///
/// Pangunahing paggamit:
///
/// ```
/// let v = vec![1, 2, 3];
///
/// drop(v); // tahasan drop ang vector
/// ```
///
/// Dahil ang [`RefCell`] ay nagpapatupad ng mga panuntunan sa paghiram sa runtime, maaaring palabasin ng `drop` ang isang [`RefCell`] loan:
///
/// ```
/// use std::cell::RefCell;
///
/// let x = RefCell::new(1);
///
/// let mut mutable_borrow = x.borrow_mut();
/// *mutable_borrow = 1;
///
/// drop(mutable_borrow); // talikuran ang mutable humiram na ito sa slot
///
/// let borrow = x.borrow();
/// println!("{}", *borrow);
/// ```
///
/// Ang mga integer at iba pang mga uri ng pagpapatupad ng [`Copy`] ay hindi naapektuhan ng `drop`.
///
/// ```
/// #[derive(Copy, Clone)]
/// struct Foo(u8);
///
/// let x = 1;
/// let y = Foo(2);
/// drop(x); // isang kopya ng `x` ay inilipat at bumaba
/// drop(y); // isang kopya ng `y` ay inilipat at bumaba
///
/// println!("x: {}, y: {}", x, y.0); // magagamit pa rin
/// ```
///
/// [`RefCell`]: crate::cell::RefCell
///
#[doc(alias = "delete")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn drop<T>(_x: T) {}

/// Nabibigyan ng kahulugan ang `src` bilang pagkakaroon ng uri na `&U`, at pagkatapos ay binabasa ang `src` nang hindi nililipat ang nilalaman na nilalaman.
///
/// Ang pagpapaandar na ito ay hindi ligtas na ipalagay na ang pointer `src` ay wasto para sa [`size_of::<U>`][size_of] bytes sa pamamagitan ng paglilipat ng `&T` sa `&U` at pagkatapos ay basahin ang `&U` (maliban na ito ay ginagawa sa isang paraan na tama kahit na ang `&U` ay gumagawa ng mas mahigpit na mga kinakailangan sa pagkakahanay kaysa sa `&T`).
/// Lilikha rin ito ng hindi ligtas na kopya ng nilalaman na nilalaman sa halip na lumipat sa `src`.
///
/// Hindi ito isang error sa compile-time kung ang `T` at `U` ay may magkakaibang sukat, ngunit lubos na hinihikayat na gamitin lamang ang pagpapaandar na ito kung saan ang `T` at `U` ay may parehong laki.Ang pagpapaandar na ito ay nagpapalitaw ng [undefined behavior][ub] kung ang `U` ay mas malaki kaysa sa `T`.
///
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// #[repr(packed)]
/// struct Foo {
///     bar: u8,
/// }
///
/// let foo_array = [10u8];
///
/// unsafe {
///     // Kopyahin ang data mula 'foo_array' at ituring ito bilang 'Foo'
///     let mut foo_struct: Foo = mem::transmute_copy(&foo_array);
///     assert_eq!(foo_struct.bar, 10);
///
///     // Baguhin ang mga kinopya data
///     foo_struct.bar = 20;
///     assert_eq!(foo_struct.bar, 20);
/// }
///
/// // Ang mga nilalaman ng 'foo_array' ay hindi dapat ay nagbago
/// assert_eq!(foo_array, [10]);
/// ```
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_transmute_copy", issue = "83165")]
pub const unsafe fn transmute_copy<T, U>(src: &T) -> U {
    // Kung ang U ay may mas mataas na kinakailangan sa pagkakahanay, ang src ay maaaring hindi akma na nakahanay.
    if align_of::<U>() > align_of::<T>() {
        // KALIGTASAN: Ang `src` ay isang sanggunian na ginagarantiyahan na wasto para sa mga nagbabasa.
        // Kailangang garantiya ng tumatawag na ligtas ang aktwal na transmutation.
        unsafe { ptr::read_unaligned(src as *const T as *const U) }
    } else {
        // KALIGTASAN: Ang `src` ay isang sanggunian na ginagarantiyahan na wasto para sa mga nagbabasa.
        // Namin suriin lamang na ang `src as *const U` ay maayos na nakahanay.
        // Kailangang garantiya ng tumatawag na ligtas ang aktwal na transmutation.
        unsafe { ptr::read(src as *const T as *const U) }
    }
}

/// Uri ng opaque na kumakatawan sa diskriminante ng isang enum.
///
/// Tingnan ang pagpapaandar ng [`discriminant`] sa modyul na ito para sa karagdagang impormasyon.
#[stable(feature = "discriminant_value", since = "1.21.0")]
pub struct Discriminant<T>(<T as DiscriminantKind>::Discriminant);

// N.B. Ang mga pagpapatupad na trait na ito ay hindi maaaring makuha dahil hindi namin nais ang anumang mga hangganan sa T.

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> Copy for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> clone::Clone for Discriminant<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::PartialEq for Discriminant<T> {
    fn eq(&self, rhs: &Self) -> bool {
        self.0 == rhs.0
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::Eq for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> hash::Hash for Discriminant<T> {
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.0.hash(state);
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> fmt::Debug for Discriminant<T> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_tuple("Discriminant").field(&self.0).finish()
    }
}

/// Nagbabalik ng isang halaga na natatanging kinikilala ang variant ng enum sa `v`.
///
/// Kung ang `T` ay hindi isang enum, ang pagtawag sa pagpapaandar na ito ay hindi magreresulta sa hindi natukoy na pag-uugali, ngunit ang halaga ng pagbabalik ay hindi natukoy.
///
///
/// # Stability
///
/// Ang diskriminante ng isang variant ng enum ay maaaring magbago kung magbago ang kahulugan ng enum.
/// Ang isang diskriminante ng ilang variant ay hindi magbabago sa pagitan ng mga compilation na may parehong tagatala.
///
/// # Examples
///
/// Maaari itong magamit upang ihambing ang mga enum na nagdadala ng data, habang hindi pinapansin ang aktwal na data:
///
/// ```
/// use std::mem;
///
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::discriminant(&Foo::A("bar")), mem::discriminant(&Foo::A("baz")));
/// assert_eq!(mem::discriminant(&Foo::B(1)), mem::discriminant(&Foo::B(2)));
/// assert_ne!(mem::discriminant(&Foo::B(3)), mem::discriminant(&Foo::C(3)));
/// ```
///
#[stable(feature = "discriminant_value", since = "1.21.0")]
#[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
pub const fn discriminant<T>(v: &T) -> Discriminant<T> {
    Discriminant(intrinsics::discriminant_value(v))
}

/// Ibinabalik ang bilang ng mga variant sa uri ng enum na `T`.
///
/// Kung ang `T` ay hindi isang enum, ang pagtawag sa pagpapaandar na ito ay hindi magreresulta sa hindi natukoy na pag-uugali, ngunit ang halaga ng pagbabalik ay hindi natukoy.
/// Parehas, kung ang `T` ay isang enum na may higit na mga variant kaysa sa `usize::MAX` ang halaga ng pagbabalik ay hindi natukoy.
/// Ang mga variant na hindi naninirahan ay mabibilang.
///
/// # Examples
///
/// ```
/// # #![feature(never_type)]
/// # #![feature(variant_count)]
///
/// use std::mem;
///
/// enum Void {}
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::variant_count::<Void>(), 0);
/// assert_eq!(mem::variant_count::<Foo>(), 3);
///
/// assert_eq!(mem::variant_count::<Option<!>>(), 2);
/// assert_eq!(mem::variant_count::<Result<!, !>>(), 2);
/// ```
#[inline(always)]
#[unstable(feature = "variant_count", issue = "73662")]
#[rustc_const_unstable(feature = "variant_count", issue = "73662")]
pub const fn variant_count<T>() -> usize {
    intrinsics::variant_count::<T>()
}