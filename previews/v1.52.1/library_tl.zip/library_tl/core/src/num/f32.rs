//! Patuloy na tumutukoy sa `f32` solong katumpakan na lumulutang na uri ng uri.
//!
//! *[See also the `f32` primitive type][f32].*
//!
//! Ang mga makabuluhang numero sa matematika ay ibinibigay sa `consts` sub-module.
//!
//! Para sa mga pare-pareho na tinukoy nang direkta sa modyul na ito (bilang naiiba mula sa mga tinukoy sa `consts` sub-module), dapat gamitin ng bagong code ang mga nauugnay na pare-pareho na tinukoy nang direkta sa uri ng `f32`.
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::convert::FloatToInt;
#[cfg(not(test))]
use crate::intrinsics;
use crate::mem;
use crate::num::FpCategory;

/// Ang radix o base ng panloob na representasyon ng `f32`.
/// Sa halip ay gumamit ng [`f32::RADIX`].
///
/// # Examples
///
/// ```rust
/// // wala nang paraan
/// # #[allow(deprecated, deprecated_in_future)]
/// let r = std::f32::RADIX;
///
/// // inilaan na paraan
/// let r = f32::RADIX;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `RADIX` associated constant on `f32`")]
pub const RADIX: u32 = f32::RADIX;

/// Bilang ng mga makabuluhang digit sa base 2.
/// Sa halip ay gumamit ng [`f32::MANTISSA_DIGITS`].
///
/// # Examples
///
/// ```rust
/// // wala nang paraan
/// # #[allow(deprecated, deprecated_in_future)]
/// let d = std::f32::MANTISSA_DIGITS;
///
/// // inilaan na paraan
/// let d = f32::MANTISSA_DIGITS;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MANTISSA_DIGITS` associated constant on `f32`"
)]
pub const MANTISSA_DIGITS: u32 = f32::MANTISSA_DIGITS;

/// Tinatayang bilang ng mga makabuluhang digit sa base 10.
/// Sa halip ay gumamit ng [`f32::DIGITS`].
///
/// # Examples
///
/// ```rust
/// // wala nang paraan
/// # #[allow(deprecated, deprecated_in_future)]
/// let d = std::f32::DIGITS;
///
/// // inilaan na paraan
/// let d = f32::DIGITS;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `DIGITS` associated constant on `f32`")]
pub const DIGITS: u32 = f32::DIGITS;

/// [Machine epsilon] halaga para sa `f32`.
/// Sa halip ay gumamit ng [`f32::EPSILON`].
///
/// Ito ang pagkakaiba sa pagitan ng `1.0` at ng susunod na mas malaking kinatawan na numero.
///
/// [Machine epsilon]: https://en.wikipedia.org/wiki/Machine_epsilon
///
/// # Examples
///
/// ```rust
/// // wala nang paraan
/// # #[allow(deprecated, deprecated_in_future)]
/// let e = std::f32::EPSILON;
///
/// // inilaan na paraan
/// let e = f32::EPSILON;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `EPSILON` associated constant on `f32`"
)]
pub const EPSILON: f32 = f32::EPSILON;

/// Pinakamaliit na may halaga na `f32`.
/// Sa halip ay gumamit ng [`f32::MIN`].
///
/// # Examples
///
/// ```rust
/// // wala nang paraan
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN;
///
/// // inilaan na paraan
/// let min = f32::MIN;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `MIN` associated constant on `f32`")]
pub const MIN: f32 = f32::MIN;

/// Pinakamaliit na positibong normal na halagang `f32`.
/// Sa halip ay gumamit ng [`f32::MIN_POSITIVE`].
///
/// # Examples
///
/// ```rust
/// // wala nang paraan
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN_POSITIVE;
///
/// // inilaan na paraan
/// let min = f32::MIN_POSITIVE;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_POSITIVE` associated constant on `f32`"
)]
pub const MIN_POSITIVE: f32 = f32::MIN_POSITIVE;

/// Pinakamalaking may hangganan na `f32` na halaga.
/// Sa halip ay gumamit ng [`f32::MAX`].
///
/// # Examples
///
/// ```rust
/// // wala nang paraan
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f32::MAX;
///
/// // inilaan na paraan
/// let max = f32::MAX;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `MAX` associated constant on `f32`")]
pub const MAX: f32 = f32::MAX;

/// Isang mas malaki kaysa sa minimum na posibleng normal na kapangyarihan ng 2 exponent.
/// Sa halip ay gumamit ng [`f32::MIN_EXP`].
///
/// # Examples
///
/// ```rust
/// // wala nang paraan
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN_EXP;
///
/// // inilaan na paraan
/// let min = f32::MIN_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_EXP` associated constant on `f32`"
)]
pub const MIN_EXP: i32 = f32::MIN_EXP;

/// Maximum na posibleng kapangyarihan ng 2 exponent.
/// Sa halip ay gumamit ng [`f32::MAX_EXP`].
///
/// # Examples
///
/// ```rust
/// // wala nang paraan
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f32::MAX_EXP;
///
/// // inilaan na paraan
/// let max = f32::MAX_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MAX_EXP` associated constant on `f32`"
)]
pub const MAX_EXP: i32 = f32::MAX_EXP;

/// Minimum na posibleng normal na lakas ng 10 exponent.
/// Sa halip ay gumamit ng [`f32::MIN_10_EXP`].
///
/// # Examples
///
/// ```rust
/// // wala nang paraan
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN_10_EXP;
///
/// // inilaan na paraan
/// let min = f32::MIN_10_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_10_EXP` associated constant on `f32`"
)]
pub const MIN_10_EXP: i32 = f32::MIN_10_EXP;

/// Maximum na posibleng kapangyarihan ng 10 exponent.
/// Sa halip ay gumamit ng [`f32::MAX_10_EXP`].
///
/// # Examples
///
/// ```rust
/// // wala nang paraan
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f32::MAX_10_EXP;
///
/// // inilaan na paraan
/// let max = f32::MAX_10_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MAX_10_EXP` associated constant on `f32`"
)]
pub const MAX_10_EXP: i32 = f32::MAX_10_EXP;

/// Hindi isang Numero (NaN).
/// Sa halip ay gumamit ng [`f32::NAN`].
///
/// # Examples
///
/// ```rust
/// // wala nang paraan
/// # #[allow(deprecated, deprecated_in_future)]
/// let nan = std::f32::NAN;
///
/// // inilaan na paraan
/// let nan = f32::NAN;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `NAN` associated constant on `f32`")]
pub const NAN: f32 = f32::NAN;

/// Infinity (∞).
/// Sa halip ay gumamit ng [`f32::INFINITY`].
///
/// # Examples
///
/// ```rust
/// // wala nang paraan
/// # #[allow(deprecated, deprecated_in_future)]
/// let inf = std::f32::INFINITY;
///
/// // inilaan na paraan
/// let inf = f32::INFINITY;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `INFINITY` associated constant on `f32`"
)]
pub const INFINITY: f32 = f32::INFINITY;

/// Negatibong infinity (−∞).
/// Sa halip ay gumamit ng [`f32::NEG_INFINITY`].
///
/// # Examples
///
/// ```rust
/// // wala nang paraan
/// # #[allow(deprecated, deprecated_in_future)]
/// let ninf = std::f32::NEG_INFINITY;
///
/// // inilaan na paraan
/// let ninf = f32::NEG_INFINITY;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `NEG_INFINITY` associated constant on `f32`"
)]
pub const NEG_INFINITY: f32 = f32::NEG_INFINITY;

/// Pangunahing batayan ng matematika.
#[stable(feature = "rust1", since = "1.0.0")]
pub mod consts {
    // FIXME: palitan ng mga matematika na pare-pareho mula sa cmath.

    /// Patuloy na (π) ng Archimedes
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const PI: f32 = 3.14159265358979323846264338327950288_f32;

    /// Ang buong bilog na pare-pareho (τ)
    ///
    /// Katumbas ng 2π.
    #[stable(feature = "tau_constant", since = "1.47.0")]
    pub const TAU: f32 = 6.28318530717958647692528676655900577_f32;

    /// π/2
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_2: f32 = 1.57079632679489661923132169163975144_f32;

    /// π/3
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_3: f32 = 1.04719755119659774615421446109316763_f32;

    /// π/4
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_4: f32 = 0.785398163397448309615660845819875721_f32;

    /// π/6
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_6: f32 = 0.52359877559829887307710723054658381_f32;

    /// π/8
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_8: f32 = 0.39269908169872415480783042290993786_f32;

    /// 1/π
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_1_PI: f32 = 0.318309886183790671537767526745028724_f32;

    /// 2/π
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_2_PI: f32 = 0.636619772367581343075535053490057448_f32;

    /// 2/sqrt(π)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_2_SQRT_PI: f32 = 1.12837916709551257389615890312154517_f32;

    /// sqrt(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const SQRT_2: f32 = 1.41421356237309504880168872420969808_f32;

    /// 1/sqrt(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_1_SQRT_2: f32 = 0.707106781186547524400844362104849039_f32;

    /// Ang numero ni Euler (e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const E: f32 = 2.71828182845904523536028747135266250_f32;

    /// log<sub>2</sub>(e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LOG2_E: f32 = 1.44269504088896340735992468100189214_f32;

    /// log<sub>2</sub>(10)
    #[stable(feature = "extra_log_consts", since = "1.43.0")]
    pub const LOG2_10: f32 = 3.32192809488736234787031942948939018_f32;

    /// log<sub>10</sub>(e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LOG10_E: f32 = 0.434294481903251827651128918916605082_f32;

    /// log<sub>10</sub>(2)
    #[stable(feature = "extra_log_consts", since = "1.43.0")]
    pub const LOG10_2: f32 = 0.301029995663981195213738894724493027_f32;

    /// ln(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LN_2: f32 = 0.693147180559945309417232121458176568_f32;

    /// ln(10)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LN_10: f32 = 2.30258509299404568401799145468436421_f32;
}

#[lang = "f32"]
#[cfg(not(test))]
impl f32 {
    /// Ang radix o base ng panloob na representasyon ng `f32`.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const RADIX: u32 = 2;

    /// Bilang ng mga makabuluhang digit sa base 2.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MANTISSA_DIGITS: u32 = 24;

    /// Tinatayang bilang ng mga makabuluhang digit sa base 10.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const DIGITS: u32 = 6;

    /// [Machine epsilon] halaga para sa `f32`.
    ///
    /// Ito ang pagkakaiba sa pagitan ng `1.0` at ng susunod na mas malaking kinatawan na numero.
    ///
    /// [Machine epsilon]: https://en.wikipedia.org/wiki/Machine_epsilon
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const EPSILON: f32 = 1.19209290e-07_f32;

    /// Pinakamaliit na may halaga na `f32`.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN: f32 = -3.40282347e+38_f32;
    /// Pinakamaliit na positibong normal na halagang `f32`.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_POSITIVE: f32 = 1.17549435e-38_f32;
    /// Pinakamalaking may hangganan na `f32` na halaga.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX: f32 = 3.40282347e+38_f32;

    /// Isang mas malaki kaysa sa minimum na posibleng normal na kapangyarihan ng 2 exponent.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_EXP: i32 = -125;
    /// Maximum na posibleng kapangyarihan ng 2 exponent.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX_EXP: i32 = 128;

    /// Minimum na posibleng normal na lakas ng 10 exponent.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_10_EXP: i32 = -37;
    /// Maximum na posibleng kapangyarihan ng 10 exponent.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX_10_EXP: i32 = 38;

    /// Hindi isang Numero (NaN).
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const NAN: f32 = 0.0_f32 / 0.0_f32;
    /// Infinity (∞).
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const INFINITY: f32 = 1.0_f32 / 0.0_f32;
    /// Negatibong infinity (−∞).
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const NEG_INFINITY: f32 = -1.0_f32 / 0.0_f32;

    /// Ibinabalik ang `true` kung ang halagang ito ay `NaN`.
    ///
    /// ```
    /// let nan = f32::NAN;
    /// let f = 7.0_f32;
    ///
    /// assert!(nan.is_nan());
    /// assert!(!f.is_nan());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_nan(self) -> bool {
        self != self
    }

    // FIXME(#50145): Ang `abs` ay hindi magagamit sa publiko sa libcore dahil sa mga alalahanin tungkol sa kakayahang dalhin, kaya ang pagpapatupad na ito ay para sa pribadong paggamit sa loob.
    //
    //
    #[inline]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    const fn abs_private(self) -> f32 {
        f32::from_bits(self.to_bits() & 0x7fff_ffff)
    }

    /// Ibinabalik ang `true` kung ang halagang ito ay positibong infinity o negatibong infinity, at `false` kung hindi man.
    ///
    ///
    /// ```
    /// let f = 7.0f32;
    /// let inf = f32::INFINITY;
    /// let neg_inf = f32::NEG_INFINITY;
    /// let nan = f32::NAN;
    ///
    /// assert!(!f.is_infinite());
    /// assert!(!nan.is_infinite());
    ///
    /// assert!(inf.is_infinite());
    /// assert!(neg_inf.is_infinite());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_infinite(self) -> bool {
        self.abs_private() == Self::INFINITY
    }

    /// Ibinabalik ang `true` kung ang numerong ito ay alinman sa walang katapusan o `NaN`.
    ///
    /// ```
    /// let f = 7.0f32;
    /// let inf = f32::INFINITY;
    /// let neg_inf = f32::NEG_INFINITY;
    /// let nan = f32::NAN;
    ///
    /// assert!(f.is_finite());
    ///
    /// assert!(!nan.is_finite());
    /// assert!(!inf.is_finite());
    /// assert!(!neg_inf.is_finite());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_finite(self) -> bool {
        // Hindi na kailangang hawakan nang magkahiwalay ang NaN: kung ang sarili ay NaN, ang paghahambing ay hindi totoo, eksakto tulad ng ninanais.
        //
        self.abs_private() < Self::INFINITY
    }

    /// Ibinabalik ang `true` kung ang numero ay [subnormal].
    ///
    /// ```
    /// #![feature(is_subnormal)]
    /// let min = f32::MIN_POSITIVE; // 1.17549435e-38f32
    /// let max = f32::MAX;
    /// let lower_than_min = 1.0e-40_f32;
    /// let zero = 0.0_f32;
    ///
    /// assert!(!min.is_subnormal());
    /// assert!(!max.is_subnormal());
    ///
    /// assert!(!zero.is_subnormal());
    /// assert!(!f32::NAN.is_subnormal());
    /// assert!(!f32::INFINITY.is_subnormal());
    /// // Ang mga halaga sa pagitan ng `0` at `min` ay Subnormal.
    /// assert!(lower_than_min.is_subnormal());
    /// ```
    /// [subnormal]: https://en.wikipedia.org/wiki/Denormal_number
    #[unstable(feature = "is_subnormal", issue = "79288")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_subnormal(self) -> bool {
        matches!(self.classify(), FpCategory::Subnormal)
    }

    /// Ibinabalik ang `true` kung ang numero ay alinman sa zero, infinite, [subnormal], o `NaN`.
    ///
    ///
    /// ```
    /// let min = f32::MIN_POSITIVE; // 1.17549435e-38f32
    /// let max = f32::MAX;
    /// let lower_than_min = 1.0e-40_f32;
    /// let zero = 0.0_f32;
    ///
    /// assert!(min.is_normal());
    /// assert!(max.is_normal());
    ///
    /// assert!(!zero.is_normal());
    /// assert!(!f32::NAN.is_normal());
    /// assert!(!f32::INFINITY.is_normal());
    /// // Ang mga halaga sa pagitan ng `0` at `min` ay Subnormal.
    /// assert!(!lower_than_min.is_normal());
    /// ```
    /// [subnormal]: https://en.wikipedia.org/wiki/Denormal_number
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_normal(self) -> bool {
        matches!(self.classify(), FpCategory::Normal)
    }

    /// Ibinabalik ang kategorya ng lumulutang na punto ng numero.
    /// Kung ang isang pag-aari lamang ay susubukan, sa pangkalahatan ay mas mabilis na gamitin sa halip ang tukoy na panaguri.
    ///
    ///
    /// ```
    /// use std::num::FpCategory;
    ///
    /// let num = 12.4_f32;
    /// let inf = f32::INFINITY;
    ///
    /// assert_eq!(num.classify(), FpCategory::Normal);
    /// assert_eq!(inf.classify(), FpCategory::Infinite);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    pub const fn classify(self) -> FpCategory {
        const EXP_MASK: u32 = 0x7f800000;
        const MAN_MASK: u32 = 0x007fffff;

        let bits = self.to_bits();
        match (bits & MAN_MASK, bits & EXP_MASK) {
            (0, 0) => FpCategory::Zero,
            (_, 0) => FpCategory::Subnormal,
            (0, EXP_MASK) => FpCategory::Infinite,
            (_, EXP_MASK) => FpCategory::Nan,
            _ => FpCategory::Normal,
        }
    }

    /// Ibinabalik ang `true` kung ang `self` ay may positibong pag-sign, kasama ang `+0.0`, `NaN`s na may positibong pag-sign bit at positibong infinity.
    ///
    ///
    /// ```
    /// let f = 7.0_f32;
    /// let g = -7.0_f32;
    ///
    /// assert!(f.is_sign_positive());
    /// assert!(!g.is_sign_positive());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_sign_positive(self) -> bool {
        !self.is_sign_negative()
    }

    /// Ibinabalik ang `true` kung ang `self` ay may negatibong pag-sign, kasama ang `-0.0`, `NaN`s na may negatibong sign bit at negatibong infinity.
    ///
    ///
    /// ```
    /// let f = 7.0f32;
    /// let g = -7.0f32;
    ///
    /// assert!(!f.is_sign_negative());
    /// assert!(g.is_sign_negative());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_sign_negative(self) -> bool {
        // Sinasabi ng IEEE754: Ang isSignMinus(x) ay totoo kung at kung x ay mayroong negatibong pag-sign.
        // Nalalapat ang isSignMinus sa mga zero at NaN din.
        self.to_bits() & 0x8000_0000 != 0
    }

    /// Kinukuha ang katumbas na (inverse) ng isang numero, `1/x`.
    ///
    /// ```
    /// let x = 2.0_f32;
    /// let abs_difference = (x.recip() - (1.0 / x)).abs();
    ///
    /// assert!(abs_difference <= f32::EPSILON);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn recip(self) -> f32 {
        1.0 / self
    }

    /// Nag-convert ng mga radiano sa degree.
    ///
    /// ```
    /// let angle = std::f32::consts::PI;
    ///
    /// let abs_difference = (angle.to_degrees() - 180.0).abs();
    ///
    /// assert!(abs_difference <= f32::EPSILON);
    /// ```
    #[stable(feature = "f32_deg_rad_conversions", since = "1.7.0")]
    #[inline]
    pub fn to_degrees(self) -> f32 {
        // Gumamit ng isang pare-pareho para sa mas mahusay na katumpakan.
        const PIS_IN_180: f32 = 57.2957795130823208767981548141051703_f32;
        self * PIS_IN_180
    }

    /// Nagpapalit ng degree sa mga radiano.
    ///
    /// ```
    /// let angle = 180.0f32;
    ///
    /// let abs_difference = (angle.to_radians() - std::f32::consts::PI).abs();
    ///
    /// assert!(abs_difference <= f32::EPSILON);
    /// ```
    #[stable(feature = "f32_deg_rad_conversions", since = "1.7.0")]
    #[inline]
    pub fn to_radians(self) -> f32 {
        let value: f32 = consts::PI;
        self * (value / 180.0f32)
    }

    /// Ibinabalik ang maximum ng dalawang numero.
    ///
    /// ```
    /// let x = 1.0f32;
    /// let y = 2.0f32;
    ///
    /// assert_eq!(x.max(y), y);
    /// ```
    ///
    /// Kung ang isa sa mga argumento ay NaN, pagkatapos ang iba pang argumento ay naibalik.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn max(self, other: f32) -> f32 {
        intrinsics::maxnumf32(self, other)
    }

    /// Ibinabalik ang minimum ng dalawang numero.
    ///
    /// ```
    /// let x = 1.0f32;
    /// let y = 2.0f32;
    ///
    /// assert_eq!(x.min(y), x);
    /// ```
    ///
    /// Kung ang isa sa mga argumento ay NaN, pagkatapos ang iba pang argumento ay naibalik.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn min(self, other: f32) -> f32 {
        intrinsics::minnumf32(self, other)
    }

    /// Umaikot patungo sa zero at nagko-convert sa anumang primitive na uri ng integer, ipinapalagay na ang halaga ay may hangganan at umaangkop sa uri na iyon.
    ///
    ///
    /// ```
    /// let value = 4.6_f32;
    /// let rounded = unsafe { value.to_int_unchecked::<u16>() };
    /// assert_eq!(rounded, 4);
    ///
    /// let value = -128.9_f32;
    /// let rounded = unsafe { value.to_int_unchecked::<i8>() };
    /// assert_eq!(rounded, i8::MIN);
    /// ```
    ///
    /// # Safety
    ///
    /// Ang halaga ay dapat:
    ///
    /// * Hindi maging `NaN`
    /// * Hindi maging walang hanggan
    /// * Maging kinatawan sa uri ng pagbabalik `Int`, pagkatapos maputol ang praksyonal na bahagi nito
    #[stable(feature = "float_approx_unchecked_to", since = "1.44.0")]
    #[inline]
    pub unsafe fn to_int_unchecked<Int>(self) -> Int
    where
        Self: FloatToInt<Int>,
    {
        // KALIGTASAN: ang tumatawag ay dapat na itaguyod ang kaligtasan na kontrata para sa `FloatToInt::to_int_unchecked`.
        //
        unsafe { FloatToInt::<Int>::to_int_unchecked(self) }
    }

    /// Raw transmutation sa `u32`.
    ///
    /// Kasalukuyan itong magkapareho sa `transmute::<f32, u32>(self)` sa lahat ng mga platform.
    ///
    /// Tingnan ang `from_bits` para sa ilang talakayan tungkol sa kakayahang dalhin ng operasyong ito (halos walang mga isyu).
    ///
    /// Tandaan na ang pagpapaandar na ito ay naiiba mula sa `as` casting, na sumusubok na mapanatili ang halagang *numeric*, at hindi ang bitwise na halaga.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_ne!((1f32).to_bits(), 1f32 as u32); // to_bits() ay hindi paghahagis!
    /// assert_eq!((12.5f32).to_bits(), 0x41480000);
    ///
    /// ```
    ///
    #[stable(feature = "float_bits_conv", since = "1.20.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_bits(self) -> u32 {
        // KALIGTASAN: Ang `u32` ay isang payak na dating datatype upang palagi nating mai-transmute ito
        unsafe { mem::transmute(self) }
    }

    /// Raw transmutation mula sa `u32`.
    ///
    /// Kasalukuyan itong magkapareho sa `transmute::<u32, f32>(v)` sa lahat ng mga platform.
    /// Ito ay lumabas na ito ay hindi mapaniniwalaan o kapani-paniwala portable, sa dalawang kadahilanan:
    ///
    /// * Ang Floats at Ints ay may parehong pagtatapos sa lahat ng mga sinusuportahang platform.
    /// * Ang IEEE-754 ay tiyak na tumutukoy sa kaunting layout ng floats.
    ///
    /// Gayunpaman mayroong isang caat: bago ang bersyon ng 2008 ng IEEE-754, kung paano bigyang kahulugan ang NaN signaling bit ay hindi tinukoy.
    /// Karamihan sa mga platform (kapansin-pansin ang x86 at ARM) ay pumili ng interpretasyon na huli na na-standardize noong 2008, ngunit ang ilan ay hindi (kapansin-pansin ang MIPS).
    /// Bilang isang resulta, ang lahat ng pagbibigay ng senyas ng NaNs sa MIPS ay tahimik na NaNs sa x86, at vice versa.
    ///
    /// Sa halip na subukang pangalagaan ang cross-platform na pagbibigay ng senyas, pinapaboran ng pagpapatupad na ito ang pagpapanatili ng eksaktong mga piraso.
    /// Nangangahulugan ito na ang anumang mga payload na naka-encode sa NaNs ay mapangalagaan kahit na ang resulta ng pamamaraang ito ay ipinadala sa network mula sa isang x86 machine hanggang sa MIPS.
    ///
    ///
    /// Kung ang mga resulta ng pamamaraang ito ay manipulahin lamang ng parehong arkitektura na gumawa sa kanila, kung gayon walang pag-aalala sa pagdadala.
    ///
    /// Kung ang input ay hindi NaN, kung gayon walang pag-aalala sa pagdadala.
    ///
    /// Kung wala kang pakialam tungkol sa pagbibigay ng senyas (malamang), kung gayon walang pag-aalala sa pagdadala.
    ///
    /// Tandaan na ang pagpapaandar na ito ay naiiba mula sa `as` casting, na sumusubok na mapanatili ang halagang *numeric*, at hindi ang bitwise na halaga.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = f32::from_bits(0x41480000);
    /// assert_eq!(v, 12.5);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "float_bits_conv", since = "1.20.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_bits(v: u32) -> Self {
        // KALIGTASAN: Ang `u32` ay isang payak na dating datatype upang palagi nating mai-transmute ito
        // Lumalabas na ang mga isyu sa kaligtasan sa sNaN ay labis na labis!Hooray!
        unsafe { mem::transmute(v) }
    }

    /// Ibalik ang representasyon ng memorya ng lumulutang point number na ito bilang isang byte array sa big-endian (network) byte order.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f32.to_be_bytes();
    /// assert_eq!(bytes, [0x41, 0x48, 0x00, 0x00]);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_be_bytes(self) -> [u8; 4] {
        self.to_bits().to_be_bytes()
    }

    /// Ibalik ang representasyon ng memorya ng lumulutang na numero ng puntos na ito bilang isang byte array sa maliit na endian na byte order.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f32.to_le_bytes();
    /// assert_eq!(bytes, [0x00, 0x00, 0x48, 0x41]);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_le_bytes(self) -> [u8; 4] {
        self.to_bits().to_le_bytes()
    }

    /// Ibalik ang representasyon ng memorya ng lumulutang point number na ito bilang isang byte array sa katutubong byte order.
    ///
    /// Tulad ng ginamit na katutubong endianness ng target na platform, ang portable code ay dapat gumamit ng [`to_be_bytes`] o [`to_le_bytes`], kung naaangkop, sa halip.
    ///
    ///
    /// [`to_be_bytes`]: f32::to_be_bytes
    /// [`to_le_bytes`]: f32::to_le_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f32.to_ne_bytes();
    /// assert_eq!(
    ///     bytes,
    ///     if cfg!(target_endian = "big") {
    ///         [0x41, 0x48, 0x00, 0x00]
    ///     } else {
    ///         [0x00, 0x00, 0x48, 0x41]
    ///     }
    /// );
    /// ```
    ///
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_ne_bytes(self) -> [u8; 4] {
        self.to_bits().to_ne_bytes()
    }

    /// Ibalik ang representasyon ng memorya ng lumulutang point number na ito bilang isang byte array sa katutubong byte order.
    ///
    ///
    /// [`to_ne_bytes`] ay dapat na ginustong kaysa dito hangga't maaari.
    ///
    /// [`to_ne_bytes`]: f32::to_ne_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(num_as_ne_bytes)]
    /// let num = 12.5f32;
    /// let bytes = num.as_ne_bytes();
    /// assert_eq!(
    ///     bytes,
    ///     if cfg!(target_endian = "big") {
    ///         &[0x41, 0x48, 0x00, 0x00]
    ///     } else {
    ///         &[0x00, 0x00, 0x48, 0x41]
    ///     }
    /// );
    /// ```
    #[unstable(feature = "num_as_ne_bytes", issue = "76976")]
    #[inline]
    pub fn as_ne_bytes(&self) -> &[u8; 4] {
        // KALIGTASAN: Ang `f32` ay isang payak na dating datatype upang palagi nating mai-transmute ito
        unsafe { &*(self as *const Self as *const _) }
    }

    /// Lumikha ng isang lumulutang na halaga ng point mula sa representasyon nito bilang isang byte array sa malaking endian.
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f32::from_be_bytes([0x41, 0x48, 0x00, 0x00]);
    /// assert_eq!(value, 12.5);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_be_bytes(bytes: [u8; 4]) -> Self {
        Self::from_bits(u32::from_be_bytes(bytes))
    }

    /// Lumikha ng isang lumulutang na halaga ng point mula sa representasyon nito bilang isang byte array sa maliit na endian.
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f32::from_le_bytes([0x00, 0x00, 0x48, 0x41]);
    /// assert_eq!(value, 12.5);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_le_bytes(bytes: [u8; 4]) -> Self {
        Self::from_bits(u32::from_le_bytes(bytes))
    }

    /// Lumikha ng isang lumulutang na halaga ng point mula sa representasyon nito bilang isang byte array sa katutubong endian.
    ///
    /// Tulad ng ginamit na katutubong endianness ng target na platform, malamang na nais ng portable code na gumamit ng [`from_be_bytes`] o [`from_le_bytes`], bilang naaangkop sa halip.
    ///
    ///
    /// [`from_be_bytes`]: f32::from_be_bytes
    /// [`from_le_bytes`]: f32::from_le_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f32::from_ne_bytes(if cfg!(target_endian = "big") {
    ///     [0x41, 0x48, 0x00, 0x00]
    /// } else {
    ///     [0x00, 0x00, 0x48, 0x41]
    /// });
    /// assert_eq!(value, 12.5);
    /// ```
    ///
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_ne_bytes(bytes: [u8; 4]) -> Self {
        Self::from_bits(u32::from_ne_bytes(bytes))
    }

    /// Nagbabalik ng isang pag-order sa pagitan ng sarili at iba pang mga halaga.
    /// Hindi tulad ng standard na bahagyang paghahambing sa pagitan ng mga lumulutang na numero ng point, ang paghahambing na ito ay laging gumagawa ng isang pag-order alinsunod sa kabuuang predicate ng Order na tinukoy sa IEEE 754 (2008 na rebisyon) na lumulutang na pamantayang pamantayan.
    /// Ang mga halaga ay iniutos sa sumusunod na pagkakasunud-sunod:
    /// - Negatibong tahimik NaN
    /// - Negatibong pagsenyas ng NaN
    /// - Negatibong kawalang-hanggan
    /// - Mga negatibong numero
    /// - Negatibong mga subnormal na numero
    /// - Negatibong zero
    /// - Positibong zero
    /// - Positibong subnormal na mga numero
    /// - Positive na numero
    /// - Positive infinity
    /// - Positive signaling NaN
    /// - Positibong tahimik NaN
    ///
    /// Tandaan na ang pagpapaandar na ito ay hindi palaging sumasang-ayon sa pagpapatupad ng [`PartialOrd`] at [`PartialEq`] ng `f32`.Sa partikular, itinuturing nilang negatibo at positibo ang zero bilang pantay, habang ang `total_cmp` ay hindi.
    ///
    /// # Example
    ///
    /// ```
    /// #![feature(total_cmp)]
    /// struct GoodBoy {
    ///     name: String,
    ///     weight: f32,
    /// }
    ///
    /// let mut bois = vec![
    ///     GoodBoy { name: "Pucci".to_owned(), weight: 0.1 },
    ///     GoodBoy { name: "Woofer".to_owned(), weight: 99.0 },
    ///     GoodBoy { name: "Yapper".to_owned(), weight: 10.0 },
    ///     GoodBoy { name: "Chonk".to_owned(), weight: f32::INFINITY },
    ///     GoodBoy { name: "Abs. Unit".to_owned(), weight: f32::NAN },
    ///     GoodBoy { name: "Floaty".to_owned(), weight: -5.0 },
    /// ];
    ///
    /// bois.sort_by(|a, b| a.weight.total_cmp(&b.weight));
    /// # assert!(bois.into_iter().map(|b| b.weight)
    /// #     .zip([-5.0, 0.1, 10.0, 99.0, f32::INFINITY, f32::NAN].iter())
    /// #     .all(|(a, b)| a.to_bits() == b.to_bits()))
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "total_cmp", issue = "72599")]
    #[inline]
    pub fn total_cmp(&self, other: &Self) -> crate::cmp::Ordering {
        let mut left = self.to_bits() as i32;
        let mut right = other.to_bits() as i32;

        // Sa kaso ng mga negatibo, i-flip ang lahat ng mga piraso maliban sa pag-sign upang makamit ang isang katulad na layout bilang mga kumpletong integer
        //
        // Bakit ito gumagana?Ang IEEE 754 floats ay binubuo ng tatlong mga patlang:
        // Mag-sign bit, exponent at mantissa.Ang hanay ng mga patlang na exponent at mantissa bilang isang kabuuan ay may pag-aari na ang kanilang pagkakasunud-sunod ng kaunti ay katumbas ng bilang ng laki kung saan tinukoy ang lakas.
        // Ang kalakhan ay hindi karaniwang tinukoy sa mga halagang NaN, ngunit tinutukoy ng IEEE 754 totalOrder ang mga halagang NaN din upang sundin ang pagkakasunud-sunod ng bahagyang.Ito ay humahantong sa pagkakasunud-sunod na ipinaliwanag sa komentong doc.
        // Gayunpaman, ang representasyon ng lakas ay pareho para sa mga negatibo at positibong numero-ang sign bit lamang ang magkakaiba.
        // Upang madaling maihambing ang mga float bilang naka-sign integer, kailangan nating i-flip ang exponent at mantissa bits kung sakaling magkaroon ng mga negatibong numero.
        // Mabisang binabago namin ang mga numero sa form na "two's complement".
        //
        // Upang gawin ang flipping, bumubuo kami ng isang mask at XOR laban dito.
        // Hindi namin kalkulahin ang isang "all-ones except for the sign bit" mask mula sa mga negatibong halaga na naka-sign: ang tamang pag-sign ng paglilipat ay nagpapalawak ng integer, kaya't "fill" namin ang mask na may mga sign bit, at pagkatapos ay i-convert sa unsigned upang itulak ang isa pang zero na bit.
        //
        // Sa mga positibong halaga, ang maskara ay lahat ng mga zero, kaya't ito ay isang no-op.
        //
        //
        //
        //
        //
        //
        //
        //
        //
        left ^= (((left >> 31) as u32) >> 1) as i32;
        right ^= (((right >> 31) as u32) >> 1) as i32;

        left.cmp(&right)
    }

    /// Paghigpitan ang isang halaga sa isang tiyak na agwat maliban kung ito ay NaN.
    ///
    /// Ibinabalik `max` kung `self` ay mas malaki kaysa `max`, at `min` kung `self` ay mas mababa kaysa `min`.
    /// Kung hindi man ito ay nagbabalik `self`.
    ///
    /// Tandaan na ang pagpapaandar na ito ay nagbabalik ng NaN kung ang paunang halaga ay NaN din.
    ///
    /// # Panics
    ///
    /// Ang Panics kung `min > max`, `min` ay NaN, o `max` ay NaN.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!((-3.0f32).clamp(-2.0, 1.0) == -2.0);
    /// assert!((0.0f32).clamp(-2.0, 1.0) == 0.0);
    /// assert!((2.0f32).clamp(-2.0, 1.0) == 1.0);
    /// assert!((f32::NAN).clamp(-2.0, 1.0).is_nan());
    /// ```
    ///
    #[must_use = "method returns a new number and does not mutate the original value"]
    #[stable(feature = "clamp", since = "1.50.0")]
    #[inline]
    pub fn clamp(self, min: f32, max: f32) -> f32 {
        assert!(min <= max);
        let mut x = self;
        if x < min {
            x = min;
        }
        if x > max {
            x = max;
        }
        x
    }
}