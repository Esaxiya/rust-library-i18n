//! Ang iba't ibang mga algorithm mula sa papel.

use crate::cmp::min;
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::rawfp::{self, fp_to_float, next_float, prev_float, RawFloat, Unpacked};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;

/// Bilang ng mga makahulugan na piraso sa Fp
const P: u32 = 64;

// Inimbak lamang namin ang pinakamahusay na pagtatantya para sa *lahat* na exponents, kaya't ang variable na "h" at ang mga kaugnay na kundisyon ay maaaring alisin.
// Ipinagpalit nito ang pagganap para sa isang pares na kilobytes ng puwang.

fn power_of_ten(e: i16) -> Fp {
    assert!(e >= table::MIN_E);
    let i = e - table::MIN_E;
    let sig = table::POWERS.0[i as usize];
    let exp = table::POWERS.1[i as usize];
    Fp { f: sig, e: exp }
}

// Sa karamihan ng mga arkitektura, ang mga pagpapatakbo ng lumulutang na punto ay may isang malinaw na maliit na sukat, samakatuwid ang katumpakan ng pagkalkula ay natutukoy sa bawat batayan sa bawat pagpapatakbo.
//
#[cfg(any(not(target_arch = "x86"), target_feature = "sse2"))]
mod fpu_precision {
    pub fn set_precision<T>() {}
}

// Sa x86, ang x87 FPU ay ginagamit para sa mga pagpapatakbo ng float kung ang mga extension ng SSE/SSE2 ay hindi magagamit.
// Ang x87 FPU ay nagpapatakbo ng 80 piraso ng katumpakan bilang default, na nangangahulugang ang mga pagpapatakbo ay tatakbo sa 80 bits na sanhi ng dobleng pag-ikot na nangyari kapag ang mga halaga ay kalaunan kinakatawan bilang
//
// 32/64 halaga ng bit float.Upang mapagtagumpayan ito, ang FPU control word ay maaaring maitakda upang ang mga pagkalkula ay isinasagawa sa nais na katumpakan.
//
#[cfg(all(target_arch = "x86", not(target_feature = "sse2")))]
mod fpu_precision {
    use crate::mem::size_of;

    /// Isang istrakturang ginamit upang mapanatili ang orihinal na halaga ng FPU control word, upang maibalik ito kapag nahulog ang istraktura.
    ///
    ///
    /// Ang x87 FPU ay isang 16-bits na rehistro na ang mga patlang ay ang mga sumusunod:
    ///
    /// | 12-15 | 10-11 | 8-9 | 6-7 |  5 |  4 |  3 |  2 |  1 |  0 |
    /// |------:|------:|----:|----:|---:|---:|---:|---:|---:|---:|
    /// |       | RC    | PC  |     | PM | UM | OM | ZM | DM | IM |
    ///
    /// Ang dokumentasyon para sa lahat ng mga patlang ay magagamit sa IA-32 Architectures Software Developer's Manual (Tomo 1).
    ///
    /// Ang tanging patlang na nauugnay para sa sumusunod na code ay PC, Precision Control.
    /// Tinutukoy ng patlang na ito ang katumpakan ng mga pagpapatakbo na isinagawa ng FPU.
    /// Maaari itong itakda sa:
    ///  - 0b00, solong katumpakan ibig sabihin, 32-bit
    ///  - 0b10, dobleng katumpakan ibig sabihin, 64-bit
    ///  - 0b11, doble pinalawig na katumpakan ibig sabihin, 80-bits (default na estado) Ang halaga na 0b01 ay nakalaan at hindi dapat gamitin.
    ///
    pub struct FPUControlWord(u16);

    fn set_cw(cw: u16) {
        // KALIGTASAN: ang tagubilin sa `fldcw` ay na-audit upang makapagtrabaho nang wasto
        // anumang `u16`
        unsafe {
            asm!(
                "fldcw ({})",
                in(reg) &cw,
                // FIXME: Gumagamit kami ng ATT syntax upang suportahan ang LLVM 8 at LLVM 9.
                options(att_syntax, nostack),
            )
        }
    }

    /// Itinatakda ang katumpakan na patlang ng FPU sa `T` at ibabalik ang isang `FPUControlWord`.
    pub fn set_precision<T>() -> FPUControlWord {
        let mut cw = 0_u16;

        // Kalkulahin ang halaga para sa patlang ng Precision Control na naaangkop para sa `T`.
        let cw_precision = match size_of::<T>() {
            4 => 0x0000, // 32 piraso
            8 => 0x0200, // 64 piraso
            _ => 0x0300, // default, 80 piraso
        };

        // Kunin ang orihinal na halaga ng control word upang maibalik ito sa paglaon, kapag ang istraktura ng `FPUControlWord` ay nahulog na KALIGTASAN: ang tagubilin sa `fnstcw` ay na-audit upang makapagtrabaho nang tama sa anumang `u16`
        //
        //
        //
        unsafe {
            asm!(
                "fnstcw ({})",
                in(reg) &mut cw,
                // FIXME: Gumagamit kami ng ATT syntax upang suportahan ang LLVM 8 at LLVM 9.
                options(att_syntax, nostack),
            )
        }

        // Itakda ang control word sa nais na katumpakan.
        // Nakamit ito sa pamamagitan ng masking layo ang dating katumpakan (mga bit 8 at 9, 0x300) at palitan ito ng katumpakan na bandila na nakalkula sa itaas.
        set_cw((cw & 0xFCFF) | cw_precision);

        FPUControlWord(cw)
    }

    impl Drop for FPUControlWord {
        fn drop(&mut self) {
            set_cw(self.0)
        }
    }
}

/// Ang mabilis na landas ng Bellerophon gamit ang mga integer at float na laki ng machine.
///
/// Ito ay nakuha sa isang hiwalay na pag-andar upang maaari itong subukin bago magtayo ng isang bignum.
///
pub fn fast_path<T: RawFloat>(integral: &[u8], fractional: &[u8], e: i64) -> Option<T> {
    let num_digits = integral.len() + fractional.len();
    // log_10(f64::MAX_SIG) ~ 15.95.
    // Inihambing namin ang eksaktong halaga sa MAX_SIG malapit sa pagtatapos, ito ay mabilis lamang, murang pagtanggi (at pinapalaya din ang natitirang code mula sa pag-aalala tungkol sa underflow).
    //
    if num_digits > 16 {
        return None;
    }
    if e.abs() >= T::CEIL_LOG5_OF_MAX_SIG as i64 {
        return None;
    }
    let f = num::from_str_unchecked(integral.iter().chain(fractional.iter()));
    if f > T::MAX_SIG {
        return None;
    }

    // Ang mabilis na landas na krus ay nakasalalay sa aritmetika na bilugan sa tamang bilang ng mga piraso nang walang anumang intermediate na pag-ikot.
    // Sa x86 (walang SSE o SSE2) kinakailangan nito ang katumpakan ng x87 FPU stack na mabago upang direktang umikot ito sa 64/32 bit.
    // Ang pag-andar ng `set_precision` ay nangangalaga sa pagtatakda ng katumpakan sa mga arkitektura na nangangailangan ng pagtatakda nito sa pamamagitan ng pagbabago ng pandaigdigang estado (tulad ng control word ng x87 FPU).
    //
    //
    let _cw = fpu_precision::set_precision::<T>();

    // Ang kaso e <0 ay hindi maaaring nakatiklop sa iba pang branch.
    // Ang mga negatibong kapangyarihan ay nagreresulta sa isang paulit-ulit na bahagi ng praksyonal sa binary, na bilugan, na nagiging sanhi ng mga pagkakamali ng tunay (at paminsan-minsan ay makabuluhan!) Sa huling resulta.
    //
    if e >= 0 {
        Some(T::from_int(f) * T::short_fast_pow10(e as usize))
    } else {
        Some(T::from_int(f) / T::short_fast_pow10(e.abs() as usize))
    }
}

/// Ang Algorithm Bellerophon ay walang halaga na code na nabigyang-katwiran sa pamamagitan ng di-maliit na pagsusuri sa bilang.
///
/// Inikot nito ang "f" sa isang float na may 64 bit significanceand at pinaparami ito ng pinakamahusay na approximation ng `10^e` (sa parehong format na lumulutang na point).Ito ay madalas na sapat upang makuha ang tamang resulta.
/// Gayunpaman, kapag ang resulta ay malapit sa kalahati sa pagitan ng dalawang katabing (ordinary) floats, ang compound na error sa pag-ikot mula sa pag-multiply ng dalawang approximation ay nangangahulugang ang resulta ay maaaring ma-off ng ilang mga piraso.
/// Kapag nangyari ito, inaayos ng umuulit na Algorithm R ang mga bagay.
///
/// Ang hand-wavy "close to halfway" ay ginawang tiyak sa pamamagitan ng numeric analysis sa papel.
/// Sa mga salita ni Clinger:
///
/// > Ang slop, na ipinahayag sa mga yunit ng hindi gaanong makabuluhang kaunting, ay isang inclusive bound para sa error
/// > naipon sa panahon ng pagkalkula ng lumulutang na punto ng pagtatantya sa f * 10 ^ e.(Ang slop ay
/// > hindi isang hangganan para sa totoong error, ngunit bounds ang pagkakaiba sa pagitan ng approximation z at
/// > ang pinakamahusay na posibleng pagtatantya na gumagamit ng mga p bit ng significanceand.)
///
///
pub fn bellerophon<T: RawFloat>(f: &Big, e: i16) -> T {
    let slop = if f <= &Big::from_u64(T::MAX_SIG) {
        // Ang mga kaso abs(e) <log5(2^N) ay nasa fast_path()
        if e >= 0 { 0 } else { 3 }
    } else {
        if e >= 0 { 1 } else { 4 }
    };
    let z = rawfp::big_to_fp(f).mul(&power_of_ten(e)).normalize();
    let exp_p_n = 1 << (P - T::SIG_BITS as u32);
    let lowbits: i64 = (z.f % exp_p_n) as i64;
    // Malaki ba ang slop upang makagawa ng isang pagkakaiba kapag pag-ikot sa n bits?
    //
    if (lowbits - exp_p_n as i64 / 2).abs() <= slop {
        algorithm_r(f, e, fp_to_float(z))
    } else {
        fp_to_float(z)
    }
}

/// Isang umuulit na algorithm na nagpapabuti ng isang lumulutang na point approximation ng `f * 10^e`.
///
/// Ang bawat pag-ulit ay nakakakuha ng isang yunit sa huling lugar na mas malapit, na siyempre ay tumatagal ng katakut-takot upang magtagpo kung ang `z0` ay kahit na banayad.
/// Sa kabutihang palad, kapag ginamit bilang fallback para sa Bellerophon, ang panimulang approximation ay na-off ng halos isang ULP.
///
fn algorithm_r<T: RawFloat>(f: &Big, e: i16, z0: T) -> T {
    let mut z = z0;
    loop {
        let raw = z.unpack();
        let (m, k) = (raw.sig, raw.k);
        let mut x = f.clone();
        let mut y = Big::from_u64(m);

        // Maghanap ng mga positibong integer `x`, `y` tulad ng `x / y` ay eksaktong `(f *10^e) / (m* 2^k)`.
        // Hindi lamang nito iniiwasan ang pagharap sa mga palatandaan ng `e` at `k`, tinatanggal din namin ang lakas ng dalawang karaniwan sa `10^e` at `2^k` upang gawing mas maliit ang mga numero.
        //
        make_ratio(&mut x, &mut y, e, k);

        let m_digits = [(m & 0xFF_FF_FF_FF) as u32, (m >> 32) as u32];
        // Ito ay nakasulat nang medyo mahirap dahil ang aming mga bignum ay hindi sumusuporta sa mga negatibong numero, kaya ginagamit namin ang impormasyong ganap na halaga + mag-sign.
        // Ang pagpaparami sa m_digits ay hindi maaaring mag-overflow.
        // Kung ang `x` o `y` ay sapat na malaki na kailangan nating mag-alala tungkol sa pag-apaw, pagkatapos ay sapat din ang mga ito na `make_ratio` ay nabawasan ang maliit na bahagi ng isang kadahilanan ng 2 ^ 64 o higit pa.
        //
        //
        let (d2, d_negative) = if x >= y {
            // Hindi na kailangan ng x, mag-save ng clone().
            x.sub(&y).mul_pow2(1).mul_digits(&m_digits);
            (x, false)
        } else {
            // Kailangan pa rin y, gumawa ng isang kopya.
            let mut y = y.clone();
            y.sub(&x).mul_pow2(1).mul_digits(&m_digits);
            (y, true)
        };

        if d2 < y {
            let mut d2_double = d2;
            d2_double.mul_pow2(1);
            if m == T::MIN_SIG && d_negative && d2_double > y {
                z = prev_float(z);
            } else {
                return z;
            }
        } else if d2 == y {
            if m % 2 == 0 {
                if m == T::MIN_SIG && d_negative {
                    z = prev_float(z);
                } else {
                    return z;
                }
            } else if d_negative {
                z = prev_float(z);
            } else {
                z = next_float(z);
            }
        } else if d_negative {
            z = prev_float(z);
        } else {
            z = next_float(z);
        }
    }
}

/// Dahil sa `x = f` at `y = m` kung saan ang `f` ay kumakatawan sa pag-input ng mga decimal digit tulad ng dati at ang `m` ay ang halaga ng isang lumulutang na point point, gawin ang ratio na `x / y` na katumbas ng `(f *10^e) / (m* 2^k)`, posibleng mabawasan ng isang lakas ng dalawa na pareho.
///
///
fn make_ratio(x: &mut Big, y: &mut Big, e: i16, k: i16) {
    let (e_abs, k_abs) = (e.abs() as usize, k.abs() as usize);
    if e >= 0 {
        if k >= 0 {
            // x=f *10 ^ e, y=m* 2 ^ k, maliban na binawasan natin ang maliit na bahagi ng ilang lakas na dalawa.
            let common = min(e_abs, k_abs);
            x.mul_pow5(e_abs).mul_pow2(e_abs - common);
            y.mul_pow2(k_abs - common);
        } else {
            // x=f *10 ^ e* 2^abs(k), y=m Hindi ito maaaring mag-overflow dahil nangangailangan ito ng positibong `e` at negatibong `k`, na maaari lamang mangyari para sa mga halagang napakalapit sa 1, na nangangahulugang ang `e` at `k` ay medyo maliit.
            //
            //
            //
            x.mul_pow5(e_abs).mul_pow2(e_abs + k_abs);
        }
    } else {
        if k >= 0 {
            // x=f, y=m *10^abs(e)* 2 ^ k Hindi rin ito maaaring mag-overflow, tingnan sa itaas.
            //
            y.mul_pow5(e_abs).mul_pow2(k_abs + e_abs);
        } else {
            // x=f *2^abs(k), y=m* 10^abs(e), muling binabawas ng isang karaniwang lakas ng dalawa.
            let common = min(e_abs, k_abs);
            x.mul_pow2(k_abs - common);
            y.mul_pow5(e_abs).mul_pow2(e_abs - common);
        }
    }
}

/// Konseptwal, ang Algorithm M ay ang pinakasimpleng paraan upang mai-convert ang isang decimal sa isang float.
///
/// Bumubuo kami ng isang ratio na katumbas ng `f * 10^e`, pagkatapos ay nagtatapon ng kapangyarihan ng dalawa hanggang sa magbigay ito ng isang wastong float signifikanand.
/// Ang binary exponent `k` ay ang bilang ng mga beses na pinarami namin ng numerator o denominator ng dalawa, ibig sabihin, sa lahat ng mga oras na `f *10^e` ay katumbas ng `(u / v)* 2^k`.
/// Kapag nalaman namin ang significanceand, kailangan lamang naming bilugan sa pamamagitan ng pag-iinspeksyon ng natitirang bahagi, na ginagawa sa mga pagpapaandar ng helper sa ibaba.
///
///
/// Ang algorithm na ito ay napakabagal, kahit na ang pag-optimize na inilarawan sa `quick_start()`.
/// Gayunpaman, ito ang pinakasimpleng mga algorithm upang umangkop para sa overflow, underflow, at subnormal na mga resulta.
/// Ang pagpapatupad na ito ay tumatagal kapag ang Bellerophon at Algorithm R ay nalulula.
/// Ang pagtuklas ng underflow at overflow ay madali: Ang ratio ay hindi pa rin isang in-range na kahalagahan, subalit naabot ang exponent ng minimum/maximum.
/// Sa kaso ng pag-apaw, ibabalik lamang namin ang kawalang-hanggan.
///
/// Mas mahirap ang paghawak ng underflow at mga subnormal.
/// Ang isang malaking problema ay na, sa minimum exponent, ang ratio ay maaari pa ring masyadong malaki para sa isang significance.
/// Tingnan ang underflow() para sa mga detalye.
///
pub fn algorithm_m<T: RawFloat>(f: &Big, e: i16) -> T {
    let mut u;
    let mut v;
    let e_abs = e.abs() as usize;
    let mut k = 0;
    if e < 0 {
        u = f.clone();
        v = Big::from_small(1);
        v.mul_pow5(e_abs).mul_pow2(e_abs);
    } else {
        // FIXME posibleng pag-optimize: gawing pangkalahatan ang big_to_fp upang magawa namin ang katumbas ng fp_to_float(big_to_fp(u)) dito, nang walang dobleng pag-ikot.
        //
        u = f.clone();
        u.mul_pow5(e_abs).mul_pow2(e_abs);
        v = Big::from_small(1);
    }
    quick_start::<T>(&mut u, &mut v, &mut k);
    let mut rem = Big::from_small(0);
    let mut x = Big::from_small(0);
    let min_sig = Big::from_u64(T::MIN_SIG);
    let max_sig = Big::from_u64(T::MAX_SIG);
    loop {
        u.div_rem(&v, &mut x, &mut rem);
        if k == T::MIN_EXP_INT {
            // Kailangan nating huminto sa minimum na exponent, kung maghintay kami hanggang `k < T::MIN_EXP_INT`, pagkatapos ay mawawala kami sa pamamagitan ng isang factor na dalawa.
            // Sa kasamaang palad nangangahulugan ito na kailangan nating espesyal na-case normal na mga numero na may minimum exponent.
            // FIXME makahanap ng isang mas matikas pagbabalangkas, ngunit patakbuhin ang `tiny-pow10` pagsubok upang matiyak na ito ay talagang tama!
            //
            //
            if x >= min_sig && x <= max_sig {
                break;
            }
            return underflow(x, v, rem);
        }
        if k > T::MAX_EXP_INT {
            return T::INFINITY;
        }
        if x < min_sig {
            u.mul_pow2(1);
            k -= 1;
        } else if x > max_sig {
            v.mul_pow2(1);
            k += 1;
        } else {
            break;
        }
    }
    let q = num::to_u64(&x);
    let z = rawfp::encode_normal(Unpacked::new(q, k));
    round_by_remainder(v, rem, q, z)
}

/// Nilaktawan ang karamihan sa mga pag-ulit ng Algorithm M sa pamamagitan ng pagsuri sa haba ng bit.
fn quick_start<T: RawFloat>(u: &mut Big, v: &mut Big, k: &mut i16) {
    // Ang haba ng bit ay isang pagtatantya ng base dalawang logarithm, at log(u / v) = log(u), log(v).
    // Ang pagtatantya ay naka-off ng hindi hihigit sa 1, ngunit palaging isang under-estimation, kaya't ang error sa log(u) at log(v) ay magkatulad na pag-sign at kanselahin (kung malaki ang pareho).
    // Samakatuwid ang error para sa log(u / v) ay higit sa isa rin.
    // Ang target na ratio ay isa kung saan ang u/v ay nasa isang saklaw na makahulugan.Sa gayon ang aming kundisyon sa pagwawakas ay log2(u / v) na ang pagiging makahulugan, plus/minus isa.
    // FIXME Ang pagtingin sa pangalawang bit ay maaaring mapabuti ang pagtatantya at maiwasan ang ilang higit pang mga paghihiwalay.
    //
    //
    let target_ratio = T::SIG_BITS as i16;
    let log2_u = u.bit_length() as i16;
    let log2_v = v.bit_length() as i16;
    let mut u_shift: i16 = 0;
    let mut v_shift: i16 = 0;
    assert!(*k == 0);
    loop {
        if *k == T::MIN_EXP_INT {
            // Underflow o subnormal.Iwanan ito sa pangunahing pagpapaandar.
            break;
        }
        if *k == T::MAX_EXP_INT {
            // Pag-apaw.Iwanan ito sa pangunahing pagpapaandar.
            break;
        }
        let log2_ratio = (log2_u + u_shift) - (log2_v + v_shift);
        if log2_ratio < target_ratio - 1 {
            u_shift += 1;
            *k -= 1;
        } else if log2_ratio > target_ratio + 1 {
            v_shift += 1;
            *k += 1;
        } else {
            break;
        }
    }
    u.mul_pow2(u_shift as usize);
    v.mul_pow2(v_shift as usize);
}

fn underflow<T: RawFloat>(x: Big, v: Big, rem: Big) -> T {
    if x < Big::from_u64(T::MIN_SIG) {
        let q = num::to_u64(&x);
        let z = rawfp::encode_subnormal(q);
        return round_by_remainder(v, rem, q, z);
    }
    // Ang Ratio ay hindi isang in-range na kahalagahan na may pinakamaliit na exponent, kaya kailangan nating bilugan ang labis na mga piraso at ayusin ang exponent nang naaayon.
    // Ang tunay na halaga ngayon ay ganito:
    //
    //        x lsb
    // /--------------\/
    // 1010101010101010.10101010101010 * 2^k
    // \-----/\-------/ \------------/
    //    q putol (kinatawan ni rem)
    //
    // Samakatuwid, kapag ang mga bilugan-off na mga bit ay!= 0.5 ULP, napagpasyahan nila ang pag-ikot sa kanilang sarili.
    // Kapag pantay ang mga ito at ang natitira ay non-zero, ang halaga ay kailangan pa ring bilugan.
    // Lamang kapag ang bilugan na mga piraso ay 1/2 at ang natitira ay zero, mayroon kaming isang kalahating-sa-pantay na sitwasyon.
    //
    let bits = x.bit_length();
    let lsb = bits - T::SIG_BITS as usize;
    let q = num::get_bits(&x, lsb, bits);
    let k = T::MIN_EXP_INT + lsb as i16;
    let z = rawfp::encode_normal(Unpacked::new(q, k));
    let q_even = q % 2 == 0;
    match num::compare_with_half_ulp(&x, lsb) {
        Greater => next_float(z),
        Less => z,
        Equal if rem.is_zero() && q_even => z,
        Equal => next_float(z),
    }
}

/// Karaniwang pag-ikot-hanggang-pantay, pinapansin ng pagkakaroon ng pag-ikot batay sa natitirang bahagi ng isang dibisyon.
fn round_by_remainder<T: RawFloat>(v: Big, r: Big, q: u64, z: T) -> T {
    let mut v_minus_r = v;
    v_minus_r.sub(&r);
    if r < v_minus_r {
        z
    } else if r > v_minus_r {
        next_float(z)
    } else if q % 2 == 0 {
        z
    } else {
        next_float(z)
    }
}