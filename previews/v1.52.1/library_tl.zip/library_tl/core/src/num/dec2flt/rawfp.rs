//! Kinakalikot ang bit sa positibong IEEE 754 floats.Ang mga negatibong numero ay hindi at hindi kailangang hawakan.
//! Ang mga normal na lumulutang na numero ng numero ay may isang representasyong kanonikal bilang (frac, exp) na ang halaga ay 2 <sup>exp</sup> * (1 + sum(frac[N-i] / 2<sup>i</sup>)) kung saan ang N ay ang bilang ng mga piraso.
//!
//! Ang mga subnormal ay bahagyang naiiba at kakaiba, ngunit nalalapat ang parehong prinsipyo.
//!
//! Gayunpaman, kinakatawan namin ang mga ito bilang (sig, k) na may positibong f, na ang halaga ay f *
//! 2 <sup>e</sup> .Bukod sa ginagawang malinaw ang "hidden bit", binabago nito ang exponent ng tinaguriang shift ng mantissa.
//!
//! Maglagay ng ibang paraan, karaniwang floats ay nakasulat bilang (1) ngunit narito ang mga ito ay nakasulat bilang (2):
//!
//! 1. `1.101100...11 * 2^m`
//! 2. `1101100...11 * 2^n`
//!
//! Tinatawag namin ang (1) na **praksyonal na representasyon** at (2) ang **integral na representasyon**.
//!
//! Maraming mga pagpapaandar sa modyul na ito ang nangangasiwa lamang ng mga normal na numero.Ang dec2flt na gawain ay konserbatibong gawin ang unibersal na tamang mabagal na landas (Algorithm M) para sa napakaliit at napakalaking numero.
//! Ang algorithm na iyon ay nangangailangan lamang ng next_float() na nangangasiwa sa mga subnormal at zero.
//!
//!
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::convert::{TryFrom, TryInto};
use crate::fmt::{Debug, LowerExp};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;
use crate::num::FpCategory;
use crate::num::FpCategory::{Infinite, Nan, Normal, Subnormal, Zero};
use crate::ops::{Add, Div, Mul, Neg};

#[derive(Copy, Clone, Debug)]
pub struct Unpacked {
    pub sig: u64,
    pub k: i16,
}

impl Unpacked {
    pub fn new(sig: u64, k: i16) -> Self {
        Unpacked { sig, k }
    }
}

/// Ang isang helper na trait upang maiwasan ang pagdoble ng karaniwang lahat ng code ng conversion para sa `f32` at `f64`.
///
/// Tingnan ang komentong doc ng magulang module kung bakit kinakailangan ito.
///
/// Dapat **hindi kailanman** ipinatupad para sa iba pang mga uri o gagamitin sa labas ng modyul na dec2flt.
pub trait RawFloat:
    Copy + Debug + LowerExp + Mul<Output = Self> + Div<Output = Self> + Neg<Output = Self>
{
    const INFINITY: Self;
    const NAN: Self;
    const ZERO: Self;

    /// Uri na ginamit ng `to_bits` at `from_bits`.
    type Bits: Add<Output = Self::Bits> + From<u8> + TryFrom<u64>;

    /// Nagsasagawa ng isang hilaw na transmutation sa isang integer.
    fn to_bits(self) -> Self::Bits;

    /// Nagsasagawa ng isang hilaw na transmutation mula sa isang integer.
    fn from_bits(v: Self::Bits) -> Self;

    /// Ibinabalik ang kategorya kung saan nabibilang ang numerong ito.
    fn classify(self) -> FpCategory;

    /// Ibinabalik ang mantissa, exponent at mag-sign bilang mga integer.
    fn integer_decode(self) -> (u64, i16, i8);

    /// Na-decode ang float.
    fn unpack(self) -> Unpacked;

    /// Mga cast mula sa isang maliit na integer na maaaring kinatawan nang eksakto.
    /// Panic kung ang integer ay hindi maaaring kinatawan, ang iba pang code sa modyul na ito ay tinitiyak na hindi kailanman hahayaan na mangyari iyon.
    fn from_int(x: u64) -> Self;

    /// Nakukuha ang halagang 10 <sup>e</sup> mula sa isang pre-compute na talahanayan.
    /// Panics para sa `e >= CEIL_LOG5_OF_MAX_SIG`.
    fn short_fast_pow10(e: usize) -> Self;

    /// Kung ano ang sinasabi ng pangalan.
    /// Ito ay mas madali sa hard code kaysa sa juggling intrinsics at umaasa LLVM pare-pareho tiklop ito.
    const CEIL_LOG5_OF_MAX_SIG: i16;

    // Ang isang konserbatibo na nakatali sa decimal digit ng mga input na hindi makagawa ng overflow o zero o
    /// mga subnormal.Marahil ang decimal exponent ng maximum na normal na halaga, kaya't ang pangalan.
    const MAX_NORMAL_DIGITS: usize;

    /// Kapag ang pinaka-makabuluhang decimal digit ay may halaga ng lugar na mas malaki kaysa dito, ang bilang ay tiyak na bilugan hanggang sa infinity.
    ///
    const INF_CUTOFF: i64;

    /// Kapag ang pinaka-makabuluhang decimal digit ay may isang halaga ng lugar na mas mababa sa ito, ang numero ay tiyak na bilugan sa zero.
    ///
    const ZERO_CUTOFF: i64;

    /// Ang bilang ng mga piraso sa exponent.
    const EXP_BITS: u8;

    /// Ang bilang ng mga piraso sa significanceand,*kabilang ang* ang nakatagong kaunti.
    const SIG_BITS: u8;

    /// Ang bilang ng mga piraso sa significanceand,*hindi kasama ang* nakatagong kaunti.
    const EXPLICIT_SIG_BITS: u8;

    /// Ang maximum na legal na tagapagtaguyod sa representasyong praksyonal.
    const MAX_EXP: i16;

    /// Ang minimum na legal na tagapagtaguyod sa representasyon ng praksyonal, hindi kasama ang mga subnormal.
    const MIN_EXP: i16;

    /// `MAX_EXP` para sa integral na representasyon, ibig sabihin, na inilapat ang shift.
    const MAX_EXP_INT: i16;

    /// `MAX_EXP` naka-encode (ibig sabihin, may offset bias)
    const MAX_ENCODED_EXP: i16;

    /// `MIN_EXP` para sa integral na representasyon, ibig sabihin, na inilapat ang shift.
    const MIN_EXP_INT: i16;

    /// Ang maximum na na-normalize na makahulugan sa integral na representasyon.
    const MAX_SIG: u64;

    /// Ang minimal na normalized na makahulugan sa integral na representasyon.
    const MIN_SIG: u64;
}

// Karamihan sa isang pag-aayos para sa #34344.
macro_rules! other_constants {
    ($type: ident) => {
        const EXPLICIT_SIG_BITS: u8 = Self::SIG_BITS - 1;
        const MAX_EXP: i16 = (1 << (Self::EXP_BITS - 1)) - 1;
        const MIN_EXP: i16 = -<Self as RawFloat>::MAX_EXP + 1;
        const MAX_EXP_INT: i16 = <Self as RawFloat>::MAX_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_ENCODED_EXP: i16 = (1 << Self::EXP_BITS) - 1;
        const MIN_EXP_INT: i16 = <Self as RawFloat>::MIN_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_SIG: u64 = (1 << Self::SIG_BITS) - 1;
        const MIN_SIG: u64 = 1 << (Self::SIG_BITS - 1);

        const INFINITY: Self = $type::INFINITY;
        const NAN: Self = $type::NAN;
        const ZERO: Self = 0.0;
    };
}

impl RawFloat for f32 {
    type Bits = u32;

    const SIG_BITS: u8 = 24;
    const EXP_BITS: u8 = 8;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 11;
    const MAX_NORMAL_DIGITS: usize = 35;
    const INF_CUTOFF: i64 = 40;
    const ZERO_CUTOFF: i64 = -48;
    other_constants!(f32);

    /// Ibinabalik ang mantissa, exponent at mag-sign bilang mga integer.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 31 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 23) & 0xff) as i16;
        let mantissa =
            if exponent == 0 { (bits & 0x7fffff) << 1 } else { (bits & 0x7fffff) | 0x800000 };
        // Exponent bias + mantissa shift
        exponent -= 127 + 23;
        (mantissa as u64, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f32 {
        // Ang rkruppe ay hindi sigurado kung tama ang pag-ikot ng `as` sa lahat ng mga platform.
        debug_assert!(x as f32 == fp_to_float(Fp { f: x, e: 0 }));
        x as f32
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F32_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

impl RawFloat for f64 {
    type Bits = u64;

    const SIG_BITS: u8 = 53;
    const EXP_BITS: u8 = 11;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 23;
    const MAX_NORMAL_DIGITS: usize = 305;
    const INF_CUTOFF: i64 = 310;
    const ZERO_CUTOFF: i64 = -326;
    other_constants!(f64);

    /// Ibinabalik ang mantissa, exponent at mag-sign bilang mga integer.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 63 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 52) & 0x7ff) as i16;
        let mantissa = if exponent == 0 {
            (bits & 0xfffffffffffff) << 1
        } else {
            (bits & 0xfffffffffffff) | 0x10000000000000
        };
        // Exponent bias + mantissa shift
        exponent -= 1023 + 52;
        (mantissa, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f64 {
        // Ang rkruppe ay hindi sigurado kung tama ang pag-ikot ng `as` sa lahat ng mga platform.
        debug_assert!(x as f64 == fp_to_float(Fp { f: x, e: 0 }));
        x as f64
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F64_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

/// Nagko-convert ng `Fp` sa pinakamalapit na uri ng float ng makina.
/// Hindi hawakan ang subnormal na mga resulta.
pub fn fp_to_float<T: RawFloat>(x: Fp) -> T {
    let x = x.normalize();
    // x.f ay 64 bit, kaya xe ay may mantissa shift na 63
    let e = x.e + 63;
    if e > T::MAX_EXP {
        panic!("fp_to_float: exponent {} too large", e)
    } else if e > T::MIN_EXP {
        encode_normal(round_normal::<T>(x))
    } else {
        panic!("fp_to_float: exponent {} too small", e)
    }
}

/// Paikotin ang 64-bit significanceand sa T::SIG_BITS bits na may kalahating-sa-pantay.
/// Hindi hawakan ang exponent overflow.
pub fn round_normal<T: RawFloat>(x: Fp) -> Unpacked {
    let excess = 64 - T::SIG_BITS as i16;
    let half: u64 = 1 << (excess - 1);
    let (q, rem) = (x.f >> excess, x.f & ((1 << excess) - 1));
    assert_eq!(q << excess | rem, x.f);
    // Ayusin ang shift ng mantissa
    let k = x.e + excess;
    if rem < half {
        Unpacked::new(q, k)
    } else if rem == half && (q % 2) == 0 {
        Unpacked::new(q, k)
    } else if q == T::MAX_SIG {
        Unpacked::new(T::MIN_SIG, k + 1)
    } else {
        Unpacked::new(q + 1, k)
    }
}

/// Kabaligtaran ng `RawFloat::unpack()` para sa na-normalize na mga numero.
/// Panics kung ang significance at exponent ay hindi wasto para sa na-normalize na mga numero.
pub fn encode_normal<T: RawFloat>(x: Unpacked) -> T {
    debug_assert!(
        T::MIN_SIG <= x.sig && x.sig <= T::MAX_SIG,
        "encode_normal: significand not normalized"
    );
    // Alisin ang nakatagong piraso
    let sig_enc = x.sig & !(1 << T::EXPLICIT_SIG_BITS);
    // Ayusin ang exponent para sa exponent bias at mantissa shift
    let k_enc = x.k + T::MAX_EXP + T::EXPLICIT_SIG_BITS as i16;
    debug_assert!(k_enc != 0 && k_enc < T::MAX_ENCODED_EXP, "encode_normal: exponent out of range");
    // Iiwan ang pag-sign bit sa 0 ("+"), lahat ng aming mga numero ay positibo
    let bits = (k_enc as u64) << T::EXPLICIT_SIG_BITS | sig_enc;
    T::from_bits(bits.try_into().unwrap_or_else(|_| unreachable!()))
}

/// Bumuo ng isang subnormal.Pinapayagan ang isang mantissa na 0 at nagtatayo ng zero.
pub fn encode_subnormal<T: RawFloat>(significand: u64) -> T {
    assert!(significand < T::MIN_SIG, "encode_subnormal: not actually subnormal");
    // Ang naka-encode na exponent ay 0, ang bit ng pag-sign ay 0, kaya kailangan lang naming muling bigyang kahulugan ang mga piraso.
    T::from_bits(significand.try_into().unwrap_or_else(|_| unreachable!()))
}

/// Tinatayang isang bignum sa isang Fp.Mga bilog sa loob ng 0.5 ULP na may kalahating-sa-pantay.
pub fn big_to_fp(f: &Big) -> Fp {
    let end = f.bit_length();
    assert!(end != 0, "big_to_fp: unexpectedly, input is zero");
    let start = end.saturating_sub(64);
    let leading = num::get_bits(f, start, end);
    // Pinutol namin ang lahat ng mga piraso bago ang index `start`, ibig sabihin, epektibo kaming tamang paglipat ng isang halaga ng `start`, kaya ito rin ang exponent na kailangan namin.
    //
    let e = start as i16;
    let rounded_down = Fp { f: leading, e }.normalize();
    // Round (half-to-even) depende sa pinutol na mga piraso.
    match num::compare_with_half_ulp(f, start) {
        Less => rounded_down,
        Equal if leading % 2 == 0 => rounded_down,
        Equal | Greater => match leading.checked_add(1) {
            Some(f) => Fp { f, e }.normalize(),
            None => Fp { f: 1 << 63, e: e + 1 },
        },
    }
}

/// Mahahanap ang pinakamalaking numero ng lumulutang na punto na mahigpit na mas maliit kaysa sa pagtatalo.
/// Hindi hawakan ang mga subnormal, zero, o exponent underflow.
pub fn prev_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Infinite => panic!("prev_float: argument is infinite"),
        Nan => panic!("prev_float: argument is NaN"),
        Subnormal => panic!("prev_float: argument is subnormal"),
        Zero => panic!("prev_float: argument is zero"),
        Normal => {
            let Unpacked { sig, k } = x.unpack();
            if sig == T::MIN_SIG {
                encode_normal(Unpacked::new(T::MAX_SIG, k - 1))
            } else {
                encode_normal(Unpacked::new(sig - 1, k))
            }
        }
    }
}

// Hanapin ang pinakamaliit na bilang ng lumulutang na mahigpit na mas malaki kaysa sa pagtatalo.
// Ang pagpapatakbo na ito ay nakakabusog, ibig sabihin, next_float(inf) ==inf.
// Hindi tulad ng karamihan sa code sa modyul na ito, ang pagpapaandar na ito ay nangangasiwa ng zero, subnormal, at infinities.
// Gayunpaman, tulad ng lahat ng iba pang code dito, hindi ito nakikitungo sa NaN at mga negatibong numero.
pub fn next_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Nan => panic!("next_float: argument is NaN"),
        Infinite => T::INFINITY,
        // Mukhang napakahusay na totoo, ngunit gumagana ito.
        // 0.0 ay naka-encode bilang all-zero na salita.Ang mga subnormal ay 0x000m ... m kung saan ang mantissa.
        // Sa partikular, ang pinakamaliit na subnormal ay 0x0 ... 01 at ang pinakamalaki ay 0x000F ... F.
        // Ang pinakamaliit na normal na numero ay 0x0010 ... 0, kaya't gumagana rin ang kanto na ito.
        // Kung ang pagtaas ay umapaw sa mantissa, ang bit ng bitbit ay nagdaragdag ng exponent ayon sa gusto natin, at ang mantissa bits ay naging zero.
        // Dahil sa nakatagong kombensyon, ito rin mismo ang nais namin!
        // Panghuli, f64::MAX + 1=7eff ... f + 1=7ff0 ... 0= f64::INFINITY.
        //
        Zero | Subnormal | Normal => T::from_bits(x.to_bits() + T::Bits::from(1u8)),
    }
}