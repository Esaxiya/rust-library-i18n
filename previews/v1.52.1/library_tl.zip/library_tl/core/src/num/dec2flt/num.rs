//! Mga pagpapaandar ng utility para sa mga bignum na walang katuturan upang maging mga pamamaraan.

// FIXME Ang pangalan ng modyul na ito ay medyo kapus-palad, dahil ang ibang mga module ay nag-i-import din ng `core::num`.

use crate::cmp::Ordering::{self, Equal, Greater, Less};

pub use crate::num::bignum::Big32x40 as Big;

/// Subukan kung ang pagpuputol ng lahat ng mga bit na hindi gaanong makabuluhan kaysa sa `ones_place` ay nagpapakilala sa isang kamag-anak na error na mas mababa, pantay, o mas malaki kaysa sa 0.5 ULP.
///
pub fn compare_with_half_ulp(f: &Big, ones_place: usize) -> Ordering {
    if ones_place == 0 {
        return Less;
    }
    let half_bit = ones_place - 1;
    if f.get_bit(half_bit) == 0 {
        // <0.5 ULP
        return Less;
    }
    // Kung ang lahat ng natitirang mga bit ay zero, ito ay= 0.5 ULP, kung hindi man> 0.5 Kung wala nang mga piraso (half_bit==0), ang ibaba ay tama ring nagbabalik ng Pantay.
    //
    for i in 0..half_bit {
        if f.get_bit(i) == 1 {
            return Greater;
        }
    }
    Equal
}

/// Nagko-convert ng isang ASCII string na naglalaman lamang ng mga decimal digit sa isang `u64`.
///
/// Hindi nagsasagawa ng mga tseke para sa overflow o hindi wastong mga character, kaya kung hindi nag-ingat ang tumatawag, ang resulta ay bogus at maaari panic (kahit na hindi ito magiging `unsafe`).
/// Bilang karagdagan, ang walang laman na mga string ay itinuturing na zero.
/// Ang pagpapaandar na ito ay mayroon dahil
///
/// 1. ang paggamit ng `FromStr` sa `&[u8]` ay nangangailangan ng `from_utf8_unchecked`, alin ang masama, at
/// 2. ang pagdidikit ng mga resulta ng `integral.parse()` at `fractional.parse()` ay mas kumplikado kaysa sa buong pagpapaandar na ito.
///
pub fn from_str_unchecked<'a, T>(bytes: T) -> u64
where
    T: IntoIterator<Item = &'a u8>,
{
    let mut result = 0;
    for &c in bytes {
        result = result * 10 + (c - b'0') as u64;
    }
    result
}

/// Nagko-convert ng isang string ng ASCII digit sa isang bignum.
///
/// Tulad ng `from_str_unchecked`, ang pagpapaandar na ito ay nakasalalay sa parser upang maalis ang mga di-digit.
pub fn digits_to_big(integral: &[u8], fractional: &[u8]) -> Big {
    let mut f = Big::from_small(0);
    for &c in integral.iter().chain(fractional) {
        let n = (c - b'0') as u32;
        f.mul_small(10);
        f.add_small(n);
    }
    f
}

/// Inaalis ang isang bignum sa isang 64 bit na integer.Panics kung ang bilang ay masyadong malaki.
pub fn to_u64(x: &Big) -> u64 {
    assert!(x.bit_length() < 64);
    let d = x.digits();
    if d.len() < 2 { d[0] as u64 } else { (d[1] as u64) << 32 | d[0] as u64 }
}

/// Kinukuha ang isang hanay ng mga piraso.

/// Ang index 0 ay ang hindi gaanong makabuluhang kaunting at ang saklaw ay kalahating bukas tulad ng dati.
/// Panics kung hiniling na kumuha ng higit pang mga piraso kaysa magkasya sa uri ng pagbabalik.
pub fn get_bits(x: &Big, start: usize, end: usize) -> u64 {
    assert!(end - start <= 64);
    let mut result: u64 = 0;
    for i in (start..end).rev() {
        result = result << 1 | x.get_bit(i) as u64;
    }
    result
}