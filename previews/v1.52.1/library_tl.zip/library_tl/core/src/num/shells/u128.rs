//! Patuloy para sa 128-bit unsigned integer type.
//!
//! *[See also the `u128` primitive type][u128].*
//!
//! Dapat gamitin ng bagong code ang mga nauugnay na pare-pareho nang direkta sa uri ng primitive.

#![stable(feature = "i128", since = "1.26.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `u128`"
)]

int_module! { u128, #[stable(feature = "i128", since="1.26.0")] }