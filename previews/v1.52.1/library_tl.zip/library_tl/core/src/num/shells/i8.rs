//! Patuloy para sa 8-bit na naka-sign na uri ng integer.
//!
//! *[See also the `i8` primitive type][i8].*
//!
//! Dapat gamitin ng bagong code ang mga nauugnay na pare-pareho nang direkta sa uri ng primitive.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `i8`"
)]

int_module! { i8 }