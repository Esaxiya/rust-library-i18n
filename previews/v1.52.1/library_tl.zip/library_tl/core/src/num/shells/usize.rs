//! Patuloy para sa uri ng pointer na hindi naka-sign na uri ng integer.
//!
//! *[See also the `usize` primitive type][usize].*
//!
//! Dapat gamitin ng bagong code ang mga nauugnay na pare-pareho nang direkta sa uri ng primitive.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `usize`"
)]

int_module! { usize }