//! Patuloy para sa uri ng naka-sign na integer na laki ng pointer.
//!
//! *[See also the `isize` primitive type][isize].*
//!
//! Dapat gamitin ng bagong code ang mga nauugnay na pare-pareho nang direkta sa uri ng primitive.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `isize`"
)]

int_module! { isize }