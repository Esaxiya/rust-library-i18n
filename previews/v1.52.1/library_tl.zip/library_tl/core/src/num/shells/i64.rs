//! Patuloy para sa 64-bit na naka-sign na uri ng integer.
//!
//! *[See also the `i64` primitive type][i64].*
//!
//! Dapat gamitin ng bagong code ang mga nauugnay na pare-pareho nang direkta sa uri ng primitive.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `i64`"
)]

int_module! { i64 }