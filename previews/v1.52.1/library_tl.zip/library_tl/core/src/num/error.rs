//! Mga uri ng error para sa conversion sa mga integral na uri.

use crate::convert::Infallible;
use crate::fmt;

/// Bumalik ang uri ng error kapag nabigo ang isang naka-check na integral na uri ng conversion.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Debug, Copy, Clone, PartialEq, Eq)]
pub struct TryFromIntError(pub(crate) ());

impl TryFromIntError {
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        "out of range integral type conversion attempted"
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for TryFromIntError {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(fmt)
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl From<Infallible> for TryFromIntError {
    fn from(x: Infallible) -> TryFromIntError {
        match x {}
    }
}

#[unstable(feature = "never_type", issue = "35121")]
impl From<!> for TryFromIntError {
    fn from(never: !) -> TryFromIntError {
        // Tumugma sa halip na pilitin upang matiyak na ang code tulad ng `From<Infallible> for TryFromIntError` sa itaas ay patuloy na gagana kapag ang `Infallible` ay naging isang alias sa `!`.
        //
        //
        match never {}
    }
}

/// Isang error na maaaring ibalik kapag nag-parse ng isang integer.
///
/// Ang error na ito ay ginagamit bilang uri ng error para sa mga pagpapaandar ng `from_str_radix()` sa mga primitive na integer na uri, tulad ng [`i8::from_str_radix`].
///
/// # Mga potensyal na sanhi
///
/// Kabilang sa iba pang mga kadahilanan, ang `ParseIntError` ay maaaring itapon dahil sa nangunguna o sumusunod na whitespace sa string hal, kapag nakuha ito mula sa karaniwang input.
///
/// Ang paggamit ng pamamaraang [`str::trim()`] ay nagsisiguro na walang whitespace na mananatili bago ang pag-parse.
///
/// # Example
///
/// ```
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {}", e);
/// }
/// ```
///
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseIntError {
    pub(super) kind: IntErrorKind,
}

/// Enum upang maiimbak ang iba't ibang mga uri ng mga error na maaaring maging sanhi ng pagkabigo ng pag-parse ng isang integer.
///
/// # Example
///
/// ```
/// #![feature(int_error_matching)]
///
/// # fn main() {
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {:?}", e.kind());
/// }
/// # }
/// ```
#[unstable(
    feature = "int_error_matching",
    reason = "it can be useful to match errors when making error messages \
              for integer parsing",
    issue = "22639"
)]
#[derive(Debug, Clone, PartialEq, Eq)]
#[non_exhaustive]
pub enum IntErrorKind {
    /// Ang pagpapahalaga sa halaga ay walang laman.
    ///
    /// Kabilang sa iba pang mga kadahilanan, ang variant na ito ay maitatayo kapag nag-parse ng isang walang laman na string.
    Empty,
    /// Naglalaman ng isang hindi wastong digit sa konteksto nito.
    ///
    /// Kabilang sa iba pang mga kadahilanan, ang variant na ito ay maitatayo kapag nag-parse ng isang string na naglalaman ng isang char na hindi ASCII.
    ///
    /// Ang variant na ito ay itinatayo din kapag ang isang `+` o `-` ay maling lugar sa loob ng isang string alinman sa sarili nito o sa gitna ng isang numero.
    ///
    ///
    InvalidDigit,
    /// Masyadong malaki ang integer upang maiimbak sa uri ng target na integer.
    PosOverflow,
    /// Ang integer ay masyadong maliit upang maiimbak sa uri ng target na integer.
    NegOverflow,
    /// Ang halaga ay Zero
    ///
    /// Ipapalabas ang variant na ito kapag ang parsing string ay may halagang zero, na magiging labag sa batas para sa mga di-zero na uri.
    ///
    Zero,
}

impl ParseIntError {
    /// Naglabas ng detalyadong sanhi ng pag-parse ng isang integer na pagkabigo.
    #[unstable(
        feature = "int_error_matching",
        reason = "it can be useful to match errors when making error messages \
              for integer parsing",
        issue = "22639"
    )]
    pub fn kind(&self) -> &IntErrorKind {
        &self.kind
    }
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            IntErrorKind::Empty => "cannot parse integer from empty string",
            IntErrorKind::InvalidDigit => "invalid digit found in string",
            IntErrorKind::PosOverflow => "number too large to fit in target type",
            IntErrorKind::NegOverflow => "number too small to fit in target type",
            IntErrorKind::Zero => "number would be zero for non-zero type",
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseIntError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}