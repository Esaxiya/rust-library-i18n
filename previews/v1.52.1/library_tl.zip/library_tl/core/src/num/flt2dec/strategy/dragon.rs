//! Halos direktang (ngunit bahagyang na-optimize) na pagsasalin ng Rust ng Larawan 3 ng "Pag-print ng Mga Lumulutang-Point na Numero nang Mabilis at Tumpak" [^ 1].
//!
//!
//! [^1]: Burger, RG at Dybvig, RK 1996. Pag-print ng mga numero ng lumulutang-point
//!   mabilis at tumpak.SIGPLAN Hindi.31, 5 (Mayo. 1996), 108-116.

use crate::cmp::Ordering;
use crate::mem::MaybeUninit;

use crate::num::bignum::Big32x40 as Big;
use crate::num::bignum::Digit32 as Digit;
use crate::num::flt2dec::estimator::estimate_scaling_factor;
use crate::num::flt2dec::{round_up, Decoded, MAX_SIG_DIGITS};

static POW10: [Digit; 10] =
    [1, 10, 100, 1000, 10000, 100000, 1000000, 10000000, 100000000, 1000000000];
static TWOPOW10: [Digit; 10] =
    [2, 20, 200, 2000, 20000, 200000, 2000000, 20000000, 200000000, 2000000000];

// kinakalkula na mga array ng `Digit`s para sa 10 ^ (2 ^ n)
static POW10TO16: [Digit; 2] = [0x6fc10000, 0x2386f2];
static POW10TO32: [Digit; 4] = [0, 0x85acef81, 0x2d6d415b, 0x4ee];
static POW10TO64: [Digit; 7] = [0, 0, 0xbf6a1f01, 0x6e38ed64, 0xdaa797ed, 0xe93ff9f4, 0x184f03];
static POW10TO128: [Digit; 14] = [
    0, 0, 0, 0, 0x2e953e01, 0x3df9909, 0xf1538fd, 0x2374e42f, 0xd3cff5ec, 0xc404dc08, 0xbccdb0da,
    0xa6337f19, 0xe91f2603, 0x24e,
];
static POW10TO256: [Digit; 27] = [
    0, 0, 0, 0, 0, 0, 0, 0, 0x982e7c01, 0xbed3875b, 0xd8d99f72, 0x12152f87, 0x6bde50c6, 0xcf4a6e70,
    0xd595d80f, 0x26b2716e, 0xadc666b0, 0x1d153624, 0x3c42d35a, 0x63ff540e, 0xcc5573c0, 0x65f9ef17,
    0x55bc28f2, 0x80dcc7f7, 0xf46eeddc, 0x5fdcefce, 0x553f7,
];

#[doc(hidden)]
pub fn mul_pow10(x: &mut Big, n: usize) -> &mut Big {
    debug_assert!(n < 512);
    if n & 7 != 0 {
        x.mul_small(POW10[n & 7]);
    }
    if n & 8 != 0 {
        x.mul_small(POW10[8]);
    }
    if n & 16 != 0 {
        x.mul_digits(&POW10TO16);
    }
    if n & 32 != 0 {
        x.mul_digits(&POW10TO32);
    }
    if n & 64 != 0 {
        x.mul_digits(&POW10TO64);
    }
    if n & 128 != 0 {
        x.mul_digits(&POW10TO128);
    }
    if n & 256 != 0 {
        x.mul_digits(&POW10TO256);
    }
    x
}

fn div_2pow10(x: &mut Big, mut n: usize) -> &mut Big {
    let largest = POW10.len() - 1;
    while n > largest {
        x.div_rem_small(POW10[largest]);
        n -= largest;
    }
    x.div_rem_small(TWOPOW10[n]);
    x
}

// magagamit lamang kapag `x < 16 * scale`;Ang `scaleN` ay dapat na `scale.mul_small(N)`
fn div_rem_upto_16<'a>(
    x: &'a mut Big,
    scale: &Big,
    scale2: &Big,
    scale4: &Big,
    scale8: &Big,
) -> (u8, &'a mut Big) {
    let mut d = 0;
    if *x >= *scale8 {
        x.sub(scale8);
        d += 8;
    }
    if *x >= *scale4 {
        x.sub(scale4);
        d += 4;
    }
    if *x >= *scale2 {
        x.sub(scale2);
        d += 2;
    }
    if *x >= *scale {
        x.sub(scale);
        d += 1;
    }
    debug_assert!(*x < *scale);
    (d, x)
}

/// Ang pinakamaikling pagpapatupad ng mode para sa Dragon.
pub fn format_shortest<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    // ang bilang na `v` sa format ay kilala na:
    // - katumbas ng `mant * 2^exp`;
    // - na nauna sa pamamagitan ng `(mant - 2 *minus)* 2^exp` sa orihinal na uri;at
    // - sinusundan ng `(mant + 2 *plus)* 2^exp` sa orihinal na uri.
    //
    // malinaw naman, ang `minus` at `plus` ay hindi maaaring zero.(para sa mga infinity, gumagamit kami ng mga halagang wala sa saklaw.) Ipinapalagay din namin na hindi bababa sa isang digit ang nabuo, ibig sabihin, ang `mant` ay hindi maaaring maging zero din.
    //
    // nangangahulugan din ito na ang anumang numero sa pagitan ng `low = (mant - minus)*2^exp` at `high = (mant + plus)* 2^exp` ay mai-map sa eksaktong numero ng lumulutang point na ito, kasama ang mga hangganan kapag ang orihinal na mantissa ay pantay (ibig sabihin, `!mant_was_odd`).
    //
    //
    //

    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());
    assert!(buf.len() >= MAX_SIG_DIGITS);

    // `a.cmp(&b) < rounding` ay `if d.inclusive {a <= b} else {a < b}`
    let rounding = if d.inclusive { Ordering::Greater } else { Ordering::Equal };

    // tantyahin ang `k_0` mula sa orihinal na mga input na nagbibigay-kasiyahan sa `10^(k_0-1) < high <= 10^(k_0+1)`.
    // ang masikip na nakatali `k` nagbibigay-kasiyahan `10^(k-1) < high <= 10^k` ay kinakalkula sa paglaon.
    let mut k = estimate_scaling_factor(d.mant + d.plus, d.exp);

    // i-convert ang `{mant, plus, minus} * 2^exp` sa form na praksyonal upang:
    // - `v = mant / scale`
    // - `low = (mant - minus) / scale`
    // - `high = (mant + plus) / scale`
    let mut mant = Big::from_u64(d.mant);
    let mut minus = Big::from_u64(d.minus);
    let mut plus = Big::from_u64(d.plus);
    let mut scale = Big::from_small(1);
    if d.exp < 0 {
        scale.mul_pow2(-d.exp as usize);
    } else {
        mant.mul_pow2(d.exp as usize);
        minus.mul_pow2(d.exp as usize);
        plus.mul_pow2(d.exp as usize);
    }

    // hatiin ang `mant` ng `10^k`.ngayon `scale / 10 < mant + plus <= scale * 10`.
    if k >= 0 {
        mul_pow10(&mut scale, k as usize);
    } else {
        mul_pow10(&mut mant, -k as usize);
        mul_pow10(&mut minus, -k as usize);
        mul_pow10(&mut plus, -k as usize);
    }

    // pag-aayos kapag `mant + plus > scale` (o `>=`).
    // hindi namin talaga binabago ang `scale`, dahil maaari naming laktawan sa halip ang paunang pagpaparami.
    // ngayon `scale < mant + plus <= scale * 10` at handa na kaming makabuo ng mga digit.
    //
    // tandaan na ang `d[0]`*ay maaaring* maging zero, kapag `scale - plus < mant < scale`.
    // sa kasong ito ang pag-ikot ng kundisyon (`up` sa ibaba) ay ma-trigger agad.
    if scale.cmp(mant.clone().add(&plus)) < rounding {
        // katumbas ng pag-scale ng `scale` ng 10
        k += 1;
    } else {
        mant.mul_small(10);
        minus.mul_small(10);
        plus.mul_small(10);
    }

    // cache `(2, 4, 8) * scale` para sa pagbuo ng digit.
    let mut scale2 = scale.clone();
    scale2.mul_pow2(1);
    let mut scale4 = scale.clone();
    scale4.mul_pow2(2);
    let mut scale8 = scale.clone();
    scale8.mul_pow2(3);

    let mut down;
    let mut up;
    let mut i = 0;
    loop {
        // mga invariant, kung saan ang `d[0..n-1]` ay mga digit na nabuo sa ngayon:
        // - `v = mant / scale * 10^(k-n-1) + d[0..n-1] * 10^(k-n)`
        // - `v - low = minus / scale * 10^(k-n-1)`
        // - `high - v = plus / scale * 10^(k-n-1)`
        // - `(mant + plus) / scale <= 10` (kaya `mant / scale < 10`) kung saan ang `d[i..j]` ay isang maikling salita para sa `d [i] * 10 ^ (ji) + ...
        // + d [j-1] * 10 + d[j]`.

        // makabuo ng isang digit: `d[n] = floor(mant / scale) < 10`.
        let (d, _) = div_rem_upto_16(&mut mant, &scale, &scale2, &scale4, &scale8);
        debug_assert!(d < 10);
        buf[i] = MaybeUninit::new(b'0' + d);
        i += 1;

        // ito ay isang pinasimple na paglalarawan ng binagong Dragon algorithm.
        // maraming mga panggitna derivasyon at pagkakumpleto ng mga argumento ay tinanggal para sa kaginhawaan.
        //
        // magsimula sa binagong mga invariant, tulad ng pag-update namin ng `n`:
        // - `v = mant / scale * 10^(k-n) + d[0..n-1] * 10^(k-n)`
        // - `v - low = minus / scale * 10^(k-n)`
        // - `high - v = plus / scale * 10^(k-n)`
        //
        // ipalagay na ang `d[0..n-1]` ay ang pinakamaikling representasyon sa pagitan ng `low` at `high`, ibig sabihin, natutugunan ng `d[0..n-1]` ang parehong mga sumusunod ngunit ang `d[0..n-2]` ay hindi:
        //
        // - `low < d[0..n-1] * 10^(k-n) < high` (bijectivity: mga digit na bilog hanggang `v`);at
        // - `abs(v / 10^(k-n) - d[0..n-1]) <= 1/2` (tama ang huling digit).
        //
        // ang pangalawang kondisyon ay nagpapasimple sa `2 * mant <= scale`.
        // ang paglutas ng mga invariant sa mga tuntunin ng `mant`, `low` at `high` ay magbubunga ng isang mas simpleng bersyon ng unang kundisyon: `-plus < mant < minus`.
        // mula noong `-plus < 0 <= mant`, mayroon kaming tamang pinakamaikling representasyon kapag `mant < minus` at `2 * mant <= scale`.
        // (ang dating ay nagiging `mant <= minus` kapag ang orihinal na mantissa ay pantay.)
        //
        // kapag ang pangalawa ay hindi hawakan (`2 * mant> scale`), kailangan nating taasan ang huling digit.
        // sapat na ito para sa pagpapanumbalik ng kundisyong iyon: alam na natin na ang henerasyon ng digit na ginagarantiyahan ang `0 <= v / 10^(k-n) - d[0..n-1] < 1`.
        // sa kasong ito, ang unang kondisyon ay nagiging `-plus < mant - scale < minus`.
        // mula noong `mant < scale` pagkatapos ng henerasyon, mayroon kaming `scale < mant + plus`.
        // (muli, ito ay nagiging `scale <= mant + plus` kapag ang orihinal na mantissa ay pantay.)
        //
        // sa maikling salita:
        // - itigil at bilugan ang `down` (panatilihin ang mga digit bilang ay) kapag `mant < minus` (o `<=`).
        // - itigil at bilugan ang `up` (taasan ang huling digit) kapag `scale < mant + plus` (o `<=`).
        // - patuloy na bumuo ng kung hindi man.
        //
        //
        //
        down = mant.cmp(&minus) < rounding;
        up = scale.cmp(mant.clone().add(&plus)) < rounding;
        if down || up {
            break;
        } // mayroon kaming pinakamaikling representasyon, magpatuloy sa pag-ikot

        // ibalik ang mga invariants.
        // Ginagawa nitong laging wakas ang algorithm: Laging nagdaragdag ang `minus` at `plus`, ngunit ang `mant` ay na-clip na modulo `scale` at ang `scale` ay naayos.
        //
        mant.mul_small(10);
        minus.mul_small(10);
        plus.mul_small(10);
    }

    // nangyayari ang pag-ikot kapag i) ang kalagayan lamang sa pag-ikot ang na-trigger, o ii) ang parehong mga kundisyon ay na-trigger at ang paggapos ng kurbatang ginusto ang pag-ikot.
    //
    //
    if up && (!down || *mant.mul_pow2(1) >= scale) {
        // kung binabago ng pag-ikot ang haba, dapat ding magbago ang exponent.
        // tila ang kondisyong ito ay napakahirap masiyahan (posibleng imposible), ngunit ligtas at pare-pareho lamang kami dito.
        //
        // KALIGTASAN: sinimulan namin ang memorya na iyon sa itaas.
        if let Some(c) = round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) }) {
            buf[i] = MaybeUninit::new(c);
            i += 1;
            k += 1;
        }
    }

    // KALIGTASAN: sinimulan namin ang memorya na iyon sa itaas.
    (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..i]) }, k)
}

/// Ang eksaktong at naayos na pagpapatupad ng mode para sa Dragon.
pub fn format_exact<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());

    // tantyahin ang `k_0` mula sa orihinal na mga input na nagbibigay-kasiyahan sa `10^(k_0-1) < v <= 10^(k_0+1)`.
    let mut k = estimate_scaling_factor(d.mant, d.exp);

    // `v = mant / scale`.
    let mut mant = Big::from_u64(d.mant);
    let mut scale = Big::from_small(1);
    if d.exp < 0 {
        scale.mul_pow2(-d.exp as usize);
    } else {
        mant.mul_pow2(d.exp as usize);
    }

    // hatiin ang `mant` ng `10^k`.ngayon `scale / 10 < mant <= scale * 10`.
    if k >= 0 {
        mul_pow10(&mut scale, k as usize);
    } else {
        mul_pow10(&mut mant, -k as usize);
    }

    // pag-aayos kapag `mant + plus >= scale`, kung saan `plus / scale = 10^-buf.len() / 2`.
    // upang mapanatili ang naayos na laki ng bignum, talagang ginagamit namin ang `mant + floor(plus) >= scale`.
    // hindi namin talaga binabago ang `scale`, dahil maaari naming laktawan sa halip ang paunang pagpaparami.
    // muli sa pinakamaikling algorithm, ang `d[0]` ay maaaring zero ngunit sa huli ay maikot.
    if *div_2pow10(&mut scale.clone(), buf.len()).add(&mant) >= scale {
        // katumbas ng pag-scale ng `scale` ng 10
        k += 1;
    } else {
        mant.mul_small(10);
    }

    // kung nagtatrabaho kami sa huling-digit na limitasyon, kailangan naming paikliin ang buffer bago ang aktwal na pag-render upang maiwasan ang dobleng pag-ikot.
    //
    // tandaan na kailangan nating palakihin muli ang buffer kapag nangyari ang pag-ikot!
    let mut len = if k < limit {
        // oops, hindi kami makagawa ng *isang* digit.
        // posible ito kapag, sabihin natin, mayroon kaming isang bagay tulad ng 9.5 at binubuo ito sa 10.
        // ibabalik namin ang isang walang laman na buffer, na may pagbubukod sa susunod na pag-ikot na kaso na nangyayari kapag `k == limit` at kailangang makabuo ng eksaktong isang digit.
        //
        0
    } else if ((k as i32 - limit as i32) as usize) < buf.len() {
        (k - limit) as usize
    } else {
        buf.len()
    };

    if len > 0 {
        // cache `(2, 4, 8) * scale` para sa pagbuo ng digit.
        // (maaari itong maging mahal, kaya huwag kalkulahin ang mga ito kapag ang buffer ay walang laman.)
        let mut scale2 = scale.clone();
        scale2.mul_pow2(1);
        let mut scale4 = scale.clone();
        scale4.mul_pow2(2);
        let mut scale8 = scale.clone();
        scale8.mul_pow2(3);

        for i in 0..len {
            if mant.is_zero() {
                // ang mga sumusunod na digit ay lahat ng zero, humihinto kami dito huwag *huwag* subukang magsagawa ng pag-ikot!sa halip, punan ang natitirang mga digit.
                //
                for c in &mut buf[i..len] {
                    *c = MaybeUninit::new(b'0');
                }
                // KALIGTASAN: sinimulan namin ang memorya na iyon sa itaas.
                return (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, k);
            }

            let mut d = 0;
            if mant >= scale8 {
                mant.sub(&scale8);
                d += 8;
            }
            if mant >= scale4 {
                mant.sub(&scale4);
                d += 4;
            }
            if mant >= scale2 {
                mant.sub(&scale2);
                d += 2;
            }
            if mant >= scale {
                mant.sub(&scale);
                d += 1;
            }
            debug_assert!(mant < scale);
            debug_assert!(d < 10);
            buf[i] = MaybeUninit::new(b'0' + d);
            mant.mul_small(10);
        }
    }

    // pag-ikot kung huminto kami sa gitna ng mga digit kung ang mga sumusunod na digit ay eksaktong 5000 ..., suriin ang naunang digit at subukang bilugan sa pantay (ibig sabihin, iwasan ang pag-ikot kapag pantay ang naunang digit).
    //
    //
    let order = mant.cmp(scale.mul_small(5));
    if order == Ordering::Greater
        || (order == Ordering::Equal
            // KALIGTASAN: Ang `buf[len-1]` ay naisasimula.
            && (len == 0 || unsafe { buf[len - 1].assume_init() } & 1 == 1))
    {
        // kung binabago ng pag-ikot ang haba, dapat ding magbago ang exponent.
        // ngunit hiniling sa amin ang isang nakapirming bilang ng mga digit, kaya huwag baguhin ang buffer ...
        // KALIGTASAN: sinimulan namin ang memorya na iyon sa itaas.
        if let Some(c) = round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..len]) }) {
            // ... maliban kung hiniling namin sa halip ang naayos na katumpakan.
            // kailangan din naming suriin iyon, kung ang orihinal na buffer ay walang laman, ang karagdagang digit ay maaari lamang idagdag kapag `k == limit` (edge case).
            //
            k += 1;
            if k > limit && len < buf.len() {
                buf[len] = MaybeUninit::new(c);
                len += 1;
            }
        }
    }

    // KALIGTASAN: sinimulan namin ang memorya na iyon sa itaas.
    (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, k)
}