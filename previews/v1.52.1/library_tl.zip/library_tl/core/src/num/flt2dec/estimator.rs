//! Ang exponent estimator.

/// Nakahanap ng `k_0` tulad ng `10^(k_0-1) < mant * 2^exp <= 10^(k_0+1)`.
///
/// Ginagamit ito upang matantya ang `k = ceil(log_10 (mant * 2^exp))`;
/// ang totoong `k` ay alinman sa `k_0` o `k_0+1`.
#[doc(hidden)]
pub fn estimate_scaling_factor(mant: u64, exp: i16) -> i16 {
    // 2 ^ (nbits-1) <mant <=2 ^ nbits kung mant> 0
    let nbits = 64 - (mant - 1).leading_zeros() as i64;
    // 1292913986= floor(2^32 * log_10 2) samakatuwid ito ay laging minamaliit (o eksaktong), ngunit hindi gaanong.
    //
    (((nbits + exp as i64) * 1292913986) >> 32) as i16
}