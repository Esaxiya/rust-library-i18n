//! Na-decode ang isang lumulutang-point na halaga sa mga indibidwal na bahagi at mga saklaw ng error.

use crate::num::dec2flt::rawfp::RawFloat;
use crate::num::FpCategory;

/// Na-decode ang unsigned na may hangganan na halaga, tulad ng:
///
/// - Ang orihinal na halaga ay katumbas ng `mant * 2^exp`.
///
/// - Anumang numero mula `(mant - minus)*2^exp` hanggang `(mant + plus)* 2^exp` ay bilog sa orihinal na halaga.
/// Ang saklaw ay kasama lamang kapag `inclusive` ay `true`.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct Decoded {
    /// Ang sinukat na mantissa.
    pub mant: u64,
    /// Ang saklaw ng mas mababang error.
    pub minus: u64,
    /// Ang saklaw ng itaas na error.
    pub plus: u64,
    /// Ang ibinahaging exponent sa base 2.
    pub exp: i16,
    /// Totoo kapag kasama ang saklaw ng error.
    ///
    /// Sa IEEE 754, totoo ito kapag pantay ang orihinal na mantissa.
    pub inclusive: bool,
}

/// Na-decode ang hindi naka-sign na halaga.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub enum FullDecoded {
    /// Not-a-number.
    Nan,
    /// Infinities, alinman sa positibo o negatibo.
    Infinite,
    /// Zero, positibo man o negatibo.
    Zero,
    /// May hangganang mga numero na may karagdagang naka-decode na mga patlang.
    Finite(Decoded),
}

/// Isang uri ng lumulutang na punto na maaaring `i-decode`d.
pub trait DecodableFloat: RawFloat + Copy {
    /// Ang minimum na positibong normalized na halaga.
    fn min_pos_norm_value() -> Self;
}

impl DecodableFloat for f32 {
    fn min_pos_norm_value() -> Self {
        f32::MIN_POSITIVE
    }
}

impl DecodableFloat for f64 {
    fn min_pos_norm_value() -> Self {
        f64::MIN_POSITIVE
    }
}

/// Nagbabalik ng isang sign (totoo kapag negatibo) at `FullDecoded` na halaga mula sa ibinigay na lumulutang na numero ng point.
///
pub fn decode<T: DecodableFloat>(v: T) -> (/*negative?*/ bool, FullDecoded) {
    let (mant, exp, sign) = v.integer_decode();
    let even = (mant & 1) == 0;
    let decoded = match v.classify() {
        FpCategory::Nan => FullDecoded::Nan,
        FpCategory::Infinite => FullDecoded::Infinite,
        FpCategory::Zero => FullDecoded::Zero,
        FpCategory::Subnormal => {
            // kapitbahay: (mant, 2, exp)-(mant, exp)-(mant + 2, exp)
            // Float::integer_decode laging pinapanatili ang exponent, kaya ang mantissa ay nasukat para sa mga subnormal.
            //
            FullDecoded::Finite(Decoded { mant, minus: 1, plus: 1, exp, inclusive: even })
        }
        FpCategory::Normal => {
            let minnorm = <T as DecodableFloat>::min_pos_norm_value().integer_decode();
            if mant == minnorm.0 {
                // kapitbahay: (maxmant, exp, 1)-(minnormmant, exp)-(minnormmant + 1, exp)
                // kung saan ang maxmant=minnormmant * 2, 1
                FullDecoded::Finite(Decoded {
                    mant: mant << 2,
                    minus: 1,
                    plus: 2,
                    exp: exp - 2,
                    inclusive: even,
                })
            } else {
                // kapitbahay: (mant, 1, exp)-(mant, exp)-(mant + 1, exp)
                FullDecoded::Finite(Decoded {
                    mant: mant << 1,
                    minus: 1,
                    plus: 1,
                    exp: exp - 1,
                    inclusive: even,
                })
            }
        }
    };
    (sign < 0, decoded)
}