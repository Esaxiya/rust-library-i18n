//! Ang pag-aangkop ng Rust ng Grisu3 algorithm na inilarawan sa "Pag-print ng Mga Numero ng Floating-Point nang Mabilis at tumpak sa mga Integer" [^ 1].
//! Gumagamit ito ng tungkol sa 1KB ng precomputadong talahanayan, at sa turn, ito ay napakabilis para sa karamihan ng mga input.
//!
//! [^1]: Florian Loitsch.2010. Mabilis na pag-print ng mga numero ng lumulutang-point at
//!   tumpak na may mga integer.SIGPLAN Hindi.45, 6 (Hunyo 2010), 233-243.
//!

use crate::mem::MaybeUninit;
use crate::num::diy_float::Fp;
use crate::num::flt2dec::{round_up, Decoded, MAX_SIG_DIGITS};

// tingnan ang mga komento sa `format_shortest_opt` para sa katwiran.
#[doc(hidden)]
pub const ALPHA: i16 = -60;
#[doc(hidden)]
pub const GAMMA: i16 = -32;

/*
# the following Python code generates this table:
for i in xrange(-308, 333, 8):
    if i >= 0: f = 10**i; e = 0
    else: f = 2**(80-4*i) // 10 **-i;e=4* i, 80
    l = f.bit_length()
    f = ((f << 64 >> (l-1)) + 1) >> 1; e += l - 64
    print '    (%#018x, %5d, %4d),' % (f, e, i)
*/

#[doc(hidden)]
pub static CACHED_POW10: [(u64, i16, i16); 81] = [
    // (f, e, k)
    (0xe61acf033d1a45df, -1087, -308),
    (0xab70fe17c79ac6ca, -1060, -300),
    (0xff77b1fcbebcdc4f, -1034, -292),
    (0xbe5691ef416bd60c, -1007, -284),
    (0x8dd01fad907ffc3c, -980, -276),
    (0xd3515c2831559a83, -954, -268),
    (0x9d71ac8fada6c9b5, -927, -260),
    (0xea9c227723ee8bcb, -901, -252),
    (0xaecc49914078536d, -874, -244),
    (0x823c12795db6ce57, -847, -236),
    (0xc21094364dfb5637, -821, -228),
    (0x9096ea6f3848984f, -794, -220),
    (0xd77485cb25823ac7, -768, -212),
    (0xa086cfcd97bf97f4, -741, -204),
    (0xef340a98172aace5, -715, -196),
    (0xb23867fb2a35b28e, -688, -188),
    (0x84c8d4dfd2c63f3b, -661, -180),
    (0xc5dd44271ad3cdba, -635, -172),
    (0x936b9fcebb25c996, -608, -164),
    (0xdbac6c247d62a584, -582, -156),
    (0xa3ab66580d5fdaf6, -555, -148),
    (0xf3e2f893dec3f126, -529, -140),
    (0xb5b5ada8aaff80b8, -502, -132),
    (0x87625f056c7c4a8b, -475, -124),
    (0xc9bcff6034c13053, -449, -116),
    (0x964e858c91ba2655, -422, -108),
    (0xdff9772470297ebd, -396, -100),
    (0xa6dfbd9fb8e5b88f, -369, -92),
    (0xf8a95fcf88747d94, -343, -84),
    (0xb94470938fa89bcf, -316, -76),
    (0x8a08f0f8bf0f156b, -289, -68),
    (0xcdb02555653131b6, -263, -60),
    (0x993fe2c6d07b7fac, -236, -52),
    (0xe45c10c42a2b3b06, -210, -44),
    (0xaa242499697392d3, -183, -36),
    (0xfd87b5f28300ca0e, -157, -28),
    (0xbce5086492111aeb, -130, -20),
    (0x8cbccc096f5088cc, -103, -12),
    (0xd1b71758e219652c, -77, -4),
    (0x9c40000000000000, -50, 4),
    (0xe8d4a51000000000, -24, 12),
    (0xad78ebc5ac620000, 3, 20),
    (0x813f3978f8940984, 30, 28),
    (0xc097ce7bc90715b3, 56, 36),
    (0x8f7e32ce7bea5c70, 83, 44),
    (0xd5d238a4abe98068, 109, 52),
    (0x9f4f2726179a2245, 136, 60),
    (0xed63a231d4c4fb27, 162, 68),
    (0xb0de65388cc8ada8, 189, 76),
    (0x83c7088e1aab65db, 216, 84),
    (0xc45d1df942711d9a, 242, 92),
    (0x924d692ca61be758, 269, 100),
    (0xda01ee641a708dea, 295, 108),
    (0xa26da3999aef774a, 322, 116),
    (0xf209787bb47d6b85, 348, 124),
    (0xb454e4a179dd1877, 375, 132),
    (0x865b86925b9bc5c2, 402, 140),
    (0xc83553c5c8965d3d, 428, 148),
    (0x952ab45cfa97a0b3, 455, 156),
    (0xde469fbd99a05fe3, 481, 164),
    (0xa59bc234db398c25, 508, 172),
    (0xf6c69a72a3989f5c, 534, 180),
    (0xb7dcbf5354e9bece, 561, 188),
    (0x88fcf317f22241e2, 588, 196),
    (0xcc20ce9bd35c78a5, 614, 204),
    (0x98165af37b2153df, 641, 212),
    (0xe2a0b5dc971f303a, 667, 220),
    (0xa8d9d1535ce3b396, 694, 228),
    (0xfb9b7cd9a4a7443c, 720, 236),
    (0xbb764c4ca7a44410, 747, 244),
    (0x8bab8eefb6409c1a, 774, 252),
    (0xd01fef10a657842c, 800, 260),
    (0x9b10a4e5e9913129, 827, 268),
    (0xe7109bfba19c0c9d, 853, 276),
    (0xac2820d9623bf429, 880, 284),
    (0x80444b5e7aa7cf85, 907, 292),
    (0xbf21e44003acdd2d, 933, 300),
    (0x8e679c2f5e44ff8f, 960, 308),
    (0xd433179d9c8cb841, 986, 316),
    (0x9e19db92b4e31ba9, 1013, 324),
    (0xeb96bf6ebadf77d9, 1039, 332),
];

#[doc(hidden)]
pub const CACHED_POW10_FIRST_E: i16 = -1087;
#[doc(hidden)]
pub const CACHED_POW10_LAST_E: i16 = 1039;

#[doc(hidden)]
pub fn cached_power(alpha: i16, gamma: i16) -> (i16, Fp) {
    let offset = CACHED_POW10_FIRST_E as i32;
    let range = (CACHED_POW10.len() as i32) - 1;
    let domain = (CACHED_POW10_LAST_E - CACHED_POW10_FIRST_E) as i32;
    let idx = ((gamma as i32) - offset) * range / domain;
    let (f, e, k) = CACHED_POW10[idx as usize];
    debug_assert!(alpha <= e && e <= gamma);
    (k, Fp { f, e })
}

/// Dahil sa `x > 0`, ibabalik ang `(k, 10^k)` tulad ng `10^k <= x < 10^(k+1)`.
#[doc(hidden)]
pub fn max_pow10_no_more_than(x: u32) -> (u8, u32) {
    debug_assert!(x > 0);

    const X9: u32 = 10_0000_0000;
    const X8: u32 = 1_0000_0000;
    const X7: u32 = 1000_0000;
    const X6: u32 = 100_0000;
    const X5: u32 = 10_0000;
    const X4: u32 = 1_0000;
    const X3: u32 = 1000;
    const X2: u32 = 100;
    const X1: u32 = 10;

    if x < X4 {
        if x < X2 {
            if x < X1 { (0, 1) } else { (1, X1) }
        } else {
            if x < X3 { (2, X2) } else { (3, X3) }
        }
    } else {
        if x < X6 {
            if x < X5 { (4, X4) } else { (5, X5) }
        } else if x < X8 {
            if x < X7 { (6, X6) } else { (7, X7) }
        } else {
            if x < X9 { (8, X8) } else { (9, X9) }
        }
    }
}

/// Ang pinakamaikling pagpapatupad ng mode para sa Grisu.
///
/// Ibinabalik nito ang `None` kapag ibabalik nito ang isang hindi eksaktong representasyon kung hindi man.
pub fn format_shortest_opt<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> Option<(/*digits*/ &'a [u8], /*exp*/ i16)> {
    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());
    assert!(buf.len() >= MAX_SIG_DIGITS);
    assert!(d.mant + d.plus < (1 << 61)); // kailangan namin ng hindi bababa sa tatlong piraso ng karagdagang katumpakan

    // magsimula sa na-normalize na mga halaga sa ibinahaging exponent
    let plus = Fp { f: d.mant + d.plus, e: d.exp }.normalize();
    let minus = Fp { f: d.mant - d.minus, e: d.exp }.normalize_to(plus.e);
    let v = Fp { f: d.mant, e: d.exp }.normalize_to(plus.e);

    // hanapin ang anumang `cached = 10^minusk` tulad ng `ALPHA <= minusk + plus.e + 64 <= GAMMA`.
    // dahil ang `plus` ay na-normalize, nangangahulugan ito ng `2^(62 + ALPHA) <= plus * cached < 2^(64 + GAMMA)`;
    // ibinigay ang aming mga pagpipilian ng `ALPHA` at `GAMMA`, inilalagay nito ang `plus * cached` sa `[4, 2^32)`.
    //
    // malinaw na kanais-nais na i-maximize ang `GAMMA - ALPHA`, upang hindi namin kailangan ng maraming mga naka-cache na kapangyarihan na 10, ngunit may ilang mga pagsasaalang-alang:
    //
    //
    // 1. nais naming panatilihin ang `floor(plus * cached)` sa loob ng `u32` dahil kailangan nito ng isang mamahaling paghahati.
    //    (hindi talaga ito maiiwasan, kailangan ng natitira para sa pagtantiya ng kawastuhan.)
    // 2.
    // ang natitirang `floor(plus * cached)` ay paulit-ulit na nadagdagan ng 10, at hindi ito dapat mag-overflow.
    //
    // ang una ay nagbibigay ng `64 + GAMMA <= 32`, habang ang pangalawa ay nagbibigay ng `10 * 2^-ALPHA <= 2^64`;
    // -60 at -32 ay ang pinakamataas na saklaw na may hadlang na ito, at ginagamit din ng V8 ang mga ito.
    let (minusk, cached) = cached_power(ALPHA - plus.e - 64, GAMMA - plus.e - 64);

    // scale fps.nagbibigay ito ng pinakamataas na error ng 1 ulp (napatunayan mula sa Theorem 5.1).
    let plus = plus.mul(&cached);
    let minus = minus.mul(&cached);
    let v = v.mul(&cached);
    debug_assert_eq!(plus.e, minus.e);
    debug_assert_eq!(plus.e, v.e);

    // +-aktwal na saklaw ng minus
    //   | <---|---------------------- unsafe region --------------------------> |
    //   |     |                                                                 |
    //   |  |<--->|  | <--------------- safe region ---------------> |           |
    //   |  |     |  |                                               |           |
    //   | 1 ulp | 1 ulp || 1 ulp | 1 ulp || 1 ulp | 1 ulp |
    //   |<--->|<--->|                 |<--->|<--->|                 |<--->|<--->|
    //   |-----|-----|-------...-------|-----|-----|-------...-------|-----|-----|
    //   |   minus   |                 |     v     |                 |   plus    | minus1     minus0           v - 1 ulp   v + 1 ulp           plus0       plus1
    //
    //
    // sa itaas ng `minus`, `v` at `plus` ay *tinatantiya* na mga pagtatantya (error <1 ulp).
    // dahil hindi namin alam na ang error ay positibo o negatibo, gumagamit kami ng dalawang mga approximations spaced pantay at mayroong maximum na error ng 2 ulps.
    //
    // ang "unsafe region" ay isang liberal interval na una naming nabuo.
    // ang "safe region" ay isang konserbatibong agwat na tatanggapin lamang namin.
    // nagsisimula kami sa tamang repr sa loob ng hindi ligtas na rehiyon, at subukang hanapin ang pinakamalapit na repr sa `v` na nasa loob din ng ligtas na rehiyon.
    // kung hindi natin kaya, sumuko na tayo.
    //
    let plus1 = plus.f + 1;
    // hayaan ang plus0 = plus.f, 1;//para lamang sa paliwanag hayaan minus0 = minus.f + 1;//para lamang sa paliwanag
    //
    let minus1 = minus.f - 1;
    let e = -plus.e as usize; // ibinahaging tagataguyod

    // hatiin ang `plus1` sa mga integral at praksyonal na bahagi.
    // Ang mga integral na bahagi ay ginagarantiyahan na magkasya sa u32, dahil ang cache ng kapangyarihan ay ginagarantiyahan ang `plus < 2^32` at ang na-normalize na `plus.f` ay palaging mas mababa sa `2^64 - 2^4` dahil sa eksaktong kinakailangan.
    //
    let plus1int = (plus1 >> e) as u32;
    let plus1frac = plus1 & ((1 << e) - 1);

    // kalkulahin ang pinakamalaking `10^max_kappa` hindi hihigit sa `plus1` (kaya't `plus1 < 10^(max_kappa+1)`).
    // ito ay isang itaas na hangganan ng `kappa` sa ibaba.
    let (max_kappa, max_ten_kappa) = max_pow10_no_more_than(plus1int);

    let mut i = 0;
    let exp = max_kappa as i16 - minusk + 1;

    // Theorem 6.2: kung `k` ang pinakadakilang integer st
    // `0 <= y mod 10^k <= y - x`,              pagkatapos ang `V = floor(y / 10^k) * 10^k` ay nasa `[x, y]` at isa sa pinakamaikling representasyon (na may kaunting bilang ng mga makabuluhang digit) sa saklaw na iyon.
    //
    //
    // hanapin ang haba ng digit na `kappa` sa pagitan ng `(minus1, plus1)` ayon sa bawat Theorem 6.2.
    // Maaaring gamitin ang teorema 6.2 upang maibukod ang `x` sa pamamagitan ng paghiling sa halip ng `y mod 10^k < y - x`.
    // (hal., `x` =32000, `y` =32777; `kappa` =2 mula noong `y mod 10 ^ 3=777 <y, x=777`.) Ang algorithm ay umaasa sa susunod na yugto ng pag-verify upang maibukod ang `y`.
    //
    let delta1 = plus1 - minus1;
    // hayaan ang delta1int=(delta1>> e) bilang paggamit;//para lamang sa paliwanag
    let delta1frac = delta1 & ((1 << e) - 1);

    // mag-render ng mga mahalagang bahagi, habang sinusuri ang kawastuhan sa bawat hakbang.
    let mut kappa = max_kappa as i16;
    let mut ten_kappa = max_ten_kappa; // 10^kappa
    let mut remainder = plus1int; // ang mga digit ay maibigay pa
    loop {
        // palagi kaming may hindi bababa sa isang digit na mai-render, bilang `plus1 >= 10^kappa` invariants:
        // - `delta1int <= remainder < 10^(kappa+1)`
        // - `plus1int = d[0..n-1] * 10^(kappa+1) + remainder`   (sumusunod ito sa `remainder = plus1int % 10^(kappa+1)`)
        //
        //

        // hatiin ang `remainder` ng `10^kappa`.pareho ay nasukat ng `2^-e`.
        let q = remainder / ten_kappa;
        let r = remainder % ten_kappa;
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        let plus1rem = ((r as u64) << e) + plus1frac; // ==(plus1% 10 ^ kappa) * 2 ^ e
        if plus1rem < delta1 {
            // `plus1 % 10^kappa < delta1 = plus1 - minus1`; nahanap namin ang tamang `kappa`.
            let ten_kappa = (ten_kappa as u64) << e; // scale 10 ^ kappa pabalik sa ibinahaging exponent
            return round_and_weed(
                // KALIGTASAN: sinimulan namin ang memorya na iyon sa itaas.
                unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) },
                exp,
                plus1rem,
                delta1,
                plus1 - v.f,
                ten_kappa,
                1,
            );
        }

        // basagin ang loop kapag na-render namin ang lahat ng mga integral na digit.
        // ang eksaktong bilang ng mga digit ay `max_kappa + 1` bilang `plus1 < 10^(max_kappa+1)`.
        if i > max_kappa as usize {
            debug_assert_eq!(ten_kappa, 1);
            debug_assert_eq!(kappa, 0);
            break;
        }

        // ibalik ang mga invariant
        kappa -= 1;
        ten_kappa /= 10;
        remainder = r;
    }

    // mag-render ng mga praksyonal na bahagi, habang sinusuri ang kawastuhan sa bawat hakbang.
    // sa oras na ito ay umaasa kami sa paulit-ulit na pagpaparami, dahil ang paghati ay mawawalan ng katumpakan.
    let mut remainder = plus1frac;
    let mut threshold = delta1frac;
    let mut ulp = 1;
    loop {
        // ang susunod na digit ay dapat na makabuluhan habang nasubukan namin iyon bago paghiwalayin ang mga invariant, kung saan ang `m = max_kappa + 1` (#ng mga digit sa mahalagang bahagi):
        //
        // - `remainder < 2^e`
        // - `plus1frac * 10^(n-m) = d[m..n-1] * 2^e + remainder`

        remainder *= 10; // hindi umaapaw, `2^e * 10 < 2^64`
        threshold *= 10;
        ulp *= 10;

        // hatiin ang `remainder` ng `10^kappa`.
        // kapwa na-scale ng `2^e / 10^kappa`, kaya't ang huli ay implicit dito.
        let q = remainder >> e;
        let r = remainder & ((1 << e) - 1);
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        if r < threshold {
            let ten_kappa = 1 << e; // implicit divisor
            return round_and_weed(
                // KALIGTASAN: sinimulan namin ang memorya na iyon sa itaas.
                unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) },
                exp,
                r,
                threshold,
                (plus1 - v.f) * ulp,
                ten_kappa,
                ulp,
            );
        }

        // ibalik ang mga invariant
        kappa -= 1;
        remainder = r;
    }

    // nakabuo kami ng lahat ng makabuluhang mga digit ng `plus1`, ngunit hindi sigurado kung ito ang pinakamainam.
    // halimbawa, kung ang `minus1` ay 3.14153 ... at ang `plus1` ay 3.14158 ..., mayroong 5 magkakaibang pinakamaikling representasyon mula 3.14154 hanggang 3.14158 ngunit mayroon lamang kaming pinakadakilang isa.
    // kailangan nating sunud-sunod na bawasan ang huling digit at suriin kung ito ang pinakamainam na repr.
    // mayroong higit sa 9 na mga kandidato (..1 hanggang ..9), kaya't ito ay medyo mabilis.("rounding" phase)
    //
    // Sinusuri ng pagpapaandar kung ang "optimal" repr na ito ay nasa loob mismo ng mga saklaw ng ulp, at gayundin, posible na ang "second-to-optimal" repr ay maaaring maging tunay na optimal dahil sa error sa pag-ikot.
    // sa alinmang kaso ibabalik nito ang `None`.
    // ("weeding" phase)
    //
    // ang lahat ng mga argumento dito ay nasukat ng karaniwang (ngunit implicit) na halagang `k`, upang:
    // - `remainder = (plus1 % 10^kappa) * k`
    // - `threshold = (plus1 - minus1) * k` (at gayundin, `remainder < threshold`)
    // - `plus1v = (plus1 - v) * k` (at gayundin, `threshold > plus1v` mula sa mga naunang invariant)
    // - `ten_kappa = 10^kappa * k`
    // - `ulp = 2^-e * k`
    //
    fn round_and_weed(
        buf: &mut [u8],
        exp: i16,
        remainder: u64,
        threshold: u64,
        plus1v: u64,
        ten_kappa: u64,
        ulp: u64,
    ) -> Option<(&[u8], i16)> {
        assert!(!buf.is_empty());

        // gumawa ng dalawang mga approximations sa `v` (talagang `plus1 - v`) sa loob ng 1.5 ulps.
        // ang nagresultang representasyon ay dapat na ang pinakamalapit na representasyon sa pareho.
        //
        // dito ay ginagamit ang `plus1 - v` dahil ang mga kalkulasyon ay ginagawa na may paggalang sa `plus1` upang maiwasan ang overflow/underflow (samakatuwid ay ang mga tila palitan na pangalan).
        //
        let plus1v_down = plus1v + ulp; // plus1 - (v, 1 ulp)
        let plus1v_up = plus1v - ulp; // plus1 - (v + 1 ulp)

        // bawasan ang huling digit at huminto sa pinakamalapit na representasyon sa `v + 1 ulp`.
        let mut plus1w = remainder; // plus1w(n) = plus1, w(n)
        {
            let last = buf.last_mut().unwrap();

            // nagtatrabaho kami sa tinatayang mga digit na `w(n)`, na una ay katumbas ng `plus1 - plus1 % 10^kappa`.pagkatapos patakbuhin ang loop body `n` beses, `w(n) = plus1 - plus1 % 10^kappa - n * 10^kappa`.
            // itinakda namin ang `plus1w(n) = plus1 - w(n) = plus1 % 10^kappa + n * 10^kappa` (kaya `natitira= plus1w(0)`) upang gawing simple ang mga tseke.
            // tandaan na ang `plus1w(n)` ay palaging pagtaas.
            //
            // mayroon kaming tatlong mga kundisyon upang wakasan.alinman sa mga ito ay gagawing hindi makapagpatuloy ang loop, ngunit mayroon kaming kahit isang wastong representasyon na alam na pinakamalapit pa rin sa `v + 1 ulp`.
            // ipakilala namin ang mga ito bilang TC1 sa pamamagitan ng TC3 para sa kabutihan.
            //
            // TC1: `w(n) <= v + 1 ulp`, ibig sabihin, ito ang huling repr na maaaring maging ang pinakamalapit.
            // katumbas ito ng `plus1 - w(n) = plus1w(n) >= plus1 - (v + 1 ulp) = plus1v_up`.
            // isinama sa TC2 (kung aling mga tseke kung `w(n+1)` is valid), pinipigilan nito ang posibleng pag-overflow sa pagkalkula ng `plus1w(n)`.
            //
            // TC2: `w(n+1) < minus1`, ibig sabihin, ang susunod na repr ay tiyak na hindi bilog sa `v`.
            // katumbas ito ng `plus1 - w(n) + 10^kappa = plus1w(n) + 10^kappa > plus1 - minus1 = threshold`.
            // ang kaliwang bahagi ng kamay ay maaaring mag-overflow, ngunit alam namin ang `threshold > plus1v`, kaya kung ang TC1 ay mali, `threshold - plus1w(n) > threshold - (plus1v - 1 ulp) > 1 ulp` at maaari naming ligtas na subukan kung `threshold - plus1w(n) < 10^kappa` sa halip.
            //
            //
            // TC3: `abs(w(n) - (v + 1 ulp)) <= abs(w(n+1) - (v + 1 ulp))`, ibig sabihin, ang susunod na repr ay
            // walang malapit sa `v + 1 ulp` kaysa sa kasalukuyang repr.
            // ibinigay `z(n) = plus1v_up - plus1w(n)`, ito ay nagiging `abs(z(n)) <= abs(z(n+1))`.sa pag-aakalang muli na ang TC1 ay hindi totoo, mayroon kaming `z(n) > 0`.mayroon kaming dalawang kaso na dapat isaalang-alang:
            //
            // - kapag `z(n+1) >= 0`: TC3 ay nagiging `z(n) <= z(n+1)`.
            // habang dumarami ang `plus1w(n)`, ang `z(n)` ay dapat na bumababa at malinaw na mali ito.
            // - kapag `z(n+1) < 0`:
            //   - TC3a: ang precondition ay `plus1v_up < plus1w(n) + 10^kappa`.sa pag-aakalang TC2 ay hindi totoo, `threshold >= plus1w(n) + 10^kappa` kaya't hindi ito maaaring mag-overflow.
            //   - TC3b: Ang TC3 ay nagiging `z(n) <= -z(n+1)`, ibig sabihin, `plus1v_up - plus1w(n) >=     plus1w(n+1) - plus1v_up = plus1w(n) + 10^kappa - plus1v_up`.
            //   ang tinanggihan na TC1 ay nagbibigay sa `plus1v_up > plus1w(n)`, kaya't hindi ito maaaring mag-overflow o mag-underflow kapag isinama sa TC3a.
            //
            // dahil dito, dapat nating ihinto kapag `TC1 || TC2 || (TC3a && TC3b)`.ang sumusunod ay katumbas ng kabaligtaran nito, `!TC1 && !TC2 && (!TC3a || !TC3b)`.
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            while plus1w < plus1v_up
                && threshold - plus1w >= ten_kappa
                && (plus1w + ten_kappa < plus1v_up
                    || plus1v_up - plus1w >= plus1w + ten_kappa - plus1v_up)
            {
                *last -= 1;
                debug_assert!(*last > b'0'); // ang pinakamaikling repr ay hindi maaaring magtapos sa `0`
                plus1w += ten_kappa;
            }
        }

        // suriin kung ang representasyong ito ay ang pinakamalapit na representasyon din sa `v - 1 ulp`.
        //
        // ito ay pareho lamang sa mga natatapos na kundisyon para sa `v + 1 ulp`, sa lahat ng `plus1v_up` ay pinalitan ng `plus1v_down` sa halip.
        // ang pagtatasa ng overflow ay pantay na humahawak.
        if plus1w < plus1v_down
            && threshold - plus1w >= ten_kappa
            && (plus1w + ten_kappa < plus1v_down
                || plus1v_down - plus1w >= plus1w + ten_kappa - plus1v_down)
        {
            return None;
        }

        // Ngayon mayroon kaming pinakamalapit na representasyon sa `v` sa pagitan ng `plus1` at `minus1`.
        // ito ay masyadong liberal, bagaman, kaya tinanggihan namin ang anumang `w(n)` hindi sa pagitan ng `plus0` at `minus0`, ibig sabihin, `plus1 - plus1w(n) <= minus0` o `plus1 - plus1w(n) >= plus0`.
        // ginagamit namin ang mga katotohanan na `threshold = plus1 - minus1` at `plus1 - plus0 = minus0 - minus1 = 2 ulp`.
        //
        if 2 * ulp <= plus1w && plus1w <= threshold - 4 * ulp { Some((buf, exp)) } else { None }
    }
}

/// Ang pinakamaikling pagpapatupad ng mode para sa Grisu na may fallback ng Dragon.
///
/// Dapat itong gamitin para sa karamihan ng mga kaso.
pub fn format_shortest<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    use crate::num::flt2dec::strategy::dragon::format_shortest as fallback;
    // KALIGTASAN: Ang check check ay hindi sapat na matalino upang ipaalam sa amin na gamitin ang `buf`
    // sa pangalawang branch, kaya't tinutuluyan natin ang buhay dito.
    // Ngunit gagamitin lamang namin ang `buf` kung ibalik ng `format_shortest_opt` ang `None` kaya't okay lang ito.
    match format_shortest_opt(d, unsafe { &mut *(buf as *mut _) }) {
        Some(ret) => ret,
        None => fallback(d, buf),
    }
}

/// Ang eksaktong at naayos na pagpapatupad ng mode para sa Grisu.
///
/// Ibinabalik nito ang `None` kapag ibabalik nito ang isang hindi eksaktong representasyon kung hindi man.
pub fn format_exact_opt<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> Option<(/*digits*/ &'a [u8], /*exp*/ i16)> {
    assert!(d.mant > 0);
    assert!(d.mant < (1 << 61)); // kailangan namin ng hindi bababa sa tatlong piraso ng karagdagang katumpakan
    assert!(!buf.is_empty());

    // gawing normal at sukatin ang `v`.
    let v = Fp { f: d.mant, e: d.exp }.normalize();
    let (minusk, cached) = cached_power(ALPHA - v.e - 64, GAMMA - v.e - 64);
    let v = v.mul(&cached);

    // hatiin ang `v` sa mga integral at praksyonal na bahagi.
    let e = -v.e as usize;
    let vint = (v.f >> e) as u32;
    let vfrac = v.f & ((1 << e) - 1);

    // parehong lumang `v` at bagong `v` (na-scale ng `10^-k`) ay may error na <1 ulp (Theorem 5.1).
    // dahil hindi namin alam na ang error ay positibo o negatibo, gumagamit kami ng dalawang mga approximations spaced pantay at mayroong maximum na error ng 2 ulps (pareho sa pinakamaikling kaso).
    //
    //
    // ang layunin ay upang mahanap ang eksaktong bilugan na serye ng mga digit na karaniwan sa parehong `v - 1 ulp` at `v + 1 ulp`, sa gayon kami ay lubos na may kumpiyansa.
    // kung hindi ito posible, hindi namin alam kung alin ang tamang output para sa `v`, kaya't sumuko kami at babagsak.
    //
    // `err` ay tinukoy bilang `1 ulp * 2^e` dito (pareho sa ulp sa `vfrac`), at sukatin namin ito sa tuwing nai-scale ang `v`.
    //
    //
    //
    let mut err = 1;

    // kalkulahin ang pinakamalaking `10^max_kappa` hindi hihigit sa `v` (kaya't `v < 10^(max_kappa+1)`).
    // ito ay isang itaas na hangganan ng `kappa` sa ibaba.
    let (max_kappa, max_ten_kappa) = max_pow10_no_more_than(vint);

    let mut i = 0;
    let exp = max_kappa as i16 - minusk + 1;

    // kung nagtatrabaho kami sa huling-digit na limitasyon, kailangan naming paikliin ang buffer bago ang aktwal na pag-render upang maiwasan ang dobleng pag-ikot.
    //
    // tandaan na kailangan nating palakihin muli ang buffer kapag nangyari ang pag-ikot!
    let len = if exp <= limit {
        // oops, hindi kami makagawa ng *isang* digit.
        // posible ito kapag, sabihin natin, mayroon kaming isang bagay tulad ng 9.5 at binubuo ito sa 10.
        //
        // sa prinsipyo maaari naming agad na tawagan ang `possibly_round` na may walang laman na buffer, ngunit ang pag-scale ng `max_ten_kappa << e` ng 10 ay maaaring magresulta sa overflow.
        //
        // sa gayon tayo ay palpak dito at pinapalawak ang saklaw ng error sa pamamagitan ng isang factor na 10.
        // tataas nito ang maling rate ng negatibong, ngunit lamang,*napaka* bahagyang;
        // maaari lamang itong maging kapansin-pansin kapag ang mantissa ay mas malaki sa 60 piraso.
        //
        // KALIGTASAN: `len=0`, kaya't ang obligasyon ng pagkakaroon ng gawing pauna sa memorya na ito ay walang halaga.
        return unsafe {
            possibly_round(buf, 0, exp, limit, v.f / 10, (max_ten_kappa as u64) << e, err << e)
        };
    } else if ((exp as i32 - limit as i32) as usize) < buf.len() {
        (exp - limit) as usize
    } else {
        buf.len()
    };
    debug_assert!(len > 0);

    // mag-render ng mga mahalagang bahagi.
    // ang error ay buong praksyonal, kaya't hindi namin kailangang suriin ito sa bahaging ito.
    let mut kappa = max_kappa as i16;
    let mut ten_kappa = max_ten_kappa; // 10^kappa
    let mut remainder = vint; // ang mga digit ay maibigay pa
    loop {
        // palagi kaming mayroong kahit isang digit upang mag-render ng mga invariant:
        // - `remainder < 10^(kappa+1)`
        // - `vint = d[0..n-1] * 10^(kappa+1) + remainder`   (sumusunod ito sa `remainder = vint % 10^(kappa+1)`)
        //
        //

        // hatiin ang `remainder` ng `10^kappa`.pareho ay nasukat ng `2^-e`.
        let q = remainder / ten_kappa;
        let r = remainder % ten_kappa;
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        // puno na ba ang buffer?patakbuhin ang rounding pass kasama ang natitira.
        if i == len {
            let vrem = ((r as u64) << e) + vfrac; // ==(v% 10 ^ kappa) * 2 ^ e
            // KALIGTASAN: nasimulan namin ang `len` maraming mga byte.
            return unsafe {
                possibly_round(buf, len, exp, limit, vrem, (ten_kappa as u64) << e, err << e)
            };
        }

        // basagin ang loop kapag na-render namin ang lahat ng mga integral na digit.
        // ang eksaktong bilang ng mga digit ay `max_kappa + 1` bilang `plus1 < 10^(max_kappa+1)`.
        if i > max_kappa as usize {
            debug_assert_eq!(ten_kappa, 1);
            debug_assert_eq!(kappa, 0);
            break;
        }

        // ibalik ang mga invariant
        kappa -= 1;
        ten_kappa /= 10;
        remainder = r;
    }

    // mag-render ng mga praksyonal na bahagi.
    //
    // sa prinsipyo maaari naming ipagpatuloy ang huling magagamit na digit at suriin para sa kawastuhan.
    // sa kasamaang palad nagtatrabaho kami sa may hangganan na laki na integer, kaya kailangan namin ng ilang pamantayan upang makita ang overflow.
    // V8 gumagamit ng `remainder > err`, na kung saan ay nagiging mali kapag ang unang `i` makabuluhang mga digit ng `v - 1 ulp` at `v` ay magkakaiba.
    // subalit tinatanggihan nito ang masyadong maraming kung hindi man wastong input.
    //
    // dahil ang huling yugto ay may tamang pagtuklas ng overflow, sa halip ay gumagamit kami ng mas mahigpit na pamantayan:
    // nagpatuloy kami hanggang sa lumampas ang `err` sa `10^kappa / 2`, upang ang saklaw sa pagitan ng `v - 1 ulp` at `v + 1 ulp` ay tiyak na naglalaman ng dalawa o higit pang mga bilugan na representasyon.
    //
    // pareho ito sa unang dalawang paghahambing mula sa `possibly_round`, para sa sanggunian.
    //
    let mut remainder = vfrac;
    let maxerr = 1 << (e - 1);
    while err < maxerr {
        // mga invariant, kung saan `m = max_kappa + 1` (#ng mga digit sa mahalagang bahagi):
        // - `remainder < 2^e`
        // - `vfrac * 10^(n-m) = d[m..n-1] * 2^e + remainder`
        // - `err = 10^(n-m)`

        remainder *= 10; // hindi umaapaw, `2^e * 10 < 2^64`
        err *= 10; // hindi umaapaw, `err * 10 < 2^e * 5 < 2^64`

        // hatiin ang `remainder` ng `10^kappa`.
        // kapwa na-scale ng `2^e / 10^kappa`, kaya't ang huli ay implicit dito.
        let q = remainder >> e;
        let r = remainder & ((1 << e) - 1);
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        // puno na ba ang buffer?patakbuhin ang rounding pass kasama ang natitira.
        if i == len {
            // KALIGTASAN: nasimulan namin ang `len` maraming mga byte.
            return unsafe { possibly_round(buf, len, exp, limit, r, 1 << e, err) };
        }

        // ibalik ang mga invariant
        remainder = r;
    }

    // ang karagdagang pagkalkula ay walang silbi (tiyak na nabigo ang `possibly_round`), kaya sumuko kami.
    return None;

    // nalikha namin ang lahat ng hiniling na mga digit ng `v`, na dapat ay pareho sa mga kaukulang numero ng `v - 1 ulp`.
    // ngayon sinusuri namin kung mayroong isang natatanging representasyon na ibinahagi ng parehong `v - 1 ulp` at `v + 1 ulp`;maaari itong maging pareho sa mga nabuong digit, o sa bilugan na bersyon ng mga digit.
    //
    // kung ang saklaw ay naglalaman ng maraming mga representasyon ng parehong haba, hindi kami makatiyak at dapat na ibalik ang `None` sa halip.
    //
    // ang lahat ng mga argumento dito ay nasukat ng karaniwang (ngunit implicit) na halagang `k`, upang:
    // - `remainder = (v % 10^kappa) * k`
    // - `ten_kappa = 10^kappa * k`
    // - `ulp = 2^-e * k`
    //
    // KALIGTASAN: ang unang `len` bytes ng `buf` ay dapat na maisimula.
    //
    unsafe fn possibly_round(
        buf: &mut [MaybeUninit<u8>],
        mut len: usize,
        mut exp: i16,
        limit: i16,
        remainder: u64,
        ten_kappa: u64,
        ulp: u64,
    ) -> Option<(&[u8], i16)> {
        debug_assert!(remainder < ten_kappa);

        // 10^kappa
        //    :   :   :<->:   :
        //    :   :   :   :   :
        //    : | 1 ulp | 1 ulp |:
        //    :|<--->|<--->|  :
        // ----|-----|-----|----
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // (para sa sanggunian, ipinahiwatig ng linya na may tuldok ang eksaktong halaga para sa mga posibleng representasyon sa ibinigay na bilang ng mga digit.)
        //
        //
        // ang error ay masyadong malaki na mayroong hindi bababa sa tatlong posibleng mga representasyon sa pagitan ng `v - 1 ulp` at `v + 1 ulp`.
        // hindi namin matukoy kung alin ang tama.
        //
        if ulp >= ten_kappa {
            return None;
        }

        // 10^kappa
        //   :<------->:
        //   :         :
        //   : | 1 ulp | 1 ulp |
        //   : |<--->|<--->|
        // ----|-----|-----|----
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // sa katunayan, ang 1/2 ulp ay sapat upang ipakilala ang dalawang posibleng representasyon.
        // (tandaan na kailangan namin ng isang natatanging representasyon para sa parehong `v - 1 ulp` at `v + 1 ulp`.) hindi ito umaapaw, tulad ng `ulp < ten_kappa` mula sa unang tseke.
        //
        //
        if ten_kappa - ulp <= ulp {
            return None;
        }

        // remainder
        //       :<->|                           :
        //       :   |                           :
        //       : <---------10 ^ kappa-- -------->:
        //     | :   |                           :
        //     | 1 ulp | 1 ulp |:
        //     |<--->|<--->|                     :
        // ----|-----|-----|------------------------
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // kung ang `v + 1 ulp` ay mas malapit sa bilugan-down na representasyon (na nasa `buf`), sa gayon maaari kaming ligtas na makabalik.
        // tandaan na ang `v - 1 ulp`*ay maaaring* mas mababa sa kasalukuyang representasyon, ngunit bilang `1 ulp < 10^kappa / 2`, sapat ang kondisyong ito:
        // ang distansya sa pagitan ng `v - 1 ulp` at ng kasalukuyang representasyon ay hindi maaaring lumagpas sa `10^kappa / 2`.
        //
        // ang kondisyon ay katumbas ng `remainder + ulp < 10^kappa / 2`.
        // dahil madali itong mag-overflow, suriin muna kung `remainder < 10^kappa / 2`.
        // na-verify na namin na `ulp < 10^kappa / 2`, kaya't hangga't hindi pa umaapaw ang `10^kappa` pagkatapos ng lahat, ang pangalawang tseke ay mabuti.
        //
        //
        //
        //
        if ten_kappa - remainder > remainder && ten_kappa - 2 * remainder >= 2 * ulp {
            // KALIGTASAN: ang aming tumatawag ay nagsimula sa memorya na iyon.
            return Some((unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, exp));
        }

        // : <-------natitira------> |:
        //   :                          |   :
        //   : <---------10 ^ kappa-- ------->:
        //   :                    |     |   : |
        //   : | 1 ulp | 1 ulp |
        //   :                    |<--->|<--->|
        // -----------------------|-----|-----|-----
        //                        |     v     |                    v - 1 ulp   v + 1 ulp
        //
        // sa kabilang banda, kung ang `v - 1 ulp` ay mas malapit sa bilugan na representasyon, dapat tayong bilugan at bumalik.
        // para sa parehong dahilan hindi namin kailangang suriin ang `v + 1 ulp`.
        //
        // ang kondisyon ay katumbas ng `remainder - ulp >= 10^kappa / 2`.
        // muli naming suriin muna kung `remainder > ulp` (tandaan na hindi ito `remainder >= ulp`, dahil ang `10^kappa` ay hindi kailanman zero).
        //
        // tandaan din na `remainder - ulp <= 10^kappa`, kaya't ang pangalawang tseke ay hindi umaapaw.
        //
        if remainder > ulp && ten_kappa - (remainder - ulp) <= remainder - ulp {
            if let Some(c) =
                // KALIGTASAN: ang aming tumatawag ay dapat na nagpasimula ng memorya na iyon.
                round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..len]) })
            {
                // magdagdag lamang ng isang karagdagang digit kapag hiniling sa amin ang naayos na katumpakan.
                // kailangan din naming suriin iyon, kung ang orihinal na buffer ay walang laman, ang karagdagang digit ay maaari lamang idagdag kapag `exp == limit` (edge case).
                //
                exp += 1;
                if exp > limit && len < buf.len() {
                    buf[len] = MaybeUninit::new(c);
                    len += 1;
                }
            }
            // KALIGTASAN: kami at ang aming tumatawag ay nagpasimula ng memorya na iyon.
            return Some((unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, exp));
        }

        // kung hindi man tayo ay tiyak na mapapahamak (ibig sabihin, ang ilang mga halaga sa pagitan ng `v - 1 ulp` at `v + 1 ulp` ay pag-ikot at ang iba ay pag-ikot) at sumuko.
        //
        None
    }
}

/// Ang eksaktong at naayos na pagpapatupad ng mode para sa Grisu na may fallback ng Dragon.
///
/// Dapat itong gamitin para sa karamihan ng mga kaso.
pub fn format_exact<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    use crate::num::flt2dec::strategy::dragon::format_exact as fallback;
    // KALIGTASAN: Ang check check ay hindi sapat na matalino upang ipaalam sa amin na gamitin ang `buf`
    // sa pangalawang branch, kaya't tinutuluyan natin ang buhay dito.
    // Ngunit gagamitin lamang namin ang `buf` kung ibalik ng `format_exact_opt` ang `None` kaya't okay lang ito.
    match format_exact_opt(d, unsafe { &mut *(buf as *mut _) }, limit) {
        Some(ret) => ret,
        None => fallback(d, buf, limit),
    }
}