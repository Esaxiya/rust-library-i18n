//! Ang libcore prelude
//!
//! Ang module na ito ay inilaan para sa mga gumagamit ng libcore na hindi naka-link sa libstd din.
//! Ang modyul na ito ay na-import bilang default kapag ang `#![no_std]` ay ginagamit sa parehong pamamaraan tulad ng prelude ng karaniwang silid-aklatan.
//!

#![stable(feature = "core_prelude", since = "1.4.0")]

pub mod v1;

/// Ang 2015 na bersyon ng pangunahing prelude.
///
/// Tingnan ang [module-level documentation](self) para sa higit pa.
#[unstable(feature = "prelude_2015", issue = "none")]
pub mod rust_2015 {
    #[unstable(feature = "prelude_2015", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// Ang bersyon ng 2018 ng pangunahing prelude.
///
/// Tingnan ang [module-level documentation](self) para sa higit pa.
#[unstable(feature = "prelude_2018", issue = "none")]
pub mod rust_2018 {
    #[unstable(feature = "prelude_2018", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// Ang 2021 na bersyon ng pangunahing prelude.
///
/// Tingnan ang [module-level documentation](self) para sa higit pa.
#[unstable(feature = "prelude_2021", issue = "none")]
pub mod rust_2021 {
    #[unstable(feature = "prelude_2021", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;

    // FIXME: Magdagdag ng maraming bagay.
}