//! Suporta ng Panic sa karaniwang silid-aklatan.

#![stable(feature = "core_panic_info", since = "1.41.0")]

use crate::any::Any;
use crate::fmt;

#[doc(hidden)]
#[unstable(feature = "edition_panic", issue = "none", reason = "use panic!() instead")]
#[allow_internal_unstable(core_panic)]
#[rustc_diagnostic_item = "core_panic_2015_macro"]
#[rustc_macro_transparency = "semitransparent"]
pub macro panic_2015 {
    () => (
        $crate::panicking::panic("explicit panic")
    ),
    ($msg:literal $(,)?) => (
        $crate::panicking::panic($msg)
    ),
    ($msg:expr $(,)?) => (
        $crate::panicking::panic_str($msg)
    ),
    ($fmt:expr, $($arg:tt)+) => (
        $crate::panicking::panic_fmt($crate::format_args!($fmt, $($arg)+))
    ),
}

#[doc(hidden)]
#[unstable(feature = "edition_panic", issue = "none", reason = "use panic!() instead")]
#[allow_internal_unstable(core_panic)]
#[rustc_diagnostic_item = "core_panic_2021_macro"]
#[rustc_macro_transparency = "semitransparent"]
pub macro panic_2021 {
    () => (
        $crate::panicking::panic("explicit panic")
    ),
    ($($t:tt)+) => (
        $crate::panicking::panic_fmt($crate::format_args!($($t)+))
    ),
}

/// Isang istruktura na nagbibigay ng impormasyon tungkol sa isang panic.
///
/// `PanicInfo` ang istraktura ay naipasa sa isang panic hook na itinakda ng pagpapaandar ng [`set_hook`].
///
///
/// [`set_hook`]: ../../std/panic/fn.set_hook.html
///
/// # Examples
///
/// ```should_panic
/// use std::panic;
///
/// panic::set_hook(Box::new(|panic_info| {
///     if let Some(s) = panic_info.payload().downcast_ref::<&str>() {
///         println!("panic occurred: {:?}", s);
///     } else {
///         println!("panic occurred");
///     }
/// }));
///
/// panic!("Normal panic");
/// ```
#[lang = "panic_info"]
#[stable(feature = "panic_hooks", since = "1.10.0")]
#[derive(Debug)]
pub struct PanicInfo<'a> {
    payload: &'a (dyn Any + Send),
    message: Option<&'a fmt::Arguments<'a>>,
    location: &'a Location<'a>,
}

impl<'a> PanicInfo<'a> {
    #[unstable(
        feature = "panic_internals",
        reason = "internal details of the implementation of the `panic!` and related macros",
        issue = "none"
    )]
    #[doc(hidden)]
    #[inline]
    pub fn internal_constructor(
        message: Option<&'a fmt::Arguments<'a>>,
        location: &'a Location<'a>,
    ) -> Self {
        struct NoPayload;
        PanicInfo { location, message, payload: &NoPayload }
    }

    #[unstable(
        feature = "panic_internals",
        reason = "internal details of the implementation of the `panic!` and related macros",
        issue = "none"
    )]
    #[doc(hidden)]
    #[inline]
    pub fn set_payload(&mut self, info: &'a (dyn Any + Send)) {
        self.payload = info;
    }

    /// Ibinabalik ang bayad na nauugnay sa panic.
    ///
    /// Karaniwan itong, ngunit hindi palaging, maging isang `&'static str` o [`String`].
    ///
    /// [`String`]: ../../std/string/struct.String.html
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(s) = panic_info.payload().downcast_ref::<&str>() {
    ///         println!("panic occurred: {:?}", s);
    ///     } else {
    ///         println!("panic occurred");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn payload(&self) -> &(dyn Any + Send) {
        self.payload
    }

    /// Kung ang `panic!` macro mula sa `core` crate (hindi mula sa `std`) ay ginamit gamit ang isang formatting string at ilang karagdagang mga argumento, ibabalik ang mensahe na handa nang magamit halimbawa kasama ng [`fmt::write`]
    ///
    ///
    #[unstable(feature = "panic_info_message", issue = "66745")]
    pub fn message(&self) -> Option<&fmt::Arguments<'_>> {
        self.message
    }

    /// Nagbabalik ng impormasyon tungkol sa lokasyon kung saan nagmula ang panic, kung magagamit.
    ///
    /// Ang pamamaraang ito ay kasalukuyang palaging magbabalik ng [`Some`], ngunit maaaring magbago ito sa mga bersyon ng future.
    ///
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred in file '{}' at line {}",
    ///             location.file(),
    ///             location.line(),
    ///         );
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    ///
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn location(&self) -> Option<&Location<'_>> {
        // NOTE: Kung binago ito upang minsan ay bumalik ng Wala,
        // harapin ang kasong iyon sa std::panicking::default_hook at std::panicking::begin_panic_fmt.
        Some(&self.location)
    }
}

#[stable(feature = "panic_hook_display", since = "1.26.0")]
impl fmt::Display for PanicInfo<'_> {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        formatter.write_str("panicked at ")?;
        if let Some(message) = self.message {
            write!(formatter, "'{}', ", message)?
        } else if let Some(payload) = self.payload.downcast_ref::<&'static str>() {
            write!(formatter, "'{}', ", payload)?
        }
        // NOTE: hindi namin maaaring gamitin ang downcast_ref: :<String>() dito
        // dahil ang String ay hindi magagamit sa libcore!
        // Ang payload ay isang String kapag tinawag ang `std::panic!` na may maraming mga argumento, ngunit sa kasong iyon ang mensahe ay magagamit din.
        //

        self.location.fmt(formatter)
    }
}

/// Isang istrukturang naglalaman ng impormasyon tungkol sa lokasyon ng isang panic.
///
/// Ang istrakturang ito ay nilikha ng [`PanicInfo::location()`].
///
/// # Examples
///
/// ```should_panic
/// use std::panic;
///
/// panic::set_hook(Box::new(|panic_info| {
///     if let Some(location) = panic_info.location() {
///         println!("panic occurred in file '{}' at line {}", location.file(), location.line());
///     } else {
///         println!("panic occurred but can't get location information...");
///     }
/// }));
///
/// panic!("Normal panic");
/// ```
///
/// # Comparisons
///
/// Ang mga paghahambing para sa pagkakapantay-pantay at pag-order ay ginawa sa file, linya, pagkatapos ay ang priyoridad ng haligi.
/// Ang mga file ay inihambing bilang mga string, hindi `Path`, na maaaring hindi inaasahan.
/// Tingnan ang dokumentasyon ng [Lokasyon: : file`] para sa karagdagang talakayan.
#[lang = "panic_location"]
#[derive(Copy, Clone, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
#[stable(feature = "panic_hooks", since = "1.10.0")]
pub struct Location<'a> {
    file: &'a str,
    line: u32,
    col: u32,
}

impl<'a> Location<'a> {
    /// Ibinabalik ang lokasyon ng pinagmulan ng tumatawag sa pagpapaandar na ito.
    /// Kung ang tumatawag sa pagpapaandar na iyon ay na-annotate pagkatapos ay ang lokasyon ng tawag nito ay ibabalik, at iba pa hanggang sa stack sa unang tawag sa loob ng isang hindi sinusubaybayang body ng pag-andar.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::panic::Location;
    ///
    /// /// Ibinabalik ang [`Location`] kung saan ito tinawag.
    /// #[track_caller]
    /// fn get_caller_location() -> &'static Location<'static> {
    ///     Location::caller()
    /// }
    ///
    /// /// Nagbabalik ng isang [`Location`] mula sa loob ng kahulugan ng pagpapaandar na ito.
    /// fn get_just_one_location() -> &'static Location<'static> {
    ///     get_caller_location()
    /// }
    ///
    /// let fixed_location = get_just_one_location();
    /// assert_eq!(fixed_location.file(), file!());
    /// assert_eq!(fixed_location.line(), 14);
    /// assert_eq!(fixed_location.column(), 5);
    ///
    /// // ang pagpapatakbo ng parehong hindi na-track na pag-andar sa ibang lokasyon ay nagbibigay sa amin ng parehong resulta
    /// let second_fixed_location = get_just_one_location();
    /// assert_eq!(fixed_location.file(), second_fixed_location.file());
    /// assert_eq!(fixed_location.line(), second_fixed_location.line());
    /// assert_eq!(fixed_location.column(), second_fixed_location.column());
    ///
    /// let this_location = get_caller_location();
    /// assert_eq!(this_location.file(), file!());
    /// assert_eq!(this_location.line(), 28);
    /// assert_eq!(this_location.column(), 21);
    ///
    /// // ang pagpapatakbo ng sinusubaybayan na pag-andar sa ibang lokasyon ay gumagawa ng ibang halaga
    /// let another_location = get_caller_location();
    /// assert_eq!(this_location.file(), another_location.file());
    /// assert_ne!(this_location.line(), another_location.line());
    /// assert_ne!(this_location.column(), another_location.column());
    /// ```
    #[stable(feature = "track_caller", since = "1.46.0")]
    #[rustc_const_unstable(feature = "const_caller_location", issue = "76156")]
    #[track_caller]
    pub const fn caller() -> &'static Location<'static> {
        crate::intrinsics::caller_location()
    }
}

impl<'a> Location<'a> {
    #![unstable(
        feature = "panic_internals",
        reason = "internal details of the implementation of the `panic!` and related macros",
        issue = "none"
    )]
    #[doc(hidden)]
    pub const fn internal_constructor(file: &'a str, line: u32, col: u32) -> Self {
        Location { file, line, col }
    }

    /// Ibinabalik ang pangalan ng pinagmulang file na nagmula sa panic.
    ///
    /// # `&str`, hindi `&Path`
    ///
    /// Ang naibalik na pangalan ay tumutukoy sa isang mapagkukunang landas sa pag-iipon ng system, ngunit hindi wasto na kumatawan ito nang direkta bilang isang `&Path`.
    /// Ang pinagsamang code ay maaaring tumakbo sa isang iba't ibang mga system na may ibang pagpapatupad ng `Path` kaysa sa system na nagbibigay ng mga nilalaman at ang library na ito ay kasalukuyang walang iba't ibang uri ng "host path".
    ///
    /// Ang pinaka-nakakagulat na pag-uugali ay nangyayari kapag "the same" file ay mapupuntahan sa pamamagitan ng maramihang mga landas sa module ng sistema (karaniwan ay gamit ang `#[path = "..."]` attribute o katulad), na maaaring maging sanhi ng kung ano ay lilitaw upang maging magkapareho code upang bumalik magkakaibang mga halaga mula sa function na ito.
    ///
    ///
    /// # Cross-compilation
    ///
    /// Ang halagang ito ay hindi angkop para sa pagpasa sa `Path::new` o mga katulad na tagapagbuo kapag naiiba ang host platform at target na platform.
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred in file '{}'", location.file());
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn file(&self) -> &str {
        self.file
    }

    /// Ibinabalik ang numero ng linya kung saan nagmula ang panic.
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred at line {}", location.line());
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn line(&self) -> u32 {
        self.line
    }

    /// Ibinabalik ang haligi kung saan nagmula ang panic.
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred at column {}", location.column());
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    #[stable(feature = "panic_col", since = "1.25.0")]
    pub fn column(&self) -> u32 {
        self.col
    }
}

#[stable(feature = "panic_hook_display", since = "1.26.0")]
impl fmt::Display for Location<'_> {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(formatter, "{}:{}:{}", self.file, self.line, self.col)
    }
}

/// Isang panloob na trait na ginamit ng libstd upang maipasa ang data mula sa libstd hanggang `panic_unwind` at iba pang mga runtime ng panic.
/// Hindi inilaan na maging matatag anumang oras sa madaling panahon, huwag gamitin.
///
#[unstable(feature = "std_internals", issue = "none")]
#[doc(hidden)]
pub unsafe trait BoxMeUp {
    /// Dalhin ang buong pagmamay-ari ng mga nilalaman.
    /// Ang uri ng pagbabalik ay talagang `Box<dyn Any + Send>`, ngunit hindi namin maaaring gamitin ang `Box` sa libcore.
    ///
    /// Matapos matawag ang pamamaraang ito, ang ilang halaga lamang sa default na natatira sa `self`.
    /// Ang pagtawag sa pamamaraang ito nang dalawang beses, o pagtawag sa `get` pagkatapos tumawag sa pamamaraang ito, ay isang error.
    ///
    /// Ang argumento ay hiniram dahil ang panic runtime (`__rust_start_panic`) ay nakakakuha lamang ng isang hiniram na `dyn BoxMeUp`.
    ///
    fn take_box(&mut self) -> *mut (dyn Any + Send);

    /// Manghiram lamang ng nilalaman.
    fn get(&mut self) -> &(dyn Any + Send);
}