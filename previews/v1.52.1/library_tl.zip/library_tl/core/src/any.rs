//! Ang module na ito ipinapatupad ng `Any` trait, na kung saan ay nagbibigay-daan dynamic na pag-type ng anumang uri `'static` pamamagitan runtime pagmuni-muni.
//!
//! `Any` mismo ay maaaring gamitin upang makakuha ng isang `TypeId`, at may mas maraming mga tampok kapag ginamit bilang trait object.
//! Bilang `&dyn Any` (isang hiniram na bagay na trait), mayroon itong mga pamamaraan na `is` at `downcast_ref`, upang subukan kung ang nilalaman na nilalaman ay isang ibinigay na uri, at upang makakuha ng isang sanggunian sa panloob na halaga bilang isang uri.
//! Bilang `&mut dyn Any`, mayroon ding mga `downcast_mut` paraan, para sa pagkuha ng isang nagbabago reference sa panloob na halaga.
//! `Box<dyn Any>` nagdadagdag ng `downcast` na paraan, na sumusubok na i-convert sa isang `Box<T>`.
//! Tingnan ang dokumentasyon ng [`Box`] para sa buong detalye.
//!
//! Tandaan na `&dyn Any` ay limitado sa pagsubok kung ang halaga ay ng isang tinukoy na uri ng kongkreto, at hindi maaaring gamitin upang pagsubok kung ang isang i-type ang mga nagpapatupad ng trait.
//!
//! [`Box`]: ../../std/boxed/struct.Box.html
//!
//! # Mga smart point at `dyn Any`
//!
//! Isang piraso ng pag-uugali na dapat tandaan kapag gumagamit ng `Any` bilang trait bagay, lalo na sa mga uri tulad ng `Box<dyn Any>` o `Arc<dyn Any>`, ay na lamang ng pagtawag `.type_id()` sa halaga ay makakapagdulot ng ang `TypeId` ng *container*, hindi ang kalakip trait object.
//!
//! Maiiwasan ito sa pamamagitan ng pag-convert ng smart pointer sa isang `&dyn Any` sa halip, na ibabalik ang `TypeId` ng object.
//! Halimbawa:
//!
//! ```
//! use std::any::{Any, TypeId};
//!
//! let boxed: Box<dyn Any> = Box::new(3_i32);
//!
//! // Mas malamang na gusto mo ito:
//! let actual_id = (&*boxed).type_id();
//! // ... kaysa dito:
//! let boxed_id = boxed.type_id();
//!
//! assert_eq!(actual_id, TypeId::of::<i32>());
//! assert_eq!(boxed_id, TypeId::of::<Box<dyn Any>>());
//! ```
//!
//! # Examples
//!
//! Isaalang-alang ang isang sitwasyon kung saan nais naming mag-log out ng isang halagang ipinasa sa isang pagpapaandar.
//! Alam namin ang halagang ginagawa namin sa pagpapatupad ng Debug, ngunit hindi namin alam ang kongkretong uri nito.Nais naming bigyan ang espesyal na paggamot sa ilang mga uri: sa kasong ito ang pag-print ng haba ng mga halaga ng String bago ang kanilang halaga.
//! Hindi namin alam ang kongkretong uri ng aming halaga sa oras ng pagtitipon, kaya kailangan naming gumamit ng halip na pagmuni-muni ng runtime.
//!
//! ```rust
//! use std::fmt::Debug;
//! use std::any::Any;
//!
//! // Logger pag-andar para sa anumang uri na nagpapatupad Debug.
//! fn log<T: Any + Debug>(value: &T) {
//!     let value_any = value as &dyn Any;
//!
//!     // Subukan upang i-convert ang aming halaga sa isang `String`.
//!     // Kung matagumpay, nais naming i-output ang haba ng String` pati na rin ang halaga nito.
//!     // Kung hindi, ito ay isang iba't ibang uri: i-print lamang ito nang hindi naka-adorno.
//!     match value_any.downcast_ref::<String>() {
//!         Some(as_string) => {
//!             println!("String ({}): {}", as_string.len(), as_string);
//!         }
//!         None => {
//!             println!("{:?}", value);
//!         }
//!     }
//! }
//!
//! // function na ito ay nais na mag-log parameter kanyang out bago ang paggawa ng trabaho sa mga ito.
//! fn do_work<T: Any + Debug>(value: &T) {
//!     log(value);
//!     // ... gumawa ng ibang trabaho
//! }
//!
//! fn main() {
//!     let my_string = "Hello World".to_string();
//!     do_work(&my_string);
//!
//!     let my_i8: i8 = 100;
//!     do_work(&my_i8);
//! }
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::intrinsics;

///////////////////////////////////////////////////////////////////////////////
// Anumang trait
///////////////////////////////////////////////////////////////////////////////

/// Isang trait na gayahin ang pabagu-bagong pagta-type.
///
/// Karamihan sa mga uri ay nagpapatupad ng `Any`.Gayunpaman, ang anumang uri na naglalaman ng isang di-`ttatic` na sanggunian ay hindi.
/// Tingnan ang [module-level documentation][mod] para sa karagdagang detalye.
///
/// [mod]: crate::any
// Ito trait ay hindi ligtas, kahit na kami ay umaasa sa mga pagtutukoy ng `type_id` function na ito sa natatangi impl sa hindi ligtas na code (eg, `downcast`).Karaniwan, na magiging isang problema, ngunit dahil ang tanging impl ng `Any` ay isang blanket pagpapatupad, walang iba pang mga code ay maaaring ipatupad `Any`.
//
// Maari nating gawin itong trait na hindi ligtas-hindi ito magiging sanhi ng pagkasira, dahil kinokontrol namin ang lahat ng pagpapatupad-ngunit pinili namin na hindi dahil iyan ay kapwa hindi talaga kinakailangan at maaaring lituhin ang mga gumagamit tungkol sa pagkakaiba ng hindi ligtas na traits at hindi ligtas na pamamaraan (ibig sabihin, `type_id` pa rin maging ligtas tawagan, ngunit nais naming malamang na nais upang ipahiwatig dahil dito sa dokumentasyon).
//
//
//
//
//
//
//
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Any: 'static {
    /// Nakukuha ang `TypeId` ng `self`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string(s: &dyn Any) -> bool {
    ///     TypeId::of::<String>() == s.type_id()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "get_type_id", since = "1.34.0")]
    fn type_id(&self) -> TypeId;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: 'static + ?Sized> Any for T {
    fn type_id(&self) -> TypeId {
        TypeId::of::<T>()
    }
}

///////////////////////////////////////////////////////////////////////////////
// Mga pamamaraan ng extension para sa Anumang mga bagay na trait.
///////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

// Tiyakin na ang resulta ng eg, pagsali sa isang thread ay maaaring ipi-print at samakatuwid magamit sa `unwrap`.
// Sa huli ay maaaring hindi na kailangan kung dispatch gumagana sa upcasting.
//
#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any + Send {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

#[stable(feature = "any_send_sync_methods", since = "1.28.0")]
impl fmt::Debug for dyn Any + Send + Sync {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

impl dyn Any {
    /// Ibinabalik `true` kung ang boxed uri ay katulad ng `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &dyn Any) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        // Kunin ang `TypeId` ng uri na ang function na ito ay instantiated sa.
        let t = TypeId::of::<T>();

        // Kunin ang `TypeId` ng uri sa trait object (`self`).
        let concrete = self.type_id();

        // Paghambingin ang parehong `TypeId` sa pagkakapantay-pantay.
        t == concrete
    }

    /// Nagbabalik ng ilang sanggunian sa naka-box na halaga kung ito ay uri ng `T`, o `None` kung hindi.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &dyn Any) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        if self.is::<T>() {
            // KALIGTASAN: naka-check lamang kung tumuturo kami sa tamang uri, at maaari kaming umasa
            // na suriin para sa kaligtasan ng memorya dahil naipatupad namin ang Anumang para sa lahat ng uri;walang iba pang mga impls na maaaring umiiral tulad ng salungatan nila sa aming impl.
            //
            unsafe { Some(&*(self as *const dyn Any as *const T)) }
        } else {
            None
        }
    }

    /// Nagbabalik ng ilang nababagabag na sanggunian sa naka-box na halaga kung ito ay uri ng `T`, o `None` kung hindi.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut dyn Any) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        if self.is::<T>() {
            // KALIGTASAN: naka-check lamang kung tumuturo kami sa tamang uri, at maaari kaming umasa
            // na suriin para sa kaligtasan ng memorya dahil naipatupad namin ang Anumang para sa lahat ng uri;walang iba pang mga impls na maaaring umiiral tulad ng salungatan nila sa aming impl.
            //
            unsafe { Some(&mut *(self as *mut dyn Any as *mut T)) }
        } else {
            None
        }
    }
}

impl dyn Any + Send {
    /// Ipasa ang paraan na tinukoy sa uri ng `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// Ipasa ang paraan na tinukoy sa uri ng `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// Ipasa ang paraan na tinukoy sa uri ng `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

impl dyn Any + Send + Sync {
    /// Ipasa ang paraan na tinukoy sa uri ng `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send + Sync)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// Ipasa ang paraan na tinukoy sa uri ng `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send + Sync)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// Ipasa ang paraan na tinukoy sa uri ng `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send + Sync)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

///////////////////////////////////////////////////////////////////////////////
// TypeID at ang mga pamamaraan nito
///////////////////////////////////////////////////////////////////////////////

/// Ang isang `TypeId` ay kumakatawan sa isang pangkalahatang natatanging identifier para sa isang uri.
///
/// Ang bawat `TypeId` ay isang opaque na bagay na hindi pinapayagan ang pag-inspeksyon sa kung ano sa loob ngunit pinapayagan ang mga pangunahing operasyon tulad ng cloning, paghahambing, pag-print, at pagpapakita.
///
///
/// Ang isang `TypeId` ay kasalukuyang magagamit lamang para sa mga uri na tumutukoy sa `'static`, ngunit ang limitasyon na ito ay maaaring alisin sa future.
///
/// Habang `TypeId` nagpapatupad `Hash`, `PartialOrd`, at `Ord`, ito ay nagkakahalaga ng noting na ang mga hash at pag-order ay mag-iiba sa pagitan Rust paglabas.
/// Mag-ingat sa pag-asa sa kanila sa loob ng iyong code!
///
///
///
#[derive(Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Debug, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct TypeId {
    t: u64,
}

impl TypeId {
    /// Ibinabalik ang `TypeId` ng uri na ang pangkasalukuyang pag-andar na ito ay na-instantiate na.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string<T: ?Sized + Any>(_s: &T) -> bool {
    ///     TypeId::of::<String>() == TypeId::of::<T>()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub const fn of<T: ?Sized + 'static>() -> TypeId {
        TypeId { t: intrinsics::type_id::<T>() }
    }
}

/// Ibinabalik ang pangalan ng isang uri bilang isang hiwa ng string.
///
/// # Note
///
/// Ito ay inilaan para sa paggamit ng diagnostic.
/// Ang eksaktong nilalaman at format ng string na ibinalik ay hindi tinukoy, maliban sa pagiging isang pinakamahusay na pagsisikap na paglalarawan ng uri.
/// Halimbawa, sa gitna ng mga string na maaaring ibalik ng `type_name::<Option<String>>()` ay `"Option<String>"` at `"std::option::Option<std::string::String>"`.
///
///
/// Ang naibalik na string ay hindi dapat isaalang-alang na isang natatanging pagkakakilanlan ng isang uri dahil ang maraming uri ay maaaring mapa sa parehong pangalan ng uri.
/// Katulad nito, walang garantiya na ang lahat ng mga bahagi ng isang uri ay lilitaw sa naibalik na string: halimbawa, ang mga tagapahiwatig sa buhay ay kasalukuyang hindi kasama.
/// Bilang karagdagan, ang output ay maaaring magbago sa pagitan ng mga bersyon ng compiler.
///
/// Ang kasalukuyang pagpapatupad ay gumagamit ng parehong imprastraktura tulad ng compiler diagnostic at debuginfo, ngunit ito ay hindi garantisadong.
///
/// # Examples
///
/// ```rust
/// assert_eq!(
///     std::any::type_name::<Option<String>>(),
///     "core::option::Option<alloc::string::String>",
/// );
/// ```
///
///
///
///
#[stable(feature = "type_name", since = "1.38.0")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name<T: ?Sized>() -> &'static str {
    intrinsics::type_name::<T>()
}

/// Ibinabalik ang pangalan ng uri ng matulis na-to halaga ng isang string slice.
/// Ito ay kapareho ng `type_name::<T>()`, ngunit maaaring magamit kung saan ang uri ng isang variable ay hindi madaling magamit.
///
/// # Note
///
/// Ito ay inilaan para sa paggamit ng diagnostic.Ang eksaktong mga nilalaman at format ng string ay hindi tinukoy, bukod sa pagiging isang pinakamahusay na pagsisikap paglalarawan ng mga uri.
/// Halimbawa, maaaring ibalik ng `type_name_of_val::<Option<String>>(None)` ang `"Option<String>"` o `"std::option::Option<std::string::String>"`, ngunit hindi `"foobar"`.
///
/// Bilang karagdagan, ang output ay maaaring magbago sa pagitan ng mga bersyon ng compiler.
///
/// function na ito ay hindi malutas trait bagay, ibig sabihin na `type_name_of_val(&7u32 as &dyn Debug)` maaaring bumalik `"dyn Debug"`, ngunit hindi `"u32"`.
///
/// Ang pangalan ng uri ay hindi dapat isaalang-alang na isang natatanging pagkakakilanlan ng isang uri;
/// maraming uri ang maaaring magbahagi ng parehong pangalan ng uri.
///
/// Ang kasalukuyang pagpapatupad ay gumagamit ng parehong imprastraktura tulad ng compiler diagnostic at debuginfo, ngunit ito ay hindi garantisadong.
///
/// # Examples
///
/// Nagpi-print ng mga default na uri ng integer at float.
///
/// ```rust
/// #![feature(type_name_of_val)]
/// use std::any::type_name_of_val;
///
/// let x = 1;
/// println!("{}", type_name_of_val(&x));
/// let y = 1.0;
/// println!("{}", type_name_of_val(&y));
/// ```
///
///
///
///
///
///
#[unstable(feature = "type_name_of_val", issue = "66359")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name_of_val<T: ?Sized>(_val: &T) -> &'static str {
    type_name::<T>()
}