//! Pagmanipula ng string.
//!
//! Para sa karagdagang detalye, tingnan ang module na [`std::str`].
//!
//! [`std::str`]: ../../std/str/index.html

#![stable(feature = "rust1", since = "1.0.0")]

mod converts;
mod error;
mod iter;
mod traits;
mod validations;

use self::pattern::Pattern;
use self::pattern::{DoubleEndedSearcher, ReverseSearcher, Searcher};

use crate::char;
use crate::mem;
use crate::slice::{self, SliceIndex};

pub mod pattern;

#[unstable(feature = "str_internals", issue = "none")]
#[allow(missing_docs)]
pub mod lossy;

#[stable(feature = "rust1", since = "1.0.0")]
pub use converts::{from_utf8, from_utf8_unchecked};

#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub use converts::{from_utf8_mut, from_utf8_unchecked_mut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use error::{ParseBoolError, Utf8Error};

#[stable(feature = "rust1", since = "1.0.0")]
pub use traits::FromStr;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Bytes, CharIndices, Chars, Lines, SplitWhitespace};

#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated)]
pub use iter::LinesAny;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplit, RSplitTerminator, Split, SplitTerminator};

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplitN, SplitN};

#[stable(feature = "str_matches", since = "1.2.0")]
pub use iter::{Matches, RMatches};

#[stable(feature = "str_match_indices", since = "1.5.0")]
pub use iter::{MatchIndices, RMatchIndices};

#[stable(feature = "encode_utf16", since = "1.8.0")]
pub use iter::EncodeUtf16;

#[stable(feature = "str_escape", since = "1.34.0")]
pub use iter::{EscapeDebug, EscapeDefault, EscapeUnicode};

#[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
pub use iter::SplitAsciiWhitespace;

#[stable(feature = "split_inclusive", since = "1.51.0")]
pub use iter::SplitInclusive;

#[unstable(feature = "str_internals", issue = "none")]
pub use validations::next_code_point;

use iter::MatchIndicesInternal;
use iter::SplitInternal;
use iter::{MatchesInternal, SplitNInternal};

use validations::truncate_to_char_boundary;

#[inline(never)]
#[cold]
#[track_caller]
fn slice_error_fail(s: &str, begin: usize, end: usize) -> ! {
    const MAX_DISPLAY_LENGTH: usize = 256;
    let (truncated, s_trunc) = truncate_to_char_boundary(s, MAX_DISPLAY_LENGTH);
    let ellipsis = if truncated { "[...]" } else { "" };

    // 1. sa labas ng hangganan
    if begin > s.len() || end > s.len() {
        let oob_index = if begin > s.len() { begin } else { end };
        panic!("byte index {} is out of bounds of `{}`{}", oob_index, s_trunc, ellipsis);
    }

    // 2. magsimula <=pagtatapos
    assert!(
        begin <= end,
        "begin <= end ({} <= {}) when slicing `{}`{}",
        begin,
        end,
        s_trunc,
        ellipsis
    );

    // 3. hangganan ng character
    let index = if !s.is_char_boundary(begin) { begin } else { end };
    // hanapin ang tauhan
    let mut char_start = index;
    while !s.is_char_boundary(char_start) {
        char_start -= 1;
    }
    // `char_start` dapat mas mababa sa len at isang char hangganan
    let ch = s[char_start..].chars().next().unwrap();
    let char_range = char_start..char_start + ch.len_utf8();
    panic!(
        "byte index {} is not a char boundary; it is inside {:?} (bytes {:?}) of `{}`{}",
        index, ch, char_range, s_trunc, ellipsis
    );
}

#[lang = "str"]
#[cfg(not(test))]
impl str {
    /// Ibinabalik ang haba ng `self`.
    ///
    /// Ang haba na ito ay nasa mga byte, hindi [`char`] s o graphemes.
    /// Sa madaling salita, maaaring hindi ito ang isinasaalang-alang ng isang tao sa haba ng string.
    ///
    /// [`char`]: prim@char
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// let len = "foo".len();
    /// assert_eq!(3, len);
    ///
    /// assert_eq!("ƒoo".len(), 4); // magarbong f!
    /// assert_eq!("ƒoo".chars().count(), 3);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_str_len", since = "1.32.0")]
    #[inline]
    pub const fn len(&self) -> usize {
        self.as_bytes().len()
    }

    /// Ibinabalik ang `true` kung ang `self` ay may haba ng zero bytes.
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// let s = "";
    /// assert!(s.is_empty());
    ///
    /// let s = "not empty";
    /// assert!(!s.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_str_is_empty", since = "1.32.0")]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Sinusuri na ang `index`-th byte ay ang unang byte sa isang pagkakasunud-sunod ng code point na UTF-8 o ang pagtatapos ng string.
    ///
    ///
    /// Ang simula at dulo ng string (kapag `index== self.len()`) ay itinuturing na hangganan.
    ///
    /// Ibinabalik ang `false` kung ang `index` ay mas malaki sa `self.len()`.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// assert!(s.is_char_boundary(0));
    /// // simula ng `老`
    /// assert!(s.is_char_boundary(6));
    /// assert!(s.is_char_boundary(s.len()));
    ///
    /// // pangalawang byte ng `ö`
    /// assert!(!s.is_char_boundary(2));
    ///
    /// // pangatlong byte ng `老`
    /// assert!(!s.is_char_boundary(8));
    /// ```
    ///
    #[stable(feature = "is_char_boundary", since = "1.9.0")]
    #[inline]
    pub fn is_char_boundary(&self, index: usize) -> bool {
        // 0 at len laging ok.
        // Malinaw na subukan ang 0 upang ma-optimize nito ang tseke nang madali at laktawan ang data ng pagbasa ng string para sa kasong iyon.
        //
        if index == 0 || index == self.len() {
            return true;
        }
        match self.as_bytes().get(index) {
            None => false,
            // Ito ay bit magic na katumbas ng: b <128 ||b>=192
            Some(&b) => (b as i8) >= -0x40,
        }
    }

    /// Nagko-convert ng isang hiwa ng string sa isang byte slice.
    /// Upang i-convert ang byte slice pabalik sa isang string slice, gamitin ang [`from_utf8`] function.
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// let bytes = "bors".as_bytes();
    /// assert_eq!(b"bors", bytes);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "str_as_bytes", since = "1.32.0")]
    #[inline(always)]
    #[allow(unused_attributes)]
    #[rustc_allow_const_fn_unstable(const_fn_transmute)]
    pub const fn as_bytes(&self) -> &[u8] {
        // KALIGTASAN: tunog ng const dahil nagpapasalin kami ng dalawang uri na may parehong layout
        unsafe { mem::transmute(self) }
    }

    /// Nag-convert ng isang nababagabag na hiwa ng string sa isang nababagong byte slice.
    ///
    /// # Safety
    ///
    /// Dapat tiyakin ng tumatawag na ang nilalaman ng hiwa ay wastong UTF-8 bago matapos ang utang at ang pinagbabatayan na `str` ay ginamit.
    ///
    ///
    /// Gamitin ng isang `str` na ang mga nilalaman ay hindi wasto UTF-8 ay hindi natukoy na pag-uugali.
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// let mut s = String::from("Hello");
    /// let bytes = unsafe { s.as_bytes_mut() };
    ///
    /// assert_eq!(b"Hello", bytes);
    /// ```
    ///
    /// Mutability:
    ///
    /// ```
    /// let mut s = String::from("🗻∈🌏");
    ///
    /// unsafe {
    ///     let bytes = s.as_bytes_mut();
    ///
    ///     bytes[0] = 0xF0;
    ///     bytes[1] = 0x9F;
    ///     bytes[2] = 0x8D;
    ///     bytes[3] = 0x94;
    /// }
    ///
    /// assert_eq!("🍔∈🌏", s);
    /// ```
    #[stable(feature = "str_mut_extras", since = "1.20.0")]
    #[inline(always)]
    pub unsafe fn as_bytes_mut(&mut self) -> &mut [u8] {
        // KALIGTASAN: ang cast mula `&str` hanggang `&[u8]` ay ligtas mula `str`
        // ay may parehong layout tulad ng `&[u8]` (ang libstd lamang ang makakagawa ng garantiyang ito).
        // Ang pointer dereference ay ligtas dahil ito ay nagmumula sa isang nagbabago reference na kung saan ay garantisadong upang maging wasto para writes.
        //
        unsafe { &mut *(self as *mut str as *mut [u8]) }
    }

    /// Nagko-convert ng isang hiwa ng string sa isang hilaw na pointer.
    ///
    /// Tulad ng mga hiwa ng string ay isang slice ng bytes, ang hilaw na pointer ay tumuturo sa isang [`u8`].
    /// Ituturo ng pointer na ito ang unang byte ng hiwa ng string.
    ///
    /// Dapat tiyakin ng tumatawag na ang naibalik na pointer ay hindi kailanman naisulat.
    /// Kung kailangan mong i-mutate ang mga nilalaman ng hiwa ng string, gamitin ang [`as_mut_ptr`].
    ///
    ///
    /// [`as_mut_ptr`]: str::as_mut_ptr
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// let s = "Hello";
    /// let ptr = s.as_ptr();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "rustc_str_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(&self) -> *const u8 {
        self as *const str as *const u8
    }

    /// Nagko-convert ng isang nababagabag na hiwa ng string sa isang hilaw na pointer.
    ///
    /// Tulad ng mga hiwa ng string ay isang slice ng bytes, ang hilaw na pointer ay tumuturo sa isang [`u8`].
    /// Ituturo ng pointer na ito ang unang byte ng hiwa ng string.
    ///
    /// Responsibilidad mong tiyakin na ang hiwa ng string ay nabago lamang sa isang paraan na mananatili itong wastong UTF-8.
    ///
    ///
    #[stable(feature = "str_as_mut_ptr", since = "1.36.0")]
    #[inline]
    pub fn as_mut_ptr(&mut self) -> *mut u8 {
        self as *mut str as *mut u8
    }

    /// Nagbabalik ng isang subslice ng `str`.
    ///
    /// Ito ang alternatibong hindi panic sa pag-index ng `str`.
    /// Ibinabalik ang [`None`] tuwing katumbas ng pagpapatakbo sa pag-index ay panic.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = String::from("🗻∈🌏");
    ///
    /// assert_eq!(Some("🗻"), v.get(0..4));
    ///
    /// // mga indeks na wala sa mga hangganan ng pagkakasunud-sunod ng UTF-8
    /// assert!(v.get(1..).is_none());
    /// assert!(v.get(..8).is_none());
    ///
    /// // sa labas ng hangganan
    /// assert!(v.get(..42).is_none());
    /// ```
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub fn get<I: SliceIndex<str>>(&self, i: I) -> Option<&I::Output> {
        i.get(self)
    }

    /// Ibinabalik maaaring mabago ng isang subslice ng `str`.
    ///
    /// Ito ang alternatibong hindi panic sa pag-index ng `str`.
    /// Ibinabalik ang [`None`] tuwing katumbas ng pagpapatakbo sa pag-index ay panic.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = String::from("hello");
    /// // tamang haba
    /// assert!(v.get_mut(0..5).is_some());
    /// // sa labas ng hangganan
    /// assert!(v.get_mut(..42).is_none());
    /// assert_eq!(Some("he"), v.get_mut(0..2).map(|v| &*v));
    ///
    /// assert_eq!("hello", v);
    /// {
    ///     let s = v.get_mut(0..2);
    ///     let s = s.map(|s| {
    ///         s.make_ascii_uppercase();
    ///         &*s
    ///     });
    ///     assert_eq!(Some("HE"), s);
    /// }
    /// assert_eq!("HEllo", v);
    /// ```
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub fn get_mut<I: SliceIndex<str>>(&mut self, i: I) -> Option<&mut I::Output> {
        i.get_mut(self)
    }

    /// Nagbabalik ng isang hindi naseksyong subslice ng `str`.
    ///
    /// Ito ang walang check alternatibo sa pag-index ng `str`.
    ///
    /// # Safety
    ///
    /// Ang mga tumatawag sa pagpapaandar na ito ay responsable na nasiyahan ang mga precondition na ito:
    ///
    /// * Ang panimulang indeks ay hindi dapat lumagpas sa nagtatapos na indeks;
    /// * Ang mga indeks ay dapat nasa loob ng mga hangganan ng orihinal na hiwa;
    /// * Ang mga indeks ay dapat na nakasalalay sa mga hangganan ng pagkakasunud-sunod ng UTF-8.
    ///
    /// Nabigo iyon, ang naibalik na hiwa ng string ay maaaring mag-refer ng di-wastong memorya o lumabag sa mga invariant na naipaabot ng `str` na uri.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let v = "🗻∈🌏";
    /// unsafe {
    ///     assert_eq!("🗻", v.get_unchecked(0..4));
    ///     assert_eq!("∈", v.get_unchecked(4..7));
    ///     assert_eq!("🌏", v.get_unchecked(7..11));
    /// }
    /// ```
    ///
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub unsafe fn get_unchecked<I: SliceIndex<str>>(&self, i: I) -> &I::Output {
        // KALIGTASAN: ang tumatawag ay dapat na itaguyod ang kaligtasan na kontrata para sa `get_unchecked`;
        // ang hiwa ay hindi maaalis dahil ang `self` ay isang ligtas na sanggunian.
        // Ang naibalik na pointer ay ligtas dahil ang mga impls ng `SliceIndex` ay kailangang garantiya na ito ay.
        unsafe { &*i.get_unchecked(self) }
    }

    /// Nagbabalik ng isang nababagabag, hindi naka-check na subslice ng `str`.
    ///
    /// Ito ang walang check alternatibo sa pag-index ng `str`.
    ///
    /// # Safety
    ///
    /// Ang mga tumatawag sa pagpapaandar na ito ay responsable na nasiyahan ang mga precondition na ito:
    ///
    /// * Ang panimulang indeks ay hindi dapat lumagpas sa nagtatapos na indeks;
    /// * Ang mga indeks ay dapat nasa loob ng mga hangganan ng orihinal na hiwa;
    /// * Ang mga indeks ay dapat na nakasalalay sa mga hangganan ng pagkakasunud-sunod ng UTF-8.
    ///
    /// Nabigo iyon, ang naibalik na hiwa ng string ay maaaring mag-refer ng di-wastong memorya o lumabag sa mga invariant na naipaabot ng `str` na uri.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = String::from("🗻∈🌏");
    /// unsafe {
    ///     assert_eq!("🗻", v.get_unchecked_mut(0..4));
    ///     assert_eq!("∈", v.get_unchecked_mut(4..7));
    ///     assert_eq!("🌏", v.get_unchecked_mut(7..11));
    /// }
    /// ```
    ///
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I: SliceIndex<str>>(&mut self, i: I) -> &mut I::Output {
        // KALIGTASAN: ang tumatawag ay dapat na itaguyod ang kaligtasan na kontrata para sa `get_unchecked_mut`;
        // ang hiwa ay hindi maaalis dahil ang `self` ay isang ligtas na sanggunian.
        // Ang naibalik na pointer ay ligtas dahil ang mga impls ng `SliceIndex` ay kailangang garantiya na ito ay.
        unsafe { &mut *i.get_unchecked_mut(self) }
    }

    /// Lumilikha ng isang hiwa ng string mula sa isa pang hiwa ng string, na lampas sa mga pagsusuri sa kaligtasan.
    ///
    /// Sa pangkalahatan ito ay hindi inirerekomenda, gamitin nang may pag-iingat!Para sa isang ligtas na kahalili tingnan ang [`str`] at [`Index`].
    ///
    ///
    /// [`Index`]: crate::ops::Index
    ///
    /// Ang bagong hiwa na ito ay pupunta mula sa `begin` hanggang `end`, kabilang ang `begin` ngunit hindi kasama ang `end`.
    ///
    /// Upang makakuha ng isang nagbabago string slice halip, tingnan ang [`slice_mut_unchecked`] paraan.
    ///
    /// [`slice_mut_unchecked`]: str::slice_mut_unchecked
    ///
    /// # Safety
    ///
    /// Ang mga tumatawag sa pagpapaandar na ito ay responsable na tatlong mga precondition ang nasiyahan:
    ///
    /// * `begin` hindi dapat lumagpas sa `end`.
    /// * `begin` at `end` ay dapat na mga byte na posisyon sa loob ng string slice.
    /// * `begin` at `end` ay dapat magsinungaling sa mga hangganan ng pagkakasunud-sunod ng UTF-8.
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// unsafe {
    ///     assert_eq!("Löwe 老虎 Léopard", s.slice_unchecked(0, 21));
    /// }
    ///
    /// let s = "Hello, world!";
    ///
    /// unsafe {
    ///     assert_eq!("world", s.slice_unchecked(7, 12));
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.29.0", reason = "use `get_unchecked(begin..end)` instead")]
    #[inline]
    pub unsafe fn slice_unchecked(&self, begin: usize, end: usize) -> &str {
        // KALIGTASAN: ang tumatawag ay dapat na itaguyod ang kaligtasan na kontrata para sa `get_unchecked`;
        // ang hiwa ay hindi maaalis dahil ang `self` ay isang ligtas na sanggunian.
        // Ang naibalik na pointer ay ligtas dahil ang mga impls ng `SliceIndex` ay kailangang garantiya na ito ay.
        unsafe { &*(begin..end).get_unchecked(self) }
    }

    /// Lumilikha ng isang hiwa ng string mula sa isa pang hiwa ng string, na lampas sa mga pagsusuri sa kaligtasan.
    /// Sa pangkalahatan ito ay hindi inirerekomenda, gamitin nang may pag-iingat!Para sa isang ligtas na kahalili tingnan ang [`str`] at [`IndexMut`].
    ///
    ///
    /// [`IndexMut`]: crate::ops::IndexMut
    ///
    /// Ang bagong hiwa na ito ay pupunta mula sa `begin` hanggang `end`, kabilang ang `begin` ngunit hindi kasama ang `end`.
    ///
    /// Upang makakuha ng isang hindi nababago na hiwa ng string sa halip, tingnan ang paraan ng [`slice_unchecked`].
    ///
    /// [`slice_unchecked`]: str::slice_unchecked
    ///
    /// # Safety
    ///
    /// Ang mga tumatawag sa pagpapaandar na ito ay responsable na tatlong mga precondition ang nasiyahan:
    ///
    /// * `begin` hindi dapat lumagpas sa `end`.
    /// * `begin` at `end` ay dapat na mga byte na posisyon sa loob ng string slice.
    /// * `begin` at `end` ay dapat magsinungaling sa mga hangganan ng pagkakasunud-sunod ng UTF-8.
    ///
    ///
    ///
    ///
    #[stable(feature = "str_slice_mut", since = "1.5.0")]
    #[rustc_deprecated(since = "1.29.0", reason = "use `get_unchecked_mut(begin..end)` instead")]
    #[inline]
    pub unsafe fn slice_mut_unchecked(&mut self, begin: usize, end: usize) -> &mut str {
        // KALIGTASAN: ang tumatawag ay dapat na itaguyod ang kaligtasan na kontrata para sa `get_unchecked_mut`;
        // ang hiwa ay hindi maaalis dahil ang `self` ay isang ligtas na sanggunian.
        // Ang naibalik na pointer ay ligtas dahil ang mga impls ng `SliceIndex` ay kailangang garantiya na ito ay.
        unsafe { &mut *(begin..end).get_unchecked_mut(self) }
    }

    /// Hatiin ang isang hiwa ng string sa dalawa sa isang index.
    ///
    /// Ang argument, `mid`, ay dapat na isang byte offset mula sa simula ng string.
    /// Dapat din itong maging nasa hangganan ng isang code point UTF-8.
    ///
    /// Ang dalawang hiwa bumalik go mula sa simula ng ang string na hati sa `mid`, at mula `mid` sa dulo ng string slice.
    ///
    /// Upang makakuha ng mga mutable na hiwa ng string sa halip, tingnan ang paraan ng [`split_at_mut`].
    ///
    /// [`split_at_mut`]: str::split_at_mut
    ///
    /// # Panics
    ///
    /// Panics kung ang `mid` ay wala sa isang hangganan ng point ng UTF-8 code, o kung lampas na ito sa huling bahagi ng huling punto ng code ng hiwa ng string.
    ///
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// let s = "Per Martin-Löf";
    ///
    /// let (first, last) = s.split_at(3);
    ///
    /// assert_eq!("Per", first);
    /// assert_eq!(" Martin-Löf", last);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "str_split_at", since = "1.4.0")]
    pub fn split_at(&self, mid: usize) -> (&str, &str) {
        // is_char_boundary mga tseke na ang index ay nasa [0, .len()]
        if self.is_char_boundary(mid) {
            // KALIGTASAN: naka-check lamang na ang `mid` ay nasa isang char hangganan.
            unsafe { (self.get_unchecked(0..mid), self.get_unchecked(mid..self.len())) }
        } else {
            slice_error_fail(self, 0, mid)
        }
    }

    /// Hatiin ang isang nababagabag na hiwa ng string sa dalawa sa isang index.
    ///
    /// Ang argument, `mid`, ay dapat na isang byte offset mula sa simula ng string.
    /// Dapat din itong maging nasa hangganan ng isang code point UTF-8.
    ///
    /// Ang dalawang hiwa bumalik go mula sa simula ng ang string na hati sa `mid`, at mula `mid` sa dulo ng string slice.
    ///
    /// Upang makakuha ng hindi mababago na mga hiwa ng string sa halip, tingnan ang paraan ng [`split_at`].
    ///
    /// [`split_at`]: str::split_at
    ///
    /// # Panics
    ///
    /// Panics kung ang `mid` ay wala sa isang hangganan ng point ng UTF-8 code, o kung lampas na ito sa huling bahagi ng huling punto ng code ng hiwa ng string.
    ///
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// let mut s = "Per Martin-Löf".to_string();
    /// {
    ///     let (first, last) = s.split_at_mut(3);
    ///     first.make_ascii_uppercase();
    ///     assert_eq!("PER", first);
    ///     assert_eq!(" Martin-Löf", last);
    /// }
    /// assert_eq!("PER Martin-Löf", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "str_split_at", since = "1.4.0")]
    pub fn split_at_mut(&mut self, mid: usize) -> (&mut str, &mut str) {
        // is_char_boundary mga tseke na ang index ay nasa [0, .len()]
        if self.is_char_boundary(mid) {
            let len = self.len();
            let ptr = self.as_mut_ptr();
            // KALIGTASAN: naka-check lamang na ang `mid` ay nasa isang char hangganan.
            unsafe {
                (
                    from_utf8_unchecked_mut(slice::from_raw_parts_mut(ptr, mid)),
                    from_utf8_unchecked_mut(slice::from_raw_parts_mut(ptr.add(mid), len - mid)),
                )
            }
        } else {
            slice_error_fail(self, 0, mid)
        }
    }

    /// Ibinabalik ang isang iterator sa mga [`char`] s ng isang hiwa ng string.
    ///
    /// Bilang isang string slice ay binubuo ng valid UTF-8, maaari naming umulit sa pamamagitan ng isang string slice sa pamamagitan [`char`].
    /// Ang pamamaraang ito ay nagbabalik ng tulad ng isang umuulit.
    ///
    /// Mahalagang tandaan na ang [`char`] ay kumakatawan sa isang Halaga ng Unicode Scalar, at maaaring hindi tumugma sa iyong ideya kung ano ang isang 'character'.
    ///
    /// Ang pag-iintero sa mga kumpol ng grapheme ay maaaring kung ano ang talagang gusto mo.
    /// Ang pagpapaandar na ito ay hindi ibinigay ng karaniwang pamantasan ng Rust, suriin sa halip ang crates.io.
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// let word = "goodbye";
    ///
    /// let count = word.chars().count();
    /// assert_eq!(7, count);
    ///
    /// let mut chars = word.chars();
    ///
    /// assert_eq!(Some('g'), chars.next());
    /// assert_eq!(Some('o'), chars.next());
    /// assert_eq!(Some('o'), chars.next());
    /// assert_eq!(Some('d'), chars.next());
    /// assert_eq!(Some('b'), chars.next());
    /// assert_eq!(Some('y'), chars.next());
    /// assert_eq!(Some('e'), chars.next());
    ///
    /// assert_eq!(None, chars.next());
    /// ```
    ///
    /// Tandaan, maaaring hindi tumugma ang [`char`] sa iyong intuwisyon tungkol sa mga character:
    ///
    /// [`char`]: prim@char
    ///
    /// ```
    /// let y = "y̆";
    ///
    /// let mut chars = y.chars();
    ///
    /// assert_eq!(Some('y'), chars.next()); // hindi 'y̆'
    /// assert_eq!(Some('\u{0306}'), chars.next());
    ///
    /// assert_eq!(None, chars.next());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chars(&self) -> Chars<'_> {
        Chars { iter: self.as_bytes().iter() }
    }

    /// Ibinabalik ang isang iterator sa mga [`char`] s ng isang hiwa ng string, at ang kanilang mga posisyon.
    ///
    /// Bilang isang string slice ay binubuo ng valid UTF-8, maaari naming umulit sa pamamagitan ng isang string slice sa pamamagitan [`char`].
    /// Ang pamamaraan na ito ay nagbabalik ng isang iterator ng parehong mga ito [`char`] s, pati na rin ang kanilang mga byte posisyon.
    ///
    /// Nagbibigay ang iterator ng mga tuple.Ang posisyon ay una, ang [`char`] ay pangalawa.
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// let word = "goodbye";
    ///
    /// let count = word.char_indices().count();
    /// assert_eq!(7, count);
    ///
    /// let mut char_indices = word.char_indices();
    ///
    /// assert_eq!(Some((0, 'g')), char_indices.next());
    /// assert_eq!(Some((1, 'o')), char_indices.next());
    /// assert_eq!(Some((2, 'o')), char_indices.next());
    /// assert_eq!(Some((3, 'd')), char_indices.next());
    /// assert_eq!(Some((4, 'b')), char_indices.next());
    /// assert_eq!(Some((5, 'y')), char_indices.next());
    /// assert_eq!(Some((6, 'e')), char_indices.next());
    ///
    /// assert_eq!(None, char_indices.next());
    /// ```
    ///
    /// Tandaan, maaaring hindi tumugma ang [`char`] sa iyong intuwisyon tungkol sa mga character:
    ///
    /// [`char`]: prim@char
    ///
    /// ```
    /// let yes = "y̆es";
    ///
    /// let mut char_indices = yes.char_indices();
    ///
    /// assert_eq!(Some((0, 'y')), char_indices.next()); // hindi (0, 'y̆')
    /// assert_eq!(Some((1, '\u{0306}')), char_indices.next());
    ///
    /// // tandaan ang 3 dito, ang huling character kinuha up ng dalawang bytes
    /// assert_eq!(Some((3, 'e')), char_indices.next());
    /// assert_eq!(Some((4, 's')), char_indices.next());
    ///
    /// assert_eq!(None, char_indices.next());
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn char_indices(&self) -> CharIndices<'_> {
        CharIndices { front_offset: 0, iter: self.chars() }
    }

    /// Isang iterator sa mga byte ng isang string slice.
    ///
    /// Bilang isang hiwa ng string ay binubuo ng isang pagkakasunud-sunod ng mga byte, maaari naming umulit sa pamamagitan ng isang hiwa ng string ng byte.
    /// Ang pamamaraang ito ay nagbabalik ng tulad ng isang umuulit.
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// let mut bytes = "bors".bytes();
    ///
    /// assert_eq!(Some(b'b'), bytes.next());
    /// assert_eq!(Some(b'o'), bytes.next());
    /// assert_eq!(Some(b'r'), bytes.next());
    /// assert_eq!(Some(b's'), bytes.next());
    ///
    /// assert_eq!(None, bytes.next());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn bytes(&self) -> Bytes<'_> {
        Bytes(self.as_bytes().iter().copied())
    }

    /// Hinahati ang isang hiwa ng string sa pamamagitan ng whitespace.
    ///
    /// Ang umuulit na ito ay ibabalik ay ibabalik ang mga hiwa ng string na mga sub-hiwa ng orihinal na hiwa ng string, na pinaghihiwalay ng anumang halaga ng whitespace.
    ///
    ///
    /// 'Whitespace' ay tinukoy alinsunod sa mga tuntunin ng Unicode Derived Core Property `White_Space`.
    /// Kung gusto mo lamang na split sa ASCII whitespace sa halip, gamitin [`split_ascii_whitespace`].
    ///
    /// [`split_ascii_whitespace`]: str::split_ascii_whitespace
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// let mut iter = "A few words".split_whitespace();
    ///
    /// assert_eq!(Some("A"), iter.next());
    /// assert_eq!(Some("few"), iter.next());
    /// assert_eq!(Some("words"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    /// Lahat ng uri ng whitespace ay isinasaalang-alang:
    ///
    /// ```
    /// let mut iter = " Mary   had\ta\u{2009}little  \n\t lamb".split_whitespace();
    /// assert_eq!(Some("Mary"), iter.next());
    /// assert_eq!(Some("had"), iter.next());
    /// assert_eq!(Some("a"), iter.next());
    /// assert_eq!(Some("little"), iter.next());
    /// assert_eq!(Some("lamb"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[stable(feature = "split_whitespace", since = "1.1.0")]
    #[inline]
    pub fn split_whitespace(&self) -> SplitWhitespace<'_> {
        SplitWhitespace { inner: self.split(IsWhitespace).filter(IsNotEmpty) }
    }

    /// Splits ng isang string slice sa pamamagitan ng ASCII whitespace.
    ///
    /// Ang umuulit na ito ay ibabalik ay ibabalik ang mga hiwa ng string na mga sub-hiwa ng orihinal na hiwa ng string, na pinaghihiwalay ng anumang halaga ng whitespace ng ASCII.
    ///
    ///
    /// Upang split sa pamamagitan ng Unicode `Whitespace` halip, gamitin [`split_whitespace`].
    ///
    /// [`split_whitespace`]: str::split_whitespace
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// let mut iter = "A few words".split_ascii_whitespace();
    ///
    /// assert_eq!(Some("A"), iter.next());
    /// assert_eq!(Some("few"), iter.next());
    /// assert_eq!(Some("words"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    /// Ang lahat ng mga uri ng whitespace ng ASCII ay isinasaalang-alang:
    ///
    /// ```
    /// let mut iter = " Mary   had\ta little  \n\t lamb".split_ascii_whitespace();
    /// assert_eq!(Some("Mary"), iter.next());
    /// assert_eq!(Some("had"), iter.next());
    /// assert_eq!(Some("a"), iter.next());
    /// assert_eq!(Some("little"), iter.next());
    /// assert_eq!(Some("lamb"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    #[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
    #[inline]
    pub fn split_ascii_whitespace(&self) -> SplitAsciiWhitespace<'_> {
        let inner =
            self.as_bytes().split(IsAsciiWhitespace).filter(BytesIsNotEmpty).map(UnsafeBytesToStr);
        SplitAsciiWhitespace { inner }
    }

    /// Ang isang iterator sa ibabaw ng linya ng isang string, tulad ng string hiwa.
    ///
    /// Linya ay natapos na may alinman sa isang newline (`\n`) o isang carriage return na may isang linya feed (`\r\n`).
    ///
    /// Ang huling pagtatapos ng linya ay opsyonal.
    /// Ang isang string na nagtatapos sa isang pangwakas na linya na nagtatapos ay magbabalik ng parehong mga linya bilang isang kung hindi man magkapareho ang string nang walang isang pangwakas na linya na nagtatapos.
    ///
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// let text = "foo\r\nbar\n\nbaz\n";
    /// let mut lines = text.lines();
    ///
    /// assert_eq!(Some("foo"), lines.next());
    /// assert_eq!(Some("bar"), lines.next());
    /// assert_eq!(Some(""), lines.next());
    /// assert_eq!(Some("baz"), lines.next());
    ///
    /// assert_eq!(None, lines.next());
    /// ```
    ///
    /// Hindi kinakailangan ang huling pagtatapos ng linya:
    ///
    /// ```
    /// let text = "foo\nbar\n\r\nbaz";
    /// let mut lines = text.lines();
    ///
    /// assert_eq!(Some("foo"), lines.next());
    /// assert_eq!(Some("bar"), lines.next());
    /// assert_eq!(Some(""), lines.next());
    /// assert_eq!(Some("baz"), lines.next());
    ///
    /// assert_eq!(None, lines.next());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn lines(&self) -> Lines<'_> {
        Lines(self.split_terminator('\n').map(LinesAnyMap))
    }

    /// Isang iterator sa mga linya ng isang string.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.4.0", reason = "use lines() instead now")]
    #[inline]
    #[allow(deprecated)]
    pub fn lines_any(&self) -> LinesAny<'_> {
        LinesAny(self.lines())
    }

    /// Nagbabalik ng isang iterator ng `u16` sa ibabaw ng string na naka-encode bilang UTF-16.
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// let text = "Zażółć gęślą jaźń";
    ///
    /// let utf8_len = text.len();
    /// let utf16_len = text.encode_utf16().count();
    ///
    /// assert!(utf16_len <= utf8_len);
    /// ```
    #[stable(feature = "encode_utf16", since = "1.8.0")]
    pub fn encode_utf16(&self) -> EncodeUtf16<'_> {
        EncodeUtf16 { chars: self.chars(), extra: 0 }
    }

    /// Ibinabalik ang `true` kung ang ibinigay na pattern ay tumutugma sa isang sub-slice ng string slice na ito.
    ///
    /// Ibinabalik ang `false` kung hindi.
    ///
    /// Ang [pattern] ay maaaring isang `&str`, [`char`], isang hiwa ng [`char`] s, o isang pagpapaandar o pagsasara na tumutukoy kung tumutugma ang isang character.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.contains("nana"));
    /// assert!(!bananas.contains("apples"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn contains<'a, P: Pattern<'a>>(&'a self, pat: P) -> bool {
        pat.is_contained_in(self)
    }

    /// Ibinabalik `true` kung ang ibinigay na pattern ay tumutugma sa isang prefix ng ang string na ito slice.
    ///
    /// Ibinabalik ang `false` kung hindi.
    ///
    /// Ang [pattern] ay maaaring isang `&str`, [`char`], isang hiwa ng [`char`] s, o isang pagpapaandar o pagsasara na tumutukoy kung tumutugma ang isang character.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.starts_with("bana"));
    /// assert!(!bananas.starts_with("nana"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn starts_with<'a, P: Pattern<'a>>(&'a self, pat: P) -> bool {
        pat.is_prefix_of(self)
    }

    /// Ibinabalik ang `true` kung ang ibinigay na pattern ay tumutugma sa isang panlapi ng hiwa ng string na ito.
    ///
    /// Ibinabalik ang `false` kung hindi.
    ///
    /// Ang [pattern] ay maaaring isang `&str`, [`char`], isang hiwa ng [`char`] s, o isang pagpapaandar o pagsasara na tumutukoy kung tumutugma ang isang character.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.ends_with("anas"));
    /// assert!(!bananas.ends_with("nana"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ends_with<'a, P>(&'a self, pat: P) -> bool
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        pat.is_suffix_of(self)
    }

    /// Ibinabalik ang byte index ng unang karakter ng hiwa ng string na tumutugma sa pattern.
    ///
    /// Ibinabalik ang [`None`] kung hindi tumutugma ang pattern.
    ///
    /// Ang [pattern] ay maaaring isang `&str`, [`char`], isang hiwa ng [`char`] s, o isang pagpapaandar o pagsasara na tumutukoy kung tumutugma ang isang character.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Mga simpleng pattern:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard Gepardi";
    ///
    /// assert_eq!(s.find('L'), Some(0));
    /// assert_eq!(s.find('é'), Some(14));
    /// assert_eq!(s.find("pard"), Some(17));
    /// ```
    ///
    /// Mas kumplikadong mga pattern gamit ang estilo at pagsasara na walang point:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// assert_eq!(s.find(char::is_whitespace), Some(5));
    /// assert_eq!(s.find(char::is_lowercase), Some(1));
    /// assert_eq!(s.find(|c: char| c.is_whitespace() || c.is_lowercase()), Some(1));
    /// assert_eq!(s.find(|c: char| (c < 'o') && (c > 'a')), Some(4));
    /// ```
    ///
    /// Hindi mahanap ang pattern:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// let x: &[_] = &['1', '2'];
    ///
    /// assert_eq!(s.find(x), None);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn find<'a, P: Pattern<'a>>(&'a self, pat: P) -> Option<usize> {
        pat.into_searcher(self).next_match().map(|(i, _)| i)
    }

    /// Ibinabalik ang byte index para sa unang character ng pinakamatuwid na pagtutugma ng pattern sa hiwa ng string na ito.
    ///
    /// Ibinabalik ang [`None`] kung hindi tumutugma ang pattern.
    ///
    /// Ang [pattern] ay maaaring isang `&str`, [`char`], isang hiwa ng [`char`] s, o isang pagpapaandar o pagsasara na tumutukoy kung tumutugma ang isang character.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Mga simpleng pattern:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard Gepardi";
    ///
    /// assert_eq!(s.rfind('L'), Some(13));
    /// assert_eq!(s.rfind('é'), Some(14));
    /// assert_eq!(s.rfind("pard"), Some(24));
    /// ```
    ///
    /// Mas kumplikadong mga pattern na may pagsasara:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// assert_eq!(s.rfind(char::is_whitespace), Some(12));
    /// assert_eq!(s.rfind(char::is_lowercase), Some(20));
    /// ```
    ///
    /// Hindi mahanap ang pattern:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// let x: &[_] = &['1', '2'];
    ///
    /// assert_eq!(s.rfind(x), None);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rfind<'a, P>(&'a self, pat: P) -> Option<usize>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        pat.into_searcher(self).next_match_back().map(|(i, _)| i)
    }

    /// Isang iterator sa mga substring ng string slice na ito, pinaghiwalay ng mga character na naitugma ng isang pattern.
    ///
    /// Ang [pattern] ay maaaring isang `&str`, [`char`], isang hiwa ng [`char`] s, o isang pagpapaandar o pagsasara na tumutukoy kung tumutugma ang isang character.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Pag-uugali ng Iterator
    ///
    /// Ang ibinalik na iterator ay magiging isang [`DoubleEndedIterator`] kung ang pattern ay nagbibigay-daan sa isang pabalik na paghahanap at forward/reverse paghahanap ay magbubunga ng parehong mga elemento.
    /// Ito ay totoo para sa, hal, [`char`], ngunit hindi para sa `&str`.
    ///
    /// Kung pinapayagan ng pattern ang isang pabalik na paghahanap ngunit ang mga resulta ay maaaring magkakaiba mula sa isang pasulong na paghahanap, maaaring magamit ang [`rsplit`] na pamamaraan.
    ///
    /// [`rsplit`]: str::rsplit
    ///
    /// # Examples
    ///
    /// Mga simpleng pattern:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".split(' ').collect();
    /// assert_eq!(v, ["Mary", "had", "a", "little", "lamb"]);
    ///
    /// let v: Vec<&str> = "".split('X').collect();
    /// assert_eq!(v, [""]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".split('X').collect();
    /// assert_eq!(v, ["lion", "", "tiger", "leopard"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".split("::").collect();
    /// assert_eq!(v, ["lion", "tiger", "leopard"]);
    ///
    /// let v: Vec<&str> = "abc1def2ghi".split(char::is_numeric).collect();
    /// assert_eq!(v, ["abc", "def", "ghi"]);
    ///
    /// let v: Vec<&str> = "lionXtigerXleopard".split(char::is_uppercase).collect();
    /// assert_eq!(v, ["lion", "tiger", "leopard"]);
    /// ```
    ///
    /// Kung ang pattern ay isang slice ng chars, hatiin sa bawat paglitaw ng alinman sa mga character:
    ///
    /// ```
    /// let v: Vec<&str> = "2020-11-03 23:59".split(&['-', ' ', ':', '@'][..]).collect();
    /// assert_eq!(v, ["2020", "11", "03", "23", "59"]);
    /// ```
    ///
    /// Isang mas kumplikadong pattern, gamit ang isang pagsasara:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".split(|c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["abc", "def", "ghi"]);
    /// ```
    ///
    /// Kung ang isang string ay naglalaman ng maraming magkadikit na separator, magtatapos ka ng walang laman na mga string sa output:
    ///
    /// ```
    /// let x = "||||a||b|c".to_string();
    /// let d: Vec<_> = x.split('|').collect();
    ///
    /// assert_eq!(d, &["", "", "", "", "a", "", "b", "c"]);
    /// ```
    ///
    /// Ang magkakadikit na mga separator ay pinaghihiwalay ng walang laman na string.
    ///
    /// ```
    /// let x = "(///)".to_string();
    /// let d: Vec<_> = x.split('/').collect();
    ///
    /// assert_eq!(d, &["(", "", "", ")"]);
    /// ```
    ///
    /// Panghiwalay sa simula o dulo ng isang string ay neighbored pamamagitan ng walang laman na string.
    ///
    /// ```
    /// let d: Vec<_> = "010".split("0").collect();
    /// assert_eq!(d, &["", "1", ""]);
    /// ```
    ///
    /// Kapag ang walang laman na string ay ginamit bilang isang separator, pinaghihiwalay nito ang bawat character sa string, kasama ang simula at pagtatapos ng string.
    ///
    /// ```
    /// let f: Vec<_> = "rust".split("").collect();
    /// assert_eq!(f, &["", "r", "u", "s", "t", ""]);
    /// ```
    ///
    /// Ang magkakadikit na mga separator ay maaaring humantong sa posibleng nakakagulat na pag-uugali kapag ang whitespace ay ginagamit bilang separator.Tama ang code na ito:
    ///
    /// ```
    /// let x = "    a  b c".to_string();
    /// let d: Vec<_> = x.split(' ').collect();
    ///
    /// assert_eq!(d, &["", "", "", "", "a", "", "b", "c"]);
    /// ```
    ///
    /// Ibinibigay sa iyo ng _not_:
    ///
    /// ```,ignore
    /// assert_eq!(d, &["a", "b", "c"]);
    /// ```
    ///
    /// Gumamit ng [`split_whitespace`] para sa pag-uugaling ito.
    ///
    /// [`split_whitespace`]: str::split_whitespace
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split<'a, P: Pattern<'a>>(&'a self, pat: P) -> Split<'a, P> {
        Split(SplitInternal {
            start: 0,
            end: self.len(),
            matcher: pat.into_searcher(self),
            allow_trailing_empty: true,
            finished: false,
        })
    }

    /// Isang iterator sa mga substring ng string slice na ito, pinaghiwalay ng mga character na naitugma ng isang pattern.
    /// Iba't ibang mula sa iterator na ginawa ng `split` sa `split_inclusive` na iyon ay iniiwan ang naitugmang bahagi bilang terminator ng substring.
    ///
    ///
    /// Ang [pattern] ay maaaring isang `&str`, [`char`], isang hiwa ng [`char`] s, o isang pagpapaandar o pagsasara na tumutukoy kung tumutugma ang isang character.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb\nlittle lamb\nlittle lamb."
    ///     .split_inclusive('\n').collect();
    /// assert_eq!(v, ["Mary had a little lamb\n", "little lamb\n", "little lamb."]);
    /// ```
    ///
    /// Kung ang huling elemento ng string ay itinutugma, na element ay isasaalang-alang ang terminator ng mga naunang substring.
    /// substring Iyon ay ang huling item ibinalik sa pamamagitan ng iterator.
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb\nlittle lamb\nlittle lamb.\n"
    ///     .split_inclusive('\n').collect();
    /// assert_eq!(v, ["Mary had a little lamb\n", "little lamb\n", "little lamb.\n"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive<'a, P: Pattern<'a>>(&'a self, pat: P) -> SplitInclusive<'a, P> {
        SplitInclusive(SplitInternal {
            start: 0,
            end: self.len(),
            matcher: pat.into_searcher(self),
            allow_trailing_empty: false,
            finished: false,
        })
    }

    /// Isang iterator sa mga substring ng ibinigay na hiwa ng string, na pinaghihiwalay ng mga character na naitugma ng isang pattern at nagbigay sa reverse order.
    ///
    /// Ang [pattern] ay maaaring isang `&str`, [`char`], isang hiwa ng [`char`] s, o isang pagpapaandar o pagsasara na tumutukoy kung tumutugma ang isang character.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Pag-uugali ng Iterator
    ///
    /// Nagbalik ang iterator ay nangangailangan na ang pattern ay sumusuporta sa isang reverse paghahanap, at ito ay magiging isang [`DoubleEndedIterator`] kung ang isang forward/reverse search magbubunga ng parehong elemento.
    ///
    ///
    /// Para sa iterating mula sa front, ang [`split`] paraan ay maaaring gamitin.
    ///
    /// [`split`]: str::split
    ///
    /// # Examples
    ///
    /// Mga simpleng pattern:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".rsplit(' ').collect();
    /// assert_eq!(v, ["lamb", "little", "a", "had", "Mary"]);
    ///
    /// let v: Vec<&str> = "".rsplit('X').collect();
    /// assert_eq!(v, [""]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".rsplit('X').collect();
    /// assert_eq!(v, ["leopard", "tiger", "", "lion"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".rsplit("::").collect();
    /// assert_eq!(v, ["leopard", "tiger", "lion"]);
    /// ```
    ///
    /// Isang mas kumplikadong pattern, gamit ang isang pagsasara:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".rsplit(|c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["ghi", "def", "abc"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplit<'a, P>(&'a self, pat: P) -> RSplit<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplit(self.split(pat).0)
    }

    /// Isang iterator sa mga substring ng ibinigay na slice ng string, na pinaghihiwalay ng mga character na naitugma ng isang pattern.
    ///
    /// Ang [pattern] ay maaaring isang `&str`, [`char`], isang hiwa ng [`char`] s, o isang pagpapaandar o pagsasara na tumutukoy kung tumutugma ang isang character.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// Katumbas ng [`split`], maliban sa sumusunod na substring ay nilaktawan kung walang laman.
    ///
    /// [`split`]: str::split
    ///
    /// Ang pamamaraang ito ay maaaring magamit para sa data ng string na _terminated_, sa halip na _separated_ sa pamamagitan ng isang pattern.
    ///
    /// # Pag-uugali ng Iterator
    ///
    /// Ang ibinalik na iterator ay magiging isang [`DoubleEndedIterator`] kung ang pattern ay nagbibigay-daan sa isang pabalik na paghahanap at forward/reverse paghahanap ay magbubunga ng parehong mga elemento.
    /// Ito ay totoo para sa, hal, [`char`], ngunit hindi para sa `&str`.
    ///
    /// Kung pinapayagan ng pattern ang isang pabalik na paghahanap ngunit ang mga resulta ay maaaring magkakaiba mula sa isang pasulong na paghahanap, maaaring magamit ang [`rsplit_terminator`] na pamamaraan.
    ///
    /// [`rsplit_terminator`]: str::rsplit_terminator
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// let v: Vec<&str> = "A.B.".split_terminator('.').collect();
    /// assert_eq!(v, ["A", "B"]);
    ///
    /// let v: Vec<&str> = "A..B..".split_terminator(".").collect();
    /// assert_eq!(v, ["A", "", "B", ""]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_terminator<'a, P: Pattern<'a>>(&'a self, pat: P) -> SplitTerminator<'a, P> {
        SplitTerminator(SplitInternal { allow_trailing_empty: false, ..self.split(pat).0 })
    }

    /// Isang iterator sa mga substring ng `self`, na pinaghihiwalay ng mga character na naitugma ng isang pattern at nagbigay sa reverse order.
    ///
    /// Ang [pattern] ay maaaring isang `&str`, [`char`], isang hiwa ng [`char`] s, o isang pagpapaandar o pagsasara na tumutukoy kung tumutugma ang isang character.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// Katumbas ng [`split`], maliban sa sumusunod na substring ay nilaktawan kung walang laman.
    ///
    /// [`split`]: str::split
    ///
    /// Ang pamamaraang ito ay maaaring magamit para sa data ng string na _terminated_, sa halip na _separated_ sa pamamagitan ng isang pattern.
    ///
    /// # Pag-uugali ng Iterator
    ///
    /// Nagbalik ang iterator ay nangangailangan na ang pattern ay sumusuporta sa isang reverse paghahanap, at ito ay double natapos kung ang isang forward/reverse search magbubunga ng parehong elemento.
    ///
    ///
    /// Para sa pag-ulit mula sa harap, maaaring magamit ang pamamaraang [`split_terminator`].
    ///
    /// [`split_terminator`]: str::split_terminator
    ///
    /// # Examples
    ///
    /// ```
    /// let v: Vec<&str> = "A.B.".rsplit_terminator('.').collect();
    /// assert_eq!(v, ["B", "A"]);
    ///
    /// let v: Vec<&str> = "A..B..".rsplit_terminator(".").collect();
    /// assert_eq!(v, ["", "B", "", "A"]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplit_terminator<'a, P>(&'a self, pat: P) -> RSplitTerminator<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplitTerminator(self.split_terminator(pat).0)
    }

    /// Ang isang iterator higit substrings ng ibinigay na string slice, na pinaghihiwalay ng isang pattern, limitado sa mga bumabalik na sa karamihan `n` item.
    ///
    /// Kung ang `n` substrings ay ibinalik, ang huling substring (ang `n`th substring) ay maglalaman ng natitirang string.
    ///
    /// Ang [pattern] ay maaaring isang `&str`, [`char`], isang hiwa ng [`char`] s, o isang pagpapaandar o pagsasara na tumutukoy kung tumutugma ang isang character.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Pag-uugali ng Iterator
    ///
    /// Ang naibalik na umuulit ay hindi dadalhin sa dobleng natapos, sapagkat hindi ito mabisa upang suportahan.
    ///
    /// Kung pinapayagan ng pattern ang isang pabalik na paghahanap, maaaring magamit ang [`rsplitn`] na pamamaraan.
    ///
    /// [`rsplitn`]: str::rsplitn
    ///
    /// # Examples
    ///
    /// Mga simpleng pattern:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lambda".splitn(3, ' ').collect();
    /// assert_eq!(v, ["Mary", "had", "a little lambda"]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".splitn(3, "X").collect();
    /// assert_eq!(v, ["lion", "", "tigerXleopard"]);
    ///
    /// let v: Vec<&str> = "abcXdef".splitn(1, 'X').collect();
    /// assert_eq!(v, ["abcXdef"]);
    ///
    /// let v: Vec<&str> = "".splitn(1, 'X').collect();
    /// assert_eq!(v, [""]);
    /// ```
    ///
    /// Isang mas kumplikadong pattern, gamit ang isang pagsasara:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".splitn(2, |c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["abc", "defXghi"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn<'a, P: Pattern<'a>>(&'a self, n: usize, pat: P) -> SplitN<'a, P> {
        SplitN(SplitNInternal { iter: self.split(pat).0, count: n })
    }

    /// Ang isang iterator sa paglipas ng mga substrings ng hiwa ng string na ito, na pinaghihiwalay ng isang pattern, na nagsisimula sa dulo ng string, na pinaghihigpitan na bumalik sa karamihan sa mga item na `n`.
    ///
    ///
    /// Kung ang `n` substrings ay ibinalik, ang huling substring (ang `n`th substring) ay maglalaman ng natitirang string.
    ///
    /// Ang [pattern] ay maaaring isang `&str`, [`char`], isang hiwa ng [`char`] s, o isang pagpapaandar o pagsasara na tumutukoy kung tumutugma ang isang character.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Pag-uugali ng Iterator
    ///
    /// Ang naibalik na umuulit ay hindi dadalhin sa dobleng natapos, sapagkat hindi ito mabisa upang suportahan.
    ///
    /// Para sa paghahati mula sa front, ang [`splitn`] paraan ay maaaring gamitin.
    ///
    /// [`splitn`]: str::splitn
    ///
    /// # Examples
    ///
    /// Mga simpleng pattern:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".rsplitn(3, ' ').collect();
    /// assert_eq!(v, ["lamb", "little", "Mary had a"]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".rsplitn(3, 'X').collect();
    /// assert_eq!(v, ["leopard", "tiger", "lionX"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".rsplitn(2, "::").collect();
    /// assert_eq!(v, ["leopard", "lion::tiger"]);
    /// ```
    ///
    /// Isang mas kumplikadong pattern, gamit ang isang pagsasara:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".rsplitn(2, |c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["ghi", "abc1def"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn<'a, P>(&'a self, n: usize, pat: P) -> RSplitN<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplitN(self.splitn(n, pat).0)
    }

    /// Hinahati ang string sa unang paglitaw ng tinukoy na delimiter at nagbabalik ng unlapi bago ang delimiter at panlapi pagkatapos ng delimiter.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("cfg".split_once('='), None);
    /// assert_eq!("cfg=foo".split_once('='), Some(("cfg", "foo")));
    /// assert_eq!("cfg=foo=bar".split_once('='), Some(("cfg", "foo=bar")));
    /// ```
    #[stable(feature = "str_split_once", since = "1.52.0")]
    #[inline]
    pub fn split_once<'a, P: Pattern<'a>>(&'a self, delimiter: P) -> Option<(&'a str, &'a str)> {
        let (start, end) = delimiter.into_searcher(self).next_match()?;
        Some((&self[..start], &self[end..]))
    }

    /// Hinahati ang string sa huling paglitaw ng tinukoy na delimiter at nagbabalik ng unlapi bago ang delimiter at panlapi pagkatapos ng delimiter.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("cfg".rsplit_once('='), None);
    /// assert_eq!("cfg=foo".rsplit_once('='), Some(("cfg", "foo")));
    /// assert_eq!("cfg=foo=bar".rsplit_once('='), Some(("cfg=foo", "bar")));
    /// ```
    #[stable(feature = "str_split_once", since = "1.52.0")]
    #[inline]
    pub fn rsplit_once<'a, P>(&'a self, delimiter: P) -> Option<(&'a str, &'a str)>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        let (start, end) = delimiter.into_searcher(self).next_match_back()?;
        Some((&self[..start], &self[end..]))
    }

    /// Isang iterator sa magkahiwalay na mga tugma ng isang pattern sa loob ng ibinigay na hiwa ng string.
    ///
    /// Ang [pattern] ay maaaring isang `&str`, [`char`], isang hiwa ng [`char`] s, o isang pagpapaandar o pagsasara na tumutukoy kung tumutugma ang isang character.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Pag-uugali ng Iterator
    ///
    /// Ang ibinalik na iterator ay magiging isang [`DoubleEndedIterator`] kung ang pattern ay nagbibigay-daan sa isang pabalik na paghahanap at forward/reverse paghahanap ay magbubunga ng parehong mga elemento.
    /// Ito ay totoo para sa, hal, [`char`], ngunit hindi para sa `&str`.
    ///
    /// Kung pinapayagan ng pattern ang isang pabalik na paghahanap ngunit ang mga resulta ay maaaring magkakaiba mula sa isang pasulong na paghahanap, maaaring magamit ang [`rmatches`] na pamamaraan.
    ///
    /// [`rmatches`]: str::matches
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// let v: Vec<&str> = "abcXXXabcYYYabc".matches("abc").collect();
    /// assert_eq!(v, ["abc", "abc", "abc"]);
    ///
    /// let v: Vec<&str> = "1abc2abc3".matches(char::is_numeric).collect();
    /// assert_eq!(v, ["1", "2", "3"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "str_matches", since = "1.2.0")]
    #[inline]
    pub fn matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> Matches<'a, P> {
        Matches(MatchesInternal(pat.into_searcher(self)))
    }

    /// Isang iterator sa magkahiwalay na mga tugma ng isang pattern sa loob ng hiwa ng string na ito, na nagbigay sa reverse order.
    ///
    /// Ang [pattern] ay maaaring isang `&str`, [`char`], isang hiwa ng [`char`] s, o isang pagpapaandar o pagsasara na tumutukoy kung tumutugma ang isang character.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Pag-uugali ng Iterator
    ///
    /// Nagbalik ang iterator ay nangangailangan na ang pattern ay sumusuporta sa isang reverse paghahanap, at ito ay magiging isang [`DoubleEndedIterator`] kung ang isang forward/reverse search magbubunga ng parehong elemento.
    ///
    ///
    /// Para sa pag-ulit mula sa harap, maaaring magamit ang pamamaraang [`matches`].
    ///
    /// [`matches`]: str::matches
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// let v: Vec<&str> = "abcXXXabcYYYabc".rmatches("abc").collect();
    /// assert_eq!(v, ["abc", "abc", "abc"]);
    ///
    /// let v: Vec<&str> = "1abc2abc3".rmatches(char::is_numeric).collect();
    /// assert_eq!(v, ["3", "2", "1"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "str_matches", since = "1.2.0")]
    #[inline]
    pub fn rmatches<'a, P>(&'a self, pat: P) -> RMatches<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RMatches(self.matches(pat).0)
    }

    /// Isang iterator sa magkahiwalay na mga tugma ng isang pattern sa loob ng hiwa ng string na ito pati na rin ang index kung saan nagsisimula ang laban.
    ///
    /// Para sa mga tugma ng `pat` sa loob ng `self` na nagsasapawan, ang mga indeks lamang na naaayon sa unang tugma ang naibalik.
    ///
    /// Ang [pattern] ay maaaring isang `&str`, [`char`], isang hiwa ng [`char`] s, o isang pagpapaandar o pagsasara na tumutukoy kung tumutugma ang isang character.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Pag-uugali ng Iterator
    ///
    /// Ang ibinalik na iterator ay magiging isang [`DoubleEndedIterator`] kung ang pattern ay nagbibigay-daan sa isang pabalik na paghahanap at forward/reverse paghahanap ay magbubunga ng parehong mga elemento.
    /// Ito ay totoo para sa, hal, [`char`], ngunit hindi para sa `&str`.
    ///
    /// Kung pinapayagan ng pattern ang isang pabalik na paghahanap ngunit ang mga resulta ay maaaring magkakaiba mula sa isang pasulong na paghahanap, maaaring magamit ang [`rmatch_indices`] na pamamaraan.
    ///
    /// [`rmatch_indices`]: str::match_indices
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// let v: Vec<_> = "abcXXXabcYYYabc".match_indices("abc").collect();
    /// assert_eq!(v, [(0, "abc"), (6, "abc"), (12, "abc")]);
    ///
    /// let v: Vec<_> = "1abcabc2".match_indices("abc").collect();
    /// assert_eq!(v, [(1, "abc"), (4, "abc")]);
    ///
    /// let v: Vec<_> = "ababa".match_indices("aba").collect();
    /// assert_eq!(v, [(0, "aba")]); // ang unang `aba` lamang
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "str_match_indices", since = "1.5.0")]
    #[inline]
    pub fn match_indices<'a, P: Pattern<'a>>(&'a self, pat: P) -> MatchIndices<'a, P> {
        MatchIndices(MatchIndicesInternal(pat.into_searcher(self)))
    }

    /// Ang isang iterator sa ibabaw ng magkahiwa-hiwalay na tumutugma sa isang pattern sa loob `self`, yielded sa reverse order kasama ang index ng mga tugma.
    ///
    /// Para sa mga tugma ng `pat` loob `self` na nago-overlap, tanging ang mga indeks ng naaayon sa huling tugma ay ibinalik.
    ///
    /// Ang [pattern] ay maaaring isang `&str`, [`char`], isang hiwa ng [`char`] s, o isang pagpapaandar o pagsasara na tumutukoy kung tumutugma ang isang character.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Pag-uugali ng Iterator
    ///
    /// Nagbalik ang iterator ay nangangailangan na ang pattern ay sumusuporta sa isang reverse paghahanap, at ito ay magiging isang [`DoubleEndedIterator`] kung ang isang forward/reverse search magbubunga ng parehong elemento.
    ///
    ///
    /// Para sa pag-ulit mula sa harap, maaaring magamit ang pamamaraang [`match_indices`].
    ///
    /// [`match_indices`]: str::match_indices
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// let v: Vec<_> = "abcXXXabcYYYabc".rmatch_indices("abc").collect();
    /// assert_eq!(v, [(12, "abc"), (6, "abc"), (0, "abc")]);
    ///
    /// let v: Vec<_> = "1abcabc2".rmatch_indices("abc").collect();
    /// assert_eq!(v, [(4, "abc"), (1, "abc")]);
    ///
    /// let v: Vec<_> = "ababa".rmatch_indices("aba").collect();
    /// assert_eq!(v, [(2, "aba")]); // ang huling `aba` lamang
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "str_match_indices", since = "1.5.0")]
    #[inline]
    pub fn rmatch_indices<'a, P>(&'a self, pat: P) -> RMatchIndices<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RMatchIndices(self.match_indices(pat).0)
    }

    /// Ibinabalik ng isang string slice sa mga nangungunang at trailing whitespace inalis.
    ///
    /// 'Whitespace' ay tinukoy alinsunod sa mga tuntunin ng Unicode Derived Core Property `White_Space`.
    ///
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!("Hello\tworld", s.trim());
    /// ```
    #[inline]
    #[must_use = "this returns the trimmed string as a slice, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn trim(&self) -> &str {
        self.trim_matches(|c: char| c.is_whitespace())
    }

    /// Nagbabalik ng isang hiwa ng string na tinanggal ang nangungunang whitespace.
    ///
    /// 'Whitespace' ay tinukoy alinsunod sa mga tuntunin ng Unicode Derived Core Property `White_Space`.
    ///
    /// # Direksyon ng teksto
    ///
    /// Ang isang string ay isang pagkakasunud-sunod ng mga byte.
    /// `start` sa kontekstong ito ay nangangahulugang ang unang posisyon ng byte string na iyon;para sa isang kaliwa-sa-kanang wika tulad ng Ingles o Ruso, ito ay kaliwang bahagi, at para sa mga kaliwa-sa-kaliwang wika tulad ng Arabe o Hebrew, ito ang magiging kanang bahagi.
    ///
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    /// assert_eq!("Hello\tworld\t", s.trim_start());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English  ";
    /// assert!(Some('E') == s.trim_start().chars().next());
    ///
    /// let s = "  עברית  ";
    /// assert!(Some('ע') == s.trim_start().chars().next());
    /// ```
    ///
    ///
    #[inline]
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_start(&self) -> &str {
        self.trim_start_matches(|c: char| c.is_whitespace())
    }

    /// Nagbabalik ng isang hiwa ng string na tinanggal ang sumusunod na whitespace.
    ///
    /// 'Whitespace' ay tinukoy alinsunod sa mga tuntunin ng Unicode Derived Core Property `White_Space`.
    ///
    /// # Direksyon ng teksto
    ///
    /// Ang isang string ay isang pagkakasunud-sunod ng mga byte.
    /// `end` sa kontekstong ito ay nangangahulugang ang huling posisyon ng byte string na iyon;para sa isang kaliwa-sa-kanang wika tulad ng Ingles o Ruso, ito ay magiging kanang bahagi, at para sa mga kanan-sa-kaliwang wika tulad ng Arabe o Hebrew, ito ang kaliwang bahagi.
    ///
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    /// assert_eq!(" Hello\tworld", s.trim_end());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English  ";
    /// assert!(Some('h') == s.trim_end().chars().rev().next());
    ///
    /// let s = "  עברית  ";
    /// assert!(Some('ת') == s.trim_end().chars().rev().next());
    /// ```
    ///
    ///
    #[inline]
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_end(&self) -> &str {
        self.trim_end_matches(|c: char| c.is_whitespace())
    }

    /// Nagbabalik ng isang hiwa ng string na tinanggal ang nangungunang whitespace.
    ///
    /// 'Whitespace' ay tinukoy alinsunod sa mga tuntunin ng Unicode Derived Core Property `White_Space`.
    ///
    /// # Direksyon ng teksto
    ///
    /// Ang isang string ay isang pagkakasunud-sunod ng mga byte.
    /// 'Left' sa ganitong konteksto ay nangangahulugan na ang unang posisyon na iyon byte string;para sa isang wikang tulad ng Arabe o Hebrew na 'kanan sa kaliwa' kaysa 'kaliwa pakanan', ito ang magiging panig ng _right_, hindi sa kaliwa.
    ///
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!("Hello\tworld\t", s.trim_left());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English";
    /// assert!(Some('E') == s.trim_left().chars().next());
    ///
    /// let s = "  עברית";
    /// assert!(Some('ע') == s.trim_left().chars().next());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_start`",
        suggestion = "trim_start"
    )]
    pub fn trim_left(&self) -> &str {
        self.trim_start()
    }

    /// Nagbabalik ng isang hiwa ng string na tinanggal ang sumusunod na whitespace.
    ///
    /// 'Whitespace' ay tinukoy alinsunod sa mga tuntunin ng Unicode Derived Core Property `White_Space`.
    ///
    /// # Direksyon ng teksto
    ///
    /// Ang isang string ay isang pagkakasunud-sunod ng mga byte.
    /// 'Right' sa kontekstong ito ay nangangahulugang ang huling posisyon ng byte string na iyon;para sa isang wikang tulad ng Arabe o Hebrew na 'kanan sa kaliwa' kaysa 'kaliwa pakanan', ito ang magiging panig ng _left_, hindi ang kanan.
    ///
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!(" Hello\tworld", s.trim_right());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "English  ";
    /// assert!(Some('h') == s.trim_right().chars().rev().next());
    ///
    /// let s = "עברית  ";
    /// assert!(Some('ת') == s.trim_right().chars().rev().next());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_end`",
        suggestion = "trim_end"
    )]
    pub fn trim_right(&self) -> &str {
        self.trim_end()
    }

    /// Nagbabalik ng isang string slice sa lahat ng prefix at suffix na tumutugma sa isang pattern ng paulit-ulit inalis.
    ///
    /// Ang [pattern] ay maaaring isang [`char`], isang hiwa ng [`char`] s, o isang pagpapaandar o pagsasara na tumutukoy kung ang isang character ay tumutugma.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Mga simpleng pattern:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_matches('1'), "foo1bar");
    /// assert_eq!("123foo1bar123".trim_matches(char::is_numeric), "foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_matches(x), "foo1bar");
    /// ```
    ///
    /// Isang mas kumplikadong pattern, gamit ang isang pagsasara:
    ///
    /// ```
    /// assert_eq!("1foo1barXX".trim_matches(|c| c == '1' || c == 'X'), "foo1bar");
    /// ```
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn trim_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: DoubleEndedSearcher<'a>>,
    {
        let mut i = 0;
        let mut j = 0;
        let mut matcher = pat.into_searcher(self);
        if let Some((a, b)) = matcher.next_reject() {
            i = a;
            j = b; // Alalahanin ang pinakamaagang kilalang laban, iwasto ito sa ibaba kung
            // ang huling laban ay iba
        }
        if let Some((_, b)) = matcher.next_reject_back() {
            j = b;
        }
        // KALIGTASAN: Ang `Searcher` ay kilalang bumalik sa wastong mga indeks.
        unsafe { self.get_unchecked(i..j) }
    }

    /// Nagbabalik ng isang hiwa ng string kasama ang lahat ng mga unlapi na tumutugma sa isang pattern na paulit-ulit na tinanggal.
    ///
    /// Ang [pattern] ay maaaring isang `&str`, [`char`], isang hiwa ng [`char`] s, o isang pagpapaandar o pagsasara na tumutukoy kung tumutugma ang isang character.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Direksyon ng teksto
    ///
    /// Ang isang string ay isang pagkakasunud-sunod ng mga byte.
    /// `start` sa kontekstong ito ay nangangahulugang ang unang posisyon ng byte string na iyon;para sa isang kaliwa-sa-kanang wika tulad ng Ingles o Ruso, ito ay kaliwang bahagi, at para sa mga kaliwa-sa-kaliwang wika tulad ng Arabe o Hebrew, ito ang magiging kanang bahagi.
    ///
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_start_matches('1'), "foo1bar11");
    /// assert_eq!("123foo1bar123".trim_start_matches(char::is_numeric), "foo1bar123");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_start_matches(x), "foo1bar12");
    /// ```
    ///
    ///
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_start_matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> &'a str {
        let mut i = self.len();
        let mut matcher = pat.into_searcher(self);
        if let Some((a, _)) = matcher.next_reject() {
            i = a;
        }
        // KALIGTASAN: Ang `Searcher` ay kilalang bumalik sa wastong mga indeks.
        unsafe { self.get_unchecked(i..self.len()) }
    }

    /// Nagbabalik ng isang hiwa ng string na tinanggal ang unlapi.
    ///
    /// Kung ang string ay nagsisimula sa pattern `prefix`, ibabalik ang substring pagkatapos ng unlapi, nakabalot sa `Some`.
    /// Hindi tulad ng `trim_start_matches`, tinanggal ng pamamaraang ito nang eksakto nang isang beses ang unlapi.
    ///
    /// Kung ang string ay hindi nagsisimula sa `prefix`, ibabalik ang `None`.
    ///
    /// Ang [pattern] ay maaaring isang `&str`, [`char`], isang hiwa ng [`char`] s, o isang pagpapaandar o pagsasara na tumutukoy kung tumutugma ang isang character.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("foo:bar".strip_prefix("foo:"), Some("bar"));
    /// assert_eq!("foo:bar".strip_prefix("bar"), None);
    /// assert_eq!("foofoo".strip_prefix("foo"), Some("foo"));
    /// ```
    #[must_use = "this returns the remaining substring as a new slice, \
                  without modifying the original"]
    #[stable(feature = "str_strip", since = "1.45.0")]
    pub fn strip_prefix<'a, P: Pattern<'a>>(&'a self, prefix: P) -> Option<&'a str> {
        prefix.strip_prefix_of(self)
    }

    /// Nagbabalik ng isang hiwa ng string na tinanggal ang panlapi.
    ///
    /// Kung ang mga dulo ng string na may pattern `suffix`, nagbabalik ang substring bago ang suffix, nakabalot sa `Some`.
    /// Hindi tulad ng `trim_end_matches`, tinanggal ng pamamaraang ito ang eksaktong panlapi nang sabay-sabay.
    ///
    /// Kung ang string ay hindi nagtatapos sa `suffix`, ibabalik ang `None`.
    ///
    /// Ang [pattern] ay maaaring isang `&str`, [`char`], isang hiwa ng [`char`] s, o isang pagpapaandar o pagsasara na tumutukoy kung tumutugma ang isang character.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("bar:foo".strip_suffix(":foo"), Some("bar"));
    /// assert_eq!("bar:foo".strip_suffix("bar"), None);
    /// assert_eq!("foofoo".strip_suffix("foo"), Some("foo"));
    /// ```
    #[must_use = "this returns the remaining substring as a new slice, \
                  without modifying the original"]
    #[stable(feature = "str_strip", since = "1.45.0")]
    pub fn strip_suffix<'a, P>(&'a self, suffix: P) -> Option<&'a str>
    where
        P: Pattern<'a>,
        <P as Pattern<'a>>::Searcher: ReverseSearcher<'a>,
    {
        suffix.strip_suffix_of(self)
    }

    /// Nagbabalik ng isang hiwa ng string sa lahat ng mga panlapi na tumutugma sa isang pattern na paulit-ulit na tinanggal.
    ///
    /// Ang [pattern] ay maaaring isang `&str`, [`char`], isang hiwa ng [`char`] s, o isang pagpapaandar o pagsasara na tumutukoy kung tumutugma ang isang character.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Direksyon ng teksto
    ///
    /// Ang isang string ay isang pagkakasunud-sunod ng mga byte.
    /// `end` sa kontekstong ito ay nangangahulugang ang huling posisyon ng byte string na iyon;para sa isang kaliwa-sa-kanang wika tulad ng Ingles o Ruso, ito ay magiging kanang bahagi, at para sa mga kanan-sa-kaliwang wika tulad ng Arabe o Hebrew, ito ang kaliwang bahagi.
    ///
    ///
    /// # Examples
    ///
    /// Mga simpleng pattern:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_end_matches('1'), "11foo1bar");
    /// assert_eq!("123foo1bar123".trim_end_matches(char::is_numeric), "123foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_end_matches(x), "12foo1bar");
    /// ```
    ///
    /// Isang mas kumplikadong pattern, gamit ang isang pagsasara:
    ///
    /// ```
    /// assert_eq!("1fooX".trim_end_matches(|c| c == '1' || c == 'X'), "1foo");
    /// ```
    ///
    ///
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_end_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        let mut j = 0;
        let mut matcher = pat.into_searcher(self);
        if let Some((_, b)) = matcher.next_reject_back() {
            j = b;
        }
        // KALIGTASAN: Ang `Searcher` ay kilalang bumalik sa wastong mga indeks.
        unsafe { self.get_unchecked(0..j) }
    }

    /// Nagbabalik ng isang hiwa ng string kasama ang lahat ng mga unlapi na tumutugma sa isang pattern na paulit-ulit na tinanggal.
    ///
    /// Ang [pattern] ay maaaring isang `&str`, [`char`], isang hiwa ng [`char`] s, o isang pagpapaandar o pagsasara na tumutukoy kung tumutugma ang isang character.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Direksyon ng teksto
    ///
    /// Ang isang string ay isang pagkakasunud-sunod ng mga byte.
    /// 'Left' sa ganitong konteksto ay nangangahulugan na ang unang posisyon na iyon byte string;para sa isang wikang tulad ng Arabe o Hebrew na 'kanan sa kaliwa' kaysa 'kaliwa pakanan', ito ang magiging panig ng _right_, hindi sa kaliwa.
    ///
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_left_matches('1'), "foo1bar11");
    /// assert_eq!("123foo1bar123".trim_left_matches(char::is_numeric), "foo1bar123");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_left_matches(x), "foo1bar12");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_start_matches`",
        suggestion = "trim_start_matches"
    )]
    pub fn trim_left_matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> &'a str {
        self.trim_start_matches(pat)
    }

    /// Nagbabalik ng isang hiwa ng string sa lahat ng mga panlapi na tumutugma sa isang pattern na paulit-ulit na tinanggal.
    ///
    /// Ang [pattern] ay maaaring isang `&str`, [`char`], isang hiwa ng [`char`] s, o isang pagpapaandar o pagsasara na tumutukoy kung tumutugma ang isang character.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Direksyon ng teksto
    ///
    /// Ang isang string ay isang pagkakasunud-sunod ng mga byte.
    /// 'Right' sa kontekstong ito ay nangangahulugang ang huling posisyon ng byte string na iyon;para sa isang wikang tulad ng Arabe o Hebrew na 'kanan sa kaliwa' kaysa 'kaliwa pakanan', ito ang magiging panig ng _left_, hindi ang kanan.
    ///
    ///
    /// # Examples
    ///
    /// Mga simpleng pattern:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_right_matches('1'), "11foo1bar");
    /// assert_eq!("123foo1bar123".trim_right_matches(char::is_numeric), "123foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_right_matches(x), "12foo1bar");
    /// ```
    ///
    /// Isang mas kumplikadong pattern, gamit ang isang pagsasara:
    ///
    /// ```
    /// assert_eq!("1fooX".trim_right_matches(|c| c == '1' || c == 'X'), "1foo");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_end_matches`",
        suggestion = "trim_end_matches"
    )]
    pub fn trim_right_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        self.trim_end_matches(pat)
    }

    /// Ginagawa ang hiwa ng string na ito sa ibang uri.
    ///
    /// Dahil ang `parse` ay napakalawak, maaari itong maging sanhi ng mga problema sa paghihinuha ng uri.
    /// Gaya ng nabanggit, `parse` ay isa sa mga ilang beses makikita mo ang syntax affectionately kilala bilang ang 'turbofish': `::<>`.
    ///
    /// Tinutulungan nito ang inferensi algorithm na maunawaan kung aling uri ang sinusubukan mong i-parse.
    ///
    /// `parse` ma-parse sa anumang uri na nagpapatupad ng [`FromStr`] trait.
    ///

    /// # Errors
    ///
    /// Ibabalik ang [`Err`] kung hindi posible na mai-parse ang hiwa ng string na ito sa nais na uri.
    ///
    ///
    /// [`Err`]: FromStr::Err
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit
    ///
    /// ```
    /// let four: u32 = "4".parse().unwrap();
    ///
    /// assert_eq!(4, four);
    /// ```
    ///
    /// Paggamit ng 'turbofish' sa halip na anotasyon ng `four`:
    ///
    /// ```
    /// let four = "4".parse::<u32>();
    ///
    /// assert_eq!(Ok(4), four);
    /// ```
    ///
    /// Nabigong mai-parse:
    ///
    /// ```
    /// let nope = "j".parse::<u32>();
    ///
    /// assert!(nope.is_err());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn parse<F: FromStr>(&self) -> Result<F, F::Err> {
        FromStr::from_str(self)
    }

    /// Ang mga tseke kung ang lahat ng mga character sa ang string na ito ay sa loob ng hanay ASCII.
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = "hello!\n";
    /// let non_ascii = "Grüße, Jürgen ❤";
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        // Maaari naming gamutin ang bawat byte bilang character dito: ang lahat ng mga character na multibyte ay nagsisimula sa isang byte na wala sa saklaw ng ascii, kaya titigil na kami doon.
        //
        //
        self.as_bytes().is_ascii()
    }

    /// Sinusuri na ang dalawang mga string ay isang ASCII case-insensitive match.
    ///
    /// Kapareho ng `to_ascii_lowercase(a) == to_ascii_lowercase(b)`, ngunit nang walang paglalaan at pagkopya ng mga pansamantala.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert!("Ferris".eq_ignore_ascii_case("FERRIS"));
    /// assert!("Ferrös".eq_ignore_ascii_case("FERRöS"));
    /// assert!(!"Ferrös".eq_ignore_ascii_case("FERRÖS"));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &str) -> bool {
        self.as_bytes().eq_ignore_ascii_case(other.as_bytes())
    }

    /// Kino-convert ang string na ito sa kanyang ASCII upper case katumbas in-lugar.
    ///
    /// Ang mga titik ng ASCII 'a' hanggang 'z' ay nai-map sa 'A' hanggang 'Z', ngunit ang mga hindi ASCII na titik ay hindi nagbabago.
    ///
    /// Upang ibalik ang isang bagong na-uppercased na halaga nang hindi binabago ang mayroon nang, gamitin ang [`to_ascii_uppercase()`].
    ///
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("Grüße, Jürgen ❤");
    ///
    /// s.make_ascii_uppercase();
    ///
    /// assert_eq!("GRüßE, JüRGEN ❤", s);
    /// ```
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        // KALIGTASAN: ligtas sapagkat nagpapadala kami ng dalawang uri na may parehong layout.
        let me = unsafe { self.as_bytes_mut() };
        me.make_ascii_uppercase()
    }

    /// Ino-convert ang string na ito sa ASCII na mas mababang kaso na katumbas na lugar.
    ///
    /// ASCII titik 'A' na 'Z' ay nama-map sa 'a' na 'z', ngunit hindi ASCII mga titik ay hindi magbabago.
    ///
    /// Upang maibalik ang isang bagong nabayarang halaga nang hindi binabago ang mayroon nang, gamitin ang [`to_ascii_lowercase()`].
    ///
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("GRÜßE, JÜRGEN ❤");
    ///
    /// s.make_ascii_lowercase();
    ///
    /// assert_eq!("grÜße, jÜrgen ❤", s);
    /// ```
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        // KALIGTASAN: ligtas sapagkat nagpapadala kami ng dalawang uri na may parehong layout.
        let me = unsafe { self.as_bytes_mut() };
        me.make_ascii_lowercase()
    }

    /// Ibalik ang isang iterator na escapes sa bawat char sa `self` na may [`char::escape_debug`].
    ///
    ///
    /// Note: ang mga pinalawak lamang na grapheme codepoints na nagsisimula sa string ay makakatakas.
    ///
    /// # Examples
    ///
    /// Bilang isang iterator:
    ///
    /// ```
    /// for c in "❤\n!".escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Direktang paggamit ng `println!`:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_debug());
    /// ```
    ///
    /// Ang parehong ay katumbas ng:
    ///
    /// ```
    /// println!("❤\\n!");
    /// ```
    ///
    /// Paggamit ng `to_string`:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_debug().to_string(), "❤\\n!");
    /// ```
    ///
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_debug(&self) -> EscapeDebug<'_> {
        let mut chars = self.chars();
        EscapeDebug {
            inner: chars
                .next()
                .map(|first| first.escape_debug_ext(true))
                .into_iter()
                .flatten()
                .chain(chars.flat_map(CharEscapeDebugContinue)),
        }
    }

    /// Ibalik ang isang iterator na makatakas sa bawat char sa `self` gamit ang [`char::escape_default`].
    ///
    ///
    /// # Examples
    ///
    /// Bilang isang iterator:
    ///
    /// ```
    /// for c in "❤\n!".escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Direktang paggamit ng `println!`:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_default());
    /// ```
    ///
    /// Ang parehong ay katumbas ng:
    ///
    /// ```
    /// println!("\\u{{2764}}\\n!");
    /// ```
    ///
    /// Paggamit ng `to_string`:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_default().to_string(), "\\u{2764}\\n!");
    /// ```
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_default(&self) -> EscapeDefault<'_> {
        EscapeDefault { inner: self.chars().flat_map(CharEscapeDefault) }
    }

    /// Ibalik ang isang iterator na makatakas sa bawat char sa `self` gamit ang [`char::escape_unicode`].
    ///
    ///
    /// # Examples
    ///
    /// Bilang isang iterator:
    ///
    /// ```
    /// for c in "❤\n!".escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Direktang paggamit ng `println!`:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_unicode());
    /// ```
    ///
    /// Ang parehong ay katumbas ng:
    ///
    /// ```
    /// println!("\\u{{2764}}\\u{{a}}\\u{{21}}");
    /// ```
    ///
    /// Paggamit ng `to_string`:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_unicode().to_string(), "\\u{2764}\\u{a}\\u{21}");
    /// ```
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_unicode(&self) -> EscapeUnicode<'_> {
        EscapeUnicode { inner: self.chars().flat_map(CharEscapeUnicode) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<[u8]> for str {
    #[inline]
    fn as_ref(&self) -> &[u8] {
        self.as_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Default for &str {
    /// Lumilikha ng isang walang laman str
    #[inline]
    fn default() -> Self {
        ""
    }
}

#[stable(feature = "default_mut_str", since = "1.28.0")]
impl Default for &mut str {
    /// Lumilikha ng isang walang laman na mutable str
    #[inline]
    fn default() -> Self {
        // KALIGTASAN: Ang walang laman na string ay wastong UTF-8.
        unsafe { from_utf8_unchecked_mut(&mut []) }
    }
}

impl_fn_for_zst! {
    /// Isang pangalan, cloneable fn na uri
    #[derive(Clone)]
    struct LinesAnyMap impl<'a> Fn = |line: &'a str| -> &'a str {
        let l = line.len();
        if l > 0 && line.as_bytes()[l - 1] == b'\r' { &line[0 .. l - 1] }
        else { line }
    };

    #[derive(Clone)]
    struct CharEscapeDebugContinue impl Fn = |c: char| -> char::EscapeDebug {
        c.escape_debug_ext(false)
    };

    #[derive(Clone)]
    struct CharEscapeUnicode impl Fn = |c: char| -> char::EscapeUnicode {
        c.escape_unicode()
    };
    #[derive(Clone)]
    struct CharEscapeDefault impl Fn = |c: char| -> char::EscapeDefault {
        c.escape_default()
    };

    #[derive(Clone)]
    struct IsWhitespace impl Fn = |c: char| -> bool {
        c.is_whitespace()
    };

    #[derive(Clone)]
    struct IsAsciiWhitespace impl Fn = |byte: &u8| -> bool {
        byte.is_ascii_whitespace()
    };

    #[derive(Clone)]
    struct IsNotEmpty impl<'a, 'b> Fn = |s: &'a &'b str| -> bool {
        !s.is_empty()
    };

    #[derive(Clone)]
    struct BytesIsNotEmpty impl<'a, 'b> Fn = |s: &'a &'b [u8]| -> bool {
        !s.is_empty()
    };

    #[derive(Clone)]
    struct UnsafeBytesToStr impl<'a> Fn = |bytes: &'a [u8]| -> &'a str {
        // KALIGTASAN: hindi ligtas
        unsafe { from_utf8_unchecked(bytes) }
    };
}