//! Ang string Pattern API.
//!
//! Nagbibigay ang pattern API ng isang generic na mekanismo para sa paggamit ng iba't ibang mga uri ng pattern kapag naghahanap sa pamamagitan ng isang string.
//!
//! Para sa karagdagang detalye, tingnan ang traits [`Pattern`], [`Searcher`], [`ReverseSearcher`], at [`DoubleEndedSearcher`].
//!
//! Bagaman hindi matatag ang API na ito, nakalantad ito sa pamamagitan ng matatag na mga API sa [`str`] na uri.
//!
//! # Examples
//!
//! [`Pattern`] ay [implemented][pattern-impls] sa matatag na API para sa [`&str`][`str`], [`char`], mga hiwa ng [`char`], at mga pagpapaandar at pagsasara na nagpapatupad ng `FnMut(char) -> bool`.
//!
//!
//! ```
//! let s = "Can you find a needle in a haystack?";
//!
//! // &str pattern
//! assert_eq!(s.find("you"), Some(4));
//! // pattern ng char
//! assert_eq!(s.find('n'), Some(2));
//! // hiwa ng pattern ng chars
//! assert_eq!(s.find(&['a', 'e', 'i', 'o', 'u'][..]), Some(1));
//! // pattern ng pagsasara
//! assert_eq!(s.find(|c: char| c.is_ascii_punctuation()), Some(35));
//! ```
//!
//! [pattern-impls]: Pattern#implementors
//!
//!
//!
//!

#![unstable(
    feature = "pattern",
    reason = "API not fully fleshed out and ready to be stabilized",
    issue = "27721"
)]

use crate::cmp;
use crate::fmt;
use crate::slice::memchr;

// Pattern

/// Isang pattern ng string.
///
/// Ang isang `Pattern<'a>` ay nagpapahayag na ang uri ng pagpapatupad ay maaaring magamit bilang isang pattern ng string para sa paghahanap sa isang [`&'a str`][str].
///
/// Halimbawa, ang parehong `'a'` at `"aa"` ay mga pattern na tutugma sa index `1` sa string `"baaaab"`.
///
/// Ang trait mismo ay kumikilos bilang isang tagabuo para sa isang nauugnay na uri ng [`Searcher`], na gumagawa ng aktwal na gawain ng paghahanap ng mga paglitaw ng pattern sa isang string.
///
///
/// Nakasalalay sa uri ng pattern, maaaring magbago ang pag-uugali ng mga pamamaraan tulad ng [`str::find`] at [`str::contains`].
/// Inilalarawan ng talahanayan sa ibaba ang ilan sa mga pag-uugaling iyon.
///
/// | Pattern type             | Match condition                           |
/// |--------------------------|-------------------------------------------|
/// | `&str`                   | is substring                              |
/// | `char`                   | is contained in string                    |
/// | `&[char]`                | any char in slice is contained in string  |
/// | `F: FnMut(char) -> bool` | `F` returns `true` for a char in string   |
/// | `&&str`                  | is substring                              |
/// | `&String`                | is substring                              |
///
/// # Examples
///
/// ```
/// // &str
/// assert_eq!("abaaa".find("ba"), Some(1));
/// assert_eq!("abaaa".find("bac"), None);
///
/// // char
/// assert_eq!("abaaa".find('a'), Some(0));
/// assert_eq!("abaaa".find('b'), Some(1));
/// assert_eq!("abaaa".find('c'), None);
///
/// // &[char]
/// assert_eq!("ab".find(&['b', 'a'][..]), Some(0));
/// assert_eq!("abaaa".find(&['a', 'z'][..]), Some(0));
/// assert_eq!("abaaa".find(&['c', 'd'][..]), None);
///
/// // FnMut(char) -> bool
/// assert_eq!("abcdef_z".find(|ch| ch > 'd' && ch < 'y'), Some(4));
/// assert_eq!("abcddd_z".find(|ch| ch > 'd' && ch < 'y'), None);
/// ```
///
///
///
///
pub trait Pattern<'a>: Sized {
    /// Kaugnay na naghahanap para sa pattern na ito
    type Searcher: Searcher<'a>;

    /// Binubuo ang nauugnay na naghahanap mula sa `self` at ang `haystack` upang maghanap.
    ///
    fn into_searcher(self, haystack: &'a str) -> Self::Searcher;

    /// Sinusuri kung tumutugma ang pattern saanman sa haystack
    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        self.into_searcher(haystack).next_match().is_some()
    }

    /// Sinusuri kung tumutugma ang pattern sa harap ng haystack
    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        matches!(self.into_searcher(haystack).next(), SearchStep::Match(0, _))
    }

    /// Sinusuri kung tumutugma ang pattern sa likod ng haystack
    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        matches!(self.into_searcher(haystack).next_back(), SearchStep::Match(_, j) if haystack.len() == j)
    }

    /// Tinatanggal ang pattern mula sa harap ng haystack, kung tumutugma ito.
    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        if let SearchStep::Match(start, len) = self.into_searcher(haystack).next() {
            debug_assert_eq!(
                start, 0,
                "The first search step from Searcher \
                 must include the first character"
            );
            // KALIGTASAN: Ang `Searcher` ay kilalang bumalik sa wastong mga indeks.
            unsafe { Some(haystack.get_unchecked(len..)) }
        } else {
            None
        }
    }

    /// Tinatanggal ang mga pattern mula sa likod ng mandala ng dayami, kung tumutugma ito.
    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        if let SearchStep::Match(start, end) = self.into_searcher(haystack).next_back() {
            debug_assert_eq!(
                end,
                haystack.len(),
                "The first search step from ReverseSearcher \
                 must include the last character"
            );
            // KALIGTASAN: Ang `Searcher` ay kilalang bumalik sa wastong mga indeks.
            unsafe { Some(haystack.get_unchecked(..start)) }
        } else {
            None
        }
    }
}

// Searcher

/// Magreresulta ng pagtawag [`Searcher::next()`] o [`ReverseSearcher::next_back()`].
#[derive(Copy, Clone, Eq, PartialEq, Debug)]
pub enum SearchStep {
    /// Nagpapahayag na ang isang tugma ng mga pattern ay natagpuan sa `haystack[a..b]`.
    ///
    Match(usize, usize),
    /// Ipinapahiwatig na ang `haystack[a..b]` ay tinanggihan bilang isang posibleng tugma ng pattern.
    ///
    /// Tandaan na maaaring may higit sa isang `Reject` sa pagitan ng dalawang `Match`es, walang kinakailangan para sa kanila na pagsamahin sa isa.
    ///
    ///
    Reject(usize, usize),
    /// Ipinapahiwatig na ang bawat byte ng haystack ay nabisita, na nagtatapos sa pag-ulit.
    ///
    Done,
}

/// Isang naghahanap para sa isang pattern ng string.
///
/// Ang trait na ito ay nagbibigay ng mga pamamaraan para sa paghahanap para sa mga hindi nagsasapawan na mga tugma ng isang pattern na nagsisimula sa harap na (left) ng isang string.
///
/// Ito ay ipinatupad sa pamamagitan nauugnay `Searcher` uri ng [`Pattern`] trait.
///
/// Ang trait ay minarkahan na hindi ligtas dahil ang mga indeks na ibinalik ng mga pamamaraan na [`next()`][Searcher::next] ay kinakailangan upang magsinungaling sa wastong mga hangganan ng utf8 sa haystack.
/// Ito ay nagbibigay-daan sa mga mamimili ng mga ito trait hatiin mandala ng dayami na walang karagdagang mga tseke runtime.
///
///
///
///
pub unsafe trait Searcher<'a> {
    /// Getter para sa mga kalakip na string na hahanapin in
    ///
    /// Palaging ibabalik ang parehong [`&str`][str].
    fn haystack(&self) -> &'a str;

    /// Isinasagawa ang susunod na hakbang sa paghahanap na nagsisimula sa harap.
    ///
    /// - Ibinabalik ang [`Match(a, b)`][SearchStep::Match] kung ang `haystack[a..b]` ay tumutugma sa pattern.
    /// - Ibinabalik ang [`Reject(a, b)`][SearchStep::Reject] kung ang `haystack[a..b]` ay hindi maaaring tumugma sa pattern, kahit na bahagyang.
    /// - Ibinabalik ang [`Done`][SearchStep::Done] kung ang bawat byte ng haystack ay napuntahan.
    ///
    /// Ang stream ng mga [`Match`][SearchStep::Match] at [`Reject`][SearchStep::Reject] halaga ng hanggang sa isang [`Done`][SearchStep::Done] ay maglalaman ng mga saklaw index na magkakaharap, non-overlapping, na sumasakop sa buong mandala ng dayami, at pagpapatong utf8 hangganan.
    ///
    ///
    /// Ang isang resulta na [`Match`][SearchStep::Match] ay kailangang maglaman ng buong katugmang pattern, subalit ang mga resulta ng [`Reject`][SearchStep::Reject] ay maaaring hatiin sa di-makatwirang maraming katabing mga fragment.Ang parehong mga saklaw ay maaaring may haba na zero.
    ///
    /// Bilang isang halimbawa, ang pattern `"aaa"` at ang haystack `"cbaaaaab"` ay maaaring gumawa ng stream
    /// `[Reject(0, 1), Reject(1, 2), Match(2, 5), Reject(5, 8)]`
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn next(&mut self) -> SearchStep;

    /// Hinahanap ang susunod na resulta ng [`Match`][SearchStep::Match].Tingnan ang [`next()`][Searcher::next].
    ///
    /// Hindi tulad ng [`next()`][Searcher::next], walang garantiya na ang ibinalik na mga saklaw nito at ang [`next_reject`][Searcher::next_reject] ay magkakapatong.
    /// Ito ang magbabalik `(start_match, end_match)`, kung saan start_match ay ang index ng kung saan ang tugma ay nagsisimula, at end_match ay ang index pagkatapos ng dulo ng tugma.
    ///
    ///
    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next() {
                SearchStep::Match(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }

    /// Hinahanap ang susunod na resulta ng [`Reject`][SearchStep::Reject].Tingnan ang [`next()`][Searcher::next] at [`next_match()`][Searcher::next_match].
    ///
    /// Hindi tulad ng [`next()`][Searcher::next], walang garantiya na ang ibinalik na mga saklaw nito at ang [`next_match`][Searcher::next_match] ay magkakapatong.
    ///
    ///
    #[inline]
    fn next_reject(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next() {
                SearchStep::Reject(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }
}

/// Isang pabalik na naghahanap para sa isang pattern ng string.
///
/// Ito trait nagbibigay ng mga paraan para sa paghahanap para sa mga di-magkasanib-sanib tugma ng isang pattern na nagsisimula mula sa likod (right) ng isang string.
///
/// Ipapatupad ito ng mga nauugnay na uri ng [`Searcher`] ng [`Pattern`] trait kung sinusuportahan ng pattern ang paghahanap para dito mula sa likuran.
///
///
/// Ang mga saklaw ng index na ibinalik ng trait na ito ay hindi kinakailangan upang eksaktong tumugma sa mga sa harap na paghahanap sa reverse.
///
/// Para sa kadahilanan kung bakit ang trait na ito ay minarkahan na hindi ligtas, tingnan ang magulang na trait [`Searcher`].
///
///
///
///
pub unsafe trait ReverseSearcher<'a>: Searcher<'a> {
    /// Isinasagawa ang susunod na hakbang sa paghahanap na nagsisimula sa likuran.
    ///
    /// - Ibinabalik ang [`Match(a, b)`][SearchStep::Match] kung ang `haystack[a..b]` ay tumutugma sa pattern.
    /// - Ibinabalik [`Reject(a, b)`][SearchStep::Reject] kung `haystack[a..b]` ay hindi maaaring tumugma sa mga pattern, kahit na bahagyang.
    /// - Ibinabalik ang [`Done`][SearchStep::Done] kung ang bawat byte ng haystack ay napuntahan
    ///
    /// Ang stream ng mga [`Match`][SearchStep::Match] at [`Reject`][SearchStep::Reject] halaga ng hanggang sa isang [`Done`][SearchStep::Done] ay maglalaman ng mga saklaw index na magkakaharap, non-overlapping, na sumasakop sa buong mandala ng dayami, at pagpapatong utf8 hangganan.
    ///
    ///
    /// Ang isang resulta na [`Match`][SearchStep::Match] ay kailangang maglaman ng buong katugmang pattern, subalit ang mga resulta ng [`Reject`][SearchStep::Reject] ay maaaring hatiin sa di-makatwirang maraming katabing mga fragment.Ang parehong mga saklaw ay maaaring may haba na zero.
    ///
    /// Bilang isang halimbawa, ang pattern `"aaa"` at ang haystack `"cbaaaaab"` ay maaaring gumawa ng stream `[Reject(7, 8), Match(4, 7), Reject(1, 4), Reject(0, 1)]`.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn next_back(&mut self) -> SearchStep;

    /// Mahahanap ang susunod na resulta ng [`Match`][SearchStep::Match].
    /// Tingnan ang [`next_back()`][ReverseSearcher::next_back].
    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next_back() {
                SearchStep::Match(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }

    /// Mahahanap ang susunod na resulta ng [`Reject`][SearchStep::Reject].
    /// Tingnan ang [`next_back()`][ReverseSearcher::next_back].
    #[inline]
    fn next_reject_back(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next_back() {
                SearchStep::Reject(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }
}

/// Ang isang marker na trait upang ipahayag na ang isang [`ReverseSearcher`] ay maaaring magamit para sa isang pagpapatupad ng [`DoubleEndedIterator`].
///
/// Para sa mga ito, ang impl ng [`Searcher`] at [`ReverseSearcher`] ay kailangang sundin ang mga kundisyong ito:
///
/// - Ang lahat ng mga resulta ng `next()` ay kailangang magkapareho sa mga resulta ng `next_back()` sa reverse order.
/// - `next()` at `next_back()` kailangan upang kumilos bilang ang dalawang dulo ng isang hanay ng mga halaga, iyon ay hindi nila maaaring "walk past each other".
///
/// # Examples
///
/// `char::Searcher` ay isang `DoubleEndedSearcher` sapagkat ang paghahanap para sa isang [`char`] ay nangangailangan lamang ng pagtingin nang paisa-isa, na magkatulad na kumilos mula sa magkabilang dulo.
///
/// `(&str)::Searcher` ay hindi isang `DoubleEndedSearcher` dahil ang pattern `"aa"` sa haystack `"aaa"` ay tumutugma sa alinman sa `"[aa]a"` o `"a[aa]"`, depende sa kung aling panig ito hinanap.
///
///
///
///
///
///
///
///
///
pub trait DoubleEndedSearcher<'a>: ReverseSearcher<'a> {}

/////////////////////////////////////////////////////////////////////////////
// Ipatupad para sa char
/////////////////////////////////////////////////////////////////////////////

/// Nauugnay na uri para sa `<char as Pattern<'a>>::Searcher`.
#[derive(Clone, Debug)]
pub struct CharSearcher<'a> {
    haystack: &'a str,
    // kaligtasan ng invariant: `finger`/`finger_back` Dapat na wastong utf8 byte index ng `haystack` invariant na ito ay maaaring nasira *sa loob* next_match at next_match_back, gayunpaman dapat silang lumabas na may mga daliri sa wastong mga hangganan code point.
    //
    //
    /// `finger` ay ang kasalukuyang byte index ng inaasahang paghahanap.
    /// Isipin na mayroon ito bago ang byte sa index nito, ibig sabihin
    /// `haystack[finger]` ay ang unang byte ng hiwa na dapat nating siyasatin habang naghahanap ng maaga
    ///
    finger: usize,
    /// `finger_back` ay ang kasalukuyang byte index ng reverse paghahanap.
    /// Isipin na mayroon ito pagkatapos ng byte sa index nito, ibig sabihin
    /// ang haystack [finger_back, 1] ay ang huling byte ng hiwa na dapat nating siyasatin habang naghahanap ng pasulong (at sa gayon ang unang byte na napagmasdan kapag tumatawag sa next_back()).
    ///
    finger_back: usize,
    /// Ang tauhang hinahanap
    needle: char,

    // kaligtasan ng invariant: `utf8_size` ay dapat na mas mababa sa 5
    /// Ang bilang ng mga byte `needle` ay tumatagal kapag naka-encode sa utf8.
    utf8_size: usize,
    /// Isang naka-encode na utf8 na kopya ng `needle`
    utf8_encoded: [u8; 4],
}

unsafe impl<'a> Searcher<'a> for CharSearcher<'a> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }
    #[inline]
    fn next(&mut self) -> SearchStep {
        let old_finger = self.finger;
        // KALIGTASAN: 1-4 ginagarantiyahan ang kaligtasan ng `get_unchecked`
        // 1. `self.finger` at `self.finger_back` ay pinananatili sa mga hangganan ng unicode (ito ay walang paltos)
        // 2. `self.finger >= 0` dahil nagsisimula ito sa 0 at tataas lamang
        // 3. `self.finger < self.finger_back` dahil kung hindi man ay ibabalik ng char `iter` ang `SearchStep::Done`
        // 4.
        // `self.finger` nauuna bago ang katapusan ng mandala ng dayami dahil `self.finger_back` ay nagsisimula sa pagtatapos at ang tanging bumababa
        //
        //
        let slice = unsafe { self.haystack.get_unchecked(old_finger..self.finger_back) };
        let mut iter = slice.chars();
        let old_len = iter.iter.len();
        if let Some(ch) = iter.next() {
            // magdagdag ng byte offset ng kasalukuyang character nang hindi muling pag-encode bilang utf-8
            //
            self.finger += old_len - iter.iter.len();
            if ch == self.needle {
                SearchStep::Match(old_finger, self.finger)
            } else {
                SearchStep::Reject(old_finger, self.finger)
            }
        } else {
            SearchStep::Done
        }
    }
    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        loop {
            // makakuha ng mandala ng dayami matapos ang huling character na natagpuan
            let bytes = self.haystack.as_bytes().get(self.finger..self.finger_back)?;
            // ang huling byte ng utf8 naka-encode na karayom SAFETY: mayroon kaming isang invariant na `utf8_size < 5`
            //
            let last_byte = unsafe { *self.utf8_encoded.get_unchecked(self.utf8_size - 1) };
            if let Some(index) = memchr::memchr(last_byte, bytes) {
                // Ang bagong daliri ay ang index ng mga byte nakita namin, plus one, dahil kami ay memchr'd para sa huling byte ng character.
                //
                // Tandaan na hindi ito laging nagbibigay sa amin ng isang daliri sa isang UTF8 na hangganan.
                // Kung hindi namin * natagpuan ang aming character maaari kaming mag-index sa hindi huling byte ng isang 3-byte o 4-byte na character.
                // Hindi lamang namin maaaring laktawan ang susunod na wastong panimulang byte dahil ang isang character tulad ng ꁁ (U + A041 YI SYLLABLE PA), utf-8 `EA 81 81` ay palagi naming hahanapin ang pangalawang byte kapag naghahanap para sa pangatlo.
                //
                //
                // Gayunpaman, ito ay ganap na okay.
                // Habang kami ay may invariant na self.finger ay sa isang UTF8 hangganan, invariant na ito ay hindi umasa sa loob ng ang paraan na ito (ito ay relied sa ibabaw sa CharSearcher::next()).
                //
                // Kami lamang lumabas ang paraan kapag maabot namin ang dulo ng string, o kung makakita kami ng isang bagay.Kapag nakakita kami ng isang bagay ang `finger` ay maitatakda sa isang UTF8 na hangganan.
                //
                //
                //
                //
                //
                //
                self.finger += index + 1;
                if self.finger >= self.utf8_size {
                    let found_char = self.finger - self.utf8_size;
                    if let Some(slice) = self.haystack.as_bytes().get(found_char..self.finger) {
                        if slice == &self.utf8_encoded[0..self.utf8_size] {
                            return Some((found_char, self.finger));
                        }
                    }
                }
            } else {
                // walang nahanap, exit
                self.finger = self.finger_back;
                return None;
            }
        }
    }

    // hayaan next_reject gamitin ang default na pagpapatupad mula sa Searcher trait
}

unsafe impl<'a> ReverseSearcher<'a> for CharSearcher<'a> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        let old_finger = self.finger_back;
        // KALIGTASAN: tingnan ang komento para sa next() itaas
        let slice = unsafe { self.haystack.get_unchecked(self.finger..old_finger) };
        let mut iter = slice.chars();
        let old_len = iter.iter.len();
        if let Some(ch) = iter.next_back() {
            // ibawas ang byte offset ng kasalukuyang character nang hindi muling pag-encode bilang utf-8
            //
            self.finger_back -= old_len - iter.iter.len();
            if ch == self.needle {
                SearchStep::Match(self.finger_back, old_finger)
            } else {
                SearchStep::Reject(self.finger_back, old_finger)
            }
        } else {
            SearchStep::Done
        }
    }
    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        let haystack = self.haystack.as_bytes();
        loop {
            // makuha ang haystack hanggang sa ngunit hindi kasama ang huling character na hinanap
            let bytes = haystack.get(self.finger..self.finger_back)?;
            // ang huling byte ng utf8 naka-encode na karayom SAFETY: mayroon kaming isang invariant na `utf8_size < 5`
            //
            let last_byte = unsafe { *self.utf8_encoded.get_unchecked(self.utf8_size - 1) };
            if let Some(index) = memchr::memrchr(last_byte, bytes) {
                // naghanap kami ng isang hiwa na napunan ng self.finger, magdagdag ng self.finger upang mabawi ang orihinal na index
                //
                let index = self.finger + index;
                // ibabalik ng memrchr ang index ng byte na nais naming hanapin.
                // Sa kaso ng isang ASCII character, ito talaga ang nais namin na ang aming bagong daliri ay ("after" ang nahanap na char sa tularan ng reverse iteration).
                //
                // Para sa mga multibyte chars kailangan nating lumaktaw pababa sa bilang ng mas maraming mga byte na mayroon sila kaysa sa ASCII
                //
                //
                let shift = self.utf8_size - 1;
                if index >= shift {
                    let found_char = index - shift;
                    if let Some(slice) = haystack.get(found_char..(found_char + self.utf8_size)) {
                        if slice == &self.utf8_encoded[0..self.utf8_size] {
                            // ilipat ang daliri sa bago natagpuan ang character (ibig sabihin, sa simula ng indeks nito)
                            self.finger_back = found_char;
                            return Some((self.finger_back, self.finger_back + self.utf8_size));
                        }
                    }
                }
                // Hindi namin magagamit ang daliri_back=index, laki + 1 dito.
                // Kung nakita namin ang huling char ng isang iba't ibang laki ng character (o ang gitnang byte ng ibang character) kailangan naming mauntog ang daliri_back pababa sa `index`.
                // Katulad nito na ang `finger_back` ay may potensyal na wala na sa isang hangganan, ngunit ito ay OK dahil lumalabas lamang kami sa pagpapaandar na ito sa isang hangganan o kapag ang haystack ay lubos na hinanap.
                //
                //
                // Hindi tulad ng next_match wala itong problema ng paulit-ulit na mga byte sa utf-8 dahil naghahanap kami para sa huling byte, at maaari lamang naming matagpuan ang huling byte kapag naghahanap ng pabalik.
                //
                //
                //
                //
                //
                self.finger_back = index;
            } else {
                self.finger_back = self.finger;
                // walang nahanap, exit
                return None;
            }
        }
    }

    // hayaan ang susunod_reject_back na gamitin ang default na pagpapatupad mula sa Searcher trait
}

impl<'a> DoubleEndedSearcher<'a> for CharSearcher<'a> {}

/// Naghahanap ng mga chars na katumbas ng isang naibigay na [`char`].
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find('o'), Some(4));
/// ```
impl<'a> Pattern<'a> for char {
    type Searcher = CharSearcher<'a>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> Self::Searcher {
        let mut utf8_encoded = [0; 4];
        let utf8_size = self.encode_utf8(&mut utf8_encoded).len();
        CharSearcher {
            haystack,
            finger: 0,
            finger_back: haystack.len(),
            needle: self,
            utf8_size,
            utf8_encoded,
        }
    }

    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        if (self as u32) < 128 {
            haystack.as_bytes().contains(&(self as u8))
        } else {
            let mut buffer = [0u8; 4];
            self.encode_utf8(&mut buffer).is_contained_in(haystack)
        }
    }

    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        self.encode_utf8(&mut [0u8; 4]).is_prefix_of(haystack)
    }

    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        self.encode_utf8(&mut [0u8; 4]).strip_prefix_of(haystack)
    }

    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        self.encode_utf8(&mut [0u8; 4]).is_suffix_of(haystack)
    }

    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        self.encode_utf8(&mut [0u8; 4]).strip_suffix_of(haystack)
    }
}

/////////////////////////////////////////////////////////////////////////////
// Ipataw para sa isang MultiCharEq na pambalot
/////////////////////////////////////////////////////////////////////////////

#[doc(hidden)]
trait MultiCharEq {
    fn matches(&mut self, c: char) -> bool;
}

impl<F> MultiCharEq for F
where
    F: FnMut(char) -> bool,
{
    #[inline]
    fn matches(&mut self, c: char) -> bool {
        (*self)(c)
    }
}

impl MultiCharEq for &[char] {
    #[inline]
    fn matches(&mut self, c: char) -> bool {
        self.iter().any(|&m| m == c)
    }
}

struct MultiCharEqPattern<C: MultiCharEq>(C);

#[derive(Clone, Debug)]
struct MultiCharEqSearcher<'a, C: MultiCharEq> {
    char_eq: C,
    haystack: &'a str,
    char_indices: super::CharIndices<'a>,
}

impl<'a, C: MultiCharEq> Pattern<'a> for MultiCharEqPattern<C> {
    type Searcher = MultiCharEqSearcher<'a, C>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> MultiCharEqSearcher<'a, C> {
        MultiCharEqSearcher { haystack, char_eq: self.0, char_indices: haystack.char_indices() }
    }
}

unsafe impl<'a, C: MultiCharEq> Searcher<'a> for MultiCharEqSearcher<'a, C> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }

    #[inline]
    fn next(&mut self) -> SearchStep {
        let s = &mut self.char_indices;
        // Paghambingin ang haba ng panloob na byte slice iterator upang makahanap ng haba ng kasalukuyang char
        //
        let pre_len = s.iter.iter.len();
        if let Some((i, c)) = s.next() {
            let len = s.iter.iter.len();
            let char_len = pre_len - len;
            if self.char_eq.matches(c) {
                return SearchStep::Match(i, i + char_len);
            } else {
                return SearchStep::Reject(i, i + char_len);
            }
        }
        SearchStep::Done
    }
}

unsafe impl<'a, C: MultiCharEq> ReverseSearcher<'a> for MultiCharEqSearcher<'a, C> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        let s = &mut self.char_indices;
        // Paghambingin ang haba ng panloob na byte slice iterator upang makahanap ng haba ng kasalukuyang char
        //
        let pre_len = s.iter.iter.len();
        if let Some((i, c)) = s.next_back() {
            let len = s.iter.iter.len();
            let char_len = pre_len - len;
            if self.char_eq.matches(c) {
                return SearchStep::Match(i, i + char_len);
            } else {
                return SearchStep::Reject(i, i + char_len);
            }
        }
        SearchStep::Done
    }
}

impl<'a, C: MultiCharEq> DoubleEndedSearcher<'a> for MultiCharEqSearcher<'a, C> {}

/////////////////////////////////////////////////////////////////////////////

macro_rules! pattern_methods {
    ($t:ty, $pmap:expr, $smap:expr) => {
        type Searcher = $t;

        #[inline]
        fn into_searcher(self, haystack: &'a str) -> $t {
            ($smap)(($pmap)(self).into_searcher(haystack))
        }

        #[inline]
        fn is_contained_in(self, haystack: &'a str) -> bool {
            ($pmap)(self).is_contained_in(haystack)
        }

        #[inline]
        fn is_prefix_of(self, haystack: &'a str) -> bool {
            ($pmap)(self).is_prefix_of(haystack)
        }

        #[inline]
        fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
            ($pmap)(self).strip_prefix_of(haystack)
        }

        #[inline]
        fn is_suffix_of(self, haystack: &'a str) -> bool
        where
            $t: ReverseSearcher<'a>,
        {
            ($pmap)(self).is_suffix_of(haystack)
        }

        #[inline]
        fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
        where
            $t: ReverseSearcher<'a>,
        {
            ($pmap)(self).strip_suffix_of(haystack)
        }
    };
}

macro_rules! searcher_methods {
    (forward) => {
        #[inline]
        fn haystack(&self) -> &'a str {
            self.0.haystack()
        }
        #[inline]
        fn next(&mut self) -> SearchStep {
            self.0.next()
        }
        #[inline]
        fn next_match(&mut self) -> Option<(usize, usize)> {
            self.0.next_match()
        }
        #[inline]
        fn next_reject(&mut self) -> Option<(usize, usize)> {
            self.0.next_reject()
        }
    };
    (reverse) => {
        #[inline]
        fn next_back(&mut self) -> SearchStep {
            self.0.next_back()
        }
        #[inline]
        fn next_match_back(&mut self) -> Option<(usize, usize)> {
            self.0.next_match_back()
        }
        #[inline]
        fn next_reject_back(&mut self) -> Option<(usize, usize)> {
            self.0.next_reject_back()
        }
    };
}

/////////////////////////////////////////////////////////////////////////////
// Ipatupad para sa&[char]
/////////////////////////////////////////////////////////////////////////////

// Todo: Baguhin/Alisin dahil sa hindi siguridad sa kahulugan.

/// Nauugnay na uri para sa `<&[char] as Pattern<'a>>::Searcher`.
#[derive(Clone, Debug)]
pub struct CharSliceSearcher<'a, 'b>(<MultiCharEqPattern<&'b [char]> as Pattern<'a>>::Searcher);

unsafe impl<'a, 'b> Searcher<'a> for CharSliceSearcher<'a, 'b> {
    searcher_methods!(forward);
}

unsafe impl<'a, 'b> ReverseSearcher<'a> for CharSliceSearcher<'a, 'b> {
    searcher_methods!(reverse);
}

impl<'a, 'b> DoubleEndedSearcher<'a> for CharSliceSearcher<'a, 'b> {}

/// Naghahanap ng mga char na katumbas ng alinman sa mga [`char`] na hiwa.
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find(&['l', 'l'] as &[_]), Some(2));
/// assert_eq!("Hello world".find(&['l', 'l'][..]), Some(2));
/// ```
impl<'a, 'b> Pattern<'a> for &'b [char] {
    pattern_methods!(CharSliceSearcher<'a, 'b>, MultiCharEqPattern, CharSliceSearcher);
}

/////////////////////////////////////////////////////////////////////////////
// Ipatupad para sa F: FnMut(char)-> bool
/////////////////////////////////////////////////////////////////////////////

/// Nauugnay na uri para sa `<F as Pattern<'a>>::Searcher`.
#[derive(Clone)]
pub struct CharPredicateSearcher<'a, F>(<MultiCharEqPattern<F> as Pattern<'a>>::Searcher)
where
    F: FnMut(char) -> bool;

impl<F> fmt::Debug for CharPredicateSearcher<'_, F>
where
    F: FnMut(char) -> bool,
{
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("CharPredicateSearcher")
            .field("haystack", &self.0.haystack)
            .field("char_indices", &self.0.char_indices)
            .finish()
    }
}
unsafe impl<'a, F> Searcher<'a> for CharPredicateSearcher<'a, F>
where
    F: FnMut(char) -> bool,
{
    searcher_methods!(forward);
}

unsafe impl<'a, F> ReverseSearcher<'a> for CharPredicateSearcher<'a, F>
where
    F: FnMut(char) -> bool,
{
    searcher_methods!(reverse);
}

impl<'a, F> DoubleEndedSearcher<'a> for CharPredicateSearcher<'a, F> where F: FnMut(char) -> bool {}

/// Mga paghahanap para sa [`char`] na tumutugma sa ibinigay na panaguri.
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find(char::is_uppercase), Some(0));
/// assert_eq!("Hello world".find(|c| "aeiou".contains(c)), Some(1));
/// ```
impl<'a, F> Pattern<'a> for F
where
    F: FnMut(char) -> bool,
{
    pattern_methods!(CharPredicateSearcher<'a, F>, MultiCharEqPattern, CharPredicateSearcher);
}

/////////////////////////////////////////////////////////////////////////////
// Ipatupad para sa&&str
/////////////////////////////////////////////////////////////////////////////

/// Delegado sa `&str` impl.
impl<'a, 'b, 'c> Pattern<'a> for &'c &'b str {
    pattern_methods!(StrSearcher<'a, 'b>, |&s| s, |s| s);
}

/////////////////////////////////////////////////////////////////////////////
// Ipatupad para sa &str
/////////////////////////////////////////////////////////////////////////////

/// Hindi paglalaan ng paghahanap sa substring.
///
/// Hahawakan ang pattern `""` bilang pagbabalik ng walang laman na mga tugma sa bawat hangganan ng character.
///
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find("world"), Some(6));
/// ```
impl<'a, 'b> Pattern<'a> for &'b str {
    type Searcher = StrSearcher<'a, 'b>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> StrSearcher<'a, 'b> {
        StrSearcher::new(haystack, self)
    }

    /// Sinusuri kung tumutugma ang pattern sa harap ng haystack.
    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        haystack.as_bytes().starts_with(self.as_bytes())
    }

    /// Tinatanggal ang pattern mula sa harap ng haystack, kung tumutugma ito.
    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        if self.is_prefix_of(haystack) {
            // KALIGTASAN: ang preview ay na-verify lamang na mayroon.
            unsafe { Some(haystack.get_unchecked(self.as_bytes().len()..)) }
        } else {
            None
        }
    }

    /// Sinusuri kung tumutugma ang pattern sa likod ng haystack.
    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool {
        haystack.as_bytes().ends_with(self.as_bytes())
    }

    /// Tinatanggal ang mga pattern mula sa likod ng mandala ng dayami, kung tumutugma ito.
    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str> {
        if self.is_suffix_of(haystack) {
            let i = haystack.len() - self.as_bytes().len();
            // KALIGTASAN: suffix ay lamang na-verify na umiiral.
            unsafe { Some(haystack.get_unchecked(..i)) }
        } else {
            None
        }
    }
}

/////////////////////////////////////////////////////////////////////////////
// Two Way substring na naghahanap
/////////////////////////////////////////////////////////////////////////////

#[derive(Clone, Debug)]
/// Nauugnay na uri para sa `<&str as Pattern<'a>>::Searcher`.
pub struct StrSearcher<'a, 'b> {
    haystack: &'a str,
    needle: &'b str,

    searcher: StrSearcherImpl,
}

#[derive(Clone, Debug)]
enum StrSearcherImpl {
    Empty(EmptyNeedle),
    TwoWay(TwoWaySearcher),
}

#[derive(Clone, Debug)]
struct EmptyNeedle {
    position: usize,
    end: usize,
    is_match_fw: bool,
    is_match_bw: bool,
}

impl<'a, 'b> StrSearcher<'a, 'b> {
    fn new(haystack: &'a str, needle: &'b str) -> StrSearcher<'a, 'b> {
        if needle.is_empty() {
            StrSearcher {
                haystack,
                needle,
                searcher: StrSearcherImpl::Empty(EmptyNeedle {
                    position: 0,
                    end: haystack.len(),
                    is_match_fw: true,
                    is_match_bw: true,
                }),
            }
        } else {
            StrSearcher {
                haystack,
                needle,
                searcher: StrSearcherImpl::TwoWay(TwoWaySearcher::new(
                    needle.as_bytes(),
                    haystack.len(),
                )),
            }
        }
    }
}

unsafe impl<'a, 'b> Searcher<'a> for StrSearcher<'a, 'b> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }

    #[inline]
    fn next(&mut self) -> SearchStep {
        match self.searcher {
            StrSearcherImpl::Empty(ref mut searcher) => {
                // tinatanggihan ng walang laman na karayom ang bawat char at tumutugma sa bawat walang laman na string sa pagitan nila
                let is_match = searcher.is_match_fw;
                searcher.is_match_fw = !searcher.is_match_fw;
                let pos = searcher.position;
                match self.haystack[pos..].chars().next() {
                    _ if is_match => SearchStep::Match(pos, pos),
                    None => SearchStep::Done,
                    Some(ch) => {
                        searcher.position += ch.len_utf8();
                        SearchStep::Reject(pos, searcher.position)
                    }
                }
            }
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                // TwoWaySearcher gumagawa valid *Tugma* indeks na split sa char hangganan hangga't ginagawa nito tamang matching at na mandala ng dayami at karayom ay wasto UTF-8 *Rejects* mula sa algorithm ay maaaring mahulog sa anumang mga indeks, sapagka't kami ay magsisisunod sa kanila nang manu-mano sa susunod na hangganan karakter, upang ang mga ito ay ligtas na utf-8.
                //
                //
                //
                //
                if searcher.position == self.haystack.len() {
                    return SearchStep::Done;
                }
                let is_long = searcher.memory == usize::MAX;
                match searcher.next::<RejectAndMatch>(
                    self.haystack.as_bytes(),
                    self.needle.as_bytes(),
                    is_long,
                ) {
                    SearchStep::Reject(a, mut b) => {
                        // laktawan ang susunod na hangganan ng char
                        while !self.haystack.is_char_boundary(b) {
                            b += 1;
                        }
                        searcher.position = cmp::max(b, searcher.position);
                        SearchStep::Reject(a, b)
                    }
                    otherwise => otherwise,
                }
            }
        }
    }

    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        match self.searcher {
            StrSearcherImpl::Empty(..) => loop {
                match self.next() {
                    SearchStep::Match(a, b) => return Some((a, b)),
                    SearchStep::Done => return None,
                    SearchStep::Reject(..) => {}
                }
            },
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                let is_long = searcher.memory == usize::MAX;
                // write out `true` at `false` kaso upang hikayatin ang mga compiler upang magpakadalubhasa sa dalawang mga kaso hiwalay.
                //
                if is_long {
                    searcher.next::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        true,
                    )
                } else {
                    searcher.next::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        false,
                    )
                }
            }
        }
    }
}

unsafe impl<'a, 'b> ReverseSearcher<'a> for StrSearcher<'a, 'b> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        match self.searcher {
            StrSearcherImpl::Empty(ref mut searcher) => {
                let is_match = searcher.is_match_bw;
                searcher.is_match_bw = !searcher.is_match_bw;
                let end = searcher.end;
                match self.haystack[..end].chars().next_back() {
                    _ if is_match => SearchStep::Match(end, end),
                    None => SearchStep::Done,
                    Some(ch) => {
                        searcher.end -= ch.len_utf8();
                        SearchStep::Reject(searcher.end, end)
                    }
                }
            }
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                if searcher.end == 0 {
                    return SearchStep::Done;
                }
                let is_long = searcher.memory == usize::MAX;
                match searcher.next_back::<RejectAndMatch>(
                    self.haystack.as_bytes(),
                    self.needle.as_bytes(),
                    is_long,
                ) {
                    SearchStep::Reject(mut a, b) => {
                        // laktawan ang susunod na hangganan ng char
                        while !self.haystack.is_char_boundary(a) {
                            a -= 1;
                        }
                        searcher.end = cmp::min(a, searcher.end);
                        SearchStep::Reject(a, b)
                    }
                    otherwise => otherwise,
                }
            }
        }
    }

    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        match self.searcher {
            StrSearcherImpl::Empty(..) => loop {
                match self.next_back() {
                    SearchStep::Match(a, b) => return Some((a, b)),
                    SearchStep::Done => return None,
                    SearchStep::Reject(..) => {}
                }
            },
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                let is_long = searcher.memory == usize::MAX;
                // isulat ang `true` at `false`, tulad ng `next_match`
                if is_long {
                    searcher.next_back::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        true,
                    )
                } else {
                    searcher.next_back::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        false,
                    )
                }
            }
        }
    }
}

/// Ang panloob na estado ng two-way substring algorithm ng paghahanap.
#[derive(Clone, Debug)]
struct TwoWaySearcher {
    // constants
    /// kritikal na index ng pagpapatungkol
    crit_pos: usize,
    /// kritikal paktorisasyon index para sa reverse karayom
    crit_pos_back: usize,
    period: usize,
    /// `byteset` ay isang extension (hindi bahagi ng two way algorithm);
    /// ito ay isang 64-bit "fingerprint" kung saan ang bawat hanay kinagat `j` kumakatawan sa isang (byte&63)==j naroroon sa karayom.
    ///
    byteset: u64,

    // variables
    position: usize,
    end: usize,
    /// index sa karayom bago kung saan na namin maitugma
    memory: usize,
    /// index sa karayom pagkatapos na tugma na kami
    memory_back: usize,
}

/*
    This is the Two-Way search algorithm, which was introduced in the paper:
    Crochemore, M., Perrin, D., 1991, Two-way string-matching, Journal of the ACM 38(3):651-675.

    Here's some background information.

    A *word* is a string of symbols. The *length* of a word should be a familiar
    notion, and here we denote it for any word x by |x|.
    (We also allow for the possibility of the *empty word*, a word of length zero).

    If x is any non-empty word, then an integer p with 0 < p <= |x| is said to be a
    *period* for x iff for all i with 0 <= i <= |x| - p - 1, we have x[i] == x[i+p].
    For example, both 1 and 2 are periods for the string "aa". As another example,
    the only period of the string "abcd" is 4.

    We denote by period(x) the *smallest* period of x (provided that x is non-empty).
    This is always well-defined since every non-empty word x has at least one period,
    |x|. We sometimes call this *the period* of x.

    If u, v and x are words such that x = uv, where uv is the concatenation of u and
    v, then we say that (u, v) is a *factorization* of x.

    Let (u, v) be a factorization for a word x. Then if w is a non-empty word such
    that both of the following hold

      - either w is a suffix of u or u is a suffix of w
      - either w is a prefix of v or v is a prefix of w

    then w is said to be a *repetition* for the factorization (u, v).

    Just to unpack this, there are four possibilities here. Let w = "abc". Then we
    might have:

      - w is a suffix of u and w is a prefix of v. ex: ("lolabc", "abcde")
      - w is a suffix of u and v is a prefix of w. ex: ("lolabc", "ab")
      - u is a suffix of w and w is a prefix of v. ex: ("bc", "abchi")
      - u is a suffix of w and v is a prefix of w. ex: ("bc", "a")

    Note that the word vu is a repetition for any factorization (u,v) of x = uv,
    so every factorization has at least one repetition.

    If x is a string and (u, v) is a factorization for x, then a *local period* for
    (u, v) is an integer r such that there is some word w such that |w| = r and w is
    a repetition for (u, v).

    We denote by local_period(u, v) the smallest local period of (u, v). We sometimes
    call this *the local period* of (u, v). Provided that x = uv is non-empty, this
    is well-defined (because each non-empty word has at least one factorization, as
    noted above).

    It can be proven that the following is an equivalent definition of a local period
    for a factorization (u, v): any positive integer r such that x[i] == x[i+r] for
    all i such that |u| - r <= i <= |u| - 1 and such that both x[i] and x[i+r] are
    defined. (i.e., i > 0 and i + r < |x|).

    Using the above reformulation, it is easy to prove that

        1 <= local_period(u, v) <= period(uv)

    A factorization (u, v) of x such that local_period(u,v) = period(x) is called a
    *critical factorization*.

    The algorithm hinges on the following theorem, which is stated without proof:

    **Critical Factorization Theorem** Any word x has at least one critical
    factorization (u, v) such that |u| < period(x).

    The purpose of maximal_suffix is to find such a critical factorization.

    If the period is short, compute another factorization x = u' v' to use
    for reverse search, chosen instead so that |v'| < period(x).

*/
impl TwoWaySearcher {
    fn new(needle: &[u8], end: usize) -> TwoWaySearcher {
        let (crit_pos_false, period_false) = TwoWaySearcher::maximal_suffix(needle, false);
        let (crit_pos_true, period_true) = TwoWaySearcher::maximal_suffix(needle, true);

        let (crit_pos, period) = if crit_pos_false > crit_pos_true {
            (crit_pos_false, period_false)
        } else {
            (crit_pos_true, period_true)
        };

        // Ang isang partikular na nababasa na paliwanag tungkol sa kung ano ang nangyayari dito ay matatagpuan sa libro ng Crochemore at Rytter na "Text Algorithms", ch 13.
        // Partikular makita ang code para sa "Algorithm CP" sa p.
        // 323.
        //
        // Ano ang nangyayari ay mayroon kaming ilang mga kritikal na pag-factor (u, v) ng karayom, at nais naming matukoy kung ikaw ay isang panlapi ng&v [.. panahon].
        // Kung ito ay, gumagamit kami ng "Algorithm CP1".
        // Kung hindi man gumagamit kami ng "Algorithm CP2", na na-optimize para sa kung malaki ang panahon ng karayom.
        //
        //
        if needle[..crit_pos] == needle[period..period + crit_pos] {
            // kaso ng maikling panahon-ang panahon ay eksaktong pagkalkula ng isang hiwalay na kritikal na pag-factor para sa baligtad na karayom x=u 'v' kung saan | v '|<period(x).
            //
            // Ito ay pinabilis ng panahon na alam na.
            // Tandaan na ang isang kaso tulad ng x= "acba" ay maaaring na-factored nang eksakto pasulong (crit_pos=1, period=3) habang na-factored na may tinatayang panahon sa kabaligtaran (crit_pos=2, period=2).
            // Ginagamit namin ang naibigay na reverse factorization ngunit panatilihin ang eksaktong panahon.
            //
            //
            //
            //
            let crit_pos_back = needle.len()
                - cmp::max(
                    TwoWaySearcher::reverse_maximal_suffix(needle, period, false),
                    TwoWaySearcher::reverse_maximal_suffix(needle, period, true),
                );

            TwoWaySearcher {
                crit_pos,
                crit_pos_back,
                period,
                byteset: Self::byteset_create(&needle[..period]),

                position: 0,
                end,
                memory: 0,
                memory_back: needle.len(),
            }
        } else {
            // mahabang panahon case-kami ay may isang approximation sa aktwal na panahon, at huwag gumamit ng memorization.
            //
            //
            // Tantyahin ang panahon sa pamamagitan ng mas mababang bound max(|u|, |v|) + 1.
            // Ang kritikal na pag-factor ay mahusay na gamitin para sa parehong pasulong at baligtarin ang paghahanap.
            //

            TwoWaySearcher {
                crit_pos,
                crit_pos_back: crit_pos,
                period: cmp::max(crit_pos, needle.len() - crit_pos) + 1,
                byteset: Self::byteset_create(needle),

                position: 0,
                end,
                memory: usize::MAX, // Dummy halaga upang magpahiwatig na ang panahon ay mahaba
                memory_back: usize::MAX,
            }
        }
    }

    #[inline]
    fn byteset_create(bytes: &[u8]) -> u64 {
        bytes.iter().fold(0, |a, &b| (1 << (b & 0x3f)) | a)
    }

    #[inline]
    fn byteset_contains(&self, byte: u8) -> bool {
        (self.byteset >> ((byte & 0x3f) as usize)) & 1 != 0
    }

    // Ang isa sa mga pangunahing ideya ng Dalawang-Daan ay na isinasama namin ang karayom sa dalawang halves, (u, v), at simulang subukang hanapin ang v sa haystack sa pamamagitan ng pag-scan ng kaliwa hanggang kanan.
    // Kung v tugma, subukan namin upang tumugma u sa pamamagitan ng pag-scan sa kanan pakaliwa.
    // Gaano kalayo ang maaari naming tumalon kapag nakatagpo kami ng isang hindi pagtutugma ay ang lahat batay sa ang katunayan na (u, v) ay isang kritikal na paktorisasyon para sa mga karayom.
    //
    //
    #[inline]
    fn next<S>(&mut self, haystack: &[u8], needle: &[u8], long_period: bool) -> S::Output
    where
        S: TwoWayStrategy,
    {
        // `next()` gumagamit ng `self.position` bilang cursor nito
        let old_pos = self.position;
        let needle_last = needle.len() - 1;
        'search: loop {
            // Suriin na mayroon kaming silid upang maghanap sa posisyon + karayom_last ay hindi maaaring mag-overflow kung ipinapalagay namin ang mga hiwa ay nalilimitahan ng saklaw ng isize.
            //
            //
            let tail_byte = match haystack.get(self.position + needle_last) {
                Some(&b) => b,
                None => {
                    self.position = haystack.len();
                    return S::rejecting(old_pos, self.position);
                }
            };

            if S::use_early_reject() && old_pos != self.position {
                return S::rejecting(old_pos, self.position);
            }

            // Mabilis na laktawan sa pamamagitan ng malalaking bahagi na hindi nauugnay sa aming substring
            if !self.byteset_contains(tail_byte) {
                self.position += needle.len();
                if !long_period {
                    self.memory = 0;
                }
                continue 'search;
            }

            // Tingnan kung tumutugma ang tamang bahagi ng karayom
            let start =
                if long_period { self.crit_pos } else { cmp::max(self.crit_pos, self.memory) };
            for i in start..needle.len() {
                if needle[i] != haystack[self.position + i] {
                    self.position += i - self.crit_pos + 1;
                    if !long_period {
                        self.memory = 0;
                    }
                    continue 'search;
                }
            }

            // Tingnan kung tumutugma ang kaliwang bahagi ng karayom
            let start = if long_period { 0 } else { self.memory };
            for i in (start..self.crit_pos).rev() {
                if needle[i] != haystack[self.position + i] {
                    self.position += self.period;
                    if !long_period {
                        self.memory = needle.len() - self.period;
                    }
                    continue 'search;
                }
            }

            // Nakakita kami ng tugma!
            let match_pos = self.position;

            // Note: magdagdag ng self.period sa halip na needle.len() upang magkaroon ng magkakapatong na mga tugma
            self.position += needle.len();
            if !long_period {
                self.memory = 0; // nakatakda sa needle.len(), self.period para sa nagpapang-abot na mga tugma
            }

            return S::matching(match_pos, match_pos + needle.len());
        }
    }

    // Sumusunod ang mga ideya sa `next()`.
    //
    // Ang mga kahulugan ay simetriko, na may period(x) = period(reverse(x)) at local_period(u, v) = local_period(reverse(v), reverse(u)), kaya kung ang (u, v) ay isang kritikal na pag-factorize, ganoon din ang (reverse(v), reverse(u)).
    //
    //
    // Para sa reverse kaso kami ay nakalkula isang kritikal na paktorisasyon x=u 'v' (patlang `crit_pos_back`).Kailangan namin | u |<period(x) para sa pasulong na kaso at sa gayon | v '|<period(x) para sa reverse.
    //
    // Upang maghanap ng pabaliktad sa pamamagitan ng haystack, naghahanap kami pasulong sa pamamagitan ng isang baligtad na haystack na may isang baligtad na karayom, na tumutugma muna sa iyo 'at pagkatapos ay v'.
    //
    //
    //
    //
    #[inline]
    fn next_back<S>(&mut self, haystack: &[u8], needle: &[u8], long_period: bool) -> S::Output
    where
        S: TwoWayStrategy,
    {
        // `next_back()` ay gumagamit ng `self.end` nito cursor-upang ang `next()` at `next_back()` ay malayang.
        //
        let old_end = self.end;
        'search: loop {
            // Tiyaking mayroon kaming room upang maghanap sa dulo, needle.len() ay wrap sa paligid kapag walang karagdagang puwang, ngunit dahil sa slice limitasyon ng haba ay hindi kailanman ito ay maaaring I-wrap ang lahat ng paraan bumalik sa ang haba ng mandala ng dayami.
            //
            //
            //
            let front_byte = match haystack.get(self.end.wrapping_sub(needle.len())) {
                Some(&b) => b,
                None => {
                    self.end = 0;
                    return S::rejecting(0, old_end);
                }
            };

            if S::use_early_reject() && old_end != self.end {
                return S::rejecting(self.end, old_end);
            }

            // Mabilis na laktawan sa pamamagitan ng malalaking bahagi na hindi nauugnay sa aming substring
            if !self.byteset_contains(front_byte) {
                self.end -= needle.len();
                if !long_period {
                    self.memory_back = needle.len();
                }
                continue 'search;
            }

            // Tingnan kung tumutugma ang kaliwang bahagi ng karayom
            let crit = if long_period {
                self.crit_pos_back
            } else {
                cmp::min(self.crit_pos_back, self.memory_back)
            };
            for i in (0..crit).rev() {
                if needle[i] != haystack[self.end - needle.len() + i] {
                    self.end -= self.crit_pos_back - i;
                    if !long_period {
                        self.memory_back = needle.len();
                    }
                    continue 'search;
                }
            }

            // Tingnan kung tumutugma ang tamang bahagi ng karayom
            let needle_end = if long_period { needle.len() } else { self.memory_back };
            for i in self.crit_pos_back..needle_end {
                if needle[i] != haystack[self.end - needle.len() + i] {
                    self.end -= self.period;
                    if !long_period {
                        self.memory_back = self.period;
                    }
                    continue 'search;
                }
            }

            // Nakakita kami ng tugma!
            let match_pos = self.end - needle.len();
            // Note: sub self.period sa halip na needle.len() upang magkaroon ng magkakapatong na mga tugma
            self.end -= needle.len();
            if !long_period {
                self.memory_back = needle.len();
            }

            return S::matching(match_pos, match_pos + needle.len());
        }
    }

    // Kalkulahin ang maximum na panlapi ng `arr`.
    //
    // Ang maximum na panlapi ay isang posibleng kritikal na pag-factor (u, v) ng `arr`.
    //
    // Ibinabalik (`i`, `p`) kung saan `i` ay ang panimulang index ng v at `p` ay ang panahon ng v.
    //
    // `order_greater` tinutukoy kung ang leksikal na pagkakasunud-sunod ay `<` o `>`.
    // Ang parehong mga order ay dapat na kalkulahin-ang pag-order na may pinakamalaking `i` ay nagbibigay ng isang kritikal na pag-factor.
    //
    //
    // Para sa mga pangmatagalang kaso, ang nagresultang panahon ay hindi eksakto (ito ay masyadong maikli).
    //
    #[inline]
    fn maximal_suffix(arr: &[u8], order_greater: bool) -> (usize, usize) {
        let mut left = 0; // Naaayon sa i sa papel
        let mut right = 1; // Naaayon sa j sa papel
        let mut offset = 0; // Naaayon sa k sa papel, ngunit nagsisimula sa 0
        // upang tumugma sa 0-based na pag-index.
        let mut period = 1; // Naaayon sa p sa papel

        while let Some(&a) = arr.get(right + offset) {
            // `left` ay papasok hanggang `right` ay.
            let b = arr[left + offset];
            if (a < b && !order_greater) || (a > b && order_greater) {
                // Ang Suffix ay mas maliit, ang panahon ay buong unlapi sa ngayon.
                right += offset + 1;
                offset = 0;
                period = right - left;
            } else if a == b {
                // Isulong sa pamamagitan ng pag-uulit ng kasalukuyang panahon.
                if offset + 1 == period {
                    right += offset + 1;
                    offset = 0;
                } else {
                    offset += 1;
                }
            } else {
                // Ang Suffix ay mas malaki, magsimula sa kasalukuyang lokasyon.
                left = right;
                right += 1;
                offset = 0;
                period = 1;
            }
        }
        (left, period)
    }

    // Kalkulahin ang maximum na panlapi ng baligtad ng `arr`.
    //
    // Ang maximum na panlapi ay isang posibleng kritikal na pag-factor (u ', v') ng `arr`.
    //
    // Ibinabalik `i` kung saan `i` ay ang panimulang index ng v ', mula sa likod;
    // babalik kaagad kapag naabot ang isang panahon ng `known_period`.
    //
    // `order_greater` tinutukoy kung ang leksikal na pagkakasunud-sunod ay `<` o `>`.
    // Ang parehong mga order ay dapat na kalkulahin-ang pag-order na may pinakamalaking `i` ay nagbibigay ng isang kritikal na pag-factor.
    //
    //
    // Para sa mga pangmatagalang kaso, ang nagresultang panahon ay hindi eksakto (ito ay masyadong maikli).
    fn reverse_maximal_suffix(arr: &[u8], known_period: usize, order_greater: bool) -> usize {
        let mut left = 0; // Naaayon sa i sa papel
        let mut right = 1; // Naaayon sa j sa papel
        let mut offset = 0; // Naaayon sa k sa papel, ngunit nagsisimula sa 0
        // upang tumugma sa 0-based na pag-index.
        let mut period = 1; // Naaayon sa p sa papel
        let n = arr.len();

        while right + offset < n {
            let a = arr[n - (1 + right + offset)];
            let b = arr[n - (1 + left + offset)];
            if (a < b && !order_greater) || (a > b && order_greater) {
                // Ang Suffix ay mas maliit, ang panahon ay buong unlapi sa ngayon.
                right += offset + 1;
                offset = 0;
                period = right - left;
            } else if a == b {
                // Isulong sa pamamagitan ng pag-uulit ng kasalukuyang panahon.
                if offset + 1 == period {
                    right += offset + 1;
                    offset = 0;
                } else {
                    offset += 1;
                }
            } else {
                // Ang Suffix ay mas malaki, magsimula sa kasalukuyang lokasyon.
                left = right;
                right += 1;
                offset = 0;
                period = 1;
            }
            if period == known_period {
                break;
            }
        }
        debug_assert!(period <= known_period);
        left
    }
}

// Pinapayagan ng TwoWayStrategy ang algorithm na alinman sa laktawan ang mga hindi tugma nang mabilis hangga't maaari, o upang gumana sa isang mode kung saan mabilis itong naglalabas ng Mga Tanggihan.
//
trait TwoWayStrategy {
    type Output;
    fn use_early_reject() -> bool;
    fn rejecting(a: usize, b: usize) -> Self::Output;
    fn matching(a: usize, b: usize) -> Self::Output;
}

/// Laktawan upang tumugma sa mga agwat nang mabilis hangga't maaari
enum MatchOnly {}

impl TwoWayStrategy for MatchOnly {
    type Output = Option<(usize, usize)>;

    #[inline]
    fn use_early_reject() -> bool {
        false
    }
    #[inline]
    fn rejecting(_a: usize, _b: usize) -> Self::Output {
        None
    }
    #[inline]
    fn matching(a: usize, b: usize) -> Self::Output {
        Some((a, b))
    }
}

/// Emit Tumanggi nang regular
enum RejectAndMatch {}

impl TwoWayStrategy for RejectAndMatch {
    type Output = SearchStep;

    #[inline]
    fn use_early_reject() -> bool {
        true
    }
    #[inline]
    fn rejecting(a: usize, b: usize) -> Self::Output {
        SearchStep::Reject(a, b)
    }
    #[inline]
    fn matching(a: usize, b: usize) -> Self::Output {
        SearchStep::Match(a, b)
    }
}