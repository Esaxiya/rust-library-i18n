//! Operations may kaugnayan sa UTF-8 pagpapatunay.

use crate::mem;

use super::Utf8Error;

/// Ibinabalik ang paunang codepoint accumulator para sa unang byte.
/// Ang unang byte ay espesyal, nais lamang sa ibaba 5 bits para sa lapad 2, 4 na piraso para sa lapad 3, at 3 mga piraso para sa lapad 4.
///
#[inline]
fn utf8_first_byte(byte: u8, width: u32) -> u32 {
    (byte & (0x7F >> width)) as u32
}

/// Ibinabalik ang halaga ng na-update na `ch` na may pagpapatuloy byte `byte`.
#[inline]
fn utf8_acc_cont_byte(ch: u32, byte: u8) -> u32 {
    (ch << 6) | (byte & CONT_MASK) as u32
}

/// Sinusuri kung ang byte ay isang UTF-8 pagpapatuloy byte (ibig sabihin, nagsisimula sa mga bit `10`).
///
#[inline]
pub(super) fn utf8_is_cont_byte(byte: u8) -> bool {
    (byte & !CONT_MASK) == TAG_CONT_U8
}

#[inline]
fn unwrap_or_0(opt: Option<&u8>) -> u8 {
    match opt {
        Some(&byte) => byte,
        None => 0,
    }
}

/// Binabasa ang susunod na code point sa labas ng isang byte iterator (ipagpalagay ng isang UTF-8-tulad ng encoding).
///
#[unstable(feature = "str_internals", issue = "none")]
#[inline]
pub fn next_code_point<'a, I: Iterator<Item = &'a u8>>(bytes: &mut I) -> Option<u32> {
    // I-decode ang UTF-8
    let x = *bytes.next()?;
    if x < 128 {
        return Some(x as u32);
    }

    // Sinusundan ng kaso ng Multibyte ang Mag-decode mula sa isang kumbinasyon ng byte mula sa: [[[x y] z] w]
    //
    // NOTE: Ang pagganap ay sensitibo sa eksaktong pagbabalangkas dito
    let init = utf8_first_byte(x, 2);
    let y = unwrap_or_0(bytes.next());
    let mut ch = utf8_acc_cont_byte(init, y);
    if x >= 0xE0 {
        // [[x y z] w] kaso
        // 5th bit sa 0xE0 .. Ang 0xEF ay laging malinaw, kaya `init` ay may bisa pa rin
        let z = unwrap_or_0(bytes.next());
        let y_z = utf8_acc_cont_byte((y & CONT_MASK) as u32, z);
        ch = init << 12 | y_z;
        if x >= 0xF0 {
            // [x y z w] kaso gamitin lamang ang mas mababang 3 piraso ng `init`
            //
            let w = unwrap_or_0(bytes.next());
            ch = (init & 7) << 18 | utf8_acc_cont_byte(y_z, w);
        }
    }

    Some(ch)
}

/// Binabasa ang huling code point sa labas ng isang byte iterator (ipagpalagay ng isang UTF-8-tulad ng encoding).
///
#[inline]
pub(super) fn next_code_point_reverse<'a, I>(bytes: &mut I) -> Option<u32>
where
    I: DoubleEndedIterator<Item = &'a u8>,
{
    // I-decode ang UTF-8
    let w = match *bytes.next_back()? {
        next_byte if next_byte < 128 => return Some(next_byte as u32),
        back_byte => back_byte,
    };

    // Multibyte case sumusunod Decode mula sa isang byte kumbinasyon ng: [x [y [z w]]]
    //
    let mut ch;
    let z = unwrap_or_0(bytes.next_back());
    ch = utf8_first_byte(z, 2);
    if utf8_is_cont_byte(z) {
        let y = unwrap_or_0(bytes.next_back());
        ch = utf8_first_byte(y, 3);
        if utf8_is_cont_byte(y) {
            let x = unwrap_or_0(bytes.next_back());
            ch = utf8_first_byte(x, 4);
            ch = utf8_acc_cont_byte(ch, y);
        }
        ch = utf8_acc_cont_byte(ch, z);
    }
    ch = utf8_acc_cont_byte(ch, w);

    Some(ch)
}

// gumamit ng truncation upang magkasya ang u64 sa usize
const NONASCII_MASK: usize = 0x80808080_80808080u64 as usize;

/// Ibinabalik `true` kung anumang byte sa salitang `x` ay nonascii (>=128).
#[inline]
fn contains_nonascii(x: usize) -> bool {
    (x & NONASCII_MASK) != 0
}

/// Naglalakad sa pamamagitan ng `v` na suriin na ito ay isang wastong pagkakasunud-sunod ng UTF-8, ibabalik ang `Ok(())` sa kasong iyon, o, kung ito ay hindi wasto, `Err(err)`.
///
#[inline(always)]
pub(super) fn run_utf8_validation(v: &[u8]) -> Result<(), Utf8Error> {
    let mut index = 0;
    let len = v.len();

    let usize_bytes = mem::size_of::<usize>();
    let ascii_block_size = 2 * usize_bytes;
    let blocks_end = if len >= ascii_block_size { len - ascii_block_size + 1 } else { 0 };
    let align = v.as_ptr().align_offset(usize_bytes);

    while index < len {
        let old_offset = index;
        macro_rules! err {
            ($error_len: expr) => {
                return Err(Utf8Error { valid_up_to: old_offset, error_len: $error_len })
            };
        }

        macro_rules! next {
            () => {{
                index += 1;
                // kailangan namin ng data, ngunit wala: error!
                if index >= len {
                    err!(None)
                }
                v[index]
            }};
        }

        let first = v[index];
        if first >= 128 {
            let w = UTF8_CHAR_WIDTH[first as usize];
            // Ang pag-encode ng 2-byte ay para sa mga codepoints\u {0080} upang\u {07ff} muna C2 80 huling DF BF
            // Ang 3-byte encoding ay para sa mga codepoints\u {0800} hanggang\u {ffff} unang E0 A0 80 huling EF BF BF na hindi kasama ang mga kahaliling codepoints\u {d800} sa\u {dfff} ED A0 80 hanggang ED BF BF
            // Ang 4-byte encoding ay para sa mga codepoints\u {1000} 0 hanggang\u {10ff} ff muna F0 90 80 80 huling F4 8F BF BF
            //
            // Gamitin ang UTF-8 syntax mula sa RFC
            //
            // https://tools.ietf.org/html/rfc3629
            // UTF8-1=% x00-7F UTF8-2=% xC2-DF UTF8-buntot UTF8-3= %xE0% xA0-BF UTF8-buntot/% xE1-EC 2( UTF8-tail )/%xED% x80-9F UTF8-buntot/% xEE-EF 2( UTF8-tail ) UTF8-4= %xF0% X90-BF 2( UTF8-tail )/% XF1-F3 3( UTF8-tail )/%xF4% x80-8F 2( UTF8-tail )
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            match w {
                2 => {
                    if next!() & !CONT_MASK != TAG_CONT_U8 {
                        err!(Some(1))
                    }
                }
                3 => {
                    match (first, next!()) {
                        (0xE0, 0xA0..=0xBF)
                        | (0xE1..=0xEC, 0x80..=0xBF)
                        | (0xED, 0x80..=0x9F)
                        | (0xEE..=0xEF, 0x80..=0xBF) => {}
                        _ => err!(Some(1)),
                    }
                    if next!() & !CONT_MASK != TAG_CONT_U8 {
                        err!(Some(2))
                    }
                }
                4 => {
                    match (first, next!()) {
                        (0xF0, 0x90..=0xBF) | (0xF1..=0xF3, 0x80..=0xBF) | (0xF4, 0x80..=0x8F) => {}
                        _ => err!(Some(1)),
                    }
                    if next!() & !CONT_MASK != TAG_CONT_U8 {
                        err!(Some(2))
                    }
                    if next!() & !CONT_MASK != TAG_CONT_U8 {
                        err!(Some(3))
                    }
                }
                _ => err!(Some(1)),
            }
            index += 1;
        } else {
            // Kaso ng Ascii, subukang lumaktaw nang mabilis.
            // Kapag nakahanay ang pointer, basahin ang 2 mga salita ng data bawat pag-ulit hanggang sa makita namin ang isang salita na naglalaman ng isang byte na hindi-ascii.
            //
            if align != usize::MAX && align.wrapping_sub(index) % usize_bytes == 0 {
                let ptr = v.as_ptr();
                while index < blocks_end {
                    // KALIGTASAN: dahil ang `align - index` at `ascii_block_size` ay
                    // mga multiply ng `usize_bytes`, `block = ptr.add(index)` ay palaging nakahanay sa isang `usize` kaya't ligtas na makilala ang parehong `block` at `block.offset(1)`.
                    //
                    //
                    unsafe {
                        let block = ptr.add(index) as *const usize;
                        // masira kung mayroong isang nonascii byte
                        let zu = contains_nonascii(*block);
                        let zv = contains_nonascii(*block.offset(1));
                        if zu | zv {
                            break;
                        }
                    }
                    index += ascii_block_size;
                }
                // hakbang mula sa punto kung saan tumigil ang loop na patungkol sa salita
                while index < len && v[index] < 128 {
                    index += 1;
                }
            } else {
                index += 1;
            }
        }
    }

    Ok(())
}

// https://tools.ietf.org/html/rfc3629
static UTF8_CHAR_WIDTH: [u8; 256] = [
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    1, // 0x1F
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    1, // 0x3F
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    1, // 0x5F
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    1, // 0x7F
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, // 0x9F
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, // 0xBF
    0, 0, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
    2, // 0xDF
    3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, // 0xEF
    4, 4, 4, 4, 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, // 0xFF
];

/// Ibinigay ng isang unang byte, kung gaano karaming mga byte ay sa ito UTF-8 character.
#[unstable(feature = "str_internals", issue = "none")]
#[inline]
pub fn utf8_char_width(b: u8) -> usize {
    UTF8_CHAR_WIDTH[b as usize] as usize
}

/// Mask ng mga halaga ng piraso ng isang pagpapatuloy na byte.
const CONT_MASK: u8 = 0b0011_1111;
/// Halaga ng bits tag (tag mask ay !CONT_MASK) ng isang pagpapatuloy byte.
const TAG_CONT_U8: u8 = 0b1000_0000;

// putulin ang `&str` hanggang haba ng halos katumbas ng `max` ibalik ang `true` kung ito ay pinutol, at ang bagong str.
//
pub(super) fn truncate_to_char_boundary(s: &str, mut max: usize) -> (bool, &str) {
    if max >= s.len() {
        (false, s)
    } else {
        while !s.is_char_boundary(max) {
            max -= 1;
        }
        (true, &s[..max])
    }
}